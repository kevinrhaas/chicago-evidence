from pathlib import Path
import argparse,fcntl,hashlib,importlib.util,json,os,re,shutil,subprocess,sys,datetime,time
HERE=Path(__file__).parent;R=Path('/workspace/chicago-pr1700-memory-constant-scalars-20261104');APP=R/'chicago/4d';REPO='kevinrhaas/chicago';PUBLIC='steward/t2804-driver-garment-coverage-projected-20261104';PR=1700;LAP='8220eec02e008d11b04de8c8c45312fae9bbe957';OLD='967b427e5f8681b27eceefb065cf6f37199e3bbc';C='e803db79d3b152e444158104f796c6106f9080ab';BASE='e803db79d3b152e444158104f796c6106f9080ab';TREE='44fafc531cf7f8389afd68aebc203a476b637e43';TITLE='Repair driver clothing, movement and phone memory'
SUP=Path('/workspace/.cloud-setup/transport-supervise.py');LOCK=Path('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock');GATE=Path('/workspace/.cloud-setup/transport-current-20261103/actual-pr1700-e803-original-fourpart-01/CLOSED.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text());save=lambda p,j:Path(p).write_text(json.dumps(j,indent=2)+'\n')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--binding',type=Path,required=True);a=ap.parse_args();auth=load(a.binding);authsha=sha(a.binding)
 assert __debug__ and sys.version_info[:2]==(3,11)and auth['ROOT_POST_FOURPART_DELIVERY_GO']is True and auth['template_only']is False
 assert sha(__file__)==auth['runner_sha256']and sha(HERE/'COMMIT-MESSAGE.txt')==auth['message_sha256'];assert sha(GATE)==auth['gate_sha256'];gate=load(GATE)
 assert gate['status']=='PASS_ALL_FOUR_NATIVE_CHECK_PARTS_SAME_STAGED_SOURCE'and gate['resources']['accepted']and gate['owned_TMPDIR_cleanup_complete']and len(gate['ledger'])==4
 assert gate['source_before']==gate['source_after']==auth['source']and auth['source']['HEAD']==C and auth['source']['TREE']==TREE and auth['source']['MERGE_HEAD']==[OLD]
 for row in gate['ledger']:
  rr=row['result'];assert rr['returncode']==0 and not rr['timed_out']and rr['requested_timeout_seconds']==rr['effective_timeout_seconds']==600 and rr['timeout_override_reason']is None
  assert row['resources']['accepted']and row['cleanup']['cleanup_complete']and not row['cleanup']['remaining_owned_children']and row['source_before']==row['source_after']==auth['source']and sha(row['log'])==row['log_sha256']and row['native_footer_counts']==gate['expected_parts'][str(row['part'])]
 lock=LOCK.open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',CHECK_JOBS='4',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',C4D_RULINGS_BASE=BASE)
 env['GH_HOST']='github.com'
 for k in ['GH_REPO','GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR','CHECK_PART','BASE','CHECK_TIMINGS','GIT_DIR','GIT_WORK_TREE']:env.pop(k,None)
 for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:assert env[k]=='1'
 meta=dict(env,GIT_NO_LAZY_FETCH='1');git=lambda *args:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(R),*args],env=meta,timeout=45);val=lambda *args:git(*args).decode().strip()
 def api(path):return json.loads(subprocess.check_output(['gh','api','repos/'+REPO+'/'+path],env=env,timeout=45))
 def origin():
  assert val('config','--get','remote.origin.url')=='https://github.com/kevinrhaas/chicago.git'and val('remote','get-url','--push','origin')=='https://github.com/kevinrhaas/chicago.git'
 admission_records=[]
 def admission(expected):
  origin()
  # Only bounded read-only propagation reconciliation; never repeat a mutation.
  for attempt in range(3):
   pr=api('pulls/1700');ref=api('git/ref/heads/'+PUBLIC);lap=api('git/ref/heads/lap/pr-1700');lc=api('git/commits/'+LAP)
   checks=dict(open=pr['state']=='open',ready=not pr['draft'],unmerged=not pr['merged'],PR_HEAD=pr['head']['sha']==expected,feature_HEAD=ref['object']['sha']==expected,branch=pr['head']['ref']==PUBLIC,repo=pr['head']['repo']['full_name']==REPO,base=pr['base']['ref']=='dev',lap=lap['object']['sha']==LAP,lap_owner=lc['parents']==[]and lc['tree']['sha']=='4b825dc642cb6eb9a060e54bf8d69288fbee4904'and 'garment visible increment'in lc['message'])
   record=dict(expected_HEAD=expected,attempt=attempt+1,checks=checks,PR=pr,feature=ref,lap=lap,lap_commit=lc);admission_records.append(record);save(HERE/('READONLY-ADMISSION-%02d.json'%len(admission_records)),record)
   if all(checks.values()):return dict(PR=pr,feature=ref,lap=lap,lap_commit=lc)
   if attempt<2:time.sleep(2)
  raise AssertionError('Exact public/lap admission mismatch: '+json.dumps(checks))
 def source(expected,staged):
  assert sha(a.binding)==authsha and sha(__file__)==auth['runner_sha256']and sha(HERE/'COMMIT-MESSAGE.txt')==auth['message_sha256']and sha(R/'.git/config')==auth['config_sha256']
  for p,h in auth['execution_pins'].items():assert sha(p)==h
  assert val('branch','--show-current')==auth['local_branch']and val('rev-parse','refs/remotes/origin/dev')==BASE and not git('ls-files','-u').strip()and not git('diff','--name-only').strip()and not git('ls-files','--others','--exclude-standard').strip()
  merge=Path(val('rev-parse','--git-path','MERGE_HEAD'));merge=merge if merge.is_absolute()else R/merge;mh=merge.read_text().split()if merge.exists()else[];assert mh==([OLD]if staged else[])
  t=val('write-tree');s=dict(HEAD=val('rev-parse','HEAD'),TREE=t,APP=val('rev-parse',t+':chicago/4d'),MERGE_HEAD=mh,semantic_index_sha256=hashlib.sha256(git('ls-files','--stage','-z')).hexdigest());want=dict(auth['source'],HEAD=expected,MERGE_HEAD=mh);assert s==want
  assert sorted(val('diff','--cached','--name-only').splitlines())==(sorted(auth['owned_files'])if staged else[])
  for f,h in auth['owned_files'].items():assert sha(R/f)==h
  for f,h in auth['protected_human_payloads'].items():assert sha(APP/f)==h
  return s
 source(C,True);fresh=admission(OLD)
 hooks=subprocess.run(['git','-C',str(R),'config','--get','core.hooksPath'],env=meta,capture_output=True);assert hooks.returncode==1;hp=Path(val('rev-parse','--git-path','hooks'));hp=hp if hp.is_absolute()else R/hp;assert not any(p.is_file()and not p.name.endswith('.sample')for p in hp.iterdir())
 out=Path('/workspace/.cloud-setup/transport-current-20261103/actual-pr1700-e803-delivery-01');assert not out.exists(),'No automatic repeated mutation';out.mkdir();scratch=out/'native-tmp';scratch.mkdir();env['TMPDIR']=str(scratch);save(out/'ADMISSION-BEFORE.json',fresh)
 spec=importlib.util.spec_from_file_location('guard','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard);before=guard.snapshot();assert guard.check(before)['accepted'];rows=[];head=None;error=None;inflight=False;public=None;edited=None
 def run(name,cmd,cap=120,cwd=APP):
  nonlocal inflight
  rb=guard.snapshot();assert guard.check(rb)['accepted'];prefix=out/name;save(out/'STATE.json',dict(owner_pid=os.getpid(),active=name,HEAD=head));inflight=True
  with Path(str(prefix)+'.stdout').open('xb')as log:completed=subprocess.run([sys.executable,str(SUP),'--prefix',str(prefix),'--cwd',str(cwd),'--timeout',str(cap),'--',*cmd],env=env,stdout=log,stderr=subprocess.STDOUT)
  rr=load(str(prefix)+'.result.json');cl=load(str(prefix)+'.cleanup.json');res=guard.pair(rb,guard.snapshot());inflight=not(cl['cleanup_complete']and not cl['remaining_owned_children']);rows.append(dict(name=name,result=rr,cleanup=cl,resources=res,log_sha256=sha(str(prefix)+'.log')));save(out/'LEDGER.json',rows)
  assert completed.returncode==rr['returncode']==0 and not rr['timed_out']and rr['requested_timeout_seconds']==rr['effective_timeout_seconds']==cap and rr['timeout_override_reason']is None and not inflight and res['accepted'],name
 try:
  save(out/'COMMIT-INTENT.json',dict(parents=[C,OLD],TREE=TREE,message_sha256=auth['message_sha256'],mutation_budget=1));run('ordinary-resolved-merge-commit-ONCE',['git','-c','user.name=polecat-steward','-c','user.email=steward@polecat.live','commit','-F',str(HERE/'COMMIT-MESSAGE.txt')],cwd=R)
  head=val('rev-parse','HEAD');source(head,False);assert val('show','-s','--format=%P','HEAD').split()==[C,OLD]
  commands=[('entry',['node','tools/check-changelog-entry.mjs',BASE,'HEAD']),('identifiers',['node','tools/resolve_id_collisions.mjs','--base',BASE,'--check']),('changelog',['node','tools/check-changelog.mjs']),('pending-entry',['node','tools/changelog-entries.mjs','--check']),('history',['node','tools/changelog-history.mjs','--base',BASE])]
  for label,cmd in commands:run('actual-HEAD-'+label,cmd);source(head,False)
  run('actual-HEAD-whitespace',['git','show','--check','--format=oneline','HEAD'],cwd=R);run('actual-HEAD-base-whitespace',['git','diff','--check',BASE,'HEAD'],cwd=R);source(head,False)
  run('original-native-publish',['bash','tools/publish.sh'],180);source(head,False);run('original-published-check',['node','tools/check_published.mjs'],120);source(head,False);assert load(R/'site/4d/build.json')['version']==head[:10]
  save(out/'FRESH-PRE-PUSH-ADMISSION.json',admission(OLD));save(out/'PUSH-INTENT.json',dict(HEAD=head,branch=PUBLIC,normal_fast_forward_from=OLD,force=False,budget=1));run('ordinary-existing1700-feature-push-ONCE',['git','push','origin','HEAD:refs/heads/'+PUBLIC],cwd=R)
  public=admission(head);commit=api('git/commits/'+head);assert commit['tree']['sha']==TREE and[x['sha']for x in commit['parents']]==[C,OLD];save(out/'PUBLIC-COMMIT.json',commit);save(out/'PUBLIC-ADMISSION.json',public)
  times='/'.join(f"{x['result']['seconds']:.3f}"for x in gate['ledger']);body=f"Otis’s and Hans’s lower-detail clothing keeps the repaired garment coverage. Driver movement/interaction fixes, lossless repeated building scalar storage and the documented shadow-calibration view are retained from public `967b427e`. This ordinary reconciliation also preserves all house, source and evidence updates from reviewed DEV `{C}`.\n\nThe upstream interaction source `8057b7d6` remains included through 967; no separate DEV merge of that feature is asserted. The unsuccessful noncaster experiment is not part of this source.\n\nValidation:\n\n- All 1,165 distinct native checks and 402 self-tests passed on exact committed TREE `{TREE}` in four parts ({times} seconds), each under its original 600-second cap with source/resource/cleanup guards. Actual HEAD `{head}` passes all five QA checks, whitespace, original publication and published checks. Original LIBERTIES/source-use owner checks passed before freeze.\n- Public967’s earlier four-part/native-HEAD/publication proof remains tied to TREE ff904; it is not substituted for this fresh run. Four repaired clothing payloads and the exact memory implementation remain unchanged. Earlier all 24 desktop/phone human fixture evidence retains its own admitted garment source scope.\n- The separate measured memory candidate 05a2899 passed the unchanged 400 MiB mobile gate at 399.358 MiB with 0.642 MiB headroom; actual GPU storage fell 4,767,776 bytes, with byte-exact native/fresh-fallback pixel and pick controls. This is not a memory verdict on the later combined tree: current frame/memory CI must measure it.\n- The shadow counterfactual retakes the declared lake_market view and restores boot. Source 8057’s mobile diagnostic found worst 8/restoration 0; boot-pose worst 3 remains recorded. Current desktop/mobile Stage 9 and full smoke remain pending.\n\nThe global Light cost failure (4,100 calls versus 4,498 Full, above the unchanged 0.9 ratio) stays open. Broad transport/animation tickets remain claimed with no settlement; photographic quality, natural gait, continuous contact and boarding/riding acceptance are not claimed. Fresh exact-head CI is required before ordinary DEV delivery.\n"
  assert not re.search(r'\bT-?\d+\b',TITLE+'\n'+body);bodyfile=out/'PR-BODY.md';bodyfile.write_text(body);update=out/'PR-UPDATE.json';save(update,dict(title=TITLE,body=body));save(out/'PR-UPDATE-INTENT.json',dict(PR=PR,HEAD=head,body_sha256=sha(bodyfile),title=TITLE,budget=1));run('existing1700-title-body-update-ONCE',['gh','api','--method','PATCH','repos/'+REPO+'/pulls/1700','--input',str(update)],cwd=R)
  edited=admission(head);assert edited['PR']['title']==TITLE and edited['PR']['body']==body;save(out/'READY-PR-READBACK.json',edited['PR']);source(head,False)
 except BaseException as err:error=repr(err)
 source_error=None
 try:current=source(val('rev-parse','HEAD'),val('rev-parse','HEAD')==C)
 except BaseException as err:current=None;source_error=repr(err)
 resources=guard.pair(before,guard.snapshot())
 if not inflight and all(r['cleanup']['cleanup_complete']for r in rows):shutil.rmtree(scratch)
 # On an uncertain failure, inspect remote state once; never repeat commit/push/PATCH.
 remote_error=None
 try:remote_after=dict(feature=api('git/ref/heads/'+PUBLIC),lap=api('git/ref/heads/lap/pr-1700'))
 except BaseException as err:remote_after=None;remote_error=repr(err)
 passed=error is None and source_error is None and edited is not None and resources['accepted']and not scratch.exists()
 save(out/'CLOSED.json',dict(passed=passed,error=error,source_error=source_error,source=current,HEAD=head,PR=PR,ledger=rows,resources=resources,owned_TMPDIR_removed=not scratch.exists(),gate=dict(path=str(GATE),sha256=auth['gate_sha256']),all_four_on_final_committed_TREE=True,own_lap_preserved=LAP,remote_after=remote_after,remote_error=remote_error,ticket_state_changes=False,CI_dispatches=False,DEV_merge=False,production_changed=False));print(json.dumps(dict(passed=passed,error=error,HEAD=head,TREE=TREE,PR=PR)),flush=True);return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
