#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Prepared one-phase controller. No geometry work before explicit Root GO."""
from pathlib import Path
import argparse,hashlib,json,os,struct,subprocess
P=Path(__file__).resolve().parent
CORE=Path('/workspace/chicago-current26-riding-gear-source-20261104')
PY='/workspace/.cloud-setup/venv311/bin/python'
NODE='/workspace/.cloud-setup/node-v22.22.0-linux-x64/bin/node'
SUP='/workspace/.cloud-setup/transport-supervise.py'
H=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')
def verify():
    manifest=load(P/'PREPARATION-MANIFEST.json')
    for r in manifest['files']:
        b=(P/r['file']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'],r['file']
    cfg=load(P/'CONFIG.json')
    assert H((CORE/'SOURCE-MANIFEST.json').read_bytes())==cfg['source_manifest_sha256']
    for r in load(CORE/'SOURCE-MANIFEST.json')['files']:
        b=(CORE/r['file']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'],r['file']
    for r in cfg['native_dependency_pins']+cfg['kernel_and_tool_pins']+load(CORE/'INPUTS.json')['files']:
        b=Path(r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'],r['path']
    return cfg
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['admit'],required=True);p.add_argument('--go',type=Path,required=True);p.add_argument('--candidate-root',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
cfg=verify();binding=load(cfg['actual_candidate_binding']['path']);assert H(Path(cfg['actual_candidate_binding']['path']).read_bytes())==cfg['actual_candidate_binding']['sha256'];go=load(a.go);assert go['approved']is True and go['canonical_lane_released']is True and go['phase']==a.phase
assert go['admission_manifest_sha256']==H((P/'PREPARATION-MANIFEST.json').read_bytes())
assert go['source_manifest_sha256']==cfg['source_manifest_sha256']
assert go['horse_containment_status']=='UNQUALIFIED_CURRENT_BODY_SOLID_NOT_PROVED'
assert go['horse_no_penetration_accepted']is False and go['full_fit_accepted']is False
candidate_root=a.candidate_root.resolve();assert candidate_root.parent==CORE.resolve()
assert str(candidate_root/'current26-saddle-girth-core-SOURCE.glb')==binding['candidate']['path']
out=a.out.resolve();assert out.parent==P.resolve()and not out.exists();out.mkdir()
initial_affinity=sorted(os.sched_getaffinity(0));assert initial_affinity;cpu=initial_affinity[0];os.sched_setaffinity(0,{cpu});assert os.sched_getaffinity(0)=={cpu}
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
steps=[]
def step(label,cap,cmd):
    prefix=str(out/label)
    with (out/(label+'.supervisor.stdout')).open('wb')as f:
        rc=subprocess.run([PY,SUP,'--prefix',prefix,'--cwd',str(P),'--timeout',str(cap),'--',*cmd],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=cap+30,check=False).returncode
    r,c=load(prefix+'.result.json'),load(prefix+'.cleanup.json')
    steps.append({'label':label,'prefix':prefix,'command':cmd,'cap_s':cap,'outer_returncode':rc,'result_sha256':H(Path(prefix+'.result.json').read_bytes()),'cleanup_sha256':H(Path(prefix+'.cleanup.json').read_bytes())});write(out/'STEPS.json',steps)
    assert rc==0 and r['returncode']==0 and not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==cap and r['timeout_override_reason']is None,label
    assert c['cleanup_complete']and not c['remaining_owned_children'],label
    verify()
try:
    candidate=candidate_root/'current26-saddle-girth-core-SOURCE.glb';raw=candidate.read_bytes();digest=H(raw);assert digest==go['candidate_sha256']==binding['candidate']['sha256'],'Root binds the ACTUAL newly generated candidate hash'
    source=load(candidate_root/'SOURCE-CANDIDATE.json');assert source['generated']['sha256']==digest and source['source_and_input_after_exact']is True
    step('containment-scope-control',30,[PY,cfg['containment_scope_control']['path'],'--out',str(Path(cfg['containment_scope_control']['path']).parent/out.name)])
    containment=load(Path(cfg['containment_scope_control']['path']).parent/out.name/'CONTROL.json');assert containment['status']=='SYNTHETIC_SCOPE_CONTROL_PASS_ONLY'and containment['passed']is True and containment['current_horse_volume_topology_or_containment_proved']is False and containment['checker_sha256']==H((P/'check_current_rest.py').read_bytes())
    step('khronos',60,[NODE,cfg['validator_script'],str(candidate),str(out/'khronos.json')])
    validation=load(out/'khronos.json');assert validation['validatorVersion']=='2.0.0-dev.3.10'and validation['issues']['numErrors']==0
    step('original-predicate-controls',30,[PY,'-c',"import sys;sys.path.insert(0,'/workspace/chicago-riding-tack-footplate-proposal-20261104/source');from official_fit_predicates import predicate_controls;predicate_controls();print('Original predicate controls PASS')"])
    step('native-rest-capture',60,[NODE,str(P/'capture_current_rest.mjs'),'--candidate',str(candidate),'--candidate-sha',digest,'--horse',cfg['horse_path'],'--config',str(P/'CONFIG.json'),'--out',str(out/'capture')])
    capture=out/'capture/capture.json';assert load(capture)['passed']is True
    base=[PY,str(P/'check_current_rest.py'),'--capture',str(capture),'--params',str(CORE/'PARAMETERS.json'),'--candidate-sha',digest]
    step('actual-self',900,[*base,'--phase','self','--out',str(out/'self')])
    self_receipt=out/'self/self.json';assert load(self_receipt)['passed']is True
    step('actual-28-pairs-all-horse',900,[*base,'--phase','assembly','--self-receipt',str(self_receipt),'--self-sha',H(self_receipt.read_bytes()),'--out',str(out/'assembly')])
    assembly=load(out/'assembly/assembly.json');assert assembly['passed']is True and assembly['source_after_exact']is True
    assert H(candidate.read_bytes())==digest
    result={'status':'CURRENT26_ACTUAL_NATIVE_REST_SURFACE_SELF_28_ALL17390_PASS_ONLY','phase':'admit','candidate_path':str(candidate),'candidate_sha256':digest,'source_manifest_sha256':cfg['source_manifest_sha256'],'capture_sha256':H(capture.read_bytes()),'self_receipt_sha256':H(self_receipt.read_bytes()),'assembly_receipt_sha256':H((out/'assembly/assembly.json').read_bytes()),'actual_pose':{'mode':'serialized_rest','clip':None,'time_s':None,'mixer_created':False},'motion_load_rider_or_photo_accepted':False}
    result.update(horse_containment_status='UNQUALIFIED_CURRENT_BODY_SOLID_NOT_PROVED',horse_volume_topology_audit='NOT_RUN',horse_no_penetration_accepted=False,full_fit_accepted=False,containment_scope_control_receipt={'path':str(Path(cfg['containment_scope_control']['path']).parent/out.name/'CONTROL.json'),'sha256':H((Path(cfg['containment_scope_control']['path']).parent/out.name/'CONTROL.json').read_bytes())},actual_candidate_binding_sha256=cfg['actual_candidate_binding']['sha256'])
    verify();result.update(passed=True,all_steps=steps,actual_one_cpu_affinity={'initial':initial_affinity,'selected':cpu},source_after_exact=True);write(out/'RESULT.json',result);print(result['status'])
except BaseException as error:
    write(out/'FIRST-FAILURE.json',{'status':'NONPASS_NO_AUTOMATIC_RETRY','phase':a.phase,'error':repr(error),'completed_or_attempted_steps':steps,'motion_load_rider_or_photo_accepted':False});raise
