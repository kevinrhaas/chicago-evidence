# Actual current26 candidate: SURFACE admission V2 — prepared, UNRUN

Root already generated one unqualified candidate c5a1771e324b96736ad52a17c916a242a7fdd347d0a827b4898695ec96b6db73,
58,184B /8 parts /856 triangles /one26-joint skin /no animation. Its real build
closure passed0.816s, cleanup/resources/source exact. ACTUAL-CANDIDATE-BINDING.json
pins that full candidate, source manifest630f0acd, actual120s-child result/cleanup,
source receipt and closed-build receipt1b538d66. No candidate is regenerated here.

The constructor, source manifest and raw checker f84af39c remain UNCHANGED. Native
capture162ce791 is byte-exact V1 too. This is a new surrounding scope/control version;
old admission dc1b1aca remains immutable and unexecuted.

## Honest scope

SELF proves the actual eight closed gear shells by the original predicates. All28
interpart pairs include their original nonintersection/contact/nesting obligations.
All8 versus all3 current horse surface cohorts covers17,390 triangles. These are
SURFACE checks for the horse: a wholly contained part with no boundary crossing
could escape. Current BODY has NOT been proved a watertight/embedded solid here.

Every new result/closure explicitly records:

    horse_containment_status = UNQUALIFIED_CURRENT_BODY_SOLID_NOT_PROVED
    horse_volume_topology_audit = NOT_RUN
    horse_no_penetration_accepted = false
    full_fit_accepted = false
    motion_load_rider_or_photo_accepted = false

Do not interpret raw checker passed=true as horse-volume/no-penetration/full-fit.
Raw checker receipts keep their original bytes and are hash-linked to this narrower
wrapper interpretation. There is no proxy, near-weld, hole fill or changed tolerance.
Source construction remains valid as explicitly UNQUALIFIED construction, separately.

Before current-model checks, the prepared30s containment_scope_control executes the
ACTUAL frozen scan AST on known closed tetrahedra. A complete inner closed part
strictly inside an outer closed tetra must have0surface hits but trigger the existing
closed-target nesting rejection. Outside/proper-crossing/open-target cases retain
their distinct outcomes. This genuine synthetic control demonstrates the gap and
must itself pass; it DOES NOT prove current horse closure or containment.

## Later exact one attempt (Root canonical handoff only)

No actual ADMIT GO, native capture, control, SELF, collision, volume or new render
has run. World/claim-renewal/G4gate own the lane; do not request or take it early.

After Root hands off the lane, copy ROOT-GO-ADMIT-SURFACE-UNBOUND-TEMPLATE.json to a
NEW actual GO. Root sets approved/lane true and admission_manifest_sha256 to the
reviewed frozen PREPARATION-MANIFEST.json SHA. Candidate SHA is already c5a1771e...
and source630f0acd; scope flags explicitly remain unqualified. Run once:

    bash /workspace/chicago-current26-riding-gear-surface-admission-v2-20261104/run_owned_phase_once.sh admit \
      /ABSOLUTE/ROOT-ACTUAL-SURFACE-ADMIT-GO.json \
      /workspace/chicago-current26-riding-gear-surface-admission-v2-20261104/actual-surface-admission-01 \
      /workspace/chicago-current26-riding-gear-source-20261104/actual-core-01

One inherited CPU, maththreads1, canonical flock, unchanged3f49 epoch/floors and
before/after source/input/manifest/candidate guards. Same1800s overall cap; children:
containment control30s, Khronos60s, original predicate controls30s, native capture60s,
SELF900s, interpart/horse900s. The sum of subcaps is not permission to exceed1800;
a real timeout remains NONPASS. No automatic retry or generic ignore flags.

Actual native capture uses real pinned GLTFLoader/Skeleton CPU readback, validates
gear rest/parentage/inverse binds BEFORE rebind, then binds to the actual horse
skeleton. It captures every indexed native world vertex/triangle of8+3 meshes.
No Mixer/action/pose evaluation, images, GPU/browser or fake scene APIs are used.
Pose is serialized REST, never relabelled idle0. Raw streams, all kernel hashes,
actual commands, child results/cleanups, resource pair and first failure persist.

Expected positive outer status (only if all real steps pass):
CURRENT26_NATIVE_REST_SURFACE_ADMISSION_CLOSED_PASS_ONLY.
This still DOES NOT establish horse containment, motion, loaded fit, rider contact,
material strength or photo acceptance. A future29-part cohort requires all406pairs
and all29 against all17,390 faces; old20/9 or15-rig/14,172-face positives never transfer.
Any first failure is retained and reviewed before a separate corrected attempt.
