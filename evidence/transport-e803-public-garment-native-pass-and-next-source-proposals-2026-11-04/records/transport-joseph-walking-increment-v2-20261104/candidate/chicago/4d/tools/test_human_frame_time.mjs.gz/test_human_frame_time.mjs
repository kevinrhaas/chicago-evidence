// SPDX-License-Identifier: GPL-3.0-or-later
// Execute the native shared clock/latches, actor update and route; no browser or copied clock implementation.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const THREE = await import(new URL('../renderers/web/vendor/three-0.185.1/three.module.js', import.meta.url));

const main = await readFile(new URL('../renderers/web/js/main.js', import.meta.url), 'utf8');
const engine = await readFile(new URL('../renderers/web/js/humans.js', import.meta.url), 'utf8');
const standing = await readFile(new URL('../renderers/web/js/standing-horses.js', import.meta.url), 'utf8');
function required(match, label) { assert(match, `Actual native ${label} must resolve`); return match; }
const clockSource = required(main.match(/function tick\([^\n]*\) \{([\s\S]*?)\n    if \(!gateOpen\)/), 'tick clock')[1];
const call = required(main.match(/api\.humans\?\.update\([^;]+;/g)?.filter(s => s.includes('walker.state')), 'human update calls');
assert.equal(call.length, 1, 'One native human update per tick');
const horseCall = required(main.match(/standingHorses\.update\(camera, [^;]+;/), 'standing update')[0];
const latches = required(main.match(/  let visualClockReset = true;([\s\S]*?)\n  crashGuard\.watchContext/), 'visible clock event latches')[0].replace(/\n  crashGuard\.watchContext$/, '');
const hold = required(main.match(/    setAnimationHold\(on\) \{([\s\S]*?)\n    \},/), 'animation hold')[1];
const pause = required(main.match(/gateOpen = true;\s*visualClockReset = true;/), 'pause clock reset')[0];
const enter = required(main.match(/gateOpen = false;\s*visualClockReset = true;/), 'entry clock reset')[0];
function bus(extra = {}) {
  const handlers = new Map();
  return {...extra, addEventListener(name, fn) { const rows = handlers.get(name) ?? []; rows.push(fn); handlers.set(name, rows); },
    fire(name) { for (const fn of handlers.get(name) ?? []) fn(); }};
}
function clockHarness(absent = false) {
  const document = bus({hidden:false}), window = bus(), dom = bus(), loops = [], calls = [], horses = [];
  const camera = {}, state = {}, clock = {delta:0, reads:0, getDelta() { this.reads++; return this.delta; }};
  const api = absent ? {} : {humans:{update(dt, c, s, visualDt) { assert.strictEqual(c, camera); assert.strictEqual(s, state); calls.push({dt, visualDt}); }}};
  const standingHorses = {update(c, dt, options) { assert.strictEqual(c,camera); horses.push({dt,...options}); }};
  const factory = new Function('document','window','renderer','clock','api','camera','walker','standingHorses', `
    let animationHold = false, gateOpen = false, contextPaused = false;
    const frameLoop = () => {}, contextNeedsReload = () => false;
    ${latches}
    return {
      tick() { ${clockSource}\n${call[0]}\n${horseCall}\nreturn {frameDt, dt, visualDt}; },
      hold(on) { ${hold} }, pause() { ${pause} }, enter() { ${enter} },
      state() { return {visualClockReset,contextPaused}; }
    };`);
  const native = factory(document,window,{domElement:dom,setAnimationLoop(fn) { loops.push(fn); }},clock,api,camera,{state},standingHorses);
  return {document,window,dom,calls,horses,loops,...native,tick(delta) { clock.delta = delta; const before = clock.reads; const row = native.tick(); assert.equal(clock.reads-before,1,'Consume the native clock once per tick'); return row; }};
}
function total(deltas, held = false, gated = false) {
  const h = clockHarness(); if (held) h.hold(true); if (gated) h.pause();
  let elapsed = 0; for (const delta of deltas) elapsed += h.tick(delta).frameDt;
  return elapsed;
}
// Original bounded locomotion/hold assertions remain; reset-aware visual time is a separate fourth argument.
assert(Math.abs(total(Array(4).fill(.25))-1)<1e-12, 'Four slow frames must advance one second');
assert(Math.abs(total(Array(60).fill(1/60))-1)<1e-12, 'Fast/slow native locomotion time must match');
assert.equal(total([1]),.25,'Long pauses retain the quarter-second locomotion clamp');
assert.equal(total([.2,.2],true),0,'Capture hold stops human locomotion');
assert.equal(total([.2,.2],false,true),0,'Arrival gate stops human locomotion');
clockHarness(true).tick(.2); // An absent human layer is a normal year/scene case.
const h = clockHarness();
assert.equal(h.tick(25).visualDt,0,'First real frame cannot consume unseen visual time');
assert.deepEqual(h.tick(1.75),{frameDt:.25,dt:.05,visualDt:1.75},'Slow visible idle keeps wall time; locomotion/effects remain bounded');
assert.deepEqual(h.calls.at(-1),{dt:.25,visualDt:1.75},'Only the human fourth argument receives raw cosmetic time');
assert.deepEqual(h.horses.at(-1),{dt:1.75,paused:false,visualFrame:true},'Standing horse gets the same separate cosmetic time');
h.hold(true); assert.deepEqual(h.tick(.2),{frameDt:0,dt:0,visualDt:0});
h.hold(false); assert.equal(h.tick(20).visualDt,0,'Resuming a hold rejects its invisible interval');
assert.equal(h.tick(.2).visualDt,.2);
h.hold(true); h.hold(false); assert.equal(h.tick(20).visualDt,0,'Hold/resume also resets when no held tick occurred');
h.pause(); assert.equal(h.tick(.2).frameDt,0); h.enter(); assert.equal(h.tick(20).visualDt,0,'World entry resets the visual interval');
h.tick(.2); h.document.hidden = true; h.document.fire('visibilitychange'); assert.equal(h.tick(20).visualDt,0);
h.document.hidden = false; h.document.fire('visibilitychange'); assert.equal(h.tick(20).visualDt,0,'Shown page rejects hidden elapsed time');
h.tick(.2); h.document.hidden=true; h.document.fire('visibilitychange'); h.document.hidden=false; h.document.fire('visibilitychange');
assert.equal(h.tick(20).visualDt,0,'Hidden/shown without any hidden tick still rebases visual time');
for (const event of ['pageshow','pagehide']) { h.tick(.2); h.window.fire(event); assert.equal(h.tick(20).visualDt,0,`${event} rebases the first visual frame`); }
h.tick(.2); h.dom.fire('webglcontextlost'); assert.equal(h.state().visualClockReset,true); assert.equal(h.state().contextPaused,true); assert.equal(h.loops.at(-1),null);
h.tick(0); h.dom.fire('webglcontextrestored'); assert.equal(h.state().visualClockReset,true); assert.equal(h.state().contextPaused,false); assert.equal(typeof h.loops.at(-1),'function');
assert.equal(h.tick(20).visualDt,0,'Context restoration rejects the old document gap');
for (const invalid of [NaN,Infinity,-1]) assert.equal(h.tick(invalid).visualDt,0,'Invalid raw intervals never reach cosmetic helpers');

// Actual HumanActor update: substitute only its external scene/body collaborators.
const constants = required(engine.match(/export const HUMAN_TIERS[\s\S]*?export const RECHECK_S = [^;]+;/), 'human distance constants')[0].replace(/^export /gm,'');
const choose = required(engine.match(/export function chooseHumanLod\([\s\S]*?\n\}/), 'native human LOD selector')[0].replace(/^export /,'');
const update = required(engine.match(/\n  update\(dt, cameraPosition, visualDt = dt\) \{([\s\S]*?)\n  \}\n\n  dispose/), 'human update')[1];
const dispose = required(engine.match(/\n  dispose\(\) \{([\s\S]*?)\n  \}\n\}/), 'human disposal')[1];
const actorUpdate = new Function('dt','cameraPosition','visualDt = dt',`${constants}\n${choose}\n${update}`);
const actorDispose = new Function(dispose);
function body() { const values = []; return {values,faces:[{}],mixer:{update(dt) { values.push(dt); }}}; }
function actor() {
  const a = {disposed:false,recheck:0,inRange:true,tier:'full',lod:0,wanted:0,instance:{lod:{}},root:{position:{},visible:true,removeFromParent(){}},
    counters:{updates:0,animated:0,faced:0},body:body(),visualIdleBody:null,state:'standing',clipName:'idle_natural_v1',
    blinkClock:0,expression:{},walks:[],walk(dt) { this.walks.push(dt); },setLod(lod) { this.wanted=lod; return Promise.resolve(); },applyFace(){},applyCosts(){},teardown(){}};
  a.distanceForTest = 2;
  a.step = (dt, visualDt) => actorUpdate.call(a,dt,{distanceTo() { return a.distanceForTest; }},visualDt);
  return a;
}
const a = actor(); a.step(.05,50); assert.equal(a.body.values.at(-1),0,'New body starts without unseen animation');
a.step(.05,1.8); assert.equal(a.body.values.at(-1),1.8); assert.equal(a.walks.at(-1),.05); assert(Math.abs(a.blinkClock-.1)<1e-12,'Face and non-route actor policy keep bounded dt');
for (const mode of [{state:'walking'},{state:'talking'},{state:'working'},{state:'standing',clipName:'idle'},{state:'standing',clipName:'idle_natural_v1',oneShot:true}]) {
  a.state=mode.state; a.clipName=mode.clipName??'idle_natural_v1'; a.body.oneShot=mode.oneShot; a.step(.05,50);
  assert.equal(a.body.values.at(-1),.05,'Walking-in-place/talking/work/old idle/one-shot preserve original bounded dt');
}
a.state='standing'; a.clipName='idle_natural_v1'; a.body.oneShot=false; a.step(.05,50); assert.equal(a.body.values.at(-1),0,'Standing transition does not catch up');
a.step(.05,.2); assert.equal(a.body.values.at(-1),.2);
a.body=body(); a.step(.05,50); assert.equal(a.body.values.at(-1),0,'LOD replacement starts its own idle clock');
a.step(.05,.2); for (const invalid of [NaN,Infinity,-1]) { a.step(.05,invalid); assert.equal(a.body.values.at(-1),0); }
a.distanceForTest=100; const beforeFar=a.body.values.length; a.step(.05,50); assert.equal(a.body.values.length,beforeFar,'Far actor holds its mixer');
a.distanceForTest=2; a.step(.05,50); assert.equal(a.body.values.at(-1),0,'Animation-range re-entry rejects unseen time');
a.step(.05,.2); a.distanceForTest=200; a.step(.05,50); assert.equal(a.inRange,false); assert.equal(a.visualIdleBody,null);
a.distanceForTest=2; a.step(.25,50); a.step(.25,50); assert.equal(a.body.values.at(-1),0,'Draw-range re-entry starts without catchup');
a.step(0,0); assert.equal(a.body.values.at(-1),0,'A held visual tick advances no idle');
actorDispose.call(a); const disposedCount=a.body; assert.equal(a.step(.05,50),false); assert.equal(a.body,disposedCount);
const layerUpdate = required(engine.match(/\n    update\(dt, camera, visitor = null, visualDt = dt\) \{([\s\S]*?)\n    \},\n\n    \/\*\* The selectable/), 'human layer update')[1];
const forwarded=[]; const layer = new Function('actors','near','emit','THREE',`return function(dt,camera,visitor=null,visualDt=dt){${layerUpdate}}`)(new Map([['one',{inRange:true,instance:{},update(...args){forwarded.push(args);}}]]),new Set(),()=>{},{});
const eye={}; layer(.05,{position:eye},{e:1,n:2},3); assert.deepEqual(forwarded.at(-1),[.05,eye,3]);
layer(.05,{position:eye}); assert.deepEqual(forwarded.at(-1),[.05,eye,.05],'Optional visual argument retains existing callers');

// Actual shared horse-layer activation: reduced motion, ancestor/range visibility and tier changes cannot bank unseen time.
const horseUpdate = required(standing.match(/    update\(camera, dt = 0, ([\s\S]*?)\n    \},\n    async setTier/), 'horse update');
const horseSignature = horseUpdate[1].slice(0,horseUpdate[1].indexOf(' {\n')).replace(/\)$/, '');
const horseBody = horseUpdate[1].slice(horseUpdate[1].indexOf(' {\n')+3);
const horseTier = required(standing.match(/    async setTier\(next\) \{([\s\S]*?)\n    \},\n    pickAt/), 'horse tier change')[1];
const horseReset = required(standing.match(/  const resetIdleClock = [\s\S]*?\n  motionPreference\?\.addEventListener\?\.\('change', resetIdleClock\);/), 'horse preference reset')[0];
const reach = required(standing.match(/const REACH = [^;]+;/), 'horse reach')[0];
const horseFactory = new Function('assert','globalThis',`return function(){
  ${reach}
  let tier='full', disposed=false, revision=0, active=null,lastCamera=null;
  const group={visible:true,parent:null}, confidence=null, motionPreference={matches:false,listeners:[],addEventListener(event,fn){this.listeners.push(fn);}};
  const eye={distanceTo(){return distance;}}, values=[];let distance=2;
  const make=()=>({group:{visible:true,position:{}},root:{traverse(fn){fn({isMesh:true});}},idleWasActive:false,idle:{status:{disposed:false},update(dt,options){values.push({dt,...options});}}});
  const withinReach=()=>false,load=async()=>{active??=make();},retire=()=>{if(active)active.idleWasActive=false;active=null;},abort=null;
  ${horseReset}
  active=make();const camera={getWorldPosition(v){return v;}};
  const out={update(camera,dt=0,${horseSignature}){${horseBody}},async setTier(next){${horseTier}}};
  return {values,group,frame(dt,options){out.update(camera,dt,options);},tier:out.setTier.bind(out),distance(v){distance=v;},reduced(v){motionPreference.matches=v;for(const fn of motionPreference.listeners)fn();}};
}`)(assert,{document:{hidden:false}});
const horse = horseFactory(); horse.frame(100,{visualFrame:false}); horse.frame(100,{visualFrame:true}); assert.equal(horse.values.at(-1).dt,0,'Visibility-only refresh must not prime first real horse frame');
horse.frame(.2,{visualFrame:true}); assert.equal(horse.values.at(-1).dt,.2);
horse.frame(100,{paused:true,visualFrame:true}); assert.equal(horse.values.at(-1).dt,0);
horse.frame(100,{paused:false,visualFrame:true}); assert.equal(horse.values.at(-1).dt,0,'Horse pause resumes without catchup');
horse.frame(.2,{visualFrame:true});
horse.reduced(true); horse.reduced(false); horse.frame(100,{visualFrame:true}); assert.equal(horse.values.at(-1).dt,0,'Preference change without a rendered tick rebases horse');
horse.frame(.2,{visualFrame:true}); horse.reduced(true); horse.frame(100,{visualFrame:true}); assert.equal(horse.values.at(-1).dt,0); assert.equal(horse.values.at(-1).reducedMotion,true);
horse.reduced(false); horse.frame(100,{visualFrame:true}); assert.equal(horse.values.at(-1).dt,0);
horse.frame(.2,{visualFrame:true}); horse.group.visible=false; horse.frame(100,{visualFrame:true}); assert.equal(horse.values.at(-1).dt,0);
horse.group.visible=true; horse.frame(100,{visualFrame:true}); assert.equal(horse.values.at(-1).dt,0,'Ancestor visibility resumes without catchup');
horse.frame(.2,{visualFrame:true}); horse.distance(100); horse.frame(100,{visualFrame:true}); assert.equal(horse.values.at(-1).dt,0);
horse.distance(2); horse.frame(100,{visualFrame:true}); assert.equal(horse.values.at(-1).dt,0,'Horse range re-entry rebases idle');
horse.frame(.2,{visualFrame:true}); await horse.tier('balanced'); horse.frame(100,{visualFrame:true}); assert.equal(horse.values.at(-1).dt,0,'Tier refresh does not prime a new real idle interval');
horse.frame(.2,{visualFrame:true}); await horse.tier('light'); const last=horse.values.length; horse.frame(100,{visualFrame:true}); assert.equal(horse.values.length,last,'Phone-light tier has no standing development horse');
await horse.tier('balanced'); horse.frame(100,{visualFrame:true}); assert.equal(horse.values.at(-1).dt,0,'Reloaded owner has a separate activation clock');

assert.throws(()=>horse.frame(NaN,{visualFrame:true}),/finite and nonnegative/);
assert.throws(()=>horse.frame(-1,{visualFrame:true}),/finite and nonnegative/);

const route = required(engine.match(/\n  walk\(dt\) \{([\s\S]*?)\n  \}\n\n  \/\*\*/), 'human route')[1];
const runningSource = required(engine.match(/function routeGaitRunning\(body\) \{[\s\S]*?\n\}/), 'route gait policy')[0];
const routeGaitRunning = new Function('THREE','verbOf',`${runningSource}\nreturn routeGaitRunning;`)(THREE,n=>String(n).split('_')[0]);
const walk = new Function('dt','routeGaitRunning',route);
const walkClip = new THREE.AnimationClip('walk',1,[]);walkClip.userData={speed_m_s:1};
const walkMixer = new THREE.AnimationMixer(new THREE.Group()),walkAction=walkMixer.clipAction(walkClip).play();walkMixer.update(0);
const walker = {state:'walking',route:[{local_e:0,local_n:0},{local_e:.2,local_n:0},{local_e:.2,local_n:.2}],
  body:{mixer:walkMixer,action:walkAction},leg:0,legT:0,e:0,n:0,placements:0,place(){this.placements++;}};
walk.call(walker,.25,routeGaitRunning); assert.equal(walker.leg,1,'Slow frame consumes a route corner without losing elapsed time');
assert(Math.abs(walker.e-.2)<1e-12&&Math.abs(walker.n-.05)<1e-12);
walker.state='standing';const before={e:walker.e,n:walker.n,leg:walker.leg,placements:walker.placements};walk.call(walker,.25,routeGaitRunning);
assert.deepEqual({e:walker.e,n:walker.n,leg:walker.leg,placements:walker.placements},before,'Standing actors remain planted');
console.log('PASS: native clock/latches preserve bounded locomotion and routes; cosmetic idle resets across visibility, holds, context, body/range/tier and reduced motion');

// Route walkers use the actual class with real Three roots, clips and AnimationMixer.
// Assets are controlled asynchronous collaborators; this is not a body/contact test.
const classSource = engine.replace(/^import .*;$/gm, '').replace(/^export /gm, '');
const {HumanActor,routeGaitRunning:actualRouteGaitRunning} = new Function('THREE','cloneSkinned','enuToWorld',`${classSource}\nreturn {HumanActor,routeGaitRunning:typeof routeGaitRunning==='function'?routeGaitRunning:null};`)(
  THREE, scene=>scene.clone(true), (e,n,y,out)=>out.set(e,y,-n));
const motionHandlers=new Set(), preference={matches:false,
  addEventListener(name,fn){assert.equal(name,'change');motionHandlers.add(fn);},
  removeEventListener(name,fn){assert.equal(name,'change');motionHandlers.delete(fn);}};
const oldMatchMedia=globalThis.matchMedia;
globalThis.matchMedia=()=>preference;
const close=(got,want,label)=>assert(Math.abs(got-want)<1e-9,`${label}: ${got} vs ${want}`);
const routeRecord={id:'hi_rc_dufresne_joseph_1835',person_id:'rc_dufresne_joseph',
  appearance:{asset_id:'dufresne_joseph_1835'},placement:{local_e:0,local_n:0,heading_deg:90},
  behaviour:{state:'walking',route:[{local_e:20,local_n:0},{local_e:20,local_n:20},{local_e:0,local_n:20}]},
  animation:{clip:'walk',loop:true,phase:0},interaction:{selectable:true,opens:'resident_card'},lod:{policy:'fixed',fixed:0}};
function gait(name='walk',speed=.6){
  const clip=new THREE.AnimationClip(name,1.2,[new THREE.VectorKeyframeTrack('walker_bone.position',[0,.6,1.2],[0,0,0,.1,0,0,0,0,0])]);
  clip.userData={speed_m_s:speed};return clip;
}
function fixtureAsset(){const scene=new THREE.Group(),bone=new THREE.Bone();bone.name='walker_bone';scene.add(bone);const gesture=new THREE.AnimationClip('gesture_wave',.5,[new THREE.VectorKeyframeTrack('walker_bone.position',[0,.25,.5],[0,0,0,0,.1,0,0,0,0])]);const idle=new THREE.AnimationClip('idle',2,[new THREE.VectorKeyframeTrack('walker_bone.position',[0,2],[0,0,0,0,0,0])]);return {scene,animations:[gait(),gait('walk_slow',.3),gesture,idle]};}
function actorFixture(){
  let resolve;const ready=new Promise(r=>{resolve=r;}),released=[];
  const assets={acquire:()=>ready,release:(...args)=>released.push(args)};
  const samples=[];
  const actor=new HumanActor({instance:structuredClone(routeRecord),assets,heightAt:(e,n)=>{samples.push({e,n});return .01*e+.02*n;}});
  const eye=new THREE.Vector3(0,1,2);
  return {actor,eye,released,samples,resolve:()=>resolve(fixtureAsset()),step:(visual=.5,dt=.25)=>actor.update(dt,eye,visual)};
}
async function readyWalker(){const f=actorFixture();f.step(50);f.resolve();await f.actor.pending;f.step(50);return f;}
try {
  const cold=actorFixture();for(let i=0;i<4;i++)cold.step(25);
  close(cold.actor.e,0,'cold actor never travels at invented fallback speed');assert.equal(cold.actor.body,null);
  cold.resolve();await cold.actor.pending;cold.step(50);
  close(cold.actor.e,0,'first actual visible body rejects cold elapsed time');close(cold.actor.body.mixer.time,0,'cold mixer also starts at zero');
  cold.step(.5);close(cold.actor.e,.3,'ready walker uses exported .6m/s metadata');close(cold.actor.body.mixer.time,.5,'feet and root consume same half second');
  close(cold.actor.root.position.y,.003,'actual place samples rendered-ground collaborator at moved location');
  assert.equal(cold.samples.length,2,'ready frame samples final ground once; no physical sweep is claimed');
  for(const [fps,count] of [[1,2],[2,4],[60,120]]){
    const f=await readyWalker();for(let i=0;i<count;i++)f.step(1/fps,Math.min(1/fps,.25));
    close(f.actor.e,1.2,`${fps}FPS retains two actual visible seconds of route distance`);
    close(f.actor.body.mixer.time,2,`${fps}FPS feet use same two visible seconds`);f.actor.dispose();
  }
  const huge=await readyWalker();let reads=0;const actualRoute=huge.actor.route;
  huge.actor.route=new Proxy(actualRoute,{get(target,key,receiver){if(/^\d+$/.test(String(key))&&++reads>100)throw Error('route arithmetic exceeded waypoint bound');return Reflect.get(target,key,receiver);}});
  const sampleCount=huge.samples.length;huge.actor.walk(1e12);
  close(huge.actor.e,0,'huge exact complete circuits finish at the declared endpoint');close(huge.actor.n,0,'huge complete circuits preserve northing');
  close(huge.actor.heading,180,'a complete circuit finishes on its incoming southbound edge');
  assert(reads<=100,'route work is bounded by waypoints, not elapsed 50ms ticks');assert.equal(huge.samples.length,sampleCount+1,'huge interval samples only its final ground');
  huge.actor.route=actualRoute;huge.actor.walk(.5);close(huge.actor.e,.3,'no old interval debt survives the huge frame');huge.actor.dispose();
  const controls=await readyWalker();controls.step(.5);
  async function restoreRoute(){controls.actor.play('walk',{fade:0,loop:true});controls.step(50);const before=controls.actor.e;controls.step(.5);close(controls.actor.e,before+.3,'restored supported gait travels only the fresh interval');}
  for(const [name,change] of [
    ['paused',f=>{f.actor.body.action.paused=true;}],
    ['stopped',f=>f.actor.body.action.stop()],
    ['disabled',f=>{f.actor.body.action.enabled=false;}],
    ['zero action scale',f=>f.actor.body.action.setEffectiveTimeScale(0)],
    ['half action scale',f=>f.actor.body.action.setEffectiveTimeScale(.5)],
    ['half mixer scale',f=>{f.actor.body.mixer.timeScale=.5;}],
    ['zero effective weight',f=>f.actor.body.action.setEffectiveWeight(0)],
    ['pending warp',f=>f.actor.body.action.warp(1,.5,.5)],
    ['pending fade',f=>f.actor.body.action.fadeOut(.5)]
  ]){
    change(controls);const before=controls.actor.e;controls.step(.5);close(controls.actor.e,before,name+' cannot propel a route');
    controls.actor.body.mixer.timeScale=1;controls.actor.body.action.stopFading().stopWarping().setEffectiveWeight(1).setEffectiveTimeScale(1);
    await restoreRoute();
  }
  controls.actor.play('walk',{fade:0,loop:false});const beforeOnce=controls.actor.e;
  for(let i=0;i<6;i++)controls.step(.5);
  assert.equal(controls.actor.body.action.paused,true,'actual LoopOnce action finishes and clamps');
  close(controls.actor.body.action.time,1.2,'actual finite gait ends at its clip endpoint');close(controls.actor.e,beforeOnce,'unsupported finite walk plays in place throughout');
  controls.step(50);close(controls.actor.e,beforeOnce,'finished/clamped gait cannot slide the root');await restoreRoute();
  controls.actor.body.action.setLoop(THREE.LoopRepeat,1);const beforeFiniteRepeat=controls.actor.e;
  for(let i=0;i<6;i++)controls.step(.5);close(controls.actor.e,beforeFiniteRepeat,'finite repeats are not indefinite route gait');await restoreRoute();
  controls.actor.dispose();
  const fading=await readyWalker();fading.actor.play('idle',{fade:0});fading.step(.05,.05);fading.step(.05,.05);
  fading.actor.play('walk',{fade:.25});assert.equal(fading.actor.body.action.getEffectiveWeight(),0,'actual idle-to-walk fade starts at zero weight');
  const startFade=fading.actor.e;let eligibleFrames=0;
  for(let i=0;i<15;i++){
    const eligible=actualRouteGaitRunning(fading.actor.body),before=fading.actor.e;fading.step(.05,.05);
    if(!eligible)close(fading.actor.e,before,'partial-weight fade plays in place');
    else if(eligibleFrames++===0)close(fading.actor.e,before,'first eligible route frame rejects in-place animation time');
  }
  assert(eligibleFrames>=2,'the real crossfade completes and starts route travel without deadlock');
  close(fading.actor.e-startFade,(eligibleFrames-1)*.03,'crossfade contributes no deferred locomotion debt');fading.actor.dispose();
  const near=await readyWalker();near.step(.5);const held=near.actor.e;
  near.step(0,0);near.step(0,.25);close(near.actor.e,held,'held/hidden reset intervals never advance route');
  near.step(.5);close(near.actor.e,held+.3,'resumed walking accepts only new visible elapsed');
  const beforeFar=near.actor.e,timeBeforeFar=near.actor.body.mixer.time;
  near.eye.set(100,1,2);near.step(50);close(near.actor.e,beforeFar,'animation-distance hold stops root too');close(near.actor.body.mixer.time,timeBeforeFar,'far feet stay still');
  near.eye.set(0,1,2);near.step(50);close(near.actor.e,beforeFar,'near re-entry rejects unseen time');near.step(.5);
  const beforeDraw=near.actor.e;near.eye.set(200,1,2);near.step(50,1);assert.equal(near.actor.root.visible,false);
  near.eye.set(0,1,2);near.step(50,1);close(near.actor.e,beforeDraw,'draw re-entry rejects unseen time');
  const parent=new THREE.Group();parent.add(near.actor.root);parent.visible=false;near.step(50);const hidden=near.actor.e;
  parent.visible=true;near.step(50);close(near.actor.e,hidden,'confidence/ancestor re-entry rejects unseen time');near.step(.5);
  for(const invalid of [NaN,Infinity,-1]){const before=near.actor.e;near.step(invalid);close(near.actor.e,before,'invalid visual intervals never move a route');}
  assert(near.actor.gesture('gesture_wave'));const beforeGesture=near.actor.e;near.step(.25);near.step(.25);
  close(near.actor.e,beforeGesture,'one-shot pose suspends route travel');near.step(50);close(near.actor.e,beforeGesture,'gesture return starts without locomotion catchup');
  const beforePreference=near.actor.e;preference.matches=true;for(const fn of motionHandlers)fn();near.step(50);
  close(near.actor.e,beforePreference,'Reduced Motion holds the reconstructed walk');
  preference.matches=false;for(const fn of motionHandlers)fn();near.step(50);close(near.actor.e,beforePreference,'preference resume rejects unseen time');
  // A change away and back between frames also resets, as the actual media listener does.
  preference.matches=true;for(const fn of motionHandlers)fn();preference.matches=false;for(const fn of motionHandlers)fn();near.step(50);
  close(near.actor.e,beforePreference,'unticked preference round-trip cannot bank time');
  near.actor.play('walk_slow',{fade:0});near.step(50);const beforeSlow=near.actor.e;near.step(.5);
  close(near.actor.e,beforeSlow+.15,'route uses the actual active walk variant speed');
  const activeClip=near.actor.body.action.getClip();for(const invalid of [undefined,NaN,Infinity,'0.3',0,-.3]){
    activeClip.userData.speed_m_s=invalid;const before=near.actor.e;near.step(50);close(near.actor.e,before,'invalid/missing speed never receives fallback locomotion');
  }
  activeClip.userData.speed_m_s=.3;near.step(50);const beforeGood=near.actor.e;near.step(.5);close(near.actor.e,beforeGood+.15,'restored valid metadata starts with a fresh clock');
  const previous=near.actor.body;const originalTime=previous.action.time;
  await near.actor.setLod(1);close(near.actor.body.action.time,originalTime,'actual LOD switch retains gait phase');
  const beforeLod=near.actor.e;near.step(50);close(near.actor.e,beforeLod,'new LOD body starts without catchup');
  near.step(.5);close(near.actor.e,beforeLod+.15,'new LOD then moves in phase at its active clip speed');
  const beforeDispose=motionHandlers.size;near.actor.dispose();assert.equal(motionHandlers.size,beforeDispose-1,'disposing actor removes its media listener');
  assert.equal(near.actor.visualWalkBody,null);assert.equal(near.actor.visualWalkAction,null);cold.actor.dispose();
  console.log('PASS: actual HumanActor route/mixer clock, cold load, 1/2/60FPS, holds, distance/ancestor visibility, Reduced Motion, active-clip speed, LOD phase and disposal');
} finally {
  if(oldMatchMedia===undefined)delete globalThis.matchMedia;else globalThis.matchMedia=oldMatchMedia;
}
