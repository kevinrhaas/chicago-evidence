import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const app=process.env.C4D_TEST_APP??'/workspace/chicago-driver-interaction-integration-20261104/chicago/4d';
const engine=await readFile(process.env.C4D_HUMAN_SOURCE??app+'/renderers/web/js/humans.js','utf8');
const THREE = await import(pathToFileURL(app+'/renderers/web/vendor/three-0.185.1/three.module.js').href);
// Route walkers use the actual class with real Three roots, clips and AnimationMixer.
// Assets are controlled asynchronous collaborators; this is not a body/contact test.
const classSource = engine.replace(/^import .*;$/gm, '').replace(/^export /gm, '');
const {HumanActor,routeGaitRunning:actualRouteGaitRunning} = new Function('THREE','cloneSkinned','enuToWorld',`${classSource}\nreturn {HumanActor,routeGaitRunning:typeof routeGaitRunning==='function'?routeGaitRunning:null};`)(
  THREE, scene=>scene.clone(true), (e,n,y,out)=>out.set(e,y,-n));
const motionHandlers=new Set(), preference={matches:false,
  addEventListener(name,fn){assert.equal(name,'change');motionHandlers.add(fn);},
  removeEventListener(name,fn){assert.equal(name,'change');motionHandlers.delete(fn);}};
const oldMatchMedia=globalThis.matchMedia;
globalThis.matchMedia=()=>preference;
const close=(got,want,label)=>assert(Math.abs(got-want)<1e-9,`${label}: ${got} vs ${want}`);
const routeRecord={id:'hi_rc_dufresne_joseph_1835',person_id:'rc_dufresne_joseph',
  appearance:{asset_id:'dufresne_joseph_1835'},placement:{local_e:0,local_n:0,heading_deg:90},
  behaviour:{state:'walking',route:[{local_e:20,local_n:0},{local_e:20,local_n:20},{local_e:0,local_n:20}]},
  animation:{clip:'walk',loop:true,phase:0},interaction:{selectable:true,opens:'resident_card'},lod:{policy:'fixed',fixed:0}};
function gait(name='walk',speed=.6){
  const clip=new THREE.AnimationClip(name,1.2,[new THREE.VectorKeyframeTrack('walker_bone.position',[0,.6,1.2],[0,0,0,.1,0,0,0,0,0])]);
  clip.userData={speed_m_s:speed};return clip;
}
function fixtureAsset(){const scene=new THREE.Group(),bone=new THREE.Bone();bone.name='walker_bone';scene.add(bone);const gesture=new THREE.AnimationClip('gesture_wave',.5,[new THREE.VectorKeyframeTrack('walker_bone.position',[0,.25,.5],[0,0,0,0,.1,0,0,0,0])]);const idle=new THREE.AnimationClip('idle',2,[new THREE.VectorKeyframeTrack('walker_bone.position',[0,2],[0,0,0,0,0,0])]);return {scene,animations:[gait(),gait('walk_slow',.3),gesture,idle]};}
function actorFixture(){
  let resolve;const ready=new Promise(r=>{resolve=r;}),released=[];
  const assets={acquire:()=>ready,release:(...args)=>released.push(args)};
  const samples=[];
  const actor=new HumanActor({instance:structuredClone(routeRecord),assets,heightAt:(e,n)=>{samples.push({e,n});return .01*e+.02*n;}});
  const eye=new THREE.Vector3(0,1,2);
  return {actor,eye,released,samples,resolve:()=>resolve(fixtureAsset()),step:(visual=.5,dt=.25)=>actor.update(dt,eye,visual)};
}
async function readyWalker(){const f=actorFixture();f.step(50);f.resolve();await f.actor.pending;f.step(50);return f;}
try {
  const cold=actorFixture();for(let i=0;i<4;i++)cold.step(25);
  close(cold.actor.e,0,'cold actor never travels at invented fallback speed');assert.equal(cold.actor.body,null);
  cold.resolve();await cold.actor.pending;cold.step(50);
  close(cold.actor.e,0,'first actual visible body rejects cold elapsed time');close(cold.actor.body.mixer.time,0,'cold mixer also starts at zero');
  cold.step(.5);close(cold.actor.e,.3,'ready walker uses exported .6m/s metadata');close(cold.actor.body.mixer.time,.5,'feet and root consume same half second');
  close(cold.actor.root.position.y,.003,'actual place samples rendered-ground collaborator at moved location');
  assert.equal(cold.samples.length,2,'ready frame samples final ground once; no physical sweep is claimed');
  for(const [fps,count] of [[1,2],[2,4],[60,120]]){
    const f=await readyWalker();for(let i=0;i<count;i++)f.step(1/fps,Math.min(1/fps,.25));
    close(f.actor.e,1.2,`${fps}FPS retains two actual visible seconds of route distance`);
    close(f.actor.body.mixer.time,2,`${fps}FPS feet use same two visible seconds`);f.actor.dispose();
  }
  const huge=await readyWalker();let reads=0;const actualRoute=huge.actor.route;
  huge.actor.route=new Proxy(actualRoute,{get(target,key,receiver){if(/^\d+$/.test(String(key))&&++reads>100)throw Error('route arithmetic exceeded waypoint bound');return Reflect.get(target,key,receiver);}});
  const sampleCount=huge.samples.length;huge.actor.walk(1e12);
  close(huge.actor.e,0,'huge exact complete circuits finish at the declared endpoint');close(huge.actor.n,0,'huge complete circuits preserve northing');
  close(huge.actor.heading,180,'a complete circuit finishes on its incoming southbound edge');
  assert(reads<=100,'route work is bounded by waypoints, not elapsed 50ms ticks');assert.equal(huge.samples.length,sampleCount+1,'huge interval samples only its final ground');
  huge.actor.route=actualRoute;huge.actor.walk(.5);close(huge.actor.e,.3,'no old interval debt survives the huge frame');huge.actor.dispose();
  const controls=await readyWalker();controls.step(.5);
  async function restoreRoute(){controls.actor.play('walk',{fade:0,loop:true});controls.step(50);const before=controls.actor.e;controls.step(.5);close(controls.actor.e,before+.3,'restored supported gait travels only the fresh interval');}
  for(const [name,change] of [
    ['paused',f=>{f.actor.body.action.paused=true;}],
    ['stopped',f=>f.actor.body.action.stop()],
    ['disabled',f=>{f.actor.body.action.enabled=false;}],
    ['zero action scale',f=>f.actor.body.action.setEffectiveTimeScale(0)],
    ['half action scale',f=>f.actor.body.action.setEffectiveTimeScale(.5)],
    ['half mixer scale',f=>{f.actor.body.mixer.timeScale=.5;}],
    ['zero effective weight',f=>f.actor.body.action.setEffectiveWeight(0)],
    ['pending warp',f=>f.actor.body.action.warp(1,.5,.5)],
    ['pending fade',f=>f.actor.body.action.fadeOut(.5)]
  ]){
    change(controls);const before=controls.actor.e;controls.step(.5);close(controls.actor.e,before,name+' cannot propel a route');
    controls.actor.body.mixer.timeScale=1;controls.actor.body.action.stopFading().stopWarping().setEffectiveWeight(1).setEffectiveTimeScale(1);
    await restoreRoute();
  }
  controls.actor.play('walk',{fade:0,loop:false});const beforeOnce=controls.actor.e;
  for(let i=0;i<6;i++)controls.step(.5);
  assert.equal(controls.actor.body.action.paused,true,'actual LoopOnce action finishes and clamps');
  close(controls.actor.body.action.time,1.2,'actual finite gait ends at its clip endpoint');close(controls.actor.e,beforeOnce,'unsupported finite walk plays in place throughout');
  controls.step(50);close(controls.actor.e,beforeOnce,'finished/clamped gait cannot slide the root');await restoreRoute();
  controls.actor.body.action.setLoop(THREE.LoopRepeat,1);const beforeFiniteRepeat=controls.actor.e;
  for(let i=0;i<6;i++)controls.step(.5);close(controls.actor.e,beforeFiniteRepeat,'finite repeats are not indefinite route gait');await restoreRoute();
  controls.actor.dispose();
  const fading=await readyWalker();fading.actor.play('idle',{fade:0});fading.step(.05,.05);fading.step(.05,.05);
  fading.actor.play('walk',{fade:.25});assert.equal(fading.actor.body.action.getEffectiveWeight(),0,'actual idle-to-walk fade starts at zero weight');
  const startFade=fading.actor.e;let eligibleFrames=0;
  for(let i=0;i<15;i++){
    const eligible=actualRouteGaitRunning(fading.actor.body),before=fading.actor.e;fading.step(.05,.05);
    if(!eligible)close(fading.actor.e,before,'partial-weight fade plays in place');
    else if(eligibleFrames++===0)close(fading.actor.e,before,'first eligible route frame rejects in-place animation time');
  }
  assert(eligibleFrames>=2,'the real crossfade completes and starts route travel without deadlock');
  close(fading.actor.e-startFade,(eligibleFrames-1)*.03,'crossfade contributes no deferred locomotion debt');fading.actor.dispose();
  const near=await readyWalker();near.step(.5);const held=near.actor.e;
  near.step(0,0);near.step(0,.25);close(near.actor.e,held,'held/hidden reset intervals never advance route');
  near.step(.5);close(near.actor.e,held+.3,'resumed walking accepts only new visible elapsed');
  const beforeFar=near.actor.e,timeBeforeFar=near.actor.body.mixer.time;
  near.eye.set(100,1,2);near.step(50);close(near.actor.e,beforeFar,'animation-distance hold stops root too');close(near.actor.body.mixer.time,timeBeforeFar,'far feet stay still');
  near.eye.set(0,1,2);near.step(50);close(near.actor.e,beforeFar,'near re-entry rejects unseen time');near.step(.5);
  const beforeDraw=near.actor.e;near.eye.set(200,1,2);near.step(50,1);assert.equal(near.actor.root.visible,false);
  near.eye.set(0,1,2);near.step(50,1);close(near.actor.e,beforeDraw,'draw re-entry rejects unseen time');
  const parent=new THREE.Group();parent.add(near.actor.root);parent.visible=false;near.step(50);const hidden=near.actor.e;
  parent.visible=true;near.step(50);close(near.actor.e,hidden,'confidence/ancestor re-entry rejects unseen time');near.step(.5);
  for(const invalid of [NaN,Infinity,-1]){const before=near.actor.e;near.step(invalid);close(near.actor.e,before,'invalid visual intervals never move a route');}
  assert(near.actor.gesture('gesture_wave'));const beforeGesture=near.actor.e;near.step(.25);near.step(.25);
  close(near.actor.e,beforeGesture,'one-shot pose suspends route travel');near.step(50);close(near.actor.e,beforeGesture,'gesture return starts without locomotion catchup');
  const beforePreference=near.actor.e;preference.matches=true;for(const fn of motionHandlers)fn();near.step(50);
  close(near.actor.e,beforePreference,'Reduced Motion holds the reconstructed walk');
  preference.matches=false;for(const fn of motionHandlers)fn();near.step(50);close(near.actor.e,beforePreference,'preference resume rejects unseen time');
  // A change away and back between frames also resets, as the actual media listener does.
  preference.matches=true;for(const fn of motionHandlers)fn();preference.matches=false;for(const fn of motionHandlers)fn();near.step(50);
  close(near.actor.e,beforePreference,'unticked preference round-trip cannot bank time');
  near.actor.play('walk_slow',{fade:0});near.step(50);const beforeSlow=near.actor.e;near.step(.5);
  close(near.actor.e,beforeSlow+.15,'route uses the actual active walk variant speed');
  const activeClip=near.actor.body.action.getClip();for(const invalid of [undefined,NaN,Infinity,'0.3',0,-.3]){
    activeClip.userData.speed_m_s=invalid;const before=near.actor.e;near.step(50);close(near.actor.e,before,'invalid/missing speed never receives fallback locomotion');
  }
  activeClip.userData.speed_m_s=.3;near.step(50);const beforeGood=near.actor.e;near.step(.5);close(near.actor.e,beforeGood+.15,'restored valid metadata starts with a fresh clock');
  const previous=near.actor.body;const originalTime=previous.action.time;
  await near.actor.setLod(1);close(near.actor.body.action.time,originalTime,'actual LOD switch retains gait phase');
  const beforeLod=near.actor.e;near.step(50);close(near.actor.e,beforeLod,'new LOD body starts without catchup');
  near.step(.5);close(near.actor.e,beforeLod+.15,'new LOD then moves in phase at its active clip speed');
  const beforeDispose=motionHandlers.size;near.actor.dispose();assert.equal(motionHandlers.size,beforeDispose-1,'disposing actor removes its media listener');
  assert.equal(near.actor.visualWalkBody,null);assert.equal(near.actor.visualWalkAction,null);cold.actor.dispose();
  console.log('PASS: actual HumanActor route/mixer clock, cold load, 1/2/60FPS, holds, distance/ancestor visibility, Reduced Motion, active-clip speed, LOD phase and disposal');
} finally {
  if(oldMatchMedia===undefined)delete globalThis.matchMedia;else globalThis.matchMedia=oldMatchMedia;
}
