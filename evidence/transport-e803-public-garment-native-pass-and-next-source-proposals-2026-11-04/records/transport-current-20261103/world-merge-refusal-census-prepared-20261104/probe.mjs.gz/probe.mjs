import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {execSync} from 'node:child_process';
const APP='/workspace/chicago-driver-interaction-integration-20261104/chicago/4d';
const ROOT=path.resolve(APP,'../../site/4d'), OUT=process.argv[2], MODE=process.argv[3];
assert(OUT && ['light','shadow1904'].includes(MODE));
const smoke=fs.readFileSync(path.join(APP,'tools/smoke_renderer.mjs'),'utf8');
const report={mode:MODE,sourceSmokeSha256:crypto.createHash('sha256').update(smoke).digest('hex'),checks:[],errors:[],httpErrors:[]};
report.mode='INITIAL_LIGHT_REFUSAL_SHAPE_CENSUS_NOT_RATIO';report.served={};
const overlay=fs.readFileSync(path.join(OUT,'far-merge.census-only.mjs'));
const save=()=>fs.writeFileSync(path.join(OUT,'PROBE.json'),JSON.stringify(report,null,2)+'\n');
const check=(name,pass,details)=>{report.checks.push({name,pass:!!pass,details});save();assert(pass,name+': '+details)};
const signatureDistance=new Function(smoke.slice(smoke.indexOf('function signatureDistance(a, b) {'),smoke.indexOf('\n/** Diagnostic bracket',smoke.indexOf('function signatureDistance(a, b) {')))+'; return signatureDistance;')();
const server=http.createServer((req,res)=>{const rel=decodeURIComponent(req.url.split('?')[0]);if(rel==='/walk/js/far-merge.js'){report.served[rel]={sha256:crypto.createHash('sha256').update(overlay).digest('hex'),bytes:overlay.length};save();res.setHeader('content-type','text/javascript');res.end(overlay);return;}let file=path.join(ROOT,rel);if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');if(!file.startsWith(ROOT+'/')||!fs.existsSync(file)){res.writeHead(404);res.end(rel);return}res.setHeader('content-type',({'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.wasm':'application/wasm','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg'})[path.extname(file)]||'application/octet-stream');fs.createReadStream(file).pipe(res)});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let ns;try{ns=await import('playwright')}catch{ns=await import(path.join((process.env.NODE_PATH||execSync('npm root -g',{encoding:'utf8'})).trim().split(path.delimiter)[0],'playwright/index.js'))}const{chromium}=ns.chromium?ns:ns.default;
let browser;
try{
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE,args:['--enable-unsafe-swiftshader']});
 const ctx=await browser.newContext({viewport:{width:390,height:780},hasTouch:true,isMobile:false,deviceScaleFactor:2});
 const page=await ctx.newPage();page.setDefaultTimeout(90000);
 page.on('pageerror',e=>{report.errors.push(String(e));save()});page.on('console',m=>{if(m.type()==='error'){report.errors.push(m.text());save()}});page.on('response',r=>{if(r.status()>=400){report.httpErrors.push({status:r.status(),url:r.url()});save()}});
 const url=`http://127.0.0.1:${server.address().port}/walk/?keep-geometry=1`;
 await page.goto(url,{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>window.__chicago4d?.ready===true||!!window.__chicago4d?.error,null,{timeout:240000,polling:1000});
 check('1835 reaches ready',await page.evaluate(()=>window.__chicago4d?.ready===true));
 const contracts=await import('file://'+path.join(APP,'tools/world_smoke_contracts.mjs'));
 const bstart=smoke.indexOf('    const batchCensus = await page.evaluate(() => {');
 const bend=smoke.indexOf('    await page.evaluate(() => window.__chicago4d.setAnimationHold(true));',bstart);
 const batchCode=smoke.slice(bstart,bend);
 report.batchSourceSha256=crypto.createHash('sha256').update(batchCode).digest('hex');
 const constants={STRUCTURE_BATCHES:contracts.STRUCTURE_BATCH_KEYS.length,TEXTURED_STRUCTURE_BATCHES:Number(smoke.match(/const TEXTURED_STRUCTURE_BATCHES = ([0-9]+)/)[1]),ROUGHNESS_VALUES_MIN:Number(smoke.match(/const ROUGHNESS_VALUES_MIN = ([0-9]+)/)[1]),structureBatchContract:contracts.structureBatchContract};
 report.batchCensus=await new Function('page','check','label',...Object.keys(constants), 'return(async()=>{'+batchCode+';return batchCensus;})()')(page,check,'mobile 390x780',...Object.values(constants));save();
 const bootStart=smoke.indexOf('    const bootPose = await page.evaluate(() => {');
 const bootEnd=smoke.indexOf('    // Stand where the thresholds were measured.',bootStart);
 const bootCode=smoke.slice(bootStart,bootEnd);
 report.bootPoseSourceSha256=crypto.createHash('sha256').update(bootCode).digest('hex');
 report.bootPose=await new Function('page','return(async()=>{'+bootCode+';return bootPose;})()')(page);save();
 const estart=smoke.indexOf('  const enterTown = () => page.evaluate(async () => {');
 const eend=smoke.indexOf('  // A click on the HUD chrome',estart);
 const enterCode=smoke.slice(estart,eend);
 report.enterTownSourceSha256=crypto.createHash('sha256').update(enterCode).digest('hex');save();
 await new Function('page','return(async()=>{'+enterCode+';return enterTown();})()')(page);
 report.enteredTown=true;save();
 const standText=smoke.match(/  \{\n    id: 'prairie_west'[^]*?\n  \},/)[0].trim().replace(/,$/,'');
 const stand=new Function('return ('+standText+');')();
 report.stand=stand;
 report.reading=await page.evaluate(async(st)=>{
  const a=window.__chicago4d;
  if(a.detail!=='light')throw new Error('census requires supported initial/default Light; does not replant Full/Light');
  a.setFarMerge(false);a.setFly(false);a.walker.teleport(st.pose);
  await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));a.step();
  const module=await import('/walk/js/far-merge.js');
  return {profile:'INITIAL_DEFAULT_LIGHT_SHAPE_ONLY_NOT_FULL_TO_LIGHT_RATIO_PROOF',detail:a.detail,stats:a.stats(),
   uploadRelease:a.uploadRelease,originalKernelStillHasNoNearBranch:!module.createFarMerge.toString().includes('nearNoncasting'),
   census:module.inspectFarMerge(a.scene3d)};
 },stand);save();
 check('read-only observer reaches actual saved original clusters',!!report.reading.census&&report.reading.originalKernelStillHasNoNearBranch);
 report.status='READ_ONLY_INITIAL_LIGHT_CENSUS_COMPLETED';report.noMissingRequests=report.httpErrors.length===0;save();
}catch(e){report.status='NONPASS';report.failure=String(e.stack||e);save();console.error(report.failure);process.exitCode=1}
finally{await browser?.close();await new Promise(r=>server.close(r));save()}
