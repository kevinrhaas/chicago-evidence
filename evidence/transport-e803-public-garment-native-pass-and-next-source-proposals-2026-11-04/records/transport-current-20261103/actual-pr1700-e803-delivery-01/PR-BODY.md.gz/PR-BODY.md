Otis’s and Hans’s lower-detail clothing keeps the repaired garment coverage. Driver movement/interaction fixes, lossless repeated building scalar storage and the documented shadow-calibration view are retained from public `967b427e`. This ordinary reconciliation also preserves all house, source and evidence updates from reviewed DEV `e803db79d3b152e444158104f796c6106f9080ab`.

The upstream interaction source `8057b7d6` remains included through 967; no separate DEV merge of that feature is asserted. The unsuccessful noncaster experiment is not part of this source.

Validation:

- All 1,165 distinct native checks and 402 self-tests passed on exact committed TREE `44fafc531cf7f8389afd68aebc203a476b637e43` in four parts (342.335/368.981/490.010/534.721 seconds), each under its original 600-second cap with source/resource/cleanup guards. Actual HEAD `6db8a69cc76cbb6a4527138f735b10cf8364b51a` passes all five QA checks, whitespace, original publication and published checks. Original LIBERTIES/source-use owner checks passed before freeze.
- Public967’s earlier four-part/native-HEAD/publication proof remains tied to TREE ff904; it is not substituted for this fresh run. Four repaired clothing payloads and the exact memory implementation remain unchanged. Earlier all 24 desktop/phone human fixture evidence retains its own admitted garment source scope.
- The separate measured memory candidate 05a2899 passed the unchanged 400 MiB mobile gate at 399.358 MiB with 0.642 MiB headroom; actual GPU storage fell 4,767,776 bytes, with byte-exact native/fresh-fallback pixel and pick controls. This is not a memory verdict on the later combined tree: current frame/memory CI must measure it.
- The shadow counterfactual retakes the declared lake_market view and restores boot. Source 8057’s mobile diagnostic found worst 8/restoration 0; boot-pose worst 3 remains recorded. Current desktop/mobile Stage 9 and full smoke remain pending.

The global Light cost failure (4,100 calls versus 4,498 Full, above the unchanged 0.9 ratio) stays open. Broad transport/animation tickets remain claimed with no settlement; photographic quality, natural gait, continuous contact and boarding/riding acceptance are not claimed. Fresh exact-head CI is required before ordinary DEV delivery.
