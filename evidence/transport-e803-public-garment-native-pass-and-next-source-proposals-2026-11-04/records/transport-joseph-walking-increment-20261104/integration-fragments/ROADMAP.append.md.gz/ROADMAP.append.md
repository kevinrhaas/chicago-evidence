### Joseph: one own-resident walking circuit

Qualify and install the exact already generated Joseph source/WEB exports, the proposed bounded route and his own resident-card interaction. The source candidate synchronizes a ready walking action with root travel and rejects unseen intervals; it does not change the other human/vehicle clocks. Actual foot contact, all-LOD animated clothes, route clearance, published phone/desktop interaction and town budgets remain open. Do not identify this reconstructed circuit with a documented stable or action.
