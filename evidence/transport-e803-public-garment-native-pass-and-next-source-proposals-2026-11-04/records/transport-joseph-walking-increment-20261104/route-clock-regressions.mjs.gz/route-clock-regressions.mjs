import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const app=process.env.C4D_TEST_APP??'/workspace/chicago-driver-interaction-integration-20261104/chicago/4d';
const engine=await readFile(process.env.C4D_HUMAN_SOURCE??app+'/renderers/web/js/humans.js','utf8');
// Route walkers use the actual class with real Three roots, clips and AnimationMixer.
// Assets are controlled asynchronous collaborators; this is not a body/contact test.
const THREE = await import(pathToFileURL(app+'/renderers/web/vendor/three-0.185.1/three.module.js').href);
const classSource = engine.replace(/^import .*;$/gm, '').replace(/^export /gm, '');
const {HumanActor} = new Function('THREE','cloneSkinned','enuToWorld',`${classSource}\nreturn {HumanActor};`)(
  THREE, scene=>scene.clone(true), (e,n,y,out)=>out.set(e,y,-n));
const motionHandlers=new Set(), preference={matches:false,
  addEventListener(name,fn){assert.equal(name,'change');motionHandlers.add(fn);},
  removeEventListener(name,fn){assert.equal(name,'change');motionHandlers.delete(fn);}};
const oldMatchMedia=globalThis.matchMedia;
globalThis.matchMedia=()=>preference;
const close=(got,want,label)=>assert(Math.abs(got-want)<1e-9,`${label}: ${got} vs ${want}`);
const routeRecord={id:'hi_rc_dufresne_joseph_1835',person_id:'rc_dufresne_joseph',
  appearance:{asset_id:'dufresne_joseph_1835'},placement:{local_e:0,local_n:0,heading_deg:90},
  behaviour:{state:'walking',route:[{local_e:20,local_n:0},{local_e:20,local_n:20},{local_e:0,local_n:20}]},
  animation:{clip:'walk',loop:true,phase:0},interaction:{selectable:true,opens:'resident_card'},lod:{policy:'fixed',fixed:0}};
function gait(name='walk',speed=.6){
  const clip=new THREE.AnimationClip(name,1.2,[new THREE.VectorKeyframeTrack('walker_bone.position',[0,.6,1.2],[0,0,0,.1,0,0,0,0,0])]);
  clip.userData={speed_m_s:speed};return clip;
}
function fixtureAsset(){const scene=new THREE.Group(),bone=new THREE.Bone();bone.name='walker_bone';scene.add(bone);const gesture=new THREE.AnimationClip('gesture_wave',.5,[new THREE.VectorKeyframeTrack('walker_bone.position',[0,.25,.5],[0,0,0,0,.1,0,0,0,0])]);return {scene,animations:[gait(),gait('walk_slow',.3),gesture]};}
function actorFixture(){
  let resolve;const ready=new Promise(r=>{resolve=r;}),released=[];
  const assets={acquire:()=>ready,release:(...args)=>released.push(args)};
  const samples=[];
  const actor=new HumanActor({instance:structuredClone(routeRecord),assets,heightAt:(e,n)=>{samples.push({e,n});return .01*e+.02*n;}});
  const eye=new THREE.Vector3(0,1,2);
  return {actor,eye,released,samples,resolve:()=>resolve(fixtureAsset()),step:(visual=.5,dt=.25)=>actor.update(dt,eye,visual)};
}
async function readyWalker(){const f=actorFixture();f.step(50);f.resolve();await f.actor.pending;f.step(50);return f;}
try {
  const cold=actorFixture();for(let i=0;i<4;i++)cold.step(25);
  close(cold.actor.e,0,'cold actor never travels at invented fallback speed');assert.equal(cold.actor.body,null);
  cold.resolve();await cold.actor.pending;cold.step(50);
  close(cold.actor.e,0,'first actual visible body rejects cold elapsed time');close(cold.actor.body.mixer.time,0,'cold mixer also starts at zero');
  cold.step(.5);close(cold.actor.e,.3,'ready walker uses exported .6m/s metadata');close(cold.actor.body.mixer.time,.5,'feet and root consume same half second');
  close(cold.actor.root.position.y,.003,'actual place samples rendered-ground collaborator at moved location');
  assert(cold.samples.length>=11,'full visible half-second samples terrain throughout bounded route steps');
  for(let i=1;i<cold.samples.length;i++)assert(Math.hypot(cold.samples[i].e-cold.samples[i-1].e,cold.samples[i].n-cold.samples[i-1].n)<=.030000001,'ground callback skips no more than 50ms of declared gait travel');
  for(const [fps,count] of [[1,2],[2,4],[60,120]]){
    const f=await readyWalker();for(let i=0;i<count;i++)f.step(1/fps,Math.min(1/fps,.25));
    close(f.actor.e,1.2,`${fps}FPS retains two actual visible seconds of route distance`);
    close(f.actor.body.mixer.time,2,`${fps}FPS feet use same two visible seconds`);f.actor.dispose();
  }
  const near=await readyWalker();near.step(.5);const held=near.actor.e;
  near.step(0,0);near.step(0,.25);close(near.actor.e,held,'held/hidden reset intervals never advance route');
  near.step(.5);close(near.actor.e,held+.3,'resumed walking accepts only new visible elapsed');
  const beforeFar=near.actor.e,timeBeforeFar=near.actor.body.mixer.time;
  near.eye.set(100,1,2);near.step(50);close(near.actor.e,beforeFar,'animation-distance hold stops root too');close(near.actor.body.mixer.time,timeBeforeFar,'far feet stay still');
  near.eye.set(0,1,2);near.step(50);close(near.actor.e,beforeFar,'near re-entry rejects unseen time');near.step(.5);
  const beforeDraw=near.actor.e;near.eye.set(200,1,2);near.step(50,1);assert.equal(near.actor.root.visible,false);
  near.eye.set(0,1,2);near.step(50,1);close(near.actor.e,beforeDraw,'draw re-entry rejects unseen time');
  const parent=new THREE.Group();parent.add(near.actor.root);parent.visible=false;near.step(50);const hidden=near.actor.e;
  parent.visible=true;near.step(50);close(near.actor.e,hidden,'confidence/ancestor re-entry rejects unseen time');near.step(.5);
  for(const invalid of [NaN,Infinity,-1]){const before=near.actor.e;near.step(invalid);close(near.actor.e,before,'invalid visual intervals never move a route');}
  assert(near.actor.gesture('gesture_wave'));const beforeGesture=near.actor.e;near.step(.25);near.step(.25);
  close(near.actor.e,beforeGesture,'one-shot pose suspends route travel');near.step(50);close(near.actor.e,beforeGesture,'gesture return starts without locomotion catchup');
  const beforePreference=near.actor.e;preference.matches=true;for(const fn of motionHandlers)fn();near.step(50);
  close(near.actor.e,beforePreference,'Reduced Motion holds the reconstructed walk');
  preference.matches=false;for(const fn of motionHandlers)fn();near.step(50);close(near.actor.e,beforePreference,'preference resume rejects unseen time');
  // A change away and back between frames also resets, as the actual media listener does.
  preference.matches=true;for(const fn of motionHandlers)fn();preference.matches=false;for(const fn of motionHandlers)fn();near.step(50);
  close(near.actor.e,beforePreference,'unticked preference round-trip cannot bank time');
  near.actor.play('walk_slow',{fade:0});near.step(50);const beforeSlow=near.actor.e;near.step(.5);
  close(near.actor.e,beforeSlow+.15,'route uses the actual active walk variant speed');
  const activeClip=near.actor.body.action.getClip();for(const invalid of [undefined,NaN,Infinity,'0.3',0,-.3]){
    activeClip.userData.speed_m_s=invalid;const before=near.actor.e;near.step(50);close(near.actor.e,before,'invalid/missing speed never receives fallback locomotion');
  }
  activeClip.userData.speed_m_s=.3;near.step(50);const beforeGood=near.actor.e;near.step(.5);close(near.actor.e,beforeGood+.15,'restored valid metadata starts with a fresh clock');
  const previous=near.actor.body;const originalTime=previous.action.time;
  await near.actor.setLod(1);close(near.actor.body.action.time,originalTime,'actual LOD switch retains gait phase');
  const beforeLod=near.actor.e;near.step(50);close(near.actor.e,beforeLod,'new LOD body starts without catchup');
  near.step(.5);close(near.actor.e,beforeLod+.15,'new LOD then moves in phase at its active clip speed');
  const beforeDispose=motionHandlers.size;near.actor.dispose();assert.equal(motionHandlers.size,beforeDispose-1,'disposing actor removes its media listener');
  assert.equal(near.actor.visualWalkBody,null);assert.equal(near.actor.visualWalkAction,null);cold.actor.dispose();
  console.log('PASS: actual HumanActor route/mixer clock, cold load, 1/2/60FPS, holds, distance/ancestor visibility, Reduced Motion, active-clip speed, LOD phase and disposal');
} finally {
  if(oldMatchMedia===undefined)delete globalThis.matchMedia;else globalThis.matchMedia=oldMatchMedia;
}
