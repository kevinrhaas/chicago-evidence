from pathlib import Path
import subprocess,json,base64,hashlib,os,datetime
P=Path(__file__).resolve().parent;W=Path('/tmp/wolf-poster-source-20261103/chicago/4d');T=W/'tickets';N='T-2250-2499/T-2376-match-the-green-tree-tavern-to-its-pictures.md';BY='codex GT1684 approved exact-resume handoff coordinator'
def call(args,timeout=120,cwd=W):
 r=subprocess.run(args,cwd=cwd,capture_output=True,timeout=timeout);print(r.stdout.decode(),end='',flush=True)
 if r.returncode:print(r.stderr.decode(),flush=True)
 assert r.returncode==0,(args,r.returncode,r.stderr.decode());return r
assert not subprocess.check_output(['git','-C',str(T),'status','--porcelain']).strip()
s=subprocess.run(['node','tools/ticket.mjs','lap','1684','--status'],cwd=W,capture_output=True,timeout=120);(P/'OWN-LAP-METADATA-GUARD.log').write_bytes(s.stdout+s.stderr);assert s.returncode==3 and BY.encode()in s.stdout,'Foreign lap or unreadable holder; stop'
call(['git','-C',str(T),'pull','--ff-only','--quiet','origin','main'])
q=call(['gh','api','repos/kevinrhaas/chicago-tickets/contents/'+N],cwd=P);x=json.loads(q.stdout);original=base64.b64decode(x['content']);assert (T/N).read_bytes()==original
front=original.decode().split('---',2)[1];assert '\nstate: open\n'in front and '\nclaimed_by: null\n'in front and '\nclaimed_run: null\n'in front and '\npr: null\n'in front
append=(P/'PROPOSED-T2376-APPEND.md').read_bytes();assert hashlib.sha256(append).hexdigest()=='aa2f0269b1ef645b797fae5999c4da34b7991b62654ebb2a889ae8a485c4db17';marker=b'## Exact native resume of existing PR1684';assert marker not in original
(P/'T2376-BEFORE-METADATA.md').write_bytes(original);tail=b'\n\n'+append+b'\n[Immutable root-reviewed exact-resume packet](https://github.com/kevinrhaas/chicago-evidence/blob/77ae63460dd21e2e7dc3fb2ad0a9155e033cc7f6/evidence/green-tree-2026-11-04/pr1684-exact-resume-review-a3a87/RECOVERY.md).\n';(T/N).write_bytes(original+tail);assert(T/N).read_bytes().startswith(original)
assert subprocess.check_output(['git','-C',str(T),'diff','--name-only'],text=True).splitlines()==[N]
call(['node','tools/ticket.mjs','sync','-m','T-2376: root-reviewed exact PR1684 native resume handoff and truthful bounded repair plan'],timeout=240)
assert not subprocess.check_output(['git','-C',str(T),'status','--porcelain']).strip()
q=call(['gh','api','repos/kevinrhaas/chicago-tickets/contents/'+N],cwd=P);x=json.loads(q.stdout);assert base64.b64decode(x['content'])==original+tail;(P/'T2376-AFTER-METADATA.md').write_bytes(original+tail)
(P/'METADATA-PROOF.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ticket_blob':x['sha'],'before_sha256':hashlib.sha256(original).hexdigest(),'after_sha256':hashlib.sha256(original+tail).hexdigest(),'prior_body_byte_exact_prefix':True,'append_once':True,'ticket_still_open_unclaimed_prnull':True,'only_ticket_path_written':N,'no_forced_ticket_claim':True},indent=2)+'\n')
call(['bash','.github/steward/pr-rest.sh','--repo','kevinrhaas/chicago','resume','1684','--why','Root-approved exact saved-PR finish: normal current-dev integration, repair Source-use backlinks with compile_source_use.py, correct unused-UV provenance, reuse only exact native GT export proof while preserving outer bake124 truth; actual current both viewport/native and whole eight-part gate before partial dev merge. Full bounded handoff preserved on T-2376; no new geometry research.','--waits-on','nothing'],timeout=180,cwd=W.parent.parent)
s=subprocess.run(['node','tools/ticket.mjs','lap','1684','--status'],cwd=W,capture_output=True,timeout=120);(P/'OWN-LAP-PRE-RELEASE.log').write_bytes(s.stdout+s.stderr);assert s.returncode==3 and BY.encode()in s.stdout,'Do not release foreign holder'
call(['node','tools/ticket.mjs','lap','1684','--release'])
s=subprocess.run(['node','tools/ticket.mjs','lap','1684','--status'],cwd=W,capture_output=True,timeout=120);(P/'LAP-AFTER-COORDINATOR-RELEASE.log').write_bytes(s.stdout+s.stderr);assert s.returncode==0 and s.stdout.startswith(b'free ')
assert not subprocess.check_output(['git','-C',str(T),'status','--porcelain']).strip()
(P/'METADATA-CLOSED.json').write_text(json.dumps({'status':'APPEND_SYNC_RESUME_NOTE_AND_ONLY_OWN_LAP_RELEASED','ticket_clone_clean':True,'coordinator_lap_released':True,'foreign_1685_1687_laps_not_written':True,'no_app_authored_source_write':True},indent=2)+'\n');print('Approved whole-body-preserving GT handoff pushed; only own coordinator lap released',flush=True)
