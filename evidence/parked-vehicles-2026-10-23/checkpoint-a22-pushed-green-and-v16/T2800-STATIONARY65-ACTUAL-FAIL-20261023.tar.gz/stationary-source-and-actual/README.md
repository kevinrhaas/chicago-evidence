# One stationary65 diagnostic from an existing V14 saved field

This is held source, not another field build or section preflight. It reads the
exact future V14 `DIAGNOSTIC-FLOAT32-ANATOMICAL-ARRAYS-NOT-MODEL.npz` and its actual
protected/serialization receipt. The future array, receipt, terminal and optional
walk-report pins remain null until those actual outputs exist. Only root may
bind/release this one 30-second/512-MiB numerical unit after reviewing them.

A failed walk does **not** disqualify an independently measured smaller standing
posture automatically. The checker requires protected serialized field data and a
closed V14 process, not WALK PASS. It preserves the actual V14 terminal/report
status verbatim and leaves walking/trotting disabled. It never imports or calls
the V14 binding builder, performs an optimization or edits any field array.

The copied V2 standing module is exact `1404bfb2…`: one fixed reconstructed
12-second profile, 4 mm lateral/2 mm longitudinal lean and at most 4 mm compression.
It starts/ends by copying original pivots/identity rotations directly. Four exact
closed chains retain all original neutral hoof transforms. The walk's 30 mm start
drop, stride/route and individual hoof-minimum flattening are absent because they
describe a different motion domain. This checker must not replace the original
walk caller or reinterpret its earlier failures as standing results.

The original edge .9–1.1, area .8–1.2, no-negative-rest-normal, ground −1e−5 m,
seam 1e−6 m, segment/parent 1e−9 m, loop 1e−9 and full-patch contact 1e−5 m limits
are copied and checked against their original source. Original neutral position
tolerance is 1e−6 m. All three full meshes are skinned at exactly65 inclusive
samples. Every 59/59/13/10-vertex hoof patch is compared both to its original
neutral positions and to the candidate's actual neutral positions, with zero
route. A fixed carrier rotation/translation preserves these distance comparisons;
the current test does not qualify a new street/terrain placement or actor support.

The loader independently checks unchanged source positions/rest/inverse binds,
original source-known label vectors, exact original969 tail joint/weight slots
and float32 bits, and rigid ownership of all four original annotated patches.
The candidate weights are loaded directly with their original float32 dtype;
the only casts of those values are to binary64 computation, never a new serialized
field. Transient corrupted copies are negative controls, not candidate rebuilds.

Negative controls use an actual neutral pose plus a real 3 mm hoof translation,
the already-sampled quarter-cycle body displacement without limb closure, an
actual source-known row corruption, and an original tail weight-bit change. The
same contact/segment/protection predicates must reject them. Full65 aggregate
metrics and worst edge/area witnesses are retained even on physical failure;
invalid inputs or unreachable/degenerate poses refuse immediately without retry.

No numerical import, pose, field generation, test, browser or export ran while
preparing this source. No current15-joint host clock, asset, app, ticket or lease
changed. Even a future PASS would only qualify this sampled canonical standing
posture: force/load transfer, continuous contact/collision, anatomical naturalness,
composed head/tail idle, glTFLoader/Mixer, visual/photo, harness, rider and live
activation remain separate work. Prior walk, QP and V12 failures stay unchanged.
