"""HELD single saved-field standing65 diagnostic: 30s/512MiB, no retry/export."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
PYTHON = '/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert sys.version_info[:3] == (3, 11, 17), 'Known runtime required before numerical imports'
    release_path = Path(sys.argv[1]).resolve()
    release = json.loads(release_path.read_text())
    assert release['released'] is True and release['authorization'] == 'ONE_ROOT_AUTHORIZED_STATIONARY65_SAVED_V14_FIELD'
    assert release['maximum_runs'] == release['maximum_stationary65_diagnostics'] == 1
    assert release['maximum_fields'] == release['maximum_solvers'] == release['maximum_exports'] == 0
    assert release['maximum_wall_seconds'] == 30 and release['maximum_rss_bytes'] == 512*1024*1024
    assert set(release['source_sha256']) == {'actual_model.py', 'standing_planted_pose_HELD.py', 'prove_stationary65_HELD.py', 'run_once_HELD.py', 'ORIGINAL-PHYSICAL-LIMITS.json'}
    assert set(release['input_pins']) == {'rig26', 'controls26', 'contact_sidecar', 'tail_fixture', 'phase_a_arrays', 'original_walk_threshold_source', 'v14_float32_arrays', 'v14_field_receipt', 'v14_terminal', 'v14_walk_report'}
    for name, digest in release['source_sha256'].items():
        assert sha(HERE/name) == digest, name+' source drift'
    assert release['source_sha256'][Path(__file__).name] == sha(__file__)
    for key, pin in release['input_pins'].items():
        if key == 'v14_walk_report' and pin is None:
            continue
        assert isinstance(pin['path'], str) and isinstance(pin['sha256'], str) and len(pin['sha256']) == 64, key+' actual pin absent'
        assert sha(pin['path']) == pin['sha256'], key+' input drift'
    out = HERE/'ACTUAL'
    assert not out.exists(), 'One-shot output already exists; no retry'
    out.mkdir()
    (out/'ROOT-RELEASE.json').write_text(json.dumps(release, indent=2)+'\n')
    intent = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), fields=0, solvers=0, exports=0,
                  stationary65_diagnostics=1, maximum_wall_seconds=30, maximum_rss_bytes=536870912,
                  nice=19, math_threads=1, prior_walk_pass_not_required=True)
    (out/'INTENT.json').write_text(json.dumps(intent, indent=2)+'\n')
    env = os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1',
               VECLIB_MAXIMUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    start, peak, reason = time.monotonic(), 0, None
    with (out/'stdout.log').open('w') as stdout, (out/'stderr.log').open('w') as stderr:
        child = subprocess.Popen(['nice', '-n', '19', PYTHON, str(HERE/'prove_stationary65_HELD.py'), str(release_path)],
                                 cwd=HERE, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        while child.poll() is None:
            try:
                for line in (Path('/proc')/str(child.pid)/'status').read_text().splitlines():
                    if line.startswith('VmRSS:'):
                        peak = max(peak, int(line.split()[1])*1024)
            except FileNotFoundError:
                pass
            if time.monotonic()-start > 30:
                reason = 'WALL_LIMIT_30_SECONDS'
            elif peak > 512*1024*1024:
                reason = 'RSS_LIMIT_512_MiB'
            if reason:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                break
            time.sleep(.025)
        code = child.wait()
    elapsed = time.monotonic()-start
    peak = max(peak, int(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)*1024)
    if peak > 512*1024*1024:
        reason = reason or 'KERNEL_PEAK_RSS_EXCEEDED_512_MiB'
    if elapsed > 30:
        reason = reason or 'ELAPSED_LIMIT_EXCEEDED_30_SECONDS'
    path = out/'STATIONARY65-RESULT.json'
    report = json.loads(path.read_text()) if path.exists() else None
    passed = report is not None and report['status'] == 'STATIONARY65_SAVED_FIELD_CPU_PASS_ONLY' and code == 0 and reason is None
    status = ('STATIONARY65_SAVED_FIELD_CPU_PASS_ONLY' if passed else 'RESOURCE_FAIL_NO_RETRY' if reason
              else 'STATIONARY65_SAVED_FIELD_CPU_FAIL_NO_RETRY' if report else 'INPUT_OR_MOTION_REFUSAL_NO_ACCEPTANCE_NO_RETRY')
    terminal = dict(status=status, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), exit_code=code,
                    elapsed_seconds=elapsed, actual_peak_rss_bytes=peak, resource_failure=reason,
                    runs=1, reruns=0, no_owned_child_active=True, report_present=report is not None,
                    fields=0, solvers=0, exports=0, prior_walk_pass_not_required=True,
                    prior_v14_walk_status=report['v14_walk_report_status_preserved'] if report else 'NO_NEW_READING',
                    walk_or_trot_or_visual_or_activation_accepted=False)
    (out/'TERMINAL.json').write_text(json.dumps(terminal, indent=2)+'\n')
    print(json.dumps(terminal), flush=True)
    return 0 if passed else 2


if __name__ == '__main__':
    raise SystemExit(main())
