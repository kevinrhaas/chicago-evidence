from pathlib import Path
import subprocess,os,json,datetime,time,shutil,hashlib
R=Path('/tmp/chicago-covered-sag/chicago/4d');D=Path(__file__).resolve().parent
OLD='13375406538e76e8c1deadf18165089f7145ea28';BASE='5135fb7674eea8cf5b140a7cf0c8bc208b0b1f4e';TREE='fa427eb201de4bad4b7265313fcc5a422f440ea4'
def git(*a):return subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert not (D/'START.json').exists()
assert git('rev-parse','HEAD')==OLD and git('rev-parse','MERGE_HEAD')==BASE
assert git('write-tree')==TREE and not git('ls-files','-u') and not git('diff','--name-only')
assert git('rev-parse','origin/dev')=='824957fe47dd70fad729c3b117cb18b695d54b0b'
proof=Path('/workspace/shared/T2794-DEV513-MERGE-FOCUSED-ACTUAL-20261023/PROTECTED-STAGED-SOURCE-PROOF.json');assert json.loads(proof.read_text())['pass']
env=os.environ.copy();env['PATH']='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:'+env['PATH']
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:env[key]='1'
env.update({'C4D_GATE_REQUIRE_READERS':'1','CHECK_JOBS':'4','BASE':BASE})
start={'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'head':OLD,'merge_head':BASE,'staged_tree':TREE,'lease':'950ce00ce394fc30547294ef731738f6e08138b7','command':['bash','tools/preflight.sh'],'check_jobs':4,'math_threads':1,'execution_mode':'require_escalated','reader_path':env['PATH'].split(':')[:2],'protected_proof_sha256':hashlib.sha256(proof.read_bytes()).hexdigest()}
(D/'START.json').write_text(json.dumps(start,indent=2)+'\n');print(json.dumps(start),flush=True)
t=time.monotonic()
with (D/'FULL-PREFLIGHT.log').open('wb') as f:p=subprocess.run(['bash','tools/preflight.sh'],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
logs={}
for name in ['preflight-check.log','preflight-cl.log','preflight-ids.log','check-timings.tsv']:
 src=Path('/tmp')/name
 if src.exists():shutil.copyfile(src,D/name);logs[name]={'sha256':hashlib.sha256((D/name).read_bytes()).hexdigest(),'bytes':src.stat().st_size}
terminal={'terminal':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'pass':p.returncode==0,'elapsed_seconds':time.monotonic()-t,'head':git('rev-parse','HEAD'),'merge_head':git('rev-parse','MERGE_HEAD'),'staged_tree':git('write-tree'),'unstaged':git('diff','--name-only'),'unmerged':git('ls-files','-u'),'logs':logs,'own_children_reaped':True}
(D/'TERMINAL.json').write_text(json.dumps(terminal,indent=2)+'\n');print(json.dumps(terminal),flush=True)
print((D/'FULL-PREFLIGHT.log').read_text()[-3500:],flush=True)
raise SystemExit(p.returncode)
