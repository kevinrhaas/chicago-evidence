import pathlib,json,subprocess,hashlib,datetime,re
D=pathlib.Path('/workspace/shared/PR1213-A22CA758-AUX-BAKE39913287670-GET-20261023');D.mkdir(exist_ok=False);H='a22ca758323e6e2f1ed9f3909a88fb98636be55c';RUN=39913287670;PATH='.github/workflows/chicago-4d-bake.yml';n=0
workflow=subprocess.check_output(['git','-C','/workspace/chicago','show',H+':'+PATH]);(D/'SOURCE-WORKFLOW.yml').write_bytes(workflow)
def api(label,route,plain=False):
 global n
 n+=1;p=D/f'{n:02d}-{label}';p.with_suffix('.request.json').write_text(json.dumps({'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'GET','route':route},indent=2)+'\n');r=subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/'+route],capture_output=True,timeout=45);p.with_suffix('.stdout').write_bytes(r.stdout);p.with_suffix('.stderr').write_bytes(r.stderr);assert r.returncode==0,'GET unavailable; STOP without retry '+str(p);return r.stdout.decode()if plain else json.loads(r.stdout)
r=api('ACTUAL-FIXED-RUN','actions/runs/'+str(RUN));assert r['id']==RUN and r['head_sha']==H and r['head_branch']=='steward/t2794-brougham-v17-20261022'and r['event']=='push'and r['workflow_id']==365585052 and r['path']==PATH and r['run_attempt']==1 and r['repository']['full_name']=='kevinrhaas/chicago','Auxiliary run identity drift'
out={'run_id':RUN,'workflow_path':PATH,'workflow_id':365585052,'event':'push','attempt':1,'head':H,'status':r['status'],'conclusion':r['conclusion'],'role':'Auxiliary conditional content-build workflow; not counted in applicable normal3/world passes','source_workflow_sha256':hashlib.sha256(workflow).hexdigest(),'terminal_evidence_complete':False,'app_source_edits':0,'POSTs':0,'reruns':0,'normal_success_count_contribution':0,'qualification_pass':False}
if r['status']=='completed':
 jobs=api('ACTUAL-JOBS','actions/runs/'+str(RUN)+'/attempts/1/jobs?per_page=100');assert jobs['total_count']==len(jobs['jobs']),'Incomplete auxiliary job inventory';rows=[];all_skipped_except_warranted=True
 for j in jobs['jobs']:
  assert j['run_id']==RUN and j['head_sha']==H and j['run_attempt']==1
  row={'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'steps':j.get('steps',[])}
  if j['conclusion']!='skipped':
   text=api('JOB-'+str(j['id'])+'-LOG','actions/jobs/'+str(j['id'])+'/logs',True);clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text);values=re.findall(r'(?m)^\S+Z\s*\[command\].*[/ ]git log -1 --format=%H\s*\n\S+Z\s*([a-f0-9]{40})\s*$',clean);assert values==[H],'Auxiliary job checkout does not match exactsource';row.update(actual_checkout=H,log_sha256=hashlib.sha256(text.encode()).hexdigest(),actual_skip_or_bake_notices=[x for x in text.splitlines()if re.search(r'^\S+Z\s*##\[notice\].*(?:SKIPPING|baking|Bake declined)',x)],failed_steps=[x for x in j.get('steps',[])if x['conclusion']in['failure','cancelled','timed_out']])
   if j['name']!='warranted':all_skipped_except_warranted=False
  rows.append(row)
 out.update(jobs=rows,terminal_evidence_complete=True,actual_non_skipped_job_names=[x['name']for x in rows if x['conclusion']!='skipped'],conditional_downstream_skips_observed=all_skipped_except_warranted and any(x['conclusion']=='skipped'for x in rows),actual_red_jobs=[{'name':x['name'],'conclusion':x['conclusion']}for x in rows if x['conclusion']in['failure','cancelled','timed_out']],no_content_bake_or_smoke_execution_claimed=all_skipped_except_warranted)
out['GETs']=n;(D/'ACTUAL-AUXILIARY-BAKE-READOUT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
