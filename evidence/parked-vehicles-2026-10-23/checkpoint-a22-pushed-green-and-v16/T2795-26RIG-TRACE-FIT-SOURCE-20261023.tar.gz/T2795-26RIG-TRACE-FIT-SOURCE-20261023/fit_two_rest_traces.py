#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""ONE opt-in rest fitting candidate from already decoded exact horse surfaces.

Does not export/change a mesh, run Blender, animate, render or edit an app.
The current authoring turn has NOT invoked this runner.
"""
import argparse
import hashlib
import json
import math
import struct
from pathlib import Path


def need(ok, message):
    if not ok:
        raise ValueError(message)


def read_json_pinned(description):
    raw = Path(description['path']).read_bytes()
    need(hashlib.sha256(raw).hexdigest() == description['sha256'],
         'Exact saved input changed: ' + description['path'])
    return json.loads(raw)


def clip(poly, axis, value, sign):
    """Clip actual triangles, including edges crossing the slab without a vertex in it."""
    result = []
    for a, b in zip(poly, poly[1:] + poly[:1]):
        da, db = sign * (a[axis] - value), sign * (b[axis] - value)
        if da >= 0:
            result.append(a)
        if (da >= 0) != (db >= 0):
            t = da / (da - db)
            result.append([a[k] + t * (b[k] - a[k]) for k in range(3)])
    return result


def finite3(p):
    return isinstance(p, list) and len(p) == 3 and all(math.isfinite(v) for v in p)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--candidate-sha256', required=True)
    parser.add_argument('--profile-template', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    raw = args.candidate.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == args.candidate_sha256,
         'Reviewed candidate bytes changed')
    c = json.loads(raw)
    need(c['status'] == 'SOURCE_ONLY_ROOT_REVIEW_PENDING' and c['scene'] == '1904'
         and c['fit_accepted'] is False and c['production_activation_allowed'] is False,
         'Explicit unaccepted1904 candidate only')
    need(c['units'] == 'metres' and c['frame'] == '+Yup +Zforward +Xleft',
         'Canonical metre frame required; never normalize03a1 a second time')
    need(not args.output_dir.exists(), 'Fresh output directory required; preserve prior trial')

    # Authenticate actual horse GLB and already decoded CPU/LBS readback. Its
    # canonical positions are not raw native POSITION accessors or bone pivots.
    host = Path(c['host']['path']).read_bytes()
    need(hashlib.sha256(host).hexdigest() == c['host']['sha256'], 'Actual horse host changed')
    need(struct.unpack_from('<III', host)[0:2] == (0x46546c67, 2), 'glTF2 GLB required')
    doc = json.loads(host[20:20 + struct.unpack_from('<I', host, 12)[0]])
    need(len(doc['skins'][0]['joints']) == 26, 'Exact26joint rest study required')
    carrier = c['carrier']
    need(doc['nodes'][carrier['gltf_node_index']]['name'] == carrier['expected_gltf_node_name'],
         'Exact current26rig carrier node required')
    data = read_json_pinned(c['saved_actual_rest_readback'])
    need(any(x['label'] == 'horse' and x['sha256'] == c['host']['sha256'] for x in data['inputs']),
         'Saved decoded surfaces are not this actual host')
    horse = data['objects']['horse']
    actual_rest = horse['frames'][carrier['expected_gltf_node_name']]['matrixWorld']
    need(len(actual_rest) == 16 and all(abs(a - b) < 1e-8 for a, b in zip(
        actual_rest, carrier['rest_world_matrix'])), 'Actual rest carrier frame differs')
    contacts = read_json_pinned(c['saved_contact_witnesses'])
    need(contacts['horse']['shoulder_plane_surface_intersections']['hits']
         == c['saved_contact_witnesses']['actual_surface_points'], 'Shoulder witness changed')

    triangles = []
    for mesh in horse['meshes']:
        positions, indices = mesh['positions'], mesh['triangles']
        need(all(finite3(p) for p in positions) and len(indices) % 3 == 0,
             'Finite actual indexed horse surfaces required')
        for offset in range(0, len(indices), 3):
            ids = indices[offset:offset + 3]
            need(all(isinstance(i, int) and 0 <= i < len(positions) for i in ids), 'Invalid actual index')
            triangles.append((mesh['name'], offset // 3, [positions[i] for i in ids]))
    need(len(triangles) == 14986, 'Exact complete original horse surface count required')

    g = c['trace_geometry']
    y, zs = g['center_y_m'], g['z_stations_m']
    need(math.isfinite(y) and 2 <= len(zs) <= 6 and all(math.isfinite(z) for z in zs)
         and all(a > b for a, b in zip(zs, zs[1:])), 'Finite descending aft station chain required')
    need(g['width_m'] == 0.0254 and 0 < g['thickness_m'] < g['width_m'],
         'Moore1inch trace width and explicit finite thickness required')
    need(g['engineering_surface_gap_m'] > 0 and g['serialization_allowance_m'] > 0
         and g['sag_m'] >= 0, 'Explicit reconstructed static clearance and slack required')
    radius = math.hypot(g['width_m'] / 2, g['thickness_m'] / 2)
    expansion = radius + g['engineering_surface_gap_m'] + g['serialization_allowance_m']
    ylo, yhi = y - g['sag_m'] - expansion, y + expansion
    bands = []
    for leg, (za, zb) in enumerate(zip(zs, zs[1:])):
        zlo, zhi = min(za, zb) - expansion, max(za, zb) + expansion
        minimum, maximum = math.inf, -math.inf
        witnesses = {}; count = 0
        for name, ti, tri in triangles:
            # Cheap rejection before polygon clipping; no vertex-only acceptance.
            if max(p[1] for p in tri) < ylo or min(p[1] for p in tri) > yhi:
                continue
            if max(p[2] for p in tri) < zlo or min(p[2] for p in tri) > zhi:
                continue
            poly = tri
            for axis, value, sign in [(1, ylo, 1), (1, yhi, -1), (2, zlo, 1), (2, zhi, -1)]:
                poly = clip(poly, axis, value, sign)
                if not poly:
                    break
            if not poly:
                continue
            count += 1
            for point in poly:
                if point[0] < minimum:
                    minimum = point[0]; witnesses['minimum'] = {'mesh': name, 'triangle': ti, 'point_m': point}
                if point[0] > maximum:
                    maximum = point[0]; witnesses['maximum'] = {'mesh': name, 'triangle': ti, 'point_m': point}
        need(count > 0 and math.isfinite(minimum) and math.isfinite(maximum),
             'No actual surface in declared leg; do not silently invent a fitting')
        bands.append({'leg': leg, 'y_interval_m': [ylo, yhi], 'z_interval_m': [zlo, zhi],
                      'actual_clipped_triangles': count, 'actual_surface_x_m': [minimum, maximum],
                      'required_center_x_m': {'l': maximum + expansion, 'r': minimum - expansion},
                      'witnesses': witnesses})

    points, anchors, chains = {}, [], {}
    for side in ['l', 'r']:
        chains[side] = []
        for i, z in enumerate(zs):
            adjacent = bands[max(0, i - 1):min(len(bands), i + 1)]
            values = [b['required_center_x_m'][side] for b in adjacent]
            x = max(values) if side == 'l' else min(values)
            need(abs(x) <= g['maximum_lateral_extent_m'],
                 'Candidate exceeds explicit outerseed envelope; preserve failure, no expansion')
            name = 'trace_rest_' + side + '_' + str(i)
            point = [x, y, z]; points[name] = point; chains[side].append(name)
            anchors.append({'id': name, 'gltf_node_index': carrier['gltf_node_index'],
                            'expected_gltf_node_name': carrier['expected_gltf_node_name'],
                            'expected_carrier_rest_world_matrix': actual_rest,
                            'canonical_rest_point_m': point,
                            'role': 'outboard unhitched rest trace candidate, not pressure/contact/socket'})

    receipt = {'status': 'ONE reconstructed unaccepted exact26rig rest trace fitting candidate',
               'candidate_sha256': args.candidate_sha256, 'host_sha256': c['host']['sha256'],
               'host_geometry_license': c['host']['license'], 'host_credit': c['host']['credit'],
               'saved_readback_sha256': c['saved_actual_rest_readback']['sha256'],
               'whole_horse_triangle_count': len(triangles), 'carrier_rest_world_matrix': actual_rest,
               'cross_section_half_diagonal_m': radius, 'clip_slab_expansion_m': expansion,
               'declared_engineering_gap_m': g['engineering_surface_gap_m'], 'bands': bands,
               'center_points_m': points, 'actual_generated_strip_clearance_measured': False,
               'scope': 'Conservative complete-rest-surface slab constraint; no animated fit, collar, pressure, load, bit, palm, vehicle or photographic acceptance',
               'fit_accepted': False, 'production_activation_allowed': False}
    receipt_bytes = (json.dumps(receipt, indent=2) + '\n').encode()
    calibration = {'schema': 'harness_actual_rest_anchor_candidate_v1',
                   'status': 'root_reviewed_rest_anchor_candidate', 'fit_accepted': False,
                   'production_activation_allowed': False, 'host_sha256': c['host']['sha256'],
                   'license': c['host']['license'], 'source_credit': c['host']['credit'],
                   'host_fitting_receipt_sha256': hashlib.sha256(receipt_bytes).hexdigest(),
                   'units': c['units'], 'frame': c['frame'], 'anchors': anchors,
                   'output_root_rest_points_m': points, 'free_ends_are_unhitched_rest_tails': True}
    profile_bytes = args.profile_template.read_bytes()
    need(hashlib.sha256(profile_bytes).hexdigest() == c['profile_template_sha256'],
         'Reviewed recipe template changed')
    profile = json.loads(profile_bytes)
    need(profile['eligible_scene_ids'] == ['1904'], 'Keep separate1904Moore recipe')
    profile['id'] = 'moore_no1_two_flat_rest_traces_26rig_candidate'
    profile['license'] = c['host']['license']
    profile['fitted_host_credit'] = c['host']['credit']
    profile['original_parameter_license'] = 'CC0-1.0'
    profile['links'] = [{'id': 'trace_' + side, 'role': 'trace', 'anchors': chains[side],
                         'segments_per_leg': g['segments_per_leg'], 'width_m': g['width_m'],
                         'thickness_m': g['thickness_m'], 'sag_m': g['sag_m'],
                         'width_hint_local': [0, 1, 0], 'width_grade': 'text_attested',
                         'routing_status': 'unaccepted actual26rig rest-surface candidate; no vehicle connected'}
                        for side in ['l', 'r']]
    args.output_dir.mkdir()
    (args.output_dir / 'FIT-RECEIPT.json').write_bytes(receipt_bytes)
    (args.output_dir / 'REST-POINTS.json').write_text(json.dumps(calibration, indent=2) + '\n')
    (args.output_dir / 'TRACE-PROFILE.json').write_text(json.dumps(profile, indent=2) + '\n')
    print(json.dumps({'status': receipt['status'], 'output': str(args.output_dir),
                      'fitted_anchor_count': len(anchors), 'generated_meshes': 0,
                      'fit_accepted': False, 'production_activation_allowed': False}))


if __name__ == '__main__':
    main()
