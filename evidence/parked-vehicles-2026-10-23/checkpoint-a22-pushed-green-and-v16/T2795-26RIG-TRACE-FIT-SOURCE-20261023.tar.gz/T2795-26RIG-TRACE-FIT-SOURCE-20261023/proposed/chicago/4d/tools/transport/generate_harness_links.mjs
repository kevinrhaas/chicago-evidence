#!/usr/bin/env node
// SPDX-License-Identifier: GPL-3.0-or-later
// Generate an engine-neutral rest GLB with the SAME fixed topology as the live
// isolated link adapter. No Blender or model download. Not invoked by default.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import * as THREE from '../../renderers/web/vendor/three-0.185.1/three.module.js';
import { createFlatHarnessLinks } from '../../renderers/web/transport/hitch/flat-harness-links.mjs';

const need = (ok, why) => { if (!ok) throw Error(why); };
const flags = new Map();
for (let i = 2; i < process.argv.length; i += 2) {
  need(['--profile', '--rest-points', '--output-dir', '--scene', '--host-glb', '--fitting-receipt'].includes(process.argv[i])
    && process.argv[i + 1] && !flags.has(process.argv[i]), 'Explicit unique profile/rest-points/output-dir/scene arguments required');
  flags.set(process.argv[i], process.argv[i + 1]);
}
need(flags.size === 6, 'Usage: --profile file --rest-points file --host-glb file --fitting-receipt file --output-dir NEW_DIRECTORY --scene 1904');
const profileBytes = await fs.readFile(flags.get('--profile'));
const restBytes = await fs.readFile(flags.get('--rest-points'));
const profile = JSON.parse(profileBytes), rest = JSON.parse(restBytes);
need(rest.status === 'root_reviewed_rest_anchor_candidate' && rest.fit_accepted === false,
  'Reviewed actual-source rest-point candidate required, not unfitted template');
need(/^[0-9a-f]{64}$/.test(rest.host_sha256) && /^[0-9a-f]{64}$/.test(rest.host_fitting_receipt_sha256 ?? ''),
  'Pinned source and actual fitting-receipt hashes required');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
need(sha(await fs.readFile(flags.get('--host-glb'))) === rest.host_sha256,
  'Actual horse bytes differ from rest-anchor host');
need(sha(await fs.readFile(flags.get('--fitting-receipt'))) === rest.host_fitting_receipt_sha256,
  'Actual fitting receipt differs from reviewed rest-anchor contract');
need(rest.units === 'metres' && rest.frame === '+Yup +Zforward +Xleft', 'Explicit canonical metre frame required');
const points = rest.output_root_rest_points_m;
need(points && Object.values(points).every(p => Array.isArray(p) && p.length === 3 && p.every(Number.isFinite)),
  'Explicit actual geometric rest points required');
const root = new THREE.Group();
const material = new THREE.MeshStandardMaterial({
  color: new THREE.Color().fromArray(profile.material.baseColorFactor),
  roughness: profile.material.roughnessFactor, metalness: profile.material.metallicFactor,
});
const links = createFlatHarnessLinks(THREE, {
  profile, sceneId: flags.get('--scene'), material, linkRoot: root,
  anchorPoint(id, out) { need(points[id], 'No fitted rest point: ' + id); out.fromArray(points[id]); },
});
try {
  links.update();
  const doc = { asset: { version: '2.0', generator: 'original finite flat harness-link study' },
    scene: 0, scenes: [{ nodes: [] }], nodes: [], meshes: [], materials: [{
      name: profile.material.name, pbrMetallicRoughness: {
        baseColorFactor: profile.material.baseColorFactor,
        roughnessFactor: profile.material.roughnessFactor,
        metallicFactor: profile.material.metallicFactor,
      },
    }], accessors: [], bufferViews: [], buffers: [],
    extras: { grade: 'reconstructed', units: 'metres', frame: '+Yup +Zforward +Xleft',
      source_profile: profile.id, host_sha256: rest.host_sha256,
      fitAccepted: false, liveActivationAllowed: false, photographicAcceptance: false } };
  const chunks = []; let offset = 0;
  const pad = () => { const n = (4 - offset % 4) % 4; if (n) { chunks.push(Buffer.alloc(n)); offset += n; } };
  function accessor(array, count, type, componentType, target, bounds = false) {
    pad(); const bytes = Buffer.from(array.buffer, array.byteOffset, array.byteLength);
    const vi = doc.bufferViews.length;
    doc.bufferViews.push({ buffer: 0, byteOffset: offset, byteLength: bytes.length, target });
    chunks.push(bytes); offset += bytes.length;
    const entry = { bufferView: vi, componentType, count, type };
    if (bounds) {
      entry.min = [Infinity, Infinity, Infinity]; entry.max = [-Infinity, -Infinity, -Infinity];
      for (let i = 0; i < count; i++) for (let k = 0; k < 3; k++) {
        entry.min[k] = Math.min(entry.min[k], array[i * 3 + k]);
        entry.max[k] = Math.max(entry.max[k], array[i * 3 + k]);
      }
    }
    doc.accessors.push(entry); return doc.accessors.length - 1;
  }
  for (const { mesh } of links.links) {
    const g = mesh.geometry, p = g.attributes.position, n = g.attributes.normal, index = g.index;
    doc.scenes[0].nodes.push(doc.nodes.length);
    doc.nodes.push({ name: mesh.name, mesh: doc.meshes.length, extras: mesh.userData.harnessStudy });
    doc.meshes.push({ name: mesh.name, primitives: [{
      attributes: { POSITION: accessor(p.array, p.count, 'VEC3', 5126, 34962, true),
        NORMAL: accessor(n.array, n.count, 'VEC3', 5126, 34962) },
      indices: accessor(index.array, index.count, 'SCALAR', 5123, 34963), material: 0,
    }] });
  }
  pad(); doc.buffers.push({ byteLength: offset });
  const binary = Buffer.concat(chunks), text = Buffer.from(JSON.stringify(doc));
  const json = Buffer.concat([text, Buffer.alloc((4 - text.length % 4) % 4, 0x20)]);
  const header = Buffer.alloc(20), binHeader = Buffer.alloc(8);
  header.writeUInt32LE(0x46546c67, 0); header.writeUInt32LE(2, 4);
  header.writeUInt32LE(28 + json.length + binary.length, 8);
  header.writeUInt32LE(json.length, 12); header.writeUInt32LE(0x4e4f534a, 16);
  binHeader.writeUInt32LE(binary.length, 0); binHeader.writeUInt32LE(0x004e4942, 4);
  const glb = Buffer.concat([header, json, binHeader, binary]);
  const receipt = { profile: profile.id, profile_sha256: sha(profileBytes), rest_points_sha256: sha(restBytes),
    horse_host_sha256: rest.host_sha256, host_fitting_receipt_sha256: rest.host_fitting_receipt_sha256,
    glb_sha256: sha(glb), glb_bytes: glb.length,
    triangles: links.links.reduce((s, x) => s + x.mesh.geometry.index.count / 3, 0),
    draw_primitives: links.links.length, textures: 0, grade: 'reconstructed',
    live_activation_allowed: false, surface_clearance_accepted: false,
    scope: 'generated fixed-topology rest links only; no whole gear, historical fit, skin, force, browser or world qualification' };
  const dest = path.resolve(flags.get('--output-dir'));
  await fs.mkdir(dest); // Refuse existing destination; never overwrite a prior trial.
  await fs.writeFile(path.join(dest, profile.id + '.glb'), glb);
  await fs.writeFile(path.join(dest, 'binding-sidecar.json'), JSON.stringify({ profile, rest, receipt }, null, 2) + '\n');
  console.log(JSON.stringify(receipt, null, 2));
} finally { links.dispose(); material.dispose(); }
