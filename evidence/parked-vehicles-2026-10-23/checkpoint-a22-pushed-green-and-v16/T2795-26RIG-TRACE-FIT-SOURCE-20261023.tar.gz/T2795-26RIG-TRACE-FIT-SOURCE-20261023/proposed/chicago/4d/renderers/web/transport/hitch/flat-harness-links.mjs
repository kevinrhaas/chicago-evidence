// SPDX-License-Identifier: GPL-3.0-or-later
// Opt-in technical study. Call only after root release and actual rest-anchor fitting.
// Rectangular leather links, not TubeGeometry ropes; fixed buffers, no force solver.
const need = (ok, message) => { if (!ok) throw Error(message); };
const finite3 = p => Array.isArray(p) && p.length === 3 && p.every(Number.isFinite);

/** Make one closed, hard-edged rectangular strip. Each guide is passed exactly.
 * anchorPoint(id, out) must write an actual live point in linkRoot LOCAL metres.
 * No guessed driver, horse, shaft or pole socket is supplied by this module.
 */
export function createFlatHarnessLink(THREE, {
  definition, anchorPoint, material, linkRoot, widthHint = [0, 1, 0],
}) {
  const d = definition;
  need(d?.role === 'trace' || d?.role === 'rein', 'Explicit trace/rein role required');
  need(Array.isArray(d.anchors) && d.anchors.length >= 2 && d.anchors.length <= 6
    && new Set(d.anchors).size === d.anchors.length,
    'Distinct explicit route anchors required');
  need(Number.isInteger(d.segments_per_leg) && d.segments_per_leg >= 4 && d.segments_per_leg <= 32,
    'Bounded fixed tessellation required');
  need(d.width_m > 0 && d.thickness_m > 0 && d.thickness_m < d.width_m,
    'Finite rectangular leather cross section required');
  need([d.width_m, d.thickness_m, d.sag_m].every(Number.isFinite) && d.sag_m >= 0,
    'Finite dimensions and nonnegative reconstructed sag required');
  need(finite3(widthHint) && typeof anchorPoint === 'function' && material && linkRoot,
    'Owned material, root and actual-point provider required');

  const legs = d.anchors.length - 1, segments = legs * d.segments_per_leg;
  const ringCount = segments + 1, vertices = ringCount * 8 + 8;
  const positions = new Float32Array(vertices * 3), normals = new Float32Array(vertices * 3);
  const indices = new Uint16Array(segments * 24 + 12);
  const anchors = d.anchors.map(() => new THREE.Vector3());
  const points = Array.from({ length: ringCount }, () => new THREE.Vector3());
  const tangents = Array.from({ length: ringCount }, () => new THREE.Vector3());
  const widths = Array.from({ length: ringCount }, () => new THREE.Vector3());
  const thicknesses = Array.from({ length: ringCount }, () => new THREE.Vector3());
  const hint = new THREE.Vector3().fromArray(widthHint), scratch = new THREE.Vector3();
  let offset = 0;
  for (let i = 0; i < segments; i++) for (let face = 0; face < 4; face++) {
    const a = i * 8 + face * 2, b = a + 1, c = b + 8, e = a + 8;
    indices.set([a, b, c, a, c, e], offset); offset += 6;
  }
  const cap = ringCount * 8;
  indices.set([cap, cap + 2, cap + 1, cap, cap + 3, cap + 2,
    cap + 4, cap + 5, cap + 6, cap + 4, cap + 6, cap + 7], offset);
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3).setUsage(THREE.DynamicDrawUsage));
  geometry.setAttribute('normal', new THREE.BufferAttribute(normals, 3).setUsage(THREE.DynamicDrawUsage));
  geometry.setIndex(new THREE.BufferAttribute(indices, 1));
  const mesh = new THREE.Mesh(geometry, material);
  mesh.name = d.id;
  mesh.visible = false; // No transient old/default geometry before complete fitting.
  mesh.userData.harnessStudy = { grade: 'reconstructed', role: d.role,
    forceFit: false, photographicAcceptance: false, fixedTriangles: segments * 8 + 4 };
  linkRoot.add(mesh);
  let disposed = false;
  const cornerSigns = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
  function put(vertex, point, side, normal, signs, surfaceNormal) {
    const at = vertex * 3;
    positions[at] = point.x + side.x * signs[0] * d.width_m / 2 + normal.x * signs[1] * d.thickness_m / 2;
    positions[at + 1] = point.y + side.y * signs[0] * d.width_m / 2 + normal.y * signs[1] * d.thickness_m / 2;
    positions[at + 2] = point.z + side.z * signs[0] * d.width_m / 2 + normal.z * signs[1] * d.thickness_m / 2;
    surfaceNormal.toArray(normals, at);
  }
  function update() {
    need(!disposed, 'Disposed harness link');
    mesh.visible = false; // Failure never leaves stale links visible.
    for (let i = 0; i < anchors.length; i++) {
      anchors[i].set(NaN, NaN, NaN);
      anchorPoint(d.anchors[i], anchors[i]);
      need([anchors[i].x, anchors[i].y, anchors[i].z].every(Number.isFinite),
        'Missing/nonfinite actual harness anchor: ' + d.anchors[i]);
      if (i) need(anchors[i].distanceToSquared(anchors[i - 1]) > 1e-8,
        'Collapsed guide span: ' + d.id);
    }
    for (let leg = 0; leg < legs; leg++) for (let j = 0; j < d.segments_per_leg; j++) {
      const t = j / d.segments_per_leg;
      points[leg * d.segments_per_leg + j].copy(anchors[leg]).lerp(anchors[leg + 1], t);
      // Explicit visual slack only. No tension, stopping or animal-pressure claim.
      points[leg * d.segments_per_leg + j].y -= 4 * d.sag_m * t * (1 - t);
    }
    points[segments].copy(anchors[legs]);
    for (let i = 0; i < ringCount; i++) {
      const tangent = tangents[i].subVectors(points[Math.min(i + 1, segments)], points[Math.max(i - 1, 0)]);
      need(tangent.lengthSq() > 1e-12, 'Folded or collapsed route: ' + d.id);
      tangent.normalize();
      const side = widths[i].copy(i ? widths[i - 1] : hint);
      side.addScaledVector(tangent, -side.dot(tangent));
      // An unsuitable explicit hint is refused, never replaced by a sudden frame flip.
      need(side.lengthSq() > 1e-8, 'Width hint/frame parallel to route: ' + d.id);
      side.normalize();
      const normal = thicknesses[i].crossVectors(tangent, side).normalize();
      for (let face = 0; face < 4; face++) {
        scratch.copy(face % 2 === 0 ? normal : side).multiplyScalar(face < 2 ? (face === 0 ? -1 : 1) : (face === 2 ? 1 : -1));
        put(i * 8 + face * 2, points[i], side, normal, cornerSigns[face], scratch);
        put(i * 8 + face * 2 + 1, points[i], side, normal, cornerSigns[(face + 1) % 4], scratch);
      }
    }
    for (let k = 0; k < 4; k++) {
      scratch.copy(tangents[0]).negate();
      put(cap + k, points[0], widths[0], thicknesses[0], cornerSigns[k], scratch);
      put(cap + 4 + k, points[segments], widths[segments], thicknesses[segments], cornerSigns[k], tangents[segments]);
    }
    geometry.attributes.position.needsUpdate = true;
    geometry.attributes.normal.needsUpdate = true;
    geometry.computeBoundingBox(); geometry.computeBoundingSphere();
    mesh.visible = true;
    return { id: d.id, triangles: segments * 8 + 4, exactGuideCount: anchors.length,
      scope: 'actual provided endpoints, finite flat visual strip; no collision/force acceptance' };
  }
  return { mesh, update, dispose() {
    if (disposed) return; disposed = true; mesh.visible = false;
    mesh.removeFromParent(); geometry.dispose(); // Caller retains material ownership.
  } };
}

/** Atomic opt-in study group. The source-specific recipe, not this geometry
 * primitive, decides date eligibility. Missing a fitted point hides ALL links.
 */
export function createFlatHarnessLinks(THREE, { profile, sceneId, anchorPoint, material, linkRoot }) {
  need(profile?.status === 'source_proposal_unaccepted' && profile.production_activation_allowed === false,
    'Explicit held profile required');
  need(profile.eligible_scene_ids?.includes(String(sceneId)), 'Harness recipe not eligible for this scene');
  need(Array.isArray(profile.links) && profile.links.length > 0 && profile.links.length <= 8,
    'Bounded explicit links required');
  need(new Set(profile.links.map(x => x.id)).size === profile.links.length, 'Unique link names required');
  const links = [];
  try {
    for (const definition of profile.links) links.push(createFlatHarnessLink(THREE, {
      definition, anchorPoint, material, linkRoot,
      widthHint: definition.width_hint_local,
    }));
  } catch (error) { for (const link of links) link.dispose(); throw error; }
  return { links, update() {
    try { return links.map(link => link.update()); }
    catch (error) { for (const link of links) link.mesh.visible = false; throw error; }
  }, dispose() { for (const link of links) link.dispose(); }, liveActivationAllowed: false };
}
