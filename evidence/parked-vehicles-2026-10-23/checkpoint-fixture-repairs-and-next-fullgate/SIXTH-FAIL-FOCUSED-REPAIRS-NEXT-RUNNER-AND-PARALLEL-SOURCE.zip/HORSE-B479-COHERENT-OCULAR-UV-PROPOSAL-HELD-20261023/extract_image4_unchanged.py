from pathlib import Path
import struct,json,hashlib
D=Path(__file__).parent
P=Path('/workspace/chicago-waistcoat/chicago/4d/renderers/web/transport/standing-horse/horse-sevket-v16-planted-standing-v1.glb')
raw=P.read_bytes();sha=hashlib.sha256(raw).hexdigest()
assert sha=='b479442cb03ac46eb13c19da15a79cdfaf28dbdf356b116f78de7ce7ecdc60be'
n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);binary=raw[28+n:]
im=g['images'][4];v=g['bufferViews'][im['bufferView']];start=v.get('byteOffset',0);image=binary[start:start+v['byteLength']]
assert im['mimeType']=='image/jpeg' and image[:2]==b'\xff\xd8'
assert hashlib.sha256(image).hexdigest()=='1e0382c8ad5d155dc3bf45378a5a37bb10bdcc79ffefee211e69edb3b609a5b3'
at=2;dimensions=None
while at<len(image):
 assert image[at]==255
 while image[at]==255:at+=1
 marker=image[at];at+=1
 if marker in [0xD8,0xD9] or 0xD0<=marker<=0xD7:continue
 size=struct.unpack_from('>H',image,at)[0]
 if marker in [0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF]:
  precision,height,width=struct.unpack_from('>BHH',image,at+2);dimensions=dict(width=width,height=height,precision_bits=precision,SOF_marker=hex(marker));break
 at+=size
assert dimensions['width']==256 and dimensions['height']==256
out=D/'eye-brown-image4-source-UNCHANGED.jpg';assert not out.exists();out.write_bytes(image)
receipt=dict(scope='Exact embedded image4 bitcopy only; no decode/edit/reencode/GLB derivative',asset=str(P),asset_sha256=sha,image_index=4,image=im,bufferView=v,image_sha256=hashlib.sha256(image).hexdigest(),image_bytes=len(image),dimensions=dimensions,external_copy=str(out),copy_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),asset_after_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),extractor_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
assert receipt['asset_after_sha256']==sha
(D/'ACTUAL-IMAGE4-BITCOPY-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
