#!/bin/bash
bash -c 'node "$1"; result=$?; exit "$result"' _ "$1"
result=$?
exit "$result"
