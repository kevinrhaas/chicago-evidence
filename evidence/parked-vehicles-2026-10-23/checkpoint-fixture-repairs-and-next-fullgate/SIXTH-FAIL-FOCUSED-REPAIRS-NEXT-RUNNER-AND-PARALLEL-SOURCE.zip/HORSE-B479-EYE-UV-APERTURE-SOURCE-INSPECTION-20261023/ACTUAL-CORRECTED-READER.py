from pathlib import Path
import struct,json,math,hashlib,time
start=time.monotonic();P=Path('/workspace/chicago-waistcoat/chicago/4d/renderers/web/transport/standing-horse/horse-sevket-v16-planted-standing-v1.glb');raw=P.read_bytes();sha=hashlib.sha256(raw).hexdigest();assert sha=='b479442cb03ac46eb13c19da15a79cdfaf28dbdf356b116f78de7ce7ecdc60be',sha
n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);B=raw[28+n:]
D=Path('/workspace/shared/HORSE-B479-EYE-UV-APERTURE-SOURCE-INSPECTION-20261023');D.mkdir(exist_ok=False)
(D/'FIRST-LAUNCH-PARSER-FAIL.txt').write_text('Authorized first source-reader launch failed before execution. File <stdin>, line109: xoff=10 if sign==1 else340; SyntaxError: expected else after if expression. Exit1. No asset read, report, or persistent process from that launch. Root authorized lexical correction and same finite inspection once.\n')
fmt={5120:('b',1),5121:('B',1),5122:('h',2),5123:('H',2),5125:('I',4),5126:('f',4)};types={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16};cache={}
def attr(i):
 if i in cache:return cache[i]
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];f,size=fmt[a['componentType']];k=types[a['type']];off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size*k);out=[]
 for j in range(a['count']):
  t=struct.unpack_from('<'+f*k,B,off+j*stride)
  if a.get('normalized'):
   den={5120:127,5121:255,5122:32767,5123:65535}.get(a['componentType']);t=tuple(max(-1,x/den)for x in t)
  out.append(t)
 cache[i]=out;return out
I=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]
def mm(a,b):return[sum(a[k*4+r]*b[c*4+k]for k in range(4))for c in range(4)for r in range(4)]
def mv(m,p):
 t=(*p[:3],1);return tuple(sum(m[c*4+r]*t[c]for c in range(4))for r in range(3))
def local(d):
 if 'matrix'in d:return d['matrix']
 x,y,z,w=d.get('rotation',[0,0,0,1]);sx,sy,sz=d.get('scale',[1,1,1]);tx,ty,tz=d.get('translation',[0,0,0]);return[(1-2*y*y-2*z*z)*sx,(2*x*y+2*z*w)*sx,(2*x*z-2*y*w)*sx,0,(2*x*y-2*z*w)*sy,(1-2*x*x-2*z*z)*sy,(2*y*z+2*x*w)*sy,0,(2*x*z+2*y*w)*sz,(2*y*z-2*x*w)*sz,(1-2*x*x-2*y*y)*sz,0,tx,ty,tz,1]
parent={c:i for i,d in enumerate(g['nodes'])for c in d.get('children',[])};world={}
def wm(i):
 if i not in world:world[i]=mm(wm(parent[i]),local(g['nodes'][i]))if i in parent else local(g['nodes'][i])
 return world[i]
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def mul(a,s):return tuple(x*s for x in a)
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def norm(a):return math.sqrt(dot(a,a))
def unit(a):return mul(a,1/max(norm(a),1e-30))
prims=[]
for ni,node in enumerate(g['nodes']):
 if 'mesh'not in node:continue
 skin=g['skins'][node['skin']]if 'skin'in node else None;skinm=[mm(wm(j),list(ib))for j,ib in zip(skin['joints'],attr(skin['inverseBindMatrices']))]if skin else None
 for pi,p in enumerate(g['meshes'][node['mesh']]['primitives']):
  pos=attr(p['attributes']['POSITION']);uv=attr(p['attributes']['TEXCOORD_0'])if 'TEXCOORD_0'in p['attributes']else None;idx=[q[0]for q in attr(p['indices'])];points=[]
  weights=attr(p['attributes']['WEIGHTS_0'])if skin else None;joints=attr(p['attributes']['JOINTS_0'])if skin else None
  for vi,v in enumerate(pos):
   if skin:
    total=sum(weights[vi]);acc=(0,0,0)
    for joint,weight in zip(joints[vi],weights[vi]):
     if weight:acc=add(acc,mul(mv(skinm[joint],v),weight/total))
    points.append(acc)
   else:points.append(mv(wm(ni),v))
  prims.append({'node':ni,'mesh':node['mesh'],'primitive':pi,'material':p['material'],'attributes':p['attributes'],'indices_accessor':p['indices'],'points':points,'uv':uv,'indices':idx})
eye=[p for p in prims if g['materials'][p['material']]['name']=='Eye_brown'];assert len(eye)==1;eye=eye[0];pts=eye['points'];uv=eye['uv'];idx=eye['indices'];tris=[tuple(idx[i:i+3])for i in range(0,len(idx),3)]
weld={};wid=[]
for p in pts:
 key=tuple(round(x,7)for x in p);wid.append(weld.setdefault(key,len(weld)))
par=list(range(len(weld)))
def find(x):
 while par[x]!=x:par[x]=par[par[x]];x=par[x]
 return x
def union(a,b):
 a,b=find(a),find(b)
 if a!=b:par[b]=a
for a,b,c in tris:union(wid[a],wid[b]);union(wid[a],wid[c])
components={}
for i in range(len(pts)):components.setdefault(find(wid[i]),[]).append(i)
compinfo=[{'original_vertex_count':len(v),'center':tuple(sum(pts[i][k]for i in v)/len(v)for k in range(3)),'uv_min':tuple(min(uv[i][k]for i in v)for k in range(2)),'uv_max':tuple(max(uv[i][k]for i in v)for k in range(2))}for v in components.values()]
sides={name:[t for t in tris if all(sign*pts[i][0]>0 for i in t)]for name,sign in [('positive_X',1),('negative_X',-1)]}
other=[t for p in prims if p is not eye for t in [tuple(p['points'][i]for i in p['indices'][at:at+3])for at in range(0,len(p['indices']),3)]]
def bary(t,u,v):
 a,b,c=[uv[i]for i in t];det=(b[0]-a[0])*(c[1]-a[1])-(c[0]-a[0])*(b[1]-a[1])
 if abs(det)<1e-14:return None
 q=((u-a[0])*(c[1]-a[1])-(c[0]-a[0])*(v-a[1]))/det;r=((b[0]-a[0])*(v-a[1])-(u-a[0])*(b[1]-a[1]))/det
 return(1-q-r,q,r)if min(1-q-r,q,r)>=-1e-7 else None
def atuv(ts,u,v):
 out=[]
 for t in ts:
  w=bary(t,u,v)
  if w is not None:out.append((t,w,tuple(sum(pts[i][k]*b for i,b in zip(t,w))for k in range(3))))
 return out
def hit(o,d,t):
 a,b,c=t;e1=sub(b,a);e2=sub(c,a);h=cross(d,e2);det=dot(e1,h)
 if abs(det)<1e-12:return False
 inv=1/det;s=sub(o,a);u=dot(s,h)*inv
 if u<0 or u>1:return False
 q=cross(s,e1);v=dot(d,q)*inv
 if v<0 or u+v>1:return False
 distance=dot(e2,q)*inv;return distance>1e-5
results={};svg=[]
for side,ts in sides.items():
 sign=1 if side=='positive_X'else -1;ids=sorted({i for t in ts for i in t});center=tuple(sum(pts[i][k]for i in ids)/len(ids)for k in range(3));samples=atuv(ts,.5,.5)
 samples.sort(key=lambda q:sign*q[2][0],reverse=True);s=samples[0]if samples else None
 result={'side':side,'vertex_count':len(ids),'triangle_count':len(ts),'center':center,'u_range':[min(uv[i][0]for i in ids),max(uv[i][0]for i in ids)],'v_range':[min(uv[i][1]for i in ids),max(uv[i][1]for i in ids)],'uv_center_candidate_count':len(samples)}
 if not s:results[side]=result;continue
 t,w,p=s;a,b,c=[uv[i]for i in t];e1=sub(pts[t[1]],pts[t[0]]);e2=sub(pts[t[2]],pts[t[0]]);du1=b[0]-a[0];dv1=b[1]-a[1];du2=c[0]-a[0];dv2=c[1]-a[1];det=du1*dv2-du2*dv1;dU=mul(sub(mul(e1,dv2),mul(e2,dv1)),1/det);dV=mul(sub(mul(e2,du1),mul(e1,du2)),1/det);normal=unit(cross(dU,dV));target=sub((0,0,1),mul(normal,dot(normal,(0,0,1))));aa=dot(dU,dU);bb=dot(dU,dV);cc=dot(dV,dV);den=aa*cc-bb*bb;ud=(dot(dU,target)*cc-dot(dV,target)*bb)/den;vd=(dot(dV,target)*aa-dot(dU,target)*bb)/den;length=math.hypot(ud,vd);direction=[ud/length,vd/length];axisangle=math.degrees(math.atan2(direction[1],direction[0]))%180
 result.update({'uv_center_3d':p,'center_triangle_vertex_ids':t,'center_barycentric':w,'center_triangle_evidence':[{'vertex':i,'position':pts[i],'uv':uv[i]}for i in t],'dPosition_dU':dU,'dPosition_dV':dV,'surface_normal_unoriented':normal,'projected_anatomical_forward_Z_texture_direction':direction,'texture_axis_angle_deg_mod180':axisangle,'texture_U_world_up_fraction':dot(unit(dU),(0,1,0)),'texture_V_world_up_fraction':dot(unit(dV),(0,1,0))})
 radius=.18;near=[q for q in other if all(max(v[k]for v in q)>=p[k]-radius and min(v[k]for v in q)<=p[k]+radius for k in range(3))];result['local_other_surface_triangles']=len(near);visibility={}
 for label,d in [('lateral',unit((sign,0,0))),('forward_quarter',unit((sign,0,1)))]:
  rows=[]
  for yi in range(9):
   row=[]
   for xi in range(9):
    U=.35+xi*.3/8;V=.35+yi*.3/8;ss=atuv(ts,U,V)
    if not ss:row.append('N');continue
    ss.sort(key=lambda q:dot(q[2],d),reverse=True);point=ss[0][2];occluded=any(hit(add(point,mul(d,1e-6)),d,q)for q in near);row.append('O'if occluded else 'V')
   rows.append(''.join(row))
  visibility[label]={'direction_toward_viewer':d,'sample_uv_square':[.35,.65,.35,.65],'grid9_rows_V_increasing':rows,'visible_count':sum(r.count('V')for r in rows),'occluded_count':sum(r.count('O')for r in rows),'no_uv_count':sum(r.count('N')for r in rows),'scope':'source neutral rest pose only; local body/hair triangle opaque ray occlusion, no rendering or calibrated camera'}
 result['aperture_source_rays']=visibility;results[side]=result
 xoff=10 if sign==1 else 340;svg.append(f'<text x="{xoff}" y="20">{side}: UV chart, red = anatomical +Z axis</text>')
 for q in ts:
  if any(.28<=uv[i][0]<=.72 and .28<=uv[i][1]<=.72 for i in q):
   coords=' '.join(f'{xoff+300*uv[i][0]:.3f},{35+300*uv[i][1]:.3f}'for i in q);svg.append(f'<polygon points="{coords}" fill="none" stroke="#999" stroke-width=".4"/>')
 dx,dy=direction;svg.append(f'<line x1="{xoff+150-60*dx}" y1="{185-60*dy}" x2="{xoff+150+60*dx}" y2="{185+60*dy}" stroke="red" stroke-width="3"/>')
report={'status':'ACTUAL_FINITE_SOURCE_ONLY_INSPECTION','asset':str(P),'sha256':sha,'coordinate_space':'canonical metres +Yup +Zforward +Xleft, per frozen SOURCE.json; actual neutral glTF rest transforms/normalized source skin weights applied','eye_material_index':eye['material'],'material':g['materials'][eye['material']],'eye_node':eye['node'],'eye_mesh':eye['mesh'],'accessor_mapping':eye['attributes'],'indices_accessor':eye['indices_accessor'],'connected_components_weld_tolerance_m':1e-7,'weld_components':compinfo,'eye_side_results':results,'total_other_triangles':len(other),'unchanged_asset_after':hashlib.sha256(P.read_bytes()).hexdigest()==sha,'elapsed_seconds':time.monotonic()-start,'limits':['No browser/render/Node/NumPy/newdownload/textureedit/GLB/app modification','Source-ray occlusion is not actual rendered visibility or present animation-frame qualification','Near local body/hair screen only; external world/fence occlusion excluded','UV-axis anatomy target is projected +Z tangent at UVcenter, not pupil muscle measurement; head pitch may make exact anatomical horizontal more nuanced']}
(D/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');(D/'UV-COORDINATE-DIAGRAM.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="670" height="350" viewBox="0 0 670 350"><rect width="670" height="350" fill="white"/><g font-size="10" font-family="sans-serif">'+''.join(svg)+'</g></svg>')
receipt={'directory':str(D),'result_sha256':hashlib.sha256((D/'RESULT.json').read_bytes()).hexdigest(),'diagram_sha256':hashlib.sha256((D/'UV-COORDINATE-DIAGRAM.svg').read_bytes()).hexdigest(),'asset_unchanged':report['unchanged_asset_after'],'elapsed_seconds':report['elapsed_seconds']};(D/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':receipt,'component_count':len(compinfo),'eye_results':results},indent=2))
