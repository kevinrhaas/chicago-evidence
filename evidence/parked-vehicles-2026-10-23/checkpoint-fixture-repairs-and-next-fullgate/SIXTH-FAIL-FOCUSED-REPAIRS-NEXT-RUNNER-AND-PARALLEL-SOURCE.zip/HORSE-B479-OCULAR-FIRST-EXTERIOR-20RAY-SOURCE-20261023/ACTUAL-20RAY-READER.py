from pathlib import Path
import struct,json,math,hashlib,time,traceback
START=time.monotonic()
D=Path('/workspace/shared/HORSE-B479-OCULAR-FIRST-EXTERIOR-20RAY-SOURCE-20261023')
SOURCE=Path(__file__)
P=Path('/workspace/chicago-waistcoat/chicago/4d/renderers/web/transport/standing-horse/horse-sevket-v16-planted-standing-v1.glb')
EXPECTED='b479442cb03ac46eb13c19da15a79cdfaf28dbdf356b116f78de7ce7ecdc60be'
READER=Path('/workspace/shared/HORSE-B479-EYE-UV-APERTURE-SOURCE-INSPECTION-20261023/ACTUAL-CORRECTED-READER.py')
EXPECTED_READER='3f7e06fe4c1e0a91e142e0adc4358a8b277662e9335228269ed5d156e6630729'
digest=lambda b:hashlib.sha256(b).hexdigest()
result={'status':'RUNNING_SOURCE_ONLY','source_sha256':digest(SOURCE.read_bytes()),'asset':str(P),'expected_asset_sha256':EXPECTED,'ray_count_planned':20,'hits':[],'scope':'One finite source-neutral opaque exterior first-hit diagnostic; no render/model edit/photo acceptance'}
try:
 raw=P.read_bytes();result['asset_before_sha256']=digest(raw);assert result['asset_before_sha256']==EXPECTED
 n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);B=raw[28+n:]
 saved=READER.read_bytes();assert digest(saved)==EXPECTED_READER
 text=saved.decode();fragment=text[text.index('fmt='):text.index('eye=[p for p in prims')]
 # Reuse only the pinned original accessor/TRS/normalized-rest-skin decoding and primitive extraction.
 # The earlier UV/ray loops and original report writers are NOT executed.
 exec(compile(fragment,str(READER)+':accessor-rest-primitive-fragment','exec'),globals())
 result['decoder_dependency']={'file':str(READER),'sha256':EXPECTED_READER,'fragment_start':'fmt=','fragment_end_exclusive':'eye=[p for p in prims','fragment_sha256':digest(fragment.encode())}
 eye=[p for p in prims if g['materials'][p['material']]['name']=='Eye_brown'];assert len(eye)==1;eye=eye[0]
 allpoints=[v for p in prims for v in p['points']]
 faces=[]
 for pi,p in enumerate(prims):
  p['raw_positions']=attr(p['attributes']['POSITION'])
  p['raw_normals']=attr(p['attributes']['NORMAL'])
  for at in range(0,len(p['indices']),3):
   ids=tuple(p['indices'][at:at+3]);verts=tuple(p['points'][i]for i in ids)
   faces.append((pi,at//3,ids,verts))
 def intersect(origin,direction,verts):
  a,b,c=verts;e1=sub(b,a);e2=sub(c,a);q=cross(direction,e2);det=dot(e1,q)
  if abs(det)<1e-12:return None
  inv=1/det;s=sub(origin,a);u=dot(s,q)*inv
  if u < -1e-9 or u > 1+1e-9:return None
  q2=cross(s,e1);v=dot(direction,q2)*inv
  if v < -1e-9 or u+v > 1+1e-9:return None
  t=dot(e2,q2)*inv
  return (t,(1-u-v,u,v))if t>1e-8 else None
 result['eye_bounds']={}
 for side,sign in [('positive_X',1),('negative_X',-1)]:
  points=[v for v in eye['points']if sign*v[0]>0];assert points
  center=tuple(sum(p[k]for p in points)/len(points)for k in range(3))
  lower=tuple(min(p[k]for p in points)for k in range(3));upper=tuple(max(p[k]for p in points)for k in range(3))
  offset=.20*min(upper[1]-lower[1],upper[2]-lower[2])
  result['eye_bounds'][side]={'vertex_count':len(points),'center':center,'min':lower,'max':upper,'diagnostic_offset_m':offset,'offset_rule':'20% of smaller native eye Y/Z extent; diagnostic ray layout, no geometry modification'}
  for view,viewer_direction in [('lateral',unit((sign,0,0))),('forward_quarter',unit((sign,0,1)))]:
   horizontal=unit(sub((0,0,1),mul(viewer_direction,dot((0,0,1),viewer_direction))))
   vertical=(0,1,0)
   maximum_projection=max(dot(v,viewer_direction)for v in allpoints)
   for label,shift in [('center',(0,0,0)),('horizontal_plus',mul(horizontal,offset)),('horizontal_minus',mul(horizontal,-offset)),('vertical_plus',mul(vertical,offset)),('vertical_minus',mul(vertical,-offset))]:
    if time.monotonic()-START>110:raise TimeoutError('Finite source inspection110s guard')
    target=add(center,shift);length=maximum_projection-dot(target,viewer_direction)+.05
    origin=add(target,mul(viewer_direction,length));direction=mul(viewer_direction,-1)
    ray={'side':side,'view':view,'sample':label,'target':target,'origin':origin,'direction':direction,'exterior_origin_proof':{'all_source_vertices_max_projection':maximum_projection,'origin_projection':dot(origin,viewer_direction),'clearance_beyond_all_source_vertices_m':dot(origin,viewer_direction)-maximum_projection,'basis':'All source-rest vertices lie inside a projection slab; origin is50mm beyond maximum along viewer direction'},'target_distance_m':length}
    found=[]
    for pi,face_id,ids,verts in faces:
     value=intersect(origin,direction,verts)
     if value:found.append((value[0],pi,face_id,ids,verts,value[1]))
    found.sort(key=lambda x:x[0]);ray['total_positive_intersections']=len(found)
    if found:
     t,pi,face_id,ids,verts,w=found[0];p=prims[pi];mat=g['materials'][p['material']]
     point=tuple(sum(v[k]*b for v,b in zip(verts,w))for k in range(3))
     UV=tuple(sum(p['uv'][i][k]*b for i,b in zip(ids,w))for k in range(2))if p['uv']else None
     normal=unit(cross(sub(verts[1],verts[0]),sub(verts[2],verts[0])))
     ray['first_hit']={'source_primitive_ordinal':pi,'node':p['node'],'mesh':p['mesh'],'primitive':p['primitive'],'material_index':p['material'],'material_name':mat['name'],'material_alphaMode':mat.get('alphaMode','OPAQUE'),'material_doubleSided':mat.get('doubleSided',False),'triangle_id_within_primitive':face_id,'indices_accessor':p['indices_accessor'],'index_triplet':ids,'attribute_accessors':p['attributes'],'distance_from_exterior_origin_m':t,'barycentric':w,'source_rest_position':point,'interpolated_TEXCOORD_0':UV,'geometric_source_rest_normal':normal,'normal_dot_toward_viewer':dot(normal,viewer_direction),'outward_depth_from_eye_center_m':dot(sub(point,center),viewer_direction),'triangle_corner_evidence':[{'vertex':i,'raw_POSITION':p['raw_positions'][i],'source_rest_POSITION':p['points'][i],'raw_NORMAL':p['raw_normals'][i],'TEXCOORD_0':p['uv'][i]if p['uv']else None}for i in ids],'source_texture':mat.get('pbrMetallicRoughness',{}).get('baseColorTexture')}
     # Keep the first few intersections to distinguish outer visible surface from a hidden globe.
     ray['next_intersections']=[{'distance_m':v[0],'source_primitive_ordinal':v[1],'triangle_id':v[2],'material_name':g['materials'][prims[v[1]]['material']]['name']}for v in found[1:4]]
    result['hits'].append(ray)
 assert len(result['hits'])==20
 result['asset_after_sha256']=digest(P.read_bytes());assert result['asset_after_sha256']==EXPECTED
 result['status']='CLOSED_SOURCE_FIRST_HIT_INSPECTION_COMPLETE'
 result['limits']=['Neutral glTF rest/source geometry only; no current animated/GPU/world visibility qualification','Exterior origins are source-model projection proofs, not original saved camera positions','Material and UV identity locate the visible source surface; they do not prove that its tissue is cornea rather than closed eyelid','OPAQUE/doubleSided material assumptions are recorded per actual first hit; no shader overrides or holes','Ray hits preserve exact original primitive/face/vertex/accessor IDs; no automatic ocular patch selection or edits']
except Exception as error:
 result['status']='CLOSED_SOURCE_FIRST_HIT_INSPECTION_FAIL';result['error']=traceback.format_exc();result['asset_after_sha256']=digest(P.read_bytes())
finally:
 result['elapsed_seconds']=time.monotonic()-START
 R=D/'RESULT.json';assert not R.exists();R.write_text(json.dumps(result,indent=2)+'\n')
 receipt={'source_file':str(SOURCE),'source_sha256':digest(SOURCE.read_bytes()),'decoder_source_sha256':EXPECTED_READER,'asset_before_sha256':result.get('asset_before_sha256'),'asset_after_sha256':result.get('asset_after_sha256'),'status':result['status'],'elapsed_seconds':result['elapsed_seconds'],'result_sha256':digest(R.read_bytes()),'ray_count_completed':len(result['hits'])}
 (D/'ACTUAL-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'receipt':receipt,'hits':[{'side':v['side'],'view':v['view'],'sample':v['sample'],'first_hit':{k:v.get('first_hit',{}).get(k)for k in ['material_name','triangle_id_within_primitive','index_triplet','barycentric','interpolated_TEXCOORD_0','source_rest_position','geometric_source_rest_normal','outward_depth_from_eye_center_m']}}for v in result['hits']]},indent=2))
 if result['status'].endswith('_FAIL'):raise SystemExit(1)
