'use strict';
// ONE released readback only. No app server, remote requests, or renderer.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto');
const D=__dirname,need=(v,m)=>{if(!v)throw Error(m)},sha=b=>crypto.createHash('sha256').update(b).digest('hex');
need(process.argv.length===3,'Explicit external ROOT release path required');
const release=JSON.parse(fs.readFileSync(process.argv[2]));
need(release.released===true&&release.authorization==='ONE_ROOT_AUTHORIZED_V16_LOADED129_READBACK','Held until ROOT release');
const verify=pin=>{const b=fs.readFileSync(pin.path);need(b.length===pin.bytes&&sha(b)===pin.sha256,'Pinned input/source mismatch '+pin.path);return b;};
for(const pin of Object.values(release.source))verify(pin);
need(release.source.caller.path===__filename,'Actual caller pin');
const routes=new Map(),config={inputs:{}};
for(const[role,pin]of Object.entries(release.inputs)){const url='/input/'+role;routes.set(url,{bytes:verify(pin),type:role==='original'||role==='candidate'?'model/gltf-binary':'application/json'});config.inputs[role]={url,bytes:pin.bytes,sha256:pin.sha256};}
for(const[route,pin]of Object.entries(release.vendor))routes.set(route,{bytes:verify(pin),type:'text/javascript'});
// Materialize only immutable accepted Dirichlet declarations, never a new field.
const {spawnSync}=require('node:child_process');
const fixture=spawnSync('/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python',[path.join(D,'extract_known_reference.py'),process.argv[2]],{encoding:null,timeout:2000,maxBuffer:4*1024*1024,env:{...process.env,OMP_NUM_THREADS:'1',OPENBLAS_NUM_THREADS:'1',MKL_NUM_THREADS:'1'}});
need(fixture.status===0&&!fixture.error,'Accepted PhaseA declaration extraction failed '+String(fixture.stderr));
const fixtureJSON=JSON.parse(fixture.stdout);
need(fixtureJSON.phase_a_arrays_sha256===release.inputs.phase_a_arrays.sha256,'Exact accepted fixture source');
routes.set('/input/accepted_known',{bytes:fixture.stdout,type:'application/json'});
config.inputs.accepted_known={url:'/input/accepted_known',bytes:fixture.stdout.length,sha256:sha(fixture.stdout)};
routes.set('/CONFIG.json',{bytes:Buffer.from(JSON.stringify(config)),type:'application/json'});
routes.set('/',{bytes:verify(release.source.html),type:'text/html'});
routes.set('/readback.mjs',{bytes:verify(release.source.module),type:'text/javascript'});
const out=path.resolve(release.output_directory);need(!fs.existsSync(out),'No overwrite/retry');fs.mkdirSync(out);
fs.writeFileSync(path.join(out,'ACCEPTED-PHASEA-KNOWN-REFERENCE.json'),fixture.stdout);
const lines=[],fatal=[];let browser,server,timer,origin,result;
const start=performance.now(),write=(name,x)=>fs.writeFileSync(path.join(out,name),JSON.stringify(x,null,2)+'\n');
async function main(){
 try{
  const {chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
  server=http.createServer((req,res)=>{const key=new URL(req.url,'http://127.0.0.1').pathname;if(key==='/favicon.ico'){res.writeHead(204);return res.end();}const r=routes.get(key);if(!r){fatal.push({type:'unlisted_http',url:req.url});res.writeHead(404);return res.end();}res.writeHead(200,{'Content-Type':r.type,'Content-Length':r.bytes.length,'Cache-Control':'no-store'});res.end(r.bytes);});
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});origin='http://127.0.0.1:'+server.address().port;
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-gpu'],timeout:8000});
  const page=await browser.newPage({viewport:{width:800,height:600}});
  page.on('console',msg=>{const row={type:msg.type(),text:msg.text()};lines.push(row);fs.appendFileSync(path.join(out,'console.jsonl'),JSON.stringify(row)+'\n');if(msg.type()==='error')fatal.push(row);});
  page.on('pageerror',error=>fatal.push({type:'pageerror',message:error.message,stack:error.stack}));
  page.on('requestfailed',request=>fatal.push({type:'requestfailed',url:request.url(),failure:request.failure()}));
  page.on('response',response=>{if(response.status()>=400)fatal.push({type:'http_error',url:response.url(),status:response.status()});});
  await page.route('**/*',route=>{const u=route.request().url();if(u.startsWith(origin+'/')||u.startsWith('blob:')||u.startsWith('data:'))return route.continue();fatal.push({type:'remote_request_blocked',url:u});return route.abort();});
  const work=(async()=>{await page.goto(origin+'/',{waitUntil:'load',timeout:10000});await page.waitForFunction(()=>window.ready===true,null,{timeout:10000});return await page.evaluate(()=>window.compare());})();
  const deadline=new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Owned 25-second work deadline; no retry')),Math.max(1,25000-(performance.now()-start)));});
  result=await Promise.race([work,deadline]);
 }catch(error){result={status:'LOADED_STANDING129_CALLER_FAIL_NO_RETRY',error:{message:error.message,stack:error.stack}};}
 finally{
  clearTimeout(timer);
  if(browser)await browser.close().catch(error=>fatal.push({type:'browser_close_error',message:error.message}));
  if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
  try{for(const group of['inputs','source','vendor'])for(const pin of Object.values(release[group]))verify(pin);}catch(error){fatal.push({type:'changed_pinned_file',message:error.message});}
  write('STANDING129-RESULT.json',result??{status:'NO_RESULT'});
  const terminal={status:result?.status==='LOADED_STANDING65_KEYS64_MIDPOINTS_PASS_ONLY'&&fatal.length===0?'LOADED_STANDING129_PASS_ONLY':'LOADED_STANDING129_FAIL_NO_RETRY',result_status:result?.status,elapsed_seconds:(performance.now()-start)/1000,fatal,inputs_unchanged:fatal.every(x=>x.type!=='changed_pinned_file'),fields:0,solvers:0,exports:0,renderers:0,browser_closed:browser?!browser.isConnected():true,server_closed:!server?.listening,walking_enabled:false,app_intake:false};
  write('CALLER-TERMINAL.json',terminal);console.log(JSON.stringify(terminal));process.exitCode=terminal.status==='LOADED_STANDING129_PASS_ONLY'?0:1;
 }
}
main().catch(error=>{console.error(error);process.exitCode=1;});
