"""Copy accepted PhaseA Dirichlet declarations; not a field, pose or new solve."""
from pathlib import Path
import hashlib,json,sys
assert len(sys.argv)==2 and sys.version_info[:3]==(3,11,17)
release=json.loads(Path(sys.argv[1]).read_text())
assert release['released'] is True and release['authorization']=='ONE_ROOT_AUTHORIZED_V16_LOADED129_READBACK'
for group in ['inputs','source']:
 for pin in release[group].values():
  raw=Path(pin['path']).read_bytes()
  assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],pin['path']
# Numerical arrays are read only after explicit released binding checks.
import numpy as np
pin=release['inputs']['phase_a_arrays']
with np.load(pin['path'],allow_pickle=False) as f:
 ids=f['declared_known_class_ids'];vectors=f['declared_known_vectors'];protected=f['source_protected_class_ids'];vc=f['vertex_classes_0']
 assert vectors.dtype==np.float64 and vectors.shape==(len(ids),26)
 reference=json.loads(Path(release['inputs']['cpu_reference']['path']).read_text())
 tail_classes=set(int(i) for i in vc[reference['tail_vertex_ids']])
 assert len(tail_classes)==901 and len(protected)==6506
 selected=set(int(i) for i in protected)-tail_classes
 assert selected.issubset(set(int(i) for i in ids))
 # Same original V14 packing definition: positive authored f64 palette,
 # ascending joint index, exactly one f32 cast; no normalization here.
 cast=vectors.astype('<f4');rows=[]
 for ci,row,row32 in zip(ids,vectors,cast):
  if int(ci) not in selected:continue
  palette=np.flatnonzero(row>0);assert len(palette)<=4
  joints=np.zeros(4,dtype=np.uint16);weights=np.zeros(4,dtype='<f4')
  joints[:len(palette)]=palette;weights[:len(palette)]=row32[palette]
  rows.append({'class_id':int(ci),'joints':joints.tolist(),'weights':weights.tolist()})
 assert len(rows)==len(selected)==5605
 result={'schema':'accepted_phase_a_known_declarations_not_new_field_v1','phase_a_arrays_sha256':pin['sha256'],'declared_known_ids_dtype':ids.dtype.str,'declared_known_ids_shape':list(ids.shape),'declared_known_ids_raw_sha256':hashlib.sha256(ids.tobytes()).hexdigest(),'declared_known_vectors_dtype':vectors.dtype.str,'declared_known_vectors_shape':list(vectors.shape),'declared_known_vectors_raw_sha256':hashlib.sha256(vectors.tobytes()).hexdigest(),'declared_known_vectors_once_f32_sha256':hashlib.sha256(cast.tobytes()).hexdigest(),'protected_classes':6506,'tail_classes_excluded':901,'protected_non_tail_classes':len(rows),'derivation':'Immutable PhaseA declared_known_vectors; original V14 ascending positive-f64 palette, one f32 cast, zero pad to4; no new normalization/field/pose. Tail retains raw03a1 slots/bits instead.','rows':rows}
 print(json.dumps(result,separators=(',',':')))
