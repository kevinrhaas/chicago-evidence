# SPDX-License-Identifier: CC0-1.0
"""Linux-only owned-descendant cleanup, including detached Playwright Chromium.

This process becomes a child subreaper and starts exactly one owned child. PID and
start-time pairs prevent signaling reused PIDs. Other agents' browser processes
are outside this ancestry and are never targeted. No browser is launched here.
"""
import ctypes, hashlib, json, os, pathlib, signal, subprocess, sys, time

def read_process(pid):
 try:
  data=(pathlib.Path('/proc')/str(pid)/'stat').read_text();tail=data.rsplit(')',1)[1].split()
  return {'pid':int(pid),'state':tail[0],'ppid':int(tail[1]),'pgid':int(tail[2]),'start_time_ticks':int(tail[19]),'rss_bytes':int(tail[21])*os.sysconf('SC_PAGE_SIZE')}
 except (OSError,ValueError,IndexError):return None

def process_records():
 records={}
 for path in pathlib.Path('/proc').iterdir():
  if path.name.isdigit():
   record=read_process(int(path.name))
   if record:records[record['pid']]=record
 return records

def owned_descendants(owner):
 records=process_records();owned=set();parents={owner}
 while parents:
  children={pid for pid,record in records.items() if record['ppid'] in parents and pid not in owned}
  owned.update(children);parents=children
 return [records[pid] for pid in sorted(owned)]

def matching_signal(record,sig):
 current=read_process(record['pid'])
 if not current or current['start_time_ticks']!=record['start_time_ticks']:return False
 try:os.kill(record['pid'],sig);return True
 except ProcessLookupError:return False

def reap_adopted():
 result=[]
 while True:
  try:pid,status=os.waitpid(-1,os.WNOHANG)
  except ChildProcessError:break
  if pid==0:break
  result.append({'pid':pid,'status':status})
 return result

def run_owned(command,logdir,whole_timeout=30,execution_timeout=26):
 logdir=pathlib.Path(logdir);logdir.mkdir()
 libc=ctypes.CDLL(None,use_errno=True)
 if libc.prctl(36,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'PR_SET_CHILD_SUBREAPER failed; browser not launched')
 owner=os.getpid();started=time.monotonic()
 report={'status':'RUNNING','command':command,'whole_deadline_seconds':whole_timeout,'execution_timeout_seconds':execution_timeout,'supervisor_pid':owner,'subreaper_enabled':True,'ownership':'only descendants of this supervisor, including detached Chromium adopted as child subreaper; PID start-time identity checked','cleanup_signals':[],'summed_owned_rss_limit_bytes':1073741824,'peak_summed_owned_rss_bytes':0}
 oldterm=signal.getsignal(signal.SIGTERM)
 def interrupted(signum,frame):raise KeyboardInterrupt('Supervisor interrupted')
 signal.signal(signal.SIGTERM,interrupted)
 child=None
 try:
  with (logdir/'capture.stdout').open('wb') as stdout,(logdir/'capture.stderr').open('wb') as stderr:
   child=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1'})
   report['owned_node_pid']=child.pid;report['owned_node_pgid']=child.pid
   try:
    while child.poll() is None:
     records=owned_descendants(owner);rss=sum(r['rss_bytes'] for r in records)
     report['peak_summed_owned_rss_bytes']=max(report['peak_summed_owned_rss_bytes'],rss)
     if rss>report['summed_owned_rss_limit_bytes']:
      report['status']='OWNED_RSS_LIMIT';report['exit_code']=137;break
     if time.monotonic()-started>=execution_timeout:
      raise subprocess.TimeoutExpired(command,execution_timeout)
     time.sleep(.025)
    else:report['status']='TERMINAL';report['exit_code']=child.returncode
   except subprocess.TimeoutExpired:report['status']='TIMEOUT';report['exit_code']=124
   except BaseException as exc:report['status']='INTERRUPTED';report['exit_code']=130;report['interruption']=repr(exc)
   finally:
    report['cleanup_initial_descendants']=owned_descendants(owner)
    term_deadline=min(started+whole_timeout-2,time.monotonic()+2)
    while True:
     descendants=owned_descendants(owner);active=[r for r in descendants if r['state']!='Z']
     if not active:break
     for record in reversed(active):
      if matching_signal(record,signal.SIGTERM):report['cleanup_signals'].append({'signal':'SIGTERM',**record})
     if child.poll() is not None:report.setdefault('reaped_adopted_children',[]).extend(reap_adopted())
     if time.monotonic()>=term_deadline:break
     time.sleep(.05)
    for record in reversed(owned_descendants(owner)):
     if record['state']!='Z' and matching_signal(record,signal.SIGKILL):report['cleanup_signals'].append({'signal':'SIGKILL',**record})
    try:child.wait(timeout=max(.05,started+whole_timeout-time.monotonic()))
    except subprocess.TimeoutExpired:report['owned_node_wait_timeout']=True
    if child.poll() is not None:report.setdefault('reaped_adopted_children',[]).extend(reap_adopted())
    report['remaining_owned_descendants']=owned_descendants(owner)
    report['remaining_owned_active_pids']=[r for r in report['remaining_owned_descendants'] if r['state']!='Z']
    if report['remaining_owned_descendants']:report['status']='FAILED owned cleanup';report['exit_code']=125
 except BaseException as exc:
  report['status']='FAILED supervisor/launch';report['exit_code']=1;report['error']=repr(exc)
 finally:
  signal.signal(signal.SIGTERM,oldterm)
  report['elapsed_seconds']=time.monotonic()-started
  (logdir/'terminal.json').write_text(json.dumps(report,indent=2)+'\n')
 return report


def main():
 D=pathlib.Path(__file__).parent
 assert len(sys.argv)==2,'Explicit external ROOT release path required'
 assert sys.version_info[:3]==(3,11,17),'Approved Python3.11.17 only'
 release_path=pathlib.Path(sys.argv[1]).resolve()
 release=json.loads(release_path.read_text())
 assert release['released'] is True and release['authorization']=='ONE_ROOT_AUTHORIZED_V16_LOADED129_READBACK','Held until explicit ROOT release'
 assert release['whole_seconds']==30 and release['owned_summed_rss_bytes']==1073741824
 for group in ['source','inputs','vendor','runtime']:
  for pin in release[group].values():
   raw=pathlib.Path(pin['path']).read_bytes()
   assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],pin['path']
 assert pathlib.Path(release['source']['supervisor']['path']).resolve()==pathlib.Path(__file__).resolve()
 assert pathlib.Path(release['source']['caller']['path']).parent==D
 os.nice(19)
 result=run_owned(['node',str(D/'run.cjs'),str(release_path)],release['owner_directory'])
 print(json.dumps(result,indent=2))
 return result.get('exit_code',1)

if __name__=='__main__':raise SystemExit(main())
