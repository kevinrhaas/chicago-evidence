// Source-only standalone loader/Mixer proof; no renderer or app injection.

import * as T from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
const need=(x,message)=>{if(!x)throw Error(message);};
const get=(a,i,k)=>k===0?a.getX(i):k===1?a.getY(i):k===2?a.getZ(i):a.getW(i);
const bytesEqual=(a,b)=>a.byteLength===b.byteLength&&new Uint8Array(a.buffer,a.byteOffset,a.byteLength).every((v,i)=>v===new Uint8Array(b.buffer,b.byteOffset,b.byteLength)[i]);
const pixelHashes=new WeakMap();
async function textureInfo(texture){
 if(!texture)return null;
 const image=texture.image;need(image&&image.width&&image.height,'actual decoded map image unavailable');
 let pixel_sha256=pixelHashes.get(image);
 if(!pixel_sha256){const canvas=new OffscreenCanvas(image.width,image.height),ctx=canvas.getContext('2d');ctx.drawImage(image,0,0);const pixels=ctx.getImageData(0,0,image.width,image.height).data;pixel_sha256=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',pixels)),v=>v.toString(16).padStart(2,'0')).join('');pixelHashes.set(image,pixel_sha256);}
 return{width:image.width,height:image.height,pixel_sha256,colorSpace:texture.colorSpace,flipY:texture.flipY,channel:texture.channel,wrapS:texture.wrapS,wrapT:texture.wrapT,minFilter:texture.minFilter,magFilter:texture.magFilter,offset:texture.offset.toArray(),repeat:texture.repeat.toArray(),rotation:texture.rotation};
}
async function maps(model){const rows=[];for(const m of model.meshes){const slots=[];for(const material of[].concat(m.material)){const textures={};for(const key of['map','normalMap','roughnessMap','metalnessMap','aoMap','emissiveMap','alphaMap','bumpMap','lightMap'])textures[key]=await textureInfo(material[key]);slots.push({name:material.name,type:material.type,color:material.color?.toArray(),side:material.side,roughness:material.roughness,metalness:material.metalness,opacity:material.opacity,alphaTest:material.alphaTest,transparent:material.transparent,normalScale:material.normalScale?.toArray(),textures});}rows.push({mesh_key:m.userData.parityKey,materials:slots});}return rows;}
async function load(url,raw){
 const loader=new GLTFLoader(),gltf=await loader.parseAsync(raw,location.origin+'/'),meshes=[];
 gltf.scene.traverse(o=>{if(o.isSkinnedMesh){const a=gltf.parser.associations.get(o);need(a&&Number.isInteger(a.meshes)&&Number.isInteger(a.primitives),'actual parser mesh correspondence missing');o.userData.parityKey=a.meshes+':'+a.primitives;meshes.push(o);}});
 meshes.sort((a,b)=>a.userData.parityKey.localeCompare(b.userData.parityKey));need(meshes.length===3&&new Set(meshes.map(m=>m.userData.parityKey)).size===3,'three unique original mesh primitives required');
 const bind=[];gltf.scene.traverse(o=>bind.push([o,o.position.clone(),o.quaternion.clone(),o.scale.clone()]));return{...gltf,meshes,bind,mixer:new T.AnimationMixer(gltf.scene)};
}
function pose(model,clip,time){model.mixer.stopAllAction();for(const[o,p,q,s]of model.bind){o.position.copy(p);o.quaternion.copy(q);o.scale.copy(s);}if(clip!==null){const action=model.mixer.clipAction(model.animations[clip]);action.reset();action.setLoop(T.LoopOnce,1);action.clampWhenFinished=true;action.play();model.mixer.setTime(time);}model.scene.updateMatrixWorld(true);for(const m of model.meshes)m.skeleton.update();}
function cache(mesh){
 const g=mesh.geometry,position=g.attributes.position,normal=g.attributes.normal,skinIndex=g.attributes.skinIndex,skinWeight=g.attributes.skinWeight,index=g.index;
 need(position&&normal&&skinIndex&&skinWeight&&index,'indexed normal/skinned geometry required');need(!Object.values(g.morphAttributes).some(a=>a.length),'morphs require separate explicit handling');
 const ids=Array.from({length:position.count},(_,i)=>i),j=new Uint32Array(position.count*4),w=new Float64Array(position.count*4),bn=new Float64Array(position.count*3),B=mesh.bindMatrix.elements;let zeroOut=0;
 for(const i of ids){need(i>=0&&i<position.count,'index outside position buffer');const x=normal.getX(i),y=normal.getY(i),z=normal.getZ(i);bn.set([B[0]*x+B[4]*y+B[8]*z,B[1]*x+B[5]*y+B[9]*z,B[2]*x+B[6]*y+B[10]*z],i*3);for(let k=0;k<4;k++){j[i*4+k]=get(skinIndex,i,k);w[i*4+k]=get(skinWeight,i,k);if(w[i*4+k]!==0)need(j[i*4+k]<mesh.skeleton.bones.length,'positive weight outside actual bone palette');else if(j[i*4+k]>=mesh.skeleton.bones.length)zeroOut++;}}
 return{mesh,position,normal,index,ids,j,w,bn,zero_weight_out_of_palette_components:zeroOut};
}
function normalContext(c){
 const m=c.mesh,b=m.skeleton.boneMatrices;for(let i=0;i<b.length;i+=16)need(b[i+3]===0&&b[i+7]===0&&b[i+11]===0&&b[i+15]===1,'nonaffine bone matrices unsupported');
 // Exact affine factorization of ShaderChunk.skinnormal_vertex and
 // defaultnormal_vertex with identity view: normalMatrix(world) * B^-1 *
 // [sum(w_j * actual GPU boneMatrix_j)] * B * vec4(normal,0).
 // Deliberately no inverse transpose of the weighted bone blend.
 return{b,prefix:new T.Matrix3().getNormalMatrix(m.matrixWorld).multiply(new T.Matrix3().setFromMatrix4(m.bindMatrixInverse))};
}
function shaderNormal(c,frame,i,out){const q=i*3,bx=c.bn[q],by=c.bn[q+1],bz=c.bn[q+2],b=frame.b;let x=0,y=0,z=0;for(let k=0;k<4;k++){const w=c.w[i*4+k];if(w===0)continue;const o=c.j[i*4+k]*16;x+=w*(b[o]*bx+b[o+4]*by+b[o+8]*bz);y+=w*(b[o+1]*bx+b[o+5]*by+b[o+9]*bz);z+=w*(b[o+2]*bx+b[o+6]*by+b[o+10]*bz);}out.set(x,y,z).applyMatrix3(frame.prefix);need(Number.isFinite(out.lengthSq())&&out.lengthSq()>1e-24,'degenerate/nonfinite shader normal');return out.normalize();}

const digest=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');
async function pinned(pin){const r=await fetch(pin.url,{cache:'no-cache'});need(r.ok,'Actual proof resource HTTP '+pin.url);const b=await r.arrayBuffer();need(b.byteLength===pin.bytes&&await digest(b)===pin.sha256,'Actual proof bytes '+pin.url);return b;}
const json=bytes=>JSON.parse(new TextDecoder().decode(bytes));
function glb(raw){const v=new DataView(raw),n=v.getUint32(12,true);need(v.getUint32(0,true)===0x46546c67&&v.getUint32(4,true)===2&&v.getUint32(8,true)===raw.byteLength&&v.getUint32(16,true)===0x4e4f534a,'GLB header');return{doc:json(raw.slice(20,20+n)),bin:new Uint8Array(raw,28+n)};}
function rawAttribute(g,mi,name){const a=g.doc.accessors[g.doc.meshes[mi].primitives[0].attributes[name]],v=g.doc.bufferViews[a.bufferView],C=a.componentType===5123?Uint16Array:a.componentType===5126?Float32Array:null;need(C&&!v.byteStride&&!a.sparse&&!a.normalized,'Direct source-bound raw accessor');return new C(g.bin.buffer,g.bin.byteOffset+(v.byteOffset??0)+(a.byteOffset??0),a.count*(a.type==='VEC3'?3:4)).slice();}
const rint=x=>{const f=Math.floor(x),d=x-f;return d===.5?(f%2===0?f:f+1):Math.round(x);};
const distance=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2]);
const sub=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]];
const cross3=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const dot3=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
const norm3=a=>Math.hypot(...a);
const xyz=(a,i)=>[a[i*3],a[i*3+1],a[i*3+2]];
function expectedBones(world,inverses){const b=new Float64Array(26*16);for(let i=0;i<26;i++)new T.Matrix4().set(...world[i].flat()).multiply(inverses[i]).toArray(b,i*16);return b;}
function affineSkin(c,b,i,out){const x=c.position.getX(i),y=c.position.getY(i),z=c.position.getZ(i);let px=0,py=0,pz=0;for(let k=0;k<4;k++){const w=c.w[i*4+k];if(!w)continue;const o=c.j[i*4+k]*16;px+=w*(b[o]*x+b[o+4]*y+b[o+8]*z+b[o+12]);py+=w*(b[o+1]*x+b[o+5]*y+b[o+9]*z+b[o+13]);pz+=w*(b[o+2]*x+b[o+6]*y+b[o+10]*z+b[o+14]);}return out.set(px,py,pz);}
function identity(matrix){const a=matrix.elements,b=new T.Matrix4().elements;return a.every((v,i)=>Math.abs(v-b[i])<=1e-12);}
function denseAt(c,i){const a=new Float64Array(26);for(let k=0;k<4;k++)a[c.j[i*4+k]]+=c.w[i*4+k];return a;}
function chainErrors(nodes,pivots,limbs){let length=0,parent=0;for(const row of Object.values(limbs))for(let k=0;k<4;k++){const a=row.joints[k],b=row.joints[k+1],pa=new T.Vector3().setFromMatrixPosition(nodes[a].matrixWorld),pb=new T.Vector3().setFromMatrixPosition(nodes[b].matrixWorld),offset=new T.Vector3().fromArray(sub(pivots[b],pivots[a]));length=Math.max(length,Math.abs(pa.distanceTo(pb)-offset.length()));const expected=offset.clone().applyMatrix4(nodes[a].matrixWorld);parent=Math.max(parent,expected.distanceTo(pb));}return{length,parent};}
function maxContact(moved,rest,patches){let worst={gap:0};for(const[label,ids]of Object.entries(patches))for(const i of ids){const gap=distance(xyz(moved[1],i),rest[1][i]);if(gap>worst.gap)worst={gap,label,vertex:i,actual:xyz(moved[1],i),expected:rest[1][i]};}return worst;}

window.compare=async()=>{
 const started=performance.now(),config=await(await fetch('/CONFIG.json')).json();let source,candidate;
 const report=window.cpuReport={status:'LOADED_STANDING129_INCOMPLETE',key_count:0,midpoint_count:0,poses:[],normalization:[],failures:[],positions:{tolerance_m:1e-5,maximum_delta_m:0,evaluations:0},normals:{tolerance_degrees:.01,maximum_angle_degrees:0,evaluations:0},joint_world:{maximum_translation_error_m:0,maximum_matrix_component_error:0},physical:{maximum_segment_length_error_m:0,maximum_parent_residual_m:0,maximum_seam_gap_m:0,maximum_contact_error_m:0},WebGL_contexts_created:0,renderers_created:0,walking_enabled:false,head_tail_composed:false};
 const fail=(condition,label,witness)=>{if(!condition&&report.failures.length<100)report.failures.push({label,witness});};
 try{
  need(T.REVISION==='185','Actual project Three revision');
  need(T.ShaderChunk.skinnormal_vertex.includes('skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;')&&T.ShaderChunk.defaultnormal_vertex.includes('transformedNormal = normalMatrix * transformedNormal;'),'Native shader normal algebra');
  report.shader_normal_algebra='normalMatrix(meshWorld) * bindInverse * weighted Float32 boneMatrices * bind * normal; no inverse-transpose of weighted blend';
  const entries=await Promise.all(Object.entries(config.inputs).map(async([k,p])=>[k,await pinned(p)])),resources=Object.fromEntries(entries);
  const knownReference=json(resources.accepted_known);need(knownReference.phase_a_arrays_sha256===config.inputs.phase_a_arrays.sha256&&knownReference.protected_non_tail_classes===5605,'Accepted PhaseA declaration lineage');const knownRows=new Map(knownReference.rows.map(r=>[r.class_id,r]));report.protected_baseline={source:'accepted PhaseA declared_known_vectors, one f32 cast; original raw-tail separate',phase_a_arrays_sha256:knownReference.phase_a_arrays_sha256,known_vectors_raw_sha256:knownReference.declared_known_vectors_raw_sha256,known_vectors_once_f32_sha256:knownReference.declared_known_vectors_once_f32_sha256};
  const receipt=json(resources.export_receipt),reference=json(resources.cpu_reference),frames=json(resources.accepted_matrices).frames,controls=json(resources.controls26),limit=json(resources.limits);
  need(receipt.output_sha256===config.inputs.candidate.sha256&&receipt.field_sha256==='04df599158ea091eb6d0036d3aeab9159ee96b8dfd43524a17ff874d72492e2d','Actual exported lineage');
  need(frames.length===65&&frames[0].time_s===0&&frames[64].time_s===12,'Actual accepted65 timeline');
  const originalRaw=glb(resources.original),candidateRaw=glb(resources.candidate);
  const raw=[],rawSource=[];
  for(let mi=0;mi<3;mi++){raw.push({j:rawAttribute(candidateRaw,mi,'JOINTS_0'),w:rawAttribute(candidateRaw,mi,'WEIGHTS_0')});rawSource.push({j:rawAttribute(originalRaw,mi,'JOINTS_0'),w:rawAttribute(originalRaw,mi,'WEIGHTS_0')});for(const semantic of['JOINTS_0','WEIGHTS_0']){const r=receipt.accepted_field_bytes_exact.find(x=>x.mesh===mi&&x.semantic===semantic);need(r,'Explicit field range');const bytes=candidateRaw.bin.slice(r.byte_offset,r.byte_offset+r.bytes);need(await digest(bytes)===r.sha256,'Actual serialized V16 field range');}}
  const allowed=receipt.accepted_field_bytes_exact.map(x=>[x.byte_offset,x.byte_offset+x.bytes]).sort((a,b)=>a[0]-b[0]);let cursor=0;for(const[a,b]of allowed){need(bytesEqual(originalRaw.bin.subarray(cursor,a),candidateRaw.bin.subarray(cursor,a)),'Original nonweight BIN bytes');cursor=b;}need(bytesEqual(originalRaw.bin.subarray(cursor),candidateRaw.bin.subarray(cursor,originalRaw.bin.length)),'Original final BIN bytes');
  for(const semantic of['JOINTS_0','WEIGHTS_0']){const originalTail=rawAttribute(originalRaw,0,semantic),derivedTail=semantic==='JOINTS_0'?raw[0].j:raw[0].w;for(const i of reference.tail_vertex_ids)need(bytesEqual(originalTail.subarray(i*4,i*4+4),derivedTail.subarray(i*4,i*4+4)),'Original serialized tail byte identity');}
  [source,candidate]=await Promise.all([load(config.inputs.original.url,resources.original),load(config.inputs.candidate.url,resources.candidate)]);
  need(source.animations.length===0&&candidate.animations.length===1&&candidate.animations[0].name===receipt.animation&&candidate.animations[0].duration===12&&candidate.animations[0].tracks.length===13,'Only actual13track standing clip');
  for(const track of candidate.animations[0].tracks){need(track.getInterpolation()===T.InterpolateLinear&&track.times.length===65&&track.times.every((t,i)=>t===frames[i].time_s),'Actual imported65 linear key streams');}
  pose(source,null,null);pose(candidate,0,0);
  const [sourceMaps,candidateMaps]=await Promise.all([maps(source),maps(candidate)]);need(JSON.stringify(sourceMaps)===JSON.stringify(candidateMaps),'Actual decoded image/material equality');report.decoded_maps_equal=true;
  const sc=source.meshes.map(cache),cc=candidate.meshes.map(cache),rc=cc.map((c,i)=>({...c,j:raw[i].j,w:raw[i].w}));
  const nodes=await Promise.all(Array.from({length:26},(_,i)=>candidate.parser.getDependency('node',i)));
  for(let i=0;i<26;i++){need(candidate.meshes.every(m=>m.skeleton.bones[i]===nodes[i]),'Actual shared joint/node identity');const p=controls.nodes[i].parent_index;if(p!==null)need(nodes[i].parent===nodes[p],'Actual parentchain');}
  const tailClasses=new Set(reference.tail_vertex_ids.map(i=>reference.vertex_classes[0][i]));need(tailClasses.size===901,'Original901 tail classes');const protectedSet=new Set(reference.source_protected_classes);need(protectedSet.size===6506&&reference.tail_vertex_ids.length===969,'Original protected/tail inventory');report.protected_source_classes=protectedSet.size;report.tail_vertices=reference.tail_vertex_ids.length;const rest=reference.rest_points_per_mesh,pivots=frames[0].global_canonical_matrices.map(m=>[m[0][3],m[1][3],m[2][3]]);
  for(let mi=0;mi<3;mi++){
   const a=sc[mi],b=cc[mi];need(a.position.count===b.position.count&&a.position.count===rest[mi].length&&bytesEqual(a.index.array,b.index.array),'Actual indexed geometry inventory');
   for(const key of Object.keys(a.mesh.geometry.attributes).filter(k=>!['skinIndex','skinWeight'].includes(k)))need(bytesEqual(a.mesh.geometry.attributes[key].array,b.mesh.geometry.attributes[key].array),'Geometry/normal/UV exact '+key);
   need(identity(b.mesh.matrixWorld)&&identity(b.mesh.bindMatrix)&&identity(b.mesh.bindMatrixInverse),'Canonical identity mesh/bind basis');
   for(let j=0;j<26;j++)need(a.mesh.skeleton.boneInverses[j].elements.every((v,k)=>v===b.mesh.skeleton.boneInverses[j].elements[k]),'Original inverse binds');
   let rows=0,components=0,max=0,originalLoadedDifferences=0,protectedRows=0;for(let i=0;i<b.position.count;i++){let changed=false;for(let k=0;k<4;k++){const delta=Math.abs(b.w[i*4+k]-raw[mi].w[i*4+k]);max=Math.max(max,delta);if(delta){changed=true;components++;}}rows+=+changed;const ci=reference.vertex_classes[mi][i];if(protectedSet.has(ci)&&!tailClasses.has(ci)){
    const known=knownRows.get(ci);need(known,'Every protected non-tail class has accepted fixture');
    const expected=denseAt({j:known.joints,w:known.weights},0),actual=denseAt(raw[mi],i);need(expected.every((v,j)=>Object.is(v,actual[j])),'Serialized accepted PhaseA protected semantic-vector bits');
    // Independent reproduction of standard normalizeSkinWeights on expected
    // accepted4slots, including its actual Float32BufferAttribute write.
    const w=known.weights,scale=1/(Math.abs(w[0])+Math.abs(w[1])+Math.abs(w[2])+Math.abs(w[3]));need(Number.isFinite(scale),'Finite positive accepted protected mass');
    for(let k=0;k<4;k++)need(b.j[i*4+k]===known.joints[k]&&Object.is(b.w[i*4+k],Math.fround(w[k]*scale)),'Loaded accepted PhaseA protected normalization');
    const x=denseAt(a,i),y=denseAt(b,i);originalLoadedDifferences+=+!x.every((v,j)=>Object.is(v,y[j]));protectedRows++;
   }}
   report.normalization.push({mesh:mi,changed_rows:rows,changed_components:components,maximum_delta:max,protected_compared_to_accepted_phase_a:true,protected_non_tail_rows:protectedRows,original_standard_loader_vector_differences_measured_only:originalLoadedDifferences});
  }
  for(const i of reference.tail_vertex_ids)for(let k=0;k<4;k++)need(sc[0].j[i*4+k]===cc[0].j[i*4+k]&&Object.is(sc[0].w[i*4+k],cc[0].w[i*4+k]),'Same-loader original tail slots/bits');
  const patches={};for(const[label,row]of Object.entries(reference.contacts))patches[label]=[...new Set(row.source_triangle_ids.flatMap(t=>[cc[1].index.getX(3*t),cc[1].index.getX(3*t+1),cc[1].index.getX(3*t+2)]))].sort((a,b)=>a-b);
  need(Object.keys(patches).length===4&&Object.entries({fore_l:59,fore_r:59,hind_l:13,hind_r:10}).every(([k,n])=>patches[k]?.length===n),'Original four complete patches');
  const seams=new Map();for(let mi=0;mi<3;mi++)for(let i=0;i<rest[mi].length;i++){const key=rest[mi][i].map(v=>rint(v/1e-6)).join(',');if(!seams.has(key))seams.set(key,[]);seams.get(key).push([mi,i]);}const seamPairs=[...seams.values()].flatMap(v=>v.slice(1).map(p=>[v[0],p]));
  const base=cc.map((c,mi)=>Array.from({length:c.index.count/3},(_,t)=>{const ids=[0,1,2].map(k=>c.index.getX(t*3+k)),p=ids.map(i=>rest[mi][i]),n=cross3(sub(p[1],p[0]),sub(p[2],p[0]));return{ids,edges:[distance(p[1],p[0]),distance(p[2],p[1]),distance(p[0],p[2])],normal:n,area:norm3(n)};}));
  const timeline=frames.flatMap((f,i)=>i===64?[{time:f.time_s,key:i}]:[{time:f.time_s,key:i},{time:(f.time_s+frames[i+1].time_s)/2,key:null}]);need(timeline.length===129,'65keys+64midpoints');
  let firstNodes=null,firstPoints=null,neutralResidual=0;
  const p=new T.Vector3(),q=new T.Vector3(),e=new T.Vector3(),actualNormal=new T.Vector3(),expectedNormal=new T.Vector3(),cross=new T.Vector3();
  for(const sample of timeline){
   pose(candidate,0,sample.time);const actualWorld=nodes.map(n=>n.matrixWorld.clone()),metrics=chainErrors(nodes,pivots,controls.limbs),moved=[];let maxP=0,maxN=0,maxNative=0,keyMatrix=0,keyTranslation=0;
   report.physical.maximum_segment_length_error_m=Math.max(report.physical.maximum_segment_length_error_m,metrics.length);report.physical.maximum_parent_residual_m=Math.max(report.physical.maximum_parent_residual_m,metrics.parent);
   fail(metrics.length<=limit.segment_length_error_m,'Original segment length',{time:sample.time,error:metrics.length});fail(metrics.parent<=limit.segment_length_error_m,'Original parent linkage',{time:sample.time,error:metrics.parent});
   let expected=null;if(sample.key!==null){expected=expectedBones(frames[sample.key].global_canonical_matrices,cc[0].mesh.skeleton.boneInverses);for(let i=0;i<26;i++){const wanted=new T.Matrix4().set(...frames[sample.key].global_canonical_matrices[i].flat());keyMatrix=Math.max(keyMatrix,...wanted.elements.map((v,k)=>Math.abs(v-actualWorld[i].elements[k])));keyTranslation=Math.max(keyTranslation,new T.Vector3().setFromMatrixPosition(wanted).distanceTo(new T.Vector3().setFromMatrixPosition(actualWorld[i])));}}
   const surfaces=[];
   for(let mi=0;mi<3;mi++){
    const c=cc[mi],nf=normalContext(c),points=new Float64Array(c.position.count*3);let minY=Infinity;
    for(let i=0;i<c.position.count;i++){
     affineSkin(c,nf.b,i,p);points.set(p.toArray(),i*3);minY=Math.min(minY,p.y);need(p.toArray().every(Number.isFinite),'Finite actual shader position');
     c.mesh.applyBoneTransform(i,q.fromBufferAttribute(c.position,i)).applyMatrix4(c.mesh.matrixWorld);maxNative=Math.max(maxNative,p.distanceTo(q));
     shaderNormal(c,nf,i,actualNormal);
     if(expected){affineSkin(rc[mi],expected,i,e);maxP=Math.max(maxP,p.distanceTo(e),q.distanceTo(e));shaderNormal(rc[mi],{b:expected,prefix:nf.prefix},i,expectedNormal);const angle=Math.atan2(cross.crossVectors(actualNormal,expectedNormal).length(),actualNormal.dot(expectedNormal))*180/Math.PI;maxN=Math.max(maxN,angle);report.positions.evaluations++;report.normals.evaluations++;}
    }
    moved.push(points);let edgeMin=1,edgeMax=1,areaMin=1,areaMax=1,negative=0,worstEdge=null;
    for(let ti=0;ti<base[mi].length;ti++){const b=base[mi][ti],v=b.ids.map(i=>xyz(points,i));for(let k=0;k<3;k++)if(b.edges[k]>1e-8){const ratio=distance(v[(k+1)%3],v[k])/b.edges[k];if(ratio<edgeMin){edgeMin=ratio;worstEdge={triangle:ti,vertices:b.ids,ratio};}edgeMax=Math.max(edgeMax,ratio);}const normal=cross3(sub(v[1],v[0]),sub(v[2],v[0]));if(b.area>1e-12){const ratio=norm3(normal)/b.area;areaMin=Math.min(areaMin,ratio);areaMax=Math.max(areaMax,ratio);negative+=+(dot3(b.normal,normal)<0);}}
    surfaces.push({mesh:mi,edgeMin,edgeMax,areaMin,areaMax,negative,minY,worstEdge});
    fail(edgeMin>=limit.minimum_triangle_edge_ratio&&edgeMax<=limit.maximum_triangle_edge_ratio,'Original edge limits',{time:sample.time,key:sample.key,mesh:mi,edgeMin,edgeMax,worstEdge});fail(areaMin>=limit.minimum_triangle_area_ratio&&areaMax<=limit.maximum_triangle_area_ratio,'Original area limits',{time:sample.time,mesh:mi,areaMin,areaMax});fail(negative===limit.allowed_rest_relative_triangle_normal_dot_negative,'Original normal sign',{time:sample.time,mesh:mi,negative});fail(minY>=limit.minimum_all_surface_y_m,'Original ground limit',{time:sample.time,mesh:mi,minY});
   }
   const contact=maxContact(moved,rest,patches);let seam=0;for(const[[ma,va],[mb,vb]]of seamPairs)seam=Math.max(seam,distance(xyz(moved[ma],va),xyz(moved[mb],vb)));
   report.physical.maximum_contact_error_m=Math.max(report.physical.maximum_contact_error_m,contact.gap);report.physical.maximum_seam_gap_m=Math.max(report.physical.maximum_seam_gap_m,seam);
   fail(contact.gap<=limit.stance_patch_drift_m,'Original whole-hoof contact limit',{time:sample.time,key:sample.key,...contact});fail(seam<=limit.minimum_seam_gap_tolerance_m,'Original seam limit',{time:sample.time,seam});
   if(sample.key===0){firstNodes=actualWorld.map(m=>m.clone());firstPoints=moved.map(a=>a.slice());for(let mi=0;mi<3;mi++)for(let i=0;i<rest[mi].length;i++)neutralResidual=Math.max(neutralResidual,distance(xyz(moved[mi],i),rest[mi][i]));fail(neutralResidual<=1e-6,'Original neutral position limit',{neutralResidual});}
   if(sample.key!==null){report.key_count++;report.positions.maximum_delta_m=Math.max(report.positions.maximum_delta_m,maxP);report.normals.maximum_angle_degrees=Math.max(report.normals.maximum_angle_degrees,maxN);report.joint_world.maximum_translation_error_m=Math.max(report.joint_world.maximum_translation_error_m,keyTranslation);report.joint_world.maximum_matrix_component_error=Math.max(report.joint_world.maximum_matrix_component_error,keyMatrix);fail(maxP<=1e-5&&maxN<=.01&&keyTranslation<=1e-5&&keyMatrix<=1e-5,'Actual loaded key equivalence',{time:sample.time,maxP,maxN,keyTranslation,keyMatrix});}else report.midpoint_count++;
   report.poses.push({time:sample.time,key:sample.key,contact,seam,surfaces,metrics,maxP,maxN,maxNative,keyMatrix,keyTranslation,world_matrices:actualWorld.map(m=>m.elements.slice())});
   console.log('STANDING_READBACK_PROGRESS '+JSON.stringify({time:sample.time,key:sample.key,contact:contact.gap,failures:report.failures.length}));
  }
  let loopP=0,loopR=0,loopSkin=0;for(let i=0;i<26;i++){const last=nodes[i].matrixWorld.elements,first=firstNodes[i].elements;for(const k of[12,13,14])loopP=Math.max(loopP,Math.abs(last[k]-first[k]));for(const k of[0,1,2,4,5,6,8,9,10])loopR=Math.max(loopR,Math.abs(last[k]-first[k]));}for(let mi=0;mi<3;mi++){const c=cc[mi],nf=normalContext(c);for(let i=0;i<c.position.count;i++)loopSkin=Math.max(loopSkin,affineSkin(c,nf.b,i,p).distanceTo(new T.Vector3().fromArray(firstPoints[mi],i*3)));}fail(loopP<=limit.loop_position_m&&loopR<=limit.loop_rotation_matrix_abs&&loopSkin<=limit.stance_patch_drift_m,'Original loop limits',{loopP,loopR,loopSkin});
  // Actual temporary wrong-local and hoof corruptions; no second model/grid.
  pose(candidate,0,3);const cnode=nodes[controls.limbs.fore_l.joints[2]],savedQ=cnode.quaternion.clone(),worldQ=cnode.getWorldQuaternion(new T.Quaternion());cnode.quaternion.copy(worldQ);candidate.scene.updateMatrixWorld(true);candidate.meshes.forEach(m=>m.skeleton.update());
  const sampleContact=()=>{const moved=cc.map(c=>{const a=new Float64Array(c.position.count*3),f=normalContext(c);for(let i=0;i<c.position.count;i++)a.set(affineSkin(c,f.b,i,p).toArray(),i*3);return a;});return maxContact(moved,rest,patches).gap;};const wrongLocal=sampleContact();cnode.quaternion.copy(savedQ);candidate.scene.updateMatrixWorld(true);candidate.meshes.forEach(m=>m.skeleton.update());
  const hoof=nodes[controls.limbs.fore_l.joints[4]],savedP=hoof.position.clone();hoof.position.y+=.003;candidate.scene.updateMatrixWorld(true);candidate.meshes.forEach(m=>m.skeleton.update());const hoofCorruption=sampleContact(),badLength=chainErrors(nodes,pivots,controls.limbs).length;hoof.position.copy(savedP);candidate.scene.updateMatrixWorld(true);candidate.meshes.forEach(m=>m.skeleton.update());
  report.negative_controls={wrong_world_as_local_contact_error_m:wrongLocal,three_mm_hoof_contact_error_m:hoofCorruption,three_mm_segment_error_m:badLength};fail(wrongLocal>limit.stance_patch_drift_m&&hoofCorruption>=limit.negative_control_min_detected_m&&badLength>=limit.negative_control_min_detected_m,'Meaningful actual corruption controls',report.negative_controls);
  report.loop={loopP,loopR,loopSkin};report.neutral_residual_m=neutralResidual;report.original_physical_limits=limit;report.WebGL_contexts_created=window.__proofGLContexts??0;need(report.WebGL_contexts_created===0,'No WebGL context allowed');
  report.status=report.key_count===65&&report.midpoint_count===64&&report.failures.length===0?'LOADED_STANDING65_KEYS64_MIDPOINTS_PASS_ONLY':'LOADED_STANDING129_FAIL_NO_RETRY';
 }catch(error){report.status='LOADED_STANDING129_FAIL_NO_RETRY';report.error={name:error.name,message:error.message,stack:error.stack};}
 finally{for(const model of[source,candidate])if(model){model.mixer.stopAllAction();model.mixer.uncacheRoot(model.scene);for(const c of model.meshes??[])c.skeleton.dispose();}report.elapsed_ms=performance.now()-started;report.scope='Actual standard-loader/Mixer imported13track standing clip at65keys+64midpoints. No renderer/GPUfloat-arithmetic/continuous collision/photographic/app/independentheadtail/walking acceptance.';}
 return report;
};
window.ready=true;
