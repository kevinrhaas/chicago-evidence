"""One unexecuted whole-field anatomical construction, no optimization/export.

Exact old f64 iter40 is ONLY upstream body/proximal base, not a new QP solution.
Actual V12 nested bands replace distal skin with meaningful b/c/d/e support.
"""
from pathlib import Path
import hashlib,json,sys
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
HERE=Path(__file__).resolve().parent
OUT=HERE/'ACTUAL'
EPS=1e-10

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def h5(u):return u*u*u*(10+u*(-15+6*u))
def original_joint_ownership(source_weights):
    owned=np.max(source_weights[:,2:6],axis=1)
    competing=np.max(source_weights[:,[0,1]+list(range(6,26))],axis=1)
    return owned>competing,(owned==competing)&(owned>0)

def validate_protected_and_support(dense,protected,reference,limbs):
    assert np.array_equal(dense[protected],reference[protected]), 'Original protected vector changed'
    for label,row in limbs.items():
        for joint in row['joints'][2:4]:
            assert np.any(dense[:,joint]>0),label+' has no effective carpus/hock or pastern skin influence'

def build(rest,parts,controls,hoof_patch_ids):
    release=json.loads(Path(sys.argv[1]).read_text())
    assert release['released'] is True and release['authorization']=='ONE_ROOT_AUTHORIZED_V14_ANATOMICAL_BIND_ORIGINAL65'
    assert release['candidate_sha256']==sha(__file__)
    for name,digest in release['source_sha256'].items():assert sha(HERE/name)==digest,name+' drift'
    pins=json.loads((HERE/'INPUT-PINS.json').read_text())
    for key,row in pins.items():assert sha(row['path'])==row['sha256'],key+' drift'
    old_c=json.loads(Path(pins['phase_c_report']['path']).read_text())
    assert old_c['native_success'] and old_c['iterations']==40 and old_c['independent_primal_KKT']['KKT_pass'] is False
    old_v12=json.loads(Path(pins['v12_report']['path']).read_text())
    assert old_v12['status']=='RECONSTRUCTED_SECTION_LEDGER_PREFLIGHT_FAIL_NO_RETRY'
    assert all(v['proposal_section_precondition_pass'] for v in old_v12['sections'])
    certificate=json.loads(Path(pins['v13_set_certificate']['path']).read_text())
    assert certificate['V12_report_sha256']==pins['v12_report']['sha256']
    assert certificate['all8proof_source']['sha256']==pins['v13_body_proof']['sha256']
    with np.load(pins['phase_c_vector']['path'],allow_pickle=False) as f:
        x=f['x'].copy();vi=f['var_class_ids'].copy();vj=f['var_joint_ids'].copy()
    with np.load(pins['phase_c_best40']['path'],allow_pickle=False) as f:
        assert int(f['iteration'])==40 and np.array_equal(x,f['x'])
        assert np.array_equal(vi,f['var_class_ids']) and np.array_equal(vj,f['var_joint_ids'])
    with np.load(pins['phase_a_arrays']['path'],allow_pickle=False) as f:
        data={name:f[name].copy() for name in f.files}
    points=data['points_m'];vc=[data['vertex_classes_'+str(mi)] for mi in range(3)];n=len(points)
    assert n==7524 and all(np.array_equal(points[vc[mi]],p) for mi,p in enumerate(rest))
    ids=data['declared_known_class_ids'];rows=data['declared_known_vectors']
    baseline=np.zeros((n,26));baseline[ids]=rows;baseline[vi,vj]=x
    assert np.isfinite(baseline).all() and (baseline>=0).all() and (baseline<=1).all()
    assert np.array_equal(baseline[ids],rows)
    protected=np.zeros(n,dtype=bool);protected[data['source_protected_class_ids']]=True
    original_reference=baseline.copy();dense=baseline.copy()
    # Actual body connectivity only, with the same positive-area edges as A.
    tri=vc[1][parts[1][4]]
    area=np.linalg.norm(np.cross(points[tri[:,1]]-points[tri[:,0]],points[tri[:,2]]-points[tri[:,0]]),axis=1)/2
    graph_tri=tri[area>0]
    edges=np.unique(np.concatenate([np.sort(graph_tri[:,[a,b]],axis=1) for a,b in ((0,1),(1,2),(2,0))]),axis=0)
    edges=edges[edges[:,0]!=edges[:,1]]
    body=np.zeros(n,dtype=bool);body[vc[1]]=True
    claimed=np.zeros(n,dtype=bool);domain_receipts=[];band_receipts=[]
    previous_A=json.loads(Path(pins['phase_a_report']['path']).read_text())
    spec=json.loads((HERE/'RECONSTRUCTED-ANATOMY-AND-PROFILE-INPUTS.json').read_text())
    planes=spec['section_scheme']['planes_per_limb'];handles=['H_b_forearm_handle','H_c_cannon_handle','H_d_pastern_handle','H_e_candidate_coronet']
    all_foot_added=set()
    for label,limb in controls['limbs'].items():
        a,b,c,d,e=limb['joints'];old=next(v for v in previous_A['cuts'] if v['tag']==label+':proximal')
        pivot=np.asarray(old['pivot_m']);normal=np.asarray(old['normal_distal_m']);normal=normal/np.linalg.norm(normal)
        signed=(points-pivot)@normal;positive=body&(signed>EPS)
        es=edges[positive[edges].all(1)]
        graph=coo_matrix((np.ones(2*len(es)),(np.r_[es[:,0],es[:,1]],np.r_[es[:,1],es[:,0]])),shape=(n,n)).tocsr()
        _,labels=connected_components(graph,directed=False)
        own=data[label+'_whole_foot_classes'];seed_labels=np.unique(labels[own])
        assert positive[own].all() and len(seed_labels)==1
        full=positive&(labels==seed_labels[0])
        # This is field-domain reconstruction, NOT another contour preflight.
        st=signed[tri];crossing=tri[(st.min(1)<-EPS)&(st.max(1)>EPS)&full[tri].any(1)]
        boundary=np.unique(crossing.ravel())
        cropped=full.copy();cropped[boundary]=False
        saved=np.zeros(n,dtype=bool);saved[data[label+'_distal_domain_classes']]=True
        assert np.array_equal(cropped,saved), 'Original optimization crop parity failed'
        assert int(full.sum())==old['selected_classes'] and len(boundary)==old['boundary_classes']
        assert not (claimed&full).any(), 'Anatomical limb components overlap'
        claimed|=full
        masks=[]
        for name in handles:
            mask=np.zeros(n,dtype=bool);mask[old_v12['regions'][label+':'+name]['class_ids']]=True;masks.append(mask)
        parent=full
        for mask in masks:
            assert not (mask&~parent).any();parent=mask
        B,C,D,E=masks
        # Preserve the exact upstream body/proximal attachment at the b cut.
        # Old cropped boundary-star rows have NO distal channels. Retain any
        # genuine proximal overlap, rather than hard-assigning only own-a.
        near=np.intersect1d(boundary,np.flatnonzero(full))
        distal=[j for r in controls['limbs'].values() for j in r['joints'][1:]]
        assert np.count_nonzero(baseline[np.ix_(near,distal)])==0, 'Old boundary-star distal exclusion parity failed'
        local=full&~B
        assert np.all(points[local,1]>=planes[handles[0]])
        up=signed[local];down=points[local,1]-planes[handles[0]]
        assert np.all(up>0) and np.all(up+down>0)
        u=up/(up+down);s=h5(u);attachment=baseline[local].copy()
        # New authored attachment definition: own old b/e mass returns to body
        # while all upstream proximal labels are kept. This is NOT a claimed
        # co-motion identity, post-solve pruning, clipping or normalization.
        attachment[:,1]+=attachment[:,b]+attachment[:,e]
        attachment[:,b]=0;attachment[:,e]=0
        assert np.all((attachment>0).sum(1)+((attachment[:,b]==0)&(s>0))<=4), 'Upstream palette plus b exceeds GPU4; no pruning'
        dense[local]=(1-s[:,None])*attachment;dense[local,b]+=s
        for top,bottom,j0,j1,yt,yb in [(B,C,b,c,planes[handles[0]],planes[handles[1]]),(C,D,c,d,planes[handles[1]],planes[handles[2]]),(D,E,d,e,planes[handles[2]],planes[handles[3]])]:
            mask=top&~bottom;u=(yt-points[mask,1])/(yt-yb)
            assert np.all((u>=0)&(u<=1)), 'No coordinate clipping'
            s=h5(u);dense[mask]=0;dense[mask,j0]=1-s;dense[mask,j1]=s
            band_receipts.append({'limb':label,'joint_pair':[j0,j1],'classes':np.flatnonzero(mask).tolist()})
        dense[E]=0;dense[E,e]=1
        all_foot_added.update(int(ci) for ci in own if not protected[ci])
        for other_label,other_limb in controls['limbs'].items():
            if other_label!=label:
                assert not np.intersect1d(np.flatnonzero(full),data[other_label+'_whole_foot_classes']).size
        domain_receipts.append({'limb':label,'full_b_classes':np.flatnonzero(full).tolist(),'old_crop_parity_exact':True,'old_boundary_star':boundary.tolist(),'old_whole_foot_classes':own.tolist(),'no_witness_whitelist':True})
    # Only root-authorized V10-added foot/pastern rows may change any old-known
    # row. Source-original rows remain exact, including all annotated patches.
    changed=np.flatnonzero(np.any(dense!=baseline,axis=1))
    changed_old_known=sorted(set(map(int,changed))&set(map(int,ids)))
    assert set(changed_old_known)<=all_foot_added
    validate_protected_and_support(dense,protected,original_reference,controls['limbs'])
    assert np.isfinite(dense).all() and (dense>=0).all() and (dense<=1).all()
    assert np.abs(dense.sum(1)-1).max()<=1e-8
    assert ((dense>0).sum(1)<=4).all(), 'No rank pruning permitted'
    # Exact frozen V12 before/after proposals become the only allowed change
    # ledger for V10-created whole-foot anchors. No hidden extra row release.
    ledger=old_v12['V10_only_reclassification_ledger'];ledger_ids=set()
    for row in ledger:
        ci=row['class'];ledger_ids.add(ci)
        assert not protected[ci] and np.array_equal(baseline[ci],np.asarray(row['before']))
        assert np.array_equal(dense[ci],np.asarray(row['after_preview'])), 'V12 pastern ledger drift'
    assert set(changed_old_known)==ledger_ids
    # Controls corrupt synthetic copies only; no second field construction.
    bad=dense.copy();bad[:,[j for r in controls['limbs'].values() for j in r['joints'][2:4]]]=0
    lost_support=False
    try:validate_protected_and_support(bad,protected,original_reference,controls['limbs'])
    except AssertionError:lost_support=True
    assert lost_support
    bad=dense.copy();first=int(np.flatnonzero(protected)[0]);bad[first]*=.5
    altered_anchor=False
    try:validate_protected_and_support(bad,protected,original_reference,controls['limbs'])
    except AssertionError:altered_anchor=True
    assert altered_anchor
    # ONE value-changing float64->float32 cast, no clipping/pruning/renorm.
    dense32=dense.astype(np.float32);joints=np.zeros((n,4),dtype=np.uint16);weights=np.zeros((n,4),dtype=np.float32)
    for ci,row in enumerate(dense):
        palette=np.flatnonzero(row>0);assert len(palette)<=4
        joints[ci,:len(palette)]=palette;weights[ci,:len(palette)]=dense32[ci,palette]
    recovered=np.zeros_like(dense32);np.add.at(recovered,(np.arange(n)[:,None],joints),weights)
    assert np.array_equal(recovered,dense32)
    assert np.array_equal(recovered[protected],original_reference[protected].astype(np.float32))
    arrays=[(joints[classes].astype(int),weights[classes].copy()) for classes in vc]
    fixture=json.loads((HERE/'PROVED-TAIL-COMPONENT.json').read_text());tv=np.asarray(fixture['exact_source_vertex_ids'],dtype=int);tc=np.unique(vc[0][tv])
    assert len(tv)==969 and len(tc)==901
    for mi in range(len(parts)):
        local=np.flatnonzero(np.isin(vc[mi],tc));assert not len(local) or mi==0
        arrays[mi][0][local]=parts[mi][2][local];arrays[mi][1][local]=parts[mi][3][local]
        assert np.array_equal(arrays[mi][0][local],parts[mi][2][local])
        assert np.array_equal(arrays[mi][1][local].view(np.uint32),parts[mi][3][local].astype(np.float32).view(np.uint32))
    for label,patch in hoof_patch_ids.items():
        e=controls['limbs'][label]['joints'][-1]
        assert np.all(np.where(arrays[1][0][patch]==e,arrays[1][1][patch],0).sum(1)==1)
    cast_error=np.abs(dense32.astype(float)-dense)
    mass64=np.abs(dense.sum(1)-1);mass32=np.abs(dense32.astype(float).sum(1)-1)
    assert np.all(mass32<=mass64+cast_error.sum(1)+2e-15)
    receipt={'status':'ONE_NEW_ANATOMICAL_FIELD_DIAGNOSTIC_ONLY_NO_GAIT_ACCEPTANCE','QP_certificate_pass':False,'old_V12_cropped_domain_FAIL_preserved':True,
        'original_protected_classes':int(protected.sum()),'original_protected_f64_sha256':hashlib.sha256(dense[protected].tobytes()).hexdigest(),
        'original_protected_vectors_exact':True,'tail_vertices_bits_exact':969,'tail_classes':901,
        'V10_only_pastern_reclassification_ledger':ledger,'new_field_constructions':1,'changed_classes':len(changed),'changed_old_known_classes':changed_old_known,
        'full_domain_reconstruction':domain_receipts,'adjacent_joint_bands':band_receipts,
        'effective_c_d_support_counts':{label:{str(j):int(np.count_nonzero(dense[:,j])) for j in r['joints'][2:4]} for label,r in controls['limbs'].items()},
        'stable_joint_slots':True,'float32_casts':1,'clipping_pruning_or_renormalization':False,'maximum_cast_error':float(cast_error.max()),
        'f64_simplex_residual':float(mass64.max()),'f32_simplex_residual':float(mass32.max()),'roundoff_mass_envelope_verified':True,
        'negative_controls':{'missing_c_d_support_rejected':lost_support,'changed_original_anchor_rejected':altered_anchor},
        'solvers':0,'new_contour_preflights':0,'candidate_planes_profiles_gait_thresholds_changed':False,'model_exports':0,'activation':False,
        'scope':'GLB-standard LBS arrays only. Old LP ell/edge-union/palette assumptions do not apply to new adjacent-segment field. Original physical65 independently decides measured acceptance; QPFAIL remains history.'}
    np.savez_compressed(OUT/'DIAGNOSTIC-FLOAT32-ANATOMICAL-ARRAYS-NOT-MODEL.npz',**{'mesh_'+str(mi)+'_'+key:values.astype(dtype,copy=False) for mi,pair in enumerate(arrays) for key,values,dtype in [('joints',pair[0],np.uint16),('weights',pair[1],np.float32)]})
    (OUT/'ANATOMICAL-BIND-SERIALIZATION-READBACK.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return arrays,receipt
