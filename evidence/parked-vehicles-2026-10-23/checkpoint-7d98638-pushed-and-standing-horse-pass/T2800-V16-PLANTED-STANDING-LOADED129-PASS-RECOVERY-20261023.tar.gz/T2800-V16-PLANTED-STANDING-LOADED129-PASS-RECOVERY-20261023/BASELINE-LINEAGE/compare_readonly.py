"""One root-authorized <=5s raw-array/baseline lineage inspection. No poses."""
from pathlib import Path
import hashlib,json,struct,time
import numpy as np
start=time.monotonic();D=Path(__file__).parent
A=Path('/workspace/shared/T2803-V10-PHASE-A-RUNNER-HELD-20261023/ACTUAL/SOURCE-FEASIBILITY-READBACK.npz')
O=Path('/workspace/shared/T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb')
C=Path('/workspace/shared/T2800-V16-PLANTED-STANDING-GLB-EXPORT-ACTUAL-20261023/horse-sevket-v16-planted-standing-v1.glb')
R=Path('/workspace/shared/T2800-V16-PLANTED-STANDING-GLB-EXPORT-ACTUAL-20261023/CPU-REST-AND-PROTECTION-REFERENCE.json')
def read(p):
 b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];return json.loads(b[20:20+n]),b[28+n:]
def attr(g,b,mi,name):
 a=g['accessors'][g['meshes'][mi]['primitives'][0]['attributes'][name]];v=g['bufferViews'][a['bufferView']];dtype={5123:'<u2',5126:'<f4',5125:'<u4'}[a['componentType']];width=4 if a['type']=='VEC4' else 1
 assert not v.get('byteStride') and not a.get('sparse')
 return np.frombuffer(b,dtype=dtype,count=a['count']*width,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(a['count'],width)
def dense(j,w):
 d=np.zeros((len(j),26),dtype=np.float64);np.add.at(d,(np.arange(len(j))[:,None],j),w);return d
def vec(v):return [{'joint':int(i),'value':float(v[i]),'f32_bits':hex(int(np.asarray(v[i],dtype='<f4').view('<u4')))} for i in np.flatnonzero(v)]
with np.load(A,allow_pickle=False) as f:
 ids=f['declared_known_class_ids'];known=f['declared_known_vectors'];protected=f['source_protected_class_ids'];classes=[f['vertex_classes_'+str(i)] for i in range(3)]
expected=np.zeros((7524,26),dtype='<f4');expected[ids]=known.astype('<f4')
ref=json.loads(R.read_text());tail=np.asarray(ref['tail_vertex_ids']);tailclasses=np.unique(classes[0][tail]);og,ob=read(O);cg,cb=read(C)
report={'scope':'ONE read-only raw-array comparison; no poses, skin evaluation, fields, exports or browser','phase_a_arrays_sha256':hashlib.sha256(A.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(C.read_bytes()).hexdigest(),'meshes':[],'first_mismatch':None}
for mi in range(3):
 oj,ow=attr(og,ob,mi,'JOINTS_0'),attr(og,ob,mi,'WEIGHTS_0');cj,cw=attr(cg,cb,mi,'JOINTS_0'),attr(cg,cb,mi,'WEIGHTS_0')
 od,cd=dense(oj,ow),dense(cj,cw);selected=np.flatnonzero(np.isin(classes[mi],protected)&~np.isin(classes[mi],tailclasses));target=expected[classes[mi][selected]]
 rawdiff=np.any(od[selected]!=cd[selected],axis=1);targetdiff=np.any(cd[selected]!=target,axis=1)
 # Exact standard-loader arithmetic order, independently observed source normalization; no model evaluation.
 def normalized_slots(w):
  f=w.astype(np.float64);s=np.abs(f[:,0])+np.abs(f[:,1])+np.abs(f[:,2])+np.abs(f[:,3]);return (f*(1/s)[:,None]).astype('<f4')
 oldload=dense(oj,normalized_slots(ow));newload=dense(cj,normalized_slots(cw));loaddiff=np.any(oldload[selected]!=newload[selected],axis=1)
 report['meshes'].append({'mesh':mi,'selected_non_tail_rows':len(selected),'candidate_vs_exact_known_f32_mismatches':int(targetdiff.sum()),'raw_original_vs_candidate_mismatches':int(rawdiff.sum()),'standard_loader_original_vs_candidate_mismatches':int(loaddiff.sum())})
 if report['first_mismatch'] is None and rawdiff.any():
  vi=int(selected[np.flatnonzero(rawdiff)[0]]);ci=int(classes[mi][vi]);collapsed=od[vi].copy();collapsed[1]+=collapsed[6:].sum();collapsed[6:]=0;collapsed/=collapsed.sum()
  report['first_mismatch']={'mesh':mi,'vertex':vi,'class':ci,'original_joint_slots':oj[vi].tolist(),'original_weight_slots':ow[vi].tolist(),'original_weight_slot_bits':[hex(int(x)) for x in ow[vi].view('<u4')],'original_raw_vector':vec(od[vi]),'candidate_raw_vector':vec(cd[vi]),'accepted_known_f32_vector':vec(expected[ci]),'source_collapsed_ge6_to1_then_f64_normalized_cast_f32':vec(collapsed.astype('<f4')),'candidate_matches_known':bool(np.array_equal(cd[vi],expected[ci])),'normalized_collapsed_original_matches_known':bool(np.array_equal(collapsed.astype('<f4'),expected[ci])),'same_loader_original_vector':vec(oldload[vi]),'same_loader_candidate_vector':vec(newload[vi])}
report['elapsed_seconds']=time.monotonic()-start
assert report['elapsed_seconds']<5
(D/'READONLY-BASELINE-COMPARISON.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
