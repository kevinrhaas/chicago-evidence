"""HELD; one explicitly released source-pinned tiny capture diagnostic; no app imports."""
from pathlib import Path
import hashlib,importlib.util,json
D=Path(__file__).parent
r=json.loads((D/'ACTUAL-ROOT-TINY-CAPTURE-RELEASE.json').read_text())
assert r['released']is True
for name in ['run.cjs','run_owned.py']:assert hashlib.sha256((D/name).read_bytes()).hexdigest()==r['source_sha256'][name]
p=Path('/workspace/shared/horse-sevket-native-preview-source-20261022/ownership_supervisor.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='778e5623d81821a48aeae5080a8cbff4ef57901570ceea9935fa98ecd9bd0ce5'
s=importlib.util.spec_from_file_location('owned',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=m.run_owned(['node',str(D/'run.cjs')],D/'OWNED-ONE',whole_timeout=15,execution_timeout=12)
print(json.dumps(r,indent=2));raise SystemExit(r.get('exit_code',1))
