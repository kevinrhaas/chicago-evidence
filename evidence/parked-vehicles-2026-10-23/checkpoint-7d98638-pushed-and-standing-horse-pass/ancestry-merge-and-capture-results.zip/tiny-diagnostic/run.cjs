// HELD source. One separately released tiny2D/WebGL transport diagnostic, NOT world qualification.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
const D=__dirname,sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const release=JSON.parse(fs.readFileSync(path.join(D,'ACTUAL-ROOT-TINY-CAPTURE-RELEASE.json')));
for(const name of ['run.cjs','run_owned.py'])if(release.released!==true||release.source_sha256?.[name]!==sha(fs.readFileSync(path.join(D,name))))throw Error('Exact explicit source-pinned diagnostic release absent');
const OUT=path.join(D,'ACTUAL-ONE');fs.mkdirSync(OUT,{recursive:false});
const startMS=Date.now(),result={scope:'Standalone32x32 2D/WebGL canvas+existing evaluate transport diagnosis only; no application/world/vehicle/pixel parity qualification',started:new Date().toISOString(),ownerPID:process.pid,pass:false,progress:[],consoleErrors:[],pageErrors:[]};
const save=()=>fs.writeFileSync(path.join(OUT,'RESULT.json'),JSON.stringify(result,null,2)+'\n');
const note=(stage,edge,extra={})=>{const p={stage,edge,atUTC:new Date().toISOString(),elapsedMS:Date.now()-startMS,...extra};result.progress.push(p);save();console.log(JSON.stringify(p))};
const stage=async(name,work)=>{note(name,'begin');try{const value=await work();note(name,'end');return value}catch(e){note(name,'error',{error:String(e)});throw e}};
const png=(name,reply)=>{const bytes=Buffer.from(reply.data,'base64');if(bytes.length<33||bytes.subarray(0,8).toString('hex')!=='89504e470d0a1a0a'||bytes.toString('ascii',12,16)!=='IHDR'||bytes.readUInt32BE(16)!==32||bytes.readUInt32BE(20)!==32)throw Error('Actual tiny PNG signature/dimensions failed');fs.writeFileSync(path.join(OUT,name),bytes);const{data,...metadata}=reply;return{file:name,width:32,height:32,bytes:bytes.length,sha256:sha(bytes),...metadata}};
let browser,context,page;
const deadline=setTimeout(()=>{result.innerDeadlineReached=true;note('inner10s','deadline');if(page)void page.close().catch(()=>{});if(browser)void browser.close().catch(()=>{})},10000);
(async()=>{
 browser=await stage('chromium.launch',()=>chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']}));
 context=await stage('browser.newContext',()=>browser.newContext({viewport:{width:320,height:240},deviceScaleFactor:1}));
 page=await stage('context.newPage',()=>context.newPage());
 page.on('console',m=>{if(m.type()==='error'){result.consoleErrors.push(m.text());save()}else if(m.text().startsWith('TINY_CAPTURE_PHASE '))note(m.text().slice('TINY_CAPTURE_PHASE '.length),'browser')});
 page.on('pageerror',e=>{result.pageErrors.push(e.message);save()});
 result.canvas2D=png('TINY-2D.png',await stage('page.evaluate:2d-export',()=>page.evaluate(()=>{
  const mark=s=>console.log('TINY_CAPTURE_PHASE '+s),c=document.createElement('canvas');c.width=32;c.height=32;document.body.append(c);
  mark('2d.getContext:begin');const ctx=c.getContext('2d');if(!ctx)throw Error('No2Dcontext');mark('2d.getContext:end');
  mark('2d.fillRect:begin');ctx.fillStyle='rgb(23,87,151)';ctx.fillRect(0,0,32,32);mark('2d.fillRect:end');
  mark('2d.toDataURL:begin');const url=c.toDataURL('image/png');mark('2d.toDataURL:end');
  if(!url.startsWith('data:image/png;base64,')||c.width!==32||c.height!==32)throw Error('2DPNG/dimensions changed');mark('2d.evaluate:return');return{data:url.slice('data:image/png;base64,'.length),scope:'Actual standalone2Dcanvas, excludes DOM',canvasWidth:c.width,canvasHeight:c.height};
 })));
 save();
 result.webGL=png('TINY-WEBGL.png',await stage('page.evaluate:webgl-export',()=>page.evaluate(()=>{
  const mark=s=>console.log('TINY_CAPTURE_PHASE '+s),c=document.createElement('canvas');c.width=32;c.height=32;document.body.append(c);
  mark('webgl.getContext:begin');const gl=c.getContext('webgl2');if(!gl)throw Error('NoWebGL2context');mark('webgl.getContext:end');
  const dimensions={width:c.width,height:c.height,drawingBufferWidth:gl.drawingBufferWidth,drawingBufferHeight:gl.drawingBufferHeight};
  mark('webgl.clear:begin');gl.clearColor(.125,.5,.75,1);gl.clear(gl.COLOR_BUFFER_BIT);mark('webgl.clear:end');
  mark('webgl.finish:begin');gl.finish();mark('webgl.finish:end');
  mark('webgl.toDataURL:begin');const url=c.toDataURL('image/png');mark('webgl.toDataURL:end');
  if(!url.startsWith('data:image/png;base64,')||c.width!==32||c.height!==32||gl.drawingBufferWidth!==32||gl.drawingBufferHeight!==32)throw Error('WebGLPNG/dimensions changed');
  const glError=gl.getError();if(glError!==0)throw Error('TinyWebGLerror '+glError);mark('webgl.evaluate:return');return{data:url.slice('data:image/png;base64,'.length),scope:'Actual standaloneWebGLcanvas, excludes DOM',dimensions,glError,contextAttributes:gl.getContextAttributes()};
 })));
 result.pass=!result.pageErrors.length&&!result.consoleErrors.length;
})().catch(e=>{result.error=String(e.stack??e);result.pass=false}).finally(async()=>{
 clearTimeout(deadline);if(context)await context.close().catch(e=>{result.closeError=String(e);result.pass=false});if(browser)await browser.close().catch(e=>{result.closeError=String(e);result.pass=false});
 result.browserClosed=!browser||!browser.isConnected();if(!result.browserClosed||result.innerDeadlineReached)result.pass=false;result.ended=new Date().toISOString();result.state=result.pass?'CLOSED_TINY_DIAGNOSTIC_PASS':'CLOSED_TINY_DIAGNOSTIC_FAIL';save();console.log(JSON.stringify(result));process.exitCode=result.pass?0:1;
});
