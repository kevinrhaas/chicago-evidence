T2795 minimal serialization correction — SOURCE ONLY, 2026-10-23

Root actually ran originalsource 3b035802fb9ae9d2e6af785cc32fe67926a633798c73866b4c19753194392308 once: exit1 after1.131452547997469s,finished08:28:14.494552Z,no timeout,retries0. It reached JSONserialization and raisedTypeError: ObjectoftypeboolisnotJSONserializable (NumPybool scalar). Rawstdout/stderr/TERMINAL preserved at /workspace/shared/T2795-SERIALIZED-TRACE-CHECK-ONE-ACTUAL-20261023. No RESULT.json was written, so no physicalpredicate/clearancePASS orFAIL is inferred from that run.

Minimal delta: add JSONdefault helper numpy_scalar_json(value), ONLY np.generic ->value.item(); raiseTypeError for everyotherunknown object. Pass this helper to report andstdout JSONdumps. No str/coercingbool/blanketfallback and no alteredmetric/threshold/geometry. Everyoldpredicate/metricfunction is sourcebyteidentical. Wholeoldsource is EXACTly restored after removingjustthehelperandtwoJSONdefaultarguments; SOURCE-ONLY-DELTA-PROOF.json records this. Input CHECK-SPEC.json is byteidentical 104830e896752eb9e516c9fae763f4187d920e6936a63159241264d6846071ba.

Correctedsource SHA256 549fa2e0925b360eb7746cd6a74a0826f04c462e6ef9ca8e5bcec9780260e0bc
MINIMAL-SERIALIZATION-ONLY.patch is the entirechange. PythonASTparseonly passes. No source/module/NumPy import, numericalrun, testexecution, fit/export/browser/gate orapp/index/refmutation occurred. Existingoldsource/capsule/failedrun remainunchanged. Expectedresults remainUNKNOWN until rootreviewauthorizes thisfresh checker invocation.

ONE new bounded correctedchecker proposal afterROOTreview, same20soneCPUcap:
 timeout 20s env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 nice -n 15 python3 /workspace/shared/T2795-SERIALIZED-TRACE-CHECK-SERIALIZATION-FIX-SOURCE-20261023/check_serialized_traces.py --spec /workspace/shared/T2795-SERIALIZED-TRACE-CHECK-SERIALIZATION-FIX-SOURCE-20261023/CHECK-SPEC.json --spec-sha256 104830e896752eb9e516c9fae763f4187d920e6936a63159241264d6846071ba --output /workspace/shared/T2795-SERIALIZED-TRACE-CHECK-SERIALIZATION-V2-ONE-ACTUAL-20261023/RESULT.json

Use root'ssameactualPython/NumPyenvironment andusualterminalcapture. Freshoutputpathmustnotexist. This doesnot overwrite/reclassify priorfailure orautorun a retry. Onlyactualsavednewreceipt+exit can qualify serializednormals/caps/restsurface predicates. Existing8mmgap/1e-7numericguard,allsourcepins/controls remainunchanged. No skin/gait,solidcontainment,selfintersection,photographic,harness/vehicle/fullteam acceptance is added.
