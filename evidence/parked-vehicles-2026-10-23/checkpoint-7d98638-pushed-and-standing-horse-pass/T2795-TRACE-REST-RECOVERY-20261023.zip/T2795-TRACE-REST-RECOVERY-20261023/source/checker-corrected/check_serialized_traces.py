#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent serialized GLB check. SOURCE ONLY until root authorizes one run.

No import of the fitting or export source, no Three/browser, no mesh rewriting.
Distance arithmetic uses binary64 decoded from the actual serialized Float32.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import struct
import time

import numpy as np


def numpy_scalar_json(value):
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError('Object of type ' + type(value).__name__ + ' is not JSON serializable')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def pinned(description):
    data = Path(description['path']).read_bytes()
    need(hashlib.sha256(data).hexdigest() == description['sha256'],
         'Pinned actual input changed: ' + description['path'])
    return data


def decode_glb(raw):
    magic, version, length = struct.unpack_from('<III', raw)
    need((magic, version, length) == (0x46546c67, 2, len(raw)), 'Invalid complete GLB header')
    chunks = {}; offset = 12
    while offset < len(raw):
        count, kind = struct.unpack_from('<II', raw, offset); offset += 8
        need(count % 4 == 0 and offset + count <= len(raw) and kind not in chunks,
             'Malformed or repeated GLB chunk')
        chunks[kind] = raw[offset:offset + count]; offset += count
    need(offset == len(raw) and set(chunks) == {0x4e4f534a, 0x004e4942}, 'Exact JSON/BIN GLB required')
    return json.loads(chunks[0x4e4f534a]), chunks[0x004e4942]


def accessor(doc, binary, index, component, shape):
    a = doc['accessors'][index]
    need(a['componentType'] == component and a['type'] == shape and 'sparse' not in a
         and not a.get('normalized'), 'Unexpected actual accessor representation')
    dtype, width = {5126: ('<f4', 4), 5123: ('<u2', 2)}[component]
    columns = {'VEC3': 3, 'SCALAR': 1}[shape]
    v = doc['bufferViews'][a['bufferView']]
    need(v['buffer'] == 0 and v.get('byteStride', columns * width) == columns * width,
         'Unexpected interleaved or external accessor')
    local = a.get('byteOffset', 0); count = a['count'] * columns * width
    offset = v.get('byteOffset', 0) + local
    need(0 <= local <= v['byteLength'] and local + count <= v['byteLength']
         and offset + count <= len(binary), 'Accessor outside actual buffer')
    result = np.frombuffer(binary, dtype=dtype, count=a['count'] * columns, offset=offset)
    return result.reshape(a['count'], columns).copy()


def dot(a, b):
    return np.einsum('...i,...i->...', a, b)


def point_segment_sq(p, a, b):
    direction = b - a; denom = dot(direction, direction)
    t = np.divide(dot(p - a, direction), denom, out=np.zeros_like(denom), where=denom > 0)
    t = np.clip(t, 0, 1)
    delta = p - a - t[..., None] * direction
    return dot(delta, delta)


def point_triangle_sq(p, tri):
    a, b, c = tri[:, 0], tri[:, 1], tri[:, 2]
    result = np.minimum.reduce([point_segment_sq(p, a, b), point_segment_sq(p, b, c),
                                point_segment_sq(p, c, a)])
    u, v, w = b - a, c - a, p - a
    normal = np.cross(u, v); denominator = dot(normal, normal)
    duu, duv, dvv, dwu, dwv = dot(u, u), dot(u, v), dot(v, v), dot(w, u), dot(w, v)
    first = np.divide(dvv * dwu - duv * dwv, denominator,
                      out=np.zeros_like(denominator), where=denominator > 0)
    second = np.divide(duu * dwv - duv * dwu, denominator,
                       out=np.zeros_like(denominator), where=denominator > 0)
    # A tiny conservative inclusion tolerance can only LOWER the candidate
    # distance; it cannot excuse an unsafe near pair. Degenerates use edges.
    inside = (denominator > 0) & (first >= -1e-12) & (second >= -1e-12) & (first + second <= 1 + 1e-12)
    plane = np.divide(dot(w, normal) ** 2, denominator,
                      out=np.full_like(denominator, np.inf), where=denominator > 0)
    return np.minimum(result, np.where(inside, plane, np.inf))


def segment_segment_sq(a, b, c, d):
    result = np.minimum.reduce([point_segment_sq(a, c, d), point_segment_sq(b, c, d),
                                point_segment_sq(c, a, b), point_segment_sq(d, a, b)])
    u, v, w = b - a, d - c, a - c
    aa, bb, cc, dd, ee = dot(u, u), dot(u, v), dot(v, v), dot(u, w), dot(v, w)
    denominator = dot(np.cross(u, v), np.cross(u, v))
    s = np.divide(bb * ee - cc * dd, denominator, out=np.zeros_like(denominator), where=denominator > 0)
    t = np.divide(aa * ee - bb * dd, denominator, out=np.zeros_like(denominator), where=denominator > 0)
    inside = (denominator > 0) & (s >= -1e-12) & (s <= 1 + 1e-12) & (t >= -1e-12) & (t <= 1 + 1e-12)
    delta = w + s[:, None] * u - t[:, None] * v
    return np.minimum(result, np.where(inside, dot(delta, delta), np.inf))


def segment_crosses_triangle(a, b, tri):
    u, v = tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]
    normal = np.cross(u, v)
    da, db = dot(a - tri[:, 0], normal), dot(b - tri[:, 0], normal)
    denominator = da - db
    t = np.divide(da, denominator, out=np.zeros_like(da), where=denominator != 0)
    point = a + t[:, None] * (b - a); w = point - tri[:, 0]
    area = dot(normal, normal)
    first = np.divide(dot(v, v) * dot(w, u) - dot(u, v) * dot(w, v), area,
                      out=np.zeros_like(area), where=area > 0)
    second = np.divide(dot(u, u) * dot(w, v) - dot(u, v) * dot(w, u), area,
                       out=np.zeros_like(area), where=area > 0)
    return ((denominator != 0) & (area > 0) & (t >= -1e-12) & (t <= 1 + 1e-12)
            & (first >= -1e-12) & (second >= -1e-12) & (first + second <= 1 + 1e-12))


def triangle_pair_sq(a, b):
    """All feature families, including edge-through-face intersections.

    Vertex-only or edge-edge-only distance misses an edge crossing a face's
    interior. Coplanar overlap is covered by vertex/face and edge/edge terms.
    """
    result = np.full(len(a), np.inf)
    intersection = np.zeros(len(a), dtype=bool)
    for i in range(3):
        result = np.minimum(result, point_triangle_sq(a[:, i], b))
        result = np.minimum(result, point_triangle_sq(b[:, i], a))
        intersection |= segment_crosses_triangle(a[:, i], a[:, (i + 1) % 3], b)
        intersection |= segment_crosses_triangle(b[:, i], b[:, (i + 1) % 3], a)
        for j in range(3):
            result = np.minimum(result, segment_segment_sq(a[:, i], a[:, (i + 1) % 3],
                                                           b[:, j], b[:, (j + 1) % 3]))
    return np.where(intersection, 0.0, np.maximum(result, 0))


def weld_topology(position, indices):
    table = {}; ids = []
    for p in position:
        key = tuple(float(x) for x in p)
        if key not in table:
            table[key] = len(table)
        ids.append(table[key])
    faces = np.asarray(ids, dtype=np.int64)[indices]
    edges = defaultdict(list); adjacency = defaultdict(set)
    for face in faces:
        for a, b in zip(face, np.roll(face, -1)):
            a, b = int(a), int(b)
            edges[tuple(sorted((a, b)))].append((a, b))
            adjacency[a].add(b); adjacency[b].add(a)
    bad = [(list(edge), values) for edge, values in edges.items()
           if len(values) != 2 or values[0] != tuple(reversed(values[1]))]
    remaining = set(table.values()); components = 0
    while remaining:
        pending = [remaining.pop()]; components += 1
        while pending:
            for v in adjacency[pending.pop()]:
                if v in remaining:
                    remaining.remove(v); pending.append(v)
    return {'weld_rule': 'EXACT serialized position tuples, no tolerance welding',
            'welded_vertices': len(table), 'edges': len(edges), 'faces': len(faces),
            'components': components, 'euler': len(table) - len(edges) + len(faces),
            'bad_oriented_edges': len(bad), 'first_bad_edges': bad[:8],
            'closed_oriented_two_manifold': not bad and components == 1 and len(table) - len(edges) + len(faces) == 2}


def cap_check(position, normals, indices, definition, rest_points, tolerance):
    chain = [np.asarray(rest_points[name], dtype=np.float64) for name in definition['anchors']]
    n = definition['segments_per_leg']; sag = definition['sag_m']
    first = chain[0] + (chain[1] - chain[0]) / n
    first[1] -= 4 * sag * (1 / n) * (1 - 1 / n)
    last = chain[-2] + (chain[-1] - chain[-2]) * (1 - 1 / n)
    last[1] -= 4 * sag * (1 - 1 / n) / n
    expected = [('start', chain[0], chain[0] - first), ('end', chain[-1], chain[-1] - last)]
    results = []
    for label, center, axis in expected:
        axis /= np.linalg.norm(axis)
        # Discover cap faces by ACTUAL normal/plane, not exporter vertex offsets.
        normal_match = np.all(np.einsum('tvi,i->tv', normals[indices], axis) > 1 - 2e-6, axis=1)
        plane_match = np.all(np.abs(np.einsum('tvi,i->tv', position[indices] - center, axis)) <= tolerance, axis=1)
        chosen = indices[normal_match & plane_match]
        corners = sorted({tuple(float(x) for x in p) for tri in position[chosen] for p in tri})
        midpoint_error = float(np.linalg.norm(np.asarray(corners).mean(axis=0) - center)) if len(corners) == 4 else None
        edge_counts = Counter(tuple(sorted((tuple(position[a]), tuple(position[b]))))
                              for face in chosen for a, b in zip(face, np.roll(face, -1)))
        boundary = [edge for edge, count in edge_counts.items() if count == 1]
        lengths = sorted(float(np.linalg.norm(np.asarray(a) - np.asarray(b))) for a, b in boundary)
        target = sorted([definition['width_m']] * 2 + [definition['thickness_m']] * 2)
        neighbors = defaultdict(list)
        for a, b in boundary:
            neighbors[a].append(b); neighbors[b].append(a)
        right_angle_error = max((abs(float(np.dot(np.asarray(v[0]) - key, np.asarray(v[1]) - key)))
                                 for key, v in neighbors.items() if len(v) == 2), default=math.inf)
        rectangle = (len(lengths) == 4 and len(neighbors) == 4 and all(len(v) == 2 for v in neighbors.values())
                     and all(abs(a - b) <= tolerance for a, b in zip(lengths, target))
                     and right_angle_error <= tolerance * (definition['width_m'] + definition['thickness_m']))
        results.append({'end': label, 'actual_triangles': len(chosen), 'distinct_corners': len(corners),
                        'center_error_m': midpoint_error, 'boundary_lengths_m': lengths,
                        'adjacent_edge_max_abs_dot_m2': right_angle_error,
                        'passed': len(chosen) == 2 and len(corners) == 4 and midpoint_error <= tolerance and rectangle})
    return results


def minimum_surface_distance(gear, horse, guard):
    gmin, gmax = gear.min(axis=1), gear.max(axis=1)
    hmin, hmax = horse.min(axis=1), horse.max(axis=1)
    def bounds(start, end):
        delta = np.maximum(np.maximum(hmin[None] - gmax[start:end, None],
                                       gmin[start:end, None] - hmax[None]), 0)
        return np.einsum('ghi,ghi->gh', delta, delta)
    # Seed a REAL upper bound from nearest-AABB pairs, evaluated as whole
    # triangles. The second sweep considers every remaining potential pair.
    nearest = []
    for start in range(0, len(gear), 24):
        nearest.extend(np.argmin(bounds(start, min(start + 24, len(gear))), axis=1).tolist())
    nearest = np.asarray(nearest, dtype=np.int64)
    initial = triangle_pair_sq(gear, horse[nearest])
    need(np.isfinite(initial).all(), 'Nonfinite initial independent surface distances')
    gi = int(np.argmin(initial)); hi = int(nearest[gi]); best = float(initial[gi])
    exact_pairs = len(gear); candidates = 0
    for start in range(0, len(gear), 24):
        end = min(start + 24, len(gear))
        lower = bounds(start, end)
        rows, cols = np.where(lower <= (math.sqrt(best) + guard) ** 2)
        candidates += len(rows)
        for offset in range(0, len(rows), 4096):
            rr, cc = rows[offset:offset + 4096] + start, cols[offset:offset + 4096]
            distances = triangle_pair_sq(gear[rr], horse[cc]); exact_pairs += len(rr)
            need(np.isfinite(distances).all(), 'Nonfinite independent surface distances')
            which = int(np.argmin(distances))
            if float(distances[which]) < best:
                best, gi, hi = float(distances[which]), int(rr[which]), int(cc[which])
    return {'minimum_m': math.sqrt(best), 'closest_gear_triangle': gi, 'closest_horse_triangle': hi,
            'total_triangle_pairs_covered': len(gear) * len(horse),
            'second_sweep_candidate_pairs': candidates, 'exact_feature_pair_evaluations': exact_pairs,
            'broad_phase': 'all pair AABB binary64 lower bounds; guard-expanded current real upper bound',
            'narrow_phase': 'six vertex/face, nine edge/edge, six edge/face crossing families per candidate pair',
            'arithmetic': 'binary64, numerical guard stated; not an exact-real algebraic certificate'}


def metric_controls():
    """Small analytical controls, executed only during a root-released check.

    No exported asset is generated or replaced by these in-memory predicates.
    """
    flat = [[0, 0, 0], [1, 0, 0], [0, 1, 0]]
    cases = [
        ('parallel_faces_20mm', flat, [[0, 0, .02], [1, 0, .02], [0, 1, .02]], .02),
        ('edge_through_face_interior', flat, [[.2, .2, -1], [.2, .2, 1], [.2, .4, 1]], 0),
        ('coplanar_nested', flat, [[.1, .1, 0], [.2, .1, 0], [.1, .2, 0]], 0),
        ('degenerate_points_20mm', [[0, 0, 0]] * 3, [[0, 0, .02]] * 3, .02),
        ('skew_edge_interiors_30mm', [[-1, 0, 0], [1, 0, 0], [-1, 0, 0]],
         [[0, -1, .03], [0, 1, .03], [0, -1, .03]], .03),
    ]
    a = np.asarray([x[1] for x in cases], dtype=np.float64)
    b = np.asarray([x[2] for x in cases], dtype=np.float64)
    measured = np.sqrt(triangle_pair_sq(a, b))
    results = [{'case': row[0], 'expected_m': row[3], 'measured_m': float(value),
                'passed': abs(value - row[3]) <= 1e-10} for row, value in zip(cases, measured)]
    need(all(row['passed'] for row in results), 'Independent distance feature controls failed')
    return results


def run(spec):
    expected = spec['expected']; inputs = spec['inputs']
    controls = metric_controls()
    raw = pinned(inputs['trace_glb']); doc, binary = decode_glb(raw)
    sidecar = json.loads(pinned(inputs['binding_sidecar']))
    fit = json.loads(pinned(inputs['fit_receipt'])); rest = json.loads(pinned(inputs['rest_points']))
    need(sidecar['receipt']['glb_sha256'] == inputs['trace_glb']['sha256'], 'Sidecar/export bytes differ')
    need(sidecar['rest'] == rest and sidecar['receipt']['host_fitting_receipt_sha256']
         == inputs['fit_receipt']['sha256'], 'Wrong actual fitting sidecar')
    need(rest['fit_accepted'] is False and sidecar['profile']['eligible_scene_ids'] == ['1904'],
         'Keep reconstructed unaccepted1904 scope')
    pinned(inputs['horse_host'])
    need(inputs['horse_host']['sha256'] == expected['host_sha256'] == fit['host_sha256']
         == rest['host_sha256'], 'Exact26rig source pair required')
    actual = json.loads(pinned(inputs['saved_horse_actual_rest']))
    need(any(i['label'] == 'horse' and i['sha256'] == expected['host_sha256'] for i in actual['inputs']),
         'Actual decoded horse data belongs to another source')
    need(len(doc['materials']) == 1 and not doc.get('textures') and not doc.get('images'),
         'Unexpected material/texture budget')
    definitions = {d['id']: d for d in sidecar['profile']['links']}
    checked, geometry, gear_labels = [], [], []
    for ni in doc['scenes'][doc.get('scene', 0)]['nodes']:
        node = doc['nodes'][ni]
        need(not any(k in node for k in ['translation', 'rotation', 'scale', 'matrix', 'skin', 'children']),
             'This exact rest export must have identity rigid leaf mesh nodes')
        name = node['name']; need(name in definitions, 'Unexpected actual trace node')
        mesh = doc['meshes'][node['mesh']]
        need(len(mesh['primitives']) == 1, 'One primitive per trace expected')
        p = mesh['primitives'][0]; need(p.get('mode', 4) == 4, 'Triangle primitive required')
        position = accessor(doc, binary, p['attributes']['POSITION'], 5126, 'VEC3').astype(np.float64)
        normals = accessor(doc, binary, p['attributes']['NORMAL'], 5126, 'VEC3').astype(np.float64)
        ids = accessor(doc, binary, p['indices'], 5123, 'SCALAR').reshape(-1).astype(np.int64)
        need(len(ids) % 3 == 0 and len(normals) == len(position) and ids.max() < len(position)
             and np.isfinite(position).all() and np.isfinite(normals).all(), 'Malformed actual geometry')
        indices = ids.reshape(-1, 3); triangles = position[indices]
        normal_error = np.abs(np.linalg.norm(normals, axis=1) - 1)
        crosses = np.cross(triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0])
        twice_area = np.linalg.norm(crosses, axis=1)
        face_normal = np.divide(crosses, twice_area[:, None], out=np.zeros_like(crosses), where=twice_area[:, None] > 0)
        winding = np.einsum('ti,tvi->tv', face_normal, normals[indices])
        topology = weld_topology(position, indices)
        missing_face = weld_topology(position, indices[:-1])
        reversed_indices = indices.copy(); reversed_indices[0] = reversed_indices[0, [0, 2, 1]]
        reversed_face = weld_topology(position, reversed_indices)
        topology_controls = {'removed_face_refused': not missing_face['closed_oriented_two_manifold'],
                             'reversed_face_refused': not reversed_face['closed_oriented_two_manifold']}
        caps = cap_check(position, normals, indices, definitions[name],
                         rest['output_root_rest_points_m'], expected['cap_position_tolerance_m'])
        signed_volume = float(np.sum(dot(triangles[:, 0], np.cross(triangles[:, 1], triangles[:, 2]))) / 6)
        passed = (float(normal_error.max()) <= expected['normal_length_tolerance']
                  and float(twice_area.min()) > 0 and float(winding.min()) > expected['normal_direction_dot_min']
                  and topology['closed_oriented_two_manifold'] and signed_volume > 0
                  and all(topology_controls.values())
                  and all(c['passed'] for c in caps))
        checked.append({'name': name, 'serialized_vertices': len(position), 'triangles': len(indices),
                        'normal_length_max_error': float(normal_error.max()),
                        'minimum_twice_triangle_area_m2': float(twice_area.min()),
                        'minimum_face_vs_vertex_normal_dot': float(winding.min()),
                        'signed_volume_m3': signed_volume, 'topology': topology, 'caps': caps, 'passed': passed})
        checked[-1]['actual_topology_negative_controls'] = topology_controls
        geometry.append(triangles); gear_labels.extend((name, i) for i in range(len(triangles)))
    need(sorted(c['name'] for c in checked) == sorted(expected['trace_names'])
         and len(checked) == expected['trace_primitives'], 'Wrong actual trace set')
    gear = np.concatenate(geometry)
    need(len(gear) == expected['trace_triangles'], 'Wrong actual total trace triangles')
    htri, horse_labels = [], []
    for mesh in actual['objects']['horse']['meshes']:
        ps = np.asarray(mesh['positions'], dtype=np.float64)
        ids = np.asarray(mesh['triangles'], dtype=np.int64).reshape(-1, 3)
        need(np.isfinite(ps).all() and ids.min() >= 0 and ids.max() < len(ps), 'Invalid complete actual horse geometry')
        htri.append(ps[ids]); horse_labels.extend((mesh['name'], i) for i in range(len(ids)))
    horse = np.concatenate(htri)
    need(len(horse) == expected['horse_triangles'], 'Incomplete actual horse triangle set')
    distance = minimum_surface_distance(gear, horse, expected['numeric_distance_guard_m'])
    gi, hi = distance['closest_gear_triangle'], distance['closest_horse_triangle']
    distance['gear_identity'] = gear_labels[gi]; distance['horse_identity'] = horse_labels[hi]
    distance['actual_gear_triangle_m'] = gear[gi].tolist(); distance['actual_horse_triangle_m'] = horse[hi].tolist()
    distance['required_m'] = expected['target_rest_surface_clearance_m']
    distance['numeric_guard_m'] = expected['numeric_distance_guard_m']
    distance['passed'] = distance['minimum_m'] - distance['numeric_guard_m'] >= distance['required_m']
    return {'status': 'independent actual serialized trace/rest-surface check',
            'pass': all(c['passed'] for c in checked) and distance['passed'],
            'input_pins': inputs, 'mesh_checks': checked, 'complete_rest_surface_distance': distance,
            'analytical_metric_controls': controls,
            'fit_generator_imported': False, 'self_intersections_checked': False,
            'solid_containment_checked': False, 'skin_gait_accepted': False,
            'whole_harness_or_photographic_acceptance': False, 'production_activation_allowed': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--spec', type=Path, required=True)
    parser.add_argument('--spec-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    need(not args.output.exists(), 'Fresh receipt path required')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    try:
        raw = args.spec.read_bytes()
        need(hashlib.sha256(raw).hexdigest() == args.spec_sha256, 'Reviewed check spec changed')
        report = run(json.loads(raw))
    except Exception as error:
        report = {'pass': False, 'status': 'checker refused/error', 'error': str(error),
                  'production_activation_allowed': False}
    report['elapsed_seconds'] = time.monotonic() - start
    args.output.write_text(json.dumps(report, indent=2, default=numpy_scalar_json) + '\n')
    print(json.dumps({'pass': report['pass'], 'status': report['status'],
                      'elapsed_seconds': report['elapsed_seconds'], 'receipt': str(args.output)}, default=numpy_scalar_json))
    raise SystemExit(0 if report['pass'] else 1)


if __name__ == '__main__':
    main()
