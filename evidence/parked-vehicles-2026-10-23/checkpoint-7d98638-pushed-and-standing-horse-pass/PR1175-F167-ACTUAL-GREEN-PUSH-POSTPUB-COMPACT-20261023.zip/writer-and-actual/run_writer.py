"""HELD. Root release binds actual finite intake terminal/tree; elevated tool invocation REQUIRED.
One fullpreflight, then only on actualPASS a normalmergecommit/immediatepush/postpub.
No source edits, automaticretry, newerDEVintake, ready promotion or PRmerge.
"""
import argparse,pathlib,subprocess,json,datetime,time,hashlib,os,sys,re,shutil,ctypes,signal
from protected_sources import protected_snapshot,sha
H=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/chicago');A=R/'chicago/4d';D=pathlib.Path('/workspace/shared/PR1175-8EB-DEV29785-DELTA-INTAKE-SOURCE-ONLY-20261023/ACTUAL-ONCE')
OLD='4766644295b5668084130fed80c6a18c9f0e6a04';INCOMING='a22ca758323e6e2f1ed9f3909a88fb98636be55c';LEASE='c1a6e2df2418f5add5615e9940a637d5ccd2cc0d';BRANCH='steward/1835-workwear-repair-20261021';ORIGIN_DEV='824957fe47dd70fad729c3b117cb18b695d54b0b'
ENV=os.environ.copy();ENV['PATH']='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:'+ENV['PATH'];ENV.update({k:'1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','C4D_GATE_REQUIRE_READERS']});ENV.update(CHECK_JOBS='4',BASE='29785b404e1bcab6f29ef467a829ecbf6bbaa5d0')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
O=None;active=None;steps=[];started=None

def save(name,data):
    (O/name).write_text(json.dumps(data,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(R),*args],env=ENV).decode().strip()
def command(name,args,input_bytes=None):
    global active
    intent={'name':name,'command':args,'started':now(),'owner_pid':os.getpid()};save(name+'-INTENT.json',intent);print(json.dumps(intent),flush=True);t=time.monotonic()
    with (O/(name+'.log')).open('wb') as log:
        active=subprocess.Popen(args,cwd=A,env=ENV,stdin=subprocess.PIPE if input_bytes is not None else subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);save('CURRENT.json',{**intent,'child_pid':active.pid});active.communicate(input=input_bytes);rc=active.returncode;active=None
    terminal={**intent,'returncode':rc,'seconds':time.monotonic()-t,'finished':now()};steps.append(terminal);save(name+'-TERMINAL.json',terminal);print(json.dumps(terminal),flush=True);assert rc==0,name+' failed; no retry';return terminal

def api(name,route):
    command(name,['gh','api','--method','GET','repos/kevinrhaas/chicago/'+route]);return json.loads((O/(name+'.log')).read_bytes())
def lease_guard(label):
    actual=api(label,'git/ref/heads/lap/pr-1175');assert actual['object']['sha']==LEASE,'Lease changed';return actual

def merge_source_guard(tree):
    assert git('rev-parse','HEAD')==OLD and git('rev-parse','MERGE_HEAD')==INCOMING
    assert git('branch','--show-current')==BRANCH and git('write-tree')==tree
    assert not git('diff','--name-only') and not git('diff','--name-only','--diff-filter=U')
    assert not git('ls-files','--others','--exclude-standard'),'Untracked source would escape the gated staged tree'
    assert git('rev-parse','origin/dev')==ORIGIN_DEV

def cleanup():
    global active
    if active and active.poll() is None:
        os.killpg(active.pid,signal.SIGTERM)
        try:active.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(active.pid,signal.SIGKILL);active.wait()
    # This Python is a subreaper. Only its own direct/adopted children qualify.
    def children():
        out=[]
        for p in pathlib.Path('/proc').iterdir():
            if not p.name.isdigit():continue
            try:
                s=(p/'stat').read_text().rsplit(')',1)[1].split()
                if int(s[1])==os.getpid():out.append(int(p.name))
            except (FileNotFoundError,ProcessLookupError,ValueError):pass
        return out
    old=children()
    for pid in old:
        try:os.kill(pid,signal.SIGTERM)
        except ProcessLookupError:pass
    end=time.monotonic()+5
    while time.monotonic()<end:
        try:
            pid,_=os.waitpid(-1,os.WNOHANG)
            if pid==0:time.sleep(.05)
        except ChildProcessError:break
    for pid in children():
        try:os.kill(pid,signal.SIGKILL)
        except ProcessLookupError:pass
    while True:
        try:
            pid,_=os.waitpid(-1,os.WNOHANG)
            if pid==0:break
        except ChildProcessError:break
    return {'adopted_children_cleaned':old,'remaining_owned_children':children()}

def main():
    global O,started
    parser=argparse.ArgumentParser();parser.add_argument('--release',required=True);arg=parser.parse_args();rel=json.loads(pathlib.Path(arg.release).read_text())
    assert rel['released'] is True and rel['authorization']=='ONE_ELEVATED_CURRENT29785_FULLGATE_GREEN_CHECKPOINT_PUSH'
    assert rel['elevated_invocation_confirmed'] is True and rel['exclusive_heavy_lane_free'] is True
    assert rel['expected_head']==OLD and rel['expected_merge_head']==INCOMING and rel['expected_lease']==LEASE
    manifest=(H/'SOURCE-MANIFEST.json').read_bytes();assert sha(manifest)==rel['reviewed_source_manifest_sha256']
    for p,pin in json.loads(manifest)['files'].items():assert sha((H/p).read_bytes())==pin['sha256']
    for name,key in [('TERMINAL.json','intake_terminal_sha256'),('FINAL-STAGED-TREE.json','intake_staged_receipt_sha256'),('CURRENT-COMBINED-CONTAINMENT-PROOF.json','containment_proof_sha256')]:assert sha((D/name).read_bytes())==rel[key]
    resolved=json.loads((D/'TERMINAL.json').read_text());stage=json.loads((D/'FINAL-STAGED-TREE.json').read_text());assert resolved['status']=='PASS' and all(s['returncode']==(1 if s['name']=='01-APPLY-17PATH' else 0) for s in resolved['steps']) and not resolved['fullgate_commit_push_executed']
    TREE=rel['expected_staged_tree'];assert len(TREE)==40 and stage['tree']==TREE
    O=H/'ACTUAL-ONCE';O.mkdir(exist_ok=False);started=now();ENV['CHECK_TIMINGS']=str(O/'FULL-PREFLIGHT-TIMINGS.tsv')
    assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
    signal.signal(signal.SIGTERM,lambda s,f:(_ for _ in ()).throw(SystemExit(128+s)))
    status='FAIL';error=None;head=None
    try:
        merge_source_guard(TREE);lease_guard('01-LEASE-INITIAL')
        py=subprocess.check_output(['python3','--version'],env=ENV).decode().strip();assert py=='Python 3.11.17'
        save('START.json',{'started':started,'owner_pid':os.getpid(),'head':OLD,'merge_head':INCOMING,'tree':TREE,'lease':LEASE,'release':rel,'python':py,'node':subprocess.check_output(['node','--version'],env=ENV).decode().strip(),'CHECK_JOBS':4,'math_threads':1,'root_reviewed_actual_combined_tree':True})
        before=protected_snapshot(O/'02-PROTECTED-BEFORE.json')
        # Sixteen focused checks already PASS on this exact source; do not repeat.
        assert len([s for s in resolved['steps'] if s['name'].startswith('FOCUSED-')])==16
        merge_source_guard(TREE)
        # Exact existing preflight. RawBASE cannot advance sharedorigin/dev; no newDEVintake.
        gate=None
        try:gate=command('FULL-PREFLIGHT',['bash','tools/preflight.sh'])
        finally:
            for name in ['preflight-check.log','preflight-cl.log','preflight-ids.log']:
                p=pathlib.Path('/tmp')/name
                if p.is_file():shutil.copy2(p,O/name)
        for name in ['preflight-check.log','preflight-cl.log','preflight-ids.log']:assert (O/name).is_file()
        strip=lambda b:re.sub(r'\x1b\[[0-9;]*m','',b.decode(errors='replace'))
        checklog=strip((O/'preflight-check.log').read_bytes());summary=re.findall(r'CHECK (PASS|FAIL).*?— (\d+) steps',checklog);assert summary and summary[-1][0]=='PASS' and 'none red.' in checklog[-700:]
        assert 'PREFLIGHT PASS' in strip((O/'FULL-PREFLIGHT.log').read_bytes())[-1200:]
        merge_source_guard(TREE);after=protected_snapshot(O/'04-PROTECTED-AFTER-GATE.json');assert after['actual_hashes']==before['actual_hashes']
        gate_receipt={'status':'PASS','returncode':0,'head':OLD,'merge_head':INCOMING,'tree_before':TREE,'tree_after':git('write-tree'),'steps':int(summary[-1][1]),'selftests':re.findall(r'(\d+) of them are self-tests',checklog)[-1:],'seconds':gate['seconds'],'finished':now(),'unstaged':git('diff','--name-only'),'unmerged':git('diff','--name-only','--diff-filter=U'),'checklog_sha256':sha((O/'preflight-check.log').read_bytes())};save('ACTUAL-FULLGATE-PASS.json',gate_receipt)
        lease_guard('05-LEASE-PRECOMMIT');pr=api('06-PR-PRECOMMIT','pulls/1175');assert pr['state']=='open' and isinstance(pr['draft'],bool) and pr['head']['sha']==OLD and pr['head']['ref']==BRANCH and pr['base']['ref']=='dev';save('PR-PRECOMMIT-STATE.json',{'number':1175,'state':pr['state'],'draft':pr['draft'],'head':pr['head']['sha'],'branch':pr['head']['ref'],'draft_state_changed_by_writer':False})
        merge_source_guard(TREE)
        message='T-1789: integrate the reconstructed resident and period vehicle delivery\n\nMerge exact reviewed vehicle a22ca758 while preserving source-bounded Bardwell workwear, person identity and all human eligibility/card guards. Retain parked vehicle payloads, current Inspect/Research UI, both independent glossary tap contracts and all 222 structures. Import the exact reviewed 513-to-29785 authored and asset delta with canonical liberty/source-use outputs; preserve honest merge parents and consolidate the two unshipped pending notes into one resident-and-vehicle entry.\n\nCurrent normal CI, world/browser, photographic and occupied qualification remain open.\n';(O/'COMMIT-MESSAGE.txt').write_text(message)
        command('07-CANDIDATE',['git','commit-tree',TREE,'-p',OLD,'-p',INCOMING],message.encode());candidate=(O/'07-CANDIDATE.log').read_text().strip();assert len(candidate)==40
        command('08-CANDIDATE-CHANGELOG',['node','tools/check-changelog-entry.mjs',ENV['BASE'],candidate]);command('09-CANDIDATE-IDS',['node','tools/resolve_id_collisions.mjs','--base',ENV['BASE'],'--check']);command('10-CANDIDATE-WHITESPACE',['git','diff','--check',ENV['BASE'],candidate]);merge_source_guard(TREE)
        command('11-NORMAL-MERGE-COMMIT',['git','commit','-F',str(O/'COMMIT-MESSAGE.txt')]);head=git('rev-parse','HEAD');assert git('show','-s','--format=%T',head)==TREE and git('show','-s','--format=%P',head).split()==[OLD,INCOMING] and not git('status','--porcelain')
        save('COMMITTED-BEFORE-PUSH.json',{'head':head,'tree':TREE,'parents':[OLD,INCOMING],'gate_pass_sha256':sha((O/'ACTUAL-FULLGATE-PASS.json').read_bytes()),'at':now()});print('COMMITTED '+head,flush=True)
        # Immediate ordinary FF push; no newerDEV fetch/intake or delayed source checkpoint.
        command('12-IMMEDIATE-NORMAL-PUSH',['git','push','origin','HEAD:refs/heads/'+BRANCH]);remote=git('ls-remote','origin','refs/heads/'+BRANCH).split()[0];assert remote==head
        save('COMMIT-PUSH-TERMINAL.json',{'status':'PUSHED','head':head,'tree':TREE,'parents':[OLD,INCOMING],'remote_head':remote,'branch':BRANCH,'at':now(),'native_auto_or_PRmerge':False,'pr_draft_before':pr['draft'],'draft_state_changed_by_writer':False})
        for label,cmd in [('13-HEAD-CHANGELOG',['node','tools/check-changelog-entry.mjs',ENV['BASE'],head]),('14-HEAD-IDS',['node','tools/resolve_id_collisions.mjs','--base',ENV['BASE'],'--check']),('15-HEAD-WHITESPACE',['git','diff','--check',ENV['BASE'],head]),('16-POSTCOMMIT-PUBLISH',['bash','tools/publish.sh']),('17-POSTCOMMIT-MIRROR',['node','tools/check_published.mjs']),('18-POSTCOMMIT-SITE-VALIDATE',['python3','tools/validate.py','--site'])]:command(label,cmd)
        assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==TREE and not git('status','--porcelain') and git('rev-parse','origin/dev')==ORIGIN_DEV
        post=protected_snapshot(O/'19-PROTECTED-AFTER-POSTPUB.json');assert post['actual_hashes']==before['actual_hashes'];build=json.loads((R/'site/4d/build.json').read_text());assert head.startswith(build['version'])
        save('POSTCOMMIT-PUBLISH-TERMINAL.json',{'status':'PASS','head':head,'tree':TREE,'build':build,'at':now(),'clean':True,'ordinary_source_pushed':True,'pr_draft_before':pr['draft'],'draft_state_changed_by_writer':False,'PR_merge_or_ready_actions_executed':False});status='PASS'
    except BaseException as exc:error=repr(exc);print('STOP '+error,flush=True)
    finally:
        children=cleanup()
        if children['remaining_owned_children']:status='FAIL'
        save('TERMINAL.json',{'status':status,'started':started,'finished':now(),'owner_pid':os.getpid(),'head':head,'steps':steps,'error':error,'cleanup':children,'no_automatic_retry':True,'no_newDEV_intake':True,'PR_merge_or_ready_promotion_executed':False});print(json.dumps({'status':status,'head':head,'error':error,'owner_closed':True}),flush=True)
    return 0 if status=='PASS' else 1
if __name__=='__main__':sys.exit(main())
