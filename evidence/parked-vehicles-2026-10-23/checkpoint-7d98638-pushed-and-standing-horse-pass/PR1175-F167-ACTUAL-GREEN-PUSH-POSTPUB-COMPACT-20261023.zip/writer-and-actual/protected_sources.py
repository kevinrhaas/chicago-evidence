"""Read-only source protection for actual476+a22 integration; never bless arbitrary drift."""
import pathlib,json,hashlib,difflib,re,subprocess
HERE=pathlib.Path(__file__).resolve().parent;ROOT=pathlib.Path('/workspace/chicago');APP=ROOT/'chicago/4d'
def sha(b):return hashlib.sha256(b).hexdigest()
def protected_snapshot(output):
    rules=json.loads((HERE/'PROTECTION-RULES.json').read_text());results=[];seen={}
    for group in rules['groups']:
        for row in group['rows']:
            p=row['path']
            if row.get('expected_absent'):
                assert not (ROOT/p).exists(),p
                seen[p]=None;results.append({'path':p,'group':group['name'],'strict':True,'absent':True,'changed':False});continue
            data=(ROOT/p).read_bytes();actual=sha(data);strict=p not in rules['canonical_exceptions']
            if strict:assert actual==row['expected_sha256'],f'Strict protected source drift: {p}'
            item={'path':p,'group':group['name'],'expected_sha256':row['expected_sha256'],'actual_sha256':actual,'strict':strict,'changed':actual!=row['expected_sha256'],'canonical_owner':rules['canonical_exceptions'].get(p)}
            results.append(item);seen[p]=actual
    for row in rules['authored7']:
        actual=sha((ROOT/row['path']).read_bytes());assert actual==row['proposed_sha256'],row['path'];seen[row['path']]=actual
    main='chicago/4d/renderers/web/js/main.js';assert seen[main]=='bf8f965db2cdc8260f97c949b44a3d357acdf11989ebab22fd8680bc1c1bec3b'
    smoke='chicago/4d/tools/smoke_renderer.mjs';actual=(ROOT/smoke).read_bytes();assert sha(actual)==rules['smoke_expected_sha256']
    # This exact source retains the independently checked person delta AND new incoming UI.
    text=actual.decode();incoming=subprocess.check_output(['git','-C',str(ROOT),'show',rules['incoming']+':'+smoke]).decode()
    for start,end in [('    // T-2662: measure a real first appearance','    const problems ='),('    // ---- T-2662/T-3043:','    // ---- end T-2662')]:
        block=lambda s:s[s.index(start):s.index(end,s.index(start))]
        assert block(text)==block(incoming)
    assert 'const api = window.__chicago4d;' in block(text)
    start='        const PLACED_1904 = [';j=text.index(start);arr=text[j:text.index('].sort();',j)+len('].sort();')];ids=re.findall(r"'([a-z0-9_]+)'",arr);assert len(ids)==222 and len(set(ids))==222
    meta=APP/'tools/derived_manifest.json';assert sha(meta.read_bytes())==rules['derived_manifest_sha256'],'Canonical ownership manifest changed'
    owners={p:s for s in json.loads(meta.read_text())['steps'] for p in s.get('resolves',[])}
    for p,rule in rules['canonical_exceptions'].items():assert owners[p]['command']==rule['owner_command'],p
    result={'groups':{g['name']:len(g['rows']) for g in rules['groups']},'strict_person62':True,'authored7_exact':True,'main_exact_incoming':True,'both_independent_tooltip_blocks_exact':True,'census222exact':True,'rows':results,'actual_hashes':seen,'canonical_changes':[r for r in results if r['changed']]}
    pathlib.Path(output).write_text(json.dumps(result,indent=2)+'\n');return result
