"""Root-released one finite patch intake + exact range unions + canonical owners/checks.
No fullgate, commit, push, newDEV intake, or extra merge parent.
"""
import datetime, hashlib, json, os, pathlib, re, subprocess, time, traceback
H=pathlib.Path(__file__).resolve().parent
R=pathlib.Path('/workspace/chicago'); A=R/'chicago/4d'
O=H/'ACTUAL-ONCE'; O.mkdir(exist_ok=False)
ENV=os.environ.copy(); ENV['PATH']='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:'+ENV['PATH']
ENV.update({k:'1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','C4D_GATE_REQUIRE_READERS']});ENV['CHECK_JOBS']='4'
TREE='8eb92ce6495223b51bde21184fe2eb45ffb4229f'; HEAD='4766644295b5668084130fed80c6a18c9f0e6a04'; MERGE='a22ca758323e6e2f1ed9f3909a88fb98636be55c'; LEASE='c1a6e2df2418f5add5615e9940a637d5ccd2cc0d'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
steps=[]
def save(n,x): (O/n).write_text(json.dumps(x,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git','-C',str(R),*args],env=ENV)
def run(name,args,allowed=(0,)):
    intent={'name':name,'command':args,'started':now(),'owner_pid':os.getpid()};save(name+'-INTENT.json',intent); print(json.dumps(intent),flush=True); t=time.monotonic()
    with (O/(name+'.log')).open('wb') as f: p=subprocess.run(args,cwd=A,env=ENV,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
    terminal={**intent,'returncode':p.returncode,'finished':now(),'seconds':time.monotonic()-t};steps.append(terminal);save(name+'-TERMINAL.json',terminal); print(json.dumps(terminal),flush=True)
    assert p.returncode in allowed, name+' failed; stop, no retry'
    return p.returncode
def guard():
    assert git('rev-parse','HEAD').decode().strip()==HEAD
    assert git('rev-parse','MERGE_HEAD').decode().strip()==MERGE
    assert not git('diff','--name-only')
    assert not git('ls-files','--others','--exclude-standard')
def getstage(path): return git('show',':'+path)
def protected(label):
    p=json.loads((H/'PROTECTED-AND-RANGE-PROOF.json').read_text());out=[]
    for row in p['protected']:
        body=(R/row['path']).read_bytes();assert sha(body)==row['sha256'],row['path'];assert getstage(row['path'])==body,row['path'];out.append(row)
    save(label,{'strict_pins':len(out),'all_pass':True,'rows':out})
start=now();status='FAIL';error=None
try:
    guard(); assert not git('ls-files','-u'); assert git('write-tree').decode().strip()==TREE
    run('00-LEASE',['gh','api','--method','GET','repos/kevinrhaas/chicago/git/ref/heads/lap/pr-1175'])
    assert json.loads((O/'00-LEASE.log').read_text())['object']['sha']==LEASE
    assert subprocess.check_output(['python3','--version'],env=ENV).decode().strip()=='Python 3.11.17'
    save('OWNER.json',{'started':start,'pid':os.getpid(),'head':HEAD,'merge_head':MERGE,'tree':TREE,'lease':LEASE,'root_release':'17 literal paths; exact EOF/222 unions; T1789 reconstructed resident title; two canonical owners; focused freshness only','fullgate_commit_push_authorized':False})
    for cmd,name in [(('diff','--cached','--binary','--full-index'),'BEFORE-STAGED.patch'),(('ls-files','-s'),'BEFORE-INDEX.txt')]: (O/name).write_bytes(git(*cmd))
    protected('PROTECTED-BEFORE.json')
    matrix=json.loads((H/'19PATH-PREIMAGES-AND-TEXTUAL-PROJECTION.json').read_text())
    for row in matrix:
        body=getstage(row['path']);assert sha(body)==row['person_preimage_sha256'];assert (R/row['path']).read_bytes()==body
    patch=H/'EXACT-513-TO-29785-17PATH-AUTHORED-ASSETS-BINARY.patch'
    assert sha(patch.read_bytes())=='e468a5ef4a71f2b73c83ec29a9873502313c24e6e25ee048084453582a998119'
    run('01-APPLY-17PATH',['git','-C',str(R),'apply','--3way','--index',str(patch)],(0,1))
    (O/'ACTUAL-CONFLICT-STAGES.txt').write_bytes(git('ls-files','-u'))
    upaths=set(git('diff','--name-only','--diff-filter=U').decode().splitlines())
    docpath='chicago/4d/docs/LIBERTIES.md'; smokepath='chicago/4d/tools/smoke_renderer.mjs'
    assert upaths=={docpath},'Unexpected authored conflicts: '+repr(upaths)
    actual_ours=git('show',':2:'+docpath); actual_theirs=git('show',':3:'+docpath)
    assert actual_ours==git('show',TREE+':'+docpath)
    assert actual_theirs==git('show','29785b404e1bcab6f29ef467a829ecbf6bbaa5d0:'+docpath)
    frag=(H/'ONLY-INCOMING-KIMBALL-LIBERTY.fragment').read_bytes();assert sha(frag)=='47a48ecf15bdc3a55b2fe8d5f77c655681a58b64b508178f89a0d841024b019d'
    newdoc=actual_ours+frag;assert sha(newdoc)=='6476f898a476e8188bdb9171e539e2068d75771414fa43f50fab2b78f7ae172a'
    (R/docpath).write_bytes(newdoc)
    smoke=(R/smokepath).read_bytes();rx=rb'const PLACED_1904 = \[(.*?)\]\.sort\(\);';m=re.search(rx,smoke,re.S);assert m
    original=git('show',TREE+':'+smokepath);old=re.search(rx,original,re.S);assert old
    assert smoke[:m.start()]==original[:old.start()] and smoke[m.end():]==original[old.end():]
    arr=(H/'EXACT-INCOMING-222-ARRAY.fragment').read_bytes();assert sha(arr)=='6b5df645da3a47f8672387659dd2eedfaeabfe37909c8fccd247bc6211393a67'
    newsmoke=smoke[:m.start()]+arr+smoke[m.end():];assert sha(newsmoke)=='2369bade4d9ec71cdd4b368530c45e43ca2d6e164ece7c563f0a7ee04eae7bb0'
    assert len(re.findall(rb"'([a-z0-9_]+)'",arr))==len(set(re.findall(rb"'([a-z0-9_]+)'",arr)))==222
    (R/smokepath).write_bytes(newsmoke)
    entry=(H/'ONE-T1789-COMBINED-ENTRY.PROPOSAL.json').read_bytes();e=json.loads(entry)
    assert e['title']=='A reconstructed resident, timber wagons and a catalogue-guided carriage'
    assert e['items'][2:]==json.loads((A/'changelog.d/T-2794.json').read_bytes())['items']
    (A/'changelog.d/T-1789.json').write_bytes(entry);(A/'changelog.d/T-2794.json').unlink()
    run('02-STAGE-AUTHORED',['git','-C',str(R),'add','--',docpath,smokepath,'chicago/4d/changelog.d/T-1789.json','chicago/4d/changelog.d/T-2794.json'])
    assert not git('ls-files','-u');guard();protected('PROTECTED-AFTER-AUTHORED.json')
    authoredtree=git('write-tree').decode().strip();save('AUTHORED-TREE.json',{'tree':authoredtree,'merge_head':MERGE,'actual_conflicts':[docpath],'generated_conflicts_manufactured':False})
    for row in matrix:
        if row['person_preimage_equals_patch_base']:assert sha(getstage(row['path']))==row['incoming_sha256'],row['path']
    run('03-OWNER-LIBERTIES',['python3','tools/compile_liberties.py'])
    run('04-OWNER-SOURCE-USE',['python3','tools/compile_source_use.py'])
    changed=git('diff','--name-only').decode().splitlines()
    # Canonical source-use writes are owned outputs, never an authored overwrite.
    allowed={'chicago/4d/data/liberties.json','chicago/4d/docs/measurements/source_use_coverage.md'}
    allowed.update(str(p.relative_to(R)) for p in (A/'data/sidecars/1835/sources').glob('*.json'))
    allowed.update(str(p.relative_to(R)) for p in (A/'data/sidecars').glob('*/sources/uses.json'))
    assert set(changed)<=allowed,repr(changed)
    save('CANONICAL-OWNER-CHANGED-PATHS.json',{'paths':changed,'count':len(changed)})
    if changed:run('05-STAGE-OWNER-OUTPUTS',['git','-C',str(R),'add','--',*changed])
    focused=[
      ['python3','tools/compile_liberties.py','--check'],
      ['python3','tools/compile_scene.py','--all','--check'],
      ['python3','tools/compile_source_use.py','--check'],
      ['python3','tools/compile_jaunts.py','--check'],
      ['python3','tools/jaunt_built_so_far.py','--check'],
      ['python3','tools/export_resident_audit.py','--check'],
      ['python3','tools/report_research_closing_audit.py','--check'],
      ['python3','tools/test_people_scene.py'],
      ['node','tools/test_brougham_card.mjs'],
      ['python3','tools/check_brougham_near.py'],
      ['node','tools/transport/brougham/test_lod.mjs'],
      ['node','--check','tools/smoke_renderer.mjs'],
      ['node','--check','renderers/web/js/main.js'],
      ['node','tools/changelog-entries.mjs','--check'],
      ['node','tools/resolve_id_collisions.mjs','--check'],
      ['git','diff','--check','--cached']]
    for i,cmd in enumerate(focused):run('FOCUSED-'+str(i+1).zfill(2),cmd)
    guard();protected('PROTECTED-FINAL.json');assert not git('ls-files','-u')
    tree=git('write-tree').decode().strip();save('FINAL-STAGED-TREE.json',{'tree':tree,'head':HEAD,'merge_head':MERGE,'lease':LEASE,'no_unstaged_or_U_or_untracked':True})
    (O/'FINAL-STAGED.patch').write_bytes(git('diff','--cached','--binary','--full-index'))
    (O/'FINAL-INDEX.txt').write_bytes(git('ls-files','-s'))
    status='PASS'
except BaseException as e:
    error=repr(e);(O/'EXCEPTION.txt').write_text(traceback.format_exc());raise
finally:
    terminal={'started':start,'finished':now(),'owner_pid':os.getpid(),'status':status,'error':error,'steps':steps,'fullgate_commit_push_executed':False}
    save('TERMINAL.json',terminal);print(json.dumps(terminal),flush=True)
