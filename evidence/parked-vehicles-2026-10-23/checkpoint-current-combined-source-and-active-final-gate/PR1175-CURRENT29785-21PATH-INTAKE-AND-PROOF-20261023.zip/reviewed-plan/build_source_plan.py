import datetime, hashlib, json, pathlib, re, subprocess, tarfile

OUT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('/workspace/chicago')
TREE = '8eb92ce6495223b51bde21184fe2eb45ffb4229f'
BASE = '5135fb7674eea8cf5b140a7cf0c8bc208b0b1f4e'
INCOMING = '29785b404e1bcab6f29ef467a829ecbf6bbaa5d0'
TRANSFER = pathlib.Path('/workspace/shared/PR1175-COMBINED-DELIVERY-TRANSFER-SOURCE-ONLY-20261023')
RULES = pathlib.Path('/workspace/shared/PR1175-A22-GATE-CHECKPOINT-WRITER-HELD-20261023/PROTECTION-RULES.json')

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def sha(body):
    return hashlib.sha256(body).hexdigest()

def blob(path):
    return git('show', f'{TREE}:{path}')

def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n')

assert git('rev-parse', 'HEAD').decode().strip() == '4766644295b5668084130fed80c6a18c9f0e6a04'
assert git('rev-parse', 'MERGE_HEAD').decode().strip() == 'a22ca758323e6e2f1ed9f3909a88fb98636be55c'
assert not git('ls-files', '-u')
assert not git('diff', '--name-only')
assert git('diff', '--cached', '--name-only', TREE) == b''
rows = json.loads((OUT / '19PATH-PREIMAGES-AND-TEXTUAL-PROJECTION.json').read_text())
excluded = ['chicago/4d/data/liberties.json', 'chicago/4d/docs/measurements/source_use_coverage.md']
paths = [row['path'] for row in rows if row['path'] not in excluded]
assert len(paths) == 17
patch = git('diff', '--binary', '--full-index', BASE, INCOMING, '--', *paths)
(OUT / 'EXACT-513-TO-29785-17PATH-AUTHORED-ASSETS-BINARY.patch').write_bytes(patch)
assert len(re.findall(rb'^diff --git ', patch, re.M)) == 17

protected = []
rules = json.loads(RULES.read_text())
for group in rules['groups']:
    if group['name'] != 'PERSON62_STRICT':
        continue
    for row in group['rows']:
        body = blob(row['path'])
        assert sha(body) == row['expected_sha256'], row['path']
        assert (REPO / row['path']).read_bytes() == body, row['path']
        assert row['path'] not in paths
        protected.append({'group': 'PERSON62_STRICT', 'path': row['path'], 'sha256': sha(body)})
containment = json.loads((TRANSFER / 'COMBINED-CONTAINMENT-AND-TRANSFER-PROOF.json').read_text())
vehicles = [r for r in containment['vehicle_paths'] if '/transport/' in r['path'] or r['path'].endswith('/parked-transport.js')]
assert len(vehicles) == 49
for row in vehicles:
    body = blob(row['path'])
    assert sha(body) == row['vehicle_a22_sha256'] == row['person_8eb_sha256']
    assert (REPO / row['path']).read_bytes() == body
    assert row['path'] not in paths
    protected.append({'group': 'VEHICLE49_STRICT', 'path': row['path'], 'sha256': sha(body)})
for row in rows:
    assert sha(blob(row['path'])) == row['person_preimage_sha256']
    assert (REPO / row['path']).read_bytes() == blob(row['path'])

docpath = 'chicago/4d/docs/LIBERTIES.md'
smokepath = 'chicago/4d/tools/smoke_renderer.mjs'
doc = blob(docpath)
smoke = blob(smokepath)
frag = (TRANSFER / 'ONLY-INCOMING-KIMBALL-LIBERTY.fragment').read_bytes()
arr = (TRANSFER / 'EXACT-INCOMING-222-ARRAY.fragment').read_bytes()
assert sha(frag) == '47a48ecf15bdc3a55b2fe8d5f77c655681a58b64b508178f89a0d841024b019d'
assert sha(arr) == '6b5df645da3a47f8672387659dd2eedfaeabfe37909c8fccd247bc6211393a67'
docnew = doc + frag
rx = rb'const PLACED_1904 = \[(.*?)\]\.sort\(\);'
old = re.search(rx, smoke, re.S)
assert old and re.fullmatch(rx, arr, re.S)
smokenew = smoke[:old.start()] + arr + smoke[old.end():]
assert sha(docnew) == '6476f898a476e8188bdb9171e539e2068d75771414fa43f50fab2b78f7ae172a'
assert sha(smokenew) == '2369bade4d9ec71cdd4b368530c45e43ca2d6e164ece7c563f0a7ee04eae7bb0'
assert (OUT / 'authored-comparison' / docpath).read_bytes() == docnew
assert (OUT / 'authored-comparison' / smokepath).read_bytes() == smokenew
ids = re.findall(rb"'([a-z0-9_]+)'", re.search(rx, smokenew, re.S).group(1))
assert len(ids) == len(set(ids)) == 222
assert set(ids) == set(re.findall(rb"'([a-z0-9_]+)'", old.group(1)))
(OUT / 'ONLY-INCOMING-KIMBALL-LIBERTY.fragment').write_bytes(frag)
(OUT / 'EXACT-INCOMING-222-ARRAY.fragment').write_bytes(arr)

entry = json.loads((OUT / 'ONE-T1789-COMBINED-ENTRY.PROPOSAL.json').read_text())
oldvehicle = json.loads(blob('chicago/4d/changelog.d/T-2794.json'))
assert entry['items'][2:] == oldvehicle['items']
assert len(entry['items']) == 6
assert set(entry) == {'title', 'kind', 'items'}
save('PROTECTED-AND-RANGE-PROOF.json', {
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_only_primary_unchanged': True,
    'head': '4766644295b5668084130fed80c6a18c9f0e6a04',
    'merge_head': 'a22ca758323e6e2f1ed9f3909a88fb98636be55c',
    'staged_tree': TREE,
    'required_own1175_lap': 'c1a6e2df2418f5add5615e9940a637d5ccd2cc0d',
    'patch_name': 'EXACT-513-TO-29785-17PATH-AUTHORED-ASSETS-BINARY.patch',
    'patch_bytes': len(patch), 'patch_sha256': sha(patch),
    'literal_paths': paths, 'excluded_generated_outputs': excluded,
    'actual_expected_authored_conflict_paths': [docpath],
    'actual_conflicts_must_be_inspected_before_resolution': True,
    'incoming15_direct_exact': [row['path'] for row in rows if row['person_preimage_equals_patch_base']],
    'protected': protected,
    'doc': {'preimage_sha256': sha(doc), 'output_sha256': sha(docnew), 'entire_person_prefix_preserved': True, 'appended_fragment_sha256': sha(frag)},
    'smoke': {'preimage_sha256': sha(smoke), 'output_sha256': sha(smokenew), 'only_array_replaced': True, 'incoming_array_sha256': sha(arr), 'unique_ids': 222, 'same_id_set': True, 'all_other_human_vehicle_tooltip_assertion_bytes_preserved': True},
    'changelog_sha256': sha((OUT / 'ONE-T1789-COMBINED-ENTRY.PROPOSAL.json').read_bytes()),
    'all4_vehicle_items_verbatim': True,
    'vehicle63_accounting_after_pending_entry_transfer': '53 exact whole files + 9 shared semantic + 1 changelog content transfer',
})
print(json.dumps({'patch_bytes': len(patch), 'patch_sha256': sha(patch), 'protected': len(protected), 'source_only': True}))
