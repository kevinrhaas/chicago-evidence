import datetime, hashlib, json, pathlib, subprocess
H=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/chicago');O=H/'ACTUAL-ONCE'
OLD='8eb92ce6495223b51bde21184fe2eb45ffb4229f';NEW='1d6048e957bfca326db1cdd0aecd16e62f1bd96a';DEV='29785b404e1bcab6f29ef467a829ecbf6bbaa5d0'
sha=lambda x:hashlib.sha256(x).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
def blob(t,p):return git('show',t+':'+p)
actual=json.loads((O/'TERMINAL.json').read_text());assert actual['status']=='PASS'
assert git('write-tree').decode().strip()==NEW
matrix=json.loads((H/'19PATH-PREIMAGES-AND-TEXTUAL-PROJECTION.json').read_text())
changed=git('diff','--name-only',OLD,NEW).decode().splitlines()
allowed={r['path'] for r in matrix}|{'chicago/4d/changelog.d/T-1789.json','chicago/4d/changelog.d/T-2794.json'}
assert set(changed)==allowed,(set(changed)-allowed,allowed-set(changed))
incoming=[]
for row in matrix:
    body=blob(NEW,row['path']);exact=sha(body)==row['incoming_sha256']
    if row['person_preimage_equals_patch_base']:assert exact,row['path']
    incoming.append({'path':row['path'],'final_sha256':sha(body),'exact_incoming29785':exact,'disposition':('exact incoming' if row['person_preimage_equals_patch_base'] else 'reviewed range union' if row['path'].endswith(('LIBERTIES.md','smoke_renderer.mjs')) else 'canonical owner regenerated')})
lp='chicago/4d/data/liberties.json';old=json.loads(blob(OLD,lp));new=json.loads(blob(NEW,lp));up=json.loads(blob(DEV,lp))
oldrows={r['id']:r for r in old['liberties']};newrows={r['id']:r for r in new['liberties']};uprows={r['id']:r for r in up['liberties']}
assert len(oldrows)==old['count'] and len(newrows)==new['count']
assert all(newrows[k]==v for k,v in oldrows.items())
newids=set(newrows)-set(oldrows);assert len(newids)==1
assert all(newrows[k]==uprows[k] for k in newids)
assert {k:v for k,v in old.items() if k not in ('count','liberties')}=={k:v for k,v in new.items() if k not in ('count','liberties')}
rules=json.loads(pathlib.Path('/workspace/shared/PR1175-A22-GATE-CHECKPOINT-WRITER-HELD-20261023/PROTECTION-RULES.json').read_text())
dispositions=[]
for group in rules['groups']:
    for row in group['rows']:
        path=row['path']
        if path=='chicago/4d/changelog.d/T-2794.json':
            assert not (R/path).exists();row['expected_absent']=True;row.pop('expected_sha256',None)
            dispositions.append({'group':group['name'],'path':path,'disposition':'only redundant unshipped entry removed; all four items copied verbatim to T1789'})
            continue
        body=blob(NEW,path);current=sha(body);before=sha(blob(OLD,path))
        if current!=before:assert path in allowed,path
        if group['name']=='PERSON62_STRICT':assert current==row['expected_sha256']
        dispositions.append({'group':group['name'],'path':path,'original_reviewed_expected_sha256':row['expected_sha256'],'frozen8eb_sha256':before,'current_sha256':current,'changed_from8eb':current!=before,'reviewed_reason':next((i['disposition'] for i in incoming if i['path']==path),'consolidated six-item anchor changelog' if path.endswith('T-1789.json') else 'unchanged frozen 8eb')})
        row['expected_sha256']=current
for row in rules['authored7']:row['proposed_sha256']=sha(blob(NEW,row['path']))
rules['canonical_exceptions']={}
rules['final_tree']=NEW;rules['frozen8eb']=OLD;rules['reviewed_dev_delta']=DEV
rules['smoke_expected_sha256']='2369bade4d9ec71cdd4b368530c45e43ca2d6e164ece7c563f0a7ee04eae7bb0'
rules['no_further_derived_drift_permitted']=True
(O/'FINAL-PROTECTION-RULES.json').write_text(json.dumps(rules,indent=2)+'\n')
report={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','tree':NEW,'frozen8eb':OLD,'reviewed_literal_delta':DEV,'delta_paths_vs8eb':changed,'all_other8eb_tree_paths_unchanged':True,'incoming19':incoming,'incoming15_exact':sum(r['exact_incoming29785'] for r in incoming),'old_liberty_count':old['count'],'new_liberty_count':new['count'],'all_old_liberty_records_deep_equal':True,'new_liberty_ids':sorted(newids),'incoming_new_liberty_deep_equal':True,'all_other_liberty_metadata_equal':True,'owner_changed_only_two_expected_files':json.loads((O/'CANONICAL-OWNER-CHANGED-PATHS.json').read_text()),'original_groups_current_disposition':dispositions,'vehicle63_accounting':'53 whole-file exact + 9 shared semantic + 1 changelog content transfer','gate_base_for_current_payload':DEV,'honest_commit_parents':['4766644295b5668084130fed80c6a18c9f0e6a04','a22ca758323e6e2f1ed9f3909a88fb98636be55c'],'all16focused_pass':True,'no_fullgate_or_commit_yet':True}
(O/'CURRENT-COMBINED-CONTAINMENT-PROOF.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'tree':NEW,'delta_paths':len(changed),'incoming_exact':report['incoming15_exact'],'old_liberties':old['count'],'new_liberties':new['count'],'proof_sha256':sha((O/'CURRENT-COMBINED-CONTAINMENT-PROOF.json').read_bytes()),'rules_sha256':sha((O/'FINAL-PROTECTION-RULES.json').read_bytes())}))
