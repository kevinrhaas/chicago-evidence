"""UNEXECUTED genuine four-link motion proposal; no skin/solver/export.

Mandatory reviewed periodic profiles supply upper-link and pastern orientation.
No guessed amplitude, frozen-proximal fallback, stride scaling or reach clamp.
The separate fixed-proximal file is only a diagnostic control, never a default.
"""
import math
import numpy as np
from walk_source_ORIGINAL import PARAMETERS, THRESHOLDS, path, unit, arc


def pose_articulated(t,pivots,limbs,hoof_min_y,reviewed_orientations):
    xyz=pivots.copy();xyz[1:,1]-=PARAMETERS['body_lowering_m']
    rot=np.repeat(np.eye(3)[None],len(pivots),axis=0)
    states={}
    for label,row in limbs.items():
        a,b,c,d,e=row['joints']
        # Input contract: actual source-reviewed proper rotation matrices,
        # periodic/C2 on original 1.6s cycle, with original authored phases.
        ra,rd=reviewed_orientations(t,label)
        for r in (ra,rd):
            assert r.shape==(3,3) and np.isfinite(r).all()
            assert np.max(np.abs(r.T@r-np.eye(3)))<=1e-12
            assert abs(np.linalg.det(r)-1)<=1e-12
        delta,stance,phase=path(t,PARAMETERS['phase_offsets'][label])
        delta[1]-=hoof_min_y[label];target=pivots[e]+delta
        # Hoof e orientation stays identity, hence its complete rigid contact
        # region retains the exact old target. Pastern d may rotate around e.
        elbow=xyz[a]+ra@(pivots[b]-pivots[a])
        fetlock=target-rd@(pivots[e]-pivots[d])
        old_b=pivots[c]-pivots[b];old_c=pivots[d]-pivots[c]
        l1,l2=np.linalg.norm(old_b),np.linalg.norm(old_c)
        line=fetlock-elbow;distance=np.linalg.norm(line)
        if not abs(l1-l2)<distance<l1+l2:
            raise ValueError(f'Unreachable articulated {label}; no clamp or fallback')
        direction=unit(line);rest_pole=ra@old_b
        pole=unit(rest_pole-direction*(rest_pole@direction))
        along=(l1*l1-l2*l2+distance*distance)/(2*distance)
        height=math.sqrt(max(0,l1*l1-along*along))
        carpus=elbow+along*direction+height*pole
        xyz[b],xyz[c],xyz[d],xyz[e]=elbow,carpus,fetlock,target
        rot[a],rot[b],rot[c],rot[d]=ra,arc(old_b,carpus-elbow),arc(old_c,fetlock-carpus),rd
        states[label]={'stance':stance,'phase':phase,'target_local_m':target.tolist(),
                       'reach_margin_m':float(l1+l2-distance)}
    matrices=np.repeat(np.eye(4)[None],len(pivots),axis=0)
    matrices[:,:3,:3]=rot;matrices[:,:3,3]=xyz
    return matrices,states
