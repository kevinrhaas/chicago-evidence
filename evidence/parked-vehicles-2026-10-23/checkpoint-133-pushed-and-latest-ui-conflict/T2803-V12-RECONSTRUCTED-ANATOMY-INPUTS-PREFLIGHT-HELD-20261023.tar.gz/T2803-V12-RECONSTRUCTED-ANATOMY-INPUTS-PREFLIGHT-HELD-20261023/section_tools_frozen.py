"""One root-released V10 source feasibility read; no solver/weights/poses/export.

Palette-union <=4 and the ell Lipschitz cap are conservative assumptions of
THIS formulation. They are not GPU edge requirements or original skin physics.
"""
from pathlib import Path
import ast, hashlib, json, sys, time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components, dijkstra
from actual_model import Model

HERE = Path(__file__).resolve().parent
ELL = 0.3263955630216535
EPS = 1e-10
QUANT = 1e-6
CONTOUR_QUANT = 1e-5


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def quotient(weights):
    q = weights.copy()
    q[..., 1] += q[..., 2:6].sum(axis=-1)
    q[..., 2:6] = 0
    return q


def gradient_violation(a, b, length):
    jump = float(np.abs(quotient(a) - quotient(b)).max())
    bound = float(length / ELL)
    return {'jump': jump, 'bound': bound, 'fails_proposal_regularizer': jump > bound + 1e-9}


def seed_membership(selected, own, other):
    return {'all_own_seeds_included': bool(selected[own].all()),
            'foreign_hoof_seed_classes': np.flatnonzero(selected & other).tolist()}


def contour_summary(points, triangles, signed, selected):
    """Actual arbitrary-plane triangle intersections for the selected component."""
    st = signed[triangles]
    mask = (st.min(1) < -EPS) & (st.max(1) > EPS) & selected[triangles].any(1)
    cross_triangles = triangles[mask]
    adjacency = {}
    for tri in cross_triangles:
        hits = []
        for i, j in ((0, 1), (1, 2), (2, 0)):
            a, b = int(tri[i]), int(tri[j])
            if signed[a] * signed[b] < 0:
                point = points[a] + signed[a] / (signed[a] - signed[b]) * (points[b] - points[a])
                hits.append(tuple(np.rint(point / CONTOUR_QUANT).astype(np.int64)))
        if len(hits) != 2 or hits[0] == hits[1]:
            continue
        a, b = hits
        adjacency.setdefault(a, set()).add(b)
        adjacency.setdefault(b, set()).add(a)
    remaining = set(adjacency)
    closed = open_count = 0
    component_sizes = []
    while remaining:
        todo = [remaining.pop()]
        component = []
        while todo:
            item = todo.pop()
            component.append(item)
            for nxt in adjacency[item]:
                if nxt in remaining:
                    remaining.remove(nxt)
                    todo.append(nxt)
        is_closed = len(component) >= 3 and all(len(adjacency[x]) == 2 for x in component)
        closed += int(is_closed)
        open_count += int(not is_closed)
        component_sizes.append(len(component))
    return {'crossing_triangles': int(len(cross_triangles)),
            'closed_contours': closed, 'open_contours': open_count,
            'contour_component_sizes': component_sizes,
            'unique_closed_separating_contour': closed == 1 and open_count == 0}, cross_triangles


def section(points, triangles, edges, body_mask, pivot, incoming, own, foreign, tag):
    """Virtual graph cut only; actual input vertex/triangle arrays never change."""
    n = len(points)
    normal = incoming / np.linalg.norm(incoming)
    signed = (points - pivot) @ normal
    positive = body_mask & (signed > EPS)
    contained = positive[edges].all(1)
    es = edges[contained]
    graph = coo_matrix((np.ones(2 * len(es)),
                        (np.r_[es[:, 0], es[:, 1]], np.r_[es[:, 1], es[:, 0]])), shape=(n, n)).tocsr()
    _, labels = connected_components(graph, directed=False)
    seed_labels = np.unique(labels[own])
    selected = np.zeros(n, dtype=bool)
    if len(seed_labels) == 1 and positive[own].all():
        selected = positive & (labels == seed_labels[0])
    membership = seed_membership(selected, own, foreign)
    contour, crossing = contour_summary(points, triangles, signed, selected)
    boundary = np.unique(crossing.ravel()) if len(crossing) else np.zeros(0, dtype=int)
    # Vertices exactly on a plane are not jittered or silently assigned a side.
    on_plane = np.flatnonzero(body_mask & (np.abs(signed) <= EPS))
    ok = (positive[own].all() and len(seed_labels) == 1
          and membership['all_own_seeds_included'] and not membership['foreign_hoof_seed_classes']
          and contour['unique_closed_separating_contour'] and len(on_plane) == 0)
    report = {'tag': tag, 'pivot_m': pivot.tolist(), 'normal_distal_m': normal.tolist(),
              'plane_epsilon_m': EPS, 'no_plane_jitter': True,
              'own_seed_classes': int(len(own)), 'all_seeds_distal': bool(positive[own].all()),
              'seed_graph_components': int(len(seed_labels)), 'selected_classes': int(selected.sum()),
              'on_plane_original_classes': on_plane.tolist(), 'boundary_classes': int(len(boundary)),
              **membership, **contour, 'proposal_section_precondition_pass': bool(ok)}
    return report, selected, boundary

