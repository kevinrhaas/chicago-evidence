"""One FUTURE root-released 16-section/source-ledger preflight. NO poses/solver.

The ledger includes numerical previews ONLY for old V10-authored foot rows.
It is not a whole-surface field, serialized skin, physical or anatomical PASS.
"""
from pathlib import Path
import hashlib,json,sys,time
import numpy as np
from actual_model import Model
from section_tools_frozen import section

HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def h5(u):return u*u*u*(10+u*(-15+6*u))

def require_reclassification(ci,source_protected):
    assert ci not in source_protected, 'Original protected row cannot be reclassified'


def main():
    start=time.monotonic();release=json.loads(Path(sys.argv[1]).read_text());out=HERE/'ACTUAL'
    assert release['released'] is True and release['authorization']=='ONE_ROOT_RELEASED_V12_ANATOMICAL_SECTION_LEDGER_PREFLIGHT'
    assert release['maximum_sections']==16 and release['maximum_runs']==1
    assert release['poses_solvers_fields_exports_authorized'] is False
    for name,digest in release['source_sha256'].items():assert sha(HERE/name)==digest,name+' drift'
    pins=json.loads((HERE/'INPUT-PINS.json').read_text())
    for key,row in pins.items():assert sha(row['path'])==row['sha256'],key+' drift'
    assert out.exists() and not (out/'PREFLIGHT-REPORT.json').exists()
    spec=json.loads((HERE/'RECONSTRUCTED-ANATOMY-AND-PROFILE-INPUTS.json').read_text())
    controls=json.loads(Path(pins['controls']['path']).read_text());contacts=json.loads(Path(pins['contacts']['path']).read_text())
    data=np.load(pins['phase_a_arrays']['path'],allow_pickle=False)
    points=data['points_m'];edges=data['edges'];vc=data['vertex_classes_1'];n=len(points)
    assert n==7524
    # Decode actual index topology only. NO neutral/animated skin or pose call.
    model=Model(Path(pins['rig']['path']))
    pr=model.g['meshes'][model.g['nodes'][27]['mesh']]['primitives'][0]
    ix=model.accessor(pr['indices']).astype(int).reshape(-1,3);triangles=vc[ix]
    body_mask=np.zeros(n,dtype=bool);body_mask[vc]=True
    body_area=np.linalg.norm(np.cross(points[triangles[:,1]]-points[triangles[:,0]],points[triangles[:,2]]-points[triangles[:,0]]),axis=1)/2
    graph_triangles=triangles[body_area>0]
    body_edges=np.unique(np.concatenate([np.sort(graph_triangles[:,[a,b]],axis=1) for a,b in ((0,1),(1,2),(2,0))]),axis=0)
    body_edges=body_edges[body_edges[:,0]!=body_edges[:,1]]
    source_protected=set(map(int,data['source_protected_class_ids']))
    known={int(ci):row for ci,row in zip(data['declared_known_class_ids'],data['declared_known_vectors'])}
    patches={label:np.unique(vc[ix[row['source_triangle_ids']].ravel()]) for label,row in contacts['contacts'].items()}
    all_seeds=set(int(ci) for ids in patches.values() for ci in ids)
    sections=[];ledger=[];regions={};failures=[];candidate_previews=0
    planes=spec['section_scheme']['planes_per_limb']
    names=['H_b_forearm_handle','H_c_cannon_handle','H_d_pastern_handle','H_e_candidate_coronet']
    for label,limb in controls['limbs'].items():
        a,b,c,d,e=limb['joints'];own=patches[label]
        foreign=np.zeros(n,dtype=bool);foreign[list(all_seeds-set(map(int,own)))]=True
        masks=[]
        for name in names:
            row,mask,boundary=section(points,triangles,body_edges,body_mask,
                np.array([0.,planes[name],0.]),np.array([0.,-1.,0.]),own,foreign,label+':'+name)
            sections.append(row);masks.append(mask)
            regions[label+':'+name]={'class_ids':np.flatnonzero(mask).tolist(),'boundary_class_ids':boundary.tolist()}
            if not row['proposal_section_precondition_pass']:
                failures.append({'limb':label,'code':'SECTION_FAIL_NO_CHANGED_PLANE','handle':name})
        top=data[label+'_distal_domain_classes'];parent=np.zeros(n,dtype=bool);parent[top]=True
        for name,mask in zip(names,masks):
            outside=np.flatnonzero(mask&~parent)
            if len(outside):failures.append({'limb':label,'code':'NESTING_FAIL','handle':name,'classes':outside.tolist()})
            parent=mask
        if not masks[-1][own].all():failures.append({'limb':label,'code':'ORIGINAL_HOOF_SEED_OMITTED'})
        rigid_min=float(points[masks[-1],1].min()) if masks[-1].any() else None
        patch_min=float(points[own,1].min())
        if rigid_min is None or rigid_min-patch_min < -1e-5:
            failures.append({'limb':label,'code':'UNCHANGED_GROUND_LIMIT_CONFLICT','rigid_min':rigid_min,'patch_min':patch_min})
        regions[label+':hoof_ground']={'rigid_min_y_m':rigid_min,'original_patch_min_y_m':patch_min,'ground_tolerance_m':-1e-5}
        # Classify actual support bands. Axial u is local canonical height ONLY
        # after nested same-limb topology proof; no global height/body mask.
        # This replaces V11's unrealized geodesic-u design explicitly.
        C,D,E=masks[1:]
        protected_moving=[int(ci) for ci in source_protected if C[ci] and not E[ci]]
        regions[label+':original_protected_in_moving_distal_bands']=protected_moving
        if protected_moving:failures.append({'limb':label,'code':'ORIGINAL_PROTECTED_MOVING_BAND_REQUIRES_REVIEW_NO_RELEASE','classes':protected_moving})
        for ci_raw in data[label+'_whole_foot_classes']:
            ci=int(ci_raw);before=known[ci];after=np.zeros(26)
            if E[ci]:after[e]=1;band='rigid_hoof'
            elif D[ci]:
                u=(planes[names[2]]-points[ci,1])/(planes[names[2]]-planes[names[3]])
                assert 0<=u<=1;v=h5(u);after[d]=1-v;after[e]=v;band='pastern_to_hoof'
            elif C[ci]:
                u=(planes[names[1]]-points[ci,1])/(planes[names[1]]-planes[names[2]])
                assert 0<=u<=1;v=h5(u);after[c]=1-v;after[d]=v;band='cannon_to_pastern'
            else:
                failures.append({'limb':label,'code':'OLD_WHOLE_FOOT_EXTENDS_ABOVE_REVIEWED_DISTAL_BANDS','class':ci});continue
            candidate_previews+=1
            if ci in source_protected and not np.array_equal(before,after):
                failures.append({'limb':label,'code':'ORIGINAL_PROTECTED_CONFLICT_NO_OVERRIDE','class':ci})
            if not np.array_equal(before,after):
                if ci not in source_protected:
                    require_reclassification(ci,source_protected)
                    ledger.append({'limb':label,'class':ci,'source_vertices_mesh1':np.flatnonzero(vc==ci).tolist(),
                        'before':before.tolist(),'after_preview':after.tolist(),'band':band,
                        'reason':'ONLY V10-added non-original-protected row; explicit reconstructed anatomical input',
                        'anatomical_input_sha256':sha(HERE/'RECONSTRUCTED-ANATOMY-AND-PROFILE-INPUTS.json')})
        # Effective support counts are opportunities, not emitted field values.
        regions[label+':cannon_candidate_classes']=np.flatnonzero(masks[0]&~masks[2]).tolist()
        regions[label+':pastern_candidate_classes']=np.flatnonzero(C&~E).tolist()
        if not np.any(masks[0]&~masks[2]):failures.append({'limb':label,'code':'NO_ORIGINAL_VERTEX_CANNON_SUPPORT_IN_CHOSEN_PARTITION'})
        if not np.any(C&~E):failures.append({'limb':label,'code':'NO_ORIGINAL_VERTEX_PASTERN_SUPPORT_IN_CHOSEN_PARTITION'})
    assert len(sections)==16
    # Meaningful controls use actual protected/contact IDs, without rerunning
    # geometry or creating a second candidate/cut.
    actual_protected=int(data['source_protected_class_ids'][0]);protected_detected=False
    try:require_reclassification(actual_protected,source_protected)
    except AssertionError:protected_detected=True
    assert protected_detected
    missing_hoof_detected=all(not np.zeros(n,dtype=bool)[ids].all() for ids in patches.values())
    assert missing_hoof_detected
    # Valid complementary endpoint palettes can union>4: no edge-union rule.
    controls_report={'actual_source_protected_release_rejected':protected_detected,
                     'mask_omitting_actual_original_hoof_seeds_rejected':missing_hoof_detected,
                     'no_plane_jitter_or_second_candidate':True,'no_edge_union_cap':True}
    report={'status':'RECONSTRUCTED_SECTION_LEDGER_PREFLIGHT_PASS_NO_SKIN_OR_GAIT_ACCEPTANCE' if not failures else 'RECONSTRUCTED_SECTION_LEDGER_PREFLIGHT_FAIL_NO_RETRY',
        'sections':sections,'regions':regions,'original_protected_conflicts':[f for f in failures if f['code']=='ORIGINAL_PROTECTED_CONFLICT_NO_OVERRIDE'],
        'V10_only_reclassification_ledger':ledger,'candidate_foot_row_previews':candidate_previews,
        'negative_controls':controls_report,'failures':failures,'elapsed_seconds':time.monotonic()-start,
        'support_coordinate':'Topologically isolated nested same-limb domains + explicit local axial quintic, not V11 unrealized geodesic coordinates',
        'profile_coefficients_pinned_but_NOT_evaluated':spec['profile'],'full_weight_fields_generated':0,
        'poses_solvers_models_exports':0,'original_QP_certificate_pass':False,'original65_physical_pass':False,
        'natural_walk_anatomical_or_visual_acceptance':False,'source_protected_rows_changed':0,
        'scope':'Numerical previews for V10-added foot rows only are proposals, not an applied anchor release or final field. Chosen-partition failure is not general anatomical/weights-only impossibility.'}
    (out/'PREFLIGHT-REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'failures':len(failures),'elapsed_seconds':report['elapsed_seconds']}))
    return 0 if not failures else 2

if __name__=='__main__':raise SystemExit(main())
