"""HELD one-shot anatomical section/old-foot ledger preflight supervisor."""
from pathlib import Path
import datetime,hashlib,json,os,resource,signal,subprocess,sys,time
HERE=Path(__file__).resolve().parent
PYTHON='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python'

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    assert sys.version_info[:3]==(3,11,17), 'Runtime guard HOLD before runner/imports'
    release_path=Path(sys.argv[1]).resolve();r=json.loads(release_path.read_text())
    assert r['released'] is True and r['authorization']=='ONE_ROOT_RELEASED_V12_ANATOMICAL_SECTION_LEDGER_PREFLIGHT'
    assert r['maximum_runs']==1 and r['maximum_sections']==16
    assert r['maximum_wall_seconds']==15 and r['maximum_rss_bytes']==512*1024*1024
    assert r['poses_solvers_fields_exports_authorized'] is False
    assert r['ledger_weight_previews_only_for_existing_V10_foot_rows'] is True
    for name,digest in r['source_sha256'].items():assert sha(HERE/name)==digest,name+' drift'
    for key,row in json.loads((HERE/'INPUT-PINS.json').read_text()).items():assert sha(row['path'])==row['sha256'],key+' drift'
    out=HERE/'ACTUAL';assert not out.exists(), 'One-shot output exists; no retry'
    out.mkdir();(out/'ROOT-RELEASE.json').write_text(json.dumps(r,indent=2)+'\n')
    (out/'INTENT.json').write_text(json.dumps({'started_utc':utc(),'one_run':True,'sections':16,'pose_solver_fullfield_model_exports':0,'old_foot_row_ledger_previews':True,'nice':19,'math_threads':1,'wall_seconds':15,'rss_bytes':536870912},indent=2)+'\n')
    env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    start=time.monotonic();peak=0;reason=None
    with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
        child=subprocess.Popen(['nice','-n','19',PYTHON,str(HERE/'preflight_HELD.py'),str(release_path)],cwd=HERE,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        while child.poll() is None:
            try:
                for line in (Path('/proc')/str(child.pid)/'status').read_text().splitlines():
                    if line.startswith('VmRSS:'):peak=max(peak,int(line.split()[1])*1024)
            except FileNotFoundError:pass
            if time.monotonic()-start>15:reason='WALL_LIMIT_15_SECONDS'
            elif peak>512*1024*1024:reason='RSS_LIMIT_512_MiB'
            if reason:
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                break
            time.sleep(.025)
        code=child.wait()
    elapsed=time.monotonic()-start;peak=max(peak,int(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)*1024)
    if peak>512*1024*1024:reason=reason or 'KERNEL_PEAK_RSS_EXCEEDED_512_MiB'
    if elapsed>15:reason=reason or 'ELAPSED_LIMIT_EXCEEDED_15_SECONDS'
    report_path=out/'PREFLIGHT-REPORT.json';report=json.loads(report_path.read_text()) if report_path.exists() else None
    status='RESOURCE_FAIL_NO_RETRY' if reason else report['status'] if report is not None and code in (0,2) else 'SOURCE_OR_INCOMPLETE_ERROR_NO_RETRY'
    t={'status':status,'finished_utc':utc(),'exit_code':code,'elapsed_seconds':elapsed,'actual_peak_rss_bytes':peak,'resource_failure':reason,'runs':1,'reruns':0,'no_owned_child_active':True,'source_protected_rows_changed':0,'pose_solver_fullfield_model_export_calls':0,'original_QP_certificate_pass':False,'original65_physical_pass':False,'anatomical_natural_walk_visual_or_activation_accepted':False}
    (out/'TERMINAL.json').write_text(json.dumps(t,indent=2)+'\n');print(json.dumps(t),flush=True)
    return 0 if report is not None and not report['failures'] and code==0 and reason is None else 2

if __name__=='__main__':raise SystemExit(main())
