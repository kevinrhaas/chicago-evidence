# PR1175: person476 plus vehicle133 authored resolution proposal

SOURCE ONLY. This packet does not merge, edit, stage or commit the app. Primary remains clean person476; origin/dev8249 and its index are unchanged. No GitHub/fetch/browser/gate/publisher/rederive/numerical work ran. Textual three-way merges used copies outside the app, not Git merge-tree or an actual merge. Actual DEV landing, incoming proof and root intake release are still required.

## Exact proposal

Person source4766644295b5668084130fed80c6a18c9f0e6a04; vehicle source13375406538e76e8c1deadf18165089f7145ea28; common base58fd2216a9312295cefbcc08c301852db09ea199. The previous oldb7 inventory is reused; this packet refreshes the incoming source and resolves the new Home/Welcome overlap without duplicating historical asset work.

Seven authored files have proposed complete bytes under `proposed/`; each patch against exact vehicle133 is under `files/.../PROPOSED-VS-VEHICLE133.patch`, combined in `AUTHORED-PROPOSAL-VS-VEHICLE133.patch`. These patches are proposals against a known source, not authorization to overwrite a later DEV file.

- assets/LICENSES.md: retain both complete actual Bardwell export/license sections and the complete incoming Brougham/W01/cloth license sections, including all three explicit asset registry paths. No license changes or abbreviated paths.
- docs/LIBERTIES.md: its text merge is conflict-free; retain person workwear declaration and incoming existing Glessner amendment plus all carriage/wagon liberties. This authored ledger then drives canonical generated data.
- docs/ROADMAP.md and docs/STATUS.md: retain both complete conflict sides, including person source/shoulder/card-honesty history and incoming school/fort/transport records. Preserve raw bytes and existing historical caveats. Add an accurate current integration summary only when actual work exists.
- tools/check.sh and step_isolation.json: text merge is conflict-free; retain all disjoint human, vehicle and shadow test registrations/isolation rows.
- tools/smoke_renderer.mjs: choose incoming vehicle sides for all three textual conflicts, then restore its entire exact Guide block (including `const api`) because automatic merging otherwise deletes that binding outside markers. Retain person human manifest/scene eligibility, request-gate, reconstructed identity/firm-card assertions and supporting wanted fields byte-exact. Keep exact incoming222-ID fixture, whose27 Indiana IDs are already at the beginning; choosing person tail would duplicate them. Both initial Welcome/Reconstructed and Home/Confidence hit-target/onTop/inTile/home/text/dismiss predicates remain independently intact. The initial Welcome readout is unchanged on both inputs. Proposed SHA c0eddb7b9f7c88e52222ae2f9b4db18824433a64452e6316601b7a380925b087. Node syntax and check.sh shell syntax passed on these outside-app proposals only.

## Protected sources and generated files

`PERSON62-REFRESHED-EXPECTED-PINS.json` verifies all original person source hashes. Keep61 exact person pins; the one explicit exception is main.js, whose incoming vehicle change is only the drawing-buffer callback. `INCOMING-MAIN-EXCEPTION.patch` shows it. `PERSON476-ONLY-EXPECTED-PINS.json` pins38 person-only paths. `INCOMING133-NONPERSON-EXPECTED-PINS.json` pins233 incoming paths that person did not change, including vehicle production assets and all reviewed Glessner inputs. Actual later DEV changes must be reviewed before rebinding these expectations.

Do NOT apply hand-merged generated files. data/liberties.json, data/sidecars/1835/sources/index.json and docs/measurements/source_use_coverage.md require the supported canonical derivation after authored resolution. Explicit liberty entries are692 person /695 vehicle; ID union696 (one person workwear liberty plus four vehicle/background additions), with updated existing Glessner prose retained from incoming. Count696 is evidence, not a value to write by hand. An initial generic metadata probe selected the separate names index; it was corrected to the explicit `liberties` key before reporting, without app effects.

## Implementation after root release

1. Verify actual vehicle DEV merge result and current own1175 lap, primary clean HEAD476/index, and source commitments. Use a custom immutable DEV ref; do not move shared origin/dev.
2. Run one actual incoming conflict classification in the assigned primary checkout only after explicit root release. Compare actual source deltas with this packet. Resolve authored overlap consciously; use supported `rederive.mjs --resolve` for conflicted generated files and asset registry tool if needed. No human rebake is needed merely to take these incoming files; preserve existing qualified source/web assets and exact original normal/sole guards.
3. If the ignored Glessner GLBs are stale, prove their old origin/ignored state and restore only through the current incoming canonical archive. Do not hand-copy stale caches or install Blender.
4. Record exact final source/protected proof. Run the required preflight in the exclusive heavy lane when root releases it. On actual PASS, make a normal authored commit, push immediately, validate actual HEAD and normal publication, then collect new current-source CI and appropriate affected browser proof.
5. Vehicles must actually land first; no PR into a topic, no merge/draft promotion/dispatch is authorized by this packet. Root owns final qualification and ordinary DEV merge release.

Historical ca9 desktop14 FAIL4,600,305 against4,600,000 remains a failure, as does the original whole18 result12PASS/6FAIL. Neither source union nor reduced native Glessner geometry proves a new rendered frame. Current merged1904 scene14 and affected human/card scopes still need genuine qualification; do not weaken budgets, cameras, timing or assertions. Broad photographic T1789 stays open after the standing-person increment.
