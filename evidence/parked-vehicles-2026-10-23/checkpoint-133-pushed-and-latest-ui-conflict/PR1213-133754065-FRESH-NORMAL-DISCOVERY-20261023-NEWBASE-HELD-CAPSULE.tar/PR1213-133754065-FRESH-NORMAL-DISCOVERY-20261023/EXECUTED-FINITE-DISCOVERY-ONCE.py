import subprocess,pathlib,json,datetime,hashlib,shutil
D=pathlib.Path('/workspace/shared/PR1213-133754065-FRESH-NORMAL-DISCOVERY-20261023');D.mkdir(exist_ok=False);H='13375406538e76e8c1deadf18165089f7145ea28';T='ea747ccc5dbd095522140a21f1cfcd11e7cbf9b7';P=['cbb94c2d46223e4ca75fc4b02560f43c4de2e710','575b4968569283177e36e92878b2a84c5554068e'];B=P[1];i=0
owner=pathlib.Path('/workspace/shared/T2794-W01-MID11706-CLOTH-DEV575-FULLGATE-COMMIT-ACTUAL-20261023')
for name,digest in [('HEAVY-CLOSED-PUSHED-PUBLISHED-TERMINAL.json','d362b92a38dea722c775750545930535184b7c5d930746f9a698908e09ee0d5a'),('POSTCOMMIT-TERMINAL.json','00ec07133ff8602f40084e4ff3a304e646bb43455017af1df5a4321a422c52cf')]:
 raw=(owner/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest;shutil.copy2(owner/name,D/('OWNER-'+name))
def api(label,route):
 global i
 i+=1;p=D/f'{i:02d}-{label}';p.with_suffix('.request.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'GET','route':route},indent=2)+'\n');r=subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/'+route],capture_output=True,timeout=45);p.with_suffix('.stdout').write_bytes(r.stdout);p.with_suffix('.stderr').write_bytes(r.stderr);assert r.returncode==0,'GET unavailable; STOP no retry '+str(p);return json.loads(r.stdout)
pr=api('ACTUAL-PR','pulls/1213');assert pr['state']=='open'and pr['head']['sha']==H and pr['base']['ref']=='dev'and pr['head']['repo']['full_name']=='kevinrhaas/chicago'and pr['auto_merge']is None,'PR source/state differs'
base=api('ACTUAL-DEV','git/ref/heads/dev')['object']['sha'];source=api('ACTUAL-SOURCE-COMMIT','git/commits/'+H);assert source['tree']['sha']==T and [x['sha']for x in source['parents']]==P
assert api('ACTUAL-SOURCE-REF','git/ref/heads/'+pr['head']['ref'])['object']['sha']==H
inventory=api('NEW-SOURCE-RUN-INVENTORY','actions/runs?head_sha='+H+'&per_page=100');assert inventory['total_count']==len(inventory['workflow_runs']),'Incomplete inventory'
packet=pathlib.Path('/workspace/shared/PR1213-AFTER-575-FRESH-NORMAL-PREPARED-HELD-20261023');binding=json.loads((packet/'ROOT-NORMAL-BINDING-TEMPLATE-HELD.json').read_bytes());known={x['path']:(x['workflow_id'],x['event'])for x in binding['normal_runs']};normal=[];other=[]
for x in inventory['workflow_runs']:
 assert x['head_sha']==H and not x['head_sha'].startswith('0be5')and x['head_sha']!=P[0],'Wrong/old source returned'
 row={k:x.get(k)for k in ['id','path','workflow_id','event','run_attempt','head_sha','head_branch','status','conclusion','created_at','html_url']}
 if x['path']in known:
  assert (x['workflow_id'],x['event'])==known[x['path']]and x['head_branch']==pr['head']['ref']and x['run_attempt']==1,'New normal identity differs'
  normal.append(row)
 else:other.append(row)
merge=None
if pr['merge_commit_sha']:
 c=api('ACTUAL-TESTMERGE','git/commits/'+pr['merge_commit_sha']);merge={'head':c['sha'],'tree':c['tree']['sha'],'parents':[x['sha']for x in c['parents']]}
ready=base==B and pr['mergeable']is True and merge is not None and merge['tree']==T and merge['parents']==[B,H]and len(normal)==4 and {x['path']for x in normal}==set(known)
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':H,'source_tree':T,'source_parents':P,'source_branch':pr['head']['ref'],'actual_dev':base,'stale_PR_API_base_field':pr['base']['sha'],'mergeable':pr['mergeable'],'mergeable_state':pr['mergeable_state'],'draft':pr['draft'],'actual_testmerge':merge,'new_normal_runs':normal,'extra_workflows':other,'normal_four_inventory_complete':len(normal)==4,'binding_ready':ready,'GETs':i,'dispatches':0,'reruns':0,'merge_attempts':0,'collector_started':False}
if ready:
 binding.update(status='ROOT_RELEASED_PR1213_FRESH_NORMAL_FOUR_GET',allow_get=True,source_head=H,source_tree=T,source_parents=P,source_branch=pr['head']['ref'],reviewed_base=B,testmerge_head=merge['head'],testmerge_tree=merge['tree'],testmerge_parents=merge['parents'],actual_new_push_verified=True,actual_postpublish_verified=True)
 ids={x['path']:x['id']for x in normal}
 for row in binding['normal_runs']:row['run_id']=ids[row['path']]
 assert hashlib.sha256((packet/'collect-normal-terminals-GET-only.py').read_bytes()).hexdigest()==binding['collector_sha256']
 f=D/'ACTUAL-ROOT-RELEASED-NORMAL-BINDING.json';f.write_text(json.dumps(binding,indent=2)+'\n');summary['binding_file']=str(f);summary['binding_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
(D/'DISCOVERY-READOUT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
