"""Stdlib-only frozen serialized-data inspection; NO arrays/new section/pose.

Read exact8 recorded V12 failure class scalars and their actual incident index
triangles/edges. A saved-domain neighbor proves old-component membership; an
incident signed-crossing triangle proves old boundary-star removal by source.
"""
from pathlib import Path
import ast,hashlib,json,math,struct,zipfile

HERE=Path(__file__).resolve().parent
A=Path('/workspace/shared/T2803-V10-PHASE-A-RUNNER-HELD-20261023/ACTUAL/SOURCE-FEASIBILITY-READBACK.npz')
R=Path('/workspace/shared/T2803-V12-RECONSTRUCTED-ANATOMY-INPUTS-PREFLIGHT-HELD-20261023/ACTUAL/PREFLIGHT-REPORT.json')
G=Path('/workspace/shared/T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb')
C=Path('/workspace/shared/T2803-V10-ORIGINAL65-ITER40-DIAGNOSTIC-HELD-20261023/RERIG-CONTROLS-PROPOSAL-V2.json')
EXPECTED={A:'869fdff5ca774f48554d1c762539946084246f9d03f413c5067a79d46827d2f1',R:'34e3b1f5ec01e8d4acdb9e55bd660429ad44cec705dc9532751a1142f40b7431',G:'03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36',C:'f540c3e1da1e84e694336d4872cd965e1ca594a4e988ae73d749acaf30f7f6dc'}

def npy_bytes(z,name):
    raw=z.read(name+'.npy');assert raw[:6]==b'\x93NUMPY'
    version=tuple(raw[6:8]);width=2 if version==(1,0) else 4
    length=int.from_bytes(raw[8:8+width],'little');offset=8+width+length
    header=ast.literal_eval(raw[8+width:offset].decode('latin1'))
    assert header['fortran_order'] is False
    code={'<f8':'d','<i8':'q','<i4':'i','<u4':'I','|u1':'B','|b1':'?'}[header['descr']]
    return raw,offset,header,code

def scalar(blob,index):
    raw,offset,header,code=blob
    return struct.unpack_from('<'+code,raw,offset+struct.calcsize(code)*index)[0]

def ints(blob):
    raw,offset,header,code=blob
    return tuple(v[0] for v in struct.iter_unpack('<'+code,raw[offset:]))

for p,h in EXPECTED.items():assert hashlib.sha256(p.read_bytes()).hexdigest()==h,str(p)
controls=json.loads(C.read_text());report=json.loads(R.read_text())
failures={v['limb']:v['classes'] for v in report['failures']};assert failures=={'hind_l':[5147,5149,5151,5171],'hind_r':[5146,5148,5150,5170]}
raw=G.read_bytes();jlen=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+jlen]);binary=raw[28+jlen:]
primitive=g['meshes'][g['nodes'][27]['mesh']]['primitives'][0]
accessor=g['accessors'][primitive['indices']];view=g['bufferViews'][accessor['bufferView']]
assert accessor['type']=='SCALAR';code={5123:'H',5125:'I'}[accessor['componentType']]
start=view.get('byteOffset',0)+accessor.get('byteOffset',0);size=struct.calcsize(code)
assert view.get('byteStride',size)==size
index_bytes=binary[start:start+accessor['count']*size]
rows=[]
with zipfile.ZipFile(A) as z:
    points=npy_bytes(z,'points_m');vc_blob=npy_bytes(z,'vertex_classes_1');vc=ints(vc_blob)
    edge_blob=npy_bytes(z,'edges');edge_raw,edge_offset,edge_header,edge_code=edge_blob
    assert edge_header['shape'][1]==2
    actual_edges=tuple(struct.iter_unpack('<'+edge_code*2,edge_raw[edge_offset:]))
    def point(ci):return tuple(scalar(points,3*ci+k) for k in range(3))
    for label,ids in failures.items():
        domain=set(ints(npy_bytes(z,label+'_distal_domain_classes')))
        a,b,*_=controls['limbs'][label]['joints']
        pa=controls['nodes'][a]['rest_world_pivot_m'];pb=controls['nodes'][b]['rest_world_pivot_m']
        incoming=tuple(y-x for x,y in zip(pa,pb));length=math.sqrt(sum(x*x for x in incoming));normal=tuple(x/length for x in incoming)
        def signed(ci):return sum((x-y)*n for x,y,n in zip(point(ci),pb,normal))
        for ci in ids:
            positions=[vi for vi,value in enumerate(vc) if value==ci]
            positive_saved_neighbors=sorted({v if u==ci else u for u,v in actual_edges if (u==ci or v==ci) and (v if u==ci else u) in domain and signed(v if u==ci else u)>1e-10})
            incident=[]
            for ti in range(accessor['count']//3):
                vertices=struct.unpack_from('<'+code*3,index_bytes,ti*3*size)
                classes=tuple(vc[vi] for vi in vertices)
                if ci not in classes:continue
                distances=tuple(signed(v) for v in classes)
                if min(distances)<-1e-10 and max(distances)>1e-10:
                    incident.append({'triangle':ti,'vertices':vertices,'classes':classes,'old_b_signed_distances_m':distances})
            proof=bool(signed(ci)>1e-10 and positive_saved_neighbors and incident and ci not in domain)
            rows.append({'limb':label,'class':ci,'source_mesh1_vertices':positions,'saved_point_m':point(ci),'old_b_pivot_m':pb,'old_b_distal_unit_normal':normal,'old_b_signed_distance_m':signed(ci),'V12_H_b_y062_signed_distance_m':.62-point(ci)[1],'in_saved_cropped_V10_domain':ci in domain,'positive_edge_neighbors_in_saved_domain':positive_saved_neighbors,'incident_old_b_crossing_triangle_witnesses':incident,'proof_only_boundary_star_crop':proof})
result={'status':'ALL8_LOCAL_WITNESSES_PROVE_BOUNDARY_STAR_CROP_ONLY' if all(r['proof_only_boundary_star_crop'] for r in rows) else 'PARTIAL_OR_MISSING_LOCAL_PROOF_NO_ASSUMED_RELAXATION','rows':rows,'proof':'Each true signed-positive failing class has an actual edge to an existing saved old-domain class, so belongs to the already proved full old b-distal component. Its actual incident signed-crossing triangle is therefore selected by the frozen old section definition; all vertices of that triangle enter b_boundary and are explicitly removed from V10 domain. Absence from cropped domain is optimization crop, not an outside-plane class. This is a scalar/incident-topology witness, not a new contour/component/pose computation.','source_pins':{str(p):h for p,h in EXPECTED.items()},'numerical_libraries_imported':False,'arrays_created':False,'new_section_pose_field_solver_export':0,'V12_actual_failure_preserved':True}
(HERE/'EXACT8-SCALAR-AND-INCIDENT-TOPOLOGY-PROOF.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'rows':[{'class':r['class'],'b_signed_m':r['old_b_signed_distance_m'],'crop_only':r['proof_only_boundary_star_crop'],'saved_domain_neighbors':r['positive_edge_neighbors_in_saved_domain'],'crossing_triangles':[t['triangle'] for t in r['incident_old_b_crossing_triangle_witnesses']]} for r in rows]}))
