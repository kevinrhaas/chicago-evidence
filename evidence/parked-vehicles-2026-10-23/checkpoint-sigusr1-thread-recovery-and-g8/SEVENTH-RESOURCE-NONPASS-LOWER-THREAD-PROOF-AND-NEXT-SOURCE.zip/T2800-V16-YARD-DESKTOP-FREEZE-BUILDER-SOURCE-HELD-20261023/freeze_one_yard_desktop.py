"""Source only until ROOT reviews and supplies an explicit freeze authorization.
Read committed source and the existing COMPLETE published1835 year pack. Copy no assets.
Writes only one external release JSON and its receipt, never runs a caller/browser/tool.
"""
import argparse, datetime, hashlib, json, pathlib, subprocess

REPO = pathlib.Path('/workspace/chicago-waistcoat')
APP = REPO / 'chicago/4d'
SITE = REPO / 'site/4d'
CALLER = pathlib.Path('/tmp/T2800-V16-ACTUAL-YARD-QUALIFIER-SOURCE-HELD-20261023')
SUPERVISOR = pathlib.Path('/workspace/shared/horse-sevket-native-preview-source-20261022/ownership_supervisor.py')
MODEL_SHA = 'b479442cb03ac46eb13c19da15a79cdfaf28dbdf356b116f78de7ce7ecdc60be'
RECEIPT_SHA = '3212f61c3688cc550bfcf5a7a2116c1a12aa06d501b6e7dff9583369ed5d060c'
CALLER_SHA = '086eb9874d9b90792d56b7d0e7f11655f209ab98ff361ca13ffa07ad18a50d9b'
WRAPPER_SHA = 'd706e2443a93c1e6921bf84a3d32abb0fb4f74cab4b07f0667acacd5907f3bd0'
SUPERVISOR_SHA = '778e5623d81821a48aeae5080a8cbff4ef57901570ceea9935fa98ecd9bd0ce5'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(REPO), *args])


def outside_app(path):
    p = path.resolve()
    assert p.is_relative_to('/tmp') or p.is_relative_to('/workspace/shared'), p
    assert not p.is_relative_to(REPO), p
    return p


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-release', required=True)
    parser.add_argument('--output-release', required=True)
    parser.add_argument('--output-receipt', required=True)
    args = parser.parse_args()
    authorization_path = pathlib.Path(args.root_release).resolve()
    authorization_bytes = authorization_path.read_bytes()
    authorization = json.loads(authorization_bytes)
    assert authorization['authorization'] == 'FREEZE_ONE_COMMITTED_V16_YARD_DESKTOP'
    assert authorization['released'] is True and authorization['heavy_owner_closed'] is True
    assert authorization['phase'] == 'yard-desktop'
    expected_head = authorization['expected_committed_head']
    expected_tree = authorization['expected_committed_tree']
    assert len(expected_head) == len(expected_tree) == 40
    assert all(c in '0123456789abcdef' for c in expected_head + expected_tree)
    assert not expected_head.startswith('e4745b3'), 'Refuse pre-integration base HEAD'
    output = outside_app(pathlib.Path(args.output_release))
    receipt_path = outside_app(pathlib.Path(args.output_receipt))
    assert not output.exists() and not receipt_path.exists() and output != receipt_path
    assert output.parent.is_dir() and receipt_path.parent.is_dir()
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    assert (head, tree) == (expected_head, expected_tree)
    assert git('branch', '--show-current').decode().strip() == 'steward/t2800-planted-standing-v16-dev-20261023'
    assert not git('diff', '--name-only', 'HEAD'), 'Tracked source differs from committed HEAD'
    assert not git('ls-files', '-u'), 'Unmerged source'
    assert not git('ls-files', '--others', '--exclude-standard'), 'Untracked source would escape commitment'
    assert subprocess.run(['git', '--no-optional-locks', '-C', str(REPO), 'rev-parse', '--verify', 'MERGE_HEAD'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode != 0
    build = json.loads((SITE / 'build.json').read_text())
    assert len(build['version']) >= 7 and head.startswith(build['version']), 'Published build is stale'
    expected_files = {}
    file_bytes = 0

    def pin(path):
        nonlocal file_bytes
        path = path.absolute()
        assert path.is_file(), path
        if str(path) not in expected_files:
            expected_files[str(path)] = digest(path)
            file_bytes += path.stat().st_size
        return expected_files[str(path)]

    assert pin(CALLER / 'capture_smoke.mjs') == CALLER_SHA
    assert pin(CALLER / 'run_owned.py') == WRAPPER_SHA
    assert pin(SUPERVISOR) == SUPERVISOR_SHA
    pin(pathlib.Path(__file__).resolve())
    pin(authorization_path)
    pin(SITE / 'build.json')
    pin(SITE / 'packs/index.json')
    pin(SITE / 'packs/1835.json')
    pack = json.loads((SITE / 'packs/1835.json').read_text())
    index = json.loads((SITE / 'packs/index.json').read_text())
    assert str(pack['year']) == '1835' and index['1835']['id'] == pack['id']
    assert pack['count'] == len(pack['files'])
    pack_paths = set()
    pack_bytes = 0
    for rel, short_sha, size in pack['files']:
        rel_path = pathlib.PurePosixPath(rel)
        assert not rel_path.is_absolute() and '..' not in rel_path.parts and rel not in pack_paths, rel
        pack_paths.add(rel)
        p = SITE / rel
        assert p.stat().st_size == size, rel
        assert pin(p).startswith(short_sha), 'Published year-pack file stale: ' + rel
        pack_bytes += size
    assert pack_bytes == pack['bytes']
    pack_id_bytes = '\n'.join(' '.join(map(str, row)) for row in pack['files']).encode()
    assert hashlib.sha256(pack_id_bytes).hexdigest()[:16] == pack['id']

    # Pin every committed app JS/vendor/CSS source used by the real mirror; do not copy.
    tracked = git('ls-files', '-z', '--', 'chicago/4d/renderers/web/js', 'chicago/4d/renderers/web/vendor', 'chicago/4d/renderers/web/css').decode().split('\0')
    for rel in filter(None, tracked):
        path = REPO / rel
        committed = git('show', head + ':' + rel)
        assert hashlib.sha256(committed).hexdigest() == pin(path), rel
    source_pairs = [
        ('renderers/web/index.html', 'walk/index.html'),
        ('data/scenes/1835.json', 'data/scenes/1835.json'),
        ('data/transport/parked/standing-horses.json', 'data/transport/parked/standing-horses.json'),
        ('data/transport/parked/horse-sevket-sidecar.json', 'data/transport/parked/horse-sevket-sidecar.json'),
        ('data/transport/parked/standing-horse-planted/export-receipt.json', 'data/transport/parked/standing-horse-planted/export-receipt.json'),
        ('data/transport/parked/standing-horse-planted/loaded129-summary.json', 'data/transport/parked/standing-horse-planted/loaded129-summary.json'),
        ('renderers/web/transport/standing-horse/horse-sevket-v16-planted-standing-v1.glb', 'walk/transport/standing-horse/horse-sevket-v16-planted-standing-v1.glb'),
    ]
    for src, published in source_pairs:
        a, b = APP / src, SITE / published
        assert published in pack_paths, published
        committed = git('show', head + ':chicago/4d/' + src)
        assert hashlib.sha256(committed).hexdigest() == pin(a), src
        pin(b)
        if src != 'renderers/web/index.html':
            assert pin(a) == pin(b), 'Published/source pair differs: ' + src
        # index.html is legitimately stamped and stripped by publish.sh; its exact
        # published bytes are independently covered by the validated complete pack.
    for rel in ['assets/authored/transport/horse_standing/horse-sevket-v16-planted-standing-v1.glb',
                'assets/authored/transport/horse_standing/planted-standing-export-receipt.json',
                'data/scene.schema.json']:
        p = APP / rel
        committed = git('show', head + ':chicago/4d/' + rel)
        assert hashlib.sha256(committed).hexdigest() == pin(p), rel
    assert pin(APP / source_pairs[-1][0]) == MODEL_SHA
    assert pin(APP / 'assets/authored/transport/horse_standing/horse-sevket-v16-planted-standing-v1.glb') == MODEL_SHA
    assert (APP / source_pairs[-1][0]).stat().st_size == 3783600
    assert pin(APP / 'data/transport/parked/standing-horse-planted/export-receipt.json') == RECEIPT_SHA
    spec = json.loads((APP / 'data/transport/parked/horse-sevket-sidecar.json').read_text())
    assert spec['runtime_asset']['sha256'] == MODEL_SHA and spec['runtime_scale_m_per_unit'] == 1 and spec['runtime_origin_m'] == [0, 0, 0]
    assert git('rev-parse', 'HEAD').decode().strip() == head and not git('diff', '--name-only', 'HEAD')
    # Freezing is separate from authorizing a browser. Default output stays HELD.
    browser_released = authorization.get('authorize_one_browser_execution', False) is True
    lane_free = authorization.get('browser_lane_free', False) is True
    assert not browser_released or lane_free
    cfg = {
        'released': browser_released, 'browser_lane_free': lane_free,
        'phase': 'yard-desktop', 'app_root': str(APP), 'site_root': str(SITE),
        'source_model': str(APP / source_pairs[-1][0]), 'source_sha256': MODEL_SHA,
        'source_head': head, 'source_staged_tree': tree,
        'published_build': build, 'complete_1835_pack_id': pack['id'],
        'expected_files': expected_files,
        'freeze_scope': 'Complete existing published1835 pack plus committed runtime source/caller/vendor and exact horse source/mirror inputs; no copied assets/images; one mobile phase only',
    }
    encoded = (json.dumps(cfg, indent=2) + '\n').encode()
    with output.open('xb') as f:
        f.write(encoded)
    receipt = {
        'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_head': head, 'source_tree': tree, 'pack_id': pack['id'],
        'pack_files': pack['count'], 'pack_bytes': pack_bytes,
        'all_pinned_files': len(expected_files), 'all_pinned_bytes': file_bytes,
        'release_path': str(output), 'release_sha256': hashlib.sha256(encoded).hexdigest(),
        'authorization_sha256': hashlib.sha256(authorization_bytes).hexdigest(),
        'browser_released': browser_released, 'phase': 'yard-desktop',
        'assets_copied': 0, 'app_writes': False, 'browser_or_launcher_executed': False,
    }
    with receipt_path.open('x') as f:
        json.dump(receipt, f, indent=2)
        f.write('\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
