# Historical wagon/carriage source audit — 2026-10-23

Scope: compact record of evidence already loaded before the G7 resource hold. This save performs no new research, browser work, model processing, or application/ticket changes. Hashing identifies available local files; it does not independently validate all their contents.

## Dearborn wagon

Juliette A. M. Kinzie, *Wau-Bun* (1856 first edition), printed p297, Chapter XXIII, “Second Sight—Hickory Creek,” describing the 1831 journey:

> Our heavy articles of furniture, trunks, &c., had been sent on board the Napoleon to be brought round to us by way of Fox River. We had retained only such few necessaries as could be conveniently carried on a pack-horse, and in a light dearborn wagon lately brought by Mr. Kercheval from Detroit (the first luxury of the kind ever seen on the prairies), and which my husband had purchased as an agreeable mode of conveyance for his mother and little nephew.

Saved source locator: Internet Archive item waubunearlydayin00kinz_0, scan0309 corresponds to printed p297; scan0314 corresponds to printed p302 (Chapter XXIV, “Return to Fort Winnebago,” travelling-horse context). OCR excerpt locator: waubun1856-ocr.txt around line11013; original scan evidence takes precedence over OCR. This record quotes the previously inspected passage, not a fresh transcription.

The passage attests a light passenger-wagon type, purchase, passengers, and arrival from Detroit. It does not name a maker or prove Detroit manufacture. “My husband” refers to John Harris Kinzie. The 1831 journey does not establish an1812 wagon or the same individual wagon in Chicago in1835. No precise model dimensions or visual identity follow from this passage.

## Era/type coverage

| Era | Existing support | What remains reconstructed or unsupported |
| --- | --- | --- |
| 1812 | Retrospective Wau-Bun1856, printed pp210/221, establishes local wagon/baggage-wagon presence. Muller1768 Treatise of Artillery pp128/131 supplies external construction comparison. | W01 is a carefully declared reconstructed family, not an attested Chicago maker/model, exact Muller military wagon, or Dearborn wagon. Muller’s 48in front/60in rear wheel example and89in wheelbase are comparator dimensions, not a specification for the existing asset. The oilcloth-roof passage belongs to the preceding powder cart, not automatically this wagon. |
| 1835 | W01 and the two covered variants are unidentified type reconstructions. Wau-Bun gives a separately attested1831 Dearborn passenger-wagon type. | Existing W01/covered assets must not be relabelled Dearborn without appearance evidence. Existing town_wagon_dearborn_* identifiers may refer to the Fort Dearborn district; identifiers alone are not type evidence. |
| 1904 | Existing research cites an1893 Studebaker catalogue for Brougham/FarmNo.4 design families before1904. | A catalogue illustration is not a dated photograph, proof of local ownership, proof of the individual parked carriage, or Pullman’s actual carriage. Current Brougham remains a reconstructed design. |

No unsupported current named-manufacturer assertion was established in the portions already loaded; this is a bounded finding, not an exhaustive metadata clearance. No present vehicle is certified photographically complete by this audit.

## Photographic-source coverage and next evidence gap

The loaded historical register reports947 Prairie records,84 inspected and863 uninspected, plus an inspected14-image register. These are recorded research counts, not a fresh archive inventory. Existing catalogue access is stronger than acquired high-resolution photographic masters; earlier acquisition failures remain failures. No newly verified, fully identified dated photographic upgrade can be named from the portions loaded. Do not turn a catalogue illustration, modern survivor, modern museum reconstruction, or reconstructed asset render into a period photograph. A specifically identified historic Chicago carriage photograph with an acquired master and date/ownership provenance would be more valuable than inventing a maker attribution.

## Provenance and limitations

The accompanying SOURCE-PINS.json lists exact available local paths and hashes captured during this checkpoint. It includes current Brougham metadata as a location pin only; that file was not exhaustively audited during the save. No network retrieval occurred. The prior source-read attempt encountered EAGAIN/resource exhaustion; no further research was launched. This packet is historical source review only, not placement/provider/render/photo qualification.
