Instructions only. No command here has run, and all inventories remain UNBOUND/released:false. ROOT must first observe G7 owner CLOSED, then commit/push/publish the actual horseHEAD and verify its exact tree. No new HEAD value is guessed here.

1. ROOT creates /tmp/ROOT-REVIEWED-MOBILE-FREEZE-AUTHORIZATION.json from the freeze_root_input inventory, fills actual committedHEAD/tree, and explicitly authorizes the freeze. To prepare an executable capture release for the later owner, ROOT must deliberately set authorize_one_browser_execution:true and browser_lane_free:true after the heavy lane is free. This writes no browser process itself; the separately bound owner release remains required.

2. Exact freezer command (external output files must be absent):

python3 /tmp/T2800-V16-YARD-MOBILE-FREEZE-BUILDER-SOURCE-HELD-20261023/freeze_one_yard_mobile.py --root-release /tmp/ROOT-REVIEWED-MOBILE-FREEZE-AUTHORIZATION.json --output-release /tmp/ROOT-NEW-DEFAULT086E-MOBILE-CAPTURE-RELEASE.json --output-receipt /tmp/ROOT-NEW-DEFAULT086E-MOBILE-BINDING-RECEIPT.json

3. ROOT reviews the actual binding receipt and output release. Use its actual release_sha256/source_head/source_tree in a new /tmp/ROOT-REVIEWED-ONE-MOBILE-OWNER.json from owner_root_input, retaining exact outer8f872213/helper60ea pins. Explicitly release only this one mobile execution in a free lane. Freeze authorization/capture release bytes and the full bound source/mirror inputs then remain unchanged.

4. Exact SINGLE owned launch command, fresh external output directories only:

python3 /tmp/T2800-V16-DEFAULT086E-WAITID-OUTER-OWNER-SOURCE-HELD-20261023/run_default086e_owned.py --root-release /tmp/ROOT-REVIEWED-ONE-MOBILE-OWNER.json --capture-release /tmp/ROOT-NEW-DEFAULT086E-MOBILE-CAPTURE-RELEASE.json --output-dir /tmp/ROOT-NEW-DEFAULT086E-MOBILE-CAPTURE --owner-log-dir /tmp/ROOT-NEW-DEFAULT086E-MOBILE-OUTER-OWNER

Do not launch d706/778 standalone, add browser flags, replace the086e caller, run desktop in this mobile authorization, reuse an output directory, or retry automatically. Original capture execution350s/inner whole360s remain exact. Outer command deadline360s plus separately recorded bounded cleanup waits never extend product time. ROOT reviews raw product/timing receipts and final kernelECHILD cleanup before any result is called green. No release is implied by these instructions.
