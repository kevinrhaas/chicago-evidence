"""HELD source: original086e/d706/778 browser unit inside ROOT's pinned60ea waitid owner.
No changed browser args/product timing. One explicit phase; no retry; no PID1 action.
"""
import argparse, datetime, hashlib, importlib.util, json, os, pathlib, sys, time, traceback

CALLER_DIR = pathlib.Path('/tmp/T2800-V16-ACTUAL-YARD-QUALIFIER-SOURCE-HELD-20261023')
CALLER = CALLER_DIR / 'capture_smoke.mjs'
INNER = CALLER_DIR / 'run_owned.py'
OLD_OWNER = pathlib.Path('/workspace/shared/horse-sevket-native-preview-source-20261022/ownership_supervisor.py')
WAITID_OWNER = pathlib.Path('/workspace/shared/owned_child_reaper_20261023.py')
PINS = {
    str(CALLER): '086eb9874d9b90792d56b7d0e7f11655f209ab98ff361ca13ffa07ad18a50d9b',
    str(INNER): 'd706e2443a93c1e6921bf84a3d32abb0fb4f74cab4b07f0667acacd5907f3bd0',
    str(OLD_OWNER): '778e5623d81821a48aeae5080a8cbff4ef57901570ceea9935fa98ecd9bd0ce5',
    str(WAITID_OWNER): '60ea8bdddc4491cdc788c2574194e2e33410c0c01c3d9a9a0c73a9751b37df2f',
}
OUTER_COMMAND_DEADLINE_S = 360  # Inner caller still execution350/whole360, byte exact.


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def external(path):
    p = path.resolve()
    assert p.is_relative_to('/tmp') or p.is_relative_to('/workspace/shared'), p
    assert not p.is_relative_to('/workspace/chicago-waistcoat'), p
    return p


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-release', required=True)
    parser.add_argument('--capture-release', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--owner-log-dir', required=True)
    args = parser.parse_args()
    root_path = pathlib.Path(args.root_release).resolve()
    capture_path = pathlib.Path(args.capture_release).resolve()
    root_bytes = root_path.read_bytes()
    release = json.loads(root_bytes)
    capture_bytes = capture_path.read_bytes()
    capture = json.loads(capture_bytes)
    assert release['authorization'] == 'ONE_ORIGINAL086E_V16_YARD_PHASE_UNDER_ROOT60EA_WAITID'
    assert release['released'] is True and release['heavy_lane_free'] is True
    assert release['phase'] in ('yard-mobile', 'yard-desktop')
    assert capture['phase'] == release['phase'] and capture['released'] is True and capture['browser_lane_free'] is True
    assert hashlib.sha256(capture_bytes).hexdigest() == release['capture_release_sha256']
    assert capture['source_head'] == release['expected_committed_head']
    assert capture['source_staged_tree'] == release['expected_committed_tree']
    assert len(capture['source_head']) == len(capture['source_staged_tree']) == 40
    assert sha(pathlib.Path(__file__).resolve()) == release['outer_wrapper_sha256']
    assert release['waitid_owner_sha256'] == PINS[str(WAITID_OWNER)]
    for path, pin in PINS.items():
        assert sha(pathlib.Path(path)) == pin, path
        if path != str(WAITID_OWNER):
            assert capture['expected_files'][path] == pin, path
    assert not capture.get('launcher_resource_fallback'), 'Original-default unit only; no fallback flags/settings'
    out = external(pathlib.Path(args.output_dir))
    logs = external(pathlib.Path(args.owner_log_dir))
    inner_logs = out.with_name(out.name + '-terminal')
    assert not out.exists() and not logs.exists() and not inner_logs.exists(), 'Fresh output required; no retry'
    assert out != logs and not logs.is_relative_to(out) and not out.is_relative_to(logs)
    assert out.parent.is_dir() and logs.parent.is_dir()
    logs.mkdir()
    spec = importlib.util.spec_from_file_location('root60ea_owned_child_reaper', WAITID_OWNER)
    owner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owner)
    owner.enable()  # Must precede starting even the historical inner Python owner.
    command = [sys.executable, str(INNER), '--lane-released', '--phase', capture['phase'],
               '--release-file', str(capture_path), '--output-dir', str(out)]
    started = now()
    timer = time.monotonic()
    intent = {
        'started': started, 'owner_pid': os.getpid(), 'phase': capture['phase'],
        'command': command, 'source_head': capture['source_head'], 'source_tree': capture['source_staged_tree'],
        'root_release_sha256': hashlib.sha256(root_bytes).hexdigest(),
        'capture_release_sha256': hashlib.sha256(capture_bytes).hexdigest(),
        'pins': PINS, 'outer_wrapper_sha256': sha(pathlib.Path(__file__).resolve()),
        'inner_execution_deadline_s': 350, 'inner_whole_deadline_s': 360,
        'outer_command_deadline_s': OUTER_COMMAND_DEADLINE_S,
        'outer_cleanup_wait_windows_s': {'main_TERM': 3, 'adopted_TERM': 3, 'adopted_KILL': 2},
        'product_deadlines_widened': False, 'no_PID1_action': True,
        'environment_readonly': {k: os.environ.get(k) for k in
            ('PATH', 'CHECK_JOBS', 'NODE_OPTIONS', 'UV_THREADPOOL_SIZE', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')},
    }
    (logs / 'INTENT.json').write_text(json.dumps(intent, indent=2) + '\n')
    print(json.dumps(intent), flush=True)
    result = None
    error = None
    cleanup = None
    terminal = None
    kernel_no_children = False
    try:
        result = owner.run(command, cwd=str(CALLER_DIR), env=os.environ.copy(),
                           log=logs / 'INNER-WRAPPER.stdout-stderr.log', timeout=OUTER_COMMAND_DEADLINE_S)
        assert result['returncode'] == 0, 'Original inner unit returned nonzero'
        historical = json.loads((inner_logs / 'terminal.json').read_text())
        assert historical['exit_code'] == 0, 'Historical inner receipt did not pass'
        assert historical['whole_deadline_seconds'] == 360 and historical['execution_timeout_seconds'] == 350
        product = json.loads((out / 'receipt.json').read_text())
        assert product['phase'] == capture['phase'] and product['pass'] is True and product['closed'] is True
        assert product['inputs_unchanged'] is True and product['product_checks_status'] == 'PASS'
        assert product['original_timing_check']['status'] == 'PASS', 'Timing failure cannot become a pass'
        assert all(row['status'] == 'PASS' for row in product['product_checks'].values())
        for path, pin in PINS.items():
            assert sha(pathlib.Path(path)) == pin, path
        assert sha(capture_path) == intent['capture_release_sha256']
    except BaseException as exc:
        error = repr(exc)
        (logs / 'ERROR.txt').write_text(traceback.format_exc())
    finally:
        # Kernel waitid cleanup/authority covers children adopted when old inner owner exits.
        cleanup = owner.finish()
        late_reaped = owner.reap_orphans()
        cleanup['late_owned_orphans_reaped'] = late_reaped
        try:
            event = os.waitid(os.P_ALL, 0, os.WEXITED | os.WNOHANG | os.WNOWAIT)
            # None means children still exist but none exited. Neither case is clean.
            cleanup['kernel_final_event'] = None if event is None else {
                'pid': event.si_pid, 'code': event.si_code, 'status': event.si_status}
        except ChildProcessError:
            kernel_no_children = True
        status = 'PASS' if error is None and not cleanup['remaining_owned_children'] and kernel_no_children else 'FAIL'
        terminal = {
            'status': status, 'started': started, 'finished': now(), 'seconds': time.monotonic() - timer,
            'phase': capture['phase'], 'source_head': capture['source_head'], 'source_tree': capture['source_staged_tree'],
            'main_result': result, 'error': error, 'cleanup': cleanup,
            'kernel_ECHILD_proves_no_remaining_owned_children': kernel_no_children,
            'historical_inner_receipt': str(inner_logs / 'terminal.json'),
            'product_receipt': str(out / 'receipt.json'), 'no_automatic_retry': True,
            'only_new_own_children_touched': True, 'PID1_or_other_agent_children_touched': False,
            'inner350_360_deadlines_preserved': True,
        }
        (logs / 'TERMINAL.json').write_text(json.dumps(terminal, indent=2) + '\n')
        print(json.dumps(terminal), flush=True)
    return 0 if terminal['status'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
