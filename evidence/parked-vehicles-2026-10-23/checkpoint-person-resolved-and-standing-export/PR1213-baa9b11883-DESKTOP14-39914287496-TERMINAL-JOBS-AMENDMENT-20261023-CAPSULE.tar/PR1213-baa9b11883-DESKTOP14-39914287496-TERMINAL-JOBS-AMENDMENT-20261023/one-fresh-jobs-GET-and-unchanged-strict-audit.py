import pathlib,json,subprocess,hashlib,sys,re,base64,datetime
OUT=pathlib.Path(__file__).resolve().parent
OLD=pathlib.Path('/workspace/shared/PR1213-AFFECTED14-4_13-baa9b11883-GET-owner2')
HELPER=pathlib.Path('/workspace/shared/PR1213-A22CA758-ACTUAL-RELEASED-COLLECTORS-20261023/AFFECTED4-READONLY-CONTINUATION2')
sys.path.insert(0,str(HELPER));from strict_helpers import need,audit_job,checkout_sha,smoke_cell
sha=lambda b:hashlib.sha256(b).hexdigest()
need(sha((HELPER/'strict_helpers.py').read_bytes())=='5d2bd671a0c292dcdb3a4fe251d6f138b44061c6ecc778373a0948f526f20fe7','Unchanged strict helper required')
r=subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/actions/runs/39914287496/attempts/1/jobs?per_page=100'],capture_output=True,timeout=45)
(OUT/'ACTUAL-FRESH-JOBS.stdout').write_bytes(r.stdout);(OUT/'ACTUAL-FRESH-JOBS.stderr').write_bytes(r.stderr)
(OUT/'ACTUAL-ONE-GET-RECEIPT.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'endpoint':'actions/runs/39914287496/attempts/1/jobs?per_page=100','exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'GETs':1,'POSTs':0,'retry':False},indent=2)+'\n')
need(r.returncode==0,'Fresh jobsGET failed; no retry')
fresh=json.loads(r.stdout);need(fresh['total_count']==len(fresh['jobs'])==1,'Unexpected fresh jobinventory');job=fresh['jobs'][0]
run=json.loads((OLD/'RUN-39914287496.json').read_bytes());need(run['id']==39914287496 and run['conclusion']=='success' and run['head_sha']=='baa9b11883e224d2d1c6a69fd71de9377cba1382' and run['run_attempt']==1 and run['workflow_id']==365585058,'Run identity/conclusion differs')
logs=list(OLD.glob('*job-120284189846-log.stdout'));need(len(logs)==1,'Unique prior exactactualrawlog required');raw=logs[0].read_bytes();need(sha(raw)=='6a0940aa8cdaf08562836cd143b2263a363b8062c8b824d3ede764b1630ec275','Actual rawlog pin differs');log=raw.decode()
workflow=json.loads((OLD/'0005-source-workflow.stdout').read_bytes());need(sha(base64.b64decode(workflow['content']))=='00ae307ad6cbeb556ddd5028668ee53a839393c619cc52ae5d0e8f39eb84ec52','Workflow pin differs')
commit=json.loads((OLD/'0002-source-commit.stdout').read_bytes());need(commit['tree']['sha']=='fa427eb201de4bad4b7265313fcc5a422f440ea4' and [p['sha']for p in commit['parents']]==['5135fb7674eea8cf5b140a7cf0c8bc208b0b1f4e','a22ca758323e6e2f1ed9f3909a88fb98636be55c'],'Immutable checkouttree/parents differ')
STEPS=['Set up job','Run actions/checkout@v4','Run actions/setup-node@v4','Install Playwright','Publish the mirror the smoke serves (site/4d/ is generated)','Run the smoke against the published mirror','Complete job']
proof=audit_job(job,run,run['head_sha'],'smoke',STEPS);checkout=checkout_sha(log,run['head_sha']);cell=smoke_cell(log);need(cell==('desktop','14'),'Actual cell differs')
counts=re.findall(r'(?m)^\S+Z\s+(\d+) passed, 0 failed\s*$',log);need(len(counts)==1 and int(counts[0])>0,'Nonzero unambiguous0failures required')
prior=json.loads((OLD/'FAILURE-39914287496.json').read_bytes());need(prior['failure']=='Job did not succeed' and not prior['causal_lines'],'Expected staleinventoryrefusal notactualsmokefailure')
proof.update({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_LATER_TERMINAL_JOBS_AMENDMENT_STRICT_PASS','actual_checkout_sha':checkout,'actual_tree':commit['tree']['sha'],'actual_parents':[p['sha']for p in commit['parents']],'viewport':cell[0],'stage':cell[1],'passed_assertions':int(counts[0]),'failed_assertions':0,'actual_smoke_step_terminal_success_exit0':True,'job_log_sha256':sha(raw),'strict_helper_sha256':sha((HELPER/'strict_helpers.py').read_bytes()),'original_observation':'Prior jobsAPI inventory had in_progress/null while runsuccess andallstepscompleted. Original collectorrefusal retained immutable; thisonefresh terminaljobsGET supplies latercompletion evidence.','no_browser_rerun':True,'POSTs':0,'active_collector_NOT_modified':True,'wholebatch_or_finalmerge_PASS':False})
(OUT/'ACTUAL-STRICT-TERMINAL-AMENDMENT.json').write_text(json.dumps(proof,indent=2)+'\n')
for n in ['RUN-39914287496.json','RUN-39914287496-JOBS.json','FAILURE-39914287496.json','0002-source-commit.stdout','0005-source-workflow.stdout']:(OUT/('PRIOR-'+n)).write_bytes((OLD/n).read_bytes())
(OUT/'ACTUAL-ORIGINAL-JOB-LOG.stdout').write_bytes(raw)
print(json.dumps(proof,indent=2))
