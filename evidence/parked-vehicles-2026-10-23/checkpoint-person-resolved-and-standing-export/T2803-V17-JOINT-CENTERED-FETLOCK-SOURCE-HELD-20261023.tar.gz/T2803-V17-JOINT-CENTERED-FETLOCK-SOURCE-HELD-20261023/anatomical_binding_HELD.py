"""HELD one joint-centered cannon/fetlock attachment; no solve/tuning/export.

Immutable V16 upper/source-protected/tail/rigid hoof rows. Only incoming c to
outgoing d/e distribution changes around their shared anatomical pivot d.
"""
from pathlib import Path
import hashlib,json,sys
import numpy as np
HERE=Path(__file__).resolve().parent
OUT=HERE/'ACTUAL'
EPS=1e-10

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def h5(u):return u*u*u*(10+u*(-15+6*u))
def original_joint_ownership(w):
    own=w[:,2:6].max(1);other=w[:,[0,1]+list(range(6,26))].max(1)
    return own>other,(own==other)&(own>0)

def build(rest,parts,controls,hoof_patch_ids):
    release=json.loads(Path(sys.argv[1]).read_text())
    assert release['released'] is True and release['authorization']=='ONE_ROOT_AUTHORIZED_V17_JOINT_CENTERED_FETLOCK_ORIGINAL65'
    for name,digest in release['source_sha256'].items():assert sha(HERE/name)==digest,name+' drift'
    pins=json.loads((HERE/'INPUT-PINS.json').read_text())
    for key,row in pins.items():assert sha(row['path'])==row['sha256'],key+' drift'
    prior=json.loads(Path(pins['v16_field_receipt']['path']).read_text())
    assert prior['original_protected_vectors_exact'] and prior['original_lower_field_bits_exact']
    assert prior['profile_gait_threshold_changes'] is False and prior['field_constructions']==1 and prior['tail_vertices_bits_exact']==969
    terminal=json.loads(Path(pins['v16_terminal']['path']).read_text());assert terminal['no_owned_child_active'] and terminal['status']=='ORIGINAL65_ANATOMICAL_DIAGNOSTIC_FAIL_NO_RETRY'
    with np.load(pins['phase_a_arrays']['path'],allow_pickle=False) as f:
        points=f['points_m'].copy();vc=[f['vertex_classes_'+str(i)].copy() for i in range(3)];protected_ids=f['source_protected_class_ids'].copy()
    n=len(points);protected=np.zeros(n,dtype=bool);protected[protected_ids]=True
    assert all(np.array_equal(points[vc[mi]],p) for mi,p in enumerate(rest))
    with np.load(pins['v16_arrays']['path'],allow_pickle=False) as f:
        arrays=[(f['mesh_'+str(mi)+'_joints'].copy(),f['mesh_'+str(mi)+'_weights'].copy()) for mi in range(3)]
    assert all(j.dtype==np.uint16 and w.dtype==np.float32 and j.shape==w.shape==(len(rest[mi]),4) for mi,(j,w) in enumerate(arrays))
    originals=[(j.copy(),w.copy()) for j,w in arrays]
    v12=json.loads(Path(pins['v12_report']['path']).read_text())
    planes=json.loads((HERE/'RECONSTRUCTED-ANATOMY-AND-PROFILE-INPUTS.json').read_text())['section_scheme']['planes_per_limb']
    pastern_handle=planes['H_d_pastern_handle'];hoof_handle=planes['H_e_candidate_coronet']
    v12_added={r['class'] for r in v12['V10_only_reclassification_ledger']}
    changed=np.zeros(n,dtype=bool);new_dense=np.zeros((n,26));all_cap=np.zeros(n,dtype=bool);all_lower=np.zeros(n,dtype=bool)
    receipts=[];ledger=[]
    for label,limb in controls['limbs'].items():
        a,b,c,d,e=limb['joints'];pc=np.asarray(controls['nodes'][c]['rest_world_pivot_m']);pd=np.asarray(controls['nodes'][d]['rest_world_pivot_m']);pe=np.asarray(controls['nodes'][e]['rest_world_pivot_m'])
        cannon_length=float(np.linalg.norm(pd-pc));pastern_length=float(np.linalg.norm(pe-pd));axis=(pd-pc)/cannon_length
        C=np.zeros(n,dtype=bool);C[v12['regions'][label+':H_c_cannon_handle']['class_ids']]=True
        E=np.zeros(n,dtype=bool);E[v12['regions'][label+':H_e_candidate_coronet']['class_ids']]=True
        assert E.any() and not (E&~C).any()
        all_cap|=E;all_lower|=C
        cap_projection=(points[E]-pd)@axis
        first_cap=float(cap_projection.min())
        # ONE rest-derived extent, not a swept/tuned width: stay entirely before
        # frozen hoof cap and no wider than actual outgoing pastern link.
        assert cannon_length>EPS and pastern_length>EPS and first_cap>EPS, 'Rig/hoof cap intersects joint; no geometric fallback'
        radius=min(first_cap,pastern_length)
        assert radius<cannon_length, 'Invalid local joint envelope; no clamp'
        active=C&~E
        assert not (active&protected).any(), 'Original protected row enters proposed deforming fetlock region'
        assert not (active&changed).any(), 'Named limb regions overlap'
        ids=np.flatnonzero(active);assert len(ids)>0
        signed=(points[ids]-pd)@axis
        alpha=np.zeros(len(ids));alpha[signed>=radius]=1
        middle=(signed>-radius)&(signed<radius);u=(signed[middle]+radius)/(2*radius)
        assert np.all((u>0)&(u<1));alpha[middle]=h5(u)
        # Analytic piecewise C2 transition, NOT numerical weight clipping.
        c_weight=1-alpha
        y=points[ids,1];assert (y>hoof_handle).all()
        e_fraction=np.zeros(len(ids));pastern=y<pastern_handle
        eu=(pastern_handle-y[pastern])/(pastern_handle-hoof_handle);assert np.all((eu>0)&(eu<1));e_fraction[pastern]=h5(eu)
        authored=np.zeros((len(ids),26));authored[:,c]=c_weight;authored[:,d]=alpha*(1-e_fraction);authored[:,e]=alpha*e_fraction
        assert np.isfinite(authored).all() and (authored>=0).all() and (authored<=1).all()
        assert np.abs(authored.sum(1)-1).max()<=1e-8
        assert np.any(authored[:,d]>0), 'No actual source vertices support pastern articulation; retopology review needed, no widening'
        assert np.all((authored>0).sum(1)<=3)
        new_dense[ids]=authored;changed[ids]=True
        receipts.append({'limb':label,'cannon_axis_distal':axis.tolist(),'shared_fetlock_pivot_m':pd.tolist(),'actual_cannon_length_m':cannon_length,'actual_pastern_length_m':pastern_length,'first_frozen_hoof_projection_m':first_cap,'derived_symmetric_half_extent_m':radius,'upper_envelope_m':(pd-radius*axis).tolist(),'lower_envelope_m':(pd+radius*axis).tolist(),'classes':ids.tolist(),'candidate_support_counts':{str(j):int(np.count_nonzero(authored[:,j])) for j in (c,d,e)}})
    assert not (changed&protected).any() and not (changed&all_cap).any()
    ids=np.flatnonzero(changed);assert len(ids)>0
    authored=new_dense[ids];cast=authored.astype(np.float32)
    joints=np.zeros((len(ids),4),dtype=np.uint16);weights=np.zeros((len(ids),4),dtype=np.float32)
    for row,ci in enumerate(ids):
        palette=np.flatnonzero(authored[row]>0);joints[row,:len(palette)]=palette;weights[row,:len(palette)]=cast[row,palette]
        vertices=np.flatnonzero(vc[1]==ci);assert len(vertices)>0
        before=np.zeros(26,dtype=np.float32)
        vi=int(vertices[0]);np.add.at(before,originals[1][0][vi],originals[1][1][vi])
        ledger.append({'class':int(ci),'body_source_vertices':vertices.tolist(),'before_V16_f32_dense':before.tolist(),'after_authored_f64_dense':authored[row].tolist(),'was_V12_added_pastern_anchor':int(ci) in v12_added,'original_protected':False})
    lookup=np.full(n,-1,dtype=int);lookup[ids]=np.arange(len(ids))
    for mi,classes in enumerate(vc):
        selected=changed[classes];rows=lookup[classes[selected]]
        arrays[mi][0][selected]=joints[rows];arrays[mi][1][selected]=weights[rows]
        frozen=(~changed[classes])|protected[classes]|all_cap[classes]
        assert np.array_equal(arrays[mi][0][frozen],originals[mi][0][frozen])
        assert np.array_equal(arrays[mi][1][frozen].view(np.uint32),originals[mi][1][frozen].view(np.uint32))
        # Every V16 upper row remains bit-exact; no reauthoring/body changes.
        assert np.array_equal(arrays[mi][0][~all_lower[classes]],originals[mi][0][~all_lower[classes]])
        assert np.array_equal(arrays[mi][1][~all_lower[classes]].view(np.uint32),originals[mi][1][~all_lower[classes]].view(np.uint32))
    for label,patch in hoof_patch_ids.items():
        e=controls['limbs'][label]['joints'][-1];j,w=arrays[1]
        assert np.all(np.where(j[patch]==e,w[patch],0).sum(1)==1)
    # Finite synthetic immutable-row controls, no second field or pose grid.
    immutable_body=protected[vc[1]]|all_cap[vc[1]]|(~all_lower[vc[1]])
    first=int(np.flatnonzero(immutable_body)[0]);bad=arrays[1][1].copy();bad[first]*=.5
    assert not np.array_equal(bad[immutable_body].view(np.uint32),originals[1][1][immutable_body].view(np.uint32))
    cap_vertex=int(np.flatnonzero(all_cap[vc[1]])[0]);bad=arrays[1][1].copy();bad[cap_vertex]*=.5
    assert not np.array_equal(bad[all_cap[vc[1]]].view(np.uint32),originals[1][1][all_cap[vc[1]]].view(np.uint32))
    receipt={'status':'ONE_JOINT_CENTERED_FETLOCK_FIELD_ONLY_NO_ACCEPTANCE','source_V16_arrays_sha256':pins['v16_arrays']['sha256'],'original_protected_vectors_exact':True,'tail_vertices_bits_exact':969,'V16_upper_field_bits_exact':True,'rigid_hoof_cap_bits_exact':True,'field_constructions':1,'changed_lower_classes':len(ids),'joint_envelopes':receipts,'explicit_lower_reclassification_ledger':ledger,'updated_row_float32_casts':1,'clipping_pruning_or_renormalization':False,'maximum_updated_cast_error':float(np.abs(cast.astype(float)-authored).max()),'negative_controls':{'immutable_source_row_corruption_rejected':True,'rigid_hoof_corruption_rejected':True},'profile_gait_threshold_changes':False,'solvers':0,'exports':0,'prior_V16_WALK_FAIL_preserved':True,'scope':'One geometric joint-centered incomingc/outgoingd-e partition. Shared-pivot affine agreement is exact kinematic algebra, not a global posed skin-strain guarantee.'}
    np.savez_compressed(OUT/'DIAGNOSTIC-FLOAT32-ANATOMICAL-ARRAYS-NOT-MODEL.npz',**{'mesh_'+str(mi)+'_'+key:value for mi,pair in enumerate(arrays) for key,value in [('joints',pair[0]),('weights',pair[1])]})
    (OUT/'ANATOMICAL-BIND-SERIALIZATION-READBACK.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return arrays,receipt
