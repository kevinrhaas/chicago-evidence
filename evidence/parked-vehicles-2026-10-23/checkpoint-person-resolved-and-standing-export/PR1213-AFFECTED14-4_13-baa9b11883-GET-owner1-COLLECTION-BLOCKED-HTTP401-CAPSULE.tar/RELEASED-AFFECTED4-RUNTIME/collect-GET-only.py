"""Root-released affected14/4,13 four-cell batch GET collection; never whole-batch/finalmerge qualification."""
import argparse,base64,datetime,hashlib,json,os,pathlib,re,subprocess,time
from strict_helpers import need,smoke_cell,audit_job,checkout_sha,RANGES
HERE=pathlib.Path(__file__).resolve().parent
OUT=None
RECEIPT=None
HEAD=None
TREE=None
BRANCH=None
SMOKE='.github/workflows/chicago-4d-smoke.yml'
STEPS=['Set up job','Run actions/checkout@v4','Run actions/setup-node@v4','Install Playwright','Publish the mirror the smoke serves (site/4d/ is generated)','Run the smoke against the published mirror','Complete job']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save(path,value):
 tmp=path.with_suffix(path.suffix+'.new');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def expand(stage):
 need(stage in ['14','4,13'],'Unexpected affected-stage scope')
 parts=[]
 for token in stage.split(','):
  match=re.fullmatch(r'(\d+)(?:-(\d+))?',token.strip());need(match is not None,'Invalid canonical stage token')
  lo=int(match[1]);hi=int(match[2]or match[1]);need(1<=lo<=hi<=15,'Invalid canonical stage bounds');parts.extend(range(lo,hi+1))
 need(len(parts)==len(set(parts)),'Overlapping canonical stage set');return parts
def main():
 global OUT,RECEIPT,HEAD,TREE,BRANCH
 parser=argparse.ArgumentParser();parser.add_argument('--receipt',required=True,type=pathlib.Path);args=parser.parse_args();RECEIPT=args.receipt
 actual=json.loads(RECEIPT.read_bytes());need(actual.get('dispatch_complete')is True and actual.get('root_dispatch_release_status')=='ROOT_RELEASED_PR1213_AFFECTED14_AND4_13_FOUR','HELD: no actual released complete four-request receipt');HEAD=actual['source_head'];TREE=actual['source_integration_tree'];BRANCH=actual['verification_ref'];OUT=pathlib.Path('/workspace/shared/PR1213-AFFECTED14-4_13-'+HEAD[:10]+'-GET-owner1')
 need(all(re.fullmatch('[0-9a-f]{40}',x)for x in [HEAD,TREE,*actual['source_integration_parents']]),'Actual source pins must be full immutableSHAs')
 need(actual['repository']=='kevinrhaas/chicago'and actual['pr']==1213,'Wrong repository/PR receipt')
 need(isinstance(actual['pr_source_parents'],list)and len(actual['pr_source_parents'])in[1,2]and all(isinstance(x,str)and re.fullmatch('[0-9a-f]{40}',x)for x in [actual['pr_source_head'],actual['pr_source_tree'],actual['integrated_dev'],actual['expected_owned_lease'],*actual['pr_source_parents']]),'Unknown immutable PRsource/base/lease pins')
 need(actual['source_integration_parents']==[actual['integrated_dev'],actual['pr_source_head']]and HEAD!=actual['pr_source_head'],'Actual testmerge/PRsource/base binding differs')
 need(not actual['pr_source_head'].startswith('0be5')and actual['pr_source_head']not in['cbb94c2d46223e4ca75fc4b02560f43c4de2e710','13375406538e76e8c1deadf18165089f7145ea28'],'Historical source cannot qualify next source')
 need(actual['collector_sha256']==sha(pathlib.Path(__file__).read_bytes())and actual['strict_helper_sha256']==sha((HERE/'strict_helpers.py').read_bytes()),'Collector/strict helper byte pins differ')
 need(isinstance(actual['smoke_source_sha256'],str)and re.fullmatch('[0-9a-f]{64}',actual['smoke_source_sha256'])and isinstance(actual['smoke_source_git_blob_sha1'],str)and re.fullmatch('[0-9a-f]{40}',actual['smoke_source_git_blob_sha1']),'Actual new whole-smoke/Gitblob pins missing')
 d=json.loads(RECEIPT.read_bytes());selected={r['id']for r in d['runs']};cells={(v,s)for v in ['desktop','mobile']for s in ['14','4,13']}
 need(d['repository']=='kevinrhaas/chicago'and d['verification_ref']==BRANCH and d['source_head']==HEAD and d['source_integration_tree']==TREE and d['dispatch_complete'],'Actual integration receipt binding changed')
 need(len(selected)==len(d['runs'])==len(d['dispatches'])==4 and all(x['post_succeeded']for x in d['dispatches']),'Exactly4 accepted/discovered requests required')
 need({(x['viewport'],x['stage'])for x in d['dispatches']}==cells,'Declared4 coverage differs')
 need(all(r['head_sha']==HEAD and r['head_branch']==BRANCH and r['event']=='workflow_dispatch'and r['path']==SMOKE and r['run_attempt']==1 for r in d['runs']),'Receipt selected identity differs')
 need(d['workflow_sha256']=='00ae307ad6cbeb556ddd5028668ee53a839393c619cc52ae5d0e8f39eb84ec52','Dispatch workflow pin mismatch')
 workflow_sha='00ae307ad6cbeb556ddd5028668ee53a839393c619cc52ae5d0e8f39eb84ec52'
 lock=pathlib.Path(str(OUT)+'.lock');lock.mkdir(exist_ok=False);OUT.mkdir(exist_ok=False)
 start=time.monotonic();deadline=start+180*60;counter=0;audited={};bound={};warned=set()
 state={'status':'GET_COLLECTING_PR1213_AFFECTED14_4_13_FOUR','started':now(),'observer_pid':os.getpid(),'head':HEAD,'tree':TREE,'branch':BRANCH,'source_integration_parents':d['source_integration_parents'],'dispatch_receipt_sha256':sha(RECEIPT.read_bytes()),'collector_sha256':sha(pathlib.Path(__file__).read_bytes()),'strict_helper_sha256':sha((HERE/'strict_helpers.py').read_bytes()),'workflow_sha256':workflow_sha,'workflow_id':365585058,'poll_seconds':60,'maximum_minutes':180,'deadline_utc':(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=180)).isoformat(),'POSTs':0,'reruns':0,'cancellations':0,'qualification_pass':False,'current_final_head_qualified':False,'snapshot_batch_pass':False,'scope':'Exactly desktop/mobile14 and canonical4,13 at the actual immutable next PR1213 GitHub testmerge. No broad18/whole15/current-final-head qualification. Prior133 normal2PASS1FAIL and public-world timeoutFAIL remain unchanged. Root owns latest-base projection/world/card/merge.'}
 save(OUT/'OWNER.json',state);save(lock/'OWNER.json',{'pid':os.getpid(),'output':str(OUT),'started':state['started']});print(json.dumps({'owner_pid':os.getpid(),'output':str(OUT),'status':state['status']}),flush=True)
 def api(label,endpoint,plain=False):
  nonlocal counter
  need(time.monotonic()<deadline,'180min collection deadline reached');counter+=1;stem=OUT/('%04d-%s'%(counter,label))
  r=subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/'+endpoint],capture_output=True,timeout=45)
  stem.with_suffix('.stdout').write_bytes(r.stdout);stem.with_suffix('.stderr').write_bytes(r.stderr)
  with (OUT/'GET-ATTEMPTS.jsonl').open('a')as f:f.write(json.dumps({'at':now(),'endpoint':endpoint,'returncode':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'retry':False})+'\n')
  need(r.returncode==0,'GET unavailable; preserve and stop without automatic retry: '+label+' '+r.stderr.decode(errors='replace')[-500:])
  return r.stdout.decode()if plain else json.loads(r.stdout)
 listing={'workflow_runs':[]};cached={}
 try:
  pr_source=api('pr-source-commit','git/commits/'+d['pr_source_head']);need(pr_source['tree']['sha']==d['pr_source_tree'] and [x['sha']for x in pr_source['parents']]==d['pr_source_parents'],'PR source checkpoint identity differs')
  commit=api('source-commit','git/commits/'+HEAD);need(commit['tree']['sha']==TREE and [x['sha']for x in commit['parents']]==d['source_integration_parents'],'Actual sourcecommit tree/parents mismatch')
  need(api('initial-verification-ref','git/ref/heads/'+BRANCH)['object']['sha']==HEAD,'Immutable verificationref differs')
  workflow=api('workflow-metadata','actions/workflows/chicago-4d-smoke.yml');need(workflow['id']==365585058 and workflow['path']==SMOKE and workflow['state']=='active','Actual workflowidentity differs')
  content=api('source-workflow','contents/'+SMOKE+'?ref='+HEAD);need(content['encoding']=='base64' and sha(base64.b64decode(content['content']))==workflow_sha,'Actual source workflowbytes differ')
  smoke_source=api('source-smoke','contents/chicago/4d/tools/smoke_renderer.mjs?ref='+HEAD);need(smoke_source['sha']==d['smoke_source_git_blob_sha1'],'Exact smoke source/assertions differ')
  while time.monotonic()<deadline:
   tick=time.monotonic()
   for ident in sorted(selected):
    if ident not in audited:cached[ident]=api('run-'+str(ident),'actions/runs/'+str(ident))
   listing={'total_count':len(cached),'workflow_runs':list(cached.values())}
   need(listing['total_count']==len(listing['workflow_runs']),'Incomplete smoke workflow inventory')
   byid={r['id']:r for r in listing['workflow_runs']};need(selected<=set(byid),'A dispatched run disappeared; no redispatch')
   extras=[{k:r.get(k)for k in ['id','event','head_sha','head_branch','status','conclusion']}for r in byid.values()if r['id']not in selected]
   for x in extras:
    if x['id']not in warned:print(json.dumps({'ALERT':'UNEXPECTED_VERIFICATION_REF_WORKFLOW_DO_NOT_CANCEL','run':x,'at':now()}),flush=True);warned.add(x['id'])
   for ident in sorted(selected):
    r=byid[ident];need(r['head_sha']==HEAD and r['head_branch']==BRANCH and r['event']=='workflow_dispatch'and r['path']==SMOKE and r['workflow_id']==365585058 and r['run_attempt']==1 and r['repository']['full_name']=='kevinrhaas/chicago','Selected run identity/attempt drift')
    if ident in audited or r['status']!='completed':continue
    jobs=api('jobs-'+str(ident),'actions/runs/'+str(ident)+'/attempts/1/jobs?per_page=100');save(OUT/('RUN-'+str(ident)+'-JOBS.json'),jobs)
    need(jobs['total_count']==len(jobs['jobs'])==1,'Unexpected actual smoke job inventory')
    job=jobs['jobs'][0];log=api('job-'+str(job['id'])+'-log','actions/jobs/'+str(job['id'])+'/logs',True)
    save(OUT/('RUN-'+str(ident)+'.json'),r)
    proof={'run_id':ident,'job_id':job['id'],'run_conclusion':r['conclusion'],'head':HEAD,'workflow_path':SMOKE,'workflow_id':365585058,'event':r['event'],'run_attempt':1,'job_log_sha256':sha(log.encode()),'PASS':False}
    raw_viewports=re.findall(r'(?m)^\S+Z\s+SMOKE_VIEWPORT:\s*(\S+)\s*$',log);raw_stages=re.findall(r'(?m)^\S+Z\s+SMOKE_STAGE:\s*(\S+)\s*$',log)
    if len(raw_viewports)==len(raw_stages)==1:proof.update({'actual_step_env_viewport':raw_viewports[0],'actual_step_env_stage':raw_stages[0]})
    try:
     proof['actual_checkout_sha']=checkout_sha(log,HEAD)
     need(r['conclusion']=='success','Actual workflow conclusion '+str(r['conclusion']))
     proof.update(audit_job(job,r,HEAD,'smoke',STEPS));cell=smoke_cell(log);checkout=checkout_sha(log,HEAD)
     counts=re.findall(r'(?m)^\S+Z\s+(\d+) passed, 0 failed\s*$',log);need(len(counts)==1 and int(counts[0])>0,'Missing/ambiguous nonzero terminal count with0failures')
     need(cell not in bound,'Duplicate actual log-bound cell');bound[cell]=ident
     proof.update({'viewport':cell[0],'stage':cell[1],'actual_checkout_sha':checkout,'passed_assertions':int(counts[0]),'failed_assertions':0,'actual_smoke_step_terminal_success_exit0':True,'covered_stages':expand(cell[1]),'PASS':True})
    except Exception as error:
     proof['PASS']=False;proof['failure']=str(error);proof['causal_lines']=[x for x in log.splitlines()if re.search(r'\bfail\b|\bFAIL\b|Error:|AssertionError|exit code',x)][-60:]
     save(OUT/('FAILURE-'+str(ident)+'.json'),proof)
     print(json.dumps({'ALERT':'ACTUAL_SMOKE_FAILURE_OR_BINDING_REFUSAL','proof':proof,'at':now()}),flush=True)
    audited[ident]=proof;save(OUT/'AUDITED-JOBS.json',list(audited.values()))
    print(json.dumps({'at':now(),'new_terminal_run':ident,'PASS':proof['PASS'],'viewport':proof.get('viewport'),'stage':proof.get('stage'),'failure':proof.get('failure')}),flush=True)
   success=sum(x['PASS']for x in audited.values());failed=len(audited)-success
   state.update({'at':now(),'selected_success':success,'selected_failed_or_refused':failed,'selected_terminal_collected':len(audited),'selected_queued':sum(byid[i]['status']=='queued'for i in selected),'selected_active':sum(byid[i]['status']=='in_progress'for i in selected),'bound_cells':[{'viewport':v,'stage':s,'run_id':i}for(v,s),i in sorted(bound.items())],'unexpected_workflows':extras,'runs':[{k:byid[i].get(k)for k in ['id','status','conclusion','created_at','run_started_at']}for i in sorted(selected)],'api_requests':counter})
   save(OUT/'LATEST.json',state);summary=(success,failed,state['selected_queued'],state['selected_active'],len(extras))
   print(json.dumps({'at':state['at'],'strict_snapshot_success':success,'failed_or_refused':failed,'terminal_collected':len(audited),'queued':summary[2],'active':summary[3],'unexpected':len(extras),'current_final_head_qualified':False}),flush=True)
   if len(audited)==4:
    if success==4:
     need(set(bound)==cells,'Actual4cell inventory incomplete')
     for viewport in ['desktop','mobile']:
      tile=[part for v,s in bound if v==viewport for part in expand(s)];need(sorted(tile)==[4,13,14],'Actual canonical4,13/full14 tiling incomplete/overlapping')
     need(api('final-verification-ref','git/ref/heads/'+BRANCH)['object']['sha']==HEAD,'Immutable verification ref moved')
     state['snapshot_batch_pass']=True;state['status']='ACTUAL_TESTMERGE_AFFECTED14_4_13_FOUR_PASS_NOT_FINAL_HEAD_QUALIFICATION'
    else:state['status']='ACTUAL_TESTMERGE_AFFECTED14_4_13_FOUR_TERMINAL_FAILURE_RETAINED'
    break
   remaining=min(60-(time.monotonic()-tick),deadline-time.monotonic())
   if remaining>0:time.sleep(remaining)
  else:state['status']='BOUNDED180MIN_DEADLINE_PARTIAL_NO_RETRY'
 except Exception as error:state.update({'status':'STOPPED_COLLECTION_ERROR_NO_RETRY','error':str(error)})
 finally:
  state.update({'ended':now(),'elapsed_s':time.monotonic()-start,'api_requests':counter});save(OUT/'LATEST.json',state);save(OUT/'TERMINAL.json',state)
  print(json.dumps({'status':state['status'],'snapshot_batch_pass':state['snapshot_batch_pass'],'selected_success':state.get('selected_success',0),'selected_terminal_collected':state.get('selected_terminal_collected',0),'error':state.get('error'),'output':str(OUT),'current_final_head_qualified':False}),flush=True)
 return 0 if state.get('snapshot_batch_pass')else 1
if __name__=='__main__':raise SystemExit(main())
