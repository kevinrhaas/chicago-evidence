"""Four affected PR1213 testmerge smoke cells, explicitly root-released once; no retry."""
import argparse,base64,datetime,hashlib,json,pathlib,re,subprocess,time
REPO='kevinrhaas/chicago'
INTEGRATED_DEV=None
WORKFLOW='chicago-4d-smoke.yml';WORKFLOW_SHA='00ae307ad6cbeb556ddd5028668ee53a839393c619cc52ae5d0e8f39eb84ec52'
OUT=None
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 global OUT,INTEGRATED_DEV
 a=argparse.ArgumentParser();a.add_argument('--root-release',required=True,type=pathlib.Path);args=a.parse_args()
 release=json.loads(args.root_release.read_bytes())
 assert release.get('status')=='ROOT_RELEASED_PR1213_AFFECTED14_AND4_13_FOUR' and release.get('allow_dispatch') is True
 HEAD=release['source_head'];TREE=release['tree'];PARENTS=release['parents'];PR_SOURCE=release['pr_source_head'];INTEGRATED_DEV=release['integrated_dev']
 assert release['repository']==REPO and release['pr']==1213
 assert isinstance(PARENTS,list) and len(PARENTS)==2 and isinstance(release['pr_source_parents'],list) and len(release['pr_source_parents'])in[1,2]
 assert all(isinstance(x,str)and re.fullmatch('[0-9a-f]{40}',x)for x in [HEAD,TREE,PR_SOURCE,INTEGRATED_DEV,release['pr_source_tree'],release['expected_owned_lease'],release['smoke_source_git_blob_sha1'],*PARENTS,*release['pr_source_parents']])
 assert PARENTS==[INTEGRATED_DEV,PR_SOURCE] and HEAD!=PR_SOURCE
 assert not PR_SOURCE.startswith('0be5') and PR_SOURCE not in ['cbb94c2d46223e4ca75fc4b02560f43c4de2e710','13375406538e76e8c1deadf18165089f7145ea28'],'Historical source cannot be the next qualification source'
 assert isinstance(release['pr_source_branch'],str)and re.fullmatch('[A-Za-z0-9_./-]+',release['pr_source_branch'])
 assert release['workflow_sha256']==WORKFLOW_SHA and isinstance(release['smoke_source_sha256'],str)and re.fullmatch('[0-9a-f]{64}',release['smoke_source_sha256'])
 assert release['strict_helper_sha256']==sha((pathlib.Path(__file__).resolve().parent/'strict_helpers.py').read_bytes())
 assert release['collector_sha256']==sha((pathlib.Path(__file__).resolve().parent/'collect-GET-only.py').read_bytes())
 OUT=pathlib.Path('/workspace/shared/PR1213-AFFECTED14-4_13-'+HEAD[:10]+'-SMOKES')
 assert release.get('source_head')==HEAD and release.get('tree')==TREE and release.get('parents')==PARENTS
 assert release.get('dispatcher_sha256')==sha(pathlib.Path(__file__).read_bytes())
 branch=release['verification_ref'];assert branch.startswith('steward/pr1213-verify-')
 OUT.mkdir(exist_ok=False);deadline=time.monotonic()+180;number=0
 cells=[(v,s)for v in ['desktop','mobile']for s in ['14','4,13']]
 record={'repository':REPO,'pr':1213,'root_dispatch_release_status':release['status'],'pr_source_head':PR_SOURCE,'pr_source_branch':release['pr_source_branch'],'verification_ref':branch,'source_head':HEAD,'source_integration_tree':TREE,'source_integration_parents':PARENTS,'integrated_dev':INTEGRATED_DEV,'pr_source_tree':release['pr_source_tree'],'pr_source_parents':release['pr_source_parents'],'expected_owned_lease':release['expected_owned_lease'],'root_release_sha256':sha(args.root_release.read_bytes()),'workflow_sha256':WORKFLOW_SHA,'smoke_source_sha256':release['smoke_source_sha256'],'smoke_source_git_blob_sha1':release['smoke_source_git_blob_sha1'],'strict_helper_sha256':release['strict_helper_sha256'],'collector_sha256':release['collector_sha256'],'started':now(),'dispatches':[],'runs':[],'automatic_retry':False,'qualification_pass':False,'current_final_head_qualified':False,'scope':'Exactly desktop/mobile full14 and canonical4,13 on the actual immutable next GitHub testmerge. No broad18/whole15/current-final-head qualification. Prior133 normal2PASS1FAIL and public-world timeoutFAIL remain unchanged. Root separately owns latest-base projection, world/card evidence and ordinary merge.'}
 def save():(OUT/'RECEIPT.json').write_text(json.dumps(record,indent=2)+'\n')
 def api(route,method='GET',body=None):
  nonlocal number
  assert time.monotonic()<deadline;number+=1;stem=OUT/f'{number:03d}'
  (stem.with_suffix('.request.json')).write_text(json.dumps({'at':now(),'route':route,'method':method,'body':body},indent=2)+'\n')
  cmd=['gh','api','--method',method,'repos/'+REPO+'/'+route]
  if body is not None:cmd+=['--input','-']
  r=subprocess.run(cmd,input=json.dumps(body).encode()if body is not None else None,capture_output=True,timeout=min(45,max(1,deadline-time.monotonic())))
  stem.with_suffix('.stdout').write_bytes(r.stdout);stem.with_suffix('.stderr').write_bytes(r.stderr)
  assert r.returncode==0,f'{method} failed/ambiguous: inspect {stem}; no retry'
  return json.loads(r.stdout)if r.stdout.strip()else None
 save()
 try:
  pr=api('pulls/1213');assert pr['state']=='open' and pr['head']['sha']==PR_SOURCE and pr['head']['ref']==release['pr_source_branch'] and pr['head']['repo']['full_name']==REPO and pr['base']['ref']=='dev' and pr['auto_merge'] is None
  record['actual_PR_source_base_merge_at_dispatch']={k:pr[k]for k in ['head','base','merge_commit_sha']}
  need_source=api('git/commits/'+PR_SOURCE);assert need_source['tree']['sha']==release['pr_source_tree'] and [p['sha']for p in need_source['parents']]==release['pr_source_parents']
  assert api('git/ref/heads/dev')['object']['sha']==INTEGRATED_DEV
  assert api('git/ref/heads/lap/pr-1213')['object']['sha']==release['expected_owned_lease']
  assert pr['mergeable'] is True and pr['merge_commit_sha']==HEAD
  commit=api('git/commits/'+HEAD);assert commit['tree']['sha']==TREE and [p['sha']for p in commit['parents']]==PARENTS
  assert api('git/ref/heads/'+branch)['object']['sha']==HEAD
  workflow=api('actions/workflows/'+WORKFLOW);assert workflow['id']==365585058 and workflow['path']=='.github/workflows/'+WORKFLOW and workflow['state']=='active'
  data=api('contents/.github/workflows/'+WORKFLOW+'?ref='+HEAD);assert sha(base64.b64decode(data['content']))==WORKFLOW_SHA
  smoke_source=api('contents/chicago/4d/tools/smoke_renderer.mjs?ref='+HEAD);assert smoke_source['sha']==release['smoke_source_git_blob_sha1']
  listing='actions/workflows/'+WORKFLOW+'/runs?branch='+branch+'&head_sha='+HEAD+'&per_page=100'
  before=api(listing);assert before['total_count']==len(before['workflow_runs'])==0,'Existing runs: never duplicate'
  for viewport,stage in cells:
   assert api('git/ref/heads/'+branch)['object']['sha']==HEAD
   row={'viewport':viewport,'stage':stage,'post_attempted':True,'post_succeeded':False,'at':now()};record['dispatches'].append(row);save()
   api('actions/workflows/'+WORKFLOW+'/dispatches','POST',{'ref':branch,'inputs':{'viewport':viewport,'stage':stage}});row['post_succeeded']=True;save()
  for trial in range(4):
   inventory=api(listing);record['runs']=[{k:r.get(k)for k in ['id','head_sha','head_branch','event','run_attempt','path','workflow_id','status','conclusion','created_at','html_url']}for r in inventory['workflow_runs']];save()
   if inventory['total_count']==len(record['runs'])==4:break
   if trial<3:time.sleep(5)
  assert inventory['total_count']==len(record['runs'])==4 and len({r['id']for r in record['runs']})==4,'Incomplete/extra discovery: no redispatch'
  assert all(r['head_sha']==HEAD and r['head_branch']==branch and r['event']=='workflow_dispatch' and r['run_attempt']==1 and r['path']=='.github/workflows/'+WORKFLOW and r['workflow_id']==365585058 for r in record['runs'])
  assert api('git/ref/heads/'+branch)['object']['sha']==HEAD
  record['dispatch_complete']=True
 except BaseException as error:record['error']=str(error);raise
 finally:record['ended']=now();record['api_requests']=number;save();print(json.dumps({'receipt':str(OUT/'RECEIPT.json'),'accepted':sum(x['post_succeeded']for x in record['dispatches']),'discovered':len(record['runs']),'complete':record.get('dispatch_complete',False),'error':record.get('error')}),flush=True)
if __name__=='__main__':main()
