"""Root-authorized one nonexistent immutable verification ref; fixed concrete a22/513/baa9/950ce guards, no retry/overwrite."""
import pathlib,json,subprocess,datetime
D=pathlib.Path(__file__).resolve().parent;r=json.loads((D/'ACTUAL-ROOT-RELEASE.json').read_bytes());O=D/'REF-CREATE-ONCE';O.mkdir(exist_ok=False);n=0
assert r['status']=='ROOT_RELEASED_PR1213_AFFECTED14_AND4_13_FOUR'and r['allow_dispatch']is True
assert r['pr_source_head']=='a22ca758323e6e2f1ed9f3909a88fb98636be55c'and r['integrated_dev']=='5135fb7674eea8cf5b140a7cf0c8bc208b0b1f4e'and r['source_head']=='baa9b11883e224d2d1c6a69fd71de9377cba1382'and r['expected_owned_lease']=='950ce00ce394fc30547294ef731738f6e08138b7'
def api(label,route,method='GET',body=None,missing=False):
 global n
 n+=1;p=O/f'{n:02d}-{label}';p.with_suffix('.request.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':method,'route':route,'body':body},indent=2)+'\n');cmd=['gh','api','--method',method,'repos/kevinrhaas/chicago/'+route]
 if body is not None:cmd+=['--input','-']
 v=subprocess.run(cmd,input=json.dumps(body).encode()if body is not None else None,capture_output=True,timeout=45);p.with_suffix('.stdout').write_bytes(v.stdout);p.with_suffix('.stderr').write_bytes(v.stderr)
 if missing:
  assert v.returncode!=0 and str(json.loads(v.stdout).get('status'))=='404','Ref not demonstrably absent: STOP, no create/overwrite';return
 assert v.returncode==0,'API refused/ambiguous: STOP without retry '+str(p);return json.loads(v.stdout)if v.stdout.strip()else None
assert api('OWNED-LEASE','git/ref/heads/lap/pr-1213')['object']['sha']==r['expected_owned_lease'],'Different lease: STOP'
assert api('CURRENT-DEV','git/ref/heads/dev')['object']['sha']==r['integrated_dev'],'CurrentDEV changed: STOP'
assert api('CURRENT-SOURCE','git/ref/heads/'+r['pr_source_branch'])['object']['sha']==r['pr_source_head'],'Source changed: STOP'
p=api('CURRENT-PR-TESTMERGE','pulls/1213');assert p['state']=='open'and p['head']['sha']==r['pr_source_head']and p['head']['ref']==r['pr_source_branch']and p['head']['repo']['full_name']=='kevinrhaas/chicago'and p['base']['ref']=='dev'and p['auto_merge']is None and p['mergeable']is True and p['merge_commit_sha']==r['source_head'],'Actual PR/testmerge differs: STOP'
c=api('ACTUAL-TESTMERGE-COMMIT','git/commits/'+r['source_head']);assert c['tree']['sha']==r['tree']and[x['sha']for x in c['parents']]==r['parents'],'Actual testmerge tree/parents differ: STOP'
api('PROVE-REF-NONEXISTENT','git/ref/heads/'+r['verification_ref'],missing=True)
created=api('ONE-REF-CREATION','git/refs','POST',{'ref':'refs/heads/'+r['verification_ref'],'sha':r['source_head']});assert created['object']['sha']==r['source_head']
assert api('ACTUAL-CREATED-REF','git/ref/heads/'+r['verification_ref'])['object']['sha']==r['source_head']
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'created_once':True,'verification_ref':r['verification_ref'],'actual_head':r['source_head'],'tree':r['tree'],'parents':r['parents'],'pr_source_head':r['pr_source_head'],'current_reviewed_base':r['integrated_dev'],'owned_lease':r['expected_owned_lease'],'POST_ref_creations':1,'overwrites':0,'retries':0,'smoke_dispatches':0,'merge_attempts':0};(O/'ACTUAL-REF-CREATED-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
