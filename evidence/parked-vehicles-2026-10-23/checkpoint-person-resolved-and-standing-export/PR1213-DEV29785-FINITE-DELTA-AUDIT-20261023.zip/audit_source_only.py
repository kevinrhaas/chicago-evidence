from pathlib import Path
import subprocess,json,struct,hashlib,re,datetime
R=Path('/tmp/chicago-covered-sag/chicago/4d');D=Path(__file__).resolve().parent;A='5135fb7674eea8cf5b140a7cf0c8bc208b0b1f4e';B='29785b404e1bcab6f29ef467a829ecbf6bbaa5d0';H='a22ca758323e6e2f1ed9f3909a88fb98636be55c';P='chicago/4d/'
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
def blob(ref,p):return git('show',ref+':'+p)
def sha(b):return hashlib.sha256(b).hexdigest()
paths=git('diff','--name-only',A,B).decode().splitlines();(D/'COMPLETE-TEXT-DELTA.patch').write_bytes(git('diff',A,B,'--',*[p for p in paths if not p.endswith(('.glb','.jpg'))]))
(D/'SMOKE-ONLY-DELTA.patch').write_bytes(git('diff',A,B,'--',P+'tools/smoke_renderer.mjs'));(D/'COMMITS.txt').write_bytes(git('log','--format=%H %s',A+'..'+B))
identical={}
for x in ['renderers/web/transport','data/transport','assets/authored/transport','renderers/web/js/main.js','renderers/web/js/popup.js','renderers/web/js/parked-transport.js','renderers/web/js/world.js','renderers/web/js/shadow-casters.js','renderers/web/js/terrain.js','data/scenes/1904.json','data/sidecars/1904/index.json']:
 try:
  old=git('rev-parse',A+':'+P+x).decode().strip();new=git('rev-parse',B+':'+P+x).decode().strip()
 except subprocess.CalledProcessError:continue
 assert old==new,x;identical[x]=old
geos=[]
for p in paths:
 if p.endswith('.glb'):
  versions=[]
  for ref in [A,B]:
   raw=blob(ref,p);n=struct.unpack_from('<I',raw,12)[0];j=json.loads(raw[20:20+n]);prim=[pr for m in j['meshes']for pr in m['primitives']];tri=sum(j['accessors'][pr['indices']]['count']//3 if 'indices'in pr else j['accessors'][pr['attributes']['POSITION']]['count']//3 for pr in prim)
   pos=[j['accessors'][pr['attributes']['POSITION']]for pr in prim];bounds=[[min(a['min'][i]for a in pos)for i in range(3)],[max(a['max'][i]for a in pos)for i in range(3)]]
   versions.append({'ref':ref,'bytes':len(raw),'sha256':sha(raw),'triangles':tri,'primitives':len(prim),'materials':j.get('materials',[]),'images':j.get('images',[]),'local_accessor_bounds':bounds,'node_transforms':[{k:v for k,v in node.items()if k in['name','matrix','translation','rotation','scale','children']}for node in j['nodes']]})
  old,new=versions;geos.append({'path':p,'old':{k:v for k,v in old.items()if k not in['materials','images','node_transforms']},'new':{k:v for k,v in new.items()if k not in['materials','images','node_transforms']},'triangle_delta':new['triangles']-old['triangles'],'materials_exact':old['materials']==new['materials'],'images_exact':old['images']==new['images'],'node_transforms_exact':old['node_transforms']==new['node_transforms'],'local_bounds_exact':old['local_accessor_bounds']==new['local_accessor_bounds']})
def ids(ref):
 s=blob(ref,P+'tools/smoke_renderer.mjs').decode();match=re.search(r'const PLACED_1904 = \[(.*?)\]\.sort\(\);',s,re.S);assert match;s=re.sub(r'//[^\n]*','',match.group(1));return re.findall(r"'([A-Za-z0-9_]+)'",s)
a,b,h=ids(A),ids(B),ids(H);assert len(a)==len(set(a))==195 and len(b)==len(set(b))==len(h)==len(set(h))==222 and set(b)==set(h)
registry={x['id']for x in json.loads(blob(B,P+'data/sidecars/1904/index.json'))['structures']};assert registry==set(b)
pr=json.loads((D/'PR-GET.stdout').read_text());fetch=json.loads((D/'FETCH-REQUEST.json').read_text());out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_before':A,'reviewed_actual_dev':B,'source_unchanged':H,'app_source_edits':0,'network_GETs':1,'custom_ref':fetch['cmd'][-1].split(':',1)[1],'origin_dev_unchanged':git('rev-parse','origin/dev').decode().strip(),'source_still_clean':not git('status','--porcelain'),'net_changed_paths':paths,'net_change_count':len(paths),'is_only_three_file_changelog_fold':False,'exact_unchanged_trees_or_blobs':identical,'geometry_changes':geos,'smoke_fixture':{'old_baseline_count':len(a),'incoming_unique_count':len(b),'own_unique_count':len(h),'incoming_set_equals_own_set':True,'incoming_equals_actual_registry':True,'incoming_added27':sorted(set(b)-set(a)),'naive_combination_would_duplicate27':True,'minimal_resolution':'Replace only PLACED_1904 array with exact incoming29785 full222 array; remove own front27, retain all own/incoming other assertions and complete independent Home/Welcome taps.'},'actual_one_PR_GET':{'source':pr['head']['sha'],'base_field':pr['base']['sha'],'state':pr['state'],'draft':pr['draft'],'mergeable':pr['mergeable'],'mergeable_state':pr['mergeable_state'],'testmerge':pr['merge_commit_sha']},'actual_testmerge_tree_available':False,'new_testmerge_qualification_claimed':False,'old_normal3_binding_remains_historical_513_baa9':True,'next_action':'Root review only; no merge/rederive/gate/ready/source mutation authorized by this audit.'}
assert out['source_still_clean'] and out['origin_dev_unchanged']=='824957fe47dd70fad729c3b117cb18b695d54b0b';(D/'FINITE-IMPACT-PROOF.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'paths':len(paths),'geometry_changes':geos,'fixture_counts':(len(a),len(b),len(h)),'transport_UI_blobs_exact':len(identical),'actual_testmerge':pr['merge_commit_sha']},indent=2))
