"""Root released07:26 only exact cache recovery + ONE canonical fullresolve. No gate/commit."""
import os,pathlib,json,subprocess,hashlib,datetime,time,shutil,sys,ctypes,signal
O=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/chicago');A=R/'chicago/4d';SRC=pathlib.Path('/workspace/shared/PR1175-AFTER513-AUTHORED-RESOLUTION-PROPOSAL-20261023');INTAKE=pathlib.Path('/workspace/shared/PR1175-A22-ACTUAL-SOURCE-INTAKE-20261023')
P='4766644295b5668084130fed80c6a18c9f0e6a04';V='a22ca758323e6e2f1ed9f3909a88fb98636be55c';LEASE='a65c70157a76890926237a24e264ac9e2477a891';OLDINDEX='ba91b3d7c18051e4be7ace13157524d6e5c5bb3f53ae362b8cae5f25c2c7b841'
GENERATED=['chicago/4d/data/liberties.json','chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/docs/measurements/source_use_coverage.md']
CACHEOLD={'assets/gltf/glessner_house__as_built_1887.glb':'40c41087ed07d91fd27716120e1599260d194135dc7430d8519efa9acb68ece9','assets/web/glessner_house__as_built_1887.glb':'c80e51729a6ce049c32c1f92aed57f704c36c402e58a5a188a2079ca8c4ac85c','assets/web/glessner_house__as_built_1887.light.glb':'feff2bf03710752c156f7696c6291520a637bda67d9e812d58cb40d0fb16fd3d'}
env=os.environ.copy();env['PATH']='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:'+env['PATH'];env.update({k:'1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','C4D_GATE_REQUIRE_READERS']});env.update(CHECK_JOBS='4',BASE=V)
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=env).decode().strip()
def save(name,data): (O/name).write_text(json.dumps(data,indent=2)+'\n')
active=None;commands=[];status='FAIL';error=None;started=now();assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
signal.signal(signal.SIGTERM,lambda s,f:(_ for _ in ()).throw(SystemExit(128+s)))
def run(name,cmd):
 global active
 intent={'name':name,'command':cmd,'at':now(),'owner_pid':os.getpid(),'elevated_invocation_required':True};save(name+'-INTENT.json',intent);print(json.dumps(intent),flush=True);t=time.monotonic()
 with (O/(name+'.log')).open('wb') as f:
  active=subprocess.Popen(cmd,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);save('CURRENT.json',{**intent,'child_pid':active.pid});rc=active.wait();active=None
 terminal={**intent,'returncode':rc,'seconds':time.monotonic()-t,'ended':now()};commands.append(terminal);save(name+'-TERMINAL.json',terminal);print(json.dumps(terminal),flush=True);assert rc==0,name+' failed; preserve, no retry'
try:
 assert not (O/'START.json').exists(),'No repeat execution'
 idx=pathlib.Path(git('rev-parse','--git-path','index'));idx=idx if idx.is_absolute() else R/idx
 assert sha(idx.read_bytes())==OLDINDEX,'Exact original intake index changed'
 assert git('rev-parse','HEAD')==P and git('rev-parse','MERGE_HEAD')==V and git('rev-parse',V+'^{tree}')=='fa427eb201de4bad4b7265313fcc5a422f440ea4'
 assert git('diff','--name-only','--diff-filter=U').splitlines()==GENERATED
 assert git('rev-parse','origin/dev')=='824957fe47dd70fad729c3b117cb18b695d54b0b'
 for name in ['PERSON62-REFRESHED-EXPECTED-PINS.json','PERSON476-ONLY-EXPECTED-PINS.json','INCOMING513-NONPERSON-EXPECTED-PINS.json']:
  for row in json.loads((SRC/name).read_text()):assert sha((R/row['path']).read_bytes())==row['expected_sha256'],row['path']
 for row in json.loads((SRC/'PROPOSED-AUTHORED-PROOF.json').read_text()):assert sha((R/row['path']).read_bytes())==row['proposed_sha256'],row['path']
 lease=json.loads(subprocess.check_output(['gh','api','--method','GET','repos/kevinrhaas/chicago/git/ref/heads/lap/pr-1175'],env=env));assert lease['object']['sha']==LEASE;save('ACTUAL-LEASE.json',lease)
 py=subprocess.check_output(['python3','--version'],env=env).decode().strip();assert py=='Python 3.11.17',py
 rec=A/'docs/RESEARCH/glessner-v4-recovery';manifestbytes=(rec/'manifest.json').read_bytes();assert sha(manifestbytes)=='c8e7107aa83ae2fa6ec57eb17935091c10c2c7d3da71d813dfcac11cd01bc26b';assert manifestbytes==subprocess.check_output(['git','-C',str(R),'show',V+':chicago/4d/docs/RESEARCH/glessner-v4-recovery/manifest.json'],env=env)
 m=json.loads(manifestbytes);assert len(m['parts'])==20 and set(m['files'])==set(CACHEOLD)
 parts=[]
 for part in m['parts']:
  f=rec/part['name'];b=f.read_bytes();assert len(b)==part['bytes'] and sha(b)==part['sha256'];assert b==subprocess.check_output(['git','-C',str(R),'show',V+':chicago/4d/docs/RESEARCH/glessner-v4-recovery/'+part['name']],env=env);parts.append(part)
 old=[]
 for rel,digest in CACHEOLD.items():
  f=A/rel;assert f.is_file() and sha(f.read_bytes())==digest,rel
  assert not subprocess.check_output(['git','-C',str(R),'ls-files','--','chicago/4d/'+rel],env=env)
  assert subprocess.run(['git','-C',str(R),'check-ignore','-q','chicago/4d/'+rel],env=env).returncode==0
  old.append({'path':rel,'old_sha256':digest,'old_bytes':f.stat().st_size,'expected':m['files'][rel]})
 save('START.json',{'started':started,'owner_pid':os.getpid(),'HEAD':P,'MERGE_HEAD':V,'index_sha256':OLDINDEX,'release':'root explicit07:26 cache recovery + ONE fullresolve only','python':py,'CHECK_JOBS':4,'math_threads':1,'prior_V7_closed':'07:22:50Z','prior_V17_closed':'07:25:52Z','commands_allowed':['recover_glessner_v4.py --materialize','node tools/rederive.mjs --resolve'],'fullgate_commit_publish_after_resolve_authorized':False})
 save('CACHE-EXACT-PREIMAGE-AND-CURRENT20PARTS-PROOF.json',{'old':old,'archive_manifest_sha256':sha(manifestbytes),'parts':parts,'allparts_exact_a22':True})
 for rel in CACHEOLD:
  dst=O/'OLD-IGNORED-CACHES'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(A/rel),str(dst))
 run('01-MATERIALIZE',['python3','tools/recover_glessner_v4.py','--materialize'])
 for rel,pin in m['files'].items():assert sha((A/rel).read_bytes())==pin['sha256'] and (A/rel).stat().st_size==pin['bytes']
 assert sha(idx.read_bytes())==OLDINDEX,'Cache recovery unexpectedly changed source index'
 run('02-CANONICAL-FULLRESOLVE',['node','tools/rederive.mjs','--resolve'])
 assert not git('diff','--name-only','--diff-filter=U'),'Resolve left conflicts'
 assert not git('diff','--name-only'),'Resolve left unstaged tracked changes'
 tree=git('write-tree');save('ACTUAL-STAGED-TREE-AFTER-RESOLVE.json',{'tree':tree,'HEAD':git('rev-parse','HEAD'),'MERGE_HEAD':git('rev-parse','MERGE_HEAD'),'index_sha256':sha(idx.read_bytes()),'staged_paths':git('diff','--cached','--name-only').splitlines(),'after':now(),'gate_or_commit_released':False})
 (O/'AFTER-RESOLVE-STAGED.diff').write_bytes(subprocess.check_output(['git','-C',str(R),'diff','--cached','--no-ext-diff','--no-color'],env=env));shutil.copy2(idx,O/'INDEX-AFTER-RESOLVE.bin');status='PASS'
except BaseException as e:
 error=repr(e);print('STOP '+error,flush=True)
finally:
 if active and active.poll() is None:
  os.killpg(active.pid,signal.SIGTERM)
  try:active.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(active.pid,signal.SIGKILL);active.wait()
 # Adopted owned descendants only; never kill another agent's processes.
 owned=[]
 for q in pathlib.Path('/proc').iterdir():
  if not q.name.isdigit():continue
  try:
   s=(q/'stat').read_text().rsplit(')',1)[1].split()
   if int(s[1])==os.getpid():owned.append(int(q.name))
  except (FileNotFoundError,ProcessLookupError,ValueError):pass
 for pid in owned:
  try:os.kill(pid,signal.SIGTERM)
  except ProcessLookupError:pass
 end=time.monotonic()+5
 while time.monotonic()<end:
  try:
   p,_=os.waitpid(-1,os.WNOHANG)
   if p==0:time.sleep(.05)
  except ChildProcessError:break
 for pid in owned:
  try:os.kill(pid,signal.SIGKILL)
  except ProcessLookupError:pass
 while True:
  try:
   p,_=os.waitpid(-1,os.WNOHANG)
   if p==0:break
  except ChildProcessError:break
 save('TERMINAL.json',{'status':status,'started':started,'finished':now(),'owner_pid':os.getpid(),'commands':commands,'error':error,'owned_adopted_children_cleaned':owned,'fullgate_commit_push_executed':False,'next':'Root reviews actual derived tree/protected proof, then separately releases gate/checkpoint writer.'});print(json.dumps({'status':status,'out':str(O),'error':error}),flush=True)
sys.exit(0 if status=='PASS' else 1)
