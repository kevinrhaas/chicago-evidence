"""Read-only after actualresolvePASS: source/index hashes and full changed-stage classification. No tests/gate/publisher."""
import pathlib,json,subprocess,hashlib,datetime,sys,difflib
sys.dont_write_bytecode=True
O=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/chicago');BEFORE=pathlib.Path('/workspace/shared/PR1175-A22-ACTUAL-SOURCE-INTAKE-20261023');H=pathlib.Path('/workspace/shared/PR1175-A22-GATE-CHECKPOINT-WRITER-HELD-20261023');sys.path.insert(0,str(H));from protected_sources import protected_snapshot
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',str(R),*a]);now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not (O/'AFTER-RESOLVE-PROTECTED-TERMINAL.json').exists(),'No silent repeat'
result={'started':now(),'status':'FAIL','source_only_readback':True,'tests_gates_publishers_commits_executed':False}
try:
 terminal=json.loads((O/'TERMINAL.json').read_text());assert terminal['status']=='PASS'
 assert git('rev-parse','HEAD').decode().strip()=='4766644295b5668084130fed80c6a18c9f0e6a04' and git('rev-parse','MERGE_HEAD').decode().strip()=='a22ca758323e6e2f1ed9f3909a88fb98636be55c'
 assert not git('diff','--name-only').decode().strip() and not git('diff','--name-only','--diff-filter=U').decode().strip()
 assert not git('ls-files','--others','--exclude-standard').decode().strip(),'Untracked source exists outside the staged tree'
 proof=protected_snapshot(O/'AFTER-RESOLVE-ALL-PROTECTED-PINS.json')
 for p,digest in proof['actual_hashes'].items():assert sha(git('show',':'+p))==digest,p
 def stages(data):
  out={}
  for line in data.decode().splitlines():
   mode,blob,rest=line.split(' ',2);stage,path=rest.split('\t',1);out.setdefault(path,{})[int(stage)]={'mode':mode,'blob':blob}
  return out
 old=stages((BEFORE/'INDEX-STAGES.txt').read_bytes());new=stages(git('ls-files','--stage'));m=json.loads((R/'chicago/4d/tools/derived_manifest.json').read_text());owners={p:s['command'] for s in m['steps'] for p in s.get('resolves',[])};changed=[]
 for p in sorted(set(old)|set(new)):
  if old.get(p)==new.get(p):continue
  row={'path':p,'before_stages':old.get(p),'after_stages':new.get(p),'canonical_owner':owners.get(p),'was_unmerged':old.get(p,{}).get(0) is None};changed.append(row)
  if p in old and 0 in old[p] and p in new and 0 in new[p]:
   a=git('cat-file','blob',old[p][0]['blob']);b=git('cat-file','blob',new[p][0]['blob']);dst=O/'AFTER-RESOLVE-DELTA'/p;dst.parent.mkdir(parents=True,exist_ok=True)
   if b'\0' not in a+b:
    dst.with_name(dst.name+'.patch').write_bytes(b''.join(difflib.diff_bytes(difflib.unified_diff,a.splitlines(True),b.splitlines(True),fromfile=('a/'+p).encode(),tofile=('b/'+p).encode())))
   else:dst.with_name(dst.name+'.binary-meta.json').write_text(json.dumps({'old_bytes':len(a),'new_bytes':len(b),'old_sha256':sha(a),'new_sha256':sha(b)},indent=2)+'\n')
 (O/'AFTER-RESOLVE-STAGE-CHANGE-CLASSIFICATION.json').write_text(json.dumps(changed,indent=2)+'\n')
 result.update(status='PASS',tree=git('write-tree').decode().strip(),protected_groups=proof['groups'],strict_person62=True,person38_expectations_with_canonical_exceptions=True,incoming256_expectations_with_canonical_exceptions=True,all7authored_exact=True,working_index_protected_coherent=True,canonical_protected_digest_changes=proof['canonical_changes'],total_changed_stage_paths=len(changed),changed_nonowner_paths=[x['path'] for x in changed if not x['canonical_owner']],root_review_still_needed_before_fullgate=True)
except BaseException as e:result['error']=repr(e)
result['finished']=now();(O/'AFTER-RESOLVE-PROTECTED-TERMINAL.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));sys.exit(0 if result['status']=='PASS' else 1)
