"""HELD single export,30s512MiB; no field, solver, loader, browser or retry."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
PYTHON = '/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert sys.version_info[:3] == (3, 11, 17)
    release_path = Path(sys.argv[1]).resolve()
    release = json.loads(release_path.read_text())
    assert release['released'] is True and release['authorization'] == 'ONE_ROOT_AUTHORIZED_V16_PLANTED_STANDING_GLB_EXPORT'
    assert release['maximum_runs'] == release['maximum_exports'] == 1
    assert release['maximum_fields'] == release['maximum_solvers'] == 0
    assert release['maximum_wall_seconds'] == 30 and release['maximum_rss_bytes'] == 536870912
    assert set(release['source_sha256']) == {'export_planted_standing_HELD.py', 'run_export_once_HELD.py'}
    assert set(release['input_pins']) == {'rig26', 'v16_field', 'stationary_result', 'stationary_terminal', 'stationary_matrices', 'controls26', 'standing_profile', 'tail_fixture', 'phase_a_arrays', 'contact_sidecar'}
    for name, digest in release['source_sha256'].items():
        assert sha(HERE/name) == digest, name+' source drift'
    for key, row in release['input_pins'].items():
        assert sha(row['path']) == row['sha256'], key+' input drift'
    assert not Path(release['output_dir']).exists()
    owner = HERE/'ACTUAL'
    assert not owner.exists(), 'One-shot owner exists; no retry'
    owner.mkdir()
    (owner/'ROOT-RELEASE.json').write_text(json.dumps(release, indent=2)+'\n')
    env = os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1',
               VECLIB_MAXIMUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    start, peak, reason = time.monotonic(), 0, None
    with (owner/'stdout.log').open('w') as stdout, (owner/'stderr.log').open('w') as stderr:
        child = subprocess.Popen(['nice', '-n', '19', PYTHON, str(HERE/'export_planted_standing_HELD.py'), str(release_path)],
                                 cwd=HERE, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        while child.poll() is None:
            try:
                for line in (Path('/proc')/str(child.pid)/'status').read_text().splitlines():
                    if line.startswith('VmRSS:'):
                        peak = max(peak, int(line.split()[1])*1024)
            except FileNotFoundError:
                pass
            if time.monotonic()-start > 30:
                reason = 'WALL_LIMIT_30_SECONDS'
            elif peak > 536870912:
                reason = 'RSS_LIMIT_512_MiB'
            if reason:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                break
            time.sleep(.025)
        code = child.wait()
    elapsed = time.monotonic()-start
    peak = max(peak, int(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)*1024)
    if elapsed > 30 or peak > 536870912:
        reason = reason or 'KERNEL_PEAK_OR_ELAPSED_LIMIT_EXCEEDED'
    receipt_path = Path(release['output_dir'])/'EXPORT-RECEIPT.json'
    receipt = json.loads(receipt_path.read_text()) if receipt_path.exists() else None
    passed = code == 0 and reason is None and receipt is not None and receipt['status'] == 'ACTUAL_EXPORT_ONLY_NO_LOADED_OR_VISUAL_ACCEPTANCE'
    terminal = dict(status='STANDING_GLB_EXPORT_ONLY_PASS_NO_LOADED_ACCEPTANCE' if passed else 'STANDING_GLB_EXPORT_FAIL_NO_RETRY',
                    finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), exit_code=code,
                    elapsed_seconds=elapsed, actual_peak_rss_bytes=peak, resource_failure=reason, no_owned_child_active=True,
                    exports=1 if receipt else None, fields=0, solvers=0, runs=1, retries=0, output_dir=release['output_dir'],
                    loaded_readback_or_browser_or_app_activation_authorized=False)
    (owner/'TERMINAL.json').write_text(json.dumps(terminal, indent=2)+'\n')
    print(json.dumps(terminal), flush=True)
    return 0 if passed else 2


if __name__ == '__main__':
    raise SystemExit(main())
