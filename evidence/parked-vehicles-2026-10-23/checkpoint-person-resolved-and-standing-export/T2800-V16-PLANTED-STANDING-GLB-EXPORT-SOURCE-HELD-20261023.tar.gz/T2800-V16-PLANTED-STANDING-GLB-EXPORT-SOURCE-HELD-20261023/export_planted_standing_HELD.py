"""One future in-place-range derivative plus local-TRS planted-posture clip.

Source only until explicit root release. Never edits the source GLB or builds a
field. Original geometry/maps/IB and rest node tree remain byte/value exact.
"""
import copy
import hashlib
import json
from pathlib import Path
import struct
import sys

HERE = Path(__file__).resolve().parent
CLIP = 'sevket_reconstructed_planted_posture_v1'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    release = json.loads(Path(sys.argv[1]).read_text())
    assert release['released'] is True and release['authorization'] == 'ONE_ROOT_AUTHORIZED_V16_PLANTED_STANDING_GLB_EXPORT'
    assert release['maximum_exports'] == 1 and release['maximum_fields'] == release['maximum_solvers'] == 0
    assert set(release['source_sha256']) == {'export_planted_standing_HELD.py', 'run_export_once_HELD.py'}
    for name, digest in release['source_sha256'].items():
        assert sha(HERE/name) == digest, name+' source drift'
    assert release['source_sha256'][Path(__file__).name] == sha(__file__)
    pins = release['input_pins']
    assert set(pins) == {'rig26', 'v16_field', 'stationary_result', 'stationary_terminal', 'stationary_matrices', 'controls26', 'standing_profile', 'tail_fixture', 'phase_a_arrays', 'contact_sidecar'}
    for key, row in pins.items():
        assert sha(row['path']) == row['sha256'], key+' input drift'
    assert sys.byteorder == 'little'
    import numpy as np
    source = Path(pins['rig26']['path'])
    assert pins['rig26']['sha256'] == '03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36'
    assert pins['v16_field']['sha256'] == '04df599158ea091eb6d0036d3aeab9159ee96b8dfd43524a17ff874d72492e2d'
    result = json.loads(Path(pins['stationary_result']['path']).read_text())
    terminal = json.loads(Path(pins['stationary_terminal']['path']).read_text())
    assert result['status'] == terminal['status'] == 'STATIONARY65_SAVED_FIELD_CPU_PASS_ONLY'
    assert result['source_field_sha256'] == pins['v16_field']['sha256'] and result['sampled_poses'] == 65
    assert pins['standing_profile']['sha256'] == '1404bfb28eb06271b1bd3546d5d163dfd3378bbd961fea2fdc95f8aa73cd0e76'
    assert {k: result['parameters'][k] for k in ['period_s', 'lateral_amplitude_m', 'longitudinal_amplitude_m', 'body_compression_m']} == dict(period_s=12., lateral_amplitude_m=.004, longitudinal_amplitude_m=.002, body_compression_m=.004)
    assert result['original_known_and_tail_protection_pass'] is True and result['negative_controls']['all_detected'] is True
    assert terminal['no_owned_child_active'] is True and terminal['fields'] == terminal['solvers'] == terminal['exports'] == 0
    controls = json.loads(Path(pins['controls26']['path']).read_text())
    frames = json.loads(Path(pins['stationary_matrices']['path']).read_text())['frames']
    assert len(frames) == 65
    times = np.asarray([f['time_s'] for f in frames], dtype=float)
    world = np.asarray([f['global_canonical_matrices'] for f in frames], dtype=float)
    assert world.shape == (65, 26, 4, 4) and np.isfinite(world).all()
    assert times[0] == 0 and times[-1] == 12 and np.all(np.diff(times) == .1875)
    assert np.array_equal(world[0], world[-1])
    raw = source.read_bytes()
    magic, version, total = struct.unpack_from('<III', raw)
    assert (magic, version, total) == (0x46546c67, 2, len(raw))
    jlen, jkind = struct.unpack_from('<II', raw, 12)
    assert jkind == 0x4e4f534a
    original = json.loads(raw[20:20+jlen])
    blen, bkind = struct.unpack_from('<II', raw, 20+jlen)
    assert bkind == 0x004e4942 and 28+jlen+blen == len(raw)
    oldbin = raw[28+jlen:]
    assert len(original['buffers']) == 1 and 'uri' not in original['buffers'][0]
    assert not original.get('animations') and len(original['nodes']) == 29
    assert original['skins'][0]['joints'] == list(range(26)) and len(original['skins']) == 1
    doc, binary = copy.deepcopy(original), bytearray(oldbin)
    parents = {child: parent for parent, n in enumerate(original['nodes']) for child in n.get('children', [])}
    for i, row in enumerate(controls['nodes']):
        assert row['index'] == i and row['parent_index'] == parents.get(i)
        assert original['nodes'][i]['name'] == row['name']
        assert 'matrix' not in original['nodes'][i] and 'rotation' not in original['nodes'][i] and 'scale' not in original['nodes'][i]
    approved_ranges, field_ranges = [], []
    with np.load(pins['v16_field']['path'], allow_pickle=False) as saved:
        assert set(saved.files) == {f'mesh_{mi}_{key}' for mi in range(3) for key in ['joints', 'weights']}
        for mi in range(3):
            primitive = original['meshes'][mi]['primitives'][0]
            assert len(original['meshes'][mi]['primitives']) == 1
            for semantic, key, dtype, component in [('JOINTS_0', 'joints', np.dtype('<u2'), 5123), ('WEIGHTS_0', 'weights', np.dtype('<f4'), 5126)]:
                array = saved[f'mesh_{mi}_{key}']
                aid = primitive['attributes'][semantic]
                accessor = original['accessors'][aid]
                view = original['bufferViews'][accessor['bufferView']]
                assert accessor['type'] == 'VEC4' and accessor['componentType'] == component and not accessor.get('normalized') and not accessor.get('sparse')
                assert view['buffer'] == 0 and not view.get('byteStride') and not accessor.get('byteOffset')
                assert array.dtype == dtype and array.shape == (accessor['count'], 4)
                payload = array.tobytes(order='C')
                begin, end = view['byteOffset'], view['byteOffset']+view['byteLength']
                assert len(payload) == view['byteLength']
                assert not any(begin < b and a < end for a, b in approved_ranges)
                assert [i for i, a in enumerate(original['accessors']) if a.get('bufferView') == accessor['bufferView']] == [aid]
                approved_ranges.append((begin, end))
                binary[begin:end] = payload
                field_ranges.append(dict(mesh=mi, semantic=semantic, accessor=aid, buffer_view=accessor['bufferView'],
                                         byte_offset=begin, bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest()))
    cursor = 0
    for begin, end in sorted(approved_ranges):
        assert bytes(binary[cursor:begin]) == oldbin[cursor:begin]
        cursor = end
    assert bytes(binary[cursor:len(oldbin)]) == oldbin[cursor:]
    tail = json.loads(Path(pins['tail_fixture']['path']).read_text())
    tail_ids = np.asarray(tail['exact_source_vertex_ids'], dtype=int)
    assert len(tail_ids) == 969
    for semantic, width in [('JOINTS_0', 8), ('WEIGHTS_0', 16)]:
        row = next(r for r in field_ranges if r['mesh'] == 0 and r['semantic'] == semantic)
        for vi in tail_ids:
            begin = row['byte_offset']+int(vi)*width
            assert binary[begin:begin+width] == oldbin[begin:begin+width], 'Original tail byte changed'
    local = np.empty_like(world)
    for i in range(26):
        parent = parents.get(i)
        local[:, i] = world[:, i] if parent is None else np.linalg.inv(world[:, parent]) @ world[:, i]
        assert np.max(np.abs(local[:, i, 3, :]-[0., 0., 0., 1.])) <= 1e-12
        r = local[:, i, :3, :3]
        assert np.max(np.abs(r.transpose(0, 2, 1) @ r-np.eye(3))) <= 1e-12
        assert np.max(np.abs(np.linalg.det(r)-1)) <= 1e-12
        assert np.max(np.abs(local[0, i, :3, 3]-original['nodes'][i]['translation'])) <= 1e-12
        assert np.max(np.abs(local[0, i, :3, :3]-np.eye(3))) <= 1e-12
        if i != 1:
            assert np.max(np.abs(local[:, i, :3, 3]-local[0, i, :3, 3])) <= 1e-9, 'Unexpected local translation channel; no silent omission'
    expected_rotations = {j for row in controls['limbs'].values() for j in row['joints'][1:4]}
    rotation_nodes = {i for i in range(26) if np.max(np.abs(local[:, i, :3, :3]-np.eye(3))) > 1e-12}
    assert rotation_nodes == expected_rotations and len(rotation_nodes) == 12

    def quaternion(r):
        # Reviewed standing rotations lie near identity: reject another branch,
        # rather than silently guessing an antipodal/large-angle convention.
        trace = float(np.trace(r))
        assert trace > 0
        w = np.sqrt(1+trace)/2
        q = np.array([r[2, 1]-r[1, 2], r[0, 2]-r[2, 0], r[1, 0]-r[0, 1], 4*w*w])/(4*w)
        assert abs(np.linalg.norm(q)-1) <= 1e-12
        return q/np.linalg.norm(q)

    def append(values, kind, minimum=None, maximum=None):
        values = np.asarray(values, dtype='<f4')
        while len(binary) % 4:
            binary.append(0)
        begin, payload = len(binary), values.tobytes(order='C')
        binary.extend(payload)
        view = len(doc['bufferViews'])
        doc['bufferViews'].append(dict(buffer=0, byteOffset=begin, byteLength=len(payload)))
        aid = len(doc['accessors'])
        accessor = dict(bufferView=view, componentType=5126, count=len(values), type=kind)
        if minimum is not None:
            accessor.update(min=minimum, max=maximum)
        doc['accessors'].append(accessor)
        return aid

    input_id = append(times, 'SCALAR', [0], [12])
    animation = dict(name=CLIP, samplers=[], channels=[], extras=dict(
        confidence='reconstructed', behavior='Small planted standing posture; no measured force/load transfer.',
        standing_matrices_sha256=pins['stationary_matrices']['sha256'], no_walk_or_trot=True, independent_head_tail_composition=False))

    def channel(node, target, values, kind):
        si = len(animation['samplers'])
        animation['samplers'].append(dict(input=input_id, output=append(values, kind), interpolation='LINEAR'))
        animation['channels'].append(dict(sampler=si, target=dict(node=node, path=target)))

    channel(1, 'translation', local[:, 1, :3, 3], 'VEC3')
    for i in sorted(rotation_nodes):
        quaternions = np.array([quaternion(r) for r in local[:, i, :3, :3]])
        for k in range(1, len(quaternions)):
            if quaternions[k-1] @ quaternions[k] < 0:
                quaternions[k] *= -1
        assert np.array_equal(quaternions[0], quaternions[-1])
        channel(i, 'rotation', quaternions, 'VEC4')
    assert len(animation['channels']) == 13
    doc['animations'] = [animation]
    doc['buffers'][0]['byteLength'] = len(binary)
    for key, value in original.items():
        if key not in ['buffers', 'bufferViews', 'accessors', 'animations']:
            assert doc[key] == value, key+' original document changed'
    for key in ['bufferViews', 'accessors']:
        assert doc[key][:len(original[key])] == original[key]
    encoded = json.dumps(doc, ensure_ascii=False, separators=(',', ':')).encode()
    encoded += b' '*((-len(encoded)) % 4)
    while len(binary) % 4:
        binary.append(0)
    exported = struct.pack('<III', magic, 2, 28+len(encoded)+len(binary))+struct.pack('<II', len(encoded), 0x4e4f534a)+encoded+struct.pack('<II', len(binary), 0x004e4942)+binary
    assert len(exported) <= 4194304, 'Existing 4MiB maximum remains fixed'
    out = Path(release['output_dir']).resolve()
    assert out.is_relative_to(Path('/workspace/shared')) and not out.exists()
    out.mkdir()
    name = 'horse-sevket-v16-planted-standing-v1.glb'
    (out/name).write_bytes(exported)
    # Existing accepted source samples copied for a separate loader readback;
    # this does not evaluate a new skin field or another posture.
    with np.load(pins['phase_a_arrays']['path'], allow_pickle=False) as saved:
        points = saved['points_m']
        reference = dict(rest_points_per_mesh=[points[saved[f'vertex_classes_{mi}']].tolist() for mi in range(3)],
                         vertex_classes=[saved[f'vertex_classes_{mi}'].tolist() for mi in range(3)],
                         source_protected_classes=saved['source_protected_class_ids'].tolist(),
                         source_phase_a_sha256=pins['phase_a_arrays']['sha256'])
    reference['tail_vertex_ids'] = tail['exact_source_vertex_ids']
    reference['contacts'] = json.loads(Path(pins['contact_sidecar']['path']).read_text())['contacts']
    reference_path = out/'CPU-REST-AND-PROTECTION-REFERENCE.json'
    reference_path.write_text(json.dumps(reference, separators=(',', ':'))+'\n')
    for key, row in pins.items():
        assert sha(row['path']) == row['sha256'], key+' input changed during export'
    receipt = dict(status='ACTUAL_EXPORT_ONLY_NO_LOADED_OR_VISUAL_ACCEPTANCE', schema='sevket_v16_planted_standing_export_v1',
                   source_rig_sha256=pins['rig26']['sha256'], field_sha256=pins['v16_field']['sha256'],
                   stationary_result_sha256=pins['stationary_result']['sha256'], stationary_matrices_sha256=pins['stationary_matrices']['sha256'],
                   output_file=name, output_sha256=hashlib.sha256(exported).hexdigest(), output_bytes=len(exported),
                   skin_joints=26, animation=CLIP, channels=13, keys=65, duration_s=12, interpolation='LINEAR',
                   translation_nodes=[1], rotation_nodes=sorted(rotation_nodes), local_translation_residual_limit_m=1e-9,
                   every_original_nonweight_BIN_byte_exact=True, original_document_except_buffer_append_and_new_animation_exact=True,
                   original_geometry_normals_uv_indices_materials_images_inverse_binds_exact=True, original_tail969_joint_weight_bytes_exact=True,
                   accepted_field_bytes_exact=field_ranges, original15_head_tail_clip_composed=False, walking_or_trotting_enabled=False,
                   source_credit='Horse by sevketkabatas, CC BY4.0. Modern development derivative; not historical testimony. Project-reconstructed 26-joint controls, V16 skin and planted posture.',
                   original_source_url='https://sketchfab.com/3d-models/horse-53a6eb7ccf054aa2a378dd7ec08f88fe',
                   readback_reference_file=reference_path.name, readback_reference_sha256=sha(reference_path),
                   fields_built=0, solvers=0, exports=1, inputs_unchanged_after=True,
                   pending='Khronos validation, actual GLTFLoader/Mixer all65 world/skin/normal/contact readback and actual street visuals before any app intake or activation.')
    (out/'EXPORT-RECEIPT.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
