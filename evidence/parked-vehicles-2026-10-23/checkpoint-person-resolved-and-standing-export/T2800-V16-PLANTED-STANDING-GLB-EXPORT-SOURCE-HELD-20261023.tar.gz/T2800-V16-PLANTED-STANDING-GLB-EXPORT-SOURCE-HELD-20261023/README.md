# V16 planted-standing export — source only

The accepted stationary65 unit passed at07:12:54UTC in1.625533s/68,947,968B. Its rawsource+allinputs recovery capsule is5e082cf9ca481b0cbb10b88c2b19c5651d3bba5a5d000ab680406be8374fb810. V14standingFAIL and V14/V16walkFAIL remain preserved.

This packet contains a concrete single-export producer and30s512MiB supervisor, bound to the actual03a1rig/04dfV16field/807dstationaryPASS/294fmatrices. released:false; no numerical import/export/test or browser ran while preparing it.

Read READBACK-PLAN.md before release. The producer writes only six existing skin byte ranges and appends a standard13channel clip derived from accepted world matrices. Geometry/normal/UV/index/image/IB/resttree bytes and original tail are protected. It copies existing CPUrest/protection data for independent actualGLTFLoader/Mixer readback; it never constructs a new field, evaluates new profile poses or composes the old15joint head/tail clip.

The shortest usable path is this source-preserving derivative, actual65standardloader/Mixer/whole-surface/contact readback, then an explicit26joint consumer branch in the existing standing yard. Keep canonical unit-scale/zero-origin intake separate from the old15asset native conversion, and preserve organic_dielectric_v1/hostclock/reach/confidence/pause/disposal/card/ground support guards. No application or activation is changed here.
