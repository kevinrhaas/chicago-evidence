# Shortest usable asset and actual readback path

The next deliverable is one new outside-app GLB, not another field/pose candidate.
`export_planted_standing_HELD.py` copies source03a1f747, writes the six existing
noninterleaved u16/f32 J/W ranges from accepted V16field04df5991, and appends only
13 animation channels: body1 translation and b/c/d rotations for all four limbs.
It derives local transforms as inverse(globalParent)×globalChild from the accepted
65 standing matrices294f0a1a. Other local translations must match the existing bind
tree within1e−9m; other rotations must remain identity. Existing nodes, parenting,
skins/IB, geometry, normals, UVs, indices, materials, images and all nonweight BIN
bytes remain exact. Original969 tail J/W bytes are compared directly. New weights
are copied byte-for-byte, never normalized or rebuilt.

The source GLB is3,766,696bytes, below the existing4MiB limit. Reusing its J/W ranges
avoids another277KB skin buffer;13 tracks add about14KB plusJSON. The producer
refuses a model above4,194,304bytes. It writes a separate JSON copy of already-saved
CPU rest points/classes/protected IDs and original contact triangles for readback;
that reference is not another candidate field or pose evaluation.

First root-released numerical unit: one exporter run under approvedPython3.11.17,
nice19/math1,30s/512MiB, at a fresh outside-app output directory. Then preserve its
actual model/receipt hashes and validate the standard GLB with the already-installed
Khronos validator. No Blender, installation, new mesh bake or app source edit is
needed. An export or Khronos PASS alone does not qualify animation playback.

The next source-reviewed readback can reuse the existing no-WebGL GLTFLoader/Mixer
browser caller used by the normalized horse parity proof. It creates no renderer,
camera or scene-world app. A dedicated local proof page must fetch actual source
03a1 and exported GLB bytes and verify their final hashes, plus accepted65matrices,
CPU rest/protection reference, export receipt and original physical limits. Use
actual pinned project Three/GLTFLoader. No placeholder image or fake loader path.
All embedded images must really decode; source/derived geometry and decoded
material/map facts must match. The existing normalization proof's `maps` and
shader-normal helpers provide the source-reviewed implementation basis.

Actual GLTFLoader calls `mesh.normalizeSkinWeights()` when constructing a skinned
mesh. Do not disable it and do not assert every loaded raw weight bit stayed exact.
Measure all nonprotected loaded-weight changes against serialized raw V16 bytes.
For original protected classes, tail and hoof rows, compare the derived model to
the **same standard loader's original03a1 model**, using semantic joint vectors
where slot ordering differs and exact tail slots/bits where unchanged. This
distinguishes inherited loader normalization from an authored field alteration.
The serialized derivative itself must still contain the exact accepted V16 bits.

At each of exactly65 stored times, play only the new clip with a real
AnimationMixer/LoopOnce/clampWhenFinished; update scene matrices and skeletons.
Map all26actual nodes through GLTFParser node associations, not guessed names.
Compare every actual global joint matrix to the corresponding accepted canonical
matrix. Existing rest parentchains and inverse binds must agree. Evaluate every
indexed unique vertex through actual SkinnedMesh.applyBoneTransform; expected
positions use the saved world matrices, unchanged original inverse binds, source
positions and serialized V16weights. Compare all full-surface positions at1e−5m
and directions at.01degrees, the existing portable-horse parity tolerances.
Also retain the stricter original neutral1e−6m and original physical edge/area,
ground, normal-sign, seam, segment/parent, loop and full-hoof-patch limits.

Shader normals use the native Three algebra already checked by the normalized
parity proof: normalMatrix(meshWorld) × bindMatrixInverse × weightedBoneMatrix ×
bindMatrix × vec4(normal,0), then direction normalization. Do not inverse-transpose
the weighted bone blend. Each joint is rigid and mesh world/bind are identity in
this asset; any unexpected scale/shear or changed shader contract must refuse.

Full-hoof target positions are the exact original CPU neutral rest points, with
zero route and the same59/59/13/10patches. All65 loaded postures must retain these
contacts and all original physical guards. Include real wrong-parent/local-track
and3mm-hoof corruptions that fail the same checks. Report actual source/derived
weight normalization changes and worst matrix/position/normal/contact witnesses;
any failure stays a failure. No whole-time or between-key collision proof is
claimed by65samples; LINEAR quaternion/translation interpolation is standard glTF
and its in-between appearance still needs actual inspection.

Only then adapt the standing runtime with a separate explicit26joint contract.
The current15joint head/tail adapter correctly rejects this asset: it may remain
available for its existing model, but its curves must not be retargeted by name or
advertised as composed with this clip. The new26consumer needs one clone mixer,
the same host-owned delta, deterministic seed timing, visibility/pause/reduced-
motion/disposal, current reach/texture/download/budget and source-bound contact
checks. Data must explicitly select the new derivative; do not create duplicate
overlapping horses or silently replace historical appearance/placement claims.

The shortest visible route is this source-preserving derivative plus its explicit
26consumer in the existing standing yard. No walking, team, rider or hitch code is
needed for that increment. Normally published desktop/mobile street/card/contact/
idle checks and honest appearance review remain before DEV delivery. Successful
sampled standing posture is not photographic anatomy, force/load transfer or
independent head/ear/tail animation acceptance.

Coordinate intake must be explicit: this26rig asset is already canonical metres,
+Y up/+Z forward. Its new sidecar uses unit scale and zero model origin after
actual readback. Do not apply the current15asset's0.3644068837 native-unit scale or
its native-origin subtraction again. Preserve the existing stand/support carrier
only after its canonical whole-patch samples agree with the new actual loader.
Update contact mesh node/native bounds/minimum anchors from actual26decode; retain
original triangle/vertex provenance. Keep the existing `organic_dielectric_v1`
runtime variant (metalness0) separately from unchanged raw source materials, along
with confidence/shadow patches and current disposal; don't silently lose those
existing appearance/selection safeguards while adding a26joint branch.
