"""HELD single upper-attachment correction; frozen V14 lower field is immutable.

Two-sided topology/geometry collar, actual proximal link length; no optimizer,
parameter search, class whitelist, threshold/profile change or model export.
"""
from pathlib import Path
import hashlib,json,sys
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
HERE=Path(__file__).resolve().parent
OUT=HERE/'ACTUAL'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def h5(u):return u*u*u*(10+u*(-15+6*u))
def original_joint_ownership(w):
    own=w[:,2:6].max(1);other=w[:,[0,1]+list(range(6,26))].max(1)
    return own>other,(own==other)&(own>0)

def build(rest,parts,controls,hoof_patch_ids):
    release=json.loads(Path(sys.argv[1]).read_text())
    assert release['released'] is True and release['authorization']=='ONE_ROOT_AUTHORIZED_V16_TWO_SIDED_BIND_ORIGINAL65'
    for name,digest in release['source_sha256'].items():assert sha(HERE/name)==digest,name+' drift'
    pins=json.loads((HERE/'INPUT-PINS.json').read_text())
    for key,row in pins.items():assert sha(row['path'])==row['sha256'],key+' drift'
    source=json.loads(Path(pins['v14_field_receipt']['path']).read_text())
    assert source['original_protected_vectors_exact'] and source['tail_vertices_bits_exact']==969
    assert source['new_field_constructions']==1 and source['QP_certificate_pass'] is False
    with np.load(pins['phase_a_arrays']['path'],allow_pickle=False) as f:data={name:f[name].copy() for name in f.files}
    points=data['points_m'];vc=[data['vertex_classes_'+str(mi)] for mi in range(3)];n=len(points)
    assert all(np.array_equal(points[vc[mi]],p) for mi,p in enumerate(rest))
    with np.load(pins['v14_arrays']['path'],allow_pickle=False) as f:
        arrays=[(f['mesh_'+str(mi)+'_joints'].copy(),f['mesh_'+str(mi)+'_weights'].copy()) for mi in range(3)]
    assert all(j.dtype==np.uint16 and w.dtype==np.float32 and j.shape==w.shape==(len(rest[mi]),4) for mi,(j,w) in enumerate(arrays))
    originals=[(j.copy(),w.copy()) for j,w in arrays]
    # Exact old f64 source prior only; never optimize or treat it as accepted.
    baseline=np.zeros((n,26));baseline[data['declared_known_class_ids']]=data['declared_known_vectors']
    with np.load(pins['phase_c_vector']['path'],allow_pickle=False) as f:baseline[f['var_class_ids'],f['var_joint_ids']]=f['x']
    protected=np.zeros(n,dtype=bool);protected[data['source_protected_class_ids']]=True
    v12=json.loads(Path(pins['v12_report']['path']).read_text())
    tri=vc[1][parts[1][4]];body=np.zeros(n,dtype=bool);body[vc[1]]=True
    area=np.linalg.norm(np.cross(points[tri[:,1]]-points[tri[:,0]],points[tri[:,2]]-points[tri[:,0]]),axis=1)/2
    gt=tri[area>0];edges=np.unique(np.concatenate([np.sort(gt[:,[a,b]],axis=1) for a,b in ((0,1),(1,2),(2,0))]),axis=0);edges=edges[edges[:,0]!=edges[:,1]]
    lengths=np.linalg.norm(points[edges[:,0]]-points[edges[:,1]],axis=1);assert (lengths>1e-8).all()
    metric=coo_matrix((np.r_[lengths,lengths],(np.r_[edges[:,0],edges[:,1]],np.r_[edges[:,1],edges[:,0]])),shape=(n,n)).tocsr()
    full={};lower={};raw={};extents={};distance={}
    for row in source['full_domain_reconstruction']:
        label=row['limb'];a,b,c,d,e=controls['limbs'][label]['joints']
        full[label]=np.zeros(n,dtype=bool);full[label][row['full_b_classes']]=True
        lower[label]=np.zeros(n,dtype=bool);lower[label][v12['regions'][label+':H_c_cannon_handle']['class_ids']]=True
        pa=np.asarray(controls['nodes'][a]['rest_world_pivot_m']);pb=np.asarray(controls['nodes'][b]['rest_world_pivot_m'])
        extent=float(np.linalg.norm(pb-pa));extents[label]=extent
        dist=dijkstra(metric,directed=False,indices=np.asarray(row['old_boundary_star'],dtype=int),min_only=True)
        distance[label]=dist
        # Both sides of original b contour, one ACTUAL proximal link length.
        raw[label]=body&((dist<extent)|full[label])
    counts=sum(mask.astype(int) for mask in raw.values())
    changed=np.zeros(n,dtype=bool);new_values=np.zeros((n,26));receipts=[]
    for label,region in raw.items():
        a,b,c,d,e=controls['limbs'][label]['joints'];C=lower[label]
        overlap=region&(counts>1)&~C
        # Ambiguous proximal collars are a shared zero-support boundary, never
        # assigned by arbitrary nearest-bone choice or a class-ID exception.
        assert not (overlap&full[label]).any(),'Ambiguous overlap reaches a limb component; no ownership fallback'
        proximal=((~region)|protected|overlap)&~C
        assert proximal.any() and C.any() and not (proximal&C).any()
        dp=dijkstra(metric,directed=False,indices=np.flatnonzero(proximal&body),min_only=True)
        dd=dijkstra(metric,directed=False,indices=np.flatnonzero(C),min_only=True)
        active=region&~C&~proximal
        assert not (active&protected).any() and not (active&changed).any()
        denom=dp[active]+dd[active];assert np.isfinite(denom).all() and (denom>0).all()
        u=dp[active]/denom;assert ((u>=0)&(u<=1)).all();alpha=h5(u)
        # Upstream source attachment, with own b/e mass returning to body.
        # Existing raw head/tail/proximal labels are retained, not relabelled.
        P=baseline[active].copy();P[:,1]+=P[:,b]+P[:,e];P[:,b]=0;P[:,e]=0
        Q=np.zeros_like(P);y=points[active,1];below=y<.62
        Q[~below,b]=1
        v=(.62-y[below])/(.62-.32);assert ((v>=0)&(v<=1)).all()
        s=h5(v);Q[below,b]=1-s;Q[below,c]=s
        W=(1-alpha[:,None])*P+alpha[:,None]*Q
        assert np.isfinite(W).all() and (W>=0).all() and (W<=1).all()
        assert np.abs(W.sum(1)-1).max()<=1e-8
        assert ((W>0).sum(1)<=4).all(),'GPU4 palette refusal, no prune/renorm'
        new_values[active]=W;changed|=active
        receipts.append({'limb':label,'rest_proximal_link_extent_m':extents[label],'active_classes':np.flatnonzero(active).tolist(),'ambiguous_proximal_boundary_classes':np.flatnonzero(overlap).tolist(),'C2_quintic_in_geodesic_coordinate':True,'global_C2_surface_not_claimed':True})
    # Frozen source protection and ALL lower c/d/pastern/hoof rows are bitwise
    # immutable. Only genuinely unprotected upper attachment classes change.
    assert not (changed&protected).any()
    for C in lower.values():assert not (changed&C).any()
    ids=np.flatnonzero(changed);assert len(ids)>0,'No upper attachment changes; refuse no-op'
    authored=new_values[ids];cast=authored.astype(np.float32)
    joints=np.zeros((len(ids),4),dtype=np.uint16);weights=np.zeros((len(ids),4),dtype=np.float32)
    for row,p in enumerate(authored):
        palette=np.flatnonzero(p>0);joints[row,:len(palette)]=palette;weights[row,:len(palette)]=cast[row,palette]
    lookup=np.full(n,-1,dtype=int);lookup[ids]=np.arange(len(ids))
    for mi,classes in enumerate(vc):
        chosen=changed[classes];rows=lookup[classes[chosen]]
        arrays[mi][0][chosen]=joints[rows];arrays[mi][1][chosen]=weights[rows]
        immutable=(~changed[classes])|protected[classes]
        assert np.array_equal(arrays[mi][0][immutable],originals[mi][0][immutable])
        assert np.array_equal(arrays[mi][1][immutable].view(np.uint32),originals[mi][1][immutable].view(np.uint32))
    for label,patch in hoof_patch_ids.items():
        e=controls['limbs'][label]['joints'][-1];j,w=arrays[1]
        assert np.all(np.where(j[patch]==e,w[patch],0).sum(1)==1)
    # Negative controls inspect synthetic copies of the immutable-row contract.
    def immutable_rows_equal(candidate):
        return all(np.array_equal(candidate[mi][1][~changed[vc[mi]]].view(np.uint32),originals[mi][1][~changed[vc[mi]]].view(np.uint32)) for mi in range(3))
    bad=[(j.copy(),w.copy()) for j,w in arrays];mi,vi=next((mi,int(np.flatnonzero(protected[vc[mi]])[0])) for mi in range(3) if protected[vc[mi]].any());bad[mi][1][vi]*=.5
    assert not immutable_rows_equal(bad)
    lower_class=int(np.flatnonzero(next(iter(lower.values())))[0]);lower_vertex=int(np.flatnonzero(vc[1]==lower_class)[0])
    bad_lower=[(j.copy(),w.copy()) for j,w in arrays];bad_lower[1][1][lower_vertex]*=.5
    assert not immutable_rows_equal(bad_lower)
    receipt={'status':'ONE_TWO_SIDED_UPPER_ATTACHMENT_FIELD_ONLY_NO_ACCEPTANCE','source_V14_arrays_sha256':pins['v14_arrays']['sha256'],'original_protected_vectors_exact':True,'tail_vertices_bits_exact':969,'tail_classes':901,'original_lower_field_bits_exact':True,'V12_pastern_ledger_unchanged':True,'field_constructions':1,'changed_upper_classes':len(ids),'attachment_regions':receipts,'updated_row_float32_casts':1,'clipping_pruning_or_renormalization':False,'maximum_updated_cast_error':float(np.abs(cast.astype(float)-authored).max()),'negative_controls':{'original_anchor_corruption_rejected':True,'frozen_lower_field_corruption_rejected':True},'profile_gait_threshold_changes':False,'solvers':0,'exports':0,'prior_V14_WALK_FAIL_preserved':True,'scope':'One geometry-derived two-sided upper attachment only; C2 profile in graph coordinate is not a global surface smoothness or strain guarantee.'}
    np.savez_compressed(OUT/'DIAGNOSTIC-FLOAT32-ANATOMICAL-ARRAYS-NOT-MODEL.npz',**{'mesh_'+str(mi)+'_'+key:value for mi,pair in enumerate(arrays) for key,value in [('joints',pair[0]),('weights',pair[1])]})
    (OUT/'ANATOMICAL-BIND-SERIALIZATION-READBACK.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return arrays,receipt
