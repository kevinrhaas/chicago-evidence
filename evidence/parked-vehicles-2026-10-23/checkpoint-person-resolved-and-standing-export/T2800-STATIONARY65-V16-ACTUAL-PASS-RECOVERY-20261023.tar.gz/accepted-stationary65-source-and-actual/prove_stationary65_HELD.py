"""ONE future stationary65 check of an EXISTING saved V16 float32 field.

No builder, optimization, field candidate, float32 recast, clip export or runtime.
Walking need not pass: standing is a separately measured smaller motion domain.
"""
import ast
import datetime
import hashlib
import json
import math
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
AUTHORIZATION = 'ONE_ROOT_AUTHORIZED_STATIONARY65_SAVED_V16_UPPER_FIELD'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    start = time.monotonic()
    release = json.loads(Path(sys.argv[1]).read_text())
    assert release['released'] is True and release['authorization'] == AUTHORIZATION
    assert release['maximum_fields'] == release['maximum_solvers'] == release['maximum_exports'] == 0
    assert release['maximum_stationary65_diagnostics'] == release['maximum_runs'] == 1
    assert set(release['source_sha256']) == {'actual_model.py', 'standing_planted_pose_HELD.py', 'prove_stationary65_HELD.py', 'run_once_HELD.py', 'ORIGINAL-PHYSICAL-LIMITS.json'}
    for name, digest in release['source_sha256'].items():
        assert sha(HERE / name) == digest, name + ' source drift'
    assert release['source_sha256'][Path(__file__).name] == sha(__file__)
    pins = release['input_pins']
    assert set(pins) == {'rig26', 'controls26', 'contact_sidecar', 'tail_fixture', 'phase_a_arrays', 'original_walk_threshold_source', 'v16_float32_arrays', 'v16_field_receipt', 'v16_terminal', 'v16_walk_report', 'v14_source_arrays', 'v14_source_receipt', 'v12_report', 'v16_binding_source'}
    for key, pin in pins.items():
        if key == 'v16_walk_report' and pin is None:
            continue
        assert isinstance(pin['path'], str) and len(pin['sha256']) == 64, key + ' unbound'
        assert sha(pin['path']) == pin['sha256'], key + ' input drift'
    # Guard the release and all immutable bytes before any numerical import.
    import numpy as np
    from actual_model import Model
    from standing_planted_pose_HELD import pose, PARAMETERS
    out = HERE / 'ACTUAL'
    assert out.is_dir()
    original_tree = ast.parse(Path(pins['original_walk_threshold_source']['path']).read_text())
    limits = next(ast.literal_eval(n.value) for n in original_tree.body
                  if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'THRESHOLDS' for t in n.targets))
    assert limits == json.loads((HERE / 'ORIGINAL-PHYSICAL-LIMITS.json').read_text())
    field_receipt = json.loads(Path(pins['v16_field_receipt']['path']).read_text())
    source_receipt = json.loads(Path(pins['v14_source_receipt']['path']).read_text())
    assert pins['v14_source_arrays']['sha256'] == '8df6411c4d288f64f1f9abbb5e375259bba088e435a70c616a317c0000b71025'
    assert pins['v16_float32_arrays']['sha256'] != pins['v14_source_arrays']['sha256'], 'No unchanged-field retry'
    assert field_receipt['source_V14_arrays_sha256'] == pins['v14_source_arrays']['sha256']
    assert source_receipt['float32_casts'] == 1 and source_receipt['new_field_constructions'] == 1
    assert source_receipt['roundoff_mass_envelope_verified'] is True and source_receipt['QP_certificate_pass'] is False
    assert source_receipt['original_protected_vectors_exact'] is True and source_receipt['tail_vertices_bits_exact'] == 969
    terminal = json.loads(Path(pins['v16_terminal']['path']).read_text())
    assert terminal['no_owned_child_active'] is True, 'V16 must actually end first'
    assert field_receipt['original_protected_vectors_exact'] is True
    assert field_receipt['tail_vertices_bits_exact'] == 969 and field_receipt['tail_classes'] == 901
    assert field_receipt['updated_row_float32_casts'] == 1 and field_receipt['clipping_pruning_or_renormalization'] is False
    assert field_receipt['field_constructions'] == 1 and field_receipt['original_lower_field_bits_exact'] is True
    assert field_receipt['V12_pastern_ledger_unchanged'] is True and field_receipt['prior_V14_WALK_FAIL_preserved'] is True
    assert field_receipt['profile_gait_threshold_changes'] is False and field_receipt['solvers'] == field_receipt['exports'] == 0
    producer = ast.parse(Path(pins['v16_binding_source']['path']).read_text())
    simplex_guard = ast.dump(ast.parse('assert np.abs(W.sum(1)-1).max() <= 1e-8').body[0], include_attributes=False)
    assert sum(ast.dump(n, include_attributes=False) == simplex_guard for n in ast.walk(producer) if isinstance(n, ast.Assert)) == 1
    updated_f64_simplex_bound = 1e-8  # Exact executed producer assertion, not a physical tolerance.
    updated_cast_error = field_receipt['maximum_updated_cast_error']
    assert math.isfinite(updated_cast_error) and updated_cast_error >= 0
    old_mass_envelope = source_receipt['f64_simplex_residual'] + 4 * source_receipt['maximum_cast_error'] + 2e-15
    updated_mass_envelope = updated_f64_simplex_bound + 4 * updated_cast_error + 2e-15
    # No requirement for V16 WALK PASS: retain its actual result verbatim.
    prior_walk = json.loads(Path(pins['v16_walk_report']['path']).read_text()) if pins['v16_walk_report'] else None
    model = Model(Path(pins['rig26']['path']))
    assert sha(pins['rig26']['path']) == '03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36'
    assert not model.g.get('animations')
    controls = json.loads(Path(pins['controls26']['path']).read_text())
    side = json.loads(Path(pins['contact_sidecar']['path']).read_text())
    tail = json.loads(Path(pins['tail_fixture']['path']).read_text())
    assert tail['source_rig_sha256'] == pins['rig26']['sha256']
    pivots = np.array([model.world(i)[:3, 3] for i in range(26)])
    inverse_bind = model.accessor(model.g['skins'][0]['inverseBindMatrices']).reshape(-1, 4, 4).transpose(0, 2, 1)
    limbs = controls['limbs']
    with np.load(pins['phase_a_arrays']['path'], allow_pickle=False) as saved:
        classes = [saved[f'vertex_classes_{mi}'].copy() for mi in range(3)]
        protected = saved['source_protected_class_ids'].copy()
        known_ids, known_vectors = saved['declared_known_class_ids'].copy(), saved['declared_known_vectors'].copy()
        source_points = saved['points_m'].copy()
    updated_ids = np.asarray(sorted({ci for row in field_receipt['attachment_regions'] for ci in row['active_classes']}), dtype=int)
    assert len(updated_ids) == field_receipt['changed_upper_classes'] == 467
    assert sum(len(row['active_classes']) for row in field_receipt['attachment_regions']) == len(updated_ids)
    v12 = json.loads(Path(pins['v12_report']['path']).read_text())
    lower_ids = np.asarray(sorted({ci for label in limbs for ci in v12['regions'][label+':H_c_cannon_handle']['class_ids']}), dtype=int)
    assert not np.intersect1d(updated_ids, protected).size and not np.intersect1d(updated_ids, lower_ids).size
    with np.load(pins['v14_source_arrays']['path'], allow_pickle=False) as saved:
        source_arrays = [(saved[f'mesh_{mi}_joints'].copy(), saved[f'mesh_{mi}_weights'].copy()) for mi in range(3)]
    original_parts, parts, rest = [], [], []
    expected_keys = {f'mesh_{mi}_{key}' for mi in range(3) for key in ('joints', 'weights')}
    with np.load(pins['v16_float32_arrays']['path'], allow_pickle=False) as saved:
        assert set(saved.files) == expected_keys
        for mi, ni in enumerate((26, 27, 28)):
            node = model.g['nodes'][ni]
            primitive = model.g['meshes'][node['mesh']]['primitives'][0]
            a = primitive['attributes']
            pos = model.accessor(a['POSITION']).astype(float)
            normal = model.accessor(a['NORMAL']).astype(float)
            original_joints = model.accessor(a['JOINTS_0']).astype(np.uint16)
            original_weights = model.accessor(a['WEIGHTS_0'])
            assert original_weights.dtype == np.float32
            indices = model.accessor(primitive['indices']).astype(int).reshape(-1, 3)
            joints, weights = saved[f'mesh_{mi}_joints'].copy(), saved[f'mesh_{mi}_weights'].copy()
            assert joints.dtype == np.uint16 and weights.dtype == np.float32
            assert joints.shape == weights.shape == (len(pos), 4)
            assert (joints < 26).all() and np.isfinite(weights).all() and (weights >= 0).all() and (weights <= 1).all()
            old_j, old_w = source_arrays[mi]
            assert old_j.dtype == np.uint16 and old_w.dtype == np.float32 and old_j.shape == old_w.shape == joints.shape
            updated_rows = np.isin(classes[mi], updated_ids)
            frozen_rows = ~updated_rows
            assert np.array_equal(joints[frozen_rows], old_j[frozen_rows])
            assert np.array_equal(weights[frozen_rows].view(np.uint32), old_w[frozen_rows].view(np.uint32))
            envelope = np.where(updated_rows, updated_mass_envelope, old_mass_envelope)
            assert np.all(np.abs(weights.astype(float).sum(1) - 1) <= envelope)
            original_parts.append((original_joints, original_weights.copy()))
            parts.append((pos, normal, joints, weights, indices))
            rest.append(model.mesh(ni)[0])
    for mi in range(3):
        assert np.array_equal(source_points[classes[mi]], rest[mi])
    tail_vertices = np.asarray(tail['exact_source_vertex_ids'], dtype=int)
    tail_classes = np.unique(classes[0][tail_vertices])
    assert len(tail_vertices) == 969 and len(tail_classes) == 901
    expected_known = np.zeros((len(source_points), 26), dtype=np.float32)
    expected_known[known_ids] = known_vectors.astype(np.float32)
    assert np.isin(protected, known_ids).all()

    def validate_source_protection(candidate):
        for mi, (_, _, joints, weights, _) in enumerate(candidate):
            frozen = ~np.isin(classes[mi], updated_ids)
            old_j, old_w = source_arrays[mi]
            assert np.array_equal(joints[frozen], old_j[frozen]), 'Frozen V14 joint slots changed'
            assert np.array_equal(weights[frozen].view(np.uint32), old_w[frozen].view(np.uint32)), 'Frozen V14 lower/nonupdated weight bits changed'
            selected = np.flatnonzero(np.isin(classes[mi], protected) & ~np.isin(classes[mi], tail_classes))
            recovered = np.zeros((len(selected), 26), dtype=np.float32)
            np.add.at(recovered, (np.arange(len(selected))[:, None], joints[selected]), weights[selected])
            assert np.array_equal(recovered, expected_known[classes[mi][selected]]), 'Original source-known vector changed'
        j, w = candidate[0][2:4]
        old_j, old_w = original_parts[0]
        assert np.array_equal(j[tail_vertices], old_j[tail_vertices]), 'Original tail joint slots changed'
        assert np.array_equal(w[tail_vertices].view(np.uint32), old_w[tail_vertices].view(np.uint32)), 'Original tail weight bits changed'

    validate_source_protection(parts)
    patches = {label: np.unique(parts[1][4][row['source_triangle_ids']].ravel()) for label, row in side['contacts'].items()}
    assert {k: len(v) for k, v in patches.items()} == {'fore_l': 59, 'fore_r': 59, 'hind_l': 13, 'hind_r': 10}
    for label, ids in patches.items():
        j, w = parts[1][2:4]
        own = limbs[label]['joints'][-1]
        assert np.all(np.where(j[ids] == own, w[ids], 0).sum(1) == 1)

    def skin(matrices):
        transforms, points, normals = matrices @ inverse_bind, [], []
        for pos, normal, joints, weights, _ in parts:
            blend = np.einsum('nw,nwij->nij', weights, transforms[joints])
            points.append(np.einsum('nij,nj->ni', blend, np.c_[pos, np.ones(len(pos))])[:, :3])
            n = np.einsum('nij,nj->ni', blend, np.c_[normal, np.zeros(len(normal))])[:, :3]
            n /= np.linalg.norm(n, axis=1)[:, None]
            normals.append(n)
        return points, normals

    def chain_errors(matrices):
        length_error = parent_error = 0.
        for row in limbs.values():
            for a, b in zip(row['joints'][:-1], row['joints'][1:]):
                length_error = max(length_error, abs(np.linalg.norm(matrices[b, :3, 3] - matrices[a, :3, 3]) - np.linalg.norm(pivots[b] - pivots[a])))
                expected = matrices[a, :3, 3] + matrices[a, :3, :3] @ (pivots[b] - pivots[a])
                parent_error = max(parent_error, float(np.linalg.norm(matrices[b, :3, 3] - expected)))
        return float(length_error), parent_error

    def contact_error(points):
        return max(float(np.linalg.norm(points[1][ids] - rest[1][ids], axis=1).max()) for ids in patches.values())

    neutral, neutral_states = pose(0., pivots, limbs)
    assert np.array_equal(neutral[:, :3, 3], pivots) and np.array_equal(neutral[:, :3, :3], np.repeat(np.eye(3)[None], 26, axis=0))
    neutral_points, neutral_normals = skin(neutral)
    neutral_delta = max(float(np.abs(a-b).max()) for a, b in zip(neutral_points, rest))
    assert neutral_delta <= 1e-6, 'Original neutral tolerance'
    base_edges, base_areas, base_normals = [], [], []
    for mi, points in enumerate(rest):
        tri = points[parts[mi][4]]
        base_edges.append(np.linalg.norm(tri[:, [1, 2, 0]] - tri[:, [0, 1, 2]], axis=2))
        norm = np.cross(tri[:, 1]-tri[:, 0], tri[:, 2]-tri[:, 0])
        base_normals.append(norm)
        base_areas.append(np.linalg.norm(norm, axis=1))
    seam_classes = {}
    for mi, points in enumerate(rest):
        for vi, point in enumerate(points):
            seam_classes.setdefault(tuple(np.rint(point / 1e-6).astype(int)), []).append((mi, vi))
    seam_pairs = [(v[0], other) for v in seam_classes.values() for other in v[1:]]
    surfaces = [dict(mesh=mi, vertices=len(points), triangles=len(parts[mi][4]), edge_ratio_min=1., edge_ratio_max=1., area_ratio_min=1., area_ratio_max=1., max_rest_relative_normal_dot_negative_count=0, minimum_y_m=1e9) for mi, points in enumerate(rest)]
    contact = {label: dict(vertices=len(ids), stationary_samples=0, original_neutral_patch_residual_m=0., neutral_candidate_patch_drift_m=0.) for label, ids in patches.items()}
    witnesses, frames = {}, []
    maximum_length = maximum_parent = maximum_seam = 0.
    finite = True
    quarter = None
    for sample, t in enumerate(np.linspace(0., PARAMETERS['period_s'], 65)):
        matrices, states = pose(float(t), pivots, limbs)
        moved, normals = skin(matrices)
        finite &= all(np.isfinite(p).all() and np.isfinite(n).all() for p, n in zip(moved, normals))
        le, pe = chain_errors(matrices)
        maximum_length, maximum_parent = max(maximum_length, le), max(maximum_parent, pe)
        for label, ids in patches.items():
            e = limbs[label]['joints'][-1]
            assert states[label]['stance'] is True
            assert np.array_equal(matrices[e, :3, 3], pivots[e]) and np.array_equal(matrices[e, :3, :3], np.eye(3)), 'Original neutral hoof transform changed'
            row = contact[label]
            row['stationary_samples'] += 1
            row['original_neutral_patch_residual_m'] = max(row['original_neutral_patch_residual_m'], float(np.linalg.norm(moved[1][ids]-rest[1][ids], axis=1).max()))
            row['neutral_candidate_patch_drift_m'] = max(row['neutral_candidate_patch_drift_m'], float(np.linalg.norm(moved[1][ids]-neutral_points[1][ids], axis=1).max()))
        for mi, points in enumerate(moved):
            tri, s = points[parts[mi][4]], surfaces[mi]
            edges = np.linalg.norm(tri[:, [1, 2, 0]]-tri[:, [0, 1, 2]], axis=2)
            ratio = np.divide(edges, base_edges[mi], out=np.ones_like(edges), where=base_edges[mi] > 1e-8)
            norm = np.cross(tri[:, 1]-tri[:, 0], tri[:, 2]-tri[:, 0])
            area = np.linalg.norm(norm, axis=1)
            area_ratio = np.divide(area, base_areas[mi], out=np.ones_like(area), where=base_areas[mi] > 1e-12)
            s['edge_ratio_min'], s['edge_ratio_max'] = min(s['edge_ratio_min'], float(ratio.min())), max(s['edge_ratio_max'], float(ratio.max()))
            s['area_ratio_min'], s['area_ratio_max'] = min(s['area_ratio_min'], float(area_ratio.min())), max(s['area_ratio_max'], float(area_ratio.max()))
            s['max_rest_relative_normal_dot_negative_count'] = max(s['max_rest_relative_normal_dot_negative_count'], int(np.count_nonzero((np.einsum('ni,ni->n', base_normals[mi], norm) < 0) & (base_areas[mi] > 1e-12))))
            s['minimum_y_m'] = min(s['minimum_y_m'], float(points[:, 1].min()))
            for key, values, maximize in [('edge_min', ratio, False), ('edge_max', ratio, True), ('area_min', area_ratio, False), ('area_max', area_ratio, True)]:
                flat = int(np.argmax(values) if maximize else np.argmin(values))
                value, prior = float(values.flat[flat]), witnesses.get(key)
                if prior is not None and ((value <= prior['value']) if maximize else (value >= prior['value'])):
                    continue
                ti = flat // 3 if values.ndim == 2 else flat
                ids = parts[mi][4][ti]
                witnesses[key] = dict(mesh=mi, triangle=int(ti), time_s=float(t), value=value, vertex_ids=ids.tolist(), rest_m=rest[mi][ids].tolist(), posed_m=points[ids].tolist())
        for (ma, va), (mb, vb) in seam_pairs:
            maximum_seam = max(maximum_seam, float(np.linalg.norm(moved[ma][va]-moved[mb][vb])))
        if sample == 16:
            quarter = matrices.copy()
        frames.append(dict(time_s=float(t), global_canonical_matrices=matrices.tolist(), limb_states=states))
    last, _ = pose(PARAMETERS['period_s'], pivots, limbs)
    loop_position = float(np.abs(neutral[:, :3, 3]-last[:, :3, 3]).max())
    loop_rotation = float(np.abs(neutral[:, :3, :3]-last[:, :3, :3]).max())
    assert quarter is not None
    # Corrupt real saved data/poses only. No new field/solve or second pose grid.
    bad = neutral.copy()
    bad[limbs['fore_l']['joints'][-1], 1, 3] += .003
    bad_hoof_points, _ = skin(bad)
    bad_contact = contact_error(bad_hoof_points)
    bad_length, _ = chain_errors(bad)
    body_only = neutral.copy()
    body_only[1:, :3, 3] += quarter[1, :3, 3]-pivots[1]
    bad_body_points, _ = skin(body_only)
    bad_body_contact = contact_error(bad_body_points)
    def protection_corruption(tail_corruption, lower_corruption=False):
        bad_parts = list(parts)
        if tail_corruption:
            mi, vi = 0, int(tail_vertices[0])
        elif lower_corruption:
            mi, vi = next((mi, int(np.flatnonzero(np.isin(classes[mi], lower_ids))[0])) for mi in range(3) if np.any(np.isin(classes[mi], lower_ids)))
        else:
            mi, vi = next((mi, int(np.flatnonzero(np.isin(classes[mi], protected) & ~np.isin(classes[mi], tail_classes))[0])) for mi in range(3) if np.any(np.isin(classes[mi], protected) & ~np.isin(classes[mi], tail_classes)))
        pos, normal, joints, weights, indices = bad_parts[mi]
        weights = weights.copy()
        slot = int(np.flatnonzero(weights[vi] > 0)[0])
        weights[vi, slot] = np.nextafter(weights[vi, slot], np.float32(0)) if tail_corruption else weights[vi, slot] * .5
        bad_parts[mi] = (pos, normal, joints, weights, indices)
        try:
            validate_source_protection(bad_parts)
        except AssertionError:
            return True
        return False
    negative = dict(three_mm_real_hoof_patch_drift_m=bad_contact, three_mm_real_hoof_segment_error_m=bad_length,
                    naive_body_only_no_closure_patch_drift_m=bad_body_contact,
                    changed_original_known_vector_rejected=protection_corruption(False), changed_original_tail_weight_bit_rejected=protection_corruption(True),
                    changed_frozen_lower_vector_rejected=protection_corruption(False, lower_corruption=True))
    negative['all_detected'] = bool(bad_contact > limits['stance_patch_drift_m'] and bad_length > limits['segment_length_error_m'] and bad_body_contact > limits['stance_patch_drift_m'] and negative['changed_original_known_vector_rejected'] and negative['changed_original_tail_weight_bit_rejected'] and negative['changed_frozen_lower_vector_rejected'])
    mechanics = bool(finite and maximum_length <= limits['segment_length_error_m'] and maximum_parent <= limits['segment_length_error_m'] and loop_position <= limits['loop_position_m'] and loop_rotation <= limits['loop_rotation_matrix_abs'] and all(r['original_neutral_patch_residual_m'] <= limits['stance_patch_drift_m'] and r['neutral_candidate_patch_drift_m'] <= limits['stance_patch_drift_m'] for r in contact.values()))
    deformation = bool(all(r['edge_ratio_min'] >= limits['minimum_triangle_edge_ratio'] and r['edge_ratio_max'] <= limits['maximum_triangle_edge_ratio'] and r['area_ratio_min'] >= limits['minimum_triangle_area_ratio'] and r['area_ratio_max'] <= limits['maximum_triangle_area_ratio'] and r['max_rest_relative_normal_dot_negative_count'] == limits['allowed_rest_relative_triangle_normal_dot_negative'] and r['minimum_y_m'] >= limits['minimum_all_surface_y_m'] for r in surfaces) and maximum_seam <= limits['minimum_seam_gap_tolerance_m'])
    for key, pin in pins.items():
        if pin is not None:
            assert sha(pin['path']) == pin['sha256'], key + ' input changed after observation'
    result = dict(status='STATIONARY65_SAVED_FIELD_CPU_PASS_ONLY' if mechanics and deformation and negative['all_detected'] else 'STATIONARY65_SAVED_FIELD_CPU_FAIL',
                  source_field_sha256=pins['v16_float32_arrays']['sha256'], mechanics_pass=mechanics, deformation_screen_pass=deformation,
                  original_known_and_tail_protection_pass=True, neutral_maximum_position_delta_m=neutral_delta, neutral_position_tolerance_m=1e-6,
                  thresholds=limits, parameters=PARAMETERS, sampled_poses=65, route_root_advance_m=0.,
                  maximum_segment_length_error_m=maximum_length, maximum_parent_chain_residual_m=maximum_parent,
                  loop_position_error_m=loop_position, loop_rotation_matrix_abs_error=loop_rotation, maximum_seam_gap_m=maximum_seam,
                  all_finite=bool(finite), contacts=contact, surfaces=surfaces, witnesses=witnesses, negative_controls=negative,
                  v16_terminal_status_preserved=terminal['status'], v16_walk_report_status_preserved=prior_walk['status'] if prior_walk else 'NO_COMPLETED_WALK_REPORT',
                  original_v14_field_sha256=pins['v14_source_arrays']['sha256'], all_nonupdated_and_lower_field_bits_exact=True,
                  mass_validation=dict(updated_f64_simplex_bound=updated_f64_simplex_bound, maximum_updated_cast_error=updated_cast_error,
                                       updated_row_mass_envelope=updated_mass_envelope, original_v14_mass_envelope=old_mass_envelope,
                                       justification='Triangle inequality for <=4 stored weights: |sum(f32)-1| <= |sum(f64)-1| + sum(abs(cast error)); physical limits unchanged.'),
                  prior_walk_pass_not_required=True, walk_or_trot_or_force_load_transfer_accepted=False,
                  new_fields=0, solver_calls=0, exports=0, original15_hostclock_or_app_edits=0,
                  scope='One fixed canonical planted-standing posture on exactly saved V16 field. No continuous collision, anatomy, composed head/tail, glTF/Mixer, street/terrain carrier, visual/photo, harness, rider, traffic or activation qualification.', elapsed_seconds=time.monotonic()-start)
    (out / 'STATIONARY65-RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    (out / 'STATIONARY65-MATRICES.json').write_text(json.dumps(dict(frames=frames), separators=(',', ':'))+'\n')
    print(json.dumps(result, indent=2), flush=True)
    return 0 if result['status'] == 'STATIONARY65_SAVED_FIELD_CPU_PASS_ONLY' else 2


if __name__ == '__main__':
    raise SystemExit(main())
