# V16 saved upper-field standing check — source only, held

This adapts the reviewed stationary65 reader to the **actual different V16 field**
04df5991, not an unchanged retry of V14 field8df6411c. V16's walk remains an
actual FAIL. The previous stationary V14 failure remains immutable in capsule
35aaeb83. No field is built, optimized, renormalized or exported by this reader.

The only code changes are receipt/lineage guards, row-specific serialization mass
validation, an additional frozen-lower corruption control, and identity labels.
`MINIMAL-V14-TO-V16-ADAPTATION.patch` is the complete two-file code diff. The exact
1404bfb2 standing profile, all65 sample-loop code, skin/chain/contact metrics and
mechanics/deformation predicates are unchanged. Original physical thresholds are
byte-exact b64a5784. A Python-AST-only comparison records this source equivalence;
no numerical imports, field/pose evaluation or tests ran during preparation.

V16's schema truthfully reports **one cast of only updated rows**, not another cast
of its frozen lower field. The checker accepts the actual `updated_row_float32_casts`,
`field_constructions` and `maximum_updated_cast_error` keys. Its original V14 NPZ
and serialization receipt are separate pinned lineage inputs. The actual producer
source is also pinned: its executed `assert abs(sum(W)-1) <= 1e-8` guard supplies
the float64 simplex bound for each newly authored row.

For at most four stored weights and cast error epsilon, triangle inequality gives

    abs(sum(float32 weights)-1) <= abs(sum(float64 weights)-1) + 4*epsilon.

Updated rows therefore use `1e-8 + 4*maximum_updated_cast_error + 2e-15`, with the
same small summation allowance as the previous serialization guard. Unmodified
rows retain exactly `old_f64_simplex_residual + 4*old_maximum_cast_error + 2e-15`
from the original V14 receipt. This is a serialization-roundoff bound; it does not
alter any physical, contact, neutral, edge, area, ground or motion tolerance.

The reader independently verifies all nonupdated joint slots and float32 weight
bits against the frozen V14 NPZ. It separately reconstructs the immutable lower
class set from the already-recorded V12 H_c masks and checks the467 updated upper
classes are disjoint from it and every original protected class. Original source-
known vectors, all969 original tail joint/weight slots and bits, and all four
whole-hoof patches retain the existing independent checks. A deliberate lower-row
corruption must be detected in addition to the original controls.

Actual NPZ/receipt/closed-terminal/walk-report hashes are bound under V16 names;
old V14 lineage and V12 masks are distinct inputs. `ROOT-RELEASE-BOUND-HELD.json`
remains `released:false`. No numerical execution is authorized until fresh root
review/release and a free heavy lane. A later release permits exactly one30-second,
512-MiB stationary65 unit, zero fields/solvers/exports and no retry. Walking need
not pass for this separate standing domain, but no standing result can relabel a
walk failure or enable walking, photography, hitching or live actors.
