"""UNEXECUTED reconstructed standing posture; no runtime clock or asset edits.

This is a future CPU clip-authoring input, never a renderer curve. The carrier's
existing rigid standing support transform stays outside this canonical +Y-up
frame. Hoof world transforms equal their exact neutral transforms at all times;
we do not flatten the donor hooves or borrow the walk's 30-mm starting drop.

Requires an independently accepted 26-joint skin. Its current V14 candidate has
not run/passed. An exact rest/ground/65-pose surface/normal/contact/loop proof and
ordinary glTF export/import proof are required before any live use. No execution
or export is authorized by this module's existence.
"""
import math
import numpy as np

PARAMETERS = {
    'period_s': 12.0,
    'lateral_amplitude_m': 0.004,
    'longitudinal_amplitude_m': 0.002,
    'body_compression_m': 0.004,
    'provenance': 'Artist-reconstructed small postural sway, not measured horse motion, force or period evidence.',
    'contact': 'All four original neutral hoof transforms fixed; no hoof lifted, slid or yawed.',
}


def _unit(v):
    length = float(np.linalg.norm(v))
    if not math.isfinite(length) or length <= 1e-12:
        raise ValueError('Degenerate standing-chain direction; no fallback')
    return v / length


def _arc(a, b):
    a, b = _unit(a), _unit(b)
    cosine = float(a @ b)
    if cosine <= -0.999999:
        raise ValueError('Antiparallel standing link; no arbitrary twist')
    x, y, z = np.cross(a, b)
    skew = np.array([[0., -z, y], [z, 0., -x], [-y, x, 0.]])
    return np.eye(3) + skew + skew @ skew / (1. + cosine)


def body_offset(t):
    """One fixed C2 periodic profile, exact neutral at cycle boundaries.

    sin^3 and |sin^3| have zero first/second derivative at each neutral crossing.
    Compression accompanies either lean direction, rather than a constant lower
    stance at clip start. These are declared modelling choices, not a parameter
    search or measured center-of-mass trajectory.
    """
    if not math.isfinite(t) or t < 0:
        raise ValueError('Finite nonnegative authoring time required')
    phase = (t % PARAMETERS['period_s']) / PARAMETERS['period_s']
    wave = math.sin(2. * math.pi * phase) ** 3 if phase else 0.
    return np.array([
        PARAMETERS['lateral_amplitude_m'] * wave,
        -PARAMETERS['body_compression_m'] * abs(wave),
        PARAMETERS['longitudinal_amplitude_m'] * wave,
    ])


def pose(t, pivots, limbs):
    """Return global canonical joint matrices and explicit fixed-contact states.

    The uppermost and pastern links keep their neutral orientation. Moving the
    whole body changes the b-to-d vector; the exact two-sphere intersection closes
    b-c-d with each original link length. Unlike the old all-distal-rigid walk,
    carpus/hock c participates. This restricted small posture is not a walk or an
    anatomical joint-range certification; unreachable geometry fails immediately.
    """
    if pivots.shape != (26, 3) or not np.isfinite(pivots).all():
        raise ValueError('Exact reviewed 26-joint canonical rest pivots required')
    if set(limbs) != {'fore_l', 'fore_r', 'hind_l', 'hind_r'}:
        raise ValueError('Exactly four named source limbs required')
    displacement = body_offset(t)
    if not np.any(displacement):
        # Preserve exact neutral data, including signed-zero pivot components.
        # An IK square-root/arc roundtrip would be neutral only to roundoff.
        # This branch applies only to the explicitly requested rest posture;
        # every nonzero candidate still faces strict reach/degeneracy guards.
        neutral = np.repeat(np.eye(4)[None], len(pivots), axis=0)
        neutral[:, :3, 3] = pivots
        states = {}
        for label, row in limbs.items():
            _, b, c, d, e = row['joints']
            states[label] = {
                'stance': True,
                'neutral_hoof_transform_preserved': True,
                'target_local_m': pivots[e].tolist(),
                'reach_margin_m': float(np.linalg.norm(pivots[c] - pivots[b])
                                        + np.linalg.norm(pivots[d] - pivots[c])
                                        - np.linalg.norm(pivots[d] - pivots[b])),
                'exact_neutral_branch': True,
                'force_load_transfer': 'UNPROVEN',
            }
        return neutral, states
    xyz = pivots.copy()
    xyz[1:] += displacement
    rotations = np.repeat(np.eye(3)[None], len(pivots), axis=0)
    states = {}
    for label, row in limbs.items():
        a, b, c, d, e = row['joints']
        elbow = xyz[a] + (pivots[b] - pivots[a])
        # Exact original e transform: fixed pivot and identity world rotation.
        target = pivots[e].copy()
        fetlock = target - (pivots[e] - pivots[d])
        first, second = pivots[c] - pivots[b], pivots[d] - pivots[c]
        l1, l2 = float(np.linalg.norm(first)), float(np.linalg.norm(second))
        line = fetlock - elbow
        distance = float(np.linalg.norm(line))
        if not abs(l1 - l2) < distance < l1 + l2:
            raise ValueError(f'Unreachable planted standing chain {label}; no amplitude reduction, clamp or retry')
        direction = _unit(line)
        pole = _unit(first - direction * (first @ direction))
        along = (l1 * l1 - l2 * l2 + distance * distance) / (2. * distance)
        radius_squared = l1 * l1 - along * along
        if radius_squared <= 0.:
            raise ValueError(f'Degenerate standing intersection {label}; no square-root clipping')
        carpus = elbow + along * direction + math.sqrt(radius_squared) * pole
        xyz[b], xyz[c], xyz[d], xyz[e] = elbow, carpus, fetlock, target
        rotations[b] = _arc(first, carpus - elbow)
        rotations[c] = _arc(second, fetlock - carpus)
        states[label] = {
            'stance': True,
            'neutral_hoof_transform_preserved': True,
            'target_local_m': target.tolist(),
            'reach_margin_m': l1 + l2 - distance,
            'force_load_transfer': 'UNPROVEN',
        }
    matrices = np.repeat(np.eye(4)[None], len(pivots), axis=0)
    matrices[:, :3, :3] = rotations
    matrices[:, :3, 3] = xyz
    return matrices, states
