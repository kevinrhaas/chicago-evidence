// Finite, once-only focused unit. Root must release the exact prepared packet.
// No source writes, request rewriting, candidate injection or geometry settings.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto');
const {execFileSync}=require('node:child_process');
const {chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
const HERE=__dirname,planBytes=fs.readFileSync(path.join(HERE,'PREPARED.json')),plan=JSON.parse(planBytes);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),unitName=process.argv[2];
if(!['1835-desktop','1835-mobile','1904-desktop','1904-mobile'].includes(unitName))throw Error('One explicit era/profile unit required');
const release=JSON.parse(fs.readFileSync(path.join(HERE,'ACTUAL-ROOT-GRAPHICS-RELEASE.json')));
if(release.prepared_manifest_sha256!==hash(planBytes)||!release.allow_units?.includes(unitName)||release.released!==true)throw Error('Exact root release absent');
const unit=plan.units.find(p=>p.name===unitName),profile=unit.profile,ROOT=plan.root,OUT=path.join(HERE,'ACTUAL-'+unitName);
fs.mkdirSync(OUT,{recursive:false});
const git=(...args)=>execFileSync('git',args,{cwd:ROOT,encoding:'utf8'}).trim();
const checkPins=()=>{if(git('rev-parse','HEAD')!==plan.expectedHead||git('rev-parse','HEAD^{tree}')!==plan.expectedHeadTree||git('rev-parse','HEAD^{tree}')!==plan.expectedTree||git('diff','--name-only')||git('status','--porcelain')!==plan.expectedStatus)throw Error('Exact frozen feature HEAD/index/worktree required');if(plan.snapshotMode!=='clean-committed-pushed-only'||plan.expectedStatus!=='')throw Error('Only actual clean committed pushed snapshot');for(const[p,pin]of Object.entries(plan.sourceAndPublishedPins))if(hash(fs.readFileSync(path.join(ROOT,p)))!==pin.sha256)throw Error('Source/published pin drift '+p);for(const[p,pin]of Object.entries(plan.fixturePins))if(hash(fs.readFileSync(path.join(HERE,p)))!==pin.sha256)throw Error('Prepared fixture drift '+p)};
const result={state:'RUNNING',pass:false,ownerPID:process.pid,profile,unit:unitName,started:new Date().toISOString(),head:plan.expectedHead,tree:plan.expectedTree,snapshotMode:plan.snapshotMode,scope:plan.scope,unitDeadline_ms:270000,views:[],pageErrors:[],requestsFailed:[],optionalDirectoryAborts:[],mandatoryRequestFailures:[],directoryAvailability:'UNPROVEN',progress:[],badResponses:[],consoleErrors:[]};
const save=()=>fs.writeFileSync(path.join(OUT,'RESULT.json'),JSON.stringify(result,null,2)+'\n');save();
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.css':'text/css','.wasm':'application/wasm','.bin':'application/octet-stream','.ktx2':'image/ktx2'};
const server=http.createServer((req,res)=>{try{if(req.url==='/favicon.ico'){res.statusCode=204;return res.end()}let p=path.resolve(ROOT,'.'+decodeURIComponent(new URL(req.url,'http://local').pathname));if(!p.startsWith(ROOT+'/'))throw Error('Outside root');if(fs.statSync(p).isDirectory())p=path.join(p,'index.html');res.setHeader('Content-Type',mime[path.extname(p)]??'application/octet-stream');if(req.method==='HEAD')return res.end();fs.createReadStream(p).pipe(res)}catch{res.statusCode=404;res.end('not found')}});
let browser,context,page,captureSession;
// Preserve Playwright's native Chromium capture surface. Its utility-world
// preparation stalled before native capture in V5; no page/style/clock changes.
const capturePNG=async(file,timeoutMS)=>{
 let timer;
 try{
  const native=(async()=>{captureSession??=await context.newCDPSession(page);return captureSession.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false});})();
  const reply=await Promise.race([native,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Native PNG capture exceeded '+timeoutMS+'ms')),timeoutMS);})]);
  const bytes=Buffer.from(reply.data,'base64');fs.writeFileSync(file,bytes);
  if(bytes.length<33||bytes.subarray(0,8).toString('hex')!=='89504e470d0a1a0a'||bytes.toString('ascii',12,16)!=='IHDR')throw Error('Native capture did not return a PNG');
  const width=bytes.readUInt32BE(16),height=bytes.readUInt32BE(20);
  if(width!==profile.width*profile.dpr||height!==profile.height*profile.dpr)throw Error('Native capture dimensions differ from unchanged viewport/DPR: '+width+'x'+height);
  return{method:'Page.captureScreenshot',fromSurface:true,captureBeyondViewport:false,width,height,bytes:bytes.length,sha256:hash(bytes)};
 }finally{clearTimeout(timer);}
};
const observationStartedMS=Date.now();let currentPhase='boot';
const progress=(edge,stage,extra={})=>{const entry={edge,stage,atUTC:new Date().toISOString(),elapsedMS:Date.now()-observationStartedMS,currentPhase,...extra};result.progress.push(entry);save();console.log(JSON.stringify({progress:entry}));};
const measured=async(stage,work)=>{progress('begin',stage);try{const value=await work();progress('end',stage);return value}catch(error){progress('error',stage,{error:String(error)});throw error}};
const optionalDirectoryAbort=event=>{const p=plan.optionalPeopleDirectoryProof;return unit.year==='1904'&&p?.year==='1904'&&p.residentsAbsent===true&&!p.layers.includes('residents')&&p.sourceSceneSha256===plan.sourceAndPublishedPins[p.sourceScene]?.sha256&&p.publishedSceneSha256===plan.sourceAndPublishedPins[p.publishedScene]?.sha256&&p.mainSourceSha256===plan.sourceAndPublishedPins[p.mainSource]?.sha256&&event.url===result.origin+p.expectedPathname&&event.method==='HEAD'&&event.failure?.errorText==='net::ERR_ABORTED'&&event.currentPhase==='boot';};
const deadline=setTimeout(()=>{currentPhase='cleanup';result.deadlineReached=true;result.pass=false;result.error='Focused graphics unit reached its declared270s deadline; partial evidence is retained';save();if(page)void page.close().catch(()=>{});if(browser)void browser.close().catch(()=>{})},270000);
(async()=>{
 checkPins();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 result.origin='http://127.0.0.1:'+server.address().port;
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});result.browserPID=browser.process?.()?.pid??null;
 context=await browser.newContext({viewport:{width:profile.width,height:profile.height},hasTouch:profile.touch,deviceScaleFactor:profile.dpr});page=await context.newPage();
 page.on('pageerror',e=>result.pageErrors.push(e.message));page.on('requestfailed',r=>{const atMS=Date.now();const event={url:r.url(),method:r.method(),failure:r.failure(),atUTC:new Date(atMS).toISOString(),elapsedMS:atMS-observationStartedMS,currentPhase};result.requestsFailed.push(event);(optionalDirectoryAbort(event)?result.optionalDirectoryAborts:result.mandatoryRequestFailures).push(event);save();});page.on('response',r=>{if(r.status()>=400)result.badResponses.push({url:r.url(),method:r.request().method(),status:r.status()})});page.on('console',m=>{if(m.type()==='error')result.consoleErrors.push(m.text());else if(m.type()==='log'&&m.text().startsWith('VEHICLE_REVIEW_PROGRESS ')){try{progress('browser','reader',JSON.parse(m.text().slice('VEHICLE_REVIEW_PROGRESS '.length)))}catch(error){result.consoleErrors.push('Malformed reader progress '+error.message)}}});
 await page.addInitScript(detail=>localStorage.setItem('chicago4d.settings',JSON.stringify({detail})),profile.detail);
 result.url=result.origin+plan.publishedPrefix+unit.query;await page.goto(result.url,{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:240000,polling:500});
 await page.evaluate(async()=>{const a=window.__chicago4d;if(!a.ready)throw Error('Actual boot failure '+a.error);const end=performance.now()+90000;while(a.welcome?.state!=='world'&&performance.now()<end){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100))}if(a.welcome?.state!=='world')throw Error('Welcome did not enter world');document.getElementById('control-help-gotit')?.click();document.exitPointerLock?.()});
 await page.evaluate(({plan,unit})=>{window.VehicleReviewPlan=plan;window.VehicleReviewUnit=unit},{plan,unit});
 for(const file of ['read_normal_vehicles.js'])await page.addScriptTag({path:path.join(HERE,file)});
 for(const camera of unit.cameras){
  currentPhase='view:'+camera.name;
  const state=await measured('normal-frame-sampling:'+camera.name,()=>page.evaluate(camera=>{const a=window.__chicago4d;if(camera.pose)a.walker.teleport(camera.pose);a.step();a.step();if(String(a.year)==='1904')a.streetTrees.settle();const frames=[];for(let k=0;k<3;k++){a.step();a.renderer.getContext().finish();frames.push(a.stats())}return{pose:structuredClone(a.walker.state),detail:a.detail,bootDetail:a.bootDetail,device:a.device.choice,frames,stats:a.stats(),problems:[...a.problems],glError:a.renderer.getContext().getError(),build:document.getElementById('gate-build')?.textContent}},camera));
  const view={name:camera.name,camera,state,world:null,screenshot:null};result.views.push(view);save();
  if(state.detail!==profile.detail)throw Error('Requested profile silently changed');
  view.capture=await measured('normal-png:'+camera.name,()=>capturePNG(path.join(OUT,camera.name+'.png'),60000));view.screenshot=camera.name+'.png';view.screenshotQualification='RAW_UNQUALIFIED_PENDING_WORLD_CHECKS';save();
  view.world=await measured('world-reader:'+camera.name,()=>page.evaluate(camera=>window.readNormalVehicleWorld(camera),camera));save();
  view.pass=view.world.accepted===true&&state.frames.every(s=>s.withinBudget===true&&s.budget.drawCalls===profile.drawCalls&&s.budget.triangles===profile.triangles)&&(unit.year==='1835'||state.problems.length===0)&&state.glError===0;view.screenshotQualification=view.pass?'NORMAL_WORLD_ASSERTIONS_PASSED_REQUIRES_IMAGE_REVIEW':'RAW_UNQUALIFIED_ASSERTION_FAILURE';save();if(!view.pass)throw Error('Normal vehicle/frame assertion failed');
  // Capture ordinary normal frame before public card and restored layer controls.
  if(camera.name!=='scene-spawn'){
   view.card=await measured('own-card:'+camera.name,()=>page.evaluate(id=>window.reviewNormalVehicleCard(id),view.world.cardTarget));save();
   try{view.cardCapture=await capturePNG(path.join(OUT,camera.name+'-own-card.png'),60000);view.cardScreenshot=camera.name+'-own-card.png';}
   finally{await page.evaluate(()=>{const a=window.__chicago4d;a.popup.close();if(a.popup.openId!==null||!document.getElementById('popup').hidden)throw Error('Actual card closes');});}
   view.controls=await measured('controls:'+camera.name,()=>page.evaluate(id=>window.reviewNormalVehicleControls(id),view.world.cardTarget));save();
  }
 }
 currentPhase='cleanup';result.cleanup=await measured('layer-disposal',()=>page.evaluate(()=>window.disposeNormalVehicleReview()));save();
 result.pass=result.views.length===unit.cameras.length&&result.views.every(v=>v.pass)&&!result.pageErrors.length&&!result.mandatoryRequestFailures.length&&!result.badResponses.length&&!result.consoleErrors.length;
} )().catch(async error=>{result.error=String(error.stack??error);if(page)await capturePNG(path.join(OUT,'FAILED.png'),15000).catch(e=>{result.failureScreenshotError=e.message});result.pass=false}).finally(async()=>{
 currentPhase='cleanup';clearTimeout(deadline);if(context)await context.close().catch(e=>{result.closeError=e.message;result.pass=false});if(browser)await browser.close().catch(e=>{result.closeError=e.message;result.pass=false});if(server.listening){server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}
 try{checkPins();result.inputsUnchanged=true}catch(e){result.inputsUnchanged=false;result.pinError=e.message;result.pass=false}
 result.ended=new Date().toISOString();result.browserClosed=!browser||!browser.isConnected();result.serverClosed=!server.listening;if(!result.browserClosed||!result.serverClosed||result.deadlineReached)result.pass=false;result.state=result.pass?'CLOSED_FOCUSED_PASS':'CLOSED_FOCUSED_FAILURE';save();console.log(JSON.stringify({state:result.state,pass:result.pass,profile:unitName,views:result.views.length,error:result.error,out:OUT,browserClosed:result.browserClosed,serverClosed:result.serverClosed}));process.exitCode=result.pass?0:1;
});
