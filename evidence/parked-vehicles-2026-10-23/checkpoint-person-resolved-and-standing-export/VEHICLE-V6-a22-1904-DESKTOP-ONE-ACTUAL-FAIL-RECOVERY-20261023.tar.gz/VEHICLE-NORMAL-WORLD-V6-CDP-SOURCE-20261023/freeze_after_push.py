"""HELD source: bind only an actually clean committed/pushed/published snapshot.
No publish, Git mutation, browser, culler selection, dispatch or automatic follow-up.
Root must supply ROOT-POSTPUSH-FREEZE-RELEASE.json after actual source-owner terminal.
"""
from pathlib import Path
import copy,datetime,hashlib,json,re,subprocess
D=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def need(ok,msg):
 if not ok:raise ValueError(msg)
def main():
 need(not(D/'PREPARED.json').exists(),'Fresh once-only frozen packet required')
 release=json.loads((D/'ROOT-POSTPUSH-FREEZE-RELEASE.json').read_text());need(release['released']is True,'Explicit root freeze release')
 need(release['reviewed_source_manifest_sha256']==digest(D/'SOURCE-MANIFEST.json'),'Root reviewed exact caller sources')
 sources=json.loads((D/'SOURCE-MANIFEST.json').read_text())
 for name,pin in sources['files'].items():need(digest(D/name)==pin['sha256'],'Caller source changed '+name)
 p=json.loads((D/'RECIPE-UNBOUND.json').read_text());need(all(p[k]is None for k in ['expectedHead','expectedHeadTree','expectedTree','publishedBuild','sourceAndPublishedPins','fixturePins']),'Unbound source recipe only');W=Path(p['root'])
 def git(*args):return subprocess.check_output(['git','-C',str(W),*args],stderr=subprocess.PIPE).decode().strip()
 need(git('status','--porcelain')=='','Actual clean committed worktree required');head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
 need(head==release['expectedHead']==release['remoteBranchVerifiedHead']and tree==release['expectedTree'],'Root exact actual pushed HEAD/tree required')
 receipt=Path(release['sourceOwnerTerminalFile']);need(digest(receipt)==release['sourceOwnerTerminalSha256'],'Actual canonical owner terminal receipt hash')
 p.update(expectedHead=head,expectedHeadTree=tree,expectedTree=tree,expectedStatus='',sourceOwnerTerminal={'file':str(receipt),'sha256':digest(receipt)},snapshotMode='clean-committed-pushed-only')
 c=release['fullCullerDecision'];need(isinstance(c.get('enabled'),bool),'Final production Full-culler decision must be explicit')
 if c['enabled']:
  need(c.get('actualPixelParityPassed')is True and digest(Path(c['parityReceiptFile']))==c['parityReceiptSha256'],'Actual reviewed Full-culler pixel parity receipt required')
 p['fullCullerDecision']=c
 build=json.loads((W/'site/4d/build.json').read_text());need(build['version']==head[:9],'Actual final published build');need('build '+head[:9]in(W/'site/4d/walk/index.html').read_text(),'Normal entry HEAD stamp');p['publishedBuild']=build
 pairs=[('chicago/4d/renderers/web/js/changelog.js','site/4d/js/changelog.js')]
 for name in ['main.js','parked-transport.js','yard.js','buildings.js','confidence.js','street-grid.js','terrain.js','tree-model.js','tree-instances.js','tree-surface.js','street-trees.js','render-budget.js','upload-release.js','popup.js','shadow-casters.js','world.js','driver-draws.js','walker.js','spatial-batch.js','batch-coalesce.js']:
  pairs.append(('chicago/4d/renderers/web/js/'+name,'site/4d/walk/js/'+name))
 for name in ['three.core.js','three.module.js']:
  pairs.append(('chicago/4d/renderers/web/vendor/three-0.185.1/'+name,'site/4d/walk/vendor/three-0.185.1/'+name))
 for name in ['transport/parked/placements.json','transport/parked/covered-w01.json','transport/parked/wagon-w01.json','yard/town_trade_goods.json','scenes/1835.json','scenes/1904.json','street_trees/1904.json','street_grid/1904.json','street_surfaces/1904.json','street_section/1904.json','terrain/epochs/e1871_postfire/heightfield.json','terrain/epochs/e1871_postfire/heightfield.bin','terrain/epochs/e1834_harbor_cut/heightfield.json','terrain/epochs/e1834_harbor_cut/heightfield.bin','enclosures/western_hotel_wagon_yard.json','enclosures/wolf_point_tavern_yard.json','liberties.json','sidecars/1835/sources/index.json']:
  pairs.append(('chicago/4d/data/'+name,'site/4d/data/'+name))
 assets=['parked-brougham/'+n for n in ['brougham-near.glb','brougham-source.glb','brougham-mid.glb','brougham-mid-source.glb','brougham.json','MID-BUILD-RECEIPT.json']]
 assets+=['parked-wagon-fine-wood/wagon-w01.glb','parked-wagon-fine-wood/ATTRIBUTION.txt','parked-wagon/wagon-w01.glb','parked-carriage/carriage-c02.glb','parked-carriage/shaft-rest.glb','LICENSES.md']
 for model in ['covered_w01_western_blue','covered_w01_wolfpoint_oak']:
  assets+=['covered-wagon/'+model+'/'+n for n in ['covered-w01.glb','covered-w01.json']]
 for name in assets:pairs.append(('chicago/4d/renderers/web/transport/'+name,'site/4d/walk/transport/'+name))
 pins={}
 def bind(name):
  f=W/name;pins[name]={'bytes':f.stat().st_size,'sha256':digest(f)}
 for source,published in pairs:
  need(digest(W/source)==digest(W/published),'Exact normal source/published pair '+published)
  bind(source);bind(published)
 for name in ['site/4d/build.json','site/4d/walk/index.html','chicago/4d/tools/changelog_shim.mjs','chicago/4d/tools/stamp-changelog.mjs','chicago/4d/tools/pack_boot_sidecars.mjs','chicago/4d/tools/check_published.mjs','chicago/4d/renderers/web/vendor/three-0.185.1/three.core.js','chicago/4d/docs/RESEARCH/glessner-v4-recovery/manifest.json','chicago/4d/assets/authored/transport/wagon_covered/SOURCE.json','chicago/4d/assets/authored/transport/wagon_parked_fine_wood/SOURCE.json','chicago/4d/tools/transport/brougham/near-contract.json','chicago/4d/tools/transport/brougham/mid-contract.json']:bind(name)
 # Supported normal publisher transforms: bind raw bytes, then the exact
 # declared projection. Never compare authored changelog with its walk shim,
 # or authored sidecar indexes byte-for-byte with their packed boot indexes.
 publisher_projections={}
 def same_json(a,b):
  if isinstance(a,dict):return isinstance(b,dict)and set(a)==set(b)and all(same_json(a[k],b[k])for k in a)
  if isinstance(a,list):return isinstance(b,list)and len(a)==len(b)and all(same_json(x,y)for x,y in zip(a,b))
  if type(a)is bool or type(b)is bool:return type(a)is type(b)and a==b
  if type(a)in(int,float)and type(b)in(int,float):return a==b
  return type(a)is type(b)and a==b
 shim_source=(W/'chicago/4d/tools/changelog_shim.mjs').read_text()
 match=re.search(r"export const WALK_SHIM = `([\s\S]*?)`;",shim_source)
 need(match is not None,'Pinned normal WALK_SHIM literal declaration')
 literal=match.group(1)
 need('\\'not in literal and '${'not in literal,'WALK_SHIM now needs reviewed JS escape/interpolation semantics')
 shim=literal.encode('utf-8');shim_path='site/4d/walk/js/changelog.js'
 need((W/shim_path).read_bytes()==shim,'Normal published WALK_SHIM exact bytes');bind(shim_path)
 publisher_projections['changelog']={'source':'chicago/4d/renderers/web/js/changelog.js','fleet':'site/4d/js/changelog.js','walk_shim':shim_path,'shim_contract':'chicago/4d/tools/changelog_shim.mjs','WALK_SHIM_sha256':sha(shim),'fleet_exact_source':True,'walk_exact_normal_literal':True}
 for era in ['1835','1904']:
  source_name='chicago/4d/data/sidecars/'+era+'/index.json';published_name='site/4d/data/sidecars/'+era+'/index.json'
  source_index=json.loads((W/source_name).read_text());published_index=json.loads((W/published_name).read_text());projected=copy.deepcopy(published_index)
  need('boot'not in source_index and 'boot'in projected,'Normal source/index boot ownership')
  boot=projected.pop('boot');expected_boot={'shared':'sidecars/'+era+'/boot/shared.json','dir':'sidecars/'+era+'/boot/','per_part':50}
  need(same_json(boot,expected_boot)and same_json(projected,source_index),'Published index must equal source plus ONLY exact supported boot descriptor')
  bind(source_name);bind(published_name)
  shared_name='site/4d/data/'+boot['shared'];shared=json.loads((W/shared_name).read_text());need(set(shared)=={'values'}and isinstance(shared['values'],list),'Normal boot shared table');bind(shared_name)
  def check_shared_refs(value):
   if isinstance(value,dict):
    if set(value)=={'$shared'}:
     ref=value['$shared'];need(type(ref)is int and 0<=ref<len(shared['values']),'Boot shared reference range')
    else:
     for child in value.values():check_shared_refs(child)
   elif isinstance(value,list):
    for child in value:check_shared_refs(child)
  rows=[]
  for row in source_index.get('structures',[]):
   row={'id':row}if isinstance(row,str)else row
   if isinstance(row,dict)and isinstance(row.get('id'),str):rows.append(row)
  part_rows={};record_refs=[];missing_records=[]
  for at,row in enumerate(rows):
   record_name='site/4d/data/'+row.get('sidecar','sidecars/'+era+'/'+row['id']+'.json')
   if not(W/record_name).is_file():missing_records.append(record_name);continue
   bind(record_name)
   part_name='site/4d/data/'+boot['dir']+'part-'+str(at//50)+'.json'
   part_rows.setdefault(part_name,[]).append(row['id']);record_refs.append({'id':row['id'],'record':record_name,'part':part_name,'index_position':at})
  for part_name,ids in part_rows.items():
   part=json.loads((W/part_name).read_text());need(isinstance(part,dict)and set(part)==set(ids),'Boot part identities exactly match supported index grouping');check_shared_refs(part);bind(part_name)
  expected_names={'shared.json'}|{Path(name).name for name in part_rows};boot_directory=W/('site/4d/data/'+boot['dir'])
  need({f.name for f in boot_directory.iterdir()}==expected_names,'No unreferenced normal boot pack files')
  publisher_projections['sidecars_'+era]={'source_index':source_name,'published_index':published_name,'projection':'published JSON with ONLY boot removed equals complete source JSON','exact_boot':boot,'shared':shared_name,'part_files':list(part_rows),'record_refs':record_refs,'missing_published_records':missing_records,'scope':'Immutable raw index/shared/part hashes and supported descriptor/group/shared-reference binding. Normal pack_boot_sidecars --check owns full record rehydration; this freeze does not import/run it or claim a new checker pass.'}
 p['normalPublisherProjections']=publisher_projections
 # Read CURRENT manifest; never inherit old8249/Glessner output hashes.
 glessner=json.loads((W/'chicago/4d/docs/RESEARCH/glessner-v4-recovery/manifest.json').read_text())
 for name,expected in glessner['files'].items():
  f=W/'chicago/4d'/name;need(f.stat().st_size==expected['bytes']and digest(f)==expected['sha256'],'Current exact Glessner output '+name);bind('chicago/4d/'+name)
 for relative,key in [('parked-brougham/brougham-near.glb','nearSha256'),('parked-brougham/brougham-source.glb','rawSha256'),('parked-brougham/brougham-mid.glb','midSha256'),('parked-brougham/brougham-mid-source.glb','midRawSha256'),('parked-wagon-fine-wood/wagon-w01.glb','fineWoodSha256')]:need(digest(W/'chicago/4d/renderers/web/transport'/relative)==p[key],'Reviewed exact asset '+relative)
 for model,pin in p['coveredHashes'].items():need(digest(W/'chicago/4d/renderers/web/transport/covered-wagon'/model/'covered-w01.glb')==pin,'Exact distinct drape variant '+model)
 metadata=json.loads((W/'chicago/4d/renderers/web/transport/parked-brougham/brougham.json').read_text())
 for key,value in p['protectedNearInterfaces'].items():need(metadata[key]==value,'Protected original conservative NEAR '+key)
 p['metadataSha256']=digest(W/'chicago/4d/renderers/web/transport/parked-brougham/brougham.json')
 for name,pin in p['protectedLegacyAssets'].items():need(digest(W/name)==pin,'Unchanged protected legacy asset '+name)
 rows=json.loads((W/'chicago/4d/data/transport/parked/placements.json').read_text())['scenes'];need(len(rows['1835'])==5 and len(rows['1904'])==1 and rows['1904'][0]['id']=='prairie_parked_studebaker_brougham','Five distinct1835/one1904/noobsoleteC02')
 for era in ['1835','1904']:
  for row in rows[era]:
   old=next((r for r in p['expectedSceneRows'][era]if r['id']==row['id']),None);need(old is not None,'Original identity')
   for key in ['id','model','at_local_enu_m','bearing_deg','replaces','belongs_to','liberty','source_ids']:need(row.get(key)==old.get(key),'Protected row '+key)
 # V5 binds only resources actually needed by each unchanged unit. The reader
 # fetches all independent resources together, verifies actual bytes, and caches
 # immutable proofs only; every live per-view geometry/contact assertion remains.
 models=json.loads((W/'chicago/4d/data/transport/parked/placements.json').read_text())['models']
 resource_plan={}
 for era in ['1835','1904']:
  resources=[{'key':'manifest','pathname':'/site/4d/data/transport/parked/placements.json','pinKey':'site/4d/data/transport/parked/placements.json','kind':'json'}]
  if era=='1904':resources.append({'key':'metadata','pathname':'/site/4d/walk/transport/parked-brougham/brougham.json','pinKey':'site/4d/walk/transport/parked-brougham/brougham.json','kind':'json'})
  files=set()
  for row in rows[era]:
   model=models[row['model']];files.add(model['file'])
   if model.get('delivery_lods',{}).get('mid'):files.add(model['delivery_lods']['mid'])
  for file in sorted(files):resources.append({'key':file,'pathname':'/site/4d/walk/'+file,'pinKey':'site/4d/walk/'+file,'kind':'asset'})
  for resource in resources:need(resource['pinKey']in pins,'Every served resource has a final exact byte pin')
  resource_plan[era]=resources
 p['servedResourcePlan']=resource_plan
 source_scene='chicago/4d/data/scenes/1904.json';published_scene='site/4d/data/scenes/1904.json'
 scene=json.loads((W/source_scene).read_text())
 need(scene.get('id')=='1904'and isinstance(scene.get('layers'),list)and 'residents'not in scene['layers'],'Exact 1904 source lacks residents layer')
 main_source=(W/'chicago/4d/renderers/web/js/main.js').read_text()
 need("fetch(url, { method: 'HEAD', cache: 'no-cache' }).then((r) => { known = r.ok; }, () => { known = false; });"in main_source and 'known = r.ok' in main_source and 'known = false' in main_source,'Reviewed optional directory HEAD source shape')
 p['optionalPeopleDirectoryProof']={'year':'1904','sourceScene':source_scene,'publishedScene':published_scene,'sourceSceneSha256':pins[source_scene]['sha256'],'publishedSceneSha256':pins[published_scene]['sha256'],'layers':scene['layers'],'residentsAbsent':True,'mainSource':'chicago/4d/renderers/web/js/main.js','mainSourceSha256':pins['chicago/4d/renderers/web/js/main.js']['sha256'],'expectedPathname':'/site/4d/data/sidecars/1904/people.json','method':'HEAD','errorText':'net::ERR_ABORTED','phase':'boot','directoryAvailability':'UNPROVEN'}
 p['expectedSceneRows']=rows;p['sourceAndPublishedPairs']=pairs;p['sourceAndPublishedPins']=pins;p['fixturePins']={name:pin for name,pin in sources['files'].items()};p['state']='BOUND_AFTER_ACTUAL_PUSH_PUBLISH_HELD_FOR_PER_UNIT_ROOT_RELEASE';p['preparedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();(D/'PREPARED.json').write_text(json.dumps(p,indent=2)+'\n')
 print(json.dumps({'state':p['state'],'head':head,'tree':tree,'prepared_manifest_sha256':digest(D/'PREPARED.json'),'pairs':len(pairs),'execution':False}))
if __name__=='__main__':main()
