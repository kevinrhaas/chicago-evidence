"""HELD once-only owner wrapper; source-only preparation is not a graphics release."""
from pathlib import Path
import hashlib,importlib.util,json,sys
D=Path(__file__).parent
assert len(sys.argv)==3 and sys.argv[1]=='--root-released-unit','One explicitly released unit only'
unit=sys.argv[2];assert unit in ['1835-desktop','1835-mobile','1904-desktop','1904-mobile']
release=json.loads((D/'ACTUAL-ROOT-GRAPHICS-RELEASE.json').read_text());raw=(D/'PREPARED.json').read_bytes()
assert release['released']is True and unit in release['allow_units']and release['prepared_manifest_sha256']==hashlib.sha256(raw).hexdigest()
supervisor=Path('/workspace/shared/horse-sevket-native-preview-source-20261022/ownership_supervisor.py');assert hashlib.sha256(supervisor.read_bytes()).hexdigest()=='778e5623d81821a48aeae5080a8cbff4ef57901570ceea9935fa98ecd9bd0ce5'
spec=importlib.util.spec_from_file_location('owned',supervisor);owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
# Actual work has the old270s timer. These5/10s margins are ownership cleanup only.
result=owned.run_owned(['node',str(D/'run.cjs'),unit],D/('OWNED-'+unit),whole_timeout=280,execution_timeout=275)
print(json.dumps(result,indent=2));raise SystemExit(result.get('exit_code',1))
