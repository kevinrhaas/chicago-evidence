// Source-only proposed normal published reader. No model injection or level forcing.
window.readNormalVehicleWorld = async function(camera) {
 const a=window.__chicago4d,T=await import('three'),plan=window.VehicleReviewPlan,unit=window.VehicleReviewUnit;
 const need=(v,m)=>{if(!v)throw Error(m)},same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 need(a?.ready&&String(a.year)===unit.year,'Actual ready normal era');
 need(location.pathname===plan.publishedPrefix&&!new URL(location.href).searchParams.has('keep-geometry'),'Ordinary no-flag published entry');
 need(document.getElementById('gate-build')?.textContent.includes(plan.expectedHead.slice(0,9)),'Exact published build');
 need(a.detail===unit.profile.detail&&!a.confidence.ghosting,'Exact normal requested tier');
 const manifest=await(await fetch(new URL('transport/parked/placements.json',a.dataBase))).json(),rows=manifest.scenes[unit.year],instances=a.parkedTransport.instances;
 need(rows.length===unit.expectedRows&&instances.length===rows.length,'Actual expected scene cardinality');
 need(!rows.some(r=>r.id==='prairie_parked_carriage')&&!instances.some(i=>i.row.id==='prairie_parked_carriage'),'Obsolete C02 absent');
 for(const row of rows){const expected=plan.expectedSceneRows[unit.year].find(r=>r.id===row.id);need(expected,'Unexpected individual row');for(const k of ['id','model','at_local_enu_m','bearing_deg','replaces','belongs_to','liberty','source_ids'])need(same(row[k],expected[k]),'Protected individual '+k);}
 const result={scope:'Actual visible normal vehicles, source-bound contacts/interfaces, card and layer cleanup; not exhaustive SAT/collision or whole smoke',year:unit.year,profile:unit.profile,instances:[],problems:[...a.problems],accepted:false};
 const served=new Map(),verifyAsset=async file=>{if(served.has(file))return served.get(file);const pin=plan.sourceAndPublishedPins['site/4d/walk/'+file];need(pin,'Final source/published asset pin');const response=await fetch(new URL(file,document.baseURI),{cache:'no-cache'});need(response.ok,'Actual served vehicle asset');const bytes=await response.arrayBuffer(),digest=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(v=>v.toString(16).padStart(2,'0')).join('');need(bytes.byteLength===pin.bytes&&digest===pin.sha256,'Exact served vehicle model bytes');const proof={file,bytes:bytes.byteLength,sha256:digest};served.set(file,proof);return proof;};
 const triangles=root=>{let n=0,meshes=0;root.traverse(o=>{if(o.isMesh){need(o.visible,'Active material mesh hidden');n+=(o.geometry.index?.count??o.geometry.getAttribute('position').count)/3;meshes++;}});return{triangles:n,meshes};};
 for(const i of instances){
  const expected=rows.find(r=>r.id===i.row.id);need(same(expected,i.row),'Loaded row differs');i.group.updateMatrixWorld(true);
  need(i.group.position.x===i.row.at_local_enu_m[0]&&i.group.position.z===-i.row.at_local_enu_m[1]&&Math.abs(i.group.rotation.y-(Math.PI-i.row.bearing_deg*Math.PI/180))<1e-12,'Installed stand/pivot differs');
  need(i.wheel_clearance_m<=.03,'Original30mmwheel guard');
  const active=i.lod?i.lod.levels[i.lod.getCurrentLevel()].object:i.group,count=triangles(active),entry={id:i.row.id,model:i.row.model,visible:i.group.visible,position:i.group.position.toArray(),quaternion:i.group.quaternion.toArray(),active_lod:i.active_lod??null,active_geometry:count,wheel_plane_span_m:i.wheel_clearance_m,static_support:i.static_support};
  if(i.lod){
   const level=i.lod.getCurrentLevel(),selected=level===0?'near':'mid';need(selected===i.active_lod,'Actual selected LOD agrees with runtime');need(count.triangles===(selected==='near'?33502:11706)&&count.triangles===i.active_triangles&&count.meshes===7&&i.draw_batches===7,'Actual ACTIVE geometry count; hidden level excluded');
   const size=a.renderer.getDrawingBufferSize(new T.Vector2()),focal=size.y/(2*Math.tan(a.camera.fov*Math.PI/360)),threshold=Math.max(24,2.5+focal*(.65*(1-Math.cos(Math.PI/16)))/.5);
   need(i.lod.levels[1].distance===threshold&&i.lod.levels[1].hysteresis===.05&&i.lod.autoUpdate===false,'Existing24m/screenerror/5percent selector unchanged');
   entry.selector={drawing_buffer:size.toArray(),fov:a.camera.fov,zoom:a.camera.zoom,threshold_m:threshold,current_level:level,visible_levels:i.lod.levels.map(l=>l.object.visible)};
  }else need(count.triangles===(i.row.model==='wagon_w01'?12104:17292)&&i.draw_batches===(i.row.model==='wagon_w01'?8:9),'Actual W01/covered cost');
  const box=new T.Box3().setFromObject(active,true),corners=[];for(const x of[box.min.x,box.max.x])for(const y of[box.min.y,box.max.y])for(const z of[box.min.z,box.max.z])corners.push(new T.Vector3(x,y,z).project(a.camera));
  entry.projected_bounds={min:[0,1,2].map(k=>Math.min(...corners.map(v=>v.getComponent(k)))),max:[0,1,2].map(k=>Math.max(...corners.map(v=>v.getComponent(k))))};
  entry.in_frame=entry.projected_bounds.min.every((v,k)=>v<1&&entry.projected_bounds.max[k]>-1);
  if(unit.year==='1904'){
   const metadata=await(await fetch(new URL('transport/parked-brougham/brougham.json',document.baseURI))).json();
   for(const[k,v]of Object.entries(plan.protectedNearInterfaces))need(same(metadata[k],v),'Original NEAR conservative interface '+k);
   need(metadata.anchors.length===13,'Original13anchors');const spec=manifest.models[i.row.model],ground=(e,n)=>a.streetGrid.carriagewayHeight(e,n),yaw=Math.PI-i.row.bearing_deg*Math.PI/180,co=Math.cos(yaw),si=Math.sin(yaw),toEN=([x,y,z])=>[i.row.at_local_enu_m[0]+co*x+si*z,i.row.at_local_enu_m[1]+si*x-co*z,y];
   entry.conservative_near_interfaces={source_triangles:33502,scope:'Unchanged source NEARmaster13anchors/full conservative proxy and declared contact interfaces; distinct from actual selected LOD geometry. Not a new full-road/tree SAT pass.',anchors:metadata.anchors.map(x=>{const p=new T.Vector3(...x.translation_root_m).applyMatrix4(i.group.matrixWorld);return{name:x.node,world_enu:[p.x,-p.z,p.y]};}),proxy:metadata.static_master.collision_proxy};
   entry.wheels=spec.wheel_contacts_m.map(([x,z])=>{const[e,n]=toEN([x,0,z]),y=ground(e,n);return{e,n,ground:y,gap_m:Number.isFinite(y)?i.group.position.y-y:null};});
   entry.supports=spec.static_support_contacts_m.map(p=>{const[e,n,y]=toEN(p),g=ground(e,n);return{e,n,ground:g,gap_m:Number.isFinite(g)?i.group.position.y+y-g:null};});
   need(entry.wheels.length===4&&entry.wheels.every(x=>Number.isFinite(x.gap_m)&&x.gap_m>=-.001&&x.gap_m<=.03),'Original four-wheel1mm/30mmprovider limits');need(entry.supports.every(x=>Number.isFinite(x.gap_m)&&x.gap_m>=-.001&&x.gap_m<=.03),'Original shoe1mm/30mmprovider limits');
  }
  entry.servedAssets=[await verifyAsset(manifest.models[i.row.model].file)];if(i.lod)entry.servedAssets.push(await verifyAsset(manifest.models[i.row.model].delivery_lods.mid));
  result.instances.push(entry);
 }
 const target=unit.year==='1904'?instances[0]:instances.find(i=>i.row.id===camera.targetId);need(target?.group.visible,'Expected fixed-view target visible');
 if(unit.year==='1835'){
  const e=result.instances.find(i=>i.id===target.row.id),b=e.projected_bounds;need(Math.max(...[...b.min.slice(0,2),...b.max.slice(0,2)].map(Math.abs))<.95&&b.min[2]>-1&&b.max[2]<1,'Existing covered whole-reference framing');
  need(result.instances.some(i=>i.model==='wagon_w01'&&i.visible&&i.in_frame),'Current W01 timber in unchanged yard frame; no camera substitution');
  result.wood_scope='At least one W01 is in the unchanged yard frame; image review still determines visibility/detail/occlusion quality. Not every board/stand photographic acceptance.';
 }
 result.cardTarget=target.row.id;result.accepted=!a.problems.some(p=>/parked transport/i.test(p));
 if(unit.year==='1904')need(a.problems.length===0,'Existing1904no-problem assertion');
 return result;
};
window.reviewNormalVehicleCard = async function(id){
 const a=window.__chicago4d,T=await import('three'),p=a.parkedTransport,i=p.instances.find(i=>i.row.id===id),need=(v,m)=>{if(!v)throw Error(m)};need(i?.group.visible,'Actual visible card target');
 const active=i.lod?i.lod.levels[i.lod.getCurrentLevel()].object:i.group;let hit=null,ndc=null,attempts=0;
 // Same bounded actual-source vertex sampling/public nearest-hit arbitration as old covered reader.
 for(const mesh of active.children){if(!mesh.isMesh)continue;const attr=mesh.geometry.getAttribute('position');need(attr.array?.length,'Normal active pick arrays required');for(let k=0;k<attr.count;k+=Math.max(3,Math.floor(attr.count/24/3)*3)){const v=new T.Vector3().fromBufferAttribute(attr,k).applyMatrix4(mesh.matrixWorld).project(a.camera);if(Math.abs(v.x)>.85||Math.abs(v.y)>.85)continue;const local=p.pickAt({x:v.x,y:v.y},a.camera);if(local?.id!==id)continue;attempts++;const global=a.pick({x:v.x,y:v.y});if(global?.id===id){hit=global;ndc={x:v.x,y:v.y};break;}a.popup.close();}if(hit)break;}
 need(hit?.id===id&&a.popup.openId===id,'Public normal nearest-hit pick opens OWN vehicle card');
 const popup=document.getElementById('popup');try{need(!popup.hidden,'Actual popup visible');const tab=popup.querySelector('[data-pop-tab="evidence"]');need(tab,'Sources tab');tab.click();for(const b of popup.querySelectorAll('#pop-pane-evidence [data-toggle-note]'))b.click();const text=popup.innerText;need(/reconstructed/i.test(text)&&/Unoccupied and unhitched/.test(text),'Empty reconstructed identity');
 if(i.row.model==='studebaker_brougham_1893')need(/1893/.test(text)&&/Studebaker/.test(text)&&/not attested|not source-attested/.test(text)&&/reconstructed.*individual|individual.*reconstructed/is.test(text),'Attested catalogue DESIGN separated from reconstructed individual');
 else need(/Unidentified; type reconstruction/.test(text)&&/Covered wagon/.test(text),'Original covered identity');
 return{id,ndc,attempts,text,scope:'Actual public NDC pick through main nearest-hit arbitration; caller screenshots actual open card and closes before controls.'};}catch(error){a.popup.close();throw error;}
};
window.reviewNormalVehicleControls = async function(id){
 const a=window.__chicago4d,p=a.parkedTransport,i=p.instances.find(i=>i.row.id===id),need=(v,m)=>{if(!v)throw Error(m)},frame=()=>{a.step();a.step();a.renderer.getContext().finish();const s=a.stats();need(s.withinBudget&&a.renderer.getContext().getError()===0,'Unchanged budget/GL');return s;};
 const controlRoot=i.lod?i.lod.levels[i.lod.getCurrentLevel()].object:i.group,controlled=controlRoot.children;
 const before=frame(),visible=controlled.map(x=>x.visible);let hidden;
 try{controlled.forEach(x=>x.visible=false);hidden=frame();}finally{controlled.forEach((x,k)=>x.visible=visible[k]);}const restored=frame(),delta={driverDraws:restored.drawCalls-hidden.drawCalls,rendererCalls:restored.rendererCalls-hidden.rendererCalls,triangles:restored.triangles-hidden.triangles};need(delta.driverDraws>0,'Actual target driver draw contribution');
 const oldHidden=a.confidence.hidden.reconstructed;try{a.confidence.setHidden('reconstructed',true);need(p.pickAt({x:0,y:0},a.camera)===null,'Hidden reconstructed vehicle unpickable');}finally{a.confidence.setHidden('reconstructed',oldHidden);}const tier=a.detail;
 try{await p.setTier('light');frame();need(p.instances.every(x=>!x.group.visible),'Original Light reach0');}finally{await p.setTier(tier);frame();}need(i.group.visible,'Original tier restores fixed-view target');return{before,hidden,restored,delta,light_scope:'Parked layer contract only; not a full-app Light memory qualification.'};
};
window.disposeNormalVehicleReview = async function(){
 const p=window.__chicago4d.parkedTransport,geometry=new Set(),disposed=new Set();for(const i of p.instances)i.group.traverse(o=>{if(o.geometry)geometry.add(o.geometry);});for(const g of geometry)g.addEventListener('dispose',()=>disposed.add(g));p.dispose();await Promise.resolve();if(p.instances.length||disposed.size!==geometry.size)throw Error('Normal parked owned geometry/instances cleanup');return{owned_geometries:geometry.size,disposed_geometries:disposed.size,instances:p.instances.length,scope:'End-of-page destructive layer disposal; no browser-GPUallocation claim.'};
};
