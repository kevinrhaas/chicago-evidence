// GPL-3.0-or-later. Single-use diagnostic copy of the existing C02 triangle SAT.
// Surface intersection only. No solid containment or collision-physics claim.
(() => {
 const sub=(a,b)=>a.map((v,i)=>v-b[i]), dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
 const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
 function intersects(a,b,tol=1e-8){
  const ea=a.map((v,i)=>sub(a[(i+1)%3],v)),eb=b.map((v,i)=>sub(b[(i+1)%3],v));
  const na=cross(ea[0],ea[1]),nb=cross(eb[0],eb[1]);
  const axes=[na,nb,...ea.flatMap(x=>eb.map(y=>cross(x,y))),...ea.map(x=>cross(na,x)),...eb.map(x=>cross(nb,x))];
  for(const q of axes){const l=Math.hypot(...q);if(l<1e-14)continue;const n=q.map(v=>v/l),pa=a.map(v=>dot(v,n)),pb=b.map(v=>dot(v,n));if(Math.max(...pa)<Math.min(...pb)-tol||Math.max(...pb)<Math.min(...pa)-tol)return false}return true;
 }
 function controls(){
  const a=[[0,0,0],[1,0,0],[0,1,0]],cases=[[[[.1,.1,0],[.4,.1,0],[.1,.4,0]],true],[[[.8,.8,0],[1,.8,0],[.8,1,0]],false],[[[0,0,.001],[1,0,.001],[0,1,.001]],false],[[[.2,.2,-1],[.2,.2,1],[.4,.2,0]],true],[[[0,0,0],[1,0,0],[0,-1,0]],true]];
  for(const[b,want]of cases)if(intersects(a,b)!==want||intersects(b,a)!==want)throw Error('Existing SAT predicate control failed');return{pass:true,cases:cases.length,tolerance_m:1e-8};
 }
 globalThis.BroughamSurfaceSAT={intersects,controls};
})();
