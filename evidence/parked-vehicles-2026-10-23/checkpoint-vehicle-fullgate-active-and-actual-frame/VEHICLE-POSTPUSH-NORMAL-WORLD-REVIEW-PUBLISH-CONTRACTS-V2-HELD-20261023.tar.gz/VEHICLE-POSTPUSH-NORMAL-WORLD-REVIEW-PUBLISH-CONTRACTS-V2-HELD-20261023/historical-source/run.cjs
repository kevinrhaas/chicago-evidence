// Finite, once-only focused unit. Root must release the exact prepared packet.
// No source writes, request rewriting, candidate injection or geometry settings.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto');
const {execFileSync}=require('node:child_process');
const {chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
const HERE=__dirname,planBytes=fs.readFileSync(path.join(HERE,'PREPARED.json')),plan=JSON.parse(planBytes);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),viewport=process.argv[2];
if(!['desktop','mobile'].includes(viewport))throw Error('One explicit desktop or mobile unit is required');
const release=JSON.parse(fs.readFileSync(path.join(HERE,'ACTUAL-ROOT-GRAPHICS-RELEASE.json')));
if(release.prepared_manifest_sha256!==hash(planBytes)||!release.allow_viewports?.includes(viewport)||release.released!==true)throw Error('Exact root release absent');
const profile=plan.profiles.find(p=>p.name===viewport),ROOT=plan.root,OUT=path.join(HERE,'ACTUAL-'+viewport);
fs.mkdirSync(OUT,{recursive:false});
const git=(...args)=>execFileSync('git',args,{cwd:ROOT,encoding:'utf8'}).trim();
const checkPins=()=>{if(git('rev-parse','HEAD')!==plan.expectedHead||git('rev-parse','HEAD^{tree}')!==plan.expectedHeadTree||git('write-tree')!==plan.expectedTree||git('diff','--name-only')||git('status','--porcelain')!==plan.expectedStatus)throw Error('Exact frozen feature HEAD/index/worktree required');if(plan.snapshotMode==='staged-source-merge'&&(!release.allow_staged_source||git('rev-parse','MERGE_HEAD')!==plan.expectedMergeHead))throw Error('Explicit root release for the staged merge required');for(const[p,pin]of Object.entries(plan.sourceAndPublishedPins))if(hash(fs.readFileSync(path.join(ROOT,p)))!==pin.sha256)throw Error('Source/published pin drift '+p);for(const[p,pin]of Object.entries(plan.fixturePins))if(hash(fs.readFileSync(path.join(HERE,p)))!==pin.sha256)throw Error('Prepared fixture drift '+p)};
const result={state:'RUNNING',pass:false,ownerPID:process.pid,profile,started:new Date().toISOString(),head:plan.expectedHead,tree:plan.expectedTree,snapshotMode:plan.snapshotMode,scope:plan.scope,unitDeadline_ms:270000,views:[],pageErrors:[],requestsFailed:[],badResponses:[],consoleErrors:[]};
const save=()=>fs.writeFileSync(path.join(OUT,'RESULT.json'),JSON.stringify(result,null,2)+'\n');save();
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.css':'text/css','.wasm':'application/wasm','.bin':'application/octet-stream','.ktx2':'image/ktx2'};
const server=http.createServer((req,res)=>{try{if(req.url==='/favicon.ico'){res.statusCode=204;return res.end()}let p=path.resolve(ROOT,'.'+decodeURIComponent(new URL(req.url,'http://local').pathname));if(!p.startsWith(ROOT+'/'))throw Error('Outside root');if(fs.statSync(p).isDirectory())p=path.join(p,'index.html');res.setHeader('Content-Type',mime[path.extname(p)]??'application/octet-stream');if(req.method==='HEAD')return res.end();fs.createReadStream(p).pipe(res)}catch{res.statusCode=404;res.end('not found')}});
let browser,context,page;
const deadline=setTimeout(()=>{result.deadlineReached=true;result.pass=false;result.error='Focused graphics unit reached its declared270s deadline; partial evidence is retained';save();if(page)void page.close().catch(()=>{});if(browser)void browser.close().catch(()=>{})},270000);
(async()=>{
 checkPins();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 result.origin='http://127.0.0.1:'+server.address().port;
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});result.browserPID=browser.process?.()?.pid??null;
 context=await browser.newContext({viewport:{width:profile.width,height:profile.height},hasTouch:profile.touch,deviceScaleFactor:profile.dpr});page=await context.newPage();
 page.on('pageerror',e=>result.pageErrors.push(e.message));page.on('requestfailed',r=>result.requestsFailed.push({url:r.url(),method:r.method(),failure:r.failure()}));page.on('response',r=>{if(r.status()>=400)result.badResponses.push({url:r.url(),method:r.request().method(),status:r.status()})});page.on('console',m=>{if(m.type()==='error')result.consoleErrors.push(m.text())});
 await page.addInitScript(detail=>localStorage.setItem('chicago4d.settings',JSON.stringify({detail})),profile.detail);
 result.url=result.origin+plan.publishedPrefix+'?year=1904&keep-geometry=1';await page.goto(result.url,{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:240000,polling:500});
 await page.evaluate(async()=>{const a=window.__chicago4d;if(!a.ready)throw Error('Actual boot failure '+a.error);const end=performance.now()+90000;while(a.welcome?.state!=='world'&&performance.now()<end){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100))}if(a.welcome?.state!=='world')throw Error('Welcome did not enter world');document.getElementById('control-help-gotit')?.click();document.exitPointerLock?.()});
 await page.evaluate(plan=>{window.BroughamWorldPlan=plan},plan);
 for(const file of ['collision_kernel.js','read_base_installed_world.js','read_published_world.js'])await page.addScriptTag({path:path.join(HERE,file)});
 for(const camera of plan.cameras){
  const state=await page.evaluate(camera=>{const a=window.__chicago4d;if(camera.pose)a.walker.teleport(camera.pose);a.step();a.step();a.streetTrees.settle();const frames=[];for(let k=0;k<3;k++){a.step();a.renderer.getContext().finish();frames.push(a.stats())}return{pose:structuredClone(a.walker.state),detail:a.detail,bootDetail:a.bootDetail,device:a.device.choice,frames,stats:a.stats(),problems:[...a.problems],glError:a.renderer.getContext().getError(),build:document.getElementById('gate-build')?.textContent}},camera);
  const view={name:camera.name,camera,state,world:null,screenshot:null};result.views.push(view);save();
  if(state.detail!==profile.detail)throw Error('Requested profile silently changed');
  view.world=await page.evaluate(()=>window.readPublishedBroughamWorld());save();
  await page.screenshot({path:path.join(OUT,camera.name+'.png'),timeout:60000});view.screenshot=camera.name+'.png';
  view.pass=view.world.accepted===true&&state.frames.every(s=>s.withinBudget===true)&&state.problems.length===0&&state.glError===0;save();
 }
 result.pass=result.views.length===plan.cameras.length&&result.views.every(v=>v.pass)&&!result.pageErrors.length&&!result.requestsFailed.length&&!result.badResponses.length&&!result.consoleErrors.length;
} )().catch(async error=>{result.error=String(error.stack??error);if(page)await page.screenshot({path:path.join(OUT,'FAILED.png'),timeout:15000}).catch(e=>{result.failureScreenshotError=e.message});result.pass=false}).finally(async()=>{
 clearTimeout(deadline);if(context)await context.close().catch(e=>{result.closeError=e.message;result.pass=false});if(browser)await browser.close().catch(e=>{result.closeError=e.message;result.pass=false});if(server.listening){server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}
 try{checkPins();result.inputsUnchanged=true}catch(e){result.inputsUnchanged=false;result.pinError=e.message;result.pass=false}
 result.ended=new Date().toISOString();result.browserClosed=!browser||!browser.isConnected();result.serverClosed=!server.listening;if(!result.browserClosed||!result.serverClosed||result.deadlineReached)result.pass=false;result.state=result.pass?'CLOSED_FOCUSED_PASS':'CLOSED_FOCUSED_FAILURE';save();console.log(JSON.stringify({state:result.state,pass:result.pass,profile:viewport,views:result.views.length,error:result.error,out:OUT,browserClosed:result.browserClosed,serverClosed:result.serverClosed}));process.exitCode=result.pass?0:1;
});
