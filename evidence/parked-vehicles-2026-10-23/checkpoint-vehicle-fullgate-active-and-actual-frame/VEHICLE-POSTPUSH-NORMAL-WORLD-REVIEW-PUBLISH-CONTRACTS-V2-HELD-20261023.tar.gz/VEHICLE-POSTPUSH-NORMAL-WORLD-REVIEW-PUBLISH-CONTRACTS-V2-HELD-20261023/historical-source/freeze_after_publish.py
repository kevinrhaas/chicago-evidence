"""Pin the already-published exact source snapshot; does not publish or launch graphics."""
import hashlib
import json
import pathlib
import subprocess
import datetime

D = pathlib.Path(__file__).parent
plan = json.loads((D / 'CAMERA-PLAN.json').read_bytes())
W = pathlib.Path(plan['root'])
def git(*args):
    return subprocess.check_output(['git', '-C', str(W), *args], stderr=subprocess.PIPE).decode().strip()
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()
assert not git('diff', '--name-only'), 'Stage the real source/producer outputs before freezing'
assert not git('ls-files', '-u'), 'Unmerged index is not a published snapshot'
assert not (D / 'PREPARED.json').exists(), 'Once-only freeze: preserve the previous packet and use a new owned attempt directory'
plan['expectedHead'] = git('rev-parse', 'HEAD')
plan['expectedHeadTree'] = git('rev-parse', 'HEAD^{tree}')
plan['expectedTree'] = git('write-tree')
plan['expectedStatus'] = git('status', '--porcelain')
try:
    plan['expectedMergeHead'] = git('rev-parse', '--verify', 'MERGE_HEAD')
except subprocess.CalledProcessError:
    plan['expectedMergeHead'] = None
plan['snapshotMode'] = 'staged-source-merge' if plan['expectedStatus'] else 'committed-feature'
if plan['snapshotMode'] == 'staged-source-merge':
    assert plan['expectedMergeHead'] == '824957fe47dd70fad729c3b117cb18b695d54b0b', 'Only the explicitly prepared8249 merge is supported'
    plan['scope'] += ' This is explicitly an uncommitted staged merge snapshot; final committed/public qualification remains pending.'
html = (W / 'site/4d/walk/index.html').read_text()
assert ('build ' + plan['expectedHead'][:9]) in html, 'Publish the current HEAD metadata first'
pairs = []
for name in ['main.js', 'parked-transport.js', 'street-grid.js', 'terrain.js', 'tree-model.js', 'tree-instances.js', 'tree-surface.js', 'street-trees.js', 'render-budget.js', 'upload-release.js', 'popup.js']:
    pairs.append(('chicago/4d/renderers/web/js/' + name, 'site/4d/walk/js/' + name))
for name in ['transport/parked/placements.json', 'street_trees/1904.json', 'scenes/1904.json', 'street_grid/1904.json', 'street_surfaces/1904.json', 'street_section/1904.json', 'terrain/epochs/e1871_postfire/heightfield.json', 'terrain/epochs/e1871_postfire/heightfield.bin']:
    pairs.append(('chicago/4d/data/' + name, 'site/4d/data/' + name))
for name in ['brougham-near.glb', 'brougham-source.glb', 'brougham.json']:
    pairs.append(('chicago/4d/renderers/web/transport/parked-brougham/' + name, 'site/4d/walk/transport/parked-brougham/' + name))
plan['sourceAndPublishedPins'] = {}
for source, published in pairs:
    assert digest(W / source) == digest(W / published), 'Stale published bytes: ' + published
    for name in [source, published]:
        plan['sourceAndPublishedPins'][name] = {'bytes': (W / name).stat().st_size, 'sha256': digest(W / name)}
for name in ['site/4d/walk/index.html', 'chicago/4d/renderers/web/vendor/three-0.185.1/three.core.js', 'chicago/4d/docs/RESEARCH/glessner-v4-recovery/manifest.json']:
    plan['sourceAndPublishedPins'][name] = {'bytes': (W / name).stat().st_size, 'sha256': digest(W / name)}
manifest = json.loads((W / 'chicago/4d/docs/RESEARCH/glessner-v4-recovery/manifest.json').read_bytes())
for name, expected in manifest['files'].items():
    p = W / 'chicago/4d' / name
    assert p.stat().st_size == expected['bytes'] and digest(p) == expected['sha256'], 'Current exact Glessner output needed'
assert digest(W / 'chicago/4d/renderers/web/transport/parked-brougham/brougham-near.glb') == plan['nearSha256']
assert digest(W / 'chicago/4d/renderers/web/transport/parked-brougham/brougham-source.glb') == plan['rawSha256']
assert digest(pathlib.Path(plan['referencePath'])) == plan['referenceSha256']
plan['metadataSha256'] = digest(W / 'chicago/4d/renderers/web/transport/parked-brougham/brougham.json')
plan['fixturePins'] = {name: {'bytes': (D / name).stat().st_size, 'sha256': digest(D / name)} for name in ['run.cjs', 'collision_kernel.js', 'read_base_installed_world.js', 'read_published_world.js', 'CAMERA-PLAN.json']}
plan['state'] = 'PREPARED_HELD_PENDING_EXACT_ROOT_GRAPHICS_RELEASE'
plan['preparedUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(D / 'PREPARED.json').write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps({'state': plan['state'], 'snapshotMode': plan['snapshotMode'], 'head': plan['expectedHead'], 'tree': plan['expectedTree'], 'prepared_manifest_sha256': digest(D / 'PREPARED.json')}))
