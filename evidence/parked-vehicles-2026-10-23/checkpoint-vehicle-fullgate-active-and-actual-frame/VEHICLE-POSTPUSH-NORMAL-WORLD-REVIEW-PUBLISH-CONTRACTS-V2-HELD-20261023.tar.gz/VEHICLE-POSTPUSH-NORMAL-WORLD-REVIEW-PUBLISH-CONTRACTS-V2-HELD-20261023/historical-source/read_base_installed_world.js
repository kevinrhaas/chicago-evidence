// Prepared read-only hook for the existing main-page fixture's next graphics slot.
// No camera, stand, detail, material, lighting, visibility or source mutation.
window.readInstalledBroughamWorld = async function () {
  const a=window.__chicago4d,T=await import('three');
  if(!a?.ready||String(a.year)!=='1904'||!a.streetGrid?.carriagewayHeight)throw Error('Actual ready 1904 main required');
  const dataUrl=new URL('transport/parked/placements.json',a.dataBase);
  const response=await fetch(dataUrl,{cache:'no-cache'});
  if(!response.ok)throw Error('Actual placement manifest HTTP '+response.status);
  const bytes=await response.arrayBuffer(),manifest=JSON.parse(new TextDecoder().decode(bytes));
  const digest=async b=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(x=>x.toString(16).padStart(2,'0')).join('');
  const row=manifest.scenes['1904'].find(r=>r.id==='prairie_parked_studebaker_brougham'),spec=manifest.models[row?.model];
  if(!row||!spec||JSON.stringify(row.at_local_enu_m)!=='[1397.9,-3240]'||row.bearing_deg!==178.99)throw Error('Frozen standing pose differs');
  const i=a.parkedTransport.instances.find(i=>i.row.id===row.id),ground=(e,n)=>a.streetGrid.carriagewayHeight(e,n);
  const yaw=Math.PI-row.bearing_deg*Math.PI/180,co=Math.cos(yaw),si=Math.sin(yaw);
  const toEN=([x,y,z])=>[row.at_local_enu_m[0]+co*x+si*z,row.at_local_enu_m[1]+si*x-co*z,y];
  const wheels=spec.wheel_contacts_m.map(([x,z])=>{const[e,n]=toEN([x,0,z]);return{e,n,ground:ground(e,n)}});
  const wheelOnlyBase=Math.max(...wheels.map(p=>p.ground));
  const result={scope:'Read-only installed main diagnostics, not a replacement for normal published smoke',url:location.href,year:a.year,detail:a.detail,
    manifest_url:String(dataUrl),manifest_sha256:await digest(bytes),row,installed:!!i,parkedProblems:a.problems.filter(p=>p.includes('parked transport')),
    actualGroundProvider:'__chicago4d.streetGrid.carriagewayHeight',wheels,wheelOnlyBase,stats:a.stats(),genericC02Retained:a.parkedTransport.instances.some(i=>i.row.id==='prairie_parked_carriage')};
  const base=i?.group.position.y??wheelOnlyBase;
  result.supports=spec.static_support_contacts_m.map(p=>{const[e,n,y]=toEN(p),g=ground(e,n);return{e,n,source_y:y,world_y:base+y,ground:g,gap_m:Number.isFinite(g)?base+y-g:null}});
  result.maximumWheelGap_m=base-Math.min(...wheels.map(p=>p.ground));
  result.staticSupportGuardPass=result.supports.every(p=>Number.isFinite(p.gap_m)&&p.gap_m>=-.001&&p.gap_m<=.03);
  if(!i){result.accepted=false;result.reason='Production refused or did not load the installed Brougham; no diagnostic injection performed';return result;}
  if(JSON.stringify(i.row)!==JSON.stringify(row))throw Error('Loaded row differs from manifest');
  const modelUrl=new URL('./'+spec.file,document.baseURI),modelResponse=await fetch(modelUrl,{cache:'no-cache'});
  if(!modelResponse.ok)throw Error('Actual indexed asset HTTP '+modelResponse.status);
  const model=await modelResponse.arrayBuffer();result.model_url=String(modelUrl);result.model_sha256=await digest(model);
  if(result.model_sha256!=='ec2bfc0da49b570429dbcd8db39250aa6f1bbf55587570f0dafad9a42afc4ee5')throw Error('Exact V17 indexed source not served');
  i.group.updateMatrixWorld(true);
  const sample={vertices:0,missingGround:0,minGap_m:Infinity,witness:null};
  i.group.traverse(n=>{const p=n.geometry?.getAttribute('position');if(!p)return;for(let k=0;k<p.count;k++){const v=new T.Vector3().fromBufferAttribute(p,k).applyMatrix4(n.matrixWorld),g=ground(v.x,-v.z);sample.vertices++;if(!Number.isFinite(g)){sample.missingGround++;continue}if(v.y-g<sample.minGap_m){sample.minGap_m=v.y-g;sample.witness={mesh:n.name,vertex:k,world_enu:[v.x,-v.z,v.y],ground:g,gap_m:v.y-g}}}});
  result.actualMergedVertices=sample;result.drawBatches=i.draw_batches;result.visible=i.group.visible;result.productionStaticSupport=i.static_support;
  result.position=i.group.position.toArray();result.quaternion=i.group.quaternion.toArray();result.card=i.card;
  result.accepted=result.genericC02Retained&&result.staticSupportGuardPass&&result.maximumWheelGap_m<=.03&&sample.missingGround===0&&sample.minGap_m>=-.001&&result.drawBatches===7&&result.stats.withinBudget===true;
  result.unproved=['Rendered building/roof/eave and street-tree/branch narrow phase','Continuous surface extrema between actual vertices','All normal card/picking/confidence/tier/disposal smoke assertions','Photographic and occupied/riding/boarding/hitch acceptance'];
  return result;
};
