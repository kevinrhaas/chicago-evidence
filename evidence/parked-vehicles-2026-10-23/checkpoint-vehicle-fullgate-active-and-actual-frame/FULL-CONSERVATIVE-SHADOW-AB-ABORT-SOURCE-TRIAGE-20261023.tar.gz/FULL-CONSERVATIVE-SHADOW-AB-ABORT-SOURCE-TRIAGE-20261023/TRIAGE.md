# Source-only abort triage; original overallFAIL retained

The actual3stand unit stopped after one completed ordinary1904spawn cell, with four `requestfailed` /`net::ERR_ABORTED` records. All four remain in the immutable actual report and capsule. There was no automatic retry, source/default-flag change, new browser, or continuation to the two remaining stands. Current vehicle Full-OFF frame was actually inside4.6M at4,596,121; optional global culling is not necessary to claim that specific observed frame.

Exact original URLs (origin port35653):

- `/data/textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_orm.ktx2`
- `/data/textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_basecolor.ktx2`
- `/data/textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_orm.ktx2`
- `/data/sidecars/1904/people.json`

The immutable server readout proves each exact file was requested once and read from its pinned body (368349,47431,97724 and3191bytes respectively). There were no server409/404 failures, consoleerrors, pageerrors or GL errors. This does **not** prove successful complete client consumption of those bodies.

## Source paths and cancellation controllers

Roof ORM originates in `roof-relief.js`'s `loadRoofRelief`→`reliefTexture`→`ktx2.js.loadSheet/loadCompressed`→shared Three `KTX2Loader.loadAsync`. Street grass/curb originate in `street-grid.js.loadLibrary`→`loadSheet`, the same compressed loader. Three `FileLoader` creates the fetch with `AbortSignal.any([this._abortController.signal,this.manager.abortController.signal])`, then wraps a response reader in a new ReadableStream/Response before decoding the arrayBuffer. These are the possible source loader controllers; the actual failed report does not name which, if either, fired. `loadCompressed` catches rejection and can use the existing image fallback, so normal boot alone does not prove a compressed request succeeded.

The scene lacks the residents layer, so main's boot directory load is gated off. Its separate `peopleDirectory.ask()` is scheduled with `setTimeout(...,0)` after readiness and performs a plain `fetch(...,{method:'HEAD'})` at main.js4453. It passes no explicit AbortController. The caller never opens People; this after-ready HEAD is the directly supported source request path. Actual request method was not recorded, so it must not be retroactively claimed from the URL alone.

A source search found no matching application call to loader.abort/manager.abort for these resources. `disposeLoadedAsset` disposes geometry/material/texture resources but does not abort fetches. `KTX2Loader.dispose()` disposes its worker pool/revokes its worker URL, without aborting FileLoader requests. Existing parked-transport.js separately documents a prior FileLoader cancellation despite a decoded Brougham, for which that model owns a complete direct fetch/arrayBuffer before parsing. This is a relevant known pattern, not causal proof for these four current requests.

## Startup hypothesis is not proven

The frozen caller did not store a Full preference before navigation, unlike the older world caller. It calls `setDetail('full')` after normal boot. That difference is real. However `device-profile.js` chooses **Full** for a fresh desktop software/standard renderer, **Balanced** for a weak desktop, and **Light** for touch. It therefore does not support assuming this exact desktop booted Light. The actual packet records final Full, not `bootDetail`/device class before that setter. No source disposal→request-abort path was found that establishes the proposed transition as the cause.

The frozen requestfailed records omit method, timestamp, response-completion and phase. At least one failure existed before the first cell's global failure test because its native/state failures were empty and no other global error class was present. Other final failure records could also include cleanup cancellation. Exact per-request timing/controller cannot be recovered from the retained artifacts. Do not label all four intentional, suppress them, or call the whole unit green.

No startup correction patch is prepared because causal proof is insufficient. A separately reviewed future diagnostic could record actual bootDetail/device and request method/time/phase/finish before choosing a change, and should follow the existing normal-profile preference contract. No such diagnostic or rerun is authorized/performed here. Full's source flag remains unchanged.

Actual evidence: `/workspace/shared/FULL-CONSERVATIVE-SHADOW-C9CD75-3STAND-ONE-ACTUAL-20261023/`; archive SHA256 `658c88582093518274578e3dbb919ff140f500d235304266e88f8471f9ee00ad`.
