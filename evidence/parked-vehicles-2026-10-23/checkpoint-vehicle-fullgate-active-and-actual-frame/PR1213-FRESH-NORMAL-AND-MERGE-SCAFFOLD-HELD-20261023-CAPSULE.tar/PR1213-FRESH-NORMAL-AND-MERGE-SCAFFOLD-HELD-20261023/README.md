# PR1213 fresh normal CI and ordinary merge scaffolding — HELD

This packet performs no GitHub reads or writes while its templates remain held. All new source, tree, parent, branch, test-merge and actual-base pins are null, as are all four normal run IDs. Reviewed base candidate is b7cde6d86e42edd1c80204642c40ca8b683ceffd. Current owned lease is 47ec205454aa9464a1c5d06968278d714f2e1394, stale boundary 06:59:44 UTC. These candidates do not substitute for fresh actual review.

## Read-only normal collector

After the actual new source commit/push and postpublication proof, root can copy and fill ROOT-NORMAL-BINDING-TEMPLATE-HELD.json with immutable source/tree/direct parents, branch, actual reviewed base, actual GitHub test-merge/tree/parents and exactly four newly discovered standard normal run IDs. Explicit root release status ROOT_RELEASED_PR1213_FRESH_NORMAL_FOUR_GET and allow_get=true are required. No discovery query, dispatch, retry or rerun is built into this collector.

The collector refuses any source beginning 0be5, unknown pins and mismatched run identities. An old 0be5 green run cannot pass under a new source binding: every actual run and job must match the new source HEAD. Gate, humans and moving must actually checkout the exact expected new test-merge/tree/parents; push report must actually checkout the new source/tree/parents. Actual source and checkout workflow bytes must match the retained reviewed byte pins. All original normal helper assertions are unchanged, including every required successful step and the explicitly skipped dependent teamster-studies job. Exactly one fixed-ID collector owns a source-specific output directory and lock, polling at 60 seconds for at most 180 minutes. Failed/incomplete/unknown proof remains failed or partial. Nothing grants final merge qualification.

Prepared invocation, ONLY after explicit root binding/release:

    python3 collect-normal-terminals-GET-only.py --root-binding ACTUAL-ROOT-NORMAL-BINDING.json

## Ordinary merge guard

ROOT-ORDINARY-MERGE-RELEASE-TEMPLATE-HELD.json remains separately held. Passing the normal collector does not release this guard. Root must explicitly review actual current source/base/own lease, actual postpublication proof and all four genuine world units, then provide the exact unit IDs, qualified source HEAD/tree, raw receipt paths and SHA256s. No world proof is invented by this packet.

Only the distinct status ROOT_RELEASED_PR1213_ORDINARY_HEAD_PINNED_MERGE, allow_merge=true, matching guard bytes and --execute-ordinary-merge can enable an action. The guard requires the same actual four normal run IDs/checkouts and all four root-reviewed world units. It checks current DEV, source branch, PR identity, exact clean test-merge, owned unexpired 47ec lease and native policy twice. Any new base beyond reviewed b7 or owner drift holds. If explicitly released, it sends one ordinary REST squash merge pinned to the new source SHA, with no admin/auto/bypass/force and no retry, then verifies actual result tree/base. Deployment and lease release remain separate and are not claimed here.

Prepared invocation, ONLY after that later separate explicit root release:

    python3 ordinary-merge-guard-HELD.py --root-release ACTUAL-ROOT-ORDINARY-RELEASE.json --execute-ordinary-merge

## Source-only validation already performed

Python syntax passed. Four local negative controls passed with a fake gh that cannot reach the network: held normal template, forbidden old 0be5 source, unknown source pins, and held ordinary-merge release. Each refused before any remote call or output-owner creation. No actual collector, world unit, full gate, browser, CI dispatch, remote smoke, app change or merge ran while preparing this packet. Strict normal helper bytes remain SHA256 0d960da4b79a5264d8b45f83a0788baebf7eb49a0cd5272b2dc493df99459623.
