"""HELD PR1213 ordinary merge scaffold. Only a separate explicit root world/source/base/lease review release can enable the one head-pinned merge. No dispatch or bypass."""
import argparse,datetime,hashlib,json,pathlib,re,subprocess
HERE=pathlib.Path(__file__).resolve().parent
EXPECTED_LEASE='47ec205454aa9464a1c5d06968278d714f2e1394'
REVIEWED_BASE_CANDIDATE='b7cde6d86e42edd1c80204642c40ca8b683ceffd'
def need(x,message):
 if not x:raise ValueError(message)
def sha(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def load(p):return json.loads(pathlib.Path(p).read_bytes())
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--root-release',required=True,type=pathlib.Path);parser.add_argument('--execute-ordinary-merge',action='store_true');a=parser.parse_args();release_bytes=a.root_release.read_bytes();r=json.loads(release_bytes)
 need(r.get('status')=='ROOT_RELEASED_PR1213_ORDINARY_HEAD_PINNED_MERGE' and r.get('allow_merge')is True,'HELD: root has not explicitly released current world four/source/base/lease review')
 need(a.execute_ordinary_merge,'HELD: explicit one-merge execution flag required')
 need(r['repository']=='kevinrhaas/chicago' and r['pr']==1213,'Wrong repository/PR')
 H=r['source_head'];T=r['source_tree'];P=r['source_parents'];B=r['reviewed_base'];Q=r['testmerge_head'];QT=r['testmerge_tree'];BRANCH=r['source_branch']
 need(all(isinstance(x,str)and re.fullmatch('[a-f0-9]{40}',x)for x in[H,T,B,Q,QT]),'Unknown immutable new source/tree/testmerge/base')
 need(not H.startswith('0be5'),'Old0be5 source/green evidence is forbidden')
 need(B==REVIEWED_BASE_CANDIDATE and r['testmerge_parents']==[B,H],'Base beyond finite reviewed b7 or wrong testmerge parents; HOLD for review')
 need(isinstance(P,list)and len(P)in[1,2]and all(re.fullmatch('[a-f0-9]{40}',x)for x in P),'Unknown source parents')
 need(isinstance(BRANCH,str)and re.fullmatch('[A-Za-z0-9_./-]+',BRANCH),'Unknown source branch')
 need(r['expected_owned_lease']==EXPECTED_LEASE,'Lease pin requires explicit new-owner review')
 need(r['guard_sha256']==sha(pathlib.Path(__file__).read_bytes()),'Ordinary guard byte pin differs')
 need(r['root_actual_world_four_verified']is True and r['root_current_source_base_lease_reviewed']is True and r['actual_postpublication_verified']is True,'Current root world/source/base/lease/postpublication review incomplete')
 world=r['world_units'];need(isinstance(world,list)and len(world)==4 and len({x['unit_id']for x in world})==4,'Exactly four distinct root-reviewed actual world units required')
 for w in world:
  need(w['actual_PASS']is True and w['qualified_source_head']==H and w['qualified_source_tree']==T,'World unit not explicitly qualified for exact fresh source/tree')
  need(sha(pathlib.Path(w['raw_receipt']).read_bytes())==w['raw_receipt_sha256'],'World raw receipt byte pin differs')
 N=pathlib.Path(r['normal_collector_output']);binding_bytes=(N/'ACTUAL-ROOT-BINDING.json').read_bytes();binding=json.loads(binding_bytes);terminal=load(N/'TERMINAL.json');jobs=load(N/'AUDITED-JOBS.json')
 need(sha(binding_bytes)==r['normal_binding_sha256'] and binding['source_head']==H and binding['source_tree']==T and binding['source_parents']==P and binding['source_branch']==BRANCH and binding['reviewed_base']==B and binding['testmerge_head']==Q and binding['testmerge_tree']==QT and binding['testmerge_parents']==[B,H],'Normal collector is not bound to same actual new source/base/tree')
 need(terminal['status']=='NORMAL_FOUR_TERMINAL_SOURCE_AND_CHECKOUT_EVIDENCE_ONLY' and terminal['terminal_collected']==terminal['strict_success']==4,'Four actual standard normals have not all passed')
 need(len(jobs)==4 and all(x['PASS']is True for x in jobs)and {x['run_id']for x in jobs}=={x['run_id']for x in binding['normal_runs']},'Actual fixed run IDs or verdicts differ')
 for x in jobs:
  need(x['source']==H and x['workflow_sha256']==binding['workflow_byte_pins'][x['workflow_path']],'Source/workflow proof differs')
  if x['event']=='pull_request':need(x['actual_checkout_sha']==Q and x['actual_checkout_tree']==QT and x['actual_checkout_parents']==[B,H],'PR checkout not exact reviewed new integration')
  else:need(x['event']=='push'and x['actual_checkout_sha']==H and x['actual_checkout_tree']==T and x['actual_checkout_parents']==P,'Push report source/tree/parents differ')
 O=pathlib.Path('/workspace/shared/PR1213-'+H[:10]+'-ORDINARY-MERGE-ONCE');O.mkdir(exist_ok=False);(O/'ACTUAL-ROOT-RELEASE.json').write_bytes(release_bytes);counter=0
 def api(label,route,method='GET',body=None):
  nonlocal counter
  counter+=1;stem=O/f'{counter:03d}-{label}';stem.with_suffix('.request.json').write_text(json.dumps({'at':now(),'method':method,'route':route,'body':body},indent=2)+'\n');cmd=['gh','api','--method',method,'repos/kevinrhaas/chicago/'+route]
  if body is not None:cmd+=['--input','-']
  v=subprocess.run(cmd,input=json.dumps(body).encode()if body is not None else None,capture_output=True,timeout=45);stem.with_suffix('.stdout').write_bytes(v.stdout);stem.with_suffix('.stderr').write_bytes(v.stderr);need(v.returncode==0,'API refused/ambiguous: preserve and STOP without retry '+str(stem));return json.loads(v.stdout)if v.stdout.strip()else None
 def fresh_guards():
  need(api('owned-lease-ref','git/ref/heads/lap/pr-1213')['object']['sha']==EXPECTED_LEASE,'Owned lease changed: HOLD')
  lease=api('owned-lease-commit','git/commits/'+EXPECTED_LEASE);age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(lease['committer']['date'].replace('Z','+00:00'))).total_seconds();need(0<=age<=3*3600,'Owned lease stale/invalid; HOLD for guarded renewal')
  need(api('actual-dev','git/ref/heads/dev')['object']['sha']==B,'DEV advanced beyond reviewed base: HOLD')
  need(api('actual-source-ref','git/ref/heads/'+BRANCH)['object']['sha']==H,'PR branch advanced: HOLD')
  pr=api('actual-pr','pulls/1213');need(pr['state']=='open'and pr['head']['sha']==H and pr['head']['ref']==BRANCH and pr['head']['repo']['full_name']=='kevinrhaas/chicago'and pr['base']['ref']=='dev'and pr['auto_merge']is None,'PR identity/state/auto-merge differs')
  need(pr['mergeable']is True and pr['mergeable_state']=='clean'and pr['merge_commit_sha']==Q and 'hold'not in{x['name']for x in pr['labels']},'Native clean policy/testmerge/hold differs: HOLD')
 fresh_guards()
 source=api('actual-source-commit','git/commits/'+H);need(source['tree']['sha']==T and [x['sha']for x in source['parents']]==P,'Source tree/parents drift')
 merge=api('actual-testmerge-commit','git/commits/'+Q);need(merge['tree']['sha']==QT and [x['sha']for x in merge['parents']]==[B,H],'Testmerge tree/parents drift')
 fresh_guards()
 answer=api('one-ordinary-head-pinned-merge','pulls/1213/merge','PUT',{'sha':H,'merge_method':'squash'});need(answer.get('merged')is True,'Ordinary merge refused/ambiguous; STOP without retry')
 M=answer['sha'];actual=api('actual-merged-commit','git/commits/'+M);need(actual['tree']['sha']==QT and [x['sha']for x in actual['parents']]==[B],'Actual result tree/base differs from qualified integration')
 pr=api('actual-merged-pr','pulls/1213');need(pr['merged']is True and pr['state']=='closed'and pr['merge_commit_sha']==M and pr['head']['sha']==H,'Actual merged PR/source differs')
 receipt={'at':now(),'ordinary_head_pinned_merge':True,'source_head':H,'source_tree':T,'source_parents':P,'base':B,'testmerge_head':Q,'testmerge_tree':QT,'actual_merge':M,'actual_result_tree':actual['tree']['sha'],'owned_lease':EXPECTED_LEASE,'root_release_sha256':sha(release_bytes),'actual_normal_four_PASS':True,'world_four_verified_by_root':True,'native_auto_merge':False,'admin_bypass':False,'force_source_push':False,'CI_dispatches':0,'smoke_dispatches':0,'retries':0,'deployment_verified':False,'lease_released':False,'scope':'Bounded current1213 delivery only; no whole suite or broad photographic-parent closure.'}
 (O/'ACTUAL-MERGE-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
if __name__=='__main__':main()
