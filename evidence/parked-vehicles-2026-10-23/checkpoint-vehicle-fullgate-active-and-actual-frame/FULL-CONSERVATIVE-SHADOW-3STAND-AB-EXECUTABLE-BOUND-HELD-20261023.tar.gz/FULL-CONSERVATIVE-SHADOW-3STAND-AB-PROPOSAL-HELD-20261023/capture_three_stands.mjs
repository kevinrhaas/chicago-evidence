// External source-only preparation. Execute only through run_owned.py after root binding.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import {createRequire} from 'node:module';

const arg=(name)=>{const i=process.argv.indexOf(name);if(i<0||!process.argv[i+1])throw Error('Missing '+name);return process.argv[i+1];};
const binding=JSON.parse(fs.readFileSync(arg('--binding'),'utf8'));
const out=path.resolve(arg('--out')),site=path.resolve(binding.site_root),workMs=Number(arg('--work-ms'));
if(!binding.root_browser_release||!binding.exclusive_browser_lane_confirmed||!binding.canonical_publication_terminal_confirmed)throw Error('HELD');
if(!Number.isFinite(workMs)||workMs<=0||workMs>570000)throw Error('Invalid finite work budget');
const require=createRequire(path.join(binding.source_root,'chicago/4d/tools/qa.mjs'));
const {chromium}=require('playwright');
const sha=(b)=>crypto.createHash('sha256').update(b).digest('hex');
const save=(name,obj)=>fs.writeFileSync(path.join(out,name),JSON.stringify(obj,null,2)+'\n');
const report={status:'FAIL',kind:'SEPARATE_FULL_CULLER_REGRESSION_NOT_WHOLE_WORLD_PHOTOGRAPHIC_QUALIFICATION',started_utc:new Date().toISOString(),pid:process.pid,browser_started:false,binding_sha256:sha(fs.readFileSync(arg('--binding'))),source:{head:binding.source_head,head_tree:binding.source_head_tree,staged_tree:binding.source_tree,merge_heads:binding.source_merge_heads,build:binding.build_version},viewport:{width:1280,height:800,deviceScaleFactor:1},detail:'full',attempts:1,automatic_retry:false,errors:[],console_errors:[],failed_requests:[],server_errors:[],served_files:{},harmless_favicon_204_requests:[],stands:[],cleanup:{contexts_closed:0,browser_closed:false,server_closed:false}};
let browser=null,server=null,currentContext=null,timedOut=false;
const flush=()=>save('REPORT.json',report);
const timer=setTimeout(()=>{timedOut=true;report.error='Finite browser work deadline reached';flush();void browser?.close().catch(()=>{});server?.closeAllConnections?.();server?.close();},workMs);
timer.unref();
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.glb':'model/gltf-binary','.svg':'image/svg+xml','.bin':'application/octet-stream','.wasm':'application/wasm','.ktx2':'image/ktx2','.woff2':'font/woff2','.mp3':'audio/mpeg','.ogg':'audio/ogg'};

// Native readPixels are bottom-up. Encode a shareable PNG from those exact bytes.
const crcTable=Uint32Array.from({length:256},(_,n)=>{let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
function crc32(buf){let c=0xffffffff;for(const b of buf)c=crcTable[(c^b)&255]^(c>>>8);return(c^0xffffffff)>>>0;}
function chunk(type,data){const tag=Buffer.from(type),n=Buffer.alloc(4),crc=Buffer.alloc(4);n.writeUInt32BE(data.length);crc.writeUInt32BE(crc32(Buffer.concat([tag,data])));return Buffer.concat([n,tag,data,crc]);}
function pngRGBA(raw,w,h){
  if(raw.length!==w*h*4)throw Error('Wrong native RGBA size');
  const scan=Buffer.alloc((w*4+1)*h);
  for(let y=0;y<h;y++){const dst=y*(w*4+1);scan[dst]=0;raw.copy(scan,dst+1,(h-y-1)*w*4,(h-y)*w*4);}
  const ih=Buffer.alloc(13);ih.writeUInt32BE(w,0);ih.writeUInt32BE(h,4);ih[8]=8;ih[9]=6;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ih),chunk('IDAT',zlib.deflateSync(scan)),chunk('IEND',Buffer.alloc(0))]);
}
function writeFrame(id,key,frame,w,h){
  const bytes=Buffer.from(frame.rgba_base64,'base64');delete frame.rgba_base64;
  const raw=id+'-'+key+'.rgba',png=id+'-'+key+'.png';
  fs.writeFileSync(path.join(out,raw),bytes);fs.writeFileSync(path.join(out,png),pngRGBA(bytes,w,h));
  return {...frame,native_rgba:{file:raw,bytes:bytes.length,sha256:sha(bytes),order:'bottom-up RGBA8'},png:{file:png,sha256:sha(fs.readFileSync(path.join(out,png)))}};
}
async function openScene(year){
  currentContext=await browser.newContext({viewport:{width:1280,height:800},deviceScaleFactor:1,isMobile:false,hasTouch:false});
  const page=await currentContext.newPage();page.setDefaultTimeout(240000);
  page.on('pageerror',e=>report.errors.push({scene:year,error:String(e)}));
  page.on('console',message=>{if(message.type()==='error')report.console_errors.push({scene:year,text:message.text(),location:message.location()});});
  page.on('requestfailed',r=>report.failed_requests.push({scene:year,url:r.url(),error:r.failure()?.errorText}));
  page.on('response',r=>{if(r.status()>=400)report.failed_requests.push({scene:year,url:r.url(),status:r.status()});});
  await page.goto(origin+(year==='1904'?'/1904/':'/walk/?year=1835'),{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:240000,polling:500});
  const ready=await page.evaluate(()=>({ready:window.__chicago4d?.ready,error:window.__chicago4d?.error}));
  if(!ready.ready||ready.error)throw Error('Normal boot failed: '+JSON.stringify(ready));
  await page.waitForFunction(()=>window.__chicago4d?.welcome.state==='welcome',null,{timeout:240000,polling:500});
  const boot=await page.evaluate(async({year,initial})=>{
    const a=window.__chicago4d;if(!a.ready||a.error||a.scene.id!==year)throw Error('Wrong/failed normal scene boot');
    if(!a.welcome.enter('spawn'))throw Error('Normal welcome entry failed');
    document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();
    a.renderer.setAnimationLoop(null);await a.setDetail('full');a.setAnimationHold(true);a.step();
    if(a.setCastersTowardView().on!==initial)throw Error('Full baseline flag changed; this is an OFF-source A/B');
    return{scene:a.scene.id,detail:a.detail,initial_casters:a.setCastersTowardView(),source_spawn:a.scene.spawn,build_label:document.getElementById('gate-build')?.textContent??null};
  },{year,initial:binding.expected_initial_full_casters_toward_view});
  await page.waitForFunction(()=>document.getElementById('gate')?.hidden===true);
  if(boot.detail!=='full')throw Error('Full did not settle');
  report.boots??=[];report.boots.push(boot);flush();return page;
}

const stands=[
  {id:'1904-ordinary-glessner-spawn',year:'1904',kind:'spawn'},
  {id:'1904-t2434-front',year:'1904',kind:'eye-target',eye:[1394,-3001,1.7],target:[1413,-3001,8.5]},
  {id:'1835-western-yard-existing-horse-quarter',year:'1835',kind:'walker',pose:{local_e:-124.9,local_n:-293.4,yaw_deg:225,pitch_deg:-12}},
];
let origin='';
try{
  server=http.createServer((req,res)=>{
    try{
      const uri=new URL(req.url,'http://127.0.0.1');
      if(uri.pathname==='/favicon.ico'){report.harmless_favicon_204_requests.push({url:req.url,status:204});res.writeHead(204);res.end();return;}
      let relative=decodeURIComponent(uri.pathname).replace(/^\/+/,''),file=path.resolve(site,relative);
      if(file!==site&&!file.startsWith(site+path.sep))throw Error('Path leaves bound site');
      if(fs.statSync(file).isDirectory()){relative=relative?relative.replace(/\/+$/,'')+'/index.html':'index.html';file=path.join(file,'index.html');}
      const expected=binding.published_files[relative];if(!expected)throw Error('Unbound served file: '+relative);
      const bytes=fs.readFileSync(file);if(sha(bytes)!==expected)throw Error('Published bytes moved: '+relative);
      report.served_files[relative]={sha256:expected,bytes:bytes.length,requests:(report.served_files[relative]?.requests??0)+1};
      res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Content-Length':bytes.length,'Cache-Control':'no-store'});res.end(bytes);
    }catch(e){const status=e.code==='ENOENT'?404:409;report.server_errors.push({url:req.url,error:String(e),status});res.writeHead(status,{'Content-Type':'text/plain'});res.end('Bound immutable publication unavailable');}
  });
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
  origin='http://127.0.0.1:'+server.address().port;report.server={origin,pid:process.pid};flush();
  browser=await chromium.launch({executablePath:binding.playwright_executable||process.env.PW_EXECUTABLE||undefined,args:['--no-sandbox','--enable-unsafe-swiftshader']});
  report.browser_started=true;report.browser_version=browser.version();flush();
  let page=null,year=null;
  for(const stand of stands){
    if(timedOut)throw Error('Finite browser work boundary');
    if(year!==stand.year){
      if(currentContext){await currentContext.close();currentContext=null;report.cleanup.contexts_closed++;}
      page=await openScene(stand.year);year=stand.year;
    }
    const preparation=await page.evaluate(async({stand,expectedHorse})=>{
      const a=window.__chicago4d;
      if(stand.kind==='eye-target'){
        const p=[stand.eye[0],stand.eye[1],a.terrain.surfaceHeight(stand.eye[0],stand.eye[1])+stand.eye[2]],t=[stand.target[0],stand.target[1],a.terrain.surfaceHeight(stand.target[0],stand.target[1])+stand.target[2]];
        a.setFly(true);a.walker.teleport({local_e:p[0],local_n:p[1],altitude_m:stand.eye[2],yaw_deg:Math.atan2(t[0]-p[0],t[1]-p[1])*180/Math.PI,pitch_deg:Math.atan2(t[2]-p[2],Math.hypot(t[0]-p[0],t[1]-p[1]))*180/Math.PI});a.step();
        a.camera.position.set(p[0],p[2],-p[1]);a.camera.lookAt(t[0],t[2],-t[1]);
      }else if(stand.kind==='walker'){
        a.setFly(false);a.walker.teleport(stand.pose);a.step();
        if(expectedHorse){if(!a.standingHorses)throw Error('Bound eligible horse layer missing');await a.standingHorses.ready;a.step();}
      }
      a.camera.updateMatrixWorld();a.scene3d.updateMatrixWorld(true);a.world.follow(a.camera.position);a.world.aim(a.camera);
      return{walker:{e:a.walker.state.e,n:a.walker.state.n,bearing:a.walker.bearingDeg,pitch:a.walker.state.pitch},detail:a.detail,camera:{position:a.camera.position.toArray(),quaternion:a.camera.quaternion.toArray(),fov:a.camera.fov,zoom:a.camera.zoom}};
    },{stand,expectedHorse:binding.expected_horse_actor_present_1835});
    const result=await page.evaluate(({stand,binding})=>{
      const a=window.__chicago4d,gl=a.renderer.getContext(),renderer=a.renderer,light=a.world.light;
      const fail=[],check=(condition,text)=>{if(!condition)fail.push(text);};
      const identity=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
      const camera=()=>({position:a.camera.position.toArray(),quaternion:a.camera.quaternion.toArray(),projection:a.camera.projectionMatrix.toArray(),inverse:a.camera.matrixWorldInverse.toArray(),fov:a.camera.fov,zoom:a.camera.zoom,near:a.camera.near,far:a.camera.far});
      const rig=()=>({sun:a.world.direction.toArray(),sunDate:a.world.sunDate,rig:{...a.world.shadowRig},mapSize:light.shadow.mapSize.toArray(),bias:light.shadow.bias,normalBias:light.shadow.normalBias,radius:light.shadow.radius,camera:light.shadow.camera.projectionMatrix.toArray()});
      const visibility=()=>{
        const rows=[];a.scene3d.traverse(o=>{
          const row={uuid:o.uuid,name:o.name,visible:o.visible};
          if(o.isBatchedMesh){row.matrixWorld=o.matrixWorld.toArray();row.bits='';for(let i=0;i<(o.userData.batchIndex?.length??0);i++)row.bits+=o.userData.batchIndex[i]==null?'-':o.getVisibleAt(i)?'1':'0';}
          rows.push(row);
        });return rows;
      };
      const horse=()=>a.standingHorses?.instances?.map(i=>{let visible=true;for(let p=i.root;p;p=p.parent)visible=visible&&p.visible;const bones=[];i.root?.traverse(o=>{if(o.isBone)bones.push({name:o.name,position:o.position.toArray(),quaternion:o.quaternion.toArray(),scale:o.scale.toArray()});});return{id:i.row?.id,visible,position:i.root?.position.toArray(),bones,idle:i.idle?.status?JSON.parse(JSON.stringify(i.idle.status)):null};})??[];
      const parked=()=>a.parkedTransport?.instances?.map(i=>({id:i.row.id,model:i.row.model,visible:i.group.visible,active_lod:i.active_lod??null,active_triangles:i.active_triangles??null}))??[];
      const serialize=v=>JSON.stringify(v),baseCamera=camera(),baseRig=rig(),baseVisibility=visibility(),baseHorse=horse(),baseParked=parked();
      check(a.detail==='full','not Full');check(a.camera.fov===55&&a.camera.zoom===1,'fixed native desktop camera changed');
      check(a.setCastersTowardView().on===false,'Full baseline was not off');
      check(a.buildings.batches.every(b=>b.matrixWorld.toArray().every((v,k)=>v===identity[k])),'structure batch matrixWorld is not identity');
      if(stand.kind==='spawn'){
        const offBearing=Math.abs(((a.walker.bearingDeg-264.94+540)%360)-180);
        check(Math.hypot(a.walker.state.e-1410.12,a.walker.state.n+3218.01)<0.5&&offBearing<1&&a.walker.state.pitch===0,'ordinary source spawn differs from existing T1739 guard');
        const b=baseParked.find(i=>i.id==='prairie_parked_studebaker_brougham');
        check(!!b&&b.active_lod===binding.expected_brougham_active_lod_1904_spawn&&b.active_triangles===binding.expected_brougham_active_triangles_1904_spawn,'accepted Brougham selected LOD missing/stale');
        check(!baseParked.some(i=>i.id==='prairie_parked_carriage'),'obsolete C02 row still active');
      }
      if(stand.year==='1835'){
        check(baseHorse.some(i=>i.id==='western_hotel_yard_standing_horse_01')===binding.expected_horse_actor_present_1835,'actual horse activation differs from final source binding');
        if(binding.expected_horse_actor_present_1835)check(baseHorse.some(i=>i.id==='western_hotel_yard_standing_horse_01'&&i.visible),'eligible source horse is hidden; no horse visual parity');
        check(baseParked.length===5,'five distinct1835 parked rows not present');
      }
      const settings={caster:a.setCastersTowardView().on,castShadow:light.castShadow,autoUpdate:renderer.shadowMap.autoUpdate,needsUpdate:renderer.shadowMap.needsUpdate,lightNeedsUpdate:light.shadow.needsUpdate};
      check(settings.castShadow===true,'sun shadows were already disabled');
      const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;
      const encode=bytes=>{let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s);};
      const frame=()=>{
        const started=performance.now();
        for(let k=0;k<2;k++){
          a.camera.updateMatrixWorld();a.world.follow(a.camera.position);a.world.aim(a.camera);
          renderer.shadowMap.needsUpdate=true;light.shadow.needsUpdate=true;
          renderer.render(a.scene3d,a.camera);
        }
        const px=new Uint8Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.UNSIGNED_BYTE,px);
        const error=gl.getError(),lost=gl.isContextLost(),stats=a.stats();
        check(error===gl.NO_ERROR&&!lost,'GL error/context loss');
        check(serialize(camera())===serialize(baseCamera),'camera changed across held frame');
        check(serialize(rig())===serialize(baseRig),'sun/shadow quality or rig changed');
        check(serialize(visibility())===serialize(baseVisibility),'colour/pick visibility not restored');
        check(serialize(horse())===serialize(baseHorse),'horse pose/time changed across pair');
        check(serialize(parked())===serialize(baseParked),'parked identities/selected LOD changed');
        return{px,stats,gl_error:error,context_lost:lost,render_pair_ms:performance.now()-started};
      };
      let off=null,on=null,control=null,culled=0,restored=false;
      try{
        // All renders and native readbacks are synchronous in this one page task.
        // Normal loop is stopped and supported animationHold keeps clock dt at0.
        a.setCastersTowardView(false);off=frame();
        const on0=a.setCastersTowardView(true).culled;on=frame();culled=a.setCastersTowardView().culled-on0;
        light.castShadow=false;control=frame();
      }finally{
        light.castShadow=settings.castShadow;a.setCastersTowardView(settings.caster);
        renderer.shadowMap.autoUpdate=settings.autoUpdate;renderer.shadowMap.needsUpdate=settings.needsUpdate;light.shadow.needsUpdate=settings.lightNeedsUpdate;
        restored=light.castShadow===settings.castShadow&&a.setCastersTowardView().on===settings.caster&&renderer.shadowMap.autoUpdate===settings.autoUpdate;
      }
      let differingPixels=0,differingBytes=0,maxDelta=0,controlPixels=0;
      if(off&&on&&control){
        for(let i=0;i<off.px.length;i+=4){let changed=false,c=false;for(let k=0;k<4;k++){const delta=Math.abs(off.px[i+k]-on.px[i+k]);if(delta){changed=true;differingBytes++;maxDelta=Math.max(maxDelta,delta);}if(k<3&&off.px[i+k]!==control.px[i+k])c=true;}if(changed)differingPixels++;if(c)controlPixels++;}
        check(differingBytes===0,'native RGBA OFF/ON differs');check(controlPixels>0,'all-shadows-off positive control changed no RGB pixel');
        check(on.stats.triangles<=off.stats.triangles,'ON added triangles');
        for(const f of [off,on,control])check(f.stats.budget.drawCalls===binding.expected_caps[stand.year].drawCalls&&f.stats.budget.triangles===binding.expected_caps[stand.year].triangles,'unchanged source budget mismatch');
        check(on.stats.withinBudget===true,'ON is outside unchanged public frame budget');
      }
      check(restored,'harness shadow state not restored');
      // Same normal-world exclusion used by the ordinary T1739 smoke: these
      // source-declared provisional notes are reported, not new loader errors.
      check(a.problems.filter(p=>!/provisional|PLACEHOLDER|placeholder/i.test(p)).length===0,'normal world has non-provisional loader/geometry problems');
      const pack=f=>f?{stats:f.stats,gl_error:f.gl_error,context_lost:f.context_lost,render_pair_ms:f.render_pair_ms,rgba_base64:encode(f.px)}:null;
      return{failures:fail,width,height,gl_metadata:{version:gl.getParameter(gl.VERSION),renderer:gl.getParameter(gl.RENDERER),vendor:gl.getParameter(gl.VENDOR)},off:pack(off),on:pack(on),control:pack(control),native_comparison:{differing_pixels:differingPixels,differing_bytes:differingBytes,max_channel_delta:maxDelta,positive_control_rgb_differing_pixels:controlPixels},pieces_culled_during_two_ON_renders:culled,harness_state_restored:restored,camera:baseCamera,rig:baseRig,initial_visibility:baseVisibility,final_visibility:visibility(),horses:baseHorse,horse_visual_claim:baseHorse.length?'frozen actual present source actor':'ABSENT_NO_HORSE_VISUAL_CLAIM',parked:baseParked,problems:[...a.problems]};
    },{stand,binding:{expected_caps:binding.expected_caps,expected_horse_actor_present_1835:binding.expected_horse_actor_present_1835,expected_brougham_active_lod_1904_spawn:binding.expected_brougham_active_lod_1904_spawn,expected_brougham_active_triangles_1904_spawn:binding.expected_brougham_active_triangles_1904_spawn}});
    for(const key of ['off','on','control'])if(result[key])result[key]=writeFrame(stand.id,key,result[key],result.width,result.height);
    report.stands.push({id:stand.id,scene:stand.year,preparation,...result});flush();
    console.log(JSON.stringify({stand:stand.id,off:result.off?.stats,on:result.on?.stats,comparison:result.native_comparison,failures:result.failures}));
    if(result.failures.length||report.errors.length||report.console_errors.length||report.failed_requests.length||report.server_errors.length)throw Error('Actual cell failed; no retry or next cell');
  }
  if(report.stands.length!==3)throw Error('Missing fixed stand');
  if(timedOut)throw Error('Browser deadline');
  report.status='PASS';
}catch(e){report.status='FAIL';report.error=String(e?.stack??e);}
finally{
  clearTimeout(timer);
  try{if(currentContext){await currentContext.close();currentContext=null;report.cleanup.contexts_closed++;}}catch(e){report.cleanup.context_error=String(e);report.status='FAIL';}
  try{if(browser){await browser.close();report.cleanup.browser_closed=true;}}catch(e){report.cleanup.browser_error=String(e);report.status='FAIL';}
  try{if(server){server.closeAllConnections?.();if(server.listening)await new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()));report.cleanup.server_closed=!server.listening;}}catch(e){report.cleanup.server_error=String(e);report.status='FAIL';}
  if(!report.cleanup.browser_closed||!report.cleanup.server_closed)report.status='FAIL';
  if(report.errors.length||report.console_errors.length||report.failed_requests.length||report.server_errors.length)report.status='FAIL';
  report.ended_utc=new Date().toISOString();report.timed_out=timedOut;flush();
}
process.exitCode=report.status==='PASS'?0:1;
