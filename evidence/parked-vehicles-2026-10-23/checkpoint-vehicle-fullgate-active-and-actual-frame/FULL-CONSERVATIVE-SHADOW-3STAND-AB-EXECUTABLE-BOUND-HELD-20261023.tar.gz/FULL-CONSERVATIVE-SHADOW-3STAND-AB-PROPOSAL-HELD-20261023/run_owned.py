#!/usr/bin/env python3
"""One finite source-bound native A/B. Preparation only until root fills binding."""
import argparse, datetime, hashlib, json, os, pathlib, signal, subprocess, sys, time

HERE = pathlib.Path(__file__).resolve().parent
START = time.monotonic()
DEADLINE = START + 600
WORK_END = START + 570
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def require(ok, text):
    if not ok: raise RuntimeError(text)
def timed(): require(time.monotonic() < WORK_END, '570s work boundary reached')
def digest_file(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): timed();h.update(b)
    return h.hexdigest()
def safe(root, rel):
    require(isinstance(rel,str) and rel and not pathlib.Path(rel).is_absolute(), 'invalid relative path')
    p=(root/rel).resolve();require(p.is_relative_to(root), 'path leaves bound root')
    require(p.is_file() and not (root/rel).is_symlink(), 'missing file or symlink: '+rel)
    return p
def command(root, args):
    timed()
    return subprocess.check_output(['git','-C',str(root),*args], timeout=min(15,max(.1,WORK_END-time.monotonic())))
def index_tree(root):
    # Compute the Git tree Merkle hash from the index without git write-tree or
    # any object/index writes. Raw byte names preserve Git's exact ordering.
    trie={}
    for row in command(root,['ls-files','--stage','-z']).split(b'\0'):
        if not row:continue
        meta,sep,name=row.partition(b'\t');require(bool(sep),'invalid index row')
        mode,oid,stage=meta.split();require(stage==b'0','unresolved index stage')
        node=trie;parts=name.split(b'/')
        for part in parts[:-1]:
            if part not in node:node[part]={}
            require(isinstance(node[part],dict),'index file/directory collision');node=node[part]
        require(parts[-1] not in node,'duplicate index path')
        node[parts[-1]]=(mode,bytes.fromhex(oid.decode()))
    def tree(node):
        body=b''
        for name,value in sorted(node.items(),key=lambda pair:pair[0]+(b'/' if isinstance(pair[1],dict) else b'')):
            mode,oid=(b'40000',tree(value)) if isinstance(value,dict) else value
            body+=mode+b' '+name+b'\0'+oid
        return hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).digest()
    return tree(trie).hex()
def verify(b):
    require(b.get('schema')=='full-shadow-three-stand-binding-v1','wrong binding schema')
    for key in ['root_browser_release','exclusive_browser_lane_confirmed','canonical_publication_terminal_confirmed']:
        require(b.get(key) is True,'HELD: '+key)
    root=pathlib.Path(b['source_root']).resolve();site=pathlib.Path(b['site_root']).resolve()
    for key in ['source_head','source_head_tree','source_tree','source_status_porcelain_sha256','build_json_sha256','build_version']:
        require(isinstance(b.get(key),str) and b[key],'unset binding '+key)
    require(command(root,['rev-parse','HEAD']).decode().strip()==b['source_head'],'HEAD moved')
    require(command(root,['rev-parse','HEAD^{tree}']).decode().strip()==b['source_head_tree'],'HEAD tree moved')
    require(index_tree(root)==b['source_tree'],'staged index tree moved')
    merge_file=pathlib.Path(command(root,['rev-parse','--git-path','MERGE_HEAD']).decode().strip())
    if not merge_file.is_absolute():merge_file=root/merge_file
    merge_heads=merge_file.read_text().splitlines() if merge_file.is_file() else []
    require(isinstance(b.get('source_merge_heads'),list) and merge_heads==b['source_merge_heads'],'merge context moved/unset')
    status=command(root,['status','--porcelain=v1','-z','--untracked-files=all'])
    require(hashlib.sha256(status).hexdigest()==b['source_status_porcelain_sha256'],'source status moved')
    require(b.get('expected_initial_full_casters_toward_view') is False,'must measure unmodified Full-off baseline')
    require(type(b.get('expected_horse_actor_present_1835')) is bool,'derive horse activation from final source')
    require(b.get('expected_brougham_active_lod_1904_spawn')=='mid' and b.get('expected_brougham_active_triangles_1904_spawn')==11706,'wrong accepted Brougham expectation')
    require(b.get('expected_caps')=={'1904':{'drawCalls':7800,'triangles':4600000},'1835':{'drawCalls':7800,'triangles':3470000}},'caps must remain unchanged')
    files=b.get('published_files');pairs=b.get('source_pairs')
    require(isinstance(files,dict) and files and isinstance(pairs,list) and pairs,'unset source/publication inventory')
    implementation=b.get('implementation_sha256')
    require(isinstance(implementation,dict),'unset reviewed executable pins')
    for p in [HERE/'run_owned.py',HERE/'capture_three_stands.mjs']:
        require(implementation.get(p.name)==hashlib.sha256(p.read_bytes()).hexdigest(),'reviewed executable moved: '+p.name)
    seen=set()
    for pair in pairs:
        timed();src=pair['source_rel'];pub=pair['published_rel'];mode=pair.get('mode','byte-identical')
        require(src not in seen,'duplicate source pair');seen.add(src)
        if mode=='byte-identical':
            h=pair['sha256']
            require(digest_file(safe(root,src))==h,'source pin mismatch: '+src)
            require(digest_file(safe(site,pub))==h,'publication pair mismatch: '+pub)
            require(files.get(pub)==h,'pair absent from immutable served inventory: '+pub)
        elif mode=='index-boot-projection':
            allowed={f'chicago/4d/data/sidecars/{y}/index.json':y for y in ['1835','1904']}
            require(src in allowed,'boot projection allowed only for actual scene indexes')
            year=allowed[src];require(pub==f'data/sidecars/{year}/index.json','wrong index published route')
            require(digest_file(safe(root,src))==pair['source_sha256'],'index source raw hash moved')
            require(digest_file(safe(site,pub))==pair['published_sha256'],'index published raw hash moved')
            require(files.get(pub)==pair['published_sha256'],'index missing from immutable inventory')
            source=json.loads(safe(root,src).read_text());published=json.loads(safe(site,pub).read_text())
            expected_boot={'shared':f'sidecars/{year}/boot/shared.json','dir':f'sidecars/{year}/boot/','per_part':50}
            require('boot' not in source,'source unexpectedly already has boot')
            require(published.get('boot')==pair['boot']==expected_boot,'unsupported boot descriptor')
            require({k:v for k,v in published.items() if k!='boot'}==source,'index semantic projection changed')
            count=len(source['structures']);refs={'data/'+expected_boot['shared']}
            refs.update('data/'+expected_boot['dir']+f'part-{i}.json' for i in range((count+49)//50))
            require(set(pair['pack_refs'])==refs,'wrong generated pack reference set')
            for rel,h in pair['pack_refs'].items():
                require(files.get(rel)==h and digest_file(safe(site,rel))==h,'boot pack reference pin moved: '+rel)
        else:raise RuntimeError('unsupported source/publication mode: '+str(mode))
    needed={
      'chicago/4d/renderers/web/js/'+x for x in ['main.js','buildings.js','world.js','shadow-casters.js','driver-draws.js','render-budget.js','parked-transport.js','terrain.js','walker.js','spatial-batch.js','batch-coalesce.js']}
    needed.update('chicago/4d/'+x for x in ['data/scenes/1904.json','data/scenes/1835.json','data/transport/parked/placements.json','data/sidecars/1904/index.json','data/sidecars/1835/index.json','data/terrain/epochs/e1871_postfire/heightfield.json','data/terrain/epochs/e1871_postfire/heightfield.bin','renderers/web/transport/parked-brougham/brougham.json','renderers/web/transport/parked-brougham/brougham-near.glb','renderers/web/transport/parked-brougham/brougham-mid.glb','renderers/web/vendor/three-0.185.1/three.core.js','renderers/web/vendor/three-0.185.1/three.module.js'])
    ids=['2000','2004','2016','2032','2100','2106','2114','2124','2128','2140']
    allids=[]
    for number in ids:
        sid='house_'+number+'_calumet';allids.append(sid)
        if number!='2124':allids.append(sid+'_coach_house')
        if number in ['2032','2140']:allids.append(sid+'_shed')
    require(len(allids)==21,'internal21-ID census error')
    for sid in allids:
        needed.add('chicago/4d/assets/web/'+sid+'__draft_1904.glb')
        needed.add('chicago/4d/data/sidecars/1904/'+sid+'.json')
    require(needed<=seen,'missing mandatory source pairs: '+', '.join(sorted(needed-seen)))
    pinned={p['source_rel']:p.get('sha256',p.get('source_sha256')) for p in pairs}
    require(pinned['chicago/4d/renderers/web/transport/parked-brougham/brougham-mid.glb']=='d6d6709ec4dda73e84a916e71dfb9dba6ad16961423a4f3babebdf58363c20d2','accepted mid bytes changed')
    require(pinned['chicago/4d/renderers/web/transport/parked-brougham/brougham-near.glb']=='ec2bfc0da49b570429dbcd8db39250aa6f1bbf55587570f0dafad9a42afc4ee5','original near bytes changed')
    require(digest_file(safe(site,'build.json'))==b['build_json_sha256'],'build.json moved')
    require(json.loads(safe(site,'build.json').read_text())['version']==b['build_version'],'wrong published build')
    for rel,h in files.items():
        timed();require(digest_file(safe(site,rel))==h,'served file changed: '+rel)
    for rel in ['1904/index.html','walk/index.html','build.json']:
        require(rel in files,'missing normal entry/build pin: '+rel)
    return {'head':b['source_head'],'head_tree':b['source_head_tree'],'staged_index_tree':b['source_tree'],'merge_heads':merge_heads,'status_sha256':b['source_status_porcelain_sha256'],'build_version':b['build_version'],'pairs':len(pairs),'published_files':len(files),'mandatory_pairs':len(needed),'verified_utc':utc()}
def process_snapshot():
    out={}
    for p in pathlib.Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            raw=(p/'stat').read_text();fields=raw[raw.rfind(')')+2:].split()
            out[int(p.name)]=(int(fields[1]),int(fields[19]),fields[0])
        except (OSError,ValueError,IndexError):pass
    return out
def descendants(known):
    snapshot=process_snapshot();changed=True
    while changed:
        changed=False
        for pid,(ppid,start,state) in snapshot.items():
            if ppid in known and pid not in known:
                parent=snapshot.get(ppid)
                if parent and parent[1]==known[ppid]:known[pid]=start;changed=True
    return {pid:start for pid,start in known.items() if pid in snapshot and snapshot[pid][1]==start and snapshot[pid][2]!='Z'}
def stop_owned(known):
    signals=[]
    for sig,seconds in [(signal.SIGTERM,8),(signal.SIGKILL,5)]:
        live=descendants(known)
        for pid,start in live.items():
            try:os.kill(pid,sig);signals.append({'pid':pid,'start_ticks':start,'signal':sig.name})
            except ProcessLookupError:pass
        until=min(DEADLINE,time.monotonic()+seconds)
        while time.monotonic()<until and descendants(known):time.sleep(.1)
    return {'signals':signals,'live_owned_after_cleanup':descendants(known)}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--binding',required=True);parser.add_argument('--out',required=True);args=parser.parse_args()
    out=pathlib.Path(args.out).resolve()
    require(out.is_relative_to(pathlib.Path('/workspace')) or out.is_relative_to(pathlib.Path('/tmp')),'output outside approved external roots')
    require(not out.exists(),'one attempt only: output already exists')
    binding_path=pathlib.Path(args.binding).resolve();raw=binding_path.read_bytes();b=json.loads(raw)
    require(not out.is_relative_to(pathlib.Path(b['source_root']).resolve()),'output must be outside app checkout')
    require(not out.is_relative_to(pathlib.Path(b['site_root']).resolve()),'output must be outside published site')
    out.mkdir(parents=True)
    (out/'BINDING-COPY.json').write_bytes(raw)
    report={'status':'FAIL','started_utc':utc(),'owner_pid':os.getpid(),'binding_sha256':hashlib.sha256(raw).hexdigest(),'implementation_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [HERE/'run_owned.py',HERE/'capture_three_stands.mjs']},'owner_cap_seconds':600,'work_cap_seconds':570,'attempts':1,'automatic_retry':False,'source_mutations':False,'caller_started':False,'browser_started':False}
    child=None;known={};stdout=stderr=None
    try:
        report['preflight']=verify(b);(out/'PREFLIGHT.json').write_text(json.dumps(report['preflight'],indent=2)+'\n')
        timed();env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
        stdout=(out/'caller.stdout').open('wb');stderr=(out/'caller.stderr').open('wb')
        args=['nice','-n','19','node',str(HERE/'capture_three_stands.mjs'),'--binding',str(out/'BINDING-COPY.json'),'--out',str(out),'--work-ms',str(max(1,int((WORK_END-time.monotonic())*1000)))]
        report['command']=args
        child=subprocess.Popen(args,cwd=b['source_root'],stdout=stdout,stderr=stderr,env=env,start_new_session=True)
        report['caller_started']=True;report['caller_pid']=child.pid
        snapshot=process_snapshot();require(child.pid in snapshot,'caller disappeared before ownership pin');known[child.pid]=snapshot[child.pid][1]
        while child.poll() is None:
            descendants(known)
            if time.monotonic()>=WORK_END:raise TimeoutError('570s work deadline; no retry')
            time.sleep(.2)
        report['caller_exit']=child.returncode
        descendants(known)
        require(child.returncode==0,'caller failed; retain raw partial evidence')
        result=json.loads((out/'REPORT.json').read_text());report['caller_verdict']=result.get('status');report['browser_started']=result.get('browser_started',False)
        require(result.get('status')=='PASS','caller did not report whole-unit PASS')
        report['postflight']=verify(b)
        report['status']='PASS'
    except BaseException as exc:
        report['error']=repr(exc)
    finally:
        if child is not None:
            report['owned_processes_observed']=known
            report['owned_cleanup']=stop_owned(known)
            if report['owned_cleanup']['live_owned_after_cleanup']:report['status']='FAIL';report['cleanup_error']='owned processes remain'
            try:child.wait(timeout=max(.1,min(2,DEADLINE-time.monotonic())))
            except subprocess.TimeoutExpired:report['status']='FAIL';report['cleanup_error']='caller did not reap'
            report['caller_exit_after_cleanup']=child.returncode
        for stream in [stdout,stderr]:
            if stream:stream.close()
        if (out/'REPORT.json').is_file():
            try:report['browser_started']=json.loads((out/'REPORT.json').read_text()).get('browser_started',False)
            except (OSError,ValueError):pass
        report['ended_utc']=utc();report['elapsed_seconds']=time.monotonic()-START
        if report['elapsed_seconds']>600:report['status']='FAIL';report['owner_deadline_exceeded']=True
        (out/'OWNER-TERMINAL.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps(report,indent=2))
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':
    def interrupt(signum,frame):raise InterruptedError('owner interrupted by signal '+str(signum))
    signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt)
    sys.exit(main())
