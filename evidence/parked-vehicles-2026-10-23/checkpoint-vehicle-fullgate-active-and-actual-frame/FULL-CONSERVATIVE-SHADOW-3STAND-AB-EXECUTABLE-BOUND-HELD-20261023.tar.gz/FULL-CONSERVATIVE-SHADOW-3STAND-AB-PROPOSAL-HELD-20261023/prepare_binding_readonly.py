"""Metadata only: bind frozen canonical working bytes; never invokes A/B or publisher."""
import pathlib, json, hashlib, subprocess, time

out=pathlib.Path(__file__).resolve().parent
root=pathlib.Path('/tmp/chicago-covered-sag');site=root/'site/4d';start=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
b=json.loads((out/'binding-template.json').read_text())
b['source_head']=git('rev-parse','HEAD').decode().strip()
b['source_head_tree']=git('rev-parse','HEAD^{tree}').decode().strip()
index=git('ls-files','--stage','-z');trie={}
for row in index.split(b'\0'):
    if not row:continue
    meta,name=row.split(b'\t',1);mode,oid,stage=meta.split();assert stage==b'0'
    node=trie;parts=name.split(b'/')
    for part in parts[:-1]:node=node.setdefault(part,{})
    assert parts[-1]not in node
    node[parts[-1]]=(mode,bytes.fromhex(oid.decode()))
def merkle(node):
    body=b''
    for name,val in sorted(node.items(),key=lambda kv:kv[0]+(b'/' if isinstance(kv[1],dict) else b'')):
        mode,oid=(b'40000',merkle(val)) if isinstance(val,dict) else val
        body+=mode+b' '+name+b'\0'+oid
    return hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).digest()
b['source_tree']=merkle(trie).hex()
assert b['source_tree']=='c9cd75af565cec0de09858dc8d69972beeb901b3'
b['source_merge_heads']=git('rev-parse','MERGE_HEAD').decode().splitlines()
b['source_status_porcelain_sha256']=hashlib.sha256(git('status','--porcelain=v1','-z','--untracked-files=all')).hexdigest()
b['build_json_sha256']=sha(site/'build.json')
b['build_version']=json.loads((site/'build.json').read_text())['version']
b['implementation_sha256']={n:sha(out/n) for n in ['run_owned.py','capture_three_stands.mjs']}
b['expected_horse_actor_present_1835']=False
b['playwright_executable']='/usr/bin/chromium'
published={str(p.relative_to(site)):sha(p) for p in sorted(site.rglob('*')) if p.is_file()}
b['published_files']=published;pairs={};mismatches=[];routes=[]
for srcbase,pubbase in [(root/'chicago/4d/renderers/web',site/'walk'),(root/'chicago/4d/data',site/'data'),(root/'chicago/4d/assets/web',site/'data/gltf'),(root/'chicago/4d/assets/humans/web',site/'data/humans/web')]:
    if not srcbase.is_dir():continue
    for src in sorted(srcbase.rglob('*')):
        if not src.is_file():continue
        pub=pubbase/src.relative_to(srcbase)
        if src==root/'chicago/4d/renderers/web/js/changelog.js':
            pub=site/'js/changelog.js'
            routes.append({'source':'chicago/4d/renderers/web/js/changelog.js','published':'js/changelog.js','reason':'normal publisher fleet copy; generated walk re-export independently inventoried'})
        if not pub.is_file():continue
        sr=str(src.relative_to(root));pr=str(pub.relative_to(site));h=sha(src)
        if h==published[pr]:pairs[sr]={'source_rel':sr,'published_rel':pr,'sha256':h}
        else:
            mismatches.append({'source_rel':sr,'published_rel':pr,'source_sha256':h,'published_sha256':published[pr]})
            assert not(sr.startswith('chicago/4d/renderers/web/') and src.suffix in ['.js','.mjs','.glb','.bin']),sr
for year in ['1835','1904']:
    sr=f'chicago/4d/data/sidecars/{year}/index.json';pr=f'data/sidecars/{year}/index.json'
    source=json.loads((root/sr).read_text());pub=json.loads((site/pr).read_text())
    boot={'shared':f'sidecars/{year}/boot/shared.json','dir':f'sidecars/{year}/boot/','per_part':50}
    assert 'boot' not in source and pub['boot']==boot and {k:v for k,v in pub.items() if k!='boot'}==source
    refs={'data/'+boot['shared']}
    refs.update('data/'+boot['dir']+f'part-{i}.json' for i in range((len(source['structures'])+49)//50))
    pairs[sr]={'mode':'index-boot-projection','source_rel':sr,'published_rel':pr,'source_sha256':sha(root/sr),'published_sha256':published[pr],'boot':boot,'pack_refs':{r:published[r] for r in sorted(refs)}}
b['source_pairs']=[pairs[k] for k in sorted(pairs)]
b['note']='Actual read-only binding after canonical publication terminal. Full source remainsOFF; all release flagsFALSE. HEAD0be5/stagedc9cd75/MERGEb7 independently read, no write-tree. Complete published inventory plus exact bytecopy pairs and2strict indexbootprojections. Known other normal publisher transformations listed in BINDING-READONLY-PREPARATION.json are not claimed byte-equal. Authored changelog routes to exact fleet copy; generated re-export independently inventoried. No caller/supervisor/browser run.'
assert all(b[k] is False for k in ['root_browser_release','exclusive_browser_lane_confirmed','canonical_publication_terminal_confirmed'])
assert hashlib.sha256(index).hexdigest()==hashlib.sha256(git('ls-files','--stage','-z')).hexdigest()
assert b['source_status_porcelain_sha256']==hashlib.sha256(git('status','--porcelain=v1','-z','--untracked-files=all')).hexdigest()
(out/'ACTUAL-C9CD75-PUBLISHED-BINDING-HELD.json').write_text(json.dumps(b,indent=2)+'\n')
proof={'status':'READONLY_BINDING_PREPARED_NOT_CALLER_EXECUTION','source_head':b['source_head'],'source_head_tree':b['source_head_tree'],'source_staged_tree':b['source_tree'],'source_merge_heads':b['source_merge_heads'],'index_bytes_sha256':hashlib.sha256(index).hexdigest(),'source_status_porcelain_sha256':b['source_status_porcelain_sha256'],'published_build':json.loads((site/'build.json').read_text()),'published_inventory_files':len(published),'source_pairs':len(pairs),'byte_identical_pairs':sum(p.get('mode','byte-identical')=='byte-identical' for p in pairs.values()),'exact_boot_projection_pairs':2,'normal_route_overrides':routes,'observed_non_bytecopy_candidates':mismatches,'reviewed_runtime_code_glb_binary_mismatch_count':0,'implementation_sha256':b['implementation_sha256'],'binding_sha256':sha(out/'ACTUAL-C9CD75-PUBLISHED-BINDING-HELD.json'),'release_flags_all_false':True,'elapsed_seconds':time.monotonic()-start,'caller_executed':False,'supervisor_executed':False,'browser_executed':False,'syntax_or_test_execution':False,'source_app_writes':False}
(out/'BINDING-READONLY-PREPARATION.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items() if k!='observed_non_bytecopy_candidates'},indent=2))
print('non-bytecopy-candidates',len(mismatches))
