| Asset | License | Provenance |
| --- | --- | --- |
| `authored/transport/wagon_parked_fine_wood/ATTRIBUTION.txt` | GPL-3.0-or-later | Original project attribution text identifying the separately licensed CC0 texture maps and their transformations. |
| `authored/transport/wagon_parked_fine_wood/surface.json` | GPL-3.0-or-later (project binding and charts); CC0-1.0 (texture derivatives) | Original project UV/tangent/index binding; Fine Grained Wood maps by Rob Tuytel / Poly Haven and original CC0 paint, iron and cut-end pixels, as documented above and in SOURCE.json. |
| `authored/transport/wagon_parked_fine_wood/surface.bin` | GPL-3.0-or-later (project charts); CC0-1.0 (texture pixels) | Original project chart streams and documented CC0 texture derivatives; no third-party geometry. |

