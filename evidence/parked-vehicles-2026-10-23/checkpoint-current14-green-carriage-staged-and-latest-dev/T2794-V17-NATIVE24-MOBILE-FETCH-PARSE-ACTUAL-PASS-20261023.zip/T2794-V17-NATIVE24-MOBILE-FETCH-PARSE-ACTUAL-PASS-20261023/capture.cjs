const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
const ROOT=__dirname,OUT=path.join(ROOT,'actual'),port=Number(process.argv[2]);
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),need=(v,m)=>{if(!v)throw Error(m)};
need(fs.existsSync(path.join(ROOT,'RUN-INTENT.json')),'Released once-only owner required');fs.mkdirSync(OUT);
const result={scope:'Four mobile-only forced-near/mid isolated paired frames at23.99/24.01m; exact candidate runtime selector and ordinary1904world renderer/lighting, source-catalogue direction. Not current world, GPU-budget, half-pixel or photographic acceptance.',started:new Date().toISOString(),pass:false,rows:[],attemptedRows:[],errors:[],disposal:[],browserClosed:false,expectedImages:4};
result.networkLifecycle=[];let phase='before-launch';const event=(kind,data={})=>{result.networkLifecycle.push({utc:new Date().toISOString(),phase,kind,...data})};
const save=()=>fs.writeFileSync(path.join(OUT,'receipt.json'),JSON.stringify(result,null,2)+'\n');let browser,context,page;
const watchdog=setTimeout(()=>{result.error='Original165second browser deadline';save();browser?.close().finally(()=>process.exit(124))},165000);
(async()=>{try{
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox'],timeout:15000});
 for(const [profile,width,height,dpr,touch]of[['mobile',390,780,2,true]]){
  phase='new-mobile-context';event('phase');context=await browser.newContext({viewport:{width,height},deviceScaleFactor:dpr,hasTouch:touch});page=await context.newPage();
  const cdp=await context.newCDPSession(page),requestsById=new Map();await cdp.send('Network.enable');
  cdp.on('Network.requestWillBeSent',e=>{requestsById.set(e.requestId,e.request.url);if(e.request.url.includes('brougham-'))event('CDP-request',{id:e.requestId,url:e.request.url,timestamp:e.timestamp,wallTime:e.wallTime,initiator:e.initiator,type:e.type,documentURL:e.documentURL})});
  cdp.on('Network.responseReceived',e=>{const url=requestsById.get(e.requestId);if(url?.includes('brougham-'))event('CDP-response',{id:e.requestId,url,timestamp:e.timestamp,status:e.response.status,fromDiskCache:e.response.fromDiskCache,fromServiceWorker:e.response.fromServiceWorker,protocol:e.response.protocol})});
  cdp.on('Network.loadingFinished',e=>{const url=requestsById.get(e.requestId);if(url?.includes('brougham-'))event('CDP-finished',{id:e.requestId,url,timestamp:e.timestamp,encodedDataLength:e.encodedDataLength})});
  cdp.on('Network.loadingFailed',e=>{event('CDP-failed',{...e,url:requestsById.get(e.requestId)??null})});
  page.on('framenavigated',f=>event('frame-navigated',{url:f.url(),mainFrame:f===page.mainFrame()}));page.on('domcontentloaded',()=>event('DOM-ready'));page.on('load',()=>event('page-load'));page.on('close',()=>event('page-close'));
  page.on('requestfailed',r=>event('Playwright-failed',{url:r.url(),resourceType:r.resourceType(),navigation:r.isNavigationRequest(),failure:r.failure(),timing:r.timing()}));
  const note=(kind,message)=>{result.errors.push({profile,kind,message});save()};page.on('pageerror',e=>note('page',e.message));page.on('console',m=>{if(m.type()==='error')note('console',m.text())});page.on('requestfailed',r=>note('request',r.url()+':'+r.failure()?.errorText));page.on('response',r=>{if(r.status()>=400)note('http',r.status()+' '+r.url())});
  await page.route('**/*',r=>{const u=new URL(r.request().url());return ['data:','blob:'].includes(u.protocol)||(u.protocol==='http:'&&u.hostname==='127.0.0.1'&&u.port===String(port))?r.continue():r.abort('blockedbyclient')});
  phase='initial-mobile-goto';event('phase');await page.goto(`http://127.0.0.1:${port}/?profile=${profile}`,{waitUntil:'load',timeout:20000});await page.waitForFunction(()=>window.nativeComparisonReady&&document.querySelector('aside img').complete,null,{timeout:25000});
  phase='native-ready-after-runtime-and-duplicate-witness';event('phase');const inputs=await page.evaluate(()=>window.nativeInputHashes);
  need(inputs['transport/parked-brougham/brougham-near.glb']==='ec2bfc0da49b570429dbcd8db39250aa6f1bbf55587570f0dafad9a42afc4ee5','Exact original near');need(inputs['transport/parked-brougham/brougham-mid.glb']==='29a7feaa7aa660f31fbf53fecdc555526935a0d69fb59e39f6c427b644860282','Exact genuine mid');need(inputs['plate0095.jpg']==='b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe','Exact source plate');
  event('actual-native-input-hashes',{inputs});for(const distance of[23.99,24.01]){
   phase='set-distance-'+distance;event('phase');
   const selection=await page.evaluate(d=>setNativeDistance(d),distance);need(selection.selected===(distance<24?'near':'mid')&&selection.threshold===24&&selection.hysteresis===.05,'Actual frozen transition selection');
   let binding=null;
   for(const detail of['near','mid']){
    phase='render-'+distance+'-'+detail;event('phase');const row=await page.evaluate(d=>renderNativeLevel(d),detail);result.attemptedRows.push(row);save();
    if(binding)for(const field of['camera','renderer','world','viewport','drawingBuffer','modelBounds'])need(JSON.stringify(binding[field])===JSON.stringify(row[field]),'Forced near/mid pair changes '+field);else binding=row;
    need(row.actualGeometryTriangles===(detail==='near'?33502:22238)&&row.mergedMaterialBatches===7,'Actual merged native geometry count');need(row.confidenceEnabled===false&&!Object.values(row.hidden).some(Boolean),'Ordinary Normal confidence');need(row.renderer.exposure===.95&&row.renderer.shadowEnabled&&row.camera.fov===(profile==='desktop'?55:94),'Ordinary app world/lens settings');need(row.pixelRatio===1&&row.drawingBuffer[0]===width&&row.drawingBuffer[1]===height,'Actual ordinary render sampling');need(row.ndcMin.every(x=>x>=-1)&&row.ndcMax.every(x=>x<=1),'Whole unchanged model/pole inside fixed camera');need(row.glError===0&&row.problems.length===0&&result.errors.length===0,'Actual runtime errors');
    phase='screenshot-'+distance+'-'+detail;event('phase');const png=`${profile}-${distance.toFixed(2)}m-forced-${detail}.png`;await page.screenshot({path:path.join(OUT,png),timeout:15000});result.rows.push({...row,png,image_sha256:hash(path.join(OUT,png)),normalBrowserScreenshot:true});save();
   }
   await page.evaluate(()=>finishNativePair());
  }
  phase='successful-profile-disposal';event('phase');const disposal=await page.evaluate(()=>disposeNativeComparison());result.disposal.push({profile,...disposal});save();need(disposal.expectedMergedGeometries===disposal.mergedGeometryDisposeEvents&&disposal.remainingGeometries===0&&disposal.remainingTextures===0&&disposal.sceneChildren===0&&disposal.dfg.every(x=>x.liveBefore&&!x.liveAfter),'Actual owned resource disposal');
  phase='successful-context-close';event('phase');await context.close();context=null;page=null;
 }
 need(result.rows.length===4&&result.disposal.length===1&&result.errors.length===0,'Four-frame mobile native completeness');result.pass=true;
}catch(error){event('caught-failure',{error:String(error)});result.error=String(error.stack||error);process.exitCode=1}finally{
 phase='finally-cleanup';event('phase');clearTimeout(watchdog);if(page&&!page.isClosed()){try{result.disposal.push({profile:'failure-finally',...await page.evaluate(()=>disposeNativeComparison())})}catch(error){result.disposal.push({profile:'failure-finally',error:String(error)})}}if(context)await context.close().catch(()=>{});if(browser){await browser.close();result.browserClosed=!browser.isConnected()}result.finished=new Date().toISOString();save();
}if(!result.pass)throw Error(result.error);console.log('PASS4mobile-native near/mid transition images; actual browser closed; world/photo acceptance remains open.');})().catch(e=>{console.error(e);process.exitCode=1});
