"""Independent saved-byte readback of the one emitted candidate; no generation."""
from pathlib import Path
import hashlib,io,json,struct
import numpy as np
from PIL import Image
OUT=Path('/workspace/shared/T2793-W01-POLYHAVEN-V3B-HELD-20261023');PARENT=Path('/workspace/shared/w01-oldcart-material-transfer-v1-HELD-20261022/candidate-normalized/wagon-w01.glb');BASE=Path('/tmp/chicago-covered-sag/chicago/4d/renderers/web/transport/parked-wagon/wagon-w01.glb')
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def unpack(path):
 raw=path.read_bytes();n=struct.unpack_from('<I',raw,12)[0];return raw,json.loads(raw[20:20+n]),raw[28+n:]
def image(g,b,i):
 v=g['bufferViews'][g['images'][i]['bufferView']];return b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
def array(g,b,ai):
 a=g['accessors'][ai];v=g['bufferViews'][a['bufferView']];C={5126:'<f4',5125:'<u4'}[a['componentType']];dim={'VEC2':2,'VEC3':3,'VEC4':4,'SCALAR':1}[a['type']];return np.frombuffer(b,dtype=C,count=a['count']*dim,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,dim)
r={'status':'RUNNING','scope':'Saved-byte/map/hierarchy/topology readback; no browser, rendering or new candidate'}
try:
 raw,g,b=unpack(OUT/'wagon-w01.glb');old,og,ob=unpack(PARENT);original,bg,bb=unpack(BASE)
 need(sha(raw)=='30af3da5d0ad40854b30ece08317f3b81ff0ceff76908062cb0fd01be24f37b7','Candidate pin');need(sha(old)=='da5df4b37ce6830af04f055453f6cb11890be29b3b28e9f4bd31a26bd3ff86ec','Parent pin');need(sha(original)=='274e737b51872983df792d0b24de8e75de8631890a8d586a32d9c6f0066484fb','Original pin')
 for key in ['meshes','accessors','nodes','skins','animations','scene','scenes','textures','samplers']:need(g.get(key)==og.get(key),'Changed protected '+key)
 need(b[:len(ob)]==ob,'Parent binary prefix differs');triangles=0;faceHash=hashlib.sha256()
 for mesh,baseMesh in zip(g['meshes'],bg['meshes']):
  ids=[];basePrimitive=baseMesh['primitives'][0];N=bg['accessors'][basePrimitive['attributes']['POSITION']]['count']
  for p in mesh['primitives']:
   for name in ('POSITION','NORMAL'):need(np.array_equal(array(g,b,p['attributes'][name]),array(bg,bb,basePrimitive['attributes'][name])),'Original oriented attributes differ')
   for name,ai in p['attributes'].items():need(np.isfinite(array(g,b,ai)).all(),'Nonfinite '+name)
   group=array(g,b,p['indices']).reshape(-1)if'indices'in p else np.arange(g['accessors'][p['attributes']['POSITION']]['count']);need(len(group)%3==0 and all(group[k+1]==group[k]+1 and group[k+2]==group[k]+2 for k in range(0,len(group),3)),'Changed oriented corners');ids.extend(group.tolist());triangles+=len(group)//3
  need(sorted(ids)==list(range(N)),'Original face missing/duplicated');faceHash.update(array(bg,bb,basePrimitive['attributes']['POSITION']).tobytes());faceHash.update(array(bg,bb,basePrimitive['attributes']['NORMAL']).tobytes())
 for mi in range(len(g['materials'])):need({k:v for k,v in g['materials'][mi].items()if k!='extras'}=={k:v for k,v in og['materials'][mi].items()if k!='extras'},'Changed factor/map/normal-scale '+str(mi))
 for i in range(3,len(g['images'])):need(image(g,b,i)==image(og,ob,i),'Changed paint/iron/cutend')
 need(all(g['materials'][i]==og['materials'][i]for i in (0,4,5,6,7,8)),'Protected material differs');dims=[];cost=0
 for i in range(len(g['images'])):
  im=Image.open(io.BytesIO(image(g,b,i)));w,h=im.size;dim=[w,h];mip=0
  while True:
   mip+=w*h*4
   if(w,h)==(1,1):break
   w=max(1,w//2);h=max(1,h//2)
  dims.append({'image':i,'pixels':dim,'RGBA8_all_mips_dimension_bytes':mip});cost+=mip
 for kind,ii in [('color',0),('normal',1),('orm',2)]:need(image(g,b,ii)==(OUT/'textures'/('polyhaven_timber_'+kind+'.png')).read_bytes(),'Embedded map differs '+kind);need(dims[ii]['pixels']==[1024,240],'Unexpected side size')
 need(triangles==12104 and cost==6291168,'Triangle/memory count differs')
 r.update(status='ACTUAL_V3B_SAVED_SOURCE_AND_SIDE_ONLY_READBACK_PASS_UNRENDERED',candidate_sha256=sha(raw),triangles=triangles,source_meshes=len(g['meshes']),source_primitives=sum(len(m['primitives'])for m in g['meshes']),all_original_oriented_positions_normals_exact=True,base_original_per_mesh_PN_array_hash=faceHash.hexdigest(),all_V1_UV_tangents_topology_pivots_and_material_ownership_exact=True,green_paint_iron_painted_hubs_and_existing_endgrain_exact=True,referenced_materials=len({p['material']for m in g['meshes']for p in m['primitives']}),same_material_grouping_as_prior_actual_V1_8batch_readback=True,active_images=len(g['images']),RGBA8_all_mips_dimension_estimate=cost,images=dims,legacy_oldcart_binary_unreferenced_but_credited=True,no_new_normal_from_albedo=True)
except Exception as e:r.update(status='ACTUAL_V3B_READBACK_FAIL',error=repr(e));raise
finally:(OUT/'ACTUAL-INDEPENDENT-READBACK.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='images'},indent=2))
