"""GPL-3.0-or-later: ONE external W01 side-timber material candidate.

Modern Poly Haven fine_grained_wood optical analogy, not period/maker evidence.
Only three side-timber image bindings and honest material metadata change.
Geometry, UV/tangents, normal scale, paint, iron, cut ends and pivots stay exact.
"""
from pathlib import Path
import copy,hashlib,io,json,struct,time
import numpy as np
from PIL import Image
SOURCE=Path('/workspace/shared/T2793-POLYHAVEN-ONE-WOOD-SOURCE-REVIEW-20261023')
PARENT=Path('/workspace/shared/w01-oldcart-material-transfer-v1-HELD-20261022/candidate-normalized/wagon-w01.glb')
BASE=Path('/tmp/chicago-covered-sag/chicago/4d/renderers/web/transport/parked-wagon/wagon-w01.glb')
OUT=Path('/workspace/shared/T2793-W01-POLYHAVEN-V3B-HELD-20261023')
PARENT_SHA='da5df4b37ce6830af04f055453f6cb11890be29b3b28e9f4bd31a26bd3ff86ec'
BASE_SHA='274e737b51872983df792d0b24de8e75de8631890a8d586a32d9c6f0066484fb'
CROP=[0,784,2048,1264] # After90CCW rotation: full source grain length,480native cross-grain rows.
DOWNSAMPLE=4
SIZE=[1024,240] #512x120 unique output samples, reflected once in U/V.
def need(ok,message):
 if not ok:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def unpack(raw):
 need(struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw)),'Exact GLB2 envelope');n=struct.unpack_from('<I',raw,12)[0];return json.loads(raw[20:20+n]),raw[28+n:]
def img(g,b,i):
 v=g['bufferViews'][g['images'][i]['bufferView']];return b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
def from_srgb(a):return np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
def to_srgb(a):return np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055)
def mirror(a,normal=False):
 other=a[:,::-1].copy()
 if normal:other[:,:,0]*=-1
 row=np.concatenate([a,other],axis=1);other=row[::-1].copy()
 if normal:other[:,:,1]*=-1
 return np.concatenate([row,other],axis=0)
def box4(a):return a.reshape(120,4,512,4,a.shape[2]).mean(axis=(1,3))
def normalize(a):return a/np.maximum(np.linalg.norm(a,axis=2,keepdims=True),1e-10)
def png(a):
 f=io.BytesIO();Image.fromarray(a.astype('uint8')).save(f,format='PNG',compress_level=6);return f.getvalue()
def main():
 started=time.monotonic();need(not OUT.exists(),'Fresh single candidate only');OUT.mkdir();(OUT/'textures').mkdir();r={'status':'RUNNING','actual_generation_count':1,'routine_fixed_normalization_correction_from':'V3 pre-output clipping FAIL preserved unchanged','app_modified':False,'browser_GPU_run':False}
 try:
  parent=PARENT.read_bytes();baseline=BASE.read_bytes();need(sha(parent)==PARENT_SHA and sha(baseline)==BASE_SHA,'Frozen source pin mismatch');g,b=unpack(parent);original=copy.deepcopy(g);bg,bb=unpack(baseline);binary=bytearray(b)
  files=json.loads((SOURCE/'fine_grained_wood-files.json').read_text());info=json.loads((SOURCE/'fine_grained_wood-info.json').read_text());need(info['authors']=={'Rob Tuytel':'All'}and info['max_resolution']==[8192,8192],'Chosen family metadata changed')
  # Explicit asset-page licence and official policy, not inference from filename.
  page=(SOURCE/'fine_grained_wood-official-asset-page.html').read_text();need('https://creativecommons.org/publicdomain/zero/1.0/'in page and 'Rob Tuytel'in page,'Asset-specific CC0/creator proof missing')
  crops={};source_pins={}
  for role,key,name in [('color','Diffuse','col'),('normal','nor_gl','nor_gl'),('roughness','Rough','rough')]:
   p=SOURCE/('fine_grained_wood_'+name+'_2k.png');raw=p.read_bytes();expected=files[key]['2k']['png'];need(len(raw)==expected['size']and hashlib.md5(raw).hexdigest()==expected['md5'],'Official map mismatch '+role)
   image=np.asarray(Image.open(io.BytesIO(raw)).convert('RGB'));need(image.shape==(2048,2048,3),'Native2K map dimensions changed');rotated=np.rot90(image);x0,y0,x1,y1=CROP;crops[role]=rotated[y0:y1,x0:x1].copy();need(crops[role].shape==(480,2048,3),'Declared native crop changed');source_pins[role]={'file':str(p),'sha256':sha(raw),'official_md5':expected['md5'],'bytes':len(raw),'native_pixels':[2048,2048],'url':expected['url']}
  need(sum(x['bytes']for x in source_pins.values())<=40000000,'40MB source budget exceeded')
  # Preserve original reconstructed neutral map palette, not donor dark varnish.
  base=np.asarray(Image.open(io.BytesIO(img(bg,bb,0))).convert('RGB'),dtype=np.float32)/255;target=from_srgb(base)@np.array([.2126,.7152,.0722],dtype=np.float32);target_mean=float(target.mean());target_std=float(target.std())
  source_linear=from_srgb(crops['color'].astype(np.float32)/255);luma=box4(source_linear)@np.array([.2126,.7152,.0722],dtype=np.float32);luma=luma.astype(np.float64);residual=luma-float(luma.mean());desired_scale=target_std/max(float(luma.std()),1e-12)
  # Largest shared affine contrast within every channel's bounds. Grayscale
  # residual is shared by all3map channels; original colored factors stay exact.
  # One representable inward step keeps the original strict no-clipping guard
  # valid at IEEE754 boundary rounding, without clipping a source pixel.
  lower=np.nextafter(0.,1.);upper=np.nextafter(1.,0.);lower_scale=(target_mean-lower)/max(float(-residual.min()),1e-12);upper_scale=(upper-target_mean)/max(float(residual.max()),1e-12);shared_scale=float(np.nextafter(min(desired_scale,lower_scale,upper_scale),0.));neutral=target_mean+residual*shared_scale
  need(float(neutral.min())>0 and float(neutral.max())<1,'Fixed palette transform would clip; no tuning retry');color=np.repeat(neutral[:,:,None],3,axis=2);color=np.rint(to_srgb(mirror(color))*255).astype('uint8')
  # Real official GL normal, spatial90CCW and matching tangent-vector rotation.
  # No albedo-derived height/normal or increased normal strength.
  normal=normalize(crops['normal'].astype(np.float32)/127.5-1);normal=normal[:,:,[1,0,2]]*np.array([1,-1,1],dtype=np.float32);normal=normalize(box4(normal));normal=normalize(mirror(normal,True));normal=np.rint((normal*.5+.5)*255).astype('uint8')
  rough=box4(crops['roughness'].astype(np.float32)/255)[:,:,0];centered=rough-float(rough.mean());rough_scale=min(1.,.14/max(float(centered.max()),1e-12),.24/max(float(-centered.min()),1e-12));rough=.84+centered*rough_scale;orm=np.stack([np.ones_like(rough),rough,np.zeros_like(rough)],axis=2);orm=np.rint(mirror(orm)*255).astype('uint8')
  maps={'color':color,'normal':normal,'orm':orm};map_receipts={}
  for name,a in maps.items():
   need(a.shape==(240,1024,3),'Output dimensions differ from fixed memory plan');data=png(a);(OUT/'textures'/('polyhaven_timber_'+name+'.png')).write_bytes(data);binary.extend(b'\0'*((-len(binary))%4));vi=len(g['bufferViews']);g['bufferViews'].append({'buffer':0,'byteOffset':len(binary),'byteLength':len(data)});binary.extend(data)
   field='normalTexture'if name=='normal'else'baseColorTexture'if name=='color'else'metallicRoughnessTexture';holder=g['materials'][1]if name=='normal'else g['materials'][1]['pbrMetallicRoughness'];ii=g['textures'][holder[field]['index']]['source'];need(ii in (0,1,2),'Only side timber images may change');g['images'][ii]={'bufferView':vi,'mimeType':'image/png'};map_receipts[name]={'image_index':ii,'sha256':sha(data),'bytes':len(data),'pixels':SIZE}
  for mi in (1,2,3):
   g['materials'][mi]['extras']={'grade':'reconstructed unmeasured optical finish; photographic/world acceptance OPEN','active_pixel_source':'Poly Haven fine_grained_wood by Rob Tuytel, CC0-1.0','changes':'Native2K crop,4x box reduction,90CCW spatial/normal rotation, periodic reflection and normal sign correction; neutral original palette and reconstructed roughness mean retained','normal_scale':.35,'historical_identity':'No1835wood species/varnish/date/maker/Chicago specimen asserted','legacy_binary_notice':'Unreferenced OldCart CC-BY4.0 bytes retained in frozen V1 prefix; original credit preserved separately in asset copyright'}
  legacy_credit=original['asset'].get('copyright','');g['asset']['copyright']='Active side timber: Fine Grained Wood by Rob Tuytel / Poly Haven, https://polyhaven.com/a/fine_grained_wood , CC0-1.0 https://creativecommons.org/publicdomain/zero/1.0/ . Changes: native2K crop/reduction, spatial/tangent-normal rotation and reflection, neutral palette and roughness adjustment. No measured period finish/species/maker/date. Original W01 geometry/charts GPL-3.0-or-later; original paint/iron/cut-end pixels CC0-1.0. Legacy UNREFERENCED frozen V1 binary content retains this credit: '+legacy_credit
  if'material_study'in g['extras']:g['extras']['material_study']['images']='Active side timber is adapted CC0 Poly Haven fine_grained_wood; original CC0 paint/iron/cut ends. Original GPL UV/tangents/geometry unchanged. Modern optical analogy, no measured period finish.'
  g['extras']['timber_surface_candidate_legacy']=g['extras'].get('timber_surface_candidate');g['extras']['timber_surface_candidate']={'scope':'HELD source-only V3; actual native/world/photographic acceptance OPEN','source_asset':'fine_grained_wood','source_author':'Rob Tuytel','source_license':'CC0-1.0','source_metadata_physical_scale':'Unresolved API scale30x30CM versus dimensions600; not used as measured calibration','parent_sha256':PARENT_SHA,'original_geometry_sha256':BASE_SHA,'maps_native_input_pixels':[2048,2048],'rotated_native_crop':CROP,'downsample_factor':4,'output_pixels':SIZE,'unique_downsampled_pixels':[512,120],'periodic_reflection':'U/V eachonce with tangent-normal component sign changes','normal_height_from_albedo':False,'original_palette_target_linear_mean':target_mean,'original_palette_target_linear_std_upper_bound':target_std,'contrast_bounds':{'desired_std_scale':desired_scale,'lower_bound_scale':lower_scale,'upper_bound_scale':upper_scale,'largest_shared_safe_scale':shared_scale,'IEEE754_inward_rounding':'nextafter from channel bounds and final scale, toward safe interior; no pixel clipping','actual_unquantized_std':float(neutral.std()),'unquantized_minmax':[float(neutral.min()),float(neutral.max())]},'roughness_target_mean':.84,'no_active_OldCart_maps':True,'legacy_unreferenced_OldCart_bytes_attributed':True,'all_geometry_pivots_paint_iron_cutends_variants_unchanged':True}
  for key in ('meshes','accessors','nodes','skins','animations','scene','scenes','textures','samplers'):need(g.get(key)==original.get(key),'Protected field changed '+key)
  for mi in (0,4,5,6,7,8):need(g['materials'][mi]==original['materials'][mi],'Protected paint/iron/end material changed')
  for mi in (1,2,3):need({k:v for k,v in g['materials'][mi].items()if k!='extras'}=={k:v for k,v in original['materials'][mi].items()if k!='extras'},'Original timber factors/normal scale/bindings changed')
  for i in range(3,len(g['images'])):need(g['images'][i]==original['images'][i]and img(g,binary,i)==img(original,b,i),'Paint/iron/end image changed')
  need(binary[:len(b)]==b,'V1 geometry binary prefix changed');binary.extend(b'\0'*((-len(binary))%4));g['buffers'][0]['byteLength']=len(binary);header=json.dumps(g,separators=(',',':')).encode();header+=b' '*((-len(header))%4);raw=struct.pack('<III',0x46546c67,2,28+len(header)+len(binary))+struct.pack('<II',len(header),0x4e4f534a)+header+struct.pack('<II',len(binary),0x004e4942)+binary;(OUT/'wagon-w01.glb').write_bytes(raw);(OUT/'ATTRIBUTION.txt').write_text(g['asset']['copyright']+'\n')
  decoded=[]
  for i in range(len(g['images'])):
   im=Image.open(io.BytesIO(img(g,binary,i)));w,h=im.size;cost=0
   while True:
    cost+=w*h*4
    if w==h==1:break
    w=max(1,w//2);h=max(1,h//2)
   decoded.append({'image':i,'pixels':list(im.size),'RGBA8_mips_dimension_bytes':cost})
  actual_mean=float(from_srgb(color.astype(float)/255).mean());actual_std=float((from_srgb(color.astype(float)/255)@np.array([.2126,.7152,.0722])).std());need(abs(actual_mean-target_mean)<.002 and actual_std<=target_std+.002,'Serialized palette mean/contrast upper bound differs from original target')
  normal_error=float(np.abs(np.linalg.norm(normal.astype(float)/127.5-1,axis=2)-1).max());need(normal_error<.01,'Serialized official normal is not unit length')
  r.update(status='ACTUAL_FIXED_V3_SIDE_MATERIAL_STRUCTURE_PASS_UNRENDERED',candidate_sha256=sha(raw),candidate_bytes=len(raw),parent_sha256=PARENT_SHA,baseline_sha256=BASE_SHA,source_pins=source_pins,source_maps_download_bytes=sum(x['bytes']for x in source_pins.values()),source_changes=g['extras']['timber_surface_candidate'],map_receipts=map_receipts,all_geometry_UV_tangents_pivots_paint_iron_cutends_exact=True,source_primitives=31,source_material_definitions=9,referenced_materials=8,active_map_images=12,decoded_images=decoded,RGBA8_all_mips_dimension_estimate=sum(x['RGBA8_mips_dimension_bytes']for x in decoded),normal_length_max_error=normal_error,normal_scale_unchanged=.35,actual_serialized_linear_color_mean=actual_mean,actual_serialized_linear_color_std=actual_std,roughness_additive_scale=rough_scale,roughness_serialized_mean=float(orm[:,:,1].mean()/255),no_albedo_height_or_normal_derivation=True,elapsed_seconds=time.monotonic()-started)
 except Exception as e:r.update(status='ACTUAL_V3_CANDIDATE_FAIL',error=repr(e),elapsed_seconds=time.monotonic()-started)
 finally:(OUT/'ACTUAL-RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k not in ('source_pins','map_receipts','decoded_images','source_changes')},indent=2))
 return 0 if r['status']=='ACTUAL_FIXED_V3_SIDE_MATERIAL_STRUCTURE_PASS_UNRENDERED'else 2
if __name__=='__main__':raise SystemExit(main())
