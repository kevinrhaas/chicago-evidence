"""One root-released GET-only watch, at most one poll/minute; no CI mutations."""
from pathlib import Path
import concurrent.futures, datetime, json, os, subprocess, time

OUT = Path('/workspace/shared/PR1175-SCOPED-LAP-39880078603-GET-owner1')
OLD = '3f73940923d6cd1883334e7170e1b5e78245a7c6'
URLS = {'run': 'repos/kevinrhaas/chicago/actions/runs/39880078603',
        'jobs': 'repos/kevinrhaas/chicago/actions/runs/39880078603/jobs?filter=all&per_page=100',
        'pr': 'repos/kevinrhaas/chicago/pulls/1175',
        'branch': 'repos/kevinrhaas/chicago/git/ref/heads/steward/1835-workwear-repair-20261021'}

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def get(item):
    key, endpoint = item
    r = subprocess.run(['gh', 'api', endpoint], capture_output=True, timeout=45)
    if r.returncode:
        return key, {'GET_error_exit': r.returncode, 'stderr': r.stderr.decode(errors='replace'), 'body': r.stdout.decode(errors='replace')}
    return key, json.loads(r.stdout)

def main():
    OUT.mkdir(exist_ok=False)
    owner = {'status': 'SOLE_GET_ONLY_OWNER', 'pid': os.getpid(), 'started_utc': utc(),
             'run_id': 39880078603, 'job_id_not_guessed': True, 'interval_seconds': 60,
             'maximum_seconds': 7200, 'CI_mutations': False, 'automatic_retries': 0}
    (OUT / 'OWNER.json').write_text(json.dumps(owner, indent=2) + '\n')
    print(json.dumps(owner), flush=True)
    start = time.monotonic()
    for poll in range(120):
        at = time.monotonic()
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            raw = dict(pool.map(get, URLS.items()))
        snapshot = {'observed_utc': utc(), 'poll': poll, 'raw': raw}
        (OUT / ('POLL-%03d.json' % poll)).write_text(json.dumps(snapshot, indent=2) + '\n')
        if any('GET_error_exit' in value for value in raw.values()):
            result = {'status': 'STOPPED_GET_ERROR_NO_RETRY', 'observed_utc': utc(), 'poll': poll}
        else:
            assert raw['run']['id'] == 39880078603
            assert raw['run']['event']=='workflow_dispatch' and raw['run']['run_attempt']==1
            assert raw['run']['path']=='.github/workflows/chicago-4d-pr-lap.yml'
            assert raw['run']['head_sha']=='b6eb3e5fee325dc8c65380afa1f1d1b6c7985a59'
            assert raw['pr']['head']['ref'] == 'steward/1835-workwear-repair-20261021'
            assert raw['pr']['head']['repo']['full_name'] == 'kevinrhaas/chicago'
            branch = raw['branch']['object']['sha']; pr_head = raw['pr']['head']['sha']
            result = {'status': 'RUNNING_GET_ONLY', 'observed_utc': snapshot['observed_utc'],
                      'branch_head': branch, 'pr_head': pr_head,
                      'run_status': raw['run']['status'], 'run_conclusion': raw['run']['conclusion'],
                      'jobs': [{'id': j['id'], 'status': j['status'], 'conclusion': j['conclusion'],
                                'active_steps': [s['name'] for s in j['steps'] if s['status'] == 'in_progress']}
                               for j in raw['jobs']['jobs']],
                      'PR_ready_or_merge_qualification': False}
            if branch != OLD or pr_head != OLD:
                result['status'] = 'ACTUAL_SOURCE_HEAD_CHANGED_STOP_FOR_ROOT'
                result['last_push_proven'] = raw['run']['status'] == 'completed'
                actual_new=branch if branch!=OLD else pr_head
                _,commit=get(('commit','repos/kevinrhaas/chicago/git/commits/'+actual_new))
                (OUT/'ACTUAL-NEW-SOURCE-COMMIT.json').write_text(json.dumps(commit,indent=2)+'\n')
                result['actual_new_source']={k:commit.get(k)for k in ['sha','tree','parents']}
                result['branch_PR_head_agree']=branch==pr_head
            elif raw['run']['status'] == 'completed':
                result['status'] = 'ACTUAL_LAP_TERMINAL_WITHOUT_HEAD_CHANGE'
        (OUT / 'LATEST.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result), flush=True)
        if result['status'] != 'RUNNING_GET_ONLY':
            (OUT / 'TERMINAL.json').write_text(json.dumps(result, indent=2) + '\n')
            return
        remaining = 60 - (time.monotonic() - at)
        if remaining > 0: time.sleep(remaining)
    terminal = {'status': 'BOUNDED_OBSERVATION_DEADLINE_NO_RETRY', 'observed_utc': utc(), 'elapsed_seconds': time.monotonic() - start}
    (OUT / 'TERMINAL.json').write_text(json.dumps(terminal, indent=2) + '\n')
    print(json.dumps(terminal), flush=True)

if __name__ == '__main__': main()
