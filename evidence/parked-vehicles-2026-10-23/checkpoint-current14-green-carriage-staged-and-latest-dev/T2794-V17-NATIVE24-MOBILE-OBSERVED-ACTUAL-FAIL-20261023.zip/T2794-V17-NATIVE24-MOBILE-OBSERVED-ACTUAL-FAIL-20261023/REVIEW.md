# Observed mobile native4 actualFAIL

The unchanged source/CDP-observed unit closed1 after6.489seconds,0images. Runtime near request2044334.27, initiatedbyFileLoader→GLTFLoader→parked-transport, received200thenERR_ABORTED at00:12:24.313UTC. This precedesmidrequest.28(24.327),duplicatewitnessrequests.30/.31(24.381),ready(24.405),distance/render(24.407/.410),caughtfailureandcleanup(24.750). Witness.30finished;thefailingrequestisruntime,notwitness/disposal/navigation. Its full decoded geometry was nevertheless read back; this does not waive the actual requesterror. Underlying Chrome/progress-stream cause is unproven.

Finalpostcleanupqualificationremainsfalse. Browser/serverclosed;supervisoremptyownedactivePIDs,reaped4Zchildren,nosignals. Original8unitFAILalsoremainsintact. No retry or source/application change occurred within this observed unit.
