"""HELD one anatomical-field + original65 diagnostic;30s512MiB, no retry/export."""
from pathlib import Path
import datetime,hashlib,json,os,resource,signal,subprocess,sys,time
HERE=Path(__file__).resolve().parent
PYTHON='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def main():
    assert sys.version_info[:3]==(3,11,17),'Runtime guard HOLD before imports/field'
    release_path=Path(sys.argv[1]).resolve();r=json.loads(release_path.read_text())
    assert r['released'] is True and r['authorization']=='ONE_ROOT_AUTHORIZED_V14_ANATOMICAL_BIND_ORIGINAL65'
    assert r['maximum_runs']==1 and r['maximum_fields']==1 and r['maximum_original65_diagnostics']==1
    assert r['maximum_wall_seconds']==30 and r['maximum_rss_bytes']==512*1024*1024
    assert r['solver_or_model_export_or_activation_authorized'] is False
    for name,digest in r['source_sha256'].items():assert sha(HERE/name)==digest,name+' drift'
    for key,row in json.loads((HERE/'INPUT-PINS.json').read_text()).items():assert sha(row['path'])==row['sha256'],key+' drift'
    out=HERE/'ACTUAL';assert not out.exists(),'One-shot output exists; no retry'
    out.mkdir();(out/'ROOT-RELEASE.json').write_text(json.dumps(r,indent=2)+'\n')
    (out/'INTENT.json').write_text(json.dumps({'started_utc':utc(),'field_constructions':1,'original65_diagnostics':1,'maximum_wall_seconds':30,'maximum_rss_bytes':536870912,'nice':19,'math_threads':1,'solvers':0,'model_export_or_activation':False},indent=2)+'\n')
    env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    start=time.monotonic();peak=0;reason=None
    with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
        child=subprocess.Popen(['nice','-n','19',PYTHON,str(HERE/'prove_original65_anatomical_HELD.py'),str(release_path)],cwd=HERE,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        while child.poll() is None:
            try:
                for line in (Path('/proc')/str(child.pid)/'status').read_text().splitlines():
                    if line.startswith('VmRSS:'):peak=max(peak,int(line.split()[1])*1024)
            except FileNotFoundError:pass
            if time.monotonic()-start>30:reason='WALL_LIMIT_30_SECONDS'
            elif peak>512*1024*1024:reason='RSS_LIMIT_512_MiB'
            if reason:
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                break
            time.sleep(.025)
        code=child.wait()
    elapsed=time.monotonic()-start;peak=max(peak,int(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)*1024)
    if peak>512*1024*1024:reason=reason or 'KERNEL_PEAK_RSS_EXCEEDED_512_MiB'
    if elapsed>30:reason=reason or 'ELAPSED_LIMIT_EXCEEDED_30_SECONDS'
    path=out/'ACTUAL-WALK-WEIGHT-V14-DIAGNOSTIC-CPU-READBACK.json';report=json.loads(path.read_text()) if path.exists() else None
    if reason:status='RESOURCE_FAIL_NO_RETRY'
    elif report is None:status='BUILD_OR_MOTION_REFUSAL_OR_SOURCE_ERROR_NO_ACCEPTANCE_NO_RETRY'
    elif report['mechanics_pass'] and report['deformation_screen_pass'] and code==0:status='ORIGINAL65_ANATOMICAL_DIAGNOSTIC_PASS_ONLY_PRIOR_FAILURES_PRESERVED'
    else:status='ORIGINAL65_ANATOMICAL_DIAGNOSTIC_FAIL_NO_RETRY'
    terminal={'status':status,'finished_utc':utc(),'exit_code':code,'elapsed_seconds':elapsed,'actual_peak_rss_bytes':peak,'resource_failure':reason,'runs':1,'reruns':0,'no_owned_child_active':True,'report_present':report is not None,'original65_samples':65 if report is not None else None,'solvers':0,'prior_QP_certificate_pass':False,'prior_V10_physical_FAIL_preserved':True,'prior_V12_cropped_mask_FAIL_preserved':True,'walk_or_visual_accepted':False,'model_export_or_activation_or_next_phase':False}
    (out/'TERMINAL.json').write_text(json.dumps(terminal,indent=2)+'\n');print(json.dumps(terminal),flush=True)
    return 0 if status=='ORIGINAL65_ANATOMICAL_DIAGNOSTIC_PASS_ONLY_PRIOR_FAILURES_PRESERVED' else 2

if __name__=='__main__':raise SystemExit(main())
