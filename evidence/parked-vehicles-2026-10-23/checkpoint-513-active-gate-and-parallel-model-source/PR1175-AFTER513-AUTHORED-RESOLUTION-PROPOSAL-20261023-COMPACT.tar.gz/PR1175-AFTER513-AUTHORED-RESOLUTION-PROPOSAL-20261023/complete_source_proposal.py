import pathlib,json,subprocess,hashlib,difflib,datetime,shutil,re
R='/workspace/chicago';VR='/tmp/chicago-covered-sag';P='4766644295b5668084130fed80c6a18c9f0e6a04';V='13375406538e76e8c1deadf18165089f7145ea28';B='575b4968569283177e36e92878b2a84c5554068e';N='5135fb7674eea8cf5b140a7cf0c8bc208b0b1f4e'
o=pathlib.Path(__file__).resolve().parent;old=pathlib.Path('/workspace/shared/PR1175-AFTER133-AUTHORED-RESOLUTION-PROPOSAL-20261023')
def git(repo,*a):return subprocess.check_output(['git','-C',repo,*a],stderr=subprocess.DEVNULL)
def sha(b):return hashlib.sha256(b).hexdigest()
def patch(a,b,ap,bp):return b''.join(difflib.diff_bytes(difflib.unified_diff,a.splitlines(True),b.splitlines(True),fromfile=ap.encode(),tofile=bp.encode()))
paths=[x['path'] for x in json.loads((o/'INITIAL-TEXT-CLASSIFICATION.json').read_text())]
proof=[];allpatch=[]
for p in paths:
 d=o/'files'/p;incoming=(d/'incoming513plusVehicle133.raw').read_bytes();actual=git(VR,'show',':'+p);assert incoming==actual,p
 proposed=(o/'proposed'/p).read_bytes();diff=patch(incoming,proposed,'a/'+p,'b/'+p);(d/'PROPOSED-VS-INCOMING513.patch').write_bytes(diff);allpatch.append(diff)
 proof.append({'path':p,'proposed_sha256':sha(proposed),'incoming_sha256':sha(incoming),'actual_vehicle_staged_blob':git(VR,'rev-parse',':'+p).decode().strip(),'synthetic_expected_equals_actual_stage':True})
(o/'AUTHORED-PROPOSAL-VS-INCOMING513.patch').write_bytes(b''.join(allpatch));(o/'PROPOSED-AUTHORED-PROOF.json').write_text(json.dumps(proof,indent=2)+'\n')
pins=json.loads((old/'PERSON62-REFRESHED-EXPECTED-PINS.json').read_text());incoming_changed=set(git(R,'diff','--name-only',B,N,'--','chicago/4d').decode().splitlines())
for row in pins:
 p=row['path'];assert sha(git(R,'show',P+':'+p))==row['person_sha256'],p
 if p.endswith('/main.js'):
  incoming=(o/'proposed'/p).read_bytes();row['expected_sha256']=sha(incoming);row['expected_owner']='incoming513_UI_plus_preserved_vehicle_drawing_buffer_callback';row['incoming513_vehicle_sha256']=sha(incoming);row.pop('vehicle133_sha256',None)
 else:
  assert row['expected_sha256']==row['person_sha256'];assert p not in incoming_changed,p
  row['expected_owner']='person476_exact';row.pop('vehicle133_sha256',None)
(o/'PERSON62-REFRESHED-EXPECTED-PINS.json').write_text(json.dumps(pins,indent=2)+'\n');assert len(pins)==62
shutil.copy2(old/'PERSON476-ONLY-EXPECTED-PINS.json',o/'PERSON476-ONLY-EXPECTED-PINS.json')
for row in json.loads((o/'PERSON476-ONLY-EXPECTED-PINS.json').read_text()):assert sha(git(R,'show',P+':'+row['path']))==row['expected_sha256']
oldincoming=json.loads((old/'INCOMING133-NONPERSON-EXPECTED-PINS.json').read_text());personchanged=set(git(R,'diff','--name-only','58fd2216a9312295cefbcc08c301852db09ea199',P,'--','chicago/4d').decode().splitlines());expectedpaths={r['path'] for r in oldincoming}|{p for p in incoming_changed if p not in personchanged}|{'chicago/4d/tools/transport/brougham/legacy-card-contract.json'}
new=[]
for p in sorted(expectedpaths):
 b=git(VR,'show',':'+p);new.append({'path':p,'expected_owner':'incoming_vehicle133_plus_exact513_and_reviewed_legacy_fixture','exists':True,'expected_sha256':sha(b),'actual_staged_git_blob':git(VR,'rev-parse',':'+p).decode().strip()})
(o/'INCOMING513-NONPERSON-EXPECTED-PINS.json').write_text(json.dumps(new,indent=2)+'\n')
assert next(x for x in new if x['path'].endswith('legacy-card-contract.json'))['expected_sha256']=='66c973fdda170150dd7a1accd32bdf39aeb25d2dadc714e58e9580a194d9360d'
s=(o/'proposed/chicago/4d/tools/smoke_renderer.mjs').read_text();t=(o/'files/chicago/4d/tools/smoke_renderer.mjs/incoming513plusVehicle133.raw').read_text()
for start,end in [('    // T-2662: measure a real first appearance','    const problems ='),('    // ---- T-2662/T-3043:','    // ---- end T-2662')]:
 block=lambda text:text[text.index(start):text.index(end,text.index(start))]
 assert block(s)==block(t)
assert 'const api = window.__chicago4d;' in block(s)
oldmain=git(R,'show',P+':chicago/4d/renderers/web/js/main.js');newmain=(o/'proposed/chicago/4d/renderers/web/js/main.js').read_bytes();(o/'INCOMING-MAIN-EXCEPTION.patch').write_bytes(patch(oldmain,newmain,'a/person476/main.js','b/incoming513-with-vehicle-hook/main.js'))
libP=json.loads(git(R,'show',P+':chicago/4d/data/liberties.json'));libN=json.loads(git(VR,'show',':chicago/4d/data/liberties.json'));ids=lambda x:{v['id'] for v in x['liberties']};a=ids(libP);b=ids(libN);assert len(a|b)==696
(o/'LIBERTY-UNION-EXPECTED-ONLY.json').write_text(json.dumps({'person_count':len(a),'incoming513_count':len(b),'union_id_count':len(a|b),'person_only_ids':sorted(a-b),'incoming_only_ids':sorted(b-a),'generated_source_written':False,'required':'canonical supported derivation after actual authoredmerge; retain exact incomingAmes revisions and oldGlessner liberty amendment'},indent=2)+'\n')
index_path=pathlib.Path(git(R,'rev-parse','--git-path','index').decode().strip());index_path=index_path if index_path.is_absolute() else pathlib.Path(R)/index_path
status=git(R,'status','--porcelain').decode();assert status=='';assert git(R,'rev-parse','HEAD').decode().strip()==P;idx=sha(index_path.read_bytes());assert idx=='b9e97ba20b2a48b26bb0e5b4c9cbd42833af7dbc4f7c45ecd75c325b95b5328a'
origin=git(R,'rev-parse','origin/dev').decode().strip();assert origin=='824957fe47dd70fad729c3b117cb18b695d54b0b'
checks={'saved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_only':True,'node_check_main_smoke':'PASS','bash_n_check':'PASS','all8incoming_synthetic_matches_actual_vehicle_stage':True,'person61_exact_pins':True,'main_explicit_incoming_UI_exception':True,'person38_only_pins_exact':True,'person_smoke_delta_byteexact':True,'Guide_and_initial_Welcome_blocks_byteexact_incoming':True,'222census_byteexact_incoming':True,'incoming_nonperson_expected_paths':len(new),'primary_HEAD':P,'primary_index_sha256':idx,'primary_status':status,'origin_dev':origin,'app_index_or_worktree_mutated':False,'actual_merged_world_frame_pass_claimed':False}
(o/'SOURCE-CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks))
