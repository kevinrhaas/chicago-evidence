# Read-only b7 Calumet assessment at the unchanged Glessner spawn

Source ref `b7cde6d86e42edd1c80204642c40ca8b683ceffd`; prior DEV `6c3603ff3019b8600a8945433f9196f4d861fd2d`. This is finite source analysis, with no application writes, regeneration, provider solver, renderer, browser, checker, test run, publication or gate execution. It is not a budget PASS or photographic acceptance.

The actual failed ordinary desktop frame is **4,600,305 / 4,600,000 triangles** at **Prairie/18th, E1410.12 N−3218.01 yaw264.94**, the T1739 smoke pose. The earlier20th/T3012 wording was corrected by root; no new camera is proposed. The preserved actual failure is `/workspace/shared/PR1175-DATE34-FULL14-ca9a89eb41-GET-owner1/ACTUAL-CA9A-SPAWN-BUDGET-FAILURE.json`.

## New geometry and possible submission

The21 committed web GLBs total **34,440 native triangles /133 primitives**. Their exact normalized POSITION accessor minima/maxima, node transforms and sidecar placements were read from Git. No compressed buffers need decoding for conservative bounds. All21 objects lie wholly behind this ordinary colour camera: their aggregate conservative forward-depth extrema are **−90.0503…−20.7561m**. They therefore provide no colour fragments at this pose. Runtime bounding-sphere/spatial/coalescing submission counters still require actual observation.

Full shadow reach is **240m**, not parked-vehicle reach100m. Under the exact1904 sun (bearing126.612202°, elevation62.944726°),14 new objects have their complete conservative geometry outside the sun-map rectangle;7 intersect it. A conservative *unpartitioned source primitive* sphere assessment leaves **9,824 native triangles** potentially submitted. This is neither an exact production counter nor a guaranteed upper bound after production spatial partition/compaction. The seven are2000house/coach,2004house/coach,2016house/coach and2032coach. Sun-box overlap alone says nothing about a shadow reaching the view.

## Source-supported genuine optimization proposal

The shipped `shadow-casters.js` already sweeps each structure's bounding sphere away from the **current** sun by `(2r + FLOOR_BELOW_M30) / sun.y`, and rejects it only if **both endpoint spheres** lie strictly outside one **current** camera-frustum plane. It fails open for low/absent sun and restores visibility in `finally`, preserving colour/picks. Every structure batch receives this wrapper, but `DETAIL.light` alone enables `castersTowardView:true`; Full leaves it disabled.

Applying the same conservative envelope analytically to whole-object world-AABB circumspheres proves all21 new objects' swept capsules remain outside the exact ordinary desktop camera's **left plane**. The closest complete capsule remains **207.322m outside**. The30m floor stays unchanged and is below the entire committed terrain envelope. The proof uses pitch0, fov55,1280×800,zoom1, the actual source spawn; the plane has no vertical component, so eyeheight and ground interpolation do not affect this exclusion. See `CONSERVATIVE-SHADOW-CAPSULE-ANALYTIC.json` for every object's start/end distance, radius and sweep length.

Thus enabling the existing conservative receiver-frustum shadow-caster policy for Full is a plausible genuine optimization. This is a proposal only. It must remain dynamic while walking/turning and continue failing open when bounds/sun/receiver semantics cannot be proven. It must not blanket-hide objects, change camera/placements, reduce shadow quality/reach, change caps, or assume the analytic9,824 is an observed saving. Source review, actual ordinary spawned frame counters and image/negative-control evidence remain required before accepting any implementation. No such implementation or tests were performed here.

## Brougham replacement arithmetic

The committed6c/ca9 baseline contains **only old C02**, not the additive experimental seven-row Brougham configuration. C02 native geometry is **12,228 triangles plus60 shaft-rest support =12,288**. Its replacement is the accepted **11,706** mid, with the **33,502 near master unchanged**. The qualified Brougham stand stays E1397.9 N−3240,bearing178.99, horizontally25.157m from spawn. The unchanged desktop fov55/800px selector computes a24m minimum threshold; its native11,706 mid is therefore the expected selected level at this stand, subject to actual runtime observation.

Equivalent-pass arithmetic saves **582 native triangles** versus committed C02. Savings of22,820 relate only to replacing the experimental additive22,238 mid and deleting C02, not to the actual6c/ca9 world baseline. Actual colour and sun pass submission sets differ, so neither582 nor a simple multiple establishes a final frame count. New b7 shadow submissions can erase modest headroom; no analytic budget verdict is warranted.

All five distinct1835 parked identities, original near conservative proxy, source near33502, legacy asset bytes, caps, thresholds, cameras and stands remain unchanged by this assessment. Root owns any next implementation/measurement decision.

## Preparation note

An initial attempt to read compressed web bufferView offsets directly stopped with `struct.error` before output: meshopt stores compressed bytes separately from the logical buffer views. The final analysis uses declared glTF POSITION accessor extrema and exact transforms, avoiding decompression entirely. This was a local read-only preparation error; no model/checker/runtime pass was claimed or relabelled.
