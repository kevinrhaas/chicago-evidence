import hashlib, itertools, json, math, pathlib, struct, subprocess

OUT = pathlib.Path(__file__).parent
REPO = '/workspace/chicago'
REF = 'b7cde6d86e42edd1c80204642c40ca8b683ceffd'
PREFIX = 'chicago/4d/'
def blob(p):
    return subprocess.check_output(['git', 'show', REF+':'+p], cwd=REPO)
def js(p):
    return json.loads(blob(PREFIX+p))
def sha(b):
    return hashlib.sha256(b).hexdigest()
scene = js('data/scenes/1904.json')
datum = js('data/datum.json')
terrain = js('data/terrain/epochs/e1871_postfire/heightfield.json')
world = blob(PREFIX+'renderers/web/js/world.js').decode()
solar = world[world.index('export function solarPosition('):world.index('/** Compass bearing + elevation')]
solar = solar.replace('export function', 'function', 1)
script = ('const DEG=Math.PI/180;function mod(a,n){return ((a%n)+n)%n;}function mod360(a){return mod(a,360);}\n'
          +solar+'\nconsole.log(JSON.stringify(solarPosition('+json.dumps(dict(lat=datum['origin_lat'],lon=datum['origin_lon'],date=scene['target_date'],localMeanTime=scene['lighting']['local_time']))+')));')
sun = json.loads(subprocess.check_output(['node','-e',script]))
az,el = map(math.radians,[sun['azimuthDeg'],sun['elevationDeg']])
direction = [math.sin(az)*math.cos(el),math.sin(el),-math.cos(az)*math.cos(el)]
right = [direction[2],0,-direction[0]]
norm = math.hypot(*right);right=[v/norm for v in right]
up = [direction[1]*right[2], direction[2]*right[0]-direction[0]*right[2],-direction[1]*right[0]]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
spawn=scene['spawn'];origin=[spawn['local_e'],0,-spawn['local_n']]
# Full scene-detail shadow rig:240m half width,4096 map. Same snapped centre as world.js.
reach=240.;texel=480/4096
centre=origin[:]
for basis in [right,up]:
    v=dot(origin,basis);delta=math.floor(v/texel+0.5)*texel-v
    centre=[x+delta*b for x,b in zip(centre,basis)]
census=json.loads(pathlib.Path('/workspace/shared/DEVB7-READONLY-DELTA-AUDIT-20261023/NEW-WEB-GLB-CENSUS.json').read_text())
b=math.radians(spawn['yaw_deg']);tanhalf=math.tan(math.radians(55/2))*1.6
rows=[]
for entry in census:
    data=blob(entry['path']);assert sha(data)==entry['sha256']
    nj=struct.unpack_from('<I',data,12)[0];g=json.loads(data[20:20+nj]);nb=20+nj
    binlen,bintype=struct.unpack_from('<II',data,nb);assert bintype==0x004e4942
    binary=data[nb+8:nb+8+binlen]
    sid=pathlib.Path(entry['path']).stem.split('__')[0]
    sc=js('data/sidecars/1904/'+sid+'.json');p=sc['placement'];rot=math.radians(p['rotation_deg'])
    cs,sn=math.cos(rot),math.sin(rot)
    verts=[];prims=[]
    for node in g['nodes']:
        assert not node.get('rotation') and not node.get('matrix') and not node.get('children'), 'unhandled node transform'
        if 'mesh' not in node:continue
        scale=node.get('scale',[1,1,1]);translation=node.get('translation',[0,0,0])
        for prim in g['meshes'][node['mesh']]['primitives']:
            ac=g['accessors'][prim['attributes']['POSITION']]
            pts=[]
            # Compressed web buffers need no decompression for this conservative proof:
            # glTF accessor extrema in encoding coordinates enclose every vertex.
            for v in itertools.product(*zip(ac['min'],ac['max'])):
                if ac.get('normalized'):
                    denom={5122:32767,5123:65535,5120:127,5121:255}[ac['componentType']]
                    v=[max(-1,x/denom) for x in v]
                x,y,z=[v[k]*scale[k]+translation[k] for k in range(3)]
                pts.append([p['local_e']+cs*x-sn*z,y,-p['local_n']+sn*x+cs*z])
            count=g['accessors'][prim['indices']]['count'] if 'indices'in prim else ac['count']
            assert prim.get('mode',4)==4
            prims.append(dict(triangles=count//3,points=pts));verts+=pts
    triangles=sum(z['triangles']for z in prims);assert triangles==entry['native_triangles']
    e0,e1=min(v[0]for v in verts),max(v[0]for v in verts)
    n0,n1=min(-v[2]for v in verts),max(-v[2]for v in verts)
    depth=[];side=[];sr=[];su=[]
    for v in verts:
        de,dn=v[0]-spawn['local_e'],-v[2]-spawn['local_n']
        depth.append(de*math.sin(b)+dn*math.cos(b));side.append(de*math.cos(b)-dn*math.sin(b))
        for ground in [terrain['min_m']-terrain['quantisation_error_m'],terrain['max_m']+terrain['quantisation_error_m']]:
            d=[v[0]-centre[0],v[1]+ground-centre[1],v[2]-centre[2]];sr.append(dot(d,right));su.append(dot(d,up))
    # Conservative sphere used by stock BatchedMesh frustum culling. This is NOT an actual submitted count.
    possible=excluded=0
    for pr in prims:
        pts=pr['points'];lo=[min(v[k]for v in pts)for k in range(3)];hi=[max(v[k]for v in pts)for k in range(3)]
        c=[(lo[k]+hi[k])/2 for k in range(3)];radius=max(math.dist(v,c)for v in pts)
        ranges=[]
        for basis in [right,up]:
            vals=[]
            for ground in [terrain['min_m']-terrain['quantisation_error_m'],terrain['max_m']+terrain['quantisation_error_m']]:
                d=[c[0]-centre[0],c[1]+ground-centre[1],c[2]-centre[2]];vals.append(dot(d,basis))
            ranges.append([min(vals)-radius,max(vals)+radius])
        outside=any(a>reach or z < -reach for a,z in ranges)
        if outside:excluded+=pr['triangles']
        else:possible+=pr['triangles']
    rows.append(dict(id=sid,native_triangles=triangles,primitives=len(prims),web_sha256=entry['sha256'],placement=p,
      horizontal_world_bounds_enu_m=dict(e=[e0,e1],n=[n0,n1]),local_y_bounds_m=[min(v[1]for v in verts),max(v[1]for v in verts)],
      closest_horizontal_aabb_distance_m=math.hypot(max(e0-spawn['local_e'],0,spawn['local_e']-e1),max(n0-spawn['local_n'],0,spawn['local_n']-n1)),
      accessor_aabb_colour_forward_depth_m=[min(depth),max(depth)],colour_completely_behind_camera=max(depth)<0,
      light_plane_accessor_aabb_extents_full_ground_envelope_m=dict(right=[min(sr),max(sr)],up=[min(su),max(su)]),
      shadow_geometric_aabb_excluded= min(sr)>reach or max(sr)<-reach or min(su)>reach or max(su)<-reach,
      unpartitioned_primitive_shadow_sphere_possible_native_triangles=possible,unpartitioned_primitive_shadow_sphere_excluded_native_triangles=excluded))
report=dict(status='SOURCE_ONLY_NO_BUDGET_VERDICT',ref=REF,spawn=spawn,sun=sun,shadow=dict(half_reach_m=reach,map_size=4096,texel_m=texel,centre_world=centre,right=right,up=up),
 terrain_ground_envelope_m=[terrain['min_m']-terrain['quantisation_error_m'],terrain['max_m']+terrain['quantisation_error_m']],
 totals=dict(objects=len(rows),native_triangles=sum(r['native_triangles']for r in rows),primitives=sum(r['primitives']for r in rows),
 wholly_behind_colour_camera=sum(r['colour_completely_behind_camera']for r in rows),shadow_geometric_aabb_excluded_objects=sum(r['shadow_geometric_aabb_excluded']for r in rows),
 unpartitioned_primitive_shadow_sphere_possible_native_triangles=sum(r['unpartitioned_primitive_shadow_sphere_possible_native_triangles']for r in rows)),rows=rows,
 limitations=['Committed web-GLB normalized POSITION accessor extrema transformed through exact node/placement transforms; no buffers decoded or regenerated.','Source bounds only, not renderer counters or budget PASS.','Production buildings spatially partition and compact vertices; sphere counts here conservatively enclose unpartitioned source primitive AABBs, not exact production submissions.','Ground envelope conservatively uses entire epoch min/max plus declared quantisation error; no provider solver or terrain geometry was regenerated.','Colour behind-camera proof uses conservative accessor AABBs; production sphere/coalescing may submit geometry despite no visible colour fragments.','Shadow rectangle overlap does not prove visible contribution; depth/frustum, material consolidation, spatial splits, quantisation, and shadow flags must be observed in actual ordinary world.'])
(OUT/'BOUNDS-AND-SPAWN-ANALYSIS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(totals=report['totals'],sun=sun,behind_depth_extrema=[min(r['accessor_aabb_colour_forward_depth_m'][0]for r in rows),max(r['accessor_aabb_colour_forward_depth_m'][1]for r in rows)],possible_shadow_rows=[dict(id=r['id'],tri=r['unpartitioned_primitive_shadow_sphere_possible_native_triangles'],up=r['light_plane_accessor_aabb_extents_full_ground_envelope_m']['up'])for r in rows if r['unpartitioned_primitive_shadow_sphere_possible_native_triangles']]),indent=2))
