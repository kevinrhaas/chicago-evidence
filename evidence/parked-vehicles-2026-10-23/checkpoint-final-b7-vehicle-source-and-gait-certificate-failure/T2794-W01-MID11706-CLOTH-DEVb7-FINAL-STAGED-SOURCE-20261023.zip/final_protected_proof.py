import pathlib,json,hashlib,subprocess,re,datetime
R=pathlib.Path('/tmp/chicago-covered-sag/chicago/4d');O=pathlib.Path(__file__).parent
CAP=pathlib.Path('/workspace/shared/T2794-W01-MID11706-DEV6c-ACTUAL-APP-20261023/FINAL-DEV6c-STAGED-CAPSULE')
BASE='b7cde6d86e42edd1c80204642c40ca8b683ceffd';HEAD='0be5e645e016a212bd04eeda58e893472650d3d0';P='chicago/4d/'
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def old(ref,p):return git('show',ref+':'+P+p)
def h(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse','MERGE_HEAD').decode().strip()==BASE
assert git('rev-parse','origin/dev').decode().strip()=='824957fe47dd70fad729c3b117cb18b695d54b0b'
assert not git('diff','--name-only','--diff-filter=U').strip()
assert not git('diff','--name-only').strip()
tree=git('write-tree').decode().strip()
changed=git('diff','--name-only',BASE,'--',':(top)chicago/4d').decode().splitlines()
assert not [p for p in changed if p.startswith(tuple(P+x for x in ['assets/gltf/','assets/web/','assets/bakes/','assets/manifest']))]
docproof={}
for name in ['docs/STATUS.md','docs/ROADMAP.md','docs/LIBERTIES.md']:
 incoming=[x for x in old(BASE,name).splitlines() if x.strip()];current=iter((R/name).read_bytes().splitlines())
 for line in incoming:assert any(line==v for v in current),(name,line[:120])
 docproof[name]={'all_incoming_nonblank_lines_retained_in_order':True,'line_count':len(incoming)}
jschanged=[p for p in changed if p.startswith(P+'renderers/web/js/')]
assert set(jschanged)=={P+'renderers/web/js/main.js',P+'renderers/web/js/parked-transport.js'},jschanged
assert (R/'renderers/web/js/main.js').read_bytes()==old(HEAD,'renderers/web/js/main.js')
a=old(HEAD,'renderers/web/js/parked-transport.js');b=(R/'renderers/web/js/parked-transport.js').read_bytes();assert a.replace(b'22238',b'11706')==b
smoke=(R/'tools/smoke_renderer.mjs').read_bytes();assert h(smoke)=='9d3e23287022a92e1410e3e0952432d75639211c087e9597f57b4c2acae8a0f9'
near=json.loads(old(HEAD,'renderers/web/transport/parked-brougham/brougham.json'));current=json.loads((R/'renderers/web/transport/parked-brougham/brougham.json').read_text())
for k in ['static_master','anchors','wheel_contacts_root_m','static_pole_ground_shoe_contact_root_m']:assert near[k]==current[k],k
assert near['lods'][0]==current['lods'][0];assert current['lods'][1]['triangles']==11706
oldproof=json.loads((CAP/'records/FINAL-STAGED-PROTECTED-PROOF.json').read_text());glbs=[]
for row in oldproof['original_transport_glbs']:
 p=row['path'][len(P):];data=(R/p).read_bytes();assert h(data)==row['sha256'],p
 if not row['intentional_change']:assert data==old(HEAD,p),p
 glbs.append(row)
placements=json.loads((R/'data/transport/parked/placements.json').read_text());expected=json.loads((CAP/'actual-source/data/transport/parked/placements.json').read_text());assert placements==expected
source=json.loads((R/'assets/authored/transport/wagon_covered/SOURCE.json').read_text());insource=json.loads(old(BASE,'assets/authored/transport/wagon_covered/SOURCE.json'));allowed={'core_source_sha256','variants','limitations','source_commit_scope','canvas_drape_refinement'}
assert all(source.get(k)==insource.get(k) for k in source.keys()|insource.keys() if k not in allowed)
iso=json.loads((R/'tools/step_isolation.json').read_text());incomingiso=json.loads(old(BASE,'tools/step_isolation.json'));ownrow=json.loads((CAP/'OWNED-ISOLATION-ROW.json').read_text());assert iso['tools'].pop(ownrow['tool'])==ownrow['row']; inheritediso=json.loads(old(HEAD,'tools/step_isolation.json')); extras=set(iso['tools'])-set(incomingiso['tools']); assert extras=={'tools/check_brougham_near.py','tools/test_brougham_card.mjs'}; assert all(iso['tools'].pop(k)==inheritediso['tools'][k] for k in extras); assert iso==incomingiso
pins=json.loads((CAP/'PREIMAGE-AND-OWNED-FILE-PINS.json').read_text());owned=[]
for p in [row['path'] for row in pins]+['tools/smoke_renderer.mjs','tools/transport/check_parked_placements.py']:
 path=R/p;data=path.read_bytes();owned.append({'path':p,'blob':git('rev-parse',':'+P+p).decode().strip(),'sha256':h(data),'bytes':len(data),'mode':oct(path.stat().st_mode&0o777)})
index=git('ls-files','--stage','-z');(O/'FINAL-INDEX-STAGE-PINS.bin').write_bytes(index)
proof={'expected_parents':[HEAD,BASE],'staged_tree':tree,'no_unmerged_or_unstaged':True,'origin_dev':git('rev-parse','origin/dev').decode().strip(),'owned_files':owned,'index_stage_pins_sha256':h(index),'incoming_tracked_geometry_manifests_and_bakes_exact_b7':True,'incoming_authored_docs':docproof,'all_incoming_js_except_main_and_parked_runtime_exact_b7':True,'main_exact_0be5_only_existing_two_line_buffer_callback_vs_b7':True,'parked_runtime_only_active_triangle_literal_changed_since_0be5':True,'smoke_entire_sha256':h(smoke),'smoke_exact_root_approved_minimal_b7_candidate':True,'five_1835_rows_and_all_placement_identity_exact_accepted_capsule':True,'near33502_raw_indexed_lod_metadata_anchors_static_master_and_proxy_exact_0be5':True,'original_transport_glbs':glbs,'newer_cloth_terrain_and_variant_identity_exact':True,'incoming_isolation_metadata_and_rows_preserved':True,'only_four_original_transport_payload_changes_allowed':True,'world_budget_photo_qualification_pending':True,'created':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'FINAL-STAGED-PROTECTED-PROOF.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k not in ['owned_files','original_transport_glbs']},indent=2))
