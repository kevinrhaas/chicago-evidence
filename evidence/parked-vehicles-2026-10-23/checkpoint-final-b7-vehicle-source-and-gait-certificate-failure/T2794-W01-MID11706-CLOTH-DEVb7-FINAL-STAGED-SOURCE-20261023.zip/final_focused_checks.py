import subprocess,pathlib,json,time,datetime,os
R=pathlib.Path('/tmp/chicago-covered-sag/chicago/4d');O=pathlib.Path(__file__).parent
env=os.environ.copy();env['PATH']='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:'+env['PATH'];env.update({k:'1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','C4D_GATE_REQUIRE_READERS']});env['BASE']='b7cde6d86e42edd1c80204642c40ca8b683ceffd'
checks=[('READERS',['python3','tools/check_gate_readers.py']),('NATIVE',['python3','tools/check_brougham_near.py']),('CARD-LOD',['node','tools/test_brougham_card.mjs']),('PLACEMENTS',['python3','tools/transport/check_parked_placements.py']),('COVERED-IDENTITY',['python3','tools/transport/wagon_covered/test_identity.py']),('LIBERTIES',['python3','tools/compile_liberties.py','--check']),('CHANGELOG',['node','tools/changelog-entries.mjs','--check']),('ISOLATION-AUDIT',['node','tools/audit_step_isolation.mjs','--check','--quiet']),('SMOKE-PARSE',['node','--check','tools/smoke_renderer.mjs'])]
rows=[]
for name,cmd in checks:
 t=time.monotonic()
 with (O/('FINAL-FOCUSED-'+name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-t};rows.append(row);print(json.dumps(row),flush=True)
 if r.returncode:break
result={'checks':rows,'pass':len(rows)==len(checks) and all(x['exit_code']==0 for x in rows),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat()};(O/'FINAL-FOCUSED-TERMINAL.json').write_text(json.dumps(result,indent=2)+'\n');raise SystemExit(0 if result['pass'] else 1)
