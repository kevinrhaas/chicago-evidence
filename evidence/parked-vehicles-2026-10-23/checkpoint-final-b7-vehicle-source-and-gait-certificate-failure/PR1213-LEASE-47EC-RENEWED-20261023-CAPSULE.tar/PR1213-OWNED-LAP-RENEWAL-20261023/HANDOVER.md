# PR1213 owned lease renewed once

Root explicitly authorized renewal of exact owned old marker `4bd851866e15db788690646a4b17df83bf577091`. Its parentless empty tree, root parked carriage/wagon material ownership message, timestamp and actual nonce `mvk86dcg17xyox08qmpl6` were recorded before proceeding.

One root-reviewed fixed-old-owner CAS succeeded at 03:59:44 UTC, installing actual marker `47ec205454aa9464a1c5d06968278d714f2e1394`. The after-ref GET verified that exact SHA. The new local commit matching that remote SHA has an empty tree, no parents and a distinct fresh nonce. The stale boundary is 06:59:44 UTC. No different owner was overwritten; no retry occurred.

The exact adapted execution recipe and raw before-ref/commit, CAS push and after-ref outputs are retained. Five GETs total include the initial ownership record plus the recipe's immediate guard and actual after-ref proof. No app, index, source, PR body, CI, smoke, merge or other lease action occurred. Future PR1213 guards must use actual new marker47ec; no such guard was executed here. Root remains canonical ticket writer.
