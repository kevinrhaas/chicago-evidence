"""Unexecuted source: exact sparse smooth QP on already fixed V10 palettes.

No optimizer, pose, asset export or app action is called by this module.
Q(2..5 -> 1) is confined to the already-proved exact frozen walk. The pinned
raw protected vectors remain unchanged; no independent clip inherits Q.
"""
from pathlib import Path
import hashlib, json
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
from actual_model import Model

ELL = 0.3263955630216535


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def quotient(weights):
    q = weights.copy()
    q[..., 1] += q[..., 2:6].sum(axis=-1)
    q[..., 2:6] = 0
    return q


def prepare(pins):
    """Build only after a future explicit root release; never import-and-run."""
    for name, row in pins.items():
        assert sha(row['path']) == row['sha256'], name + ' input drift'
    a = json.loads(Path(pins['phase_a_report']['path']).read_text())
    b = json.loads(Path(pins['phase_b_report']['path']).read_text())
    b_terminal = json.loads(Path(pins['phase_b_terminal']['path']).read_text())
    assert a['status'] == 'PROPOSAL_SOURCE_PREFLIGHT_PASS_NO_SOLVE'
    assert b['status'] == 'PROPOSAL_LP_FEASIBLE_WITNESS_ONLY_NO_GAIT_ACCEPTANCE'
    assert b_terminal['status'] == b['status'] and b_terminal['LP_solver_calls'] == 1
    assert b_terminal['no_owned_child_active'] is True
    assert not a['failures'] and b['solver_calls'] == 1
    original = a['source_pins']
    for name, row in original.items():
        assert sha(row['path']) == row['sha256'], name + ' original drift'
    solve = json.loads(Path(original['v8_solve_receipt']['path']).read_text())
    equivalence = solve['co_moving_palette_reduction']
    assert equivalence['joint_indices'] == [2, 3, 4, 5]
    assert equivalence['destination_joint'] == 1
    assert equivalence['maximum_frozen_walk_affine_difference'] < 1e-7
    assert equivalence['excluded_root0_affine_difference'] > .01
    with np.load(pins['phase_a_arrays']['path'], allow_pickle=False) as f:
        points = f['points_m'].copy()
        edges = f['edges'].copy()
        lengths = f['edge_lengths_m'].copy()
        allowed = f['fixed_palette_allowed'].copy()
        fixed = f['fixed_rows'].copy()
        known_ids = f['declared_known_class_ids'].copy()
        raw_rows = f['declared_known_vectors'].copy()
        vc = [f['vertex_classes_' + str(i)].copy() for i in range(3)]
    with np.load(pins['phase_b_matrices']['path'], allow_pickle=False) as f:
        var_classes = f['var_class_ids'].copy()
        var_joints = f['var_joint_ids'].copy()
    with np.load(pins['phase_b_witness']['path'], allow_pickle=False) as f:
        x0 = f['x'].copy()
        assert np.array_equal(var_classes, f['var_class_ids'])
        assert np.array_equal(var_joints, f['var_joint_ids'])
    assert not np.any((var_joints >= 2) & (var_joints < 6))
    assert not np.any(var_joints == 0)
    assert np.array_equal(np.flatnonzero(fixed), known_ids)
    expected_classes, expected_joints = np.nonzero(allowed & ~fixed[:, None])
    assert np.array_equal(expected_classes, var_classes)
    assert np.array_equal(expected_joints, var_joints)
    n, nv = len(points), len(x0)
    assert nv == 2019
    known_raw = np.zeros((n, 26))
    known_raw[known_ids] = raw_rows
    known_raw_sha = hashlib.sha256(known_raw.tobytes()).hexdigest()
    known_q = quotient(known_raw)
    model = Model(Path(original['rig']['path']))
    triangles = []
    for mi, node_id in enumerate((26, 27, 28)):
        pr = model.g['meshes'][model.g['nodes'][node_id]['mesh']]['primitives'][0]
        ix = model.accessor(pr['indices']).astype(int).reshape(-1, 3)
        triangles.append(vc[mi][ix])
    triangles = np.concatenate(triangles)
    assert len(triangles) == 14986
    p = points[triangles]
    area = np.linalg.norm(np.cross(p[:, 1] - p[:, 0], p[:, 2] - p[:, 0]), axis=1) / 2
    mass = np.zeros(n)
    for k in range(3):
        np.add.at(mass, triangles[:, k], area / 3)
    raw_edges = np.concatenate([np.sort(triangles[:, [i, j]], axis=1)
                                for i, j in ((0, 1), (1, 2), (2, 0))])
    area_edges = np.tile(area / 3, 3)
    valid = (raw_edges[:, 0] != raw_edges[:, 1]) & (area_edges > 0)
    raw_edges, area_edges = raw_edges[valid], area_edges[valid]
    observed_edges, inverse = np.unique(raw_edges, axis=0, return_inverse=True)
    assert np.array_equal(observed_edges, edges)
    raw_squared_length = np.square(points[raw_edges[:, 0]] - points[raw_edges[:, 1]]).sum(1)
    assert np.all(raw_squared_length > 1e-16)
    conductance = np.zeros(len(edges))
    np.add.at(conductance, inverse, area_edges / raw_squared_length)
    assert np.all(conductance > 0) and np.isfinite(conductance).all()
    screen = mass / ELL ** 2
    assert np.all(screen[var_classes] > 0)
    u, v = edges.T
    degree = np.zeros(n)
    np.add.at(degree, u, conductance)
    np.add.at(degree, v, conductance)
    metric = coo_matrix((np.r_[lengths, lengths],
                         (np.r_[u, v], np.r_[v, u])), shape=(n, n)).tocsr()
    trunk = np.flatnonzero((points[:, 1] >= 1.14) & (known_raw[:, 1] > .999999))
    assert len(trunk)
    distance = dijkstra(metric, directed=False, indices=trunk, min_only=True)
    assert np.isfinite(distance[var_classes]).all()
    target = np.zeros((n, 26))
    target[:, 1] = np.exp(-np.square(distance / ELL))
    controls = json.loads(Path(original['controls']['path']).read_text())
    pivots = np.asarray([row['rest_world_pivot_m'] for row in controls['nodes']])
    for row in controls['limbs'].values():
        a0, b0, c0, d0, e0 = row['joints']
        for joint, start, end, radius in ((a0, a0, b0, .13), (b0, b0, c0, .12), (e0, c0, e0, .13)):
            delta = pivots[end] - pivots[start]
            t = np.clip((points - pivots[start]) @ delta / (delta @ delta), 0, 1)
            r = np.linalg.norm(points - pivots[start] - t[:, None] * delta, axis=1) / radius
            q = np.maximum(0, 1 - r)
            target[:, joint] += q ** 4 * (4 * r + 1)
    target[~allowed] = 0
    unknown = np.flatnonzero(~fixed)
    assert np.all(target[unknown].sum(1) > 0)
    target[unknown] /= target[unknown].sum(1)[:, None]
    # Fixed screen energy is irrelevant to minimization. Choose this zero
    # constant convention explicitly; raw protected source vectors are untouched.
    target[fixed] = known_q[fixed]
    column = np.full((n, 26), -1, dtype=np.int64)
    column[var_classes, var_joints] = np.arange(nv)
    rr = [np.arange(nv)]
    cc = [np.arange(nv)]
    dd = [(degree + screen)[var_classes]]
    for joint in np.unique(var_joints):
        left, right = column[u, joint], column[v, joint]
        free = (left >= 0) & (right >= 0)
        rr.extend([left[free], right[free]])
        cc.extend([right[free], left[free]])
        dd.extend([-conductance[free], -conductance[free]])
    hessian = coo_matrix((np.concatenate(dd), (np.concatenate(rr), np.concatenate(cc))),
                         shape=(nv, nv)).tocsr()
    hessian.sum_duplicates()
    hessian.sort_indices()
    lc = degree[:, None] * known_q
    np.add.at(lc, u, -conductance[:, None] * known_q[v])
    np.add.at(lc, v, -conductance[:, None] * known_q[u])
    linear = (lc - screen[:, None] * target)[var_classes, var_joints]
    constant = (.5 * np.sum(conductance[:, None] * np.square(known_q[u] - known_q[v]))
                + .5 * np.sum(screen[:, None] * np.square(known_q - target)))

    def full_q(x):
        field = known_q.copy()
        field[var_classes, var_joints] = x
        return field

    def direct_energy_gradient(x):
        field = full_q(x)
        difference = field[u] - field[v]
        value = (.5 * np.sum(conductance[:, None] * np.square(difference))
                 + .5 * np.sum(screen[:, None] * np.square(field - target)))
        gradient = screen[:, None] * (field - target)
        np.add.at(gradient, u, conductance[:, None] * difference)
        np.add.at(gradient, v, -conductance[:, None] * difference)
        return float(value), gradient[var_classes, var_joints]

    assert hashlib.sha256(known_raw.tobytes()).hexdigest() == known_raw_sha
    return {'H': hessian, 'g': linear, 'constant': float(constant), 'x0': x0,
            'var_classes': var_classes, 'var_joints': var_joints,
            'mass': mass, 'screen': screen, 'conductance': conductance,
            'target_q': target, 'known_raw_sha256': known_raw_sha,
            'direct_energy_gradient': direct_energy_gradient,
            'analytic_minimum_hessian_eigenvalue_bound': float(screen[var_classes].min()),
            'original_acceptance_uninvoked': True}


def check_objective(problem):
    """Future released numerical self-consistency controls, not pose checks."""
    h, g, c, x0 = (problem[k] for k in ('H', 'g', 'constant', 'x0'))
    error = h - h.T
    symmetry = float(np.abs(error.data).max()) if error.nnz else 0.
    assert symmetry < 1e-12
    direction = np.sin(np.arange(len(x0)) + 1.)
    direction[0] = 1.
    rows = []
    direct0 = None
    for x in (x0, x0 + 1e-4 * direction):
        value, gradient = problem['direct_energy_gradient'](x)
        poly = float(.5 * x @ (h @ x) + g @ x + c)
        assembled = h @ x + g
        scale = max(1., abs(value), float(np.abs(gradient).max()))
        energy_error = abs(value - poly)
        gradient_error = float(np.abs(gradient - assembled).max())
        assert np.isfinite(value) and np.isfinite(gradient).all()
        assert energy_error <= 1e-10 * scale and gradient_error <= 1e-10 * scale
        rows.append({'energy_error_abs': energy_error, 'gradient_error_inf': gradient_error, 'scale': scale})
        if direct0 is None:
            direct0 = gradient
    _, perturbed_gradient = problem['direct_energy_gradient'](x0 + direction)
    hv_error = float(np.abs(perturbed_gradient - direct0 - h @ direction).max())
    assert hv_error <= 1e-10 * max(1., float(np.abs(perturbed_gradient).max()))
    bad_g = g.copy()
    bad_g[0] += 1e-3
    assert np.abs(direct0 - (h @ x0 + bad_g)).max() >= 9e-4
    corrupted_hv = h @ direction
    corrupted_hv[0] += 1e-3
    assert np.abs(perturbed_gradient - direct0 - corrupted_hv).max() >= 9e-4
    assert problem['analytic_minimum_hessian_eigenvalue_bound'] > 0
    return {'hessian_symmetry_error': symmetry, 'energy_gradient_identity': rows,
            'hessian_vector_identity_error_inf': hv_error,
            'corrupted_linear_boundary_term_detected': True,
            'corrupted_hessian_diagonal_detected': True,
            'PSD_proof': 'delta^T H delta = sum_edges c||deltaW_u-deltaW_v||^2 + sum_i screen_i||deltaW_i||^2; c>0, screen>=0 and screen>0 at every free scalar. Thus H is SPD on the unchanged fixed-palette unknowns.',
            'strict_positive_eigenvalue_lower_bound': problem['analytic_minimum_hessian_eigenvalue_bound'],
            'control_perturbations_are_algebra_only_not_skin_candidates': True}
