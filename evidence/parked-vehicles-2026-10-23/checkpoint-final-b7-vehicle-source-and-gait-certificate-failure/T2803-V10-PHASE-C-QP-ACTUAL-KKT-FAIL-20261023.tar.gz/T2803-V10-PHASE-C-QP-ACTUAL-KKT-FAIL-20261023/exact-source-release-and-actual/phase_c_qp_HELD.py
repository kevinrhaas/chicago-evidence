"""One FUTURE root-released sparse QP; current source is HELD and unexecuted."""
from pathlib import Path
import hashlib, json, sys, time, traceback, warnings
import numpy as np
import scipy
from scipy.sparse import csr_matrix, issparse
from scipy.optimize import minimize, LinearConstraint, Bounds
from smooth_objective_HELD import prepare, check_objective

HERE = Path(__file__).resolve().parent
PRIMAL = 1e-8
KKT = 1e-7


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def feasibility(x, au, bu, ae, be):
    return {'finite': bool(np.isfinite(x).all()),
            'inequality_violation': float(max(0., np.max(au @ x - bu))),
            'simplex_residual': float(np.abs(ae @ x - be).max()),
            'lower_bound_violation': float(max(0., -x.min())),
            'upper_bound_violation': float(max(0., x.max() - 1))}


def primal_pass(metrics):
    return metrics['finite'] and all(value <= PRIMAL for name, value in metrics.items() if name != 'finite')


def kkt_metrics(x, multipliers, h, g, au, bu, ae, be):
    metrics = feasibility(x, au, bu, ae, be)
    if multipliers is None or len(multipliers) != 3:
        return {**metrics, 'multipliers_present': False, 'KKT_pass': False}
    ve, vu, vb = [np.asarray(v) for v in multipliers]
    if ve.shape != be.shape or vu.shape != bu.shape or vb.shape != x.shape:
        return {**metrics, 'multipliers_present': True, 'multiplier_shapes_correct': False, 'KKT_pass': False}
    finite = bool(np.isfinite(ve).all() and np.isfinite(vu).all() and np.isfinite(vb).all())
    station = h @ x + g + ae.T @ ve + au.T @ vu + vb
    stat = float(np.abs(station).max())
    upper_comp = float(np.abs(vu * (au @ x - bu)).max())
    bound_comp = float(max(np.abs(np.maximum(vb, 0) * (x - 1)).max(),
                           np.abs(np.minimum(vb, 0) * x).max()))
    min_dual = float(vu.min())
    passed = (primal_pass(metrics) and finite and stat <= KKT
              and upper_comp <= KKT and bound_comp <= KKT and min_dual >= -KKT)
    return {**metrics, 'multipliers_present': True, 'multiplier_shapes_correct': True,
            'all_multipliers_finite': finite, 'stationarity_residual_inf': stat,
            'upper_inequality_complementarity_inf': upper_comp,
            'box_bound_complementarity_inf': bound_comp,
            'minimum_upper_inequality_multiplier': min_dual, 'KKT_pass': bool(passed)}


def serial(value):
    if issparse(value):
        c = value.tocsr()
        return {'CSR_shape': list(c.shape), 'nnz': int(c.nnz),
                'data': c.data.tolist(), 'indices': c.indices.tolist(), 'indptr': c.indptr.tolist()}
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(v) for v in value]
    return value


def main():
    start = time.monotonic()
    release_path, out = map(Path, sys.argv[1:])
    release = json.loads(release_path.read_text())
    assert release['released'] is True
    assert release['authorization'] == 'ONE_ROOT_RELEASED_V10_PHASE_C_SPARSE_QP'
    for key, file in [('runner_sha256', 'phase_c_qp_HELD.py'),
                      ('objective_sha256', 'smooth_objective_HELD.py'),
                      ('decoder_sha256', 'actual_model.py'),
                      ('pins_sha256', 'INPUT-PINS.json'), ('recipe_sha256', 'QP-RECIPE.json')]:
        assert release[key] == sha(HERE / file), key + ' source drift'
    assert release['maximum_QP_runs'] == 1
    assert release['maximum_iterations'] == 50
    assert release['LP_or_poses_final_skin_export_authorized'] is False
    pins = json.loads((HERE / 'INPUT-PINS.json').read_text())
    problem = prepare(pins)
    h, g, const, x0 = (problem[k] for k in ('H', 'g', 'constant', 'x0'))
    objective_controls = check_objective(problem)
    (out / 'OBJECTIVE-CONTROLS.json').write_text(json.dumps(objective_controls, indent=2) + '\n')
    with np.load(pins['phase_b_matrices']['path'], allow_pickle=False) as f:
        au = csr_matrix((f['a_ub_data'], f['a_ub_indices'], f['a_ub_indptr']), shape=tuple(f['a_ub_shape']))
        ae = csr_matrix((f['a_eq_data'], f['a_eq_indices'], f['a_eq_indptr']), shape=tuple(f['a_eq_shape']))
        bu, be = f['b_ub'].copy(), f['b_eq'].copy()
        assert np.all(f['lower_bounds'] == 0) and np.all(f['upper_bounds'] == 1)
    initial = feasibility(x0, au, bu, ae, be)
    assert primal_pass(initial)
    initial_energy = float(.5 * x0 @ (h @ x0) + g @ x0 + const)
    assert np.isfinite(initial_energy)
    np.savez_compressed(out / 'EXACT-QUADRATIC-OBJECTIVE.npz',
        h_data=h.data, h_indices=h.indices, h_indptr=h.indptr, h_shape=np.asarray(h.shape),
        linear=g, constant=np.asarray(const), initial_lp_witness=x0,
        var_class_ids=problem['var_classes'], var_joint_ids=problem['var_joints'],
        mass=problem['mass'], screen=problem['screen'], conductance=problem['conductance'],
        target_quotient=problem['target_q'])
    assert not kkt_metrics(x0, None, h, g, au, bu, ae, be)['KKT_pass']
    history = []
    best_energy = initial_energy
    best_iteration = None

    def callback(x, state):
        nonlocal best_energy, best_iteration
        metrics = feasibility(x, au, bu, ae, be)
        energy = float(.5 * x @ (h @ x) + g @ x + const)
        row = {'iteration': int(state.niter), 'elapsed_seconds': time.monotonic() - start,
               'energy': energy, 'native_optimality': float(state.optimality),
               'native_constraint_violation': float(state.constr_violation),
               'barrier_parameter': float(state.barrier_parameter),
               'independent_primal': metrics}
        history.append(row)
        with (out / 'ITERATIONS.jsonl').open('a') as f:
            f.write(json.dumps(row) + '\n')
        if primal_pass(metrics) and np.isfinite(energy) and energy < best_energy:
            best_energy, best_iteration = energy, int(state.niter)
            np.savez_compressed(out / 'BEST-FEASIBLE-UNACCEPTED-CHECKPOINT.npz',
                                x=x, energy=energy, iteration=state.niter,
                                var_class_ids=problem['var_classes'], var_joint_ids=problem['var_joints'])
        # Independent outer supervisor remains the actual90s/1GiB hard cap.
        return time.monotonic() - start > 84 or not np.isfinite(energy)

    options = {'maxiter': 50, 'gtol': 1e-8, 'xtol': 1e-10, 'barrier_tol': 1e-8,
               'sparse_jacobian': True, 'factorization_method': 'AugmentedSystem', 'verbose': 0}
    (out / 'QP-INTENT.json').write_text(json.dumps({'QP_runs': 1, 'method': 'trust-constr',
        'options': options, 'no_alternate_solver_or_SVD_fallback': True,
        'LP_reruns': 0, 'initial_primal': initial, 'initial_energy': initial_energy}, indent=2) + '\n')
    result = None
    caught = None
    qp_start = time.monotonic()
    try:
        with warnings.catch_warnings():
            # Abort this method on rank failure; never permit its automatic dense
            # SVD fallback. The exception and traceback remain actual evidence.
            warnings.filterwarnings('error', message='.*Singular Jacobian.*')
            result = minimize(lambda x: float(.5 * x @ (h @ x) + g @ x + const), x0,
                jac=lambda x: h @ x + g, hess=lambda x: h,
                constraints=[LinearConstraint(ae, be, be), LinearConstraint(au, -np.inf, bu)],
                bounds=Bounds(np.zeros(len(x0)), np.ones(len(x0))),
                method='trust-constr', options=options, callback=callback)
    except Exception as error:
        caught = {'type': type(error).__name__, 'message': str(error)}
        traceback.print_exc()
    qp_seconds = time.monotonic() - qp_start
    kkt = None
    final_energy = None
    corrupt_duals_rejected = None
    if result is None:
        status = 'QP_METHOD_EXCEPTION_NO_RETRY'
    else:
        (out / 'SCIPY-COMPLETE-QP-RESULT.json').write_text(json.dumps(serial(dict(result)), indent=2) + '\n')
        kkt = kkt_metrics(result.x, result.v, h, g, au, bu, ae, be)
        final_energy = float(.5 * result.x @ (h @ result.x) + g @ result.x + const)
        # Finite returned vectors are saved as numerical QP evidence only.
        np.savez_compressed(out / 'QP-NUMERICAL-RESULT-NOT-A-SKIN.npz',
                            x=result.x, var_class_ids=problem['var_classes'], var_joint_ids=problem['var_joints'])
        objective_ok = np.isfinite(final_energy) and final_energy <= initial_energy + 1e-8 * max(1., abs(initial_energy))
        accepted_numerically = bool(result.success and result.status == 1 and kkt['KKT_pass'] and objective_ok)
        status = ('SPARSE_QP_NUMERICALLY_CONVERGED_NO_GAIT_ACCEPTANCE' if accepted_numerically else
                  'SPARSE_QP_UNCONVERGED_OR_RESIDUAL_FAIL_NO_RETRY')
        if result.v is not None and len(result.v) == 3:
            bad_v = [np.asarray(v).copy() for v in result.v]
            station = h @ result.x + g + ae.T @ bad_v[0] + au.T @ bad_v[1] + bad_v[2]
            bad_v[2][0] += 2 * abs(float(station[0])) + 1
            corrupt = kkt_metrics(result.x, bad_v, h, g, au, bu, ae, be)
            corrupt_duals_rejected = not corrupt['KKT_pass']
            assert corrupt_duals_rejected
    report = {'status': status, 'QP_runs': 1, 'QP_seconds': qp_seconds,
              'initial_lp_primal': initial, 'initial_energy': initial_energy, 'final_energy': final_energy,
              'best_feasible_unaccepted_energy': best_energy, 'best_unaccepted_iteration': best_iteration,
              'objective_self_consistency': objective_controls, 'independent_primal_KKT': kkt,
              'missing_multiplier_false_success_rejected': True,
              'corrupted_bound_multiplier_rejected': corrupt_duals_rejected,
              'solver_exception': caught, 'native_success': None if result is None else bool(result.success),
              'native_status': None if result is None else int(result.status),
              'native_message': None if result is None else str(result.message),
              'iterations': len(history), 'options': options, 'scipy_version': scipy.__version__,
              'known_raw_rows_sha256_unchanged': problem['known_raw_sha256'],
              'Q_scope': 'Only pinned frozen walk with inherited affine equivalence<1e-7; no independent idle/headtail/clip blending claim.',
              'original_parameters_thresholds_unmodified_uninvoked': True,
              'supports_palettes_fixed_rows_boundaries_edge_caps_unchanged': True,
              'LP_reruns': 0, 'pose_generations_or_checks': 0, 'float32_skins': 0,
              'exports_or_app_ticket_ref_writes': 0, 'next_phase_released': False,
              'scope': 'Numerical fixed-formulation smooth QP only; every previous failure remains a failure. Numerical convergence is not gait, anatomy or photographic acceptance.',
              'elapsed_seconds': time.monotonic() - start}
    (out / 'PHASE-C-REPORT.json').write_text(json.dumps(report, indent=2) + '\n')
    assert sum(p.stat().st_size for p in out.iterdir() if p.is_file()) < 33554432
    print(json.dumps(report), flush=True)
    return 0 if status == 'SPARSE_QP_NUMERICALLY_CONVERGED_NO_GAIT_ACCEPTANCE' else 2


if __name__ == '__main__':
    raise SystemExit(main())
