"""UNEXECUTED anatomical band binding; standard GLB LBS, no optimizer/export.

Precomputed bands must come from reviewed nested intrinsic mesh sections. This
module deliberately does not invent a hoof/coronet landmark or classify geometry
by a bare height/capsule. Incomplete anatomical evidence refuses construction.
"""
import numpy as np


def smooth5(u):
    return u*u*u*(10 + u*(-15 + 6*u))


def build_binding(v10_dense, protected_dense, original_protected, whole_feet,
                  bands, anatomical_receipt):
    """Return dense class vectors + explicit V10-only reclassification ledger.

    Every band contains full-class boolean `members`, intrinsic `u` in [0,1],
    and either `j0`,`j1`, or `upstream_to_proximal`,`j1`. Rings and masks are
    EXTERNAL PREFLIGHT OUTPUTS, not guessed or silently repaired in this function.
    Distal paired bands are a->b, b->c, c->d, d->e on each separate limb.
    `upstream_to_proximal` blends the unchanged V10 body/proximal vector to a.
    Shared section rows appear only once and have the exact common pure joint.
    Original protected vectors always win; a disagreement is a refusal, not an
    override or permission to trim a protected anatomical region.
    """
    assert anatomical_receipt['reviewed_hoof_coronet_landmarks'] is True
    assert anatomical_receipt['all_nested_sections_closed_and_separating'] is True
    assert anatomical_receipt['no_foreign_limb_or_protected_tail_in_bands'] is True
    assert anatomical_receipt['root_authorized_V10_only_pastern_reclassification'] is True
    n,joints=v10_dense.shape
    assert joints==26
    result=v10_dense.copy()
    visited=np.zeros(n,dtype=bool)
    protected=np.asarray(original_protected,dtype=bool)
    for band in bands:
        members=np.asarray(band['members'],dtype=bool)
        assert members.shape==(n,) and not np.any(visited & members)
        visited|=members
        ids=np.flatnonzero(members)
        u=np.asarray(band['u'],dtype=float)
        assert u.shape==(len(ids),) and np.isfinite(u).all()
        assert ((u>=0)&(u<=1)).all(), 'No clipping anatomical coordinates'
        s=smooth5(u)
        proposed=np.zeros((len(ids),joints),dtype=float)
        j1=band['j1']
        if band.get('upstream_to_proximal',False):
            proposed=(1-s[:,None])*v10_dense[ids]
            proposed[:,j1]+=s
        else:
            proposed[:,band['j0']]=1-s
            proposed[:,j1]=s
        hard=protected[ids]
        # Geometry must leave room for every original anchor; no exception mask.
        assert np.array_equal(proposed[hard],protected_dense[ids[hard]]), 'Original protected row conflicts with proposed band'
        result[ids]=proposed
    assert np.array_equal(result[protected],protected_dense[protected])
    assert np.isfinite(result).all() and (result>=0).all()
    assert np.max(np.abs(result.sum(1)-1))<=1e-8
    assert ((result>0).sum(1)<=4).all(), 'No top-four truncation authorized'
    ledger=[]
    for label,ids in whole_feet.items():
        for ci in ids:
            if not np.array_equal(result[ci],v10_dense[ci]):
                assert not protected[ci]
                ledger.append({'limb':label,'class':int(ci),
                               'before':v10_dense[ci].tolist(),
                               'after':result[ci].tolist(),
                               'reason':'V10-added non-original protected pastern row; reviewed coronet/segment band',
                               'anatomical_receipt_sha256':anatomical_receipt['sha256']})
    # The serializer must preserve raw source per-vertex tail slots/weight bits,
    # not a class representative; this function never touches a model file.
    return result,ledger
