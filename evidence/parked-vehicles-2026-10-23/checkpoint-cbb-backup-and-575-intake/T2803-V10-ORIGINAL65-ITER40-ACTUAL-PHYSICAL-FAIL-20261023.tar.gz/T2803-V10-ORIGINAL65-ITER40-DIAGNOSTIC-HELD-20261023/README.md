# Exact iter40 field — original65pose diagnostic, HELD

This packet has not imported numerical modules, generated arrays or evaluated poses. It prepares a separate physical diagnostic; it does not retry or erase the QP certificate failure. The source field is exactly the saved final/bestfeasible40 vector, with no new optimization or tolerance change.

The original checker core from def skin through mechanics/deformation and meaningful negative controls is byte-identical to the old V8 checker. The neutral/stance/full-surface edge/area/normal/ground/seam/loop formulas, all65sample times and original failure-exit line are unchanged. ORIGINAL-CHECKER-CORE-BYTE-PROOF.json and the import/metadata-only patch provide exact hashes and readable differences. The original gait module and tail fixture are unchanged copies.

The loader rebuilds the exact pinned knownclassvectors and fixedpalettes, assigns the savedfloat64 field, and preserves all absent channels as zero. Stable ascending joint slots undergo one value-changing float32cast, with no ranking, pruning, clipping or renormalization. It then restores the isolated original tail's exact pervertex slots and float32weightbits, including source UV duplicates; this is the same approved source exception, not a new normalized tail. No raw known weights are relabelled through the co-motion quotient.

Serialization evidence reports actual cast errors, originalf64 LPprimal checks, actualf32 linear/simplex/mass/gradient residuals and verified absolute-matrix/endpoint roundoff envelopes. It does not waive an LP/QP limit or claim certificatePASS; original physical checks independently measure the actual serialized arrays. Tail class-representative reporting is explicitly separate from exact pervertex source restoration.

The proposed owned run is one30second/512MiB nice19/math1 diagnostic, with no solver, browser, model/GLB/animation export or app/ticket/Git action. Source/refusal/resource/incomplete-check errors stay errors with raw logs and no retry. Even a physical diagnosticPASS leaves prior QPcertificateFAIL, walk_acceptedFalse and visual/anatomical/GLTFLoader/interactive acceptance open. No next phase or activation follows automatically.

Root must separately verify exact hashes, approved existing interpreter and free heavy lane before copying RELEASE-TEMPLATE-HELD.json to a true release. Current approved path is historical venv311/bin/python, independently observed3.11.17 by root. No execution is currently released.
