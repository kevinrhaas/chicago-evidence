"""Owned one-shot original65pose diagnostic supervisor: 30s wall/512MiB RSS; no next phase."""
from pathlib import Path
import datetime, hashlib, json, os, resource, signal, subprocess, sys, time

HERE = Path(__file__).resolve().parent
PYTHON = '/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    release_path = Path(sys.argv[1]).resolve()
    release = json.loads(release_path.read_text())
    assert release['released'] is True
    assert release['authorization'] == 'ONE_ROOT_AUTHORIZED_V10_ITER40_ORIGINAL65_DIAGNOSTIC'
    for key, filename in [('supervisor_sha256', 'run_once_HELD.py'),
                          ('caller_sha256', 'prove_original65_iter40_HELD.py'),
                          ('candidate_sha256', 'fixed_iter40_field_HELD.py'),
                          ('tail_fixture_sha256', 'PROVED-TAIL-COMPONENT.json'),
                          ('decoder_sha256', 'actual_model.py'),
                          ('walk_source_sha256', 'walk_source.py'),
                          ('controls_sha256', 'RERIG-CONTROLS-PROPOSAL-V2.json'),
                          ('core_proof_sha256', 'ORIGINAL-CHECKER-CORE-BYTE-PROOF.json'),
                          ('pins_sha256', 'INPUT-PINS.json'),
                          ('recipe_sha256', 'DIAGNOSTIC-RECIPE.json')]:
        assert release[key] == sha(HERE / filename), key + ' drift'
    assert release['maximum_runs'] == 1 and release['maximum_65pose_diagnostics'] == 1
    assert release['maximum_wall_seconds'] == 30
    assert release['maximum_rss_bytes'] == 512 * 1024 * 1024
    assert release['solver_model_export_app_or_activation_authorized'] is False
    assert not (HERE / 'ACTUAL').exists(), 'One-shot output exists; no rerun authorized'
    out = HERE / 'ACTUAL'
    out.mkdir()
    (out / 'ROOT-RELEASE.json').write_text(json.dumps(release, indent=2) + '\n')
    intent = {'started_utc': utc(), 'one_shot': True, 'released_phase': 'ORIGINAL65POSE_ITER40_DIAGNOSTIC_ONLY',
              'wall_limit_seconds': 30, 'rss_limit_bytes': 512 * 1024 * 1024,
              'maximum_65pose_diagnostics': 1, 'solver_calls': 0,
              'math_threads': 1, 'nice': 19, 'automatic_next_phase': False}
    (out / 'INTENT.json').write_text(json.dumps(intent, indent=2) + '\n')
    env = os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
               NUMEXPR_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    start = time.monotonic()
    peak = 0
    stopped = None
    with (out / 'stdout.log').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
        process = subprocess.Popen(['nice', '-n', '19', PYTHON, str(HERE / 'prove_original65_iter40_HELD.py'),
                                    str(release_path)], cwd=HERE, env=env,
                                   stdout=stdout, stderr=stderr, start_new_session=True)
        while process.poll() is None:
            try:
                for line in (Path('/proc') / str(process.pid) / 'status').read_text().splitlines():
                    if line.startswith('VmRSS:'):
                        peak = max(peak, int(line.split()[1]) * 1024)
            except FileNotFoundError:
                pass
            if time.monotonic() - start > 30:
                stopped = 'WALL_LIMIT_30_SECONDS'
            elif peak > 512 * 1024 * 1024:
                stopped = 'RSS_LIMIT_512_MiB'
            if stopped:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                break
            time.sleep(.025)
        code = process.wait()
    peak = max(peak, int(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss) * 1024)
    if peak > 512 * 1024 * 1024:
        stopped = stopped or 'KERNEL_PEAK_RSS_EXCEEDED_512_MiB'
    elapsed = time.monotonic() - start
    if elapsed > 30:
        stopped = stopped or 'ELAPSED_LIMIT_EXCEEDED_30_SECONDS'
    report_path = out / 'ACTUAL-WALK-WEIGHT-V10-DIAGNOSTIC-CPU-READBACK.json'
    report = json.loads(report_path.read_text()) if report_path.exists() else None
    status = ('RESOURCE_LIMIT_FAIL_NO_RETRY' if stopped else
              ('ORIGINAL65POSE_PHYSICAL_DIAGNOSTIC_PASS_QP_CERTIFICATE_STILL_FAIL' if report['mechanics_pass'] and report['deformation_screen_pass'] and code == 0 else 'ORIGINAL65POSE_PHYSICAL_DIAGNOSTIC_FAIL_QP_CERTIFICATE_STILL_FAIL') if report is not None and code in (0, 2) else
              'DIAGNOSTIC_SOURCE_OR_INCOMPLETE_CHECK_ERROR_NO_RETRY')
    terminal = {'status': status, 'finished_utc': utc(), 'exit_code': code,
                'elapsed_seconds': elapsed, 'actual_peak_rss_bytes': peak,
                'resource_failure': stopped, 'runs': 1, 'reruns': 0,
                'caller_sha256': release['caller_sha256'],
                'supervisor_sha256': release['supervisor_sha256'],
                'report_present': report is not None,
                'solvers_run': 0,
                'original65_pose_samples': 65 if report is not None else None,
                'QP_certificate_pass': False,
                'walk_accepted': False,
                'no_owned_child_active': True,
                'GLB_model_export_app_or_next_phase_executions': 0,
                'visual_or_activation_released': False}
    (out / 'TERMINAL.json').write_text(json.dumps(terminal, indent=2) + '\n')
    print(json.dumps(terminal), flush=True)
    return 0 if status == 'ORIGINAL65POSE_PHYSICAL_DIAGNOSTIC_PASS_QP_CERTIFICATE_STILL_FAIL' and code == 0 else 2


if __name__ == '__main__':
    raise SystemExit(main())
