"""HELD fixed-field diagnostic loader; no solve, clipping, pruning or renorm.

Only a separate root release can run the original65pose diagnostic. The prior
QP independent certificate remains FAIL even if these physical screens pass.
"""
from pathlib import Path
import hashlib, json, sys
import numpy as np
from scipy.sparse import csr_matrix

HERE = Path(__file__).resolve().parent
OUT = HERE / 'ACTUAL'
ELL = 0.3263955630216535


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def quotient(weights):
    q = weights.copy()
    q[..., 1] += q[..., 2:6].sum(axis=-1)
    q[..., 2:6] = 0
    return q


def original_joint_ownership(source_weights):
    owned_strength = np.max(source_weights[:, 2:6], axis=1)
    competing_strength = np.max(source_weights[:, [0, 1] + list(range(6, 26))], axis=1)
    return owned_strength > competing_strength, (owned_strength == competing_strength) & (owned_strength > 0)


def build(rest, parts, controls, hoof_patch_ids):
    release = json.loads(Path(sys.argv[1]).read_text())
    assert release['released'] is True
    assert release['authorization'] == 'ONE_ROOT_AUTHORIZED_V10_ITER40_ORIGINAL65_DIAGNOSTIC'
    assert release['candidate_sha256'] == sha(__file__)
    assert release['pins_sha256'] == sha(HERE / 'INPUT-PINS.json')
    assert release['recipe_sha256'] == sha(HERE / 'DIAGNOSTIC-RECIPE.json')
    pins = json.loads((HERE / 'INPUT-PINS.json').read_text())
    for name, row in pins.items():
        assert sha(row['path']) == row['sha256'], name + ' source drift'
    c = json.loads(Path(pins['phase_c_report']['path']).read_text())
    assert c['native_success'] and c['native_status'] == 1 and c['iterations'] == 40
    assert c['status'] == 'SPARSE_QP_UNCONVERGED_OR_RESIDUAL_FAIL_NO_RETRY'
    assert c['independent_primal_KKT']['KKT_pass'] is False
    assert c['best_unaccepted_iteration'] == 40
    with np.load(pins['phase_c_vector']['path'], allow_pickle=False) as f:
        x = f['x'].copy()
        vi, vj = f['var_class_ids'].copy(), f['var_joint_ids'].copy()
    with np.load(pins['phase_c_best40']['path'], allow_pickle=False) as f:
        assert int(f['iteration']) == 40 and np.array_equal(x, f['x'])
        assert np.array_equal(vi, f['var_class_ids']) and np.array_equal(vj, f['var_joint_ids'])
    assert np.isfinite(x).all() and np.all(x >= 0) and np.all(x <= 1)
    x_sha = hashlib.sha256(x.tobytes()).hexdigest()
    with np.load(pins['phase_a_arrays']['path'], allow_pickle=False) as f:
        points = f['points_m'].copy()
        vc = [f['vertex_classes_' + str(i)].copy() for i in range(3)]
        allowed, fixed = f['fixed_palette_allowed'].copy(), f['fixed_rows'].copy()
        known_ids, known_rows = f['declared_known_class_ids'].copy(), f['declared_known_vectors'].copy()
        edges, lengths = f['edges'].copy(), f['edge_lengths_m'].copy()
    assert np.array_equal(known_ids, np.flatnonzero(fixed))
    assert all(np.array_equal(points[vc[mi]], ps) for mi, ps in enumerate(rest))
    expected_i, expected_j = np.nonzero(allowed & ~fixed[:, None])
    assert np.array_equal(expected_i, vi) and np.array_equal(expected_j, vj)
    known = np.zeros((len(points), 26))
    known[known_ids] = known_rows
    known_sha = hashlib.sha256(known.tobytes()).hexdigest()
    dense64 = known.copy()
    dense64[vi, vj] = x
    assert np.array_equal(dense64[known_ids], known_rows)
    assert not np.count_nonzero(dense64[~allowed])
    assert np.all(dense64 >= 0) and np.all(dense64 <= 1)
    assert np.all(allowed.sum(1) <= 4)
    # Exactly one f64 -> f32 cast, with stable declared joint slots. No ranking.
    dense32 = dense64.astype(np.float32)
    assert np.isfinite(dense32).all() and np.all(dense32 >= 0) and np.all(dense32 <= 1)
    joints = np.zeros((len(points), 4), dtype=np.uint16)
    weights = np.zeros((len(points), 4), dtype=np.float32)
    for ci, mask in enumerate(allowed):
        palette = np.flatnonzero(mask)
        assert len(palette) <= 4
        joints[ci, :len(palette)] = palette
        weights[ci, :len(palette)] = dense32[ci, palette]
    recovered = np.zeros_like(dense32)
    np.add.at(recovered, (np.arange(len(points))[:, None], joints), weights)
    assert np.array_equal(recovered, dense32)
    assert np.array_equal(recovered[known_ids], known_rows.astype(np.float32))
    assert hashlib.sha256(known.tobytes()).hexdigest() == known_sha
    arrays = [(joints[classes].astype(int), weights[classes].copy()) for classes in vc]
    fixture = json.loads((HERE / 'PROVED-TAIL-COMPONENT.json').read_text())
    tail_vertices = np.asarray(fixture['exact_source_vertex_ids'], dtype=int)
    tail_classes = np.unique(vc[0][tail_vertices])
    assert len(tail_vertices) == 969 and len(tail_classes) == 901
    assert all(not np.intersect1d(tail_classes, vc[1][ids]).size for ids in hoof_patch_ids.values())
    # Approved original-source exception: restore exact per-vertex tail slots,
    # not the class representative's normalized/cast approximation.
    tail_restorations = []
    representative_after_tail = dense32.astype(float)
    for mi in range(len(parts)):
        ids = np.flatnonzero(np.isin(vc[mi], tail_classes))
        if len(ids):
            assert mi == 0
        arrays[mi][0][ids] = parts[mi][2][ids]
        arrays[mi][1][ids] = parts[mi][3][ids]
        assert np.array_equal(arrays[mi][0][ids], parts[mi][2][ids])
        assert np.array_equal(arrays[mi][1][ids], parts[mi][3][ids])
        assert np.array_equal(arrays[mi][1][ids].view(np.uint32),
                              parts[mi][3][ids].astype(np.float32).view(np.uint32))
        tail_restorations.append({'mesh': mi, 'vertices': int(len(ids)),
                                  'joint_slots_and_source_weight_values_exact': True})
    seen = set()
    for vertex in tail_vertices:
        ci = int(vc[0][vertex])
        if ci in seen:
            continue
        seen.add(ci)
        representative_after_tail[ci] = 0
        np.add.at(representative_after_tail[ci], parts[0][2][vertex], parts[0][3][vertex])
    with np.load(pins['phase_b_matrices']['path'], allow_pickle=False) as f:
        au = csr_matrix((f['a_ub_data'], f['a_ub_indices'], f['a_ub_indptr']), shape=tuple(f['a_ub_shape']))
        ae = csr_matrix((f['a_eq_data'], f['a_eq_indices'], f['a_eq_indptr']), shape=tuple(f['a_eq_shape']))
        bu, be = f['b_ub'].copy(), f['b_eq'].copy()
        assert np.array_equal(vi, f['var_class_ids']) and np.array_equal(vj, f['var_joint_ids'])
    residual64 = au @ x - bu
    simplex64 = ae @ x - be
    assert residual64.max() <= 1e-8 and np.abs(simplex64).max() <= 1e-8
    x32 = dense32[vi, vj].astype(float)
    dx = np.abs(x32 - x)
    assert dx.max() <= np.finfo(np.float32).eps
    abs_au = au.copy()
    abs_au.data = np.abs(abs_au.data)
    abs_ae = ae.copy()
    abs_ae.data = np.abs(abs_ae.data)
    residual32 = au @ x32 - bu
    simplex32 = ae @ x32 - be
    assert np.all(residual32 <= residual64 + abs_au @ dx + 2e-15)
    assert np.all(np.abs(simplex32) <= np.abs(simplex64) + abs_ae @ dx + 2e-15)
    q64, q32 = quotient(dense64), quotient(dense32.astype(float))
    u, v = edges.T
    direct64 = np.abs(q64[v] - q64[u]) - lengths[:, None] / ELL
    direct32 = np.abs(q32[v] - q32[u]) - lengths[:, None] / ELL
    rounding = np.abs(q32 - q64)
    assert np.all(direct32 <= direct64 + rounding[u] + rounding[v] + 2e-15)
    mass64 = np.abs(dense64.sum(1) - 1)
    mass32 = np.abs(dense32.astype(float).sum(1) - 1)
    assert np.all(mass32 <= mass64 + np.abs(dense32.astype(float) - dense64).sum(1) + 2e-15)
    for label, ids in hoof_patch_ids.items():
        own = controls['limbs'][label]['joints'][-1]
        assert np.all(np.where(arrays[1][0][ids] == own, arrays[1][1][ids], 0).sum(1) == 1)
    receipt = {'status': 'FIXED ITER40 DIAGNOSTIC ARRAYS ONLY; QP CERTIFICATE FAIL REMAINS',
        'QP_certificate_pass': False, 'QP_native_converged': True, 'source_iteration': 40,
        'source_f64_x_sha256': x_sha, 'final_equals_best40_exact': True,
        'known_f64_class_vectors_exact_sha256': known_sha,
        'known_class_f32_values_exact_single_cast_before_source_tail_restore': True,
        'tail_source_restorations': tail_restorations,
        'stable_joint_index_palette_no_rank_pruning': True, 'f64_to_f32_casts': 1,
        'clipping_or_renormalization': False,
        'max_unknown_cast_error_abs': float(dx.max()),
        'max_all_class_cast_error_abs': float(np.abs(dense32.astype(float) - dense64).max()),
        'f64_LP_inequality_violation': float(max(0., residual64.max())),
        'f64_LP_simplex_residual': float(np.abs(simplex64).max()),
        'f32_variable_LP_inequality_violation_with_original_constants': float(max(0., residual32.max())),
        'f32_variable_LP_simplex_residual': float(np.abs(simplex32).max()),
        'f32_full_class_gradient_cap_violation_before_tail_restore': float(max(0., direct32.max())),
        'f32_full_class_mass_residual_before_tail_restore': float(mass32.max()),
        'post_tail_representative_class_gradient_cap_violation': float(max(0., (np.abs(quotient(representative_after_tail)[v] - quotient(representative_after_tail)[u]) - lengths[:, None] / ELL).max())),
        'actual_roundoff_envelopes_verified': True,
        'roundoff_scope': 'Reports actual cast errors and exact absolute-matrix envelopes, not a tolerance waiver or QP/LP PASS. Per-vertex original-tail exception is exact source restoration; original65pose checks judge full actual arrays.',
        'gait_thresholds_or_sample_times_changed': False, 'solver_runs': 0,
        'model_exports': 0, 'automatic_activation': False}
    np.savez_compressed(OUT / 'DIAGNOSTIC-FLOAT32-ARRAYS-NOT-MODEL-EXPORT.npz',
        **{'mesh_' + str(mi) + '_' + key: values.astype(dtype, copy=False)
           for mi, pair in enumerate(arrays)
           for key, values, dtype in [('joints', pair[0], np.uint16), ('weights', pair[1], np.float32)]})
    (OUT / 'SERIALIZATION-AND-QUANTIZATION-READBACK.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return arrays, receipt
