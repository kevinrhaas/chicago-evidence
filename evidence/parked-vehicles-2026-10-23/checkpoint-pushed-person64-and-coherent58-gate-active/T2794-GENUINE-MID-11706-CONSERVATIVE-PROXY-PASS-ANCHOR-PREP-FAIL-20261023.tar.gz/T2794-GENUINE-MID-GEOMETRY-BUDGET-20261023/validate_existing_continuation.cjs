const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const base='/workspace/shared/T2794-V17-GENUINE-RING16-MID-CANDIDATE-20261022';
const pins=JSON.parse(fs.readFileSync(path.join(base,'VALIDATOR-PINS.json')));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const[f,h]of Object.entries(pins.files))if(sha(fs.readFileSync(path.join(base,'validator',f)))!==h)throw Error('Pinned Khronos input drift');
const validator=require(path.join(base,'validator/index.js'));if(validator.version()!==pins.version)throw Error('Pinned validator version drift');
(async()=>{for(const[label,file]of [['raw',process.argv[3]],['indexed',process.argv[4]]]){
 const p=file,bytes=fs.readFileSync(p),report=await validator.validateBytes(new Uint8Array(bytes),{uri:path.basename(p),maxIssues:1000});
 fs.writeFileSync(path.join(process.argv[2],'KHRONOS-'+label+'.json'),JSON.stringify(report,null,2)+'\n');
 if(report.issues.numErrors||report.issues.numWarnings||report.issues.truncated||report.info.totalTriangleCount!==11706)throw Error('Candidate Khronos FAIL '+label);
 console.log(JSON.stringify({label,sha256:sha(bytes),triangles:report.info.totalTriangleCount,errors:report.issues.numErrors,warnings:report.issues.numWarnings,infos:report.issues.numInfos}));
}})().catch(e=>{console.error(e.stack);process.exitCode=1});
