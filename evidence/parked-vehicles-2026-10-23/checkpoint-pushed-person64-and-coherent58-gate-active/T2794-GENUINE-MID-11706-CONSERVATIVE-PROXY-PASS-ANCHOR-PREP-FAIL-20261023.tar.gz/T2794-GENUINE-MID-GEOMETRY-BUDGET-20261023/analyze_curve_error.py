# SPDX-License-Identifier: GPL-3.0-or-later
# Read-only analytic source-curve sampling, not mesh generation or validation.
from pathlib import Path
import json,math,hashlib
P=Path('/tmp/chicago-covered-sag/chicago/4d/tools/transport/brougham/parameters.json');p=json.loads(P.read_bytes());q=p['roof_longitudinal_profile_z_y_m'];scale=p['body_vertical_affine']['scale_y']
def curve(i,t):
 a,b,c,d=q[max(0,i-1)],q[i],q[i+1],q[min(len(q)-1,i+2)]
 v=[.5*(2*b[k]+(-a[k]+c[k])*t+(2*a[k]-5*b[k]+4*c[k]-d[k])*t*t+(-a[k]+3*b[k]-3*c[k]+d[k])*t*t*t)for k in range(2)]
 return [v[0],v[1]*scale]
def distance(v,a,b):
 d=[b[k]-a[k]for k in range(2)];l=sum(x*x for x in d);t=max(0,min(1,sum((v[k]-a[k])*d[k]for k in range(2))/l));return math.dist(v,[a[k]+t*d[k]for k in range(2)])
rows=[]
for n in [1,2,3,5]:
 worst=(0,None)
 for i in range(len(q)-1):
  samples=[curve(i,k/n)for k in range(n+1)]
  for k in range(1001):
   t=k/1000;cell=min(n-1,int(t*n));v=curve(i,t);error=distance(v,samples[cell],samples[cell+1])
   if error>worst[0]:worst=(error,{'source_interval':i,'t':t,'position_z_y_m':v})
 rows.append({'longitudinal_steps':n,'dense_samples_per_interval':1001,'maximum_sampled_curve_to_chord_m':worst[0],'witness':worst[1],'cross6_quadratic_crown_error_bound_m':scale*p['roof_cross_crown_m']/36,'sum_error_m':worst[0]+scale*p['roof_cross_crown_m']/36})
wheel=.65*(1-math.cos(math.pi/16));ppu=.5/wheel
report={'scope':'Static source-parameter analytic geometry study only; no GLB/candidate produced, no validation/browser/world pass','parameters_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'existing_selector_wheel_chord_m':wheel,'existing_selector_maximum_pixels_per_metre_at_reserved_closest_depth':ppu,'roof_sampling':rows,'other_source_error_bounds':{'tube4_maximum_body_affine_error_m':.015*(1-math.cos(math.pi/4))*scale,'hub_cross6_axial_ellipse_bound_m':.064*(1-math.cos(math.pi/6)),'nonhub_cross4_maximum_ellipse_bound_m':.0205*(1-math.cos(math.pi/4)),'hub8_maximum_radius_chord_m':.042*(1-math.cos(math.pi/8)),'spring5_root_parabolic_chord_m':(.105/.34**2)*(.68/4)**2/4,'rear4x6_quadratic_sin_estimate_m':None},'limits':['Roof values are densely sampled maxima, not interval-certified suprema','Cross/radial errors are incremental relative to existing ring16 geometry; do not independently certify combined near-mid silhouette bound','Native all4-view comparison and world frame proof remain required','No caps/cameras/distance thresholds changed']}
for r in report['roof_sampling']:r['sum_error_pixels_bound_at_existing_selector']=r['sum_error_m']*ppu
for key,val in report['other_source_error_bounds'].items():
 if val is not None:report.setdefault('incremental_pixel_error_bounds',{})[key]=val*ppu
out=Path(__file__).with_name('ANALYTIC-SOURCE-ERROR.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
