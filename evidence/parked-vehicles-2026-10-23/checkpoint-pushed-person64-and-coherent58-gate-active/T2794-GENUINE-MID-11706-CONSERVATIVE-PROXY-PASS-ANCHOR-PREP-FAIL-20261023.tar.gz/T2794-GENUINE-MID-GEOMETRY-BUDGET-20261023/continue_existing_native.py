# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import collections,copy,datetime,hashlib,json,os,subprocess,sys,time,traceback
R=Path(__file__).resolve().parent; S=R/'candidate-one'; O=R/'ACTUAL-INDEPENDENT-CONTINUATION-20261023'
O.mkdir(exist_ok=False); START=time.monotonic(); DEADLINE=START+13
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,value):(O/name).write_text(json.dumps(value,indent=2)+'\n')
def run(name,argv):
    remaining=DEADLINE-time.monotonic();assert remaining>0,'Unit absolute deadline reached'
    p=subprocess.run(argv,capture_output=True,timeout=remaining)
    (O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr)
    assert p.returncode==0,(name,p.returncode,p.stderr.decode(errors='replace'))
    return p
result={'status':'RUNNING','started_utc':utc(),'pid':os.getpid(),'maximum_seconds':13,'browser':False,'app_writes':False,'retries':0}
save('START.json',result)
try:
    pins=json.loads((R/'FROZEN-SOURCE-MANIFEST.json').read_bytes())['files']
    for row in pins:
        if row['file'].startswith(('candidate-one/','original/')):assert sha(R/row['file'])==row['sha256'],row['file']
    baseline=Path('/tmp/chicago-covered-sag/chicago/4d/renderers/web/transport/parked-brougham/brougham-source.glb')
    assert sha(baseline)=='b74e00937871eef8666fe048501456a8409b18df185c87a0905b083b7a2448fa'
    save('ACTUAL-INPUT-PINS.json',{'files':{str(p):sha(p)for p in [*S.glob('*'),*list((R/'native-helpers').glob('*.py')),baseline]if p.is_file()},'frozen_capsule_sha256':'12d7c00800cdef173b3eff72d10e10e40d98771678643f78451e0ee917ace497'})
    # Existing pinned payload only; no generator invocation or changed candidate.
    G=R/'ACTUAL-ONE-UNIT-20261023'
    near=G/'generated-near/brougham.glb'
    assert sha(near)==sha(baseline)
    assert sha(G/'generated-mid/brougham.glb')=='48a9224ba38da8a1beb809f6970a7d51801da8d032332a52da4b60590c44102f'
    assert sha(G/'brougham-mid.glb')=='d6d6709ec4dda73e84a916e71dfb9dba6ad16961423a4f3babebdf58363c20d2'
    sys.path[:0]=[str(S),str(R/'native-helpers')]
    from index_streams import write_indexed
    from check_near import read,expanded,world_nodes,decoded_bounds,native_contacts
    from check_mid import bind_parts
    from static_master import static_master_contract
    raw=G/'generated-mid/brougham.glb';indexed=G/'brougham-mid.glb'
    old,ob=read(near);new,nb=read(raw);idx,ib=read(indexed)
    a,b=expanded(new,nb),expanded(idx,ib);assert a==b and a[1]==11706
    for key in ['nodes','materials','scenes','scene','extensionsUsed']:assert old.get(key)==new.get(key)==idx.get(key),key
    assert len(new['nodes'])==42 and len(new['meshes'])==25 and len(new['materials'])==7
    for key in old['extras']:
        if key not in ['statistics','parts']:assert old['extras'][key]==new['extras'][key],key
    before=bind_parts(old,ob);after=bind_parts(new,nb);assert len(before)==468 and len(after)==302
    categories=lambda d:collections.Counter(x['identity'][0]for x in d)
    bc,nc=categories(before),categories(after);assert set(bc)==set(nc)
    assert {k:(bc[k],nc[k])for k in bc if bc[k]!=nc[k]}=={'leaf_spring':(160,64),'roof_edge_fascia':(110,40)}
    assert nc['tapered_rounded_spoke']==64 and nc['leaf_spring']==16*(5-1)
    predicted=json.loads((R/'PROPOSED-ONE-RECIPE-COUNTS.json').read_bytes())['categories'];targets={x['name']:x['predicted_new_triangles']for x in predicted}
    # Narrow correction of the three preexisting late fittings only; original
    # formula failure remains FAIL and all source/payload bytes remain unchanged.
    targets.update(source_near_forward_oval_latch=512,
                   source_near_central_open_fitting=396,
                   source_near_central_fitting_prong=132)
    actual=collections.Counter()
    for p in new['extras']['parts']:actual[p['name']]+=p['triangles']
    assert dict(actual)==targets,'Generated category count drift from frozen algebra'
    near_categories=collections.Counter()
    for p in old['extras']['parts']:near_categories[p['name']]+=p['triangles']
    # Comparison is fresh near33502 versus candidate11706, not the intermediate
    # ring16mid22238 used in the incremental cost sheet.
    changed={name for name,count in targets.items()if near_categories[name]!=count}

    def protected(rows):
        out=[]
        for row in rows:
            if row['identity'][0]not in changed:out.append((row['identity'],row['node_path'],row['chunks']))
        return out
    assert protected(before)==protected(after),'Unchanged physical feature stream changed'
    ow,nw=world_nodes(old),world_nodes(new);assert ow==nw
    before_bounds=decoded_bounds(old,ob,ow);after_bounds=decoded_bounds(new,nb,nw)
    assert before_bounds==after_bounds==decoded_bounds(idx,ib,world_nodes(idx)),'Outer dimensions changed'
    old_contacts=native_contacts(old,ob);new_contacts=native_contacts(new,nb)
    assert old_contacts==new_contacts==native_contacts(idx,ib),'Actual wheel/shoe contacts changed'
    old_static=static_master_contract(old,ob,ow,sha(near));new_static=static_master_contract(new,nb,nw,sha(raw))
    old_static['source_master_sha256']=new_static['source_master_sha256']
    assert old_static==new_static,'Static targets/seats/entries/collision bounds changed'
    assert len(new_static['named_targets'])==13
    # Real in-memory negative controls, leaving all source and delivery files intact.
    shifted=copy.deepcopy(new);anchor=next(i for i,n in enumerate(shifted['nodes'])if n['name']=='vehicle_hitch_team');shifted['nodes'][anchor]['translation'][0]+=.001
    assert world_nodes(shifted)!=nw
    assert expanded(old,ob)[1]!=11706
    save('ACTUAL-NATIVE-CHECK.json',{'pass':True,'near_byte_exact_sha256':sha(near),'raw_sha256':sha(raw),'indexed_sha256':sha(indexed),'expanded_PN_sha256':a[0],'triangles':a[1],'subdivision_records_before':len(before),'subdivision_records_after':len(after),'physical_names_preserved':sorted(bc),'actual_category_triangle_counts':dict(actual),'unchanged_physical_feature_PN_exact':True,'parameters_and_source_reference_exact':True,'materials_exact':7,'hierarchy_nodes_exact':42,'native_meshes':25,'anchors_exact':13,'bounds_exact':after_bounds,'contacts_exact':new_contacts,'static_master_only_source_hash_differs':True,'negative_controls':{'anchor_shift_detected':True,'near_copy_not_mid':True},'world_budget_accepted':False,'appearance_or_photographic_accepted':False})
    run('03-khronos',[os.environ.get('NODE_BINARY','node'),str(R/'validate_existing_continuation.cjs'),str(O),str(raw),str(indexed)])
    result.update(status='PASS_EXISTING_PAYLOAD_NATIVE_ONLY_ORIGINAL_UNIT_REMAINS_FAIL',exit_code=0,raw_sha256=sha(raw),indexed_sha256=sha(indexed),triangles=11706,near_byte_exact=True,generator_invocations=0,original_whole_unit_status='FAIL_NO_RETRY')
except BaseException as e:
    result.update(status='FAIL_NO_RETRY',exit_code=1,error=repr(e),traceback=traceback.format_exc());print(result['traceback'],file=sys.stderr)
finally:
    result.update(ended_utc=utc(),seconds=round(time.monotonic()-START,6),owned_subprocesses_active=False)
    save('TERMINAL.json',result);print(json.dumps(result),flush=True)
sys.exit(result['exit_code'])
