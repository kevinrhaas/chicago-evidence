from pathlib import Path
import subprocess,os,json,datetime,hashlib,shutil
out=Path(__file__).parent;app=Path('/workspace/chicago/chicago/4d');repo=app.parents[1]
env=os.environ.copy();env['PATH']='/workspace/shared/node22-runtime-acquisition-20261022/node-v22.23.4-linux-x64/bin:/workspace/shared/chicago-tools/usr/bin:/workspace/shared/chicago-venv/bin:'+env['PATH']
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:env[name]='1'
env.update(C4D_GATE_REQUIRE_READERS='1',CHECK_JOBS='4',CHECK_TIMINGS=str(out/'FULL-PREFLIGHT-TIMINGS.tsv'),BASE='refs/chicago-snapshots/dev-b6eb3e-20261023')
def g(*a):return subprocess.check_output(['git',*a],cwd=repo).decode().strip()
assert g('rev-parse','HEAD')=='3f73940923d6cd1883334e7170e1b5e78245a7c6'
assert g('rev-parse','MERGE_HEAD')=='b6eb3e5fee325dc8c65380afa1f1d1b6c7985a59'
assert not g('diff','--name-only','--diff-filter=U')
assert not g('diff','--name-only')
assert not (out/'PREFLIGHT-START.json').exists(),'One preflight already attempted; never silently retry'
start={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner_pid':os.getpid(),'head':g('rev-parse','HEAD'),'merge_head':g('rev-parse','MERGE_HEAD'),'branch':g('branch','--show-current'),'staged_tree_before':g('write-tree'),'base':env['BASE'],'reviewed_base_sha':g('rev-parse',env['BASE']),'origin_dev_before':g('rev-parse','refs/remotes/origin/dev'),'command':['bash','tools/preflight.sh'],'CHECK_JOBS':4,'C4D_GATE_REQUIRE_READERS':1,'math_threads':1,'PATH':env['PATH'],'python_version':subprocess.check_output(['python3','--version'],env=env).decode().strip(),'node_version':subprocess.check_output(['node','--version'],env=env).decode().strip(),'automatic_retry':False,'outer_timeout':False}
(out/'PREFLIGHT-START.json').write_text(json.dumps(start,indent=2)+'\n');print(json.dumps(start),flush=True)
with(out/'FULL-PREFLIGHT.log').open('wb')as log:r=subprocess.run(start['command'],cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
for name in ['preflight-check.log','preflight-cl.log','preflight-ids.log']:
 p=Path('/tmp')/name
 if p.is_file():shutil.copy2(p,out/name)
result={'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':r.returncode,'head':g('rev-parse','HEAD'),'merge_head':g('rev-parse','MERGE_HEAD'),'staged_tree_after':g('write-tree'),'unstaged_paths':g('diff','--name-only').splitlines(),'origin_dev_after':g('rev-parse','refs/remotes/origin/dev'),'full_log_sha256':hashlib.sha256((out/'FULL-PREFLIGHT.log').read_bytes()).hexdigest()}
(out/'PREFLIGHT-EXIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(r.returncode)
