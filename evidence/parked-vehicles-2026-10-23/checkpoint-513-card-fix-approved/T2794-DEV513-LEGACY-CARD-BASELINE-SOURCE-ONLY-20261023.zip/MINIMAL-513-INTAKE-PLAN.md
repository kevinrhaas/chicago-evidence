# Minimal dev513 intake and independent legacy fixture proposal

Current app HEAD is clean pushed `13375406538e76e8c1deadf18165089f7145ea28`. The reviewed incoming commit is `5135fb7674eea8cf5b140a7cf0c8bc208b0b1f4e`. No app, index, HEAD, published output or shared origin/dev change was made by this investigation. No merge, gate, publication or browser was run.

## Concrete cause and independent expected output

The actual GitHub test-merge failure at checkout365/tree992/[a3,133] is a single raw popup HTML hash mismatch. Exact upstream513 popup/import modules and its own parked-card adapter were extracted by Git blob, separately from the feature. The old133 closure first reproduced every original stored HTML hash, establishing the same test context. The exact upstream adapter rendered the unchanged six current/historical legacy inputs; the feature's adapter rendered those inputs through the same exact upstream popup. All six card objects and complete new HTML outputs were byte-identical between those independent paths. Existing card JSON hashes, opening objects and design-section hashes remain unchanged.

Each new popup is exactly 38 bytes shorter. Every line becomes identical when only leading spaces/tabs are removed; line counts and all other characters remain identical. A separate HTML-parser comparison also preserves element order, all attributes and nonempty normalized text. This is T3022's research-pane indentation refactor, not changed facts or a relaxed test. Expected hashes come from upstream modules, not from blessing the feature's current output.

The proposed app diff changes only six popup_html_sha256 values in legacy-card-contract.json and adds explicit provenance for renderer commit, popup hash, frozen input checkpoint and generation method. Test source stays exact133; all existing Brougham source/card/negative-control assertions and full raw HTML hash comparisons remain. An external copy executed every original card-phase assertion and all four negative controls unchanged with the new fixture and latest renderer: PASS. The separate native LOD import was not run in this source-only investigation, remains unchanged, and must pass after authorized intake.

## Proposed execution after root review

1. Reverify clean133 and the frozen inventory. Perform one normal no-commit merge of exact513 using the existing supported merge drivers. Preserve every incoming T3022 Inspect/Research route, UI-framing change, popup factor, current smoke guard and the tracked Ames GLBs/manifests. Preserve the feature's drawing-buffer callback, two independent glossary taps, 222-ID set and all vehicle assets/positions/licenses. The actual a3/133 GitHub test merge was clean; a3-to513 is only three changelog-fold files. Inspect and report any unexpected authored conflict rather than choosing a side blindly.
2. Apply only the reviewed legacy-contract proposal under its exact original preimage pin. Do not change popup/runtime code or test assertions. Keep the existing single changelog entry. All card JSON/opening/design values remain byte-identical.
3. Run the existing full registered card+LOD test, syntax/whitespace/changelog and full validator/freshness checks. The new Ames GLBs are tracked incoming assets; do not rebake or replace the unchanged Glessner package. Only use a supported canonical derivation if an actual derived conflict or freshness failure requires it.
4. Record the final staged tree and protected proof: all vehicle payloads, original near/proxy, 60 nonshared feature paths (except the intentional legacy fixture), complete incoming Ames/UI source and all smoke limits preserved. Root reviews the concrete source before one full preflight.
5. On actual full PASS, perform candidate precheck, normal merge commit parents[133,513], immediate normal branch push, actual-HEAD checks and normal postpublication/site validation. Keep draft, normal CI/world/photo pending and retain the actual failed CI record. Root owns ticket updates and the final dev merge guard.

Shared origin/dev must remain `824957fe47dd70fad729c3b117cb18b695d54b0b`. No extra model, camera, cap, shadow, placement or test-policy change is proposed.
