"""HELD: one fixed-formulation LP feasibility witness, never gait acceptance.

Uses only the actual pinned phaseA declarations. No support/palette selection,
new objective, ranking/pruning, pose generation, float32 skin or export follows.
"""
from pathlib import Path
import ast, hashlib, json, sys, time
import numpy as np
import scipy
from scipy.sparse import coo_matrix, csr_matrix
from scipy.optimize import linprog

HERE = Path(__file__).resolve().parent
ELL = 0.3263955630216535
TOL = 1e-8


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def quotient(weights):
    q = weights.copy()
    q[..., 1] += q[..., 2:6].sum(axis=-1)
    q[..., 2:6] = 0
    return q


def row_declaration(left_columns, right_columns, left_constant, right_constant, bound):
    """a*x+c = right-left; preserve actual source edge orientation."""
    coefficients = {}
    for col in left_columns:
        coefficients[col] = coefficients.get(col, 0.) - 1.
    for col in right_columns:
        coefficients[col] = coefficients.get(col, 0.) + 1.
    pairs = sorted((k, v) for k, v in coefficients.items() if v != 0)
    constant = float(right_constant - left_constant)
    return pairs, constant, float(bound - constant), float(bound + constant)


def residuals(x, a_ub, b_ub, a_eq, b_eq):
    ub = np.asarray(a_ub @ x - b_ub)
    eq = np.asarray(a_eq @ x - b_eq)
    return {'maximum_inequality_violation': float(max(0., ub.max())) if len(ub) else 0.,
            'maximum_simplex_residual_abs': float(np.abs(eq).max()) if len(eq) else 0.,
            'minimum_variable': float(x.min()), 'maximum_variable': float(x.max()),
            'all_finite': bool(np.isfinite(x).all())}, ub, eq


def jsonable(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    return value


def main():
    start = time.monotonic()
    release_path, out = map(Path, sys.argv[1:])
    release = json.loads(release_path.read_text())
    assert release['released'] is True
    assert release['authorization'] == 'ONE_ROOT_RELEASED_V10_PHASE_B_LP_FEASIBILITY'
    assert release['runner_sha256'] == sha(__file__)
    assert release['pins_sha256'] == sha(HERE / 'INPUT-PINS.json')
    assert release['recipe_sha256'] == sha(HERE / 'CONSTRAINT-RECIPE.json')
    assert release['maximum_runs'] == 1 and release['maximum_LP_solves'] == 1
    assert release['QP_poses_export_or_candidate_authorized'] is False
    assert not (out / 'PHASE-B-REPORT.json').exists()
    pins = json.loads((HERE / 'INPUT-PINS.json').read_text())
    for name, row in pins.items():
        assert sha(row['path']) == row['sha256'], name + ' pinned source drift'
    a = json.loads(Path(pins['phase_a_report']['path']).read_text())
    terminal_a = json.loads(Path(pins['phase_a_terminal']['path']).read_text())
    assert a['status'] == terminal_a['status'] == 'PROPOSAL_SOURCE_PREFLIGHT_PASS_NO_SOLVE'
    assert terminal_a['no_owned_child_active'] and not a['failures']
    assert terminal_a['runner_sha256'] == 'c0f39855ef525518fadd6f8db498edd8be9fe54608991a3555c6876fdce95dea'
    assert terminal_a['supervisor_sha256'] == 'd27ee78bc10244a9762dbe4e87f63e104119d104754f4751ae6a7f141b9aa16f'
    for name, row in a['source_pins'].items():
        assert sha(row['path']) == row['sha256'], name + ' original source drift'
    assert a['declared_ell_m'] == ELL
    assert a['palette_precondition']['class_maximum'] <= 4
    assert a['palette_precondition']['edge_union_maximum'] <= 4
    # The latter is THIS formulation's conservative assumption, not GPU physics.
    gait = ast.parse(Path(a['source_pins']['gait']['path']).read_text())
    gait_literals = {}
    for statement in gait.body:
        if isinstance(statement, ast.Assign):
            for target in statement.targets:
                if isinstance(target, ast.Name) and target.id in ('PARAMETERS', 'THRESHOLDS'):
                    gait_literals[target.id] = ast.literal_eval(statement.value)
    assert gait_literals['PARAMETERS'] == a['original_parameters']
    assert gait_literals['THRESHOLDS'] == a['original_thresholds']
    with np.load(Path(pins['phase_a_arrays']['path']), allow_pickle=False) as frozen:
        points = frozen['points_m'].copy()
        edges = frozen['edges'].copy()
        lengths = frozen['edge_lengths_m'].copy()
        allowed = frozen['fixed_palette_allowed'].copy()
        fixed = frozen['fixed_rows'].copy()
        known_ids = frozen['declared_known_class_ids'].copy()
        known_vectors = frozen['declared_known_vectors'].copy()
        vc_body = frozen['vertex_classes_1'].copy()
    n = len(points)
    assert allowed.shape == (n, 26) and fixed.shape == (n,)
    assert np.array_equal(np.flatnonzero(fixed), known_ids)
    assert known_vectors.shape == (len(known_ids), 26)
    assert np.all(allowed.sum(1) <= 4)
    assert np.all((allowed[edges[:, 0]] | allowed[edges[:, 1]]).sum(1) <= 4)
    assert np.all(lengths > 0) and len(lengths) == len(edges)
    assert np.abs(np.linalg.norm(points[edges[:, 1]] - points[edges[:, 0]], axis=1) - lengths).max() < 1e-12
    known = np.zeros((n, 26))
    known[known_ids] = known_vectors
    assert np.abs(known_vectors.sum(1) - 1).max() < TOL
    assert np.all(known_vectors >= 0)
    assert np.count_nonzero(known_vectors[~allowed[known_ids]]) == 0
    unknown_classes = np.flatnonzero(~fixed)
    var_classes, var_joints = np.nonzero(allowed & ~fixed[:, None])
    nv = len(var_classes)
    assert 0 < nv <= 20000
    assert nv == a['palette_precondition']['unknown_scalar_variables']
    var_class_rows = np.searchsorted(unknown_classes, var_classes)
    a_eq = coo_matrix((np.ones(nv), (var_class_rows, np.arange(nv))),
                      shape=(len(unknown_classes), nv)).tocsr()
    b_eq = np.ones(len(unknown_classes))
    q_joint = np.arange(26)
    q_joint[2:6] = 1
    q_known = quotient(known)
    q_allowed = allowed.copy()
    q_allowed[:, 1] |= q_allowed[:, 2:6].any(1)
    q_allowed[:, 2:6] = False
    column_groups = {}
    for col, (ci, ji) in enumerate(zip(var_classes, var_joints)):
        column_groups.setdefault((int(ci), int(q_joint[ji])), []).append(col)
    row_indices, column_indices, data, rhs, row_meta = [], [], [], [], []
    known_constant_rows = []
    constant_conflicts = []
    for edge_id, ((u, v), length) in enumerate(zip(edges, lengths)):
        u, v = int(u), int(v)
        bound = float(length / ELL)
        for j in np.flatnonzero(q_allowed[u] | q_allowed[v]):
            j = int(j)
            coefficients, constant, positive_rhs, negative_rhs = row_declaration(
                column_groups.get((u, j), []), column_groups.get((v, j), []),
                q_known[u, j], q_known[v, j], bound)
            if not coefficients:
                known_constant_rows.append((edge_id, j, constant, bound))
                if abs(constant) > bound + TOL:
                    constant_conflicts.append({'edge_id': edge_id, 'classes': [u, v],
                                               'joint_quotient_channel': j,
                                               'constant_difference': constant, 'bound': bound})
                continue
            for sign, row_rhs in ((1., positive_rhs), (-1., negative_rhs)):
                row = len(rhs)
                for col, coefficient in coefficients:
                    row_indices.append(row)
                    column_indices.append(col)
                    data.append(sign * coefficient)
                rhs.append(row_rhs)
                row_meta.append((edge_id, j, int(sign)))
    a_ub = coo_matrix((data, (row_indices, column_indices)), shape=(len(rhs), nv)).tocsr()
    a_ub.sum_duplicates()
    a_ub.sort_indices()
    b_ub = np.asarray(rhs, dtype=float)
    row_meta = np.asarray(row_meta, dtype=np.int64).reshape(-1, 3)
    assert a_ub.shape[0] + a_eq.shape[0] <= 160000
    assert np.isfinite(a_ub.data).all() and np.isfinite(b_ub).all()
    assert np.all(a_ub.getnnz(axis=1) > 0)
    # Necessary interval diagnostics from actual single-variable inequalities.
    # These are not a second LP, an IIS, or a global infeasibility certificate.
    lower, upper = np.zeros(nv), np.ones(nv)
    single = np.flatnonzero(a_ub.getnnz(axis=1) == 1)
    for row in single:
        index = a_ub.indptr[row]
        col, coefficient = a_ub.indices[index], a_ub.data[index]
        value = b_ub[row] / coefficient
        if coefficient > 0:
            upper[col] = min(upper[col], value)
        else:
            lower[col] = max(lower[col], value)
    bad_intervals = np.flatnonzero(lower > upper + TOL)
    sum_lower = np.bincount(var_class_rows, weights=lower, minlength=len(unknown_classes))
    sum_upper = np.bincount(var_class_rows, weights=upper, minlength=len(unknown_classes))
    bad_simplex = np.flatnonzero((sum_lower > 1 + TOL) | (sum_upper < 1 - TOL))
    interval_diagnostics = {
        'single_variable_constraint_rows': int(len(single)),
        'inconsistent_variable_interval_count': int(len(bad_intervals)),
        'inconsistent_variable_samples': [{'variable': int(i), 'class': int(var_classes[i]),
                                         'joint': int(var_joints[i]), 'lower': float(lower[i]),
                                         'upper': float(upper[i])} for i in bad_intervals[:30]],
        'simplex_interval_contradiction_count': int(len(bad_simplex)),
        'simplex_contradiction_samples': [{'class': int(unknown_classes[i]),
                                           'sum_lower': float(sum_lower[i]),
                                           'sum_upper': float(sum_upper[i])} for i in bad_simplex[:30]],
        'scope': 'Necessary local diagnostics only; no minimal infeasible subsystem or alternate solve.'}
    np.savez_compressed(out / 'EXACT-LINEAR-CONSTRAINTS.npz',
        a_ub_data=a_ub.data, a_ub_indices=a_ub.indices, a_ub_indptr=a_ub.indptr,
        a_ub_shape=np.asarray(a_ub.shape), b_ub=b_ub,
        a_eq_data=a_eq.data, a_eq_indices=a_eq.indices, a_eq_indptr=a_eq.indptr,
        a_eq_shape=np.asarray(a_eq.shape), b_eq=b_eq,
        lower_bounds=np.zeros(nv), upper_bounds=np.ones(nv),
        var_class_ids=var_classes, var_joint_ids=var_joints,
        unknown_class_ids=unknown_classes, row_edge_channel_sign=row_meta,
        dropped_known_rows=np.asarray(known_constant_rows).reshape(-1, 4),
        singleton_implied_lower=lower, singleton_implied_upper=upper)
    # Replay actual V9 failures through the SAME row-constant assembly rule.
    v9 = json.loads(Path(a['source_pins']['v9_readback']['path']).read_text())
    negative_controls = []
    for name, aa, bb in [('edge_max', 3666, 3708), ('normal_min', 3518, 3520)]:
        vertices = {v['id']: v for v in v9['witnesses'][name]['vertices']}
        aw, bw = np.zeros(26), np.zeros(26)
        for row in vertices[aa]['weights']:
            aw[row['joint']] = row['weight']
        for row in vertices[bb]['weights']:
            bw[row['joint']] = row['weight']
        qa, qb = quotient(aw), quotient(bw)
        joint = int(np.abs(qb - qa).argmax())
        length = float(np.linalg.norm(np.asarray(vertices[bb]['rest_m']) - vertices[aa]['rest_m']))
        coeffs, constant, pos_rhs, neg_rhs = row_declaration([], [], qa[joint], qb[joint], length / ELL)
        assert not coeffs and min(pos_rhs, neg_rhs) < -TOL
        negative_controls.append({'case': 'actual_rejected_V9_' + name, 'vertices': [aa, bb],
                                  'channel': joint, 'constant_difference': constant,
                                  'chosen_bound': length / ELL,
                                  'constant_row_detects_infeasibility_without_extra_solve': True,
                                  'scope': 'Our chosen regularizer; not original posed skin acceptance.'})
    ci = int(vc_body[3255])
    assert not allowed[ci, 15]
    negative_controls.append({'case': 'forbidden_chest_distal_variable', 'vertex': 3255,
                              'class': ci, 'joint': 15, 'absent_from_fixed_anatomical_palette': True})
    # Actual equality matrix must reject a spurious zero-vector solver witness.
    zero_residual, _, _ = residuals(np.zeros(nv), a_ub, b_ub, a_eq, b_eq)
    assert zero_residual['maximum_simplex_residual_abs'] == 1
    negative_controls.append({'case': 'spurious_zero_LP_witness',
                              'actual_simplex_residual': zero_residual['maximum_simplex_residual_abs'],
                              'independent_witness_verifier_rejects': True})
    # A negative coordinate must independently fail bounds even if solver says success.
    bad_bounds = np.zeros(nv)
    bad_bounds[0] = -.01
    corrupt_residual, _, _ = residuals(bad_bounds, a_ub, b_ub, a_eq, b_eq)
    assert corrupt_residual['minimum_variable'] == -.01
    negative_controls.append({'case': 'negative_LP_coordinate', 'minimum_variable': -.01,
                              'independent_bounds_verifier_rejects': True})
    solver_calls = 0
    result = None
    actual_residual = None
    local_infeasible = bool(constant_conflicts or len(bad_intervals) or len(bad_simplex))
    options = {'time_limit': 25., 'presolve': True,
               'primal_feasibility_tolerance': 1e-9,
               'dual_feasibility_tolerance': 1e-9, 'threads': 1}
    solver_start = time.monotonic()
    if local_infeasible:
        status = 'PROPOSAL_LP_LOCAL_CONTRADICTION_NO_SOLVE'
    else:
        solver_calls = 1
        (out / 'SOLVER-INTENT.json').write_text(json.dumps({
            'solver_calls': 1, 'method': 'highs', 'objective': 'zero feasibility only',
            'options': options, 'variables': nv, 'inequalities': a_ub.shape[0],
            'equalities': a_eq.shape[0], 'no_retry_or_alternate_solver': True}, indent=2) + '\n')
        result = linprog(np.zeros(nv), A_ub=a_ub, b_ub=b_ub,
                         A_eq=a_eq, b_eq=b_eq, bounds=(0., 1.), method='highs', options=options)
        (out / 'HIGHS-COMPLETE-RESULT.json').write_text(json.dumps(jsonable(dict(result)), indent=2) + '\n')
        if result.success and result.x is not None:
            actual_residual, ub, eq = residuals(result.x, a_ub, b_ub, a_eq, b_eq)
            checked = (actual_residual['all_finite']
                       and actual_residual['maximum_inequality_violation'] <= TOL
                       and actual_residual['maximum_simplex_residual_abs'] <= TOL
                       and actual_residual['minimum_variable'] >= -TOL
                       and actual_residual['maximum_variable'] <= 1 + TOL)
            status = ('PROPOSAL_LP_FEASIBLE_WITNESS_ONLY_NO_GAIT_ACCEPTANCE' if checked else
                      'PROPOSAL_LP_SOLVER_SUCCESS_BUT_INDEPENDENT_RESIDUAL_FAIL')
            np.savez_compressed(out / 'LP-FEASIBILITY-WITNESS-NOT-A-SKIN.npz',
                                x=result.x, inequality_residual=ub, simplex_residual=eq,
                                var_class_ids=var_classes, var_joint_ids=var_joints)
        elif result.status == 2:
            status = 'PROPOSAL_FIXED_SUPPORT_LP_INFEASIBLE'
        elif result.status == 1:
            status = 'PROPOSAL_LP_LIMIT_NO_RETRY'
        else:
            status = 'PROPOSAL_LP_OTHER_SOLVER_FAILURE_NO_RETRY'
    solver_seconds = time.monotonic() - solver_start
    histogram = np.bincount(row_meta[:, 1], minlength=26).tolist() if len(row_meta) else [0] * 26
    report = {'status': status, 'solver_calls': solver_calls, 'solver_seconds': solver_seconds,
              'source_phase_a_status': a['status'], 'source_pins': pins,
              'original_source_pins': a['source_pins'], 'variables': nv,
              'inequality_rows': int(a_ub.shape[0]), 'inequality_nnz': int(a_ub.nnz),
              'simplex_equalities': int(a_eq.shape[0]),
              'dropped_already_checked_constant_rows': len(known_constant_rows),
              'constant_constraint_conflicts': constant_conflicts,
              'necessary_local_interval_diagnostics': interval_diagnostics,
              'inequality_channel_histogram': histogram,
              'independent_solution_residuals': actual_residual,
              'solver_status': None if result is None else int(result.status),
              'solver_message': None if result is None else str(result.message),
              'iterations': None if result is None else int(result.nit),
              'scipy_version': scipy.__version__, 'solver_method': 'highs', 'solver_options': options,
              'negative_controls': negative_controls,
              'original_parameters': gait_literals['PARAMETERS'],
              'original_thresholds': gait_literals['THRESHOLDS'],
              'original_acceptance_unmodified_uninvoked': True,
              'palette_selection': 'Pre-fixed phaseA anatomical palettes; no ranking or top-four pruning.',
              'conservative_edge_union_is_OUR_assumption_not_GPU_requirement': True,
              'ell_is_chosen_regularizer_not_original_pose_acceptance': True,
              'infeasibility_scope': 'This fixed conservative formulation only; no universal weights-only, anatomy or bone impossibility claim. Exact row metadata and matrices permit inspection; no minimal IIS/Farkas certificate is claimed.',
              'QP_runs': 0, 'final_skin_candidates': 0, 'pose_generations_or_checks': 0,
              'float32_skin_serializations': 0, 'exports': 0,
              'app_ticket_ref_writes': 0, 'next_phase_released': False,
              'elapsed_seconds': time.monotonic() - start}
    (out / 'PHASE-B-REPORT.json').write_text(json.dumps(report, indent=2) + '\n')
    assert sum(p.stat().st_size for p in out.iterdir() if p.is_file()) < 33554432
    print(json.dumps(report), flush=True)
    return 0 if status == 'PROPOSAL_LP_FEASIBLE_WITNESS_ONLY_NO_GAIT_ACCEPTANCE' else 2


if __name__ == '__main__':
    raise SystemExit(main())
