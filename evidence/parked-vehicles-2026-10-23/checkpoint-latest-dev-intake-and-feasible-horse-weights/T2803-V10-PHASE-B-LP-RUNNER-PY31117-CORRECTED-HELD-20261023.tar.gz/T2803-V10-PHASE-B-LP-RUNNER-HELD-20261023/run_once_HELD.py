"""Owned one-shot phaseB LP supervisor: 30s wall/768MiB RSS; no next phase."""
from pathlib import Path
import datetime, hashlib, json, os, resource, signal, subprocess, sys, time

HERE = Path(__file__).resolve().parent
PYTHON = '/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    release_path = Path(sys.argv[1]).resolve()
    release = json.loads(release_path.read_text())
    assert release['released'] is True
    assert release['authorization'] == 'ONE_ROOT_RELEASED_V10_PHASE_B_LP_FEASIBILITY'
    for key, filename in [('supervisor_sha256', 'run_once_HELD.py'),
                          ('runner_sha256', 'phase_b_lp_HELD.py'),
                          ('pins_sha256', 'INPUT-PINS.json'),
                          ('recipe_sha256', 'CONSTRAINT-RECIPE.json')]:
        assert release[key] == sha(HERE / filename), key + ' drift'
    assert release['maximum_runs'] == 1 and release['maximum_LP_solves'] == 1
    assert release['maximum_wall_seconds'] == 30
    assert release['maximum_rss_bytes'] == 768 * 1024 * 1024
    assert release['QP_poses_export_or_candidate_authorized'] is False
    assert not (HERE / 'ACTUAL').exists(), 'One-shot output exists; no rerun authorized'
    out = HERE / 'ACTUAL'
    out.mkdir()
    (out / 'ROOT-RELEASE.json').write_text(json.dumps(release, indent=2) + '\n')
    intent = {'started_utc': utc(), 'one_shot': True, 'released_phase': 'B_LP_FEASIBILITY_ONLY',
              'wall_limit_seconds': 30, 'rss_limit_bytes': 768 * 1024 * 1024,
              'maximum_LP_calls': 1, 'solver_internal_limit_seconds': 25,
              'math_threads': 1, 'nice': 19, 'automatic_next_phase': False}
    (out / 'INTENT.json').write_text(json.dumps(intent, indent=2) + '\n')
    env = os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
               NUMEXPR_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    start = time.monotonic()
    peak = 0
    stopped = None
    with (out / 'stdout.log').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
        process = subprocess.Popen(['nice', '-n', '19', PYTHON, str(HERE / 'phase_b_lp_HELD.py'),
                                    str(release_path), str(out)], cwd=HERE, env=env,
                                   stdout=stdout, stderr=stderr, start_new_session=True)
        while process.poll() is None:
            try:
                for line in (Path('/proc') / str(process.pid) / 'status').read_text().splitlines():
                    if line.startswith('VmRSS:'):
                        peak = max(peak, int(line.split()[1]) * 1024)
            except FileNotFoundError:
                pass
            if time.monotonic() - start > 30:
                stopped = 'WALL_LIMIT_30_SECONDS'
            elif peak > 768 * 1024 * 1024:
                stopped = 'RSS_LIMIT_768_MiB'
            if stopped:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                break
            time.sleep(.025)
        code = process.wait()
    peak = max(peak, int(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss) * 1024)
    if peak > 768 * 1024 * 1024:
        stopped = stopped or 'KERNEL_PEAK_RSS_EXCEEDED_768_MiB'
    elapsed = time.monotonic() - start
    if elapsed > 30:
        stopped = stopped or 'ELAPSED_LIMIT_EXCEEDED_30_SECONDS'
    report_path = out / 'PHASE-B-REPORT.json'
    report = json.loads(report_path.read_text()) if report_path.exists() else None
    status = ('RESOURCE_LIMIT_FAIL_NO_RETRY' if stopped else
              report['status'] if report is not None and code in (0, 2) else
              'LP_RUNNER_ERROR_NO_RETRY')
    intent_exists = (out / 'SOLVER-INTENT.json').exists()
    terminal = {'status': status, 'finished_utc': utc(), 'exit_code': code,
                'elapsed_seconds': elapsed, 'actual_peak_rss_bytes': peak,
                'resource_failure': stopped, 'runs': 1, 'reruns': 0,
                'runner_sha256': release['runner_sha256'],
                'supervisor_sha256': release['supervisor_sha256'],
                'report_present': report is not None,
                'LP_solver_intent_present': intent_exists,
                'LP_solver_calls': report['solver_calls'] if report is not None else None,
                'no_owned_child_active': True,
                'QP_pose_skin_export_app_or_next_phase_executions': 0,
                'phase_C_released': False}
    (out / 'TERMINAL.json').write_text(json.dumps(terminal, indent=2) + '\n')
    print(json.dumps(terminal), flush=True)
    return 0 if status == 'PROPOSAL_LP_FEASIBLE_WITNESS_ONLY_NO_GAIT_ACCEPTANCE' and code == 0 else 2


if __name__ == '__main__':
    raise SystemExit(main())
