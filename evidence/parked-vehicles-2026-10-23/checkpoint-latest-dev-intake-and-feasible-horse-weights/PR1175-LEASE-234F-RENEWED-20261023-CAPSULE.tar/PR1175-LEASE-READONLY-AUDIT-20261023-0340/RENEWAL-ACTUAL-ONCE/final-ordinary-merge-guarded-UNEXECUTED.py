"""Ordinary merge only after actual strict collectors pass and all immutable source/base/lease pins match. No bypass or automatic retry."""
import argparse,datetime,hashlib,json,pathlib,subprocess
D=pathlib.Path(__file__).resolve().parent
P='4766644295b5668084130fed80c6a18c9f0e6a04';PT='c9d944caaca53cce404e8706e0f92534fd8e52a3';PP=['64b126d52b49cb3576c9921b82bd2a7cf2cef802','58fd2216a9312295cefbcc08c301852db09ea199'];B='6c3603ff3019b8600a8945433f9196f4d861fd2d';Q='ca9a89eb4108d09ff0a8f1941f5b7f2294cc0097';T='967213de77a9ca54ebadfbd2d165b6245474170d';LEASE='234f1ccdd2aa49803718851cb16b675ab35383cb'
N=pathlib.Path('/workspace/shared/PR1175-4766644295-NORMAL-TERMINAL-GET-owner1');S=pathlib.Path('/workspace/shared/PR1175-DATE34-FULL14-ca9a89eb41-GET-owner1')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def load(p):return json.loads(p.read_bytes())
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute-ordinary-merge',action='store_true');args=a.parse_args()
 n=load(N/'TERMINAL.json');s=load(S/'TERMINAL.json');nj=load(N/'AUDITED-JOBS.json');sj=load(S/'AUDITED-JOBS.json')
 assert n['status']=='NORMAL_FOUR_TERMINAL_SOURCE_AND_CHECKOUT_EVIDENCE_ONLY' and n['strict_success']==n['terminal_collected']==4
 assert s['snapshot_batch_pass']is True and s['selected_success']==s['selected_terminal_collected']==4 and s['selected_failed_or_refused']==0
 assert len(nj)==len(sj)==4 and all(x['PASS']for x in nj+sj)
 assert {x['run_id']for x in nj}=={39886670107,39886670145,39886670144,39886663074}
 assert {x['run_id']for x in sj}=={39887496097,39887499026,39887502224,39887505240}
 assert {(x['viewport'],x['stage'])for x in sj}=={('desktop','3-4'),('desktop','14'),('mobile','3-4'),('mobile','14')}
 assert all(x['actual_checkout_sha']==Q and x['failed_assertions']==0 and x['passed_assertions']>0 for x in sj)
 for x in nj:
  if x['event']=='pull_request':assert x['actual_checkout_sha']==Q and x['actual_checkout_tree']==T and x['actual_checkout_parents']==[B,P]
  else:assert x['actual_checkout_sha']==P and x['actual_checkout_tree']==PT and x['actual_checkout_parents']==PP
 assert args.execute_ordinary_merge,'All actual collection guards passed; explicit execution flag required for the one ordinary merge'
 O=D/'FINAL-ORDINARY-MERGE';O.mkdir(exist_ok=False);i=0
 def api(route,method='GET',body=None):
  nonlocal i
  i+=1;stem=O/f'{i:03d}';(stem.with_suffix('.request.json')).write_text(json.dumps({'at':now(),'method':method,'route':route,'body':body},indent=2)+'\n')
  cmd=['gh','api','--method',method,'repos/kevinrhaas/chicago/'+route]
  if body is not None:cmd+=['--input','-']
  r=subprocess.run(cmd,input=json.dumps(body).encode()if body is not None else None,capture_output=True,timeout=45);stem.with_suffix('.stdout').write_bytes(r.stdout);stem.with_suffix('.stderr').write_bytes(r.stderr)
  assert r.returncode==0,'API refused/ambiguous; preserve actual failure and do not retry: '+str(stem)
  return json.loads(r.stdout)if r.stdout.strip()else None
 def guards():
  assert api('git/ref/heads/lap/pr-1175')['object']['sha']==LEASE,'Lease owner changed'
  assert api('git/ref/heads/dev')['object']['sha']==B,'DEV advanced beyond reviewed base'
  assert api('git/ref/heads/steward/1835-workwear-repair-20261021')['object']['sha']==P,'Source branch advanced'
  pr=api('pulls/1175');assert pr['state']=='open' and pr['head']['sha']==P and pr['base']['ref']=='dev' and pr['head']['repo']['full_name']=='kevinrhaas/chicago' and pr['auto_merge']is None
  assert pr['mergeable']is True and pr['mergeable_state']=='clean' and pr['merge_commit_sha']==Q,'Actual merge policy/testmerge differs'
  assert 'hold'not in {x['name']for x in pr['labels']},'PR on hold'
  return pr
 guards()
 c=api('git/commits/'+Q);assert c['tree']['sha']==T and [x['sha']for x in c['parents']]==[B,P]
 c=api('git/commits/'+P);assert c['tree']['sha']==PT and [x['sha']for x in c['parents']]==PP
 assert api('git/ref/heads/steward/pr1175-verify-ca9a89eb4108-date34-full14-20261023')['object']['sha']==Q
 draft=(D/'PR-BODY-AFTER-GREEN-DRAFT.md').read_text();assert draft.count('PENDING_FINAL_ACTUAL_TERMINALS')==1
 counts='; '.join(f"{x['viewport']} stages {x['stage']}: {x['passed_assertions']} passed/0 failed ([run {x['run_id']}](https://github.com/kevinrhaas/chicago/actions/runs/{x['run_id']}))"for x in sorted(sj,key=lambda x:(x['viewport'],x['stage'])))
 body=draft.replace('PENDING_FINAL_ACTUAL_TERMINALS',counts+'; all four actual published smoke steps and required workflow steps passed')
 (O/'FINAL-PR-BODY.md').write_text(body)
 guards()
 updated=api('pulls/1175','PATCH',{'body':body});assert updated['head']['sha']==P and updated['body']==body
 guards()
 result=api('pulls/1175/merge','PUT',{'sha':P,'merge_method':'squash'});assert result.get('merged')is True,'Ordinary merge not accepted'
 M=result['sha'];c=api('git/commits/'+M);assert c['tree']['sha']==T and [x['sha']for x in c['parents']]==[B],'Actual merged result tree/base differs from qualified integration'
 pr=api('pulls/1175');assert pr['merged']is True and pr['state']=='closed' and pr['merge_commit_sha']==M and pr['head']['sha']==P
 receipt={'at':now(),'ordinary_head_pinned_merge':True,'head':P,'source_tree':PT,'source_parents':PP,'reviewed_dev':B,'qualified_testmerge':Q,'qualified_tree':T,'actual_merge':M,'actual_merge_tree':c['tree']['sha'],'owned_lease_at_merge':LEASE,'native_auto_merge':False,'admin_bypass':False,'force':False,'normal_four_strict_PASS':True,'fresh_smoke_four_strict_PASS':True,'whole18_new_pass_claimed':False,'scope_review':'/workspace/shared/PR1175-CA9A-SCOPED-CARRY-REVIEW-20261023.md','scope_review_sha256':hashlib.sha256(pathlib.Path('/workspace/shared/PR1175-CA9A-SCOPED-CARRY-REVIEW-20261023.md').read_bytes()).hexdigest(),'historical_failures_retained':True,'T1789_photographic_acceptance':'OPEN','deployment_verified':False,'lease_released':False}
 (O/'MERGE-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
if __name__=='__main__':main()
