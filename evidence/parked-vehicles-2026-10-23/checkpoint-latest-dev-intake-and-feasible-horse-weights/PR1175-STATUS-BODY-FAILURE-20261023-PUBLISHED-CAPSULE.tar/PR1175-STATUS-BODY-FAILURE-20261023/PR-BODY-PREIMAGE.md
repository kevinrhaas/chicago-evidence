Adds a reconstructed standing resident beside the Wolf Point wagons using the repaired Bardwell & Otis portable model. Connected waistcoat shoulders, grounded shoes and identity cards distinguish reconstructed appearance and placement from the historically modelled firm.

Canonical authoring/export remains source `96c4da4b` and successful run `39736567239`. The eight Bardwell raw/web GLBs, placement, person data and human runtime are unchanged by the final test repairs and incoming DEV folds. Photographic finishing, complete tailoring, other people/eras, walking, drivers and riders remain open under T-1789.

Validation already observed:

- Authored `248ecfb56`: full preflight 1,048 checks/381 self-tests, committed-HEAD checks and postcommit publication/mirror parity passed.
- Repaired immutable `248ecfb56`: desktop/mobile stages 1–2 each194/0 and stages9–12 each69/0 passed. Exact census and actual visible glossary meaning/viewport/dismiss assertions remain.
- Incoming integration `8f5127d4`: supported CI fold and local publication/mirror passed. All four normal workflows passed; the main1048/381 gate, human workflow and moving/upload-release32 actually tested merge `8fc3fd3f0` (DEV7d9 + source8f). Push report tested8f. These are scoped to those actual commits.
- Original immutablefe98 eighteen-cell batch completed12 PASS/6 FAIL; desktop13 passed160/0. All six obsolete-test failures remain recorded. The repaired cells above replace their affected assertions without relabelling the original batch.
- Immutable8f: both stage15 and mobile14 passed. Actual8fc merge: mobile14 passed. Both corresponding desktop14 jobs remain pending at the latest observation.
- Focused published8f mobile passed20/0. Desktop original focused projection timed out after its QA11 assertion passed; a separate six-check projection timed out after the first five release assertions passed. The authentic returning-profile observation separately passed16/0. All timeouts remain failures, with their partial scope preserved; this is not a claim that either timed-out whole projection passed.

Current remaining merge work: latest DEV `73aefb020` changes the 1904 Wheeler roof/provenance/feed. Selected supported incoming integration run `39871276267` is active; source remains8f at this update. After its actual push, verify exact parents/tree, run actual new normal CI and fresh published stage14 in both viewports. Existing valid1835/person/UI/15 results retain their source labels; no full-current-head eighteen-cell PASS is claimed.

DEV only. Ordinary merge when the applicable current checks are green. Source, evidence, claims and recovery instructions are periodically committed and pushed to `kevinrhaas/chicago-tickets` (latest checkpoint `bcbf9678`). No broad photographic-parent closure.
