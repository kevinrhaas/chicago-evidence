# PR1175 truthful status body published

One structured REST PATCH succeeded at 03:52:50 UTC. Existing person, period and canonical provenance opening remains byte-identical. Source476 remains open and pushed, with local full 1,048/381 checks, HEAD/publication proof and four actual normal CI passes correctly scoped.

The current body records ca9a four-cell matrix overall FAIL (three PASS, one FAIL), actual desktop14 4,600,305 triangles against 4,600,000, 305 over. It preserves original fe98 12 PASS/6 FAIL overall FAIL, source-labelled assertion repairs, focused timeout failures and narrow mobile/returning-profile results. New DEVb7 geometry/world/smoke changes remain explicitly unqualified. Genuine vehicle1213 replacement and fresh reviewed fold/qualification are the next step, with no analytic PASS or cap workaround claimed.

Actual owned lease234f was checked before PATCH and is recorded until 06:44:17 UTC. Exactly one initial PR-body GET, one lease GET and one PATCH occurred, without retry. The PATCH response contains the exact requested body and unchanged source476. No app edit, CI/smoke dispatch, merge or ticket write occurred. Root remains canonical ticket writer. Raw preimage, structured request, response, exact body, executed wrapper and checksummed receipt are included.
