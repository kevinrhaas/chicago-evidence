Adds a reconstructed standing resident beside the Wolf Point wagons using the repaired Bardwell & Otis portable model. Connected waistcoat shoulders, grounded shoes and identity cards distinguish reconstructed appearance and placement from the historically modelled firm.

Canonical authoring/export remains source `96c4da4b` and successful run `39736567239`. The eight Bardwell raw/web GLBs, placement, person data and human runtime are unchanged by the final test repairs and incoming DEV folds. Photographic finishing, complete tailoring, other people/eras, walking, drivers and riders remain open under T-1789.

Current status: source `4766644295b5668084130fed80c6a18c9f0e6a04` is committed and pushed. PR1175 has **not merged**: fresh desktop full14 exceeds the unchanged render budget by 305 triangles. No assertion, camera, LOD threshold or budget has been weakened; there has been no automatic retry.

Current saved source and validation:

- Source tree `c9d944caaca53cce404e8706e0f92534fd8e52a3`, direct parents `64b126d52b49cb3576c9921b82bd2a7cf2cef802` and `58fd2216a9312295cefbcc08c301852db09ea199`.
- Full local preflight passed 1,048 checks and 381 deliberate self-tests. Committed-HEAD changelog entry/contract, ID and whitespace checks passed. Postcommit publication and site/mirror validation passed, with a clean source tree. Actual preflight duration was 698.243 seconds, exceeding the nominal 600-second target; that observation remains recorded.
- All four actual normal workflows passed. [Gate 39886670107](https://github.com/kevinrhaas/chicago/actions/runs/39886670107), [humans 39886670145](https://github.com/kevinrhaas/chicago/actions/runs/39886670145) and [moving 39886670144](https://github.com/kevinrhaas/chicago/actions/runs/39886670144) actually checked out GitHub test merge `ca9a89eb4108d09ff0a8f1941f5b7f2294cc0097`, tree `967213de77a9ca54ebadfbd2d165b6245474170d`, parents DEV `6c3603ff3019b8600a8945433f9196f4d861fd2d` and source 476. The [push report 39886663074](https://github.com/kevinrhaas/chicago/actions/runs/39886663074) actually checked out source 476/tree c9d. Required steps, checkout commits/trees and raw logs were audited.

Exactly four fresh published smoke requests were sent once against immutable ca9a. Their actual terminals are:

| Viewport | Stages | Passed | Failed | Actual result |
| --- | --- | ---: | ---: | --- |
| Desktop | 3–4 |134|0|[PASS 39887496097](https://github.com/kevinrhaas/chicago/actions/runs/39887496097)|
| Desktop | Full 14 |139|1|[FAIL 39887499026](https://github.com/kevinrhaas/chicago/actions/runs/39887499026)|
| Mobile | 3–4 |137|0|[PASS 39887502224](https://github.com/kevinrhaas/chicago/actions/runs/39887502224)|
| Mobile | Full 14 |140|0|[PASS 39887505240](https://github.com/kevinrhaas/chicago/actions/runs/39887505240)|

The fresh four-cell batch is overall **FAIL: 3 PASS/1 FAIL**. Desktop 14 job `120198995508` reported 5,007 draw calls and **4,600,305 triangles against 4,600,000** at the 1904 spawn. Its only failed assertion is the 305-triangle excess; draw calls remain within 7,800. This is exactly 543 more triangles than the prior source 3f desktop frame. Mobile 14 actually reported 1,719 draw calls/714,089 triangles and passed its unchanged caps. Failure logs and all four strict checkout/workflow/step proofs are preserved in capsule SHA256 `47b28efa9ea3e428e1f352a4efc1ebda9b156839cc3c1305097ed87e5bd6b3fd`.

The mapped fresh scopes cover date wording, source/catalog changes, eight house summaries, the Glessner liberty-note expansion and Ames 1904 geometry. Current published source index contains 412 entries. All 63 protected source blobs match source 476; the person/main/scene/runtime pins remain unchanged through the reviewed incoming folds, and the full smoke source retains SHA256 `d5d0d2974e4d1dc5cb9977a05402c85a4f5f4460dcef5d5953deb79d3fb68e45`, including the three assertion repairs and inherited Hogan wording. Earlier scope evidence carries only through those exact pins; it does not replace the fresh desktop14 failure.

Failure history and scope limits remain explicit:

- Original immutable fe98 full 18 completed 12 PASS/6 FAIL and remains overall FAIL forever. Its desktop 13 result remains 160/0 at that source; original failures are never relabelled.
- Repaired immutable 248 stages 1–2 passed 194/0 in each viewport; stages 9–12 passed 69/0 in each viewport. These repaired assertions remain in the current smoke without weakening their meaning.
- Earlier source-labelled 14/15 results retain their original sources. Source3f both 14 passed 140/0, but those results do not substitute for current ca9a desktop 14 after the actual Ames geometry change.
- Focused published 8f mobile passed 20/0. Its original desktop projection timed out after QA11 passed; a separate six-check projection timed out after five release assertions passed. Both whole projections remain failures. The separate authentic returning-profile observation remains a narrow 16/0 result.
- No whole-current-head eighteen-cell PASS is claimed. Other wagon, horse, driver, rider and route branches are outside this PR's evidence. Broad T-1789 photographic acceptance remains open.

New DEV `b7cde6d86e42edd1c80204642c40ca8b683ceffd` contains additional Calumet geometry plus world phone-shadow and smoke changes. It is **not qualified by source 476 or the ca9a results above**; its finite audit and any future combined-source qualification remain separate. No latest-DEV or deployment PASS is inferred from these older source-specific receipts.

Next, prioritize vehicle PR #1213's genuine carriage/obsolete-wagon replacement cost reduction. Its latest combined render cost must be measured against the actual integrated source. If that work lands green, fold the reviewed result into 1175 and qualify the resulting source before an ordinary head-pinned DEV merge. No cap workaround or analytic PASS claim is authorized. Current owned PR1175 lease is `234f1ccdd2aa49803718851cb16b675ab35383cb`, stale boundary 2026-10-23 06:44:17 UTC.

DEV only. Source476 and recovery evidence are saved; tickets remain under the canonical queue/claim workflow. No broad photographic-parent closure.
