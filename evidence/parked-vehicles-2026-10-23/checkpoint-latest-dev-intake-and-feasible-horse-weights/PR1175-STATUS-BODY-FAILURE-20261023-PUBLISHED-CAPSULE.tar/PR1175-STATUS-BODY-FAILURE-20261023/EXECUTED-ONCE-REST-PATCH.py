import subprocess,pathlib,json,datetime,hashlib
D=pathlib.Path('/workspace/shared/PR1175-STATUS-BODY-FAILURE-20261023');D.mkdir(exist_ok=False);number=0
SOURCE='4766644295b5668084130fed80c6a18c9f0e6a04';LEASE='234f1ccdd2aa49803718851cb16b675ab35383cb'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def api(name,route,method='GET',body=None):
 global number
 number+=1;stem=D/f'{number:02d}-{name}';(stem.with_suffix('.request.json')).write_text(json.dumps({'at':now(),'method':method,'route':route,'body':body},indent=2)+'\n');cmd=['gh','api','--method',method,'repos/kevinrhaas/chicago/'+route]
 if body is not None:cmd+=['--input','-']
 r=subprocess.run(cmd,input=json.dumps(body).encode()if body is not None else None,capture_output=True,timeout=45);stem.with_suffix('.stdout').write_bytes(r.stdout);stem.with_suffix('.stderr').write_bytes(r.stderr)
 assert r.returncode==0,'API refusal/ambiguous: preserve and STOP without retry '+str(stem)
 return json.loads(r.stdout)
pr=api('PR-BODY-PREIMAGE','pulls/1175');assert pr['state']=='open' and pr['head']['sha']==SOURCE and pr['base']['ref']=='dev' and pr['auto_merge']is None,'Unexpected PR state/source: STOP'
old=pr['body'];(D/'PR-BODY-PREIMAGE.md').write_text(old)
opening=old.split('\n\nValidation already observed:',1)[0]
assert opening.count('\n\n')==1 and 'Bardwell & Otis'in opening and '96c4da4b'in opening and '39736567239'in opening,'Opening/provenance unexpectedly changed: STOP rather than overwrite'
assert api('OWNED-LEASE-GUARD','git/ref/heads/lap/pr-1175')['object']['sha']==LEASE,'Owned lease changed: STOP'
body=opening+'''

Current status: source `4766644295b5668084130fed80c6a18c9f0e6a04` is committed and pushed. PR1175 has **not merged**: fresh desktop full14 exceeds the unchanged render budget by305 triangles. No assertion, camera, LOD threshold or budget has been weakened; there has been no automatic retry.

Current saved source and validation:

- Source tree `c9d944caaca53cce404e8706e0f92534fd8e52a3`, direct parents `64b126d52b49cb3576c9921b82bd2a7cf2cef802` and `58fd2216a9312295cefbcc08c301852db09ea199`.
- Full local preflight passed1,048 checks and381 deliberate self-tests. Committed-HEAD changelog entry/contract, ID and whitespace checks passed. Postcommit publication and site/mirror validation passed, with a clean source tree. Actual preflight duration was698.243 seconds, exceeding the nominal600-second target; that observation remains recorded.
- All four actual normal workflows passed. [Gate39886670107](https://github.com/kevinrhaas/chicago/actions/runs/39886670107), [humans39886670145](https://github.com/kevinrhaas/chicago/actions/runs/39886670145) and [moving39886670144](https://github.com/kevinrhaas/chicago/actions/runs/39886670144) actually checked out GitHub test merge `ca9a89eb4108d09ff0a8f1941f5b7f2294cc0097`, tree `967213de77a9ca54ebadfbd2d165b6245474170d`, parents DEV `6c3603ff3019b8600a8945433f9196f4d861fd2d` and source476. The [push report39886663074](https://github.com/kevinrhaas/chicago/actions/runs/39886663074) actually checked out source476/treec9d. Required steps, checkout commits/trees and raw logs were audited.

Exactly four fresh published smoke requests were sent once against immutable ca9a. Their actual terminals are:

| Viewport | Stages | Passed | Failed | Actual result |
| --- | --- | ---: | ---: | --- |
| Desktop | 3–4 |134|0|[PASS39887496097](https://github.com/kevinrhaas/chicago/actions/runs/39887496097)|
| Desktop | Full14 |139|1|[FAIL39887499026](https://github.com/kevinrhaas/chicago/actions/runs/39887499026)|
| Mobile | 3–4 |137|0|[PASS39887502224](https://github.com/kevinrhaas/chicago/actions/runs/39887502224)|
| Mobile | Full14 |140|0|[PASS39887505240](https://github.com/kevinrhaas/chicago/actions/runs/39887505240)|

The fresh four-cell batch is overall **FAIL:3PASS/1FAIL**. Desktop14 job `120198995508` reported5,007 draw calls and **4,600,305 triangles against4,600,000** at the1904 spawn. Its only failed assertion is the305-triangle excess; draw calls remain within7,800. This is exactly543 more triangles than the prior source3f desktop frame. Mobile14 actually reported1,719 draw calls/714,089 triangles and passed its unchanged caps. Failure logs and all four strict checkout/workflow/step proofs are preserved in capsule SHA256 `47b28efa9ea3e428e1f352a4efc1ebda9b156839cc3c1305097ed87e5bd6b3fd`.

The mapped fresh scopes cover date wording, source/catalog changes, eight house summaries, the Glessner liberty-note expansion and Ames1904 geometry. Current published source index contains412 entries. All63 protected source blobs match source476; the person/main/scene/runtime pins remain unchanged through the reviewed incoming folds, and the full smoke source retains SHA256 `d5d0d2974e4d1dc5cb9977a05402c85a4f5f4460dcef5d5953deb79d3fb68e45`, including the three assertion repairs and inherited Hogan wording. Earlier scope evidence carries only through those exact pins; it does not replace the fresh desktop14 failure.

Failure history and scope limits remain explicit:

- Original immutable fe98 full18 completed12PASS/6FAIL and remains overallFAIL forever. Its desktop13 result remains160/0 at that source; original failures are never relabelled.
- Repaired immutable248 stages1–2 passed194/0 in each viewport; stages9–12 passed69/0 in each viewport. These repaired assertions remain in the current smoke without weakening their meaning.
- Earlier source-labelled14/15 results retain their original sources. Source3f both14 passed140/0, but those results do not substitute for current ca9a desktop14 after the actual Ames geometry change.
- Focused published8f mobile passed20/0. Its original desktop projection timed out after QA11 passed; a separate six-check projection timed out after five release assertions passed. Both whole projections remain failures. The separate authentic returning-profile observation remains a narrow16/0 result.
- No whole-current-head eighteen-cell PASS is claimed. Other wagon, horse, driver, rider and route branches are outside this PR's evidence. Broad T-1789 photographic acceptance remains open.

New DEV `b7cde6d86e42edd1c80204642c40ca8b683ceffd` contains additional Calumet geometry plus world phone-shadow and smoke changes. It is **not qualified by source476 or the ca9a results above**; its finite audit and any future combined-source qualification remain separate. No latest-DEV or deployment PASS is inferred from these older source-specific receipts.

Next, prioritize vehicle PR#1213's genuine carriage/obsolete-wagon replacement cost reduction. Its latest combined render cost must be measured against the actual integrated source. If that work lands green, fold the reviewed result into1175 and qualify the resulting source before an ordinary head-pinned DEV merge. No cap workaround or analytic PASS claim is authorized. Current owned PR1175 lease is `234f1ccdd2aa49803718851cb16b675ab35383cb`, stale boundary2026-10-23 06:44:17 UTC.

DEV only. Source476 and recovery evidence are saved; tickets remain under the canonical queue/claim workflow. No broad photographic-parent closure.
'''
for old_text,new_text in [('by305','by 305'),('passed1,048','passed 1,048'),('and381','and 381'),('was698.243','was 698.243'),('nominal600','nominal 600'),('Gate398','Gate 398'),('humans398','humans 398'),('moving398','moving 398'),('report398','report 398'),('source476','source 476'),('treec9d','tree c9d'),('Full14','Full 14'),('PASS398','PASS 398'),('FAIL398','FAIL 398'),('FAIL:3PASS/1FAIL','FAIL: 3 PASS/1 FAIL'),('Desktop14','Desktop 14'),('reported5,007','reported 5,007'),('against4,600,000','against 4,600,000'),('the1904','the 1904'),('the305','the 305'),('within7,800','within 7,800'),('exactly543','exactly 543'),('source3f','source 3f'),('Mobile14','Mobile 14'),('reported1,719','reported 1,719'),('Ames1904','Ames 1904'),('contains412','contains 412'),('All63','All 63'),('full18','full 18'),('completed12PASS/6FAIL','completed 12 PASS/6 FAIL'),('overallFAIL','overall FAIL'),('desktop13','desktop 13'),('remains160/0','remains 160/0'),('immutable248 stages1–2 passed194/0','immutable 248 stages 1–2 passed 194/0'),('stages9–12 passed69/0','stages 9–12 passed 69/0'),('source-labelled14/15','source-labelled 14/15'),('both14 passed140/0','both 14 passed 140/0'),('ca9a desktop14','ca9a desktop 14'),('published8f','published 8f'),('passed20/0','passed 20/0'),('narrow16/0','narrow 16/0'),('PR#1213','PR #1213'),('into1175','into 1175'),('boundary2026','boundary 2026')]:body=body.replace(old_text,new_text)
assert body.startswith(opening+'\n\n') and 'PENDING_FINAL_ACTUAL_TERMINALS'not in body and '**FAIL: 3 PASS/1 FAIL**'in body and 'b7cde6d86e42edd1c80204642c40ca8b683ceffd'in body
(D/'PR-BODY-EXACT-PATCH.md').write_text(body)
response=api('ACTUAL-PR-BODY-PATCH','pulls/1175','PATCH',{'body':body});assert response['state']=='open' and response['head']['sha']==SOURCE and response['body']==body,'Actual PATCH response differs: STOP without retry'
receipt={'at':now(),'method':'REST_PATCH','route':'repos/kevinrhaas/chicago/pulls/1175','PATCH_attempts':1,'PATCH_actual_success':True,'GETs':2,'source':SOURCE,'owned_lease':LEASE,'preimage_sha256':hashlib.sha256(old.encode()).hexdigest(),'body_sha256':hashlib.sha256(body.encode()).hexdigest(),'actual_response_body_sha256':hashlib.sha256(response['body'].encode()).hexdigest(),'opening_person_period_provenance_byteexact':True,'original_failure_history_preserved':True,'fresh_smoke_batch':'3PASS_1FAIL_OVERALL_FAIL','desktop14_over_cap':305,'new_DEVb7_unqualified':True,'merge':False,'app_edits':False,'CI_dispatches':0,'smoke_dispatches':0,'retries':0,'actual_PR_url':response['html_url']}
(D/'PATCH-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
