## T-2793 — Parked W01 timber material increment

Modern CC0 wood texture maps improve the existing three reconstructed 1835 farm-box wagons while retaining their geometry, stands and original paint/iron. The original parked source and both covered-wagon finish families remain exact; a separate cloth-only increment preserves their colors and identities. Four actual native views support a bounded material improvement; GPL project charts and CC0 source pixels have explicit provenance, and no historic finish or specimen is claimed.

Next: normal integrated DEV derivation and full preflight, followed by normal published mobile/desktop placement and combined-budget qualification (eight pooled batches versus five baseline). Photographic refinement, occupants, hitching, driving, riding and boarding remain open; this is a material increment under T-2793.

- T-2980: carry the already generated20–28mm cloth-drape increment for the two existing distinct1835 covered wagons; preserve current terrain proof and all IDs/seeds/stands/yokes. Historical065646706 source+publishedstage8 qualification is separate from current combined integration. Photographic cloth/wood/iron, compressed LOD, occupancy and interaction remain open.
