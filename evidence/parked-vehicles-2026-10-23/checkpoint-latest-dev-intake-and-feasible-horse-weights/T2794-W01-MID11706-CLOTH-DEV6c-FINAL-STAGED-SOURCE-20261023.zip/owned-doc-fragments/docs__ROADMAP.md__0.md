## T-2794 — Parked Brougham distance model and prototype replacement

The Brougham replaces only the obsolete1904C02 display, retaining its own existing qualified stand and the five distinct1835wagons; C02 assets and model remain compatible. Exact33,502near geometry is paired with the unchanged validated11,706mid candidate. All physical feature categories, materials, nodes, anchors, contacts and original near conservative proxy remain; only source tessellation and active triangle reporting change. Eight fixed native views support distance-LOD appearance, not photographic or world-budget acceptance.

Next: finish normal integrated source verification and published desktop/mobile qualification at unchanged cameras and caps, including combined budgets and full body/pole/ground/tree clearance. Earlier failed units remain recorded. Photographic refinement, people, horses, occupied driving, doors, hitching, boarding and traffic remain open.

