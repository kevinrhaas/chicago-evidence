### L-w01-timber-finish-2793 — Parked farm-box timber uses modern CC0 wood texture maps

**Decision:** The three existing reconstructed 1835 W01 farm-box wagons share a finer timber surface adapted from Rob Tuytel's Poly Haven Fine Grained Wood CC0 texture maps. Native 2K color, roughness and OpenGL normal maps are rotated, cropped and reduced 2x, with an eight-pixel periodic edge blend, corresponding tangent-normal rotation and bounded 1.5 linear color exposure. Project-authored UV/tangent/index charts and freshly regenerated project geometry remain GPL-3.0-or-later; original paint, iron and cut-end pixels retain their CC0 provenance. The exact sources and changes are recorded in `assets/authored/transport/wagon_parked_fine_wood/SOURCE.json`.

**What is invented:** Brown timber finish, grain scale and chart orientation are reconstructed from a modern optical analogy. The reference does not identify an 1835 species, coating, manufacturer, model, owner or Chicago specimen. No geometry, node pivot, wheel contact, placement, bearing or covered-wagon variation changes. Eight pooled material batches replace five for this asset; the 6,291,168-byte RGBA8-plus-mips figure is an image-dimension estimate, not measured GPU allocation. Four native fixed-camera images support a bounded material improvement; photographic, normal published-world and combined-budget acceptance remain open.

**How to resolve:** Period close photographs or conserved material from an identified wagon would replace the surface inference; current-world mobile/desktop inspection must still establish rendering and budget acceptance.
**Ticket:** T-2793.
**Recorded:** 2026-10-23.


