# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,traceback
R=Path(__file__).resolve().parent;O=R/'ACTUAL-FINAL-VALIDATION-BATCH-20261023';O.mkdir(exist_ok=False)
start=time.monotonic();deadline=start+13;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
raw=R/'ACTUAL-ONE-UNIT-20261023/generated-mid/brougham.glb';indexed=R/'ACTUAL-ONE-UNIT-20261023/brougham-mid.glb'
record={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'maximum_seconds':13,'generator_invocations':0,'app_writes':False,'browser':False,'prior_three_whole_units_remain_FAIL':True,'tasks':[],'errors':[]}
def save():(O/'TERMINAL.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 assert sha(raw)=='48a9224ba38da8a1beb809f6970a7d51801da8d032332a52da4b60590c44102f'
 assert sha(indexed)=='d6d6709ec4dda73e84a916e71dfb9dba6ad16961423a4f3babebdf58363c20d2'
 tasks=[('01-independent-khronos-FIRST',['node',str(R/'validate_existing_continuation.cjs'),str(O),str(raw),str(indexed)]),('02-native-geometry-interface-and-original-anchor-lists',[sys.executable,str(R/'final_pinned_native.py')])]
 for name,args in tasks:
  row={'name':name,'started_seconds':time.monotonic()-start};record['tasks'].append(row)
  try:
   remaining=deadline-time.monotonic();assert remaining>0
   p=subprocess.run(args,capture_output=True,timeout=remaining)
   (O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr)
   row.update(exit_code=p.returncode,pass_result=p.returncode==0)
   if p.returncode:record['errors'].append({'task':name,'exit_code':p.returncode,'stderr':p.stderr.decode(errors='replace')})
  except BaseException as error:
   row.update(pass_result=False,error=repr(error));record['errors'].append({'task':name,'error':repr(error)})
  row['ended_seconds']=time.monotonic()-start;save()
except BaseException as error:record['errors'].append({'batch_error':repr(error),'traceback':traceback.format_exc()})
record.update(status='PASS_EXISTING11706_NATIVE_KHRONOS_ONLY' if not record['errors']else'FAIL_NO_RETRY',seconds=round(time.monotonic()-start,6),ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),owned_subprocesses_active=False,appearance_accepted=False,world_budget_accepted=False)
save();print(json.dumps(record),flush=True);sys.exit(0 if not record['errors']else 1)
