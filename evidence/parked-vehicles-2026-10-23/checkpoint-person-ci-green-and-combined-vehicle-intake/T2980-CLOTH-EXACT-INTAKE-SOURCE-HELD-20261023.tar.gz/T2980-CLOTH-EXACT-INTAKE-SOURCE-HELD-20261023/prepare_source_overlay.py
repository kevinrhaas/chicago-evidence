from pathlib import Path
import copy,difflib,hashlib,json,subprocess
ROOT=Path('/tmp/chicago-covered-sag');APP=ROOT/'chicago/4d';REF='0656467069ee3f8d0a40685ee571ceaaf4b0a2d7';OUT=Path('/workspace/shared/T2980-CLOTH-EXACT-INTAKE-SOURCE-HELD-20261023');OUT.mkdir();OVER=OUT/'overlay';FRAG=OUT/'fragments';FRAG.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def git(rel,ref=REF):return subprocess.check_output(['git','-C',str(ROOT),'show',ref+':chicago/4d/'+rel])
def emit(rel,raw):
 p=OVER/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);return p
source_rel='assets/authored/transport/wagon_covered/SOURCE.json';curraw=(APP/source_rel).read_bytes();current=json.loads(curraw);prior=json.loads(git(source_rel,REF+'^'));candidate=json.loads(git(source_rel));assert set(k for k in set(current)|set(prior)if current.get(k)!=prior.get(k))=={'actual_terrain_qualification'}
# Merge cloth-only source changes onto current metadata: preserve complete current terrain proof.
merged=copy.deepcopy(current)
for key in candidate:
 if candidate.get(key)!=prior.get(key):merged[key]=copy.deepcopy(candidate[key])
assert merged['actual_terrain_qualification']==current['actual_terrain_qualification']
ciroot=Path('/workspace/shared/COVERED1208-BLOCKER1205-FINITE-AUDIT-20261022-195613');ci=json.loads((ciroot/'RECEIPT.json').read_text())['PR1208'];historical={}
for run in ci['targeted_smokes']if 'targeted_smokes'in ci else ci.get('published_smokes',[]):pass
# Saved receipt's two terminal source-bound stage8 cells; discover its explicit list by shape.
cells=next(v for v in ci.values()if isinstance(v,list)and len(v)==2 and all(isinstance(i,dict)and 'actual_stage'in i for i in v))
for cell in cells:
 log=(ciroot/cell['full_job_log']).read_bytes();assert sha(log)==cell['full_job_log_sha256'];assert cell['actual_checkout_sha']==REF and str(cell['actual_stage'])=='8'and cell['targeted_cell_qualified']is True
 historical[cell['actual_viewport']]={'run_id':cell['run_id'],'job_id':cell['job_id'],'stage':8,'result':cell['smoke_result'],'job_log_sha256':sha(log)}
assert set(historical)=={'desktop','mobile'}
full=Path('/workspace/shared/T2980-COVERED-SAG-NORMAL-PREFLIGHT-V2-20261022/FINAL-RECEIPT.json');proof=json.loads(full.read_text());assert proof['commit']==REF and proof['normal_preflight']['exit']==0 and proof['normal_preflight']['check_steps']==1046 and proof['normal_preflight']['selftests']==381 and proof['postcommit_publish_exit']==proof['postcommit_mirror_exit']==0
merged['canvas_drape_refinement']['historical_qualification']={'source_commit':REF,'source_tree':proof['tree'],'normal_preflight':'1046 checks /381 self-tests PASS','postcommit_publication_and_mirror':'PASS, both exact GLB source/published byte equality','published_stage8':historical,'scope':'Historical exact-source qualification only. Current combined integration, full-world budget, photographic, compressed LOD and occupied acceptance remain open.'}
emit(source_rel,(json.dumps(merged,indent=2)+'\n').encode())
paths=['tools/transport/wagon_covered/build.py','changelog.d/T-2980.json']
for model in ['covered_w01_western_blue','covered_w01_wolfpoint_oak']:
 for name in ['covered-w01.glb','covered-w01.json']:paths.append('renderers/web/transport/covered-wagon/'+model+'/'+name)
preimages={source_rel:{'sha256':sha(curraw),'bytes':len(curraw)}};source_products={}
for rel in paths:
 p=APP/rel;actual=p.read_bytes()if p.exists()else None;old=git(rel,REF+'^')if rel!='changelog.d/T-2980.json'else None;new=git(rel);assert actual==old,rel+' no longer equals exact source preimage';preimages[rel]={'sha256':sha(actual)if actual else None,'bytes':len(actual)if actual else None,'must_be_absent':actual is None};emit(rel,new);source_products[rel]={'sha256':sha(new),'bytes':len(new),'exact_source_commit_bytes':True}
# Preserve source's existing liberty section as a fragment; never overwrite shared current liberty/docs files.
lib=json.loads(git('data/liberties.json'))
def records(x):
 if isinstance(x,dict):
  if x.get('id')=='L-covered-wagons-2980':yield x
  for v in x.values():yield from records(v)
 elif isinstance(x,list):
  for v in x:yield from records(v)
entry=next(records(lib));field=next(v for v in entry['sections']if v.get('label')=='Canvas refinement, 2026-10-22')if 'sections'in entry else None
if field is None:
 lists=[v for v in entry.values()if isinstance(v,list)];field=next(i for group in lists for i in group if isinstance(i,dict)and i.get('label')=='Canvas refinement, 2026-10-22')
(FRAG/'liberty-section-append.json').write_text(json.dumps({'target_id':'L-covered-wagons-2980','append_section_if_absent':field,'instruction':'Apply to current resolved data/liberties.json and run supported compile_liberties.py; never replace historic whole file or hand-edit generated docs.'},indent=2)+'\n')
(FRAG/'STATUS-addendum.md').write_text('### T-2980 — Exact previously qualified covered-cloth increment\n\nThe Western Hotel blue/oxide and Wolf Point oak/darkoak covered wagons retain distinct seeded finishes, aging, yokes, stands, bearings and running gear. Only their reconstructed inter-bow cloth/hem drape deepens from8–10mm to20–28mm over750mm spans, with1.2mm creases unchanged. The exact prior aaffa339/22072e6f products remain17,292triangles,26sourceprimitives,9materialgroups and8,388,608RGBA8+mipsdimension-estimate bytes each. Project geometry/source GPL-3.0-or-later; original procedural pixels CC0; no historical textile, manufacturer or owner attestation.\n\nHistorical source065646706 passed normal1046checks/381self-tests, postcommit publication/mirror, and published desktop8/mobile8 each21passed/0failed. Those exact-source historical results do not qualify this combined integration. Initial mobile visual evidence remains6images from a deadline failure plus a separate2image continuation, with unfrozen residents/foliage; photographic materials/cloth construction, compressed LOD, occupied use and whole-world acceptance remain open. Current terrain-proof bytes are preserved.\n')
(FRAG/'ROADMAP-addendum.md').write_text('- T-2980: carry the already generated20–28mm cloth-drape increment for the two existing distinct1835 covered wagons; preserve current terrain proof and all IDs/seeds/stands/yokes. Historical065646706 source+publishedstage8 qualification is separate from current combined integration. Photographic cloth/wood/iron, compressed LOD, occupancy and interaction remain open.\n')
patch=[]
for p in sorted(OVER.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(OVER).as_posix()
 try:new=p.read_text();old=(APP/rel).read_text()if(APP/rel).exists()else''
 except UnicodeDecodeError:continue
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel if(APP/rel).exists()else'/dev/null',tofile='b/'+rel))
(OUT/'UNAPPLIED-CLOTH-ONLY.patch').write_text(''.join(patch));(OUT/'PREIMAGE-PINS.json').write_text(json.dumps(preimages,indent=2)+'\n');inventory={p.relative_to(OVER).as_posix():{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}for p in sorted(OVER.rglob('*'))if p.is_file()};(OUT/'OVERLAY-INVENTORY.json').write_text(json.dumps(inventory,indent=2)+'\n')
terrain=current['actual_terrain_qualification'];terrain_pins=[]
for rel,pin in terrain['data_sha256'].items():
 actual=sha((ROOT/rel).read_bytes());terrain_pins.append({'path':rel,'current_sha256':actual,'source_proof_sha256':pin,'matches':actual==pin});assert actual==pin
protected=['data/transport/parked/covered-w01.json','tools/transport/generate_covered_wagons.py','tools/transport/wagon_covered/check.py','tools/transport/wagon_covered/test_identity.py','renderers/web/transport/parked-wagon/wagon-w01.glb']
protected_pins={rel:sha((APP/rel).read_bytes())for rel in protected}
report={'status':'FINITE_STATIC_SOURCE_DELTA_CLEAN_LOW_RISK_EXACT_CLOTH_OVERLAY_PREPARED_APP_UNTOUCHED','source_commit':REF,'source_tree':proof['tree'],'exact_source_product_paths':source_products,'overlay_files':len(inventory),'metadata_merge':'Only source-parent→candidate cloth fields merged; complete current actual_terrain_qualification preserved; historical qualification explicitly separated','current_source_sha256':sha(curraw),'merged_source_sha256':inventory[source_rel]['sha256'],'source_copyleft':'Original project GPL-3.0-or-later geometry and source; original procedural pixels CC0-1.0. No external models or pixels.','scope':'Two old1835individual covered wagons only;20–28mmdrape; no oldW01/Brougham/DEV/UI/sharedwhole-doc import','cost_per_variant':{'triangles':17292,'source_primitives':26,'material_groups':9,'RGBA8_mips_dimension_estimate':8388608,'candidate_glb_bytes':2970448,'delta_triangles':0,'delta_primitives':0,'delta_material_groups':0,'delta_image_memory':0},'protected_current_pins':protected_pins,'protected_terrain_byte_pins':terrain_pins,'historical_generation_scope':'Prior actual22.424s,1883588byteparentprefix+101streams exact;only6cloth/hemPOSITION/NORMAL/TANGENTstreams change. Bounded4032cloth/hemvs1920bowtriangles no intersections;notexhaustivecollision/occupiedproof.','historical_qualification':merged['canvas_drape_refinement']['historical_qualification'],'historical_source_capsule':{'path':'/workspace/shared/T2980-COVERED-SAG-065646706-NORMAL-PREFLIGHT-PUSHED-20261022.tar.gz','sha256':'2b6f4ddd38d070e66de7d43e3d64d7f06e3cf0ef7af879486bae018412289f95'},'current_execution_scope':'Static file/Git/JSON/hash inspection and external source preparation only; no generator/checker/browser/publish/fullgate/app/index/ref/ticket writes.','application_decision':'Root decides; carriage agent sole app writer. Compare every preimage before applying; merge liberty/docs fragments into resolved current files, do not overwrite shared docs.','quality_limits':'Subtle form increment only, no photographic completion. Prior mobile6FAIL+2continuationPASS population/foliage caveat retained. Current combined app qualification pending.'}
(OUT/'FINITE-INTAKE-ASSESSMENT.json').write_text(json.dumps(report,indent=2)+'\n');(OUT/'README.md').write_text('UNAPPLIED source-only exact cloth overlay. Seven files:core2linedelta,exacttwoGLBs+sidecars,newT2980changelog,currentSOURCE mergedwithcurrentterrainproofpreserved. Binary files are inoverlay;patch istextonly. Sharedliberty/docs arefragments only. Root mustdecidebeforecarriagesolewriterapplies. Noapp/queue/Git/browser/generator/checker/publishwrite/runperformed. Historicalqualificationisnotcurrentcombinedqualification.\n');print(json.dumps({'out':str(OUT),'overlay_files':len(inventory),'scope':list(inventory),'current_terrain_pins_preserved':True,'historical_stage8_logs_hash_verified':True,'app_untouched':True},indent=2))
