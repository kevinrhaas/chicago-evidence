// SPDX-License-Identifier: GPL-3.0-or-later
// Isolated appearance/transition diagnostic. Real app modules, synthetic floor.
import * as T from 'three';
import {createWorld} from './js/world.js';
import {createConfidenceView} from './js/confidence.js';
import {createParkedTransport} from './js/parked-transport.js';
const profile=new URLSearchParams(location.search).get('profile');
if(!['desktop','mobile'].includes(profile))throw Error('Explicit prepared profile required');
const mobile=profile==='mobile',canvas=document.querySelector('canvas');
const renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance',stencil:false,preserveDrawingBuffer:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,mobile?1:1.5));renderer.setSize(innerWidth,innerHeight,true);
const scene=new T.Scene(),problems=[],sceneJson=await(await fetch('./scene1904.json')).json(),datum=await(await fetch('./datum.json')).json();
const world=createWorld({renderer,scene,sceneJson,datum,lowSpec:mobile,problems});world.setShadowRig(240);
const floor=new T.Mesh(new T.PlaneGeometry(200,200),new T.MeshStandardMaterial({color:0xc9c7b9,roughness:1}));floor.rotation.x=-Math.PI/2;floor.position.set(1397.9,-.004,3240);floor.receiveShadow=true;scene.add(floor);
const confidence=createConfidenceView();confidence.set(false);
const bufferSize=new T.Vector2();
const transport=await createParkedTransport({dataBase:new URL('./data/',location.href),sceneId:'1904',terrain:{surfaceHeight:()=>0},groundHeight:()=>0,confidence,detail:mobile?'balanced':'full',problems,getDrawingBufferHeight:()=>renderer.getDrawingBufferSize(bufferSize).y});scene.add(transport.group);
if(problems.length)throw Error(JSON.stringify(problems));
const instance=transport.instances[0];if(!instance?.lod)throw Error('Actual candidate runtime LOD not created');
const camera=new T.PerspectiveCamera(62,innerWidth/innerHeight,.1,3000);
camera.fov=T.MathUtils.clamp(2*Math.atan(Math.tan(76*Math.PI/360)/camera.aspect)*180/Math.PI,55,94);camera.updateProjectionMatrix();
const hypothesis=await(await fetch('./camera-hypothesis.json')).json();
// Original catalogue direction, rotated with the unchanged real stand bearing.
const direction=new T.Vector3(...hypothesis.fit.basis.towardCamera).applyAxisAngle(new T.Vector3(0,1,0),instance.group.rotation.y).normalize();
const hash=async buffer=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',buffer))).map(x=>x.toString(16).padStart(2,'0')).join('');
window.nativeInputHashes=Object.fromEntries(await Promise.all(['transport/parked-brougham/brougham-near.glb','transport/parked-brougham/brougham-mid.glb','plate0095.jpg'].map(async p=>[p,await hash(await(await fetch(p)).arrayBuffer())])));
let current=null,disposed=false;
const triangles=root=>{let count=0;root.traverse(n=>{if(n.isMesh)count+=(n.geometry.index?.count??n.geometry.attributes.position.count)/3});return count};
window.setNativeDistance=distance=>{
 if(disposed||![23.99,24.01].includes(distance))throw Error('Only frozen transition distances allowed');
 camera.position.copy(instance.group.position).addScaledVector(direction,distance);camera.lookAt(instance.group.position);camera.updateMatrixWorld(true);transport.update(camera);scene.updateMatrixWorld(true);world.follow(camera.position);world.aim(camera);
 current={distance,selected:instance.active_lod,selectedTriangles:instance.active_triangles,threshold:instance.lod.levels[1].distance,hysteresis:instance.lod.levels[1].hysteresis,originalVisibility:instance.lod.levels.map(l=>l.object.visible)};
 return structuredClone(current);
};
window.renderNativeLevel=detail=>{
 if(disposed||!current||!['near','mid'].includes(detail))throw Error('Frozen paired native level required');
 const level=detail==='near'?0:1;instance.lod.levels.forEach((l,i)=>{l.object.visible=i===level});
 renderer.render(scene,camera);renderer.getContext().finish();
 const selected=instance.lod.levels[level].object,full=new T.Box3().setFromObject(selected,true),corners=[];
 for(const x of[full.min.x,full.max.x])for(const y of[full.min.y,full.max.y])for(const z of[full.min.z,full.max.z])corners.push(new T.Vector3(x,y,z).project(camera));
 const actual=renderer.getDrawingBufferSize(new T.Vector2());
 const row={profile,detail,scope:'Forced native A/B at unchanged diagnostic pose; selected runtime level recorded separately. Synthetic floor is not actual world ground.',selection:structuredClone(current),camera:{position:camera.position.toArray(),quaternion:camera.quaternion.toArray(),fov:camera.fov,near:camera.near,far:camera.far,projection:camera.projectionMatrix.toArray(),direction:direction.toArray()},viewport:[innerWidth,innerHeight],drawingBuffer:actual.toArray(),pixelRatio:renderer.getPixelRatio(),actualGeometryTriangles:triangles(selected),mergedMaterialBatches:selected.children.length,modelBounds:{min:full.min.toArray(),max:full.max.toArray()},ndcMin:[0,1,2].map(k=>Math.min(...corners.map(p=>p.getComponent(k)))),ndcMax:[0,1,2].map(k=>Math.max(...corners.map(p=>p.getComponent(k)))),renderer:{colorSpace:renderer.outputColorSpace,toneMapping:renderer.toneMapping,exposure:renderer.toneMappingExposure,shadowType:renderer.shadowMap.type,shadowEnabled:renderer.shadowMap.enabled},world:world.describe(),confidenceEnabled:confidence.enabled,hidden:confidence.hidden,drawCalls:renderer.info.render.calls,renderTriangles:renderer.info.render.triangles,glError:renderer.getContext().getError(),problems:[...problems]};
 document.querySelector('#label').textContent=`${profile} · ${current.distance}m · forced${detail} (${current.selected}selected)`;
 return row;
};
window.finishNativePair=()=>{instance.lod.levels.forEach((l,i)=>{l.object.visible=current.originalVisibility[i]});};
window.disposeNativeComparison=async()=>{
 if(disposed)return{alreadyDisposed:true};disposed=true;
 const sourceMaterials=new Set(),batchGeometries=new Set();transport.group.traverse(n=>{if(n.geometry)batchGeometries.add(n.geometry);if(n.material)sourceMaterials.add(n.material)});
 // Retain actual single-renderer PBR LUT before disposing material properties.
 const dfgs=new Set();for(const m of sourceMaterials){const t=renderer.properties.get(m).uniforms?.dfgLUT?.value;if(t)dfgs.add(t)}
 const before={geometries:renderer.info.memory.geometries,textures:renderer.info.memory.textures},gl=renderer.getContext();let geometryEvents=0;for(const g of batchGeometries)g.addEventListener('dispose',()=>geometryEvents++);
 transport.dispose();await Promise.resolve();await Promise.resolve();floor.geometry.dispose();floor.material.dispose();world.light.shadow.dispose();world.dispose();scene.environment=null;
 const dfg=[];for(const t of dfgs){const handle=renderer.properties.get(t).__webglTexture;dfg.push({name:t.name,liveBefore:!!handle&&gl.isTexture(handle)});t.dispose();dfg.at(-1).liveAfter=!!handle&&gl.isTexture(handle)}
 scene.clear();renderer.dispose();
 return{before,expectedMergedGeometries:batchGeometries.size,mergedGeometryDisposeEvents:geometryEvents,remainingGeometries:renderer.info.memory.geometries,remainingTextures:renderer.info.memory.textures,sceneChildren:scene.children.length,dfg,sourceCacheDisposedViaActualRuntime:true};
};
window.nativeComparisonReady=true;
