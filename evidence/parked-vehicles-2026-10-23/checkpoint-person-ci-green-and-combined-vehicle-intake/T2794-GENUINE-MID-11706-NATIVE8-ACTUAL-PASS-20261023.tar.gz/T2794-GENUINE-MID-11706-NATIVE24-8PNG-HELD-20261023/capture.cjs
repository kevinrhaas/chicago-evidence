const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
const ROOT=__dirname,OUT=path.join(ROOT,'actual'),port=Number(process.argv[2]);
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),need=(v,m)=>{if(!v)throw Error(m)};
need(fs.existsSync(path.join(ROOT,'RUN-INTENT.json')),'Released once-only owner required');fs.mkdirSync(OUT);
const result={scope:'Eight forced-near/mid isolated paired frames at23.99/24.01m; exact candidate runtime selector and ordinary1904world renderer/lighting, source-catalogue direction. Not current world, GPU-budget, half-pixel or photographic acceptance.',started:new Date().toISOString(),pass:false,rows:[],attemptedRows:[],errors:[],disposal:[],browserClosed:false,expectedImages:8};
const save=()=>fs.writeFileSync(path.join(OUT,'receipt.json'),JSON.stringify(result,null,2)+'\n');let browser,context,page;
const watchdog=setTimeout(()=>{result.error='Original165second browser deadline';save();browser?.close().finally(()=>process.exit(124))},165000);
(async()=>{try{
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox'],timeout:15000});
 for(const [profile,width,height,dpr,touch]of[['desktop',1280,800,1,false],['mobile',390,780,2,true]]){
  context=await browser.newContext({viewport:{width,height},deviceScaleFactor:dpr,hasTouch:touch});page=await context.newPage();
  const note=(kind,message)=>{result.errors.push({profile,kind,message});save()};page.on('pageerror',e=>note('page',e.message));page.on('console',m=>{if(m.type()==='error')note('console',m.text())});page.on('requestfailed',r=>note('request',r.url()+':'+r.failure()?.errorText));page.on('response',r=>{if(r.status()>=400)note('http',r.status()+' '+r.url())});
  await page.route('**/*',r=>{const u=new URL(r.request().url());return ['data:','blob:'].includes(u.protocol)||(u.protocol==='http:'&&u.hostname==='127.0.0.1'&&u.port===String(port))?r.continue():r.abort('blockedbyclient')});
  await page.goto(`http://127.0.0.1:${port}/?profile=${profile}`,{waitUntil:'load',timeout:20000});await page.waitForFunction(()=>window.nativeComparisonReady&&document.querySelector('aside img').complete,null,{timeout:25000});
  const inputs=await page.evaluate(()=>window.nativeInputHashes);
  need(inputs['transport/parked-brougham/brougham-near.glb']==='ec2bfc0da49b570429dbcd8db39250aa6f1bbf55587570f0dafad9a42afc4ee5','Exact original near');need(inputs['transport/parked-brougham/brougham-mid.glb']==='d6d6709ec4dda73e84a916e71dfb9dba6ad16961423a4f3babebdf58363c20d2','Exact genuine mid');need(inputs['plate0095.jpg']==='b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe','Exact source plate');
  for(const distance of[23.99,24.01]){
   const selection=await page.evaluate(d=>setNativeDistance(d),distance);need(selection.selected===(distance<24?'near':'mid')&&selection.threshold===24&&selection.hysteresis===.05,'Actual frozen transition selection');
   let binding=null;
   for(const detail of['near','mid']){
    const row=await page.evaluate(d=>renderNativeLevel(d),detail);result.attemptedRows.push(row);save();
    if(binding)for(const field of['camera','renderer','world','viewport','drawingBuffer','modelBounds'])need(JSON.stringify(binding[field])===JSON.stringify(row[field]),'Forced near/mid pair changes '+field);else binding=row;
    need(row.actualGeometryTriangles===(detail==='near'?33502:11706)&&row.mergedMaterialBatches===7,'Actual merged native geometry count');need(row.confidenceEnabled===false&&!Object.values(row.hidden).some(Boolean),'Ordinary Normal confidence');need(row.renderer.exposure===.95&&row.renderer.shadowEnabled&&row.camera.fov===(profile==='desktop'?55:94),'Ordinary app world/lens settings');need(row.pixelRatio===1&&row.drawingBuffer[0]===width&&row.drawingBuffer[1]===height,'Actual ordinary render sampling');need(row.ndcMin.every(x=>x>=-1)&&row.ndcMax.every(x=>x<=1),'Whole unchanged model/pole inside fixed camera');need(row.glError===0&&row.problems.length===0&&result.errors.length===0,'Actual runtime errors');
    const png=`${profile}-${distance.toFixed(2)}m-forced-${detail}.png`;await page.screenshot({path:path.join(OUT,png),timeout:15000});result.rows.push({...row,png,image_sha256:hash(path.join(OUT,png)),normalBrowserScreenshot:true});save();
   }
   await page.evaluate(()=>finishNativePair());
  }
  const disposal=await page.evaluate(()=>disposeNativeComparison());result.disposal.push({profile,...disposal});save();need(disposal.expectedMergedGeometries===disposal.mergedGeometryDisposeEvents&&disposal.remainingGeometries===0&&disposal.remainingTextures===0&&disposal.sceneChildren===0&&disposal.dfg.every(x=>x.liveBefore&&!x.liveAfter),'Actual owned resource disposal');
  await context.close();context=null;page=null;
 }
 need(result.rows.length===8&&result.disposal.length===2&&result.errors.length===0,'Eight-frame native completeness');result.pass=true;
}catch(error){result.error=String(error.stack||error);process.exitCode=1}finally{
 clearTimeout(watchdog);if(page&&!page.isClosed()){try{result.disposal.push({profile:'failure-finally',...await page.evaluate(()=>disposeNativeComparison())})}catch(error){result.disposal.push({profile:'failure-finally',error:String(error)})}}if(context)await context.close().catch(()=>{});if(browser){await browser.close();result.browserClosed=!browser.isConnected()}result.finished=new Date().toISOString();save();
}if(!result.pass)throw Error(result.error);console.log('PASS8native near/mid transition images; actual browser closed; world/photo acceptance remains open.');})().catch(e=>{console.error(e);process.exitCode=1});
