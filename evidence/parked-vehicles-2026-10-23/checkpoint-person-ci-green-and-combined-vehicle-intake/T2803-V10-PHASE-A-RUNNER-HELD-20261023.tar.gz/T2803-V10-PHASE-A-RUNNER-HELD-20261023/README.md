# V10 source phase A — frozen runner, NOT RUN

Root may release only this source preflight. No LP/QP, weight field, gait pose, checker, exporter, browser/server, install, app/ticket/Git or workflow action is authorized.

Read FORMULATION-CLARIFICATIONS.json first. GPU skinning requires at most four influences per vertex; it does not require adjacent vertices to share a union of four. The edge-union cap is this proposal's conservative assumption and may reject perfectly representable continuous fields. Likewise the chosen ell Lipschitz bound is an extra regularizer, not the original skin-physics gate. Neither kind of failure proves every weights-only skin or bone placement impossible.

phase_a_HELD.py verifies all source pins and inherited frozen-walk co-motion evidence; reads the immutable neutral GLB; recreates original seam classes/protected vectors; makes exactly eight virtual graph/triangle-plane cuts at declared fetlock and proximal joints; inspects complete foot/triangle-star ownership and unchanged ground compatibility; and, only if all foot domains are valid, computes intrinsic collars, palettes, forced-boundary distances and protected-edge regularity. It reports original V8 chest and V9 foot witness memberships. Source geometry is never modified. It preserves every precondition failure and skips dependent analyses rather than invent missing domains.

Negative controls use actual rejected V9 weights and edges, actual source contact seed sets, and an explicit valid-per-vertex/union-five example. This phase does not run a gait test or claim photographic/anatomical acceptance.

run_once_HELD.py owns exactly one nice19, math1 process group. Its actual15second wall and512MiB RSS caps include numerical imports and source reads. It samples own-child RSS and records kernel peakRSS at terminal; it kills only its own process group upon a limit. It refuses any existing ACTUAL output directory, so no retry is implicit. Raw stdout/stderr, exact root release, result and terminal remain saved even on failure. Output budget16MiB.

To release, root makes a separate release JSON from RELEASE-TEMPLATE-HELD.json, changes released to true, records the root authorization/clean lane, and invokes the supervisor with that release path using the existing Python3.11 environment. All source hashes must still match. Never change the template to evade a failed run; a retry requires new explicit scope.

The runner and supervisor have had a text-only AST syntax review. They have NEVER executed/imported, and runtime/cost/passing preconditions remain unmeasured. Any source/runtime/resource failure is a preserved terminal failure, with no automatic next phase.
