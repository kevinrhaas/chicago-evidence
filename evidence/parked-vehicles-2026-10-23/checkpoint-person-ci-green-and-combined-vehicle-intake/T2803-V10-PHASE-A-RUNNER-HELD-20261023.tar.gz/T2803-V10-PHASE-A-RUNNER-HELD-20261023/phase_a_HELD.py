"""One root-released V10 source feasibility read; no solver/weights/poses/export.

Palette-union <=4 and the ell Lipschitz cap are conservative assumptions of
THIS formulation. They are not GPU edge requirements or original skin physics.
"""
from pathlib import Path
import ast, hashlib, json, sys, time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components, dijkstra
from actual_model import Model

HERE = Path(__file__).resolve().parent
ELL = 0.3263955630216535
EPS = 1e-10
QUANT = 1e-6
CONTOUR_QUANT = 1e-5


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def quotient(weights):
    q = weights.copy()
    q[..., 1] += q[..., 2:6].sum(axis=-1)
    q[..., 2:6] = 0
    return q


def gradient_violation(a, b, length):
    jump = float(np.abs(quotient(a) - quotient(b)).max())
    bound = float(length / ELL)
    return {'jump': jump, 'bound': bound, 'fails_proposal_regularizer': jump > bound + 1e-9}


def seed_membership(selected, own, other):
    return {'all_own_seeds_included': bool(selected[own].all()),
            'foreign_hoof_seed_classes': np.flatnonzero(selected & other).tolist()}


def contour_summary(points, triangles, signed, selected):
    """Actual arbitrary-plane triangle intersections for the selected component."""
    st = signed[triangles]
    mask = (st.min(1) < -EPS) & (st.max(1) > EPS) & selected[triangles].any(1)
    cross_triangles = triangles[mask]
    adjacency = {}
    for tri in cross_triangles:
        hits = []
        for i, j in ((0, 1), (1, 2), (2, 0)):
            a, b = int(tri[i]), int(tri[j])
            if signed[a] * signed[b] < 0:
                point = points[a] + signed[a] / (signed[a] - signed[b]) * (points[b] - points[a])
                hits.append(tuple(np.rint(point / CONTOUR_QUANT).astype(np.int64)))
        if len(hits) != 2 or hits[0] == hits[1]:
            continue
        a, b = hits
        adjacency.setdefault(a, set()).add(b)
        adjacency.setdefault(b, set()).add(a)
    remaining = set(adjacency)
    closed = open_count = 0
    component_sizes = []
    while remaining:
        todo = [remaining.pop()]
        component = []
        while todo:
            item = todo.pop()
            component.append(item)
            for nxt in adjacency[item]:
                if nxt in remaining:
                    remaining.remove(nxt)
                    todo.append(nxt)
        is_closed = len(component) >= 3 and all(len(adjacency[x]) == 2 for x in component)
        closed += int(is_closed)
        open_count += int(not is_closed)
        component_sizes.append(len(component))
    return {'crossing_triangles': int(len(cross_triangles)),
            'closed_contours': closed, 'open_contours': open_count,
            'contour_component_sizes': component_sizes,
            'unique_closed_separating_contour': closed == 1 and open_count == 0}, cross_triangles


def section(points, triangles, edges, body_mask, pivot, incoming, own, foreign, tag):
    """Virtual graph cut only; actual input vertex/triangle arrays never change."""
    n = len(points)
    normal = incoming / np.linalg.norm(incoming)
    signed = (points - pivot) @ normal
    positive = body_mask & (signed > EPS)
    contained = positive[edges].all(1)
    es = edges[contained]
    graph = coo_matrix((np.ones(2 * len(es)),
                        (np.r_[es[:, 0], es[:, 1]], np.r_[es[:, 1], es[:, 0]])), shape=(n, n)).tocsr()
    _, labels = connected_components(graph, directed=False)
    seed_labels = np.unique(labels[own])
    selected = np.zeros(n, dtype=bool)
    if len(seed_labels) == 1 and positive[own].all():
        selected = positive & (labels == seed_labels[0])
    membership = seed_membership(selected, own, foreign)
    contour, crossing = contour_summary(points, triangles, signed, selected)
    boundary = np.unique(crossing.ravel()) if len(crossing) else np.zeros(0, dtype=int)
    # Vertices exactly on a plane are not jittered or silently assigned a side.
    on_plane = np.flatnonzero(body_mask & (np.abs(signed) <= EPS))
    ok = (positive[own].all() and len(seed_labels) == 1
          and membership['all_own_seeds_included'] and not membership['foreign_hoof_seed_classes']
          and contour['unique_closed_separating_contour'] and len(on_plane) == 0)
    report = {'tag': tag, 'pivot_m': pivot.tolist(), 'normal_distal_m': normal.tolist(),
              'plane_epsilon_m': EPS, 'no_plane_jitter': True,
              'own_seed_classes': int(len(own)), 'all_seeds_distal': bool(positive[own].all()),
              'seed_graph_components': int(len(seed_labels)), 'selected_classes': int(selected.sum()),
              'on_plane_original_classes': on_plane.tolist(), 'boundary_classes': int(len(boundary)),
              **membership, **contour, 'proposal_section_precondition_pass': bool(ok)}
    return report, selected, boundary


def main():
    start = time.monotonic()
    release_path, out = map(Path, sys.argv[1:])
    release = json.loads(release_path.read_text())
    assert release['released'] is True
    assert release['authorization'] == 'ONE_ROOT_RELEASED_V10_PHASE_A_PREFLIGHT'
    assert release['runner_sha256'] == sha(__file__)
    assert release['decoder_sha256'] == sha(HERE / 'actual_model.py')
    assert release['pins_sha256'] == sha(HERE / 'INPUT-PINS.json')
    assert release['clarifications_sha256'] == sha(HERE / 'FORMULATION-CLARIFICATIONS.json')
    assert release['maximum_runs'] == 1 and release['optimizations_authorized'] is False
    pins = json.loads((HERE / 'INPUT-PINS.json').read_text())
    for name, row in pins.items():
        assert sha(row['path']) == row['sha256'], name + ' source drift'
    assert not (out / 'PHASE-A-REPORT.json').exists()
    controls = json.loads(Path(pins['controls']['path']).read_text())
    contacts = json.loads(Path(pins['contacts']['path']).read_text())
    tail = json.loads(Path(pins['tail']['path']).read_text())
    inherited_solve = json.loads(Path(pins['v8_solve_receipt']['path']).read_text())
    co_motion = inherited_solve['co_moving_palette_reduction']
    assert co_motion['maximum_frozen_walk_affine_difference'] < 1e-7
    assert co_motion['excluded_root0_affine_difference'] > .01
    assert co_motion['joint_indices'] == [2, 3, 4, 5] and co_motion['destination_joint'] == 1
    gait_ast = ast.parse(Path(pins['gait']['path']).read_text())
    literals = {}
    for statement in gait_ast.body:
        if isinstance(statement, ast.Assign):
            for target in statement.targets:
                if isinstance(target, ast.Name) and target.id in ('PARAMETERS', 'THRESHOLDS'):
                    literals[target.id] = ast.literal_eval(statement.value)
    # Reading a literal declaration does not generate or evaluate any pose.
    model = Model(Path(pins['rig']['path']))
    pivots = np.asarray([r['rest_world_pivot_m'] for r in controls['nodes']])
    parts, rest = [], []
    for node_id in (26, 27, 28):
        pr = model.g['meshes'][model.g['nodes'][node_id]['mesh']]['primitives'][0]
        attrs = pr['attributes']
        j = model.accessor(attrs['JOINTS_0']).astype(int)
        w = model.accessor(attrs['WEIGHTS_0']).astype(float)
        ix = model.accessor(pr['indices']).astype(int).reshape(-1, 3)
        # Existing immutable decoder evaluates serialized NEUTRAL bind only.
        points = model.mesh(node_id)[0]
        parts.append((j, w, ix))
        rest.append(points)
    assert sum(len(p) for p in rest) == 11556
    assert sum(len(part[2]) for part in parts) == 14986
    keys, members, points, vc = {}, [], [], []
    for mi, ps in enumerate(rest):
        ids = []
        for vi, point in enumerate(ps):
            key = tuple(np.rint(point / QUANT).astype(np.int64))
            if key not in keys:
                keys[key] = len(points)
                points.append(point)
                members.append([])
            ci = keys[key]
            members[ci].append((mi, vi))
            ids.append(ci)
        vc.append(np.asarray(ids, dtype=int))
    points = np.asarray(points)
    n = len(points)
    spread = max(np.linalg.norm(rest[mi][vi] - points[ci])
                 for ci, group in enumerate(members) for mi, vi in group)
    assert spread <= 2e-6
    triangles = np.concatenate([vc[mi][part[2]] for mi, part in enumerate(parts)])
    body_triangles = vc[1][parts[1][2]]
    body_mask = np.zeros(n, dtype=bool)
    body_mask[vc[1]] = True
    area = np.linalg.norm(np.cross(points[triangles[:, 1]] - points[triangles[:, 0]],
                                   points[triangles[:, 2]] - points[triangles[:, 0]]), axis=1) / 2
    graph_triangles = triangles[area > 0]
    all_edges = np.unique(np.concatenate([np.sort(graph_triangles[:, [a, b]], axis=1)
                                          for a, b in ((0, 1), (1, 2), (2, 0))]), axis=0)
    all_edges = all_edges[all_edges[:, 0] != all_edges[:, 1]]
    lengths = np.linalg.norm(points[all_edges[:, 0]] - points[all_edges[:, 1]], axis=1)
    assert np.all(lengths > 1e-8)
    body_area = np.linalg.norm(np.cross(points[body_triangles[:, 1]] - points[body_triangles[:, 0]],
                                        points[body_triangles[:, 2]] - points[body_triangles[:, 0]]), axis=1) / 2
    body_graph_triangles = body_triangles[body_area > 0]
    body_edges = np.unique(np.concatenate([np.sort(body_graph_triangles[:, [a, b]], axis=1)
                                           for a, b in ((0, 1), (1, 2), (2, 0))]), axis=0)
    body_edges = body_edges[body_edges[:, 0] != body_edges[:, 1]]
    metric = coo_matrix((np.r_[lengths, lengths],
                         (np.r_[all_edges[:, 0], all_edges[:, 1]],
                          np.r_[all_edges[:, 1], all_edges[:, 0]])), shape=(n, n)).tocsr()
    mass = np.zeros(n)
    for k in range(3):
        np.add.at(mass, triangles[:, k], area / 3)
    source = np.zeros((n, 26))
    baseline = np.zeros((n, 26))
    for ci, group in enumerate(members):
        mi, vi = group[0]
        for j, w in zip(parts[mi][0][vi], parts[mi][1][vi]):
            source[ci, j] += w
            baseline[ci, j if j < 6 else 1] += w
    source /= source.sum(1)[:, None]
    baseline /= baseline.sum(1)[:, None]
    owned = source[:, 2:6].max(1) > source[:, [0, 1] + list(range(6, 26))].max(1)
    tail_classes = np.unique(vc[0][np.asarray(tail['exact_source_vertex_ids'], dtype=int)])
    assert len(tail_classes) == 901
    _, source_components = connected_components(metric, directed=False)
    assert np.array_equal(np.flatnonzero(source_components == source_components[tail_classes[0]]), tail_classes)
    assert np.array_equal(points[tail_classes].min(0), np.asarray(tail['bounds_min_m']))
    assert np.array_equal(points[tail_classes].max(0), np.asarray(tail['bounds_max_m']))
    fixed = (points[:, 1] >= 1.14) | owned | (mass <= 0)
    fixed[tail_classes] = True
    hoof = {}
    patch_vertices = {}
    for label, row in contacts['contacts'].items():
        vertices = np.unique(parts[1][2][row['source_triangle_ids']].ravel())
        classes = np.unique(vc[1][vertices])
        joint = controls['limbs'][label]['joints'][-1]
        assert np.all(np.where(parts[1][0][vertices] == joint,
                               parts[1][1][vertices], 0).sum(1) == 1)
        hoof[label] = classes
        patch_vertices[label] = vertices
        fixed[classes] = True
        baseline[classes] = 0
        baseline[classes, joint] = 1
    protected_fixed = fixed.copy()
    protected_vectors = baseline[fixed].copy()
    foot_rows, cut_rows, domains, feet, collars = [], [], {}, {}, {}
    failures = []
    all_hoof = np.zeros(n, dtype=bool)
    for seed in hoof.values():
        all_hoof[seed] = True
    for label, row in controls['limbs'].items():
        a, b, c, d, e = row['joints']
        foreign = all_hoof.copy()
        foreign[hoof[label]] = False
        foot_report, below_d, d_boundary = section(points, body_triangles, body_edges,
            body_mask, pivots[d], pivots[d] - pivots[c], hoof[label], foreign, label + ':fetlock')
        cut_rows.append(foot_report)
        # One source triangle star; not repeated dilation or radius tuning.
        star = body_triangles[below_d[body_triangles].any(1)]
        whole = below_d.copy()
        if len(star):
            whole[np.unique(star.ravel())] = True
        component_foreign = np.flatnonzero(whole & foreign)
        # Always inspect the second declared plane; invalid foot cannot become an accepted domain.
        b_seeds = np.flatnonzero(whole) if whole.any() else hoof[label]
        proximal_report, below_b, b_boundary = section(points, body_triangles, body_edges,
            body_mask, pivots[b], pivots[b] - pivots[a], b_seeds, foreign, label + ':proximal')
        cut_rows.append(proximal_report)
        new_ids = np.flatnonzero(whole)
        desired = np.zeros(26)
        desired[e] = 1
        conflicts = new_ids[protected_fixed[new_ids]
                            & (np.abs(baseline[new_ids] - desired).max(1) > 1e-9)]
        patch_min = float(rest[1][patch_vertices[label], 1].min())
        whole_min = float(points[new_ids, 1].min()) if len(new_ids) else None
        ground_compatible = (whole_min is not None
                            and whole_min - patch_min >= literals['THRESHOLDS']['minimum_all_surface_y_m'])
        good = (foot_report['proposal_section_precondition_pass']
                and proximal_report['proposal_section_precondition_pass']
                and not len(component_foreign) and not len(conflicts) and ground_compatible)
        foot_rows.append({'limb': label, 'whole_foot_classes': int(whole.sum()),
                          'original_contact_classes': int(len(hoof[label])),
                          'original_patch_min_y_m': patch_min, 'whole_foot_min_y_m': whole_min,
                          'rigid_whole_foot_stance_min_y_m': None if whole_min is None else whole_min - patch_min,
                          'unchanged_ground_tolerance_m': literals['THRESHOLDS']['minimum_all_surface_y_m'],
                          'ground_schedule_compatible': bool(ground_compatible),
                          'protected_row_conflicts': conflicts.tolist(),
                          'foreign_foot_classes_in_star': component_foreign.tolist(),
                          'proposal_foot_precondition_pass': bool(good)})
        if not good:
            failures.append({'code': 'ANATOMICAL_FOOT_OR_SECTION_PRECONDITION_FAIL', 'limb': label,
                             'scope': 'this declared support formulation only'})
            continue
        domain = below_b.copy()
        domain[b_boundary] = False
        distances = dijkstra(metric, directed=False, indices=b_boundary, min_only=True)
        collar = below_b | (distances < ELL)
        domains[label], feet[label], collars[label] = domain, whole, collar
    assert len(cut_rows) == 8
    foot_overlap = []
    labels = sorted(feet)
    for i, label in enumerate(labels):
        for other in labels[i + 1:]:
            overlap = np.flatnonzero(feet[label] & feet[other])
            if len(overlap):
                foot_overlap.append({'limbs': [label, other], 'overlap_class_ids': overlap.tolist()})
    if foot_overlap:
        failures.append({'code': 'EXTENDED_COMPLETE_FOOT_OWNERSHIP_OVERLAP', 'conflicts': foot_overlap})
    palette_report = None
    known_edges_report = None
    membership_report = None
    distance_report = []
    arrays = {'points_m': points, 'edges': all_edges, 'edge_lengths_m': lengths,
              'source_protected_class_ids': np.flatnonzero(protected_fixed)}
    for mi, classes in enumerate(vc):
        arrays['vertex_classes_' + str(mi)] = classes
    if len(domains) == 4 and not foot_overlap:
        allowed = np.zeros((n, 26), dtype=bool)
        allowed[:, 1] = True
        for label, row in controls['limbs'].items():
            a, b, c, d, e = row['joints']
            allowed[collars[label], a] = True
            allowed[domains[label], b] = True
            allowed[domains[label], e] = True
            ids = np.flatnonzero(feet[label])
            fixed[ids] = True
            baseline[ids] = 0
            baseline[ids, e] = 1
            allowed[ids] = False
            allowed[ids, e] = True
            arrays[label + '_whole_foot_classes'] = ids
            arrays[label + '_distal_domain_classes'] = np.flatnonzero(domains[label])
            arrays[label + '_proximal_collar_classes'] = np.flatnonzero(collars[label])
            zero = ~domains[label] | (fixed & (baseline[:, e] < 1e-9))
            distances = dijkstra(metric, directed=False, indices=ids, min_only=True)
            minimum = float(distances[zero].min())
            pass_distance = minimum + 1e-9 >= ELL
            distance_report.append({'limb': label, 'channel': e, 'forced1_to_forced0_geodesic_m': minimum,
                                    'chosen_regularizer_required_m': ELL,
                                    'passes_this_regularizer_precondition': bool(pass_distance)})
            if not pass_distance:
                failures.append({'code': 'FORCED_ONE_ZERO_DISTANCE_INFEASIBLE_UNDER_CHOSEN_ELL', 'limb': label,
                                 'not_a_general_skin_physics_or_weights_only_impossibility_claim': True})
        assert np.array_equal(baseline[protected_fixed], protected_vectors)
        allowed[fixed] = baseline[fixed] > 0
        # Single-channel unknown palettes force a constant by simplex; no solve occurs.
        forced = (~fixed) & (allowed.sum(1) == 1)
        baseline[forced] = allowed[forced].astype(float)
        fixed[forced] = True
        counts = allowed.sum(1)
        u, v = all_edges.T
        edge_counts = (allowed[u] | allowed[v]).sum(1)
        bad_classes = np.flatnonzero(counts > 4)
        bad_edges = np.flatnonzero(edge_counts > 4)
        scalar_variables = int(allowed[~fixed].sum())
        constraint_estimate = int(2 * edge_counts.sum() + (~fixed).sum())
        palette_report = {'class_maximum': int(counts.max()), 'class_cap': 4,
                          'bad_class_count': int(len(bad_classes)), 'bad_class_sample': bad_classes[:50].tolist(),
                          'edge_union_maximum': int(edge_counts.max()), 'bad_edge_union_count': int(len(bad_edges)),
                          'bad_edge_union_sample': all_edges[bad_edges[:50]].tolist(),
                          'edge_union_cap_is_conservative_proposal_assumption_not_GPU_requirement': True,
                          'per_vertex_gpu_maximum_remains4_edges_may_legitimately_union_more': True,
                          'nonconvex_palette_selection_not_solved_or_rank_pruned': True,
                          'fixed_palettes_required_before_any_convex_QP': True,
                          'unknown_scalar_variables': scalar_variables,
                          'estimated_linear_constraint_rows': constraint_estimate}
        if len(bad_classes) or len(bad_edges):
            failures.append({'code': 'CONSERVATIVE_FIXED_PALETTE_PRECONDITION_FAIL',
                             'not_a_GPU_edge_or_anatomical_impossibility_claim': True})
        if scalar_variables > 20000 or constraint_estimate > 160000:
            failures.append({'code': 'PROPOSED_LATER_SOLVER_SIZE_CAP_EXCEEDED'})
        q = quotient(baseline)
        kk = fixed[u] & fixed[v]
        jumps = np.abs(q[u[kk]] - q[v[kk]]).max(1)
        limits = lengths[kk] / ELL
        bad = np.flatnonzero(jumps > limits + 1e-9)
        fixed_edges = all_edges[kk]
        known_edges_report = {'known_known_edges': int(kk.sum()),
                              'violating_known_edges': int(len(bad)),
                              'maximum_weight_jump_minus_bound': float((jumps - limits).max()) if len(jumps) else None,
                              'violating_edge_samples': fixed_edges[bad[:50]].tolist(),
                              'ell_is_chosen_sufficient_regularizer_not_original_pose_acceptance': True}
        if len(bad):
            failures.append({'code': 'FIXED_ROWS_CONFLICT_WITH_CHOSEN_GRADIENT_REGULARIZER',
                             'not_a_general_skin_or_bone_infeasibility_claim': True})
        v8 = json.loads(Path(pins['v8_readback']['path']).read_text())
        v9 = json.loads(Path(pins['v9_readback']['path']).read_text())
        witness_rows = []
        for name in ('area_max', 'area_min'):
            witness = v8['witnesses'][name]
            for vertex in witness['vertices']:
                ci = int(vc[1][vertex['id']])
                excluded = not allowed[ci, 12] and not allowed[ci, 15]
                witness_rows.append({'source': 'V8', 'witness': name, 'triangle': witness['triangle'],
                                     'vertex': vertex['id'], 'class': ci,
                                     'distal_right_fore_elbow_hoof_excluded_by_actual_domain': bool(excluded)})
                if not excluded:
                    failures.append({'code': 'ORIGINAL_CHEST_WITNESS_NOT_ANATOMICALLY_SEPARATED', 'vertex': vertex['id']})
        for label, ids in [('fore_l', (3666, 3708, 3706)), ('hind_l', (3518, 3524, 3520))]:
            for vertex in ids:
                ci = int(vc[1][vertex])
                included = bool(feet[label][ci])
                witness_rows.append({'source': 'V9', 'limb': label, 'vertex': vertex, 'class': ci,
                                     'complete_foot_star_includes_old_boundary_vertex': included})
                if not included:
                    failures.append({'code': 'OLD_HOOF_BOUNDARY_WITNESS_OUTSIDE_COMPLETE_FOOT', 'vertex': vertex})
        membership_report = witness_rows
        arrays['fixed_palette_allowed'] = allowed
        arrays['fixed_rows'] = fixed
        # These are original/Dirichlet declarations ONLY, not a generated skin field.
        arrays['declared_known_vectors'] = baseline[fixed]
        arrays['declared_known_class_ids'] = np.flatnonzero(fixed)
    else:
        failures.append({'code': 'DEPENDENT_PALETTE_GRADIENT_PHASE_SKIPPED_INVALID_ANATOMICAL_DOMAIN',
                         'valid_domains': sorted(domains)})
    # Meaningful actual failed-boundary controls, evaluated by the same metric.
    v9 = json.loads(Path(pins['v9_readback']['path']).read_text())
    controls_rows = []
    for witness_name, aa, bb in [('edge_max', 3666, 3708), ('normal_min', 3518, 3520)]:
        vertices = {v['id']: v for v in v9['witnesses'][witness_name]['vertices']}
        av, bv = vertices[aa], vertices[bb]
        aw, bw = np.zeros(26), np.zeros(26)
        for row in av['weights']:
            aw[row['joint']] = row['weight']
        for row in bv['weights']:
            bw[row['joint']] = row['weight']
        length = float(np.linalg.norm(np.asarray(av['rest_m']) - np.asarray(bv['rest_m'])))
        checked = gradient_violation(aw, bw, length)
        assert checked['fails_proposal_regularizer']
        controls_rows.append({'negative_control': 'actual_V9_' + witness_name, 'vertices': [aa, bb],
                              'rest_edge_length_m': length, **checked,
                              'scope': 'Chosen regularizer detects actual rejected V9 boundary; not pose acceptance.'})
    # A union-of-five edge can have entirely valid three-weight endpoints.
    ca, cb = np.zeros(26, dtype=bool), np.zeros(26, dtype=bool)
    ca[[1, 6, 7]], cb[[1, 11, 12]] = True, True
    assert ca.sum() == 3 and cb.sum() == 3 and (ca | cb).sum() == 5
    controls_rows.append({'negative_control': 'valid_GPU_endpoints_union5',
                          'endpoint_counts': [3, 3], 'edge_union': 5,
                          'fails_OUR_conservative_edge_union_assumption': True,
                          'fails_GPU_per_vertex4_requirement': False,
                          'not_an_impossibility_certificate': True})
    fore = np.zeros(n, dtype=bool)
    fore[hoof['fore_l']] = True
    foreign = np.zeros(n, dtype=bool)
    foreign[hoof['fore_r']] = True
    missing = fore.copy()
    missing[hoof['fore_l'][0]] = False
    corrupt = fore | foreign
    assert not seed_membership(missing, hoof['fore_l'], foreign)['all_own_seeds_included']
    assert seed_membership(corrupt, hoof['fore_l'], foreign)['foreign_hoof_seed_classes']
    controls_rows.append({'negative_control': 'actual_hoof_seed_missing_or_foreign_component',
                          'missing_own_seed_detected': True, 'foreign_hoof_component_detected': True})
    status = 'PROPOSAL_SOURCE_PREFLIGHT_FAIL_NO_SOLVE' if failures else 'PROPOSAL_SOURCE_PREFLIGHT_PASS_NO_SOLVE'
    result = {'status': status, 'original_V8_V9_deformation_failures_still_fail': True,
              'source_pins': pins, 'vertices': 11556, 'triangles': 14986, 'welded_classes': n,
              'edges': int(len(all_edges)), 'maximum_class_spread_m': float(spread),
              'declared_ell_m': ELL, 'cuts': cut_rows, 'feet': foot_rows,
              'forced_boundary_distance_checks': distance_report, 'palette_precondition': palette_report,
              'known_gradient_precondition': known_edges_report, 'actual_witness_memberships': membership_report,
              'negative_controls': controls_rows, 'failures': failures,
              'original_parameters': literals['PARAMETERS'], 'original_thresholds': literals['THRESHOLDS'],
              'original_parameters_thresholds_unchanged': True, 'optimizations': 0,
              'new_weight_fields': 0, 'pose_generations': 0, 'pose_checks': 0,
              'geometry_mutations': 0, 'exports': 0, 'app_ticket_ref_writes': 0,
              'scope': 'Feasibility of this fixed conservative V10 formulation only. Palette edge union and ell bound are not GPU edge limits or original skin physics. Failure is not general weights-only/bone impossibility.',
              'next_phase_released': False, 'elapsed_seconds': time.monotonic() - start}
    np.savez_compressed(out / 'SOURCE-FEASIBILITY-READBACK.npz', **arrays)
    (out / 'PHASE-A-REPORT.json').write_text(json.dumps(result, indent=2) + '\n')
    assert sum(p.stat().st_size for p in out.iterdir() if p.is_file()) < 16777216
    print(json.dumps(result), flush=True)
    return 2 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
