"""Owned one-shot phaseA supervisor: 15s wall/512MiB RSS, no automatic next step."""
from pathlib import Path
import datetime, hashlib, json, os, resource, signal, subprocess, sys, time

HERE = Path(__file__).resolve().parent
PYTHON = '/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    release_path = Path(sys.argv[1]).resolve()
    release = json.loads(release_path.read_text())
    assert release['released'] is True
    assert release['authorization'] == 'ONE_ROOT_RELEASED_V10_PHASE_A_PREFLIGHT'
    for key, filename in [('supervisor_sha256', 'run_once_HELD.py'),
                          ('runner_sha256', 'phase_a_HELD.py'),
                          ('decoder_sha256', 'actual_model.py'),
                          ('pins_sha256', 'INPUT-PINS.json'),
                          ('clarifications_sha256', 'FORMULATION-CLARIFICATIONS.json')]:
        assert release[key] == sha(HERE / filename), key + ' drift'
    assert release['maximum_runs'] == 1 and release['maximum_wall_seconds'] == 15
    assert release['maximum_rss_bytes'] == 512 * 1024 * 1024
    assert release['optimizations_authorized'] is False
    assert not (HERE / 'ACTUAL').exists(), 'One-shot output exists; no rerun authorized'
    out = HERE / 'ACTUAL'
    out.mkdir()
    (out / 'ROOT-RELEASE.json').write_text(json.dumps(release, indent=2) + '\n')
    intent = {'started_utc': utc(), 'one_shot': True, 'released_phase': 'SOURCE_A_ONLY',
              'wall_limit_seconds': 15, 'rss_limit_bytes': 512 * 1024 * 1024,
              'math_threads': 1, 'nice': 19, 'automatic_next_phase': False}
    (out / 'INTENT.json').write_text(json.dumps(intent, indent=2) + '\n')
    env = os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
               NUMEXPR_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    start = time.monotonic()
    peak = 0
    stopped = None
    with (out / 'stdout.log').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
        process = subprocess.Popen(['nice', '-n', '19', PYTHON, str(HERE / 'phase_a_HELD.py'),
                                    str(release_path), str(out)], cwd=HERE, env=env,
                                   stdout=stdout, stderr=stderr, start_new_session=True)
        while process.poll() is None:
            try:
                status = Path('/proc') / str(process.pid) / 'status'
                for line in status.read_text().splitlines():
                    if line.startswith('VmRSS:'):
                        peak = max(peak, int(line.split()[1]) * 1024)
            except FileNotFoundError:
                pass
            if time.monotonic() - start > 15:
                stopped = 'WALL_LIMIT_15_SECONDS'
            elif peak > 512 * 1024 * 1024:
                stopped = 'RSS_LIMIT_512_MiB'
            if stopped:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                break
            time.sleep(.025)
        code = process.wait()
    # Only this child is launched by the fresh supervisor. Capture kernel maxRSS
    # as well as live sampling; a post-terminal memory violation still FAILS.
    peak = max(peak, int(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss) * 1024)
    if peak > 512 * 1024 * 1024:
        stopped = stopped or 'KERNEL_PEAK_RSS_EXCEEDED_512_MiB'
    elapsed = time.monotonic() - start
    if elapsed > 15:
        stopped = stopped or 'ELAPSED_LIMIT_EXCEEDED_15_SECONDS'
    report_path = out / 'PHASE-A-REPORT.json'
    report = json.loads(report_path.read_text()) if report_path.exists() else None
    status = ('RESOURCE_LIMIT_FAIL_NO_RETRY' if stopped else
              report['status'] if report is not None and code in (0, 2) else
              'SOURCE_RUNNER_ERROR_NO_RETRY')
    terminal = {'status': status, 'finished_utc': utc(), 'exit_code': code,
                'elapsed_seconds': elapsed, 'actual_peak_rss_bytes': peak,
                'resource_failure': stopped, 'runs': 1, 'reruns': 0,
                'runner_sha256': release['runner_sha256'],
                'supervisor_sha256': release['supervisor_sha256'],
                'report_present': report is not None, 'no_owned_child_active': True,
                'optimization_pose_export_app_or_next_phase_executions': 0,
                'phase_B_released': False}
    (out / 'TERMINAL.json').write_text(json.dumps(terminal, indent=2) + '\n')
    print(json.dumps(terminal), flush=True)
    return 0 if status == 'PROPOSAL_SOURCE_PREFLIGHT_PASS_NO_SOLVE' and code == 0 else 2


if __name__ == '__main__':
    raise SystemExit(main())
