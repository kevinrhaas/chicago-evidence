# T2795: exact-b479 component review proposal

This packet adds source for a private, isolated 1904 technical component review. It does not install anything in the app or activate tack on a production horse. Keep the current 1835 standing horse untacked, with its existing planted posture animation and actual ground support.

The two existing traces are useful geometry, but displaying them as a worn harness would be misleading. Their front ends have no breastcollar or takeoff hardware, their routes have no suspension, and their unhitched tails have no physical keeper or coil. They do not connect to a swingletree. Bare traces therefore remain separate technical components until the missing subassembly is fitted and checked.

## Concrete source delivered

- `proposed/chicago/4d/renderers/web/transport/hitch/rest-tack-preview.mjs` exports `createRestTackPreview`. It verifies the exact host and trace bytes before parsing those same buffers, owns only private loaded objects, defaults to bare, and permits an exploded component display. It creates no animation mixer, public scene hook, ground solve, or actor-cache lease. Disposal releases its private geometry, materials, skeletons, textures and image bitmaps.
- `proposed/chicago/4d/data/transport/studies/b479-1904-rest-tack-preview.json` pins the actual b479 horse and actual d375 traces, preserves their credit/license distinctions, selects 1904 only, and leaves placement and ground support null. It deliberately supplies no b479 clearance receipt.
- `NEXT-BREASTCOLLAR-SUSPENSION-CANDIDATE.json` defines the next physical subassembly: breastcollar, neck suspension, takeoff hardware and physical retention for both unhitched traces. It gives finite surface slabs, a valid body carrier, clearances and six physical connections. These are reconstructed engineering candidates, not measurements from a period harness or accepted anatomical sockets. The candidate has not been numerically fitted or generated.

## How an authorized owner could trial it

No existing app file is modified by the patch. Installing or importing these files requires the owner's normal source review and license registration. There is no automatic entry point. An isolated transport lab caller can import the factory, load the proposed JSON, and pass `T`, its GLTF loader, and `baseUrl` set to the absolute URL of `renderers/web/transport/hitch/`. The factory expects the separately staged b479 horse in `../standing-horse/` and the actual trace GLB in the hitch directory. Those assets are not copied in this packet.

The returned `group` belongs in an isolated lab stage. `setMode('exploded_components')` separates the traces by 1.25 m and is explicitly a component inspection, with no worn-harness or historical placement claim. `setMode('bare')` hides the traces. `dispose()` releases this private instance.

`setMode('traces_rest_overlay')` refuses to display an overlay unless an owner-reviewed, byte-pinned **new exact-b479** serialized clearance result is supplied. It checks both host and trace identities and the 8 mm guarded rest clearance. A failed request first returns the display to bare. Even a successful overlay is a technical rest study, not approval of the missing collar, suspension, period appearance, planted movement or production use. The configuration intentionally leaves that future receipt null.

## Evidence and historical limits

The existing independent serialized trace result passed on the earlier 03a1 rest host: 19.28685177368743 mm minimum, 8 mm required, 9,710,928 triangle pairs covered. The exact b479 export receipt states that geometry, normals, UVs, indices, materials, images and inverse binds are preserved, but this packet does not relabel the old result as a new b479 proof. The accepted b479 skin field and planted clip changed. Neither the old rest check nor this source packet checks gear through the planted poses.

The original horse model and its derivative geometry rights are modern CC BY 4.0; they do not attest a historical Chicago horse, breed, owner, coat or presence. John Moore's 1891 catalog, printed page 1, attests the No. 1 breastcollar family and one-inch straight stitched traces as a pre-1904 American market offering. It does not establish an 1835 application, Chicago ownership, the proposed dimensions beyond trace width, exact hardware, color or this complete assembly. The viewed Hasluck 1904 illustrations remain separate comparators; they are not silently identified as Moore No. 1 hardware. No source-image pixels are embedded by the new module.

Before a public worn preview, fit and serialize the actual breastcollar/support/retention geometry; check its combined surface and physical connections against exact b479 at rest and through the relevant planted-standing poses and interpolation scope; then choose a dated 1904 stand with actual ground support. Do not borrow the existing 1835 yard position or support quaternion. Full working harness, bridle, reins, driving hands, hitch force, moving-team gait and photographic materials remain outside this increment.

## Validation and preservation

Only source syntax, JSON readability, source diff creation and file hashing were run while preparing this packet. No fitting, generation, export, browser, numerical clearance checker, app gate, network query, ticket edit or Git mutation was run. The prior serialization failure and subsequent corrected successful result remain in the existing recovery archive; neither is overwritten here.

Existing complete trace recovery archive: `/workspace/shared/T2795-TRACE-REST-RECOVERY-20261023.zip`, SHA-256 `ee828091a74f37495ea8daf883719103f208f3f69f26b6421668e2c9546def2c`.
