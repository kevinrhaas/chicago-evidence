// SPDX-License-Identifier: GPL-3.0-or-later
// Isolated technical component view ONLY. No public scene hook or auto-start.
// Bare traces are never represented as a complete wearable harness.
const need = (ok, why) => { if (!ok) throw Error(why); };

function releasePrivateGltf(gltf) {
  const geometries = new Set(), materials = new Set(), textures = new Set(), skeletons = new Set();
  const images = new Set();
  gltf?.scene?.traverse(node => {
    if (node.geometry) geometries.add(node.geometry);
    if (node.skeleton) skeletons.add(node.skeleton);
    for (const material of (Array.isArray(node.material) ? node.material : [node.material])) {
      if (!material) continue; materials.add(material);
      for (const value of Object.values(material)) if (value?.isTexture) {
        textures.add(value);
        for (const image of (Array.isArray(value.image) ? value.image : [value.image])) {
          if (image && typeof image.close === 'function') images.add(image);
        }
      }
    }
  });
  gltf?.scene?.removeFromParent();
  for (const value of skeletons) value.dispose();
  for (const value of geometries) value.dispose();
  for (const value of materials) value.dispose();
  for (const value of textures) value.dispose();
  for (const value of images) value.close();
}

/** Caller owns an ISOLATED lab stage and its loader; no production actor/cache
 * is leased, cloned, relocated or duplicated. Both parsed buffers are private.
 * No floor/support solve or Mixer is created. Canonical rest is shown as rest.
 */
export async function createRestTackPreview({ T, loader, config, baseUrl,
  fetchBuffer = async url => {
    const response = await fetch(url); need(response.ok, 'Preview asset unavailable');
    return response.arrayBuffer();
  } }) {
  need(config?.scope === 'isolated_component_review_only' && config.scene_id === '1904'
    && config.production_activation_allowed === false && config.placement === null,
  'Explicit unplaced 1904 technical review required');
  need(config.horse.canonical_scale === 1 && config.horse.canonical_origin_m.every(v => v === 0)
    && config.horse.clip_in_this_review === null && config.horse.automatic_support_tilt === null,
  'Canonical rest only; no borrowed 1835 support or planted-clip composition');
  need(config.traces.recipe_eligibility.join() === '1904' && config.traces.complete_harness === false,
    'Do not backdate the 1891 recipe or call loose traces a harness');
  const assets = [];
  let disposed = false;
  async function verifiedBytes(spec) {
    need(/^[0-9a-f]{64}$/.test(spec.sha256), 'Actual byte pin required');
    const url = new URL(spec.file, baseUrl), bytes = await fetchBuffer(url);
    need(bytes instanceof ArrayBuffer && bytes.byteLength === spec.bytes, 'Wrong actual preview bytes');
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    const sha = Array.from(new Uint8Array(digest), x => x.toString(16).padStart(2, '0')).join('');
    need(sha === spec.sha256, 'Preview asset hash mismatch');
    return { bytes, url };
  }
  async function load(spec) {
    const { bytes, url } = await verifiedBytes(spec);
    const gltf = await loader.parseAsync(bytes, new URL('.', url).href);
    assets.push(gltf); return gltf; // Parse THE SAME verified ArrayBuffer.
  }
  const group = new T.Group(); group.name = config.id;
  const traceFrame = new T.Group(); traceFrame.name = 'unhitched-trace-component-review';
  try {
    const horse = await load(config.horse), trace = await load(config.traces);
    let reviewedActualB479Receipt = null;
    if (config.traces.b479_rest_receipt) {
      const { bytes } = await verifiedBytes(config.traces.b479_rest_receipt);
      reviewedActualB479Receipt = JSON.parse(new TextDecoder().decode(bytes));
    }
    need(horse.parser.json.skins?.[0]?.joints.length === 26, 'Wrong horse rig derivative');
    const actualTraceNames = [];
    trace.scene.traverse(node => { if (node.isMesh) actualTraceNames.push(node.name); });
    need(actualTraceNames.sort().join() === [...config.traces.names].sort().join(), 'Wrong trace inventory');
    group.add(horse.scene, traceFrame); traceFrame.add(trace.scene);
    const status = {
      scope: '1904 isolated rest component review', mode: 'bare',
      horse_sha256: config.horse.sha256, trace_sha256: config.traces.sha256,
      complete_harness: false, horse_ground_support_qualified: false,
      historical_appearance_accepted: false, planted_gear_clearance_accepted: false,
      production_activation_allowed: false,
    };
    function setMode(mode) {
      need(!disposed, 'Disposed component preview');
      need(['bare', 'exploded_components', 'traces_rest_overlay'].includes(mode), 'Unknown technical mode');
      // Failure returns to bare, never leaves an uncertified fitted-looking overlay.
      traceFrame.visible = false; status.mode = 'bare';
      if (mode === 'exploded_components') {
        traceFrame.position.fromArray(config.display.exploded_offset_m);
        traceFrame.visible = true; status.mode = mode;
      } else if (mode === 'traces_rest_overlay') {
        // A 03a1 rest proof is not silently relabelled b479. The caller must supply
        // an actual exact-b479 serialized clearance receipt and its authenticated
        // root review; this API does not fabricate or fetch that future receipt.
        const result = reviewedActualB479Receipt;
        need(result?.pass === true
          && result.input_pins?.horse_host?.sha256 === config.horse.sha256
          && result.input_pins?.trace_glb?.sha256 === config.traces.sha256
          && result.skin_gait_accepted === false && result.production_activation_allowed === false
          && result.complete_rest_surface_distance?.passed === true
          && result.complete_rest_surface_distance.minimum_m
            - result.complete_rest_surface_distance.numeric_guard_m >= config.traces.qualified_rest_gap_m,
        'New exact-b479 rest receipt required; the old 19.286 mm 03a1 proof is separate');
        traceFrame.position.set(0, 0, 0); traceFrame.visible = true; status.mode = mode;
      }
      return { ...status };
    }
    setMode(config.display.default_mode);
    return { group, status, setMode,
      // No attach-as-working-harness API: collar/suspension/retention are absent.
      dispose() {
        if (disposed) return; disposed = true; group.removeFromParent();
        for (const asset of assets.splice(0)) releasePrivateGltf(asset);
      } };
  } catch (error) {
    group.removeFromParent(); for (const asset of assets.splice(0)) releasePrivateGltf(asset);
    throw error;
  }
}
