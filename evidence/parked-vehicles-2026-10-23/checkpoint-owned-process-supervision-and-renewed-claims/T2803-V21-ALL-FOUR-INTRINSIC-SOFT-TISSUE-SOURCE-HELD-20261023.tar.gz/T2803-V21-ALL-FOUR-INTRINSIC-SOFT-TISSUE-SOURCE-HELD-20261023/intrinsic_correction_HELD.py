"""HELD all-four intrinsic shape diagnostic, NOT a glTF skin/morph exporter.

One fixed20-step positive-weight local/global ARAP process per sample. Every
original source-protected/tail/hoof class is exact Dirichlet, including normals.
Nonconvergence is not proof of infeasibility. Only necessary hard-boundary
violations can produce an infeasibility certificate; unchanged65 guards judge
any finite returned embedding separately from ARAP optimality/convergence.
"""
from pathlib import Path
import hashlib,json
from fractions import Fraction
import numpy as np
from scipy.sparse import coo_matrix,diags
from scipy.sparse.csgraph import connected_components
from scipy.sparse.linalg import splu

HERE=Path(__file__).resolve().parent
STEPS=20
CAPS={'classes':12000,'edges':80000,'free_classes':6000,'unique_poses':67,'factor_nnz':4000000}

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

class Intrinsic:
    def __init__(self,rest,parts,limbs,patch,neutral_matrices,neutral_normals,limits):
        pins=json.loads((HERE/'INPUT-PINS.json').read_text())
        for row in pins.values():assert sha(row['path'])==row['sha256']
        with np.load(pins['phase_a_arrays']['path'],allow_pickle=False) as f:
            p=f['points_m'].copy();vc=[f['vertex_classes_'+str(i)].copy() for i in range(3)]
            protected=f['source_protected_class_ids'].copy()
        n=len(p);assert n<=CAPS['classes'] and p.shape==(n,3)
        assert all(np.array_equal(p[vc[i]],r) for i,r in enumerate(rest))
        body=np.zeros(n,dtype=bool);body[vc[1]]=True
        v14=json.loads(Path(pins['v14_field_receipt']['path']).read_text())
        v16=json.loads(Path(pins['v16_field_receipt']['path']).read_text())
        domain=np.zeros(n,dtype=bool);ledger=[]
        upper={r['limb']:r for r in v16['attachment_regions']}
        assert {r['limb'] for r in v14['full_domain_reconstruction']}==set(limbs)==set(upper)
        for r in v14['full_domain_reconstruction']:
            label=r['limb'];ids=np.unique(np.r_[r['full_b_classes'],upper[label]['active_classes']]).astype(int)
            domain[ids]=True;ledger.append({'limb':label,'anatomical_domain_classes':len(ids)})
        hard=np.zeros(n,dtype=bool);hard[protected]=True
        tail=json.loads((HERE/'PROVED-TAIL-COMPONENT.json').read_text())
        tail_ids=np.asarray(tail['exact_source_vertex_ids'],dtype=int);assert len(tail_ids)==969
        hard[vc[0][tail_ids]]=True
        for label,ids in patch.items():hard[vc[1][ids]]=True
        pure_hoof_counts={}
        for label,row in limbs.items():
            e=row['joints'][-1];owned=[]
            for mi,part in enumerate(parts):
                j,w=part[2:4];pure=((w==0)|(j==e)).all(axis=1)&(w>0).any(axis=1)
                owned.extend(vc[mi][pure].tolist())
            owned=np.unique(np.asarray(owned,dtype=int));hard[owned]=True
            pure_hoof_counts[label]=len(owned)
        free=domain&body&~hard;fixed=~free;fi=np.flatnonzero(free);ci=np.flatnonzero(fixed)
        assert 0<len(fi)<=CAPS['free_classes'],'Proposal domain/cost refusal, not physical infeasibility'
        for row in ledger:
            label=row['limb'];original=next(r for r in v14['full_domain_reconstruction'] if r['limb']==label)
            assert free[np.asarray(original['full_b_classes'],int)].any(),'No free skin on one limb'
        self.mesh_edges=[]
        for mi,part in enumerate(parts):
            tri=part[4];ee=np.unique(np.concatenate([np.sort(tri[:,[a,b]],axis=1) for a,b in ((0,1),(1,2),(2,0))]),axis=0)
            ll=np.linalg.norm(rest[mi][ee[:,0]]-rest[mi][ee[:,1]],axis=1);ok=ll>1e-8
            self.mesh_edges.append((ee[ok],ll[ok]))
        triangles=np.concatenate([vc[i][part[4]] for i,part in enumerate(parts)])
        edges=np.unique(np.concatenate([np.sort(triangles[:,[a,b]],axis=1) for a,b in ((0,1),(1,2),(2,0))]),axis=0)
        edges=edges[edges[:,0]!=edges[:,1]];vectors=p[edges[:,0]]-p[edges[:,1]]
        lengths=np.linalg.norm(vectors,axis=1);keep=(lengths>1e-8)&(free[edges[:,0]]|free[edges[:,1]]) # original metric mask; soft-tissue incident edges only
        edges,vectors,lengths=edges[keep],vectors[keep],lengths[keep]
        assert len(edges)<=CAPS['edges'];weights=1/(lengths*lengths)
        i,j=edges.T
        adjacency=coo_matrix((np.ones(2*len(edges)),(np.r_[i,j],np.r_[j,i])),shape=(n,n)).tocsr()
        _,components=connected_components(adjacency,directed=False)
        assert np.isin(components[fi],np.unique(components[ci])).all(),'Unanchored proposal island; no damping/fallback'
        degree=np.bincount(np.r_[i,j],weights=np.r_[weights,weights],minlength=n)
        lap=(diags(degree)-coo_matrix((np.r_[weights,weights],(np.r_[i,j],np.r_[j,i])),shape=(n,n)).tocsr()).tocsr()
        self.lff=lap[fi][:,fi].tocsc();self.lfc=lap[fi][:,ci].tocsr()
        self.factor=splu(self.lff,permc_spec='MMD_AT_PLUS_A',diag_pivot_thresh=0.)
        assert self.factor.L.nnz+self.factor.U.nnz<=CAPS['factor_nnz'],'Factor cost refusal'
        self.p,self.vc,self.edges,self.vectors,self.lengths,self.weights=p,vc,edges,vectors,lengths,weights
        self.free,self.fixed,self.hard,self.fi,self.ci=free,fixed,hard,fi,ci
        self.active_rotation_ids=np.unique(edges)
        self.neutral=neutral_matrices.copy();self.neutral_normals=[a.copy() for a in neutral_normals]
        self.limits=limits;self.cache={};self.samples=[];self.saved=[];self.rejections=[]
        self.ledger=ledger;self.tail_ids=tail_ids;self.patch=patch;self.rest=rest
        self.receipt={'classification':'INTRINSIC_FIXED_BOUNDARY_SHAPE_DIAGNOSTIC_NOT_PRODUCTION_SKIN',
          'classes':n,'free_classes':len(fi),'hard_source_tail_hoof_classes':int(hard.sum()),
          'entire_existing_pure_hoof_owned_classes_by_limb':pure_hoof_counts,
          'edges':len(edges),'domain_source':'V14 full b-distal topology components plus V16 two-sided upper attachment classes, minus exact original-source/tail/hoof anchors',
          'limbs':ledger,'weights':'positive inverse-squared original rest-edge length; no strain-witness weights',
          'steps_per_unique_pose':STEPS,'factor_nnz':self.factor.L.nnz+self.factor.U.nnz,
          'rest_geometry_UV_maps_weights_pivots_inversebinds_changed':False,
          'source_known_tail_hoof_corrections_exact_zero':True,
          'field_builds':0,'QP_or_LP_solves':0,'new_GLTF_or_morph_or_animation_exports':0}

    def rotations(self,q):
        i,j=self.edges.T;outer=np.einsum('ni,nj->nij',q[i]-q[j],self.vectors)*self.weights[:,None,None]
        covariance=np.zeros((len(self.p),3,3));np.add.at(covariance,i,outer);np.add.at(covariance,j,outer)
        active=self.active_rotation_ids
        u,s,vh=np.linalg.svd(covariance[active],full_matrices=False)
        signs=np.ones((len(u),3));signs[:,2]=np.where(np.linalg.det(u@vh)<0,-1.,1.)
        r=np.repeat(np.eye(3)[None],len(self.p),axis=0);r[active]=(u*signs[:,None,:])@vh
        assert np.isfinite(r).all() and np.abs(np.linalg.det(r)-1).max()<1e-10
        return r

    def energy(self,q,r):
        i,j=self.edges.T;delta=q[i]-q[j]
        a=delta-np.einsum('nij,nj->ni',r[i],self.vectors)
        b=delta-np.einsum('nij,nj->ni',r[j],self.vectors)
        return float(.5*np.sum(self.weights*(np.sum(a*a,axis=1)+np.sum(b*b,axis=1))))

    def fixed_certificates(self,raw_points):
        # Test actual per-mesh vertex endpoints, not averaged welded classes.
        # Every returned certificate is an unchanged physical edge that this
        # domain cannot move; required-hard endpoints prove the stronger claim.
        cert=[];exact_checks=0
        for mi,(edges,lengths) in enumerate(self.mesh_edges):
            a,b=edges.T;ca,cb=self.vc[mi][a],self.vc[mi][b]
            ratio=np.linalg.norm(raw_points[mi][a]-raw_points[mi][b],axis=1)/lengths
            bad=self.fixed[ca]&self.fixed[cb]&((ratio<self.limits['minimum_triangle_edge_ratio'])|(ratio>self.limits['maximum_triangle_edge_ratio']))
            for k in np.flatnonzero(bad):
                if len(cert)>=16:break
                if exact_checks>=64:return cert # finite certificate budget, no impossibility claim on skipped edges
                exact_checks+=1
                aa,bb=int(ca[k]),int(cb[k]);hard=bool(self.hard[aa] and self.hard[bb])
                def norm2(points):
                    return sum((Fraction.from_float(float(points[a[k],axis]))-Fraction.from_float(float(points[b[k],axis])))**2 for axis in range(3))
                squared_rest=norm2(self.rest[mi]);squared_posed=norm2(raw_points[mi])
                lo=Fraction(str(self.limits['minimum_triangle_edge_ratio']));hi=Fraction(str(self.limits['maximum_triangle_edge_ratio']))
                if not (squared_posed<lo*lo*squared_rest or squared_posed>hi*hi*squared_rest):continue
                cert.append({'kind':'FIXED_REST_EDGE_NECESSARY_BOUND_VIOLATION',
                  'mesh':mi,'vertex_ids':[int(a[k]),int(b[k])],'class_ids':[aa,bb],
                  'edge_ratio':float(ratio[k]),'rest_length_m':float(lengths[k]),
                  'both_required_source_tail_hoof_anchors':hard,
                  'scope':'INFEASIBLE_UNDER_REQUIRED_FIXED_ANCHORS' if hard else 'INFEASIBLE_IN_THIS_RESTRICTED_FREE_DOMAIN_ONLY',
                  'exact_rational_squared_distance_inequality_verified':True,
                  'exactness_scope':'Decoded rest and fixed posed float64 coordinates treated as exact dyadic values; decimal physical limits unchanged',
                  'not_a_general_rig_or_motion_impossibility':True})
        return cert

    def validate_fixed(self,candidate,baseline):
        return np.array_equal(candidate[self.fixed],baseline[self.fixed])

    def apply(self,matrices,raw_points,raw_normals):
        if np.array_equal(matrices,self.neutral):return raw_points,raw_normals
        key=hashlib.sha256(matrices.tobytes()).hexdigest()
        if key in self.cache:
            q,r=self.cache[key];return self.scatter(q,r,raw_points,raw_normals)
        assert len(self.cache)<CAPS['unique_poses'],'Pose cost cap refused, no extra samples'
        baseline=np.zeros_like(self.p);seen=np.zeros(len(self.p),dtype=bool)
        for classes,points in zip(self.vc,raw_points):
            already=seen[classes]
            if already.any():assert np.max(np.abs(baseline[classes[already]]-points[already]))<=self.limits['minimum_seam_gap_tolerance_m']
            baseline[classes]=points;seen[classes]=True
        assert seen.all() and np.isfinite(baseline).all()
        certificates=self.fixed_certificates(raw_points)
        self.rejections.extend(certificates)
        q=baseline.copy();initial_r=self.rotations(q);initial_energy=self.energy(q,initial_r)
        final_step=linear_residual=energy_drop=0.;iterations=0
        if not certificates:
            for iteration in range(STEPS):
                r=self.rotations(q);old=self.energy(q,r)
                i,j=self.edges.T
                goals=.5*np.einsum('nij,nj->ni',r[i]+r[j],self.vectors)*self.weights[:,None]
                rhs=np.zeros_like(q);np.add.at(rhs,i,goals);np.add.at(rhs,j,-goals)
                b=rhs[self.fi]-self.lfc@baseline[self.ci]
                nextq=baseline.copy();nextq[self.fi]=self.factor.solve(b)
                assert np.isfinite(nextq).all() and self.validate_fixed(nextq,baseline)
                linear_residual=float(np.abs(self.lff@nextq[self.fi]-b).max()/max(1.,float(np.abs(b).max())))
                assert linear_residual<=1e-9,'Numerical linear solve refusal; not physical infeasibility'
                new=self.energy(nextq,r)
                assert new<=old+1e-10*max(1.,old),'Numerical monotonicity refusal; no line search/retry'
                final_step=float(np.linalg.norm(nextq-q,axis=1).max());energy_drop=old-new
                q=nextq;iterations+=1
        r=self.rotations(q);final_energy=self.energy(q,r)
        assert self.validate_fixed(q,baseline)
        # Meaningful synthetic corruption, never used as candidate output.
        bad=q.copy();bad[int(np.flatnonzero(self.hard)[0]),0]+=.003
        assert not self.validate_fixed(bad,baseline),'Fixed-anchor corruption control not rejected'
        moved=[p.copy() for p in raw_points]
        for mi,classes in enumerate(self.vc):
            active=self.free[classes];moved[mi][active]=q[classes[active]]
            assert np.array_equal(moved[mi][~active],raw_points[mi][~active])
        correction=max(float(np.linalg.norm(a-b,axis=1).max()) for a,b in zip(moved,raw_points))
        self.samples.append({'pose_sha256':key,'fixed_steps':iterations,'initial_ARAP_energy':initial_energy,
          'final_ARAP_energy':final_energy,'last_step_max_m':final_step,'last_fixed_rotation_energy_drop':energy_drop,
          'relative_linear_residual':linear_residual,'maximum_correction_m':correction,
          'converged_observed_only':final_step<=1e-9 and abs(energy_drop)<=1e-10*max(1.,initial_energy),
          'fixed_edge_certificates':certificates,'original_required_anchors_exact':True,
          'algorithm_nonconvergence_does_not_prove_infeasibility':True})
        self.cache[key]=(q.copy(),r.copy());self.saved.append((matrices.copy(),q[self.fi].copy()))
        return self.scatter(q,r,raw_points,raw_normals)

    def scatter(self,q,r,raw_points,raw_normals):
        moved=[p.copy() for p in raw_points];normals=[n.copy() for n in raw_normals]
        for mi,classes in enumerate(self.vc):
            active=self.free[classes]
            moved[mi][active]=q[classes[active]]
            normals[mi][active]=np.einsum('nij,nj->ni',r[classes[active]],self.neutral_normals[mi][active])
            normals[mi][active]/=np.linalg.norm(normals[mi][active],axis=1)[:,None]
            assert np.array_equal(moved[mi][~active],raw_points[mi][~active])
            assert np.array_equal(normals[mi][~active],raw_normals[mi][~active])
        # A welded free class gets the same correction; every fixed original
        # vertex keeps its own raw LBS bits rather than being averaged/welded.
        return moved,normals

    def finish(self,first,last,raw_skin):
        p0,n0=self.apply(first,*raw_skin(first));p1,n1=self.apply(last,*raw_skin(last))
        loop=max(float(np.abs(a-b).max()) for a,b in zip(p0,p1))
        normal_loop=max(float(np.abs(a-b).max()) for a,b in zip(n0,n1))
        loop_pass=loop<=self.limits['loop_position_m'] and normal_loop<=self.limits['loop_rotation_matrix_abs']
        if self.saved:
            np.savez(HERE/'ACTUAL'/'DIAGNOSTIC-FLOAT64-CORRECTED-CLASS-POSITIONS-NOT-MODEL.npz',
              free_class_ids=self.fi,pose_matrices=np.array([r[0] for r in self.saved]),
              corrected_free_positions_m=np.array([r[1] for r in self.saved]))
        return {**self.receipt,'unique_pose_count':len(self.cache),'sample_records':self.samples,
          'infeasibility_certificates':self.rejections,'corrected_geometry_loop_max_m':loop,
          'corrected_normal_component_loop_max':normal_loop,'corrected_loop_pass':loop_pass,
          'corruption_control_rejected':True,'algorithm_optimality_or_global_feasibility_claim':False,
          'skin_joint_centre_following_or_anatomical_collision_qualified':False,
          'diagnostic_normals':'Local proper ARAP rotations applied to neutral source normals; original geometric normal screen unchanged; no GLB shading proof',
          'production_GLTF_bone_morph_budget_or_activation_qualified':False}
