from pathlib import Path
import json,hashlib,difflib,ast
P=Path(__file__).parent;V19=Path('/workspace/shared/T2803-V19-FORE-SAGITTAL-POLE-SAVED-V16-SOURCE-HELD-20261023');V16=Path('/workspace/shared/T2803-V16-TWO-SIDED-UPPER-ATTACHMENT-SOURCE-HELD-20261023')
for name in ['walk_source_ORIGINAL.py','walk_source.py','articulated_chain_PROPOSAL_HELD.py','reconstructed_profiles_HELD.py','actual_model.py','saved_v16_field_HELD.py','RECONSTRUCTED-ANATOMY-AND-PROFILE-INPUTS.json','RERIG-CONTROLS-PROPOSAL-V2.json','PROVED-TAIL-COMPONENT.json']:(P/name).write_bytes((V19/name).read_bytes())
pins=json.loads((V19/'INPUT-PINS.json').read_text());p14=json.loads((V16/'INPUT-PINS.json').read_text());pins['v14_field_receipt']=p14['v14_field_receipt']
for name,path in [('unchanged_hind_certificate','/workspace/shared/T2803-V19-UNCHANGED-HIND-FAIL-SOURCE-CERTIFICATE-20261023.json'),('v17_fail','/workspace/shared/T2803-V17-JOINT-CENTERED-FETLOCK-SOURCE-HELD-20261023/ACTUAL/TERMINAL.json')]:
 pp=Path(path);pins[name]={'path':str(pp),'sha256':hashlib.sha256(pp.read_bytes()).hexdigest(),'bytes':pp.stat().st_size}
(P/'INPUT-PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
authorization='ONE_ROOT_AUTHORIZED_V21_ALL_FOUR_INTRINSIC_ORIGINAL65_DIAGNOSTIC'
s=(V19/'prove_original65_anatomical_HELD.py').read_text();original=s
s=s.replace('ONE_ROOT_AUTHORIZED_V19_FORE_POLE_SAVED_V16_ORIGINAL65',authorization)
# Harden refusal before numerical imports. Original physical core below stays exact apart from one declared hook insertion.
s=s.replace('import numpy as np\nfrom actual_model import Model\nfrom walk_source import pose,PARAMETERS as PARAM,THRESHOLDS as LIMIT\n','')
anchor="F=pathlib.Path('/workspace/shared/T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb');"
s=s.replace(anchor,'import numpy as np\nfrom actual_model import Model\nfrom walk_source import pose,PARAMETERS as PARAM,THRESHOLDS as LIMIT\n'+anchor)
insertion="""# V21 explicit diagnostic-only correction hook; raw LBS function above retained byte-exact.
raw_skin=skin
from intrinsic_correction_HELD import Intrinsic
reference_neutral=np.array([m.world(i)for i in range(26)])
reference_points,reference_normals=raw_skin(reference_neutral)
intrinsic=Intrinsic(rest,parts,limbs,patch,reference_neutral,reference_normals,LIMIT)
def skin(matrices):
 return intrinsic.apply(matrices,*raw_skin(matrices))
# End V21 hook; original metric/core statements below remain byte-exact.
"""
s=s.replace('neutral_matrices=np.array(',insertion+'neutral_matrices=np.array(',1)
s=s.replace("'ACTUAL-V19-FORE-POLE-SAVED-V16-ORIGINAL65-READBACK.json'","'ACTUAL-V21-INTRINSIC-ORIGINAL65-READBACK.json'")
s=s.replace("'Exact immutable26joint rig/rest/IB and saved accepted-standing V16 field04df with fore anatomical sagittal pole only; no field construction/cast/clipping/pruning/renormalization. Original protected/tail/hoof bits copied unchanged. Current body30mm/foot path/Ra/Rd schedules and hind motion unchanged. Known hind WALK failures may remain. Prior independentQPcertificate remainsFAIL. Original65pose CPU diagnostic only, no GLB/animation export, GLTFLoader/Mixer, rendered or photographic acceptance.'", "'Exact immutable26joint rig/rest/IB and saved V16 field04df plus V19 fore pole. Diagnostic-only all-four ARAP soft-tissue positions on topology domains; original source-protected/tail/hoof vertices and normals retain raw LBS bits. No field rebuild/cast/prune/renormalization, no bone/motion/threshold change beyond source-reviewed forepole. Internal joint surface-following/collision is NOT qualified. No glTF skin/morph/animation export or photographic acceptance; prior QP and walking FAIL remain.'")
needle="(OUT/'ACTUAL-V21-INTRINSIC-ORIGINAL65-READBACK.json').write_text"
addition="""intrinsic_report=intrinsic.finish(first,last,raw_skin)
result['intrinsic_fixed_boundary_diagnostic']=intrinsic_report
result['original65_physical_guards_pass_independently']=bool(mechanics and deformation)
result['original65_plus_corrected_loop_pass']=bool(mechanics and deformation and intrinsic_report['corrected_loop_pass'])
result['ARAP_optimality_required_for_physical_feasibility_witness']=False
result['walk_accepted']=False
"""
s=s.replace(needle,addition+needle)
s=s.replace('if not mechanics or not deformation:raise SystemExit(2)',"if not mechanics or not deformation or not intrinsic_report['corrected_loop_pass']:raise SystemExit(2)")
(P/'prove_original65_anatomical_HELD.py').write_text(s)
core=lambda x:x[x.index('def skin('):x.index('result=')]
assert core(s).replace(insertion,'')==core(original)
assert hashlib.sha256(core(original).encode()).hexdigest()=='d78d622061bdf450bd00f9a75a935880c466a1076ba7d406223ea0c891c871ca'
(P/'ORIGINAL-CORE-HOOK-PROOF.json').write_text(json.dumps({'original_core_sha256':hashlib.sha256(core(original).encode()).hexdigest(),'after_removing_exact_declared_hook_core_byte_identical':True,'raw_LBS_function_byte_exact':True,'all_original65_times_thresholds_metrics_and_negative_controls_byte_exact':True,'hook_text':insertion,'new_corrected_geometry_loop_is_additional_independent_guard':True},indent=2)+'\n')
(P/'CALLER-MINIMAL.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='V19/prove_original65_anatomical_HELD.py',tofile='V21/prove_original65_anatomical_HELD.py')))
# A false release remains false. No runner is invoked by this assembler.
source_names=[p.name for p in P.iterdir() if p.is_file() and p.suffix in ['.py','.json','.md','.patch'] and p.name not in ['RELEASE-TEMPLATE-HELD.json','MANIFEST.json','SOURCE-READINESS.json']]
release={'released':False,'authorization':authorization,'maximum_runs':1,'maximum_fields':0,'maximum_original65_diagnostics':1,'maximum_wall_seconds':60,'maximum_rss_bytes':768*1024*1024,'maximum_address_space_bytes':768*1024*1024,'nice':19,'math_threads':1,'fixed_ARAP_steps_per_unique_pose':20,'maximum_unique_pose_solves':67,'maximum_sparse_factorizations':1,'maximum_LP_QP_solves':0,'maximum_GLTF_animation_morph_exports':0,'intrinsic_linear_solve_execution_authorized':False,'QP_LP_or_model_export_or_activation_authorized':False,'ARAP_linear_solves_require_separate_explicit_root_release':True,'no_retry_or_automatic_next_phase':True,'caller_sha256':hashlib.sha256((P/'prove_original65_anatomical_HELD.py').read_bytes()).hexdigest(),'loader_sha256':hashlib.sha256((P/'saved_v16_field_HELD.py').read_bytes()).hexdigest(),'tail_fixture_sha256':hashlib.sha256((P/'PROVED-TAIL-COMPONENT.json').read_bytes()).hexdigest(),'source_sha256':{name:hashlib.sha256((P/name).read_bytes()).hexdigest() for name in sorted(source_names)},'runtime':{'path':'/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python','version':'3.11.17'},'prior_QP_certificate_pass':False,'prior_V17_WALK_FAIL_preserved':True,'prior_V16_WALK_FAIL_preserved':True}
(P/'RELEASE-TEMPLATE-HELD.json').write_text(json.dumps(release,indent=2)+'\n')
print('Source assembled; numerical imports and ACTUAL absent')
