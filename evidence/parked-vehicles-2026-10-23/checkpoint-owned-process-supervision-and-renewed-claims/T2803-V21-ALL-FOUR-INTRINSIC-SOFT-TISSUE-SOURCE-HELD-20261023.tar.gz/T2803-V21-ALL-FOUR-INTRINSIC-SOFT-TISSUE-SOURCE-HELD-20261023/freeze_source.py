"""Standard-library source inspection ONLY; never import the proposal."""
from pathlib import Path
import ast,hashlib,json,tarfile
P=Path(__file__).parent
assert not (P/'ACTUAL').exists()
checked=[]
for p in sorted(P.glob('*.py')):
    source=p.read_text();ast.parse(source,filename=str(p));compile(source,str(p),'exec')
    checked.append({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'AST_and_compile_only':'PASS'})
for p in sorted(P.glob('*.json')):json.loads(p.read_text())
r=json.loads((P/'RELEASE-TEMPLATE-HELD.json').read_text());assert r['released'] is False
assert r['intrinsic_linear_solve_execution_authorized'] is False
for name,digest in r['source_sha256'].items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest,name
inputs=json.loads((P/'INPUT-PINS.json').read_text());pins=[]
for name,row in inputs.items():
    p=Path(row['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],name
    pins.append({'name':name,**row,'hash_readback':'PASS'})
V19=Path('/workspace/shared/T2803-V19-FORE-SAGITTAL-POLE-SAVED-V16-SOURCE-HELD-20261023')
unchanged=['walk_source_ORIGINAL.py','walk_source.py','articulated_chain_PROPOSAL_HELD.py','reconstructed_profiles_HELD.py','actual_model.py','saved_v16_field_HELD.py','RECONSTRUCTED-ANATOMY-AND-PROFILE-INPUTS.json','RERIG-CONTROLS-PROPOSAL-V2.json','PROVED-TAIL-COMPONENT.json']
for name in unchanged:assert (P/name).read_bytes()==(V19/name).read_bytes(),name
proof=json.loads((P/'ORIGINAL-CORE-HOOK-PROOF.json').read_text())
new=(P/'prove_original65_anatomical_HELD.py').read_text();old=(V19/'prove_original65_anatomical_HELD.py').read_text()
core=lambda s:s[s.index('def skin('):s.index('result=')]
assert core(new).replace(proof['hook_text'],'')==core(old)
assert hashlib.sha256(core(old).encode()).hexdigest()==proof['original_core_sha256']=='d78d622061bdf450bd00f9a75a935880c466a1076ba7d406223ea0c891c871ca'
report={'status':'SOURCE_ONLY_READY_FOR_ROOT_REVIEW_EXECUTION_HELD','AST_compile_checks':checked,'external_pins':pins,'byte_exact_V19_inputs':unchanged,'raw_original_core_after_exact_hook_removal':'BYTE_IDENTICAL','physical_metric_subject':'Corrected diagnostic positions/normals, explicitly NOT unchanged production LBS skin','original65_times_limits_metrics_controls':'UNCHANGED','release_false':True,'ACTUAL_absent':True,'numerical_imports_fields_poses_solvers_tests_runs':0,'GLTF_morph_animation_or_model_exports':0,'canonical_app_ticket_index_ref_writes':0,'standing_b479_changed':False,'bounded_future_recipe_only':'60s/768MiBRSS+AS/nice19/math1,20steps/max67poses/onefactor/noQP_LP/no retry','no_global_infeasibility_claim_from_ARAP_failure':True}
(P/'SOURCE-READINESS.json').write_text(json.dumps(report,indent=2)+'\n')
manifest={str(p.relative_to(P)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in sorted(P.rglob('*'))if p.is_file() and p.name!='MANIFEST.json'}
(P/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=Path(str(P)+'.tar.gz')
with tarfile.open(archive,'w:gz')as t:t.add(P,arcname=P.name)
print(json.dumps({'source_directory':str(P),'capsule':str(archive),'capsule_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'capsule_bytes':archive.stat().st_size,'manifest_sha256':hashlib.sha256((P/'MANIFEST.json').read_bytes()).hexdigest(),'engine_sha256':hashlib.sha256((P/'intrinsic_correction_HELD.py').read_bytes()).hexdigest(),'caller_sha256':hashlib.sha256((P/'prove_original65_anatomical_HELD.py').read_bytes()).hexdigest(),'supervisor_sha256':hashlib.sha256((P/'run_once_HELD.py').read_bytes()).hexdigest(),'recipe_sha256':hashlib.sha256((P/'SINGLE-RUN-RECIPE.json').read_bytes()).hexdigest(),'release_template_sha256':hashlib.sha256((P/'RELEASE-TEMPLATE-HELD.json').read_bytes()).hexdigest(),'readiness':report['status']},indent=2))
