"""HELD one intrinsic all-four diagnostic,60s768MiB; no LP/QP/export/retry."""
from pathlib import Path
import ctypes,datetime,hashlib,json,os,resource,signal,subprocess,sys,time
HERE=Path(__file__).resolve().parent
PYTHON='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python'
AUTH='ONE_ROOT_AUTHORIZED_V21_ALL_FOUR_INTRINSIC_ORIGINAL65_DIAGNOSTIC'
PARENT_PID=os.getpid()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def child_limits():
    # Conservative kernel virtual-address cap also bounds resident mappings;
    # import/allocation refusal remains RESOURCE/INCONCLUSIVE, never physics.
    libc=ctypes.CDLL(None,use_errno=True)
    libc.prctl.argtypes=[ctypes.c_int,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong]
    libc.prctl.restype=ctypes.c_int
    if libc.prctl(1,int(signal.SIGKILL),0,0,0)!=0:raise OSError(ctypes.get_errno(),'Parent-death guard refused')
    if os.getppid()!=PARENT_PID:os.kill(os.getpid(),signal.SIGKILL)
    limit=768*1024*1024
    resource.setrlimit(resource.RLIMIT_AS,(limit,limit))
    resource.setrlimit(resource.RLIMIT_CPU,(60,60))

def group_alive(pid):
    try:os.killpg(pid,0);return True
    except ProcessLookupError:return False

def main():
    assert sys.version_info[:3]==(3,11,17),'Runtime HOLD before numerical imports'
    assert Path(sys.executable).resolve()==Path(PYTHON).resolve(),'Approved executable guard HOLD'
    rpath=Path(sys.argv[1]).resolve();r=json.loads(rpath.read_text())
    assert r['released'] is True and r['authorization']==AUTH
    assert r['intrinsic_linear_solve_execution_authorized'] is True
    assert r['QP_LP_or_model_export_or_activation_authorized'] is False
    assert r['maximum_runs']==1 and r['maximum_fields']==0 and r['maximum_original65_diagnostics']==1
    assert r['maximum_wall_seconds']==60 and r['maximum_rss_bytes']==768*1024*1024
    assert r['maximum_address_space_bytes']==768*1024*1024
    assert r['fixed_ARAP_steps_per_unique_pose']==20 and r['maximum_unique_pose_solves']==67
    assert r['maximum_sparse_factorizations']==1 and r['maximum_LP_QP_solves']==0
    assert r['maximum_GLTF_animation_morph_exports']==0
    for name,digest in r['source_sha256'].items():assert sha(HERE/name)==digest,name+' drift'
    for key,row in json.loads((HERE/'INPUT-PINS.json').read_text()).items():assert sha(row['path'])==row['sha256'],key+' drift'
    out=HERE/'ACTUAL';assert not out.exists(),'One-shot directory exists; no retry'
    out.mkdir();(out/'ROOT-RELEASE.json').write_text(json.dumps(r,indent=2)+'\n')
    intent={'started_utc':utc(),'wall_limit_s':60,'rss_limit_bytes':768*1024*1024,
      'kernel_address_space_limit_bytes':768*1024*1024,'kernel_CPU_limit_seconds':60,
      'nice':19,'math_threads':1,'original65_diagnostics':1,'new_weight_fields':0,
      'maximum_sparse_factorizations':1,'maximum_linear_solves':67*20,
      'maximum_batch_3x3_polar_SVD_calls':67*22,'LP_QP_solves':0,
      'GLTF_morph_animation_export_or_activation':False}
    (out/'INTENT.json').write_text(json.dumps(intent,indent=2)+'\n')
    env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    start=time.monotonic();peak=0;reason=None
    child=None;code=None;supervisor_error=None
    def interrupted(signum,frame):raise RuntimeError('Supervisor signal '+str(signum))
    previous_term=signal.signal(signal.SIGTERM,interrupted)
    try:
        with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
            child=subprocess.Popen(['nice','-n','19',PYTHON,str(HERE/'prove_original65_anatomical_HELD.py'),str(rpath)],cwd=HERE,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=child_limits)
            while child.poll() is None:
                try:
                    for line in (Path('/proc')/str(child.pid)/'status').read_text().splitlines():
                        if line.startswith('VmRSS:'):peak=max(peak,int(line.split()[1])*1024)
                except FileNotFoundError:pass
                if time.monotonic()-start>60:reason='WALL_LIMIT_60_SECONDS'
                elif peak>768*1024*1024:reason='RSS_LIMIT_768_MiB'
                if reason:break
                time.sleep(.025)
    except BaseException as error:
        supervisor_error={'type':type(error).__name__,'message':str(error)}
        reason=reason or 'SUPERVISOR_EXCEPTION_OR_INTERRUPT'
    finally:
        if child is not None:
            if child.poll() is None:
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
            code=child.wait()
        signal.signal(signal.SIGTERM,previous_term)
    elapsed=time.monotonic()-start;peak=max(peak,int(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)*1024)
    if peak>768*1024*1024:reason=reason or 'KERNEL_PEAK_RSS_EXCEEDED_768_MiB'
    if elapsed>60:reason=reason or 'ELAPSED_LIMIT_EXCEEDED_60_SECONDS'
    closed=child is None or not group_alive(child.pid)
    if not closed:
        try:os.killpg(child.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        time.sleep(.025);closed=not group_alive(child.pid)
        reason=reason or 'UNEXPECTED_OWNED_PROCESS_GROUP_AFTER_CHILD_WAIT'
    path=out/'ACTUAL-V21-INTRINSIC-ORIGINAL65-READBACK.json';report=json.loads(path.read_text()) if path.exists() else None
    error_path=out/'stderr.log';error_text=error_path.read_text() if error_path.exists() else ''
    if report is None and any(word in error_text for word in ['MemoryError','failed to map','Cannot allocate memory']):
        reason=reason or 'KERNEL_ADDRESS_SPACE_OR_ALLOCATION_REFUSAL'
    if reason:status='RESOURCE_OR_CHILD_CLOSURE_FAIL_NO_RETRY'
    elif report is None:status='SOURCE_PROPOSAL_OR_NUMERICAL_REFUSAL_INCONCLUSIVE_NO_RETRY'
    elif report['original65_plus_corrected_loop_pass'] and code==0:status='ORIGINAL65_INTRINSIC_SHAPE_DIAGNOSTIC_PASS_ONLY_NOT_PRODUCTION_SKIN'
    else:status='ORIGINAL65_INTRINSIC_SHAPE_DIAGNOSTIC_FAIL_NO_RETRY'
    terminal={'status':status,'finished_utc':utc(),'exit_code':code,'elapsed_seconds':elapsed,
      'actual_peak_rss_bytes':peak,'resource_failure':reason,'runs':1,'reruns':0,
      'child_started':child is not None,'child_reaped':child is not None and code is not None,
      'parent_exception':supervisor_error,'child_parent_death_SIGKILL_registered':child is not None,
      'no_owned_child_active':closed,'report_present':report is not None,
      'all65_physical_samples':65 if report is not None else None,
      'LP_QP_solves':0,'weight_fields':0,'production_GLTF_or_animation_or_morph_export':False,
      'prior_V8_V9_V10_QP_V12_V14_V16_V17_FAIL_preserved':True,
      'standing_V16_b479_unchanged':True,'walk_naturalness_or_visual_or_interaction_accepted':False,
      'model_activation_or_next_phase':False}
    (out/'TERMINAL.json').write_text(json.dumps(terminal,indent=2)+'\n');print(json.dumps(terminal),flush=True)
    return 0 if status=='ORIGINAL65_INTRINSIC_SHAPE_DIAGNOSTIC_PASS_ONLY_NOT_PRODUCTION_SKIN' else 2
if __name__=='__main__':raise SystemExit(main())
