"""Unexecuted reconstructed C1 rotation reference. NOT a gait/contact/skin pass.

Input is previously reviewed full-ancestor proper WORLD rotation data, not raw
local keys or scaled world basis columns. No translations, IK, field or export.
"""
import bisect
import hashlib
import json
import math

DONOR_NODES = (46,47,48,49,50,52,53,54,55,56,71,72,73,74,75,77,78,79,80,81)
TARGET_NODES = tuple(range(6,26))
TARGET_PARENTS = (None,0,1,2,1,4,1,6,7,8,9,1,11,12,13,14,1,16,17,18,19,1,21,22,23,24)
SOURCE_SHA = '51ab71106472321b565a47aabe281235e2c0801804bcee7694f729192913e22c'
TARGET_SHA = '03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36'
DURATION = 1.75

def unit(q):
    q=tuple(float(v) for v in q)
    assert len(q)==4 and all(math.isfinite(v) for v in q)
    assert abs(sum(v*v for v in q)-1.0)<=1e-10, 'Proper unit rotation required; no raw scaled-basis/quaternion fallback'
    return q

def mul(a,b):
    x,y,z,w=a;X,Y,Z,W=b
    return (w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W,w*W-x*X-y*Y-z*Z)

def inv(q):
    x,y,z,w=unit(q)
    return (-x,-y,-z,w)

def log_rotation(q):
    q=unit(q)
    if q[3]<0:q=tuple(-v for v in q)
    n=math.hypot(*q[:3])
    if n==0:return (0.0,0.0,0.0)
    angle=2*math.atan2(n,q[3])
    assert angle<math.pi, 'Bind-relative principal-log chart boundary; no guessed unwrapping'
    return tuple(angle*v/n for v in q[:3])

def exp_rotation(v):
    angle=math.hypot(*v)
    assert math.isfinite(angle) and angle<math.pi, 'Cubic overshoot left reviewed log chart; fail, do not clamp'
    if angle==0:return (0.0,0.0,0.0,1.0)
    scale=math.sin(angle/2)/angle
    return unit((*[scale*x for x in v],math.cos(angle/2)))

class CyclicC1:
    """One fixed endpoint-drift projection + nonuniform cyclic cubic Hermite.

    Raw log-rotation endpoint residual is removed linearly over exactly1.75s.
    Native key data are therefore explicitly RECONSTRUCTED, not relabelled.
    No parameter sweep, solver, arbitrary width, amplitude or phase selection.
    """
    def __init__(self,times,raw):
        assert len(times)==len(raw)==84 and times[0]==0 and times[-1]==DURATION
        assert all(math.isfinite(t) for t in times) and all(a<b for a,b in zip(times,times[1:]))
        assert all(len(v)==3 and all(math.isfinite(x) for x in v) for v in raw)
        self.times=tuple(times[:-1])
        self.endpoint_log_residual=tuple(raw[-1][k]-raw[0][k] for k in range(3))
        self.values=tuple(tuple(v[k]-(t/DURATION)*self.endpoint_log_residual[k] for k in range(3)) for t,v in zip(times[:-1],raw[:-1]))
        assert all(math.hypot(*v)<math.pi for v in self.values)
        tangents=[];n=len(self.times)
        for i in range(n):
            previous=(i-1)%n;following=(i+1)%n
            tp=self.times[previous]-(DURATION if i==0 else 0)
            tn=self.times[following]+(DURATION if i==n-1 else 0)
            hp=self.times[i]-tp;hn=tn-self.times[i]
            vp,vi,vn=self.values[previous],self.values[i],self.values[following]
            tangents.append(tuple((hn*(vi[k]-vp[k])/hp+hp*(vn[k]-vi[k])/hn)/(hp+hn) for k in range(3)))
        self.tangents=tuple(tangents)

    def at(self,time):
        assert math.isfinite(time)
        t=time%DURATION
        # This is evaluation of the defined periodic function, not an endpoint
        # overwrite or fallback after a failed physical closure calculation.
        if t==0:return self.values[0]
        i=bisect.bisect_right(self.times,t)-1;j=(i+1)%len(self.times)
        end=self.times[j]+(DURATION if j==0 else 0);h=end-self.times[i];u=(t-self.times[i])/h
        h00=2*u*u*u-3*u*u+1;h10=u*u*u-2*u*u+u;h01=-2*u*u*u+3*u*u;h11=u*u*u-u*u
        value=tuple(h00*self.values[i][k]+h10*h*self.tangents[i][k]+h01*self.values[j][k]+h11*h*self.tangents[j][k] for k in range(3))
        assert math.hypot(*value)<math.pi, 'Curve outside log chart; no clipping/fallback'
        return value

class Reference:
    """All20 target world rotations + exact actual-parent local conversion only."""
    def __init__(self,prepared_input_bytes,release):
        assert release['released'] is True and release['authorization']=='ONE_ROOT_AUTHORIZED_PERIODIC_ROTATION_REFERENCE_ONLY'
        assert release['prepared_world_rotation_input_sha256'] is not None
        assert hashlib.sha256(prepared_input_bytes).hexdigest()==release['prepared_world_rotation_input_sha256']
        data=json.loads(prepared_input_bytes)
        assert data['source_sha256']==SOURCE_SHA and data['target_rig_sha256']==TARGET_SHA
        assert data['full_ancestor_world_composition_reviewed'] is True
        assert data['proper_rotation_scale_separation_reviewed'] is True
        assert data['donor_nodes_in_target_order']==list(DONOR_NODES)
        assert data['target_parent_indices']==list(TARGET_PARENTS)
        times=data['union_times_s'];assert len(times)==84 and times[0]==0 and times[-1]==DURATION
        self.target_bind=tuple(unit(q) for q in data['target_bind_world_quaternions'])
        assert len(self.target_bind)==26
        self.curves={}
        for target,donor in zip(TARGET_NODES,DONOR_NODES):
            source_bind=unit(data['donor_bind_world_quaternions'][str(donor)])
            raw_world=data['donor_key_world_quaternions'][str(donor)];assert len(raw_world)==84
            # Full world, right bind inverse; this includes BOTH hind ancestors
            # and fore node34's known2.3567degree seam before reconstruction.
            raw=[log_rotation(mul(unit(q),inv(source_bind))) for q in raw_world]
            self.curves[target]=CyclicC1(times,raw)

    def world_rotations(self,time,unchanged_target_world_0_to_5):
        assert len(unchanged_target_world_0_to_5)==6
        world=[unit(q) for q in unchanged_target_world_0_to_5]
        for target in TARGET_NODES:
            x,y,z=self.curves[target].at(time)
            # Fixed proper donor WORLD→canonical rotation A(x,y,z)=(z,y,-x).
            delta=exp_rotation((z,y,-x))
            world.append(unit(mul(delta,self.target_bind[target])))
        return tuple(world)

    def local_rotations(self,time,unchanged_target_world_0_to_5):
        world=self.world_rotations(time,unchanged_target_world_0_to_5)
        return tuple(world[i] if p is None else unit(mul(inv(world[p]),world[i])) for i,p in enumerate(TARGET_PARENTS))
