# Held complete-limb periodic rotation reference

SOURCE ONLY. This is a reusable mathematical rotation-reference proposal, not a bound runnable gait candidate. No numerical import/evaluation, pose, solver, model, export, browser, test or app/ticket/ref mutation was performed. Actual accepted standingV16/exportb479 and current walking field are untouched. ROOT's standing app delivery has priority.

The donor discontinuity is native: existing51ab source Walk1.75s has local hindFoot75/81 endpoint orientation seams20.180848° each, and fore ancestor34 endpoint seam2.356715°. Those were recorded before any canonical retarget. Donor foot-pivot seams also fail a strict loop; they are not foot sole/contact evidence. A canonicaltarget retarget can add further errors through incorrect local/world bind conversion, ignored ancestors/scales or incompatible segment lengths, but it did not cause those recorded native endpoint differences.

A quaternion sign change cannot repair a20° orientation difference. Copying localfoot keys, repairing onlyfore or onlyhindFoot, or hiding an endpoint mismatch in root translation is insufficient. Complete source hierarchy is required: fore ancestor33→34, hind33→60→65, plus all upstream root/wrapper nodes. All20 donor joints46–50/52–56/71–75/77–81 map to Sevket6–25. The existing metadata inventory pins their actual local/rest bases and84 irregular union timestamps.

One fixed, explicit **reconstructed** periodic representation is provided in periodic_reference_HELD.py. Given reviewed proper full-ancestor donor world quaternions at every original uniontime, compute each world bind-relative rotation vector v(t_i)=Log(R_D(t_i) inverse(R_D,bind)). In that single reviewed principal chart remove the measured endpoint drift across the cycle:

```
v_corrected(t_i) = v(t_i) - (t_i / 1.75) * (v(1.75) - v(0))
```

The correction is determined by the actual endpoint mismatch; there is no guessed amplitude, width, phase, sweep or numerical solver. It changes source motion and must be credited as a project reconstruction, never reported as the exact native Walk. This is a neutral engineering proposal for distributing a recorded defect, not biological evidence that its new intermediate joint angles are correct.

A nonuniform cyclic cubic Hermite representation is built on the corrected83 independent controls (the84th endpoint equals the first). Cyclic neighboring secants determine each knot's one shared derivative; last and first segments use the same endpoint value and tangent. Evaluation uses t modulo1.75, so the defined rotation curve is C1 periodic by construction, not an endpoint overwrite after a failed test. It is not C2. The log chart is explicit: input or cubic overshoot outside angle<pi fails; no clipping, guessed unwrapping, fallback or amplitude reduction. This representation is not an assertion that all continuous-time physical constraints hold.

Retarget uses fixed proper A(x,y,z)=(z,y,-x): R_S,j(t)=Exp(A v_corrected,j(t)) R_S,j,bind. All localtarget rotations then come from inverse(actual parent world rotation) times child world rotation using the exact26-node parent list. No rawlocal-quaternion copy or donorposition/length paste occurs. The first6 target worldrotations must be the original reviewed body/root/head/tail input, itself periodic for full-frame closure; this helper neither composes a new idle nor qualifies head/tail blends. All target restlocal translations, route/root trajectory, savedV16 weights and geometry remain external/unchanged. It emits no positions or root translation and cannot conceal contact drift by moving the origin.

Callable held API:

```
reference = Reference(prepared_input_bytes, explicit_root_release)
reference.world_rotations(time, unchanged_target_world_0_to_5)  #26proper quaternions
reference.local_rotations(time, unchanged_target_world_0_to_5)  #actual-parent locals
```

Release requires SHA256 of an actual reviewed prepared-input JSON. That pin is NULL in HELD-INPUT-CONTRACT.json. Missing input fields are full donor bind/worldkey quaternions for all20 joints at84 originaluniontimes after reviewed proper-rotation/scale separation, all26 target bindworldquaternions and exactparentindices, and actual sourcehash provenance. Saved metadata currently has restbases and33 foot-pivot paths, not those composed quaternion streams; no streams were fabricated or evaluated here.

Even with that rotation input, contact is unresolved. Donor has no qualified sole/ground frame, stance/roll events or route speed (Walk root19 is in place). Retarget changes target jointpositions through its own forward kinematics and does not preserve donor contacts automatically. A usable next candidate must declare the original target complete59/59/13/10patch schedule and stride/root mapping, then face every original loop/contact/segment/edge/area/normal/ground/seam/neutral guard plus loaded interpolation behavior. No threshold is changed here; a periodicrotation representation can still FAIL contact and skin everywhere. No source-backed claim that this particular reconstruction will pass is available.

No automatic runtime or numerical recipe is authorized by this packet. This small source alternative is held while the gait agent prepares the separate complete all-four lower-transition correction. Do not combine independently changed fields/motions or run a search. If that actual correction succeeds, this alternative may remain unused.
