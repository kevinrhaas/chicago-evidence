from pathlib import Path
import json,hashlib,subprocess,tarfile
out=Path(__file__).parent; root='chicago/4d/'
base=out/'base'/root; new=out/'new'/root
# Syntax only: node --check does not import or execute the app, unit, Three or assets.
checks=[]
for p in sorted(new.rglob('*')):
 if not p.is_file():continue
 if p.suffix in ['.js','.mjs']:
  r=subprocess.run(['nice','-n','19','node','--check',str(p)],capture_output=True,text=True,timeout=8)
  checks.append({'file':str(p.relative_to(new)),'operation':'node --check ONLY','exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
  if r.returncode: print(json.dumps(checks[-1],indent=2))
  assert r.returncode==0
 elif p.suffix=='.json':json.loads(p.read_text())
old=json.loads((base/'data/transport/parked/standing-horses.json').read_text());d=json.loads((new/'data/transport/parked/standing-horses.json').read_text())
def raw_first_row(text):
 start=text.index('"1835"');start=text.index('{',start);_,end=json.JSONDecoder().raw_decode(text[start:]);return text[start:start+end]
assert raw_first_row((base/'data/transport/parked/standing-horses.json').read_text())==raw_first_row((new/'data/transport/parked/standing-horses.json').read_text())
assert d['scenes']['1835']==old['scenes']['1835'];assert d['models']==old['models']
assert (new/'renderers/web/js/yard-static-support.js').read_bytes().startswith((base/'renderers/web/js/yard-static-support.js').read_bytes())
assert (new/'docs/LIBERTIES.md').read_bytes().startswith((base/'docs/LIBERTIES.md').read_bytes())
assert (new/'tools/test_planted_standing_horse_contract.mjs').read_bytes().startswith((base/'tools/test_planted_standing_horse_contract.mjs').read_bytes())
assert not d['scenes']['1904'][0]['enabled'] and not d['scenes']['1904'][0]['animation']['enabled']
assert d['scenes']['1904'][0]['world_qualified'] is False
assert d['scenes']['1904'][0]['qualified_runtime_asset_sha256'] is None
assert d['scenes']['1904'][0]['qualified_support_quaternion_xyzw'] is None
orig_scene=json.loads((base/'data/scenes/1904.json').read_text());new_scene=json.loads((new/'data/scenes/1904.json').read_text());new_scene.pop('static_support_regions');new_scene['layers'].remove('standing_horses');assert new_scene==orig_scene
# No production asset, clip, skin, old1835 scene, publish script, release policy or app data was written here.
report={'status':'SOURCE_SYNTAX_AND_STDLIB_TEXT_PROOF_ONLY','checks':checks,'json_parse':'PASS','1835_row_raw_bytes_exact':True,'1835_models_exact':True,'1835_original_yard_helper_prefix_exact':True,'existing_unit_prefix_exact':True,'liberties_append_only':True,'1904_original_scene_semantics_exact_except_layer_and_region':True,'1904_placement_and_animation_disabled':True,'1904_ground_asset_app_qualification_absent':True,'unit_execution':'HELD_NOT_RUN','app_glb_pose_ground_model_browser_execution':'NONE','canonical_app_index_ticket_ref_mutations':'NONE'}
(out/'SOURCE-READINESS.json').write_text(json.dumps(report,indent=2)+'\n')
manifest={str(p.relative_to(out)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=Path(str(out)+'.tar.gz')
with tarfile.open(archive,'w:gz') as t:t.add(out,arcname=out.name)
print(json.dumps({'capsule':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'patch_sha256':hashlib.sha256((out/'1904-EXTENSION.patch').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((out/'MANIFEST.json').read_bytes()).hexdigest(),'syntax_checks':len(checks),'status':report['status']},indent=2))
