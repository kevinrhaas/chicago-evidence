from pathlib import Path
import json,hashlib,difflib
out=Path(__file__).parent; app=Path('/workspace/chicago-waistcoat'); root='chicago/4d/'
files=['renderers/web/js/standing-horses.js','renderers/web/js/standing-horse-card.js','renderers/web/js/yard-static-support.js','renderers/web/js/street-grid.js','renderers/web/js/main.js','data/scene.schema.json','data/scenes/1904.json','data/transport/parked/standing-horses.json','tools/test_planted_standing_horse_contract.mjs','docs/LIBERTIES.md']
base={}; new={}
for f in files:
 p=app/(root+f);base[f]=p.read_text();new[f]=base[f]
def replace(f,a,b):
 assert new[f].count(a)==1,(f,a[:100],new[f].count(a));new[f]=new[f].replace(a,b,1)
f='renderers/web/js/standing-horses.js'
replace(f,"import { standingHorseCard as card } from './standing-horse-card.js';","import { standingHorseCard as card } from './standing-horse-card.js';\nimport { selectStandingHorseRows } from './standing-horse-placement-contract.js';")
replace(f,"  problems = [], hostMissing = () => false, groundHeight = null } = {}) {","  problems = [], hostMissing = () => false, hostPresent = () => false, groundHeight = null,\n  targetDate = null, supportRegions = [] } = {}) {")
replace(f,"  if (!dataBase || String(sceneId) !== '1835') return out;","  if (!dataBase || !['1835', '1904'].includes(String(sceneId))) return out;")
replace(f,"    rows = (manifest.scenes[String(sceneId)] ?? []).filter(row => !hostMissing(row.belongs_to));","    rows = selectStandingHorseRows(manifest, { sceneId, targetDate, supportRegions, hostMissing, hostPresent });")
replace(f,"    assert(q.every((value, i) => Math.abs(value - spec.proposed_static_support_pose.local_quaternion_xyzw[i]) < 1e-12),\n      'Horse support pose differs from the explicit sidecar proposal');","    if (row.surface_kind === 'carriageway_triangle') {\n      assert(row.world_qualified === true && row.support_pose_status === 'qualified'\n        && row.qualified_runtime_asset_sha256 === spec.runtime_asset.sha256,\n        '1904 ground/asset/app qualification required');\n      assert(row.qualified_support_quaternion_xyzw?.length === 4\n        && q.every((value, i) => value === row.qualified_support_quaternion_xyzw[i]),\n        '1904 support pose differs from its qualified placement');\n    } else {\n      assert(q.every((value, i) => Math.abs(value - spec.proposed_static_support_pose.local_quaternion_xyzw[i]) < 1e-12),\n        'Horse support pose differs from the explicit sidecar proposal');\n    }")
replace(f,"groundHeight(e, n, row.ground_record_id, row.ground_support_region_id);","groundHeight(e, n, row.ground_record_id, row.ground_support_region_id, row.surface_kind);")
f='renderers/web/js/standing-horse-card.js'
replace(f,"    const source = spec.citation_records?.[source_id];","    const source = spec.citation_records?.[source_id] ?? row.citation_records?.[source_id];")
replace(f,"  return { id: row.id, sidecar: {","  const yard1835 = row.scene_id !== '1904';\n  const context = yard1835 ? 'the 1835 Western Hotel yard' : row.location;\n  const year = yard1835 ? '1835' : '1904';\n  return { id: row.id, sidecar: {")
replace(f,"A reconstructed, unidentified horse in the 1835 Western Hotel yard.","A reconstructed, unidentified horse in ${context}.")
replace(f,"a particular 1835 horse, breed or owner.","a particular ${year} horse, breed or owner.")
replace(f,"sources: row.source_ids, note: 'Yard context supports horsekeeping; this individual is a reconstruction.'","sources: row.source_ids, note: yard1835\n          ? 'Yard context supports horsekeeping; this individual is a reconstruction.'\n          : 'Neighborhood stable context supports horsekeeping; neither this individual nor its exact street stand is attested.'")
replace(f,"declared whole-root support rotation, yard placement and reconstructed planted body shifts.","declared whole-root support rotation, ${yard1835 ? 'yard' : 'carriageway'} placement and reconstructed planted body shifts.")
f='renderers/web/js/yard-static-support.js';new[f]+= (out/'carriageway-support-append.js').read_text()
f='renderers/web/js/street-grid.js'
replace(f,"import * as THREE from 'three';","import * as THREE from 'three';\nimport { retainCarriagewayStaticSupport } from './yard-static-support.js';")
replace(f,"  dataBase, assetBase = null, sceneId, terrain, confidence = null, problems = [],","  dataBase, assetBase = null, sceneId, terrain, confidence = null, problems = [],\n  targetDate = null, supportRegions = [],")
replace(f,"    carriagewayHeight: () => null,","    carriagewayHeight: () => null,\n    drawnStaticSupport: null,")
replace(f,"  out.dispose = () => {\n    if (out.groundCut)","  // Snapshot named top-surface spans before normal upload release; overlays are excluded.\n  const staticSupport = retainCarriagewayStaticSupport(meshes, supportRegions, {\n    sceneId, targetDate, problems,\n  });\n  out.drawnStaticSupport = staticSupport;\n  out.dispose = () => {\n    staticSupport.dispose();\n    if (out.groundCut)")
f='renderers/web/js/main.js'
replace(f,"    terrain, confidence, problems: layerProblems('street_grid'),","    terrain, confidence, problems: layerProblems('street_grid'),\n    targetDate: loaded.scene.target_date,\n    supportRegions: String(YEAR) === '1904' && draws('standing_horses')\n      ? (loaded.scene.static_support_regions ?? []) : [],")
replace(f,"    supportRegions: draws('standing_horses') ? (loaded.scene.static_support_regions ?? []) : [],","    supportRegions: String(YEAR) === '1835' && draws('standing_horses') ? (loaded.scene.static_support_regions ?? []) : [],")
replace(f,"    groundHeight: (e, n, recordId, regionId) => yards.drawnBaseHeightAt(e, n, recordId, regionId),","    targetDate: loaded.scene.target_date, supportRegions: loaded.scene.static_support_regions ?? [],\n    hostPresent: id => Boolean(id && loaded.registry.has(id) && !hostMissing(id)),\n    groundHeight: (e, n, recordId, regionId, kind) => kind === 'carriageway_triangle'\n      ? streetGrid.drawnStaticSupport?.heightAt(e, n, recordId, regionId) ?? null\n      : kind === undefined ? yards.drawnBaseHeightAt(e, n, recordId, regionId) : null,")
f='data/scene.schema.json';d=json.loads(new[f]);reg=d['properties']['static_support_regions'];reg['description']+=' Optional1904 carriageway regions additionally declare scene_id, target_date and surface_kind; their named opaque top triangles are retained before normal release, at the same per-scene cap. No fit acceptance is encoded by a region.'
reg['items']['properties'].update({'scene_id':{'const':'1904'},'target_date':{'const':'1904-07-01'},'surface_kind':{'const':'carriageway_triangle'}})
reg['items']['allOf']=[{'if':{'anyOf':[{'required':['scene_id']},{'required':['target_date']},{'required':['surface_kind']}]},'then':{'required':['scene_id','target_date','surface_kind']}}]
new[f]=json.dumps(d,indent=2)+'\n'
f='data/scenes/1904.json';d=json.loads(new[f]);d['layers'].append('standing_horses')
old=Path('/workspace/shared/HORSE-THREE-ERA-FUTURE-IMPLEMENTATION-a086-20261022');rb=json.loads((old/'evidence/1904/READBACK.json').read_text());region=rb['region'];region.update({'basis':'Reconstructed candidate rectangle from saved old-asset contact footprint plus50mm margin; no newb479 ground fit/app acceptance. Only named prairie_18_20 opaque carriageway top triangles may support it.','maximum_region_count':1,'maximum_region_area_m2':4,'maximum_retained_triangles':32,'maximum_retained_typed_array_bytes':4096,'lifetime':'Copy bounded drawn top triangles before normal release; dispose with streetGrid. Original town geometry still releases.'})
d['static_support_regions']=[region];new[f]=json.dumps(d,indent=2)+'\n'
f='data/transport/parked/standing-horses.json';d=json.loads(new[f]);original1835=d['scenes']['1835'];oldrow=json.loads((old/'source/chicago/4d/data/transport/parked/standing-horses.json').read_text())['scenes']['1904'][0]
row=json.loads(json.dumps(original1835[0]));fields=['id','name','belongs_to','ground_record_id','at_local_enu_m','bearing_deg','location','source_ids','confidence','note','ground_support_region_id','surface_kind'];row.update({k:oldrow[k] for k in fields});row.update({'scene_id':'1904','target_date':'1904-07-01','enabled':False,'world_qualified':False,'support_pose_status':'unqualified','qualified_runtime_asset_sha256':None,'qualified_support_quaternion_xyzw':None,'liberty':'L-standing-horse-1904-candidate-2800','support_note':'Current1835 quaternion is a source-only seed, not an accepted1904 fit. Enable only after exact currentb479/drawn-carriageway/whole-clip/app qualification; no oldc255 acceptance transfers.','material_variant_status':'Retain explicit organic dielectric material;1904 visual qualification is pending.'})
row['animation']['enabled']=False;row['capabilities']['playback_enabled']=False;row['capabilities']['static_standing']=False;row['capabilities']['standing_weight_shift']=False
row['citation_records']={sid:json.loads((app/(root+f'data/sources/{sid}.json')).read_text()) for sid in row['source_ids']}
g=row['citation_records']['glessner_story_of_a_house_1923'];g['url']=row['citation_records']['habs_glessner_house_il_1015_data_pages']['url'];g['url_basis']='Link is to HABS ILL-1015, whose data pages transcribe the1923 text. The underlying original typescript was not consulted; text-only/check-required rights remain unchanged.'
d['scenes']['1904']=[row];assert d['scenes']['1835']==original1835;new[f]=json.dumps(d,indent=2)+'\n'
new['docs/LIBERTIES.md'] += '''

### L-standing-horse-1904-candidate-2800 — an inactive Prairie Avenue standing-horse candidate

**Decision:** Record one disabled, unidentified reconstructed horse at E+1397.5,N-3221.2,bearing178.99degrees on the named Prairie Avenue carriageway north of the separate parked Brougham. This is a future stand, not a1904 sighting, household ownership or attachment to that vehicle. Both placement and animation remain disabled until their exact current asset/ground/app checks qualify them. The existing1835 horse and its evidence are unchanged.

**Sources and uncertainty:** Glessner1923, consulted only through the HABS transcription, and the HABS stable/coach-house record support neighborhood horsekeeping, not this street stand or its date. The1923 phrase 'now garage' supplies no conversion date for1904. Sanborn1911 is carried back for inferred street context; the1905 code is later-period analogy. The exact individual, chestnut appearance, stature, grooming, date and stand are reconstructed; no historical breed, owner, tack, tie, rider, driver or route is assigned. Historical text sources supply no image/mesh asset. The1923 citation link names its consulted HABS transcription, not an inspected original manuscript.

**Implementation limits:** The immutable licensed canonical-metre b479 asset and single planted clip are the proposed source; no new model/rig/motion is generated. One named opaque carriageway top region retains at most4m²/32triangles/4096typed-array bytes before normal release, without retaining town arrays or changing release flags. The oldc255 support fit is evidence of an old source-CPU candidate only, not currentb479/world acceptance. Its quaternion is not copied as an accepted fit. The new row has world_qualified:false, support_pose_status:unqualified, null qualified asset/pose, enabled:false and animation.enabled:false. Walking, hitching, tack, riding and photographic acceptance remain open.

**Ticket:** T-2800, source-only additional-era candidate; no ticket completion implied.
**Recorded:**2026-10-23.
'''
new['renderers/web/js/standing-horse-placement-contract.js']=(out/'standing-horse-placement-contract.js').read_text()
# Test addition saved separately; parent must review/run only in its own later window.
new['tools/test_planted_standing_horse_contract.mjs']+=(out/'contract-test-append.mjs').read_text()
for f,s in base.items():
 p=out/'base'/(root+f);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
for f,s in new.items():
 p=out/'new'/(root+f);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
patch=''
for f,s in new.items():
 oldtext=base.get(f,'');patch+=''.join(difflib.unified_diff(oldtext.splitlines(True),s.splitlines(True),fromfile=('a/'+root+f if f in base else '/dev/null'),tofile='b/'+root+f))
(out/'1904-EXTENSION.patch').write_text(patch)
(out/'BASE-PINS.json').write_text(json.dumps({root+f:hashlib.sha256(s.encode()).hexdigest() for f,s in base.items()},indent=2)+'\n')
print('Prepared',len(new),'text files; patch bytes',len(patch.encode()))
