"""Finite Git-object/source containment inspection only; no refs/index/app writes."""
from pathlib import Path
import copy,datetime,hashlib,json,os,subprocess
D=Path(__file__).parent;R='/workspace/chicago';H='0656467069ee3f8d0a40685ee571ceaaf4b0a2d7';M='fffae74c728b469163d3c1a6997aea29b4b9b7b3';T='1d6048e957bfca326db1cdd0aecd16e62f1bd96a'
def git(*args,allow_missing=False):
 q=subprocess.run(['git','-C',R,*args],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
 if q.returncode:
  if allow_missing:return None
  raise RuntimeError(q.stderr.decode(errors='replace'))
 return q.stdout
def show(c,p):return git('show',c+':'+p,allow_missing=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def lines(b):return b.decode(errors='replace').splitlines()
base=git('rev-parse',H+'^').decode().strip();assert git('rev-parse',M+'^{tree}').decode().strip()==T
paths=git('diff','--name-only',base,H).decode().splitlines();assert len(paths)==11
(D/'ORIGINAL-11-PATHS.txt').write_text('\n'.join(paths)+'\n')
(D/'ORIGINAL-SCOPE.diff').write_bytes(git('diff',base,H,'--',*paths))
rows=[]
for p in paths:
 a,b=show(H,p),show(M,p);rows.append({'path':p,'head_sha256':sha(a),'merged_sha256':sha(b) if b is not None else None,'byte_status':'EXACT_BYTES'if a==b else'CONSOLIDATED_PENDING_FRAGMENT'if b is None else'SEMANTIC_RECORD_OR_METADATA_UNION'})
exact=[r for r in rows if r['byte_status']=='EXACT_BYTES'];assert len(exact)==5
P='chicago/4d/assets/authored/transport/wagon_covered/SOURCE.json';a=json.loads(show(H,P));b=json.loads(show(M,P));old=copy.deepcopy(a);new=copy.deepcopy(b)
terrain=[]
for p,value in b['actual_terrain_qualification']['data_sha256'].items():
 actual=sha(show(M,p));assert value==actual;terrain.append({'path':p,'old_snapshot_sha256':a['actual_terrain_qualification']['data_sha256'][p],'merged_pin':value,'actual_merged_bytes_sha256':actual,'pin_matches_merged':True})
old['actual_terrain_qualification'].pop('data_sha256');new['actual_terrain_qualification'].pop('data_sha256');qualification=new['canvas_drape_refinement'].pop('historical_qualification');assert old==new
assert qualification['source_commit']==H and qualification['source_tree']==git('rev-parse',H+'^{tree}').decode().strip()
lib='chicago/4d/data/liberties.json';x=json.loads(show(H,lib));y=json.loads(show(M,lib));lr=next(r for r in x['liberties'] if r['id']=='L-covered-wagons-2980');mr=next(r for r in y['liberties'] if r['id']==lr['id']);assert lr==mr
narrative=next(r['text'] for r in lr['fields'] if r['label']=='Canvas refinement, 2026-10-22');assert narrative.encode() in show(M,'chicago/4d/docs/LIBERTIES.md')
source=b['canvas_drape_refinement'];assert all(w in source['preserved'] for w in ['identities','positions','bearings','finishes','aging','yokes','running gear','materials','textures','runtime unchanged'])
status=show(M,'chicago/4d/docs/STATUS.md').decode(errors='replace');roadmap=show(M,'chicago/4d/docs/ROADMAP.md').decode(errors='replace')
assert 'T-2980 — Exact previously qualified covered-cloth increment' in status and 'aaffa339/22072e6f' in status and '20–28mm' in status
assert 'T-2980: carry the already generated20–28mm cloth-drape increment' in roadmap
pending='chicago/4d/changelog.d/T-2980.json';oldcl=json.loads(show(H,pending));combined=json.loads(show(M,'chicago/4d/changelog.d/T-1789.json'));assert show(M,pending) is None
covered=next(v for v in combined['items'] if v.startswith('The two covered wagons'))
assert all(w in covered for w in ['blue and oak finishes','aging','laid-by yokes','reconstructed canvas drape'])
limits=combined['items'][-1];assert 'Photographic refinement continues; boarding and driving are unavailable.' in limits
historical=Path('/workspace/shared/PR1175-1208-FINITE-CI-AUDIT-20261022-193738/PR-1208.json');pr=json.loads(historical.read_text());assert pr['head']['sha']==H
snapshot={k:pr[k] for k in ['number','title','state','draft','updated_at','body']};snapshot.update(head_sha=pr['head']['sha'],head_ref=pr['head']['ref'],snapshot_source=str(historical),snapshot_source_sha256=sha(historical.read_bytes()),current_GitHub_state_queried=False)
(D/'HISTORICAL-PR1208-SNAPSHOT.json').write_text(json.dumps(snapshot,indent=2)+'\n')
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'STRICT_IMPLEMENTATION_CONTAINMENT_PASS_WITH_EXPLICIT_CHANGELOG_SEMANTIC_CONSOLIDATION','source_head':H,'source_parent':base,'source_tree':git('rev-parse',H+'^{tree}').decode().strip(),'actual_merged_PR1175':M,'actual_merged_tree':T,'scope_accounting':'11 paths =5 exact bytes +1 metadata union +1 exact structured liberty record +1 exact narrative in canonicalLIBERTIES +2 equivalent/up-to-date scope documents +1 explicit semantic changelog consolidation','paths':rows,'source_metadata':{'all_original_keys_values_exact_except_two_terrainpins_and_added_historical_qualification':True,'terrain_pin_updates':terrain,'added_historical_qualification':qualification,'all_original_canvas_parameters_protection_recipe_seed_stand_scope_and_limits_exact':True},'liberty':{'id':lr['id'],'complete_record_deep_equal':True,'original_refinement_narrative_exact_in_merged_LIBERTIES':True,'record_sha256':sha(json.dumps(lr,sort_keys=True).encode())},'scope_documents':{'STATUS_exact_covered_heading_present':True,'STATUS_exact_two_asset_hash_prefixes':True,'STATUS_preserves_20_28mm_750mm_1_2mm_separate_historical_qualification_and_open_scope':True,'ROADMAP_covered_20_28mm_scope_and_preservation_present':True,'stale_premerge_prepared_validation_text_not_reapplied':True},'changelog':{'old_fragment':pending,'merged_fragment':'chicago/4d/changelog.d/T-1789.json','old_title':oldcl['title'],'old_items':oldcl['items'],'old_item_strings_literal_in_combined':[v in combined['items'] for v in oldcl['items']],'literal_transfer':False,'covered_user_facing_consolidation':covered,'open_scope_consolidation':limits,'unchanged_position_runninggear_and_fallback_semantics':'Protected running gear and stand preserved in exact GLBs/sidecars/producer+unchangedSOURCEpreservedcontract. Legacyfallback preserved in merged ROADMAP. Changelog deliberately uses one shorter covered vehicle item plus shared limitations; exact old wording is not claimed.','implementation_semantics_preserved':True},'protected_semantics':{'all_original_asset_and_sidecar_bytes_exact':True,'producer_exact_bytes':True,'original_SOURCE_preserved_contract_exact':source['preserved'],'source_recipe_core_originalyardseed_contracts_and_variant_lineage_unchanged':True,'prior_structural_proof_not_rerun_or_promoted':True},'closure_readiness':{'recommended':'READY_FOR_ROOT_SUPERSEDED_DUPLICATE_CLOSE_AFTER_FRESH_PR_HEAD_STATE_GUARD','fresh_guard_required':'Confirm GitHubPR1208 still OPEN/DRAFT and head065646706 unchanged; actualmerged1175commit/tree are pinned above. No new source/asset/changelog change required for semantic superseded closure.','literal_word_for_word_changelog_transfer_pass':False,'PR1213_analogy':'Same exact-asset/source containment criterion; unlike1213,1208 changelog is intentionally semantic consolidation rather than literal item transfer.','parent_ticket_T2980_closure_authorized_by_this_audit':False,'photographic_LOD_occupied_horse_driving_boarding_completion_claim':False},'old_failures_scope_limits_retained':True,'PR_closed':False,'ticket_commands':0,'new_GitHub_queries':0,'network_calls':0,'app_index_ref_origin_dev_writes':0,'numerical_browser_export_tests':0}
(D/'STRICT-MERGED-CONTAINMENT-READOUT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'paths':len(paths),'exact':len(exact),'source_metadata_contract_preserved':old==new,'covered_liberty_deep_equal':lr==mr,'changelog_literal_transfer':False,'recommended':report['closure_readiness']['recommended']},indent=2))
