from pathlib import Path
import hashlib,importlib.util,json,sys
assert sys.argv[1:]==['--root-browser-lane-released'],'Do not execute without explicit root browser-lane release'
p=Path('/workspace/shared/horse-sevket-native-preview-source-20261022/ownership_supervisor.py');assert hashlib.sha256(p.read_bytes()).hexdigest()=='778e5623d81821a48aeae5080a8cbff4ef57901570ceea9935fa98ecd9bd0ce5'
packet=Path('/workspace/shared/T2793-W01-POLYHAVEN-V4B-NATIVE-AB-CORRECTED-PIN-20261023')
for name,pin in json.loads((packet/'PREPARED-FROZEN-MANIFEST.json').read_text()).items():assert hashlib.sha256((packet/name).read_bytes()).hexdigest()==pin,name
inputs=json.loads((packet/'INPUTS.json').read_text());import re
embedded=dict(re.findall(r"(baseline|candidate):'([a-f0-9]{64})'",(packet/'view.html').read_text()))
for key,model in inputs['models'].items():
 raw=Path(model['path']).read_bytes();assert len(raw)==model['bytes']and hashlib.sha256(raw).hexdigest()==model['sha256']==embedded[key]
spec=importlib.util.spec_from_file_location('owned',p);owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
report=owned.run_owned(['node',str(packet/'capture.cjs'),'--lane-released'],Path('/workspace/shared/T2793-W01-V4B-NATIVE-AB-OWNED-CORRECTED-PIN-20261023'),whole_timeout=100,execution_timeout=95)
print(json.dumps(report,indent=2));raise SystemExit(report.get('exit_code',1))
