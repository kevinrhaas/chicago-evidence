from pathlib import Path
import copy,difflib,hashlib,json,shutil,struct
ROOT=Path('/tmp/chicago-covered-sag/chicago/4d');CAND=Path('/workspace/shared/T2793-W01-POLYHAVEN-V4B-HELD-20261023');OUT=Path('/workspace/shared/T2793-W01-POLYHAVEN-V4B-NORMAL-INTAKE-HELD-20261023');OUT.mkdir();OVER=OUT/'overlay';OVER.mkdir()
def sha(x):return hashlib.sha256(x).hexdigest()
def glb(p):
 r=p.read_bytes();n=struct.unpack_from('<I',r,12)[0];return r,json.loads(r[20:20+n]),r[28+n:]
def write(n,b):
 p=OVER/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes)else b.encode());return p
br,bg,bb=glb(ROOT/'renderers/web/transport/parked-wagon/wagon-w01.glb');cr,cg,cb=glb(CAND/'wagon-w01.glb');assert cb[:len(bb)]==bb
AUTH='assets/authored/transport/wagon_parked_fine_wood';MODEL='renderers/web/transport/parked-wagon-fine-wood'
payload=cb[len(bb):];binding={'schema':'w01_fine_wood_surface_append_v1','parent_sha256':sha(br),'expected_glb_sha256':sha(cr),'payload_sha256':sha(payload),'parent_binary_bytes':len(bb),'append_buffer_views':cg['bufferViews'][110:],'append_accessors':cg['accessors'][92:],'meshes':cg['meshes'],'textures':cg['textures'],'materials':cg['materials'],'images':cg['images'],'asset_copyright':cg['asset']['copyright'],'extras':cg['extras'],'scope':'Project-authored GPL UV/tangent/index charts plus CC0 pixels only; no new POSITION/NORMAL geometry or third-party GPL input. Exact original geometry prefix preserved.'}
write(AUTH+'/surface.bin',payload);write(AUTH+'/surface.json',json.dumps(binding,indent=2)+'\n');write(AUTH+'/ATTRIBUTION.txt',(CAND/'ATTRIBUTION.txt').read_bytes());write(AUTH+'/SOURCE.json',json.dumps({'asset':'fine_grained_wood','creator':'Rob Tuytel','source':'https://polyhaven.com/a/fine_grained_wood','license':'CC0-1.0','license_url':'https://creativecommons.org/publicdomain/zero/1.0/','source_maps':json.loads((CAND/'ACTUAL-RECEIPT.json').read_text())['source_pins'],'changes':cg['extras']['timber_surface_candidate'],'project_geometry_chart_license':'GPL-3.0-or-later','historical_scope':'Modern optical analogy only; no period/species/date/coating/maker/Chicago-specimen claim. Photographic completion remains open.'},indent=2)+'\n')
producer='''#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Fresh original W01 pipeline plus portable project charts and CC0 timber pixels.
No cached GLB input; no external model geometry. Photographic acceptance is open.
"""
from pathlib import Path
import argparse,copy,hashlib,json,struct,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[2]
AUTHORED=ROOT/'assets/authored/transport/wagon_parked_fine_wood'
PARENT='274e737b51872983df792d0b24de8e75de8631890a8d586a32d9c6f0066484fb'
EXPECTED='e1e5b4f1d7dfe6bf08cca21e8cfae2e88748a3f6e6c6959753334ae2b0c84dd8'
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(x):return hashlib.sha256(x).hexdigest()
def unpack(raw):
 need(struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw)),'Invalid GLB2')
 n,k=struct.unpack_from('<II',raw,12);need(k==0x4e4f534a,'JSON missing');g=json.loads(raw[20:20+n]);sz,k=struct.unpack_from('<II',raw,20+n);need(k==0x004e4942 and 28+n+sz==len(raw),'BIN bounds');return g,raw[28+n:]
def bind_surface(raw,authored=AUTHORED):
 need(sha(raw)==PARENT,'Fresh original baseline differs');g,b=unpack(raw);before=copy.deepcopy(g)
 s=json.loads((authored/'surface.json').read_text());payload=(authored/'surface.bin').read_bytes()
 need(s['schema']=='w01_fine_wood_surface_append_v1'and s['parent_sha256']==PARENT and s['expected_glb_sha256']==EXPECTED,'Unexpected binding');need(sha(payload)==s['payload_sha256'],'Changed payload');need(len(b)==s['parent_binary_bytes'],'Changed prefix length')
 views=s['append_buffer_views'];acc=s['append_accessors'];need(len(views)==38 and len(acc)==32 and len(g['accessors'])==92 and len(g['bufferViews'])==110,'Unexpected append counts')
 image_views={s['images'][i]['bufferView']for i in (0,1,2,9,10,11)};chart_views={a['bufferView']for a in acc}
 need(image_views.isdisjoint(chart_views)and image_views|chart_views==set(range(110,148)),'Unowned append')
 need(all(a['type']in ('VEC2','VEC4','SCALAR')and a['componentType']in (5126,5125)for a in acc),'Only UV/tangent/index chart arrays allowed')
 for v in views:need(v['buffer']==0 and v['byteOffset']>=len(b)and v['byteOffset']+v['byteLength']<=len(b)+len(payload),'Append escapes payload')
 for vi in image_views:
  v=views[vi-110];start=v['byteOffset']-len(b);need(payload[start:start+8]==b'\\x89PNG\\r\\n\\x1a\\n','Non-PNG image')
 g['bufferViews'].extend(views);g['accessors'].extend(acc);data=b+payload
 need(len(s['meshes'])==len(before['meshes']),'Mesh count changed')
 for original,new in zip(before['meshes'],s['meshes']):
  p=original['primitives'][0];need({k:v for k,v in original.items()if k!='primitives'}=={k:v for k,v in new.items()if k!='primitives'},'Mesh metadata changed')
  if new==original:continue
  need(p['material']in (1,2,3)and len(new['primitives'])==2,'Only wood face ownership may split');indices=[]
  for q in new['primitives']:
   need(q['attributes']['POSITION']==p['attributes']['POSITION']and q['attributes']['NORMAL']==p['attributes']['NORMAL'],'Position/normal reference changed');need(q['material']in (p['material'],p['material']+5),'Changed face material family')
   need(set(q)-{'attributes','indices','material'}==set(p)-{'attributes','indices','material'},'Primitive shape changed')
   ai=q['indices'];need(92<=ai<124,'New project index required');a=g['accessors'][ai];v=g['bufferViews'][a['bufferView']];need(a['type']=='SCALAR'and a['componentType']==5125,'Index type');start=v['byteOffset']+a.get('byteOffset',0);indices+=struct.unpack_from('<'+'I'*a['count'],data,start)
  need(sorted(indices)==list(range(g['accessors'][p['attributes']['POSITION']]['count'])),'Missing/duplicated original rendered vertices')
 for i in (0,4,5):need(s['materials'][i]==before['materials'][i],'Paint/iron changed')
 for i in range(3,9):need(s['images'][i]==before['images'][i],'Paint/iron images changed')
 g['meshes']=s['meshes'];g['textures']=s['textures'];g['materials']=s['materials'];g['images']=s['images'];g['asset']['copyright']=s['asset_copyright'];g['extras']=s['extras'];g['buffers'][0]['byteLength']=len(data)
 for key in ('nodes','skins','animations','scene','scenes','samplers'):need(g.get(key)==before.get(key),'Protected '+key+' changed')
 head=json.dumps(g,separators=(',',':')).encode();head+=b' '*((-len(head))%4);out=struct.pack('<III',0x46546c67,2,28+len(head)+len(data))+struct.pack('<II',len(head),0x4e4f534a)+head+struct.pack('<II',len(data),0x004e4942)+data;need(sha(out)==EXPECTED,'Not exact reviewed material candidate');return out

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--parameters',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--verify',action='store_true');a=p.parse_args()
 with tempfile.TemporaryDirectory(prefix='w01-fine-wood-source-')as temp:
  subprocess.run([sys.executable,str(ROOT/'tools/transport/generate_parked_wagon.py'),'--parameters',str(a.parameters),'--output-dir',temp],check=True)
  raw=bind_surface((Path(temp)/'wagon-w01.glb').read_bytes())
 target=a.output_dir/'wagon-w01.glb'
 if a.verify:need(target.is_file()and target.read_bytes()==raw,'Stale/missing fine wood output')
 else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 print(json.dumps({'source_regenerated':True,'sha256':sha(raw),'verified':a.verify,'photographic_acceptance':False}))
if __name__=='__main__':main()
'''
write('tools/transport/generate_parked_wagon_fine_wood.py',producer);write(MODEL+'/wagon-w01.glb',cr);write(MODEL+'/ATTRIBUTION.txt',(CAND/'ATTRIBUTION.txt').read_bytes())
rel='data/transport/parked/placements.json';placement=(ROOT/rel).read_text();placement=placement.replace('transport/parked-wagon/wagon-w01.glb','transport/parked-wagon-fine-wood/wagon-w01.glb');placement=placement.replace('with individual boards, iron hardware and original procedural finish.','with individual boards and iron hardware. Modern CC0 Poly Haven fine_grained_wood pixels provide a reconstructed timber appearance; no historic species, coating or maker is established.');write(rel,placement)
license_note='\n\n## W01 fine-grained timber material increment (T-2793)\n\n`parked-wagon-fine-wood/` uses unchanged original project W01 geometry and project-authored UV/tangent/index charts (GPL-3.0-or-later). Side timber pixels derive from [Fine Grained Wood](https://polyhaven.com/a/fine_grained_wood), Rob Tuytel / Poly Haven, [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/); original paint, iron and cut-end pixels remain CC0. Native2K maps were rotated, cropped, reduced2x, narrow8pxperiodic edge blended, and albedo given bounded1.5linear exposure; GL normal vectors were correspondingly rotated and renormalized. This is a modern optical analogy and reconstructed brown finish, with no species/date/coating/maker/Chicago-specimen attestation. Photographic/world/budget acceptance remains open. Source map URLs, official hashes and derivation are in `assets/authored/transport/wagon_parked_fine_wood/SOURCE.json`.\n'
for rel in ('assets/LICENSES.md','renderers/web/transport/LICENSES.md'):write(rel,(ROOT/rel).read_text()+license_note)
pins={};patch=[]
for p in sorted(OVER.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(OVER).as_posix();original=ROOT/rel
 if original.exists():pins[rel]=sha(original.read_bytes())
 try:new=p.read_text();old=original.read_text()if original.exists()else''
 except UnicodeDecodeError:continue
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel if original.exists()else'/dev/null',tofile='b/'+rel))
(OUT/'UNAPPLIED-normal-intake.patch').write_text(''.join(patch));(OUT/'BASE-SOURCE-PINS.json').write_text(json.dumps(pins,indent=2)+'\n');(OUT/'README.md').write_text('HELD and UNAPPLIED. No app/queue/Git write. Root must review final native V4B images before intake. Overlay switches only W01 parked model; covered variants and original baseline producer stay unchanged. New producer regenerates original geometry then binds only portable GPL project charts and CC0 pixels; no cached GLB input or OldCart pixels. 8 actual app batches versus5 baseline;12,104triangles;6,291,168RGBA8+mips dimension estimate; app/device/world acceptance OPEN. Binary files are carried in overlay and not encoded by text patch. No runtime flag or settings flow added.\n');print(json.dumps({'prepared':str(OUT),'files':len(list(OVER.rglob('*'))),'no_app_write':True}))
