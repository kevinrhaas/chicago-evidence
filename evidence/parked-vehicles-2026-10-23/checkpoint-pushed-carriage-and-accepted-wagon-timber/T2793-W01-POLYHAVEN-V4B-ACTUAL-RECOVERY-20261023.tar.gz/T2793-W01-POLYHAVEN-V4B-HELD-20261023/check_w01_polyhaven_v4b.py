from pathlib import Path
import hashlib,json,struct,io
import numpy as np
from PIL import Image
OUT=Path('/workspace/shared/T2793-W01-POLYHAVEN-V4B-HELD-20261023');CHART=Path('/workspace/shared/T2793-W01-POLYHAVEN-V3B-HELD-20261023/wagon-w01.glb');BASE=Path('/tmp/chicago-covered-sag/chicago/4d/renderers/web/transport/parked-wagon/wagon-w01.glb')
def need(x,m):
 if not x:raise ValueError(m)
def unpack(p):
 r=p.read_bytes();n=struct.unpack_from('<I',r,12)[0];return r,json.loads(r[20:20+n]),r[28+n:]
def arr(g,b,i):
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];return np.frombuffer(b,dtype={5126:'<f4',5125:'<u4'}[a['componentType']],count=a['count']*{'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']],offset=v.get('byteOffset',0)+a.get('byteOffset',0))
def image(g,b,i):
 v=g['bufferViews'][g['images'][i]['bufferView']];return b[v['byteOffset']:v['byteOffset']+v['byteLength']]
r={'status':'RUNNING'}
try:
 raw,g,b=unpack(OUT/'wagon-w01.glb');cr,c,cb=unpack(CHART);br,base,bb=unpack(BASE);need(hashlib.sha256(raw).hexdigest()=='e1e5b4f1d7dfe6bf08cca21e8cfae2e88748a3f6e6c6959753334ae2b0c84dd8','Pin differs');need(b[:len(bb)]==bb,'Original geometry prefix differs');need(g['meshes']==c['meshes'],'Changed chart/face material ownership')
 for key in ['nodes','skins','animations','scene','scenes','samplers']:need(g.get(key)==base.get(key),'Changed '+key)
 for i in range(len(g['accessors'])):need(np.array_equal(arr(g,b,i),arr(c,cb,i)),'Changed actual P/N/UV/tangent/index array '+str(i))
 for i in (0,4,5):need(g['materials'][i]==base['materials'][i],'Paint/iron differs')
 for i in (1,2,3,6,7,8):
  a=json.loads(json.dumps(g['materials'][i]));z=json.loads(json.dumps(c['materials'][i]));a.pop('extras',None);z.pop('extras',None);a['pbrMetallicRoughness'].pop('baseColorFactor');z['pbrMetallicRoughness'].pop('baseColorFactor');need(a==z,'Unexpected wood/end material edit')
 for i in range(3,12):need(image(g,b,i)==image(c,cb,i),'Changed paint/iron/cutend image')
 pixels={}
 for i,role in enumerate(('color','normal','orm')):
  encoded=image(g,b,i);need(encoded==(OUT/'textures'/('polyhaven_timber_'+role+'.png')).read_bytes(),'Saved '+role+' PNG differs')
  pixels[role]=np.asarray(Image.open(io.BytesIO(encoded)).convert('RGB'))
  need(pixels[role].shape==(240,1024,3),'Map resolution')
  need(np.array_equal(pixels[role][0],pixels[role][-1])and np.array_equal(pixels[role][:,0],pixels[role][:,-1]),'Periodic '+role+' edges differ')
 need(not np.array_equal(pixels['color'][:,:512],pixels['color'][:,512:][:,::-1]),'Mirrored halves')
 need(float(np.abs(np.linalg.norm(pixels['normal'].astype(float)/127.5-1,axis=2)-1).max())<.005,'Normal length')
 need(np.all(pixels['orm'][:,:,0]==255)and np.all(pixels['orm'][:,:,2]==0),'ORM channel semantics')
 total=0
 for i in range(12):
  w,h=Image.open(io.BytesIO(image(g,b,i))).size
  while True:
   total+=w*h*4
   if(w,h)==(1,1):break
   w=max(1,w//2);h=max(1,h//2)
 need(total==6291168,'Unexpected memory dimensions')
 r.update(status='ACTUAL_V4B_SAVED_ARRAY_MATERIAL_READBACK_PASS_UNRENDERED',candidate_sha256=hashlib.sha256(raw).hexdigest(),all_actual_position_normal_UV_tangent_index_arrays_exact=True,original_geometry_pivots_greenpaint_iron_variants_exact=True,cutend_image_exact_color_only_matched=True,official_normal_rotated_downsampled_renormalized_no_albedo_height=True,unique_unmirrored_strip_and_periodic_edges=True,RGBA8_mips_dimension_estimate=total,referenced_materials=8,source_primitives=31,OldCart_pixels_not_copied=True)
except Exception as e:r.update(status='ACTUAL_V4B_READBACK_FAIL',error=repr(e));raise
finally:(OUT/'ACTUAL-INDEPENDENT-READBACK.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
