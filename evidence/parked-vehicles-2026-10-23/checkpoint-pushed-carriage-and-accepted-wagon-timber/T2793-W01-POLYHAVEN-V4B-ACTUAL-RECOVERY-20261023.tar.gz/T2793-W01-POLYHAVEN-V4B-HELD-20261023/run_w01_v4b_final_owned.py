from pathlib import Path
import hashlib,importlib.util,json,sys
assert sys.argv[1:]==['--root-browser-lane-released'],'Do not execute without explicit root browser-lane release'
p=Path('/workspace/shared/horse-sevket-native-preview-source-20261022/ownership_supervisor.py');assert hashlib.sha256(p.read_bytes()).hexdigest()=='778e5623d81821a48aeae5080a8cbff4ef57901570ceea9935fa98ecd9bd0ce5'
packet=Path('/workspace/shared/T2793-W01-POLYHAVEN-V4B-NATIVE-AB-HELD-20261023')
for name,pin in json.loads((packet/'PREPARED-FROZEN-MANIFEST.json').read_text()).items():assert hashlib.sha256((packet/name).read_bytes()).hexdigest()==pin,name
spec=importlib.util.spec_from_file_location('owned',p);owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
report=owned.run_owned(['node',str(packet/'capture.cjs'),'--lane-released'],Path('/workspace/shared/T2793-W01-V4B-NATIVE-AB-OWNED-FINAL-20261023'),whole_timeout=100,execution_timeout=95)
print(json.dumps(report,indent=2));raise SystemExit(report.get('exit_code',1))
