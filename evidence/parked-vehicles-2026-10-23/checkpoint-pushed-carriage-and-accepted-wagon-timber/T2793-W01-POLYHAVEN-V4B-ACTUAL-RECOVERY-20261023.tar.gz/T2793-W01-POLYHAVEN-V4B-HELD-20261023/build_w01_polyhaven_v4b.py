"""GPL-3.0-or-later project code/charts. One direct-tone CC0 material candidate.
Fresh original W01 geometry + original project UV/index charts + CC0 pixels.
No third-party geometry/GPL asset; no OldCart pixels, active or inactive.
"""
from pathlib import Path
import copy,hashlib,io,json,struct,time
import numpy as np
from PIL import Image
BASE=Path('/tmp/chicago-covered-sag/chicago/4d/renderers/web/transport/parked-wagon/wagon-w01.glb')
CHARTS=Path('/workspace/shared/T2793-W01-POLYHAVEN-V3B-HELD-20261023/wagon-w01.glb')
SOURCE=Path('/workspace/shared/T2793-POLYHAVEN-ONE-WOOD-SOURCE-REVIEW-20261023')
OUT=Path('/workspace/shared/T2793-W01-POLYHAVEN-V4B-HELD-20261023')
BASESHA='274e737b51872983df792d0b24de8e75de8631890a8d586a32d9c6f0066484fb';CHARTSHA='30af3da5d0ad40854b30ece08317f3b81ff0ceff76908062cb0fd01be24f37b7'
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def unpack(raw):
 need(struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw)),'GLB2 envelope');n=struct.unpack_from('<I',raw,12)[0];return json.loads(raw[20:20+n]),raw[28+n:]
def image(g,b,i):
 v=g['bufferViews'][g['images'][i]['bufferView']];return b[v['byteOffset']:v['byteOffset']+v['byteLength']]
def srgb(a):return np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055)
def linear(a):return np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
def box2(a):return a.reshape(240,2,1024,2,a.shape[2]).mean(axis=(1,3))
def normalize(a):return a/np.maximum(np.linalg.norm(a,axis=2,keepdims=True),1e-12)
def periodic_edges(a,width=8):
 # Match periodic border texels with a narrow convex blend, never reflect or
 # duplicate half of the source. Interior unique samples remain untouched.
 out=a.copy()
 for axis in (0,1):
  before=out.copy()
  for distance in range(width):
   low=[slice(None)]*3;high=[slice(None)]*3
   low[axis]=distance;high[axis]=-1-distance
   low=tuple(low);high=tuple(high)
   mean=(before[low]+before[high])*.5
   weight=1-distance/(width-1)
   out[low]=before[low]*(1-weight)+mean*weight
   out[high]=before[high]*(1-weight)+mean*weight
 return out
def png(a):
 f=io.BytesIO();Image.fromarray(a.astype('uint8')).save(f,format='PNG',compress_level=6);return f.getvalue()
def main():
 start=time.monotonic();need(not OUT.exists(),'One fresh candidate only');OUT.mkdir();(OUT/'textures').mkdir();r={'status':'RUNNING','browser_or_app_run':False,'source_family':'fine_grained_wood','style':'Unique unmirrored 2x-downsampled source strip; bounded direct exposure; narrow periodic seam blend'}
 try:
  base=BASE.read_bytes();chart=CHARTS.read_bytes();need(sha(base)==BASESHA and sha(chart)==CHARTSHA,'Frozen input changed');g,b=unpack(base);original=copy.deepcopy(g);cg,cb=unpack(chart);binary=bytearray(b)
  def append(data,target=None):
   binary.extend(b'\0'*((-len(binary))%4));vi=len(g['bufferViews']);v={'buffer':0,'byteOffset':len(binary),'byteLength':len(data)}
   if target:v['target']=target
   g['bufferViews'].append(v);binary.extend(data);return vi
  # Only new project-authored UV/TANGENT/index arrays, never copied source PNGs,
  # POSITION/NORMAL data, geometry or third-party model input.
  need(len(g['accessors'])==92 and len(cg['accessors'])==124,'Original chart range changed')
  for ai,a in enumerate(cg['accessors'][92:],92):
   old=cg['bufferViews'][a['bufferView']];need(a['type']in ('VEC2','VEC4','SCALAR')and a['componentType']in (5126,5125),'Unexpected chart payload');data=cb[old['byteOffset']:old['byteOffset']+old['byteLength']];new=copy.deepcopy(a);new['bufferView']=append(data,old.get('target'));g['accessors'].append(new)
  g['meshes']=copy.deepcopy(cg['meshes']);g['textures']=copy.deepcopy(cg['textures']);g['materials']=copy.deepcopy(cg['materials']);g['images'].extend(copy.deepcopy(cg['images'][9:]))
  files=json.loads((SOURCE/'fine_grained_wood-files.json').read_text());source_pins={};maps={}
  exposure=None
  for role,key,name in [('color','Diffuse','col'),('normal','nor_gl','nor_gl'),('roughness','Rough','rough')]:
   p=SOURCE/('fine_grained_wood_'+name+'_2k.png');raw=p.read_bytes();spec=files[key]['2k']['png'];need(len(raw)==spec['size']and hashlib.md5(raw).hexdigest()==spec['md5'],'Official source mismatch');a=np.asarray(Image.open(io.BytesIO(raw)).convert('RGB'));need(a.shape==(2048,2048,3),'Native source resolution');a=np.rot90(a)[784:1264,:].astype(np.float32)/255
   if role=='color':
    reduced=box2(linear(a));exposure=1.5 if float(reduced.max())*1.5<=1 else 1.
    colored=periodic_edges(reduced*exposure)
    need(float(colored.min())>=0 and float(colored.max())<=1,'Direct exposure must not clip source texels')
    maps['color']=np.rint(srgb(colored)*255).astype('uint8')
   elif role=='normal':
    normal=a*2-1
    # Image90CCW maps GL tangent +U to +V, and +V to -U.
    # Synthetic cardinal control makes this explicit instead of inheriting
    # V3/V4A's opposite XY rotation (those candidates were never applied).
    def rotate_normal(v):return np.stack([-v[:,:,1],v[:,:,0],v[:,:,2]],axis=2)
    cardinal=np.array([[[1.,0.,0.],[0.,1.,0.]]]);need(np.array_equal(rotate_normal(cardinal),np.array([[[0.,1.,0.],[-1.,0.,0.]]])),'GL normal cardinal orientation')
    normal=normalize(periodic_edges(normalize(box2(rotate_normal(normal)))))
    maps['normal']=np.rint((normal*.5+.5)*255).astype('uint8')
   else:
    rr=periodic_edges(box2(a))[:,:,0];maps['orm']=np.stack([np.full_like(rr,255),np.rint(rr*255),np.zeros_like(rr)],2).astype('uint8')
   source_pins[role]={'sha256':sha(raw),'official_md5':spec['md5'],'url':spec['url'],'bytes':len(raw)}
  need(sum(v['bytes'] for v in source_pins.values())<=40000000,'40MB source budget')
  receipts={}
  for name,ii in [('color',0),('normal',1),('orm',2)]:
   a=maps[name];need(a.shape==(240,1024,3),'Fixed memory footprint changed');data=png(a);(OUT/'textures'/('polyhaven_timber_'+name+'.png')).write_bytes(data);g['images'][ii]={'bufferView':append(data),'mimeType':'image/png'};receipts[name]={'sha256':sha(data),'bytes':len(data),'pixels':[1024,240]}
  for ii in (9,10,11):g['images'][ii]={'bufferView':append(image(cg,cb,ii)),'mimeType':'image/png'}
  # Retain the existing board brightness ordering with NEUTRAL factors; no
  # old tan tint/mean/std forced on the real dark-brown source albedo.
  luma=np.array([.2126,.7152,.0722]);old_luma={i:float(np.array(original['materials'][i]['pbrMetallicRoughness']['baseColorFactor'][:3])@luma)for i in (1,2,3)};top=max(old_luma.values());mean_color=linear(maps['color'].astype(float)/255).mean(axis=(0,1));cutmean=linear(np.asarray(Image.open(io.BytesIO(image(cg,cb,9))).convert('RGB')).astype(float)/255).mean(axis=(0,1));factors={}
  for i in (1,2,3):
   v=old_luma[i]/top;side=[v,v,v,1];end=[*np.minimum(1.,mean_color/cutmean*v).tolist(),1];g['materials'][i]['pbrMetallicRoughness']['baseColorFactor']=side;g['materials'][i+5]['pbrMetallicRoughness']['baseColorFactor']=end;factors[str(i)]={'side':side,'cut_end':end}
   g['materials'][i]['extras']={'scope':'Reconstructed dark brown timber finish; modern optical analogy, no species/date/coating/maker attestation','active_source':'Poly Haven fine_grained_wood by Rob Tuytel, CC0-1.0','changes':'Native crop/2x linear box reduction/90CCW, no reflection, eight-pixel periodic edge blend; bounded direct exposure and source roughness; neutral factors preserve only relative original board brightness','normal_scale':.35}
   g['materials'][i+5]['extras']={'scope':'Existing original CC0 cut-end pixels; material color matches actual modern source mean. Reconstructed finish, no identified wood species/coating/date.'}
  g['asset']['copyright']='Original project W01 geometry/UV/index charts and generator GPL-3.0-or-later. Active side timber adapted from Fine Grained Wood by Rob Tuytel / Poly Haven, https://polyhaven.com/a/fine_grained_wood , CC0-1.0 https://creativecommons.org/publicdomain/zero/1.0/ . Changes: native2K crop,2x box reduction,90CCW spatial/tangent-normal rotation with +U-to-+V mapping, no reflection, eight-pixel periodic edge blend; bounded direct exposure and source roughness; neutral board factors and color-matched original CC0 cut ends. Original paint/iron/cut-end pixels CC0-1.0. No third-party geometry, OldCart pixels, measured1835finish/species/date/coating/maker/Chicago specimen.'
  g['extras']['timber_surface_candidate']={'scope':'HELD material-only candidate; actual photographic/app/world acceptance OPEN','source_family':'fine_grained_wood','source_author':'Rob Tuytel','source_license':'CC0-1.0','native_input_pixels':[2048,2048],'rotated_crop':[0,784,2048,1264],'linear_box_reduction':2,'unique_output_pixels':[1024,240],'output_pixels':[1024,240],'periodic_edge_blend_pixels':8,'reflection':False,'linear_source_exposure':exposure,'GL_normal_rotation':'[-ny,nx,nz] for image90CCW','albedo_original_mean_std_matching':False,'normal_scale':.35,'normal_from_albedo':False,'finish':'Reconstructed brown finish; no attested1835species/coating/date/maker','original_geometry_sha256':BASESHA,'project_authored_chart_source_sha256':CHARTSHA,'project_authored_chart_license':'GPL-3.0-or-later original project work, no external GPL asset','OldCart_pixels_included':False}
  if'material_study'in g['extras']:g['extras']['material_study']['images']='CC0 Poly Haven direct-tone side timber plus original CC0 paint/iron/cut ends; geometry/charts project GPL; reconstructed finish, not attested period materials.'
  for key in ('nodes','skins','animations','scene','scenes','samplers'):need(g.get(key)==original.get(key),'Changed protected '+key)
  need(g['meshes']==cg['meshes'],'Existing oriented chart/primitive ownership changed');need(binary[:len(b)]==b,'Original binary geometry prefix changed')
  for i in (0,4,5):need(g['materials'][i]==original['materials'][i],'Paint/iron/original unused material changed')
  for ii in range(3,9):need(g['images'][ii]==original['images'][ii]and image(g,binary,ii)==image(original,b,ii),'Paint/iron image changed')
  for ii in (9,10,11):need(image(g,binary,ii)==image(cg,cb,ii),'Existing cut-end image changed')
  g['buffers'][0]['byteLength']=len(binary);binary.extend(b'\0'*((-len(binary))%4));g['buffers'][0]['byteLength']=len(binary);head=json.dumps(g,separators=(',',':')).encode();head+=b' '*((-len(head))%4);raw=struct.pack('<III',0x46546c67,2,28+len(head)+len(binary))+struct.pack('<II',len(head),0x4e4f534a)+head+struct.pack('<II',len(binary),0x004e4942)+binary;(OUT/'wagon-w01.glb').write_bytes(raw);(OUT/'ATTRIBUTION.txt').write_text(g['asset']['copyright']+'\n')
  cost=0
  for ii in range(12):
   w,h=Image.open(io.BytesIO(image(g,binary,ii))).size
   while True:
    cost+=w*h*4
    if(w,h)==(1,1):break
    w=max(1,w//2);h=max(1,h//2)
  r.update(status='ACTUAL_V4B_DIRECT_SOURCE_MATERIAL_PASS_UNRENDERED',candidate_sha256=sha(raw),candidate_bytes=len(raw),base_sha256=BASESHA,chart_source_sha256=CHARTSHA,original_geometry_prefix_exact=True,project_chart_arrays_exact=True,green_paint_iron_pivots_variants_exact=True,existing_cutend_images_exact=True,cutend_color_match_only=True,OldCart_pixels_included=False,material_factors=factors,source_pins=source_pins,maps=receipts,linear_source_albedo_mean=mean_color.tolist(),linear_source_albedo_std=float((linear(maps['color'].astype(float)/255)@luma).std()),direct_source_roughness_mean=float(maps['orm'][:,:,1].mean()/255),linear_exposure=exposure,source_unique_pixels=[1024,240],normal_orientation_cardinal_control=True,normal_length_max_error=float(np.abs(np.linalg.norm(maps['normal'].astype(float)/127.5-1,axis=2)-1).max()),normal_scale=.35,RGBA8_mips_dimension_estimate=cost,triangles=12104,primitives=31,referenced_materials=8,active_images=12,elapsed_seconds=time.monotonic()-start)
 except Exception as e:r.update(status='ACTUAL_V4B_BUILD_FAIL',error=repr(e),elapsed_seconds=time.monotonic()-start)
 finally:(OUT/'ACTUAL-RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k not in ('source_pins','maps','material_factors')},indent=2))
 return 0 if r['status']=='ACTUAL_V4B_DIRECT_SOURCE_MATERIAL_PASS_UNRENDERED'else 2
if __name__=='__main__':raise SystemExit(main())
