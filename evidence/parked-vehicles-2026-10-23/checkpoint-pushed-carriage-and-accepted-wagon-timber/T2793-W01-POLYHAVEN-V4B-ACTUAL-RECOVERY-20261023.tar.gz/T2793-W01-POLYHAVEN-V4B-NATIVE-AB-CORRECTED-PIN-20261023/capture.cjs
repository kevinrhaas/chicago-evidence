// Prepared only. Root must release the exclusive browser lane before invoking.
// Reuses the existing W01 static A/B fixture, four desktop images, no tuning loop.
const fs = require('node:fs'), http = require('node:http'), path = require('node:path');
const crypto = require('node:crypto'), assert = require('node:assert/strict');
const { chromium } = require('/workspace/shared/chicago-browser/node_modules/playwright');
assert.deepEqual(process.argv.slice(2), ['--lane-released'], 'Require explicit root browser-lane release');
const root = __dirname, out = path.join(root, 'actual');
const input = JSON.parse(fs.readFileSync(path.join(root, 'INPUTS.json')));
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
assert.equal(sha(fs.readFileSync(path.join(root, 'view.html'))), input.fixture_sha256);
for (const spec of Object.values(input.models)) {
 const data = fs.readFileSync(spec.path); assert.equal(data.length, spec.bytes); assert.equal(sha(data), spec.sha256);
}
fs.mkdirSync(out); // Fresh actual evidence only; a failed run is never overwritten.
const result = { status: 'RUNNING', scope: 'Four native W01 baseline/frozen-V4B static A/B images only; no app, photo, period, world or coarse-mip acceptance', started: new Date().toISOString(), inputs_sha256: sha(fs.readFileSync(path.join(root, 'INPUTS.json'))), views: [], errors: [], browserClosed: false, serverClosed: false };
const save = () => fs.writeFileSync(path.join(out, 'receipt.json'), JSON.stringify(result, null, 2) + '\n');
let server, browser, page, deadline, timedOut = false;
(async () => {
 try {
  const routes = { '/': path.join(root, 'view.html'), '/baseline.glb': input.models.baseline.path, '/candidate.glb': input.models.candidate.path };
  server = http.createServer((req, res) => {
   const name = new URL(req.url, 'http://localhost').pathname;
   if (name === '/favicon.ico') { res.writeHead(204); return res.end(); }
   let file = routes[name];
   if (!file && name.startsWith('/vendor/')) {
    file = path.resolve(input.vendor, name.slice(8));
    if (!file.startsWith(input.vendor + path.sep)) file = null;
   }
   if (!file || !fs.existsSync(file)) { res.writeHead(404); return res.end(); }
   res.writeHead(200, { 'Content-Type': file.endsWith('.js') ? 'text/javascript' : file.endsWith('.html') ? 'text/html' : 'model/gltf-binary', 'Cache-Control': 'no-store' });
   fs.createReadStream(file).pipe(res);
  });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  const origin = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, timeout: 15000, args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  // The root caller must additionally own a <=100s process-group cap. Closing
  // the owned browser at85s aborts pending capture waits; no unrelated PID kill.
  deadline = setTimeout(() => { timedOut = true; result.errors.push('85 second browser deadline'); save(); void browser?.close().catch(() => {}); }, 85000);
  page = await browser.newPage({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 });
  page.on('pageerror', error => result.errors.push(String(error)));
  page.on('console', msg => { if (msg.type() === 'error') result.errors.push(msg.text()); });
  page.on('requestfailed', req => result.errors.push(req.url() + ': ' + req.failure()?.errorText));
  page.on('response', res => { if (res.status() >= 400) result.errors.push(`HTTP ${res.status()} ${res.url()}`); });
  await page.route('**/*', route => {
   const url = route.request().url();
   if (url.startsWith(origin + '/') || url.startsWith('data:') || url.startsWith('blob:')) return route.continue();
   result.errors.push('Blocked remote request: ' + url); return route.abort();
  });
  await page.goto(origin, { waitUntil: 'load', timeout: 15000 });
  await page.waitForFunction(() => window.show, null, { timeout: 15000 });
  for (const shot of input.shots) {
   let baseline;
   for (const kind of ['baseline', 'candidate']) {
    const data = await page.evaluate(([kind, shot]) => window.show(kind, shot), [kind, shot]);
    assert.equal(data.sha, input.models[kind].sha256); assert.equal(data.glError, 0); assert(data.maxTextureSize >= 2576);
    if (baseline) for (const key of ['camera', 'target', 'cameraQuaternion', 'projection', 'lighting', 'commonBounds']) assert.deepEqual(data[key], baseline[key], 'Matched ' + key);
    else baseline = data;
    const file = `1280-${shot}-${kind}.png`;
    await page.screenshot({ path: path.join(out, file), timeout: 10000 });
    result.views.push({ ...data, file, image_sha256: sha(fs.readFileSync(path.join(out, file))), width: 1280, height: 800 }); save();
   }
  }
  await page.evaluate(() => window.closeStudy());
  assert.equal(result.views.length, 4); assert.deepEqual(result.errors, []); assert(!timedOut);
  result.status = 'ACTUAL_NATIVE_AB_FOUR_IMAGES_CAPTURED_UNREVIEWED';
 } catch (error) { result.status = timedOut ? 'ACTUAL_TIMEOUT_UNCOMPLETED' : 'ACTUAL_NATIVE_AB_FAIL'; result.errors.push(String(error.stack || error)); process.exitCode = 1; }
 finally {
  clearTimeout(deadline);
  if (browser) { try { await browser.close(); result.browserClosed = true; } catch (error) { result.errors.push('Owned browser close: ' + error); } }
  if (server) { await new Promise(resolve => server.close(resolve)); result.serverClosed = true; }
  result.finished = new Date().toISOString(); save();
 }
})();
