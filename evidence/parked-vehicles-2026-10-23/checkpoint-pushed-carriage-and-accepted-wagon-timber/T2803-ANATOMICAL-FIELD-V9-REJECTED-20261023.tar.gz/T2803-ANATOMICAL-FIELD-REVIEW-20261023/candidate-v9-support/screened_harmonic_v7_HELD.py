"""HELD counterfactual: source-surface screened weights, no ROI body clamps.

Only hoof contacts and actual upper-trunk/head/tail source anchors are hard.
Bone capsule targets are soft. Positive area/edge² conductance with lumped
triangle mass gives a physical screened-Poisson length scale. The scale is the
actual median reconstructed proximal-link length, not a trial fit to the gate.
No anatomical, deformation, serialization, gait or visual acceptance follows
from solving this field. Actual post-four-weight pose screens remain required.
"""
import numpy as np
import json,pathlib,hashlib
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import spsolve
from scipy.sparse.csgraph import dijkstra,connected_components
DECLARED={'version':'V9_HELD_COMPACT_ANATOMICAL_CAPSULE_SUPPORT','maximum_influences':4,'seam_position_quantization_m':1e-6,'maximum_seam_class_spread_m':2e-6,'hard_upper_trunk_y_m':1.14,'proximal_capsule_radius_m':.13,'lower_capsule_radius_m':.12,'distal_capsule_radius_m':.13,'screening_length':'median actual reconstructed proximal segment length','body_prior_length':'same actual proximal segment length','kernel':'C2 Wendland (1-r)^4*(4r+1), r<1; otherwise0','signed_x_or_z_ROI_hard_boundary':False,'nonhoof_bone_Dirichlet_handles':False,'physical_gradient_bound':'NOT guaranteed by smoothness; disclose edge weight jumps and require unchanged actual65pose edge/area/normal/ground/hoof/seam screens','original_gait_and_thresholds_unchanged':True}
def original_joint_ownership(source_weights):
 owned_strength=np.max(source_weights[:,2:6],axis=1)
 competing_strength=np.max(source_weights[:,[0,1]+list(range(6,26))],axis=1)
 return owned_strength>competing_strength,(owned_strength==competing_strength)&(owned_strength>0)
def capsule_support(points,a,b,radius):
 """C2 support: full inside half the declared radius, zero at its boundary.

 Radius is the existing reconstructed bone capsule's radius, not fitted to any
 posed witness. This bounds anatomical ownership, not physical strain.
 """
 delta=b-a;t=np.clip((points-a)@delta/(delta@delta),0,1)
 r=np.linalg.norm(points-a-t[:,None]*delta,axis=1)/radius
 u=np.clip(2*r-1,0,1)
 return 1-(6*u**5-15*u**4+10*u**3)
def build(rest,parts,controls,hoof_patch_ids):
 keys={};members=[];points=[];vc=[]
 for mi,ps in enumerate(rest):
  ids=[]
  for vi,p in enumerate(ps):
   key=tuple(np.rint(p/1e-6).astype(int))
   if key not in keys:keys[key]=len(points);points.append(p);members.append([])
   ci=keys[key];members[ci].append((mi,vi));ids.append(ci)
  vc.append(np.asarray(ids,dtype=int))
 points=np.asarray(points);N=len(points);spread=max(np.linalg.norm(rest[mi][vi]-points[ci])for ci,group in enumerate(members)for mi,vi in group);assert spread<=2e-6
 tri=np.concatenate([vc[mi][part[4]]for mi,part in enumerate(parts)]);tp=points[tri];area=np.linalg.norm(np.cross(tp[:,1]-tp[:,0],tp[:,2]-tp[:,0]),axis=1)/2;mass=np.zeros(N)
 for k in range(3):np.add.at(mass,tri[:,k],area/3)
 rawedge=np.concatenate([np.sort(tri[:,[a,b]],axis=1)for a,b in [(0,1),(1,2),(2,0)]]);areaedge=np.tile(area/3,3);valid=(rawedge[:,0]!=rawedge[:,1])&(areaedge>0);rawedge,areaedge=rawedge[valid],areaedge[valid];edges,inverse=np.unique(rawedge,axis=0,return_inverse=True);u,v=edges.T;length=np.linalg.norm(points[u]-points[v],axis=1);assert np.all(length>1e-8);conductance=np.zeros(len(edges));np.add.at(conductance,inverse,areaedge/(np.linalg.norm(points[rawedge[:,0]]-points[rawedge[:,1]],axis=1)**2));assert np.all(conductance>0)
 graph=coo_matrix((np.r_[conductance,conductance],(np.r_[u,v],np.r_[v,u])),shape=(N,N)).tocsr();lap=diags(np.asarray(graph.sum(1)).ravel())-graph;metric=coo_matrix((np.r_[length,length],(np.r_[u,v],np.r_[v,u])),shape=(N,N)).tocsr()
 baseline=np.zeros((N,26));original_weights=np.zeros((N,26))
 for ci,group in enumerate(members):
  mi,vi=group[0]
  for j,w in zip(parts[mi][2][vi],parts[mi][3][vi]):
   original_weights[ci,int(j)]+=w
   baseline[ci,int(j)if j<6 else 1]+=w
 baseline/=baseline.sum(1)[:,None]
 # A tiny incidental neck weight is not ownership of a chest vertex. Require
 # an original head/neck/tail JOINT to exceed every original body/limb joint.
 # Exact ties are disclosed as ambiguous and never create this hard anchor.
 original_weights/=original_weights.sum(1)[:,None]
 genuine_ownership,ownership_ties=original_joint_ownership(original_weights)
 legacy_any_headtail=baseline[:,2:6].sum(1)>1e-8
 # Preserve the exact independently proved isolated tail, never every hair
 # primitive/disconnected component. Its source influences are body/tail only.
 fixture_path=pathlib.Path(__file__).with_name('PROVED-TAIL-COMPONENT.json');tail_fixture=json.loads(fixture_path.read_text());tail_vertices=np.asarray(tail_fixture['exact_source_vertex_ids'],dtype=int);tail_classes=np.unique(vc[0][tail_vertices]);assert len(tail_vertices)==969 and len(tail_classes)==901
 _,components=connected_components(graph,directed=False);observed_component=np.flatnonzero(components==components[tail_classes[0]]);assert np.array_equal(observed_component,tail_classes),'Tail fixture must equal one complete actual source component'
 assert len(np.unique(tail_vertices))==len(tail_vertices) and np.array_equal(np.flatnonzero(np.isin(vc[0],tail_classes)),np.sort(tail_vertices))
 assert all(mi==0 for ci in tail_classes for mi,vi in members[ci]),'Proved component must remain in the actual hair primitive only'
 assert np.array_equal(points[tail_classes].min(0),np.asarray(tail_fixture['bounds_min_m']))and np.array_equal(points[tail_classes].max(0),np.asarray(tail_fixture['bounds_max_m']))
 assert [controls['nodes'][i]['name']for i in [1,4,5]]==tail_fixture['source_control_names']
 excluded=[i for i in range(26)if i not in [1,4,5]];assert np.count_nonzero(original_weights[np.ix_(tail_classes,excluded)])==0
 assert all(not np.intersect1d(tail_classes,vc[1][ids]).size for ids in hoof_patch_ids.values())
 tail_mask=np.zeros(N,dtype=bool);tail_mask[tail_classes]=True
 fixed=(points[:,1]>=DECLARED['hard_upper_trunk_y_m'])|genuine_ownership|(mass<=0)|tail_mask;trunk=(points[:,1]>=DECLARED['hard_upper_trunk_y_m'])&(baseline[:,1]>.999999);assert trunk.any()
 piv=np.asarray([r['rest_world_pivot_m']for r in controls['nodes']]);limbs=controls['limbs'];ell=float(np.median([np.linalg.norm(piv[row['joints'][1]]-piv[row['joints'][0]])for row in limbs.values()]));assert .1<ell<.6
 distance=dijkstra(metric,directed=False,indices=np.flatnonzero(trunk),min_only=True);unknown=np.flatnonzero(~fixed);assert np.isfinite(distance[unknown]).all(),'Disconnected unknown source component lacks actual trunk anchor'
 target=np.zeros((N,26));target[:,1]=np.exp(-(distance/ell)**2)
 def score(a,b,radius):
  delta=b-a;t=np.clip((points-a)@delta/(delta@delta),0,1);r=np.linalg.norm(points-a-t[:,None]*delta,axis=1)/radius;q=np.maximum(0,1-r);return q**4*(4*r+1)
 for label,row in limbs.items():
  a,b,c,d,e=row['joints']
  for joint,start,end,radius in [(a,a,b,.13),(b,b,c,.12),(e,c,e,.13)]:target[:,joint]+=score(piv[start],piv[end],radius)
 # Only explicit annotated rigid hoof patches override the source anchors.
 hoof={label:np.unique(vc[1][ids])for label,ids in hoof_patch_ids.items()}
 for label,classes in hoof.items():
  joint=limbs[label]['joints'][-1];fixed[classes]=True;baseline[classes]=0;baseline[classes,joint]=1
 unknown=np.flatnonzero(~fixed);known=np.flatnonzero(fixed);assert np.all(target[unknown].sum(1)>0);target[unknown]/=target[unknown].sum(1)[:,None]
 screen=mass/(ell*ell);assert np.all(screen[unknown]>0);matrix=(lap[unknown][:,unknown]+diags(screen[unknown])).tocsc();rhs=-(lap[unknown][:,known]@baseline[known])+screen[unknown,None]*target[unknown];solution=spsolve(matrix,rhs);residual=float(np.abs(matrix@solution-rhs).max());assert np.isfinite(solution).all()and residual<1e-8;assert solution.min()>=-1e-9 and solution.max()<=1+1e-9;assert np.abs(solution.sum(1)-1).max()<1e-8
 dense=baseline.copy();dense[unknown]=np.clip(solution,0,1);dense/=dense.sum(1)[:,None]
 # V8: remove only numerically co-moving redundant palette entries from UNKNOWN
 # classes before four-weight pruning. Protected original owners/upper trunk/
 # rigid hoof/tail classes remain unchanged. This equivalence is WALK-BOUND;
 # another head/tail clip must earn a fresh proof, never inherit this mapping.
 from actual_model import Model
 from walk_source import pose,PARAMETERS
 walk_path=pathlib.Path(__file__).with_name('walk_source.py')
 assert hashlib.sha256(walk_path.read_bytes()).hexdigest()=='86649a8d7baee024fa7afb172063e38d880932bc8f085673390f99cf09f2bd17'
 source_path=pathlib.Path('/workspace/shared/T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb')
 source=Model(source_path);assert hashlib.sha256(source.raw).hexdigest()=='03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36'
 bind=source.accessor(source.g['skins'][0]['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1)
 actual_pivots=np.asarray([source.world(i)[:3,3]for i in range(26)])
 hoof_min={label:float(rest[1][ids,1].min())for label,ids in hoof_patch_ids.items()}
 equivalence_max=0.;root_non_equivalence=0.
 for t in np.linspace(0,PARAMETERS['period_s'],65):
  world,_=pose(float(t),actual_pivots,controls['limbs'],hoof_min);affine=world@bind
  equivalence_max=max(equivalence_max,float(np.abs(affine[2:6]-affine[1]).max()))
  root_non_equivalence=max(root_non_equivalence,float(np.abs(affine[0]-affine[1]).max()))
 assert equivalence_max<1e-7 and root_non_equivalence>.01,'Co-motion proof failed; no weight remap permitted'
 unknown_headtail_mass=dense[unknown,2:6].sum(1)
 dense[unknown,1]+=unknown_headtail_mass;dense[unknown,2:6]=0
 assert np.abs(dense.sum(1)-1).max()<1e-8
 # V9: anatomical ownership may not diffuse beyond its declared capsule.
 # C2 masks apply only to existing UNKNOWN classes; exact source anchors,
 # rigid annotated hooves and the independently proved tail remain unchanged.
 # Return excluded mass to body rather than renormalizing remaining limbs,
 # which would manufacture stronger influence by another distant limb.
 support_removed=np.zeros(N);support_channels=[]
 protected_before=dense[known].copy()
 for label,row in limbs.items():
  a,b,c,d,e=row['joints']
  for joint,start,end,radius in [(a,a,b,.13),(b,b,c,.12),(e,c,e,.13)]:
   support=capsule_support(points,piv[start],piv[end],radius)
   removed_channel=dense[unknown,joint]*(1-support[unknown])
   dense[unknown,joint]-=removed_channel
   dense[unknown,1]+=removed_channel
   support_removed[unknown]+=removed_channel
   assert np.count_nonzero(dense[unknown[support[unknown]==0],joint])==0
   support_channels.append({'joint':joint,'start':start,'end':end,'radius_m':radius,'maximum_returned_mass':float(removed_channel.max())})
 assert np.array_equal(dense[known],protected_before)
 assert np.isfinite(dense).all() and dense.min()>=-1e-12
 assert np.abs(dense.sum(1)-1).max()<1e-8
 order=np.argsort(-dense,axis=1,kind='stable')[:,:4];w=np.take_along_axis(dense,order,axis=1);kept=w.sum(1);removed=1-kept;w/=kept[:,None];w=w.astype(np.float32);j=order.astype(np.uint16);pruned=np.zeros_like(dense);np.add.at(pruned,(np.arange(N)[:,None],j),w)
 for label,classes in hoof.items():assert np.all(np.where(j[classes]==limbs[label]['joints'][-1],w[classes],0).sum(1)==1)
 jumps=np.abs(pruned[u]-pruned[v]).sum(1);worst=int(np.argmax(jumps/length));arrays=[(j[x].astype(int),w[x].astype(float))for x in vc]
 # Preserve every original source slot/value exactly, including UV duplicates;
 # do not merely renormalize a representative class or repaint a tail.
 for mi in range(len(parts)):
  ids=np.flatnonzero(np.isin(vc[mi],tail_classes));arrays[mi][0][ids]=parts[mi][2][ids];arrays[mi][1][ids]=parts[mi][3][ids]
  assert np.array_equal(arrays[mi][0][ids],parts[mi][2][ids])and np.array_equal(arrays[mi][1][ids],parts[mi][3][ids])
 return arrays,{'status':'HELD candidate source; numerical solution is not skin or gait acceptance','method':DECLARED,'classes':N,'edges':len(edges),'physical_screening_length_m':ell,'hard_source_anchor_classes':len(known),'proved_tail_component_classes':len(tail_classes),'proved_tail_actual_vertices':len(tail_vertices),'exact_original_tail_joint_slots_and_weights_preserved':True,'tail_component_fixture_sha256':hashlib.sha256(fixture_path.read_bytes()).hexdigest(),'tail_original_limb_weight':0.0,'gradient_diagnostic_scope':'class field before exact per-vertex original tail restoration; final all65pose measurements use the exact returned arrays','legacy_any_headtail_classes':int(legacy_any_headtail.sum()),'genuine_original_joint_owner_classes':int(genuine_ownership.sum()),'tiny_or_nondominant_headtail_classes_released':int(np.count_nonzero(legacy_any_headtail&~genuine_ownership)),'ambiguous_exact_dominance_ties_not_pinned_as_headtail':int(ownership_ties.sum()),'headtail_anchor_semantics':'original head/neck/tail joint must exceed every original body/limb joint; ties disclosed, not guessed','unknown_classes':len(unknown),'co_moving_palette_reduction':{'joint_indices':[2,3,4,5],'destination_joint':1,'eligible_classes':'existing unknown classes only; all existing hard/source-owned/hoof/tail anchors preserved','maximum_frozen_walk_affine_difference':equivalence_max,'excluded_root0_affine_difference':root_non_equivalence,'maximum_redundant_mass_folded':float(unknown_headtail_mass.max()),'poses_verified':65,'scope':'exact frozen walk only; not independent head/tail articulation or clip blending'},'anatomical_support':{'method':'C2 smooth compact bone capsules; full inside radius/2, zero at radius; excluded mass returned to body','existing_declared_radii_m':[.13,.12,.13],'eligible_classes':'existing unknown classes only; protected anchors/hoof/tail exact','maximum_mass_returned_to_body':float(support_removed.max()),'changed_classes':int(np.count_nonzero(support_removed)),'channels':support_channels,'physical_strain_guarantee':False},'maximum_harmonic_residual_abs':residual,'maximum_class_spread_m':float(spread),'maximum_discarded_mass_before_4_weight_renormalization':float(removed.max()),'discarded_mass_p95':float(np.quantile(removed,.95)),'maximum_post_pruning_edge_weight_L1_jump':float(jumps.max()),'maximum_post_pruning_edge_weight_L1_per_m':float((jumps/length).max()),'worst_weight_gradient_edge_class_ids':edges[worst].tolist(),'gait_and_deformation_assertions_changed':False,'anatomical_or_visual_qualification':False}
