"""Four current-source date UI and 1904 smoke cells, explicitly root-released once; no retry."""
import argparse,base64,datetime,hashlib,json,pathlib,re,subprocess,time
REPO='kevinrhaas/chicago'
INTEGRATED_DEV='b6eb3e5fee325dc8c65380afa1f1d1b6c7985a59'
WORKFLOW='chicago-4d-smoke.yml';WORKFLOW_SHA='00ae307ad6cbeb556ddd5028668ee53a839393c619cc52ae5d0e8f39eb84ec52'
OUT=None
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 global OUT
 a=argparse.ArgumentParser();a.add_argument('--root-release',required=True,type=pathlib.Path);args=a.parse_args()
 release=json.loads(args.root_release.read_bytes())
 assert release.get('status')=='ROOT_RELEASED_PR1175_DATE34_FULL14_FOUR' and release.get('allow_dispatch') is True
 HEAD=release['source_head'];TREE=release['tree'];PARENTS=release['parents'];PR_SOURCE=HEAD
 assert all(re.fullmatch('[0-9a-f]{40}',x)for x in [HEAD,TREE,*PARENTS]) and len(PARENTS)==2
 assert release['integrated_dev']==INTEGRATED_DEV and INTEGRATED_DEV in PARENTS
 assert release['pr_source_head']==HEAD and release['workflow_sha256']==WORKFLOW_SHA and release['smoke_source_sha256']=='d5d0d2974e4d1dc5cb9977a05402c85a4f5f4460dcef5d5953deb79d3fb68e45'
 OUT=pathlib.Path('/workspace/shared/PR1175-DATE34-FULL14-'+HEAD[:10]+'-SMOKES')
 assert release.get('source_head')==HEAD and release.get('tree')==TREE and release.get('parents')==PARENTS
 assert release.get('dispatcher_sha256')==sha(pathlib.Path(__file__).read_bytes())
 branch=release['verification_ref'];assert branch.startswith('steward/pr1175-verify-')
 OUT.mkdir(exist_ok=False);deadline=time.monotonic()+180;number=0
 cells=[(v,s)for v in ['desktop','mobile']for s in ['3-4','14']]
 record={'repository':REPO,'pr':1175,'pr_source_head':PR_SOURCE,'verification_ref':branch,'source_head':HEAD,'source_integration_tree':TREE,'source_integration_parents':PARENTS,'integrated_dev':INTEGRATED_DEV,'root_release_sha256':sha(args.root_release.read_bytes()),'workflow_sha256':WORKFLOW_SHA,'smoke_source_sha256':'d5d0d2974e4d1dc5cb9977a05402c85a4f5f4460dcef5d5953deb79d3fb68e45','smoke_source_git_blob_sha1':'a30fa1feeb595b2e0091b0c8db0f09e308796edd','started':now(),'dispatches':[],'runs':[],'automatic_retry':False,'qualification_pass':False,'current_final_head_qualified':False,'scope':'Only desktop/mobile3-4 and full14 at actual released currentPR source after integratedb6. All priorfe98/248/8f/8fc results retain their actualsources/failures. Root separately owns currentnormalCI/focused/carryprojection/merge; neverwhole18PASS.'}
 def save():(OUT/'RECEIPT.json').write_text(json.dumps(record,indent=2)+'\n')
 def api(route,method='GET',body=None):
  nonlocal number
  assert time.monotonic()<deadline;number+=1;stem=OUT/f'{number:03d}'
  (stem.with_suffix('.request.json')).write_text(json.dumps({'at':now(),'route':route,'method':method,'body':body},indent=2)+'\n')
  cmd=['gh','api','--method',method,'repos/'+REPO+'/'+route]
  if body is not None:cmd+=['--input','-']
  r=subprocess.run(cmd,input=json.dumps(body).encode()if body is not None else None,capture_output=True,timeout=min(45,max(1,deadline-time.monotonic())))
  stem.with_suffix('.stdout').write_bytes(r.stdout);stem.with_suffix('.stderr').write_bytes(r.stderr)
  assert r.returncode==0,f'{method} failed/ambiguous: inspect {stem}; no retry'
  return json.loads(r.stdout)if r.stdout.strip()else None
 save()
 try:
  pr=api('pulls/1175');assert pr['state']=='open' and pr['head']['sha']==PR_SOURCE and pr['head']['ref']=='steward/1835-workwear-repair-20261021' and pr['head']['repo']['full_name']==REPO and pr['base']['ref']=='dev' and pr['auto_merge'] is None
  record['actual_PR_source_base_merge_at_dispatch']={k:pr[k]for k in ['head','base','merge_commit_sha']}
  commit=api('git/commits/'+HEAD);assert commit['tree']['sha']==TREE and [p['sha']for p in commit['parents']]==PARENTS
  assert api('git/ref/heads/'+branch)['object']['sha']==HEAD
  workflow=api('actions/workflows/'+WORKFLOW);assert workflow['id']==365585058 and workflow['path']=='.github/workflows/'+WORKFLOW and workflow['state']=='active'
  data=api('contents/.github/workflows/'+WORKFLOW+'?ref='+HEAD);assert sha(base64.b64decode(data['content']))==WORKFLOW_SHA
  smoke_source=api('contents/chicago/4d/tools/smoke_renderer.mjs?ref='+HEAD);assert smoke_source['sha']=='a30fa1feeb595b2e0091b0c8db0f09e308796edd'
  listing='actions/workflows/'+WORKFLOW+'/runs?branch='+branch+'&head_sha='+HEAD+'&per_page=100'
  before=api(listing);assert before['total_count']==len(before['workflow_runs'])==0,'Existing runs: never duplicate'
  for viewport,stage in cells:
   assert api('git/ref/heads/'+branch)['object']['sha']==HEAD
   row={'viewport':viewport,'stage':stage,'post_attempted':True,'post_succeeded':False,'at':now()};record['dispatches'].append(row);save()
   api('actions/workflows/'+WORKFLOW+'/dispatches','POST',{'ref':branch,'inputs':{'viewport':viewport,'stage':stage}});row['post_succeeded']=True;save()
  for trial in range(4):
   inventory=api(listing);record['runs']=[{k:r.get(k)for k in ['id','head_sha','head_branch','event','run_attempt','path','workflow_id','status','conclusion','created_at','html_url']}for r in inventory['workflow_runs']];save()
   if inventory['total_count']==len(record['runs'])==4:break
   if trial<3:time.sleep(5)
  assert inventory['total_count']==len(record['runs'])==4 and len({r['id']for r in record['runs']})==4,'Incomplete/extra discovery: no redispatch'
  assert all(r['head_sha']==HEAD and r['head_branch']==branch and r['event']=='workflow_dispatch' and r['run_attempt']==1 and r['path']=='.github/workflows/'+WORKFLOW and r['workflow_id']==365585058 for r in record['runs'])
  assert api('git/ref/heads/'+branch)['object']['sha']==HEAD
  record['dispatch_complete']=True
 except BaseException as error:record['error']=str(error);raise
 finally:record['ended']=now();record['api_requests']=number;save();print(json.dumps({'receipt':str(OUT/'RECEIPT.json'),'accepted':sum(x['post_succeeded']for x in record['dispatches']),'discovered':len(record['runs']),'complete':record.get('dispatch_complete',False),'error':record.get('error')}),flush=True)
if __name__=='__main__':main()
