# PR1213 carriage checkpoint — actual terminal 2026-10-23

Pushed source commit: 0be5e645e016a212bd04eeda58e893472650d3d0
Exact source tree: d6aff82fac67dfac64d8c1c483d53edff55e1d22
PR: https://github.com/kevinrhaas/chicago/pull/1213 (draft, open, base dev, auto_merge null)
Checkout: /tmp/chicago-covered-sag; branch steward/t2794-brougham-v17-20261022.

Actual normal fullpreflight PASS at 00:48:25.945 UTC: 1049 steps, 381 self-tests, 696.251 s. Raw BASE and shared origin/dev stayed 824957fe47dd70fad729c3b117cb18b695d54b0b; exact staged tree, no unstaged/unmerged changes enforced at terminal. Complete three global preflight logs copied immediately. Available strict readers checked separately with required-reader flag. Full preflight ran once. A Python owner-wrapper parse refusal occurred before launch; raw record retained.

Actual committed-HEAD changelog, ticket-ID and whitespace checks PASS. Initial sandbox subprocess EPERM retained separately, then normal required-subprocess access passed. Ordinary Git push verified remote exact commit. Postcommit normal publish PASS45.298s and mirror PASS1.119s, terminal00:50:50.640 UTC; source clean. All7 original scene rows and13 original transport GLB blobs/hashes preserved. No source edits after commit. No browser launched by this owner.

Heavy lane was released to root at actual postpublish terminal. Wagon material agent notified to wait for root coordination. Parent owns PR1213 lap lease and canonical ticket updates; this child did not edit tickets or release the lease.

REST PR body updated and exact draft/head/base/open/auto_merge guards passed. Observed latest DEV at body update: b6eb3e5fee325dc8c65380afa1f1d1b6c7985a59, not integrated. Source includes only DEV824957fe; actual current integration and normal desktop/mobile world/performance/photo qualification remain pending. Original native and mobile-observed failures, and bounded270s world failures remain failures. Do not merge or close T-2794 based on this checkpoint.

Related source/visual recovery:
- T2794-V17-MID-FETCH-PARSE-ACTUAL-APP-STAGING-20261023.zip SHA256 b158a626e3c701c9c9a42ead7125e0b344ede8b703884eceb6597f904046ec1d (23-file patch + records; previousHEAD3289b16).
- T2794-V17-NATIVE24-MOBILE-FETCH-PARSE-ACTUAL-PASS-20261023.zip SHA256 127d3082fff6f97054a415e8731d2e0a542aed1e1728434911e427ed99fdbd11 (repaired-source four-frame native mobile PASS7.376s; not whole-world/photo acceptance).
- T2794-V17-NEAR-MID-NATIVE24-ACTUAL-FAIL-PARTIAL-20261023.zip SHA256 ee02953e4b41a8f1a69aa402e2e8bb85aa299c6416a133a1d0f560e86a1f2889.
- T2794-V17-NATIVE24-MOBILE-OBSERVED-ACTUAL-FAIL-20261023.zip SHA256 4d9a0ef78e2c6996309752e4219328080dcfa57a6d79e6721f91fb1b33167a06.
