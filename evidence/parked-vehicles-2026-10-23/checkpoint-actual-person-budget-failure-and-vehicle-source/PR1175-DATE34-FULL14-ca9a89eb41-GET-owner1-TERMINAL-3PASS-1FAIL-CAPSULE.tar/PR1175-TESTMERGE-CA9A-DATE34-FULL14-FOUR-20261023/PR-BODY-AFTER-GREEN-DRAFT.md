Adds a reconstructed standing resident beside the Wolf Point wagons using the repaired Bardwell & Otis portable model. Connected waistcoat shoulders, grounded shoes and identity cards distinguish reconstructed appearance and placement from the historically modelled firm.

Canonical authoring/export remains source `96c4da4b` and successful run `39736567239`. The eight Bardwell raw/web GLBs, placement, person data and human runtime are unchanged by the final test repairs and incoming DEV folds. Photographic finishing, complete tailoring, other people/eras, walking, drivers and riders remain open under T-1789.

Current reviewable source is `4766644295b5668084130fed80c6a18c9f0e6a04`, tree `c9d944caaca53cce404e8706e0f92534fd8e52a3`, parents `64b126d52b49cb3576c9921b82bd2a7cf2cef802` and `58fd2216a9312295cefbcc08c301852db09ea199`. Its full local preflight passed 1,048 checks and 381 deliberate self-tests, followed by committed-HEAD checks and postcommit publication/site parity. Actual preflight duration was 698.243 seconds, exceeding the nominal 600-second target; this observation is retained.

Fresh combined-tree qualification uses immutable GitHub test merge `ca9a89eb4108d09ff0a8f1941f5b7f2294cc0097`, tree `967213de77a9ca54ebadfbd2d165b6245474170d`, parents DEV `6c3603ff3019b8600a8945433f9196f4d861fd2d` and source `4766644295b5668084130fed80c6a18c9f0e6a04`:

- Actual normal gate, human and moving-frame workflows passed on that exact test merge/tree. The push report passed on exact source 476/tree c9d. Required steps, checkout commits and raw logs were checked.
- Fresh published desktop/mobile stages 3–4 and full 14: PENDING_FINAL_ACTUAL_TERMINALS. Exactly four requests were sent once, with no retries. No smoke assertion, camera, budget, ground or gait threshold was weakened.

The fresh mapped scopes cover incoming building-date wording, sources/catalog changes, eight house summaries, the Glessner liberty-note expansion and actual Ames 1904 geometry (+543 native triangles/+1 material). Current published source index contains 412 entries. The original source smoke, including all three assertion repairs and the inherited Hogan wording, retains full SHA256 `d5d0d2974e4d1dc5cb9977a05402c85a4f5f4460dcef5d5953deb79d3fb68e45`.

Earlier evidence carries only through exact unchanged person/main/scene/runtime pins. Repaired immutable 248 stages 1–2 passed 194/0 in each viewport and stages 9–12 passed 69/0 in each viewport. Original fe98 eighteen-cell matrix remains 12 PASS/6 FAIL, overall FAIL; its desktop 13 result remains 160/0 at that source. Earlier focused desktop timeouts remain failures, and separate mobile 20/0 and returning-profile 16/0 observations remain narrow evidence. Earlier 14 results do not substitute for the fresh current 14 cells. No whole-current-head eighteen-cell PASS is claimed.

DEV only, ordinary head-pinned merge after all applicable current checks pass and the reviewed base remains current. Other wagon/horse proposals and their evidence are outside this PR. Broad T-1789 photographic acceptance remains open. Source checkpoints and recovery evidence are saved in the tickets repository and external qualification capsules.
