import subprocess,json,pathlib,datetime
D=pathlib.Path(__file__).resolve().parent;r=json.loads((D/'ROOT-RELEASE.json').read_bytes());n=0
def api(route,method='GET',body=None,missing=False):
 global n
 n+=1;p=D/f'REF-{n:02d}';cmd=['gh','api','--method',method,'repos/kevinrhaas/chicago/'+route]
 if body is not None:cmd+=['--input','-']
 v=subprocess.run(cmd,input=json.dumps(body).encode()if body is not None else None,capture_output=True,timeout=45);p.with_suffix('.stdout').write_bytes(v.stdout);p.with_suffix('.stderr').write_bytes(v.stderr)
 (p.with_suffix('.request.json')).write_text(json.dumps({'route':route,'method':method,'body':body,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
 if missing:
  assert v.returncode!=0 and json.loads(v.stdout)['status']=='404','Ref not demonstrably absent; do not create or overwrite'
  return
 assert v.returncode==0,v.stderr.decode();return json.loads(v.stdout)
assert api('git/ref/heads/lap/pr-1175')['object']['sha']=='c8f78d53fc96257e88a8f43f0d54d83c1e684ea6'
assert api('git/ref/heads/dev')['object']['sha']==r['integrated_dev']
p=api('pulls/1175');assert p['state']=='open' and p['head']['sha']==r['pr_source_head'] and p['mergeable']is True and p['merge_commit_sha']==r['source_head'] and p['auto_merge']is None
api('git/ref/heads/'+r['verification_ref'],missing=True)
v=api('git/refs','POST',{'ref':'refs/heads/'+r['verification_ref'],'sha':r['source_head']});assert v['object']['sha']==r['source_head']
assert api('git/ref/heads/'+r['verification_ref'])['object']['sha']==r['source_head']
(D/'REF-CREATED.json').write_text(json.dumps({'ref':r['verification_ref'],'head':r['source_head'],'created_once':True,'overwrites':0},indent=2)+'\n')
print('Guarded immutable verification ref created once')
