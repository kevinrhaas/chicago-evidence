"""HELD: one root-released bounded CPU-only constructor/hull/support unit."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
D=Path(__file__).parent
assert sys.argv[1:]==['--root-released-one'],'One explicit source-only unit'
r=json.loads((D/'ACTUAL-ROOT-SOURCE-CHECK-RELEASE.json').read_text());assert r['released']is True
assert r['maximumInnerMS']==25000
s=Path('/workspace/shared/horse-sevket-native-preview-source-20261022/ownership_supervisor.py')
assert hashlib.sha256(s.read_bytes()).hexdigest()=='778e5623d81821a48aeae5080a8cbff4ef57901570ceea9935fa98ecd9bd0ce5'
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
if hasattr(os,'sched_getaffinity'):os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
spec=importlib.util.spec_from_file_location('owned',s);owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
result=owned.run_owned(['nice','-n','19','node','--max-old-space-size=1536',str(D/'check_actual_source.mjs')],D/'OWNED-ONE',whole_timeout=35,execution_timeout=30)
print(json.dumps(result,indent=2));raise SystemExit(result.get('exit_code',1))
