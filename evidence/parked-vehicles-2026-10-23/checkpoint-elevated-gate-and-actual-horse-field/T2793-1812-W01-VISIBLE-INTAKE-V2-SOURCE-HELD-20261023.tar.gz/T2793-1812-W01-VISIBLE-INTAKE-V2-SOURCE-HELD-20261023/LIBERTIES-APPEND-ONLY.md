

### L-1812-utility-wagon-2793 — One reconstructed empty utility wagon near the first fort

**Decision:** A single empty, unhitched1812 utility wagon reuses exact accepted fine-wood W01 bytes, GPL-3.0-or-later project geometry/charts and CC0 original/Rob Tuytel Poly Haven image maps. Local presence context is retrospective Wau-Bun1856 pp210/221 (`kinzie_waubun_1856`); stable context is Whistler1808 (`whistler_1808_fort_dearborn_draught`). Muller1768 (`muller_1768_treatise_artillery`) supports a pre1812 wooden-wheel/pole/forecarriage construction family, not United States adoption or this body's exact design. No newly manufactured geometry or historical maker badge is introduced.

**What is invented:** This individual, box dimensions3.05×1.07×.55m, wheel diameters1.07/1.37m, exact hardware, brown/green finish and planned E1075.5,N144/bearing0 stop are reconstructed. The stable is a location context, not vehicle ownership. The proposal has no cargo, cover, horse, driver, passengers, boarding, traffic or evacuation action; no person is created. It is not a Dearborn, Conestoga, Studebaker or exact military-pattern replica.

**Qualification boundary:** The proposed intake must pass actual support and world checks before application. All four wheels and every articulated tongue timber/iron vertex need the same bounded exact drawn1812 natural-ground provider; structure, flora, fence, water, approach, neighboring horse proposal and ordinary desktop/mobile world checks remain. No terrain numerical or browser qualification is recorded here. This candidate does not change current1835/1904 stands or the1812 scene's event/review disclosures and release state.

**How to resolve:** Qualify an actual separate stand without moving existing objects or weakening ground/budget/camera guards; retain uncertain form/colors as reconstruction unless stronger source evidence is found.
**Ticket:** T-2793.
**Recorded:** 2026-10-23.
