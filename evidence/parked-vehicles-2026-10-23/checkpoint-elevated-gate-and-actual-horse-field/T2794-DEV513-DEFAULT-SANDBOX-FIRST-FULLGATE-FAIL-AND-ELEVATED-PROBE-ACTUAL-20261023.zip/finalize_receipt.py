from pathlib import Path
import subprocess,json,hashlib,datetime,os
R=Path('/tmp/chicago-covered-sag/chicago/4d');O=Path(__file__).resolve().parent
BASE='5135fb7674eea8cf5b140a7cf0c8bc208b0b1f4e';TREE='fa427eb201de4bad4b7265313fcc5a422f440ea4'
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
post=json.loads((O/'POSTCOMMIT-TERMINAL.json').read_text());push=json.loads((O/'COMMIT-PUSH-TERMINAL.json').read_text());HEAD=push['head']
assert post['status']=='PASS' and post['clean'] and post['actual_head']==HEAD and post['actual_tree']==TREE
assert git('rev-parse','HEAD')==HEAD and git('rev-parse','HEAD^{tree}')==TREE and not git('status','--porcelain')
assert git('ls-remote','origin','refs/heads/'+push['branch']).split()[0]==HEAD
prior=json.loads(Path('/workspace/shared/T2794-W01-MID11706-CLOTH-DEV575-FULLGATE-COMMIT-ACTUAL-20261023/FINAL-COMMITTED-SOURCE-PUBLISHED-PINS.json').read_text())
pairs=[]
for item in prior['pairs']:
 s=Path(item['source']);p=Path(item['published']);exact=s.read_bytes()==p.read_bytes()
 row={'source':str(s),'published':str(p),'source_sha256':sha(s),'published_sha256':sha(p),'exact_bytes':exact}
 if not exact:
  assert str(s).endswith('/data/sidecars/1904/index.json')
  src=json.loads(s.read_text());pub=json.loads(p.read_text());boot=pub.pop('boot');assert src==pub and boot=={'shared':'sidecars/1904/boot/shared.json','dir':'sidecars/1904/boot/','per_part':50}
  row.update(exact_source_object_with_only_supported_boot_augmentation=True,normal_publisher='tools/publish.sh -> tools/pack_boot_sidecars.mjs',boot=boot)
 pairs.append(row)
# Explicit newer incoming UI and Ames publication pins.
extra=[('renderers/web/js/apps/inspect-view.js','walk/js/apps/inspect-view.js'),('renderers/web/js/apps/people-view.js','walk/js/apps/people-view.js'),('renderers/web/js/navigator.js','walk/js/navigator.js'),('renderers/web/js/researcher.js','walk/js/researcher.js'),('renderers/web/css/inspect.css','walk/css/inspect.css'),('assets/web/coleman_ames_house_1811_prairie__as_mapped_1904.glb','data/gltf/coleman_ames_house_1811_prairie__as_mapped_1904.glb')]
site=R/'../../site/4d'
for src,pub in extra:
 s=R/src;p=site/pub;assert s.read_bytes()==p.read_bytes();pairs.append({'source':str(s),'published':str(p),'source_sha256':sha(s),'published_sha256':sha(p),'exact_bytes':True,'reviewed_incoming513':True})
final={'head':HEAD,'tree':TREE,'build':post['build'],'pairs':pairs,'raw_byte_identical_pairs':sum(x['exact_bytes'] for x in pairs),'exact_supported_boot_augmented_index_pairs':sum(not x['exact_bytes'] for x in pairs),'normal_mirror_check_passed':True,'world_or_browser_qualification_claimed':False}
(O/'FINAL-COMMITTED-SOURCE-PUBLISHED-PINS.json').write_text(json.dumps(final,indent=2)+'\n')
paths=git('diff','--name-only',BASE,HEAD,'--','.').splitlines();files=[]
for p in paths:
 rel=p.removeprefix('chicago/4d/');src=R/rel;dst=O/'actual-source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes());files.append({'path':p,'sha256':sha(src),'bytes':src.stat().st_size,'git_blob':git('rev-parse',HEAD+':'+p),'file_mode':oct(src.stat().st_mode&0o777)})
(O/'COMPLETE-PR-DIFF-SOURCE-INVENTORY.json').write_text(json.dumps({'head':HEAD,'base':BASE,'tree':TREE,'all_changed_PR_paths_saved':True,'paths':files},indent=2)+'\n')
processes=subprocess.check_output(['ps','-eo','pid,ppid,comm,args'],text=True);(O/'POSTPUB-PROCESS-SNAPSHOT.txt').write_text(processes)
receipt={'status':'PASS','heavy_lane':'CLOSED','terminal':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':HEAD,'tree':TREE,'parents':push['parents'],'remote_head':HEAD,'branch':push['branch'],'clean':True,'source_path_count':len(files),'own_children_reaped':True,'browser_started_by_owner':False,'origin_dev_frozen':git('rev-parse','origin/dev'),'build':post['build'],'gate_terminal':str(O/'TERMINAL.json'),'gate_terminal_sha256':sha(O/'TERMINAL.json'),'push_terminal':str(O/'COMMIT-PUSH-TERMINAL.json'),'push_terminal_sha256':sha(O/'COMMIT-PUSH-TERMINAL.json'),'postpub_terminal':str(O/'POSTCOMMIT-TERMINAL.json'),'postpub_terminal_sha256':sha(O/'POSTCOMMIT-TERMINAL.json'),'source_published_pins':str(O/'FINAL-COMMITTED-SOURCE-PUBLISHED-PINS.json'),'source_published_pins_sha256':sha(O/'FINAL-COMMITTED-SOURCE-PUBLISHED-PINS.json'),'draft':True,'normal_CI_and_current_world_photo_occupied_acceptance':'PENDING','preserved_failure_history':['actual new-runtime CI39906632536 failed original legacy popup raw HTML pins; fixed via independently reproduced exact upstream513 baseline, all original assertions retained','prior missing explicit W01 license paths first gate FAIL; exact3 registration fix and corrected gate PASS','optional Full culler A/B overallFAIL4ERR_ABORTED after oneRGBAequalcell; other2notrun, flagOFF','historical original native8/mobile failures retained in prior source capsules; no claim they passed']}
(O/'HEAVY-CLOSED-PUSHED-PUBLISHED-TERMINAL.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
