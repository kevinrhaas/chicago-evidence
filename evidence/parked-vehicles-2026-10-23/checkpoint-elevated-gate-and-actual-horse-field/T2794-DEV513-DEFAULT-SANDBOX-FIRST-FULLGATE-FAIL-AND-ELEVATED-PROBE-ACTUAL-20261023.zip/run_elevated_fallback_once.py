from pathlib import Path
import subprocess,os,json,time,datetime,hashlib,signal
O=Path(__file__).resolve().parent;R=Path('/tmp/chicago-covered-sag/chicago/4d');assert (O/'TERMINAL.json').exists();assert not (O/'ELEVATED-FALLBACK-START.json').exists()
S=R/'tools/test_fallback_summary.mjs';before=hashlib.sha256(S.read_bytes()).hexdigest();env=os.environ.copy();env['PATH']='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:'+env['PATH']
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:env[k]='1'
start={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':['node','tools/test_fallback_summary.mjs'],'source_sha256':before,'unmodified':True,'execution_mode':'require_escalated','timeout_seconds':30,'reader_path':env['PATH'].split(':')[:2]};(O/'ELEVATED-FALLBACK-START.json').write_text(json.dumps(start,indent=2)+'\n');print(json.dumps(start),flush=True)
t=time.monotonic();timeout=False
with (O/'ELEVATED-FALLBACK-ACTUAL.log').open('wb') as f:
 p=subprocess.Popen(['node','tools/test_fallback_summary.mjs'],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:p.wait(timeout=30)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5)
terminal={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pass':p.returncode==0 and not timeout,'exit_code':p.returncode,'timeout':timeout,'seconds':time.monotonic()-t,'source_sha256_before':before,'source_sha256_after':hashlib.sha256(S.read_bytes()).hexdigest(),'node_reaped':True,'log_sha256':hashlib.sha256((O/'ELEVATED-FALLBACK-ACTUAL.log').read_bytes()).hexdigest()};assert terminal['source_sha256_before']==terminal['source_sha256_after'];(O/'ELEVATED-FALLBACK-TERMINAL.json').write_text(json.dumps(terminal,indent=2)+'\n');print(json.dumps(terminal),flush=True);print((O/'ELEVATED-FALLBACK-ACTUAL.log').read_text()[-2000:]);raise SystemExit(0 if terminal['pass'] else 1)
