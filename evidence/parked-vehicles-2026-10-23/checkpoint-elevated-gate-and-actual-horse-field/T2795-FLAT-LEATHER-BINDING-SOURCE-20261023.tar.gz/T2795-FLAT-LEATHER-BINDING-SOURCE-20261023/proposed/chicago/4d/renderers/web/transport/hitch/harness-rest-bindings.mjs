// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit rest-delta adapter. No legacy89b sockets or inferred Bone.* anatomy.
const need = (ok, why) => { if (!ok) throw Error(why); };
const matrixOk = m => m?.isMatrix4 && m.elements.every(Number.isFinite) && Math.abs(m.determinant()) > 1e-12;
const rigid = m => {
  const e = m.elements;
  const dot = (a, b) => e[a] * e[b] + e[a + 1] * e[b + 1] + e[a + 2] * e[b + 2];
  return [0, 4, 8].every(a => Math.abs(dot(a, a) - 1) < 1e-4)
    && Math.abs(dot(0, 4)) < 1e-4 && Math.abs(dot(0, 8)) < 1e-4
    && Math.abs(dot(4, 8)) < 1e-4 && Math.abs(m.determinant() - 1) < 1e-4;
};

/** Technical fixture acquisition only: hash and parse THE SAME buffer.
 * Nothing mounts, animates, selects a human, changes a rig, or activates a scene.
 */
export async function parsePinnedHarnessHost({ bytes, expectedSha256, loader, resourceBase = '' }) {
  need(bytes instanceof ArrayBuffer && /^[0-9a-f]{64}$/.test(expectedSha256), 'Pinned actual host bytes required');
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  const sha = [...new Uint8Array(digest)].map(v => v.toString(16).padStart(2, '0')).join('');
  need(sha === expectedSha256, 'Horse bytes differ from reviewed harness host');
  const gltf = await loader.parseAsync(bytes, resourceBase);
  return { gltf, verifiedSha256: sha, sameBufferParsed: true };
}

/** Call once BEFORE any Mixer action, on an owned rest-pose technical host.
 * Each canonical rest point is an explicitly fitted GEOMETRIC attachment datum;
 * its carrier is an exact glTF node index, not a claimed anatomical socket.
 */
export async function createHarnessRestBindings(THREE, { host, calibration, outputRoot }) {
  need(host?.sameBufferParsed && host.verifiedSha256 === calibration?.host_sha256,
    'Exact pinned host/calibration pair required');
  need(calibration.status === 'root_reviewed_rest_anchor_candidate' && calibration.fit_accepted === false,
    'Explicit reviewed candidate, never an invented accepted fitting');
  need(/^[0-9a-f]{64}$/.test(calibration.host_fitting_receipt_sha256 ?? ''),
    'Actual source-fitted anchor receipt hash required');
  need(calibration.units === 'metres' && calibration.frame === '+Yup +Zforward +Xleft', 'Canonical rest frame required');
  need(Array.isArray(calibration.anchors) && calibration.anchors.length > 0 && outputRoot,
    'Actual fitted anchor table and explicit output root required');
  const ids = new Set(), rows = [];
  host.gltf.scene.updateMatrixWorld(true);
  for (const a of calibration.anchors) {
    need(typeof a.id === 'string' && !ids.has(a.id), 'Unique anchor id required'); ids.add(a.id);
    need(Number.isInteger(a.gltf_node_index) && a.gltf_node_index >= 0,
      'Explicit actual glTF carrier node index required');
    need(Array.isArray(a.canonical_rest_point_m) && a.canonical_rest_point_m.length === 3
      && a.canonical_rest_point_m.every(Number.isFinite), 'Actual source-fitted canonical point required');
    const carrier = await host.gltf.parser.getDependency('node', a.gltf_node_index);
    need(carrier && matrixOk(carrier.matrixWorld), 'Carrier rest matrix missing');
    let inActiveScene = false;
    host.gltf.scene.traverse(node => { if (node === carrier) inActiveScene = true; });
    need(inActiveScene, 'Carrier must be the actual loaded active-scene node');
    const restWorld = carrier.matrixWorld.clone();
    const local = new THREE.Vector3().fromArray(a.canonical_rest_point_m)
      .applyMatrix4(host.gltf.scene.matrixWorld).applyMatrix4(restWorld.clone().invert());
    rows.push({ id: a.id, carrier, restInverse: restWorld.invert(), local });
  }
  const table = new Map(rows.map(r => [r.id, r]));
  const inverseOutput = new THREE.Matrix4(), delta = new THREE.Matrix4();
  return { anchorPoint(id, out) {
    const row = table.get(id); need(row, 'Unknown fitted anchor ' + id);
    // Caller updates host/owned wrapper matrices after animation and before link update.
    need(matrixOk(row.carrier.matrixWorld) && matrixOk(outputRoot.matrixWorld), 'Finite live attachment frames required');
    need(rigid(outputRoot.matrixWorld), 'Harness output root must keep metre scale without shear');
    delta.multiplyMatrices(row.carrier.matrixWorld, row.restInverse);
    need(rigid(delta), 'Rig/normalization changed size or sheared after calibration');
    inverseOutput.copy(outputRoot.matrixWorld).invert();
    return out.copy(row.local).applyMatrix4(row.carrier.matrixWorld).applyMatrix4(inverseOutput);
  }, status: 'geometric_rest_candidate_only', collisionAccepted: false, liveActivationAllowed: false };
}
