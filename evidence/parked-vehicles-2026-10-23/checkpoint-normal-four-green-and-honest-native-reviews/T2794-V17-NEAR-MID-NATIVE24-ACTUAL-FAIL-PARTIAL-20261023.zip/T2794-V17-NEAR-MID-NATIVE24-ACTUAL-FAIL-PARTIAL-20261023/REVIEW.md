# Actual native comparison: failure retained

The once-only supervised unit ended with exit1 after11.30seconds. Four desktop images are complete; mobile reached one near render readback but two actual GLB requests reported net::ERR_ABORTED before its first PNG. The abort cause is unresolved. Exact input hashes and eight exact served GLB responses do not waive that failure. No retry occurred.

All four desktop PNGs were personally inspected at native1280×800. The cabin, fine spoke wheels and full pole retain their gross silhouette and position in each same-pose near/mid pair. Thin rim/spoke-edge highlights differ. Body paint and glass remain dark/simple, and this distance view cannot establish photographic finish. Native image-envelope differences are reported descriptively without an acceptance threshold; screenshots are unmodified.

The desktop selector actually changes from near at23.99m to mid at24.01m. Each level has7merged material batches; pass-inclusive isolated geometry reports67018triangles for near and44490for mid, not current-world render budgets. Both desktop and failure-finally cleanup report0GPUtextures/0geometries and14of14merged-buffer disposal events. The pinned supervisor reaped4adoptedzombiechildren, needed no signals and ended with no active owned processes; server/browser closed.

The app remains clean3289b16/tree01d923. No application, publication or acceptance change was made. Original world deadline failures remain failures. The complete unrun fixture is recoverable from T2794-V17-NEAR-MID-NATIVE24-HELD-20261022.zip (SHAd245497b0d05a4a4cd174e6cfc6c41d44d6a834913bd50398039c5d576967598).
