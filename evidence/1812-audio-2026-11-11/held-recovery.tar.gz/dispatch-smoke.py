import datetime
import json
from pathlib import Path
import subprocess
import sys
import time

manifest = Path('/workspace/audio-1812/ci-smoke-matrix.json')
state = json.loads(manifest.read_text())
repo, branch, workflow = (state[k] for k in ('repository', 'branch', 'workflow'))
expected = state['head_sha']
if not expected or len(expected) != 40:
    sys.exit('Set the reviewed pushed head_sha before dispatch.')

def gh(*args, body=None):
    result = subprocess.run(['gh', *args], input=None if body is None else json.dumps(body), text=True, capture_output=True, check=True)
    return json.loads(result.stdout) if result.stdout.strip() else None

def head():
    return gh('api', f'repos/{repo}/git/ref/heads/{branch}')['object']['sha']

def runs():
    return gh('api', f'repos/{repo}/actions/workflows/{workflow}/runs?branch={branch}&event=workflow_dispatch&per_page=100')['workflow_runs']

def save():
    manifest.write_text(json.dumps(state, indent=2) + '\n')

for row in state['runs']:
    if row.get('run_id'):
        continue
    if row.get('dispatch_started'):
        sys.exit('A dispatch has no recorded run ID; inspect it before retrying to avoid duplicates.')
    if head() != expected:
        sys.exit('Remote head changed; refusing mixed-revision smoke coverage.')
    before = {run['id'] for run in runs()}
    row['dispatch_started'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    gh('api', '--method', 'POST', f'repos/{repo}/actions/workflows/{workflow}/dispatches', '--input', '-',
       body={'ref': branch, 'inputs': {'viewport': row['viewport'], 'stage': row['stage']}})
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        fresh = [run for run in runs() if run['id'] not in before and run['head_sha'] == expected]
        if len(fresh) > 1:
            sys.exit('Ambiguous concurrent dispatches; inspect run inputs before mapping coverage.')
        if fresh:
            row['run_id'] = fresh[0]['id']
            row['url'] = fresh[0]['html_url']
            row['head_sha'] = fresh[0]['head_sha']
            save()
            print(f"{row['viewport']} {row['stage']}: {row['url']}", flush=True)
            break
        time.sleep(2)
    else:
        sys.exit('Dispatch accepted but run visibility timed out; inspect before retry.')
current = sum(row.get('head_sha') == expected for row in state['runs'])
print(f'{len(state["runs"])} recorded rows: {current} dispatched on selected head, {len(state["runs"])-current} retained with their earlier tested head; scope validation is separate.', flush=True)
