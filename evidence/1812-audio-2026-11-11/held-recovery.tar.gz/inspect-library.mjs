import {chromium} from '/workspace/audio-tooling/node_modules/playwright/index.mjs';
import fs from 'node:fs/promises';import path from 'node:path';
const root='/workspace/chicago/site/4d/walk';const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
try{const p=await b.newPage({viewport:{width:390,height:780}});
await p.route('https://chicago.polecat.live/**',async r=>{const f=path.join(root,new URL(r.request().url()).pathname);try{await r.fulfill({body:await fs.readFile(f),contentType:f.endsWith('.html')?'text/html':'application/json'});}catch{await r.fulfill({status:404,body:''});}});
await p.goto('https://chicago.polecat.live/audio/credits.html');await p.waitForSelector('article');await p.selectOption('#era','1812');
console.log(JSON.stringify(await p.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,overflow:[...document.querySelectorAll('body *')].map(e=>({tag:e.tagName,id:e.id,text:e.textContent.slice(0,90),left:e.getBoundingClientRect().left,right:e.getBoundingClientRect().right,width:e.getBoundingClientRect().width})).filter(x=>x.right>innerWidth)})),null,2));await p.screenshot({path:'/workspace/audio-1812/library-before.png',fullPage:true});
}finally{await b.close();}
