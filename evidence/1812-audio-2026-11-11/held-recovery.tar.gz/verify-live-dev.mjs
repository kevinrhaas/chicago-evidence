// External live sanity check. Run ONLY after the expected DEV deployment is ready.
// No interception, fake actors/contacts, renderer overrides, or listening claims.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/audio-tooling/node_modules/playwright/index.mjs';
const base='https://chicago.polecat.live/4d/dev/';
const expected=process.env.EXPECTED_DEV_VERSION;
assert(expected,'Set EXPECTED_DEV_VERSION to the exact deployed DEV revision');
const out=process.env.AUDIO_1812_REPORT_DIR??'/workspace/audio-1812/live-dev-results';
await fs.mkdir(out,{recursive:true});
const sha=b=>createHash('sha256').update(b).digest('hex');
// Pinned to immutable published-props at 3df73785f. The reviewed equivalence
// proof preserves all 326 JS files, catalog and prop bytes; only the asset path
// changed after the 390 Light/1280 Full qualification. EXPECTED_DEV_VERSION
// still identifies the actual deployed revision independently of this baseline.
const artifacts={
 'walk/audio/catalog.json':'ba3ddc06813630c2c371139850e3a8019aa91be063fac6461ee835a34f9c46eb',
 'data/humans/work_1812.json':'8b1bc11fa24d7b12ff9e0fe3a676c16a959773d15c7244dab69884354551e4a8',
 'data/props/work_1812.glb':'64fdcbdffa35e00b0ed4704794993b21ae24286a3947bcb5961cfc1872180e7f',
 'walk/js/work-activity.js':'ab9661f515effba6f48c621b531a3066bd9fa60add160959415d420af5c9e822',
 'walk/js/work-audio.js':'821f84d1e292efaee3f65eb3652dd071103d19a5244f3a4ecc7bb6e6323f3bdd',
};
const report={base,expected,started:new Date().toISOString(),physicalListening:false,
 screenshotQualityApproved:false,scope:'Live default-summer 1812 sanity; no repeated all-season or full lifecycle suite',
 baseline:'/workspace/audio-1812/published-props',baselineVersion:'3df73785f',
 equivalenceProof:'/workspace/audio-1812/prop-path-equivalence.json',
 baselineQualification:'/workspace/audio-1812/review/results/report.json plus prop-path equivalence',
 harnessSha256:sha(await fs.readFile(new URL(import.meta.url))),artifacts,results:[]};
const proxyURL=process.env.HTTPS_PROXY||process.env.HTTP_PROXY||process.env.https_proxy||process.env.http_proxy;
const u=proxyURL?new URL(proxyURL):null;
const proxy=u?{server:u.origin,...(u.username?{username:decodeURIComponent(u.username),password:decodeURIComponent(u.password)}:{})}:undefined;
async function checkBuild(context,label){
 const r=await context.request.get(base+'build.json?audio1812='+Date.now()+'-'+label,{timeout:30000,headers:{'Cache-Control':'no-cache'}});
 assert(r.ok(),`build ${label}: HTTP ${r.status()}`);const build=await r.json();
 assert.equal(build.tier,'dev');assert.equal(build.sha??build.version,expected,`DEV revision changed or stale at ${label}`);return build;
}
function validateCatalog(catalog,config){
 const asset=id=>{const a=catalog.assets.find(x=>x.id===id);assert(a?.runtime_enabled,`${id} enabled`);return a;};
 assert.equal(asset('hammer-nail').scene_placement.mode,'visible-work');
 assert.equal(asset('horse-walking').scene_placement.mode,'hoof-contact');
 assert(asset('summer-cicada-proxy').seasonal_placements.some(p=>p.scene_id==='1812'&&p.season==='summer'));
 assert(asset('late-summer-katydid').seasonal_placements.some(p=>p.scene_id==='1812'&&p.season==='summer'&&p.active_periods.includes('night')));
 assert.deepEqual(asset('robin-calls').seasonal_placements.filter(p=>p.scene_id==='1812').map(p=>p.season).sort(),['fall','spring']);
 const task=config.tasks.find(t=>t.id==='militia-packing-chest');
 assert.equal(task.actor_id,'hi_town_chicago_militia_unnamed_4_1812');
 assert.deepEqual(task.dates,{from:'1812-08-14',to:'1812-08-14'});assert.deepEqual(task.hours,[[13,18]]);
 assert.equal(config.asset,'props/work_1812.glb');return task;
}
for(const width of [390,1280]){
 const detail=width===390?'light':'full';
 const row={width,detail,pageErrors:[],badMedia:[],requests:[],failedRequests:[]};report.results.push(row);
 const browser=await chromium.launch({proxy,executablePath:process.env.PW_EXECUTABLE??'/usr/bin/chromium',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
 let page,context;
 try{
  context=await browser.newContext({viewport:{width,height:width===390?780:800},hasTouch:width===390,serviceWorkers:'block'});
  row.buildStart=await checkBuild(context,'start-'+width);
  const delivered={};row.deliveredHashes={};
  for(const [file,hash]of Object.entries(artifacts)){
   const r=await context.request.get(base+file+'?audio1812='+Date.now(),{timeout:30000});
   assert(r.ok(),`${file}: HTTP ${r.status()}`);const bytes=await r.body();
   row.deliveredHashes[file]=sha(bytes);assert.equal(sha(bytes),hash,`Delivered ${file} differs from qualified publication`);
   if(file.endsWith('.json'))delivered[file]=JSON.parse(bytes);
  }
  const catalog=delivered['walk/audio/catalog.json'],config=delivered['data/humans/work_1812.json'];
  const task=validateCatalog(catalog,config);assert(catalog.hosting?.public_base);
  page=await context.newPage();page.setDefaultTimeout(90000);
  page.on('pageerror',e=>row.pageErrors.push(e.message));
  page.on('request',r=>{if(r.url().startsWith(catalog.hosting.public_base))row.requests.push(r.url());});
  page.on('response',r=>{if(r.url().startsWith(catalog.hosting.public_base)&&![200,206].includes(r.status()))row.badMedia.push({url:r.url(),status:r.status()});});
  page.on('requestfailed',r=>row.failedRequests.push({url:r.url(),error:r.failure()?.errorText}));
  await page.addInitScript(detail=>localStorage.setItem('chicago4d.settings',JSON.stringify({soundMaster:0,soundMusic:0,soundAmbience:0,soundEffects:1,timeOfDay:'15:00',detail})),detail);
  await page.goto(base+'walk/?year=1812',{waitUntil:'domcontentloaded',timeout:60000});
  await page.waitForFunction(()=>window.__chicago4d?.ready===true&&__chicago4d.welcome?.state==='welcome',null,{timeout:240000,polling:500});
  assert.equal(await page.evaluate(()=>__chicago4d.detail),detail);assert.equal(row.requests.length,0,'Muted boot fetches no recordings');
  const toggle=page.locator('#arrival-sound');const box=await toggle.boundingBox();assert(box&&box.width<=48&&box.height<=48,'Compact sound icon');
  assert.equal((await toggle.textContent()).trim(),'');assert.equal(await toggle.getAttribute('aria-pressed'),'false');
  assert(await toggle.getAttribute('aria-label'),'Icon retains accessible name');row.toggle=box;
  assert.equal((await page.locator('#s-sound-effects-help').textContent()).trim(),'Nearby actions: hoofbeats, wagon wheels and hammering.');
  assert.equal((await page.locator('#s-sound-ambience-help').textContent()).trim(),'Background environment: wind, lake waves, birds and insects.');
  assert.equal(await page.locator('#s-sound-note,#s-sound-music-help').count(),0);
  await toggle.click({noWaitAfter:true,timeout:30000});assert.equal(await toggle.getAttribute('aria-pressed'),'true');
  await page.locator('#home-roam').click({noWaitAfter:true,timeout:30000});
  await page.waitForFunction(()=>__chicago4d.welcome.state==='world'&&__chicago4d.journey.state==='exploring'&&__chicago4d.sound?.state.context==='running',null,{timeout:90000});
  // Real DOM input handlers; native Stop/Continue temporarily isolate the work meter.
  await page.evaluate(()=>{
   const a=__chicago4d;document.exitPointerLock?.();
   for(const [id,value]of [['s-sound-ambience',0],['s-sound-music',0],['s-sound-effects',1],['s-sound-master',1]]){
    const el=document.getElementById(id);if(!el)throw Error('Missing native sound range '+id);el.value=String(value);el.dispatchEvent(new Event('input',{bubbles:true}));
   }
   window.__liveStoppedTeams=a.townTransport.actors.filter(x=>x.audioState.moving);__liveStoppedTeams.forEach(x=>x.stop());
   const meter=a.audio.createAnalyser();a.sound.nodes.effects.connect(meter);window.__liveMeter=meter;
   window.__livePeak=()=>{const data=new Float32Array(meter.fftSize);meter.getFloatTimeDomainData(data);return Math.max(...data.map(Math.abs));};
  });
  await page.waitForFunction(()=>!__chicago4d.sound.state.recorded.transport.voices.length,null,{timeout:10000});
  const before=await page.evaluate(async task=>{
   const a=__chicago4d;await a.season.set('summer');await a.timeOfDay.set('15:00');
   if(a.timeOfDay.current.date!=='1812-08-14')throw Error('Unexpected default summer date');
   const e=task.at.e+6,n=task.at.n-7,t=a.terrain;
   if(!t.heightfield.contains(e,n)||t.isWater(e,n)||!Number.isFinite(t.surfaceHeight(e,n)))throw Error('Work listener lacks dry measured ground');
   a.walker.teleport({local_e:e,local_n:n,yaw_deg:320});a.step();a.step();return a.sound.state.recorded.work?.started??0;
  },task);
  await page.waitForFunction(({before,taskId})=>{
   const a=__chicago4d,w=a.workActivity?.state,s=a.sound.state.recorded.work,peak=__livePeak();
   if(!(w?.ready&&w.active&&w.taskId===taskId&&w.actorId==='hi_town_chicago_militia_unnamed_4_1812'&&w.contactSerial>0&&s?.started>before&&s.voices.length===1&&s.lastContact?.taskId===taskId&&s.lastContact.session===w.session&&s.lastContact.serial===w.contactSerial&&peak>1e-6))return false;
   const nodes=['work_chest','work_hammer','work_contact','hammer_strike'].map(name=>{
    const o=a.workActivity.group.getObjectByName(name);if(!o)return{name,present:false};let visible=true;
    for(let p=o;p;p=p.parent)if(p.visible===false)visible=false;
    const p=o.getWorldPosition(o.position.clone());return{name,present:true,visible,position:{x:p.x,y:p.y,z:p.z}};
   });
   window.__liveWorkProof={work:w,audio:s,nodes,peak,sources:a.workActivity.audioSources,naturalWork:a.days.workSource(w.actorId),time:a.timeOfDay.current};return true;
  },{before,taskId:task.id},{timeout:120000,polling:25});
  row.work=await page.evaluate(()=>__liveWorkProof);
  assert.equal(row.work.audio.decodedBytes,69120);assert.equal(row.work.audio.failed,false);
  assert.deepEqual(row.work.audio.errors,[]);assert.deepEqual(row.work.work.errors,[]);assert(row.work.work.handError<=.08);
  assert(row.work.naturalWork?.active);assert.equal(row.work.naturalWork.actorId,task.actor_id);
  assert(Math.hypot(row.work.naturalWork.originalAt.e-task.at.e,row.work.naturalWork.originalAt.n-task.at.n)<.01);
  assert(row.work.nodes.every(x=>x.present&&x.visible));assert.equal(row.work.sources.length,1);
  assert.equal(row.work.audio.lastContact.session,row.work.sources[0].session);
  // Resume actual teams, choose their authored route, and move only the listener.
  await page.evaluate(async detail=>{
   const a=__chicago4d;__liveStoppedTeams.forEach(x=>x.resume());window.__liveStoppedTeams=[];
   await a.timeOfDay.set('10:00');await a.townTransport.setTier(detail);
   const data=await(await fetch('../data/transport/driven/loops.json')).json();
   const row=data.rows.find(x=>x.id==='fort_wagon_loop_1812');if(!row)throw Error('Missing real fort route');
   const {routeFor}=await import('./js/transport-loop.js'),p=routeFor(row.route).at(row.initial_distance_m??0);
   a.walker.teleport({local_e:p.e+12,local_n:p.n,yaw_deg:270});a.step();a.step();await a.townTransport.ready();
   window.__liveFollow=setInterval(()=>{
    const source=a.townTransport.audioSources.find(x=>x.id==='fort_wagon_loop_1812'),p=source?.anchors?.wagon;
    if(p)a.walker.teleport({local_e:p.x+12,local_n:-p.z,yaw_deg:270});
   },1000);
  },detail);
  await page.waitForFunction(()=>{
   const a=__chicago4d,s=a.sound.state.recorded.transport,sources=a.townTransport.audioSources;
   if(!(s.contactVoices>0&&s.contacts.some(x=>x.actor==='fort_wagon_loop_1812')&&sources.some(x=>x.id==='fort_wagon_loop_1812'&&x.moving)))return false;
   window.__liveHoofProof={audio:s,sources,time:a.timeOfDay.current,peak:__livePeak()};return true;
  },null,{timeout:90000,polling:25});
  row.hooves=await page.evaluate(()=>__liveHoofProof);const h=row.hooves.audio;
  assert.equal(h.voiceLimit,6);assert.equal(h.decodedByteLimit,10*1024*1024);
  assert(h.voices.length<=6&&h.peakDecodedBytes<=10*1024*1024);assert.equal(h.contactDecodedBytes,55296);
  assert(h.contacts.some(x=>x.snowCover===0&&Math.abs(x.lowpassHz-18000)<1e-6));assert.deepEqual(h.errors,[]);
  for(const id of ['hammer-nail','horse-walking'])assert(row.requests.includes(catalog.assets.find(x=>x.id===id).url),`Exact R2 recording requested: ${id}`);
  await page.evaluate(()=>{clearInterval(window.__liveFollow);const el=document.getElementById('s-sound-master');el.value='0';el.dispatchEvent(new Event('input',{bubbles:true}));});
  await page.waitForFunction(()=>{const s=__chicago4d.sound.state;return s.silent&&!s.recorded.work.voices.length&&!s.recorded.transport.voices.length&&!s.recorded.habitat.voices.length;},null,{timeout:10000});
  row.muted=true;assert.deepEqual(row.pageErrors,[]);assert.deepEqual(row.badMedia,[]);
  row.buildEnd=await checkBuild(context,'end-'+width);row.passed=true;
 }catch(e){row.error=e.stack;row.passed=false;
  if(context)try{row.buildAfterFailure=await checkBuild(context,'failure-'+width);}catch(x){row.buildError=x.message;}
  if(page)try{row.diagnostics=await Promise.race([page.evaluate(()=>({ready:window.__chicago4d?.ready,time:window.__chicago4d?.timeOfDay?.current,work:window.__chicago4d?.workActivity?.state,audio:window.__chicago4d?.sound?.state})),new Promise((_,reject)=>setTimeout(()=>reject(Error('diagnostics timeout')),4000))]);}catch(x){row.diagnosticError=x.message;}
 }finally{
  if(page)try{await Promise.race([page.evaluate(()=>{clearInterval(window.__liveFollow);window.__liveStoppedTeams?.forEach(x=>x.resume());if(window.__liveMeter){__chicago4d.sound.nodes.effects.disconnect(__liveMeter);__liveMeter.disconnect();}}),new Promise((_,reject)=>setTimeout(()=>reject(Error('cleanup timeout')),4000))]);}catch{}
  await browser.close();await fs.writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
 }
 console.log(JSON.stringify({width,detail,passed:row.passed,error:row.error??null}));
 if(!row.passed)break;
}
report.finished=new Date().toISOString();report.passed=report.results.length===2&&report.results.every(x=>x.passed);
await fs.writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
if(!report.passed)process.exitCode=1;
