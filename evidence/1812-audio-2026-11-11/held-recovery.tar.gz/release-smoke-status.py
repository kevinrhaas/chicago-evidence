import collections
import json
from pathlib import Path
import subprocess
import sys

root = Path('/workspace/audio-1812')
old = json.loads((root/'ci-smoke-matrix.json').read_text())
new = json.loads((root/'ci-smoke-stage13.json').read_text())
proof = json.loads(subprocess.check_output(['python3', '/workspace/audio-next/verify_smoke_scope_reuse.py', old['head_sha'], new['head_sha']], text=True))
assert proof['scope_verification'] == 'PASS'
all_runs = json.loads(Path(sys.argv[1]).read_text()) if len(sys.argv)>1 else json.loads(subprocess.check_output(['gh','run','list','--repo',old['repository'],'--workflow',old['workflow'],'--branch',old['branch'],'--event','workflow_dispatch','--limit','100','--json','databaseId,status,conclusion,headSha,url'],text=True))
lookup = {r['databaseId']:r for r in all_runs}
rows = []
counts = collections.Counter()
coverage = {v:collections.Counter() for v in ['mobile','desktop']}
for row in [r for r in old['runs'] if r['stage'] != '13'] + new['runs']:
    expected = new['head_sha'] if row['stage'] == '13' else old['head_sha']
    run = lookup[row['run_id']]
    assert run['headSha'] == expected, 'Wrong tested commit'
    stage = row['stage'].split('-')
    stages = range(int(stage[0]),int(stage[-1])+1)
    coverage[row['viewport']].update(stages)
    label = run['conclusion'] if run['status'] == 'completed' else run['status']
    counts[label] += 1
    rows.append({**row,**run,'actual_tested_sha':expected,'basis':'fresh changed-stage test' if row['stage']=='13' else 'unchanged source verified by scope receipt'})
    print(row['viewport'], row['stage'], label,run['databaseId'],expected[:9])
assert all(c == collections.Counter(range(1,16)) for c in coverage.values()), 'Incomplete or duplicated stages'
green = counts == {'success':18}
receipt = {'head_sha':new['head_sha'],'scope_proof':proof,'green':green,'counts':dict(counts),'runs':rows,'coverage':{v:dict(c) for v,c in coverage.items()},'note':'Old run SHA retained honestly. Only PART13 assertion changed; all other tracked source bytes match. Current-head required CI and moving checks are separate requirements.'}
(root/'release-smoke-coverage.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(dict(counts))
print('COMPLETE SOURCE-QUALIFIED MATRIX GREEN' if green else 'MATRIX PENDING OR FAILED')
