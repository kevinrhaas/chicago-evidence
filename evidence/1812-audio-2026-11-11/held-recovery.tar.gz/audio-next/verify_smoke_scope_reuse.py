#!/usr/bin/env python3
"""Fail-closed committed-source proof for reusing smoke runs outside part 13.

Usage: verify_smoke_scope_reuse.py BASE_FULL_SHA HEAD_FULL_SHA [--repo PATH]
Writes one JSON receipt to stdout, including failures. This checks source scope,
not whether any browser run passed; keep actual run SHAs and results separately.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

SMOKE_PATH = 'chicago/4d/tools/smoke_renderer.mjs'
DEFAULT_REPO = Path('/workspace/chicago')
UNCHANGED_PARTS = list(range(1, 13)) + [14, 15]
START = re.compile(rb'^    // PART 13 [^\r\n]*\n', re.MULTILINE)
END = re.compile(rb'^    } // end PART 13 [^\r\n]*(?:\n|\Z)', re.MULTILINE)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git_bytes(repo, *args):
    result = subprocess.run(['git', '-C', str(repo), *args], check=False,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise ValueError('git command failed: ' + ' '.join(args[:2]) + ': '
                         + result.stderr.decode('utf-8', errors='replace').strip())
    return result.stdout


def split_part13(source):
    starts, ends = list(START.finditer(source)), list(END.finditer(source))
    if len(starts) != 1 or len(ends) != 1:
        raise ValueError('Expected exactly one PART 13 start and end marker')
    start, end = starts[0], ends[0]
    if start.end() >= end.start():
        raise ValueError('PART 13 markers are out of order or empty')
    return {
        'before_part_13': source[:start.start()],
        'part_13': source[start.start():end.end()],
        'after_end_part_13': source[end.end():],
        'start_marker': start.group(),
        'end_marker': end.group(),
    }


def verify(repo, base, head):
    for label, revision in [('base', base), ('head', head)]:
        if not re.fullmatch(r'(?:[0-9a-f]{40}|[0-9a-f]{64})', revision):
            raise ValueError(label + ' must be a full lowercase commit SHA')
        resolved = git_bytes(repo, 'rev-parse', '--verify', revision + '^{commit}').decode().strip()
        if resolved != revision:
            raise ValueError(label + ' must name the commit itself, not another Git object')

    paths = git_bytes(repo, 'diff', '--no-ext-diff', '--no-renames', '--name-only',
                      '-z', base, head, '--').split(b'\0')
    paths = [p.decode('utf-8', errors='strict') for p in paths if p]
    if paths != [SMOKE_PATH]:
        raise ValueError('Changed paths must be exactly [' + SMOKE_PATH + ']; got '
                         + json.dumps(paths))

    sources = []
    modes = []
    for revision in (base, head):
        tree = git_bytes(repo, 'ls-tree', '-z', revision, '--', SMOKE_PATH)
        entries = [entry for entry in tree.split(b'\0') if entry]
        if len(entries) != 1:
            raise ValueError('Expected one smoke file in each commit tree')
        metadata, tree_path = entries[0].split(b'\t', 1)
        mode, object_type, _object_id = metadata.split(b' ')
        if tree_path.decode() != SMOKE_PATH or object_type != b'blob' or mode not in (b'100644', b'100755'):
            raise ValueError('Smoke file must be a regular tracked file in both commits')
        modes.append(mode.decode())
        sources.append(git_bytes(repo, 'show', revision + ':' + SMOKE_PATH))
    if modes[0] != modes[1]:
        raise ValueError('Smoke file mode changed')
    old, new = map(split_part13, sources)
    for key in ('before_part_13', 'after_end_part_13', 'start_marker', 'end_marker'):
        if old[key] != new[key]:
            raise ValueError('Bytes changed outside the permitted PART 13 body: ' + key)
    if old['part_13'] == new['part_13']:
        raise ValueError('Expected an actual PART 13 source change')

    region_receipts = {}
    for key in ('before_part_13', 'part_13', 'after_end_part_13'):
        region_receipts[key] = {
            'equal': old[key] == new[key],
            'base_bytes': len(old[key]), 'head_bytes': len(new[key]),
            'base_sha256': sha256(old[key]), 'head_sha256': sha256(new[key]),
        }
    return {
        'schema_version': 1,
        'scope_verification': 'PASS',
        'repository': str(repo.resolve()),
        'base_commit': base, 'head_commit': head,
        'changed_paths': paths,
        'only_changed_file': SMOKE_PATH,
        'file_mode': modes[0],
        'whole_smoke_file': {
            'equal': False,
            'base_sha256': sha256(sources[0]), 'head_sha256': sha256(sources[1]),
            'base_bytes': len(sources[0]), 'head_bytes': len(sources[1]),
        },
        'regions': region_receipts,
        'boundary_markers_identical': True,
        'unchanged_parts': UNCHANGED_PARTS,
        'shared_setup_and_teardown_identical': True,
        'all_other_tracked_paths_unchanged': True,
        'app_source_data_assets_unchanged': True,
        'requires_new_runs': {'parts': [13], 'viewports': ['mobile', 'desktop']},
        'reuse_scope': 'Source equivalence permits considering existing runs of unchanged parts. Each reused run must retain its actual base commit, viewport, stage and result; this receipt does not prove those runs passed.',
        'limitations': [
            'The whole smoke file hash differs; no whole-tree hash equality is claimed.',
            'Only the two named committed trees are compared; working-tree files are not checked.',
            'No browser, playback, deployment or CI check is executed by this verifier.',
            'This does not count reused runs or manufacture missing run results.',
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('base', help='Full SHA of the commit actually tested by reused runs')
    parser.add_argument('head', help='Full SHA containing only the PART 13 smoke correction')
    parser.add_argument('--repo', type=Path, default=DEFAULT_REPO)
    args = parser.parse_args()
    try:
        receipt = verify(args.repo, args.base, args.head)
    except (ValueError, OSError, UnicodeError) as error:
        print(json.dumps({'schema_version': 1, 'scope_verification': 'FAIL',
                          'base_commit': args.base, 'head_commit': args.head,
                          'error': str(error)}, indent=2))
        return 1
    print(json.dumps(receipt, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
