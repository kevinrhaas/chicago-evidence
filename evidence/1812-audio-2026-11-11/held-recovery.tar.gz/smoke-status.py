import collections
import json
from pathlib import Path
import subprocess
import sys

file = Path('/workspace/audio-1812/ci-smoke-matrix.json')
state = json.loads(file.read_text())
result = subprocess.run(['gh', 'run', 'list', '--repo', state['repository'],
    '--workflow', state['workflow'], '--branch', state['branch'], '--event', 'workflow_dispatch',
    '--limit', '100', '--json', 'databaseId,status,conclusion,headSha,url'],
    check=True, text=True, capture_output=True)
runs = {run['databaseId']: run for run in json.loads(result.stdout)}
counts = collections.Counter()
for row in state['runs']:
    run = runs.get(row.get('run_id'))
    if not run:
        counts['missing'] += 1
        continue
    expected = row.get('head_sha', state['head_sha'])
    if run['headSha'] != expected:
        sys.exit('Run belongs to another commit; refusing coverage claim.')
    if expected != state['head_sha']:
        sys.exit('This release requires fresh coverage on its selected head.')
    row.update(status=run['status'], conclusion=run['conclusion'])
    label = run['conclusion'] if run['status'] == 'completed' else run['status']
    counts[label] += 1
    print(f"{row['viewport']:7} {row['stage']:5} {label:12} {row['run_id']}")
file.write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps(dict(counts)))
print('FULL MATRIX GREEN' if counts == {'success': 18} else 'FULL MATRIX NOT GREEN')
