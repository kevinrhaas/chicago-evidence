// External adapter for check-published-1812.mjs. Native actors/actions/props only.
import assert from 'node:assert/strict';
export async function checkWork({page,screenshot}) {
  const result={tasks:[],lifecycle:[]};
  await page.evaluate(()=>{
    const a=__chicago4d;
    // Native Stop/Continue APIs isolate the Effects meter from moving wagons.
    window.__workStoppedTeams=a.townTransport.actors.filter(x=>x.audioState.moving);
    __workStoppedTeams.forEach(x=>x.stop());
    a.hud.settings.soundAmbience=0;a.hud.settings.soundMusic=0;a.hud.settings.soundEffects=1;a.hud.settings.soundMaster=1;a.sound.sync();
    const meter=a.audio.createAnalyser();a.sound.nodes.effects.connect(meter);window.__workMeter=meter;
    window.__workPeak=()=>{const x=new Float32Array(meter.fftSize);meter.getFloatTimeDomainData(x);return Math.max(...x.map(Math.abs));};
  });
  try {
    await page.waitForFunction(()=>!__chicago4d.sound.state.recorded.transport.voices.length,null,{timeout:5000});
    for(const task of [
      {id:'militia-packing-chest',season:'summer',date:'1812-08-14',hour:'15:00',e:1082,n:165},
      {id:'militia-piazza-repair',season:'spring',date:'1812-04-15',hour:'10:00',e:1072.5,n:177},
    ]) {
      const before=await page.evaluate(async task=>{
        const a=__chicago4d;
        await a.season.set(task.season);await a.timeOfDay.set(task.hour);
        if(a.timeOfDay.current.date!==task.date)throw Error('Work seasonal date mismatch');
        const e=task.e+6,n=task.n-7,t=a.terrain;
        if(!t.heightfield.contains(e,n)||t.isWater(e,n)||!Number.isFinite(t.surfaceHeight(e,n)))throw Error('Work listener is not on actual dry measured ground');
        a.walker.teleport({local_e:e,local_n:n,yaw_deg:320});a.step();a.step();
        return a.sound.state.recorded.work?.started??0;
      },task);
      await page.waitForFunction(({task,before})=>{
        const a=__chicago4d,w=a.workActivity?.state,s=a.sound.state.recorded.work;
        return w?.ready&&w.active&&w.taskId===task.id&&w.actorId==='hi_town_chicago_militia_unnamed_4_1812'
          &&w.contactSerial>0&&s?.started>before&&s.voices.length===1&&s.lastContact?.taskId===task.id
          &&s.lastContact.session===w.session&&s.lastContact.serial===w.contactSerial&&__workPeak()>1e-6;
      },{task,before},{timeout:120000,polling:25});
      const proof=await page.evaluate(()=>{
        const a=__chicago4d,g=a.workActivity.group,w=a.workActivity.state,s=a.sound.state.recorded.work;
        const nodes=['work_chest','work_hammer','work_contact','hammer_strike'].map(name=>{
          const o=g.getObjectByName(name);if(!o)return{name,present:false};
          let visible=true;for(let p=o;p;p=p.parent)if(p.visible===false)visible=false;
          const position=o.getWorldPosition(o.position.clone());
          return{name,present:true,visible,position:{x:position.x,y:position.y,z:position.z}};
        });
        return{work:w,audio:s,nodes,source:a.workActivity.audioSources,
          naturalWork:a.days.workSource('hi_town_chicago_militia_unnamed_4_1812'),
          time:a.timeOfDay.current,peak:__workPeak()};
      });
      assert.equal(proof.audio.decodedBytes,69120);assert.equal(proof.audio.failed,false);
      assert.deepEqual(proof.work.errors,[]);assert(proof.work.handError<=.08);
      assert.deepEqual(proof.audio.errors,[]);
      assert(proof.naturalWork?.active,'actual day engine supplies current primary work');
      assert.equal(proof.naturalWork.actorId,'hi_town_chicago_militia_unnamed_4_1812');
      assert(Math.hypot(proof.naturalWork.originalAt.e-task.e,proof.naturalWork.originalAt.n-task.n)<.01);
      assert(proof.nodes.every(x=>x.present&&x.visible));
      assert.equal(proof.source.length,1);assert.equal(proof.audio.lastContact.session,proof.source[0].session);
      assert(proof.audio.lastContact.serial<=proof.source[0].contactSerial);
      result.tasks.push(proof);await screenshot(task.id);
    }
    // Both controls are normal public app APIs; no source or eligibility spoof.
    for(const kind of ['effects','people','confidence']) {
      const saved=await page.evaluate(kind=>{
        const a=__chicago4d;
        const previous={effects:a.hud.settings.soundEffects,people:a.humans.shown,hidden:a.confidence.hidden.reconstructed};
        if(kind==='effects'){a.hud.settings.soundEffects=0;a.sound.sync();}
        if(kind==='people')a.humans.setShown(false);
        if(kind==='confidence')a.confidence.setHidden('reconstructed',true);
        return previous;
      },kind);
      await page.waitForFunction(()=>!__chicago4d.sound.state.recorded.work.voices.length&&__workPeak()<1e-6,null,{timeout:5000,polling:50});
      const silent=await page.evaluate(()=>({work:__chicago4d.workActivity.state,audio:__chicago4d.sound.state.recorded.work}));
      if(kind!=='effects')assert.equal(silent.work.active,false);
      result.lifecycle.push({kind,silent});
      await page.evaluate(({kind,saved})=>{
        const a=__chicago4d;
        if(kind==='effects'){a.hud.settings.soundEffects=saved.effects;a.sound.sync();}
        if(kind==='people')a.humans.setShown(saved.people);
        if(kind==='confidence')a.confidence.setHidden('reconstructed',saved.hidden);
      },{kind,saved});
      await page.waitForFunction(started=>__chicago4d.sound.state.recorded.work.started>started&&__workPeak()>1e-6,silent.audio.started,{timeout:45000,polling:25});
    }
    await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'));});
    await page.waitForFunction(()=>!__chicago4d.sound.state.recorded.work.voices.length&&__workPeak()<1e-6,null,{timeout:5000});
    result.lifecycle.push({kind:'document hidden fixture',audio:await page.evaluate(()=>__chicago4d.sound.state.recorded.work)});
    await page.evaluate(()=>{delete document.hidden;document.dispatchEvent(new Event('visibilitychange'));});
    return result;
  } finally {
    await page.evaluate(()=>{
      delete document.hidden;document.dispatchEvent(new Event('visibilitychange'));
      if(window.__workMeter){__chicago4d.sound.nodes.effects.disconnect(__workMeter);__workMeter.disconnect();delete window.__workMeter;}
      window.__workStoppedTeams?.forEach(x=>x.resume());delete window.__workStoppedTeams;
    });
  }
}
