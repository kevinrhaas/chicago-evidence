// External T-3551 integration draft. Run only after parent freezes and publishes.
// Uses one immutable generated publication; no source/catalog/actor overlays.
// Draw holds apply only to labelled data/audio checks. Screenshots restore draws.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/audio-tooling/node_modules/playwright/index.mjs';
const published = path.resolve(process.env.C4D_PUBLISHED_ROOT ?? '');
const expected = process.env.EXPECTED_BUILD_SHA;
assert(process.env.C4D_PUBLISHED_ROOT && expected, 'Set immutable C4D_PUBLISHED_ROOT and exact EXPECTED_BUILD_SHA');
const out = process.env.AUDIO_1812_REPORT_DIR ?? '/workspace/audio-1812/review/results';
await fs.mkdir(out, {recursive:true});
const buildBytes = await fs.readFile(path.join(published,'build.json'));
const build = JSON.parse(buildBytes);
assert.equal(build.sha ?? build.version, expected, 'Published metadata must match the supplied exact revision');
const catalogBytes = await fs.readFile(path.join(published,'walk/audio/catalog.json'));
const catalog = JSON.parse(catalogBytes);
assert(catalog.hosting?.public_base, 'Require generated hosted-audio catalog');
const base = 'https://chicago.polecat.live/4d/';
const sha = b => createHash('sha256').update(b).digest('hex');
const codeNames=['main.js','sound.js','recorded-audio.js','habitat-audio.js','habitat-seasons.js','season.js',
  'transport-audio.js','hoof-contact-events.js','driven-assembly-loader.js','town-transport.js','human-actions.js','human-days.js','work-activity.js','work-audio.js'];
const codeHashes=async()=>Object.fromEntries(await Promise.all(codeNames.map(async name=>[name,sha(await fs.readFile(path.join(published,'walk/js',name)))])));
const publishedCodeHashes=await codeHashes();
const report = {kind:'published 1812 native data/audio and separate rendered screenshots',
  physicalListening:false, screenshotQualityApproved:false, published, build,
  reviewedSourceTree:process.env.REVIEWED_SOURCE_TREE??null,
  provenanceNote:'Build metadata identifies the publication stamp. An uncommitted reviewed source tree is separately supplied by the caller; the stamp alone does not prove that tree.',
  catalogSha256:sha(catalogBytes),publishedCodeHashes,harnessSha256:sha(await fs.readFile(new URL(import.meta.url))),results:[]};
const proxyUrl = process.env.HTTPS_PROXY || process.env.HTTP_PROXY || process.env.https_proxy || process.env.http_proxy;
const proxyU = proxyUrl ? new URL(proxyUrl) : null;
const proxy = proxyU ? {server:proxyU.origin,...(proxyU.username ? {username:decodeURIComponent(proxyU.username),password:decodeURIComponent(proxyU.password)} : {})} : undefined;
const mime = {'.js':'text/javascript','.json':'application/json','.html':'text/html','.css':'text/css',
  '.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml','.glb':'model/gltf-binary'};
const widths = process.env.AUDIO_1812_VIEWPORT ? [Number(process.env.AUDIO_1812_VIEWPORT)] : [390,1280];
for (const width of widths) {
  const browser = await chromium.launch({proxy, executablePath:process.env.PW_EXECUTABLE ?? '/usr/bin/chromium',
    headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
  const detail=width===390?'light':'full';
  const row = {width,detail,pageErrors:[],badMedia:[],missingFiles:[],requests:[],checks:[]};
  report.results.push(row);
  let page;
  try {
    const context = await browser.newContext({viewport:{width,height:width===390?780:800},hasTouch:width===390,serviceWorkers:'block'});
    await context.route(base+'**',async route => {
      const relative = decodeURIComponent(new URL(route.request().url()).pathname).replace(/^\/4d\//,'');
      let file = path.resolve(published,relative);
      if (!file.startsWith(published+path.sep)) return route.fulfill({status:403});
      try { if ((await fs.stat(file)).isDirectory()) file=path.join(file,'index.html');
        await route.fulfill({body:await fs.readFile(file),contentType:mime[path.extname(file)]??'application/octet-stream'});
      } catch { row.missingFiles.push(relative); await route.fulfill({status:404,body:relative}); }
    });
    page=await context.newPage(); page.setDefaultTimeout(90000);
    page.on('pageerror',e=>row.pageErrors.push(e.message));
    page.on('request',r=>{if(r.url().startsWith(catalog.hosting.public_base))row.requests.push(r.url());});
    page.on('response',r=>{if(r.url().startsWith(catalog.hosting.public_base)&&![200,206].includes(r.status()))row.badMedia.push({url:r.url(),status:r.status()});});
    await page.addInitScript(detail=>localStorage.setItem('chicago4d.settings',JSON.stringify({soundMaster:0,soundMusic:0,soundAmbience:1,soundEffects:0,timeOfDay:'15:00',detail})),detail);
    await page.goto(base+'walk/?year=1812&keep-geometry=1',{waitUntil:'domcontentloaded',timeout:60000});
    await page.waitForFunction(()=>window.__chicago4d?.ready===true&&__chicago4d.welcome?.state==='welcome',null,{timeout:240000,polling:500});
    assert.equal(await page.evaluate(()=>__chicago4d.detail),detail,'native renderer uses requested detail');
    assert.equal(row.requests.length,0,'muted boot fetches no media');
    const hold = async on => page.evaluate(on=>{
      const a=__chicago4d;
      if(on&&!window.__audio1812Render){window.__audio1812Render=a.renderer.render;a.renderer.render=(s,c)=>c?.updateMatrixWorld?.();}
      else if(!on&&window.__audio1812Render){a.renderer.render=window.__audio1812Render;delete window.__audio1812Render;}
    },on);
    const screenshot = async name => {
      await hold(false);
      const before=await page.evaluate(()=>__chicago4d.renderer.info.render.frame);
      await page.waitForFunction(before=>!window.__audio1812Render&&__chicago4d.renderer.info.render.frame>before,before,{timeout:60000,polling:100});
      await page.screenshot({path:path.join(out,`${width}-${name}.png`)});
      row.checks.push({name,kind:'rendered screenshot captured; requires visual review'});
      await hold(true);
    };
    await hold(true);
    await page.locator('#arrival-sound').click({noWaitAfter:true,timeout:30000});
    await page.locator('#home-roam').click({noWaitAfter:true,timeout:30000});
    await page.waitForFunction(()=>__chicago4d.welcome.state==='world'&&__chicago4d.journey.state==='exploring'&&__chicago4d.sound?.state.context==='running',null,{timeout:90000});
    await page.evaluate(async()=>{
      const a=__chicago4d; document.exitPointerLock?.();
      const h=await import('./js/habitat-audio.js');
      window.__audio1812={habitat:h,catalog:await(await fetch('./audio/catalog.json')).json()};
      __audio1812.env=()=>({camera:a.camera,terrain:a.terrain,flora:a.flora,faunaZones:a.fauna?.records,
        season:a.season.current,time:a.timeOfDay.current,sunElevation:a.world.sun.elevationDeg});
    });
    // Native date/season APIs plus actual flora/terrain. A search clone chooses a
    // station; the actual walker then goes there and eligibility is checked again.
    row.seasons=[];
    for (const [season,date] of Object.entries({summer:'1812-08-14',spring:'1812-04-15',fall:'1812-10-15',winter:'1812-02-15'})) {
      const result=await page.evaluate(async({season,date})=>{
        const a=__chicago4d,h=__audio1812;
        await a.season.set(season);await a.timeOfDay.set('15:00');
        const current=a.timeOfDay.current;
        if(current.date!==date)throw Error(`Native seasonal date mismatch ${JSON.stringify(current)}`);
        const samples={};
        for(let e=-900;e<=1500;e+=40)for(let n=-900;n<=1100;n+=40){
          if(!a.terrain.heightfield.contains(e,n)||a.terrain.isWater(e,n))continue;
          const zone=a.flora.zoneAt(e,n),ground=a.terrain.surfaceHeight(e,n);
          if(!zone||samples[zone]?.ids.length||!Number.isFinite(ground)||ground<=0)continue;
          const camera=a.camera.clone();camera.position.set(e,ground+1.7,-n);camera.quaternion.set(0,0,0,1);
          const candidates=h.habitat.habitatCandidates(h.catalog,{...h.env(),camera},'1812');
          samples[zone]={e,n,ground,ids:candidates.map(x=>x.asset.id),modes:candidates.map(x=>x.mode)};
        }
        const target=Object.values(samples).find(x=>season==='summer'?x.ids.includes('summer-cicada-proxy'):x.ids.length);
        if(target){a.walker.teleport({local_e:target.e,local_n:target.n,yaw_deg:0});a.step();a.step();}
        const actual=h.habitat.habitatCandidates(h.catalog,h.env(),'1812');
        return {season,time:current,epoch:a.terrain.epochId,samples,target,actual:actual.map(x=>({id:x.asset.id,mode:x.mode,anchor:x.anchor}))};
      },{season,date});
      assert.equal(result.epoch,'e1830_natural');
      if(season==='winter') assert(Object.values(result.samples).every(x=>!x.ids.length),'authored winter daytime is quiet');
      else {assert(result.target,`${season}: actual natural habitat admits a recording`);assert(result.actual.length,'native walker preserves real habitat eligibility');}
      if(season!=='summer'){
        assert(Object.values(result.samples).every(x=>!x.modes.includes('habitat-insects')));
        await page.waitForFunction(()=>!__chicago4d.sound.state.recorded.habitat.voices.some(x=>['summer-cicada-proxy','summer-crickets','late-summer-katydid'].includes(x)),null,{timeout:5000});
      }
      if(season==='summer'){
        await page.waitForFunction(()=>__chicago4d.sound.state.recorded.habitat.voices.includes('summer-cicada-proxy'),null,{timeout:45000,polling:100});
        result.integratedVoice=await page.evaluate(()=>__chicago4d.sound.state.recorded.habitat);
        assert.equal(result.integratedVoice.errors.length,0);
      }
      row.seasons.push(result);
    }
    await page.evaluate(async()=>{await __chicago4d.timeOfDay.set('15:00',{date:'1812-08-15'});});
    await page.waitForFunction(()=>!__chicago4d.sound.state.recorded.habitat.active&&!__chicago4d.sound.state.recorded.habitat.voices.length,null,{timeout:5000});
    row.checks.push({name:'native unsupported date suppresses seasonal habitat',date:'1812-08-15'});
    await page.evaluate(()=>{const a=__chicago4d;a.hud.settings.soundAmbience=0;a.hud.settings.soundEffects=1;a.sound.sync();});
    // Actual route data chooses the first view; no transport actor is injected.
    await page.evaluate(async detail=>{
      const a=__chicago4d;await a.season.set('summer');await a.timeOfDay.set('10:00');
      await a.townTransport.setTier(detail);
      const data=await(await fetch('../data/transport/driven/loops.json')).json();
      const row=data.rows.find(x=>x.id==='fort_wagon_loop_1812');
      const {routeFor}=await import('./js/transport-loop.js');const p=routeFor(row.route).at(row.initial_distance_m??0);
      a.walker.teleport({local_e:p.e+12,local_n:p.n,yaw_deg:270});a.step();a.step();await a.townTransport.ready();
      // Follow only through the ordinary walker hook; never move/pose the actor.
      window.__audio1812Follow=setInterval(()=>{
        const source=a.townTransport.audioSources.find(x=>x.id==='fort_wagon_loop_1812'),p=source?.anchors?.wagon;
        if(p)a.walker.teleport({local_e:p.x+12,local_n:-p.z,yaw_deg:270});
      },1000);
    },detail);
    row.hooves=[];
    for(const season of ['summer','winter']){
      await page.evaluate(async season=>{await __chicago4d.season.set(season);await __chicago4d.timeOfDay.set('10:00');},season);
      await page.waitForFunction(()=>__chicago4d.sound.state.recorded.transport.contactVoices>0,null,{timeout:60000,polling:25});
      const proof=await page.evaluate(()=>({audio:__chicago4d.sound.state.recorded.transport,sources:__chicago4d.townTransport.audioSources,
        time:__chicago4d.timeOfDay.current,season:__chicago4d.season.current}));
      assert.equal(proof.audio.voiceLimit,6);assert.equal(proof.audio.decodedByteLimit,10*1024*1024);
      assert(proof.audio.voices.length<=6&&proof.audio.peakDecodedBytes<=10*1024*1024);
      assert.equal(proof.audio.contactTracker.queuedEvents,0);assert.equal(proof.audio.contactDecodedBytes,55296);
      assert(proof.audio.contacts.some(x=>x.snowCover===(season==='winter'?1:0)&&Math.abs(x.lowpassHz-(season==='winter'?900:18000))<1e-6));
      assert(proof.sources.some(x=>x.id==='fort_wagon_loop_1812'&&x.moving));assert.deepEqual(proof.audio.errors,[]);
      row.hooves.push(proof);await screenshot(`fort-team-${season}`);
    }
    for(const id of ['horse-walking','summer-cicada-proxy'])assert(row.requests.includes(catalog.assets.find(x=>x.id===id)?.url),`exact hosted recording requested: ${id}`);
    await page.evaluate(()=>{clearInterval(window.__audio1812Follow);delete window.__audio1812Follow;});
    // Explicit external adapter keeps work coverage independently reviewable.
    assert(process.env.AUDIO_1812_WORK_ADAPTER,'Set AUDIO_1812_WORK_ADAPTER to reviewed external native-work check module');
    report.workAdapterSha256=sha(await fs.readFile(path.resolve(process.env.AUDIO_1812_WORK_ADAPTER)));
    const {checkWork}=await import(path.resolve(process.env.AUDIO_1812_WORK_ADAPTER));
    row.work=await checkWork({page,screenshot,reportDirectory:out,width});
    assert(row.requests.includes(catalog.assets.find(x=>x.id==='hammer-nail')?.url),'exact hosted hammer recording requested');
    await page.evaluate(()=>{const a=__chicago4d;a.hud.settings.soundMaster=0;a.sound.sync();});
    await page.waitForFunction(()=>{const s=__chicago4d.sound.state;return s.silent&&!s.recorded.transport.voices.length&&!s.recorded.habitat.voices.length&&!s.recorded.work.voices.length;},null,{timeout:5000});
    row.muted=await page.evaluate(()=>__chicago4d.sound.state);
    // Native visibility event handler exercised explicitly; this is a lifecycle
    // fixture, not a claim that the operating system backgrounded this tab.
    await page.evaluate(()=>{__chicago4d.hud.settings.soundMaster=1;__chicago4d.sound.sync();});
    await page.waitForFunction(()=>!__chicago4d.sound.state.silent,null,{timeout:5000});
    await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'));});
    assert(await page.evaluate(()=>{const s=__chicago4d.sound.state;return s.silent&&!s.recorded.transport.voices.length&&!s.recorded.habitat.voices.length&&!s.recorded.work.voices.length;}));
    await page.evaluate(()=>{delete document.hidden;__chicago4d.hud.settings.soundMaster=0;document.dispatchEvent(new Event('visibilitychange'));});
    assert.deepEqual(row.pageErrors,[]);assert.deepEqual(row.badMedia,[]);assert.deepEqual(row.missingFiles,[]);
    assert.deepEqual(await fs.readFile(path.join(published,'build.json')),buildBytes,'publication build must remain immutable');
    assert.deepEqual(await fs.readFile(path.join(published,'walk/audio/catalog.json')),catalogBytes,'catalog must remain immutable');
    assert.deepEqual(await codeHashes(),publishedCodeHashes,'published integration code must remain immutable');
    row.passed=true;
  } catch(e) {
    row.error=e.stack;
    // Failure evidence is best-effort and bounded; never replace the original
    // assertion or wait indefinitely on a page whose render thread is blocked.
    const deadline=Date.now()+10000;
    const bounded=async(promise,ms)=>{
      let timer;
      try{return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error(`Diagnostic timeout after ${ms}ms`)),ms);})]);}
      finally{clearTimeout(timer);}
    };
    if(page&&!page.isClosed()) {
      try {
        row.failureDiagnostic=await bounded(page.evaluate(()=>{
          const a=window.__chicago4d;
          const clip=(v,depth=0)=>{
            if(v==null||typeof v==='boolean'||typeof v==='number')return v;
            if(typeof v==='string')return v.slice(0,1200);
            if(depth>=5)return '[depth limit]';
            if(Array.isArray(v))return v.slice(0,32).map(x=>clip(x,depth+1));
            if(typeof v==='object')return Object.fromEntries(Object.entries(v).slice(0,32).map(([k,x])=>[k,clip(x,depth+1)]));
            return String(v).slice(0,120);
          };
          const read=fn=>{try{return clip(fn());}catch(err){return{diagnosticError:String(err).slice(0,500)};}};
          const position=o=>o?{x:o.x,y:o.y,z:o.z}:null;
          const id='hi_town_chicago_militia_unnamed_4_1812';
          return {
            ready:a?.ready,error:a?.error,detail:a?.detail,season:a?.season?.current,
            time:read(()=>a?.timeOfDay?.current),journey:a?.journey?.state,welcome:a?.welcome?.state,
            documentHidden:document.hidden,drawsHeld:!!window.__audio1812Render,
            problems:read(()=>a?.problems),
            work:read(()=>a?.workActivity?.state),
            naturalWork:read(()=>a?.days?.workSource?.(id)),
            workSources:read(()=>a?.workActivity?.audioSources),
            actor:read(()=>{
              const x=a?.humans?.get?.(id);if(!x)return null;
              return{id:x.id,state:x.state,e:x.e,n:x.n,heading:x.heading,disposed:x.disposed,
                indoors:x.indoors,inRange:x.inRange,distance:x.distance,lod:x.lod,
                path:!!x.path,route:!!x.route,tow:!!x.tow,counters:x.counters,
                root:{visible:x.root?.visible,position:position(x.root?.position)},
                bodyLoaded:!!x.body,bodyVisible:x.body?.scene?.visible,oneShot:!!x.body?.oneShot,
                clip:x.clipName,actionTime:x.body?.action?.time,actionsBound:x.actions?.bound,
                peopleShown:a.humans.shown,held:a.humans.isHeld?.(x)};
            }),
            confidence:read(()=>a?.confidence?.hidden),
            audio:read(()=>a?.sound?.state),
            transport:read(()=>a?.townTransport?.audioSources?.slice(0,6).map(s=>({
              id:s.id,scene:s.scene,moving:s.moving,speed:s.speed,
              // Do not materialize the lazy hoof getter merely for diagnostics.
              anchors:s.anchors?{wagon:s.anchors.wagon,harness:s.anchors.harness}:null,
            }))),
            walker:read(()=>a?.walker?.state),
          };
        }),4500);
      } catch(diagError) {row.failureDiagnosticError=String(diagError);}
      const remaining=deadline-Date.now();
      if(remaining>250) {
        const file=path.join(out,`${width}-failure.png`);
        try {
          await bounded(page.screenshot({path:file,timeout:remaining-100}),remaining);
          row.failureScreenshot={file,drawsHeld:row.failureDiagnostic?.drawsHeld??null,
            note:'Best-effort failure capture; draws may be held. Not a fresh rendered-frame or visual-quality assertion.'};
        } catch(shotError) {row.failureScreenshotError=String(shotError);}
      }
    }
    throw e;
  }
  finally {
    if(page&&!page.isClosed())await page.evaluate(()=>{clearInterval(window.__audio1812Follow);if(window.__audio1812Render){__chicago4d.renderer.render=__audio1812Render;delete window.__audio1812Render;}delete document.hidden;__chicago4d.sound?.dispose();}).catch(()=>{});
    await browser.close();await fs.writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
  }
}
console.log('PUBLISHED 1812 CHECK PASS: native data/audio assertions and separate screenshots; no physical-listening or screenshot-quality claim.');
