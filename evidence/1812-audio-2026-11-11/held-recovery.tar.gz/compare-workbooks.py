import io, json, subprocess
from pathlib import Path
import openpyxl
root=Path('/workspace/chicago')
report=[]
for name in subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines():
 if not name.endswith('.xlsx'): continue
 old_bytes=subprocess.check_output(['git','show','HEAD:'+name],cwd=root)
 a=openpyxl.load_workbook(io.BytesIO(old_bytes)); b=openpyxl.load_workbook(root/name)
 assert a.sheetnames==b.sheetnames,name
 count=0
 for sa,sb in zip(a,b):
  assert sa.max_row==sb.max_row and sa.max_column==sb.max_column,(name,sa.title,'size')
  assert str(sa.merged_cells)==str(sb.merged_cells),(name,sa.title,'merged')
  for ra,rb in zip(sa,sb):
   for ca,cb in zip(ra,rb):
    fields=lambda c:(c.value,c.data_type,c.number_format,str(c.font),str(c.fill),str(c.border),str(c.alignment),str(c.protection),c.hyperlink.target if c.hyperlink else None,c.comment.text if c.comment else None)
    assert fields(ca)==fields(cb),(name,sa.title,ca.coordinate)
    count+=1
  for attr in ('freeze_panes','print_area','sheet_state'):
   assert str(getattr(sa,attr))==str(getattr(sb,attr)),(name,sa.title,attr)
  for attr in ('row_dimensions','column_dimensions'):
   va,vb=getattr(sa,attr),getattr(sb,attr)
   assert set(va)==set(vb),(name,sa.title,attr)
   for k in va: assert dict(va[k])==dict(vb[k]),(name,sa.title,attr,k)
 report.append({'path':name,'cells':count,'semantic_match':True})
print(json.dumps(report,indent=2))
