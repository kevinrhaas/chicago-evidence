from pathlib import Path
import subprocess,json
P=Path(__file__).resolve().parent
A=Path('/tmp/lake-house-source-20261103/chicago/4d')
commands=[['python','tools/compile_pictures.py'],['python','tools/compile_scene.py','--scene','1835'],['python','tools/compile_source_use.py'],['python','tools/grade_structures.py','--check'],['node','tools/changelog-entries.mjs','--check'],['python','tools/replace_invented_residents.py','--self-test'],['python','tools/validate.py','--all']]
rows=[]
for i,c in enumerate(commands,1):
 label='integration92bee-owner'+str(i)
 subprocess.run(['python',str(P/'run_native.py'),'--cwd',str(A),'--label',label,'--timeout','600','nice','-n','19','taskset','-c','2',*c],check=True)
 rows.append(json.loads((P/(label+'-REAPER.json')).read_text()))
(P/'INTEGRATION92BEE-OWNERS.json').write_text(json.dumps(rows,indent=2)+'\n')
print('All seven integration owners including actual validate --all PASS')
