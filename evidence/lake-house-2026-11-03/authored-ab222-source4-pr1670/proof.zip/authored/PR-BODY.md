Lake House’s Images tab gains a credited public-domain picture titled “Old Fort Dearborn — later completed Lake House, about 1836–1849.” The source record identifies the 1856 Kellogg/Blanchard print, credits NYPL’s collection through its Commons scan, and records the direct NYPL catalog access limitation.

This is incremental progress on original T-2379. The picture shows the later completed hotel; the July 1835 construction phase and its inferred grade are preserved. No camera or building match is claimed. The original ticket stays open with no completion PR bound to it.

Validation:

- All four native source parts passed: 462.311 / 350.513 / 259.859 / 311.581 seconds. Exact source guards and all child-process reapers passed. Both native PR-only checks also passed.
- Six focused native owners and both JSON schemas passed. Actual whole-tree Pictures join: 0 → 1; grade: inferred → inferred.
- Root independently reviewed the source identity and frozen change; model bytes and all other structure fields match the base.
- Draft until current-head published desktop/390×780 card review, native runtime checks and required hosted checks pass.

Applied-source checkpoint: https://github.com/kevinrhaas/chicago-evidence/blob/18e97fd849afc59672bc80c7b9d860b9f522d994/evidence/lake-house-2026-11-03/applied-source13-485c-before-full-gates/RECOVERY.md
