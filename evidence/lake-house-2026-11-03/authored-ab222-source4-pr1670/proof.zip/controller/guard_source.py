"""Check exact frozen source bytes/path scope and semantic staged index; no source writes."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
P=Path(__file__).resolve().parent;R=Path('/tmp/lake-house-source-20261103');F=Path('/tmp/lake-house-source13-frozen-20261103');f=json.loads((F/'SCOPE.json').read_bytes());E=os.environ.copy()
for k in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','CHICAGO_TICKETS_DIR']:E.pop(k,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
git=lambda *a:subprocess.check_output(['/usr/local/bin/git','-C',str(R),*a],env=E)
paths={r['path']:r for r in f['tracked_authored_and_derived_paths']};assert len(paths)==13
for rel,row in paths.items():
 b=(R/rel).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],rel
names=set()
for args in [('diff','--name-only','-z'),('diff','--cached','--name-only','-z'),('ls-files','--others','--exclude-standard','-z')]:names.update(os.fsdecode(v)for v in git(*args).split(b'\0')if v)
assert names==set(paths),names^set(paths);assert git('rev-parse','HEAD').decode().strip()==f['head'];assert git('branch','--show-current').decode().strip()==f['branch'];assert not git('diff','--name-only').strip();assert hashlib.sha256((R/'.git/config').read_bytes()).hexdigest()==f['own_git_metadata_sha256']['config'];index=git('ls-files','--stage','-z');digest=hashlib.sha256(index).hexdigest();expected=P/'EXPECTED-INDEX-ENTRIES.sha256'
if expected.exists():assert expected.read_text().strip()==digest,'Semantic staged index changed'
else:
 assert '--initialize' in sys.argv;expected.write_text(digest+'\n')
for rel,digest2 in f['model_bodies_unchanged'].items():assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==digest2,rel
r={'all13_frozen_bytes_exact':True,'no_unexpected_tracked_or_untracked_source_paths':True,'all13_staged_no_unstaged_change':True,'head':f['head'],'branch':f['branch'],'semantic_index_entries_sha256':digest,'raw_index_sha256':hashlib.sha256((R/'.git/index').read_bytes()).hexdigest(),'source_config_exact':True,'model_bodies_exact':True}
if '--output' in sys.argv:
 path=Path(sys.argv[sys.argv.index('--output')+1]);assert not path.exists();path.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
