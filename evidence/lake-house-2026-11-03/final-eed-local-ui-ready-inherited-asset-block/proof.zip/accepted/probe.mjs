/** One real default world, elevated actual Wolf mesh body, unchanged native frustum/lifecycle. */
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire('/workspace/shared/node/node_modules/playwright/package.json');
const { chromium } = require('playwright');
const plan = JSON.parse(fs.readFileSync(process.env.GT_PROBE_PLAN));
const out = process.env.GT_PROBE_OUT, viewport = process.env.GT_PROBE_VIEWPORT;
assert(['desktop', 'mobile'].includes(viewport)); assert(out); fs.mkdirSync(out);
const mobile = viewport === 'mobile', root = plan.site_parent;
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const save = (name, value) => fs.writeFileSync(path.join(out, name), JSON.stringify(value, null, 2) + '\n');
const errors = [], network = [], cancelled = [], consoleErrors = [], serverErrors = [];
const guard = () => { for (const [name, binding] of Object.entries(plan.input_bindings)) assert.equal(sha(fs.readFileSync(name)), binding.sha256, name); };
const types = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json', '.css': 'text/css', '.wasm': 'application/wasm', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.glb': 'model/gltf-binary', '.ktx2': 'image/ktx2', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };
const server = http.createServer((req, res) => {
  try {
    let file = path.resolve(root, '.' + decodeURIComponent(new URL(req.url, 'http://localhost').pathname));
    if (!file.startsWith(root + path.sep)) { res.writeHead(403).end(); return; }
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404).end(); return; }
    res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
    fs.createReadStream(file).on('error', e => { serverErrors.push(e.message); res.destroy(e); }).pipe(res);
  } catch (e) { serverErrors.push(e.message); res.writeHead(500).end(); }
});
let browser, context, page, lakeCard=null, failure=null;
const started = performance.now();
try {
  guard();
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const proxyUrl = process.env.HTTPS_PROXY ?? process.env.HTTP_PROXY;
  const proxy = proxyUrl ? (() => { const p = new URL(proxyUrl); return { server: p.origin, bypass: '127.0.0.1,localhost', username: decodeURIComponent(p.username) || undefined, password: decodeURIComponent(p.password) || undefined }; })() : undefined;
  process.env.PLAYWRIGHT_DISABLE_FORCED_CHROMIUM_PROXIED_LOOPBACK = '1';
  browser = await chromium.launch({ executablePath: '/usr/bin/chromium', proxy, args: ['--no-sandbox', '--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader'] });
  context = await browser.newContext({ viewport: { width: mobile ? 390 : 1280, height: mobile ? 780 : 800 }, hasTouch: mobile, isMobile: false, deviceScaleFactor: mobile ? 2 : 1 });
  page = await context.newPage(); page.setDefaultTimeout(90000);
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') consoleErrors.push(m.text()); });
  page.on('requestfailed', r => (r.failure()?.errorText === 'net::ERR_ABORTED' ? cancelled : network).push({ url: r.url(), failure: r.failure() }));
  page.on('response', r => { if (r.status() >= 400) network.push({ url: r.url(), status: r.status() }); });
  await context.addInitScript(() => { localStorage.setItem('chicago4d.researcher', 'on'); localStorage.setItem('chicago4d.settings', JSON.stringify({ detail: 'full' })); });
  assert.equal((await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835`)).status(), 200);
  await page.waitForFunction(() => window.__chicago4d?.ready === true, null, { timeout: 240000, polling: 1000 });
  await page.evaluate(async () => {
    const a = window.__chicago4d, end = Date.now() + 90000;
    while (a.welcome?.state !== 'world' && Date.now() < end) {
      if (a.welcome?.state === 'welcome') a.welcome.enter('spawn');
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    if (a.welcome?.state !== 'world') throw Error('Welcome did not enter world');
    document.exitPointerLock?.(); document.getElementById('control-help-gotit')?.click();
    a.setAnimationHold(true); a.setFloraSpread(true); a.popup.close(); a.navigator.dock();
  });
  const baseline = await page.evaluate(() => { const a = window.__chicago4d; return { frame: a.renderer.info.render.frame, ready: a.ready, welcome: a.welcome.state, visible: document.visibilityState, contextLost: a.renderer.getContext().isContextLost(), detail: a.detail }; });
  save('WORLD-SETTLE.json', { status: 'WAITING', baseline, native_counter_advances_required: 3, bound_ms: 180000 });
  assert(baseline.ready && baseline.welcome === 'world' && baseline.visible === 'visible' && !baseline.contextLost && Number.isSafeInteger(baseline.frame));
  await page.waitForFunction(start => {
    const a = window.__chicago4d;
    if (a.renderer.getContext().isContextLost()) throw Error('Native WebGL context lost');
    if (!a.ready || a.welcome.state !== 'world' || document.visibilityState !== 'visible') throw Error('World readiness changed');
    return Number.isSafeInteger(a.renderer.info.render.frame) && a.renderer.info.render.frame >= start + 3;
  }, baseline.frame, { timeout: 180000, polling: 500 });
  const settled = await page.evaluate(() => window.__chicago4d.renderer.info.render.frame);
  assert(settled >= baseline.frame + 3);
  save('WORLD-SETTLE.json', { status: 'PASS', baseline, settled, native_counter_advances_required: 3, bound_ms: 180000, scope: 'Renderer counter only; no FPS or GPU-readback timing claim' });

  await page.evaluate(()=>{const a=window.__chicago4d;a.pick('lake_house_construction');document.querySelector('#popup [data-pop-tab="evidence"]')?.click();});
  await page.waitForFunction(()=>window.__chicago4d.popup.picturesDoc?.by_structure?.lake_house_construction?.length===1,null,{timeout:20000});
  await page.waitForFunction(()=>window.__chicago4d.popup.openId==='lake_house_construction'&&[...document.querySelectorAll('#popup .pop-facts dt')].some(e=>e.textContent.trim().toLowerCase()==='grade'&&(e.nextElementSibling?.textContent??'').trim().toLowerCase().startsWith('inferred')),null,{timeout:20000});
  lakeCard=await page.evaluate(()=>{
    const a=window.__chicago4d,popup=document.querySelector('#popup');const rows=a.popup.picturesDoc.by_structure.lake_house_construction;
    const grade=[...popup.querySelectorAll('.pop-facts dt')].find(e=>e.textContent.trim().toLowerCase()==='grade')?.nextElementSibling?.textContent.trim()??'';
    const noPreload=popup.querySelectorAll('[data-pop-pane="images"] img[src]').length===0;document.querySelector('#popup [data-pop-tab="images"]')?.click();
    const items=[...popup.querySelectorAll('[data-pop-pane="images"] .pop-pic-list li,[data-pop-pane="images"] .pop-pic-tile')];
    return {id:a.popup.openId,rows,grade,noPreload,item_count:items.length,tab_count:popup.querySelector('[data-pop-tab="images"] .pop-count')?.textContent.trim(),credits:items.map(e=>({text:e.textContent.trim(),credit:e.querySelector('.pop-pic-meta,.pop-pic-tile-credit')?.textContent.trim()??'',href:e.querySelector('a')?.href??null}))};
  });
  assert(lakeCard.id==='lake_house_construction'&&lakeCard.noPreload&&lakeCard.item_count===1&&lakeCard.tab_count==='1');assert.deepEqual(lakeCard.rows,plan.expected_lake_pictures);assert(lakeCard.grade.toLowerCase().startsWith('inferred'));
  const picture=lakeCard.rows[0];assert(picture.id===plan.picture_source_id&&!picture.spot&&!picture.held);assert(picture.rights==='public domain'&&picture.date==='1856');assert(picture.title.includes('later completed Lake House')&&picture.title.includes('1836–1849'));assert(lakeCard.credits.every(e=>e.credit),'Actual linked picture must show credit');
  const link=page.locator('#popup [data-pop-pane="images"] a').filter({hasText:picture.title});assert.equal(await link.count(),1);await link.scrollIntoViewIfNeeded();await link.evaluate(el=>el.closest('li,.pop-pic-tile').scrollIntoView({block:'center'}));
  const visible=await link.evaluate(el=>{const r=el.getBoundingClientRect(),c=el.closest('li,.pop-pic-tile')?.querySelector('.pop-pic-meta,.pop-pic-tile-credit'),cr=c?.getBoundingClientRect();return {href:el.href,text:el.textContent,credit:c?.textContent,linkVisible:r.width>0&&r.height>0&&r.top>=0&&r.bottom<=innerHeight,creditVisible:!!cr&&cr.width>0&&cr.height>0&&cr.top>=0&&cr.bottom<=innerHeight};});assert(visible.linkVisible&&visible.creditVisible&&visible.href===picture.url);assert(visible.credit.includes('1856')&&visible.credit.includes('Kellogg')&&visible.credit.includes('New York Public Library'));lakeCard.visible=visible;
  await page.screenshot({path:path.join(out,'lake-images.jpg'),type:'jpeg',quality:92});save('LAKE-CARD.json',lakeCard);
  const recordTab=page.locator('#popup [data-pop-tab="record"]');await recordTab.scrollIntoViewIfNeeded();await recordTab.click();const summary=page.locator('#popup [data-pop-pane="record"] details.research summary');await summary.scrollIntoViewIfNeeded();await summary.click();
  const research=await page.evaluate(expected=>{const pane=document.querySelector('#popup [data-pop-pane="record"]'),p=pane.querySelector('.research-body'),details=pane.querySelector('details.research');return {shown:!pane.hidden,open:details.open,text:p.textContent,expected};},plan.expected_research_note);assert(research.shown&&research.open&&research.text===research.expected);assert(research.text.includes('LATER COMPLETED-STATE PICTURE')&&research.text.includes('unfinished July 1835 shell'));save('LAKE-NATIVE-READER.json',research);await page.screenshot({path:path.join(out,'lake-research.jpg'),type:'jpeg',quality:92});
  for(const list of [errors,network,consoleErrors,serverErrors])assert.equal(list.length,0,JSON.stringify(list));guard();save('RESULT.json',{status:'ACTUAL_FINAL_LAKE_CONTEXT_CARD_READER_PASS',viewport,head:plan.expected_head,qualified_source_scope_sha256:plan.source_scope_sha256,lakeCard,phase:plan.expected_phase,target_date:plan.expected_target,grade:'inferred',errors,network,cancelled,consoleErrors,serverErrors,wall_ms:performance.now()-started,no_retry:true,scope:'Actual published default1835 world and linked later-state picture/card/native reader. No solved geographic picture camera, historical construction match, new geometry or original-ticket completion.'});
} catch(e) {
  failure={message:e.message,stack:e.stack};
  if(page){try{await page.screenshot({path:path.join(out,'FAIL.jpg'),type:'jpeg',quality:90});}catch(x){failure.screenshot_error=x.message;}}
  save('FAILURE.json',{failure,errors,network,cancelled,consoleErrors,serverErrors});
} finally {
  if(context)try{await context.close();}catch(e){failure??={message:e.message};}
  if(browser)try{await browser.close();}catch(e){failure??={message:e.message};}
  if(server.listening)await new Promise(resolve=>server.close(resolve));
  save('CLOSURE.json',{failure,errors,network,cancelled,consoleErrors,serverErrors,no_retry:true});
}
if(failure)process.exitCode=1;
