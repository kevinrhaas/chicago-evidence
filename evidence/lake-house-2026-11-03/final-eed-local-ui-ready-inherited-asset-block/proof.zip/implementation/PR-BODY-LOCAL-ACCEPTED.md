Lake House’s Images tab gains a credited public-domain link titled “Old Fort Dearborn — later completed Lake House, about 1836–1849.” The SourceRecord identifies the 1856 Kellogg/Blanchard print, credits NYPL through its Commons scan, and records the direct NYPL catalog access limitation.

This is partial progress on original T-2379. The later finished hotel supplies context; the July 1835 construction phase, model bytes and inferred grade are preserved. No camera, geometric match or original-ticket completion is claimed.

A separate explicit CI commit reuses the exact one-line checkout fix from [PR #1669](https://github.com/kevinrhaas/chicago/pull/1669), shared commit `54bbf95efa1c7f4a87dd807e2e4d38427f0a75d8`: `filter: blob:none`. It retains `fetch-depth: 0`, the complete current checkout, assertions and TLS behavior. The whole `chicago/` app/reference subtree is byte-identical before and after that CI commit.

Validation:

- Four native source parts passed on the exact authored change: 462.311 / 350.513 / 259.859 / 311.581 seconds. Both native PR-only checks passed.
- Normal dev integration through `073a337` preserved all six authored Lake House bodies and models; seven focused integration checks passed. The three affected workflow self-tests also passed.
- Final head `eedbe16`: actual published desktop1280×800 and phone390×780 Images1/full credit/date/context and native reader checks passed. Both reviewers inspected the actual screenshots. Official Stage3 passed107/0 at each viewport; every qualified run has complete guards and reapers. The interrupted old desktop run is retained separately; a fresh desktop-only107/0 run closed correctly.

CI remains blocked by one inherited asset error, independently confirmed by `validate.py --all`: Mayer2009’s mesh is stale. A genuine targeted production bake is underway in the shared repair branch. No assertion or asset hash is bypassed; this PR must not merge until the required hosted gate passes.

Source4 and actual authored push proof: https://github.com/kevinrhaas/chicago-evidence/blob/07bb7fda07d362d01c000aa39b0d795757777685/evidence/lake-house-2026-11-03/authored-ab222-source4-pr1670/RECOVERY.md
