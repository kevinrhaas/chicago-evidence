import ast,json,datetime as dt,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent;B=D/'chicago/4d';build=B/'generators/build.py';t=ast.parse(build.read_text());f=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='resolve_phase');ns={'dt':dt};exec(compile(ast.Module(body=[f],type_ignores=[]),str(build),'exec'),ns)
record=json.loads((B/'data/structures/lake_house_construction.json').read_text());later={'id':record['id'],'phases':[{'id':'completed_context_only','documented_range':{'from':'1837-01-01','to':'1849-12-31'}}]};out={}
for p in sorted((B/'data/scenes').glob('*.json')):
 scene=json.loads(p.read_text());date=dt.date.fromisoformat(scene['target_date']);a=ns['resolve_phase'](record,date);b=ns['resolve_phase'](later,date);out[p.stem]={'date':str(date),'current_phase':a['id'] if a else None,'hypothetical_later_phase':b['id'] if b else None}
assert all(r['hypothetical_later_phase'] is None for r in out.values());assert out['1835']['current_phase']=='shell_1835'
proof={'native_resolve_phase_AST_exact':True,'build_file_sha256':hashlib.sha256(build.read_bytes()).hexdigest(),'hypothetical_later_date_window_not_a_proposed_historical_record':['1837-01-01','1849-12-31'],'results':out,'conclusion':'A correctly later-dated version has no reachable committed scene, so targeted bake cannot build it merely by adding a version. Do not backdate it into 1835.'};(D/'prepared/NATIVE-VERSION-DATE-PROOF.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
