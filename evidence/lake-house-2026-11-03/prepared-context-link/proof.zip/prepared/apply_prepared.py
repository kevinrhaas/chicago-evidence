"""Apply six closed prepared bodies to an independently owned checkout; never applies by default."""
import argparse,hashlib,json
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('checkout',type=Path);ap.add_argument('--apply',action='store_true');args=ap.parse_args();P=Path(__file__).resolve().parent;manifest=json.loads((P/'MANIFEST.json').read_text());plan=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
for row in manifest['paths']:
 path=row['path'];target=args.checkout/path;new=(P/path).read_bytes();assert sha(new)==row['after_sha256'],path
 old=target.read_bytes() if target.exists() else b''
 if row['before_sha256'] is None:assert not target.exists(),f'new path already exists: {path}';result=new
 elif row['append_only']:
  baseline=(P/'BASELINES'/path).read_bytes();assert sha(baseline)==row['before_sha256'];assert old.startswith(baseline),f'base prefix changed; re-evaluate: {path}'
  addition=new[len(baseline):];assert addition not in old,f'already appended: {path}';result=old+addition
 else:assert sha(old)==row['before_sha256'],f'base changed; re-evaluate: {path}';result=new
 plan.append((target,result))
print(json.dumps({'mode':'APPLY' if args.apply else 'DRY RUN','paths':[str(t) for t,b in plan]},indent=2))
if args.apply:
 for target,result in plan:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(result)
