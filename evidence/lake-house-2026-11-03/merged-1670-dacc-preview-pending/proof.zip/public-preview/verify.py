"""Read-only public delivery verification; does not extend runtime proof scope."""
import argparse
import hashlib
import json
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
HEAD = "5603e2d6d1496d346d5fe61421b857ef4032df6f"
BASE = "https://chicago.polecat.live/4d/dev/"
PICTURES = "data/pictures/1835.json"
SIDECAR = "data/sidecars/1835/lake_house_construction.json"
MODELS = {"data/gltf/lake_house_construction__shell_1835.glb": "fc049e07a7d91931ea97a458968b46aec1881d3d0bc435b0fd90a62562e3ff0d"}


def api(path):
    return json.loads(subprocess.check_output(["gh", "api", "repos/kevinrhaas/chicago/" + path], text=True))


def get(path):
    with urlopen(Request(BASE + path + "?pr1670=" + str(time.time_ns()),
                         headers={"Cache-Control": "no-cache"}), timeout=45) as response:
        assert response.status == 200
        data = response.read(2_000_001)
    assert len(data) <= 2_000_000
    return data


def snapshot():
    stamp = get("build.json")
    paths = [PICTURES, SIDECAR, *MODELS]
    with ThreadPoolExecutor(max_workers=4) as pool:
        payloads = dict(zip(paths, pool.map(get, paths)))
    assert stamp == get("build.json"), "Public build changed during snapshot; repeat"
    return json.loads(stamp), {"build.json": stamp, **payloads}


parser = argparse.ArgumentParser()
parser.add_argument("--snapshot-before", action="store_true")
args = parser.parse_args()
if args.snapshot_before:
    build, payloads = snapshot()
    assert not json.loads(payloads[PICTURES])["by_structure"].get("lake_house_construction", [])
    output = ROOT / "before"
    output.mkdir(parents=True, exist_ok=True)
    for path, data in payloads.items():
        target = output / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    print(json.dumps({"status": "PREMERGE_PUBLIC_SNAPSHOT", "build": build["sha"], "lake_entries": 0}))
    raise SystemExit()

pr = api("pulls/1670")
assert pr["head"]["sha"] == HEAD, "Review scope changed"
if not pr["merged"]:
    print("NOT_MERGED_YET")
    raise SystemExit(20)
merge = pr["merge_commit_sha"]
build, payloads = snapshot()
assert build["tier"] == "dev" and build["ref"] == "refs/heads/dev"
comparison = api(f"compare/{merge}...{build['sha']}")
if comparison["behind_by"] or comparison["status"] not in ("ahead", "identical"):
    print("MERGED_NOT_DEPLOYED_YET", merge, build["sha"])
    raise SystemExit(21)
for path, expected in MODELS.items():
    assert hashlib.sha256(payloads[path]).hexdigest() == expected, path
pictures = json.loads(payloads[PICTURES])["by_structure"]
rows = pictures["lake_house_construction"]
assert len(rows) == 1
row = rows[0]
expected = json.loads(Path('/tmp/lake-final-eed-qa-20261103/PLAN.json').read_bytes())['expected_lake_pictures']
assert rows == expected
assert row['rights']=='public domain' and row['date']=='1856' and not row.get('held') and not row.get('spot')
assert all(term in row['title'] for term in ['later completed Lake House','1836–1849'])
assert 'Kellogg' in row['creator'] and 'Blanchard' in row['creator'] and 'New York Public Library' in row['holder']
sidecar = json.loads(payloads[SIDECAR]);assert sidecar['id']=='lake_house_construction' and sidecar['grade']['value']=='inferred'
assert sidecar['phase']=='shell_1835' and sidecar['target_date']=='1835-07-01'
assert 'LATER COMPLETED-STATE PICTURE' in sidecar['research_note'] and 'NOT JULY 1835 CONSTRUCTION EVIDENCE' in sidecar['research_note']
assert 'kellogg_blanchard_1856_old_fort_lake_house' in sidecar['research_note']
output = ROOT / ("after-" + build["sha"])
output.mkdir(exist_ok=True)
for path, data in payloads.items():
    target = output / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
result = {
    "status": "MERGED_AND_DEPLOYED_DEV_DELIVERY_VERIFIED",
    "at": datetime.now(timezone.utc).isoformat(),
    "pr": 1670, "reviewed_head": HEAD, "merge_commit": merge,
    "deployed_build": build, "deployed_descends_from_merge": True,
    "lake_entries": 1, "new_credited_source": row,
    "lake_grade": sidecar["grade"], "phase_shell1835_and_later_datewarning_verified": True,
    "files": {path: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
              for path, data in payloads.items()},
    "scope": "Public dev ancestry and static delivery only. Runtime proof remains scoped to actual eed browser acceptance with relevant5603 identity reuse; originalT2379 is partial, with no full image-match claim.",
}
text = json.dumps(result, indent=2) + "\n"
(output / "RESULT.json").write_text(text)
(ROOT / "RESULT.json").write_text(text)
print(json.dumps({"status": result["status"], "merge": merge, "build": build["sha"]}))
