from pathlib import Path
import hashlib, json, os, subprocess

D = Path(__file__).resolve().parent
repo = D / 'objects.git'
objects = json.loads((D / 'OBJECTS.json').read_bytes())
source = json.loads((D / 'VERIFIED-LOOSE-READY.json').read_bytes())
pack_dir = D / 'pack'
pack_dir.mkdir()
lines = ('\n'.join(sorted(objects)) + '\n').encode()
command = ['nice', '-n', '19', 'taskset', '-c', '2', 'git', '--git-dir', str(repo), 'pack-objects', '--window=0', '--depth=0', '--threads=1', '--compression=1', str(pack_dir / 'pack')]
result = subprocess.run(command, input=lines, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
pack_id = result.stdout.decode().strip()
pack = pack_dir / ('pack-' + pack_id + '.pack')
index = pack_dir / ('pack-' + pack_id + '.idx')
assert pack.exists() and index.exists()
v = subprocess.run(['nice', '-n', '19', 'taskset', '-c', '2', 'git', 'verify-pack', '-v', str(index)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
(D / 'VERIFY-PACK.txt').write_bytes(v.stdout + v.stderr)
verify = D / 'verify.git'
subprocess.run(['git', 'init', '--bare', '-q', str(verify)], check=True)
for path in [pack, index]:
    (verify / 'objects/pack' / path.name).symlink_to(path)
raw = subprocess.check_output(['nice', '-n', '19', 'taskset', '-c', '2', 'git', '--git-dir', str(verify), 'cat-file', '--batch'], input=lines)
offset = 0
for sha in sorted(objects):
    boundary = raw.index(b'\n', offset)
    header = raw[offset:boundary].decode().split()
    expected = objects[sha]
    assert header == [sha, expected['type'], str(expected['bytes'])], header
    begin = boundary + 1
    body = raw[begin:begin + expected['bytes']]
    assert hashlib.sha1(expected['type'].encode() + b' ' + str(len(body)).encode() + b'\0' + body).hexdigest() == sha
    offset = begin + expected['bytes']
    assert raw[offset:offset + 1] == b'\n'
    offset += 1
assert offset == len(raw)
base = json.loads((D / 'BASE-files.json').read_bytes())
tip = json.loads((D / 'TIP-files.json').read_bytes())
wolf_paths = {path: row for path, row in base.items() if '/reference_views/wolf_point_tavern/' in path}
assert all(tip[path]['sha'] == row['sha'] for path, row in wolf_paths.items())
renderers = {path: row for path, row in base.items() if path.startswith('chicago/4d/renderers/') and not path.endswith('/changelog.js')}
renderer_unchanged = {path: tip.get(path, {}).get('sha') == row['sha'] for path, row in renderers.items()}
unchanged_cobra = [path for path in base if path.startswith('chicago/4d/') and any(path.endswith(name) for name in ['data/structures/cobweb_castle.json', 'data/sidecars/1835/cobweb_castle.json', 'docs/RESEARCH/cobweb_castle.md', 'docs/ROADMAP.md', 'docs/STATUS.md'])]
same_cobra = {path: tip[path]['sha'] == base[path]['sha'] for path in unchanged_cobra}
file_rows = {path.name: {'path': str(path), 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in [pack, index]}
ready = {**source, 'pack': pack_id, 'pack_files': file_rows, 'packed_objects': len(objects), 'verify_pack_pass': True, 'fresh_pack_only_every_raw_object_readback_exact': True, 'native_low_CPU_pack_parameters': '--window=0 --depth=0 --threads=1 --compression=1, nice19, CPU2', 'all_unchanged_renderer_members_except_changelog': sum(renderer_unchanged.values()), 'changed_existing_renderer_members_except_changelog': [path for path, same in renderer_unchanged.items() if not same], 'all_existing_Wolf_reference_members_unchanged': len(wolf_paths), 'Cobra_already_landed_paths_unchanged': same_cobra, 'important_integration_note': 'BASE92bee to current dev includes actual Lake PR1670 plus possible changelog fold; authenticate bytes only. Existing native51K01 repair preserved. Preserve Wolf authored postimages and both STATUS/ROADMAP append blocks. No automatic application.'}
# Read only the sibling's explicitly closed receipt, never its active copy.
old_native = json.loads(Path('/tmp/wolf-source-copy-20261103/NATIVE20-D307-COMPATIBILITY.json').read_bytes())
native_rows = []
for row in old_native['rows']:
    path = row['path']
    if path in tip:
        actual = tip[path]['sha']
    else:
        actual = subprocess.check_output(['git', '--git-dir', str(repo), 'rev-parse', source['tip'] + ':' + path], text=True).strip()
    assert actual == row['expected_object'], path
    native_rows.append({'path': path, 'expected_object': row['expected_object'], 'tip_object': actual, 'exact': True})
vendor_prefix = 'chicago/4d/renderers/web/vendor/three-0.185.1/'
vendor_base = {p: e['sha'] for p,e in base.items() if p.startswith(vendor_prefix)}
vendor_tip = {p: e['sha'] for p,e in tip.items() if p.startswith(vendor_prefix)}
assert vendor_base == vendor_tip and len(vendor_tip) == 15
native_proof = {'base': source['base'], 'tip': source['tip'], 'rows': native_rows, 'vendor_members': vendor_tip, 'all20_exact_on_actual_tip': True, 'scope': 'Five tool/helper blobs plus all15 files under exact expected vendor subtree. Does NOT assert unchanged world renderer or final app UI.'}
(D / 'NATIVE20-TIP-COMPATIBILITY.json').write_text(json.dumps(native_proof, indent=2)+'\n')
ready['native20_unchanged'] = native_proof
(D / 'READY.json').write_text(json.dumps(ready, indent=2) + '\n')
print(json.dumps({'tip': ready['tip'], 'objects': len(objects), 'blob_bytes': ready['blob_bytes'], 'pack': pack_id, 'verify': 'PASS', 'all_objects_readback': 'PASS', 'changed_tip_paths': len(ready['changed_tip_blobs']), 'removed': list(ready['removed_paths']), 'Cobra_unchanged': same_cobra, 'pack_files': file_rows}), flush=True)
