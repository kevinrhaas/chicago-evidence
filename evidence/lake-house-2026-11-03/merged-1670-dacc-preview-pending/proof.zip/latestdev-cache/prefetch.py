"""Finite public-API recovery cache; never reads the active source or publication."""
from pathlib import Path
import base64, hashlib, json, os, subprocess

D = Path(__file__).resolve().parent
BASE = '92bee8bdb89a900a840bcd94e760bb8f21c757c2'
TIP = json.loads((D / 'initial-dev-api.json').read_bytes())['sha']
repo = D / 'objects.git'
assert not repo.exists()
subprocess.run(['git', 'init', '--bare', '-q', str(repo)], check=True)
subprocess.run(['git', '--git-dir', str(repo), 'config', 'gc.auto', '0'], check=True)
subprocess.run(['git', '--git-dir', str(repo), 'config', 'maintenance.auto', 'false'], check=True)
# Reuse only the closed, already-tested public metadata reconstruction functions.
helper = Path('/workspace/cobweb-resume-recovery-20261103/adopt_latest.py')
ns = {'__file__': str(helper)}
exec(helper.read_text().split('comparison =')[0], ns)
ns['P'] = D
ns['O'] = repo / 'objects'
objects = {}
def put(kind, raw, sha):
    assert ns['oid'](kind, raw) == sha
    ns['put'](kind, raw, sha)
    objects[sha] = {'type': kind, 'bytes': len(raw)}

def trees(tree_sha):
    tree = ns['api']('git/trees/' + tree_sha + '?recursive=1')
    assert not tree['truncated']
    directories = {'': {}}
    ids = {'': tree_sha}
    files = {}
    for entry in tree['tree']:
        parent, _, name = entry['path'].rpartition('/')
        directories.setdefault(parent, {})[name] = entry
        if entry['type'] == 'tree':
            directories.setdefault(entry['path'], {})
            ids[entry['path']] = entry['sha']
        else:
            files[entry['path']] = entry
    for path, children in directories.items():
        raw = b''
        for name, entry in sorted(children.items(), key=lambda item: (item[0] + ('/' if item[1]['type'] == 'tree' else '')).encode()):
            raw += entry['mode'].lstrip('0').encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(entry['sha'])
        put('tree', raw, ids[path])
    return files, len(directories)

comparison = json.loads((D / 'initial-compare-api.json').read_bytes())
assert comparison['ahead_by'] <= 16 and comparison['behind_by'] == 0
assert len(comparison['commits']) == comparison['ahead_by']
commits = [BASE, comparison['merge_base_commit']['sha']] + [row['sha'] for row in comparison['commits']]
# Include every immediate parent of this bounded comparison's commits.
parent_ids = []
for sha in dict.fromkeys(commits):
    data = ns['api']('git/commits/' + sha)
    parent_ids.extend(p['sha'] for p in data['parents'])
commits = list(dict.fromkeys(commits + parent_ids))
commit_rows = []
all_files = {}
for sha in dict.fromkeys(commits):
    data = ns['commit'](sha)
    raw = subprocess.check_output(['git', '--git-dir', str(repo), 'cat-file', 'commit', sha])
    assert ns['oid']('commit', raw) == sha
    objects[sha] = {'type': 'commit', 'bytes': len(raw)}
    files, count = trees(data['tree']['sha'])
    commit_rows.append({'commit': sha, 'tree': data['tree']['sha'], 'authenticated_tree_nodes': count, 'parents': [parent['sha'] for parent in data['parents']]})
    all_files[sha] = files
    print('Commit/tree authenticated', sha, count, flush=True)
old = all_files[BASE]
new = all_files[TIP]
changed = {path: row for path, row in new.items() if old.get(path, {}).get('sha') != row['sha']}
removed = {path: row for path, row in old.items() if path not in new}
assert len(changed) <= 200
assert all(row.get('size', 0) < 32 * 1024**2 for row in changed.values())
print('Finite blob budget', len(changed), sum(row.get('size', 0) for row in changed.values()), flush=True)
assert sum(row.get('size', 0) for row in changed.values()) < 128 * 1024**2
blob_rows = []
total = 0
for path, row in changed.items():
    assert row['type'] == 'blob'
    data = ns['api']('git/blobs/' + row['sha'])
    body = base64.b64decode(data['content'])
    assert len(body) == row['size'] and len(body) < 32 * 1024**2
    total += len(body)
    assert total < 128 * 1024**2
    put('blob', body, row['sha'])
    blob_rows.append({'path': path, 'git_blob': row['sha'], 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
    print('Tip blob authenticated', path, len(body), flush=True)
critical = [
    'chicago/4d/assets/gltf/wolf_point_tavern__log_frame_1828.glb',
    'chicago/4d/assets/web/wolf_point_tavern__log_frame_1828.glb',
    'chicago/4d/data/structures/wolf_point_tavern.json',
    'chicago/4d/data/sources/blanchard_davis_c1893_wolfs_point_poster.json',
    'chicago/4d/data/structures/cobweb_castle.json',
    'chicago/4d/data/sidecars/1835/cobweb_castle.json',
    'chicago/4d/docs/RESEARCH/cobweb_castle.md',
]
for path in critical:
    assert old[path]['sha'] == new[path]['sha'], path
renderer_changes = [path for path in changed if path.startswith('chicago/4d/renderers/') and not path.endswith('/changelog.js')]
result = {'base': BASE, 'tip': TIP, 'tip_tree': next(row['tree'] for row in commit_rows if row['commit'] == TIP), 'commits': commit_rows, 'changed_tip_blobs': blob_rows, 'removed_paths': removed, 'blob_bytes': total, 'per_blob_cap_bytes': 32 * 1024**2, 'total_blob_cap_bytes': 128 * 1024**2, 'all_object_ids_authenticated': True, 'critical_unchanged': {path: new[path]['sha'] for path in critical}, 'shared_renderer_changes_except_changelog': renderer_changes, 'inherited_pending_changelog_removed_on_dev': 'chicago/4d/changelog.d/T-2374.json' in removed, 'scope': 'Public metadata and changed TIP blobs only, no active source/Git/index/ref/config/publication/ticket reads or mutations. No fetch/repack/GC. Cache does not apply changes.'}
(D / 'OBJECTS.json').write_text(json.dumps(objects, indent=2) + '\n')
(D / 'TIP-files.json').write_text(json.dumps(new) + '\n')
(D / 'BASE-files.json').write_text(json.dumps(old) + '\n')
(D / 'VERIFIED-LOOSE-READY.json').write_text(json.dumps(result, indent=2) + '\n')
print('Finite loose cache READY', len(objects), total, flush=True)
