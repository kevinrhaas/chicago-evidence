from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,subprocess,sys,shutil
P=Path('/workspace/chicago-pr1700-memory-constant-scalars-20261104');A=P/'chicago/4d';OUT=Path('/workspace/.cloud-setup/transport-current-20261103/actual-pr1700-final-G-prechecks-01');assert not OUT.exists()
lock=open('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('g','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
before=g.snapshot();assert g.check(before)['accepted'];OUT.mkdir();tmp=OUT/'owned-tmp';tmp.mkdir();env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(tmp),C4D_GATE_REQUIRE_BASE='1',C4D_GATE_REQUIRE_READERS='1',C4D_RULINGS_BASE='6eeeeaa26942efc79e7b822b387bdc3979adb939')
for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR','BASE','CHECK_PART','CHECK_TIMINGS']:env.pop(k,None)
meta=dict(env,GIT_NO_LAZY_FETCH='1');git=lambda *a:subprocess.check_output(['git','-C',str(P),*a],env=meta,timeout=45)
def source():
 t=git('write-tree').decode().strip();return dict(HEAD=git('rev-parse','HEAD').decode().strip(),TREE=t,APP=git('rev-parse',t+':chicago/4d').decode().strip(),MERGE_HEAD=git('rev-parse','MERGE_HEAD').decode().strip(),index=hashlib.sha256(git('ls-files','--stage','-z')).hexdigest(),status=git('status','--porcelain').decode())
original=source();ledger=[];error=None;save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n');save(OUT/'OWNER.json',dict(owner_pid=os.getpid(),source=original))
commands=[('materialize-all-original-inputs',['git','-C',str(P),'-c','gc.auto=0','-c','maintenance.auto=false','sparse-checkout','disable'],True),('syntax-smoke',['node','--check','tools/smoke_renderer.mjs'],False),('original-smoke-budget-selftest',['node','tools/smoke_budget.mjs','--self-test'],False),('strict-changelog',['node','tools/check-changelog.mjs'],False),('strict-history',['node','tools/changelog-history.mjs','--base',env['C4D_RULINGS_BASE']],False),('strict-rulings',['python3','tools/check_rulings_not_lost.py'],False),('whitespace',['git','diff','--cached','--check'],True)]
try:
 for name,cmd,is_meta in commands:
  rb=g.snapshot();assert g.check(rb)['accepted'];save(OUT/'STATE.json',dict(owner_pid=os.getpid(),phase=name,ledger=ledger));prefix=OUT/name
  subprocess.run([sys.executable,'/workspace/.cloud-setup/transport-supervise.py','--prefix',str(prefix),'--cwd',str(A),'--timeout','120','--',*cmd],env=meta if is_meta else env,check=False)
  r=json.loads(Path(str(prefix)+'.result.json').read_text());c=json.loads(Path(str(prefix)+'.cleanup.json').read_text());res=g.pair(rb,g.snapshot());ledger.append(dict(name=name,result=r,cleanup=c,resources=res));save(OUT/'LEDGER.json',ledger)
  assert r['returncode']==0 and not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==120 and r['timeout_override_reason']is None and c['cleanup_complete']and not c['remaining_owned_children']and res['accepted'],name
  assert source()==original,'Source drift'
 assert 'held to origin/dev at 6eeeeaa26' in (OUT/'strict-changelog.log').read_text()
except BaseException as e:error=repr(e)
res=g.pair(before,g.snapshot());stable=source()==original;safe=all(x['cleanup']['cleanup_complete']and not x['cleanup']['remaining_owned_children']for x in ledger)
if safe:shutil.rmtree(tmp)
passed=error is None and stable and safe and res['accepted'];save(OUT/'CLOSED.json',dict(passed=passed,error=error,source=original,source_unchanged=stable,ledger=ledger,resources=res,owned_tmp_removed=not tmp.exists()));print(json.dumps(dict(passed=passed,error=error,source=original)));sys.exit(0 if passed else 1)
