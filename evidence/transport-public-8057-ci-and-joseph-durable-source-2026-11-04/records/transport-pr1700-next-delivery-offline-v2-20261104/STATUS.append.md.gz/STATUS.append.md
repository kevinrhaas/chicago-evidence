

## Driver clothing delivery: lossless phone memory repair — 2026-11-04

The original 1904 phone measurement exposed a memory overage inherited from the unchanged DEV parent. An isolated descendant of PR1700’s public clothing head now stores an exactly repeated building scalar tuple once, while preserving every source vertex, shader, picking reader and original limit. Varying channels retain their original buffers. The existing native scalar suite and actual Three native/fallback WebGL controls pass, including byte-identical colour, roughness, confidence and depth frames and matching pick IDs/points.

The original 1904 mobile gate measured 418,757,056 bytes (399.358 MiB) against the unchanged 400 MiB limit, with 673,344 bytes (0.642 MiB) of headroom. Actual GPU storage fell by 4,767,776 bytes; texture storage stayed exact. This finite result belongs to staged TREE `05a2899f72a8628fcff0a765019de3f26b2295c3`, not the still-public `79e302ee4b8648b2b89e81ef504049010de4cb7e` or a later integrated source. The four clothing payloads and all other assets were unchanged in that measured comparison. Integration with the qualified interaction increment, the complete new native gate, exact-head CI and ordinary DEV delivery remain pending. T-2804/T-1790 remain claimed; photographic quality, continuous garment/contact fit and riding/boarding acceptance remain open.
