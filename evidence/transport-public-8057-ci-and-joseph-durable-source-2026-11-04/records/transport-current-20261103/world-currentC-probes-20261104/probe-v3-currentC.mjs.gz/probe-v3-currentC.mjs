import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {execSync} from 'node:child_process';
const APP='/workspace/chicago-driver-interaction-integration-20261104/chicago/4d';
const ROOT=path.resolve(APP,'../../site/4d'), OUT=process.argv[2], MODE=process.argv[3];
assert(OUT && ['light','shadow1904'].includes(MODE));
const smoke=fs.readFileSync(path.join(APP,'tools/smoke_renderer.mjs'),'utf8');
const report={mode:MODE,sourceSmokeSha256:crypto.createHash('sha256').update(smoke).digest('hex'),checks:[],errors:[],httpErrors:[]};
const save=()=>fs.writeFileSync(path.join(OUT,'PROBE.json'),JSON.stringify(report,null,2)+'\n');
const check=(name,pass,details)=>{report.checks.push({name,pass:!!pass,details});save();assert(pass,name+': '+details)};
const signatureDistance=new Function(smoke.slice(smoke.indexOf('function signatureDistance(a, b) {'),smoke.indexOf('\n/** Diagnostic bracket',smoke.indexOf('function signatureDistance(a, b) {')))+'; return signatureDistance;')();
const server=http.createServer((req,res)=>{const rel=decodeURIComponent(req.url.split('?')[0]);let file=path.join(ROOT,rel);if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');if(!file.startsWith(ROOT+'/')||!fs.existsSync(file)){res.writeHead(404);res.end(rel);return}res.setHeader('content-type',({'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.wasm':'application/wasm','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg'})[path.extname(file)]||'application/octet-stream');fs.createReadStream(file).pipe(res)});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let ns;try{ns=await import('playwright')}catch{ns=await import(path.join((process.env.NODE_PATH||execSync('npm root -g',{encoding:'utf8'})).trim().split(path.delimiter)[0],'playwright/index.js'))}const{chromium}=ns.chromium?ns:ns.default;
let browser;
try{
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE,args:['--enable-unsafe-swiftshader']});
 const ctx=await browser.newContext({viewport:{width:390,height:780},hasTouch:true,isMobile:false,deviceScaleFactor:2});
 const page=await ctx.newPage();page.setDefaultTimeout(90000);
 page.on('pageerror',e=>{report.errors.push(String(e));save()});page.on('console',m=>{if(m.type()==='error'){report.errors.push(m.text());save()}});page.on('response',r=>{if(r.status()>=400){report.httpErrors.push({status:r.status(),url:r.url()});save()}});
 const url=`http://127.0.0.1:${server.address().port}/walk/?keep-geometry=1`;
 await page.goto(url,{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>window.__chicago4d?.ready===true||!!window.__chicago4d?.error,null,{timeout:240000,polling:1000});
 check('1835 reaches ready',await page.evaluate(()=>window.__chicago4d?.ready===true));
 const contracts=await import('file://'+path.join(APP,'tools/world_smoke_contracts.mjs'));
 const bstart=smoke.indexOf('    const batchCensus = await page.evaluate(() => {');
 const bend=smoke.indexOf('    await page.evaluate(() => window.__chicago4d.setAnimationHold(true));',bstart);
 const batchCode=smoke.slice(bstart,bend);
 report.batchSourceSha256=crypto.createHash('sha256').update(batchCode).digest('hex');
 const constants={STRUCTURE_BATCHES:contracts.STRUCTURE_BATCH_KEYS.length,TEXTURED_STRUCTURE_BATCHES:Number(smoke.match(/const TEXTURED_STRUCTURE_BATCHES = ([0-9]+)/)[1]),ROUGHNESS_VALUES_MIN:Number(smoke.match(/const ROUGHNESS_VALUES_MIN = ([0-9]+)/)[1]),structureBatchContract:contracts.structureBatchContract};
 report.batchCensus=await new Function('page','check','label',...Object.keys(constants), 'return(async()=>{'+batchCode+';return batchCensus;})()')(page,check,'mobile 390x780',...Object.values(constants));save();
 const bootStart=smoke.indexOf('    const bootPose = await page.evaluate(() => {');
 const bootEnd=smoke.indexOf('    // Stand where the thresholds were measured.',bootStart);
 const bootCode=smoke.slice(bootStart,bootEnd);
 report.bootPoseSourceSha256=crypto.createHash('sha256').update(bootCode).digest('hex');
 report.bootPose=await new Function('page','return(async()=>{'+bootCode+';return bootPose;})()')(page);save();
 const estart=smoke.indexOf('  const enterTown = () => page.evaluate(async () => {');
 const eend=smoke.indexOf('  // A click on the HUD chrome',estart);
 const enterCode=smoke.slice(estart,eend);
 report.enterTownSourceSha256=crypto.createHash('sha256').update(enterCode).digest('hex');save();
 await new Function('page','return(async()=>{'+enterCode+';return enterTown();})()')(page);
 report.enteredTown=true;save();
 await page.exposeFunction('__worldProbeProgress',x=>{report.progress=x;save()});
 if(MODE==='light'){
  const dstart=smoke.indexOf('    const detail = await page.evaluate(async (stands) => {');
  const dend=smoke.indexOf('    for (const s of detail.seen) {',dstart);
  const originalDetail=smoke.slice(dstart,dend);
  report.detailOriginalSourceSha256=crypto.createHash('sha256').update(originalDetail).digest('hex');
  const standText=smoke.match(/  \{\n    id: 'prairie_west'[^]*?\n  \},/)[0].trim().replace(/,$/,'');
  const stands=new Function('return ['+standText+'];')();
  report.selectedStands=stands;report.selectedLevels=['full','light'];save();
  let detailCode=originalDetail.replace('for (const level of a.detailOrder) {',"for (const level of a.detailOrder.filter((level) => level === 'full' || level === 'light')) {");
  detailCode=detailCode.replace('        await a.setDetail(level);',"        await window.__worldProbeProgress({level,phase:'beforeSetDetail'});\n        await a.setDetail(level);\n        await window.__worldProbeProgress({level,phase:'afterSetDetail'});");
  detailCode=detailCode.replace('        await settle();',"        await settle();\n        await window.__worldProbeProgress({level,phase:'afterTierSettle'});");
  detailCode=detailCode.replace('          atStands.push(row);',"          atStands.push(row);\n          await window.__worldProbeProgress({level,phase:'baseline',row});");
  report.detailObservedSourceSha256=crypto.createHash('sha256').update(detailCode).digest('hex');save();
  report.detail=await new Function('page','STANDS','return(async()=>{'+detailCode+';return detail;})()')(page,stands);save();
  const full=report.detail.seen.find(x=>x.level==='full'),light=report.detail.seen.find(x=>x.level==='light');
  report.ratio={full:full.worstCalls.calls,light:light.worstCalls.calls,ratio:light.worstCalls.calls/full.worstCalls.calls};save();
  const cstart=smoke.indexOf('    const LIGHT_CALL_FLOOR = 5900;');
  const cend=smoke.indexOf('    // THE RIDGE DRAPE follows',cstart);
  const costChecks=smoke.slice(cstart,cend);
  report.costPredicatesSourceSha256=crypto.createHash('sha256').update(costChecks).digest('hex');save();
  new Function('check','label','full','light',costChecks)(check,'mobile 390x780',full,light);
 }else{
  report.shadow=[];
  const number=(name)=>Number(smoke.match(new RegExp('const '+name+' = ([0-9_]+);'))[1].replaceAll('_',''));
  const rigConstants=['SHADOW_REACH_LIGHT_M','SHADOW_REACH_M','SHADOW_MAP_LOW','SHADOW_MAP_FULL'];
  const rigCode=smoke.slice(smoke.indexOf('const shadowRigFor ='),smoke.indexOf('\n/**',smoke.indexOf('const shadowRigFor =')));
  const shadowRigFor=new Function(...rigConstants,rigCode+';return shadowRigFor;')(...rigConstants.map(number));
  const kstart=smoke.indexOf('    const rigLevel = await page.evaluate(() => window.__chicago4d.detail);');
  const kend=smoke.indexOf('    // --- R-BUG6, the shadow box',kstart);
  const originalKernel=smoke.slice(kstart,kend);
  report.shadowOriginalSourceSha256=crypto.createHash('sha256').update(originalKernel).digest('hex');
  const poseStart=smoke.indexOf('    const standAtBootPose = async () => {');
  const poseEnd=smoke.indexOf('\n\n',poseStart);
  const poseCode=smoke.slice(poseStart,poseEnd);
  report.shadowPoseSourceSha256=crypto.createHash('sha256').update(poseCode).digest('hex');save();
  for(const station of ['boot','lake_market']){
   const pose=station==='boot'?report.bootPose:await page.evaluate(()=>window.__chicago4d.scene.anchors.find(a=>a.id==='lake_market'));
   const standAtBootPose=()=>new Function('page','bootPose','return(async()=>{'+poseCode+';return standAtBootPose();})()')(page,pose);
   let kernel=originalKernel;
   for(const [variable,suffix]of [['reachFull','120'],['reachOld','60'],['reachBack','restored120']]){
    const line=kernel.split('\n').find(x=>x.includes('const '+variable+' ='));
    kernel=kernel.replace(line,line+"\n    await page.screenshot({path:shotPrefix+'-"+suffix+".png'});");
   }
   const startCheck=report.checks.length;
   const observeCheck=(name,pass,details)=>{report.checks.push({name,pass:!!pass,details});save()};
   const raw=await new Function('page','check','label','shadowRigFor','touch','standAtBootPose','ROAD_AID_GRID','SHADOW_REACH_MIN_WORST','signatureDistance','shotPrefix','return(async()=>{'+kernel+';return {rigLevel,rig,want,woundBack,restored,dReach,dReachBack,reachFull,reachOld,reachBack};})()')(page,observeCheck,'mobile 390x780 '+station,shadowRigFor,true,standAtBootPose,number('ROAD_AID_GRID'),number('SHADOW_REACH_MIN_WORST'),signatureDistance,path.join(OUT,station));
   report.shadow.push({station,pose,...raw,checks:report.checks.slice(startCheck)});save();
  }
  const pstart=smoke.indexOf('      const peopleMountSelector =');const pend=smoke.indexOf('      const door = wantPublished',pstart);
  const positive=smoke.slice(pstart,pend);report.positiveSourceSha256=crypto.createHash('sha256').update(positive).digest('hex');
  const peopleSelector=await new Function('page','check','label',`return(async()=>{${positive}; return peopleMountSelector;})()`)(page,check,'mobile 390x780');
  await page.goto(`http://127.0.0.1:${server.address().port}/1904/?keep-geometry=1`,{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>window.__chicago4d?.ready===true||!!window.__chicago4d?.error,null,{timeout:240000,polling:1000});check('1904 reaches ready',await page.evaluate(()=>window.__chicago4d?.ready===true));
  const dstart=smoke.indexOf('        const drawer = await page.evaluate((peopleSelector)');const dend=smoke.indexOf('        // >>> T-2667:',dstart);const drawerCode=smoke.slice(dstart,dend);report.drawerSourceSha256=crypto.createHash('sha256').update(drawerCode).digest('hex');
  report.drawer=await new Function('page','check','label','peopleMountSelector',`return(async()=>{${drawerCode}; return drawer;})()`)(page,check,'mobile 390x780',peopleSelector);save();
  report.publicPeopleOpen=await page.evaluate(()=>typeof window.__chicago4d.people?.open==='function');check('1904 public people.open bridge retained',report.publicPeopleOpen);
 }
 report.status='DIAGNOSTIC_COMPLETED';report.noMissingRequests=report.httpErrors.length===0;save();
}catch(e){report.status='NONPASS';report.failure=String(e.stack||e);save();console.error(report.failure);process.exitCode=1}
finally{await browser?.close();await new Promise(r=>server.close(r));save()}
