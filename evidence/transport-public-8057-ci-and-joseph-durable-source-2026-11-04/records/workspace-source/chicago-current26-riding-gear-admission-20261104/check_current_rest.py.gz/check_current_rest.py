#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Prepared actual-current26 REST admission; no model work at import.

The separate native capture is authoritative for indexed world geometry. This
checker never consumes producer contact receipts or historical horse geometry.
It reuses unchanged pinned historical collision/contact kernels, not their inputs.
A successful result is rest-only, not idle/motion/load/riding/photo qualification.
"""
from pathlib import Path
import argparse
import collections
import hashlib
import itertools
import json
import math
import sys
import numpy as np

OLD = Path('/workspace/chicago-riding-tack-footplate-proposal-20261104/source')
KERNELS = {
    'official_fit_predicates.py': '4e6b5911283dc806cd4f820063f2787bf0f637988f6a2a8a418e0c3202ce607a',
    'exact_contact.py': '5d9f570bdbe7224f23b0d64f3f5224cf71aac5022b5d00dbe00c036d344b08ff',
    'interface_contact.py': '23f27390f4a73d09ed3b45837fe6da0f308dfb87479a3861e8b09e8b88d05b86',
    'boundary_aliases.py': '7491a424e1d84a11bc3a4551a5e994c902c7b93ed573bf7dffbae395b3598e48',
    'source_interfaces.py': '534e1bc8f02e946f34f1aa429b1fbe8caca169b34deecac4d4ad9f7fe076b508',
    'iron_subdivision.py': '249d100c5016fc8c27a9d716ecc834c1aae299eb7f9e92346f264a8b723927a6',
    'footplate_join.py': '27744f5572056ce362cfa5e010e4d23b76a376b792362523c52ebf511c5af708',
    'topology.py': 'f80db635063081d93b21708e97774c90748d90365e4ae71424b789dbf4e40206',
}
NAMES = ('saddle_pad_l', 'saddle_pad_r', 'tree_sidebar_l', 'tree_sidebar_r',
         'saddle_seat', 'riding_girth', 'billet_l', 'billet_r')
EXPECTED = {'saddle_pad_l': (32, 60), 'saddle_pad_r': (32, 60),
            'tree_sidebar_l': (64, 124), 'tree_sidebar_r': (64, 124),
            'saddle_seat': (80, 156), 'riding_girth': (68, 132),
            'billet_l': (52, 100), 'billet_r': (52, 100)}
REST = {'mode': 'serialized_rest', 'clip': None, 'time_s': None, 'mixer_created': False}
HORSE = '7ce84d43445e930eecc6d9f69e97ed7ade0fe0b3fc44a9a753c25d88b3f548e1'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def kernels():
    for filename, expected in KERNELS.items():
        need(digest((OLD/filename).read_bytes()) == expected, 'Kernel drift: '+filename)
    # No checker/kernel import occurs until the explicit phase is run. No old
    # model, producer, fit result, source contact definition or input is loaded.
    sys.path.insert(0, str(OLD))
    from official_fit_predicates import sat, proper
    from exact_contact import source_edge_only, source_vertex_only
    from interface_contact import certify
    from boundary_aliases import decode_catalog, validate_catalog
    for name in ('official_fit_predicates', 'exact_contact', 'interface_contact',
                 'boundary_aliases', 'source_interfaces', 'iron_subdivision',
                 'footplate_join', 'topology'):
        need(Path(sys.modules[name].__file__).resolve() == (OLD/(name+'.py')).resolve(),
             'Unexpected imported kernel path: '+name)
    return sat, proper, source_edge_only, source_vertex_only, certify, decode_catalog, validate_catalog


def capture(path, expected):
    raw = path.read_bytes()
    metadata = json.loads(raw)
    need(metadata['schema'] == 'current26-rest-physical-capture-v1', 'Actual native capture schema')
    need(len(expected) == 64 and metadata['candidate_sha256'] == expected,
         'Explicit actual candidate SHA')
    need(metadata['horse_sha256'] == HORSE, 'Exact current standing horse SHA')
    need(metadata['actual_pose'] == REST, 'Serialized rest only, no mixer/action')
    seen, parts = set(), []
    for row in metadata['parts']:
        cohort, name = row['cohort'], row['name']
        need(cohort in ('gear', 'horse') and (cohort, name) not in seen,
             'Unique actual cohort/name')
        seen.add((cohort, name))
        need(type(row['mesh']) is int and row['mesh'] >= 0 and row['primitive'] == 0,
             'Explicit actual mesh/primitive association')
        n, f = row['vertices'], row['triangles']
        need(type(n) is int and type(f) is int and n > 0 and f > 0,
             'Complete nonempty row counts')
        arrays = {}
        for field, checksum, dtype, shape, size in (
                ('vertex_file', 'vertex_sha256', '<f8', (n, 3), n*24),
                ('index_file', 'index_sha256', '<u4', (f, 3), f*12),
                ('triangle_file', 'triangle_sha256', '<f8', (f, 3, 3), f*72)):
            filename = row[field]
            need(isinstance(filename, str) and Path(filename).name == filename,
                 'Capture stream must be an owned basename')
            body = (path.parent/filename).read_bytes()
            need(len(body) == size and digest(body) == row[checksum],
                 'Full native stream identity: '+filename)
            arrays[field] = np.frombuffer(body, dtype=dtype).reshape(shape)
        P, F, T = arrays['vertex_file'], arrays['index_file'], arrays['triangle_file']
        need(np.isfinite(P).all() and np.isfinite(T).all(), 'Finite actual native geometry')
        need(int(F.max()) < len(P), 'Actual index bounds')
        need(np.array_equal(T, P[F]), 'Every native triangle equals its complete indexed vertex stream')
        need(float(np.linalg.norm(np.cross(T[:, 1]-T[:, 0], T[:, 2]-T[:, 0]), axis=1).min()) > 2e-12,
             'Original actual-triangle nondegeneracy floor 2e-12')
        parts.append({'name': name, 'cohort': cohort, 'mesh': row['mesh'], 'P': P, 'F': F,
                      'tri': T, 'lo': T.min(1), 'hi': T.max(1),
                      'overall_lo': T.min((0, 1)), 'overall_hi': T.max((0, 1))})
    gear = [part for part in parts if part['cohort'] == 'gear']
    horse = [part for part in parts if part['cohort'] == 'horse']
    need(len(gear) == 8 and {part['name'] for part in gear} == set(NAMES), 'Exact eight-part gear cohort')
    need({part['mesh'] for part in gear} == set(range(8)), 'All eight actual gear meshes')
    for part in gear:
        need((len(part['P']), len(part['F'])) == EXPECTED[part['name']], 'Expected current source topology '+part['name'])
    need(len(horse) == 3 and {part['mesh'] for part in horse} == {0, 1, 2}
         and sum(len(part['F']) for part in horse) == 17390, 'All three horse meshes/all17390 triangles')
    return metadata, digest(raw), {part['name']: part for part in gear}, horse


def graph_components(faces):
    owners, adjacency = collections.defaultdict(list), collections.defaultdict(set)
    for index, face in enumerate(faces):
        face = list(map(int, face))
        for a, b in zip(face, face[1:]+face[:1]):
            owners[tuple(sorted((a, b)))].append(index)
    for ids in owners.values():
        for index in ids:
            adjacency[index].update(ids)
    result, seen = [], set()
    for index in range(len(faces)):
        if index in seen:
            continue
        group, pending = set(), [index]
        while pending:
            current = pending.pop()
            if current not in group:
                group.add(current)
                pending.extend(adjacency[current]-group)
        seen.update(group)
        result.append(sorted(group))
    return result


def topology(part):
    P, F, T = part['P'], part['F'], part['tri']
    need(len({tuple(map(float, p)) for p in P}) == len(P), 'No coincident unowned source rows')
    edges, links = collections.defaultdict(list), collections.defaultdict(dict)
    used = set()
    for face in F:
        face = list(map(int, face))
        need(len(set(face)) == 3, 'No repeated face index')
        used.update(face)
        for a, b in zip(face, face[1:]+face[:1]):
            edges[tuple(sorted((a, b)))].append((a, b))
        for v in face:
            a, b = [other for other in face if other != v]
            links[v].setdefault(a, set()).add(b)
            links[v].setdefault(b, set()).add(a)
    need(used == set(range(len(P))), 'Every actual vertex is used')
    need(all(len(edge) == 2 and edge[0] == edge[1][::-1] for edge in edges.values()),
         'Closed opposite directed edges')
    need(len(graph_components(F)) == 1 and len(P)-len(edges)+len(F) == 2,
         'Single component/Euler2')
    for link in links.values():
        need(all(len(neighbors) == 2 for neighbors in link.values()), 'Vertex link degree2')
        seen, pending = set(), [next(iter(link))]
        while pending:
            current = pending.pop()
            if current not in seen:
                seen.add(current)
                pending.extend(link[current]-seen)
        need(len(seen) == len(link), 'Single-cycle vertex link')
    areas = np.linalg.norm(np.cross(T[:, 1]-T[:, 0], T[:, 2]-T[:, 0]), axis=1)/2
    need(float(areas.min()) > 1e-11, 'Original closed-topology area floor 1e-11')
    volume = float(np.einsum('ij,ij->i', T[:, 0], np.cross(T[:, 1], T[:, 2])).sum()/6)
    need(volume > 0 and math.isfinite(volume), 'Actual outward finite volume')
    return {'V': len(P), 'E': len(edges), 'F': len(F), 'Euler': 2,
            'minimum_area_m2': float(areas.min()), 'volume_m3': volume}


def self_phase(gear, result, save, kernel):
    sat, proper, source_edge_only, source_vertex_only = kernel[:4]
    result['parts'] = {}
    for name in NAMES:
        A = gear[name]
        row = {'complete': False, 'closed': False, 'embedded_closed_solid': False,
               'faces': len(A['F']), 'AABB_candidates': 0, 'raw_SAT': 0,
               'exact_edge_only': 0, 'exact_vertex_only': 0, 'unexpected': []}
        result['parts'][name] = row
        save()
        row['topology'] = topology(A)
        row['closed'] = True
        for i, a in enumerate(A['tri']):
            possible = np.flatnonzero(np.all(A['hi'] >= A['lo'][i]-1e-8, axis=1)
                                     & np.all(A['lo'] <= A['hi'][i]+1e-8, axis=1))
            for j in map(int, possible):
                if j <= i:
                    continue
                row['AABB_candidates'] += 1
                b = A['tri'][j]
                if not sat(a, b):
                    continue
                row['raw_SAT'] += 1
                witness = proper(a, b)
                ia, ib = list(map(int, A['F'][i])), list(map(int, A['F'][j]))
                shared, certificate = set(ia)&set(ib), None
                if witness is None and len(shared) == 2:
                    certificate = source_edge_only(a, b, ia, ib)
                    if certificate is not None:
                        row['exact_edge_only'] += 1
                elif witness is None and len(shared) == 1:
                    vertex = next(iter(shared))
                    certificate = source_vertex_only(a, b, ia.index(vertex), ib.index(vertex))
                    if certificate is not None:
                        row['exact_vertex_only'] += 1
                if certificate is None:
                    row['unexpected'].append({'a_face': i, 'b_face': j, 'proper': witness,
                                              'actual_coordinates': [a.tolist(), b.tolist()]})
                    save()
                    raise ValueError('FIRST actual self intersection/touch '+name)
        row.update(complete=True, embedded_closed_solid=True)
        save()
    need(len(result['parts']) == 8 and all(row['complete'] for row in result['parts'].values()),
         'All eight actual complete self scans')


def disk(F):
    faces = [list(map(int, face)) for face in F]
    need(len(graph_components(faces)) == 1, 'Connected registered disk')
    edges = collections.Counter(tuple(sorted((a, b))) for face in faces
                                for a, b in zip(face, face[1:]+face[:1]))
    vertices = {v for face in faces for v in face}
    need(len(vertices)-len(edges)+len(faces) == 1 and all(n in (1, 2) for n in edges.values()),
         'Registered disk Euler1/edge incidence')
    adjacency = collections.defaultdict(set)
    for (a, b), count in edges.items():
        if count == 1:
            adjacency[a].add(b)
            adjacency[b].add(a)
    need(adjacency and all(len(neighbors) == 2 for neighbors in adjacency.values()),
         'Registered disk boundary degree2')
    visited, pending = set(), [next(iter(adjacency))]
    while pending:
        current = pending.pop()
        if current not in visited:
            visited.add(current)
            pending.extend(adjacency[current]-visited)
    need(len(visited) == len(adjacency), 'One disk boundary cycle')


def faces_on(part, vertices):
    vertices = set(vertices)
    faces = [index for index, face in enumerate(part['F']) if set(map(int, face)) <= vertices]
    need(faces and {int(v) for index in faces for v in part['F'][index]} == vertices,
         'Complete indexed planned patch vertex coverage')
    return faces


def grid_layout(columns, rows, layers=0):
    count = columns*rows
    boundary = (list(range(columns))
                + [row*columns+columns-1 for row in range(1, rows)]
                + [(rows-1)*columns+column for column in range(columns-2, -1, -1)]
                + [row*columns for row in range(rows-2, 0, -1)])
    mapping = {(0, row, col): row*columns+col for row in range(rows) for col in range(columns)}
    offset = count
    for layer in range(1, layers+1):
        for index in boundary:
            mapping[layer, index//columns, index % columns] = offset
            offset += 1
    for row in range(rows):
        for col in range(columns):
            mapping[layers+1, row, col] = offset+row*columns+col
    return mapping, count, len(boundary), offset


def interfaces(gear, params, decode_catalog, validate_catalog):
    zlo = params['girth_z_m']-params['girth_width_m']/2
    zhi = params['girth_z_m']+params['girth_width_m']/2
    zs = sorted(set(params['saddle_z_stations_m']+[zlo, zhi]))
    need(len(zs) == 8 and zs.index(zhi) == zs.index(zlo)+1, 'Actual eight current grid rows')
    pad, count, boundary, unused = grid_layout(2, len(zs))
    wood, wood_count, wood_boundary, top_offset = grid_layout(2, len(zs), 2)
    seat, seat_count, seat_boundary, unused = grid_layout(5, len(zs))
    need(count == 16 and wood_boundary == 16 and top_offset == 48, 'Expected actual indexed grid schedule')
    definitions = []
    for side, outer, seat_columns in (('l', 1, (3, 4)), ('r', 0, (0, 1))):
        padname, barname, billetname = 'saddle_pad_'+side, 'tree_sidebar_'+side, 'billet_'+side
        definitions.append(('pad_tree_'+side, padname, list(range(count, count*2)),
                            barname, list(range(wood_count))))
        definitions.append(('tree_seat_'+side, barname, list(range(top_offset, top_offset+wood_count)),
                            'saddle_seat', [seat[0, row, col] for row in range(len(zs)) for col in seat_columns]))
        port = [wood[layer, row, outer] for layer, row in
                ((1, zs.index(zlo)), (2, zs.index(zlo)),
                 (2, zs.index(zhi)), (1, zs.index(zhi)))]
        patch_faces = faces_on(gear[barname], port)
        need(len(patch_faces) == 2, 'Actual two-triangle wood port')
        diagonal = set(map(int, gear[barname]['F'][patch_faces[0]])) & set(map(int, gear[barname]['F'][patch_faces[1]]))
        local = {port.index(vertex) for vertex in diagonal}
        need(local in ({0, 2}, {1, 3}), 'Actual port diagonal')
        labels = [1, 2, 3, 0] if local == {1, 3} else [0, 1, 2, 3]
        # Source ring permutation is independently inferred from the actual wood
        # indexed diagonal, not read from the producer's receipt or alias table.
        for index, vertex in enumerate([port[j] for j in labels]):
            need(np.array_equal(gear[barname]['P'][vertex], gear[billetname]['P'][index]),
                 'Actual tree-port to billet-start correspondence')
        definitions.append(('tree_billet_'+side, barname, port, billetname, list(range(4))))
        end = 0 if side == 'l' else 64
        for index, vertex in enumerate([end+j for j in labels]):
            need(np.array_equal(gear['riding_girth']['P'][vertex], gear[billetname]['P'][48+index]),
                 'Actual girth cap to billet-end correspondence')
        definitions.append(('billet_girth_'+side, billetname, list(range(48, 52)),
                            'riding_girth', list(range(end, end+4))))
    packets = []
    for name, an, av, bn, bv in definitions:
        A, B = gear[an], gear[bn]
        af, bf = faces_on(A, av), faces_on(B, bv)
        need(len(af) == len(bf), 'Complete matching contact face counts')
        disk(A['F'][af]); disk(B['F'][bf])
        lookup = {}
        for index in bf:
            key = frozenset(tuple(map(float, p)) for p in B['tri'][index])
            need(len(key) == 3 and key not in lookup, 'Unique actual opposing contact triangle')
            lookup[key] = index
        matched = []
        for index in af:
            triangle = A['tri'][index]
            key = frozenset(tuple(map(float, p)) for p in triangle)
            need(key in lookup, 'Actual exact opposed face point match '+name)
            other = lookup[key]
            na = np.cross(triangle[1]-triangle[0], triangle[2]-triangle[0])
            b = B['tri'][other]
            nb = np.cross(b[1]-b[0], b[2]-b[0])
            need(float(np.dot(na, nb)) < 0, 'Actual opposing contact face winding')
            matched.append(other)
        need(len(set(matched)) == len(bf), 'No partial registered face overlap')
        coordinate_a, coordinate_b = {}, {}
        for ids, part, target in ((av, A, coordinate_a), (bv, B, coordinate_b)):
            for vertex in ids:
                target.setdefault(tuple(map(float, part['P'][vertex])), []).append(vertex)
        need(set(coordinate_a) == set(coordinate_b), 'Complete actual patch alias positions')
        aliases = [{'alias': index, 'actual_point_m': list(point),
                    'a_vertices': coordinate_a[point], 'b_vertices': coordinate_b[point]}
                   for index, point in enumerate(sorted(coordinate_a))]
        packet = {'name': name, 'a_mesh': an, 'b_mesh': bn, 'a_faces': af, 'b_faces': bf,
                  'actual_coplanar_matching_boundary_only': True, 'aliases': aliases,
                  'strict_proper_allowed': False}
        packet['boundary_source_aliases'] = decode_catalog(packet, A['P'], A['F'], B['P'], B['F'])
        validate_catalog(packet, A['P'], A['F'], B['P'], B['F'])
        packets.append(packet)
    need(len(packets) == 8, 'Eight and only eight independently decoded planned interfaces')
    return packets


def complement_probes(gear, packets):
    patches, points = collections.defaultdict(list), collections.defaultdict(set)
    for packet in packets:
        for prefix in ('a', 'b'):
            name = packet[prefix+'_mesh']
            faces = set(packet[prefix+'_faces'])
            patches[name].append(faces)
            points[name].update(tuple(point['actual_point_m']) for point in packet['aliases'])
    for name, part in gear.items():
        vertices = [{int(vertex) for index in patch for vertex in part['F'][index]} for patch in patches[name]]
        need(all(not a & b for index, a in enumerate(vertices) for b in vertices[index+1:]),
             'Disjoint registered contact disks/vertices '+name)
        removed = set().union(*patches[name]) if patches[name] else set()
        remaining = [index for index in range(len(part['F'])) if index not in removed]
        need(remaining and len(graph_components(part['F'][remaining])) == 1,
             'Actual surface-minus-contact-disks connected '+name)
        valid = [index for index in remaining if all(tuple(map(float, p)) not in points[name]
                                                    for p in part['tri'][index])]
        need(valid, 'Strict noncontact probe exists '+name)
        triangle = part['tri'][valid[0]]
        part['representatives'] = [triangle[0]*.5+triangle[1]*.25+triangle[2]*.25]


def absolute_winding(point, triangles):
    v = triangles-point
    u, vv, w = v[:, 0], v[:, 1], v[:, 2]
    lu, lv, lw = np.linalg.norm(u, axis=1), np.linalg.norm(vv, axis=1), np.linalg.norm(w, axis=1)
    need(float(min(lu.min(), lv.min(), lw.min())) > 1e-10, 'Probe away from actual target vertices')
    numerator = np.einsum('ij,ij->i', u, np.cross(vv, w))
    denominator = (lu*lv*lw + np.einsum('ij,ij->i', u, vv)*lw
                   + np.einsum('ij,ij->i', vv, w)*lu + np.einsum('ij,ij->i', w, u)*lv)
    return abs(float(np.arctan2(numerator, denominator).sum())/(2*math.pi))


def nesting(A, B):
    maximum = 0.0
    for point in A['representatives']:
        if np.any(point < B['overall_lo']) or np.any(point > B['overall_hi']):
            continue
        value = absolute_winding(point, B['tri'])
        maximum = max(maximum, value)
        need(value < 1e-5 or abs(value-1) < 1e-5, 'Ambiguous actual winding')
        need(value < .5, 'FIRST actual closed-component nesting '+A['name']+'/'+B['name'])
    return {'solid': B['name'], 'status': 'outside', 'maximum_absolute_winding': maximum}


def assembly_phase(gear, horse, params, result, save, kernel):
    sat, proper, unused_edge, unused_vertex, certify, decode_catalog, validate_catalog = kernel
    result['interfaces'] = interfaces(gear, params, decode_catalog, validate_catalog)
    complement_probes(gear, result['interfaces'])
    result['pairs'] = []
    save()
    def scan(A, B, kind):
        row = {'kind': kind, 'a': A['name'], 'b': B['name'], 'triangles_a': len(A['F']),
               'triangles_b': len(B['F']), 'AABB_candidates': 0, 'raw_SAT': 0,
               'strict_proper': 0, 'certified_contacts': [], 'unexpected': [], 'complete': False}
        result['pairs'].append(row)
        save()
        if not (np.any(A['overall_hi'] < B['overall_lo']-1e-8)
                or np.any(B['overall_hi'] < A['overall_lo']-1e-8)):
            for i, a in enumerate(A['tri']):
                possible = np.flatnonzero(np.all(B['hi'] >= A['lo'][i]-1e-8, axis=1)
                                         & np.all(B['lo'] <= A['hi'][i]+1e-8, axis=1))
                for j in map(int, possible):
                    b = B['tri'][j]
                    row['AABB_candidates'] += 1
                    if not sat(a, b):
                        continue
                    row['raw_SAT'] += 1
                    witness = proper(a, b)
                    row['strict_proper'] += int(witness is not None)
                    certificate = None
                    if witness is None and kind == 'interpart':
                        certificate = certify(a, b, list(map(int, A['F'][i])), list(map(int, B['F'][j])),
                                              A['name'], B['name'], i, j, result['interfaces'])
                    if certificate is not None:
                        row['certified_contacts'].append({'a_face': i, 'b_face': j, **certificate})
                        continue
                    row['unexpected'].append({'a_face': i, 'b_face': j, 'proper': witness,
                                              'actual_coordinates': [a.tolist(), b.tolist()]})
                    save()
                    raise ValueError('FIRST actual unexpected contact/proper '+A['name']+'/'+B['name'])
        if kind == 'interpart':
            row['nesting'] = [nesting(A, B), nesting(B, A)]
        row['complete'] = True
        save()
    for left, right in itertools.combinations(NAMES, 2):
        scan(gear[left], gear[right], 'interpart')
    need(len(result['pairs']) == 28 and all(row['complete'] for row in result['pairs']),
         'All28 full actual interpart scans')
    for name in NAMES:
        for target in horse:
            scan(gear[name], target, 'horse')
    horse_rows = [row for row in result['pairs'] if row['kind'] == 'horse']
    need(len(horse_rows) == 24 and all(row['complete'] for row in horse_rows),
         'All8 versus each of3 actual horse meshes completed')
    result['actual_horse_coverage'] = {'gear_parts': 8, 'horse_parts': 3,
                                       'horse_triangles': 17390, 'part_pairs': 24,
                                       'whole_pair_or_horse_contact_exemptions': []}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('self', 'assembly'), required=True)
    parser.add_argument('--capture', type=Path, required=True)
    parser.add_argument('--params', type=Path, required=True)
    parser.add_argument('--candidate-sha', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--self-receipt', type=Path)
    parser.add_argument('--self-sha')
    args = parser.parse_args()
    need(args.out.is_absolute() and not args.out.exists(), 'Fresh absolute checker output')
    args.out.mkdir()
    filename = 'self.json' if args.phase == 'self' else 'assembly.json'
    result = {'schema': 'current26-rest-'+args.phase+'-admission-v1', 'passed': False,
              'phase': args.phase, 'scope': 'ACTUAL_SERIALIZED_REST_ONLY_NOT_IDLE_MOTION_RIDING_OR_PHOTO',
              'candidate_sha256': args.candidate_sha, 'actual_pose': REST,
              'original_kernel_hashes': KERNELS, 'parts_required': list(NAMES),
              'interpart_pairs_required': 28, 'horse_triangles_required': 17390}
    def save():
        (args.out/filename).write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    save()
    try:
        metadata, capture_sha, gear, horse = capture(args.capture, args.candidate_sha)
        params_raw = args.params.read_bytes()
        params = json.loads(params_raw)
        result.update(capture_metadata_sha256=capture_sha, params_sha256=digest(params_raw),
                      horse_sha256=metadata['horse_sha256'])
        kernel = kernels()
        if args.phase == 'self':
            self_phase(gear, result, save, kernel)
        else:
            need(args.self_receipt is not None and args.self_sha is not None,
                 'Assembly requires explicit passed self receipt SHA')
            raw = args.self_receipt.read_bytes()
            need(digest(raw) == args.self_sha, 'Explicit self receipt byte identity')
            self_result = json.loads(raw)
            need(self_result['schema'] == 'current26-rest-self-admission-v1'
                 and self_result['passed'] is True
                 and self_result['candidate_sha256'] == args.candidate_sha
                 and self_result['capture_metadata_sha256'] == capture_sha
                 and self_result['params_sha256'] == result['params_sha256']
                 and self_result['actual_pose'] == REST
                 and self_result['original_kernel_hashes'] == KERNELS
                 and set(self_result['parts']) == set(NAMES), 'Same complete actual self qualification')
            for name in NAMES:
                row = self_result['parts'][name]
                need(row['complete'] is True and row['closed'] is True
                     and row['embedded_closed_solid'] is True and not row['unexpected']
                     and row['faces'] == len(gear[name]['F']), 'All eight embedded closed targets')
            result['self_receipt_sha256'] = args.self_sha
            assembly_phase(gear, horse, params, result, save, kernel)
        # The same native files and metadata must still be complete after scans.
        unused_meta, after_sha, unused_gear, unused_horse = capture(args.capture, args.candidate_sha)
        need(after_sha == capture_sha and digest(args.params.read_bytes()) == result['params_sha256'],
             'Source capture and parameter identities after admission')
        for kernel_name, expected in KERNELS.items():
            need(digest((OLD/kernel_name).read_bytes()) == expected, 'Kernel drift after admission')
        result.update(passed=True, source_after_exact=True,
                      fit_motion_load_rider_or_photographic_accepted=False)
        save()
    except BaseException as error:
        result['error'] = repr(error)
        result['first_failure'] = result.get('first_failure', repr(error))
        save()
        raise


if __name__ == '__main__':
    main()
