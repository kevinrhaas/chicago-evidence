// SPDX-License-Identifier: GPL-3.0-or-later
// Prepared only: actual current horse/gear GLTFLoader rest capture, no animation.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {register} from 'node:module';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
const sha=b=>createHash('sha256').update(b).digest('hex');
const args=process.argv.slice(2);assert.equal(args.length,10);
const opts={};for(let i=0;i<args.length;i+=2){assert(args[i].startsWith('--'));opts[args[i].slice(2)]=args[i+1];}
for(const k of ['candidate','candidate-sha','horse','config','out'])assert(opts[k]);
const configRaw=readFileSync(opts.config),config=JSON.parse(configRaw);
assert.equal(config.horse_sha256,'7ce84d43445e930eecc6d9f69e97ed7ade0fe0b3fc44a9a753c25d88b3f548e1');
for(const row of config.native_dependency_pins){const bytes=readFileSync(row.path);assert.equal(bytes.length,row.bytes);assert.equal(sha(bytes),row.sha256,row.path);}
const horseRaw=readFileSync(opts.horse),gearRaw=readFileSync(opts.candidate);
assert.equal(sha(horseRaw),config.horse_sha256);assert.equal(sha(gearRaw),opts['candidate-sha']);
const out=path.resolve(opts.out);assert(!existsSync(out),'Fresh native output');mkdirSync(out);
register(pathToFileURL(config.native_vendor_loader),import.meta.url);
const T=await import('three');assert.equal(T.REVISION,'185');
const {GLTFLoader}=await import('three/addons/loaders/GLTFLoader.js');
const {MeshoptDecoder}=await import('three/addons/libs/meshopt_decoder.module.js');await MeshoptDecoder.ready;
function doc(raw){assert.equal(raw.readUInt32LE(0),0x46546c67);assert.equal(raw.readUInt32LE(4),2);assert.equal(raw.readUInt32LE(8),raw.length);return JSON.parse(raw.subarray(20,20+raw.readUInt32LE(12)));}
async function load(raw){
 const d=doc(raw);const loader=new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);
 loader.register(()=>({name:'CPU_POSE_ONLY_MATERIAL_ADAPTER',loadMaterial:async i=>new T.MeshBasicMaterial({side:d.materials[i].doubleSided?T.DoubleSide:T.FrontSide})}));
 const parsed=await loader.parseAsync(raw.buffer.slice(raw.byteOffset,raw.byteOffset+raw.byteLength),'');parsed.scene.updateMatrixWorld(true);
 const meshes=[];parsed.scene.traverse(m=>{if(m.isMesh)meshes.push(m);});
 return{d,parsed,meshes};
}
const horse=await load(horseRaw),gear=await load(gearRaw);
assert.equal(horse.meshes.length,3);assert.equal(gear.meshes.length,8);
assert.equal(gear.parsed.animations.length,0,'Gear has no copied horse animation');
const body=horse.meshes.find(m=>horse.parsed.parser.associations.get(m)?.meshes===1);
assert(body?.isSkinnedMesh&&body.geometry.attributes.position.count===5595);
const names=body.skeleton.bones.map(b=>b.name);assert.deepEqual(names,config.joint_names);assert.equal(names.length,26);
const identity=new T.Matrix4().elements;assert.deepEqual(body.matrixWorld.elements,identity);assert.deepEqual(body.bindMatrix.elements,identity);
const disposed=new Set(),bindings=[];
for(const mesh of gear.meshes){
 assert(mesh.isSkinnedMesh);assert.deepEqual(mesh.skeleton.bones.map(b=>b.name),names);
 assert.deepEqual(mesh.bindMatrix.elements,identity);assert.deepEqual(mesh.matrixWorld.elements,identity);
 for(let j=0;j<26;j++){
  const gb=mesh.skeleton.bones[j],hb=body.skeleton.bones[j];
  assert.equal(mesh.skeleton.bones.indexOf(gb.parent),body.skeleton.bones.indexOf(hb.parent),'Copied actual joint parentage');
  for(let k=0;k<16;k++){
   assert(Object.is(mesh.skeleton.boneInverses[j].elements[k],body.skeleton.boneInverses[j].elements[k]),'Copied exact actual inverse bind');
   assert(Object.is(gb.matrix.elements[k],hb.matrix.elements[k]),'Actual local rest matrix before rebind');
   assert(Object.is(gb.matrixWorld.elements[k],hb.matrixWorld.elements[k]),'Actual world rest matrix before rebind');
  }
 }
 const own=mesh.skeleton;assert.notEqual(own,body.skeleton);
 if(!disposed.has(own)){own.dispose();disposed.add(own);}
 mesh.removeFromParent();horse.parsed.scene.add(mesh);mesh.bind(body.skeleton,new T.Matrix4());
 bindings.push({name:gear.d.meshes[gear.parsed.parser.associations.get(mesh).meshes].name,joint_names:names,input_rest_and_parentage_match_before_rebind:true,bind:'Actual same horse BODY skeleton, not oldproxy or synthetic rest'});
}
horse.parsed.scene.updateMatrixWorld(true);
for(const m of [...horse.meshes,...gear.meshes])m.skeleton.update();
const parts=[],point=new T.Vector3();
function emit(name,bytes){writeFileSync(path.join(out,name),bytes);return{file:name,bytes:bytes.length,sha256:sha(bytes)};}
for(const [cohort,model]of[['horse',horse],['gear',gear]])for(const mesh of model.meshes){
 const assoc=model.parsed.parser.associations.get(mesh);assert(assoc&&Number.isInteger(assoc.meshes));assert.equal(assoc.primitives??0,0);
 const mi=assoc.meshes,pi=assoc.primitives??0,source=model.d.meshes[mi],primitive=source.primitives[pi];assert.equal(source.primitives.length,1);assert.equal(primitive.mode??4,4);
 const name=cohort==='horse'?`horse_mesh_${mi}`:source.name;
 assert(cohort==='horse'||config.gear_names.includes(name));assert(mesh.isSkinnedMesh);
 const g=mesh.geometry,P=g.attributes.position,I=g.index;assert(P&&I&&I.count%3===0);assert(!Object.values(g.morphAttributes).some(a=>a.length),'Explicit handling required for any morph');
 assert.equal(P.count,model.d.accessors[primitive.attributes.POSITION].count);assert.equal(I.count,model.d.accessors[primitive.indices].count);
 const vb=Buffer.alloc(P.count*24),ib=Buffer.alloc(I.count*4),tb=Buffer.alloc(I.count*24);
 for(let i=0;i<P.count;i++){
  mesh.getVertexPosition(i,point).applyMatrix4(mesh.matrixWorld);assert(point.toArray().every(Number.isFinite));
  for(let k=0;k<3;k++)vb.writeDoubleLE(point.getComponent(k),(i*3+k)*8);
 }
 for(let i=0;i<I.count;i++){
  const id=I.getX(i);assert(Number.isInteger(id)&&id>=0&&id<P.count);ib.writeUInt32LE(id,i*4);vb.copy(tb,i*24,id*24,id*24+24);
 }
 const v=emit(`${name}.vertices.f64le`,vb),ix=emit(`${name}.indices.u32le`,ib),t=emit(`${name}.triangles.f64le`,tb);
 parts.push({cohort,name,mesh:mi,primitive:pi,vertices:P.count,triangles:I.count/3,
  vertex_file:v.file,vertex_sha256:v.sha256,vertex_bytes:v.bytes,index_file:ix.file,index_sha256:ix.sha256,index_bytes:ix.bytes,triangle_file:t.file,triangle_sha256:t.sha256,triangle_bytes:t.bytes});
}
assert.deepEqual(parts.filter(p=>p.cohort==='gear').map(p=>p.name).sort(),[...config.gear_names].sort());
assert.equal(parts.filter(p=>p.cohort==='horse').reduce((a,p)=>a+p.triangles,0),17390);
assert.deepEqual(parts.filter(p=>p.cohort==='horse').map(p=>p.mesh).sort(),[0,1,2]);
assert.equal(sha(readFileSync(opts.horse)),config.horse_sha256);assert.equal(sha(readFileSync(opts.candidate)),opts['candidate-sha']);assert.equal(sha(readFileSync(opts.config)),sha(configRaw));
for(const row of config.native_dependency_pins)assert.equal(sha(readFileSync(row.path)),row.sha256);
const report={schema:'current26-rest-physical-capture-v1',status:'ACTUAL_NATIVE_REST_CAPTURE_NOT_SELF_CONTACT_OR_RIDING_QUALIFICATION',passed:true,
 candidate_sha256:opts['candidate-sha'],horse_sha256:config.horse_sha256,actual_pose:{mode:'serialized_rest',clip:null,time_s:null,mixer_created:false},
 actual_native_three_revision:T.REVISION,actual_node_version:process.version,geometry_only_material_adapter:true,images_or_pixels_loaded:false,
 actual_shared_horse_skeleton_bindings:bindings,gear_parts:8,horse_parts:3,horse_triangles:17390,parts,source_inputs_after_exact:true,
 geometry_or_model_or_actor_installed:false,rest_only_not_idle_or_motion_or_photo_acceptance:true};
writeFileSync(path.join(out,'capture.json'),JSON.stringify(report,null,2)+'\n');
console.log('Actual native current26 serialized-rest capture complete: 8 gear parts and all 17390 horse faces; physical checks remain next');
