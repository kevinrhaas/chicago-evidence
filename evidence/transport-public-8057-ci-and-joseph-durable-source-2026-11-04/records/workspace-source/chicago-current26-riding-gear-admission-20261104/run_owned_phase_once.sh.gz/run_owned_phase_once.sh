#!/usr/bin/env bash
# Prepared only. Root hands canonical lane and binds each actual phase explicitly.
set -euo pipefail
[ "$#" -eq 4 ] || { echo 'usage: run_owned_phase_once.sh build|admit ACTUAL-GO.json /fresh-admission-output /owned-candidate-root';exit 2; }
source /workspace/.cloud-setup/transport-activate.sh
admission_root=/workspace/chicago-current26-riding-gear-admission-20261104
admission_phase=$1
admission_go=$2
admission_out=$3
admission_candidate=$4
admission_prefix="${admission_out}-driver"
case "$admission_phase" in build) admission_cap=180;;admit) admission_cap=1800;;*)exit 2;;esac
python - "$admission_out" "$admission_root" <<'PY'
from pathlib import Path
import sys
assert Path(sys.argv[1]).is_absolute()and Path(sys.argv[1]).resolve().parent==Path(sys.argv[2]).resolve()
PY
exec 9>>/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock
flock -n 9
for suffix in .resource-before.json .resource-after.json .resource-pair.json .supervisor.stdout .CLOSED.json;do
 [ ! -e "${admission_prefix}${suffix}" ] || { echo 'Use a new output/prefix';exit 2; }
done
python /workspace/.cloud-setup/transport-current-20261103/resource_guard.py capture "${admission_prefix}.resource-before.json"
set +e
python /workspace/.cloud-setup/transport-supervise.py --prefix "$admission_prefix" --cwd "$admission_root" --timeout "$admission_cap" -- \
 /workspace/.cloud-setup/venv311/bin/python "$admission_root/run_stage_once.py" --phase "$admission_phase" --go "$admission_go" --candidate-root "$admission_candidate" --out "$admission_out" > "${admission_prefix}.supervisor.stdout" 2>&1
admission_rc=$?
python /workspace/.cloud-setup/transport-current-20261103/resource_guard.py capture "${admission_prefix}.resource-after.json"
admission_after=$?
python /workspace/.cloud-setup/transport-current-20261103/resource_guard.py pair "${admission_prefix}.resource-before.json" "${admission_prefix}.resource-after.json" "${admission_prefix}.resource-pair.json"
admission_pair=$?
set -e
python - "$admission_prefix" "$admission_out" "$admission_phase" "$admission_cap" "$admission_rc" "$admission_after" "$admission_pair" <<'PY'
from pathlib import Path
import sys,json
prefix,out,phase,cap,rc,after,pair=sys.argv[1:];cap=int(cap)
load=lambda p:json.loads(Path(p).read_text())if Path(p).exists()else None
r,c,g,i=load(prefix+'.result.json'),load(prefix+'.cleanup.json'),load(prefix+'.resource-pair.json'),load(str(Path(out)/'RESULT.json'))
ok=bool(rc==after==pair=='0'and r and r['returncode']==0 and not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==cap and r['timeout_override_reason']is None and c and c['cleanup_complete']and not c['remaining_owned_children']and g and g['accepted']and i and i['passed']is True and i['phase']==phase and i['source_after_exact']is True)
status=('CURRENT26_SOURCE_BUILD_CLOSED_PASS_UNQUALIFIED'if phase=='build'else'CURRENT26_NATIVE_REST_ADMISSION_CLOSED_PASS_ONLY')if ok else'NONPASS_NO_AUTOMATIC_RETRY'
Path(prefix+'.CLOSED.json').write_text(json.dumps({'status':status,'phase':phase,'result':r,'cleanup':c,'resources':g,'phase_result':i,'motion_load_rider_or_photo_accepted':False},indent=2)+'\n');print(status);raise SystemExit(0 if ok else 1)
PY
