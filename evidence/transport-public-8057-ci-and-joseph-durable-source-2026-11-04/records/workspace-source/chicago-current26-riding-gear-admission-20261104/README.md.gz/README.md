# Prepared current26 build + actual REST admission — UNRUN

No constructor, model loader, animation, geometry, physical test or browser ran.
This package is separate from the frozen source owner. Root's canonical handoff
and actual hash-bound GO are mandatory; N's native gate currently owns the lane.

The source manifest is630f0acd59d3b60117f371a97ed00438fd5d6ea250582dccb0f2281758a287cc.
Its only producer change from Root's reviewed initial version is embedding the
FULL actual pinned native attribution, independently of GPL generated geometry.

## Two explicit single attempts, no automatic chain or retry

1. Build: copy ROOT-GO-BUILD-UNBOUND-TEMPLATE.json to a NEW actual GO. Root alone
   sets approved/lane true and admission_manifest_sha256 to this frozen package's
   reviewed PREPARATION-MANIFEST.json SHA. Source manifest is already fixed. Run:

    bash /workspace/chicago-current26-riding-gear-admission-20261104/run_owned_phase_once.sh build \
      /ABSOLUTE/ROOT-ACTUAL-BUILD-GO.json \
      /workspace/chicago-current26-riding-gear-admission-20261104/actual-build-01 \
      /workspace/chicago-current26-riding-gear-source-20261104/actual-core-01

   Actual builder is one120s supervised child, one inherited CPU, math threads1;
   enclosing supervision180s. Canonical flock, exact3f49 resource epoch/floors,
   before/after source/input pins and original owned-descendant cleanup remain.
   This output must be new; failed/partial output is never overwritten. The closed
   result must be CURRENT26_SOURCE_BUILD_CLOSED_PASS_UNQUALIFIED; actual GLB hash,
   source receipt and complete source-surface attribution are re-read and bound.
   Source construction is not self/contact/visual/rider qualification.

2. Admit: only after Root reads the actual candidate, copy the ADMIT template to
   a separate actual GO, bind candidate_sha256 to the REAL new GLB hash and both
   reviewed manifest hashes. Run once with a NEW admission output and same candidate:

    bash /workspace/chicago-current26-riding-gear-admission-20261104/run_owned_phase_once.sh admit \
      /ABSOLUTE/ROOT-ACTUAL-ADMIT-GO.json \
      /workspace/chicago-current26-riding-gear-admission-20261104/actual-rest-admission-01 \
      /workspace/chicago-current26-riding-gear-source-20261104/actual-core-01

   Original overall1800s bound; Khronos60s, original predicate controls30s,
   real native capture60s, native SELF900s and interpart/horse900s subcaps. Total
   worst-case subcaps are not a promise to exceed the1800s outer bound: timeout
   remains NONPASS. Same one-CPU/resource/flock/fresh-output/cleanup/source guards.

## What the actual admission reads and proves

capture_current_rest.mjs uses real pinned Three185/GLTFLoader and the existing CPU
material adapter. Original horse7ce is unchanged; no image decode, renderer, mocks,
Mixer, animation or interpolant evaluation. It resolves the current26 BODY and
validates exact joint names, parentage, local/world rest matrices and raw-copy
inverse binds BEFORE rebind (so rebind cannot mask a broken portable rig). All eight actual gear meshes
bind to that REAL horse skeleton. It captures complete indexed native world vertices
and triangles from all eight parts and all THREE horse primitives:17,390 faces.
Source/index/native hashes are saved and checked; no part is dropped by material,
visibility, old proxy shape or source-side triangle estimates.

check_current_rest.py independently verifies those complete indexed world streams.
Each of8 must pass finite/nondegenerate, closed/oriented/Euler2/single-component/
vertex-link and ALL native self-face checks. Unchanged original strict proper/SAT,
exact edge/vertex simplex, opposed patch, duplicate-boundary and winding kernels
are source-pinned; no old model or fit receipt enters the new case.

Eight actual planned contact patches derive from indexed grid/layer/cap layouts,
not producer contact receipts. Full face/alias coverage, opposed identical actual
faces, disk topology, disjoint patches, surface-minus-patch connectivity and strict
noncontact component probes are required. Registered contact applies only AFTER
strict proper rejects no witness. No whole adjacency, face-pair or object-pair
exemptions are added. All28 part pairs run, followed by8×3 actual horse-cohort scans
covering EACH current part versus ALL17,390 faces. Complete counting is mandatory.

A successful closed status is CURRENT26_NATIVE_REST_ADMISSION_CLOSED_PASS_ONLY.
It is serialized REST, not idle0: no mixer was created. It does not establish quiet,
walk, continuous contact, pressure, loading, stirrup construction, Joseph pose,
photo quality or an installed actor. Native motion/visual/rider work remains later.
If future current gear has29 parts, ALL406 pairs and all29 horse-contact scopes are
required; no historical20affected/9protected or old15rig/14,172-face proof transfers.

Any first failure saves partial counts/witness and remains NONPASS. Root inspects
it before any correction/new attempt; no tolerance/quality/cap/threshold changes
or generic ignore flags are present. All actual result/cleanup/resource receipts
must be retained. No current candidate or actual GO exists at preparation time.
