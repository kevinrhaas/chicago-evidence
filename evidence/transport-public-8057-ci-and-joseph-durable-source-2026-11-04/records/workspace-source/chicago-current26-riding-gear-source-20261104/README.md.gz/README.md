# Current26 saddle/girth core — source only, UNRUN

This is an isolated owner, not an APP install or replacement of historical406.
No constructor, model import, generation, native test, bake or browser has run.
Python files were AST-parsed only. ROOT-GO remains false; Root owns the canonical
lane while N's complete native gate runs. No source or assets in N/R/G were edited.

## Actual inputs and concrete binding decisions

Root's current skin/track intake closed PASS in1.418s: fixed standing7ce84d and
movingad9dc0 have equal complete native rest/skin outputs,17,390 horse triangles,
26 joints and unmodified source bytes. Native zero-padding counts were0, recorded
without a policy that drops padding. Native body weight sums span approximately
.999999959..1.000000036; source/native tables remain exact and are not rewritten.
Quiet has15 tracks/65 keys over12s; moving also has21 careful-walk tracks,129 keys
apart from the2-key motion-root translation. These are metadata, not new pose tests.

Dorsal influences include small neck/tail terms; girth has shoulder/elbow terms.
The source therefore does not pretend every source point is rigid horse_body.
It reads every referenced BODY vertex's actual native influences. New flexible
gear coefficients are barycentric authored fields normalized for new output only;
ALL nonzero influences must fit four slots or generation refuses (no top4 pruning).
New rigid wood/seat uses the explicitly chosen current horse_body joint1. This is
an unqualified engineering choice, not inherited dynamic-contact evidence.

Shared pad/tree, tree/seat, tree/billet and billet/girth port vertices copy exactly
the same new positions and serialized weights across both parts. Native contact
must still verify all complete proposed interfaces; matching vertices are not a
whole-pair exemption or a contact/pressure certificate.

Actual current BODY world/bind matrices are identity; the GLB writer preserves
source26 joint order, ancestor/rest nodes and raw inverse-bind matrices. It copies
no horse mesh/image/animation and mutates no source file. Eight named skinned parts
can later be bound to the real horse skeleton using the existing draft-hitch rig
validation/bind pattern. The two-horse hitch factory itself requires one tack mesh
and is NOT called to install this8-part/single-rider asset.

## Implemented source scope

* Two closed pad strips: actual dorsal surface,8–20mm design offsets.
* Two closed wooden bars:20–42mm offsets; real4mm wall ports at24–28mm.
* A closed seat construction surface:42–62mm offsets, no pelvis target.
* One closed lower-half girth:35mm wide,8–12mm source-surface design offset.
* Two closed billets, following current upper-side surface queries and sharing
  exact actual tree-port/girth-cap source patches. There is no over-back girth.

Dimensions, materials, offsets, construction and posture implications are original
reconstructions, not dated saddle measurements or load-bearing guarantees. The
bar front extends to+.25m so the girth port's axial edges+.1825/+.2175m lie inside
real wood. These added locations query the complete measured BODY/native tables;
they are not manufactured sockets or copied oldproxy coordinates. Full source
face/indices/barycentric/outward/offset/binding provenance is emitted per query.

closed_mesh.py builds F32 closed indexed shells/lofts and checks finite faces,
edge incidence, vertex links, Euler2 and volume. It does NOT prove embedding,
clearance, source-normal visual quality or material strength. Materials are original
flat PBR factors with no new image/UV derivation; visual/photographic acceptance is
open. Source/geometry licensing follows the current hitch's GPL3+ convention and
embeds the FULL actual pinned native report attribution (Horse, sevketkabatas,
source URL,CC-BY4, original41acd9 hash and adaptation), independently of the old CC0
proxy/hardware. Source surfaces/textures/rig/animations remain immutable.

## Later authorized bounded generation and qualification

After Root reviews exact SOURCE-MANIFEST.json and releases the canonical lane, an
actual GO may set approved/lane true and bind source_manifest_sha256 to that file.
Under existing canonical resource/flock/supervisor controls, one Root-approved120s build
child can invoke the IMPLEMENTED command (UNRUN now):

    source /workspace/.cloud-setup/transport-activate.sh
    cd /workspace/chicago-current26-riding-gear-source-20261104
    python source/build_current26_core.py --go ROOT-ACTUAL-GO.json \
      --out /workspace/chicago-current26-riding-gear-source-20261104/actual-core-01

The output must be a new direct child of this owner. No APP/publisher writes or
Blender dependency are involved. Native readback/Khronos retain original60s caps;
actual source-self/contact tests retain original subcaps and strict predicates.
No such run exists. Any failure stops; no blind retry or tolerance adjustment.

Current coverage is8 parts, ALL8 self obligations, ALL28 interpart pairs and EACH
of8 versus ALL17,390 horse faces. Proposed complete contact patches need original
independent topology/contact certification; never exclude a whole pair. All parts
are current and require fresh proof, with no old20/9 inheritance. A future29-part
cohort must execute ALL406 pairs and all29 against the current horse. Original
cf148/88 crossing negatives and29-part self/contact controls remain preserved
historical inputs, not positives or an1800s oldproxy exercise renamed rider work.

SOURCE-CANDIDATE.json, if later generated, is explicitly unqualified and carries
real mesh/face IDs, proposed interfaces, query/binding ledgers and required coverage.
It does not certify intersections or declare a new rider. The next native readback
must use the actual current horse, current rig and all emitted gear, then inspect
actual images. Sparse rest/source queries are not continuous motion/fit proofs.

Stirrup geometry, Joseph pelvis/sole/palm targets and installation are NULL/false.
Recovered ten-sided footplate/lower-arch methods remain available for a later local
hardware construction after real current Joseph contact targets exist; no old15-rig
or old horse-fit coordinates enter this producer. The original historical406 source
and caller stay unchanged and unrun.
