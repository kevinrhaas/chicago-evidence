# SPDX-License-Identifier: GPL-3.0-or-later
"""Small closed meshes for an unqualified current-horse tack source candidate.

Coordinates are metres. Grid dimensions count vertices, not cells. Inputs must
already contain the intended surfaces and offsets; this module neither fits a
horse nor changes contacts. Its checks establish local triangle/topology facts,
not absence of self-intersection or contact with another object.
"""
from math import fsum, isfinite, sqrt
from struct import pack, unpack


def f32(value):
    """Round one finite scalar to finite IEEE-754 binary32, preserving signed zero."""
    value = float(value)
    if not isfinite(value):
        raise ValueError('non-finite coordinate')
    try:
        result = unpack('<f', pack('<f', value))[0]
    except (OverflowError, ValueError) as error:
        raise ValueError('coordinate outside finite binary32 range') from error
    if not isfinite(result):
        raise ValueError('coordinate outside finite binary32 range')
    return result


def _sub(a, b):
    return tuple(a[i] - b[i] for i in range(3))


def _cross(a, b):
    return (a[1]*b[2] - a[2]*b[1],
            a[2]*b[0] - a[0]*b[2],
            a[0]*b[1] - a[1]*b[0])


def _dot(a, b):
    return fsum(a[i]*b[i] for i in range(3))


def _finalize(positions, faces):
    """Round once, check a connected oriented closed genus-zero triangle mesh."""
    vertices = []
    for position in positions:
        if len(position) != 3:
            raise ValueError('positions require exactly three coordinates')
        vertices.append(tuple(f32(value) for value in position))
    if len(vertices) < 4:
        raise ValueError('a closed volume requires at least four vertices')
    triangles = []
    edge_uses = {}
    neighbors = [set() for _ in vertices]
    incident = [[] for _ in vertices]
    for source_face in faces:
        face = tuple(source_face)
        if len(face) != 3 or any(type(i) is not int or not 0 <= i < len(vertices)
                                 for i in face) or len(set(face)) != 3:
            raise ValueError('face must contain three distinct valid integer indices')
        a, b, c = face
        normal = _cross(_sub(vertices[b], vertices[a]), _sub(vertices[c], vertices[a]))
        area_squared = _dot(normal, normal)
        if not isfinite(area_squared) or area_squared <= 0:
            raise ValueError('triangle degenerate after binary32 rounding')
        triangles.append(face)
        for u, v in ((a, b), (b, c), (c, a)):
            key = (min(u, v), max(u, v))
            edge_uses.setdefault(key, []).append((u, v))
            neighbors[u].add(v)
            neighbors[v].add(u)
        for vertex, other_a, other_b in ((a, b, c), (b, c, a), (c, a, b)):
            incident[vertex].append((other_a, other_b))
    if not triangles or any(not links for links in incident):
        raise ValueError('empty mesh or unused vertex')
    for uses in edge_uses.values():
        if len(uses) != 2 or uses[0] != uses[1][::-1]:
            raise ValueError('edge must occur twice with opposite directions')
    reached, pending = set(), [0]
    while pending:
        vertex = pending.pop()
        if vertex not in reached:
            reached.add(vertex)
            pending.extend(neighbors[vertex] - reached)
    if len(reached) != len(vertices):
        raise ValueError('mesh must be connected')
    # Edge incidence alone permits pinched vertices. Each vertex link must be
    # one cycle, so smooth shared normals are attached to a manifold vertex.
    for links in incident:
        link_neighbors = {}
        for a, b in links:
            link_neighbors.setdefault(a, []).append(b)
            link_neighbors.setdefault(b, []).append(a)
        if any(len(adjacent) != 2 for adjacent in link_neighbors.values()):
            raise ValueError('vertex link must have degree two')
        visited, pending = set(), [next(iter(link_neighbors))]
        while pending:
            vertex = pending.pop()
            if vertex not in visited:
                visited.add(vertex)
                pending.extend(v for v in link_neighbors[vertex] if v not in visited)
        if len(visited) != len(link_neighbors):
            raise ValueError('vertex link must be a single cycle')
    euler = len(vertices) - len(edge_uses) + len(triangles)
    if euler != 2:
        raise ValueError('mesh must have Euler characteristic two')
    origin = vertices[0]
    volume = fsum(_dot(_sub(vertices[a], origin),
                       _cross(_sub(vertices[b], origin), _sub(vertices[c], origin)))
                  for a, b, c in triangles) / 6.0
    if not isfinite(volume) or volume == 0:
        raise ValueError('mesh must enclose finite nonzero signed volume')
    if volume < 0:
        triangles = [(a, c, b) for a, b, c in triangles]
        volume = -volume
    contributions = [[] for _ in vertices]
    for a, b, c in triangles:
        normal = _cross(_sub(vertices[b], vertices[a]), _sub(vertices[c], vertices[a]))
        for index in (a, b, c):
            contributions[index].append(normal)
    normals = []
    for values in contributions:
        normal = tuple(fsum(value[i] for value in values) for i in range(3))
        magnitude = sqrt(_dot(normal, normal))
        if not isfinite(magnitude) or magnitude == 0:
            raise ValueError('area-weighted vertex normal cancels or is non-finite')
        normals.append(tuple(f32(value/magnitude) for value in normal))
    return {'positions': vertices, 'faces': triangles, 'normals': normals,
            'topology': {'V': len(vertices), 'F': len(triangles), 'E': len(edge_uses),
                         'Euler': euler, 'volume_m3': volume}}


def closed_grid(bottom, top, columns, rows, boundary_layers=()):
    """Join two rectangular row-major vertex grids with triangulated boundary walls.

Each grid has columns*rows points with both dimensions >=2. The same cell
    triangulation is used on both surfaces; bottom winding is reversed. Optional
    intermediate layers each supply a full grid, but only their boundary points
    become vertices. Layer zero is bottom; the last numbered layer is top.
    Input surfaces must correspond and enclose nonzero volume.
"""
    if type(columns) is not int or type(rows) is not int or columns < 2 or rows < 2:
        raise ValueError('grid dimensions must be integer vertex counts >=2')
    bottom, top = list(bottom), list(top)
    count = columns*rows
    if len(bottom) != count or len(top) != count:
        raise ValueError('each grid must contain columns*rows vertices')
    intermediate = [list(layer) for layer in boundary_layers]
    if any(len(layer) != count for layer in intermediate):
        raise ValueError('each intermediate boundary layer must supply a full grid')
    boundary = (list(range(columns))
                + [row*columns+columns-1 for row in range(1, rows)]
                + [(rows-1)*columns+column for column in range(columns-2, -1, -1)]
                + [row*columns for row in range(rows-2, 0, -1)])
    positions = list(bottom)
    grid_vertex_ids = {f'0:{index//columns}:{index%columns}': index
                       for index in range(count)}
    boundary_ids = [list(boundary)]
    for layer_index, layer in enumerate(intermediate, start=1):
        ids = []
        for index in boundary:
            vertex_id = len(positions)
            positions.append(layer[index])
            ids.append(vertex_id)
            grid_vertex_ids[f'{layer_index}:{index//columns}:{index%columns}'] = vertex_id
        boundary_ids.append(ids)
    top_offset = len(positions)
    positions.extend(top)
    top_layer = len(intermediate)+1
    for index in range(count):
        grid_vertex_ids[f'{top_layer}:{index//columns}:{index%columns}'] = top_offset+index
    boundary_ids.append([top_offset+index for index in boundary])
    faces = []
    for row in range(rows-1):
        for column in range(columns-1):
            a = row*columns+column
            b, c, d = a+1, a+columns, a+columns+1
            for triangle in ((a, b, d), (a, d, c)):
                faces.append((triangle[0], triangle[2], triangle[1]))
                faces.append(tuple(index+top_offset for index in triangle))
    for lower, upper in zip(boundary_ids, boundary_ids[1:]):
        for index, a in enumerate(lower):
            following = (index+1) % len(lower)
            b, c, d = lower[following], upper[index], upper[following]
            faces.extend(((a, b, d), (a, d, c)))
    result = _finalize(positions, faces)
    result['grid_vertex_ids'] = grid_vertex_ids
    return result


def closed_loft(rings, cap_diagonals=(0, 0)):
    """Join >=2 corresponding cyclic four-vertex rings with side triangles and caps.

    Caller supplies ring positions and correspondence. Each cap flag selects
    diagonal 0--2 (zero) or 1--3 (one), without changing vertex correspondence.
    No resampling, fitting or threshold adjustment occurs; malformed/degenerate
    results are rejected.
"""
    rings = [list(ring) for ring in rings]
    if len(rings) < 2 or any(len(ring) != 4 for ring in rings):
        raise ValueError('loft requires at least two four-vertex cyclic rings')
    cap_diagonals = tuple(cap_diagonals)
    if len(cap_diagonals) != 2 or any(type(flag) is not int or flag not in (0, 1)
                                      for flag in cap_diagonals):
        raise ValueError('cap_diagonals requires two integer flags in {0,1}')
    cap_faces = (((0, 1, 2), (0, 2, 3)), ((1, 2, 3), (1, 3, 0)))
    positions = [position for ring in rings for position in ring]
    faces = [(a, c, b) for a, b, c in cap_faces[cap_diagonals[0]]]
    for ring in range(len(rings)-1):
        first, second = ring*4, (ring+1)*4
        for corner in range(4):
            following = (corner+1) % 4
            a, b = first+corner, first+following
            c, d = second+corner, second+following
            faces.extend(((a, b, d), (a, d, c)))
    end = (len(rings)-1)*4
    faces.extend(tuple(end+corner for corner in face)
                 for face in cap_faces[cap_diagonals[1]])
    result = _finalize(positions, faces)
    result['ring_vertex_ids'] = [[ring*4+corner for corner in range(4)]
                                 for ring in range(len(rings))]
    return result
