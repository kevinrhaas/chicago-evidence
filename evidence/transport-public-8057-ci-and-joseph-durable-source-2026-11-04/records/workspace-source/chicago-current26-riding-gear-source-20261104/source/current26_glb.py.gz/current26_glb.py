# SPDX-License-Identifier: GPL-3.0-or-later
"""Serialize an unqualified current26 gear candidate; never copies horse meshes.

All inputs are in memory. This module performs no fitting, skin solving or native
qualification. The caller supplies authored weights, materials and full provenance.
"""
from copy import deepcopy
from hashlib import sha256
import json
from math import isfinite
from pathlib import Path
from struct import pack, unpack


def _float(value):
    number = float(value)
    if not isfinite(number):
        raise ValueError('non-finite floating-point input')
    try:
        rounded = unpack('<f', pack('<f', number))[0]
    except (OverflowError, ValueError) as error:
        raise ValueError('input outside finite binary32 range') from error
    if not isfinite(rounded):
        raise ValueError('input outside finite binary32 range')
    return rounded


def _rows(values, width, integer=False):
    result = []
    for source_row in values:
        row = tuple(source_row)
        if len(row) != width:
            raise ValueError('attribute row has incorrect width')
        if integer:
            if any(type(value) is not int or not 0 <= value <= 65535 for value in row):
                raise ValueError('joint components must be unsigned 16-bit integers')
        else:
            row = tuple(_float(value) for value in row)
        result.append(row)
    if not result:
        raise ValueError('empty attribute')
    return result


def _rig(source_doc):
    skin = source_doc['skins'][0]
    joints = list(skin['joints'])
    nodes = source_doc['nodes']
    if len(joints) != 26 or len(set(joints)) != 26:
        raise ValueError('skin zero must have exactly 26 ordered unique joints')
    if any(type(index) is not int or not 0 <= index < len(nodes) for index in joints):
        raise ValueError('invalid source joint node')
    parents = {}
    for index, node in enumerate(nodes):
        for child in node.get('children', []):
            if type(child) is not int or not 0 <= child < len(nodes) or child in parents:
                raise ValueError('invalid source node child or multiple parents')
            parents[child] = index
    closure = set()
    for joint in joints:
        chain = set()
        current = joint
        while current is not None:
            if current in chain:
                raise ValueError('cycle in source joint ancestry')
            chain.add(current)
            closure.add(current)
            current = parents.get(current)
    ordered = sorted(closure)
    mapping = {old: new for new, old in enumerate(ordered)}
    copied = []
    for old in ordered:
        node = nodes[old]
        copy = {key: deepcopy(node[key]) for key in
                ('name', 'matrix', 'translation', 'rotation', 'scale', 'extras') if key in node}
        if 'matrix' in copy and any(key in copy for key in ('translation', 'rotation', 'scale')):
            raise ValueError('source node mixes matrix and TRS transforms')
        for key, width in (('matrix', 16), ('translation', 3), ('rotation', 4), ('scale', 3)):
            if key in copy:
                if len(copy[key]) != width or not all(isfinite(float(v)) for v in copy[key]):
                    raise ValueError('invalid source rest transform')
        children = [mapping[child] for child in node.get('children', []) if child in closure]
        if children:
            copy['children'] = children
        copied.append(copy)
    names = [nodes[joint].get('name') for joint in joints]
    if any(not isinstance(name, str) or not name for name in names) or len(set(names)) != 26:
        raise ValueError('source joints must have 26 unique existing names')
    roots = [mapping[old] for old in ordered if parents.get(old) not in closure]
    output_skin = {'joints': [mapping[joint] for joint in joints]}
    if 'skeleton' in skin:
        if skin['skeleton'] not in closure:
            raise ValueError('source skeleton root outside joint ancestor closure')
        output_skin['skeleton'] = mapping[skin['skeleton']]
    if 'name' in skin:
        output_skin['name'] = skin['name']
    return copied, roots, output_skin, mapping, names


def write_current26(path, source_doc, inverse_bind_raw, parts, materials, provenance):
    """Write one fresh GLB and return byte identity plus actual stream/node metadata.

Each part supplies name, positions, normals, faces, JOINTS_0, WEIGHTS_0 and
material_index. Weights are serialized to F32 without normalization or filtering.
Zero-weight padding joint values are retained, including out-of-palette values.
Only nonzero-weight joints must address the 26-joint palette. This is not a skin,
collision, contact, appearance or riding acceptance check.
"""
    if source_doc.get('asset', {}).get('version') != '2.0':
        raise ValueError('source must be glTF 2.0')
    if not isinstance(provenance, dict) or not provenance:
        raise ValueError('explicit caller provenance is required')
    rig_nodes, roots, skin, node_mapping, joint_names = _rig(source_doc)
    inverse_bind_raw = bytes(inverse_bind_raw)
    if len(inverse_bind_raw) != 26*16*4:
        raise ValueError('26 raw F32 MAT4 inverse bind matrices required')
    if not all(isfinite(value) for value in unpack('<416f', inverse_bind_raw)):
        raise ValueError('non-finite source inverse bind matrix')
    source_ibm = source_doc['accessors'][source_doc['skins'][0]['inverseBindMatrices']]
    if (source_ibm.get('componentType'), source_ibm.get('type'), source_ibm.get('count')) != (5126, 'MAT4', 26):
        raise ValueError('source inverse bind accessor must be 26 F32 MAT4 values')
    materials = deepcopy(list(materials))
    if not materials:
        raise ValueError('at least one explicit flat PBR material required')
    def no_texture(value):
        if isinstance(value, dict):
            if any(key.endswith('Texture') for key in value):
                raise ValueError('texture references unsupported: no images are copied')
            for item in value.values():
                no_texture(item)
        elif isinstance(value, list):
            for item in value:
                no_texture(item)
    no_texture(materials)
    binary = bytearray()
    views, accessors = [], []
    def append(raw, component_type, kind, count, target=None, bounds=None):
        binary.extend(b'\x00' * ((-len(binary)) % 4))
        offset = len(binary)
        binary.extend(raw)
        view = {'buffer': 0, 'byteOffset': offset, 'byteLength': len(raw)}
        if target is not None:
            view['target'] = target
        view_id = len(views)
        views.append(view)
        accessor = {'bufferView': view_id, 'byteOffset': 0, 'componentType': component_type,
                    'count': count, 'type': kind}
        if bounds is not None:
            accessor['min'], accessor['max'] = bounds
        accessor_id = len(accessors)
        accessors.append(accessor)
        return accessor_id
    ibm_accessor = append(inverse_bind_raw, 5126, 'MAT4', 26)
    skin['inverseBindMatrices'] = ibm_accessor
    meshes, nodes, records = [], list(rig_nodes), []
    names = set()
    for part in parts:
        name = part['name']
        if not isinstance(name, str) or not name or name in names:
            raise ValueError('each part needs a unique nonempty name')
        names.add(name)
        positions = _rows(part['positions'], 3)
        normals = _rows(part['normals'], 3)
        joints = _rows(part['JOINTS_0'], 4, integer=True)
        # Check authored values before conversion too: a tiny nonzero weight must
        # never conceal an invalid joint by becoming zero during F32 conversion.
        authored_weights = [tuple(row) for row in part['WEIGHTS_0']]
        weights = _rows(authored_weights, 4)
        if not len(positions) == len(normals) == len(joints) == len(weights):
            raise ValueError('part attributes must have equal row counts')
        for joint_row, original_row, weight_row in zip(joints, authored_weights, weights):
            for joint, original, weight in zip(joint_row, original_row, weight_row):
                value = float(original)
                if not isfinite(value) or not 0 <= value <= 1 or not 0 <= weight <= 1:
                    raise ValueError('weights must be finite and within zero and one')
                if value != 0 and joint >= 26:
                    raise ValueError('nonzero weight outside actual 26-joint palette')
            if not any(value > 0 for value in weight_row):
                raise ValueError('vertex has no surviving positive weight')
        material = part['material_index']
        if type(material) is not int or not 0 <= material < len(materials):
            raise ValueError('invalid material index')
        faces = []
        for source_face in part['faces']:
            face = tuple(source_face)
            if len(face) != 3 or any(type(i) is not int or not 0 <= i < len(positions) for i in face):
                raise ValueError('invalid triangle indices')
            faces.append(face)
        if not faces or len(positions) > 4294967295:
            raise ValueError('empty or oversized part')
        bounds = ([min(row[axis] for row in positions) for axis in range(3)],
                  [max(row[axis] for row in positions) for axis in range(3)])
        def floats(rows):
            return b''.join(pack('<'+'f'*len(row), *row) for row in rows)
        attrs = {'POSITION': append(floats(positions), 5126, 'VEC3', len(positions), 34962, bounds),
                 'NORMAL': append(floats(normals), 5126, 'VEC3', len(normals), 34962),
                 'JOINTS_0': append(b''.join(pack('<4H', *row) for row in joints), 5123, 'VEC4', len(joints), 34962),
                 'WEIGHTS_0': append(floats(weights), 5126, 'VEC4', len(weights), 34962)}
        index_accessor = append(b''.join(pack('<3I', *face) for face in faces),
                                5125, 'SCALAR', len(faces)*3, 34963)
        mesh_id = len(meshes)
        meshes.append({'name': name, 'primitives': [{'attributes': attrs,
                       'indices': index_accessor, 'material': material, 'mode': 4}]})
        node_id = len(nodes)
        nodes.append({'name': name, 'mesh': mesh_id, 'skin': 0})
        roots.append(node_id)
        records.append({'name': name, 'mesh': mesh_id, 'node': node_id,
                        'vertices': len(positions), 'faces': len(faces),
                        'accessors': {**attrs, 'indices': index_accessor}})
    if not meshes:
        raise ValueError('at least one gear part required')
    doc = {'asset': {'version': '2.0', 'generator': 'Chicago4D current26 gear source serializer',
                    'extras': {'serializer_license': 'GPL-3.0-or-later',
                              'source_asset_metadata': deepcopy(source_doc['asset']),
                              'provenance': deepcopy(provenance),
                              'qualification': 'UNQUALIFIED_CURRENT26_GEAR_CANDIDATE'}},
           'scene': 0, 'scenes': [{'nodes': roots}], 'nodes': nodes, 'skins': [skin],
           'meshes': meshes, 'materials': materials, 'buffers': [{'byteLength': len(binary)}],
           'bufferViews': views, 'accessors': accessors}
    if 'copyright' in source_doc['asset']:
        doc['asset']['copyright'] = source_doc['asset']['copyright']
    json_bytes = json.dumps(doc, separators=(',', ':'), allow_nan=False).encode('utf-8')
    json_bytes += b' ' * ((-len(json_bytes)) % 4)
    bin_bytes = bytes(binary) + b'\x00' * ((-len(binary)) % 4)
    total = 12+8+len(json_bytes)+8+len(bin_bytes)
    if total > 4294967295:
        raise ValueError('GLB exceeds unsigned 32-bit container size')
    output = (pack('<III', 0x46546c67, 2, total)
              + pack('<II', len(json_bytes), 0x4e4f534a) + json_bytes
              + pack('<II', len(bin_bytes), 0x004e4942) + bin_bytes)
    with Path(path).open('xb') as target:
        target.write(output)
    return {'path': str(path), 'sha256': sha256(output).hexdigest(), 'bytes': len(output),
            'parts': records, 'inverse_bind_accessor': ibm_accessor,
            'source_node_to_output_node': {str(old): new for old, new in node_mapping.items()},
            'joint_nodes': skin['joints'], 'joint_names': joint_names,
            'fit_or_physics_or_riding_qualified': False}
