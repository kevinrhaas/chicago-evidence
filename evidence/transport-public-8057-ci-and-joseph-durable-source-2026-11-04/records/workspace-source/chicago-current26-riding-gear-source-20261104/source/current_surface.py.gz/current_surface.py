# SPDX-License-Identifier: GPL-3.0-or-later
"""Current native-rest surface input only; not a collision or riding qualification.

Imported/evaluated only on a later authorized build. No old horse or rig input.
"""
from pathlib import Path
from struct import pack,unpack
import hashlib,json,math,struct
import numpy as np

sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,message):
    if not ok:raise ValueError(message)

def glb(raw):
    need(struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw)),'Exact GLB2 header')
    n,t=struct.unpack_from('<II',raw,12);need(t==0x4e4f534a,'GLB JSON first')
    size,t=struct.unpack_from('<II',raw,20+n);need(t==0x004e4942 and len(raw)==28+n+size,'Exact original BIN')
    return json.loads(raw[20:20+n]),raw[28+n:]

def raw_accessor(d,b,i):
    a=d['accessors'][i];v=d['bufferViews'][a['bufferView']]
    sizes={5121:1,5123:2,5125:4,5126:4};counts={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
    need(not a.get('sparse')and not v.get('extensions',{}).get('EXT_meshopt_compression')and v['buffer']==0,'Pinned uncompressed accessor')
    element=sizes[a['componentType']]*counts[a['type']];stride=v.get('byteStride',element);off=v.get('byteOffset',0)+a.get('byteOffset',0)
    need(stride>=element and a.get('byteOffset',0)+(a['count']-1)*stride+element<=v['byteLength'],'Accessor within its source view')
    return b''.join(b[off+k*stride:off+k*stride+element]for k in range(a['count']))

class Surface:
    def __init__(self,config):
        self.config=config
        for r in config['files']:
            data=Path(r['path']).read_bytes();need(len(data)==r['bytes']and sha(data)==r['sha256'],'Source pin '+r['path'])
        need(config['standing_horse_sha256']=='7ce84d43445e930eecc6d9f69e97ed7ade0fe0b3fc44a9a753c25d88b3f548e1'and config['moving_horse_sha256']=='ad9dc060f8630d0de04fef97d716e8c82be3ac8bf070684e78107720c5221ec6','Explicit fixed current family, never oldproxy')
        need(sha(Path(config['native_closed']['path']).read_bytes())==config['native_closed']['sha256'],'Native closure reference hash')
        need(sha(Path(config['native_report']['path']).read_bytes())==config['native_report']['sha256'],'Native report reference hash')
        closed=json.loads(Path(config['native_closed']['path']).read_text())
        need(closed['status']=='CURRENT26_NATIVE_SKIN_TRACK_INTAKE_MEASURED_NOT_FIT','Actual native skin intake')
        need(closed['result']['returncode']==0 and closed['cleanup']['cleanup_complete']and not closed['cleanup']['remaining_owned_children']and closed['resources']['accepted'],'Closed native/cleanup/resource chain')
        report=json.loads(Path(config['native_report']['path']).read_text());self.report=report
        need(report['asset_sha256']==config['standing_horse_sha256'],'Exact current7ce source')
        need(report['total_triangles']==17390 and report['actual_skin_joint_count']==26,'Full current body family')
        body=next(m for m in report['meshes']if m['is_BODY']);self.body=body
        need(body['mesh']==1 and body['vertices']==5595 and body['triangles']==9794,'Actual BODY cohort')
        identity=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]
        need(all(body[k]==identity for k in('matrix_world','bind_matrix','bind_matrix_inverse')),'Measured canonical BODY frame')
        directory=Path(config['native_report']['path']).parent
        def stream(key,dtype,shape):
            meta=body['files'][key];data=(directory/meta['file']).read_bytes();need(sha(data)==meta['sha256']and len(data)==meta['bytes'],'Actual emitted '+key)
            return np.frombuffer(data,dtype=dtype).reshape(shape).copy()
        self.P=stream('vertices','<f8',(-1,3));self.F=stream('original_indices','<u4',(-1,3));self.J=stream('skin_indices','<u4',(-1,4));self.W=stream('skin_weights','<f8',(-1,4))
        self.T=self.P[self.F];self.A=self.T[:,0];self.E1=self.T[:,1]-self.A;self.E2=self.T[:,2]-self.A
        self.names=[j['name']for j in body['joints']];need(self.names[1]=='horse_body','Current horse_body binding')
        source_bytes=Path(config['standing_asset']).read_bytes();need(sha(source_bytes)==config['standing_horse_sha256'],'Original current standing bytes')
        self.doc,self.bin=glb(source_bytes)
        need(len(self.doc['skins'][0]['joints'])==26,'Exact current26 source skin')
        need([self.doc['nodes'][i]['name']for i in self.doc['skins'][0]['joints']]==self.names,'Source/native joint order')
        a=self.doc['accessors'][self.doc['skins'][0]['inverseBindMatrices']]
        need(a['type']=='MAT4'and a['componentType']==5126 and a['count']==26,'Current raw inverse binds')
        self.ibm=raw_accessor(self.doc,self.bin,self.doc['skins'][0]['inverseBindMatrices'])
        self.cache={};self.queries=[]

    def ray(self,origin,direction):
        key=tuple(origin)+tuple(direction)
        if key in self.cache:return self.cache[key]
        o=np.array(origin,dtype=float);v=np.array(direction,dtype=float);need(np.isfinite(o).all()and np.isfinite(v).all()and np.linalg.norm(v)>0,'Finite query')
        h=np.cross(np.broadcast_to(v,self.E2.shape),self.E2);det=np.einsum('ij,ij->i',self.E1,h);valid=det!=0
        inv=np.zeros_like(det);inv[valid]=1/det[valid];s=o-self.A;u=inv*np.einsum('ij,ij->i',s,h);q=np.cross(s,self.E1);w=inv*np.einsum('j,ij->i',v,q);t=inv*np.einsum('ij,ij->i',self.E2,q)
        b0=1-u-w;ids=np.flatnonzero(valid&(u>=0)&(w>=0)&(b0>=0)&(u<=1)&(w<=1)&(b0<=1)&(t>0));need(len(ids)>0,'No actual BODY intersection')
        face=min(map(int,ids),key=lambda i:(float(t[i]),i));bary=[float(b0[face]),float(u[face]),float(w[face])]
        normal=np.cross(self.E1[face],self.E2[face]);normal=normal/np.linalg.norm(normal)
        point=np.sum(self.T[face]*np.array(bary)[:,None],axis=0)
        need(np.isfinite(point).all()and np.isfinite(normal).all(),'Finite actual surface')
        out={'face':face,'indices':list(map(int,self.F[face])),'barycentric':bary,'surface_world_m':point.tolist(),'source_winding_unit_normal':normal.tolist(),'query_origin':list(origin),'query_direction':list(direction)}
        self.cache[key]=out;self.queries.append(out);return out

    def dorsal(self,x,z):
        ref=self.ray([float(x),float(self.P[:,1].max()+1),float(z)],[0,-1,0]);need(ref['source_winding_unit_normal'][1]>0,'Actual upper winding');return ref

    def radial(self,theta,z,cy=1.05):
        direction=[math.sin(theta),math.cos(theta),0.]
        ref=self.ray([0.,cy,float(z)],direction)
        need(sum(a*b for a,b in zip(ref['source_winding_unit_normal'],direction))>0,'Actual radial exit winding');return ref

    def bind(self,ref,rigid=False):
        if rigid:return ([1,0,0,0],[1.,0.,0.,0.])
        weights={}
        for vertex,c in zip(ref['indices'],ref['barycentric']):
            for joint,w in zip(self.J[vertex],self.W[vertex]):
                if w==0:continue
                joint=int(joint);need(0<=joint<26,'Nonzero current native palette');weights[joint]=weights.get(joint,0.)+c*float(w)
        weights={j:w for j,w in weights.items()if w>0}
        need(0<len(weights)<=4,'No influence pruning: current source face must fit four slots')
        ordered=sorted(weights,key=lambda j:(-weights[j],j));total=math.fsum(weights.values());need(total>0 and math.isfinite(total),'New gear influence sum')
        js=ordered+[0]*(4-len(ordered));ws=[weights[j]/total for j in ordered]+[0.]*(4-len(ordered))
        need(all(unpack('<f',pack('<f',w))[0]>0 for w in ws[:len(ordered)]),'No nonzero authored influence may disappear in F32 serialization')
        return js,ws
