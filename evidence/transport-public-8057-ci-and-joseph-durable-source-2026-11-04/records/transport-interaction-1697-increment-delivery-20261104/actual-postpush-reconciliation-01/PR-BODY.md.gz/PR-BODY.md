Named drivers keep their configured pace and wait through cold Find loading. Go to now stays docked while Inspect loads, newer navigation supersedes late completion, and empty transport roots no longer cause Light-transition console errors. The 1904 people-card API remains available; smoke checks inspect actual directory DOM, source-owned yard modes and exact material-batch classes. This 19-path increment preserves assets and route geometry from reviewed DEV6eeee.

Validation:

- Native coverage spans 1,163 distinct checks and 402 self-tests with unchanged 600-second part caps. Parts 1–2 qualified tree e384 in 484.030/516.109 seconds; parts 3–4 qualified tree 5ed4 in 355.051/360.244 seconds. The explicit tooling-only bridge expands one coverage-map row from [13] to [13, 14]; all_four_same_TREE=false. Original map and missing-local-base failures remain preserved. Strict base readers and complete affected parts passed after correction.
- Committed HEAD 8057b7d6 passes all five QA checks, both whitespace checks and native publish/check. Actual-module mobile/desktop DOM checks reproduce the original negatives and pass the repair at the original 150 ms Dock assertion, with Hans cards and zero Light-transition errors.
- Fresh CI on this HEAD is pending. Global Light/shadow full-smoke failures remain OPEN and block merge; whole published-smoke acceptance is not claimed.

Broad T1790/T2804/T3088 remain claimed with pr:null. Animation, clothing, gait, riding, boarding and photographic goals remain open.
