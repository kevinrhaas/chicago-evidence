"""Read current frame input closure only; never emit or rewrite an asset/registry."""
from pathlib import Path
from urllib.request import Request,urlopen
import base64,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=Path('/tmp/wolf-poster-source-20261103/chicago/4d');BASE='485ca2736e9e5e38dc8aaa8f5700d57ef8dee298';sha=lambda b:hashlib.sha256(b).hexdigest()
def api(p):
 with urlopen(Request('https://api.github.com/repos/kevinrhaas/chicago/'+p,headers={'User-Agent':'Chicago-T2380-family-input-readback'}),timeout=45)as r:return json.load(r)
d=api('contents/chicago/4d/assets/manifest.json?ref='+BASE)
if d.get('encoding')!='base64':d=api('git/blobs/'+d['sha'])
b=base64.b64decode(d['content']);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==d['sha'];(O/'current-master-manifest.json').write_bytes(b);manifest=json.loads(b)['assets'];roster={k:v for k,v in manifest.items()if v.get('archetype')=='frame_dwelling'}
sys.path[:0]=[str(R/'generators'),str(R/'tools')];import mesh_inputs
rows=[];records={}
for name,row in sorted(roster.items()):
 p=R/'data/structures'/f"{row['structure_id']}.json";raw=p.read_bytes();rec=json.loads(raw);ph=next(x for x in rec['phases']if x['id']==row['phase_id']);old=mesh_inputs.structure_inputs_sha(rec,ph);assert old==row['inputs_sha256'],name;master=(R/'assets/gltf'/name).read_bytes();web=(R/'assets/web'/name).read_bytes();records[name]=(rec,ph)
 rows.append({'asset':name,'structure':row['structure_id'],'phase':row['phase_id'],'current_record_sha256':sha(raw),'current_recipe':old,'current_MASTER_sha256':sha(master),'current_MASTER_bytes':len(master),'current_WEB_sha256':sha(web),'current_WEB_bytes':len(web)})
name='archetypes.frame_dwelling_params';p=O/'postimages/generators/archetypes/frame_dwelling_params.py';sp=importlib.util.spec_from_file_location(name,p);mod=importlib.util.module_from_spec(sp);sys.modules[name]=mod;sp.loader.exec_module(mod);old_sha=mesh_inputs._sha_file;mesh_inputs._sha_file=lambda f:sha((O/'postimages/generators/archetypes/frame_dwelling.py').read_bytes())if Path(f)==R/'generators/archetypes/frame_dwelling.py'else old_sha(f)
for row in rows:
 rec,ph=records[row['asset']];row['candidate_recipe_prediction']=mesh_inputs.structure_inputs_sha(rec,ph);assert row['candidate_recipe_prediction']!=row['current_recipe']
out={'base':BASE,'manifest_git_blob':d['sha'],'scope':'ACTUAL_CURRENT_INPUT_AND_ASSET_READBACK_WITH_PREDICTED_NEW_RECIPES_NOT_NATIVE_GEOMETRY_PARITY','family_count':len(rows),'current_MASTER_bytes':sum(x['current_MASTER_bytes']for x in rows),'current_WEB_bytes':sum(x['current_WEB_bytes']for x in rows),'all_current_recipes_match_actual_manifest':True,'all_new_recipes_stale_due_to_optin_builder_and_param_change':True,'native_emit_or_web_encode_ran':False,'rows':rows};(O/'CURRENT-FAMILY-ROSTER-AND-PREDICTIONS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='rows'}))
