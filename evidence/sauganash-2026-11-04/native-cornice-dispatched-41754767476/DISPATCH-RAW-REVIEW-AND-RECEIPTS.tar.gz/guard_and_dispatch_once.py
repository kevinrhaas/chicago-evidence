from pathlib import Path
import subprocess,json,base64,datetime,re
P=Path(__file__).resolve().parent
S=json.loads((P/'DISPATCH-REVIEW.json').read_bytes());HEAD=S['expected_feature_head']
def api(repo,path,missing=False):
 q=subprocess.run(['gh','api','repos/kevinrhaas/'+repo+'/'+path],capture_output=True)
 if missing and q.returncode and 'HTTP 404'in q.stderr.decode():return None
 assert q.returncode==0,q.stderr.decode();return json.loads(q.stdout)
assert not (P/'DISPATCH-ATTEMPT.json').exists(),'A dispatch was already attempted; never repeat on uncertainty'
feature=api('polecat-platform','git/ref/heads/'+S['ref']);assert feature['object']['sha']==HEAD
ci=[api('polecat-platform','actions/runs/'+str(i))for i in [41752421848,41752413970]];assert all(x['head_sha']==HEAD and x['status']=='completed'and x['conclusion']=='success'for x in ci)
dev=api('chicago','git/ref/heads/dev')['object']['sha']
expected={'chicago/4d/generators/archetypes/frame_tavern.py':'074e65335525503106c4eacd3dffc752bb076df2','chicago/4d/generators/archetypes/frame_tavern_params.py':'b7f0783c2947e28a7830d9bb6e86879f808b30b0','chicago/4d/data/structures/sauganash_hotel.json':'82077d6d9fbae7c4d7867395a58363f9fc2fd2f1','chicago/4d/assets/gltf/sauganash_hotel__frame_1831.glb':'f07142bfc9a2075c205e1e17e00a33c88262f3a0','chicago/4d/assets/web/sauganash_hotel__frame_1831.glb':'028fabb40cb92825999894a8a7add3f886aaf952'}
owned=[]
for path,sha in expected.items():
 x=api('chicago','contents/'+path+'?ref='+dev);assert x['sha']==sha,'OWNED SOURCE CHANGED '+path;owned.append({'path':path,'blob':x['sha'],'reviewed_baseline_exact':True})
prs=api('chicago','pulls?state=open&per_page=100');overlap=[x for x in prs if re.search(r't-?2383|sauganash',x['title']+' '+x['head']['ref'],re.I)];assert not overlap,'Live Sauganash PR'
laps=api('chicago','git/matching-refs/heads/lap/');oldlap=[x for x in laps if x['ref']=='refs/heads/lap/pr-1680'];assert not oldlap,'Old Sauganash lap still present; review owner before dispatch'
t=api('chicago-tickets','contents/'+S['ticket_path']);body=base64.b64decode(t['content']);assert body==(P/'TICKET-FINAL-HANDOFF.md').read_bytes(),'Ticket changed since released handoff';front=body.decode().split('---',2)[1];assert '\nstate: open\n'in front and '\nclaimed_by: null\n'in front and '\npr: null\n'in front
roster=api('polecat-platform','actions/workflows/steward-improve.yml/runs?per_page=50');assert not any(S['inputs']['lane']in x['display_title']for x in roster['workflow_runs']),'A run already exists for exact new lane'
gt=api('chicago','pulls/1684');guard={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root_approved_actual_handoff_and_dispatch':True,'feature':feature,'both_exact_head_ci':ci,'current_dev':dev,'owned_source':owned,'open_pr_overlap':overlap,'old1680lap_absent':True,'laps_observed':laps,'ticket_blob':t['sha'],'ticket_body_exact_released_handoff':True,'ticket_frontmatter':front,'GT':{'state':gt['state'],'merged':gt['merged'],'head':gt['head']['sha']},'roster':roster,'dispatch_inputs':S['inputs']}
(P/'FRESH-DISPATCH-GUARDS.json').write_text(json.dumps(guard,indent=2)+'\n')
request={'ref':S['ref'],'inputs':S['inputs']};attempt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'single_post_only':True,'request':request,'expected_head':HEAD,'target':'repos/kevinrhaas/polecat-platform/actions/workflows/steward-improve.yml/dispatches','no_uncertainty_retry':True};(P/'DISPATCH-ATTEMPT.json').write_text(json.dumps(attempt,indent=2)+'\n')
q=subprocess.run(['gh','api','--include','repos/kevinrhaas/polecat-platform/actions/workflows/steward-improve.yml/dispatches','--method','POST','--input','-'],input=json.dumps(request).encode(),capture_output=True);(P/'DISPATCH-POST-STDOUT.log').write_bytes(q.stdout);(P/'DISPATCH-POST-STDERR.log').write_bytes(q.stderr)
response={'exit':q.returncode,'accepted_http204':bool(re.search(rb'HTTP/[^ ]+ 204',q.stdout)),'one_post_attempt':True,'no_retry':True};(P/'DISPATCH-POST-RESULT.json').write_text(json.dumps(response,indent=2)+'\n');assert q.returncode==0 and response['accepted_http204'],'Dispatch response uncertain or rejected; inspect/read roster, DO NOT retry POST'
print(json.dumps({'status':'ONE_EXACT_DISPATCH_POST_ACCEPTED_HTTP204','ref':S['ref'],'head':HEAD,'dev':dev,'ticket':S['inputs']['target_ticket'],'lane':S['inputs']['lane'],'max_turns':S['inputs']['max_turns']}),flush=True)
