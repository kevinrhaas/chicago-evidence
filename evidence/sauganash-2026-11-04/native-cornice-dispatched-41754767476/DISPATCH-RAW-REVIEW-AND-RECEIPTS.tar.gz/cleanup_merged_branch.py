from pathlib import Path
import subprocess,json,base64,datetime
P=Path(__file__).resolve().parent
repo='repos/kevinrhaas/chicago/';old='steward/t2383-sauganash-andreas-current-20261103';backup='archive/sauganash-andreas-merged-1680-20261104';sha='27ab2f3b6dc38547e2668ced16191c30c0e8ca48'
def api(path,body=None,method=None,missing=False):
 cmd=['gh','api',repo+path]
 if method:cmd+=['--method',method]
 if body is not None:cmd+=['--input','-']
 q=subprocess.run(cmd,input=None if body is None else json.dumps(body).encode(),capture_output=True)
 if missing and q.returncode and 'HTTP 404' in q.stderr.decode():return None
 assert q.returncode==0,q.stderr.decode()
 return json.loads(q.stdout)if q.stdout.strip()else None
pr=api('pulls/1680');assert pr['merged'] and pr['state']=='closed' and pr['head']['sha']==sha and pr['head']['ref']==old and pr['merge_commit_sha']=='6953d4131bf741a1d56a141a83b0bc852b8cb56b'
ref=api('git/ref/heads/'+old);assert ref['object']['sha']==sha
prior=api('git/ref/heads/'+backup,missing=True);assert prior is None or prior['object']['sha']==sha
attempt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorization':'Root explicitly authorized exact completed-PR1680 branch archive+standard deletion to permit normal claim; no force','old':old,'backup':backup,'exact_head':sha,'prior_backup_exists':prior is not None,'pr1680':pr}
(P/'BRANCH-CLEANUP-ATTEMPT.json').write_text(json.dumps(attempt,indent=2)+'\n')
if prior is None:api('git/refs',{'ref':'refs/heads/'+backup,'sha':sha},'POST')
b=api('git/ref/heads/'+backup);assert b['object']['sha']==sha;(P/'ARCHIVE-REF-EXACT.json').write_text(json.dumps(b,indent=2)+'\n')
openprs=api('pulls?state=open&per_page=100');assert not any(x['head']['ref']==old or x['title'].startswith(('T-2383:','T2383:'))for x in openprs)
tq=subprocess.run(['gh','api','repos/kevinrhaas/chicago-tickets/contents/T-2250-2499/T-2383-match-the-sauganash-hotel-to-its-pictures.md'],capture_output=True);assert tq.returncode==0;t=json.loads(tq.stdout);front=base64.b64decode(t['content']).decode().split('---')[1];assert '\nstate: open\n'in front and '\nclaimed_by: null\n'in front and '\npr: null\n'in front
fresh=api('git/ref/heads/'+old);assert fresh['object']['sha']==sha
(P/'BRANCH-PREDELETE-GUARD.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_ref':fresh,'backup_ref':b,'ticket_blob':t['sha'],'ticket_frontmatter':front,'open_same_branch_or_ticket':False,'pr1680_merged_exact_head':True},indent=2)+'\n')
api('git/refs/heads/'+old,method='DELETE')
assert api('git/ref/heads/'+old,missing=True)is None
assert api('git/ref/heads/'+backup)['object']['sha']==sha
(P/'BRANCH-CLEANUP-RESULT.json').write_text(json.dumps({'status':'EXACT_MERGED_BRANCH_ARCHIVED_AND_STANDARD_DELETED','old_ref_absent_404':True,'backup_ref':backup,'backup_sha':sha,'normal_create_no_force':True,'ticket_writes':False,'source_writes':False},indent=2)+'\n')
print(json.dumps({'status':'EXACT_MERGED_BRANCH_ARCHIVED_AND_STANDARD_DELETED','backup':backup,'sha':sha}),flush=True)
