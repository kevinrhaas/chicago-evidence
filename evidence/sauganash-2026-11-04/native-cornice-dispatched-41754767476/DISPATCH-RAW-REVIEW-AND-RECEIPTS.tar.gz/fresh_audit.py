from pathlib import Path
import subprocess,json,base64,hashlib,datetime
P=Path(__file__).resolve().parent
D=json.loads((P/'DEV-REF.json').read_bytes())['object']['sha']
def api(repo,path,out):
 q=subprocess.run(['gh','api','repos/kevinrhaas/'+repo+'/'+path],capture_output=True);assert q.returncode==0,q.stderr.decode();x=json.loads(q.stdout);(P/out).parent.mkdir(parents=True,exist_ok=True);(P/out).write_bytes(q.stdout);return x
def content(path,out):
 x=api('chicago','contents/'+path+'?ref='+D,out+'.CONTENTS.json')
 b=base64.b64decode(x['content'])if x.get('content')else base64.b64decode(api('chicago','git/blobs/'+x['sha'],out+'.BLOB.json')['content'])
 (P/out).write_bytes(b);return x['sha'],b
prs=api('chicago','pulls?state=open&per_page=100','OPEN-PRS.json')
runs=api('polecat-platform','actions/workflows/steward-improve.yml/runs?per_page=40','WORKER-ROSTER.json')
refs=api('chicago','git/matching-refs/heads/steward','STEWARD-REFS.json')
overlap=[{'number':x['number'],'title':x['title'],'head':x['head']['sha'],'branch':x['head']['ref']}for x in prs if any(a in (x['title']+' '+x['head']['ref']).lower()for a in ['t-2383','t2383','sauganash'])]
related=[x for x in refs if any(v in x['ref'].lower()for v in ['t2383','t-2383','sauganash'])]
manifest_blob,b=content('chicago/4d/assets/manifest.json','MASTER-MANIFEST.json');m=json.loads(b);rows=m.get('assets',[]);rows=list(rows.values())if isinstance(rows,dict)else rows;family=[x for x in rows if x.get('archetype')=='frame_tavern']
if not family:
 print('MANIFEST_TOP_KEYS',list(m)[:15]);raise SystemExit('Unexpected manifest format')
(P/'CURRENT-FAMILY.json').write_text(json.dumps({'head':D,'manifest_blob':manifest_blob,'count':len(family),'rows':family},indent=2)+'\n')
ids=[]
for path,out in [('chicago/4d/assets/gltf/sauganash_hotel__frame_1831.glb','HOTEL-MASTER.glb'),('chicago/4d/assets/web/sauganash_hotel__frame_1831.glb','HOTEL-WEB.glb')]:
 blob,b=content(path,out);ids.append({'path':path,'blob':blob,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
canon=json.loads(Path('/tmp/sauganash-next-geometry-readiness-20261104/AFFECTED-CANONICAL-GROUPS.json').read_bytes());now=[]
for row in canon:
 a=dict(row)
 for kind,path in [('camera',row['path']),('match',row['match_path'])]:
  blob,b=content('chicago/4d/'+path,'canonical/'+path)
  a[kind+'_blob']=blob;a[kind+'_sha256']=hashlib.sha256(b).hexdigest()
  if kind=='match':a['current_match']=json.loads(b)
 now.append(a)
(P/'CURRENT-CANONICAL-GROUPS.json').write_text(json.dumps(now,indent=2)+'\n')
for n in [1680,1684]:api('chicago','pulls/'+str(n),'PR'+str(n)+'.json')
audit={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'dev':D,'ticket_snapshot':json.loads((P/'TICKET-REF.json').read_bytes())['object']['sha'],'open_pr_overlap':overlap,'related_remote_branches':related,'current_family_count':len(family),'hotel_outputs':ids,'no_claim_source_edit_dispatch_or_native_build':True}
(P/'FRESH-AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps({'dev':D,'overlap':overlap,'related_branches':[x['ref']for x in related],'family':len(family),'hotel':ids}),flush=True)
