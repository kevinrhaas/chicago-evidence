from pathlib import Path
import json
P=Path(__file__).parent;B=Path('/tmp/first-fort-magazine-prep-20261104/controller.py');s=B.read_text().replace('NEW T-3041','NEW T-2383').replace('first-fort-magazine-native-20261104','sauganash-stacks-native-20261104').replace("T-3000-3249/T-3041-match-the-first-fort-dearborn-buildings-against-.md","T-2250-2499/T-2383-match-the-sauganash-hotel-to-its-pictures.md").replace("'T-3041'","'T-2383'").replace('T3041','T2383').replace('3041\\b','2383\\b').replace("'## Native magazine vault handoff — 2026-11-04'","'## Sauganash stacks native handoff — 2026-11-04'").replace('UNQUALIFIED-CANDIDATE.patch','UNQUALIFIED-DATA-ONLY.patch')
s=s.replace('import argparse,base64,concurrent.futures,datetime,hashlib,json,os,re,subprocess,time','import argparse,base64,concurrent.futures,datetime,hashlib,json,os,re,subprocess,time,urllib.request')
a=s.index("CUPOLA_HEAD=");b=s.index('FEATURE_GUARDS=',a)
s=s[:a]+"BASE_BLOBS="+repr(json.loads((P/'APPROVED-BASE-BLOBS.json').read_bytes()))+"\nAUTH_PREFIX='evidence/sauganash-2026-11-04/stacks-native-execution-authorization/'\n"+s[b:]
a=s.index('PATHS=');b=s.index('\ndef sha(',a)
paths=list(json.loads((P/'APPROVED-BASE-BLOBS.json').read_bytes()))+['assets/gltf/sauganash_hotel__frame_1831.glb','assets/web/sauganash_hotel__frame_1831.glb','data/structures/green_tree_tavern.json','assets/gltf/green_tree_tavern__frame_1833.glb','assets/web/green_tree_tavern__frame_1833.glb','data/structures/philo_carpenter_log_shop.json','assets/gltf/philo_carpenter_log_shop__log_1832.glb','assets/web/philo_carpenter_log_shop__log_1832.glb','generators/archetypes/fort_structure.py','generators/archetypes/fort_structure_params.py','data/structures/fort_dearborn_blockhouse.json','assets/gltf/fort_dearborn_blockhouse__log_1816.glb','assets/web/fort_dearborn_blockhouse__log_1816.glb','data/structures/first_fort_dearborn_magazine.json','generators/emit.py','generators/blender.pin','generators/mesh_inputs.py','generators/code_inputs.py','generators/common/mesh.py','data/structure_grades.json','docs/LIBERTIES.md','renderers/web/js/main.js','renderers/web/js/buildings.js','renderers/web/js/scene-loader.js']
for name in ['andreas-1884','kurz-allison-1893-panel14','trowbridge-1902']:
 paths+=['data/reference_views/philo_carpenter_log_shop/'+name+'.json','data/reference_views/philo_carpenter_log_shop/'+name+'.match.json']
s=s[:a]+'PATHS='+repr(paths)+s[b:]
a=s.index('def audit(strict=False):');b=s.index('\ndef prepare():',a)
s=s[:a]+'''def audit(strict=False):
 ftr=feature();t,b,f=ticket();prs=open_target_prs();runs=active_runs();conflicts=[{k:x[k]for k in ['id','display_title','status','head_sha']}for x in runs if LANE in x['display_title']or re.search(r'(?i)T[-_ ]?2383\\b',x['display_title'])];src=source();by={r['path']:r['git_blob']for r in src['paths']};block=[]
 if any(f.get(k)!='null'for k in ['claimed_by','claimed_run','claimed_at','pr'])or f.get('state')!='open':block.append('OriginalT2383 not normally OPEN/free')
 if prs:block.append('OpenPR mentions T2383; inspect association before any work')
 if conflicts:block.append('Live T2383/unique lane run')
 if any(by.get(p)!=h for p,h in BASE_BLOBS.items()):block.append('Currentdev approved Sauganash record/producer/camera/source baseline moved; rebind/review')
 fam=src['families']['frame_tavern'];defaults=fam['defaults'];variants=fam['variants']
 if len(defaults)!=23 or len(variants)!=2:block.append('Fresh frame inventory is not23defaults+2variants; inspect actual scope')
 gt='green_tree_tavern__frame_1833.glb'
 if defaults.get(gt,{}).get('inputs_sha256')!='712cb7c9530c5c6d6fba6b83c7d2b6e2e19d49f78e94da7ebf688ee3937c6974' or fam['web_master_bindings'].get(gt)!='f213818f5a686d31bfbb07217233a7021c514be64b841035d3c29996a380807b':block.append('MergedGT712cb/f213 preservation guard moved')
 if any(v.get('structure_id')=='sauganash_hotel'for v in variants.values()):block.append('Sauganash variant now exists; re-inventory affected scope')
 if MARKER.encode()not in b:block.append('Reviewed public handoff not yet attached to original ticket')
 if not all(x['status']=='completed'and x['conclusion']=='success'for x in ftr['hosted']):block.append('Exact owner-safe feature CI not green')
 if strict:assert not block,block
 return {'utc':now(),'feature':FEATURE,'feature_guards':ftr,'request':REQUEST,'ticket_blob':t['sha'],'ticket_fields':f,'ticket_body_sha256':sha(b),'open_target_prs':prs,'live_target_runs':conflicts,'source':src,'blockers':block,'dispatch_allowed':not block,'read_only':True}

def verify_public_go(go_bytes):
 receipt=json.loads((P/'PUBLIC-GO-RECEIPT.json').read_bytes());assert receipt['prefix']==AUTH_PREFIX
 assert receipt['files']['ROOT-GO.json']['sha256']==sha(go_bytes)
 url='https://raw.githubusercontent.com/kevinrhaas/chicago-evidence/'+receipt['commit']+'/'+AUTH_PREFIX+'ROOT-GO.json'
 with urllib.request.urlopen(url,timeout=30)as r:raw=r.read()
 assert raw==go_bytes,'Exact actual rootGO must be PUBLIC before any POST'
 # The stable handoff locator must also resolve to this actual GO, never a false template.
 stable='https://raw.githubusercontent.com/kevinrhaas/chicago-evidence/main/'+AUTH_PREFIX+'ROOT-GO.json'
 with urllib.request.urlopen(stable+'?_='+str(time.time_ns()),timeout=30)as r:assert r.read()==go_bytes
 proof={'utc':now(),'public_commit':receipt['commit'],'immutable_url':url,'stable_url':stable,'root_go_sha256':sha(go_bytes),'actual_GO_public_BEFORE_POST':True}
 dump('PUBLIC-GO-VERIFIED.json',proof);return proof
''' + s[b:]
s=s.replace("go=json.loads((P/'ROOT-GO.json').read_bytes());expected=", "go_bytes=(P/'ROOT-GO.json').read_bytes();go=json.loads(go_bytes);expected=")
s=s.replace("assert json.loads((P/'REQUEST.json').read_bytes())==REQUEST", "public_go=verify_public_go(go_bytes)\n assert json.loads((P/'REQUEST.json').read_bytes())==REQUEST")
s=s.replace("'state':'RESERVED_BEFORE_SINGLE_POST_NO_RETRY'", "'public_GO':public_go,'state':'RESERVED_BEFORE_SINGLE_POST_NO_RETRY'")
s=s.replace('cupola merge and','public actual GO and')
(P/'controller.py').write_text(s)
