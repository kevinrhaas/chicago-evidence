"""Authorized normal append-only metadata, exact source/claim/prefix CAS. No claim."""
from pathlib import Path
import subprocess,json,base64,hashlib,time
P=Path(__file__).parent;REPO='repos/kevinrhaas/chicago-tickets/';REL='T-3000-3249/T-3041-match-the-first-fort-dearborn-buildings-against-.md';tail=b'\n\n'+(P/'HANDOFF.md').read_bytes();MARKER='## Native magazine vault handoff — 2026-11-04'.encode()
def api(p,data=None,method=None):
 cmd=['gh','api','-H','Cache-Control: no-cache',p]
 if data is not None:cmd+=['--method',method or'POST','--input','-']
 r=subprocess.run(cmd,input=None if data is None else json.dumps(data).encode(),capture_output=True,timeout=45);assert r.returncode==0,r.stderr;return json.loads(r.stdout)
assert len(tail)<9010 and not(P/'TICKET-APPEND-ATTEMPT.json').exists()
raw=json.loads((P/'RAW-PATCH-PUBLIC-READBACK.json').read_bytes());assert raw['sha256']=='661b69b2c544c73af8745be7f5b55bc142f3e2d338f6abd19a6cf8fddf4f17f5'
# Root explicitly reviewed the frozen design and authorized only trim/raw-link and this append.
go={'authorized_append_only':True,'source':'Root explicit instruction: finish immutable publication, trimHANDOFF<9000, append preservingfields/foreigntext; NOclaim/dispatch','handoff_sha256':hashlib.sha256((P/'HANDOFF.md').read_bytes()).hexdigest(),'patch_sha256':raw['sha256']};(P/'ROOT-METADATA-GO.json').write_text(json.dumps(go,indent=2)+'\n')
up=api('repos/kevinrhaas/chicago/pulls/1687');assert up['merged']and up['head']['sha']=='52d6f631df788258a50a6e3271cca9e97ba960ac'
tip=api(REPO+'git/ref/heads/main')['object']['sha'];d=api(REPO+'contents/'+REL+'?ref='+tip);old=base64.b64decode(d['content']);assert hashlib.sha1(b'blob '+str(len(old)).encode()+b'\0'+old).hexdigest()==d['sha'];front=old.decode().split('---',2)[1];f={l.split(':',1)[0]:l.split(':',1)[1].strip()for l in front.splitlines()if':'in l};assert f['state']=='open'and all(f[k]=='null'for k in ['claimed_by','claimed_run','claimed_at','pr']),f;assert MARKER not in old
(P/'TICKET-APPEND-BEFORE.md').write_bytes(old);new=old+tail;assert new.startswith(old)
(P/'TICKET-APPEND-ATTEMPT.json').write_text(json.dumps({'before_tip':tip,'before_blob':d['sha'],'append_sha256':hashlib.sha256(tail).hexdigest(),'handoff_sha256':go['handoff_sha256'],'single_normal_SHA_guarded_PUT':True},indent=2)+'\n')
r=api(REPO+'contents/'+REL,{'message':'T-3041: append reviewed unqualified magazine-vault native handoff; keep original open','branch':'main','sha':d['sha'],'content':base64.b64encode(new).decode()},'PUT');h=r['commit']['sha'];v=api(REPO+'contents/'+REL+'?ref='+h);actual=base64.b64decode(v['content']);assert actual==new and actual.startswith(old)and actual.decode().split('---',2)[1]==front
commit=api(REPO+'git/commits/'+h);parent=commit['parents'][0]['sha'];compare=api(REPO+'compare/'+parent+'...'+h);assert len(compare['files'])==1 and compare['files'][0]['filename']==REL
receipt={'commit':h,'actual_parent':parent,'before_tip':tip,'before_blob':d['sha'],'after_blob':v['sha'],'prior_foreign_body_byte_exact_prefix':True,'front_matter_byte_exact':True,'original_OPEN_free_prnull_preserved':True,'append_sha256':hashlib.sha256(tail).hexdigest(),'handoff_sha256':go['handoff_sha256'],'only_ticket_MD_changed':True,'no_claim_no_force_no_dispatch_no_appsourcewrite':True,'immutable_commit_readback_exact':True};(P/'TICKET-APPEND-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');(P/'TICKET-APPEND-PUBLISHED.md').write_bytes(actual);print(json.dumps(receipt),flush=True)
