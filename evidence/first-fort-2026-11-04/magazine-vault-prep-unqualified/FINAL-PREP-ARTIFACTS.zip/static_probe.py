"""External AST/pure-math probe only. No Blender/module import or repo mutations."""
from pathlib import Path
import ast,math,json,types,collections,importlib.util,sys,dataclasses,hashlib
P=Path(__file__).parent;B=P/'cupola-base';C=P/'candidate'
def load(label,path):
 spec=importlib.util.spec_from_file_location(label,path);m=importlib.util.module_from_spec(spec);sys.modules[label]=m;spec.loader.exec_module(m);return m
old=load('magazine_base_params',B/'generators/archetypes/fort_structure_params.py');new=load('magazine_candidate_params',C/'generators/archetypes/fort_structure_params.py')
record=json.loads((C/'data/structures/first_fort_dearborn_magazine.json').read_bytes());p=new.from_phase(record['phases'][0],record);baseline=json.loads((B/'data/structures/first_fort_dearborn_magazine.json').read_bytes());q=old.from_phase(baseline['phases'][0],baseline)
assert p.width_m==q.width_m and p.depth_m==q.depth_m and p.wall_height_m==q.wall_height_m and p.chimneys==q.chimneys==0
h=p.barrel_rise_m;oldpeak=q.wall_height_m+min(q.width_m,q.depth_m)/2*math.tan(math.radians(q.roof_pitch_deg));assert math.isclose(p.wall_height_m+h,oldpeak,abs_tol=1e-12)
def expect_bad(**kw):
 v=dataclasses.replace(p,**kw)
 try:v.validate()
 except new.ParamError:return
 raise AssertionError(('Bad candidate accepted',kw))
for kw in [dict(kind='blockhouse'),dict(cupola=True),dict(chimneys=1),dict(barrel_rise_m=None),dict(barrel_rise_m=True),dict(barrel_rise_m=float('nan')),dict(barrel_rise_m=0),dict(barrel_rise_m=1e-320),dict(barrel_rise_m=p.width_m/2),dict(barrel_rise_m=1.6),dict(roof_type='gable')]:expect_bad(**kw)
class Probe:
 def __init__(self):self.tone_fn=None;self.faces=[]
 def add_poly(self,pts,conf,mat):
  tones=[None if self.tone_fn is None else self.tone_fn(q,None,mat)for q in pts];self.faces.append({'points':pts,'confidence':conf,'material':mat,'tone':tones});return[]
text=(C/'generators/archetypes/fort_structure.py').read_text();tree=ast.parse(text);fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='_barrel_vault_roof')
env={'math':math,'MeshBuilder':Probe,'FortStructureParams':new.FortStructureParams,'BARREL_EAVE_M':0.30,'ROOF_EDGE_M':0.07,'ROOF_EAVE_K':0.84,'ROOF_RIDGE_K':1.02,'ROOF_EDGE_K':0.85,'M_ROOF':1,'M_WALL':0}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<external-magazine-AST-probe>','exec'),env)
try:
 env['_barrel_vault_roof'](Probe(),dataclasses.replace(p,barrel_rise_m=1e-320),0,0,p.width_m,p.depth_m,p.wall_height_m,1.0,.5)
except ValueError:pass
else:raise AssertionError('Producer accepted overflowed derived radius')
b=Probe();peak=env['_barrel_vault_roof'](b,p,0,0,p.width_m,p.depth_m,p.wall_height_m,1.0,.5);assert b.tone_fn is None and math.isclose(peak,oldpeak,abs_tol=1e-12)
roof=[x for x in b.faces if x['material']==1];ends=[x for x in b.faces if x['material']==0];assert len(ends)==2
normal=lambda pts:tuple(sum((pts[i][(a+1)%3]-pts[(i+1)%len(pts)][(a+1)%3])*(pts[i][(a+2)%3]+pts[(i+1)%len(pts)][(a+2)%3])for i in range(len(pts)))for a in range(3))
assert normal(ends[0]['points'])[1]>0 and normal(ends[1]['points'])[1]<0
for e in ends:
 pts=e['points'];assert math.isclose(pts[0][2],p.wall_height_m,abs_tol=1e-12)and math.isclose(pts[-1][2],p.wall_height_m,abs_tol=1e-12);assert all(x['confidence']==1.0 for x in ends)
# Covering is closed without internal strip-thickness ribs; pair geometric edges.
def key(p):return tuple(round(x,10)for x in p)
edges=collections.Counter();oriented=collections.Counter()
for face in roof:
 pts=face['points'];assert sum(x*x for x in normal(pts))>1e-15
 for a,z in zip(pts,pts[1:]+pts[:1]):
  ka,kz=key(a),key(z);edge=tuple(sorted((ka,kz)));edges[edge]+=1;oriented[edge]+=1 if ka<kz else -1
assert set(edges.values())=={2},collections.Counter(edges.values())
assert not any(oriented.values()),'Closed covering must have opposite directed edge pairs'
assert math.isclose(max(z for f in roof for x,y,z in f['points']),oldpeak,abs_tol=1e-12)
# Continuous height treatment: identical shared top positions carry identical tones.
tops=roof[:(len(roof)-2)//4];tones={}
for f in tops:
 assert normal(f['points'])[2]>0
 for xyz,t in zip(f['points'],f['tone']):
  k=key(xyz)
  if k in tones:assert abs(tones[k]-t)<1e-12
  tones[k]=t
# All existing cupola routines, constants and fields remain byte-identical in source.
def functions(src):
 lines=src.splitlines(True);return {n.name:''.join(lines[n.lineno-1:n.end_lineno])for n in ast.parse(src).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
oldtext=(B/'generators/archetypes/fort_structure.py').read_text();of,nf=functions(oldtext),functions(text);unchanged=[]
for k in of:
 if k not in ['_building','_roof']:assert of[k]==nf[k],k;unchanged.append(k)
assert '_cupola'in unchanged
# Non-roof fields, phase/date/position/footprint/name/grade evidence are unchanged.
a=json.loads(json.dumps(baseline));z=json.loads(json.dumps(record));af=a['phases'][0]['form'];zf=z['phases'][0]['form']
for k in ['roof_type','roof_pitch_deg']:af.pop(k,None)
for k in ['roof_type','barrel_rise_m']:zf.pop(k,None)
z["research_note"]=a["research_note"]
assert a==z
result={'status':'EXTERNAL_AST_AND_PURE_MATH_ONLY_PASS_NOT_NATIVE_QUALIFIED','rise_m':h,'old_and_candidate_peak_m':peak,'radius_m':((p.width_m/2)**2+h*h)/(2*h),'side_eave_z_m':min(q[2]for f in tops for q in f['points']),'old_gable_side_eave_z_m':p.wall_height_m-.30*math.tan(math.radians(q.roof_pitch_deg)),'roof_faces':len(roof),'end_faces':len(ends),'all_covering_geometric_edges_used_twice':True,'all_closed_covering_edge_directions_cancel':True,'front_rear_end_winding_correct':True,'continuous_top_tone':True,'invalid_profiles_rejected':11,'existing_cupola_and_other_helpers_byte_exact':unchanged,'only_data_roof_fields_and_matching_research_qualification_changed':True,'claims_or_dispatch_or_Blender_or_GPU_or_sourcewrites':False}
(P/'STATIC-PROBE.json').write_text(json.dumps(result,indent=2)+'\n');(P/'STATIC-PROBE-FACES.json').write_text(json.dumps(b.faces));print(json.dumps(result,indent=2))
