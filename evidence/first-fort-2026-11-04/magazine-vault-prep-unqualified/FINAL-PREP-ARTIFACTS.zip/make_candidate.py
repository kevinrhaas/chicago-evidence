from pathlib import Path
import json,math,difflib,hashlib,ast
P=Path(__file__).parent;B=P/'cupola-base';C=P/'candidate';C.mkdir(exist_ok=True)
rel='generators/archetypes/fort_structure_params.py';s=(B/rel).read_text();s=s.replace('ROOF_TYPES = ("gable", "hip", "pyramid", "shed", "flat", "none")','ROOF_TYPES = ("gable", "hip", "pyramid", "shed", "flat", "none", "barrel_vault")\n# Existing roof projection, reused only by the explicit magazine vault.\nBARREL_EAVE_M = 0.30')
s=s.replace('    roof_pitch_deg: float = 34.0','    roof_pitch_deg: float = 34.0\n    # T-3041: rise ABOVE the unchanged wall top, not a uniform curved-roof pitch.\n    barrel_rise_m: float | None = field(default=None, kw_only=True)')
s=s.replace('"kind", "stories", "wall_height_m", "roof_type", "roof_pitch_deg",','"kind", "stories", "wall_height_m", "roof_type", "roof_pitch_deg", "barrel_rise_m",')
needle='        for k, v in self.confidence.items():'
extra='''        if self.roof_type == "barrel_vault":
            if (self.kind != "magazine" or self.stories != 1 or self.chimneys or
                    self.gallery or self.cupola or self.loopholes or self.lantern):
                raise ParamError("barrel_vault is a one-storey magazine without roof fittings")
            h = self.barrel_rise_m
            a = self.width_m / 2.0
            if (isinstance(h, bool) or not isinstance(h, (int, float)) or
                    not math.isfinite(h) or not 0.0 < h < a):
                raise ParamError("barrel_rise_m must be finite, positive and below half the width")
            radius = (a * a + h * h) / (2.0 * h)
            if not math.isfinite(radius) or radius <= a + BARREL_EAVE_M:
                raise ParamError("barrel rise leaves no real same-circle 0.30 m side eave")
        elif self.barrel_rise_m is not None:
            raise ParamError("barrel_rise_m requires roof_type barrel_vault")
'''
assert s.count(needle)==1;s=s.replace(needle,extra+needle)
s=s.replace('self.roof_type not in ("flat", "none")','self.roof_type not in ("flat", "none", "barrel_vault")')
s=s.replace('        roof_pitch_deg=float(val("roof_pitch_deg", 34.0)),','        roof_pitch_deg=float(val("roof_pitch_deg", 34.0)),\n        barrel_rise_m=val("barrel_rise_m", None),')
(C/rel).parent.mkdir(parents=True,exist_ok=True);(C/rel).write_text(s);ast.parse(s)
rel='generators/archetypes/fort_structure.py';s=(B/rel).read_text();s=s.replace('from archetypes.fort_structure_params import (','from archetypes.fort_structure_params import (')
# Preserve the live cupola imports and definitions verbatim; add only this new constant.
needle='from archetypes.fort_structure_params import ('
assert needle in s;s=s.replace(needle,needle+'\n    BARREL_EAVE_M,',1)
s=s.replace('    c_roof = p.worst_conf("roof_type", "roof_pitch_deg")','    c_roof = p.worst_conf("roof_type", "barrel_rise_m" if p.roof_type == "barrel_vault" else "roof_pitch_deg")')
needle='    if p.roof_type == "none":\n        return eave_z'
assert s.count(needle)==1;s=s.replace(needle,'    if p.roof_type == "barrel_vault":\n        return _barrel_vault_roof(b, p, x0, y0, x1, y1, eave_z, conf, c_wall)\n'+needle)
fn='''def _barrel_vault_roof(b: MeshBuilder, p: FortStructureParams,
                       x0, y0, x1, y1, eave_z: float, conf: float,
                       c_wall: float) -> float:
    """T-3041: a circular-segment magazine roof, its axis along local Y.

    The pictures/owner ruling supply a vault, NOT its radius. The explicit
    reconstructed rise preserves the old reconstructed gable's peak. Its varying
    tangent is never called a uniform pitch. Walls, door and footprint stay put.
    """
    a = (x1 - x0) / 2.0
    h = p.barrel_rise_m
    radius = (a * a + h * h) / (2.0 * h)
    o = BARREL_EAVE_M
    if not math.isfinite(radius) or radius <= a + o:
        raise ValueError("barrel side eave is outside the declared circle")
    xm = (x0 + x1) / 2.0
    crown = eave_z + h
    zc = crown - radius
    edge = math.asin((a + o) / radius)
    spring = math.asin(a / radius)
    # Exact crown and wall-seat samples; 32 arc facets are a mesh resolution,
    # not a historical count. No radicand clamp or guessed replacement radius.
    angles = sorted(set([-edge + 2.0 * edge * i / 32 for i in range(33)] +
                        [-spring, 0.0, spring]))
    profile = [(xm + radius * math.sin(t), zc + radius * math.cos(t)) for t in angles]
    lo = profile[0][1]
    prev = b.tone_fn
    # One continuous height treatment, not a new random paint for every strip.
    b.tone_fn = lambda q, _c, _m: (ROOF_EAVE_K +
        (ROOF_RIDGE_K - ROOF_EAVE_K) * (q[2] - lo) / (crown - lo))
    for (xa, za), (xb, zb) in zip(profile, profile[1:]):
        b.add_poly([(xa, y0 - o, za), (xb, y0 - o, zb),
                    (xb, y1 + o, zb), (xa, y1 + o, za)], conf, M_ROOF)
    # A closed covering: underside, front/rear fascia and only the TWO outer
    # side eaves. Per-strip perimeter thickness would put ribs inside the vault.
    b.tone_fn = lambda _q, _c, _m: ROOF_EAVE_K * ROOF_EDGE_K
    t = ROOF_EDGE_M
    for (xa, za), (xb, zb) in zip(profile, profile[1:]):
        b.add_poly([(xa, y0 - o, za - t), (xa, y1 + o, za - t),
                    (xb, y1 + o, zb - t), (xb, y0 - o, zb - t)], conf, M_ROOF)
        b.add_poly([(xa, y1 + o, za), (xb, y1 + o, zb),
                    (xb, y1 + o, zb - t), (xa, y1 + o, za - t)], conf, M_ROOF)
        b.add_poly([(xb, y0 - o, zb), (xa, y0 - o, za),
                    (xa, y0 - o, za - t), (xb, y0 - o, zb - t)], conf, M_ROOF)
    xa, za = profile[0]
    xb, zb = profile[-1]
    b.add_poly([(xa, y0 - o, za), (xa, y1 + o, za),
                (xa, y1 + o, za - t), (xa, y0 - o, za - t)], conf, M_ROOF)
    b.add_poly([(xb, y0 - o, zb), (xb, y0 - o, zb - t),
                (xb, y1 + o, zb - t), (xb, y1 + o, zb)], conf, M_ROOF)
    b.tone_fn = prev
    # Only the two brick end infills change above the unchanged rectangular
    # wall tops. Outward winding: front +Y, rear -Y. Geometry uncertainty follows
    # the reconstructed rise (larger _CONFIDENCE means more reconstructed).
    wall = [(xm + radius * math.sin(t), y1, zc + radius * math.cos(t))
            for t in angles if -spring <= t <= spring]
    wall[0] = (x0, y1, eave_z)
    wall[-1] = (x1, y1, eave_z)
    b.add_poly(wall, max(conf, c_wall), M_WALL)
    b.add_poly([(x, y0, z) for x, _y, z in reversed(wall)], max(conf, c_wall), M_WALL)
    return crown


'''
needle='def _gable_roof(';assert s.count(needle)==1;s=s.replace(needle,fn+needle);(C/rel).write_text(s);ast.parse(s)
rel='data/structures/first_fort_dearborn_magazine.json';raw=(B/rel).read_text();d=json.loads(raw);f=d['phases'][0]['form'];oldf=json.loads(json.dumps(f));poly=d['phases'][0]['footprint']['polygon'];w=max(x[0]for x in poly);depth=max(x[1]for x in poly);rise=min(w,depth)/2*math.tan(math.radians(f['roof_pitch_deg']['value']))
f['roof_type']={'value':'barrel_vault','confidence':'inferred','sources':['whistler_1808_fort_dearborn_draught','currey_1912_first_fort_birdseye'],'note':"Owner adoption (2026-11-03, T-3335/T-3041): Currey's 1912 retrospective bird's-eye labels the magazine (8) under a rounded vault, consistent with Whistler's 1808 arched front. Adopt that roof shape for the first-fort 1812 phase only. These sources give no vault radius, rise, thickness, colour or construction date. The contemporary surveyed seat, bearing and front width remain unchanged; neither the retrospective picture nor its diagnostic camera supplies a metric fit."}
# Retain key position while replacing an obsolete gable pitch with an honest dimension.
f2={}
for key,value in f.items():
 if key=='roof_pitch_deg':
  f2['barrel_rise_m']={'value':rise,'confidence':'reconstructed','note':"Not a measured vault rise. Preserve the former reconstructed gable peak: half of the shorter unchanged 3.05 m plan span times tan(34 degrees) = "+format(rise,'.12g')+" m above the unchanged 2.6 m wall. The old 34-degree gable parameter is no longer a visitor-facing pitch claim: a curved roof has varying tangent. A circular segment across the unchanged 4.51 m front, the existing 0.30 m projection and 0.07 m covering edge are working reconstructions, not dimensions read from Whistler or Currey. Covering, material and colour remain the existing reconstruction; the black-and-white illustration attests none of them."}
 else:f2[key]=value
d['research_note']="THE ONE BUILDING OF THE FIRST FORT THAT DID NOT BURN — Quaife says the brick magazine alone 'defied the fire'. Its front and place are the commandant's draught. The vault shape is inferred from the arched front and Currey's later reconstruction under owner adoption (T-3335/T-3041); the depth, height, circular-segment profile, rise and covering details remain reconstructed. Neither picture supplies a vault completion date."
d['phases'][0]['form']=f2;(C/rel).parent.mkdir(parents=True,exist_ok=True);(C/rel).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
patch=[];files=[]
for rel in ['generators/archetypes/fort_structure.py','generators/archetypes/fort_structure_params.py','data/structures/first_fort_dearborn_magazine.json']:
 before=(B/rel).read_text();after=(C/rel).read_text();patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel));files.append({'path':rel,'base_sha256':hashlib.sha256(before.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(after.encode()).hexdigest()})
(P/'UNQUALIFIED-CANDIDATE.patch').write_text(''.join(patch));(P/'CANDIDATE-MANIFEST.json').write_text(json.dumps({'status':'UNQUALIFIED_EXTERNAL_PREP_ONLY','cupola_base':'52d6f631df788258a50a6e3271cca9e97ba960ac','data_base':'492f285ccb43431323e1911e6134a0ac04148ce5; magazine exact52d too','rise_m':rise,'old_peak_m':2.6+rise,'radius_m':((w/2)**2+rise**2)/(2*rise),'files':files,'no_app_source_changes_claim_dispatch_or_native_execution':True},indent=2)+'\n');print('External patch',len((P/'UNQUALIFIED-CANDIDATE.patch').read_bytes()),'rise',rise,'peak',2.6+rise)
