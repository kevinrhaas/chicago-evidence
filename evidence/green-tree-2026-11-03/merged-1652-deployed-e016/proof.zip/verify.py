"""Verify public dev delivery after the protected PR merge; no runtime claim."""
import hashlib
import json
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
HEAD = "ebf7befa1afba05947578a5ee08e0cbc8655d98a"
BASE = "https://chicago.polecat.live/4d/dev/"
EXPECTED = {
    "green_tree_tavern__frame_1833.glb": "e9688ba27ce9d46a1baf0c00aee020e49c005a362b44c5349f197787824012cc",
    "wolf_point_tavern__log_frame_1828.glb": "fdc5ef22a440636e35e4cec15818661f4351f0f4d0c9e506ef36b00422a45210",
}


def api(path):
    return json.loads(subprocess.check_output(["gh", "api", "repos/kevinrhaas/chicago/" + path], text=True))


def get(path):
    url = BASE + path + "?pr1652-verify=" + str(time.time_ns())
    with urlopen(Request(url, headers={"Cache-Control": "no-cache"}), timeout=45) as response:
        assert response.status == 200
        data = response.read(2_000_001)
        assert len(data) <= 2_000_000
    return data


pr = api("pulls/1652")
assert pr["head"]["sha"] == HEAD, "PR head changed; review verification scope"
if not pr["merged"]:
    print("NOT_MERGED_YET")
    raise SystemExit(20)
merge = pr["merge_commit_sha"]
before_build = get("build.json")
build = json.loads(before_build)
assert build["tier"] == "dev" and build["ref"] == "refs/heads/dev"
comparison = api(f"compare/{merge}...{build['sha']}")
if comparison["behind_by"] or comparison["status"] not in ("ahead", "identical"):
    print("MERGED_NOT_DEPLOYED_YET", merge, build["sha"])
    raise SystemExit(21)
paths = ["data/pictures/1835.json"] + ["data/gltf/" + name for name in EXPECTED]
with ThreadPoolExecutor(max_workers=3) as pool:
    payloads = dict(zip(paths, pool.map(get, paths)))
assert before_build == get("build.json"), "Build changed during delivery checks; repeat"
for name, expected in EXPECTED.items():
    assert hashlib.sha256(payloads["data/gltf/" + name]).hexdigest() == expected, name
pictures = json.loads(payloads["data/pictures/1835.json"])
wolf = pictures["by_structure"]["wolf_point_tavern"]
old_wolf = json.loads((ROOT / "before/BEFORE-WOLF.json").read_bytes())
by_id = {row["id"]: row for row in wolf}
assert len(wolf) == len(by_id) == 7
assert sum(bool(row.get("held")) for row in wolf) == 1
assert all(by_id[row["id"]] == row for row in old_wolf), "Existing source card changed"
poster = by_id["blanchard_davis_c1893_wolfs_point_poster"]
assert poster["url"] == "https://collections.newberry.org/asset-management/2KXJ8ZS8068IZ"
assert not poster.get("held")
assert poster["rights"] == "public domain"
assert "Davis" in poster["creator"] and "Blanchard" in poster["creator"]
out = ROOT / ("after-" + build["sha"])
out.mkdir(exist_ok=True)
(out / "build.json").write_bytes(before_build)
for path, data in payloads.items():
    (out / Path(path).name).write_bytes(data)
result = {
    "status": "DEPLOYED_DEV_DELIVERY_VERIFIED",
    "at": datetime.now(timezone.utc).isoformat(),
    "pr": 1652,
    "reviewed_head": HEAD,
    "merge_commit": merge,
    "deployed_build": build,
    "comparison_status": comparison["status"],
    "deployed_descends_from_merge": True,
    "files": {path: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()} for path, data in payloads.items()},
    "wolf_picture_entries": 7,
    "existing_six_entries_exact": True,
    "new_poster": poster,
    "scope": "Public dev build ancestry, shipped Green Tree/Wolf WEB bytes and credited picture entries. Static delivery checks do not extend reviewed-head runtime proofs to later core changes.",
}
(out / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
(ROOT / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": result["status"], "merge": merge, "build": build["sha"], "output": str(out)}))
