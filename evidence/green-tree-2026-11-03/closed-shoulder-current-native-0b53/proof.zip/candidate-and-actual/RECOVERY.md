# T-2376: one existing boolean supplies the pictured closed shoulder

Prepared on current public e32 source; no source/Git/ticket/canonical model/grade/camera or world state was changed. No new producer, default-family bake, renderer/browser/GPU job or matching verdict. Original T-2376 remains OPEN/DIFFERS.

## Concrete data-only candidate

`one-boolean-source.patch` changes ONLY `enclosed_left_annex.value.shoulder_enclosed: false -> true`. The full candidate retains every byte except that boolean; every numeric form control, placement, footprint, phase date, confidence and source list remains unchanged. It is a PRIVATE isolated comparison candidate, not a proposal to blindly replace the canonical open-bay reading.

The existing native producer `_enclosed_left_annex` skips an unoccupied shoulder; when the boolean is true it already draws its clapboard walls, lower sash, shed roof and small front-gable/dormer with upper light. `frame_tavern_params.left_annex_parts` supplies the same bounded part frames to occupied-solid readers. Existing dimensions and hidden faces stay reconstructed. No new measurement, survey coordinate, alteration date or hidden fabric is invented. The existing far gabled range already supplies one lower sash, a door and gable light; this packet changes no station/count/pitch before a genuine comparison demonstrates another material defect.

## Genuine native geometry can be reused now

The full CURRENT native normalized document for this one-boolean candidate equals the retained actual `andreas-reading` native production version exactly, recipe `80d47de6a30209568a37752835292968162def80d4eff8f2bb0a6eecaf867722`. Actual MASTER `0b53a6fe30e23b10b330ddb60d4bb362cbce2e798690104e90f4f304cd9d18b8`,269880bytes, is copied with its original actual native result/reaper/command and native registry row. No new bake, WEB encode or registry registration is claimed. No retained WEB pair was found in the finite inspected proposal; it is not invented.

The current helper body was fetched from public e32, and all geometry/parameter/common/emit/pin dependencies were verified against current immutable N. The older N mesh_inputs dispatch differs only in unrelated family support; this proof uses the actual current helper body. Default-family25qualification need NOT rerun for this data-only choice because neither producer nor parameter code changes. New registrations/WEB/current source/app checks still remain necessary before shipping anything.

## Why this next comparison is useful

The canonical f447MASTER/camera/photo are already bound to the existing canonical side-by-side; rerendering that unchanged tuple would repeat existing work. In contrast the retained old closed-version template binds DIFFERENT f1d48geometry and f615camera, so it is not current evidence for this 0b53MASTER at the existing9439camera. A new fixed-pose native comparison of the 0b53closed form is a concrete next observation, without rebaking, refitting the camera or guessing new dimensions.

`PLAN.json` contains the ready command using the UNCHANGED native photo_match owner and all20 tools/vendor from immutable N, each verified byte-exact at public e32. The private camera is a byte-identical copy of the original Andreas camera under a private filename; the explicit `--glb` selects the actual closed MASTER. The source image was directly viewed unchanged. The existing open canonical comparison remains separate and unchanged. The native raw result will start UNREVIEWED; no verdict is prefilled. This is only prepared, with NO render grant and NO execution.

## Do not flip the default blindly

The current independent yard layer intentionally draws the open shed's roof/posts and covered wagon in this shoulder. The existing building producer expressly never suppresses those props. Closing the default without handling the yard relation would put competing geometry/props in one volume. An isolated diagnostic avoids that overlap; it does not solve a world-state interpretation. The next actual application choice must keep the Trowbridge-open/Andreas-closed disagreement explicit and establish either a properly scoped comparison version/context or a justified canonical choice with native yard/occupied-solid/doorway review. No dated conversion between the retrospective witnesses is established.

This packet changes no producer and requires no new opt-in implementation. It is a bounded source candidate plus genuine reusable geometry and a ready native fixed-camera command; not complete ticket acceptance or permission to suppress conflicting sources, props or checks.
