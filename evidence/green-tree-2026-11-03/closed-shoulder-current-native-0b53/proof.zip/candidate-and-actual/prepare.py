from pathlib import Path
from urllib.request import Request,urlopen
import base64,concurrent.futures,copy,difflib,hashlib,importlib.util,json,shutil,sys
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;N=Path('/tmp/cobweb-active-20261103/chicago/4d');OLD=Path('/workspace/GT-Saug-current-dev-20261102');HEAD='e32abc49306697818ebdf22958ae80afaf5d44d2';sha=lambda b:hashlib.sha256(b).hexdigest()
rels=['generators/mesh_inputs.py','generators/code_inputs.py','generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','generators/emit.py','generators/common/mesh.py','generators/common/openings.py','generators/common/materials.py','generators/common/logwork.py','generators/blender.pin']
def fetch(rel):
 with urlopen(Request('https://api.github.com/repos/kevinrhaas/chicago/contents/chicago/4d/'+rel+'?ref='+HEAD,headers={'User-Agent':'Chicago-GT-data-only-shoulder-preparation'}),timeout=45)as r:d=json.load(r)
 b=base64.b64decode(d['content']);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==d['sha'];p=O/'current-native-code'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return rel,{'public_blob':d['sha'],'sha256':sha(b),'N_exact':(N/rel).read_bytes()==b}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:pins=dict(ex.map(fetch,rels))
# Only this module's dispatcher gained unrelated archetypes since N; use its actual current body.
for rel,row in pins.items():
 if rel!='generators/mesh_inputs.py':assert row['N_exact'],rel
base=json.loads((N/'data/structures/green_tree_tavern.json').read_bytes());candidate=copy.deepcopy(base);candidate['phases'][0]['form']['enclosed_left_annex']['value']['shoulder_enclosed']=True
# This is a PRIVATE isolated-form proposal, not a default-world adoption with duplicate yard geometry.
put=lambda p,b:(p.parent.mkdir(parents=True,exist_ok=True),p.write_bytes(b))
raw=(N/'data/structures/green_tree_tavern.json').read_bytes();assert raw.count(b'"shoulder_enclosed": false')==1;out=raw.replace(b'"shoulder_enclosed": false',b'"shoulder_enclosed": true');assert json.loads(out)==candidate;put(O/'baseline/green_tree_tavern.json',raw);put(O/'candidate/green_tree_tavern.andreas-closed.json',out)
(O/'one-boolean-source.patch').write_text(''.join(difflib.unified_diff(raw.decode().splitlines(True),out.decode().splitlines(True),fromfile='a/data/structures/green_tree_tavern.json',tofile='b/data/structures/green_tree_tavern.json')))
# Native parameter/recipe resolution only, no producer or Blender invocation.
sys.path[:0]=[str(N/'generators'),str(N/'tools')];p=O/'current-native-code/generators/mesh_inputs.py';sp=importlib.util.spec_from_file_location('gt_current_mesh_inputs',p);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m);m.ROOT=N
base_doc=m.structure_inputs_doc(base,base['phases'][0]);candidate_doc=m.structure_inputs_doc(candidate,candidate['phases'][0]);base_sig=m.structure_inputs_sha(base,base['phases'][0]);candidate_sig=m.structure_inputs_sha(candidate,candidate['phases'][0]);manifest=json.loads((N/'assets/manifest.json').read_bytes());assert base_sig==manifest['assets']['green_tree_tavern__frame_1833.glb']['inputs_sha256']
oldversion=json.loads((OLD/'postimages/chicago/4d/data/structures/versions/green_tree_tavern/andreas-reading.json').read_bytes());old_doc=m.structure_inputs_doc(oldversion,oldversion['phases'][0]);assert candidate_doc==old_doc
rows=json.loads((OLD/'REGISTRY-ROWS.json').read_bytes());reg=next(x['post']for r in rows['registries']for x in r['rows']if x['key']=='versions/green_tree_tavern/andreas-reading/green_tree_tavern__frame_1833.glb');assert candidate_sig==reg['inputs_sha256'],(candidate_sig,reg['inputs_sha256'])
asset=OLD/'postimages/chicago/4d/assets/gltf/versions/green_tree_tavern/andreas-reading/green_tree_tavern__frame_1833.glb';b=asset.read_bytes();assert sha(b)=='0b53a6fe30e23b10b330ddb60d4bb362cbce2e798690104e90f4f304cd9d18b8';put(O/'retained-native/andreas-reading.glb',b)
for n in ['RESULT.json','REAPER.json','COMMAND.json']:put(O/'retained-native'/n,(OLD/'evidence/native'/n).read_bytes())
# One semantic boolean only; byte serialization itself is not the authority for change count.
left=copy.deepcopy(base_doc);right=copy.deepcopy(candidate_doc);v=right['params']['fields']['enclosed_left_annex'];v['shoulder_enclosed']=False
# Inferred occupancy/entrances may change by the shared native dataclass: state every actual document path.
def differences(a,b,path=''):
 if isinstance(a,dict)and isinstance(b,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):out+=differences(a.get(k),b.get(k),path+'/'+k)
  return out
 if isinstance(a,list)and isinstance(b,list)and len(a)==len(b):
  out=[]
  for i,(x,y)in enumerate(zip(a,b)):out+=differences(x,y,path+'/'+str(i))
  return out
 return []if a==b else[{'path':path,'before':a,'after':b}]
source_diff=differences(base,candidate);assert len(source_diff)==1 and source_diff[0]['path'].endswith('/shoulder_enclosed')
plan={'status':'PRIVATE_DATA_ONLY_CLOSED_READING_PREPARED_NOT_APPLIED_OR_RENDERED','public_tip':HEAD,'source_diff':source_diff,'all_numeric_form_inputs_unchanged':True,'position_footprint_dates_confidences_sources_unchanged':True,'producer_parameter_code_unchanged':True,'base_recipe':base_sig,'closed_recipe':candidate_sig,'full_current_closed_normalized_doc_equals_retained_actual_native_version':True,'retained_actual_MASTER':sha(b),'retained_actual_MASTER_bytes':len(b),'retained_WEB_available':False,'native25_defaults_requalification_required':False,'native25_reason':'No producer/parameter code changes; only selectedGT record data changes. Prior genuine native version is reusable under exact full document equality, not rehashed oldcanonicalgeometry.','no_current_model_rendered':True,'canonical_default_must_not_be_flipped_blindly':'Independent native yard shed/posts and covered wagon occupy this shoulder. Existing builder intentionally never suppresses them. Current-source world/grade/camera remain untouched.','far_range_openings':'Existing controls already emit one lower sash, one door and one gable light. No count/metric alteration prepared from this one image; compare the retained closed form before any new station choice.','current_native_code_bindings':pins,'native_document_differences':differences(base_doc,candidate_doc)}
for name,value in [('PLAN.json',plan),('CLOSED-CURRENT-MESH-INPUT-DOCUMENT.json',candidate_doc),('BASE-CURRENT-MESH-INPUT-DOCUMENT.json',base_doc),('RETAINED-NATIVE-VERSION-REGISTRATION.json',reg)]:put(O/name,(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
print(json.dumps({k:v for k,v in plan.items()if k not in ['current_native_code_bindings','native_document_differences']},indent=2))
