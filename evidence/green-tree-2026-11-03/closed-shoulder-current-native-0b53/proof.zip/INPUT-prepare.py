from pathlib import Path
from urllib.request import Request,urlopen
import hashlib,json,shutil,struct,os
O=Path(__file__).resolve().parent;N=Path('/tmp/cobweb-active-20261103');A=N/'chicago/4d';F=O/'fixture/chicago/4d';tip='e32abc49306697818ebdf22958ae80afaf5d44d2';sha=lambda b:hashlib.sha256(b).hexdigest();gsha=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
assert not F.exists();assert os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize>1_800_000_000+30*1024*1024
old=json.loads(Path('/workspace/wolf-source15-frozen-20261103/NATIVE20-TIP-COMPATIBILITY.json').read_bytes());native=[r['path']for r in old['rows']if r['path'].endswith('.mjs')or r['path'].endswith('.js')]+list(old['vendor_members']);assert len(native)==20
selected=['chicago/4d/assets/gltf/green_tree_tavern__frame_1833.glb','chicago/4d/assets/web/green_tree_tavern__frame_1833.glb','chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json','chicago/4d/data/reference_views/green_tree_tavern/andreas_1838.json','chicago/4d/data/reference_views/green_tree_tavern/andreas_1838.match.json','chicago/4d/data/structures/green_tree_tavern.json','chicago/4d/data/sidecars/1835/green_tree_tavern.json','chicago/4d/data/sources/andreas_1884_green_tree_hotel_plate.json','chicago/reference/images/chicago/chicago_green_tree_inn_1838.jpg','chicago/4d/docs/RESEARCH/photo-match/green_tree_tavern/andreas_1838-side-by-side.jpg']
with urlopen(Request('https://api.github.com/repos/kevinrhaas/chicago/git/trees/'+tip+'?recursive=1',headers={'User-Agent':'Chicago-GT-bounded-native-comparison-prep'}),timeout=60)as r:tree=json.load(r)
assert not tree['truncated'];mapping={r['path']:r for r in tree['tree']if r['path']in native+selected};assert len(mapping)==len(native)+len(selected)
rows=[]
for rel in native+selected:
 src=N/rel;b=src.read_bytes()
 if rel in ['chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json']:
  import base64
  with urlopen(Request('https://api.github.com/repos/kevinrhaas/chicago/git/blobs/'+mapping[rel]['sha'],headers={'User-Agent':'Chicago-GT-current-registry-readback'}),timeout=45)as response:blob=json.load(response)
  b=base64.b64decode(blob['content']);src='https://api.github.com/repos/kevinrhaas/chicago/git/blobs/'+mapping[rel]['sha']
 assert mapping[rel]['type']=='blob'and mapping[rel]['sha']==gsha(b),(rel,mapping[rel]['sha'],gsha(b))
 if rel.endswith('/andreas_1838-side-by-side.jpg'):dest=O/'baseline/andreas_1838-side-by-side.jpg'
 else:dest=O/'fixture'/rel
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);rows.append({'source':str(src),'relative_to_repo':rel,'destination':dest.relative_to(O).as_posix(),'bytes':len(b),'sha256':sha(b),'public_tip_git_blob':mapping[rel]['sha']})
master=F/'assets/gltf/green_tree_tavern__frame_1833.glb';web=F/'assets/web/green_tree_tavern__frame_1833.glb';assert sha(master.read_bytes())=='f447aa45b93e507ea8606f6c74703b5948d9ee736a84d3a01d47d8a587db81c3';assert sha(web.read_bytes())=='e9688ba27ce9d46a1baf0c00aee020e49c005a362b44c5349f197787824012cc'
b=master.read_bytes();length,kind=struct.unpack_from('<II',b,12);assert kind==0x4e4f534a;glb=json.loads(b[20:20+length]);external=[q.get('uri')for q in glb.get('images',[])+glb.get('buffers',[])if q.get('uri')and not q['uri'].startswith('data:')];assert not external,external
cam=F/'data/reference_views/green_tree_tavern/andreas_1838.json';c=json.loads(cam.read_bytes());photo=(cam.parent/c['photo']).resolve();assert photo.is_file();oldmatch=json.loads(cam.with_suffix('.match.json').read_bytes());assert oldmatch['glb_sha256']==sha(master.read_bytes())and oldmatch['camera_sha256']==sha(cam.read_bytes())and oldmatch['photo_sha256']==sha(photo.read_bytes())
from PIL import Image
assert list(Image.open(photo).size)==c['image_px']
plan={'status':'READY_UNRUN_NATIVE_SINGLE_FIXED_CAMERA_COMPARISON','public_tip':tip,'copied_source_base':'07b8ece7c807352ee56ba59d76f76fa54b3691c8','all31_copied_blobs_exact_public_tip':True,'all20_native_tools_vendor_unchanged':True,'fixture_root':str(F),'native_command':['node','tools/photo_match.mjs','data/reference_views/green_tree_tavern/andreas_1838.json','--glb','assets/gltf/green_tree_tavern__frame_1833.glb','--out',str(O/'actual/frame')],'original_camera_and_photo_byte_exact':True,'master':sha(master.read_bytes()),'web':sha(web.read_bytes()),'camera_sha256':sha(cam.read_bytes()),'photo_sha256':sha(photo.read_bytes()),'glb_external_dependencies':external,'existing_match_verdict':oldmatch['verdict'],'existing_match_current_glb_camera_photo_binding_exact':True,'existing_open_differences':[r for r in oldmatch['differences']if r['status']=='open'],'source_controls_or_verdicts_changed':False,'input_files':rows,'all_existing_sources_unchanged':all(sha(Path(r['source']).read_bytes())==r['sha256']for r in rows if not r['source'].startswith('https://')),'copied_regular_bytes':sum(r['bytes']for r in rows),'no_browser_or_render_yet':True};assert plan['copied_regular_bytes']<20*1024*1024;(O/'INPUT-PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({k:v for k,v in plan.items()if k not in ['input_files','existing_open_differences']},indent=2))
