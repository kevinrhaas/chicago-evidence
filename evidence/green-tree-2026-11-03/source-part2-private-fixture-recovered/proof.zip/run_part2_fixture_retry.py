"""Run one foreground native source-gate part, preserving exact authored inputs."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('part', type=int, choices=range(1, 5))
args = parser.parse_args()
root = Path('/tmp/cobweb-active-20261103')
app = root/'chicago/4d'
out = Path(__file__).parent
part = args.part
assert part == 2
receipt = out/f'PART{part}-FIXTURE-LOCAL-RETRY-REAPER.json'
log = out/f'part{part}-fixture-local-retry.log'
result_path = out/f'PART{part}-FIXTURE-LOCAL-RETRY-RESULT.json'
frozen = json.loads(Path('/tmp/gt-closed-source-073-20261103/EXACT-STAGING.json').read_bytes())
env = os.environ.copy()
env['PATH'] = str(out/'fixture-local-git-bin')+os.pathsep+env['PATH']
adapter = out/'fixture-local-git-bin/git'
adapter_sha256 = hashlib.sha256(adapter.read_bytes()).hexdigest()
for key in ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES']:
    env.pop(key, None)
env.update(CHECK_JOBS='4', C4D_GATE_REQUIRE_READERS='1', GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')

def git(*arguments):
    return subprocess.check_output(['git', '-C', str(root), *arguments], env=env)

def guard():
    assert hashlib.sha256(adapter.read_bytes()).hexdigest() == adapter_sha256
    assert git('rev-parse', 'HEAD').decode().strip() == frozen['base']
    assert not git('diff', '--name-only'), 'Unexpected unstaged source change'
    for row in frozen['rows']:
        assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest() == row['sha256'], row['path']
        line = git('ls-files', '--stage', '--', row['path']).decode()
        assert line.startswith(row['mode']+' '+row['oid']+' 0\t'), row['path']
    free = {path: shutil.disk_usage(path).free for path in ['/workspace', '/tmp']}
    assert free['/workspace'] >= 536870912 and free['/tmp'] >= 1800000000, free
    return free

assert not receipt.exists() and not log.exists() and not result_path.exists()
assert not Path('/proc/295201').exists() or Path('/proc/295201/stat').read_text().split(') ', 1)[1].startswith('Z '), 'Original native source run is still active'
before = guard()
started = time.monotonic()
command = ['setsid', '--fork', '--wait', 'python', '/workspace/shared/run-with-reaping.py', str(receipt), '--', 'timeout', '--signal=TERM', '--kill-after=15s', '600s', 'taskset', '-c', '0,1,3,4', './tools/check.sh', '--part', f'{part}/4']
# setsid --wait remains a single foreground command. Its bounded subreaper keeps
# writing a truthful receipt if the cloud connection kills the outer controller.
with log.open('xb') as stream:
    native = subprocess.run(command, cwd=app, env=env, stdout=stream, stderr=subprocess.STDOUT)
closed = json.loads(receipt.read_bytes())
text = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', log.read_text(errors='replace'))
passed = native.returncode == closed['command_exit'] == 0 and closed['all_children_reaped'] and not closed['leftover_cleanup'] and closed['interrupted_signal'] is None
passed = passed and bool(re.search(r'CHECK PASS\s*[—-]\s*part\s+'+str(part)+r'/4\b', text))
try:
    after = guard()
    exact = True
    error = None
except BaseException as problem:
    after = {path: shutil.disk_usage(path).free for path in ['/workspace', '/tmp']}
    exact = False
    error = repr(problem)
result = {'part': part, 'status': 'NATIVE_SOURCE_PART_PASS' if passed and exact else 'NOT_QUALIFIED', 'seconds': time.monotonic()-started, 'native_exit': native.returncode, 'base': frozen['base'], 'all19_authored_index_and_worktree_postimages_exact': exact, 'reaper': closed, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(), 'last_lines': text.splitlines()[-8:], 'before_free': before, 'after_free': after, 'error': error, 'fixture_adapter_sha256': adapter_sha256, 'fixture_scope': 'Only T2331 private /tmp/repo-file-*/leg with identical same-fixture file://origin and known two tiny fixture payloads; GIT_ALLOW_PROTOCOL=file; all real Git calls retain NoLazy1'}
result_path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'part': part, 'status': result['status'], 'seconds': result['seconds'], 'result': str(result_path)}), flush=True)
raise SystemExit(0 if result['status'] == 'NATIVE_SOURCE_PART_PASS' else 1)
