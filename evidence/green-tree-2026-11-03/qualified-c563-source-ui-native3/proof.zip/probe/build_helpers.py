from pathlib import Path
import json,ast,hashlib
P=Path(__file__).parent;REF=Path('/workspace/combined-wolf-saug-probe-final-20261103');old=(REF/'run.py').read_text();baseplan=json.loads(Path('/workspace/combined-wolf-saug-plan-final-20261103.json').read_text());protected={k:v['sha256']for k,v in baseplan['input_bindings'].items()if '/assets/'in k and any(s in k for s in ['wolf_point_tavern','sauganash_hotel','philo_carpenter_log_shop'])};(P/'PROTECTED-0E-MODELS.json').write_text(json.dumps(protected,indent=2)+'\n')
start=old.index('EXPECTED_CAMERA_SOURCE_IDS=');end=old.index('\nsha=lambda',start);old=old[:start]+"TARGET='green_tree_tavern'\nEXPECTED_GT_MASTER='f447aa45b93e507ea8606f6c74703b5948d9ee736a84d3a01d47d8a587db81c3'\nPROTECTED_MODELS=json.loads((P/'PROTECTED-0E-MODELS.json').read_bytes())\n"+old[end:]
start=old.index('def inputs():');end=old.index('\nap=argparse.',start)
inspect='''def inspect_inputs(reference_name=None):
    # This function is called ONLY by a later explicit frozen-source plan/run.
    files=set((A/'renderers/web/js').rglob('*.js'))|set((S/'walk/js').rglob('*.js'))
    views=A/'data/reference_views'/TARGET
    cameras=sorted(p for p in views.glob('*.json')if not p.name.endswith('.match.json'))
    assert cameras,'No native Green Tree diagnostic cameras'
    choices=[p for p in cameras if p.name==reference_name]if reference_name else[p for p in cameras if 'andreas'in p.stem.lower()]
    assert len(choices)==1,('Choose one existing diagnostic direction with --camera', [p.name for p in cameras])
    chosen=choices[0];reference=json.loads(chosen.read_bytes());assert len(reference['eye'])==3
    camera_bindings=[]
    for camera in cameras:
        match=camera.with_suffix('.match.json');c=json.loads(camera.read_bytes());m=json.loads(match.read_bytes());photo=(camera.parent/c['photo']).resolve();model=A/m['glb'];sideby=A/m['side_by_side']
        assert pf(camera)==m['camera_sha256']and pf(photo)==m['photo_sha256']and pf(model)==m['glb_sha256']
        # A genuine diagnostic 'differs' result is preserved; no match verdict is invented.
        assert m.get('verdict')in ('matches','differs')
        files|={camera,match,photo,model,sideby,A/'data/sources'/f"{c['source_id']}.json"}
        camera_bindings.append(dict(camera=camera.name,source_id=c['source_id'],verdict=m['verdict'],group_sha256=m.get('group_sha256')))
    pictures=A/'data/pictures/1835.json';published_pictures=S/'data/pictures/1835.json';assert pictures.read_bytes()==published_pictures.read_bytes()
    rows=json.loads(published_pictures.read_bytes())['by_structure'][TARGET];assert rows and len({r['id']for r in rows})==len(rows)
    files|={pictures,published_pictures,S/'walk/index.html',A/'tools/compile_pictures.py',A.parent/'prairie_1904_v1/data/images.json',A/'assets/manifest.json',A/'assets/manifest.versions.json'}
    assert(A/'renderers/web/js/main.js').read_bytes()==(S/'walk/js/main.js').read_bytes()
    contract=json.loads((P/'household-contract-REAPER.json').read_bytes());assert contract['command_exit']==0 and contract['all_children_reaped']and not contract['leftover_cleanup']
    assert'record(s) ship slim, and their households ship whole beside them'in(P/'household-contract.log').read_text()
    files|={P/'household-contract.log',P/'household-contract-REAPER.json',A/'tools/defer_household_notes.mjs',P/'PROTECTED-0E-MODELS.json'}
    for sid in [TARGET,'sauganash_hotel','wolf_point_tavern','philo_carpenter_log_shop']:
        source=A/f'data/sidecars/1835/{sid}.json';published=S/f'data/sidecars/1835/{sid}.json';record=json.loads(source.read_bytes());shipped=json.loads(published.read_bytes());files|={source,published,A/f'data/structures/{sid}.json'}
        if record.get('residents'):
            household=S/f'data/sidecars/1835/households/{sid}.json';doc=json.loads(household.read_bytes());assert doc=={'id':record['id'],'residents':record['residents']};assert dict(shipped,residents=doc['residents'])==record;files.add(household)
        else:assert shipped==record
        asset=Path(record['asset']);assert not asset.is_absolute()and'..'not in asset.parts
        files|={A/'assets'/asset,A/'assets/web'/asset.name,S/'data'/asset};assert(A/'assets/web'/asset.name).read_bytes()==(S/'data'/asset).read_bytes()
    for name,expected in PROTECTED_MODELS.items():assert pf(name)==expected,name;files.add(Path(name))
    master=A/'assets/gltf/green_tree_tavern__frame_1833.glb';assert pf(master)==EXPECTED_GT_MASTER
    sc=json.loads((A/'data/sidecars/1835/green_tree_tavern.json').read_bytes());parts=sc['footprint']['additional_polygons'];assert [x['id']for x in parts]==['connector','boarding_range']
    web=A/'assets/web'/Path(sc['asset']).name
    for rel in ['data/enclosures/town_entrance_aprons.json','data/yard/town_trade_goods.json']:
        files|={A/rel,S/rel};assert(A/rel).read_bytes()==(S/rel).read_bytes()
    entrances=json.loads((A/'data/enclosures/town_entrance_aprons.json').read_bytes())['entrances'];entrance=next(x for x in entrances if x['id']=='green_tree_tavern__door_1')
    bindings={str(f):dict(sha256=pf(f),bytes=f.stat().st_size,mode=stat.S_IMODE(f.stat().st_mode))for f in sorted(files)}
    return dict(input_bindings=bindings,gt_reference_camera=reference,gt_reference_camera_name=chosen.name,gt_reference_camera_scope='Existing diagnostic eye supplies an oblique direction only; actual pose is recomputed to fit current compound bounds, never historical calibration.',gt_entrance=entrance,gt_all_entrances=[x for x in entrances if x['id'].startswith(TARGET+'__')],gt_occupied_parts=parts,gt_picture_rows=rows,expected_picture_ids=[r['id']for r in rows],expected_picture_count=len(rows),expected_held_count=sum(bool(r.get('held'))for r in rows),gt_MASTER_sha256=pf(master),gt_WEB_sha256=pf(web),camera_bindings=camera_bindings)
def inputs(reference_name):return inspect_inputs(reference_name)['input_bindings']
'''
old=old[:start]+inspect+old[end:]
old=old.replace("ap.add_argument('--prepare',type=Path);", "ap.add_argument('--prepare',type=Path);ap.add_argument('--camera');ap.add_argument('--frozen-head');")
start=old.index('    bindings=inputs()');end=old.index("    args.prepare.write_text",start)
old=old[:start]+'''    assert args.frozen_head and git('rev-parse','HEAD').decode().strip()==args.frozen_head,'Explicit exact frozen HEAD is required for draft preparation'
    assert not git('status','--porcelain','--untracked-files=normal'),'Frozen source must be clean'
    current=inspect_inputs(args.camera);bindings=current.pop('input_bindings')
    plan=dict(current,root_approved=False,source_check_parts_and_publish_closed=False,source_root=str(R),site_parent=str(R/'site'),output='/workspace/green-tree-both-actual-20261103',TMP='/tmp/greentreeactual1103',expected_head=args.frozen_head,input_bindings=bindings,source_scope_sha256=sha(canonical(bindings)),metadata=metadata(),helpers={'run.py':pf(P/'run.py'),'probe.mjs':pf(P/'probe.mjs')},reaper_sha256=pf('/workspace/shared/run-with-reaping.py'),scope='Partial T-2376 actual published credited Images card, curated compound exterior and native arrival under the default visitor geometry-release lifecycle. Open bay/gaps are visual context only; no traversal, historical camera calibration, obstruction-free/all-features view or full-ticket signoff claim.')
'''+old[end:]
old=old.replace('inputs()==plan[\'input_bindings\']',"inputs(plan['gt_reference_camera_name'])==plan['input_bindings']")
old=old.replace('WOLF_PROBE','GT_PROBE').replace('ACTUAL_PUBLISHED_COMBINED_WOLF_SAUG_PASS','ACTUAL_PUBLISHED_GREEN_TREE_PASS').replace('FOCUSED_PUBLISHED_COMBINED_WOLF_SAUG_BOTH_PASS','FOCUSED_PUBLISHED_GREEN_TREE_BOTH_PASS').replace('FOCUSED_PUBLISHED_COMBINED_WOLF_SAUG_NOT_QUALIFIED','FOCUSED_PUBLISHED_GREEN_TREE_NOT_QUALIFIED')
old=old.replace('Combined Wolf Images/Sauganash current exterior/arrival probe.','Partial Green Tree published Images/compound exterior/arrival probe.')
ast.parse(old);(P/'run.py').write_text(old)
js=(REF/'probe.mjs').read_text();js=js.replace('WOLF_PROBE','GT_PROBE').replace('wolf_point_tavern','green_tree_tavern').replace('sauganash_hotel','green_tree_tavern').replace('philo_carpenter_log_shop','green_tree_tavern').replace('saugExterior','gtExterior').replace('saugArrival','gtArrival').replace('saug_reference_camera','gt_reference_camera').replace('saug_entrance','gt_entrance').replace('SAUG','GT').replace('saug-exterior','gt-exterior').replace('saug-arrival','gt-arrival').replace('wolf-images','gt-images').replace('ACTUAL-WOLF-CARD','ACTUAL-GT-CARD').replace('WOLF-RESULT','GT-CARD-RESULT').replace('Wolf','Green Tree').replace('Sauganash','Green Tree').replace('Carpenter','Green Tree')
js=js.replace('ACTUAL_PUBLISHED_COMBINED_WOLF_GT_PASS','ACTUAL_PUBLISHED_GREEN_TREE_PASS').replace('ACTUAL_PUBLISHED_COMBINED_WOLF_GT_FAIL','ACTUAL_PUBLISHED_GREEN_TREE_FAIL')
start=js.index('  await page.waitForFunction(()=>{\n    const pane=document.querySelector(\'#popup [data-pop-pane="images"]\');');end=js.index("  const screenshot=path.join(out,'gt-images.jpg')",start)
js=js[:start]+'''  const imageLocator=page.locator('#popup [data-pop-pane="images"] img');
  assert.equal(await imageLocator.count(),plan.expected_held_count,'Native thumbnail count follows actual compiled held rows');
  const loadedImages=[];
  for(let index=0;index<plan.expected_held_count;index++){
    const item=imageLocator.nth(index);await item.scrollIntoViewIfNeeded();
    await item.evaluate(async image=>{const until=Date.now()+60000;while((!image.complete||image.naturalWidth===0)&&Date.now()<until)await new Promise(r=>setTimeout(r,100));if(!image.complete||image.naturalWidth===0)throw Error('Native held picture did not load');});
    const actual=await item.evaluate(image=>{const r=image.getBoundingClientRect();return{src:image.currentSrc,naturalWidth:image.naturalWidth,naturalHeight:image.naturalHeight,rect:{x:r.x,y:r.y,width:r.width,height:r.height},inViewport:r.width>0&&r.height>0&&r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth};});
    assert(actual.inViewport&&actual.naturalWidth>0,'Genuine held thumbnail loaded through physical card scrolling');loadedImages.push(actual);
  }
  const paneVisibility=await page.locator('#popup [data-pop-pane="images"]').evaluate(p=>{const r=p.getBoundingClientRect();return{width:r.width,height:r.height,inViewport:r.width>0&&r.height>0&&r.bottom>0&&r.top<innerHeight};});
  assert(paneVisibility.inViewport,'Native credited Images pane is physically visible');
  const visibleImage={expected_held_count:plan.expected_held_count,loadedImages,paneVisibility,no_held_thumbnail_claim:plan.expected_held_count===0};
  save('VISIBLE-IMAGE.json',visibleImage);
'''+js[end:]
js=js.replace('outcome.items>=6','outcome.items===plan.expected_picture_count')
js=js.replace("assert(outcome.missingExpected.length===0&&outcome.noHistoricalSpots,'Seven reviewed diagnostic views join six credited sources without invented historical camera spots');","assert(outcome.missingExpected.length===0,'Every frozen compiled Green Tree picture row is present');\n  assert.deepEqual(outcome.rows,plan.gt_picture_rows,'Actual published picture rows and credits match the frozen plan');")
js=js.replace("assert(outcome.rows.length===6&&outcome.rows.filter(r=>r.held).length===1&&outcome.rows.filter(r=>!r.held).length===5,'Actual Green Tree card is one held image and five credited links');","assert(outcome.rows.length===plan.expected_picture_count&&outcome.rows.filter(r=>r.held).length===plan.expected_held_count,'Actual held/link counts match the frozen native compiled card');")
js=js.replace('whole-hotel','whole-compound').replace('full-hotel','full-Green-Tree').replace('Actual published Green Tree Images card and Green Tree exterior/arrival per viewport.','Actual published partial Green Tree Images card and compound exterior/arrival per viewport.')
js=js.replace('reference_world_eye:referenceEye','reference_world_eye:referenceEye,reference_direction_only:true')
(P/'probe.mjs').write_text(js)
print('Helpers written without reading canonical source or preparing a plan.')
