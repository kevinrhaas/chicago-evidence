"""Publish a closed proof bundle independently by normal FF and exact blob readback."""
from pathlib import Path
import argparse,json,hashlib,base64,zipfile
from urllib.request import Request,urlopen
from urllib.error import HTTPError
ap=argparse.ArgumentParser();ap.add_argument('--bundle',type=Path,required=True);ap.add_argument('--prefix',required=True);args=ap.parse_args();O=args.bundle;P=O/'payload';PREFIX=args.prefix;assert PREFIX.startswith('evidence/green-tree-2026-11-03/')and PREFIX.endswith('/')and'..'not in PREFIX;assert not(O/'PUBLISHED.json').exists();sha=lambda b:hashlib.sha256(b).hexdigest();gsha=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();API='https://api.github.com/repos/kevinrhaas/chicago-evidence/';archive=json.loads((O/'archive.json').read_bytes());assert sha((O/'proof.zip').read_bytes())==archive['sha256'];manifest=json.loads((P/'CLOSED-MANIFEST.json').read_bytes());assert sha((P/'CLOSED-MANIFEST.json').read_bytes())==archive['manifest_sha256']
with zipfile.ZipFile(O/'proof.zip')as z:
 for row in manifest['members']:assert sha(z.read(row['path']))==row['sha256']
files={n:(O/n).read_bytes()for n in ['proof.zip','archive.json']}
for n in ['RECOVERY.md','ROOT-RECOVERY.md','SUMMARY.json','CLOSED-MANIFEST.json']:files[n]=(P/n).read_bytes()
for p in(P/'actual-ui').rglob('*')if(P/'actual-ui').exists()else[]:
 if p.is_file()and(p.suffix=='.jpg'or p.name in ['RESULT.json','ROOT-DIRECT-REVIEW.json']):files[p.relative_to(P).as_posix()]=p.read_bytes()
for n in ['native-stage3/RESULT.json','native-stage3/FINAL-CLOSURE.json']:
 if(P/n).exists():files[n]=(P/n).read_bytes()
def api(p,data=None,method=None):
 req=Request(API+p,data=None if data is None else json.dumps(data).encode(),headers={'User-Agent':'Chicago-published-evidence','Content-Type':'application/json','Accept':'application/vnd.github+json'},method=method or('GET'if data is None else'POST'))
 with urlopen(req,timeout=60)as r:return json.load(r)
blobs={}
for n,b in files.items():
 d=api('git/blobs',{'encoding':'base64','content':base64.b64encode(b).decode()});assert d['sha']==gsha(b);blobs[n]=d['sha']
for attempt in range(5):
 parent=api('git/ref/heads/main')['object']['sha'];base=api('git/commits/'+parent)['tree']['sha'];tree=api('git/trees',{'base_tree':base,'tree':[{'path':PREFIX+n,'mode':'100644','type':'blob','sha':blobs[n]}for n in files]});commit=api('git/commits',{'message':'Save prepared Green Tree QA helper; not executed','tree':tree['sha'],'parents':[parent]})
 try:api('git/refs/heads/main',{'sha':commit['sha'],'force':False},'PATCH');break
 except HTTPError as e:
  if e.code not in(409,422):raise
else:raise RuntimeError('Concurrent evidence updates; no forced push')
for n,b in files.items():assert base64.b64decode(api('git/blobs/'+blobs[n])['content'])==b
receipt={'commit':commit['sha'],'prefix':PREFIX,'normal_fast_forward':True,'every_blob_readback_exact':True,'files':{n:{'bytes':len(b),'sha256':sha(b),'url':'https://github.com/kevinrhaas/chicago-evidence/blob/'+commit['sha']+'/'+PREFIX+n}for n,b in files.items()}};(O/'PUBLISHED.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'commit':commit['sha'],'files':len(files),'readback':'PASS'}))
