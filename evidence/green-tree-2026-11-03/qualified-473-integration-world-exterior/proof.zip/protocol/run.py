"""Focused post-tree GT world/exterior replay only. --prepare only writes a draft; root separately releases it."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,stat,subprocess,sys
P=Path(__file__).resolve().parent
R=Path('/workspace/chicago-bridge-increment-20261102');A=R/'chicago/4d';S=R/'site/4d'
TARGET='green_tree_tavern'
EXPECTED_GT_MASTER='f447aa45b93e507ea8606f6c74703b5948d9ee736a84d3a01d47d8a587db81c3'
PROTECTED_MODELS=json.loads((P/'PROTECTED-0E-MODELS.json').read_bytes())

sha=lambda b:hashlib.sha256(b).hexdigest()
pf=lambda p:sha(Path(p).read_bytes())
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def git(*args):return subprocess.check_output(['git','-C',str(R),*args],env=E)
def canonical(value):return (json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
def metadata():
    result={k:sha(git(*args)) for k,args in {'index_stage':['ls-files','--stage','-z'],'index_flags':['ls-files','-v','-z'],'refs':['for-each-ref','--format=%(refname) %(objectname)'],'config':['config','--local','--list','--null'],'untracked':['ls-files','--others','--exclude-standard','-z']}.items()}
    result['head']=git('rev-parse','HEAD').decode().strip()
    for name in ['index','HEAD','MERGE_HEAD','MERGE_MSG','ORIG_HEAD']:
        q=Path(git('rev-parse','--path-format=absolute','--git-path',name).decode().strip())
        result[name]=dict(sha256=pf(q),mode=stat.S_IMODE(q.stat().st_mode),mtime_ns=q.stat().st_mtime_ns,ctime_ns=q.stat().st_ctime_ns)if q.exists()else None
    return result
def inspect_inputs(reference_name=None,collision_reaper=None,collision_log=None):
    # This function is called ONLY by a later explicit frozen-source plan/run.
    assert collision_reaper and collision_log,'Bind the current existing native collision fixture proof at frozen-source preparation'
    collision_reaper=Path(collision_reaper);collision_log=Path(collision_log);cr=json.loads(collision_reaper.read_bytes())
    assert cr['command_exit']==0 and cr['all_children_reaped']and not cr['leftover_cleanup']
    assert any(str(x).endswith('test_walker_passage.mjs')for x in cr['command'])
    assert 'WALKER PASSAGE PASS'in collision_log.read_text()
    files=set((A/'renderers/web/js').rglob('*.js'))|set((S/'walk/js').rglob('*.js'))
    files|={collision_reaper,collision_log,A/'tools/test_walker_passage.mjs',A/'tools/test_frame_tavern_picture_features.py'}
    views=A/'data/reference_views'/TARGET
    cameras=sorted(p for p in views.glob('*.json')if not p.name.endswith('.match.json'))
    assert cameras,'No native Green Tree diagnostic cameras'
    choices=[p for p in cameras if p.name==reference_name]if reference_name else[p for p in cameras if 'andreas'in p.stem.lower()]
    assert len(choices)==1,('Choose one existing diagnostic direction with --camera', [p.name for p in cameras])
    chosen=choices[0];reference=json.loads(chosen.read_bytes());assert len(reference['eye'])==3
    camera_bindings=[]
    for camera in cameras:
        match=camera.with_suffix('.match.json');c=json.loads(camera.read_bytes());m=json.loads(match.read_bytes());photo=(camera.parent/c['photo']).resolve();model=A/m['glb'];sideby=A/m['side_by_side']
        assert pf(camera)==m['camera_sha256']and pf(photo)==m['photo_sha256']and pf(model)==m['glb_sha256']
        # A genuine diagnostic 'differs' result is preserved; no match verdict is invented.
        assert m.get('verdict')in ('matches','differs')
        files|={camera,match,photo,model,sideby,A/'data/sources'/f"{c['source_id']}.json"}
        camera_bindings.append(dict(camera=camera.name,source_id=c['source_id'],verdict=m['verdict'],group_sha256=m.get('group_sha256')))
    pictures=A/'data/pictures/1835.json';published_pictures=S/'data/pictures/1835.json';assert pictures.read_bytes()==published_pictures.read_bytes()
    rows=json.loads(published_pictures.read_bytes())['by_structure'][TARGET];assert rows and len({r['id']for r in rows})==len(rows)
    files|={pictures,published_pictures,S/'walk/index.html',A/'tools/compile_pictures.py',A.parent/'prairie_1904_v1/data/images.json',A/'assets/manifest.json',A/'assets/manifest.versions.json',A/'assets/manifest.web.json'}
    assert(A/'renderers/web/js/main.js').read_bytes()==(S/'walk/js/main.js').read_bytes()
    contract=json.loads((P/'household-contract-REAPER.json').read_bytes());assert contract['command_exit']==0 and contract['all_children_reaped']and not contract['leftover_cleanup']
    assert'record(s) ship slim, and their households ship whole beside them'in(P/'household-contract.log').read_text()
    files|={P/'household-contract.log',P/'household-contract-REAPER.json',A/'tools/defer_household_notes.mjs',P/'PROTECTED-0E-MODELS.json'}
    for sid in [TARGET,'sauganash_hotel','wolf_point_tavern','philo_carpenter_log_shop']:
        source=A/f'data/sidecars/1835/{sid}.json';published=S/f'data/sidecars/1835/{sid}.json';record=json.loads(source.read_bytes());shipped=json.loads(published.read_bytes());files|={source,published,A/f'data/structures/{sid}.json'}
        if record.get('residents'):
            household=S/f'data/sidecars/1835/households/{sid}.json';doc=json.loads(household.read_bytes());assert doc=={'id':record['id'],'residents':record['residents']};assert dict(shipped,residents=doc['residents'])==record;files.add(household)
        else:assert shipped==record
        asset=Path(record['asset']);assert not asset.is_absolute()and'..'not in asset.parts
        files|={A/'assets'/asset,A/'assets/web'/asset.name,S/'data'/asset};assert(A/'assets/web'/asset.name).read_bytes()==(S/'data'/asset).read_bytes()
    for name,expected in PROTECTED_MODELS.items():assert pf(name)==expected,name;files.add(Path(name))
    master=A/'assets/gltf/green_tree_tavern__frame_1833.glb';assert pf(master)==EXPECTED_GT_MASTER
    sc=json.loads((A/'data/sidecars/1835/green_tree_tavern.json').read_bytes());parts=sc['footprint']['additional_polygons'];assert [x['id']for x in parts]==['connector','boarding_range']
    web=A/'assets/web'/Path(sc['asset']).name
    for rel in ['data/enclosures/town_entrance_aprons.json','data/yard/town_trade_goods.json']:
        files|={A/rel,S/rel};assert(A/rel).read_bytes()==(S/rel).read_bytes()
    entrances=json.loads((A/'data/enclosures/town_entrance_aprons.json').read_bytes())['entrances'];entrance=next(x for x in entrances if x['id']=='green_tree_tavern__door_1')
    bindings={str(f):dict(sha256=pf(f),bytes=f.stat().st_size,mode=stat.S_IMODE(f.stat().st_mode))for f in sorted(files)}
    return dict(input_bindings=bindings,collision_reaper=str(collision_reaper),collision_log=str(collision_log),gt_reference_camera=reference,gt_reference_camera_name=chosen.name,gt_reference_camera_scope='Existing diagnostic eye supplies an oblique direction only; actual pose is recomputed to fit current compound bounds, never historical calibration.',gt_entrance=entrance,gt_all_entrances=[x for x in entrances if x['id'].startswith(TARGET+'__')],gt_occupied_parts=parts,gt_picture_rows=rows,expected_picture_ids=[r['id']for r in rows],expected_picture_count=len(rows),expected_held_count=sum(bool(r.get('held'))for r in rows),gt_MASTER_sha256=pf(master),gt_WEB_sha256=pf(web),camera_bindings=camera_bindings)
def inputs(plan):return inspect_inputs(plan['gt_reference_camera_name'],plan['collision_reaper'],plan['collision_log'])['input_bindings']

ap=argparse.ArgumentParser();ap.add_argument('--prepare',type=Path);ap.add_argument('--camera');ap.add_argument('--frozen-head');ap.add_argument('--collision-reaper',type=Path);ap.add_argument('--collision-log',type=Path);ap.add_argument('--plan',type=Path);ap.add_argument('--plan-sha256');ap.add_argument('--run',action='store_true');args=ap.parse_args()
if args.prepare:
    assert not args.run and not args.prepare.exists()
    assert args.frozen_head and git('rev-parse','HEAD').decode().strip()==args.frozen_head,'Explicit exact frozen HEAD is required for draft preparation'
    assert not git('status','--porcelain','--untracked-files=normal'),'Frozen source must be clean'
    current=inspect_inputs(args.camera,args.collision_reaper,args.collision_log);bindings=current.pop('input_bindings')
    plan=dict(current,root_approved=False,source_check_parts_and_publish_closed=False,source_root=str(R),site_parent=str(R/'site'),output='/workspace/green-tree-post-tree-both-actual-20261103',TMP='/tmp/green-tree-post-tree-actual-20261103',expected_head=args.frozen_head,input_bindings=bindings,source_scope_sha256=sha(canonical(bindings)),metadata=metadata(),helpers={'run.py':pf(P/'run.py'),'probe.mjs':pf(P/'probe.mjs')},reaper_sha256=pf('/workspace/shared/run-with-reaping.py'),scope='Fresh two-viewport default-visitor1835 world and curated GT compound exterior/native readback after changed shared trees code. This targeted replay does not re-exercise or relabel the c563 credited Images card, native arrival or107x2 native stage3 results. Those require separate unchanged-data/full-map scope evidence. No full-photo, traversal or all-features-unobstructed signoff.')
    args.prepare.write_text(json.dumps(plan,indent=2)+'\n');print('Draft only. Root must set both approval booleans true after source/publication writers close.');sys.exit(0)
assert args.run and args.plan and args.plan_sha256 and pf(args.plan)==args.plan_sha256
plan=json.loads(args.plan.read_bytes());assert plan['root_approved']is True and plan['source_check_parts_and_publish_closed']is True
assert plan['source_root']==str(R)and plan['site_parent']==str(R/'site')
assert plan['helpers']=={'run.py':pf(P/'run.py'),'probe.mjs':pf(P/'probe.mjs')}
assert plan['reaper_sha256']==pf('/workspace/shared/run-with-reaping.py')
assert plan['source_scope_sha256']==sha(canonical(plan['input_bindings']))
assert inputs(plan)==plan['input_bindings']and metadata()==plan['metadata']and git('rev-parse','HEAD').decode().strip()==plan['expected_head']
O=Path(plan['output']);T=Path(plan['TMP']);assert O.is_relative_to('/workspace')and T.is_relative_to('/tmp')and not O.is_relative_to(R)and not T.is_relative_to(R)and not O.exists()and not T.exists()
O.mkdir();T.mkdir(mode=0o700);os.sched_setaffinity(0,{0,1,3,4});os.nice(19)
def save(n,value):(O/n).write_text(json.dumps(value,indent=2)+'\n')
def floor():
    v={x:shutil.disk_usage(x).free for x in ['/workspace','/tmp']};assert v['/workspace']>=536870912 and v['/tmp']>=1800000000,v;return v
run_env=dict(E,TMPDIR=str(T),TMP=str(T),TEMP=str(T),NODE_COMPILE_CACHE=str(T/'node-cache'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PLAYWRIGHT_DISABLE_FORCED_CHROMIUM_PROXIED_LOOPBACK='1',GT_PROBE_PLAN=str(args.plan))
for k in ['SMOKE_ROOT','SMOKE_ENTRY','SMOKE_TARGET','SMOKE_YEAR','SMOKE_PORT','SMOKE_STAGE','SMOKE_VIEWPORT','SMOKE_SHOTS']:run_env.pop(k,None)
before=metadata();steps=[];error=None;closure=None
save('OWNER.json',dict(pid=os.getpid(),at=now(),head=plan['expected_head'],plan=str(args.plan),plan_sha256=args.plan_sha256,resources=floor(),scope=plan['scope']))
try:
    for viewport in ['desktop','mobile']:
        assert metadata()==before and inputs(plan)==plan['input_bindings'];floor()
        env=dict(run_env,GT_PROBE_VIEWPORT=viewport,GT_PROBE_OUT=str(O/viewport))
        receipt=O/(viewport+'-REAPER.json');log=O/(viewport+'.log')
        command=['python3','/workspace/shared/run-with-reaping.py',str(receipt),'--','timeout','--signal=TERM','--kill-after=15s','600s','nice','-n','19','taskset','-c','0,1,3,4','node',str(P/'probe.mjs')]
        with log.open('xb')as handle:q=subprocess.run(command,cwd=A,env=env,stdout=handle,stderr=subprocess.STDOUT)
        rr=json.loads(receipt.read_bytes());steps.append(dict(viewport=viewport,exit=q.returncode,reaper=rr,reaper_sha256=pf(receipt),log=str(log),log_sha256=pf(log)));save('STEPS.json',steps)
        assert q.returncode==rr['command_exit']==0 and rr['all_children_reaped']and not rr['leftover_cleanup']and rr['interrupted_signal']is None,steps[-1]
        assert json.loads((O/viewport/'RESULT.json').read_bytes())['status']=='ACTUAL_PUBLISHED_GT_WORLD_EXTERIOR_PASS'
        assert metadata()==before and inputs(plan)==plan['input_bindings'];floor()
except BaseException as exc:error=repr(exc)
finally:
    try:
        closure=dict(metadata_unchanged=metadata()==before,selected_source_and_published_inputs_unchanged=inputs(plan)==plan['input_bindings'],plan_unchanged=pf(args.plan)==args.plan_sha256,helpers_unchanged=plan['helpers']=={'run.py':pf(P/'run.py'),'probe.mjs':pf(P/'probe.mjs')},resources=floor())
        assert all(closure[k]for k in ['metadata_unchanged','selected_source_and_published_inputs_unchanged','plan_unchanged','helpers_unchanged'])
    except BaseException as exc:error=(error+'; 'if error else '')+'Closure: '+repr(exc)
save('RESULT.json',dict(status='FOCUSED_PUBLISHED_GT_WORLD_EXTERIOR_BOTH_PASS'if error is None and len(steps)==2 else'FOCUSED_PUBLISHED_GT_WORLD_EXTERIOR_NOT_QUALIFIED',at=now(),head=plan['expected_head'],source_scope_sha256=plan['source_scope_sha256'],steps=steps,closure=closure,error=error,no_retry=True,scope=plan['scope']))
print(json.dumps({'status':json.loads((O/'RESULT.json').read_bytes())['status'],'error':error,'output':str(O)}));sys.exit(1 if error else 0)
