"""Print native owner commands; never execute them or mutate an app."""
from pathlib import Path
import argparse,json

ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--app',type=Path,required=True);args=ap.parse_args();app=args.app.resolve();O=Path(__file__).parent
manifest=json.loads((app/'tools/derived_manifest.json').read_bytes());steps=manifest['steps']
def owner(script):
    hits=[(i+1,s['command'])for i,s in enumerate(steps)if any(str(a).endswith(script)for a in s['command'])]
    assert len(hits)==1,(script,hits)
    return {'display_ordinal_1_based':hits[0][0],'command':hits[0][1]}
scripts=['compile_liberties.py','compile_scene.py','generate_entrances.py','compile_source_use.py','generate_dooryard_pickets.py','generate_dooryard_plantings.py','generate_frontage_works.py','generate_yard_goods.py']
owners={s:owner(s)for s in scripts};scene=owners['compile_scene.py']['display_ordinal_1_based']-1
assert scene<owners['generate_entrances.py']['display_ordinal_1_based']-1<owners['compile_source_use.py']['display_ordinal_1_based']-1
rows=json.loads((O/'NATIVE25-RECIPE-DOCUMENTS.json').read_bytes())['rows'];csv=','.join(r['native_registry_key']for r in rows);assert len(rows)==25
plan={'status':'NATIVE_OWNER_COMMAND_PLAN_ONLY_NOT_EXECUTED','app_input':str(app),'current_local_Blender_allowed':False,'MASTER_strategy':'Consume authenticated existing f447 artifact and actual native25 post rows ONLY after full current recipe-document and SHA identity. If identity fails, stop and use sanctioned GitHub bake/data-half route. No local Blender command exists in this plan.','declared_READ_addition':'read.structures: phases[].form.enclosed_left_annex.note','native_owner_resolution':owners,'scene_tail_steps_resolved_dynamically':[s['command']for s in steps[scene:]],'ordered_stages':[
 {'stage':'metadata-and-native-artifact','command':'Use /tmp/GT-native-adopter-20261103/adopt.py with explicit --app, --packet, --source-guards, --receipt-dir; --check then --adopt. Both recheck all25 full native recipe documents before asset writes.'},
 {'stage':'real-WEB25','command':['bash','tools/web_derivatives.sh','--only',csv],'pin':'CLI,core,functions,extensions all4.5.0; native script proves resolution before writing'},
 {'stage':'WEB-preservation','command':'Run same adopter with --verify-web; require24otherMASTER/WEBexact,23canonicalmasterlinks,2TremontversionWEBlinks,foreignregistryrows/metadataexact.'},
 {'stage':'READ-native-check','command':['python3','tools/replace_invented_residents.py','--check'],'on_failure':'Investigate actual policy/seat finding; do not ignore provenance or silently rewrite resident cards.'},
 {'stage':'Liberties-owner','command':owners['compile_liberties.py']['command']},
 {'stage':'settled-scene-entrance-source-use-and-yard-owners','command':['node','tools/rederive.mjs','--tail','tools/compile_scene.py'],'note':'Native tail resolves current manifest command order and repeats to fixed point. Do not compile scene alone or drive it by a remembered ordinal.'},
 {'stage':'genuine-Andreas-render','command':['node','tools/photo_match.mjs','data/reference_views/green_tree_tavern/andreas_1838.json'],'review_required':'Actual renderer rewrites image/model/camera bindings and resets changed-input verdict to unreviewed. Read actual image/side-by-side, retain original open gaps and differs where present; never edit only hashes.'},
 *[{'stage':f'source-part-{n}','command':['./tools/check.sh','--part',f'{n}/4'],'foreground_seconds_cap':600}for n in range(1,5)],
 {'stage':'PR-preflight-questions','commands':[['node','tools/check-changelog-entry.mjs','<merge-base>','HEAD'],['node','tools/resolve_id_collisions.mjs','--check']]},
 {'stage':'publish-and-contract','commands':[['./tools/publish.sh'],['node','tools/check_published.mjs']]},
 {'stage':'actual-two-viewport-qualification-and-PR','note':'After writer closure: real published desktop+390x780 scene/card/routes/yard/framing checks, source-bound evidence, final-head CI and normal dev PR. Partial original T2376 stays open.'}
], 'ordinal_note':'Display ordinals are1-based. Earlier checkpoint147/148/151 were unlabeled0-based indexes; no numeric ordinal drives a command here.'}
print(json.dumps(plan,indent=2))
