# Green Tree connector and turned range — partial original-ticket increment

The new low connector and turned farther gabled range replace the previous rear ell beside Green Tree's existing open wagon bay. The main-gable door and two-sash layout were already adopted. The open shoulder is not drawn by the model: `shoulder_enclosed: false` omits it, while the existing native yard layer supplies the bay's roof, posts and covered wagon. It is not a second model roof. The separate closed-shoulder alternative remains unenrolled.

Andreas1884, Trowbridge1902 and Kurz1893 are retrospective, potentially dependent pictured readings, not independent contemporary dimensions. Every numeric annex parameter and its July1835 continuity remain reconstructed. The genuine MASTER `f447aa45…` comes from the authenticated earlier native production/control run. Adopting it requires full equality of all25 current native recipe documents to that production record, preserving the other24 MASTERs; it is not a new local bake.

The occupied-solid consumers keep the core reference footprint and separate connector/range rings, leaving the open bay and gaps open. They carry the same component frames through compilation, collisions, routes, ground/prop clearance, entrance placement and framing. Sauganash's existing APIs and source/model values remain unchanged.

The read-only yard audit found no Green Tree-specific clearance finding with the new occupied rings. The actual native yard roof's flat-base projection stops about0.249m before the connector wall. Its projected roof edge touches the connector roof's projection by only1.3mm; that is not duplicate geometry or proof of a3-D intersection. Actual terrain seating, the compiled yard and app appearance still require runtime review.

This is useful partial progress on original T-2376. Its genuine Andreas comparison must be rendered again from the new model and reviewed; the original full picture-match signoff stays open. No new photo follow-up or complete-match claim is made.
