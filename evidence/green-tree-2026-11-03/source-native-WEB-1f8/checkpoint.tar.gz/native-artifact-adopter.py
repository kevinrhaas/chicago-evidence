#!/usr/bin/env python3
"""Finite authenticated GT artifact adoption; metadata only, never a mesh bake."""
import argparse
import copy
import hashlib
import importlib.abc
import json
import shutil
import sys
from pathlib import Path
sys.dont_write_bytecode = True
GT = 'green_tree_tavern__frame_1833.glb'
OLD = 'f69934897306e608bad55f6ffecfdcb53adf030675b6df0df9fa1004ba3a4d2c'
NEW = 'f447aa45b93e507ea8606f6c74703b5948d9ee736a84d3a01d47d8a587db81c3'
CLOSED = '44e832f1be4da5e4f7dad90347947e254110f501b89cf1ab2cc77051490970b3'
RECIPES = 'd4e0d2c71ba529eb76db5dd379c4b4dfd3ef38a70ae95db58994709a975250e0'
REGS = ['assets/manifest.json', 'assets/manifest.versions.json', 'assets/manifest.web.json']
PINNED_POSTS = {'chicago/4d/generators/archetypes/frame_tavern.py',
                'chicago/4d/generators/archetypes/frame_tavern_params.py',
                'chicago/4d/data/structures/green_tree_tavern.json'}
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    return json.loads(p.read_text())
def need(ok, message):
    if not ok:
        raise ValueError(message)
def write(p, d):
    p.write_text(json.dumps(d, indent=2, sort_keys=True) + '\n')
def member(root, rel):
    p = (root / rel).resolve()
    need(p.is_relative_to(root), 'path escapes root: ' + rel)
    return p
class MetadataOnly(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        need(fullname.split('.')[0] not in {'bpy', 'build', 'emit'}, 'prohibited import: ' + fullname)
def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ['app', 'receipt-dir', 'packet']:
        ap.add_argument('--' + name, required=True, type=Path)
    ap.add_argument('--source-guards', type=Path, help='Explicit final 23 guards; three native geometry/data posts remain pinned')
    modes = ap.add_mutually_exclusive_group(required=True)
    for mode in ['check', 'adopt', 'verify-web']:
        modes.add_argument('--' + mode, action='store_true')
    a = ap.parse_args()
    app, out, packet = a.app.resolve(), a.receipt_dir.resolve(), a.packet.resolve()
    need(app.is_dir() and packet.is_dir(), 'explicit app and packet must be directories')
    need(not out.is_relative_to(app) and not app.is_relative_to(out), 'receipts must be outside app')
    need(not out.is_relative_to(packet), 'receipts must be outside authenticated packet')
    need(sha(packet / 'CLOSED-MANIFEST.json') == CLOSED, 'unauthenticated closed packet')
    closed = read(packet / 'CLOSED-MANIFEST.json')
    for row in closed['members']:
        p = member(packet, row['path'])
        need(sha(p) == row['sha256'] and p.stat().st_size == row['bytes'], 'packet member: ' + row['path'])
    recipe_file = Path(__file__).resolve().with_name('NATIVE25-RECIPE-DOCUMENTS.json')
    need(sha(recipe_file) == RECIPES, 'unauthenticated recipe documents')
    proof = read(recipe_file)
    rows = proof['rows']
    need(len(rows) == 25 and len({r['master_path'] for r in rows}) == 25, 'native family count')
    native = read(packet / 'evidence/prior-native/RESULT.json')
    reaper = read(packet / 'evidence/prior-native/REAPER.json')
    need(sha(packet / 'evidence/prior-native/RESULT.json') == proof['prior_native_result_sha256'], 'native result')
    need(sha(packet / 'evidence/prior-native/REAPER.json') == proof['prior_native_reaper_sha256'], 'native reaper')
    need(reaper['command_exit'] == 0 and reaper['all_children_reaped'] and not reaper['leftover_cleanup'], 'native reaper failed')
    need(native['official_wrote_count'] == 25 and native['all24_unaffected_official_masters_byte_exact'], 'native production incomplete')
    reg_file = packet / 'prior-native-REGISTRY-ROWS.json'
    need(sha(reg_file) == proof['native_registry_rows_sha256'], 'native production rows')
    actual_rows = {(r['path'].removeprefix('chicago/4d/'), x['key']): x for r in read(reg_file)['registries'] for x in r['rows']}
    guard_file = (a.source_guards or packet / 'ADOPTION-FILES.json').resolve()
    need(not guard_file.is_relative_to(app), 'final source guards must be outside app')
    guards = read(guard_file)['rows']
    original = {r['path']: r for r in read(packet / 'ADOPTION-FILES.json')['rows']}
    need(len(guards) == 23 and {r['path'] for r in guards} == set(original), 'source guard set')
    source_hashes = {}
    for r in guards:
        rel = r['path']
        need(rel not in PINNED_POSTS or r['post_sha256'] == original[rel]['post_sha256'], 'native geometry/data post changed: ' + rel)
        p = member(app, rel.removeprefix('chicago/4d/'))
        source_hashes[rel] = sha(p)
        need(source_hashes[rel] == r['post_sha256'], 'source post mismatch: ' + rel)
    read_file = member(app, 'data/reconstruction/name_pool_keys.json')
    source_hashes['chicago/4d/data/reconstruction/name_pool_keys.json'] = sha(read_file)
    read_keys = read(read_file)['read']['structures']
    for key in ['phases[].form.enclosed_left_annex.note', 'phases[].form.rear_ell.note']:
        need(key in read_keys, 'missing READ key: ' + key)
    need(any('front_lower_sash.note' in k for k in read_keys), 'missing Sauganash READ note')
    sys.path.insert(0, str(app / 'generators'))
    sys.meta_path.insert(0, MetadataOnly())
    import mesh_inputs
    need(Path(mesh_inputs.__file__).resolve() == app / 'generators/mesh_inputs.py', 'metadata import origin')
    docs = {rel: read(member(app, rel)) for rel in REGS}
    canonical = {r['native_registry_key'] for r in rows if r['native_registry'] == REGS[0]}
    versions = {r['native_registry_key'] for r in rows if r['native_registry'] == REGS[1]}
    need(len(canonical) == 23 and len(versions) == 2, 'expected 23 canonical + 2 versions')
    need(versions == {f'versions/tremont_house_1/{v}/tremont_house_1__frame_1833.glb' for v in ['gale-reading', 'gifford-reading']}, 'version family')
    for rel, wanted in [(REGS[0], canonical), (REGS[1], versions)]:
        need({k for k,v in docs[rel]['assets'].items() if v.get('archetype') == 'frame_tavern'} == wanted, 'registry family set: ' + rel)
    hashes = {}
    for r in rows:
        rel, key, post = r['native_registry'], r['native_registry_key'], r['native_production_registry_row']
        need(actual_rows[(rel,key)]['post'] == post, 'native row mismatch: ' + key)
        record = read(member(app, r['record_path']))
        phase = next(p for p in record['phases'] if p['id'] == r['phase'])
        need(json.loads(json.dumps(mesh_inputs.structure_inputs_doc(record, phase))) == r['native_input_document'], 'recipe document mismatch: ' + key + '; use sanctioned GitHub bake/data-half route, never local Blender')
        need(mesh_inputs.structure_inputs_sha(record, phase) == r['inputs_sha256'] == post['inputs_sha256'], 'recipe SHA mismatch: ' + key)
        master = member(app, r['master_path'])
        expected = NEW if a.verify_web or key != GT else OLD
        if key != GT:
            expected = r['master_sha256']
        need(sha(master) == expected, 'current MASTER mismatch: ' + key)
        webrel = r['master_path'].replace('assets/gltf/', 'assets/web/', 1)
        hashes[r['master_path']] = sha(master)
        hashes[webrel] = sha(member(app, webrel))
        if not a.verify_web:
            current = docs[rel]['assets'][key]
            need(all(current.get(k) == v for k,v in actual_rows[(rel,key)]['pre'].items()), 'target pre-row changed: ' + key)
    native_output = native['selected_native_outputs'][0]
    need(native_output['relative_to_mirror'] == 'assets/gltf/' + GT and native_output['sha256'] == NEW and native_output['bytes'] == 245112, 'native GT output identity')
    artifact = member(packet, 'models/chicago/4d/assets/gltf/' + GT)
    need(sha(artifact) == native_output['sha256'] and artifact.stat().st_size == native_output['bytes'], 'authenticated packet GT artifact unavailable')
    csv = ','.join(r['native_registry_key'] for r in rows)
    snapshot = {'app': str(app), 'registries': docs, 'hashes': hashes, 'source_hashes': source_hashes, 'packet_sha256': CLOSED, 'recipes_sha256': RECIPES, 'source_guards_path': str(guard_file), 'source_guards_sha256': sha(guard_file)}
    out.mkdir(parents=True, exist_ok=True)
    if a.verify_web:
        before = read(out / 'BEFORE.json')
        adoption = read(out / 'ADOPTED.json')
        need(sha(out / 'BEFORE.json') == adoption['before_sha256'] and before['app'] == str(app), 'before receipt binding')
        need(before['source_hashes'] == source_hashes, 'sources changed since adoption')
        need(before['source_guards_path'] == str(guard_file) and before['source_guards_sha256'] == sha(guard_file), 'final source guards changed since adoption')
        for p,h in before['hashes'].items():
            if Path(p).name != GT:
                need(hashes[p] == h, 'unaffected MASTER/WEB changed: ' + p)
        for rel in REGS:
            mapping = 'masters' if rel == REGS[2] else 'assets'
            wanted = canonical if rel != REGS[1] else versions
            olddoc, now = before['registries'][rel], docs[rel]
            need({k:v for k,v in olddoc.items() if k != mapping} == {k:v for k,v in now.items() if k != mapping}, 'registry metadata changed: ' + rel)
            need({k:v for k,v in olddoc[mapping].items() if k not in wanted} == {k:v for k,v in now[mapping].items() if k not in wanted}, 'foreign registry rows changed: ' + rel)
        for r in rows:
            rel,key = r['native_registry'],r['native_registry_key']
            expected = copy.deepcopy(before['registries'][rel]['assets'][key])
            expected.update(r['native_production_registry_row'])
            if rel == REGS[1]:
                expected = {k:v for k,v in expected.items() if not k.startswith('web_')}
                expected['web_master_sha256'] = r['master_sha256']
            else:
                need(docs[REGS[2]]['masters'].get(key) == r['master_sha256'], 'canonical WEB master link: ' + key)
            need(docs[rel]['assets'][key] == expected, 'adopted target row mismatch: ' + key)
        need(hashes['assets/web/' + GT] != before['hashes']['assets/web/' + GT], 'GT WEB was not regenerated')
        write(out / 'VERIFIED-WEB.json', {'status':'PASS_ARTIFACT_AND_WEB_PRESERVATION_ONLY_NOT_APP_READY', 'before_sha256':sha(out/'BEFORE.json'), 'hashes':hashes})
    elif a.check:
        write(out / 'CHECK.json', {'status':'PASS_METADATA_PREFLIGHT_ONLY_NOT_APP_READY', **snapshot})
    else:
        need(not (out / 'BEFORE.json').exists(), 'fresh receipt directory required for adoption')
        write(out / 'BEFORE.json', snapshot)
        for rel in REGS:
            shutil.copyfile(app / rel, out / Path(rel).name)
        before_sha = sha(out / 'BEFORE.json')
        for r in rows:
            rel,key = r['native_registry'],r['native_registry_key']
            target = docs[rel]['assets'][key]
            target.update(r['native_production_registry_row'])
            if rel == REGS[1]:
                for k in list(target):
                    if k.startswith('web_'):
                        del target[k]
        shutil.copyfile(artifact, app / 'assets/gltf' / GT)
        for rel in REGS[:2]:
            write(app / rel, docs[rel])
        write(out / 'ADOPTED.json', {'status':'ADOPTED_GENUINE_NATIVE_ARTIFACT_WEB_REQUIRED_NOT_APP_READY', 'before_sha256':before_sha, 'master_sha256':NEW, 'web_only_csv':csv})
    (out / 'WEB-ONLY.csv').write_text(csv + '\n')
    print(('PASS VERIFY-WEB' if a.verify_web else 'PASS CHECK' if a.check else 'ADOPTED; REAL WEB REQUIRED') + '; not app-ready')
    print(csv)
if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, OSError, StopIteration) as e:
        sys.exit('STOP: ' + str(e))
