# Native command order, without remembered step numbers

This is a new recovery note; checkpoints `d43266ce…` and `e1c2de29…` remain unchanged. Their adoption prose used147/148/151 as unlabelled zero-based array indexes. The same immutable0e entries display as148/149/152 in a one-based list. That ambiguity is removed here: commands are resolved by exact native owner names from the then-current `tools/derived_manifest.json`; displayed ordinals never drive execution.

`owner_plan.py --app <explicit immutable or adopted app>` reads that manifest and prints a JSON checklist. It never executes an owner or changes the application. The actual owner is `node tools/rederive.mjs --tail tools/compile_scene.py`: it includes every current step below scene, including entrances, source-use and yard writers, and repeats to its native fixed point. Compiling only the scene does not complete that dependency chain.

No local Blender command is offered. The GT MASTER is the authenticated existing f447 artifact. All25 current native recipe documents and actual recipe hashes must match the real earlier generated input documents/manifest before entrywise artifact adoption. A mismatch stops before writes and uses the sanctioned GitHub bake/data-half route. Native WEB production remains the pinned4.5.0 owner, with all25 exact master paths and explicit preservation of the two Tremont version links and24 other model deliveries.

The required new READ key is `phases[].form.enclosed_left_annex.note` in `data/reconstruction/name_pool_keys.json` under `read.structures`. The existing `rear_ell.note` and Sauganash lower-sash note stay READ. Native `replace_invented_residents.py --check` verifies the policy/deal without rewriting cards.

The genuine Andreas owner renders the new model and writes its own input bindings, resetting a changed-input verdict to unreviewed. The reviewer reads the actual image and side-by-side, then keeps remaining substantial gaps in the original record and original T-2376 open. Full source checks and actual app qualification still follow adoption.
