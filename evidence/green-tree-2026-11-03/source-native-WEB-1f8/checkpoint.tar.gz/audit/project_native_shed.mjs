import fs from 'node:fs';
import crypto from 'node:crypto';
const base='/tmp/GT-actual-increment-20261103/audit';
const source=fs.readFileSync('/tmp/GT-consumers-fort-20261103/immutable01a/chicago/4d/renderers/web/js/yard.js','utf8');
const start=source.indexOf('function buildShed('),end=source.indexOf('\n/**',start);
if(start<0||end<0)throw new Error('native buildShed not found');
const native=source.slice(start,end).trim();
const vertices=[];
// Generic box corner collector: execute the real buildShed body, without drawing.
const box=(buf,c,a,b,d)=>{for(const i of[-1,1])for(const j of[-1,1])for(const k of[-1,1])vertices.push(c.map((x,n)=>x+i*a[n]+j*b[n]+k*d[n]));};
const axisBox=(buf,x,y,z,ux,uz,hl,hw,hh)=>box(buf,[x,y,z],[ux*hl,0,uz*hl],[-uz*hw,0,ux*hw],[0,hh,0]);
const build=new Function('pushBox','pushBoxV','groundAt','DECK_T_M',`return (${native});`)(axisBox,box,()=>0,0.04);
const goods=JSON.parse(fs.readFileSync(base+'/town_trade_goods.0e.json'));
const shed=goods.sheds.find(x=>x.id==='green_tree_tavern_wagon_shed');
const problems=[];if(!build({},shed,{shedTimber:goods.form.shed_timber_m.value},{},1,problems)||problems.length)throw new Error(JSON.stringify(problems));
const out={status:'READ_ONLY_REAL_SHED_PRODUCER_FLAT_BASE_PROJECTION_NOT_APP_REVIEW',source_sha256:crypto.createHash('sha256').update(source).digest('hex'),shed_id:shed.id,vertices,flat_base_only:true,generic_box_corner_collection_only:true};
fs.writeFileSync(base+'/SHED-PROJECTED-VERTICES.json',JSON.stringify(out,null,2)+'\n');
console.log('Captured actual native shed box corners:',vertices.length);
