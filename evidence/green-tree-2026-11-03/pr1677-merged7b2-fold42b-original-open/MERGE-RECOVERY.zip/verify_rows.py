from pathlib import Path
import os,subprocess,json
p=Path(__file__).parent;n='/tmp/cobweb-active-20261103';e=os.environ.copy();e.update(GIT_OBJECT_DIRECTORY='/tmp/gt-clean-composite-qualification-20261103/default.git/objects',GIT_NO_LAZY_FETCH='1')
dev='b6cf5233320b1042dc1bb5d8eb92bbe7f8dbd830';head='74992e8fb2811f92e9e90da6f97039d1dd29b60c';tree='3df23705b71a3de069d547cdddae4991366b4418'
def read(ref,path):return json.loads(subprocess.check_output(['git','-C',n,'show',ref+':chicago/4d/'+path],env=e))
result={}
for path,key in [('assets/manifest.json','assets'),('assets/manifest.web.json','masters')]:
 old=read(dev,path);auth=read(head,path);merged=read(tree,path);own='green_tree_tavern__frame_1833.glb'
 assert merged[key][own]==auth[key][own]
 assert {k:v for k,v in merged[key].items() if k!=own}=={k:v for k,v in old[key].items() if k!=own}
 assert {k:v for k,v in merged.items() if k!=key}=={k:v for k,v in old.items() if k!=key}
 result[path]={'own_exact_accepted_head':True,'all_other_rows_and_metadata_exact_current_dev':True,'rows':len(merged[key])}
old=read(dev,'data/liberties.json');auth=read(head,'data/liberties.json');merged=read(tree,'data/liberties.json')
oldmap={x['id']:x for x in old['liberties']};authmap={x['id']:x for x in auth['liberties']};mergedmap={x['id']:x for x in merged['liberties']}
changed=[k for k in set(oldmap)|set(mergedmap) if oldmap.get(k)!=mergedmap.get(k)]
assert changed and all(mergedmap[k]==authmap[k] and 'green_tree' in json.dumps(mergedmap[k]) for k in changed),changed
assert {k:v for k,v in oldmap.items() if k not in changed}=={k:v for k,v in mergedmap.items() if k not in changed}
assert merged['names']==old['names']
result['liberties']={'only_Green_Tree_rows_changed':changed,'all_other_current_rows_and_names_exact':True,'rows':len(mergedmap)}
# Accepted GT-specific source/reader contract, renderer UI/door paths, and images are unchanged by peers.
paths=['data/structures/green_tree_tavern.json','data/sidecars/1835/green_tree_tavern.json','data/reference_views/green_tree_tavern/andreas_1838.match.json']
for path in paths:assert read(tree,path)==read(head,path)
oldsign=read(head,'data/signage/town_business_signboards.json');newsign=read(tree,'data/signage/town_business_signboards.json')
assert not any(x.get('structure_id')=='green_tree_tavern' for x in newsign['signs'])
assert [x for x in oldsign['refused'] if x.get('structure_id')=='green_tree_tavern']==[x for x in newsign['refused'] if x.get('structure_id')=='green_tree_tavern']
assert read(head,'data/frontage/green_tree_frontage.json')==read(tree,'data/frontage/green_tree_frontage.json')
result['GT_signage']={'town_board_absent_both':True,'dedicated_corner_post_refusal_and_frontage_exact':True,'new_front_wall_reader_refuses_gable_front':True}
result['scope']='Exact targeted data and all current foreign registry/liberty rows retained. Background tree canopy legitimately changes; no whole-frame identity, 1904 clipped-core plant correctness, complete original ticket, full screenshot prose, all wheel contact or through-door claim.'
(p/'COMPOSITE-REGISTRY-SEMANTICS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
