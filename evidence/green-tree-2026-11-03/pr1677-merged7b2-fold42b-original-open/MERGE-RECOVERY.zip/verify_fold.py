from pathlib import Path
import subprocess,json,base64,hashlib
p=Path(__file__).parent;fold='42b9c601d51d8a93cde2706e1773f0bd00fadfbe';merge='7b2e956d38c7a35d2b8964cff4f6f7163f3e8665'
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path]))
commit=api('git/commits/'+fold);assert [x['sha'] for x in commit['parents']]==[merge];assert 'changelog: fold entry files' in commit['message']
diff=api('compare/'+merge+'...'+fold);assert diff['ahead_by']==1 and diff['behind_by']==0
changed={x['filename']:x for x in diff['files']};allowed={'chicago/4d/changelog.d/T-2376.json','chicago/4d/renderers/web/js/changelog.js','chicago/4d/data/liberties.json','chicago/4d/docs/measurements/source_use_coverage.md'};assert set(changed)==allowed,set(changed);assert changed['chicago/4d/changelog.d/T-2376.json']['status']=='removed'
rows=[]
for path in ['chicago/4d/data/liberties.json','chicago/4d/docs/measurements/source_use_coverage.md']:
 expected=(p/'owner-generated'/path).read_bytes();oid=hashlib.sha1(b'blob '+str(len(expected)).encode()+b'\0'+expected).hexdigest();assert changed[path]['sha']==oid;actual=base64.b64decode(api('git/blobs/'+oid)['content']);assert actual==expected
 rows.append({'path':path,'actual_blob':oid,'bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest(),'actual_server_bytes_exact_native_owner_output':True})
 if path.endswith('liberties.json'):doc=json.loads(actual);assert doc['count']==len(doc['liberties'])==981
 else:assert b'| liberties (structured citations) | 981 | 0 | 0 |' in actual
run=api('actions/runs/41736976965');assert run['head_sha']==merge and run['status']=='completed' and run['conclusion']=='success',('fold_run_not_closed_yet',run['status'],run['conclusion'])
jobs=api('actions/runs/41736976965/jobs');assert all(x['conclusion']=='success' for x in jobs['jobs']);(p/'FOLD-JOBS.json').write_text(json.dumps(jobs,indent=2)+'\n')
log=subprocess.check_output(['gh','run','view','41736976965','--repo','kevinrhaas/chicago','--log']);(p/'ACTUAL-FOLD-JOB.log').write_bytes(log)
out={'merge':merge,'actual_fold':fold,'fold_parent_exact_merge':True,'only_expected_four_fold_paths':sorted(changed),'native_current_owners_exact_server_outputs':rows,'actual_liberties_count_and_rows':981,'actual_source_use_count':981,'actual_workflow_run':run,'workflow_native_checks':'compile_liberties.py --check and compile_source_use.py --check inside successful folding job','required_postmerge_protocol_complete':True};(p/'POSTMERGE-FOLD-VERIFIED.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'fold':fold,'count':981,'owners_exact_actual':True,'run':'41736976965 SUCCESS'}),flush=True)
