from pathlib import Path
import json,hashlib,re,subprocess,datetime,os
R=Path('/workspace/chicago-bridge-increment-20261102');N=Path(__file__).parent;U=Path('/tmp/combined-gt-wolf-both-actual-20261103');H=Path('/tmp/combined-gt-wolf-probe-20261103');PF=Path('/tmp/combined-gt-wolf-plan-20261103.json');HEAD='ebf7befa1afba05947578a5ee08e0cbc8655d98a';TREE='9408f2014cb52da1d28a687cb42198d3f2b64602';sha=lambda b:hashlib.sha256(b).hexdigest()
assert not(N/'FINAL-CLOSURE.json').exists();plan=json.loads(PF.read_bytes());ui=json.loads((U/'RESULT.json').read_bytes());native=json.loads((N/'RESULT.json').read_bytes());assert plan['expected_head']==ui['head']==native['head']==HEAD and ui['status']=='FOCUSED_PUBLISHED_COMBINED_GT_WOLF_BOTH_PASS'and native['status']=='NATIVE_PUBLISHED_CARD_PART3_BOTH_PASS';assert all(ui['closure'][k]for k in ['metadata_unchanged','selected_source_and_published_inputs_unchanged','plan_unchanged','helpers_unchanged'])
reviews=[]
for v,label in [('desktop','DESKTOP'),('mobile','MOBILE')]:
 f=Path('/workspace/combined-pr1652-checkpoint-20261103')/f'ROOT-{label}-DIRECT-REVIEW.json';d=json.loads(f.read_bytes());assert d['head']==HEAD and d['directly_viewed']and d['verdict']=='PASS within incremental scope'
 for name,digest in d['files'].items():assert sha((U/v/name).read_bytes())==digest
 reviews.append({'path':str(f),'sha256':sha(f.read_bytes()),'verdict':d['verdict']})
counts=[]
for group in ui['steps']:
 q=group['reaper'];assert group['exit']==q['command_exit']==0 and q['all_children_reaped']and not q['leftover_cleanup']and q['interrupted_signal']is None
for row in native['rows']:
 q=row['reaper'];assert row['exit']==q['command_exit']==0 and q['all_children_reaped']and not q['leftover_cleanup']and q['interrupted_signal']is None
 text=re.sub(r'\x1b\[[0-9;]*m','',Path(row['log']).read_text(errors='replace'));passed=len(re.findall(r'^\s*pass\s+',text,re.M|re.I));failed=len(re.findall(r'^\s*fail\s+',text,re.M|re.I));assert passed==107 and failed==0 and'SMOKE PASS'in text;counts.append({'viewport':row['viewport'],'passed':passed,'failed':failed,'seconds':row['seconds']})
assert {x['viewport']for x in counts}=={'desktop','mobile'}
post=N/'POST-NATIVE-PLAN.json';subprocess.run(['python3',str(H/'run.py'),'--prepare',str(post),'--frozen-head',HEAD,'--camera',plan['gt_reference_camera_name'],'--collision-reaper',plan['collision_reaper'],'--collision-log',plan['collision_log']],check=True)
after=json.loads(post.read_bytes())
for key in set(plan)|set(after):
 if key in ['root_approved','source_check_parts_and_publish_closed']:continue
 assert plan[key]==after[key],key
before=json.loads((N/'BEFORE-NATIVE-PUBMAP.json').read_bytes());rows=[]
for f in sorted((R/'site/4d').rglob('*')):
 if not f.is_file():continue
 h=hashlib.sha256()
 with f.open('rb')as inp:
  for b in iter(lambda:inp.read(1048576),b''):h.update(b)
 rows.append({'path':f.relative_to(R/'site/4d').as_posix(),'bytes':f.stat().st_size,'sha256':h.hexdigest()})
assert rows==before['members'];digest=sha((json.dumps(rows,sort_keys=True,separators=(',',':'))+'\n').encode());assert digest==before['map_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD and subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip()==TREE;assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=normal'],cwd=R)
r={'status':'FRESH_COMBINED_GT_WOLF_CUSTOM_AND_NATIVE3_ALL_READERS_CLOSED_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':HEAD,'tree':TREE,'native_counts':counts,'all_custom_and_native_reapers_closed_zero_leftovers':True,'root_all_six_direct_reviews':reviews,'selected_bindings':len(plan['input_bindings']),'all_selected_source_published_inputs_exact':True,'all_Git_metadata_exact':True,'helpers_plan_reaper_exact':True,'full_published_members':len(rows),'full_published_map_sha256':digest,'all_full_published_bytes_exact_before_after_native3':True,'fullmap_baseline_position':'After customBOTH closed, before officialnative3; customUI separately guarded all625selectedinputs/fullGitmetadata','R_source_clean':True,'no_further_R_reads_after_returning_lease':True,'scope':'Fresh defaultvisitor1835 world, actualWolf7/held1+links6/currentNewberryfullcredit and curatedGreenTreeexterior atbothviewports; separatefreshofficialnativeStage3both107/0. PartialT2376/T2386 only, no fullpicture/doortraversal/Wolfbodyframing/originalticketcompletion claim.'};(N/'FINAL-CLOSURE.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
