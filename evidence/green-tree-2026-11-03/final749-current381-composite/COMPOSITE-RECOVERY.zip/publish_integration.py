from pathlib import Path
import base64,datetime,hashlib,json,re,subprocess
p=Path(__file__).parent;n=Path('/tmp/cobweb-active-20261103');branch='steward/t2376-closed-shoulder-coupled-yard-20261103';old='74992e8fb2811f92e9e90da6f97039d1dd29b60c';dev='38119e64aed68b59e77b37ddd90575196330f642'
def git(*args):return subprocess.check_output(['git','-C',str(n),*args])
def api(path,data=None,method=None):
 cmd=['gh','api','repos/kevinrhaas/chicago/'+path]
 if data is not None:cmd+=['--method',method or 'POST','--input','-']
 r=subprocess.run(cmd,input=None if data is None else json.dumps(data).encode(),capture_output=True)
 if r.returncode:raise RuntimeError((path,r.stderr.decode()[:1200]))
 return json.loads(r.stdout)
assert not git('diff','--name-only').strip()
head=git('rev-parse','HEAD').decode().strip();assert head!=old
raw=git('cat-file','commit',head);headers,message=raw.split(b'\n\n',1);lines=headers.decode().splitlines();parents=[x[7:] for x in lines if x.startswith('parent ')];fields=dict(x.split(' ',1) for x in lines if not x.startswith('parent '));tree=fields['tree'];assert parents==[old,dev]
assert api('git/ref/heads/'+branch)['object']['sha']==old,'public head moved; no overwrite'
def ident(s):
 m=re.fullmatch(r'(.*) <([^<>]+)> (\d+) ([+-])(\d{2})(\d{2})',s);assert m
 offset=(int(m[5])*60+int(m[6]))*(1 if m[4]=='+' else -1)
 return {'name':m[1],'email':m[2],'date':datetime.datetime.fromtimestamp(int(m[3]),datetime.timezone(datetime.timedelta(minutes=offset))).isoformat()}
paths=git('diff','--name-only',dev,head).decode().splitlines();entries=[];proof=[]
for path in paths:
 body=git('show',head+':'+path);oid=git('rev-parse',head+':'+path).decode().strip();assert hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==oid
 r=api('git/blobs',{'encoding':'base64','content':base64.b64encode(body).decode()});assert r['sha']==oid
 assert base64.b64decode(api('git/blobs/'+oid)['content'])==body
 entries.append({'path':path,'mode':'100644','type':'blob','sha':oid});proof.append({'path':path,'oid':oid,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
server_tree=api('git/trees',{'base_tree':git('rev-parse',dev+'^{tree}').decode().strip(),'tree':entries});assert server_tree['sha']==tree
commit=api('git/commits',{'tree':tree,'parents':parents,'message':message.decode(),'author':ident(fields['author']),'committer':ident(fields['committer'])});assert commit['sha']==head
ref=api('git/refs/heads/'+branch,{'sha':head,'force':False},'PATCH');assert ref['object']['sha']==head
assert api('git/ref/heads/'+branch)['object']['sha']==head
out={'head':head,'tree':tree,'parents':parents,'branch':branch,'normal_fast_forward':True,'all_native_commit_tree_and_blob_readbacks_exact':True,'no_dev_main_ref_write':True,'paths':proof}
(p/'INTEGRATION381-PUBLIC.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'head':head,'tree':tree,'normal_public_source_FF':True}),flush=True)
