from pathlib import Path
import json,subprocess,os,time
p=Path(__file__).parent;n=Path('/tmp/cobweb-active-20261103');a=n/'chicago/4d';e=os.environ.copy();e.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def git(*args):return subprocess.check_output(['git','-C',str(n),*args],env=e)
proof=json.loads((p/'final-owners/CONTROLLER-REAPER.json').read_bytes());assert proof['command_exit']==0 and proof['all_children_reaped'] and not proof['leftover_cleanup']
assert not git('diff','--name-only').strip();assert git('write-tree').decode().strip()=='42000ef3652d5a3a4f32ae8eedd3dcea55c98c82'
assert git('rev-parse','HEAD').decode().strip()=='74992e8fb2811f92e9e90da6f97039d1dd29b60c';assert git('rev-parse','MERGE_HEAD').decode().strip()=='38119e64aed68b59e77b37ddd90575196330f642'
with (p/'NATIVE-FINAL-COMMIT.log').open('xb') as log:
 r=subprocess.run(['setsid','--fork','--wait','python','/workspace/shared/run-with-reaping.py',str(p/'NATIVE-FINAL-COMMIT-REAPER.json'),'--','timeout','--signal=TERM','--kill-after=15s','600s','git','-C',str(n),'commit','-m','Merge current dev into T-2376 closed shoulder; regenerate liberty counts'],env=e,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
head=git('rev-parse','HEAD').decode().strip();parents=git('show','-s','--format=%P','HEAD').decode().split();assert parents==['74992e8fb2811f92e9e90da6f97039d1dd29b60c','38119e64aed68b59e77b37ddd90575196330f642'];assert not git('status','--porcelain','--untracked-files=no')
rows=[]
for tag,cmd in [('pr-changelog',['node','tools/check-changelog-entry.mjs',parents[1],head]),('pr-ids',['node','tools/resolve_id_collisions.mjs','--check','--base',parents[1]])]:
 with (p/(tag+'.log')).open('xb') as log:r=subprocess.run(['setsid','--fork','--wait','python','/workspace/shared/run-with-reaping.py',str(p/(tag+'-REAPER.json')),'--','timeout','--signal=TERM','--kill-after=15s','600s',*cmd],cwd=a,env=e,stdout=log,stderr=subprocess.STDOUT)
 proof=json.loads((p/(tag+'-REAPER.json')).read_bytes());assert r.returncode==proof['command_exit']==0 and proof['all_children_reaped'] and not proof['leftover_cleanup'];rows.append({'command':cmd,'reaper':proof})
(p/'INTEGRATION381-NATIVE-COMMIT.json').write_text(json.dumps({'head':head,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'parents':parents,'pr_questions':rows,'source_clean':True,'all10_current_owners_passed':True,'all_accepted_GT_feature_blobs_unchanged':True,'two_derived_count_repairs_only_beyond_calibrated_composite':True},indent=2)+'\n');print(head,flush=True)
