from pathlib import Path
import os,subprocess,json,hashlib,zlib,shutil
p=Path(__file__).parent;n=Path('/tmp/cobweb-active-20261103');e=os.environ.copy();e.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');head='74992e8fb2811f92e9e90da6f97039d1dd29b60c';dev='38119e64aed68b59e77b37ddd90575196330f642';tree='4c7ef6211cb302fd15f96019d399d055521c1cf9'
def git(*args):return subprocess.check_output(['git','-C',str(n),*args],env=e,stderr=subprocess.STDOUT)
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain','--untracked-files=no')
alt=n/'.git/objects/info/alternates';old=alt.read_text();(p/'N-ALTERNATES-BEFORE').write_text(old)
cache=[str(Path('/tmp')/x/'objects.git/objects') for x in ['gt-current500-composite-cache-20261103','gt-801-fold-composite-cache-20261103','gt-381-k12-composite-cache-20261103']]
alt.write_text(old+''.join(x+'\n' for x in cache if x not in old.splitlines()))
# Only newly produced synthetic trees/blobs, never touch existing packed objects.
imported=[]
for x in (p/'default.git/objects').glob('[0-9a-f][0-9a-f]/*'):
 if not x.is_file() or len(x.name)!=38:continue
 oid=x.parent.name+x.name
 r=subprocess.run(['git','-C',str(n),'cat-file','-e',oid],env=e,capture_output=True)
 if not r.returncode:continue
 raw=zlib.decompress(x.read_bytes());assert hashlib.sha1(raw).hexdigest()==oid
 dst=n/'.git/objects'/x.parent.name/x.name;dst.parent.mkdir(exist_ok=True);assert not dst.exists();shutil.copyfile(x,dst);assert git('cat-file','-t',oid).strip() in [b'tree',b'blob'];imported.append(oid)
# Native merge establishes exact two-parent metadata; calibrated default tree supersedes custom-generated ours products.
r=subprocess.run(['git','-C',str(n),'merge','--no-ff','--no-commit',dev],env=e,capture_output=True);(p/'NATIVE-MERGE.log').write_bytes(r.stdout+r.stderr)
assert (n/'.git/MERGE_HEAD').read_text().strip()==dev
assert r.returncode in [0,1]
git('read-tree','--reset','-u',tree)
for path in ['chicago/4d/data/liberties.json','chicago/4d/docs/measurements/source_use_coverage.md']:
 (n/path).write_bytes((p/'owner-generated'/path).read_bytes());git('add','--',path)
assert git('rev-parse','MERGE_HEAD').decode().strip()==dev
newtree=git('write-tree').decode().strip();assert newtree!=tree
(p/'INTEGRATION381-PRECOMMIT.json').write_text(json.dumps({'head':head,'dev':dev,'defaulttree':tree,'owner_corrected_tree':newtree,'imported_only_new_loose_objects':imported,'native_merge_exit':r.returncode,'two_derived_corrections':['liberties count980→981','source_use liberties count980→981']},indent=2)+'\n')
print('Native normal merge staged',newtree)
