from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
n = Path('/tmp/cobweb-active-20261103')
a = n/'chicago/4d'
env = os.environ.copy()
for key in ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES']:
    env.pop(key, None)
env.update(GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
commands = [
    ['python', 'tools/compile_liberties.py'],
    ['python', 'tools/compile_jaunts.py'],
    ['python', 'tools/compile_pictures.py'],
    ['python', 'tools/compile_scene.py', '--scene', '1835'],
    ['python', 'tools/compile_source_use.py'],
    ['python', 'tools/grade_structures.py', '--check'],
    ['node', 'tools/changelog-entries.mjs', '--check'],
    ['node', 'tools/check-changelog.mjs'],
    ['python', 'tools/replace_invented_residents.py', '--self-test'],
    ['python', 'tools/validate.py', '--all'],
]
rows = []
for index, command in enumerate(commands, 1):
    tag = 'integration381-owner'+str(index)
    started = time.monotonic()
    with (p/(tag+'.log')).open('xb') as stream:
        result = subprocess.run(['setsid', '--fork', '--wait', 'python', '/workspace/shared/run-with-reaping.py', str(p/(tag+'-REAPER.json')), '--', 'timeout', '--signal=TERM', '--kill-after=15s', '600s', 'nice', '-n', '19', 'taskset', '-c', '2', *command], cwd=a, env=env, stdout=stream, stderr=subprocess.STDOUT)
    proof = json.loads((p/(tag+'-REAPER.json')).read_bytes())
    assert result.returncode == proof['command_exit'] == 0 and proof['all_children_reaped'] and not proof['leftover_cleanup'], (tag, command, result.returncode)
    rows.append({'command': command, 'seconds': time.monotonic()-started, 'reaper': proof})
    print(json.dumps({'check': tag, 'pass': True, 'seconds': rows[-1]['seconds']}), flush=True)
(p/'INTEGRATION381-OWNERS-PASS.json').write_text(json.dumps(rows, indent=2)+'\n')

assert not subprocess.check_output(['git','-C',str(n),'diff','--name-only'],env=env).strip(), 'owner postimages changed again'
print('All10current381 owners closed; staged tree unchanged',flush=True)
