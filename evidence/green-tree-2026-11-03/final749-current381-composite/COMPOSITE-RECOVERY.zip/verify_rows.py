from pathlib import Path
import os,subprocess,json
p=Path(__file__).parent;n='/tmp/cobweb-active-20261103';e=os.environ.copy();e.update(GIT_OBJECT_DIRECTORY=str(p/'default.git/objects'),GIT_NO_LAZY_FETCH='1')
dev='38119e64aed68b59e77b37ddd90575196330f642';head='74992e8fb2811f92e9e90da6f97039d1dd29b60c';tree='4c7ef6211cb302fd15f96019d399d055521c1cf9'
def read(ref,path):return json.loads(subprocess.check_output(['git','-C',n,'show',ref+':chicago/4d/'+path],env=e))
result={}
for path,key in [('assets/manifest.json','assets'),('assets/manifest.web.json','masters')]:
 old=read(dev,path);auth=read(head,path);merged=read(tree,path);own='green_tree_tavern__frame_1833.glb'
 assert merged[key][own]==auth[key][own]
 assert {k:v for k,v in merged[key].items() if k!=own}=={k:v for k,v in old[key].items() if k!=own}
 assert {k:v for k,v in merged.items() if k!=key}=={k:v for k,v in old.items() if k!=key}
 result[path]={'own_exact_accepted_head':True,'all_other_rows_and_metadata_exact_current_dev':True,'rows':len(merged[key])}
old=read(dev,'data/liberties.json');auth=read(head,'data/liberties.json');merged=read(tree,'data/liberties.json')
oldmap={x['id']:x for x in old['liberties']};authmap={x['id']:x for x in auth['liberties']};mergedmap={x['id']:x for x in merged['liberties']}
changed=[k for k in set(oldmap)|set(mergedmap) if oldmap.get(k)!=mergedmap.get(k)]
assert changed and all(mergedmap[k]==authmap[k] and 'green_tree' in json.dumps(mergedmap[k]) for k in changed),changed
assert {k:v for k,v in oldmap.items() if k not in changed}=={k:v for k,v in mergedmap.items() if k not in changed}
assert merged['names']==old['names']
result['liberties']={'only_Green_Tree_rows_changed':changed,'all_other_current_rows_and_names_exact':True,'rows':len(mergedmap)}
# Accepted GT-specific source/reader contract, renderer UI/door paths, and images are unchanged by peers.
paths=['data/structures/green_tree_tavern.json','data/sidecars/1835/green_tree_tavern.json','data/reference_views/green_tree_tavern/andreas_1838.match.json']
for path in paths:assert read(tree,path)==read(head,path)
result['scope']='Exact targeted data and all current foreign registry/liberty rows retained. Background tree canopy legitimately changes; no whole-frame identity, 1904 clipped-core plant correctness, complete original ticket, full screenshot prose, all wheel contact or through-door claim.'
(p/'COMPOSITE-REGISTRY-SEMANTICS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
