from pathlib import Path
import os, subprocess, json, hashlib, time, sys
p=Path(__file__).parent;n=Path('/tmp/cobweb-active-20261103');a=n/'chicago/4d';candidate='4c7ef6211cb302fd15f96019d399d055521c1cf9';head='74992e8fb2811f92e9e90da6f97039d1dd29b60c';dev='38119e64aed68b59e77b37ddd90575196330f642'
env=os.environ.copy()
for k in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_ALTERNATE_OBJECT_DIRECTORIES']:env.pop(k,None)
env.update(GIT_OBJECT_DIRECTORY=str(p/'default.git/objects'),GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
def git(*args):return subprocess.check_output(['git','-C',str(n),*args],env=env)
assert git('rev-parse','HEAD').decode().strip()==head
assert not git('status','--porcelain','--untracked-files=no')
index=(n/'.git/index').read_bytes(); istat=(n/'.git/index').stat(); meta={str(x.relative_to(n/'.git')):x.read_bytes() for x in [n/'.git/HEAD',n/'.git/config',*(n/'.git/refs').rglob('*')] if x.is_file()}
(p/'ORIGINAL-INDEX').write_bytes(index)
owned=json.loads(Path('/tmp/gt-source4-recovery-20261103/AUTHORED-COMMIT.json').read_bytes())['paths']
shared={'chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json','chicago/4d/data/liberties.json','chicago/4d/docs/LIBERTIES.md','chicago/4d/docs/measurements/source_use_coverage.md','chicago/4d/docs/ROADMAP.md','chicago/4d/docs/STATUS.md'}
exact={x:git('rev-parse',head+':'+x).decode().strip() for x in owned if x not in shared}
for x,oid in exact.items():assert git('rev-parse',candidate+':'+x).decode().strip()==oid,x
rows=[];failure=None
try:
 git('read-tree','--reset','-u',candidate)
 assert git('write-tree').decode().strip()==candidate
 # All source feature, fixture, protected study and models preserve exact accepted bytes.
 for x,oid in exact.items():assert hashlib.sha1(b'blob '+str((n/x).stat().st_size).encode()+b'\0'+(n/x).read_bytes()).hexdigest()==oid,x
 commands=[['python','tools/compile_liberties.py'],['python','tools/compile_pictures.py'],['python','tools/compile_scene.py','--scene','1835'],['python','tools/compile_jaunts.py'],['python','tools/compile_source_use.py'],['python','tools/grade_structures.py','--check'],['node','tools/changelog-entries.mjs','--check'],['node','tools/check-changelog.mjs'],['python','tools/replace_invented_residents.py','--self-test'],['python','tools/validate.py','--all']]
 for i,cmd in enumerate(commands,1):
  tag='owner'+str(i);t=time.monotonic()
  with (p/(tag+'.log')).open('xb') as log:
   r=subprocess.run(['setsid','--fork','--wait','python','/workspace/shared/run-with-reaping.py',str(p/(tag+'-REAPER.json')),'--','timeout','--signal=TERM','--kill-after=15s','600s','nice','-n','19','taskset','-c','2',*cmd],cwd=a,env=env,stdout=log,stderr=subprocess.STDOUT)
  proof=json.loads((p/(tag+'-REAPER.json')).read_bytes()); row={'command':cmd,'seconds':time.monotonic()-t,'exit':r.returncode,'reaper':proof};rows.append(row)
  print(json.dumps(row),flush=True)
  assert r.returncode==proof['command_exit']==0 and proof['all_children_reaped'] and not proof['leftover_cleanup'],tag
 changed=git('diff','--name-only').decode().splitlines();(p/'GENERATED-POSTIMAGE-CHANGES.json').write_text(json.dumps(changed,indent=2)+'\n')
 assert not changed,changed
 assert git('write-tree').decode().strip()==candidate
 for x,oid in exact.items():assert git('hash-object','--',x).decode().strip()==oid,x
 sys.path.insert(0,str(a/'generators'));import mesh_inputs
 record=json.loads((a/'data/structures/green_tree_tavern.json').read_bytes());assert mesh_inputs.structure_inputs_sha(record,record['phases'][0])=='80d47de6a30209568a37752835292968162def80d4eff8f2bb0a6eecaf867722'
except BaseException as exc:
 failure=repr(exc);raise
finally:
 # Save any owner-generated deltas for diagnosis before exact restoration.
 changed=git('diff','--name-only').decode().splitlines()
 for x in changed:
  dest=p/'owner-generated'/x;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((n/x).read_bytes())
 git('read-tree','--reset','-u',head)
 (n/'.git/index').write_bytes(index);os.utime(n/'.git/index',ns=(istat.st_atime_ns,istat.st_mtime_ns));os.chmod(n/'.git/index',istat.st_mode)
 assert (n/'.git/index').read_bytes()==index
 assert all((n/'.git'/x).read_bytes()==v for x,v in meta.items())
 assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain','--untracked-files=no')
 result={'candidate_tree':candidate,'actual_dev':dev,'qualified_source_head':head,'default_algorithm_calibrated_exact_server_old_tree':True,'owners':rows,'owned_feature_full_blobs_exact':exact,'recipe':'80d47de6a30209568a37752835292968162def80d4eff8f2bb0a6eecaf867722','generated_changes':changed,'failure':failure,'original_index_HEAD_refs_config_restored_exact':True,'no_public_head_or_pub_mutations':True}
 (p/'COMPOSITE-QUALIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
 print('CLOSED '+json.dumps({'pass':failure is None,'owners':len(rows),'source_restored':True}),flush=True)
