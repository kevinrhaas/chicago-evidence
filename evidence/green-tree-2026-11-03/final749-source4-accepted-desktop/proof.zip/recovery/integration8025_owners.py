from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
n = Path('/tmp/cobweb-active-20261103')
a = n/'chicago/4d'
env = os.environ.copy()
for key in ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES']:
    env.pop(key, None)
env.update(GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
commands = [
    ['python', 'tools/compile_pictures.py'],
    ['python', 'tools/compile_scene.py', '--scene', '1835'],
    ['python', 'tools/compile_source_use.py'],
    ['python', 'tools/grade_structures.py', '--check'],
    ['node', 'tools/changelog-entries.mjs', '--check'],
    ['node', 'tools/check-changelog.mjs'],
    ['python', 'tools/replace_invented_residents.py', '--self-test'],
    ['python', 'tools/validate.py', '--all'],
]
rows = []
for index, command in enumerate(commands, 1):
    tag = 'integration8025-owner'+str(index)
    started = time.monotonic()
    with (p/(tag+'.log')).open('xb') as stream:
        result = subprocess.run(['setsid', '--fork', '--wait', 'python', '/workspace/shared/run-with-reaping.py', str(p/(tag+'-REAPER.json')), '--', 'timeout', '--signal=TERM', '--kill-after=15s', '600s', 'nice', '-n', '19', 'taskset', '-c', '0,1,3,4', *command], cwd=a, env=env, stdout=stream, stderr=subprocess.STDOUT)
    proof = json.loads((p/(tag+'-REAPER.json')).read_bytes())
    assert result.returncode == proof['command_exit'] == 0 and proof['all_children_reaped'] and not proof['leftover_cleanup'], (tag, command, result.returncode)
    rows.append({'command': command, 'seconds': time.monotonic()-started, 'reaper': proof})
    print(json.dumps({'check': tag, 'pass': True, 'seconds': rows[-1]['seconds']}), flush=True)
(p/'INTEGRATION8025-OWNERS-PASS.json').write_text(json.dumps(rows, indent=2)+'\n')
frozen = json.loads((p/'EXACT-STAGING-V3-21.json').read_bytes())
allowed = {'chicago/4d/docs/ROADMAP.md', 'chicago/4d/docs/STATUS.md', 'chicago/4d/docs/measurements/source_use_coverage.md'}
for row in frozen['rows']:
    if row['path'] not in allowed:
        assert hashlib.sha256((n/row['path']).read_bytes()).hexdigest() == row['sha256'], row['path']
sys_path = str(a/'generators')
import sys
sys.path.insert(0, sys_path)
import mesh_inputs
record = json.loads((a/'data/structures/green_tree_tavern.json').read_bytes())
assert mesh_inputs.structure_inputs_sha(record, record['phases'][0]) == '80d47de6a30209568a37752835292968162def80d4eff8f2bb0a6eecaf867722'
print('All8currentintegrationowners/all-assets/changelog passed;18ownedpostimages and full80d47recipe exact', flush=True)
