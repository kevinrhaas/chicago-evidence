from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile,datetime

P=Path('/tmp/gt-source4-recovery-20261103')
Q=Path('/tmp/green-tree-final-qa-prep-20261103')
N=Path('/tmp/cobweb-active-20261103')
O=Path('/tmp/gt-749-source4-accepted-desktop-20261103')
assert not O.exists()
F=O/'payload';F.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0'}
H='74992e8fb2811f92e9e90da6f97039d1dd29b60c'
assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD'],env=env).decode().strip()==H
assert not subprocess.check_output(['git','-C',str(N),'status','--porcelain','--untracked-files=normal'],env=env)

def copy(src,rel):
    target=F/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(Path(src).read_bytes())

parts=[('PART1','part1.log'),('PART2-FIXTURE-LOCAL-RETRY','part2-fixture-local-retry.log'),('PART3-CANONICAL-FIXTURE-RETRY','part3-canonical-fixture-retry.log'),('PART4-PROTECTED-TRANSITION-RETRY','part4-protected-transition-retry.log')]
rows=[]
for label,log in parts:
    d=json.loads((P/(label+'-RESULT.json')).read_bytes());r=json.loads((P/(label+'-REAPER.json')).read_bytes())
    assert d['status']=='NATIVE_SOURCE_PART_PASS' and d['native_exit']==r['command_exit']==0
    assert r['all_children_reaped'] and not r['leftover_cleanup'] and r['interrupted_signal'] is None
    assert sha((P/log).read_bytes())==d['log_sha256']
    rows.append({'part':d['part'],'seconds':d['seconds'],'last_lines':d['last_lines'],'reaper':r})
    for name in [label+'-RESULT.json',label+'-REAPER.json',log]:copy(P/name,'source4/'+name)
for path in P.iterdir():
    if path.is_file() and path.suffix in ['.json','.log','.diff','.py','.md','.txt']:
        copy(path,'recovery/'+path.name)
for path in (P/'fixture-local-git-bin').iterdir():
    if path.is_file():copy(path,'recovery/fixture-local-git-bin/'+path.name)

auth=json.loads((P/'AUTHORED-COMMIT.json').read_bytes())
for rel in auth['paths']:
    b=subprocess.check_output(['git','-C',str(N),'show',H+':'+rel],env=env)
    target=F/'source-postimages'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
for name in ['PLAN.json','BEFORE-PUBMAP.json','NATIVE-READER-EXPECTATION.json','WRITER-FREEZE.json','DIRECTION-ONLY-CLOSED-REFERENCE.json','run.py','probe.mjs','README.md']:
    copy(Q/name,'qa-plan/'+name)
for path in (Q/'custom/desktop').iterdir():
    if path.is_file():copy(path,'actual-ui/desktop/'+path.name)
copy(Q/'custom/desktop-REAPER.json','actual-ui/desktop-REAPER.json')
result=json.loads((Q/'custom/desktop/RESULT.json').read_bytes())
reaper=json.loads((Q/'custom/desktop-REAPER.json').read_bytes())
assert result['status']=='ACTUAL_FINAL_GREEN_TREE_PASS' and result['head']==H
assert not any(result[k]for k in ['errors','network','consoleErrors','serverErrors'])
assert reaper['command_exit']==0 and reaper['all_children_reaped'] and not reaper['leftover_cleanup']
review=Path('/workspace/green-tree-final-749-root-review-20261103/ROOT-DESKTOP-DIRECT-REVIEW.json')
copy(review,'actual-ui/desktop/ROOT-DIRECT-REVIEW.json')
summary={'status':'SOURCE4_FINAL749_AND_ACTUAL_DESKTOP_ACCEPTED_PHONE_NATIVE107_PENDING','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':H,'tree':'a91253792489ca4e1c9528243caed9b91eb08cee','authored_head':auth['head'],'pr':1677,'original_T2376':'PARTIAL_CLAIMED_DIFFERS_NOT_DONE','qualified_source_parts':rows,'chronology':{'all19_application_postimages_exact_across_all_parts':True,'parts1_2_predate_only_existing_test_fixture_adaptation':True,'parts1_2_3_predate_only_conscious_wagon_protected_snapshot_transition':True,'final_hosted_whole_gate_still_required':True},'desktop':{'status':result['status'],'native_wall_ms':result['wall_ms'],'reaper':reaper,'root_review_sha256':sha(review.read_bytes()),'errors':[]},'phone':'PENDING','official_native107_both':'PENDING','hosted_gate41727276542':'PENDING_LAST_OBSERVED','merge':'NOT_MERGED','public_delivery':'NOT_CLAIMED','no_source_Git_publication_mutation_during_checkpoint':True}
(F/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
(F/'RECOVERY.md').write_text('''# Green Tree: all source parts, PR1677 and accepted current desktop\n\nThis is a CLOSED partial qualification checkpoint, not a phone, native107-both, hosted-gate, merge, deployment or original-ticket completion claim.\n\nActual public source is74992e8fb2811f92e9e90da6f97039d1dd29b60c, a normal merge of authored3ce297e2 (21paths, parent92bee) and actual dev8025bc1. Draft PR1677 is open. Actual current owners, validate --all, PR-only questions, fresh publish and correct published contract pass. All exact21 source postimages are preserved.\n\nFour source parts passed in457.254/336.181/241.131/318.610seconds with actual per-part footers287/286/287/286, proper native exit0 and all children reaped. Do not add their repeated setup work into a new unique-test count. All19 application postimages were unchanged across every part. Parts1/2 preceded only the precise existing open-bay fixture adaptation; parts1/2/3 preceded only the consciously documented protected wagon snapshot transition. Original interrupted/failed attempts remain separate in recovery; they are not passing qualifications. Whole hosted current-head gate remains required before dev merge.\n\nThe protected transition removes only Green Tree's competing covered wagon when its shed is suppressed by the chosen closed shoulder. All80 retained wagon bodies/order/dimensions and all67 old refusals stay exact; one explicit closed-shoulder refusal is added. The previous transition chain and every other protected export/license/geometry/LOD guard are preserved. No asset recipe was manually stamped and no assertion was weakened. The full old and new logical packets and hashes are included.\n\nActual published desktop1280x800 passed after the cloud reconnect: the bounded protected controller and real subreapers survived; no rerender/relabel was needed. Desktop probe538.520seconds; complete closed leg549.221seconds with five children reaped, no cleanup and zero page/console/network/server errors. Root directly reviewed all six actual shots and accepted the bounded new shoulder/yard/card/Record/grounded outside-entry scope. Tiny/reed-obscured wagon pixels do not prove every wheel contact; full Trowbridge prose was not all visible in one shot, while exact nativeReader text and scrollability are separate evidence. No through-door, perfect roof match, historical camera or street-arrival body completeness is accepted.\n\nPHONE/custom and official native107 both viewports are still pending here. The exclusive live controller is /tmp/green-tree-final-qa-prep-20261103/run.py, protected by setsid and a2500-second outer reaper, with unchanged600-second native leg limits. Do not restart it or edit source/Git/publication/tickets/helpers during its freeze. Inspect actual FINAL-CLOSURE and native receipts before resuming any leg after another reconnect. Root final acceptance remains required for the phone.\n\nOriginalT2376 stays partial/DIFFERS and must remain open after this increment merges. No new picture follow-up or done override. Normal exact-head protected dev merge only after actual final hosted gate passes.\n''')
members=[]
for path in sorted(F.rglob('*')):
    if path.is_file():members.append({'path':path.relative_to(F).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})
manifest={'status':'CLOSED_SOURCE4_AND_ACCEPTED_DESKTOP_ONLY','head':H,'members':members}
(F/'CLOSED-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(O/'proof.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for path in sorted(F.rglob('*')):
        if path.is_file():z.write(path,path.relative_to(F).as_posix())
with zipfile.ZipFile(O/'proof.zip')as z:
    for row in members:assert sha(z.read(row['path']))==row['sha256']
archive={'head':H,'members':len(members)+1,'bytes':(O/'proof.zip').stat().st_size,'sha256':sha((O/'proof.zip').read_bytes()),'manifest_sha256':sha((F/'CLOSED-MANIFEST.json').read_bytes())}
(O/'archive.json').write_text(json.dumps(archive,indent=2)+'\n')
files={'proof.zip':str(O/'proof.zip'),'archive.json':str(O/'archive.json')}
for name in ['RECOVERY.md','SUMMARY.json','CLOSED-MANIFEST.json']:files[name]=str(F/name)
for path in (F/'actual-ui/desktop').iterdir():
    if path.suffix=='.jpg' or path.name in ['RESULT.json','ROOT-DIRECT-REVIEW.json']:files[path.relative_to(F).as_posix()]=str(path)
spec={'prefix':'evidence/green-tree-2026-11-03/final749-source4-accepted-desktop/','message':'Checkpoint Green Tree source quad and accepted exact749 desktop while phone continues','receipt':str(O/'PUBLISHED.json'),'files':files}
(O/'publication.json').write_text(json.dumps(spec))
print(json.dumps(archive))
