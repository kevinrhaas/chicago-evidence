"""Commit only the four-part checked, exact 19-path Green Tree increment."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
n = Path('/tmp/cobweb-active-20261103')
a = n/'chicago/4d'
env = os.environ.copy()
for key in ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES']:
    env.pop(key, None)
env.update(GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
frozen = json.loads((p/'EXACT-STAGING-V3-21.json').read_bytes())

def git(*args):
    return subprocess.check_output(['git', '-C', str(n), *args], env=env)

assert not (p/'AUTHORED-COMMIT.json').exists()
parts = []
for part in range(1, 5):
    result_file = p/('PART2-FIXTURE-LOCAL-RETRY-RESULT.json' if part == 2 else 'PART3-CANONICAL-FIXTURE-RETRY-RESULT.json' if part == 3 else 'PART4-PROTECTED-TRANSITION-RETRY-RESULT.json' if part == 4 else f'PART{part}-RESULT.json')
    row = json.loads(result_file.read_bytes())
    assert row['status'] == 'NATIVE_SOURCE_PART_PASS' and row.get('all_owned_authored_index_and_worktree_postimages_exact', row.get('all19_authored_index_and_worktree_postimages_exact'))
    assert row['reaper']['command_exit'] == 0 and row['reaper']['all_children_reaped'] and not row['reaper']['leftover_cleanup']
    parts.append(row)
assert git('rev-parse', 'HEAD').decode().strip() == frozen['base']
assert not git('diff', '--name-only')
paths = [r['path'] for r in frozen['rows']]
assert sorted(git('diff', '--cached', '--name-only').decode().splitlines()) == sorted(paths)
for row in frozen['rows']:
    assert hashlib.sha256((n/row['path']).read_bytes()).hexdigest() == row['sha256']
    assert git('ls-files', '--stage', '--', row['path']).decode().startswith(row['mode']+' '+row['oid']+' 0\t')
message = "T-2376: Enclose Green Tree's pictured shoulder and retire the competing yard bay"
with (p/'authored-native-commit.log').open('xb') as stream:
    result = subprocess.run(['setsid', '--fork', '--wait', 'python', '/workspace/shared/run-with-reaping.py', str(p/'AUTHORED-COMMIT-REAPER.json'), '--', 'timeout', '--signal=TERM', '--kill-after=15s', '600s', 'git', 'commit', '-m', message], cwd=n, env=env, stdout=stream, stderr=subprocess.STDOUT)
reaper = json.loads((p/'AUTHORED-COMMIT-REAPER.json').read_bytes())
assert result.returncode == reaper['command_exit'] == 0 and reaper['all_children_reaped'] and not reaper['leftover_cleanup']
h = git('rev-parse', 'HEAD').decode().strip()
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
assert git('rev-parse', 'HEAD^').decode().strip() == frozen['base']
assert sorted(git('diff-tree', '--no-commit-id', '--name-only', '-r', h).decode().splitlines()) == sorted(paths)
assert not git('status', '--porcelain', '--untracked-files=normal')
receipt = {'head': h, 'tree': tree, 'parent': frozen['base'], 'branch': git('branch', '--show-current').decode().strip(), 'paths': paths, 'all21_owned_postimages_exact': True, 'first_three_parts_predate_only_part4_protected_snapshot_transition': True, 'first_two_parts_predate_only_part3_test_fixture_change': True, 'all19_application_postimages_unchanged_across_every_qualified_part': True, 'all_four_native_parts_passed_before_commit': True, 'source_part_seconds': [r['seconds'] for r in parts], 'original_unclosed_part1_retained_not_used_as_qualification': True, 'original_T2376': 'PARTIAL_CLAIMED_NO_DONE', 'commit_reaper': reaper}
(p/'AUTHORED-COMMIT.json').write_text(json.dumps(receipt, indent=2)+'\n')
for label, command in [('actual-head-PR-changelog', ['node', 'tools/check-changelog-entry.mjs', frozen['base'], h]), ('actual-head-PR-ids', ['node', 'tools/resolve_id_collisions.mjs', '--check', '--base', frozen['base']])]:
    started = time.monotonic()
    with (p/(label+'.log')).open('xb') as stream:
        check = subprocess.run(['setsid', '--fork', '--wait', 'python', '/workspace/shared/run-with-reaping.py', str(p/(label+'-REAPER.json')), '--', 'timeout', '--signal=TERM', '--kill-after=15s', '600s', 'taskset', '-c', '0,1,3,4', *command], cwd=a, env=env, stdout=stream, stderr=subprocess.STDOUT)
    proof = json.loads((p/(label+'-REAPER.json')).read_bytes())
    assert check.returncode == proof['command_exit'] == 0 and proof['all_children_reaped'] and not proof['leftover_cleanup']
    print(json.dumps({'check': label, 'pass': True, 'seconds': time.monotonic()-started}), flush=True)
(p/'AUTHORED-PR-QUESTIONS-PASS.json').write_text(json.dumps({'head': h, 'tree': tree, 'base': frozen['base'], 'actual_commit_changelog_and_id_questions_passed': True}, indent=2)+'\n')
print(json.dumps({'head': h, 'tree': tree, 'source4': 'PASS', 'PR_questions': 'PASS'}), flush=True)
