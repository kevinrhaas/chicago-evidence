"""Publish the exact checked native commit without walking missing old local history."""
from pathlib import Path
import base64, datetime, hashlib, json, re, subprocess

P = Path(__file__).resolve().parent
R = Path('/tmp/cobweb-active-20261103')
receipt = json.loads((P / 'AUTHORED-COMMIT.json').read_bytes())
HEAD = receipt['head']
TREE = receipt['tree']
BRANCH = 'steward/t2376-closed-shoulder-coupled-yard-20261103'

def git(*args):
    return subprocess.check_output(['git', '-C', str(R), *args])

def api(path, data=None, method=None):
    args = ['gh', 'api', 'repos/kevinrhaas/chicago/' + path]
    if data is not None:
        args += ['--method', method or 'POST', '--input', '-']
    result = subprocess.run(args, input=None if data is None else json.dumps(data).encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError((path, result.stderr.decode()[:1200]))
    return json.loads(result.stdout)

raw = git('cat-file', 'commit', HEAD)
assert hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == HEAD
headers, message = raw.split(b'\n\n', 1)
lines = headers.decode().splitlines()
assert len(lines) == 4
fields = dict(line.split(' ', 1) for line in lines)
assert fields['tree'] == TREE and fields['parent'] == receipt['parent']

def identity(value):
    m = re.fullmatch(r'(.*) <([^<>]+)> (\d+) ([+-])(\d{2})(\d{2})', value)
    assert m
    minutes = (int(m[5]) * 60 + int(m[6])) * (1 if m[4] == '+' else -1)
    date = datetime.datetime.fromtimestamp(int(m[3]), datetime.timezone(datetime.timedelta(minutes=minutes))).isoformat()
    return {'name': m[1], 'email': m[2], 'date': date}

entries = []
blobs = []
for path in receipt['paths']:
    body = git('show', f'{HEAD}:{path}')
    oid = hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    assert git('rev-parse', f'{HEAD}:{path}').decode().strip() == oid
    result = api('git/blobs', {'encoding': 'base64', 'content': base64.b64encode(body).decode()})
    assert result['sha'] == oid
    # Read actual server bytes before any ref is created.
    back = api('git/blobs/' + oid)
    assert base64.b64decode(back['content']) == body
    entries.append({'path': path, 'mode': '100644', 'type': 'blob', 'sha': oid})
    blobs.append({'path': path, 'git_blob': oid, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
    print('Exact server blob', path, flush=True)
base_tree = git('rev-parse', receipt['parent'] + '^{tree}').decode().strip()
tree = api('git/trees', {'base_tree': base_tree, 'tree': entries})
assert tree['sha'] == TREE, ('native tree changed', tree['sha'], TREE)
commit = api('git/commits', {'tree': TREE, 'parents': [receipt['parent']], 'message': message.decode(), 'author': identity(fields['author']), 'committer': identity(fields['committer'])})
assert commit['sha'] == HEAD, ('native commit changed', commit['sha'], HEAD)
ref_path = 'git/ref/heads/' + BRANCH
read = subprocess.run(['gh', 'api', 'repos/kevinrhaas/chicago/' + ref_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if read.returncode == 0:
    assert json.loads(read.stdout)['object']['sha'] == HEAD, 'A different branch already exists; never overwrite it'
    created = False
else:
    assert b'HTTP 404' in read.stderr
    ref = api('git/refs', {'ref': 'refs/heads/' + BRANCH, 'sha': HEAD})
    assert ref['object']['sha'] == HEAD
    created = True
assert api(ref_path)['object']['sha'] == HEAD
result = {'head': HEAD, 'tree': TREE, 'parent': receipt['parent'], 'branch': BRANCH, 'normal_new_source_branch_create': created, 'exact_native_commit_and_tree': True, 'every_blob_server_readback_exact': True, 'blobs': blobs, 'no_force_or_dev_main_ref_write': True, 'reason': 'Publish the exact native checked authored head without walking unrelated incomplete historical objects. No assertion or required PR check is bypassed.'}
(P / 'PUBLIC-PUSH.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'head': HEAD, 'branch': BRANCH, 'all_server_readback': 'PASS'}), flush=True)
