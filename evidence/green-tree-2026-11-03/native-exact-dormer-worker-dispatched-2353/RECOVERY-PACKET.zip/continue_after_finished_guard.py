from pathlib import Path
import json,subprocess,base64,hashlib,os,datetime,concurrent.futures
P=Path(__file__).resolve().parent;A=Path('/tmp/wolf-poster-source-20261103/chicago/4d');T=A/'tickets';AUTHOR='Codex Green Tree dormer native handoff 2026-11-03';PATH='T-2250-2499/T-2376-match-the-green-tree-tavern-to-its-pictures.md'
def api(path):return json.loads(subprocess.check_output(['gh','api',path],timeout=45))
def dump(n,j):(P/n).write_text(json.dumps(j,indent=2)+'\n')
def native(label,args):
 cmd=['python','/workspace/shared/run-with-reaping.py',str(P/(label+'-REAPER.json')),'--','timeout','--signal=TERM','--kill-after=15s','120s','nice','-n','19','taskset','-c','2','node','tools/ticket.mjs',*args]
 with (P/(label+'.log')).open('xb')as f:r=subprocess.run(cmd,cwd=A,stdout=f,stderr=subprocess.STDOUT)
 j=json.loads((P/(label+'-REAPER.json')).read_text());assert r.returncode==j['command_exit']==0 and j['all_children_reaped']and not j['leftover_cleanup'],(label,j)
 return j
before=(P/'T2376-BEFORE-CLAIM.md').read_bytes()
assert json.loads((P/'FINISHED-BRANCH-GUARD-AUDIT.json').read_text())['first_branch_is_exact_reviewed_already_merged_PR1677_head']
native('CLAIM-FINISHED-BRANCH-RETRY',['claim','T-2376','--by',AUTHOR,'--force']);local=T/PATH;claimed=local.read_bytes();(P/'T2376-CLAIMED-BEFORE-NOTE.md').write_bytes(claimed);assert AUTHOR.encode()in claimed and b'\nstate: claimed\n'in claimed;assert claimed.decode().split('---',2)[2]==before.decode().split('---',2)[2]
local.write_bytes(claimed+(P/'HANDOFF-NOTE.md').read_bytes());(P/'T2376-AFTER-NOTE-BEFORE-SYNC.md').write_bytes(local.read_bytes());native('SYNC',['sync','-m','T-2376: add reviewed exact-native small dormer-peak trial handoff'])
r=api('repos/kevinrhaas/chicago-tickets/contents/'+PATH);actual=base64.b64decode(r['content']);assert actual==local.read_bytes();(P/'HANDOFF-SYNC-REMOTE-READBACK.md').write_bytes(actual)
native('RELEASE',['release','T-2376','--why','Reviewed bounded data-only dormer trial native handoff saved; OPEN for authorized exact T2376 worker. No geometry, dispatch or full-original completion claimed by metadata handoff.'])
r=api('repos/kevinrhaas/chicago-tickets/contents/'+PATH);released=base64.b64decode(r['content']);assert b'\nstate: open\n'in released and b'\nclaimed_by: null\n'in released and b'\npr: null\n'in released;assert released.decode().split('---',2)[2].startswith(before.decode().split('---',2)[2]);assert released.count(b'## Exact native-worker small dormer-peak trial handoff')==1;(P/'T2376-RELEASED-REMOTE.md').write_bytes(released)
head=subprocess.check_output(['git','-C',str(T),'rev-parse','HEAD']).decode().strip();assert not subprocess.check_output(['git','-C',str(T),'status','--porcelain','--untracked-files=normal']);dump('HANDOFF-CLOSED.json',{'status':'NATIVE_CLAIM_SYNC_RELEASE_CLOSED','release_commit':head,'ticket_blob':r['sha'],'all_original_body_preserved':True,'dated_handoff_once':True,'source_geometry_unchanged':True,'actual_dispatch':'PENDING'})
print(json.dumps({'status':'HANDOFF_CLOSED','release_commit':head,'ticket_blob':r['sha']}),flush=True)
