from pathlib import Path
import subprocess,os,json,hashlib,shutil
O=Path(__file__).resolve().parent;N=Path('/tmp/cobweb-active-20261103');env={**os.environ,'GIT_NO_LAZY_FETCH':'1'}
def git(*a,**kw):return subprocess.run(['git','-C',str(N),*a],env=env,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kw).stdout
assert git('rev-parse','HEAD').decode().strip()=='92bee8bdb89a900a840bcd94e760bb8f21c757c2'
assert not git('diff','--cached','--name-only'),'Unexpected prior staged work'
paths=git('diff','--name-only','--no-ext-diff').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines();assert len(paths)==19 and len(set(paths))==19
assert all(p.startswith('chicago/4d/')for p in paths)
index=N/git('rev-parse','--git-path','index').decode().strip();shutil.copyfile(index,O/'INDEX-BEFORE-EXACT-STAGING');rows=[]
for p in sorted(paths):
 b=(N/p).read_bytes();oid=git('hash-object','--',p).decode().strip();present=subprocess.run(['git','-C',str(N),'cat-file','-e',oid],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
 if not present:assert git('hash-object','-w','--',p).decode().strip()==oid
 mode='100755'if os.stat(N/p).st_mode&0o111 else'100644';git('update-index','--add','--cacheinfo',mode,oid,p)
 rows.append({'path':p,'mode':mode,'oid':oid,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'object_preexisted':present,'new_object_written_only_when_absent':not present})
r=subprocess.run(['git','-C',str(N),'update-index','--refresh'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert r.returncode==0,(r.stdout+r.stderr).decode();assert not git('diff','--name-only'),'Postimages moved during staging';assert set(git('diff','--cached','--name-only').decode().splitlines())==set(paths)
receipt={'method':'native hash-object WITHOUT-w ->cat-file-e ->hash-object-w ONLY missing ->update-index --cacheinfo ->refresh','base':'92bee8bdb89a900a840bcd94e760bb8f21c757c2','native_broad_git_add':False,'index_before_sha256':hashlib.sha256((O/'INDEX-BEFORE-EXACT-STAGING').read_bytes()).hexdigest(),'index_after_sha256':hashlib.sha256(index.read_bytes()).hexdigest(),'all_worktree_postimages_exact_staged':True,'rows':rows};(O/'EXACT-STAGING.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'paths':len(rows),'new_unique_objects':sum(not r['object_preexisted']for r in rows),'all_postimages_exact_staged':True}))
