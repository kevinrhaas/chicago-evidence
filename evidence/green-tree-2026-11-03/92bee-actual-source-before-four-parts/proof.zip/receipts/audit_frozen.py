from pathlib import Path
import json,hashlib,subprocess,sys,zipfile,io,shutil
O=Path(__file__).resolve().parent;N=Path('/tmp/cobweb-active-20261103');A=N/'chicago/4d';sys.path[:0]=[str(A/'generators'),str(A/'tools')];sys.dont_write_bytecode=True
import mesh_inputs
sha=lambda b:hashlib.sha256(b).hexdigest()
def base(p):return subprocess.check_output(['git','-C',str(N),'show','HEAD:'+p])
def j(p):return json.loads((A/p).read_bytes())
assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD']).decode().strip()=='92bee8bdb89a900a840bcd94e760bb8f21c757c2'
s=j('data/structures/green_tree_tavern.json');old=json.loads(base('chicago/4d/data/structures/green_tree_tavern.json'));assert mesh_inputs.structure_inputs_sha(s,s['phases'][0])=='80d47de6a30209568a37752835292968162def80d4eff8f2bb0a6eecaf867722';assert json.loads(json.dumps(mesh_inputs.structure_inputs_doc(s,s['phases'][0])))==json.loads((O/'CURRENT-CLOSED-MESH-DOCUMENT.json').read_bytes())
clone=json.loads(json.dumps(s));clone['research_note']=old['research_note'];clone['phases'][0]['form']['enclosed_left_annex']['note']=old['phases'][0]['form']['enclosed_left_annex']['note'];clone['phases'][0]['form']['enclosed_left_annex']['value']['shoulder_enclosed']=False;assert clone==old
asset='green_tree_tavern__frame_1833.glb';regs={}
for name,key in [('manifest.json','assets'),('manifest.web.json','masters')]:
 cur=j('assets/'+name);prev=json.loads(base('chicago/4d/assets/'+name));assert set(cur)==set(prev)
 # native WEB schema is a top-level map, detect the existing keyed container.
 if key not in cur:key=next((k for k,v in cur.items()if isinstance(v,dict)and asset in v),None)
 if key is None:
  assert asset in cur;assert {k:v for k,v in cur.items()if k!=asset}=={k:v for k,v in prev.items()if k!=asset}
 else:
  assert {k:v for k,v in cur.items()if k!=key}=={k:v for k,v in prev.items()if k!=key};assert {k:v for k,v in cur[key].items()if k!=asset}=={k:v for k,v in prev[key].items()if k!=asset}
 regs[name]='ALL_FOREIGN_EXACT'
for p in ['assets/manifest.versions.json','data/reference_views/green_tree_tavern/andreas_1838.json','data/enclosures/town_entrance_aprons.json']:
 assert (A/p).read_bytes()==base('chicago/4d/'+p)
for folder,want in [('gltf','0b53a6fe30e23b10b330ddb60d4bb362cbce2e798690104e90f4f304cd9d18b8'),('web','0154cfad5d6512a0d68e74a4f76c0cd5adad540a84844adc1f4a2fdc1d9d51e4')]:assert sha((A/'assets'/folder/asset).read_bytes())==want
side=j('data/sidecars/1835/green_tree_tavern.json');assert [r['id']for r in side['footprint']['additional_polygons']]==['shoulder','connector','boarding_range'];assert side['footprint']['polygon']==json.loads(base('chicago/4d/data/sidecars/1835/green_tree_tavern.json'))['footprint']['polygon']
# Preserve the unrelated generated workbook before restoring only its deterministic
# HEAD bytes when all actual ZIP entry payloads prove identical.
p='chicago/reference/resident-research/final/audit/resident_audit_master.xlsx';raw=(N/p).read_bytes();before=base(p);za=zipfile.ZipFile(io.BytesIO(raw));zb=zipfile.ZipFile(io.BytesIO(before));same=za.namelist()==zb.namelist()and all(za.read(n)==zb.read(n)for n in za.namelist());w={'same_all_zip_entry_payloads':same,'current_sha256':sha(raw),'baseline_sha256':sha(before),'restored':False}
if same and raw!=before:
 (O/'owner_generated_resident_audit_master.xlsx').write_bytes(raw);(N/p).write_bytes(before);w['restored']=True
r={'base':'92bee8bdb89a900a840bcd94e760bb8f21c757c2','current_normalized_recipe':'80d47de6a30209568a37752835292968162def80d4eff8f2bb0a6eecaf867722','all_original_numeric_values_phases_sources_confidences_position_footprint_exact':True,'only_structure_semantic_delta':['shoulder_enclosed=true','annex.note','research_note'],'registries':regs,'version_manifest_camera_and_entrance_aprons_byte_exact':True,'occupied_components':['core','shoulder','connector','boarding_range'],'core_polygon_exact':True,'workbook':w,'owners_tail':'All204sequence steps reached; final Git tree snapshot timed out at600s; not owner-loop closure PASS','full_source4':'NOT_RUN','actual_published_phone_desktop':'NOT_RUN','original_T2376':'CLAIMED_PARTIAL_DIFFERENCES_REMAIN'}
(O/'FROZEN-INPUTS-AUDIT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
