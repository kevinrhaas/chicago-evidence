"""Single, finite external-mirror native qualification. Never import from R."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import sys
import time
import traceback

HOME_PACKET = Path(__file__).resolve().parent
doc = json.loads((HOME_PACKET / 'INPUTS.json').read_text())
app = Path(doc['mirror']).resolve()
assert app == HOME_PACKET / 'source/chicago/4d'
assert not any(p.is_symlink() for p in app.rglob('*'))
assert os.environ['GT_NATIVE_EXTERNAL_READY'] == 'approved-cpu2-finite-native-only'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
started = time.monotonic()
controls = []
unchanged = []


def save(name, value):
    (HOME_PACKET / name).write_text(json.dumps(value, indent=2) + '\n')


def source_guard():
    return [{'source': row['source'], 'expected': row['sha256'],
             'observed': sha(Path(row['source']))}
            for row in doc['source_bindings']
            if sha(Path(row['source'])) != row['sha256']]


try:
    assert not source_guard(), 'Source input changed before qualification'
    sys.path.insert(0, str(app / 'generators'))
    import emit
    import build
    import mesh_inputs
    from common import versions
    for module in (emit, build, mesh_inputs, versions):
        assert module.ROOT.resolve() == app, str(module.__file__)
        assert Path(module.__file__).resolve().is_relative_to(app)
    for row in doc['rows']:
        record_path = HOME_PACKET / row['baseline_record']
        master_path = HOME_PACKET / row['baseline_master']
        assert sha(record_path) == row['record_sha256']
        assert sha(master_path) == row['master_sha256']
        record = json.loads(record_path.read_text())
        phase = next(x for x in record['phases'] if x['id'] == row['phase'])
        destination = HOME_PACKET / 'None-controls' / row['control_asset']
        destination.parent.mkdir(exist_ok=True)
        emit.emit_structure(record, phase, 'frame_tavern', destination,
                            bake=True, ao=False)
        observed = sha(destination)
        actual = observed == row['master_sha256']
        controls.append({'id': row['id'], 'phase': row['phase'],
                         'actual_current_master': row['master_path'],
                         'control': str(destination.relative_to(HOME_PACKET)),
                         'expected_sha256': row['master_sha256'],
                         'observed_sha256': observed, 'byte_exact': actual})
        save('CONTROL-PROGRESS.json', controls)
        assert actual, 'Current default parity failed: ' + row['control_asset']
    assert len(controls) == 25
    # Official CLI implementation, private ROOT and private native registries.
    ids = sorted({row['id'] for row in doc['rows']})
    wrote = HOME_PACKET / 'PRODUCTION-WROTE.txt'
    sys.argv = ['blender', '--', '--only', ','.join(ids),
                '--wrote', str(wrote)]
    production_started = time.monotonic()
    assert build.main() == 0
    production_seconds = time.monotonic() - production_started
    for row in doc['rows']:
        if row['id'] == 'green_tree_tavern' and row['phase'] == 'frame_1833':
            continue
        target = app / row['master_path']
        observed = sha(target)
        unchanged.append({'path': row['master_path'],
                          'expected_sha256': row['master_sha256'],
                          'observed_sha256': observed,
                          'byte_exact': observed == row['master_sha256']})
        assert observed == row['master_sha256'], 'Unselected default changed: ' + str(target)
    assert len(unchanged) == 24
    actual_wrote = wrote.read_text().splitlines()
    assert len(actual_wrote) == 25 and len(set(actual_wrote)) == 25
    selected = []
    for rel in ['assets/gltf/green_tree_tavern__frame_1833.glb']:
        file = app / rel
        selected.append({'path': str(file), 'relative_to_mirror': rel,
                         'sha256': sha(file), 'bytes': file.stat().st_size})
    guard_changes = source_guard()
    assert not guard_changes, 'R inputs moved during external production'
    save('RESULT.json', {
        'status': 'PASS_ACTUAL_IMMUTABLE18AF_GT_ONLY_NATIVE_MODEL_NOT_APP_READY',
        'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'input_snapshot_sha256': sha(HOME_PACKET / 'INPUTS.json'),
        'source_head_at_snapshot': doc['source_head'],
        'mirror': str(app), 'seconds': time.monotonic() - started,
        'production_seconds': production_seconds,
        'all25_current_record_defaults_byte_exact': True, 'controls': controls,
        'all24_unaffected_official_masters_byte_exact': True,
        'unchanged_official': unchanged, 'selected_native_outputs': selected,
        'official_wrote_count': len(actual_wrote),
        'private_registry_sha256': {
            rel: sha(app / rel) for rel in
            ['assets/manifest.json', 'assets/manifest.versions.json']},
        'R_source_input_guard_changes': guard_changes,
        'limits': 'Actual native geometry/default parity only. No WEB, foot/ground, camera, image verdict, app/phone, source gate, publish, ticket, commit, PR or merge. R was only read. Outer reaper and timeout verdict remain separate.'})
except BaseException as error:
    save('RESULT.json', {
        'status': 'FAIL_EXTERNAL_NATIVE_QUALIFICATION_STOP_NO_RETRY',
        'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'seconds': time.monotonic() - started,
        'error': str(error), 'traceback': traceback.format_exc(),
        'controls_completed': controls, 'unchanged_official': unchanged,
        'limits': 'Failure retained; no repeated run or project acceptance.'})
    raise
