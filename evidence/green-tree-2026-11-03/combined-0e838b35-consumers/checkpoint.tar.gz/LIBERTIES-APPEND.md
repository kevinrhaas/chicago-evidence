

### L-green-tree-enclosed-left-reading-2376 — Green Tree wagon bay and turned range

**Covers:** `green_tree_tavern.frame_1833.form.enclosed_left_annex`, `green_tree_tavern.frame_1833.form.rear_ell`.

**Decision:** Retain the already-adopted main-gable door and two front sash. Replace the old reconstructed rear ell in the proposed visible model with the Trowbridge/Gale open post-and-roof wagon bay, a low connector and the farther gabled boarding range shown more fully by Andreas. These retrospective dependent pictures disagree about an open or enclosed shoulder and do not establish a dated alteration sequence. This minimal proposal enrolls the open reading only; a separate optional closed reading is not adopted here.

Every span, hidden depth, elevation, roof slope, opening station, plan turn, offset and timber/pigment treatment is reconstructed. The undated additions are chosen for the July1835 scene without claiming unchanged survival, exact dimensions, a surveyed location, tenant identity or increased lodging capacity. The unverified1859 catalogue photograph supplies no geometry. Source records: `andreas_1884_green_tree_hotel_plate`, `trowbridge_green_tree_1902`, `kurz_allison_1893`, `chicagology_prefire127`.

This source/model preparation leaves the main-body footprint and existing Sauganash opt-ins unchanged. It does not yet qualify the new compound occupied solids, open-bay walking clearance, entrance/yard consumers, camera framing, app performance or original picture-match ticket. Those require the separately documented compound-consumer work before safe app adoption; no source-derived coordinate or full match is claimed.

**Ticket:** T-2376.
**Recorded:** 2026-11-03.
