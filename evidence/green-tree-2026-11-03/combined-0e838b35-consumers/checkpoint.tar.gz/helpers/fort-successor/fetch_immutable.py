from pathlib import Path
import concurrent.futures, hashlib, json, urllib.request

Q=Path(__file__).parent
BASE='01a82b38666715230edf114b514f66c9ec05d2f9'
tree=json.loads((Q/'01a-tree.json').read_bytes())
by_path={r['path']:r for r in tree['tree'] if r['type']=='blob'}
rows=json.loads((Q/'REMOTE-RENDERER-PATHS.json').read_bytes())
extra=['chicago/4d/AGENTS.md','chicago/4d/docs/PIPELINE.md']
rows += [by_path[p] for p in extra]
def sha(b):return hashlib.sha256(b).hexdigest()
def git_sha(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def fetch(row):
    p=row['path']; current=Q/'runtime'/p
    b=current.read_bytes() if current.exists() else None
    reused=b is not None and git_sha(b)==row['sha']
    if not reused:
        url='https://raw.githubusercontent.com/kevinrhaas/chicago/'+BASE+'/'+p
        req=urllib.request.Request(url,headers={'User-Agent':'chicago-green-tree-bounded-successor'})
        with urllib.request.urlopen(req,timeout=45) as response:b=response.read()
    assert len(b)==row['size'] and git_sha(b)==row['sha'],p
    out=Q/'immutable01a'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
    current.parent.mkdir(parents=True,exist_ok=True);current.write_bytes(b)
    return {'path':p,'commit':BASE,'git_blob':row['sha'],'sha256':sha(b),'bytes':len(b),'reused_exact_prior_bytes':reused}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:result=list(pool.map(fetch,rows))
(Q/'ready/01A-RENDERER-INPUTS.json').write_text(json.dumps({'immutable_commit':BASE,'rows':result,'all_git_blob_sha_verified':True,'no_canonical_reads_or_writes':True},indent=2)+'\n')
print(json.dumps({'bindings':len(result),'downloaded':sum(not r['reused_exact_prior_bytes']for r in result),'reused':sum(r['reused_exact_prior_bytes']for r in result)}))
