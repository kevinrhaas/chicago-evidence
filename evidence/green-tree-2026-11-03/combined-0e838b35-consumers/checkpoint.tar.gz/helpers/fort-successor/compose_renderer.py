from pathlib import Path
import difflib, hashlib, json, subprocess, urllib.request

Q=Path(__file__).parent;D=Q/'ready';OLD=Path('/tmp/GT-consumers-eae-20261103/ready')
CURRENT='01a82b38666715230edf114b514f66c9ec05d2f9'; EAE='eaeff876666fa231e7a619f5c4939b10d754a58d'
sha=lambda b:hashlib.sha256(b).hexdigest()
ad=json.loads((OLD/'ADOPTION-FILES.json').read_bytes());changed=[];bindings=[]
for row in ad['rows']:
    p=row['path']
    if '/renderers/'not in p:continue
    oldpost=(OLD/row['postimage']).read_bytes()
    current_path=Q/'immutable01a'/p; current=current_path.read_bytes() if current_path.exists() else None
    if row['pre_sha256'] is None:
        assert current is None,p
        result=oldpost; method='new-opt-in-helper'
    else:
        url='https://raw.githubusercontent.com/kevinrhaas/chicago/'+EAE+'/'+p
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'chicago-green-tree-bounded-successor'}),timeout=45)as response:base=response.read()
        assert sha(base)==row['pre_sha256'],p
        pre=Q/'merge-inputs'/p;pre.parent.mkdir(parents=True,exist_ok=True)
        for suffix,b in [('current',current),('base',base),('proposal',oldpost)]:pre.with_name(pre.name+'.'+suffix).write_bytes(b)
        cmd=['git','merge-file','--stdout',str(pre.with_name(pre.name+'.current')),str(pre.with_name(pre.name+'.base')),str(pre.with_name(pre.name+'.proposal'))]
        merged=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (D/(Path(p).name+'.01A-3WAY-RAW.txt')).write_bytes(merged.stdout)
        assert merged.returncode==0,(p,merged.returncode,merged.stderr.decode())
        result=merged.stdout;method='clean-native-three-way-from-Eae-proposal'
    row.update(pre_sha256=sha(current)if current is not None else None,post_sha256=sha(result),post_bytes=len(result),preimage_commit=CURRENT,successor_composition=method)
    (D/row['postimage']).write_bytes(result);(Q/'runtime'/p).write_bytes(result)
    delta=''.join(difflib.unified_diff((current or b'').decode().splitlines(True),result.decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p))
    (D/(Path(p).name+'.01A-ONLY-GT-DELTA.patch')).write_text(delta)
    changed.append({'path':p,'method':method,'pre_sha256':row['pre_sha256'],'post_sha256':row['post_sha256'],'delta':Path(p).name+'.01A-ONLY-GT-DELTA.patch'})
    if current is not None:
        removals=[line[1:]for line in difflib.unified_diff(current.decode().splitlines(),result.decode().splitlines())if line.startswith('-')and not line.startswith('---')]
        bindings.append({'path':p,'removed_lines':removals})
# Do not offer a complete historical Liberty book as an adoptable postimage.
lib=next(r for r in ad['rows']if r['path']=='chicago/4d/docs/LIBERTIES.md')
oldlib=D/lib['postimage'];retained=D/'prior-artifacts'/lib['postimage'];retained.parent.mkdir(parents=True,exist_ok=True);oldlib.rename(retained)
ad['rows'].remove(lib)
ad.update(status='IMPLEMENTED_PRIVATE_FORT_RENDERER_COMPOSITE_NOT_APP_READY',source_paths=len(ad['rows']),composite_bases={'renderer':CURRENT,'producer_entrance_and_other_authored_source':'258ae324686c7bd40159a2e3a04735f90b4e5262'},parent_checkpoint='dda6ee9414ddcfd5f67cfd3bc3815f436c8f792b',successor_updated=changed,liberties_append={'path':'LIBERTIES-APPEND.md','sha256':sha((D/'LIBERTIES-APPEND.md').read_bytes()),'rule':'append to the entire then-current combined Liberty book; historical complete book retained only as prior-artifacts, never adopt it'},future_combined_head_rebind_required=True)
(D/'ADOPTION-FILES.json').write_text(json.dumps(ad,indent=2)+'\n')
(D/'01A-PRESERVATION.json').write_text(json.dumps({'composition':changed,'renderer_delta_removed_lines':bindings,'latest_fort_renderer_inputs':'01A-RENDERER-INPUTS.json','original_Eae_research_preserved':'EAE-PRESERVATION.json','no_canonical_reads_or_writes':True,'producer_base_not_replaced_with_01a_because_unmerged_Sauganash_must_survive':True},indent=2)+'\n')
print(json.dumps({'renderer_paths':len(changed),'adoptable_source_paths':len(ad['rows']),'clean_native_threeways':True}))
