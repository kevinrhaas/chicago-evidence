from pathlib import Path
import ast, hashlib, json, os, subprocess, time

Q=Path(__file__).parent;D=Q/'ready';A=Q/'runtime/chicago/4d';O=D/'evidence/fort-successor';O.mkdir(parents=True,exist_ok=True)
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(A/'tools'),TMPDIR=str(Q/'scratch'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
(Q/'scratch').mkdir(exist_ok=True)
rows=[]
for row in json.loads((D/'ADOPTION-FILES.json').read_bytes())['rows']:
    p=Q/'runtime'/row['path']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==row['post_sha256'],p
    if p.suffix=='.py':ast.parse(p.read_bytes())
commands=[('syntax-main',['node','--check','renderers/web/js/main.js']),('syntax-walker',['node','--check','renderers/web/js/walker.js']),('syntax-navigation',['node','--check','renderers/web/js/navigation.js']),('syntax-jaunt-context',['node','--check','renderers/web/js/jaunt-context.js']),('walker-passage',['node','tools/test_walker_passage.mjs']),('street-travel',['node','tools/test_street_travel.mjs']),('fort-gates',['node','tools/test_fort_gates.mjs']),('texture-residency',['node','tools/test_texture_residency.mjs']),('rail-geometry-lifecycle',['node','tools/test_rail_geometry_lifecycle.mjs','--self-test']),('ktx2-texture-policy',['node','tools/test_ktx2_texture_policy.mjs','--self-test']),('picture-features',['python3','tools/test_frame_tavern_picture_features.py'])]
for name,cmd in commands:
    log=O/(name+'.log');rp=O/(name+'-REAPER.json');assert not log.exists()and not rp.exists()
    started=time.monotonic()
    with log.open('xb')as out:p=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','nice','-n','19','taskset','-c','2','timeout','--signal=TERM','--kill-after=3s','55s',*cmd],cwd=A,env=E,stdout=out,stderr=subprocess.STDOUT)
    r=json.loads(rp.read_bytes());rows.append({'name':name,'command':cmd,'exit':p.returncode,'reaper_exit':r['command_exit'],'all_reaped':r['all_children_reaped'],'cleanup':r['leftover_cleanup'],'seconds':time.monotonic()-started,'log':str(log.relative_to(D)),'reaper':str(rp.relative_to(D))})
    print(name,p.returncode,log.read_text()[-1400:],flush=True)
result={'status':'PASS_PRIVATE_FORT_SEMANTIC_COMPOSITION_UNIT_ONLY_NOT_APP_READY'if all(x['exit']==0 and x['reaper_exit']==0 and x['all_reaped']and not x['cleanup']for x in rows)else'FAIL_PRIVATE_FORT_SEMANTIC_COMPOSITION_UNIT_ONLY_NOT_APP_READY','checks':rows,'canonical_source_or_git_reads_or_writes':False,'browser_or_full_source_gates':False,'native_owner_or_WEB_refresh':False,'immutable_renderer_base':'01a82b38666715230edf114b514f66c9ec05d2f9'}
(D/'FORT-FOCUSED-RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'],flush=True)
raise SystemExit(0 if result['status'].startswith('PASS_')else 1)
