from pathlib import Path
import subprocess,json,hashlib,io,shutil,sys,os
Q=Path(__file__).parent; A=Q/'runtime/chicago/4d'; R=Path('/workspace/chicago-bridge-increment-20261102'); H='1855273d9d8d423db20ea072a95d8169bda7ae71'
os.environ.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',H,'--','chicago/4d/data/frontage','chicago/4d/data/sidecars/1904','chicago/4d/data/street_grid/1904.json','chicago/4d/data/sidecars/1835/index.json','chicago/4d/data/sidecars/1835/dearborn_street_drawbridge.json'],cwd=R,text=True).splitlines()
rows=[]
for rel in paths:
 data=subprocess.check_output(['git','show',H+':'+rel],cwd=R); p=Q/'runtime'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);rows.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(Q/'FIXTURE-INPUTS.json').write_text(json.dumps({'immutable_base':H,'rows':rows},indent=2)+'\n')
variant='data/structures/versions/green_tree_tavern/andreas-reading.json';dst=A/variant;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(Path('/workspace/GT-Saug-current-dev-20261102/postimages/chicago/4d')/variant,dst)
checks=[]
commands=[('js-syntax',['node','--check',str(A/'renderers/web/js/'+x)])for x in []]
commands=[]
for rel in ['renderers/web/js/occupied-footprints.js','renderers/web/js/walker.js','renderers/web/js/navigation.js','renderers/web/js/main.js','renderers/web/js/jaunt-context.js','tools/test_walker_passage.mjs','tools/test_street_travel.mjs']:
 commands.append(('syntax-'+Path(rel).stem,['node','--check',str(A/rel)]))
commands += [('walker-passage',['node','tools/test_walker_passage.mjs']),('street-travel',['node','tools/test_street_travel.mjs']),('picture-features',['python3','-m','unittest','tools.test_frame_tavern_picture_features.PictureFeatures.test_occupied_annex_components_preserve_the_open_bay','tools.test_frame_tavern_picture_features.PictureFeatures.test_annex_door_uses_the_same_rotated_frame_as_its_walls','tools.test_frame_tavern_picture_features.PictureFeatures.test_sauganash_only_states_three_main_end_sash','tools.test_frame_tavern_picture_features.PictureFeatures.test_front_ground_access_reads_exact_phase_not_sidecar_form'])]
for name,argv in commands:
 log=Q/(name+'.log');receipt=Q/(name+'-reaper.json')
 with log.open('w')as out:
  p=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(receipt),'--','nice','-n','19','taskset','-c','2','timeout','--signal=TERM','--kill-after=3s','55s',*argv],cwd=A,stdout=out,stderr=subprocess.STDOUT)
 checks.append({'name':name,'command':argv,'exit_code':p.returncode,'log':log.name,'reaper':receipt.name})
 print(name,p.returncode,flush=True)
 if p.returncode:print(log.read_text()[-2000:],flush=True)
(Q/'UNIT-RESULTS.json').write_text(json.dumps({'status':'PASS_BOUNDED_UNIT_FIXTURES'if all(x['exit_code']==0 for x in checks)else'FAIL_BOUNDED_UNIT_FIXTURES','checks':checks,'optional_andreas_record_used_only_as_private_unit_fixture_not_enrolled':True},indent=2)+'\n')
