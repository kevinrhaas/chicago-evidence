from pathlib import Path
import json,hashlib,shutil,ast
Q=Path(__file__).parent;D=Q/'ready';G=Path('/tmp/GT-minimal-after-Saug-20261103/ready');N=Path('/tmp/GT-minimal-after-Saug-20261103/native');A=Q/'runtime/chicago/4d';sha=lambda b:hashlib.sha256(b).hexdigest();assert not D.exists();D.mkdir()
def copy(src,dst):
 dst=D/dst;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
ad=json.loads((Q/'ADOPTION-FILES.json').read_text())
for row in ad['rows']:
 copy(Q/row['postimage'],row['postimage'])
 if row['path'].endswith('.py'):ast.parse((Q/row['postimage']).read_text())
for name in ['ADOPTION-FILES.json','GT-consumer-integration.patch','IMMUTABLE-INPUTS.json','FIXTURE-INPUTS.json','FORT-FIXTURE-INPUTS.json','UNIT-RESULTS.json','FOLLOWUP-UNIT-RESULTS.json','FINAL-FOCUSED-RESULTS.json','RECIPE-REUSE.json','RECIPE-REUSE-ACTUAL.json','walker-threeway-conflict.txt']:
 if(Q/name).exists():copy(Q/name,name)
for name in ['compose.py','qualify.py','followup.py','recipe_reuse.py','recipe_reuse_actual.py','trim_and_close.py','package.py']:copy(Q/name,'helpers/'+name)
for item in Q.iterdir():
 if item.name.endswith(('.log','-reaper.json')):copy(item,'evidence/current/'+item.name)
for src in (G/'evidence/native').iterdir():
 if src.is_file():copy(src,'evidence/prior-native/'+src.name)
copy(G/'REGISTRY-ROWS.json','prior-native-REGISTRY-ROWS.json');copy(G/'LIBERTIES-APPEND.md','LIBERTIES-APPEND.md');copy(G/'models/chicago/4d/assets/gltf/green_tree_tavern__frame_1833.glb','models/chicago/4d/assets/gltf/green_tree_tavern__frame_1833.glb')
rows=[]
for item in json.loads((N/'RESULT.json').read_text())['unchanged_official']:
 current=sha((A/item['path']).read_bytes());rows.append({'path':item['path'],'current1855_sha256':current,'prior_native_sha256':item['observed_sha256'],'exact':current==item['observed_sha256']})
assert len(rows)==24 and all(x['exact']for x in rows)
(D/'CURRENT24-MASTER-IDENTITY.json').write_text(json.dumps({'all24_exact':True,'rows':rows,'genuine_GT_master_sha256':'f447aa45b93e507ea8606f6c74703b5948d9ee736a84d3a01d47d8a587db81c3'},indent=2)+'\n')
readme='''# T-2376 Green Tree compound consumers — implemented checkpoint

Private source implementation on immutable Chicago commit `1855273d9d8d423db20ea072a95d8169bda7ae71`. Nothing from this package has been adopted into the app, committed, or declared ticket-complete. Source checkout, tickets and Git metadata were not changed.

## Implemented

24 guarded source/test postimages include the existing five-path geometry proposal and the necessary compound-footprint compiler, collision, routing, framing, jaunt-distance, ground/obstruction and rotated-doorway consumers. The Green Tree canonical record alone opts into the new open-wagon-bay/connector/turned-range fields. The core reference footprint stays unchanged. Only the connector and boarding range become separate occupied rings; the open bay and gaps are not filled by a hull. Existing front sash/door layout was already landed and is not a new correction here.

The Sauganash producer/data values and every other frame-tavern record stay unchanged. The walker composition explicitly preserves current Fort T-3319 parade-ground behavior on its original core, and existing passage lanes remain attached to that core. Current Dearborn bridge framing remains present. Unrelated Miller updates, alternate Green Tree enrollment, global placement overrides and the older packet's independent sign-post changes are excluded. `ADOPTION-FILES.json` has exact preimage hashes, postimage hashes and composition methods; absent preimages are explicitly null.

## Actual verification

The existing 22-test native CPU picture-feature suite passes, including open-bay geometry, rotated annex doorway, Sauganash and legacy-default controls. Existing walker passage/compound-gap and street-travel tests pass, including actual main framing/bridge controls. Existing native fort-gates test passes all 54 checks. All changed JavaScript passes syntax checks and all proposed Python parses. Reaper receipts show exit 0 and all child processes reaped. No browser, full source gate or owner publication ran for this checkpoint.

The included genuine GT MASTER has SHA256 `f447aa45b93e507ea8606f6c74703b5948d9ee736a84d3a01d47d8a587db81c3`. It comes from the earlier actual 9.8015-second native production/control run, not a new bake. `RECIPE-REUSE-ACTUAL.json` directly recomputes all 25 candidate native input documents and confirms exact equality to that genuine production tree. `CURRENT24-MASTER-IDENTITY.json` confirms every other official family MASTER still matches the native control's exact bytes. The earlier run's unmodified evidence is included.

The first Python module-style fixture attempt lacked the tools import path and failed setup; the corrected invocation and full native script both pass. The first recipe check incorrectly looked up two Tremont variants using the canonical basename and overrequired unrelated K01/Fort producer equality; its failure is preserved. Direct per-record native recipe-document comparison passes all 25 without replacing/restamping assets. The old private merge conflict is retained; it was explicitly resolved, not an automatic clean merge. The full-suite pass is authoritative for the final scoped source. The optional Andreas record is private unit-test input only and is not an adoption postimage.

## Remaining before an app PR/adoption

1. Rebase guarded source posts onto the then-current dev head, preserving incoming changes and the entire latest Liberties text; append only `LIBERTIES-APPEND.md`. Do not overwrite live manifests or derived data with this private tree.
2. Adopt the 24 source paths and genuine GT MASTER under the normal native ownership workflow. Integrate family registry rows entrywise against current registries, preserving foreign entries. `prior-native-REGISTRY-ROWS.json` is historical evidence, not a wholesale replacement manifest.
3. Run the native WEB derivative/family refresh for all 25 stale producer rows, preserve all 24 foreign model bytes, both Tremont version links and all other registry entries. No GT WEB was produced here; the private execution leaf is deliberately not a coherent app publication.
4. Run native scene compilation and Liberties/entrances/source-use owners, then checks and only necessary writers for footprint/clearance/corridor/ground/frontage/fences/plantings/yard-goods/jaunt consumers. Qualify actual occupied rings, entrance station and remaining props against the real compiled publication. Open-bay native yard geometry may need a fit check against the new model; this checkpoint makes no no-overlap or walking-through-door claim.
5. Regenerate affected native camera-group/context bindings and historical image comparisons as required. Existing picture matches have not been refreshed or approved for this new compound. Run required source gates, publication checks and actual app/browser exterior, collision/route, doorway and mobile/desktop checks before PR/merge. T-2376 remains open.

Recovery source and fixtures remain under `/tmp/GT-consumers-after-combined-20261103`. The standalone checkpoint members and hash closure are enumerated in `CLOSED-MANIFEST.json`. The large private execution tree is intentionally excluded. No dependencies were installed and no historical-source rights were upgraded.
'''
(D/'README.md').write_text(readme)
manifest=[]
for p in sorted(D.rglob('*')):
 if p.is_file():manifest.append({'path':p.relative_to(D).as_posix(),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
closed={'status':'CLOSED_IMPLEMENTED_SOURCE_AND_UNIT_PROOF_NOT_APP_READY','immutable_base':ad['immutable_base'],'members':manifest,'member_count_excluding_this_manifest':len(manifest),'bytes_excluding_this_manifest':sum(x['bytes']for x in manifest),'authored_postimage_count':len(ad['rows']),'model_inputs_all25_exact':True,'other24_master_bytes_exact':True,'full_picture_tests':22,'native_fort_gate_checks':54,'requires_WEB_owners_sourcegates_actual_runtime':True}
(D/'CLOSED-MANIFEST.json').write_text(json.dumps(closed,indent=2)+'\n')
for x in manifest:assert sha((D/x['path']).read_bytes())==x['sha256']
print(json.dumps({'ready':str(D),'members_including_manifest':len(manifest)+1,'bytes_excluding_manifest':closed['bytes_excluding_this_manifest'],'closed_sha256':sha((D/'CLOSED-MANIFEST.json').read_bytes()),'authored_paths':len(ad['rows'])}))
