from pathlib import Path
import ast, base64, difflib, hashlib, json, shutil, subprocess, urllib.request

Q=Path(__file__).parent;D=Q/'ready';OLD=Path('/tmp/GT-consumers-fort-20261103/ready')
HEAD='0e838b35b5ba32b61ccd01499310520e160ab4a2'
tree=json.loads((Q/'combined-tree.json').read_bytes());assert not tree['truncated']
by_path={r['path']:r for r in tree['tree']if r['type']=='blob'}
sha=lambda b:hashlib.sha256(b).hexdigest()
gsha=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def fetch(commit,p,expected_git=None,expected_sha=None):
    req=urllib.request.Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+commit+'/'+p,headers={'User-Agent':'chicago-green-tree-bounded-successor'})
    with urllib.request.urlopen(req,timeout=45)as r:b=r.read()
    if expected_git is not None:assert gsha(b)==expected_git,p
    if expected_sha is not None:assert sha(b)==expected_sha,p
    return b
ad=json.loads((OLD/'ADOPTION-FILES.json').read_bytes());out=[];modified=[];patch=''
for row in ad['rows']:
    p=row['path'];entry=by_path.get(p);current=fetch(HEAD,p,expected_git=entry['sha'])if entry else None
    oldpost=(OLD/row['postimage']).read_bytes();assert sha(oldpost)==row['post_sha256'],p
    if row['pre_sha256']is None:
        assert current is None,(p,'new helper now exists in base')
        result=oldpost;method='new-opt-in-source'
    elif sha(current)==row['pre_sha256']:
        result=oldpost;method='preimage-byte-exact-no-source-recomposition'
    else:
        base=fetch(row['preimage_commit'],p,expected_sha=row['pre_sha256'])
        m=Q/'merge-inputs'/p;m.parent.mkdir(parents=True,exist_ok=True)
        for suffix,b in [('current',current),('base',base),('proposal',oldpost)]:m.with_name(m.name+'.'+suffix).write_bytes(b)
        proc=subprocess.run(['git','merge-file','--stdout',str(m.with_name(m.name+'.current')),str(m.with_name(m.name+'.base')),str(m.with_name(m.name+'.proposal'))],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        raw=D/'evidence/combined-rebind'/f'{Path(p).name}.3WAY-RAW.txt';raw.parent.mkdir(parents=True,exist_ok=True);raw.write_bytes(proc.stdout)
        assert proc.returncode==0,(p,proc.returncode,proc.stderr.decode())
        result=proc.stdout;method='clean-native-three-way-preserving-combined-head'
        modified.append({'path':p,'old_preimage_commit':row['preimage_commit'],'old_pre_sha256':row['pre_sha256'],'combined_pre_sha256':sha(current),'old_post_sha256':sha(oldpost),'new_post_sha256':sha(result),'raw_result':str(raw.relative_to(D))})
    prepath=None
    if current is not None:
        prepath='preimages/'+p;f=D/prepath;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(current)
    row.update(pre_sha256=sha(current)if current is not None else None,preimage_git_blob=entry['sha']if entry else None,preimage_commit=HEAD,preimage=prepath,post_sha256=sha(result),post_bytes=len(result),successor_composition=method)
    (D/row['postimage']).write_bytes(result);(Q/'runtime'/p).write_bytes(result)
    if p.endswith('.py'):ast.parse(result)
    out.append({'path':p,'base_commit':HEAD,'base_git_blob':entry['sha']if entry else None,'pre_sha256':row['pre_sha256'],'post_sha256':row['post_sha256'],'source_postimage_unchanged_from_Fort_tested_packet':result==oldpost,'composition':method})
    patch+=''.join(difflib.unified_diff((current or b'').decode().splitlines(True),result.decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p))
oldpatch=D/'GT-consumer-integration.patch';legacy=D/'prior-artifacts/GT-consumer-integration-before-combined.patch';legacy.parent.mkdir(parents=True,exist_ok=True);oldpatch.rename(legacy);oldpatch.write_text(patch)
ad.update(status='GUARDED_PRIVATE_COMBINED_0E_SOURCE_PROPOSAL_NOT_APP_READY',immutable_base=HEAD,composite_bases=None,parent_checkpoint='d43266ce12e00f27ee4e20b3721f6e3331165d12',successor_updated=modified,future_combined_head_rebind_required=False,then_current_dev_guard_still_required=True)
(D/'ADOPTION-FILES.json').write_text(json.dumps(ad,indent=2)+'\n')
# Every non-proposal renderer input was unchanged on the newly combined source.
renderer=[]
for old in json.loads((D/'01A-RENDERER-INPUTS.json').read_bytes())['rows']:
    p=old['path']
    if '/renderers/'not in p:continue
    entry=by_path[p];assert entry['sha']==old['git_blob'],p
    renderer.append({'path':p,'combined_git_blob':entry['sha'],'unchanged_from_bound_01a_renderer':True})
result={'status':'PASS_IMMUTABLE_COMBINED_SOURCE_GUARDS_ONLY_NOT_APP_READY','base_commit':HEAD,'rows':out,'native_three_way_changed_paths':modified,'all_renderer_inputs_unchanged_from_Fort_base':True,'renderer_bindings':renderer,'all_proposed_source_posts_unchanged_from_tested_Fort_packet':all(r['source_postimage_unchanged_from_Fort_tested_packet']for r in out),'prior_native_unit_results':'FORT-FOCUSED-RESULTS.json','prior_units_not_rerun':True,'canonical_source_or_git_reads_or_writes':False,'app_adoption_WEB_owners_browser_full_source_gate_or_merge':False}
(D/'COMBINED-REBIND-RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source_paths':len(out),'base_commit':HEAD,'incoming_changed_sources':modified,'all_renderer_inputs_same_as_Fort_base':True,'source_postimages_unchanged':result['all_proposed_source_posts_unchanged_from_tested_Fort_packet']}),flush=True)
