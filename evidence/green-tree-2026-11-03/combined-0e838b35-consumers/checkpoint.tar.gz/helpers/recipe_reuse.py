from pathlib import Path
import sys,json,hashlib
Q=Path(__file__).parent; A=Q/'runtime/chicago/4d'; N=Path('/tmp/GT-minimal-after-Saug-20261103/native');sys.path.insert(0,str(A/'generators'))
from mesh_inputs import structure_inputs_sha
old=json.loads((N/'INPUTS.json').read_text());manifest=json.loads((N/'source/chicago/4d/assets/manifest.json').read_text())['assets'];rows=[]
for item in old['rows']:
 record=json.loads((A/item['record_path']).read_text());phase=next(x for x in record['phases']if x['id']==item['phase']);asset=Path(item['master_path']).name
 current=structure_inputs_sha(record,phase,record['archetype']);expected=manifest[asset]['inputs_sha256'];rows.append({'id':item['id'],'phase':item['phase'],'inputs_sha256':current,'genuine_prior_native_inputs_sha256':expected,'exact_recipe':current==expected,'actual_master_sha256':hashlib.sha256((A/item['master_path']).read_bytes()).hexdigest()})
source=[]
for item in old['source_bindings']:
 rel=item['immutable_git_path']; before=N/'source'/rel;after=Q/'runtime'/rel
 source.append({'path':rel,'bytes_exact':before.read_bytes()==after.read_bytes()})
result={'status':'PASS_REUSE_GENUINE_MODEL_INPUTS'if all(x['exact_recipe']for x in rows)else'FAIL_REUSE_MODEL_INPUTS','rows':rows,'all25_recipe_inputs_exact':all(x['exact_recipe']for x in rows),'producer_bindings':source,'all_prior204_producer_bindings_exact':all(x['bytes_exact']for x in source),'prior_native_result_sha256':hashlib.sha256((N/'RESULT.json').read_bytes()).hexdigest(),'no_new_bake_claim':True}
(Q/'RECIPE-REUSE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['rows','producer_bindings']}))
assert result['all25_recipe_inputs_exact'] and result['all_prior204_producer_bindings_exact']
