from pathlib import Path
import subprocess,json,hashlib,io,ast,difflib,shutil
P=Path(__file__).parent;R=Path('/workspace/chicago-bridge-increment-20261102');H='1855273d9d8d423db20ea072a95d8169bda7ae71';F=Path('/workspace/GT-Saug-current-dev-20261102');G=Path('/tmp/GT-minimal-after-Saug-20261103/ready');A=P/'runtime/chicago/4d';sha=lambda b:hashlib.sha256(b).hexdigest()
full=json.load(open(F/'ADOPTION-FILES.json'));fr={x['path']:x for x in full['rows']};deps=json.load(open(G/'REQUIRED-CONSUMERS.json'))['rows'];consumer=[x['path']for x in deps]+['chicago/4d/tools/test_walker_passage.mjs','chicago/4d/tools/test_frame_tavern_picture_features.py'];geo=json.load(open(G/'ADOPTION-FILES.json'))['rows'];old=json.load(open('/tmp/GT-minimal-after-Saug-20261103/native/INPUTS.json'))
paths=set(consumer)|{x['path']for x in geo}
for x in old['source_bindings']:paths.add(x['immutable_git_path'])
for x in old['rows']:
 for rel in [x['record_path'],x['master_path']]:paths.add('chicago/4d/'+rel)
paths|={'chicago/4d/data/sidecars/1904/glessner_house.json','chicago/4d/data/sidecars/1835/green_tree_tavern.json','chicago/4d/data/sidecars/1835/sauganash_hotel.json','chicago/4d/data/datum.json','chicago/4d/tools/test_street_travel.mjs'}
allnames=subprocess.check_output(['git','ls-tree','-r','--name-only',H,'--','chicago/4d/renderers/web/js','chicago/4d/renderers/web/vendor/three-0.185.1','chicago/4d/tools'],cwd=R,text=True).splitlines()
paths.update(x for x in allnames if x.startswith('chicago/4d/renderers/web/')or(x.startswith('chicago/4d/tools/')and x.endswith(('.py','.mjs'))))
paths=sorted(paths);raw=subprocess.check_output(['git','cat-file','--batch'],cwd=R,input=''.join(H+':'+x+'\n'for x in paths).encode());s=io.BytesIO(raw);blobs={};rows=[]
for rel in paths:
 header=s.readline().decode().split()
 if len(header)==2 and header[-1]=='missing':blobs[rel]=None;continue
 assert len(header)==3 and header[1]=='blob',(rel,header)
 data=s.read(int(header[2]));assert s.read(1)==b'\n';assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==header[0];blobs[rel]=data
 q=P/'immutable1855'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
 target=P/'runtime'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 rows.append({'git_path':rel,'git_blob':header[0],'sha256':sha(data),'bytes':len(data)})
posts={};composition=[]
for rel in consumer:
 current=blobs[rel];basefile=F/'preimages'/rel;base=basefile.read_bytes()if basefile.exists()else None;after=(F/'postimages'/rel).read_bytes();assert sha(after)==fr[rel]['post_sha256']
 if base is None:
  assert current is None,rel;merged=after;method='new opt-in helper'
 elif current==base:merged=after;method='unchanged1855preimage'
 elif after.startswith(base):
  suffix=after[len(base):];merged=current if suffix in current else current+suffix;method='qualified append preserves entire1855text'
 else:
  tmp=P/'merge-inputs'/rel;tmp.parent.mkdir(parents=True,exist_ok=True)
  for ext,b in [('current',current),('base',base),('proposal',after)]:tmp.with_name(tmp.name+'.'+ext).write_bytes(b)
  q=subprocess.run(['git','merge-file','--stdout',str(tmp.with_name(tmp.name+'.current')),str(tmp.with_name(tmp.name+'.base')),str(tmp.with_name(tmp.name+'.proposal'))],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  if q.returncode and rel=='chicago/4d/renderers/web/js/walker.js':
   import re
   text=q.stdout.decode();conflicts=re.findall(r'<<<<<<<[^\n]*\n(.*?)=======\n(.*?)>>>>>>>[^\n]*',text,re.S);assert len(conflicts)==1
   left,right=conflicts[0];assert 'T-3319' in left and 'for (const [index, poly]' in right
   right=right.replace('      // Existing passages belong',"      // Preserve the native parade-ground floor flag on its original core.\n      if (index === 0 && record.sidecar?.attributes?.kind?.value === 'parade') fp.ground = true;\n      // Existing passages belong")
   text=re.sub(r'<<<<<<<[^\n]*\n.*?=======\n.*?>>>>>>>[^\n]*',lambda m:right.rstrip('\n'),text,flags=re.S);assert '<<<<<<<'not in text;merged=text.encode();method='explicit compound-loop + existing T3319 parade-ground composition'
  else:
   assert q.returncode==0,(rel,q.stdout.decode(errors='replace')[:700]);merged=q.stdout;method='clean3way preserving1855fortbridgeSaug'
 if merged!=current:posts[rel]=merged
 composition.append({'path':rel,'method':method})
for x in geo:
 rel=x['path'];post=(G/x['postimage']).read_bytes();assert sha(post)==x['post_sha256'];current=blobs[rel]
 if rel.endswith('LIBERTIES.md'):
  suffix=(G/'LIBERTIES-APPEND.md').read_bytes();assert b'### L-green-tree-enclosed-left-reading-2376 'not in current;post=current+suffix
 else:assert current is None or sha(current)==x['pre_sha256'],rel
 posts[rel]=post
adopt=[];patch=''
for rel,data in posts.items():
 if rel.endswith('.py'):ast.parse(data)
 if rel.endswith('.json'):json.loads(data)
 q=P/'postimages'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);target=P/'runtime'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 before=blobs[rel];adopt.append({'path':rel,'pre_sha256':sha(before)if before is not None else None,'post_sha256':sha(data),'post_bytes':len(data),'postimage':str(q.relative_to(P))})
 patch+=''.join(difflib.unified_diff((before or b'').decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(P/'GT-consumer-integration.patch').write_text(patch)
(P/'ADOPTION-FILES.json').write_text(json.dumps({'status':'IMPLEMENTED_PRIVATE_ONLY_UNQUALIFIED_APP','immutable_base':H,'rows':adopt,'composition':composition,'no_canonical_or_git_metadata_writes':True},indent=2)+'\n')
(P/'IMMUTABLE-INPUTS.json').write_text(json.dumps({'commit':H,'files':rows,'git_blob_bytes_verified':True},indent=2)+'\n')
# The already genuine model is copied, not recomputed or restamped.
model=G/'models/chicago/4d/assets/gltf/green_tree_tavern__frame_1833.glb';assert sha(model.read_bytes())=='f447aa45b93e507ea8606f6c74703b5948d9ee736a84d3a01d47d8a587db81c3';target=A/'assets/gltf/green_tree_tavern__frame_1833.glb';target.write_bytes(model.read_bytes())
print(json.dumps({'implemented_paths':len(adopt),'immutable_files':len(rows),'copied_runtime_bytes':sum(x['bytes']for x in rows),'all_3way_clean':True}),flush=True)
