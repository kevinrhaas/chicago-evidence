from pathlib import Path
import subprocess,json,os,hashlib
Q=Path(__file__).parent;A=Q/'runtime/chicago/4d';R=Path('/workspace/chicago-bridge-increment-20261102');H='1855273d9d8d423db20ea072a95d8169bda7ae71';os.environ.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(A/'tools'))
# All actual fort sidecars at the immutable base are test inputs, not proposal files.
names=subprocess.check_output(['git','ls-tree','-r','--name-only',H,'--','chicago/4d/data/sidecars/1812','chicago/4d/data/sidecars/1835'],cwd=R,text=True).splitlines();rows=[]
for rel in names:
 if '/1812/'not in rel and not any(x in Path(rel).name for x in ['fort_','dearborn','stockade','palisade','parade']):continue
 data=subprocess.check_output(['git','show',H+':'+rel],cwd=R);dst=Q/'runtime'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);rows.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(Q/'FORT-FIXTURE-INPUTS.json').write_text(json.dumps({'immutable_base':H,'rows':rows},indent=2)+'\n')
commands=[('picture-features-correct-pythonpath',['python3','-m','unittest','tools.test_frame_tavern_picture_features.PictureFeatures.test_occupied_annex_components_preserve_the_open_bay','tools.test_frame_tavern_picture_features.PictureFeatures.test_annex_door_uses_the_same_rotated_frame_as_its_walls','tools.test_frame_tavern_picture_features.PictureFeatures.test_sauganash_only_states_three_main_end_sash','tools.test_frame_tavern_picture_features.PictureFeatures.test_front_ground_access_reads_exact_phase_not_sidecar_form']),('fort-gates',['node','tools/test_fort_gates.mjs'])];checks=[]
for name,argv in commands:
 with (Q/(name+'.log')).open('w')as out:p=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(Q/(name+'-reaper.json')),'--','nice','-n','19','taskset','-c','2','timeout','--signal=TERM','--kill-after=3s','55s',*argv],cwd=A,stdout=out,stderr=subprocess.STDOUT)
 checks.append({'name':name,'command':argv,'exit_code':p.returncode,'log':name+'.log','reaper':name+'-reaper.json'});print(name,p.returncode,(Q/(name+'.log')).read_text()[-1100:],flush=True)
(Q/'FOLLOWUP-UNIT-RESULTS.json').write_text(json.dumps({'checks':checks,'all_pass':all(x['exit_code']==0 for x in checks),'original_failed_pythonpath_attempt_preserved':True},indent=2)+'\n')
