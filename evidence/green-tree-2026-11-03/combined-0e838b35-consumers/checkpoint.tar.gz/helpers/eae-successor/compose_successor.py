from pathlib import Path
import json,subprocess,hashlib,shutil,os,difflib,ast
Q=Path(__file__).parent;old=Path('/tmp/GT-consumers-after-combined-20261103');G=old/'ready';D=Q/'ready';A=Q/'runtime/chicago/4d';R=Path('/workspace/chicago-bridge-increment-20261102');E='eaeff876666fa231e7a619f5c4939b10d754a58d';os.environ.update(GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1');B=subprocess.check_output(['git','rev-parse','258ae324^{commit}'],cwd=R,text=True).strip();sha=lambda b:hashlib.sha256(b).hexdigest();assert not D.exists();shutil.copytree(G,D);shutil.copytree(old/'runtime',Q/'runtime');ad=json.loads((G/'ADOPTION-FILES.json').read_text());bindings=[]
def blob(h,p):
 x=subprocess.run(['git','cat-file','blob',h+':'+p],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL);return x.stdout if x.returncode==0 else None
# Actual Eae renderer graph, including its original texture/release policies.
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',E,'--','chicago/4d/renderers/web/js'],cwd=R,text=True).splitlines();paths += ['chicago/4d/tools/'+x for x in ['test_texture_residency.mjs','test_rail_geometry_lifecycle.mjs','test_ktx2_texture_policy.mjs']]
for rel in paths:
 data=blob(E,rel);assert data is not None;dst=Q/'runtime'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);bindings.append({'path':rel,'commit':E,'sha256':sha(data),'bytes':len(data)})
patch='';updated=[]
for row in ad['rows']:
 rel=row['path'];basehash=E if '/renderers/'in rel else B;current=blob(basehash,rel);post=(G/row['postimage']).read_bytes();pre=old/'immutable1855'/rel;prior=pre.read_bytes()if pre.exists()else None
 if current!=prior:
  if rel.endswith('LIBERTIES.md'):
   delta=(G/'LIBERTIES-APPEND.md').read_bytes();assert delta not in current;post=current+delta;method='qualified appendix on entire258ae324Liberties'
  else:
   assert '/renderers/'in rel,(rel,sha(current)if current else None,row['pre_sha256']);m=Q/'merge-inputs'/rel;m.parent.mkdir(parents=True,exist_ok=True)
   for suffix,b in [('current',current),('base',prior),('proposal',post)]:m.with_name(m.name+'.'+suffix).write_bytes(b)
   p=subprocess.run(['git','merge-file','--stdout',str(m.with_name(m.name+'.current')),str(m.with_name(m.name+'.base')),str(m.with_name(m.name+'.proposal'))],stdout=subprocess.PIPE,stderr=subprocess.PIPE);(Q/'MAIN-3WAY-RAW.txt').write_bytes(p.stdout);assert p.returncode==0,(rel,p.stdout.decode(errors='replace')[:1500]);post=p.stdout;method='clean3wayEaeCoreplusGTcompound'
  updated.append({'path':rel,'method':method})
 else:method='sourceproposalunchangedonperfilecompositebase'
 row.update(pre_sha256=sha(current)if current is not None else None,post_sha256=sha(post),post_bytes=len(post),preimage_commit=basehash,successor_composition=method)
 (D/row['postimage']).write_bytes(post);(Q/'runtime'/rel).write_bytes(post)
 if rel.endswith('.py'):ast.parse(post)
 patch+=''.join(difflib.unified_diff((current or b'').decode().splitlines(True),post.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
ad.update(status='IMPLEMENTED_PRIVATE_EAE_COMPOSITE_NOT_APP_READY',immutable_base=None,composite_bases={'renderer':E,'producer_entrance_and_other_authored_source':B},parent_checkpoint='f8707c10b0d4c34333f583461c84088b999fa1ab',successor_updated=updated)
(D/'ADOPTION-FILES.json').write_text(json.dumps(ad,indent=2)+'\n');(D/'GT-consumer-integration.patch').write_text(patch);(D/'EAE-RENDERER-INPUTS.json').write_text(json.dumps({'rows':bindings,'all_bytes_from_immutable_git':True},indent=2)+'\n');(D/'CLOSED-MANIFEST.json').unlink()
print(json.dumps({'composite_bases':ad['composite_bases'],'updated':updated,'source_paths':len(ad['rows']),'renderer_bindings':len(bindings)}),flush=True)
