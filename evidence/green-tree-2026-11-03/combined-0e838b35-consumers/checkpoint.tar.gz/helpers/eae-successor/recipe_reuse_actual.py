from pathlib import Path
import subprocess,json,os,hashlib
Q=Path(__file__).parent;A=Q/'runtime/chicago/4d';N=Path('/tmp/GT-minimal-after-Saug-20261103/native');os.environ['PYTHONDONTWRITEBYTECODE']='1'
code='''from pathlib import Path
import sys,json
A=Path(sys.argv[1]);N=Path(sys.argv[2]);sys.path.insert(0,str(A/'generators'))
from mesh_inputs import structure_inputs_sha,structure_inputs_doc
out=[]
for row in json.loads((N/'INPUTS.json').read_text())['rows']:
 record=json.loads((A/row['record_path']).read_text());phase=next(x for x in record['phases']if x['id']==row['phase']);out.append({'id':row['id'],'phase':row['phase'],'record_path':row['record_path'],'inputs_sha256':structure_inputs_sha(record,phase,record['archetype']),'doc':structure_inputs_doc(record,phase,record['archetype'])})
print(json.dumps(out))
'''
prior=json.loads(subprocess.check_output(['python3','-c',code,str(N/'source/chicago/4d'),str(N)]));current=json.loads(subprocess.check_output(['python3','-c',code,str(A),str(N)]));rows=[]
for old,new in zip(prior,current):
 assert(old['id'],old['phase'],old['record_path'])==(new['id'],new['phase'],new['record_path']);rows.append({k:new[k]for k in ['id','phase','record_path','inputs_sha256']}|{'genuine_prior_native_inputs_sha256':old['inputs_sha256'],'exact_recipe':new['inputs_sha256']==old['inputs_sha256'],'exact_native_recipe_document':new['doc']==old['doc']})
(Q/'RECIPE-REUSE-ACTUAL.json').write_text(json.dumps({'status':'PASS_ACTUAL_PRIOR_NATIVE_RECIPE_IDENTITY'if all(x['exact_recipe']for x in rows)else'FAIL_ACTUAL_PRIOR_NATIVE_RECIPE_IDENTITY','rows':rows,'all25_recipe_inputs_exact':all(x['exact_recipe']for x in rows),'prior_result_sha256':hashlib.sha256((N/'RESULT.json').read_bytes()).hexdigest(),'prior_native_seconds':9.801505837007426,'no_new_bake':True,'prior_manifest_lookup_failure_preserved':'RECIPE-REUSE.json used canonical asset basename for two Tremont variants and overbroad unrelated producer checks; direct native recipe document comparison resolves this without restamping assets.'},indent=2)+'\n')
print([(x['id'],x['phase'],x['exact_recipe'])for x in rows]);assert all(x['exact_recipe']for x in rows)
