from pathlib import Path
import json,difflib,hashlib,shutil,ast,subprocess,os
Q=Path(__file__).parent;A=Q/'runtime/chicago/4d';G=Path('/tmp/GT-minimal-after-Saug-20261103/ready');sha=lambda b:hashlib.sha256(b).hexdigest();ad=json.loads((Q/'ADOPTION-FILES.json').read_text());removed='chicago/4d/tools/generate_business_signboards.py';(Q/'postimages'/removed).unlink();shutil.copyfile(Q/'immutable1855'/removed,Q/'runtime'/removed)
rel='chicago/4d/tools/generate_frontage_works.py';before=(Q/'immutable1855'/rel).read_text().splitlines(True);after=(Q/'postimages'/rel).read_text().splitlines(True);merged=[]
for tag,i,j,a,b in difflib.SequenceMatcher(None,before,after,autojunk=False).get_opcodes():
 merged.extend(after[a:b]if tag=='equal'or i<150 or i>=2500 else before[i:j])
content=''.join(merged);assert 'independent_corner_sign'not in content;assert 'additional_world_polygons'in content;ast.parse(content)
(Q/'postimages'/rel).write_text(content);(Q/'runtime'/rel).write_text(content)
# The prepared optional reading is not enrolled by this candidate.
rel2='chicago/4d/tools/generate_yard_goods.py';text=(Q/'postimages'/rel2).read_text();text=text.replace('"The optional Andreas reading closes the immediate shoulder; this open "','"The unadopted prepared Andreas reading closes the shoulder; this open "');(Q/'postimages'/rel2).write_text(text);(Q/'runtime'/rel2).write_text(text)
ad['rows']=[x for x in ad['rows']if x['path']!=removed];ad['composition']=[x for x in ad['composition']if x['path']!=removed];ad['excluded_unrelated_full_packet_changes']=['Green Tree independent sign-post implementation/narrative','optional Andreas alternate enrollment','Miller source updates','global nav/yard placement overrides'];ad['source_paths']=len(ad['rows']);ad['explicit_resolved_conflicts']=['walker.js compound loop preserves original Fort T3319 ground flag on core'];ad['all_conflicts_resolved']=True
patch=''
for row in ad['rows']:
 path=row['path'];data=(Q/row['postimage']).read_bytes();row.update(post_sha256=sha(data),post_bytes=len(data));pre=Q/'immutable1855'/path;old=pre.read_bytes()if pre.exists()else b'';assert sha(old)==row['pre_sha256']if pre.exists()else row['pre_sha256']is None
 patch+=''.join(difflib.unified_diff(old.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(Q/'ADOPTION-FILES.json').write_text(json.dumps(ad,indent=2)+'\n');(Q/'GT-consumer-integration.patch').write_text(patch)
# Full existing CPU unit suite, not a rendered/model qualification.
os.environ.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(A/'tools'))
with(Q/'picture-features-full.log').open('w')as out:p=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(Q/'picture-features-full-reaper.json'),'--','nice','-n','19','taskset','-c','2','timeout','--signal=TERM','--kill-after=3s','55s','python3','tools/test_frame_tavern_picture_features.py'],cwd=A,stdout=out,stderr=subprocess.STDOUT)
(Q/'FINAL-FOCUSED-RESULTS.json').write_text(json.dumps({'status':'PASS_IMPLEMENTED_PRIVATE_CONSUMERS_UNIT_ONLY_NOT_APP_READY'if p.returncode==0 else'PARTIAL_IMPLEMENTED_PRIVATE_CONSUMERS_UNIT_ONLY_NOT_APP_READY','existing_full_picture_feature_suite_exit':p.returncode,'authored_paths':len(ad['rows']),'sign_scope_trimmed':True,'canonical_writes':False,'no_full_source_gates_or_browser':True},indent=2)+'\n');print((Q/'picture-features-full.log').read_text()[-1400:],flush=True)
