"""One ordinary delivery after qualified gate and the authorized caption bridge."""
from pathlib import Path
import argparse,datetime,fcntl,hashlib,importlib.util,json,os,re,shutil,subprocess,sys
HERE=Path(__file__).parent;R=Path('/workspace/chicago-driver-garment-projected-20261104');APP=R/'chicago/4d'
SUP=Path('/workspace/.cloud-setup/transport-supervise.py');LOCK=Path('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock')
TITLE='Repair driver clothing at lower detail'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
save=lambda p,j:Path(p).write_text(json.dumps(j,indent=2)+'\n')
def main():
 assert __debug__ and sys.version_info[:2]==(3,11)
 parser=argparse.ArgumentParser();parser.add_argument('--binding',required=True,type=Path);a=parser.parse_args();auth=load(a.binding);auth_sha=sha(a.binding)
 assert auth['standing_ROOT_delivery_authorized']and auth['source']['HEAD']==auth['base']
 assert all(auth[k]==1 for k in ['commit_budget','normal_push_budget','ready_PR_budget','own_lap_budget'])
 assert all(auth[k]==0 for k in ['merge_budget','force_budget','CI_dispatch_budget','ticket_state_write_budget','production_action_budget'])
 assert sha(__file__)==auth['runner_sha256']and sha(HERE/'COMMIT-MESSAGE.txt')==auth['message_sha256']
 for p,h in auth['execution_pins'].items():assert sha(p)==h
 gate=load(auth['gate']['path']);bridge=load(auth['bridge']['path'])
 assert sha(auth['gate']['path'])==auth['gate']['sha256']and sha(auth['bridge']['path'])==auth['bridge']['sha256']
 assert gate['status']=='PASS_ALL_FOUR_NATIVE_CHECK_PARTS_SAME_STAGED_SOURCE'and gate['resources']['accepted']and gate['owned_TMPDIR_cleanup_complete']
 assert gate['source_before']==gate['source_after']==bridge['source_before']and bridge['source_after']==auth['source']and bridge['passed']
 assert bridge['all_four_ran_on_final_metadata_TREE']is False
 for row in gate['ledger']:
  r=row['result'];assert r['returncode']==0 and not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==600 and r['timeout_override_reason']is None
  assert row['resources']['accepted']and row['cleanup']['cleanup_complete']and not row['cleanup']['remaining_owned_children']and row['source_before']==row['source_after']==gate['source_before']
  assert sha(row['log'])==row['log_sha256']and row['native_footer_counts']==gate['expected_parts'][str(row['part'])]
 lock=LOCK.open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',CHECK_JOBS='4',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',C4D_RULINGS_BASE=auth['base'])
 for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR','CHECK_PART','BASE','CHECK_TIMINGS']:env.pop(k,None)
 for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:assert env[k]=='1'
 meta=dict(env,GIT_NO_LAZY_FETCH='1')
 def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(R),*args],env=meta,timeout=45)
 def val(*a):return git(*a).decode().strip()
 def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path],env=env,timeout=45))
 def source(head,staged):
  assert sha(a.binding)==auth_sha and sha(__file__)==auth['runner_sha256']and sha(HERE/'COMMIT-MESSAGE.txt')==auth['message_sha256']
  for p,h in auth['execution_pins'].items():assert sha(p)==h
  assert val('branch','--show-current')==auth['branch']and not git('ls-files','-u').strip()and not git('diff','--name-only').strip()and not git('ls-files','--others','--exclude-standard').strip()
  assert sha(R/'.git/config')==auth['config_sha256']
  merge=Path(val('rev-parse','--git-path','MERGE_HEAD'));merge=merge if merge.is_absolute()else R/merge;assert not merge.exists()
  tree=val('write-tree');s=dict(HEAD=val('rev-parse','HEAD'),TREE=tree,APP=val('rev-parse',tree+':chicago/4d'),semantic_index_sha256=hashlib.sha256(git('ls-files','--stage','-z')).hexdigest());assert s==dict(auth['source'],HEAD=head)
  assert sorted(val('diff','--cached','--name-only').splitlines())==(sorted(auth['owned_files'])if staged else[])
  for f,h in auth['owned_files'].items():assert sha(R/f)==h
  for f,h in auth['human24'].items():assert sha(APP/f)==h
  return s
 assert val('remote','get-url','origin')=='https://github.com/kevinrhaas/chicago.git';source(auth['base'],True)
 assert not val('ls-remote','--heads','origin','refs/heads/'+auth['branch']),'Remote feature exists; reconcile without repeat'
 hooks=subprocess.run(['git','-C',str(R),'config','--get','core.hooksPath'],env=meta,capture_output=True);assert hooks.returncode==1
 hp=Path(val('rev-parse','--git-path','hooks'));hp=hp if hp.is_absolute()else R/hp;assert not any(p.is_file()and not p.name.endswith('.sample')for p in hp.iterdir())
 out=HERE/'actual-delivery-01';assert not out.exists(),'Never repeat uncertain mutations';out.mkdir();scratch=out/'native-tmp';scratch.mkdir();env['TMPDIR']=str(scratch)
 spec=importlib.util.spec_from_file_location('guard','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard);before=guard.snapshot();assert guard.check(before)['accepted']
 rows=[];head=None;pr=None;error=None;inflight=False;lap_acquired=False
 def run(name,cmd,cap=120,cwd=APP,allow_nonzero=False):
  nonlocal inflight
  rb=guard.snapshot();assert guard.check(rb)['accepted'];prefix=out/name;save(out/'STATE.json',dict(active=name,HEAD=head,PR=pr['number']if pr else None));inflight=True
  with Path(str(prefix)+'.stdout').open('xb')as f:subprocess.run([sys.executable,str(SUP),'--prefix',str(prefix),'--cwd',str(cwd),'--timeout',str(cap),'--',*cmd],env=env,stdout=f,stderr=subprocess.STDOUT)
  r=load(str(prefix)+'.result.json');c=load(str(prefix)+'.cleanup.json');pair=guard.pair(rb,guard.snapshot());inflight=not(c['cleanup_complete']and not c['remaining_owned_children']);row=dict(name=name,result=r,cleanup=c,resources=pair,log_sha256=sha(str(prefix)+'.log'));rows.append(row);save(out/'LEDGER.json',rows)
  assert not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==cap and r['timeout_override_reason']is None and not inflight and pair['accepted']
  if not allow_nonzero:assert r['returncode']==0,name
  return row
 try:
  save(out/'COMMIT-INTENT.json',dict(source=auth['source'],message_sha256=auth['message_sha256'],mutation_budget=1));run('ordinary-commit-ONCE',['git','commit','-F',str(HERE/'COMMIT-MESSAGE.txt')],cwd=R)
  head=val('rev-parse','HEAD');source(head,False);assert val('show','-s','--format=%P','HEAD').split()==[auth['base']]
  for label,cmd in auth['actual_HEAD_QA']:run('HEAD-'+label,cmd);source(head,False)
  run('HEAD-whitespace',['git','show','--check','--format=oneline','HEAD'],cwd=R);run('HEAD-base-whitespace',['git','diff','--check',auth['base'],'HEAD'],cwd=R);source(head,False)
  run('native-publish',['bash','tools/publish.sh'],180);source(head,False);run('published-check',['node','tools/check_published.mjs'],120);source(head,False);assert load(R/'site/4d/build.json')['version']==head[:10]
  save(out/'PUSH-INTENT.json',dict(HEAD=head,branch=auth['branch'],force=False,mutation_budget=1));run('normal-feature-push-ONCE',['git','push','origin','HEAD:refs/heads/'+auth['branch']],cwd=R,allow_nonzero=True)
  assert val('ls-remote','--heads','origin','refs/heads/'+auth['branch']).split()==[head,'refs/heads/'+auth['branch']]
  ref=api('git/ref/heads/'+auth['branch']);commit=api('git/commits/'+head);save(out/'PUBLIC-REF.json',ref);save(out/'PUBLIC-COMMIT.json',commit);assert ref['object']['sha']==head and commit['tree']['sha']==auth['source']['TREE']and[x['sha']for x in commit['parents']]==[auth['base']]
  times='/'.join(f"{r['result']['seconds']:.3f}"for r in gate['ledger'])
  body=f"Otis and Hans had visible gaps in their shirts and trousers at lower scene detail. The active lower-detail assets now retain fuller reviewed garments while preserving their existing bodies, rigs, images and animations.\n\nValidation:\n\n- All 1,163 distinct local checks and 402 self-tests passed on tree `14f4256` in {times} seconds across four parts, under the original 600-second caps and source/resource/cleanup guards.\n- The final recipe caption and current derivation hash have a finite metadata bridge with fresh original regeneration and affected checks. All four admitted asset hashes and the other twenty human payloads remain exact. All four parts have not run on the later metadata tree; fresh CI tests the exact committed source.\n- The original all-24 desktop/phone human fixture passed. Otis/Hans WEB LOD3 costs are 564,628/551,488 bytes and 13,679/13,635 triangles, each with nine draws.\n- Committed HEAD `{head[:10]}` passes five QA checks, whitespace and native publish/check. Fresh world/frame/memory checks, continuous fit and photographic review remain pending. The broader transport work stays open.\n"
  bodyfile=out/'PR-BODY.md';bodyfile.write_text(body);assert not re.search(r'\bT-?\d+\b',TITLE+'\n'+body)
  existing=json.loads(subprocess.check_output(['gh','pr','list','--repo','kevinrhaas/chicago','--head',auth['branch'],'--base','dev','--state','open','--json','number'],env=env,timeout=45));assert existing==[]
  save(out/'PR-INTENT.json',dict(HEAD=head,title=TITLE,body_sha256=sha(bodyfile),mutation_budget=1));run('ready-PR-create-ONCE',['gh','pr','create','--repo','kevinrhaas/chicago','--base','dev','--head',auth['branch'],'--title',TITLE,'--body-file',str(bodyfile)],cwd=R,allow_nonzero=True)
  found=json.loads(subprocess.check_output(['gh','pr','list','--repo','kevinrhaas/chicago','--head',auth['branch'],'--base','dev','--state','open','--json','number'],env=env,timeout=45));assert len(found)==1
  pr=api('pulls/'+str(found[0]['number']));save(out/'READY-PR.json',pr);assert not pr['draft']and pr['state']=='open'and not pr['merged']and pr['title']==TITLE and pr['base']['ref']=='dev'and pr['head']['sha']==head
  print(json.dumps(dict(event='READY_PR_PUBLISHED',HEAD=head,PR=pr['number'],url=pr['html_url'])),flush=True)
  row=run('own-lap-ONCE',['node','tools/ticket.mjs','lap',str(pr['number']),'--by','garment visible increment'],allow_nonzero=True);source(head,False);text=(out/'own-lap-ONCE.log').read_text();lap_acquired=row['result']['returncode']==0 and f"lap/pr-{pr['number']} taken"in text
  if lap_acquired:assert len(val('ls-remote','--heads','origin','refs/heads/lap/pr-'+str(pr['number'])).split())==2
 except BaseException as e:error=repr(e)
 source_error=None
 try:actual=source(val('rev-parse','HEAD'),val('rev-parse','HEAD')==auth['base'])
 except BaseException as e:actual=None;source_error=repr(e)
 resources=guard.pair(before,guard.snapshot())
 if not inflight and all(r['cleanup']['cleanup_complete']for r in rows):shutil.rmtree(scratch)
 passed=error is None and source_error is None and bool(pr)and resources['accepted']and not scratch.exists()
 closed=dict(passed=passed,error=error,source_error=source_error,source=actual,HEAD=head,PR_number=pr['number']if pr else None,PR_url=pr['html_url']if pr else None,own_lap_acquired=lap_acquired,ledger=rows,resources=resources,owned_TMPDIR_removed=not scratch.exists(),all_four_ran_on_final_metadata_TREE=False,qualified_gate=auth['gate'],metadata_bridge=auth['bridge'],ticket_state_changes=False,CI_dispatched=False,merged=False,production_changed=False)
 save(out/'CLOSED.json',closed);print(json.dumps(dict(passed=passed,error=error,HEAD=head,PR=closed['PR_number'])));return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
