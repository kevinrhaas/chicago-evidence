Otis and Hans had visible gaps in their shirts and trousers at lower scene detail. The active lower-detail assets now retain fuller reviewed garments while preserving their existing bodies, rigs, images and animations.

Validation:

- All 1,163 distinct local checks and 402 self-tests passed on tree `14f4256` in 328.462/366.547/487.377/521.594 seconds across four parts, under the original 600-second caps and source/resource/cleanup guards.
- The final recipe caption and current derivation hash have a finite metadata bridge with fresh original regeneration and affected checks. All four admitted asset hashes and the other twenty human payloads remain exact. All four parts have not run on the later metadata tree; fresh CI tests the exact committed source.
- The original all-24 desktop/phone human fixture passed. Otis/Hans WEB LOD3 costs are 564,628/551,488 bytes and 13,679/13,635 triangles, each with nine draws.
- Committed HEAD `79e302ee4b` passes five QA checks, whitespace and native publish/check. Fresh world/frame/memory checks, continuous fit and photographic review remain pending. The broader transport work stays open.
