Otis and Hans had visible gaps in their shirts and trousers at lower scene detail. The active lower-detail assets now retain fuller reviewed garments while preserving their existing bodies, rigs, images and animations.

Validation:

- The local four-part gate covers 1,163 distinct checks and 402 self-tests on tree `14f4256`, under the original 600-second caps and source/resource/cleanup guards. Actual final timings will be bound after successful closure.
- The final recipe caption and current derivation hash have a finite metadata bridge with fresh original regeneration and affected checks. All four admitted asset hashes and the other twenty human payloads remain exact; all four parts have not run on the later metadata tree.
- The original all-24 desktop/phone human fixture passed. Otis/Hans WEB LOD3 costs are 564,628/551,488 bytes and 13,679/13,635 triangles, each with nine draws.
- Actual committed-HEAD QA and native publish/check results will be bound before the ready PR is created. Fresh CI, world/frame/memory checks, continuous fit and photographic review remain pending. The broader transport work stays open.
