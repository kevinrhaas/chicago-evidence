from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,shutil,stat,subprocess,sys
G=Path('/workspace/chicago-driver-garment-projected-20261104');P=Path('/workspace/chicago-pr1700-memory-baseline-ff1827-20261104');APP=P/'chicago/4d'
OUT=Path('/workspace/.cloud-setup/transport-current-20261103/actual-pr1700-ff-parent-mobile-memory-control-01');BASE='ff1827f94a7c05cc7e5802be88f38b8193f4d2ac'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
save=lambda p,j:Path(p).write_text(json.dumps(j,indent=2)+'\n')
def main():
 assert __debug__ and not P.exists()and not OUT.exists()
 lock=open('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 spec=importlib.util.spec_from_file_location('guard','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
 before=guard.snapshot();assert guard.check(before)['accepted'];OUT.mkdir();scratch=OUT/'native-tmp';scratch.mkdir()
 env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(scratch),PW_EXECUTABLE='/workspace/.cloud-setup/transport-browser141-20261103/chromium_headless_shell-1194/chrome-linux/headless_shell')
 for key in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR','CHECK_PART','BASE','CHECK_TIMINGS']:env.pop(key,None)
 meta=dict(env,GIT_NO_LAZY_FETCH='1')
 def git(repo,*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(repo),*a],env=meta,timeout=45)
 def profile(repo):
  tree=git(repo,'write-tree').decode().strip();return dict(HEAD=git(repo,'rev-parse','HEAD').decode().strip(),TREE=tree,APP=git(repo,'rev-parse',tree+':chicago/4d').decode().strip(),semantic_index_sha256=hashlib.sha256(git(repo,'ls-files','--stage','-z')).hexdigest(),dirty=git(repo,'status','--porcelain').decode())
 original=profile(G);assert original['HEAD']=='79e302ee4b8648b2b89e81ef504049010de4cb7e'and not original['dirty']
 P.mkdir();git(P,'init','-q');(P/'.git/objects/info/alternates').write_text(str(G/'.git/objects')+'\n')
 for k,v in [('gc.auto','0'),('maintenance.auto','false'),('remote.origin.url','https://github.com/kevinrhaas/chicago.git'),('remote.origin.fetch','+refs/heads/*:refs/remotes/origin/*'),('remote.origin.promisor','true'),('remote.origin.partialclonefilter','blob:none')]:git(P,'config',k,v)
 dirs=git(G,'ls-tree','-z','-d','--name-only',BASE+':chicago/4d').decode().split('\0');paths=['.github','chicago/pre_fire_v1','chicago/prairie_1904_v1','site','chicago/4d/docs/RESEARCH/glessner-v4-recovery']+['chicago/4d/'+d for d in dirs if d and d!='docs']
 git(P,'sparse-checkout','set','--cone',*paths)
 ledger=[];error=None;meter=None;baseline=None
 def run(name,cmd,cap,cwd,allow_nonzero=False):
  rb=guard.snapshot();assert guard.check(rb)['accepted'];prefix=OUT/name;save(OUT/'STATE.json',dict(active=name,owner_pid=os.getpid(),ledger=ledger))
  subprocess.run([sys.executable,'/workspace/.cloud-setup/transport-supervise.py','--prefix',str(prefix),'--cwd',str(cwd),'--timeout',str(cap),'--',*cmd],env=env,check=False)
  r=json.loads(Path(str(prefix)+'.result.json').read_text());c=json.loads(Path(str(prefix)+'.cleanup.json').read_text());res=guard.pair(rb,guard.snapshot());ledger.append(dict(name=name,result=r,cleanup=c,resources=res));save(OUT/'LEDGER.json',ledger)
  assert not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==cap and r['timeout_override_reason']is None
  assert c['cleanup_complete']and not c['remaining_owned_children']and res['accepted']
  if not allow_nonzero:assert r['returncode']==0,name
  assert profile(G)==original,'Public source G changed';return r
 try:
  run('materialize-ff-native-inputs',['git','-c','gc.auto=0','-c','maintenance.auto=false','switch','--detach',BASE],120,P)
  baseline=profile(P);assert baseline['HEAD']==BASE and not baseline['dirty']
  for rel in git(P,'ls-files','-z').decode().split('\0'):
   if not rel:continue
   f=P/rel
   if not f.exists()or not stat.S_ISREG(f.lstat().st_mode)or f.stat().st_size<1048576:continue
   fd=os.open(f,os.O_RDONLY|os.O_NOFOLLOW)
   try:os.posix_fadvise(fd,0,0,os.POSIX_FADV_DONTNEED)
   finally:os.close(fd)
  run('native-publish',['bash','tools/publish.sh'],180,APP);assert profile(P)==baseline
  run('published-check',['node','tools/check_published.mjs'],120,APP);assert profile(P)==baseline
  assert json.loads((P/'site/4d/build.json').read_text())['version']==BASE[:10]
  result=run('original1904-mobile-memory-ONCE',['node','tools/measure_memory.mjs','--gate','--year','1904','--only','mobile','--json',str(OUT/'memory-1904-mobile.json')],600,APP,True);assert profile(P)==baseline
  meter=json.loads((OUT/'memory-1904-mobile.json').read_text());row=meter['rows'][0];assert row['year']=='1904'and row['viewport']=='mobile'and row['keepGeometry']is False and row['tier']=='light'
  assert len(meter['rows'])==1 and meter['measured']['build']==BASE[:7]and row['errors']==[]and row['residency']['pending']==0
 except BaseException as e:error=repr(e)
 resources=guard.pair(before,guard.snapshot());safe=all(r['cleanup']['cleanup_complete']and not r['cleanup']['remaining_owned_children']for r in ledger)
 if safe:shutil.rmtree(scratch)
 source_ok=profile(G)==original and(baseline is None or profile(P)==baseline)
 closed=dict(status='EXACT_FF_ORIGINAL_MOBILE_MEMORY_CONTROL_COMPLETE'if error is None and source_ok and resources['accepted']else'CONTROL_NONPASS_NO_AUTOMATIC_RETRY',error=error,baseline_source=baseline,public_G_before=original,public_G_after=profile(G),sources_unchanged=source_ok,reading=meter,original400MiB_limit_bytes=419430400,control_memory_PASS=(meter['rows'][0]['totals']['total']<=419430400)if meter else None,ledger=ledger,resources=resources,owned_TMPDIR_removed=not scratch.exists(),PR79_rerun=False,budget_changes=False)
 save(OUT/'CLOSED.json',closed);print(json.dumps(dict(status=closed['status'],error=error,total=meter['rows'][0]['totals']['total']if meter else None,memory_PASS=closed['control_memory_PASS'])));return 0 if error is None and source_ok and resources['accepted']else 1
if __name__=='__main__':raise SystemExit(main())
