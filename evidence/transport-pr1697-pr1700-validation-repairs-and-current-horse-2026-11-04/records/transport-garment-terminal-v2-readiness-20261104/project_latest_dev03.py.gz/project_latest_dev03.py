from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,subprocess,sys
OUT=Path(__file__).parent/'projection-03';OUT.mkdir()
G=Path('/workspace/chicago-driver-garment-validation-20261104');P=Path('/workspace/chicago-driver-garment-projected-20261104');assert P.is_dir() and (P/'.git').is_dir()
lock=open('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('guard','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard);before=guard.snapshot();assert guard.check(before)['accepted']
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');env.pop('GIT_NO_LAZY_FETCH',None)
def git(repo,*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(repo),*a],env=env,timeout=120)
source=json.loads((Path(__file__).parent/'STATIC-REPAIRED-SOURCE.json').read_text());assert git(G,'write-tree').decode().strip()==source['TREE'];assert not git(G,'diff','--name-only').strip()
assert git(P,'rev-parse','HEAD').decode().strip()=='ff1827f94a7c05cc7e5802be88f38b8193f4d2ac'; assert not git(P,'status','--porcelain').strip()
for k,v in [('gc.auto','0'),('maintenance.auto','false'),('remote.origin.promisor','true'),('remote.origin.partialclonefilter','blob:none'),('user.name','Chicago steward'),('user.email','steward@localhost')]:git(P,'config',k,v)
(P/'.git/objects/info/alternates').write_text(str(G/'.git/objects')+'\n');git(P,'config','remote.origin.url','https://github.com/kevinrhaas/chicago.git');git(P,'config','remote.origin.fetch','+refs/heads/*:refs/remotes/origin/*')
ledger=[];error=None
try:
 def run(name,cmd):
  prefix=OUT/name
  subprocess.run([sys.executable,'/workspace/.cloud-setup/transport-supervise.py','--prefix',str(prefix),'--cwd',str(P),'--timeout','120','--',*cmd],env=env,check=False)
  result=json.loads(Path(str(prefix)+'.result.json').read_text());cleanup=json.loads(Path(str(prefix)+'.cleanup.json').read_text());ledger.append(dict(name=name,result=result,cleanup=cleanup));assert result['returncode']==0 and not result['timed_out'];assert cleanup['cleanup_complete']and not cleanup['remaining_owned_children']
 run('fetch-dev',['git','-c','gc.auto=0','-c','maintenance.auto=false','fetch','--no-tags','--filter=blob:none','--depth=64','--refetch','origin','ff1827f94a7c05cc7e5802be88f38b8193f4d2ac'])
 base=git(P,'rev-parse','refs/remotes/origin/dev').decode().strip();(OUT/'BASE.json').write_text(json.dumps(dict(DEV=base),indent=2)+'\n')
 assert git(P,'rev-parse','HEAD').decode().strip()==base
 assert not git(P,'status','--porcelain').strip()
 assert subprocess.run(['git','-C',str(P),'merge-base','--is-ancestor',source['HEAD'],base],env=env,timeout=30).returncode==0
 run('apply-owned',['git','apply','--3way','--index',str(Path(__file__).parent/'STATIC-REPAIRED.patch')])
 assert not git(P,'ls-files','-u').strip() and not git(P,'diff','--name-only').strip()
 baseline=json.loads((Path('/workspace/.cloud-setup/transport-garment-terminal-v2-adoption-20261104')/'BASELINE-HUMAN24.json').read_text());fixed=json.loads((Path(__file__).parent/'FIXED-OUTPUT-HASHES.json').read_text())
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 for f,old in baseline.items():
  current=sha(git(P,'show',base+':chicago/4d/'+f));assert current==old,'Later DEV human payload changed: '+f
  assert sha((P/'chicago/4d'/f).read_bytes())==fixed.get(f,current),f
 assert git(G,'write-tree').decode().strip()==source['TREE']and not git(G,'diff','--name-only').strip()
except BaseException as e:error=repr(e)
after=guard.snapshot();pair=guard.pair(before,after)
record=dict(passed=error is None and pair['accepted'],error=error,repo=str(P),DEV=locals().get('base'),ledger=ledger,original_G_source=source,original_G_preserved=git(G,'write-tree').decode().strip()==source['TREE'],resources=pair,no_commit_push_or_PR=True)
(OUT/'CLOSED.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(0 if record['passed']else 1)
