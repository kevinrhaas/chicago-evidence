"""One ROOT-authorized metadata correction after the complete qualified gate."""
from pathlib import Path
import copy,fcntl,hashlib,importlib.util,json,os,shutil,subprocess,sys
HERE=Path(__file__).parent
ROOT=Path('/workspace/chicago-driver-garment-projected-20261104');APP=ROOT/'chicago/4d'
GATE=Path('/workspace/.cloud-setup/transport-current-20261103/actual-garment-terminal-v2-projected-fourpart-03/CLOSED.json')
OUT=Path('/workspace/.cloud-setup/transport-current-20261103/actual-garment-terminal-v2-caption-bridge-01')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
save=lambda p,j:Path(p).write_text(json.dumps(j,indent=2)+'\n')
def main():
 assert __debug__ and not OUT.exists()
 gate=json.loads(GATE.read_text());qualified=gate['source_before']
 assert gate['status']=='PASS_ALL_FOUR_NATIVE_CHECK_PARTS_SAME_STAGED_SOURCE'
 assert gate['source_after']==qualified and qualified['TREE']=='14f42560097b085bb4e9ee2237faf8e368f43089'
 assert gate['resources']['accepted']and gate['owned_TMPDIR_cleanup_complete']and len(gate['ledger'])==4
 for row in gate['ledger']:
  r=row['result'];assert r['returncode']==0 and not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==600 and r['timeout_override_reason']is None
  assert row['resources']['accepted']and row['source_before']==row['source_after']==qualified and row['cleanup']['cleanup_complete']and not row['cleanup']['remaining_owned_children']
  assert sha(row['log'])==row['log_sha256']
 lock=open('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 spec=importlib.util.spec_from_file_location('guard','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0');env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None)
 meta=dict(env,GIT_NO_LAZY_FETCH='1')
 def git(*a):return subprocess.check_output(['git','--no-optional-locks','-C',str(ROOT),*a],env=meta,timeout=45)
 def profile():
  tree=git('write-tree').decode().strip();return dict(HEAD=git('rev-parse','HEAD').decode().strip(),TREE=tree,APP=git('rev-parse',tree+':chicago/4d').decode().strip(),semantic_index_sha256=hashlib.sha256(git('ls-files','--stage','-z')).hexdigest())
 assert profile()==qualified and not git('diff','--name-only').strip()and not git('ls-files','--others','--exclude-standard').strip()
 before=guard.snapshot();assert guard.check(before)['accepted'];OUT.mkdir();scratch=OUT/'native-tmp';scratch.mkdir();env['TMPDIR']=str(scratch)
 recipepath='data/humans/animations/driver-garment-retention-v2.json';derivpath='data/humans/animations/driver-garment-retention-v2.derivation.json';bridgepath='data/humans/animations/driver-garment-retention-v2.metadata-bridge.json'
 old_recipe=json.loads((APP/recipepath).read_text());old_deriv=json.loads((APP/derivpath).read_text());old_recipe_sha=sha(APP/recipepath);old_deriv_sha=sha(APP/derivpath)
 all_assets={str(p.relative_to(APP)):sha(p)for p in(APP/'assets/humans').rglob('*.glb')};assert len(all_assets)==24
 caption=json.loads((HERE/'POST-GATE-CAPTION-CORRECTION-PLAN.json').read_text())['replacement_caption']
 rows=[];error=None;final=None
 def run(name,cmd,cap):
  prefix=OUT/name;rb=guard.snapshot();assert guard.check(rb)['accepted']
  subprocess.run([sys.executable,'/workspace/.cloud-setup/transport-supervise.py','--prefix',str(prefix),'--cwd',str(APP),'--timeout',str(cap),'--',*cmd],env=env,check=False)
  r=json.loads(Path(str(prefix)+'.result.json').read_text());c=json.loads(Path(str(prefix)+'.cleanup.json').read_text());pair=guard.pair(rb,guard.snapshot());rows.append(dict(name=name,result=r,cleanup=c,resources=pair));save(OUT/'LEDGER.json',rows)
  assert r['returncode']==0 and not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==cap and r['timeout_override_reason']is None
  assert c['cleanup_complete']and not c['remaining_owned_children']and pair['accepted']
 try:
  new=copy.deepcopy(old_recipe);new['acceptance_scope']=caption;save(APP/recipepath,new)
  run('fresh-original-regeneration',['python3','tools/human_garment_retention.py','--output',str(OUT/'generated')],120)
  receipt=json.loads((OUT/'generated/DERIVATION.json').read_text());check=copy.deepcopy(receipt);check['recipe_sha256']=old_deriv['recipe_sha256'];assert check==old_deriv
  assert receipt['recipe_sha256']==sha(APP/recipepath)
  for r in receipt['files']:assert(OUT/'generated'/r['file']).read_bytes()==(APP/r['file']).read_bytes()
  shutil.copyfile(OUT/'generated/DERIVATION.json',APP/derivpath)
  for name,cmd,cap in [('terminal',['python3','tools/human_garment_retention.py','--check'],120),('chain',['python3','tools/test_human_garment_retention.py'],120),('human-schema',['python3','tools/human_contract.py','--check'],5),('changelog',['node','tools/changelog-entries.mjs','--check'],5)]:run(name,cmd,cap)
  assert all(sha(APP/f)==h for f,h in all_assets.items())
  git('add','--','chicago/4d/'+recipepath,'chicago/4d/'+derivpath)
  pre_bridge=profile();diff=git('diff-tree','--no-commit-id','--name-only','-r',qualified['TREE'],pre_bridge['TREE']).decode().splitlines();assert set(diff)=={'chicago/4d/'+recipepath,'chicago/4d/'+derivpath}
  record=dict(schema='terminal_garment_metadata_caption_bridge_v1',qualified_fourpart_source=qualified,qualified_fourpart_closed_sha256=sha(GATE),qualified_fourpart_status=gate['status'],original_caps_unchanged=True,all_four_ran_on_final_metadata_TREE=False,recipe_before_sha256=old_recipe_sha,recipe_after_sha256=sha(APP/recipepath),only_recipe_field_changed='acceptance_scope',old_acceptance_scope=old_recipe['acceptance_scope'],new_acceptance_scope=caption,derivation_before_sha256=old_deriv_sha,derivation_after_sha256=sha(APP/derivpath),only_generated_receipt_field_changed='recipe_sha256',original_native_and_historical_receipts_preserved=True,all_24_asset_payloads_exact=True,all_code_runtime_thresholds_and_other_source_exact=True,expected_four_payload_hashes_unchanged={r['file']:r['output_sha256']for r in new['terminals']},pre_bridge_metadata_source=pre_bridge,actual_original_producer_and_affected_checks=[dict(name=r['name'],command=r['result']['command'],seconds=r['result']['seconds'],cap_seconds=r['result']['effective_timeout_seconds'])for r in rows],scope='Finite metadata bridge only: update the stale preparation caption and regenerate the current receipt hash with the original producer. No all-four-on-final-tree claim; fresh exact-source CI and world/frame/memory/photographic acceptance remain pending.')
  save(APP/bridgepath,record);git('add','--','chicago/4d/'+bridgepath);git('diff','--cached','--check')
  final=profile();assert set(git('diff-tree','--no-commit-id','--name-only','-r',qualified['TREE'],final['TREE']).decode().splitlines())=={'chicago/4d/'+p for p in[recipepath,derivpath,bridgepath]}
  assert not git('diff','--name-only').strip()and not git('ls-files','--others','--exclude-standard').strip()
 except BaseException as e:error=repr(e)
 resources=guard.pair(before,guard.snapshot());safe=all(r['cleanup']['cleanup_complete']and not r['cleanup']['remaining_owned_children']for r in rows)
 if safe:shutil.rmtree(scratch)
 passed=error is None and resources['accepted']and not scratch.exists()
 closed=dict(passed=passed,error=error,source_before=qualified,source_after=final,gate_sha256=sha(GATE),metadata_bridge_file=bridgepath,metadata_bridge_sha256=sha(APP/bridgepath)if(APP/bridgepath).exists()else None,all_four_ran_on_final_metadata_TREE=False,ledger=rows,resources=resources,owned_TMPDIR_removed=not scratch.exists(),no_asset_install_commit_push_or_PR=True)
 save(OUT/'CLOSED.json',closed);save(HERE/'FINAL-CORRECTED-SOURCE.json',closed);print(json.dumps(dict(passed=passed,error=error,source=final)));return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
