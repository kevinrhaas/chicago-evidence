from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,subprocess,sys,time
ROOT=Path('/workspace/chicago-driver-garment-projected-20261104');APP=ROOT/'chicago/4d';OUT=Path(__file__).parent/'actual-readiness-02';OUT.mkdir()
lock=open('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('guard','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0');env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None)
scratch=OUT/'native-tmp';scratch.mkdir();env['TMPDIR']=str(scratch)
meta=dict(env,GIT_NO_LAZY_FETCH='1')
def git(*a):return subprocess.check_output(['git','--no-optional-locks','-C',str(ROOT),*a],env=meta,timeout=40)
assert not git('diff','--name-only').strip()and not git('ls-files','-u').strip()and not git('ls-files','--others','--exclude-standard').strip()
index=hashlib.sha256(git('ls-files','--stage','-z')).hexdigest();stepmap=json.loads((APP/'tools/step_isolation.json').read_text());before=guard.snapshot();assert guard.check(before)['accepted']
fixed=json.loads((Path(__file__).parent/'FIXED-OUTPUT-HASHES.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
steps=[('terminal-check',120,['python3','tools/human_garment_retention.py','--check']),('real-chain',120,['python3','tools/test_human_garment_retention.py']),('terminal-step-write-measurement',120,['node','tools/measure_step_isolation.mjs','--tool','tools/human_garment_retention.py']),('step-map-check',120,['node','tools/audit_step_isolation.mjs','--check']),('direct-check-coverage',120,['python3','tools/audit_check_gates.py','--gate','--quiet']),('writer-manifest-coverage',120,['node','tools/audit_manifest_coverage.mjs']),('changelog',5,['node','tools/changelog-entries.mjs','--check'])]
ledger=[];error=None
try:
 for name,cap,command in steps:
  rb=guard.snapshot();assert guard.check(rb)['accepted'];prefix=OUT/name
  (OUT/'STATE.json').write_text(json.dumps(dict(active=name,owner_pid=os.getpid(),ledger=ledger),indent=2)+'\n')
  subprocess.run([sys.executable,'/workspace/.cloud-setup/transport-supervise.py','--prefix',str(prefix),'--cwd',str(APP),'--timeout',str(cap),'--',*command],env=env,check=False)
  result=json.loads(Path(str(prefix)+'.result.json').read_text());cleanup=json.loads(Path(str(prefix)+'.cleanup.json').read_text());pair=guard.pair(rb,guard.snapshot());ledger.append(dict(name=name,result=result,cleanup=cleanup,resources=pair))
  assert result['returncode']==0 and not result['timed_out'],name+' failed'
  assert result['requested_timeout_seconds']==result['effective_timeout_seconds']==cap and result['timeout_override_reason']is None
  assert cleanup['cleanup_complete']and not cleanup['remaining_owned_children']and pair['accepted']
  assert hashlib.sha256(git('ls-files','--stage','-z')).hexdigest()==index
  assert not git('ls-files','--others','--exclude-standard').strip()
  if name=='exact-regeneration':
   for f,d in fixed.items():assert sha(OUT/'generated'/f)==d==sha(APP/f),'Expected output retarget refused: '+f
  if name=='terminal-step-write-measurement':
   actual=json.loads((APP/'tools/step_isolation.json').read_text());new=actual['tools'].pop('tools/human_garment_retention.py');assert new=={'wrote':[],'wrote_ignored':[]};actual['measured']=stepmap['measured'];assert actual==stepmap,'Existing step-map facts changed'
except BaseException as e:error=repr(e)
pair=guard.pair(before,guard.snapshot());changed=git('diff','--name-only').decode().splitlines();allowed={'chicago/4d/tools/step_isolation.json','chicago/4d/data/liberties.json','chicago/4d/docs/measurements/source_use_coverage.md'}
safe=not(set(changed)-allowed)and hashlib.sha256(git('ls-files','--stage','-z')).hexdigest()==index
if all(s['cleanup']['cleanup_complete']for s in ledger):
 import shutil
 shutil.rmtree(scratch)
record=dict(passed=error is None and safe and pair['accepted']and not scratch.exists(),error=error,ledger=ledger,allowed_generated_changes_only=safe,changed_paths=changed,resources=pair,owned_TMPDIR_removed=not scratch.exists(),no_commit_push_or_PR=True)
(OUT/'CLOSED.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(0 if record['passed']else 1)
