# Preserve owned garment work while integrating current DEV

Original23-path source is immutable at TREE5b0e0257df3685502337e04f62f23585e4fea61e and its saved OWNED.patch. Current G retains that base59ec and every owned change. Latest read-only remote DEV observation was ff1827f94a7c05cc7e5802be88f38b8193f4d2ac; resolve it again before integration. No latest-DEV checkout or merge has run.

After the horse owner closes and releases the canonical lock:

1. Capture repaired G index/tree and binary patch, assets24 hash manifest, fixed expected4 outputs and clean-WT/index evidence. Retain both old and repaired snapshots.
2. Fetch only current DEV commit metadata into isolated G storage with blob:none, bounded history sufficient to retain59ec ancestry; do not touch R/N refs or configuration. Record the actual DEV SHA and ancestor relationship.
3. Build a NEW isolated source projection based on that exact latest DEV commit. Give it an independent Git index/config/refs, read-only object alternates and no auto gc. Preserve G unchanged as recovery source. Materialize required native/compiler inputs only after resource checks.
4. Apply the full owned binary diff from59ec with three-way index application. Resolve only overlapping owned documentation, check.sh registration, licence and step-map/generated records. Preserve all later legitimate DEV changes. Do not reset, force-checkout, remove foreign files or retarget any expected payload hash. Refuse new asset/runtime/identity conflicts for review rather than choosing blindly.
5. Recheck the protected20 asset hashes against the latest DEV baseline as well as the original G baseline. If DEV legitimately changed a protected payload, retain DEV and report the changed baseline explicitly; never erase it to force the old manifest. Require the same four admitted candidate hashes or stop.
6. Run original standalone exact regeneration120s and actual real-chain test/write/timing measurement, regenerate original liberties mirror, and verify all resulting owned diffs. Retain previous native proofs as evidence for exact unchanged assets, not as a new-source full-gate claim.
7. Freeze the final projected tree before the first complete four-part source/native gate; each part retains its original600second cap. No commits, pushes, new PRs, ticket settlement or world/photo acceptance until required later gates.
