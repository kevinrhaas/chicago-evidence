// SPDX-License-Identifier: GPL-3.0-or-later
// PREPARED ONLY. This reads actual native rest geometry; no animation/fit is inferred.
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { register } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
const here = path.dirname(fileURLToPath(import.meta.url));
const sha = b => createHash('sha256').update(b).digest('hex');
const pinsPath = path.join(here, 'PINNED-INPUTS.json');
const pinsBytes = readFileSync(pinsPath), pins = JSON.parse(pinsBytes);
function verifyInputs() {
  assert.equal(sha(readFileSync(pinsPath)), sha(pinsBytes));
  for (const p of pins.files) {
    const b = readFileSync(p.path);
    assert.equal(b.length, p.bytes, p.path);
    assert.equal(sha(b), p.sha256, p.path);
  }
}
verifyInputs();
const args = process.argv.slice(2);
assert.equal(args.length, 4); assert.equal(args[0], '--asset'); assert.equal(args[2], '--out');
const asset = pins.assets[args[1]]; assert(asset, 'Explicit standing7ce/movingad9 selector');
const out = path.resolve(args[3]); assert(!existsSync(out), 'Fresh output only'); mkdirSync(out);
register(pathToFileURL(pins.native_vendor_loader), import.meta.url);
const T = await import('three'); assert.equal(T.REVISION, '185');
const { GLTFLoader } = await import('three/addons/loaders/GLTFLoader.js');
const { MeshoptDecoder } = await import('three/addons/libs/meshopt_decoder.module.js');
await MeshoptDecoder.ready;
const raw = readFileSync(asset.path); assert.equal(sha(raw), asset.sha256);
assert.equal(raw.readUInt32LE(0), 0x46546c67); assert.equal(raw.readUInt32LE(4), 2);
const doc = JSON.parse(raw.subarray(20, 20 + raw.readUInt32LE(12)).toString('utf8'));
assert.equal(doc.meshes.length, 3); assert.equal(doc.skins.length, 1);
// Same geometry-only material adapter as tools/measure_horse_support_domain.mjs.
// Original GLB bytes are passed unchanged; images/shader rendering are NOT exercised.
const loader = new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);
loader.register(() => ({name: 'CPU_POSE_ONLY_MATERIAL_ADAPTER', loadMaterial: async i =>
  new T.MeshBasicMaterial({side: doc.materials[i].doubleSided ? T.DoubleSide : T.FrontSide})}));
const parsed = await loader.parseAsync(raw.buffer.slice(raw.byteOffset, raw.byteOffset + raw.byteLength), '');
const scene = parsed.scene; scene.updateMatrixWorld(true);
assert.deepEqual(scene.position.toArray(), [0,0,0]); assert.deepEqual(scene.scale.toArray(), [1,1,1]);
assert.deepEqual(scene.quaternion.toArray(), [0,0,0,1]);
const meshes = []; scene.traverse(o => { if (o.isSkinnedMesh) meshes.push(o); });
assert.equal(meshes.length, 3);
const binding = JSON.parse(readFileSync(pins.hitch_binding));
const outputs = [], rows = [], meshesByID = new Map(); let totalVertices = 0, totalTriangles = 0;
const native = new T.Vector3();
function emit(name, bytes) {
  writeFileSync(path.join(out, name), bytes);
  const row = {file:name, bytes:bytes.length, sha256:sha(bytes)}; outputs.push(row); return row;
}
function binary(name, values, kind) {
  const bytes = Buffer.alloc(values.length * (kind === 'f64' ? 8 : 4));
  for(let i=0;i<values.length;i++) kind === 'f64' ? bytes.writeDoubleLE(values[i],i*8) : bytes.writeUInt32LE(values[i],i*4);
  return emit(name, bytes);
}
for (const mesh of meshes) {
  const association = parsed.parser.associations.get(mesh);
  assert(association && Number.isInteger(association.meshes));
  const mi = association.meshes, pi = association.primitives ?? 0;
  assert.equal(pi, 0); assert(!meshesByID.has(mi));
  const declared = doc.meshes[mi].primitives[pi], g = mesh.geometry;
  assert.equal(declared.mode ?? 4, 4); assert(g.index, 'Original indexed triangle stream required');
  const count = g.attributes.position.count, ic = g.index.count; assert.equal(ic % 3, 0);
  assert.equal(count, doc.accessors[declared.attributes.POSITION].count);
  assert.equal(ic, doc.accessors[declared.indices].count);
  assert.equal(mesh.skeleton.bones.length, 26);
  assert.deepEqual(mesh.skeleton.bones.map(b => b.name), binding.joint_names);
  mesh.skeleton.update();
  const vertices = [], indices = [], triangles = [], min=[Infinity,Infinity,Infinity], max=[-Infinity,-Infinity,-Infinity];
  for(let i=0;i<count;i++) {
    mesh.getVertexPosition(i,native).applyMatrix4(mesh.matrixWorld);
    const v=native.toArray(); assert(v.every(Number.isFinite)); vertices.push(...v);
    for(let k=0;k<3;k++){min[k]=Math.min(min[k],v[k]);max[k]=Math.max(max[k],v[k]);}
  }
  for(let i=0;i<ic;i++) {const id=g.index.getX(i); assert(Number.isInteger(id)&&id>=0&&id<count);indices.push(id);triangles.push(...vertices.slice(id*3,id*3+3));}
  const files={vertices:binary(`mesh-${mi}-rest-world-vertices.f64le`,vertices,'f64'),
    original_indices:binary(`mesh-${mi}-source-indices.u32le`,indices,'u32'),
    triangles:binary(`mesh-${mi}-rest-world-triangles.f64le`,triangles,'f64')};
  const materialName=doc.materials[declared.material]?.name;
  const isBody=count===binding.source_body_vertex_count&&materialName===binding.source_body_material_name;
  const joints=mesh.skeleton.bones.map((b,j)=>({index:j,name:b.name,
    local_matrix:b.matrix.toArray(),world_matrix:b.matrixWorld.toArray(),
    world_position:new T.Vector3().setFromMatrixPosition(b.matrixWorld).toArray(),
    inverse_bind_matrix:mesh.skeleton.boneInverses[j].toArray(),
    parent_name:b.parent?.name??null}));
  for(const j of joints) for(const k of ['local_matrix','world_matrix','world_position','inverse_bind_matrix']) assert(j[k].every(Number.isFinite));
  const row={mesh:mi,primitive:pi,material_name:materialName,is_BODY:isBody,vertices:count,triangles:ic/3,
    min_xyz_m:min,max_xyz_m:max,matrix_world:mesh.matrixWorld.toArray(),
    bind_matrix:mesh.bindMatrix.toArray(),bind_matrix_inverse:mesh.bindMatrixInverse.toArray(),joints,files};
  rows.push(row);meshesByID.set(mi,{row,vertices,indices});totalVertices+=count;totalTriangles+=ic/3;
}
rows.sort((a,b)=>a.mesh-b.mesh);
assert.equal(totalVertices,12838); assert.equal(totalTriangles,17390);
const bodies=[...meshesByID.values()].filter(x=>x.row.is_BODY); assert.equal(bodies.length,1);
const body=bodies[0]; assert.equal(body.row.vertices,5595); assert.equal(body.row.triangles,9794);
const draftGuides=[];
for(const [group, refs] of Object.entries(binding.surface_guides)) for(const [index,ref] of refs.entries()) {
  assert.deepEqual(body.indices.slice(ref.face*3,ref.face*3+3),ref.indices,'Actual existing BODY face correspondence');
  assert.equal(ref.barycentric.length,3); assert(ref.barycentric.every(x=>Number.isFinite(x)&&x>=0&&x<=1));
  assert(Math.abs(ref.barycentric.reduce((a,b)=>a+b,0)-1)<1e-12,'Existing weights form barycentric point');
  const point=new T.Vector3();
  ref.indices.forEach((id,k)=>point.addScaledVector(new T.Vector3(...body.vertices.slice(id*3,id*3+3)),ref.barycentric[k]));
  draftGuides.push({group,index,source_reference:ref,measured_unoffset_surface_world_m:point.toArray(),
    scope:'EXISTING_DRAFT_GUIDE_ONLY_NOT_A_RIDING_SOCKET'});
}
assert.equal(draftGuides.length,26);
const report={schema:'current26-native-rest-intake-v1',status:'NATIVE_REST_MEASUREMENT_ONLY_NOT_FIT_QUALIFICATION',
  asset_key:args[1],asset_sha256:asset.sha256,pins_sha256:sha(pinsBytes),native_three_revision:T.REVISION,
  actual_node_version:process.version,actual_node_versions:process.versions,
  clips_declared:parsed.animations.map(c=>({name:c.name,duration_s:c.duration})),
  pose:'GLTF loader initial serialized rest; no mixer, animation, skeleton.pose(), root repositioning or scale changes',
  geometry_only_material_adapter:true,images_or_pixels_reviewed:false,actual_skin_joint_count:26,
  total_vertices:totalVertices,total_triangles:totalTriangles,meshes:rows,draft_guides:draftGuides,
  surface_stream_layout:'All triangles, including hair/eyes; face f uses source indices[3f:3f+3] and nine F64LE world coordinates; source vertex IDs retained',
  saddle_anchor:null,seat_anchor:null,stirrup_anchor:null,rider_fit_or_loaded_contact:false,
  old_6e9_inputs_used:false,asset_body_rig_texture_changed:false,attribution:pins.current_source_attribution,outputs};
verifyInputs();emit('REST-WITNESSES.json',Buffer.from(JSON.stringify(report,null,2)+'\n'));
console.log(`Current26 rest intake measured ${totalTriangles} original triangles, 26 joints and ${draftGuides.length} draft-guide witnesses; fit remains UNRUN`);
