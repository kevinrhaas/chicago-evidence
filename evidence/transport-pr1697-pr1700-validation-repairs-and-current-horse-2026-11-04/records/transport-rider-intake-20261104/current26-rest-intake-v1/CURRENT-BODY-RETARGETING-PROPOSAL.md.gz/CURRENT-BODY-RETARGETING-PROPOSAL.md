# Current horse intake before fitting

Prepared, not executed. The historical 406 source/caller remains frozen UNRUN.
This proposal is a separate input family, not a 6e9 replacement in the old mode.

The unchanged Sevket standing 7ce84d and moving ad9dc0 body/rest/skin serialized
streams match. Each has 12,838 vertices, 17,390 triangles, 26 named joints. The
BODY is the actual 5,595-vertex / 9,794-triangle Material_HorseMain4k00.png primitive;
all3 primitives including hair/eyes remain in subsequent horse collision scope.
Neither asset declares a rider seat/saddle/stirrup socket. Old 6e9 seat coordinates,
15-joint indices, skin weights, fixed surface anchors and old mesh counts are
not portable. The old horse actually has 14,172 triangles and is a distinct CC0
procedural proxy; it is never a fallback for this intake.

The current source is Horse by sevketkabatas, CC-BY 4.0, Sketchfab 53a6eb7..., source
41acd9be... . Attribution/changes notice must accompany any derivative tack fitted
to it. New original hardware construction may retain its CC0 license; GPL predicate
code remains GPL. Do not relabel the horse CC0 or promote the reference rig's
antemeossa attribution into a copied current socket. Body, textures,26-joint rig,
clip data and current APP remain immutable throughout this intake.

The existing draft-hitch interface verifies BODY identity and the 26 joint order
then uses source face IDs/barycentrics through actual getVertexPosition. Its
26 trace/cheek guide references are draft witnesses, not a riding-anchor grant.
This intake rechecks their exact face/indices and records native unoffset surface
positions. It does not copy old draft band/girth coordinates into a saddle.

After Root's explicit lane handoff, copy ROOT-GO-UNBOUND-TEMPLATE.json to a NEW
ROOT-ACTUAL-GO.json, set approved/canonical_lane_released true and bind
preparation_manifest_sha256 to the reviewed frozen PREPARATION-MANIFEST.json
SHA256 (template placeholder is fatal), then run once:

    bash /workspace/.cloud-setup/transport-rider-intake-20261104/current26-rest-intake-v1/run_owned_once.sh \
      /workspace/.cloud-setup/transport-rider-intake-20261104/current26-rest-intake-v1/ROOT-ACTUAL-GO.json \
      /workspace/.cloud-setup/transport-rider-intake-20261104/current26-rest-intake-v1/actual-rest-01

Each original native readback has 60s, one CPU by inherited OS affinity plus one math thread, no automatic retry;
180s enclosing orchestration accounts for two separate readbacks. Canonical flock,
same 3f49 resource epoch and original floors, source/vendor before/after pins,
supervisor descendant cleanup and actual result receipts are required. The Node
reader is native Three 0.185.1/GLTFLoader with the existing CPU-only material adapter:
no image decode or rendering is exercised, geometry/skin input bytes unchanged.
No mixer/action/pose override/root scale is applied. Every vertex, original face
index and triangle is emitted via native getVertexPosition in serialized rest,
with 26 joint local/world/inverse-bind matrices and per-mesh bounds. Complete
standing/moving native rest outputs must match; emitted stream files are reread
and rehashed before the paired result. Any mismatch stops before fit.

Next bounded decision AFTER measurements: inspect actual BODY rest surfaces and
joint distribution, select explicit face IDs+barycentric witnesses for saddle
underside/girth/headgear contact and intended rider support regions; record why
those faces, not guessed coordinates. Check the actual quiet/walk pose envelope
separately before any moving fit. Rest equality is not dynamic contact proof.
The old hardware provides construction methods only: ten-sided footplate partition,
exact lower-arch join and original collision/topology/contact predicates. Its
old2/3/4 segment coordinates and old protected nine transforms are not retained
as a current-fit claim. A new builder must emit independently bound current gear
placement/skin weights; no provisional seat/skin socket is admitted here.

Keep historical cf148 / 88 crossings and all 29 self/contact assertions as old-input
negative controls; do not reinterpret their coordinates as current positives.
When a complete 29-part current candidate exists, execute all 406 pairs (including
36 fixed/fixed), and every affected hardware surface against all 17,390 current
horse triangles under unchanged strict predicates/caps. Any altered part cohort
requires an explicit new coverage count. The historical original 1800 / 30 / 60 / 900
qualification caps remain future qualification caps, not a reason to run oldproxy
now. This intake does not run that qualification, generate/fit gear, add a rider,
replace assets, authorize new gait or claim photo/loaded riding acceptance.
