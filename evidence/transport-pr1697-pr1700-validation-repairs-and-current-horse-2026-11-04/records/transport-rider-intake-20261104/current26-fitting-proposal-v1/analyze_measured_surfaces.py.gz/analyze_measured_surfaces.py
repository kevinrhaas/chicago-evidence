# Static analysis of Root's already-measured native rest stream; no model loader/skin/generation.
from pathlib import Path
import hashlib,json,struct,math
P=Path(__file__).resolve().parent
I=Path('/workspace/.cloud-setup/transport-rider-intake-20261104/current26-rest-intake-v1')
D=I/'actual-rest-01/standing7ce-rest'
h=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((D/'REST-WITNESSES.json').read_text());body=next(m for m in r['meshes']if m['is_BODY'])
for f in body['files'].values():
 b=(D/f['file']).read_bytes();assert h(b)==f['sha256']and len(b)==f['bytes']
raw=(D/body['files']['triangles']['file']).read_bytes();A=list(struct.iter_unpack('<9d',raw));rawi=(D/body['files']['original_indices']['file']).read_bytes();indices=list(struct.iter_unpack('<3I',rawi));assert len(A)==len(indices)==9794

def intersects(axis, target, uvaxes):
 # These are line/surface intersections of the already emitted F64 world coordinates.
 # No projection/nearest-vertex snapping; retain the exact original face and weights.
 found=[];ax0,ax1=uvaxes
 for face,t in enumerate(A):
  v=[t[j:j+3]for j in(0,3,6)]
  a,b,c=v;u0,v0=target;det=(b[ax1]-c[ax1])*(a[ax0]-c[ax0])+(c[ax0]-b[ax0])*(a[ax1]-c[ax1])
  if det==0:continue
  w0=((b[ax1]-c[ax1])*(u0-c[ax0])+(c[ax0]-b[ax0])*(v0-c[ax1]))/det
  w1=((c[ax1]-a[ax1])*(u0-c[ax0])+(a[ax0]-c[ax0])*(v0-c[ax1]))/det;w=[w0,w1,1-w0-w1]
  if min(w)<0 or max(w)>1:continue
  p=[sum(w[j]*v[j][k]for j in range(3))for k in range(3)]
  e=[b[k]-a[k]for k in range(3)];f=[c[k]-a[k]for k in range(3)];n=[e[1]*f[2]-e[2]*f[1],e[2]*f[0]-e[0]*f[2],e[0]*f[1]-e[1]*f[0]];length=math.sqrt(sum(x*x for x in n))
  if length==0:continue
  found.append({'face':face,'indices':indices[face],'barycentric':w,'surface_world_m':p,'source_winding_unit_normal':[x/length for x in n]})
 return sorted(found,key=lambda x:x['surface_world_m'][axis])
rows=[]
for z in[-.5,-.4,-.3,-.2,-.1,0,.1,.2,.3,.4]:
 for x in[-.16,-.08,0,.08,.16]:
  hits=intersects(1,(x,z),(0,2));rows.append({'query':'vertical_y','xz_m':[x,z],'all_intersections':hits})
# A few torso crosssection rows only, not a fitted girth path.
cross=[]
for z in[0,.1,.2,.3]:
 for y in[.85,.95,1.05,1.15,1.25,1.35,1.4]:
  cross.append({'query':'horizontal_x','yz_m':[y,z],'all_intersections':intersects(0,(y,z),(1,2))})
res={'schema':'current26-measured-rest-surface-candidate-analysis-v1','status':'STATIC_DATA_ANALYSIS_NOT_FIT','source_report_sha256':h((D/'REST-WITNESSES.json').read_bytes()),'body_triangles_sha256':h(raw),'vertical_queries':rows,'torso_crosssection_queries':cross,'body_or_rig_modified':False,'native_or_generation_or_tests_executed':False}
(P/'MEASURED-SURFACE-CANDIDATES.json').write_text(json.dumps(res,indent=2)+'\n')
for q in rows:
 if q['xz_m'][0]in(0,.16):
  hits=q['all_intersections'];print('xz',q['xz_m'],'y/faces',[(round(a['surface_world_m'][1],5),a['face'],round(a['source_winding_unit_normal'][1],3))for a in hits])
print('SIDE z.2',[(q['yz_m'],[(round(a['surface_world_m'][0],5),a['face'])for a in q['all_intersections']])for q in cross if q['yz_m'][1]==.2])

# Candidate girth station: reconstructed design choice z=+0.20m, behind the
# measured fore-shoulder joint z=+0.46m; not an anatomical/archival measurement.
def radial_hits(theta):
 origin=(0.,1.05,.2);direction=(math.sin(theta),math.cos(theta),0.);hits=[]
 def cross(a,b):return(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
 def dot(a,b):return sum(x*y for x,y in zip(a,b))
 for face,t in enumerate(A):
  a,b,c=[t[j:j+3]for j in(0,3,6)];e1=tuple(b[k]-a[k]for k in range(3));e2=tuple(c[k]-a[k]for k in range(3));q=cross(direction,e2);det=dot(e1,q)
  if det==0:continue
  tv=tuple(origin[k]-a[k]for k in range(3));u=dot(tv,q)/det
  if u<0 or u>1:continue
  qq=cross(tv,e1);v=dot(direction,qq)/det
  if v<0 or u+v>1:continue
  distance=dot(e2,qq)/det
  if distance<=0:continue
  weights=[1-u-v,u,v];point=[sum(weights[j]*p[k]for j,p in enumerate((a,b,c)))for k in range(3)];normal=cross(e1,e2);nn=math.sqrt(dot(normal,normal))
  if nn==0:continue
  hits.append({'face':face,'indices':indices[face],'barycentric':weights,'surface_world_m':point,'source_winding_unit_normal':[x/nn for x in normal],'ray_distance_m':distance,'outward_dot_ray':dot(normal,direction)/nn})
 return sorted(hits,key=lambda x:(x['ray_distance_m'],x['face']))
girth=[]
for i in range(32):
 theta=2*math.pi*i/32;hits=radial_hits(theta);assert hits and hits[0]['outward_dot_ray']>0
 girth.append({'id':f'proposed_girth_20cm_station_{i:02}','theta_rad':theta,'status':'PROPOSED_CURRENT_SURFACE_WITNESS_NOT_FIT','witness':hits[0],'all_positive_ray_hits':hits})
selected=[]
for q in rows:
 if q['xz_m'][1]in(-.3,-.2,-.1,0,.1,.2):
  hits=q['all_intersections'];top=hits[-1];assert top['source_winding_unit_normal'][1]>0
  x,z=q['xz_m'];selected.append({'id':f'dorsal_x{x:+.2f}_z{z:+.2f}','role':'centerline_gullet_clearance_probe'if x==0 else'proposed_saddle_bar_surface_probe','query_xz_m':[x,z],'status':'PROPOSED_CURRENT_SURFACE_WITNESS_NOT_FIT','witness':top})
seat=[w for w in selected if w['query_xz_m'][0]in(-.08,.08)and w['query_xz_m'][1]in(-.1,.1)]
assert len(seat)==4
seat_reference=[sum(w['witness']['surface_world_m'][k]for w in seat)/4 for k in range(3)]
stirrups=[w for w in selected if w['query_xz_m'][0]in(-.16,.16)and w['query_xz_m'][1]==.1];assert len(stirrups)==2
proposal={'schema':'current26-proposed-riding-fit-surface-witnesses-v1','status':'PROPOSED_UNQUALIFIED_NO_GEAR_OR_RIDER_GENERATED',
 'actual_native_closure':{'path':str(I/'actual-rest-01-driver.CLOSED.json'),'sha256':h((I/'actual-rest-01-driver.CLOSED.json').read_bytes())},
 'source_report':{'path':str(D/'REST-WITNESSES.json'),'sha256':h((D/'REST-WITNESSES.json').read_bytes())},
 'body_mesh':{'mesh':1,'material':'Material_HorseMain4k00.png','vertices':5595,'triangles':9794,'all_horse_triangles_in_future_contact_scope':17390,'joints':26,'triangles_f64le_sha256':h((D/body['files']['triangles']['file']).read_bytes()),'original_indices_u32le_sha256':h(rawi)},
 'source_assets':{'standing7ce':'7ce84d43445e930eecc6d9f69e97ed7ade0fe0b3fc44a9a753c25d88b3f548e1','movingad9':'ad9dc060f8630d0de04fef97d716e8c82be3ac8bf070684e78107720c5221ec6'},
 'frame':'Original native rest metres +Yup +Zforward; no root/axis/scale adjustment',
 'design_parameters_not_historical_measurements':{'saddle_station_z_m':[-.30,-.20,-.10,0,.10,.20],'saddle_bar_sample_x_m':[-.16,-.08,.08,.16],'centerline_x_m':0.,'girth_station_z_m':.20,'girth_query_origin_m':[0.,1.05,.20],'girth_radial_samples':32,'proposed_pad_offset_m':.008,'actual_final_pad_or_tree_or_loaded_contact_offset_m':None},
 'dorsal_surface_witnesses':selected,'girth_surface_witnesses':girth,
 'seat_reference':{'kind':'centroid_of_four_measured_BODY_face_points_NOT_a_rider_pelvis_anchor','witness_ids':[w['id']for w in seat],'reference_world_m':seat_reference,'rider_pelvis_world_m':None,'finished_seat_surface_world_m':None,'status':'PROPOSED_REFERENCE_ONLY'},
 'stirrup_bar_references':[{'side':'left'if w['query_xz_m'][0]>0 else'right','support_witness_id':w['id'],'BODY_surface_witness':w['witness'],'physical_bar_world_m':None,'leather_length_m':None,'footplate_world_m':None,'status':'PROPOSED_SURFACE_REFERENCE_ONLY_NOT_HARDWARE_ANCHOR'}for w in stirrups],
 'required_next_native_inputs':['JOINTS_0 and WEIGHTS_0 at every referenced BODY vertex','Actual current Joseph source skeleton/bone lengths, native garment/body sole/palm surface readback; existing W01 sit_drive is not a riding pose'],
 'proposed_new_rigid_gear_joint_not_contact_qualified':'horse_body (index1); actual emitted inversebind/rest must match current26, no old15-joint rebind',
 'future_horse_contact_cohort':'EVERY current gear part (ALL29 if a29-part candidate); no inherited old20affected/9protected exemption',
 'all_existing_draft_guides_remain_draft_only':True,'historical406_run_or_fit_transferred':False,'body_textures_rig_or_clip_mutated':False,'new_meshes_generated':False,'analysis_stage_native_skinmath_generation_contact_tests_or_browser_executed':False,
 'girth_material_arc':{'query_support_only_full_circle_count':32,'proposed_lower_arc_sample_ids':[girth[i]['id']for i in range(8,25)],'source_angle_interval_rad':[math.pi/2,3*math.pi/2],'over_back_girth_geometry_permitted':False,'billet_connections_to_tree':'Must be constructed and checked separately; full circular query is NOT proposed closed strap geometry'}}
(P/'PROPOSED-CURRENT-FIT-WITNESSES.json').write_text(json.dumps(proposal,indent=2)+'\n')
print('SELECTED',len(selected),'dorsal',len(girth),'girth; seat-reference',seat_reference)
for w in stirrups:print('STIRRUP SUPPORT REF',w['query_xz_m'],w['witness'])
for i in (0,8,16,24):print('GIRTH',i,girth[i]['witness'])
