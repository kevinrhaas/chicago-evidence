# Current horse fitting proposal — not fitted or accepted

Root's actual current rest intake passed: standing7ce and movingad9 emitted equal
complete rest surfaces and 26-joint matrices. This proposal analyzes those saved
F64 streams only. It has not loaded a model, posed/skinned a body, generated gear,
run contact tests or rendered an image. Historical406 remains frozen and UNRUN.

The complete witness table is PROPOSED-CURRENT-FIT-WITNESSES.json. Every point has
an actual BODY face ID, its three original vertex IDs, barycentrics, measured world
position and source-winding normal. BODY is mesh1, Material_HorseMain4k00.png,
5,595 vertices /9,794 triangles. The future contact target includes all three meshes,
17,390 triangles, rather than dropping hair or eyes. There is no old6e9 fallback.
All dimensions and region choices below are reconstructed engineering proposals,
not observed saddle dimensions, historical usage or proven load-bearing anatomy.

## Proposed fit witnesses

The existing horse uses metres, +Y up, +Z forward. Its body joint is (0,1.05,0),
fore shoulders are z +0.46m, and hind hips are approximately z −0.705m. These are
actual rig placements, not a claim that a rig joint measures an anatomical edge.

* Saddle contact-region proposal: sample z −0.30,−0.20,−0.10,0,+0.10,+0.20m
  at x ±0.08/±0.16m. This gives24 actual dorsal bar-surface witnesses, plus six
  centerline probes for gullet clearance. Dorsal y at x0 is1.51502m at z−.30,
  1.45437m at z0, and1.47088m at z+.20. Proposed padding offset8mm is an untested
  design input; it is not a certified gap, contact tolerance or pressure model.
* Seat reference: the centroid of four BODY points x ±.08, z ±.10 is approximately
  (0,1.441630633,0). It is a construction reference INSIDE the dorsal envelope,
  not a finished seat surface, rider pelvis target or accepted attachment node.
  The actual seat surface must come from newly emitted saddle/padding geometry;
  Joseph's pelvis must then be solved against actual body/garment seat contact.
* Girth pilot station: z+.20m,32 radial surface-query witnesses from (0,1.05,.20).
  Actual top face8665 is y1.470884932; bottom face8716 is y.764210079; side faces
  4720/4718 are x+.299873855/−.300864053 at y1.05. The full circle is query context,
  NOT proposed over-back strap geometry. Only lower-half samples8..24 are proposed
  for the underbelly arc; billets must independently join the saddle and pass the
  original complete-interface/contact predicates. Adjacent straight segments may
  cut the horse between samples: neither these points nor a vertex gap proves fit.
* Stirrup-bar support references: BODY face8657, indices[3863,2853,2850], weights
  [.008958171757,.066937432411,.924104395832] yields (+.16,1.412135318,+.10);
  face8655, indices[2852,3861,2849], weights
  [.065647508929,.017870374686,.916482116385] yields (−.16,1.412330133,+.10).
  These are horse surface references only. Physical bars require the new tree's
  actual face IDs. Leather lengths, tread positions and the rider's leg pose remain
  unset until Joseph's actual femur/tibia, sole and garment surfaces are read.
  Do not force the feet to an old proxy's tread height or rescale source bones.

Full-precision values are in JSON; rounded numbers here are for review only. Face
selection used strict barycentrics on already measured triangles, not nearest-point
snapping. Source winding faces out at each selected ray exit. This is surface
location evidence, not a new collision/clearance predicate or fit PASS.

## Source changes to implement after Root gives the lane

Create a separate current26 fit owner with explicit7ce/ad9/26-joint input schema.
Never swap current bodies under the old14,172-triangle/15-joint mode. Reuse original
Fraction/topology/contact kernels and the body-independent ten-sided footplate/
lower-arch partition method. Reconstruct current saddle/tree/girth/headgear fit
from these witnesses. Preserve hardware local design dimensions only where useful;
no old world coordinates, old9 protected transforms, old socket positions or old
skin weights are current positives. Old check_actual.py hardcodes old girth centres,
source face ranges and protected streams: it cannot certify this new family merely
by changing an input hash. Keep that old owner and its failure controls intact.

First authorized native readback, original60s cap: emit actual JOINTS_0/WEIGHTS_0
for every referenced BODY vertex and verify exact26 names/rest/inverse binds. Then
new current-mode builder can derive explicit current gear weights; a proposed rigid
saddle attached to horse_body is still UNQUALIFIED until actual quiet/walk contact.
Headgear/reins must use actual current head/hand surfaces, not a proxy head socket.
A next rest candidate can run original30s build,60s actual readback/Khronos and
original self/contact subcaps, with source/input/vendor guards and first-failure
stop. No native current builder exists yet: do not invent a runnable fit command
or describe this table as generated tack. Root can hand off implementation next.

Preserve cf148 and all88 historical stirrup crossings as old-input negative controls;
retain the original29 self/contact obligations, exact interface topology, strict
proper/SAT/winding predicates and no whole-pair exemptions. A complete new29-part
candidate must execute all406 pairs, including36 previously unproved fixed/fixed,
and EVERY current gear part versus ALL17,390 horse triangles. Every part needs
fresh horse-contact evidence; the old20-affected/9-protected split is not a
current-body exemption. If the candidate cohort differs,
recompute and disclose its actual pair/component counts instead of claiming29/406.
Fresh pose/contact evidence is required for quiet/walk/rider motion; existing bare
horse clips and rest equality do not establish tack clearance or continuous fit.

## Joseph and runtime boundaries

Existing person rc_dufresne_joseph is a reconstructed, present1835 livery stable
keeper, age-band30–39. His named worker recipe chooses prepared_adult_35,1.75m as
an unmeasured authoring choice, stable_keeper_round_jacket. No portrait, ownership,
actual ride, date-specific clothing or recorded stature is claimed. Otis remains
his existing wagon driver; do not duplicate or substitute that identity.

In this inspected N, registered display-human instances contain Otis only. Joseph's
old W01 pose and native canonical ingredients exist, but there is no separate
installed named Joseph display-export set here. Hans's anonymous1904 ingredient
copies must not be relabelled as already-qualified Joseph riding exports. A current
named canonical assembly/pose is needed, coordinated with the garment owner. Reuse
pure rest-to-pose basis math, never bypass the strict W01 bench loader or rename
sit_drive as a riding pose. Preserve the one-identity/card/disposal/Light boundaries;
no runtime or APP edit is proposed before standalone current fit/pose is measured.

The Sevket horse remains CC-BY4.0 with existing source/adaptation attribution; old
procedural6e9 remains CC0. New original hardware may retain its own CC0 grant and
GPL predicates remain GPL. No changes to current body, rig, textures, clips, horse
support certificate, canonical assets, registry, tickets or APP are made here.
