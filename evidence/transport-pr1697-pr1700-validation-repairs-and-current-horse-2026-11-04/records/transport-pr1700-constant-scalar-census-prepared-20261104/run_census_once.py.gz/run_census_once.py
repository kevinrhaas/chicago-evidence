from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,shutil,subprocess,sys
HERE=Path(__file__).parent;P=Path('/workspace/chicago-pr1700-memory-baseline-ff1827-20261104');G=Path('/workspace/chicago-driver-garment-projected-20261104')
OUT=Path('/workspace/.cloud-setup/transport-current-20261103/actual-ff-constant-scalar-upload-census-01');assert not OUT.exists()
lock=open('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('guard','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',PW_EXECUTABLE='/workspace/.cloud-setup/transport-browser141-20261103/chromium_headless_shell-1194/chrome-linux/headless_shell')
for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR']:env.pop(k,None)
def source(repo):
 m=dict(env,GIT_NO_LAZY_FETCH='1');g=lambda *a:subprocess.check_output(['git','--no-optional-locks','-C',str(repo),*a],env=m,timeout=30)
 return dict(HEAD=g('rev-parse','HEAD').decode().strip(),TREE=g('write-tree').decode().strip(),index=hashlib.sha256(g('ls-files','--stage','-z')).hexdigest(),status=g('status','--porcelain').decode())
before_G=source(G);before_P=source(P);assert before_G['HEAD']=='79e302ee4b8648b2b89e81ef504049010de4cb7e'and before_P['HEAD']=='ff1827f94a7c05cc7e5802be88f38b8193f4d2ac';assert not before_G['status']and not before_P['status']
before=guard.snapshot();assert guard.check(before)['accepted'];OUT.mkdir();scratch=OUT/'native-tmp';scratch.mkdir();env['TMPDIR']=str(scratch)
prefix=OUT/'observed-ff-scalar-census';command=['node',str(HERE/'measure_ff_constant_scalars_observed.mjs'),'--gate','--year','1904','--only','mobile','--json',str(OUT/'OBSERVED-FF.json')]
q=subprocess.run([sys.executable,'/workspace/.cloud-setup/transport-supervise.py','--prefix',str(prefix),'--cwd',str(P/'chicago/4d'),'--timeout','600','--',*command],env=env,check=False)
r=json.loads(Path(str(prefix)+'.result.json').read_text());c=json.loads(Path(str(prefix)+'.cleanup.json').read_text());resources=guard.pair(before,guard.snapshot());after_G=source(G);after_P=source(P)
error=None;summary=None
try:
 assert not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==600 and r['timeout_override_reason']is None
 assert c['cleanup_complete']and not c['remaining_owned_children']and resources['accepted']and after_G==before_G and after_P==before_P
 j=json.loads((OUT/'OBSERVED-FF.json').read_text());row=j['rows'][0];data=row['diagnostic_only_constant_scalar_census'];assert row['errors']==[]and data
 uploaded=[x for x in data if x['uploaded']];constant=[x for x in uploaded if x.get('constant')and x['bytes']>4];summary=dict(structure_batches=len(data),uploaded_scalar_buffers=len(uploaded),constant_uploaded_buffers=len(constant),actual_redundant_constant_bytes=sum(x['bytes']-4 for x in constant),constant_rows=constant,unmodified_original_memory_still_nonpassing=row['totals']['total']>419430400,observed_total_not_an_original_gate_qualification=row['totals']['total'])
except BaseException as e:error=repr(e)
if c['cleanup_complete']and not c['remaining_owned_children']:shutil.rmtree(scratch)
closed=dict(status='DIAGNOSTIC_ONLY_CONSTANT_BUFFER_CENSUS_COMPLETE'if error is None else'CENSUS_NONPASS_NO_AUTOMATIC_RETRY',error=error,result=r,cleanup=c,resources=resources,G79_unchanged=after_G==before_G,FF_unchanged=after_P==before_P,summary=summary,owned_TMPDIR_removed=not scratch.exists(),no_source_edit_or_geometry_quality_or_counter_changes=True,original_memory_gate_PASS_claimed=False)
(OUT/'CLOSED.json').write_text(json.dumps(closed,indent=2)+'\n');print(json.dumps(dict(status=closed['status'],error=error,summary=summary)));sys.exit(0 if error is None else 1)
