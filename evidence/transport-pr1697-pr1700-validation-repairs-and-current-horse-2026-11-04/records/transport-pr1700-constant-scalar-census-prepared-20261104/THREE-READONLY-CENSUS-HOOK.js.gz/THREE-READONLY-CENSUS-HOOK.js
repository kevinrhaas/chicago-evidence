
// External observation only: never mutates attribute bytes or original callback semantics.
(() => {
 const named = new WeakSet(), facts = new WeakMap();
 const set = BufferGeometry.prototype.setAttribute;
 BufferGeometry.prototype.setAttribute = function(name, attribute) { if(name === '_chiScalars') named.add(attribute); return set.call(this,name,attribute); };
 function inspect(attribute) {
  const a=attribute.array; if(!(a instanceof Uint8Array)||attribute.itemSize!==4||attribute.normalized||a.length<4)return null;
  const tuple=Array.from(a.slice(0,4)); let constant=true;
  for(let i=4;i<a.length;i++)if(a[i]!==tuple[i%4]){constant=false;break;}
  return {bytes:a.byteLength,count:attribute.count,tuple,constant,instanced:!!attribute.isInstancedBufferAttribute};
 }
 const onUpload=BufferAttribute.prototype.onUpload;
 BufferAttribute.prototype.onUpload=function(callback){return onUpload.call(this,function(){if(named.has(this)){const f=inspect(this);if(f)facts.set(this,f);}return callback.apply(this,arguments);});};
 globalThis.__constantScalarCensus={snapshot(batches){return batches.map((b)=>{const a=b.geometry.getAttribute('_chiScalars');return {name:b.name,uuid:b.uuid,material:b.material.name,positionCount:b.geometry.attributes.position.count,indexCount:b.geometry.index?.count??0,uploaded:facts.has(a),...(facts.get(a)??inspect(a)??{}),sourceStructures:[...new Set((b.userData.batchIndex??[]).filter(Boolean))]};});}};
})();
