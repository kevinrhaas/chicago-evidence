# H747 ordinary CI — verified success, metadata proof

PR1278 H747 ordinary gate40139170087 attempt1/job121007034968 completed SUCCESS. Content build passed; renderer checks were skipped. PR remains DRAFT.

The observed native merge ref Q1c69377 has base70b and H747 parents and exactly equals H747 full treefc8/APPc7a. The single official completed-job log request redirected to denied productionresultssa1.blob.core.windows.net and yielded zero bytes. This packet therefore does not prove the actual hosted checkoutQ or hosted1065/384 counts. The separate exact-source local1065/384 preflight remains documented in CP33.

Only selected metadata and content hashes are included. No rawPRIVATE stderr, signed storage URLs, credentials, alternate requests, CI reruns, READY or merge. Renderer qualification remains pending.
