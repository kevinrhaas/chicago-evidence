PR1284 fresh normal CI passed on H84272 / Q2158, exact tree4a2.

Hosted actual checkout and log independently show1065 steps /384 self-tests, none red, then workflow-only changelog exemption. Local exact-tree preflight also passed in639.020s with721 owned descendants reaped and0remaining.

The only change versus tested DEVabb1 is the full-smoke workflow. APP/reference subtrees are identical. Ordinary content/report checks passed; content smoke was skipped, and no incidental feature-H full-smoke ran. No new renderer pass or PR1278 acceptance is claimed.

Gate: https://github.com/kevinrhaas/chicago/actions/runs/40121257436

PROOF.json includes timestamped native refs and lap status; these observations can age. Root owns any PR-ready or SHA-pinned normal merge action. Raw logs, signed URLs and credentials are excluded.
