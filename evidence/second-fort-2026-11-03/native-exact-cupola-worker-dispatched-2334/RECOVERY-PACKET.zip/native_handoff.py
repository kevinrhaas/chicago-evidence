from pathlib import Path
import json,subprocess,base64,hashlib,os,datetime,concurrent.futures
P=Path(__file__).resolve().parent;A=Path('/tmp/wolf-poster-source-20261103/chicago/4d');T=A/'tickets';AUTHOR='Codex second-fort cupola native handoff 2026-11-03';PATH='T-2250-2499/T-2388-match-the-second-fort-dearborn-1835-to-its-pictu.md'
def api(path):return json.loads(subprocess.check_output(['gh','api',path],timeout=45))
def dump(n,j):(P/n).write_text(json.dumps(j,indent=2)+'\n')
def native(label,args):
 cmd=['python','/workspace/shared/run-with-reaping.py',str(P/(label+'-REAPER.json')),'--','timeout','--signal=TERM','--kill-after=15s','120s','nice','-n','19','taskset','-c','2','node','tools/ticket.mjs',*args]
 with (P/(label+'.log')).open('xb')as f:r=subprocess.run(cmd,cwd=A,stdout=f,stderr=subprocess.STDOUT)
 j=json.loads((P/(label+'-REAPER.json')).read_text());assert r.returncode==j['command_exit']==0 and j['all_children_reaped']and not j['leftover_cleanup'],(label,j)
 return j
assert not(P/'CLAIM-REAPER.json').exists(),'No repeated claim'
assert not subprocess.check_output(['git','-C',str(T),'status','--porcelain','--untracked-files=normal'])
r=api('repos/kevinrhaas/chicago-tickets/contents/'+PATH);before=base64.b64decode(r['content']);(P/'T2388-BEFORE-CLAIM.md').write_bytes(before);s=before.decode();assert '\nstate: open\n'in s and '\nclaimed_by: null\n'in s and '\npr: null\n'in s;assert '## Exact native-worker blockhouse cupola handoff'not in s
prs=api('repos/kevinrhaas/chicago/pulls?state=open&per_page=100');assert not any('2388'in x['title']+x['head']['ref']for x in prs)
runs=api('repos/kevinrhaas/polecat-platform/actions/runs?event=workflow_dispatch&per_page=50')['workflow_runs'];assert not any('fort-cupola-native-20261103'in x['display_title']for x in runs)
dev=api('repos/kevinrhaas/chicago/git/ref/heads/dev')['object']['sha'];audit=json.loads(Path('/tmp/second-fort-native-readiness-20261103/AUDIT.json').read_text());expected=audit['current_blob_readbacks']
def read_one(x):
 j=api('repos/kevinrhaas/chicago/contents/chicago/4d/'+x['path']+'?ref='+dev);b=base64.b64decode(j['content']);assert j['sha']==x['blob']and hashlib.sha256(b).hexdigest()==x['sha256'],x['path'];return {'path':x['path'],'blob':j['sha'],'sha256':hashlib.sha256(b).hexdigest(),'exact_reviewed_source':True}
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:checks=list(pool.map(read_one,expected))
dump('FRESH-SOURCE-AND-OWNERSHIP.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'dev':dev,'ticket_blob':r['sha'],'ticket_open_unclaimed_prnull':True,'no_matching_openPR_or_run':True,'reviewed_source_readbacks':checks})
native('CLAIM',['claim','T-2388','--by',AUTHOR]);local=T/PATH;claimed=local.read_bytes();(P/'T2388-CLAIMED-BEFORE-NOTE.md').write_bytes(claimed);assert AUTHOR.encode()in claimed and b'\nstate: claimed\n'in claimed;assert claimed.decode().split('---',2)[2]==before.decode().split('---',2)[2]
local.write_bytes(claimed+(P/'HANDOFF-NOTE.md').read_bytes());(P/'T2388-AFTER-NOTE-BEFORE-SYNC.md').write_bytes(local.read_bytes());native('SYNC',['sync','-m','T-2388: add reviewed exact-native blockhouse cupola handoff'])
r=api('repos/kevinrhaas/chicago-tickets/contents/'+PATH);actual=base64.b64decode(r['content']);assert actual==local.read_bytes();(P/'HANDOFF-SYNC-REMOTE-READBACK.md').write_bytes(actual)
native('RELEASE',['release','T-2388','--why','Reviewed bounded pictured-cupola native handoff saved; OPEN for authorized exact T2388 worker. No geometry, worker dispatch or full-original completion claimed by metadata handoff.'])
r=api('repos/kevinrhaas/chicago-tickets/contents/'+PATH);released=base64.b64decode(r['content']);assert b'\nstate: open\n'in released and b'\nclaimed_by: null\n'in released and b'\npr: null\n'in released;assert released.decode().split('---',2)[2].startswith(before.decode().split('---',2)[2]);assert released.count(b'## Exact native-worker blockhouse cupola handoff')==1;(P/'T2388-RELEASED-REMOTE.md').write_bytes(released)
head=subprocess.check_output(['git','-C',str(T),'rev-parse','HEAD']).decode().strip();assert not subprocess.check_output(['git','-C',str(T),'status','--porcelain','--untracked-files=normal']);dump('HANDOFF-CLOSED.json',{'status':'NATIVE_CLAIM_SYNC_RELEASE_CLOSED','release_commit':head,'ticket_blob':r['sha'],'all_original_body_preserved':True,'dated_handoff_once':True,'source_geometry_unchanged':True,'actual_dispatch':'PENDING'})
print(json.dumps({'status':'HANDOFF_CLOSED','release_commit':head,'ticket_blob':r['sha']}),flush=True)
