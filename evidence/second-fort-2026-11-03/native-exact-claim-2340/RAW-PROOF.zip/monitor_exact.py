"""Bounded read-only exact-second-fort health/claim observer; no writes to repositories."""
from pathlib import Path
import json,subprocess,base64,time,datetime,argparse
ap=argparse.ArgumentParser();ap.add_argument('--snapshots',type=int,default=40);ap.add_argument('--interval',type=int,default=45);args=ap.parse_args()
P=Path(__file__).resolve().parent;RUN=41740271907;URL='https://github.com/kevinrhaas/polecat-platform/actions/runs/'+str(RUN);rows=[];last=None

def api(path):return json.loads(subprocess.check_output(['gh','api',path],timeout=30))
for i in range(args.snapshots):
 try:
  run=api('repos/kevinrhaas/polecat-platform/actions/runs/'+str(RUN));jobs=api('repos/kevinrhaas/polecat-platform/actions/runs/'+str(RUN)+'/jobs');ticket=api('repos/kevinrhaas/chicago-tickets/contents/T-2250-2499/T-2388-match-the-second-fort-dearborn-1835-to-its-pictu.md');body=base64.b64decode(ticket['content']).decode();front=body.split('---',2)[1];fields={line.split(':',1)[0]:line.split(':',1)[1].strip()for line in front.splitlines()if ':'in line};target=next(j for j in jobs['jobs']if j['name']=='targeted-chicago');step=next((s['name']for s in target['steps']if s['status']=='in_progress'),None)
  row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':RUN,'head':run['head_sha'],'run_status':run['status'],'run_conclusion':run['conclusion'],'job':target['id'],'job_status':target['status'],'job_conclusion':target['conclusion'],'labels':target['labels'],'step':step,'ticket_blob':ticket['sha'],'ticket_state':fields.get('state'),'claimed_by':fields.get('claimed_by'),'claimed_run':fields.get('claimed_run'),'claimed_at':fields.get('claimed_at'),'pr':fields.get('pr'),'failed_steps':[s['name']for s in target['steps']if s['conclusion']=='failure']}
  assert row['head']=='aa9d7d2322d3abbc78d72526146c018a241c643e';assert 'ubuntu-26.04'in row['labels']
  row['our_exact_claim']=row['ticket_state']=='claimed'and row['claimed_run']==URL
  if row['ticket_state']=='claimed'and not row['our_exact_claim']:row['ownership_mismatch']=True
 except Exception as exc:row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'read_error':repr(exc)}
 rows.append(row);(P/'MONITOR-SNAPSHOTS.json').write_text(json.dumps(rows,indent=2)+'\n');(P/'MONITOR-LATEST.json').write_text(json.dumps(row,indent=2)+'\n');sig=(row.get('run_status'),row.get('step'),row.get('ticket_state'),row.get('our_exact_claim'),row.get('ownership_mismatch'),row.get('read_error'))
 if sig!=last:print(json.dumps(row),flush=True);last=sig
 if row.get('our_exact_claim')or row.get('ownership_mismatch')or row.get('run_status')=='completed':break
 if i+1<args.snapshots:time.sleep(args.interval)
(P/'MONITOR-CLOSED.json').write_text(json.dumps({'snapshots':len(rows),'latest':rows[-1],'read_only':True,'no_repository_mutations':True},indent=2)+'\n')
