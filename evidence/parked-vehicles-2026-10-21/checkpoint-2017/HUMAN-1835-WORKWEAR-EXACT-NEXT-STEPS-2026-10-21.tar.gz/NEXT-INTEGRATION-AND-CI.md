# Next1835 human integration — exact existing path

No new gate, workflow, Blender installation, CI dispatch or browser execution was performed for this note. Root owns tracked writes. ParkedT2979 validation/landing has priority.

## Current source compatibility

Readonly check `CURRENT-INTEGRATION-READINESS.json` confirms the two existing-file preimages still match current local DEVfdb227db exactly, despite the unrelated parked work:

- `tools/human_teamster_blend.py`: SHA256 `a96e4dd1ca0f7dd488c82c4b43c0f12a32589fbeeadb277f788e65aa49e67fda`.
- `data/humans/recipes/worker_1835.json`: SHA256 `3d23ee26a8541c73eefdefa3684cafe034cb7923b6e1d358775845ecd9d94616`.
- The two new helper paths are absent in the current app. `git apply --check` passed. Patch SHA256 remains `bbf3553f0cc261fdb161d11f101a43137ca2df66459df571ce7e1ea2bc84d1ba`; capsule `f80fab1c…`, peer review `2de5b5d8…`.

After parked work lands, recheck actual bytes rather than assuming the old branch/head. Create a fresh `steward/` branch from current DEV; do not reopen mergedPR1099. Apply the four-file patch, append the appropriate license/liberty/STATUS/ROADMAP/changelog/ticket notes, run the required full existing preflight, commit and push an owner-visible PR into DEV. This source repair does not yet enable a person in town or close photographic acceptance.

## Existing canonical workflow — important input distinction

Current `.github/workflows/chicago-4d-humans.yml` SHA256 is `62048edeed40b6d5fe8c42feec1a031b7b2581a39ec7215ce0a20b170769c847`.

- PR changes to `tools/human_*` or `data/humans/**` trigger the ordinary **humans** fixture/browser job. A successful automatic PR run does **not** build the residents: `teamster-studies` is an intentionally skipped manual-only job.
- Manual dispatch accepts exactly two existing booleans: `build_teamsters` and `build_seated_driver_study`, both defaultfalse. No `experimental_normal_probes` workflow input exists; the canonical builder already receives `--experimental-normal-probes` plus fresh `/tmp` receipts in this workflow.
- Prefer **one** explicit final dispatch with both booleans true. The clothing/footwear changes affect existing sit_drive as well as idle/walk; this runs that existing regression without a second later rebuild. Bothfalse would run fixtures only and prove nothing about the new clothing.
- The concrete command, only after the intended source is committed/pushed, is:

```sh
gh workflow run chicago-4d-humans.yml --repo kevinrhaas/chicago \
  --ref <actual-new-human-branch> \
  -f build_teamsters=true -f build_seated_driver_study=true
```

Bind the discovered run to the exact pushed human commit and dispatch event. Keep one metadata observer and do not re-dispatch while it is running: this workflow's per-ref concurrency is cancel-in-progress. `humans` must succeed before `teamster-studies` runs. Its timeout is20minutes for fixtures and30minutes for residents.

The resident job already prepares the exact25/35 source bodies, generates the physicalW01 bench study, builds/exports all three named masters with the normal experiment, constructs hierarchy controls, audits animation times and hair, runs container validators, measures fixture/master/web parity, and performs actual source and published inspection plus unchanged sole-contact checks. The seated input also renders all three exported residents onW01, source and published. No era-studies dispatch is needed: this patch does not touch its two later/earlier builders or recipe IDs.

## Actual visual acceptance and model delivery

On terminal success, inspect the `resident-teamster-studies-<exactsha>` artifact. Its stable folders are `tmp/teamster-studies/source/`, `web/`, `seated-driver/`, plus the canonical source/webGLBs and master files under the archived runner checkout. Artifact access now works through the supported proxy; the earlier network block is no longer an excuse to skip inspection.

1. Confirm actual build/export/validator/hair/animation/frame/sole results are green, not merely workflowconclusion. Preserve the raw results.
2. View **new** Bardwell front, profile andthreequarter standing/close PNGs in both source/web sets, desktop andmobile. Compare with the saved baselinePNG. Check continuous closed waistcoat/trouser seams, no shirt-colored chin patch, sensible neck/armholes/hem, opaque cloth and smaller weave, enclosed toes, visible sclera/iris/pupil and eyelid fit. Check everyLOD still looks coherent. Dark eyes, visible skin leaks, inverted faces or protruding toes remain blockers even when mechanical checks pass.
3. View seatedW01 captures and actual idle/walk/sole readings. Shoe proof in our source parcel is only a static4mm horizontal support margin; it is not proof of exported/bent shoe enclosure. The old2mm loaded contact tolerance stays unchanged. Do not loosen a guard after a failure.
4. The existing authoring workflow saves artifacts; it does **not** commit the new human assets or place them in the town. To land a usable first person, import only an actually reviewed selected resident's four sourceGLBs and fourwebGLBs into `assets/humans/` and `assets/humans/web/`, with exact output hashes and license/provenance records. Preserve canonical/master evidence separately through the supported artifact/source pipeline. Do not blindly copy all three models or the entire~500MB archive into Git.
5. Re-measure the **actual committed set** with supported `node tools/human_fixture.mjs --write` before committing model bytes. The CI artifact's measure includes all three residents; copying that whole32-entry measure while committing onlyBardwell's8files would correctly fail `human_fixture.mjs --check`. Do not fabricate measurements or delete failed readings.
6. A first1835 standing Bardwell can reuse `mountHumans`/`HumanActor`: existing person `rc_bardwell_otis`, asset `bardwell_otis_1835`, `standing`/`idle`, reconstructed placement/appearance, `terrain` anchor, autoLOD, existing person-card interaction, retained review metadata. Add a scene-specific instance/index and `humans` layer only after source+published actual scene checks. The1835 scene already has the people directory. Keep the figure near an actually inspected safe wagon/yard position with a declared reconstructed staging basis; do not claim that historical person/action/placement was observed.
7.1904 Glessner needs a separate wardrobe fit/eye repair before placement. He remains standing/walking/passenger only. Do not substitute the1835 outfit or call him a driver. Never enable the old currentGlessner prototype merely becausePR1099 merged.

Root may land the validated authoring improvement before world placement if its PR accurately says so; only claim visible town progress after the new reviewed GLB and actual instance are delivered through the published app path.
