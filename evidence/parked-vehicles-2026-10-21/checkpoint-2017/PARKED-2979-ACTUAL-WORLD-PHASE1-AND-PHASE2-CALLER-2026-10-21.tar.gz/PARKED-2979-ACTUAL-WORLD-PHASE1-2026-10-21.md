# T-2979 actual published main-scene phase1

Four normal DOM screenshots from two actual world boots. Overall receipt remains FAIL because one mobile people.json requestfailed event lacks its errorText in the original outside helper; no retrospective exclusion. Source/index/model/data pins remained unchanged.

| View | Canonical driver draws | Renderer calls | Triangles | GL error | Budget |
|---|---:|---:|---:|---:|---|
| desktop-1835-western-yard | 2449 | 189 | 1249166 | 0 | PASS |
| desktop-1835-wolf-point | 1838 | 130 | 1006622 | 0 | PASS |
| mobile-1904-glessner-wide | 4124 | 303 | 1857217 | 0 | PASS |
| mobile-1904-carriage-close | 3975 | 308 | 1875879 | 0 | PASS |

Desktop1835 used Full; mobile1904 used explicitly saved Balanced, not the default Light mode. All three W01 placements and one C02 loaded. Actual visible W01 marginal rendering was 10 driver/renderer draws and24208 rendered triangles per instance including shadows. C02 plus shaft-rest marginal rendering was16 draws/24576 rendered triangles including shadows. Wheel-plane variations: W01 3.036/1.510/.540mm; C02 3.715mm.

Root and validator visually inspected all four actual PNGs: coherent grounded parked models and retained covered fallback. Wolf Point has a partially occluding existing foreground tree; remaining planned camera moved5m north without changing app placement. These are bounded prototype improvements, not photographic acceptance. Glessner wide is world context; curb-close shows the carriage.

The justified remaining phase2 plan is five actual boots: published1835mobile, published1904desktop, source1835desktop, source1904mobile, and one published1904mobile diagnostic with reason-preserving official request classification. W01/C02 actual popup DOM checks follow hero screenshots. No browser will launch while root final full preflight34702 runs. No new workflow dispatch has occurred; CI ownership transferred to wagon_visual.
