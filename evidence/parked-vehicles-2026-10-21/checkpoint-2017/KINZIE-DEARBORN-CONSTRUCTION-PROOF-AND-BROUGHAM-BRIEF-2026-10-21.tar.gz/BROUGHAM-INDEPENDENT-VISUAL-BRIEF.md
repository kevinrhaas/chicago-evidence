# Studebaker1893 Brougham: independent visible-shape check

Reference actually viewed: `studebaker-brougham-cdn.jpg`, 1556×1145 pixels, SHA256 `b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe`, original scan JP2 suffix0095. **The similarly named `/page/n95.jpg` service result is a blank neighboring page and is excluded.** Original full-resolution JP2 `studebaker-brougham-original.jp2` has SHA256 `89f12c2659b4cf81817a2c4a0f3b6809fa2983de7b450a873f42e4b9876b0689`.

Independent landmark estimates below come from visual selection on the pictured oblique projection. They are neither calibrated measurements nor inferred dimensions. Approximate pixel locations/ranges are only a reference-camera comparison aid.

- Near front wheel center about(807,796), radius123; near rear center about(1251,790), radius169. Projected rear/front radius ratio about1.37; wheelbase projected442 pixels. Do not turn that into exact physical wheel diameters without handling perspective.
- Cab roof runs from about(961,484) toward(1258,502), gently shaped rather than a flat cuboid slab. The rear roof/cab edge is rounded. The far-side roof line and depth are only partly visible; unseen width/cross-section remain reconstructed.
- The lower near door is a deep smooth U, reaching about(1109,856); it does not end in a horizontal freight-box bottom. Main front door edge descends nearx1031 from about585, turns into the lower curve, and returns upward at the rear side. The trim follows that curve continuously.
- The near side window is genuinely glazed/transparent in the picture: occupants and interior are visible. It has a vertical divider and relatively fine framing. Exact reflection, glass thickness and interior upholstery details are not recoverable.
- A narrow cab-front corner lamp is centered near(961,564), outside the cabin/window. It is an enclosed lamp with curved/oval ornament, not a large rectangular wood block. One clear near lamp is visible; the opposite side is occluded.
- The rear side body/quarter panel bows outward; the near wheel remains separate below/behind it. Wheels have dark slender spokes/rims with bright hub accents, not broad plain orange discs. Exact spoke count needs closer verification and is not stated here.
- Driver bench is elevated well ahead/above the cabin floor. Brown leather seat/back and a very dark textured lap robe are depicted. Two men occupy that bench in the plate; this does not require shipping occupants in the first parked specimen.
- Painted body is very dark green to black in the print; metal/trim highlights are narrow. These are catalog-depicted colors, not measured paint chemistry or exact1904 specimen livery.
- Pair of horses and a central pole arrangement are visible. A single-horse shaft rig would differ from this illustrated specimen. A parked vehicle may be shown unhitched with support hardware, preserving the documented paired-team geometry for later work.

The first parked variant should match these visible distinctions from C02 while openly reconstructing unpictured opposite side, cross-section, physical dimensions, interior and underbody connections. Plate art may be idealized. No other view or measured engineering drawing of this exact Studebaker Brougham has been acquired; matching one oblique source is not proof of perfect3D recovery.

App-ready proposed source record: `proposed/data/sources/studebaker_1893_illustrated_souvenir.json`. Root owns integration and assigning liberty identifiers. No named Prairie household ownership or specific person is established by the plate.
