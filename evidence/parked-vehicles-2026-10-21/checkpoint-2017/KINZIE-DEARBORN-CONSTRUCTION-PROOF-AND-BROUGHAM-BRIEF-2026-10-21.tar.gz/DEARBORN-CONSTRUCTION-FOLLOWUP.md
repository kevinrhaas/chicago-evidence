# Dearborn wagon construction follow-up

The first register archive76d3118d remains immutable. This follow-up adds stronger same-trip textual evidence and a bounded result of the pre1835 appearance search. It also supplies the app-ready Studebaker source record and independent Brougham reference brief requested by root.

## What Kinzie actually says beyond the purchase paragraph

All refer to the same Chicago-to-Fort-Winnebago1831 return journey in the1856 first edition, IA `waubunearlydayin00kinz_0`:

| Printed page / source scan suffix | Construction evidence | Strength / limitation |
| --- | --- | --- |
| p297 /0309 | “light dearborn wagon”; bought by author’s husband after Kercheval brought it from Detroit; intended comfort for mother/nephew | Identifies type, buyer, origin of transport and passenger purpose. Maker is not named. |
| p302 /0314 | “a pair of excellent travelling horses” | This particular trip uses a team of two, not proof that every Dearborn used two horses. |
| p309 /0321 | Horses remain attached to the **pole** by neck-strap after their heads were freed; pole breaks as they struggle out of stream | Establishes a central team-pole arrangement and leather harness; exact attachment hardware and dimensions are not stated. |
| p310 /0322 | Tent packed at **rear of wagon**; new pole cut from an **“iron-tree”**; small box with awl/waxed-ends **under the seat** | Real storage/loading/repair details for a model. The replacement-pole wood is stated only in this episode: do not claim every original member was ironwood or identify a botanical species without evidence. |
| p321 /0335 | “the ascent of the **four-wheeled carriage**” | Four wheels now rest on the same-trip narrative, not a later1913 dictionary definition. |
| p330 /0344 | Wagon passengers can use umbrellas against the sun whereas mounted people cannot | Supports exposed/open passenger use on that day; does NOT prove there was no folding hood or that the usual Dearborn always lacked one. |
| p332 /0346 | Passengers could mount upon the **seats** if water entered | Actual passenger seating and floor below seat level. Plural does not by itself fix number, bench arrangement or width. |

Occupancy must not be flattened into one posed group for every moment. p297 states the purchaser’s intended use; p310 explicitly has **Margaret and her son Edwin** in the wagon at the accident; p330 says the mother had ridden until that day and then exchanged her saddle mount with Margaret. The source does not authorize labeling John Harris Kinzie an always-seated wagon driver.

## Pre1835 comparator search: useful text, no authenticated appearance plate yet

**Basil Hall**, *Travels in North America in the Years1827 and1828*,1829 printing, IA `travelsinnortham00hall`, actual OCR acquired/read:

- p106, Stockbridge, Massachusetts: a “one-horse waggon” described as “a light cart, with seats placed in it resting on wooden springs.”
- p255, Upper Canada near Burlington: an “open cart” with **four wheels**, the seat in the middle resting on elastic supporting wooden bars; p256 contrasts it with the replacement common two-wheel farm cart.

This is a contemporary North American light-passenger-wagon construction comparator. Hall does **not** call those wagons Dearborns; wooden seat-springs may guide a declared reconstruction but cannot be promoted to an attested Kinzie feature. No physical dimensions or wheel ratios are supplied.

**John Treat Irving**, *Indian Sketches: Taken During an Expedition to the Pawnee Tribes*, vol1, Philadelphia: Carey, Lea & Blanchard,1835, IA `indiansketchesta01irvirich` (explicit `NOT_IN_COPYRIGHT`), actual text acquired/read: p15 calls a Dearborn wagon drawn by **two mules**; later text distinguishes heavy/unwieldy wagons from “light dearborns.” This corroborates early frontier use and the light/heavy distinction, not a roof, body drawing or Kinzie-specific mechanism. Publication year1835 alone does not prove release before July1, and it is not Chicago presence.

**Images checked and rejected as a shape basis:** Hall’s1829 *Forty Etchings* from1827–1828 sketches, actual platesVII/VIII andIX/X acquired/viewed. The selected road/frontier views contain no sufficiently readable passenger wagon. Do not call them a wagon reference merely because their roads could carry carriages. Smithsonian exact Dearborn-wagon image search returned no object result; Commons exact results were mostly books or geographic Dearborn/Michigan confusion. A Sturbridge museum request was403 and was not routed around. Met public API returned410; no image acquired. Later1848 Lossing andc1830 Mills travel texts mention Dearborns but neither was an acquired pre1835 construction image. These are search outcomes, not a claim that no such picture exists anywhere.

## Buildable honest version, while the appearance search continues

A light four-wheel passenger wagon with **paired-team pole**, exposed seating, a small under-seat repair box and small rear tent/bundle is supported in this text. Frame/wheels/seats can reuse the portable interface architecture, but its freight-box body should be rebuilt as a light passenger body. Keep no fixed hood in the first open depiction; record that choice as reconstructed and add a later optional hood only with a defensible design comparator. Do not attach a Studebaker badge, make it a Conestoga, or backdate the1831 purchase into1812.

There is currently **no evidence-derived numerical geometry/ratio sheet** for this Dearborn. Choosing engineering dimensions remains legitimate bounded reconstruction: specify the chosen adult/child seating envelope, wheel clearance, axle span and turning constraint; do not attribute those values to Kinzie or Hall. A close photographic match cannot honestly be certified from a paragraph with no image. Root can land a visibly improved light passenger reconstruction while keeping the exact-specimen/photo ticket open.

## Current downstream files

- `proposed/data/sources/studebaker_1893_illustrated_souvenir.json`: standalone proposed app source JSON, not installed.
- `BROUGHAM-INDEPENDENT-VISUAL-BRIEF.md`: independently observed curved door/roof/window/driver-bench/wheel/pole features and uncalibrated projected landmark estimates for the actual1893 plate.
- Correct Brougham image: `studebaker-brougham-cdn.jpg`, SHA256 `b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe`. Original JP2 suffix0095; `/page/n95.jpg` was a blank neighboring page and is expressly excluded.

No app/Git/ticket write, generated vehicle, invented source or photographic acceptance is part of this research follow-up.
