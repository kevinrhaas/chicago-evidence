# Original1835 workwear visible repair — source proposal

This is a concrete replacement construction for the existing1835 resident builder, against DEV `fdb227dbf5ed952921ef652f5a02480fffdad462`. It changes no shared app checkout. Root owns integration. Proposed files and the four-file patch are frozen while wagon_visual independently reviews them.

## Why this work is needed

Human PR1099 already merged on2026-10-20. Its old normal recovery is no longer outstanding. Actual subsequent era workflow39442643176 passed master/export/source/published/sole checks. Network access now permits artifact delivery: `/workspace/shared/human-visible-next/era-authoring-18199b3d.zip` is the actual182,161,237-byte artifact, SHA256 `97f216970bd7d60af2a6d58577a79566ee7addf0898ca7e3648203575554a2b3`.

Actual published Glessner renders have bare shoulders and thighs, a flat dark eye instead of sclera/iris and coarse shoes. Source garment bounds confirm a coat top at1.412m versus neck base1.506m; the garment explicitly records unsewn seams and absent fit acceptance. Do not enable that figure in the1904 town merely because mechanical CI passed.

The1835 named Bardwell export is more covered but has UV-seam skin leaks, a brick-like coarse shirt pattern, stair-stepped vest edges and bare toes outside the old shoe. I inspected its actual front/threequarter source/web PNGs from successful run39289017835. Its downloaded artifact is `/workspace/shared/human-visible-next/resident-teamsters-aedc8012.zip`,491,494,931bytes,SHA256 `f7c169ad8e0d99539bf800d84f01f23b7745d7dd84b4e47ae74d797ab459801e`.

## Concrete patch

`WORKWEAR-VISIBLE-REPAIR.patch` contains four proposed files:

1. New `tools/human_workwear_fit.py`: original source construction, ordinary Python only. Garment ease uses full-body source-shared normals, so duplicate UV charts do not offset in different directions. Geometry is welded across those seams while distinct UV samples remain per corner. Vest-front triangles are actually clipped to the reconstructed V rather than retaining/discarding whole coarse triangles by their centroids. Original weights survive original vertices; new cut vertices interpolate weights, retain four largest influences and renormalize. A new disclosed construction refusal bounds discarded mass to2.5%; measured actual maxima are0.8596% and0.8435% on adult25/35. This affects new garment vertices, never body skin/rig weights. Independent review also identified a disconnected9-vertex under-chin shirt patch inherited from the height-only predicate. The successor excludes head/jaw/eye-majority faces from the shirt (228 faces in the adult25 old numeric band); the retained shirt is one connected2584-vertex/5008-face component. The actual standing collar and neck/torso-owned shirt remain.

2. New `tools/human_eye_components.py`: reuse of the already-saved original CC0 eye study, with transparent cornea **disabled at every LOD**. Original opaque sclera/iris/pupil geometry uses actual existing eye-helper centers/directions. Reconstructed12mm globe/5.5mm iris/2.2mm pupil and brown color do not assert any resident's eyes. No new bone, external eye photograph, refraction extension or alpha sorting mechanism.

3. `tools/human_teamster_blend.py`: consumes those arrays through the existing skinned-mesh path; adds per-corner garment UV support; replaces huge high-contrast shirt ridges with one-percent one-texel alternation; packs the original512x256 iris. The shoe uses32/24/16/12 fixed support planes per foot and seven rings. At each ring, support distances enclose both adjacent complete source-foot triangle slabs. Those support planes interpolate linearly along the actual planar loft, establishing a4mm **horizontal support** margin around the source foot triangles at rest. It is not a4mm Euclidean surface-clearance assertion. Body is unchanged and no skin/body face is hidden. The reconstructed shoe is open at its145mm ankle, where the trousers overlap, and has an actual flat bottom fan. Footwear is not decimated; old sole selection/contact guards remain unchanged.

4. `data/humans/recipes/worker_1835.json`: explicit construction choices/status/limits. Existing three named records, grades, dates, bodies, sources, skin/hair, colors and role metadata remain. The builder improvement applies to all three existing resident variants; Bardwell is the first visual target. It does not touch the1812/1904 builders.

## Source evidence, limits and next validation

`SOURCE-CONTROLS.json` and `.log` record actual adult25/35 source construction, all four shoe/eye LODs, welded geometry with per-corner UVs, four negative controls, exact unchanged core AST checks and patch applicability. Source construction passed in5.47seconds. New source-only shoe triangles are832/624/416/312 per person. Every source sole has at least three fixed ground-plane vertices per side, bound to the existing foot/ball joints. Source body bytes are unchanged.

The entire original raw0.001 normal/probe branch, body morph function, CLI/person/skin validators and sockets/idle/walk/seated/provenance tail remain unchanged. Original exporter, contract, sole sampler, hair/source helpers and all normal thresholds are untouched.

**No Blender ran and no canonical master/export/actual contact/photographic acceptance follows.** Root should independently inspect the patch and peer receipt, run required full preflight before commit, then run the existing pinned canonical1835 authoring/export workflow and all unchanged source+published close, sole, normal, morph, hair and container gates. Inspect actual before/after images, including walking and seated fits. Vest sleeve/armhole/hem construction, textile density, collar form, actual dress fit, skin/eye anatomy, individual likeness and photographic quality remain open.

`preview.html`, `capture_preview.py` and `capture_preview.cjs` support one bounded readonly runtime preview: actual successful Bardwell GLB body/rig/idle/hair are preserved while candidate source garment and eye arrays replace only runtime meshes. It is **not** a canonical BPy/export/LOD/sole trial. Browser execution is held while root's full preflight uses all CPUs; coordinate with root/env_validation before running. Fresh runtime screenshots/receipt, if generated, are explicitly labeled separately. Do not infer scene eligibility from this preview.

Root must append appropriate license/liberty/status/changelog/ticket evidence when integrating; original generated graphical arrays are CC0 and helper/builder code retains its respective SPDX license. This parcel does not assign a new liberty number or close a photographic ticket.
