"""Finite real-source controls; no Blender/GPU, no app write."""
from pathlib import Path
import ast,hashlib,json,math,subprocess,sys,time

OUT=Path(__file__).parent;ROOT=Path('/workspace/chicago/chicago/4d')
sys.path[:0]=[str(OUT/'proposed/chicago/4d/tools'),str(ROOT/'tools')]
from human_workwear_fit import garment_shell,fitted_shoes,_slab_points
from human_eye_components import build_eye_components,iris_pixels

def need(x,msg):
    if not x:raise AssertionError(msg)

start=time.monotonic();runs=[]
recipe=json.loads((OUT/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text())
for age in (25,35):
    path=ROOT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json'
    raw=path.read_bytes();body=json.loads(raw);bones={b['name']:b for b in body['skeleton']}
    h=max(p[1] for m in body['meshes'] for p in m['positions_m'])
    for kind,off in [('shirt',.006),('waistcoat',.014),('trousers',.007)]:
        result=[]
        for mesh in body['meshes']:
            g=garment_shell(mesh,kind,off,recipe,bones,h)
            need(len(g['corner_uvs'])==len(g['triangles']),'per-corner UV count')
            need(all(len(c)==3 and all(len(uv)==2 and all(math.isfinite(v) for v in uv) for uv in c) for c in g['corner_uvs']),'UV corners finite')
            need(all(abs(sum(w.values())-1)<1e-12 and 1<=len(w)<=4 for w in g['weights']),'normalized portable garment weights')
            # Every original shared graphical vertex emits one position, even
            # where the body has several different per-corner UV samples.
            source_positions={}
            for p,basis in zip(g['positions_m'],g['source_basis']):
                if len(basis)==1 and next(iter(basis.values()))==1.:
                    source_positions.setdefault(next(iter(basis)),set()).add(tuple(p))
            need(all(len(ps)==1 for ps in source_positions.values()),'source UV seams must not separate')
            need(g['receipt']['maximum_discarded_cut_weight']<=.025,'four influence cut bound')
            need(hashlib.sha256(path.read_bytes()).digest()==hashlib.sha256(raw).digest(),'body immutable')
            # Mesh edges are geometric, UV boundaries remain corner attributes.
            uv_seams=0
            corner_samples={}
            for face,uvs in zip(g['triangles'],g['corner_uvs']):
                for i,uv in zip(face,uvs):corner_samples.setdefault(i,set()).add(tuple(uv))
            uv_seams=sum(len(v)>1 for v in corner_samples.values())
            result.append({'vertices':len(g['positions_m']),'triangles':len(g['triangles']),
                'welded_vertices_with_distinct_corner_uvs':uv_seams,'maximum_cut_weight_discarded':g['receipt']['maximum_discarded_cut_weight']})
            if age==25:(OUT/f'{kind}-adult25.json').write_text(json.dumps([g],separators=(',',':')))
        runs.append({'age':age,'kind':kind,'meshes':result})
    for lod in range(4):
        shoe=fitted_shoes(body,bones,lod)
        need(min(p[1] for p in shoe['positions_m'])==0,'actual sole plane unchanged')
        sole=[(p,w) for p,w in zip(shoe['positions_m'],shoe['weights']) if p[1]==0]
        for side,sign in [('l',1),('r',-1)]:
            part=[(p,w) for p,w in sole if p[0]*sign>0]
            need(len(part)>=3,'fixed flat sole survives all LODs')
            need(all(abs(sum(v for b,v in w.items() if b in ('foot_'+side,'ball_'+side))-1)<1e-12 for p,w in part),'sole foot binding')
        need(all(s['minimum_source_support_clearance_m']>=.004-1e-12 for s in shoe['receipt']['sides']),'complete source foot enclosure')
        if age==25:(OUT/f'shoes-adult25-lod{lod}.json').write_text(json.dumps(shoe,separators=(',',':')))
        eye=build_eye_components(bones,lod,recipe['eye_components'])
        need({m['material'] for m in eye['meshes']}=={'eyes__sclera','eyes__iris','eyes__pupil'},'opaque eye materials only')
        need(all(len(w)==1 and next(iter(w)).startswith('eye_') and next(iter(w.values()))==1 for m in eye['meshes'] for w in m['weights']),'existing eye-joint binding')
        if age==25:(OUT/f'eyes-adult25-lod{lod}.json').write_text(json.dumps(eye,separators=(',',':')))
        runs.append({'age':age,'lod':lod,'shoes':{'vertices':len(shoe['positions_m']),'triangles':len(shoe['triangles']),**shoe['receipt']},'eye_triangles':eye['triangles']})
    print('actual source age',age,'PASS',flush=True)

# Reject malformed source ownership/physical construction before a BPy build.
for label,fn in [
 ('invalid footwear clearance',lambda:fitted_shoes(body,bones,0,clearance_m=.0001)),
 ('invalid eye geometry',lambda:build_eye_components(bones,0,{'radius_m':.001,'iris_radius_m':.0055})),
 ('unknown garment role',lambda:garment_shell(body['meshes'][0],'invented',.006,recipe,bones,h)),
 ('empty foot source',lambda:fitted_shoes({'meshes':[]},bones,0)),
]:
    try:fn()
    except (ValueError,KeyError):pass
    else:raise AssertionError('negative control passed: '+label)

before=(OUT/'preimages/chicago/4d/tools/human_teamster_blend.py').read_text()
after=(OUT/'proposed/chicago/4d/tools/human_teamster_blend.py').read_text()
old=ast.parse(before);new=ast.parse(after)
functions=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.FunctionDef)}
of,nf=functions(old),functions(new)
need({k:v for k,v in of.items() if k!='build'}=={k:v for k,v in nf.items() if k!='build'},'CLI/identity/skin source validators unchanged')
o=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name=='build')
n=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name=='build')
of={f.name:f for f in o.body if isinstance(f,ast.FunctionDef)};nf={f.name:f for f in n.body if isinstance(f,ast.FunctionDef)}
need(ast.dump(of['morphs'],include_attributes=False)==ast.dump(nf['morphs'],include_attributes=False),'body morph function unchanged')
branch=lambda f:next(x for x in f.body if isinstance(x,ast.If) and isinstance(x.test,ast.Compare) and 'source_vertex_indices' in ast.unparse(x.test))
need(ast.dump(branch(of['object_mesh']),include_attributes=False)==ast.dump(branch(nf['object_mesh']),include_attributes=False),'entire original raw-normal/probe gate unchanged')
anchor="    for name,bone in contract['sockets']['required']:\n"
need(before[before.index(anchor):]==after[after.index(anchor):],'sockets/idle/walk/seated/identity provenance tail unchanged')
for f in (OUT/'proposed').rglob('*.py'):compile(f.read_text(),str(f),'exec')
check=subprocess.run(['git','apply','--check',str(OUT/'WORKWEAR-VISIBLE-REPAIR.patch')],cwd=ROOT.parents[1],capture_output=True,text=True)
need(check.returncode==0,'patch applicability: '+check.stderr)

# A concrete image for the same original pixels the proposed BPy builder packs.
from PIL import Image
pixels=iris_pixels();image=Image.new('RGB',(512,256));image.putdata([tuple(round(max(0,min(1,pixels[i+a]))*255) for a in range(3)) for i in range(0,len(pixels),4)])
image.save(OUT/'iris-original-preview.png')
report={'PASS':True,'scope':'Actual original source arrays, source ownership/UV/foot enclosure, opaque eyes and unchanged core AST only. No Blender/export/sole/GPU/photographic acceptance.',
 'actual_source_runs':runs,'negative_controls':4,'unchanged_guards':['CLI/identity/skin validators','body morphs','complete raw0.001 normal/probe audit','sockets/idle/walk/seated/identity provenance'],
 'elapsed_s':time.monotonic()-start}
(OUT/'SOURCE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n')
print('SOURCE CONTROLS PASS',report['elapsed_s'],flush=True)
