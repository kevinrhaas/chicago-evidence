// SPDX-License-Identifier: GPL-3.0-or-later
import * as T from 'three';
import {GLTFLoader} from '../../vendor/three-0.185.1/addons/loaders/GLTFLoader.js';
const canvas=document.querySelector('canvas');
const renderer=new T.WebGLRenderer({canvas,antialias:true,preserveDrawingBuffer:true});
renderer.setPixelRatio(1);renderer.outputColorSpace=T.SRGBColorSpace;
renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.3;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
const scene=new T.Scene();scene.background=new T.Color('#e9e7df');
scene.add(new T.HemisphereLight(0xe5f1ff,0x8d7b57,2.6));
const sun=new T.DirectionalLight(0xfff3d7,3.8);sun.position.set(4,8,5);sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048);sun.shadow.bias=-.0002;scene.add(sun);
const floor=new T.Mesh(new T.PlaneGeometry(100,100),new T.MeshStandardMaterial({color:0xc9c7b9,roughness:1}));
floor.rotation.x=-Math.PI/2;floor.position.y=-.004;floor.receiveShadow=true;scene.add(floor);
const response=await fetch('./brougham.glb');if(!response.ok)throw Error('BroughamHTTP'+response.status);
const buffer=await response.arrayBuffer();const gltf=await new GLTFLoader().parseAsync(buffer,'');
const model=gltf.scene.getObjectByName('vehicle_root');scene.add(model);
model.traverse(n=>{if(n.isMesh){n.castShadow=true;n.receiveShadow=true;}});model.updateMatrixWorld(true);
const pole=model.getObjectByName('vehicle_team_pole');
const full=new T.Box3().setFromObject(model,true);pole.visible=false;
const body=new T.Box3();
model.traverse(n=>{if(!n.isMesh)return;let a=n;while(a&&a!==pole)a=a.parent;if(a===pole)return;body.union(new T.Box3().setFromObject(n,true));});
pole.visible=true;
const corners=b=>{const out=[];for(const x of[b.min.x,b.max.x])for(const y of[b.min.y,b.max.y])for(const z of[b.min.z,b.max.z])out.push(new T.Vector3(x,y,z));return out;};
scene.updateMatrixWorld(true);sun.shadow.updateMatrices(sun);
const caster=corners(full),ray=sun.position.clone().normalize().multiplyScalar(-1);
const floorPoints=caster.map(p=>{const d=(floor.position.y-p.y)/ray.y;return p.clone().addScaledVector(ray,d);});
const lightPoints=[...caster,...floorPoints].map(p=>p.clone().applyMatrix4(sun.shadow.camera.matrixWorldInverse));
Object.assign(sun.shadow.camera,{left:Math.min(...lightPoints.map(p=>p.x))-.15,right:Math.max(...lightPoints.map(p=>p.x))+.15,bottom:Math.min(...lightPoints.map(p=>p.y))-.15,top:Math.max(...lightPoints.map(p=>p.y))+.15,near:Math.max(.01,Math.min(...lightPoints.map(p=>-p.z))-.25),far:Math.max(...lightPoints.map(p=>-p.z))+.25});
sun.shadow.camera.updateProjectionMatrix();sun.shadow.updateMatrices(sun);
const ortho=new T.OrthographicCamera(-2,2,2,-2,.05,100),perspective=new T.PerspectiveCamera(40,1,.05,100);
let activeCamera=ortho,current='reference',disposed=false;
function fit(name){
  current=name;const reference=name==='reference';pole.visible=!reference;
  const selected=reference?body:full,center=selected.getCenter(new T.Vector3());
  const direction=new T.Vector3(...(reference?[1,.20,-.484]:name==='side'?[1,.12,0]:[.7,.18,1])).normalize();
  const w=canvas.clientWidth,h=canvas.clientHeight,aspect=w/h;renderer.setSize(w,h,false);
  const camera=reference?ortho:perspective;activeCamera=camera;
  camera.position.copy(center).addScaledVector(direction,10);camera.lookAt(center);camera.updateMatrixWorld(true);
  const inv=camera.quaternion.clone().invert(),local=corners(selected).map(p=>p.clone().sub(center).applyQuaternion(inv));
  if(reference){const halfY=Math.max(...local.map(p=>Math.abs(p.y))),halfX=Math.max(...local.map(p=>Math.abs(p.x)));const half=Math.max(halfY,halfX/aspect)/.86;Object.assign(camera,{left:-half*aspect,right:half*aspect,top:half,bottom:-half});}
  else{camera.aspect=aspect;const tanV=Math.tan(T.MathUtils.degToRad(camera.fov/2)),tanH=tanV*aspect;let distance=0;for(const p of local)distance=Math.max(distance,p.z+Math.abs(p.x)/(tanH*.86),p.z+Math.abs(p.y)/(tanV*.86));camera.position.copy(center).addScaledVector(direction,distance);camera.lookAt(center);}
  camera.updateProjectionMatrix();camera.updateMatrixWorld(true);renderer.render(scene,camera);
  const projected=corners(selected).map(p=>p.clone().project(camera)),lo=[0,1,2].map(k=>Math.min(...projected.map(p=>p.getComponent(k)))),hi=[0,1,2].map(k=>Math.max(...projected.map(p=>p.getComponent(k))));
  return{name,scope:reference?'Referencebodyandwheels;longparkedteamPoleexplicitlyhidden':'Wholecarriageincludingparkedcentralpole',camera:{position:camera.position.toArray(),target:center.toArray(),kind:camera.type},framing:{ndcMin:lo,ndcMax:hi,entireSelectedBoundsInside:lo.every(v=>v>=-1)&&hi.every(v=>v<=1)},bounds:{min:selected.min.toArray(),max:selected.max.toArray()},drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles,sourceTriangles:gltf.parser.json.extras.statistics.triangles,sourceBytes:buffer.byteLength,glError:renderer.getContext().getError()};
}
window.setView=fit;
window.projectBroughamPoint=p=>{const q=new T.Vector3(...p).project(activeCamera);return{ndc:q.toArray(),canvas:[(q.x+1)*canvas.clientWidth/2,(1-q.y)*canvas.clientHeight/2]};};
window.disposeBrougham=()=>{if(disposed)return;disposed=true;const gs=new Set(),ms=new Set();scene.traverse(n=>{if(n.geometry)gs.add(n.geometry);for(const m of Array.isArray(n.material)?n.material:[n.material])if(m)ms.add(m);});gs.forEach(g=>g.dispose());ms.forEach(m=>m.dispose());sun.shadow.map?.dispose();renderer.dispose();scene.clear();};
window.addEventListener('resize',()=>{if(!disposed)fit(current);});window.addEventListener('pagehide',e=>{if(!e.persisted)window.disposeBrougham();});
fit('reference');window.broughamReady=true;
