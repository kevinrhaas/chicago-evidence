// Readonly actual app capture; all receipts/screenshots are outside the checkout.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto');
const {execFileSync,spawnSync}=require('node:child_process');
const {chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
const cfg=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const root='/workspace/chicago',out=path.resolve(cfg.output);
if(!out.startsWith('/workspace/shared/'))throw Error('outside-app output required');
fs.mkdirSync(out,{recursive:false});
const head=()=>execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const indexDigest=()=>sha(execFileSync('git',['ls-files','--stage'],{cwd:root,maxBuffer:8*1024*1024}));
const cleanWorking=()=>spawnSync('git',['diff','--quiet'],{cwd:root}).status===0;
const pinFiles=['chicago/4d/renderers/web/js/main.js','chicago/4d/renderers/web/js/parked-transport.js','chicago/4d/renderers/web/js/street-grid.js','chicago/4d/renderers/web/js/yard.js','chicago/4d/data/transport/parked/placements.json','site/4d/walk/index.html','site/4d/walk/js/main.js','site/4d/walk/js/parked-transport.js','site/4d/walk/js/street-grid.js','site/4d/walk/js/yard.js','site/4d/data/transport/parked/placements.json'];
for(const prefix of['chicago/4d/renderers/web/','site/4d/walk/'])for(const file of['transport/parked-wagon/wagon-w01.glb','transport/parked-carriage/carriage-c02.glb','transport/parked-carriage/shaft-rest.glb'])pinFiles.push(prefix+file);
const inputPins=Object.fromEntries(pinFiles.map(p=>[p,sha(fs.readFileSync(path.join(root,p)))]));
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.css':'text/css','.wasm':'application/wasm'};
const server=http.createServer((req,res)=>{if(req.url==='/favicon.ico'){res.statusCode=204;res.end();return;}try{let p=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://local').pathname));if(!p.startsWith(root+'/'))throw Error('bad');if(fs.statSync(p).isDirectory())p=path.join(p,'index.html');res.setHeader('Content-Type',mime[path.extname(p)]||'application/octet-stream');res.end(fs.readFileSync(p));}catch{res.statusCode=404;res.end('not found');}});
const receipt={started:new Date().toISOString(),headAtStart:head(),indexDigestAtStart:indexDigest(),cleanWorkingAtStart:cleanWorking(),inputPins,config:cfg,captures:[]};
let browser;
(async()=>{
 if(cfg.expectedHead&&receipt.headAtStart!==cfg.expectedHead)throw Error('HEAD differs before capture');
 if(!receipt.cleanWorkingAtStart)throw Error('Unstaged source changes before capture');
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 for(const [size,width,height] of cfg.viewports||[['desktop',1280,800],['mobile',390,780]])for(const item of cfg.pages){
  if(item.viewport&&item.viewport!==size)continue;
  console.log('START '+size+' '+item.label+' '+new Date().toISOString());
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
  const page=await browser.newPage({viewport:{width,height},hasTouch:size==='mobile',deviceScaleFactor:size==='mobile'?2:1}),errors=[],failed=[],messages=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('requestfailed',r=>failed.push(r.url()));page.on('response',r=>{if(r.status()>=400)failed.push(r.url()+':'+r.status());});
  page.on('console',m=>{if(['warning','error'].includes(m.type()))messages.push({type:m.type(),text:m.text()});});
  page.setDefaultTimeout(90000);
  const requestedDetail=item.detail||(size==='mobile'?'balanced':'full');
  await page.addInitScript(detail=>{localStorage.setItem('chicago4d.settings',JSON.stringify({detail}));},requestedDetail);
  const prefix=item.published?'/site/4d/walk/':'/chicago/4d/renderers/web/';
  const url=origin+prefix+'?year='+item.year+'&keep-geometry=1'+(item.search||'');
  await page.goto(url,{waitUntil:'domcontentloaded'});
  try{await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:240000,polling:1000});}
  catch(error){
   const boot=await page.evaluate(()=>({title:document.title,text:document.body.innerText.slice(0,6000),ready:window.__chicago4d?.ready,error:window.__chicago4d?.error,problems:window.__chicago4d?.problems,apiKeys:window.__chicago4d?Object.keys(window.__chicago4d):null})).catch(e=>({readError:e.message}));
   receipt.failedCapture={item,size,url,errors,failed,messages,boot,error:error.message};
   await page.screenshot({path:path.join(out,size+'-'+item.label+'-FAILED.png')}).catch(()=>{});
   throw error;
  }
  for(const view of item.views||[{}]){
  const captureItem={...item,...view,requestedDetail};
  const state=await page.evaluate(async item=>{
   const a=window.__chicago4d;if(!a.ready)throw Error('boot failure '+a.error);
   const end=performance.now()+90000;while(a.welcome?.state!=='world'&&performance.now()<end){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}
   if(a.welcome?.state!=='world')throw Error('Welcome did not enter world');
   document.getElementById('control-help-gotit')?.click();document.exitPointerLock?.();
   if(item.detail)await a.setDetail(item.detail);
   let pose=item.pose,anchor=null;
   if(item.yardEnclosure){anchor=(a.yard?.wagons||[]).find(w=>w.in_enclosure===item.yardEnclosure);if(!anchor)throw Error('yard anchor absent '+item.yardEnclosure);const p=anchor.at_local_enu_m;pose={local_e:p[0]+5,local_n:p[1]-5,yaw_deg:315,pitch_deg:-2,altitude_m:null};}
   if(pose)a.walker.teleport(pose);
   const frame=()=>{a.step();a.step();a.renderer.getContext().finish();const s=a.stats();return {driverDraws:s.drawCalls,rendererCalls:s.rendererCalls,triangles:s.triangles,budget:s.budget,withinBudget:s.withinBudget,geometries:s.geometries,textures:s.textures,glError:a.renderer.getContext().getError()};};
   const before=frame(),parked=a.parkedTransport||a.parked||null,deltas=[];let after=before;
   const expected=String(item.year)==='1835'?3:1;
   if(!parked||parked.instances.length!==expected)throw Error('Expected '+expected+' refined parked vehicles; actual '+parked?.instances?.length+'; '+JSON.stringify(a.problems.filter(p=>p.startsWith('parked transport'))));
   if(parked&&item.measure!==false){let roots=parked.models||parked.instances||parked.vehicles||parked.group?.children||[];if(roots instanceof Map)roots=[...roots.values()];for(const entry of roots){const model=entry.group||entry.model||entry.root||entry.object||entry;if(!model||typeof model.visible!=='boolean')continue;if(!model.visible){deltas.push({name:model.name,id:entry.row?.id||entry.id,visible:false,marginalDriverDraws:0,marginalRendererCalls:0,marginalTriangles:0});continue;}const meshes=[];model.traverse(n=>{if(n.isMesh)meshes.push(n);});const visibility=meshes.map(n=>n.visible);let hidden;try{meshes.forEach(n=>n.visible=false);hidden=frame();}finally{meshes.forEach((n,i)=>n.visible=visibility[i]);}const restored=frame();after=restored;deltas.push({name:model.name,id:entry.row?.id||entry.id,visible:true,before:restored,hidden,marginalDriverDraws:restored.driverDraws-hidden.driverDraws,marginalRendererCalls:restored.rendererCalls-hidden.rendererCalls,marginalTriangles:restored.triangles-hidden.triangles});}}
   return {ready:a.ready,year:a.year,detail:a.detail,requestedDetail:item.requestedDetail,bootDetail:a.bootDetail,welcome:a.welcome?.state,pose:a.walker.state,anchor,problems:a.problems,draw:after,before,perPlacement:deltas,parkedKeys:parked?Object.keys(parked):null,parkedInstances:parked?.instances?.map(i=>({id:i.row.id,visible:i.group.visible,batches:i.draw_batches,wheelClearance:i.wheel_clearance_m,parking:i.parking})),sceneChildren:a.scene3d.children.map(n=>({name:n.name,type:n.type,visible:n.visible}))};
  },captureItem);
  const name=size+'-'+captureItem.label;
  const capture={name,url,state,errors:[...errors],failed:[...failed],messages:[...messages],screenshot:'pending'};
  receipt.captures.push(capture);fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify(receipt,null,2)+'\n');
  console.log('STATE '+name+' '+JSON.stringify(state.draw));
  await page.screenshot({path:path.join(out,name+'.png'),timeout:90000});
  capture.screenshot='saved';console.log('DONE '+name+' '+JSON.stringify(state.draw));
  }
  await page.close();await browser.close();browser=null;
 }
 receipt.pass=receipt.captures.every(c=>c.state.ready&&c.state.welcome==='world'&&c.state.draw.withinBudget===true&&c.state.draw.glError===0&&!c.errors.length&&!c.failed.length&&!c.messages.some(m=>m.type==='error'));
 if(!receipt.pass)process.exitCode=1;
})().catch(e=>{receipt.pass=false;receipt.error=e.stack;process.exitCode=1;}).finally(async()=>{
 if(browser)await browser.close();if(server.listening)await new Promise(r=>server.close(r));receipt.ended=new Date().toISOString();receipt.headAtEnd=head();receipt.headChanged=receipt.headAtStart!==receipt.headAtEnd;receipt.indexUnchanged=indexDigest()===receipt.indexDigestAtStart;receipt.cleanWorkingAtEnd=cleanWorking();receipt.inputsUnchanged=pinFiles.every(p=>sha(fs.readFileSync(path.join(root,p)))===inputPins[p]);if(!receipt.indexUnchanged||!receipt.cleanWorkingAtEnd||!receipt.inputsUnchanged){receipt.pass=false;process.exitCode=1;}fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({out,pass:receipt.pass,error:receipt.error,captures:receipt.captures.length,headAtStart:receipt.headAtStart,headAtEnd:receipt.headAtEnd,indexUnchanged:receipt.indexUnchanged,inputsUnchanged:receipt.inputsUnchanged}));
});
