"""SYNTHETIC OFFLINE dispatcher controls. No network, no real CI evidence."""
import contextlib,datetime,importlib.util,io,json,pathlib,subprocess,sys,tempfile,types
SCRIPT=pathlib.Path('/workspace/shared/dispatch-parked-2979-smoke.py')
spec=importlib.util.spec_from_file_location('dispatch',SCRIPT);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
head='a'*40;tree='b'*40;out=pathlib.Path(tempfile.mkdtemp(prefix='parked-2979-SYNTHETIC-OFFLINE-',dir='/workspace/shared'));m.SHARED=out
def fakegit(*args):
 if args[0]=='rev-parse':return (tree+'\n').encode()
 return (m.ROOT/args[1].split(':',1)[1]).read_bytes()
m.git=fakegit
allruns=[{'id':1000+i,'head_sha':head,'head_branch':m.BRANCH,'event':'workflow_dispatch','path':'.github/workflows/'+m.WORKFLOW,'run_attempt':1}for i in range(18)]
class API:
 def __init__(self,mode):self.mode=mode;self.posts=[];self.lists=0
 def run(self,cmd,**kw):
  assert cmd[:2]==['gh','api'],'unexpected command';method=cmd[cmd.index('--method')+1];endpoint=cmd[-1]if'--input'not in cmd else cmd[cmd.index('--input')-1]
  value=None
  if endpoint.endswith('git/ref/heads/'+m.BRANCH):value={'object':{'sha':'c'*40 if self.mode=='head-drift'else head}}
  elif endpoint.endswith('git/commits/'+head):value={'tree':{'sha':tree}}
  elif '/pulls/'in endpoint:value={'state':'open','head':{'sha':head,'ref':m.BRANCH,'repo':{'full_name':m.REPO}},'base':{'ref':'main'if self.mode=='wrong-base'else'dev'}}
  elif '/dispatches'in endpoint:
   assert method=='POST';self.posts.append(json.loads(kw['input']))
   if self.mode=='ambiguous-post':return types.SimpleNamespace(returncode=1,stdout='',stderr='SYNTHETIC network ambiguity')
  elif '/runs?'in endpoint:
   self.lists+=1
   n=1 if self.mode=='existing-runs'else(0 if self.lists==1 and self.mode!='reconcile'else(17 if self.mode=='discovery-lag'else 18))
   value={'total_count':n,'workflow_runs':allruns[:n]}
  else:raise AssertionError('unexpected endpoint '+endpoint)
  return types.SimpleNamespace(returncode=0,stdout=json.dumps(value)if value is not None else'',stderr='')
def run(mode,extra=None,expected=1):
 api=API(mode);subprocess_run=m.subprocess.run;m.subprocess.run=api.run
 sys.argv=[str(SCRIPT),'--sha',head,'--pr','123','--output',str(out/mode)]+(extra or ['--execute'])
 try:
  with contextlib.redirect_stdout(io.StringIO()):code=m.main()
 finally:m.subprocess.run=subprocess_run
 assert code==expected,(mode,code)
 return api
checks=[]
for mode in ['head-drift','wrong-base','existing-runs']:
 api=run(mode);assert api.posts==[];checks.append(mode+' refuses before any POST')
api=run('ambiguous-post');assert len(api.posts)==1;checks.append('ambiguous POST stops without retry')
(out/('parked-2979-smoke-'+head+'.POST.lock')).rmdir()
api=run('discovery-lag');assert len(api.posts)==18 and len({(d['inputs']['viewport'],d['inputs']['stage'])for d in api.posts})==18;checks.append('all18 unique cells posted once;17 discovery remains failure')
receipt=out/'discovery-lag/receipt.json';old=receipt.read_bytes();api=run('reconcile',['--reconcile',str(receipt)],expected=0);assert api.posts==[] and receipt.read_bytes()==old;checks.append('GET-only18 reconciliation leaves original failed receipt unchanged')
data={'label':'SYNTHETIC OFFLINE CONTROLS ONLY — NOT ACTUAL CI','PASS':True,'checks':checks,'source':str(SCRIPT),'directory':str(out)};(out/'OFFLINE-CONTROL-RESULT.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2))
