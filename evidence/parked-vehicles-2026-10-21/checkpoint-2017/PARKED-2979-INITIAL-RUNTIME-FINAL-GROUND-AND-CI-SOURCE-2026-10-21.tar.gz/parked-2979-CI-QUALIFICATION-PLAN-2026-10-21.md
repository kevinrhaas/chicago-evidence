# Parked vehicles: current CI qualification plan

Prepared from current DEV fdb227dbf workflow sources and the staged T-2979 paths. This is a plan, **not dispatch or green CI evidence**. No workflow POST was made by this agent.

## Ordinary workflows that should actually trigger

- PR `Chicago 4D — gate`: `chicago-4d-check.yml` because the PR changes `chicago/4d/**`. Requires real `Run the gate` and PR changelog steps.
- PR `Chicago 4D — moving frames`: `chicago-4d-moving-frames.yml` because renderer JS changes. Requires actual published moving-frame and phone upload-release steps, not only setup.
- Push `Chicago 4D — stuck PR report`: `chicago-4d-pr-stuck.yml` because branch is `steward/**`. It is a report and is soft-fail by source on that trigger, but preserve its actual conclusion/check record.
- **No human or era authoring workflow is required by this staged diff.** It changes no human assets/tools, `humans.js`, `scene-loader.js`, vendor tree, pin, exporter or corresponding workflow YAML. Do not dispatch human Blender work merely because a previous transport PR happened to include it.
- **No bake is triggered.** The diff contains no `generators/**`, `tools/bake.sh` or bake YAML. Existing committed authored GLBs have deterministic outside-Blender producers and source gates. No geometry bake workflow should be invented.
- No automatic smoke is triggered unless its own YAML changes; the staged diff currently does not edit workflow YAML. Its manual trigger is existing and supports `viewport` and `stage`.

Re-evaluate actual changed paths if the final commit differs; use actual check/run identities rather than demanding a guessed count forever.

## Complete smoke grid

The current nightly workflow's own exact grid is:

```
viewport: mobile, desktop
stage: 1-2, 3-4, 5, 6-7, 8, 9-12, 13, 14, 15
```

Two viewports × nine disjoint ranges = **18 manual workflow requests**; each of the15 parts is covered exactly once per viewport. `node tools/smoke_budget.mjs --legs` reads this from current `.github/workflows/chicago-4d-bake.yml`. Its current per-leg cap is40minutes. The manual `chicago-4d-smoke.yml` job has150minutes, with real publish and browser smoke steps. Source `main.js` touches the boot chain, so the smoke map conservatively calls for all15 parts. Do not reduce to the parked module's own flat fixture or only part2/14.

After full local preflight, actual source+published parked fixture and real main placement inspection are green, freeze/push the branch and save its exact SHA/tree. Read `git/ref/heads/steward/parked-period-vehicles-20261021`, the intended PR head/base/repository, and existing exact-SHA smoke workflow runs before posting. Refuse if the remote no longer equals the qualified local source or if runs already exist that may cover this attempt.

One representative existing command is:

```
gh workflow run chicago-4d-smoke.yml --repo kevinrhaas/chicago \
  --ref steward/parked-period-vehicles-20261021 \
  -f viewport=desktop -f stage=13
```

Use a structured API body or a reviewed once-only dispatcher for all18 cells, retaining each attempted/succeeded POST and its exact inputs in a fresh outside-app receipt. Queue desktop13 early (historically the slowest), desktop14 and desktop1-2 early to expose new C02/W01 failures. This changes order, not coverage. Never silently retry a POST with an ambiguous response. Reconcile delayed run discovery with ordinary bounded GETs, preserving the initial error and without reposting.

Do **not** run the old25b9 dispatcher/verifier unchanged: they intentionally pin another branch, head, tree, PR1041, code hashes and22-workflow graph, and PR1041 has already merged. No second old observer should be resurrected. A new qualification must bind the new exact source and actual3-normal workflow graph (if the final diff remains as above).

## Final acceptance

- One owner monitors the actual18 discovered run IDs and actual ordinary PR checks. Save metadata/terminal jobs; source triggers and required-step conclusions must cohere. Never infer input pairing from chronological run creation order.
- Require actual setup, supported publish and `Run the smoke against the published mirror` to succeed for every chosen viewport/range; a staged pass alone is not the whole gate.
- Check all actual current PR-required checks and ordinary merge protection. Fresh exact head, open/dev-target PR and `mergeable=true` before normal ready/conditional DEV merge. DEV moving alone is observational; actual source conflicts/runtime changes need reconciliation.
- The user's existing ordinary green DEV merge authorization applies. No admin/bypass or production promotion.
- A green integration does not close photographic likeness, full tack fit, occupied people, riders or boarding acceptance. Actual main-scene vehicle screenshots should show the upgrade, correct location/period and sensible terrain contacts.

## Current local runtime evidence

`/workspace/shared/parked-runtime-source-2026-10-21T194836077Z/receipt.json`: actual source module/GLBs passed42 checks at1280×800 and42 at390×780, plus4 PNGs. Source pins include modulef50a8890/data7c328b8f/W01274e737b/C02f02c6a4e/support5ef9d47e. Flat fixture color-only inventory: W01 five calls/12,104tri; C02+stand eight calls/12,288tri. These exclude world/shadow passes and are not main-scene budget proof. Root is currently running full four-worker preflight; all browser workers are held until it terminates.


## Subsequent frozen ground-provider check and current budget unit

Current root source adds the actual depressed-road height provider. Direct browser fixture `/workspace/shared/parked-ground-check-2026-10-21T200802036Z/receipt.json` passed on street-gridc9b3bcad/parked10ab6984/data71dd3389: four real wheel points differ from actual normal road-mesh ray heights by at most0.690087mm on the actual e1871 field (flat2m max1.93e-8m). Road is257.3mm below the raw field at this stand. Actual carriage base4.067699809m, wheel-plane variation3.715mm. Outside-road returnsnull, explicitnullprovider refuses, default1835raw-ground path remains valid. This does not claim exact CPU-vs-triangle equality. Root is running one complete final preflight after these frozen corrections.

T-2970 changed the draw budget unit: `api.stats().drawCalls` counts actual driver draws; `renderer.info.render.calls` is historical compatibility. The general current budget is7,800 driver draws, not the old330 calls. Record BOTH via api.stats after actual production steps. No budget relaxation is proposed.

Approved concrete dispatcher `/workspace/shared/dispatch-parked-2979-smoke.py` SHA2569fabd4c4d6fbea012e2b01831d029980420777926339a019d82ad22f04a95735 has six synthetic offline guard controls passing and no real POST yet. Root explicitly approved use only after providing pushed exactHEAD+PR.

Agreed actual scene coverage is4published boots (1835/1904 × desktop/mobile) plus2source boots (1835desktop,1904mobile), with source+published flat parked-module fixtures at both sizes. Each1835 world boot captures Western yard and WolfPoint without reloading; each1904 captures Glessner wide and curbside close. This is12 main PNGs/6boots, not all4source year×viewport combinations. All screenshots require actual world entry; source/module file pins and complete index digest are held unchanged across an ordinary commit of the same staged source.
