import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root=path.resolve(process.argv[2]), original=process.argv.includes('--expect-original-leak');
const THREE=await import(pathToFileURL(path.join(root,'renderers/web/vendor/three-0.185.1/three.module.js')));
const {countDriverDraws}=await import(pathToFileURL(path.join(root,'renderers/web/js/driver-draws.js')));
const {gpuPick,gpuPickAsync,setPickRenderer,setPickLog}=await import(pathToFileURL(path.join(root,'renderers/web/js/gpu-pick.js')));
function fixture({tracker=true,multi=true}={}) {
 const render={frame:17,calls:0,triangles:0,points:0,lines:0};
 const info={render,autoReset:true,reset(){render.calls=0;render.triangles=0;},update(n){render.calls++;render.triangles+=n/3;}};
 const sent=[],asked=[];const ext=multi?{multiDrawElementsWEBGL(_m,_counts,_co,_t,_offsets,_oo,n){sent.push(n);}}:null;
 const gl={getExtension(name){asked.push(name);return name==='WEBGL_multi_draw'?ext:null;}};
 const originalTarget={name:'visitor-target'},clear=new THREE.Color(0x123456);
 let target=originalTarget,alpha=.7,extension;
 const r={info,autoClear:false,shadowMap:{autoUpdate:true},getContext:()=>gl,getRenderTarget:()=>target,
  getClearColor(c){return c.copy(clear);},getClearAlpha:()=>alpha,
  setClearColor(c,a){clear.set(c);if(a!==undefined)alpha=a;},getDrawingBufferSize(s){return s.set(1280,800);},
  setRenderTarget(t){if(r.throwRestore&&t===originalTarget){r.throwRestore=false;throw Error('restore-target');}target=t;},
  readRenderTargetPixels(_t,_x,_y,_w,_h,out){if(r.throwRead)throw Error('read-pixel');out.fill(0);},
  render(object,camera){
   r.seenCamera=camera;
   if(r.onRender)r.onRender();
   if(object.isBatchedMesh){object.onBeforeRender(r,null,camera,object.geometry,object.material);draw(object._multiDrawCount);}
   else for(const child of object.children){if(child.visible){r.seenStand=child;draw(1);}}
   if(r.throwRender&&object.isBatchedMesh)throw Error('render-batch');
  }};
 function draw(n){if(!n)return;extension??=gl.getExtension('WEBGL_multi_draw');if(extension){extension.multiDrawElementsWEBGL(4,[],0,5125,[],0,n);info.update(n*3);}else for(let k=0;k<n;k++)info.update(3);}
 const d=tracker?countDriverDraws(r):null;
 const cam=new THREE.PerspectiveCamera(62,1280/800,.1,100);cam.updateMatrixWorld(true);cam.updateProjectionMatrix();
 const material=new THREE.MeshBasicMaterial(),g=new THREE.PlaneGeometry(2,2),batch=new THREE.BatchedMesh(5,20,30,material);
 for(let k=0;k<5;k++){const id=batch.addInstance(batch.addGeometry(g));batch.setMatrixAt(id,new THREE.Matrix4().makeTranslation(0,0,-5-k));}
 batch.updateMatrixWorld(true);
 const plain=new THREE.Mesh(new THREE.PlaneGeometry(1,1));plain.position.z=-3;plain.updateMatrixWorld(true);
 const logs=[];setPickRenderer(r);setPickLog((kind,data)=>logs.push({kind,...data}));
 const seed=()=>{info.reset();draw(7);info.autoReset=false;draw(3);};
 const state=()=>({render:{...render},extra:d?.multiDrawExtra??0,draws:d?.draws??render.calls,autoReset:info.autoReset,autoClear:r.autoClear,shadow:r.shadowMap.autoUpdate});
 return {r,d,cam,batch,plain,material,logs,sent,asked,draw,seed,state,pick:(list=[batch])=>gpuPick(list,{x:0,y:0},cam),asyncPick:()=>gpuPickAsync([batch],{x:0,y:0},cam),originalTarget};
}
const results=[];
async function check(name,fn){try{await fn();results.push({name,pass:true});console.log('PASS '+name);}catch(e){results.push({name,pass:false,error:e.stack});console.error('FAIL '+name+' '+e.message);}}
function preserved(f,before,{target=true,pool=false}={}){
 assert.deepEqual(f.r.info.render,before.render,'visitor renderer fields restored');
 assert.equal(f.d?.multiDrawExtra??0,before.extra,'visitor multidraw extra restored');
 assert.equal(f.d?.draws??f.r.info.render.calls,before.draws,'visitor driver count restored');
 assert.equal(f.r.info.autoReset,before.autoReset);assert.equal(f.r.autoClear,before.autoClear);assert.equal(f.r.shadowMap.autoUpdate,before.shadow);
 if(target)assert.equal(f.r.getRenderTarget(),f.originalTarget);
 assert.equal(f.batch.material,f.material,'actual batch material restored');
 assert.equal(f.r.seenCamera.view.enabled,false,'private camera offset cleared');
 if(pool){assert.notEqual(f.r.seenStand.geometry,f.plain.geometry,'stand-in source geometry released');assert.equal(f.r.seenStand.userData.boxes,null);}
}
await check('actual original gpuPick exposes extra leak; candidate preserves visitor opaque+ghost frame',()=>{
 const f=fixture();f.seed();const before=f.state();assert.equal(before.draws,10);assert.equal(before.render.calls,2);
 assert.equal(f.pick(),null);
 if(original){assert.equal(f.d.multiDrawExtra-before.extra,4);assert.equal(f.d.draws,14);assert.deepEqual(f.r.info.render,before.render);}
 else {preserved(f,before);assert.deepEqual(f.logs.find(x=>x.kind==='pick-work'),{kind:'pick-work',rendererCalls:1,multiDrawExtra:4,draws:5});}
});
await check('repeated private picks do not accumulate; work remains separately observable',()=>{
 const f=fixture();f.seed();const before=f.state();for(let k=0;k<3;k++)f.pick();
 if(original){assert.equal(f.d.draws,22);assert.equal(f.d.multiDrawExtra-before.extra,12);}
 else {preserved(f,before);assert.equal(f.logs.filter(x=>x.kind==='pick-work').reduce((s,x)=>s+x.draws,0),15);}
});
await check('nested actual pick scopes restore in reverse order',()=>{
 const f=fixture();f.seed();const before=f.state();let nested=false;f.r.onRender=()=>{if(!nested){nested=true;f.pick();}};f.pick();
 if(original)assert.equal(f.d.draws,18);
 else {preserved(f,before);assert.equal(f.logs.filter(x=>x.kind==='pick-work').length,2);assert.equal(f.logs.filter(x=>x.kind==='pick-work').reduce((s,x)=>s+x.draws,0),10);}
});
for(const kind of ['throwRender','throwRead']) await check(kind+' restores counters and actual material/camera/target/pool',()=>{
 const f=fixture();f.seed();const before=f.state();f.r[kind]=true;assert.throws(()=>f.pick([f.plain,f.batch]),/render-batch|read-pixel/);
 if(original)assert.equal(f.d.multiDrawExtra-before.extra,4);else preserved(f,before,{pool:true});
});
await check('native-extension fallback and absent tracker retain legacy picker behavior',()=>{
 for(const opts of [{tracker:false,multi:false},{tracker:true,multi:false},{tracker:false,multi:true}]){
  const f=fixture(opts);f.seed();const before=f.state();f.pick([f.plain,f.batch]);preserved(f,before,{pool:true});
  if(!original){const work=f.logs.find(x=>x.kind==='pick-work');assert.equal(work.multiDrawExtra,opts.tracker?0:null);assert.equal(work.draws,opts.tracker?6:null);}
 }
});
await check('first lazy extension acquisition inside pick remains live for subsequent world draws',()=>{
 const f=fixture();assert.deepEqual(f.asked,[]);assert.equal(f.d.native,false);const before=f.state();f.pick();assert.equal(f.d.native,true);
 if(original)assert.equal(f.d.draws,4);else {preserved(f,before);assert.deepEqual(f.asked,['WEBGL_multi_draw']);f.draw(6);assert.equal(f.d.draws,6);}
});
await check('asynchronous API fallback uses the same preserved draw boundary',async()=>{
 const f=fixture();f.seed();const before=f.state();assert.equal(await f.asyncPick(),null);
 if(original)assert.equal(f.d.draws,14);else preserved(f,before);
});
if(!original){
 await check('a repeated scope restore is inert after subsequent legitimate world draws',()=>{
  const f=fixture();f.seed();const before=f.state();const outer=f.d.preserve();f.draw(5);const inner=f.d.preserve();f.draw(4);inner();assert.equal(f.d.multiDrawExtra,before.extra+4);outer();assert.equal(f.d.multiDrawExtra,before.extra);f.draw(3);outer();assert.equal(f.d.multiDrawExtra,before.extra+2);
 });
 await check('diagnostic callback throws only after all existing picker state is restored',()=>{
  const f=fixture();f.seed();const before=f.state();setPickLog(kind=>{if(kind==='pick-work')throw Error('diagnostic-log');});assert.throws(()=>f.pick([f.plain,f.batch]),/diagnostic-log/);preserved(f,before,{pool:true});
 });
 await check('driver/info and camera/pool restore even if render-target restoration throws',()=>{
  const f=fixture();f.seed();const before=f.state();f.r.throwRestore=true;assert.throws(()=>f.pick([f.plain,f.batch]),/restore-target/);preserved(f,before,{target:false,pool:true});
 });
}
setPickLog(null);setPickRenderer(null);
const report={scope:'Actual exact/proposed gpuPick and counter modules, real Three camera/batch/mesh, renderer/GL boundary stub; no WebGL/world/CI causality claim',original_expected_leak_control:original,results,pass:results.every(x=>x.pass)};
fs.writeFileSync(path.resolve(process.argv[3]),JSON.stringify(report,null,2)+'\n');if(!report.pass)process.exitCode=1;
