#!/usr/bin/env python3
"""Root-only guarded installer. Default is read-only; refuses any changed preimage."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--proposal', type=Path, required=True)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--apply', action='store_true')
args = parser.parse_args()
rows = json.loads((args.proposal/'PROPOSED-FILES.json').read_text())
targets = []
for row in rows:
    relative = Path(row['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    source = args.proposal/'proposed'/relative
    target = args.repo/relative
    raw = source.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['sha256'], 'Changed frozen proposal: '+str(relative)
    if row['preimage_sha256'] is None:
        assert not target.exists(), 'New file already exists: '+str(relative)
    else:
        assert target.is_file() and hashlib.sha256(target.read_bytes()).hexdigest() == row['preimage_sha256'], 'Changed preimage; root must merge scoped hunks: '+str(relative)
    targets.append((target, raw))
print('CHECK PASS: all '+str(len(targets))+' frozen proposed files and exact target preimages')
if args.apply:
    for target, raw in targets:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    print('APPLIED '+str(len(targets))+' reviewed files; no Git, publisher or gate operation')
else:
    print('Read-only check; pass --apply only as the root tracked writer on its chosen branch')
