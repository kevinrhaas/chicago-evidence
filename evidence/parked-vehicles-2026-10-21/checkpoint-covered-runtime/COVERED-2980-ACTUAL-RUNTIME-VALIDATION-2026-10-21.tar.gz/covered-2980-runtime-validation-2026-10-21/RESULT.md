# T-2980 actual isolated runtime result

The frozen proposal's prepared actual module fixture ran once and terminated EXIT0/PASS from 22:16:37.437 to 22:16:39.424 UTC (1.987 s). All 26 checks passed. The owned Chromium and local server are closed. No tracked app/Git/ticket write, world boot, publisher or full gate ran. All frozen proposal-manifest bytes and all standalone overlay input pins remain unchanged.

The unchanged parked-transport.js and actual GLTFLoader loaded both proposed covered GLBs from the pinned exported overlay. Each model became nine actual static material batches and rendered as nine renderer calls / 17,292 triangles at 1280×800 and 390×780, DPR 1, GL error zero. This is a simple isolated renderer with no production-shadow assertion, not canonical main-scene api.stats driver budgets. No new screenshot was requested or captured in this fixture; prior actual model PNGs remain in the original source checkpoint.

Both actual models passed unchanged four-wheel and tongue-settling code against the original e1834 Heightfield. The earlier actual terrain query established wheel spans of 0 mm (Western Hotel) and 3.441274106 mm (Wolf Point). The runtime independently asserts its base is the maximum of the four actual samples, its span is at most 30 mm, and its actual tongue minimum gap lies in [0, 0.00001 m). It does not record a more precise tongue angle/gap, and it does not establish full body/yoke or ground-mesh clearance.

Actual initial Light loaded zero GLBs; switching to Full loaded exactly two. Near updates hid each exact original fallback ID; Light/far/dispose restored the callbacks for both original IDs. A null provider and an excessive wheel span refused both models without moving their stands or coercing null to zero. An explicitly injected GLB fetch rejection ran the real loader/module failure path and retained the original fallback identities; this is a controlled TypeError, not a real network outage. Missing hosts generated no replacement IDs. The test uses callback visibility state rather than mounting the entire real yard, so final no-duplicate old/new main-world observation remains required.

Actual generated card objects identify Covered wagon, unidentified maker, unoccupied/unhitched state, retained laid-by yoke and unsupported occupied/hitch interfaces. This does not qualify the real popup DOM, picking/confidence shader or accessibility. The caller collected page errors, request failures and HTTP failures, all empty; it did not collect console messages, so it makes no console-error assertion. The frozen source independently preserved original seeds/finishes/yokes and disabled interfaces, with the peer review and source controls retained in earlier packets.

Production shadows, real main source/published old/new matched views, popup/picking/confidence/disposal, ground/host/yoke clearance, mobile/driver/texture budgets, compressed LOD outputs, full preflight/current published smoke and photographic acceptance remain open. No preview shadow-off or bias setting is carried into the app.

## Exact integration commands for the root tracked writer

The reviewed source packet is `/workspace/shared/covered-wagon-integration-proposal-2026-10-21`, archive SHA256 `10ef740f9ae8859fbd3283c048d761748082fda79531985194879b08eb0d6ed8`. Source base is exact parked commit `2aebef95f6a5b6fa1bd8353db936c7674a73c32f`. Root should create its separate covered branch from approved current DEV after the parked merge/human checkpoint. The guarded installer below checks all proposed bytes and all 24 target preconditions before any write. It has NOT been run against the app or with --apply.

```sh
python /workspace/shared/covered-2980-runtime-validation-2026-10-21/apply-proposal.py --proposal /workspace/shared/covered-wagon-integration-proposal-2026-10-21 --repo /workspace/chicago
python /workspace/shared/covered-2980-runtime-validation-2026-10-21/apply-proposal.py --proposal /workspace/shared/covered-wagon-integration-proposal-2026-10-21 --repo /workspace/chicago --apply
```

If any modern DEV preimage differs, the first command fails before writes and names that file. Root must merge only the scoped text hunks or append-only notes into its current branch; do not overwrite newer STATUS/ROADMAP/LIBERTIES/license/check.sh contents with the old full files. The frozen text-only patch is `covered-2980-proposal.patch` (SHA256 `9910899cb3b2367c90ffe895895aad7319290fb6e2bfb0907929eb06c2b54dab`); binary products are supplied separately under proposed/. After manual reconciliation, retain current originals and regenerate any normal source-use/derived reports. No automatic conflict resolution is proposed.

On the integrated branch, use the existing supported commands in the app:

```sh
cd /workspace/chicago/chicago/4d
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /workspace/shared/chicago-venv/bin/python tools/transport/generate_covered_wagons.py --verify
/workspace/shared/chicago-venv/bin/python tools/transport/check_parked_placements.py
/workspace/shared/chicago-venv/bin/python tools/transport/wagon_covered/test_identity.py
```

Root then owns supported publication, exact-source/published runtime/main comparisons, budget pricing and normal preflight/smoke. Do not run the full gate while another renderer owns the four-core environment. Nine isolated renderer calls per model do not replace those requirements.
