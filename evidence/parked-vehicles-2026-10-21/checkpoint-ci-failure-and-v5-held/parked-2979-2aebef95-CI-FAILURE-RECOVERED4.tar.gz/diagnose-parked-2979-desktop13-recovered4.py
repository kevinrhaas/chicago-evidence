import datetime,hashlib,json,pathlib,re,subprocess,time
out=pathlib.Path('/workspace/shared/parked-2979-2aebef95-failed-desktop13-recovered4');out.mkdir(exist_ok=False)
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def get(label,endpoint,plain=False):
 for attempt in range(1,4):
  r=subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/'+endpoint],capture_output=True,text=True,timeout=45)
  stem=out/(label+'-attempt'+str(attempt));stem.with_suffix('.stdout').write_text(r.stdout);stem.with_suffix('.stderr').write_text(r.stderr)
  transient=not re.search(r'HTTP (?:401|403)\b',r.stderr) and bool(re.search(r'HTTP (?:502|503|504)\b|unexpected EOF|connection reset by peer|transport read',r.stderr,re.I))
  retry=bool(r.returncode and transient and attempt<3)
  with (out/'GET-ATTEMPTS.jsonl').open('a') as f:f.write(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'endpoint':endpoint,'attempt':attempt,'returncode':r.returncode,'retry':retry,'delay_seconds':2**attempt if retry else 0,'stdout_sha256':hashlib.sha256(r.stdout.encode()).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr.encode()).hexdigest()})+'\n')
  if retry:time.sleep(2**attempt);continue
  if r.returncode:raise RuntimeError(label+': '+r.stderr[-1000:])
  return r.stdout if plain else json.loads(r.stdout)
try:
 run=get('run','actions/runs/39673247878');assert run['id']==39673247878 and run['head_sha']=='2aebef95f6a5b6fa1bd8353db936c7674a73c32f' and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='failure'
 jobs=get('jobs','actions/runs/39673247878/jobs?per_page=100');assert jobs['total_count']==len(jobs['jobs'])==1
 job=jobs['jobs'][0];assert job['run_id']==run['id'] and job['head_sha']==run['head_sha'] and job['run_attempt']==1
 log=get('job-log','actions/jobs/'+str(job['id'])+'/logs',True)
 summary={'run_id':run['id'],'head':run['head_sha'],'run_conclusion':run['conclusion'],'run_attempt':run['run_attempt'],'job_id':job['id'],'job_status':job['status'],'job_conclusion':job['conclusion'],'job_started_at':job['started_at'],'job_completed_at':job['completed_at'],'steps':job['steps'],'log_sha256':hashlib.sha256(log.encode()).hexdigest(),'diagnostic_only':True,'dispatches_added':0,'merges_attempted':0}
 save(out/'summary.json',summary);print(json.dumps(summary))
 lines=log.splitlines();print('\n'.join(lines[-100:]))
except Exception as e:save(out/'error.json',{'error':str(e)});raise
