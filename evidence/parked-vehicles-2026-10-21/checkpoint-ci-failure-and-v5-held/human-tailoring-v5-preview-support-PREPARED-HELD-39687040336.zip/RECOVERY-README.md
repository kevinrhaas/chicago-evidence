# PREPARED / HELD V5 preview support recovery capsule

No runtime has run. The covered main task currently owns the browser lane. This capsule grants no release and its RELEASE-TEMPLATE.json has both release flags false. Wait for explicit root release after the covered browser closes.

This compact recovery capsule omits duplicate Three vendor bytes and the8.6MB actual canonical V4 baseline GLB. REACQUISITION.json records the exact original successful artifact, API GET URL, unique member, byte count and SHA256, plus every omitted input/vendor hash. INPUTS.json remains the original immutable complete-input manifest. The source V5 arrays, caller bytes, preparation/source/release manifests and independent verdict are included unchanged.

For recovery, create a new shared directory and copy capsule data there. Reacquire only the selected baseline GLB and pinned vendor files, generate the exact JSON-chunk metadata serialization, and verify all INPUTS.json and PREPARED-CALLER.json hashes before any runtime. Confirm copied vendor source bytes against their hashes; never silently substitute newer vendor code. Preserve release hashes and require explicit root authorization. The Python caller owns the local server and browser, records one exclusive run intent and caps its owned process group at85seconds.

The frozen proposal peer review is [included here](V5-INDEPENDENT-VERDICT.md); original local path and SHA256 are recorded in REACQUISITION.json. The original proposal packet SHA256 is c26f48fbd71cf716fea6fcb4e9e90e6c326183aec3dcff77aaa78291448a07ce.

The future finite grid is24 source-array appearance captures: unchanged actual canonical V4 vs V5 trousers/waistcoat-only source geometry, desktop/mobile, idle/sit_drive time0, front/profile/quarter. All other actual canonical materials/body/skin/rig/animations/shirt/eyes/shoes/hair stay intact. Indexed normals precede UV expansion. This is not V5 canonical/export/LOD/completefit/sole/photo/world acceptance. Forty inherited negative projections remain OPEN; cuffs/full shirt/seat drape/lapels/buttons and finishing remain deferred. No app, Git, ticket, ref or CI action was performed.
