# V5 runtime-swap caller — prepared and held

No browser or server has been launched. Root owns the browser lane and must explicitly release this one preview after the covered browser closes.

The baseline is the exact actual Bardwell sourceLOD0 GLB from successful V4 run39687040336 / source2f75ef23, SHA256 `e3f33cec321e37293d284907652f196ec9ec8fe0f8e653601b2dc26e5ed2b60c`. `BASELINE-ARTIFACT-EXTRACTION.json` records its unique member, full artifact metadata and matching actual source-inspection receipts. The GLB is self-contained, with embedded image/buffer data, nine expected skinned meshes and actual idle/sit_drive/walk clips.

The after view changes only trousers and waistcoat geometry using the exact frozen V5 packet arrays (`c26f48fbd71cf716fea6fcb4e9e90e6c326183aec3dcff77aaa78291448a07ce`). The actual V4 body, skin, shirt, shoes, eyes, hair, materials/textures, skeleton, binds, animations and identity remain intact. Indexed source normals are computed before corner-UV expansion. Runtime checks enforce protected mesh and skeleton invariants. This adapts the previous V4 caller but removes its obsolete shirt/eye/shoe/collar/material approximation replacements.

The one future finite run captures24 original images: before/after × desktop/mobile × idle/sit_drive time0 × front/profile/quarter. Lighting, cameras and time are fixed across each pair. This is an isolated source-array appearance study; it has no W01 scene fixtures and does not qualify V5 canonical exports, LODs, sole contact, complete fit, period tailoring, photographic quality or world use.

All40 inherited negative projections remain OPEN; normal0.001m and sole0.002m guards are unchanged. Cuffs, full shirt/sleeves, full seat/thigh drape, lapels, buttons and finishing remain deferred.

`INPUTS.json` pins all data and copied vendor files; `PREPARED-CALLER.json` pins caller bytes and safeguards. `RELEASE-TEMPLATE.json` is deliberately false and cannot launch the caller. Only after root explicitly releases the browser lane, root can copy it to `RELEASE.json`, set both `release_preview` and `covered_browser_lane_closed` true while preserving exact hashes, then execute the prepared caller once:

```bash
python /workspace/shared/human-tailoring-v5-runtime-preview-prepared-39687040336/capture_preview.py --release /workspace/shared/human-tailoring-v5-runtime-preview-prepared-39687040336/RELEASE.json
```

The caller refuses byte drift or an existing RUN-INTENT receipt. No retries are automatic. It owns and closes the local server/browser, kills its process group at85seconds, and records image/input hashes and failures. All writes stay in this shared preparation directory. No app, Git, ticket, CI, ref, Blender, install or new network action is part of this preparation.
