const {chromium}=require('playwright');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const out=__dirname,parcel='/workspace/shared/human-workwear-visible-repair';
const scope='Readonly runtime-swap preview: actual successful CI Bardwell source GLB body/rig/idle/hair, proposed source garment+opaque-eye arrays. Not a canonical Blender build, exported GLB, LOD/sole-contact qualification, period/likeness or photographic acceptance. Runtime shirt/iris material approximations require actual canonical confirmation.';
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
(async()=>{
 const started=new Date().toISOString(),receipts=[],errors=[],sourceInputs={};
 for(const name of ['shirt-adult25.json','waistcoat-adult25.json','trousers-adult25.json','shoes-adult25-lod0.json','eyes-adult25-lod0.json','iris-original-preview.png'])sourceInputs[name]=hash(path.join(parcel,name));
 sourceInputs.actualCIModel=hash('/workspace/shared/human-visible-next/bardwell_otis_1835.lod0.glb');
 let browser=null,browserClosed=false,failed=null;
 try{
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
  for(const [width,height]of[[1280,800],[390,780]]){
   const page=await browser.newPage({viewport:{width,height}}),local=[];
   const note=(kind,message)=>{const item={kind,message,viewport:[width,height],at:new Date().toISOString()};local.push(item);errors.push(item);};
   page.on('pageerror',e=>note('page',e.message));
   page.on('console',m=>{if(m.type()==='error')note('console',m.text());});
   page.on('requestfailed',r=>note('request',r.url()+': '+r.failure()?.errorText));
   page.on('response',r=>{if(r.status()>=400)note('http',r.status()+' '+r.url());});
   await page.goto('http://127.0.0.1:'+process.argv[2]+'/',{timeout:10000});
   await page.waitForFunction(()=>window.preview?.ready,null,{timeout:10000});
   for(const repair of[false,true]){
    await page.evaluate(r=>preview.load(r),repair);
    for(const view of['front','quarter','face']){
     const r=await page.evaluate(v=>preview.view(v),view);
     if(r.glError!==0){note('gl',String(r.glError));throw Error('WebGL error '+r.glError);}
     if(local.length)throw Error('Browser errors: '+JSON.stringify(local));
     const png=`${width}-${repair?'after':'before'}-${view}.png`;
     await page.screenshot({path:path.join(out,png)});
     receipts.push({png,sha256:hash(path.join(out,png)),...r,errors:[...local]});
     fs.writeFileSync(path.join(out,'PARTIAL.json'),JSON.stringify({scope,started,sourceInputs,captures:receipts,errors,browserClosed:false},null,2));
    }
   }
   await page.evaluate(()=>preview.dispose());await page.close();
  }
 }catch(e){failed={name:e.name,message:e.message,stack:e.stack};}
 finally{
  if(browser){await browser.close();browserClosed=true;}
  const report={scope,started,finished:new Date().toISOString(),sourceInputs,captures:receipts,errors,browserClosed,failed,technical_preview_passed:!failed&&errors.length===0&&receipts.length===12,canonical_or_photographic_accepted:false};
  fs.writeFileSync(path.join(out,'RUNTIME-SOURCE-PREVIEW.json'),JSON.stringify(report,null,2));
 }
 if(failed)throw Error(failed.message);
 console.log('PASS12 actual runtime preview captures; no canonical/photo acceptance. Browser closed.');
})().catch(e=>{console.error(e);process.exitCode=1;});
