# Actualv6 first inspection: technicalpass, sourcefitNOTaccepted

ONEauthorized90sbound actualChromiumrun completed6desktop/mobile frames, sourcecontainer30804faces, fullside/frontstrictframing,0console/page/GL errors, browser/serverclosed. Actualinputs andliteralviewer/caller are retained. No sharedapp/publisher/Gitwrite.

The firstreferenceview fitted earlier approximatewheelcoordinates that turnedout materiallywrong after actualpixelgrid review. Zero residual is only a checkthat the camerafit used its inputs; it doesnotestablish a source match. Researchauthor corrected thenote and wagonagentindependentlyconfirmed. ALLearliernumericlandmarkguesses are superseded asfitcontrols. Updatedreview+correctionnote retain this history; rawactualreceipt/framesareUNCHANGED.

Actualsourceb458: nearfronthub810,820±3px,radius106±5; nearrear1277,795±4px,radius137±5. Manualillustrationestimates, notmetres/calibratedbounds. ActualWB/radiusratio callsforcorrection beforechangingcabinshape. Roofclips thisinvalidreferencecrop, but that alone doesnotjustifyshrinkingroof.

V6candidate04d4f6ce solidbuttonslookclosed; curvedbody/glazing/blackwheels are visible. Wholephotographic/sourceappearanceacceptance remainsOPEN. Next proposedv7 startswith reconstructedWB2.40/RF.50/RR.65, keepsbody/hubs unchanged, refitsactualcorrectedcontrols, thencompareswholebodyagainstsource. No secondbrowser/modelattempt hasbeen launched. Root ownsnextresourcerelease/alltrackedwrites.
