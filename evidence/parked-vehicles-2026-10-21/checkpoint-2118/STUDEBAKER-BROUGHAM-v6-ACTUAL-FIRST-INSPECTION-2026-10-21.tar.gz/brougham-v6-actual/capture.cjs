// SPDX-License-Identifier: GPL-3.0-or-later
// Actual renderer capture is not photographic/source-match acceptance.
const fs=require('fs'),path=require('path'),cp=require('child_process');
const{chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
const ROOT=__dirname,OUT=path.join(ROOT,'actual');fs.mkdirSync(OUT);
let browser,server;const r={pass:false,rows:[],errors:[],scope:'First actual original Brougham renderer inspection; source comparison and photographic acceptance open'};
const save=()=>fs.writeFileSync(path.join(OUT,'receipt.json'),JSON.stringify(r,null,2));
async function cleanup(){await browser?.close().catch(()=>{});if(server)try{process.kill(-server.pid,'SIGTERM')}catch{}}
const timer=setTimeout(()=>{r.error='90sdeadline';save();cleanup().finally(()=>process.exit(124))},90000);
(async()=>{
  server=cp.spawn('python',['-m','http.server','8896','--bind','127.0.0.1','--directory',path.join(ROOT,'fixture')],{detached:true,stdio:'ignore'});
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  const page=await browser.newPage({viewport:{width:1280,height:800}});
  page.on('pageerror',e=>r.errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')r.errors.push(m.text())});
  await page.goto('http://127.0.0.1:8896/transport/brougham/');await page.waitForFunction(()=>window.broughamReady);
  for(const[viewport,width,height]of[['desktop',1280,800],['mobile',390,780]]){
    await page.setViewportSize({width,height});
    for(const view of['reference','side','front']){
      const row=await page.evaluate(view=>{const m=setView(view),c=document.querySelector('canvas').getBoundingClientRect(),h=document.querySelector('header').getBoundingClientRect(),last=document.querySelector('header p:last-child').getBoundingClientRect();return{...m,dom:{canvas:c.toJSON(),header:h.toJSON(),lastText:last.toJSON(),viewport:[innerWidth,innerHeight]}}},view);
      await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
      const image=await page.locator('canvas').screenshot({timeout:10000});fs.writeFileSync(path.join(OUT,`${viewport}-${view}.png`),image);
      r.rows.push({viewport,...row});save();
      if(row.glError||r.errors.length||row.sourceTriangles!==30804||(view!=='reference'&&(row.framing.ndcMin.slice(0,2).some(v=>v<-.98)||row.framing.ndcMax.slice(0,2).some(v=>v>.98)||!row.framing.entireSelectedBoundsInside))||(view==='reference'&&(row.referenceFit.rearResidualPx>.5||row.referenceFit.frontResidualPx>.5))||row.dom.canvas.right>width+1||row.dom.canvas.bottom>height+1||row.dom.header.bottom>row.dom.canvas.top+1||row.dom.lastText.bottom>row.dom.canvas.top+1)throw Error('Actual geometry/GL/framing/DOM guard');
    }
  }
  await page.evaluate(()=>disposeBrougham());r.pass=true;
})().catch(e=>{r.error=String(e.stack);process.exitCode=1}).finally(async()=>{clearTimeout(timer);await cleanup();r.closed=true;save()});
