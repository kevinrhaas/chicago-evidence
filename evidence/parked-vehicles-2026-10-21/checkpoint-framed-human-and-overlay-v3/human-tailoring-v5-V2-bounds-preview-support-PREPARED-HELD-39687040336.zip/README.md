# V2 actual posed union framing — PREPARED / HELD

The V1 fixed-camera assumption was wrong for actual sit_drive. The actual V1 technical24PASS did not establish framing or pose acceptance: root observed quarter-view feet at the top and torso/head cropped out. V1 remains immutable and is frozen explicitly as a seated-framing FAIL. Root's standing images remain valid source-appearance evidence, with a jagged hem now obvious. This V2 is a separate preparation, not a renamed completion.

No V2 browser or server has run. Root currently owns the browser lane and will release only after it is free. RELEASE-TEMPLATE.json is false and cannot launch the caller.

V2 keeps every actual canonical V4 input and frozen V5 array byte-exact. It changes only framing: after setting each original animation to time0 and updating model/skeleton matrices, it calls SkinnedMesh.getVertexPosition for every mesh vertex and applies mesh.matrixWorld. It measures both before/after variants for idle and sit_drive, forms each paired world-bound union and uses the same fitted camera for each pose/view/viewport pair. The fitted union's8 corners lie in NDC±0.8, with a1percent distance margin. Every actual posed vertex must also remain within the clip volume and10percent canvas padding. Unsupported/nonfinite geometry, drift, padding failure or85seconds stops the one run; there is no retry.

World bounds, per-mesh binds, original model transform and all unique bone local/world frames are logged in FRAMING-PREFLIGHT.json and each capture. No body/root translation is applied. Pose, skin, skeleton, material and source arrays are unchanged. The informational aside is hidden in images so it cannot obscure the figure.

The future finite grid is the same24 captures: before/after ×1280×800 and390×780 ×idle/sit_drive0 ×front/profile/quarter. One preparation preflight of both variants per viewport supplies the paired bounds. This does not establish correct anatomical seated pose, fit/collision, sole contact, V5 canonical export/LOD, period tailoring, photographic or world acceptance. Forty inherited negatives and cuffs/full-shirt/seat/lapels/buttons/finishing remain open. SourceV5 has not been applied.

After explicit root release when the browser lane is free, root may copy RELEASE-TEMPLATE.json to RELEASE.json, set its two release flags true while preserving exact manifest hashes, and run once:

```bash
python /workspace/shared/human-tailoring-v5-runtime-preview-V2-bounds-prepared-39687040336/capture_preview.py --release /workspace/shared/human-tailoring-v5-runtime-preview-V2-bounds-prepared-39687040336/RELEASE.json
```

The explicit root guard, exclusive run-intent, pinned inputs/callers, localhost-only assets and owned browser/server closure remain enforced. All writes stay in this shared directory. No browser, app, source, Git, ticket, CI, ref, Blender or install action was performed during preparation.
