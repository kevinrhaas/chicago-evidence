# Actual V2 — framing PASS; inherited posed footwear coverage FAIL / OPEN

All24 actual images passed the actual posed vertex10percent-padding guards, with matched before/after cameras and identical bone frames/model transforms. Browser and server closed at23:57:26UTC. Exact inputs/caller,24 original PNGs, framing preflight, release/intent and technical receipts are preserved under immutable-actual-V2/.

Independent read-only view_image inspection confirms full figure framing in the selected images and the intended fuller trouser/closed-waistcoat source appearance. Jagged hems and unfinished garment fit remain visible.

**Inherited posed footwear coverage FAIL / OPEN:** both actual V4-before and V5-after seated views visibly show bare toes/top feet, while standing views show brown shoes. The closed_shoes mesh is present with450 vertices and changes its logged posed bounds between standing and seated; before/after bounds match. This evidence does not establish why the feet are exposed. No missing-mesh or causal skinning/material/occlusion claim is made.

V4 canonical mechanical success remains valid within its stated scope; it did not prove full footwear/garment fit. V5 source is still unapplied and canonically unqualified. Full fit, period completion, photographic/world/occupied acceptance and T1789 remain OPEN;40 inherited negative projections remain OPEN.

V1 remains preserved as the old fixed-camera seated-framing failure; it is not renamed complete. No new browser, repair preparation, app/source/body-mask/rig/pose/material/Git/ref/CI action was performed for this read-only freeze.

## Independently viewed actual images

- [1280-before-sit_drive-quarter.png](immutable-actual-V2/1280-before-sit_drive-quarter.png)
- [1280-after-sit_drive-quarter.png](immutable-actual-V2/1280-after-sit_drive-quarter.png)
- [390-after-idle-front.png](immutable-actual-V2/390-after-idle-front.png)
- [390-after-idle-profile.png](immutable-actual-V2/390-after-idle-profile.png)
- [1280-before-sit_drive-front.png](immutable-actual-V2/1280-before-sit_drive-front.png)
- [1280-after-sit_drive-front.png](immutable-actual-V2/1280-after-sit_drive-front.png)
- [1280-before-sit_drive-profile.png](immutable-actual-V2/1280-before-sit_drive-profile.png)
- [1280-after-sit_drive-profile.png](immutable-actual-V2/1280-after-sit_drive-profile.png)
- [1280-before-idle-quarter.png](immutable-actual-V2/1280-before-idle-quarter.png)
- [1280-after-idle-quarter.png](immutable-actual-V2/1280-after-idle-quarter.png)

Other images are retained with their actual framing receipts and are not visually accepted. Root reviewed the four images recorded separately in READONLY-VISUAL-REVIEW.json.
