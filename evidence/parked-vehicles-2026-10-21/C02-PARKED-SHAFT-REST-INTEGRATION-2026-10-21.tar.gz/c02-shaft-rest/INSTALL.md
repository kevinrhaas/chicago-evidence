# Separate original C02 timber shaft rest

Copy files beneath app. Load `renderers/web/transport/parked-carriage/shaft-rest.glb` and add its GLTF scene to the SAME parent/unit pose as final C02 f02c6a4e. Its vertices are already authored in carriage ground-local coordinates; do not independently translate to station again. Root node name carriage_shaft_rest_root. Never change original carriage geometry.

Reproduce: `python tools/transport/produce_carriage_shaft_rest.py --carriage renderers/web/transport/parked-carriage/carriage-c02.glb --output /tmp/c02-rest-fresh`. Exact input hash f02c6a4ed9537546d5576ac9d15b881ae684920d5233a62f83387b015bf5af39 required. Two fresh runs output byte-identical shaft-rest.glb SHA5ef9d47e60a77dbf86d921163ce0cebb45f4f69848159d9def3c424a167e074d.

6,960bytes/60triangles/one material+mesh. Crossbar width1.08m/depth0.075m, stationZ2.8m. Two feet0.13x0.34x0.045m on groundY0 and two slightly splayed0.055m timber legs. Its sloping crossbar top is derived from the actual decoded two shaft undersides at serialized Z2.762499809..2.837500095m; all clipped triangle vertices have positive signed clearance minimum7.4169478e-8m. Since Y-minus-top(Z) is affine on each clipped triangle, this checks the whole clipped surface; Float32 rounddown leaves an invisible positive gap rather than sinking. No force/stability/load acceptance is implied.

Khronos0errors/0warnings. Actual same-body with/without support passed desktop1280x800/mobile390x780 side+oblique:4pairs8PNGs, identicalcamera/bounds, exactly+2draw/+120tri INCLUDINGshadow (60tri/+1draw main pass); no console/page/GL errors or framing/DOM failures. Browser/server closed. Author actually viewed desktop side and mobile oblique; the tips now visibly rest on a simple wooden prop instead of floating. Root still verifies placement against actual world terrain/sidewalk footprint.

All added timber geometry/material/form/dimensions/location are original GPL3+ engineering reconstruction for1904, no manufacturer/type/source measurement claim. Add to the same asset license registry and liberty as parked specimen. No new source ID needed for this original declared reconstruction.
