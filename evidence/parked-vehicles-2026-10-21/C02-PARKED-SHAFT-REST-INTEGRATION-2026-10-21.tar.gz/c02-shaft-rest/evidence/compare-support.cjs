// SPDX-License-Identifier: GPL-3.0-or-later
const fs=require('fs'),path=require('path'),cp=require('child_process');
const {chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
const PNG=require('/workspace/shared/c02-normal-independent-probe/png.cjs');
const ROOT=__dirname,OUT=path.join(ROOT,'actual-support');fs.mkdirSync(OUT);
let browser,server;
const receipt={pass:false,rows:[],errors:[],scope:'Identical C02 body with/without separate timber shaft-rest; desktop/mobile side+oblique; support-only +60tri/+1draw plus same shadow pass; no stability/photo claim'};
const save=()=>fs.writeFileSync(path.join(OUT,'receipt.json'),JSON.stringify(receipt,null,2));
async function cleanup(){await browser?.close().catch(()=>{});if(server)try{process.kill(-server.pid,'SIGTERM')}catch{}}
const timer=setTimeout(()=>{receipt.error='120s deadline';save();cleanup().finally(()=>process.exit(124))},120000);
(async()=>{
  server=cp.spawn('python',['-m','http.server','8897','--bind','127.0.0.1','--directory',path.join(ROOT,'fixture-support')],{detached:true,stdio:'ignore'});
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  const pages={};
  for(const asset of ['baseline','candidate']){
    const p=await browser.newPage({viewport:{width:1280,height:800}});pages[asset]=p;
    p.on('pageerror',e=>receipt.errors.push(asset+':'+String(e)));
    p.on('console',m=>{if(m.type()==='error')receipt.errors.push(asset+':'+m.text())});
    await p.goto('http://127.0.0.1:8897/transport/carriage-c02/index.html?asset='+asset);
    await p.waitForFunction(()=>window.c02Ready);
  }
  for(const[viewport,width,height]of[['desktop',1280,800],['mobile',390,780]]){
    for(const p of Object.values(pages))await p.setViewportSize({width,height});
    for(const[view,door]of[['side',0],['close',0]]){
      const pair=[];
      for(const[asset,p]of Object.entries(pages)){
        const row=await p.evaluate(({view,door})=>{
          setDoor(door);const r=setView(view,false,true);
          const canvas=document.querySelector('canvas').getBoundingClientRect(),header=document.querySelector('header').getBoundingClientRect();
          return{...r,dom:{canvas:canvas.toJSON(),header:header.toJSON(),viewport:[innerWidth,innerHeight]}};
        },{view,door});
        await p.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
        const png=await p.locator('canvas').screenshot({timeout:10000});
        fs.writeFileSync(path.join(OUT,`${viewport}-${view}-${door}-${asset}.png`),png);
        pair.push({asset,...row,png});
      }
      const a=pair[0],b=pair[1],diff=PNG.compare(PNG.decode(a.png),PNG.decode(b.png));
      delete diff.diff;delete a.png;delete b.png;
      const row={viewport,view,door,baseline:a,candidate:b,diff,delta_calls:b.drawCalls-a.drawCalls,delta_triangles:b.triangles-a.triangles};
      receipt.rows.push(row);save();
      for(const r of pair){
        if(r.glError||r.framing.ndcMin.slice(0,2).some(v=>v<-.98)||r.framing.ndcMax.slice(0,2).some(v=>v>.98)||!r.framing.entireSelectedBoundsInside||r.dom.canvas.right>width+1||r.dom.canvas.bottom>height+1||r.dom.header.bottom>r.dom.canvas.top+1)throw Error('GL/framing/DOM guard');
      }
      if(JSON.stringify(a.camera)!==JSON.stringify(b.camera)||row.delta_calls!==2||row.delta_triangles!==120||a.sourceTriangles!==12228||b.sourceTriangles!==12228||!diff.changed_pixels||receipt.errors.length)throw Error('Camera/cost/visiblechange/error guard');
    }
  }
  receipt.pass=true;
})().catch(e=>{receipt.error=String(e.stack);process.exitCode=1}).finally(async()=>{clearTimeout(timer);await cleanup();receipt.closed=true;save()});
