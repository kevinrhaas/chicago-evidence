"""Finite single-thread V3 source audit, no BPy/browser/gates/candidate writes."""
from pathlib import Path
import ast,collections,copy,hashlib,importlib.util,json,math,sys,time
sys.dont_write_bytecode=True
ROOT=Path('/workspace/chicago/chicago/4d');V2=Path('/workspace/shared/human-workwear-visible-repair-v2');V3=Path('/workspace/shared/human-tailoring-v3-source-design');OUT=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,s):
 if not v:raise AssertionError(s)
frozen=V3/'FROZEN-V3-SOURCE.json';need(sha(frozen)=='fc655ccb2c882891cb00e7047a5f7428119f26ea8ec5ee6338ad2f3a8718151a','frozen pin')
pins=json.loads(frozen.read_text())['files']
for f,p in pins.items():need(sha(V3/f)==p['sha256'] and (V3/f).stat().st_size==p['bytes'],'frozen file '+f)
def funcs(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(path.read_text())) if isinstance(n,ast.FunctionDef)}
tool='proposed/chicago/4d/tools/';a=funcs(V2/(tool+'human_teamster_blend.py'));b=funcs(V3/(tool+'human_teamster_blend.py'))
need({k:v for k,v in a.items() if k!='build'}=={k:v for k,v in b.items() if k!='build'},'all non-build functions including nested object_mesh/morphs exact')
a=funcs(V2/(tool+'human_workwear_fit.py'));b=funcs(V3/(tool+'human_workwear_fit.py'))
need(all(b[k]==v for k,v in a.items() if k!='garment_shell'),'all prior non-garment functions exact')
old=(V2/(tool+'human_teamster_blend.py')).read_text();new=(V3/(tool+'human_teamster_blend.py')).read_text();anchor="    for name,bone in contract['sockets']['required']:"
need(old[old.index(anchor):]==new[new.index(anchor):],'animation/socket/export provenance tail exact')
need("if kind=='shirt':garment=standing_collar_extension(garment,m,bones,recipe,scale)" in new,'loft before same object_mesh/decimator')
need('standing_collar_lod' not in new and "colors['garment_upper__shirt_collar']" not in new,'separate ellipse and material alias removed')
recipe=json.loads((V3/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text())
sys.path.insert(0,str(ROOT/'tools'))
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
oldhelper=load('immutable_v2_source',V2/(tool+'human_workwear_fit.py'));helper=load('frozen_v3_source',V3/(tool+'human_workwear_fit.py'))
def edges(g):
 result=collections.defaultdict(list)
 for f in g['triangles']:
  for a,b in zip(f,f[1:]+f[:1]):result[tuple(sorted((a,b)))].append((a,b))
 return result
def audit(g,shirt,body,bones):
 c=g['collar_extension'];nv=len(shirt['positions_m']);nf=len(shirt['triangles']);ids=c['shared_base_vertex_ids'];E=edges(g)
 for k in ['positions_m','weights','uvs','source_basis']:need(g[k][:nv]==shirt[k],'shirt vertex prefix untouched '+k)
 for k in ['triangles','corner_uvs','source_triangle_indices']:need(g[k][:nf]==shirt[k],'shirt face prefix untouched '+k)
 need(c['ring_vertex_ids'][0]==ids and all(i<nv for i in ids),'real original IDs shared')
 for a,b in zip(ids,ids[1:]+ids[:1]):
  es=E[tuple(sorted((a,b)))];need(len(es)==2 and es[0]==es[1][::-1],'junction orientation exact')
 need(max(map(len,E.values()))==2,'nonmanifold collar edge')
 need(all(len(w)<=4 and abs(sum(w.values())-1)<1e-12 for w in g['weights']),'portable normalized weights')
 need(all(not({'head','jaw'}&set(w)) for w in g['weights'][nv:]),'new collar not jaw/head bound')
 need(all(math.isfinite(x) and 0<=x<=1 for uv in g['corner_uvs'][nf:] for pair in uv for x in pair),'new UV corners finite normalized')
 need(all(fi is None for fi in g['source_triangle_indices'][nf:]),'authored faces do not claim body UV ownership')
 src={sid:p for sid,p in zip(body['source_vertex_indices'],body['positions_m'])};neck=bones['neck_01']['head_m'];maxerr=0.
 for r in c['source_support']:
  basis=r['source_basis'];need(abs(sum(basis.values())-1)<1e-12 and min(basis.values())>=-1e-12,'support convex source basis')
  fi=r['source_triangle'];allowed={body['source_vertex_indices'][i] for i in body['triangles'][fi]};need(set(basis)<=allowed,'support exact original triangle')
  p=[sum(coef*src[sid][k] for sid,coef in basis.items()) for k in range(3)];q=g['positions_m'][r['vertex']];radial=[p[0]-neck[0],p[2]-neck[2]];length=math.hypot(*radial)
  expected=[p[0]+.006*radial[0]/length,p[1],p[2]+.006*radial[1]/length];err=math.dist(q,expected);maxerr=max(maxerr,err);need(err<1e-10,'actual body ray plus radial ease')
  f=r['height_fraction'];k=c['ring_vertex_ids'][int(round(f*4))].index(r['vertex']);w={j:(1-f)*v for j,v in shirt['weights'][ids[k]].items()};w['neck_01']=w.get('neck_01',0)+f;w={j:v for j,v in w.items() if v>1e-12};need(w==g['weights'][r['vertex']],'declared continuous source-seam to neck ramp')
 for lo,hi in zip(c['ring_vertex_ids'][-2],c['ring_vertex_ids'][-1]):need(g['weights'][lo]==g['weights'][hi],'turn-under top neck weights exact')
 need(all(g['source_basis'][i] for i in range(nv,len(g['positions_m']))),'source support references survive')
 A=[math.atan2(g['positions_m'][i][2]-neck[2],g['positions_m'][i][0]-neck[0]) for i in ids]
 ds=[math.atan2(math.sin(y-x),math.cos(y-x)) for x,y in zip(A,A[1:]+A[:1])];need(all(d>0 for d in ds) or all(d<0 for d in ds),'collar angular loop monotone')
 return {'junction_edges':len(ids),'junction_position_and_weight_gap_m':0.,'max_source_support_radial_vector_error_m':maxerr,'angular_step_max_rad':max(abs(d) for d in ds),'new_vertices':len(g['positions_m'])-nv,'new_triangles':len(g['triangles'])-nf,'old_shirt_geometry_weights_and_corner_uvs_exact':True}
def vest_audit(g,body,bones,height):
 lo=recipe['waist_height_fraction']*height-.04;hi=bones['upperarm_l']['head_m'][1]+.025;need(min(p[1] for p in g['positions_m'])>=lo-1e-12 and max(p[1] for p in g['positions_m'])<=hi+1e-12,'exact clipped hem/top envelope')
 E=edges(g);need(max(map(len,E.values()))<=2,'vest nonmanifold edge');uvmax=0.;werr=0.;source={sid:i for i,sid in enumerate(body['source_vertex_indices'])}
 for face,uvs,fi in zip(g['triangles'],g['corner_uvs'],g['source_triangle_indices']):
  original={body['source_vertex_indices'][i]:body['uvs'][i] for i in body['triangles'][fi]}
  for i,uv in zip(face,uvs):
   basis=g['source_basis'][i];need(set(basis)<=set(original),'vest source ownership')
   expected=[sum(v*original[s][k] for s,v in basis.items()) for k in range(2)];uvmax=max(uvmax,math.dist(uv,expected))
 for i,basis in enumerate(g['source_basis']):
  w=collections.defaultdict(float)
  for sid,coef in basis.items():
   for name,value in body['weights'][source[sid]].items():w[name]+=coef*value
  ordered=sorted(((k,v) for k,v in w.items() if v>1e-12),key=lambda kv:(-kv[1],kv[0]));need(sum(v for k,v in ordered[4:])<=.025,'same discarded weight refusal')
  expected=dict(ordered[:4]);total=sum(expected.values());expected={k:v/total for k,v in expected.items()}
  werr=max(werr,max(abs(expected.get(k,0)-g['weights'][i].get(k,0)) for k in set(expected)|set(g['weights'][i])))
 need(uvmax<1e-12 and werr<1e-12,'source UV and skin interpolation')
 hem=sum(len(fs)==1 and all(abs(g['positions_m'][i][1]-lo)<1e-12 for i in e) for e,fs in E.items());need(hem>20,'real source-clipped planar hem')
 return {'vertices':len(g['positions_m']),'triangles':len(g['triangles']),'exact_hem_edges':hem,'max_corner_uv_error':uvmax,'max_skin_interpolation_error':werr,'discarded_skin_mass_max':g['receipt']['maximum_discarded_cut_weight']}
start=time.monotonic();report={'scope':'Finite source/topology/math only, no model files/Blender/browser/decimation/export/animation/collision/photo qualification','frozen_manifest_sha256':sha(frozen),'patch_sha256':sha(V3/'TAILORING-V3-AGAINST-V2.patch'),'ages':[],'negative_controls':[]}
for age in [25,35]:
 bp=ROOT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json';raw=bp.read_bytes();body=json.loads(raw);source=body['meshes'][0];bones={b['name']:b for b in body['skeleton']};height=max(p[1] for p in source['positions_m']);shirt=oldhelper.garment_shell(source,'shirt',.006,recipe,bones,height)
 if age==25:g=json.loads((V3/'shirt-adult25.json').read_text())[0];v=json.loads((V3/'waistcoat-adult25.json').read_text())[0]
 else:g=helper.standing_collar_extension(shirt,source,bones,recipe);v=helper.garment_shell(source,'waistcoat',.014,recipe,bones,height)
 # JSON source IDs become strings in saved arrays; normalize only those maps.
 for mesh in [g,v]:
  mesh['source_basis']=[{int(k):v for k,v in b.items()} for b in mesh['source_basis']]
 for r in g['collar_extension']['source_support']:r['source_basis']={int(k):v for k,v in r['source_basis'].items()}
 report['ages'].append({'age':age,'collar':audit(g,shirt,source,bones),'waistcoat':vest_audit(v,source,bones,height),'body_sha256':sha(bp)})
 if age==25:
  for label,mutate,check in [
   ('copied collar IDs',lambda q:q['collar_extension']['shared_base_vertex_ids'].__setitem__(0,len(shirt['positions_m'])),lambda q:audit(q,shirt,source,bones)),
   ('alter original junction weight',lambda q:q['weights'][g['collar_extension']['shared_base_vertex_ids'][0]].__setitem__('neck_01',0.),lambda q:audit(q,shirt,source,bones)),
   ('false radial source support',lambda q:q['positions_m'][g['collar_extension']['source_support'][0]['vertex']].__setitem__(0,0.),lambda q:audit(q,shirt,source,bones)),
   ('old centroid hem',lambda q:None,lambda q:vest_audit(oldhelper.garment_shell(source,'waistcoat',.014,recipe,bones,height),source,bones,height))]:
   q=copy.deepcopy(g);mutate(q)
   try:check(q)
   except AssertionError as error:report['negative_controls'].append({'label':label,'refused':str(error)})
   else:raise AssertionError('negative accepted '+label)
 need(bp.read_bytes()==raw,'body source immutable')
for f,p in pins.items():need(sha(V3/f)==p['sha256'],'candidate unchanged '+f)
report['source_invariants_PASS']=True;report['eligible_for_one_authorized_actual_preview']=True;report['elapsed_s']=time.monotonic()-start
report['limits']=['Shared base positions/weights are exact before decimation only; same-object topology prevents separate-object seam drift but does not prove LOD silhouette, surface normals, UV sampling or collar fit after reduction/export.',
 'Six millimetres is radial section ease at 4 support rows, not minimum normal/triangle clearance. Between rays/rows and the authored turn-under are not certified for complete body/jaw collision.',
 'Top collar weights intentionally ramp to neck; independent head/jaw and upperarm poses were not re-audited. Base shares the existing shirt influences exactly.',
 '12mm front and23mm side/back, turn-under, V and arm-influence contour are declared reconstruction, not an attested 1835 pattern. Same linen material is reused; no photographic textile quality claim.',
 'Separate author-measured retained-original shirt normal clearance is positive for actual25/35 with no sub1mm vertices; no new ease defect or correction is inferred. Complete triangle/LOD/animation collision remains unqualified.',
 'Source-support ray code rejects ambiguous/absent crossings; exact horizontal vertex coincidences can conservatively refuse. Only actual prepared25/35 sources checked; no new arbitrary-body compatibility claim.']
report['separate_shirt_clearance_evidence']=[]
for age,pin in [(25,'4a4bbf32427648cce77ed9836b85e12d3e1c7be86f1a631882fcabc09277eace'),(35,'bdd1a3fc57aad5aadbdced785d0bfe54913af26fc1d11a99825c1903c2444282')]:
 p=Path('/workspace/shared/human-shirt-source-clearance-diagnosis')/f'ACTUAL-ADULT{age}-SHIRT-NORMAL-CLEARANCE.json';need(sha(p)==pin,'separate shirt diagnostic pin');j=json.loads(p.read_text());need(j['negative_vertices']==0 and j['vertices_below_1mm']==0,'no measured retained-original shirt low-clearance defect')
 report['separate_shirt_clearance_evidence'].append({'age':age,'path':str(p),'sha256':pin,'minimum_m':j['minimum_actual_normal_clearance_m'],'arm_minimum_m':j['arm_minimum_normal_clearance_m'],'scope':'Author-generated diagnostic read and hash-verified; not independently rerun'})
era=json.loads((V3/'ERA-DEPENDENCY-AUDIT.json').read_text())
for name,entry in era['era_dependency_modules'].items():need(sha(ROOT/'tools'/f'{name}.py')==entry['sha256'],'era dependency source hash '+name)
report['era_dependency_audit']={'sha256':sha(V3/'ERA-DEPENDENCY-AUDIT.json'),'recorded_closure_modules':len(era['era_dependency_modules']),'all_recorded_module_hashes_verified':True,'changed_modules_reachable':era['changed_modules_reachable'],'limit':'Author AST closure reviewed, source hashes verified; no era model or workflow execution'}
(OUT/'INDEPENDENT-V3-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
