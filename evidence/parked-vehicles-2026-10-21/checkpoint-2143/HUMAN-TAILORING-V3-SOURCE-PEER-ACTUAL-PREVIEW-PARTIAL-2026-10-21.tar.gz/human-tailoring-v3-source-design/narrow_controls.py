"""Finite single-thread actual25/35 source controls; no Blender/browser/full gate."""
from pathlib import Path
import sys,ast,json,math,collections,copy,hashlib,importlib.util,time
sys.dont_write_bytecode=True
D=Path(__file__).parent;V2=Path('/workspace/shared/human-workwear-visible-repair-v2');ROOT=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(ROOT/'tools'))
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=load('immutable_v2_helper',V2/'proposed/chicago/4d/tools/human_workwear_fit.py');new=load('outside_v3_helper',D/'proposed/chicago/4d/tools/human_workwear_fit.py');recipe=json.loads((D/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text())
def need(v,s):
 if not v:raise AssertionError(s)
def edge_map(g):
 e=collections.defaultdict(list)
 for f in g['triangles']:
  for a,b in zip(f,f[1:]+f[:1]):e[tuple(sorted((a,b)))].append((a,b))
 return e
def collar_checks(g,shirt):
 c=g['collar_extension'];nv=c['original_shirt_vertex_count'];nf=c['original_shirt_face_count'];need(nv==len(shirt['positions_m']) and nf==len(shirt['triangles']),'actual source prefix sizes')
 for k in ('positions_m','weights','uvs','source_basis'):need(g[k][:nv]==shirt[k],'shirt prefix untouched '+k)
 for k in ('triangles','corner_uvs','source_triangle_indices'):need(g[k][:nf]==shirt[k],'shirt face prefix untouched '+k)
 ids=c['shared_base_vertex_ids'];need(all(i<nv for i in ids),'collar uses actual original shirt vertex IDs');es=edge_map(g)
 for a,b in zip(ids,ids[1:]+ids[:1]):
  incident=es[tuple(sorted((a,b)))];need(len(incident)==2 and incident[0]==tuple(reversed(incident[1])),'collar junction is shared consistently oriented two-face edge')
 need(max(map(len,es.values()))==2,'no nonmanifold collar edge')
 need(all(1<=len(w)<=4 and abs(math.fsum(w.values())-1)<1e-12 for w in g['weights']),'collar four normalized skin lanes')
 need(all(not({'head','jaw'}&set(w)) for w in g['weights'][nv:]),'new collar not face bound')
 need(all(0<=x<=1 for uv in g['corner_uvs'][nf:] for p in uv for x in p),'authored collar UV finite normalized')
 need(all(x is None for x in g['source_triangle_indices'][nf:]),'authored collar faces do not invent original body triangle ownership')
 need(len(set(tuple(p) for p in g['positions_m']))==len(g['positions_m']),'no duplicated garment positions')
 for f in g['triangles'][nf:]:
  a,b,c=[g['positions_m'][i] for i in f];u=[b[k]-a[k] for k in range(3)];v=[c[k]-a[k] for k in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];need(math.hypot(*cross)>1e-18,'no degenerate collar triangles')
 return {'shared_junction_edges':len(ids),'actual_junction_gap_m':0.,'actual_junction_weight_delta':0.,'vertices':len(g['positions_m']),'triangles':len(g['triangles']),'added_vertices':len(g['positions_m'])-nv,'added_triangles':len(g['triangles'])-nf}
def vest_checks(g,source,bones,height):
 lo=recipe['waist_height_fraction']*height-.04;hi=bones['upperarm_l']['head_m'][1]+.025;need(min(p[1] for p in g['positions_m'])>=lo-1e-12 and max(p[1] for p in g['positions_m'])<=hi+1e-12,'continuous source hem/top no old centroid stair')
 es=edge_map(g);need(max(map(len,es.values()))<=2,'vest no nonmanifold edges');graph=collections.defaultdict(set)
 for (a,b),fs in es.items():
  if len(fs)==1:graph[a].add(b);graph[b].add(a)
 need(all(len(v)==2 for v in graph.values()),'vest boundaries no branch or endpoint');seen=set();todo=[next(iter(graph))]
 while todo:
  i=todo.pop()
  if i in seen:continue
  seen.add(i);todo.extend(graph[i]-seen)
 need(len(seen)==len(graph),'one coherent vest boundary')
 uvmax=0.
 for face,uvs,fi in zip(g['triangles'],g['corner_uvs'],g['source_triangle_indices']):
  uv={source['source_vertex_indices'][i]:source['uvs'][i] for i in source['triangles'][fi]}
  for i,p in zip(face,uvs):
   expected=[math.fsum(v*uv[int(sid)][k] for sid,v in g['source_basis'][i].items()) for k in range(2)];uvmax=max(uvmax,math.dist(expected,p))
 need(uvmax<1e-12,'all vest source corner UVs retained');need(g['receipt']['maximum_discarded_cut_weight']<=.025,'unchanged cut-weight bound')
 need(all(len(w)<=4 and abs(sum(w.values())-1)<1e-12 for w in g['weights']),'vest portable skin lanes');hem=[e for e,fs in es.items() if len(fs)==1 and all(abs(g['positions_m'][i][1]-lo)<1e-12 for i in e)];need(len(hem)>20,'actual exactly planar source-clipped hem')
 return {'vertices':len(g['positions_m']),'triangles':len(g['triangles']),'exact_planar_hem_edges':len(hem),'max_source_corner_uv_error':uvmax,'maximum_discarded_skin_mass':g['receipt']['maximum_discarded_cut_weight'],'hem_y_m':lo,'top_y_m':hi}
start=time.monotonic();report={'scope':'Finite actual25/35 source invariants only, no renderer/Blender/export/animated collision/photographic or period acceptance','ages':[],'negative_controls':[],'unchanged':[]}
for age in (25,35):
 bp=ROOT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json';raw=bp.read_bytes();body=json.loads(raw);source=body['meshes'][0];bones={b['name']:b for b in body['skeleton']};height=max(p[1] for p in source['positions_m']);shirt=old.garment_shell(source,'shirt',.006,recipe,bones,height);need(new.garment_shell(source,'shirt',.006,recipe,bones,height)==shirt,'source shirt unchanged before extension');g=new.standing_collar_extension(shirt,source,bones,recipe);vest=new.garment_shell(source,'waistcoat',.014,recipe,bones,height)
 report['ages'].append({'age':age,'collar':collar_checks(g,shirt),'waistcoat':vest_checks(vest,source,bones,height),'body_sha256':hashlib.sha256(raw).hexdigest()});need(bp.read_bytes()==raw,'original body file immutable')
 if age==25:
  (D/'shirt-adult25.json').write_text(json.dumps([g],separators=(',',':')));(D/'waistcoat-adult25.json').write_text(json.dumps([vest],separators=(',',':')))
  for label,make,check in [('disconnect copied collar base',lambda q:q['collar_extension'].__setitem__('shared_base_vertex_ids',[len(shirt['positions_m'])+i for i in range(len(g['collar_extension']['shared_base_vertex_ids']))]),lambda q:collar_checks(q,shirt)),('move original shirt edge to fit ellipse',lambda q:q['positions_m'][g['collar_extension']['shared_base_vertex_ids'][0]].__setitem__(0,0.),lambda q:collar_checks(q,shirt)),('restore old jagged centroid hem',lambda q:None,lambda q:vest_checks(old.garment_shell(source,'waistcoat',.014,recipe,bones,height),source,bones,height)),('corrupt retained source UV',lambda q:q['corner_uvs'][0][0].__setitem__(0,0.),lambda q:vest_checks(q,source,bones,height))]:
   q=copy.deepcopy(vest if label=='corrupt retained source UV' else g);make(q)
   try:check(q)
   except AssertionError as e:report['negative_controls'].append({'label':label,'refused':str(e)})
   else:raise AssertionError('negative control accepted: '+label)
# No normal/probe/body/export/sole or eye helper changes are part of this successor.
functions=lambda p:{n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.FunctionDef)}
o=functions(V2/'proposed/chicago/4d/tools/human_teamster_blend.py');n=functions(D/'proposed/chicago/4d/tools/human_teamster_blend.py')
for name in o:
 if name!='build':need(o[name]==n[name],'builder function AST unchanged '+name)
report['unchanged'].append('Every builder function exceptbuild AST exact, including full object_mesh body normal/probe/raw0.001 and decimation, parse_args/identity/skin validators/morphs')
of=functions(V2/'proposed/chicago/4d/tools/human_workwear_fit.py');nf=functions(D/'proposed/chicago/4d/tools/human_workwear_fit.py')
for name in of:
 if name!='garment_shell':need(of[name]==nf[name],'original fit helper AST unchanged '+name)
report['unchanged'].append('All previous helper functions exceptgarment_shell AST exact, including fitted_shoes/_slab_points/_clip; no sole change or body mask')
oldbuilder=(V2/'proposed/chicago/4d/tools/human_teamster_blend.py').read_text();newbuilder=(D/'proposed/chicago/4d/tools/human_teamster_blend.py').read_text();tail="    for name,bone in contract['sockets']['required']:";need(oldbuilder[oldbuilder.index(tail):]==newbuilder[newbuilder.index(tail):],'sockets animation export provenance tail exact');report['unchanged'].append('Entire socket/idle/walk/seated/export/provenance tail exact')
report['PASS']=True;report['elapsed_s']=time.monotonic()-start;(D/'NARROW-SOURCE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
