# V3 source and actual preview checkpoint

Source invariants PASS; actual runtime technical PASS16/zero errors. Actual garment and photographic/world acceptance remain OPEN. Root owns tracked integration.

Apply only if root accepts the bounded source improvement and recorded remaining defects:

```sh
git -C /workspace/chicago apply --check /workspace/shared/human-tailoring-v3-source-design/TAILORING-V3-AGAINST-V2.patch
git -C /workspace/chicago apply /workspace/shared/human-tailoring-v3-source-design/TAILORING-V3-AGAINST-V2.patch
```

Patch SHA256 `4aac95205a45b6d29db3adae121d592aa12424556812f38583b51d203493fc83`, three files against applied V2. Frozen source manifest `fc655ccb2c882891cb00e7047a5f7428119f26ea8ec5ee6338ad2f3a8718151a`; independent review `5be545a7f2d59554e471bb62f408f4cf2f71e3dc7089a0c4c7f715a8209e903f`.

Collar extension shares actual96/98 shirt vertex IDs, weights and manifold oriented boundary before original decimation. It uses same linen material, authored corner-UV island and actual body-section supports; old unrelated ellipse removed. New12mm front/23mm side-back dimensions and1.2mm turn-under are explicit reconstructed engineering choices, not measured period cuts. Original shirt prefixes, body/skin/identity/rig/normal/probe/export/animation/sole paths stay unchanged. Waistcoat uses exact source-triangle trimming on the same bounds/V/arm field; original corner UV interpolation and2.5% cut-weight refusal remain.

Actual new quarter/neck/face images show straighter hem and attached collar. New closeup ALSO reveals shoulder skin patches in retained shirt, faceted/rippled collar/high-band appearance and small linen protrusions below hem. These are genuine remaining defects. Positive retained-vertex shirt clearance3.33/3.59mm does not prove complete triangle coverage. No blanket ease removal is justified; actual V2/V3 original shirt coordinates are identical. No further candidate edits after inspection.

Era AST dependency audit resolves fixed1812/1904 dynamic module choices and recursively checks all local imports. Neither era path reaches changed teamster/workwear/eye modules; shared normals/probe/hair/gait are unchanged. New1835 recipe keys do not require an era rebuild through shared imports. Material-limitations text now honestly records procedural iris atlas and retained cleared generic skin.

If root folds this into the still-uncommitted source checkpoint, regenerate required derived publication/source-use outputs, run required existing full preflight, commit/push and dispatch the existing canonical humans workflow once with both build_teamsters=true and build_seated_driver_study=true. The actual new exported source/published allLOD standing/profile/close/seated/idle/walk and unchanged sole/frame/normal receipts still require inspection. No model was committed or placed by this source/runtime preview.

Bounded next actual inspection: first review saved16PNGs, especially1280-after-neck.png. After a canonical build, inspect new exported shoulder coverage, collar/jaw/neck junction and material normal behavior in source and published desktop/mobile images before any town placement. Keep complete triangle/animated collision, independent jaw/head motion, LOD interface and historical wardrobe/photographic qualification open until real evidence exists.
