# SPDX-License-Identifier: GPL-3.0-or-later
"""Finite roof-only V10 source audit; no render or whole-vehicle collision claim."""
from pathlib import Path
import collections,hashlib,json,struct
import numpy as np
R=Path(__file__).parent
BASE=R/'baseline/brougham.glb'
ROOF={'swept_crowned_roof','roof_underside','roof_edge_fascia','roof_drip_edge','roof_end_lip','closed_upper_side_header','closed_end_crown_header'}
def load(path):
 b=path.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);binary=b[28+n:]
 def arr(ai):
  a=d['accessors'][ai];v=d['bufferViews'][a['bufferView']];assert a['componentType']==5126 and a['type']=='VEC3'
  return np.frombuffer(binary,dtype='<f4',count=a['count']*3,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,3).astype(float)
 def parts():
  result={};occ=collections.Counter()
  for p in d['extras']['parts']:
   key=(p['frame'],p['material'],p['name']);occ[key]+=1;key+=tuple([occ[key]])
   m=next(m for m in d['meshes']if m['name']=='surface_'+p['frame']+'_'+str(p['material']));s=p['triangle_start_in_batch']*3;e=s+p['triangles']*3
   result[key]=(p,arr(m['primitives'][0]['attributes']['POSITION'])[s:e],arr(m['primitives'][0]['attributes']['NORMAL'])[s:e])
  return result
 return b,d,arr,parts()
b0,d0,a0,pa0=load(BASE);b1,d1,a1,pa1=load(R/'candidate/brougham.glb')
assert hashlib.sha256(b0).hexdigest()=='03c333afc2b2e963a808e325ad37d33c8b88923672e6be362e6678bd47200798'
assert b1==(R/'repeat/brougham.glb').read_bytes();assert pa0.keys()==pa1.keys()
assert d0['nodes']==d1['nodes'] and d0['materials']==d1['materials'] and d0['scenes']==d1['scenes']
assert d0['extras']['parts']==d1['extras']['parts']
preserved=[];changed=[];minarea=1;maxnorm=0;minbodydot=1;volumes=[]
for key,(p,x,n) in pa1.items():
 old,ox,on=pa0[key];assert p==old
 same=x.tobytes()==ox.tobytes()and n.tobytes()==on.tobytes()
 if p['name']not in ROOF:assert same,'Unexpected nonroof P/N change: '+str(key);preserved.append({'part_key':key,'vertices':len(x)})
 else:changed.append({'part_key':key,'vertices':len(x),'P_N_changed':not same,'max_position_change_m':float(np.linalg.norm(x-ox,axis=1).max())})
 tri=x.reshape(-1,3,3);cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);length=np.linalg.norm(cross,axis=1)
 assert np.isfinite(x).all()and np.isfinite(n).all();minarea=min(minarea,float(length.min()/2));maxnorm=max(maxnorm,float(abs(np.linalg.norm(n,axis=1)-1).max()))
 if p['frame']=='vehicle_body':minbodydot=min(minbodydot,float(np.einsum('ij,ikj->ik',cross/length[:,None],n.reshape(-1,3,3)).min()))
 if p['name']in {'roof_drip_edge','roof_end_lip'}:
  volume=float(np.einsum('ij,ij->i',tri[:,0],np.cross(tri[:,1],tri[:,2])).sum()/6);assert volume>0;volumes.append({'part_key':key,'positive_signed_volume_m3':volume})
assert minarea>1e-10 and maxnorm<1e-5 and minbodydot>0
shell=np.concatenate([x.reshape(-1,3,3)for key,(p,x,n)in pa1.items()if p['name']in {'swept_crowned_roof','roof_underside','roof_edge_fascia'}])
edges=collections.Counter()
for tri in shell:
 ids=[tuple(x)for x in tri]
 for u,v in zip(ids,ids[1:]+ids[:1]):edges[tuple(sorted([u,v]))]+=1
assert all(k==2 for k in edges.values()),collections.Counter(edges.values())
vol=float(np.einsum('ij,ij->i',shell[:,0],np.cross(shell[:,1],shell[:,2])).sum()/6);assert vol>0
p0=json.load(open(R/'preimage/parameters.json'));p1=json.load(open(R/'proposed/parameters.json'))
allowed={'roof_longitudinal_profile_z_y_m','roof_sheet_thickness_m','roof_drip_edge_radius_m','roof_end_lip_radius_m','revision','limits'}
assert {k:v for k,v in p0.items()if k not in allowed}=={k:v for k,v in p1.items()if k not in allowed}
assert p1['limits'][:-1]==p0['limits'];assert p0['roof_longitudinal_profile_z_y_m'][:4]==p1['roof_longitudinal_profile_z_y_m'][:4]
assert p0['roof_longitudinal_profile_z_y_m'][-1]==p1['roof_longitudinal_profile_z_y_m'][-1]
assert max(y for z,y in p0['roof_longitudinal_profile_z_y_m'])==max(y for z,y in p1['roof_longitudinal_profile_z_y_m'])
assert (R/'preimage/camera-hypothesis.json').read_bytes()==(R/'proposed/camera-hypothesis.json').read_bytes()
q=json.load(open(R/'proposed/camera-hypothesis.json'))['fit'];right=np.array(q['basis']['right']);up=np.array(q['basis']['up']);toward=np.array(q['basis']['towardCamera'])
def project(points):
 dep=q['distance_m']-points@toward;return np.c_[q['principal_px'][0]+q['focal_px']*(points@right)/dep,q['principal_px'][1]-q['focal_px']*(points@up)/dep]
projection={}
for label,p in [('v9',p0),('v10',p1)]:
 points=np.array([[.64,y*1.13+.03,z]for z,y in p['roof_longitudinal_profile_z_y_m']]);projection[label]={'near_edge_profile_control_source_pixels':project(points).tolist(),'note':'Geometric control points under unchanged nonunique camera, not visible silhouette/occlusion; no actual render'}
report={'scope':'Finite roof-only source arithmetic, no runtime/source-match/photo qualification','baseline_sha256':hashlib.sha256(b0).hexdigest(),'candidate_sha256':hashlib.sha256(b1).hexdigest(),'repeat_byteexact':True,'nodes_materials_scenes_parts_metadata_exact':True,'all_nonroof_parts_P_N_exact':preserved,'allowed_roof_parts':changed,'minimum_triangle_area_m2':minarea,'maximum_normal_length_error':maxnorm,'minimum_body_stored_normal_dot_geometric_face':minbodydot,'roof_trim_positive_signed_volumes':volumes,'roof_shell_all_welded_edges_incident_twice':True,'roof_shell_positive_volume_m3':vol,'unchanged_camera_projection':projection,'limits':['Only original roof/frontheader/molding pieces may change; all door/glass/quarter/perch/wheels/hubs/pole/etc exact','No whole-vehicle collision, continuous sweep, fit, LOD, material or photographic acceptance','Sourceplateb458565e is correct; misnamed page.jpg2daf1ecd is blank background and supplies no vehicle evidence','Coachmen obscure far/front contours; numerical newroof dimensions remain reconstruction']}
(R/'SOURCE-GEOMETRY-AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k not in ['all_nonroof_parts_P_N_exact','allowed_roof_parts','unchanged_camera_projection']},indent=2))
