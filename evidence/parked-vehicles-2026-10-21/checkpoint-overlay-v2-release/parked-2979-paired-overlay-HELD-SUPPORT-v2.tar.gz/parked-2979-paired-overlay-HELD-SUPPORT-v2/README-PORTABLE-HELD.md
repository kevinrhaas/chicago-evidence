# Corrected V2 support identity — unsigned actualLayers control

V1 remains unchanged/historical. V2 fixes only the actualLayers ghost31 signed/unsigned classification and version bookkeeping. Actual pinned Layers positive/negative controls and V1 regression reproduction are included. V2 mirror bytes are read-only hardlinks to immutable V1, with origin/hash/inode-reuse policy recorded; no writes through links. The mirror remains omitted here. No release authorization or runtime result is embedded.

# Portable HELD support — not standalone runnable

This capsule preserves the prepared parked parent/new comparison caller, supervisor, unchanged root release template, source overlays, full original manifests, checkout guard, buffer/source-integrity metadata and historical freeze/verify-only receipts. It is support for root review and backup. It contains no release authorization and has launched no browser. The failed CI qualification remains failed and merge remains stopped.

Original prepared-manifest SHA256:
`2b65a3b2f627ba252a6826fd871e431d7db545c80b2138c315c5b972374c7bfe`

The `prepared-metadata-and-source/` files retain their original bytes. The original manifest deliberately continues to list omitted files; it must not be edited to pretend this capsule is complete. All new portability documentation is outside that copied preparation.

## Included and omitted

- Exact caller/supervisor/template/HELD status and source overlays, including exact fdb227dbf/2aeb runtime and new model bytes. Common coalescing/buildings support is included for static review; no coalescer activation exists.
- Full original `PREPARED-MANIFEST.json`, source overlay manifest, six decoded prebuilt-buffer integrity results, all declared prebuilt-source-input comparison, original14,909-file checkout guard and raw index hash.
- External historical freeze receipt and verify-only result; the V2 verify-only result sawzero active browser processes at its recorded time and is not current lane-readiness evidence.
- **Omitted:** all5,142 read-only V1-linked private mirror files,352,408,342bytes, including duplicate vendor resources; all804 externally pinned runtime/dependency files,679,593,888bytes. The runtime files were never embedded in the original package either. Their exact individual paths/lengths/SHA256 values remain in the original manifest.

## Exact reacquisition, if the original environment survives

1. Recover the original frozen directory `/workspace/shared/parked-2979-paired-overlay-PREPARED-HELD-v2` from the original environment or a separate complete artifact. The omitted mirror is under its `mirror/` directory. Copy real bytes, not hardlinks to mutable app output.
2. For every omitted `mirror/...` entry in `prepared-metadata-and-source/PREPARED-MANIFEST.json`, require exact path, byte length and SHA256. The manifest is the complete5,142-file reacquisition inventory. A directory merely labelled2aeb is insufficient. The copied prebuilt integrity metadata additionally identifies compressed-wire and fully decoded buffer hashes and all declared gzip passes.
3. Restore every `external_runtime_pins` entry at its original absolute path and require its exact hash. `RUNTIME-REACQUISITION-LOCATORS.json` records Playwright/playwright-core1.56.1 as a locating aid; version equality alone is insufficient. Chromium wrapper/binary/resources, Node, Python and every recorded package file must match. Do not reuse downloaded packages or a system browser under an old receipt without checking their pinned bytes.
4. Included overlay bytes can independently be recovered from repository `kevinrhaas/chicago` objects at parent `fdb227dbf5ed952921ef652f5a02480fffdad462` and failed candidate `2aebef95f6a5b6fa1bd8353db936c7674a73c32f`, by reading each manifest source path as a Git blob and checking its saved SHA256. No checkout, ref rewrite or app-file replacement is required to read those objects. Saved `common` support blobs are pinned to2aeb. The original source-path manifest and complete capsule inventory preserve the bindings.
5. Recovering dependencies does not release the caller. Root must still review the full reconstructed preparation, verify current source/mirror/index protection, wait for the covered lane to be actually CLOSED, bind its current terminal evidence and departed PID(s), and create a separate explicit release file. Do not activate the copied HELD template or run the caller from this support capsule.

## If exact omitted bytes or the old checkout no longer exist

Stop exact reacquisition. A new publish from either commit is a newly generated substrate: stamps, compressed representations and generated prebuilt files can differ. Do not retag files or replace their hash entries while retaining the old manifest identity. Prepare a new isolated shared snapshot and a new reviewed manifest/release instead, preserving the old evidence and clearly naming any changed substrate/runtime conditions.

The historical checkout guard has HEAD2aeb but covers the then-staged covered work as well; its raw index SHA256 is `d03d1b392717001c639a2ae9b830f8b5d4b22e548e0cb7afbead99daae7f2edf`. The complete dirty/staged tree and raw index payload are **not embedded**. Neither this commit nor a list of hashes can reconstruct those staged bytes. Root must not overwrite an active checkout or attempt to manufacture the old index to satisfy a guard. A different or advanced checkout requires an explicitly re-bound, freshly reviewed protection snapshot and new preparation identity.

Absolute paths remain unchanged in the callers and original manifests (`/workspace/chicago`, the original shared directory and runtime dependency locations). Merely extracting this archive in another directory does not make it runnable. Relocation/path edits require a new reviewed preparation and hashes, without changing this support capsule or the original frozen manifest.

No current source/tree/index comparison, browser verification retry, package installation, network retrieval, source/app/test/CI/ref mutation or release was performed to make this capsule. Only copied-file/archive integrity was checked. Hidden target cadence, historical CI pose/effective tier, actual GL instrumentation and Chromium helper process-group behavior retain the uncertainties documented in the original README.
