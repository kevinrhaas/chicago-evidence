# SPDX-License-Identifier: CC0-1.0
"""Original CC0 bay-coat material study; no geometry, rig or motion change.

This is an authored appearance hypothesis, not a named animal or breed claim.
The native 1024 maps are generated here from seeded fields. No photographic
textures, downloaded image derivatives, upscaling, or AI imagery are used.
"""
from pathlib import Path
import copy
import hashlib
import io
import json
import math
import struct

import numpy as np
from PIL import Image, ImageFilter

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/shared/horse-natural-labial-corner-three-primitives-next/candidate-one/candidate.glb')
SOURCE_SHA = '419a6194b660bcd9ab1f7da21a2b1fcbd67d9ba620d294fd6299440dc8890c31'


def digest(b):
    return hashlib.sha256(b).hexdigest()


def read_glb(b):
    magic, version, length = struct.unpack_from('<III', b)
    assert (magic, version, length) == (0x46546c67, 2, len(b))
    n, t = struct.unpack_from('<II', b, 12)
    assert t == 0x4e4f534a
    g = json.loads(b[20:20+n])
    offset = 20+n
    bn, bt = struct.unpack_from('<II', b, offset)
    assert bt == 0x004e4942 and offset+8+bn == len(b)
    return g, b[offset+8:]


def array(g, b, index):
    a = g['accessors'][index]
    v = g['bufferViews'][a['bufferView']]
    assert a['componentType'] == 5126 and not v.get('byteStride')
    size = {'VEC3': 3, 'VEC2': 2}[a['type']]
    return np.frombuffer(b, dtype='<f4', count=a['count']*size,
                         offset=v.get('byteOffset', 0)+a.get('byteOffset', 0)).reshape(-1, size).copy()


def png(a):
    out = io.BytesIO()
    Image.fromarray(a.astype(np.uint8), mode='RGB').save(out, format='PNG', optimize=False)
    return out.getvalue()


def textures():
    """Small directional coat variation, not painted muscles or shadows."""
    rng = np.random.default_rng(20261021)
    n = 1024
    raw = np.clip(rng.normal(127, 28, (n, n)), 0, 255).astype(np.uint8)
    # Narrow longitudinal filtering makes short directional fibres. The result
    # stays intentionally subtle at distance; no pixel is a fake lit highlight.
    fine = np.asarray(Image.fromarray(raw).filter(ImageFilter.BoxBlur(.35)), dtype=float)/255
    coarse = rng.normal(127, 18, (64, 64)).clip(0, 255).astype(np.uint8)
    broad = np.asarray(Image.fromarray(coarse).resize((n, n), Image.Resampling.BICUBIC)
                       .filter(ImageFilter.GaussianBlur(6)), dtype=float)/255
    yy, xx = np.mgrid[0:n, 0:n]
    fibre = np.sin(xx*.51 + np.sin(yy*.011)*1.4 + fine*3)
    albedo = np.clip(.942 + (fine-.5)*.035 + (broad-.5)*.045 + fibre*.0035, .90, .98)
    # G is glTF perceptual roughness. R=1 (no AO), B=0 (dielectric).
    roughness = np.clip(.44 + (fine-.5)*.11 + (broad-.5)*.06, .36, .53)
    base = np.repeat((albedo[..., None]*255), 3, axis=2)
    orm = np.stack([np.full((n,n),255), roughness*255, np.zeros((n,n))], axis=-1)
    return {'coat-albedo.png': png(base), 'coat-roughness.png': png(orm)}


def smooth(lo, hi, x):
    t = np.clip((x-lo)/(hi-lo), 0, 1)
    return t*t*(3-2*t)


def coat_colors(p):
    x, y, z = p.T.astype(float)
    # Original bay-colour reconstruction: black points below the knees/hocks,
    # darker muzzle, slight warm ventral variation. These are appearance choices,
    # not anatomy/lighting baked into the texture or asserted historic colour.
    chestnut = np.array([.255, .075, .026])
    points = np.array([.024, .018, .014])
    lower = (1-smooth(.51, .89, y)) * smooth(.07, .12, abs(x))
    muzzle = smooth(1.04, 1.26, z) * (1-smooth(1.81, 1.95, y))
    amount = np.maximum(lower, muzzle*.90)
    colors = chestnut[None, :]*(1-amount[:, None])+points[None, :]*amount[:, None]
    # Very small broad tonal variation; no hard material seam or identity mark.
    variation = .96+.045*np.sin(z*3.1+y*1.3)+.020*np.cos(x*6.2-y*2.1)
    return np.asarray(np.clip(colors*variation[:,None], 0, 1), dtype='<f4')


def main():
    out = ROOT/'candidate'
    out.mkdir(exist_ok=False)
    b = SOURCE.read_bytes()
    assert digest(b) == SOURCE_SHA
    old, binary = read_glb(b)
    g = copy.deepcopy(old)
    storage = bytearray(binary)
    original_length = len(storage)

    def append_blob(data, target=None):
        while len(storage)%4:
            storage.append(0)
        view = {'buffer':0, 'byteOffset':len(storage), 'byteLength':len(data)}
        if target:
            view['target'] = target
        storage.extend(data)
        g['bufferViews'].append(view)
        return len(g['bufferViews'])-1

    def append_array(values):
        view = append_blob(values.tobytes(), 34962)
        a = {'bufferView':view, 'componentType':5126, 'count':len(values),
             'type':{2:'VEC2', 3:'VEC3'}[values.shape[1]],
             'min':values.min(axis=0).tolist(), 'max':values.max(axis=0).tolist()}
        g['accessors'].append(a)
        return len(g['accessors'])-1

    g['images'] = []
    g['textures'] = []
    g['samplers'] = [{'magFilter':9729, 'minFilter':9987, 'wrapS':10497, 'wrapT':10497}]
    maps = textures()
    for name,data in maps.items():
        (out/name).write_bytes(data)
        g['images'].append({'name':name, 'mimeType':'image/png', 'bufferView':append_blob(data)})
        g['textures'].append({'source':len(g['images'])-1, 'sampler':0})

    uv, color = {}, {}
    for mesh in g['meshes']:
        for prim in mesh['primitives']:
            if prim.get('material') != 0:
                continue
            position = prim['attributes']['POSITION']
            p = array(old, binary, position)
            if position not in uv:
                # One fixed lateral projection in immutable authoring coordinates.
                # Addition of UV/COLOR only; no vertex splitting or position edit.
                tex = np.asarray(np.stack([(p[:,2]+1.10)/2.50, p[:,1]/2.20], axis=1), dtype='<f4')
                uv[position] = append_array(tex)
                color[position] = append_array(coat_colors(p))
            prim['attributes']['TEXCOORD_0'] = uv[position]
            prim['attributes']['COLOR_0'] = color[position]

    coat = g['materials'][0]['pbrMetallicRoughness']
    coat.update(baseColorFactor=[1,1,1,1], baseColorTexture={'index':0},
                metallicRoughnessTexture={'index':1}, metallicFactor=0, roughnessFactor=1)
    g['materials'][1]['pbrMetallicRoughness'].update(baseColorFactor=[.018,.014,.011,1], roughnessFactor=.55)
    g['materials'][2]['pbrMetallicRoughness'].update(baseColorFactor=[.055,.049,.041,1], roughnessFactor=.48)
    g['materials'][3]['pbrMetallicRoughness'].update(baseColorFactor=[.008,.006,.004,1], roughnessFactor=.075)
    g.setdefault('asset',{}).setdefault('extras',{}).update(
        chicago4dMaterialStudy='Original CC0 bay coat; unoccupied idle study only; anatomical/photographic acceptance OPEN',
        input_sha256=SOURCE_SHA, texture_resolution=1024,
        historical_status='Coat colours, points, finish and exact animal appearance are reconstructed. No Chicago horse identity or breed is asserted.')
    g['buffers'][0]['byteLength'] = len(storage)
    encoded = json.dumps(g,separators=(',',':')).encode()
    encoded += b' '*((-len(encoded))%4)
    padded = bytes(storage)+b'\0'*((-len(storage))%4)
    result = struct.pack('<III',0x46546c67,2,12+8+len(encoded)+8+len(padded))
    result += struct.pack('<II',len(encoded),0x4e4f534a)+encoded
    result += struct.pack('<II',len(padded),0x004e4942)+padded
    (out/'candidate.glb').write_bytes(result)

    # Independent byte-preservation obligations are cheap and decisive for a
    # material-only variant; there is no reason to rerun the unchanged SAT mesh.
    decoded, actual = read_glb(result)
    assert actual[:original_length] == binary
    for key in ['nodes','skins','animations','scenes','scene']:
        assert decoded.get(key) == old.get(key), key
    assert decoded['accessors'][:len(old['accessors'])] == old['accessors']
    assert decoded['bufferViews'][:len(old['bufferViews'])] == old['bufferViews']
    for om,nm in zip(old['meshes'],decoded['meshes']):
        for op,np_ in zip(om['primitives'],nm['primitives']):
            expected=copy.deepcopy(np_)
            for key in ['TEXCOORD_0','COLOR_0']:
                if key not in op['attributes']:
                    expected['attributes'].pop(key,None)
            assert expected == op
    proof={'PASS':True, 'scope':'Material-only byte preservation, not visual/photo acceptance',
           'source':str(SOURCE),'source_sha256':SOURCE_SHA,'candidate_sha256':digest(result),
           'binary_prefix_bytes':original_length,'all_original_geometry_normals_indices_weights_rig_animation_bytes':'EXACT',
           'triangles':13456,'primitives':6,'images':[{ 'file':n,'sha256':digest(v),'bytes':len(v),'native_size':[1024,1024],'license':'CC0-1.0; original project procedural work'}for n,v in maps.items()],
           'new_uv_and_color_accessors':len(uv)*2,'added_draws':0,'decoded_texture_bytes':2*1024*1024*4,
           'limitations':['No horse anatomy or silhouette improvement','No new pose, motion, halter, rope, load or hitch acceptance','No measured period coat/breed/individual evidence','Images and materials still require actual matched rendering and review']}
    (out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps(proof,indent=2))


if __name__ == '__main__':
    main()
