# Static horse coat study — 2026-10-21

Candidate `93177c8a149c21b8ea15c6f19d645cbbbf9c687ed2115f76eb9d545d41d02231`
is a geometry-preserving material derivative of the previously fully idle-checked
`419a6194b660bcd9ab1f7da21a2b1fcbd67d9ba620d294fd6299440dc8890c31` horse.
It is an optional original bay-colour reconstruction, not a historical animal,
breed, likeness or coat identification. It is **not photographically accepted**.

## Actual result

The old uniform flat brown finish gains dark bay-style lower points and muzzle,
subtle native1024 original coat variation, spatial roughness and different mane,
hoof and eye finishes. No photographed pixels were used. The authored vertex
colour and image fields are generated deterministically by `build.py`.

`candidate/proof.json` confirms the complete old2,413,720-byte binary prefix, all
old accessors, primitive indices/attributes, nodes, skins and animation records
are exact. New UV and vertex-colour attributes are appended; no original geometry,
normal, position, weight, joint, rig, socket or clip changed. No redundant physical
SAT scan was performed. The known419a idle physical result is not a new motion,
grounding, tether, harness, force or rider qualification.

Khronos reports0errors/0warnings (86 informational inherited unused/empty-node
messages). The actual matched browser run passed in5.338seconds:8PNGs, desktop
1280x900 and mobile390x844, whole horse and mouth quarter, both variants, exact
same camera/projection and idle0, full actual primitive/P/N/index coverage,
0page/console/WebGL errors, both corruption refusals and late-fetch disposal,
browser/server closed. `appearance-actual-one/receipt.json` retains details.

The author actually viewed the desktop before/after whole-horse frames, desktop
after mouth quarter and mobile after whole. The finish is visibly less flat.
**Coarse body/leg joins, straight limbs, angular ears/nostril, weak mouth anatomy,
tiny eyes and the open bit portal remain obvious**. Material work does not make
this photographic. The generated fibre detail is subtle in these render sizes.
Vehicle work should land first, as the owner requested.

## Cost and proposed admission

13,456triangles /6primitives /0added draw calls. Two1024x1024 decoded RGBA8 maps
cost8MiB base, about10.67MiB with a complete mip chain; their PNGs are785,578bytes
combined. This budget needs deliberate admission for a single near static study,
not multiplication across all scene horses. Do not change the legacy default or
enable walk/trot just because these clips remain stored unchanged.

The quickest defensible eventual main-scene test is **one idle, unoccupied horse
without driving/riding gear** at an existing reconstructed stable, with original
terrain/grounding/collision and current source+published mobile/desktop inspection.
Possible1835 existing records are `stable_blk_lake_clinton_lot8` (belongs to
`inf_teamster_dwelling_west`) and `stable_blk_lake_wells_lot6` (belongs to
`inf_teamster_dwelling_south`) in `data/yard/town_yard_outbuildings.json`. That file
and L353 explicitly reconstruct horse-keeping/stables by household class; neither
attests this animal, colour, position, post or tether. Exact location must be chosen
in the scene after checking doorway, yard, street/wall clearance and ground height.
**No hitch post or tether is supplied or qualified here.** Until halter/tether
construction is real and checked, describe a standing horse near the stable rather
than a horse tied to a post. Do not use an incomplete driving harness to fake it.

For1904, choose a separately supported stable/carriage-yard location. Do not carry
an1835 coordinate or household inference into1904, and do not call a parked horse
the personal property of a named resident without evidence.

## Source / license / integration

`build.py` and the two generated images are original CC0-1.0 project work. The input
horse's CC0 project provenance is recorded under assets/LICENSES.md's equine
prototype/head-neck refinement entries. Existing research informs reconstruction,
not photographic copying. Copied diagnostic viewer/inspection helpers retain their
existing GPL-3.0-or-later headers. This does not relicense those helpers.

Root alone integrates tracked app/tickets. The input419a is still an outside-app
qualified reference, so this is not an app patch ready to apply blindly: root must
decide how to admit that authored model with its original generation/source closure,
license rows, a new asset/manifest ID and explicit placement liberties. Preserve
the exact source proof and run normal app/published gates. Do not close T-2800 or a
photographic/interaction ticket because this source/material study passes.

No local Blender, app mutation, Git mutation, scene placement or browser process
is left by this work. `appearance/` is a minimal adaptation of the existing reviewed
matched viewer; loaded images are embedded bufferViews, and only internally
generated blob URLs are permitted after all external resource URIs are refused.
