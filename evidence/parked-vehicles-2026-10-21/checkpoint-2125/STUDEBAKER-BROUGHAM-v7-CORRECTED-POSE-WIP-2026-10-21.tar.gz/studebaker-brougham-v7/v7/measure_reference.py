# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import hashlib,json,struct
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).parent;I=R.parent/'reference-inspection-v7-front';A=I/'actual';h=json.loads((R/'camera-hypothesis.json').read_text());q=h['fit'];b=(R/'candidate/brougham.glb').read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);binary=b[28+n:]
def arr(ai):
 a=d['accessors'][ai];v=d['bufferViews'][a['bufferView']];return np.frombuffer(binary,dtype='<f4',count=a['count']*3,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,3)
parent={c:i for i,no in enumerate(d['nodes'])for c in no.get('children',[])}
def world(i):
 out=np.zeros(3)
 while True:
  out+=d['nodes'][i].get('translation',[0,0,0])
  if i not in parent:break
  i=parent[i]
 return out
right=np.array(q['basis']['right']);up=np.array(q['basis']['up']);toward=np.array(q['basis']['towardCamera']);cx,cy=q['principal_px'];F=q['focal_px'];D=q['distance_m']
def proj(p):
 depth=D-p@toward;return np.c_[cx+F*(p@right)/depth,cy-F*(p@up)/depth]
selected=['deep_U_closed_door','side_door_glass','rear_quarter_panel','swept_crowned_roof','rounded_iron_tire','solid_bright_hub_button'];rows=[]
for mi,m in enumerate(d['meshes']):
 nodei=next(i for i,no in enumerate(d['nodes'])if no.get('mesh')==mi);frame=d['nodes'][parent[nodei]]['name'];pr=m['primitives'][0];vertices=arr(pr['attributes']['POSITION'])
 seen=set()
 for p in d['extras']['parts']:
  if p['name'] not in selected or p['frame']!=frame or p['material']!=pr['material']:continue
  key=(p['name'],p['triangle_start_in_batch'],p['triangles'])
  if key in seen:continue
  seen.add(key);s=p['triangle_start_in_batch']*3;points=vertices[s:s+p['triangles']*3].astype(float)+world(nodei);pixels=proj(points);near=bool(points[:,0].mean()>0)
  rows.append({'part':p['name'],'frame':frame,'side':'both' if points[:,0].min()<0<points[:,0].max() else 'near'if near else'far','source_px_min':pixels.min(0).tolist(),'source_px_max':pixels.max(0).tolist(),'world_min_m':points.min(0).tolist(),'world_max_m':points.max(0).tolist()})
# Vertical radius is the major ellipse axis approximately; actual rim/mesh envelope differs from ideal wheel radius by the rounded tire section.
r={'candidate_sha256':hashlib.sha256(b).hexdigest(),'projection':'Actual browser positive-Z perspective hypothesis, source-pixel coordinates, full selected triangle vertices before occlusion','parts':rows,'camera':q,'manual_control_limits':h['limits'],'important':'No all-part bounding box is a visible silhouette or an exact historic measurement; roof is both sides, door records each side separately.'}
(A/'mesh-source-pixel-measurements.json').write_text(json.dumps(r,indent=2)+'\n')
source=Path('/workspace/shared/dearborn-history-2026-10-21/studebaker-brougham-cdn.jpg');assert hashlib.sha256(source.read_bytes()).hexdigest()=='b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe'
primary=Image.open(source).convert('RGB');receipt=json.loads((A/'receipt.json').read_text());row=receipt['rows'][0];fit=row['referenceFit'];scale=fit['sourceCropScale'];pad=fit['paddingPx'];crop=fit['sourceCrop'];candidate=Image.open(A/'desktop-reference.png').convert('RGB');aligned=Image.new('RGB',candidate.size,'#e9e7df');piece=primary.crop(tuple(crop));piece=piece.resize((round(piece.width*scale),round(piece.height*scale)),Image.Resampling.LANCZOS);aligned.paste(piece,(round(pad[0]),round(pad[1])));aligned.save(A/'actual-source-aligned.png')
controls=h['controls'];over=aligned.copy();co=candidate.copy()
for img in[over,co]:
 draw=ImageDraw.Draw(img)
 for c in controls:
  x=pad[0]+(c['center_px'][0]-crop[0])*scale;y=pad[1]+(c['center_px'][1]-crop[1])*scale;draw.ellipse((x-5,y-5,x+5,y+5),outline='red',width=2);draw.text((x+6,y+5),c['name'],fill='red')
for y in range(450,951,50):
 yy=pad[1]+(y-crop[1])*scale
 for img in[over,co]:ImageDraw.Draw(img).line((pad[0],yy,pad[0]+820*scale,yy),fill='#d0a0a0',width=1)
header=56;sheet=Image.new('RGB',(candidate.width*2,candidate.height+header),'white');sheet.paste(over,(0,header));sheet.paste(co,(candidate.width,header));dr=ImageDraw.Draw(sheet);dr.text((16,12),'ACTUAL SOURCE b458 plate0095; manual controls, source-only people/horses omitted from model',fill='black');dr.text((candidate.width+16,12),'V7 corrected front-oblique diagnostic: no cabin changes, source match UNACCEPTED',fill='black');sheet.save(A/'plate-versus-v7-front-contact-sheet.png')
print(json.dumps([x for x in rows if x['part']in ['swept_crowned_roof','deep_U_closed_door','rounded_iron_tire']],indent=2))
