# Studebaker Brougham v7 — source comparison WIP, not accepted

This is an original static, empty, closed Brougham appearance reconstruction for a possible 1904 scene. The named maker/type comes from Studebaker's 1893 catalog plate0095, actual image SHA b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe. No particular 1904 specimen, owner, Prairie location, exact dimensions, hidden upholstery or opposite-side construction is attested. No boarding, occupants, animation or traffic is supplied. This is separate from the generic C02 already installed in the app.

## What changed

The v6 producer is byte-identical. Parameters change wheelbase 1.90 to 2.40m and front radius .475 to .500m, retaining rear radius .650m. Absolute metres are reconstruction, not source measurements. All six body material batches, four cap/button batches and each wheel's rounded hub/solid core P/N arrays remain bit exact. Materials, part ranges, topology and 41-node hierarchy remain intact. The resulting candidate is 49ff146c67131b5e7d5dfbd8bf260eade8c218829a009f67494b4dc4658aae02, 2,289,772 bytes / 30,804 triangles / 24 mesh batches. Repeat production is byte exact; Khronos reports 0 errors / 0 warnings (4 empty seat/hitch informational nodes). Minimum triangle area 2.7063e-6m²; maximum normal-length error 4.2063e-8.

## Camera corrections and actual evidence

All old approximate numerical landmarks from the original research brief are withdrawn. Independently corrected near hubs are front (810,820) ±3px / rear (1277,795) ±4px; approximate radii106±5 /137±5px. These are manual illustration estimates, not certified bounds.

The first v7 six-frame actual capture in `reference-inspection-v7` retained a negative-Z/rear-oblique camera. Its exact near-pair residual is construction arithmetic, not source acceptance: actual source far wheels lie LEFT of their near wheels, while this camera put them RIGHT. Raw captures/receipt are preserved as withdrawn camera evidence. Do not use this pose to judge cabin length.

The second actual diagnostic in `reference-inspection-v7-front` uses positive-Z/front-oblique perspective and all four hubs plus visible rim radii with weighted residuals. Loose provisional far controls are front(750,795) ±12px and rear(1215,775) ±15px, radii98±12/125±15px. An independent reviewer recommends at least ±15px for both far hubs because of overlap; these are weaker than the corrected near pair. A fitting objective does not create calibrated camera evidence.

This hypothesis uses azimuth11.80°, elevation2.25°, mathematical distance175.55m/focal34936.73sourcepx (near orthographic; nonunique). Actual near-face projection in source pixels is front(809.16,822.33), rear(1278.67,788.81). Ideal rim vertical radii are99.96/129.60px, so fixed WB2.40 leaves residuals outside parts of the informal near-control ranges. This remains an UNACCEPTED source fit. Camera matrices, face offsets, source-space mesh bounds, fit objective and controls are saved. Camera target metadata records the actual target, correcting the v6 diagnostic's generic-center metadata. Visible hub centers use solid-button outer-face axial offset .096m, not wheel frame origins.

Both runs ended with browser and server CLOSED, six desktop/mobile frames each, zero console/page/GL errors. Full-carriage side/front views pass .98 framing and DOM checks. Reference diagnostic reports selected AABB clipping on mobile; actual visible carriage fits, but the AABB corners are not a visible silhouette. Its technical guard is diagnostic and does not mean source or photographic acceptance.

## Actual visual findings after the corrected pose

Read `reference-inspection-v7-front/actual/plate-versus-v7-front-contact-sheet.png` beside the actual primary; the source image is solely comparison evidence and is not a model texture. All numerical comparisons below are source-pixel coordinates in this hypothesis, not historic metres.

* Far-wheel handedness now matches; near/rear quarter positions align much better. The earlier blanket long-cab/roof-shrink conclusion is withdrawn. Cabin geometry was not edited to mask a camera error.
* The complete roof mesh spans x887.9–1253.9,y539.3–570.7, including both near and far edges. Actual visible primary roof is around y480–510, informally ±10px with coachmen occluding its front. The roof/cabin currently sits visibly low and has a shallow crown. Compare corresponding near edges, not a two-side mesh bounding box against one visible edge.
* Near U-door mesh spans x967.1–1122.7,y663.2–843.6. Actual near door bottom appears around y830, informally ±10px. Source window bottom/curved lower rail is around y620–635; the prototype's near glass bottom is lower. Roof/window/door vertical proportions need coordinated revision after wheel/camera refinement.
* The prototype driver perch and supports are sparse and angular; primary coachmen, garments and lap robe occlude much of the real seat. Add source-supported exterior shaping and ornament, while retaining the empty-seat upholstery claim as reconstruction.
* Primary molding/door hardware and wheel spokes look finer and denser than the prototype. Exact spoke count is not established by this single overlapping view. Bright solid hub buttons are present and no longer open torus holes.
* Rear-quarter outline is curved in profile but its cross-width side surface remains planar; source curved highlights are not reproduced. The body shows faceting/self-shadow artifacts, and transparent glass double surfaces/empty interior differ from source occupants/occlusions. These are open appearance issues. No photographic-quality claim is made.

## Shortest next work

Keep this v7 packet immutable. Before editing cabin geometry, refine wheelbase/radius ratios and the positive-Z hypothesis against all four hub/rim controls with uncertainties. A first finite proposal is wheelbase roughly2.25–2.30m at rear radius.65m rather than2.40m, subject to the source ambiguity; this is a ratio hypothesis, not measured dimensions. Then raise/recurve cabin and glazing/roof using actual corresponding visible edges, retain rear-quarter placement, add fine molding/perch ornament and address body faceting/shadows. Re-render bounded actual comparisons before considering app placement. Do not turn near-anchor zero residual into whole-model acceptance. Preserve the generic C02 in the app until a named replacement passes actual source review.

## Reproduce

Generate fresh outputs with Python+NumPy:

`OPENBLAS_NUM_THREADS=1 python v7/generate_brougham.py --output /tmp/brougham-v7-fresh`

`v7/review_geometry.py` compares against sibling frozen v6 and candidate/repeat folders. The saved producer byte hash and candidate hash allow standalone reproduction without those review inputs. Khronos validator package is `gltf-validator`2.0.0-dev.3.10. `v7/fit_camera.py` uses NumPy+SciPy; one math thread is sufficient.

Each actual fixture's `capture.cjs` uses local Playwright, `/usr/bin/chromium`, and a temporary loopback Python server with a 90s deadline. It expects Playwright at `/workspace/shared/chicago-browser/node_modules/playwright` and a vendor symlink to the installed Three0.185.1 tree. These are environment paths, not downloaded runtime dependencies. Run only in a fresh copy because the actual output directory is append-protected. No browser is currently running. Parent requested HOLD during its next full preflight; do not launch until it releases the lane.
