"""One <=90s owned browser/server preview. No app writes, no canonical claim."""
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from threading import Thread
import json,mimetypes,subprocess,time,os,signal

ROOT=Path('/workspace/chicago/chicago/4d').resolve();HERE=Path(__file__).parent.resolve()
PARCEL=Path('/workspace/shared/human-workwear-visible-repair-v2').resolve()
MODEL=Path('/workspace/shared/human-visible-next/bardwell_otis_1835.lod0.glb')
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        name=self.path.split('?',1)[0]
        if name.startswith('/app/'):
            path=(ROOT/name.removeprefix('/app/')).resolve();base=ROOT
        elif name=='/model.glb':path=MODEL;base=MODEL.parent
        elif name=='/':path=HERE/'preview.html';base=HERE
        elif name.lstrip('/') in {'shirt-adult25.json','waistcoat-adult25.json','trousers-adult25.json','shoes-adult25-lod0.json','eyes-adult25-lod0.json','iris-original-preview.png'}:
            path=PARCEL/name.lstrip('/');base=PARCEL
        else:self.send_error(404);return
        if not path.is_relative_to(base) or not path.is_file():self.send_error(404);return
        data=path.read_bytes();self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(path.name)[0] or 'application/octet-stream');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=Thread(target=server.serve_forever,daemon=True);thread.start()
port=server.server_address[1]
try:
    process=subprocess.Popen(['node',str(HERE/'capture_preview.cjs'),str(port)],env={**os.environ,'NODE_PATH':'/workspace/shared/chicago-browser/node_modules'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
    try:stdout,stderr=process.communicate(timeout=85)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid,signal.SIGKILL)
        stdout,stderr=process.communicate(timeout=3)
        raise RuntimeError('bounded preview timeout; owned browser process group killed')
    (HERE/'PREVIEW-stdout.log').write_text(stdout);(HERE/'PREVIEW-stderr.log').write_text(stderr)
    if process.returncode:raise RuntimeError('owned browser EXIT'+str(process.returncode)+': '+stderr[-1500:])
finally:server.shutdown();server.server_close();thread.join(timeout=2)
print('Readonly runtime-swap source preview finished; server and browser closed.')
