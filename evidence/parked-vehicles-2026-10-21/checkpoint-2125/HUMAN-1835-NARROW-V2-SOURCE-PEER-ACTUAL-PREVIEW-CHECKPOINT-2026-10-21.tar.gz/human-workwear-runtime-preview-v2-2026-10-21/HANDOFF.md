# Narrow1835 source checkpoint — V2

Status: source controls and finite independent invariants review PASS; actual repeat runtime preview EXIT0 with12captures and zero errors. Observed trouser tear and serrated neckline are improved. This is eligible for a source checkpoint; collar fit/motion, canonical exports and photographic/world acceptance remain OPEN. Root owns tracked integration.

## Exact source integration

Frozen source directory: `/workspace/shared/human-workwear-visible-repair-v2`. Patch SHA256 `6c9a9ed220217e1fc64a377cda85caedf1cfda0bb189b15e5272b788d321a047`. Parent parked app is `2aebef95f6a5b6fa1bd8353db936c7674a73c32f`; both human source preimages match exactly, and readonly apply check passed. No old PR1099 recovery patch is needed.

After final source/preview checkpoint, on the new human branch from the intended current DEV:

```sh
git -C /workspace/chicago apply --check /workspace/shared/human-workwear-visible-repair-v2/WORKWEAR-VISIBLE-REPAIR.patch
git -C /workspace/chicago apply /workspace/shared/human-workwear-visible-repair-v2/WORKWEAR-VISIBLE-REPAIR.patch
```

The patch adds two authoring helpers and modifies only the existing1835 teamster builder and recipe. It preserves the original identity/body/skin/rig, raw0.001 normal guard, exporter, unchanged2mm sole-contact guard and socket/idle/walk/seated controls. It does not enable a person in town. Root adds required project/license/changelog/ticket notes and runs the existing full preflight before commit/push and an owner-visible DEV PR.

## Existing canonical path

Once the intended source is committed/pushed, dispatch exactly once on the new source branch:

```sh
gh workflow run chicago-4d-humans.yml --repo kevinrhaas/chicago \
  --ref <actual-new-human-branch> \
  -f build_teamsters=true -f build_seated_driver_study=true
```

Bind the returned workflow event to the exact pushed commit. The ordinary automatic PR humans job does not generate canonical residents. No new workflow/input is needed; experimental normal probing is already part of this workflow. Do not duplicate dispatch because per-ref concurrency cancels earlier runs.

Inspect the actual newly generated resident-teamster artifact, including all source/published standing, close, profile and seated captures, four LODs, actual animation/hair/frame/normal and unchanged sole receipts. Runtime preview uses unchanged actual CI body/rig but new source-array meshes, so canonical exported quality remains unproven. No photograph-level acceptance or world placement may be inferred from source controls.

If the first resident is accepted, import only that resident’s four source and four published GLBs with exact provenance/hashes/licenses, remeasure the actual committed set using the existing `human_fixture.mjs --write`, and inspect the actual1835 instance before placing. The artifact itself does not commit models or place people. Glessner1904’s old prototype remains unsuitable.

## Candid appearance limits

This narrow successor removes trouser globalX ease while preserving7mm source-shared normal offset and replaces the stepped neckline with source-triangle collar-base clipping and explicit collar-only neck weighting. The fitted footwear and opaque sclera/iris/pupil improvements from V1 remain. Body masking and threshold relaxation are absent.

Waistcoat hem/armhole/corners still need garment tailoring; seams, lapels, buttons, fabric construction, mature skin/eye realism and likeness/period review remain open. Do not call this photographic completion or completed rideable humans.

## Actual final checkpoint

Runtime evidence: `RUNTIME-SOURCE-PREVIEW.json`, `ACTUAL-VISUAL-FINDINGS.json` and12PNGs in this directory. The browser/server were closed at terminal. Peer report: `/workspace/shared/human-workwear-v2-independent-review/INDEPENDENT-REVIEW.json`, SHA256 `08fc41be4794d96d0f2e66a66e93c293fef8269b077366ee47eaf678dd1b6601`. Peer sampled rest,117idle,94walk and61sit_drive times using actual prior CI skin matrices as inert data. Source invariants PASS, but collar fit/independent-motion acceptance remains open.

Actual viewed before/after evidence shows the inner-left trouser tear gone, continuous neckline replacing the serrated cut, retained toe enclosure and opaque sclera/iris/pupil. The neckline still reads as a crude raised band, with dark/open side junction to the retained collar visible close. Peer measured34.4mm rest/35.8mm animated separation; old clips do not independently move head/jaw versus neck. Do not market the collar as tailored or motion-qualified. This source checkpoint does not claim photograph-quality completion or approve town placement.
