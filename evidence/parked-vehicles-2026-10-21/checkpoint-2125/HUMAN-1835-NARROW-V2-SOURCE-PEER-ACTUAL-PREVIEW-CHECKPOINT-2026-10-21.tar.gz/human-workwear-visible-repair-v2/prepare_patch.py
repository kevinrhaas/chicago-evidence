from pathlib import Path
import json,difflib

root=Path('/workspace/chicago/chicago/4d')
out=Path(__file__).parent
proposed=out/'proposed/chicago/4d'
pre=out/'preimages/chicago/4d'
old=(root/'tools/human_teamster_blend.py').read_text();new=old
anchor='                                 STANCE_FRACTION)\n'
assert new.count(anchor)==1
new=new.replace(anchor,anchor+'from human_workwear_fit import garment_shell, fitted_shoes\nfrom human_eye_components import build_eye_components, iris_pixels, MATERIALS as EYE_MATERIALS\n')
anchor="    colors['garment_upper__shirt_collar'] = colors['garment_upper__shirt_linen']\n"
assert new.count(anchor)==1
new=new.replace(anchor,anchor+"    colors.pop('eyes',None)\n    colors.update({name:spec['base_color'] for name,spec in EYE_MATERIALS.items() if name!='eyes__cornea'})\n")
anchor='        materials[name] = material\n'
assert new.count(anchor)==1
new=new.replace(anchor,"""        if name in EYE_MATERIALS:bsdf.inputs['Roughness'].default_value=EYE_MATERIALS[name]['roughness']
        materials[name] = material
    # Original opaque sclera/iris/pupil; no transparent shell/new extension.
    # Dimensions and brown color are reconstruction, not resident facts.
    iris=bpy.data.images.new('original_reconstructed_iris',width=512,height=256,alpha=False)
    iris.colorspace_settings.name='sRGB';iris.pixels=iris_pixels();iris.file_format='PNG';iris.pack()
    iris_nodes=materials['eyes__iris'].node_tree.nodes
    iris_tex=iris_nodes.new('ShaderNodeTexImage');iris_tex.image=iris
    materials['eyes__iris'].node_tree.links.new(iris_tex.outputs['Color'],iris_nodes['Principled BSDF'].inputs['Base Color'])
""")
start=new.index('            warp=(xx%8)/7;weft=(yy%8)/7')
end=new.index('            pixels.extend(',start)
new=new[:start]+"""            # The old eight-texel ridges read as giant blocks on body UVs.
            # This original one-texel alternation has only one percent contrast.
            shade=.99+.01*((xx+yy)%2)
"""+new[end:]
anchor='ratio=1,source_vertex_indices=None):'
assert new.count(anchor)==1
new=new.replace(anchor,'ratio=1,source_vertex_indices=None,corner_uvs=None):')
anchor='                layer.data[li].uv = uvs[mesh.loops[li].vertex_index]'
assert new.count(anchor)==1
new=new.replace(anchor,"                layer.data[li].uv = corner_uvs[polygon.index][list(polygon.loop_indices).index(li)] if corner_uvs is not None else uvs[mesh.loops[li].vertex_index]")
start=new.index('    def region(m, face, kind):');end=new.index('    def morphs(obj):',start)
new=new[:start]+"""    def shell(m,kind,offset):
        return garment_shell(m,kind,offset,recipe,bones,height,scale)
"""+new[end:]
anchor="""                points,faces,uvs,weights=shell(m,kind,offset)
                if not faces:raise ValueError(f'{kind}: no faces selected from body; input proportions need review')
                object_mesh(f'{asset}_{kind}_{mi}_lod{lod}',points,faces,uvs,weights,mat,col,ratio)
"""
assert new.count(anchor)==1
new=new.replace(anchor,"""                garment=shell(m,kind,offset)
                object_mesh(f'{asset}_{kind}_{mi}_lod{lod}',garment['positions_m'],garment['triangles'],garment['uvs'],garment['weights'],mat,col,ratio,corner_uvs=garment['corner_uvs'])
                if lod==0:print(json.dumps({'source_workwear_coverage':garment['receipt']}),flush=True)
""")
start=new.index('        # Originally authored closed shoes:');end=new.index('        # Original standing collar,',start)
new=new[:start]+"""        # Actual source foot sections bound this reconstructed closed shoe.
        # No body skin is hidden. All sole points survive at every LOD; the
        # existing loaded stance/foot/sole contact gates remain unchanged.
        shoes=fitted_shoes(body,bones,lod,scale,recipe['workwear_coverage']['shoe_clearance_m'])
        object_mesh(f'{asset}_closed_shoes_lod{lod}',shoes['positions_m'],shoes['triangles'],shoes['uvs'],shoes['weights'],'footwear__closed_leather_shoes',col)
        if lod==0:print(json.dumps({'source_shoe_enclosure':shoes['receipt']}),flush=True)
"""+new[end:]
start=new.index('        # Independent originally-authored corneas;');end=new.index("    for name,bone in contract['sockets']['required']:",start)
new=new[:start]+"""        eye_data=build_eye_components(bones,lod,recipe['eye_components'])
        for component in eye_data['meshes']:
            object_mesh(f"{asset}_{component['name']}_lod{lod}",component['positions_m'],component['triangles'],component['uvs'],component['weights'],component['material'],col)
"""+new[end:]
compile(new,'proposed-human_teamster_blend.py','exec')
(pre/'tools/human_teamster_blend.py').write_text(old)
(proposed/'tools/human_teamster_blend.py').write_text(new)

eye=Path('/workspace/shared/eye-quality-draft/human_eye_components.py').read_text()
anchor=" config=config or {};N,L,C=LOD_SAMPLING[lod];R=config.get('radius_m',.012);"
assert eye.count(anchor)==1
eye=eye.replace(anchor," config=config or {};N,L,C=LOD_SAMPLING[lod];C=0;R=config.get('radius_m',.012);")
(proposed/'tools/human_eye_components.py').write_text(eye)
oldrecipe=(root/'data/humans/recipes/worker_1835.json').read_text()
v=json.loads(oldrecipe)
v['procedural_shirt_texture']['construction']='original one-texel alternating thread study, one percent albedo contrast, no baked light'
v['procedural_shirt_texture']['metric_uv_density']='Body source UVs retained; no measured historic textile density asserted.'
v['workwear_coverage']={
 'garment_seams':'Full-body source-shared offset normals; welded geometry and source per-corner UVs',
 'vest_front':'Source-triangle clipped V, replacing centroid-stepped whole-face exclusion',
 'trouser_ease':'Retain7mm source-shared normal ease; no globalX translation that cancels inner-leg clearance',
 'shirt_neckline':'Triangles clipped to existing collar-baseY; UVs/weights interpolated, boundary shares geometry; no headweight whole-face staircut',
 'new_collar_seam_weights':'Only newly clipped shirt seam transfers head/jaw influence to existing neck_01; original body and below-cut shirt weights unchanged; actual transferred mass is reported',
 'shoe_clearance_m':.004,
 'shoe_construction':'Fixed-normal support-plane loft containing complete adjacent source foot slabs; no body visibility mask',
 'skin_influence_interpolation':'New vest cuts retain four largest interpolated weights; discard <=0.025, report actual mass; body skin unchanged',
 'status':'Source construction only; actual exported fit/deformation/sole/photo acceptance pending'}
v['eye_components']={
 'radius_m':.012,'iris_radius_m':.0055,'pupil_radius_m':.0022,
 'corneal_bulge_m':0,'cornea_enabled':False,
 'source_basis':'Actual helper centers/axes; original opaque sclera/iris/pupil, reconstructed dimensions and brown color, not resident facts',
 'status':'No actual BPy/export/blink fit/photographic acceptance'}
v['validation_status']='Proposed source-owned seam/vest/footwear/eye repair; fresh canonical/export/sole/render validation required. Not scene eligible solely by source controls.'
(pre/'data/humans/recipes/worker_1835.json').write_text(oldrecipe)
(proposed/'data/humans/recipes/worker_1835.json').write_text(json.dumps(v,indent=2)+'\n')
patch=''
for p in sorted((out/'proposed').rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(out/'proposed');before=out/'preimages'/rel
    patch+=''.join(difflib.unified_diff(before.read_text().splitlines(True) if before.exists() else [],p.read_text().splitlines(True),fromfile='a/'+str(rel) if before.exists() else '/dev/null',tofile='b/'+str(rel)))
(out/'WORKWEAR-VISIBLE-REPAIR.patch').write_text(patch)
print('Prepared four-file source patch; no app writes. Patch bytes',len(patch))
