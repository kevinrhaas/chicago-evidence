# SPDX-License-Identifier: GPL-3.0-or-later
"""Original reconstructed workwear geometry, evaluated without Blender.

Generated graphical arrays are CC0-1.0, as are their cleared body inputs. The
clothes are not an attested outfit or a photographic human. This helper keeps
the body/rig unchanged, shares offsets across source UV seams, cuts the vest V
on actual triangles, and constructs a shoe around actual source foot sections.
"""
from __future__ import annotations
import math
from human_source_normals import source_shared_normals


def _unit(v):
    d=math.hypot(*v)
    if not math.isfinite(d) or d<=1e-20:raise ValueError('zero or nonfinite normal')
    return [x/d for x in v]


def _mix(a,b,t):return [math.fsum((x*(1-t),y*t)) for x,y in zip(a,b)]


def _clip(poly,field):
    """Retain field>=0 and interpolate source barycentrics, UVs and weights."""
    if not poly:return []
    out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        da,db=field(a),field(b)
        if da>=0:out.append(a)
        if (da<0<db) or (db<0<da):
            # A consistent endpoint order also makes a shared source edge's
            # cut identical when its neighboring face traverses it backwards.
            if tuple(sorted(a['basis'].items()))>tuple(sorted(b['basis'].items())):a,b,da,db=b,a,db,da
            t=da/(da-db)
            basis={i:math.fsum((a['basis'].get(i,0)*(1-t),b['basis'].get(i,0)*t)) for i in sorted(set(a['basis'])|set(b['basis']))}
            out.append({'p':_mix(a['p'],b['p'],t),'uv':_mix(a['uv'],b['uv'],t),
                        'n':_mix(a['n'],b['n'],t),'basis':basis,
                        'w':{i:math.fsum((a['w'].get(i,0)*(1-t),b['w'].get(i,0)*t)) for i in sorted(set(a['w'])|set(b['w']))}})
    clean=[]
    for v in out:
        if not clean or math.dist(v['p'],clean[-1]['p'])>1e-14:clean.append(v)
    if len(clean)>1 and math.dist(clean[0]['p'],clean[-1]['p'])<=1e-14:clean.pop()
    return clean


def garment_shell(m,kind,offset,recipe,bones,height,scale=1.):
    """A source-derived shell with coincident UV seams and clipped vest edges.

    Original source UVs and exact weights survive on original vertices. New vest
    cut vertices interpolate them on their source triangle. At most four skin
    influences are emitted; actual discarded mass must stay below 2.5 percent.
    This is a disclosed garment interpolation choice, not a change to body skin.
    """
    if kind not in ('shirt','waistcoat','trousers') or not 0<scale or not 0<offset<.05:
        raise ValueError('invalid garment kind/scale/ease')
    ps=m['positions_m'];fs=m['triangles'];sids=m['source_vertex_indices']
    ns=source_shared_normals(ps,fs,sids)
    waist=recipe['waist_height_fraction']*height/scale
    hem=recipe['shirt_hem_fraction']*height/scale
    shoulder=bones['upperarm_l']['head_m'][1]
    wrist=abs(bones['hand_l']['head_m'][0]);neck=bones['neck_01']['head_m'][1]
    slope=.105/max(.01,shoulder-waist)
    result={'positions_m':[],'triangles':[],'uvs':[],'weights':[],'source_basis':[],'corner_uvs':[],'source_triangle_indices':[]}
    cache={};selected=[];maximum_drop=0.;maximum_neck_transfer=0.;discarded_zero=0
    for fi,face in enumerate(fs):
        p=[math.fsum(ps[i][a] for i in face)/3 for a in range(3)]
        w={}
        for i in face:
            for b,v in m['weights'][i].items():w[b]=w.get(b,0)+v/3
        arm=sum(v for b,v in w.items() if b.startswith(('clavicle','upperarm','lowerarm')))
        leg=sum(v for b,v in w.items() if b.startswith(('thigh','calf','pelvis')))
        foot=sum(v for b,v in w.items() if b.startswith(('foot','ball')))
        keep=((hem<=p[1]<=neck+.035 and abs(p[0])<.23) or (arm>.35 and abs(p[0])<wrist-.012)) if kind=='shirt' else (
             waist-.04<=p[1]<=shoulder+.025 and arm<.35 and abs(p[0])<.235) if kind=='waistcoat' else (
             p[1]<=waist and leg>.25 and foot<.35)
        if not keep:continue
        selected.append(fi)
        poly=[{'p':ps[i],'uv':m['uvs'][i],'w':m['weights'][i],'n':ns[i],'basis':{sids[i]:1.}} for i in face]
        # End the shirt on the actual existing collar's base plane. This
        # clips triangles and interpolates UVs/weights, instead of selecting
        # jagged whole faces by head weight. Neck/skin anatomy stays exact.
        polys=[_clip(poly,lambda v:neck-v['p'][1])] if kind=='shirt' else [poly]
        if kind=='waistcoat':
            # A union of three disjoint source regions. Their shared z=0
            # boundary is a seam, and the two front boundaries are straight Vs.
            back=_clip(poly,lambda v:-v['p'][2])
            front=_clip(poly,lambda v:v['p'][2])
            left=_clip(_clip(front,lambda v:v['p'][0]-.012),lambda v:v['p'][0]-slope*(v['p'][1]-waist))
            right=_clip(_clip(front,lambda v:-v['p'][0]-.012),lambda v:-v['p'][0]-slope*(v['p'][1]-waist))
            polys=[back,left,right]
        for polygon in polys:
            ids=[]
            for vertex in polygon:
                n=_unit(vertex['n']);p=[vertex['p'][a]+n[a]*offset/scale for a in range(3)]
                # A global outwardX shift cancels normal ease on the INNER
                # leg. Trousers keep their full positive normal offset only.
                if kind!='trousers' and abs(p[0])>.02:p[0]+=math.copysign(.007/scale,p[0])
                if kind=='shirt':
                    # Cut-edge normals can have a small vertical component.
                    # The garment seam itself stays on its declared collar
                    # plane instead of sagging into a near-planar stair edge.
                    p[1]=neck if abs(vertex['p'][1]-neck)<=1e-12 else min(p[1],neck)
                mapping=dict(vertex['w'])
                if kind=='shirt' and abs(vertex['p'][1]-neck)<=1e-12:
                    # The newly cut collar seam belongs to the neck garment,
                    # not the moving jaw/face. Rebind only this new seam, never
                    # the body or existing shirt vertices below the cut.
                    transfer=math.fsum(mapping.pop(k,0.) for k in ('head','jaw'))
                    mapping['neck_01']=mapping.get('neck_01',0.)+transfer
                    maximum_neck_transfer=max(maximum_neck_transfer,transfer)
                weights=sorted(((k,v) for k,v in mapping.items() if v>1e-12),key=lambda kv:(-kv[1],kv[0]))
                dropped=math.fsum(v for k,v in weights[4:]);maximum_drop=max(maximum_drop,dropped)
                if dropped>.025:raise ValueError('garment cut exceeds 2.5 percent discarded skin mass: '+repr((fi,dropped,weights)))
                weights=weights[:4];total=math.fsum(v for k,v in weights)
                if total<=0:raise ValueError('empty garment skin weights')
                weights={k:v/total for k,v in weights}
                basis={k:v for k,v in vertex['basis'].items() if v>1e-12}
                # Geometry is shared across an original body's UV seam. UVs
                # live on corners, so the decimator cannot pull two coincident
                # seam vertices apart and reopen the garment at a lower LOD.
                key=(tuple(p),tuple(sorted(weights.items())))
                if key not in cache:
                    cache[key]=len(result['positions_m']);result['positions_m'].append(p)
                    result['uvs'].append(list(vertex['uv']));result['weights'].append(weights);result['source_basis'].append(basis)
                ids.append(cache[key])
            for k in range(1,len(ids)-1):
                tri=[ids[0],ids[k],ids[k+1]]
                a,b,c=[result['positions_m'][i] for i in tri]
                u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)]
                cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
                if len(set(tri))<3 or math.hypot(*cross)<=1e-18:discarded_zero+=1;continue
                result['triangles'].append(tri)
                result['source_triangle_indices'].append(fi)
                result['corner_uvs'].append([polygon[j]['uv'] for j in (0,k,k+1)])
    if not result['triangles']:raise ValueError('empty garment shell')
    result['receipt']={'kind':kind,'source_selected_faces':selected,'source_uv_seams':'Full-body source-shared normals, not isolated UV chart normals',
        'neckline_clip_y_m':neck if kind=='shirt' else None,
        'maximum_new_collar_seam_head_jaw_mass_rebound_to_neck':maximum_neck_transfer,
        'additional_global_x_ease_m':0. if kind=='trousers' else .007,
        'body_mutated':False,'maximum_discarded_cut_weight':maximum_drop,'degenerate_cut_fans_discarded':discarded_zero,
        'fit_accepted':False,'scope':'Original source construction; actual deformation and rendered clothing still need review'}
    return result


def _slab_points(triangles,lo,hi):
    result=[]
    for tri in triangles:
        poly=[{'p':p,'uv':[],'n':[],'w':{},'basis':{i:1.}} for i,p in enumerate(tri)]
        poly=_clip(_clip(poly,lambda v:v['p'][1]-lo),lambda v:hi-v['p'][1])
        result.extend(v['p'] for v in poly)
    return result


def fitted_shoes(body,bones,lod,scale=1.,clearance_m=.004):
    """Closed soles and support-plane lofts enclosing the actual source feet.

    Each ring's support polygon contains both adjacent complete body slabs.
    The fixed-normal support values interpolate linearly between rings, so every
    clipped source triangle is inside the actual planar loft at rest. An open
    ankle at145mm is deliberate; trousers overlap it. No body is hidden.
    """
    if lod not in range(4) or scale<=0 or not .002<=clearance_m<=.01:raise ValueError('invalid shoe parameters')
    N=[32,24,16,12][lod]
    levels=[v/scale for v in (0,.016,.035,.060,.085,.115,.145)]
    clearance=clearance_m/scale
    planes=[(math.cos(2*math.pi*k/N),math.sin(2*math.pi*k/N)) for k in range(N)]
    out={'positions_m':[],'triangles':[],'uvs':[],'weights':[]};reports=[]
    for side,cell in [('l',0),('r',1)]:
        sign=1 if side=='l' else -1
        triangles=[]
        for mesh in body['meshes']:
            for face in mesh['triangles']:
                ps=[mesh['positions_m'][i] for i in face]
                if min(p[1] for p in ps)>levels[-1] or max(p[1] for p in ps)<0:continue
                if math.fsum(p[0] for p in ps)*sign<=0:continue
                # Preserve exact named-limb ownership instead of assuming the
                # sign of a stray source vertex establishes a foot identity.
                chain={j+'_'+side for j in ('thigh','calf','foot','ball')}
                if min(math.fsum(v for k,v in mesh['weights'][i].items() if k in chain) for i in face)<.9:
                    raise ValueError('body triangle in shoe band has ambiguous leg ownership')
                triangles.append(ps)
        if not triangles:raise ValueError('no source foot triangles')
        supports=[]
        for i,y in enumerate(levels):
            points=_slab_points(triangles,levels[max(0,i-1)],levels[min(len(levels)-1,i+1)])
            if len(points)<3:raise ValueError('empty source foot section')
            supports.append([max(nx*p[0]+nz*p[2] for p in points)+clearance for nx,nz in planes])
        minimum=math.inf;sample_count=0
        for i,(lo,hi) in enumerate(zip(levels,levels[1:])):
            for p in _slab_points(triangles,lo,hi):
                t=(p[1]-lo)/(hi-lo)
                for k,(nx,nz) in enumerate(planes):
                    margin=(1-t)*supports[i][k]+t*supports[i+1][k]-nx*p[0]-nz*p[2]
                    minimum=min(minimum,margin);sample_count+=1
        if minimum<clearance-1e-12:raise ValueError('source foot escapes support-plane loft')
        base=len(out['positions_m']);det=math.sin(2*math.pi/N)
        for j,y in enumerate(levels):
            for k,(nx,nz) in enumerate(planes):
                next_k=(k+1)%N;mx,mz=planes[next_k];h,q=supports[j][k],supports[j][next_k]
                x=(h*mz-nz*q)/det;z=(nx*q-h*mx)/det
                out['positions_m'].append([x,y,z]);out['uvs'].append([(cell+.05+.9*k/N)/2,.05+.9*j/(len(levels)-1)])
                blend=max(0.,min(1.,(z-bones['ball_'+side]['head_m'][2]+.04/scale)/(.08/scale)))
                out['weights'].append({'foot_'+side:1-blend,'ball_'+side:blend})
        for j in range(len(levels)-1):
            for k in range(N):
                a=base+j*N+k;b=base+j*N+(k+1)%N;c=b+N;d=a+N
                out['triangles'].extend([[a,c,b],[a,d,c]])
        center=len(out['positions_m']);p=[math.fsum(out['positions_m'][base+k][a] for k in range(N))/N for a in range(3)]
        out['positions_m'].append(p);out['uvs'].append([(cell+.5)/2,.025]);out['weights'].append({'foot_'+side:1.})
        for k in range(N):out['triangles'].append([center,base+k,base+(k+1)%N])
        reports.append({'side':side,'source_triangles_in_band':len(triangles),'support_inequality_checks':sample_count,
            'minimum_source_support_clearance_m':minimum*scale,'ankle_height_m':levels[-1]*scale,'plane_count':N,
            'body_hidden':False,'proof_scope':'Exact source triangle slab vertices satisfy every linear loft support plane; source Float64 only, actual exported/readback deformation and contact remain untested'})
    out['receipt']={'sides':reports,'clearance_m':clearance_m,'ring_heights_m':[v*scale for v in levels],
        'parameters_status':'Reconstructed footwear last/ease, not an attested shoe or material measurement',
        'export_or_walk_contact_accepted':False}
    return out
