"""Finite real-source controls; no Blender/GPU, no app write."""
from pathlib import Path
import ast,hashlib,json,math,subprocess,sys,time,collections

OUT=Path(__file__).parent;ROOT=Path('/workspace/chicago/chicago/4d')
sys.path[:0]=[str(OUT/'proposed/chicago/4d/tools'),str(ROOT/'tools')]
from human_workwear_fit import garment_shell,fitted_shoes,_slab_points
from human_eye_components import build_eye_components,iris_pixels
from human_source_normals import source_shared_normals

def need(x,msg):
    if not x:raise AssertionError(msg)

start=time.monotonic();runs=[]
recipe=json.loads((OUT/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text())
for age in (25,35):
    path=ROOT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json'
    raw=path.read_bytes();body=json.loads(raw);bones={b['name']:b for b in body['skeleton']}
    h=max(p[1] for m in body['meshes'] for p in m['positions_m'])
    for kind,off in [('shirt',.006),('waistcoat',.014),('trousers',.007)]:
        result=[]
        for mesh in body['meshes']:
            g=garment_shell(mesh,kind,off,recipe,bones,h)
            need(len(g['corner_uvs'])==len(g['triangles']),'per-corner UV count')
            need(all(len(c)==3 and all(len(uv)==2 and all(math.isfinite(v) for v in uv) for uv in c) for c in g['corner_uvs']),'UV corners finite')
            need(all(abs(sum(w.values())-1)<1e-12 and 1<=len(w)<=4 for w in g['weights']),'normalized portable garment weights')
            # Every original shared graphical vertex emits one position, even
            # where the body has several different per-corner UV samples.
            source_positions={}
            for p,basis in zip(g['positions_m'],g['source_basis']):
                if len(basis)==1 and next(iter(basis.values()))==1.:
                    source_positions.setdefault(next(iter(basis)),set()).add(tuple(p))
            need(all(len(ps)==1 for ps in source_positions.values()),'source UV seams must not separate')
            need(g['receipt']['maximum_discarded_cut_weight']<=.025,'four influence cut bound')
            need(hashlib.sha256(path.read_bytes()).digest()==hashlib.sha256(raw).digest(),'body immutable')
            # Mesh edges are geometric, UV boundaries remain corner attributes.
            uv_seams=0
            corner_samples={}
            for face,uvs in zip(g['triangles'],g['corner_uvs']):
                for i,uv in zip(face,uvs):corner_samples.setdefault(i,set()).add(tuple(uv))
            uv_seams=sum(len(v)>1 for v in corner_samples.values())
            extra={}
            # Check the emitted corner samples against their actual original
            # body triangle UVs, including a welded seam's distinct chart UVs.
            need(len(g['source_triangle_indices'])==len(g['triangles']),'source triangle ownership per emitted face')
            for face,uvs,source_fi in zip(g['triangles'],g['corner_uvs'],g['source_triangle_indices']):
                source_face=mesh['triangles'][source_fi]
                source_uv={mesh['source_vertex_indices'][i]:mesh['uvs'][i] for i in source_face}
                for i,uv in zip(face,uvs):
                    basis=g['source_basis'][i]
                    need(set(basis)<=set(source_uv),'cut has exact source face ownership')
                    expected=[math.fsum(coef*source_uv[sid][a] for sid,coef in basis.items()) for a in range(2)]
                    need(math.dist(expected,uv)<1e-12,'emitted corner retains source UV interpolation')
            if kind=='trousers':
                ns=source_shared_normals(mesh['positions_m'],mesh['triangles'],mesh['source_vertex_indices'])
                originals={sid:(p,n) for sid,p,n in zip(mesh['source_vertex_indices'],mesh['positions_m'],ns)}
                clearances=[]
                for q,basis in zip(g['positions_m'],g['source_basis']):
                    need(len(basis)==1 and next(iter(basis.values()))==1,'trouser original source vertex retained')
                    original,n=originals[next(iter(basis))]
                    clearances.append(math.fsum((q[a]-original[a])*n[a] for a in range(3)))
                need(min(clearances)>=.007-1e-12,'every trouser source vertex retains7mm actual normal separation')
                extra['minimum_actual_source_normal_separation_m']=min(clearances)
                if age==25:
                    previous=json.loads(Path('/workspace/shared/human-workwear-visible-repair/trousers-adult25.json').read_text())[0]
                    old=[]
                    for q,basis in zip(previous['positions_m'],previous['source_basis']):
                        original,n=originals[int(next(iter(basis)))];old.append(math.fsum((q[a]-original[a])*n[a] for a in range(3)))
                    need(sum(v<.001 for v in old)==131,'old131 low-clearance vertices reproduced')
                    need(min(old)<.000001,'old globalX cancellation negative witness')
                    extra['old_negative_vertices_below_1mm']=sum(v<.001 for v in old)
                    extra['old_minimum_source_normal_separation_m']=min(old)
            if kind=='shirt':
                plane=g['receipt']['neckline_clip_y_m'];edges=collections.Counter()
                for face in g['triangles']:
                    for a,b in zip(face,face[1:]+face[:1]):edges[tuple(sorted((a,b)))]+=1
                need(max(edges.values())<=2,'shirt remains manifold at the clipped neckline')
                boundary=[e for e,c in edges.items() if c==1 and all(abs(g['positions_m'][i][1]-plane)<1e-12 for i in e)]
                need(len(boundary)>12,'actual collar-plane boundary exists')
                graph=collections.defaultdict(set)
                for a,b in boundary:graph[a].add(b);graph[b].add(a)
                need(all(len(v)==2 for v in graph.values()),'collar plane boundary has no open endpoint or branch')
                todo=[next(iter(graph))];seen=set(todo)
                while todo:
                    for other in graph[todo.pop()]:
                        if other not in seen:seen.add(other);todo.append(other)
                need(len(seen)==len(graph),'one continuous collar-base loop')
                need(max(p[1] for p in g['positions_m'])<=plane+1e-12,'shirt never crosses its declared collar plane')
                need(all(not({'head','jaw'}&set(g['weights'][i])) for i in graph),'new shirt seam is neck garment, not facial binding')
                extra.update({'neckline_plane_m':plane,'neckline_boundary_edges':len(boundary),'neckline_cycles':1,
                    'maximum_new_collar_head_jaw_mass_rebound_to_neck':g['receipt']['maximum_new_collar_seam_head_jaw_mass_rebound_to_neck']})
            result.append({'vertices':len(g['positions_m']),'triangles':len(g['triangles']),**extra,
                'welded_vertices_with_distinct_corner_uvs':uv_seams,'maximum_cut_weight_discarded':g['receipt']['maximum_discarded_cut_weight']})
            if age==25:(OUT/f'{kind}-adult25.json').write_text(json.dumps([g],separators=(',',':')))
        runs.append({'age':age,'kind':kind,'meshes':result})
    for lod in range(4):
        shoe=fitted_shoes(body,bones,lod)
        need(min(p[1] for p in shoe['positions_m'])==0,'actual sole plane unchanged')
        sole=[(p,w) for p,w in zip(shoe['positions_m'],shoe['weights']) if p[1]==0]
        for side,sign in [('l',1),('r',-1)]:
            part=[(p,w) for p,w in sole if p[0]*sign>0]
            need(len(part)>=3,'fixed flat sole survives all LODs')
            need(all(abs(sum(v for b,v in w.items() if b in ('foot_'+side,'ball_'+side))-1)<1e-12 for p,w in part),'sole foot binding')
        need(all(s['minimum_source_support_clearance_m']>=.004-1e-12 for s in shoe['receipt']['sides']),'complete source foot enclosure')
        if age==25:(OUT/f'shoes-adult25-lod{lod}.json').write_text(json.dumps(shoe,separators=(',',':')))
        eye=build_eye_components(bones,lod,recipe['eye_components'])
        need({m['material'] for m in eye['meshes']}=={'eyes__sclera','eyes__iris','eyes__pupil'},'opaque eye materials only')
        need(all(len(w)==1 and next(iter(w)).startswith('eye_') and next(iter(w.values()))==1 for m in eye['meshes'] for w in m['weights']),'existing eye-joint binding')
        if age==25:(OUT/f'eyes-adult25-lod{lod}.json').write_text(json.dumps(eye,separators=(',',':')))
        runs.append({'age':age,'lod':lod,'shoes':{'vertices':len(shoe['positions_m']),'triangles':len(shoe['triangles']),**shoe['receipt']},'eye_triangles':eye['triangles']})
    print('actual source age',age,'PASS',flush=True)

# Reject malformed source ownership/physical construction before a BPy build.
for label,fn in [
 ('invalid footwear clearance',lambda:fitted_shoes(body,bones,0,clearance_m=.0001)),
 ('invalid eye geometry',lambda:build_eye_components(bones,0,{'radius_m':.001,'iris_radius_m':.0055})),
 ('unknown garment role',lambda:garment_shell(body['meshes'][0],'invented',.006,recipe,bones,h)),
 ('empty foot source',lambda:fitted_shoes({'meshes':[]},bones,0)),
]:
    try:fn()
    except (ValueError,KeyError):pass
    else:raise AssertionError('negative control passed: '+label)

before=(OUT/'preimages/chicago/4d/tools/human_teamster_blend.py').read_text()
after=(OUT/'proposed/chicago/4d/tools/human_teamster_blend.py').read_text()
old=ast.parse(before);new=ast.parse(after)
functions=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.FunctionDef)}
of,nf=functions(old),functions(new)
need({k:v for k,v in of.items() if k!='build'}=={k:v for k,v in nf.items() if k!='build'},'CLI/identity/skin source validators unchanged')
o=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name=='build')
n=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name=='build')
of={f.name:f for f in o.body if isinstance(f,ast.FunctionDef)};nf={f.name:f for f in n.body if isinstance(f,ast.FunctionDef)}
need(ast.dump(of['morphs'],include_attributes=False)==ast.dump(nf['morphs'],include_attributes=False),'body morph function unchanged')
branch=lambda f:next(x for x in f.body if isinstance(x,ast.If) and isinstance(x.test,ast.Compare) and 'source_vertex_indices' in ast.unparse(x.test))
need(ast.dump(branch(of['object_mesh']),include_attributes=False)==ast.dump(branch(nf['object_mesh']),include_attributes=False),'entire original raw-normal/probe gate unchanged')
anchor="    for name,bone in contract['sockets']['required']:\n"
need(before[before.index(anchor):]==after[after.index(anchor):],'sockets/idle/walk/seated/identity provenance tail unchanged')
for f in (OUT/'proposed').rglob('*.py'):compile(f.read_text(),str(f),'exec')
check=subprocess.run(['git','apply','--check',str(OUT/'WORKWEAR-VISIBLE-REPAIR.patch')],cwd=ROOT.parents[1],capture_output=True,text=True)
need(check.returncode==0,'patch applicability: '+check.stderr)

# A concrete image for the same original pixels the proposed BPy builder packs.
from PIL import Image
pixels=iris_pixels();image=Image.new('RGB',(512,256));image.putdata([tuple(round(max(0,min(1,pixels[i+a]))*255) for a in range(3)) for i in range(0,len(pixels),4)])
image.save(OUT/'iris-original-preview.png')
report={'PASS':True,'scope':'Actual original source arrays, source ownership/UV/foot enclosure, opaque eyes and unchanged core AST only. No Blender/export/sole/GPU/photographic acceptance.',
 'actual_source_runs':runs,'negative_controls':4,'unchanged_guards':['CLI/identity/skin validators','body morphs','complete raw0.001 normal/probe audit','sockets/idle/walk/seated/identity provenance'],
 'elapsed_s':time.monotonic()-start}
(OUT/'SOURCE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n')
print('SOURCE CONTROLS PASS',report['elapsed_s'],flush=True)
