"""Independent inert-data/source audit; no Blender, browser, app or candidate writes."""
from pathlib import Path
import ast, collections, hashlib, importlib.util, json, math, struct, sys
import numpy as np

sys.dont_write_bytecode=True
ROOT=Path('/workspace/chicago/chicago/4d')
V1=Path('/workspace/shared/human-workwear-visible-repair')
V2=Path('/workspace/shared/human-workwear-visible-repair-v2')
OUT=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,label):
    if not v:raise AssertionError(label)
frozen=V2/'FROZEN-SOURCE-REVIEW.json'
need(sha(frozen)=='5d4e68462a18035a5df05c2e5501b13cc354f6960e40a281dc2852dc99ec8fab','frozen pin')
pins=json.loads(frozen.read_text())
for name,spec in pins['files'].items():
    need(sha(V2/name)==spec['sha256'] and (V2/name).stat().st_size==spec['bytes'],'frozen file '+name)

report={'scope':'Independent source/math/topology and CPU LBS diagnostic only; no model files, Blender, browser, export, cloth/body collision or photographic acceptance',
        'frozen_sha256':sha(frozen),'patch_sha256':sha(V2/'WORKWEAR-VISIBLE-REPAIR.patch'),'source_audits':[]}
tool='proposed/chicago/4d/tools/'
for name in ['human_teamster_blend.py','human_eye_components.py']:
    need((V1/(tool+name)).read_bytes()==(V2/(tool+name)).read_bytes(),'v1 immutable builder/eyes '+name)
oldrecipe=json.loads((V1/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text())
recipe=json.loads((V2/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text())
recipe_copy=json.loads(json.dumps(recipe))
for k in ['trouser_ease','shirt_neckline','new_collar_seam_weights']:del recipe_copy['workwear_coverage'][k]
need(recipe_copy==oldrecipe,'only three descriptive recipe additions')
oldast=ast.parse((V1/(tool+'human_workwear_fit.py')).read_text());newast=ast.parse((V2/(tool+'human_workwear_fit.py')).read_text())
funcs=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,ast.FunctionDef)}
of,nf=funcs(oldast),funcs(newast)
need({k:v for k,v in of.items() if k!='garment_shell'}=={k:v for k,v in nf.items() if k!='garment_shell'},'all non-garment helpers AST exact')
need('if dropped>.025:raise ValueError' in (V2/(tool+'human_workwear_fit.py')).read_text(),'2.5 percent refusal retained')
report['immutable_guards']=['v1/v2 full teamster builder byte-identical: body/rig/identity/raw0.001 normal branch/sockets/idle/walk/seated unchanged',
    'eye helper byte-identical','all non-garment-shell fit helper ASTs unchanged including shoes and clipping','only three descriptive recipe additions','2.5 percent discarded-weight guard retained']

# The frozen source helper is project-authored, reviewed plain Python. Import
# only the pure geometry helper for adult35 arrays; never import the BPy builder.
sys.path.insert(0,str(ROOT/'tools'))
spec=importlib.util.spec_from_file_location('reviewed_v2_fit',V2/(tool+'human_workwear_fit.py'))
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
for age in [25,35]:
    bp=ROOT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json'
    before=bp.read_bytes();body=json.loads(before);immutable=json.dumps(body,sort_keys=True)
    bones={b['name']:b for b in body['skeleton']};height=max(p[1] for m in body['meshes'] for p in m['positions_m'])
    need(len(body['meshes'])==1,'one prepared body mesh')
    source=body['meshes'][0];P=np.array(source['positions_m']);F=np.array(source['triangles']);S=np.array(source['source_vertex_indices'])
    # Independent area-weighted full-body normals summed by explicit source ID.
    cross=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]])
    sums=np.zeros((int(S.max())+1,3))
    for col in range(3):np.add.at(sums,S[F[:,col]],cross)
    norms=sums/np.where(np.linalg.norm(sums,axis=1,keepdims=True)>0,np.linalg.norm(sums,axis=1,keepdims=True),1)
    sid_index={int(sid):i for i,sid in enumerate(S)}
    record={'age':age}
    pants=helper.garment_shell(source,'trousers',.007,recipe,bones,height)
    shirt=helper.garment_shell(source,'shirt',.006,recipe,bones,height)
    if age==25:
        need(json.loads(json.dumps(pants))==json.loads((V2/'trousers-adult25.json').read_text())[0],'saved pants exact pure-source reconstruction')
        need(json.loads(json.dumps(shirt))==json.loads((V2/'shirt-adult25.json').read_text())[0],'saved shirt exact pure-source reconstruction')
        body25,shirt25,source25=body,shirt,source
    sep=[];deltan=[];current={}
    for q,b in zip(pants['positions_m'],pants['source_basis']):
        need(len(b)==1 and next(iter(b.values()))==1.,'pants preserve source vertices')
        sid=int(next(iter(b)));v=P[sid_index[sid]];normal=norms[sid];d=np.array(q)-v
        sep.append(float(d@normal));deltan.append(float(np.linalg.norm(d-.007*normal)));current[sid]=float(d@normal)
    need(min(sep)>=.007-1e-12 and max(deltan)<1e-12,'every retained pants vertex true 7mm normal ease')
    record['pants']={'vertices':len(sep),'normal_separation_min_m':min(sep),'normal_separation_max_m':max(sep),'max_vector_error_vs_7mm_n_m':max(deltan)}
    if age==25:
        old=json.loads((V1/'trousers-adult25.json').read_text())[0];bad=[];oldsep=[]
        for q,b in zip(old['positions_m'],old['source_basis']):
            sid=int(next(iter(b)));s=float((np.array(q)-P[sid_index[sid]])@norms[sid]);oldsep.append(s)
            if s<.001:bad.append(sid)
        need(len(bad)==131 and all(current[s]>=.007-1e-12 for s in bad),'all 131 old low-clearance vertices recovered')
        record['pants'].update(old_below_1mm=len(bad),old_min_m=min(oldsep),recovered_min_m=min(current[s] for s in bad))
    Q=np.array(shirt['positions_m']);plane=shirt['receipt']['neckline_clip_y_m'];edges=collections.Counter()
    for tri in shirt['triangles']:
        for a,b in zip(tri,tri[1:]+tri[:1]):edges[tuple(sorted((a,b)))]+=1
    need(max(edges.values())==2,'no nonmanifold shirt edges')
    boundary=[e for e,c in edges.items() if c==1 and all(abs(Q[i,1]-plane)<1e-12 for i in e)]
    graph=collections.defaultdict(set)
    for a,b in boundary:graph[a].add(b);graph[b].add(a)
    need(all(len(v)==2 for v in graph.values()),'neckline degree two')
    seen=set();todo=[next(iter(graph))]
    while todo:
        i=todo.pop()
        if i in seen:continue
        seen.add(i);todo.extend(graph[i]-seen)
    need(len(seen)==len(graph),'one closed neckline cycle')
    need(max(Q[:,1])<=plane+1e-12,'no shirt above collar base')
    uv_error=0.;weight_error=0.;changed=[];origweights=[];sourceskin=[]
    for i,basis in enumerate(shirt['source_basis']):
        src=np.zeros(3);w=collections.defaultdict(float)
        for sid,coef in basis.items():
            oi=sid_index[int(sid)];src+=coef*P[oi]
            for name,value in source['weights'][oi].items():w[name]+=coef*value
        sourceskin.append(src.tolist());origweights.append(dict(w));expected=dict(w)
        if abs(src[1]-plane)<=1e-12:
            transfer=sum(expected.pop(k,0.) for k in ['head','jaw']);expected['neck_01']=expected.get('neck_01',0.)+transfer
            if transfer>1e-12:changed.append(i)
        vals=sorted(((k,v) for k,v in expected.items() if v>1e-12),key=lambda kv:(-kv[1],kv[0]));need(sum(v for k,v in vals[4:])<=.025,'unchanged four-weight bound')
        expected=dict(vals[:4]);total=sum(expected.values());expected={k:v/total for k,v in expected.items()}
        actual=shirt['weights'][i]
        weight_error=max(weight_error,max(abs(actual.get(k,0)-expected.get(k,0)) for k in set(actual)|set(expected)))
        need(len(actual)<=4 and abs(sum(actual.values())-1)<1e-12,'shirt weights normalized <=4')
    for face,uvs,fi in zip(shirt['triangles'],shirt['corner_uvs'],shirt['source_triangle_indices']):
        corner_source={source['source_vertex_indices'][i]:source['uvs'][i] for i in source['triangles'][fi]}
        for i,uv in zip(face,uvs):
            basis=shirt['source_basis'][i];need(set(basis)<=set(corner_source),'exact original face corner ownership')
            uv_expected=np.sum([coef*np.array(corner_source[sid]) for sid,coef in basis.items()],axis=0)
            uv_error=max(uv_error,float(np.linalg.norm(np.array(uv)-uv_expected)))
    need(uv_error<1e-12 and weight_error<1e-12,'independent UV/skin interpolation')
    need(all(i in graph for i in changed),'head/jaw transfer only on actual new boundary')
    need(all(not({'head','jaw'}&set(shirt['weights'][i])) for i in graph),'no head/jaw on seam')
    need(len({tuple(p) for p in shirt['positions_m']})==len(Q),'no duplicate position vertices')
    record['shirt']={'vertices':len(Q),'triangles':len(shirt['triangles']),'neckline_edges':len(boundary),'neckline_cycles':1,'new_rebound_vertices':len(changed),
        'max_corner_uv_error':uv_error,'max_interpolated_skin_weight_error':weight_error,'maximum_head_jaw_transfer':shirt['receipt']['maximum_new_collar_seam_head_jaw_mass_rebound_to_neck']}
    need(json.dumps(body,sort_keys=True)==immutable and bp.read_bytes()==before,'body file and source arrays immutable')
    report['source_audits'].append(record)
    if age==25:original25,new25,skin25,neck25=origweights,shirt['weights'],sourceskin,sorted(graph)

# Inert GLB decoder: read accessors, compose transforms and sample existing clips.
glb=Path('/workspace/shared/human-visible-next/bardwell_otis_1835.lod0.glb');raw=glb.read_bytes();ln,typ=struct.unpack_from('<II',raw,12)
g=json.loads(raw[20:20+ln]);off=20+ln;blen,btyp=struct.unpack_from('<II',raw,off);binary=raw[off+8:off+8+blen]
def acc(idx):
    a=g['accessors'][idx];v=g['bufferViews'][a['bufferView']];dtype={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']]
    n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];dt=np.dtype(dtype);start=v.get('byteOffset',0)+a.get('byteOffset',0)
    arr=np.ndarray((a['count'],n),dtype=dt,buffer=binary,offset=start,strides=(v.get('byteStride',n*dt.itemsize),dt.itemsize)).astype(float)
    if a.get('normalized') and a['componentType']!=5126:arr/=np.iinfo(dt).max
    return arr[:,0] if n==1 else arr
nodes=g['nodes'];parents={c:i for i,n in enumerate(nodes) for c in n.get('children',[])}
def qmatrix(q):
    x,y,z,w=q/np.linalg.norm(q)
    return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],
        [2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
def slerp(a,b,t):
    d=float(a@b)
    if d<0:b=-b;d=-d
    if d>.9995:r=a+t*(b-a);return r/np.linalg.norm(r)
    angle=math.acos(max(-1,min(1,d)));return (math.sin((1-t)*angle)*a+math.sin(t*angle)*b)/math.sin(angle)
def worlds(overrides):
    result={}
    def world(i):
        if i in result:return result[i]
        n=nodes[i]
        if 'matrix' in n:local=np.array(n['matrix']).reshape(4,4,order='F')
        else:
            tr=np.array(overrides.get((i,'translation'),n.get('translation',[0,0,0])));rot=np.array(overrides.get((i,'rotation'),n.get('rotation',[0,0,0,1])));sc=np.array(overrides.get((i,'scale'),n.get('scale',[1,1,1])))
            local=np.eye(4);local[:3,:3]=qmatrix(rot)@np.diag(sc);local[:3,3]=tr
        result[i]=(world(parents[i])@local) if i in parents else local;return result[i]
    for i in range(len(nodes)):world(i)
    return result
skin=g['skins'][0];jointnames=[nodes[i]['name'] for i in skin['joints']];joint_index={n:i for i,n in enumerate(jointnames)}
ib=acc(skin['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1)
def matrices(overrides):
    w=worlds(overrides);return np.stack([w[i]@ib[k] for k,i in enumerate(skin['joints'])])
rest=matrices({});resterror=float(np.max(np.abs(rest-np.eye(4))))
need(resterror<3e-6,'prior glb skin matrices are identity within float32 transform noise at source rest')
def weights_array(weightlist):
    a=np.zeros((len(weightlist),len(jointnames)))
    for i,w in enumerate(weightlist):
        for n,v in w.items():a[i,joint_index[n]]=v
    return a
def deform(points,weights,mats):
    p=np.c_[points,np.ones(len(points))];transformed=np.einsum('jkl,il->ijk',mats,p)
    return np.einsum('ij,ijk->ik',weights,transformed)[:,:3]
def mesh_data(namepart):
    node=next(n for n in nodes if namepart in n.get('name','') and 'mesh' in n);primitive=g['meshes'][node['mesh']]['primitives'][0];at=primitive['attributes']
    points=acc(at['POSITION']);faces=acc(primitive['indices']).astype(int).reshape(-1,3);joints=acc(at['JOINTS_0']).astype(int);ws=acc(at['WEIGHTS_0']);weights=np.zeros((len(points),len(jointnames)))
    for k in range(4):np.add.at(weights,(np.arange(len(points)),joints[:,k]),ws[:,k])
    return points,faces,weights
CP,CF,CW=mesh_data('standing_collar');BP,BF,BW=mesh_data('_body_0_')
neckplane=shirt25['receipt']['neckline_clip_y_m'];band=(BP[BF,:,][...,1].min(axis=1)<=neckplane+.03)&(BP[BF,:,][...,1].max(axis=1)>=neckplane-.03);BF=BF[band]
def surface_distance(points,vertices,faces):
    a,b,c=(vertices[faces[:,k]][None,:,:] for k in range(3));p=points[:,None,:];ab=b-a;ac=c-a;ap=p-a
    d00=np.sum(ab*ab,axis=-1);d01=np.sum(ab*ac,axis=-1);d11=np.sum(ac*ac,axis=-1);d20=np.sum(ap*ab,axis=-1);d21=np.sum(ap*ac,axis=-1)
    denom=d00*d11-d01*d01;good=np.abs(denom)>1e-20;denom=np.where(good,denom,1)
    u=(d11*d20-d01*d21)/denom;v=(d00*d21-d01*d20)/denom
    projection=a+u[...,None]*ab+v[...,None]*ac
    ds=np.sum((p-projection)**2,axis=-1);inside=good&(u>=0)&(v>=0)&(u+v<=1)
    ds=np.where(inside,ds,np.inf)
    for start,end in [(a,b),(b,c),(c,a)]:
        e=end-start;length=np.sum(e*e,axis=-1);t=np.clip(np.sum((p-start)*e,axis=-1)/np.maximum(length,1e-30),0,1)
        q=start+t[...,None]*e;d=np.sum((p-q)**2,axis=-1);take=d<ds;projection=np.where(take[...,None],q,projection);ds=np.minimum(ds,d)
    nearest=np.argmin(ds,axis=1);ii=np.arange(len(points));normal=np.cross(ab,ac)[0];normal/=np.maximum(np.linalg.norm(normal,axis=1,keepdims=True),1e-30)
    delta=points-projection[ii,nearest];signed=np.sum(delta*normal[nearest],axis=1)
    return np.sqrt(ds[ii,nearest]),signed
Q=np.array(shirt25['positions_m'])[neck25];original=weights_array([original25[i] for i in neck25]);new=weights_array([new25[i] for i in neck25]);skinpoints=np.array(skin25)[neck25]
neckonly=weights_array([{'neck_01':1.} for i in neck25]);CPU=[]
for animation in [None]+g['animations']:
    if animation is None:name='rest';times=[0.];channels=[]
    else:
        name=animation['name'];channels=[];alltimes=[]
        for ch in animation['channels']:
            sampler=animation['samplers'][ch['sampler']];ts=acc(sampler['input']);vs=acc(sampler['output']);path=ch['target']['path'];alltimes.extend(ts)
            if path in ['translation','rotation','scale']:channels.append((ch['target']['node'],path,ts,vs,sampler.get('interpolation','LINEAR')))
        # Every supplied source key time plus an evenly spaced 61-point sweep.
        times=sorted(set(float(t) for t in alltimes)|set(np.linspace(min(alltimes),max(alltimes),61)))
    maximum=0.;relative=0.;posedmin=math.inf;posedmax=0.;normalmin=math.inf;collarmax=0.;bodymin=math.inf;bodymax=0.;head_neck=0.
    for t in times:
        overrides={}
        for node,path,ts,vs,interp in channels:
            ix=min(len(ts)-1,max(0,int(np.searchsorted(ts,t,side='right')-1)));value=vs[ix]
            if interp=='LINEAR' and ix+1<len(ts):
                f=float((t-ts[ix])/(ts[ix+1]-ts[ix]));value=slerp(vs[ix],vs[ix+1],f) if path=='rotation' else (1-f)*vs[ix]+f*vs[ix+1]
            else:need(interp=='STEP' or interp=='LINEAR','supported source sampler')
            overrides[(node,path)]=value
        mats=matrices(overrides);a=deform(Q,original,mats);b=deform(Q,new,mats);c=deform(Q,neckonly,mats);sk=deform(skinpoints,original,mats)
        maximum=max(maximum,float(np.max(np.linalg.norm(a-b,axis=1))));relative=max(relative,float(np.max(np.linalg.norm(b-c,axis=1))))
        distances=np.linalg.norm(b-sk,axis=1);posedmin=min(posedmin,float(np.min(distances)));posedmax=max(posedmax,float(np.max(distances)))
        collar=deform(CP,CW,mats);bodysurface=deform(BP,BW,mats)
        cd,cs=surface_distance(b,collar,CF);bd,bs=surface_distance(b,bodysurface,BF)
        collarmax=max(collarmax,float(max(cd)));bodymin=min(bodymin,float(min(bs)));bodymax=max(bodymax,float(max(bd)))
        head_neck=max(head_neck,float(np.max(np.abs(mats[joint_index['head']]-mats[joint_index['neck_01']]))))
    CPU.append({'clip':name,'sample_times':len(times),'max_seam_displacement_due_to_rebind_m':maximum,'max_seam_vs_same_points_neck_only_binding_m':relative,
        'seam_to_own_barycentric_body_point_min_m':posedmin,'seam_to_own_barycentric_body_point_max_m':posedmax,
        'max_nearest_collar_surface_distance_m':collarmax,'min_nearest_body_triangle_signed_distance_m':bodymin,'max_nearest_body_triangle_distance_m':bodymax,
        'head_neck_skin_matrix_max_difference':head_neck})
report['cpu_movement']={'glb_path':str(glb),'glb_sha256':sha(glb),'prepared_age':25,'source_meshes_identity':True,'rest_skin_identity_max_error':resterror,
    'neckline_points':len(neck25),'samples':CPU,'limits':['CPU linear blend skinning of frozen v2 seam against prior successful actual rig+clips, not new GLB/readback.',
    'Barycentric source point distance is not signed cloth/body clearance. Additional nearest-triangle oriented distances only sample the seam against the prior rest-neck body triangle band, not complete cloth/body collision.',
    'Ignores morph deformation and cloth simulation. No age35 actual prior rig/clip movement validation; adult35 has independent static geometry/weight audit only.',
    'New seam head/jaw to neck rebinding is disclosed reconstruction, not mere weight truncation or body-skin edit.']}
for name,spec in pins['files'].items():need(sha(V2/name)==spec['sha256'],'candidate unchanged after review '+name)
report['PASS']=True
report['disposition']={'source_invariants':'PASS','eligible_for_one_bounded_runtime_preview':True,'collar_fit_or_motion_accepted':False,
    'concerns':['New self-welded shirt loop is not fitted to retained collar: maximum nearest collar surface distance 34.4mm rest, 35.8mm idle/walk. Possible visible skin band requires actual pixels.',
        'Existing clips have effectively locked relative head/jaw versus neck transforms, so their negligible rebind displacement does not test independent head/jaw motion.',
        'Retained torso/upper-body influences move seam up to4.94mm versus a pure-neck-bound collar; no complete physical garment-fit claim.']}
(OUT/'INDEPENDENT-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
