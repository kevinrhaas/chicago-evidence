# Actual V1 preview — seated framing FAIL

The old prepared fixed-camera assumption was wrong for actual sit_drive. Technical24PASS and clean shutdown are preserved unchanged; seated framing and pose acceptance failed. Root viewed only the four images listed in V1-FRAMING-VERDICT.json. Standing source appearance shows fuller lower legs and a closed waistcoat, with a jagged hem now obvious. Complete fit, canonicalV5, photographic and world acceptance remain open. V5 source was not applied.

immutable-V1/ contains exact caller, inputs including actual canonical V4 baseline GLB/vendor, all24 original PNGs, release/intent, full technical receipts and server closure evidence. No V1 file was edited.
