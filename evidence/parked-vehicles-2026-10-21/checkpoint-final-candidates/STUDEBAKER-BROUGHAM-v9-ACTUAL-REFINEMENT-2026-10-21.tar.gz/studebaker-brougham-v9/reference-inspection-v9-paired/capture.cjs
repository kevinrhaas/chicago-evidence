// SPDX-License-Identifier: GPL-3.0-or-later
// Six-frame diagnostic, not photographic/model/app acceptance.
const fs=require('fs'),path=require('path'),cp=require('child_process');
const{chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
const ROOT=__dirname,OUT=path.join(ROOT,'actual');fs.mkdirSync(OUT);
let browser,server;const r={pass:false,rows:[],errors:[],scope:'Paired v8 original shadow / v8 preview normalBias / v9 refined geometry with same preview normalBias; source match remains open'};
const save=()=>fs.writeFileSync(path.join(OUT,'receipt.json'),JSON.stringify(r,null,2));
async function cleanup(){await browser?.close().catch(()=>{});if(server)try{process.kill(-server.pid,'SIGTERM')}catch{}}
const timer=setTimeout(()=>{r.error='90s deadline';save();cleanup().finally(()=>process.exit(124))},90000);
(async()=>{
 server=cp.spawn('python',['-m','http.server','8900','--bind','127.0.0.1','--directory',path.join(ROOT,'fixture')],{detached:true,stdio:'ignore'});
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const page=await browser.newPage();
 page.on('pageerror',e=>r.errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')r.errors.push(m.text())});
 for(const[viewport,width,height]of[['desktop',1280,800],['mobile',390,780]]){
  await page.setViewportSize({width,height});let baseline;
  for(const[version,normalBias,label,count]of[['v8',0,'v8-original-shadow',30804],['v8',.008,'v8-preview-normalbias',30804],['v9',.008,'v9-preview-normalbias',30782]]){
   if(!label.startsWith('v8-preview')){await page.goto(`http://127.0.0.1:8900/transport/brougham-${version}/`);await page.waitForFunction(()=>window.broughamReady)}
   const row=await page.evaluate(normalBias=>{const m=setPreviewNormalBias(normalBias),c=document.querySelector('canvas').getBoundingClientRect(),h=document.querySelector('header').getBoundingClientRect(),last=document.querySelector('header p:last-child').getBoundingClientRect();return{...m,dom:{canvas:c.toJSON(),header:h.toJSON(),lastText:last.toJSON(),viewport:[innerWidth,innerHeight]}}},normalBias);
   await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));fs.writeFileSync(path.join(OUT,`${viewport}-${label}.png`),await page.locator('canvas').screenshot());
   if(!baseline)baseline=row;const sameCamera=JSON.stringify(row.camera)===JSON.stringify(baseline.camera)&&JSON.stringify(row.referenceFit.basis)===JSON.stringify(baseline.referenceFit.basis)&&row.referenceFit.perspectiveFocalSourcePx===baseline.referenceFit.perspectiveFocalSourcePx;
   r.rows.push({viewport,label,sameCamera,...row});save();
   if(!sameCamera||row.glError||r.errors.length||row.sourceTriangles!==count||row.referenceFit.frontResidualPx>12||row.referenceFit.rearResidualPx>12||row.dom.canvas.right>width+1||row.dom.canvas.bottom>height+1||row.dom.header.bottom>row.dom.canvas.top+1||row.dom.lastText.bottom>row.dom.canvas.top+1)throw Error('Actual comparison guard');
  }
 }
 await page.evaluate(()=>disposeBrougham());r.pass=true;
})().catch(e=>{r.error=String(e.stack);process.exitCode=1}).finally(async()=>{clearTimeout(timer);await cleanup();r.closed=true;save()});
