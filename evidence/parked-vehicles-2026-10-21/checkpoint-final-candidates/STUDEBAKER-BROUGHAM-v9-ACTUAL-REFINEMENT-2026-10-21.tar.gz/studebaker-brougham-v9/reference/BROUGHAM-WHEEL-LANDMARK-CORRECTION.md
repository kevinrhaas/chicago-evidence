# Brougham wheel-landmark correction

This explicitly supersedes the **numerical pixel guesses** in `BROUGHAM-INDEPENDENT-VISUAL-BRIEF.md`. The earlier brief and capsules remain unchanged as history. The earlier wheel coordinates/radii were materially wrong; the author’s actual model/source comparison exposed the error. They must not be used as camera or geometry fit inputs.

The exact1556×1145 source b458565e and the author’s coordinate-grid crop were independently reread at original detail. Corrected manual estimates:

| Visible near wheel | Hub, source pixels | Approximate projected outer radius | Approximate visible rim extents |
| --- | --- | --- | --- |
| Front | (810,820), about±3px |106px, about±5px | x703–917; y713–926 |
| Rear | (1277,795), about±4px |137px, about±5px | x1140–1412; y655–929 |

Hub separation is roughly(467,−25)px. The projected radius ratio is about1.29; propagating the approximate manual radius intervals gives about1.19–1.41. These are informal visual uncertainty estimates, not certified numerical bounds. Some rear rim is obscured by body/suspension, and the near wheels overlap far wheels and gear. The older123/169px radii conflated visible arcs and were not adequately checked.

This is a projected drawing, not a dimensioned engineering side elevation. Its wheel ratio must not be copied as an exact physical diameter ratio. All other old roof/door/window numerical guesses are also withdrawn as fit inputs until checked against a coordinate grid. Qualitative curved-door/roof/glazing/driver-bench observations remain observations only. A render fitted to the old guesses is technical evidence, not photographic/source-match acceptance.

Machine-readable values and exact source/grid SHA256 bindings are in `BROUGHAM-WHEEL-LANDMARK-CORRECTION.json`. No source pixels were changed; no mesh, pose, browser, scan or network request was executed for this correction.
