# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,struct,hashlib
import numpy as np
R=Path(__file__).parent

def load(path):
 b=path.read_bytes();jlen=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+jlen]);binary=b[28+jlen:]
 def array(ai):
  a=d['accessors'][ai];v=d['bufferViews'][a['bufferView']];return np.frombuffer(binary,dtype='<f4',count=a['count']*3,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,3).astype(float)
 return b,d,array
b7,d7,a7=load(R.parent/'v7/candidate/brougham.glb');b8,d8,a8=load(R.parent/'v8/candidate/brougham.glb');b9,d9,a9=load(R/'candidate/brougham.glb');assert b9==(R/'repeat/brougham.glb').read_bytes()
maxerr=0;vertices=0
for i,m in enumerate(d8['meshes']):
 if not m['name'].startswith('surface_vehicle_body_'):continue
 old=a7(d7['meshes'][i]['primitives'][0]['attributes']['NORMAL']);new=a8(m['primitives'][0]['attributes']['NORMAL']);keep=np.ones(len(new),bool)
 for p in d8['extras']['parts']:
  if p['frame']=='vehicle_body'and p['material']==m['primitives'][0]['material'] and p['name'] in ['swept_crowned_roof','roof_underside','roof_end_lip','closed_end_crown_header']:
   s=p['triangle_start_in_batch']*3;keep[s:s+p['triangles']*3]=False
 expected=old[keep].copy();expected[:,1]/=1.13;expected/=np.linalg.norm(expected,axis=1)[:,None];maxerr=max(maxerr,float(np.max(np.linalg.norm(expected-new[keep],axis=1))));vertices+=len(expected)
assert maxerr<2e-5
minarea=1.;maxne=0.;mindot=1.;protected=[]
for i,m in enumerate(d9['meshes']):
 a=m['primitives'][0]['attributes'];pos=a9(a['POSITION']);normal=a9(a['NORMAL']);assert np.isfinite(pos).all()and np.isfinite(normal).all();t=pos.reshape(-1,3,3);cross=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);ln=np.linalg.norm(cross,axis=1);minarea=min(minarea,float(ln.min()/2));maxne=max(maxne,float(abs(np.linalg.norm(normal,axis=1)-1).max()))
 if m['name'].startswith('surface_vehicle_body_'):
  face=cross/ln[:,None];dot=np.einsum('ij,ikj->ik',face,normal.reshape(-1,3,3));mindot=min(mindot,float(dot.min()))
  if dot.min()<0:
   bad=np.where(dot.min(1)<0)[0];print('NEGATIVE',m['name'],[(p['name'],len([k for k in bad if p['triangle_start_in_batch']<=k<p['triangle_start_in_batch']+p['triangles']]))for p in d9['extras']['parts']if p['frame']=='vehicle_body'and p['material']==m['primitives'][0]['material']and any(p['triangle_start_in_batch']<=k<p['triangle_start_in_batch']+p['triangles']for k in bad)])
 else:
  om=d8['meshes'][i];assert om['name']==m['name'];prev=om['primitives'][0]['attributes'];assert np.array_equal(pos,a8(prev['POSITION']))and np.array_equal(normal,a8(prev['NORMAL']));protected.append(m['name'])
assert minarea>1e-10 and maxne<1e-5 and mindot>0

def cap_part(d,ar,name,outer):
 mi=next(i for i,m in enumerate(d['meshes'])if m['name']=='surface_vehicle_body_0');p=next(p for p in d['extras']['parts']if p['name']==name and p['frame']=='vehicle_body'and p['material']==0 and p['triangle_start_in_batch']>0)if name=='deep_U_closed_door'else None
 matches=[p for p in d['extras']['parts']if p['name']==name and p['frame']=='vehicle_body'and p['material']==0];verts=ar(d['meshes'][mi]['primitives'][0]['attributes']['POSITION']);tris=[]
 for p in matches:
  s=p['triangle_start_in_batch']*3;t=verts[s:s+p['triangles']*3].reshape(-1,3,3);n=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);n/=np.linalg.norm(n,axis=1)[:,None];tris.extend(t[(t[:,:,0].mean(1)>0)&((n[:,0]>.5)if outer else(n[:,0]<-.5))])
 return np.array(tris)
def clearance(d,ar):
 body=cap_part(d,ar,'deep_curved_lower_body',True);door=cap_part(d,ar,'deep_U_closed_door',False);samples=[]
 for t in door:
  for bary in [[1/3,1/3,1/3],[.6,.2,.2],[.2,.6,.2],[.2,.2,.6]]:samples.append(np.array(bary)@t)
 gaps=[]
 for s in samples:
  for t in body:
   uv=np.array([t[1,1:]-t[0,1:],t[2,1:]-t[0,1:]]).T
   if abs(np.linalg.det(uv))<1e-12:continue
   v,w=np.linalg.solve(uv,s[1:]-t[0,1:])
   if v>=-1e-7 and w>=-1e-7 and v+w<=1+1e-7:gaps.append(float(s[0]-(t[0,0]+v*(t[1,0]-t[0,0])+w*(t[2,0]-t[0,0]))))
 assert gaps
 return {'samples_overlapping_body_cap':len(gaps),'minimum_door_inner_to_body_outer_x_clearance_m':min(gaps),'scope':'Positive-X near body/door cap overlap region, interior barycentric samples; not exhaustive whole-vehicle collision certification'}
tube_volumes=[]
tube_names={'door_edge_lining','side_window_frame','rear_quarter_fine_lining','roof_drip_edge','roof_end_lip','driver_side_rail','lamp_frame_ring','lamp_corner_stile','lamp_finial'}
for part in d9['extras']['parts']:
 if part['frame']!='vehicle_body' or part['name']not in tube_names:continue
 mi=next(i for i,m in enumerate(d9['meshes'])if m['name']=='surface_vehicle_body_'+str(part['material']));po=a9(d9['meshes'][mi]['primitives'][0]['attributes']['POSITION']);start=part['triangle_start_in_batch']*3;t=po[start:start+part['triangles']*3].reshape(-1,3,3);volume=float(np.einsum('ij,ij->i',t[:,0],np.cross(t[:,1],t[:,2])).sum()/6)
 assert volume>0;tube_volumes.append({'name':part['name'],'positive_signed_volume_m3':volume})
review={'candidate_sha256':hashlib.sha256(b9).hexdigest(),'repeat_byteexact':True,'v8_inverse_transpose_normal_proof_against_v7':{'vertices':vertices,'maximum_unit_normal_error':maxerr,'roof_crown_changed_parts_excluded':True},'v9_trim_signed_volumes':tube_volumes,'v9_minimum_stored_corner_normal_dot_geometric_face':mindot,'minimum_triangle_area_m2':minarea,'maximum_normal_length_error':maxne,'all_nonbody_P_N_arrays_exact_v8':protected,'v8_door_body_overlap_check':clearance(d8,a8),'v9_door_body_overlap_check':clearance(d9,a9),'limits':'Finite visible-body affine normal/winding and cap overlap diagnostics. Does not prove all assemblies collision-free. Preview shadow normalBias may diagnose raster acne but cannot establish model or app appearance acceptance.'}
assert review['v9_door_body_overlap_check']['minimum_door_inner_to_body_outer_x_clearance_m']>0
(R/'normal-winding-overlap-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review))
