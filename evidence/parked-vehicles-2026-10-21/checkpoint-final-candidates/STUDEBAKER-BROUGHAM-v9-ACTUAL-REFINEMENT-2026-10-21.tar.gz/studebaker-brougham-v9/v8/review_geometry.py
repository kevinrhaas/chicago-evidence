# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,hashlib,struct
import numpy as np
R=Path(__file__).parent

def load(p):
 b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);binary=b[28+n:]
 def arr(ai):
  a=d['accessors'][ai];v=d['bufferViews'][a['bufferView']];return np.frombuffer(binary,dtype='<f4',count=a['count']*3,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,3)
 return b,d,arr
old,od,oa=load(R.parent/'v7/candidate/brougham.glb');b,d,arr=load(R/'candidate/brougham.glb');assert b==(R/'repeat/brougham.glb').read_bytes();assert d['materials']==od['materials'];assert d['extras']['parts']==od['extras']['parts'];assert d['extras']['statistics']=={'triangles':30804,'meshes':24,'nodes':41};p=d['extras']['parameters'];mindeg=float('inf');err=0;rows=[]
for i,m in enumerate(d['meshes']):
 a=m['primitives'][0]['attributes'];po=arr(a['POSITION']);no=arr(a['NORMAL']);prev=od['meshes'][i]['primitives'][0]['attributes'];assert np.isfinite(po).all() and np.isfinite(no).all()
 tr=po.astype(float).reshape(-1,3,3);areas=np.linalg.norm(np.cross(tr[:,1]-tr[:,0],tr[:,2]-tr[:,0]),axis=1)/2;mindeg=min(mindeg,float(areas.min()));err=max(err,float(np.max(np.abs(np.linalg.norm(no.astype(float),axis=1)-1))))
 if m['name'].startswith('surface_vehicle_body_'):
  keep=np.ones(len(po),dtype=bool)
  for part in d['extras']['parts']:
   if part['frame']=='vehicle_body' and part['material']==m['primitives'][0]['material'] and part['name']=='roof_end_lip':
    start=part['triangle_start_in_batch']*3;keep[start:start+part['triangles']*3]=False
  assert po[keep][:,[0,2]].tobytes()==oa(prev['POSITION'])[keep][:,[0,2]].tobytes()
 if m['name'].startswith('surface_hubcap_') or m['name'].startswith('surface_vehicle_wheel_rear_'):
  assert po.tobytes()==oa(prev['POSITION']).tobytes() and no.tobytes()==oa(prev['NORMAL']).tobytes();rows.append(m['name'])
 if 'vehicle_wheel_front_'in m['name']:
  nodei=next(k for k,n in enumerate(d['nodes'])if n.get('mesh')==i);frame=next(n['name']for n in d['nodes']if nodei in n.get('children',[]))
  for part in d['extras']['parts']:
   if part['frame']==frame and part['material']==m['primitives'][0]['material'] and part['name']in['rounded_hub','solid_painted_hub_core']:
    start=part['triangle_start_in_batch']*3;end=start+part['triangles']*3;assert po[start:end].tobytes()==oa(prev['POSITION'])[start:end].tobytes() and no[start:end].tobytes()==oa(prev['NORMAL'])[start:end].tobytes();rows.append(frame+':'+part['name'])
assert mindeg>1e-10 and err<1e-5
for n,on in zip(d['nodes'],od['nodes']):
 if n['name'].startswith('vehicle_seat_'):assert abs(n['translation'][1]-(on['translation'][1]*1.13+.03))<1e-12
 if n['name']in ['vehicle_running_gear_rear','vehicle_steer_front']:
  assert abs(abs(n['translation'][2])-p['wheelbase_m']/2)<1e-12
r={'candidate_sha256':hashlib.sha256(b).hexdigest(),'repeat_byteexact':True,'statistics':d['extras']['statistics'],'materials_and_part_ranges_exact_v7':True,'body_X_Z_arrays_exact_v7_except_crown_following_roof_end_lip':True,'protected_local_arrays_exact_v7':rows,'seat_sockets_follow_body_vertical_mapping':True,'minimum_triangle_area_m2':mindeg,'maximum_normal_length_error':err,'body_vertical_affine':p['body_vertical_affine'],'roof_crown_m_before_body_map':p['roof_cross_crown_m'],'dimension_tier':p['dimension_tier'],'status':'UNRENDERED until root releases browser lane; not photographic/source acceptance'}
(R/'pure-geometry-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
