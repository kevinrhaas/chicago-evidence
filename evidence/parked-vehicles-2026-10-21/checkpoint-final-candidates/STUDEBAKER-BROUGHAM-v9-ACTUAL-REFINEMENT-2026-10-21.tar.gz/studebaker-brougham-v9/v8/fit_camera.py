# SPDX-License-Identifier: GPL-3.0-or-later
"""Perspective hypothesis using manual source controls, never metric calibration."""
from pathlib import Path
import json,math
import numpy as np
from scipy.optimize import least_squares
R=Path(__file__).parent
p=json.loads((R/'parameters.json').read_text());WB=p['wheelbase_m'];RF=p['front_wheel_radius_m'];RR=p['rear_wheel_radius_m'];track=p['track_m'];face=.096
controls=[('front_near',[810,820],3,RF,1,106,5),('rear_near',[1277,795],4,RR,-1,137,5),('front_far',[750,795],15,RF,1,98,12),('rear_far',[1215,775],15,RR,-1,125,15)]
# Far estimates here are deliberately loose manual readings; primary illustration has overlap/ink ambiguity.
def eval(q):
 az,el,D,F,cx,cy=q;d=np.array([math.cos(el)*math.cos(az),math.sin(el),math.cos(el)*math.sin(az)]);right=np.cross([0,1,0],d);right/=np.linalg.norm(right);up=np.cross(d,right)
 def proj(v):
  dep=D-v@d;return np.c_[cx+F*(v@right)/dep,cy-F*(v@up)/dep]
 rows=[]
 for name,xy,u,r,zsgn,rpix,ru in controls:
  side=1 if name.endswith('near') else -1;hub=np.array([side*(track/2+face),r,zsgn*WB/2]);wheel=hub.copy();wheel[0]=side*track/2
  theta=np.linspace(0,2*np.pi,720);ring=wheel+np.c_[np.zeros_like(theta),r*np.sin(theta),r*np.cos(theta)];rim=proj(ring);h=proj(hub.reshape(1,3))[0]
  rows.append({'name':name,'hub':h.tolist(),'rim_min':rim.min(0).tolist(),'rim_max':rim.max(0).tolist(),'vertical_radius':float(np.ptp(rim[:,1])/2),'horizontal_radius':float(np.ptp(rim[:,0])/2)})
 return rows,{'right':right.tolist(),'up':up.tolist(),'towardCamera':d.tolist()}
def residual(q):
 rows,_=eval(q);res=[]
 for row,(_,xy,u,r,zsgn,rpix,ru) in zip(rows,controls):
  res.extend((np.array(row['hub'])-xy)/u);res.append((row['vertical_radius']-rpix)/ru)
  if row['name'].endswith('near'):res.append((row['horizontal_radius']-({'front_near':107,'rear_near':136}[row['name']]))/7)
 return res
best=None
for az0 in [5,15,25]:
 for D0 in [10,30,100,500]:
  q=[math.radians(az0),math.radians(3),D0,210*D0,1050,940]
  fit=least_squares(residual,q,bounds=([0,-.15,4,300,-3000,-1000],[1,.3,3000,800000,5000,3000]),max_nfev=2000)
  if best is None or np.linalg.norm(fit.fun)<np.linalg.norm(best.fun):best=fit
rows,basis=eval(best.x);az,el,D,F,cx,cy=best.x
out={'kind':'weighted least-squares perspective hypothesis, manual controls, not calibrated camera','parameters_unchanged':p,'fit':{'azimuth_front_deg':math.degrees(az),'elevation_deg':math.degrees(el),'distance_m':D,'focal_px':F,'principal_px':[cx,cy],'basis':basis,'weighted_residual_norm':float(np.linalg.norm(best.fun))},'controls':[{'name':n,'center_px':xy,'center_informal_uncertainty_px':u,'vertical_radius_px':rr,'radius_informal_uncertainty_px':ru}for n,xy,u,r,z,rr,ru in controls],'predictions':rows,'limits':'Unscaled illustration, hidden/overlapping rims. Near controls corrected independently; far controls are loose provisional manual readings. Near-fit residual alone does not establish camera or silhouette acceptance.'}
(R/'camera-hypothesis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['fit']));print(json.dumps(rows))
