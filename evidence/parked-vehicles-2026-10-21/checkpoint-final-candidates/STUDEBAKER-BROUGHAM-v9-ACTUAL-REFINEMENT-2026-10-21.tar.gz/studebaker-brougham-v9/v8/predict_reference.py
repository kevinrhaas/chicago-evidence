# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import hashlib,json,struct
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).parent;A=R;h=json.loads((R/'camera-hypothesis.json').read_text());q=h['fit'];b=(R/'candidate/brougham.glb').read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);binary=b[28+n:]
def arr(ai):
 a=d['accessors'][ai];v=d['bufferViews'][a['bufferView']];return np.frombuffer(binary,dtype='<f4',count=a['count']*3,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,3)
parent={c:i for i,no in enumerate(d['nodes'])for c in no.get('children',[])}
def world(i):
 out=np.zeros(3)
 while True:
  out+=d['nodes'][i].get('translation',[0,0,0])
  if i not in parent:break
  i=parent[i]
 return out
right=np.array(q['basis']['right']);up=np.array(q['basis']['up']);toward=np.array(q['basis']['towardCamera']);cx,cy=q['principal_px'];F=q['focal_px'];D=q['distance_m']
def proj(p):
 depth=D-p@toward;return np.c_[cx+F*(p@right)/depth,cy-F*(p@up)/depth]
selected=['deep_U_closed_door','side_door_glass','rear_quarter_panel','swept_crowned_roof','rounded_iron_tire','solid_bright_hub_button'];rows=[]
for mi,m in enumerate(d['meshes']):
 nodei=next(i for i,no in enumerate(d['nodes'])if no.get('mesh')==mi);frame=d['nodes'][parent[nodei]]['name'];pr=m['primitives'][0];vertices=arr(pr['attributes']['POSITION'])
 seen=set()
 for p in d['extras']['parts']:
  if p['name'] not in selected or p['frame']!=frame or p['material']!=pr['material']:continue
  key=(p['name'],p['triangle_start_in_batch'],p['triangles'])
  if key in seen:continue
  seen.add(key);s=p['triangle_start_in_batch']*3;points=vertices[s:s+p['triangles']*3].astype(float)+world(nodei);pixels=proj(points);near=bool(points[:,0].mean()>0)
  rows.append({'part':p['name'],'frame':frame,'side':'both' if points[:,0].min()<0<points[:,0].max() else 'near'if near else'far','source_px_min':pixels.min(0).tolist(),'source_px_max':pixels.max(0).tolist(),'world_min_m':points.min(0).tolist(),'world_max_m':points.max(0).tolist()})
# Vertical radius is the major ellipse axis approximately; actual rim/mesh envelope differs from ideal wheel radius by the rounded tire section.
r={'candidate_sha256':hashlib.sha256(b).hexdigest(),'projection':'CPU-only prospective positive-Z perspective hypothesis; NOT an actual render, source-pixel coordinates, full selected triangle vertices before occlusion','parts':rows,'camera':q,'manual_control_limits':h['limits'],'important':'No all-part bounding box is a visible silhouette or an exact historic measurement; roof is both sides, door records each side separately.'}
(A/'predicted-mesh-source-pixel-measurements.json').write_text(json.dumps(r,indent=2)+'\n')

print(json.dumps([x for x in rows if x["part"] in ["swept_crowned_roof","deep_U_closed_door","side_door_glass"] and x["side"]!="far"],indent=2))
