# Brougham upper rear quarter: finite source ruling

**Ruling: material/glazing is unresolved in the acquired source.** The plate supports the panel outline and its tonal treatment; it does not establish that this area is transparent glass, a closed curtain, exterior leather or painted coachwork. Do not promote any of those interpretations to attested.

I independently inspected the correct1556×1145 image `b458565e…` and a pixel-exact crop of the3112×2290 original JP2 `89f12c26…`. Crop original pixels(2200,960)–(2540,1380) corresponds to half-size source(1100,480)–(1270,690); no resizing or retouching was applied. The inspection image is `brougham-rear-quarter-source-inspection.png`.

Visible evidence:

- A dark upper-quarter field is bounded by a near-vertical forward member, roof rail, outer rear edge, and a broad curved lower molding.
- It has a triangular/diagonal stippled highlight, darkening to near-black at the top. The print does not resolve folds, a curtain hem, glazing reflections or recognizable objects seen through it.
- The neighboring door window does show occupants/interior. That contrast means the quarter is not demonstrated to be equally clear glass; it could nevertheless have dark glazing, a shade or an opaque surface.
- The acquired catalog text captions this specimen only **“BROUGHAM.”** No glazing/material specification was found for it. “CURTAIN ROCKAWAY” is a different catalog specimen and cannot be transferred here. The background shop word “CURTAINS” is scenery, not a label for this panel.

For the next model, **retaining an opaque dark quarter is a defensible reconstruction**, with a gently varied/stippled finish matching the visible tonal difference. It must be labeled an appearance choice, not proof of solid painted construction. A transparent rear-quarter window would also be a new reconstruction and needs another view or technical description before being treated as a correction. Preserve the observed curved molding and roof/body boundaries regardless of material choice.

No second view or physical-dimension drawing of this exact specimen was acquired. No network, browser, mesh, renderer, app or Git operation was used for this ruling. The original source/correction capsules remain unchanged.
