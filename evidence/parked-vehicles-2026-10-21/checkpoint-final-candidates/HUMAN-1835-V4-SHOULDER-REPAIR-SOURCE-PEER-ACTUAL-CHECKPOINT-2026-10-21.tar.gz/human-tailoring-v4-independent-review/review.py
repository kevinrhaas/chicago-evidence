"""Finite one-thread V4 source/math review. No browser/BPy/app/candidate writes."""
from pathlib import Path
import ast,hashlib,importlib.util,json,math,sys,time
sys.dont_write_bytecode=True
V3=Path('/workspace/shared/human-tailoring-v3-source-design');V4=Path('/workspace/shared/human-tailoring-v4-shoulder-repair');ROOT=Path('/workspace/chicago/chicago/4d');OUT=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(x,s):
 if not x:raise AssertionError(s)
frozen=V4/'FROZEN-V4-SOURCE.json';need(sha(frozen)=='ae9688fbb96462513f0e07ac567e95b4948f8eb1a6127da209d3e30b6f64caae','manifest pin');pins=json.loads(frozen.read_text())['files']
for f,p in pins.items():need(sha(V4/f)==p['sha256'],'frozen source '+f)
def functions(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.FunctionDef)}
path='proposed/chicago/4d/tools/human_workwear_fit.py';a=functions(V3/path);b=functions(V4/path)
need(set(a)==set(b) and all(v==b[k] for k,v in a.items() if k!='garment_shell'),'only garment_shell function changes')
recipe=json.loads((V4/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text());oldrecipe=json.loads((V3/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text());r=json.loads(json.dumps(recipe))
for key in ['shirt_x_ease_arm_radius_fraction','shirt_x_ease_basis','shirt_coverage_limit']:del r['workwear_tailoring'][key]
need(r==oldrecipe,'only three disclosed recipe additions')
sys.path.insert(0,str(ROOT/'tools'))
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
old=load('immutable_v3_fit',V3/path);new=load('frozen_v4_fit',V4/path)
start=time.monotonic();report={'scope':'Independent finite source field/preservation and replayed exact saved ray/face controls only; no renderer/Blender/whole gate/broader animation sweep','frozen_sha256':sha(frozen),'patch_sha256':sha(V4/'SHOULDER-V4-AGAINST-V3.patch'),'source_math':[]}
for age in [25,35]:
 bp=ROOT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json';raw=bp.read_bytes();body=json.loads(raw);m=body['meshes'][0];bones={b['name']:b for b in body['skeleton']};h=max(p[1] for p in m['positions_m']);s0=old.garment_shell(m,'shirt',.006,recipe,bones,h);s1=new.garment_shell(m,'shirt',.006,recipe,bones,h)
 for key in ['triangles','weights','uvs','source_basis','corner_uvs','source_triangle_indices']:need(s0[key]==s1[key],'shirt topology/skin/UV/source unchanged '+key)
 axis=sum(bones['upperarm_'+side]['head_m'][1] for side in ['l','r'])/2;radial=max(abs(p[1]-axis) for p,w in zip(m['positions_m'],m['weights']) if max(w.get('upperarm_l',0),w.get('upperarm_r',0))>.5);width=.5*radial
 need(s1['receipt']['shirt_continuous_x_ease_field']=={'axis_y_m':axis,'actual_arm_radial_extent_m':radial,'transition_width_m':width,'radius_fraction':.5},'field actual skeletal/surface measurements')
 source={sid:p for sid,p in zip(m['source_vertex_indices'],m['positions_m'])};maxerr=0.;envelope=0.;altered=0
 for before,after,basis in zip(s0['positions_m'],s1['positions_m'],s1['source_basis']):
  point=[sum(v*source[sid][k] for sid,v in basis.items()) for k in range(3)];factor=max(0,min(1,(axis-point[1])/width));expected=list(before)
  if abs(before[0])>.02:expected[0]+=(factor-1)*math.copysign(.007,before[0])
  err=math.dist(after,expected);maxerr=max(maxerr,err);envelope=max(envelope,math.dist(after,point));altered+=before!=after
  need(before[1:]==after[1:],'only original shirt X positions change')
 need(maxerr<1e-12 and envelope<=.013+1e-12,'independent field equation/envelope')
 for kind,offset in [('trousers',.007),('waistcoat',.014)]:
  q0=old.garment_shell(m,kind,offset,recipe,bones,h);q1=new.garment_shell(m,kind,offset,recipe,bones,h)
  for key in ['positions_m','triangles','weights','uvs','source_basis','corner_uvs','source_triangle_indices']:need(q0[key]==q1[key],'other garment unchanged '+kind+'/'+key)
 if age==25:
  joined=new.standing_collar_extension(s1,m,bones,recipe);need(json.loads(json.dumps(joined))==json.loads((V4/'shirt-adult25.json').read_text())[0],'saved actual joined V4 exact source reproduction')
  ids=joined['collar_extension']['shared_base_vertex_ids'];need(all(joined['positions_m'][i]==s1['positions_m'][i] and joined['weights'][i]==s1['weights'][i] for i in ids),'collar shares new actual base')
  bad=json.loads(json.dumps(recipe));bad['workwear_tailoring']['shirt_x_ease_arm_radius_fraction']=0
  try:new.garment_shell(m,'shirt',.006,bad,bones,h)
  except ValueError:pass
  else:raise AssertionError('zero transition width accepted')
 need(bp.read_bytes()==raw,'source body immutable')
 report['source_math'].append({'age':age,'body_sha256':sha(bp),'axis_y_m':axis,'actual_radial_extent_m':radial,'width_m':width,'independent_field_max_vector_error_m':maxerr,'maximum_original_shirt_displacement_m':envelope,'changed_original_shirt_vertices':altered,'topology_uv_skin_exact':True,'waistcoat_trousers_exact':True})

# Replay only the author-pinned finite controls after inspecting their code.
# Prefix ends BEFORE its report creation/write; diagnose.py prelude ends BEFORE
# image loading or any old report write. It imports our prior inert GLB/LBS defs.
control=(V4/'face_ray_controls.py').read_text();prefix=control[:control.index("report={'scope'")]
need('write_text(' not in prefix and 'write_bytes(' not in prefix,'finite control prefix has no explicit output writes')
ns={'__file__':str(V4/'face_ray_controls.py')};exec(compile(prefix,str(V4/'face_ray_controls.py')+' finite no-write replay','exec'),ns)
saved=json.loads((V4/'FACE-RAY-CONTROLS.json').read_text())
need(ns['full']==saved['full_saved_face_audit'],'complete original rest/idle0 face controls reproduced exactly')
need(ns['rays']==saved['exact_observed_ray_controls'],'two observed ray controls reproduced exactly')
need(ns['clipchecks']==saved['same_finite_affected_face_clip_samples'],'same8 faces at exact10 saved pose samples reproduced exactly')
need(len(ns['rows'])==4792 and len(ns['clipchecks'])==10,'finite source scope unchanged')
need(all(not r['new_negative_source_faces'] for r in ns['full'].values()),'new negative source face')
need(all(r['old_body_first'] and not r['v4_body_first'] for r in ns['rays']),'old skin-first ray must reverse to cloth-first')
need(all(not face['newly_negative'] for row in ns['clipchecks'] for face in row['faces']),'new sampled regression-face negative')
need(ns['full']['idle0']['v4_negative_faces']==40,'remaining inherited negatives must stay disclosed')
report['finite_face_ray_replay']={'pinned_author_control_sha256':sha(V4/'FACE-RAY-CONTROLS.json'),'complete_original_faces':4792,'rest':ns['full']['rest'],'idle0':ns['full']['idle0'],'observed_rays':ns['rays'],'same_regression_source_faces':[2566,15804,2227,2704,7120,15468,15943,20357],'saved_pose_samples':10,'new_sampled_negative_faces':0,'scope':'Replayed reviewed/pinned finite control arithmetic and independently checked resulting regression decisions; no new pose times or source faces added'}
for f,p in pins.items():need(sha(V4/f)==p['sha256'],'candidate immutable after review '+f)
report['source_invariants_PASS']=True;report['eligible_for_one_authorized_actual_preview']=True;report['elapsed_s']=time.monotonic()-start
report['limits']=['40 inherited idle0 negative source-face projections remain OPEN (minimum -8.98mm); no mask, reclassification or complete garment fit acceptance.',
 'Field is continuous piecewise linear in source Y with slope changes at clamp bounds; existing abs(X)>20mm branch is unchanged. It affects all shirt points by the declared skeletal-height field, not only triangles named shoulder.',
 'Full6mm source-shared normal term is retained, but added X can alter signed clearance;13mm is a displacement envelope, not surface clearance.',
 'Two saved pixel rays are source-array geometric predictions under actual prior idle0 rig matrices, not actual new rendered pixels. Existing10 pose samples cover only8 faces; rest/idle0 complete-original audit excludes clipped collar/cut triangles.',
 'One actual preview, fresh canonical LOD/export/source-web/sole/animation qualification and photographic/period tailoring remain pending. No easing amount, normal method, skin, body, rig, mask, weights, UV, sole or export guard change is approved by this source result.']
(OUT/'INDEPENDENT-V4-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
