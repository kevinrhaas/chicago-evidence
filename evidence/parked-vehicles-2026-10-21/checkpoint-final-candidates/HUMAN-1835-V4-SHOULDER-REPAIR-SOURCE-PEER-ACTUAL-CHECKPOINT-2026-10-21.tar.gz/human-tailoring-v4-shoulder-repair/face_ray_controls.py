"""Finite source/actual idle face-ray regression and same8faces at3clip times."""
from pathlib import Path
import ast,json,sys,math,time
import numpy as np
sys.dont_write_bytecode=True
D=Path(__file__).parent;diagnosis=Path('/workspace/shared/human-tailoring-v4-shoulder-source-diagnosis');text=(diagnosis/'diagnose.py').read_text();exec(compile(text[:text.index('img=Image.open')],str(diagnosis/'diagnose.py')+' inert prelude','exec'))
# D is reset by the inert prelude; restore the successor output, no old writes.
D=Path('/workspace/shared/human-tailoring-v4-shoulder-repair');v4=json.loads((D/'shirt-adult25.json').read_text())[0];VP=np.array(v4['positions_m']);VW=weights_array(v4['weights']);v4posed=deform(VP,VW,mats);oldshirt=shirt;old_pos=shirt_pos;body_by_sid={sid:i for i,sid in enumerate(S)};sourcepos={sid:p for sid,p in zip(source['source_vertex_indices'],PP)};rows=[]
for gi,(face,fi) in enumerate(zip(shirt['triangles'],shirt['source_triangle_indices'])):
 if fi is None or any(len(shirt['source_basis'][i])!=1 or next(iter(shirt['source_basis'][i].values()))!=1. for i in face):continue
 sids=[int(next(iter(shirt['source_basis'][i]))) for i in face];bi=[body_by_sid[sid] for sid in sids];bp=body_pos[bi];n=np.cross(bp[1]-bp[0],bp[2]-bp[0]);n/=np.linalg.norm(n);rp=np.array([sourcepos[sid] for sid in sids]);rn=np.cross(rp[1]-rp[0],rp[2]-rp[0]);rn/=np.linalg.norm(rn)
 rows.append({'source_face':fi,'shirt_triangle':gi,'source_ids':sids,'old_rest_m':float(min(np.sum((SP[face]-rp)*rn,axis=1))),'v4_rest_m':float(min(np.sum((VP[face]-rp)*rn,axis=1))),'old_idle0_m':float(min(np.sum((old_pos[face]-bp)*n,axis=1))),'v4_idle0_m':float(min(np.sum((v4posed[face]-bp)*n,axis=1)))})
full={}
for pose in ('rest','idle0'):
 oldbad={x['source_face'] for x in rows if x['old_'+pose+'_m']<0};newbad={x['source_face'] for x in rows if x['v4_'+pose+'_m']<0};full[pose]={'old_negative_faces':len(oldbad),'v4_negative_faces':len(newbad),'new_negative_source_faces':sorted(newbad-oldbad),'v4_minimum_m':min(x['v4_'+pose+'_m'] for x in rows)}
rays=[]
for x,y in [(970,563),(407,499)]:
 direction=forward+(2*(x+.5)/1280-1)*1.6*fov*right+(1-2*(y+.5)/800)*fov*up;direction/=np.linalg.norm(direction);bh=hit(body_pos,BF,direction);oldh=hit(old_pos,SF,direction);newh=hit(v4posed,np.array(v4['triangles']),direction);rays.append({'pixel':[x,y],'old_shirt_minus_body_distance_m':oldh['distance']-bh['distance'],'v4_shirt_minus_body_distance_m':newh['distance']-bh['distance'],'old_body_first':bh['distance']<oldh['distance'],'v4_body_first':bh['distance']<newh['distance']})
regression=[2566,15804,2227,2704,7120,15468,15943,20357];byfi={x['source_face']:x for x in rows};gi=sorted(set(i for fi in regression for i in SF[byfi[fi]['shirt_triangle']]));bi=sorted(set(body_by_sid[sid] for fi in regression for sid in byfi[fi]['source_ids']));gmap={i:j for j,i in enumerate(gi)};bmap={i:j for j,i in enumerate(bi)};clipchecks=[]
for animation in [None]+g['animations']:
 if animation is None:name='rest';times=[0.];channels=[]
 else:
  name=animation['name'];channels=[];alltimes=[]
  for ch in animation['channels']:
   sample=animation['samplers'][ch['sampler']];ts=acc(sample['input']);vs=acc(sample['output']);path=ch['target']['path'];alltimes.extend(ts)
   if path in ('translation','rotation','scale'):channels.append((ch['target']['node'],path,ts,vs,sample.get('interpolation','LINEAR')))
  times=sorted(set([float(min(alltimes)),float((min(alltimes)+max(alltimes))/2),float(max(alltimes))]))
 for tm in times:
  overrides={}
  for node,path,ts,vs,interpolation in channels:
   i=min(len(ts)-1,max(0,int(np.searchsorted(ts,tm,side='right')-1)));value=vs[i]
   if interpolation=='LINEAR' and i+1<len(ts):
    t=float((tm-ts[i])/(ts[i+1]-ts[i]));value=slerp(vs[i],vs[i+1],t) if path=='rotation' else (1-t)*vs[i]+t*vs[i+1]
   elif interpolation not in ('STEP','LINEAR'):raise ValueError('unhandled actual interpolation')
   overrides[(node,path)]=value
  M=matrices(overrides);bodymini=deform(BP[bi],BW[bi],M);oldmini=deform(SP[gi],weights_array(shirt['weights'])[gi],M);newmini=deform(VP[gi],VW[gi],M);faces=[]
  for fi in regression:
   row=byfi[fi];gf=[gmap[i] for i in SF[row['shirt_triangle']]];bf=[bmap[body_by_sid[sid]] for sid in row['source_ids']];p=bodymini[bf];n=np.cross(p[1]-p[0],p[2]-p[0]);n/=np.linalg.norm(n);a=float(min(np.sum((oldmini[gf]-p)*n,axis=1)));b=float(min(np.sum((newmini[gf]-p)*n,axis=1)));faces.append({'source_face':fi,'old_minimum_projection_m':a,'v4_minimum_projection_m':b,'newly_negative':a>=0>b})
  clipchecks.append({'clip':name,'time_s':tm,'faces':faces})
report={'scope':'Finite complete-original4,792source-face planes at rest/actualidle0, exact two saved pixel rays, only same8regression faces at3times per actual clip. Not complete triangle collision/continuous animation/LOD/export/photo or period acceptance.','full_saved_face_audit':full,'saved_faces_tested':len(rows),'exact_observed_ray_controls':rays,'same_finite_affected_face_clip_samples':clipchecks,'remaining40negative_face_projections_open':True,'no_source_or_app_edit_in_controls':True,'PASS':all(not x['new_negative_source_faces'] for x in full.values()) and all(not x['v4_body_first'] and x['old_body_first'] for x in rays) and all(not f['newly_negative'] for x in clipchecks for f in x['faces'])};(D/'FACE-RAY-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='same_finite_affected_face_clip_samples'},indent=2));print('clip samples',len(clipchecks),'newly_negative',[{'clip':x['clip'],'time':x['time_s'],'face':f['source_face']} for x in clipchecks for f in x['faces'] if f['newly_negative']])
