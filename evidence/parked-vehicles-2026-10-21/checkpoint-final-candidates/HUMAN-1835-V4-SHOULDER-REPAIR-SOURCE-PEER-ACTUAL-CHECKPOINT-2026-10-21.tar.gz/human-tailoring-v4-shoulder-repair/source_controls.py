"""Finite one-thread actual25/35 source controls for narrow landmark ease field."""
from pathlib import Path
import json,sys,ast,math,collections,hashlib,importlib.util,time
sys.dont_write_bytecode=True
D=Path(__file__).parent;V3=Path('/workspace/shared/human-tailoring-v3-source-design');ROOT=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(ROOT/'tools'))
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
old=load('v3_frozen_fit',V3/'proposed/chicago/4d/tools/human_workwear_fit.py');new=load('v4_outside_fit',D/'proposed/chicago/4d/tools/human_workwear_fit.py');recipe=json.loads((D/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text());start=time.monotonic()
def need(v,s):
 if not v:raise AssertionError(s)
# Reuse only pure topology checker definitions, not previous audit execution.
tree=ast.parse((V3/'narrow_controls.py').read_text());exec(compile(ast.fix_missing_locations(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('edge_map','collar_checks')],type_ignores=[])),'prior pure topology checker','exec'))
report={'scope':'Actual25/35 source invariant controls only; complete cloth collision/LOD/export/animation/period/photo open','ages':[],'negative_controls':[]}
for age in (25,35):
 bp=ROOT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json';raw=bp.read_bytes();body=json.loads(raw);m=body['meshes'][0];bones={b['name']:b for b in body['skeleton']};height=max(p[1] for p in m['positions_m']);s0=old.garment_shell(m,'shirt',.006,recipe,bones,height);s1=new.garment_shell(m,'shirt',.006,recipe,bones,height)
 for k in ('triangles','weights','uvs','source_basis','corner_uvs','source_triangle_indices'):need(s0[k]==s1[k],'original shirt unchanged '+k)
 sources={sid:p for sid,p in zip(m['source_vertex_indices'],m['positions_m'])};envelope=[]
 for q,basis in zip(s1['positions_m'],s1['source_basis']):
  p=[math.fsum(v*sources[sid][k] for sid,v in basis.items()) for k in range(3)];envelope.append(math.dist(q,p))
 need(max(envelope)<=.013+1e-12,'unchanged13mm original shirt displacement envelope')
 field=s1['receipt']['shirt_continuous_x_ease_field'];need(field['radius_fraction']==.5 and field['transition_width_m']>0,'actual source landmark ease width')
 for kind,offset in [('trousers',.007),('waistcoat',.014)]:
  a=old.garment_shell(m,kind,offset,recipe,bones,height);b=new.garment_shell(m,kind,offset,recipe,bones,height)
  for k in ('positions_m','triangles','weights','uvs','corner_uvs','source_basis','source_triangle_indices'):need(a[k]==b[k],'other garment unchanged '+kind+'/'+k)
 g=new.standing_collar_extension(s1,m,bones,recipe);joined=collar_checks(g,s1);need(bp.read_bytes()==raw,'actual source body immutable');report['ages'].append({'age':age,'source_body_sha256':hashlib.sha256(raw).hexdigest(),'field':field,'maximum_original_shirt_displacement_m':max(envelope),'unchanged_original_topology_uv_weights':True,'collar_shared_junction':joined})
 if age==25:
  (D/'shirt-adult25.json').write_text(json.dumps([g],separators=(',',':')))
  # A stale shirt-clone or field-free recipe must not silently certify coverage.
  wrong=json.loads(json.dumps(s1));wrong['positions_m']=s0['positions_m'];need(wrong['positions_m']!=s1['positions_m'],'old shoulder collision retained negative geometry witness');report['negative_controls'].append('OriginalV3 positions differ; old actual skin-ray/face negative fixtures retained, not certified by vertex clearance alone')
  bad=json.loads(json.dumps(recipe));bad['workwear_tailoring']['shirt_x_ease_arm_radius_fraction']=0
  try:new.garment_shell(m,'shirt',.006,bad,bones,height)
  except ValueError:report['negative_controls'].append('Zero actual source-arm transition width refused')
  else:raise AssertionError('zero width accepted')
functions=lambda p:{n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.FunctionDef)}
a=functions(V3/'proposed/chicago/4d/tools/human_workwear_fit.py');b=functions(D/'proposed/chicago/4d/tools/human_workwear_fit.py')
for name in a:
 if name!='garment_shell':need(a[name]==b[name],'all other helper ASTs untouched '+name)
report['unchanged']='All helper functions exceptgarment_shell AST exact. V3 teamster builder/eye helper/raw0.001/13mm envelope/2mm soles/rig/identity/export/animation unchanged; no masks/new dependency.';report['PASS']=True;report['elapsed_s']=time.monotonic()-start;(D/'SOURCE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
