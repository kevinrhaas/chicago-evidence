import fs from 'node:fs';
import * as T from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js';
const dir='/workspace/shared/human-tailoring-v4-shoulder-source-diagnosis';
const [data]=JSON.parse(fs.readFileSync('/workspace/shared/human-tailoring-v3-source-design/shirt-adult25.json'));
const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(data.positions_m.flat(),3));g.setIndex(data.triangles.flat());g.computeVertexNormals();
const expanded=g.toNonIndexed(),normals=g.getAttribute('normal'),out=expanded.getAttribute('normal'),indices=g.index.array;
let maximum=0,nonFaceCornerCount=0;
const p=g.getAttribute('position'),a=new T.Vector3(),b=new T.Vector3(),c=new T.Vector3(),faceNormal=new T.Vector3(),corner=new T.Vector3();
for(let k=0;k<indices.length;k++)for(let j=0;j<3;j++)maximum=Math.max(maximum,Math.abs(normals.array[3*indices[k]+j]-out.array[3*k+j]));
for(let k=0;k<indices.length;k+=3){a.fromBufferAttribute(p,indices[k]);b.fromBufferAttribute(p,indices[k+1]);c.fromBufferAttribute(p,indices[k+2]);faceNormal.crossVectors(b.sub(a),c.sub(a)).normalize();for(let j=0;j<3;j++){corner.fromBufferAttribute(out,k+j);if(corner.distanceTo(faceNormal)>1e-4)nonFaceCornerCount++;}}
const report={scope:'Actual vendor Three BufferGeometry CPU-only reproduction of preview normal ordering, no renderer',source:'preview.html geometry computes shared-index normals BEFORE toNonIndexed, then only replaces UV attribute; no normal recomputation after expansion',originalVertices:p.count,expandedCorners:out.count,maximumNormalChangeAcrossUVExpansion:maximum,expandedCornersDifferingFromOwnFlatTriangleNormal:nonFaceCornerCount,flatNormalsCausedByUVExpansion:false,canonicalBlenderNormalParityAccepted:false,conclusion:'The suspected per-corner expansion flat-normal mismatch is disproved for this caller. Observed ripple alone does not establish source geometry fault or canonical BPy shading behavior; do not change source silhouette/UV/normal controls solely on this image.'};
fs.writeFileSync(dir+'/PREVIEW-NORMAL-ORDER-AUDIT.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));g.dispose();expanded.dispose();
