"""Bounded actual idle0 pixel-ray/source-face audit, no renderer/model generation."""
from pathlib import Path
import ast,json,struct,math,collections,sys,hashlib,time
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
D=Path(__file__).parent;ROOT=Path('/workspace/chicago/chicago/4d');V3=Path('/workspace/shared/human-tailoring-v3-source-design');GLB=Path('/workspace/shared/human-visible-next/bardwell_otis_1835.lod0.glb');raw=GLB.read_bytes();ln,_=struct.unpack_from('<II',raw,12);g=json.loads(raw[20:20+ln]);off=20+ln;blen,_=struct.unpack_from('<II',raw,off);binary=raw[off+8:off+8+blen];nodes=g['nodes'];parents={c:i for i,n in enumerate(nodes) for c in n.get('children',[])}
# Reuse only inert parsing/LBS function definitions from the independently audited
# old receipt; no top-level old audit/animation sweep or BPy is executed.
review=Path('/workspace/shared/human-workwear-v2-independent-review/review.py');tree=ast.parse(review.read_text());names={'acc','qmatrix','slerp','worlds','matrices','weights_array','deform','mesh_data'}
module=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]);exec(compile(ast.fix_missing_locations(module),str(review)+' selected inert defs','exec'))
skin=g['skins'][0];jointnames=[nodes[i]['name'] for i in skin['joints']];joint_index={n:i for i,n in enumerate(jointnames)};ib=acc(skin['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1)
a=next(x for x in g['animations'] if x['name']=='idle');overrides={}
for ch in a['channels']:
 sampler=a['samplers'][ch['sampler']];path=ch['target']['path']
 if path in ('translation','rotation','scale'):overrides[(ch['target']['node'],path)]=acc(sampler['output'])[0]
mats=matrices(overrides);BP,BF,BW=mesh_data('_body_0_');body_pos=deform(BP,BW,mats);shirt=json.loads((V3/'shirt-adult25.json').read_text())[0];SP=np.array(shirt['positions_m']);SF=np.array(shirt['triangles']);shirt_pos=deform(SP,weights_array(shirt['weights']),mats)
prepared=json.loads((ROOT/'assets/authored/humans/makehuman_hm08/prepared_adult_25.json').read_text());source=prepared['meshes'][0];PP=np.array(source['positions_m']);lookup=collections.defaultdict(set)
for sid,p in zip(source['source_vertex_indices'],PP):lookup[tuple(np.round(p,5))].add(sid)
S=[];mapping_errors=[]
# Float32 GLB coordinates can straddle rounded-grid cell boundaries. Resolve
# nearest original position within1micrometre, requiring unique source identity.
lookup=collections.defaultdict(list)
for sid,p in zip(source['source_vertex_indices'],PP):lookup[tuple(np.floor(p/1e-5).astype(int))].append((sid,p))
import itertools
for p in BP:
 cell=np.floor(p/1e-5).astype(int);candidates=[]
 for delta in itertools.product((-1,0,1),repeat=3):candidates.extend(lookup.get(tuple(cell+delta),[]))
 close=[(sid,float(np.linalg.norm(q-p))) for sid,q in candidates if np.linalg.norm(q-p)<1e-6]
 ids=set(sid for sid,error in close)
 if len(ids)!=1:raise ValueError('actual GLB vertex does not uniquely map to prepared sourceID: '+repr((p,len(ids))))
 S.append(next(iter(ids)));mapping_errors.append(min(error for sid,error in close))
fmap={tuple(sorted(source['source_vertex_indices'][i] for i in f)):fi for fi,f in enumerate(source['triangles'])};body_source_faces=[]
for f in BF:
 key=tuple(sorted(S[i] for i in f))
 if key not in fmap:raise ValueError('actual body triangle not in original prepared source')
 body_source_faces.append(fmap[key])
selected=set(x for x in shirt['source_triangle_indices'] if x is not None)
origin=np.array([.42,1.58,.62]);target=np.array([0.,1.52,.015]);forward=target-origin;forward/=np.linalg.norm(forward);right=np.cross(forward,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,forward);fov=math.tan(math.radians(32/2))
def hit(vertices,faces,direction):
 A=vertices[faces[:,0]];E=vertices[faces[:,1]]-A;F=vertices[faces[:,2]]-A;P=np.cross(direction,F);det=np.sum(E*P,axis=1);valid=np.abs(det)>1e-12;inv=np.where(valid,1/np.where(valid,det,1),0);T=origin-A;u=np.sum(T*P,axis=1)*inv;Q=np.cross(T,E);v=np.sum(direction*Q,axis=1)*inv;t=np.sum(F*Q,axis=1)*inv;valid&=(u>=0)&(v>=0)&(u+v<=1)&(t>0);ts=np.where(valid,t,np.inf);idx=int(np.argmin(ts));return None if not np.isfinite(ts[idx]) else {'triangle':idx,'distance':float(ts[idx]),'barycentric':[float(1-u[idx]-v[idx]),float(u[idx]),float(v[idx])],'position_m':(origin+ts[idx]*direction).tolist()}
img=Image.open('/workspace/shared/human-tailoring-v3-runtime-preview-2026-10-21/1280-after-neck.png').convert('RGB');samples=[]
for name,x,y in [('rightpatch',970,563),('rightpatch2',947,554),('leftpatch',407,499),('leftpatch2',392,494),('near-right-linen',987,589),('near-left-linen',400,525)]:
 direction=forward+(2*(x+.5)/1280-1)*1.6*fov*right+(1-2*(y+.5)/800)*fov*up;direction/=np.linalg.norm(direction);bh=hit(body_pos,BF,direction);sh=hit(shirt_pos,SF,direction)
 if bh:
  fi=body_source_faces[bh['triangle']];bh['prepared_source_triangle']=fi;bh['shirt_source_selected']=fi in selected;bh['original_source_ids']=[source['source_vertex_indices'][i] for i in source['triangles'][fi]];bh['original_source_positions_m']=[source['positions_m'][i] for i in source['triangles'][fi]];bh['original_source_weights']=[source['weights'][i] for i in source['triangles'][fi]]
 samples.append({'name':name,'pixel':[x,y],'RGB':img.getpixel((x,y)),'body':bh,'shirt':sh,'nearest_is_body':bool(bh and(not sh or bh['distance']<sh['distance']))})
r={'scope':'Actual savedV3 neck PNG pixel rays through actual prior CI GLB idle0 skin matrices and exact candidate source arrays. No renderer,decimation,modelgeneration or animated sweep. Source GLB face correspondence exact via prepared source IDs.','source_glb_sha256':hashlib.sha256(raw).hexdigest(),'samples':samples,'v3_shirt_original_body_faces_selected':len(selected),'body_triangles':len(BF),'all_actual_body_triangles_match_prepared_source':True,'max_float32_source_mapping_error_m':max(mapping_errors),'source_candidate_not_decimated':True,'matrix_scope':'Actual idle animation first key sampled exactly as runtime preview mixer.setTime(0); no arbitrary new pose'};(D/'ACTUAL-PIXEL-SOURCE-FACE-DIAGNOSIS-V2.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps([{'name':x['name'],'RGB':x['RGB'],'body_source':x['body']['prepared_source_triangle'] if x['body'] else None,'selected':x['body']['shirt_source_selected'] if x['body'] else None,'body_front':x['nearest_is_body'],'distance_delta_shirt_minus_body_m':(x['shirt']['distance']-x['body']['distance']) if x['shirt'] and x['body'] else None} for x in samples],indent=2))

# Compare ACTUAL same-source face clearances, not only source vertex normals.
sys.path.insert(0,str(ROOT/'tools'))
from human_source_normals import source_shared_normals
ns=source_shared_normals(source['positions_m'],source['triangles'],source['source_vertex_indices'])
normal_by_sid={sid:n for sid,n in zip(source['source_vertex_indices'],ns)}
position_by_sid={sid:p for sid,p in zip(source['source_vertex_indices'],source['positions_m'])}
body_index_by_sid={sid:i for i,sid in enumerate(S)}
alternate=SP.copy()
for i,basis in enumerate(shirt['source_basis'][:shirt['collar_extension']['original_shirt_vertex_count']]):
 if abs(alternate[i,0])>.027:alternate[i,0]-=math.copysign(.007,alternate[i,0])
altposed=deform(alternate,weights_array(shirt['weights']),mats)
records=[]
for gi,(face,sourcefi) in enumerate(zip(shirt['triangles'],shirt['source_triangle_indices'])):
 if sourcefi is None or any(len(shirt['source_basis'][i])!=1 or next(iter(shirt['source_basis'][i].values()))!=1. for i in face):continue
 sids=[int(next(iter(shirt['source_basis'][i]))) for i in face]
 bi=[body_index_by_sid[sid] for sid in sids]
 p=body_pos[bi];normal=np.cross(p[1]-p[0],p[2]-p[0]);normal/=np.linalg.norm(normal)
 original=PP[source['triangles'][sourcefi]];rn=np.cross(original[1]-original[0],original[2]-original[0]);rn/=np.linalg.norm(rn)
 posed=np.sum((shirt_pos[face]-p)*normal,axis=1);counter=np.sum((altposed[face]-p)*normal,axis=1)
 restbody=np.array([position_by_sid[sid] for sid in sids]);rest=np.sum((SP[face]-restbody)*rn,axis=1)
 records.append({'source_face':sourcefi,'shirt_triangle':gi,'source_ids':sids,'rest_face_minimum_normal_clearance_m':float(min(rest)),'actual_idle0_face_minimum_normal_clearance_m':float(min(posed)),'actual_idle0_face_vertex_clearances_m':posed.tolist(),'counterfactual_remove_only_shirt_globalX_face_minimum_m':float(min(counter)),'source_positions_m':restbody.tolist()})
negative=[x for x in records if x['actual_idle0_face_minimum_normal_clearance_m']<0];negative.sort(key=lambda x:x['actual_idle0_face_minimum_normal_clearance_m'])
targets=set(x['body']['prepared_source_triangle'] for x in samples if x['body'] and x['nearest_is_body']);rr={'scope':'Finite same-source complete original triangle-plane normal projection at actual idle0; not minimum distance/collision or complete clips. Counterfactual only, no source patch written.','original_source_faces_tested':len(records),'actual_idle0_negative_face_count':len(negative),'actual_idle0_minimum_face_vertex_normal_projection_m':min(x['actual_idle0_face_minimum_normal_clearance_m'] for x in records),'counterfactual_negative_face_count':sum(x['counterfactual_remove_only_shirt_globalX_face_minimum_m']<0 for x in records),'counterfactual_minimum_face_vertex_normal_projection_m':min(x['counterfactual_remove_only_shirt_globalX_face_minimum_m'] for x in records),'visible_patch_source_faces':sorted(targets),'visible_patch_face_records':[x for x in records if x['source_face'] in targets],'negative_fixture':negative,'source_or_app_edited':False};(D/'ACTUAL-TRIANGLE-CLEARANCE-COUNTERFACTUAL.json').write_text(json.dumps(rr,indent=2)+'\n');print(json.dumps({k:v for k,v in rr.items() if k!='negative_fixture'},indent=2))

oldbad={x['source_face'] for x in negative};newbad={x['source_face'] for x in records if x['counterfactual_remove_only_shirt_globalX_face_minimum_m']<0};raycontrols=[]
for sample in samples:
 if not sample['body'] or not sample['nearest_is_body']:continue
 x,y=sample['pixel'];direction=forward+(2*(x+.5)/1280-1)*1.6*fov*right+(1-2*(y+.5)/800)*fov*up;direction/=np.linalg.norm(direction);alt_hit=hit(altposed,SF,direction)
 raycontrols.append({'pixel':[x,y],'actual_source_face':sample['body']['prepared_source_triangle'],'old_body_first':True,'old_shirt_minus_body_ray_distance_m':sample['shirt']['distance']-sample['body']['distance'],'counterfactual_shirt_minus_body_ray_distance_m':alt_hit['distance']-sample['body']['distance'],'counterfactual_body_first':alt_hit['distance']>sample['body']['distance']})
control={'scope':'Controlled source-array counterfactual ONLY; no helper/app edit/render/build. Exact old source face/rays retained as regression.','visible_skin_ray_controls':raycontrols,'old_negative_complete_original_face_count':len(oldbad),'counterfactual_negative_complete_original_face_count':len(newbad),'new_negative_source_faces':sorted(newbad-oldbad),'resolved_negative_source_faces':sorted(oldbad-newbad),'remaining_negative_source_faces':sorted(oldbad&newbad),'rest_face_controls':[x for x in records if x['source_face'] in targets],'guards_or_ease_amount_changed':False,'counterfactual_changes':'Only remove inherited shirt globalX7mm in memory; retain source6mm normal offset/Y neck clipping/original weights. Waistcoat untouched. Collar extension would need regeneration from actual changed shirt boundary before source integration.','limitation':'40remaining same-source negative triangle projections show complete shirt collision/animated fit is still unqualified; no new negative in this tested set is a scoped comparison, not whole cloth acceptance.'};(D/'CONTROLLED-SHIRT-X-TEST.json').write_text(json.dumps(control,indent=2)+'\n');print(json.dumps({k:v for k,v in control.items() if k not in ('resolved_negative_source_faces','remaining_negative_source_faces','rest_face_controls')},indent=2))

# Finite feasibility of ONE coherent inherited-X factor, retaining every tested
# previously positive original triangle; not a proposed threshold relaxation.
lo,hi=0.,1.;lower_witness=None;upper_witness=None
for row in records:
 gi=row['shirt_triangle'];face=SF[gi];sids=row['source_ids'];bi=[body_index_by_sid[sid] for sid in sids];p=body_pos[bi];normal=np.cross(p[1]-p[0],p[2]-p[0]);normal/=np.linalg.norm(normal);c0=np.sum((altposed[face]-p)*normal,axis=1);c1=np.sum((shirt_pos[face]-p)*normal,axis=1)
 for lane,(a,b) in enumerate(zip(c0,c1)):
  if row['actual_idle0_face_minimum_normal_clearance_m']>=0 or row['source_face'] in targets:
   slope=b-a
   if abs(slope)<1e-15:
    if a<0:lo,hi=1.,0.
   elif slope>0:
    bound=-a/slope
    if bound>lo:lo=float(bound);lower_witness={'source_face':row['source_face'],'lane':lane,'clearance_withoutX_m':float(a),'clearance_withX_m':float(b)}
   else:
    bound=-a/slope
    if bound<hi:hi=float(bound);upper_witness={'source_face':row['source_face'],'lane':lane,'clearance_withoutX_m':float(a),'clearance_withX_m':float(b)}
feas={'scope':'One scalarshirt globalX factor in[0,1], preserving actual idle0 old-positive complete source face halfspaces and requiring both actual observed patch faces positive. Source only, no adoption.','feasible_lower_factor':lo,'feasible_upper_factor':hi,'feasible':lo<=hi,'lower_constraint':lower_witness,'upper_constraint':upper_witness,'new_negative_faces_withoutX_centroids':[]}
for fi in sorted(newbad-oldbad):
 f=source['triangles'][fi];pos=np.array([source['positions_m'][i] for i in f]);feas['new_negative_faces_withoutX_centroids'].append({'source_face':fi,'centroid_m':pos.mean(axis=0).tolist()})
(D/'COHERENT-X-FACTOR-FEASIBILITY.json').write_text(json.dumps(feas,indent=2)+'\n');print(json.dumps(feas,indent=2))

# One bounded anatomical ease-field counterstudy; no source correction adopted.
# It never adds padding: each X displacement lies between existing0 and7mm.
axis=next(b['head_m'][1] for b in prepared['skeleton'] if b['name']=='upperarm_l');dominant=[p for p,w in zip(PP,source['weights']) if w.get('upperarm_l',0)>.5];radius=max(abs(p[1]-axis) for p in dominant);fieldruns=[]
for radius_fraction in (.25,.5,.75,1.):
 width=radius*radius_fraction;candidate=SP.copy()
 for i,basis in enumerate(shirt['source_basis'][:shirt['collar_extension']['original_shirt_vertex_count']]):
  original_y=math.fsum(float(v)*position_by_sid[int(sid)][1] for sid,v in basis.items());factor=max(0.,min(1.,(axis-original_y)/width))
  if abs(candidate[i,0])>.027:candidate[i,0]-=(1-factor)*math.copysign(.007,candidate[i,0])
 posed=deform(candidate,weights_array(shirt['weights']),mats);bad=[];patchrecords=[]
 for row in records:
  face=SF[row['shirt_triangle']];p=body_pos[[body_index_by_sid[sid] for sid in row['source_ids']]];normal=np.cross(p[1]-p[0],p[2]-p[0]);normal/=np.linalg.norm(normal);margin=float(min(np.sum((posed[face]-p)*normal,axis=1)))
  if margin<0:bad.append(row['source_face'])
  if row['source_face'] in targets:patchrecords.append({'face':row['source_face'],'minimum_actual_idle0_face_projection_m':margin})
 rays=[]
 for sample in samples:
  if not sample['body'] or not sample['nearest_is_body']:continue
  x,y=sample['pixel'];direction=forward+(2*(x+.5)/1280-1)*1.6*fov*right+(1-2*(y+.5)/800)*fov*up;direction/=np.linalg.norm(direction);h=hit(posed,SF,direction);rays.append({'pixel':[x,y],'shirt_minus_body_ray_distance_m':h['distance']-sample['body']['distance']})
 fieldruns.append({'radius_fraction':radius_fraction,'transition_width_m':width,'old_negative_face_count':len(oldbad),'candidate_negative_face_count':len(bad),'new_negative_faces':sorted(set(bad)-oldbad),'patch_face_controls':patchrecords,'patch_ray_controls':rays})
(D/'ANATOMICAL-EASE-FIELD-COUNTERSTUDY.json').write_text(json.dumps({'scope':'Finite4candidate actual source array counterstudy, not an adopted source patch/render or garment collision acceptance','source_upperarm_axis_y_m':axis,'actual_upperarm_dominant_vertex_max_radial_y_m':float(radius),'field':'globalX factor=clamp((upperarm_axisY-sourcepointY)/transition_width,0,1), same on both sides; no original offset magnitude increased and original6mm source normal retained. Width fractions of actual cleared arm radialextent, engineering reconstruction choices.','candidates':fieldruns},indent=2)+'\n');print(json.dumps(fieldruns,indent=2))
