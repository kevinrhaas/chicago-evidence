# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent saved-array checks; no renderer or application mutation."""
from pathlib import Path
import json,struct,hashlib,math,sys
P=Path(__file__).resolve().parent.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):
 b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];return json.loads(b[20:20+n]),b[28+n:]
def arr(g,b,i):
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];w={'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];flat=struct.unpack_from('<'+'f'*(a['count']*w),b,v.get('byteOffset',0)+a.get('byteOffset',0));return [flat[j:j+w] for j in range(0,len(flat),w)]
auditRaw=(P/'inputs/covered-variation-inventory.json').read_bytes();audit=json.loads(auditRaw)
parent,bin=load(P/'inputs/2aebef95/chicago/4d/renderers/web/transport/parked-wagon/wagon-w01.glb');cfg=json.loads((P/'source/parameters.json').read_text());results=[]
for variant in cfg['variants']:
 name=variant['asset_id'];one=P/'candidate-v1-run1'/name;two=P/'candidate-v1-run2'/name;raw=(one/'covered-w01.glb').read_bytes();g,b=load(one/'covered-w01.glb');checks={}
 checks['repeatGLBExact']=raw==(two/'covered-w01.glb').read_bytes();checks['repeatSidecarExact']=(one/'covered-w01.json').read_bytes()==(two/'covered-w01.json').read_bytes();checks['parentBINprefixExact']=b[:len(bin)]==bin
 old={m['name']:m for m in parent['meshes']};new={m['name']:m for m in g['meshes']};gear=[n for n in old if not n.startswith('vehicle_body_')]
 checks['allGearPositionNormalUvTangentAccessorsExact']=all(new[n]['primitives'][0]['attributes']==old[n]['primitives'][0]['attributes'] for n in gear)
 checks['gearStreamBytesExact']=all(arr(g,b,a)==arr(parent,bin,i) for n in gear for key,i in old[n]['primitives'][0]['attributes'].items() for a in [new[n]['primitives'][0]['attributes'][key]])
 checks['nodeTransformsExact']=all(all(g['nodes'][i].get(k)==node.get(k) for k in ['translation','rotation','scale','matrix']) for i,node in enumerate(parent['nodes']))
 unsupported=g['extras']['covered_derivative']['unsupported_inherited_sockets'];checks['allInheritedOccupantHitchCollisionInterfacesExplicitlyUnsupported']=bool(unsupported) and all(node.get('extras',{}).get('covered_empty_interface_supported') is False for node in g['nodes'] if node['name'] in unsupported)
 expected={n['name'] for n in parent['nodes'] if n['name'].startswith(('vehicle_seat_','vehicle_driver_foot_','vehicle_board_','vehicle_camera_','vehicle_hitch_','vehicle_collision'))};checks['unsupportedInterfaceSetExact']=set(unsupported)==expected
 side=json.loads((one/'covered-w01.json').read_text());original=next(row for row in audit['allCovered'] if row['id']==variant['id']);checks['frozenAuditHashExact']=sha(auditRaw)==cfg['variant_audit_sha256'];checks['sourceSeedAndCoatExact']=side['seeded_coat']==original['coat'];checks['exactOldPlaceBearingAndYoke']=side['original_coordinates']==original['at_local_enu_m'] and side['original_bearing_deg']==original['bearing_deg'] and g['extras']['covered_derivative']['yoke']==original['yoke']
 removed=side['retiredOnlySourceOwnedFurniture'];checks['onlyOwnedFurnitureRetired']=bool(removed) and all(p['part'].startswith(('driver_bench_','driver_footboard')) for p in removed);checks['furnitureOnlyBatchRetired']=side['retiredSourceOwnedFurnitureMeshIndices']==[22] and 'vehicle_body_timber' not in new
 minima={'twiceTriangleArea':float('inf'),'faceNormalDot':float('inf'),'normalUnitError':0,'tangentDotNormal':0}
 for name2,m in new.items():
  if name2 in old:continue
  q=m['primitives'][0];pos=arr(g,b,q['attributes']['POSITION']);norm=arr(g,b,q['attributes']['NORMAL']);tan=arr(g,b,q['attributes']['TANGENT'])
  for n,t in zip(norm,tan):minima['normalUnitError']=max(minima['normalUnitError'],abs(sum(v*v for v in n)-1));minima['tangentDotNormal']=max(minima['tangentDotNormal'],abs(sum(n[k]*t[k] for k in range(3))))
  for i in range(0,len(pos),3):
   u=[pos[i+1][k]-pos[i][k] for k in range(3)];v=[pos[i+2][k]-pos[i][k] for k in range(3)];c=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];area=math.sqrt(sum(x*x for x in c));dn=sum(c[k]*sum(norm[i+j][k] for j in range(3))/3 for k in range(3))/area if area else -1;minima['twiceTriangleArea']=min(minima['twiceTriangleArea'],area);minima['faceNormalDot']=min(minima['faceNormalDot'],dn)
 checks['newTrianglesNondegenerate']=minima['twiceTriangleArea']>1e-10;checks['newFacesAgreeWithNormals']=minima['faceNormalDot']>0;checks['newNormalsAndTangentsValid']=minima['normalUnitError']<1e-5 and minima['tangentDotNormal']<1e-5
 canopy=arr(g,b,new['covered_original_canvas_sheet']['primitives'][0]['attributes']['POSITION']);bounds={'min':[min(v[k] for v in canopy) for k in range(3)],'max':[max(v[k] for v in canopy) for k in range(3)]};checks['existingCanvasEnvelopeRetained']=abs(bounds['max'][0]-.535)<1e-6 and abs(bounds['min'][0]+.535)<1e-6 and abs(bounds['max'][1]-2.6)<1e-6 and abs(bounds['max'][2]-1.645)<1e-6 and abs(bounds['min'][2]+1.645)<1e-6
 checks['laidByYokePresent']=('covered_preserved_laid_by_yoke' in new)==variant['yoke'];results.append({'asset_id':name,'sha256':sha(raw),'checks':checks,'minima':minima,'canvasBounds':bounds,'retiredPartCount':len(removed),'pass':all(checks.values())})
receipt={'scope':'Independent deterministic saved-array/ownership/interface/normal controls; not appearance or terrain qualification','variants':results,'pass':all(r['pass'] for r in results)};(P/'candidate-v1-run1/CONTROLS.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));sys.exit(0 if receipt['pass'] else 1)
