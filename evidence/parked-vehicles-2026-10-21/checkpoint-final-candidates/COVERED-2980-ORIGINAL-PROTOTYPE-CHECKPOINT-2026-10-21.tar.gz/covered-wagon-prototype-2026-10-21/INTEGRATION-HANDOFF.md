# T-2980 covered-wagon prototype handoff

This is an outside-app original EMPTY reconstruction, ready for peer review and a bounded next decision. It is not an installed replacement or a photographic-quality completion. No maker, owner, historical load or Dearborn identity is claimed. Geometry/source are GPL-3.0-or-later; inherited and new analytic pixels retain their original CC0 terms. No third-party images were imported.

## Recoverable inputs and outputs

`inputs/SOURCE-MANIFEST.json` pins selected immutable inputs from committed app `2aebef95f6a5b6fa1bd8353db936c7674a73c32f`. These are exported files, not another checkout. The current shared app branch may differ. Do not copy them over the app blindly.

`source/build_covered.py` and `source/parameters.json` produce exactly two variants. Their full hashes, sidecars, axes, units and wheel contacts are in `ASSET-INDEX.json`. Reviewed parent GLB is `274e737b51872983df792d0b24de8e75de8631890a8d586a32d9c6f0066484fb`. Source-owned donor furniture is identified by a canonical rebuilt hardware map, `parent-authored-map/authored-parts.json`; the producer refuses a different parent or map before creating output. Original parent producer chain and materials are included under `inputs/2aebef95/chicago/4d`. The actual full-source reproduction log reports the expected parent hash; `verified:false` means generator build mode, not a failed hash check.

`candidate-v1-run1` includes the two authoritative GLBs, sidecars, original cloth PNGs and actual Khronos, independent-array and corrupt-input control reports. A second generation actually ran and matched both GLBs/sidecars byte-for-byte. `RUN2-SHA256.json` retains its hashes; duplicate run2 binaries are omitted from the compact capsule. `actual-v1` preserves all 14 baseline PNGs and receipt. Both shadow-control attempts are preserved separately. The corrected shadow-off image is a diagnostic, not a proposed production lighting change.

## Preserve the deliberate variation

The frozen sibling `covered-wagon-variation-audit-2026-10-21` inventory identifies 86 declared indexed vehicle records: 80 town_trade_goods, one water cart and five trade-yard vehicles. Eighteen are covered. These counts describe source rows, not actual draw counts. Legacy covered rows share geometry but differ in original-ID/exact-coordinate seeded paint/wood/canvas age, board shades, grain, context and optional laid-by yoke.

Selected originals are `town_wagon_western_hotel_wagon_yard_1` at E−136.05/N−291 and `town_wagon_wolf_point_tavern_yard_1` at E−90.5/N−39.5, both bearing 356.2 degrees. Exact original seed strings and coat factors are retained in sidecars and frozen audit. Do not derive replacement seeds from new asset IDs, rounded coordinates or array indices. Both original laid-by yokes are included in the new GLBs at their old canonical relative location. Other covered rows, especially the no-yoke shed wagon, must retain their own identities rather than inheriting one of these variants.

The new canopy preserves the old 3.29 m length, 1.07 m width and 2.60 m crown above the vehicle base. Five restrained original bows, subtle inter-bow sag, long seams, hems and analytic weave are reconstruction. New dimensional and cloth construction details are not an attested measured artifact. The 1.18 m donor bench and its footboard were explicitly retired from this empty derivative only; original W01 gear/source remain untouched. Inherited seat, foot, hitch, boarding, collision and ride-camera sockets are explicitly disabled metadata. Do not expose a driver or ride interface through them.

## Minimal safe app interface, when separately authorized

Use an explicit small `replaces` list of original IDs at exact old coordinates/bearings and keep original host/confidence/provenance. Current parked loader supports explicit model files and optional support files, not a general per-record coat field. Explicit variant files avoid mutating materials shared by `asset.scene.clone(true)`. Do not replace every wagon or modify the common yard coat generator.

The existing fallback chunk includes the complete original wagon and laid-by yoke. Hiding that chunk without preserving the yoke would regress the scene. These two models include their own yoke; a future no-yoke row must stay no-yoke. Preserve legacy visibility for Light, far distance and failed/refused GLBs, along with picking, cards, disposal and source authority. Use the existing four finite wheel-contact samples and 30 mm maximum span guard; old center-only yard placement is not new terrain qualification. The parked tongue articulation must follow its supported settling logic, not a baked arbitrary pose. No full animation or occupied behavior follows from a static parked derivative.

Actual qualification still required: exact current-terrain four-wheel/yoke/body clearance for each candidate, old/new covered comparisons in source and published main at desktop/mobile, production shadows, popup/picking/fallback controls, canonical driver budgets via `api.stats()`, source/publish mirrored pins, production checks and current CI. Default mobile Light intentionally keeps fallback; gallery mobile views do not qualify default production quality. Main shadow aliasing must be checked with actual app lighting. Do not fix a model-study shadow artifact through global lighting changes.

## Cost and verified scope

Each model: 17,292 triangles, 26 raw primitives, nine referenced material groups. Whole gallery render including shadow/floor: 53 renderer calls and 34,586 rendered triangles; the pair: 105 calls and 69,170 triangles. This is not static-batched production cost.

Per variant texture estimate uses RGBA8 bytes and 4/3 mip allowance: three 2048×128 maps = 4 MiB; three 1024×64 maps = 1 MiB; three 256×256 maps = 1 MiB; three new 512×256 cloth maps = 2 MiB. Total 8,388,608 bytes = 8 MiB. Pair estimate is 16 MiB if separately loaded; no speculative cross-GLB texture deduplication is credited. GLB transfer bytes are separately listed in ASSET-INDEX.json.

Actual controls: zero Khronos errors/warnings; 36 independent saved-array checks; two actual pre-output corruption refusals; repeat generation; 14 baseline screenshots; corrected two-frame shadow-on/off diagnostic. Protected gear streams and all inherited node transforms are exact. No Blender, network fetch, app write, main boot, fleet/LOD bake or photographic closure occurred.

## Reproduction

Use Python 3 with Pillow, one math thread, and a fresh output path. From this prototype directory:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /workspace/shared/chicago-venv/bin/python source/build_covered.py --parent inputs/2aebef95/chicago/4d/renderers/web/transport/parked-wagon/wagon-w01.glb --authored-parts parent-authored-map/authored-parts.json --parameters source/parameters.json --output candidate-v1-run2
```

The capsule omits run2 binaries so that path is fresh on extraction. Then `python source/controls.py` reruns the saved-array/repeat checks against retained run1. The actual Khronos caller is `source/validate.cjs`; it uses the existing validator installation. The full model fixture is `source/capture.cjs`; it uses the current app's Three vendor files and installed local Playwright/Chromium. Browser scripts need a free coordinated lane and authorized subprocess execution, and their fresh output directories must not already exist. Do not rerun captures during a four-worker app gate.

Use `CAPSULE-MANIFEST.json` to verify included bytes. Existing run1, baseline pixels and failed/ineffective controls should remain immutable as reference evidence.
