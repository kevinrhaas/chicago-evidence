# Canonical human success capsule

Actual run **39687040336**, attempt **1**, SHA **2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3**. Both required jobs and all mandatory steps succeeded. Mechanical qualification passed.

Root viewed only the three images marked **ROOT VIEWED** below. Its assessment: coverage, shoes and eyes exported; garments remain tight/crude and need period drape/closure; face, hair and skin remain short of photographic quality. Other included images are preserved for later review and have not been visually accepted. No scene figure or occupied acceptance; T1789 remains OPEN.

This capsule contains selected original data/images, qualification and job proof, dispatch/source binding, all24 sole metric summaries, safe extraction manifest, the full upstream artifact file/hash index, and fresh actual attempt logs. It omits the large canonical artifact ZIP, GLBs and Blender files. No downloaded code was executed. Raw24 sole receipts remain downloadable in the exact full artifact identified by MANIFEST.json.

The canonical run is terminal. No branch write was made by this recovery. Any later human-ref movement needs authoring input continuity checks against the exact-head runtime source pins; historical canonical success does not qualify later modified input bytes.

Full API download metadata and ZIP SHA256 are recorded in MANIFEST.json. API access requires repository authorization. Source normal0.001m and sole0.002m guards remain unchanged.

## Selected actual same-run images

- [images/source/bardwell_otis_1835.lod0-desktop-standing-front.png](images/source/bardwell_otis_1835.lod0-desktop-standing-front.png) — unreviewed
- [images/source/bardwell_otis_1835.lod0-desktop-standing-profile.png](images/source/bardwell_otis_1835.lod0-desktop-standing-profile.png) — unreviewed
- [images/source/bardwell_otis_1835.lod0-desktop-standing-threequarter.png](images/source/bardwell_otis_1835.lod0-desktop-standing-threequarter.png) — unreviewed
- [images/source/bardwell_otis_1835.lod0-desktop-close-front.png](images/source/bardwell_otis_1835.lod0-desktop-close-front.png) — unreviewed
- [images/source/bardwell_otis_1835.lod0-desktop-close-profile.png](images/source/bardwell_otis_1835.lod0-desktop-close-profile.png) — unreviewed
- [images/source/bardwell_otis_1835.lod0-desktop-close-threequarter.png](images/source/bardwell_otis_1835.lod0-desktop-close-threequarter.png) — unreviewed
- [images/web/bardwell_otis_1835.lod0-desktop-standing-front.png](images/web/bardwell_otis_1835.lod0-desktop-standing-front.png) — unreviewed
- [images/web/bardwell_otis_1835.lod0-desktop-standing-profile.png](images/web/bardwell_otis_1835.lod0-desktop-standing-profile.png) — unreviewed
- [images/web/bardwell_otis_1835.lod0-desktop-standing-threequarter.png](images/web/bardwell_otis_1835.lod0-desktop-standing-threequarter.png) — ROOT VIEWED
- [images/web/bardwell_otis_1835.lod0-desktop-close-front.png](images/web/bardwell_otis_1835.lod0-desktop-close-front.png) — ROOT VIEWED
- [images/web/bardwell_otis_1835.lod0-desktop-close-profile.png](images/web/bardwell_otis_1835.lod0-desktop-close-profile.png) — unreviewed
- [images/web/bardwell_otis_1835.lod0-desktop-close-threequarter.png](images/web/bardwell_otis_1835.lod0-desktop-close-threequarter.png) — unreviewed
- [images/seated-driver/bardwell_otis_1835-1280-front.png](images/seated-driver/bardwell_otis_1835-1280-front.png) — unreviewed
- [images/seated-driver/bardwell_otis_1835-1280-side.png](images/seated-driver/bardwell_otis_1835-1280-side.png) — unreviewed
- [images/seated-driver/bardwell_otis_1835-1280-threequarter.png](images/seated-driver/bardwell_otis_1835-1280-threequarter.png) — ROOT VIEWED
- [images/source/dufresne_joseph_1835.lod0-desktop-standing-front.png](images/source/dufresne_joseph_1835.lod0-desktop-standing-front.png) — unreviewed
- [images/source/dufresne_joseph_1835.lod0-desktop-standing-profile.png](images/source/dufresne_joseph_1835.lod0-desktop-standing-profile.png) — unreviewed
- [images/source/dufresne_joseph_1835.lod0-desktop-standing-threequarter.png](images/source/dufresne_joseph_1835.lod0-desktop-standing-threequarter.png) — unreviewed
- [images/source/dufresne_joseph_1835.lod0-desktop-close-front.png](images/source/dufresne_joseph_1835.lod0-desktop-close-front.png) — unreviewed
- [images/source/dufresne_joseph_1835.lod0-desktop-close-profile.png](images/source/dufresne_joseph_1835.lod0-desktop-close-profile.png) — unreviewed
- [images/source/dufresne_joseph_1835.lod0-desktop-close-threequarter.png](images/source/dufresne_joseph_1835.lod0-desktop-close-threequarter.png) — unreviewed
- [images/web/dufresne_joseph_1835.lod0-desktop-standing-front.png](images/web/dufresne_joseph_1835.lod0-desktop-standing-front.png) — unreviewed
- [images/web/dufresne_joseph_1835.lod0-desktop-standing-profile.png](images/web/dufresne_joseph_1835.lod0-desktop-standing-profile.png) — unreviewed
- [images/web/dufresne_joseph_1835.lod0-desktop-standing-threequarter.png](images/web/dufresne_joseph_1835.lod0-desktop-standing-threequarter.png) — unreviewed
- [images/web/dufresne_joseph_1835.lod0-desktop-close-front.png](images/web/dufresne_joseph_1835.lod0-desktop-close-front.png) — unreviewed
- [images/web/dufresne_joseph_1835.lod0-desktop-close-profile.png](images/web/dufresne_joseph_1835.lod0-desktop-close-profile.png) — unreviewed
- [images/web/dufresne_joseph_1835.lod0-desktop-close-threequarter.png](images/web/dufresne_joseph_1835.lod0-desktop-close-threequarter.png) — unreviewed
- [images/seated-driver/dufresne_joseph_1835-1280-front.png](images/seated-driver/dufresne_joseph_1835-1280-front.png) — unreviewed
- [images/seated-driver/dufresne_joseph_1835-1280-side.png](images/seated-driver/dufresne_joseph_1835-1280-side.png) — unreviewed
- [images/seated-driver/dufresne_joseph_1835-1280-threequarter.png](images/seated-driver/dufresne_joseph_1835-1280-threequarter.png) — unreviewed
- [images/source/flynn_martin_1835.lod0-desktop-standing-front.png](images/source/flynn_martin_1835.lod0-desktop-standing-front.png) — unreviewed
- [images/source/flynn_martin_1835.lod0-desktop-standing-profile.png](images/source/flynn_martin_1835.lod0-desktop-standing-profile.png) — unreviewed
- [images/source/flynn_martin_1835.lod0-desktop-standing-threequarter.png](images/source/flynn_martin_1835.lod0-desktop-standing-threequarter.png) — unreviewed
- [images/source/flynn_martin_1835.lod0-desktop-close-front.png](images/source/flynn_martin_1835.lod0-desktop-close-front.png) — unreviewed
- [images/source/flynn_martin_1835.lod0-desktop-close-profile.png](images/source/flynn_martin_1835.lod0-desktop-close-profile.png) — unreviewed
- [images/source/flynn_martin_1835.lod0-desktop-close-threequarter.png](images/source/flynn_martin_1835.lod0-desktop-close-threequarter.png) — unreviewed
- [images/web/flynn_martin_1835.lod0-desktop-standing-front.png](images/web/flynn_martin_1835.lod0-desktop-standing-front.png) — unreviewed
- [images/web/flynn_martin_1835.lod0-desktop-standing-profile.png](images/web/flynn_martin_1835.lod0-desktop-standing-profile.png) — unreviewed
- [images/web/flynn_martin_1835.lod0-desktop-standing-threequarter.png](images/web/flynn_martin_1835.lod0-desktop-standing-threequarter.png) — unreviewed
- [images/web/flynn_martin_1835.lod0-desktop-close-front.png](images/web/flynn_martin_1835.lod0-desktop-close-front.png) — unreviewed
- [images/web/flynn_martin_1835.lod0-desktop-close-profile.png](images/web/flynn_martin_1835.lod0-desktop-close-profile.png) — unreviewed
- [images/web/flynn_martin_1835.lod0-desktop-close-threequarter.png](images/web/flynn_martin_1835.lod0-desktop-close-threequarter.png) — unreviewed
- [images/seated-driver/flynn_martin_1835-1280-front.png](images/seated-driver/flynn_martin_1835-1280-front.png) — unreviewed
- [images/seated-driver/flynn_martin_1835-1280-side.png](images/seated-driver/flynn_martin_1835-1280-side.png) — unreviewed
- [images/seated-driver/flynn_martin_1835-1280-threequarter.png](images/seated-driver/flynn_martin_1835-1280-threequarter.png) — unreviewed
- [images/wagon-driver-source/1280-bench.png](images/wagon-driver-source/1280-bench.png) — unreviewed
- [images/wagon-driver-source/1280-rear.png](images/wagon-driver-source/1280-rear.png) — unreviewed
- [images/wagon-driver-source/1280-side.png](images/wagon-driver-source/1280-side.png) — unreviewed
- [images/wagon-driver-source/1280-threequarter.png](images/wagon-driver-source/1280-threequarter.png) — unreviewed
- [images/wagon-driver-published/1280-bench.png](images/wagon-driver-published/1280-bench.png) — unreviewed
- [images/wagon-driver-published/1280-rear.png](images/wagon-driver-published/1280-rear.png) — unreviewed
- [images/wagon-driver-published/1280-side.png](images/wagon-driver-published/1280-side.png) — unreviewed
- [images/wagon-driver-published/1280-threequarter.png](images/wagon-driver-published/1280-threequarter.png) — unreviewed
