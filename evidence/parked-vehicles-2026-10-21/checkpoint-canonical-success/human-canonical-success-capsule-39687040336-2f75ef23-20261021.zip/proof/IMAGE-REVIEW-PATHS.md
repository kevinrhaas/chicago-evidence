# Same-run human CI image review paths

Run39687040336; SHA2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3. Mechanical evidence passed; photographic/tailoring/world acceptance remains open.

## web

- [bardwell_otis_1835 standing-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/bardwell_otis_1835.lod0-desktop-standing-front.png)
- [bardwell_otis_1835 standing-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/bardwell_otis_1835.lod0-desktop-standing-profile.png)
- [bardwell_otis_1835 standing-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/bardwell_otis_1835.lod0-desktop-standing-threequarter.png)
- [bardwell_otis_1835 close-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/bardwell_otis_1835.lod0-desktop-close-front.png)
- [bardwell_otis_1835 close-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/bardwell_otis_1835.lod0-desktop-close-profile.png)
- [bardwell_otis_1835 close-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/bardwell_otis_1835.lod0-desktop-close-threequarter.png)
- [dufresne_joseph_1835 standing-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/dufresne_joseph_1835.lod0-desktop-standing-front.png)
- [dufresne_joseph_1835 standing-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/dufresne_joseph_1835.lod0-desktop-standing-profile.png)
- [dufresne_joseph_1835 standing-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/dufresne_joseph_1835.lod0-desktop-standing-threequarter.png)
- [dufresne_joseph_1835 close-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/dufresne_joseph_1835.lod0-desktop-close-front.png)
- [dufresne_joseph_1835 close-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/dufresne_joseph_1835.lod0-desktop-close-profile.png)
- [dufresne_joseph_1835 close-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/dufresne_joseph_1835.lod0-desktop-close-threequarter.png)
- [flynn_martin_1835 standing-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/flynn_martin_1835.lod0-desktop-standing-front.png)
- [flynn_martin_1835 standing-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/flynn_martin_1835.lod0-desktop-standing-profile.png)
- [flynn_martin_1835 standing-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/flynn_martin_1835.lod0-desktop-standing-threequarter.png)
- [flynn_martin_1835 close-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/flynn_martin_1835.lod0-desktop-close-front.png)
- [flynn_martin_1835 close-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/flynn_martin_1835.lod0-desktop-close-profile.png)
- [flynn_martin_1835 close-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/web/flynn_martin_1835.lod0-desktop-close-threequarter.png)

## source

- [bardwell_otis_1835 standing-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/bardwell_otis_1835.lod0-desktop-standing-front.png)
- [bardwell_otis_1835 standing-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/bardwell_otis_1835.lod0-desktop-standing-profile.png)
- [bardwell_otis_1835 standing-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/bardwell_otis_1835.lod0-desktop-standing-threequarter.png)
- [bardwell_otis_1835 close-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/bardwell_otis_1835.lod0-desktop-close-front.png)
- [bardwell_otis_1835 close-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/bardwell_otis_1835.lod0-desktop-close-profile.png)
- [bardwell_otis_1835 close-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/bardwell_otis_1835.lod0-desktop-close-threequarter.png)
- [dufresne_joseph_1835 standing-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/dufresne_joseph_1835.lod0-desktop-standing-front.png)
- [dufresne_joseph_1835 standing-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/dufresne_joseph_1835.lod0-desktop-standing-profile.png)
- [dufresne_joseph_1835 standing-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/dufresne_joseph_1835.lod0-desktop-standing-threequarter.png)
- [dufresne_joseph_1835 close-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/dufresne_joseph_1835.lod0-desktop-close-front.png)
- [dufresne_joseph_1835 close-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/dufresne_joseph_1835.lod0-desktop-close-profile.png)
- [dufresne_joseph_1835 close-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/dufresne_joseph_1835.lod0-desktop-close-threequarter.png)
- [flynn_martin_1835 standing-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/flynn_martin_1835.lod0-desktop-standing-front.png)
- [flynn_martin_1835 standing-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/flynn_martin_1835.lod0-desktop-standing-profile.png)
- [flynn_martin_1835 standing-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/flynn_martin_1835.lod0-desktop-standing-threequarter.png)
- [flynn_martin_1835 close-front](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/flynn_martin_1835.lod0-desktop-close-front.png)
- [flynn_martin_1835 close-profile](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/flynn_martin_1835.lod0-desktop-close-profile.png)
- [flynn_martin_1835 close-threequarter](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/source/flynn_martin_1835.lod0-desktop-close-threequarter.png)

## seated-driver

- [bardwell_otis_1835-1280-front.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/seated-driver/bardwell_otis_1835-1280-front.png)
- [bardwell_otis_1835-1280-side.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/seated-driver/bardwell_otis_1835-1280-side.png)
- [bardwell_otis_1835-1280-threequarter.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/seated-driver/bardwell_otis_1835-1280-threequarter.png)
- [dufresne_joseph_1835-1280-front.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/seated-driver/dufresne_joseph_1835-1280-front.png)
- [dufresne_joseph_1835-1280-side.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/seated-driver/dufresne_joseph_1835-1280-side.png)
- [dufresne_joseph_1835-1280-threequarter.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/seated-driver/dufresne_joseph_1835-1280-threequarter.png)
- [flynn_martin_1835-1280-front.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/seated-driver/flynn_martin_1835-1280-front.png)
- [flynn_martin_1835-1280-side.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/seated-driver/flynn_martin_1835-1280-side.png)
- [flynn_martin_1835-1280-threequarter.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/seated-driver/flynn_martin_1835-1280-threequarter.png)

## wagon-driver-source

- [1280-bench.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/wagon-driver-source/1280-bench.png)
- [1280-rear.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/wagon-driver-source/1280-rear.png)
- [1280-side.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/wagon-driver-source/1280-side.png)
- [1280-threequarter.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/wagon-driver-source/1280-threequarter.png)

## wagon-driver-published

- [1280-bench.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/wagon-driver-published/1280-bench.png)
- [1280-rear.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/wagon-driver-published/1280-rear.png)
- [1280-side.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/wagon-driver-published/1280-side.png)
- [1280-threequarter.png](/workspace/shared/human-canonical-qualification-39687040336-terminal-recovery-20261021T2250/data-only-v2/tmp/teamster-studies/wagon-driver-published/1280-threequarter.png)

