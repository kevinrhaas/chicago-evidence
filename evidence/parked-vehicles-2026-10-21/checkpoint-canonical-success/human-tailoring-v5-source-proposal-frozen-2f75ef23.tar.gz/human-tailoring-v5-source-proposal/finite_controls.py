"""One finite, nice single-thread source packet. No renderer/pose/dense face sweep."""
from pathlib import Path
import json,sys,math,ast,hashlib,collections,importlib.util,time
sys.dont_write_bytecode=True
D=Path(__file__).parent;ROOT=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(ROOT/'tools'))
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
old=module('pinned_2f75_fit',D/'preimages/chicago/4d/tools/human_workwear_fit.py');new=module('outside_v5_fit',D/'proposed/chicago/4d/tools/human_workwear_fit.py');recipe=json.loads((D/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text());start=time.monotonic()
def need(v,s):
 if not v:raise AssertionError(s)
def sourcepos(basis,lookup):return [math.fsum(v*lookup[int(i)][k] for i,v in basis.items()) for k in range(3)]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
report={'scope':'Finite static source controls only; no renderer/BPy/pose/dense full-face sweep or photographic/completefit acceptance','ages':[],'limitations':['Existing canonical39687040336 is untouched and does not test thisV5 proposal','Upper seat/thigh, sleeves/cuffs, lapels/buttons/neckcloth and captured materials are deferred','No complete triangle-body enclosure or animated/canonical/LOD clothing fit claim'],'negative_controls':[]}
for age in (25,35):
 bp=ROOT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json';raw=bp.read_bytes();body=json.loads(raw);m=body['meshes'][0];bones={b['name']:b for b in body['skeleton']};height=max(p[1] for p in m['positions_m']);lookup={sid:p for sid,p in zip(m['source_vertex_indices'],m['positions_m'])};sids=m['source_vertex_indices'];record={'age':age,'body_sha256':hashlib.sha256(raw).hexdigest()}
 before=old.garment_shell(m,'trousers',.007,recipe,bones,height);after=new.garment_shell(m,'trousers',.007,recipe,bones,height)
 for k in ('triangles','weights','uvs','corner_uvs','source_basis','source_triangle_indices'):need(before[k]==after[k],'trouser topology/UV/weights unchanged '+k)
 changed=[i for i,(a,b) in enumerate(zip(before['positions_m'],after['positions_m'])) if a!=b];need(len(changed)>100,'actual visible hang volume changes real source vertices');need(all(a[1]==b[1] for a,b in zip(before['positions_m'],after['positions_m'])),'trouser Y/sole/waist frame unchanged')
 profile=after['receipt']['trouser_hang_profile'];need(all(q['section_rx_m']<abs(q['axis_x_m']) for q in profile['sides'].values()),'separate lowerleg envelopes do not reach centre plane')
 samples=[]
 for fi,face in enumerate(m['triangles']):
  if fi not in set(after['source_triangle_indices']):continue
  y=sum(m['positions_m'][i][1] for i in face)/3
  # Fixed independent source landmark bands: ankle/calf/knee/transition.
  ys=[bones['foot_l']['head_m'][1]+.06,(bones['foot_l']['head_m'][1]+bones['calf_l']['head_m'][1])/2,bones['calf_l']['head_m'][1],profile['sides']['l']['transition_end_y_m']]
  if min(abs(y-q) for q in ys)<.025:samples.append(fi)
 # Deterministic limited source-face sample spans actual original triangulation.
 samples=sorted(samples);samples=[samples[round(i*(len(samples)-1)/95)] for i in range(min(96,len(samples)))];byfi={fi:f for fi,f in zip(after['source_triangle_indices'],after['triangles'])};min_before=math.inf;min_after=math.inf;new_negative=[]
 for fi in samples:
  f=m['triangles'][fi];p=[m['positions_m'][i] for i in f];n=cross([p[1][k]-p[0][k] for k in range(3)],[p[2][k]-p[0][k] for k in range(3)]);n=[v/math.hypot(*n) for v in n];gf=byfi[fi];a=[];b=[]
  for gi in gf:
   original=sourcepos(after['source_basis'][gi],lookup);a.append(sum((before['positions_m'][gi][k]-original[k])*n[k] for k in range(3)));b.append(sum((after['positions_m'][gi][k]-original[k])*n[k] for k in range(3)))
  min_before=min(min_before,min(a));min_after=min(min_after,min(b))
  if min(a)>=0>min(b):new_negative.append(fi)
 need(not new_negative,'no new negative incident face in bounded independent source sample')
 record['trousers']={'changed_original_vertices':len(changed),'maximum_added_radial_displacement_m':max(math.dist(a,b) for a,b in zip(before['positions_m'],after['positions_m'])),'profile':profile,'independent_source_faces':samples,'source_face_sample_old_min_m':min_before,'source_face_sample_v5_min_m':min_after,'new_negative_sample_faces':new_negative,'completefit_accepted':False}
 vest=new.garment_shell(m,'waistcoat',.014,recipe,bones,height);vold=old.garment_shell(m,'waistcoat',.014,recipe,bones,height);edges=collections.Counter(tuple(sorted(e)) for f in vest['triangles'] for e in zip(f,f[1:]+f[:1]));need(max(edges.values())<=2,'closed lowerfront manifold');need(vest['receipt']['maximum_discarded_cut_weight']<=.025,'unchanged2.5percent skin-cut refusal');closure=vest['receipt']['waistcoat_front_closure_y_m'];midline=[];lo=recipe['waist_height_fraction']*height-.04
 original=[sourcepos(b,lookup) for b in vest['source_basis']]
 for e,c in edges.items():
  if all(abs(original[i][0])<1e-12 and original[i][2]>0 and lo+1e-8<original[i][1]<closure-1e-8 for i in e):midline.append((e,c))
 need(midline and all(c==2 for e,c in midline),'lower waistcoat front actually closed with shared edges, no slit or overlapping duplicate patches')
 uvmax=0.
 for face,uvs,fi in zip(vest['triangles'],vest['corner_uvs'],vest['source_triangle_indices']):
  uv={sids[i]:m['uvs'][i] for i in m['triangles'][fi]}
  for i,p in zip(face,uvs):expected=[math.fsum(v*uv[int(sid)][k] for sid,v in vest['source_basis'][i].items()) for k in range(2)];uvmax=max(uvmax,math.dist(expected,p))
 need(uvmax<1e-12,'closed panels retain actual source triangle corner UVs');need(all(1<=len(w)<=4 and abs(sum(w.values())-1)<1e-12 for w in vest['weights']),'closed panels portable skin lanes')
 record['waistcoat']={'old_faces':len(vold['triangles']),'v5_faces':len(vest['triangles']),'lowerfront_shared_midline_edges':len(midline),'lower_closed_band_height_m':closure-lo,'Vends_y_m':closure,'maximum_source_corner_uv_error':uvmax,'maximum_discarded_cut_weight':vest['receipt']['maximum_discarded_cut_weight'],'buttons_lapels_accepted':False}
 need(bp.read_bytes()==raw,'actual body input unchanged');report['ages'].append(record)
 if age==25:
  (D/'trousers-adult25.json').write_text(json.dumps([after],separators=(',',':')));(D/'waistcoat-adult25.json').write_text(json.dumps([vest],separators=(',',':')))
# Existing guards/functions untouched; only source garments and added pure helpers.
funcs=lambda p:{n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.FunctionDef)}
a=funcs(D/'preimages/chicago/4d/tools/human_workwear_fit.py');b=funcs(D/'proposed/chicago/4d/tools/human_workwear_fit.py')
for name in a:
 if name!='garment_shell':need(a[name]==b[name],'existing helper AST untouched '+name)
report['preservation']='Exact2f75 builder/eye helper remain preimages only and unedited; all existing helper functions exceptgarment_shell AST exact, including shoe/sole/collar/clip. No body/skin/rig/identity/raw0.001 normal/export/animation/sole guard/mask changes.';report['PASS']=True;report['elapsed_s']=time.monotonic()-start;(D/'FINITE-SOURCE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='ages'},indent=2));print(json.dumps([{ 'age':x['age'],'trouser_changed':x['trousers']['changed_original_vertices'],'added_max':x['trousers']['maximum_added_radial_displacement_m'],'face_min':x['trousers']['source_face_sample_v5_min_m'],'front_edges':x['waistcoat']['lowerfront_shared_midline_edges']} for x in report['ages']],indent=2))
