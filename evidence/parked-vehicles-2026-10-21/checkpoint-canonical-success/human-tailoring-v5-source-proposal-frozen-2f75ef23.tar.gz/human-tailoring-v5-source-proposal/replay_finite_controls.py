"""Replay the preserved completed finite control against capsule-only inputs.

Usage: python replay_finite_controls.py /tmp/v5-replay-output
Original terminal reports and original fixtures are never overwritten.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit(__doc__)
output=Path(sys.argv[1]).resolve()
if output==D or D in output.parents:raise SystemExit('Choose a replay output directory outside this frozen capsule')
output.mkdir(parents=True,exist_ok=True)
source=(D/'finite_controls.py').read_text()
source=source.replace("ROOT=Path('/workspace/chicago/chicago/4d')","ROOT=D/'inputs/chicago/4d'")
for name in ('trousers-adult25.json','waistcoat-adult25.json','FINITE-SOURCE-CONTROLS.json'):
 source=source.replace("(D/'"+name+"')","(OUTPUT/'"+name+"')")
exec(compile(source,str(D/'finite_controls.py'),'exec'),{'__file__':str(D/'finite_controls.py'),'__name__':'__main__','OUTPUT':output})
