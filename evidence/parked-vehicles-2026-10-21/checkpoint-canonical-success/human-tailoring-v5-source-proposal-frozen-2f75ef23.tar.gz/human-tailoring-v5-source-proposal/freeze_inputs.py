"""Capture exact, read-only pinned inputs outside the application checkout."""
from pathlib import Path
import hashlib,json,subprocess,shutil
D=Path(__file__).resolve().parent
APP=Path('/workspace/chicago');REF='2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3'
paths=['tools/human_workwear_fit.py','tools/human_teamster_blend.py','tools/human_eye_components.py','data/humans/recipes/worker_1835.json','tools/human_source_normals.py','assets/authored/humans/makehuman_hm08/prepared_adult_25.json','assets/authored/humans/makehuman_hm08/prepared_adult_35.json']
items=[]
for rel in paths:
 p='chicago/4d/'+rel
 raw=subprocess.check_output(['git','-C',str(APP),'show',REF+':'+p])
 dest=D/('preimages' if (D/'preimages'/p).exists() else 'inputs')/p
 if dest.exists():assert dest.read_bytes()==raw,p
 else:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
 items.append({'git_path':p,'capsule_path':str(dest.relative_to(D)),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'exact_git_object':True})
(D/'PINNED-INPUTS.json').write_text(json.dumps({'ref':REF,'files':items,'working_tree_used_as_source':False},indent=2)+'\n')
src=Path('/workspace/shared/human-1835-clothing-reference-2026-10-21')
for name in ['TAILORING-REFERENCE-BRIEF.md','CROP-PROVENANCE.json','IMAGE-METADATA-HASH-CHECKS.json','MANIFEST.json','horse-1835-original.jpg','barroom-1835-original.jpg','horse-1835-men-source-crop.png','barroom-1835-seated-source-crop.png','horse-commons-metadata.json','barroom-commons-metadata.json','horse-nyhistory-record.html']:
 target=D/'references'/name;target.parent.mkdir(exist_ok=True)
 if target.exists():assert target.read_bytes()==(src/name).read_bytes()
 else:shutil.copyfile(src/name,target)
p=Path('/workspace/shared/human-canonical-release-2f75ef23-20261021/ACTIVE-PLAN.json');target=D/'inherited-evidence/V4-RELEASE-ACTIVE-PLAN.json';target.parent.mkdir(exist_ok=True);shutil.copyfile(p,target)
print(json.dumps({'pinned_inputs':len(items),'reference_files':11,'inherited_negative_count':40}))
