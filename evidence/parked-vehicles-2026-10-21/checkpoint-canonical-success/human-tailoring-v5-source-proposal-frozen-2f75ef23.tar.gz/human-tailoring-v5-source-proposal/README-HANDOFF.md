# Frozen V5 bounded tailoring source proposal

**Ready for source/design review only.** This is one complete, finite outside-app proposal against **2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3**. It has not been integrated, rendered, exported or submitted to CI. The original completed finite control report and fixtures were recovered after the environment restart and preserved unchanged. A separate short supplemental source pass completed successfully. No failed candidate is represented as accepted.

The V4 canonical run **39687040336** belongs to the pinned V4 source, not this proposal. Its terminal/artifact qualification is owned separately. Its outcome cannot qualify V5. This capsule performs no CI action.

## The two selected changes

- **Hanging trouser legs:** keep the original high waist, seat and uppermost thigh; expand the source lower-leg surface radially about each actual hip/bone axis. An ellipse derived from actual knee/calf body sections plus an original **12 mm** section-ease parameter creates fuller knee-to-shoe legs. A smooth transition ends **65%** of the knee-to-hip span above the knee; the hem profile uses **85%** of the knee-section radii. Expansion never intentionally shrinks an existing surface point. This is construction geometry, not cloth simulation.
- **Closed lower waistcoat:** replace the old persistent front slit/long V with actual front panels that meet on shared centre edges below the V. The V ends **40%** of the waist-to-shoulder span above the waist. Ten internal shared centre edges per prepared age demonstrate closure. The closed lower band is about **189 mm** high. Existing high waist and garment lower boundary stay in their source frame.

These dimensions are disclosed original engineering choices. They were not measured from painted people. William Sidney Mount's *Bargaining for a Horse* (1835, NYHS 1858.59) and *Bar-room Scene* (1835, AIC 1939.392) support the fuller hanging-leg silhouette and substantial closed lower waistcoat front. Both exact source crops were inspected again during finalization. Full reproductions, original-pixel crops, rights/catalog metadata and the detailed reference brief are included under `references/`. They establish circa-1835 American comparators, not a named Chicago resident's exact outfit or a completion date before July 1.

## Finite controls and their limits

| Control | Prepared age 25 | Prepared age 35 |
| --- | ---: | ---: |
| Original trouser vertices changed | 786 | 788 |
| Maximum additional radial displacement | 59.59 mm | 56.32 mm |
| Source-face sample minimum before V5 | 3.79 mm | 4.76 mm |
| Source-face sample minimum with V5 | 6.57 mm | 6.66 mm |
| Newly closed vest source-face sample minimum | 13.43 mm | 13.46 mm |
| Shared lower-front internal centre edges | 10 | 10 |

The original terminal `FINITE-SOURCE-CONTROLS.json` covers **96 deterministic original source-face samples per age** across ankle/calf/knee/transition landmark bands, source trouser topology/weights/UV/barycentrics, unchanged trouser Y, separated declared lower-leg envelopes, vest shared-edge closure/manifold edge incidence and interpolated corner UV/skin-lane preservation. Its `PASS: true` is scoped to those finite static controls. Its empty `negative_controls` does **not** mean zero global or inherited failures.

The supplementary pass uses capsule-only exact inputs. It verifies body, original skin, rig, identity and metadata unchanged **in memory**, exact original shirt geometry/UV/weights/source identity, declared real-limb section support and **32 actual newly closed front incident source-face samples per age**. Those projections are signed local source-face checks, not closest triangle/body distances or collision proofs. The untapered design support ellipse enclosing its selected source vertices does not prove that every tapered garment triangle encloses the entire leg.

**Forty inherited V4 idle0 negative source-face projections remain OPEN.** Their previous release provenance is copied under `inherited-evidence/`. They were not rerun, hidden, repaired or waived by this finite pass. No newly negative sample was found in the two bounded sample sets above. No full source-face/pose sweep was run.

No body/source skin/rig/UV/identity mutation, geometry mask, acceptance threshold change or waiver is included. The builder and eye helper are exact pinned preimages, provided for audit only; they are not part of the proposed patch. All pre-existing fit-helper functions except `garment_shell` have identical ASTs; only two new pure trouser-construction functions are added. Existing shoe/sole/collar/clip helpers, original source-normal **0.001** requirement, **2 mm** sole guards, exports and animation remain unmodified. The normal helper and both complete prepared bodies are pinned and included for independent replay.

## Deliberately unfinished features and acceptance

Full seat and upper-thigh drape, fuller sleeves, fitted cuff bands, a finished neckcloth/collar design, lapels, buttons, seams, cloth texture/material work and restrained wear are deferred. The waistcoat now closes but has no newly authored button row or lapel construction. The legs are fuller but are not accepted as final period tailoring.

Complete static triangle/body enclosure, broad poses, seated driving, independent head/jaw movement, post-decimation LODs, canonical exports, animation, photographic appearance and world acceptance remain unqualified for V5. This capsule contains no new town figure. The selected source proposal is frozen; it is not a request for further unbounded refinement.

## Review and future integration handoff

1. Verify `MANIFEST.sha256`; use `CAPSULE-MANIFEST.json` for lengths and hashes. `PINNED-INPUTS.json` binds every original input to the exact Git object. The original four-file preimage manifest is retained unchanged.
2. Review `V5-BOUNDED-TAILORING-AGAINST-2f75.patch` against the supplied `preimages/` and compare with `proposed/`. Only `human_workwear_fit.py` and `worker_1835.json` are proposed replacements. Builder, eye helper, normal helper and prepared bodies are audit/replay inputs, not edits.
3. The patch is coupled to its V5 recipe parameters. A future integrator should start from the exact pinned source or consciously resolve intervening source changes; never apply it blindly to the currently covered application checkout.
4. Optional finite replay, after extracting this capsule: `nice -n 15 env OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python replay_finite_controls.py /tmp/v5-finite-replay`. It uses the included inputs and writes to the chosen external directory. The original report is preserved. The original `finite_controls.py` records its historical application path; the replay wrapper redirects that dependency to the pinned included inputs.
5. Any future integration/render/export/pose/LOD/canonical acceptance belongs to a separately authorized next step with unchanged guards. This handoff makes no production or visual acceptance claim.

The source patch was applied only to a temporary copy of its exact preimages and reproduced both supplied proposed files byte-for-byte. Source/provenance capture used read-only saved Git objects; no application file, index, branch, ref, ticket, remote or workflow was changed.
