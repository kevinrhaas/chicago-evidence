# W01 parked visible increment — root-owned app integration

All app-relative files in `overlay/` are NEW paths. Do not apply old gallery/check/changelog patches; this parcel supplies a scene-ready model/material recipe, not a UI feature by itself. Root owns the main-scene instance batching/placement/legacy suppression and any ticket/changelog/docs/liberty/check integration.

Copy the overlay without overwriting an existing path. Reproduce and verify:

```sh
python3 tools/transport/generate_parked_wagon.py --parameters data/transport/parked/wagon-w01.json --output-dir renderers/web/transport/parked-wagon --texture-output-dir assets/authored/transport/wagon_parked/textures --verify
```

This regenerates original hardware,0138 source-mapped materials and the274e finish using pure Python/NumPy/SciPy/Pillow. No Blender or copied master input is required. Actual output and verify passed; all protected geometry/accessors/nodes/UVs/tangents/rig streams and parent BIN prefix remain exact. Full-model count12104triangles/23mesh draws;9maps estimate6MiB RGBA8+mips, unchanged from0138. Khronos0errors/0warnings (28 informational unused-object notices).

Twelve actual matched desktop1280x800/mobile390x780 whole/bench/stake captures passed, browser/server closed, no console/page/GL errors. Geometry is identical, so each camera/frustum renders exactly the same triangle/draw counts before/after. Root should actually inspect `actual/desktop-whole-candidate.png` and compare the baseline; the timber is visibly darker/more varied, paint muted, but this is a bounded increment and not photographic completion. Existing coarse silhouettes, faceted endgrain/hubs and isolated unlit-metal macro remain unresolved.

Forward+Z/up+Y. Node `vehicle_tongue` has world joint origin[0,.535,1.525] in rest model. Actual timber bounds[-.0275,-.0275,0]..[.0275,.0275,2.75] and iron bounds[-.031,-.0315,.0875]..[.031,.0315,2.6625]. Flat-ground all-vertex tip contact gives positive Xrotation0.18578444683082146rad (10.6446647026deg); a centerline-only arcsine would sink thickness. Solve/check the actual rotated vertices against placed terrain and do not claim force/contact mechanics. All wheels remain at originalmetric radius.

Root may statically merge exact scene-rest transformed primitives by material for parked instances (six material batches, not23clones perwagon); preserve original source model and data provenance. Restrict this first use to a small set of farm-box placements in their existing coordinates. Covered wagons/carts and Light/fallback paths remain separate. Actual main-scene source and published desktop/mobile captures, foreground preflight, unchanged budget gates and normal greenDEV merge remain root tasks.

Assets/license ledger, SOURCE.json and a real numeric liberty heading must be installed before app gating. This overlay includes an appendix draft, not a claimed assigned liberty. No tracked shared checkout or Git ref was modified by the author.
