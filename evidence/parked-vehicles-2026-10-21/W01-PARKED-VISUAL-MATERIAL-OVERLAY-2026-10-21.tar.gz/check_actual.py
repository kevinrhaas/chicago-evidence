#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Read actual GLB bytes independently; preserve all original geometry/rig data."""
from pathlib import Path
import hashlib, json, struct, sys
import numpy as np
ROOT=Path(__file__).resolve().parent
parent=Path('/workspace/shared/w01-refined-app-integration-v2/files/renderers/web/transport/wagon-refined/wagon-w01.glb')
candidate=ROOT/'candidate/wagon-w01.glb'
def read(path):
    b=path.read_bytes();n=struct.unpack_from('<I',b,12)[0]
    assert struct.unpack_from('<III',b)==(0x46546c67,2,len(b))
    return json.loads(b[20:20+n]),b[28+n:]
a,ab=read(parent);b,bb=read(candidate)
assert bb[:len(ab)]==ab
for k in ['accessors','meshes','nodes','scenes','skins','animations','samplers','textures']:
    assert a.get(k)==b.get(k),k
assert len(b['images'])==9 and len(b['materials'])==6
assert [x['name'] for x in a['materials']]==[x['name'] for x in b['materials']]
for am,bm in zip(a['materials'],b['materials']):
    ap=am['pbrMetallicRoughness'];bp=bm['pbrMetallicRoughness']
    assert {k:v for k,v in ap.items()if k!='baseColorFactor'}=={k:v for k,v in bp.items()if k!='baseColorFactor'}
    assert am.get('normalTexture')==bm.get('normalTexture')
    assert len(bp['baseColorFactor'])==4 and all(0<=v<=1 for v in bp['baseColorFactor'])
count=0
for m in b['meshes']:
    for p in m['primitives']:
        indices=b['accessors'][p.get('indices',p['attributes']['POSITION'])]
        assert indices['count']%3==0
        count+=indices['count']//3
assert count==12104
browser=json.loads((ROOT/'actual/receipt.json').read_text())
assert browser['passed'] and browser['closed'] and len(browser['runs'])==12
assert not browser['errors'] and not browser['console']
baselines={(r['viewport'],r['shot']):r for r in browser['runs'] if r['kind']=='baseline'}
for run in browser['runs']:
    base=baselines[run['viewport'],run['shot']]
    assert (run['draws'],run['triangles'])==(base['draws'],base['triangles'])
    if run['shot']=='whole':
        assert run['draws']==23 and run['triangles']==12104
    assert abs(run['estimatedRGBA8MipBytes']-6291456)<1e-6
    assert all(abs(v)<.98 for v in run['bounds'].values())
report={'PASS':True,'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'protected_old_binary_prefix_bytes':len(ab),'all_geometry_accessors_meshes_nodes_scenes_skins_animations_samplers_texture_refs_exact':True,'triangles':count,'draw_batches':23,'actual_matched_captures':12,'browser_closed':True,'estimated_decoded_texture_mips_bytes':6291456,'acceptance':'bounded visible finish increment; no photographic or historical-finish completion'}
(ROOT/'actual-independent-readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
