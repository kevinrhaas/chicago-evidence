#!/usr/bin/env python3
"""Prepare exact staged-source identity pins; does not launch a renderer or publisher."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--capture-dir',type=Path,required=True)
a=p.parse_args()
root=Path('/workspace/chicago')
assert str(a.output.resolve()).startswith('/workspace/shared/')
assert str(a.capture_dir.resolve()).startswith('/workspace/shared/') and not a.capture_dir.exists()
assert subprocess.run(['git','diff','--quiet'],cwd=root).returncode==0,'Stage reviewed source first'
config=json.loads((Path(__file__).parent/'config.template.json').read_text())
config['expectedHead']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
config['expectedIndexDigest']=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage'],cwd=root)).hexdigest()
config['output']=str(a.capture_dir.resolve())
a.output.write_text(json.dumps(config,indent=2)+'\n')
print(json.dumps({'config':str(a.output),'expectedHead':config['expectedHead'],'expectedIndexDigest':config['expectedIndexDigest'],'screenshots':22}))
