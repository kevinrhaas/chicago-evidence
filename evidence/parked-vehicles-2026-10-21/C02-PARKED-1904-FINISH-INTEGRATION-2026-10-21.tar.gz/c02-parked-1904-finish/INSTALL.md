# Parked1904 reconstructed carriage: integration parcel

Copy `files/` beneath `chicago/4d/` after root review. It adds a new parked-carriage
asset and original producers; the existing carriage-c02 baseline and generator
remain unchanged. Root integrates actual scene placement, popup metadata, license
registry, liberties/status/roadmap/changelog and any verifier registration needed.
No tracked app or Git file was written by the parcel author.

Reproduce with the repository's existing NumPy/Pillow Python environment:

```
python tools/transport/produce_parked_carriage.py \
  --baseline renderers/web/transport/carriage-c02/carriage-c02.glb \
  --output /tmp/c02-parked-fresh
```

Expected output SHA256:
`f02c6a4ed9537546d5576ac9d15b881ae684920d5233a62f83387b015bf5af39`.
The exact baseline93d40200 is transformed through reviewed cushioncc469f5b;
the new original material pass appends UV/tangent/image streams but preserves the
complete old binary prefix, all existing position/normal arrays, hierarchy,
scene roots, doors and sockets. Two complete source-chain runs are byte-identical.
No Blender, external texture, network acquisition or image tracing is involved.

Actual A/B fixture passed eight pairs/sixteen captures: desktop1280x800 and
mobile390x780, side/rear/close closed and side70-degree door endpoint. Cameras
match exactly; draw and triangle deltas are0; source count12228; console/page/GL,
framing and canvas/header checks pass. Both browser and server closed. The
supplied scene asset itself has door interaction/boarding/occupants/traffic OFF.
The old optional study viewer's fitted shadow calculation was reused in the
comparison only; scene shadows are the scene renderer's responsibility.

Khronos final:0errors/0warnings. Independent decoded readback verifies all source
P/N, binary prefix, hierarchy and socket transforms and thirteen finite orthogonal
unit tangent frames. The first tangent-space-warning candidate and favicon404
fixture failure are retained explicitly; neither is relabeled as a pass.

Runtime asset:1,844,804bytes,12228triangles,31batches,9 embedded native256px
maps (3MiB upper-bound RGBA+mips). The source generator also writes inspectable
PNG maps; they need not be separately shipped because they are embedded in GLB.
Output ground-local closed bounds:
`[-0.879999995,-0.000000012,-1.570908070]` to
`[0.970000029,2.140000105,3.151774836]` metres. Unit scale, +Yup, +Zforward,
ground-midpoint-between-axles datum. Empty shafts remain raised; no ground-pose
rescale or coupling adjustment is needed for this parked specimen.

Author actually viewed desktop side/rear/close and mobile rear. It visibly
improves flat orange timber and uniform upholstery through a restrained painted
finish, fine paint/leather surface variation and tinted glazing. It is still
boxy with simple lamps/frames and does not meet full photographic acceptance.
The newly found1893 Studebaker Brougham plate is a better future named-geometry
target; this carriage is NOT that vehicle and carries no Studebaker/Pullman or
Glessner ownership claim. Original source comparison belongs to the next repair,
not a retroactive provenance claim for this finished material-only pass.
