New generator, original paint/leather image maps and material definitions:
GPL-3.0-or-later. Existing C02 geometry/cushion source remains GPL-3.0-or-later;
glb_data.py and planar.py retain their original CC0 SPDX declarations. The GLB
contains original project-authored geometry and maps, with no imported source
pixels. Root must add the GLB/JSON/LICENSE/recipe path to assets/LICENSES.md and
the applicable transport license registry.

Proposed liberty append (root assigns numeric ID): The1904 parked town-carriage
specimen is an original reconstruction with unknown maker, subtype and owner.
Its original bounded cushion uses the already recorded Ware1875 printed326
construction-family analogy, not exact C02 design or dimensions. Deep green
bodywork, red-brown painted running gear, dark brown leather, generated micrograin,
roughness, metallic/clearcoat values and tinted glazing are unmeasured authored
choices. The broad painted-timber practice is period-plausible but no individual
finish chemistry/color is asserted. Its sidecar explicitly permits a1904 parked
reconstruction rather than claiming a recorded carriage at the chosen position.
Source photograph support remains only a coarse silhouette analogy and does not
identify Pullman ownership. Doors, boarding, occupants and traffic are disabled
in the parked scene. Photographic quality, full historical subtype matching,
occupant fit and force/dynamic validation remain open.
