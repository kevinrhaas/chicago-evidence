# T-2980 minimal covered-wagon integration proposal

This packet proposes replacing exactly two existing reconstructed 1835 covered wagons, preserving their distinct finishes and laid-by yokes. It is outside the tracked app and is not installed, merged or photographically accepted. Base is exact parked commit `2aebef95f6a5b6fa1bd8353db936c7674a73c32f`.

The selected original stands were chosen only after the actual pinned browser Heightfield query: Western Hotel `town_wagon_western_hotel_wagon_yard_1`, E−136.05/N−291, bearing 356.2°, has 0 mm four-wheel variation; Wolf Point `town_wagon_wolf_point_tavern_yard_1`, E−90.5/N−39.5, bearing 356.2°, has 3.441274 mm. Both preserve the existing 30 mm guard. No old stand moved and no guard changed. All 18 covered stands were sampled; only these two modelled candidates are proposed. This qualifies wheel-plane samples, not actual ground-mesh/body/yoke clearance.

## Files and application boundary

`preimage/` contains selected exact Git blobs and module dependencies, with SHA256 pins in PREIMAGES.json. This is not another checkout or worktree and has no Git metadata. `proposed/` contains 24 proposed files: eight modified text files and 16 new files, including two GLBs and three original cloth PNGs. PROPOSED-FILES.json identifies each file; covered-2980-proposal.patch contains text changes only. Binary assets are supplied separately under proposed/. CAPSULE-MANIFEST.json pins the entire packet.

The eight existing edits are placements.json, check_parked_placements.py, two small check.sh steps, append-only licenses in assets/ and transport/, and append-only LIBERTIES/STATUS/ROADMAP notes. Existing bytes, including non-UTF8 historical license/liberty text, are preserved exactly. No yard.js, main.js, parked-transport.js, global lighting, publisher, schema or workflow change is proposed. Existing publisher already recursively copies parked data and renderer assets, with parked data covered by check_published.

Do not copy complete historical STATUS/ROADMAP/license files over a newer branch. Root should review/apply the patch against matching preimages, or carry only the scoped append/edit hunks onto a newer DEV and regenerate derived reports normally. Changed IDs/changelog and source-use/asset manifests must be reconciled after integration. This proposal does not waive those normal checks.

## Source, data and truthful cards

`generate_covered_wagons.py` rebuilds the parent with the existing complete original W01 hardware/material/finish producer, regenerates the exact hardware ownership map in a temporary directory, then runs the unchanged original covered producer. No cached exported parent is a production input. `--verify` validates two GLBs, two sidecars and three cloth maps against reviewed hashes. Geometry/source remain GPL-3.0-or-later; original analytic pixels retain CC0. No downloaded model, third-party image, photographic texture or scan was introduced.

Data-only model manifests reuse the existing parked card renderer. The vehicle type is Covered wagon; maker is unidentified; state is unoccupied/unhitched. The model basis/row notes disclose seeded reconstructed paint/wood/canvas aging, bows/seams/folds, preserved laid-by ox yoke, omitted donor bench/footboard and unsupported occupant/driver/hitch/collision/ride interfaces. No attested maker, owner, historical cargo, Dearborn identity or measured textile is supplied. These are card objects until an actual popup DOM check is run in the integrated app.

Each exact old record ID, numeric coordinate and bearing stays unchanged. The old ID and coordinate string remain the finish seed; the new asset ID does not reseed it. Blue/oxide and oak/darkoak families, body age, canvas age and per-board factors are recorded. Strict validation checks the original kind is covered, tilt/yoke/context remain exact, no farm_box/cart becomes covered, no unreviewed individual substitutes, no source attests an invented individual, and each new row is unique in 1835. Source contract hashes pin the old palette, schemes, hash/stream and wagonCoat functions without locking unrelated yard code. Terrain meta/binary pins invalidate stale wheel qualification when the ground data changes.

All ten inherited driver/passenger/foot/boarding/hitch/collision/ride-camera sockets are explicitly unsupported in GLB metadata and sidecars. Only donor source-owned bench/footboard geometry is omitted; protected wheel/axle/tongue streams and inherited node transforms/pivots remain byte-exact. Original W01 source/output are untouched. Both selected yokes are built into the covered model. Other old wagons, including no-yoke/shed vehicles, remain unchanged.

## Existing parked behavior and costs

The unchanged production module groups static meshes by identical material after tongue settling. The new models have nine active material groups; shared-material attribute signatures are compatible (the colored body clones have COLOR_0 and are separate from the uncolored running-gear/yoke materials). Each explicit variant loads once through the existing asset-promise cache; no shared material is recolored after clone(true).

Existing replacementIds and fallback callbacks hide only the explicit original chunks near a successfully loaded model, restore them for Light/far/dispose, and leave failed or refused GLBs drawing the old prop. The old chunk includes its yoke, so including exactly the retained yoke in the near model avoids its disappearance when that chunk hides. No farm-box-specific hiding rule is added. Existing confidence/picking/disposal and finite ground/30 mm/tongue contact logic are reused, not reimplemented.

Each new GLB is approximately 2.97 MB / 17,292 triangles / 26 raw primitives / nine material groups. Estimated mapped RGBA8 textures plus a 4/3 mip allowance are 8 MiB each, 16 MiB for separately loaded variants: inherited six MiB plus new cloth two MiB. Cross-GLB deduplication is not credited. Existing raw prototype gallery cost (53 calls including shadow/floor) is not a canonical main-scene driver budget. Compression/near-mid-far delivery and mobile production costs remain unqualified; no fleet or LOD bake is proposed.

## Evidence actually run

- Original two-variant prototype: byte-exact repeat, Khronos zero errors/zero warnings, 36 independent structural controls, two real corrupt-input refusals and 14 actual desktop/mobile model PNGs. Preserved in the previous source capsule `721dcf096c88f19bf65ed8997275a0d0801bc22abde246d4587dd3925c2337f2`.
- This proposal: actual source-only wrapper --verify PASS, all six total parked placements PASS, eight actual covered identity refusals PASS. SHORT-CHECKS.json and logs retain terminal results. A rejected exec-server CreateProcess request created no worker; the subsequent owned caller terminated normally. No duplicate browser or gate ran.
- One actual lightweight browser query used pinned original Heightfield/e1834 samples at all 18 old covered stands, qualified the two candidates, and closed browser/server. See actual-terrain-query/receipt.json; no renderer or world boot was run in that query.

`fixtures/module-fixture.{html,cjs}` is PREPARED AND UNRUN. It exercises the unchanged actual parked module with the two proposed variants: initial Light/no loads, near replacement, loaded Light/far fallback, actual finite terrain/tongue provider, null/over-30mm refusal, controlled GLB-load rejection, missing-host fallback, disposal, truthful card object fields, nine static material batches and actual desktop/mobile renderer frames. It deliberately narrows only its fixture manifest and injects an explicit loader rejection. No real popup DOM, confidence shader, production shadow or main-world budget claim follows. Root may run it when the coordinated browser lane is free; it has no fullworld startup.

Baseline ribbed canvas shading disappeared only in a corrected matched shadow-off diagnostic. The first ineffective toggle and corrected evidence are both retained in the prototype capsule. No shadow-off/bias adjustment is carried into this proposal. Actual production lighting/self-shadow quality is still required.

## Reproduction and next validation

Recreate the standalone exported overlay without touching the app:

```sh
python prepare-review-root.py
cd review-root/chicago/4d
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /workspace/shared/chicago-venv/bin/python tools/transport/generate_covered_wagons.py --verify
/workspace/shared/chicago-venv/bin/python tools/transport/check_parked_placements.py
/workspace/shared/chicago-venv/bin/python tools/transport/wagon_covered/test_identity.py
```

The prepared browser caller uses installed local Playwright/Chromium and the existing Three 0.185.1 vendor; obtain the free browser lane and authorized subprocess execution before running `node fixtures/module-fixture.cjs` from this packet root. It creates a fresh actual-module-fixture directory and preserves errors. Do not run during a full app gate.

Before any ordinary DEV merge: independent peer review; scoped integration on current DEV; real module fixture; exact body/wheel/tongue/yoke/host clearance; matched old/new close/side/front-quarter/distant source and published main screenshots on both viewports; actual popup DOM/picking/confidence/fallback/disposal; production shadow quality; canonical api.stats driver and texture/memory budgets; supported publish/mirror checks; source-use/derived report regeneration; full preflight and appropriate current published CI smoke. This packet is not parent photographic, all-era, fleet, horse, driver, animation or boarding completion.
