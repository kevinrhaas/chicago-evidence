#!/usr/bin/env python3
"""Materialize only the pinned exported-blob review overlay; no Git or app writes."""
from pathlib import Path
import hashlib
import json
import shutil
p = Path(__file__).resolve().parent
manifest = json.loads((p/'PREIMAGES.json').read_text())
for row in manifest['files']:
    assert hashlib.sha256((p/'preimage'/row['path']).read_bytes()).hexdigest() == row['sha256'], row['path']
if not (p/'review-root').exists():
    shutil.copytree(p/'preimage', p/'review-root')
shutil.copytree(p/'proposed', p/'review-root', dirs_exist_ok=True)
expected = json.loads((p/'REVIEW-PINS.json').read_text())
for row in expected['files']:
    assert hashlib.sha256((p/'review-root'/row['path']).read_bytes()).hexdigest() == row['sha256'], row['path']
print('Pinned exported review overlay ready; no checkout, app or Git write')
