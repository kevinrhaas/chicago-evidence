#!/usr/bin/env python3
"""LIGHT exact-blob/formula tests; no canonical target changes."""
import importlib.util
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
root = Path(__file__).parent
spec = importlib.util.spec_from_file_location('bounded_kimball', root / 'graft_reviewed_liberties.py')
w = importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)
g = w.load_original(w.ORIGINAL)
repo = Path('/tmp/chicago-log-integration')
original_blob = g.blob
proof = json.loads((root / 'source-proof/proof.json').read_bytes())
kimball_source = (root / 'source-proof/kimball-9f-LIBERTIES.md').read_bytes()
import hashlib
assert hashlib.sha1(b'blob ' + str(len(kimball_source)).encode() + b'\0' + kimball_source).hexdigest() == proof['source_git_blob_sha1']
assert proof['source_git_blob_sha1'] == '6e07370489de298269463359fd1c076e2dd47f30'


def immutable_fixture_blob(repo_, ref, path):
    if ref == w.KIMBALL_COMMIT and path == w.LIBRARY:
        return kimball_source
    return original_blob(repo_, ref, path)


g.blob = immutable_fixture_blob
before = g.blob(repo, g.BASE, w.LIBRARY)
after = (Path(g.PACKET) / w.LIBRARY).read_bytes()
fragment = after[len(before):]
previous = g.blob(repo, w.PREVIOUS_PARENT_COMMIT, w.LIBRARY)
incoming = previous + (root / 'source-proof/kimball-append.md').read_bytes()
checks = []


def ok(name, value):
    assert value, name
    checks.append(name)


def refused(name, fn):
    try:
        fn()
    except (ValueError, g.Conflict):
        checks.append(name)
    else:
        raise AssertionError(name + ' did not refuse')


audit = w.validate_audit(w.AUDIT_PATH)
supersession = w.validate_supersession_audit(w.SUPERSESSION_AUDIT_PATH)
ok('original frozen helper and both frozen audit sets verified', len(audit) == 3 and supersession['guarded_paths'] == 87)
ok('Kimball reconstruction equals immutable source Git blob', proof['status'] == 'PASS')
binding = w.validate_incoming(g, repo, before, incoming)
ok('only exact a219+Glessner2849+Kimball2331 formula accepted', binding['incoming_exact_a219_plus_glessner_plus_kimball'])
ok('whole incoming SHA equals closed3fa actual observation', w.sha(incoming) == w.ONLY_REVIEWED_INCOMING_SHA)
ok('actual local immutable9f source equals reconstructed Git blob', original_blob(repo, w.KIMBALL_COMMIT, w.LIBRARY) == kimball_source)
ok('actual local3fa raw document equals exact formula', original_blob(repo, w.NEW_PARENT_COMMIT, w.LIBRARY) == incoming)
refused('previous d872 alone now refuses', lambda: w.validate_incoming(g, repo, before, previous))
refused('single incoming byte alteration refuses', lambda: w.validate_incoming(g, repo, before, b'X' + incoming[1:]))
refused('new unreviewed incoming append refuses', lambda: w.validate_incoming(g, repo, before, incoming + b'\nOther history\n'))
refused('missing Kimball byte refuses', lambda: w.validate_incoming(g, repo, before, incoming[:-1]))
result = g.append_doc(b'', fragment, incoming, 'docs/LIBERTIES.md')
ok('entire incoming parent/Glessner/Kimball raw history exact', result[:len(incoming)] == incoming)
ok('only exact12-entry selected fragment appended', result[len(incoming):] == fragment)
ok('exact append idempotent', g.append_doc(b'', fragment, result, 'docs/LIBERTIES.md') == result)
ids = re.findall(rb'(?m)^#{2,4} (L-[A-Za-z0-9_-]+)\b', fragment)
ok('twelve unique native liberty ids', len(ids) == len(set(ids)) == 12)
for identity in ids:
    refused('same liberty id refuses: ' + identity.decode(), lambda identity=identity:
            g.append_doc(b'', fragment, incoming + b'\n### ' + identity + b': changed title\nOther text\n', 'docs/LIBERTIES.md'))
refused('other docs retain original raw-prefix refusal', lambda:
        g.append_doc(b'old\n', b'old\n\nNew\n', b'incoming-rewrite\n', 'docs/STATUS.md'))
(root / 'anticipated-incoming-LIBERTIES.md').write_bytes(incoming)
(root / 'anticipated-liberty-result.md').write_bytes(result)
stage_report = json.loads((root / 'stage-parent3fa/report.json').read_bytes())
ok('actual3fa concrete stage has eighteen files and no conflicts', stage_report['status'] == 'STAGED_NOT_APPLIED'
   and stage_report['target_commit'] == w.NEW_PARENT_COMMIT and len(stage_report['files']) == 18 and not stage_report['conflicts'])
ok('actual3fa staged liberty result preserves exact incoming plus12',
   (root / 'stage-parent3fa/overlay' / w.LIBRARY).read_bytes() == result)
receipt = {'status': 'ANTICIPATED_INPUT_PROOF_ONLY_NOT_APPLYABLE',
           'actual_new_parent_commit': w.NEW_PARENT_COMMIT,
           'actual_context_pending': 'Run bounded wrapper on actual target once new Git objects/merge are available; no target stage/apply claimed by this formula proof.',
           'parent_audit_manifest_sha256': w.AUDIT_SHA, 'parent_supersession_audit': supersession,
           'incoming_history_binding': binding, 'reviewed_incoming_sha256': w.sha(incoming),
           'reviewed_incoming_bytes': len(incoming), 'immutable_kimball_blob_proof': proof,
           'selected_append_sha256': w.sha(fragment), 'selected_append_bytes': len(fragment),
           'selected_liberty_ids': [x.decode() for x in ids],
           'result_sha256': w.sha(result), 'result_bytes': len(result),
           'entire_incoming_raw_prefix_exact': True, 'only_exact_selected_append_added': True}
(root / 'anticipated-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
summary = {'status': 'PASS', 'checks': len(checks), 'passed': checks,
           'limits': 'Actual pinned parent/e5/9f/3fa Git blobs, immutable REST-blob proof, and read-only actual3fa18-file staging. Pure LIGHT checks; no canonical writes/fetch/checkout/heavy/gates.'}
(root / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'checks': len(checks), 'result_sha256': w.sha(result)}))
