# PR1256 / Kimball-bound T3081 graft

This is a new helper packet. Both earlier frozen graft helpers remain untouched.
It stages the same root-pinned 18 authored changes while preserving all of the
new parent, Glessner and Kimball liberty history.

The **only** accepted incoming LIBERTIES SHA256 is
`bd3256a762f0a81bd3d067b7a5f6bc5222dde7425c74ce97e45e1aef40d3ef92`.
Every run proves its exact raw composition:

1. Entire a219 LIBERTIES, SHA `b61665c79dd760c2531797c907d214903d0341bf865e3a9d084870a050c3c866`;
2. Exact 2,849-byte Glessner appendix from e5, SHA `f2afc417785d5d31c8b2b0cafa42b575d9da1c59f0fe36b759318a8da211a61a`;
3. Exact 2,331-byte Kimball appendix from `9f21dd6a7a3e4523ebd7e99b6bb39faa04dcfeb0`, SHA `c3dd92843213540c3de380eef6c799b91d98850c1a586471da70b161216b1dbd`.

The first two parts must equal the entire previous parent96 raw document. The
actual new parent is `3fa6e0e84f84a33ccb8ac82c4778f6468af3b029`, PR1256.
The new wrapper accepts neither the previous d872 document nor any additional
incoming history. A future history change needs a new bounded review.

The wrapper verifies both provenance manifests and every one of their inputs:

- Parent historical review `b7f17d99f1fcaad9298a0c28f289818b13e7c7dc54512edf1394652437fb6f7c` at `/tmp/frame1239-resumed-readonly-20261023/closed-review/MANIFEST.json`;
- PR1256 supersession review `36f6c31eb33abea96d61a74544c1a3ea8685fab1d85c27c2e74dbde9ea541429` at `/tmp/PR1239-live-owner-watch-20261023/closed-3fa6-supersession-review/MANIFEST.json`, including the exact 87-path preservation and whole96-prefix/Kimball2331 proof.

## Stage the actual assembled target

For the clean explicit parent commit:

```sh
python3 /tmp/log82-reviewed-liberties-kimball-graft-20261024T0010/graft_reviewed_liberties.py --repo /tmp/chicago-log-integration --target-ref 3fa6e0e84f84a33ccb8ac82c4778f6468af3b029 --reviewed-liberties-sha256 bd3256a762f0a81bd3d067b7a5f6bc5222dde7425c74ce97e45e1aef40d3ef92 --out /tmp/t3081-graft-parent3fa
```

For root's resolved uncommitted parent3fa/current-dev merge, use
`--target-worktree` in place of `--target-ref ...` and choose another fresh output
directory. This binds actual HEAD, the complete index-stage fingerprint,
MERGE_HEAD and all 18 touched working-file preimages. It needs no ungated merge
commit and performs no fetch, checkout, source/index write or native derivation.
The referenced Git source objects must already be available; only root coordinates
fetches. The helper never creates or updates shared refs.

Only the LIBERTIES old-prefix guard is replaced, with the exact reviewed incoming
formula above. The entire incoming raw document remains the result's prefix, and
only the selected 12-entry fragment is appended. The unchanged native duplicate-id
and same-heading guards apply against the entire incoming document. The other
17 files retain the original general helper's field/phase/row merges, raw document
history protection, code conflicts and minimal native writer insertion.

## Apply only after root's final review

Review the actual overlay, graft patch and bound receipt, then apply that stage
with the unchanged general helper:

```sh
python3 /tmp/log82-graft-prep-20261023T2340/graft_t3081.py --repo /tmp/chicago-log-integration --apply-staged /tmp/t3081-graft-parent3fa
```

Its HEAD/index/MERGE_HEAD and all-preimages-before-writing checks remain in force.
The wrapper itself offers staging only. Never copy the anticipated whole-file
proof over a newer document. All incoming Hogan, Glessner, Kimball, source/rights,
native writer and unrelated JSON rows are preserved; no generated asset or
population output is in this 18-file overlay.

The root packet remains fixed at b9ad. It predates the side-entry consumer repair:
after applying, root must explicitly restore its checked exact-source-phase reader
fix and revised default-off/five-opt-in STATUS wording from its newer own
checkpoint. Do not lose that correction merely because the old pinned authored
composition stages successfully. Restore official82 outputs only through the
separately verified producer/input bindings and row graft; never overwrite whole
old asset/native manifests.

## LIGHT proof

`verification.json` records 29 passing formula and refusal checks. The 9f source
was additionally reconstructed from the frozen REST pure-append diff and verified
against its exact immutable Git blob id
`6e07370489de298269463359fd1c076e2dd47f30`; source-proof bytes and receipt are
included and compared byte-exact to the actual local9f source after root's
coordinated fetch. All 12 duplicate-id refusals remain active. The actual local3fa
document matches the complete formula, and `stage-parent3fa/report.json` passes
all18 files with zero conflicts. Its bound receipt SHA is
`f0e84aecbdb5cda81a45536d992f77e758c5163766777444c783406b8a5012ea`.
Root's actual final merged worktree still needs its own fresh stage/context;
neither the formula proof nor this clean-parent preview was applied.

No canonical write, native writer, Blender/browser, full gate, merge approval or
image-match acceptance is claimed by this helper packet.
