#!/usr/bin/env python3
"""Stage only: bind one reviewed incoming LIBERTIES SHA, preserve it, append T3081."""
import argparse
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ORIGINAL = Path('/tmp/log82-graft-prep-20261023T2340/graft_t3081.py')
ORIGINAL_SHA = '84d80a4e5618fb287940e70e49af744d57064d95abeaa91d02cb9d65606ab5ee'
AUDIT_SHA = 'b7f17d99f1fcaad9298a0c28f289818b13e7c7dc54512edf1394652437fb6f7c'
AUDIT_PATH = Path('/tmp/frame1239-resumed-readonly-20261023/closed-review/MANIFEST.json')
LIBRARY = 'chicago/4d/docs/LIBERTIES.md'
SOURCE_BASE_SHA = 'db54b729615c623e08353fcb4db6c4f3bfb861ceaaaf1854ca28811ca5e62e6d'
PARENT_COMMIT = 'a2192528415d04f3b83424447a0b08a766d73825'
PARENT_RAW_SHA = 'b61665c79dd760c2531797c907d214903d0341bf865e3a9d084870a050c3c866'
DEV_COMMIT = 'e5ed3ff6e5a62f70ae8a1c3c0c88c29e977cf02a'
DEV_SUFFIX_SHA = 'f2afc417785d5d31c8b2b0cafa42b575d9da1c59f0fe36b759318a8da211a61a'
PREVIOUS_PARENT_COMMIT = '96ca50cbc8150f93576cbbd699b4359d73b6de01'
PREVIOUS_INCOMING_SHA = 'd872bfe51b324e72bd47b8682ee5363d943edbce119fb3849a7fef4ed5a33079'
KIMBALL_COMMIT = '9f21dd6a7a3e4523ebd7e99b6bb39faa04dcfeb0'
KIMBALL_SUFFIX_SHA = 'c3dd92843213540c3de380eef6c799b91d98850c1a586471da70b161216b1dbd'
NEW_PARENT_COMMIT = '3fa6e0e84f84a33ccb8ac82c4778f6468af3b029'
ONLY_REVIEWED_INCOMING_SHA = 'bd3256a762f0a81bd3d067b7a5f6bc5222dde7425c74ce97e45e1aef40d3ef92'
SUPERSESSION_AUDIT_SHA = '36f6c31eb33abea96d61a74544c1a3ea8685fab1d85c27c2e74dbde9ea541429'
SUPERSESSION_AUDIT_PATH = Path('/tmp/PR1239-live-owner-watch-20261023/closed-3fa6-supersession-review/MANIFEST.json')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_original(path):
    if sha(path.read_bytes()) != ORIGINAL_SHA:
        raise ValueError('Original frozen graft helper hash changed')
    spec = importlib.util.spec_from_file_location('graft_t3081_frozen', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_audit(path):
    if sha(path.read_bytes()) != AUDIT_SHA:
        raise ValueError('Frozen parent audit manifest hash mismatch')
    manifest = json.loads(path.read_bytes())
    entries = manifest['files']
    for entry in entries:
        data = (path.parent / entry['path']).read_bytes()
        if len(data) != entry['bytes'] or sha(data) != entry['sha256']:
            raise ValueError('Parent audit input mismatch: ' + entry['path'])
    required = ['review.json', 'raw-line-preservation-review.json', 'Hogan-liberty-block-review.json']
    bound = {}
    for name in required:
        data = (path.parent / name).read_bytes()
        bound[name] = {'bytes': len(data), 'sha256': sha(data)}
    review = json.loads((path.parent / 'review.json').read_bytes())
    if review['reviewed_remote_head'] != 'a2192528415d04f3b83424447a0b08a766d73825':
        raise ValueError('Unexpected reviewed parent head')
    return bound


def validate_incoming(g, repo, before, incoming):
    """Only a219 + exact Glessner2849 + exact Kimball2331, from pinned commits."""
    parent = g.blob(repo, PARENT_COMMIT, LIBRARY)
    latest_dev = g.blob(repo, DEV_COMMIT, LIBRARY)
    if sha(before) != SOURCE_BASE_SHA or sha(parent) != PARENT_RAW_SHA:
        raise ValueError('Pinned raw base/parent bytes differ')
    if not latest_dev.startswith(before):
        raise ValueError('Pinned dev does not preserve the complete raw source base')
    dev_suffix = latest_dev[len(before):]
    if len(dev_suffix) != 2849 or sha(dev_suffix) != DEV_SUFFIX_SHA:
        raise ValueError('Pinned Glessner append differs from reviewed source e5')
    previous_parent = g.blob(repo, PREVIOUS_PARENT_COMMIT, LIBRARY)
    if previous_parent != parent + dev_suffix or sha(previous_parent) != PREVIOUS_INCOMING_SHA:
        raise ValueError('Previous96 raw document differs from exact a219 plus Glessner formula')
    kimball_source = g.blob(repo, KIMBALL_COMMIT, LIBRARY)
    if not kimball_source.startswith(latest_dev):
        raise ValueError('Pinned Kimball source does not preserve entire e5 raw document')
    kimball_suffix = kimball_source[len(latest_dev):]
    if len(kimball_suffix) != 2331 or sha(kimball_suffix) != KIMBALL_SUFFIX_SHA:
        raise ValueError('Pinned Kimball2331 raw append differs')
    if incoming != previous_parent + kimball_suffix or sha(incoming) != ONLY_REVIEWED_INCOMING_SHA:
        raise ValueError('Only exact a219 + Glessner2849 + Kimball2331 incoming bytes are allowed')
    return {'entire_parent_commit': PARENT_COMMIT, 'entire_parent_raw_bytes': len(parent),
            'entire_parent_raw_sha256': PARENT_RAW_SHA, 'incoming_startswith_entire_parent_raw': True,
            'glessner_source_commit': DEV_COMMIT, 'glessner_raw_append_bytes': len(dev_suffix),
            'glessner_raw_append_sha256': DEV_SUFFIX_SHA,
            'previous_parent_commit': PREVIOUS_PARENT_COMMIT, 'previous_parent_raw_sha256': PREVIOUS_INCOMING_SHA,
            'entire_previous_parent_prefix_preserved': True,
            'kimball_source_commit': KIMBALL_COMMIT, 'kimball_raw_append_bytes': len(kimball_suffix),
            'kimball_raw_append_sha256': KIMBALL_SUFFIX_SHA,
            'actual_new_parent_commit': NEW_PARENT_COMMIT,
            'incoming_exact_a219_plus_glessner_plus_kimball': True}


def validate_supersession_audit(path):
    if sha(path.read_bytes()) != SUPERSESSION_AUDIT_SHA:
        raise ValueError('Frozen PR1256 supersession audit manifest changed')
    manifest = json.loads(path.read_bytes())
    for entry in manifest['files']:
        data = (path.parent / entry['path']).read_bytes()
        if len(data) != entry['bytes'] or sha(data) != entry['sha256']:
            raise ValueError('Supersession audit input mismatch: ' + entry['path'])
    integrity = json.loads((path.parent / '3fa6-bounded-integrity.json').read_bytes())
    if integrity['head'] != NEW_PARENT_COMMIT or integrity['guarded_paths'] != 87 or not integrity['all_equal_a219']:
        raise ValueError('Supersession87 guard scope/head differs')
    lib = integrity['LIBERTIES']
    if (lib['sha256'] != ONLY_REVIEWED_INCOMING_SHA or not lib['96ca_complete_prefix'] or
            lib['append_bytes'] != 2331 or lib['append_sha256'] != KIMBALL_SUFFIX_SHA):
        raise ValueError('Supersession raw history bound differs')
    return {'manifest_sha256': SUPERSESSION_AUDIT_SHA, 'head': NEW_PARENT_COMMIT,
            'guarded_paths': 87, 'all_equal_a219': True, 'LIBERTIES': lib,
            'integrity_report_sha256': sha((path.parent / '3fa6-bounded-integrity.json').read_bytes())}


def run_stage(args, g):
    if not re.fullmatch('[0-9a-f]{64}', args.reviewed_liberties_sha256):
        raise ValueError('An explicit full lowercase reviewed incoming SHA256 is required')
    if args.reviewed_liberties_sha256 != ONLY_REVIEWED_INCOMING_SHA:
        raise ValueError('This bounded helper allows only root-reviewed incoming SHA ' + ONLY_REVIEWED_INCOMING_SHA)
    repo = args.repo.resolve()
    packet = args.packet.resolve()
    out = args.out.resolve()
    if out == repo or repo in out.parents:
        raise ValueError('Output must be outside the target worktree')
    bound_audit = validate_audit(args.parent_audit_manifest.resolve())
    supersession_audit = validate_supersession_audit(args.parent_supersession_audit_manifest.resolve())
    g.validate_packet(packet)
    if args.target_worktree:
        state = g.worktree_state(repo)
        target = state['head']
        incoming = g.working_blob(repo, LIBRARY)
    else:
        state = None
        target = g.run(repo, 'rev-parse', '--verify', args.target_ref + '^{commit}').stdout.decode().strip()
        incoming = g.blob(repo, target, LIBRARY)
    if incoming is None or sha(incoming) != args.reviewed_liberties_sha256:
        raise ValueError('Actual incoming LIBERTIES differs from the root-supplied reviewed SHA')
    before = g.blob(repo, g.BASE, LIBRARY)
    history_binding = validate_incoming(g, repo, before, incoming)
    after = (packet / LIBRARY).read_bytes()
    if sha(before) != SOURCE_BASE_SHA or not after.startswith(before):
        raise ValueError('Selected source base or append changed')
    addition = after[len(before):]
    ids = re.findall(rb'(?m)^#{2,4} (L-[A-Za-z0-9_-]+)\b', addition)
    if len(ids) != 12 or len(set(ids)) != 12:
        raise ValueError('Expected exactly twelve unique native liberty ids')
    original_append = g.append_doc
    calls = []

    def bounded_append(old, new, current, path):
        if path != 'docs/LIBERTIES.md':
            return original_append(old, new, current, path)
        if sha(old) != SOURCE_BASE_SHA or new != after or current != incoming:
            raise g.Conflict('Bounded LIBERTIES exception input differs from the reviewed receipt')
        # The frozen guard checks all native headings/ids against the ENTIRE
        # incoming document. Only the old-prefix precondition is superseded by
        # this exact incoming SHA. No incoming byte is replaced or decoded.
        result = original_append(b'', addition, current, path)
        if not result.startswith(current):
            raise g.Conflict('Bounded exception failed exact incoming-prefix preservation')
        if result != current and result[len(current):] != addition:
            raise g.Conflict('Bounded exception appended bytes outside the exact selected fragment')
        calls.append({'incoming_bytes': len(current), 'incoming_sha256': sha(current),
                      'result_bytes': len(result), 'result_sha256': sha(result),
                      'raw_incoming_prefix_exact': True, 'exact_append_or_idempotent': True})
        return result

    g.append_doc = bounded_append
    result = g.stage(repo, target, packet, out, args.target_worktree)
    report_path = out / 'report.json'
    report = json.loads(report_path.read_bytes())
    if report['status'] == 'STAGED_NOT_APPLIED' and len(calls) != 1:
        report['status'] = 'REFUSED_EXCEPTION_PROOF'
        report['conflicts'].append({'path': LIBRARY, 'reason': 'Expected exactly one bounded raw preservation proof'})
        result = 1
    if report['target_commit'] != target or report.get('target_worktree_state') != state:
        report['status'] = 'REFUSED_CONTEXT_DRIFT'
        report['conflicts'].append({'path': LIBRARY, 'reason': 'Target context changed during bounded staging'})
        result = 1
    receipt = {'kind': 'T3081_single_reviewed_LIBERTIES_raw_prefix_exception',
               'scope': 'Preserve every reviewed incoming byte; append only the twelve selected T3081 liberties. No rights/source/history waiver.',
               'target_mode': report['target_mode'], 'target_commit': target,
               'target_worktree_state': state,
               'root_supplied_reviewed_incoming_sha256': args.reviewed_liberties_sha256,
               'source_base_sha256': SOURCE_BASE_SHA,
               'selected_append_sha256': sha(addition), 'selected_append_bytes': len(addition),
               'selected_liberty_ids': [x.decode() for x in ids],
               'packet_manifest_sha256': g.PACKET_SHA,
               'original_helper_sha256': ORIGINAL_SHA,
               'parent_audit_manifest_sha256': AUDIT_SHA, 'parent_audit_inputs': bound_audit,
               'parent_supersession_audit': supersession_audit,
               'incoming_history_binding': history_binding,
               'parent_audit_scope': 'b7f verifies a219 historical updates/relocated Hogan;36f verifies PR1256 exact87 preservation and only2331B Kimball addition. No other incoming history delta allowed.',
               'proof': calls,
               'review_limit': 'Stage only. Root checks the actual final merged incoming liberty diff against the frozen audit before explicit application. No automatic merge/rights/gate approval.'}
    (out / 'reviewed-liberties-incoming.md').write_bytes(incoming)
    (out / 'selected-liberty-append.md').write_bytes(addition)
    receipt_path = out / 'reviewed-liberties-receipt.json'
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    report['bounded_liberties_receipt_sha256'] = sha(receipt_path.read_bytes())
    report['bounded_liberties_exception'] = True
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'receipt': str(receipt_path),
                      'receipt_sha256': report['bounded_liberties_receipt_sha256'],
                      'raw_incoming_sha256': sha(incoming)}, indent=2))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument('--target-ref')
    target.add_argument('--target-worktree', action='store_true')
    parser.add_argument('--reviewed-liberties-sha256', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--packet', type=Path, default=Path('/tmp/log82-authored-checkpoint-20261023T2324'))
    parser.add_argument('--original-helper', type=Path, default=ORIGINAL)
    parser.add_argument('--parent-audit-manifest', type=Path, default=AUDIT_PATH)
    parser.add_argument('--parent-supersession-audit-manifest', type=Path, default=SUPERSESSION_AUDIT_PATH)
    args = parser.parse_args()
    try:
        g = load_original(args.original_helper.resolve())
        return run_stage(args, g)
    except (ValueError, OSError, subprocess.CalledProcessError,
            g.Conflict if 'g' in locals() else ValueError) as e:
        parser.exit(2, 'REFUSED: ' + str(e) + '\n')


if __name__ == '__main__':
    raise SystemExit(main())
