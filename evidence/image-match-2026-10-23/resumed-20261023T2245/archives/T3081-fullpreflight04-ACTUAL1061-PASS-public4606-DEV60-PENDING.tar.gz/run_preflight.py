from pathlib import Path
import subprocess,json,datetime,os,hashlib,shutil,sys
r=Path('/tmp/chicago-log-integration/chicago/4d');o=Path(__file__).resolve().parent
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
env={**os.environ,'TMPDIR':'/workspace/tmp-t3081','PATH':'/workspace/shared/tools/usr/bin:'+os.environ['PATH'],'CHECK_JOBS':'2','C4D_GATE_REQUIRE_READERS':'1','PYTHONDONTWRITEBYTECODE':'1'}
diff=lambda:subprocess.check_output(['git','diff','--binary','HEAD'],cwd=r)
assert json.loads(Path('/workspace/T3081-dev67-native04/receipt.json').read_bytes())['status']=='PASS'
assert json.loads(Path('/workspace/T3081-dev67-native04/final-105-asset-guards.json').read_bytes())['status']=='PASS'
initial=diff();(o/'preflight-source.patch').write_bytes(initial)
s={'status':'RUNNING','started':now(),'controller_pid':os.getpid(),'HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'merge_parent':subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=r,text=True).strip(),'command':['bash','./tools/preflight.sh'],'CHECK_JOBS':2,'C4D_GATE_REQUIRE_READERS':1,'source_diff_sha256':hashlib.sha256(initial).hexdigest()};p=o/'receipt.json'
def save():p.write_text(json.dumps(s,indent=2)+'\n')
save()
with(o/'preflight.log').open('w')as f:
 q=subprocess.Popen(s['command'],cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env);s['child_pid']=q.pid;save();code=q.wait()
s.update(exit_code=code,finished=now(),status='PASS'if code==0 else'FAILED',source_bytes_unchanged=diff()==initial)
for name,src in [('check.log','/tmp/preflight-check.log'),('changelog.log','/tmp/preflight-cl.log'),('ids.log','/tmp/preflight-ids.log')]:
 if Path(src).exists():shutil.copy2(src,o/name);s[name+'_sha256']=hashlib.sha256((o/name).read_bytes()).hexdigest()
if not s['source_bytes_unchanged']:s['status']='FAILED_SOURCE_MOVED'
s['preflight_sha256']=hashlib.sha256((o/'preflight.log').read_bytes()).hexdigest();save();print(json.dumps(s,indent=2));sys.exit(0 if s['status']=='PASS' else(code or 2))
