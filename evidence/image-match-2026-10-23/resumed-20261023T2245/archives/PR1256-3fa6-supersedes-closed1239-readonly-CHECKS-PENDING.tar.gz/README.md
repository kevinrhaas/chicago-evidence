Read-only bounded PR1239→PR1256 supersession review.

Owner closed unmerged salvage draft1239 and opened non-draft1256 on3fa6. 96ca→3fa6 merges dev e5+Kimball9f and preserves all87 owned frame/source/credit/V2 guards byte-exact a219. LIBERTIES preserves full96ca prefix +2331B Kimball append; exact hashes in bounded integrity receipt.9f→ff808 is only T3076 changelog fold. Actual PR1256 head and body snapshot captured.

No writers, producers, heavy gates, browser, lap changes or approval. Prior gate1266bb/96ca+e5 is historical; new head checks pending at last ordinary poll00:02.
