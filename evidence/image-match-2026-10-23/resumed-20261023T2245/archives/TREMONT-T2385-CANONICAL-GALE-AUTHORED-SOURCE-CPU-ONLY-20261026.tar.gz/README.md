# T-2385 native authoring checkpoint003

Base9f7a31e35864e6ff7af221c5089b90c5160441d8; branch steward/t2385-tremont-gale-1835. Apply working-tree.patch to that base and copy new-files paths. Recoverable uncommitted draft, NOT exported/full-gated/merged code. Original normal claim f0037d5 expires2026-10-26 03:07UTC.

Default Gale1835-framed reading30x20ft/two-storey/yellow,5.45m walls, both street planes preserved, explicit roof-staff flag anchor recomputed. Native stock shutters need1.95m bays versus1.8288m available. Canonical form.shutters is explicitly FALSE/RECONSTRUCTED as a simplifying choice, NOT Gale-attested historical absence. Parent approved this native path; no sharedparameter changes or assertionweakening. Pictured shutters stay in nativegifford-reading version along with original3storey50x30/unpainted alternative and all oldgeometrytestcoverage. The exact matching-input native seed adopted oldGLBs, but sourcechanges now require2genuinefinalexports.

PASS: selectedschemas/nativeparams bothrecords; provenance0errors (existing sidewalktier warning); forwardLib38values/0unclaimed; namepool4heads/13refusals withoutredeal; pictureCPU16tests covering2storey28windows/zeroShutters +3storey44windows/88leaves; nativeflag5tests; diff whitespace.

PENDING: rootvalidatedGreenTreepublichead andheavylease; native2exports/web +compile/entrance/apron/clearance/protectedpopulation/fixedpoint; actualcurrentpublishedappdesktop/mobile/default/version/Images; fullcheck/preflight/smoke thenPRdev+merge. Original2385remainsOPEN for source2vs3storey/defaultmissingpicturedshutters. No fakecanonicalpicturematch.
