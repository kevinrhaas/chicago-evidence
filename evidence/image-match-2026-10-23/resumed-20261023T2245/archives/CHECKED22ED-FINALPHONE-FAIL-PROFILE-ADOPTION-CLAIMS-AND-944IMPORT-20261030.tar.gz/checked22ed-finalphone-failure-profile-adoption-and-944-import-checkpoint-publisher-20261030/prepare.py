from pathlib import Path
import json,hashlib,stat
W=Path('/workspace');O=Path(__file__).parent;old=json.loads((W/'checked64d-firstfort-native-and-845-import-progress-checkpoint-publisher-20261030/MANIFEST.json').read_text());oldrows={r['path']:r for r in old['files']};rows={};refs=[]
def add(p,e=None):
 p=Path(p);assert p.is_file()and not p.is_symlink();b=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode);row={'path':str(p),'relative_path':str(p.relative_to(W)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':mode}
 if e:
  assert len(b)==e['bytes']and row['sha256']==e['sha256'],p
  if 'mode'in e:assert mode==(int(e['mode'],0)if isinstance(e['mode'],str)else e['mode'])
 if oldrows.get(str(p))==row:refs.append({'path':str(p),'sha256':row['sha256'],'bytes':len(b),'mode':mode,'checkpoint':'719','archive_member':row['relative_path']});return
 rows[str(p)]=row
R=W/'PR1456-rail-profile-normal-candidate-gt-20261030';M=R/'CLOSED-MANIFEST.json';j=json.loads(M.read_text());add(M);ls=j.get('files',j.get('members'));ls=[{'path':p,**r}for p,r in ls.items()]if isinstance(ls,dict)else ls
for r in ls:
 p=Path(r.get('path',r.get('file')));add(p if p.is_absolute()else R/p,r)
for d in [*W.glob('PR1456-final830-*'),W/'PR1456-native-22ed-published-publisher-20261030',W/'currentdev944-incremental-price-publisher-20261030',W/'PR1456-incremental944-import-publisher-20261030',W/'OLD845-raw-binding-retirement-publisher-20261030',W/'four-case-code-rest-transport-v6-192path-bound-20261030']:
 for p in d.rglob('*'):
  if p.is_file()and not p.is_symlink()and not any(v in ('__pycache__','profile','profiles','fixture','.git')for v in p.parts):add(p)
C=W/'original-ready-CB-school-sparse-renewals-publisher-20261030'
for p in C.iterdir():
 if p.is_file()and p.name!='PUBLISHED-RENEWAL.json'and p.suffix in ['.json','.md','.log','.py']:add(p)
add(C/'bin/git')
for n in ['SESSION-RECOVERY-root-20261030T0523.md','GT-WRITER-RECOVERY-830-GATE-LIVE-20261030T0526.md','PR1456-dev-after830-readonly-scope-publisher-20261030.json','owned-closed-Mary-import-preimages-verified-dedup-root-20261030.json']:add(W/n)
for p in W.glob('owned-closed-Mary-import-preimages*gz'):add(p)
refnote={'status':'EXACT_UNCHANGED_PAYLOADS_ALREADY_STRICTLY_DURABLE719','authority':'https://github.com/kevinrhaas/chicago-evidence/blob/838147139a7e03dd4d87af9d1367663e68ba5cb9/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md','rows':sorted({r['path']:r for r in refs}.values(),key=lambda r:r['path'])};p=O/'PRIOR719-EXACT-REFERENCES.json';p.write_text(json.dumps(refnote,indent=2)+'\n');add(p);add(O/'prepare.py')
note="""The checked native commit 22ed686f, tree df5a6513, has genuine parents 64d and 830. Its full source gate passed 1,105 checks in 788.045 seconds with all seven guards, configuration and reapers exact. Four PR questions and four image gates passed. Normal force-false publication preserved its native SHA, tree, parents and all 134 changed paths through immutable readback. Its FINAL same-head phone FAILED at 400.1480436 MiB / 400, with no page errors and all children reaped. This remains a source-only checkpoint: no final phone pass, dev merge or original ticket completion. The required GitHub gate is absent because newer dev 944 conflicts.

The earlier one-line rail-profile candidate passed 122 native checks and an external trial phone at 399.9564657 MiB. Root reviewed all six paired captures: AIR zero differences, SOUTH 86 pixels with maximum one, NORTH 33 with maximum one; the wrong control changed substantially. Raw visual exit 1 preserves inherited AIR/NORTH triangle-cap failures on both sides, not a whole performance-smoke pass. Its 32-member packet, actual two-path adoption and the closed 61-owner pass (253.185 seconds, last unchanged, 44 canonical binaries and timestamp-only workbook proof) are saved. The earlier trial pass does not supersede the failed final phone. The new uniform-ground allocation research remains outside this checkpoint.

Official native ticket renewals are durable: LIVE SAME-OWNER Green Tree 9ed1547f expires 08:18:54; expired SAME-OWNER Carpenter eaa28e9a expires 08:27:31. Original no-force refusals and exact reviewed historical branches are preserved. Only claimed_at/by changed, and all 3,231 foreign paths, modes and SHAs remained exact, with normal force-false publication and no primary or nested-mirror writes. School 252 remains valid until 07:22. The old closed 845 raw consumer map alone was retired after explicit release and fresh immutable checkpoint-719 member verification; its exact restoration pointer remains, with other receipts and current data untouched.

Root's exact hardlink pass reclaimed 36,388,864 bytes from eleven closed duplicate JSON/public-JS files while retaining every path, byte and mode with an original-time ledger. The missing-only 944 import closed successfully: 56 canonical objects, complete 18,154 tip and 18,169 source-head leaf/type/size proofs, only local origin/dev CAS from 830 to 944, with HEAD 22ed, index, configuration, working bytes and other refs unchanged. Remote dev was still 944 at closure. No 944 composition, phone or gate is claimed here. External transport v6 changes only the finite path ceiling/help from 128 to 192; exact count, path/SHA, native tree/parents, scope, 64-MiB and force-false guards remain. Dated recovery notes are preserved; unchanged checkpoint-719 payloads are referenced rather than copied. Live 944 work and private profiles are excluded."""
b=(json.dumps({'status':'CHECKED22ED_SOURCE_ONLY_FINAL_PHONE_FAIL_WITH_CLOSED_PROFILE_ADOPTION_CLAIMS_AND_944_IMPORT','scope_note':note,'files':sorted(rows.values(),key=lambda r:r['relative_path'])},indent=2)+'\n').encode();(O/'MANIFEST.json').write_bytes(b);print(json.dumps({'files':len(rows),'bytes':sum(r['bytes']for r in rows.values()),'prior719_refs':len(refnote['rows']),'manifest_sha256':hashlib.sha256(b).hexdigest()},indent=2))
