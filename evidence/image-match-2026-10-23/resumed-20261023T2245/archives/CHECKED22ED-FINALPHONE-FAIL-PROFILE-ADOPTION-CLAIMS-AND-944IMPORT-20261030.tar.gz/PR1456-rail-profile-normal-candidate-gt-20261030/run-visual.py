from pathlib import Path
import datetime,gzip,hashlib,json,os,shutil,subprocess,time
O=Path(__file__).parent
raw=(O/'phone-experiment.py').read_text();prefix=raw[:raw.index("assert not(O/'BINDING.json').exists()")];ns={'__file__':str(O/'phone-experiment.py')};exec(compile(prefix,str(O/'phone-experiment.py'),'exec'),ns)
expected=json.loads(gzip.decompress((O/'ALL-CONSUMER-BINDINGS.json.gz').read_bytes()));binding=json.loads((O/'BINDING.json').read_bytes());state=binding['state'];assert ns['consumer_map']()==expected and ns['git_state']()==state
assert ns['sha']((ns['A']/'renderers/web/js/railway.js').read_bytes())=='e1c0fea0e26bf9f1062a6c91fe5ab4c70347f5ddec0adfa4a1c4d12f46cf2b5d'
assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
start=time.monotonic();env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
with(O/'visual.log').open('x')as log:q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(O/'VISUAL-REAPER.json'),'--','taskset','-c','0,1,3,4','node',str(O/'visual.mjs')],env=env,stdout=log,stderr=subprocess.STDOUT)
r=json.loads((O/'VISUAL-REAPER.json').read_bytes());j=json.loads((O/'VISUAL.json').read_bytes());guards={'all_consumer_bytes_modes_links_fileset_exact':ns['consumer_map']()==expected,'HEAD_MERGE_HEAD_stagedtree_index_config_allrefs_and_stagedshas_exact':ns['git_state']()==state,'all_children_reaped':r['all_children_reaped']};assert all(guards.values());assert j and len(j['stands'])==3 and not j['errors']and not j['bad']
rows=[]
for stand in j['stands']:
 structural=stand['allNonNormalStreamsIndicesAndMaterialsExact']and stand['oldStats']['triangles']==stand['compactStats']['triangles']and stand['oldStats']['drawCalls']==stand['compactStats']['drawCalls']and stand['restoredVsFloat']['pixelsDiffering']==0 and stand['maxComponentError']<=1/254+1e-6 and stand['maxAngleDeg']<1 and(stand['name']=='air'or stand['wrongNormalPositiveControl']['pixelsDiffering']>0)
 assert structural
 rows.append({'stand':stand['name'],'normal_bytes_saved':stand['normalBytesSaved'],'visible_profile_bytes_saved':stand['visibleProfileBytesSaved'],'old_within_budget':stand['oldStats']['withinBudget'],'compact_within_budget':stand['compactStats']['withinBudget'],'structural_normal_scope_pass':True,'pixel_difference':stand['compactVsFloat'],'wrong_normal_positive_control':stand['wrongNormalPositiveControl']})
log=(O/'visual.log').read_text();assert q.returncode==0 or(q.returncode==1 and'Error: nativebudget'in log)
out={'status':'ACTUAL830_LIGHT_PROFILE_THREE_HELD_FRAMES_CLOSED_ROOT_VIEW_PENDING','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_visual_exit':q.returncode,'seconds':time.monotonic()-start,'guards':guards,'stands':rows,'limits':'All narrow normal/otherstream/sameframe checks asserted. Native AIR/NORTH triangle budget failures may remain in BOTH baseline/candidate; rawexit retained, no budget assertion weakened, no all-budget pass claim. Root directview required before primary adoption. Full61/source1105/final samehead phone/CI/merge still owed.'};(O/'VISUAL-CLOSURE.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
