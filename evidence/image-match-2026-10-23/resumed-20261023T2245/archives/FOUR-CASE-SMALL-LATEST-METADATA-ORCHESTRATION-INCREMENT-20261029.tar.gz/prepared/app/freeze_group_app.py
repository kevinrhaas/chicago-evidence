"""Freeze the final four-case published unit after native closure; no browser run."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path(os.environ['EARLY_GROUP_APP_HOME'])
assert os.environ.get('EARLY_GROUP_APP_READY')=='current-native-and-publish-closed'
assert not O.exists();O.mkdir(parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
paths=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted((R/'site/4d').rglob('*'))if p.is_file()]
assert paths
binding={'at':now,'paths':paths,'scope':'Actual final published site inputs, frozen once for all cases; metadata only, no app acceptance.'}
site=O/'SOURCE-BINDINGS.json';site.write_text(json.dumps(binding,indent=2)+'\n')
images=json.loads((A.parent/'prairie_1904_v1/data/images.json').read_text())['images']
store=json.loads((A.parent/'prairie_1904_v1/research/images/STORE.json').read_text())
entrances=json.loads((A/'data/enclosures/town_entrance_aprons.json').read_text())['entrances']
results=[]
for label,sid,phase_id,camera_name in [('miller','miller_house','log_frame_1827','wolf-point-1833'),('hogan','hogan_store','log_1831','cameron_1833'),('mary','st_marys_church','frame_1833','moss-engraving'),('lighthouse','chicago_lighthouse_1832','tower_1832','castelnau-1842')]:
 record_path=A/'data/structures'/(sid+'.json');record=json.loads(record_path.read_text());phase=next(p for p in record['phases']if p['id']==phase_id)
 side_path=A/'data/sidecars/1835'/(sid+'.json');side=json.loads(side_path.read_text());attrs=phase['form']
 for k,v in attrs.items():
  assert side['attributes'][k]['value']==v['value'],(sid,k)
  assert side['attributes'][k]['confidence']==v['confidence'],(sid,k)
 camera=A/'data/reference_views'/sid/(camera_name+'.json');cam=json.loads(camera.read_text());assert cam['diagnostic_only']is True
 iid=cam['library_image'];matches=[r for r in images if r['id']==iid];assert len(matches)==1
 image=matches[0];display=Path(image['local']['display']).name;thumb=Path(image['local']['thumb']).name
 photo={'id':iid,'display':display,'thumb':thumb,'base_url':store['base_url'],'display_binding':store['files'][display],'thumb_binding':store['files'][thumb]}
 name=sid+'__'+phase_id+'.glb';master=A/'assets/gltf'/name;web=A/'assets/web'/name;assert sha(web)==sha(R/'site/4d/data/gltf'/name)
 assert side['grade']['value']=='attested'and side['grade']['pictures']==[iid]
 assert side['grade']['why']=='Pictured: a picture on the Images tab shows it.'
 if label=='miller':
  assert attrs['frame_addition_ridge_stack']['confidence']=='reconstructed'
  if'frame_addition_front_set_out'in attrs:
   row=attrs['frame_addition_front_set_out']['value'];assert sum(r['kind']=='window'and r['z0']>=attrs['frame_addition_height_m']['value']/2 for r in row)==3
  else:assert attrs['frame_addition_upper_windows']['value']==3
 elif label=='hogan':
  assert attrs['end_gable_courses']['value']=='+x'and attrs['ridge_stack_cap_m']['value']==[.1,.12]
  assert attrs['ridge_stack_cap_m']['confidence']=='reconstructed'
 elif label=='mary':
  assert attrs['front_window_sill_m']['value']==1.4 and attrs['front_window_sill_m']['confidence']=='reconstructed'
  assert sha(master)=='1443ab7dc50739a211a41ba87eb3ab31c85644c344469fdd578ad80101b6bbaf'
 else:assert sha(master)=='ae855793a983ff884b2653479c74fe517d3f8f2f14b6eae606f972a68373224d'
 doors=[d for d in entrances if d['structure_id']==sid]
 if label!='lighthouse':assert doors
 expected={'at':now,'source_binding':{'head':head,'working_snapshot_uncommitted':bool(subprocess.check_output(['git','status','--porcelain=v1'],cwd=R,text=True).strip()),'record_sha256':sha(record_path),'master_sha256':sha(master),'WEB_sha256':sha(web),'native_sidecar_sha256':sha(side_path),'canonical_camera_sha256':sha(camera)},'site_binding_file':str(site),'sidecar':side,'grade':side['grade'],'attributes':attrs,'placement':side['placement'],'entrances':doors,'WEB_sha256':sha(web),'photo':photo}
 target=O/label;target.mkdir();(target/'APP-EXPECTED.json').write_text(json.dumps(expected,indent=2)+'\n');results.append({'case':label,'expected':str(target/'APP-EXPECTED.json'),'WEB_sha256':sha(web)})
# Compatibility locator for the prepared single-case scripts. The combined app
# reads this same binding, never a separately frozen site graph.
(O/'miller/SOURCE-BINDINGS.json').write_text(site.read_text())
(O/'PREPARED.json').write_text(json.dumps({'status':'CURRENT_FINAL_GROUP_APP_INPUTS_FROZEN_NOT_RUN','site_binding_file':str(site),'cases':results},indent=2)+'\n')
print(json.dumps({'cases':results,'site_members':len(paths),'app_NOT_RUN':True},indent=2))
