import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

// Check the visitor's real thumbnail -> full credited picture -> close flow.
// Native hosting verification remains separate; this verifies the delivered
// full copy's actual browser response against the frozen STORE record.
export async function reviewHeldPicture(page,pane,expected,label,out) {
  assert(expected.photo,'Freeze the current canonical library picture');
  const p=expected.photo,imgs=pane.locator('img');assert.equal(await imgs.count(),1,'one governing held composition');
  const thumb=imgs.first();await thumb.scrollIntoViewIfNeeded();
  await thumb.evaluate(img=>new Promise((resolve,reject)=>{
    if(img.complete){img.naturalWidth>0?resolve():reject(Error('thumbnail did not load'));return;}
    const timer=setTimeout(()=>reject(Error('thumbnail load timeout')),60000);
    img.addEventListener('load',()=>{clearTimeout(timer);resolve();},{once:true});
    img.addEventListener('error',()=>{clearTimeout(timer);reject(Error('thumbnail load failed'));},{once:true});
  }));
  assert.equal(new URL(await thumb.getAttribute('src')).pathname.split('/').at(-1),p.thumb);
  const url=new URL(p.display,p.base_url).href;
  const responsePromise=page.waitForResponse(r=>r.url()===url&&r.status()===200,{timeout:90000});
  await pane.locator('button.ph-tile').click();
  const response=await responsePromise,bytes=await response.body();
  assert.equal(bytes.length,p.display_binding.bytes);
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),p.display_binding.sha256);
  await page.waitForFunction(url=>{const v=document.querySelector('.pic-viewer');const i=v?.querySelector('[data-pv-img]');return v&&!v.hidden&&i?.complete&&i.naturalWidth>0&&i.currentSrc===url;},url,{timeout:90000});
  const observed=await page.locator('.pic-viewer').evaluate(v=>({text:v.innerText,credit:v.querySelector('[data-pv-credit]')?.innerText,count:v.querySelector('[data-pv-count]')?.innerText,image:v.querySelector('[data-pv-img]')?.currentSrc,width:v.querySelector('[data-pv-img]')?.naturalWidth}));
  assert.equal(observed.count,'1 / 1');assert(observed.credit?.trim());
  await page.screenshot({path:path.join(out,label+'-full-credited-picture.png')});
  await page.locator('.pic-viewer [data-pv-close]').click();
  assert(await page.locator('.pic-viewer').isHidden());
  assert.equal(await page.locator('.pic-viewer [data-pv-img]').getAttribute('src'),null,'closing releases the full image DOM source');
  fs.writeFileSync(path.join(out,label+'-full-credited-picture.json'),JSON.stringify({status:'PASS',...observed,actual_browser_HTTP:response.status(),sha256:p.display_binding.sha256,bytes:bytes.length,closed_and_source_released:true},null,2)+'\n');
}
