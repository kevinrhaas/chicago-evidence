import {reviewHeldPicture} from './held-picture-review.mjs';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require = createRequire('/workspace/shared/node/node_modules/playwright/package.json');
const {chromium} = require('playwright');
const root = process.env.GROUP_APP_SITE || '/workspace/chicago/site';
const home=process.env.HOGAN_APP_HOME;assert(home,'Freeze current Hogan inputs first');
const expected=JSON.parse(fs.readFileSync(path.join(home,'APP-EXPECTED.json')));
for(const b of JSON.parse(fs.readFileSync(expected.site_binding_file)).paths)assert.equal(crypto.createHash('sha256').update(fs.readFileSync(b.path)).digest('hex'),b.sha256,b.path);
const sid = 'hogan_store';
const out = process.env.HOGAN_APP_OUT;
assert(out, 'Use a fresh evidence directory');
fs.mkdirSync(out);
const save = (name, value) => fs.writeFileSync(path.join(out, name), JSON.stringify(value, null, 2)+'\n');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const expectedWeb=expected.WEB_sha256;
const types = {'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary'};
const serverErrors = [];
const server = http.createServer((req,res) => {
  try {
    const rel = decodeURIComponent(new URL(req.url,'http://localhost').pathname).replace(/^\/+/, '');
    assert(!rel.split('/').includes('..'));
    let file = path.join(root,rel);
    if(fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file,'index.html');
    if(!fs.existsSync(file)){res.writeHead(404).end();return;}
    res.setHeader('Content-Type',types[path.extname(file)] || 'application/octet-stream');
    fs.createReadStream(file).on('error',e=>{serverErrors.push(e.message);res.destroy(e);}).pipe(res);
  } catch(e){serverErrors.push(e.message);res.writeHead(500).end();}
});
let browser;
const results=[];
try {
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  const launchOptions={executablePath:process.env.PW_EXECUTABLE || '/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']};
  if(process.env.HOGAN_TRUST_PROFILE){
    const persistent=await chromium.launchPersistentContext(process.env.HOGAN_TRUST_PROFILE,{...launchOptions,ignoreHTTPSErrors:false});
    browser=persistent.browser();
  } else browser=await chromium.launch(launchOptions);
  for(const [name,width,height,touch] of [['mobile',390,780,true],['desktop',1280,800,false]].filter(x=>!process.env.HOGAN_VIEWPORT||x[0]===process.env.HOGAN_VIEWPORT)) {
    const context = await browser.newContext({viewport:{width,height},hasTouch:touch,deviceScaleFactor:touch?2:1});
    const errors=[], failures=[], responses=[], responseWork=[];
    const page = await context.newPage();
    page.setDefaultTimeout(180000);
    page.on('pageerror',e=>errors.push(e.message));
    page.on('response',r=>{
      if(r.status()>=400) failures.push({url:r.url(),status:r.status()});
      if(r.url().includes('hogan_store__log_1831.glb')) responseWork.push(r.body().then(b=>responses.push({url:r.url(),bytes:b.length,sha256:sha(b)})));
    });
    page.on('requestfailed',r=>{if(r.failure()?.errorText!=='net::ERR_ABORTED') failures.push({url:r.url(),failure:r.failure()});});
    try {
      await context.addInitScript(()=>localStorage.setItem('chicago4d.researcher','on'));
      const url=`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835&keep-geometry=1`;
      assert.equal((await page.goto(url,{timeout:300000})).status(),200);
      await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:300000,polling:1000});
      await page.evaluate(async sid=>{
        const a=window.__chicago4d, end=Date.now()+90000;
        while(a.welcome?.state!=='world' && Date.now()<end){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}
        if(a.welcome && a.welcome.state!=='world')throw Error('welcome did not enter world');
        document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();
        a.setAnimationHold(true);a.navigator.dock();a.setConfidenceView(false);
        if(!a.frame(sid))throw Error('target missing from live scene');
        await a.capture(1);
      },sid);
      const runtime=await page.evaluate(sid=>{const a=window.__chicago4d;return {scene:a.scene?.id,sidecar:a.registry.get(sid)?.sidecar,stats:a.stats()};},sid);
      assert.equal(runtime.scene,'1835');assert.equal(runtime.sidecar.id,sid);assert.deepEqual(runtime.sidecar,expected.sidecar);
      assert.equal(runtime.sidecar.grade.value,'attested');assert.deepEqual(runtime.sidecar.grade.pictures,[expected.photo.id]);assert.equal(runtime.sidecar.grade.why,'Pictured: a picture on the Images tab shows it.');assert(runtime.stats.withinBudget);
      save(name+'-runtime.json',runtime);
      await page.screenshot({path:path.join(out,name+'-normal.png')});
      await page.evaluate(async()=>{const a=window.__chicago4d;a.setConfidenceView(true);await a.capture(1);});
      const graded=await page.evaluate(()=>({active:window.__chicago4d.confidenceView,stats:window.__chicago4d.stats()}));
      assert(graded.active&&graded.stats.withinBudget);save(name+'-ByGrade.json',graded);
      await page.screenshot({path:path.join(out,name+'-ByGrade.png')});
      await page.evaluate(async()=>{const a=window.__chicago4d;a.setConfidenceView(false);await a.capture(1);});
      await page.evaluate(async sid=>{const a=window.__chicago4d;a.pick(sid);await a.navigator.select('inspect');a.navigator.open(2);},sid);
      await page.waitForFunction(sid=>document.querySelector('#nav-app-inspect')?.dataset.structure===sid,sid);
      for(const key of ['photos','sources','research']){
        await page.locator(`#nav-app-inspect [data-insp-tab="${key}"]`).click();
        await page.waitForFunction(k=>document.querySelector(`#nav-app-inspect [data-insp-pane="${k}"]`)?.dataset.filled==='yes',key);
        const pane=page.locator(`#nav-app-inspect [data-insp-pane="${key}"]`);
        await pane.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});
        if(key==='photos') {
          const images=pane.locator('img');
          for(let i=0;i<await images.count();i++){
            await images.nth(i).scrollIntoViewIfNeeded();
            await images.nth(i).evaluate(img=>new Promise((resolve,reject)=>{
              if(img.complete){img.naturalWidth>0?resolve():reject(Error('picture failed to load'));return;}
              const timer=setTimeout(()=>reject(Error('picture load timed out')),30000);
              img.addEventListener('load',()=>{clearTimeout(timer);resolve();},{once:true});
              img.addEventListener('error',()=>{clearTimeout(timer);reject(Error('picture failed to load'));},{once:true});
            }));
            await page.screenshot({path:path.join(out,`${name}-credited-picture-${i+1}.png`)});
          }
        }
        const card=await pane.evaluate(p=>({text:p.innerText,visible:p.checkVisibility(),pageOverflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1,images:[...p.querySelectorAll('img')].map(i=>({src:i.currentSrc,loaded:i.complete&&i.naturalWidth>0}))}));
        save(name+'-'+key+'-observed.json',card);
        assert(card.visible&&!card.pageOverflow&&!card.paneOverflow);assert.match(card.text,/Cameron|post.?office|1833/i);
        if(key==='photos'){await reviewHeldPicture(page,pane,expected,name,out);assert.equal(card.images.length,1);assert(card.images.every(i=>i.loaded));assert.match(card.text,/Cameron/);assert.match(card.text,/1833/);assert.doesNotMatch(card.text,/From this spot/i);}
        else assert.match(card.text,/Hogan|Cameron|store|post.?office/i);
        if(key==='research'){assert.match(card.text,/Attested\. Pictured: a picture on the Images tab shows it\./);assert.doesNotMatch(card.text,/Pictured: 2 of the pictures/);}
        save(name+'-'+key+'.json',card);await page.screenshot({path:path.join(out,name+'-'+key+'.png')});
      }
      const ground=await page.evaluate(async({sid,expectedDoors})=>{
        const a=window.__chicago4d,doc=await fetch('../data/enclosures/town_entrance_aprons.json').then(r=>{if(!r.ok)throw Error('native entrances unavailable');return r.json();}),doors=doc.entrances.filter(d=>d.structure_id===sid);
        if(JSON.stringify(doors)!==JSON.stringify(expectedDoors)||!doors.length)throw Error('current native door binding differs');a.setFly(false);a.navigator.dock();a.popup.close();const samples=[];
        for(const door of doors){const b=door.bearing_deg*Math.PI/180;for(const distance of[3,2]){const e=door.at_local_enu_m[0]+Math.sin(b)*distance,n=door.at_local_enu_m[1]+Math.cos(b)*distance;a.walker.teleport({local_e:e,local_n:n,yaw_deg:(door.bearing_deg+180)%360});await a.capture(1);samples.push({door:door.id,distance,e,n,water:a.terrain.isWater(e,n),blocked:a.router.blockedAt(e,n),surface:a.walker.surfaceAt(e,n),ground:a.walker.state.groundY,eye:a.walker.state.eyeY,actualE:a.walker.state.e,actualN:a.walker.state.n,flying:a.walker.state.flying,hudFlying:a.hud.flying,intentFlying:a.intent.flying});}}
        return{doors,samples,scope:'Existing current compiled exterior door approaches; no indoor or passable proxy claim.'};
      },{sid,expectedDoors:expected.entrances});
      for(const p of ground.samples){assert(!p.water&&!p.blocked);assert(!p.flying&&!p.hudFlying&&!p.intentFlying);assert(Math.abs(p.ground-p.surface)<1e-6);assert(p.eye>p.ground);assert(Math.hypot(p.actualE-p.e,p.actualN-p.n)<.01);}
      save(name+'-ground.json',ground);await page.screenshot({path:path.join(out,name+'-ground.png')});
      await Promise.all(responseWork);assert(responses.length>0);assert(responses.every(r=>r.sha256===expectedWeb));
      assert.deepEqual(errors,[]);assert.deepEqual(failures,[]);assert.deepEqual(serverErrors,[]);
      results.push({viewport:name,status:'PASS',url,errors,failures,selectedWebResponses:responses});
      save(name+'-RESULT.json',results.at(-1));
    } catch(e){save(name+'-FAIL.json',{message:e.message,stack:e.stack,errors,failures,responses});throw e;}
    finally {await context.close();}
  }
  save('RESULT.json',{status:'PASS',results,scope:'Bounded actual published Hogan Normal/ByGrade and credited Photos/Sources/Research review at both viewports. One canonical held image, singular attested wording, exact selected WEB and no invented historical From this spot. No timing/performance, whole18, full3 or automatic originalDONE claim.'});
} finally {
  if(browser)await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));
}
