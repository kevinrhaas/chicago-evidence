"""Normally FF the owned branch, then compose exact own deltas entrywise.

Use only after the accepted predecessor is imported and its merge is verified.
Every prospective content union is checked before the retained stash/ref action.
"""
from pathlib import Path
import argparse,copy,datetime,hashlib,json,os,subprocess
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--accepted-base',required=True);p.add_argument('--out',required=True,type=Path);p.add_argument('--prepare-tree',action='store_true',help='Compose an immutable unaccepted predecessor tree in a PRIVATE index only; no source/ref/stash mutation.');args=p.parse_args()
if not args.prepare_tree:assert os.environ.get('EARLY_GROUP_ACCEPTED_PREDECESSOR')=='actual-qualified-TGT-merge-verified'
R=Path('/workspace/chicago');O=args.out;assert not O.exists();O.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
def g(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
def text(*a):return g(*a).decode().strip()
def blob(ref,rel):return g('show',ref+':'+rel)
def save(name,v):(O/name).write_text(json.dumps(v,indent=2)+'\n')
oldhead=text('rev-parse','HEAD');target=args.accepted_base
if args.prepare_tree:assert text('cat-file','-t',target)=='tree'
else:assert text('rev-parse','origin/dev')==target
assert not text('ls-files','-u')and not(R/'.git/MERGE_HEAD').exists()
if not args.prepare_tree:assert subprocess.run(['git','merge-base','--is-ancestor',oldhead,target],cwd=R).returncode==0
status=g('status','--porcelain=v1','-z','--untracked-files=all');changed=[(row[:2].decode(),row[3:].decode())for row in status.split(b'\0')if row]
assert changed and all(rel.startswith(('chicago/4d/','chicago/prairie_1904_v1/research/images/'))for _,rel in changed)
target_paths=set(text('ls-tree','-r','--name-only',target).splitlines());oldpaths=set(text('ls-tree','-r','--name-only',oldhead).splitlines())
actions=[];proof=[];registry={'chicago/4d/assets/manifest.json':'assets','chicago/4d/assets/manifest.web.json':'masters','chicago/prairie_1904_v1/research/images/STORE.json':'files','chicago/4d/tools/rights_derivation_baseline.json':'entries'}
for state,rel in changed:
 candidate=(R/rel).read_bytes();incoming=blob(target,rel)if rel in target_paths else None;old=blob(oldhead,rel)if rel in oldpaths else None
 if incoming==candidate:result=incoming;kind='ALREADY_EXACT_INCOMING'
 elif incoming==old:result=candidate;kind='OWN_DELTA_IN_DISJOINT_PATH'
 elif old is not None and candidate.startswith(old)and rel.endswith('.md'):
  assert incoming is not None;result=incoming+(b''if incoming.endswith(b'\n')else b'\n')+candidate[len(old):];kind='APPEND_OWN_SUFFIX_TO_COMPLETE_INCOMING'
 elif rel in registry:
  key=registry[rel];before=json.loads(old);mine=json.loads(candidate);theirs=json.loads(incoming);merged=copy.deepcopy(theirs);own_keys={k for k in set(before[key])|set(mine[key])if before[key].get(k)!=mine[key].get(k)}
  for k in own_keys:
   assert theirs[key].get(k)in[before[key].get(k),mine[key].get(k)],('Same registry row changed on both sides',rel,k)
   if k in mine[key]:merged[key][k]=mine[key][k]
   else:merged[key].pop(k,None)
  for k in set(before)|set(mine):
   if k==key or(rel.endswith('/STORE.json')and k=='bytes'):continue
   if before.get(k)!=mine.get(k):
    assert theirs.get(k)in[before.get(k),mine.get(k)],('Registry header changed on both sides',rel,k);merged[k]=mine[k]
  if rel.endswith('/STORE.json'):merged['bytes']=sum(v['bytes']for v in merged['files'].values())
  assert all(merged[key][k]==v for k,v in theirs[key].items()if k not in own_keys)
  result=(json.dumps(merged,indent=1 if rel.endswith('/STORE.json')else 2)+'\n').encode();kind='ENTRYWISE_REGISTRY_UNION'
 elif rel=='chicago/4d/data/structure_grades.json':
  before=json.loads(old);mine=json.loads(candidate);theirs=json.loads(incoming);assert len(before['pictured'])==len(mine['pictured']);merged=copy.deepcopy(theirs);deltas=[(a,b)for a,b in zip(before['pictured'],mine['pictured'])if a!=b]
  assert{a['structure']for a,b in deltas}=={'miller_house','hogan_store','chicago_lighthouse_1832'}
  for a,b in deltas:
   ids=[i for i,x in enumerate(merged['pictured'])if x.get('scene')==a['scene']and x.get('structure')==a['structure']];assert len(ids)==1;idx=ids[0];assert merged['pictured'][idx]in[a,b],('Pictured ruling actually changed',a['structure']);merged['pictured'][idx]=b
  result=(json.dumps(merged,indent=2,ensure_ascii=False)+'\n').encode();kind='ONLY_THREE_EXISTING_PICTURE_ALIASES'
 else:raise AssertionError(('Actual authored conflict needs conscious review before stash/ref changes',rel))
 proof.append({'path':rel,'kind':kind,'old_SHA256':sha(old)if old is not None else None,'candidate_SHA256':sha(candidate),'incoming_SHA256':sha(incoming)if incoming is not None else None,'composed_SHA256':sha(result)})
 actions.append((rel,result))
 backup=O/'own-source'/rel;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(candidate)
(O/'TRACKED-WIP.patch').write_bytes(g('diff','--binary','HEAD','--'))
save('PRECOMPUTED-UNIONS.json',proof);save('BEFORE.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':oldhead,'target':target,'branch':text('branch','--show-current'),'status':status.decode().replace('\0','\n'),'all_unions_checked_before_any_stash_or_ref_action':True})
assert status==g('status','--porcelain=v1','-z','--untracked-files=all')
if args.prepare_tree:
 staged_before=g('ls-files','--stage');private_env=dict(os.environ,GIT_INDEX_FILE=str(O/'PREPARED-PRIVATE.index'))
 def private(*a,input=None):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R,env=private_env,input=input)
 private('read-tree',target)
 for rel,value in actions:
  oid=private('hash-object','-w','--stdin',input=value).decode().strip();mode='100755'if(R/rel).stat().st_mode&0o111 else'100644';private('update-index','--add','--cacheinfo',mode,oid,rel)
 prepared_tree=private('write-tree').decode().strip()
 assert staged_before==g('ls-files','--stage')and status==g('status','--porcelain=v1','-z','--untracked-files=all')and text('rev-parse','HEAD')==oldhead
 result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PRIVATE_SOURCE_UNIONS_PREPARED_NOT_ACCEPTED_PREDECESSOR','unmerged_immutable_TGT_tree':target,'composed_private_tree':prepared_tree,'source_HEAD_unchanged':oldhead,'real_index_staged_entries_unchanged':True,'source_working_bytes_and_status_unchanged':True,'all_TGT_incoming_paths_preserved_with_entrywise_own_deltas':True,'rights_bank_union':'Only distinct current GT and own Miller repairs; no other row changes','own_changed_paths':len(actions),'actual_parent_qualification_and_merge_ancestry_globalnative_app_full3_code_PR_merge_still_owed':True}
 save('RESULT.json',result);print(json.dumps(result,indent=2));raise SystemExit(0)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','stash','push','-u','-m','Complete four original picture cases before accepted TGT/currentdev integration'],cwd=R,check=True)
stash=text('rev-parse','refs/stash');save('RETAINED-EXACT-OWN-STASH.json',{'stash':stash,'old_head':oldhead,'never_pop_or_drop_automatically':True})
assert not text('status','--porcelain=v1')
with(O/'NORMAL-FF-ADVANCE.log').open('x')as log:subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','merge','--ff-only',target],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
assert text('rev-parse','HEAD')==target and not text('status','--porcelain=v1')
for rel,value in actions:
 dst=R/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(value)
for row in proof:assert sha((R/row['path']).read_bytes())==row['composed_SHA256'],row['path']
sys_path=R/'chicago/4d/generators';import sys;sys.path.insert(0,str(sys_path));import mesh_inputs
A=R/'chicago/4d';assets=json.loads((A/'assets/manifest.json').read_text())['assets'];audit=[]
for name,e in assets.items():
 if e.get('archetype')not in{'log_dwelling','frame_dwelling'}:continue
 r=json.loads((A/'data/structures'/(e['structure_id']+'.json')).read_text());phase=next(p for p in r['phases']if p['id']==e['phase_id']);fresh=mesh_inputs.structure_inputs_sha(r,phase,e['archetype'])==e['inputs_sha256'];audit.append({'name':name,'archetype':e['archetype'],'fresh':fresh})
save('ACTUAL-COMPOSED-353-RECIPE-AUDIT.json',audit);assert len(audit)==353 and all(r['fresh']for r in audit),'A real incoming dependency moved; regenerate genuinely, do not restamp old proof'
save('RESULT.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_ACCEPTED_CURRENTDEV_FF_OWN_FOUR_CASES_COMPOSED_ENTRYWISE','previous_head':oldhead,'accepted_target':target,'retained_stash':stash,'authored_unions':proof,'all353_current_recipes_fresh':True,'global_owning_spatial_capacity_metadata_app_full3_code_PR_merge_still_pending':True,'source_status':text('status','--porcelain=v1','--untracked-files=all')});print((O/'RESULT.json').read_text())
