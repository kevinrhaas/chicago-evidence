from pathlib import Path
import subprocess,os,json,hashlib,importlib.util,sys,re,datetime
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path('/workspace/shared/WolfPoint-T2386-Mary-bffc-stack-20261026T1402');env=dict(os.environ,GIT_NO_LAZY_FETCH='1');H='4fe7d4baf3af163e6156a4b003656713f3b7560d';N='bffc4cff33670bde34e718751ea8712e087eef8b';B='a575dddeed356333423b20361a1f90f3b39a862f'
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=env)
def show(c,p):return git('show',c+':'+p)
sha=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==H and git('rev-parse','MERGE_HEAD').decode().strip()==N
resolved=[]
for name in ['LIBERTIES.md','ROADMAP.md','STATUS.md']:
 p='chicago/4d/docs/'+name;base=show(B,p);ours=show(H,p);incoming=show(N,p);assert ours.startswith(base),name;suffix=ours[len(base):]
 if name=='STATUS.md':
  donor=json.loads(Path('/workspace/green-tree-strict-repair-donor-6a61.json').read_text());db=show(donor['base'],p);ds=show('6a61ab6eca1f1ea2322302d131e847b383ac9c8b',p);assert ds.startswith(db);s=ds[len(db):];assert suffix.count(s)==1 and incoming.count(s)==1;suffix=suffix.replace(s,b'')
 assert not re.search(rb'^(?:<<<<<<< |=======$|>>>>>>> )',incoming,re.M)
 (R/p).write_bytes(incoming+suffix);git('add',p);resolved.append({'path':p,'exact_incoming_prefix':True,'own_append_sha256':sha(suffix),'deduplicated_only_exact_shared_donor':name=='STATUS.md'})
p='chicago/4d/docs/STATUS.md';note=b'\nT-2386 cumulative draft checkpoint (2026-10-26): checked Jail PR #1333 head 8cd2db60 and checked Mary PR #1334 head bffc4cff are upstream dependencies while this PR remains based on dev. The earlier Wolf 4fe7d4ba passed all eighteen native published groups; that old-base result does not certify this cumulative world. Supported native regeneration, the complete binary audit, current all-three preflight and a fresh exact-head eighteen-group matrix are required for this candidate. Jail and Mary must land first. Before ready/merge, integrate actual dev and compare the native global smoke-input hash with this tested candidate; rerun stage 13 at both viewports when only the separately hashed changelog changes. All eight original picture acceptances remain unfinished; no original image-match completion is claimed.\n';(R/p).write_bytes((R/p).read_bytes()+note);git('add',p)
p='chicago/4d/tools/smoke_renderer.mjs';current=(R/p).read_text();incoming=show(N,p).decode();pat=r'const PLACED_1904 = \[.*?\]\.sort\(\);';a=list(re.finditer(pat,current,re.S));b=list(re.finditer(pat,incoming,re.S));assert len(a)==len(b)==1;ids=re.findall(r"'([a-z][a-z0-9_]+)'",b[0].group());assert len(ids)==len(set(ids))==283
current=current[:a[0].start()]+b[0].group()+current[a[0].end():];assert current==incoming,'Other smoke code must retain all checked incoming repairs byte-for-byte';(R/p).write_text(current);git('add',p)
spec=importlib.util.spec_from_file_location('native_registry',A/'tools/merge_asset_registry.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);regs=[]
for p in ['chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json']:
 expected=mod.merge_texts(p,show(B,p).decode(),show(H,p).decode(),show(N,p).decode());actual=(R/p).read_text();assert json.loads(expected)==json.loads(actual);regs.append({'path':p,'native_entrywise_exact':True,'sha256':sha(actual.encode())})
old=json.loads(Path('/workspace/shared/WolfPoint-T2386-a9c5-integration-20261026/PREMERGE.json').read_text())
for row in old['all82_pairs']:
 data=(R/row['path']).read_bytes();assert sha(data)==row['sha256']and len(data)==row['bytes'],row['path']
sys.path.insert(0,str(A/'generators'));import mesh_inputs
rows=[]
for k,r in json.loads((A/'assets/manifest.json').read_text())['assets'].items():
 if r.get('archetype')!='log_dwelling':continue
 st=json.loads((A/'data/structures'/(r['structure_id']+'.json')).read_text());ph=next(p for p in st['phases']if p['id']==r['phase_id']);h=mesh_inputs.structure_inputs_sha(st,ph,'log_dwelling');assert h==r['inputs_sha256'],k;rows.append({'asset':k,'fresh_native_inputs_sha256':h})
assert len(rows)==82
u=git('diff','--name-only','--diff-filter=U').decode().splitlines();assert set(u)==set('chicago/4d/'+p for p in ['data/liberties.json','data/sidecars/1835/sources/index.json','docs/measurements/source_use_coverage.md'])
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':H,'incoming':N,'mergebase':git('merge-base',H,N).decode().strip(),'authored_resolutions':resolved,'strict_smoke_byte_exact_checked_incoming':True,'native_registries':regs,'all82_pairs_byte_exact':True,'fresh82_recipe_hashes':rows,'remaining_derived_U':u,'native_gate_pending':True,'no_codecommit':True};(O/'AUTHORED-RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='fresh82_recipe_hashes'}))
