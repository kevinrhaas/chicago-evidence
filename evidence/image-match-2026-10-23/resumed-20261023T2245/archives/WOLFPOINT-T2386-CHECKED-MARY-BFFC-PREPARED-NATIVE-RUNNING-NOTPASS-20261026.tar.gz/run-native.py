from pathlib import Path
import os,json,subprocess,hashlib,datetime,time,shutil,gzip,zipfile,io,xml.etree.ElementTree as ET
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path('/workspace/shared/WolfPoint-T2386-Mary-bffc-stack-20261026T1402');P=json.loads((O/'NATIVE-PREPARED.json').read_text());N=P['incoming'];env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',TMPDIR='/tmp/wolfpoint-Mary-bffc-native-scratch');Path(env['TMPDIR']).mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(R),*args],env=env)
def save(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n')
def guards(tag):
 bad=[]
 for kind in ['frozen_assets_and_registries','frozen_authored_sources_people_generators']:
  for row in P[kind]:
   b=(A/row['path']).read_bytes()
   if len(b)!=row['bytes']or sha(b)!=row['sha256']:bad.append({'kind':kind,'path':row['path'],'before':row['sha256'],'after':sha(b)})
 save('GUARDS-'+tag+'.json',{'assets':len(P['frozen_assets_and_registries']),'controls':len(P['frozen_authored_sources_people_generators']),'changed':bad});assert not bad,bad
 assert (A/'renderers/web/js/changelog.js').read_bytes()==git('show',N+':chicago/4d/renderers/web/js/changelog.js')
steps=[]
def run(name,cmd):
 assert shutil.disk_usage('/tmp').free>=P['floor_bytes'],('ROOT_NATIVE_STARTUP_RESERVE_ONLY',name)
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();print('START',name,start,flush=True)
 with (O/(name+'.log')).open('x')as log:result=subprocess.run(cmd,cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'started':start,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':result.returncode,'tmp_free_after':shutil.disk_usage('/tmp').free,'workspace_free_after':shutil.disk_usage('/workspace').free};steps.append(row);save('NATIVE-STEPS.json',steps);print('CLOSED',json.dumps(row),flush=True);assert result.returncode==0,row
assert git('rev-parse','HEAD').decode().strip()==P['head'] and git('rev-parse','MERGE_HEAD').decode().strip()==N
guards('PRE')
run('official-glessner-check',['python3','tools/recover_glessner_v4.py','--check'])
# Resolve only by supported owning contract; no prior external publish of conflicted JSON.
run('owning-native-resolve',['node','tools/rederive.mjs','--resolve']);guards('POST-RESOLVE')
assert not git('diff','--name-only','--diff-filter=U').strip()
DCT='{http://purl.org/dc/terms/}'
def canon(raw,name):
 root=ET.fromstring(raw)
 if name=='docProps/core.xml':
  for x in list(root):
   if x.tag in {DCT+'created',DCT+'modified'}:root.remove(x)
 return ET.canonicalize(ET.tostring(root,encoding='unicode'),rewrite_prefixes=True)
def workbook(a,b):
 with zipfile.ZipFile(io.BytesIO(a))as x,zipfile.ZipFile(io.BytesIO(b))as y:
  assert len(x.namelist())==len(set(x.namelist())) and len(y.namelist())==len(set(y.namelist()))
  if set(x.namelist())!=set(y.namelist()):return False,[]
  rows=[]
  for n in sorted(x.namelist()):
   p,q=x.read(n),y.read(n);equal=p==q
   if not equal and n.endswith(('.xml','.rels')):equal=canon(p,n)==canon(q,n)
   rows.append({'member':n,'raw_equal':p==q,'canonical_semantics_equal':equal,'incoming_sha256':sha(p),'generated_sha256':sha(q)})
  return all(r['canonical_semantics_equal']for r in rows),rows
rows=[];restore=[];B={r['path']:r for r in P['binary44']}
dirty=[p.decode()for p in git('diff',N,'--name-only','-z').split(b'\0')if p];outside=[p for p in dirty if not p.startswith('chicago/4d/')]
for rel in sorted(set(B)|set(outside)):
 old=git('show',N+':'+rel);new=(R/rel).read_bytes();row={'path':rel,'incoming_sha256':sha(old),'generated_sha256':sha(new),'bytes_equal':old==new,'semantics_equal':old==new,'kind':'BYTE_EXACT_SHORT_CIRCUIT'}
 if rel in B:assert sha(old)==B[rel]['sha256'] and old==Path(B[rel]['raw_baseline']).read_bytes()
 if old!=new:
  p=O/'generated-before-restoration'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(new)
  if rel.endswith('.gz'):row.update(semantics_equal=gzip.decompress(old)==gzip.decompress(new),kind='EXACT_COMPLETE_DECOMPRESSED_BYTES')
  elif rel.endswith('.xlsx'):
   equal,members=workbook(old,new);row.update(semantics_equal=equal,kind='ALL_ZIP_MEMBERS_EXACT_OR_CANONICAL_XML_EXCEPT_CORE_CREATED_MODIFIED',members=members)
  else:row.update(semantics_equal=False,kind='OUTSIDE4D_REAL_OR_UNCLASSIFIED_CHANGE_PRESERVED')
  if row['semantics_equal']:restore.append(rel)
 rows.append(row)
save('ALL44-AND-OUTSIDE-BEFORE-RESTORATION.json',{'count44':len(B),'outside':outside,'rows':rows,'all_equal':all(r['semantics_equal']for r in rows)})
assert all(r['semantics_equal']for r in rows),[r for r in rows if not r['semantics_equal']]
for rel in restore:(R/rel).write_bytes(git('show',N+':'+rel))
if restore:git('add','--',*restore)
save('ALL44-RESTORED.json',{'all44_semantics_equal':True,'all_changed_generated_preserved':True,'serialization_only_restored':restore,'rows':rows})
run('package5-tail',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']);guards('POST-PACKAGE')
run('final-publish',['bash','tools/publish.sh']);guards('FINAL')
for row in P['binary44']:assert sha((R/row['path']).read_bytes())==row['sha256'],row['path']
assert not (R/'site/4d').is_symlink() and (R/'site/4d').is_dir()
assert sha((R/'site/4d/data/gltf/wolf_point_tavern__log_frame_1828.glb').read_bytes())=='fdc5ef22a440636e35e4cec15818661f4351f0f4d0c9e506ef36b00422a45210'
git('add','-u');assert not git('diff','--name-only').strip()
r={'status':'NATIVE_RESOLVE_FIXEDPOINT_ALL44_PROOF_PACKAGE5_FINAL_PUBLISH_PASS','head':P['head'],'incoming':N,'closed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'staged_tree':git('write-tree').decode().strip(),'steps':steps,'all82_pairs_protected':True,'frozen_assets':len(P['frozen_assets_and_registries']),'frozen_controls':len(P['frozen_authored_sources_people_generators']),'no_exports':True,'all44_semantic_proof':True,'serialization_only_restored':restore,'pending':'whole3actualPASSbeforecodecommit, committedCLIDs and currentbasequalifiedsmoke'};save('NATIVE-RESULT.json',r);print(json.dumps(r),flush=True)
