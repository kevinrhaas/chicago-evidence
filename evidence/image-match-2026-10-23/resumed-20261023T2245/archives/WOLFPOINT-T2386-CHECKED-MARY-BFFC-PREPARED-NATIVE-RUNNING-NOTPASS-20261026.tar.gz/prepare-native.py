from pathlib import Path
import os,json,subprocess,hashlib,datetime
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path('/workspace/shared/WolfPoint-T2386-Mary-bffc-stack-20261026T1402');H='4fe7d4baf3af163e6156a4b003656713f3b7560d';N='bffc4cff33670bde34e718751ea8712e087eef8b';env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def git(*args):return subprocess.check_output(['git','-C',str(R),*args],env=env)
sha=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==H and git('rev-parse','MERGE_HEAD').decode().strip()==N
old=json.loads(Path('/tmp/WolfPoint-T2386-a575-native-closure-20261026/PREPARED.json').read_text());binary=[]
for row in old['binary44']:
 b=git('show',N+':'+row['path']);assert b==Path(row['raw_baseline']).read_bytes()==(R/row['path']).read_bytes();binary.append(dict(row,baseline_commit=N,immutable_incoming_blob=git('rev-parse',N+':'+row['path']).decode().strip(),previous_raw_baseline_still_exact_actual_incoming=True))
assert len(binary)==44
paths=[p.decode()for p in git('ls-files','-z','chicago/4d').split(b'\0')if p];paths=sorted(set(paths))
def freeze(seq):
 rows=[]
 for p in seq:
  f=R/p
  if f.is_file():
   b=f.read_bytes();rows.append({'path':str(f.relative_to(A)),'bytes':len(b),'sha256':sha(b)})
 return rows
assets=freeze(p for p in paths if p.startswith('chicago/4d/assets/'))
controls=freeze(p for p in paths if p.startswith(tuple('chicago/4d/'+s for s in ['data/residents/','data/structures/','data/sources/','generators/'])))
obj={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':H,'incoming':N,'binary44':binary,'frozen_assets_and_registries':assets,'frozen_authored_sources_people_generators':controls,'whole_binary_baseline_proof':'All44 actualincoming immutableblob bytes exact retaineda575 rawbaselines and prederive workingbytes. No extra baselinecopy needed.','floor_bytes':512*1024**2,'root_native_lease_pending':True}
(O/'NATIVE-PREPARED.json').write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps({'binary44':len(binary),'assets':len(assets),'controls':len(controls),'prepared':str(O/'NATIVE-PREPARED.json')}))
