"""Guarded, prepared private hypothesis trial. --check is read-only; actual work needs a later root grant."""
from pathlib import Path
import argparse,ast,collections,copy,dataclasses,datetime,hashlib,json,math,os,re,signal,subprocess,sys,tarfile,traceback,types
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
C=load(P/'CONFIG.json');REVISED=Path(C['revised_packet']);PRIOR=Path(C['prior_packet']);SID='fort_dearborn_officers_quarters';KEY=SID+'__log_1816.glb'

def packet_check():
 for directory,key in [(REVISED,'revised_manifest_sha256'),(PRIOR,'prior_manifest_sha256'),(Path(C['v1_packet']),'v1_manifest_sha256')]:
  assert sha((directory/'MANIFEST.json').read_bytes())==C[key]
  m=load(directory/'MANIFEST.json')
  for row in m['files']:
   b=(directory/row['path']).read_bytes();assert len(b)==row['bytes']and sha(b)==row['sha256'],row['path']
 original=(REVISED/'frozen/officers.before.json').read_bytes();candidate=(REVISED/'candidate'/f'{SID}.json').read_bytes()
 assert sha(original)==C['record_preimage_sha256']and sha(candidate)==C['candidate_sha256']
 a=json.loads(original);b=json.loads(candidate);restored=copy.deepcopy(b);f=restored['phases'][0]['form'];f['gallery']=a['phases'][0]['form']['gallery'];f.pop('gallery_storeys');f.pop('face_openings');assert restored==a
 for field in ['gallery','gallery_storeys','face_openings']:assert b['phases'][0]['form'][field]['confidence']=='reconstructed'
 params=(REVISED/'frozen/fort_structure_params.py').read_bytes();producer=(REVISED/'frozen/fort_structure.fc645.py').read_bytes();assert sha(producer)==C['repaired_producer_sha256']
 m=types.ModuleType('private_hypothesis_frozen_params');sys.modules[m.__name__]=m;exec(compile(params,'frozen_params','exec'),m.__dict__);p=m.from_phase(a['phases'][0],a);q=m.from_phase(b['phases'][0],b)
 old=load(PRIOR/'candidate'/f'{SID}.json');assert dataclasses.asdict(q)==dataclasses.asdict(m.from_phase(old['phases'][0],old))
 src=producer.decode();t=ast.parse(src);code='from __future__ import annotations\n'+'\n\n'.join(ast.get_source_segment(src,n)for n in t.body if isinstance(n,ast.FunctionDef)and n.name in {'_openings','_explicit_openings','_gallery_post_centres'});calls=[]
 def opening(_b,axis,plane,u0,u1,z0,z1,outward,conf,kind='window'):calls.append((axis,plane,u0,u1,z0,z1,outward,conf,kind))
 env={'math':math,'wall_openings':m.wall_openings,'openings':types.SimpleNamespace(CASING_W_M=.09,SILL_HORN_M=.03),'_opening':opening};exec(compile(code,'frozen_pure_functions','exec'),env);env['_openings'](None,p,0,0);oldcalls=collections.Counter(calls);calls.clear();env['_openings'](None,q,0,0);assert oldcalls==collections.Counter(calls)and len(calls)==18
 centres=env['_gallery_post_centres'](q,.14);assert len(centres)==7
 for x in centres[1:-1]:assert all(x<=o['u0']-.19+1e-9 or x>=o['u1']+.19-1e-9 for o in m.wall_openings(q,'front'))
 camera=load(P/'camera1855-diagnostic.json');oldcam=load(PRIOR/'cameras/wentworth_1855_gallery_seed.json');assert sha((P/'camera1855-diagnostic.json').read_bytes())==C['new_camera_sha256'];assert {k:v for k,v in camera.items()if k!='solve'}=={k:v for k,v in oldcam.items()if k!='solve'}
 assert camera['source_id']=='wentworth_1881_fort_dearborn'and camera['scene']=='1835'
 return {'status':'PASS_PREPARED_CHECK_ONLY_ACTUAL_TRIAL_UNRUN','immutable_packets':3,'same18opening_calls':True,'seven_supports_clear':True,'camera_pose_intrinsics_exact_prior':True,'source_period':'1855 diagnostic bracket; not formal1835view','candidate_sha256':C['candidate_sha256']}

CLOSED=Path('/workspace/T2388-private-gallery-failed-attempts-closed-20261024');F2=CLOSED/'T2388-private-gallery-existing-actual-002'
ap=argparse.ArgumentParser(description='Prepared authorized continuation from closed002; no reset or baseline recapture.');ap.add_argument('--check',action='store_true');ap.add_argument('--repo',type=Path);ap.add_argument('--out',type=Path);ap.add_argument('--blender',type=Path);ap.add_argument('--root-heavy-granted',action='store_true');a=ap.parse_args()
def closed_check():
 assert sha((CLOSED/'MANIFEST.json').read_bytes())=='562002f2e49d084ab81ea9bad74d07427797beb4e24f9fea0743b13f94ba451c'
 for row in load(CLOSED/'MANIFEST.json')['files']:
  b=(CLOSED/row['path']).read_bytes();assert len(b)==row['bytes']and sha(b)==row['sha256']
 assert load(F2/'RESULT.json')['status']=='FAIL_PRESERVED';assert load(F2/'RESULT.json')['steps'][1]['label']=='01-before1855-diagnostic'and load(F2/'RESULT.json')['steps'][1]['exit_code']==0
 return packet_check()
if a.check:print(json.dumps(closed_check(),indent=2));raise SystemExit(0)
if not a.root_heavy_granted:ap.error('A NEW root-authorized continuation heavy grant is required.')
assert all([a.repo,a.out,a.blender]);closed_check();repo=a.repo.resolve();root=repo/'chicago/4d';out=a.out.resolve();assert repo==Path(C['approved_existing_repo']).resolve()and repo not in [Path('/workspace/chicago'),Path('/tmp/chicago-log-integration')];assert a.blender.resolve()==Path(C['pinned_blender']).resolve();assert not out.exists();out.mkdir(parents=True)
state={'status':'RUNNING','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repo':str(repo),'head':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'scope':'Authorized private reconstructed hypothesis continuation;1855diagnostic ONLY; no ruling/grade/match/adoption','closed_baseline_manifest_sha256':'562002f2e49d084ab81ea9bad74d07427797beb4e24f9fea0743b13f94ba451c','steps':[]}
def save():
 p=out/'RESULT.json.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(out/'RESULT.json')
def run(label,cmd,timeout=600):
 row={'label':label,'command':list(map(str,cmd)),'status':'RUNNING'};state['steps'].append(row);save()
 with (out/(label+'.log')).open('wb')as log:
  proc=subprocess.Popen(row['command'],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'PWD':str(root),'PYTHONDONTWRITEBYTECODE':'1','PW_EXECUTABLE':os.environ.get('PW_EXECUTABLE','/usr/bin/chromium')});row['pid']=row['process_group']=proc.pid;save()
  try:row['exit_code']=proc.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   row['timeout']=True;os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   row['exit_code']=proc.returncode
 row['status']='PROCESS_EXIT_ZERO_PENDING_ARTIFACT_GUARDS'if row['exit_code']==0 else'FAIL_PRESERVED';save();assert row['exit_code']==0,label
try:
 save();assert state['head']=='308b738e6e6716a7a1411aa6c178e196eb17a719'
 status=subprocess.check_output(['git','-C',str(repo),'status','--porcelain=v1'],text=True);assert status.splitlines()==[' M chicago/4d/data/structures/'+SID+'.json'],'only exact private candidate record may be dirty'
 record=root/'data/structures'/f'{SID}.json';assert sha(record.read_bytes())==C['candidate_sha256']
 assert sha((root/'generators/archetypes/fort_structure.py').read_bytes())==C['repaired_producer_sha256'];assert (root/'generators/archetypes/fort_structure_params.py').read_bytes()==(REVISED/'frozen/fort_structure_params.py').read_bytes()
 before=load(F2/'baseline-held/manifest.json');webbefore=load(F2/'baseline-held/manifest.web.json');manifest=root/'assets/manifest.json';webmanifest=root/'assets/manifest.web.json';assert manifest.read_bytes()==(F2/'baseline-held/manifest.json').read_bytes()and webmanifest.read_bytes()==(F2/'baseline-held/manifest.web.json').read_bytes()
 for kind in ['gltf','web']:assert (root/'assets'/kind/KEY).read_bytes()==(F2/'baseline-held'/(kind+'.glb')).read_bytes()
 metadata=load(F2/'SOURCE-PROVENANCE-HASHES.json')
 for rel,row in metadata.items():
  p=REVISED/rel.removeprefix('external_revised_packet/')if rel.startswith('external_revised_packet/')else root/rel
  assert sha(p.read_bytes())==row['raw_sha256'],('provenance drift',rel)
 sys.path.insert(0,str(root/'generators'));import mesh_inputs
 rows=before['assets'];fort={k:v for k,v in rows.items()if v.get('archetype')=='fort_structure'};assert len(fort)==25;oldinputs=load(F2/'BASELINE25-INPUTS.json');currentdocs={}
 for key,row in fort.items():
  st=load(F2/'baseline-held/record.json')if key==KEY else load(root/'data/structures'/f'{row["structure_id"]}.json');phase=next(p for p in st['phases']if p['id']==row['phase_id']);doc=mesh_inputs.structure_inputs_doc(st,phase,'fort_structure');actual=sha(json.dumps(doc,sort_keys=True).encode());assert actual==row['inputs_sha256']==oldinputs[key]['inputs_sha256']and doc==oldinputs[key]['doc'];currentdocs[key]={'inputs_sha256':actual,'doc':doc}
 candidate=load(record);candidate_input=mesh_inputs.structure_inputs_sha(candidate,candidate['phases'][0],'fort_structure');assert candidate_input!=rows[KEY]['inputs_sha256']
 protected=load(F2/'PROTECTED-GLB-HASHES.json')
 for rel,h in protected.items():assert sha((root/rel).read_bytes())==h,('unrelated drift',rel)
 prior=load(F2/'RESULT.json');pinproof=prior['blender_proof']
 def stream_sha(f):
  h=hashlib.sha256()
  while True:
   b=f.read(4*1024*1024)
   if not b:return h.hexdigest()
   h.update(b)
 assert sha((root/'generators/blender.pin').read_bytes())==pinproof['pin_sha256']==C['blender_pin_sha256']
 with a.blender.open('rb')as f:installed=stream_sha(f)
 with Path(C['pinned_archive']).open('rb')as f:archive=stream_sha(f)
 assert installed==pinproof['executable_sha256']==pinproof['archive_executable_sha256']and archive==pinproof['archive_sha256']==C['archive_sha256'];state['pin_proof_reused_under_exact_archive_and_executable_rehash']=pinproof;save()
 run('00-pinned-version',[a.blender,'--version'],60);header=(out/'00-pinned-version.log').read_text().splitlines()[0];assert re.fullmatch(r'Blender '+re.escape(C['blender_version'])+r'(?: LTS)?',header)
 (out/'BASELINE25-REPROOF.json').write_text(json.dumps(currentdocs,indent=2)+'\n');(out/'SOURCE-PROVENANCE-HASHES.json').write_text(json.dumps(metadata,indent=2)+'\n');(out/'PROTECTED-GLB-HASHES.json').write_text(json.dumps(protected,indent=2)+'\n')
 import shutil
 shutil.copytree(F2/'before',out/'before');shutil.copytree(F2/'baseline-held',out/'baseline-held');(out/'after/cameras').mkdir(parents=True);(out/'after/source').mkdir();(out/'after/cameras/camera1855-diagnostic.json').write_bytes((F2/'before/cameras/camera1855-diagnostic.json').read_bytes());(out/'after/source/fortdearborn1855.jpg').write_bytes((F2/'before/source/fortdearborn1855.jpg').read_bytes())
 assert (out/'after/cameras/camera1855-diagnostic.json').read_bytes()==(P/'camera1855-diagnostic.json').read_bytes();sidecars=prior['scene_and_context_sidecar_hashes']
 for rel,h in sidecars.items():assert sha((root/rel).read_bytes())==h
 state.update({'current_source_binding_pass':True,'candidate_inputs_sha256':candidate_input,'baseline25_current_reproof_pass':True,'baseline_capture_reused_exact_closed002_no_recapture':True,'scene_and_context_sidecar_hashes':sidecars,'camera_sha256':prior['camera_sha256'],'photo_sha256':prior['photo_sha256']});save()
 # The producer path is absolute, PWD matches subprocess cwd, and Python exceptions must return nonzero.
 run('01-official-one-master',[a.blender,'-b','-noaudio','--factory-startup','--python-exit-code','1','--python',root/'generators/build.py','--','--only',SID,'--scene','1835','--wrote',out/'wrote.txt'])
 assert (out/'wrote.txt').read_text().splitlines()==[KEY]
 aftermaster=load(manifest);assert {k:v for k,v in aftermaster['assets'].items()if k!=KEY}=={k:v for k,v in rows.items()if k!=KEY};assert {k:v for k,v in aftermaster.items()if k!='assets'}=={k:v for k,v in before.items()if k!='assets'};assert aftermaster['assets'][KEY]['inputs_sha256']==candidate_input
 assert load(webmanifest)==webbefore and (root/'assets/web'/KEY).read_bytes()==(F2/'baseline-held/web.glb').read_bytes();mastersha=sha((root/'assets/gltf'/KEY).read_bytes());assert mastersha!=sha((F2/'baseline-held/gltf.glb').read_bytes());state['actual_one_master_produced_and_receipt_guarded']=True;save()
 run('02-official-one-web',['bash',root/'tools/web_derivatives.sh','--only',KEY]);assert load(manifest)==aftermaster and sha((root/'assets/gltf'/KEY).read_bytes())==mastersha
 web=load(webmanifest);assert {k:v for k,v in web['masters'].items()if k!=KEY}=={k:v for k,v in webbefore['masters'].items()if k!=KEY};assert {k:v for k,v in web.items()if k!='masters'}=={k:v for k,v in webbefore.items()if k!='masters'};assert web['masters'][KEY]==mastersha;assert (root/'assets/web'/KEY).read_bytes()!=(F2/'baseline-held/web.glb').read_bytes();state['actual_one_web_derived_and_manifest_guarded']=True;save()
 for rel,h in protected.items():assert sha((root/rel).read_bytes())==h
 for rel,h in sidecars.items():assert sha((root/rel).read_bytes())==h
 run('03-after1855-diagnostic',['node',root/'tools/photo_match.mjs',out/'after/cameras/camera1855-diagnostic.json','--out',out/'after/comparisons'])
 for rel,h in protected.items():assert sha((root/rel).read_bytes())==h
 for rel,h in sidecars.items():assert sha((root/rel).read_bytes())==h
 for rel,row in metadata.items():
  if not rel.startswith('external_revised_packet/'):assert sha((root/rel).read_bytes())==row['raw_sha256']
 allowed={'chicago/4d/data/structures/'+SID+'.json','chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json','chicago/4d/assets/gltf/'+KEY,'chicago/4d/assets/web/'+KEY};changed=set(subprocess.check_output(['git','-C',str(repo),'diff','--name-only'],text=True).splitlines());assert changed<=allowed;assert not subprocess.check_output(['git','-C',str(repo),'ls-files','--others','--exclude-standard'],text=True)
 state.update({'status':'ACTUAL_PRIVATE_ONE_MASTER_WEB_AND_1855_BRACKET_COMPLETE_PENDING_HUMAN_REVIEW_NOT_MATCH','master_sha256':mastersha,'web_sha256':sha((root/'assets/web'/KEY).read_bytes()),'actual_tracked_delta':sorted(changed),'all24_other_fort_recipes_and_unrelated_glbs_exact':True,'baseline_capture':'Retained actual002 before, not rerun','candidate_capture':'Actual003after, humanreviewpending','native_appQA_ruling_grade_adoption':'NOTRUN_NOTMADE','original_T2388':'OPEN/16DIFFERS'})
except BaseException as error:
 state.update({'status':'FAIL_PRESERVED','error':str(error),'traceback':traceback.format_exc()});raise
finally:state['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
