# Cobweb's two stack heads: bounded T3081 proposal

UNAPPLIED authored proposal. No canonical source, native output or gate was changed
by this packet. The earlier frozen packets remain unchanged.

The completed gate exposed a conservative global-roof clearance of 0.369895935 m
on the existing actual Cobweb master. Each stack already rises 0.72 m above its
own wing, but the central roof is higher. At the unchanged35-degree pitch and2.6m
eave, central ridge is4.525571m and wing ridges4.175467m; current heads4.895467m.
The existing native gate measures from the highest roof and requires18in=0.4572m.
Its rule, tolerance, jurisdiction handling and exceptions remain untouched.

The proposal reuses the existing absolute-grade `chimney_head_m` control:

- Remove only its independent-compound prohibition; keep the existing global
  height/count/ridge validation and the separate elbow prohibition.
- Pass that value to `_stack(..., head_z=...)` in the independent compound path.
  `None` retains the existing0.72m-above-local-ridge construction.
- Choose5.05m above grade for both Cobweb heads. That gives0.524429m above the
  highest roof, a67.229mm margin over the unchanged floor, and0.874533m above each
  wing ridge. This is a declared reconstructed head height, not a pictured or
  measured dimension, a claim of July1835 compliance, or an image match.
- Add the missing real note-reader path `phases[].form.chimney_head_m.note`.
  Every current reader row is retained; no ignored bypass is introduced.
- Update only root's still-uncommitted `L-cobweb-compound-2374` block with the head
  decision and one precise Cover. The entire incoming3fa raw liberty prefix and
  all other bytes remain exact. The existing newspaper corpus source resolves;
  the August1835 by-law is a construction bound, not evidence of Cobweb's height.

Exactly five authored paths are supplied in `candidate/` and `proposal.patch`:

1. `generators/archetypes/log_dwelling.py`
2. `generators/archetypes/log_dwelling_params.py`
3. `data/structures/cobweb_castle.json`
4. `data/reconstruction/name_pool_keys.json`
5. `docs/LIBERTIES.md`

`input-guards.json` binds every current preimage and candidate hash. Root may
review the5750-byte patch and explicitly adopt after the finished gate:

```sh
python3 /tmp/T3081-cobweb-stack-head-proposal/apply_guarded.py --project-root /tmp/chicago-log-integration/chicago/4d
```

The application helper checks all five preimages before writing and refuses any
drift. It stages or commits nothing. It has not been invoked by this agent.
Root owns subsequent STATUS/changelog updates and all actual generation/gates.

`raw-audit.json` records actual CPU-only producer checks using the82 current
record/phase asset keys, preserving their current selected opt-ins:

- All82 outputs before the new Cobweb field are raw-byte-stream equivalent between
  current and candidate producers, including geometry, confidence and palette.
  Legacy constructor signature is exact; the other81 selected outputs are exact.
- Opting Cobweb into5.05m changes only64 chimney-vertex Z values. Roof geometry,
  plan, stack positions/sections/count, faces, material indices, vertex confidence,
  named materials and full palette remain exact. Triangles stay1650.
- Both actual raw candidate stack heads reach5.05m; global clearance0.524429m.
  Existing actualGLB accessor bounds independently reproduce the failed0.369896m.

The raw proof used a stubbed output sink; it did not execute bpy or Blender.
Current82 source records, imported shared-source files and the existing failing
master are copied as evidence. `before/` is historical comparison material; apply
only the five guarded `candidate/` files. Existing old recipe/manifests are never
copied or hand-edited into freshness.

Changing the shared producer means root must run a real pinned official82 refresh
and native web export again, then actual byte-level stack ordinance measurement,
normal ordered derivation and complete gates. The pure raw calculation is not an
export or a gate pass. All original image gates, including T-2374, remain open.
