# Hogan's recessed doorway, gable proxy and shorter stack

T-3118 is a record-only continuation of T-2377. It uses the log controls already
present on PR #1260 head `35f0c564cc25303d3f5641812d532dd9d2166b64`; that PR
must land before this increment. No shared producer or default is changed.

The dependency merged as dev `10ac7602e6ca0be8c197367c72d6d6c40fd76c4e` on
2026-10-24. This branch normally integrates that dev commit, retaining its fold.
The official one-target pinned4.5.3 build and real web derivative now completed:
master45,616B/470tri SHA687628d4780f2409e045c1cba6b53a871d02524657a475a6a2716591c0ab2182,
web17,948B/470tri SHAe7c078f6f00cd14f323da0cacc5e4b290aa884632b5eff01172c838b1fd3fa8e.
All82 recipes are fresh;81other log record/master/web bytes and all non-target
registry entries are exact. H9's114 generator files remain unchanged.

`before/cameron-1833-before-side-by-side.jpg` uses the exact committed H9 baseline
master; `after/cameron-1833-after-side-by-side.jpg` uses the new official master.
Their cameras have identical bytes and share the source/sky/intrinsics. Both were
actually rendered and inspected; both remain `differs`, with open differences in
their adjacent match records. The before master's public origin/hash and temporary
served-copy lifecycle are recorded in `official-comparison-review.json`. The native
review tool first refused an absolute override URL; using its existing root-relative
contract fixed that invocation without changing the tool.

The first native tail failed at its scratch-copy step because /tmp had insufficient
space. Its transcript is preserved; it is not a pass. The supported full tail is
being retried with an external workspace TMPDIR after measured2GiB headroom.
Publishing/app checks and full gates remain pending at this checkpoint.

The actual local Cameron halftone and the frozen before/after were reopened. The
depicted long wall has a dark doorway occupied by a figure, one sash, a framed
gable rectangle and a short roof-piercing stack. Choose `front_door_state: recess`,
`end_openings.kind: hatch` and `ridge_stack_head_m: 0.75` using existing consumers.
The 300 mm blind back is a reconstructed exterior shadow proxy; there is no
room, door leaf position, figure or new passable interior. The walker continues
to treat the building footprint as solid. The hatch's boards and ledges are a
reconstructed proxy for unresolved infill, not proof of boards or absent glass.
The short head's height, cap and masonry remain reconstructed. Existing metric
stations/sizes, 45 by 20 ft footprint, position, bearing, dates and use stay exact.

## Source admission

`cameron_c1900_first_post_office` already names Edgar S. Cameron, the printed
Chicago Historical Society credit, the local surrogate and Commons locator.
Its existing public-domain attribution comes from the committed image inventory;
original publication and holding have not been independently established. Keep
that source record unchanged, including `asset_use: cross_check` and its limits.
No fresh remote rights verification, Alamy reuse or image-pixel texture is claimed.
The retrospective scene is labelled 1833; it provides neither geographic control
nor independent scale nor proof of the store's state/use on 1 July 1835.

## Banked preview and current light proof

The frozen continuation at `/tmp/chicago-next-model/T-2377-continuation` includes
an actual pinned Blender 4.5.3 fixture export and same-camera browser comparisons
under `preview/reviews/committed-before/` and `preview/reviews/proposed/`.
The proposed GLB SHA256 is
`687628d4780f2409e045c1cba6b53a871d02524657a475a6a2716591c0ab2182`.
Both comparisons were inspected and remain `differs`. Current H8 modules produce
the exact same complete raw geometry/material/confidence lists as that frozen
candidate: 236 polygons / 470 fan triangles. That is a CPU equivalence result,
not a fresh official export or accepted image gate.

Current light receipts are in `/tmp/chicago-next-model/T-3118-hogan-H8`.
All 82 current log master recipes were fresh before the edit. Only Hogan's recipe
changes; the other 81 recipes, records, masters and web derivatives are exact.
All 113 generator Python preimages are unchanged. Two malformed parameter controls
still refuse. The source record and non-form Hogan data are exact.

## Next official review

Only after the shared heavy slot is granted, preserve the exact current committed
Hogan master and run the native pinned build for `--only hogan_store`, then its
real web derivative. Do not replace production manifests with a fixture recipe.
Run the supported ordered native derivation to a fixed point, publish and inspect
the final tree. This is one master, not another 82-family rebuild, provided the
code and 81 other input guards still hold at execution time.

Use the unchanged numeric camera in
`docs/RESEARCH/hogan-picture-match-T-2377/cameron-1833.json` for both the exact
committed-before GLB and the new official master. The six-wallpoint provisional
fit has 16.099 px RMS / 26.809 px maximum residual, with about 5 px manual picking
uncertainty and inconsistent drawn convergence. Keep identical source, sky and
intrinsics; do not force a physical lens or move the historic footprint to fit it.
Retain the comparison in research while provisional. The actual side-by-side and
match record must name their own new hashes and retain every remaining difference.

Then review the published 1835 scene in normal and confidence views and Hogan's
Images/card at 390x780 and 1280x800. Verify the recess has no wall/chink cover,
the gable proxy and short stack render, source credit reaches the visitor,
structure grade remains pictured/attested without promoting attribute grades,
no traversal/interior is implied, and no page/loader/network error occurs.
Run strict preflight and required published smoke coverage on the final head.
The upstream 1904 Full-stage budget issue belongs to the root's separate work.

Log/chink regularity, roof texture/tone, gable cladding/infill, sash pattern, chimney
cap/fabric, proportions/perspective, absent figure/context and hidden elevations
remain unresolved. Original T-2377 stays open and `differs`.
