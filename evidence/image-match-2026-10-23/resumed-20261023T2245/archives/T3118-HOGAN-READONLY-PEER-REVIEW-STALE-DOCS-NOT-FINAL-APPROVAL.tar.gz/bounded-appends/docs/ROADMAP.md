

### T-3118 — Hogan's next pictured details

Select the already implemented recess/hatch/short-stack controls in the Hogan record, dependent on PR1260, without changing the log family. Current light proof isolates one changed master recipe and preserves the other 81. Next: grant the supported one-master bake/derivative, derive/publish to a fixed point, render committed-before and official-after with the same provisional Cameron camera, review published mobile/desktop scene and card, and complete the native gates. Continue all remaining T-2377 picture differences after this bounded increment; no original match acceptance is implied. Source/date/metric limits and actual-versus-proposed proof are in docs/RESEARCH/hogan-picture-match-T-3118/README.md.
