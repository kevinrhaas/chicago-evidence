

## Hogan record-only continuation — T-3118 (2026-10-24, prepared)

The existing log controls are selected for a dark blind doorway recess, a reconstructed boarded gable proxy and a 0.75 m ridge-stack head. No producer/default changes. The documented footprint, coordinates/bearing, dates/use and other numerical form values remain unchanged. The Cameron source retains its credit, public-domain inventory attribution and independent publication/holding/date limits. Original T-2377 remains open and differs.

On PR1260 H8, all 82 existing log input recipes initially recheck; only Hogan's recipe changes after this edit. The other 81 recipes/records/master/web bytes and all 113 generator Python preimages remain exact. Current candidate raw geometry/material/confidence lists equal the actually rendered frozen continuation (236 polygons, 470 fan triangles); that isolated comparison remains differs. This is not a new official export. PR1260 must land first. Official one-master regeneration, real derivative, ordered native derivation/publish, fresh same-camera comparison, published scene/card/Images/grade review on both viewports, strict preflight and required published smoke gates remain pending. No heavy process has run for T-3118. See docs/RESEARCH/hogan-picture-match-T-3118/README.md.
