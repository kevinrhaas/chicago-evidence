# Publisher recovery — 2026-10-30 00:55 UTC

User authorizes PRs, policy checks, safe app-dev merges and periodic GitHub checkpoints. Never app main/production. Root owns coordination; resume_gt sole primary writer, frozen during resume_phone native probe. No publisher primary-source/Git/ref mutations.

PR1456 (Miller/Lighthouse/StMary/Hogan) currenthead dd1dfd88808ee36187825706cb71a5ad70bdd262/tree5f12, requiredCI40977278547 actual SUCCESS00:30. However dev advanced to a7ffed3c5108b20a24310f8a91ed4e0a18966b2e and PR is DIRTY. Conservative actual combined publishedGT+a7ff1904Lightphone FAILED401.035075MiB/400, zeroerrors, childrenreaped, source/Git unchanged. No merge allowed on old green. resume_phone tests minimal externalrailway allocationfix; do not weaken400MiB.

## Actual authorized native relap

Root approved /workspace/PR1456-fixed-branch-native-relap-prep-publisher-20261030/PLAN.json. Immutabledd1 updaterSHAa22f2c0dae0f40d38e4e0fcdf27d998844c56296f58141d816781f824605a67b confirmed; currentdev/main updater UNFIXED. Workflow dispatch MUST use originalPRbranch `steward/t2381-t2373-t2384-t2377-early-pictures-20261029`, inputs only1456, so nativejob executes fixedscript. Actual scopeddispatch00:46:23 run40981777368/job123823299919. At00:53 stillnativeLapstepIN_PROGRESS; no newpush yet.

Owned oldmarker24c9753c7e6b57ccbe32abb695d7aa930f7cdcf9 was ACTUALLY released using official unchangedticket.mjs copied to tiny isolated lock-scratch repo. Exactguard translated ownrelease to emptyrefpush lease24c975, no primarymutation. No foreignnativejobs active atprecheck; no foreigncancels/admin/forcecodepush.

Persistent observer /workspace/PR1456-fixed-branch-native-relap-prep-publisher-20261030/observe_native.py (execsession77992) polls scopedPR/run every10s. Afteractualnewhead it verifies genuineparents[dd1,a7ff], uses officialtool+nonexistentrefCAS to reacquire ownedparentlessemptytree lap, writes NEW-NATIVE-MARKER.json and REACQUIRED-RESULT.json. Do NOT take ownlock before botpush: nativeprepush recheck would abort it. Ifjobcompletesunchanged observer writes NO-PUSH-RESULT. LATEST/OBSERVER-LATEST.json are actualstatus, not proof ofpush. Newhead must get actualCI + repairednativephone qualification before normalsquash pinnedhead; no mergeyet. Officialremote tickets settle.yml onmain afteractualmerge thenverifyfourDONE; no localticketcachewrites whileGTguards.

## Actual durable checkpoints

712: closedGT51applyjournal/native61owners x3fixedpoint/publish/library952to955/currentconsumerDateddd1/phone395.8875, plusclosedSchool6/Bridge20/CarpenterTrowbridge+Kurz packets.111members3.04MBsource1.43MBRAMgzip, strictallmembershash/size/mode+foreignpathpreservation. https://github.com/kevinrhaas/chicago-evidence/blob/2111d45b80bb6036e38592b591abb6575c548fe4/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md

713: actualcombinedphoneFAIL, all13ordinaryexclusiveoverlaypostimages and exactcurrentGT67postownerrescue.37outermembers19.13MBsource/11.290MBRAMgzip in2losslesschunks; strictouter+ALL67nestedGTrawmembers hashes/sizes/modes reread afterimmutablechunkreassembly. https://github.com/kevinrhaas/chicago-evidence/blob/4cbb20d281d1e50f890445476abbb694738289d3/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md

Publication903d7d1c77bd98f9ef9e0c09e47277b1df104301. RootapprovedretireONLYownedlocalduplicateGTgzip6356007B afterstrictreadback/hash/nlink1; actualnet6.357MB reclaimed, all67currentprimarypostimagesuntouched. LOCAL-ARCHIVE-AVAILABILITY.json under /workspace/T2376-exact67-snapshot-and-rebind-20261030 has exact2chunkRAMrestoreinstructions. AB13payloads KEPT for phoneagent reuse, no11MBduplicate. Originalfailedproof frozenmetadata immutable713; phoneagent intentionallychangesONLYexternalrailway withnewepochbindings/results.

NewCLOSEDnative selected-bake Carpenter26members1.045MB /workspace/T2382-native-selected-bake-prep-20261030/CLOSED-MANIFEST.json SHA0d41e953db32d6581c214638522f1ef3ab3b3c4beb03a2b1d0c25acc486e3da3 and School15members172787B /workspace/T2372-native-selected-bake-reuse-20261030/CLOSED-MANIFEST.json SHA7f82abecc183c78480eb04d7b492e6c0af123220a6f6a47fe5d771d138c8239f. Batchwithnextactualphonefixclosure/newnativehead, notyetdurable. Mutablefixtureexcluded.

## Runtime/resources

Source /workspace/shared/resume-chicago-env.sh; neverprimaryfetch/implicitpromisor. ConfigSHA5536e1343e7abdacddfce3d5438e08872ad6a33295900466b529df5e0c57e730 maintained; GitHTTPblocked. Floors536870912WS/1800000000TMPcaller unchanged; nativeownscratchcontract permits temporarydipwithinitscommand, mustreapandrestorebefore nextcommand. Root is reclaiming ONLY3publicaptindexes (~91MB), no evidence/source/privateprofiles.

Two owned RAMprovider services exist: oldPID1973199 port33015, newPID1973848 port45943(execsession93705). Same41immutablea7ff/old87blobs27.28MBRAM each; metadata PROVIDER.json reflects newport. Bothsafe, rootaskedonlyverifiedownedduplicateclose afterphoneconsumers finish. Newprovideractivephone source. No rawpayloadsaved.

Root-approved78objecta7ffimport is PREPAREONLY with resume_gt. Price /workspace/currentdev-a7ff-bounded-price-publisher-20261030/RESULT.json, wrapperreference earlier /workspace/PR1456-current87-and009-combined-bounded-import-publisher-20261029/import_exact.py. Do not execute duringphoneguard; primarywriter/root approval needed. No actuala7ffimport yet.
