# Closed, bounded railway-normal memory repair

Primary source, Git HEAD/branch/index/config, Green Tree working paths and all 5,633 baseline published files stayed byte exact. Only the external A/B fixture's railway.js was intentionally changed after checkpoint713 strictly saved the original13 overlay payloads and actual failed run.

The proposed production edit is PATCH.diff: import/bind the existing compactStreams(THREE).compactNormals helper, then encode groundMesh's computed normal array before native spatial partitioning. Exactly3 inserted lines. The helper retains its existing Float32 fallback. Positions, UVs, alpha, confidence, indices, materials, tier and all ceilings remain unchanged.

Preimage railway SHA256:3117e6d7e6fd52766a2f71a488e6af06f556227b4031fa82667370d73beab5f8.
Postimage railway SHA256:e1c0fea0e26bf9f1062a6c91fe5ab4c70347f5ddec0adfa4a1c4d12f46cf2b5d.
Apply only after checking the actual current PR's railway source preimage. Source/current-head gates, native PR publication and merge are root/publisher work, not completed here.

Actual unchanged native1904Light mobile memory gate:FAIL401.035075MiB -> PASS396.955676MiB against400MiB. Candidate nativeexit0/no page errors/all children reaped. These are scoped GT+dd1 published inputs composed with immutable a7ff runtime consumers; not an exact newly merged four-building tree claim.

Actual normal visual comparison: three native qa_railway_reach_t2992 camera/frame paths, actual1904Light app with its explicit keep-geometry harness. Original float normals, existing native compactNormals on all10 actual ground batch normal streams, then original attributes restored in the same held frame. Quantizing before or after native attribute-copy partitioning gives the same per-vertex normalized values. Every restored frame is pixel exact. Ground-normal GPU allocation falls4,422,584bytes. Max normal angle0.367738degrees; maximum RGB channel change air1/south3/north1 out of255, with strong wrong-normal positive controls. Draw and triangle counts stay identical.

Do not call the whole visual runner green: its unchanged native triangle budget assertion produced rawEXIT1. AIR baseline/compact both1,677,951triangles and NORTH both1,672,907 exceed1,270,000; SOUTH baseline/compact776,445passes. Raw logs, JSON and reaper preserve that failure. The narrow representation change passes picture comparison; this is not a complete performance-smoke result and does not waive the shared ceiling.

Native incoming a7ff rail geometry/lifecycle/upload marking suite:103 assertions PASS against candidate producer (only external file-path binding changed, no assertions). Existing compact-attribute/batch check PASS, confidence-lane6/6PASS. No tests or primary source files were changed.

Root directly viewed all6 before/after captures and accepted the narrow repair, preserving the raw visual budget failure. CPU lease returned to Carpenter, then School and Sauganash, per root scheduling. No further probes are required for this packet.
