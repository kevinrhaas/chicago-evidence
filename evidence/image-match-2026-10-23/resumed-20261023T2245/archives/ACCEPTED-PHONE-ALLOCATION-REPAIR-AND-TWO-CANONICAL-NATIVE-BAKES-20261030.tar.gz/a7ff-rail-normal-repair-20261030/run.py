import sys
from pathlib import Path
sys.path.insert(0,'/workspace/a7ff-GT-native-phone-probe-20261030')
from prepare import B,A,R,sha,tree,source,guard
O=Path(__file__).parent
import os,json,subprocess,time,datetime,shutil
binding=json.loads((O/'BASELINE.json').read_text());build=json.loads((O/'BUILD.json').read_text());assert tree(B)==binding['public_files'];assert source()==binding['source'];guard()
root=Path('/workspace/a7ff-GT-native-phone-probe-20261030/runtime');overlay_before={x['path']:sha((root/x['path']).read_bytes())for x in build['overlays']};native=A/'tools/measure_memory.mjs';native_before=sha(native.read_bytes());ceilings=A/'tools/memory_ceilings.json';ceilings_before=sha(ceilings.read_bytes());E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',C4D_AB_ROOT=str(root),C4D_AB_REQUEST_LOG=str(O/'REQUESTS.jsonl'),NODE_OPTIONS='--require '+str(O/'observe.cjs'))
start=time.monotonic();cmd=['python3','/workspace/shared/run-with-reaping.py',str(O/'REAPER.json'),'--','taskset','-c','0,1,3,4','node','tools/measure_memory.mjs','--root',str(root),'--year','1904','--only','mobile','--gate','--no-snapshot','--json',str(O/'PHONE.json')]
(O/'INVOCATION.json').write_text(json.dumps({'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cmd':cmd,'cwd':str(A),'native_runner_sha256':native_before,'unchanged_native_ceilings_sha256':ceilings_before,'WS_free_caller':shutil.disk_usage('/workspace').free,'TMP_free_caller':shutil.disk_usage('/tmp').free},indent=2)+'\n')
with(O/'phone.log').open('x')as f:q=subprocess.run(cmd,cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
rp=json.loads((O/'REAPER.json').read_text());assert rp['all_children_reaped'];j=json.loads((O/'PHONE.json').read_text());assert len(j['rows'])==1;row=j['rows'][0];peak=row['totals']['total']/1048576
requests=[json.loads(x)for x in (O/'REQUESTS.jsonl').read_text().splitlines()];assert not any('observer_error'in x for x in requests);served={x.get('path'):x for x in requests if x['status']==200}
for p in overlay_before:
 if p in served:assert served[p]['sha256']==overlay_before[p]
for p in ['walk/js/railway.js','walk/js/tree-model.js','data/sidecars/1904/boot/part-4.json']:
 assert p in served,('critical runtime input not requested',p)
assert 'data/textures/trees/leaf_atlas.ktx2'in served or 'data/textures/trees/leaf_atlas.webp'in served
assert tree(B)==binding['public_files'];assert source()==binding['source'];assert overlay_before=={x['path']:sha((root/x['path']).read_bytes())for x in build['overlays']};assert native_before==sha(native.read_bytes())and ceilings_before==sha(ceilings.read_bytes());guard()
passed=q.returncode==0 and 0<peak<=400 and not row['errors'];r={'status':'ACTUAL_SCOPED_A7FF_GT_RAIL_NORMAL_REPAIR_1904_MOBILE_MEMORY_'+('PASS'if passed else'FAIL'),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_exit_code':q.returncode,'peak_MiB':peak,'limit_MiB':400,'headroom_MiB':400-peak,'seconds':time.monotonic()-start,'all_children_reaped':True,'baseline_public_files_exact':len(binding['public_files']),'all_working_GT_source_and_Git_paths_exact':True,'all_native_runner_and_ceilings_bytes_exact':True,'all_13_overlay_bytes_exact':True,'runtime_inputs_requested':{p:served[p]for p in overlay_before if p in served},'runtime_inputs_not_requested':[p for p in overlay_before if p not in served],'request_count':len(requests),'errors':row['errors'],'WS_free_post':shutil.disk_usage('/workspace').free,'TMP_free_post':shutil.disk_usage('/tmp').free,'scope':build['scope']};(O/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(0 if passed else 1)
