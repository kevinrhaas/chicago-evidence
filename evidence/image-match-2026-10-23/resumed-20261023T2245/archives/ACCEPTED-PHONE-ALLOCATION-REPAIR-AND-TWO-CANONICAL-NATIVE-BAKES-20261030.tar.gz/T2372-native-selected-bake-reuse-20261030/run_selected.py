from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,sys,stat
P=Path(__file__).resolve().parent; CP=Path('/workspace/T2382-native-selected-bake-prep-20261030'); F=CP/'fixture'; A=Path('/workspace/chicago/chicago/4d'); R=A.parent.parent
sid='chappel_infant_school'; name=sid+'__log_1833.glb'; recipe='2fe83632046f2462e58524944e13e970ace9824693f5141f3769c1b726537f44'
sha=lambda b:hashlib.sha256(b).hexdigest(); pf=lambda p:sha(p.read_bytes()); now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
assert os.environ.get('SCHOOL_NATIVE_SELECTED_CPU')=='root-approved-after-sauganash-close'
assert not (P/'RESULT.json').exists()
def floors():
 assert shutil.disk_usage('/workspace').free>=536870912
 assert shutil.disk_usage('/tmp').free>=1800000000
floors()
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
def git(args):return subprocess.check_output(['git','-C',str(R),*args],env=E)
def gitstate():return {'head':git(['rev-parse','HEAD']).decode().strip(),'status':sha(git(['status','--porcelain=v1','-uno'])),'config':pf(R/'.git/config'),'index':pf(R/'.git/index'),'refs':sha(git(['for-each-ref','--format=%(refname) %(objectname)']))}
state=gitstate()
cb_manifest=CP/'CLOSED-MANIFEST.json'; cb=json.loads(cb_manifest.read_text())
for row in cb['members']:
 q=Path(row['path']); assert q.stat().st_size==row['bytes'] and pf(q)==row['sha256']
producer_plan=json.loads((CP/'PLAN.json').read_text())
producer_rows=[row for row in producer_plan['copies'] if row['kind']=='unchanged_current_native_generator' or row['target'].startswith('fixture/tools/')]
for row in producer_rows:
 assert pf(Path(row['source']))==row['sha256'] and pf(CP/row['target'])==row['sha256']
source=Path('/workspace/T2372-currentGT-guarded-source-prep-20261030/current-packet/postimages/chicago/4d/data/structures/chappel_infant_school.json')
assert pf(source)=='bca1984c8d1993e107d502930380e5cec5b3443fca97249fbab7e6d8eac6e161'
s=json.loads(source.read_text()); assert not list((A/'data/structures/versions'/sid).glob('*.json'))
primary_inputs={str(p):pf(p) for p in [A/'data/structures'/f'{sid}.json',A/'data/sources/eliza_chappel_school_shore_view.json',A/'data/datum.json',*(A/'data/scenes').glob('*.json')]}
for path in git(['diff','--name-only','HEAD']).decode().splitlines():
 q=R/path
 if q.is_file(): primary_inputs[str(q)]=pf(q)
primary_assets={str(p):pf(p) for directory in ['gltf','web'] for p in (A/'assets'/directory).rglob('*.glb')}
primary_registries={k:pf(A/'assets'/k) for k in ['manifest.json','manifest.web.json','manifest.versions.json']}
# The closed Carpenter authority is independent of this explicitly disposable fixture.
cb_name='philo_carpenter_log_shop__log_1832.glb'; cb_slot=F/'assets/gltf'/cb_name
assert not cb_slot.is_symlink() and pf(cb_slot)==pf(CP/'closed-authority/native-master'/cb_name)
cb_slot.unlink(); cb_slot.symlink_to(A/'assets/gltf'/cb_name)
slot=F/'assets/gltf'/name; assert slot.is_symlink() and slot.resolve()==A/'assets/gltf'/name; slot.unlink()
assert not (F/'assets/web'/name).exists()
for k in primary_registries:shutil.copyfile(A/'assets'/k,F/'assets'/k)
shutil.copyfile(source,F/'data/structures'/f'{sid}.json')
sys.path.insert(0,str(F/'generators')); import mesh_inputs
recipe_doc=mesh_inputs.structure_inputs_doc(s,s['phases'][0]); assert mesh_inputs.structure_inputs_sha(s,s['phases'][0])==recipe
registries={k:json.loads((F/'assets'/k).read_text()) for k in primary_registries}
short=Path('/workspace/sc2372n30'); assert not short.exists(); short.mkdir(mode=0o700); E['TMPDIR']=str(short)
commands=[('BUILD',['/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender','--background','--factory-startup','--threads','2','--python-expr','import sys; sys.dont_write_bytecode=True','--python',str(F/'generators/build.py'),'--','--only',sid,'--wrote',str(P/'WROTE.txt')]),('WEB',['bash','tools/web_derivatives.sh','--only',name])]
plan={'status':'ROOT_APPROVED_SHARED_DISPOSABLE_FIXTURE_SELECTED_STAGES','at':now(),'fixture':str(F),'selected_id':sid,'output':name,'expected_recipe_sha256':recipe,'candidate_sha256':pf(source),'primary_before':state,'CB_closed_manifest_sha256':pf(cb_manifest),'CB_closed_members_verified':len(cb['members']),'native_producer_bindings':producer_rows,'commands':commands,'no_primary_writes':True,'not_full_bake_check_publish':True,'native_cache_prevention':'Blender startup expression sets sys.dont_write_bytecode before unchanged official build.py'}
(P/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
stages=[]
for stage,command in commands:
 floors(); log=P/(stage+'.log'); reap=P/(stage+'-REAPER.json'); t=time.monotonic()
 args=['python3','/workspace/shared/run-with-reaping.py',str(reap),'--','nice','-n','19','taskset','-c','3,4',*command]
 with log.open('x') as stream:q=subprocess.run(args,cwd=F,env=E,stdout=stream,stderr=subprocess.STDOUT)
 reaper=json.loads(reap.read_text()); row={'stage':stage,'actual_exit':q.returncode,'seconds':round(time.monotonic()-t,3),'argv':args,'all_children_reaped':reaper['all_children_reaped']}; stages.append(row); print(json.dumps(row),flush=True)
 assert q.returncode==0 and reaper['command_exit']==0 and reaper['all_children_reaped'],log.read_text()[-3000:]
assert (P/'WROTE.txt').read_text().splitlines()==[name]
post={k:json.loads((F/'assets'/k).read_text()) for k in registries}
for k,key in [('manifest.json','assets'),('manifest.web.json','masters')]:
 old=registries[k]; new=post[k]; assert set(old[key])==set(new[key]); assert {n:v for n,v in old[key].items() if n!=name}=={n:v for n,v in new[key].items() if n!=name}; assert {n:v for n,v in old.items() if n!=key}=={n:v for n,v in new.items() if n!=key}
assert registries['manifest.versions.json']==post['manifest.versions.json']
master=F/'assets/gltf'/name; web=F/'assets/web'/name
assert post['manifest.json']['assets'][name]['inputs_sha256']==recipe
assert post['manifest.web.json']['masters'][name]==pf(master)
expected={'MASTER':'fb141fef3f348b494ffbf1bc2479427d0cec499001605cdcb34ce52c93c0787a','WEB':'f120aa9abc970bb5b0b28f82c5fd176b268ba67923cea9b31de9967c8c9bf804'}
assert pf(master)==expected['MASTER'] and pf(web)==expected['WEB']
assert gitstate()==state
for p,h in primary_inputs.items():assert pf(Path(p))==h
for p,h in primary_assets.items():assert pf(Path(p))==h
for k,h in primary_registries.items():assert pf(A/'assets'/k)==h
for row in producer_rows:assert pf(Path(row['source']))==row['sha256'] and pf(CP/row['target'])==row['sha256']
for row in cb['members']:assert pf(Path(row['path']))==row['sha256']
C=P/'closed-authority'; C.mkdir(); members=[]
def preserve(src,rel):
 dest=C/rel; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dest); dest.chmod(stat.S_IMODE(src.stat().st_mode));members.append({'path':str(dest),'relative_path':str(dest.relative_to(P)),'bytes':dest.stat().st_size,'sha256':pf(dest),'mode':oct(stat.S_IMODE(dest.stat().st_mode))})
preserve(master,Path('native-master')/name); preserve(web,Path('native-web')/name); preserve(source,Path('candidate')/(sid+'.json'))
entries={'master':post['manifest.json']['assets'][name],'web_master_sha256':post['manifest.web.json']['masters'][name],'recipe_doc':recipe_doc,'recipe_sha256':recipe,'unchanged_native_producers_reference':str(CP/'CLOSED-MANIFEST.json'),'producer_reference_sha256':pf(cb_manifest)}
(C/'NATIVE-ENTRIES.json').write_text(json.dumps(entries,indent=2)+'\n')
for p in [C/'NATIVE-ENTRIES.json',P/'PLAN.json',P/'run_selected.py',P/'BUILD.log',P/'WEB.log',P/'BUILD-REAPER.json',P/'WEB-REAPER.json',P/'WROTE.txt']:
 members.append({'path':str(p),'relative_path':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':pf(p),'mode':oct(stat.S_IMODE(p.stat().st_mode))})
floors(); result={'status':'ACTUAL_OFFICIAL_SELECTED_SCHOOL_BUILD_AND_WEB_CLOSED_PASS_NOT_FULL_BAKE_CHECK_PUBLISH','at':now(),'stages':stages,'official_recipe_sha256':recipe,'MASTER_sha256':pf(master),'WEB_sha256':pf(web),'accepted_prototype_bytes_identical':True,'all_foreign_registry_rows_exact':True,'all_primary_asset_bytes_exact_count':len(primary_assets),'primary_changed_source_paths_guarded':len(primary_inputs),'primary_Git_state_unchanged':True,'primary_registries_unchanged':True,'CB_closed_authority_all_members_still_exact':True,'workspace_free':shutil.disk_usage('/workspace').free,'TMP_free':shutil.disk_usage('/tmp').free,'full_canonical_pipeline_qualified':False,'original_DONE':False,'fixture_disposable_excluded_from_closed_authority':True,'members':members}
(P/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n'); members.append({'path':str(P/'RESULT.json'),'relative_path':'RESULT.json','bytes':(P/'RESULT.json').stat().st_size,'sha256':pf(P/'RESULT.json'),'mode':oct(stat.S_IMODE((P/'RESULT.json').stat().st_mode))})
(P/'CLOSED-MANIFEST.json').write_text(json.dumps({'status':result['status'],'at':now(),'members':members,'bytes':sum(x['bytes'] for x in members),'fixture_disposable_excluded':True},indent=2)+'\n')
assert not list((F/'generators').rglob('__pycache__'))
print(json.dumps({k:v for k,v in result.items() if k!='members'},indent=2),flush=True)
