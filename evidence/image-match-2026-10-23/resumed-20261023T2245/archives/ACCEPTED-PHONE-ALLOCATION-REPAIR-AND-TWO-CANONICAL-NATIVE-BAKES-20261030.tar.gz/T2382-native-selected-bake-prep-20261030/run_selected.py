from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,sys,stat
P=Path(__file__).resolve().parent;F=P/'fixture';A=Path('/workspace/chicago/chicago/4d');R=A.parent.parent;plan=json.loads((P/'PLAN.json').read_text());name=plan['selected_output'];sid=plan['selected_id'];sha=lambda b:hashlib.sha256(b).hexdigest();pf=lambda p:sha(p.read_bytes())
assert os.environ.get('CARPENTER_NATIVE_SELECTED_CPU')=='root-approved-after-phone-close','CPU lease not granted'
assert not (P/'RESULT.json').exists();assert shutil.disk_usage('/workspace').free>=536870912;assert shutil.disk_usage('/tmp').free>=1800000000
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
def gitstate():return {'head':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],env=E,text=True).strip(),'status':sha(subprocess.check_output(['git','-C',str(R),'status','--porcelain=v1','-uno'],env=E)),'config':pf(R/'.git/config'),'index':pf(R/'.git/index')}
state=gitstate();assert state['head']==plan['primary_head'];assert state['status']==plan['primary_tracked_status_sha256']
for row in plan['copies']:
 assert pf(Path(row['source']))==row['sha256'];assert pf(P/row['target'])==row['sha256']
registries={k:json.loads((F/'assets'/k).read_text())for k in ['manifest.json','manifest.web.json','manifest.versions.json']};primary_registries={k:pf(A/'assets'/k)for k in registries}
foreign_asset_shas={str(p):pf(p)for directory in ['gltf','web']for p in (A/'assets'/directory).rglob('*.glb')};assert not (F/'assets/gltf'/name).exists();assert not (F/'assets/web'/name).exists()
short=Path('/workspace/cb2382n30');assert not short.exists();short.mkdir(mode=0o700);E['TMPDIR']=str(short)
stages=[]
for stage,command in zip(['BUILD','WEB'],plan['commands']):
 assert shutil.disk_usage('/workspace').free>=536870912;assert shutil.disk_usage('/tmp').free>=1800000000
 log=P/(stage+'.log');reap=P/(stage+'-REAPER.json');t=time.monotonic();args=['python3','/workspace/shared/run-with-reaping.py',str(reap),'--','nice','-n','19','taskset','-c','3,4',*command['argv']]
 with log.open('x')as stream:q=subprocess.run(args,cwd=command['cwd'],env=E,stdout=stream,stderr=subprocess.STDOUT)
 result=json.loads(reap.read_text());row={'stage':stage,'actual_exit':q.returncode,'seconds':round(time.monotonic()-t,3),'command':args,'all_children_reaped':result['all_children_reaped']};stages.append(row);print(json.dumps(row),flush=True)
 assert q.returncode==0 and result['command_exit']==0 and result['all_children_reaped'],log.read_text()[-3000:]
assert (P/'WROTE.txt').read_text().splitlines()==[name]
post={k:json.loads((F/'assets'/k).read_text())for k in registries}
for k,key in [('manifest.json','assets'),('manifest.web.json','masters')]:
 old=registries[k];new=post[k];assert set(old[key])==set(new[key]);assert {n:v for n,v in old[key].items()if n!=name}=={n:v for n,v in new[key].items()if n!=name};assert {n:v for n,v in old.items()if n!=key}=={n:v for n,v in new.items()if n!=key}
assert registries['manifest.versions.json']==post['manifest.versions.json']
assert post['manifest.json']['assets'][name]['inputs_sha256']==plan['candidate_recipe_sha256'];master=F/'assets/gltf'/name;web=F/'assets/web'/name;assert post['manifest.web.json']['masters'][name]==pf(master)
expected={'MASTER':'f3e26f650627f36879087d75f30db5c4553e0f5938ae5bd0d305480958549cfc','WEB':'28128016f74b90fe5359f7245c9518dac519b8fc1eeeeaa9d326838f5fcfc05a'}
assert pf(master)==expected['MASTER'];assert pf(web)==expected['WEB']
assert gitstate()==state
for k,v in primary_registries.items():assert pf(A/'assets'/k)==v
assert {p:pf(Path(p))for p in foreign_asset_shas}==foreign_asset_shas
for row in plan['copies']:assert pf(Path(row['source']))==row['sha256']
C=P/'closed-authority';C.mkdir();out=[]
def preserve(src,rel):
 dest=C/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);dest.chmod(stat.S_IMODE(src.stat().st_mode));out.append({'path':str(dest),'relative_path':str(dest.relative_to(C)),'bytes':dest.stat().st_size,'sha256':pf(dest),'mode':oct(stat.S_IMODE(dest.stat().st_mode))})
preserve(master,Path('native-master')/name);preserve(web,Path('native-web')/name);preserve(F/f'data/structures/{sid}.json',Path('candidate')/(sid+'.json'))
for rel in ['generators/build.py','generators/mesh_inputs.py','generators/code_inputs.py','generators/blender.pin','generators/archetypes/log_dwelling_params.py','generators/emit.py','generators/archetypes/log_dwelling.py','generators/common/logwork.py','generators/common/materials.py','generators/common/mesh.py','generators/common/openings.py','tools/web_derivatives.sh']:preserve(F/rel,Path('native-producer')/rel)
entries={'master':post['manifest.json']['assets'][name],'web_master_sha256':post['manifest.web.json']['masters'][name],'recipe_doc':plan['candidate_recipe_doc'],'recipe_sha256':plan['candidate_recipe_sha256']};(C/'NATIVE-ENTRIES.json').write_text(json.dumps(entries,indent=2)+'\n');out.append({'path':str(C/'NATIVE-ENTRIES.json'),'relative_path':'NATIVE-ENTRIES.json','bytes':(C/'NATIVE-ENTRIES.json').stat().st_size,'sha256':pf(C/'NATIVE-ENTRIES.json'),'mode':oct(stat.S_IMODE((C/'NATIVE-ENTRIES.json').stat().st_mode))})
result={'status':'ACTUAL_OFFICIAL_SELECTED_BUILD_AND_WEB_CLOSED_PASS_NOT_FULL_BAKE_CHECK_PUBLISH','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':stages,'official_recipe_sha256':plan['candidate_recipe_sha256'],'official_inputs_doc_exact':True,'MASTER_sha256':pf(master),'WEB_sha256':pf(web),'accepted_prototype_bytes_identical':True,'all_foreign_registry_rows_exact':True,'all_primary_asset_bytes_exact_count':len(foreign_asset_shas),'primary_source_Git_state_unchanged':True,'primary_registries_exact':primary_registries,'workspace_free':shutil.disk_usage('/workspace').free,'TMP_free':shutil.disk_usage('/tmp').free,'canonical_current_pipeline_qualified':False,'original_DONE':False,'fixture_disposable':True,'fixture_may_be_reused_for_school_only_after_closed_authority_hash_verification':True,'closed_authority':out};assert result['workspace_free']>=536870912 and result['TMP_free']>=1800000000
(P/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['closed_authority','primary_registries_exact']},indent=2),flush=True)
