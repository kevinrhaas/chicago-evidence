from pathlib import Path
import os,sys,json,subprocess,hashlib,datetime,shutil,gzip,zipfile,io,fnmatch,xml.etree.ElementTree as ET
os.sched_setaffinity(0,{2})
repo=Path('/tmp/tremont-picture-20261026');app=repo/'chicago/4d';out=Path('/tmp/T2385-capacity-causal-finish-20261026');assert not out.exists();out.mkdir()
env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(TMPDIR='/tmp/t2385-capacity',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');Path(env['TMPDIR']).mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=repo,env=env)
assert git('write-tree').decode().strip()=='55b54d320ed165b4d7a7346884d420d923092e4c'
tracked=[p for p in git('ls-files','-z').decode().split('\0')if p]
manifest=json.loads((app/'tools/derived_manifest.json').read_text());generated={p for s in manifest['steps']for p in s.get('resolves',[])}
direct={'chicago/4d/data/reconstruction/1835_lodging_model.json','chicago/4d/docs/RESEARCH/1835_lodging_model.md','chicago/4d/data/reconstruction/1835_lodgers_seated.json','chicago/4d/data/reconstruction/1835_order_book.json'}
own={'chicago/4d/data/structures/tremont_house_1.json','chicago/4d/docs/STATUS.md','chicago/4d/docs/RESEARCH/tremont_house_1.md'}
residents={p:(repo/p).read_bytes()for p in tracked if p.startswith('chicago/4d/data/residents/')}
outside={p for p in tracked if not p.startswith('chicago/4d/')}
def is_generated(p):return any(p==q or p.startswith(q.rstrip('/')+'/')or fnmatch.fnmatch(p,q)for q in generated)
protected=json.loads(Path('/tmp/T2385-capacity-causal-closure-20261026/PROTECTED-BEFORE.json').read_text())
for rel in git('diff','--name-only').decode().splitlines():
    if rel in residents:residents[rel]=git('show','55b54d320ed165b4d7a7346884d420d923092e4c:'+rel)
(out/'PROTECTED-BEFORE.json').write_text(json.dumps(protected,indent=2)+'\n')
old_ledger=json.loads(Path('/tmp/T2385-capacity-causal-closure-20261026/lodgers-ledger-before.json').read_text());old_model=json.loads(git('show','55b54d320ed165b4d7a7346884d420d923092e4c:chicago/4d/data/reconstruction/1835_lodging_model.json'))
(out/'lodgers-ledger-before.json').write_text(json.dumps(old_ledger,indent=2)+'\n')
def reduced_card(d):
    d=json.loads(json.dumps(d))
    if isinstance(d,dict)and 'lodging_household'in d:
        current=d['lodging_household']['beds_ordinary']
        for person in d.get('persons',[]):
            if isinstance(person.get('note'),str):person['note']=person['note'].replace(f'the current model reports {current}', 'the current model reports CURRENT_ESTIMATE')
            if isinstance((person.get('basis')or{}).get('note'),str):person['basis']['note']=person['basis']['note'].replace(f'the current model reports {current}', 'the current model reports CURRENT_ESTIMATE')
        for k in ('beds_ordinary','stands_on','withdrawn_if'):d['lodging_household'].pop(k,None)
        for link in d.get('associated_with',[]):
            if link.get('kind')=='lodging':
                link.pop('note',None)
                if isinstance(link.get('basis'),dict):link['basis'].pop('note',None)
    return d
def verify_population(label):
    now={str(p.relative_to(repo))for p in (app/'data/residents').rglob('*')if p.is_file()and not p.name.startswith('.')}
    # Only tracked/native resident files are admitted; no new household or person path.
    assert now==set(residents),(label,'resident_file_set_changed',len(now),len(residents))
    changed=[]
    for p,before in residents.items():
        after=(repo/p).read_bytes()
        if before==after:continue
        assert p.endswith('.json'),(label,'nonJSON_population_change',p)
        x,y=json.loads(before),json.loads(after)
        assert reduced_card(x)==reduced_card(y),(label,'identity_seat_or_other_resident_change',p)
        assert len(x.get('persons',[]))==len(y.get('persons',[])),(label,'person_count_changed',p)
        for oldp,newp in zip(x.get('persons',[]),y.get('persons',[])):
            exact_expected=json.loads(json.dumps(oldp));old_n=x['lodging_household']['beds_ordinary'];new_n=y['lodging_household']['beds_ordinary']
            if isinstance(exact_expected.get('note'),str):exact_expected['note']=exact_expected['note'].replace(f'the current model reports {old_n}',f'the current model reports {new_n}')
            if isinstance((exact_expected.get('basis')or{}).get('note'),str):exact_expected['basis']['note']=exact_expected['basis']['note'].replace(f'the current model reports {old_n}',f'the current model reports {new_n}')
            assert exact_expected==newp,(label,'person_identity_or_noncapacity_explanation_changed',p,oldp.get('id'))
        changed.append({'path':p,'before_sha256':sha(before),'after_sha256':sha(after),'allowed':'ONLY household lodging current ordinary-bed count/stands_on/withdrawn_if and associated lodging explanation note/basis.note; all person identities/names/IDs/source grades/home/seat targets/dates/other fields exact; ONLY literal current model reports OLD→NEW also allowed in person.note/basis.note'})
    ledger=json.loads((app/'data/reconstruction/1835_lodgers_seated.json').read_text())
    stable=('quota_basis','seats','minted','fills','child_fills','top_up_fills','youth_top_up_fills','working_fills','household_fills','keeper_families','keepers','refusals','capacity_allocation_basis')
    for k in stable:assert ledger[k]==old_ledger[k],(label,'allocation_seat_quota_changed',k)
    assert [h['id']for h in old_ledger['houses']]==[h['id']for h in ledger['houses']],(label,'house_set_changed')
    for a,b in zip(old_ledger['houses'],ledger['houses']):
        assert {k:v for k,v in a.items()if k not in ('beds_ordinary','at_its_ordinary_night_figure')}=={k:v for k,v in b.items()if k not in ('beds_ordinary','at_its_ordinary_night_figure')},(label,'house_identity_occupancy_crowded_changed',a['id'])
    proof={'label':label,'resident_files':len(residents),'changed_reporting_only':changed,'all_person_fields_exact_except_proven_literal_current_capacity_explanation':True,'all_seat_mintedID_quota_allocation_blocks_exact':list(stable),'all_house_identity_occupancy_crowded_limits_exact':True}
    (out/(label+'-POPULATION-PROOF.json')).write_text(json.dumps(proof,indent=2)+'\n');return proof
def verify_controls(label):
    changed={p:{'before':v,'after':sha((repo/p).read_bytes())}for p,v in protected.items()if sha((repo/p).read_bytes())!=v}
    import copy
    sys.path.insert(0,str(app/'tools'));import compile_scene as native
    caps=native.compile_lodging();occupancy=native.compile_lodging_occupancy()
    allowed={f"chicago/4d/data/sidecars/1835/{k}.json"for k,v in caps.items()if k in {p['id']for p in old_model['places']}and v['beds_ordinary']!=next(p['beds_ordinary']for p in old_model['places']if p['id']==k)}
    allowed.add('chicago/4d/data/sidecars/1835/versions/tremont_house_1/gifford-reading.json')
    assert set(changed)<=allowed,(label,'noncapacity_control_changed',set(changed)-allowed)
    reports=[]
    for rel in changed:
        old=json.loads(git('show','55b54d320ed165b4d7a7346884d420d923092e4c:'+rel));new=json.loads((repo/rel).read_text());key=new['id'];expected=copy.deepcopy(caps[key]);expected['occupancy']=occupancy[key]
        assert new['lodging']==expected,(label,'native_capacity_projection_mismatch',rel)
        x=copy.deepcopy(old);y=copy.deepcopy(new);before=x.pop('lodging')['beds_ordinary'];after=y.pop('lodging')['beds_ordinary']
        if rel=='chicago/4d/data/sidecars/1835/tremont_house_1.json':
            assert x['documented_range']['sources']==['andreas_1884_v1','chicagology_prefire021','gale_1902_tremont_town_walk'];x['documented_range']['sources'].remove('gale_1902_tremont_town_walk')
        for resident in x.get('residents',[]):
            if isinstance(resident.get('why'),str):resident['why']=resident['why'].replace(f'The current estimate is {before},',f'The current estimate is {after},')
            for person in resident.get('persons',[]):
                if isinstance(person.get('note'),str):person['note']=person['note'].replace(f'the current model reports {before}',f'the current model reports {after}')
        assert x==y,(label,'noncapacity_sidecar_field_changed',rel)
        reports.append({'path':rel,'before_ordinary':before,'after_ordinary':after,'native_lodging_and_occupancy_projection_exact':True,'all_geometry_material_placement_flags_sources_other_than_explicit_range_and_resident_identities_exact':True})
    (out/(label+'-PROTECTED.json')).write_text(json.dumps({'count':len(protected),'changed_only_proven_native_capacity_sidecars':reports,'all_other_controls_exact':True},indent=2)+'\n')
steps=[]
def command(name,cmd):
    free=shutil.disk_usage('/tmp').free;assert free>=536870912,(name,'external512MiBreserve',free)
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();print(name,'START',start,flush=True)
    with(out/(name+'.log')).open('x')as log:r=subprocess.run(cmd,cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
    row={'name':name,'command':cmd,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'free_before':free,'free_after':shutil.disk_usage('/tmp').free};steps.append(row);(out/'STEPS.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0,(name,r.returncode)
# Resume after the TWO actual native owners already closedPASS; original local guardFAIL preserved.
p=app/'data/structures/tremont_house_1.json';fixed=json.loads(p.read_text());assert fixed['phases'][0]['documented_range']['sources']==['andreas_1884_v1','chicagology_prefire021']
sys.path.insert(0,str(app/'generators'));from mesh_inputs import structure_inputs_sha
assert structure_inputs_sha(fixed,fixed['phases'][0])=='717398e00f8c2d31353e07b3afbae89cd2679969283210b5572ef6f1f35ba70f'
expected=json.loads(Path('/tmp/tremont-T2385-app-prepared-20261026/expected.json').read_text())
for e in expected['outputs']:assert sha((app/e['path']).read_bytes())==e['sha256']
prior=json.loads(Path('/tmp/T2385-capacity-causal-closure-20261026/STEPS.json').read_text());assert len(prior)==2 and all(x['exit_code']==0 for x in prior)
print('RESUME after native2owners PASS; original supplementary guardFAIL preserved. Exactliteral metadata reader correction only.',flush=True)
verify_population('after-two-owners');verify_controls('after-two-owners')
new_model=json.loads((app/'data/reconstruction/1835_lodging_model.json').read_text());old={x['id']:x for x in old_model['places']};new={x['id']:x for x in new_model['places']};deltas=[{'id':k,'old_ordinary':old[k]['beds_ordinary'],'new_ordinary':v['beds_ordinary'],'crowded':v['beds_crowded']}for k,v in new.items()if old[k]['beds_ordinary']!=v['beds_ordinary']];assert len(deltas)==9
assert new['tremont_house_1']['beds_ordinary']==6 and new['tremont_house_1']['beds_crowded']==35
(out/'NATIVE-CAPACITY-DELTA.json').write_text(json.dumps({'changed_ordinary_rows':deltas,'Tremont_floor_m2':111.48,'actual_occupants_preserved':12,'crowded_35_is_existing_1840_town_proxy_not_a_dated_Tremont_room_count':True},indent=2)+'\n')
note='''\n\nT-2385 native capacity correction, 2026-10-26: the first full1070-step gate\nretained four lodging-related failures. Its61-step tail had not run the direct\nnative lodging owners. The unnecessary new Gale lifetime-range citation was\nremoved while retaining Gale on the dimensions, storeys and paint; all phase\ndates and eligibility stay exact. Native build_lodging_model_1835 and\nseat_lodgers_1835 now report111.48m² over two storeys and six ordinary-night beds\nfor Tremont, down from17. Eight other inns' ordinary estimates rebalance under\nthe existing fixed class total. The actual12 residents, every person identity/name/seat,\nsource grade, minted ID, quota and carried allocation remain exact. The existing\ncrowded limit35 is the1840 town model's proxy, not an attested Tremont room count;\nit is unchanged. The keeper home's tie is inferred, and the lodger seats remain\nreconstructed even where a person's identity is attested. These native owners\nchange current-capacity reporting, not who lives in the house. No geometry,\ncrowding rule, new ratio, dated availability or population allocation is changed.\nThe earlier fullFAIL remains preserved; final downstream/gate results are\nreported separately when actually closed.\n'''
assert 'T-2385 native capacity correction' in (app/'docs/STATUS.md').read_text()
assert 'T-2385 native capacity correction' in (app/'docs/RESEARCH/tremont_house_1.md').read_text()
# Earliest registered consumer of the rewritten resident cards is index step88;
# use its native115-step downstream tail, not a full202 or handwritten stamps.
assert manifest['steps'][87]['command']==['python3','tools/rebuild_resident_index.py','--write']
prior_tail=json.loads(Path('/tmp/T2385-capacity-causal-resume-20261026/STEPS.json').read_text());assert len(prior_tail)==1 and prior_tail[0]['exit_code']==0;assert 'last one moved nothing' in Path('/tmp/T2385-capacity-causal-resume-20261026/03-native-downstream115.log').read_text();print('Native115alreadyPASS2laps; no repeat.',flush=True)
verify_population('after-downstream115');verify_controls('after-downstream115')
binary={p for p in tracked if p.endswith(('.xlsx','.gz'))};assert len(binary)==44
dirty={p for p in git('diff','132e0e85a9645055de1bfc4544942ec969b14511','--name-only','-z').decode().split('\0')if p};targets=sorted(binary|{p for p in dirty if not p.startswith('chicago/4d/')})
def xlsx_members(b):
    with zipfile.ZipFile(io.BytesIO(b))as z:
        result={}
        for name in z.namelist():
            data=z.read(name)
            if name.endswith(('.xml','.rels')):
                root=ET.fromstring(data)
                if name=='docProps/core.xml':
                    for node in list(root):
                        if node.tag=='{http://purl.org/dc/terms/}modified':root.remove(node)
                result[name]=ET.canonicalize(ET.tostring(root,encoding='unicode'))
            else:result[name]=data.hex()
        return result
audit=[]
for rel in targets:
    p=repo/rel;now=p.read_bytes();old=git('show','132e0e85a9645055de1bfc4544942ec969b14511:'+rel);equal=now==old;kind='EXACT_BYTES'
    if not equal and rel.endswith('.xlsx'):kind='ALL_XLSX_MEMBERS_EXCEPT_MODIFIED_TIMESTAMP';equal=xlsx_members(now)==xlsx_members(old)
    elif not equal and rel.endswith('.gz'):
        kind='GZIP_DECOMPRESSED_BYTES';equal=gzip.decompress(now)==gzip.decompress(old)
        if not equal:
            try:equal=json.loads(gzip.decompress(now))==json.loads(gzip.decompress(old));kind='GZIP_JSON_SEMANTICS'
            except(ValueError,UnicodeError):pass
    elif not equal:
        try:equal=json.loads(now)==json.loads(old);kind='JSON_SEMANTICS'
        except(ValueError,UnicodeError):kind='REAL_OR_UNCLASSIFIED_CHANGE'
    rec={'path':rel,'comparison':kind,'equal':equal,'current_sha256':sha(now),'incoming132e_sha256':sha(old),'action':'UNCHANGED'if now==old else'RESTORE_WHOLE_PROOF_EQUAL_ONLY'if equal else'RETAIN_REAL_CHANGE'};audit.append(rec)
    if now!=old:
        q=out/'regenerated-before-normalization'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(now)
        if equal:p.write_bytes(old)
(out/'ALL44-AND-OUTSIDE4D-AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
command('04-native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'])
command('05-native-final-publish',['bash','tools/publish.sh'])
for name,cmd in [('06-causal-reconstruction',['python3','tools/reconstruct_residents_1835.py','--check']),('07-causal-lodging-model',['python3','tools/build_lodging_model_1835.py','--check']),('08-causal-boarders',['python3','tools/seat_lodgers_1835.py','--check']),('09-causal-boarders-selftest',['python3','tools/seat_lodgers_1835.py','--self-test'])]:command(name,cmd)
verify_population('final');verify_controls('final')
for e in expected['outputs']:assert sha((app/e['path']).read_bytes())==e['sha256']
result={'status':'PASS_MINIMAL_NATIVE_CAPACITY_CLOSURE_NO_RESEATING','finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':steps,'protected_count':len(protected),'resident_files':len(residents),'capacity_delta':deltas,'same_actual_Tremont_occupants':12,'unchanged_crowded_proxy':35,'same_two_master_two_WEB_hashes':True,'no_exports_or_app':True,'earlier_FULL4_FAILURE_retained':True,'pending':'Corrected complete source checkpoint, required full3questions at actual2joblease; no codecommit/PR yet, originalT2385 remainsOPEN/DIF.'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
