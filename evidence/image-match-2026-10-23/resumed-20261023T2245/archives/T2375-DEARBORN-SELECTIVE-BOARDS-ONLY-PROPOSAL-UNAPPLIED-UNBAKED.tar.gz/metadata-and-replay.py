from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, sys, tempfile
sys.dont_write_bytecode=True
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
HERE=Path(__file__).resolve().parent
REPO='/tmp/chicago-log-integration';BASE='33a99a557bd53aa637cc7173589d610f8a15f14b'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(p):return subprocess.check_output(['git','-C',REPO,'show',BASE+':chicago/4d/'+p])
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
guard=load('selective_bridge_guard',HERE/'guarded-apply.py')
rows=json.loads((HERE/'file-guards.json').read_text())
with tempfile.TemporaryDirectory(prefix='T2375-board-only-replay-') as temp:
 root=Path(temp)
 for row in rows:
  path=root/row['path'];path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(git(row['path'].removeprefix('chicago/4d/')))
 assert not guard.guard(root)
 subprocess.run([sys.executable,str(HERE/'guarded-apply.py'),'--root',str(root)],check=True)
 # A stale source fails before any file is written. Restore only this disposable fixture.
 source=root/'chicago/4d/data/sources/andreas_1884_dearborn_drawbridge_plate.json';saved=source.read_bytes();source.write_bytes(saved+b'\n')
 assert guard.guard(root)==['chicago/4d/data/sources/andreas_1884_dearborn_drawbridge_plate.json']
 other=[sha((root/r['path']).read_bytes()) for r in rows if root/r['path']!=source]
 attempt=subprocess.run([sys.executable,str(HERE/'guarded-apply.py'),'--root',str(root),'--apply'],capture_output=True,text=True)
 assert attempt.returncode and 'REFUSED' in attempt.stderr+attempt.stdout
 assert other==[sha((root/r['path']).read_bytes()) for r in rows if root/r['path']!=source]
 source.write_bytes(saved)
 subprocess.run([sys.executable,str(HERE/'guarded-apply.py'),'--root',str(root),'--apply'],check=True)
 assert all(sha((root/r['path']).read_bytes())==r['after_sha256'] for r in rows)
 # Append-only means the actual complete public bytes are an exact raw prefix.
 assert (root/'chicago/4d/docs/LIBERTIES.md').read_bytes()==git('docs/LIBERTIES.md')+(HERE/'LIBERTIES.fragment.md').read_bytes()
 # Snapshot the tiny native parser/schema dependency closure inside temporary paths.
 tools=root/'chicago/4d/tools';tools.mkdir()
 for p in ['compile_liberties.py','readable_text.py','compile_summaries.py']:(tools/p).write_bytes(git('tools/'+p))
 compiler=load('bridge_selective_lib_parser',tools/'compile_liberties.py')
 fragment=(HERE/'LIBERTIES.fragment.md').read_text()
 entries,errors=compiler.parse('## Per-subject liberties\n'+fragment,{'dearborn_street_drawbridge':'Dearborn Street drawbridge'})
 assert not errors,errors
 assert len(entries)==1
 expected=[{'domain':'structure','structure':'dearborn_street_drawbridge','phase':'draw_1834','aspect':'form.railing_kind'}]
 assert entries[0]['covers']==expected,entries[0]['covers']
 import jsonschema
 schema=json.loads(git('data/structures.schema.json'));record=json.loads((root/'chicago/4d/data/structures/dearborn_street_drawbridge.json').read_text())
 jsonschema.Draft202012Validator(schema,format_checker=jsonschema.FormatChecker()).validate(record)
 source_json=json.loads(source.read_text());assert source_json['id']=='andreas_1884_dearborn_drawbridge_plate' and source_json['rights_status']=='public_domain'
 hold=json.loads(git('data/sources/dearborn_street_bridge_1834_engraving.json'));assert hold['rights_status']=='check_required'
 # Whole-building and form confidence are not promoted; only the single inferred form is new.
 old=json.loads(git('data/structures/dearborn_street_drawbridge.json'))
 newform=record['phases'][0]['form'];assert newform['railing_kind']['confidence']=='inferred'
 assert {k:v for k,v in newform.items() if k!='railing_kind'}==old['phases'][0]['form']
 parser_guards={p:sha(git('tools/'+p)) for p in ['compile_liberties.py','readable_text.py','compile_summaries.py']}
proof={'scope':'SMALL_TEMP_FILE_FIXTURE_NOT_WORKTREE; schema/native parse and guarded patch replay only',
 'base':BASE,'patch_sha256':sha((HERE/'board-only.patch').read_bytes()),'six_preimage_check_and_apply_replay_exact':True,
 'stale_source_negative_refuses_before_any_write':True,'Lib_entire_base_prefix_exact':True,'one_exact_Lib_covers':expected,
 'structure_schema_with_date_formats':'PASS','Baker_hold':'check_required unchanged','Andreas_PD_source':'retained credited correction',
 'source_date_phase_location_existing_form_grades':'unchanged','source_parser_dependencies':parser_guards,
 'schema_sha256':sha(git('data/structures.schema.json')),'fixture_removed':True,'canonical_writes':False,
 'official_bake_browser_native_writers_fullgate':'NOT_RUN'}
(HERE/'metadata-replay-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print('PASS exact6path dryrun/replay; stale-preimage refusal; append-only Lib/Covers; schema; rights/date/grade controls')
