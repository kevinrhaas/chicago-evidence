"""Strict preimages; dry-run by default. Never recompose stale shared files."""
from pathlib import Path
import argparse, hashlib, json, subprocess
HERE=Path(__file__).resolve().parent
def sha(data):return hashlib.sha256(data).hexdigest()
def guard(root):
 errors=[]
 for row in json.loads((HERE/'file-guards.json').read_text()):
  p=root/row['path']
  if not p.is_file() or sha(p.read_bytes())!=row['before_sha256']:errors.append(row['path'])
 return errors
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True);parser.add_argument('--apply',action='store_true');args=parser.parse_args()
 errors=guard(args.root)
 if errors:raise SystemExit('REFUSED changed/missing preimages: '+', '.join(errors))
 patch=HERE/'board-only.patch'
 subprocess.run(['git','-C',str(args.root),'apply','--check',str(patch)],check=True)
 if args.apply:
  if guard(args.root):raise SystemExit('REFUSED preimages changed during check')
  subprocess.run(['git','-C',str(args.root),'apply',str(patch)],check=True)
  for row in json.loads((HERE/'file-guards.json').read_text()):assert sha((args.root/row['path']).read_bytes())==row['after_sha256']
  print('APPLIED exact six-path postimages; native generation/gates still owed')
 else:print('PASS exact six preimages and git apply --check; DRY RUN ONLY')
if __name__=='__main__':main()
