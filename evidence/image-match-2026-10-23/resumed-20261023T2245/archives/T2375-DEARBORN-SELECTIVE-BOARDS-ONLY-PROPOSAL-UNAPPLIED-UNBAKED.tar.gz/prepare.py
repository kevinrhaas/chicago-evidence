"""Prepare external selective files from immutable public git objects only."""
from pathlib import Path
import ast, copy, difflib, hashlib, json, subprocess

OUT=Path(__file__).resolve().parent
REPO='/tmp/chicago-log-integration'
BASE='33a99a557bd53aa637cc7173589d610f8a15f14b'
OLD=Path('/tmp/chicago-next-model/T-2375')
AUDIT=Path('/tmp/chicago-next-model/T-2375-source-audit-closed-20261023T1150')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(path):return subprocess.check_output(['git','-C',REPO,'show',BASE+':chicago/4d/'+path])
paths=['generators/archetypes/bridge_timber.py','generators/archetypes/bridge_timber_params.py',
 'data/structures/dearborn_street_drawbridge.json','data/sources/andreas_1884_dearborn_drawbridge_plate.json',
 'data/reconstruction/name_pool_keys.json','docs/LIBERTIES.md']
before={p:git(p) for p in paths}
for p in paths[:2]:assert before[p]==(OLD/'before/chicago/4d'/p).read_bytes()
after={p:before[p] for p in paths}
after[paths[0]]=(OLD/'after/chicago/4d'/paths[0]).read_bytes()
params=(OLD/'after/chicago/4d'/paths[1]).read_text()
assert params.count('    railing_kind: str = "pole"')==1
params=params.replace('    railing_kind: str = "pole"','    railing_kind: str = field(default="pole", kw_only=True)')
after[paths[1]]=params.encode()
old_record=json.loads(before[paths[2]])
field=copy.deepcopy(json.loads((OLD/'after/chicago/4d'/paths[2]).read_text())['phases'][0]['form']['railing_kind'])
field['note']='HORIZONTAL-BOARD PARAPETS. The public-domain plate published in Andreas in 1884, page 631, draws broad side parapets with horizontal joints along the approaches and closed draw. This is retrospective pictorial form, inferred for the 1835 bridge rather than a contemporary specification, coordinate, footprint dimension or surveyed height. Retain the existing 0.95 m overall parapet height and approximately 2.2 m post bays; five 162 mm courses, 40 mm thickness, 10 mm gaps, 40 mm lower clearance and 200 by 60 mm cap are reconstructed scantlings. Panels and caps stop at post bays, draw ends and the existing two-leaf meeting line. Post heads end at 0.89 m under the cap. The old pole-rail description records the prior default detail. The flat deck, original cribs and every existing height/placement control remain unchanged; the central rise, approaches, mechanism and camera remain unresolved. No accepted match is claimed.'
text=before[paths[2]].decode();anchor='        "railing": {';assert text.count(anchor)==1
block='\n'.join('      '+line for line in json.dumps({'railing_kind':field},ensure_ascii=False,indent=2).splitlines()[1:-1])+',\n'
text=text.replace(anchor,block+anchor)
key='"research_note": ';start=text.index(key)+len(key);value,n=json.JSONDecoder().raw_decode(text[start:])
add='PICTURE-BOUNDED PARAPET TRIAL: the 1884 Andreas engraving signed L. Braunhold shows horizontal-board side infill. Boarded form is inferred; member sections, courses, clearances, joints and neutral finish are reconstructed. This bounded increment keeps the existing flat closed deck and original crib layout. The drawn rise, gallows/chain mechanism, supports, approaches, source camera and other picture differences remain open. The engraving is retrospective; its bridge caption is not a dated 1835 construction record. The provisional camera reaches a principal-point bound and is not accepted. No original image verdict changes.'
new_value=value+'\n\n'+add
text=text[:start]+json.dumps(new_value,ensure_ascii=False)+text[start+n:]
after[paths[2]]=text.encode()
source=json.loads((AUDIT/'andreas_1884_dearborn_drawbridge_plate.corrected-proposal.json').read_text())
assert source['rights_status']=='public_domain'
source['note']=source['note'].replace('Proposed 1.2 m rise and parapet sections remain explicitly reconstructed.','Any proposed metric rise and parapet sections remain explicitly reconstructed; this board-only increment keeps the deck flat.')
after[paths[3]]=(json.dumps(source,ensure_ascii=False,indent=2)+'\n').encode()
pool=json.loads(before[paths[4]]);keys=pool['read']['structures'];new_key='phases[].form.railing_kind.note';assert new_key not in keys
last=keys[-1];needle=json.dumps(last)+'\n    ],';text=before[paths[4]].decode();assert text.count(needle)==1
after[paths[4]]=text.replace(needle,json.dumps(last)+',\n      '+json.dumps(new_key)+'\n    ],').encode()
lib=(OLD/'LIBERTY-entry.md').read_text().replace('**Covers:** `dearborn_street_drawbridge` form `railing_kind`.','**Covers:** `dearborn_street_drawbridge.draw_1834.form.railing_kind`.')
lib+='\n**Prepared-scope note:** This selective board-only proposal keeps the flat deck and original crib set-out. It includes no rise/profile/support controls or new runtime sampler. The original provisional 4.5.3 preview still differs; its principal point reaches a bound. Native six-family regeneration, current app/source comparisons and full policy gates remain owed. No utility admission, image acceptance or new scene date is implied.\n'
assert 'L-dearborn-board-parapet-2375' not in before[paths[5]].decode()
after[paths[5]]=before[paths[5]]+lib.encode()
(OUT/'LIBERTIES.fragment.md').write_text(lib)
(OUT/'research-note.fragment.txt').write_text(add+'\n')
for p in paths[:-1]:
 for prefix,data in [('before',before[p]),('candidate',after[p])]:
  dest=OUT/prefix/'chicago/4d'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
patch=''.join(''.join(difflib.unified_diff(before[p].decode().splitlines(True),after[p].decode().splitlines(True),fromfile='a/chicago/4d/'+p,tofile='b/chicago/4d/'+p,n=3)) for p in paths)
(OUT/'board-only.patch').write_text(patch)
guards=[{'path':'chicago/4d/'+p,'before_sha256':sha(before[p]),'after_sha256':sha(after[p]),'before_bytes':len(before[p]),'after_bytes':len(after[p])} for p in paths]
(OUT/'file-guards.json').write_text(json.dumps(guards,indent=2)+'\n')
# Snapshot only the small common-source dependency closure, not a renderer/worktree.
dependencies=[]
for p in ['generators/common/__init__.py','generators/common/mesh.py','generators/common/logwork.py','generators/common/materials.py','generators/archetypes/__init__.py']:
 data=git(p);dest=OUT/'common-runtime/chicago/4d'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 dependencies.append({'path':'chicago/4d/'+p,'sha256':sha(data),'bytes':len(data)})
# All six controls are the actual public record/phase inputs, never scene1835-only.
records=[]
names=['dearborn_street_drawbridge','lasalle_slough_crossing','north_branch_bridge','north_water_slough_crossing','slough_log_bridge','south_branch_raft_bridge']
for sid in names:
 p='data/structures/'+sid+'.json';data=git(p);record=json.loads(data)
 if sid!='dearborn_street_drawbridge':
  dest=OUT/'before/chicago/4d'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 for ph in record['phases']:records.append({'asset':sid+'__'+ph['id']+'.glb','structure_id':sid,'phase_id':ph['id'],'record_sha256':sha(data)})
assert len(records)==6
# Restrict builder additions to the boarded path; current source AST is the preimage.
ta=ast.parse(before[paths[0]]);tb=ast.parse(after[paths[0]])
def functions(t):return {n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
fa,fb=functions(ta),functions(tb);assert set(fb)-set(fa)=={'_board_parapet'}
assert all(fa[k]==fb[k] for k in fa if k!='_railing')
assert after[paths[0]]==(OLD/'preview/fixture/generators/archetypes/bridge_timber.py').read_bytes()
new_record=json.loads(after[paths[2]]);check=copy.deepcopy(new_record);check['phases'][0]['form'].pop('railing_kind');check['research_note']=old_record['research_note'];assert check==old_record
source_old=json.loads(before[paths[3]]);assert all(source[k]==source_old[k] for k in ['id','date','describes_date','url','tier','rights_status','rights_note','asset_use','verified'])
newpool=json.loads(after[paths[4]]);assert newpool['read']['structures'].pop()==new_key and newpool==pool
inputs={'public_base':BASE,'input_origin':'immutable git objects; canonical worktree unmodified','six_family':records,'code_guards':guards,'common_dependencies':dependencies,'legacy_builder_board_preview_exact':True,'target_record_only_new_form_railing_kind_and_research_note':True,'whole_source_date_rights_identity_unchanged':True,'only_one_name_reader_added':new_key,'source_correction_lineage':str(AUDIT),'liberties_full_public_prefix_preserved':True,'no_profile_support_runtime_changes':True}
(OUT/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
print('Prepared selective6path patch; common sources+six records only; no canonical writes')
