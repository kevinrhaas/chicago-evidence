# T2373 lighting runtime-only correction v2

The frozen120adb preparation is unchanged. Its first execution failed before any capture because the long run-local TMPDIR exceeded Chromium's Unix socket path limit; full negative is /workspace/T2373-8021-lighting-runs/20261024T152242-579481Z. All input guards passed.

This copied launcher keeps PACKAGE pointing at the original frozen inputs/manifest and changes only runtime temporary-directory plumbing: short owned /tmp/lh3-* for Chromium, copied into the run-local tmp directory after native children exit, then removed. Execution receipt binds the actual launcher SHA and short path. Both exact cameras, GLB/materials/photo/vendor/native CLI/commands and original output root remain unchanged. No extra lighting variation or capture is added; it retries the same still-unrun A/B after a zero-capture launch failure. No TLS/browser security bypass, source edit or canonical write.

Run only under the existing root A/B lane grant:
python3 /tmp/T2373-8021-lighting-runtime-v2/run-prepared-v2.py --run-after-root-grant

All failures remain separate timepoints. Actual A/B captures are still UNRUN at preparation closure.
