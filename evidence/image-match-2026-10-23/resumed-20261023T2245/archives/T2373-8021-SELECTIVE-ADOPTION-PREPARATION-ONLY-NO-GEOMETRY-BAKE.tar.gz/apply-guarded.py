#!/usr/bin/env python3
"""Read-only guard by default. Future application requires the root's chosen scope."""
from pathlib import Path
import argparse, hashlib, json
HERE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True)
ap.add_argument('--apply',action='store_true');args=ap.parse_args()
rows=json.loads((HERE/'file-guards.json').read_bytes());pending=[]
for row in rows:
    source=HERE/'candidate'/row['path'];target=args.root/row['path']
    proposed=source.read_bytes()
    if sha(proposed)!=row['after_sha256']:
        raise ValueError('prepared candidate changed: '+row['path'])
    current=target.read_bytes() if target.exists() else None
    if current is not None and sha(current)==row['after_sha256']:continue
    actual=sha(current) if current is not None else None
    if actual!=row['before_sha256']:
        raise ValueError('incoming preimage changed; selective recompose required: '+row['path'])
    pending.append((target,proposed))
if args.apply:
    for target,proposed in pending:
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(proposed)
print(json.dumps({'status':'APPLIED' if args.apply else 'READ_ONLY_GUARDS_PASS',
                  'paths_ready':len(pending),'optional_grade_ruling_included':False,
                  'native_assets_written':False}))
