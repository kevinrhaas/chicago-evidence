# T2373 visible prototype: selective adoption PREPARATION

**Prepared only; no claim, ticket, canonical source edit, raw25 mesh run, Blender, browser, adoption or accepted image.** Original T2373 remains OPEN and all seven source pictures remain DIFFERS/unresolved. This is a reviewable future M progress increment, not original-ticket completion. The held research GLB is evidence, never a hand-authored canonical asset.

## Exact recovered lineage

The original actual run is `/tmp/chicago-next-model/T-2373-irregular-stone-next/runs/20261023-142007-633821`. Its frozen producer SHA is `414945ba6ecf84c93faa38f07fc6378d041bea2098686cc4f72d3823fc015ff3`; params `8fe026aaed179a40d954618be6d542b885fdcadcd5ea27f5e4e15a8df9b27950`; record `3b4003aca0ff6ab99f8fffca12392eb0e89b28f77ba4f30c73f0b084ff391b83`. All154 relevant code/common/data/source/assets rows in its336-file ACTUAL-RECOVERY ledger were rehashed without a mismatch. Original `inputs.json` independently binds the three selected source files.

Recomputing the **original native** resolved-params-v4 recipe against those exact saved files gives `c111b959ccd6c1882b113c53ec81200a9eb1363046ddc3a2cac92f3dd80caa46`, exactly the actual manifest entry. `exact-prototype-inputs-document.json` records the resolved fields, derived properties, confidence floats, whole-producer/common/pipeline hashes and Blender4.5.3 pin. This was metadata resolution only, not geometry emission. The actual output is GLB `9d980cc3f8a954314785c0d8e206d965d4c439d2a5aa4cfc162587ee49166d8f`,882,276 B/8,021 triangles. Export and capture both exited0 historically; geometry/material-loader scope was checked, but it remained DIFFERS and unadopted.

The later actual direction-only overcast A/B used those same exact bytes and cameras; it improves left/front shaft shading, while the cap/cage/masonry/apertures/context/provisional camera still differ. It changes no geometry or canonical camera. That evidence is `/tmp/T2373-8021-lighting-actual-review`, manifest `adcd6e7c…`; first launch failure, runtime-only correction and actual two captures are preserved separately.

## Current base and what is deliberately retained

Base is public `308b738e6e6716a7a1411aa6c178e196eb17a719`, current fort producer `fc645a66b889e8ca837520e73d2bdee4806b0892e33591099714bff10178d64e`, params `81d6a7fbb345082d60272429f0cb92dee751d3c1cbe40624017f572d6e523a5d`.

The candidate is assembled selectively. Every current preexisting function/class except `build` and `_tower` is AST-exact, including the actual opening-aware gallery post spacing, five-face beam/canopy repair, double gallery/default gallery, facade opening helpers and current roof function. The whole original prototype module must **never** replace the current one: it contains unrelated unadopted cupola and Lake House roof-none semantics and an obsolete equal-spaced gallery. Those hazards are excluded here.

`build` adds only the optional lantern-cage alpha configuration after normal material/object creation. Its defaultNone branch retains old behavior. `_tower` and eleven new lighthouse-only helper definitions are AST-exact to the verified original prototype. Shared materials/opening kits, terrain, datum, world placement, renderer and existing first-fort data are untouched.

The new optional controls are all **keyword-only**: `lantern_profile='legacy'`, `tower_diameter_m=None`, derived `footprint_min_u_m=0`/`footprint_min_v_m=0`, `tower_openings=None`, `tower_profile=None`, `tower_lantern_detail=None`, `tower_masonry=None`. Existing16 positional arguments and the two existing keyword-only gallery/front controls remain. The six authored form keys enter CONSUMED; minima are derived exclusively from the actual polygon, not authored form fields. A nonzero-min polygon is accepted only for an explicitly dimensioned tower; mismatched diameter/unsupported offsets remain refused.

Pure metadata checks resolved all25 current legacy phases: all existing fields/confidence exactly equal; new controls default off. The proposed target's resolved values/confidence/shaft-height/opening layout exactly equal the original prototype projection, excluding its four unrelated unused cupola fields. No raw geometry25 proof or family bake was run here. `light-param-api-checks.json` and `selective-source-checks.json` give that bounded evidence.

## Seven concrete authored paths

| Path | Scope |
|---|---|
| `generators/archetypes/fort_structure.py` | Selected tower dispatch/helpers and cage-local alpha; retain all current other functions. |
| `generators/archetypes/fort_structure_params.py` | Eight new keyword-only fields, six consumed authored controls, guarded derived minima, validation/resolver/layout/property. No cupola fields. |
| `data/structures/chicago_lighthouse_1832.json` | Six selected form controls; narrowed physical footprint about unchanged centre; append explicit height/research uncertainty. Existing dates, position/origin/bearing/ownership and old prose are retained. |
| `data/sources/castelnau_1842_chicago_harbor.json` | Byte-exact credited/rights-qualified record from verified source trial. |
| `data/sources/assets/chicago_harbor_lighthouse_1838.jpg` | Byte-exact held public-domain reproduction, included on the generated Images card through actual source linkage. |
| `data/reconstruction/name_pool_keys.json` | Six exact new form-note reader paths; preserve incoming raw rows. |
| `docs/LIBERTIES.md` | Preserve current entire raw prefix and append one precise entry covering physical footprint and all six form controls. No historical-ID replacement. |

`candidate/` has full inspectable files, `before/` the exact base preimages. `selective-adoption.patch` covers the six text paths; it does not carry the JPEG. Use the guarded seven-path helper when/if root adopts, so the image is not forgotten. The helper is **read-only by default** and refuses any changed incoming file; it never copies an old manifest or GLB. Future incoming changes require selective recomposition, not a weakened guard.

```
python3 /tmp/T2373-8021-selective-adoption-prepared/apply-guarded.py --root /chosen/repository/chicago/4d
```

No `--apply` was used in this preparation. New visitor-facing notes describe actual current dimensions/architecture and uncertainty plainly; implementation identifiers remain structured fields or Covers/engineering notes. The original prototype record and recipe are retained separately as provenance, not silently rewritten history.

`proposed-grade-ruling.json` is an **optional separate appearance judgment**, intentionally not in the seven-path patch. It proposes a named reasonable-picture ruling because the actual Castelnau print shows the distinct entire visible tower despite its small far-right position and occluded toe. Root should review whether this meets the existing reasonable-picture rule; that internal review needs no new owner permission. Either outcome must retain reconstructed metric/material choices and inferred circa1838-to-July1835 continuity. A proposed appearance ruling is neither a solved camera nor a matches verdict. Do not copy this JSON wholesale over the latest grade register; append its one reviewed entry only if selected, then regenerate derived grades normally.

## Source limits, liberties and image obligations

All selected metric dimensions, scantlings, member counts, aperture orientation/section, material tones, irregular stone units, depths, seeded variation and hidden joints remain reconstructed; inferred bird-cage/profile continuity does not promote them. The unchanged nominal12.19 m is Andreas's rounded40ft literal. Its datum remains unknown; the selected reconstruction reaches12.84968 m. The three latest aperture widths are0.34/0.42/0.54 m, not older superseded values. No unproven ground door is added.

Castelnau:1842 public-domain publication, plate18 Chicago panel visibly4/prose Fig1 discrepancy retained; depicted circa1838 is later thanJuly1835. Paint/stone type, optic count, historical diameter, measured station and sun are not attested. The prototype's local transparent cage is0.18 alpha, while shared/shaft glass remains opaque; actual normal/Bygrade/GPU behavior must still be checked after native export. The old actual prototype has11 referenced material rows and8,021 triangles, compared with the generic132-triangle tower: +7,889 triangles is evidence for pricing, not a current app-budget pass. Do not silently collapse its palette or declare a new finish to fit budget; that would need a separate reviewed increment.

The public Braunhold/Andreas bridge plate clearly contains a lighthouse and its older contrary source prose needs a separate correction before reuse. Baker & Co original publication/reproduction credit remains check_required; the Peck auction reproduction needs its own credit review. The school shore view has only project-specific owner-approved attributed use, no new PD claim, and its identity/date/perspective cannot establish a metric camera. Flood1849 tower remains unlocated. No geometry or new asset is derived from those uncleared/unlocated sources. Their unresolved views remain part of the original ticket. The collapsed1831 tower's50ft/3ft wall statements never supply1832 dimensions.

All camera/lighting research remains outside canonical `data/reference_views`; no station is solved and no original image gate is bypassed. Future documented phases/versions require a shared refusal-on-ambiguity selector in both renderer and gate, not the present first-manifest-entry lookup or a research `--glb` override. No new dated phase is invented from a publication date.

## Lake House S boundary: re-audited, excluded

`roof-none-callgraph-audit.json` enumerates all six current explicit-none phases: Lake House, both parades, both flagstaffs and lighthouse. Only **Lake House (kind magazine)** dispatches through `_building` to `_roof`. Both old/new lighthouse helper closure paths avoid `_roof`; neither new lantern/profile/stone path calls it. Current `_roof` still groups flat/none exactly; this patch does not change that semantic behavior.

Therefore the earlier six-none/one-consumer observation remains true after this selective M composition. A Lake House S repair can be reviewed/grouped later, preserving flat behavior and both forts/lighthouse defaults, but is not hidden in this patch. The separate second-fort trial must also complete its own actual image review before any grouping. Combining utilities would require a new combined-source snapshot, corresponding raw parity/selected-target proof and one honest native family refresh, not copying assets from separate prototype fixtures.

## Readiness and validation still owed

The exact producer/record/source/recipe bindings are recoverable and the selective patch/data provenance are concrete. The next owner should first review the authored scope/optional grade judgment and policy utility/claim; none was filed here. Then, when root allocates CPU, perform meaningful raw/default controls against the **current**25-phase family and the opted-in lighthouse versus the frozen prototype. AST/parameter equality is not raw mesh or exported-byte parity. Preserve the actual first-fort gallery/beam/source data and Hogan/unrelated assets.

Changing this shared producer/dataclass stales the complete fort family. Re-enumerate before the official bake; run all distinct phases across scenes, not1835-only. Genuine pinned native25masters plus supported web derivatives/manifest writers are owed; no hand-edited recipe hashes or copied research GLB. Other24 must retain physical/material/confidence behavior; investigate UV/byte differences through actual native receipts. The selected lighthouse will have a new current-source recipe hash even if its visible raw stream matches the old prototype, because unrelated current fort fixes are legitimately retained.

Run ordered native derivation with source/picture/grade/name readers and sidecars; guard existing person/card/ledger identities and Hogan assets rather than accepting churn from new provenance words. Check actual floor/terrain/river/door/body placement, normals/alpha/material primitives, native app desktop/mobile normal and Bygrade plus the credited Images tab, original source comparisons and current capacity at real cameras. Required focused checks, full preflight/native CI, changelog/STATUS/ROADMAP and policy PR/dev integration belong to the actual utility. No renderer budget or image-match acceptance is inferred from this preparation.

`MANIFEST.json` closes this packet; all future correction/adoption work uses a new version. The old frozen actual producer snapshots under `provenance/` are labelled historical only and never apply over the current fort module.
