"""Run only after the actual composed source gate: dated-body bindings, fresh
source/picture audit and independently closed official phone reuse. No browser, meter or remote writes.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,shutil,subprocess,time
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path(__file__).parent;G=None;Q=Path('/workspace/PR1456-current87-inactive1835-consumer-audit-root-20261029');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();steps=[]
def g(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def frozen(binding):
 assert g('rev-parse','HEAD').decode().strip()==args.checked_head
 assert g('rev-parse','HEAD^{tree}').decode().strip()==binding['checked_final_staged_tree']
 assert not(R/'.git/MERGE_HEAD').exists()and not g('status','--porcelain=v1')
 assert not g('diff','--cached','--name-only')and not g('diff','--name-only')
 assert all(sha((R/p).read_bytes())==digest for p,digest in binding['all_staged_paths'].items())

args=argparse.ArgumentParser();args.add_argument('--oracle-caller-proof',required=True);args.add_argument('--expect-merge-parent',required=True);args.add_argument('--checked-head',required=True);args.add_argument('--expect-source-parent',required=True);args.add_argument('--full-gate-result',required=True);args.add_argument('--native-checkpoint-receipt',required=True);args.add_argument('--checkpoint-status',required=True);args.add_argument('--accept-consumer-proof-sha256',required=True);args.add_argument('--people-both-result',required=True);args.add_argument('--official-phone-receipt',required=True);args.add_argument('--audit-and-reuse-phone',action='store_true');args=args.parse_args()
assert args.audit_and_reuse_phone, 'Explicit audit-only reuse required; this helper launches no browser or meter'
assert all(re.fullmatch('[0-9a-f]{40}',v)for v in [args.checked_head,args.expect_source_parent,args.expect_merge_parent])
assert re.fullmatch('[0-9a-f]{64}',args.accept_consumer_proof_sha256)
gate_path=Path(args.full_gate_result).resolve();assert gate_path.name=='RESULT.json';G=gate_path.parent
new_proof_raw=(O/'NEW-CONSUMER-STATIC-PROOF.json').read_bytes();current_consumer_proof=json.loads(new_proof_raw)
assert sha(new_proof_raw)==args.accept_consumer_proof_sha256
assert current_consumer_proof['status']=='ACTUAL_READONLY_35EF_298_OF305_FIVE_RETAINED_AND_TWO_CHANGED_APP_SORT_BINDINGS'
assert current_consumer_proof['source_parent']==args.expect_source_parent and current_consumer_proof['incoming_merge_parent']==args.expect_merge_parent
prior_1af=current_consumer_proof['prior_1af_static_proof'];prior_1af_raw=Path(prior_1af['path']).read_bytes();assert sha(prior_1af_raw)==prior_1af['sha256'];new_proof=json.loads(prior_1af_raw);assert new_proof['status']=='ACTUAL_READONLY_1AF_INACTIVE_FRONTYARDS_AND_ADDITIVE_STANDARD_BALL_STATIC_PROOF'
# Audit-only: actual short-TMP phone has its own independently closed root receipt.
assert re.fullmatch('[0-9a-f]{40}',args.expect_merge_parent);oracle_raw=Path(args.oracle_caller_proof).read_bytes();oracle=json.loads(oracle_raw);assert oracle['status']=='ACTUAL_ROOT_ACCEPTED_34DD_GPU_ORACLE_DATED_BODY_EXCEPTION' and oracle['root_reviewed']is True and oracle['after_sha256']=='d5a44866af03c70eff7ab2d193daf55d23dfbc8a64b4ce2f585ad9c97a3acb86'
gate=json.loads((G/'RESULT.json').read_bytes());assert gate['status']=='ACTUAL_FINAL_FOUR_CHECK_PASS_SOURCE_UNCHANGED'and gate['exit']==0 and all(gate['guards'].values())and gate['config_unchanged'];b=gate['binding'];frozen(b);assert b['head']==args.expect_source_parent and b['merge_parent']==args.expect_merge_parent
checkpoint_raw=Path(args.native_checkpoint_receipt).read_bytes();checkpoint=json.loads(checkpoint_raw);assert checkpoint['status']==args.checkpoint_status and args.checkpoint_status.startswith('ACTUAL_CHECKED_')and checkpoint['head']==args.checked_head and checkpoint['tree']==b['checked_final_staged_tree']and checkpoint['parents']==[b['head'],b['merge_parent']]and checkpoint['source_gate_exact_tree']is True;assert checkpoint['full_source_gate']==str(G/'RESULT.json');assert g('show','-s','--format=%P',args.checked_head).decode().strip().split()==checkpoint['parents']
people_raw=Path(args.people_both_result).read_bytes();people=json.loads(people_raw);assert people['status']=='ACTUAL_CHECKED35_FRESH_ORIGINAL_FOUR_PEOPLE_BOTH_8_CAPTURES_PASS'and people['head']==args.checked_head and people['tree']==b['checked_final_staged_tree']and people['captures']==8 and people['all_children_reaped']is True and people['errors']==[]and people['network_errors']==[];assert people['source_and_published_guards_passed']is True
people_root_review_path=Path(args.people_both_result).parent/'ROOT-REVIEW.json';people_root_review_raw=people_root_review_path.read_bytes();people_root_review=json.loads(people_root_review_raw);assert people_root_review['status']=='ROOT_DIRECTLY_VIEWED_ALL8_FRESH_CURRENT_PEOPLE_CAPTURES_QUALIFIED_ACCEPTANCE'and people_root_review['head']==args.checked_head and people_root_review['tree']==b['checked_final_staged_tree']and len(people_root_review['frames'])==8 and all(f['directly_viewed']is True and sha(Path(f['path']).read_bytes())==f['sha256']for f in people_root_review['frames'])
assert sha((R/'.git/config').read_bytes())==b['primary_config_sha256'];config=b['primary_config_sha256'];reaper=json.loads((G/'REAPER.json').read_bytes());assert reaper['command_exit']==0 and reaper['all_children_reaped'];assert 'bash tools/publish.sh'in(G/'TIMINGS.tsv').read_text()and'published ../../site/4d'in(G/'check.log').read_text()
save('NATIVE-PUBLISH-REUSE.json',{'status':'ACTUAL_SAME_FROZEN_FULL_GATE_NATIVE_PUBLISH_REUSED','tree':b['checked_final_staged_tree'],'full_gate':str(G/'RESULT.json'),'full_gate_sha256':sha((G/'RESULT.json').read_bytes()),'native_publish_timings_sha256':sha((G/'TIMINGS.tsv').read_bytes()),'no_redundant_publish':True})
# Existing three exceptions plus the separately reviewed exact oracle caller proof.
old_receipt=json.loads((Q/'RESULT.json').read_bytes());oldraw=(Q/'305-CONSUMER-BINDINGS.json').read_bytes();assert sha(oldraw)==old_receipt['bindings_sha256'];old=json.loads(oldraw);assert len(old)==305
exceptions={'street-trees.js':'ef5c73955a6115626351f540aba6748c412bba66ea021b2ef5ad44019cc15cc6','railway.js':'a9e80f7f262c6f1ae0254c102a333fda42981f5fd2e119698280408f6f99cef0','tree-model.js':'522877e0a64c80d6e7ab18596a67557f4ee118485ff8babd2956aa18eaaeb131','front-yards.js':'9f8814401b861dbe96c798e019cfdc11f0b11be8428571b19f026719340203a8','gpu-pick.js':'d5a44866af03c70eff7ab2d193daf55d23dfbc8a64b4ce2f585ad9c97a3acb86','inspect-view.js':'76f9247cdc9e007065ad3eb5b09184326f80a92faabca58bf8ae1a321cbc8eec','people-view.js':'c9a1cc2f09b6abc0638f2da1d58a2d7d79f32722380be5d2d252042b63638411'}
rows=[]
for row in old:
 p=Path(row['path']);current=p.read_bytes();digest=sha(current);exact=digest==row['expected_sha256'];record={'path':str(p),'old_expected_sha256':row['expected_sha256'],'current_sha256':digest,'bytes':len(current),'exact':exact}
 if not exact:assert p.name in exceptions and digest==exceptions[p.name],str(p)
 rows.append(record)
assert sum(r['exact']for r in rows)==298 and len([r for r in rows if not r['exact']])==7
for name,digest in exceptions.items():
 rel=('apps/'+name)if name in ['inspect-view.js','people-view.js']else name
 assert sha((A/'renderers/web/js'/rel).read_bytes())==digest and sha((R/'site/4d/walk/js'/rel).read_bytes())==digest
route=old_receipt['actual1835_inactive_route'];assert all(sha(Path(p).read_bytes())==route['scene_sha256']for p in [route['native_scene'],route['published_scene']]);scene=json.loads(Path(route['native_scene']).read_bytes());assert 'railway'not in scene['layers']and'street_trees'not in scene['layers']and'front_yards'not in scene['layers'];assert all(sha((R/p).read_bytes())==route['unchanged_main_layer_dispatch_sha256']for p in ['chicago/4d/renderers/web/js/main.js','site/4d/walk/js/main.js'])
rail=(A/'renderers/web/js/railway.js').read_text();assert 'if (!dataBase || !terrain) return out;'in rail
before=g('show','dd1dfd88808ee36187825706cb71a5ad70bdd262:chicago/4d/renderers/web/js/tree-model.js');after=(A/'renderers/web/js/tree-model.js').read_bytes();needle=b'[0.198, 0.838, 0.002, 1.000]'
source_parent_tree=g('show',new_proof['source_parent']+':chicago/4d/renderers/web/js/tree-model.js')
assert before.count(needle)==1 and before.replace(needle,b'[0.198, 0.830, 0.002, 1.000]')==source_parent_tree
start=after.index(b'  // T-1934: an evergreen sheared to a ball on one clear stem');end=after.index(b'  pelargonium_bed: {',start)
assert len(after[start:end])==new_proof['tree_model']['additive_block_bytes'] and sha(after[start:end])==new_proof['tree_model']['additive_block_sha256']
assert after[:start]+after[end:]==source_parent_tree
assert sha(source_parent_tree)==new_proof['tree_model']['base_sha256'] and sha(after)==new_proof['tree_model']['source_sha256']
front=(A/'renderers/web/js/front-yards.js').read_bytes();prior_front=g('show',new_proof['source_parent']+':chicago/4d/renderers/web/js/front-yards.js')
def yard_stub(data):
 start=data.index(b'export async function createFrontYards({');end=data.index(b'  if (!dataBase || !terrain) return out;')+len(b'  if (!dataBase || !terrain) return out;');return data[start:end]
assert yard_stub(front)==yard_stub(prior_front) and sha(yard_stub(front))==new_proof['front_yards']['stub_sha256']
assert sha(prior_front)==new_proof['front_yards']['base_sha256'] and sha(front)==new_proof['front_yards']['source_sha256']
assert b"const layerBase = (layer) => (draws(layer) ? bases.dataBase : null);"in(A/'renderers/web/js/main.js').read_bytes()
assert not any(b'standard_ball'in p.read_bytes()for p in (A/'data/flora').rglob('*.json'))

textures={}
for ext in ['webp','ktx2']:
 source=A/('assets/textures/trees/leaf_atlas.'+ext);published=R/('site/4d/data/textures/trees/leaf_atlas.'+ext);assert source.read_bytes()==published.read_bytes();textures[ext]={'bytes':source.stat().st_size,'sha256':sha(source.read_bytes()),'source_published_exact':True}
subjects={'miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832'}
def selected(doc):return {x['id']:x for x in doc['liberties']if subjects.intersection(x.get('subjects',[]))or any(c.get('structure')in subjects for c in x.get('covers',[]))}
native=json.loads((A/'data/liberties.json').read_bytes());pub=json.loads((R/'site/4d/data/liberties.json').read_bytes());prior=json.loads(g('show','dd1dfd88808ee36187825706cb71a5ad70bdd262:chicago/4d/data/liberties.json'));assert native==pub and selected(native)==selected(prior)and len(selected(native))==29
save('BODY-CONSUMER-REUSE.json',{'status':'ACTUAL298_OF305_EXACT_FIVE_RETAINED_EXCEPTIONS_TWO_APP_CHANGES_FRESH_PEOPLE_ALL29_LIBERTIES_EXACT','at':now(),'tree':b['checked_final_staged_tree'],'rows':rows,'exceptions':{'street-trees.js':'Existing root-reviewed changed treeCard metadata branch is inactive1835; street_trees absent/null layer dispatch.','railway.js':'1904far-ground allocation plus reviewed3line ground normal packing plus1line railprofile normal packing andexactuniformgroundconfidence; railway absent/null1835dispatch returns before geometry/fetch.','tree-model.js':'ACTIVE1835 timber. Original exact elm crop .838->.830/credited atlas exception retained. The previously accepted1af addition is only590byteARCH.standard_ball; all other4b22bytes exact, no current nativefloraJSON uses new key; new1904 yard selector is inactive1835. No dated full-environment equality claimed.','front-yards.js':'New precisely reviewed inactive1835 exception: scene layer absent and unchanged main dispatch passes null; function signature/stats/no-op object/earlyreturn exact to4b22, before fetch/plant/tub/geometry/pick work. LoadedJSbytes/constants counted by currentphone.','gpu-pick.js':'Root-reviewed corrected raycast oracle/no-renderer near-plane clamp. Renderer-backed GPU picks and directID dated-harness selection unchanged; no geometry/frame/card/ground/placement change. No new GPU-oracle probe claimed here; fresh People checks are separate.'},'two_new_app_changes':{'apps/inspect-view.js':exceptions['inspect-view.js'],'apps/people-view.js':exceptions['people-view.js'],'fresh_current1835_People_receipt':args.people_both_result,'fresh_People_receipt_sha256':sha(people_raw),'1904_staff_directory_BOTH_not_claimed':True},'oracle_caller_proof':{'path':args.oracle_caller_proof,'sha256':sha(oracle_raw)},'root_accepted_current_consumer_proof':{'path':str(O/'NEW-CONSUMER-STATIC-PROOF.json'),'sha256':sha(new_proof_raw),'explicit_caller_acceptance':True},'native_published_leaf_atlas_bindings':textures,'all29_four_building_liberty_rows_fields_exact':True,'current_native_and_published_full_liberty_count':len(native['liberties']),'limits':'Dated four-building BODY/app reuse, not305-file equality, nottree-modelinactive, no freshwholeBODY/BOTH/fullenvironment validation; only the separately executed current1835People BOTH is fresh. Current complete1904nativephone still separately required.'})
# Rebind exact selected Images records/STORE delivery fields; no full catalog equality claim.
L=R/'chicago/prairie_1904_v1';librel='chicago/prairie_1904_v1/data/images.json';storerel='chicago/prairie_1904_v1/research/images/STORE.json';library=json.loads((R/librel).read_bytes());library_base=json.loads(g('show',args.expect_source_parent+':'+librel));store=json.loads((R/storerel).read_bytes());store_base=json.loads(g('show',args.expect_source_parent+':'+storerel));ids={'early-blanchard-shober-1867-wolf-point','early-cameron-first-post-office-1833','early-moss-1884-st-marys','early-castelnau-1842-chicago-harbor'};old_rows={r['id']:r for r in library_base['images']};new_rows={r['id']:r for r in library['images']};image_rows=[]
for pid in sorted(ids):
 assert new_rows[pid]==old_rows[pid];row=new_rows[pid];files=[Path(row['local'][key]).name for key in ['display','thumb']];assert all(store['files'][f]==store_base['files'][f]for f in files);assert all(store[k]==store_base[k]for k in ['base_url','prefix','repository']);image_rows.append({'id':pid,'all_library_record_fields_exact_to430':True,'STORE_delivery_rows_exact_to430':{f:store['files'][f]for f in files},'credit_rights_creator_repository_and_links_exact':True})
import parent_pictures
parent_picture_proof=parent_pictures.prove(R,args.expect_source_parent,subjects);save('ACTUAL-PARENT430-NATIVE-PICTURE-PROJECTION.json',parent_picture_proof)
save('FOUR-TARGET-IMAGES-REUSE.json',{'status':'ACTUAL_FOUR_TARGET_LIBRARY_STORE_EXACT430_PICTURES_FROM_PURE_NATIVE_PARENT_PROJECTION','rows':image_rows,'whole_global_library_catalog_equality_not_claimed':True,'new_browser_full_image_open_not_claimed':True,'dated_actual_credit_full_image_delivery_proofs_retained':True})
# New foreign tour records may extend the catalog; keep each original target's
# actual lookup metadata, source descriptions, names and claim edges exact.
index_rel='chicago/4d/data/sidecars/1835/sources/index.json'
base_index=json.loads(g('show','2b01c06042660e811bdff90619b0ea2edf953fd9:'+index_rel))
current_index=json.loads((R/index_rel).read_bytes())
assert current_index==json.loads((R/'site/4d/data/sidecars/1835/sources/index.json').read_bytes())
base_sources={r['source_id']:r for r in base_index['sources']};current_sources={r['source_id']:r for r in current_index['sources']};target_sources={}
def source_ids(value,out):
 if isinstance(value,dict):
  for key,item in value.items():
   if key in ['sources','source_ids']and isinstance(item,list):out.update(x for x in item if isinstance(x,str)and x in current_sources)
   if key in ['source_id','source']and isinstance(item,str)and item in current_sources:out.add(item)
   source_ids(item,out)
 elif isinstance(value,list):
  for item in value:source_ids(item,out)
for sid in sorted(subjects):
 rel='chicago/4d/data/sidecars/1835/'+sid+'.json';old_side=json.loads(g('show','2b01c06042660e811bdff90619b0ea2edf953fd9:'+rel));current_side=json.loads((R/rel).read_bytes());old_ids=set();new_ids=set();source_ids(old_side,old_ids);source_ids(current_side,new_ids);assert old_ids==new_ids and old_ids;target_sources[sid]=sorted(old_ids)
lookup_rows=[]
for source_id in sorted(set().union(*(set(v)for v in target_sources.values()))):
 assert source_id in current_sources
 old_meta={k:v for k,v in base_sources[source_id].items()if k!='counts'};new_meta={k:v for k,v in current_sources[source_id].items()if k!='counts'};assert old_meta==new_meta
 rel='chicago/4d/data/sidecars/1835/sources/'+source_id+'.json';old_detail=json.loads(g('show','2b01c06042660e811bdff90619b0ea2edf953fd9:'+rel));new_detail=json.loads((R/rel).read_bytes());assert new_detail==json.loads((R/'site/4d/data/sidecars/1835/sources'/(source_id+'.json')).read_bytes());assert old_detail['source']==new_detail['source'];selected_edges=lambda d:[e for e in d['edges']if e.get('entity_id')in subjects];assert selected_edges(old_detail)==selected_edges(new_detail);assert {k:v for k,v in old_detail['names'].items()if k in subjects}=={k:v for k,v in new_detail['names'].items()if k in subjects}
 lookup_rows.append({'source_id':source_id,'lookup_metadata_except_global_counts_exact':True,'source_description_exact':True,'target_claim_edges_exact':len(selected_edges(new_detail)),'target_names_exact':True,'native_published_detail_exact':True,'foreign_aggregate_count_change_allowed':base_sources[source_id].get('counts')!=current_sources[source_id].get('counts')})
expected_new={'chicago_park_district_buckingham_fountain','encyclopedia_chicago_fernando_jones_scrapbook','encyclopedia_chicago_worlds_of_prairie_avenue','jwa_encyclopedia_hannah_greenebaum_solomon','nlm_visible_proofs_frances_glessner_lee','nprillinois_2019_illinois_led_suffrage','glessner_house_blog_mattie_williamson_2020','wikipedia_arthur_meeker','wikipedia_frances_glessner_lee','wikipedia_frank_orren_lowden','wikipedia_marshall_field_iii','wikipedia_norman_b_ream','wikipedia_william_wallace_kimball','britannica_eliza_chappell_porter','encyclopedia_chicago_wilmette','lake_forest_archives_eleanor_kinzie_gordon','nwhm_juliette_gordon_low','encyclopedia_chicago_african_americans','census_1900_chicago_t623_roll245'};assert expected_new<=set(current_sources);assert set(current_sources)-set(base_sources)==expected_new

new_jaunt_sources={'britannica_eliza_chappell_porter','encyclopedia_chicago_wilmette','lake_forest_archives_eleanor_kinzie_gordon','nwhm_juliette_gordon_low'}
new_inventory_sources={'encyclopedia_chicago_african_americans'}
new_source_rows=[]
for source_id in sorted(new_jaunt_sources|new_inventory_sources):
 raw=(A/'data/sources'/(source_id+'.json')).read_bytes();doc=json.loads(raw)
 assert doc['id']==source_id and doc['type']=='website' and doc['rights_status']=='check_required' and doc['asset_use']=='text_only' and doc['verified']is True
 assert all(doc.get(k)for k in ['citation','author','url','rights_note','what_it_supplies','what_it_does_not_supply'])
 detail=json.loads((A/'data/sidecars/1835/sources'/(source_id+'.json')).read_bytes())
 assert detail==json.loads((R/'site/4d/data/sidecars/1835/sources'/(source_id+'.json')).read_bytes())
 for key in ['citation','url','tier','what_it_supplies','what_it_does_not_supply']:assert detail['source'][key]==doc[key]
 assert detail['source']['source_id']==source_id
 if source_id in new_jaunt_sources:
  assert detail['edges'] and all(e['entity_id']=='notable-women-1835' and e['entity_type']=='jaunt'for e in detail['edges'])
 else:assert not detail['edges'] and not detail['names']
 new_source_rows.append({'source_id':source_id,'source_sha256':sha(raw),'native_published_detail_exact':True,'text_only_rights_and_credit_preserved':True,'scene_claim_edge_count':len(detail['edges']),'inventory_only_no_invented1835_Black_house':source_id in new_inventory_sources})
census_id='census_1900_chicago_t623_roll245';census_raw=(A/'data/sources'/(census_id+'.json')).read_bytes();census=json.loads(census_raw);assert census['id']==census_id and census['type']=='manuscript'and census['rights_status']=='public_domain'and census['asset_use']=='text_only'and census['verified']is True and census['date']=='1900'and census['describes_date']=='1900-06-01'
assert all(census.get(k)for k in ['citation','author','repository','url','rights_note','locator','what_it_supplies','what_it_does_not_supply']);assert census['url']=='https://archive.org/details/12thcensusofpopu245unit'
census_detail=json.loads((A/'data/sidecars/1835/sources'/(census_id+'.json')).read_bytes());assert census_detail==json.loads((R/'site/4d/data/sidecars/1835/sources'/(census_id+'.json')).read_bytes())and not census_detail['edges']and not census_detail['names']
for key in ['url','tier','what_it_supplies','what_it_does_not_supply']:assert census_detail['source'][key]==census[key]
import sys
sys.path.insert(0,str(A/'tools'));import readable_text as RT
projected_citation=RT.rewrite(census['citation'],RT.Names(A))[0];assert census_detail['source']['citation']==projected_citation
incoming_census=json.loads(g('show',args.expect_merge_parent+':chicago/4d/data/sources/'+census_id+'.json'));incoming_detail=json.loads(g('show',args.expect_merge_parent+':chicago/4d/data/sidecars/1835/sources/'+census_id+'.json'));assert census==incoming_census and census_detail['source']==incoming_detail['source']
save('CENSUS-INHERITED-PUBLIC-CITATION-DISCLOSURE.json',{'status':'INHERITED_ARCHIVAL_IDENTIFIER_SANITIZATION_DISCREPANCY_EXPLICIT_NOT_AUTHORED_CITATION_EQUALITY','source_id':census_id,'incoming':args.expect_merge_parent,'authored_citation':census['citation'],'authored_citation_sha256':sha(census['citation'].encode()),'native_public_citation':projected_citation,'native_public_citation_sha256':sha(projected_citation.encode()),'unchanged_native_readable_text_projection_exact':True,'authored_raw_and_native_public_fields_exact_to_incoming35':True,'authored_citation_equals_public':census['citation']==projected_citation,'limitation':'Archival T623 is rendered as other work by inherited native ticket sanitization. Root explicitly retained existing data/projector; not a clean-credit claim for Census, no change to four original target credits/claim joins, no new1835 image or occupancy claim.'})
new_source_rows.append({'source_id':census_id,'source_sha256':sha(census_raw),'native_published_detail_exact':True,'type':'manuscript','public_domain_text_only_not_new_image_use':True,'authored_repository_locator_scene_date_limits_preserved':True,'public_citation_limitation':str(O/'CENSUS-INHERITED-PUBLIC-CITATION-DISCLOSURE.json'),'scene1835_claim_edge_count':0})
assert (A/'data/sidecars/1835/jaunts/notable-women-1835.json').read_bytes()==(R/'site/4d/data/sidecars/1835/jaunts/notable-women-1835.json').read_bytes()
save('NEW-FOREIGN-SOURCE-DETAILS.json',{'status':'ACTUAL_FIVE_RETAINED_WEBSITE_AND_CENSUS1900_MANUSCRIPT_SOURCE_DETAILS_EXACT','rows':new_source_rows,'new_picture_or_image_rights_promotions':False})
save('SOURCE-INDEX-TARGET-LOOKUPS.json',{'status':'ACTUAL_FOUR_TARGET_SOURCE_LOOKUPS_AND_CLAIM_EDGES_EXACT_WITH_NINETEEN_NEW_FOREIGN_RECORDS','tree':b['checked_final_staged_tree'],'target_source_ids':target_sources,'lookups':lookup_rows,'base_catalog_count':len(base_sources),'current_catalog_count':len(current_sources),'new_foreign_ids':sorted(expected_new),'native_published_catalog_exact':True,'whole_catalog_equality_to_old_base_not_claimed':True})
frozen(b)
image_step=next(r for r in checkpoint['PR_questions_and_original_four_image_gates']if r['name']=='image-gates');assert image_step['exit']==0 and image_step['all_children_reaped']is True and image_step['command']==['node','tools/image_gate.mjs','--structure','miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832'];frozen(b)
ceilings=(A/'tools/memory_ceilings.json').read_bytes();assert ceilings==g('show',args.expect_source_parent+':chicago/4d/tools/memory_ceilings.json') and json.loads(ceilings)['ceilings']['1904']['mobile']['total_bytes']==400*1048576
import phone_reuse
phone_reused=phone_reuse.verify(R,args.official_phone_receipt,G/'RESULT.json',Path(args.native_checkpoint_receipt),args.checked_head,b['checked_final_staged_tree']);save('REUSED-OFFICIAL-PHONE-PROOF.json',phone_reused);peak=phone_reused['actual_complete_1904_mobile_peak_MiB'];frozen(b)
# The source-checked ordinary native commit was already checkpointed so its
# GitHub CI can run concurrently with this unchanged same-head phone proof.
head=args.checked_head;tree=b['checked_final_staged_tree'];parents=checkpoint['parents'];frozen(b)
assert sha((R/'.git/config').read_bytes())==config
save('RESULT.json',{'status':'ACTUAL_CHECKED35EF_COMPLETED_SOURCE_PICTURE_AUDIT_INDEPENDENT_OFFICIAL_PHONE_AND_FRESH_PEOPLE_REUSE_PASS','at':now(),'head':head,'tree':tree,'parents':parents,'full_gate':str(G/'RESULT.json'),'full_gate_exact_tree':True,'native_checkpoint_receipt':args.native_checkpoint_receipt,'native_checkpoint_receipt_sha256':sha(checkpoint_raw),'native_publish_reused_from_actual_fullgate':True,'body_consumer_reuse':str(O/'BODY-CONSUMER-REUSE.json'),'source_index_target_lookups':str(O/'SOURCE-INDEX-TARGET-LOOKUPS.json'),'four_target_Images_reuse':str(O/'FOUR-TARGET-IMAGES-REUSE.json'),'new_foreign_source_details':str(O/'NEW-FOREIGN-SOURCE-DETAILS.json'),'inherited_Census_public_citation_discrepancy':str(O/'CENSUS-INHERITED-PUBLIC-CITATION-DISCLOSURE.json'),'root_accepted_current_consumer_proof_sha256':sha(new_proof_raw),'selected305_consumer_exact_count':298,'selected305_precise_exception_count':7,'fresh_current_People_BOTH_receipt':args.people_both_result,'fresh_current_People_BOTH_receipt_sha256':sha(people_raw),'actual_independent_phone_receipt':args.official_phone_receipt,'actual_independent_phone_reuse_proof':str(O/'REUSED-OFFICIAL-PHONE-PROOF.json'),'People_root_direct_review':{'path':str(people_root_review_path),'sha256':sha(people_root_review_raw),'limits':people_root_review['limits']},'actual_complete_1904_mobile_peak_MiB':peak,'phone_unchanged_limit_MiB':400,'all_children_reaped':phone_reused['actual_native_reaper_all_children_reaped'],'original_image_gates_reused_from_native_checkpoint':image_step,'new_browser_or_meter_runs':0,'source_clean_same_native_head_tree':True,'no_source_Git_or_remote_mutations_in_this_runtime_phase':True,'visual_disclosure':'Earlier external normal-precision visual rawexit1 retained: AIR/NORTHtrianglecapsfailed both baseline andcandidate. No assertionweakened; notanall-budgetPASS.','required_current_GitHub_CI_and_normal_dev_merge_pending':True});print((O/'RESULT.json').read_text(),flush=True)
