"""Read and verify the one actual independently closed official native phone; launch nothing."""
from pathlib import Path
import hashlib,json,os,subprocess
sha=lambda b:hashlib.sha256(b).hexdigest()
EXPECTED_RECEIPT=Path('/workspace/PR1456-current35-final-phone-native-v2-root-20261030/RESULT.json')
def verify(repo,receipt,gate_path,checkpoint_path,head,tree):
 receipt=Path(receipt).resolve();assert receipt==EXPECTED_RECEIPT and receipt.is_file(),'Actual root V2 phone is not closed yet; do not infer/relaunch'
 folder=receipt.parent;rr=receipt.read_bytes();result=json.loads(rr);br=(folder/'BINDING.json').read_bytes();binding=json.loads(br);mr=(folder/'PHONE.json').read_bytes();measured=json.loads(mr);rp=(folder/'REAPER.json').read_bytes();reaper=json.loads(rp);gate_raw=Path(gate_path).read_bytes();gate=json.loads(gate_raw);checkpoint_raw=Path(checkpoint_path).read_bytes();checkpoint=json.loads(checkpoint_raw);b=gate['binding']
 assert result['status']=='ACTUAL_SAME_CHECKED_9D97_COMPLETE_NATIVE_PHONE_PASS'and result['exit']==0 and result['all_children_reaped']is True and result['errors']==[]
 assert result['head']==binding['head']==checkpoint['head']==head=='9d97c8191a074a50f94576195614a16f55345a9f'and result['tree']==binding['tree']==checkpoint['tree']==tree=='e1ca935205e351e7c03e68c3350e13b54b5077ad'
 assert result['parents']==binding['parents']==checkpoint['parents']==['430557a76ad9c8fc70f0fbfb353765bfe8c83857','35efd89976913d8739245c98367a2b2166fd17e9']
 command=['node','tools/measure_memory.mjs','--year','1904','--only','mobile','--gate','--no-snapshot','--json',str(folder/'PHONE.json')];assert result['command']==binding['command']==command and reaper['command']==['taskset','-c','0,1,3,4',*command]
 assert reaper['command_exit']==0 and reaper['all_children_reaped']is True and result['reaper']==str(folder/'REAPER.json')
 assert result['measurement_json']==str(folder/'PHONE.json')and result['measurement_sha256']==sha(mr)
 assert gate['status']=='ACTUAL_FINAL_FOUR_CHECK_PASS_SOURCE_UNCHANGED'and gate['exit']==0 and all(gate['guards'].values())and gate['config_unchanged']and checkpoint['source_gate_exact_tree']is True
 assert binding['gate']==str(Path(gate_path))and binding['gate_sha256']==sha(gate_raw)and binding['checkpoint']==str(Path(checkpoint_path))and binding['checkpoint_sha256']==sha(checkpoint_raw)
 assert len(binding['all137_checked_source_path_sha256'])==137 and binding['all137_checked_source_path_sha256']==b['all_staged_paths']
 assert result['source_HEAD_tree_index_config_all137_checked_paths_and_critical_published_bytes_before_after_exact']is True
 E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');g=lambda *a:subprocess.check_output(['git','-C',str(repo),*a],env=E)
 assert g('rev-parse','HEAD').decode().strip()==head and g('rev-parse','HEAD^{tree}').decode().strip()==tree and not(repo/'.git/MERGE_HEAD').exists()and not g('status','--porcelain=v1')
 assert sha((repo/'.git/index').read_bytes())==binding['source_index_sha256']and sha((repo/'.git/config').read_bytes())==binding['source_config_sha256']==b['primary_config_sha256']
 assert all(sha((repo/p).read_bytes())==s for p,s in binding['all137_checked_source_path_sha256'].items())
 critical={'site/4d/build.json','site/4d/data/scenes/1904.json','site/4d/data/sidecars/1904/people.json','site/4d/walk/js/railway.js','site/4d/walk/js/main.js'};assert set(binding['critical_published_sha256'])==critical and all(sha((repo/p).read_bytes())==s for p,s in binding['critical_published_sha256'].items())
 config=(repo/'chicago/4d/tools/memory_ceilings.json').read_bytes();assert sha(config)==binding['memory_config_sha256']and config==g('show','430557a76ad9c8fc70f0fbfb353765bfe8c83857:chicago/4d/tools/memory_ceilings.json')
 assert binding['memory_ceiling_bytes']==json.loads(config)['ceilings']['1904']['mobile']['total_bytes']==400*1048576 and result['phone_unchanged_limit_MiB']==400
 meter=(repo/'chicago/4d/tools/measure_memory.mjs').read_bytes();assert meter==g('show','430557a76ad9c8fc70f0fbfb353765bfe8c83857:chicago/4d/tools/measure_memory.mjs')
 rows=measured['rows'];assert len(rows)==1 and rows[0]['year']=='1904'and rows[0]['viewport']=='mobile'and not rows[0]['errors'];total=rows[0]['totals']['total'];assert isinstance(total,(int,float))and 0<total<=400*1048576 and result['actual_complete_1904_mobile_peak_MiB']==total/1048576
 return {'status':'ACTUAL_CLOSED_INDEPENDENT_ROOT_OFFICIAL_SAME_HEAD_PHONE_REUSED_WITHOUT_BROWSER_OR_METER_RERUN','head':head,'tree':tree,'command':command,'actual_complete_1904_mobile_peak_MiB':total/1048576,'unchanged_limit_MiB':400,'actual_native_meter_module_byte_exact_to430':True,'memory_config_sha256':sha(config),'all137_source_paths_index_config_head_tree_and_critical_published_bindings_exact':True,'actual_native_reaper_all_children_reaped':True,'official_measurement_metadata_preserved_not_restamped':measured['measured'],'receipt':{'path':str(receipt),'sha256':sha(rr)},'binding':{'path':str(folder/'BINDING.json'),'sha256':sha(br)},'measurement':{'path':str(folder/'PHONE.json'),'sha256':sha(mr)},'reaper':{'path':str(folder/'REAPER.json'),'sha256':sha(rp)},'new_phone_or_browser_runs':0}
