"""Price finite native copies/guarded links; do not create the runtime fixture."""
import hashlib,json,os,pathlib,stat
P=pathlib.Path(__file__).resolve().parent;A=pathlib.Path('/workspace/chicago/chicago/4d');F=P/'runtime'
O=pathlib.Path('/workspace/T2383-front-entrance-proposal-20261030')
CB=pathlib.Path('/workspace/T2382-canonical-capture-prep-20261030/postimages/chicago/4d')
SHORT=pathlib.Path('/workspace/s2383c30');NAME='sauganash_hotel__frame_1831.glb'
os.sched_setaffinity(0,{2});sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert not F.exists()and not SHORT.exists()
copies=[];links=[];bindings={}
def bind(p):
 p=pathlib.Path(p);bindings[str(p)]={'source':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def cp(p,target,kind='unchanged current native closure'):
 p=pathlib.Path(p);bind(p);copies.append(dict(bindings[str(p)],target=target,mode=oct(stat.S_IMODE(p.stat().st_mode)),kind=kind))
def link(p,target,kind):
 p=pathlib.Path(p);s=p.stat();links.append({'source':str(p),'target':target,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'kind':kind})
for p in sorted((A/'generators').rglob('*')):
 if p.is_file()and(p.suffix=='.py'or p.name=='blender.pin'):
  rel=p.relative_to(A).as_posix();q=P/'postimages'/rel
  cp(q if q.exists()else p,rel,'entrance-only guarded native producer postimage'if q.exists()else'unchanged current native generator')
  if q.exists():bind(p)
for rel in ['tools/web_derivatives.sh','tools/structure_versions.py','tools/web_derivative_baseline.json','tools/ktx2_glb.py',
 'tools/photo_match.mjs','tools/photo_match_group.mjs','tools/photo_match_enclosures.mjs','tools/photo_match_flora.mjs',
 'assets/manifest.json','assets/manifest.web.json','assets/manifest.versions.json','data/datum.json',
 'data/scenes/1812.json','data/scenes/1835.json','data/scenes/1904.json',
 'docs/RESEARCH/glessner-v4-recovery/manifest.json',
 'data/structures/philo_carpenter_log_shop.json','data/sidecars/1835/philo_carpenter_log_shop.json','data/sidecars/1835/sauganash_hotel.json']:
 cp(A/rel,rel)
cp(P/'postimages/data/structures/sauganash_hotel.json','data/structures/sauganash_hotel.json','accepted entrance-only source record postimage')
bind(A/'data/structures/sauganash_hotel.json');bind(A/'tools/generate_entrances.py');bind(P/'postimages/tools/generate_entrances.py')
views=json.loads((P/'VIEWS.json').read_text())
for v in views:cp(v['source'],v['target'],v['kind'])
photo_bindings={
 '../../sources/assets/sauganash_hotel_andreas_1884.jpg':A.parent/'reference/images/chicago/chicago_sauganash_hotel_1831.jpg',
 '../../../../reference/images/chicago/chicago_sauganash_hotel_1831.jpg':A.parent/'reference/images/chicago/chicago_sauganash_hotel_1831.jpg',
 '../../../../reference/images/chicago/chicago_sauganash_tavern_1835.jpg':A.parent/'reference/images/chicago/chicago_sauganash_tavern_1835.jpg',
 '../../sources/assets/carpenter_log_shop_kurz_1893_panel14.png':CB/'data/sources/assets/carpenter_log_shop_kurz_1893_panel14.png'}
targets=set()
for v in views:
 cam=json.loads(pathlib.Path(v['source']).read_text());photo=photo_bindings[cam['photo']]
 target=os.path.normpath(str(pathlib.Path(v['target']).parent/cam['photo']))
 assert pathlib.Path(os.path.normpath(F/target)).is_relative_to(P)
 if target not in targets:link(photo,target,'exact source frame guarded read-only link');targets.add(target)
 bind(photo);v['photo_sha256']=sha(photo);v['photo_source']=str(photo);v['photo_runtime_target']=target
for rel in ['data/sources/andreas_1884_sauganash_hotel_plate.json','data/sources/trowbridge_sauganash_hotel.json','data/sources/kurz_allison_1893.json']:
 cp(A/rel,rel)
cp(CB/'data/sources/assets/carpenter_log_shop_kurz_1893_panel14.README.md','data/sources/assets/carpenter_log_shop_kurz_1893_panel14.README.md')
# Official WEB removes foreign rows when MASTER paths do not exist. Finite links
# retain those paths; no WEB alias tree, fabricated output or foreign control bake.
for p in sorted((A/'assets/gltf').rglob('*.glb')):
 if p.relative_to(A/'assets/gltf').as_posix()!=NAME:link(p,p.relative_to(A).as_posix(),'foreign MASTER existence/native registered current context only')
old=json.loads(pathlib.Path('/workspace/T2378-native-main-prototype-run-20261030/PLAN.json').read_text())
for row in old['links']:
 if row['target'].startswith('renderers/'):
  p=A/row['target'];bind(p);link(p,row['target'],'unchanged native photo browser module')
for row in json.loads((P/'FAMILY-26.json').read_text()):
 bind(row['record'])
 for k in ['MASTER','WEB']:
  if row[k]:bind(row[k]['path'])
for rel in ['assets/gltf/philo_carpenter_log_shop__log_1832.glb','assets/web/philo_carpenter_log_shop__log_1832.glb']:
 bind(A/rel)
for p in [P/'SOURCE-AND-NATIVE-PROOF.json',P/'ADOPTION-OPERATIONS.json',P/'LIBERTIES-APPEND.md']:
 bind(p)
for row in json.loads((P/'SOURCE-AND-NATIVE-PROOF.json').read_text())['whole_original_frames']:bind(row['file'])
for rel in ['data/pictures/1835.json','tools/generate_entrances.py']:bind(A/rel)
for p in [O/'CLOSED-MANIFEST.json',O/'NATIVE-TRIAL.json',O/'native_trial.py',O/'run_trial.py',O/'adoption/READINESS.json',
 '/workspace/shared/run-with-reaping.py',P/'FAMILY-26.json',P/'SELECTED-RECIPE.json',P/'VIEWS.json',P/'PARAM-READER-REHEARSAL.json',P/'prepare.py',P/'make_plan.py']:
 bind(p)
selected=json.loads((P/'SELECTED-RECIPE.json').read_text())
blender='/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender'
commands=[['VERSION',[blender,'--version']],['BUILD',[blender,'--background','--factory-startup','--threads','2','--python-expr','import sys; sys.dont_write_bytecode=True','--python',str(F/'generators/build.py'),'--','--only','sauganash_hotel','--wrote',str(P/'WROTE.txt')]],['WEB',['bash','tools/web_derivatives.sh','--only',NAME]]]
for i,v in enumerate(views):commands.append([f'PHOTO{i}',['node','tools/photo_match.mjs',v['target'],'--out','docs/RESEARCH/photo-match/'+pathlib.Path(v['target']).parent.name]])
regular_B=sum(r['bytes']for r in copies);allocated=sum((r['bytes']+4095)//4096*4096 for r in copies)
link_B=len(links)*4096
price={'regular_copies':len(copies),'regular_copy_bytes':regular_B,'regular_allocated_upper_B':allocated,
 'guarded_links':len(links),'link_block_upper_B':link_B,'directory_plan_guard_metadata_allowance_B':4*1024**2,
 'five_sequential_capture_and_native_output_allowance_B':16*1024**2,'owned_workspace_browser_build_scratch_allowance_B':24*1024**2,
 'reserve_B':64*1024**2,'shared_TMP_extra_allocation_reserve_B':0}
assert allocated+link_B+price['directory_plan_guard_metadata_allowance_B']+price['five_sequential_capture_and_native_output_allowance_B']+price['owned_workspace_browser_build_scratch_allowance_B']<=price['reserve_B']
plan={'status':'EXTERNAL_READONLY_PREPARED_NATIVE_CANONICAL_EXECUTION_PENDING_ROOT_GRANT','copies':copies,'links':links,'bindings':list(bindings.values()),
 'controller_sha256':sha(P/'run.py'),'candidate':str(P/'postimages/data/structures/sauganash_hotel.json'),
 'recipe_sha256':selected['prospective_recipe_sha256'],'recipe_doc':selected['prospective_recipe'],'views':views,'commands':commands,'price':price,'reserve_B':price['reserve_B'],
 'caller_floors_B':{'workspace':536870912,'shared_TMP':1800000000},'cpu':'future root-only CPUs3,4, Blender threads2; preparation CPU2',
 'deadline_seconds':300,'fixture_created':False,'native_execution_started':False,
 'full_family_native_default_byte_parity':'OWED all foreign active/current version cases before producer adoption; prospective recipes and None defaults are not output qualification',
 'primary_current_Carpenter_context':'Preserved current primary record/sidecars/MASTER exactly. Accepted external annex3 camera packet is not adopted or overwritten.',
 'held_picture_coverage':'Andreas diagnostic plus current legacy registered Andreas plus3 already accepted external source cameras. Petford and distant THE POINT have no registered native source camera and retain qualified/unresolved dispositions; no invented camera.'}
(P/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'status':plan['status'],'copies':len(copies),'links':len(links),'bindings':len(bindings),'views':len(views),'price':price,'runtime_created':F.exists()},indent=2))
