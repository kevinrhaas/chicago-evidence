The accepted T-2383 entrance form is rebased onto current shared native code. The
read-only rehearsal passes on clean committed HEAD
`9d97c8191a074a50f94576195614a16f55345a9f`. No runtime fixture, Blender process,
WEB generation, browser, app/ticket edit or new geometry trial has run here.

Run the read-only rehearsal at any time:

```bash
source /workspace/shared/resume-chicago-env.sh
python -B /workspace/T2383-current-canonical-controller-prep-20261030/run.py
```

Only after root explicitly grants the selected-hotel CPU/source window, the
concrete execution command for the currently checked commit is:

```bash
source /workspace/shared/resume-chicago-env.sh
SAUGANASH_CANONICAL_TRIAL_LEASE=root-one-selected-hotel-build-web-fixed-source-views-3-4 python -B /workspace/T2383-current-canonical-controller-prep-20261030/run.py --execute --expected-head 9d97c8191a074a50f94576195614a16f55345a9f
```

If root has committed another checked head, supply its actual full40hex to
`--expected-head`; this does not waive the264 exact input bindings, link stat
guards, clean-source/noMERGE checks or CPU lease. Changed relevant source bytes
require a new refreshed external packet, preserving this closure. Do not edit a
closed packet to make a stale preflight pass. No native execution is authorized
by this preparation.

`PLAN.json` contains the genuine selected native commands: pinned Blender4.5.3
`build.py --only sauganash_hotel`, official `web_derivatives.sh --only
sauganash_hotel__frame_1831.glb`, and5 sequential unchanged numeric camera views.
The old prototype really ran direct `emit.emit_structure` and native photo_match;
it did not run canonical build.py or official WEB. All31 members of that old
closed packet were rehashed exactly and its full comparison/raw render were
directly viewed. `SOURCE-AND-NATIVE-PROOF.json` preserves those facts.

There are4 authored replacements: the native builder's optional entrance
branch/helper, its params/validation, the native selected-phase ground entrance
reader, and just `frame_1831.form.front_opening_details` on the current hotel
record. `ENTRANCE-ONLY.diff` is the exact bounded patch. The old proposal bundled
foreign GT code that is absent from today's shared producer; none of that code
is transplanted. AST checks preserve every unrelated current top-level function;
all26 phase/reading parameter cases preserve every field except the new optional
None/default or the accepted hotel entrance dictionary. Native reader5 cases and
8 malformed-param refusals pass without generated writes. The reader postimage
is prepared for later adoption; selected hotel geometry/photo does not invoke the
ground/apron generation owner.

`FAMILY-26.json` records24 root phase cases plus2 Tremont readings, with actual
current and prospective native recipe documents. All25 existing MASTER/WEB pairs
have fresh native owner entries and exact WEB-to-MASTER ownership now. The old
hotel `log_1829` case is not selected by any configured scene date and has no
current mesh. The new shared producer changes recipe inputs for all cases;
**all24 foreign existing mesh cases still require genuine native default byte
parity before adoption.** Parameter equality, old default-hotel emit parity and
this future one-selected-hotel run do not complete that obligation.

The prospective selected hotel recipe is
`3dce1bcd7fd71611bcc6531a8510ca85595ee3aaa19af66184edf02b2c31d3dc`.
Current control MASTER is
`ef7ea827f577505cbee8142064394efcf38ff79795e220b5c247d980aa0d8b54`,
WEB `c4d6ee32a9dc0a4bd81523f13390411205d8ce36bdfba233b54b4c7455cf5daf`,
current recipe
`ca4bcb2a83b10eaf26d09aa2e69f34638c1319d0ba637e14ff750efa33d97384`.
The proposed recipe uses the actual native resolved-params document and exact
postimage builder hash; the eventual fixture's unmodified recipe owner must
recompute and equal it before any native stage launches. No output or registry
entry has been invented.

The5 fixed views are the accepted own-hotel Andreas diagnostic, the currently
registered primary legacy Andreas grouping, and the3 already accepted external
Carpenter source cameras (Andreas, Trowbridge, Kurz panel14). Their distinct
registrations and source provenance remain explicit in `VIEWS.json`/`PLAN.json`.
The primary legacy registration and the later canonical Carpenter camera have
different rays; neither is relabelled as the other. The own-hotel numeric rays
stay exact; only stale38-degree roof prose and owned source path are corrected.
The other4 camera byte streams remain exact. Each group binds the unchanged
**current primary** Carpenter record/sidecars/MASTER, not the separately accepted
external annex prototype. The latter's3 camera/annex-shape packet is untouched.
Future group reviews must name both actual mesh hashes and cannot qualify the
pending annex or claim a hotel match simply because an annex camera ran.

The finite fixture has149 copied native/input files,5,359,680 payload bytes,
5,668,864 allocated upper bound, and1051 guarded links. The foreign MASTER links
exist because official WEB otherwise prunes missing foreign native registry rows;
they do not constitute foreign builds or a WEB alias tree. Current owner
registries are copied only into the isolated future runtime. Adoption remains
entrywise; no old registry/Lib table replaces current foreign data.

Reserve64MiB in workspace: copied files/links plus4MiB metadata,16MiB native and
five-capture outputs,24MiB owned browser/build scratch. Require603,979,776 free
workspace bytes (536,870,912 caller floor +67,108,864 reserve), and unchanged
1,800,000,000 sharedTMP floor. All owned scratch uses `/workspace/s2383c30`;
Node's actual `os.tmpdir()` probe returns its `t` child and XDG cache/config return
its `c`/`k` children. Native photo_match uses os.tmpdir/mkdtemp; Chromium inherits
this environment. Official WEB's mktemp calls inherit TMPDIR. No active native
helper hardcodes shared `/tmp`. The socket upper bound is75 bytes, below108.
The future trial uses CPUs3,4/Blender2threads, native shared subreaper, total300s
deadline and0.2s caller-floor watchdog. Source Git/index/config/refs/status,
all current primary GLB bytes, foreign registry row order/metadata and version
registry exactness are guarded before/after. Root's internal lease is mandatory.

Future outputs remain raw `unreviewed` until root directly inspects the actual
source/comparison/raw images. No matches, source grade, historical metrics,
phase identity promotion or DONE is claimed. Keep outputs and runtime until root
review and a verified GitHub evidence bank; never retire symlink targets.

Remaining after the bounded canonical trial: default-family native byte parity,
root visual review, source-specific coverage dispositions, the clearly visible
lower-front-sash discrepancy, entrywise adoption with Lib/name-note union,
native ground/apron and other generated owners, current full gate, BOTH app and
phone checks, policy PR/merge. No new ticket or arbitrary camera/geometry loop.
