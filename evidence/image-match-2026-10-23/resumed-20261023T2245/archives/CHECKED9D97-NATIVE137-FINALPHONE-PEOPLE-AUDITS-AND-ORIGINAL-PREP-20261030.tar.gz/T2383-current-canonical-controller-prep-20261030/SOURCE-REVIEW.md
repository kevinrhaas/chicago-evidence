Direct source review used the full Andreas2017×1296 engraving, Trowbridge860×508,
Petford1200×847, THE POINT composition, and the whole Kurz&Allison sheet with
printed panel14/key. It also directly reviewed the accepted old native entrance
side-by-side and raw render. No new cropped source, native render or source fit
was made for this preparation.

| Held picture | Existing provenance/phase | Preserved disposition |
|---|---|---|
| Andreas/Braunhold hotel plate | Verified1884 US publication, Andreas vol1 printedp632/n1297. The source record describes before1834; the plate has no depicted date. Existing public_domain status retained. Given-name initial unresolved. | Sharpest governing entrance composition. Numeric own-hotel camera remains provisional/off-image principal; old raw comparison is different overall. |
| Trowbridge hotel | Verified Gale1902, facingp31/IA n49; retrospective1835 caption. Existing underlying US1902 public_domain record retained, without a new stock-reproduction licence assertion. | Its source-specific accepted external Carpenter camera is preserved. Same composition/redrawing is not independent dated1835 corroboration. |
| Kurz&Allison panel14 | Verified1893 US print, printed subject key The Sauganash Hotel/Built1831. Existing public_domain source record retained. Whole sheet directly viewed; exact previously registered panel crop/link/README preserved. | Red roof conflicts with inherited Petford green. Capture is a picture comparison, not proof of authentic1831 pigment or opening metrics. |
| Petford | Visible C.E.Petford signature and1831 subject caption; actual original publication/date remains unverified. Two project aliases are byte-identical. | Existing qualified comparative use retained; no new geometry or PD claim derived. No registered native camera exists. No invented copy-camera fit. |
| THE POINT | Existing IMAGE_SOURCES attribution to Justin Herriott1902 is not independently reverified here. Different distant settlement composition; subject attribution remains conditional. | Gross/contextual hotel/annex relationship only. No newly registered camera, opening measurements, placement/metric/rights promotion. |

Legacy aliases: Trowbridge main/folderJPEG share SHA1a4ae4d2…; Petford
main/folderJPEG share83c5ad66…; Andreas594px folder version has different SHA
b20dd261… and is a reduced/cropped composition, not a byte alias. The192px
stock/watermarked thumbnail remains non-measurement comparative material. The
two whole Kurz sheet reproductions are separate scans/colour treatments. These
relationships are inherited from the closed source dossier and checked byte
identities; this review did not derive new geometry from aliases.

The actual old render has the accepted broad entrance case, transom and
sidelights/blind dark centre. The visible Andreas lower front sash remain taller
and narrower than the unchanged model sash. Current generic `_fenestration`
uses0.85×1.35m sash at0.30 of each storey; this is a concrete visible form gap,
not a remaining request for tiny trim work. The source shows the grouped log
annex and roof relationship; the old own-hotel render omitted the annex, which
is why its capture does not settle grouped coverage. No new dimensions or
geometry proposal is made here; first qualify the preserved accepted entrance
through the canonical native owner and actual fixed source views.

Wau-Bun's white paint/two storeys/bright-blue shutters remain independent textual
evidence. Monochrome hatching does not erase those attributes. Retrospective
colour copies disagree; no new source/phase/date or overall building grade is
promoted. Preserve the July1,1835 uncertainty and dependency limits.
