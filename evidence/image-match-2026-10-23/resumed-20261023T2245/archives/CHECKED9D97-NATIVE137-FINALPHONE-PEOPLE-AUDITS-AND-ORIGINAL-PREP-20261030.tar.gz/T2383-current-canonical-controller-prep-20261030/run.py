"""One canonical Sauganash entrance-only native build, official WEB, fixed views.

Default is a read-only rehearsal. --execute additionally requires a clean actual
40-hex HEAD, no merge, exact source bindings, priced capacity and parent CPU lease.
"""
import argparse,datetime,hashlib,json,os,pathlib,re,shutil,signal,subprocess,sys,time
P=pathlib.Path(__file__).resolve().parent;F=P/'runtime'
A=pathlib.Path('/workspace/chicago/chicago/4d');R=A.parents[1]
SHORT=pathlib.Path('/workspace/s2383c30');SID='sauganash_hotel';NAME=SID+'__frame_1831.glb'
SHA=lambda b:hashlib.sha256(b).hexdigest();PF=lambda p:SHA(pathlib.Path(p).read_bytes())
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true');ap.add_argument('--expected-head');args=ap.parse_args()
os.sched_setaffinity(0,{2});sys.dont_write_bytecode=True;plan=json.loads((P/'PLAN.json').read_text())
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',
 OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',NODE_DISABLE_COMPILE_CACHE='1',
 TMPDIR=str(SHORT/'t'),XDG_CACHE_HOME=str(SHORT/'c'),XDG_CONFIG_HOME=str(SHORT/'k'),
 npm_config_logs_dir=str(SHORT/'npm-logs'),npm_config_update_notifier='false')
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def state():return {'head':git('rev-parse','HEAD').decode().strip(),'index':PF(R/'.git/index'),'config':PF(R/'.git/config'),
 'refs':SHA(git('for-each-ref','--format=%(refname) %(objectname)')),'status':SHA(git('status','--porcelain=v1','--untracked-files=all'))}
def check():
 assert PF(P/'run.py')==plan['controller_sha256']
 for row in plan['bindings']:assert PF(row['source'])==row['sha256'],row['source']
 for row in plan['links']:
  s=pathlib.Path(row['source']).stat();assert s.st_size==row['bytes']and s.st_mtime_ns==row['mtime_ns'],row['source']
 for row in plan['copies']:assert PF(row['source'])==row['sha256'],row['source']
 assert not list((A/'data/structures/versions'/SID).glob('*.json'))
 return state()
before=check();merge=(R/'.git/MERGE_HEAD').exists();dirty=bool(git('status','--porcelain=v1','--untracked-files=all'))
assert len(str(SHORT/'t'))+len('/playwright_chromiumdev_profile-XXXXXX/SingletonSocket')<108
if not args.execute:
 # os.tmpdir is actually queried; Chromium launch inherits this same env object.
 node=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import os from 'node:os'; console.log(JSON.stringify({tmp:os.tmpdir(),cache:process.env.XDG_CACHE_HOME,config:process.env.XDG_CONFIG_HOME}))"],env=E))
 assert node['tmp']==str(SHORT/'t')and node['cache']==str(SHORT/'c')and node['config']==str(SHORT/'k')
 print(json.dumps({'status':'READONLY_BINDINGS_AND_PATH_REHEARSAL_PASS_NO_FIXTURE_BUILD_OR_BROWSER',
  'actual_head':before['head'],'MERGE_pending':merge,'primary_dirty':dirty,
  'execution_guard':'later --expected-head must equal actual clean committed 40hex HEAD; current merge/dirty state does not grant execution',
  'commands':plan['commands'],'price':plan['price'],'workspace_required_B':536870912+plan['reserve_B'],
  'shared_TMP_required_B':1800000000,'free_B':{m:shutil.disk_usage(m).free for m in ['/workspace','/tmp']},
  'environment_probe':node,'runtime_fixture_exists':F.exists(),'workspace_scratch_exists':SHORT.exists(),
  'chromium_socket_path_upper_bound':len(str(SHORT/'t'))+len('/playwright_chromiumdev_profile-XXXXXX/SingletonSocket'),
  'prospective_recipe_sha256':plan['recipe_sha256'],'full_family_native_default_byte_parity':'OWED before any producer adoption'},indent=2));raise SystemExit(0)
assert args.expected_head and re.fullmatch('[0-9a-f]{40}',args.expected_head)
assert before['head']==args.expected_head and not merge and not dirty
assert os.environ.get('SAUGANASH_CANONICAL_TRIAL_LEASE')=='root-one-selected-hotel-build-web-fixed-source-views-3-4'
assert not(P/'RESULT.json').exists()and not F.exists()and not SHORT.exists()
assert shutil.disk_usage('/workspace').free>=536870912+plan['reserve_B']and shutil.disk_usage('/tmp').free>=1800000000
started=time.monotonic();minimum={m:shutil.disk_usage(m).free for m in ['/workspace','/tmp']}
assets={str(p):PF(p)for d in ['gltf','web']for p in(A/'assets'/d).rglob('*.glb')}
(P/'PRIMARY-ASSET-GUARDS.json').write_text(json.dumps(assets,indent=2)+'\n')
F.mkdir();SHORT.mkdir(mode=0o700)
for n in ['t','c','k','npm-logs']:(SHORT/n).mkdir(mode=0o700)
for row in plan['copies']:
 d=F/row['target'];assert d.absolute().is_relative_to(P)
 d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(row['source'],d);os.chmod(d,int(row['mode'],8));assert PF(d)==row['sha256']
for row in plan['links']:
 d=(F/row['target']).absolute();assert pathlib.Path(os.path.normpath(d)).is_relative_to(P)
 d.parent.mkdir(parents=True,exist_ok=True);d.symlink_to(row['source'])
assert not(F/'assets/gltf'/NAME).exists()and not(F/'assets/web'/NAME).exists()
# The genuine recipe owner, now installed at its native runtime paths.
sys.path.insert(0,str(F/'generators'));import mesh_inputs
record=json.loads((F/'data/structures'/f'{SID}.json').read_text());phase=next(p for p in record['phases']if p['id']=='frame_1831')
assert mesh_inputs.structure_inputs_sha(record,phase)==plan['recipe_sha256']
assert mesh_inputs.structure_inputs_doc(record,phase)==plan['recipe_doc']
registries={k:json.loads((F/'assets'/k).read_text())for k in ['manifest.json','manifest.web.json','manifest.versions.json']};stages=[]
try:
 for stage,command in plan['commands']:
  assert check()==before
  assert time.monotonic()-started<300,'300s deadline'
  reap=P/(stage+'-REAPER.json');log=P/(stage+'.log');stop=None;t=time.monotonic()
  wrapped=['python3','/workspace/shared/run-with-reaping.py',str(reap),'--','nice','-n','19','taskset','-c','3,4',*command]
  with log.open('x')as stream:
   child=subprocess.Popen(wrapped,cwd=F,env=E,stdout=stream,stderr=subprocess.STDOUT)
   while child.poll()is None:
    for m in minimum:minimum[m]=min(minimum[m],shutil.disk_usage(m).free)
    if minimum['/workspace']<536870912 or minimum['/tmp']<1800000000:stop=stop or 'caller floor breached'
    if time.monotonic()-started>300:stop=stop or '300s total deadline'
    if stop and child.poll()is None:child.send_signal(signal.SIGTERM)
    time.sleep(.2)
   code=child.wait()
  rp=json.loads(reap.read_text());row={'stage':stage,'exit':code,'seconds':time.monotonic()-t,'all_children_reaped':rp['all_children_reaped'],'stop':stop,'argv':command};stages.append(row)
  (P/'STAGES.json').write_text(json.dumps(stages,indent=2)+'\n');print(json.dumps(row),flush=True)
  assert not stop and code==0 and rp['command_exit']==0 and rp['all_children_reaped'],log.read_text()[-4000:]
  if stage=='VERSION':assert 'Blender 4.5.3'in log.read_text()
  if stage=='BUILD':assert(P/'WROTE.txt').read_text().splitlines()==[NAME]
  if stage=='WEB':assert 'gltf-transform unavailable'not in log.read_text()and 'fell back'not in log.read_text()
 finally_state=state();assert finally_state==before
finally:
 (P/'SOURCE-GUARD-AFTER.json').write_text(json.dumps({'before':before,'after':state(),'exact':state()==before,'all_primary_assets_exact':all(PF(p)==h for p,h in assets.items()),'stages':stages},indent=2)+'\n')
post={k:json.loads((F/'assets'/k).read_text())for k in registries}
for registry,key in [('manifest.json','assets'),('manifest.web.json','masters')]:
 old,new=registries[registry],post[registry];assert list(old[key])==list(new[key]);assert {n:v for n,v in old[key].items()if n!=NAME}=={n:v for n,v in new[key].items()if n!=NAME};assert {n:v for n,v in old.items()if n!=key}=={n:v for n,v in new.items()if n!=key}
assert post['manifest.versions.json']==registries['manifest.versions.json']
master=F/'assets/gltf'/NAME;web=F/'assets/web'/NAME
assert post['manifest.json']['assets'][NAME]['inputs_sha256']==plan['recipe_sha256']
assert post['manifest.web.json']['masters'][NAME]==PF(master)
assert state()==before and all(PF(p)==h for p,h in assets.items());check()
C=P/'closed-authority';C.mkdir();closed=[]
def preserve(src,rel):
 d=C/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,d);closed.append({'path':str(d.relative_to(P)),'bytes':d.stat().st_size,'sha256':PF(d)})
preserve(master,'native-master/'+NAME);preserve(web,'native-web/'+NAME)
for row in plan['copies']:
 if row['target'].startswith(('generators/','tools/','data/')):preserve(F/row['target'],'native-inputs/'+row['target'])
views=[]
for i,v in enumerate(plan['views']):
 cam=F/v['target'];match=cam.with_suffix('.match.json');review=json.loads(match.read_text())
 assert review['verdict']=='unreviewed'and review['camera_sha256']==v['sha256']and review['photo_sha256']==v['photo_sha256']
 if v['kind']=='accepted entrance own-hotel diagnostic':assert review['glb_sha256']==PF(master)
 else:
  group=review['rendered_members'];assert {m['structure_id']for m in group}=={'philo_carpenter_log_shop','sauganash_hotel'}
  assert next(m for m in group if m['structure_id']=='sauganash_hotel')['glb_sha256']==PF(master)
  assert next(m for m in group if m['structure_id']=='philo_carpenter_log_shop')['glb_sha256']==PF(A/'assets/gltf/philo_carpenter_log_shop__log_1832.glb')
 for src,rel in [(cam,'camera.json'),(match,'native-unreviewed.match.json'),(F/review['side_by_side'],'source-comparison.jpg')]:preserve(src,f'views/{i}/'+rel)
 raw=re.search(r'\n\s+(/[^\n]+-render\.png)\n',(P/f'PHOTO{i}.log').read_text());assert raw
 raw=pathlib.Path(raw.group(1));assert raw.is_relative_to(SHORT/'t');preserve(raw,f'views/{i}/native-render.png')
 views.append({'camera':v['target'],'kind':v['kind'],'raw_verdict':'unreviewed','source_id':v['source_id'],'context':'CURRENT primary Carpenter control, not adoption of pending annex proposal'})
entries={'master':post['manifest.json']['assets'][NAME],'web_master_sha256':post['manifest.web.json']['masters'][NAME],'recipe_sha256':plan['recipe_sha256'],'recipe_doc':plan['recipe_doc']}
(C/'NATIVE-ENTRIES.json').write_text(json.dumps(entries,indent=2)+'\n');closed.append({'path':str((C/'NATIVE-ENTRIES.json').relative_to(P)),'bytes':(C/'NATIVE-ENTRIES.json').stat().st_size,'sha256':PF(C/'NATIVE-ENTRIES.json')})
result={'status':'ACTUAL_CANONICAL_SELECTED_HOTEL_BUILD_WEB_FIXED_VIEWS_PASS_UNREVIEWED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_HEAD':before['head'],'seconds_total':time.monotonic()-started,'stages':stages,'MASTER_sha256':PF(master),'WEB_sha256':PF(web),'recipe_sha256':plan['recipe_sha256'],
 'native_master_entry':entries['master'],'views':views,'all_foreign_registry_rows_order_metadata_exact':True,'all_primary_asset_bytes_exact_count':len(assets),
 'primary_source_Git_guards_exact':True,'all_children_reaped':True,'minimum_free_B':minimum,'current_free_B':{m:shutil.disk_usage(m).free for m in minimum},
 'full_family_native_default_byte_parity':'OWED for all foreign current cases before producer adoption; this one selected trial does not qualify family parity',
 'matches_identity_grade_or_DONE_claimed':False,'members':closed,'fixture_retirement':'WAIT root direct review and verified evidence bank; never unlink primary targets'}
(P/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='members'},indent=2),flush=True)
