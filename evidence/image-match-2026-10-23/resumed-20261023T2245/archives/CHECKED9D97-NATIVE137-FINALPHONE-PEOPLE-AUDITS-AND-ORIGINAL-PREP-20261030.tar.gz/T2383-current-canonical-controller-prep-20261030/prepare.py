"""Refresh only the accepted T2383 entrance feature against exact current bytes.

External data preparation only. No native build, browser, runtime fixture or app writes.
Prospective recipe documents use native resolved-params-v4; the sole substituted code
hash is the exact authored frame_tavern postimage. The later native build must confirm it.
"""
import ast,copy,dataclasses,difflib,hashlib,json,os,pathlib,sys,types
P=pathlib.Path(__file__).resolve().parent
A=pathlib.Path('/workspace/chicago/chicago/4d')
O=pathlib.Path('/workspace/T2383-front-entrance-proposal-20261030')
CB=pathlib.Path('/workspace/T2382-canonical-capture-prep-20261030/postimages/chicago/4d')
os.sched_setaffinity(0,{2});sys.dont_write_bytecode=True
sha=lambda b:hashlib.sha256(b).hexdigest()
pf=lambda p:sha(pathlib.Path(p).read_bytes())
def save(rel,obj):
 p=P/rel;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(obj if isinstance(obj,str) else json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
 return p
def change(text,old,new):
 assert text.count(old)==1,old
 return text.replace(old,new,1)
def function(text,name):
 n=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)and n.name==name)
 return '\n'.join(text.splitlines()[n.lineno-1:n.end_lineno])+'\n'
paths=['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','tools/generate_entrances.py']
base={p:(A/p).read_text()for p in paths};post=dict(base)
post[paths[0]]=change(post[paths[0]],'''                _door(b, params, "y", d, 1, cx - 0.6, cx + 0.6, 0.0, 2.1, conf)
                if params.entrance_frontispiece:
                    _frontispiece(b, params, cx, d)
''','''                if params.front_opening_details is not None:
                    _pictured_front_entrance(b, params, cx, d)
                else:
                    _door(b, params, "y", d, 1, cx - 0.6, cx + 0.6, 0.0, 2.1, conf)
                    if params.entrance_frontispiece:
                        _frontispiece(b, params, cx, d)
''')
helper=function((O/'fixture'/paths[0]).read_text(),'_pictured_front_entrance')
post[paths[0]]=change(post[paths[0]],'def _frontispiece(',helper+'\n\ndef _frontispiece(')
p=paths[1]
post[p]=change(post[p],'"shutter_type", "entrance_frontispiece",','"shutter_type", "entrance_frontispiece", "front_opening_details",')
post[p]=change(post[p],'    entrance_frontispiece: bool = False\n','    entrance_frontispiece: bool = False\n    front_opening_details: dict | None = field(default=None, kw_only=True)\n')
post[p]=change(post[p],'        if self.elevation_scheme not in (','        if self.front_opening_details is not None:\n            _validate_front_opening_details(self)\n        if self.elevation_scheme not in (')
post[p]=change(post[p],'def _board_lay(',function((O/'fixture'/p).read_text(),'_validate_front_opening_details')+'\n\ndef _board_lay(')
post[p]=change(post[p],'        entrance_frontispiece=bool(val("entrance_frontispiece", False)),','        entrance_frontispiece=bool(val("entrance_frontispiece", False)),\n        front_opening_details=val("front_opening_details"),')
p=paths[2]
post[p]=change(post[p],function(post[p],'front_doors'),function((O/'adoption/generate_entrances.py').read_text(),'front_doors'))
post[p]=change(post[p],'if any(x["read_by"] == "frame_tavern.resolved_front_ground_stations (selected phase)"','if any(x["read_by"] in ("frame_tavern.resolved_front_ground_stations (selected phase)",\n                                   "frame_tavern.front_opening_details (selected phase)")')
patch=[]
for p in paths:
 ast.parse(post[p]);save('postimages/'+p,post[p])
 patch.extend(difflib.unified_diff(base[p].splitlines(True),post[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p))
record=json.loads((A/'data/structures/sauganash_hotel.json').read_text())
candidate=copy.deepcopy(record)
old=json.loads((O/'adoption/sauganash_hotel.json').read_text())
ph=next(p for p in candidate['phases']if p['id']=='frame_1831')
oldph=next(p for p in old['phases']if p['id']=='frame_1831')
assert 'front_opening_details'not in ph['form']
ph['form']['front_opening_details']=oldph['form']['front_opening_details']
save('postimages/data/structures/sauganash_hotel.json',candidate)
patch.extend(difflib.unified_diff((A/'data/structures/sauganash_hotel.json').read_text().splitlines(True),(P/'postimages/data/structures/sauganash_hotel.json').read_text().splitlines(True),fromfile='a/data/structures/sauganash_hotel.json',tofile='b/data/structures/sauganash_hotel.json'))
save('ENTRANCE-ONLY.diff',''.join(patch))
# Exact AST preservation outside the bounded changed functions/class.
def nodes(t):return {getattr(n,'name',n.targets[0].id if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)else str(i)):ast.dump(n,include_attributes=False)for i,n in enumerate(ast.parse(t).body)}
for p,allowed in [(paths[0],{'_fenestration','_pictured_front_entrance'}),(paths[1],{'CONSUMED','FrameTavernParams','_validate_front_opening_details','from_phase'}),(paths[2],{'front_doors','build'})]:
 b,n=nodes(base[p]),nodes(post[p]);assert all(b[k]==n[k]for k in b if k not in allowed),p
# Native current and proposed parameter resolution (no Blender import).
sys.path.insert(0,str(A/'generators'));import mesh_inputs
family=[]
manifest=json.loads((A/'assets/manifest.json').read_text());web=json.loads((A/'assets/manifest.web.json').read_text());versions=json.loads((A/'assets/manifest.versions.json').read_text())
for rp in sorted((A/'data/structures').glob('*.json')):
 r=json.loads(rp.read_text())
 if r.get('archetype')!='frame_tavern':continue
 for phase in r['phases']:family.append((rp,r,phase,None))
for rp in sorted((A/'data/structures/versions').rglob('*.json')):
 r=json.loads(rp.read_text())
 if r.get('archetype')=='frame_tavern':
  for phase in r['phases']:family.append((rp,r,phase,rp.stem))
assert len(family)==26,len(family)
current=[]
for rp,r,p,v in family:
 d=mesh_inputs.structure_inputs_doc(r,p);current.append((d,mesh_inputs.structure_inputs_sha(r,p)))
# Load exactly the native proposed parameter module. Prospective code hash is
# explicitly substituted because the authored builder is not installed in primary.
name='archetypes.frame_tavern_params';mod=types.ModuleType(name);mod.__file__=str(A/paths[1]);sys.modules[name]=mod
exec(compile(post[paths[1]],str(P/'postimages'/paths[1]),'exec'),mod.__dict__)
roster=[]
for (rp,r,p,v),(cur,h)in zip(family,current):
 rr=candidate if r['id']=='sauganash_hotel'else r
 pp=next(x for x in rr['phases']if x['id']==p['id'])
 doc=mesh_inputs.structure_inputs_doc(rr,pp)
 doc['code']['archetypes/frame_tavern.py']=sha(post[paths[0]].encode())
 prospective=sha(json.dumps(doc,sort_keys=True).encode())
 # Use actual native serialization definition, guarded below against current SHA.
 assert h==sha(json.dumps(cur,sort_keys=True).encode())
 bare=copy.deepcopy(doc['params']);bare['fields'].pop('front_opening_details');bare['confidence'].pop('front_opening_details',None)
 assert bare==cur['params'],(r['id'],p['id'],'non-entrance params drift')
 filename=f"{r['id']}__{p['id']}"+(f'__{v}'if v else '')+'.glb'
 matches=list((A/'assets/gltf').glob(filename))
 # Version naming is native `__v_` rather than guessed; discover existing stem.
 if v:matches=list((A/f"assets/gltf/versions/{r['id']}/{v}").glob(f"{r['id']}__{p['id']}.glb"))
 master=matches[0]if len(matches)==1 else None
 w=A/'assets/web'/master.relative_to(A/'assets/gltf') if master else None
 row={'record':str(rp),'record_sha256':pf(rp),'structure':r['id'],'phase':p['id'],'reading':v,
      'current_recipe_sha256':h,'prospective_recipe_sha256':prospective,'current_recipe':cur,'prospective_recipe':doc,
      'default_params_preserved_except_new_optional_None':r['id']!='sauganash_hotel'or p['id']!='frame_1831',
      'MASTER':None if master is None else {'path':str(master),'sha256':pf(master),'bytes':master.stat().st_size},
      'WEB':None if w is None or not w.exists()else{'path':str(w),'sha256':pf(w),'bytes':w.stat().st_size},
      'native_default_byte_parity':'OWED actual native full-family comparison; parameter equality is insufficient'}
 if master is None:row['mesh_disposition']='Inactive log_1829: no configured scene date selects this phase; no current MASTER/WEB'
 else:
  key=master.relative_to(A/'assets/gltf').as_posix()
  row['native_owner_entry']=(versions if v else manifest)['assets'][key]
  row['WEB_owner_master_sha256']=row['native_owner_entry'].get('web_master_sha256')if v else web['masters'][key]
  row['current_native_owner_recipe_fresh']=row['native_owner_entry']['inputs_sha256']==h
  row['current_WEB_owner_master_exact']=row['WEB_owner_master_sha256']==row['MASTER']['sha256']
  assert row['current_native_owner_recipe_fresh']and row['current_WEB_owner_master_exact'],key
 roster.append(row)
save('FAMILY-26.json',roster)
selected=next(r for r in roster if r['structure']=='sauganash_hotel'and r['phase']=='frame_1831')
save('SELECTED-RECIPE.json',selected)
# Actual selected-phase reader, five meaningful cases, no generated ground writes.
fn=next(n for n in ast.parse(post[paths[2]]).body if isinstance(n,ast.FunctionDef)and n.name=='front_doors')
fake=types.SimpleNamespace(STRUCTURES=A/'data/structures',_front_edge=lambda poly:(min(x[0]for x in poly),max(x[0]for x in poly),max(x[1]for x in poly)))
ns={'gbs':fake,'_frame_tavern_params':mod.from_phase,'TAVERN_DOOR_W_M':1.2};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<proposed native reader>','exec'),ns)
cases=[]
def ask(r,pid):
 p=next(p for p in r['phases']if p['id']==pid);sc={'id':r['id'],'archetype':'frame_tavern','phase':pid,'footprint':copy.deepcopy(p['footprint'])};fake._load=lambda _:r
 return ns['front_doors'](sc),sc
(doors,reader),sc=ask(candidate,'frame_1831');assert abs(doors[0]['u1']-doors[0]['u0']-.85)<1e-12;assert reader=='frame_tavern.front_opening_details (selected phase)';cases.append('candidate .85m leaf at unchanged native centre')
sc['footprint']['polygon'][0][0]+=.01
try:ns['front_doors'](sc)
except ValueError:cases.append('candidate stale sidecar refused')
else:raise AssertionError('stale candidate sidecar accepted')
(doors,reader),_=ask(record,'frame_1831');assert abs(doors[0]['u1']-doors[0]['u0']-1.2)<1e-12;cases.append('legacy centred 1.2m default retained')
gt=json.loads((A/'data/structures/green_tree_tavern.json').read_text());(doors,reader),_=ask(gt,gt['phases'][0]['id']);assert reader=='frame_tavern.resolved_front_ground_stations (selected phase)';cases.append('current GT selected-phase moved-door reader retained')
(doors,reader),_=ask(record,'log_1829');assert abs(doors[0]['u1']-doors[0]['u0']-1.2)<1e-12;cases.append('inactive old hotel phase retains default reader')
refusals=[]
for key,value in [('kind','open_interior'),('leaf_width_m',True),('leaf_width_m',float('nan')),('case_width_m',5.),('leaf_head_m',3.1),('cornice_top_m',2.8),('sidelights_each_width_m',.5),('jamb_outer_width_m',1.7)]:
 bad=copy.deepcopy(candidate);bph=next(p for p in bad['phases']if p['id']=='frame_1831');bph['form']['front_opening_details']['value'][key]=value
 try:mod.from_phase(bph,bad)
 except mod.ParamError as e:refusals.append({'field':key,'value':str(value),'refusal':str(e)})
 else:raise AssertionError(('malformed accepted',key,value))
save('PARAM-READER-REHEARSAL.json',{'status':'PASS_NO_BAKE_OR_GENERATED_WRITES','family_cases':len(roster),'reader_cases':cases,'malformed_param_refusals':refusals,'producer_native_default_byte_parity':'OWED, not tested'})
# Keep the accepted cameras immutable; separate current-primary legacy registration.
cam=json.loads((O/'andreas-current-own-hotel-diagnostic.json').read_text());original_cam=copy.deepcopy(cam)
cam['photo']='../../sources/assets/sauganash_hotel_andreas_1884.jpg'
cam['solve']='Inherited numeric own-hotel diagnostic framing; no refit. Current working roof pitch is25.2 degrees, not the stale38-degree prose of the historical camera. RMS16.28px/max30.15px refer to approximate wall-corner picks, with off-image principal point poorly constrained. Entrance-only canonical trial; no whole-building/source-date match claim.'
for k in ['eye','yaw_deg','focal_px','principal_px','image_px','sky']:assert cam[k]==original_cam[k]
save('cameras/sauganash_hotel/andreas-current-own-hotel-diagnostic.json',cam)
views=[{'kind':'accepted entrance own-hotel diagnostic','source':str(P/'cameras/sauganash_hotel/andreas-current-own-hotel-diagnostic.json'),'target':'data/reference_views/sauganash_hotel/andreas-current-own-hotel-diagnostic.json','source_id':cam['source_id']}]
currentcam=A/'data/reference_views/philo_carpenter_log_shop/andreas-1884.json'
views.append({'kind':'currently registered primary legacy diagnostic','source':str(currentcam),'target':'data/reference_views/philo_carpenter_log_shop/andreas-primary-legacy.json','source_id':'andreas_1884_sauganash_hotel_plate'})
for n in ['andreas-1884','trowbridge-1902','kurz-allison-1893-panel14']:
 views.append({'kind':'accepted external Carpenter source camera, pending primary adoption; numeric bytes unchanged','source':str(CB/f'data/reference_views/philo_carpenter_log_shop/{n}.json'),'target':f'data/reference_views/philo_carpenter_log_shop/{n}.json','source_id':json.loads((CB/f'data/reference_views/philo_carpenter_log_shop/{n}.json').read_text())['source_id']})
for v in views:v['sha256']=pf(v['source'])
save('VIEWS.json',views)
print(json.dumps({'status':'EXTERNAL_ENTRYWISE_POSTIMAGES_AND_NATIVE_PARAM_REHEARSAL_PASS','family_cases':len(roster),'current_mesh_pairs':sum(bool(r['MASTER']and r['WEB'])for r in roster),'selected_recipe':selected['prospective_recipe_sha256'],'views':len(views),'runtime_fixture_created':False,'native_build_or_browser_run':False},indent=2))
