# Dearborn bridge six-model controller refresh — prepared, native run pending

This external packet refreshes the existing accepted V5 trial against the parent's current35 integration inputs. No primary source, Git/index/ref, site, ticket, claim or PR changed. No fixture, native export, WEB derivative, browser or comparison was produced.

All six complete current and proposed native recipe rows, records and MASTER/WEB bindings are **exact to the closed controller**. The selected candidate still requires actual MASTER `c7408d424c67488f56650e190fdd7af6a23a667c67f005dff1849ef20c3b2f84`/1,101,020B and official WEB `f7abac99a73e858b055c5668a61e093a7786385cb542cecb3245ebc55d7907ab`/136,752B. Five controls must reproduce both current outputs byte for byte. Both bridge producer postimages, selected record, Earle camera, original photograph and all four source-provenance records are unchanged.

Only five unrelated producer snapshots changed: K01, K08, K13, K14 and prairie_draft. Current canonical registry contexts are rebound for entrywise foreign-row preservation. The historical20authored paths remain15exact plus the same5shared name-pool/contract/main/walker/compiler hooks. These hooks still require entrywise future adoption; no old shared table, renderer or compiler file is replayed by this trial. No new geometry, width, pile count or camera choice is made.

The bridge remains the mapped76.33m gap,18.288m draw and **16ft** width, with46 reconstructed perimeter piles per platform/92total. Cleared Earle/Andreas/Norton evidence drives geometry. The attributed owner credit is Chicago Tribune Editorial,15February1880; the exact Baker artwork remains independently unlocated and reference-only. No Baker-derived geometry/camera, blanket image clearance or new rights assertion is created. The old1849Earle filename remains only for link continuity.

## Guard and resource changes

Execution now requires the parent's **actual checked40hex HEAD**, no MERGE_HEAD and a clean checkout before creating any fixture. The exact Git/index/config/ref freeze is monitored during every owned stage. An unknown future commit is never guessed. Native phases remain serial, pinned Blender4.5.3/threads4, CPU0,1,3,4, official build/emit and WEB producers, unchanged stage limits90/120/75s, owned reaper and a strict whole-invocation **330s** cap.

The short owned scratch path is `/workspace/b2375-v3-tmp`; TMP/TEMP and XDG cache/config all stay there. A representative Chromium Unix socket path is77bytes, below108. This path is created only after the execution guards and root grant; neither it nor a run fixture exists now.

Current regular scaffold is5,119,610B. The conservative **24MiB extra reserve** remains unchanged, above workspace536,870,912B and sharedTMP1,800,000,000B floors: workspace must be at least562,036,736B at launch. Actual reserve/floors are rechecked before setup and each stage, and monitored during owned children. The read-only rehearsal reports observed space but deliberately makes no execution-resource claim while the parent's gate may use transient scratch.

Nine pure checked-state/input/CLI guards and two syntax checks passed. All72 files across the old Bridge packet, frozen JailV3 and actual38-file Jail closure remain SHA/size/mode exact. Actual recipe recomputation and source review are recorded in PLAN.json, VALIDATION.json and READONLY-REHEARSAL.json. The reviewed controller diff introduces these guards only; accepted bridge geometry/camera/native bindings remain unchanged.

## Later root invocation

Once the parent has finished its current phone/gate work and grants this one source/CPU phase, use the actual clean checked commit. Correct separate arguments are `--seconds 330`:

```bash
source /workspace/shared/resume-chicago-env.sh
T2375_NATIVE_CPU=root-approved-frozen-native6 PYTHONDONTWRITEBYTECODE=1 python /workspace/T2375-native6-current35-prep-20261030/controller.py --execute --seconds 330 --expected-head ACTUAL_CHECKED40HEX
```

That runs exactly six official exports, official WEB for the actual six-file WROTE list, five default MASTER/WEB byte controls and selected exact V5 reproduction, then ONE existing Earle full-bridge comparison. Native assets/entries close before the camera phase; selected outputs and all raw receipts/images remain outside the disposable fixture. The image verdict remains unreviewed until the parent directly inspects it.

The unchanged family-only/capture-only recovery modes remain available under the same checked source. Only after direct root view may `--retire-fixture --root-viewed --expected-head SAME_CHECKED40HEX` remove this controller's owned fixture and short scratch; exact retained artifacts/reapers and restore authority must verify first. No read-only link target is removed.

Canonical source adoption/owners, full original-picture review, current desktop/mobile app/Images/Sources/Research/walking/prop checks, full source/preflight gates and policy PR/dev merge remain pending. This is a concrete runnable next trial, not T-2375 completion.
