"""Official selected6 bridge build/WEB and one Earle comparison; UNRUN without root grant."""
from pathlib import Path
import argparse,ast,datetime,hashlib,json,os,re,shutil,signal,stat,subprocess,sys,time
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent; PLAN=json.loads((P/'PLAN.json').read_text());A=Path(PLAN['primary']);ROOT=A.parents[1];GIT_ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def need(c,m):
 if not c:raise RuntimeError(m)
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def check(r):
 p=Path(r['path']);need(p.is_file()and p.stat().st_size==r['bytes']and sha(p)==r['sha256']and stat.S_IMODE(p.stat().st_mode)==r['mode'],'bound input changed '+str(p))
def floors(extra=0):
 need(shutil.disk_usage('/workspace').free>=PLAN['workspace_floor']+extra,'workspace floor/reserve');need(shutil.disk_usage('/tmp').free>=PLAN['tmp_floor'],'TMP floor')
def inputs():
 for x in ['candidate_record','camera','photo','historical_packet','historical_V5_native','reaper']:check(PLAN[x])
 for x in PLAN['source_provenance']:check(x)
 for x in PLAN['copies']:check(x['source']);check(x['postimage'])
 man=json.loads((A/'assets/manifest.json').read_text())['assets'];web=json.loads((A/'assets/manifest.web.json').read_text())['masters']
 for r in PLAN['family']:
  for x in ['record','MASTER','WEB']:check(r[x])
  need(man[r['asset']]['inputs_sha256']==r['current_native_recipe']and web[r['asset']]==r['MASTER']['sha256'],'native family registration changed '+r['asset'])
def validate_checked_state(expected,head,has_merge,status):
 need(isinstance(expected,str)and re.fullmatch('[0-9a-f]{40}',expected),'actual checked --expected-head40hex required')
 need(head==expected,'primary checked HEAD changed');need(not has_merge,'primary MERGE_HEAD exists');need(not status,'primary source is not clean')
 return {'HEAD':head,'no_merge':True,'source_clean':True}
def checked_source_guard(expected):
 head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],env=GIT_ENV,text=True).strip()
 status=subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain=v1'],env=GIT_ENV)
 return validate_checked_state(expected,head,(ROOT/'.git/MERGE_HEAD').exists(),status)
def preflight(require_resources=True):
 inputs();
 if require_resources:floors()
 need(len(PLAN['family'])==6 and sum(r['role']=='default_control'for r in PLAN['family'])==5,'scope changed');ast.parse((P/'controller.py').read_text())
 return {'status':'PURE_PREFLIGHT_PASS_NO_FIXTURE_NO_NATIVE'if require_resources else'READONLY_REHEARSAL_INPUTS_PASS_EXECUTION_NOT_REQUESTED','resource_floors_enforced_here':require_resources,'at':now(),'six_recipes_and_source_bindings_exact':True,'current_workspace_free':shutil.disk_usage('/workspace').free,'current_TMP_free':shutil.disk_usage('/tmp').free,'required_workspace':PLAN['workspace_floor']+PLAN['start_extra_reserve'],'reserve_fits':shutil.disk_usage('/workspace').free>=PLAN['workspace_floor']+PLAN['start_extra_reserve']}
class Run:
 def __init__(self,args):
  self.args=args;self.R=P/'run';self.F=self.R/'fixture';self.D=self.R/'receipts';self.C=self.R/'closed-authority';self.tmp=Path(PLAN['short_private_TMPDIR']);self.deadline=time.monotonic()+args.seconds
  self.E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',NODE_DISABLE_COMPILE_CACHE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PW_EXECUTABLE='/usr/bin/chromium',TMPDIR=str(self.tmp),TMP=str(self.tmp),TEMP=str(self.tmp),XDG_CACHE_HOME=str(self.tmp/'xdg-cache'),XDG_CONFIG_HOME=str(self.tmp/'xdg-config'))
 def git(self):
  repo=A.parent.parent;g=lambda args:subprocess.check_output(['git','-C',str(repo),*args],env=self.E)
  return {'HEAD':g(['rev-parse','HEAD']).decode().strip(),'status':hashlib.sha256(g(['status','--porcelain=v1'])).hexdigest(),'index':sha(repo/'.git/index'),'config':sha(repo/'.git/config'),'refs':hashlib.sha256(g(['for-each-ref','--format=%(refname) %(objectname)'])).hexdigest()}
 def guard(self,full=False):
  need(self.initial['git']['HEAD']==self.args.expected_head and not(ROOT/'.git/MERGE_HEAD').exists(),'checked head/merge freeze changed')
  need(self.git()==self.initial['git'],'primary Git/source freeze changed')
  for p,h in self.initial['registries'].items():need(sha(A/p)==h,'primary registry changed '+p)
  if full:inputs()
 def link(self,src,rel):
  q=self.F/rel;q.parent.mkdir(parents=True,exist_ok=True);need(not q.exists()and not q.is_symlink(),'existing fixture slot '+str(q));q.symlink_to(src,target_is_directory=Path(src).is_dir())
 def setup(self):
  checked_source_guard(self.args.expected_head);inputs();floors(PLAN['start_extra_reserve']);need(not self.R.exists()and not self.tmp.exists(),'owned run/scratch already exists; preserve previous result')
  self.D.mkdir(parents=True);self.C.mkdir();self.tmp.mkdir(mode=0o700);self.initial={'at':now(),'git':self.git(),'registries':{x:sha(A/x)for x in PLAN['regs']}}
  save(self.R/'INITIAL.json',self.initial)
  for r in PLAN['copies']:
   q=self.F/r['rel'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r['postimage']['path'],q);q.chmod(r['postimage']['mode'])
  for rel in PLAN['regs']:
   q=self.F/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(A/rel,q)
  for rel in ['assets/gltf','assets/web','assets/bakes','data/structures','data/reference_views']:(self.F/rel).mkdir(parents=True,exist_ok=True)
  for rel in ['data/scenes','data/datum.json','data/sources','assets/textures','docs','renderers']:self.link(A/rel,rel)
  self.link(A/'assets/gltf','assets/gltf/.baseline')
  for p in sorted((A/'assets/gltf').glob('*.glb')):self.link('.baseline/'+p.name,'assets/gltf/'+p.name)
  if (A/'assets/gltf/versions').exists():self.link(A/'assets/gltf/versions','assets/gltf/versions')
  for r in PLAN['family']:self.link(r['record']['path'],'data/structures/'+r['id']+'.json')
  q=self.F/'data/structures/dearborn_street_drawbridge.json';need(q.is_symlink(),'selected record unsafe');q.unlink();shutil.copyfile(PLAN['candidate_record']['path'],q)
  self.link('/workspace/shared/node/node_modules','node_modules')
  self.before={x:json.loads((self.F/x).read_text())for x in PLAN['regs']};self.guard(True)
 def resume(self):
  checked_source_guard(self.args.expected_head);need((self.R/'FAMILY-CLOSED.json').is_file(),'no closed family to resume');self.initial=json.loads((self.R/'INITIAL.json').read_text());self.guard(True)
 def stage(self,label,argv,limit):
  floors();self.guard();need(time.monotonic()<self.deadline,'CPU lease expired');log=self.D/(label+'.log');reap=self.D/(label+'-REAPER.json');need(not log.exists()and not reap.exists(),'stage already exists')
  cmd=[sys.executable,PLAN['reaper']['path'],str(reap),'--','nice','-n','19','taskset','-c',PLAN['cpu'],*argv];start=time.monotonic();stop=None;minimum={'workspace':shutil.disk_usage('/workspace').free,'tmp':shutil.disk_usage('/tmp').free}
  with log.open('x')as out:
   proc=subprocess.Popen(cmd,cwd=self.F,env=self.E,stdout=out,stderr=subprocess.STDOUT)
   while proc.poll()is None:
    try:
     floors();need(time.monotonic()-start<limit and time.monotonic()<self.deadline,'native stage/lease timeout')
     self.guard()
     minimum={k:min(v,shutil.disk_usage('/workspace'if k=='workspace'else'/tmp').free)for k,v in minimum.items()}
    except Exception as e:stop=str(e);proc.send_signal(signal.SIGTERM);break
    time.sleep(.5)
   proc.wait(timeout=20)
  r=json.loads(reap.read_text());row={'at':now(),'stage':label,'argv':cmd,'seconds':time.monotonic()-start,'exit':proc.returncode,'native_exit':r['command_exit'],'all_children_reaped':r['all_children_reaped'],'stop_reason':stop,'minimum_free':minimum};save(self.D/(label+'-RESULT.json'),row);print(json.dumps(row),flush=True)
  need(proc.returncode==0 and r['command_exit']==0 and r['all_children_reaped']and stop is None,'native stage failed; retain all actual outputs');floors();self.guard(True);return row
 def family(self):
  code='''import sys,json;from pathlib import Path;sys.dont_write_bytecode=True;sys.path.insert(0,"generators");import mesh_inputs
out={}
for p in sorted(Path("data/structures").glob("*.json")):
 r=json.loads(p.read_text())
 for ph in r["phases"]:out[r["id"]+":"+ph["id"]]=mesh_inputs.structure_inputs_sha(r,ph,"bridge_timber")
print(json.dumps(out))'''
  got=json.loads(subprocess.check_output([sys.executable,'-c',code],cwd=self.F,env=self.E,text=True));want={r['id']+':'+r['phase']:r['proposed_native_recipe_EXPECTED_NOT_BUILT']for r in PLAN['family']};need(got==want,'actual fixture native recipes differ');save(self.R/'NATIVE-RECIPES.json',got)
  names=[r['asset']for r in PLAN['family']]
  for n in names:
   q=self.F/'assets/gltf'/n;need(q.is_symlink()and q.resolve()==A/'assets/gltf'/n,'selected output slot unsafe');q.unlink();need(not(self.F/'assets/web'/n).exists(),'WEB output slot occupied')
  wrote=self.R/'WROTE.txt';build=self.stage('BUILD6',[PLAN['blender'],'--background','--factory-startup','--threads',str(PLAN['threads']),'--python-exit-code','1','--python-expr','import sys;sys.dont_write_bytecode=True','--python',str(self.F/'generators/build.py'),'--','--only',','.join(r['id']for r in PLAN['family']),'--wrote',str(wrote)],90)
  actual=wrote.read_text().splitlines();need(len(actual)==6 and len(set(actual))==6 and set(actual)==set(names),'native WROTE scope differs')
  web=self.stage('WEB6',['bash','tools/web_derivatives.sh','--only',','.join(actual)],120);out={x:json.loads((self.F/x).read_text())for x in PLAN['regs']}
  for rel,key in [('assets/manifest.json','assets'),('assets/manifest.web.json','masters')]:
   a=self.before[rel];b=out[rel];need(set(a[key])==set(b[key]),'registry keys changed');need({k:v for k,v in a[key].items()if k not in names}=={k:v for k,v in b[key].items()if k not in names},'foreign registry row changed');need({k:v for k,v in a.items()if k!=key}=={k:v for k,v in b.items()if k!=key},'registry metadata changed')
  need(out['assets/manifest.versions.json']==self.before['assets/manifest.versions.json'],'versions changed');rows=[]
  for r in PLAN['family']:
   n=r['asset'];m=self.F/'assets/gltf'/n;w=self.F/'assets/web'/n;need(m.is_file()and w.is_file()and not m.is_symlink()and not w.is_symlink(),'selected output not owned regular');e=out['assets/manifest.json']['assets'][n]
   need(e['inputs_sha256']==r['proposed_native_recipe_EXPECTED_NOT_BUILT']and e['bytes']==m.stat().st_size and out['assets/manifest.web.json']['masters'][n]==sha(m),'native registry binding incorrect')
   if r['role']=='default_control':
    for q,b in[(m,r['MASTER']),(w,r['WEB'])]:need(q.read_bytes()==Path(b['path']).read_bytes(),'default control bytes differ '+n)
   else:
    for q,key in[(m,'expected_candidate_MASTER'),(w,'expected_candidate_WEB')]:need(sha(q)==PLAN[key]['sha256']and q.stat().st_size==PLAN[key]['bytes'],'selected output did not reproduce exact actualV5 '+key)
   rows.append({'id':r['id'],'asset':n,'role':r['role'],'MASTER':{'sha256':sha(m),'bytes':m.stat().st_size,'mode':stat.S_IMODE(m.stat().st_mode)},'WEB':{'sha256':sha(w),'bytes':w.stat().st_size,'mode':stat.S_IMODE(w.stat().st_mode)},'native_entry':e,'native_WEB_master_binding':out['assets/manifest.web.json']['masters'][n]})
  save(self.C/'NATIVE6-ENTRIES.json',{'status':'OFFICIAL6_BUILD_WEB_PASS_FIVE_DEFAULT_EXACT_SELECTED_EXACT_V5','rows':rows,'foreign_rows_metadata_versions_exact':True})
  for r in rows:
   for sub,key in[('gltf','MASTER'),('web','WEB')]:
    q=self.F/'assets'/sub/r['asset']
    if r['role']=='selected':
     dest=self.C/('native-master'if sub=='gltf'else'native-web')/r['asset'];dest.parent.mkdir(exist_ok=True);q.rename(dest);q.symlink_to(dest)
    else:
     need(q.read_bytes()==(A/'assets'/sub/r['asset']).read_bytes(),'default restore authority changed');q.unlink();q.symlink_to(A/'assets'/sub/r['asset'])
  save(self.R/'FAMILY-CLOSED.json',{'status':'ACTUAL_OFFICIAL6_NATIVE_WEB_FIVE_DEFAULT_EXACT_SELECTED_V5_EXACT','at':now(),'stages':[build,web],'native_capture':'PENDING','original_DONE':False});self.close('FAMILY6_CLOSED_CAPTURE_PENDING')
 def capture(self):
  need((self.R/'FAMILY-CLOSED.json').exists(),'family not closed');cam=json.loads(Path(PLAN['camera']['path']).read_text());need(cam['diagnostic_only']and not cam.get('also_render'),'capture scope changed')
  d=self.F/'data/reference_views/dearborn_street_drawbridge';d.mkdir(parents=True,exist_ok=True);c=d/'earle_1902_lunette.json';need(not c.exists(),'capture already exists');shutil.copyfile(PLAN['camera']['path'],c)
  photo=(d/cam['photo']).resolve();expected=self.R/'reference/images/chicago'/Path(PLAN['photo']['path']).name;need(photo==expected,'camera-relative photo algebra wrong');expected.parent.mkdir(parents=True,exist_ok=True);expected.symlink_to(PLAN['photo']['path']);need(sha(photo)==PLAN['photo']['sha256'],'source picture differs')
  result=self.stage('PHOTO_EARLE',['node','tools/photo_match.mjs',str(c),'--out',str(self.R/'capture')],75);match=json.loads(c.with_suffix('.match.json').read_text());need(match['verdict']=='unreviewed'and match['glb_sha256']==PLAN['expected_candidate_MASTER']['sha256']and match['photo_sha256']==PLAN['photo']['sha256'],'native match binding/verdict unexpected')
  side=(self.F/match['side_by_side']).resolve();need(self.F not in side.parents and self.R in side.parents and side.is_file(),'side-by-side not retained outside disposable fixture')
  raw=[Path(x.strip())for x in(self.D/'PHOTO_EARLE.log').read_text().splitlines()if x.strip().endswith('-render.png')];need(len(raw)==1 and raw[0].is_file(),'raw native render missing');dest=self.R/'capture/earle_1902_lunette-render.png';raw[0].rename(dest);shutil.copyfile(c,dest.parent/'native-camera.json');shutil.copyfile(c.with_suffix('.match.json'),dest.parent/'native.match.json')
  save(self.R/'CAPTURE-CLOSED.json',{'status':'ACTUAL_NATIVE_FULL_BRIDGE_EARLE_CAPTURED_UNREVIEWED','at':now(),'stage':result,'raw':str(dest),'side_by_side':str(side),'native_match':match,'diagnostic_only':True,'root_review':'PENDING','matches_claimed':False,'original_DONE':False});self.close('NATIVE6_PLUS_EARLE_DIAGNOSTIC_CLOSED_UNREVIEWED')
 def close(self,status):
  self.guard(True);rows=[]
  for p in sorted(self.R.rglob('*')):
   if not p.is_file()or p.is_symlink()or self.F in p.parents or p.name=='CLOSED-MANIFEST.json':continue
   rows.append({'path':str(p.relative_to(P)),'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)})
  save(self.R/'CLOSED-MANIFEST.json',{'status':status,'at':now(),'members':rows,'bytes':sum(r['bytes']for r in rows),'fixture_and_private_scratch_excluded':True,'primary_unmodified':True})
 def retire(self):
  need(self.args.root_viewed and(self.R/'CAPTURE-CLOSED.json').exists(),'root native view and closed capture required');self.resume();m=json.loads((self.R/'CLOSED-MANIFEST.json').read_text())
  for r in m['members']:
   q=P/r['path'];need(q.is_file()and q.stat().st_size==r['bytes']and sha(q)==r['sha256']and stat.S_IMODE(q.stat().st_mode)==r['mode'],'closed authority changed')
  for q in self.D.glob('*-REAPER.json'):
   r=json.loads(q.read_text());need(r['command_exit']==0 and r['all_children_reaped'],'owned stage still active/failed')
  before=shutil.disk_usage('/workspace').free;need(self.F.parent==self.R and not self.F.is_symlink()and self.tmp==Path('/workspace/b2375-v3-tmp')and not self.tmp.is_symlink(),'retirement boundary unsafe');shutil.rmtree(self.F);shutil.rmtree(self.tmp)
  save(self.R/'FIXTURE-RETIRED.json',{'status':'OWN_FIXTURE_AND_SCRATCH_RETIRED_AFTER_CLOSED_AUTHORITY_AND_ROOT_VIEW','at':now(),'removed':[str(self.F),str(self.tmp)],'actual_reclaimed':shutil.disk_usage('/workspace').free-before,'default_restore_authority':'PLAN.json current5 primaryMASTER+WEB exact hashes/modes; native output parity proved before own duplicate unlink','code_restore_authority':'PLAN.json source/candidate file bindings; actual source Git HEAD in INITIAL.json; immutable accepted V5 postimages','unique_native_outputs_and_receipts_preserved':True});self.close('NATIVE6_EARLE_CLOSED_OWN_FIXTURE_RETIRED')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--expected-head');ap.add_argument('--rehearse',action='store_true');ap.add_argument('--family-only',action='store_true');ap.add_argument('--capture-only',action='store_true');ap.add_argument('--retire-fixture',action='store_true');ap.add_argument('--root-viewed',action='store_true');ap.add_argument('--seconds',type=int,default=330);args=ap.parse_args()
 if not args.execute and not args.retire_fixture:print(json.dumps(preflight(require_resources=not args.rehearse),indent=2));return
 need(not args.rehearse,'rehearsal cannot execute');need(os.environ.get('T2375_NATIVE_CPU')=='root-approved-frozen-native6','explicit root grant missing; no fixture created');need(0<args.seconds<=330,'bridge invocation must remain bounded to330seconds');checked_source_guard(args.expected_head);need(not(args.family_only and args.capture_only),'conflicting phases');r=Run(args)
 if args.retire_fixture:r.retire();return
 if args.capture_only:r.resume()
 else:r.setup();r.family()
 if not args.family_only:r.capture()
 print(json.dumps({'status':'ACTUAL_PHASE_CLOSED','family':str(r.R/'FAMILY-CLOSED.json'),'capture':str(r.R/'CAPTURE-CLOSED.json')if(r.R/'CAPTURE-CLOSED.json').exists()else'PENDING','original_DONE':False}))
if __name__=='__main__':main()
