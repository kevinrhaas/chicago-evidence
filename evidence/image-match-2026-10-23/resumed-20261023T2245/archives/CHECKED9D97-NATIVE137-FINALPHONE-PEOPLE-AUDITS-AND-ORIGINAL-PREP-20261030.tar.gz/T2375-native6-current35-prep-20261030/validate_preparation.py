from pathlib import Path
import ast,datetime,hashlib,importlib.util,json,os,stat,subprocess,sys
sys.dont_write_bytecode=True;os.sched_setaffinity(0,{2});os.nice(19)
P=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('bridge_current35_controller',P/'controller.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);checks=[]
def test(name,fn,fail=False):
 try:fn()
 except RuntimeError:
  assert fail,name;checks.append({'name':name,'expected_refusal':True});return
 assert not fail,name;checks.append({'name':name,'expected_refusal':False})
head='a'*40
test('valid checked source state',lambda:m.validate_checked_state(head,head,False,b''))
for name,args in [('missing checked head',(None,head,False,b'')),('malformed checked head',('wrong',head,False,b'')),('changed source head',(head,'b'*40,False,b'')),('active merge',(head,head,True,b'')),('dirty or untracked source',(head,head,False,b'?? data/not_a_fixture.json\n'))]:test(name,lambda args=args:m.validate_checked_state(*args),True)
for f in ['controller.py','prepare.py']:ast.parse((P/f).read_text())
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('T2375_NATIVE_CPU',None)
r=subprocess.run([sys.executable,str(P/'controller.py'),'--execute','--seconds','330','--expected-head',head],env=env,capture_output=True,text=True)
assert r.returncode!=0 and 'explicit root grant missing' in r.stderr and not(P/'run').exists() and not Path(m.PLAN['short_private_TMPDIR']).exists();checks.append({'name':'no CPU grant refuses before owned run or scratch','expected_refusal':True})
(P/'NO-GRANT-REFUSAL.json').write_text(json.dumps({'exit':r.returncode,'stderr':r.stderr,'run_or_private_scratch_created':False},indent=2)+'\n')
row=dict(m.PLAN['camera']);row['sha256']='0'*64;test('changed source camera refused',lambda:m.check(row),True)
row=dict(m.PLAN['candidate_record']);row['sha256']='0'*64;test('changed accepted V5 record refused',lambda:m.check(row),True)
scratch=m.PLAN['short_private_TMPDIR'];socket_example=scratch+'/playwright_chromiumdev_profile-XXXXXX/SingletonSocket';assert len(socket_example.encode())<108
# Recheck closed old Bridge/Jail payloads without altering any file or primary Git state.
sets=[('/workspace/T2375-native6-controller-20261030','CLOSED-V2-MANIFEST.json'),('/workspace/T2380-corrected-reconstruction-v3-20261030','CLOSED-MANIFEST.json'),('/workspace/T2380-actual-one-keeper-closure-20261030','CLOSED-MANIFEST.json')];exact=[]
for folder,manifest in sets:
 base=Path(folder);doc=json.loads((base/manifest).read_text())
 for row in doc['files']:
  q=base/row['path'];b=q.read_bytes();mode=stat.S_IMODE(q.stat().st_mode);wanted=row['mode'];wanted=int(wanted,8)if isinstance(wanted,str)else wanted
  assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']and mode==wanted;exact.append({'path':str(q),'bytes':len(b),'sha256':row['sha256'],'mode':mode})
(P/'IMMUTABLE-OLD-PACKETS-RECHECK.json').write_text(json.dumps({'all_exact':True,'files':exact},indent=2)+'\n')
result={'status':'CURRENT35_BRIDGE_CONTROLLER_PREPARATION_GUARDS_PASS_NATIVE_UNRUN','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'syntax_pass':2,'all_six_full_current_and_proposed_recipe_docs_and_mesh_bindings_exact':True,'selected_expected_MASTER':m.PLAN['expected_candidate_MASTER'],'selected_expected_WEB':m.PLAN['expected_candidate_WEB'],'actual_future_expected_head_not_guessed':True,'scaffold_regular_bytes':m.PLAN['scaffold_regular_bytes'],'unchanged_start_reserve':m.PLAN['start_extra_reserve'],'workspace_floor':m.PLAN['workspace_floor'],'shared_TMP_floor':m.PLAN['tmp_floor'],'short_TMP':scratch,'socket_example':socket_example,'socket_example_bytes':len(socket_example.encode()),'all_old_bridge_Jail_V3_actual_closure_files_exact':len(exact),'native_or_browser_or_fixture_launched':False,'primary_source_Git_index_ref_or_ticket_mutations':False,'CPU_affinity':sorted(os.sched_getaffinity(0))};(P/'VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['checks','selected_expected_MASTER','selected_expected_WEB']},indent=2))
