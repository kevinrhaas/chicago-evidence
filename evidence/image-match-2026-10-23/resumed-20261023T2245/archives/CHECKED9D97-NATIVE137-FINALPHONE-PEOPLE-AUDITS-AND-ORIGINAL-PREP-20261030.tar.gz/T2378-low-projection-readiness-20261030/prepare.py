"""One existing-parameter low projection; CPU analysis only, no native mesh/render."""
import copy,dataclasses,difflib,hashlib,json,math,os,pathlib,sys
os.sched_setaffinity(0,{2});sys.dont_write_bytecode=True
P=pathlib.Path(__file__).parent;A=pathlib.Path('/workspace/chicago/chicago/4d')
BASE=pathlib.Path('/workspace/T2378-native-main-prototype-run-20261030')
SID='jb_beaubien_homestead';SRC='kinzie_1857_chicago_1831_panorama'
sha=lambda q:hashlib.sha256(pathlib.Path(q).read_bytes()).hexdigest()
enc=lambda d:json.dumps(d,indent=2,ensure_ascii=False)+'\n'
def emit(n,d):(P/n).write_text(enc(d))
base_path=BASE/'closed-authority/candidate'/f'{SID}.json'
base=json.loads(base_path.read_text());candidate=copy.deepcopy(base);ph=candidate['phases'][0];form=ph['form']
camera=BASE/'closed-authority/native-camera.json';cam=json.loads(camera.read_text())
assert sha(base_path)=='84254184e0292df0dea99079557a5f346d76d6697f1efe47d2fcbac5eb56ed12'
assert sha(camera)=='c914ab0a92c25ec883121a23b81441406935f46415687218725d3e0fcca9f134'
guardpaths=[base_path,camera,BASE/'RESULT.json',BASE/'CLOSED-MANIFEST.json',BASE/'closed-authority/NATIVE-ENTRIES.json',
 A/'generators/archetypes/log_dwelling.py',A/'generators/archetypes/log_dwelling_params.py',A/'generators/mesh_inputs.py',A/'data/structures.schema.json',A/'data/sources'/f'{SRC}.json',
 pathlib.Path('/workspace/T2378-role-inspection-root-20261030/source-inspection-only.png'),
 pathlib.Path('/workspace/T2378-readiness-bd316-20261024/known-ticket-whole-panorama.jpg')]
before={str(q):sha(q)for q in guardpaths}
ph['footprint']['polygon']=[[0,0],[12.192,0],[12.192,6.096],[9.144,6.096],[9.144,8.096],[3.048,8.096],[3.048,6.096],[0,6.096]]
ph['footprint']['note']+='\n\nT-2378 ONE UNRENDERED LOW-PROJECTION PROPOSAL: the accepted main core remains exactly12.192x6.096m at its existing origin. Expand only the total reconstructed depth to8.096m and use the stepped union of that core with one centered6.096x2.0m projection beyond its max-v/front wall. Native frame_addition/front subtracts the stated2m from total depth, recovering the exact accepted6.096m core rather than shrinking it. Every attachment dimension/location is reconstructed picture-relative geometry, not a historic plan or survey. The earlier factory-derived size rationale is not revived as evidence. Dates and main-core world placement remain unchanged.'
def field(k,v,note,confidence='reconstructed'):
 assert k not in form
 form[k]={'value':v,'confidence':confidence,'sources':[SRC],
 'note':'T-2378 ONE UNRENDERED LOW-PROJECTION PROPOSAL: '+note}
field('frame_addition',True,'Use existing native front-frame massing as a declared proxy for the visible low roofed projection, with no claim that the unseen structure was frame or that a dated addition event is known. This is an appearance component in the existing phase, not a new invented construction date.')
field('frame_addition_side','front','The lower mass is placed on the accepted visible longwall/max-v side. Its centered physical placement can project left under the accepted oblique camera; do not infer a true plan offset from image offset alone.')
field('frame_addition_width_m',6.096,'Choose half the accepted12.192m main frontage as one graphic-width proxy. Existing addition_extent centers it at u3.048..9.144; no source measures either number.')
field('frame_addition_depth_m',2.0,'Choose one2.0m projection beyond corev6.096; the expanded total footprint depth8.096 minus2.0 preserves main core depth6.096 exactly. Depth is reconstructed from one visible roof plane, not a recovered room plan.')
field('frame_addition_stories',1,'One low storey is the bounded interpretation of the lower wall/roof mass; exact floor plan and use are not supplied by the picture.','inferred')
field('frame_addition_height_m',3.0,'Choose3.0m lower eave, about60percent of the accepted5m main eave, as one picture-relative proxy. It is not a measured historic height. It does not alter the accepted main wall height.')
field('frame_addition_roof_pitch_deg',40.0,'Choose40degrees for one lower roof plane, below the main50degree pitch. The native addition is gabled alongu; its unshown back slope and attachment are reconstruction choices, not proven by the one visible painted plane. The projected high roof edge remains a recorded comparison uncertainty; no match is claimed.')
field('frame_addition_cladding','clapboard','Use the existing unpainted clapboard frame surface as a reconstructed implementation choice. Monochrome light tone attests neither white paint nor historic cladding; the main log material is unchanged.')
field('frame_paint','unpainted','Retain the native unpainted frame default explicitly. No white paint is inferred from the print.')
sys.path.insert(0,str(A/'generators'));import mesh_inputs
from archetypes.log_dwelling_params import core_extent,addition_extent,resolved_core_ridge_axis,front_openings
bp=mesh_inputs.resolve_params('log_dwelling',base['phases'][0],base);p=mesh_inputs.resolve_params('log_dwelling',ph,candidate);p.validate()
assert core_extent(bp)==core_extent(p)==(0.,0.,12.192,6.096)
assert addition_extent(p)==(3.048,6.096,9.144,8.096)
for k in ['stories','wall_height_m','roof_pitch_deg','chimneys','chimney_ridge_at']:
 assert form[k]==base['phases'][0]['form'][k]
assert ph['position']==base['phases'][0]['position']and ph['documented_range']==base['phases'][0]['documented_range']
assert {k:v for k,v in candidate.items()if k!='phases'}=={k:v for k,v in base.items()if k!='phases'}
assert p.chimney_ridge_at==bp.chimney_ridge_at and p.chimneys==bp.chimneys==2
assert resolved_core_ridge_axis(p)==resolved_core_ridge_axis(bp)=='x'
import jsonschema
jsonschema.Draft202012Validator(json.loads((A/'data/structures.schema.json').read_text())).validate(candidate)
assert mesh_inputs.structure_inputs_sha(base,base['phases'][0])=='f8d59ea8ca88e0d49f8d81bd4b16aac6886e2ee509e0da075544b3a82f72eeb2'
doc=mesh_inputs.structure_inputs_doc(candidate,ph);recipe=mesh_inputs.structure_inputs_sha(candidate,ph)
def project(q):
 v=[q[i]-cam['eye'][i]for i in range(3)];right,up,forward=cam['basis_right_up_forward'];depth=sum(v[i]*forward[i]for i in range(3));assert 250<depth<500
 return [cam['principal_px'][0]+cam['focal_px']*sum(v[i]*right[i]for i in range(3))/depth,
         cam['principal_px'][1]-cam['focal_px']*sum(v[i]*up[i]for i in range(3))/depth,depth]
ax0,ay0,ax1,ay1=addition_extent(p);az=p.addition_height_m;ym=(ay0+ay1)/2;ridge=az+((ay1-ay0+.5)/2)*math.tan(math.radians(p.resolved_addition_roof_pitch_deg))
roof=[[ax0-.25,ay1+.25,az],[ax1+.25,ay1+.25,az],[ax1+.25,ym,ridge],[ax0-.25,ym,ridge]]
pixels=[project(q)for q in roof];wall=[[ax0,ay1,0],[ax1,ay1,0],[ax1,ay1,az],[ax0,ay1,az]]
source_roi={'inspection_only_px':[90,245,280,355],'original_whole_source_px':[207.5,386.25,255,413.75],
 'manual_feature_uncertainty_px':8,'not_homologous_corner_residuals':True,
 'inspection_to_original':'Supplied580x520inspection corresponds to originalcrop[185,325,330,455]at4x; source-only registration correlation0.99944052 verifies pixel location, not a model camera fit.'}
emit('ANALYTIC-PROJECTION-NOT-RENDER.json',{'method':'ONE existing-parameter polygon projection only, under fixed native camera; not a mesh/render/camera solve',
 'core_extent_old_and_new':core_extent(p),'core_world_position_unchanged':True,'main5attrs_and_two_mainridge_stacks_unchanged':True,
 'addition_extent':addition_extent(p),'lower_eave_m':az,'lower_ridge_estimate_m':ridge,'roof_front_plane_model_uvheight':roof,
 'roof_front_plane_original_image_px_depth':pixels,'front_wall_original_image_px_depth':[project(q)for q in wall],
 'roof_bbox_px':[[min(q[i]for q in pixels)for i in range(2)],[max(q[i]for q in pixels)for i in range(2)]],
 'source_manual_ROI_not_a_survey':source_roi,'centering_role':'Centered u6.096 front roof projects LEFT of the main body because advancingv moves left under the accepted NW oblique. Thus screen offset alone does not require a true offset control.',
 'remaining_form_uncertainty':'Native lower gable ridge/back-slope differs from the only visible painted plane; projected high edge sits below the broad source high-roof ROI. That gap and overlap must be honestly reviewed in a later single native comparison; no analytic acceptance/matches verdict.',
 'implicit_native_side_effect':'Front addition takes exterior doorway to its front planev8.096 and replaces hidden core ground doorway with a window. Uncovered upper core band remains; lower door/two-light defaults are reconstructed, not source opening counts.',
 'generic_offset_code_needed_for_this_proposal':False,'candidate_count':1,'new_native_build_WEB_photo_or_primary_write':False})
dest=P/'candidate/data/structures'/f'{SID}.json';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(enc(candidate));(P/'CONTROL-CAMERA.json').write_bytes(camera.read_bytes());emit('NATIVE-RECIPE.json',doc)
(P/'PROPOSAL.diff').write_text(''.join(difflib.unified_diff(base_path.read_text().splitlines(True),enc(candidate).splitlines(True),fromfile='accepted-main-prototype/jb_beaubien_homestead.json',tofile='ONE-low-projection-proposal/jb_beaubien_homestead.json')))
emit('PARAM-VALIDATION.json',{'native_from_phase_validate':'PASS','structure_schema':'PASS','native_recipe_sha256':recipe,'resolved_params':dataclasses.asdict(p),'main_core_preservation':'PASS','base_native_recipe_still_exact':'f8d59ea8ca88e0d49f8d81bd4b16aac6886e2ee509e0da075544b3a82f72eeb2','front_contract':front_openings(p),'new_shared_code':False,'native_execution':False})
assert before=={str(q):sha(q)for q in guardpaths}
emit('BINDINGS.json',{'guards':before,'all_exact_after':True,'candidate_record_sha256':sha(dest),'camera_sha256':sha(camera),'native_recipe_sha256':recipe,'one_proposal_only':True,'root_review_accepted_main_only':True,'raw_native_main_match_unchanged_unreviewed':True,'no_primary_Git_ticket_site_write':True,'native_candidate_build_or_photo_run':False})
print('PASS ONE data-only centered low projection proposal; main core/camera/5attrs exact; native schema/params checked; no native execution; recipe '+recipe)
