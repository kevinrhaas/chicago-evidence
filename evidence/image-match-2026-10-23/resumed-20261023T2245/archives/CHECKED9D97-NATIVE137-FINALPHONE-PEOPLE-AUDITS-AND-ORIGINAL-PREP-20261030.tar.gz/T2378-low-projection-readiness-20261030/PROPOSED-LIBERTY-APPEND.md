
Additional proposed lower-projection qualification for L-beaubien-tall-main-block-2378:

Root directly reviewed the actual selected native main prototype and accepted
its taller mass, steeper roof, two main ridge stacks and visible face roles as an
inferred graphic working form. That acceptance does not confirm metric values,
identity, bearing or a whole-house match. The native raw match remains unreviewed.

ONE further data-only proposal uses the existing centered front-frame option:
6.096m width×2.0m depth, one low level with3.0m eave/40° roof and unpainted
clapboard as a reconstructed surface proxy. These numeric/layout/material choices
are not measured in the source. The overall reconstructed footprint expands to
8.096m depth with a stepped occupied union, while the main core remains exactly
12.192×6.096m at its existing origin,5m eave,50° roof and both accepted stacks.
The fixed camera projects this physically centered projection leftward, so its
image offset alone does not prove an asymmetric plan.

The full lower native gable supplies an unseen back slope that the illustration
does not establish. Its high-edge overlap differs from a broad, uncertain source
roof region and remains an explicit comparison question. Native lower door/window
defaults and the displaced exterior approach are reconstructed side effects, not
attested counts or a recovered interior. No white paint, new building date, main
roof/stack revision, Factor House description, historic viewpoint, structure grade
or whole-picture acceptance follows. The single proposal is UNRENDERED; actual
source matching, application/ground/access qualification and original closure
remain pending in T2378, with no new follow-up ticket.
