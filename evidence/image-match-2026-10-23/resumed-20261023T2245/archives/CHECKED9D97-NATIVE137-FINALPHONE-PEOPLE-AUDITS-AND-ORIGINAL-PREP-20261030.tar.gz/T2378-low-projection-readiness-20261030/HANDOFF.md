# Main mass accepted; one existing-parameter lower projection prepared

`ROOT-MAIN-REVIEW.json` records the coordinator's direct review of the actual
native full-source comparison and raw render. The taller two-level main mass,
steeper right gable and two main ridge stacks are accepted as an inferred graphic
working form. Metric values remain reconstructed, not confirmed measurements.
The raw native match and the166-file actual native closure remain unchanged and
UNREVIEWED; no whole-house matches, identity/grade promotion or ticket closure is
claimed. The lower front projection remains the explicit over-bar visible gap.

The earlier fixed-outer-bbox limitation is now superseded by the coordinator's
permission to expand ONLY the reconstructed outer footprint. Existing native
`core_extent` subtracts front addition depth from total depth, so total8.096m
minus2.0m recovers the exact accepted6.096m main depth. Main width12.192m, existing
origin/world placement, wall5.0m, pitch50°, stories2, both ridge stacks/fractions
0.16/0.84, and camera `c914ab0a…` remain unchanged controls. No further main height,
stack or camera trial is made.

## One proposal, not a parameter grid

Use existing `frame_addition` on `front`, centered width6.096m, depth2.0m,
one lower storey, eave3.0m, lower roof40°, unpainted clapboard default. Exact
width/depth/eave/pitch/centering/material are declared reconstructed choices;
one low level is a conditional visual inference. This describes appearance in
the existing phase, not a newly dated construction event or a recovered room
plan. No white paint is attested from the monochrome drawing; the main log
material stays unchanged. The source's actual hidden rear roof/attachment and
material are unknown.

The new occupied footprint is an8-vertex stepped union of the EXACT retained
12.192×6.096m core and centered front rectangleu3.048..9.144,v6.096..8.096. It does
not fill the outer front corners as occupied building. Native `addition_extent`
actually returns those coordinates; native `core_extent` remains exactly
(0,0,12.192,6.096). This corrects the earlier assumption that the old total depth
had to remain fixed. Schema/from_phase/validate passed, and the basef8d59 recipe
still reproduces its closed native input document. New proposal recipe:
`07f063c40fe23964a032433a0748237ab0d86e8ef5ff09f7435e1bd8b3d9b93b`.

## Analytic role and source polygon

Only one proposed parameter set was projected. Under the FIXED accepted oblique
camera, moving the centered addition forward in+v moves it LEFT on screen. Its
front roof plane projects into original pixels approximatelyx204.8..246.0,
y405.1..414.2; its front wall extends down to the existing ground neary440.
This is a real geometric explanation for apparent left offset without a true
asymmetric-plan control. The full per-corner uv/height/pixel/depth values are in
`ANALYTIC-PROJECTION-NOT-RENDER.json`.

The provided source inspection is the original region[185,325,330,455]at4×.
An in-memory source-only registration returned correlation0.99944, confirming
pixel location rather than a model camera fit. A coarse by-eye lower-roof region
isx207.5..255,y386.25..413.75, with roughly8px feature uncertainty. This region is
NOT a set of homologous corners, and includes an uncertain high/back edge and
overlap with the taller block. The proposed low front eave and horizontal role
are plausible, but the native gable's high edge is below that broad source
region. That roof/attachment uncertainty is explicitly UNRESOLVED, not fitted
away, measured in historical metres, or declared within tolerance by arithmetic.

The source only shows a visible roof plane; the native front addition supplies
a full gable with a reconstructed hidden back slope. This packet therefore
offers one existing-parameter trial, not source proof that the lower roof was
gable-shaped. Root may inspect it in one later scheduled native comparison and
accept/reject that proxy. No new generic offset control is justified by screen
offset alone, and no shared producer implementation/design or new main-mass
trial is proposed here.

There are known native side effects. The addition takes the exterior doorway
from corefrontv6.096 to projectionfrontv8.096, while the old hidden core ground
door becomes a default window behind the projection. Default lower door/two-light
and uncovered upper-window bands remain reconstructed, not newly attested opening
counts. Native chimney_ridge_at returns before addition-stack dispatch, so BOTH
accepted stacks stay on the main roof and no third lower stack is introduced.
Future ground, approach, footprint/props and source opening review are still owed.

## Scope and next execution

`candidate/data/structures/jb_beaubien_homestead.json` is the only new proposal.
`PROPOSAL.diff` is against the accepted data-only main mass84254184…, not the
old69cb one-storey record. `CONTROL-CAMERA.json` is byte-exact to the accepted
native camera. The original source image, all main5 attributes, source dates,
function/occupants, review/removal flags and existing identity qualifications are
unchanged. Existing first/second house distinctions and the Factor House140m
away remain; no two-storey Factor description is borrowed.

All work here was light CPU2 preparation. No fixture, native build/WEB, browser,
capture, primary/Git/ticket/site write or match record edit ran. Any next selected
native prototype/WEB/fixed-camera comparison requires a later root schedule and
grant after its current integration work; no automatic loop or second parameter
set follows from this packet. The raw actual main prototype is preserved and
should be banked in checkpoint724; its private fixture remains retained until
durable verification and root retirement instruction. This packet should join
the next substantive checkpoint. No new photo ticket or split is created.
