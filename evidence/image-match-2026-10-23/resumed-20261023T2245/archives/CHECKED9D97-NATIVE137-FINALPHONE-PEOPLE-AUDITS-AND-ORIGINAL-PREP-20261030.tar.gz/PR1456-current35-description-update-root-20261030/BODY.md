Give the Miller House its pictured low log wing beside the tall range, add Hogan’s horizontal gable courses and chimney cap, raise St Mary’s front sash, and add the credited Castelnau harbour view to the lighthouse’s Images card. Source records retain disputed dates and unresolved picture limits.

Integration repairs preserve freshly rebuilt derived files and reduce railway buffer memory through the existing compact-normal format and exact uniform confidence values. Mixed confidence buffers retain their original representation. Native geometry, confidence grades, bounds, materials and picking behavior are checked against their controls.

The current published head is [`9d97c819`](https://github.com/kevinrhaas/chicago/commit/9d97c8191a074a50f94576195614a16f55345a9f), with genuine parents `430557a7` and dev `35efd899`.

- **1,105 source checks passed in 804.789 s** on the exact committed tree; all source/configuration guards and reapers passed. Native PR questions and all four original image gates passed.
- The same-head complete 1904 mobile memory gate passed at **399.273 MiB / 400 MiB**, using the unchanged official meter and ceiling, with no page errors and all children reaped.
- The native commit, tree, parents and all **137 changed paths** were independently verified through immutable GitHub readback.
- Fresh 1835 Inspect People checks passed for all four targets on desktop and mobile: eight captures, no page/network errors, correct native content and links. All eight captures were directly reviewed. Mobile Hogan/Mary captures are scrolled and their sticky header occludes leading rows; full names/order/link IDs are covered by DOM assertions, not a claim that every row fits simultaneously.
- Target picture tiles equal a pure native projection of the actual tracked parent inputs and the current published outputs. All selected target library/STORE credits, rights and source joins remain exact.

Earlier desktop/mobile geometry and Images evidence is reused with seven explicit consumer qualifications: inactive 1835 street-tree, railway and front-yard paths; the active elm crop/atlas adjustment plus an unused tree architecture entry; the raycast near-plane fallback/oracle correction; the updated Inspect consumer covered by fresh People checks; and the 1904 people-view change, inactive in the existing 1835 People drawer. This does not claim a fresh complete desktop/mobile matrix, a fresh 1904 staff-directory visual review or frame-rate measurement.

Uniform-ground confidence visual comparison covers AIR and SOUTH in nine modes with zero candidate/control pixel differences; NORTH was not run. Raw visual timeouts and inherited triangle/draw-budget failures remain disclosed. A pre-existing Census citation sanitizer changes the incoming 1900 manuscript citation’s literal “T623” text in the public projection; this inherited discrepancy is recorded, and target image credits remain exact. Failed preflight receipts are retained; no assertion or ceiling was weakened.

GitHub moving-frames and upload-release checks passed. The exact-head required source gate is still running as of 09:30 UTC. Concurrent dev work continues; normal merge remains conditional on the required check and current mergeability. The four tickets stay in review until the PR merges to `dev` and the official workflow settles them. No main/production promotion is included.

[Recovery index](https://github.com/kevinrhaas/chicago-evidence/blob/main/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md) preserves the supporting source work, qualified comparisons and negative receipts. Checkpoint 724 is durable; checkpoint 725 is collecting the current closed native-source, runtime, publication and next-ticket work.
