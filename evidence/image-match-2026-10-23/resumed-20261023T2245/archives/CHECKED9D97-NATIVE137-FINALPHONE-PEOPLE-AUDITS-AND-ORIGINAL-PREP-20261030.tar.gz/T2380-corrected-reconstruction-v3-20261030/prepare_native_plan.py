from pathlib import Path
import copy,datetime,hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True;os.sched_setaffinity(0,{2});os.nice(19)
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');B=Path('/workspace/T2380-native-one-keeper-v2-prep-20261030');old=json.loads((B/'PLAN.json').read_text());plan=copy.deepcopy(old);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();bound=lambda p:{'source':str(p),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777),'sha256':h(p)}
sys.path.insert(0,str(A/'generators'));import mesh_inputs
cache={};original_sha=mesh_inputs._sha_file
mesh_inputs._sha_file=lambda p:cache.setdefault(str(p),original_sha(p))if str(p)not in cache else cache[str(p)]
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
new=module('corrected_keeper_params',P/'postimages/generators/archetypes/frame_dwelling_params.py');prior=module('negative_keeper_params',Path('/workspace/T2380-compound-readiness-20261030/implementation/postimages/generators/archetypes/frame_dwelling_params.py'))
digest=lambda doc:hashlib.sha256(json.dumps(doc,sort_keys=True).encode()).hexdigest();new_builder=h(P/'postimages/generators/archetypes/frame_dwelling.py');old_builder=old['expected_keeper_recipe_doc']['code']['archetypes/frame_dwelling.py'];current=json.loads((A/'assets/manifest.json').read_text())['assets'];family=[]
for row in old['family']:
 source=Path(row['record']['source']);assert bound(source)==row['record'];record=json.loads(source.read_text());phase=next(x for x in record['phases']if x['id']==row['phase_id']);doc=mesh_inputs.structure_inputs_doc(record,phase);assert digest(doc)==row['native_current_recipe']==current[row['master']]['inputs_sha256']
 for sub,key in [('gltf','master_sha256'),('web','web_sha256')]:assert h(A/'assets'/sub/row['master'])==row[key]
 olddoc=copy.deepcopy(doc);olddoc['params']=mesh_inputs._params_doc(prior.from_phase(phase,record));olddoc['code']['archetypes/frame_dwelling.py']=old_builder;assert digest(olddoc)==row['native_candidate_expected_recipe']
 newdoc=copy.deepcopy(doc);newdoc['params']=mesh_inputs._params_doc(new.from_phase(phase,record));newdoc['code']['archetypes/frame_dwelling.py']=new_builder;assert json.loads(json.dumps(newdoc['params']))==json.loads(json.dumps(olddoc['params']))
 family.append({**row,'native_candidate_expected_recipe':digest(newdoc)})
assert len(family)==271
record=json.loads((P/'log_jail_keeper_house.json').read_text());phase=record['phases'][0];keeper_doc=mesh_inputs.structure_inputs_doc(record,phase);keeper_doc['params']=mesh_inputs._params_doc(new.from_phase(phase,record));keeper_doc['code']['archetypes/frame_dwelling.py']=new_builder;keeper_sha=digest(keeper_doc)
copies=[];foreign=[]
for row in old['copies']:
 src=Path(row['source']);updated={**row,**bound(src)}
 if row['postimage']:
  post=P/'postimages'/row['relative'];updated['postimage']=str(post);updated['postimage_binding']=bound(post)
 elif updated['sha256']!=row['sha256']:foreign.append({'relative':row['relative'],'old_sha256':row['sha256'],'current_sha256':updated['sha256']})
 copies.append(updated)
assert all(r['relative']in{'generators/archetypes/k01_frontage.py','generators/archetypes/k08_bays.py','generators/archetypes/k13_conservatories.py','generators/archetypes/k14_yard.py','generators/archetypes/prairie_draft.py','assets/manifest.json','assets/manifest.web.json'}for r in foreign)
actual_closure={**mesh_inputs._code_shas('frame_dwelling'),'mesh_inputs.py':h(A/'generators/mesh_inputs.py'),'code_inputs.py':h(A/'generators/code_inputs.py'),'blender.pin':h(A/'generators/blender.pin')}
assert actual_closure==old['source_closure'],'A used frame input changed; stop instead of treating it as a foreign rebind'
for row in old['core_capture_inputs']:assert bound(Path(row['source']))==row
scaffold=sum(r['bytes']for r in copies)+sum(Path(r['postimage']).stat().st_size-r['bytes']for r in copies if r['postimage']);reserve=scaffold+old['largest_default_batch_master_web_bytes']+12*1024*1024
plan.update(prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='ONE_CORRECTED_KEEPER_NORTH_FACING_PROTOTYPE_AND_NATIVE_PARITY_PLAN_UNRUN',implementation_manifest=bound(P/'IMPLEMENTATION-CLOSED-MANIFEST.json'),candidate=bound(P/'log_jail_keeper_house.json'),copies=copies,family=family,expected_keeper_recipe_doc=keeper_doc,expected_keeper_recipe_sha256=keeper_sha,prototype_camera=bound(P/'gale_1902-one-corrected-compound-candidate.json'),regular_scaffold_bytes=scaffold,future_extra_fs_envelope_bytes=reserve,refresh_scope={'source_plan':str(B/'PLAN.json'),'foreign_rows_rebound_after_parent_new_dev':foreign,'all271_current_records_MASTER_WEB_and_current_recipes_exact':True,'all271_default_params_exact_to_priorNone':True,'all271_candidate_recipes_recomputed_new_builder_SHA':True,'source_recipe_closure_unchanged':True,'new_native_bake_or_capture':False})
plan['master_read_links']=[{'relative':str(p.relative_to(A)),'source':str(p),'bytes':p.stat().st_size}for p in sorted((A/'assets/gltf').rglob('*.glb'))]
plan['current_registry_sha256']={name:h(A/'assets'/name)for name in ['manifest.json','manifest.web.json','manifest.versions.json']}
(P/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n');(P/'BASELINE271.json').write_text(json.dumps({'assets':family},indent=2)+'\n')
print(json.dumps({'family_current_exact':271,'native_keeper_new_recipe':keeper_sha,'prior_negative_keeper_recipe':old['expected_keeper_recipe_sha256'],'new_builder_SHA':new_builder,'foreign_current_rows_refreshed':foreign,'future_extra_fs_envelope_bytes':reserve,'no_fixture_Blender_browser':True},indent=2))
