# One corrected north-facing keeper reconstruction — native run pending

This is the parent's single bounded reconstruction proposal after the actual first keeper capture failed framing review. It changes only external candidate files. No primary source, Git/index/ref, scene, asset registry, ticket or PR was written. No new native MASTER, WEB derivative, browser or capture was produced.

The original negative e6135117 MASTER/a72e2282 WEB and every raw receipt/image remain preserved in the closed actual-output packet. The diagnostic proves both clipping and reversed source-facing role order; it does not measure the historic house or accept its height.

## Corrected assignments

The keeper remains north-facing at bearing0, with the same6.4×4.6m footprint,2.65m eaves,25° roof and all other chosen sizes/finishes. Its trial southwest moves from7.8m west of the fixed jail to **7.8m east**, giving local[473.31,−274.57] and core offset[−7.8,0]. This is a reconstructed trial distance/direction, not a survey or historical compass claim. The existing jail, palisade, streets and other buildings do not move. The partly-enclosed relationship and low hung gate remain open.

Only `picture_layout="keeper_gale_1902"` changes: the special gable is **east/uMax**, local front stations become D/W/W so the visible north facade reads **W/W/D**; the same reconstructed stack moves near the pictured end, and the low front rail moves to the window side while clearing the door's safety band. Two east ground sash, one small loft light, four gable shutter leaves, one stack and six rail boxes remain. Numeric set-out/compass/layout choices and source1836 versus July1835 continuity stay explicitly reconstructed. No story, height, opening-count or source-rights promotion is made.

The two full producer proposals are beside diffs from both the negativeV2 postimages and current untouched primary. All271defaultNone phases preserve their old values, confidence floats, facade/entrance API and native gable primitive call trace under **1,646 actual pure checks**. These are not native mesh-parity claims.

## One physical camera

`gale_1902-one-corrected-compound-candidate.json` is the only camera proposal. The source page is unchanged/unmirrored, focal1500px and1.7m eye height remain conventions. A single rough three-corner cue set on the directly inspected1853×2741 scan (about30–40px reading uncertainty) sets a fixed face-span azimuth; one closed-form positive-depth equation sets distance. There is no optimizer, repeated solve or native trial.

The proposed northeast angle is32.9076°; keeper-frame eye is[20.2200,30.9012,1.7], principal[612.6276,995.0832], with the physical quarter-roll retained. Analytical massing/palisade-envelope bounds x472.877..700.291/y581.899..1232.218 lie within1112×1645, depths29.089..42.134m. This bound uses an analytical reflection of the negative native keeper's massing vertices only; no handcrafted or new GLB is emitted. Corrected source-facing W/W/D, gable-left and compound-right are analytically consistent. Actual appearance, source fit, partly-enclosed relation and all remaining gaps still need direct native review. No historic camera station or metric fit is claimed.

## Native execution plan and limits

New keeper native recipe: **cbc1246652fa64234391b08cde5701e910d545540112a22962bbf2c2da6067ea**. The complete expected document is in PLAN.json. All271 current records, MASTER/WEB bytes and current native recipes remain exact; all271 new expected recipes were recomputed with the new builder SHA. No default model is restamped. Every default still owes actual native MASTER+officialWEB byte parity before source adoption.

Incoming unrelatedK13/K14 producer snapshots and current registry snapshots are rebound explicitly; the complete used frame source closure remains exact. The first planner stopped on the newly encountered unusedK14 rather than silently accepting it; that receipt is retained. An initial pure entrance comparison also stopped on floating representation of.95; it now compares the same value within1e−12m arithmetic precision. No image, memory, source or acceptance threshold changed.

The executable controller is byte-for-byte the guarded V2 controller. `--expected-head` must be the parent's actual clean checked40hex source commit, with no MERGE_HEAD, before any fixture exists and throughout native stages. Future extra filesystem reserve is **18,805,437B**, above unchanged workspace536,870,912B/sharedTMP1,800,000,000B floors. Owned workspace TMP/XDG, CPU3,4/threads2,540s bound, official producers and reapers remain enforced. The read-only rehearsal asserts inputs only and truthfully does not claim current execution resource readiness while the parent may use transient scratch.

After the parent grants a new source/CPU phase:

```bash
source /workspace/shared/resume-chicago-env.sh
T2380_NATIVE_CPU=root-approved-after-phone-and-firstfort PYTHONDONTWRITEBYTECODE=1 python /workspace/T2380-corrected-reconstruction-v3-20261030/controller.py --execute --phase keeper --seconds 540 --expected-head ACTUAL_CHECKED40HEX
```

This must generate one genuine keeper MASTER, its official WEB and one full-Gale compound capture, then stop for direct parent review. Do not run271default controls before that review. No canonical adoption, grade/matches verdict, new photo ticket or originalT2380 completion is claimed.
