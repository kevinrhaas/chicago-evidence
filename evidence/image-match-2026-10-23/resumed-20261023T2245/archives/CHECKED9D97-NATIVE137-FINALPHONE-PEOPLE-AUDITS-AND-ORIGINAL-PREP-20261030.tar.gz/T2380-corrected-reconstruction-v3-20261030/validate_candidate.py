"""Bounded pure-Python validation; no Blender/browser/app writes, no pycache."""
from __future__ import annotations
import ast, dataclasses, hashlib, importlib.util, json, math, pathlib, sys, os
os.sched_setaffinity(0,{2});os.nice(19)
sys.dont_write_bytecode=True
R=pathlib.Path('/workspace/chicago/chicago/4d');O=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(R/'generators'))
def module(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m
old=module('jail_before_params',R/'generators/archetypes/frame_dwelling_params.py')
new=module('jail_after_params',O/'postimages/generators/archetypes/frame_dwelling_params.py')
from mesh_inputs import _params_doc
checks=[];results=[]
def check(label,condition):
 checks.append({'label':label,'pass':bool(condition)})
 if not condition:raise AssertionError(label)
# The real current family, including version records, not synthetic mirror tests.
records=[]
for f in sorted((R/'data/structures').glob('*.json')):
 d=json.loads(f.read_text())
 if d.get('archetype')=='frame_dwelling':
  for ph in d['phases']:records.append((f.name+':'+ph['id'],d,ph))
for f in sorted((R/'data/structures/versions').glob('*/*.json')):
 d=json.loads(f.read_text());sid=f.parent.name;base=R/'data/structures'/f'{sid}.json'
 if base.exists():
  b=json.loads(base.read_text())
  if b.get('archetype')=='frame_dwelling':
   # version may be complete structure or phase overlay; only actual phase docs.
   if d.get('phases'):
    for ph in d['phases']:records.append((str(f.relative_to(R)),d,ph))
for name,d,ph in records:
 a=old.from_phase(ph,d);b=new.from_phase(ph,d);ad=_params_doc(a);bd=_params_doc(b)
 check(name+' defaultNone',b.picture_layout is None)
 check(name+' all old fields exact',all(bd['fields'].get(k)==v for k,v in ad['fields'].items()))
 check(name+' all old derived properties exact',all(bd['inferred'].get(k)==v for k,v in ad['inferred'].items()))
 check(name+' confidence floats exact',ad['confidence']==bd['confidence'])
 check(name+' facade+entrance layout exact',old.facade_bays(a)==new.facade_bays(b) and old.front_wall(a)==new.front_wall(b))
 results.append({'phase':name,'defaultNone':True,'old_resolved_values_exact':True,'native_recipe_document_changes':ad!=bd})
record=json.loads((O/'log_jail_keeper_house.json').read_text());p=new.from_phase(record['phases'][0],record)
import jsonschema
schema=json.loads((R/'data/structures.schema.json').read_text());schema_errors=list(jsonschema.Draft202012Validator(schema).iter_errors(record))
check('candidate actual structure schema',not schema_errors)
check('candidate local D W W gives source-facing W W D',tuple(kind for _,kind in new.facade_bays(p))==('door','window','window'))
check('candidate entrance reader sees same end door',math.isclose(next(x for x in new.front_wall(p)['openings'] if x['kind']=='door')['u0'],.95-new.DOOR_W_M/2,rel_tol=0,abs_tol=1e-12))
check('candidate east gable has two distinct ground sash',len(p.keeper_gable_sash_centres)==2 and p.keeper_gable_sash_centres[1]>p.keeper_gable_sash_centres[0])
check('small loft independent of habitable halfstorey',p.stories==1 and len(p.keeper_loft_opening)==4)
# Exercise actual opt-in geometry helper call sites, with primitive recording only.
# This proves topology reaches native primitive calls; does not prove Blender output.
def builder_helpers(path):
 tree=ast.parse(path.read_text());names={'_gable_ends','_keeper_gale_gable','_keeper_front_rail'}
 nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names]
 calls=[]
 def capture(kind):
  return lambda *a,**k:calls.append({'kind':kind,'args':a[2:] if kind in ('window','fixed') else a,'kwargs':k})
 env={'math':math,'GABLE_WIN_H_M':0.70,'GABLE_WIN_W_M':0.62,'EAVE_M':0.25,'CLAPBOARD_LIP_M':0.018,'M_SHUTTER':4,'M_TRIM':2,'DOOR_W_M':new.DOOR_W_M,'openings':type('OpeningConstants',(),{'CASING_W_M':0.09}),'_window':capture('window'),'_fixed_light':capture('fixed'),'_panel':capture('shutter'),'_sash':lambda p,s,t:(min(1.25,t-s),3,3),'_stack_positions':lambda p,w:list(p.stack_x_positions)}
 code=compile(ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]+nodes,type_ignores=[])),str(path),'exec');exec(code,env);return env,calls
base_env,base_calls=builder_helpers(R/'generators/archetypes/frame_dwelling.py');next_env,next_calls=builder_helpers(O/'postimages/generators/archetypes/frame_dwelling.py')
for name,d,ph in records:
 a=old.from_phase(ph,d);b=new.from_phase(ph,d);base_calls.clear();next_calls.clear()
 for env,pa in [(base_env,a),(next_env,b)]:
  env['_gable_ends'](None,pa,pa.width_m,pa.depth_m-pa.main_depth_m,pa.depth_m,pa.wall_height_m,pa.wall_height_m+1.6,1.,1.)
 check(name+' native gable primitive trace default parity',base_calls==next_calls)
next_calls.clear();next_env['_gable_ends'](None,p,p.width_m,0,p.depth_m,p.wall_height_m,p.wall_height_m+1.2,1.,1.)
west=[c for c in next_calls if c['kind']=='window' and c['args'][0]=='x' and c['args'][1]==p.width_m]
loft=[c for c in next_calls if c['kind']=='fixed' and c['args'][0]=='x' and c['args'][1]==p.width_m]
shutters=[c for c in next_calls if c['kind']=='shutter']
check('actual new helper emits two east windows',len(west)==2)
check('actual new helper emits one east loft light',len(loft)==1)
check('actual new helper emits four gable shutter leaves',len(shutters)==4)
class Boxes:
 def __init__(self):self.boxes=[]
 def add_box(self,*a,**kw):self.boxes.append((a,kw))
boxes=Boxes();next_env['_keeper_front_rail'](boxes,p,p.depth_m,1.)
check('front low rail emitted in native primitives',len(boxes.boxes)==6)
start=.95+new.DOOR_W_M/2+.40
check('low rail clears native door safety band',min(a[0] for a,_ in boxes.boxes)>.95+(new.DOOR_W_M+.60)/2)
negative=[]
for label,changes in [('unknown control',{'picture_layout':'not_a_picture'}),('wrong storeys',{'stories':1.5}),('wrong front count',{'bays':4}),('wrong plan',{'plan':'centre_passage'}),('conflicting chapel tower',{'tower':True}),('extra stack',{'chimneys':2}),('too narrow layout',{'width_m':3.5}),('loft crosses roof',{'depth_m':3.0})]:
 q=dataclasses.replace(p,**changes)
 try:q.validate();refused=False
 except new.ParamError as e:refused=True;negative.append({'case':label,'reason':str(e)})
 check('refuse '+label,refused)
# No primary writes / no source drift. Hash only the two controlled current preimages.
source_guard=[]
original=json.loads(pathlib.Path('/workspace/T2380-compound-readiness-20261030/CURRENT-BINDINGS.json').read_text())
for row in original['files']:
 path=pathlib.Path(row['path']);same=hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'];source_guard.append({'path':str(path),'exact':same})
registry_files={'assets/manifest.json','assets/manifest.web.json'}
check('all19 owned source/model inputs exact',all(x['exact'] for x in source_guard if str(pathlib.Path(x['path']).relative_to(R)) not in registry_files))
registration=json.loads(pathlib.Path('/workspace/T2380-compound-readiness-20261030/NATIVE-ASSET-REGISTRATION.json').read_text())
master=json.loads((R/'assets/manifest.json').read_text())['assets']['log_jail__log_1833.glb']
web=json.loads((R/'assets/manifest.web.json').read_text())['masters']['log_jail__log_1833.glb']
check('jail own native registration rows exact despite concurrent foreign registry updates',master==registration['MASTER'] and web==registration['WEB_bound_master_sha256'])
result={'status':'PASS_PURE_ONLY_NATIVE_CAPTURE_UNRUN','checks':len(checks),'all_pass':all(x['pass'] for x in checks),'current_frame_family_phases':len(records),'family':results,'candidate_front':new.facade_bays(p),'candidate_gable':p.keeper_gable_sash_centres,'candidate_loft':p.keeper_loft_opening,'candidate_stack':p.stack_x_positions,'negative_cases':negative,'source_guard':source_guard,'concurrent_registry_drift':[x for x in source_guard if not x['exact']],'registry_note':'Two whole manifests changed under sole primary writer concurrent work; all19 own source/model inputs and own jail registration rows remain exact. No whole-tree freeze or unrelated manifest parity claimed.','blender_or_browser_run':False,'recipe_impact':'ALL current frame_dwelling recipes change: new None field/new empty derived properties, plus builder source bytes. Native family regeneration and MASTER/WEB byte parity remain mandatory; pure resolved/calltrace parity does not establish native output parity.'}
(O/'VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('family','source_guard')},indent=2))
