from pathlib import Path
import json,math,hashlib,struct,datetime
P=Path(__file__).resolve().parent;C=Path('/workspace/T2380-actual-one-keeper-closure-20261030');cam=json.loads((C/'native/data/reference_views/log_jail_keeper_house/gale_1902.json').read_text());W,H=cam['image_px'];f=cam['focal_px'];w,d,h=6.4,4.6,1.7
# ONE manually read rough ground-corner cue set on the original1853x2741 scan.
# These are approximate visual controls, not measured building sizes or a survey.
source={'W_front_door_end':[1158,1455],'E_front_gable_join':[1155,1885],'E_back_gable_corner':[1115,2085]};sx,sy=W/1853,H/2741;cue={k:[x*sx,y*sy]for k,(x,y)in source.items()};span=cue['E_front_gable_join'][1]-cue['W_front_door_end'][1];gable=cue['E_back_gable_corner'][1]-cue['E_front_gable_join'][1]
theta=math.atan((gable/span)*(w/d));s,c=math.sin(theta),math.cos(theta)
# Fixed azimuth from the rough face-span ratio, then the positive closed-form
# depth giving that one front span. No optimizer, repeated fit or native trial.
D=(f*c*w+math.sqrt((f*c*w)**2+(span*s*w)**2))/(2*span)
cy=cue['W_front_door_end'][1]+f*c*(w/2)/(D+s*w/2);groundx=(cue['W_front_door_end'][0]+cue['E_front_gable_join'][0])/2;cx=groundx-f*h/D
E=[w/2+D*s,d+D*c,h];R=[0,0,-1];U=[-c,s,0];F=[-s,-c,0]
cam['eye']=E;cam['principal_px']=[cx,cy];cam['yaw_deg']=(math.degrees(math.atan2(F[0],F[1]))+360)%360;cam['basis_right_up_forward']=[R,U,F]
cam['solve']='ONE UNRENDERED corrected north-facing compound reconstruction. Keeper is trial7.8m east of unchanged jail, north front local D/W/W reads pictured W/W/D, pictured gable is east/uMax and compound lies upright-right. Source full sideways1902page retained without mirror/pixel-aspect change. Fixed azimuth from ONE roughly read gable/front ground-span ratio; fixed1500px focal and1.7m eye-height conventions, positive closed-form front-span depth and principal translation. Three manually read original1853x2741 corner cues have about30-40px uncertainty. This is a finite diagnostic camera proposal, not a measured historic station or accepted source fit; inherited dimensions/heights and1936-vs-July1835continuity remain reconstructed. Core/palisade geometry unchanged; low hung gate/interface/partly-enclosed relationship and Andreas differences remain open.'
cam['solve']=cam['solve'].replace('1936-vs','1836-vs')
(P/'gale_1902-one-corrected-compound-candidate.json').write_text(json.dumps(cam,indent=2)+'\n')
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
def project(p):
 q=[a-b for a,b in zip(p,E)];z=dot(q,F);assert z>0;return [cx+f*dot(q,R)/z,cy-f*dot(q,U)/z,z]
roles=[]
for name,u in [('front-door',.95),('front-window1',3.25),('front-window2',5.2)]:
 q=project([u,4.635,1.5]);roles.append({'role':name,'ENU':[u,4.635,1.5],'raw_px':q[:2],'upright_clockwise_x':H-q[1]})
assert roles[2]['upright_clockwise_x']<roles[1]['upright_clockwise_x']<roles[0]['upright_clockwise_x']
# Pure envelope projection using the actual negative native massing vertices.
# Reflecting u is an analytical bound proxy only: NO mesh is generated/written.
b=(C/'native/assets/gltf/log_jail_keeper_house__frame_1835.glb').read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);base=20+n+8;points=[]
for prim in g['meshes'][0]['primitives']:
 a=g['accessors'][prim['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];off=base+v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',12)
 for i in range(a['count']):
  x,y,z=struct.unpack_from('<3f',b,off+i*stride);points.append([w-x,-z,y])
enc=json.loads((C/'native/data/enclosures/log_jail_palisade.json').read_text());keeper_e,keeper_n=473.31,-274.57
for run in enc['runs']:
 for e,n in run['path_local_enu_m']:
  for height in [0,3.05]:points.append([e-keeper_e,n-keeper_n,height])
pp=[project(p)for p in points];bounds=[[min(p[i]for p in pp),max(p[i]for p in pp)]for i in range(2)];assert all(0<=p[0]<=W and 0<=p[1]<=H for p in pp)
record=json.loads((P/'log_jail_keeper_house.json').read_text());primary_core=json.loads((C/'native/data/sidecars/1835/log_jail.json').read_text());core_position=primary_core['placement'];assert abs(record['phases'][0]['position']['utm_e']-447546.01)<1e-8
proof={'status':'ONE_CLOSED_FORM_PHYSICAL_CAMERA_PROPOSAL_UNRENDERED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rough_source_controls_original_px':source,'source_control_uncertainty_original_px':'about30-40px; approximate visual reading, not traced/source dimensions','controls_native1112x1645':cue,'azimuth_NE_deg':math.degrees(theta),'fixed_focal_px':f,'fixed_eye_height_convention_m':h,'closed_form_depth_m':D,'new_eye':E,'principal_px':[cx,cy],'basis':[R,U,F],'camera_is_orthonormal':all(abs(dot(a,b)-(1 if i==j else 0))<1e-12 for i,a in enumerate([R,U,F])for j,b in enumerate([R,U,F])),'source_facing_front_controls':roles,'source_order_is_W_W_D_in_upright_clockwise_reading':True,'core_offset_relative_keeper':[-7.8,0,0],'original_core_placement_unchanged':core_position,'keeper_new_UTM':record['phases'][0]['position'],'analytical_envelope_raw_px_bounds':bounds,'all_projected_envelope_depth_positive_m':[min(p[2]for p in pp),max(p[2]for p in pp)],'envelope_proxy_not_native_mesh_output':'Uses analytical u-reflection of negative native keeper vertices plus unchanged palisade endpoint heights for framing bounds only. Actual new native geometry, shading, texture/UV, default271parity and source fit remain UNRUN. No GLB written.','camera_proposals':1,'optimizer_or_fit_loops':0,'Blender_browser_or_capture_runs':0,'source_or_primary_changes':False}
(P/'ONE-CAMERA-PROOF.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:proof[k]for k in ['azimuth_NE_deg','closed_form_depth_m','new_eye','principal_px','analytical_envelope_raw_px_bounds','all_projected_envelope_depth_positive_m','camera_proposals']},indent=2))
