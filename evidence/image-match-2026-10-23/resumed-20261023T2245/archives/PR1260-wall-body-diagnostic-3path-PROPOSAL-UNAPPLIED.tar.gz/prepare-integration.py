from pathlib import Path
import json,hashlib,difflib
root=Path('/tmp/chicago-log-integration/chicago/4d');out=Path('/tmp/PR1260-wall-body-diagnostic-proposal')
replacements={
'renderers/web/js/buildings.js':[
("import { addFeet, feetPoints, packFeet } from './building-feet.js';", "import { addFeet, feetPoints, packFeet } from './building-feet.js';\nimport { buildingBodyBounds } from './building-body-bounds.js';"),
('      const sourceMaterial = Array.isArray(mesh.material) ? mesh.material[0] : mesh.material;', '      const sourceMaterial = Array.isArray(mesh.material) ? mesh.material[0] : mesh.material;\n      if (!sourceRoles.has(sourceMaterial)) sourceRoles.set(sourceMaterial, sourceMaterial.name);\n      const bodyRole = sourceRoles.get(sourceMaterial); // before batching whitens/names it'),
('  const groups = new Map();', '  const groups = new Map();\n  const sourceRoles = new WeakMap();'),
('      const entryOf = (geo) => ({ record, geo, base, factors, occludesView });', '      const entryOf = (geo) => ({ record, geo, base, factors, occludesView, bodyRole });'),
('  const localBoxes = new Map();','  const localBoxes = new Map();\n  const bodySamples = new Map();'),
('    for (const { record, geo, base, factors, occludesView } of bucket.entries) {','    for (const { record, geo, base, factors, occludesView, bodyRole } of bucket.entries) {'),
('      box.union(geo.boundingBox);','      box.union(geo.boundingBox);\n      if (record.sidecar?.attributes?.sign_pole_set_out?.value != null) {\n        let samples = bodySamples.get(record.id);\n        if (!samples) { samples = []; bodySamples.set(record.id, samples); }\n        const p = geo.getAttribute(\'position\');\n        for (let i = 0; i < p.count; i++) samples.push({ role: bodyRole,\n          point: [p.getX(i) * frame.scale, p.getY(i) * frame.scale, p.getZ(i) * frame.scale] });\n      }'),
('  let weathering = 1;','  const bodyDiagnostics = new Map();\n  for (const [id, samples] of bodySamples) {\n    bodyDiagnostics.set(id, buildingBodyBounds(registry.get(id).sidecar, samples,\n      instanceFrames.get(id).scale / 32767));\n  }\n  bodySamples.clear();\n  let weathering = 1;'),
('          max: box.max.toArray(),','          max: box.max.toArray(),\n          ...(bodyDiagnostics.has(id) ? { body: bodyDiagnostics.get(id) } : {}),')],
 'tools/smoke_renderer.mjs':[
('          wallHeight: attrs.wall_height_m?.value ?? null,','          wallHeight: attrs.wall_height_m?.value ?? null,\n          body: box.body ?? null,\n          declaredAppendage: attrs.sign_pole_set_out?.value != null,'),
('      // The box includes the roof, so height must be at least the walls and at\n      // most the walls plus a steep roof and a chimney.\n      const h = s.size[1];', '      // Full bounds still drive every size/clamp/placement guard above. A declared\n      // exterior sign needs a valid stored-position body readback, including its\n      // roof and chimney; its tall pole does not state a wall height.\n      if (s.declaredAppendage && !s.body?.valid) return true;\n      const h = s.declaredAppendage ? s.body.size[1] : s.size[1];'),
('          ? offClaim.slice(0, 5).map((s) => `${s.id} rendered ${s.size[1].toFixed(1)} m `\n            + `against a documented ${s.wallHeight} m wall`).join(\'; \')', '          ? offClaim.slice(0, 5).map((s) => `${s.id} rendered ${(s.declaredAppendage ? s.body?.size?.[1] : s.size[1])?.toFixed(1)} m `\n            + `against a documented ${s.wallHeight} m wall`\n            + (s.declaredAppendage && !s.body?.valid ? ` (${s.body?.errors?.join(\'; \') ?? \'missing body readback\'})` : \'\')).join(\'; \')')]
}
guards={};patch=[]
for rel,rs in replacements.items():
 b=(root/rel).read_bytes();s=b.decode()
 for old,new in rs:
  assert s.count(old)==1,(rel,old[:80],s.count(old));s=s.replace(old,new,1)
 a=s.encode()
 for folder,data in [('before',b),('candidate',a)]:
  f=out/folder/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 guards[rel]={'before_sha256':hashlib.sha256(b).hexdigest(),'after_sha256':hashlib.sha256(a).hexdigest(),'spans':[{'before':x,'after':y}for x,y in rs]}
 patch.extend(difflib.unified_diff(b.decode().splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
rel='renderers/web/js/building-body-bounds.js';a=(out/'candidate'/rel).read_bytes();guards[rel]={'before_sha256':None,'after_sha256':hashlib.sha256(a).hexdigest()};patch.extend(difflib.unified_diff([],a.decode().splitlines(True),fromfile='/dev/null',tofile='b/'+rel))
(out/'replacement-guards.json').write_text(json.dumps(guards,indent=2)+'\n');(out/'proposal.patch').write_text(''.join(patch))
