# Tremont: retain the pictured canonical form

Root approved withdrawing the unmerged two-storey replacement. The current WIP retains currentdev’s exact three-storey shuttered form and placement; only yellow paint and its inferred confidence differ. The smallerGale text interpretation is optional native gale-reading. No version-promotion tool, new API, new ticket or enlargement chronology is used.

Reconstruct on immutable public1290 by extracting current-corrected-source.tar.gz with its mode/hash inventory and removing exactly the three paths named deleted. The tracked patch is supplemental. The withdrawn duplicateGifford record/master/WEB are backed up here and proven byte-exact to public1290; no work is lost. The approved plan includes actual parser/input-hash guards and fresh public currentdev equality.

Canonical+Gale physical export has NOT run. The old canonicalGLB is honestly stale for new source until that pair is built. No new photo/app/native/global/preflight verdict or original ticket completion is claimed. The still-running immutable1290 matrix can certify only frozen1290, never this correctedWIP.
