from pathlib import Path
import base64,copy,dataclasses,datetime,hashlib,json,os,stat,subprocess,sys,tempfile

ROOT=Path('/tmp/tremont-picture-20261026/chicago/4d')
REPO=ROOT.parent.parent
PLAN=Path('/workspace/T2385-canonical-picture-retained-plan-20261026T1850')
OUT=Path('/workspace/T2385-picture-yellow-adoption-20261026T1900')
OLD='1290a23271b2771c77201fd17fed7cfa857ade14'
SID='tremont_house_1';MASTER=SID+'__frame_1833.glb'
OLD_VERSION='versions/'+SID+'/gifford-reading/'+MASTER
def sha(b):return hashlib.sha256(b).hexdigest()
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path]))
def save(name,obj):
    p=OUT/name;assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def atomic(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    mode=stat.S_IMODE(path.stat().st_mode)if path.exists()else 0o600
    fd,tmp=tempfile.mkstemp(dir=path.parent,prefix='.t2385-')
    with os.fdopen(fd,'wb')as f:f.write(data)
    os.chmod(tmp,mode);os.replace(tmp,path)
def jsonbytes(obj):return (json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode()

assert subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD']).decode().strip()==OLD
assert not subprocess.check_output(['git','-C',str(REPO),'status','--porcelain'])
pr=api('pulls/1337');lap=api('git/ref/heads/lap/pr-1337')
assert pr['state']=='open' and pr['draft'] and pr['head']['sha']==OLD
assert lap['object']['sha']=='9a6798cd8090dc17aa7f2b4f10b89e29ad0d577c'
verification=api('git/ref/heads/verification/t2385-1290a23271b2-renderer-20261026')
assert verification['object']['sha']==OLD
save('PUBLIC-1290-IMMUTABLE-RETENTION.json',{'PR':pr,'lap':lap,'verification':verification,'prior_checked_packet':'/workspace/shared/T2385-1290-checked-public-dispatched-20261026/MANIFEST.json','prior_checked_packet_sha256':'a2f29691c825dff0fe82a37d2e2202fede6ce6942f71d90a3fad3896d12a92f0','durable_availability':'6a1f0abaef13aa841cf330faec06a2499aedfb37','scope':'Old1290 only. Any eventual matrixPASS cannot certify the following corrected source WIP.'})
withdraw=[ROOT/'data/structures/versions'/SID/'gifford-reading.json',ROOT/'assets/gltf'/OLD_VERSION,ROOT/'assets/web'/OLD_VERSION]
retention=[]
for path in withdraw:
    rel=path.relative_to(REPO).as_posix();raw=path.read_bytes()
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    public=api('contents/'+rel+'?ref='+OLD)
    assert public['sha']==blob and public['size']==len(raw)
    if public.get('encoding')=='base64':assert base64.b64decode(public['content'])==raw
    backup=OUT/'withdrawn-public1290'/rel;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(raw);os.chmod(backup,stat.S_IMODE(path.stat().st_mode))
    retention.append({'path':rel,'bytes':len(raw),'sha256':sha(raw),'git_blob':blob,'public_ref':OLD,'public_content_sha':public['sha'],'local_backup':backup.relative_to(OUT).as_posix()})
save('WITHDRAWN-DUPLICATE-PUBLIC-RETENTION.json',retention)

remote=api('contents/chicago/4d/data/structures/tremont_house_1.json?ref=dev')
dev_bytes=base64.b64decode(remote['content'])
assert remote['sha']=='2f6c6e65929558172760b20f8f377d1d227dec24'
assert dev_bytes==(PLAN/'current-dev-canonical.json').read_bytes()
save('FRESH-DEV-CANONICAL.json',remote)
canonical=json.loads((PLAN/'proposed-canonical-yellow.json').read_text())
canonical['phases'][0]['form']['paint']['note']=canonical['phases'][0]['form']['paint']['note'].replace('already on dev','already represented').replace('existing dev','existing reconstruction')
canonical['phases'][0]['footprint']['note']=canonical['phases'][0]['footprint']['note'].replace('existing dev rectangle','existing reconstructed rectangle')
canonical['research_note']+='\n\nPICTURE-PRIORITY READING, 2026-10-26: Gifford is the distinct whole-building picture and visibly shows three storeys with shutters. Gale 1902 p51 is TEXT, not a second picture: its smaller two-storey description remains contrary evidence and is represented by the optional gale-reading version. The pictured canonical form and existing reconstructed dimensions/placement are retained, with Gale\'s compatible yellow colour adopted as inferred. Neither source supplies a dated enlargement or proves every detail on1July1835. Stock yellow/trim tones remain liberties; the drawing is monochrome.'
canonical['phases'][0]['change_note']+=' The pictured three-storey shuttered form remains the primary interpretation. A smaller two-storey reading of Gale\'s retrospective text is available separately; no dated growth sequence is asserted.'
gale=json.loads((PLAN/'proposed-gale-reading.json').read_text())
gale['phases'][0]['footprint']['note']='OPTIONAL TEXTUAL INTERPRETATION. Gale1902 printedp51 gives20x30 for the original two-storey yellow Tremont in an1835-framed walk. Feet and the30ft long/20ft short assignment are contextual inferences, yielding9.144x6.096m. The alternative retains the same two street-facing planes by using the corresponding northeast origin; this is not a new survey. The primary reconstruction retains Gifford\'s pictured three-storey shuttered form at its prior reconstructed scale. The sources disagree; no enlargement date, exact historical absence of shutters or precise July1835 form is proved.'
gale['phases'][0]['form']['stories']['note']='Optional two-storey reading of Gale1902p51, in the town walk framed by arrival in1835. This is retrospective textual evidence, not a second picture. Gifford actually shows three storeys, which the primary reconstruction retains. No dated enlargement reconciles them.'
gale['phases'][0]['form']['paint']['note']='Gale1902p51 calls the original house yellow. This optional textual reading and the pictured primary reconstruction use inferred yellow, with the renderer\'s exact stock shade and trim tones reconstructed. Gifford is monochrome and establishes no pigment.'
for attribute in ('elevation_scheme','shutters'):
    note=gale['phases'][0]['form'][attribute]['note']
    for old,new in [('native gifford-reading alternative','pictured canonical form'),('native gifford-reading version','pictured canonical form'),('native gifford-reading','pictured canonical form'),('smaller Gale default','smaller optional Gale interpretation'),('text-led default','optional textual interpretation'),('default/picture','optional reading/picture'),('in the default','in this optional reading')]:note=note.replace(old,new)
    gale['phases'][0]['form'][attribute]['note']=note
gale['research_note']+='\n\nOPTIONAL GALE TEXT READING: this two-storey, smaller form is retained for comparison, not asserted as a dated earlier state. The primary reconstruction keeps the actual Gifford picture\'s three storeys and shutters. Yellow is compatible textual colour evidence in both. No enlargement chronology is invented.'
sys.path.insert(0,str(ROOT/'generators'))
from mesh_inputs import structure_inputs_sha,structure_inputs_doc
from archetypes.frame_tavern_params import from_phase
dev=json.loads(dev_bytes)
pb=from_phase(dev['phases'][0],dev);pa=from_phase(canonical['phases'][0],canonical);pg=from_phase(gale['phases'][0],gale)
for p in (pb,pa,pg):p.validate()
b=dataclasses.asdict(pb);a=dataclasses.asdict(pa)
assert {k for k in b if b[k]!=a[k]}=={'paint','confidence'}
assert {k for k in b['confidence']if b['confidence'][k]!=a['confidence'][k]}=={'paint'}
assert structure_inputs_sha(canonical,canonical['phases'][0])=='a3a68fd5ce5684517f12b99dc6874c9de2107f0a6e185f4103ed7d96f4f1365c'
assert structure_inputs_sha(gale,gale['phases'][0])=='717398e00f8c2d31353e07b3afbae89cd2679969283210b5572ef6f1f35ba70f'
assert canonical['phases'][0]['position']==dev['phases'][0]['position']
assert canonical['phases'][0]['footprint']['polygon']==dev['phases'][0]['footprint']['polygon']
save('CANONICAL-RECIPE.json',structure_inputs_doc(canonical,canonical['phases'][0]));save('GALE-RECIPE.json',structure_inputs_doc(gale,gale['phases'][0]))

# Every ownership, public-retention and actual parameter guard precedes mutation.
atomic(ROOT/'data/structures'/f'{SID}.json',jsonbytes(canonical))
atomic(ROOT/'data/structures/versions'/SID/'gale-reading.json',jsonbytes(gale))
vpath=ROOT/'assets/manifest.versions.json';before_v=json.loads(vpath.read_text());after_v=copy.deepcopy(before_v)
assert after_v['assets'][OLD_VERSION]['inputs_sha256']=='16ddd5768fc6eece0ce64469f5e7183d0e393f50da52b6c8275d9de8d6f0fa5b'
del after_v['assets'][OLD_VERSION]
assert all(after_v['assets'][k]==v for k,v in before_v['assets'].items()if k!=OLD_VERSION)
save('VERSION-MANIFEST-BEFORE.json',before_v);atomic(vpath,(json.dumps(after_v,indent=2,sort_keys=True)+'\n').encode())
for path in withdraw:path.unlink()

source_path=ROOT/'data/sources/gale_1902_tremont_town_walk.json';source=json.loads(source_path.read_text())
source['note']+='\n\nCURRENT USE, 2026-10-26: this is textual recollection, not a second picture of the hotel. Its yellow description supplies inferred colour compatible with the monochrome Gifford drawing. Its smaller dimensions and two-storey count remain explicit contrary evidence, preserved in the optional gale-reading native version; they no longer replace the pictured three-storey shuttered primary form. No enlargement date or exact July1835 resolution is inferred from that disagreement.'
source['what_it_supplies'][1]='The printed description original20x30 yellow two story: compatible inferred colour for the primary pictured form, with dimensions/storeys retained as a contrary optional textual interpretation.'
atomic(source_path,jsonbytes(source))

camera=json.loads(Path('/tmp/tremont-T2385-runtime-20261026/canonical-photo/camera.json').read_text())
assert camera['structure_id']==SID and camera['source_id']=='gifford_tremont_house_no_1'
camera['photo']='../../../../reference/images/chicago/chicago_first_tremont_house_1833.jpg'
camera['solve']='Retained conditional picture-match framing from six approximate envelope-corner picks, numerically fitted by bounded least squares with level, vertical-preserving pinhole projection. PointRMS3.546px, maximum point residual6.866px. The same existing15.24x9.14m/7.8m reconstructed envelope is retained; those metrics are not measured from Gifford. Focal/eye/principal coupling and retrospective drawing perspective prevent an independent lens, survey or absolute-size claim. Exact picks/residuals remain in docs/RESEARCH/frame-picture-match-T-2376-T-2385/tremont/camera-fit.json. Camera numeric values and provisional light are unchanged from the actual retained three-storey comparison; the new canonical yellow master still requires a fresh render/review. UnderT3153, small camera/pose residuals alone do not invent a visible structural gap. Monochrome front-versus-side brightness motivates the provisional light, not historical pigment. Owner-approved attributed Gifford/Chicagology project reference use is retained; no public-domain finding.'
assert sha((ROOT/'data/reference_views'/SID/camera['photo']).resolve().read_bytes())=='b45d60680a0a519e561a7293bec824675d6014a6cac4da31a38ddc70d1323e59'
atomic(ROOT/'data/reference_views'/SID/'gifford.json',jsonbytes(camera))

lib=ROOT/'docs/LIBERTIES.md';old=lib.read_bytes();start=old.index(b'### L-tremont-gale-envelope-2385');end=old.find(b'\n### ',start+10);end=len(old)if end<0 else end
field=('\n**Revised primary interpretation:** The earlier proposal to replace the primary hotel with two storeys is withdrawn. Gale is text, not a second picture: its disagreement cannot excuse removing a complete storey and the shutters visible in Gifford. The pictured three-storey shuttered form and its existing reconstructed15.24x9.14m/7.8m envelope, raised entries, four stacks, roof spar and exact street placement remain the primary interpretation. The smaller two-storey proposal is retained as the optional `gale-reading` native version, not a dated earlier state. The duplicate unpainted `gifford-reading` version is unnecessary when the pictured form is already primary; its prior comparison and public1290 evidence remain preserved.\n'
 '**Yellow finish:** Gale\'s yellow description is compatible with a monochrome drawing and supplies inferred colour. The renderer\'s particular stock yellow, trim palette, surface finish and unseen fabric remain liberties; no exact archival pigment is asserted. Retained larger metrics are reconstruction, explicitly contrary to Gale\'s smaller text. Neither source dates an enlargement or proves a precise July1835 section.\n'
 '**Acceptance boundary:** The new canonical camera and yellow master require fresh actual picture/app review. A neutral isolated GLB does not draw street context or dynamic cloth; their omission there is not evidence of missing hotel geometry. Existing actual app evidence shows the flag, but new canonical validation remains owed. Sub-foot pose/camera uncertainty and monochrome pigment are classified only from actual review. No original matching verdict or complete current gate is claimed by this source amendment.\n').encode()
atomic(lib,old[:end]+field+old[end:]);assert lib.read_bytes().replace(field,b'',1)==old
note=('\n\n## T-2385: retain the pictured hotel; keep Gale as textual alternative (2026-10-26)\n\n'
 'The proposed two-storey primary replacement is withdrawn before landing: the owner asked to match the actual Gifford picture, which shows three full storeys and shutters. Gale1902p51 is text, so this is not a two-picture tolerance case. The existing three-storey/shuttered canonical form,15.24x9.14m rectangle,7.8m wall height and exact N4637304.38 placement are retained. Only compatible yellow colour is added as inferred; the stock pigment/trim shades remain liberties. The old unsupported claim that no dimension was known is superseded by the explicit Gale disagreement.\n\n'
 'The smaller9.144x6.096m,5.45m/two-storey Gale reading remains as the optional native `gale-reading` version, with its explicit stock-kit shutter omission and smaller flag anchor. It is not a dated earlier building or proof of an enlargement. The duplicate unmerged `gifford-reading` files are withdrawn only after exact public1290 retention and local backups were verified. No promotion tool or new API is used.\n\n'
 'Source adoption is not a geometry or acceptance pass. Next is exactly one selected structure bake covering canonical+Gale, with22other frame-tavern assets/rows and unrelated versions protected, then fresh canonical photo and actual both-viewport app review. The prior immutable1290 matrix, still running independently, certifies only the old frozen1290 world. New WIP is not covered by any eventual old pass. Native/global derivation, all44 binary audit and whole preflight remain owed after resource handoff; originalT2385 remains OPEN. Corrected Tremont is independent after Wolf, outside Carpenter/GT\'s critical path.\n').encode()
for rel in ('docs/RESEARCH/tremont_house_1.md','docs/STATUS.md','docs/ROADMAP.md'):
    p=ROOT/rel;old=p.read_bytes();atomic(p,old+note);assert p.read_bytes().startswith(old)
entry={'title':'Tremont keeps its pictured form and gains yellow walls','kind':'improvement','items':['The first Tremont keeps the three storeys and shutters visible in Gifford\'s drawing. Its walls take the yellow described by Gale; the exact palette shade remains reconstructed.','Gale\'s smaller two-storey description remains available as a separately labelled native version. The sources disagree; no dated enlargement or surveyed dimensions are claimed.']}
atomic(ROOT/'changelog.d/T-2385.json',jsonbytes(entry))
save('ADOPTION.json',{'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'GUARDED_CANONICAL_PICTURE_RETAINED_SOURCE_ONLY_NATIVE_PAIR_BUILD_OWED','base_HEAD':OLD,'canonical_recipe':'a3a68fd5ce5684517f12b99dc6874c9de2107f0a6e185f4103ed7d96f4f1365c','Gale_recipe':'717398e00f8c2d31353e07b3afbae89cd2679969283210b5572ef6f1f35ba70f','canonical_vs_currentdev_only_resolved_changes':['paint:unpainted→yellow','paint confidence:reconstructed→inferred'],'canonical_geometry_and_placement_controls_exact_currentdev':True,'old_Gifford_duplicate_public_retention_verified':True,'promotion_tool_invoked':False,'native_export_or_browser_or_global_gate_run':False,'original_DONE':False,'immutable1290_pass_scope':'Old frozen1290 only; never correctedWIP','resource_lease':'None. Wait Jail all4 gate closure for exactlycanonical+Gale pair export.'})
print((OUT/'ADOPTION.json').read_text(),flush=True)
