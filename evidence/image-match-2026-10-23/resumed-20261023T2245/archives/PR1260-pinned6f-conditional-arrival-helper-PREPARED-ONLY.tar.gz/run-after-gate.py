from pathlib import Path
import os,sys,json,time,subprocess,datetime,hashlib
A=Path('/tmp/chicago-log-integration/chicago/4d');H=Path(__file__).resolve().parent;R=Path('/workspace/PR1260-dev6f-arrival-only-20261024');G=Path('/workspace/T3081-dev6f-preflight05/receipt.json');S=R/'RUN.json';expected_merge='6f992fa75bb1854d51a9f2805f97734876532a9c';expected_head='460622123de7ec66c22c0d080309664ede498f50';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();r={'status':'WAITING_FINAL_GATE_PASS_SOURCE_UNCHANGED_AND_CLOSED_PROCESSES','controller_pid':os.getpid(),'started_at':now(),'gate_receipt':str(G),'command':['node',str(H/'probe.mjs'),'--out',str(R/'actual'),'--execute'],'stages':[]}
if S.exists():raise SystemExit('Refusing existing orchestration')
env={**os.environ,'TMPDIR':'/workspace/tmp-t3081','PW_EXECUTABLE':'/usr/bin/chromium','PATH':'/workspace/shared/tools/usr/bin:'+os.environ.get('PATH',''),'PYTHONDONTWRITEBYTECODE':'1'}
def save():S.write_text(json.dumps(r,indent=2)+'\n')
def live(pid):
 try:
  stat=Path('/proc/'+str(pid)+'/stat').read_text();return stat[stat.rfind(')')+2:].split()[0] not in ['Z','X']
 except FileNotFoundError:return False

def active_checks():
 out=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit() or not live(int(p.name)):continue
  try:args=(p/'cmdline').read_bytes().split(b'\0')
  except (FileNotFoundError,PermissionError):continue
  if any(a.decode(errors='replace') in ['./tools/preflight.sh','tools/preflight.sh','./tools/check.sh','tools/check.sh',str(A/'tools/preflight.sh'),str(A/'tools/check.sh')] for a in args):out.append(int(p.name))
 return out

def cmd(name,args):
 row={'stage':name,'command':args,'started_at':now()};r['stages'].append(row);save()
 with (R/(name+'.log')).open('w') as log:
  q=subprocess.Popen(args,cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT);row['pid']=q.pid;save();code=q.wait()
 row.update(exit_code=code,ended_at=now());save()
 if code:raise RuntimeError(name+' exited '+str(code))

def git(*args):return subprocess.check_output(['git',*args],cwd=A)

def bind():
 repo=Path(git('rev-parse','--show-toplevel').decode().strip());names=set(git('diff','--name-only','HEAD').decode().splitlines());critical=['renderers/web/js/buildings.js','renderers/web/js/batch-frustum-box.js','renderers/web/js/main.js','renderers/web/js/batch-coalesce.js','renderers/web/js/driver-draws.js','tools/smoke_renderer.mjs','data/datum.json','assets/manifest.json','assets/manifest.web.json']
 for file in critical:names.add(str((A/file).relative_to(repo)))
 for stem in ['glessner_house__as_built_1887','kimball_house_1801_prairie__as_mapped_1904','coleman_ames_house_1811_prairie__as_mapped_1904']:
  for kind in ['gltf','web']:names.add(str((A/'assets'/kind/(stem+'.glb')).relative_to(repo)))
 source=[]
 for name in sorted(names):
  p=repo/name
  if not p.is_relative_to(A):continue
  source.append({'path':str(p.relative_to(A)),'sha256':sha(p) if p.is_file() else 'ABSENT','bytes':p.stat().st_size if p.is_file() else 0})
 mirror=A.parent.parent/'site/4d';published=[]
 for file in ['buildings.js','batch-frustum-box.js','main.js','batch-coalesce.js','driver-draws.js']:
  assert sha(A/'renderers/web/js'/file)==sha(mirror/'walk/js'/file),file;published.append({'path':'walk/js/'+file,'sha256':sha(mirror/'walk/js'/file)})
 for stem in ['glessner_house__as_built_1887','kimball_house_1801_prairie__as_mapped_1904','coleman_ames_house_1811_prairie__as_mapped_1904']:
  file=stem+'.glb';assert sha(A/'assets/web'/file)==sha(mirror/'data/gltf'/file),file;published.append({'path':'data/gltf/'+file,'sha256':sha(mirror/'data/gltf'/file),'bytes':(mirror/'data/gltf'/file).stat().st_size})
 published.append({'path':'build.json','sha256':sha(mirror/'build.json')});return {'HEAD':git('rev-parse','HEAD').decode().strip(),'merge_parent':git('rev-parse','MERGE_HEAD').decode().strip(),'source_diff_sha256':hashlib.sha256(git('diff','--binary','HEAD')).hexdigest(),'source':source,'published':published}
try:
 save()
 while True:
  try:gate=json.loads(G.read_text())
  except (FileNotFoundError,json.JSONDecodeError):time.sleep(2);continue
  if gate['status'] not in ['RUNNING','PASS']:raise RuntimeError('Gate did not PASS: '+gate['status'])
  if gate['status']=='PASS':
   if gate.get('source_bytes_unchanged') is not True:raise RuntimeError('Gate source_bytes_unchanged not true')
   if not live(gate['controller_pid']) and not live(gate['child_pid']) and not active_checks():break
  time.sleep(2)
 assert gate['HEAD']==expected_head and gate['merge_parent']==expected_merge,'Unexpected gate source identity'
 r['status']='FINAL_GATE_PASS_CLOSED_STARTING_AUTHORIZED_ARRIVAL';r['gate_final_sha256']=sha(G);r['gate_processes_closed']=True;save();(R/'GATE-FINAL-INPUT.json').write_bytes(G.read_bytes())
 before=bind();assert before['HEAD']==expected_head and before['merge_parent']==expected_merge;assert before['source_diff_sha256']==gate['source_diff_sha256'],'Source changed after gate';assert next(x['sha256'] for x in before['source'] if x['path']=='renderers/web/js/buildings.js')=='9bbabfdcdf0ade6cd4edf161b9fe120afcc4332500b92f268461341495a9ec04';assert next(x['sha256'] for x in before['source'] if x['path']=='renderers/web/js/batch-frustum-box.js')=='3baf84f8f26ce3410691b40bd18a22a302c74c38daae606d84a1800d62736217';(R/'BOUND-INPUTS.json').write_text(json.dumps(before,indent=2)+'\n')
 cmd('readonly-published',['node','tools/check_published.mjs']);cmd('arrival',r['command'])
 after=bind();assert after==before,'Source/mirror binding moved during canonical arrival';(R/'BOUND-AFTER.json').write_text(json.dumps(after,indent=2)+'\n');actual=json.loads((R/'actual/STATUS.json').read_text());assert actual['exit_code']==0 and actual['measurement']['stats']['withinBudget'];r['status']='PASS_STRICT_CANONICAL_PUBLISHED_ARRIVAL_ONLY';r['actual_stats']=actual['measurement']['stats'];r['box_proof']=actual['measurement']['boundsNarrowPhase'];r['source_mirror_unchanged']=True;r['exit_code']=0
except BaseException as e:r['status']='STOPPED_FAIL_NO_SOURCE_WRITES';r['error']=str(e);r['exit_code']=1
finally:r['finished_at']=now();save()
print(json.dumps(r,indent=2));sys.exit(r['exit_code'])
