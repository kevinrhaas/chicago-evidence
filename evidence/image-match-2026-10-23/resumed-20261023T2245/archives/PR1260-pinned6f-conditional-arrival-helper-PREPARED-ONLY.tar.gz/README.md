# Prepared canonical1904 arrival-only replay

Prepared-only checkpoint. No browser or publish ran at this checkpoint. The live authorized waiter is separate at /workspace/PR1260-dev6f-arrival-only-20261024/RUN.json. Do not infer its future outcome from these files or launch a duplicate.

Command: python3 /tmp/PR1260-dev6f-arrival-only-20261024/run-after-gate.py

Conditional root grant requires /workspace/T3081-dev6f-preflight05/receipt.json finalPASS, source_bytes_unchanged:true, pinnedHEAD460622123…/MERGE6f992fa75bb1854d51a9f2805f97734876532a9c, and closed controller/preflight/check processes. A failed gate or changed binding stops without browser/source writes. Only the final closed gate receipt may be copied as an input; live logs are never selected.

Runner then binds current changed projectfiles and criticalsource/threeGLBmaster+web/publishedassets, exact approved981e renderer code, current source-diff fingerprint, mirror build; runs readonly check_published and one fresh desktop1280×800/DPR1 Full normal1904 arrival using the acceptedf7c9 flow (native welcome, restored street excursions and originalfrontpicks). All4manualstands removed. Strict unchanged7800/4.6M caps, standingcounts and genuine loader/page/HTTP/unexpected-request/cleanup errors fail. Existing native ERR_ABORTED classification is unchanged, raw findings retained. Actual HTTP-body hashes added for Glessner/Kimball/Coleman; pre/post source+mirror fingerprints must match. No publish, bake, source/asset/cap/settings change, alternative camera, fullstage18, deviceperformance or imageacceptance.

If interrupted, inspect live RUN/status/PIDs before any action; this prepared snapshot is not a license to restart over an active browser. Actual outcome/evidence must be separately closed, hashed and checkpointed after cleanup.
