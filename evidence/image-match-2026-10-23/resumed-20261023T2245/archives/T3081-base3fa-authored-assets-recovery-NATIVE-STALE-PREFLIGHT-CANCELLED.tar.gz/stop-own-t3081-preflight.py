import os,signal,json
from pathlib import Path
procs={}
for d in Path('/proc').iterdir():
 if not d.name.isdigit(): continue
 try:
  args=(d/'cmdline').read_bytes().split(b'\0'); stat=(d/'stat').read_text().split(') ',1)[1].split(); procs[int(d.name)]={'args':[x.decode(errors='replace') for x in args if x],'ppid':int(stat[1])}
 except (OSError,ValueError): pass
roots=[p for p,v in procs.items() if v['args'] in [['bash','./tools/preflight.sh'],['/usr/bin/bash','./tools/preflight.sh'],['/bin/bash','./tools/preflight.sh']]]
assert len(roots)==1,roots
root=roots[0]; ancestors=[]; n=root
while n in procs:
 ancestors.append(procs[n]['args']); n=procs[n]['ppid']
assert any('/tmp/T3081-base3fa-native-review/preflight.log' in ' '.join(x) and 'TMPDIR=/workspace/tmp-t3081' in ' '.join(x) for x in ancestors)
children=[]
def descend(p):
 for c,v in procs.items():
  if v['ppid']==p: descend(c); children.append(c)
descend(root)
print(json.dumps({'root':root,'root_command':procs[root]['args'],'descendant_count':len(children),'reason':'own preflight cancelled for stale sidecar after model-build ordering correction'}))
for p in children+[root]:
 try: os.kill(p,signal.SIGTERM)
 except ProcessLookupError: pass
