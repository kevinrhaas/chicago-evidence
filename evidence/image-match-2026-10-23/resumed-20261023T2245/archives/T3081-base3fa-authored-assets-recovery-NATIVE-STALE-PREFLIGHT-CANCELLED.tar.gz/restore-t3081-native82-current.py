from pathlib import Path
import subprocess,json,hashlib,sys
r=Path('/tmp/chicago-log-integration'); a=r/'chicago/4d'; cp=Path('/tmp/T3081-native653-checkpoint-20261024T0015'); official=Path('/tmp/log82-official-checkpoint-20261023T2335/tree/chicago/4d')
sha=lambda b:hashlib.sha256(b).hexdigest()
for root in [cp,official.parents[3]]:
 pass
# Exact consumer source restoration is valid only while incoming parent consumer is unchanged.
p='chicago/4d/tools/generate_entrances.py'
old=subprocess.check_output(['git','show','96ca50cbc8150f93576cbbd699b4359d73b6de01:'+p],cwd=r)
new=subprocess.check_output(['git','show','HEAD:'+p],cwd=r); assert old==new
fixed=(cp/'working-tree'/p).read_bytes(); assert b"phases = [ph for ph in record.get('phases', [])" in fixed or b"phases = [ph for ph in record.get(\"phases\", [])" in fixed or b'phases =' in fixed
# The complete target file differs from archived authored source only at the reviewed phase-reader fix.
grafted=(r/p).read_bytes(); source_old=(official/'tools/generate_entrances.py').read_bytes(); assert grafted==source_old
(r/p).write_bytes(fixed)
# Keep the entire current incoming STATUS history; replace only our appended section.
marker=b'## T-3081 \xe2\x80\x94 log-building picture details'
target=a/'docs/STATUS.md'; before=target.read_bytes(); saved=(cp/'working-tree/chicago/4d/docs/STATUS.md').read_bytes(); assert before.count(marker)==saved.count(marker)==1
fragment=marker+saved.split(marker)[1]
fragment+=b'\n\nBase refresh: PR #1239 was superseded without losing work by non-draft PR #1256. This integration now composes its reviewed head 3fa6e0e84f84a33ccb8ac82c4778f6468af3b029 with dev ff808a22d50fedf5474d33535748286b71794c8e. All incoming Glessner and Kimball records, source history and native asset rows are preserved. Earlier head-specific CI evidence remains historical; this exact tree requires its own full gate.\n'
target.write_bytes(before.split(marker)[0]+fragment)
sys.path.insert(0,str(a/'generators')); import mesh_inputs
native=json.loads((a/'assets/manifest.json').read_bytes()); web=json.loads((a/'assets/manifest.web.json').read_bytes()); source_native=json.loads((official/'assets/manifest.json').read_bytes()); source_web=json.loads((official/'assets/manifest.web.json').read_bytes()); scope=json.loads(Path('/tmp/log82-integration-evidence/all82-before-assets.json').read_bytes()); touched=[]
# All inputs are proved before any asset or recipe row is written.
for x in scope:
 st=json.loads((a/'data/structures'/f"{x['structure_id']}.json").read_bytes()); ph=next(p for p in st['phases'] if p['id']==x['phase_id']); row=source_native['assets'][x['asset']]
 assert row['archetype']=='log_dwelling'; assert mesh_inputs.structure_inputs_sha(st,ph,'log_dwelling')==row['inputs_sha256'],x['asset']
 assert sha((official/'assets/gltf'/x['asset']).read_bytes())==source_web['masters'][x['asset']]
 # incoming asset bytes still equal genuine prebuild bytes; refuse unknown changes.
 for sub,key in [('gltf','gltf'),('web','web')]: assert sha((a/'assets'/sub/x['asset']).read_bytes())==x[key]['sha256'],(sub,x['asset'])
for x in scope:
 for sub in ['gltf','web']:
  target=a/'assets'/sub/x['asset']; b=(official/'assets'/sub/x['asset']).read_bytes()
  if target.read_bytes()!=b: target.write_bytes(b); touched.append(str(target.relative_to(a)))
 native['assets'][x['asset']]=source_native['assets'][x['asset']]
 web['masters'][x['asset']]=source_web['masters'][x['asset']]
(a/'assets/manifest.json').write_text(json.dumps(native,indent=2,sort_keys=True)+'\n'); (a/'assets/manifest.web.json').write_text(json.dumps(web,indent=2)+'\n')
receipt={'status':'PASS','HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'actual_official_recipe_rows_transferred':82,'current_inputs_exact_before_transfer':82,'changed_asset_files':touched,'consumer_restored_from_closed653_checkpoint':True,'entire_incoming_STATUS_prefix_retained':True,'unrelated_incoming_native_rows_retained':True,'no_recipe_hash_manufactured':True}
Path('/tmp/T3081-base3fa-native82-transfer.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(receipt,indent=2))
