from pathlib import Path
import subprocess,json,hashlib,shutil,sys
r=Path('/tmp/chicago-log-integration'); cp=Path('/tmp/T3081-native653-checkpoint-20261024T0015'); held=Path('/tmp/T3081-native653-held-before-3fa6')
sha=lambda b:hashlib.sha256(b).hexdigest()
state=json.loads((cp/'state.json').read_bytes())
def git(*args): return subprocess.check_output(['git',*args],cwd=r)
assert git('rev-parse','HEAD').decode().strip()==state['HEAD']; assert git('rev-parse','MERGE_HEAD').decode().strip()==state['MERGE_HEAD']
assert not held.exists()
paths=set(git('diff','HEAD','--name-only','-z').split(b'\0')+git('ls-files','--others','--exclude-standard','-z').split(b'\0'))-{b''}
assert paths=={p.encode() for p in state['paths']}
for p,v in state['paths'].items():
 f=r/p; assert f.exists()==v['exists']
 if f.exists(): assert sha(f.read_bytes())==v['sha256'],p
subprocess.run(['git','merge','--quit'],cwd=r,check=True)
tracked=[p for p,v in state['paths'].items() if not v.get('untracked',False)]
subprocess.run(['git','restore','--source=HEAD','--staged','--worktree','--',*tracked],cwd=r,check=True)
for p,v in state['paths'].items():
 if v.get('untracked',False):
  dst=held/p; dst.parent.mkdir(parents=True,exist_ok=True); shutil.move(r/p,dst)
assert not git('status','--porcelain')
subprocess.run(['git','switch','-c','steward/t3081-log-picture-controls-v3','3fa6e0e84f84a33ccb8ac82c4778f6468af3b029'],cwd=r,check=True)
subprocess.run(['git','merge','--no-commit','--no-ff','ff808a22d50fedf5474d33535748286b71794c8e'],cwd=r,check=True)
print(git('status','--short').decode())
