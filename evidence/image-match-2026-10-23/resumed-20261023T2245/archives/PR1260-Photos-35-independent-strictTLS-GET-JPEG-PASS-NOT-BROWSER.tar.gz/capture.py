from pathlib import Path
import collections, concurrent.futures, datetime, hashlib, json, os, subprocess, urllib.parse, warnings
from PIL import Image, __version__ as pillow_version

OUT=Path(__file__).resolve().parent
SOURCE=Path('/workspace/PR1260-shadow-ray-actual-001/actual/desktop/RESULT.json')
assert not (OUT/'ORCHESTRATION.json').exists(), 'Preserve prior attempts'
original=SOURCE.read_bytes()
source=json.loads(original)
assert source['status']=='FAIL'
CA=Path('/etc/ssl/certs/ca-certificates.crt')
assert CA.is_file()
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for i,row in enumerate(source['request_failures']):
    if urllib.parse.urlsplit(row['url']).hostname not in ['127.0.0.1','localhost']:
        assert row['failure']['errorText']=='net::ERR_CERT_AUTHORITY_INVALID'
        rows.append({'original_request_index':i,**row})
assert len(rows)==36
urls=list(dict.fromkeys(row['url'] for row in rows))
assert len(urls)==35
items=[]
for n,url in enumerate(urls,1):
    parsed=urllib.parse.urlsplit(url)
    assert parsed.scheme=='https' and parsed.hostname=='kevinrhaas.github.io'
    indices=[r['original_request_index'] for r in rows if r['url']==url]
    items.append({'id':f'{n:02d}','url':url,'original_request_indices':indices,'occurrences':len(indices)})
(OUT/'ORIGINAL-36-REQUEST-ROWS.json').write_text(json.dumps(rows,indent=2)+'\n')
(OUT/'DEDUPLICATED-35-URLS.json').write_text(json.dumps(items,indent=2)+'\n')
(OUT/'SOURCE-FAILURE-BINDING.json').write_text(json.dumps({'source':str(SOURCE),'sha256':sha(original),'original_status':'FAIL','request_rows':36,'unique_urls':35,'duplicate_counts':{u:n for u,n in collections.Counter(r['url'] for r in rows).items()if n>1},'limits':'Original native browser FAIL is unchanged; independent GET/decode only.'},indent=2)+'\n')
state={'status':'RUNNING','pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'resources':[],'TLS_policy':{'client':'curl with inherited proxy; no environment overrides','verify_peer':True,'verify_hostname':True,'cacert_path':str(CA),'cacert_sha256':sha(CA.read_bytes()),'HTTPS_only_redirects':True,'no_insecure_or_interception':True,'proxy_environment_present':{k:bool(os.environ.get(k))for k in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY']},'curl_version':subprocess.check_output(['curl','--version'],text=True).splitlines()[0],'Pillow_version':pillow_version},'limits':'Independent resource availability, strict TLS and image decode evidence. NOT native browser image/QA/stage14/merge PASS.'}
def save():
    target=OUT/'ORCHESTRATION.next.json'
    target.write_text(json.dumps(state,indent=2)+'\n')
    target.replace(OUT/'ORCHESTRATION.json')
save()

# Optional publication membership is accepted only if its bytes still match the
# immutable original failed-run binding; no mutable source assumptions.
binding_path=Path('/workspace/PR1260-shadow-ray-actual-001/actual/bindings.json')
membership={}
if binding_path.is_file():
    binding=json.loads(binding_path.read_text())
    row=next((r for r in binding['files']if r['root']=='site'and r['path']=='data/pictures/1904.json'),None)
    pub=Path(binding['site'])/'data/pictures/1904.json'
    if row and pub.is_file():
        raw=pub.read_bytes()
        if sha(raw)==row['sha256']:
            catalog=json.loads(raw)
            (OUT/'BOUND-PUBLISHED-PICTURES-1904.json').write_bytes(raw)
            base=catalog['image_store']['base_url']
            for structure,pictures in catalog['by_structure'].items():
                for picture in pictures:
                    for key,value in (picture.get('held')or{}).items():
                        if isinstance(value,str)and value.lower().endswith(('.jpg','.jpeg','.png','.webp')):
                            url=urllib.parse.urljoin(base,value)
                            membership.setdefault(url,[]).append({'structure_id':structure,'picture_id':picture['id'],'held_key':key})
            state['published_membership']={'status':'BOUND catalog bytes exact to failed-run frozen hash','sha256':sha(raw),'source':str(pub)}
        else:state['published_membership']={'status':'SKIPPED current catalog differs from original immutable binding'}
save()

def capture(item):
    folder=OUT/('resource-'+item['id']);folder.mkdir()
    command=['curl','--silent','--show-error','--location','--max-redirs','5','--connect-timeout','15','--max-time','45','--proto','=https','--proto-redir','=https','--cacert',str(CA),'--dump-header',str(folder/'response-headers.raw'),'--output',str(folder/'body.bin'),'--write-out','%{json}',item['url']]
    r={**item,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'publication_membership':membership.get(item['url'],[]),'status':'RUNNING'}
    proc=subprocess.run(command,capture_output=True)
    (folder/'curl-writeout.json').write_bytes(proc.stdout)
    (folder/'curl-stderr.txt').write_bytes(proc.stderr)
    r['curl_exit_code']=proc.returncode
    try:
        transport=json.loads(proc.stdout)
        r['transport']={k:transport.get(k)for k in ['http_code','http_connect','ssl_verify_result','proxy_ssl_verify_result','num_redirects','size_download','content_type','url_effective','time_total','time_namelookup','time_connect','time_appconnect','remote_ip','remote_port','proxy_used','exitcode','errormsg']}
        body=folder/'body.bin'
        if body.is_file():
            raw=body.read_bytes();r.update(bytes=len(raw),sha256=sha(raw))
        assert proc.returncode==0, 'curl failed; preserve raw transport result'
        assert transport['http_code']==200, 'HTTP resource not200'
        assert transport['ssl_verify_result']==0, 'TLS verification did not succeed'
        assert urllib.parse.urlsplit(transport['url_effective']).scheme=='https'
        with warnings.catch_warnings(record=True)as seen:
            warnings.simplefilter('always')
            with Image.open(body)as image:
                fmt=image.format;dimensions=image.size;mode=image.mode;image.verify()
            with Image.open(body)as image:
                image.load();assert image.size==dimensions
            assert dimensions[0]>0 and dimensions[1]>0
            r['image']={'format':fmt,'width':dimensions[0],'height':dimensions[1],'mode':mode,'verify':'PASS','full_pixel_decode':'PASS','warnings':[str(w.message)for w in seen]}
        r['status']='PASS_STRICT_TLS_HTTP200_VALID_IMAGE_NOT_BROWSER_PASS'
    except BaseException as exc:
        r.update(status='FAILED_RESOURCE_PROOF',error=str(exc))
    r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (folder/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
    return r

try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
        futures=[pool.submit(capture,item)for item in items]
        for future in concurrent.futures.as_completed(futures):
            state['resources'].append(future.result());state['resources'].sort(key=lambda x:x['id']);save()
    assert SOURCE.read_bytes()==original, 'Original failure evidence changed'
    passed=sum(r['status']=='PASS_STRICT_TLS_HTTP200_VALID_IMAGE_NOT_BROWSER_PASS'for r in state['resources'])
    state.update(status='PASS_ALL35_STRICT_TLS_GET_AND_IMAGE_DECODE_NOT_BROWSER_PASS'if passed==35 else'COMPLETED_WITH_RESOURCE_FAILURES',passed_resources=passed,total_resources=35,original_request_rows_preserved=36,original_browser_status='FAIL_RETAINED')
finally:
    state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({k:state.get(k)for k in ['status','passed_resources','total_resources','original_request_rows_preserved','original_browser_status','started_utc','finished_utc']},indent=2))
raise SystemExit(0 if state['status']=='PASS_ALL35_STRICT_TLS_GET_AND_IMAGE_DECODE_NOT_BROWSER_PASS'else 1)
