"""Read-only by default: validates the exact T2382 donor paths and native rows.
No apply mode: the primary writer must own a separately reviewed source lease.
"""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess
ap=argparse.ArgumentParser();ap.add_argument('--repo',default='/workspace/chicago');ap.add_argument('--expect-head',required=True);a=ap.parse_args();R=Path(a.repo).resolve();P=Path(__file__).resolve().parent;plan=json.loads((P/'ADOPTION-PLAN.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();pf=lambda p:sha(p.read_bytes());E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
assert shutil.disk_usage(R).free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True,env=E).strip()==a.expect_head
for row in plan['direct_postimages']:
 dest=R/row['repo_path'];donor=P/row['postimage'];assert pf(donor)==row['after_sha256'];assert (pf(dest)if dest.exists()else None)==row['before_sha256'],row['repo_path']
for row in plan['source_bindings']:assert pf(R/row['repo_path'])==row['sha256'],row['repo_path']
regs=json.loads((P/plan['entrywise_registries_file']).read_text());counts={}
for row in regs:
 original=json.loads((R/row['repo_path']).read_text());key=row['map_key'];name=row['entry_key'];assert original[key][name]==row['before_entry'];changed=json.loads(json.dumps(original));changed[key][name]=row['after_entry'];assert {k:v for k,v in changed.items()if k!=key}=={k:v for k,v in original.items()if k!=key};assert {k:v for k,v in changed[key].items()if k!=name}=={k:v for k,v in original[key].items()if k!=name};counts[row['repo_path']]=len(original[key])-1
lib=R/plan['liberties']['repo_path'];assert pf(P/plan['liberties']['append_file'])==plan['liberties']['append_sha256'];assert b"## T-2382 \xe2\x80\x94 Carpenter's former shop: low roof"not in lib.read_bytes()
print(json.dumps({'status':'READONLY_T2382_ALL_DIRECT_PREIMAGES_DONORS_NATIVE_ROWS_AND_SOURCE_BINDINGS_PASS','primary_head':a.expect_head,'direct_postimages':len(plan['direct_postimages']),'preserved_foreign_rows':counts,'current_Liberties_sha256':pf(lib),'current_Liberties_bytes':lib.stat().st_size,'source_Git_mirror_tickets_written':False,'library_donors_unhosted':plan['library_donor_unhosted'],'app_Images_ground_BOTH_not_qualified':True},indent=2))
