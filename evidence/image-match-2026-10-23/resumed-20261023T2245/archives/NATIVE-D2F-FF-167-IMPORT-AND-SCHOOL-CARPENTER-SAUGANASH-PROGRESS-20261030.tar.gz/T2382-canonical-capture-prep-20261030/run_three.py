from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time,datetime
P=Path(__file__).resolve().parent;F=P/'runtime';plan=json.loads((P/'PLAN.json').read_text());A=Path('/workspace/chicago/chicago/4d');R=A.parent.parent;sha=lambda b:hashlib.sha256(b).hexdigest();pf=lambda p:sha(p.read_bytes());assert os.environ.get('CB_CANONICAL_CAPTURE_CPU')=='root-three-canonical-captures'
assert not (P/'ACTUAL-CAPTURES.json').exists();assert shutil.disk_usage('/workspace').free>=536870912+8*1024**2;assert shutil.disk_usage('/tmp').free>=1800000000
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
def state():return {'head':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],env=E,text=True).strip(),'status_sha256':sha(subprocess.check_output(['git','-C',str(R),'status','--porcelain=v1','-uno'],env=E)),'config_sha256':pf(R/'.git/config'),'index_sha256':pf(R/'.git/index')}
assert state()==plan['primary_Git_state']
for r in plan['immutable_old_runtime_current_consumers_all_exact']:assert pf(Path(r['path']))==r['sha256']and pf(Path(r['current']))==r['sha256']
for r in plan['bindings']:
 if 'sha256'in r:assert pf(P/r['target'])==r['sha256']and pf(Path(r['source']))==r['sha256']
for r in plan['exclusive_written_metadata']:assert pf(Path(r['path']))==r['sha256']
assert pf(Path(plan['native_geometry_authority']))==plan['native_geometry_authority_sha256'];short=Path('/workspace/cb2382canon30');assert not short.exists();short.mkdir(mode=0o700);E['TMPDIR']=str(short);stages=[]
for row in plan['cameras']:
 assert shutil.disk_usage('/workspace').free>=536870912;assert shutil.disk_usage('/tmp').free>=1800000000;assert pf(F/row['camera'])==row['camera_sha256'];assert pf(Path(row['photo']))==row['photo_sha256']
 view=row['view'];log=P/(view+'.log');reap=P/(view+'-REAPER.json');args=['python3','/workspace/shared/run-with-reaping.py',str(reap),'--','nice','-n','19','taskset','-c','3,4',*row['native_command']];t=time.monotonic()
 with log.open('x')as stream:q=subprocess.run(args,cwd=F,env=E,stdout=stream,stderr=subprocess.STDOUT)
 rp=json.loads(reap.read_text());out={'view':view,'actual_exit':q.returncode,'seconds':round(time.monotonic()-t,3),'all_children_reaped':rp['all_children_reaped'],'native_command':row['native_command']};stages.append(out);print(json.dumps(out),flush=True);(P/'STAGES.json').write_text(json.dumps(stages,indent=2)+'\n')
 assert q.returncode==0 and rp['command_exit']==0 and rp['all_children_reaped'],log.read_text()[-3000:]
 camera=F/row['camera'];match=camera.with_suffix('.match.json');data=json.loads(match.read_text());assert data['verdict']=='unreviewed'and data['camera_sha256']==pf(camera)and data['photo_sha256']==pf(Path(row['photo']))and data['glb_sha256']=='f3e26f650627f36879087d75f30db5c4553e0f5938ae5bd0d305480958549cfc';assert len(data['rendered_members'])==2 and data['rendered_members'][1]['structure_id']=='sauganash_hotel';assert data['side_by_side']=='docs/RESEARCH/photo-match/philo_carpenter_log_shop/'+view+'-side-by-side.jpg'
 raw=re.search(r'\n\s+(/[^\n]+-render\.png)\n',log.read_text());assert raw;rawpng=Path(raw.group(1));dest=P/'public-raw-native'/(view+'.png');dest.parent.mkdir(exist_ok=True);shutil.copyfile(rawpng,dest);preserve=P/'raw-native-matches'/match.name;preserve.parent.mkdir(exist_ok=True);shutil.copyfile(match,preserve)
assert state()==plan['primary_Git_state']
for r in plan['immutable_old_runtime_current_consumers_all_exact']:assert pf(Path(r['path']))==r['sha256']and pf(Path(r['current']))==r['sha256']
for r in plan['cameras']:assert pf(F/r['camera'])==r['camera_sha256']and pf(Path(r['photo']))==r['photo_sha256']
result={'status':'ACTUAL_THREE_CANONICAL_METADATA_BOUND_NATIVE_CAPTURES_PASS_UNREVIEWED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':stages,'all_source_camera_photo_group_native_bindings_exact':True,'primary_source_Git_unchanged':True,'old_public_runtime_and_current_counterparts_exact':True,'numeric_rays_from_accepted_trials_exact':True,'native_recipe':plan['native_recipe'],'raw_native_verdicts_unreviewed':True,'whole_hotel_not_accepted':True,'app_ground_walk_Images_BOTH_not_qualified':True,'source_only_crop_original_bound':True,'workspace_free':shutil.disk_usage('/workspace').free,'TMP_free':shutil.disk_usage('/tmp').free};(P/'ACTUAL-CAPTURES.json').write_text(json.dumps(result,indent=2)+'\n');assert result['workspace_free']>=536870912 and result['TMP_free']>=1800000000;print(json.dumps(result,indent=2),flush=True)
