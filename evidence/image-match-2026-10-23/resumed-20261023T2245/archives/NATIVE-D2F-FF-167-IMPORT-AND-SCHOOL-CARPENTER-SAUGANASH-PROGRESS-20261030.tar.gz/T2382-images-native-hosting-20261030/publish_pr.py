from pathlib import Path
import base64,datetime,hashlib,json,os,shutil,subprocess
P=Path(__file__).resolve().parent;j=json.loads((P/'PREPARED.json').read_text());repo=j['repository'];branch='steward/t2382-carpenter-source-images-20261030';sha=lambda b:hashlib.sha256(b).hexdigest();gitsha=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def save(n,x):(P/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def api(endpoint,data=None,method=None):
 cmd=['gh','api','repos/'+repo+'/'+endpoint,'--header','Cache-Control: no-cache']
 if method:cmd+=['--method',method]
 if data is not None:cmd+=['--input','-']
 return json.loads(subprocess.check_output(cmd,input=json.dumps(data).encode()if data is not None else None,env=E))
assert not(P/'PR-CREATED.json').exists();assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
assert api('git/ref/heads/main')['object']['sha']==j['base'];base=json.loads((P/'IMAGE-MAIN-BASE.json').read_text());nodes=[]
for row in j['files']:
 data=Path(row['path']).read_bytes();assert sha(data)==row['sha256']and len(data)==row['bytes'];blob=api('git/blobs',{'encoding':'base64','content':base64.b64encode(data).decode()},'POST');assert blob['sha']==gitsha(data);nodes.append({'path':row['repo_path'],'mode':'100644','type':'blob','sha':blob['sha']})
tree=api('git/trees',{'base_tree':j['base_tree'],'tree':nodes},'POST');newtree=api('git/trees/'+tree['sha']+'?recursive=1');assert not newtree.get('truncated');old={r['path']:(r['mode'],r['type'],r['sha'])for r in base['leaves']if r['type']!='tree'};new={r['path']:(r['mode'],r['type'],r['sha'])for r in newtree['tree']if r['type']!='tree'};changed={r['repo_path']for r in j['files']};assert set(new)-set(old)==changed-{'prairie-1904/MANIFEST.json'};assert not(set(old)-set(new));assert all(new[k]==v for k,v in old.items()if k not in changed)
message='T-2382: host credited Trowbridge and Kurz annex references';commit=api('git/commits',{'message':message,'tree':tree['sha'],'parents':[j['base']]},'POST');assert commit['tree']['sha']==tree['sha']and[r['sha']for r in commit['parents']]==[j['base']];assert api('git/ref/heads/main')['object']['sha']==j['base'];ref=api('git/refs',{'ref':'refs/heads/'+branch,'sha':commit['sha']},'POST');assert ref['object']['sha']==commit['sha']
body='''T-2382 needs the credited Trowbridge (1902) Sauganash drawing and Kurz & Allison (1893) panel 14 on the Carpenter annex’s Images tab. This adds their display JPEGs and thumbnails with source and public-domain provenance in the image manifest. The Kurz image is the exact disclosed rectangle from the held whole sheet; its native local-file fetch receipt and original public sheet URL remain explicit.

Validation: the existing official `fetch_image.py` and `sync_image_store.py` produced all four files and their records. JPEG decoding, dimensions, byte counts and SHA-256 checks pass; all 1,310 existing manifest rows and every unrelated repository leaf are preserved. Application camera/library adoption and browser checks follow in the separate Chicago app PR; this image PR does not close T-2382.
''';(P/'PR-BODY.md').write_text(body)
pr=api('pulls',{'title':message,'head':branch,'base':'main','body':body,'draft':False},'POST');assert pr['head']['sha']==commit['sha']and pr['base']['ref']=='main'
# Strict immutable object readback of every actual native output.
received=[]
for row,node in zip(j['files'],nodes):
 b=api('git/blobs/'+node['sha']);raw=base64.b64decode(b['content']);assert sha(raw)==row['sha256']and gitsha(raw)==node['sha'];received.append({'path':row['repo_path'],'bytes':len(raw),'sha256':sha(raw),'git_blob':node['sha']})
result={'status':'ACTUAL_FIVE_PATH_CREDITED_IMAGE_PR_CREATED_NATIVE_FILES_IMMUTABLE_READBACK_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':repo,'base':j['base'],'head':commit['sha'],'tree':tree['sha'],'parents':[j['base']],'branch':branch,'PR':pr['number'],'url':pr['html_url'],'all_other_repository_leaves_exact':len(old)-1,'all_1310_foreign_manifest_rows_preserved':True,'native_files_immutable_readback':received,'merged':False,'Pages_ready':False,'app_source_Git_site_tickets_written':False,'local_images_checkout_written':False};save('PR-CREATED.json',result);print(json.dumps({k:v for k,v in result.items()if k!='native_files_immutable_readback'},indent=2))
