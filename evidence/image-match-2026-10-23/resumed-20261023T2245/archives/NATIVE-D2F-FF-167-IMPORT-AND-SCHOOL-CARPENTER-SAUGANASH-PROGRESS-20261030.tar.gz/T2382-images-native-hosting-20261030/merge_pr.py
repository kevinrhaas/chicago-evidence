from pathlib import Path
import base64,datetime,hashlib,json,os,subprocess
P=Path(__file__).resolve().parent;j=json.loads((P/'PR-CREATED.json').read_text());repo=j['repository'];sha=lambda b:hashlib.sha256(b).hexdigest()
def api(endpoint,data=None,method=None):
 cmd=['gh','api','repos/'+repo+'/'+endpoint,'--header','Cache-Control: no-cache']
 if method:cmd+=['--method',method]
 if data is not None:cmd+=['--input','-']
 return json.loads(subprocess.check_output(cmd,input=json.dumps(data).encode()if data is not None else None))
assert not(P/'MERGED.json').exists();pr=api('pulls/'+str(j['PR']));checks=api('commits/'+j['head']+'/check-runs');statuses=api('commits/'+j['head']+'/status');assert pr['state']=='open'and not pr['draft']and pr['mergeable']is True and pr['mergeable_state']=='clean'and pr['head']['sha']==j['head']and pr['base']['ref']=='main';assert'hold'not in[r['name']for r in pr['labels']];assert all(r['status']=='completed'and r['conclusion']in['success','neutral','skipped']for r in checks['check_runs']);assert all(r['state']=='success'for r in statuses['statuses']);assert api('git/ref/heads/main')['object']['sha']==j['base']
merged=api('pulls/'+str(j['PR'])+'/merge',{'sha':j['head'],'merge_method':'squash','commit_title':'T-2382: host credited Trowbridge and Kurz annex references (#13)'},'PUT');assert merged['merged']is True;tip=api('git/ref/heads/main')['object']['sha'];assert tip==merged['sha'];commit=api('git/commits/'+tip);assert commit['tree']['sha']==j['tree']and[r['sha']for r in commit['parents']]==[j['base']]
for row in j['native_files_immutable_readback']:
 raw=base64.b64decode(api('git/blobs/'+row['git_blob'])['content']);assert sha(raw)==row['sha256']and len(raw)==row['bytes']
prnow=api('pulls/'+str(j['PR']));assert prnow['merged']and prnow['merge_commit_sha']==tip
out={'status':'ACTUAL_IMAGE_PR13_EXPECTED_HEAD_NORMAL_SQUASH_MERGED_MAIN_TREE_AND_NATIVE_BLOBS_VERIFIED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':repo,'PR':j['PR'],'url':j['url'],'checked_head':j['head'],'merged_commit':tip,'tree':j['tree'],'parent':j['base'],'PR_check_runs_count':checks['total_count'],'PR_statuses_count':statuses['total_count'],'no_PR_gate_configured_images_repo_only_main_Pages_workflow':True,'native_fetch_sync_decode_size_SHA_and_1310_foreign_rows_PASS':True,'all_1342_unrelated_repository_leaves_preserved':True,'Pages_ready':False,'app_library_STORE_native_publish_browser_still_pending':True,'app_source_Git_site_tickets_written':False};(P/'MERGED.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
