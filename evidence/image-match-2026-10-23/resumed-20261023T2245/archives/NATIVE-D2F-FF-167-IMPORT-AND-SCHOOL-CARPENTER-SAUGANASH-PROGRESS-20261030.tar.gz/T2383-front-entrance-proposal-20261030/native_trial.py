from pathlib import Path
import copy
import hashlib
import json
import sys
import time

P = Path('/workspace/T2383-front-entrance-proposal-20261030')
A = Path('/workspace/chicago/chicago/4d')
sys.path.insert(0, str(P / 'fixture/generators'))
import emit
from archetypes import frame_tavern
from archetypes.frame_tavern_params import from_phase
from common.mesh import reset_scene

assert Path(frame_tavern.__file__).resolve() == P / 'fixture/generators/archetypes/frame_tavern.py'
base = json.loads((A / 'data/structures/sauganash_hotel.json').read_text())
candidate = json.loads((P / 'sauganash_hotel.candidate.json').read_text())
bp = next(p for p in base['phases'] if p['id'] == 'frame_1831')
cp = next(p for p in candidate['phases'] if p['id'] == 'frame_1831')
without = copy.deepcopy(candidate)
next(p for p in without['phases'] if p['id'] == 'frame_1831')['form'].pop('front_opening_details')
assert without == base

def outside_entry(record, phase):
    reset_scene()
    params = from_phase(phase, record)
    ob = frame_tavern.build(params, 'sauganash_hotel__frame_1831')
    conf = ob.data.attributes['_CONFIDENCE'].data
    rows = []
    excluded = 0
    for poly in ob.data.polygons:
        verts = [tuple(round(float(v), 9) for v in ob.data.vertices[i].co) for i in poly.vertices]
        in_box = all(abs(v[0] - params.width_m/2) <= 1.5 and v[1] >= params.depth_m - .01
                     and v[1] <= params.depth_m + .6 and -.01 <= v[2] <= 3.3 for v in verts)
        if in_box:
            excluded += 1
            continue
        mat = ob.data.materials[poly.material_index]
        bsdf = mat.node_tree.nodes.get('Principled BSDF')
        assert bsdf is not None
        colour = tuple(round(float(v), 9) for v in bsdf.inputs['Base Color'].default_value)
        rows.append((tuple(sorted(verts)), tuple(sorted(round(float(conf[i].value), 9) for i in poly.vertices)),
                     colour, round(float(bsdf.inputs['Roughness'].default_value), 9)))
    return sorted(rows), excluded

base_out, old_entry_faces = outside_entry(base, bp)
new_out, new_entry_faces = outside_entry(candidate, cp)
assert base_out == new_out, 'Geometry/material/confidence moved outside the front entrance box'
rows = []
for label, record, phase, target in [
    ('none-current-control', base, bp, P / 'none-current-control.glb'),
    ('entrance-proposal', candidate, cp, P / 'fixture/assets/gltf/sauganash_hotel__frame_1831.glb')]:
    assert not target.exists(), target
    start = time.monotonic()
    made = emit.emit_structure(record, phase, 'frame_tavern', target, bake=True, ao=False)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    if label == 'none-current-control':
        assert target.read_bytes() == (A / 'assets/gltf/sauganash_hotel__frame_1831.glb').read_bytes()
    rows.append({'label': label, 'path': str(target), 'sha256': digest,
                 'bytes': target.stat().st_size, 'triangles': made.tris, 'seconds': time.monotonic()-start})
(P / 'NATIVE-TRIAL.json').write_text(json.dumps({
    'status': 'ACTUAL_NATIVE_TWO_EMITS_DEFAULT_EXACT_AND_FRONT_ENTRY_ONLY_CHANGE',
    'rows': rows, 'none_current_master_exact': True,
    'outside_front_entry_polygons_materials_confidence_exact': len(base_out),
    'entry_box_m': {'u': [3.46, 6.46], 'v': [7.99, 8.6], 'z': [-.01, 3.3]},
    'entry_polygons': {'before': old_entry_faces, 'after': new_entry_faces},
    'limits': 'External prototype only, no production manifest/current26-family recipe adoption, WEB, app or ticket completion.'
}, indent=2) + '\n')
