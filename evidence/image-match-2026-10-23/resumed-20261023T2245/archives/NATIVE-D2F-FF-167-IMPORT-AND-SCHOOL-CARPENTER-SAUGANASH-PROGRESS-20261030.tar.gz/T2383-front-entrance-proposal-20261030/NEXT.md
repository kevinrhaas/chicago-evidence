# T-2383 finite entrance proposal — closed, not production adopted

Root directly viewed the current ef7ea827 hotel baseline and the one entrance-only
proposal on 2026-10-30, and accepted the taller case, side lights, transom and dark
blind centre. This is form acceptance of that one feature. It is not a full hotel
image match, actual app/ground acceptance or original-ticket completion.

The actual native None control reproduced current MASTER
`ef7ea827f577505cbee8142064394efcf38ff79795e220b5c247d980aa0d8b54`
exactly. Candidate MASTER is
`fe26f05ad82f1b50ddf8f48cee245b26562e351cdb92b6bfec506a58458ceec8`
(219840 bytes, 2716 triangles). The native producer proved all 1263 polygons outside
the bounded entrance region retained positions, actual Principled BSDF colour and
roughness, and per-vertex confidence. Two emits took 1.236 seconds including Blender
startup; native photo capture took 2.250 seconds. Both exited zero, all children were
reaped, scoped inputs stayed exact and caller workspace/TMP floors held.

All source/photo/framing/light fields of the camera equal the baseline. Only the
candidate solve prose was changed to state the correct prototype identity. Its
off-image principal point and uncertain drawing fit remain explicit. The old
38-degree roof/apex text inherited by the diagnostic camera is historical; the
actual body already has 25.2 degrees and existing Liberty
L-sauganash-lower-roof-fit-2383 records its near-apex projection around (636.5,350.1).
Clean that obsolete prose when preparing a canonical camera; do not refit or retune
the roof from it.

The optional `front_opening_details` group defaults to None. Its exact eight keys,
finite numeric ranges, reconstructed metric grade, frontage/two-storey context,
ordered heads, light/leaf clearance and neighbour-shutter clearance are validated.
Eight malformed input cases passed. The current structure schema also passed.
All exact dimensions and light divisions are reconstructed; the 1884 Andreas
engraving governs architectural categories, not historical metres or an interior.
Petford's exact original publication remains unverified and governs no new asset.

No primary source, Git, site mirror or ticket was changed. Prototype match remains
`differs`: lower front sash and full source-specific hotel/compound coverage remain
open. Broad body, roof, five bays, upper/end sash, rear wing and attested blue
shutters were retained. Carpenter's separate annex is not judged by this standalone
hotel view. No new photo tickets or additional geometry/camera iterations were made.

## Ready authored adoption, after the sole writer grants a source lease

`adoption/READINESS.json` binds four direct postimages against exact current
preimages: the current producer and parameter reader, the Sauganash record, and the
native entrance owner. It also describes two entrywise operations: append the one
name-pool note path while preserving every existing key/order, and append the one
Liberty fragment without changing earlier text. Never restore whole old registries.
The record's added research prose leaves resolved geometry parameters byte-for-byte
equivalent as data to the actual native prototype.

The entrance owner postimage reads 0.85 m from the selected phase's actual opt-in,
retaining its centred station. It preserves the 1.20 m None stock and Green Tree's
moved centre, rejects stale selected-phase footprints and records the native source
dependencies. Five meaningful cases of that actual proposed function passed. This
is function validation; native generation and app/clearance checks remain owed.

Changing either archetype module changes all current family recipes. Before any
production claim, enumerate the actual current family (26 at this checkpoint),
re-emit it through the official selected bake and refresh WEB/version bindings.
Assert every unselected native master stays exact; do not exclude Green Tree's
current opt-ins or manufacture a smaller family. This prototype has no production
manifest entry or WEB qualification.

After the accepted feature is adopted: run the native entrance owner and its
downstream derived owners; prepare fresh canonical hotel/source match metadata and
honest source-specific coverage; resolve the visible lower sash; then check BOTH
app viewports, credited Images/Sources/Liberties/Research, normal grade, actual
door/approach and neighbour clearance. Finish one source preflight, relevant native
smokes and phone check on the composed tree, one PR into dev, green CI and standard
merge. The original ticket stays open until its whole image gate is actually met.
