### L-sauganash-front-entrance-2383 — Sauganash's pictured entrance, reconstructed sections

**Covers:** `sauganash_hotel.frame_1831.form.front_opening_details`.

**Decision:** Follow the broad, high entrance case, transom and flanking narrow lights in F.Braunhold's engraving, published in Andreas1884. The source's form does not measure a historical door. Reconstruct a2.70m cornice, narrower2.10m jamb body,0.85m central dark leaf/recess,0.35m side lights,2.45m leaf head,3.00m transom top and3.18m crown. The narrower jamb body preserves the existing neighbouring blue shutters without overlap. Exact sections, light divisions and unseen fabric are reconstructed. The centre is a blind dark field over the closed facade, not an attested interior or a new walkable opening.

The previous generic door already included a transom; this is a correction to the whole profile and proportions, not discovery of an absent transom. The default-None archetype path remains unchanged. Main9.92×8m footprint,5.5m eave,25.2degree roof, cross-wing, placement, five-bay stations, lower/upper/rear sash and independently attested white/blue colours are retained. New numeric geometry carries reconstructed confidence; existing per-attribute/whole-building grades are not promoted.

**Source/date:** `andreas_1884_sauganash_hotel_plate`, with verified1884 US publication and its retrospective/dependent-image limits. Neither a filename's1831 label nor the later colour copies dates every feature to1July1835. Petford's exact original publication remains unverified; no new geometry or rights declaration derives from it. Monochrome Andreas does not overturn Wau-Bun's blue-shutter recollection.

**Qualification:** Root directly reviewed the finite current-camera native before/after and accepted the entrance form on2026-10-30. Native None/currenthotel MASTER was byte-identical;1263 polygons outside the entrance box retained their positions, actual BSDF colour/roughness and confidence. This is bounded form acceptance, not a full T-2383 image match, production26-family recipe freshness or app/ground acceptance. All source-specific hotel views and visible lowerfrontsash remain to be qualified. The0.85m primary access width must be read by the native entrance owner at adoption and assessed against actual grade/neighbours in both viewports.

**Recorded:** 2026-10-30 (T-2383).
