"""Read the actual proposed native owner function; no generated/primary writes."""
from pathlib import Path
import ast
import copy
import json
import sys
from types import SimpleNamespace

P = Path(__file__).resolve().parent.parent
A = Path('/workspace/chicago/chicago/4d')
sys.path.insert(0, str(P / 'fixture/generators'))
from archetypes.frame_tavern_params import from_phase

source = (P / 'adoption/generate_entrances.py').read_text()
fn = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == 'front_doors')
fake = SimpleNamespace(STRUCTURES=A / 'data/structures',
    _front_edge=lambda poly: (min(x[0] for x in poly), max(x[0] for x in poly), max(x[1] for x in poly)))
ns = {'gbs': fake, '_frame_tavern_params': from_phase, 'TAVERN_DOOR_W_M': 1.2}
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<actual proposed native front_doors>', 'exec'), ns)
reader = ns['front_doors']
results = []

def ask(record, phase_id):
    phase = next(p for p in record['phases'] if p['id'] == phase_id)
    sc = {'id': record['id'], 'archetype': 'frame_tavern', 'phase': phase_id,
          'footprint': copy.deepcopy(phase['footprint'])}
    fake._load = lambda path: record
    return reader(sc), sc

candidate = json.loads((P / 'sauganash_hotel.candidate.json').read_text())
(doors, by), sc = ask(candidate, 'frame_1831')
assert abs(doors[0]['u1'] - doors[0]['u0'] - .85) < 1e-12
assert abs((doors[0]['u1'] + doors[0]['u0']) / 2 - 4.96) < 1e-12
assert by == 'frame_tavern.front_opening_details (selected phase)'
results.append({'case': 'candidate actual selectedphase leaf width/centre', 'doors': doors, 'reader': by})
sc['footprint']['polygon'][0][0] += .01
try:
    reader(sc)
except ValueError as e:
    results.append({'case': 'candidate stale selectedphase footprint refused', 'reason': str(e)})
else:
    raise AssertionError('stale candidate sidecar accepted')

baseline = json.loads((A / 'data/structures/sauganash_hotel.json').read_text())
(doors, by), _ = ask(baseline, 'frame_1831')
assert abs(doors[0]['u1'] - doors[0]['u0'] - 1.2) < 1e-12
assert by == 'frame_tavern centred front door'
results.append({'case': 'None baseline retains1.2m centredstock', 'doors': doors, 'reader': by})
gt = json.loads((A / 'data/structures/green_tree_tavern.json').read_text())
(doors, by), sc = ask(gt, 'frame_1833')
gtp = from_phase(next(p for p in gt['phases'] if p['id'] == 'frame_1833'), gt)
assert abs(doors[0]['u1'] - doors[0]['u0'] - 1.2) < 1e-12
assert abs((doors[0]['u1'] + doors[0]['u0']) / 2 - gtp.resolved_front_ground_stations[0]) < 1e-12
assert by == 'frame_tavern.resolved_front_ground_stations (selected phase)'
results.append({'case': 'current GT preservesmovedcentreand1.2mstockreader', 'doors': doors, 'reader': by})
sc['footprint']['polygon'][0][0] += .01
try:
    reader(sc)
except ValueError as e:
    results.append({'case': 'current GT stale footprint refusal retained', 'reason': str(e)})
else:
    raise AssertionError('stale GT sidecar accepted')
(P / 'adoption/FRONT-READER-RESULT.json').write_text(json.dumps({
    'status': 'ACTUAL_PROPOSED_NATIVE_FRONT_READER_FIVE_CASES_PASS_NOT_APP_OR_GROUND_ACCEPTANCE',
    'results': results, 'primary_writes': False,
    'limits': 'Function-level actual owner source exercised through its native selectedphase decoder. Native generation/app/clearance still owed.'
}, indent=2) + '\n')
print('actual proposed native front reader: five meaningful cases PASS')
