#!/usr/bin/env python3
"""Run the single root-reviewed external prototype, never change primary files."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

P = Path(__file__).resolve().parent
plan = json.loads((P / 'PLAN.json').read_text())
if '--execute' not in sys.argv:
    raise SystemExit('Prepared only. Root CPU lease is required, then use --execute.')
if (P / 'EMIT-REAPER.json').exists() or (P / 'RESULT.json').exists():
    raise SystemExit('Refusing to repeat or overwrite a native trial.')

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def verify():
    for row in plan['preimages']['files'] + plan['members']:
        assert sha(row['path']) == row['sha256'], row['path']

def floor():
    free = {x: os.statvfs(x).f_bavail * os.statvfs(x).f_frsize for x in ['/workspace', '/tmp']}
    assert free['/workspace'] >= 536870912 and free['/tmp'] >= 1800000000, free
    return free

def native(label, command, cwd):
    verify()
    before = floor()
    started = time.monotonic()
    args = [sys.executable, '/workspace/shared/run-with-reaping.py', str(P / f'{label}-REAPER.json'), '--', *command]
    with (P / f'{label}.log').open('x') as log:
        done = subprocess.run(args, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
    reaper = json.loads((P / f'{label}-REAPER.json').read_text())
    verify()
    assert done.returncode == 0 and reaper['command_exit'] == 0, (done.returncode, reaper)
    assert reaper['all_children_reaped'] and not reaper['leftover_cleanup'], reaper
    return {'command': command, 'seconds': time.monotonic()-started, 'exit': done.returncode,
            'all_children_reaped': True, 'pre_free_B': before, 'post_free_B': floor()}

build = native('EMIT', ['nice', '-n', '19', 'taskset', '-c', '3,4',
    '/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender',
    '--background', '--factory-startup', '--threads', '2', '--python-exit-code', '1',
    '--python', str(P / 'native_trial.py')], str(P / 'fixture'))
assert json.loads((P / 'NATIVE-TRIAL.json').read_text())['none_current_master_exact']
temps_before = set(Path('/tmp').glob('photo-match-*'))
photo = native('PHOTO', ['taskset', '-c', '0,1,3,4', *plan['photo_command']], plan['photo_cwd'])
retained = []
for directory in sorted(set(Path('/tmp').glob('photo-match-*')) - temps_before):
    children = list(directory.iterdir())
    if len(children) == 1 and children[0].name.endswith('-render.png'):
        source = children[0]
        target = P / source.name
        before_sha = sha(source)
        with source.open('rb') as src, target.open('xb') as dst:
            shutil.copyfileobj(src, dst)
        shutil.copymode(source, target)
        assert sha(target) == before_sha
        source.unlink()
        directory.rmdir()
        retained.append({'path': str(target), 'sha256': before_sha})
verify()
result = {'status': 'ACTUAL_ONE_NATIVE_FRONT_ENTRANCE_PROPOSAL_CAPTURE_PASS_UNREVIEWED',
          'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'native_emit': build,
          'native_photo': photo, 'all_scoped_source_preimages_and_proposal_inputs_exact': True,
          'retained_native_public_renders': retained, 'post_free_B': floor(),
          'scope': 'External front-only appearance prototype, currentNoneMASTERexact. Not a current26-family production adoption, WEB, app/ground/imagegate acceptance or original-ticket completion.'}
(P / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
