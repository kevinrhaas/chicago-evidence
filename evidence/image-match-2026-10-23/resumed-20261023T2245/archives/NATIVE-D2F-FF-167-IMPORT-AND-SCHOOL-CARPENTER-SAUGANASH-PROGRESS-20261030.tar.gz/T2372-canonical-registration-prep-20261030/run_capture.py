from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,time,stat
P=Path(__file__).resolve().parent;plan=json.loads((P/'PLAN.json').read_text());rt=Path(plan['capture']['cwd']);R=Path('/workspace/chicago');A=R/'chicago/4d';sha=lambda b:hashlib.sha256(b).hexdigest();pf=lambda p:sha(p.read_bytes());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
assert os.environ.get('SCHOOL_CANONICAL_PHOTO_CPU')=='root-approved-after-phone-and-Carpenter-close'
assert not (P/'CAPTURE-RESULT.json').exists()
def floors():
 assert shutil.disk_usage('/workspace').free>=536870912
 assert shutil.disk_usage('/tmp').free>=1800000000
floors(); E=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1',PW_EXECUTABLE='/usr/bin/chromium',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
def state():
 git=lambda args:subprocess.check_output(['git','-C',str(R),*args],env=E)
 return {'head':git(['rev-parse','HEAD']).decode().strip(),'status_sha256':sha(git(['status','--porcelain=v1','-uno'])),'index_sha256':pf(R/'.git/index'),'config_sha256':pf(R/'.git/config'),'refs_sha256':sha(git(['show-ref']))}
# Primary refs may be updated by an explicitly leased remote import before this new command;
# this command snapshots current actual state and refuses any mutation while it runs.
before=state();inputs={}
for row in plan['native_modules']:
 assert pf(Path(row['source']))==pf(Path(row['runtime']))==row['sha256'];inputs[row['runtime']]=row['sha256'];inputs[row['source']]=row['sha256']
for row in plan['reused_closed_static']:
 assert pf(Path(row['source']))==pf(Path(row['frozen']))==row['sha256'];inputs[row['source']]=row['sha256'];inputs[row['frozen']]=row['sha256']
for row in plan['paths']:
 d=R/row['path']
 if d.exists():inputs[str(d)]=pf(d)
cam=Path(plan['camera']['runtime']);assert pf(cam)==plan['camera']['sha256'];inputs[str(cam)]=pf(cam)
photo=Path(plan['original_photo']['runtime']);assert pf(photo)==plan['original_photo']['sha256'];inputs[str(photo)]=pf(photo)
for p in [rt/'assets/manifest.json',rt/'assets/gltf/chappel_infant_school__log_1833.glb',rt/'assets/web/chappel_infant_school__log_1833.glb',rt/'data/sources/eliza_chappel_school_shore_view.json']:inputs[str(p)]=pf(p)
assert inputs[str(rt/'assets/gltf/chappel_infant_school__log_1833.glb')]=='fb141fef3f348b494ffbf1bc2479427d0cec499001605cdcb34ce52c93c0787a'
assert not cam.with_name('shore-drawing.match.json').exists()
short=Path('/workspace/sc2372p30');assert not short.exists();short.mkdir(mode=0o700);E['TMPDIR']=str(short)
log=P/'PHOTO.log';reap=P/'PHOTO-REAPER.json';args=['python3','/workspace/shared/run-with-reaping.py',str(reap),'--','nice','-n','19','taskset','-c','3,4',*plan['capture']['argv']];t=time.monotonic()
with log.open('x')as stream:q=subprocess.run(args,cwd=rt,env=E,stdout=stream,stderr=subprocess.STDOUT)
rr=json.loads(reap.read_text());assert q.returncode==0 and rr['command_exit']==0 and rr['all_children_reaped'],log.read_text()[-3000:]
raw=log.read_text();m=re.search(r'\n\s+(/[^\n]+-render\.png)\n',raw);assert m;png=Path(m.group(1));assert png.is_file() and png.is_relative_to(short)
shutil.copyfile(png,P/'ACTUAL-NATIVE.png');matchfile=cam.with_name('shore-drawing.match.json');rawmatch=json.loads(matchfile.read_text());assert rawmatch['verdict']=='unreviewed';assert rawmatch['glb']=='assets/gltf/chappel_infant_school__log_1833.glb';assert rawmatch['glb_sha256']==inputs[str(rt/'assets/gltf/chappel_infant_school__log_1833.glb')];assert rawmatch['camera_sha256']==pf(cam);assert rawmatch['photo_sha256']==pf(photo)
side=rt/rawmatch['side_by_side'];assert side==rt/'docs/RESEARCH/photo-match/chappel_infant_school/shore-drawing-side-by-side.jpg' and side.is_file()
shutil.copyfile(matchfile,P/'RAW-NATIVE-UNREVIEWED.match.json');shutil.copyfile(side,P/'ACTUAL-NATIVE-side-by-side.jpg')
assert state()==before
for p,h in inputs.items():assert pf(Path(p))==h
floors();result={'status':'ACTUAL_NATIVE_CANONICAL_PATH_CAMERA_CAPTURE_CLOSED_PASS_UNREVIEWED','at':now(),'actual_exit':q.returncode,'seconds':round(time.monotonic()-t,3),'all_children_reaped':True,'command':args,'cwd':str(rt),'camera_sha256':pf(cam),'GLB_sha256':rawmatch['glb_sha256'],'photo_sha256':rawmatch['photo_sha256'],'side_by_side_sha256':pf(side),'raw_match_sha256':pf(P/'RAW-NATIVE-UNREVIEWED.match.json'),'inputs_hashes_before_after_exact':inputs,'primary_state_before_after_exact':before,'native_default_manifest_selection':True,'canonical_relative_paths':True,'external_runtime_only_primary_adoption_not_claimed':True,'verdict':'unreviewed','published_app_ground_BOTH_and_fullpolicy_pending':True,'workspace_free':shutil.disk_usage('/workspace').free,'TMP_free':shutil.disk_usage('/tmp').free}
(P/'CAPTURE-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['inputs_hashes_before_after_exact','primary_state_before_after_exact']},indent=2),flush=True)
