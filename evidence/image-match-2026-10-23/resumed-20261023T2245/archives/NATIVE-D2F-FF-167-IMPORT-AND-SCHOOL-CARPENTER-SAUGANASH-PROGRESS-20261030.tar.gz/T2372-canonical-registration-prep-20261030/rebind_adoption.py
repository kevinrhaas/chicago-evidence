"""Prepare a new current-primary school packet, preserving foreign rows entrywise; never apply/stage/commit.

Use only a new --output directory. The frozen reviewed camera/model/photo inputs stay fixed. A changed native recipe or source photograph refuses rather than carrying an old review forward.
"""
from pathlib import Path
import argparse,copy,datetime,hashlib,json,os,stat,subprocess,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=Path('/workspace/chicago');A=R/'chicago/4d';SHA=lambda b:hashlib.sha256(b).hexdigest();PF=lambda p:SHA(p.read_bytes());ENC=lambda d:(json.dumps(d,indent=2,ensure_ascii=False)+'\n').encode();E=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1');SID='chappel_infant_school';NAME=SID+'__log_1833.glb'
def bound(p):
 if not p.exists():return None
 assert p.is_file() and not p.is_symlink(),p
 return {'bytes':p.stat().st_size,'sha256':PF(p),'mode':oct(stat.S_IMODE(p.stat().st_mode))}
def state():
 git=lambda args:subprocess.check_output(['git','-C',str(R),*args],env=E)
 return {'head':git(['rev-parse','HEAD']).decode().strip(),'status_sha256':SHA(git(['status','--porcelain=v1','-uno'])),'index_sha256':PF(R/'.git/index'),'config_sha256':PF(R/'.git/config'),'refs_sha256':SHA(git(['show-ref']))}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--expected-head',required=True);args=ap.parse_args();out=args.output.resolve();assert out.is_relative_to(P) and not out.exists();before=state();assert before['head']==args.expected_head
 template=json.loads((P/'ADOPTION-PLAN.json').read_text());assert template['total_paths']==12
 receipt=Path(template['actual_selected_owner_receipt']);assert PF(receipt)==template['selected_owner_receipt_sha256'];native=json.loads((receipt.parent/'closed-authority/NATIVE-ENTRIES.json').read_text())
 out.mkdir();source6=out/'source-six'
 subprocess.run(['python3','/workspace/T2372-currentGT-guarded-source-prep-20261030/prepare_current.py','--output',str(source6)],env=E,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 fresh=json.loads((source6/'PLAN.json').read_text());rows=fresh['source_paths'];assert len(rows)==6
 camrel=f'chicago/4d/data/reference_views/{SID}/shore-drawing.json';oldcam=next(r for r in template['paths']if r['path']==camrel);newcam=next(r for r in rows if r['path']==camrel);newcam.update({k:copy.deepcopy(v)for k,v in oldcam.items()if k not in ['before']})
 candidate=json.loads(Path(next(r for r in rows if r['path']==f'chicago/4d/data/structures/{SID}.json')['postimage']).read_text());sys.path.insert(0,str(A/'generators'));import mesh_inputs
 assert mesh_inputs.structure_inputs_sha(candidate,candidate['phases'][0])==template['recipe_sha256']==native['recipe_sha256']
 assert json.dumps(mesh_inputs.structure_inputs_doc(candidate,candidate['phases'][0]),sort_keys=True)==json.dumps(native['recipe_doc'],sort_keys=True)
 post=out/'postimages';registry_proofs={}
 for category,kind in [('gltf','native-master'),('web','native-web')]:
  rel=f'chicago/4d/assets/{category}/{NAME}';donor=receipt.parent/'closed-authority'/kind/NAME;rows.append({'path':rel,'before':bound(R/rel),'after':bound(donor),'postimage':str(donor),'action':'exact_closed_official_selected_owner_artifact'})
 for registry,key,value in [('manifest.json','assets',native['master']),('manifest.web.json','masters',native['web_master_sha256'])]:
  rel='chicago/4d/assets/'+registry;src=A/'assets'/registry;old=json.loads(src.read_text());new=copy.deepcopy(old);assert NAME in new[key];new[key][NAME]=value
  assert list(old[key])==list(new[key]);assert {n:v for n,v in old[key].items()if n!=NAME}=={n:v for n,v in new[key].items()if n!=NAME};assert {n:v for n,v in old.items()if n!=key}=={n:v for n,v in new.items()if n!=key}
  dest=post/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(ENC(new));dest.chmod(stat.S_IMODE(src.stat().st_mode));rows.append({'path':rel,'before':bound(src),'after':bound(dest),'postimage':str(dest),'action':'entrywise_actual_native_school_owner_row_only'});registry_proofs[registry]={'entry_key':NAME,'old_owned_entry':old[key][NAME],'actual_native_owned_entry':value,'all_foreign_rows_and_order_exact':True,'all_other_metadata_exact':True}
 for rel in [f'chicago/4d/data/reference_views/{SID}/shore-drawing.match.json',f'chicago/4d/docs/RESEARCH/photo-match/{SID}/shore-drawing-side-by-side.jpg']:
  old=next(r for r in template['paths']if r['path']==rel);row=copy.deepcopy(old);row['before']=bound(R/rel);rows.append(row)
 assert len(rows)==12
 template['paths']=rows;template['primary_before_after']=before;template['registry_proofs']=registry_proofs;template['at']=datetime.datetime.now(datetime.timezone.utc).isoformat();template['status']='CURRENT_REBOUND_TWELVE_SCHOOL_PATHS_NATIVE_FRESH_IMAGE_INPUTS_EXACT_NOT_APPLIED';template['source_rebind_proof']={'fresh_six_plan':str(source6/'PLAN.json'),'sha256':PF(source6/'PLAN.json'),'foreign_grade_STORE_Liberty_rows_preserved':True,'no_new_bake_or_capture':True}
 source=A/'data/sources/eliza_chappel_school_shore_view.json';assert PF(source)==template['source_catalogue']['sha256'];assert state()==before
 (out/'ADOPTION-PLAN.json').write_bytes(ENC(template));print(json.dumps({'status':template['status'],'paths':12,'head':before['head'],'output':str(out/'ADOPTION-PLAN.json'),'no_primary_mutations':True},indent=2))
if __name__=='__main__':main()
