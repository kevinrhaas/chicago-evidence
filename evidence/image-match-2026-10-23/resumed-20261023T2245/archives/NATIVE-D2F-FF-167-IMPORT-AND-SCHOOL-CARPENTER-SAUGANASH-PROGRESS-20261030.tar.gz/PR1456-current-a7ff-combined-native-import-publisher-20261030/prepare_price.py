from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import quote
import os,json,hashlib,zlib,datetime,importlib.util,base64,sys
os.sched_setaffinity(0,{1});os.nice(19)
O=Path(__file__).parent;A=Path('/workspace/currentdev-a7ff-bounded-price-publisher-20261030');NATIVE_BASE='a7ffed3c5108b20a24310f8a91ed4e0a18966b2e';OLD='dd1dfd88808ee36187825706cb71a5ad70bdd262'
s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
sha=lambda b:hashlib.sha256(b).hexdigest();save=lambda n,x:(O/n).write_text(json.dumps(x,indent=2)+'\n')
p=m.api('pulls/1456');HEAD=p['head']['sha'];ALLOW_CURRENT='--allow-current-dd1' in sys.argv
if ALLOW_CURRENT:assert HEAD==OLD,'Native head advanced beforealternativeprice; preserveactualheadanduse normalroute'
else:assert HEAD!=OLD,'Native updater has not pushed yet; defaultprepare refuses to invent a newhead'
rc=m.api('git/commits/'+HEAD)
if not ALLOW_CURRENT:assert [r['sha']for r in rc['parents']]==[OLD,NATIVE_BASE]
TIP=m.api('git/ref/heads/dev')['object']['sha'];assert TIP==NATIVE_BASE or m.api('compare/'+NATIVE_BASE+'...'+TIP)['status']=='ahead';tip_commit=m.api('git/commits/'+TIP)
base=json.loads((A/'RESULT.json').read_text());rows={r['sha']:{**r,'origin_tip':NATIVE_BASE}for r in base['rows']};newmeta=json.loads((A/'NEW-COMMIT-GITDATA.json').read_text());newmeta[HEAD]=rc;tiptrees={NATIVE_BASE:m.api('git/trees/'+base['tree']+'?recursive=1'),TIP:m.api('git/trees/'+tip_commit['tree']['sha']+'?recursive=1'),HEAD:m.api('git/trees/'+rc['tree']['sha']+'?recursive=1')};leafsets={};treemeta={}
def price(sid,kind,b,path,origin):
 assert m.gitsha(kind,b)==sid;enc=zlib.compress(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b)
 row={'sha':sid,'kind':kind,'path':path,'bytes':len(b),'sha256':sha(b),'encoded_bytes':len(enc),'encoded_sha256':sha(enc),'allocated_upper_4k':((len(enc)+4095)//4096)*4096,'origin_tip':origin}
 if sid in rows:
  assert all(rows[sid][k]==row[k]for k in ['sha','kind','bytes','sha256','encoded_bytes','encoded_sha256','allocated_upper_4k'])
 else:rows[sid]=row
for tip,t in tiptrees.items():
 assert not t['truncated'];leafsets[tip]={r['path']:r for r in t['tree']if r['type']!='tree'};groups={}
 for r in t['tree']:
  parent,_,name=r['path'].rpartition('/');groups.setdefault(parent,[]).append((name,r))
 roots={'':t['sha'],**{r['path']:r['sha']for r in t['tree']if r['type']=='tree'}};known=m.indexed(roots.values())
 for path,sid in roots.items():
  if sid in known or sid in treemeta:continue
  entries=sorted(groups[path],key=lambda x:x[0].encode()+(b'/'if x[1]['type']=='tree'else b''));b=b''.join((('40000'if r['type']=='tree'else r['mode']).encode()+b' '+n.encode()+b'\0'+bytes.fromhex(r['sha']))for n,r in entries);treemeta[sid]=b;price(sid,'tree',b,path,tip)
 blobs={r['sha']:r for r in leafsets[tip].values()if r['type']=='blob'};known=m.indexed(blobs)
 for sid,r in blobs.items():
  if sid in known or sid in rows:continue
  assert r['size']<=64*1024**2,'Singleimmutableblobexceeds existing64MiBcombinedbound'
  with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+tip+'/'+quote(r['path'],safe='/'),headers={'User-Agent':'Chicago-current1456-combined-readonly-price'}),timeout=60)as f:b=f.read(r['size']+1);assert f.status==200
  assert len(b)==r['size'];price(sid,'blob',b,r['path'],tip)
def reconstruct(c):
 v=c['verification'];payload=v.get('payload');sig=v.get('signature')
 if payload and sig:
  h,msg=payload.encode().split(b'\n\n',1)
  for signature in [sig.encode(),sig.encode().rstrip(b'\n')]:
   b=h+b'\ngpgsig '+b'\n '.join(signature.split(b'\n'))+b'\n\n'+msg
   if m.gitsha('commit',b)==c['sha']:return b
 if not sig:
  def actor(k,tz):
   x=c[k];dt=datetime.datetime.fromisoformat(x['date'].replace('Z','+00:00'));return k+' '+x['name']+' <'+x['email']+'> '+str(int(dt.timestamp()))+' '+tz
  for tz in ['+0000','-0500','-0600']:
   h=['tree '+c['tree']['sha'],*['parent '+r['sha']for r in c['parents']],actor('author',tz),actor('committer',tz)]
   for end in ['', '\n']:
    b=('\n'.join(h)+'\n\n'+c['message']+end).encode()
    if m.gitsha('commit',b)==c['sha']:return b
 raise AssertionError('Canonicalcommit refused '+c['sha'])
pending=[TIP];seen=set()
while pending:
 sid=pending.pop()
 if sid in seen or sid in m.indexed([sid]):continue
 seen.add(sid);assert len(seen)<=16,'Refuse unbounded additionalcommitDAG'
 c=newmeta.get(sid)or m.api('git/commits/'+sid);newmeta[sid]=c;pending.extend(r['sha']for r in c['parents'])
for sid,c in newmeta.items():price(sid,'commit',reconstruct(c),'exact immutable native GitData commit',HEAD if sid==HEAD else TIP)
allrows=list(rows.values());assert sum(r['bytes']for r in allrows)<128*1024**2,'Concretecombinedthree-treepayloadexceeds128MiBread-onlypricingceiling'
v={'status':'ACTUAL_COMBINED_A7FF_AND_NATIVE1456_PRICE_ONLY_NO_PRIMARY_WRITES','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tip':TIP,'tree':tip_commit['tree']['sha'],'native_updater_base':NATIVE_BASE,'native_updater_base_tree':base['tree'],'secondary_head':HEAD,'secondary_tree':rc['tree']['sha'],'secondary_parents':[r['sha']for r in rc['parents']],'new_total_objects':len(allrows),'new_total_raw_bytes':sum(r['bytes']for r in allrows),'new_total_allocation_upper_4k':sum(r['allocated_upper_4k']for r in allrows),'required_workspace_bytes':536870912+16777216+1048576+sum(r['allocated_upper_4k']for r in allrows),'workspace_free':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize,'tmp_free':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'source_phase_expected_HEAD':OLD,'source_phase_expected_origin_dev':'87c03bcfba9d896227fe4a030c9a7b6d0823d45f','source_phase_expected_branch':'steward/t2376-green-tree-current87-20261030','primary_source_Git_writes':False,'fetch':False,'alternative_current_dd1_price':ALLOW_CURRENT,'pricing_raw_envelope_bytes':128*1024**2,'previous_raw_envelope_bytes':64*1024**2,'execution_requires_root_review_actual_price':True,'rows':allrows}
save('COMBINED-PRICE.json',v);save('NEW-COMMIT-GITDATA.json',newmeta);save('REMOTE-COMMIT.json',tip_commit);save('NATIVE-REMOTE-COMMIT.json',rc);print(json.dumps({k:x for k,x in v.items()if k!='rows'},indent=2))
