#!/usr/bin/env python3
"""One authorized native diagnostic; all writes stay in this external packet."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

packet = Path(__file__).resolve().parent
plan = json.loads((packet / 'CAPTURE-PLAN.json').read_text())
if '--execute' not in sys.argv:
    raise SystemExit('Prepared only. Root CPU lease is required; then use --execute.')
if (packet / 'ACTUAL-CAPTURE.json').exists() or (packet / 'native-reaper.json').exists():
    raise SystemExit('Refusing to repeat or overwrite an actual capture.')

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def floor():
    values = {p: os.statvfs(p).f_bavail * os.statvfs(p).f_frsize for p in ['/workspace', '/tmp']}
    assert values['/workspace'] >= plan['floors_B']['workspace'], values
    assert values['/tmp'] >= plan['floors_B']['tmp'], values
    return values

def verify():
    for row in plan['binding_rows']:
        assert digest(row['path']) == row['sha256'], row['path']

verify()
before = floor()
temp_before = set(Path('/tmp').glob('photo-match-*'))
started = time.monotonic()
cmd = [sys.executable, '/workspace/shared/run-with-reaping.py', str(packet / 'native-reaper.json'), '--',
       'taskset', '-c', '0,1,3,4', *plan['command']]
with (packet / 'native.log').open('x') as log:
    run = subprocess.run(cmd, cwd=plan['cwd'], stdout=log, stderr=subprocess.STDOUT)
seconds = time.monotonic() - started
verify()
reaper = json.loads((packet / 'native-reaper.json').read_text())
assert reaper['all_children_reaped'], reaper
assert reaper['command_exit'] == run.returncode, reaper
temps = []
for p in sorted(set(Path('/tmp').glob('photo-match-*')) - temp_before):
    # Native public render only, never a browser profile or unrelated scratch.
    children = list(p.iterdir())
    if len(children) == 1 and children[0].name.endswith('-render.png'):
        target = packet / children[0].name
        assert not target.exists()
        children[0].rename(target)
        p.rmdir()
        temps.append({'native_temp_dir': str(p), 'retained_render': str(target), 'sha256': digest(target)})
after = floor()
result = {'status': 'ACTUAL_NATIVE_CURRENT_HOTEL_DIAGNOSTIC_CAPTURE_PASS_UNREVIEWED' if run.returncode == 0 else 'ACTUAL_NATIVE_CURRENT_HOTEL_DIAGNOSTIC_CAPTURE_FAILED',
          'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'seconds': seconds,
          'native_exit': run.returncode, 'all_scoped_bindings_unchanged': True,
          'all_children_reaped': reaper['all_children_reaped'], 'before_free_B': before, 'after_free_B': after,
          'native_public_temp_outputs_retained': temps,
          'scope': 'Current ef7ea827 main hotel only in an uncertain own-hotel camera. Not an app/terrain/annex acceptance, canonical camera, source change, or original-ticket completion.'}
(packet / 'ACTUAL-CAPTURE.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
raise SystemExit(run.returncode)
