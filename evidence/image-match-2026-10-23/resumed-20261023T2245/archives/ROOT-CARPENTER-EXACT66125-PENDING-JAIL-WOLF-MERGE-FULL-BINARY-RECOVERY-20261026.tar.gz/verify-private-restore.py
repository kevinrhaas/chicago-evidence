from pathlib import Path
import subprocess,os,json,datetime,hashlib
B=Path('/tmp/Root-current66125-recovery-closed-20261026T2025');P=Path('/tmp/Root66125-isolated-index-restore-20261026T2025');P.mkdir(exist_ok=False);G=P/'repo.git';env=dict(os.environ,GIT_DIR=str(G),GIT_INDEX_FILE=str(P/'recovery.index'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/workspace/chicago/.git/objects',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');os.sched_setaffinity(0,{2});os.nice(10)
def cmd(*args):return subprocess.check_output(['git',*args],env=env,stderr=subprocess.STDOUT)
subprocess.check_output(['git','init','--bare',str(G)],stderr=subprocess.STDOUT)
cmd('read-tree','b3fb939f510a4ffe009a7c45f104ddadc76d3761');cmd('apply','--cached','--binary','--whitespace=nowarn',str(B/'CURRENT-INDEX-vs-HEAD.binary.patch'));tree=cmd('write-tree').decode().strip();assert tree=='66125b5b2cadc30c405f852f470f5f69117dce39'
listing=cmd('ls-files','--stage','-z');assert listing==(B/'CURRENT-INDEX-STAGE-LISTING.z').read_bytes()
result={'status':'ACTUAL_FULL_BINARY_PATCH_RESTORED_EXACT66125_IN_NEW_ISOLATED_INDEX','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tree':tree,'index_listing_sha256':hashlib.sha256(listing).hexdigest(),'source_object_access':'READONLY_ALTERNATE_ONLY_NO_FETCH_NO_SOURCE_INDEX_OR_REF_CONFIG_WRITE','new_isolated_git_dir':str(G),'source_worktree_touched':False,'all_index_paths_blobs_modes_exact':True,'patch_bytes':(B/'CURRENT-INDEX-vs-HEAD.binary.patch').stat().st_size}
(B/'ACTUAL-ISOLATED-INDEX-RESTORE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
