Carpenter’s log annex now uses the existing blind doorway recess, following the dark doorway in the Andreas engraving. Its Images card displays the credited reproduction. The doorway keeps its existing size and position; the 0.30 m shadow treatment is recorded as reconstructed and adds no interior or passable entrance.

The held reproduction resolves the engraver’s signed surname, Braunhold; the given name remains unresolved. The compound camera remains provisional and is marked diagnostic-only. The original T-2382 image gate remains **DIFFERS**, with the broader annex/hotel massing and camera discrepancies recorded in the existing match register.

The native image-library rebuild also refreshes 90 existing parcel cross-references and the site plan (156 → 182 parcels) against the unchanged committed 1904 grid. Every resulting parcel ID and polygon comes from that grid; existing image-source fields remain unchanged. The early picture has no Prairie building or parcel identity. The hosted display and thumbnail were added through chicago-images PR #5 and verified by their public bytes.

Validation and dependency status are recorded below before this draft becomes ready. This PR targets `dev`; it does not promote production.
