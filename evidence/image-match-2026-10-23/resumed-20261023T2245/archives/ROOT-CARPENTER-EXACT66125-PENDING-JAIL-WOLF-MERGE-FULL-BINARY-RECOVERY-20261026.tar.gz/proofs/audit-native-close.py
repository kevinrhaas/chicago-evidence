from pathlib import Path
import subprocess, json, hashlib, gzip, zipfile, io, shutil, datetime
import xml.etree.ElementTree as ET

root = Path('/tmp/jail-picture-c6')
out = Path('/workspace/T2382-currentdev-integration-20261026')
binding = json.loads((out/'CURRENT-NATIVE-BINDING.json').read_text())
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])
assert git('rev-parse','HEAD').decode().strip() == binding['head']
assert git('rev-parse','MERGE_HEAD').decode().strip() == binding['merge']
assert not git('ls-files','-u').strip(), 'Canonical resolve has not completed'
reaped = json.loads((out/'current-native-resolve-reaper.json').read_text())
assert reaped['command_exit'] == 0 and reaped['all_children_reaped']
for p, digest in binding['authored'].items():
    assert hashlib.sha256((root/p).read_bytes()).hexdigest() == digest, p
for p, info in binding['models'].items():
    assert hashlib.sha256((root/p).read_bytes()).hexdigest() == info['sha256'], p

def xml_node(n):
    text = n.text
    if text is not None and not text.strip() and len(n):
        text = None
    return n.tag, tuple(sorted(n.attrib.items())), text, n.tail if n.tail and n.tail.strip() else None, tuple(xml_node(c) for c in n)
def equivalent(a, b, name):
    if name.endswith('.gz'):
        return gzip.decompress(a) == gzip.decompress(b), 'exact decompressed stream'
    za, zb = zipfile.ZipFile(io.BytesIO(a)), zipfile.ZipFile(io.BytesIO(b))
    if sorted(za.namelist()) != sorted(zb.namelist()):
        return False, 'ZIP members differ'
    for part in sorted(za.namelist()):
        aa, bb = za.read(part), zb.read(part)
        same = xml_node(ET.fromstring(aa)) == xml_node(ET.fromstring(bb)) if part.endswith(('.xml','.rels')) else aa == bb
        if not same:
            return False, 'full member differs: '+part
    return True, 'all XML values/attributes and non-XML members equal'

rows, restore = [], {}
for p, info in binding['binaries'].items():
    actual = (root/p).read_bytes()
    row = {'path':p, 'incoming_sha256':info['sha256'], 'native_sha256':hashlib.sha256(actual).hexdigest()}
    if row['native_sha256'] != info['sha256']:
        baseline = git('show', binding['head']+':'+p)
        assert hashlib.sha256(baseline).hexdigest() == info['sha256']
        saved = out/'raw-native-binary-serialization'/p
        saved.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(root/p,saved)
        row['semantic_equal'], row['comparison'] = equivalent(actual,baseline,p)
        row['raw_generated_saved'] = str(saved)
        restore[p] = baseline
    else:
        row['byte_equal'] = True
    rows.append(row)
outside = {p for p in git('diff','HEAD','--name-only').decode().splitlines() if not p.startswith('chicago/4d/')}
unknown = sorted(outside-set(binding['allowed_outside4d'])-set(restore))
proof = {'status':'PASS' if not unknown and all(r.get('semantic_equal',True) for r in rows) else 'FAIL', 'at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'actual_incoming':binding['head'], 'whole_binary_count':len(rows), 'authored_unchanged':len(binding['authored']), 'physical_model_files_unchanged':len(binding['models']), 'intentional_outside4d':binding['allowed_outside4d'], 'unclassified_outside4d':unknown, 'records':rows, 'restored_after_full_audit':[]}
(out/'CURRENT-ALL44-AND-SCOPE-AUDIT.json').write_text(json.dumps(proof,indent=2)+'\n')
assert proof['status']=='PASS', 'Semantic changes preserved; no restoration performed'
for p,data in restore.items():
    (root/p).write_bytes(data)
if restore:
    git('add','--',*restore)
proof['restored_after_full_audit'] = list(restore)
(out/'CURRENT-ALL44-AND-SCOPE-AUDIT.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'status':'PASS','whole44':len(rows),'serialization_only_restored':len(restore),'authored_exact':len(binding['authored']),'models_exact':len(binding['models'])}))
