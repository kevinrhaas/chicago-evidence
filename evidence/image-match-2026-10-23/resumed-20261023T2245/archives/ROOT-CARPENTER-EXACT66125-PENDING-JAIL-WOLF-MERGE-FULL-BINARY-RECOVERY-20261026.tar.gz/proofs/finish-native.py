from pathlib import Path
import json, os, subprocess, time, datetime, shutil

root = Path('/tmp/jail-picture-c6/chicago/4d')
out = Path('/workspace/T2382-currentdev-integration-20261026')
receipt = out/'current-native-resolve-reaper.json'
os.sched_setaffinity(0,{0,1,3,4})
while not receipt.exists():
    time.sleep(3)
native = json.loads(receipt.read_text())
assert native['command_exit'] == 0 and native['all_children_reaped'], native
print('Canonical native resolve completed and reaped',flush=True)
commands = [
    (['python3',str(out/'audit-native-close.py')],'current-native-all44-audit.log'),
    (['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'],'current-package5.log'),
    (['bash','tools/publish.sh'],'current-publish.log'),
]
results=[]
for command, logname in commands:
    assert shutil.disk_usage('/tmp').free >= 512*1024**2
    assert int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text()) >= 512*1024**2
    print('START',command,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
    with (out/logname).open('x') as log:
        p=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    results.append({'command':command,'exit_code':p.returncode,'log':logname})
    print('CLOSED',p.returncode,logname,flush=True)
    if p.returncode:
        break
passed=len(results)==len(commands) and all(r['exit_code']==0 for r in results)
status={'status':'PASS' if passed else 'FAIL','finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':results,'scope':'Native owning closure, actual incoming44binary audit and package/publish only. App review, whole preflight and codecommit/PR remain pending.'}
(out/'CURRENT-NATIVE-PACKAGE-PUBLISH-RESULT.json').write_text(json.dumps(status,indent=2)+'\n')
raise SystemExit(0 if passed else 1)
