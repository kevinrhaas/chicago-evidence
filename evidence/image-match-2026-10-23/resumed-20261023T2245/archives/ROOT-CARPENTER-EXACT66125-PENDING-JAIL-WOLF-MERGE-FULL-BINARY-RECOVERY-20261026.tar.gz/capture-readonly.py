from pathlib import Path
import os,subprocess,json,hashlib,shutil,time,datetime,stat
R=Path('/tmp/jail-picture-c6');P=Path('/workspace/T2382-currentdev-integration-20261026');O=Path('/tmp/Root-current66125-recovery-closed-20261026T2025');TRUST=Path('/tmp/carpenter-browser-trust-20261026');TREE='66125b5b2cadc30c405f852f470f5f69117dce39';HEAD='b3fb939f510a4ffe009a7c45f104ddadc76d3761';MERGE='562a4a9adaee706a97ea3b83b06b6cda89a69fc4'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');os.sched_setaffinity(0,{2})
def git(*args):return subprocess.check_output(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false',*args],env=env)
def sha(data):return hashlib.sha256(data).hexdigest()
def save(name,data,mode=0o600):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(mode)
def js(name,x):save(name,(json.dumps(x,indent=2)+'\n').encode())
def read_json(path):
 for n in range(4):
  try:
   data=path.read_bytes();value=json.loads(data);return data,value
  except (json.JSONDecodeError,OSError):
   if n==3:raise
   time.sleep(.1)
def snap():
 gd=Path(git('rev-parse','--absolute-git-dir').decode().strip());ids={str(p):sha(p.read_bytes())for p in [gd/'HEAD',gd/'index',gd/'MERGE_HEAD']if p.is_file()}
 return {'HEAD':git('rev-parse','HEAD').decode().strip(),'MERGE_HEAD':git('rev-parse','MERGE_HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'git_metadata_sha256':ids,'index_listing_sha256':sha(git('ls-files','--stage','-z')),'unstaged_names':git('diff','--name-only').decode().splitlines(),'untracked':git('ls-files','--others','--exclude-standard','-z').decode().split('\0')[:-1]}
before=snap();assert before['HEAD']==HEAD and before['MERGE_HEAD']==MERGE;assert before['branch']=='steward/t2382-carpenter-picture-currentdev';assert not before['unstaged_names']and not before['untracked'];assert not git('ls-files','--unmerged').strip()
index=git('ls-files','--stage','-z');source={}
for row in index.split(b'\0'):
 if row:
  left,name=row.split(b'\t',1);mode,blob,stage=left.decode().split();assert stage=='0';source[name.decode()]=(mode,blob)
actual={}
for row in git('ls-tree','-r','-z',TREE).split(b'\0'):
 if row:
  left,name=row.split(b'\t',1);mode,typ,blob=left.decode().split();actual[name.decode()]=(mode,blob)
assert actual==source,'Frozen staged index differs from exact66125 tree'
patch=git('diff','--cached','--binary','--full-index','--no-ext-diff','--no-textconv','HEAD');assert 0<len(patch)<32*1024**2
save('CURRENT-INDEX-vs-HEAD.binary.patch',patch);save('CURRENT-INDEX-STAGE-LISTING.z',index);save('CURRENT-INDEX-NUMSTAT.txt',git('diff','--cached','--numstat','HEAD'));save('CURRENT-INDEX-RAW.txt',git('diff','--cached','--raw','--full-index','HEAD'));js('SOURCE-BEFORE.json',before)
# Preserve the ordinary pending merge message without reading any source config.
gitdir=Path(git('rev-parse','--absolute-git-dir').decode().strip())
if (gitdir/'MERGE_MSG').is_file():save('MERGE_MSG', (gitdir/'MERGE_MSG').read_bytes())
# Only completed reviews may be copied. Full3 and unfinished browser logs are excluded.
review_status={};excluded=[];allowed_review_dirs=set();skip_top={'current-full3-controller.log','current-full3-reaper.json'}
for reaper in P.glob('published-app-review-reaper-*.json'):
 raw,value=read_json(reaper);stamp=reaper.name.removeprefix('published-app-review-reaper-').removesuffix('.json');review_status[stamp]=value
 if value.get('command_exit')is not None and value.get('all_children_reaped'):
  allowed_review_dirs.add('published-app-review-'+stamp)
 else:
  skip_top.update({reaper.name,'published-app-review-'+stamp+'.log'});excluded.append({'path':str(reaper),'reason':'ACTIVE_REAPER_SNAPSHOT_ONLY_NOT_COMPLETION'})
raw_inventory=[]
for path in sorted((P/'raw-native-binary-serialization').rglob('*')):
 if path.is_file():
  data=path.read_bytes();raw_inventory.append({'path':str(path.relative_to(P)),'bytes':len(data),'mode':stat.S_IMODE(path.stat().st_mode),'sha256':sha(data),'payload_published':False,'reason':'Concise raw serialization inventory requested; canonical candidate bytes recoverable in full staged binary patch and native44 audit included.'})
js('RAW-NATIVE-SERIALIZATION-INVENTORY.json',{'files':raw_inventory,'payloads_intentionally_not_duplicated':True})
proofs=[];proof_bytes=0
for path in sorted(P.rglob('*')):
 if not path.is_file()or path.is_symlink():continue
 rel=path.relative_to(P);parts=rel.parts
 if parts[0]=='raw-native-binary-serialization':continue
 if parts[0]=='current-full3':
  if str(rel)!='current-full3/BINDING.json':continue
 elif parts[0].startswith('published-app-review-')and path.parent!=P:
  if parts[0]not in allowed_review_dirs:
   excluded.append({'path':str(path),'reason':'FUNCTIONAL_REVIEW_NOT_FULLY_REAPED_AT_CAPTURE'});continue
 elif path.parent==P and path.name in skip_top:continue
 # Stable closed proof read. No follow-on live/controller output admitted.
 size_before=path.stat().st_size;data=path.read_bytes();assert len(data)==size_before
 proof_bytes+=len(data);assert proof_bytes<32*1024**2,'Closed proofs exceed bounded32MiB plan'
 save('proofs/'+str(rel),data,stat.S_IMODE(path.stat().st_mode));proofs.append({'source':str(path),'path':'proofs/'+str(rel),'bytes':len(data),'sha256':sha(data)})
js('PROOF-SOURCE-INVENTORY.json',proofs)
fullraw,fullstatus=read_json(P/'current-full3-reaper.json');save('active-status/current-full3-reaper-SNAPSHOT.json',fullraw)
js('active-status/BROWSER-REAPERS-SNAPSHOT.json',review_status)
js('EXCLUDED-LIVE-AND-DUPLICATE-PAYLOADS.json',excluded)
for name in ['CONFIGURATION.json','BROWSER-PROBE.json','probe-reaper.json']:
 data,value=read_json(TRUST/name)
 if name=='probe-reaper.json':assert value['command_exit']==0 and value['all_children_reaped']
 if name=='BROWSER-PROBE.json':assert value['noCertificateErrorBypass']is True
 save('browser-trust/'+name,data,stat.S_IMODE((TRUST/name).stat().st_mode))
# The exact review controller is closed program text, not a browser profile.
review_program=Path('/workspace/T2382-Carpenter-adoption-20261026/review-published.mjs')
if review_program.is_file():save('programs/review-published.mjs',review_program.read_bytes(),stat.S_IMODE(review_program.stat().st_mode))
after=snap()
for key in ['HEAD','MERGE_HEAD','branch','index_listing_sha256','unstaged_names','untracked']:assert after[key]==before[key], 'Root semantic source changed during readonly capture: '+key
for path,value in before['git_metadata_sha256'].items():
 if Path(path).name!='index':assert after['git_metadata_sha256'][path]==value
js('SOURCE-AFTER.json',after)
binding=json.loads((O/'proofs/current-full3/BINDING.json').read_text());assert binding['staged_tree']==TREE and binding['head']==HEAD and binding['merge_head']==MERGE
state={'closed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CLOSED_EXACT66125_PENDING_MERGE_RECOVERY_SOURCE_READONLY','HEAD':HEAD,'MERGE_HEAD':MERGE,'staged_tree':TREE,'staged_index_matches_full_tree_paths_blobs_modes':True,'index_entries':len(source),'staged_patch_bytes':len(patch),'staged_patch_sha256':sha(patch),'branch':before['branch'],'checked_Jail_commit':binding['actual_checked_Jail_commit'],'checked_Jail_delta_tree':binding['checked_Jail_delta_tree'],'actual_dev':binding['actual_dev'],'full3_STATUS_AT_CAPTURE':fullstatus,'full3_result_claim':'PENDING_UNLESS_A_SEPARATE_TERMINAL_PACKET_PROVES_OTHERWISE','functional_review_snapshots':review_status,'closed_review_directories_included':sorted(allowed_review_dirs),'native44_package_publish_scope':'Closed incoming44 audit and selected native/package/publish proof only; combined whole3/app/codecommit/PR remain pending','browser_trust':'ONLY CONFIGURATION.json BROWSER-PROBE.json probe-reaper.json; no profile/LocalState/cookies/certificate-bypass','HEAD_MERGE_staged_entries_and_clean_worktree_before_after_exact':True,'raw_index_serialization_before_after_equal':after['git_metadata_sha256']==before['git_metadata_sha256'],'source_writes_by_publisher':False,'untracked_files':[],'unstaged_files':[],'raw_serialization_inventory_only':raw_inventory,'native_owning_source_evidence_fields_unchanged':True}
js('STATE.json',state)
recovery='''# Exact Root Carpenter integration recovery, source read only\n\nFrozen staged tree66125b5b2cadc30c405f852f470f5f69117dce39 has HEADb3fb939f510a4ffe009a7c45f104ddadc76d3761 and pending normal MERGE_HEAD562a4a9adaee706a97ea3b83b06b6cda89a69fc4. Full staged binary-safe patch against HEAD and every index path/mode/blob are captured. The staged index is entrywise exact to66125; no unstaged or untracked files existed. Source HEAD/MERGE_HEAD, staged path/blob/mode entries and clean worktree before/after capture are exact. Raw index serialization hashes are separately recorded; an initial strict capture stopped when active native gating changed only raw index metadata while the logical staged66125 tree stayed exact. No publisher source/index write occurred. Checked public Jailbbbe518720601b785e79628bf247ee4b9f9d4ed8/tree897824de authored delta is already included; attaching its normal ancestry after checked Wolf merge remains author-owned and needs exact full-tree equality for any source-identical gate reuse. No source state was modified by publication.\n\nRestore ONLY in a NEW private checkout/worktree; leave active authors untouched. Start at immutable HEADb3fb, begin an ordinary no-commit/no-ff merge of immutable Wolf562 and preserve its pending merge ancestry. In that new recovery worktree, reset only index/worktree via read-tree --reset -u HEAD (do not use git reset, which clears merge state), then apply CURRENT-INDEX-vs-HEAD.binary.patch with git apply --index --binary. Verify recovered write-tree equals66125 and HEAD/MERGE_HEAD remain the exact two parents above. Verify every index path/mode/blob against CURRENT-INDEX-STAGE-LISTING.z and that no unstaged/untracked files remain. An isolated metadata-only Git reconstruction may also derive66125 from this patch; do not broad-fetch into the20GB shared source Git. Only then resume native/ending/ancestry checks under current policy and normal guarded dev PR operations. No force/public branch overwrite or main app promotion is authorized by this recovery record.\n\nCombined current full3 is ACTIVE/PENDING in the separately labeled active-status snapshot. The closed runner and full3 BINDING are included; live gate log/controller output is excluded. Functional review2022 is included ONLY if its own reaper had terminal exit and all children reaped at capture; otherwise only its active status is recorded. Earlier terminated review failures and closed native44/package/publish receipts remain preserved as scoped evidence, never combined whole-gate success. The two raw native-serialization payloads are intentionally inventory-only to avoid redundant bytes; their hashes/modes/sizes and incoming44 canonical comparison are explicit.\n\nBrowser trust stores ONLY the three requested JSON receipts. The exact-host certificate-database probe succeeded without ignoring TLS errors. No browser profile, Local State, cookies or certificate database is included. No original ticket DONE, current app-wide pass, READY or merge claim is made.\n'''
save('RECOVERY.md',recovery.encode())
rows=[]
for path in sorted(O.rglob('*')):
 if path.is_file()and path.name!='MANIFEST.json':rows.append({'path':str(path.relative_to(O)),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'mode':stat.S_IMODE(path.stat().st_mode)})
js('MANIFEST.json',{'status':'CLOSED_ROOT_EXACT66125_PENDING_MERGE_RECOVERY_SOURCE_READONLY','files':rows});print(json.dumps({'manifest_sha256':sha((O/'MANIFEST.json').read_bytes()),'source_files':len(rows),'source_bytes':sum(x['bytes']for x in rows),'staged_tree':TREE,'patch_bytes':len(patch),'proof_bytes':proof_bytes,'full3_exit_at_capture':fullstatus['command_exit'],'review2022_exit':review_status.get('20261026T2022',{}).get('command_exit')}))
