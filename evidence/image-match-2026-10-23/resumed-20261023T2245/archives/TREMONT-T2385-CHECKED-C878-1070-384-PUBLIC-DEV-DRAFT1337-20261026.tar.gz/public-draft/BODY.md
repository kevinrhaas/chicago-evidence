The first Tremont now follows Gale’s retrospective walk framed in 1835: a smaller **30 × 20 ft, two-storey yellow hotel**. Units and natural long/short axes are inferred; wall height and stock colours remain reconstructed. Both Lake and Dearborn street frontages stay fixed, and the native flag anchor follows the smaller roof staff.

The native `gifford-reading` version preserves the earlier three-storey picture interpretation, including its reconstructed larger scale, unpainted walls and shutters. Gifford’s depiction is undated within the first house’s life; no enlargement date is invented. The default omits shutters as a disclosed native-kit simplification. **Original T-2385 remains OPEN/DIF:** the two-storey default does not match the drawing’s real third storey.

The existing lodging model now reports six ordinary-night beds at Tremont, against twelve unchanged residents and its unchanged crowded proxy of 35. Eight other ordinary estimates rebalance under the same class total. All resident identities, homes, seats, firms, quotas and historical allocation remain unchanged; business/staffing leaf reports now carry those current figures. This is not an attested room or bed count.

Sources: [Gale 1902, printed p. 51](https://archive.org/details/reminiscencesofe00ingale/page/n76/mode/1up), with its 1835 context on pp. 25 and 43; [attributed Gifford drawing on Chicagology](https://chicagology.com/prefire/prefire021/). The drawing retains the user’s project-reference approval without inventing public-domain provenance.

Validation:

- Two genuine native masters and two compressed WEB derivatives; the alternate is byte-exact to the prior picture-led model. Fresh a575 native downstream closure, actual 44-file serialization audit, package and publish passed. Four published strict placement/smoke-tool repairs are carried with their positive and negative fixtures.
- Full local three-question preflight passed on tree `9092fd814e577c9b7b7c55221f1f4b90b013fb48`: all 1,070 steps (including 384 self-tests), changelog entry and ID checks. Normal commit `c878258c511eb4854ffbd93c5c08ba2e0b8ea9a1` and both actual committed-head checks passed; all wrappers closed with every child reaped.
- Four earlier targeted app loads bind unchanged mesh/version/flag appearance: three actual passes and one qualified original harness failure with exact stale-property diagnosis preserved. They do not certify the final whole-world ground or performance.
- **DRAFT:** fresh 18-leg renderer renderer coverage on this exact public head remains required before ready/merge. No image-match or performance certificate is claimed.

[Current source/native checkpoint](https://raw.githubusercontent.com/kevinrhaas/chicago-evidence/26da23d3ce2a3bd7fabd521ae1692a68e1385497/evidence/image-match-2026-10-23/resumed-20261023T2245/publications/9e41c94f150d3dbfb927b3b8a79fe1bd8c5e4f69.json) · [exact leaf-report correction and retained failures](https://raw.githubusercontent.com/kevinrhaas/chicago-evidence/ea67ba86acf84d146567689abc2a9bc326f563ba/evidence/image-match-2026-10-23/resumed-20261023T2245/publications/7db4f9351baa9d0b4bb3ad812bbca68aa44cebfe.json).
