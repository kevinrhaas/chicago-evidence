from pathlib import Path
import subprocess,json,os,datetime,hashlib,urllib.parse
os.sched_setaffinity(0,{1})
os.environ.pop('GIT_NO_LAZY_FETCH',None);os.environ.pop('CHICAGO_TICKETS_DIR',None)
repo=Path('/tmp/tremont-picture-20261026');app=repo/'chicago/4d';runtime=Path('/tmp/tremont-T2385-runtime-20261026');out=runtime/'public-code-draft'
assert not out.exists();out.mkdir()
c=json.loads((runtime/'actual-a575-codecommit/RESULT.json').read_text());r=json.loads((runtime/'actual-a575-codecommit-reaper.json').read_text())
assert c['status']=='CHECKED_NORMAL_CODECOMMIT_AND_ACTUAL_COMMITTED_QUESTIONS_PASS' and r['command_exit']==0 and r['all_children_reaped'] and not r['leftover_cleanup']
head=c['HEAD'];tree=c['tree'];branch='steward/t2385-tremont-gale-a575';actor='Codex Tremont Gale evidence 2026-10-26'
def g(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo).decode().strip()
def api(path,payload=None):
 cmd=['gh','api',path];data=None
 if payload is not None:cmd+=['--method','POST','--input','-'];data=json.dumps(payload).encode()
 r=subprocess.run(cmd,input=data,capture_output=True,check=True);return json.loads(r.stdout) if r.stdout.strip() else None
assert g('rev-parse','HEAD')==head and g('show','-s','--format=%T','HEAD')==tree and not g('status','--porcelain') and g('branch','--show-current')==branch
remote=g('remote','get-url','origin');assert remote.rstrip('/').removesuffix('.git').endswith('kevinrhaas/chicago'),remote
cmd=['git','-c','gc.auto=0','-c','maintenance.auto=false','push','--set-upstream','origin',branch]
with(out/'normal-push.log').open('x') as log:subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
ref=api('repos/kevinrhaas/chicago/git/ref/heads/'+branch);assert ref['object']['sha']==head
(out/'PUBLIC-REF.json').write_text(json.dumps(ref,indent=2)+'\n')
existing=api('repos/kevinrhaas/chicago/pulls?state=open&head='+urllib.parse.quote('kevinrhaas:'+branch,safe='')+'&base=dev&per_page=100')
(out/'BEFORE-PRS.json').write_text(json.dumps(existing,indent=2)+'\n');assert not existing,'Existing PR: recover exact response rather than create a duplicate.'
body=(runtime/'PR-BODY-A575-DRAFT.md').read_text();old='Full local three-question preflight and committed-head checks: pending the actual current verdict before this PR is created.'
assert body.count(old)==1
body=body.replace(old,'Full local three-question preflight passed on tree `'+tree+'`: all 1,070 steps (including 384 self-tests), changelog entry and ID checks. Normal commit `'+head+'` and both actual committed-head checks passed; all wrappers closed with every child reaped.')
(out/'BODY.md').write_text(body)
payload={'title':"T-2385: Reconcile the first Tremont's 1835 evidence",'head':branch,'base':'dev','draft':True,'body':body}
(out/'CREATE-PAYLOAD.json').write_text(json.dumps(payload,indent=2)+'\n')
(out/'CREATE-INTENT.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'HEAD':head,'tree':tree,'payload_sha256':hashlib.sha256((out/'CREATE-PAYLOAD.json').read_bytes()).hexdigest(),'no_blind_retry':'If response is lost, list this exact branch before retrying; never create duplicate.'},indent=2)+'\n')
pr=api('repos/kevinrhaas/chicago/pulls',payload);(out/'CREATED-PR.json').write_text(json.dumps(pr,indent=2)+'\n')
assert pr['state']=='open' and pr['draft'] is True and pr['base']['ref']=='dev' and pr['head']['ref']==branch and pr['head']['sha']==head
n=pr['number']
for name,args,exitcode in [('native-direct-lap',['node','tools/ticket.mjs','lap',str(n),'--by',actor],0),('native-lap-status',['node','tools/ticket.mjs','lap',str(n),'--status'],3)]:
 with(out/(name+'.log')).open('x') as log:r=subprocess.run(args,cwd=app,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==exitcode,(name,r.returncode)
status=(out/'native-lap-status.log').read_text();assert status.startswith('held lap/pr-'+str(n)) and actor in status,status
fresh=api('repos/kevinrhaas/chicago/pulls/'+str(n));assert fresh['draft'] and fresh['head']['sha']==head and fresh['base']['ref']=='dev'
(out/'FRESH-PR.json').write_text(json.dumps(fresh,indent=2)+'\n')
assert g('rev-parse','HEAD')==head and not g('status','--porcelain')
result={'status':'CHECKED_CODE_NORMALLY_PUSHED_DEV_DRAFT_AND_OWN_DIRECT_LAP_VERIFIED','PR':n,'url':pr['html_url'],'HEAD':head,'tree':tree,'branch':branch,'original_ticket':'T-2385 remains OPEN/DIF; no done or image-match claim.','pending':'Exactly one FULL18 remote matrix on this immutable checked head, current required CI; root marks ready/merges only after actual required results.'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
