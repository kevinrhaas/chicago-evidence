from pathlib import Path
import os, subprocess, json, datetime, time
os.sched_setaffinity(0,{int(x)for x in os.environ['T2385_GATE_CPUS'].split(',')})
repo=Path('/tmp/tremont-picture-20261026');app=repo/'chicago/4d'
runtime=Path('/tmp/tremont-T2385-runtime-20261026');out=runtime/'actual-a575-codecommit'
assert not out.exists();out.mkdir()
os.environ.pop('GIT_NO_LAZY_FETCH',None);os.environ.pop('CHICAGO_TICKETS_DIR',None)
def g(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=repo).decode().strip()
gate=json.loads(Path('/tmp/T2385-a575-leaf-full3-resume-20261026/RESULT.json').read_text())
receipt=json.loads((runtime/'a575-leaf-full3-resume-reaper.json').read_text())
assert gate['status']=='PASS_ALL3_CURRENT_A575_NATIVE_PREFLIGHT'
assert receipt['command_exit']==0 and receipt['all_children_reaped'] and not receipt['leftover_cleanup']
tree='9092fd814e577c9b7b7c55221f1f4b90b013fb48'
assert g('write-tree')==tree and not g('diff','--name-only') and not g('ls-files','--others','--exclude-standard')
assert g('rev-parse','HEAD')=='a575dddeed356333423b20361a1f90f3b39a862f'
rows=[]
def run(name,cmd,cwd=app):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
    with(out/(name+'.log')).open('x')as log:r=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
    row={'name':name,'command':cmd,'started':started,'seconds':round(time.monotonic()-t,3),'exit_code':r.returncode}
    rows.append(row);(out/'STEPS.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert r.returncode==0,(name,r.returncode)
run('1-normal-codecommit',['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','T-2385: Reconcile the first Tremont\'s 1835 evidence','-m','Adopt Gale\'s retrospective 1835-framed dimensions, two storeys and yellow as inferred, preserving both street frontage planes and deriving the native roof-staff flag anchor. Retain the undated Gifford three-storey interpretation as an explicit native version with reconstructed scale/colour and the real source disagreement.','-m','Original T-2385 remains OPEN/DIF; this is a visible source correction, not a photographic match. Green Tree PR #1328 is already folded in the a575 base; retain the published four strict smoke-tool repairs.'],repo)
head=g('rev-parse','HEAD');assert g('show','-s','--format=%T','HEAD')==tree
parents=g('show','-s','--format=%P','HEAD').split();assert parents==['a575dddeed356333423b20361a1f90f3b39a862f']
assert not g('status','--porcelain')
base=g('rev-parse','origin/dev');mb=g('merge-base',base,'HEAD')
run('2-actual-committed-changelog',['node','tools/check-changelog-entry.mjs',mb,'HEAD'])
run('3-actual-committed-ids',['node','tools/resolve_id_collisions.mjs','--base',base,'--check'])
assert g('rev-parse','HEAD')==head and g('show','-s','--format=%T','HEAD')==tree and not g('status','--porcelain')
result={'status':'CHECKED_NORMAL_CODECOMMIT_AND_ACTUAL_COMMITTED_QUESTIONS_PASS','HEAD':head,'tree':tree,'parents':parents,'cached_dev':base,'committed_mergebase':mb,'steps':rows,'pending':'Normalpush/publicDEV DRAFTPR/ownlap. Rootready/merge ONLY afterfreshFULL18/currentrequiredchecks; originalT2385 staysOPEN/DIF.'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
