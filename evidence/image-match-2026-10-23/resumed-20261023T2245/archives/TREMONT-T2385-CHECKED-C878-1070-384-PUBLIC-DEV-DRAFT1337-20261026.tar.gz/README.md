Closed T-2385 local gate and public code checkpoint

The corrected candidate passed all three native preflight questions, then a normal single-parent commit and both committed-head checks. The exact checked commit is publicly pushed in DEV DRAFT PR #1337, with the normal direct own lap verified. All included wrappers are fully reaped. The original picture ticket remains OPEN/DIF because the canonical two-storey Gale interpretation conflicts with the drawing’s third storey.

This packet depends on public376 for the exact two-leaf correction, public363 for complete authored source/native closure, and public358 for unchanged four GLB blobs. No asset bytes are duplicated. The current FULL18 dispatch/results folder is live and excluded; no renderer matrix, opacity, final-world ground or performance certificate is claimed here. Root will mark ready and merge only after actual required results.
