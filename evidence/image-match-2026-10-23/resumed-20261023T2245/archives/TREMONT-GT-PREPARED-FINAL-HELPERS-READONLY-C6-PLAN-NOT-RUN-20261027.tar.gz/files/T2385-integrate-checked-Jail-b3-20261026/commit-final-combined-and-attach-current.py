from pathlib import Path
import os,subprocess,json,datetime,hashlib,tempfile,shutil

repo=Path('/tmp/tremont-picture-20261026');app=repo/'chicago/4d'
out=Path(os.environ['T2385_FINAL_ENDING_OUT']);out.mkdir()
env=dict(os.environ)
for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR']:env.pop(k,None)
n=int(env.get('GIT_CONFIG_COUNT','0'))
for k,v in [('gc.auto','0'),('maintenance.auto','false'),('remote.origin.tagOpt','--no-tags')]:
    env[f'GIT_CONFIG_KEY_{n}']=k;env[f'GIT_CONFIG_VALUE_{n}']=v;n+=1
env['GIT_CONFIG_COUNT']=str(n)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def raw(*a):return subprocess.check_output(['git',*a],cwd=repo,env=env)
def g(*a):return raw(*a).decode().strip()
def save(n,j):(out/n).write_text(json.dumps(j,indent=2)+'\n')
def run(n,args,cwd=repo):
    with(out/(n+'.log')).open('x')as log:q=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
    assert q.returncode==0,(n,q.returncode)
def ordered_lines(a,b):
    lines=a.splitlines(keepends=True);i=0
    for line in b.splitlines(keepends=True):
        if i<len(lines)and line==lines[i]:i+=1
    return i==len(lines),len(lines),i
try:
    gate=json.loads(Path(os.environ['T2385_FINAL_FULL3_OUT'],'RESULT.json').read_bytes())
    reaper=json.loads(Path(os.environ['T2385_FINAL_FULL3_REAPER']).read_bytes())
    assert gate['status']=='ALL3_NATIVE_PREFLIGHT_PASS'and reaper['command_exit']==0 and reaper['all_children_reaped']and not reaper['leftover_cleanup']
    binding=gate['binding'];tree=binding['staged_tree'];base=binding['actual_dev']
    assert g('rev-parse','HEAD')==binding['head']=='1290a23271b2771c77201fd17fed7cfa857ade14'
    assert g('rev-parse','MERGE_HEAD')==binding['merge_head']=='b3fb939f510a4ffe009a7c45f104ddadc76d3761'
    assert g('write-tree')==tree and not g('diff','--name-only','--no-renames')and not g('ls-files','--others','--exclude-standard')and not g('ls-files','-u')
    fresh=subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/dev','--jq','.object.sha'],env=env).decode().strip();assert fresh==base,'Actual dev advanced; preserve gate and inspect the concrete delta before committing'
    save('BEFORE.json',{'at':now(),'binding':binding,'scope':'Actual current combined native/app/full3 source, normal pending b3 merge; no fabricated ancestry or public update yet.'})
    run('01-normal-checked-b3-source-commit',['git','commit','-m',"T-2385, T-2376: match Tremont and refine Green Tree's setting"])
    first=g('rev-parse','HEAD');assert g('rev-parse','HEAD^{tree}')==tree
    save('FIRST-CHECKED-COMMIT.json',{'at':now(),'head':first,'tree':tree,'parents':g('show','-s','--format=%P','HEAD')})
    # Source already incorporates this exact actual base. This ordinary merge
    # attaches its real ancestry; reuse of the source checks is conditional on
    # exact whole-tree identity, never on a smoke hash or an ours strategy.
    with(out/'02-normal-actual-base-merge.log').open('x')as log:q=subprocess.run(['git','merge','--no-commit','--no-ff',base],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
    conflicts=g('diff','--name-only','--diff-filter=U','--no-renames').splitlines()
    save('ACTUAL-MERGE-RESULT.json',{'exit':q.returncode,'conflicts':conflicts,'unmerged_index':g('ls-files','-u')})
    assert all(p in ['chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md']for p in conflicts),('Unexpected merge content retained for owning-tool/source review',conflicts)
    proofs=[]
    for p in conflicts:
        checked=raw('show',first+':'+p);incoming=raw('show',base+':'+p)
        complete,count,found=ordered_lines(incoming,checked);assert complete,('Incoming authored lines need concrete review',p,count,found)
        for stage in [1,2,3]:
            saved=out/('raw-stage'+str(stage))/p;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(raw('show',':'+str(stage)+':'+p))
        dest=repo/p;fd,tmp=tempfile.mkstemp(dir=dest.parent,prefix='.t2385-checked-doc-');os.close(fd);Path(tmp).write_bytes(checked);shutil.copymode(dest,tmp);os.replace(tmp,dest)
        subprocess.run(['git','add','--',p],cwd=repo,env=env,check=True)
        proofs.append({'path':p,'all_incoming_lines_exact_in_order':True,'line_count':count,'restored_already_checked_blob_sha256':hashlib.sha256(checked).hexdigest(),'non_UTF8_preserved':True})
    assert not g('ls-files','-u')and g('write-tree')==tree and not g('diff','--name-only','--no-renames')and not g('ls-files','--others','--exclude-standard'),'Normal merge changed the checked source: inspect actual paths before another commit'
    assert g('rev-parse','MERGE_HEAD')==base
    save('EXACT-WHOLE-TREE-ANCESTRY-PROOF.json',{'at':now(),'first_checked':first,'actual_base':base,'checked_tree':tree,'actual_tree':g('write-tree'),'every_source_blob_and_mode_exact':True,'authored_conflicts':proofs})
    run('03-normal-actual-base-ancestry-commit',['git','commit','-m','T-2385, T-2376: attach checked current dev ancestry'])
    assert g('rev-parse','HEAD^{tree}')==tree and not g('status','--porcelain=v1')
    for name,cmd in [('04-committed-changelog',['node','tools/check-changelog-entry.mjs',base,'HEAD']),('05-committed-ids',['node','tools/resolve_id_collisions.mjs','--base',base,'--check']),('06-native-history',['node','tools/check-changelog.mjs'])]:run(name,cmd,app)
    state=json.loads(subprocess.check_output(['node','tools/dev-smoke-state.mjs','hash','--json'],cwd=app,env=env));assert state['dirty']is False
    save('RESULT.json',{'status':'CHECKED_COMBINED_SOURCE_AND_NORMAL_ACTUAL_ANCESTRY_COMMITTED_PASS','at':now(),'head':g('rev-parse','HEAD'),'tree':tree,'first_checked_commit':first,'actual_base':base,'native_hash_record_not_bar':state,'original_T2376':'OPEN/DIFFERS substantial enclosed annex','original_T2385':'Actual canonical picture matches; finish only after qualified PR1337 merge','pending':'Normal FF public update, current applicable published qualification/protection checks, Ready and standard expected-head merge_method=merge into dev. Verify actual merge tree and parents; never app main.'})
    print((out/'RESULT.json').read_text(),flush=True)
except Exception as e:
    save('ACTUAL-STOP.json',{'at':now(),'error':repr(e),'HEAD':g('rev-parse','HEAD'),'status':g('status','--porcelain=v1'),'scope':'Actual state/raw logs preserved. No reset/force, no generated hand merge, no second commit on a different or conflicted source.'})
    raise
