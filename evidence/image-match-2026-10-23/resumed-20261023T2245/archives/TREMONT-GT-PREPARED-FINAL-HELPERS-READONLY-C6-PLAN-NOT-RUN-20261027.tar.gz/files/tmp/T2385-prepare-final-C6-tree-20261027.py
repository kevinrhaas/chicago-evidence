from pathlib import Path
import subprocess, json, hashlib, datetime, os, mmap, struct, tempfile

repo=Path('/tmp/tremont-picture-20261026')
holder=Path('/workspace/T2385-integrate-checked-Jail-b3-20261026')
out=Path('/tmp/T2385-final-C6-tree-preparation-20261027T0235')
out.mkdir(exist_ok=False)
base='2a3d06495d73fc36b40458b093db7d67f6784fd3'
tree='03094a09eb9e7f0d802f02deb4a92bb525549b6f'
env=dict(os.environ)
n=int(env.get('GIT_CONFIG_COUNT','0'))
for k,v in [('gc.auto','0'),('maintenance.auto','false'),('remote.origin.tagOpt','--no-tags')]:
    env[f'GIT_CONFIG_KEY_{n}']=k;env[f'GIT_CONFIG_VALUE_{n}']=v;n+=1
env['GIT_CONFIG_COUNT']=str(n)
def git(*a):return subprocess.check_output(['git',*a],cwd=repo,env=env)
def save(p,b):
    q=out/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
def sha(b):return hashlib.sha256(b).hexdigest()
def objectid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
common=Path(git('rev-parse','--git-common-dir').decode().strip())
if not common.is_absolute():common=(repo/common).resolve()
objects=common/'objects'
def present(oid):
    if (objects/oid[:2]/oid[2:]).is_file():return True
    key=bytes.fromhex(oid)
    for idx in (objects/'pack').glob('*.idx'):
        with idx.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ)as m:
            assert m[:8]==b'\xfftOc\x00\x00\x00\x02',str(idx)
            low=0 if key[0]==0 else struct.unpack_from('>I',m,8+4*(key[0]-1))[0]
            high=struct.unpack_from('>I',m,8+4*key[0])[0]
            while low<high:
                mid=(low+high)//2;x=m[1032+mid*20:1032+(mid+1)*20]
                if x<key:low=mid+1
                else:high=mid
            count=struct.unpack_from('>I',m,8+4*255)[0]
            if low<count and m[1032+low*20:1032+(low+1)*20]==key:return True
    return False
classification=json.loads((holder/'FINAL-C6-03094-TREE-READONLY-CLASSIFICATION.json').read_bytes())
assert classification['incoming_TREE']==tree and classification['base_TREE']==base
rows={x['path']:x for x in classification['rows']}
assert git('rev-parse','HEAD').decode().strip()=='1290a23271b2771c77201fd17fed7cfa857ade14'
assert git('rev-parse','MERGE_HEAD').decode().strip()=='b3fb939f510a4ffe009a7c45f104ddadc76d3761'
def blob(ref,path):
    oid=rows[path]['base' if ref==base else 'incoming']
    assert oid and present(oid),('missing exact blob; no lazy-fetch probe',ref,path,oid)
    raw=git('show',ref+':'+path);assert objectid(raw)==oid
    return raw
missing=object()
def merge(a,o,t,path):
    if t==a:return o
    if o==a or o==t:return t
    if all(isinstance(x,dict)for x in [a,o,t]):
        result={}
        for k in list(o)+[k for k in t if k not in o]:
            value=merge(a.get(k,missing),o.get(k,missing),t.get(k,missing),path+'/'+k)
            if value is not missing:result[k]=value
        return result
    if path.endswith(('/pictured','/not_pictured')) and all(isinstance(x,list)for x in [a,o,t]):
        def keyed(xs):
            d={json.dumps([x.get('scene'),x.get('structure'),x.get('picture')]):x for x in xs}
            assert len(d)==len(xs),(path,'nonunique key');return d
        return list(merge(keyed(a),keyed(o),keyed(t),path+'/by-scene-structure-picture').values())
    if path.endswith(('/pictured','/not_pictured')) and all(isinstance(x,list)for x in [a,o,t]):
        def keyed(xs):
            result={json.dumps([x.get('scene'),x.get('structure'),x.get('picture')]):x for x in xs}
            assert len(result)==len(xs),(path,'duplicate composite key');return result
        return list(merge(keyed(a),keyed(o),keyed(t),path+'/by-scene-structure-picture').values())
    raise AssertionError(('concurrent field conflict',path))
actions=[];problems=[]
for p in classification['groups']['safe_incoming']:
    raw=(repo/p).read_bytes()if(repo/p).is_file()else None
    assert (objectid(raw)if raw is not None else None)==rows[p]['working']
    assert rows[p]['working']==rows[p]['base']
    if rows[p]['incoming'] is None:
        actions.append({'path':p,'action':'PROPOSED_EXACT_INCOMING_DELETE','preimage':rows[p]['working']});continue
    incoming=blob(tree,p);save(Path('proposed')/p,incoming)
    actions.append({'path':p,'action':'PROPOSED_EXACT_SAFE_INCOMING','preimage':rows[p]['working'],'sha256':sha(incoming),'bytes':len(incoming)})
jsonpaths=['chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json','chicago/4d/data/structure_grades.json']
for p in jsonpaths:
    a=blob(base,p);o=(repo/p).read_bytes();t=blob(tree,p)
    assert objectid(o)==rows[p]['working']
    try:
        result=merge(json.loads(a),json.loads(o),json.loads(t),p)
        raw=(json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode();save(Path('proposed')/p,raw)
        actions.append({'path':p,'action':'PROPOSED_EXACT_FIELDWISE_3WAY','preimage':objectid(o),'sha256':sha(raw),'bytes':len(raw)})
    except Exception as e:problems.append({'path':p,'error':repr(e)})
for p in ['chicago/4d/docs/LIBERTIES.md','chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md']:
    a=blob(base,p);o=(repo/p).read_bytes();t=blob(tree,p)
    for name,raw in [('base',a),('ours',o),('incoming',t)]:save(Path('threeway')/name/p,raw)
    args=['git','merge-file','-p',str(out/'threeway/ours'/p),str(out/'threeway/base'/p),str(out/'threeway/incoming'/p)]
    q=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    save(Path('threeway/results')/p,q.stdout)
    if q.returncode==0:
        save(Path('proposed')/p,q.stdout);actions.append({'path':p,'action':'PROPOSED_NATIVE_GIT_MERGE_FILE_CLEAN','preimage':objectid(o),'sha256':sha(q.stdout),'bytes':len(q.stdout)})
    else:problems.append({'path':p,'error':'actual merge-file conflict preserved','exit':q.returncode})
generated=[p for p in classification['groups']['both_changed']if p not in jsonpaths and p not in ['chicago/4d/docs/LIBERTIES.md','chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md']]
result={'status':'READONLY_PREPARATION_PROPOSED_INPUTS_NO_SOURCE_WRITES','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'incoming_TREE_not_commit':tree,'actions':actions,'problems':problems,'generated_for_native_owners':generated,'source_unchanged':True,'no_missing_object_probe_or_lazyfetch':True,'pending':'CheckedCarpenteractualcommit/landing; actualcompletecheckedCarpenter ending; owningnativeimage andderivedclosure/full3/actualqualification/codepush/normalexpected-headDEVmerge.'}
save('RESULT.json',(json.dumps(result,indent=2)+'\n').encode());print(json.dumps({'status':result['status'],'proposed':len(actions),'problems':problems,'native':generated},indent=2))
