"""GET-only slow observer for the two explicitly bound final stage14 runs."""
import argparse,pathlib,json,datetime,subprocess,time,os
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--dispatch',required=True);ap.add_argument('--head',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
receipt=json.loads(pathlib.Path(a.dispatch).read_text())
assert receipt['status']=='DISPATCHED_NOT_RESULTS' and receipt['head']==a.head and receipt['PR']==1260 and len(receipt['runs'])==2
assert {(r['viewport'],r['stage']) for r in receipt['runs']}=={('desktop','14'),('mobile','14')}
out=pathlib.Path(a.out);assert out.is_absolute() and str(out).startswith('/tmp/');out.mkdir(exist_ok=False)
with (out/'ACTIVE_OBSERVER_LOCK.json').open('x') as f:json.dump({'pid':os.getpid(),'head':a.head},f)
def now():return datetime.datetime.now(datetime.timezone.utc)
def state(phase,**extra):
    value={'pid':os.getpid(),'head':a.head,'phase':phase,'heartbeat_at':now().isoformat(),**extra};temp=out/'WATCHER_STATE.tmp';temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(out/'WATCHER_STATE.json')
cmd=['python',str(pathlib.Path(__file__).parent/'watch_controller.py'),'--dispatch',a.dispatch,'--head',a.head,'--out',str(out),'--harvest']
last=None
while True:
    started=now();state('POLL_RUNNING',last_summary=last)
    q=subprocess.run(cmd,capture_output=True,text=True);stamp=started.strftime('%Y%m%dT%H%M%S%fZ');(out/('observer-output-'+stamp+'.json')).write_text(q.stdout)
    if q.stderr:(out/('observer-stderr-'+stamp+'.txt')).write_text(q.stderr)
    if q.returncode:last={'at':now().isoformat(),'read_error':q.stderr[-1000:],'status':'READ_ERROR_NOT_A_CI_VERDICT'}
    else:
        try:last=json.loads(q.stdout)
        except Exception as e:last={'at':now().isoformat(),'read_error':str(e),'status':'UNREADABLE_NOT_A_CI_VERDICT'}
    with (out/'EVENTS.jsonl').open('a') as f:f.write(json.dumps(last)+'\n')
    print(json.dumps(last),flush=True)
    if q.returncode==0 and last.get('actual_terminal_log_count')==2 and not last.get('read_errors') and not last.get('log_read_errors'):
        state('COMPLETE_2_TERMINAL_LOGS',last_summary=last);break
    due=started+datetime.timedelta(seconds=300)
    while now()<due:
        state('WAITING',last_summary=last,next_poll_at=due.isoformat());time.sleep(min(45,max(0,(due-now()).total_seconds())))
