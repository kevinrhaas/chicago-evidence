from pathlib import Path
import base64,datetime,hashlib,json,re,subprocess
OUT=Path('/workspace/shared/T2376-own-claim-renewal-20261026T2240');OUT.mkdir()
ROOT=Path('/tmp/chicago-green-tree-integration/chicago/4d')
TICKETS=ROOT/'tickets'
TP='T-2250-2499/T-2376-match-the-green-tree-tavern-to-its-pictures.md'
EXPECTED_BLOB='f4d200310e1c70720b8bb55b0b094947ec3c2bda'
EXPECTED_REFS={
 'verification/t2376-cb93-6a61ab6eca1f-20261026':'6a61ab6eca1f1ea2322302d131e847b383ac9c8b',
 'verification/t2376-pr1328-0c78d17b22cf-20261026':'0c78d17b22cf91782e2c7fe7e200c19dcc8a4534',
}
def api(repo,path):return json.loads(subprocess.check_output(['gh','api',f'repos/kevinrhaas/{repo}/'+path]))
def save(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
assert not subprocess.check_output(['git','-C',str(TICKETS),'status','--porcelain'])
status_before=subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain'])
(OUT/'SOURCE-BEFORE.txt').write_bytes(status_before)
pr=api('chicago','pulls?state=open&per_page=100');assert len(pr)<100
save('OPEN-PRS.json',pr)
matching=[x for x in pr if re.search(r'\bT-?2376\b',x['title'],re.I) or re.search(r'\bt2376\b',x['head']['ref'],re.I)]
assert not matching, 'A foreign/open PR must not be rebuilt'
refs_raw=subprocess.check_output(['git','-C',str(ROOT),'ls-remote','--heads','origin'])
(OUT/'REMOTE-REFS.txt').write_bytes(refs_raw)
refs={ref.removeprefix('refs/heads/'):sha for sha,ref in (line.split() for line in refs_raw.decode().splitlines()) if re.search(r'(?:^|[-/])t-?2376(?:$|[-/])',ref,re.I)}
assert refs==EXPECTED_REFS, ('Only the two previously verified owned references may be bypassed',refs)
before=api('chicago-tickets','contents/'+TP+'?ref=main');save('PUBLIC-BEFORE.json',before)
assert before['sha']==EXPECTED_BLOB
raw=base64.b64decode(before['content']);(OUT/'TICKET-BEFORE.md').write_bytes(raw)
historical=api('chicago-tickets','contents/'+TP+'?ref=dd2c1fee917a6d4e0c52a9223f5838935e0b8763')
assert historical['sha']==EXPECTED_BLOB and base64.b64decode(historical['content'])==raw
assert b'claimed_by: Codex Green Tree wagon bay and sash continuation ' in raw
oldtime=datetime.datetime.fromisoformat(re.search(rb'^claimed_at: (.+)$',raw,re.M).group(1).decode().replace('Z','+00:00'))
assert datetime.datetime(2026,10,26,20,0,tzinfo=datetime.timezone.utc)<oldtime<datetime.datetime(2026,10,26,20,10,tzinfo=datetime.timezone.utc)
with (OUT/'tickets-pull.log').open('x') as log:
 p=subprocess.run(['git','-C',str(TICKETS),'pull','--ff-only','origin','main'],stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0 and not subprocess.check_output(['git','-C',str(TICKETS),'status','--porcelain'])
assert (TICKETS/TP).read_bytes()==raw
fresh=api('chicago-tickets','contents/'+TP+'?ref=main');save('IMMEDIATE-TICKET.json',fresh)
assert fresh['sha']==EXPECTED_BLOB
cmd=['node','tools/ticket.mjs','claim','T-2376','--force','--by','Codex Green Tree wagon bay and sash continuation']
with (OUT/'native.log').open('x') as log:
 p=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0
commit=subprocess.check_output(['git','-C',str(TICKETS),'rev-parse','HEAD']).decode().strip()
after=api('chicago-tickets','contents/'+TP+'?ref='+commit);save('PUBLIC-AFTER.json',after)
new=base64.b64decode(after['content']);(OUT/'TICKET-AFTER.md').write_bytes(new)
assert new==(TICKETS/TP).read_bytes()
assert b'state: claimed\n' in new and b'pr: null\n' in new
claimtime=re.search(rb'^claimed_at: (.+)$',new,re.M).group(1).decode()
created=datetime.datetime.fromisoformat(claimtime.replace('Z','+00:00'))
assert created>datetime.datetime(2026,10,26,22,0,tzinfo=datetime.timezone.utc)
assert not subprocess.check_output(['git','-C',str(TICKETS),'status','--porcelain'])
status_after=subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain'])
(OUT/'SOURCE-AFTER.txt').write_bytes(status_after);assert status_after==status_before
save('RESULT.json',{'status':'OWNED_NATIVE_T2376_CLAIM_RENEWED_ONLY','ticket_commit':commit,'claimed_at':created.isoformat(),'expires':(created+datetime.timedelta(hours=3)).isoformat(),'public_blob':after['sha'],'public_raw_sha256':hashlib.sha256(new).hexdigest(),'native_command':cmd,'native_exit':0,'force_scope':'Root standing owned-ref-only exception: exactly the verified6a61/0c78 references; no foreign owner/claim/PR/head override. Fresh public oldclaim byte exact historical dd2c/f4d200.', 'original_DONE':False,'code_or_model_changes':False})
print((OUT/'RESULT.json').read_text(),flush=True)
