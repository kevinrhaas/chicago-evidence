from pathlib import Path
import os, subprocess, json, datetime, shutil, re

repo = Path('/tmp/tremont-picture-20261026')
app = repo / 'chicago/4d'
out = Path('/workspace/T2385-integrate-checked-Jail-b3-20261026/current-full3-v3')
out.mkdir()
affinity={int(x)for x in os.environ['T2385_LEASE_CPU_IDS'].split(',')}
assert len(affinity)<=4
os.sched_setaffinity(0, affinity)
env = dict(os.environ)
for key in ['GIT_NO_LAZY_FETCH', 'CHICAGO_TICKETS_DIR']:
    env.pop(key, None)
env.update(CHECK_JOBS=str(len(affinity)), C4D_GATE_REQUIRE_READERS='1',
           C4D_GATE_REQUIRE_BASE='1', GITHUB_BASE_REF='dev',
           C4D_RULINGS_BASE=os.environ['T2385_ACTUAL_INCOMING_DEV_SHA'],
           TMPDIR='/tmp/tremont-currentdev-check-tmp',
           OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1',
           MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1')
Path(env['TMPDIR']).mkdir(exist_ok=True)
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', *args], cwd=repo, env=env).decode().strip()
def save(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n')
assert json.loads((out.parent/'current-metadata-native-closure/RESULT.json').read_text())['status'] == 'PASS_CURRENT_CANONICAL_METADATA_NATIVE_CLOSURE_NO_CODECOMMIT_OR_CURRENT_CARD_APP'
assert not git('ls-files', '-u')
assert not git('diff', '--name-only')
assert not git('ls-files', '--others', '--exclude-standard')
head, incoming, tree = [git('rev-parse', 'HEAD'), git('rev-parse', 'MERGE_HEAD'), git('write-tree')]
assert head == '1290a23271b2771c77201fd17fed7cfa857ade14'
assert incoming == 'b3fb939f510a4ffe009a7c45f104ddadc76d3761'
assert json.loads((app/'data/reference_views/tremont_house_1/gifford.match.json').read_text())['verdict']=='matches'
for viewport in ['mobile','desktop']:
    row=json.loads((out.parent/'current-app-review'/f'{viewport}-current-v2'/'RESULT.json').read_text())
    assert row['status']=='PASS_TARGETED_NATIVE_VERSIONS_NOT_IMAGE_MATCH'
card=json.loads((out.parent/'image-card/visible-app-v2/RESULT.json').read_text())
assert card['status']=='PASS_BOTH_VIEWPORTS_VISIBLE_NATIVE_INLINE_CARD'
base = git('rev-parse', 'origin/dev')
assert base==os.environ['T2385_ACTUAL_INCOMING_DEV_SHA']
assert git('rev-parse',base+'^{tree}')==os.environ['T2385_ACTUAL_INCOMING_DEV_TREE']
remote = subprocess.check_output(['gh', 'api', 'repos/kevinrhaas/chicago/git/ref/heads/dev', '--jq', '.object.sha'], env=env).decode().strip()
assert base == remote
free = shutil.disk_usage(env['TMPDIR']).free
assert free >= 1800000000
binding = dict(at=now(), head=head, merge_head=incoming, staged_tree=tree,
               actual_dev=base, freshly_read_remote_dev=remote,
               actual_merge_base=git('merge-base', base, 'HEAD'),
               checked_Jail_delta_tree='897824de45d16cd90fe2400cd3b8aace341d42ea',
               actual_checked_Jail_commit='bbbe518720601b785e79628bf247ee4b9f9d4ed8',
               actual_checked_Mary='776716a356cdb00dfd1083e45b5bc6cf560f2bf9',
               actual_checked_Wolf=os.environ['T2385_CHECKED_WOLF_SHA'],
               affinity=sorted(affinity), CHECK_JOBS=len(affinity), tmp_free_bytes=free,
               orchestration_startup_floor_bytes=1800000000,
               native_resource_guards_unchanged=True,
               scope='Actual three native preflight questions, without unsafe common-object broad fetch. Normal checked-Jail/Mary/Wolf/current-dev ancestry attachment still required after the checked b3 merge commit; source-identical gate reuse requires exact full-tree equality.')
save('BINDING.json', binding)
print(json.dumps(binding), flush=True)
steps=[]
for name, cmd in [
    ('1-wholecheck', ['bash', 'tools/check.sh']),
    ('2-changelog', ['node', 'tools/check-changelog-entry.mjs', binding['actual_merge_base'], 'HEAD']),
    ('3-ids', ['node', 'tools/resolve_id_collisions.mjs', '--base', base, '--check'])]:
    started = now()
    print('START', name, started, flush=True)
    with (out/(name+'.log')).open('x') as log:
        process = subprocess.run(cmd, cwd=app, env=env, stdout=log, stderr=subprocess.STDOUT)
    steps.append(dict(name=name, command=cmd, started=started, finished=now(), exit=process.returncode))
    save('STEPS.json', steps)
    print('CLOSED', name, process.returncode, now(), flush=True)
guards = dict(head=git('rev-parse','HEAD')==head,
              incoming=git('rev-parse','MERGE_HEAD')==incoming,
              staged_tree=git('write-tree')==tree,
              working_bytes=not git('diff','--name-only'),
              no_untracked=not git('ls-files','--others','--exclude-standard'))
log=re.sub(r'\x1b\[[0-9;]*m', '', (out/'1-wholecheck.log').read_text(errors='replace'))
footer=bool(re.search(r'^CHECK PASS — \d+ steps, none red\.$', log, re.M))
passed=all(step['exit']==0 for step in steps) and all(guards.values()) and footer
result=dict(status='ALL3_NATIVE_PREFLIGHT_PASS' if passed else 'ACTUAL_PREFLIGHT_FAIL_RETAINED',
            at=now(), binding=binding, steps=steps, guards=guards,
            native_footer=log.strip().splitlines()[-4:],
            pending='Actual focused inline card and prior body/version app reviewed; normal checked codecommit/ancestry attachment, committed ending checks, public PR and actual qualification before READY/DEV merge. Canonical T2385 match is based on the actual fresh source/comparison and both-viewport app review; ticket finishing still requires its existing PR1337 to merge into dev.')
save('RESULT.json', result)
print(json.dumps(result, indent=2), flush=True)
raise SystemExit(0 if passed else 1)
