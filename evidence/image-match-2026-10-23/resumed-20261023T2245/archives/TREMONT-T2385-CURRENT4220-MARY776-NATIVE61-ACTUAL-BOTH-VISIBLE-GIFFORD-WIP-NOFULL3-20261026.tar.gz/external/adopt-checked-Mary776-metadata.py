from pathlib import Path
import subprocess,json,hashlib,datetime,shutil,os
r=Path('/tmp/tremont-picture-20261026');h=Path('/workspace/T2385-integrate-checked-Jail-b3-20261026');out=h/'checked-Mary776-metadata';out.mkdir();inc='776716a356cdb00dfd1083e45b5bc6cf560f2bf9'
def g(*a):return subprocess.check_output(['git','-c','gc.auto=0',*a],cwd=r)
def incoming(p):return g('show',inc+':'+p)
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,b):
 q=r/p;d=out/'before'/p
 if q.exists():d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,d)
 q.parent.mkdir(parents=True,exist_ok=True);t=q.with_name(q.name+'.t2385tmp');t.write_bytes(b);os.replace(t,q)
assert g('rev-parse','HEAD').decode().strip()=='1290a23271b2771c77201fd17fed7cfa857ade14'
assert g('rev-parse','MERGE_HEAD').decode().strip()=='b3fb939f510a4ffe009a7c45f104ddadc76d3761'
assert g('rev-parse',inc+'^{tree}').decode().strip()=='941ff0d4ff8ce6e7f3232a40faba621513c1aac8'
cam='chicago/4d/data/reference_views/st_marys_church/moss-engraving.json';a=json.loads((r/cam).read_bytes());b=json.loads(incoming(cam));assert {k:v for k,v in b.items()if k not in ['diagnostic_only','library_image']}==a
master='chicago/4d/assets/gltf/st_marys_church__frame_1833.glb';assert sha((r/master).read_bytes())=='f3e78bf91b68e95b0eee1200e5b006729bd4a0d33fc73e8968fba18c382d26f7'
photo=(r/'chicago/4d/data/reference_views/st_marys_church'/a['photo']).resolve();assert sha(photo.read_bytes())=='e0c28e377dce83fe936cf74a2fd76186269ce6e6ec864182f5f49f37d0f7a1f2'
m='chicago/4d/data/reference_views/st_marys_church/moss-engraving.match.json';mi=json.loads(incoming(m));assert mi['verdict']=='differs'and any(x['status']=='open'for x in mi['differences']);assert mi['glb_sha256']==sha((r/master).read_bytes())and mi['photo_sha256']==sha(photo.read_bytes())and mi['camera_sha256']==sha(incoming(cam))
ss='chicago/4d/'+mi['side_by_side'];assert(r/ss).read_bytes()==incoming(ss)
for p in [cam,m,'chicago/4d/changelog.d/T-2384.json','chicago/prairie_1904_v1/research/images/stream-st-mary-reference.json']:write(p,incoming(p))
p='chicago/4d/data/structure_grades.json';j=json.loads((r/p).read_bytes());prior=json.loads((r/p).read_bytes());other=[x for x in j['pictured']if x['structure']!='st_marys_church'];ir=[x for x in json.loads(incoming(p))['pictured']if x['structure']=='st_marys_church'];assert len(ir)==1;old=[x for x in j['pictured']if x['structure']=='st_marys_church'];assert len(old)==1 and old[0]['picture']=='andreas_1884_st_marys_engraving';j['pictured']=[ir[0]if x['structure']=='st_marys_church'else x for x in j['pictured']];assert[x for x in j['pictured']if x['structure']!='st_marys_church']==other;write(p,(json.dumps(j,indent=2,ensure_ascii=False)+'\n').encode())
for p,marker in [('chicago/4d/docs/STATUS.md',b'### T-2384: credited engraving on the Images card (2026-10-26)'),('chicago/4d/docs/ROADMAP.md',b'T-2384 image-card ending:')]:
 b=incoming(p);assert b.count(marker)==1;suffix=b[b.index(marker):];ours=(r/p).read_bytes();assert marker not in ours;write(p,ours+b'\n\n'+suffix)
view=h/'image-card/native-store/prairie-1904/files';rows=json.loads(incoming('chicago/prairie_1904_v1/research/images/STORE.json'))['files'];added=[]
for name in ['early-moss-1884-st-marys.jpg','early-moss-1884-st-marys-thumb.jpg']:
 p=Path('/workspace/chicago-images/prairie-1904/files')/name;assert p.is_file()and p.stat().st_size==rows[name]['bytes']and sha(p.read_bytes())==rows[name]['sha256'];q=view/name;assert not q.exists();q.symlink_to(p);added.append(name)
result={'status':'GUARDED_CHECKED_MARY776_AUTHORED_METADATA_ADOPTED_NATIVE_DERIVATION_PENDING','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checked_incoming':inc,'tree':'941ff0d4ff8ce6e7f3232a40faba621513c1aac8','master_photo_camera_numeric_protected':True,'same_native_Moss_comparison_JPEG_exact':True,'original_T2384':'differs, existing sash OPEN retained','source_mutations':['Mary diagnostic camera/match exact incoming','Mary changelog exact incoming','Mary source stream exact incoming','Mary pictured ruling only','exact incoming two authored doc suffixes appended preserving all own bytes'],'STORE':'Only two cited verified symlinks prepared; native sync/build must regenerate with both Mary and Gifford streams, no whole-file foreign copy.','no_commit_no_ancestry_rewrite':True,'pending':'New actual dev+Wolf inputs, owning native closure/publish, actual visibleGiffordcard BOTH, ONE finalfull3 and checked ending.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
