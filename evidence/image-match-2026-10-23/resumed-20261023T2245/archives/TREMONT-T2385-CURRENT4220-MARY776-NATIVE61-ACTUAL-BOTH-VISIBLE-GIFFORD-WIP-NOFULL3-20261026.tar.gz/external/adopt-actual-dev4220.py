from pathlib import Path
import subprocess,json,hashlib,datetime,shutil,tempfile,os
r=Path('/tmp/tremont-picture-20261026');h=Path('/workspace/T2385-integrate-checked-Jail-b3-20261026');out=h/'actual-dev4220-adoption';out.mkdir();base='373851d158a7b6fc701b9cae1a651aa4b3823f97';inc='4220f39bc160816f2fc716606d854c0c9ad7bc05'
def g(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=r)
def b(ref,p):return g('show',ref+':'+p)
def sha(x):return hashlib.sha256(x).hexdigest()
def put(p,x):
 q=r/p;before=out/'before'/p
 if q.is_file():before.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,before)
 q.parent.mkdir(parents=True,exist_ok=True);fd,t=tempfile.mkstemp(dir=q.parent,prefix='.t2385-currentdev-');os.close(fd);Path(t).write_bytes(x)
 if q.exists():shutil.copymode(q,t)
 os.replace(t,q)
assert g('rev-parse','HEAD').decode().strip()=='1290a23271b2771c77201fd17fed7cfa857ade14'
assert g('rev-parse','MERGE_HEAD').decode().strip()=='b3fb939f510a4ffe009a7c45f104ddadc76d3761'
assert g('rev-parse','origin/dev').decode().strip()==inc
assert g('rev-parse',inc+'^{tree}').decode().strip()=='026ea09dbe4c739241abb38cae080c60c06d9ccf'
classes=json.loads((h/'NEWDEV4220-READONLY-INTEGRATION-CLASSIFICATION.json').read_text())['groups'];actions=[]
for p in classes['safe_incoming']:
 assert(r/p).read_bytes()==b(base,p),(p,'preimage moved');new=b(inc,p);put(p,new);actions.append({'path':p,'action':'EXACT_INCOMING_SAFE_PREIMAGE','sha256':sha(new)})
missing=object()
def merge(a,o,t,path):
 if t==a:return o
 if o==a or o==t:return t
 if isinstance(a,dict)and isinstance(o,dict)and isinstance(t,dict):
  merged={}
  for k in o: 
   v=merge(a.get(k,missing),o[k],t.get(k,missing),path+'/'+k)
   if v is not missing:merged[k]=v
  for k in t:
   if k not in o:
    v=merge(a.get(k,missing),missing,t[k],path+'/'+k)
    if v is not missing:merged[k]=v
  return merged
 raise AssertionError(('conflicting exact field',path))
for p in ['chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json']:
 a=json.loads(b(base,p));o=json.loads((r/p).read_bytes());t=json.loads(b(inc,p));m=merge(a,o,t,p);put(p,(json.dumps(m,indent=2)+'\n').encode());actions.append({'path':p,'action':'EXACT_FIELDWISE_3WAY_CHECKED_NATIVE_ROWS','all_own_unchanged_incoming_fields_preserved':True})
p='chicago/4d/docs/LIBERTIES.md';a=b(base,p);i=b(inc,p);assert i.startswith(a);suffix=i[len(a):];o=(r/p).read_bytes();assert suffix and suffix not in o;put(p,o+suffix);actions.append({'path':p,'action':'EXACT_INCOMING_APPEND_ONLY_SUFFIX','bytes':len(suffix),'every_prior_own_byte_preserved':True})
p='chicago/4d/tools/derived_manifest.json'
for name,x in [('ours',(r/p).read_bytes()),('base',b(base,p)),('incoming',b(inc,p))]:(out/(name+'-derived_manifest.json')).write_bytes(x)
q=subprocess.run(['git','merge-file','-p',str(out/'ours-derived_manifest.json'),str(out/'base-derived_manifest.json'),str(out/'incoming-derived_manifest.json')],stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/'merge-derived-manifest.stderr').write_bytes(q.stderr);assert q.returncode==0,(q.returncode,q.stderr.decode());parsed=json.loads(q.stdout);assert len(parsed['steps'])==len(json.loads((r/p).read_bytes())['steps']);put(p,q.stdout);actions.append({'path':p,'action':'CLEAN_NATIVE_TEXT_3WAY_EXACT_INCOMING_SOURCE_BACKLINK_ADDITION'})
remaining=[p for p in classes['both_changed']if p not in [x['path']for x in actions]];assert remaining==['chicago/4d/data/liberties.json','chicago/4d/data/sidecars/1812/sources/uses.json','chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/data/sidecars/1904/sources/uses.json','chicago/4d/docs/measurements/source_use_coverage.md'];result={'status':'GUARDED_ACTUAL_DEV4220_INPUT_ADOPTION_NATIVE_PRODUCTS_PENDING','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'actual_incoming':inc,'tree':'026ea09dbe4c739241abb38cae080c60c06d9ccf','actions':actions,'native_products_left_for_owning_tail':remaining,'source_code_commit':False,'pending_MERGE_HEAD_unchanged':g('rev-parse','MERGE_HEAD').decode().strip(),'scope':'Exact current1904 K13 target/producer/default controls, source/photo/reference/card/manifest and genuinefold. Preserve own Tremont yellow/Gale/Wolf/Mary rows and all source streams. Original T2385 matches but PR1337 ending still pending.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'exact_incoming_safe_paths':len(classes['safe_incoming']),'authored_or_manifest_merge_paths':4,'native_products_pending':remaining}))
