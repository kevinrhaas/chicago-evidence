from pathlib import Path
import os,json,hashlib,subprocess,datetime,shutil,zipfile,io,gzip,xml.etree.ElementTree as ET,fnmatch
repo=Path('/tmp/tremont-picture-20261026');app=repo/'chicago/4d';holder=Path('/tmp/T2385-checked-Mary-Wolf-delta-plan-20261026/prepared-23dddb8feb66');out=holder/'native-closure';out.mkdir(exist_ok=False)
base='23dddb8feb6698d6a601d200e49c79a56939935f';head='32dcead39aa5912d6e3722020f5a87086e387b26';sha=lambda b:hashlib.sha256(b).hexdigest()
env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(TMPDIR='/tmp/T2385-23dd-native-scratch-20261026',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',CHECK_JOBS='4');Path(env['TMPDIR']).mkdir(exist_ok=True)
def g(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=repo,env=dict(env,GIT_NO_LAZY_FETCH='1'))
assert g('rev-parse','HEAD').decode().strip()==head
assert g('rev-parse','MERGE_HEAD').decode().strip()==base
before44=json.loads((holder/'ACTUAL_INCOMING_44_PRE_NATIVE.json').read_text());people=json.loads((holder/'PROTECTED_PEOPLE_CAPACITY_VERSIONS.json').read_text())
for row in before44+people:assert sha((repo/row['path']).read_bytes())==row['sha256'],row['path']
manifest=json.loads((app/'tools/derived_manifest.json').read_text());gen={p for s in manifest['steps']for p in s.get('resolves',[])}
def generated(p):return any(p==q or p.startswith(q.rstrip('/')+'/') or fnmatch.fnmatch(p,q)for q in gen)
paths={p for p in g('ls-files','-z').decode().split('\0')if p}
protected={p:sha((repo/p).read_bytes())for p in paths if p.startswith('chicago/4d/') and (repo/p).is_file() and not generated(p) and not p.startswith('chicago/4d/data/sidecars/')}
for p in paths:
 if p.startswith('.github/workflows/')and(repo/p).is_file():protected[p]=sha((repo/p).read_bytes())
# The authored incoming changelog and strict tools are held despite any broad manifest entry.
for p in ['chicago/4d/renderers/web/js/changelog.js','chicago/4d/tools/smoke_renderer.mjs','chicago/4d/tools/drawn_placement_census.mjs','chicago/4d/tools/test_drawn_placement_census.mjs','chicago/4d/tools/measure_drawn_placement.mjs']:
 protected[p]=sha((repo/p).read_bytes())
(out/'PROTECTED_BEFORE.json').write_text(json.dumps(protected,indent=2)+'\n')
steps=[]
def command(name,args):
 free=shutil.disk_usage('/tmp').free;assert free>=536870912,(name,'native_helper512MiBreserve',free)
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();print(name,'START',start,flush=True)
 with (out/(name+'.log')).open('x') as log:r=subprocess.run(args,cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':args,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'free_before':free,'free_after':shutil.disk_usage('/tmp').free};steps.append(row);(out/'STEPS.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0,(name,r.returncode)
def protect(label):
 changed=[p for p,v in protected.items() if not(repo/p).exists()or sha((repo/p).read_bytes())!=v];assert not changed,(label,'authoredsource_or_assets_moved',changed)
 changed=[row['path']for row in people if sha((repo/row['path']).read_bytes())!=row['sha256']];assert not changed,(label,'resident_capacity_alternate_changed',changed)
 (out/(label+'-PROTECTIONS.json')).write_text(json.dumps({'all_authored_assets_controls_exact':len(protected),'people_capacities_versions_exact':len(people)},indent=2)+'\n')
command('01-native-resolve',['node','tools/rederive.mjs','--resolve'])
assert not g('diff','--name-only','--diff-filter=U').strip()
protect('post-resolve')
def canonical_xlsx(b):
 with zipfile.ZipFile(io.BytesIO(b)) as z:
  members={}
  for n in sorted(z.namelist()):
   raw=z.read(n)
   if n.endswith(('.xml','.rels')):
    root=ET.fromstring(raw)
    if n=='docProps/core.xml':
     for node in list(root):
      if node.tag=='{http://purl.org/dc/terms/}modified':root.remove(node)
    members[n]=ET.canonicalize(ET.tostring(root,encoding='unicode'))
   else:members[n]=raw
  return members
rows=[]
for row in before44:
 p=repo/row['path'];now=p.read_bytes();old=g('show',base+':'+row['path']);assert sha(old)==row['sha256'];same=now==old;kind='EXACT_BYTES'
 if not same:
  save=out/'regenerated-before-normalization'/row['path'];save.parent.mkdir(parents=True,exist_ok=True);save.write_bytes(now)
  if row['path'].lower().endswith('.xlsx'):same=canonical_xlsx(now)==canonical_xlsx(old);kind='ALL_XLSX_MEMBERS_CANONICAL_XML_EXCEPT_CORE_MODIFIED'
  else:same=gzip.decompress(now)==gzip.decompress(old);kind='GZIP_DECOMPRESSED_BYTES'
  if same:p.write_bytes(old)
 rows.append({'path':row['path'],'current_sha256':sha(now),'incoming_sha256':sha(old),'equivalent':same,'proof':kind,'action':'UNCHANGED'if now==old else'RESTORE_PROVEN_SERIALIZATION_ONLY'if same else'RETAIN_REAL_CHANGE'})
(out/'ONE_ALL44_ACTUAL_INCOMING_AUDIT.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(r['equivalent']for r in rows),'Actual binary data changed: preserve and review'
command('02-native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'])
command('03-native-publish',['bash','tools/publish.sh'])
for name,args in [('04-lodging-check',['python3','tools/build_lodging_model_1835.py','--check']),('05-boarders-check',['python3','tools/seat_lodgers_1835.py','--check']),('06-business-check',['python3','tools/reconstruct_businesses_1835.py','--group','lodging_river_and_transport','--check']),('07-staffing-check',['python3','tools/staffing_mint_order_1835.py','--check']),('08-strict-placement-fixtures',['node','tools/test_drawn_placement_census.mjs']),('09-independent-farwalk-census',['node','tools/check_far_plank_tops.mjs','--json'])]:command(name,args)
protect('final')
assert all(sha((repo/r['path']).read_bytes())==r['sha256']for r in before44)
result={'status':'PASS_CURRENT_23DD_NATIVE_CLOSURE_NO_CODECOMMIT_OR_BROWSER','head':head,'merge_head':base,'steps':steps,'all44_byteexact_incoming_after_proven_normalization':True,'protected_people_capacity_alternate':len(people),'protected_authored_assets':len(protected),'pending':'Actualfull3, codecommit/committedquestions/normalpush, freshapplicablepublishedrendererchecks, rootreadymerge.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
