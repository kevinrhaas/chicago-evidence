from pathlib import Path
import os,sys,subprocess,json,hashlib,datetime,tempfile,stat
repo=Path('/tmp/tremont-picture-20261026');holder=Path('/tmp/T2385-checked-Mary-Wolf-delta-plan-20261026');plan=json.loads((holder/'PLAN.json').read_text());old=plan['from_checked_Jail'];donor=plan['to_checked_Wolf'];original_own='c878258c511eb4854ffbd93c5c08ba2e0b8ea9a1';own='32dcead39aa5912d6e3722020f5a87086e387b26';oldbase='a575dddeed356333423b20361a1f90f3b39a862f';jail=sys.argv[1];assert len(jail)==40
out=holder/('prepared-'+jail[:12]);out.mkdir(exist_ok=False)
env=dict(os.environ);env['GIT_NO_LAZY_FETCH']='1'
def g(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=repo,env=env)
def blob(r,p):return g('show',r+':'+p)
def read_if_exists(r,p):
 r0=subprocess.run(['git','cat-file','-e',r+':'+p],cwd=repo,env=env,capture_output=True)
 return blob(r,p)if r0.returncode==0 else None
def write(p,b):
 p=repo/p;p.parent.mkdir(parents=True,exist_ok=True);mode=stat.S_IMODE(p.stat().st_mode)if p.exists() else 0o644
 with tempfile.NamedTemporaryFile(dir=p.parent,prefix='.t2385-source-',delete=False)as f:f.write(b);temp=f.name
 os.chmod(temp,mode);os.replace(temp,p)
def suffix(before,after,label):
 prefix=before.rstrip(b'\n');assert after.startswith(prefix),(label,'not_append_only');return after[len(prefix):]
sha=lambda b:hashlib.sha256(b).hexdigest()
assert g('rev-parse','HEAD').decode().strip()==own
assert subprocess.run(['git','rev-parse','-q','--verify','MERGE_HEAD'],cwd=repo,capture_output=True).returncode!=0
assert set(g('diff','--name-only').decode().splitlines())=={'chicago/4d/docs/STATUS.md','chicago/4d/tools/smoke_renderer.mjs'}
assert g('merge-base','--is-ancestor',old,jail)==b''
# External root/author supplies the immutable checked dependency; this script never fetches.
assert read_if_exists(jail,'chicago/4d/tools/test_dev_smoke_state.mjs')is not None and b'tools/test_dev_smoke_state.mjs --self-test' in blob(jail,'chicago/4d/tools/check.sh'), 'Expected checked newJail hash self-test registration'
index=Path(g('rev-parse','--git-path','index').decode().strip());index=index if index.is_absolute()else repo/index
(out/'old-prepared.index').write_bytes(index.read_bytes());(out/'old-status.txt').write_bytes(g('status','--porcelain=v1'));(out/'old-unmerged.txt').write_bytes(g('ls-files','-u'))
# Own uncommitted two-path patch is already immutable and privately checkpointed.
patch=Path('/tmp/T2385-a9c5-merge-preparation-20261026/premerge-two-path.patch');assert sha(patch.read_bytes())=='933099ff0f77c13dbfaa601aa50da002a0eb7127f81763937f516dab5d97f668'
(out/'preserved-own-probe-status.patch').write_bytes(patch.read_bytes())
# Preserve current repair privately; source remains on the existing public32 ancestry.
(out/'post32-own.patch').write_bytes(g('diff','--binary'))
checkpoint=g('stash','create','T2385 public32 native probe repair before checked Jail integration').decode().strip();assert len(checkpoint)==40
subprocess.run(['git','update-ref','refs/checkpoints/t2385-32dc-probe-pre-jail-'+jail[:12],checkpoint,'0'*40],cwd=repo,check=True)
(out/'PRIVATE_CHECKPOINT.txt').write_text(checkpoint+'\n')
subprocess.run(['git','restore','--source=HEAD','--worktree','--','chicago/4d/docs/STATUS.md','chicago/4d/tools/smoke_renderer.mjs'],cwd=repo,check=True)
assert not g('status','--porcelain=v1').strip()
r=subprocess.run(['git','merge','--no-commit','--no-ff',jail],cwd=repo,capture_output=True)
(out/'normal-new-jail-merge.stdout').write_bytes(r.stdout);(out/'normal-new-jail-merge.stderr').write_bytes(r.stderr)
assert r.returncode in (0,1)and g('rev-parse','MERGE_HEAD').decode().strip()==jail
# Reconcile append-only authored documents as exact newest dependency + exact Mary/Wolf + exact Tremont.
docrows=[]
for p in ['chicago/4d/docs/LIBERTIES.md','chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md']:
 incoming=blob(jail,p);mary_wolf=suffix(blob(old,p),blob(donor,p),p+' donor');tremont=suffix(blob(oldbase,p),blob(original_own,p),p+' own')
 body=incoming.rstrip(b'\n')+mary_wolf+tremont
 assert body.startswith(incoming)and body.endswith(tremont)
 write(p,body);subprocess.run(['git','add','--',p],cwd=repo,check=True)
 docrows.append({'path':p,'latest_dependency_sha256':sha(incoming),'Mary_Wolf_added_sha256':sha(mary_wolf),'Tremont_added_sha256':sha(tremont),'merged_sha256':sha(body)})
# Copy only the exact owned donor source/assets. Every pre-existing source/asset must still equal oldJail.
records=[]
for p in plan['categories']['authored_exact']+plan['categories']['assets']:
 before=read_if_exists(old,p);incoming=read_if_exists(jail,p);assert incoming==before,(p,'newJail unexpectedly changed donor-owned path')
 after=blob(donor,p);write(p,after);records.append({'path':p,'bytes':len(after),'sha256':sha(after),'checked_donor_blob':g('rev-parse',donor+':'+p).decode().strip()})
# Entrywise asset receipts: preserve every latest incoming and own Tremont record outside exact changed keys.
registry=[]
for p,key in [('chicago/4d/assets/manifest.json','assets'),('chicago/4d/assets/manifest.web.json','masters')]:
 before=json.loads(blob(old,p));after=json.loads(blob(donor,p));current=json.loads((repo/p).read_bytes());keys=set(plan['registry_changed_keys'][p]);others={k:v for k,v in current[key].items()if k not in keys};outer={k:v for k,v in current.items()if k!=key}
 for k in keys:
  assert current[key].get(k)==before[key].get(k),(p,k,'incoming or own asset record changed')
  if k in after[key]:current[key][k]=after[key][k]
  else:current[key].pop(k,None)
 assert others=={k:v for k,v in current[key].items()if k not in keys}and outer=={k:v for k,v in current.items()if k!=key}
 write(p,(json.dumps(current,indent=2)+'\n').encode());registry.append({'path':p,'exact_checked_donor_rows':len(keys),'all_other_incoming_own_rows_unchanged':True})
# Mary loading_009 correction only; all other loading entries and schema metadata stay exact latest incoming.
p='chicago/4d/data/loading/statuses.json';before=json.loads(blob(old,p));after=json.loads(blob(donor,p));current=json.loads((repo/p).read_bytes());oldrows={v['id']:v for v in before['entries']};newrows={v['id']:v for v in after['entries']};changed={k for k in set(oldrows)|set(newrows)if oldrows.get(k)!=newrows.get(k)};assert changed=={'loading_009'}
for i,row in enumerate(current['entries']):
 if row['id']in changed:assert row==oldrows[row['id']];current['entries'][i]=newrows[row['id']]
write(p,(json.dumps(current,indent=2)+'\n').encode())
# Reapply same native sign-reading and exact far-walk census repairs; never replace the newJail smoke/hash files.
r=subprocess.run(['git','apply','--check',str(patch)],cwd=repo,capture_output=True);assert r.returncode==0,r.stderr.decode();subprocess.run(['git','apply',str(patch)],cwd=repo,check=True)
# Remove only the earlier duplicate donor range when dev already supplies that exact ID.
p=repo/'chicago/4d/tools/smoke_renderer.mjs';s=p.read_text();duplicate="          // T-1880/T-1934 retained these separately modeled, 1904-dated rear ranges.\n          'pullman_house_1729_prairie_ranges',\n"
if s.count("'pullman_house_1729_prairie_ranges'")==2:
 assert s.count(duplicate)==1;s=s.replace(duplicate,'');write(str(p.relative_to(repo)),s.encode())
import re
array=re.search(r"const PLACED_1904 = (\[[\s\S]*?\])\.sort\(\);",s).group(1);ids=re.findall(r"'([^']+)'",re.sub(r'//[^\n]*','',array));assert len(ids)==len(set(ids))==283
# Preserve every newJail hash partition/check registration byte-exact (not a donor path).
protected_partition=[]
for p in g('diff','--name-only',old,jail).decode().splitlines():
 if p.startswith('chicago/4d/tools/')and ('smoke' in p or p.endswith(('/check.sh','/step_isolation.json')))and p!='chicago/4d/tools/smoke_renderer.mjs':
  if p.endswith('/step_isolation.json'):
   current=json.loads((repo/p).read_bytes());j=json.loads(blob(jail,p));prior=json.loads(blob(own,p))
   assert all(current['tools'].get(k)==v for k,v in j['tools'].items()),'NewJail measured isolation row was lost'
   assert all(current['tools'].get(k)==v for k,v in prior['tools'].items()),'Public32 runner isolation row was lost'
  elif p.endswith('/check.sh'):
   mergebase=g('merge-base',jail,own).decode().strip();inputs=[]
   for name,ref in [('jail',jail),('base',mergebase),('public32',own)]:
    q=out/('check.sh-'+name);q.write_bytes(blob(ref,p));inputs.append(str(q))
   merged=subprocess.run(['git','merge-file','-p',*inputs],cwd=repo,capture_output=True);(out/'check.sh-expected-merge').write_bytes(merged.stdout)
   assert merged.returncode==0 and (repo/p).read_bytes()==merged.stdout,'check.sh must preserve BOTH checked Jail partition assertion and public32/dev runner checks'
  else:assert (repo/p).read_bytes()==blob(jail,p),(p,'new native partition assertion overwritten')
  protected_partition.append(p)
# Scope qualification: actual owning native pass is still required for every derived conflict/output.
unmerged=g('diff','--name-only','--diff-filter=U').decode().splitlines();assert not any(p in unmerged for p in plan['categories']['authored_exact']+plan['categories']['assets']+plan['categories']['authored_union']+plan['categories']['registries'])
subprocess.run(['node','--check','chicago/4d/tools/smoke_renderer.mjs'],cwd=repo,check=True)
result={'status':'NORMAL_NEW_CHECKED_JAIL_MERGE_WITH_PRECISE_CHECKED_MARY_WOLF_TRANSPLANT_NO_NATIVE_OR_CODECOMMIT','head':own,'merge_head':jail,'donor':donor,'donor_base':old,'documents':docrows,'exact_source_asset_records':records,'registries':registry,'newJail_partition_files_exact':protected_partition,'unmerged_derived':unmerged,'derived_old_donor_paths_not_copied':plan['categories']['derived_skip'],'own_probe_status_patch_sha256':sha(patch.read_bytes()),'pending':'One owning native closure, actual all44 incoming audit, package/publish, full3, checked commit and one current exact-head matrix.'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'head':own,'merge_head':jail,'exact_source_asset_records':len(records),'newJail_partition_files_exact':protected_partition,'unmerged_derived':unmerged}),flush=True)
