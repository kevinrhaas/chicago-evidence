from pathlib import Path
import subprocess,json,datetime,time
repo=Path('/tmp/tremont-picture-20261026');holder=Path('/tmp/T2385-checked-Mary-Wolf-delta-plan-20261026/prepared-23dddb8feb66');out=holder/'public-checked';out.mkdir(exist_ok=False);c=json.loads((holder/'checked-codecommit/RESULT.json').read_text());r=json.loads((holder/'codecommit-reaper.json').read_text());assert r['command_exit']==0 and r['all_children_reaped']and not r['leftover_cleanup'];head=c['HEAD'];branch='steward/t2385-tremont-gale-a575';verification='verification/t2385-'+head[:12]+'-renderer-20261026'
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path]))
pr=api('pulls/1337');(out/'PR-before.json').write_text(json.dumps(pr,indent=2)+'\n');assert pr['state']=='open'and pr['draft']and pr['head']['sha']=='32dcead39aa5912d6e3722020f5a87086e387b26'
lock=subprocess.run(['node','chicago/4d/tools/ticket.mjs','lap','1337','--status'],cwd=repo,capture_output=True,text=True);(out/'native-lap-status.log').write_text(lock.stdout+lock.stderr);assert lock.returncode==3 and 'Codex Tremont Gale evidence 2026-10-26'in lock.stdout
steps=[]
for name,target in [('normal-FF-public-PR',branch),('normal-new-immutable-verification',verification)]:
 with(out/(name+'.log')).open('x')as log:r=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','push','origin',head+':refs/heads/'+target],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 steps.append({'name':name,'ref':target,'exit_code':r.returncode});(out/'STEPS.json').write_text(json.dumps(steps,indent=2)+'\n');assert r.returncode==0,(name,r.returncode)
 observed=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+target],cwd=repo,text=True).split();assert observed[0]==head,(target,observed)
for i in range(12):
 pr=api('pulls/1337')
 if pr['head']['sha']==head:break
 time.sleep(1)
assert pr['draft']and pr['head']['sha']==head;(out/'PR-after.json').write_text(json.dumps(pr,indent=2)+'\n')
result={'status':'NORMAL_FF_PUBLIC_PR_AND_NEW_IMMUTABLE_VERIFICATION_CONFIRMED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'PR':1337,'head':head,'tree':c['tree'],'parents':c['parents'],'branch':branch,'verification_branch':verification,'DRAFT':True,'steps':steps,'native_hashes':json.loads(c['native_hash_raw']),'pending':'ONEactual18matrix on immutable verification at same PR SHA; current hosted checks, upstreamlandings and finalownMscope before normal expectedSHADEVmerge. OriginalT2385OPEN/DIF.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
