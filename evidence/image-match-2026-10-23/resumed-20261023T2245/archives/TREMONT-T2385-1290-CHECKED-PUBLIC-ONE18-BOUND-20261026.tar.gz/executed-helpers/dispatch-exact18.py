from pathlib import Path
import subprocess,json,datetime,time,urllib.parse
holder=Path('/tmp/T2385-checked-Mary-Wolf-delta-plan-20261026/prepared-23dddb8feb66');c=json.loads((holder/'public-checked/RESULT.json').read_text());r=json.loads((holder/'public-push-reaper.json').read_text());assert r['command_exit']==0 and r['all_children_reaped']and not r['leftover_cleanup'];out=holder/'matrix1290';out.mkdir(exist_ok=False);head=c['head'];branch=c['verification_branch'];rows=[];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path]))
query='actions/workflows/chicago-4d-smoke.yml/runs?branch='+urllib.parse.quote(branch,safe='')+'&event=workflow_dispatch&per_page=100'
pr=api('pulls/1337');assert pr['draft']and pr['head']['sha']==head;(out/'PR-initial.json').write_text(json.dumps(pr,indent=2)+'\n');ref=api('git/ref/heads/'+branch);assert ref['object']['sha']==head
initial=api(query);(out/'runs-initial.json').write_text(json.dumps(initial,indent=2)+'\n');known={x['id']for x in initial['workflow_runs']};assert not known,'Immutable ref must have no prior matrix; never redispatch blindly'
for viewport in ['desktop','mobile']:
 for stage in ['1-2','3-4','5','6-7','8','9-12','13','14','15']:
  name=viewport+'-'+stage;payload={'ref':branch,'inputs':{'viewport':viewport,'stage':stage}};path=out/(name+'-request.json');path.write_text(json.dumps(payload,indent=2)+'\n')
  attempt={'viewport':viewport,'stage':stage,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'ref':branch,'rule':'Request only once. Lost response is reconciled by fresh immutable-ref runs, never a blind retry.'};(out/(name+'-attempt.json')).write_text(json.dumps(attempt,indent=2)+'\n')
  r=subprocess.run(['gh','api','repos/kevinrhaas/chicago/actions/workflows/chicago-4d-smoke.yml/dispatches','--method','POST','--input',str(path)],capture_output=True,text=True);(out/(name+'-dispatch.stdout')).write_text(r.stdout);(out/(name+'-dispatch.stderr')).write_text(r.stderr)
  found=[]
  for retry in range(20):
   data=api(query);found=[x for x in data['workflow_runs']if x['id']not in known]
   if found:break
   time.sleep(1)
  assert len(found)==1,(name,'UNKNOWN_OR_AMBIGUOUS_REQUEST_NO_REDISPATCH',r.returncode,[x['id']for x in found]);run=found[0];assert run['head_sha']==head and run['head_branch']==branch and run['event']=='workflow_dispatch'
  known.add(run['id']);row={'viewport':viewport,'stage':stage,'id':run['id'],'observed_head':run['head_sha'],'observed_branch':run['head_branch'],'dispatch_returncode':r.returncode,'dispatch_accepted':True,'bound_by':'only newly observed run after exactly one request on a unique immutable SHA-named ref','created_at':run['created_at']};rows.append(row);(out/(name+'-run.json')).write_text(json.dumps(run,indent=2)+'\n');(out/'PROGRESS.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
assert len(rows)==len({x['id']for x in rows})==18
pr=api('pulls/1337');(out/'PR-final.json').write_text(json.dumps(pr,indent=2)+'\n');assert pr['draft']and pr['head']['sha']==head
result={'status':'DISPATCHED_NOT_RESULTS','PR':1337,'head':head,'tree':c['tree'],'branch':branch,'PR_branch':c['branch'],'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':rows,'unique18':True,'same_actual_PR_head':True,'immutable_ref':True,'native_hashes':c['native_hashes'],'qualification':'All18 requests individually accepted/bound, no actual terminal result or performance/image match certificate yet. Originalc87816PASS2FAIL retained. OriginalT2385 remains OPEN/DIF.'};(out/'BOUND_DISPATCH.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
