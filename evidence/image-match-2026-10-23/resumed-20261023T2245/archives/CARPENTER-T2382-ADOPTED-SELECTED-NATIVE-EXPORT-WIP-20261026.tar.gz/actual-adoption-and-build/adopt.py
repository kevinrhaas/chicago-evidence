from pathlib import Path
import json,hashlib,dataclasses,subprocess,os,shutil,datetime,stat
from generators.archetypes.log_dwelling_params import from_phase
repo=Path('/tmp/jail-picture-c6'); app=repo/'chicago/4d'; out=Path('/workspace/T2382-Carpenter-adoption-20261026')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head=='1290a23271b2771c77201fd17fed7cfa857ade14'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
p=app/'data/structures/philo_carpenter_log_shop.json'; before=p.read_bytes();assert hashlib.sha256(before).hexdigest()=='28cfda1ca433a537f8880d231b3aa7471587759f3bdd8c47e99cc36e2e1839ca'
after=Path('/workspace/T2382-Carpenter-recess-proposal-ce892-20261026/proposed.json').read_bytes();a=json.loads(before);b=json.loads(after)
removed=b['phases'][0]['form'].pop('front_door_state');assert b==a;b=json.loads(after)
pa=from_phase(a['phases'][0],a);pb=from_phase(b['phases'][0],b);pa.validate();pb.validate()
da=dataclasses.asdict(pa);db=dataclasses.asdict(pb);diff={k:{'before':da[k],'after':db[k]} for k in da if da[k]!=db[k]}
assert set(diff)=={'front_door_state','confidence'},diff
assert db['confidence']==dict(da['confidence'],front_door_state='reconstructed')
assert db['front_door_state']=='recess' and da['front_door_state']=='closed'
assets={}
for root,dirs,files in os.walk(app/'assets'):
 for name in files:
  f=Path(root)/name;assert not f.is_symlink(),str(f);info=f.stat()
  assets[str(f.relative_to(app))]={'bytes':info.st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'mode':stat.S_IMODE(info.st_mode)}
for name in ['manifest.json','manifest.web.json']:shutil.copy2(app/'assets'/name,out/('before-'+name))
(out/'ASSETS-ACTUAL-BEFORE.json').write_text(json.dumps(assets,indent=2)+'\n');(out/'record-before.json').write_bytes(before);(out/'record-proposed.json').write_bytes(after)
tmp=p.with_suffix('.json.carpenter-tmp');tmp.write_bytes(after);os.replace(tmp,p)
links=[]
for rel in ['assets/gltf/philo_carpenter_log_shop__log_1832.glb','assets/web/philo_carpenter_log_shop__log_1832.glb']:
 f=app/rel;info=f.stat();oldhash=hashlib.sha256(f.read_bytes()).hexdigest();target=out/('before-'+f.parent.name+'-'+f.name);shutil.copy2(f,target)
 if info.st_nlink>1:
  copy=f.with_name(f.name+'.carpenter-private-tmp');shutil.copy2(f,copy);assert hashlib.sha256(copy.read_bytes()).hexdigest()==oldhash;os.replace(copy,f)
 assert hashlib.sha256(f.read_bytes()).hexdigest()==oldhash
 links.append({'path':rel,'old_nlink':info.st_nlink,'current_nlink':f.stat().st_nlink,'same_bytes':True})
state={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ONE_RECORD_ADOPTED_NATIVE_EXPORT_NOT_YET_RUN','base':head,'branch':subprocess.check_output(['git','branch','--show-current'],cwd=repo,text=True).strip(),'claim_commit':'15e232ce359931128c56e87d7b9df148b28a2279','native_actual_param_diff':diff,'source_field':removed,'actual_assets_snapshotted':len(assets),'selected_hardlink_protection':links,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'all_other_json_values_equal':True,'original_image_acceptance':'OPEN/DIFFERS no closure claim','initial_guard_stop':'Expected only state but native correctly adds confidence.front_door_state=reconstructed; no first-attempt source mutation. Corrected exact state+single confidence-entry admission.'}
(out/'ADOPTION.json').write_text(json.dumps(state,indent=2,default=str)+'\n');print(json.dumps({'status':state['status'],'native_param_diff':diff,'assets_protected':len(assets),'hardlinks':links},default=str))
