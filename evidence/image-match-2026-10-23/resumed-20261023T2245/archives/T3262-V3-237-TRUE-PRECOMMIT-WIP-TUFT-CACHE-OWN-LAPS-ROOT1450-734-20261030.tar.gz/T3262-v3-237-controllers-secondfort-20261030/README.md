# T-3262 V3: one genuine 89ad+237 source gate, checkpoint and current phone

External frozen preparation only. No primary source, Git, API, gate, native, browser or meter execution occurred here. Old 89ad's actual full-check PASS and actual 400.997/400 MiB phone failure are retained; this capsule does not rerun or relabel that head.

Root's adjusted source phase is one genuine merge with parents `[89ad07fd2b43679c028715dbf30830b7dacf2a54, 2378484c31b91a1b8d28fd8430d2b4d1a783bdaa]`, followed by the approved two V3 code postimages and two raw document prefixes. Gate requires source HEAD89ad/tree36590ee4e51d8970ebcb25608f36e7a7bf217912, actual MERGE_HEAD237, cached origin/dev237, actual root-reviewed staged tree and exact staged path map. The actual tree/new commit is unknown until root performs those operations. No single-parent or obsolete 3c/3e postimage assumption remains.

The actual staged map may contain 1–64 paths; the expected approximately17 is not guessed or hardcoded. Canonical incoming paths are derived from real bcf→237. Every non-own staged path's cached/working blob, mode and deletion must be exact237. The complete prospective tree may differ from237 in **only the original seven own paths**. Existing spatial-batch.js, check_confidence_lane.mjs and own changelog stay exact89ad. The two changed code hashes are the closed/root-approved candidate:

- railway.js: `285af6877c55f23fd88611e547b05437fdfd05becb2af3bfcc3ebd238113a0f1`
- test_rail_geometry_lifecycle.mjs: `948b025ba5f457c128392bad1642b0bffd4728c73c7f9214922df92065cda8a4`

The closed candidate manifest is `724f203129f7575c73a36b12a6db4e64b72b98f9edb01e19be5bb8702d1ad997`, all20 members verified during preparation. The actual736-check receipt, existing tie44/76 parity, checked tuft32/fallback behavior and post-grade raw-scratch proof remain in that separate authority. No unit or runtime was rerun here.

STATUS/ROADMAP composition uses raw bytes, preserving ROADMAP's invalid UTF8: exactly root's717-byte V3 prefix, then the prior own prefix from89ad overbcf, then the **complete exact237 body**. If incoming did not change that document, this is identical to the prepared717-prefix+89ad body. No old whole-document hash is blindly imposed after the merge. Root supplies actual final hashes in its reviewed manifest.

## Root-reviewed staged manifest and gate

After actual import/merge/application/staging, root provides:

```json
{
  "status": "ROOT_REVIEWED_T3262_V3_237_MERGE_STAGED_PATHS",
  "root_reviewed": true,
  "head": "89ad07fd2b43679c028715dbf30830b7dacf2a54",
  "merge_parent": "2378484c31b91a1b8d28fd8430d2b4d1a783bdaa",
  "tree": "ACTUAL_REVIEWED_40_CHARACTER_STAGED_TREE",
  "all_staged_paths": {"ACTUAL_PRESENT_PATH": "ACTUAL_SHA256", "ACTUAL_DELETION_IF_ANY": null},
  "own4_postimages": {
    "chicago/4d/renderers/web/js/railway.js": "285af6877c55f23fd88611e547b05437fdfd05becb2af3bfcc3ebd238113a0f1",
    "chicago/4d/tools/test_rail_geometry_lifecycle.mjs": "948b025ba5f457c128392bad1642b0bffd4728c73c7f9214922df92065cda8a4",
    "chicago/4d/docs/STATUS.md": "ACTUAL_FINAL_COMPOSED_SHA256",
    "chicago/4d/docs/ROADMAP.md": "ACTUAL_FINAL_COMPOSED_SHA256"
  }
}
```

Placeholders are descriptive only; no fabricated approval/tree is supplied. `own4_postimages` is a four-entry **path→SHA256 string** map, equal to those entries in the complete staged map and actual seven-source hash map.

```sh
python -B /workspace/T3262-v3-237-controllers-secondfort-20261030/gate.py --expect-head 89ad07fd2b43679c028715dbf30830b7dacf2a54 --expect-merge-parent 2378484c31b91a1b8d28fd8430d2b4d1a783bdaa --expect-tree ACTUAL_TREE --expect-branch ACTUAL_BRANCH --ticket T-3262 --reviewed-manifest ACTUAL_ROOT_REVIEW_JSON --execute
python -B /workspace/T3262-v3-237-controllers-secondfort-20261030/checkpoint.py --expect-head 89ad07fd2b43679c028715dbf30830b7dacf2a54 --expect-merge-parent 2378484c31b91a1b8d28fd8430d2b4d1a783bdaa --expect-tree ACTUAL_TREE --expect-branch ACTUAL_BRANCH --ticket T-3262 --execute
```

Gate preserves the full unchanged native check, four workers/CPUs0,1,3,4, exact reviewed tiny local-file fixture shim, child reaper, source/index/config/ref checks and actual CHECK PASS footer. Workspace floor536,870,912 B+8 MiB log reserve and shared TMP before/after1,800,000,000 B remain unchanged. Native source outcome is preserved before final resource recheck; a floor failure never automatically becomes a qualified GATE result.

PASS status is `ACTUAL_T3262_V3_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_PASS`, revision `V3_CURRENTDEV_237`. Binding carries head/source_head89ad, merge_parent/pr_base237, checked_final_staged_tree, actual all_staged_paths, all7_source_sha256, own4_postimages, root_reviewed_manifest_sha256, branch/ticket/config/index/refs, canonical incoming entries and raw document composition. Every legacy and added guard must pass. Checkpoint is one ordinary genuine two-parent commit, exact checked tree, all three PR questions against237 and only the own branch ref changed. Its PASS status is `ACTUAL_T3262_V3_CURRENTDEV_INTEGRATION_NATIVE_MERGE_CHECKPOINT_PASS`; actual new SHA is determined only then.

## Fresh actual new-head phone and native diffmap

After that actual checkpoint, replace the following head/tree/branch with real values:

```sh
python -B /workspace/T3262-v3-237-controllers-secondfort-20261030/phone.py --expect-head ACTUAL_NEW_HEAD --expect-tree ACTUAL_TREE --expect-branch ACTUAL_BRANCH --ticket T-3262 --execute
python -B /workspace/T3262-v3-237-controllers-secondfort-20261030/smoke.py --expect-head ACTUAL_NEW_HEAD --expect-tree ACTUAL_TREE --expect-branch ACTUAL_BRANCH --ticket T-3262 --outdir /workspace/ACTUAL_NEW_V3_SMOKE_OUTPUT --execute
```

Phone binds this new gate/checkpoint/head/two parents, all seven source hashes, source/index/config/refs, current authoritative data/binary rows including the Field body, and actual current native publication. The complete official `node tools/measure_memory.mjs --year 1904 --only mobile --gate --no-snapshot` command and400 MiB configuration are unchanged. Output is `PHONE-V3-*`; status is `ACTUAL_T3262_V3_CURRENTDEV_237_NATIVE_PHONE_PASS` or `_NOT_QUALIFIED`. Unique owned workspace TMP is `/workspace/v3-ph`, with the unchanged24 MiB reserve/reaper/floor guards. No prior head's reading qualifies the new scene.

Smoke defaults to stages14,1,2,3,7,8,9,10,11,12, desktop then mobile sequentially for each. A requested subset is labeled partial. Full-map BOTH PASS requires all20 actual native cells and unchanged source/data/publication guards; native assertions, waits and timeouts are unchanged. Unique owned TMP `/workspace/v3-map`; outputs `SMOKE-V3-*`. Runtime phases remain serial and separately root-authorized. Current-head CI, normal-FF publication and safe dev merge remain separate root/publisher work.
