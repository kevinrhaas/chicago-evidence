import argparse,os,json
_ap=argparse.ArgumentParser(description="ONE approved natural canonical-copy retirement; default metadata only")
_ap.add_argument('--execute',action='store_true');_ap.add_argument('--expected-primary');_args=_ap.parse_args()
if not _args.execute:
 print(json.dumps({'status':'PREPARED_READONLY_NO_RETIREMENT','expected_primary':'89ad07fd2b43679c028715dbf30830b7dacf2a54','path':'/workspace/worktrees/t2373-lighthouse/chicago/4d/assets/gltf/terrain__e1830_natural.glb','blob':'7f2e52f2872a09f10dad03e44ab411117d3a9ad3','allocated_B':30007296,'append_existing_note_preserve_prior_prefix':True}));raise SystemExit(0)
assert _args.expected_primary=='89ad07fd2b43679c028715dbf30830b7dacf2a54'
assert os.environ.get('T2373_NATURAL_RETIRE_LEASE')=='root-approved-one-natural-terrain-only'
from pathlib import Path
import os,stat,json,hashlib,subprocess,datetime,shutil
P=Path('/workspace/t2373-natural-terrain-canonical-copy-retirement-20261030');Q=Path(__file__).resolve().parent;W=Path('/workspace/worktrees/t2373-lighthouse');R=Path('/workspace/chicago');C=R/'.git';G=C/'worktrees/t2373-lighthouse'
F=W/'chicago/4d/assets/gltf/terrain__e1830_natural.glb';NOTE=W/'RESTORE-RETIRED-TERRAIN.md';OID='7f2e52f2872a09f10dad03e44ab411117d3a9ad3';H='7355878e618d7ed37dcbd65fab5c99fe64c9599b6c83ba2066e683d1465e48cf'
os.sched_setaffinity(0,{2});os.nice(19);E=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1')
PF=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(root,*a):return subprocess.check_output(['git','--no-optional-locks','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','protocol.allow=never','-C',str(root),*a],env=E)
def ident(p):
 s=p.lstat();return(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
source7=json.loads((Q/'CURRENT-PRIMARY-GUARDS.json').read_text())['source7'];assert len(source7)==7
def primary():
 out={'HEAD':git(R,'rev-parse','HEAD').decode().strip(),'HEAD_file':PF(C/'HEAD'),'index':PF(C/'index'),'index_semantic':hashlib.sha256(git(R,'ls-files','--stage','-z')).hexdigest(),'index_flags':hashlib.sha256(git(R,'ls-files','-v','-z')).hexdigest(),'config':PF(C/'config'),'refs':hashlib.sha256(git(R,'for-each-ref','--format=%(refname) %(objectname)')).hexdigest(),'status':hashlib.sha256(git(R,'status','--porcelain=v1','-z','--untracked-files=all')).hexdigest(),'source7':{p:PF(R/p)for p in source7}}
 assert out['source7']==source7;return out
assert not P.exists();P.mkdir(mode=0o700)
before=primary();assert before['HEAD']=='89ad07fd2b43679c028715dbf30830b7dacf2a54'
a=json.loads((Q/'AUDIT.json').read_text());assert PF(Q/'AUDIT.json')=='514f4c89ab76779ef2cc3ed7e0626a063134bbef274068b18fd8843728328520' and PF(Q/'PUBLIC-RESTORE-METADATA.json')=='4e634d89c292ff2fa6b68daa2dbf57ba44f93e15093753569bb311c3cf4195cd' and PF(Q/'CURRENT-PRIMARY-GUARDS.json')=='bf6989175b4235400c8e633b6b752e3b7320139fe7df451017e450242d4b23b1'
old_index=PF(G/'index');old_HEAD_file=PF(G/'HEAD');assert old_index==a['worktree_index_sha256_unchanged']and old_HEAD_file==a['worktree_HEAD_file_sha256_unchanged']
assert git(W,'rev-parse','HEAD').decode().strip()==a['old_HEAD'];rel=str(F.relative_to(W));assert git(W,'ls-files','--stage','--',rel).decode().strip()==a['old_index_entry'];assert git(W,'ls-tree',a['old_HEAD'],'--',rel).decode().strip()==a['old_HEAD_tree_entry'];assert git(W,'ls-files','-v','--',rel).decode().strip()=='H '+rel
s=F.lstat();selected_id=ident(F);assert stat.S_ISREG(s.st_mode)and s.st_nlink==1 and stat.S_IMODE(s.st_mode)==0o600 and s.st_size==30004072 and PF(F)==H
assert (s.st_dev,s.st_ino,s.st_mtime_ns,s.st_blocks*512)==(a['file']['dev'],a['file']['ino'],a['file']['mtime_ns'],a['file']['allocated_B'])
assert git(W,'cat-file','-t',OID).strip()==b'blob'and git(W,'cat-file','-s',OID).strip()==b'30004072'
pack=Path(a['canonical_local_blob']['locations'][0]['pack']);pack_id=ident(pack)
primary_file=R/rel;primary_id=ident(primary_file);assert not primary_file.is_symlink()and primary_id[:2]!=ident(F)[:2]and PF(primary_file)==H
wip=json.loads(Path('/workspace/t2373-single-glb-funding-readonly-20261030/WIP-SOURCE-MANIFEST.json').read_text())['files'];assert len(wip)==10
def verify_wip():
 for r in wip:
  p=Path(r['path']);assert p.stat().st_size==r['bytes']and stat.S_IMODE(p.stat().st_mode)==r['mode']and PF(p)==r['sha256']
verify_wip();old_status=git(W,'status','--porcelain=v1','-z','--untracked-files=all','--ignored=matching');assert NOTE.is_file()and not NOTE.is_symlink();old_note=NOTE.read_bytes();note_binding=json.loads((Q/'EXISTING-NOTE-BINDING.json').read_text());assert PF(NOTE)==note_binding['sha256']and len(old_note)==note_binding['bytes']
protected={p:ident(p)for p in [W/'.claude',W/'node_modules',W/'chicago/4d/tickets']}
# Recheck actual exact/ancestor symlink aliases. No private/config/dependency reads.
skip={'.git','node_modules','.claude','.codex','.agents','.aws','.cache','Cache','Caches','Default','GPUCache','ShaderCache','Code Cache','Crashpad','BrowserMetrics'};skiproots={Path('/workspace/shared'),Path('/workspace/b2378p30'),Path('/workspace/b2378l30'),Path('/workspace/b2378a30')};stack=[Path('/workspace')];aliases=[];links=0
while stack:
 d=stack.pop()
 for e in os.scandir(d):
  q=Path(e.path)
  if e.is_symlink():
   links+=1;t=Path(os.path.realpath(q))
   if t==F or(F.is_relative_to(t)and t.is_dir()):aliases.append(str(q))
  elif e.is_dir(follow_symlinks=False)and q not in skiproots and e.name not in skip and not any(x in e.name.lower()for x in ['playwright_chromiumdev_profile','browser-profile','chromium-profile','private-profile']):stack.append(q)
assert not aliases
live=[];unreadable=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 pid=int(p.name)
 for key in ['cwd','exe']:
  try:t=os.readlink(p/key)
  except OSError:continue
  if t==str(W)or t.startswith(str(W)+'/'):live.append((pid,key))
 try:
  if str(W)in(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace'):live.append((pid,'argv'))
 except OSError:pass
 try:fds=list((p/'fd').iterdir())
 except OSError:unreadable.append(pid);continue
 for fd in fds:
  try:t=os.readlink(fd);fs=fd.stat()
  except OSError:continue
  if t==str(F)or t.startswith(str(W)+'/')or(fs.st_dev,fs.st_ino)==(s.st_dev,s.st_ino):live.append((pid,'fd'))
 try:
  if str(W)in(p/'maps').read_text(errors='replace'):live.append((pid,'maps'))
 except OSError:pass
assert not live
inaccessible_non_zombies=[];zombies=0
allowed={(r['pid'],r['name']) for r in json.loads((Q/'FD-CLASSIFICATION.json').read_text())['non_zombie_protected_FD_processes']}
for pid in unreadable:
 try:
  status=(Path('/proc')/str(pid)/'status').read_text();fields=dict(line.split(':',1) for line in status.splitlines() if ':'in line)
 except FileNotFoundError:continue
 state=fields['State'].strip().split()[0];name=fields['Name'].strip()
 if state=='Z':zombies+=1;continue
 assert (pid,name)in allowed and set(fields['Uid'].split())=={'65534'}
 inaccessible_non_zombies.append({'pid':pid,'name':name,'state':state,'classification':'unrelated protected daemon, no affected readable metadata'})
assert primary()==before;verify_wip();assert ident(F)==selected_id and PF(F)==H and NOTE.read_bytes()==old_note
note=f'''

## ADDITIONAL RETIRED COPY: NATURAL TERRAIN — RESTORE BOTH BEFORE REUSE

The preceding harbor-cut retirement entry is preserved byte-for-byte. Under separate root authorization, ONLY this second inactive canonical copy was temporarily retired for storage:
{F}

NEVER COMMIT EITHER ASSET DELETION. Restore BOTH retired terrain paths before reusing/building/publishing this old worktree. Existing10WIP, oldindex/HEAD/flags and privateconfigs/ticketlink remain intact. This does not change the primary/historical model.

Exact native local Git restore stream (to ONE sibling temporary file, verify size/hash/mode, fsync, then atomically restore ONLY the missing natural path; no checkout/index writes):
GIT_NO_LAZY_FETCH=1 GIT_OPTIONAL_LOCKS=0 git --no-optional-locks -c protocol.allow=never --git-dir=/workspace/chicago/.git cat-file blob {OID}

Independent immutable public89ad restore URL:
{a['primary_comparison']['immutable_raw_url']}

Required bytes:30004072; SHA256:{H}; Git blob:{OID}; fullUnix0600(Git100644); originalmtime_ns:{s.st_mtime_ns}. No geometry regeneration, rawmodel copy now, source hardlink or skipworktree flags. Restore metadata: {P}/RESTORE-MAP.json.
'''
restore={'path':str(F),'old_HEAD':a['old_HEAD'],'old_index_sha256':old_index,'old_HEAD_file_sha256':old_HEAD_file,'blob':OID,'bytes':s.st_size,'sha256':H,'mode':'0o600','Git_mode':'100644','mtime_ns':s.st_mtime_ns,'public_url':a['primary_comparison']['immutable_raw_url'],'local_common_gitdir':str(C),'pack':str(pack),'source7_primary_before':before,'ten_WIP_preserved':wip,'no_aliases':True,'no_live_affected_references':True,'scanned_symlinks':links,'warning_note':str(NOTE),'prior_warning_note_sha256':PF(NOTE),'prior_warning_note_bytes':len(old_note)}
(P/'RESTORE-MAP.json').write_text(json.dumps(restore,indent=2)+'\n')
assert primary()==before and PF(G/'index')==old_index and PF(G/'HEAD')==old_HEAD_file
space_before={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']};F.unlink();assert not F.exists()
assert NOTE.read_bytes()==old_note;fd=os.open(NOTE,os.O_WRONLY|os.O_APPEND)
with os.fdopen(fd,'a')as out:out.write(note);out.flush();os.fsync(out.fileno())
assert NOTE.read_bytes()==old_note+note.encode();assert primary()==before and PF(G/'index')==old_index and PF(G/'HEAD')==old_HEAD_file;verify_wip();assert ident(primary_file)==primary_id and PF(primary_file)==H and ident(pack)==pack_id
for p,i in protected.items():assert ident(p)==i
new_status=git(W,'status','--porcelain=v1','-z','--untracked-files=all','--ignored=matching');oldrows=set(old_status.split(b'\0'))-{b''};newrows=set(new_status.split(b'\0'))-{b''};assert newrows-oldrows=={b' D '+rel.encode()}and not oldrows-newrows
space_after={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']}
result={'status':'AUTHORIZED_ONLY_OLD_CANONICAL_TERRAIN_COPY_UNLINKED_RESTORE_NOTE_CREATED_ALL_WIP_AND_PRIMARY_GUARDS_EXACT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'removed':str(F),'bytes':s.st_size,'allocated_reclaimed_B':s.st_blocks*512,'workspace_before_B':space_before['/workspace'],'workspace_after_B':space_after['/workspace'],'observed_net_workspace_delta_B':space_after['/workspace']-space_before['/workspace'],'TMP_before_B':space_before['/tmp'],'TMP_after_B':space_after['/tmp'],'warning_note':str(NOTE),'warning_note_sha256':PF(NOTE),'old_index_HEAD_flags_unchanged':True,'all10_WIP_bytes_modes_hashes_exact':True,'old_worktree_status':'existing4modified+6untracked WIP, priorharbor deletion plusnewnatural unstaged deletion; existinguntrackedrestore note appended preservingpriorharbor entry; ignoredtickets link intact','primary_source7_HEAD_index_semantics_flags_config_refs_status_exact':True,'primary_independent_terrain_and_shared_Gitpack_exact':True,'actual_symlink_aliases':0,'live_affected_FD_cwd_argv_maps':0,'fresh_inaccessible_FD_classification':{'zombies':zombies,'non_zombies':inaccessible_non_zombies},'no_other_deletions_source_changes_hardlinks_or_Gitobject_mutations':True,'import_authorized':False,'root_explicit_phase_handshake_required':True}
(P/'RETIRED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
