# RESTORE BEFORE REUSING THIS WORKTREE — NEVER COMMIT THE ASSET DELETION

ONLY the inactive exact canonical working-copy terrain payload was temporarily retired for storage, under root approval. This is not a historical-model edit. Restore this file before any reuse/build/publication of this old worktree:

/workspace/worktrees/t2373-lighthouse/chicago/4d/assets/gltf/terrain__e1834_harbor_cut.glb

Old HEAD: e5b9a0fbb145545c95079ccc7e7a3e08ffa050a5. Existing index/flags were preserved; one unstaged deletion is intentional. Ten pre-existing WIP files are immutable in checkpoint732 publication0946b2f11851e7ee0a54cdcd61caa8c0e696049c. Do not stage or commit the terrain deletion.

Exact local native blob restore command (stream to ONE owned sibling temporary file, verify, chmod/fsync, then atomically restore ONLY the missing path; no checkout/index update):
GIT_NO_LAZY_FETCH=1 GIT_OPTIONAL_LOCKS=0 git --no-optional-locks -c protocol.allow=never --git-dir=/workspace/chicago/.git cat-file blob 9e56099d72a013ae8a6cac22deab5aabb92d84ef

Immutable public fallback (same blob in current primary3e):
https://raw.githubusercontent.com/kevinrhaas/chicago/3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa/chicago/4d/assets/gltf/terrain__e1834_harbor_cut.glb

Required bytes:30621836; SHA256:6e0ac8f7a527e6ab1a3e4ad0920294b75d0a191c08523200b78603be82b22611; Git blob SHA1:9e56099d72a013ae8a6cac22deab5aabb92d84ef; full Unix mode0600 (Git100644). Originalmtime_ns:1792756793417933361. Shared local object is already materialized; no geometry regeneration or source hardlink coupling. Preserve all existing WIP/configs/ticket link. Confirm caller storage/CPU lease before restoration. Full audit and restore mapping: /workspace/t2373-terrain-master-retirement-proposal-20261030/PROPOSAL.md and /workspace/t2373-terrain-canonical-copy-retirement-20261030/RESTORE-MAP.json.


## ADDITIONAL RETIRED COPY: NATURAL TERRAIN — RESTORE BOTH BEFORE REUSE

The preceding harbor-cut retirement entry is preserved byte-for-byte. Under separate root authorization, ONLY this second inactive canonical copy was temporarily retired for storage:
/workspace/worktrees/t2373-lighthouse/chicago/4d/assets/gltf/terrain__e1830_natural.glb

NEVER COMMIT EITHER ASSET DELETION. Restore BOTH retired terrain paths before reusing/building/publishing this old worktree. Existing10WIP, oldindex/HEAD/flags and privateconfigs/ticketlink remain intact. This does not change the primary/historical model.

Exact native local Git restore stream (to ONE sibling temporary file, verify size/hash/mode, fsync, then atomically restore ONLY the missing natural path; no checkout/index writes):
GIT_NO_LAZY_FETCH=1 GIT_OPTIONAL_LOCKS=0 git --no-optional-locks -c protocol.allow=never --git-dir=/workspace/chicago/.git cat-file blob 7f2e52f2872a09f10dad03e44ab411117d3a9ad3

Independent immutable public89ad restore URL:
https://raw.githubusercontent.com/kevinrhaas/chicago/89ad07fd2b43679c028715dbf30830b7dacf2a54/chicago/4d/assets/gltf/terrain__e1830_natural.glb

Required bytes:30004072; SHA256:7355878e618d7ed37dcbd65fab5c99fe64c9599b6c83ba2066e683d1465e48cf; Git blob:7f2e52f2872a09f10dad03e44ab411117d3a9ad3; fullUnix0600(Git100644); originalmtime_ns:1792756793281930667. No geometry regeneration, rawmodel copy now, source hardlink or skipworktree flags. Restore metadata: /workspace/t2373-natural-terrain-canonical-copy-retirement-20261030/RESTORE-MAP.json.
