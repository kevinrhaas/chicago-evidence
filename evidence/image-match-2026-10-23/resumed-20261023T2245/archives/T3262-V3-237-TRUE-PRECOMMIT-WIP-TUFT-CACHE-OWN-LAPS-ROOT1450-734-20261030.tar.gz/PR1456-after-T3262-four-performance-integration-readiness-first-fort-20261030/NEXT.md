PR1456 after normalT3262merge: bounded four-performance-path readiness only

All4original3746performance files are byte-exact standalone3c. Actual commonbase of3746with3c and89ad isbc7. Native textmerge previews and hashes are inFOUR-PATH-COMPARISON; these do not create a commit/index/ref/tree. Rootshould adopt actualmergedcanonicalT3262performancebytes, not replay3746rail/lifecycle over newerlazy tie/tuft implementations. CandidateV3is only a pinned sourcepreview until actualsupportsourcegate/phone/CI/normalmerge/fold.

Futurebase/dev/T3262squash/foldtree areunknown. Re-read actualheads/commonbase and fourfile hashes; if unrelated performance source edits arrive, reclassify conflicts rather than whole-file replay. Preserve original61checked/publicationauthority and fourtarget/librarywork. Global assets/Lib/source-use owners must reconcile actualnewdev metadata; old61rows are not a rollbackrecipe. The5librarysource bindings and dated3746targetaudit stay explicit; futureentrywise joins/currentnativepublication/official400/requiredCI remain tobequalified.

This packet performs no import, source/index/ref/API/browser/nativeowner/runtime write or actualgenuinemerge. Only readonlyGitblob/tree lookup and gitmerge-file -p on disposableowned external textinputs were used. No primary source or fullscene/runtime fixture copied.
