"""Read-only ONE canonical terrain master-copy audit. No delete, staging, flags or raw copies."""
from pathlib import Path
import datetime,hashlib,json,os,stat,struct,subprocess,time,urllib.request
P=Path(__file__).resolve().parent;W=Path('/workspace/worktrees/t2373-lighthouse');C=Path('/workspace/chicago/.git')
REL='chicago/4d/assets/gltf/terrain__e1830_natural.glb';F=W/REL
os.sched_setaffinity(0,{2});os.nice(19)
E=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1')
BASE=['git','--no-optional-locks','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','protocol.allow=never','-C',str(W)]
SHA=lambda b:hashlib.sha256(b).hexdigest();PF=lambda p:SHA(p.read_bytes())
def git(*a):return subprocess.check_output(BASE+list(a),env=E)
def save(n,x):(P/n).write_text(json.dumps(x,indent=2)+'\n')
G=C/'worktrees/t2373-lighthouse';index_before=PF(G/'index');head_file_before=PF(G/'HEAD');head=git('rev-parse','HEAD').decode().strip()
index_line=git('ls-files','--stage','--',REL).decode().strip();a,b=index_line.split('\t');mode,oid,stage=a.split();assert b==REL and stage=='0'and mode=='100644'
tree=git('ls-tree',head,'--',REL).decode().strip();assert tree==f'{mode} blob {oid}\t{REL}'
index_flags=git('ls-files','-v','--',REL).decode().strip();debug=git('ls-files','--stage','--debug','--',REL).decode();assert index_flags=='H '+REL and 'flags: 0'in debug
s=F.lstat();assert stat.S_ISREG(s.st_mode)and s.st_nlink==1 and not F.is_symlink()
actual_mode=stat.S_IMODE(s.st_mode);normalized_mode='100755'if actual_mode&0o111 else'100644';assert normalized_mode==mode
assert git('cat-file','-t',oid).strip()==b'blob';size=int(git('cat-file','-s',oid));assert size==s.st_size==30004072
def stream_hash(stream,size):
 h=hashlib.sha256();g=hashlib.sha1(b'blob '+str(size).encode()+b'\0');n=0
 while True:
  data=stream.read(65536)
  if not data:break
  h.update(data);g.update(data);n+=len(data)
 return {'bytes':n,'sha256':h.hexdigest(),'Git_blob_sha1':g.hexdigest()}
with F.open('rb')as raw:disk=stream_hash(raw,size)
t=time.monotonic();proc=subprocess.Popen(BASE+['cat-file','blob',oid],env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
blob=stream_hash(proc.stdout,size);err=proc.stderr.read();assert proc.wait()==0,err.decode();assert blob==disk and disk['Git_blob_sha1']==oid
# Locate the materialized object in this exact shared store using only idx
# metadata. Never verify/decompress unrelated packs or fetch missing objects.
assert not(C/'objects/info/alternates').exists()and not E.get('GIT_OBJECT_DIRECTORY')and not E.get('GIT_ALTERNATE_OBJECT_DIRECTORIES')
object_locations=[];loose=C/'objects'/oid[:2]/oid[2:]
if loose.is_file():object_locations.append({'kind':'loose','path':str(loose),'stored_bytes':loose.stat().st_size})
target=bytes.fromhex(oid)
for idx in sorted((C/'objects/pack').glob('*.idx')):
 with idx.open('rb')as fp:
  first=fp.read(8)
  if first[:4]==b'\xfftOc':
   version=struct.unpack('>I',first[4:])[0];assert version==2;fan=struct.unpack('>256I',fp.read(1024));offset=1032;stride=20;extra=0
  else:
   fp.seek(0);fan=struct.unpack('>256I',fp.read(1024));offset=1024;stride=24;extra=4
  lo=fan[target[0]-1]if target[0]else 0;hi=fan[target[0]];match=None
  while lo<hi:
   mid=(lo+hi)//2;fp.seek(offset+stride*mid+extra);value=fp.read(20)
   if value<target:lo=mid+1
   elif value>target:hi=mid
   else:match=mid;break
  if match is not None:
   pack=idx.with_suffix('.pack');assert pack.is_file();object_locations.append({'kind':'pack','idx':str(idx),'idx_bytes':idx.stat().st_size,'pack':str(pack),'pack_bytes':pack.stat().st_size,'oid_table_index':match})
assert object_locations,'Raw cat-file returned bytes but no shared-local object location was found'
primary_head=subprocess.check_output(['git','--no-optional-locks','-c','protocol.allow=never','--git-dir',str(C),'rev-parse','HEAD'],env=E).decode().strip()
primary_tree=git('ls-tree',primary_head,'--',REL).decode().strip();assert primary_tree==tree
primary_path=Path('/workspace/chicago')/REL;ps=primary_path.lstat();assert not primary_path.is_symlink()and stat.S_ISREG(ps.st_mode)
assert(ps.st_dev,ps.st_ino)!=(s.st_dev,s.st_ino),'Primary is the same inode: not an independent disposable worktree copy'
owner=json.loads((W/'chicago/4d/assets/manifest.json').read_text())['assets'].get(F.name)
web_owner=json.loads((W/'chicago/4d/assets/manifest.web.json').read_text())['masters'].get(F.name);assert web_owner==disk['sha256']
# Enumerate real symlinks in project/proposal trees, without following links or
# reading private caches/configs/dependency contents. Check exact file targets
# and directory aliases through which this exact file can be reached.
skip_names={'.git','node_modules','.claude','.codex','.agents','.aws','.cache','Cache','Caches','Default','GPUCache','ShaderCache','Code Cache','Crashpad','BrowserMetrics'}
skip_roots={Path('/workspace/shared'),Path('/workspace/b2378p30'),Path('/workspace/b2378l30'),Path('/workspace/b2378a30')}
consumers=[];scanned_dirs=0;scanned_links=0;excluded=0;errors=[];stack=[Path('/workspace')]
while stack:
 d=stack.pop();scanned_dirs+=1
 try:entries=list(os.scandir(d))
 except OSError as e:errors.append({'path':str(d),'errno':e.errno});continue
 for e in entries:
  q=Path(e.path)
  if e.is_symlink():
   scanned_links+=1
   try:
    resolved=Path(os.path.realpath(q));kind='exact_file'if resolved==F else'ancestor_directory_alias'if F.is_relative_to(resolved)and resolved.is_dir()else None
    if kind:consumers.append({'path':str(q),'target':os.readlink(q),'resolved':str(resolved),'kind':kind,'effective_file_path':str(q/F.relative_to(resolved))if kind!='exact_file'else str(q)})
   except OSError as ex:errors.append({'path':str(q),'errno':ex.errno})
  elif e.is_dir(follow_symlinks=False):
   if q in skip_roots or e.name in skip_names or any(v in e.name.lower()for v in ['playwright_chromiumdev_profile','browser-profile','chromium-profile','private-profile']):excluded+=1
   else:stack.append(q)
consumer_roots={str(Path(r['path']).parents[len(Path(r['path']).parts)-3])for r in consumers if len(Path(r['path']).parts)>2}
# Explicit affected project/proposal roots; do not store unrelated cmdlines.
roots={str(W)}
for r in consumers:
 parts=Path(r['path']).parts
 if len(parts)>2:roots.add(str(Path(*parts[:3])))
live=[];inaccessible=[];processes=0
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 pid=int(p.name);processes+=1
 for kind in ['cwd','exe']:
  try:target_path=os.readlink(p/kind)
  except OSError:continue
  if any(target_path==root or target_path.startswith(root+'/')for root in roots):live.append({'pid':pid,'kind':kind,'path':target_path})
 try:
  text=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  if any(root in text for root in roots):live.append({'pid':pid,'kind':'affected worktree/proposal argv reference'})
 except OSError:pass
 try:fds=list((p/'fd').iterdir())
 except OSError:inaccessible.append(pid);continue
 for fd in fds:
  try:target_path=os.readlink(fd)
  except OSError:continue
  if target_path==str(F)or any(target_path==root or target_path.startswith(root+'/')for root in roots):live.append({'pid':pid,'kind':'affected open fd','path':target_path})
 try:
  for line in(p/'maps').read_text(errors='replace').splitlines():
   if str(F)in line or any(root in line for root in roots):live.append({'pid':pid,'kind':'affected mapped file'})
 except OSError:pass
# Preserve exact ten WIP payloads and oldindex/HEAD; do not duplicate their bytes.
wip_manifest=json.loads(Path('/workspace/t2373-single-glb-funding-readonly-20261030/WIP-SOURCE-MANIFEST.json').read_text());assert len(wip_manifest['files'])==10
for r in wip_manifest['files']:
 q=Path(r['path']);assert q.stat().st_size==r['bytes']and stat.S_IMODE(q.stat().st_mode)==r['mode']and PF(q)==r['sha256']
assert PF(G/'index')==index_before and PF(G/'HEAD')==head_file_before and git('rev-parse','HEAD').decode().strip()==head
stable_fields=['st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns']
after_stat=F.lstat();assert all(getattr(after_stat,k)==getattr(s,k)for k in stable_fields),'Selected inode/content/mode metadata changed during audit'
result={'status':'READONLY_CANONICAL_SINGLE_TERRAIN_COPY_EXACT_BLOB_PROPOSAL_'+('BLOCKED_ACTIVE_CONSUMER'if live else'NO_VISIBLE_LIVE_CONSUMER_FOUND'),
 'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'worktree':str(W),'path':str(F),'worktree_relative_path':REL,'old_HEAD':head,'old_index_entry':index_line,'old_HEAD_tree_entry':tree,'old_index_flags':index_flags,'old_index_debug':debug,
 'file':dict(disk,filesystem_mode=oct(actual_mode),normalized_Git_mode=normalized_mode,Git_mode=mode,nlink=s.st_nlink,allocated_B=s.st_blocks*512,dev=s.st_dev,ino=s.st_ino,mtime_ns=s.st_mtime_ns),'mode_note':'Git100644 exactly matches HEAD/index and regular non-executable file. Git does not encode0600 vs0644; preserve current full Unix0600 explicitly on restore.',
 'canonical_local_blob':dict(blob,type='blob',shared_common_gitdir=str(C),locations=object_locations,raw_hash_stream_seconds=time.monotonic()-t,lazy_fetch_disabled=True,all_protocols_disabled=True,alternates_absent=True,raw_model_copies_created=0),
 'primary_comparison':{'HEAD':primary_head,'same_tree_mode_blob':primary_tree==tree,'tree_entry':primary_tree,'path':str(primary_path),'independent_inode':True,'primary_input_path_unmodified':True,'immutable_raw_url':'https://raw.githubusercontent.com/kevinrhaas/chicago/'+primary_head+'/'+REL,'public_remote_metadata_and_HEAD_verification':'pending separate read-only request; no second30MBdownload needed'},
 'native_owner_record':owner,'native_WEB_owner_MASTER_sha256':web_owner,'restore_does_not_require_geometry_regeneration':True,
 'symlink_consumer_scan':{'actual_consumers':consumers,'scanned_project_directories':scanned_dirs,'scanned_symlinks':scanned_links,'excluded_private_dependency_SDK_cache_roots_or_dirs':excluded,'scan_errors':errors,'scope':'All readable physical/workspace project/proposal trees, no symlink traversal. Private configs/dependencies/browsercaches and sharedSDKs excluded; exact file and ancestor-directory aliases recorded.'},
 'active_consumer_scan':{'visible_processes':processes,'affected_roots':sorted(roots),'live_references':live,'inaccessible_unrelated_fd_sets':inaccessible,'scope':'No unrelated commandlines stored. All visible cwd/argv/FD/maps checked for selected worktree and actual consumer roots; recheck immediately before any approved unlink.'},
 'ten_WIP_authority_files_exact_preserved':True,'WIP_source_bytes':wip_manifest['source_bytes'],'worktree_index_sha256_unchanged':index_before,'worktree_HEAD_file_sha256_unchanged':head_file_before,
 'proposal_only_no_deletion_or_primary_Git_mutation':True,'old_worktree_restore_required_before_reuse':True,'no_historical_model_change':True,'restore_blob_oid':oid,'restore_full_mode':oct(actual_mode)}
save('AUDIT.json',result);print(json.dumps({'status':result['status'],'file':result['file'],'local_object_locations':object_locations,'primary_HEAD':primary_head,'symlink_consumer_count':len(consumers),'live_consumer_reference_count':len(live),'metadata_report_B':(P/'AUDIT.json').stat().st_size},indent=2))
