# V3 genuine current-dev merge plus reviewed memory revision — prepared, unrun

This is a minimal revision of the prior genuine-merge FF helper. It is fixed to old/source head `89ad07fd2b43679c028715dbf30830b7dacf2a54`, canonical incoming `2378484c31b91a1b8d28fd8430d2b4d1a783bdaa`, existing T-3262 branch and PR1486. The new native head/tree remain unknown required arguments. Parents must be exactly `[89ad,237]`.

Canonical bcf→237 must be exactly13non-own paths. The new first-parent diff must be exactly those13paths plus the reviewed four own railway/lifecycle/STATUS/ROADMAP revisions, at most64paths. The actual PR diff versus237 must be exactly our seven paths. Spatial-batch.js, check_confidence_lane.mjs and changelog.d/T-3262.json stay byte-identical to89ad; every non-own path/mode/blob/deletion stays canonical237. All working source hashes are checked against the actual committed tree and full-source gate.

The new integration gate must be `ACTUAL_T3262_V3_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_PASS`, revisionV3_CURRENTDEV_237, source head89ad and merge_parent/pr_base237. It binds the exact actual merged tree, staged hashes/null deletions, all7source hashes, own4_postimages as a four-entry SHA256 map, root-reviewed manifest SHA, branch/ticket/config and every source/incoming/docs/protected-three/reaper guard plus actual CHECKPASS footer. Secondfort confirmed this schema. No old failed phone or old passing source tree can substitute.

The union of already-remote parent blobs prevents uploading Field payloads again. Any unknown blob must belong to the reviewed own four paths; their source and all seven postimages remain below the hard4MiB cap. Parent signed payloads are referenced by exact SHA, never recreated. The new native merge preserves its real author/committer/timestamps/message/tree/parent order and refuses any SHA rewrite.

Every GET cache-busts with `codex_read=time_ns`. The helper requires the fresh existing ref and open PR1486 to read89ad, then uses only normal `force:false` FF. It never creates a branch or PR. Immutable raw readback verifies all seven own files; bounded immutable tree lookups verify canonical incoming modes/blobs/deletions without fetching Field payloads or constructing another full artifact inventory. PR head readback uses only short fresh read-only polling. Local HEAD/index/config/all refs/status stay exact.

## Later invocation after actual merge, review, gate and native checkpoint

```bash
source /workspace/shared/resume-chicago-env.sh
PYTHONDONTWRITEBYTECODE=1 python /workspace/T3262-v3-237-merge-publication-prep-bridge-20261030/publish_merge_v3.py \
  --expected-old 89ad07fd2b43679c028715dbf30830b7dacf2a54 \
  --incoming 2378484c31b91a1b8d28fd8430d2b4d1a783bdaa \
  --head ACTUAL_NEW_NATIVE_V3_MERGE_HEAD --qualified-tree ACTUAL_REVIEWED_V3_TREE \
  --gate-proof ACTUAL_V3_RUN/GATE-RESULT.json \
  --output /workspace/ACTUAL_V3_READONLY_PUBLICATION_PLAN
```

Default execution only plans. Root reviews the actual plan and uses a new output directory with `--publish`. If a later readback fails after FF, retain every receipt and verify that published head; never reset, recreate or force the branch. Current dev is read freshly before/after and recorded; concurrent later movement needs its own honest qualification.

No dispatch, CI rerun, PR body/title edit, ticket state change, dev/main merge or promotion is included. The new native committed head still needs its own official phone result and current required CI before merging. This helper was only syntax-parsed here; source/ref/API writes and controller execution have not occurred.
