from pathlib import Path
import json
R=Path('/workspace/chicago');O=Path(__file__).parent;test=(R/'chicago/4d/tools/test_rail_geometry_lifecycle.mjs').read_text();rail=(O/'postimages/chicago/4d/renderers/web/js/railway.js').read_text();eager=(O/'EAGER-TUFT-ORACLE.txt').read_text()
assert test.count('return {packTieCache,installTieCache};')==1;test=test.replace('return {packTieCache,installTieCache};','return {packTieCache,installTieCache,packTuftCache,installTuftCache};',1)
assert test.count('function make(){')==1;test=test.replace('function make(){','function make(dens={full:4,balanced:2,light:1}){',1);test=test.replace("Function('installTieCache','THREE'","Function('dens','installTuftCache','installTieCache','THREE'",1);test=test.replace(')(tieFunctions.installTieCache,THREE,group',')(dens,tieFunctions.installTuftCache,tieFunctions.installTieCache,THREE,group',1)
needle="const dispose=proposed.slice(proposed.indexOf('  out.dispose = () => {'),proposed.indexOf('  group.userData.census = out.census;'));";assert test.count(needle)==1;test=test.replace(needle,needle+"\nconst detailSource=proposed.slice(proposed.indexOf('  const applyDetail = () => {'),proposed.indexOf('  /** T-3247: a piece shown or hidden'));",1)
assert test.count('${headers}${update}${dispose}')==1;test=test.replace('${headers}${update}${dispose}','${detailSource}${headers}${update}${dispose}',1)
addition='''
// T-3262: final Float32 tuft payloads, density and first reach, with the former
// native eager producer retained as the byte oracle. Existing tie checks remain.
const eagerTuftSource=EAGER_LITERAL;
const lazyTuftSource=base.slice(base.indexOf('    if (tuftGeo && z.tufts.length) {'),base.indexOf('    z.tufts = null;',base.indexOf('    if (tuftGeo && z.tufts.length) {')));
const tuftGeo=Function('THREE',base.slice(base.indexOf('function tuftGeometry('),base.indexOf('function wetTint('))+';return tuftGeometry;')(THREE)(.5);
const tuftMat=new THREE.MeshStandardMaterial(),tuftLib={sheet:{height_m:.55}};
const tuftRecords=[
 {e:2.1,n:-50,y:1.3,yaw:.2,scale:.56,keep:.05,tone:1.15},
 {e:-0,n:-90,y:-0,yaw:1.5,scale:1.29,keep:.24,tone:1.08},
 {e:7,n:-70,y:.04,yaw:2.9,scale:.87,keep:.6,tone:.8},
];
function tuftPair(source,records=tuftRecords){
 const z={tufts:records.map(r=>({...r}))},group=new THREE.Group(),marker=new THREE.Object3D();
 Function('THREE','packTuftCache','z','group','zi','tuftGeo','tuftMat','tuftLib','wx','wz',`const m4=new THREE.Matrix4(),q=new THREE.Quaternion(),up=new THREE.Vector3(0,1,0),v3=new THREE.Vector3(),s3=new THREE.Vector3(),c=new THREE.Color();${source}`)(THREE,tieFunctions.packTuftCache,z,group,0,tuftGeo,tuftMat,tuftLib,e=>e,n=>-n);
 const after=new THREE.Object3D();assert.equal(after.id-marker.id,2,'Original tuft Object3D id slot retained');checks++;return{z,group};
}
function sameTuft(eager,lazy){
 const a=eager.z.tuftMesh,b=lazy.z.tuftMesh;
 assert.equal(b.count,a.count);assert.equal(b.name,a.name);assert.equal(b.material,a.material);assert.equal(b.geometry,a.geometry);assert.equal(b.castShadow,a.castShadow);assert.equal(b.receiveShadow,a.receiveShadow);
 assert.deepEqual(byteView(b.instanceMatrix.array),byteView(a.instanceMatrix.array));assert.deepEqual(byteView(b.instanceColor.array),byteView(a.instanceColor.array));assert.deepEqual(b.boundingSphere.center.toArray(),a.boundingSphere.center.toArray());assert.equal(b.boundingSphere.radius,a.boundingSphere.radius);checks+=10;
 if(a.boundingBox===null){assert.equal(b.boundingBox,null);checks++;}else{assert.deepEqual(b.boundingBox.min.toArray(),a.boundingBox.min.toArray());assert.deepEqual(b.boundingBox.max.toArray(),a.boundingBox.max.toArray());checks+=2;}
}
{
 const eager=tuftPair(eagerTuftSource),lazy=tuftPair(lazyTuftSource);assert.equal(lazy.z.tuftMesh.count,0);assert.equal(lazy.z.tuftMesh.instanceMatrix.array.byteLength,0);assert.equal(lazy.z.tuftMesh.instanceColor.array.byteLength,0);assert.equal(lazy.z.tuftMesh.boundingSphere,null);assert.equal(lazy.z.tuftCache.stride,8);assert.equal(lazy.z.tuftCache.values.byteLength,tuftRecords.length*32);assert.deepEqual(lazy.z.tuftKeeps,eager.z.tuftKeeps);checks+=7;
 // Empty-shell boxes refresh using the actual selected prefix; sphere retains
 // the original complete built payload, as before applyDetail trimmed count.
 lazy.z.tuftMesh.computeBoundingBox();assert.equal(lazy.z.tuftMesh.boundingBox.isEmpty(),true);checks++;
 eager.z.tuftMesh.count=2;eager.z.tuftMesh.computeBoundingBox();tieFunctions.installTuftCache(lazy.z.tuftMesh,lazy.z.tuftCache,2);sameTuft(eager,lazy);
 const full=new Float32Array(tuftRecords.length*19);for(let i=0;i<tuftRecords.length;i++){full.set(eager.z.tuftMesh.instanceMatrix.array.subarray(i*16,i*16+16),i*19);full.set(eager.z.tuftMesh.instanceColor.array.subarray(i*3,i*3+3),i*19+16);}
 for(const[mutate,stride]of [[a=>{a[19+10]=.4;},11],[a=>{a[19+17]=1.07;},11],[a=>{a[19+2]=0;a[19+8]=0;},11],[a=>{a[19+1]=.125;},19],[a=>{a[19+1]=-0;},19]]){
  const bad=full.slice();mutate(bad);const cache=tieFunctions.packTuftCache(bad);assert.equal(cache.stride,stride);assert.equal(cache.values.byteLength,tuftRecords.length*stride*4);checks+=2;const pair=tuftPair(lazyTuftSource);tieFunctions.installTuftCache(pair.z.tuftMesh,cache,tuftRecords.length);
  for(let i=0;i<tuftRecords.length;i++){assert.deepEqual(byteView(pair.z.tuftMesh.instanceMatrix.array.subarray(i*16,i*16+16)),byteView(bad.subarray(i*19,i*19+16)));assert.deepEqual(byteView(pair.z.tuftMesh.instanceColor.array.subarray(i*3,i*3+3)),byteView(bad.subarray(i*19+16,i*19+19)));checks+=2;}
 }
}
function withTufts(dens={full:4,balanced:2,light:1}){const pair=tuftPair(lazyTuftSource),f=make(dens);f.group.add(...pair.group.children.slice());Object.assign(f.zone,{tuftMesh:pair.z.tuftMesh,tuftKeeps:pair.z.tuftKeeps,tuftCache:pair.z.tuftCache});return f;}
{
 const eager=tuftPair(eagerTuftSource),f=withTufts();f.setDetail('light');assert.equal(f.zone.tuftWanted,2);assert.equal(f.census.tufts,2);assert.equal(f.zone.tuftMesh.count,0);checks+=3;f.update(eye(-900));assert.ok(f.zone.tuftCache);assert.equal(f.zone.tuftMesh.visible,false);checks+=2;
 f.zone.tuftMesh.computeBoundingBox();f.update(eye(-160));assert.equal(f.zone.tuftCache,null);assert.equal(f.zone.tuftMesh.visible,true);eager.z.tuftMesh.count=2;eager.z.tuftMesh.computeBoundingBox();sameTuft(eager,{z:f.zone});checks+=2;
 const matrix=f.zone.tuftMesh.instanceMatrix,color=f.zone.tuftMesh.instanceColor;
 for(const level of ['full','balanced','light'])for(const n of [-50,-209.999,-210,-279.999,-280,-349.999,-350,-900,-160]){
  f.setDetail(level);f.update(eye(n));const d=n<-110?-110-n:n>0?n:0,wanted=tuftRecords.filter(t=>t.keep<({full:4,balanced:2,light:1}[level]/4)).length;assert.equal(f.zone.tuftMesh.count,wanted);assert.equal(f.census.tufts,wanted);assert.equal(f.zone.tuftMesh.visible,d<reach[level].tufts&&wanted>0);assert.equal(f.zone.tuftMesh.instanceMatrix,matrix);assert.equal(f.zone.tuftMesh.instanceColor,color);assert.equal(f.zone.tuftCache,null);checks+=6;
 }
 let disposed=0;f.zone.tuftMesh.addEventListener('dispose',()=>disposed++);f.dispose();assert.equal(disposed,1);assert.equal(f.zone.tuftCache,null);checks+=2;
}
for(const level of ['full','balanced','light']){
 const f=withTufts();f.setDetail(level);f.update(eye(-900));assert.equal(f.zone.tuftMesh.count,0);assert.ok(f.zone.tuftCache);checks+=2;f.update(eye(-110-reach[level].tufts+.001));assert.equal(f.zone.tuftCache,null);assert.equal(f.zone.tuftMesh.visible,true);checks+=2;f.dispose();
}
{
 const f=withTufts({full:4,balanced:2,light:0});f.setDetail('light');f.update(eye(-50));assert.equal(f.zone.tuftWanted,0);assert.equal(f.zone.tuftMesh.count,0);assert.ok(f.zone.tuftCache);assert.equal(f.zone.tuftMesh.visible,false);assert.equal(f.census.tufts,0);checks+=5;
 f.setDetail('full');assert.equal(f.zone.tuftWanted,3);assert.equal(f.zone.tuftMesh.count,0);checks+=2;f.update(eye(-50));assert.equal(f.zone.tuftCache,null);assert.equal(f.zone.tuftMesh.count,3);checks+=2;const matrix=f.zone.tuftMesh.instanceMatrix;f.setDetail('light');f.update(eye(-50));assert.equal(f.zone.tuftMesh.count,0);assert.equal(f.zone.tuftMesh.visible,false);f.setDetail('full');f.update(eye(-50));assert.equal(f.zone.tuftMesh.count,3);assert.equal(f.zone.tuftMesh.instanceMatrix,matrix);checks+=4;f.dispose();
 const pending=withTufts();let disposed=0;pending.zone.tuftMesh.addEventListener('dispose',()=>disposed++);pending.dispose();assert.equal(disposed,1);assert.equal(pending.zone.tuftCache,null);assert.equal(pending.zone.tuftMesh.count,0);checks+=3;
}
{
 const clear='  // Only grade is read by the returned path; the sampling scratch is finished.\\n  raw.length = 0;\\n';const oldTrack=Function(trackCode.replace(clear,'' )+';return trackPath;')();
 for(const line of [[[0,0],[1,-90],[-4,-220]],[[3,0],[4,-100],[2,-230]]]){
  const terrain={surfaceHeight:(e,n)=>Math.sin(n/70)*.3+Math.cos(e/3)*.2},a=trackPath(line,terrain),b=oldTrack(line,terrain);assert.equal(a.length,b.length);checks++;for(const s of [-3,0,.1,5,a.length*.5,a.length,a.length+4]){assert.deepEqual(a.at(s),b.at(s));checks++;}
 }
 const wrongCode=trackCode.replace('  const grade = raw.map','  raw.length = 0;\\n  const grade = raw.map'),wrong=Function(wrongCode+';return trackPath;')();assert.throws(()=>assert.deepEqual(wrong([[0,0],[0,-20]],{surfaceHeight:()=>1}).at(5),trackPath([[0,0],[0,-20]],{surfaceHeight:()=>1}).at(5)));checks++;
}
console.log(JSON.stringify({tuftCacheUniformBytesPerInstance:32,uprightFallbackBytes:44,fullFallbackBytes:76,originalHDRFloat32ColorsAndPoseBytesExact:true,emptySphereAndCachedBoxHandled:true,wantedDensityCountBeforeFirstReach:true,firstEntryReentryAllTiersAndZeroDensityPromotion:true,unreachedAndReachedDisposal:true,trackSamplingScratchClearedAfterGradeOnly:true,trackPositionGradeTangentParity:true,noGpuMemoryPixelOr400GateClaim:true}));
'''.replace('EAGER_LITERAL',json.dumps(eager))
# Python literal needs the escaped newline inside the generated JavaScript source literal.
needle='console.log(`PASS ${checks} bounded actual-producer geometry/lifecycle/upload-mark/visibility checks.';assert test.count(needle)==1;test=test.replace(needle,addition+'\n'+needle,1);(O/'postimages/chicago/4d/tools/test_rail_geometry_lifecycle.mjs').write_text(test)
root_expr="const root=fileURLToPath(new URL('../',import.meta.url)).replace(/\\/$/,''),base=await fs.readFile(`${root}/renderers/web/js/railway.js`,'utf8'),proposed=base;";assert test.count(root_expr)==1;runner=test.replace(root_expr,'const root='+json.dumps('/workspace/chicago/chicago/4d')+',base=await fs.readFile('+json.dumps(str(O/'postimages/chicago/4d/renderers/web/js/railway.js'))+",'utf8'),proposed=base;",1);(O/'external-test-runner.mjs').write_text(runner)
