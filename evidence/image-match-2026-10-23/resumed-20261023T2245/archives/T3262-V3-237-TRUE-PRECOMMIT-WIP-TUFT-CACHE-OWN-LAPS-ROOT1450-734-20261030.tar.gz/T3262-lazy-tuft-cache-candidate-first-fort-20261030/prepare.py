from pathlib import Path
import json,hashlib,subprocess
R=Path('/workspace/chicago');O=Path(__file__).parent;rail='chicago/4d/renderers/web/js/railway.js';test='chicago/4d/tools/test_rail_geometry_lifecycle.mjs';base=(R/rail).read_text();sha=lambda b:hashlib.sha256(b).hexdigest();helpers='''// Uniform crossed-card transforms can store six matrix lanes and R/B only.
// Relations are tested AFTER Float32 conversion; sign-zero is part of equality.
function packTuftCache(final) {
  const upright = packTieCache(final);
  if (upright.stride !== 11) return upright;
  for (let i = 0; i < upright.count; i += 1) {
    const o = i * 19;
    if (!Object.is(final[o], final[o + 10])
        || !Object.is(final[o + 8], -final[o + 2])
        || !Object.is(final[o + 16], final[o + 17])) return upright;
  }
  const values = new Float32Array(upright.count * 8);
  for (let i = 0; i < upright.count; i += 1) {
    const o = i * 19;
    [0, 2, 5, 12, 13, 14, 16, 18].forEach((lane, k) => { values[i * 8 + k] = final[o + lane]; });
  }
  return { count: upright.count, stride: 8, values };
}

function installTuftCache(mesh, cache, wantedCount) {
  let upright = cache;
  if (cache.stride === 8) {
    const values = new Float32Array(cache.count * 11);
    for (let i = 0; i < cache.count; i += 1) {
      const o = i * 8;
      values.set([cache.values[o], cache.values[o + 1], cache.values[o + 2],
        -cache.values[o + 1], cache.values[o], cache.values[o + 3], cache.values[o + 4],
        cache.values[o + 5], cache.values[o + 6], cache.values[o + 6], cache.values[o + 7]], i * 11);
    }
    upright = { count: cache.count, stride: 11, values };
  }
  // The old sphere covered the complete built payload before density trimming.
  installTieCache(mesh, mesh, upright);
  mesh.count = wantedCount;
  if (mesh.boundingBox !== null) mesh.computeBoundingBox();
}

''';assert base.count('function railMesh(')==1;candidate=base.replace('function railMesh(',helpers+'function railMesh(',1)
a=base.index('    if (tuftGeo && z.tufts.length) {');b=base.index('    z.tufts = null;',a);eager=base[a:b];new='''    if (tuftGeo && z.tufts.length) {
      z.tufts.sort((a, b) => a.keep - b.keep);
      const mesh = new THREE.InstancedMesh(tuftGeo, tuftMat, 0);
      mesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(0), 3);
      const final = new Float32Array(z.tufts.length * 19);
      z.tufts.forEach((t, k) => {
        q.setFromAxisAngle(up, t.yaw);
        const h = tuftLib.sheet.height_m * t.scale;
        m4.compose(v3.set(wx(t.e), t.y, wz(t.n)), q, s3.set(h, h, h));
        m4.toArray(final, k * 19);
        c.setRGB(t.tone, t.tone, t.tone * 0.92);
        final.set([c.r, c.g, c.b], k * 19 + 16);
      });
      z.tuftCache = packTuftCache(final);
      mesh.name = `railway-tufts-z${zi}`;
      mesh.castShadow = false; mesh.receiveShadow = true;
      z.tuftKeeps = z.tufts.map((t) => t.keep);
      z.tuftMesh = mesh;
      group.add(mesh);
    }
''';assert candidate.count(eager)==1;candidate=candidate.replace(eager,new,1)
old='      z.tuftMesh.count = n;\n      out.census.tufts += n;';new='''      z.tuftWanted = n;
      if (!z.tuftCache) z.tuftMesh.count = n;
      out.census.tufts += n;''';assert candidate.count(old)==1;candidate=candidate.replace(old,new,1)
old='      if (z.tuftMesh) z.tuftMesh.visible = d < r.tufts && z.tuftMesh.count > 0;';new='''      if (z.tuftMesh) {
        const wanted = z.tuftWanted ?? z.tuftMesh.count;
        const visible = d < r.tufts && wanted > 0;
        if (visible && z.tuftCache) {
          installTuftCache(z.tuftMesh, z.tuftCache, wanted);
          z.tuftCache = null;
        }
        z.tuftMesh.visible = visible;
      }''';assert candidate.count(old)==1;candidate=candidate.replace(old,new,1)
old='      z.tieCache = null;\n      z.tiesNear?.dispose();';assert candidate.count(old)==1;candidate=candidate.replace(old,'      z.tieCache = null;\n      z.tuftCache = null;\n      z.tiesNear?.dispose();',1)
old='''    return sum / c;
  });
  const gradeAt = (s) => {''';new='''    return sum / c;
  });
  // Only grade is read by the returned path; the sampling scratch is finished.
  raw.length = 0;
  const gradeAt = (s) => {''';assert candidate.count(old)==1;candidate=candidate.replace(old,new,1)
(O/'postimages'/rail).write_text(candidate);(O/'EAGER-TUFT-ORACLE.txt').write_text(eager);(O/'BASELINES.json').write_text(json.dumps({'head':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip(),'source_preimages':{rail:sha(base.encode()),test:sha((R/test).read_bytes())},'eager_tuft_block_sha256':sha(eager.encode())},indent=2)+'\n')
