from pathlib import Path
import os,sys,json,subprocess,hashlib,datetime,urllib.request,stat
O=Path(__file__).parent;R=Path('/workspace/PR1456-fixed-branch-native-relap-prep-publisher-20261030/lock-scratch');TOOL=R/'chicago/4d/tools/ticket.mjs';EMPTY='4b825dc642cb6eb9a060e54bf8d69288fbee4904';API='https://api.github.com/repos/kevinrhaas/chicago/'
plans={1486:('a9a44ea2fd73d900f795d3844f8593ca44c1631d','Codex T-3262 phone renderer memory support 2026-10-30','89ad07fd2b43679c028715dbf30830b7dacf2a54'),1456:('656241b8f8e9b785a3c61e252ed9fdfccd0cd272','Codex four-building memory margin support 2026-10-30','3746b23bf1298c34a29946b4cdb6ee2d98abff8f')}
N=int(sys.argv[1]);OLD,BY,CODE=plans[N];REF=f'refs/heads/lap/pr-{N}';D=O/str(N);D.mkdir(exist_ok=True)
def get(p):return json.load(urllib.request.urlopen(urllib.request.Request(API+p,headers={'User-Agent':'Chicago-exact-LIVE-own-atomic-lap-renewal'}),timeout=30))
def refs():return {x['ref']:x['object']['sha'] for x in get('git/matching-refs/heads/')}
def floor():
 for p,n in [('/workspace',545259520),('/tmp',1800000000)]:
  s=os.statvfs(p);assert s.f_bavail*s.f_frsize>=n,('FLOOR',p,s.f_bavail*s.f_frsize,n)
floor();before=refs();assert before[REF]==OLD,'Marker changed; never overwrite foreign';pr=get(f'pulls/{N}');assert pr['state']=='open' and pr['head']['sha']==CODE and pr['base']['ref']=='dev' and not pr['draft'];m=get('git/commits/'+OLD);assert m['tree']['sha']==EMPTY and not m['parents'] and m['author']['name']=='polecat-steward' and m['author']['email']=='steward@polecat.live';assert m['message'].startswith(f'lap PR #{N} — '+BY+' ');dt=datetime.datetime.fromisoformat(m['committer']['date'].replace('Z','+00:00'));assert datetime.datetime.now(datetime.timezone.utc)<dt+datetime.timedelta(hours=3),'LIVE-own-only plan expired';assert hashlib.sha256(TOOL.read_bytes()).hexdigest()=='34c9f9db3cd6f1091ef075ad1bf77874a9e3f064e9e3ea4e633dc6d5569c5e90'
(D/'BEFORE.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_sha':OLD,'marker':m,'PR':pr,'advertised_refs':before,'live_same_owner':True,'source_primary_git_reads_or_writes':False},indent=2)+'\n')
(D/'BINDING.json').write_text(json.dumps({'PR':N,'old':OLD,'by':BY,'code_head':CODE,'ref':REF,'scratch':str(R)})+'\n');B=D/'bin';B.mkdir(exist_ok=True)
shim='''#!/usr/bin/env python3
from pathlib import Path
import os,sys,json,re,subprocess,urllib.request
D=Path(__file__).resolve().parent.parent;x=json.loads((D/'BINDING.json').read_text());R=Path(x['scratch']);a=sys.argv[1:];G='/usr/local/bin/git';REF=x['ref'];OLD=x['old'];assert Path.cwd().resolve().is_relative_to(R.resolve())
def fresh():
 u='https://api.github.com/repos/kevinrhaas/chicago/git/ref/heads/'+REF.removeprefix('refs/heads/');j=json.load(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Chicago-native-own-exact-CAS-guard'}),timeout=30));assert j['object']['sha']==OLD,'Owner changed; stop'
def record(kind,args):
 with (D/'GIT-AUDIT.jsonl').open('a') as f:f.write(json.dumps({'kind':kind,'native_args':a,'actual_args':args})+'\\n')
def run(network=False):
 cmd=[G]+(['-c','protocol.https.allow=always','-c','protocol.http.allow=never'] if network else [])+a;record('OWN_NATIVE_ALLOWED',cmd);os.execve(G,cmd,dict(os.environ,GIT_NO_LAZY_FETCH='1'))
if a in [['ls-remote','origin',REF],['fetch','--quiet','origin',REF]]:fresh();run(True)
if len(a)==4 and a[:2]==['push','origin'] and a[3] in ['--force-with-lease='+REF+':','--force-with-lease='+REF+':'+OLD] and re.fullmatch('[0-9a-f]{40}:'+re.escape(REF),a[2]):
 fresh();sid=a[2].split(':')[0];raw=subprocess.check_output([G,'cat-file','commit',sid]);head,msg=raw.split(b'\\n\\n',1);assert head.splitlines()[0]==b'tree 4b825dc642cb6eb9a060e54bf8d69288fbee4904' and not any(y.startswith(b'parent ') for y in head.splitlines());assert b'author polecat-steward <steward@polecat.live>' in head and b'committer polecat-steward <steward@polecat.live>' in head;assert msg.decode().startswith(f"lap PR #{x['PR']} — "+x['by']+' ') and b'\\nnonce: ' in msg
 if a[3].endswith(OLD):(D/'NEW-NATIVE-MARKER.json').write_text(json.dumps({'sha':sid,'raw_commit':raw.decode()})+'\\n')
 run(True)
if a==['hash-object','-w','-t','tree','/dev/null']:run()
if len(a)==4 and a[:2]==['commit-tree','4b825dc642cb6eb9a060e54bf8d69288fbee4904'] and a[2]=='-m' and a[3].startswith(f"lap PR #{x['PR']} — "+x['by']+' '):run()
if a and a[0] in ['rev-parse','log','show','cat-file','status','diff','symbolic-ref','ls-files']:run()
sys.exit('Own-lap-only transport denied unexpected Git operation')
''';(B/'git').write_text(shim);(B/'git').chmod(0o700)
env=dict(os.environ,PATH=str(B)+':'+os.environ['PATH'],NODE_DISABLE_COMPILE_CACHE='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(D),GIT_AUTHOR_NAME='polecat-steward',GIT_AUTHOR_EMAIL='steward@polecat.live',GIT_COMMITTER_NAME='polecat-steward',GIT_COMMITTER_EMAIL='steward@polecat.live')
cmd=['taskset','-c','2','node',str(TOOL),'lap',str(N),'--force','--by',BY];(D/'NATIVE-COMMAND.json').write_text(json.dumps(cmd)+'\n');q=subprocess.run(cmd,cwd=R,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(D/'NATIVE.log').write_text(q.stdout);assert q.returncode==0 and (D/'NEW-NATIVE-MARKER.json').exists(),q.stdout
new=json.loads((D/'NEW-NATIVE-MARKER.json').read_text())['sha'];after=refs();assert after.get(REF)==new;actual=get('git/commits/'+new);assert actual['tree']['sha']==EMPTY and not actual['parents'] and actual['message'].startswith(f'lap PR #{N} — '+BY+' ');created=datetime.datetime.fromisoformat(actual['committer']['date'].replace('Z','+00:00'));assert get(f'pulls/{N}')['head']['sha']==CODE;foreign={k:{'before':before.get(k),'after':after.get(k)} for k in set(before)|set(after) if k!=REF and before.get(k)!=after.get(k)};floor()
r={'status':'ACTUAL_NATIVE_LIVE_SAME_OWNER_ATOMIC_EXACT_OLD_LAP_RENEWAL_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'PR':N,'old_sha':OLD,'new_sha':new,'created':created.isoformat(),'expires':(created+datetime.timedelta(hours=3)).isoformat(),'actual_native_command':cmd,'native_exit':q.returncode,'native_output':q.stdout,'code_head_unchanged':CODE,'only_own_metadata_lap_write_allowed':True,'no_release_gap':True,'primary_source_Git_operations':False,'all_advertised_foreign_refs_unchanged':not foreign,'foreign_ref_changes_observed':foreign,'wording_qualification':'The native --force output may call this a dead-lap steal. The exact old marker was actually LIVE and belongs to this same user thread; --force overrode only our own live lease and actual replacement used exact-old CAS, no code force or foreign marker overwrite.'};(D/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
