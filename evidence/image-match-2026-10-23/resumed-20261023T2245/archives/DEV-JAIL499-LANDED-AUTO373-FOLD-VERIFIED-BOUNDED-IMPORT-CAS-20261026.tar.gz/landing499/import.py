from pathlib import Path
import subprocess,os,json,hashlib,shutil,datetime,time,signal
B=Path('/tmp/current-dev-landing499-metadata-cas-20261026T2105');C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='ecfff9f56ce359b70aa520e97d1923c12a6dafb2';NEW='499a0e72d98f6c351d95bc62bac06a2ffa8c3c41';CHECKED='bbbe518720601b785e79628bf247ee4b9f9d4ed8';TREE='897824de45d16cd90fe2400cd3b8aace341d42ea'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');os.sched_setaffinity(0,{2});os.nice(10)
def git(repo,*args,input=None):return subprocess.check_output(['git','-C',str(repo),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def js(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{str(p):{'sha256':sha(p),'mode':p.stat().st_mode}for p in [G/'HEAD',G/'index',G/'config']}}
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path]))
release=json.loads(Path('/tmp/jail-currentdev-ending-20261026/rail-lazy-headroom/qualified-merge/LAP-RELEASE-RESULT.json').read_text());assert release['status']=='OWN_LAP_RELEASED_AFTER_CONFIRMED_MERGE'
rootgate=json.loads(Path('/workspace/T2382-currentdev-integration-20261026/current-full3-reaper.json').read_text());assert rootgate['command_exit']==0 and rootgate['all_children_reaped']
before=snap();js('SOURCE-BEFORE-AFTER-LAP-RELEASE.json',before);assert before['HEAD']==CHECKED and git(C,'rev-parse','origin/dev').decode().strip()==OLD;assert not git(C,'status','--porcelain','--untracked-files=no').strip()
fresh=api('git/ref/heads/dev');commit=api('git/commits/'+NEW);js('FRESH-REMOTE-AT-START.json',fresh);js('LANDING-COMMIT.json',commit);assert commit['sha']==NEW and commit['tree']['sha']==TREE;assert [x['sha']for x in commit['parents']]==[OLD];assert git(C,'rev-parse',CHECKED+'^{tree}').decode().strip()==TREE
ls=git(C,'ls-tree','-r','-z',TREE);ids=[]
for row in ls.split(b'\0'):
 if row:
  meta,path=row.split(b'\t',1);mode,kind,blob=meta.decode().split()
  if kind=='blob':ids.append(blob)
ids=sorted(set(ids));batch=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();assert not any(r.endswith(' missing')for r in batch)
price={'status':'EXACT_LANDING_TREE_ALREADY_LOCAL_NO_NEW_BLOBS','landing_commit':NEW,'landing_tree':TREE,'checked_local_head':CHECKED,'checked_tree_equal':True,'landing_parent_exact_cached_old':OLD,'tip_unique_blob_count':len(ids),'missing_blobs':0,'missing_blob_bytes':0,'fresh_remote':fresh['object']['sha'],'root_gate_closed':True,'snapshot_after_lap_release':release};js('PRICE.json',price)
assert shutil.disk_usage('/tmp').free>512*1024**2
# Bounded isolated immutable metadata fetch, never a source-common fetch.
cmd=['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',NEW]
with (B/'metadata-fetch.log').open('xb')as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);reason=None;peak=0
 while p.poll()is None:
  size=sum(f.stat().st_size for f in(R/'objects').rglob('*')if f.is_file());peak=max(peak,size)
  if size>24*1024**2:reason='Isolated metadata exceeded24MiB'
  if b'filtering not recognized'in(B/'metadata-fetch.log').read_bytes().lower():reason='Server ignored requested filtering'
  if reason:os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(.1)
 rc=p.wait()
js('METADATA-FETCH.json',{'exit':rc,'peak_object_bytes':peak,'abort':reason});assert rc==0 and reason is None
assert git(R,'rev-parse',NEW+'^{tree}').decode().strip()==TREE;assert git(R,'cat-file','-p',NEW).split(b'\n')[0]==('tree '+TREE).encode()
assert git(R,'ls-tree','-r','-z',NEW)==ls
alloc=0;packs=[]
for pack in sorted((R/'objects/pack').glob('*.pack')):
 git(R,'verify-pack',str(pack.with_suffix('.idx')));data=pack.read_bytes();assert hashlib.sha1(data[:-20]).digest()==data[-20:]
 for src in [pack,pack.with_suffix('.idx'),pack.with_suffix('.promisor')]:
  if not src.exists():continue
  dest=G/'objects/pack'/src.name;new=not dest.exists()
  if not new:assert sha(src)==sha(dest)
  else:
   tmp=dest.with_name('.'+dest.name+'.landing499-'+str(os.getpid()));shutil.copy2(src,tmp);assert sha(src)==sha(tmp);tmp.rename(dest);alloc+=dest.stat().st_blocks*512
  packs.append({'file':src.name,'bytes':src.stat().st_size,'sha256':sha(src),'new':new})
assert alloc<2*1024**2,'Unexpected metadata allocation';js('PACK-IMPORT.json',packs);assert git(C,'rev-parse',NEW+'^{tree}').decode().strip()==TREE;assert git(C,'merge-base',NEW,OLD).decode().strip()==OLD
assert snap()==before,'Source HEAD/index/config/ref changed during metadata import'
remote=api('git/ref/heads/dev');js('FRESH-REMOTE-BEFORE-CAS.json',remote);cas=remote['object']['sha']==NEW
if cas:
 assert snap()==before;git(C,'update-ref','refs/remotes/origin/dev',NEW,OLD)
after=snap();assert after['metadata']==before['metadata']and after['HEAD']==before['HEAD'];expected=[line.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+NEW)for line in before['refs']]if cas else before['refs'];assert after['refs']==expected;assert not git(C,'status','--porcelain','--untracked-files=no').strip();js('SOURCE-AFTER.json',after)
result={'status':'EXACT499_LANDING_METADATA_IMPORT_AND_CAS_PASS'if cas else'EXACT499_OBJECTS_ONLY_REMOTE_MOVED_NO_CAS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'landing_commit':NEW,'tree':TREE,'tip_unique_blob_count':len(ids),'missing_blobs':0,'new_metadata_allocated_bytes':alloc,'cached_origin_dev':git(C,'rev-parse','origin/dev').decode().strip(),'fresh_remote':remote['object']['sha'],'primary_HEAD_before_after':CHECKED,'source_HEAD_index_config_unchanged':True,'all_other_refs_unchanged':True,'source_clean':True,'full3_closed_before_CAS':True,'lap_release_snapshot_before_all_refs_snapshot':True,'no_source_common_fetch':True,'no_checkpoint_compression':True};js('RESULT.json',result);print(json.dumps(result,indent=2))
