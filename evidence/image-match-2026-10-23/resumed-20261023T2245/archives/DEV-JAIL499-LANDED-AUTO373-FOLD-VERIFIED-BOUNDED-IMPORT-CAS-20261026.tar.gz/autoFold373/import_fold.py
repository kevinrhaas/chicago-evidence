from pathlib import Path
import subprocess,os,json,hashlib,shutil,datetime,time,signal,zlib,urllib.request,urllib.parse
B=Path('/tmp/current-dev-post499-fold373-price-20261026T2106');C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='ecfff9f56ce359b70aa520e97d1923c12a6dafb2';LAND='499a0e72d98f6c351d95bc62bac06a2ffa8c3c41';NEW='373851d158a7b6fc701b9cae1a651aa4b3823f97';HEAD='bbbe518720601b785e79628bf247ee4b9f9d4ed8';TREE='17d47d73eb86e8e3ca6f0219e8be1ebc19f91906';FLOOR=128*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');os.sched_setaffinity(0,{2});os.nice(10)
def git(repo,*args,input=None):return subprocess.check_output(['git','-C',str(repo),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],input=input,env=env)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{str(p):{'sha256':sha(p),'mode':p.stat().st_mode}for p in [G/'HEAD',G/'index',G/'config']}}
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path]))
price=json.loads((B/'MISSING-PRICE.json').read_text());cmp=json.loads((B/'COMPARE.json').read_text());commit=json.loads((B/'COMMIT.json').read_text());assert sum(x['size']for x in price['missing'])<=5*1024**2
assert commit['sha']==NEW and commit['tree']['sha']==TREE and [x['sha']for x in commit['parents']]==[LAND]
assert commit['author']['name']=='polecat-ci'and commit['message'].startswith('changelog: fold entry files into changelog.js; re-derive merged counts')
assert cmp['total_commits']==1 and {(x['filename'],x['status'])for x in cmp['files']}=={('chicago/4d/changelog.d/T-2380.json','removed'),('chicago/4d/renderers/web/js/changelog.js','modified')}
assert shutil.disk_usage('/workspace').free>=FLOOR+7*1024**2
before=snap();save('SOURCE-BEFORE.json',before);assert before['HEAD']==HEAD and git(C,'rev-parse','origin/dev').decode().strip()==OLD;assert not git(C,'status','--porcelain','--untracked-files=no').strip()
# Only immutable filtered metadata into existing isolated repository.
command=['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',NEW]
with(B/'metadata-fold-fetch.log').open('xb')as log:
 p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);reason=None;peak=0
 while p.poll()is None:
  size=sum(f.stat().st_size for f in(R/'objects').rglob('*')if f.is_file());peak=max(peak,size)
  if size>24*1024**2:reason='Metadata exceeded24MiB'
  if b'filtering not recognized'in(B/'metadata-fold-fetch.log').read_bytes().lower():reason='Server ignored filtering'
  if reason:os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(.1)
 rc=p.wait()
save('FOLD-METADATA-FETCH.json',{'exit':rc,'peak_bytes':peak,'abort':reason});assert rc==0 and not reason
assert git(R,'rev-parse',NEW+'^{tree}').decode().strip()==TREE
rawdiff=git(R,'diff-tree','--no-commit-id','--raw','-r','--no-renames',LAND,NEW).decode();(B/'ISOLATED-ACTUAL-LEAF-DIFF.txt').write_text(rawdiff);assert len(rawdiff.splitlines())==2
assert 'chicago/4d/changelog.d/T-2380.json'in rawdiff and'chicago/4d/renderers/web/js/changelog.js'in rawdiff
alloc=0;packs=[]
for pack in sorted((R/'objects/pack').glob('*.pack')):
 git(R,'verify-pack',str(pack.with_suffix('.idx')));data=pack.read_bytes();assert hashlib.sha1(data[:-20]).digest()==data[-20:]
 for src in [pack,pack.with_suffix('.idx'),pack.with_suffix('.promisor')]:
  if not src.exists():continue
  dest=G/'objects/pack'/src.name;new=not dest.exists()
  if not new:assert sha(src)==sha(dest)
  else:
   temp=dest.with_name('.'+dest.name+'.fold373-'+str(os.getpid()));shutil.copy2(src,temp);assert sha(src)==sha(temp);temp.rename(dest);alloc+=dest.stat().st_blocks*512
  packs.append({'name':src.name,'bytes':src.stat().st_size,'sha256':sha(src),'new':new})
save('FOLD-PACK-IMPORT.json',packs);rows=[]
for row in price['missing']:
 url='https://raw.githubusercontent.com/kevinrhaas/chicago/'+NEW+'/'+urllib.parse.quote(row['path'],safe='/')
 with urllib.request.urlopen(url,timeout=90)as response:data=response.read(row['size']+65536)
 assert len(data)==row['size'];payload=b'blob '+str(len(data)).encode()+b'\0'+data;assert hashlib.sha1(payload).hexdigest()==row['sha'];dest=G/'objects'/row['sha'][:2]/row['sha'][2:];assert not dest.exists()
 # Ordinary Git loose-object encoding, not checkpoint/tar compression.
 encoded=zlib.compress(payload);dest.parent.mkdir(exist_ok=True);temp=dest.with_name(dest.name+'.fold373-'+str(os.getpid()));temp.write_bytes(encoded);assert hashlib.sha1(zlib.decompress(temp.read_bytes())).hexdigest()==row['sha'];temp.rename(dest);alloc+=dest.stat().st_blocks*512;rows.append({'path':row['path'],'sha':row['sha'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoded_bytes':len(encoded)})
assert alloc<=5*1024**2;save('FOLD-BLOB-IMPORT.json',{'rows':rows,'new_allocated_bytes':alloc})
assert git(C,'rev-parse',NEW+'^{tree}').decode().strip()==TREE
listing=git(C,'ls-tree','-r','-z',NEW);ids=sorted({r.split(b'\t',1)[0].decode().split()[2]for r in listing.split(b'\0')if r and r.split(b'\t',1)[0].decode().split()[1]=='blob'});batch=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();assert not any(x.endswith(' missing')for x in batch)
assert snap()==before;assert shutil.disk_usage('/workspace').free>=FLOOR
fresh=api('git/ref/heads/dev');save('FRESH-REMOTE-BEFORE-CAS.json',fresh);cas=fresh['object']['sha']==NEW
if cas:
 assert snap()==before;git(C,'update-ref','refs/remotes/origin/dev',NEW,OLD)
after=snap();save('SOURCE-AFTER.json',after);assert after['metadata']==before['metadata']and after['HEAD']==HEAD;expected=[x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+NEW)for x in before['refs']]if cas else before['refs'];assert after['refs']==expected
result={'status':'NORMAL_T2380_FOLD_IMPORTED_AND_EXPECTED_OLD_CAS_PASS'if cas else'PRICED373_OBJECTS_IMPORTED_FRESH_REMOTE_MOVED_NO_CAS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'landing':LAND,'landing_tree':'897824de45d16cd90fe2400cd3b8aace341d42ea','automatic_fold':NEW,'fold_tree':TREE,'fold_only_two_expected_paths':True,'new_blob_count':len(rows),'new_blob_uncompressed_bytes':sum(x['bytes']for x in rows),'new_object_allocated_bytes':alloc,'all_tip_unique_blobs_present':len(ids),'cached_origin_dev':git(C,'rev-parse','origin/dev').decode().strip(),'fresh_remote_dev':fresh['object']['sha'],'primary_HEAD':HEAD,'HEAD_index_config_unchanged':True,'all_other_refs_unchanged':True,'source_clean':not git(C,'status','--porcelain','--untracked-files=no').strip(),'workspace_free':shutil.disk_usage('/workspace').free,'workspace_floor':FLOOR,'no_source_common_fetch':True,'no_checkpoint_compression':True,'ROOT_expanded_authorization':'Genuine automatic T2380 fold <=5MiB newsourceobjects and WS>=128MiB; expected-old CAS; no unexplainedfeature/assets.'};save('RESULT.json',result);print(json.dumps(result,indent=2))
