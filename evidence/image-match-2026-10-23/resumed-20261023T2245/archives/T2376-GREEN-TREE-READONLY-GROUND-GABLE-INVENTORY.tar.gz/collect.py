import pathlib,json,hashlib,sys,dataclasses,subprocess,shutil
r=pathlib.Path('/workspace/primary-human-runner-compat');app=r/'chicago/4d';out=pathlib.Path(__file__).parent;ref='308b738e6e6716a7a1411aa6c178e196eb17a719';sha=lambda b:hashlib.sha256(b).hexdigest();sys.path.insert(0,str(app/'generators'));import mesh_inputs
status_before=subprocess.check_output(['git','-C',str(r),'status','--porcelain=v1'],text=True)
sids=['andreas_1884_green_tree_hotel_plate','trowbridge_green_tree_1902','kurz_allison_1893','chm_green_tree_1859'];paths=['data/structures/green_tree_tavern.json','generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','generators/mesh_inputs.py','assets/manifest.json','assets/manifest.web.json']+[f'data/sources/{s}.json' for s in sids];binding={};frozen={}
for p in paths:
 b=subprocess.check_output(['git','-C',str(r),'show',f'{ref}:chicago/4d/{p}']);frozen[p]=b;current=(app/p).read_bytes();binding[p]={'frozen_sha256':sha(b),'current_sha256':sha(current),'bytes':len(b),'worktree_exact':b==current}
 if not p.startswith('assets/manifest'):assert b==current,p
record=json.loads(frozen[paths[0]]);phase=record['phases'][0];params=mesh_inputs.resolve_params('frame_tavern',phase,record)
(out/'current-target-record.json').write_text(json.dumps(record,indent=2)+'\n');(out/'current-target-params.json').write_text(json.dumps(dataclasses.asdict(params),indent=2)+'\n');(out/'current-source-records.json').write_text(json.dumps({s:json.load(open(app/f'data/sources/{s}.json')) for s in sids},indent=2)+'\n')
m=json.load(open(app/'assets/manifest.json'))['assets'];w=json.load(open(app/'assets/manifest.web.json'))['masters'];fm=json.loads(frozen['assets/manifest.json'])['assets'];fw=json.loads(frozen['assets/manifest.web.json'])['masters'];family={}
for name,row in m.items():
 if row.get('archetype')!='frame_tavern':continue
 assert row==fm[name];assert w[name]==fw[name]
 d=json.load(open(app/f'data/structures/{row["structure_id"]}.json'));p=next(p for p in d['phases'] if p['id']==row['phase_id']);digest=mesh_inputs.structure_inputs_sha(d,p);assert digest==row['inputs_sha256'],name
 family[name]={'record_id':row['structure_id'],'phase_id':p['id'],'recipe':digest,'master_sha256':sha((app/'assets/gltf'/name).read_bytes()),'master_bytes':(app/'assets/gltf'/name).stat().st_size,'web_sha256':sha((app/'assets/web'/name).read_bytes()),'web_bytes':(app/'assets/web'/name).stat().st_size,'web_row':w[name]}
assert len(family)==23
images={'andreas-whole.jpg':r/'chicago/reference/images/chicago/chicago_green_tree_inn_1838.jpg','trowbridge-full-original-plate.jpg':app/'data/sources/assets/trowbridge_green_tree_1902/gale-n55.jpg','kurz-panel11.png':app/'data/sources/assets/prefire_views_kevin_2026_08/p6_0.png','current-exact-master-old-actual-comparison.jpg':app/'docs/RESEARCH/frame-picture-match-T-2376-T-2385/green-tree/source-before-after.jpg'};info={}
for n,p in images.items():shutil.copyfile(p,out/n);info[n]={'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'actually_viewed':True}
match=app/'docs/RESEARCH/frame-picture-match-T-2376-T-2385/green-tree/andreas_1884_south.provisional.match.json';d=json.load(open(match));assert d['glb_sha256']==family['green_tree_tavern__frame_1833.glb']['master_sha256'];shutil.copyfile(match,out/'existing-actual-match-differs.json')
assert status_before==subprocess.check_output(['git','-C',str(r),'status','--porcelain=v1'],text=True)
(out/'BINDINGS.json').write_text(json.dumps({'ref':ref,'head_actual':subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','-C',str(r),'rev-parse',ref+'^{tree}'],text=True).strip(),'frozen_preimages':binding,'family':family,'actual_images':info,'target_old_actual_comparison_master_exact':True,'status_before_after_exact':status_before,'all23_current_recipes_recomputed_fresh':True,'all23_current_frame_master_web_rows_equal_308b':True,'whole_manifests_not_equal_308b_due_to_expected_private_officers_trial':True,'no_bake_capture_browser_or_mesh_change':True},indent=2)+'\n')
print('PASS',out,'family',len(family),'target',family['green_tree_tavern__frame_1833.glb']['recipe'])
