"""Prepared, not executed: adopt the two peer packets only on the settled group base.

The lead first restores its own reviewed Miller inputs fieldwise. This command
never changes branch, fetches, stamps recipes or overwrites a whole incoming registry.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess,os,shutil,datetime
R=Path('/workspace/chicago');A=R/'chicago/4d'
MARY=Path('/tmp/Mary-T2384-final-unit-orchestration-20261027/HANDOFF-MILLER-GROUP')
LIGHT=Path('/workspace/shared/T2373-canonical-capture-and-transfer-20261027T0325')
ALIAS=Path('/tmp/lighthouse-grade-alias-entrywise-20261027T0335/EXACT-OLD-NEW.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=R).decode().strip()
def manifest(root,expected):
 p=root/'MANIFEST.json';assert sha(p)==expected,p
 m=json.loads(p.read_text());rows=m.get('files',m.get('members'));assert isinstance(rows,list)
 for x in rows:assert(root/x['path']).stat().st_size==x['bytes']and sha(root/x['path'])==x['sha256'],x['path']
 return len(rows)
def append(path,extra):
 old=path.read_bytes();assert extra.strip()
 if extra.strip()in old:return
 path.write_bytes(old+(b''if old.endswith(b'\n')else b'\n')+extra);assert path.read_bytes().startswith(old)
def copy_owned(src,dst,old_sha=None):
 if dst.exists():
  if sha(dst)==sha(src):return
  assert old_sha and sha(dst)==old_sha,str(dst)+' already differs; adjudicate the owned path'
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert sha(src)==sha(dst)
def source_appends(patch):
 allowed={'chicago/4d/docs/RESEARCH/chicago_lighthouse_1832.md','chicago/4d/docs/ROADMAP.md','chicago/4d/docs/STATUS.md'}
 current=None;added={};deletes=[]
 for line in patch.read_bytes().splitlines(keepends=True):
  if line.startswith(b'diff --git '):current=line.rstrip().split(b' b/',1)[1].decode()
  elif current in allowed and line.startswith(b'+')and not line.startswith(b'+++'):added.setdefault(current,[]).append(line[1:])
  elif current in allowed and line.startswith(b'-')and not line.startswith(b'---'):deletes.append(current)
 assert not deletes,deletes;assert set(added)==allowed
 return {k:b''.join(v)for k,v in added.items()}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--settled-head',required=True);p.add_argument('--out',required=True,type=Path);args=p.parse_args();O=args.out
 assert os.environ.get('EARLY_THREE_SOURCE_READY')=='C6-and-TremontGT-actually-merged','Wait for accepted predecessor batch'
 assert git('rev-parse','HEAD')==args.settled_head and not git('diff','--name-only','--diff-filter=U')
 assert not O.exists();O.mkdir(parents=True)
 assert json.loads((A/'data/structures/miller_house.json').read_text())['phases'][0]['form']['frame_addition_upper_windows']['value']==3,'Restore current Miller authored inputs first'
 before={'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'status':git('status','--porcelain=v1'),'lighthouse_master':sha(A/'assets/gltf/chicago_lighthouse_1832__tower_1832.glb')};dump(O/'BEFORE.json',before)
 assert before['lighthouse_master']=='ae855793a983ff884b2653479c74fe517d3f8f2f14b6eae606f972a68373224d'
 manifest(MARY,'2fc73a383fb4764304e90265b53945e3a3b19a827b2d731224a74eb8969e673e');manifest(LIGHT,'b381c731bb6f93796df70d29af2ef340d938af984076a525d66c3ccaaea412e6')
 binding=json.loads((MARY/'SOURCE-AND-REVIEW-BINDING.json').read_text());old=binding['old_three_file_sha256'];new=binding['new_three_file_sha256']
 current={k:sha(R/k)for k in old}
 if current==old:
  subprocess.run(['git','apply','--check',str(MARY/'approved-three-source-files.patch')],cwd=R,check=True)
  subprocess.run(['git','apply',str(MARY/'approved-three-source-files.patch')],cwd=R,check=True)
 else:assert current==new,'Mary authored inputs changed on the settled base; merge them consciously'
 assert all(sha(R/k)==v for k,v in new.items())
 rows=json.loads((MARY/'FRAME-271-ENTRYWISE-REGISTRY-ROWS.json').read_text());assert len(rows['new_genuine_producer_entries'])==271
 mp=A/'assets/manifest.json';book=json.loads(mp.read_text());saved_other={k:v for k,v in book['assets'].items()if k not in rows['old_entries']}
 for name,value in rows['new_genuine_producer_entries'].items():
  assert book['assets'].get(name)in [rows['old_entries'][name],value],name+' incoming registry row differs; regenerate instead of restamping'
  book['assets'][name]=value
 for kind in ['gltf','web']:
  src=MARY/'native-assets'/kind/'st_marys_church__frame_1833.glb';dst=A/'assets'/kind/src.name
  if kind=='gltf':assert sha(dst)in {rows['old_MASTER_sha_bindings'][src.name],binding['new_MASTER_sha256']},'Unexpected incoming Mary master'
  elif sha(dst)!=binding['new_WEB_sha256']:assert not git('diff','--name-only','HEAD','--',str(dst.relative_to(R))),'Preserve unexpected Mary WEB work'
  dst.write_bytes(src.read_bytes())
 for name,h in rows['new_current_MASTER_sha_bindings'].items():assert sha(A/'assets/gltf'/name)==h,name+' current frame control differs'
 assert {k:v for k,v in book['assets'].items()if k not in rows['old_entries']}==saved_other;dump(mp,book)
 wp=A/'assets/manifest.web.json';web=json.loads(wp.read_text());other=dict(web['masters']);web['masters']['st_marys_church__frame_1833.glb']=binding['new_MASTER_sha256'];dump(wp,web)
 assert all(web['masters'][k]==v for k,v in other.items()if k!='st_marys_church__frame_1833.glb')
 for kind in ['match','comparison']:
  if kind=='match':rel='data/reference_views/st_marys_church/moss-engraving.match.json';oldsha=binding['old_match_sha256']
  else:rel='docs/RESEARCH/photo-match/st_marys_church/moss-engraving-side-by-side.jpg';oldsha=binding['old_comparison_sha256']
  copy_owned(MARY/'reviewed-view'/rel,A/rel,oldsha)
 assert sha(A/'data/reference_views/st_marys_church/moss-engraving.json')==binding['camera_sha256']
 for label in ['LIBERTIES.md','ROADMAP.md','STATUS.md']:
  extra=(MARY/'append-only-docs'/(label+'.append')).read_bytes()
  if label=='LIBERTIES.md'and b'**Recorded:**'not in extra:extra+=b'\n**Ticket:** T-2384.\n\n**Recorded:** 2026-10-27.\n'
  append(A/'docs'/label,extra)
 for rel,extra in source_appends(LIGHT/'tracked-WIP.patch').items():append(R/rel,extra)
 for src in sorted((LIGHT/'untracked').rglob('*')):
  if not src.is_file():continue
  rel=src.relative_to(LIGHT/'untracked')
  if str(rel)=='chicago/4d/changelog.d/T-2373.json':continue
  copy_owned(src,R/rel)
 sp=R/'chicago/prairie_1904_v1/research/images/STORE.json';store=json.loads(sp.read_text());oldfiles=dict(store['files']);newrows=json.loads((LIGHT/'STORE-NEW-ROWS.json').read_text());assert len(newrows)==2
 for k,v in newrows.items():assert k not in store['files']or store['files'][k]==v;store['files'][k]=v
 assert all(store['files'][k]==v for k,v in oldfiles.items());store['bytes']=sum(v['bytes']for v in store['files'].values());dump(sp,store)
 assert sha(ALIAS)=='b328d55da77677605392a290710364769ab669d1ad78f49b3a3aeb1fa35de29b'
 alias=json.loads(ALIAS.read_text());gradefile=R/alias['file'];grades=json.loads(gradefile.read_text());indices=[i for i,x in enumerate(grades[alias['array']])if x.get('scene')=='1835'and x.get('structure')=='chicago_lighthouse_1832'];assert len(indices)==1
 index=indices[0];current=grades[alias['array']][index];assert current in [alias['old_record'],alias['new_record']]
 if current!=alias['new_record']:
  def fragment(record):return '\n'.join('    '+line for line in json.dumps(record,indent=2,ensure_ascii=False).splitlines()).encode()
  raw=gradefile.read_bytes();old_fragment=fragment(alias['old_record']);new_fragment=fragment(alias['new_record']);assert raw.count(old_fragment)==1,'Preserve current serialization; adjudicate this one row'
  gradefile.write_bytes(raw.replace(old_fragment,new_fragment));actual=json.loads(gradefile.read_text());expected=json.loads(raw);expected[alias['array']][index]=alias['new_record'];assert actual==expected
 dump(O/'ALIAS-ENTRYWISE-APPLIED.json',{'packet':str(ALIAS),'sha256':sha(ALIAS),'row':alias['new_record'],'only_existing_picture_and_why_changed':True,'grade_not_changed':'attested','native_singular_picture_join_still_to_be_checked_after_image_builder':True})
 entry={'title':"The lighthouse, St Mary's and Miller House",'kind':'feature','items':["The Miller House's main range has a short roof chimney and three upper front windows, following the old drawing. The low cabin, lower windows and entrance retain their previous form.",(MARY/'GROUP-CHANGELOG-ITEM.txt').read_text().strip(),"The lighthouse's card carries a credited early harbour view. Its picture review distinguishes the governing view from later, tiny and conflicting depictions."]};dump(A/'changelog.d/T-2381.json',entry)
 assert not(A/'changelog.d/T-2373.json').exists()and not(A/'changelog.d/T-2384.json').exists(),'Keep only the one group entry'
 assert sha(A/'assets/gltf/chicago_lighthouse_1832__tower_1832.glb')==before['lighthouse_master']
 # Real input fingerprints, after all source files are composed. No hash repair.
 import sys;sys.path.insert(0,str(A/'generators'));import mesh_inputs
 assets=json.loads((A/'assets/manifest.json').read_text())['assets'];fresh=[]
 for filename,entry in assets.items():
  if entry.get('archetype')not in {'log_dwelling','frame_dwelling'}:continue
  r=json.loads((A/'data/structures'/f"{entry['structure_id']}.json").read_text());ph=next(x for x in r['phases']if x['id']==entry['phase_id']);actual=mesh_inputs.structure_inputs_sha(r,ph,entry['archetype']);fresh.append({'name':filename,'expected':actual,'recorded':entry['inputs_sha256'],'fresh':actual==entry['inputs_sha256']})
 dump(O/'COMBINED-RECIPE-AUDIT.json',fresh);assert all(x['fresh']for x in fresh),'Use genuine affected-family native regeneration; never restamp a stale recipe'
 dump(O/'RESULT.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'AUTHORED_PEER_PACKETS_ADOPTED_ENTRYWISE_NATIVE_CLOSURE_PENDING','base':args.settled_head,'frame_rows_updated':271,'all_incoming_nonfamily_rows_preserved':True,'all_incoming_STORE_rows_preserved':True,'new_STORE_rows':2,'combined_recipe_rows':len(fresh),'all_combined_recipes_fresh':True,'lighthouse_physical_master_unchanged':True,'one_group_changelog':True,'existing_alias_record_applied_entrywise':True,'native_image_builder_owning_tail_all44_publish_app_full3_PR_merge_still_owed':True,'original_Miller_open':True})
 print((O/'RESULT.json').read_text())
if __name__=='__main__':main()
