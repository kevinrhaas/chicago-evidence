from pathlib import Path
import os,hashlib,json,subprocess,datetime,shutil
R=Path('/workspace/chicago');mirror=R/'site/4d';O=Path('/tmp/miller-primary-preview-retirement-20261027T0215')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
def write(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def state():
 return {'HEAD':git('rev-parse','HEAD').decode().strip(),'index_sha256':sha(R/'.git/index'),'config_sha256':sha(R/'.git/config'),'status_sha256':hashlib.sha256(git('status','--porcelain=v1','-z')).hexdigest()}
assert mirror.is_dir() and not mirror.is_symlink();assert not git('ls-files','-z','--','site/4d')
ignored=subprocess.run(['git','check-ignore','-v','site/4d'],cwd=R,capture_output=True,text=True);assert ignored.returncode==0;write('IGNORED.json',{'ignored':ignored.stdout.strip(),'tracked_mirror_files':0,'restore_command':'source /workspace/shared/resume-chicago-env.sh; unset GIT_NO_LAZY_FETCH CHICAGO_TICKETS_DIR; cd /workspace/chicago/chicago/4d; bash tools/publish.sh','scope':'Only generated primary site/4d; source/assets/cache untouched.'})
readers=[];denied=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit()or int(proc.name)==os.getpid():continue
 try:
  raw=(proc/'stat').read_text();fields=raw[raw.rfind(')')+2:].split()
  if fields[0]=='Z':continue
  cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  # This task's parent shell embeds the intended mirror path in script text; require
  # an actual filesystem handle or a serving/runtime command rather than text alone.
  handles=[]
  for f in [proc/'cwd',proc/'root',*list((proc/'fd').iterdir())]:
   try:target=os.readlink(f)
   except OSError:continue
   if target==str(mirror)or target.startswith(str(mirror)+'/'):handles.append({'handle':str(f),'target':target})
  try:
   maps=(proc/'maps').read_text()
   if str(mirror)+'/'in maps:handles.append({'handle':'maps','target':str(mirror)})
  except OSError:pass
  if handles:readers.append({'pid':int(proc.name),'cmd':cmd[:300],'handles':handles})
  elif str(mirror)in cmd and any(x in cmd.split() for x in ['node','chromium','python3','http.server']):
   if 'retire.py'not in cmd and 'bash -lc'not in cmd:readers.append({'pid':int(proc.name),'cmd':cmd[:300],'reason':'runtime command explicitly names mirror'})
 except PermissionError:denied.append(int(proc.name))
 except (FileNotFoundError,ProcessLookupError):pass
services=[]
for pid in denied:
 proc=Path('/proc')/str(pid);cmd=(proc/'cmdline').read_bytes().split(b'\0')[0].decode();status=(proc/'status').read_text();uid=next(line.split()[1]for line in status.splitlines()if line.startswith('Uid:'))
 assert pid in {125,176} and uid=='65534'and Path(cmd).name in {'dockerd','containerd'},('Unexpected unreadable application process',pid,cmd,uid)
 services.append({'pid':pid,'executable':cmd,'uid':uid,'fd_visibility':'system service descriptors unreadable; not an app task'})
containers=subprocess.check_output(['docker','ps','--format','{{.ID}} {{.Names}}'],text=True);assert not containers.strip(),'Active container could be a mirror reader'
write('READERS-BEFORE.json',{'task_and_readable_process_readers':readers,'unreadable_managed_docker_services':services,'active_containers':[],'scope':'Every application/task process readable; only the two known UID65534 dormant Docker daemons have inaccessible descriptors, with no running containers.'});assert not readers,readers
before=state();free=shutil.disk_usage(R).free;files=sum(1 for f in mirror.rglob('*')if f.is_file());allocated=sum(f.stat().st_blocks*512 for f in mirror.rglob('*')if f.is_file());write('BEFORE.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_state':before,'workspace_free':free,'files':files,'allocated_bytes':allocated})
shutil.rmtree(mirror)
after=state();assert before==after;assert not mirror.exists();nowfree=shutil.disk_usage(R).free
write('RESULT.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','deleted_only':str(mirror),'source_HEAD_index_config_status_exact':True,'zero_tracked_files':True,'zero_task_or_application_readers':True,'system_service_fd_limit_explicit':True,'no_active_containers':True,'actual_workspace_df_gain':nowfree-free,'workspace_free_after':nowfree,'prior_allocated_bytes':allocated,'files':files,'restore_command':'cd /workspace/chicago/chicago/4d && bash tools/publish.sh','no_source_assets_cache_pruning':True});print((O/'RESULT.json').read_text())
