# CLOSED actual public H8 CI evidence — not merge acceptance

Declared PR1260H8head35f0c564cc25303d3f5641812d532dd9d2166b64 has three actual completedSUCCESS jobs:

- gate run40084563566/job120844716473, completed10:29:56Z. Actualrawlog CHECKPASS1063steps/nonered,383selftests; changelogPRquestion also succeeds.
- moving-frames run40084563539/job120844716040, completed10:26:08Z. Actualrawlog everymovingframeinsidetheceiling; phoneupload-release step also succeeds.
- humans run40084563551/job120844716900, completed10:08:41Z. Actualpinnedfixture rebuild/committedbytes, humanGLBbrowserbothviewports, browseractorbothviewports steps succeed.

Eachactualjobmetadata andrunmetadata is retained. Rawjoblogdownload is retained byte-for-byte; its bytes exactlymatch a completewholejobentry in the independently downloaded fullrunZIP. EveryZIPCRCtest passes and eachentryhash is indexed. No replay, POST, dispatch, native/Blender/browser run, worktree/branch mutation, sourceedit or permissionrequest was performed.

AllTHREE actualcheckout logs explicitly sayrefs/remotes/pull/1260/merge and gitlog-1 SHA07058209d81b91ec19a9d871a0f9ca0c83079c9c. Theactualsyntheticmergeparents arec96846f15ba1dec54530f8056a347695616f38e9 and35f0H8. GitHubcheckmetadatahead_sha35f0 is distinctfrom theactualcheckout. FulluntruncatedrecursiveGitAPI trees andcommitmetadata are retained; treeresponses arelosslesslygzipcompressed with deterministicmtime0. Comparison includes every non-treeleaf SHA/type/mode, not justfilenamefilters.

ONLYtwo paths differ in the ENTIRErepo between H8 andactualcheckout: chicago/4d/changelog.d/T-3096.json is deleted, and chicago/4d/renderers/web/js/changelog.js changes. Everyotherleaf/source/runtime/assetbytes+mode agrees. The WHOLE4Dtree is NOTidentical: bothactual4DsubtreeSHAs andtheseexplicitdifferences are recorded. This is not relabelled as directH8checkout or a byte-identicalwhole4Dtree.

CI3SUCCESS remains separatefromroot’s freshnative1904Fullspawn4,666,158triangles againstunchanged4,600,000cap: thatactualbudgetFAIL persists. Freshstage14 isHELD andnotimpliedpassed bythisCI. This packet does not approve merge, productionpromotion, or anynew shadow/cullingcandidate. Originalbuildingimagegatesremainopen/DIFFERS. Sourceandrights limits areunchanged.
