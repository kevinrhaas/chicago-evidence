Five first-fort barrack ranges gain two-storey galleries and the tall/short opening patterns shown in Whistler’s folded elevations. Posts clear the explicit openings, chimney choices follow the visible counts, and two blockhouses lose separate invented domestic stacks. Five appearance grades recognize the identified whole-front drawings; dimensions, glazing, opening types and hidden chimney totals retain their declared uncertainties.

T-3119 renders the stated garden plants, while T-3120 supplies the independent woodland repair. The accompanying 1812 flora prerequisite renders the four declared Kinzie poplars and six Ouilmette currants without reducing collision clearance. Uniform Light/Full thinning completes the woodland sweep while preserving the 2,100/4,700 caps, stated plants, source densities, other scenes and Balanced detail.

Validation:

- Genuine pinned Blender 4.5.3 export and native web derivatives for all 25 fort-family masters. Seven intended models change; 18 defaults preserve geometry, normals, materials and confidence. Five known defaults have UV-only master variation; 13 default masters and all default web assets are byte-identical.
- Normal native rebuilding and protected population, 105 log/frame record, 210 asset and Hogan checks pass. Legacy constructor and gallery-clearance CPU checks pass, with a genuine no-write isolation measurement.
- Fourteen standard published app cases pass across mobile/desktop, normal/By Grade, contact/budget, review context, Photos credits and Sources. Actual screenshots were directly reviewed. Initial failures remain archived.
- Sixteen source comparisons were rendered and directly reviewed; every verdict remains DIFFERS. Original T-3041/T-2387 retain every picture and all 21 named plus nine context components.
- H9 parent integration and required-reader full preflight pass: 1,065 checks including 384 self-tests. The later native T-3106 split maps its independent no-bake demonstrations to T-3119 and T-3120. Only the three-item changelog and STATUS/ROADMAP mapping changed afterward; focused ticket/changelog checks and every code/data/asset guard pass. The exact full-gate tree and final metadata delta are recorded separately. Final committed-head changelog and ticket-ID checks also pass.

The native default views stand outside the pickets. A separate attempted courtyard ground view found an existing parade collision classification issue; it remains a preserved failed diagnostic. This increment neither repairs that routing issue nor claims on-foot courtyard access, full picture fidelity or original-ticket completion.

Built on merged PR #1260, dev 10ac7602e6ca0be8c197367c72d6d6c40fd76c4e. Its source matches the validated H9 parent; the two incoming changelog metadata changes are preserved. The three utility commits replay cleanly on dev, with all 63 validated own paths exact and focused published/changelog/ID/protected-input checks passing.

The first local preflight failed because its operational ticket-directory environment variable leaked into ticket fixtures. Those unintended ticket writes were reversed with a normal corrective commit and exact-tree readback. The isolated rerun uses unchanged assertions and no global ticket-directory override. The complete failed evidence remains archived.
