from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,tarfile
h=Path('/workspace/T2376-wagon-bay-followthrough-20261026');target=h/'before-published';packet=Path('/workspace/shared/T2376-wagonbay-before-cache-exact-20261026');archive=packet/'before-published-text-exact.tar.gz'
assert os.environ.get('GT_ROOT_ACK_PUBLIC_392')=='54f0b17f0f9290e406d7cbf63a6da3944772290b','Require actualrootdurability/clearanceACK, notelapsedtime'
status=json.loads((h/'app-desktop-after-only-20261026T1236-status.json').read_text());assert status['all_children_reaped'] and status['command_exit']==1
assert target.is_dir() and not target.is_symlink() and target.resolve()==Path('/workspace/T2376-wagon-bay-followthrough-20261026/before-published')
manifest=json.loads((packet/'BEFORE-PUBLISHED-MANIFEST.json').read_text());records={p:v for p,v in manifest['records'].items()if v['frozen_copy']};files={str(p.relative_to(target)):p for p in target.rglob('*')if p.is_file()};assert set(files)==set(records)
for rel,p in files.items():
 assert not p.is_symlink();b=p.read_bytes();v=records[rel];assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256'] and oct(stat.S_IMODE(p.stat().st_mode))==v['mode'],rel
verification=json.loads((packet/'ARCHIVE-VERIFICATION.json').read_text());assert archive.stat().st_size==verification['archive_bytes'] and hashlib.sha256(archive.read_bytes()).hexdigest()==verification['archive_sha256'];assert verification['all_archive_members_bytes_sha256_size_mode_exact'] and verification['inventory_member_set_exact']
verified=set()
with tarfile.open(archive,'r:gz')as tar:
 for member in tar:
  assert member.isfile() and member.name in records and member.name not in verified;v=records[member.name];b=tar.extractfile(member).read();assert member.size==len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256'] and oct(member.mode)==v['mode'];verified.add(member.name)
assert verified==set(records)
before=shutil.disk_usage(h).free;allocation=sum(p.stat().st_blocks*512 for p in files.values());shutil.rmtree(target);after=shutil.disk_usage(h).free;assert not target.exists() and archive.is_file()
proof={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ONLY_CLOSED_LOOSE_GENERATED_BEFORE_CACHE_REMOVED_AFTER_LOSSLESS_LOCAL_AND_PUBLIC_VERIFICATION','removed_exact_path':str(target),'verified_removed_file_count':len(verified),'file_allocated_bytes':allocation,'workspace_free_before':before,'workspace_free_after':after,'observed_free_gain':after-before,'local_lossless_archive_retained':str(archive),'archive_sha256':verification['archive_sha256'],'public_durable_index':392,'public_availability':'54f0b17f0f9290e406d7cbf63a6da3944772290b','public_verification':'Publisher independentlyreadall7immutableHTTPSchunks, concatenatedouterSHA andall4340nestedmembersSHA/size/mode. RootACKreceivedbeforeaction.','source_native_assets_authored_unique_evidence_removed':False,'metadata_exact_backup_retained':True,'binary_fallback_inventory_retained':len(manifest['records'])-len(records),'no_native_or_gate_or_PR_claim':True};(h/'LOOSE-BEFORE-CACHE-REMOVAL-RECEIPT.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
