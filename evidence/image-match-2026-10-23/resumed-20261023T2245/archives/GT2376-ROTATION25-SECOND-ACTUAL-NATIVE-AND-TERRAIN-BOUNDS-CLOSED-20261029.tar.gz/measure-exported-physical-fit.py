from pathlib import Path
import json,struct,array,math,hashlib,datetime
r=Path('/tmp/chicago-green-tree-integration/chicago/4d');h=Path('/workspace/T2376-annex-20261029');p=r/'assets/gltf/versions/green_tree_tavern/andreas-reading/green_tree_tavern__frame_1833.glb';raw=p.read_bytes();off=12;parts={}
while off<len(raw):
 n,k=struct.unpack_from('<II',raw,off);parts[k]=raw[off+8:off+8+n];off+=8+n
j=json.loads(parts[0x4e4f534a]);binary=parts[0x004e4942];assert all(not any(k in n for k in ['matrix','scale','translation','rotation'])for n in j['nodes'])
formats={5120:('b',1),5121:('B',1),5122:('h',2),5123:('H',2),5125:('I',4),5126:('f',4)};lanes={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def read(i):
 a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];f,s=formats[a['componentType']];n=lanes[a['type']];stride=v.get('byteStride',n*s);at=v.get('byteOffset',0)+a.get('byteOffset',0)
 return [struct.unpack_from('<'+f*n,binary,at+k*stride)for k in range(a['count'])]
feet={};vertices=triangles=0
for mesh in j['meshes']:
 for prim in mesh['primitives']:
  pos=read(prim['attributes']['POSITION']);indices=[x[0]for x in read(prim['indices'])];vertices+=len(pos);triangles+=len(indices)//3
  def edge(a,b):
   a,b=pos[a],pos[b]
   if abs(a[1])>.05 or abs(b[1])>.05:return
   steps=max(1,math.ceil(math.hypot(b[0]-a[0],b[2]-a[2])))
   for k in range(steps+1):
    x,z=a[0]+(b[0]-a[0])*k/steps,a[2]+(b[2]-a[2])*k/steps;feet.setdefault((math.floor(x/.5+.5),math.floor(z/.5+.5)),(x,-z))
  for i in range(0,len(indices),3):
   a,b,c=indices[i:i+3];edge(a,b);edge(b,c);edge(c,a)
sc=json.loads((r/'data/sidecars/1835/green_tree_tavern.json').read_text());place=sc['placement'];theta=math.radians(place['rotation_deg']);cs,sn=math.cos(theta),math.sin(theta)
def world(u,v):return place['local_e']+u*cs+v*sn,place['local_n']-u*sn+v*cs
meta=json.loads((r/'data/terrain/epochs/e1834_harbor_cut/heightfield.json').read_text());samples=array.array('h');samples.frombytes((r/'data/terrain/epochs/e1834_harbor_cut'/meta['bin']).read_bytes())
def H(e,n):
 x=max(0,min(meta['cols']-1,(e-meta['origin_e'])/meta['cell_m']));y=max(0,min(meta['rows']-1,(n-meta['origin_n'])/meta['cell_m']));a,b=math.floor(x),math.floor(y);tx,ty=x-a,y-b
 def at(i,k):return samples[k*meta['cols']+i]*meta['scale']+meta['offset']
 return (at(a,b)*(1-tx)+at(min(a+1,meta['cols']-1),b)*tx)*(1-ty)+(at(a,min(b+1,meta['rows']-1))*(1-tx)+at(min(a+1,meta['cols']-1),min(b+1,meta['rows']-1))*tx)*ty
heights=[H(*world(u,v))for u,v in feet.values()];base=min(H(*world(0,0)),*heights);record=json.loads((r/'data/structures/versions/green_tree_tavern/andreas-reading.json').read_text());annex=record['phases'][0]['form']['enclosed_left_annex']['value'];shoulder=annex['shoulder'];front=12.19-annex['front_setback_m'];back=front-shoulder['depth_m'];x0=7.62;x1=x0+shoulder['span_m'];rows=[]
for ob in json.loads((h/'ACTUAL-NATIVE-YARD-FULL-VERTICES.json').read_text())['objects']:
 axis=[[],[],[],[],[],[]]
 for u,v,z in ob['vertices']:
  roof=base+shoulder['roof_high_m']+(u-x0)*(shoulder['roof_low_m']-shoulder['roof_high_m'])/(x1-x0)
  for values,n in zip(axis,[u-x0,x1-u,v-back,front-v,z-base,roof-z]):values.append(n)
 margins=[min(v)for v in axis];rows.append({'id':ob['id'],'vertices':len(ob['vertices']),'minimum_face_margins_m':dict(zip(['host_wall','outer_wall','back_wall','front_wall','floor','roof'],margins)),'all_inside_closed_shoulder':min(margins)>=-1e-6})
result={'status':'ACTUAL_EXPORTED_MASTER_FEET_AND_FULL_NATIVE_YARD_WORLD_CONTAINMENT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'master_sha256':hashlib.sha256(raw).hexdigest(),'master_bytes':len(raw),'decoded_position_vertices':vertices,'triangles':triangles,'feet_cells':len(feet),'actual_master_base_y':base,'maximum_ground_relief_m':max(heights)-base,'yard_objects':rows,'foot_reader':'Exact JS addFeet rules on actual uncompressed native GLB positions/indices: abs(y)<=.05,1m edge sampling,.5m dedup; actual primitive order. Static untransformed single node verified. Real committed bilinear heightfield, origin included; independent yard world heights retained.','limits':'Master geometry only; actual published WEB decoding/instance matrix/terrain.surfaceHeight/walker/neighbor GLB appendages/shadow and source fit still require app/photo review.'}
(h/'rotation-native/EXPORTED-PHYSICAL-FIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
