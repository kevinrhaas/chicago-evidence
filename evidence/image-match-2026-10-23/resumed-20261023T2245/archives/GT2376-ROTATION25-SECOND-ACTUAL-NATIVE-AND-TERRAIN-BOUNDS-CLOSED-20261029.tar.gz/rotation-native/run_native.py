from pathlib import Path
import sys,json,hashlib,time,datetime
P=Path('/workspace/T2376-annex-20261029/rotation-native');A=Path('/tmp/chicago-green-tree-integration/chicago/4d');B=Path('/workspace/T2376-annex-20261029/native');sys.path.insert(0,str(A/'generators'));import build as production
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs=json.loads((B/'INPUTS.json').read_text());ids=sorted({json.loads(Path(e['record']).read_text())['id']for e in inputs['family']})
for n in ['frame_tavern.py','frame_tavern_params.py']:assert (A/'generators/archetypes'/n).read_bytes()==(P/'inputs'/n).read_bytes()
assert (A/'data/structures/versions/green_tree_tavern/andreas-reading.json').read_bytes()==(P/'inputs/andreas-reading.json').read_bytes()
saved=sys.argv[:];sys.argv=['blender','--','--only',','.join(ids),'--wrote',str(P/'PRODUCTION-WROTE.txt')];t=time.monotonic();code=production.main();sys.argv=saved;assert code==0;elapsed=time.monotonic()-t;rows=[]
for e in inputs['family']:
 m=Path(e['current_master']);assert (B/'old25'/e['asset']).read_bytes()==m.read_bytes(),e['asset'];assert sha(Path(e['record']))==e['record_sha256'];rows.append({'asset':e['asset'],'sha256':sha(m),'bytes':m.stat().st_size,'exact_current_and_actual_old_control':True})
dest=A/'assets/gltf/versions/green_tree_tavern/andreas-reading/green_tree_tavern__frame_1833.glb'
result={'status':'ACTUAL_OFFICIAL_23_FAMILY_IDS_AND_THREE_VERSIONS_ROTATION25_WITH_ALL25_DEFAULT_BYTES_EXACT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'production_seconds':elapsed,'rows':rows,'all25_default_bytes_equal_prior_actual_native_old25_and_current_committed':True,'candidate':{'path':str(dest),'bytes':dest.stat().st_size,'sha256':sha(dest)},'inputs':{n:sha(P/'inputs'/n)for n in ['frame_tavern.py','frame_tavern_params.py','andreas-reading.json']},'limits':'Selected WEB, new actual photo, full exported/app grounding, neighbor appendages and door approach still owed. Prior rejected neighbor-overlap trial retained separately.'};(P/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='rows'}),flush=True)
