"""Execute actual chimney producer functions without Blender; not a GLB/bake claim."""
from pathlib import Path
import ast,importlib.util,sys,json,math,dataclasses,hashlib
sys.dont_write_bytecode=True
root=Path('/workspace/chicago/chicago/4d');packet=Path('/tmp/miller-next-20261027')
def module(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=module('miller_old_params',root/'generators/archetypes/log_dwelling_params.py')
new=module('miller_new_params',packet/'candidate/generators/archetypes/log_dwelling_params.py')
class Capture:
 def __init__(self):self.boxes=[]
 def add_box(self,*a,**kw):self.boxes.append((tuple(a),kw))
 def add_poly(self,*a,**kw):pass
roof_tree=ast.parse((root/"generators/common/mesh.py").read_text());roof_cls=next(n for n in roof_tree.body if isinstance(n,ast.ClassDef) and n.name=="MeshBuilder");roof_method=next(n for n in roof_cls.body if isinstance(n,ast.FunctionDef) and n.name=="add_gable_roof");roof_env={"math":math};exec(compile(ast.fix_missing_locations(ast.Module(body=[roof_method],type_ignores=[])),"actual-add-gable-roof","exec"),roof_env);Capture.add_gable_roof=roof_env["add_gable_roof"]
def functions(path,pm):
 tree=ast.parse(path.read_text());names={'_gable_axis','_chimneys','_ridge_stack','_facade_stack_cross','_stack'}
 selected=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]+[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
 env={'math':math,'addition_extent':pm.addition_extent,'resolved_core_ridge_axis':pm.resolved_core_ridge_axis,'_STACK_HALF':.48,'_STACK_CLEAR':.04,'_DOOR_HALF':pm.DOOR_HALF_M,'_WIN_HALF':pm.WIN_HALF_M,'_WIN_AT':pm.WIN_AT_FRAC}
 exec(compile(ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[])),str(path),'exec'),env);return env
of=functions(root/'generators/archetypes/log_dwelling.py',old)
nf=functions(packet/'candidate/generators/archetypes/log_dwelling.py',new)
def draw(env,pm,p):
 xy=pm.core_extent(p);axis=pm.resolved_core_ridge_axis(p);span=(xy[3]-xy[1]) if axis=='x' else (xy[2]-xy[0]);ridge=Capture().add_gable_roof(*xy,p.wall_height_m,p.roof_pitch_deg,.5,ridge_along_x=axis=="x")
 add=None
 if p.frame_addition:
  a=pm.addition_extent(p);rx0=a[0]+.26 if p.frame_addition_side=='end' else a[0];add=Capture().add_gable_roof(rx0,a[1],a[2],a[3],p.addition_height_m,p.roof_pitch_deg,.5,ridge_along_x=True)
 b=Capture();env['_chimneys'](b,p,*xy,ridge,add,p.conf('chimneys','reconstructed'),9);return b.boxes
manifest=json.loads((root/'assets/manifest.json').read_text())['assets'];compared=[]
for file,entry in manifest.items():
 if entry.get('archetype')!='log_dwelling':continue
 r=json.loads((root/'data/structures'/f"{entry['structure_id']}.json").read_text());ph=next(p for p in r['phases'] if p['id']==entry['phase_id'])
 a=old.from_phase(ph,r);b=new.from_phase(ph,r)
 assert b.frame_addition_ridge_stack is None
 assert draw(of,old,a)==draw(nf,new,b),file
 compared.append(file)
r=json.loads((packet/'candidate/data/structures/miller_house.json').read_text());p=new.from_phase(r['phases'][0],r);oldr=json.loads((root/'data/structures/miller_house.json').read_text());op=old.from_phase(oldr['phases'][0],oldr)
before=draw(of,old,op);after=draw(nf,new,p)
assert len(before)==4 and len(after)==3
assert before[:2]==after[:2], 'core stack changed'
a=new.addition_extent(p);x0,y0,z0,x1,y1,z1,*rest=after[-1][0];ridge=Capture().add_gable_roof(*a,p.addition_height_m,p.roof_pitch_deg,.5,ridge_along_x=True)
assert math.isclose((x0+x1)/2,a[0]+.4*(a[2]-a[0]))
assert math.isclose((y0+y1)/2,(a[1]+a[3])/2)
assert math.isclose(x1-x0,.45) and math.isclose(y1-y0,.45)
assert z0<ridge and math.isclose(z1-ridge,.45)
# A core turned across the addition must not turn the addition's ridge stack.
p2=dataclasses.replace(p,roof_ridge_axis='y');p2.validate()
assert draw(nf,new,p2)[-1]==after[-1]
invalid=[(),(.4,.45),(.4,.45,.45,.2),(.4,float('nan'),.45),(.4,True,.45),(-.2,.45,.45),(.4,.2,.45),(.4,.45,2)]
for v in invalid:
 try:dataclasses.replace(p,frame_addition_ridge_stack=v).validate()
 except new.ParamError:pass
 else:raise AssertionError(('accepted invalid specification',v))
for change in [{'frame_addition':False},{'chimneys':1},{'chimney_ridge_at':(.3,.7)}]:
 try:dataclasses.replace(p,**change).validate()
 except new.ParamError:pass
 else:raise AssertionError(('accepted incompatible composition',change))
# Compilation only; no bpy import, mesh emission, export or check mutation.
for rel in ['generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py']:
 compile((packet/'candidate'/rel).read_text(),rel,'exec')
base=json.loads((packet/'BASE-INPUTS.json').read_text())['paths']
for rel,entry in base.items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==entry['sha256']
result={'status':'PASS','scope':'Actual native chimney-function box outputs; pure params. Not GLB, full-builder, bake, photo comparison or all-project gate.','default_all82_chimney_outputs_exact':len(compared),'rows':compared,'Miller_core_two_boxes_exact':True,'Miller_previous_addition_two_exterior_boxes_replaced_by_one_short_roof_stack':True,'addition_x_ridge_independent_of_core_axis':True,'actual_native_add_gable_roof_overhang_and_returned_ridge_used':True,'invalid_specs_rejected':len(invalid),'incompatible_compositions_rejected':3,'source_bound_inputs_unchanged':True,'before_boxes':before,'candidate_boxes':after}
(packet/'BRANCH-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['rows','before_boxes','candidate_boxes']},indent=2))
