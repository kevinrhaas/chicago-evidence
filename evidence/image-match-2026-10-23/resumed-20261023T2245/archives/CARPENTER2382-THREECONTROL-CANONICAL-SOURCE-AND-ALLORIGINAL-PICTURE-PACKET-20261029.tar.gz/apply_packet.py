"""Default: validate only. Source mutation needs a fresh root-owned source lease.

No asset, registry, recipe, match record, index, ref, claim or ticket is written.
"""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess

P = Path(__file__).resolve().parent
ap = argparse.ArgumentParser()
ap.add_argument('--repo', default='/workspace/chicago')
ap.add_argument('--expect-head', required=True)
ap.add_argument('--expect-lib-sha', required=True)
ap.add_argument('--apply-source', action='store_true')
a = ap.parse_args()
R = Path(a.repo).resolve()
plan = json.loads((P / 'PLAN.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
head = subprocess.check_output(['git', '-C', str(R), 'rev-parse', 'HEAD'], text=True).strip()
assert head == a.expect_head, 'Fresh expected HEAD differs'
assert shutil.disk_usage(R).free >= 536870912 + 8 * 1024**2
assert shutil.disk_usage('/tmp').free >= 1800000000
payloads = []
for row in plan['postimages']:
    target = R / row['repo_path']
    assert sha(target.read_bytes()) == row['before_sha256'], row['repo_path']
    body = (P / row['postimage']).read_bytes()
    assert sha(body) == row['after_sha256'], 'Packet postimage changed'
    payloads.append((target, body))
for row in plan['source_bindings']:
    assert sha((R / row['repo_path']).read_bytes()) == row['sha256'], row['repo_path']
lib = R / plan['liberties']['repo_path']
before = lib.read_bytes()
assert sha(before) == a.expect_lib_sha, 'Fresh Liberty preimage differs'
prefix = before[:plan['liberties']['head_prefix_bytes']]
assert sha(prefix) == plan['liberties']['head_prefix_sha256'], 'Liberty prefix needs a fresh rebind'
suffix = (P / plan['liberties']['append_file']).read_bytes()
assert sha(suffix) == plan['liberties']['append_sha256'], 'Packet suffix changed'
assert b"## T-2382 \xe2\x80\x94 Carpenter's former shop: low roof" not in before, 'Already appended'
payloads.append((lib, before + suffix))
print(json.dumps({'status': 'SCOPED_PREIMAGES_AND_FRESH_HEAD_VALIDATED', 'head': head,
                  'will_apply': a.apply_source,
                  'paths': [str(p.relative_to(R)) for p, _ in payloads]}, indent=2))
if a.apply_source:
    # All preconditions are checked before the first source replacement.
    for target, body in payloads:
        temporary = target.with_name(target.name + '.t2382-packet-tmp')
        assert not temporary.exists()
        mode = target.stat().st_mode & 0o777
        temporary.write_bytes(body)
        temporary.chmod(mode)
        os.replace(temporary, target)
    print('SOURCE_APPLIED_ONLY; current native production, actual capture and gates remain')
