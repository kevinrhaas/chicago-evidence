#!/usr/bin/env python3
"""Close a measured new-base audit, reusing exact old frozen input bytes."""
import argparse
import datetime
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = Path('/tmp/log82-wolf-site-audit-20261023T2358')
EXPECTED_OLD_MANIFEST_SHA = 'd0833ab85ac77b0ef02cdbbf7b85cf5e3c8a157b9018a70a5f905a0be182c632'
ROOT = Path('/tmp/chicago-log-integration/chicago/4d')


def sha(b):
    return hashlib.sha256(b).hexdigest()


def git(*args, check=True):
    return subprocess.run(['git', '-C', str(ROOT), *args], capture_output=True, check=check)


def context():
    merge = git('rev-parse', '--verify', 'MERGE_HEAD', check=False)
    return {'head': git('rev-parse', 'HEAD').stdout.decode().strip(),
            'index_stage_sha256': sha(git('ls-files', '--stage', '-z').stdout),
            'merge_head': merge.stdout.decode().strip() if merge.returncode == 0 else None}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tail-log', required=True, type=Path)
    parser.add_argument('--parent-session', required=True)
    parser.add_argument('--parent-exit', required=True, type=int)
    args = parser.parse_args()
    before_context = context()
    assert args.parent_exit == 0, 'Parent tail must have completed successfully'
    old_manifest = (OLD / 'MANIFEST.json').read_bytes()
    assert sha(old_manifest) == EXPECTED_OLD_MANIFEST_SHA
    for entry in json.loads(old_manifest)['files']:
        data = (OLD / entry['path']).read_bytes()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256'], entry['path']
    previous = json.loads((OLD / 'site-audit.json').read_bytes())
    current = json.loads((HERE / 'site-audit.json').read_bytes())
    assert current['git_head'] == before_context['head']
    old_inputs = {x['path']: x for x in previous['input_bindings']}
    new_inputs = {x['path']: x for x in current['input_bindings']}
    assert set(old_inputs) == set(new_inputs), 'Input scope changed; explicit review required'
    plan = []
    for path, entry in new_inputs.items():
        actual = (ROOT / path).read_bytes()
        assert sha(actual) == entry['sha256'] and len(actual) == entry['bytes'], path
        captured = HERE / 'inputs' / path
        assert captured.read_bytes() == actual
        reuse = old_inputs[path]['sha256'] == entry['sha256']
        if reuse:
            assert (OLD / 'inputs' / path).read_bytes() == actual
        plan.append({**entry, 'reuse_prior_frozen_input': reuse,
                     'storage': 'prior/inputs/' + path if reuse else 'changed-inputs/' + path})
    tail = args.tail_log.read_bytes()
    last_line = tail.decode('utf-8').splitlines()[-1]
    assert 'in manifest order' in last_line and 'last one moved nothing' in last_line, last_line
    assert 'derived layer rebuilt' in last_line
    after_context = context()
    assert after_context == before_context, 'HEAD/index/MERGE_HEAD changed during validation'
    exact_fields = [
        'occupied_body_local_enu_m', 'placement', 'native_entrance_total', 'native_buildings_total',
        'wolf_native_entries', 'actual_declared_entries', 'consumer_diagnostic', 'measurements',
        'current_native_objects_read', 'current_objects_or_fence_segments_inside_body',
        'current_objects_or_fence_segments_inside_actual_declared_doorway_zones',
        'old_four_comparison', 'current_wolf_trade_goods']
    comparison = {key: previous[key] == current[key] for key in exact_fields}
    assert current['native_entrance_total'] == 653 and len(current['wolf_native_entries']) == 2
    assert not current['current_objects_or_fence_segments_inside_body']
    assert not current['current_objects_or_fence_segments_inside_actual_declared_doorway_zones']
    assert all(e['native_apron_ring_exact_present'] for e in current['actual_declared_entries'])
    assert not any(e['same_instance_coordinate_in_current_output'] for e in current['old_four_comparison'])
    assert all(region['river_polygon']['disjoint'] and
               all(water['disjoint'] for water in region['all_native_water_outer_rings'].values()) and
               region['sampled_raw_terrain']['all_within_actual_heightfield']
               for region in current['measurements'].values())
    # Input validation and scope checks finish before changing our own storage.
    for entry in plan:
        path = HERE / 'inputs' / entry['path']
        if not entry['reuse_prior_frozen_input']:
            target = HERE / 'changed-inputs' / entry['path']
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(path), target)
    shutil.rmtree(HERE / 'inputs')
    (HERE / 'history/final-native-tail.log').write_bytes(tail)
    receipt = {'status': 'CLOSED_NEW_BASE_FIXED653_BOUNDED_SITE_REPLAY',
               'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'new_target_context': after_context,
               'prior_frozen_audit_manifest_sha256': EXPECTED_OLD_MANIFEST_SHA,
               'prior_frozen_audit_path': str(OLD), 'input_count': len(plan),
               'exact_inputs_reused': sum(e['reuse_prior_frozen_input'] for e in plan),
               'changed_inputs_stored': sum(not e['reuse_prior_frozen_input'] for e in plan),
               'all_compared_site_fields_exact': all(comparison.values()), 'site_field_comparison': comparison,
               'parent_tail': {'source': str(args.tail_log), 'sha256': sha(tail), 'bytes': len(tail),
                               'completion_marker': last_line, 'parent_session': args.parent_session,
                               'parent_reported_exit': args.parent_exit, 'audit_agent_reran_writers': False},
               'limits': 'Actual new-base source/data replay only: no canonical edits, fetch, native writer, Blender/browser or full gate. Exact inherited proofs are referenced by immutable manifest. 3D/app/fullgate/image-match acceptance remains owed.'}
    (HERE / 'input-reuse.json').write_text(json.dumps({'prior_manifest_sha256': EXPECTED_OLD_MANIFEST_SHA, 'inputs': plan}, indent=2) + '\n')
    (HERE / 'replay-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    m = current['measurements']
    body = m['occupied_body']['river_polygon']['distance_m']
    primary = m['wolf_point_tavern__door_1:apron']['river_polygon']['distance_m']
    side = m['wolf_point_tavern__side_xp_door_1:apron']['river_polygon']['distance_m']
    (HERE / 'README.md').write_text(
        '# T3081 site replay on the new parent base\n\n'
        f"Actual target HEAD `{after_context['head']}`, MERGE_HEAD `{after_context['merge_head']}`. "
        'The receipt also binds the complete staged-index fingerprint and the final parent-owned native tail. '
        'No canonical source or output was written by this review.\n\n'
        f"Reused {receipt['exact_inputs_reused']} exact inputs from the prior frozen audit; "
        f"stored {receipt['changed_inputs_stored']} changed inputs separately. "
        f"All compared site findings exact: {receipt['all_compared_site_fields_exact']}. "
        f"Prior manifest SHA `{EXPECTED_OLD_MANIFEST_SHA}`.\n\n"
        'Current native entrances: 653 on 651 buildings; both Wolf entries and exact native apron rings are present. '
        f"Current objects: {current['current_native_objects_read']}; zero body or either doorway-zone intrusions. "
        'All four historical intrusion coordinates remain absent.\n\n'
        f"River/west-bank model clearances: occupied body {body:.4f} m, primary apron {primary:.4f} m, "
        f"additional south-facing apron {side:.4f} m. All native water polygons remain disjoint. "
        'These are model diagnostics; the original roughly40m along-bank/20m across-bank uncertainty remains.\n\n'
        'The unchanged original reader generated `site-audit.json`. `input-reuse.json` identifies each exact archived input; '
        'the prior packet must be retained alongside this compact addendum. Changed bytes, if any, are under `changed-inputs/`. '
        'The parent completion log is copied under `history/`; no writer or full gate was rerun here.\n\n'
        'Actual 3D mesh/terrain/prop contact, published app review, walker behavior, full gates and original image matching '
        'are outside this bounded2D replay. Prior source/shoreline/tolerance/exemption limits remain unchanged.\n')
    print(json.dumps({'status': receipt['status'], 'reused_inputs': receipt['exact_inputs_reused'],
                      'changed_inputs': receipt['changed_inputs_stored'],
                      'all_site_fields_exact': receipt['all_compared_site_fields_exact']}))


if __name__ == '__main__':
    main()
