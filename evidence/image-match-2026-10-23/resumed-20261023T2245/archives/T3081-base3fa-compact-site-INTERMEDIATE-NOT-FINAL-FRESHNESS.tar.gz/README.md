# Intermediate T3081 site snapshot on the new parent base

Actual target HEAD `3fa6e0e84f84a33ccb8ac82c4778f6468af3b029`, MERGE_HEAD `ff808a22d50fedf5474d33535748286b71794c8e`. The receipt also binds the complete staged-index fingerprint and the final parent-owned native tail. No canonical source or output was written by this review.

Reused 69 exact inputs from the prior frozen audit; stored 1 changed inputs separately. All compared site findings exact: True. Prior manifest SHA `d0833ab85ac77b0ef02cdbbf7b85cf5e3c8a157b9018a70a5f905a0be182c632`.

Current native entrances: 653 on 651 buildings; both Wolf entries and exact native apron rings are present. Current objects: 3515; zero body or either doorway-zone intrusions. All four historical intrusion coordinates remain absent.

River/west-bank model clearances: occupied body 3.6879 m, primary apron 2.1746 m, additional south-facing apron 11.4517 m. All native water polygons remain disjoint. These are model diagnostics; the original roughly40m along-bank/20m across-bank uncertainty remains.

The unchanged original reader generated `site-audit.json`. `input-reuse.json` identifies each exact archived input; the prior packet must be retained alongside this compact addendum. Changed bytes, if any, are under `changed-inputs/`. The parent completion log is copied under `history/`; no writer or full gate was rerun here.

Actual 3D mesh/terrain/prop contact, published app review, walker behavior, full gates and original image matching are outside this bounded2D replay. Prior source/shoreline/tolerance/exemption limits remain unchanged.

Root subsequently confirmed the two changed sidecar fields are stale diagnostic metadata: scene compilation preceded the fresh capacity-model build. The measured sidecar says84m² while the fresh model says61.5m². This is not the V2 allocation basis. The00:20:36 geometry/site observations remain an actual snapshot, but this packet is explicitly NOT final freshness proof. Root is rerunning the native scene tail; a separate small final receipt must bind its completed output.
