from pathlib import Path
import subprocess,json,hashlib,datetime
root=Path('/tmp/hogan-pr1229-integration');app=root/'chicago/4d';r=Path('/workspace/T3126-runtime');base='305dc4e0663faf16870c11dab2ed49beb1df3b15';tree='cfb2a9c590b3b257fc845f35e07eb0d4208a40e7';branch='steward/t3126-dearborn-board-parapets-dev'
def call(args,cwd=root):return subprocess.check_output(args,cwd=cwd,stderr=subprocess.STDOUT)
def git(*args):return call(['git',*args]).decode().strip()
run=Path((r/'latest-preflight-run.path').read_text().strip());assert (run/'preflight.exit').read_text().strip()=='0';assert 'CHECK PASS' in (run/'check.log').read_text();assert '1065 steps, none red' in (run/'check.log').read_text();assert git('write-tree')==tree;assert git('rev-parse','HEAD')==base;assert git('diff','--name-only')=='';assert git('branch','--show-current')==branch
remote=call(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/dev','--jq','.object.sha']).decode().strip();assert remote==base
assert git('ls-remote','--heads','origin','refs/heads/'+branch)==''
message='T-3126: add Dearborn board parapets\n\nSelect pictured horizontal-board side infill with reconstructed sections.\nKeep the flat deck, original supports and original T-2375 image gate open.\nThe official comparison remains DIFFERS; native budgets are unchanged.\n'
(r/'final-commit-message.txt').write_text(message);print(call(['git','commit','--file',str(r/'final-commit-message.txt')]).decode(),flush=True)
head=git('rev-parse','HEAD');assert git('rev-parse','HEAD^{tree}')==tree;assert git('show','-s','--format=%P','HEAD')==base;assert git('status','--porcelain')==''
cl=call(['node','tools/check-changelog-entry.mjs',base,head],app);(r/'logs/final-head-changelog.log').write_bytes(cl);print(cl.decode(),flush=True)
ids=call(['node','tools/resolve_id_collisions.mjs','--base','origin/dev','--check'],app);(r/'logs/final-head-id-collisions.log').write_bytes(ids);print(ids.decode(),flush=True)
log=call(['git','push','--set-upstream','origin',branch]);(r/'logs/final-normal-push.log').write_bytes(log);print(log.decode(),flush=True)
assert git('ls-remote','--heads','origin','refs/heads/'+branch).split()[0]==head
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':head,'tree':tree,'single_parent':base,'branch':branch,'remote_exact_head_verified':True,'local_preflight':'PASS 1065 steps,384self-tests;626s;exit0','preflight_run':str(run),'new_head_changelog_and_id_checks':'PASS','normal_commit_and_push_no_force':True,'working_tree_clean':True,'full_published_smokes_and_target_CI':'PENDING_ROOT_DISPATCH_REVIEW','original_T2375':'OPEN/DIFFERS','far_pose_geometry_only_control':{'previous':3483153,'candidate':3494017,'limit':3470000,'increment':10864,'budgets_unchanged':True}}
(r/'FINAL-SOURCE-PUSH.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
