import crypto from 'node:crypto';
// Actual published Dearborn scene/card review. No content or API is injected.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire('/workspace/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const root='/tmp/hogan-pr1229-integration/site';
const out=path.resolve(new URL('./far-pose-geometry-only-control-v2/',import.meta.url).pathname);
fs.mkdirSync(out,{recursive:true});
const write=(name,v)=>fs.writeFileSync(path.join(out,name),typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon'};
const serverErrors=[];
const server=http.createServer((req,res)=>{
 try{
  let file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
  if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
  if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
  if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
  res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');
  const stream=fs.createReadStream(file);stream.on('error',e=>{serverErrors.push(e.message);res.destroy(e);});stream.pipe(res);
 }catch(e){serverErrors.push(e.message);res.writeHead(500).end();}
});
let browser;
const results=[];
const expected=JSON.parse(fs.readFileSync(new URL('./app-expected.json',import.meta.url),'utf8'));
async function settle(page){await page.locator('.navigator').evaluate(async n=>{getComputedStyle(n).width;await Promise.all(n.getAnimations().filter(a=>Number.isFinite(a.effect.getComputedTiming().endTime)).map(a=>a.finished));});}
async function pane(page,key){
 await page.locator(`#nav-app-inspect [data-insp-tab="${key}"]`).click();
 await page.waitForFunction(k=>document.querySelector(`#nav-app-inspect [data-insp-pane="${k}"]`)?.dataset.filled==='yes',key,{timeout:45000});
 await settle(page);
 return page.locator(`#nav-app-inspect [data-insp-pane="${key}"]`);
}
async function observe(page,target,label,key){
 const v=await target.evaluate(p=>({text:p.innerText,links:[...p.querySelectorAll('a')].filter(a=>a.checkVisibility()).map(a=>a.href),visible:p.checkVisibility(),pageOverflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1}));
 write(`${label}-${key}.json`,v);assert(v.visible);assert.equal(v.pageOverflow,false);assert.equal(v.paneOverflow,false);
 await page.screenshot({path:path.join(out,`${label}-${key}.png`)});return v;
}
const input=JSON.parse(fs.readFileSync(path.join(out,'expected-inputs.json'),'utf8'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function inventory(dir,prefix=''){
 const files=[];for(const d of fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const rel=prefix+d.name,p=path.join(dir,d.name);if(d.isDirectory())files.push(...inventory(p,rel+'/'));else if(d.isFile()){const body=fs.readFileSync(p);files.push({path:rel,bytes:body.length,sha256:sha(body)});}else if(d.isSymbolicLink())files.push({path:rel,symlink:fs.readlinkSync(p)});else throw Error('unexpected published object '+p);}return files;
}
const before=inventory(path.join(root,'4d'));write('published-before.json',before);
const priorCandidatePath=path.resolve(out,'../far-pose-geometry-only-control/candidate-measurement.json');
assert.deepEqual(before,JSON.parse(fs.readFileSync(path.resolve(out,'../far-pose-geometry-only-control/published-before.json'),'utf8')));
const paired=[JSON.parse(fs.readFileSync(priorCandidatePath,'utf8'))];write('candidate-reuse.json',{scope:'Reuse complete, valid candidate measurement from prior run; only subsequent optional UI resize aborted. No candidate resampling or accepted budget verdict inferred.',path:priorCandidatePath,sha256:sha(fs.readFileSync(priorCandidatePath)),publishedBytesExactToPriorInventory:true});
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 for(const label of ['abb-geometry-only']){
  const context=await browser.newContext({viewport:{width:1280,height:800},hasTouch:false,deviceScaleFactor:1});const errors=[],network=[],responses=[];let interceptions=0;
  try{
   await context.addInitScript(()=>localStorage.setItem('chicago4d.researcher','on'));
   if(label==='abb-geometry-only')await context.route('**/data/gltf/dearborn_street_drawbridge__draw_1834.glb*',async route=>{interceptions++;await route.fulfill({status:200,contentType:'model/gltf-binary',body:fs.readFileSync(path.join(out,'abb-target-web.glb'))});});
   const page=await context.newPage();page.setDefaultTimeout(90000);const pending=[];
   page.on('pageerror',e=>errors.push(e.message));page.on('requestfailed',r=>network.push({url:r.url(),failure:r.failure()}));page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});if(new URL(r.url()).pathname==='/4d/data/gltf/dearborn_street_drawbridge__draw_1834.glb')pending.push(r.body().then(b=>responses.push({url:r.url(),status:r.status(),bytes:b.length,sha256:sha(b)})));});
   await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835&keep-geometry=1`);
   await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:240000,polling:1000});
   const measured=await page.evaluate(async pose=>{
    const a=window.__chicago4d;const held=a.setAnimationHold(true);const until=Date.now()+90000;
    while(a.welcome?.state!=='world'&&Date.now()<until){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}
    if(a.welcome&&a.welcome.state!=='world')throw Error('welcome not world');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.navigator.dock();a.setConfidenceView(false);a.setFly(true);
    const surface=a.walker.surfaceAt(pose.eye.e,pose.eye.n);a.walker.teleport({local_e:pose.eye.e,local_n:pose.eye.n,yaw_deg:pose.yaw,pitch_deg:pose.pitch,altitude_m:pose.eye.y-surface});
    const readings=[];for(let i=0;i<3;i++){a.step();await a.capture(1);readings.push(a.stats());}
    const target=a.registry.get('dearborn_street_drawbridge');let triangles=0,meshes=0;target.gltf?.scene.traverse(o=>{if(o.isMesh){meshes++;triangles+=(o.geometry.index?.count??o.geometry.attributes.position.count)/3;}});
    return {detail:a.detail,heldBeforeWorldEntry:held,viewport:{width:innerWidth,height:innerHeight},state:{...a.walker.state},liveFly:{walker:a.walker.state.flying,hud:a.hud.flying,intent:a.intent.flying},camera:{position:a.camera.position.toArray(),quaternion:a.camera.quaternion.toArray(),projection:a.camera.projectionMatrix.toArray()},readings,target:{assetUrl:target.assetUrl,assetDetail:target.assetDetail,decodedTriangles:triangles,meshes,sidecar:target.sidecar},problems:a.problems??[]};
   },input.pose);
   await Promise.all(pending);assert(responses.length>=1);for(const response of responses){assert.equal(response.sha256,input[label].sha256);assert.equal(response.bytes,input[label].bytes);assert.equal(response.status,200);}
   if(label==='abb-geometry-only')assert(interceptions>=1);else assert.equal(interceptions,0);
   assert.equal(measured.detail,'full');assert.equal(measured.target.decodedTriangles,input[label].triangles);assert.equal(measured.heldBeforeWorldEntry,true);assert(Object.values(measured.liveFly).every(v=>v===true));assert.deepEqual(measured.viewport,{width:1280,height:800});
   assert.equal(measured.readings.at(-1).triangles,measured.readings.at(-2).triangles);assert.equal(measured.readings.at(-1).drawCalls,measured.readings.at(-2).drawCalls);assert.deepEqual(errors,[]);assert.deepEqual(network,[]);assert.deepEqual(serverErrors,[]);
   const result={label,scope:input.scope,pose:input.pose,measured,responses,interceptions,errors,network,withinOriginalBudget:measured.readings.at(-1).withinBudget};paired.push(result);write(label+'-measurement.json',result);
   await page.screenshot({path:path.join(out,label+'-same-far-pose.png')});console.log(label+': MEASURED '+measured.readings.at(-1).triangles+'/'+measured.readings.at(-1).budget.triangles+' triangles; original budget pass='+result.withinOriginalBudget);
   if(label==='candidate'){
    await page.setViewportSize({width:390,height:780});await settle(page);
    await page.evaluate(async()=>{const a=window.__chicago4d;a.pick('dearborn_street_drawbridge');await a.navigator.select('inspect');a.navigator.open(2);});
    await page.waitForFunction(()=>document.querySelector('#nav-app-inspect')?.dataset.structure==='dearborn_street_drawbridge');
    const sourcesPane=await pane(page,'sources');await sourcesPane.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});
    const credit=sourcesPane.locator('.cite-text').filter({hasText:'Braunhold'}).first();assert(await credit.count());await credit.evaluate(el=>el.scrollIntoView({block:'end'}));
    const evidence=await credit.evaluate(el=>{const text=el.firstChild,from=text.textContent.indexOf('Drawing signed');if(from<0)throw Error('signature clause absent');const range=document.createRange();range.setStart(text,from);range.setEnd(text,text.length);const r=range.getBoundingClientRect();let parent=el.parentElement;while(parent&&!(parent.scrollHeight>parent.clientHeight+1&&/(auto|scroll)/.test(getComputedStyle(parent).overflowY)))parent=parent.parentElement;const c=parent?.getBoundingClientRect();return {text:range.toString(),rect:{top:r.top,bottom:r.bottom,left:r.left,right:r.right},clip:c?{top:c.top,bottom:c.bottom}:null,note:'Actual current candidate desktop context resized to390x780 only for visible citation text. Supplements separate independent mobile app PASS, not another mobile geometry/budget gate.'};});
    assert.match(evidence.text,/L\. Braunhold, del\./);assert(evidence.rect.top>=Math.max(0,evidence.clip?.top??0)-2);assert(evidence.rect.bottom<=Math.min(780,evidence.clip?.bottom??780)+2);assert(evidence.rect.left>=-2&&evidence.rect.right<=392);write('mobile-resized-source-credit-range.json',evidence);await page.screenshot({path:path.join(out,'mobile-resized-source-credit.png')});assert.deepEqual(errors,[]);assert.deepEqual(network,[]);
   }
  }finally{await context.close();}
 }
 assert.deepEqual(paired[0].measured.camera,paired[1].measured.camera);assert.deepEqual(paired[0].measured.state,paired[1].measured.state);assert.deepEqual(paired[0].measured.target.sidecar,paired[1].measured.target.sidecar);
 const after=inventory(path.join(root,'4d'));assert.deepEqual(after,before);write('published-after-equal.json',{fileCount:after.length,inventorySha256:sha(Buffer.from(JSON.stringify(after))),identicalToBefore:true});
 write('result.json',{status:'MEASUREMENT_COMPLETE',candidateReusedFromCompletedPriorMeasurementWithByteExactPublishedInputs:true,subsequentPriorOptionalUIAbortRetained:true,scope:input.scope,publishedInputsExactBeforeAfter:true,identicalPoseDetailSidecarCameraAndFrozenAnimation:true,onlyOldTargetHttpResponseSubstituted:true,results:paired.map(p=>({label:p.label,served:p.responses,decodedTargetTriangles:p.measured.target.decodedTriangles,stats:p.measured.readings.at(-1),withinBudget:p.withinOriginalBudget})),candidateMinusBaselineTriangles:paired[0].measured.readings.at(-1).triangles-paired[1].measured.readings.at(-1).triangles,originalBroadCandidate3494017FailureRetained:true,nativeNamedStandsAndFullPublishedGateStillRequired:true});
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));server.closeAllConnections();}
