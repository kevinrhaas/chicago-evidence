from pathlib import Path
import json,subprocess,os
r=Path('/workspace/T3126-runtime');root=Path('/tmp/hogan-pr1229-integration');app=root/'chicago/4d';receipt=json.loads((r/'FINAL-SOURCE-PUSH.json').read_text());head=receipt['source_head'];branch=receipt['branch']
body=f'''Dearborn's open pole rail now has horizontal-board side infill following the credited Andreas engraving. The selector is keyword-only and opt-in; the closed deck, original supports, footprint, coordinates, dates and existing field grades remain unchanged. Board/cap sections and joints are explicitly reconstructed. The source record now credits L. Braunhold as draughtsman and corrects the omitted background features; the separate Baker-Co rights hold remains.

Original **T-2375 stays OPEN/DIFFERS**. This T-3126 utility completes only the board-parapet increment. The actual official comparison still differs in central rise, gallows/mechanism, supports/approaches, tone and context; the provisional camera reaches a principal-point bound.

Validation:

- Genuine pinned Blender4.5.3 six-family masters and native4.5.0 web derivatives; all six recipes fresh. Five default physical/material/confidence streams and all five default WEB bytes are unchanged. Four default master byte differences are unused UV layouts only. Legacy20-positional API is preserved.
- Native reader fixed point, workbook semantic parity/exact incoming-byte restoration and dependent package refresh; all non-bridge/Ames/K01 recipe rows preserved.
- Actual390×780 and1280×800 full/close normal/ByGrade, credited Images/Sources, Building Liberty and grounded2.22m deck contacts reviewed, with zero page/network/unexpected-loader errors. Mobile visible full-citation signature has its own actual supplement.
- Final required-reader preflight **PASS1065 steps, none red;384self-tests;exit0;626s**. Actual committed-head changelog and ID checks PASS. Commit tree exactly equals the preflight-tested tree.

Known diagnostic: the broad desktop Full Fly pose remains over the **unchanged3,470,000** triangle cap. Exact previous-WEB geometry-only control measured **3,483,153**, candidate **3,494,017**, an incremental **10,864** triangles at that pose (both5,781/7,800 calls). Only the target HTTP GLB differed; response hashes/live decoded counts, camera, detail, sidecar, frozen animation and all5,383 published file hashes were checked. This is not a whole-Abb-app PASS. Closer views are visual evidence, not a fix for that breach. Native named budget stands and full published coverage remain required; no caps, assertions or renderer code changed.

**Full exact-head published smoke matrix and target CI are PENDING root dispatch/review; do not merge until complete.** Source head `{head}`, parent `{receipt['single_parent']}`, tree `{receipt['tree']}`. The source head is frozen for those jobs.

[Official source comparison](https://github.com/kevinrhaas/chicago/blob/{head}/chicago/4d/docs/RESEARCH/photo-match/dearborn_street_drawbridge/T3126-board-parapets/andreas-provisional-official-side-by-side.jpg) · [source/limits](https://github.com/kevinrhaas/chicago/blob/{head}/chicago/4d/docs/RESEARCH/photo-match/dearborn_street_drawbridge/T3126-board-parapets/README.md) · [durable exports/app diagnostics](https://github.com/kevinrhaas/chicago-evidence/blob/24c3b9270aa49ab00cbdb110189e0e50c648b2cf/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md). The latter is an earlier bounded checkpoint; the completed baseline/supplement/final-gate addendum follows separately. Historical fixture/framing/credit/CSS and interrupted-no-verdict attempts remain preserved.
'''
# Keep plain spacing in the review prose; identifiers/hashes remain literal.
for a,b in [('Blender4.5.3','Blender 4.5.3'),('native4.5.0','native 4.5.0'),('Legacy20','Legacy 20'),('Actual390','Actual 390'),('grounded2.22m','grounded 2.22 m'),('PASS1065','PASS 1065'),('red;384','red; 384'),('self-tests;exit0;626s','self-tests; exit 0; 626 s'),('unchanged3,470,000','unchanged 3,470,000'),('both5,781','both 5,781'),('all5,383','all 5,383')]:body=body.replace(a,b)
(r/'PR-BODY.md').write_text(body);request={'title':'T-3126: add Dearborn board parapets','head':branch,'base':'dev','body':body,'draft':False};(r/'PR-CREATE.json').write_text(json.dumps(request,indent=2)+'\n')
raw=subprocess.check_output(['gh','api','--method','POST','repos/kevinrhaas/chicago/pulls','--input',str(r/'PR-CREATE.json')],cwd=root);(r/'PR-CREATE-RESPONSE.json').write_bytes(raw);pr=json.loads(raw);assert pr['head']['sha']==head and pr['base']['ref']=='dev';print(json.dumps({'number':pr['number'],'url':pr['html_url'],'head':head,'tree':receipt['tree'],'parent':receipt['single_parent']}),flush=True)
env=os.environ.copy();env.pop('CHICAGO_TICKETS_DIR',None)
for args,name in [(['node','tools/ticket.mjs','lap',str(pr['number']),'--by','Codex Dearborn board-parapet delivery'],'PR-LAP.txt'),(['node','tools/ticket.mjs','lap',str(pr['number']),'--status'],'PR-LAP-STATUS.txt')]:
 result=subprocess.run(args,cwd=app,env=env,capture_output=True);(r/name).write_bytes(result.stdout+result.stderr);print((result.stdout+result.stderr).decode(),flush=True);assert result.returncode==0
(r/'FINAL-PR-BINDING.json').write_text(json.dumps({'pr':pr['number'],'url':pr['html_url'],'head':head,'tree':receipt['tree'],'parent':receipt['single_parent'],'branch':branch,'own_lap_verified':True,'source_frozen':True,'full_exact_head_published_smokes_and_CI':'PENDING_ROOT_DISPATCH_REVIEW','original_T2375':'OPEN/DIFFERS'},indent=2)+'\n')
