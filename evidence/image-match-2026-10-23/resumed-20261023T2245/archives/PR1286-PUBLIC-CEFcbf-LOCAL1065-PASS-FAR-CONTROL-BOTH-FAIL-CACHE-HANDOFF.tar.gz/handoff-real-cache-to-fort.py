from pathlib import Path
import os,stat,json,hashlib,datetime
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
r=Path('/workspace/T3126-runtime');out=r/('cache-handoff-to-fort-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
source=Path('/tmp/hogan-pr1229-integration/site/4d');dest=Path('/tmp/chicago-log-integration/site/4d');alias=Path('/workspace/dearborn-board-published-20261024')
assert source.is_dir() and not source.is_symlink();assert not dest.exists() and not dest.is_symlink();assert dest.parent.is_dir();assert source.stat().st_dev==dest.parent.stat().st_dev;assert alias.is_symlink() and alias.resolve()==source.resolve()
def inventory(root):
 rows=[]
 for p in [root,*sorted(root.rglob('*'))]:
  s=p.lstat();row={'path':'.' if p==root else str(p.relative_to(root)),'inode':s.st_ino,'device':s.st_dev,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns}
  if stat.S_ISDIR(s.st_mode):row['kind']='directory'
  elif stat.S_ISREG(s.st_mode):row.update(kind='file',bytes=s.st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
  elif stat.S_ISLNK(s.st_mode):row.update(kind='symlink',target=os.readlink(p))
  else:raise AssertionError('unexpected object '+str(p))
  rows.append(row)
 return rows
before=inventory(source);(out/'before.json').write_text(json.dumps(before,indent=2)+'\n');old_alias=os.readlink(alias)
os.rename(source,dest)
temp=alias.with_name(alias.name+'.T3126-handoff-link');assert not temp.exists() and not temp.is_symlink();os.symlink(str(dest),temp);os.replace(temp,alias)
after=inventory(dest);assert before==after;assert not source.exists() and not source.is_symlink();assert dest.is_dir() and not dest.is_symlink();assert alias.resolve()==dest.resolve()
(out/'after.json').write_text(json.dumps(after,indent=2)+'\n')
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'operation':'AUTHORIZED EXCLUSIVE IGNORED REAL GENERATED CACHE HANDOFF, no source/asset deletion','from':str(source),'to':str(dest),'central_alias':str(alias),'old_alias_target':old_alias,'new_alias_target':os.readlink(alias),'rows':len(before),'regular_files':sum(x['kind']=='file' for x in before),'regular_bytes':sum(x.get('bytes',0) for x in before),'all_relative_paths_payload_SHA_inodes_devices_modes_owners_mtimes_exact':True,'source_SITE_absent':True,'destination_SITE_real_directory':True,'atomic_same_filesystem_rename':True,'source_head_frozen':'cefcbf15534f8cfa0b592faf4e4d7287109f0822','fort_acceptance_requires_own_native_publisher_refresh':True}
(out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');files=[]
for p in sorted(out.iterdir()):b=p.read_bytes();files.append({'path':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
m=out/'MANIFEST.json';m.write_text(json.dumps({'files':files},indent=2)+'\n');(r/'latest-cache-handoff.path').write_text(str(out)+'\n');print(json.dumps({'receipt':receipt,'manifest':str(m),'manifest_sha256':hashlib.sha256(m.read_bytes()).hexdigest()}))
