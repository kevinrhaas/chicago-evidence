// Actual published Dearborn scene/card review. No content or API is injected.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire('/workspace/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const root='/tmp/hogan-pr1229-integration/site';
const out=path.resolve(new URL('./source-credit-visible-qa/',import.meta.url).pathname);
fs.mkdirSync(out,{recursive:true});
const write=(name,v)=>fs.writeFileSync(path.join(out,name),typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon'};
const serverErrors=[];
const server=http.createServer((req,res)=>{
 try{
  let file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
  if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
  if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
  if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
  res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');
  const stream=fs.createReadStream(file);stream.on('error',e=>{serverErrors.push(e.message);res.destroy(e);});stream.pipe(res);
 }catch(e){serverErrors.push(e.message);res.writeHead(500).end();}
});
let browser;
const results=[];
const expected=JSON.parse(fs.readFileSync(new URL('./app-expected.json',import.meta.url),'utf8'));
async function settle(page){await page.locator('.navigator').evaluate(async n=>{for(let attempt=0;attempt<12;attempt++){getComputedStyle(n).width;const animations=n.getAnimations().filter(a=>Number.isFinite(a.effect.getComputedTiming().endTime)&&(a.playState==='running'||a.pending));if(!animations.length)return;const results=await Promise.allSettled(animations.map(a=>a.finished));for(const result of results)if(result.status==='rejected'&&result.reason?.name!=='AbortError')throw result.reason;}throw Error('finite navigator animations did not settle');});}
async function pane(page,key){
 await page.locator(`#nav-app-inspect [data-insp-tab="${key}"]`).click();
 await page.waitForFunction(k=>document.querySelector(`#nav-app-inspect [data-insp-pane="${k}"]`)?.dataset.filled==='yes',key,{timeout:45000});
 await settle(page);
 return page.locator(`#nav-app-inspect [data-insp-pane="${key}"]`);
}
async function observe(page,target,label,key){
 const v=await target.evaluate(p=>({text:p.innerText,links:[...p.querySelectorAll('a')].filter(a=>a.checkVisibility()).map(a=>a.href),visible:p.checkVisibility(),pageOverflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1}));
 write(`${label}-${key}.json`,v);assert(v.visible);assert.equal(v.pageOverflow,false);assert.equal(v.paneOverflow,false);
 await page.screenshot({path:path.join(out,`${label}-${key}.png`)});return v;
}
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 const context=await browser.newContext({viewport:{width:390,height:780},hasTouch:true,deviceScaleFactor:2});const errors=[],network=[];
 try{
  await context.addInitScript(()=>localStorage.setItem('chicago4d.researcher','on'));
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});});page.on('requestfailed',r=>network.push({url:r.url(),failure:r.failure()}));
  await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835&keep-geometry=1`);
  await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:240000,polling:1000});
  await page.evaluate(async()=>{const a=window.__chicago4d;const until=Date.now()+90000;while(a.welcome?.state!=='world'&&Date.now()<until){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}if(a.welcome&&a.welcome.state!=='world')throw Error('welcome not world');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.setAnimationHold(true);a.pick('dearborn_street_drawbridge');await a.navigator.select('inspect');a.navigator.open(2);});
  await page.waitForFunction(()=>document.querySelector('#nav-app-inspect')?.dataset.structure==='dearborn_street_drawbridge');
  for(const [label,width,height] of [['mobile',390,780]]){
   await page.setViewportSize({width,height});await settle(page);
   const sourcesPane=await pane(page,'sources');await sourcesPane.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});
   const cite=sourcesPane.locator('.cite-text').filter({hasText:'Braunhold'}).first();assert(await cite.count());
   await cite.evaluate(el=>el.scrollIntoView({block:'end'}));
   const evidence=await cite.evaluate(el=>{const text=el.firstChild;const from=text.textContent.indexOf('Drawing signed');if(from<0)throw Error('exact signature clause missing');const range=document.createRange();range.setStart(text,from);range.setEnd(text,text.length);const r=range.getBoundingClientRect();let parent=el.parentElement;while(parent&&!(parent.scrollHeight>parent.clientHeight+1&&/(auto|scroll)/.test(getComputedStyle(parent).overflowY)))parent=parent.parentElement;const clip=parent?.getBoundingClientRect();return {citation:el.textContent,visibleSignatureText:range.toString(),signatureRect:{x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom,right:r.right},scrollport:clip?{top:clip.top,bottom:clip.bottom,left:clip.left,right:clip.right}:null,viewport:{width:innerWidth,height:innerHeight},note:'Native source citation end scrolled into view; no text/style/API injected. One actual mobile boot plus desktop-size relayout, supplementing independent full app boots.'};});
   const r=evidence.signatureRect,c=evidence.scrollport;assert.match(evidence.visibleSignatureText,/L\. Braunhold, del\./);assert(r.y>=Math.max(0,c?.top??0)-2);assert(r.bottom<=Math.min(height,c?.bottom??height)+2);assert(r.x>=-2&&r.right<=width+2);assert.deepEqual(errors,[]);assert.deepEqual(network,[]);assert.deepEqual(serverErrors,[]);
   await page.screenshot({path:path.join(out,`${label}-full-source-credit.png`)});write(`${label}-credit.json`,evidence);console.log(`${label}: actual full citation signature clause visibly framed PASS`);
  }
  write('result.json',{status:'PASS',errors,network,serverErrors,scope:'Actual visible full-source credit supplement; no model/gate/source acceptance'});
 }finally{await context.close();}
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));server.closeAllConnections();}
