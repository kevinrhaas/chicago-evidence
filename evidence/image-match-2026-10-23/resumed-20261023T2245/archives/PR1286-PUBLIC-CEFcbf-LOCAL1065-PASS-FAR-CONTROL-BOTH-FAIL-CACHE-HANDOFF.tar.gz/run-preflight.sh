#!/usr/bin/env bash
set -uo pipefail
test "${T3126_HEAVY_GRANTED:-}" = 1 || exit 2
test "${T3126_MIRROR_LEASE:-}" = 1 || exit 2
unset CHICAGO_TICKETS_DIR
export PYTHONPATH="/workspace/shared/python${PYTHONPATH:+:$PYTHONPATH}"
export PATH="/workspace/shared/tools/usr/bin:$PATH"
export npm_config_cache=/workspace/shared/npm-cache
export CHECK_JOBS=4 C4D_GATE_REQUIRE_READERS=1
run=/workspace/T3126-runtime/preflight/$(date -u +%Y%m%dT%H%M%SZ)-$$
mkdir -p "$run/tmp"
export TMPDIR="$run/tmp"
export CHECK_TIMINGS="$run/check-timings.tsv"
python3 - <<'PY' || exit 2
import os,subprocess
assert 'CHICAGO_TICKETS_DIR' not in os.environ
assert os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize>=2*1024**3
assert subprocess.run(['git','-C',os.environ['TMPDIR'],'rev-parse','--show-toplevel'],capture_output=True).returncode!=0
PY
cd /tmp/hogan-pr1229-integration/chicago/4d || exit 2
printf '%s\n' "$run" > /workspace/T3126-runtime/latest-preflight-run.path
date -u +%Y-%m-%dT%H:%M:%SZ > "$run/start.txt"
git rev-parse HEAD > "$run/head-before.txt"
git diff --binary HEAD > "$run/working-before.patch"
./tools/preflight.sh > "$run/preflight.log" 2>&1
code=$?
printf '%s\n' "$code" > "$run/preflight.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$run/end.txt"
for name in check cl ids; do
 test ! -f "/tmp/preflight-$name.log" || cp "/tmp/preflight-$name.log" "$run/$name.log"
done
git rev-parse HEAD > "$run/head-after.txt"
git diff --binary HEAD > "$run/working-after.patch"
printf 'Closed preflight exit %s: %s\n' "$code" "$run"
exit "$code"
