"""Root-owned official family build; no population or native sidecar writers."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, subprocess, sys

ROOT = Path('/tmp/chicago-log-integration/chicago/4d')
OUT = Path(__file__).resolve().parent
BASELINE = json.loads((OUT / 'all82-before-assets.json').read_text())
GUARDS = json.loads((OUT / 'hogan-before-guards.json').read_text())
PINNED = Path('/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
ap = argparse.ArgumentParser()
ap.add_argument('phase', choices=['masters', 'web'])
args = ap.parse_args()
expected = {r['asset'] for r in BASELINE}
assert len(expected) == 82
manifest = ROOT / 'assets/manifest.json'
before_manifest = json.loads(manifest.read_text())
before_web_manifest = json.loads((ROOT / 'assets/manifest.web.json').read_text())
guarded = {p: sha(ROOT / p) for p in GUARDS}
for p, value in guarded.items():
    assert value == GUARDS[p]['sha256'], ('Hogan guard before run', p)
receipt = {'phase': args.phase, 'started': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
           'status': 'running', 'expected_assets': sorted(expected), 'population_writers': False}
receipt_path = OUT / f'official-{args.phase}-receipt.json'
def save():
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
save()
try:
    if args.phase == 'masters':
        assert subprocess.check_output([str(PINNED), '--version'], text=True).splitlines()[0] == 'Blender 4.5.3 LTS'
        ids = Path('/tmp/log81-adoption-20261023T2250/structure-ids-82.txt').read_text().strip()
        assert '\n' not in ids and len(ids.split(',')) == 82
        argv = [str(PINNED), '-b', '-noaudio', '--factory-startup', '--python', 'generators/build.py',
                '--', '--only', ids, '--wrote', str(OUT / 'written-masters.txt')]
    else:
        names = (OUT / 'written-masters.txt').read_text().splitlines()
        assert len(names) == 82 and set(names) == expected
        argv = ['bash', 'tools/web_derivatives.sh', '--only', ','.join(names)]
    receipt['command'] = argv
    save()
    with (OUT / f'official-{args.phase}.log').open('w') as log:
        completed = subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'npm_config_cache': '/workspace/shared/npm-cache'})
    receipt['exit_code'] = completed.returncode
    assert completed.returncode == 0, 'Official producer failed; inspect its preserved log'
    names = (OUT / 'written-masters.txt').read_text().splitlines()
    assert len(names) == 82 and set(names) == expected, 'Unexpected family scope'
    for p, old in guarded.items():
        assert sha(ROOT / p) == old, ('Hogan bytes changed; STOP and investigate, no restoration', p)
    after_manifest = json.loads(manifest.read_text())
    unrelated = {k: v for k, v in before_manifest['assets'].items() if k not in expected}
    assert {k: v for k, v in after_manifest['assets'].items() if k not in expected} == unrelated
    if args.phase == 'web':
        after_web = json.loads((ROOT / 'assets/manifest.web.json').read_text())
        old_unrelated_web = {k: v for k, v in before_web_manifest['masters'].items() if k not in expected}
        assert {k: v for k, v in after_web['masters'].items() if k not in expected} == old_unrelated_web
    kind = 'gltf' if args.phase == 'masters' else 'web'
    changed = []
    for r in BASELINE:
        p = ROOT / 'assets' / kind / r['asset']
        if sha(p) != r[kind]['sha256']:
            changed.append(r['asset'])
    targets = {'chappel_infant_school', 'cobweb_castle', 'miller_house',
               'philo_carpenter_log_shop', 'wolf_point_tavern'}
    changed_ids = {r['structure_id'] for r in BASELINE if r['asset'] in changed}
    unexpected = changed_ids - targets
    if unexpected:
        # Explicitly reviewed exporter-only exception, with actual old/new official controls.
        assert args.phase == 'web' and unexpected == {'kinzie_stable_1812'}
        expected_uv_sha = '9a0bd88ee3ab69910f4afb7f52c1082184d67994f0e97116632c3391cfbaa84f'
        assert sha(ROOT / 'assets/gltf/kinzie_stable_1812__kinzie_1804.glb') == expected_uv_sha
        controls = json.loads((OUT / 'kinzie-uv-control/receipt.json').read_text())
        assert len(controls) == 2 and all(r['sha256'] == expected_uv_sha for r in controls)
        assert json.loads((OUT / 'master-review.json').read_text())['status'] == 'PASS'
        receipt['reviewed_uv_only_default_asset'] = 'kinzie_stable_1812'
    receipt.update(status='PASS', changed_asset_bytes=changed, unchanged_asset_bytes=82-len(changed),
                   hogan_four_guards_exact=True, unrelated_master_manifest_entries_exact=True,
                   finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    print(json.dumps(receipt, indent=2))
except BaseException as exc:
    receipt.update(status='FAILED', error=str(exc))
    save()
    raise
