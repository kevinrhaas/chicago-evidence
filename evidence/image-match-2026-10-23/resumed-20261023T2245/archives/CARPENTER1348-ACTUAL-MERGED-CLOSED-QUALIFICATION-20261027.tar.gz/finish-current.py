from pathlib import Path
import subprocess,json,os,datetime,re,time
r=Path('/tmp/jail-picture-c6');app=r/'chicago/4d';root=Path(__file__).parent;o=root/'final-ending';o.mkdir();env=dict(os.environ);n=int(env.get('GIT_CONFIG_COUNT','0'))
for k,v in [('gc.auto','0'),('maintenance.auto','false')]:env['GIT_CONFIG_KEY_'+str(n)]=k;env['GIT_CONFIG_VALUE_'+str(n)]=v;n+=1
env['GIT_CONFIG_COUNT']=str(n);env['NPM_CONFIG_PREFIX']='/tmp/T2382-runtime-prefix'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git',*a],cwd=r,env=env,text=True).strip()
def api(path):return json.loads(subprocess.check_output(['gh','api',path],env=env))
def save(n,d):(o/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def run(n,cmd,cwd=app):
 with (o/(n+'.log')).open('x') as f:code=subprocess.call(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert code==0,(n,code)
cur=root/'current-Jones403';native=json.loads((cur/'RESULT.json').read_text());nr=json.loads((cur/'reaper.json').read_text());phone=json.loads((cur/'current-phone-reaper.json').read_text());scope=json.loads((cur/'CARD-INPUT-EQUALITY.json').read_text());cards=json.loads((root/'CARD-RESULT.json').read_text());assert native['status']=='CURRENT_JONES403_AFFECTED_NATIVE_ALL44_PUBLISH_PASS' and nr['command_exit']==0 and nr['all_children_reaped'];assert phone['command_exit']==0 and phone['all_children_reaped'] and scope['status']=='PASSED_BOTH_CARD_INPUTS_EXACT_AND_CURRENT_SCOPE_PASS' and cards['status']=='PASS'
log=(cur/'current-phone.log').read_text();reading=re.search(r'ok /1904/ mobile: ([0-9.]+) MB against a ceiling of ([0-9.]+) MB',log);assert reading;actual,cap=map(float,reading.groups());assert cap==400 and actual<=cap
base=native['incoming'];tree=native['tree'];assert git('rev-parse','HEAD')==native['head'] and git('rev-parse','MERGE_HEAD')==base and git('write-tree')==tree;assert not git('diff','--no-renames','--name-only') and not git('ls-files','-u') and not git('ls-files','--others','--exclude-standard');assert api('repos/kevinrhaas/chicago/git/ref/heads/dev')['object']['sha']==base
save('BEFORE.json',{'at':now(),'head':native['head'],'incoming':base,'checked_tree':tree,'phone_MiB':actual,'cap_MiB':cap,'cards':'Both passed on exact unchanged target inputs','scope':'All identified current requirements closed; normal source-identical checked commit/publicFF/standard expected-head merge follow.'})
run('01-pending-changelog',['node','tools/check-changelog-entry.mjs',git('merge-base',base,'HEAD'),'HEAD']);run('02-pending-ids',['node','tools/resolve_id_collisions.mjs','--base',base,'--check']);run('03-checked-normal-merge-commit',['git','commit','-m',"T-2382: carry the qualified Jones development update"],r);head=git('rev-parse','HEAD');assert git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain')
for name,cmd in [('04-committed-changelog',['node','tools/check-changelog-entry.mjs',base,'HEAD']),('05-committed-ids',['node','tools/resolve_id_collisions.mjs','--base',base,'--check']),('06-current-history',['node','tools/check-changelog.mjs'])]:run(name,cmd)
pr=api('repos/kevinrhaas/chicago/pulls/1348');assert pr['base']['ref']=='dev' and pr['head']['repo']['full_name']=='kevinrhaas/chicago';assert pr['head']['sha']==native['head'];ref=pr['head']['ref'];assert ref not in ['main','dev'];run('07-normal-public-FF',['git','push','origin','HEAD:refs/heads/'+ref],r)
for _ in range(12):
 pr=api('repos/kevinrhaas/chicago/pulls/1348')
 if pr['head']['sha']==head:break
 time.sleep(.5)
assert pr['head']['sha']==head
body=f"""Carpenter’s log annex now shows the dark doorway in the Andreas engraving through the existing 0.30 m blind recess. Its Images card displays the credited reproduction and counts its library/source aliases once. The depth is reconstructed; the doorway retains its size and position. The signed surname is Braunhold; the given initial remains unresolved.

The compound camera remains diagnostic-only. Original **T-2382 stays OPEN / DIFFERS**, with the broader annex/hotel massing and camera gaps recorded in its existing match register.

Validation: the checked pre-Walker source passed all three native questions (1,077 steps / 388 self-tests). The subsequent Walker and Jones development integrations passed their changed kit/default-geometry, complete schema/staleness, scene/source-use, manifest, rights, all 44 binary and publication checks. The current 1904 phone reads **{actual:.1f} / 400 MiB**. Actual mobile AND desktop Photos/Sources/Research reviews pass with one loaded credited picture, singular grade wording, expected WEB bytes and no page/request errors; exact target/input comparisons carry those reviews through the disjoint Jones update. Earlier f311 body/ground reviews retain their dates and source bindings.

Checked head `{head}`, tree `{tree}`. [Recovery and validation record](https://github.com/kevinrhaas/chicago-evidence/blob/main/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md). This PR targets `dev`.
"""
request=o/'PR-BODY-REQUEST.json';request.write_text(json.dumps({'body':body},ensure_ascii=False)+'\n')
with (o/'PR-BODY-RESPONSE.json').open('x') as f:subprocess.run(['gh','api','--method','PATCH','repos/kevinrhaas/chicago/pulls/1348','--input',str(request)],env=env,stdout=f,check=True)
if pr['draft']:
 q=o/'READY.graphql';q.write_text('mutation($id:ID!){markPullRequestReadyForReview(input:{pullRequestId:$id}){pullRequest{isDraft}}}')
 with (o/'READY-RESPONSE.json').open('x') as f:subprocess.run(['gh','api','graphql','-f','query='+q.read_text(),'-f','id='+pr['node_id']],env=env,stdout=f,check=True)
assert api('repos/kevinrhaas/chicago/git/ref/heads/dev')['object']['sha']==base
merge_request=o/'MERGE-REQUEST.json';merge_request.write_text(json.dumps({'sha':head,'merge_method':'merge','commit_title':"T-2382: Carpenter's dark doorway and credited picture (#1348)"})+'\n')
response=subprocess.run(['gh','api','--method','PUT','repos/kevinrhaas/chicago/pulls/1348/merge','--input',str(merge_request)],env=env,text=True,capture_output=True);(o/'MERGE-RESPONSE.txt').write_text(response.stdout+'\n'+response.stderr);assert response.returncode==0,('Standard merge service rejected; no override',response.stdout,response.stderr);merged=json.loads(response.stdout);assert merged.get('merged') is True,merged
commit=api('repos/kevinrhaas/chicago/git/commits/'+merged['sha']);parents=[x['sha'] for x in commit['parents']];assert commit['tree']['sha']==tree and parents==[base,head],commit
result={'status':'ACTUAL_STANDARD_EXPECTED_HEAD_DEV_MERGE_VERIFIED','at':now(),'PR':1348,'url':'https://github.com/kevinrhaas/chicago/pull/1348','checked_author_head':head,'checked_tree':tree,'actual_merge_commit':merged['sha'],'actual_merge_tree':commit['tree']['sha'],'actual_parents':parents,'current_phone_MiB':actual,'unchanged_Light_cap_MiB':400,'both_target_card_reviews':'PASS, exact inputs carried from dfcbf','normal_FF_no_force':True,'admin_or_protection_override':False,'original_T2382':'OPEN / DIFFERS','pending':'Release only exact self lap; publish finite closed qualification/merge receipts; owner-safe inactive ignored mirror cleanup after public source checkpoint. No app main promotion.'};save('RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
