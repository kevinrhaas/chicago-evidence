from pathlib import Path
import os,subprocess,json,hashlib,datetime,shutil,gzip,zipfile,io
import xml.etree.ElementTree as ET
r=Path('/tmp/jail-picture-c6');app=r/'chicago/4d';o=Path(__file__).parent;env=dict(os.environ);n=int(env.get('GIT_CONFIG_COUNT','0'))
for k,v in [('gc.auto','0'),('maintenance.auto','false')]:env['GIT_CONFIG_KEY_'+str(n)]=k;env['GIT_CONFIG_VALUE_'+str(n)]=v;n+=1
env['GIT_CONFIG_COUNT']=str(n);env.update(NPM_CONFIG_PREFIX='/tmp/T2382-runtime-prefix',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',C4D_RULINGS_BASE='dfcbf765bc2ffb680e8efeefd1d125b9444dbfab',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',GITHUB_BASE_REF='dev');os.sched_setaffinity(0,{0,1,3,4})
def git(*a):return subprocess.check_output(['git',*a],cwd=r,env=env,text=True).strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def save(n,d):(o/n).write_text(json.dumps(d,indent=2)+'\n')
head=git('rev-parse','HEAD');tip=git('rev-parse','MERGE_HEAD');assert head=='32701e53b061eabb9728498d6d448b84ca9af2eb' and tip=='dfcbf765bc2ffb680e8efeefd1d125b9444dbfab';old=json.loads((o.parent/'BEFORE-NATIVE.json').read_text());paths=set(p for p in old['protected'] if (r/p).is_file());names=git('ls-files').splitlines();paths.update(p for p in names if p.startswith(('chicago/4d/assets/gltf/','chicago/4d/assets/web/','chicago/4d/data/structures/','chicago/4d/data/reference_views/','chicago/4d/data/sources/','chicago/4d/generators/','chicago/4d/data/components/')) and (r/p).is_file());paths.add('chicago/4d/tools/check_timber_kit.py');protected={p:{'bytes':(r/p).stat().st_size,'sha256':sha(r/p)} for p in sorted(paths)};binaries=old['binary_paths'];baseline=o/'binary-baseline';baseline.mkdir()
for p in binaries:q=baseline/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/p,q)
models=[p for p in paths if p.endswith('.glb')];binding={'at':now(),'head':head,'true_merge_head':tip,'dated_e5b9_full3_tree':'03094a09eb9e7f0d802f02deb4a92bb525549b6f','protected':protected,'models':models,'binary_paths':binaries,'scope':'Actual incomingWalkerK16feature+genuinefold on alreadychecked/publicC6. Directexistingnativeowners resolve twoowned conflicts; actualaffectedquestions/defaultsample geometry/all44/freshness/pub beforecurrentphone/cards. Earlier1077e5full3 remainsdated, neverrelabeled.'};save('BEFORE-AFFECTED.json',binding);steps=[]
def run(label,cmd):
 print('START',label,now(),flush=True);start=now()
 with (o/(label+'.log')).open('x') as f:code=subprocess.call(cmd,cwd=app,env=env,stdout=f,stderr=subprocess.STDOUT)
 steps.append({'name':label,'command':cmd,'started':start,'finished':now(),'exit':code});save('STEPS.json',steps);print('CLOSED',label,code,now(),flush=True);assert code==0,(label,code)
for label,cmd in [('owner-liberties',['python3','tools/compile_liberties.py']),('owner-scene',['python3','tools/compile_scene.py','--all']),('owner-entrances',['python3','tools/generate_entrances.py']),('owner-builtwalk',['python3','tools/jaunt_built_so_far.py']),('owner-jaunts',['python3','tools/compile_jaunts.py']),('owner-source-use',['python3','tools/compile_source_use.py'])]:run(label,cmd)
subprocess.run(['git','add','--','chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/docs/measurements/source_use_coverage.md'],cwd=r,env=env,check=True);assert not git('ls-files','-u')
for label,cmd in [('changed-K16-kit',['python3','tools/check_timber_kit.py','--check']),('changed-K16-selftests',['python3','tools/check_timber_kit.py','--self-test']),('all-records-stale',['python3','tools/validate.py','--all','--strict','--stale']),('all-scene-native',['python3','tools/compile_scene.py','--all','--check']),('liberties-native',['python3','tools/compile_liberties.py','--check']),('source-use-native',['python3','tools/compile_source_use.py','--check']),('manifest-native',['node','tools/rederive.mjs','--check']),('rights-native',['python3','tools/measure_rights_derivation.py','--gate','--quiet']),('package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'])]:run(label,cmd)
def xml(n):return (n.tag,tuple(sorted(n.attrib.items())),n.text if n.text is not None and (n.text.strip() or not len(n)) else None,n.tail if n.tail and n.tail.strip() else None,tuple(xml(c) for c in n))
def equal(a,b,p):
 if p.endswith('.gz'):return gzip.decompress(a)==gzip.decompress(b)
 with zipfile.ZipFile(io.BytesIO(a)) as aa,zipfile.ZipFile(io.BytesIO(b)) as bb:
  if sorted(aa.namelist())!=sorted(bb.namelist()):return False
  return all((xml(ET.fromstring(aa.read(n)))==xml(ET.fromstring(bb.read(n)))) if n.endswith(('.xml','.rels')) else aa.read(n)==bb.read(n) for n in aa.namelist())
rows=[];restore={}
for p in binaries:
 a=(baseline/p).read_bytes();b=(r/p).read_bytes();row={'path':p,'baseline_sha256':hashlib.sha256(a).hexdigest(),'generated_sha256':hashlib.sha256(b).hexdigest(),'byte_equal':a==b}
 if a!=b:
  q=o/'raw-generated-serialization'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);row['semantic_equal']=equal(a,b,p);row['raw_saved']=str(q)
  if row['semantic_equal']:restore[p]=a
 rows.append(row)
changed=[p for p,v in protected.items() if sha(r/p)!=v['sha256']];audit={'status':'PASS' if not changed and all(x.get('semantic_equal',True) for x in rows) else 'ACTUAL_FAILURE_RETAINED','at':now(),'protected_count':len(protected),'model_count':len(models),'changed_protected':changed,'all44_count':len(rows),'records':rows,'serialization_only_restored':[]};save('ALL44-AND-INPUTS.json',audit);assert audit['status']=='PASS',changed
for p,b in restore.items():(r/p).write_bytes(b);subprocess.run(['git','add','--',p],cwd=r,env=env,check=True)
audit['serialization_only_restored']=list(restore);save('ALL44-AND-INPUTS.json',audit)
run('publish',['bash','tools/publish.sh']);assert all(sha(r/p)==v['sha256'] for p,v in protected.items());subprocess.run(['git','add','-u'],cwd=r,env=env,check=True);assert not git('diff','--no-renames','--name-only') and not git('ls-files','--others','--exclude-standard')
for sid,pic in [('philo_carpenter_log_shop','early-andreas-1884-sauganash'),('st_marys_church','early-moss-1884-st-marys')]:assert json.loads((app/f'data/sidecars/1835/{sid}.json').read_text())['grade']['pictures']==[pic]
result={'status':'CURRENT_DFCBF_AFFECTED_NATIVE_ALL44_PUBLISH_PASS','at':now(),'head':head,'incoming':tip,'tree':git('write-tree'),'steps':steps,'all_source_models_protected':len(protected),'all44_pass':True,'scope':'ActualaffectedcurrentK16/globalmetadata/defaultsamples/freshness/rights/ownership/package/publication pass. Actuale5full3 staysdated1077/388. Current1904phone400cap and BOTHcardreview pluscheckednormalcommit/publicFF/DEVmerge remainpending.'};save('RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
