from pathlib import Path
import os,subprocess,json,hashlib,datetime,shutil,gzip,zipfile,io
import xml.etree.ElementTree as ET
r=Path('/tmp/jail-picture-c6');app=r/'chicago/4d';o=Path(__file__).parent;env=dict(os.environ);n=int(env.get('GIT_CONFIG_COUNT','0'))
for k,v in [('gc.auto','0'),('maintenance.auto','false')]:env['GIT_CONFIG_KEY_'+str(n)]=k;env['GIT_CONFIG_VALUE_'+str(n)]=v;n+=1
env['GIT_CONFIG_COUNT']=str(n);env.update(NPM_CONFIG_PREFIX='/tmp/T2382-runtime-prefix',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',C4D_RULINGS_BASE='dfcbf765bc2ffb680e8efeefd1d125b9444dbfab',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',GITHUB_BASE_REF='dev');os.sched_setaffinity(0,{0,1,3,4})
def git(*a):return subprocess.check_output(['git',*a],cwd=r,env=env,text=True).strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def save(n,d):(o/n).write_text(json.dumps(d,indent=2)+'\n')
binding=json.loads((o/'BEFORE-AFFECTED.json').read_text());head=binding['head'];tip=binding['true_merge_head'];protected=binding['protected'];binaries=binding['binary_paths'];models=binding['models'];baseline=o/'binary-baseline';assert git('rev-parse','HEAD')==head and git('rev-parse','MERGE_HEAD')==tip and not git('ls-files','-u');assert all(sha(r/p)==v['sha256'] for p,v in protected.items());steps=json.loads((o/'STEPS.json').read_text())[:-1]
def run(label,cmd):
 print('START',label,now(),flush=True);start=now()
 with (o/(label+'.log')).open('x') as f:code=subprocess.call(cmd,cwd=app,env=env,stdout=f,stderr=subprocess.STDOUT)
 steps.append({'name':label,'command':cmd,'started':start,'finished':now(),'exit':code});save('STEPS.json',steps);print('CLOSED',label,code,now(),flush=True);assert code==0,(label,code)
for label,cmd in [('all-records-native',['python3','tools/validate.py','--all']),('all-scene-native',['python3','tools/compile_scene.py','--all','--check']),('liberties-native',['python3','tools/compile_liberties.py','--check']),('source-use-native',['python3','tools/compile_source_use.py','--check']),('manifest-native',['node','tools/rederive.mjs','--check']),('rights-native',['python3','tools/measure_rights_derivation.py','--gate','--quiet']),('package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'])]:run(label,cmd)
def xml(n):return (n.tag,tuple(sorted(n.attrib.items())),n.text if n.text is not None and (n.text.strip() or not len(n)) else None,n.tail if n.tail and n.tail.strip() else None,tuple(xml(c) for c in n))
def equal(a,b,p):
 if p.endswith('.gz'):return gzip.decompress(a)==gzip.decompress(b)
 with zipfile.ZipFile(io.BytesIO(a)) as aa,zipfile.ZipFile(io.BytesIO(b)) as bb:
  if sorted(aa.namelist())!=sorted(bb.namelist()):return False
  return all((xml(ET.fromstring(aa.read(n)))==xml(ET.fromstring(bb.read(n)))) if n.endswith(('.xml','.rels')) else aa.read(n)==bb.read(n) for n in aa.namelist())
rows=[];restore={}
for p in binaries:
 a=(baseline/p).read_bytes();b=(r/p).read_bytes();row={'path':p,'baseline_sha256':hashlib.sha256(a).hexdigest(),'generated_sha256':hashlib.sha256(b).hexdigest(),'byte_equal':a==b}
 if a!=b:
  q=o/'raw-generated-serialization'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);row['semantic_equal']=equal(a,b,p);row['raw_saved']=str(q)
  if row['semantic_equal']:restore[p]=a
 rows.append(row)
changed=[p for p,v in protected.items() if sha(r/p)!=v['sha256']];audit={'status':'PASS' if not changed and all(x.get('semantic_equal',True) for x in rows) else 'ACTUAL_FAILURE_RETAINED','at':now(),'protected_count':len(protected),'model_count':len(models),'changed_protected':changed,'all44_count':len(rows),'records':rows,'serialization_only_restored':[]};save('ALL44-AND-INPUTS.json',audit);assert audit['status']=='PASS',changed
for p,b in restore.items():(r/p).write_bytes(b);subprocess.run(['git','add','--',p],cwd=r,env=env,check=True)
audit['serialization_only_restored']=list(restore);save('ALL44-AND-INPUTS.json',audit)
run('publish',['bash','tools/publish.sh']);assert all(sha(r/p)==v['sha256'] for p,v in protected.items());subprocess.run(['git','add','-u'],cwd=r,env=env,check=True);assert not git('diff','--no-renames','--name-only') and not git('ls-files','--others','--exclude-standard')
for sid,pic in [('philo_carpenter_log_shop','early-andreas-1884-sauganash'),('st_marys_church','early-moss-1884-st-marys')]:assert json.loads((app/f'data/sidecars/1835/{sid}.json').read_text())['grade']['pictures']==[pic]
result={'status':'CURRENT_DFCBF_AFFECTED_NATIVE_ALL44_PUBLISH_PASS','at':now(),'head':head,'incoming':tip,'tree':git('write-tree'),'steps':steps,'all_source_models_protected':len(protected),'all44_pass':True,'scope':'ActualaffectedcurrentK16/globalmetadata/defaultsamples/freshness/rights/ownership/package/publication pass. Actuale5full3 staysdated1077/388. Current1904phone400cap and BOTHcardreview pluscheckednormalcommit/publicFF/DEVmerge remainpending.'};save('RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
