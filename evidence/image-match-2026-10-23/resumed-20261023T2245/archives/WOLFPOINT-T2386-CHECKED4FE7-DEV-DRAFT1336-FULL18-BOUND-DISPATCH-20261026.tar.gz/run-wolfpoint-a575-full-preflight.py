from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,urllib.request
R=Path('/workspace/chicago');A=R/'chicago/4d';BASE='a575dddeed356333423b20361a1f90f3b39a862f'
O=Path('/tmp')/('WolfPoint-T2386-a575-preflight-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));O.mkdir()
env=dict(os.environ);env.pop('CHICAGO_TICKETS_DIR',None);env.pop('GIT_NO_LAZY_FETCH',None)
cpus={int(x)for x in os.environ['WOLF_GATE_CPUS'].split(',')};assert len(cpus)==2;os.sched_setaffinity(0,cpus);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',TMPDIR='/tmp/wolfpoint-a575-gate-tmp',CHECK_JOBS='2',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',PYTHONDONTWRITEBYTECODE='1',CHECK_TIMINGS=str(O/'timings.tsv'));Path(env['TMPDIR']).mkdir(exist_ok=True)
floor=2000000000;tempfree=shutil.disk_usage(env['TMPDIR']).free;assert tempfree>=floor,('ROOT_REVISED_EXTERNAL_WHOLE_STARTUP_FLOOR_2B_DECIMAL_NATIVE_ASSERTS_UNCHANGED',tempfree)
mem=lambda:int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text());assert mem()>=512*1024**2
def git(*args):return subprocess.check_output(['git','-C',str(R),'-c','core.preloadIndex=false',*args],env={**env,'GIT_NO_LAZY_FETCH':'1'})
assert git('rev-parse','HEAD').decode().strip()==BASE
assert not git('diff','--name-only','--diff-filter=U')
assert git('merge-base','origin/dev','HEAD').decode().strip()==BASE
oldapp=Path('/tmp/WolfPoint-T2386-a575-final-app-20261026');remaining=Path('/tmp/WolfPoint-T2386-desktop-remaining-20261026')
assert json.loads((oldapp/'MANIFEST.json').read_bytes())['status']=='MOBILE_TARGETED_PASS_DESKTOP_PARTIAL_AGENT_INTERRUPTED_SLOW_PROGRESS_CORRECTED_NO_FULL_PASS'
assert json.loads((oldapp/'app-qa/mobile-result.json').read_bytes())['status']=='PASS'
assert json.loads((remaining/'proof/TERMINAL-PROOF.json').read_bytes())['status']=='FRESH_DESKTOP_REMAINING_COMPONENTS_PASS'
appreap=json.loads(Path('/tmp/wolfpoint-desktop-remaining-reaping-status.json').read_bytes());assert appreap['command_exit']==0 and appreap['all_children_reaped']
for mode in ['normal','confidence']:assert json.loads((oldapp/f'app-qa/desktop-full-{mode}-stats.json').read_bytes())['withinBudget']
assert (oldapp/'app-qa/desktop-photos.json').is_file()
remote=json.loads(urllib.request.urlopen('https://api.github.com/repos/kevinrhaas/chicago/git/ref/heads/dev').read());(O/'fresh-remote-dev.json').write_text(json.dumps(remote,indent=2)+'\n')
if remote['object']['sha']!=BASE:
 comparison=json.loads(urllib.request.urlopen('https://api.github.com/repos/kevinrhaas/chicago/compare/'+BASE+'...'+remote['object']['sha']).read());(O/'fresh-remote-compare.json').write_text(json.dumps(comparison,indent=2)+'\n');assert comparison['merge_base_commit']['sha']==BASE
paths=sorted(set(p for p in (git('diff','HEAD','--name-only','-z')+git('ls-files','--others','--exclude-standard','-z')).decode().split('\0')if p));assert paths and all(p.startswith('chicago/4d/')for p in paths),paths
subprocess.run(['git','-C',str(R),'add','-A','--','chicago/4d'],env=env,check=True)
tree=git('write-tree').decode().strip();bound={p:hashlib.sha256((R/p).read_bytes()).hexdigest()if(R/p).is_file()else None for p in paths}
(O/'SOURCE-BINDING.json').write_text(json.dumps({'base':BASE,'head':BASE,'staged_tree':tree,'paths':bound,'temp_free_start':tempfree,'startup_floor':floor,'startup_floor_authority':'Parent explicit2026-10-26 revised external orchestration budget2,000,000,000Bdecimal for future whole gates; not a native quality/performance assertion; no midrun diskdip kill','memory_reserve_start':mem(),'jobs':2,'cpu_affinity':sorted(cpus),'required_readers':True,'required_base':True,'ticket_override_absent':True,'git_no_lazy_fetch_absent_from_gate_environment':True,'source_scope':'Integrated a575 plus bounded Wolf roof opt-in and exact checked shared4tool repairs. No source implementation commit before native full check PASS. Precommit changelog check sees no committed delta and is repeated on actual resulting commit.'},indent=2)+'\n');(O/'source.binary.patch').write_bytes(git('diff','--cached','--binary'))
commands=[['bash','tools/check.sh'],['node','tools/check-changelog-entry.mjs',BASE,'HEAD'],['node','tools/resolve_id_collisions.mjs','--base','origin/dev','--check']];results=[];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
for i,command in enumerate(commands):
 assert mem()>=512*1024**2
 log=O/['check.log','precommit-changelog-entry.log','precommit-ids.log'][i]
 with log.open('x')as f:p=subprocess.run(command,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append({'command':command,'exit_code':p.returncode,'log':str(log)});print('ACTUAL_REQUIRED_COMMAND',i,p.returncode,str(log),flush=True)
 if p.returncode:break
unchanged=all((hashlib.sha256((R/p).read_bytes()).hexdigest()if(R/p).is_file()else None)==v for p,v in bound.items());same_tree=git('write-tree').decode().strip()==tree;workclean=subprocess.run(['git','-C',str(R),'diff','--quiet'],env=env).returncode==0
text=re.sub(r'\x1b\[[0-9;]*m','',(O/'check.log').read_text(errors='replace'));footer=text.splitlines()[-4:];g=re.search(r'CHECK PASS — (\d+) steps, none red\.','\n'.join(footer));s=re.search(r'(\d+) of them are self-tests','\n'.join(footer))
passed=len(results)==3 and all(r['exit_code']==0 for r in results)and unchanged and same_tree and workclean and bool(g)and bool(s)
result={'status':'PASS'if passed else'FAIL','started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'staged_tree':tree,'jobs':2,'cpu_affinity':sorted(cpus),'source_unchanged':unchanged,'index_tree_unchanged':same_tree,'working_index_clean':workclean,'actual_gate_steps':int(g[1])if g else None,'actual_self_tests':int(s[1])if s else None,'footer':footer,'commands':results,'committed_head_changelog_ids':'OWED after normal source commit'};(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True);raise SystemExit(0 if passed else 1)
