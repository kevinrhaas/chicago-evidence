from pathlib import Path
import subprocess,json,os,datetime,hashlib
R=Path('/workspace/chicago');A=R/'chicago/4d';P=Path('/tmp/WolfPoint-T2386-a575-preflight-20261026T065149Z');O=Path('/tmp/WolfPoint-T2386-checked-commit-20261026');O.mkdir(exist_ok=False)
env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None)
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=env)
proof=json.loads((P/'RESULT.json').read_bytes());assert proof['status']=='PASS'
assert proof['source_unchanged']and proof['index_tree_unchanged']and proof['working_index_clean']
base='a575dddeed356333423b20361a1f90f3b39a862f';assert git('rev-parse','HEAD').decode().strip()==base
assert git('branch','--show-current').decode().strip()=='steward/t2386-wolfpoint-picture'
assert git('write-tree').decode().strip()==proof['staged_tree']
assert not git('diff','--name-only')
msg='T-2386: give Wolf Point a darker reconstructed roof tone\n\nSelect a reconstructed deep brown tone through a keyword-only LogDwelling option. Genuine builds of all 82 masters and web assets leave the other 81 pairs byte-identical. The original picture acceptance remains open.\n\nInclude the four reviewed smoke and placement fixes for the existing renderer contracts. Renderer behavior and native tolerances remain unchanged.'
(O/'commit.log').write_bytes(git('commit','-m',msg))
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^{tree}').decode().strip()==proof['staged_tree']
commands=[['node','tools/check-changelog-entry.mjs',base,head],['node','tools/resolve_id_collisions.mjs','--base','origin/dev','--check'],['node','tools/check-changelog.mjs']];results=[]
for i,c in enumerate(commands):
 p=subprocess.run(c,cwd=A,env=env,capture_output=True,text=True);(O/f'committed-question-{i}.log').write_text(p.stdout+p.stderr);results.append({'command':c,'exit_code':p.returncode});assert p.returncode==0,(c,p.stdout,p.stderr)
assert not git('status','--porcelain'),git('status','--short')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'NORMAL_COMMIT_EXACT_CHECKED_TREE_COMMITTED_CHANGELOG_IDS_HISTORY_PASS','head':head,'tree':proof['staged_tree'],'parent':base,'branch':'steward/t2386-wolfpoint-picture','whole_gate_steps':proof['actual_gate_steps'],'whole_selftests':proof['actual_self_tests'],'preflight_result_sha256':hashlib.sha256((P/'RESULT.json').read_bytes()).hexdigest(),'commands':results,'working_index_clean':True,'draftPR_push_lap_FULL18_pending':True,'originalT2386_open_no_matches':True};(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
