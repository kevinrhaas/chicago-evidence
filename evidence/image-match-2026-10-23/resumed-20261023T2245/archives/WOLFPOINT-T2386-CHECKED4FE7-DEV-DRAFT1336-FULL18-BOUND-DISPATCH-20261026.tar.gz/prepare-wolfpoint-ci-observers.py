from pathlib import Path
import json,hashlib,ast
H=Path('/tmp/WolfPoint-T2386-delivery-20261026');H.mkdir(exist_ok=False);C=json.loads(Path('/tmp/WolfPoint-T2386-checked-commit-20261026/RESULT.json').read_bytes());D=Path('/tmp/WolfPoint-T2386-full18-4fe7-20261026');dispatch=json.loads((D/'COMPLETE_DISPATCH.json').read_bytes());assert len(dispatch['runs'])==18 and dispatch['head']==C['head']
candidate={'head':C['head'],'tree':C['tree'],'base':C['parent'],'code_branch':C['branch'],'PR':1336,'expected_gate_steps':C['whole_gate_steps'],'expected_self_tests':C['whole_selftests']};(H/'FINAL-CANDIDATE.json').write_text(json.dumps(candidate,indent=2)+'\n')
source=Path('/workspace/shared/T2380-integrate-a575-20261026')
for name in ['observe-final-matrix.py','observe-final-pr-gate.py']:
 original=(source/name).read_text();s=original.replace("Path('/workspace/shared/T2380-integrate-a575-20261026')",'Path('+repr(str(H))+')').replace("ROOT=HOLDER/'full18-e81'",'ROOT=Path('+repr(str(D))+')').replace("p['number']==1333","p['number']==1336")
 ast.parse(s);(H/name).write_text(s);(H/(name+'.ADAPTATION.json')).write_text(json.dumps({'source':str(source/name),'source_sha256':hashlib.sha256(original.encode()).hexdigest(),'result_sha256':hashlib.sha256(s.encode()).hexdigest(),'changes':'Only owned holder/output/PR/candidate bindings. Preserve exact checkout/head/tree/env/publish/nativefooter/zeroerror/failure predicates. Read-only gh REST, sleep60. No source/ref/CI writes. Source ordinaryPR may currently be absent due dirtybase; never read NOT_FOUND as PASS.'},indent=2)+'\n')
print(json.dumps({'holder':str(H),'head':C['head'],'tree':C['tree'],'PR':1336,'groups':len(dispatch['runs']),'prepared_only':True}))
