from pathlib import Path
import urllib.request,json,subprocess,os,datetime,hashlib,re
O=Path('/tmp/WolfPoint-T2386-own-claim-renewal-before-PR-20261026');O.mkdir(exist_ok=False)
repo='https://api.github.com/repos/kevinrhaas/';ticketpath='T-2250-2499/T-2386-match-the-wolf-point-tavern-to-its-pictures.md';actor='T2386 Wolf Point native picture signoff'
def read(url):
 req=urllib.request.Request(url,headers={'Accept':'application/vnd.github+json','Cache-Control':'no-cache','User-Agent':'WolfPoint-T2386-native-case'});return urllib.request.urlopen(req,timeout=90).read()
def js(url):return json.loads(read(url))
ref=js(repo+'chicago-tickets/git/ref/heads/main');(O/'fresh-tickets-ref.json').write_text(json.dumps(ref,indent=2)+'\n');sha=ref['object']['sha'];body=read('https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+sha+'/'+ticketpath).decode();(O/'immutable-original-before.md').write_text(body)
state=re.search(r'^state: (.+)$',body,re.M).group(1).strip();who=re.search(r'^claimed_by: (.+)$',body,re.M).group(1).strip();assert state=='claimed' and who.startswith(actor),(state,who)
pulls=[]
for page in range(1,6):
 data=js(repo+'chicago/pulls?state=open&per_page=100&page='+str(page));pulls.extend(data)
 if len(data)<100:break
else:raise AssertionError('Open PR list truncated; no mutation')
(O/'fresh-open-pulls.json').write_text(json.dumps(pulls,indent=2)+'\n')
rivals=[{'number':p['number'],'title':p['title'],'head':p['head']['ref']}for p in pulls if re.search(r'T[-_ ]?0*2386\b|wolf.?point',p['title']+' '+p['head']['ref'],re.I)]
assert not rivals,('EXISTING_OR_RIVAL_WOLF_PR_REQUIRES_REVIEW_NO_MUTATION',rivals)
(O/'OWNERSHIP-AUDIT.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'immutable_ticket_base':sha,'state':state,'verified_same_own_actor':who,'no_rival_PR':True,'open_PR_count':len(pulls),'authorization':'Parent standing instruction renew only our verified own actor before expiry, no external worker takeover. Native timestamp only.'},indent=2)+'\n')
env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None)
command=['node','tools/ticket.mjs','claim','T-2386','--by',actor,'--force'];p=subprocess.run(command,cwd='/workspace/chicago/chicago/4d',env=env,capture_output=True,text=True);(O/'native-renew.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(p.returncode,p.stdout,p.stderr)
newref=js(repo+'chicago-tickets/git/ref/heads/main');(O/'fresh-renewed-ref.json').write_text(json.dumps(newref,indent=2)+'\n');newbody=read('https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+newref['object']['sha']+'/'+ticketpath).decode();(O/'immutable-original-renewed.md').write_text(newbody);assert re.search(r'^claimed_by: (.+)$',newbody,re.M).group(1).strip().startswith(actor) and newbody!=body
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SAME_OWN_ACTOR_NATIVE_RENEWAL_IMMUTABLE_READBACK_PASS','native_command':command,'renewed_commit':newref['object']['sha'],'ticket_sha256':hashlib.sha256(newbody.encode()).hexdigest(),'no_rival_or_other_actor_overridden':True,'only_native_automatic_timestamp':True};(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
