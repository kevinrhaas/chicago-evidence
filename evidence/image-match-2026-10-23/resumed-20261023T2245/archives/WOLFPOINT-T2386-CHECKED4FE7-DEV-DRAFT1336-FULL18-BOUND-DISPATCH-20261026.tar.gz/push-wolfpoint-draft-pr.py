from pathlib import Path
import urllib.request,urllib.error,urllib.parse,json,subprocess,os,datetime,hashlib
R=Path('/workspace/chicago');A=R/'chicago/4d';C=Path('/tmp/WolfPoint-T2386-checked-commit-20261026');O=Path('/tmp/WolfPoint-T2386-public-draft-PR-20261026');O.mkdir(exist_ok=False)
c=json.loads((C/'RESULT.json').read_bytes());assert c['status']=='NORMAL_COMMIT_EXACT_CHECKED_TREE_COMMITTED_CHANGELOG_IDS_HISTORY_PASS';head=c['head'];branch=c['branch'];api='https://api.github.com/repos/kevinrhaas/chicago/'
env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None)
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=env)
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain')
def req(path,method='GET',data=None):
 raw=None if data is None else json.dumps(data).encode();request=urllib.request.Request(api+path,data=raw,method=method,headers={'Accept':'application/vnd.github+json','Content-Type':'application/json','User-Agent':'WolfPoint-T2386-source-delivery','Cache-Control':'no-cache'})
 with urllib.request.urlopen(request,timeout=120)as response:
  b=response.read();return json.loads(b)if b else None
url=urllib.parse.urlparse(git('remote','get-url','origin').decode().strip());assert url.username is None and url.password is None and url.hostname=='github.com' and url.path.rstrip('/').removesuffix('.git')=='/kevinrhaas/chicago','Unexpected origin selector; no URL/credential contents printed'
try:before=req('git/ref/heads/'+urllib.parse.quote(branch,safe='/'))
except urllib.error.HTTPError as e:
 if e.code!=404:raise
 before=None
(O/'remote-branch-before.json').write_text(json.dumps(before,indent=2)+'\n')
p=subprocess.run(['git','-C',str(R),'push','origin','HEAD:refs/heads/'+branch],env=env,capture_output=True,text=True);(O/'normal-push.log').write_text(p.stdout+p.stderr);assert p.returncode==0,('NORMAL_PUSH_FAILED_NO_FORCE',p.returncode)
ref=req('git/ref/heads/'+urllib.parse.quote(branch,safe='/'));assert ref['object']['sha']==head;(O/'immutable-public-ref.json').write_text(json.dumps(ref,indent=2)+'\n')
commit=req('git/commits/'+head);assert commit['tree']['sha']==c['tree'];(O/'immutable-public-commit.json').write_text(json.dumps(commit,indent=2)+'\n')
for rel,expected in [('assets/gltf/wolf_point_tavern__log_frame_1828.glb','225f3e1041d02cdaa627d3d73c5f6448aff9b12c66f4a545462db45bbf8e0d59'),('assets/web/wolf_point_tavern__log_frame_1828.glb','fdc5ef22a440636e35e4cec15818661f4351f0f4d0c9e506ef36b00422a45210')]:
 request=urllib.request.Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+head+'/chicago/4d/'+rel,headers={'Cache-Control':'no-cache','User-Agent':'WolfPoint-T2386-source-delivery'});b=urllib.request.urlopen(request,timeout=90).read();assert hashlib.sha256(b).hexdigest()==expected
body=Path('/tmp/wolfpoint-draft-pr-body-template.md').read_text()
for key,val in {'HEAD':head,'TREE':c['tree'],'STEPS':str(c['whole_gate_steps']),'SELFTESTS':str(c['whole_selftests'])}.items():body=body.replace('{{'+key+'}}',val)
assert '{{'not in body;(O/'draft-pr-body.md').write_text(body)
existing=req('pulls?state=open&base=dev&head='+urllib.parse.quote('kevinrhaas:'+branch,safe=''))
assert len(existing)<=1
if existing:
 pr=existing[0];assert pr['head']['sha']==head and pr['draft'],'Existing PR requires review; no mutation'
else:pr=req('pulls','POST',{'title':'T-2386: give Wolf Point a darker reconstructed roof tone','head':branch,'base':'dev','body':body,'draft':True,'maintainer_can_modify':True})
assert pr['head']['sha']==head and pr['base']['ref']=='dev' and pr['draft'];(O/'fresh-created-PR.json').write_text(json.dumps(pr,indent=2)+'\n')
actor='T2386 Wolf Point native picture signoff';commands=[['node','tools/ticket.mjs','lap',str(pr['number']),'--by',actor],['node','tools/ticket.mjs','lap',str(pr['number']),'--status']];rows=[]
for i,command in enumerate(commands):
 p=subprocess.run(command,cwd=A,env=env,capture_output=True,text=True);(O/f'own-lap-{i}.log').write_text(p.stdout+p.stderr);rows.append({'command':command,'exit_code':p.returncode})
 if i==0:assert p.returncode==0,('NATIVE_LAP_REFUSED_NO_FORCE',i,p.returncode)
 else:assert p.returncode==3 and p.stdout.startswith('held ') and actor in p.stdout,('OWN_LAP_NOT_VERIFIED_HELD',p.returncode,p.stdout)
fresh=req('pulls/'+str(pr['number']));assert fresh['head']['sha']==head and fresh['draft'] and fresh['base']['ref']=='dev';(O/'fresh-PR-after-ownlap.json').write_text(json.dumps(fresh,indent=2)+'\n')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'NORMAL_PUSH_DEV_DRAFT_PR_OWN_NATIVE_LAP_PUBLIC_IMMUTABLE_TREE_ASSETS_PASS','PR':pr['number'],'url':pr['html_url'],'head':head,'tree':c['tree'],'branch':branch,'draft':True,'base':'dev','own_lap':rows,'FULL18_pending':True,'root_owns_ready_and_merge':True,'originalT2386_open_no_matches':True};(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
