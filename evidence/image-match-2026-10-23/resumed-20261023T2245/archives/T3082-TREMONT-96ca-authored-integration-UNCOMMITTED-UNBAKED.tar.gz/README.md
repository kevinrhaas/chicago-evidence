# T-3082 authored integration checkpoint

The main checkout `/workspace/chicago` now holds a bounded, uncommitted roof
increment on new branch `steward/t3082-tremont-quarter-roof`. HEAD is local
`96ca50cbc8150f93576cbbd699b4359d73b6de01`; MERGE_HEAD is the changelog-only fold
`e5ed3ff6e5a62f70ae8a1c3c0c88c29e977cf02a`. That merge has exactly two staged
paths. The old parent branch still points to 792598d. No PR #1239 branch, push,
lease, shared ticket clone or parent log worktree was touched.

`authored-only.patch` contains exactly the four guarded producer/record/test
edits and three raw doc appends. `AUTHORED-GUARDS.json` holds every base/after
hash. `RAW-APPEND-GUARDS.json` proves existing doc prefixes were preserved as
bytes, including LIBERTIES. `merge-fold-only.patch` is the separate incoming
fold. Apply neither over a different base without checking its guards.
The one new untracked canonical entry is copied as `T-3082.json`.

T-3082 was created, normally claimed and given explicit bounded utility
acceptance through the isolated native ticket tool. The remote main readback
was 70eff37c3c1195749148cb77c4298b0914ec87d7; creation and claim commits are in
LOCAL-STATE.json. Original T-2385 remains open/claimed with its existing image
gate and is not accepted or completed by this increment.

`FRESH-INPUT-PLAN.json` and `FRAME23-INPUT-DOCS.json` record actual candidate
resolved native recipes for the 23 current frame-family masters. The pure
Python recipe resolver imported no bpy. All 23 correctly differ from their old
manifest recipe stamps after the shared producer change. All 23 current masters
and all 23 current derivatives are still exact to HEAD; no output was rebuilt.
The exact comma ID selection and written-master inventory are supplied here.

`PROTECTED-INPUTS.json` proves Hogan/Glessner source records, Gifford source,
asset licenses, schema, name-pool keys and native flag/wind files are unchanged
from the integrated base. Quarter-linear roof colour is reconstructed; source
attribution and owner-approved project-use limits stand without any rights
upgrade. The broad-left flag-pose study remains unadopted.

`ENTRY-SHAPE-PASS.json` covers only actual entry shape/budget validation.
`git diff --check` also passed. No focused tests, official content build,
derivatives, ordered downstream derivation, browser/native picture review,
preflight/full gate, code commit, PR or merge has run for this new branch yet.
Do not confuse earlier proposal CPU proofs or GPU overrides with these pending
canonical checks. The earlier closed BUILD-PLAN.md remains the detailed
23-family execution plan; recheck inventory/guards before the parent allocates
the exclusive heavy slot.

The ignored Glessner cache is a separate prerequisite for future publication.
GLESSNER-CACHE-READONLY.json records that all three outputs differ from the
current 17ac package; the current manifest and every archive part match 17ac
exactly and pass part/combined hashes. The old cache's hashes bind to the old
792 package. A requested atomic move into /tmp was refused before mutation
because /workspace and /tmp are different filesystems. Any later move receipt
in this packet supersedes that refusal only for the explicitly documented move;
no decompression, materialization, repacking or publishing is authorized here.
Preserved GLB bytes must never be deleted or repacked over the new archive.

Next: the parent schedules the official 23-master pinned refresh, actual web
derivatives, native name-pool/seating checks and ordered fixed-point tail from
compile_liberties or the earlier affected writer. Preserve original flag/time/
camera/lighting for canonical roof comparison. Required published mobile and
desktop smoke, preflight and honest remaining-differences review precede a
bounded T-3082 PR/merge. Use PATH=/workspace/shared/tools/usr/bin:$PATH for later
publisher commands so the existing bc calculation is available.
