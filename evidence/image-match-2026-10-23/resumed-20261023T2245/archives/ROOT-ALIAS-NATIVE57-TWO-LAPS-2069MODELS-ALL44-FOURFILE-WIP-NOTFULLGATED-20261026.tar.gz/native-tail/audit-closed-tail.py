from pathlib import Path
import json,subprocess,hashlib,gzip,zipfile,io,datetime
import xml.etree.ElementTree as ET
repo=Path('/tmp/jail-picture-c6');out=Path(__file__).parent
head='f311c2a9b7628e22835973933c9de41b83a2b531'
old=json.loads((out.parent/'CURRENT-NATIVE-BINDING.json').read_text())
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==head
reaper=json.loads((out/'reaper.json').read_text());assert reaper['command_exit']==0 and reaper['all_children_reaped'] and not reaper['leftover_cleanup']
closed=json.loads((out/'RESULT.json').read_text());assert closed['status']=='OWNING_NATIVE_TAIL_PASS'
models=[]
for p,v in old['models'].items():
 actual=(repo/p).read_bytes();models.append(dict(path=p,sha256=hashlib.sha256(actual).hexdigest(),expected=v['sha256'],bytes=len(actual)))
def node(n):
 text=n.text
 if text is not None and not text.strip() and len(n):text=None
 return n.tag,tuple(sorted(n.attrib.items())),text,n.tail if n.tail and n.tail.strip() else None,tuple(node(c) for c in n)
def equivalent(a,b,p):
 if p.endswith('.gz'):return gzip.decompress(a)==gzip.decompress(b),'exact decompressed stream'
 aa,bb=zipfile.ZipFile(io.BytesIO(a)),zipfile.ZipFile(io.BytesIO(b))
 if sorted(aa.namelist())!=sorted(bb.namelist()):return False,'ZIP members differ'
 for m in sorted(aa.namelist()):
  x,y=aa.read(m),bb.read(m)
  same=node(ET.fromstring(x))==node(ET.fromstring(y)) if m.endswith(('.xml','.rels')) else x==y
  if not same:return False,'full member differs: '+m
 return True,'all XML values/attributes and non-XML members equal'
rows=[];restores={}
for p in old['binaries']:
 baseline=git('show',head+':'+p);actual=(repo/p).read_bytes();r=dict(path=p,baseline_sha256=hashlib.sha256(baseline).hexdigest(),generated_sha256=hashlib.sha256(actual).hexdigest())
 if actual==baseline:r['byte_equal']=True
 else:
  saved=out/'raw-generated-binary-serialization'/p;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(actual)
  r['semantic_equal'],r['comparison']=equivalent(actual,baseline,p);r['raw_generated_saved']=str(saved);restores[p]=baseline
 rows.append(r)
changed=git('diff','--name-only').decode().splitlines();outside=[p for p in changed if not p.startswith('chicago/4d/') and p not in restores]
passed=all(x['sha256']==x['expected'] for x in models) and all(x.get('semantic_equal',True) for x in rows) and not outside
r=dict(status='PASS' if passed else 'FAIL_RETAINED_NO_RESTORE',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,physical_models=len(models),all_model_bytes_exact=all(x['sha256']==x['expected'] for x in models),whole_binary_count=len(rows),binary_records=rows,unclassified_outside4d=outside,restored_serialization_only=[])
(out/'ALL44-AND-MODEL-AUDIT.json').write_text(json.dumps(r,indent=2)+'\n')
(out/'MODEL-BYTES.json').write_text(json.dumps(models,indent=2)+'\n')
assert passed,'Actual differences retained; no restoration performed'
for p,b in restores.items():(repo/p).write_bytes(b)
r['restored_serialization_only']=list(restores);r['final_changed_paths']=git('diff','--name-only').decode().splitlines()
(out/'ALL44-AND-MODEL-AUDIT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['binary_records']},indent=2))
