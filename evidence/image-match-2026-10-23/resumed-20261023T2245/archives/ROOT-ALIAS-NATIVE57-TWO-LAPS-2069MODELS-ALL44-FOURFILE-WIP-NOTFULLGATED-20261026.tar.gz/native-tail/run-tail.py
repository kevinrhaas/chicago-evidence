from pathlib import Path
import json,subprocess,hashlib,os,shutil,datetime
repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';out=Path(__file__).parent
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo,text=True).strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert git('rev-parse','HEAD')=='f311c2a9b7628e22835973933c9de41b83a2b531'
authored=git('diff','--name-only').splitlines();assert authored==['chicago/4d/data/structure_grades.json','chicago/4d/docs/ROADMAP.md','chicago/4d/docs/STATUS.md']
protected={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in authored}
assert shutil.disk_usage('/tmp').free>=1000000000
binding=dict(status='RUNNING',at=now(),head=git('rev-parse','HEAD'),affinity=sorted(os.sched_getaffinity(0)),authored=protected,command=['node','tools/rederive.mjs','--tail','tools/compile_scene.py'],scope='Owning57-step settled native tail for existingPhilo picturedruling canonical-ID correction; no whole3 claim.')
(out/'BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
with (out/'native-tail.log').open('w') as f:
 code=subprocess.call(binding['command'],cwd=app,stdout=f,stderr=subprocess.STDOUT)
after=git('diff','--name-only').splitlines();unchanged=all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in protected.items())
grade=json.loads((app/'data/sidecars/1835/philo_carpenter_log_shop.json').read_text())['grade']
expected={'value':'attested','why':'Pictured: a picture on the Images tab shows it.','pictures':['early-andreas-1884-sauganash']}
passed=code==0 and unchanged and grade==expected and not any(p.endswith('.glb') for p in after)
r=dict(status='OWNING_NATIVE_TAIL_PASS' if passed else 'OWNING_NATIVE_TAIL_FAIL_RETAINED',at=now(),binding=binding,exit=code,authored_bytes_unchanged=unchanged,grade=grade,expected_grade=expected,changed_paths=after,scope='Native owned derivation only. CurrentDEV integration/full3/publishedcard review remain pending; originalT2382OPEN/DIFFERS.')
(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(0 if passed else 1)
