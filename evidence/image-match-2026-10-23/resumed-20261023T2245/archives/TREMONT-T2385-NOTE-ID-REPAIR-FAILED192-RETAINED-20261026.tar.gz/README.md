# T-2385: exact source-reference ID repair, closed delta

The first native61 run stopped at step192, not because research was missing:
our historical prose digit-spacing helper had changed #c004/#c001 into #c 004/
#c 001. The native ledger lost the already-landed T-1591 venue assertions and
fell back to the closed T-1586 split. The exact failed log and exit1 are preserved.

Root authorized restoring both function.note strings EXACTLY from checked public
cf25a3f2bb653648d25502fe5fab914b8cb29453. Only damaged existing source/epoch/liberty
ID literals were additionally restored from their exact preimages in our two
records. No blanket prose rewrite, new research, ticket retarget, gate waiver,
source finding or geometry change occurred. Bad and fixed full records plus exact
field/literal proof are included. The flawed historical helper is retained here as
text, and its executable entrypoint in the runtime was DISABLED permanently.

Actual native prose_target_index now reaches both original qualified newspaper
units at /function in both default and Gifford version. The native ledger writer
and --gate both PASS: 23,716 units, zero unclassified. All four actual master/WEB
SHA256 values are unchanged; native inputs remain default717398e0... and
version16ddd576... . Explicit source-hash rebinding for the prepared app harness
is included and limited to the two reviewed notes-only record repairs.

This depends on closed author003 +native2+2 delta (manifest56e6492f...), and does
NOT claim native61 completion, fixedpoint, serialization audit, package5/final
publish, current app review, wholecheck/preflight, code commit or PR. Normal
incoming132e integration and a newly scheduled native tail remain pending.
