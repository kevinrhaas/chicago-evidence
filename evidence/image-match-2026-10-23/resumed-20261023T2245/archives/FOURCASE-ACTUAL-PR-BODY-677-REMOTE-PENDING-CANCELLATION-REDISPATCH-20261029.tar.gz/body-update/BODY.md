Give the Miller House its pictured low log wing beside the tall range, add Hogan’s horizontal gable courses and chimney cap, raise St Mary’s front sash, and add the credited Castelnau harbour view to the lighthouse card. Sources retain disputed dates, unresolved details and picture conflicts; comparison cameras remain diagnostic.

Validation at the qualified BE501 merge, native head `24e4c333`:

- All 1,104 foreground checks passed. The 27-path incoming merge preserved 536 relevant source bindings, all 706 log/frame model files and all 353 fresh recipes. Native publication, package checks, four image gates and committed PR checks passed.
- The current 1904 phone measurement passed at **394.9 MiB / 400 MiB**.
- Existing desktop/mobile app evidence is bound through 305 unchanged published inputs. Miller’s updated Full-detail runs passed both viewports with zero page errors, credited image viewing and clear approaches to both doors. This does not claim a fresh whole-app matrix or frame-rate measurement.

T-2381, T-2373, T-2384 and T-2377 are in official review for this PR. The native PR lap brings the branch onto newer `dev`; required CI must pass on the final head before merging.

Recovery, exact source bindings, actual checks, branch publication and official ticket receipts: [checkpoint 677](https://github.com/kevinrhaas/chicago-evidence/blob/7351515e2c88d1cdf13fcd15714cfa145cd0f9ab/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md).
