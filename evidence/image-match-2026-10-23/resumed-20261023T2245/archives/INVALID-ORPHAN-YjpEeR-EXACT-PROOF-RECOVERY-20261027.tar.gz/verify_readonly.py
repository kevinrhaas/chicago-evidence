from pathlib import Path
import os,subprocess,json,hashlib,time,datetime
os.sched_setaffinity(0,{3});os.nice(19)
B=Path(__file__).parent;P=Path('/workspace/chicago/.git/objects/pack/tmp_pack_YjpEeR');G=Path('/workspace/chicago/.git');C=G.parent
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def save(n,o):(B/n).write_text(json.dumps(o,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(C),*args],env=env)
def snap():return {'HEAD':git('rev-parse','HEAD').decode().strip(),'refs':git('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:hashlib.sha256((G/n).read_bytes()).hexdigest()for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()}}
def stat():
 s=P.stat();return {'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'allocated':s.st_blocks*512,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'nlink':s.st_nlink,'mode':s.st_mode}
def processes():
 writers=[];readers=[];unobservable=0
 for q in Path('/proc').iterdir():
  if not q.name.isdigit():continue
  try:
   args=(q/'cmdline').read_bytes().split(b'\0');exe=os.path.basename(args[0].decode(errors='replace'))
   if exe in ['git','git-remote-http','git-remote-https','git-index-pack','git-fetch-pack','git-pack-objects']:writers.append({'pid':q.name,'args':[a.decode(errors='replace')for a in args]})
  except OSError:pass
  try:
   for fd in(q/'fd').iterdir():
    try:
     if os.path.realpath(fd)==str(P):readers.append({'pid':q.name,'fd':fd.name})
    except OSError:pass
  except OSError:unobservable+=1
 return {'live_git_writers':writers,'readable_exact_file_open_fds':readers,'fd_directories_unobservable':unobservable,'qualification':'Only observable proc entries inspected; no global zero-FD assertion.'}
before=snap();save('SOURCE-BEFORE.json',before);s=stat();assert s['bytes']==2235564032 and s['nlink']==1
proc=processes();save('PROCESSES-BEFORE.json',proc);assert not proc['live_git_writers']and not proc['readable_exact_file_open_fds'];assert list(P.parent.glob(P.name+'*'))==[P]
registered=[str(x)for x in P.parent.glob('*.idx')];save('INDEXED-CANONICAL-PACKS-PRESERVED.json',registered)
h=hashlib.sha1();h256=hashlib.sha256()
with P.open('rb')as f:
 header=f.read(12);f.seek(0);remaining=s['bytes']-20
 while remaining:
  data=f.read(min(8*1024**2,remaining));assert data;h.update(data);h256.update(data);remaining-=len(data)
 trailer=f.read(20);assert len(trailer)==20 and not f.read(1);h256.update(trailer)
valid=h.digest()==trailer;proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'path':str(P),'stat':s,'header_hex':header.hex(),'trailer_hex':trailer.hex(),'computed_pack_body_sha1':h.hexdigest(),'whole_sha256':h256.hexdigest(),'valid_pack_checksum':valid,'registered_companion_index':False,'canonical_pack_indexes_retained_count':len(registered),'delegation':'READ ONLY proof; exact invalid unindexed scratch retirement requires source-owner coordination.'};save('VALIDITY-PROOF.json',proof)
assert not valid,'ValidpackSTOP';assert stat()==s;assert snap()==before
print(json.dumps(proof,indent=2))
