# V2: existing-checkout private trial — prepared, UNRUN

V1 (`11d1ef4a`), the revised hypothesis (`e8877684`) and the earlier 1855 preparation (`a8a11180`) remain byte-exact and unadopted. V2 uses the same revised candidate SHA256 `4fa5785909c1c6c49149a8e9803c9dc267b66fc53454a4a54dc15a3796150650` and repaired producer SHA256 `fc645a66b889e8ca837520e73d2bdee4806b0892e33591099714bff10178d64e`.

**No clone or new worktree is created.** The only accepted execution checkout is root's approved existing `/workspace/primary-human-runner-compat`. Root will later fetch and normally check out the final pushed fort combined head onto a private trial branch there, preserving the H9 branch. No checkout, fetch, source update or execution occurs during this preparation. Both active canonical writer checkouts remain forbidden.

The safe preparation check is:

```bash
python -B /workspace/T2388-private-trial-execution-prep-v2-existing-20261024/run_private_trial.py --check
```

After fort's local work and T-2373's two captures finish, root prepares the approved checkout and supplies a NEW heavy grant. The exact future command is:

```bash
PATH=/workspace/shared/tools/usr/bin:$PATH PW_EXECUTABLE=/usr/bin/chromium python -B /workspace/T2388-private-trial-execution-prep-v2-existing-20261024/run_private_trial.py --repo /workspace/primary-human-runner-compat --out /workspace/T2388-private-gallery-existing-actual-001 --blender /workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender --root-heavy-granted
```

The documented flag is not an actual grant. Without it the controller refuses before creating outputs. The actual-output path must be NEW. The approved existing checkout must be clean, contain the exact original officers' record and fc645 backend/unchanged params, and have all 25 current fort recipes fresh. A stale or incompatible source fails closed; V2 never copies an old producer overlay or restamps a manifest.

The pinned executable path is explicit. At actual execution, V2 records and verifies the trial's `generators/blender.pin` hash, streams the existing 377 MB archive through SHA256 and requires `975c58fcb244273838534bba771e64ad87739216b0f9b39a888531a49a72d845`. It compares the installed executable's streamed SHA256/size with the `blender-4.5.3-linux-x64/blender` member read from that verified archive, without extracting a second installation to disk. Normal `blender --version` must report 4.5.3. These runtime archive/executable/version proofs remain UNRUN during preparation; only the pin text and file metadata were read. No download or installation is performed.

All previous source/provenance, exact 18-opening and seven-support guards remain. Metadata binds the four existing source records, Hubbard claims/rulings, complete closed revised packet, actual renderer scene/sidecars and current 25 recipe documents. All unrelated GLB bytes, 24 non-target fort rows, other manifest rows and placements are protected. The only permitted source change in the private checkout is the three-field officers' candidate; only its normal master/web and two manifests may subsequently change. No 1827 occupants are transferred to 1835.

The bounded later execution is: actual baseline **1855 diagnostic bracket** capture; apply the reconstructed candidate in this approved private checkout; normal pinned one-master production; normal one-web derivative; identical-camera candidate bracket capture. Logs, process IDs, exits, failures, baseline record/assets and input hashes are durable. The result always awaits human image review; a completed controller is not appearance acceptance. No native writers, publisher, standalone scene compiler, app QA, full gate, identity ruling, grade change, claim, commit, push or canonical adoption runs.

The camera remains unfitted. Pose, intrinsics, source pixels, context and lighting are unchanged from V1; only V1's already clarified metadata labels it as an 1855 diagnostic. It does not become a formal matched July 1835 view. Hubbard's retrospective 1818 piazza is the revised form basis, the same-west-range identity remains a private working reconstruction, and the outside/within-pickets conflict stays unresolved. Rails/canopy/metrics and existing opening positions remain reconstructed; outside stairs are omitted and all original 16 comparisons remain DIFFERS.
