"""Guarded, prepared private hypothesis trial. --check is read-only; actual work needs a later root grant."""
from pathlib import Path
import argparse,ast,collections,copy,dataclasses,datetime,hashlib,json,math,os,re,signal,subprocess,sys,tarfile,traceback,types
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
C=load(P/'CONFIG.json');REVISED=Path(C['revised_packet']);PRIOR=Path(C['prior_packet']);SID='fort_dearborn_officers_quarters';KEY=SID+'__log_1816.glb'

def packet_check():
 for directory,key in [(REVISED,'revised_manifest_sha256'),(PRIOR,'prior_manifest_sha256'),(Path(C['v1_packet']),'v1_manifest_sha256')]:
  assert sha((directory/'MANIFEST.json').read_bytes())==C[key]
  m=load(directory/'MANIFEST.json')
  for row in m['files']:
   b=(directory/row['path']).read_bytes();assert len(b)==row['bytes']and sha(b)==row['sha256'],row['path']
 original=(REVISED/'frozen/officers.before.json').read_bytes();candidate=(REVISED/'candidate'/f'{SID}.json').read_bytes()
 assert sha(original)==C['record_preimage_sha256']and sha(candidate)==C['candidate_sha256']
 a=json.loads(original);b=json.loads(candidate);restored=copy.deepcopy(b);f=restored['phases'][0]['form'];f['gallery']=a['phases'][0]['form']['gallery'];f.pop('gallery_storeys');f.pop('face_openings');assert restored==a
 for field in ['gallery','gallery_storeys','face_openings']:assert b['phases'][0]['form'][field]['confidence']=='reconstructed'
 params=(REVISED/'frozen/fort_structure_params.py').read_bytes();producer=(REVISED/'frozen/fort_structure.fc645.py').read_bytes();assert sha(producer)==C['repaired_producer_sha256']
 m=types.ModuleType('private_hypothesis_frozen_params');sys.modules[m.__name__]=m;exec(compile(params,'frozen_params','exec'),m.__dict__);p=m.from_phase(a['phases'][0],a);q=m.from_phase(b['phases'][0],b)
 old=load(PRIOR/'candidate'/f'{SID}.json');assert dataclasses.asdict(q)==dataclasses.asdict(m.from_phase(old['phases'][0],old))
 src=producer.decode();t=ast.parse(src);code='from __future__ import annotations\n'+'\n\n'.join(ast.get_source_segment(src,n)for n in t.body if isinstance(n,ast.FunctionDef)and n.name in {'_openings','_explicit_openings','_gallery_post_centres'});calls=[]
 def opening(_b,axis,plane,u0,u1,z0,z1,outward,conf,kind='window'):calls.append((axis,plane,u0,u1,z0,z1,outward,conf,kind))
 env={'math':math,'wall_openings':m.wall_openings,'openings':types.SimpleNamespace(CASING_W_M=.09,SILL_HORN_M=.03),'_opening':opening};exec(compile(code,'frozen_pure_functions','exec'),env);env['_openings'](None,p,0,0);oldcalls=collections.Counter(calls);calls.clear();env['_openings'](None,q,0,0);assert oldcalls==collections.Counter(calls)and len(calls)==18
 centres=env['_gallery_post_centres'](q,.14);assert len(centres)==7
 for x in centres[1:-1]:assert all(x<=o['u0']-.19+1e-9 or x>=o['u1']+.19-1e-9 for o in m.wall_openings(q,'front'))
 camera=load(P/'camera1855-diagnostic.json');oldcam=load(PRIOR/'cameras/wentworth_1855_gallery_seed.json');assert sha((P/'camera1855-diagnostic.json').read_bytes())==C['new_camera_sha256'];assert {k:v for k,v in camera.items()if k!='solve'}=={k:v for k,v in oldcam.items()if k!='solve'}
 assert camera['source_id']=='wentworth_1881_fort_dearborn'and camera['scene']=='1835'
 return {'status':'PASS_PREPARED_CHECK_ONLY_ACTUAL_TRIAL_UNRUN','immutable_packets':3,'same18opening_calls':True,'seven_supports_clear':True,'camera_pose_intrinsics_exact_prior':True,'source_period':'1855 diagnostic bracket; not formal1835view','candidate_sha256':C['candidate_sha256']}

ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--check',action='store_true');ap.add_argument('--repo',type=Path);ap.add_argument('--out',type=Path);ap.add_argument('--blender',type=Path);ap.add_argument('--root-heavy-granted',action='store_true');a=ap.parse_args()
if a.check:
 assert not a.root_heavy_granted,'check is not execution';print(json.dumps(packet_check(),indent=2));raise SystemExit(0)
if not a.root_heavy_granted:ap.error('Actual trial is UNRUN. A NEW later root heavy grant is required before execution.')
if not all([a.repo,a.out,a.blender]):ap.error('Actual execution requires --repo, --out and the installed pinned --blender binary.')
packet_check();repo=a.repo.resolve();out=a.out.resolve();root=repo/'chicago/4d'
assert repo.is_dir()and repo==Path(C['approved_existing_repo']).resolve(),'only the root-approved existing private-trial checkout is allowed; no clone or new worktree'
assert a.blender.resolve()==Path(C['pinned_blender']).resolve(),'use the explicit approved shared pinned Blender executable'
assert repo not in [Path('/workspace/chicago'),Path('/tmp/chicago-log-integration')]
assert Path(subprocess.check_output(['git','-C',str(repo),'rev-parse','--show-toplevel'],text=True).strip()).resolve()==repo
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain=v1'],text=True),'baseline isolated checkout must be clean'
assert not out.exists(),'never reuse or overwrite a prior attempt';out.mkdir(parents=True)
state={'status':'RUNNING','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repo':str(repo),'head':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'source_period':'1855','renderer_scene':'1835','scope':'PRIVATE reconstructed hypothesis; no identityruling/grade/match/adoption or appQA','source_review':'Root approved private hypothesis; heavyflag is separate later executiongrant','steps':[]}
def save():
 temp=out/'RESULT.json.tmp';temp.write_text(json.dumps(state,indent=2)+'\n');temp.replace(out/'RESULT.json')
def run(label,cmd,timeout=600):
 row={'label':label,'command':list(map(str,cmd)),'status':'RUNNING'};state['steps'].append(row);save()
 with (out/(label+'.log')).open('wb')as log:
  proc=subprocess.Popen(row['command'],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PW_EXECUTABLE':os.environ.get('PW_EXECUTABLE','/usr/bin/chromium')});row['pid']=proc.pid;row['process_group']=proc.pid;save()
  try:row['exit_code']=proc.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   row['timeout']=True;os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   row['exit_code']=proc.returncode
 row['status']='PASS'if row['exit_code']==0 else'FAIL_PRESERVED';save();assert row['exit_code']==0,label
try:
 save()
 def stream_sha(stream):
  h=hashlib.sha256()
  while True:
   block=stream.read(4*1024*1024)
   if not block:return h.hexdigest()
   h.update(block)
 pin=root/'generators/blender.pin';assert sha(pin.read_bytes())==C['blender_pin_sha256'],'the actual trial must use the pinned producer version'
 pinfields={}
 for line in pin.read_text().splitlines():
  match=re.fullmatch(r'(BLENDER_[A-Z0-9_]+)=(.+)',line.strip())
  if match:pinfields[match.group(1)]=match.group(2)
 assert pinfields['BLENDER_VERSION']==C['blender_version'] and pinfields['BLENDER_SHA256']==C['archive_sha256']
 archive=Path(C['pinned_archive']);assert archive.is_file()and a.blender.is_file()
 with archive.open('rb')as f:archive_sha=stream_sha(f)
 assert archive_sha==pinfields['BLENDER_SHA256'],'pinned archive hash mismatch'
 with a.blender.open('rb')as f:installed_sha=stream_sha(f)
 member_name=pinfields['BLENDER_DIR']+'/blender'
 with tarfile.open(archive,'r:xz')as tar:
  member=tar.getmember(member_name);assert member.isfile()and member.size==a.blender.stat().st_size
  f=tar.extractfile(member);assert f is not None
  with f:archive_executable_sha=stream_sha(f)
 assert installed_sha==archive_executable_sha,'installed executable does not equal the exact verified pin archive member'
 state['blender_proof']={'archive':str(archive),'archive_sha256':archive_sha,'pin_sha256':sha(pin.read_bytes()),'executable':str(a.blender),'executable_sha256':installed_sha,'archive_executable_sha256':archive_executable_sha,'archive_member':member_name,'executable_matches_pinned_archive':True};save()
 run('00-pinned-blender-version',[a.blender,'--version'],timeout=60)
 assert (out/'00-pinned-blender-version.log').read_text().splitlines()[0]=='Blender '+pinfields['BLENDER_VERSION']
 assert sha((root/'generators/archetypes/fort_structure.py').read_bytes())==C['repaired_producer_sha256'],'rebind changed backend; do not overlay an old producer'
 assert (root/'generators/archetypes/fort_structure_params.py').read_bytes()==(REVISED/'frozen/fort_structure_params.py').read_bytes()
 record=root/'data/structures'/f'{SID}.json';assert sha(record.read_bytes())==C['record_preimage_sha256']
 sources=load(REVISED/'EXISTING-SOURCES.json');metadata={}
 for sid,expected in sources.items():
  p=root/'data/sources'/f'{sid}.json';assert load(p)==expected,('source record changed',sid);metadata[str(p.relative_to(root))]={'raw_sha256':sha(p.read_bytes()),'semantic_sha256':sha(json.dumps(expected,sort_keys=True).encode())}
 claims=load(root/'data/research/books/claims/hubbard_autobiography_1911.json')['claims'];selected=[x for x in claims if x['id']in ['bk_hub_055','bk_hub_090']];assert selected==load(REVISED/'EXISTING-CLAIMS.json')
 rulings=load(root/'data/research/spend_rulings.json');rows=rulings.get('rulings',rulings.get('entries',[]));selected=[v for v in rows if 'bk_hub_055'in json.dumps(v)or'bk_hub_090'in str(v.get('unit',''))];assert selected==load(REVISED/'EXISTING-UNRESOLVED-RULINGS.json')
 for rel in ['data/research/books/claims/hubbard_autobiography_1911.json','data/research/spend_rulings.json']:
  metadata[rel]={'raw_sha256':sha((root/rel).read_bytes())}
 for p in sorted(REVISED.rglob('*')):
  if p.is_file():metadata['external_revised_packet/'+str(p.relative_to(REVISED))]={'raw_sha256':sha(p.read_bytes())}
 (out/'SOURCE-PROVENANCE-HASHES.json').write_text(json.dumps(metadata,indent=2)+'\n')
 sys.path.insert(0,str(root/'generators'));import mesh_inputs
 manifest=root/'assets/manifest.json';webmanifest=root/'assets/manifest.web.json';before=load(manifest);webbefore=load(webmanifest);rows=before['assets'];fort={k:v for k,v in rows.items()if v.get('archetype')=='fort_structure'};assert len(fort)==25
 baseline_inputs={}
 for k,row in fort.items():
  st=load(root/'data/structures'/f'{row["structure_id"]}.json');phase=next(x for x in st['phases']if x['id']==row['phase_id']);doc=mesh_inputs.structure_inputs_doc(st,phase,'fort_structure');actual=sha(json.dumps(doc,sort_keys=True).encode());assert actual==row['inputs_sha256'],('baseline fort recipe not fresh',k);baseline_inputs[k]={'inputs_sha256':actual,'doc':doc}
  master=root/'assets/gltf'/k;assert len(master.read_bytes())==row['bytes']and sha(master.read_bytes())==webbefore['masters'][k];assert (root/'assets/web'/k).is_file()
 candidate=load(REVISED/'candidate'/f'{SID}.json');candidate_sha=mesh_inputs.structure_inputs_sha(candidate,candidate['phases'][0],'fort_structure');assert candidate_sha!=rows[KEY]['inputs_sha256']
 protected={}
 for directory in ['gltf','web']:
  for p in (root/'assets'/directory).rglob('*.glb'):
   if p!=root/'assets'/directory/KEY:protected[str(p.relative_to(root))]=sha(p.read_bytes())
 (out/'BASELINE25-INPUTS.json').write_text(json.dumps(baseline_inputs,indent=2)+'\n');(out/'PROTECTED-GLB-HASHES.json').write_text(json.dumps(protected,indent=2)+'\n')
 backup=out/'baseline-held';backup.mkdir();(backup/'record.json').write_bytes(record.read_bytes());(backup/'manifest.json').write_bytes(manifest.read_bytes());(backup/'manifest.web.json').write_bytes(webmanifest.read_bytes())
 for directory in ['gltf','web']:(backup/(directory+'.glb')).write_bytes((root/'assets'/directory/KEY).read_bytes())
 sidecar_hashes={rel:sha((root/rel).read_bytes())for rel in ['data/scenes/1835.json','data/sidecars/1835/'+SID+'.json','data/sidecars/1835/fort_dearborn_commandants_quarters.json']}
 photo=(PRIOR/'source/fortdearborn1855.jpg').read_bytes();photo_sha=sha(photo);cambytes=(P/'camera1855-diagnostic.json').read_bytes()
 for leg in ['before','after']:
  target=out/leg;(target/'cameras').mkdir(parents=True);(target/'source').mkdir();(target/'cameras/camera1855-diagnostic.json').write_bytes(cambytes);(target/'source/fortdearborn1855.jpg').write_bytes(photo)
 state.update({'candidate_recipe_sha256':candidate_sha,'baseline_recipe_sha256':rows[KEY]['inputs_sha256'],'baseline25_fresh':True,'source_metadata_guarded':True,'scene_and_context_sidecar_hashes':sidecar_hashes,'camera_sha256':sha(cambytes),'photo_sha256':photo_sha,'protected_unrelated_glbs':len(protected)});save()
 run('01-before1855-diagnostic',['node','tools/photo_match.mjs',out/'before/cameras/camera1855-diagnostic.json','--out',out/'before/comparisons'])
 # Only the assigned isolated checkout is changed, and only after all preimages passed.
 record.write_bytes((REVISED/'candidate'/f'{SID}.json').read_bytes());assert sha(record.read_bytes())==C['candidate_sha256'];state['isolated_candidate_applied']=True;save()
 assert a.blender.is_file();run('02-official-one-master',[a.blender,'-b','-noaudio','--factory-startup','--python','generators/build.py','--','--only',SID,'--scene','1835','--wrote',out/'wrote.txt'])
 assert (out/'wrote.txt').read_text().splitlines()==[KEY]
 aftermaster=load(manifest);assert {k:v for k,v in aftermaster['assets'].items()if k!=KEY}=={k:v for k,v in rows.items()if k!=KEY};assert {k:v for k,v in aftermaster.items()if k!='assets'}=={k:v for k,v in before.items()if k!='assets'};assert aftermaster['assets'][KEY]['inputs_sha256']==candidate_sha
 assert load(webmanifest)==webbefore and (root/'assets/web'/KEY).read_bytes()==(backup/'web.glb').read_bytes()
 master_sha=sha((root/'assets/gltf'/KEY).read_bytes());assert master_sha!=sha((backup/'gltf.glb').read_bytes()),'enabled gallery must produce a real master change';run('03-official-one-web',['bash','tools/web_derivatives.sh','--only',KEY])
 assert load(manifest)==aftermaster and sha((root/'assets/gltf'/KEY).read_bytes())==master_sha
 afterweb=load(webmanifest);assert {k:v for k,v in afterweb['masters'].items()if k!=KEY}=={k:v for k,v in webbefore['masters'].items()if k!=KEY};assert {k:v for k,v in afterweb.items()if k!='masters'}=={k:v for k,v in webbefore.items()if k!='masters'};assert afterweb['masters'][KEY]==master_sha
 for rel,h in protected.items():assert sha((root/rel).read_bytes())==h,('unrelated GLB changed',rel)
 for rel,h in sidecar_hashes.items():assert sha((root/rel).read_bytes())==h,('native placement/sidecar changed',rel)
 run('04-after1855-diagnostic',['node','tools/photo_match.mjs',out/'after/cameras/camera1855-diagnostic.json','--out',out/'after/comparisons'])
 for rel,h in sidecar_hashes.items():assert sha((root/rel).read_bytes())==h
 for rel,h in protected.items():assert sha((root/rel).read_bytes())==h
 for rel,row in metadata.items():
  if not rel.startswith('external_revised_packet/'):assert sha((root/rel).read_bytes())==row['raw_sha256'],('source/provenance changed',rel)
 allowed={'chicago/4d/data/structures/'+SID+'.json','chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json','chicago/4d/assets/gltf/'+KEY,'chicago/4d/assets/web/'+KEY}
 changed=set(subprocess.check_output(['git','-C',str(repo),'diff','--name-only'],text=True).splitlines());assert changed<=allowed,('unexpected tracked delta',sorted(changed-allowed))
 assert not subprocess.check_output(['git','-C',str(repo),'ls-files','--others','--exclude-standard'],text=True),'unexpected untracked output'
 assert sha((root/'assets/web'/KEY).read_bytes())!=sha((backup/'web.glb').read_bytes())
 state['actual_tracked_delta']=sorted(changed)
 state.update({'status':'ACTUAL_PRIVATE_TRIAL_COMPLETE_PENDING_HUMAN_IMAGE_REVIEW_NOT_A_MATCH','master_sha256':master_sha,'web_sha256':sha((root/'assets/web'/KEY).read_bytes()),'one_master_and_web_production_passed':True,'all_unrelated_rows_assets_and_placements_exact':True,'native_writer':'NOT_RUN','appQA':'NOT_RUN','identity_ruling':'NOT_MADE','image_acceptance':'Original16DIFFERS retained; no matches. New1855diagnostic pixels await actual human review.'})
except BaseException as error:
 state.update({'status':'FAIL_PRESERVED','error':str(error),'traceback':traceback.format_exc()});raise
finally:
 state['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
