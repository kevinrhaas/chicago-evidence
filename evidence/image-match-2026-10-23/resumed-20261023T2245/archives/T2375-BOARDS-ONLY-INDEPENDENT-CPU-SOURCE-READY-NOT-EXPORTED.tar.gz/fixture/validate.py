"""Serial single-CPU actual-source mesh/API checks; no Blender/export/browser."""
from pathlib import Path
import ast, copy, dataclasses, hashlib, importlib.util, inspect, json, math, os, sys, time, types
sys.dont_write_bytecode=True
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
HERE=Path(__file__).resolve().parent
BASE=HERE/'before/chicago/4d';NEW=HERE/'candidate/chicago/4d'
OLD=Path('/tmp/chicago-next-model/T-2375/preview/fixture')
COMMON=HERE/'common-runtime/chicago/4d'
sys.path.insert(0,str(COMMON/'generators'))
sys.modules.setdefault('bpy',types.ModuleType('bpy'))
from common import mesh
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec)
 sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
def pair(tag,root):
 p=load(tag+'_params',root/'generators/archetypes/bridge_timber_params.py')
 sys.modules['archetypes.bridge_timber_params']=p
 b=load(tag+'_builder',root/'generators/archetypes/bridge_timber.py')
 class Raw(mesh.MeshBuilder):
  def __init__(self,name):super().__init__(name);self.boxes=[]
  def add_box(self,*args,**kw):self.boxes.append((args,kw));return super().add_box(*args,**kw)
  def to_object(self,mats=None):self.material_calls=mats;return self
 b.MeshBuilder=Raw;b.simple_material=lambda name,*a,**kw:dict(name=name,args=a,kwargs=kw)
 return p,b
legacy,old=pair('base',BASE);rendered,preview=pair('rendered_board',OLD);candidate,new=pair('selected_board',NEW)
def raw(b,p,name):
 obj=b.build(p,name)
 return {k:getattr(obj,k) for k in ['verts','faces','conf','mat_index','named','material_calls']}
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
start=time.monotonic();inputs=json.loads((HERE/'inputs.json').read_text())
sig0=inspect.signature(legacy.BridgeTimberParams);sig1=inspect.signature(candidate.BridgeTimberParams)
assert len(sig0.parameters)==20
assert list(sig0.parameters.values())==[p for p in sig1.parameters.values() if p.kind!=inspect.Parameter.KEYWORD_ONLY]
assert {p.name:p.default for p in sig1.parameters.values() if p.kind==inspect.Parameter.KEYWORD_ONLY}=={'railing_kind':'pole'}
assert legacy.BridgeTimberParams.__match_args__==candidate.BridgeTimberParams.__match_args__
for name in sig0.parameters:
 a=legacy.BridgeTimberParams.__dataclass_fields__[name];b=candidate.BridgeTimberParams.__dataclass_fields__[name]
 for attr in ['default','default_factory','init','repr','hash','compare','kw_only']:assert getattr(a,attr)==getattr(b,attr),(name,attr)
def class_fields(path):
 tree=ast.parse(path.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='BridgeTimberParams')
 return [(n.target.id,ast.dump(n,include_attributes=False)) for n in cls.body if isinstance(n,ast.AnnAssign)]
a=class_fields(BASE/'generators/archetypes/bridge_timber_params.py');b=class_fields(NEW/'generators/archetypes/bridge_timber_params.py')
assert a==[v for v in b if v[0]!='railing_kind']
rows=[]
for row in inputs['six_family']:
 record=json.loads((BASE/'data/structures'/f"{row['structure_id']}.json").read_text())
 phase=next(p for p in record['phases'] if p['id']==row['phase_id'])
 op=legacy.from_phase(phase,record);np=candidate.from_phase(phase,record)
 assert np.railing_kind=='pole'
 assert all(getattr(op,n)==getattr(np,n) for n in sig0.parameters)
 args=[copy.deepcopy(getattr(op,n)) for n in sig0.parameters]
 positional0=legacy.BridgeTimberParams(*args);positional1=candidate.BridgeTimberParams(*args)
 positional0.validate();positional1.validate()
 assert all(getattr(positional0,n)==getattr(positional1,n) for n in sig0.parameters)
 try:candidate.BridgeTimberParams(*args,'board')
 except TypeError:pass
 else:raise AssertionError('new field accepted positionally')
 ra=raw(old,op,row['asset']);rb=raw(new,np,row['asset']);assert ra==rb,row['asset']
 oa=raw(old,dataclasses.replace(op,railing=False),row['asset']);nb=raw(new,dataclasses.replace(np,railing=False),row['asset']);assert oa==nb
 rows.append({'asset':row['asset'],'old_positional20_exact':True,'default_raw_geometry_confidence_material_calls_exact':True,'disabled_railing_exact':True,'raw_sha256':digest(ra),'vertices':len(ra['verts']),'faces':len(ra['faces'])})

record=json.loads((NEW/'data/structures/dearborn_street_drawbridge.json').read_text());phase=record['phases'][0];np=candidate.from_phase(phase,record)
preview_record=json.loads((OLD/'data/structures/dearborn_street_drawbridge.json').read_text());preview_phase=preview_record['phases'][0];rp=rendered.from_phase(preview_phase,preview_record)
assert dataclasses.asdict(np)==dataclasses.asdict(rp)
rb=raw(new,np,'dearborn_street_drawbridge__draw_1834');rpraw=raw(preview,rp,'dearborn_street_drawbridge__draw_1834')
assert rb==rpraw,'candidate changed actual rendered board-only raw stream'
assert len(rb['verts'])==27100 and len(rb['faces'])==6711
assert all(math.isfinite(x) for v in rb['verts'] for x in v)
assert all(len(set(f))>=3 for f in rb['faces'])
assert 'railing_kind' in candidate.CONSUMED and np.conf('railing_kind')==.5
for k in ['draw_profile','draw_rise_m','draw_bearing_supports']:assert not hasattr(np,k) and k not in candidate.CONSUMED
op=legacy.from_phase(json.loads((BASE/'data/structures/dearborn_street_drawbridge.json').read_text())['phases'][0])
assert raw(new,dataclasses.replace(np,railing=False,railing_kind='pole'),'off')==raw(old,dataclasses.replace(op,railing=False),'off')
assert np.pier_x==op.pier_x and np.deck_height_m==op.deck_height_m
rail=new.MeshBuilder('rail');new._railing(rail,np,np.deck_height_m,np.conf('railing'))
boards=[];caps=[];posts=[]
for args,kw in rail.boxes:
 x0,y0,z0,x1,y1,z1,c,mat=args;assert x0<x1 and y0<y1 and z0<z1 and c==.5
 if mat==new.M_LOG:posts.append(args)
 elif math.isclose(z1,np.deck_height_m+.95,abs_tol=1e-8):caps.append(args)
 else:boards.append(args)
assert (len(boards),len(caps),len(posts))==(380,76,72)
for a in boards+caps:
 for cut in [np.span_m/2-np.draw_span_m/2,np.span_m/2,np.span_m/2+np.draw_span_m/2]:assert not a[0]<cut<a[3]
 assert np.deck_height_m<=a[2]<a[5]<=np.deck_height_m+.95+1e-9
for a in posts:
 assert math.isclose(a[5],np.deck_height_m+.89,abs_tol=1e-8)
 for b in caps:assert min(a[5],b[5])-max(a[2],b[2])<=1e-9
neg=[]
for value in ['glass','',None,False,7]:
 for through_phase in [False,True]:
  try:
   if through_phase:
    bad=copy.deepcopy(phase);bad['form']['railing_kind']['value']=value;candidate.from_phase(bad,record)
   else:dataclasses.replace(np,railing_kind=value).validate()
  except candidate.ParamError:pass
  else:raise AssertionError(('bad railing kind accepted',value,through_phase))
 neg.append({'invalid_railing_kind':value,'direct_and_phase_refuse':True})
try:dataclasses.replace(np,railing=False).validate()
except candidate.ParamError:pass
else:raise AssertionError('board without enabled railing accepted')
# The archived positional field is an explicit counterexample, not just a signature check.
args=[copy.deepcopy(getattr(op,n)) for n in sig0.parameters]
broken=rendered.BridgeTimberParams(*args)
assert any(getattr(broken,n)!=getattr(op,n) for n in sig0.parameters)
# The exact target guard distinguishes the old open poles from board infill.
assert digest(raw(new,dataclasses.replace(np,railing_kind='pole'),'compare'))!=digest(raw(new,np,'compare'))
report={'scope':'ONE_CPU_SERIAL actual source raw streams/material call specs; bpy object/material emission stubbed; NOT Blender/export/app/normal acceptance',
 'elapsed_s':round(time.monotonic()-start,3),'affinity_cpus':sorted(os.sched_getaffinity(0)),
 'legacy20_positional_names_order_defaults_factories_annotations_AST_match_args_exact':True,
 'only_new_kwonly_field':{'railing_kind':'pole'},'current_six_defaults':rows,
 'candidate_target_equals_actually_rendered_board_only_raw_stream':True,'target_raw_sha256':digest(rb),
 'target_vertices':len(rb['verts']),'target_faces':len(rb['faces']),'actual_preview_export_triangles':13678,
 'target_flat_deck_original_piers_no_other_geometry_exact':True,
 'board_cap_post_counts':[len(boards),len(caps),len(posts)],'leaf_boundaries_cap_post_clearance_positive':True,
 'negative_controls':neg+[{'board_without_railing':'refused'},{'archived_positional_API_regression':'detected'},{'target_infill_pole_mutation':'detected'}],
 'shared_family_native_recipe_refresh_required':6,'official_exports_browser_fullgate':'NOT_RUN','image_verdict':'DIFFERS'}
(HERE/'cpu-api-proof.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS legacy20 API/AST; six default+disabled streams exact; target rendered board-only stream exact; positive/negative controls; seconds',report['elapsed_s'])
