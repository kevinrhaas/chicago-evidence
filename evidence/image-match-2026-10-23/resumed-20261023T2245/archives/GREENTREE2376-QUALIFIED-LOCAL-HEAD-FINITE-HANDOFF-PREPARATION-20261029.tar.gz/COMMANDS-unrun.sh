#!/usr/bin/env bash
# Prepared commands only. Root must supply the actual qualified pre-GT native HEAD
# and explicit source lease AFTER the stated four-ticket handoff conditions close.
set -euo pipefail
: "${GT_PRE_GT_HEAD:?Set the exact clean qualified four-ticket BE501 native merge HEAD}"
: "${GT_HANDOFF_READY:?Set to source-lease-granted-after-four-checkpoint-and-lap-release}"
[ "$GT_HANDOFF_READY" = source-lease-granted-after-four-checkpoint-and-lap-release ]
source /workspace/shared/resume-chicago-env.sh
GT_FINAL_REPO=/workspace/chicago
GT_PREP=/workspace/T2376-authored-adoption-preparation-20261029
GT_HANDOFF=/workspace/T2376-qualified-local-handoff-20261029
GT_LOCAL_BRANCH=steward/t2376-green-tree-current-four-20261029
[ "$(git -C "$GT_FINAL_REPO" rev-parse HEAD)" = "$GT_PRE_GT_HEAD" ]
[ -z "$(git -C "$GT_FINAL_REPO" status --porcelain --untracked-files=no)" ]
git -C "$GT_FINAL_REPO" switch -c "$GT_LOCAL_BRANCH"
python3 "$GT_PREP/capture_before_adoption.py" --repo "$GT_FINAL_REPO" --expected-head "$GT_PRE_GT_HEAD" --out /workspace/T2376-current-four-before-adoption-20261029
python3 "$GT_PREP/prepare_adoption.py" --target "$GT_FINAL_REPO" --expected-head "$GT_PRE_GT_HEAD" --out /workspace/T2376-current-four-authored-candidates-20261029
# Root reviews this concrete newly-bound candidate packet before invoking the
# following copy step; this unrun command list deliberately stops here by default.
[ "${GT_REVIEWED_AUTHORED_UNION:-pending}" = reviewed36-with-current-shared-unions ]
export GT_ADOPTION_READY=leased-same-qualified-head-nativeclaim-current
python3 "$GT_HANDOFF/apply_candidates.py" --repo "$GT_FINAL_REPO" --candidate /workspace/T2376-current-four-authored-candidates-20261029 --expected-head "$GT_PRE_GT_HEAD" --expected-branch "$GT_LOCAL_BRANCH" --receipt /workspace/T2376-current-four-authored-adoption-receipt-20261029.json
export GT_NATIVE_READY=leased-current-authored-source-adopted
export GT_NATIVE_REPO_ROOT="$GT_FINAL_REPO"
export GT_NATIVE_BEFORE=/workspace/T2376-current-four-before-adoption-20261029
export GT_NATIVE_OUT=/workspace/T2376-current-four-native-20261029
cd "$GT_FINAL_REPO/chicago/4d"
python3 /workspace/shared/run-with-reaping.py /workspace/T2376-current-four-native-reaper-20261029.json -- nice -n 19 taskset -c 0,1 /workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender -b -noaudio --factory-startup --threads 2 --python-exit-code 1 --python "$GT_PREP/run_final_native.py" > /workspace/T2376-current-four-native-controller-20261029.log 2>&1
python3 /workspace/shared/run-with-reaping.py /workspace/T2376-current-four-web-reaper-20261029.json -- nice -n 19 taskset -c 0,1 bash tools/web_derivatives.sh --only green_tree_tavern__frame_1833.glb,versions/green_tree_tavern/andreas-reading/green_tree_tavern__frame_1833.glb,versions/tremont_house_1/gale-reading/tremont_house_1__frame_1833.glb,versions/tremont_house_1/gifford-reading/tremont_house_1__frame_1833.glb > /workspace/T2376-current-four-web-20261029.log 2>&1
export GT_CAMERA_READY=leased-native-production-closed
python3 /workspace/shared/run-with-reaping.py /workspace/T2376-current-four-cameras-reaper-20261029.json -- python3 "$GT_HANDOFF/run_current_cameras.py" --repo "$GT_FINAL_REPO" --native-result /workspace/T2376-current-four-native-20261029/RESULT.json --out /workspace/T2376-current-four-three-cameras-20261029 > /workspace/T2376-current-four-cameras-20261029.log 2>&1
# Direct human comparison + native feet/ground/neighbor/appendage qualification,
# actual current-dev composition, full owners/publish and app/global gates remain.
