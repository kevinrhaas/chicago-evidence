#!/usr/bin/env python3
"""Current native-only neutral-plane comparisons; canonical match files are actual tool outputs."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess
assert os.environ.get('GT_CAMERA_READY')=='leased-native-production-closed','Require source lease and completed native production'
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--native-result',required=True);p.add_argument('--out',required=True);a=p.parse_args()
r=Path(a.repo).resolve();s=r/'chicago/4d';out=Path(a.out).resolve();assert not out.exists() and r not in out.parents
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native=json.loads(Path(a.native_result).read_text());assert native['status']=='ACTUAL_CURRENT25_NONE_CONTROLS_AND23_ID_NATIVE_PRODUCTION_PASS' and native['repo']==str(r)
for e in native['candidates']:assert sha(s/e['path'])==e['sha256']
out.mkdir(mode=0o700);sources=s/'data/reference_views/green_tree_tavern';optional=out/'optional-camera-root/chicago/4d/data/reference_views/green_tree_tavern/andreas_1838.json';optional.parent.mkdir(parents=True)
# Runtime lookup only. A later archive must enumerate regular output members and
# must not traverse or archive this reference symlink or its target tree.
ref=out/'optional-camera-root/chicago/reference';ref.symlink_to(s.parent/'reference',target_is_directory=True);shutil.copy2(sources/'andreas_1838.json',optional)
rows=[]
for label,camera,asset in [('canonical-andreas',sources/'andreas_1838.json','assets/gltf/green_tree_tavern__frame_1833.glb'),('optional-andreas',optional,'assets/gltf/versions/green_tree_tavern/andreas-reading/green_tree_tavern__frame_1833.glb'),('canonical-trowbridge',sources/'trowbridge_1902.json','assets/gltf/green_tree_tavern__frame_1833.glb')]:
 before=camera.read_bytes();cam=json.loads(before);assert cam['diagnostic_only']is True and cam['library_image'].startswith('early-green-tree-');target=out/label;reaper=out/(label+'-REAPER.json')
 cmd=['python3','/workspace/shared/run-with-reaping.py',str(reaper),'--','nice','-n','19','taskset','-c','3,4','node','tools/photo_match.mjs',str(camera),'--glb',asset,'--out',str(target)]
 with(out/(label+'.log')).open('x')as f:q=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT)
 assert q.returncode==0,(label,q.returncode);assert camera.read_bytes()==before;receipt=json.loads(reaper.read_text());assert receipt['command_exit']==0 and receipt['all_children_reaped']
 match=camera.with_suffix('.match.json');m=json.loads(match.read_text());assert m['glb_sha256']==sha(s/asset) and m['camera_sha256']==sha(camera);assert m['verdict']in ['unreviewed','differs','matches']
 rows.append({'case':label,'camera_path':str(camera),'camera_sha256':sha(camera),'asset':asset,'master_sha256':sha(s/asset),'photo_sha256':m['photo_sha256'],'match_path':str(match),'match_sha256':sha(match),'native_tool_verdict':m['verdict'],'side_by_side':str(target/(camera.stem+'-side-by-side.jpg')),'side_by_side_sha256':sha(target/(camera.stem+'-side-by-side.jpg')),'actual_capture_only_human_review_still_required':True,'canonical_gate':not label.startswith('optional'),'all_children_reaped':True})
result={'status':'ACTUAL_CURRENT_LOCAL_NATIVE_THREE_CAMERA_CAPTURES_CLOSED_REVIEW_PENDING','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repo':str(r),'native_result_sha256':sha(Path(a.native_result)),'rows':rows,'limits':'Neutral-plane form comparisons only. Root must directly view all three and applyT3153 before matches. No published app/phone/ground/globalfixedpoint/sourcefullgate/devmerge/ticketcompletion claim. Optional input exists outside canonical gate and cannot overwrite it. Exclude runtime reference symlink from all archives.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'captures':3,'all_children_reaped':True}))
