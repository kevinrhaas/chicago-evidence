#!/usr/bin/env python3
"""Explicitly leased authored-source copy, no index/ref/config/commit writes."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess
assert os.environ.get('GT_ADOPTION_READY')=='leased-same-qualified-head-nativeclaim-current','Require explicit source lease and renewed actual native claim'
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--candidate',required=True);p.add_argument('--expected-head',required=True);p.add_argument('--expected-branch',required=True);p.add_argument('--receipt',required=True);a=p.parse_args()
r=Path(a.repo).resolve();packet=Path(a.candidate).resolve();receipt=Path(a.receipt).resolve();assert not receipt.exists() and r not in receipt.parents
sha=lambda b:hashlib.sha256(b).hexdigest();env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*args):return subprocess.check_output(['git','-C',str(r),*args],env=env).decode().strip()
assert git('rev-parse','HEAD')==a.expected_head and git('branch','--show-current')==a.expected_branch
assert a.expected_branch.startswith('steward/t2376-') and git('status','--porcelain','--untracked-files=no')==''
d=json.loads((packet/'RESULT.json').read_text());assert d['status']=='READ_ONLY_AUTHORED_SOURCE_UNION_CANDIDATES_NO_ADOPTION_OR_GENERATED_PROOF' and d['observed_target_head']==a.expected_head and d['target']==str(r) and d['candidate_count']==36
post=[];protected={}
for row in d['rows']:
 path=row['path'];assert path.startswith('chicago/4d/') or path.startswith('chicago/prairie_1904_v1/research/images/');assert not any(x in Path(path).parts for x in ['..','.git']);q=r/path;s=packet/'postimages'/path
 assert not q.is_symlink() and not s.is_symlink() and s.is_file()
 assert(sha(q.read_bytes())if q.exists()else None)==row['current_sha256'],'Source preimage changed '+path
 raw=s.read_bytes();assert sha(raw)==row['candidate_sha256'] and len(raw)==row['bytes'];post.append((q,raw,row['git_mode']))
for row in d['protected_producers']:
 q=r/row['path'];protected[row['path']]=sha(q.read_bytes());assert protected[row['path']]==row['sha256']
# All preimages have been validated before the first write. No caller source work may run concurrently.
for q,raw,mode in post:
 q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw);q.chmod(0o755 if mode=='100755'else 0o644)
for row in d['rows']:assert sha((r/row['path']).read_bytes())==row['candidate_sha256']
for path,digest in protected.items():assert sha((r/path).read_bytes())==digest
assert git('rev-parse','HEAD')==a.expected_head and git('branch','--show-current')==a.expected_branch
receipt.write_text(json.dumps({'status':'ACTUAL_AUTHORED36_SOURCE_ADOPTED_HEAD_REFS_INDEX_UNCOMMITTED_NATIVE_STILL_PENDING','head':a.expected_head,'branch':a.expected_branch,'candidate_result_sha256':sha((packet/'RESULT.json').read_bytes()),'source_rows':d['rows'],'protected_producers':d['protected_producers'],'limits':'No native assets, WEB, camera, owner-tail/publish, phone/app, fullsource, PR or dev-merge result implied.'},indent=2)+'\n');print('Authored36 adopted; actual current native outputs remain owed.')
