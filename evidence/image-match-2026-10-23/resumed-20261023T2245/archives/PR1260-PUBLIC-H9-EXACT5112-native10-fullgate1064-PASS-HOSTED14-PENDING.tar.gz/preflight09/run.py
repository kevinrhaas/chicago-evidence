from pathlib import Path
import subprocess,json,datetime,os,hashlib,shutil,sys
r=Path('/workspace/primary-human-runner-compat/chicago/4d');o=Path(__file__).resolve().parent;n=Path('/workspace/PR1260-dev30-reconcile09');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();git=lambda *a:subprocess.check_output(['git',*a],cwd=r)
env={**os.environ,'TMPDIR':'/workspace/tmp-t3081','PATH':'/workspace/shared/tools/usr/bin:'+os.environ['PATH'],'CHECK_JOBS':'4','C4D_GATE_REQUIRE_READERS':'1','PYTHONDONTWRITEBYTECODE':'1','npm_config_cache':'/workspace/shared/npm-cache'}
s={'status':'NATIVE_RUNNING','started':now(),'controller_pid':os.getpid(),'HEAD':git('rev-parse','HEAD').decode().strip(),'incoming':git('rev-parse','MERGE_HEAD').decode().strip(),'stages':[]};save=lambda:(o/'receipt.json').write_text(json.dumps(s,indent=2)+'\n');save()
def stage(label,cmd):
 row={'name':label,'command':cmd,'started':now()};s['stages'].append(row);save()
 with(o/(label+'.log')).open('x')as f:p=subprocess.Popen(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();rc=p.wait()
 row.update(exit_code=rc,finished=now());save();assert rc==0,label
try:
 stage('native09',['python3',str(n/'run_native.py')]);stage('105-asset-guards',['python3',str(n/'check_asset_guards.py')])
 assert json.loads((n/'receipt.json').read_bytes())['status']=='PASS'
 assert not git('diff','--name-only','--diff-filter=U').strip()
 subprocess.run(['git','add','chicago/4d'],cwd=r.parent.parent,check=True)
 assert not git('diff','--name-only').strip();assert not git('ls-files','--others','--exclude-standard').strip()
 initial=git('write-tree').decode().strip();patch=git('diff','--cached','--binary',s['incoming']);(o/'own-source-against-incoming.patch').write_bytes(patch);s.update(status='PREFLIGHT_RUNNING',index_tree=initial,source_patch_sha256=hashlib.sha256(patch).hexdigest(),CHECK_JOBS=4,C4D_GATE_REQUIRE_READERS=1);save()
 stage('preflight',['bash','./tools/preflight.sh'])
 s['source_bytes_unchanged']=git('write-tree').decode().strip()==initial and not git('diff','--name-only').strip() and git('diff','--cached','--binary',s['incoming'])==patch
 assert s['source_bytes_unchanged'],'source moved'
 s['status']='PASS'
except BaseException as exc:s.update(status='FAILED',error=str(exc));save()
finally:
 for name,src in [('check.log','/tmp/preflight-check.log'),('changelog.log','/tmp/preflight-cl.log'),('ids.log','/tmp/preflight-ids.log')]:
  if Path(src).exists():shutil.copy2(src,o/name);s[name+'_sha256']=hashlib.sha256((o/name).read_bytes()).hexdigest()
 s['finished']=now();save();print(json.dumps(s,indent=2))
sys.exit(0 if s['status']=='PASS'else 1)
