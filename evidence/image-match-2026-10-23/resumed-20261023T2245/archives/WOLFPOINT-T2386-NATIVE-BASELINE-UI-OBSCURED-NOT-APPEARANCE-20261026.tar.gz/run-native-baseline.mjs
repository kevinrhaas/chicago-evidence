import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {nativeRoofProbe} from './native-roof-probe.mjs';
const require=createRequire('/workspace/chicago/chicago/4d/tools/qa.mjs');
const {chromium}=require('playwright');
const OUT='/tmp/WolfPoint-T2386-native-baseline-20261026';
const SITE='/workspace/chicago/site';
const HEAD='132e0e85a9645055de1bfc4544942ec969b14511';
const WEB='340b5339aed7a0b1f75af7bade2bca25d16186133b6663a3823d509fdcc049cd';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=(...a)=>execFileSync('git',['-C','/workspace/chicago',...a],{encoding:'utf8',env:{...process.env,GIT_NO_LAZY_FETCH:'1'}}).trim();
if(git('rev-parse','HEAD')!==HEAD || git('status','--porcelain=v1'))throw Error('Exact clean source head required');
const build=JSON.parse(fs.readFileSync(SITE+'/4d/build.json'));
if(build.version!==HEAD.slice(0,9))throw Error('Wrong native publish stamp');
if(fs.lstatSync(SITE+'/4d').isSymbolicLink())throw Error('Published mirror must be real');
const result={status:'RUNNING_FINITE_NATIVE_BASELINE_NO_MATCH',head:HEAD,build,
  started_at:new Date().toISOString(),cpu_affinity:fs.readFileSync('/proc/self/status','utf8').match(/^Cpus_allowed_list:\s*(.+)$/m)?.[1],
  viewport:{width:1280,height:800,deviceScaleFactor:1},page_errors:[],http_errors:[],request_failures:[],assets:[],views:[],limits:'Two actual normal native free-fly views only. No source change/bake, no source-camera or all8 match verdict. Scene intact; no FPS claim.'};
const save=()=>fs.writeFileSync(OUT+'/RESULT.json',JSON.stringify(result,null,2)+'\n');
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.ktx2':'image/ktx2'};
const server=http.createServer((req,res)=>{
 let file;
 try{file=path.resolve(SITE,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));}
 catch{res.writeHead(400).end();return;}
 if(file!==SITE&&!file.startsWith(SITE+'/')){res.writeHead(403).end();return;}
 try{if(fs.statSync(file).isDirectory())file=path.join(file,'index.html');
 const st=fs.statSync(file);res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Content-Length':st.size,'Cache-Control':'no-cache'});fs.createReadStream(file).pipe(res);
 }catch{res.writeHead(404).end();}
});
let browser,ctx;const responses=[];
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE,args:['--enable-unsafe-swiftshader']});
 ctx=await browser.newContext({viewport:{width:1280,height:800},deviceScaleFactor:1,hasTouch:false});
 const page=await ctx.newPage();page.setDefaultTimeout(600000);
 page.on('pageerror',e=>{result.page_errors.push(String(e));save();});
 page.on('requestfailed',q=>{result.request_failures.push({url:q.url(),error:q.failure()});save();});
 page.on('response',r=>{
  if(r.status()>=400)result.http_errors.push({url:r.url(),status:r.status()});
  if(/wolf_point_tavern__log_frame_1828\.glb$|roofs\/(wood_shingles_weathered|roof_boards_weathered)\//.test(r.url()))
   responses.push((async()=>{try{const b=await r.body();result.assets.push({url:r.url(),status:r.status(),bytes:b.length,sha256:hash(b)});}catch(e){result.assets.push({url:r.url(),error:String(e)});}})());
 });
 const t=Date.now();const url=`http://127.0.0.1:${server.address().port}/4d/walk/?year=1835&keep-geometry=1`;
 result.url=url;save();await page.goto(url,{waitUntil:'domcontentloaded',timeout:600000});
 await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:600000,polling:1000});
 result.boot_seconds=(Date.now()-t)/1000;save();
 await page.evaluate(()=>window.__chicago4d.welcome.enter());
 const poses=JSON.parse(fs.readFileSync('/tmp/WolfPoint-T2386-prep-20261026/NATIVE-FIXTURE-UNRUN.json')).poses;
 for(const pose of poses){
  const vstart=Date.now();const proof=await page.evaluate(nativeRoofProbe,pose);
  const p=OUT+'/'+pose.id+'.png';await page.screenshot({path:p,timeout:600000});
  proof.screenshot=path.basename(p);proof.screenshot_sha256=hash(fs.readFileSync(p));proof.elapsed_seconds=(Date.now()-vstart)/1000;
  result.views.push(proof);save();console.log('NATIVE_VIEW_CAPTURED',pose.id,proof.elapsed_seconds);
 }
 await Promise.all(responses);
 if(result.assets.filter(x=>x.url.endsWith('wolf_point_tavern__log_frame_1828.glb')).some(x=>x.sha256!==WEB))throw Error('Actual loaded Wolf bytes differ');
 if(!result.assets.some(x=>x.url.endsWith('wolf_point_tavern__log_frame_1828.glb')&&x.sha256===WEB))throw Error('Actual Wolf HTTP bytes not proven');
 if(result.page_errors.length||result.http_errors.length||result.request_failures.length)throw Error('Actual app/network errors recorded');
 result.source_status_after=git('status','--porcelain=v1');
 if(result.source_status_after)throw Error('Source changed');
 result.status='TWO_ACTUAL_NATIVE_VIEWS_REQUIRES_DIRECT_VISUAL_REVIEW_NO_MATCH';result.exit_code=0;
}catch(e){result.status='FAILED_NO_MATCH';result.error=String(e?.stack||e);result.exit_code=1;console.error(result.error);}
finally{
 try{await ctx?.close();await browser?.close();await new Promise(r=>server.close(r));result.cleanup='browser/context/server closed';}catch(e){result.cleanup_error=String(e);result.exit_code=1;}
 result.ended_at=new Date().toISOString();result.elapsed_seconds=(Date.parse(result.ended_at)-Date.parse(result.started_at))/1000;save();
}
console.log(result.status,JSON.stringify({elapsed_seconds:result.elapsed_seconds,page_errors:result.page_errors.length,views:result.views.length}));
process.exitCode=result.exit_code;
