

### T-2385 roof contrast increment

Track the isolated deep_brown per-Tremont stock through an official 23-master frame-family rebuild, real web derivatives and current native/published gates. Keep existing frame defaults and population allocations unchanged. The actual quarter-linear roof study improves contrast; full image-match work remains on T-2385, including shutters/entries, uncertain source camera and scene/context. A separate broad-left flag-pose research capture is unadopted and outside this increment. The roof PR does not close original image-match acceptance.
