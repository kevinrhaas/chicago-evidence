# T-2385 bounded roof integration plan

Prepared against PR #1239 head `a2192528415d04f3b83424447a0b08a766d73825`.
This is LIGHT preparation: no canonical edits, new bake, browser capture or full
gate occurred here. The parent owns adoption, scheduling, PR creation and merge.
Wait for that parent to land, then use a new isolated branch from current dev.
Recheck all four guarded inputs and the family inventory against that actual base;
do not assume that a219's manifest or generated outputs are the next base's outputs.

## Authored scope

Apply only `deep-roof.patch` from the already closed proposal folder named in
`AUTHORING-SCOPE.json`. Its four before hashes match a219 exactly, as recorded in
`A219-BEFORE-GUARDS.json`. Do not copy the proposal's support fixture tree.

The patch extends the existing `roof_colour` enum with `deep_brown`, sets that
material to one quarter of stock darkened linear RGB, preserves alpha 1, and
selects it only in Tremont's `frame_1833` phase. It adds the resolving existing
Gifford source ID to that attributed field and keeps the choice reconstructed.
The meaningful regression verifies material-only change and rejects confidence
stronger than reconstructed. Existing default stocks and constructor names,
argument kinds and defaults remain exact (40 positional and 11 keyword fields).

Append the proposal's `LIBERTY-APPEND.md` to the actual incoming LIBERTIES bytes;
never replace or decode/rewrite its existing prefix. Append the two local
STATUS/ROADMAP drafts, updating their build/gate wording to receipts actually
obtained. Add one pending changelog file from the local validated template under
the actual progress ticket ID. Keep the original image-match ticket open; a
bounded progress PR does not establish that the picture matches.

No source JSON, asset-license entry, general material stock, schema, new parameter,
name-pool registry or test-isolation entry is needed. Existing source attribution,
rights status, verification fields and owner-approved project-use limits remain.
There is no public-domain or open-license finding. No image asset is added.

`data/reconstruction/name_pool_keys.json` already reads
`phases[].form.roof_colour.note`; this patch reuses that exact path. Capitalized
words in the changed note still feed the native name pool. Keep its registry
byte-identical and run the actual native pool check on the integrated base.
If any allocation output changes, inspect the native cause and rerun the ordered
sequence from its earliest affected writer. No unchanged-allocation result has
been claimed by this plan. Do not manually repair identity or population tables.

## Exact content scope and prior parity

`CURRENT23-MASTERS.json` records the actual a219 root and web manifests and the
23 current frame-family masters. `frame23-ids.txt` is the comma-separated actual
structure selection; `frame23-masters.txt` is the expected exact written list.
All 23 current phases resolve in the 1835 scene. There are no frame-family
version entries in a219's versions manifest (`VERSION-SCOPE.json`).

The earlier raw CPU proof covered 24 parsable record phases. Its extra case is
Sauganash `log_1829` (1829–1831), whose range covers none of the current 1812,
1835 or 1904 scenes. It is not a 24th current master and is outside this refresh.
Its record archetype is frame_tavern; do not relabel the case as log_dwelling.

`CURRENT23-PARITY-BINDING.json` binds all 23 current phases to that CPU proof:
22 source records are byte-identical; New York House's metadata changed, while
all resolved builder parameters and confidence remain exact. All frame/common
producer dependencies are byte-identical. Earlier proof preserves geometry,
confidence and nonroof material streams for every case, and all material streams
for every non-target case. Only Tremont's roof RGBA changes. This is CPU stream
evidence, not a new official export or a promise of identical UV packing/GLB bytes.

## Scheduled official refresh

Only execute after explicit parent allocation of the heavy slot. Use the actual
pinned cached Blender, verify version and pin, and run the official builder from
the new isolated app directory. The following is a command template, not a run:

```bash
app=/absolute/path/to/new-isolated-checkout/chicago/4d
plan=/tmp/chicago-next-model/T-2385-followup-plan-a219-20261023
blender_bin=/absolute/path/to/pin-verified-cached/blender
roof_wrote=/tmp/T-2385-official-wrote.txt
cd "$app"
roof_ids=$(cat "$plan/frame23-ids.txt")
"$blender_bin" -b -noaudio --factory-startup --python "$app/generators/build.py" -- --only "$roof_ids" --scene 1835 --wrote "$roof_wrote"
```

No `--no-bake` or `--ao`: use the normal UV/export path and the pinned version.
Require the wrote list to equal the rebased current 23-master inventory exactly,
with no missing or extra phase. Shared producer bytes make all 23 recipe hashes
stale even though only Tremont's material changes. Rebuild the actual family;
never substitute old masters, hand-restamp recipe hashes or copy old derivatives.

Derive exactly the actual written masters through the native path:

```bash
tools/web_derivatives.sh --only "$(paste -sd, "$roof_wrote")"
```

Inspect the exported target material and all default geometry/material/confidence
streams. If UV/export packing changes, report and verify it instead of promising
byte identity. Check recipe coverage and stale derivatives with the native tools.
Other families and all canonical flag/wind code remain outside this change.

Run `python3 tools/replace_invented_residents.py --check` for the native name-pool
and seating ownership check. With only the intended note/liberty/data changes
and no upstream population change, rebuild the ordered fixed-point tail beginning
at `tools/compile_liberties.py`:

```bash
node tools/rederive.mjs --tail tools/compile_liberties.py
```

That reaches source-use/liberty/scene outputs through the manifest's own ordered
writers and fixed-point handling. If pool or other earlier inputs moved, start
at the actual earliest affected writer (or run the full native sequence).
Do not invoke compile_scene alone and declare the earlier liberty output settled.
Publish through `tools/publish.sh`; site output remains ignored build output.

`tools/bake.sh` automatically runs a broader build/derivation/publish/check/smoke
chain. Do not launch it as an unscheduled shortcut while another agent owns the
heavy slot. The parent schedules required preflight and both published smoke
viewports and records actual exit statuses before committing/opening/merging.
No gate waiver or silent skipped check is part of this plan.

## Native review and remaining differences

Re-render the actual canonical result through the native loader after the real
bake/derivatives and inspect the full Gifford pair and roof crop. Preserve camera,
time, exposure, lights, nonroof materials, native flag state and global wind.
The three actual GPU studies selected quarter-linear RGB: the selected source
roof patch luma was 57.30, native baseline 148.72, half 101.42, quarter 64.20 and
eighth 39.93. This is an image-relative reconstructed contrast choice; these
numbers do not measure historical pigment, reflectance, weather or roof age.

The separate broad-left TO105.6 flag-pose capture remains unadopted research.
Do not include its runtime holder rotation, new wind state or historical-weather
claim in this roof increment. Review with the canonical native flag baseline.
Tremont still differs in flag, shutters/entries, facade tones, source-camera and
context questions. No accepted reference view or original done status is created.

The three roof captures, producer proposal and both flag attempts are separately
closed and privately archived with full readback. `EVIDENCE-LINKS.json` records
their immutable checkpoint commits. They do not stand in for the new official
build, post-build native review or merge gates.
