

## T-2385 progress — a deeper reconstructed roof contrast

The first Tremont House selects deep_brown, exactly one quarter of the previous darkened-stock linear RGB. Three actual controlled native/GPU comparisons support this image-relative choice: quarter linear RGB is nearest the selected source roof patch and improves the pictured roof/wall contrast. It does not establish pigment, actual weather-blackening, calibrated reflectance or a surface state dated independently to 1835. Existing None/moss_green/dark_brown stocks and all nonroof geometry, material, confidence and constructor defaults are preserved. The Gifford attribution and standing owner-approved project-use rights limits remain.

The bounded authored delta is the roof selector/record, material-only regression and append-only liberty. A content build must refresh all 23 current frame_tavern masters and their web assets because shared producer bytes changed. Build, native review and gates are pending in this draft; replace this sentence with actual receipts before shipping. Original T-2385 remains open and unmatched. The separately reviewed TO105.6 flag pose remains unadopted research; global native wind and flag state remain unchanged.
