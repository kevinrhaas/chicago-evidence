import os
os.sched_setaffinity(0,{1});os.nice(19)
from pathlib import Path
import json,hashlib,datetime
from urllib.request import Request,urlopen
out=Path('/workspace/T2376-kurz-host-publication-20261029')
src=Path('/workspace/T2376-kurz-library-host-preparation-20261029')
repo='kevinrhaas/chicago-images';merge=json.loads((out/'MERGE-VERIFIED.json').read_text())['merge']
def get(url):
    with urlopen(Request(url,headers={'User-Agent':'Chicago-Green-Tree-image-public-verifier','Accept':'application/vnd.github+json'}),timeout=120) as r:
        assert r.status==200;return r.read()
runs=json.loads(get('https://api.github.com/repos/'+repo+'/actions/workflows/pages.yml/runs?per_page=10'))
(out/'PAGES-RUNS.json').write_text(json.dumps(runs,indent=2)+'\n')
actual=[x for x in runs['workflow_runs'] if x['head_sha']==merge]
assert len(actual)==1,'Expected one actual Pages run for merge'
r=actual[0];(out/'PAGES-ACTUAL-RUN.json').write_text(json.dumps(r,indent=2)+'\n')
if r['status']!='completed' or r['conclusion']!='success':
    print(json.dumps({'status':'PENDING_PAGES','run_id':r['id'],'run_status':r['status'],'conclusion':r['conclusion']}),flush=True)
    raise SystemExit(2)
proof=[]
candidate=json.loads((src/'candidate-v1-native-JPEG/RESULT.json').read_text())
for e in [r for r in candidate['postimages'] if r['repo']=='chicago-images' and r['path'].endswith('.jpg')]:
    name=e['path'].split('/')[-1];row={k:e[k] for k in ['bytes','sha256']}
    url='https://kevinrhaas.github.io/chicago-images/prairie-1904/files/'+name
    b=get(url);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],name
    proof.append({'url':url,'HTTP':200,**row,'strict_TLS':True,'native_bytes_exact':True})
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','merge':merge,'Pages_run':r['id'],'Pages_conclusion':r['conclusion'],'files':proof}
(out/'PUBLIC-HTTPS-BYTE-VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
