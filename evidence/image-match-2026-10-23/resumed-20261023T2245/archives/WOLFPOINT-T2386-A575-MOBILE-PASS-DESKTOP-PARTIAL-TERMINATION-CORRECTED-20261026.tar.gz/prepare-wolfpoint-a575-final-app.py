from pathlib import Path
import json,hashlib,subprocess
home=Path('/tmp/WolfPoint-T2386-a575-final-app-20261026');home.mkdir(exist_ok=True);app=Path('/workspace/chicago/chicago/4d')
old=Path('/tmp/WolfPoint-T2386-native-candidate-app-20261026');base='a575dddeed356333423b20361a1f90f3b39a862f'
assert subprocess.check_output(['git','-C','/workspace/chicago','rev-parse','HEAD']).decode().strip()==base
s=(old/'app-qa-prepared.mjs').read_text().replace(str(old),str(home)).replace('34124fabeea096bd1e977f82596ba9df21533320ad57ae2b173ad40102a8bb6d','fdc5ef22a440636e35e4cec15818661f4351f0f4d0c9e506ef36b00422a45210').replace('cb93ad9cd5ea38654737e05002b1f1904be14e54',base)
s=s.replace("network=[],cancelled=[],responses=[],responseWork=[]", "network=[],cancelled=[],responses=[],roofResponses=[],responseWork=[]")
anchor="page.on('requestfailed',r=>"
insert="""page.on('response',r=>{if(/wood_shingles_weathered\\/(material\\.json|wood_shingles_weathered_(normal_gl|orm)\\.(ktx2|webp))$/.test(new URL(r.url()).pathname)&&r.ok())responseWork.push(r.body().then(b=>{const relative=decodeURIComponent(new URL(r.url()).pathname);const file=path.join(root,relative);assert.equal(crypto.createHash('sha256').update(b).digest('hex'),crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'));roofResponses.push({url:r.url(),status:r.status(),bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')});}));});
   """
assert anchor in s;s=s.replace(anchor,insert+anchor)
s=s.replace("   await page.evaluate(async sid=>{const a=window.__chicago4d;a.setConfidenceView(false);a.pick(sid);", "   write('PHASE.json',{phase:'credited-Images-Sources-Building-Liberty',viewport:label,at:new Date().toISOString()});\n   await page.evaluate(async sid=>{const a=window.__chicago4d;a.setConfidenceView(false);a.pick(sid);")
s=s.replace("normalSize:[m.normalMap?.image?.width,m.normalMap?.image?.height],", "normalSize:[m.normalMap?.image?.width,m.normalMap?.image?.height],actualLinearColour:m.color.toArray(),roughness:m.roughness,")
s=s.replace("assert(responses.length);", "assert(responses.length);write(`${label}-served-native-roof-maps.json`,roofResponses);assert(roofResponses.some(r=>/normal_gl/.test(r.url))&&roofResponses.some(r=>/_orm/.test(r.url)),'Actual native roof map responses required');")
s=s.replace("servedTargetWEB:responses,loaderUnexpected", "servedTargetWEB:responses,servedNativeRoofMaps:roofResponses,loaderUnexpected")
(home/'app-qa.mjs').write_text(s)
side=json.loads((app/'data/sidecars/1835/wolf_point_tavern.json').read_bytes());side['entrances']=[r for r in json.loads((app/'data/enclosures/town_entrance_aprons.json').read_bytes())['entrances']if r['structure_id']=='wolf_point_tavern'];(home/'APP-EXPECTED.json').write_text(json.dumps(side,indent=2)+'\n')
files=['data/sidecars/1835/wolf_point_tavern.json','data/structures/wolf_point_tavern.json','assets/gltf/wolf_point_tavern__log_frame_1828.glb','assets/web/wolf_point_tavern__log_frame_1828.glb','data/enclosures/town_entrance_aprons.json','data/pictures/1835.json','data/liberties.json','renderers/web/js/main.js','renderers/web/js/roof-relief.js']
files.extend(str(p.relative_to(app))for p in (app/'assets/textures/chicago_1835_pbr/roofs/wood_shingles_weathered').glob('*')if p.suffix in ['.ktx2','.webp','.json'])
(home/'SOURCE-BINDINGS.json').write_text(json.dumps({'base':base,'ownedWIP':True,'paths':[{'path':str(app/p),'bytes':(app/p).stat().st_size,'sha256':hashlib.sha256((app/p).read_bytes()).hexdigest()}for p in files],'scope':'Two ordinary loads mobile390x780/desktop1280x800, serial contexts max1, normal/ByGrade/publicFly/credits/newLib/existing2door-ground/native caps/errors and actual roof map HTTPbytes. All8 source acceptance not implied; no FPS claim.'},indent=2)+'\n')
print(str(home/'app-qa.mjs'))
