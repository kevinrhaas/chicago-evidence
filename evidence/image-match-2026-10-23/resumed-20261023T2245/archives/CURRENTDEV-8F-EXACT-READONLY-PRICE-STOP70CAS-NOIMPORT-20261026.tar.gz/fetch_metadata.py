from pathlib import Path
import subprocess, os, time, signal, json, shutil
B=Path('/tmp/current-dev-readonly-price-8f-20261026T1443')
R=Path('/tmp/chicago-current-objects-20261025')
assert R.is_dir()
if 4 in os.sched_getaffinity(0): os.sched_setaffinity(0,{4})
command=['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','-c','index.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git','8f70801833aa36dd304f80d92cb8981ce5723f27']
assert shutil.disk_usage('/tmp').free>1024**3
with (B/'metadata-fetch.log').open('xb') as out:
 p=subprocess.Popen(command,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 peak=0;reason=None
 while p.poll() is None:
  current=sum(f.stat().st_size for f in (R/'objects').rglob('*') if f.is_file())
  peak=max(peak,current)
  log=(B/'metadata-fetch.log').read_bytes()
  if current>150*1024**2:reason='Object-growth budget exceeded150MiB'
  if b'filtering not recognized' in log.lower():reason='Server did not honor filtering'
  if reason:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.1)
 rc=p.wait()
result={'command':command,'exit':rc,'peak_object_bytes':peak,'aborted_reason':reason,'final_object_bytes':sum(f.stat().st_size for f in(R/'objects').rglob('*')if f.is_file())}
(B/'METADATA-FETCH-RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
raise SystemExit(rc or (1 if reason else 0))
