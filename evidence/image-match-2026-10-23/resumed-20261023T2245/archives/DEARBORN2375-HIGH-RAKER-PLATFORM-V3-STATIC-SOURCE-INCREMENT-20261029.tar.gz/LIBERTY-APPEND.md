

### L-dearborn-high-rakers-platforms-2375 — Gallows braces and bearing platforms

**Covers:** `dearborn_street_drawbridge.draw_1834.form.gallows_shore_attach_m`, `dearborn_street_drawbridge.draw_1834.form.draw_bearing_platform_m`.
**Decision:** The retrospective Andreas1884 p.631 plate shows prominent high
rakers and broad draw-bearing foundations, with lighter trestle-like approaches.
**What is invented:** A 5.2 m shore attachment below the existing6.4m frame head;
two nominal 3.6 m by 4.4 m crib boxes growing away from the draw; and four-log
approach bents at the existing reconstructed stations. These dimensions, sections,
counts and riverbed seating are reconstructed visual choices. The print is no
survey and the bounded provisional camera is not a metric measurement. Log
joints project slightly beyond nominal box edges. No source coordinate moves.
**Limits:** Source-picture fit remains differs until the new actual comparison
is reviewed. The mechanism, camera and exact approach framing remain uncertain;
this is a closed display with a nominal floor proxy, not operating machinery.
**Ticket:** T-2375.
**Recorded:** 2026-10-29.
