from pathlib import Path
import json,hashlib,difflib,datetime,copy
out=Path(__file__).resolve().parent;v1=Path('/tmp/dearborn-profile-implemented-20261029/candidate/chicago/4d');v2=Path('/tmp/dearborn-profile-precision-v2-20261029/candidate/chicago/4d');rels=['generators/archetypes/bridge_timber_params.py','generators/archetypes/bridge_timber.py','data/structures/dearborn_street_drawbridge.json','data/reconstruction/name_pool_keys.json'];old={r:((v2 if r.startswith('data/structures') else v1)/r).read_bytes() for r in rels};new={r:b.decode() for r,b in old.items()}
def rep(rel,a,b):
 assert new[rel].count(a)==1,(rel,a[:70],new[rel].count(a));new[rel]=new[rel].replace(a,b)
p=rels[0];rep(p,'    "draw_bearing_supports", "draw_profile", "draw_rise_m",','    "draw_bearing_supports", "draw_profile", "draw_rise_m",\n    "gallows_shore_attach_m", "draw_bearing_platform_m",')
rep(p,'    draw_rise_m: float = field(default=0.0, kw_only=True)\n','''    draw_rise_m: float = field(default=0.0, kw_only=True)
    # Optional pictured high rakers and broad bearing platforms. None keeps the
    # original shore attachment and general pier treatment byte for byte.
    gallows_shore_attach_m: float | None = field(default=None, kw_only=True)
    draw_bearing_platform_m: tuple[float, float] | None = field(default=None, kw_only=True)
''')
needle='        if self.draw_lifting_gear not in DRAW_GEAR:\n'
validation='''        if self.gallows_shore_attach_m is not None:
            a = self.gallows_shore_attach_m
            if (isinstance(a, bool) or not isinstance(a, (int, float))
                    or not math.isfinite(a) or not 0.5 <= a <= self.gallows_height_m - 0.36):
                raise ParamError("gallows_shore_attach_m must be finite and between 0.5 m and the head underside")
            if not self.gallows_braced or not self.gallows_frames:
                raise ParamError("shore attachment requires existing braced gallows")
        if self.draw_bearing_platform_m is not None:
            size = self.draw_bearing_platform_m
            if (not isinstance(size, (list, tuple)) or len(size) != 2
                    or any(isinstance(v, bool) or not isinstance(v, (int, float))
                           or not math.isfinite(v) for v in size)):
                raise ParamError("draw_bearing_platform_m needs finite [along, across] dimensions")
            along, across = size
            if not 1.5 <= along <= 6.0 or not self.width_m + 0.9 <= across <= self.width_m + 3.0:
                raise ParamError("bearing platform dimensions exceed bounded approach/frame envelope")
            if not self.draw_bearing_supports or self.gallows_frames != 2:
                raise ParamError("bearing platforms require two aligned draw-bearing supports")
            lo, hi = self.gallows_x
            if lo - along < 0 or hi + along > self.span_m:
                raise ParamError("bearing platform runs beyond an approach end")
            others = [x for x in self.pier_x if abs(x - lo) > 1e-8 and abs(x - hi) > 1e-8]
            if any(lo - along - 0.58 <= x <= lo or hi <= x <= hi + along + 0.58 for x in others):
                raise ParamError("bearing platform overlaps another approach support")
'''
rep(p,needle,validation+needle)
rep(p,'        draw_rise_m=val("draw_rise_m", 0.0),','        draw_rise_m=val("draw_rise_m", 0.0),\n        gallows_shore_attach_m=val("gallows_shore_attach_m"),\n        draw_bearing_platform_m=val("draw_bearing_platform_m"),')
m=rels[1];needle='    if p.pier_kind == "bent":\n';extra='''    if p.draw_bearing_platform_m is not None and any(abs(xp - xg) < 1e-8 for xg in p.gallows_x):
        # Only these two bearings become broad cribs; general pier_kind still
        # controls the approach bents. The nominal box grows away from the draw.
        along, across = p.draw_bearing_platform_m
        x0, x1 = ((xp - along, xp) if xp < p.span_m / 2.0 else (xp, xp + along))
        y0 = (p.width_m - across) / 2.0
        c = max(conf, p.conf("draw_bearing_platform_m"))
        _crib(b, x0, y0, x1, y0 + across, bearing_z, c)
        _cap(b, p, xp, bearing_z, c)
        return
''';rep(m,needle,extra+needle)
needle='    sgn_x = -1.0 if xc < p.span_m / 2.0 else 1.0\n';rep(m,needle,needle+'''    attach = 2.60 if p.gallows_shore_attach_m is None else p.gallows_shore_attach_m
    shore_conf = conf if p.gallows_shore_attach_m is None else max(conf, p.conf("gallows_shore_attach_m"))
''')
rep(m,'        _strut(b, (xc + sgn_x * s, y_post, deck_z + 2.60),','        _strut(b, (xc + sgn_x * s, y_post, deck_z + attach),')
rep(m,'               sh, conf, M_LOG)','               sh, shore_conf, M_LOG)')
r=rels[2];record=json.loads(new[r]);f=record['phases'][0]['form'];old_note=f['pier_kind']['note'];pier_note='PREVIOUS CRIB-ONLY RECONSTRUCTION, retained as history: '+old_note+' CURRENT PICTURE-BOUNDED RECONSTRUCTION: the retrospective Andreas plate distinguishes broad draw-bearing foundations from the lighter trestle-like approach supports. Use the existing four-log bent for the remaining approach stations; that count, section and riverbed seating are reconstructed, not evidence that the Dearborn crossing used the branch bridges\' documented construction. The two selected frame bearings override this general kind with separately dimensioned reconstructed crib platforms. No source coordinate, surveyed foundation footprint or accepted whole-picture match follows.'
rep(r,'"pier_kind": {\n          "value": "crib",','"pier_kind": {\n          "value": "bent",');rep(r,json.dumps(old_note,ensure_ascii=False),json.dumps(pier_note,ensure_ascii=False))
old_note=f['draw_bearing_supports']['note'];new_note=old_note.replace('The 12 surviving supports, invented crib construction and remaining approach stations stay reconstructed.','The 12 surviving support stations remain reconstructed. The two selected frame-bearing crib platforms and the general approach bents are separately declared reconstructions.')
assert new_note!=old_note;rep(r,json.dumps(old_note,ensure_ascii=False),json.dumps(new_note,ensure_ascii=False))
fields={'gallows_shore_attach_m':{'value':5.2,'confidence':'reconstructed','note':'HIGH OUTER RAKERS, NUMERIC TRIAL. The Andreas 1884 p.631 plate shows prominent long outer braces attaching high on the gallows posts. The old helper attached them only 2.60 m above the deck. A 5.2 m attachment, below the unchanged 6.4 m frame head, tests that pictured relationship. The unchanged 2.85 m nominal run and all timber sections remain reconstructed; this number is not measured from the principal-point-bound provisional camera.'},'draw_bearing_platform_m':{'value':[3.6,4.4],'confidence':'reconstructed','note':'TWO BROAD DRAW-BEARING PLATFORMS. The retrospective Andreas plate shows broad foundations under the gallows rather than a forest of identical narrow box cribs. The two selected bearing cribs use a reconstructed 3.6 m nominal box length away from the draw and 4.4 m width across it. These are bounded visual-trial dimensions, not a survey, geographic footprint or historical specification; visible log joints project slightly beyond that box. Existing draw endpoints and the twelve support stations remain unchanged. The remaining approaches use separately reconstructed timber bents; whole source comparison stays differs.'}}
anchor='\n      },\n      "change_note"';encoded='\n'.join('      '+line for line in json.dumps(fields,indent=2).splitlines()[1:-1]);rep(r,anchor,',\n'+encoded+anchor)
check=json.loads(new[r]);expect=copy.deepcopy(record);ef=expect['phases'][0]['form'];ef['pier_kind'].update(value='bent',note=pier_note);ef['draw_bearing_supports']['note']=new_note;ef.update(fields);assert check==expect
keys=rels[3];meta=json.loads(new[keys]);added=['phases[].form.gallows_shore_attach_m.note','phases[].form.draw_bearing_platform_m.note'];assert not any(x in meta['read']['structures'] for x in added);anchor='\n    ],\n    "households"';rep(keys,anchor,',\n'+',\n'.join('      '+json.dumps(x) for x in added)+anchor);meta['read']['structures']+=added;assert json.loads(new[keys])==meta
for rel in rels:
 for part,b in [('before',old[rel]),('candidate',new[rel].encode())]:
  dest=out/part/'chicago/4d'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
(out/'SOURCE-4PATH-INCREMENT.patch').write_text(''.join(''.join(difflib.unified_diff(old[r].decode().splitlines(True),new[r].splitlines(True),fromfile='a/chicago/4d/'+r,tofile='b/chicago/4d/'+r)) for r in rels))
(out/'LIBERTY-APPEND.md').write_text('''\n\n### L-dearborn-high-rakers-platforms-2375 — Gallows braces and bearing platforms\n\n**Covers:** `dearborn_street_drawbridge.draw_1834.form.gallows_shore_attach_m`, `dearborn_street_drawbridge.draw_1834.form.draw_bearing_platform_m`.\n**Decision:** The retrospective Andreas1884 p.631 plate shows prominent high\nrakers and broad draw-bearing foundations, with lighter trestle-like approaches.\n**What is invented:** A 5.2 m shore attachment below the existing6.4m frame head;\ntwo nominal 3.6 m by 4.4 m crib boxes growing away from the draw; and four-log\napproach bents at the existing reconstructed stations. These dimensions, sections,\ncounts and riverbed seating are reconstructed visual choices. The print is no\nsurvey and the bounded provisional camera is not a metric measurement. Log\njoints project slightly beyond nominal box edges. No source coordinate moves.\n**Limits:** Source-picture fit remains differs until the new actual comparison\nis reviewed. The mechanism, camera and exact approach framing remain uncertain;\nthis is a closed display with a nominal floor proxy, not operating machinery.\n**Ticket:** T-2375.\n**Recorded:** 2026-10-29.\n''')
(out/'SOURCE-BINDINGS.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'UNADOPTED external4pathincrement over immutableV1+V2; no canonical/claim/export/browser. Staticshapecontrols only; no runtimeprofilearchitecture change.','preimages':{r:hashlib.sha256(b).hexdigest() for r,b in old.items()},'postimages':{r:hashlib.sha256(b.encode()).hexdigest() for r,b in new.items()},'parent_manifests':{'v1':'346f1256d836ca7e42facced68cef8e27498864f9708799c2d6993220081be53','v2':'07072e0a425322d486aa729e70f11091766508476ec0e25a93ef9f4be858cc29'}},indent=2)+'\n');print('4paths prepared UNADOPTED')
