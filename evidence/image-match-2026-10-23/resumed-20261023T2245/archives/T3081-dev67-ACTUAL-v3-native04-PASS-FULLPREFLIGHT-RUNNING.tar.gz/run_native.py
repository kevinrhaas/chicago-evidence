from pathlib import Path
import subprocess,json,datetime,os,hashlib,sys
r=Path('/tmp/chicago-log-integration/chicago/4d');o=Path(__file__).resolve().parent
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
get=lambda rel:subprocess.check_output(['git','show','HEAD:chicago/4d/'+rel],cwd=r)
sha=lambda b:hashlib.sha256(b).hexdigest()
pop=['data/reconstruction/1835_lodgers_seated.json','data/reconstruction/1835_reconstruction_order_book.json',*[str(p.relative_to(r))for p in sorted((r/'data/residents/lodgers').glob('*.json'))]]
assert len(pop)==24
protected=pop+['data/reconstruction/1835_lodging_model.json','data/reconstruction/1835_placement_policy.json']
baseline={p:sha(get(p))for p in protected}
(o/'protected-before.json').write_text(json.dumps(baseline,indent=2)+'\n')
def guard():
 for p,h in baseline.items():assert sha((r/p).read_bytes())==h,('Protected drift',p)
guard()
s={'status':'RUNNING','started':now(),'controller_pid':os.getpid(),'HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'merge_parent':subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=r,text=True).strip(),'phases':[]}
p=o/'receipt.json';save=lambda:p.write_text(json.dumps(s,indent=2)+'\n');save()
env={**os.environ,'TMPDIR':'/workspace/tmp-t3081','PATH':'/workspace/shared/tools/usr/bin:'+os.environ['PATH'],'PYTHONDONTWRITEBYTECODE':'1'}
commands=[('lodging-check',['python3','tools/build_lodging_model_1835.py','--check']),('placement-check',['python3','tools/placement_policy_1835.py','--check','--quiet']),('native-tail',['node','tools/rederive.mjs','--tail','tools/compile_liberties.py']),('publish',['bash','tools/publish.sh']),('dataset-all-stale',['python3','tools/validate.py','--all','--stale']),('liberties-check',['python3','tools/compile_liberties.py','--check']),('source-use-check',['python3','tools/compile_source_use.py','--check']),('closing-check',['python3','tools/rebuild_closing_set.py','--check']),('published-check',['node','tools/check_published.mjs'])]
try:
 for name,args in commands:
  guard();row={'name':name,'command':args,'started':now()};s['phases'].append(row);save()
  with(o/(name+'.log')).open('x')as log:
   q=subprocess.Popen(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT);row['pid']=q.pid;save();code=q.wait()
  row.update(exit_code=code,finished=now());save();assert code==0,name;guard()
 s.update(status='PASS',finished=now(),all24_population_and_two_models_exact=True);save();print(json.dumps(s,indent=2))
except BaseException as e:s.update(status='FAILED',error=str(e),finished=now());save();raise
