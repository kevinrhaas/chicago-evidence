from pathlib import Path
import hashlib,json,struct,copy,shutil,datetime
app=Path('/workspace/chicago/chicago/4d');out=Path('/tmp/WolfPoint-T2386-darkened-canonical-20261026');before=json.loads((out/'BEFORE-INVENTORY.json').read_bytes());old={r['path']:r for r in before['rows']}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
new={}
for d in ['assets','data','generators']:
 for p in sorted((app/d).rglob('*')):
  if p.is_file():new[str(p.relative_to(app))]={'path':str(p.relative_to(app)),'bytes':p.stat().st_size,'sha256':sha(p),'symlink':p.is_symlink()}
assert set(new)==set(old)
changed=[k for k in old if old[k]!=new[k]];expected={'assets/gltf/wolf_point_tavern__log_frame_1828.glb','assets/web/wolf_point_tavern__log_frame_1828.glb','assets/manifest.json','assets/manifest.web.json','data/structures/wolf_point_tavern.json'}
cache=[k for k in changed if '/__pycache__/' in k and k.endswith('.pyc')];persistent=[k for k in changed if k not in cache];assert set(persistent)==expected,(persistent,cache)
rowproof=[]
for name,key in [('assets/manifest.json','assets'),('assets/manifest.web.json','masters')]:
 a=json.loads((out/'before'/name).read_bytes());b=json.loads((app/name).read_bytes());target='wolf_point_tavern__log_frame_1828.glb';d=[k for k in set(a[key])|set(b[key]) if a[key].get(k)!=b[key].get(k)];assert d==[target],d
 aa=copy.deepcopy(a);bb=copy.deepcopy(b);del aa[key][target];del bb[key][target];assert aa==bb
 rowproof.append({'path':name,'only_changed_row':target,'all_non_target_rows_and_metadata_exact':True,'before':a[key][target],'after':b[key][target]})
def read(p):
 b=p.read_bytes();j=None;bin=None;o=12
 while o<len(b):
  n,t=struct.unpack_from('<II',b,o);v=b[o+8:o+8+n];o+=n+8
  if t==0x4e4f534a:j=json.loads(v)
  if t==0x004e4942:bin=v
 return j,bin
geometry=[]
for kind in ['gltf','web']:
 name=f'assets/{kind}/wolf_point_tavern__log_frame_1828.glb';a,x=read(out/'before'/name);b,y=read(app/name);assert x==y
 ac=copy.deepcopy(a);bc=copy.deepcopy(b);mats=[]
 for i,(am,bm) in enumerate(zip(ac['materials'],bc['materials'])):
  if am!=bm:
   assert am['name']==bm['name']=='roof_shingle';o=am['pbrMetallicRoughness'].pop('baseColorFactor');n=bm['pbrMetallicRoughness'].pop('baseColorFactor');assert am==bm
   mats.append({'index':i,'name':'roof_shingle','old_baseColorFactor':o,'new_baseColorFactor':n})
 assert len(mats)==1 and ac==bc
 triangles=sum(a['accessors'][p['indices']]['count']//3 for m in a['meshes'] for p in m['primitives']);assert triangles==1730
 attrs=[{'name':m.get('name'),'material':a['materials'][p['material']]['name'],'attributes':{k:a['accessors'][v] for k,v in p['attributes'].items()},'index_accessor':a['accessors'][p['indices']]} for m in a['meshes'] for p in m['primitives']]
 geometry.append({'kind':kind,'binary_chunks_byte_identical':True,'binary_chunk_sha256':hashlib.sha256(x).hexdigest(),'binary_bytes':len(x),'only_json_difference':mats,'nodes_and_world_transforms_exact':True,'all_mesh_primitives_accessors_bufferViews_indices_exact':True,'positions_normals_confidence_UV_oriented_triangle_streams_exact':'Identical actual binary bytes with identical accessor/view/mesh/index mappings and node transforms establish identical values and oriented tuples, including normalized/quantized compressedWEB descriptors. No UV serialization difference exists.','triangles':triangles,'primitives':len(attrs),'actual_primitive_descriptors':attrs,'before':old[name],'after':new[name]})
 q=out/'after'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(app/name,q)
for name in ['data/structures/wolf_point_tavern.json','assets/manifest.json','assets/manifest.web.json']:
 q=out/'after'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(app/name,q)
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':'cb93ad9cd5ea38654737e05002b1f1904be14e54','before_file_count':len(old),'after_file_count':len(new),'persistent_changed_exactly5_expected_inventory_paths':persistent,'all_other_persistent_files_byte_identical':True,'native_refreshed_ignored_python_cache_only':cache,'exact_byte_identical_file_count':len(new)-len(changed),'all_non_target_physical_assets_sources_person_population_and_generator_source_unchanged':True,'no_added_or_removed_inventory_files':True,'registry_rows':rowproof,'canonical_output_geometry':geometry}
(out/'PROTECTION-AND-GEOMETRY-PROOF.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS:',len(new)-len(changed),'files exact; persistent changes exactly5expected paths;',len(cache),'ignored native Python caches refreshed. Both outputs1730triangles, BIN/accessor/transform streams exact; only roof PBR color and target registry rows changed.')
cam=Path('/tmp/WolfPoint-T2386-readiness-review-20261026/retained-light-plan/actual-before/camera.json');dest=out/'review/a/b/nypl-provisional.json';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(cam.read_bytes());assert sha(dest)=='2a96283300029b94481286f5b246c2c9c53efb6f505ab140ddef543288a48f82'
photo=out/'data/sources/assets/nypl-full.jpg';photo.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile('/workspace/chicago/chicago/reference/images/chicago/chicago_wolf_point_1833_nypl.jpg',photo);assert (dest.parent/json.loads(dest.read_bytes())['photo']).resolve()==photo
print('Exact retained provisional camera and actual source arranged externally; no camera edit.')
