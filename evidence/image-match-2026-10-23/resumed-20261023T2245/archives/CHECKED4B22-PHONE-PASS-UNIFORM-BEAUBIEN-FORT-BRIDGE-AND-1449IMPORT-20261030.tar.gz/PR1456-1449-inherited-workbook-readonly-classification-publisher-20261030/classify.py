from pathlib import Path
from urllib.request import Request,urlopen
import json,hashlib,datetime,zipfile,io,xml.etree.ElementTree as ET,posixpath
O=Path(__file__).parent;P='chicago/reference/resident-research/final/audit/resident_audit_master.xlsx';BASE='944fc1dcd27aee0fc051323d98fc5f3f24f0753e';TIP='1449df86599e0f8954c6dcba92804130030c600f';B='https://api.github.com/repos/kevinrhaas/chicago/';sha=lambda b:hashlib.sha256(b).hexdigest();gs=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def api(p):
 with urlopen(Request(B+p,headers={'User-Agent':'Chicago-exact-1449-workbook-classification'}),timeout=45)as r:return json.load(r)
def load(sid):
 c=api('git/commits/'+sid);t=api('git/trees/'+c['tree']['sha']+'?recursive=1');assert not t['truncated'];r=next(r for r in t['tree']if r['path']==P);assert r['mode']=='100644'and r['type']=='blob'
 with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+sid+'/'+P,headers={'User-Agent':'Chicago-exact-immutable-workbook-bytes'}),timeout=45)as f:b=f.read()
 assert len(b)==r['size']and gs(b)==r['sha'];return r,b
def canon(n,b):
 if not n.endswith('.xml')and not n.endswith('.rels'):return b
 root=ET.fromstring(b)
 if n=='docProps/core.xml':
  for e in list(root):
   if e.tag=='{http://purl.org/dc/terms/}modified':root.remove(e)
 return ET.canonicalize(ET.tostring(root,encoding='unicode')).encode()
def cells(z):
 ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};strings=[]
 if 'xl/sharedStrings.xml'in z.namelist():strings=[''.join(x.itertext())for x in ET.fromstring(z.read('xl/sharedStrings.xml'))]
 rel={e.attrib['Id']:e.attrib['Target']for e in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))};out={};sheets=[]
 for sheet in ET.fromstring(z.read('xl/workbook.xml')).findall('s:sheets/s:sheet',ns):
  name=sheet.attrib['name'];sheets.append(name);target=rel[sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']];path=target.lstrip('/')if target.startswith('/')else posixpath.normpath(posixpath.join('xl',target));assert path in z.namelist()
  for c in ET.fromstring(z.read(path)).findall('.//s:sheetData/s:row/s:c',ns):
   t=c.attrib.get('t','n');v=c.find('s:v',ns);v=None if v is None else v.text
   if t=='s'and v is not None:v=strings[int(v)]
   if t=='inlineStr':
    item=c.find('s:is',ns);v=None if item is None else ''.join(item.itertext())
   f=c.find('s:f',ns);out[name+'!'+c.attrib['r']]={'type':t,'value':v,'formula':None if f is None else f.text}
 return sheets,out
ar,a=load(BASE);br,b=load(TIP)
with zipfile.ZipFile(io.BytesIO(a))as az,zipfile.ZipFile(io.BytesIO(b))as bz:
 assert az.testzip()is None and bz.testzip()is None;names=sorted(set(az.namelist())|set(bz.namelist()));members=[{'name':n,'raw_equal':n in az.namelist()and n in bz.namelist()and az.read(n)==bz.read(n),'canonical_except_core_modified_equal':n in az.namelist()and n in bz.namelist()and canon(n,az.read(n))==canon(n,bz.read(n))}for n in names];asheets,ac=cells(az);bsheets,bc=cells(bz);diff=[{'cell':n,'base944':ac.get(n),'incoming1449':bc.get(n)}for n in sorted(set(ac)|set(bc))if ac.get(n)!=bc.get(n)]
x={'status':'READONLY_EXACT1449_WORKBOOK_CLASSIFICATION','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'path':P,'base':{'commit':BASE,**ar,'sha256':sha(a)},'incoming':{'commit':TIP,**br,'sha256':sha(b)},'all_zip_members':members,'sheets_equal':asheets==bsheets,'base_sheets':asheets,'incoming_sheets':bsheets,'base_cell_count':len(ac),'incoming_cell_count':len(bc),'changed_cell_count':len(diff),'changed_cells':diff,'all_canonical_members_equal_except_core_modified':all(r['canonical_except_core_modified_equal']for r in members),'classification':'TIMESTAMP_OR_CONTAINER_ONLY_NO_CELL_CHANGE'if not diff and all(r['canonical_except_core_modified_equal']for r in members)else'REAL_CELL_OR_OTHER_XML_CHANGE_PRESERVE_EXACT1449_BASELINE','raw_payloads_RAM_only':True,'primary_source_Git_operations':False,'parser_note':'Blank inlineStr cells without an is child decode as None; first parser refused those before producing any classification.'};(O/'RESULT.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({k:v for k,v in x.items()if k not in ['changed_cells','all_zip_members']},indent=2))
