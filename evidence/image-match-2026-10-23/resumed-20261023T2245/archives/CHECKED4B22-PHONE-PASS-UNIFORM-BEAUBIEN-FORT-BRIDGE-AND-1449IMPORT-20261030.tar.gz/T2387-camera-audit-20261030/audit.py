"""Finite CPU2 camera correspondence audit. No mesh/renderer/primary writes."""
from pathlib import Path
import os,sys,json,math,hashlib,struct,datetime
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';sys.dont_write_bytecode=True
import numpy as np
from scipy.optimize import least_squares
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');I=Path('/workspace/T2387-first-fort-readiness-20261030');N=Path('/workspace/T2387-native25-controller-20261030/run')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cam=json.loads((N/'capture/after/native-camera.json').read_text());group=json.loads((I/'CURRENT-GROUP30-BINDING.json').read_text());members={r['structure_id']:r for r in group['rendered_members']}
def peak(sid):
 p=N/'closed-authority/native-master'/(sid+'__first_fort_1803.glb');b=p.read_bytes();j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]]);acc=[j['accessors'][x['attributes']['POSITION']]for x in j['meshes'][0]['primitives']];h=max(x['max'][1]for x in acc);r=json.loads((A/'data/structures'/(sid+'.json')).read_text());fp=r['phases'][0]['footprint']['polygon'];cx=(min(p[0]for p in fp)+max(p[0]for p in fp))/2;cy=(min(p[1]for p in fp)+max(p[1]for p in fp))/2;pos=members[sid]['position'];return np.array([pos[0]+cx,-pos[2]+cy,h])
nw=peak('first_fort_dearborn_blockhouse_nw');se=peak('first_fort_dearborn_blockhouse_se');staff=np.array([17.26,-12.03,22.86]);corners={'SW':np.array([.95,-29.2,0]),'SE':np.array([33.87,-29.2,0]),'NE':np.array([33.87,4.72,0]),'NW':np.array([.95,4.72,0])}
def basis(yaw,pitch):
 t,p=np.radians([yaw,pitch]);r=np.array([np.cos(t),-np.sin(t),0.]);f=np.array([np.sin(t)*np.cos(p),np.cos(t)*np.cos(p),-np.sin(p)]);u=np.cross(r,f);return r,u,f
def project(params,points,principal):
 eye=np.array(params[:3]);r,u,f=basis(params[3],params[4]);q=np.asarray(points)-eye;depth=q@f
 if np.any(depth<=.05):return np.full((len(q),2),10000.)
 return np.column_stack([principal[0]+params[5]*(q@r)/depth,principal[1]-params[5]*(q@u)/depth])
# Six rough source controls, intentionally not hand-picked exact camera attestations.
uv=np.array([[769,248],[694,269],[769,421],[313,418],[313,377],[740,157]],float)
labels=['near lantern cap apex (not finial)','far lantern cap apex (not finial)','near blockhouse projected centre foot (qualified/partly occluded)','left visible stockade-angle foot','left visible stockade-angle crest','flagstaff top']
results=[]
for nearname,near,far,left,right,initial,lower,upper in [
 ('NW',nw,se,'NE','SW',[-70,85,3,140,0,1900],[-250,5,-6,90,-20,400],[-5,250,12,180,20,5000]),
 ('SE',se,nw,'SW','NE',[110,-110,3,320,0,1900],[40,-280,-6,270,-20,400],[280,-40,12,360,20,5000])]:
 foot=near.copy();foot[2]=0;lfoot=corners[left].copy();ltop=lfoot.copy();ltop[2]=3.7;pts=np.array([near,far,foot,lfoot,ltop,staff]);principal=[769,429.5]
 # Exactly one bounded solve per diagonal assignment, <=120 evals; no rendered search.
 fit=least_squares(lambda p:((project(p,pts,principal)-uv)/np.array([12,12,15,12,15,8])[:,None]).ravel(),initial,bounds=(lower,upper),max_nfev=120,ftol=1e-10,xtol=1e-10,gtol=1e-10)
 pred=project(fit.x,pts,principal);diff=pred-uv
 oldparams=[*cam['eye'],cam['yaw_deg'],0,cam['focal_px']];oldpred=project(oldparams,pts,cam['principal_px'])
 hold=corners[right].copy();hold[2]=3.7;hp=project(fit.x,[hold],[769,429.5])[0]
 results.append({'hypothesis':'view_from_'+nearname+'_diagonal','near_blockhouse':nearname,'left_angle_correspondence':left,'right_angle_unverified':right,'source_controls':labels,'world_controls_ENU':pts.tolist(),'source_controls_px':uv.tolist(),'principal_px_fixed_reconstructed':principal,'fit_parameters_eye_u_v_h_yaw_pitch_focal':fit.x.tolist(),'bounds':[lower,upper],'bound_parameters':[i for i,(x,lo,hi)in enumerate(zip(fit.x,lower,upper))if abs(x-lo)<1e-5 or abs(x-hi)<1e-5],'evaluations':fit.nfev,'converged':bool(fit.success),'projected_px':pred.tolist(),'residual_px':diff.tolist(),'radial_RMS_px':float(np.sqrt(np.mean(np.sum(diff**2,axis=1)))),'old_seed_same_correspondence_RMS_px':float(np.sqrt(np.mean(np.sum((oldpred-uv)**2,axis=1)))),'old_seed_projected_px':oldpred.tolist(),'unverified_right_corner_crest_projection_px':hp.tolist(),'right_wall_last_visible_px':[1181,377],'right_last_visible_is_NOT_corner_control':True,'all_model_world_points_unchanged':True})
# Pure projection against actual closed native image: known nominal cap centres are expected ~1132/450px.
oldproj=project([*cam['eye'],cam['yaw_deg'],0,cam['focal_px']],[nw,se,staff],cam['principal_px'])
out={'status':'FINITE_TWO_DIAGONAL_MATH_AUDIT_NO_NATIVE_CAPTURE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu_affinity':sorted(os.sched_getaffinity(0)),'source_sha256':sha(A/'data/sources/assets/prefire_views_kevin_2026_08/p4_0.png'),'closed_native_after_raw_sha256':sha(N/'capture/after/first-fort-panel-1-render.png'),'closed_native_camera_sha256':sha(N/'capture/after/native-camera.json'),'model_peaks_from_actual_719_GLBS':{'NW':nw.tolist(),'SE':se.tolist()},'hard_staff_height_m':22.86,'original_seed_projected_NW_SE_staff_px':oldproj.tolist(),'method':'Exactly2 bounded physical-pinhole solves, same6 rough controls, fixedcentre principal, squarepixels/roll0, sharedwholefort camera. Every source-to-record identity is conditional exceptstaff; no survey move, no height edit, no pixel-aspect invention. Reconstructed model heights cannot calibrate an attested camera. Right tree-occluded wall end is withheld.','results':results}
(P/'AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps([{k:r[k]for k in ['hypothesis','radial_RMS_px','old_seed_same_correspondence_RMS_px','fit_parameters_eye_u_v_h_yaw_pitch_focal','bound_parameters','evaluations','unverified_right_corner_crest_projection_px']}for r in results],indent=2))
