// EXTERNAL ONLY. Run only after the coordinating writer grants the CPU lease.
// Native published 1904 application; no copied runtime, no source/Git mutations.
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const BASE=path.dirname(fileURLToPath(import.meta.url));
const O=path.join(BASE,'visual944north');
const R='/workspace/chicago/chicago/4d', site='/workspace/chicago/site/4d';
const require=createRequire(path.join(R,'tools/qa.mjs'));
const {chromium}=require('playwright');
const sha=b=>createHash('sha256').update(b).digest('hex');
const PRIMARY='dfb954e5eb155afb4e560bc59a431b866ab0ea93f738ad61c4270fded8920b42';
const CANDIDATE='a9e80f7f262c6f1ae0254c102a333fda42981f5fd2e119698280408f6f99cef0';
if(process.env.C4D_VISUAL944NORTH_LEASE!=='granted-by-parent')throw Error('Internal parent CPU lease required');
fs.mkdirSync(O,{recursive:true});
for(const n of ['VISUAL944.json','VISUAL944-REQUESTS.json'])if(fs.existsSync(path.join(O,n)))throw Error('Refusing existing output '+n);
const primary=fs.readFileSync(path.join(R,'renderers/web/js/railway.js'));
const candidate=fs.readFileSync(path.join(BASE,'railway.js'));
if(sha(primary)!==PRIMARY||sha(candidate)!==CANDIDATE)throw Error('source hash drift');
// This is the exact candidate groundMesh post-partition metadata block, run on
// existing native geometry. Calling groundMesh here would recompute normals at
// partition boundaries, so native factory construction is covered separately.
const source=candidate.toString();
const meshStart=source.indexOf('async function groundMesh(');
const start=source.indexOf('  if (grade !== null) {',source.indexOf('const mesh = await spatialBatchAsync(geo, mat);',meshStart));
const end=source.indexOf('\n  mesh.sortObjects = false;',start);
if(meshStart<0||start<0||end<0)throw Error('exact metadata block missing');
const metadata=source.slice(start,end);
const addon=`\nexport { groundMaterial, sharedGroundGrade };\nexport function applyExactFinalGroundMetadata(mesh,grade) {\n${metadata}\n}\n`;
const exported=Buffer.concat([candidate,Buffer.from(addon)]);
const proof={primary_sha256:PRIMARY,candidate_sha256:CANDIDATE,candidate_export_response_sha256:sha(exported),exact_metadata_block_sha256:sha(metadata),factory:'actual candidate groundMaterial/sharedGroundGrade exports; metadata verbatim from actual groundMesh',normal_proof:'original native partitioned compact normal attribute and raw bytes retained; no normal recomputation'};
const requests=[],errors=[],bad=[];
const record=row=>{requests.push(row);fs.appendFileSync(path.join(O,'REQUESTS-PROGRESS.jsonl'),JSON.stringify(row)+'\n');};
fs.writeFileSync(path.join(O,'PROOF.json'),JSON.stringify(proof,null,2)+'\n',{flag:'wx'});
const durable=result=>{const tmp=path.join(O,'PROGRESS.tmp');fs.writeFileSync(tmp,JSON.stringify(result,null,2)+'\n');fs.renameSync(tmp,path.join(O,'PROGRESS.json'));};
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.glb':'model/gltf-binary','.svg':'image/svg+xml','.wasm':'application/wasm','.ktx2':'image/ktx2','.webp':'image/webp'};
const server=http.createServer((req,res)=>{const url=decodeURIComponent(req.url.split('?')[0]);try{
  if(url==='/walk/js/__external_uniform_confidence944.js'){
    record({url,sha256:sha(exported),candidate_sha256:CANDIDATE,bytes:exported.length});res.writeHead(200,{'Content-Type':'text/javascript'});res.end(exported);return;
  }
  let p=path.join(site,url);if(!p.startsWith(site+'/'))throw Error('path escape');
  if(fs.statSync(p).isDirectory())p=path.join(p,'index.html');
  if(url==='/walk/js/railway.js')p=path.join(R,'renderers/web/js/railway.js');
  const b=fs.readFileSync(p);record({url,sha256:sha(b),bytes:b.length});res.writeHead(200,{'Content-Type':types[path.extname(p)]||'application/octet-stream'});res.end(b);
}catch(e){record({url,error:String(e)});res.writeHead(404);res.end('missing');}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let browser,result={status:'VISUAL944_INCOMPLETE',proof,errors,bad,stands:[]},failure=null;
const started=Date.now();
try {
  browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE||undefined,args:['--no-sandbox','--enable-unsafe-swiftshader']});
  const context=await browser.newContext({viewport:{width:390,height:780},deviceScaleFactor:1,isMobile:true,hasTouch:true});
  const page=await context.newPage();page.on('pageerror',e=>errors.push(String(e)));page.on('response',r=>{if(r.status()>=400)bad.push(r.url()+':'+r.status());});
  await page.goto(`http://127.0.0.1:${server.address().port}/1904/?keep-geometry=1`,{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:240000,polling:500});
  await page.waitForFunction(()=>window.__chicago4d?.welcome.state==='welcome',null,{timeout:240000,polling:1000});
  result.boot=await page.evaluate(async()=>{const a=__chicago4d;if(!a.welcome.enter('spawn'))throw Error('welcome entry failed');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.renderer.setAnimationLoop(null);a.setAnimationHold(true);await a.setDetail('light');a.step();return {scene:a.scene.id,detail:a.detail,ceiling:a.detailLevels.light.triangles};});
  if(result.boot.scene!=='1904'||result.boot.detail!=='light')throw Error('not native1904light');
  await page.waitForFunction(()=>document.getElementById('gate').hidden);
  for(const [name,pos,target] of [['lake-yard-looking-north',[1566,-3350,1.7],[1430,-2900,1.7]]]) {
    let completed=null;
    for(const currentMode of ['normal','bygrade','hidden-inferred','hidden-reconstructed','ghost-inferred','ghost-reconstructed','dither-inferred','dither-reconstructed','xray']) {
    const row=await page.evaluate(async({name,pos,target,currentMode})=>{
      const a=__chicago4d,c=a.confidence,THREE=await import('/walk/vendor/three-0.185.1/three.module.js');
      const candidate=await import('/walk/js/__external_uniform_confidence944.js');
      const check=(v,msg)=>{if(!v)throw Error(msg);};
      const equal=(x,y)=>JSON.stringify(x)===JSON.stringify(y);
      const raw=x=>new Uint8Array(x.array.buffer,x.array.byteOffset,x.array.byteLength);
      const snapAttr=x=>({attr:x,array:x.array,bytes:raw(x).slice(),itemSize:x.itemSize,normalized:x.normalized,count:x.count});
      const exactAttr=(x,s)=>x===s.attr&&x.array===s.array&&x.itemSize===s.itemSize&&x.normalized===s.normalized&&x.count===s.count&&raw(x).length===s.bytes.length&&!raw(x).some((v,i)=>v!==s.bytes[i]);
      const savedKeys=(obj,keys)=>keys.map(key=>({key,descriptor:Object.getOwnPropertyDescriptor(obj,key)}));
      const restoreKeys=(obj,keys)=>{for(const {key,descriptor}of keys)if(descriptor)Object.defineProperty(obj,key,descriptor);else delete obj[key];};
      const exactKeys=(obj,keys)=>keys.every(({key,descriptor})=>{const d=Object.getOwnPropertyDescriptor(obj,key);return descriptor?!!d&&d.value===descriptor.value&&d.writable===descriptor.writable&&d.enumerable===descriptor.enumerable&&d.configurable===descriptor.configurable:!d;});
      const properties=['type','roughness','metalness','vertexColors','transparent','opacity','depthWrite','depthTest','side','polygonOffset','polygonOffsetFactor','polygonOffsetUnits','aoMapIntensity','alphaTest','blending','premultipliedAlpha','toneMapped','wireframe','flatShading'];
      const params=m=>({...Object.fromEntries(properties.map(k=>[k,m[k]])),color:m.color?.toArray(),normalScale:m.normalScale?.toArray(),name:m.name});
      const textures=['map','normalMap','roughnessMap','aoMap'];
      const kinds={'railway-cinders':'cinders','railway-verges':'verge','railway-ballast-beds':'bed','railway-lake-face':'face','railway-made-ground':'made'};
      const ground=a.railway.group.children.filter(m=>kinds[m.name.replace(/-far$/,'')]);
      check(ground.length===10,'expected actual ten native ground meshes');
      const saved=ground.map(m=>{const g=m.geometry,conf=g.getAttribute('_confidence');check(conf?.array instanceof Float32Array,'baseline Float32 confidence missing');return {mesh:m,geometry:g,material:m.material,params:params(m.material),textures:textures.map(k=>m.material[k]),attrs:Object.fromEntries(Object.entries(g.attributes).map(([k,x])=>[k,snapAttr(x)])),index:snapAttr(g.index),geoMeta:savedKeys(g.userData,['confidence','confidenceRange']),meshMeta:savedKeys(m.userData,['confidenceRanges']),bounds:JSON.stringify({box:g.boundingBox,sphere:g.boundingSphere}),visible:m.visible,instanceVisible:m._instanceInfo.map(x=>x.visible)};});
      const pairs=Object.keys(kinds).map(base=>{const fine=saved.find(s=>s.mesh.name===base),far=saved.find(s=>s.mesh.name===base+'-far');check(fine&&far,'fine/far missing');check(fine.material===far.material,'baseline shared material missing');const grade=candidate.sharedGroundGrade({conf:fine.attrs._confidence.array},{conf:far.attrs._confidence.array});const lib=fine.material.map?{map:fine.material.map,normalMap:fine.material.normalMap,orm:fine.material.roughnessMap}:null;return {base,fine,far,grade,lib,material:grade===null?null:candidate.groundMaterial(fine.material.name,kinds[base],lib,c,grade),wrong:grade===null?null:candidate.groundMaterial(fine.material.name,kinds[base],lib,c,grade===1?0:1)};});
      check(pairs.some(p=>p.grade!==null),'no eligible actual uniform pairs');
      for(const pair of pairs)if(pair.material){check(equal(params(pair.material),pair.fine.params),'candidate material parameters drift');check(textures.every((k,i)=>pair.material[k]===pair.fine.textures[i]),'candidate did not use exact original textures');}
      const restore=()=>{for(const s of saved){s.mesh.material=s.material;s.geometry.setAttribute('_confidence',s.attrs._confidence.attr);restoreKeys(s.geometry.userData,s.geoMeta);restoreKeys(s.mesh.userData,s.meshMeta);}};
      const verify=(variant)=>{for(const s of saved){check(s.mesh.geometry===s.geometry,'geometry object changed');const pair=pairs.find(p=>p.fine===s||p.far===s),omitted=variant!=='A'&&variant!=='D'&&pair.grade!==null;check(equal(Object.keys(s.geometry.attributes).sort(),Object.keys(s.attrs).filter(k=>!omitted||k!=='_confidence').sort()),'attribute set changed');for(const[k,snap]of Object.entries(s.attrs))if(k!=='_confidence'||!omitted)check(exactAttr(s.geometry.getAttribute(k),snap),'raw attribute changed '+k);check(exactAttr(s.geometry.index,s.index),'index changed');check(s.bounds===JSON.stringify({box:s.geometry.boundingBox,sphere:s.geometry.boundingSphere}),'bounds changed');if(!omitted){check(s.mesh.material===s.material&&equal(params(s.mesh.material),s.params),'original material changed');check(exactKeys(s.geometry.userData,s.geoMeta)&&exactKeys(s.mesh.userData,s.meshMeta),'metadata restore mismatch');}else {check(!s.geometry.getAttribute('_confidence'),'scalar still present');const grade=variant==='W'?(pair.grade===1?0:1):pair.grade;check(s.geometry.userData.confidence===grade&&equal(s.geometry.userData.confidenceRange,[grade,grade]),'final geometry metadata wrong');check(s.mesh.userData.confidenceRanges.length===s.mesh.userData.spatialBatch.pieces&&s.mesh.userData.confidenceRanges.every(x=>equal(x,[grade,grade])),'perinstance metadata wrong');}if(variant!=='W'){const read=a.confidenceOf(s.geometry);check(read?.count===s.attrs._confidence.count,'CPU confidence count changed');for(let i=0;i<read.count;i++)check(read.getX(i)===s.attrs._confidence.attr.getX(i),'CPU confidenceOf value changed');}}};
      const apply=variant=>{restore();if(variant==='C'||variant==='W')for(const pair of pairs)if(pair.grade!==null)for(const s of[pair.fine,pair.far]){s.geometry.deleteAttribute('_confidence');s.mesh.material=variant==='W'?pair.wrong:pair.material;candidate.applyExactFinalGroundMetadata(s.mesh,variant==='W'?(pair.grade===1?0:1):pair.grade);}verify(variant);};
      const p=[pos[0],pos[1],a.terrain.surfaceHeight(pos[0],pos[1])+pos[2]],t=[target[0],target[1],a.terrain.surfaceHeight(target[0],target[1])+target[2]];
      a.setFly(true);a.walker.teleport({local_e:p[0],local_n:p[1],altitude_m:pos[2],yaw_deg:Math.atan2(t[0]-p[0],t[1]-p[1])*180/Math.PI,pitch_deg:Math.atan2(t[2]-p[2],Math.hypot(t[0]-p[0],t[1]-p[1]))*180/Math.PI});a.step();
      const heldVisibility=ground.map(m=>({mesh:m.visible,instances:m._instanceInfo.map(x=>x.visible)}));
      const gl=a.renderer.getContext(),w=gl.drawingBufferWidth,h=gl.drawingBufferHeight;
      const aim=()=>{a.camera.position.set(p[0],p[2],-p[1]);a.camera.lookAt(t[0],t[2],-t[1]);a.camera.updateMatrixWorld();a.world.follow(a.camera.position);a.world.aim(a.camera);};
      // Rendering Normal once between every variant forces the real confidence
      // renderer to forget its private ghost plan before changed metadata is read.
      const reset=(renderOff=true)=>{a.setConfidenceView(false);c.resetGrades();for(const grade of['attested','inferred','reconstructed'])a.hud.setHidden(grade,false,{announce:false});if(renderOff){aim();c.render(a.renderer,a.scene3d,a.camera);}};
      const modeSet=mode=>{reset(mode.startsWith('ghost-')||mode==='xray');if(mode!=='normal')a.setConfidenceView(true);if(mode.startsWith('hidden-'))a.hud.setHidden(mode.slice(7),true,{announce:false});if(mode.startsWith('ghost-'))c.setGrade(mode.slice(6),{mode:'ghost',opacity:.5});if(mode.startsWith('dither-'))c.setGrade(mode.slice(7),{mode:'dither',opacity:.5});if(mode==='xray')for(const grade of['inferred','reconstructed'])c.setGrade(grade,{mode:'ghost',opacity:.5});};
      const picks=()=>{const out=[];for(let y=-.9;y<=.901;y+=.15)for(let x=-.9;x<=.901;x+=.15){const hit=a.railway.pickAt(new THREE.Vector2(x,y),a.camera);out.push({ndc:[x,y],hit:hit?{id:hit.id,point:hit.point.toArray(),distance:hit.distance}:null});}return out;};
      const frame=()=>{for(let i=0;i<1;i++){aim();c.render(a.renderer,a.scene3d,a.camera);}check(equal(heldVisibility,ground.map(m=>({mesh:m.visible,instances:m._instanceInfo.map(x=>x.visible)}))),'actual ghost renderer did not restore batch visibility');const px=new Uint8Array(w*h*4);gl.readPixels(0,0,w,h,gl.RGBA,gl.UNSIGNED_BYTE,px);const gs=c.ghostStats;return {px,stats:a.stats(),ghost:{targets:gs.targets,lastCalls:gs.lastCalls,opaqueSkipped:gs.opaqueSkipped,ghostSkipped:gs.ghostSkipped},picks:picks()};};
      const diff=(x,y)=>{let n=0,max=0,sum=0,over4=0;for(let i=0;i<x.length;i+=4){let d=0;for(let c=0;c<3;c++){const v=Math.abs(x[i+c]-y[i+c]);d=Math.max(d,v);sum+=v;}if(d){n++;max=Math.max(max,d);}if(d>4)over4++;}return {pixelsDiffering:n,maxChannelDelta:max,pixelsOver4ChannelValues:over4,meanAbsChannelDelta:sum/(w*h*3)};};
      const picture=px=>{const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;const ctx=canvas.getContext('2d'),flip=new Uint8ClampedArray(px.length);for(let y=0;y<h;y++)flip.set(px.subarray((h-1-y)*w*4,(h-y)*w*4),y*w*4);ctx.putImageData(new ImageData(flip,w,h),0,0);return canvas.toDataURL('image/jpeg',.9).split(',')[1];};
      const modes={},images={};let wrongControl=null,nonnull=0;
      try {for(const mode of[currentMode]){
        apply('A');modeSet(mode);const A=frame();apply('C');modeSet(mode);const C=frame();apply('D');modeSet(mode);const D=frame();verify('D');
        const cd=diff(A.px,C.px),dd=diff(A.px,D.px);check(dd.pixelsDiffering===0,'unstable restored heldframe '+mode);check(cd.pixelsDiffering===0,'candidate confidence changed pixels '+mode);check(A.stats.triangles===C.stats.triangles&&A.stats.drawCalls===C.stats.drawCalls,'native render counts changed '+mode);check(equal(A.picks,C.picks)&&equal(A.picks,D.picks),'actual railway.pickAt changed '+mode);check(A.ghost.targets===C.ghost.targets&&A.ghost.lastCalls===C.ghost.lastCalls,'actual ghost render targets/calls changed '+mode);check(equal(A.ghost,D.ghost),'restored ghost plan stats changed '+mode);
        nonnull=Math.max(nonnull,A.picks.filter(x=>x.hit).length);modes[mode]={baseline:A.stats,candidate:C.stats,restored:D.stats,candidateVsBaseline:cd,restoredVsBaseline:dd,baselineGhost:A.ghost,candidateGhost:C.ghost,restoredGhost:D.ghost,pickSamples:A.picks.length,nonnullPicks:A.picks.filter(x=>x.hit).length,picksExact:true,picks:A.picks};
        if(mode==='normal'||mode==='bygrade'){images[mode+'-before']=picture(A.px);images[mode+'-after']=picture(C.px);}
        if(mode==='bygrade'){apply('W');modeSet(mode);const W=frame();wrongControl=diff(A.px,W.px);check(wrongControl.pixelsDiffering>0,'ByGrade confidence control blind');apply('D');modeSet(mode);const E=frame();check(diff(A.px,E.px).pixelsDiffering===0,'positivecontrol restoration failed');}
      }}finally{restore();reset(false);verify('D');}
      const rows=saved.map(s=>{const pair=pairs.find(p=>p.fine===s||p.far===s),attr=s.attrs._confidence;let lo=Infinity,hi=-Infinity;const unique=new Set();for(const v of attr.array){lo=Math.min(lo,v);hi=Math.max(hi,v);unique.add(v);}return {name:s.mesh.name,kind:kinds[pair.base],grade:pair.grade,range:[lo,hi],actualUniqueValues:[...unique].sort(),vertices:attr.count,scalarBytes:attr.bytes.length,savedBytes:pair.grade===null?0:attr.bytes.length,defaultLightVisible:s.mesh.visible,defaultLightVisibleInstances:s.mesh._instanceInfo.filter(x=>x.active!==false&&x.visible).length,instances:s.mesh.userData.spatialBatch.pieces,normalType:s.attrs.normal.array.constructor.name,normalItemSize:s.attrs.normal.itemSize,normalNormalized:s.attrs.normal.normalized};});
      return {name,position:pos,target,viewport:{w,h},rows,eligibleSharedPairs:pairs.filter(p=>p.grade!==null).length,mixedOrMismatchPairsPreserved:pairs.filter(p=>p.grade===null).length,savedBytes:rows.reduce((n,r)=>n+r.savedBytes,0),visibleDefaultLightSavedBytes:rows.filter(r=>r.defaultLightVisible&&r.defaultLightVisibleInstances).reduce((n,r)=>n+r.savedBytes,0),allOtherStreamsRawBytesIndicesBoundsExact:true,allOriginalAttributesMaterialsMetadataRestored:true,actualCPUConfidenceOfEveryVertexExact:true,actualConfidenceRendererGhostPlanUsed:true,normalRecomputation:false,nonnullPicks:nonnull,wrongConfidencePositiveControl:wrongControl,modes,images,problems:a.problems};
    },{name,pos,target,currentMode});
    for(const [label,b64]of Object.entries(row.images)){const filename=`visual944-${name}-${label}.jpg`;fs.writeFileSync(path.join(O,filename),Buffer.from(b64,'base64'),{flag:'wx'});}delete row.images;
    if(!completed){completed=row;result.stands.push(completed);}else{Object.assign(completed.modes,row.modes);completed.nonnullPicks=Math.max(completed.nonnullPicks,row.nonnullPicks);if(row.wrongConfidencePositiveControl)completed.wrongConfidencePositiveControl=row.wrongConfidencePositiveControl;}
    durable(result);fs.writeFileSync(path.join(O,`${name}-${currentMode}.json`),JSON.stringify(row,null,2)+'\n',{flag:'wx'});
    console.log(JSON.stringify({stand:name,mode:currentMode,savedBytes:row.savedBytes,nonnullPicks:row.nonnullPicks,positiveControl:row.wrongConfidencePositiveControl}));
    }
    if(Object.keys(completed.modes).length!==9)throw Error('NORTH modes incomplete');
  }
  if(errors.length||bad.length)throw Error(JSON.stringify({errors,bad}));
  if(!result.stands.some(s=>s.nonnullPicks>0))throw Error('all-null NORTH picking is insufficient');
  result.status='ACTUAL_NATIVE944_CONFIDENCE_HELD_FRAMES_STRUCTURAL_AND_PIXEL_CHECKS_CLOSED_BUDGET_CHECK_PENDING';
  // Preserve every native assertion and raw failure. AIR/NORTH already exceed
  // native Light triangles in the baseline; this diagnostic cannot waive them.
  result.nativeBudgetFailures=[];
  for(const stand of result.stands)for(const [mode,row]of Object.entries(stand.modes))for(const variant of['baseline','candidate','restored'])if(!row[variant].withinBudget)result.nativeBudgetFailures.push({stand:stand.name,mode,variant,stats:row[variant]});
  if(result.nativeBudgetFailures.length)throw Error('nativebudget');
  result.status='ACTUAL_NATIVE944_CONFIDENCE_HELD_FRAMES_NATIVE_BUDGET_PASS';
}catch(e){failure=e;result.failure=String(e);}
finally{result.seconds=(Date.now()-started)/1000;fs.writeFileSync(path.join(O,'VISUAL944.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});fs.writeFileSync(path.join(O,'VISUAL944-REQUESTS.json'),JSON.stringify(requests,null,2)+'\n',{flag:'wx'});if(browser)await browser.close();await new Promise(r=>server.close(r));}
if(failure)throw failure;
console.log('PASS actual native confidence heldframe comparison and unchanged native budgets');
