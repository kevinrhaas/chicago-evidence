"""Missing NORTH only. Requires the coordinating writer's explicit review/run grant."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,shutil,subprocess,time

O=Path(__file__).parent;N=O/'visual944north'
assert os.environ.get('C4D_VISUAL944NORTH_LEASE')=='granted-by-parent','Explicit final review and internal CPU lease required'
assert os.environ.get('GIT_NO_LAZY_FETCH')=='1','Source /workspace/shared/resume-chicago-env.sh first'
assert not N.exists(),'Refusing existing NORTH attempt directory'
raw=(O/'phone-experiment.py').read_text();prefix=raw[:raw.index("assert not(O/'BINDING.json').exists()")]
ns={'__file__':str(O/'phone-experiment.py')};exec(compile(prefix,str(O/'phone-experiment.py'),'exec'),ns)
sha=ns['sha'];PRIMARY='dfb954e5eb155afb4e560bc59a431b866ab0ea93f738ad61c4270fded8920b42';CANDIDATE='a9e80f7f262c6f1ae0254c102a333fda42981f5fd2e119698280408f6f99cef0'
expected=json.loads(gzip.decompress((O/'ALL-CONSUMER-BINDINGS.json.gz').read_bytes()));binding=json.loads((O/'BINDING.json').read_bytes());state=binding['state']
assert sha((O/'BINDING.json').read_bytes())=='f590c2b695703d2da5e5323641f251585eb21f197650164ca918926ebef4c6b8'
assert sha((O/'ALL-CONSUMER-BINDINGS.json.gz').read_bytes())=='2a83979ec9dff63a49c86cfab8ffa50f214f4bcf6855e737aac93f404cc0e619'
old=json.loads((O/'VISUAL944.json').read_bytes());old_closure=json.loads((O/'VISUAL944-CLOSURE.json').read_bytes());old_requests=json.loads((O/'VISUAL944-REQUESTS.json').read_bytes());old_reaper=json.loads((O/'VISUAL944-REAPER.json').read_bytes())
assert sha((O/'VISUAL944.json').read_bytes())=='dd3763ecd0721f77ad26bed3c77b3f932d2d894e1b42a15f45ccc782f31500da'
assert sha((O/'VISUAL944-CLOSURE.json').read_bytes())=='10904c8fe6a1909bc32859055f1cc850d6f506ac1a68caca023b6964908a4e3c'
assert old_closure['raw_visual_exit']==124 and old_reaper['command_exit']==124 and old_reaper['all_children_reaped']
assert old['status']=='VISUAL944_INCOMPLETE' and old['failure']=='Error: page.evaluate: Target page, context or browser has been closed'
assert len(old['stands'])==2 and {s['name']for s in old['stands']}=={'air','lake-yard-looking-south'}
assert all(old_closure['guards'].values())and not old['errors']and not old['bad']
assert old['proof']['primary_sha256']==PRIMARY and old['proof']['candidate_sha256']==CANDIDATE
factory=old['proof']['candidate_export_response_sha256'];metadata=old['proof']['exact_metadata_block_sha256']
assert factory=='4ac3e4c10651badfd9284e0bc209d2bcd29ee639eb57816fa87e03e7f7e156ac'and metadata=='a3b59b8388ef5bd8aea750d47466032ae851898620340312e75f130992bd043e'
assert any(r['url']=='/walk/js/railway.js'and r.get('sha256')==PRIMARY for r in old_requests)
assert any(r['url']=='/walk/js/__external_uniform_confidence944.js'and r.get('sha256')==factory and r.get('candidate_sha256')==CANDIDATE for r in old_requests)
assert ns['consumer_map']()==expected and ns['git_state']()==state
assert sha((ns['A']/'renderers/web/js/railway.js').read_bytes())==PRIMARY and sha((O/'railway.js').read_bytes())==CANDIDATE
assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
old_paths=[O/n for n in ['VISUAL944.json','VISUAL944-CLOSURE.json','VISUAL944-REQUESTS.json','VISUAL944-REAPER.json','visual944.log','visual944.mjs','run-visual944.py','BINDING.json','ALL-CONSUMER-BINDINGS.json.gz','railway.js','check-external-confidence-lane.mjs','NATIVE-RESULT.json','RESULT.json','PHONE.json','PHONE-REAPER.json']]+sorted(O.glob('visual944-*.jpg'))
old_digests={p.name:sha(p.read_bytes())for p in old_paths}
N.mkdir()
with(N/'PREIMAGES.json').open('x')as f:json.dump({'old_files':old_digests,'binding_sha256':old_digests['BINDING.json'],'gzip_sha256':old_digests['ALL-CONSUMER-BINDINGS.json.gz'],'candidate_sha256':CANDIDATE,'factory_sha256':factory,'metadata_sha256':metadata,'state':state},f,indent=2);f.write('\n')
start=time.monotonic();env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
with(N/'visual.log').open('x')as log:q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(N/'REAPER.json'),'--','taskset','-c','0,1,3,4','timeout','600s','node',str(O/'visual944north.mjs')],env=env,stdout=log,stderr=subprocess.STDOUT)
reaper=json.loads((N/'REAPER.json').read_bytes())
j=json.loads((N/'VISUAL944.json').read_bytes())if(N/'VISUAL944.json').exists()else None
progress=json.loads((N/'PROGRESS.json').read_bytes())if(N/'PROGRESS.json').exists()else None
requests=json.loads((N/'VISUAL944-REQUESTS.json').read_bytes())if(N/'VISUAL944-REQUESTS.json').exists()else [json.loads(x)for x in(N/'REQUESTS-PROGRESS.jsonl').read_text().splitlines()]
proof=json.loads((N/'PROOF.json').read_bytes())if(N/'PROOF.json').exists()else None
guards={'all_consumer_bytes_modes_links_fileset_exact':ns['consumer_map']()==expected,'HEAD_MERGE_HEAD_stagedtree_index_config_allrefs_and_stagedshas_exact':ns['git_state']()==state,'all_children_reaped':reaper['all_children_reaped'],'all_original_attempt_binding_candidate_phone_native_files_immutable':all(sha(p.read_bytes())==old_digests[p.name]for p in old_paths),'current_binding_gzip_identical_preimages':sha((O/'BINDING.json').read_bytes())==old_digests['BINDING.json']and sha((O/'ALL-CONSUMER-BINDINGS.json.gz').read_bytes())==old_digests['ALL-CONSUMER-BINDINGS.json.gz'],'same_candidate_factory_and_metadata_hashes':bool(proof and proof['primary_sha256']==PRIMARY and proof['candidate_sha256']==CANDIDATE and proof['candidate_export_response_sha256']==factory and proof['exact_metadata_block_sha256']==metadata),'actual_primary_requested':any(r['url']=='/walk/js/railway.js'and r.get('sha256')==PRIMARY for r in requests),'actual_candidate_factory_requested':any(r['url']=='/walk/js/__external_uniform_confidence944.js'and r.get('sha256')==factory and r.get('candidate_sha256')==CANDIDATE for r in requests),'old_raw124_browser_closed_retained':old_closure['raw_visual_exit']==124 and old['failure']=='Error: page.evaluate: Target page, context or browser has been closed','old_source_Git_request_reaper_guards_independently_verified':True}
complete=bool(j and len(j['stands'])==1 and j['stands'][0]['name']=='lake-yard-looking-north'and len(j['stands'][0]['modes'])==9 and not j['errors']and not j['bad'])
stands=old['stands']+(j['stands']if complete else [])
parity=complete;budgets=[]
for stand in stands:
 parity=parity and stand['allOtherStreamsRawBytesIndicesBoundsExact']and stand['allOriginalAttributesMaterialsMetadataRestored']and stand['actualCPUConfidenceOfEveryVertexExact']and stand['actualConfidenceRendererGhostPlanUsed']and not stand['normalRecomputation']and len(stand['modes'])==9 and stand['wrongConfidencePositiveControl']['pixelsDiffering']>0
 for mode,row in stand['modes'].items():
  parity=parity and row['candidateVsBaseline']['pixelsDiffering']==0 and row['restoredVsBaseline']['pixelsDiffering']==0 and row['picksExact']and row['baseline']['triangles']==row['candidate']['triangles']and row['baseline']['drawCalls']==row['candidate']['drawCalls']and row['baselineGhost']['targets']==row['candidateGhost']['targets']and row['baselineGhost']['lastCalls']==row['candidateGhost']['lastCalls']and row['baselineGhost']==row['restoredGhost']
  for variant in ['baseline','candidate','restored']:
   if not row[variant]['withinBudget']:budgets.append({'stand':stand['name'],'mode':mode,'variant':variant,'stats':row[variant]})
parity=parity and any(s['nonnullPicks']>0 for s in stands)
images=sorted(str(p.relative_to(O))for p in [*O.glob('visual944-*.jpg'),*N.glob('visual944-*.jpg')])
raw_qualified=q.returncode==0 or bool(q.returncode==1 and j and j.get('failure')=='Error: nativebudget'and j.get('nativeBudgetFailures'))
closed=all(guards.values())and parity and raw_qualified and len(images)==12
out={'status':'COMBINED944_EXTERNAL_CONFIDENCE_PARITY_CLOSED_ROOT_VIEW_PENDING'if closed else'COMBINED944_EXTERNAL_CONFIDENCE_RESUME_FAILED_OR_INCOMPLETE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'first_attempt_raw_exit':124,'first_attempt_raw_failure':old['failure'],'north_attempt_raw_exit':q.returncode,'north_attempt_raw_failure':j.get('failure')if j else None,'seconds':time.monotonic()-start,'guards':guards,'combined_narrow_parity_closed':bool(closed),'completed_north_modes':list((progress or {}).get('stands',[{'modes':{}}])[0]['modes'])if progress and progress.get('stands')else [],'native_budget_failures_all_attempts':budgets,'images':images,'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free,'limits':'Original raw124/browserclosed remains unchanged. Three stand parity can close only from actual persisted nine-mode records and12images; root directview still required. All inherited AIR/NORTH triangles and SOUTHghost/Xray driver-draw failures retained with baseline/candidate rawstats. No whole-budget PASS, no primary adoption/sourcegate/final checked-head phone/CI/merge claim.'}
with(N/'COMBINED-CLOSURE.json').open('x')as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(out,indent=2),flush=True)
raise SystemExit(0 if closed else 1)
