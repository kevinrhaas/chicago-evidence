"""External-only held-frame controller. Explicit coordinating-parent CPU lease required.
Run from a shell sourcing /workspace/shared/resume-chicago-env.sh.
"""
from pathlib import Path
import datetime,gzip,json,os,shutil,subprocess,time

O=Path(__file__).parent
assert os.environ.get('C4D_VISUAL944_LEASE')=='granted-by-parent','Internal coordinating-parent CPU lease required'
assert os.environ.get('GIT_NO_LAZY_FETCH')=='1','Source /workspace/shared/resume-chicago-env.sh first'
for name in ['visual944.log','VISUAL944-REAPER.json','VISUAL944.json','VISUAL944-REQUESTS.json','VISUAL944-CLOSURE.json']:
 assert not(O/name).exists(),f'Refusing existing output {name}'
raw=(O/'phone-experiment.py').read_text()
prefix=raw[:raw.index("assert not(O/'BINDING.json').exists()")]
ns={'__file__':str(O/'phone-experiment.py')}
exec(compile(prefix,str(O/'phone-experiment.py'),'exec'),ns)
expected=json.loads(gzip.decompress((O/'ALL-CONSUMER-BINDINGS.json.gz').read_bytes()))
binding=json.loads((O/'BINDING.json').read_bytes());state=binding['state']
assert ns['consumer_map']()==expected and ns['git_state']()==state,'pre-run consumer/Git drift'
assert ns['sha']((ns['A']/'renderers/web/js/railway.js').read_bytes())=='dfb954e5eb155afb4e560bc59a431b866ab0ea93f738ad61c4270fded8920b42'
assert ns['sha']((O/'railway.js').read_bytes())=='a9e80f7f262c6f1ae0254c102a333fda42981f5fd2e119698280408f6f99cef0'
assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
start=time.monotonic()
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
with(O/'visual944.log').open('x')as log:
 q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(O/'VISUAL944-REAPER.json'),'--','taskset','-c','0,1,3,4','timeout','600s','node',str(O/'visual944.mjs')],env=env,stdout=log,stderr=subprocess.STDOUT)
reaper=json.loads((O/'VISUAL944-REAPER.json').read_bytes())
j=json.loads((O/'VISUAL944.json').read_bytes())if(O/'VISUAL944.json').exists()else None
guards={'all_consumer_bytes_modes_links_fileset_exact':ns['consumer_map']()==expected,'HEAD_MERGE_HEAD_stagedtree_index_config_allrefs_and_stagedshas_exact':ns['git_state']()==state,'all_children_reaped':reaper['all_children_reaped']}
requests=json.loads((O/'VISUAL944-REQUESTS.json').read_bytes())if(O/'VISUAL944-REQUESTS.json').exists()else []
guards['actual_primary_railway_served']=any(r['url']=='/walk/js/railway.js'and r.get('sha256')=='dfb954e5eb155afb4e560bc59a431b866ab0ea93f738ad61c4270fded8920b42'for r in requests)
guards['actual_candidate_factory_exports_served']=any(r['url']=='/walk/js/__external_uniform_confidence944.js'and r.get('candidate_sha256')=='a9e80f7f262c6f1ae0254c102a333fda42981f5fd2e119698280408f6f99cef0'and j and r.get('sha256')==j['proof']['candidate_export_response_sha256']for r in requests)
rows=[];structural=bool(j and len(j['stands'])==3 and not j['errors']and not j['bad'])
if structural:
 for stand in j['stands']:
  ok=stand['allOtherStreamsRawBytesIndicesBoundsExact']and stand['allOriginalAttributesMaterialsMetadataRestored']and stand['actualCPUConfidenceOfEveryVertexExact']and stand['actualConfidenceRendererGhostPlanUsed']and not stand['normalRecomputation']and stand['wrongConfidencePositiveControl']['pixelsDiffering']>0
  for mode,row in stand['modes'].items():
   ok=ok and row['candidateVsBaseline']['pixelsDiffering']==0 and row['restoredVsBaseline']['pixelsDiffering']==0 and row['picksExact']and row['baseline']['triangles']==row['candidate']['triangles']and row['baseline']['drawCalls']==row['candidate']['drawCalls']
  structural=structural and ok
  rows.append({'stand':stand['name'],'saved_bytes':stand['savedBytes'],'visible_default_light_saved_bytes':stand['visibleDefaultLightSavedBytes'],'eligible_shared_pairs':stand['eligibleSharedPairs'],'nonnull_pick_samples':stand['nonnullPicks'],'wrong_confidence_positive_control':stand['wrongConfidencePositiveControl'],'normal_baseline_within_budget':stand['modes']['normal']['baseline']['withinBudget'],'normal_candidate_within_budget':stand['modes']['normal']['candidate']['withinBudget'],'narrow_structural_and_pixel_parity_pass':bool(ok)})
 structural=structural and any(s['nonnullPicks']>0 for s in j['stands'])
budget_only_failure=bool(q.returncode==1 and j and j.get('failure')=='Error: nativebudget'and j.get('nativeBudgetFailures'))
raw_qualified=bool(q.returncode==0 or budget_only_failure)
images=sorted(p.name for p in O.glob('visual944-*.jpg'))
closed=all(guards.values())and structural and raw_qualified and len(images)==12
out={'status':'ACTUAL944_EXTERNAL_CONFIDENCE_HELD_FRAMES_CLOSED_ROOT_VIEW_PENDING'if closed else'ACTUAL944_EXTERNAL_CONFIDENCE_VISUAL_FAILED_OR_INCOMPLETE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_visual_exit':q.returncode,'seconds':time.monotonic()-start,'guards':guards,'structural_and_pixel_parity_closed':closed,'raw_failure':j.get('failure')if j else None,'inherited_native_budget_failure_retained':budget_only_failure,'stands':rows,'images':images,'limits':'External candidate factory on existing native baseline batches only; native fixture construction covered separately. Actual private ghost plan rendered and rebuilt by an off render between every variant; raw skip counts may differ because baseline counts whole objects and candidate counts instances. Twelve native Normal/ByGrade before/after images require root direct viewing. Restored D is asserted pixel-exact in every mode. Inherited AIR/NORTH budget assertions retained with raw exit1 when failing in baseline/candidate; no whole-budget pass claim. This is uncommitted/ungated944 diagnostic, not primary adoption, source gate, final checked-head phone, current CI or merge.'}
with(O/'VISUAL944-CLOSURE.json').open('x')as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(out,indent=2),flush=True)
raise SystemExit(0 if closed else 1)
