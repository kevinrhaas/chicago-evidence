from pathlib import Path
import argparse,datetime,hashlib,json,os,re,shutil,subprocess,time
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path(__file__).parent;E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def g(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
args=argparse.ArgumentParser();args.add_argument('--expect-head',required=True);args.add_argument('--expect-merge-parent',required=True);args=args.parse_args();assert re.fullmatch('[0-9a-f]{40}',args.expect_merge_parent)and re.fullmatch('[0-9a-f]{40}',args.expect_head)
head=args.expect_head;parent=args.expect_merge_parent;assert g('rev-parse','origin/dev').decode().strip()==parent;assert g('rev-parse','HEAD').decode().strip()==head and g('rev-parse','MERGE_HEAD').decode().strip()==parent
unmerged=g('diff','--name-only','--diff-filter=U').decode().splitlines();assert set(unmerged)<={'chicago/4d/data/liberties.json','chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/docs/measurements/source_use_coverage.md'},unmerged
if unmerged:g('checkout','--ours','--',*unmerged)
manifest=json.loads((A/'tools/derived_manifest.json').read_bytes());owned={p for step in manifest['steps']for p in step.get('resolves',[])}
paths=[p.decode()for p in g('diff','--name-only','--cached','-z').split(b'\0')if p];authored={p:sha((R/p).read_bytes())for p in paths if p not in owned};authored['chicago/4d/data/front_yards/1904.json']=sha((A/'data/front_yards/1904.json').read_bytes());models={p.relative_to(R).as_posix():sha(p.read_bytes())for folder in ['gltf','web']for p in(A/'assets'/folder).rglob('*.glb')if not p.is_symlink()};save('BEFORE-MODELS.json',models);save('BEFORE-AUTHORED.json',authored)
binary={}
for row in g('ls-files','--stage','--','*.gz','*.xlsx').splitlines():
 meta,path=row.split(b'\t',1);mode,oid,stage=meta.decode().split();assert stage=='0';path=path.decode();data=g('cat-file','blob',oid);assert (R/path).read_bytes()==data;binary[path]={'oid':oid,'bytes':len(data),'sha256':sha(data)}
assert len(binary)==44;save('BEFORE44.json',binary);config=sha((R/'.git/config').read_bytes());assert config=='5536e1343e7abdacddfce3d5438e08872ad6a33295900466b529df5e0c57e730'
bind={'at':now(),'head':head,'merge_parent':parent,'unmerged':unmerged,'earliest_native_step':'tools/compile_liberties.py','expected_tail_steps':61,'all_models':len(models),'all_authored_staged_guarded':len(authored),'all44_canonical_index_blobs_verified':True,'config_sha256':config,'workspace_free_before':shutil.disk_usage('/workspace').free,'tmp_free_before':shutil.disk_usage('/tmp').free,'scope':'Prepared explicit61fixed-point tail for genuine2b01+reviewed-currentdev merge. ClearONLYknownmanifestconflictworkingfiles via nativeoursprotocol, stageONLYafteractualregeneration. ProtectretainedT1881frontyard and existingcompactrailrepair. No204repeat/manualgeneratedcontent.'};save('BINDING.json',bind)
assert bind['workspace_free_before']>=536870912 and bind['tmp_free_before']>=1800000000
# Native sequence contract: the final owner reads the actual published mirror.
# Its previous2b01 snapshot must not stand in for the newly merged reviewed-currentdev sources.
publish_started=time.monotonic()
with(O/'pre-tail-publish.log').open('x')as log:
 publication=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(O/'pre-tail-publish-REAPER.json'),'--','taskset','-c','0,1,3,4','bash','tools/publish.sh'],cwd=A,env=E,stdout=log,stderr=subprocess.STDOUT)
publication_reaper=json.loads((O/'pre-tail-publish-REAPER.json').read_bytes());assert publication.returncode==0 and publication_reaper['all_children_reaped'];save('PRE-TAIL-PUBLISH.json',{'status':'ACTUAL_NATIVE_PUBLISH_BEFORE_EXPLICIT61_PASS','exit':publication.returncode,'seconds':time.monotonic()-publish_started,'all_children_reaped':True})
assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
start=time.monotonic()
with(O/'resolve.log').open('x')as f:q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(O/'REAPER.json'),'--','taskset','-c','0,1,3,4','node','tools/rederive.mjs','--tail','tools/compile_liberties.py'],cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
rp=json.loads((O/'REAPER.json').read_bytes());
if q.returncode==0 and rp['all_children_reaped']:
 g('add','--',*unmerged,'chicago/4d/data/front_yards/1904.json')
 owned_moved=[p for p in g('diff','--name-only').decode().splitlines()if p in owned]
 if owned_moved:g('add','--',*owned_moved)
guards={'HEAD':g('rev-parse','HEAD').decode().strip()==head,'MERGE_HEAD':g('rev-parse','MERGE_HEAD').decode().strip()==parent,'config':sha((R/'.git/config').read_bytes())==config,'authored_staged_bytes':all(sha((R/p).read_bytes())==s for p,s in authored.items()),'all_models':all(sha((R/p).read_bytes())==s for p,s in models.items()),'no_conflicts':not g('ls-files','-u'),'all_children_reaped':rp['all_children_reaped']};audit=[]
for p,b in binary.items():
 native=(R/p).read_bytes();audit.append({'path':p,'before_sha256':b['sha256'],'after_sha256':sha(native),'byte_exact':sha(native)==b['sha256'],'baseline_immutable_oid':b['oid']})
save('ALL44.json',audit);text=(O/'resolve.log').read_text();settled='the last one moved nothing' in text;native61='61 step(s) in manifest order' in text;passed=q.returncode==0 and all(guards.values())and settled and native61
save('RESULT.json',{'status':'ACTUAL_NATIVE_FINAL944_EXPLICIT61_SETTLED_PASS'if passed else'ACTUAL_NATIVE_FINAL944_EXPLICIT61_NOT_QUALIFIED','at':now(),'exit':q.returncode,'seconds':time.monotonic()-start,'guards':guards,'native61':native61,'last_native_lap_moved_nothing':settled,'binary44_exact':sum(r['byte_exact']for r in audit),'binary44_changed':[r['path']for r in audit if not r['byte_exact']],'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free,'limits':'Native resolver/fixed-point closure only. Binarysemantic classification owed if changed; railway repair/fullgate/currentphone/nativecommit/PRpush/newCI/merge pending.'});print((O/'RESULT.json').read_text(),flush=True);raise SystemExit(0 if passed else 1)
