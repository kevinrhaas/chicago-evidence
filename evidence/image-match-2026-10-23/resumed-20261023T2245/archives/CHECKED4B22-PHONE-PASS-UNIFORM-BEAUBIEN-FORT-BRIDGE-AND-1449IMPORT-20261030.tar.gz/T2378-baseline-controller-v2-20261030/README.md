# V2: relocate owned capture scratch into workspace

V1 `/workspace/T2378-baseline-controller-20261030/` and the original closed readiness packet remain unchanged. V2 changes resource placement and pricing only. Camera, whole original photo,69cb MASTER, selected recipe/WEB binding, four unchanged native tool modules,14 guarded links, normal native Chromium executable/arguments, stopping rule and unreviewed output contract are unchanged.

Read-only rehearsal, creating no fixture/browser:

```sh
source /workspace/shared/resume-chicago-env.sh
python /workspace/T2378-baseline-controller-v2-20261030/capture.py
```

After a separate root CPU/source grant:

```sh
source /workspace/shared/resume-chicago-env.sh
T2378_BASELINE_CPU_LEASE=root-one-current-master-baseline python /workspace/T2378-baseline-controller-v2-20261030/capture.py --execute --cpu 0,1,3,4
```

V2 execution owns `/workspace/T2378-native-baseline-exec-v2-20261030/`. Command-scoped `TMPDIR` points to its `tmp/`, `XDG_CACHE_HOME` to `cache/`, and `XDG_CONFIG_HOME` to `config/`; those directories are created only on authorized execution. HOME, installed tools, global configuration and native source are unchanged. The one native command and its Playwright/Chromium children inherit these variables.

Workspace precondition is536,870,912B+24MiB =562,036,736B free. The24MiB reserve covers the <0.25MiB fixture, raw/comparison outputs and20MiB short-lived browser scratch/cache allowance. These are priced allowances, not observed consumption. Shared TMP must retain its unchanged1,800,000,000B floor; extra reserve is0 because owned payload has moved. No floor or monitor threshold is weakened. The existing0.2s monitor and owned subreaper remain; actual minima are recorded on execution.

Native `photo_match.mjs:219` creates its raw screenshot directory with Node `os.tmpdir()`. Playwright `browserType.js:157,164` creates artifacts and default profile under `os.tmpdir()`; its launch process selects `process.env` when `options.env` is absent, Chromium `amendEnvironment` returns that environment unchanged, and `processLauncher` passes it to the browser spawn. The exact env probe in `ENVIRONMENT-PATH-PROOF.json` confirms fresh Node resolves `os.tmpdir()` to the deferred owned workspace path without creating it. XDG variables are also observed there; Chromium's normal profile is the Playwright-owned user-data path.

One literal shared `/tmp` remains in Debian's unchanged `/usr/bin/chromium:137`: the GDB debug branch uses `mktemp /tmp/chromiumargs.XXXXXX`. The coordinator was informed before V2 preparation. `want_debug` defaults0, and the unchanged normal native/Playwright launch supplies neither `-g` nor `--debug`; this branch is inactive. The wrapper's separate `--temp-profile` branch is also unused and its plain `mktemp -d` would respect TMPDIR. `/etc/chromium.d/dev-shm` documents TMPDIR use when `--disable-dev-shm-usage` applies. No executable/argument workaround or claim of zero unobservable Chromium-internal file activity is made; shared TMP still has its full floor and live monitor.

`V2-ONLY.diff` is the exact controller/plan difference from the sealed V1. Source-frame and candidate camera JSON are byte-identical to V1. This preparation still represents one isolated diagnostic comparison, with Wentworth1881's inferred identity proposal, Hubbard criticism and1831/1835 survival assumption intact. It does not apply the identity patch, edit geometry, solve a new camera, attest the Factor's House as this dwelling, mark matches or close T2378. Fixture/browser/native capture remain UNRUN.
