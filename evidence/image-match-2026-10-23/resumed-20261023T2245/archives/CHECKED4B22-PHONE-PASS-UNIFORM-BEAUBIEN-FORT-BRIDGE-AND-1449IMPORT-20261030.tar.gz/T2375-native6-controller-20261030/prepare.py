from pathlib import Path
import ast, copy, datetime, hashlib, importlib.util, json, os, stat, struct, sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent; A=Path('/workspace/chicago/chicago/4d')
assert not (P/'CONTROLLER-CLOSED-MANIFEST.json').exists(),'closed packet is immutable; prepare a new version directory'
OLD=Path('/workspace/T2375-currentGT-authored-rebind-20261030')
V=Path('/workspace/T2375-native-v5-width16-20261029')
POST=OLD/'postimages/chicago/4d'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def bound(p):
 s=p.stat();return {'path':str(p),'bytes':s.st_size,'sha256':sha(p),'mode':stat.S_IMODE(s.st_mode)}
old=json.loads((OLD/'RESULT.json').read_text()); family0=json.loads((V/'INPUTS.json').read_text())['family']
sys.path.insert(0,str(A/'generators')); import mesh_inputs
manifest=json.loads((A/'assets/manifest.json').read_text())['assets']
web=json.loads((A/'assets/manifest.web.json').read_text())['masters']
rows=[]; currentdocs={}
for r in family0:
 rec=json.loads((A/'data/structures'/(r['id']+'.json')).read_text()); ph=next(x for x in rec['phases']if x['id']==r['phase'])
 d=mesh_inputs.structure_inputs_doc(rec,ph,'bridge_timber'); h=mesh_inputs.structure_inputs_sha(rec,ph,'bridge_timber')
 assert h==manifest[r['asset']]['inputs_sha256'],r['asset']
 assert sha(A/'assets/gltf'/r['asset'])==r['current_master_sha256']
 assert web[r['asset']]==sha(A/'assets/gltf'/r['asset'])
 currentdocs[r['id']]=d
 rows.append({'id':r['id'],'phase':r['phase'],'asset':r['asset'],'role':'selected'if r['id']=='dearborn_street_drawbridge'else'default_control','record':bound(A/'data/structures'/(r['id']+'.json')),'MASTER':bound(A/'assets/gltf'/r['asset']),'WEB':bound(A/'assets/web'/r['asset']),'current_native_recipe':h})
spec=importlib.util.spec_from_file_location('bridge_candidate_params',POST/'generators/archetypes/bridge_timber_params.py');mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
original_resolve=mesh_inputs.resolve_params;original_sha=mesh_inputs._sha_file
mesh_inputs.resolve_params=lambda arch,ph,rec:mod.from_phase(ph,rec)if arch=='bridge_timber'else original_resolve(arch,ph,rec)
mesh_inputs._sha_file=lambda p:sha(POST/'generators/archetypes/bridge_timber.py')if p==A/'generators/archetypes/bridge_timber.py'else original_sha(p)
for r in rows:
 rec=json.loads((POST/'data/structures/dearborn_street_drawbridge.json'if r['role']=='selected'else Path(r['record']['path'])).read_text());ph=next(x for x in rec['phases']if x['id']==r['phase'])
 d=mesh_inputs.structure_inputs_doc(rec,ph,'bridge_timber');r['proposed_native_doc']=d;r['proposed_native_recipe_EXPECTED_NOT_BUILT']=mesh_inputs.structure_inputs_sha(rec,ph,'bridge_timber')
 hist=next(x for x in old['native6']if x['id']==r['id']);assert r['proposed_native_recipe_EXPECTED_NOT_BUILT']==hist['proposed_inputs_sha256'],r['id']
mesh_inputs.resolve_params=original_resolve;mesh_inputs._sha_file=original_sha
copies=[]
for p in sorted((A/'generators').rglob('*')):
 if not p.is_file()or'__pycache__'in p.parts or p.suffix not in('.py','.pin'):continue
 rel=str(p.relative_to(A));q=POST/rel if rel in['generators/archetypes/bridge_timber.py','generators/archetypes/bridge_timber_params.py']else p
 copies.append({'rel':rel,'source':bound(p),'postimage':bound(q)})
for rel in ['tools/web_derivatives.sh','tools/structure_versions.py','tools/web_derivative_baseline.json','tools/photo_match.mjs','tools/photo_match_group.mjs','tools/photo_match_enclosures.mjs','tools/photo_match_flora.mjs']:
 copies.append({'rel':rel,'source':bound(A/rel),'postimage':bound(A/rel)})
camera=POST/'data/reference_views/dearborn_street_drawbridge/earle_1902_lunette.json';cam=json.loads(camera.read_text());assert cam['diagnostic_only']and not cam.get('also_render')and not cam.get('enclosures')and not cam.get('flora')
photo=(A/'data/reference_views/dearborn_street_drawbridge'/cam['photo']).resolve();assert photo.is_file()
images={}
for r in rows:
 raw=Path(r['MASTER']['path']).read_bytes();n,_=struct.unpack_from('<II',raw,12);images[r['asset']]=len(json.loads(raw[20:20+n]).get('images',[]))
assert not any(images.values()),images
regs=['assets/manifest.json','assets/manifest.web.json','assets/manifest.versions.json']
versions=json.loads((A/regs[2]).read_text());assert not any(r['id']in json.dumps(versions)for r in rows)
source_readiness=[]
for x in old['paths']:
 q=Path('/workspace/chicago')/x['path'];source_readiness.append({'path':x['path'],'current_sha256':sha(q)if q.is_file()else None,'old_packet_preimage_matches':(sha(q)if q.is_file()else None)==x['before_sha256'],'postimage_sha256':x['after_sha256'],'NOT_whole_file_adoption_authorized':True})
plan={'status':'PREPARED_UNRUN_NO_FIXTURE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'primary':str(A),'family':rows,'copies':copies,'regs':regs,'candidate_record':bound(POST/'data/structures/dearborn_street_drawbridge.json'),'camera':bound(camera),'photo':bound(photo),'source_provenance':[bound(p)for p in sorted((POST/'data/sources').glob('*.json'))],'historical_packet':bound(OLD/'RESULT.json'),'historical_V5_native':bound(V/'CLOSED-RESULT.json'),'reaper':bound(Path('/workspace/shared/run-with-reaping.py')),'blender':'/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender','cpu':'0,1,3,4','threads':4,'workspace_floor':536870912,'tmp_floor':1800000000,'start_extra_reserve':24*1024*1024,'short_private_TMPDIR':'/workspace/b2375-native-tmp','expected_candidate_MASTER':{'sha256':'c7408d424c67488f56650e190fdd7af6a23a667c67f005dff1849ef20c3b2f84','bytes':1101020},'expected_candidate_WEB':{'sha256':'f7abac99a73e858b055c5668a61e093a7786385cb542cecb3245ebc55d7907ab','bytes':136752},'scaffold_regular_bytes':sum(x['postimage']['bytes']for x in copies)+sum((A/x).stat().st_size for x in regs),'foreign_MASTER_symlink_allocation_upper':len(list((A/'assets/gltf').rglob('*.glb')))*4096,'current6_MASTER_WEB_bytes':sum(x['MASTER']['bytes']+x['WEB']['bytes']for x in rows),'current_MASTER_image_counts':images,'selected_full_native_input_docs_equal_bound_V5':True,'bridge_dimensions_piles':'76.33m mapped gap/18.288m attested draw/16ft width; 46 reconstructed piles per cap,92total','source_20_readiness':source_readiness,'grant':'T2375_NATIVE_CPU=root-approved-frozen-native6','scope':'Official6 exports+WEB5default controls+selected exactV5 plus ONE Earle single-anchor fullbridge diagnostic capture. No primary/source/ticket/app/gate/PR/DONE; no geometry/camera iteration.'}
(P/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'status':plan['status'],'family':len(rows),'current_recipes_fresh':len(rows),'proposed_input_docs_exact_V5':len(rows),'scaffold_bytes':plan['scaffold_regular_bytes'],'MASTER_WEB_current':plan['current6_MASTER_WEB_bytes'],'reserve':plan['start_extra_reserve'],'source20_old_preimages_exact':sum(x['old_packet_preimage_matches']for x in source_readiness),'no_fixture':True}))
