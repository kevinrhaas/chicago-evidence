The closed README's execution example contains a spacing typo, `--seconds330`.
No execution occurred. The unchanged controller expects the ordinary separate
arguments `--seconds 330`:

```text
source /workspace/shared/resume-chicago-env.sh
T2375_NATIVE_CPU=root-approved-frozen-native6 python3 /workspace/T2375-native6-controller-20261030/controller.py --execute --seconds 330
```

All six original payloads and their first manifest stay immutable. This addendum
changes no controller, plan, source, future output or resource requirement.
