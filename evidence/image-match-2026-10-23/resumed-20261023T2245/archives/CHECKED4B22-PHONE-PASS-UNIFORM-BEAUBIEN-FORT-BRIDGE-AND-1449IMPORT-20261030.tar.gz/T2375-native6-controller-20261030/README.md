# T2375 official six-bridge controller — prepared, not executed

This closes the next finite native trial for the existing V5 proposal. No fixture, Blender, WEB generation, browser, source adoption, ticket change, Git operation, gate, PR or completion was performed. Current primary is owned by the parent integration agent; execution requires a later explicit CPU/source-freeze grant.

Pure preparation actually recomputed all six CURRENT native recipes and matched every canonical manifest row. The proposed full native input documents also exactly match all six bound V5 documents. Current six MASTER+WEB files total1,785,652B. Five controls stay at their existing records; Dearborn alone takes the accepted V5 record. Both producer preimages and the candidate record remain exact. Fifteen of the historical20 authored preimages still match current source; the other five are the known shared name-pool/contract/main/walker/compiler hooks. Those require entry-wise future rebase, not whole-file replay. They are not adopted or copied by this build fixture.

The six official selections are Dearborn, LaSalle slough crossing, north-branch bridge, north-water slough crossing, slough-log bridge and south-branch raft bridge. Every current bridge MASTER has zero embedded images and no bridge versions exist. Native fixture recipe hashes are recomputed again before export. The unchanged pinned build.py/emit pipeline performs six real exports with UV/bake defaults, AO off, no scene restriction. The actual native WROTE set must be exactly six. Official web_derivatives.sh then runs for those actual names. Five default MASTER and WEB outputs must equal current primary bytes; each output's actual mode is recorded without inventing an OS0644 requirement from Git100644. Dearborn must reproduce the actual accepted V5 MASTER c7408d42…1,101,020B and WEB f7abac99…136,752B. All foreign registry entries, metadata and version registry remain exact.

The historical trial used emit directly and never wrote canonical recipe rows. Its output/input evidence is real, but the future official build owns canonical rows; PLAN's expected hashes are not hand-stamped output evidence. After all outputs close, five identical owned control duplicates can retire against their retained exact primary restore authorities. The selected MASTER/WEB move outside the disposable fixture and remain preserved.

The one full-bridge Earle capture uses the already corrected diagnostic camera verbatim, with the actual newly built MASTER selected by the genuine native manifest. It is a single anchor, not a fake compound/sidecar. The four-parent relative photograph algebra is checked explicitly: the source link lives under run/reference, outside fixture. Native JPEG/raw/camera/unreviewed match are preserved outside fixture and included in the closed manifest. Root must directly view this actual comparison; no matches verdict is predeclared. No geometry or camera iteration is proposed.

Source scope remains honest. The independently verified c1902 Earle volume supplies the cleared underlying artwork; its old1849 filename stays for link continuity. Andreas/Norton/Moses independently carry the geometry. The owner's TribuneEditorial February15,1880 credit is attributed, while the exact Baker artwork remains unlocated/reference-only; no Baker-derived camera or clearance is invented. The bridge keeps the mapped76.33m gap,18.288m draw and16ft width. Pile platforms contain46 reconstructed perimeter piles each,92total;38 belongs to an older narrower trial.

## Execution envelope

The regular native source/tool/registry scaffold is5,102,349B. A conservative foreign MASTER symlink allocation upper bound and1.79MB six-output baseline are priced in PLAN. Runtime/modules/source photos remain read-only links; no whole runtime or asset copy. Short private browser scratch is /workspace/b2375-native-tmp, created only after grant, avoiding the historical deep-path socket error. Start reserve is24MiB above the unchanged workspace536,870,912B and TMP1,800,000,000B floors, so workspace must be at least562,036,736B. Current preparation observed approximately551.6MB and therefore DOES NOT fit the future reserve. No resource approval or floor reduction is implied. Recheck and fund only verified restorable space before grant.

Actual historical direct six-control+candidate export cost1.66s, selected WEB3.11s and corrected Earle capture4.62s. These are not an official six-batch timing promise. A practical estimate is20–60s WEB/build plus5–15s capture, with explicit per-stage limits90/120/75s and330s controller lease. Every heavy child runs serially under nice19, affinity0,1,3,4, pinned Blender4.5.3/threads4 and the shared reaper. Continuous floors/source registry guards stop the owned stage; all failures and partial outputs remain available. The pipeline closes the six native assets before starting the camera, so photo failure cannot erase a completed native result.

Read-only preflight:

```text
source /workspace/shared/resume-chicago-env.sh
taskset -c 2 python3 /workspace/T2375-native6-controller-20261030/controller.py
```

Only after root's explicit grant and primary source freeze:

```text
T2375_NATIVE_CPU=root-approved-frozen-native6 python3 /workspace/T2375-native6-controller-20261030/controller.py --execute --seconds330
```

The separate --family-only / --capture-only phases preserve honest closed-family results. After actual root direct-view approval, --retire-fixture --root-viewed verifies all closed retained artifacts/reapers and removes only this controller's own fixture and short scratch. No target of a read-only link is removed.

Native full sidecars/scene/rights/source-use/grades/Liberties, final canonical Andreas and Earle matches, current BOTH viewport Images/Sources/Research/walking/prop contact, smoke budget, full source/preflight checks and policy PR/dev merge remain owed before original T2375 can close. This controller is one bounded next trial, not that closure.
