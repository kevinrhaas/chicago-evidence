from pathlib import Path
import json, subprocess, hashlib, datetime
repo=Path('/tmp/tremont-picture-20261026');app=repo/'chicago/4d';runtime=Path('/tmp/tremont-T2385-runtime-20261026')
def g(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=repo).decode().strip()
assert json.loads(Path('/tmp/tremont-T2385-app-four-loads-closed-20261026/RESULT.json').read_text())['world_loads']==4
assert g('rev-parse','HEAD')=='cf25a3f2bb653648d25502fe5fab914b8cb29453'
assert g('rev-parse','MERGE_HEAD')=='132e0e85a9645055de1bfc4544942ec969b14511'
assert not g('diff','--name-only','--diff-filter=U')
expected=json.loads(Path('/tmp/tremont-T2385-app-prepared-20261026/expected.json').read_text())
for e in expected['records']+expected['outputs']:assert hashlib.sha256((app/e['path']).read_bytes()).hexdigest()==e['sha256'],e['path']
outside='chicago/reference/resident-research/final/audit/resident_audit_master.xlsx'
assert g('hash-object',outside)==g('rev-parse','132e0e85a9645055de1bfc4544942ec969b14511:'+outside)
assert all(p.startswith('chicago/4d/')or p==outside for p in g('diff','--name-only').splitlines())
subprocess.run(['git','add','-A','--','chicago/4d',outside],cwd=repo,check=True)
assert not g('diff','--name-only') and not g('ls-files','--others','--exclude-standard')
subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True)
result={'status':'FROZEN_FOR_REQUIRED_NATIVE3QUESTIONS_NO_CODE_COMMIT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'HEAD':g('rev-parse','HEAD'),'MERGE_HEAD':g('rev-parse','MERGE_HEAD'),'branch':g('branch','--show-current'),'candidate_index_tree':g('write-tree'),'cached_origin_dev':g('rev-parse','origin/dev'),'source_and_four_output_bindings':expected,'outside4d_current132e_exact':outside,'all_working_files_staged_no_untracked':True,'app_receipt':'/tmp/tremont-T2385-app-four-loads-closed-20261026/RESULT.json','ancestry':'Normal pending merge cf25GT+132edev with own source/version/native2+2. No failed-tree codecommit or ancestryrewrite.','pending':'Required wholecheck+nativeCL+IDs before normalcommit, then actualcommittedCL/IDs before publicdevPR/ownlap; GT1328/fold/latestdev/requiredcoverage beforemerge. Original2385OPEN/DIF.'}
(runtime/'CODEGATE-CANDIDATE.json').write_text(json.dumps(result,indent=2)+'\n')
(runtime/'candidate-vs132e.stat').write_text(g('diff','--cached','--stat','132e0e85a9645055de1bfc4544942ec969b14511')+'\n')
print(json.dumps({k:result[k]for k in ('status','HEAD','MERGE_HEAD','candidate_index_tree')},indent=2))
