The first Tremont now follows Gale’s retrospective, specifically 1835-framed account: a smaller 30 × 20 ft, two-storey yellow hotel. Feet and natural long/short axes are inferred; the 5.45 m wall height and stock yellow remain reconstructed. Both Lake and Dearborn street-facing planes stay fixed, and the native roof-staff flag anchor follows the smaller geometry.

The existing three-storey picture interpretation is retained as the native `gifford-reading` version, with its reconstructed 50 × 30 ft scale and unpainted colour explicitly disputed. Gifford’s drawing is undated within the first house’s life; no enlargement date is invented. The default’s omitted shutters are a disclosed native-kit simplification, not a statement that Gale attests their absence.

Sources: [Gale1902, printed p51](https://archive.org/details/reminiscencesofe00ingale/page/n76/mode/1up), with the1835 context on p25/p43; [attributed Gifford drawing on Chicagology](https://chicagology.com/prefire/prefire021/). The user’s attributed project-reference approval is preserved without inventing public-domain provenance for the drawing.

Original T-2385 remains OPEN/DIF. The two-storey default does not match the drawing’s real third storey or pictured shutters; no image-gate match or ticket closure is claimed.

Dependency: Green Tree PR#1328 must land and fold first. This branch carries its checked public cf25 ancestry and must not merge before that dependency, current-dev integration, and required smoke coverage.

Validation will be filled from the actual closed app and three-question gate receipts before the PR is opened.
