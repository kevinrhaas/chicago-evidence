from pathlib import Path
import os, subprocess, json, datetime, shutil, time, hashlib

os.sched_setaffinity(0,{2,4})
repo=Path('/tmp/tremont-picture-20261026'); app=repo/'chicago/4d'
runtime=Path('/tmp/tremont-T2385-runtime-20261026')
out=Path('/tmp/T2385-three-question-gate-20261026')
assert not out.exists();out.mkdir()
os.environ.update(CHECK_JOBS='2',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',GITHUB_BASE_REF='dev',C4D_RULINGS_BASE='132e0e85a9645055de1bfc4544942ec969b14511',TMPDIR='/tmp/t2385-g',CHECK_TIMINGS=str(out/'check-timings.tsv'))
os.environ.pop('GIT_NO_LAZY_FETCH',None);os.environ.pop('CHICAGO_TICKETS_DIR',None)
Path(os.environ['TMPDIR']).mkdir(exist_ok=True)
def g(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=repo).decode().strip()
candidate=json.loads((runtime/'CODEGATE-CANDIDATE.json').read_text())
head=g('rev-parse','HEAD'); merge=g('rev-parse','MERGE_HEAD'); tree=g('write-tree')
assert head==candidate['HEAD'] and merge==candidate['MERGE_HEAD'] and tree==candidate['candidate_index_tree']
assert head=='cf25a3f2bb653648d25502fe5fab914b8cb29453' and merge=='132e0e85a9645055de1bfc4544942ec969b14511'
assert not g('diff','--name-only') and not g('ls-files','--others','--exclude-standard')
assert json.loads((Path('/tmp/tremont-T2385-app-four-loads-closed-20261026')/'RESULT.json').read_text())['world_loads']==4
idbase=g('rev-parse','origin/dev');mb=g('merge-base',idbase,'HEAD')
expected=json.loads(Path('/tmp/tremont-T2385-app-prepared-20261026/expected.json').read_text())
for e in expected['records']+expected['outputs']:
    assert hashlib.sha256((app/e['path']).read_bytes()).hexdigest()==e['sha256'],e['path']
floor=2040109465;free=shutil.disk_usage('/tmp').free
conditions={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'HEAD':head,'MERGE_HEAD':merge,'candidate_tree':tree,'precommit_mergebase':mb,'ending_ids_cached_base':idbase,'tmp_free_before':free,'ROOT_external_startup_budget_bytes':floor,'budget_kind':'Root external1.9GiB orchestration startup budget; no native repository assertion changed and no midrun kill for ordinary fixture allocation.','native_environment':{k:os.environ[k]for k in ('CHECK_JOBS','C4D_GATE_REQUIRE_READERS','C4D_GATE_REQUIRE_BASE','GITHUB_BASE_REF','C4D_RULINGS_BASE','TMPDIR')},'explicitly_unset':['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR'],'cpu':sorted(os.sched_getaffinity(0)),'native_commands':'Identical3questions from native preflight.sh; only its unsafe broad commonGit fetch is omitted. Root explicitly authorizes frozen132e candidate with current cacheddev before public code checkpoint; latest-dev normal integration remains owed before merge.'}
(out/'CONDITIONS.json').write_text(json.dumps(conditions,indent=2)+'\n')
assert free>=floor,('EXTERNAL_STARTUP_RESERVE_NOT_NATIVE_GATE',free,floor)
results=[];start=time.monotonic()
for name,cmd in [('1-native-wholecheck',['bash','tools/check.sh']),('2-native-changelog-entry',['node','tools/check-changelog-entry.mjs',mb,'HEAD']),('3-native-id-collisions',['node','tools/resolve_id_collisions.mjs','--base',idbase,'--check'])]:
    print(name,'START',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True);t=time.monotonic()
    with(out/(name+'.log')).open('x')as log:r=subprocess.run(cmd,cwd=app,stdout=log,stderr=subprocess.STDOUT)
    row={'question':name,'command':cmd,'exit_code':r.returncode,'seconds':round(time.monotonic()-t,3)}
    results.append(row);(out/'QUESTIONS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
guard={'HEAD':g('rev-parse','HEAD')==head,'MERGE_HEAD':g('rev-parse','MERGE_HEAD')==merge,'index':g('write-tree')==tree,'working_tree':not g('diff','--name-only'),'untracked':not g('ls-files','--others','--exclude-standard')}
passed=all(r['exit_code']==0 for r in results)and all(guard.values())
result={'status':'PASS_ALL3_NATIVE_PREFLIGHT'if passed else'FAIL_NATIVE_PREFLIGHT_RETAINED','questions':results,'native_footer':(out/'1-native-wholecheck.log').read_text(errors='replace').splitlines()[-10:],'frozen_guards':guard,'candidate_tree':tree,'HEAD':head,'MERGE_HEAD':merge,'seconds':round(time.monotonic()-start,3),'tmp_free_after':shutil.disk_usage('/tmp').free,'pending':'Normal codecommit ONLYafter actualPASS, then actual committed-head nativeCL/IDs, normalpush/devPR/ownlap. OriginalT2385 staysOPEN/DIF; cannotmergebeforeGT1328/fold/latestintegration/requiredcoverage.'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
raise SystemExit(0 if passed else 1)
