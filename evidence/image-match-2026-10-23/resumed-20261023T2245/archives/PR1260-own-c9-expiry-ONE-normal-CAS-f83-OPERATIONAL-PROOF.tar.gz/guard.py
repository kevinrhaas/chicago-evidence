"""One normal expiry continuation of exact own marker c9; no early/forced/released lease."""
import pathlib,json,subprocess,datetime,hashlib,concurrent.futures,time,os,sys,shutil
P=pathlib.Path('/workspace/T3081-own-lap-c9-expiry-guard');APP=pathlib.Path('/tmp/chicago-log-integration/chicago/4d')
EXPECTED='c9ad654ec0375de3ff48928bf99f266739916917';OWNER_PREFIX='lap PR #1260 — continuing root owner ';EMPTY='4b825dc642cb6eb9a060e54bf8d69288fbee4904'
EARLIEST=datetime.datetime(2026,10,24,7,48,32,tzinfo=datetime.timezone.utc)
R={'purpose':'same authorized active root consolidation; one normal own-lap expiry CAS only','expected_marker':EXPECTED,'earliest_permitted_CAS':EARLIEST.isoformat(),'normal_CAS_attempts':0,'no_force_release_or_manual_timestamp':True,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def now():return datetime.datetime.now(datetime.timezone.utc)
def state(phase,**extra):
 value={'pid':os.getpid(),'phase':phase,'heartbeat_at':now().isoformat(),'expected_marker':EXPECTED,'earliest_permitted_CAS':EARLIEST.isoformat(),**extra};tmp=P/'GUARD_STATE.tmp';tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(P/'GUARD_STATE.json')
def save(): (P/'OPERATION_RECEIPT.json').write_text(json.dumps(R,indent=2)+'\n')
def api(path):
 q=subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/'+path],capture_output=True,text=True)
 if q.returncode:raise RuntimeError('GET unreadable: '+path+' '+q.stderr[-500:])
 return json.loads(q.stdout)
def native_status():
 q=subprocess.run(['node','tools/ticket.mjs','lap','1260','--status'],cwd=APP,capture_output=True,text=True)
 return {'at':now().isoformat(),'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
def context():
 h=subprocess.run(['git','rev-parse','HEAD'],cwd=APP,capture_output=True,text=True,check=True).stdout.strip();i=subprocess.run(['git','rev-parse','--git-path','index'],cwd=APP,capture_output=True,text=True,check=True).stdout.strip();i=pathlib.Path(i)
 if not i.is_absolute():i=APP/i
 return {'HEAD':h,'index_sha256':hashlib.sha256(i.read_bytes()).hexdigest(),'ticket_mjs_sha256':hashlib.sha256((APP/'tools/ticket.mjs').read_bytes()).hexdigest()}
def current():
 with concurrent.futures.ThreadPoolExecutor(2) as pool:
  ref,pr=list(pool.map(api,['git/ref/heads/lap/pr-1260','pulls/1260']))
 return {'at':now().isoformat(),'marker_sha':ref['object']['sha'],'PR_state':pr['state'],'PR_merged':pr['merged'],'PR_head_for_context_only':pr['head']['sha']}
def finish(status,reason):
 R.update({'status':status,'reason':reason,'ended_at':now().isoformat()});save();out=P/'closed-final-receipt';out.mkdir(exist_ok=False)
 for name in ['INITIAL.json','MARKER_WATCH.jsonl','OPERATION_RECEIPT.json','NATIVE_INVOCATION_STARTED.json','guard.py']:
  src=P/name
  if src.exists():shutil.copyfile(src,out/name)
 (out/'README.md').write_text('One exact-own-marker expiry guard for root PR1260.\n\n'+reason+'\n\nStatus: '+status+'. All exact native argv/outputs/exits and independent old/new observations are in OPERATION_RECEIPT.json. The guard never runs before07:48:32UTC, never takes a changed marker, and stops on a closed PR or unreadable/error state. No force/release/manual timestamp, CI dispatch/rerun/cancel, label, merge or checked-source edit is performed. A normal native invocation, if any, uses its existing server-side compare-and-swap. No public PR head is assumed for lease eligibility. This receipt is operational evidence, not a test PASS or merge approval.\n')
 files=[]
 for f in sorted(out.iterdir()):
  b=f.read_bytes();files.append({'path':f.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 manifest={'closed_at':now().isoformat(),'files':files,'total_bytes':sum(x['bytes'] for x in files),'scope':'one normal exact-own-c9 expiry guard; no early/force/release/manual timestamp or CI/source mutation'};m=out/'MANIFEST.json';m.write_text(json.dumps(manifest,indent=2)+'\n');digest=hashlib.sha256(m.read_bytes()).hexdigest();state('FINISHED',status=status,reason=reason,new_marker=R.get('new_marker'),new_expiry=R.get('new_expiry'),manifest=str(m),manifest_sha256=digest);print(json.dumps({'status':status,'reason':reason,'new_marker':R.get('new_marker'),'new_expiry':R.get('new_expiry'),'manifest':str(m),'manifest_sha256':digest}),flush=True);raise SystemExit(0 if status.startswith(('VERIFIED','SKIPPED')) else 4)
def require_live_own(observation):
 if observation['PR_state']!='open' or observation['PR_merged']:finish('SKIPPED_PR_CLOSED_NO_CAS','PR1260 is no longer open; no lease takeover or release performed.')
 if observation['marker_sha']!=EXPECTED:finish('STOP_CHANGED_MARKER_NO_OVERRIDE','Marker changed from exact authorized own c9; no takeover or override performed.')

try:
 with (P/'ACTIVE_GUARD_LOCK.json').open('x') as f:json.dump({'pid':os.getpid(),'started_at':now().isoformat()},f)
 code=(APP/'tools/ticket.mjs').read_bytes();text=code.decode();assert 'const RUN_HOURS = 3;' in text and 'ageHours !== null && ageHours > RUN_HOURS' in text
 initial=current();R['initial_remote']=initial;require_live_own(initial);commit=api('git/commits/'+EXPECTED)
 if not commit['message'].startswith(OWNER_PREFIX) or commit.get('parents') or commit['tree']['sha']!=EMPTY:finish('STOP_OWNER_OR_MARKER_SHAPE_MISMATCH','Original marker does not match the authorized root-owner empty-tree lease.')
 claimed=datetime.datetime.fromisoformat(commit['committer']['date'].replace('Z','+00:00'))
 if claimed!=datetime.datetime(2026,10,24,4,48,31,tzinfo=datetime.timezone.utc):finish('STOP_MARKER_TIMESTAMP_MISMATCH','Original marker timestamp differs from the authorized04:48:31UTC lease.')
 R['initial_commit']=commit;R['initial_native_status']=native_status();R['initial_tool_sha256']=hashlib.sha256(code).hexdigest();R['expiry_boundary']=(claimed+datetime.timedelta(hours=3)).isoformat()
 if R['initial_native_status']['exit'] not in [0,3]:finish('STOP_NATIVE_STATUS_ERROR','Initial native status was unreadable or errored; no CAS attempted.')
 (P/'INITIAL.json').write_text(json.dumps({k:R[k] for k in ['initial_remote','initial_commit','initial_native_status','initial_tool_sha256','expiry_boundary','earliest_permitted_CAS']},indent=2)+'\n');save()
 print(json.dumps({'guard_started':now().isoformat(),'pid':os.getpid(),'marker':EXPECTED,'earliest_CAS':EARLIEST.isoformat()}),flush=True)
 while True:
  observation=current();R['last_preexpiry_observation']=observation;require_live_own(observation)
  with (P/'MARKER_WATCH.jsonl').open('a') as f:f.write(json.dumps(observation)+'\n')
  if now()>=EARLIEST:break
  state('WAITING_OWN_FRESH',last_observation=observation,seconds_until_earliest=max(0,(EARLIEST-now()).total_seconds()));time.sleep(min(45,max(0,(EARLIEST-now()).total_seconds())))
 R['source_before']=context()
 if R['source_before']['ticket_mjs_sha256']!=R['initial_tool_sha256']:finish('STOP_NATIVE_TOOL_CHANGED','Native tool bytes changed since TTL review; no CAS attempted.')
 R['native_pre_status']=native_status()
 if R['native_pre_status']['exit']!=0 or not R['native_pre_status']['stdout'].startswith('stale lap/pr-1260 '):finish('STOP_NOT_POSITIVELY_STALE','Native pre-status did not positively report the exact own lease stale; no CAS attempted.')
 R['immediate_pre_CAS_remote']=current();require_live_own(R['immediate_pre_CAS_remote'])
 if now()<EARLIEST:finish('STOP_BEFORE_EXPIRY','Clock is before the permitted expiry boundary; no CAS attempted.')
 with (P/'NATIVE_INVOCATION_STARTED.json').open('x') as f:json.dump({'at':now().isoformat(),'expected_old_marker':EXPECTED,'normal_command':['node','tools/ticket.mjs','lap','1260','--by','continuing root owner']},f)
 R['normal_CAS_attempts']=1;R['native_argv']=['node','tools/ticket.mjs','lap','1260','--by','continuing root owner'];save();state('NORMAL_NATIVE_CAS_RUNNING')
 q=subprocess.run(R['native_argv'],cwd=APP,capture_output=True,text=True);R['native_result']={'at':now().isoformat(),'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};save()
 if q.returncode or 'taken — this run laps it' not in q.stdout or 'lock not taken' in q.stderr:finish('STOP_NATIVE_REJECTION_OR_UNKNOWN','The single normal native attempt was rejected or unverified; no retry or override performed.')
 ref=api('git/ref/heads/lap/pr-1260');R['independent_ref_after']=ref;new=ref['object']['sha'];R['new_marker']=new
 if new==EXPECTED:finish('STOP_NO_MARKER_CHANGE','Native output did not produce a new independently observed marker; no retry.')
 c=api('git/commits/'+new);R['independent_commit_after']=c
 if not c['message'].startswith(OWNER_PREFIX) or c.get('parents') or c['tree']['sha']!=EMPTY:finish('STOP_NEW_OWNER_OR_SHAPE_MISMATCH','Independent new marker is not the continuing root owner; no override.')
 created=datetime.datetime.fromisoformat(c['committer']['date'].replace('Z','+00:00'))
 if created<EARLIEST:finish('STOP_NEW_TIMESTAMP_INVALID','New native marker predates the permitted reclaim boundary; no manual timestamp or retry.')
 R['new_created_at']=created.isoformat();R['new_expiry']=(created+datetime.timedelta(hours=3)).isoformat();R['native_post_status']=native_status()
 if R['native_post_status']['exit']!=3 or not R['native_post_status']['stdout'].startswith('held lap/pr-1260 '):finish('STOP_POST_STATUS_UNVERIFIED','New marker did not independently report HELD; no retry or override.')
 R['source_after']=context();R['source_HEAD_index_tool_equal_during_CAS']=R['source_before']==R['source_after'];R['PR_post_context']=api('pulls/1260');R['PR_post_context']={k:R['PR_post_context'][k] for k in ['state','merged','merged_at']}
 finish('VERIFIED_NORMAL_NATIVE_OWN_EXPIRY_RECLAIM','One normal native reclaim occurred only after exact own c9 was stale and PR1260 was open; new owner, marker, timestamp and HELD status were independently verified.')
except SystemExit:raise
except Exception as e:
 try:finish('STOP_TOOL_OR_READ_ERROR_NO_OVERRIDE','Tool/read error: '+str(e))
 except SystemExit:raise
