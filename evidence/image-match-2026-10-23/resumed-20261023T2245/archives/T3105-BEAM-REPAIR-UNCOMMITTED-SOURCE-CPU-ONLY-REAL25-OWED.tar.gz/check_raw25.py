from pathlib import Path
from collections import Counter
from types import ModuleType
import subprocess,sys,json,hashlib,os,datetime
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
A=Path('/tmp/chicago-log-integration/chicago/4d');O=Path(__file__).resolve().parent
sys.path.insert(0,str(A/'generators'))
class NoBlender(ModuleType):
    def __getattr__(self,name):raise AssertionError('CPU proof reached Blender: '+name)
sys.modules['bpy']=NoBlender('bpy')
from archetypes import fort_structure as new
from archetypes.fort_structure_params import from_phase,FortStructureParams
old=ModuleType('baseline_fort_structure');old.__file__=str(A/'generators/archetypes/fort_structure.py')
raw=subprocess.check_output(['git','show','9e757f0bd90c4a2a2ea1ffc17525292211b6c419:chicago/4d/generators/archetypes/fort_structure.py'],cwd=A)
exec(compile(raw,old.__file__,'exec'),old.__dict__)
def geometry(module,p,name):
    b=module.TonedBuilder(name)
    fn={'parade':module._parade,'root_house':module._root_house,'tower':module._tower,'flagstaff':module._flagstaff}.get(p.kind,module._building)
    fn(b,p)
    return b
def snapshot(b):
    return (b.verts,b.faces,b.conf,b.mat_index,b.tone,b.named)
def faces(b):
    return Counter((mat,tuple(b.verts[i]for i in face),tuple(b.conf[i]for i in face),tuple(b.tone[i]for i in face))for face,mat in zip(b.faces,b.mat_index))
def bounds(b):return tuple((min(v[i]for v in b.verts),max(v[i]for v in b.verts))for i in range(3))
manifest=json.loads((A/'assets/manifest.json').read_text())['assets'];family={k:v for k,v in manifest.items()if v.get('archetype')=='fort_structure'};assert len(family)==25
rows=[]
for asset,row in sorted(family.items()):
    record=json.loads((A/'data/structures'/(row['structure_id']+'.json')).read_text());phase=next(p for p in record['phases']if p['id']==row['phase_id']);p=from_phase(phase,record)
    before,after=geometry(old,p,asset),geometry(new,p,asset);target=p.gallery and p.gallery_storeys==2
    result={'asset':asset,'target':target,'bounds_equal':bounds(before)==bounds(after),'before_faces':len(before.faces),'after_faces':len(after.faces),'named_materials_equal':before.named==after.named}
    assert result['bounds_equal']and result['named_materials_equal']
    if not target:
        assert snapshot(before)==snapshot(after),asset
        result['raw_geometry_material_confidence_tone_exact']=True
    else:
        removed=faces(before)-faces(after);added=faces(after)-faces(before)
        assert sum(removed.values())==5 and sum(added.values())==4,(asset,len(removed),len(added))
        for face in list(removed)+list(added):
            mat,verts,confidence,tone=face;assert mat==new.M_TRIM and all(x==1 for x in confidence+tone)
            assert all(p.depth_m+2.1-.14-1e-12<=y<=p.depth_m+2.1+1e-12 and p.wall_height_m-.59-1e-12<=z<=p.wall_height_m-.392+1e-12 for x,y,z in verts)
        result.update(removed_old_beam_faces=5,added_new_beam_sides=4,all_other_faces_exact=True)
    rows.append(result)
assert sum(r['target']for r in rows)==5 and sum(not r['target']for r in rows)==20
d={'status':'PASS_CPU_RAW25_FIVE_ONLY_JOINT_CHANGES_TWENTY_EXACT_NOT_AN_EXPORT','baseline':'9e757f0bd90c4a2a2ea1ffc17525292211b6c419','source_sha256':hashlib.sha256((A/'generators/archetypes/fort_structure.py').read_bytes()).hexdigest(),'rows':rows,'notes':'Actual official25 pinned Blender exports/web readback still UNRUN and owed; no API/params fields changed. Each target removes only oldbeamtop+fourwalls and adds four extendedwalls; canopy/posts/decks/allother geometry/material/confidence/tone exact.','time':datetime.datetime.now(datetime.timezone.utc).isoformat()};(O/'RAW25-PROOF.json').write_text(json.dumps(d,indent=2)+'\n');print(d['status'])
