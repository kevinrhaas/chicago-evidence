#!/usr/bin/env bash
# Source this file in the command that uses the restored Chicago tools.
export PYTHONPATH="/workspace/shared/python${PYTHONPATH:+:$PYTHONPATH}"
export PATH="/workspace/shared/tools/usr/bin:/workspace/shared/gltf-transform/node_modules/.bin:$PATH"
export NODE_PATH="/workspace/shared/node/node_modules${NODE_PATH:+:$NODE_PATH}"
export npm_config_cache=/workspace/shared/npm-cache
export PW_EXECUTABLE=/usr/bin/chromium
export PYTHONDONTWRITEBYTECODE=1

# Keep Git from launching automatic maintenance in the large shared object store.
# Preserve inherited per-command settings and make repeated sourcing idempotent.
_chicago_add_git_config() {
  local chicago_git_key="$1" chicago_git_value="$2"
  local chicago_git_config_count="${GIT_CONFIG_COUNT:-0}" chicago_git_index
  local chicago_git_key_name chicago_git_value_name chicago_git_last_value=""
  for ((chicago_git_index=0; chicago_git_index<chicago_git_config_count; chicago_git_index++)); do
    chicago_git_key_name="GIT_CONFIG_KEY_${chicago_git_index}"
    chicago_git_value_name="GIT_CONFIG_VALUE_${chicago_git_index}"
    if [[ "${!chicago_git_key_name}" == "$chicago_git_key" ]]; then
      chicago_git_last_value="${!chicago_git_value_name}"
    fi
  done
  if [[ "$chicago_git_last_value" == "$chicago_git_value" ]]; then
    return
  fi
  export "GIT_CONFIG_KEY_${chicago_git_config_count}=$chicago_git_key"
  export "GIT_CONFIG_VALUE_${chicago_git_config_count}=$chicago_git_value"
  export GIT_CONFIG_COUNT="$((chicago_git_config_count+1))"
}
_chicago_add_git_config gc.auto 0
_chicago_add_git_config maintenance.auto false
unset -f _chicago_add_git_config
