from pathlib import Path
import os,json,subprocess,hashlib,gzip,zipfile,io,xml.etree.ElementTree as ET,datetime,shutil
os.sched_setaffinity(0,{4});os.environ.update(GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1')
repo=Path('/workspace/chicago');app=repo/'chicago/4d';out=Path('/tmp/WolfPoint-T2386-deep-brown82-native-closure-20261026');prep=json.loads((out/'PREPARED.json').read_bytes());audit=out/'ONE-ALL44-AUDIT';assert not audit.exists();audit.mkdir();base=prep['base'];sha=lambda b:hashlib.sha256(b).hexdigest()
assert min(shutil.disk_usage(repo).free,shutil.disk_usage('/tmp').free)>=prep['floor_bytes']
assert json.loads((out/'TAIL-RESULT.json').read_bytes())['status'].startswith('NATIVE_OFFICIAL_PACKAGE_PUBLISH_OWNING61_FIXEDPOINT_PASS')
reap=json.loads(Path('/tmp/wolfpoint-deep82-native61-reaping-status.json').read_bytes());assert reap['command_exit']==0 and reap['all_children_reaped']
def git(*a):return subprocess.check_output(['git','-C',str(repo),*a])
assert git('rev-parse','HEAD').decode().strip()==base and not git('diff','--cached','--name-only')
DCT='{http://purl.org/dc/terms/}'
def canon(raw,name):
 root=ET.fromstring(raw)
 if name=='docProps/core.xml':
  for x in list(root):
   if x.tag in {DCT+'created',DCT+'modified'}:root.remove(x)
 return ET.canonicalize(ET.tostring(root,encoding='unicode'),rewrite_prefixes=True)
def workbook(a,b):
 with zipfile.ZipFile(io.BytesIO(a))as x,zipfile.ZipFile(io.BytesIO(b))as y:
  if len(x.namelist())!=len(set(x.namelist()))or len(y.namelist())!=len(set(y.namelist()))or set(x.namelist())!=set(y.namelist()):return False,[{'difference':'ZIP member set/duplicates'}]
  rows=[]
  for name in sorted(x.namelist()):
   p,q=x.read(name),y.read(name);equal=p==q
   if not equal and name.endswith(('.xml','.rels')):equal=canon(p,name)==canon(q,name)
   rows.append({'member':name,'raw_bytes_exact':p==q,'all_member_semantics_equal':equal,'base_sha256':sha(p),'generated_sha256':sha(q)})
  return all(z['all_member_semantics_equal']for z in rows),rows
rows=[];restore=[]
for info in prep['binary44']:
 p=info['path'];a=Path(info['raw_baseline']).read_bytes();assert sha(a)==info['sha256'];b=(repo/p).read_bytes();row={'path':p,'base_sha256':sha(a),'generated_sha256':sha(b),'bytes_exact':a==b}
 if a==b:row.update(semantics_equal=True,action='EXACT_UNCHANGED_SKIP_PARSE_INCLUDING_LEGACY_INVALID_ZIP')
 else:
  save=audit/'generated-before-restoration'/p;save.parent.mkdir(parents=True,exist_ok=True);save.write_bytes(b)
  if p.lower().endswith('.gz'):equal=gzip.decompress(a)==gzip.decompress(b);row.update(semantics_equal=equal,comparison='Exact complete decompressed byte stream')
  else:equal,detail=workbook(a,b);row.update(semantics_equal=equal,members=detail,comparison='Every ZIP member exact or canonical XML equal; only docProps created/modified timestamps ignored. All leaf/cell/formula/style/relationship text retained.')
  row['action']='RESTORE_EXACT_CB93_AFTER_WHOLE_AUDIT_PASS'if equal else'KEEP_REAL_SEMANTIC_CHANGE_FOR_REVIEW';restore.extend([p]if equal else[])
 rows.append(row)
binaryset={r['path'] for r in rows};dirty=[p.decode()for p in git('diff','HEAD','--name-only','-z').split(b'\0')if p];outside=[p for p in dirty if not p.startswith('chicago/4d/')];outside_rows=[]
for p in outside:
 b=(repo/p).read_bytes();a=git('show',base+':'+p);save=audit/'outside-before'/p;save.parent.mkdir(parents=True,exist_ok=True);save.write_bytes(b)
 outside_rows.append({'path':p,'base_sha256':sha(a),'generated_sha256':sha(b),'binary_scope_member':p in binaryset,'action':'COMPLETE_BINARY_PROOF_ABOVE'if p in binaryset else'PRESERVED_NATIVE_GENERATED_TEXT_PENDING_PACKAGE5_AND_ROOT_REVIEW','base_bytes':len(a),'generated_bytes':len(b)})
protected=[p for p in dirty if p.startswith(('chicago/4d/data/residents/','chicago/4d/data/people/','chicago/4d/data/population/'))]
whole_equal=all(r['semantics_equal']for r in rows)
result={'status':'ONE_COMPREHENSIVE_ALL44_XLSX_GZIP_OUTSIDE4D_AUDIT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'count44':len(rows),'xlsx23':sum(r['path'].endswith('.xlsx')for r in rows),'gzip21':sum(r['path'].endswith('.gz')for r in rows),'rows':rows,'all44_semantics_equal':whole_equal,'restored_semantic_equal_only':[],'retained_real_semantic_changes':[r['path']for r in rows if not r['semantics_equal']],'all_changed_outside4d_preserved_and_audited':outside_rows,'protected_population_dirty':protected,'notes':'No restoration until this entire44-file proof passes. All changed generated rawbytes preserved. Exact old invalidZIP bypassed parsing. No native gate assertion/producer/sourcealgorithm changed. Staged index required empty and left untouched.'}
(audit/'RESULT-before-restoration.json').write_text(json.dumps(result,indent=2)+'\n')
assert whole_equal and not protected,('WHOLE_PROOF_NOT_EQUAL_KEEP_ALL_GENERATED_BYTES',result['retained_real_semantic_changes'],protected)
for p in restore:
 info=next(x for x in prep['binary44']if x['path']==p);(repo/p).write_bytes(Path(info['raw_baseline']).read_bytes())
 assert git('show',':'+p)==(repo/p).read_bytes(),p
assert not git('diff','--cached','--name-only')
result['restored_semantic_equal_only']=restore;result['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(audit/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2))
