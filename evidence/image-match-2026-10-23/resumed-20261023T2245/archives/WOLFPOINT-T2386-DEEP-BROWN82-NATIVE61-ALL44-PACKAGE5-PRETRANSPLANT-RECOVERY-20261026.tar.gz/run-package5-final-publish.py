from pathlib import Path
import os,json,subprocess,hashlib,datetime,time,shutil,re,signal,sys
os.sched_setaffinity(0,{4});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1',TMPDIR='/tmp/wolfpoint-native-tmp',PYTHONDONTWRITEBYTECODE='1')
repo=Path('/workspace/chicago');app=repo/'chicago/4d';out=Path('/tmp/WolfPoint-T2386-deep-brown82-native-closure-20261026');prep=json.loads((out/'PREPARED.json').read_bytes());floor=prep['floor_bytes'];resources=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def space(label):
 row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':label,'workspace_free':shutil.disk_usage(repo).free,'tmp_free':shutil.disk_usage('/tmp').free};resources.append(row);(out/'RESOURCE-OBSERVATIONS-final-package-publish.json').write_text(json.dumps(resources,indent=2)+'\n');assert min(row['workspace_free'],row['tmp_free'])>=floor,('ROOT_EXTERNAL_RESERVE_512MIB_NO_NATIVE_ASSERT_CHANGE',row);return row
assert all(sha(app/r['path'])==r['sha256'] for r in prep['frozen_physical_assets_and_registry'])
def run(name,cmd):
 print(name,'START',space(name+' BEFORE'),flush=True);start=time.monotonic();p=subprocess.Popen(cmd,cwd=app,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
 try:
  with(out/(name+'.log')).open('x') as log:
   for line in p.stdout:
    log.write(line);log.flush()
    if re.match(r'^\s*\[\d+/\d+\]',line):
     try:space(name+' '+line.strip())
     except AssertionError:os.killpg(p.pid,signal.SIGTERM);p.wait();raise
  code=p.wait()
 finally:
  if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait()
 result={'command':cmd,'exit':code,'seconds':round(time.monotonic()-start,3),'space_after':space(name+' AFTER')};(out/(name+'-RESULT.json')).write_text(json.dumps(result,indent=2)+'\n');assert code==0,(name,code);print(name,'PASS',flush=True)
start=time.monotonic()
assert json.loads((out/'ONE-ALL44-AUDIT/RESULT.json').read_bytes())['all44_semantics_equal']
run('native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'])
text=(out/'native-package5.log').read_text();assert 'derived layer rebuilt from step 198' in text and 'the last one moved nothing' in text
run('native-final-publish',['bash','tools/publish.sh'])
assert all(sha(app/r['path'])==r['sha256'] for r in prep['frozen_physical_assets_and_registry'])
assert all(sha(app/r['path'])==r['sha256'] for r in prep['frozen_authored_people_population_source_generator_inputs'])
assert all(sha(repo/r['path'])==r['sha256'] for r in prep['binary44'])
assert sha(app/'assets/gltf/wolf_point_tavern__log_frame_1828.glb')=='225f3e1041d02cdaa627d3d73c5f6448aff9b12c66f4a545462db45bbf8e0d59'
assert sha(app/'assets/web/wolf_point_tavern__log_frame_1828.glb')=='fdc5ef22a440636e35e4cec15818661f4351f0f4d0c9e506ef36b00422a45210'
assert sha(repo/'site/4d/data/gltf/wolf_point_tavern__log_frame_1828.glb')=='fdc5ef22a440636e35e4cec15818661f4351f0f4d0c9e506ef36b00422a45210'
result={'status':'NATIVE_OWNING61_FIXEDPOINT_ALL44_PROOF_RESTORE_PACKAGE5_FIXEDPOINT_FINAL_PUBLISH_PASS','base':prep['base'],'cpu':[4],'seconds_package_publish':round(time.monotonic()-start,3),'frozen2920_physical_asset_registry_files_exact':True,'frozen3870_authored_source_people_population_generator_inputs_exact':True,'all44_actual_cb93_binary_files_exact_after_whole_semantic_proof_and_native_package_refresh':True,'master':'225f3e1041d02cdaa627d3d73c5f6448aff9b12c66f4a545462db45bbf8e0d59','real_web_and_published_WEB':'fdc5ef22a440636e35e4cec15818661f4351f0f4d0c9e506ef36b00422a45210','native_assertions_unchanged':True,'candidate_native_app_and_fullgates_still_owed':True,'no_geometry_exports':True}
(out/'FINAL-NATIVE-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
