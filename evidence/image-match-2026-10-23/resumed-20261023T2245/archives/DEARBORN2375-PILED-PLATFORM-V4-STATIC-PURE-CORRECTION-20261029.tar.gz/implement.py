from pathlib import Path
import json, hashlib, difflib, datetime

O = Path(__file__).resolve().parent
P = Path('/tmp/dearborn-high-rakers-platform-v3-20261029/candidate/chicago/4d')
rels = ['generators/archetypes/bridge_timber_params.py',
        'generators/archetypes/bridge_timber.py',
        'data/structures/dearborn_street_drawbridge.json',
        'data/reconstruction/name_pool_keys.json']
old = {r: (P/r).read_bytes() for r in rels}
new = {r: b.decode() for r, b in old.items()}
def replace(r, a, b):
    assert new[r].count(a) == 1, (r, a[:100], new[r].count(a))
    new[r] = new[r].replace(a, b)

r = rels[0]
replace(r, '    "gallows_shore_attach_m", "draw_bearing_platform_m",',
        '    "gallows_shore_attach_m", "draw_bearing_platform_m",\n    "draw_bearing_platform_offset_m",')
replace(r, '    draw_bearing_platform_m: tuple[float, float] | None = field(default=None, kw_only=True)\n',
        '    draw_bearing_platform_m: tuple[float, float] | None = field(default=None, kw_only=True)\n    draw_bearing_platform_offset_m: float = field(default=0.0, kw_only=True)\n')
replace(r, '        if self.draw_bearing_platform_m is not None:\n', '''        offset = self.draw_bearing_platform_offset_m
        if (isinstance(offset, bool) or not isinstance(offset, (int, float))
                or not math.isfinite(offset) or abs(offset) > 1.5):
            raise ParamError("bearing platform transverse offset must be finite within 1.5 m")
        if offset != 0 and self.draw_bearing_platform_m is None:
            raise ParamError("bearing platform offset requires bearing platforms")
        if self.draw_bearing_platform_m is not None:
''')
replace(r, '            if lo - along < 0 or hi + along > self.span_m:\n',
        '            if lo - along / 2 < 0 or hi + along / 2 > self.span_m:\n')
replace(r, '            if any(lo - along - 0.58 <= x <= lo or hi <= x <= hi + along + 0.58 for x in others):\n',
        '            if any(abs(x - g) <= along / 2 + 0.58 for x in others for g in (lo, hi)):\n')
replace(r, '                raise ParamError("bearing platform overlaps another approach support")\n', '''                raise ParamError("bearing platform overlaps another approach support")
            y0 = (self.width_m - across) / 2 + offset
            # Both existing gallows post footprints must stand on the selected cap.
            if y0 > -0.43 or y0 + across < self.width_m + 0.43:
                raise ParamError("bearing platform leaves a gallows post footprint unsupported")
''')
replace(r, '        draw_bearing_platform_m=val("draw_bearing_platform_m"),',
        '        draw_bearing_platform_m=val("draw_bearing_platform_m"),\n        draw_bearing_platform_offset_m=val("draw_bearing_platform_offset_m", 0.0),')

r = rels[1]
replace(r, '''        # Only these two bearings become broad cribs; general pier_kind still
        # controls the approach bents. The nominal box grows away from the draw.
        along, across = p.draw_bearing_platform_m
        x0, x1 = ((xp - along, xp) if xp < p.span_m / 2.0 else (xp, xp + along))
        y0 = (p.width_m - across) / 2.0
        c = max(conf, p.conf("draw_bearing_platform_m"))
        _crib(b, x0, y0, x1, y0 + across, bearing_z, c)
        _cap(b, p, xp, bearing_z, c)
''', '''        # The Andreas platform is an open vertical-pile foundation with a
        # boarded cap. Its plan is centered on the bearing, with an explicit
        # transverse offset; the general pier_kind still controls approaches.
        along, across = p.draw_bearing_platform_m
        x0, x1 = xp - along / 2.0, xp + along / 2.0
        y0 = (p.width_m - across) / 2.0 + p.draw_bearing_platform_offset_m
        c = max(conf, p.worst_conf("draw_bearing_platform_m", "draw_bearing_platform_offset_m"))
        _piled_platform(b, x0, y0, x1, y0 + across, bearing_z, c)
''')
anchor = '\ndef _crib(b: MeshBuilder, x0: float, y0: float, x1: float, y1: float,\n'
helper = '''
def _piled_platform(b: MeshBuilder, x0: float, y0: float, x1: float, y1: float,
                    top_z: float, conf: float) -> None:
    """Retrospective plate's piled foundation, with reconstructed scantlings.

    A close perimeter of vertical piles holds two longitudinal sleepers and a
    thin boarded cap. No filled box or horizontal crib walls are inserted.
    Pile count follows the bounded 0.48 m maximum pitch, not a historical count.
    The mesh stops below the waterline; it asserts no riverbed or driven depth.
    """
    radius, cap_t, sleeper_t = 0.15, 0.14, 0.20
    inset = radius + 0.06
    xa, xb, ya, yb = x0 + inset, x1 - inset, y0 + inset, y1 - inset
    nx = max(2, math.ceil((xb - xa) / 0.48) + 1)
    ny = max(2, math.ceil((yb - ya) / 0.48) + 1)
    points = [(xa + (xb - xa) * i / (nx - 1), y) for i in range(nx) for y in (ya, yb)]
    points += [(x, ya + (yb - ya) * i / (ny - 1)) for i in range(1, ny - 1) for x in (xa, xb)]
    for x, y in points:
        log_prism(b, (x, y, -SUBMERGED_M),
                  (x, y, top_z - cap_t - sleeper_t), radius, conf, M_LOG)
    for y in (ya, yb):
        b.add_box(x0, y - radius, top_z - cap_t - sleeper_t,
                  x1, y + radius, top_z - cap_t, conf, M_LOG)
    boards = max(1, math.ceil((x1 - x0) / SAWN_PITCH_M))
    pitch = (x1 - x0) / boards
    for i in range(boards):
        a, z = x0 + i * pitch, top_z - cap_t
        b.add_box(a + 0.005, y0, z, a + pitch - 0.005, y1,
                  top_z, conf, M_DECK)

'''
replace(r, anchor, '\n'+helper+anchor)

r = rels[2]
record = json.loads(new[r]); form = record['phases'][0]['form']
prior = form['draw_bearing_platform_m']['note']
form['draw_bearing_platform_m']['value'] = [3.6, 6.0]
form['draw_bearing_platform_m']['note'] = ('V3 SOLID-CRIB TRIAL, retained as history: '+prior+
    ' CURRENT PILED-CAP CORRECTION: direct inspection of the complete 1920 px plate shows a boarded cap over closely spaced vertical piles, not a solid horizontal-log crib. The selected 3.6 m along by 6.0 m across platform is centered on each existing frame bearing. Its 0.30 m diameter perimeter piles at at most 0.48 m spacing, two 0.20 m sleepers, 0.14 m boarded cap and below-water stopping depth are reconstructed visual choices, not dimensions or a foundation count attested by the retrospective drawing. No solid fill is built. Source-camera fitting remains provisional and whole-picture comparison stays differs until reviewed.')
form['draw_bearing_platform_offset_m'] = {'value': -1.0, 'confidence': 'reconstructed',
    'note': 'TRANSVERSE PLATFORM PROJECTION, RECONSTRUCTED. The full Andreas plate shows the broad cap projecting toward the foreground of the view, rather than growing only along the bridge toward a bank. Shift the selected platform 1.0 m toward local negative-v, the provisional source-camera side, while keeping both unchanged gallows post footprints supported. This signed offset and the platform plan dimensions are a finite visual trial; no geographic coordinate, shoreline, deck width or surveyed footprint is moved or inferred from a drawing. No claim that the bounded camera is a historic metric solve follows.'}
form['pier_kind']['note'] += ' CURRENT PLATFORM CORRECTION: the two selected bearings now use boarded pile-supported caps rather than the rejected V3 solid-crib trial; all numerical sections and counts remain reconstructed.'
form['draw_bearing_supports']['note'] += ' CURRENT PLATFORM CORRECTION: the two selected bearing foundations are open vertical-pile/boarded-cap reconstructions, replacing the rejected solid-crib visual trial.'
# Preserve every old field's source formatting except the specifically edited field values/notes.
original = json.loads(new[r]); changes = ['draw_bearing_platform_m','pier_kind','draw_bearing_supports']
for key in changes:
    for field in set(form[key]) | set(original['phases'][0]['form'][key]):
        a = original['phases'][0]['form'][key].get(field); b = form[key].get(field)
        if a != b:
            # Notes are unique. Dimension list appears exactly once in this record.
            if isinstance(a, list):
                aa = '\n'.join(('          '+line if i else line) for i,line in enumerate(json.dumps(a,indent=2).splitlines()))
                bb = '\n'.join(('          '+line if i else line) for i,line in enumerate(json.dumps(b,indent=2).splitlines()))
                replace(r, aa, bb)
            else:
                replace(r, json.dumps(a, ensure_ascii=False), json.dumps(b, ensure_ascii=False))
anchor = '\n      },\n      "change_note"'
encoded = '\n'.join('      '+line for line in json.dumps({'draw_bearing_platform_offset_m': form['draw_bearing_platform_offset_m']}, indent=2).splitlines()[1:-1])
replace(r, anchor, ',\n'+encoded+anchor)
assert json.loads(new[r]) == record

r=rels[3]
anchor='\n    ],\n    "households"'
replace(r, anchor, ',\n      "phases[].form.draw_bearing_platform_offset_m.note"'+anchor)
for rel in rels:
    for part, data in [('before',old[rel]),('candidate',new[rel].encode())]:
        dest=O/part/'chicago/4d'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
(O/'SOURCE-4PATH-INCREMENT.patch').write_text(''.join(''.join(difflib.unified_diff(old[r].decode().splitlines(True),new[r].splitlines(True),fromfile='a/chicago/4d/'+r,tofile='b/chicago/4d/'+r)) for r in rels))
(O/'SOURCE-BINDINGS.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'UNADOPTED external v4 four-path increment over closed v3. No canonical write/native/browser/claim.','preimages':{r:hashlib.sha256(b).hexdigest() for r,b in old.items()},'postimages':{r:hashlib.sha256(b.encode()).hexdigest() for r,b in new.items()}},indent=2)+'\n')
print('V4 external four-path source prepared; no native/browser run')
