from pathlib import Path
O=Path(__file__).resolve().parent
s=Path('/tmp/dearborn-high-rakers-platform-v3-20261029/verify_pure.py').read_text()
s=s.replace("assert d.pop('draw_bearing_platform_m') is None;", "assert d.pop('draw_bearing_platform_m') is None;assert d.pop('draw_bearing_platform_offset_m') == 0.0;")
s=s.replace("'gallows_shore_attach_m','draw_bearing_platform_m'", "'gallows_shore_attach_m','draw_bearing_platform_m','draw_bearing_platform_offset_m'")
s=s.replace("plan_bounds[1][0]>=-1 and plan_bounds[1][1]<=p.width_m+1", "plan_bounds[1][0]>=-3 and plan_bounds[1][1]<=p.width_m+1")
s=s.replace("dataclasses.replace(p,draw_bearing_platform_m=None)", "dataclasses.replace(p,draw_bearing_platform_m=None,draw_bearing_platform_offset_m=0.0)")
s=s.replace("if xp<p.span_m/2:assert bounds[0][0]<xp-3.4 and bounds[0][1]<xp+.3\n  else:assert bounds[0][0]>xp-.3 and bounds[0][1]>xp+3.4", "assert abs(bounds[0][0]-(xp-1.8))<1e-10 and abs(bounds[0][1]-(xp+1.8))<1e-10\n  assert abs(bounds[1][0]-(-2.476))<1e-10 and abs(bounds[1][1]-3.524)<1e-10\n  assert max(q[2] for q in body.verts)==p.deck_height_m-p.plank_t_m-p.stringer_d_m\n  assert nf.M_FILL not in body.mat_index and nf.M_DECK in body.mat_index")
s=s.replace("assert bounds[1][0]<-.5 and bounds[1][1]>p.width_m+.5", "assert bounds[1][0]<-2.4 and bounds[1][1]>p.width_m+.43")
s=s.replace("('platform_crosses_other_support',{'draw_bearing_platform_m':[6.,4.4]})", "('platform_crosses_other_support',{'draw_bearing_platform_m':[6.,6.],'pier_count':30})")
s=s.replace("('platform_exceeds_approach',{'span_m':25.})", "('platform_exceeds_approach',{'span_m':21.})")
s=s.replace("('boolean_attach',", "('bad_platform_offset_bool',{'draw_bearing_platform_offset_m':True}),('bad_platform_offset_nan',{'draw_bearing_platform_offset_m':float('nan')}),('bad_platform_offset_far',{'draw_bearing_platform_offset_m':1.51}),('offset_without_platform',{'draw_bearing_platform_m':None}),('platform_post_unsupported',{'draw_bearing_platform_m':[3.6,4.4]}),('boolean_attach',")
s=s.replace("'whole_mesh_plan_bounds_within_prior_actual_yard_clearance_guard':plan_bounds", "'whole_mesh_plan_bounds':plan_bounds")
s=s.replace("# Existing native pier helpers distinguish", "# Existing native pier helpers distinguish")
s=s.replace("pts=[gb['verts'][i] for i in f]\n for j", "pts=[gb['verts'][i] for i in f]\n # Pile-platform cap is M_DECK too, but lies below the bridge floor; it is\n # not a walking-surface face and must not convert the original plank gaps into hits.\n if max(q[2] for q in pts)<p.deck_height_m-p.plank_t_m-1e-9:continue\n for j")
# Additional physical distinction: pile streams contain no crib/fill, vertical
# pile endpoints and cap ownership are isolated from the unchanged floor profile.
needle="assert hashes=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}"
extra='''
# The platform remains open under a boarded cap, with finite distinct perimeter
# pile positions; every post footprint stays inside the top polygon.
captures=[]
saved_log=nf.log_prism
def counted_log(builder,a,b,r,c,m):
 captures.append((a,b,r,c,m));return saved_log(builder,a,b,r,c,m)
nf.log_prism=counted_log
isolated=mesh.MeshBuilder('isolated-platform')
nf._piled_platform(isolated,0,-2.476,3.6,3.524,p.deck_height_m-p.plank_t_m-p.stringer_d_m,1.)
nf.log_prism=saved_log
assert len(captures)==38 and len({(a[0],a[1]) for a,b,r,c,m in captures})==38
assert all(a[:2]==b[:2] and a[2]==-.55 and abs(r-.15)<1e-15 and c==1 and m==nf.M_LOG for a,b,r,c,m in captures)
assert nf.M_FILL not in isolated.mat_index
assert len(isolated.faces)==38*8+2*6+14*6
'''
s=s.replace(needle,extra+'\n'+needle)
(O/'verify_pure.py').write_text(s)
print('prepared pure controls; no execution')
