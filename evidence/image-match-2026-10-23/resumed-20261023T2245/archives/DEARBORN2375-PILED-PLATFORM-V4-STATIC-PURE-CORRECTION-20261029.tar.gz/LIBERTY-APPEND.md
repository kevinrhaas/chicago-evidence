
### L-dearborn-piled-platforms-2375 — Pile-supported boarded caps

**Covers:** `dearborn_street_drawbridge.draw_1834.form.draw_bearing_platform_m`,
`dearborn_street_drawbridge.draw_1834.form.draw_bearing_platform_offset_m`.
**Decision:** The full retrospective Andreas 1884 p.631 plate shows a boarded
foundation cap over vertical piles, projecting toward the foreground. The V3
solid-log crib box is a rejected visual trial whose prior notes are retained.
**What is invented:** Two selected 3.6 m by 6.0 m plans, centered along the
unchanged bearings and offset -1.0 m in local-v; 38 perimeter piles per cap,
0.30 m diameter, maximum 0.48 m pitch, two 0.20 m sleepers, 0.14 m boards and
the below-water stopping depth. These numeric choices are reconstructed visual
dimensions, not a surveyed foundation/coordinate or historical count. No riverbed
or driven depth is asserted; the ordinary approach bents and deck width stay.
**Limits:** The camera remains provisional. Actual new v4 export, WEB, photo,
canonical adoption, app walk and original image acceptance remain owed.
**Ticket:** T-2375. **Recorded:** 2026-10-29.
