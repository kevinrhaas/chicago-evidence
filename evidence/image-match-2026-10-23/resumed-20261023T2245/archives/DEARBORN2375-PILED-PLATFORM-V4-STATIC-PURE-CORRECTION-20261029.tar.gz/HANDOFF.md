# Dearborn piled platform correction — v4

UNADOPTED external four-path increment over the closed v3 proposal. Original
T-2375 remains OPEN/DIFFERS. This packet changes no canonical source, claim,
camera, image match, generated model, runtime module or ticket.

The actual v3 native/WEB/same-camera capture is preserved at
`/workspace/T2375-native-v3-rakers-platforms-20261029/MANIFEST.json`. Direct
inspection of that capture and the full 1920 px Andreas source found the two
solid horizontal-log crib boxes wrong in visible shape. The source foreground
foundation has a thin boarded cap over a close vertical-pile perimeter. The
v4 helper implements that finite correction only for the two already selected
aligned bearings. It replaces no ordinary crib or approach support path.

Selected plan: centered on each existing bearing, 3.6 m along by 6.0 m across,
with an explicit -1.0 m transverse offset toward the provisional source-camera
side. Both existing gallows post footprints remain inside the cap. These
dimensions, 38 perimeter piles per foundation, 0.30 m pile diameter, maximum
0.48 m pitch, two 0.20 m sleepers, 0.14 m boards, scantlings and below-water
stop are reconstructed visual choices. They are not a historical foundation
count, survey, geographic footprint, riverbed or driven depth. Full prior
solid-crib notes are retained as rejected trial history, with current decisions
appended. One default-zero keyword joins existing default-None platform sizes.
Invalid/nonfinite/bool/unsupported context and unsupported post footprints refuse.

Actual pure verification passes all six current legacy complete raw geometry,
materials/confidence/named streams and positional/default interfaces. The ten
ordinary approach bents remain exact; only the selected platform branch changes.
All 116 native main-deck floor hits, four plank gaps, profile and compiler
precision fixtures remain exactly equal to v2. The cap uses deck material but
sits below the bridge floor: the native floor test explicitly excludes those
lower faces so cap faces do not turn existing plank gaps into walk-floor hits.
Thirty-five invalid controls refuse. An isolated actual helper call proves
38 distinct vertical piles, no fill material, sleepers and 14 cap boards.

The whole candidate pure mesh has finite plan bounds listed in PURE-PROOF.
All 17 native yard code/terrain bindings and all eight records remain exact.
SCOPED-REUSE-AND-CLEARANCE applies a new whole-mesh-plus-1m rectangle to every
prior actual whole-float-geometry item bound, in both native atlas RNG states.
This is new arithmetic on actual unchanged output bounds, not a new yard native
run or a claim about app quantization/parked horse geometry.

Next: root grants CPU/GPU; export all six new defaults with the candidate
producer and compare to prior actual native/current bytes, export selected v4,
make its genuine WEB, take one exact inherited-camera photo, and review it.
The inherited principal-point bound is a drawing/camera uncertainty, not a
metric historical fit. No second rendering has yet run for v4 and no whole
image MATCHES claim is made. The original owner stopping rule applies.

Raw authoring/test refusals are preserved: JSON-list whitespace mismatch stopped
before writing postimages; an initial floor extractor counted lower cap faces
at an existing bridge-deck plank gap; a second extra assertion estimated the
pile count as 40 instead of the helper's actual derived 38. Corrections preserve
the meaningful floor gap, exact native geometry and structural assertions.
