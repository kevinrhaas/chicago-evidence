from pathlib import Path
import json, hashlib, math, datetime, ast, stat, difflib
O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((O/'PURE-PROOF.json').read_text())
assert proof['status']=='PASS_PURE_ONLY_UNADOPTED'
for p in (O/'candidate').rglob('*.py'):ast.parse(p.read_text())
yard=Path('/workspace/T2375-native-profile-trial-20261029')
inputs=json.loads((yard/'YARD-INPUTS.json').read_text())
for p,h in inputs['current_bindings'].items():assert sha(Path(p))==h,p
for r in inputs['records']:assert sha(Path(r['canonical']))==r['sha256'],r['canonical']
actual=json.loads((yard/'ACTUAL-WHOLE-YARD-CLEARANCE.json').read_text())
assert actual['status']=='ALL_INDEXED_NATIVE_YARD_FLOAT_GEOMETRY_CLEARS_EXPANDED_FULL_BRIDGE_RECTANGLE'
bounds=proof['candidate']['whole_mesh_plan_bounds'];guard=[[a-1,b+1]for a,b in bounds]
gaps=[]
for row in actual['cases']:
 for state,s in row['states'].items():
  b=s['bridge_local_bounds'];axis=[max(guard[i][0]-b[i][1],b[i][0]-guard[i][1],0) for i in range(2)]
  gap=math.hypot(*axis);assert gap>0
  gaps.append({'record':row['record'],'pointer':row['pointer'],'state':state,'gap_lower_bound_m':gap})
assert len(gaps)==actual['attempted_items']*2
v2=Path('/tmp/dearborn-profile-precision-v2-20261029/NATIVE-PROFILE-FIXTURE.json')
assert json.loads(v2.read_text())==json.loads((O/'NATIVE-PROFILE-FIXTURE.json').read_text())
# The runtime consumer packet and 5-decimal precision fixture are reused only at
# exact equal source/floor bindings; this is a new arithmetic proof, no rerender.
prior=json.loads(Path('/tmp/dearborn-profile-implemented-20261029/NODE-RUNTIME-PROOF.json').read_text()) if Path('/tmp/dearborn-profile-implemented-20261029/NODE-RUNTIME-PROOF.json').exists() else None
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ARITHMETIC_CLEARANCE_FROM_UNCHANGED_ACTUAL_NATIVE_YARD_BOUNDS',
 'actual_native_input_proof':str(yard/'MANIFEST.json'),'actual_native_input_proof_sha256':sha(yard/'MANIFEST.json'),
 'all17_native_yard_code_terrain_bindings_and8_records_exact':True,
 'candidate_actual_pure_mesh_bounds':bounds,'expanded_whole_mesh_guard_1m':guard,
 'actual_native_yard_items':actual['attempted_items'],'native_atlas_presence_states':2,'all_bounds_compared':len(gaps),
 'minimum_whole_emitted_geometry_gap_lower_bound_m':min(x['gap_lower_bound_m']for x in gaps),
 'floor_fixture_all116_samples_4gaps_exact_v2':True,
 'cases':gaps,'limits':'New arithmetic on actual prior native whole-geometry float bounds with exact inputs. No native yard rerun, new export/WEB/photo, app quantization, parked/horse complete-asset certificate or canonical adoption.'}
(O/'SCOPED-REUSE-AND-CLEARANCE.json').write_text(json.dumps(result,indent=2)+'\n')
(O/'HANDOFF.md').write_text('''# Dearborn piled platform correction — v4

UNADOPTED external four-path increment over the closed v3 proposal. Original
T-2375 remains OPEN/DIFFERS. This packet changes no canonical source, claim,
camera, image match, generated model, runtime module or ticket.

The actual v3 native/WEB/same-camera capture is preserved at
`/workspace/T2375-native-v3-rakers-platforms-20261029/MANIFEST.json`. Direct
inspection of that capture and the full 1920 px Andreas source found the two
solid horizontal-log crib boxes wrong in visible shape. The source foreground
foundation has a thin boarded cap over a close vertical-pile perimeter. The
v4 helper implements that finite correction only for the two already selected
aligned bearings. It replaces no ordinary crib or approach support path.

Selected plan: centered on each existing bearing, 3.6 m along by 6.0 m across,
with an explicit -1.0 m transverse offset toward the provisional source-camera
side. Both existing gallows post footprints remain inside the cap. These
dimensions, 38 perimeter piles per foundation, 0.30 m pile diameter, maximum
0.48 m pitch, two 0.20 m sleepers, 0.14 m boards, scantlings and below-water
stop are reconstructed visual choices. They are not a historical foundation
count, survey, geographic footprint, riverbed or driven depth. Full prior
solid-crib notes are retained as rejected trial history, with current decisions
appended. One default-zero keyword joins existing default-None platform sizes.
Invalid/nonfinite/bool/unsupported context and unsupported post footprints refuse.

Actual pure verification passes all six current legacy complete raw geometry,
materials/confidence/named streams and positional/default interfaces. The ten
ordinary approach bents remain exact; only the selected platform branch changes.
All 116 native main-deck floor hits, four plank gaps, profile and compiler
precision fixtures remain exactly equal to v2. The cap uses deck material but
sits below the bridge floor: the native floor test explicitly excludes those
lower faces so cap faces do not turn existing plank gaps into walk-floor hits.
Thirty-five invalid controls refuse. An isolated actual helper call proves
38 distinct vertical piles, no fill material, sleepers and 14 cap boards.

The whole candidate pure mesh has finite plan bounds listed in PURE-PROOF.
All 17 native yard code/terrain bindings and all eight records remain exact.
SCOPED-REUSE-AND-CLEARANCE applies a new whole-mesh-plus-1m rectangle to every
prior actual whole-float-geometry item bound, in both native atlas RNG states.
This is new arithmetic on actual unchanged output bounds, not a new yard native
run or a claim about app quantization/parked horse geometry.

Next: root grants CPU/GPU; export all six new defaults with the candidate
producer and compare to prior actual native/current bytes, export selected v4,
make its genuine WEB, take one exact inherited-camera photo, and review it.
The inherited principal-point bound is a drawing/camera uncertainty, not a
metric historical fit. No second rendering has yet run for v4 and no whole
image MATCHES claim is made. The original owner stopping rule applies.

Raw authoring/test refusals are preserved: JSON-list whitespace mismatch stopped
before writing postimages; an initial floor extractor counted lower cap faces
at an existing bridge-deck plank gap; a second extra assertion estimated the
pile count as 40 instead of the helper's actual derived 38. Corrections preserve
the meaningful floor gap, exact native geometry and structural assertions.
''')
(O/'LIBERTY-APPEND.md').write_text('''
### L-dearborn-piled-platforms-2375 — Pile-supported boarded caps

**Covers:** `dearborn_street_drawbridge.draw_1834.form.draw_bearing_platform_m`,
`dearborn_street_drawbridge.draw_1834.form.draw_bearing_platform_offset_m`.
**Decision:** The full retrospective Andreas 1884 p.631 plate shows a boarded
foundation cap over vertical piles, projecting toward the foreground. The V3
solid-log crib box is a rejected visual trial whose prior notes are retained.
**What is invented:** Two selected 3.6 m by 6.0 m plans, centered along the
unchanged bearings and offset -1.0 m in local-v; 38 perimeter piles per cap,
0.30 m diameter, maximum 0.48 m pitch, two 0.20 m sleepers, 0.14 m boards and
the below-water stopping depth. These numeric choices are reconstructed visual
dimensions, not a surveyed foundation/coordinate or historical count. No riverbed
or driven depth is asserted; the ordinary approach bents and deck width stay.
**Limits:** The camera remains provisional. Actual new v4 export, WEB, photo,
canonical adoption, app walk and original image acceptance remain owed.
**Ticket:** T-2375. **Recorded:** 2026-10-29.
''')
files=[]
for p in sorted(O.rglob('*')):
 if p.is_file() and p.name!='MANIFEST.json':files.append({'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(stat.S_IMODE(p.stat().st_mode))})
(O/'MANIFEST.json').write_text(json.dumps({'closed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Closed UNADOPTED external v4 finite static platform correction; actual pure6/default/mesh/floor and exact-input arithmetic yard-clearance proof only. New native/WEB/photo/app/claim/adoption/gate owed.','files':files},indent=2)+'\n')
print(json.dumps({'manifest':str(O/'MANIFEST.json'),'sha256':sha(O/'MANIFEST.json'),'files':len(files),'min_whole_yard_gap_m':result['minimum_whole_emitted_geometry_gap_lower_bound_m']},indent=2))
