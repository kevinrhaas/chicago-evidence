from pathlib import Path
import subprocess,json,hashlib,sys
A=Path('/tmp/chicago-log-integration/chicago/4d');O=Path(__file__).resolve().parent;PUBLIC='6e66191ebaea1f9d4d15c7a1ac9042a341d3714b';sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda p:subprocess.check_output(['git','show',PUBLIC+':chicago/4d/'+p],cwd=A)
F=O/'PUBLIC6E-BASELINE.json'
if '--init'in sys.argv:
    assert not F.exists()
    lodgers=[p.removeprefix('chicago/4d/')for p in subprocess.check_output(['git','ls-tree','-r','--name-only',PUBLIC,'chicago/4d/data/residents/lodgers'],cwd=A,text=True).splitlines()if p.endswith('.json')];assert len(lodgers)==22
    population=lodgers+['data/reconstruction/1835_lodgers_seated.json','data/reconstruction/1835_reconstruction_order_book.json','data/reconstruction/1835_lodging_model.json','data/reconstruction/1835_placement_policy.json']
    manifest=json.loads(blob('assets/manifest.json'))['assets'];family={k:v for k,v in manifest.items()if v.get('archetype')in ['log_dwelling','frame_tavern']};assert len(family)==105
    paths=sorted(set(population+[f'data/structures/{v["structure_id"]}.json'for v in family.values()]+[f'assets/{kind}/{name}'for name in family for kind in ['gltf','web']]+['data/sources/cameron_c1900_first_post_office.json']));assert len(paths)==342
    current=json.loads((A/'assets/manifest.json').read_text())['assets'];fort={k:v for k,v in current.items()if v.get('archetype')=='fort_structure'};assert len(fort)==25
    protected_fort={f'assets/{kind}/{name}':sha((A/'assets'/kind/name).read_bytes())for name in fort for kind in ['gltf','web']}
    protected_records={f'data/structures/{v["structure_id"]}.json':sha((A/'data/structures'/(v['structure_id']+'.json')).read_bytes())for v in fort.values()}
    d={'public':PUBLIC,'hashes':{p:sha(blob(p))for p in paths},'population26':population,'log_frame_recipe105':family,'fort25_genuine_rows':fort,'fort50_actual_hashes':protected_fort,'fort25_records':protected_records,'policy':json.loads(blob('data/reconstruction/1835_placement_policy.json')),'lodging_figures':json.loads(blob('data/reconstruction/1835_lodging_model.json'))['the_figures_this_model_does_not_move']};F.write_text(json.dumps(d,indent=2)+'\n')
d=json.loads(F.read_text());assert d['public']==PUBLIC
for p,h in (d['hashes']|d['fort50_actual_hashes']|d['fort25_records']).items():assert sha((A/p).read_bytes())==h,p+': protected source/asset drift'
current=json.loads((A/'assets/manifest.json').read_text())['assets']
for k,row in (d['log_frame_recipe105']|d['fort25_genuine_rows']).items():assert current[k]==row,k+': native recipe-row drift'
policy=json.loads((A/'data/reconstruction/1835_placement_policy.json').read_text())
for k in ['constants','clauses','outliers']:assert policy[k]==d['policy'][k]
assert json.loads((A/'data/reconstruction/1835_lodging_model.json').read_text())['the_figures_this_model_does_not_move']==d['lodging_figures']
print('PASS exactpublic6e342protected/26population/105log-frame recipes; own25genuinefortrows/50assets/25records; constants/clauses/outliers/lodging figures unchanged')
