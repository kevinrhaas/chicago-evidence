from pathlib import Path
import subprocess,json,os,datetime,time
O=Path(__file__).resolve().parent;A=Path('/tmp/chicago-log-integration/chicago/4d');assert os.environ.get('CHICAGO_HEAVY_SLOT')=='T3105_BEAM_REPAIR';assert not(O/'NATIVE.json').exists();E={**os.environ,'TMPDIR':'/workspace/T3105-tmp','PATH':'/workspace/shared/tools/usr/bin:'+os.environ['PATH'],'npm_config_cache':'/workspace/shared/npm-cache','PYTHONDONTWRITEBYTECODE':'1'};E.pop('CHICAGO_TICKETS_DIR',None);assert 'CHICAGO_TICKETS_DIR'not in E
steps=[('protected-before',['python',str(O/'guard_combined.py')]),('native-ordered-fixedpoint',['node','tools/rederive.mjs','--resolve']),('protected-after',['python',str(O/'guard_combined.py')]),('flora-reach',['python3','tools/measure_flora_reach.py','--gate']),('planting-reach',['python3','tools/measure_planting_reach.py','--gate']),('liberties',['python3','tools/compile_liberties.py','--check']),('sources',['python3','tools/compile_source_use.py','--check']),('entrances',['python3','tools/generate_entrances.py','--check']),('scenes',['python3','tools/compile_scene.py','--all','--check']),('publish',['bash','tools/publish.sh']),('published',['node','tools/check_published.mjs']),('all-fresh',['python3','tools/validate.py','--all','--stale']),('protected-final',['python',str(O/'guard_combined.py')])]
state={'status':'RUNNING_NATIVE_COMBINED_FROZEN_HOGAN6E_PLUS_FORT_BEAM','incoming':'6e66191ebaea1f9d4d15c7a1ac9042a341d3714b','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[]}
for name,cmd in steps:
    print('START',name,flush=True);t=time.monotonic()
    with(O/(name+'.log')).open('x')as f:r=subprocess.run(cmd,cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
    state['steps'].append({'name':name,'command':cmd,'exit_code':r.returncode,'seconds':round(time.monotonic()-t,3)})
    if r.returncode:state.update(status='FAILED',failed=name)
    (O/'NATIVE.json').write_text(json.dumps(state,indent=2)+'\n');print('END',name,r.returncode,flush=True);assert r.returncode==0,'Stop first realfailure: '+name
state.update(status='PASS_NATIVE_COMBINED_INPUTS_FIXEDPOINT_PROTECTED_PUBLISHED_FRESH_APP_FULLGATE_OWED',finished=datetime.datetime.now(datetime.timezone.utc).isoformat());(O/'NATIVE.json').write_text(json.dumps(state,indent=2)+'\n');print(state['status'])
