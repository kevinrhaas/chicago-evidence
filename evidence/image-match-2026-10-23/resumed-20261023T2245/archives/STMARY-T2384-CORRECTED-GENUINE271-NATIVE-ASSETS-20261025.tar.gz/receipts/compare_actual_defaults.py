from pathlib import Path
import json,struct,subprocess,collections,hashlib,os,time
app=Path('/tmp/st-mary-picture-20261025/chicago/4d');repo=app.parent.parent;out=Path('/tmp/st-mary-runtime-20261025')
base=json.loads((out/'family-before-9f7.json').read_text()); keys=sorted(k for k in base['family_rows'] if not k.startswith('st_marys_church__'))
os.sched_setaffinity(0,{3})
def parse(b):
 assert b[:4]==b'glTF'; n,typ=struct.unpack_from('<II',b,12); assert typ==0x4e4f534a
 d=json.loads(b[20:20+n]); at=20+n; raw=b''
 while at<len(b):
  z,t=struct.unpack_from('<II',b,at);at+=8
  if t==0x004e4942:raw=b[at:at+z]
  at+=z
 return d,raw
fm={5120:'b',5121:'B',5122:'h',5123:'H',5125:'I',5126:'f'};sz={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def attr(d,b,i):
 a=d['accessors'][i]; assert not a.get('sparse');v=d['bufferViews'][a['bufferView']];fmt='<'+fm[a['componentType']]*sz[a['type']]; step=v.get('byteStride',struct.calcsize(fmt));start=v.get('byteOffset',0)+a.get('byteOffset',0)
 return [struct.unpack_from(fmt,b,start+j*step)for j in range(a['count'])]
def sig(d,b):
 meta={k:d.get(k)for k in ['nodes','scenes','scene','materials','textures','images','samplers','skins','animations','extensionsUsed','extensionsRequired','extensions']}
 allmeshes=[];attrs=set()
 for m in d.get('meshes',[]):
  prims=[]
  for p in m['primitives']:
   assert p.get('mode',4)==4
   names=tuple(sorted(k for k in p['attributes']if not k.startswith('TEXCOORD')));attrs.update(p['attributes'])
   a={k:attr(d,b,p['attributes'][k])for k in names};inds=[x[0]for x in attr(d,b,p['indices'])]if 'indices'in p else list(range(len(a['POSITION'])))
   tris=[]
   for j in range(0,len(inds),3):
    corners=tuple(tuple((k,a[k][i])for k in names)for i in inds[j:j+3]);tris.append(min(corners,corners[1:]+corners[:1],corners[2:]+corners[:2]))
   prims.append((p.get('material'),names,collections.Counter(tris),{k:v for k,v in p.items()if k not in ['attributes','indices','material','mode']}))
  allmeshes.append((m.get('name'),m.get('extras'),prims))
 return meta,allmeshes,attrs
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
rows=[];fail=[];start=time.monotonic()
for k in keys:
 rel='chicago/4d/assets/gltf/'+k;proc.stdin.write((base['base']+':'+rel+'\n').encode());proc.stdin.flush();head=proc.stdout.readline().decode().split();assert len(head)==3,head;old=proc.stdout.read(int(head[2]));assert proc.stdout.read(1)==b'\n';new=(repo/rel).read_bytes()
 a,b=parse(old),parse(new);sa,sb=sig(*a),sig(*b);problems=[]
 if sa[0]!=sb[0]:problems.append('node/scene/material/extension metadata')
 if sa[1]!=sb[1]:problems.append('oriented triangle physical/NORMAL/confidence/material streams')
 if sa[2]!=sb[2]:problems.append('attribute sets')
 # All native frame surfaces use untextured PBR; UV variation cannot alter shading.
 if a[0].get('textures')or b[0].get('textures'):problems.append('unexpected textures')
 row={'key':k,'bytes_exact':old==new,'actual_export_contract_exact':not problems,'attributes':sorted(sb[2])}
 if problems:row['differences']=problems;fail.append(row)
 rows.append(row)
proc.stdin.close();assert proc.wait()==0
result={'status':'PASS'if not fail else 'FAIL','scope':'ALL270 actual baseline vs refreshed master GLBs. Exact world-free node/scene/material metadata plus exact oriented triangle corner POSITION/NORMAL/_CONFIDENCE and all non-UV attributes; triangle/vertex serialization order ignored. UV-only differences permitted only untextured materials. No CPU-builder substitution.','base':base['base'],'controls':len(rows),'byte_exact':sum(r['bytes_exact']for r in rows),'physical_material_normal_confidence_node_equivalent':sum(r['actual_export_contract_exact']for r in rows),'seconds':round(time.monotonic()-start,3),'failures':fail,'rows':rows}
(out/'genuine271/actual-default-master-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2))
