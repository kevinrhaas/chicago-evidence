from pathlib import Path
import os,sys,json,hashlib,subprocess,datetime,time
app=Path('/tmp/st-mary-picture-20261025/chicago/4d');repo=app.parent.parent;out=Path('/tmp/st-mary-runtime-20261025/genuine271');assert not out.exists();out.mkdir()
cpu=sorted(os.sched_getaffinity(0))[-1];os.sched_setaffinity(0,{cpu});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((Path('/tmp/st-mary-runtime-20261025')/'family-before-9f7.json').read_text());family=base['family_rows'];assert len(family)==271
master_manifest=json.loads((app/'assets/manifest.json').read_text());web_manifest=json.loads((app/'assets/manifest.web.json').read_text())
owned=['data/structures/st_marys_church.json','data/structures/first_presbyterian_church.json','generators/archetypes/frame_dwelling.py','generators/archetypes/frame_dwelling_params.py','docs/LIBERTIES.md','docs/STATUS.md','docs/ROADMAP.md','docs/RESEARCH/st-marys-T-2384-chronology.md','changelog.d/T-2384.json'];bound={p:sha(app/p)for p in owned}
(out/'SOURCE-BINDING.json').write_text(json.dumps({'base':'9f7a31e35864e6ff7af221c5089b90c5160441d8','source':bound,'cpu':[cpu],'frame_rows':len(family),'flags':'Pinnednativebuild.py, UVon/AOoff, --onlyall271frameids, supportedwebserialall271'},indent=2)+'\n')
ids=','.join(sorted({v['structure_id']for v in family.values()}));wrote=out/'WROTE.txt';start=time.monotonic()
cmd=['/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender','-b','-noaudio','--threads','1','--factory-startup','--python','generators/build.py','--','--only',ids,'--wrote',str(wrote)]
with(out/'native-build.log').open('x')as log:r=subprocess.run(cmd,cwd=app,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0,('NativebuildFAIL',r.returncode)
names=wrote.read_text().splitlines();assert len(names)==271 and set(names)==set(family),(len(names),len(family));assert all(sha(app/p)==s for p,s in bound.items())
build_seconds=time.monotonic()-start
with(out/'native-web.log').open('x')as log:r=subprocess.run(['bash','tools/web_derivatives.sh','--only',','.join(names)],cwd=app,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0,('NativewebFAIL',r.returncode)
assert all(sha(app/p)==s for p,s in bound.items())
post=json.loads((app/'assets/manifest.json').read_text());postweb=json.loads((app/'assets/manifest.web.json').read_text());assert {k:v for k,v in master_manifest['assets'].items()if k not in family}=={k:v for k,v in post['assets'].items()if k not in family}
# Preserve all unselected derivative registry rows too, regardless of its top-level schema.
def entries(d):return d.get('assets',d)
wa,wb=entries(web_manifest),entries(postweb);assert {k:v for k,v in wa.items()if k not in family}=={k:v for k,v in wb.items()if k not in family}
changed=[];exact=[]
for rel,info in base['file_hashes'].items():
 (exact if sha(app/rel)==info['sha256']else changed).append(rel)
result={'status':'GENUINE271_MASTER_AND_REALWEB_COMPLETE_SOURCE_UNCHANGED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'build_seconds':round(build_seconds,3),'total_seconds':round(time.monotonic()-start,3),'cpu':[cpu],'native_masters':len(names),'native_web_derivatives':len(names),'source_unchanged':True,'all_nonframe_registry_rows_exact':True,'master_web_bytes_changed':changed,'master_web_bytes_exact':len(exact),'scope':'Actualnativepipeline, notsidecar/fixedpoint/app/fullgate/imageacceptance. Decodeactualcontrols/freshnessnext.'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
