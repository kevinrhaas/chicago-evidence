from pathlib import Path
import sys,json,hashlib,datetime
app=Path('/tmp/st-mary-picture-20261025/chicago/4d');sys.path.insert(0,str(app/'generators'))
import emit,build,mesh_inputs
out=app/'.st-mary-private-review/corrected/st_marys_church__frame_1833.glb';out.parent.mkdir(parents=True,exist_ok=True)
record=json.loads((app/'data/structures/st_marys_church.json').read_text());phase=build.resolve_phase(record,datetime.date(1835,7,1));assert phase['id']=='frame_1833'
protected=[app/'assets/manifest.json',app/'assets/manifest.web.json',app/'data/structures/st_marys_church.json',app/'generators/archetypes/frame_dwelling.py',app/'generators/archetypes/frame_dwelling_params.py',app/'assets/gltf/st_marys_church__frame_1833.glb',app/'assets/web/st_marys_church__frame_1833.glb',app/'data/structures/first_presbyterian_church.json',app/'docs/LIBERTIES.md',app/'docs/STATUS.md',app/'docs/ROADMAP.md',app/'docs/RESEARCH/st-marys-T-2384-chronology.md',app/'changelog.d/T-2384.json'];before={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in protected}
made=emit.emit_structure(record,phase,record['archetype'],out,bake=True,ao=False)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in before.items())
receipt={'status':'PRIVATE_NATIVE_TARGET_ONLY','glb':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'triangles':made.tris,'inputs_sha256':mesh_inputs.structure_inputs_sha(record,phase),'protected_inputs_and_canonical_registries_unchanged':before,'scope':'Genuine pinned emit_structure preview, not canonical installation/family refresh or image acceptance'}
Path('/tmp/st-mary-runtime-20261025/corrected-preview-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
