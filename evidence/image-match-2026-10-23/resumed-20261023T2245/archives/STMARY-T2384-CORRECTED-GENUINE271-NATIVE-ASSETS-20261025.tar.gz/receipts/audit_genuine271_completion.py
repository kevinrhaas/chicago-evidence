from pathlib import Path
import json,subprocess,hashlib,os,datetime
os.sched_setaffinity(0,{3})
app=Path('/tmp/st-mary-picture-20261025/chicago/4d');repo=app.parent.parent;r=Path('/tmp/st-mary-runtime-20261025');out=r/'genuine271';base=json.loads((r/'family-before-9f7.json').read_text());family=base['family_rows'];source=json.loads((out/'SOURCE-BINDING.json').read_text())['source'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def old(rel):return json.loads(subprocess.check_output(['git','show',base['base']+':chicago/4d/'+rel],cwd=repo,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'}))
a=old('assets/manifest.json');b=json.loads((app/'assets/manifest.json').read_text());wa=old('assets/manifest.web.json');wb=json.loads((app/'assets/manifest.web.json').read_text());assert 'masters'in wa and 'masters'in wb
assert {k:v for k,v in a['assets'].items()if k not in family}=={k:v for k,v in b['assets'].items()if k not in family}
assert {k:v for k,v in wa['masters'].items()if k not in family}=={k:v for k,v in wb['masters'].items()if k not in family}
assert {k:v for k,v in wa.items()if k!='masters'}=={k:v for k,v in wb.items()if k!='masters'}
assert all(sha(app/p)==s for p,s in source.items())
names=(out/'WROTE.txt').read_text().splitlines();assert len(names)==271 and set(names)==set(family)
log=(out/'native-web.log').read_text();assert sum(' -> 'in s for s in log.splitlines())==271 and 'recorded 271 master hash(es)'in log
for k in family:assert wb['masters'][k]==sha(app/'assets/gltf'/k)
changed=[];exact=[]
for rel,info in base['file_hashes'].items():(exact if sha(app/rel)==info['sha256']else changed).append(rel)
status=json.loads((r/'genuine271-status.json').read_text());assert status['command_exit']==1 and status['all_children_reaped']
result={'status':'NATIVE271_AND_REALWEB_COMMANDS_COMPLETE_CORRECT_SCHEMA_AUDIT_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base['base'],'native_masters':271,'realweb':271,'nine_authored_sources_exact':True,'unselected_master_registry_rows_exact':True,'unselected_web_masters_rows_exact':True,'web_registry_metadata_exact':True,'all271_recorded_master_hashes_fresh':True,'master_web_bytes_changed':len(changed),'master_web_bytes_exact':len(exact),'initial_driver_status':'FAIL_POST_COMMAND_AUDIT_SCHEMA_USED_OUTEROBJECT_NOT_masters; retained original script/log/status; no commands rerun','initial_driver_wrapper_seconds':round(status['observed_unix']-status['started_unix'],3),'native_build_seconds_approx_from_log_mtime':round((out/'native-build.log').stat().st_mtime-status['started_unix'],3),'resource_correction':'Started CPU4; all owned live tasks moved toCPU3 without restart, separate affinity receipt retained.','scope':'All commands complete, source/default-master contract controls proven; sidecars/fixedpoint/app/fullcheck/preflight and image acceptance still pending.'}
(out/'RESULT-CORRECT-SCHEMA-AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
