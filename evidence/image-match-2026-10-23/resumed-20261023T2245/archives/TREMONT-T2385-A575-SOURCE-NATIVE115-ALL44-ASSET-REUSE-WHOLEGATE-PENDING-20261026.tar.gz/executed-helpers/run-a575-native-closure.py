from pathlib import Path
import os,sys,json,subprocess,hashlib,datetime,shutil,fnmatch,copy,gzip,zipfile,io,xml.etree.ElementTree as ET
os.sched_setaffinity(0,{0});repo=Path('/tmp/tremont-picture-20261026');app=repo/'chicago/4d';out=Path('/tmp/T2385-a575-native-closure-20261026');assert not out.exists();out.mkdir();env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(TMPDIR='/tmp/t2385-a575-native',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');Path(env['TMPDIR']).mkdir(exist_ok=True);probe=dict(env,GIT_NO_LAZY_FETCH='1');base='a575dddeed356333423b20361a1f90f3b39a862f';sha=lambda b:hashlib.sha256(b).hexdigest()
def g(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo,env=probe)
assert g('rev-parse','HEAD').decode().strip()==base
assert json.loads(Path('/tmp/tremont-T2385-a575-owned-transplant-20261026/RESULT.json').read_text())['status']=='OWNED_ONLY_A575_TRANSPLANT_PASS_NO_NATIVE_OR_CODECOMMIT_YET'
for n in ['integrate-a575-native-resolve-v2-status.json','integrate-a575-all44-scope-status.json','integrate-a575-package-publish-status.json']:
 r=json.loads((Path('/tmp/st-mary-runtime-20261025')/n).read_text());assert r['command_exit']==0 and r['all_children_reaped']and not r['leftover_cleanup']
tracked={p for p in g('ls-files','-z').decode().split('\0')if p};allpaths=tracked|{p for p in g('ls-files','--others','--exclude-standard','-z').decode().split('\0')if p};binary={p for p in tracked if p.endswith(('.xlsx','.gz'))};assert len(binary)==44
for p in sorted(binary):
 b=g('show',base+':'+p);q=out/'actual-a575-raw-baseline44'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
manifest=json.loads((app/'tools/derived_manifest.json').read_text());generated={p for s in manifest['steps']for p in s.get('resolves',[])}
def generated_path(p):return any(p==q or p.startswith(q.rstrip('/')+'/')or fnmatch.fnmatch(p,q)for q in generated)
sidecars={p:(repo/p).read_bytes()for p in allpaths if p.startswith('chicago/4d/data/sidecars/')and p.endswith('.json')and(repo/p).is_file()}
residents={p:sha((repo/p).read_bytes())for p in allpaths if p.startswith('chicago/4d/data/residents/')and(repo/p).is_file()}
protected={p:sha((repo/p).read_bytes())for p in allpaths if(repo/p).is_file()and not generated_path(p)and p not in sidecars and p not in residents and p.startswith('chicago/4d/')}
for rel in ['assets/gltf/glessner_house__as_built_1887.glb','assets/web/glessner_house__as_built_1887.glb','assets/web/glessner_house__as_built_1887.light.glb']:protected['chicago/4d/'+rel]=sha((app/rel).read_bytes())
old_model=json.loads(g('show',base+':chicago/4d/data/reconstruction/1835_lodging_model.json'));oldbeds={p['id']:p['beds_ordinary']for p in old_model['places']};current_model=json.loads((app/'data/reconstruction/1835_lodging_model.json').read_text());currentbeds={p['id']:p['beds_ordinary']for p in current_model['places']};changed_caps={k for k in oldbeds if oldbeds[k]!=currentbeds[k]};assert len(changed_caps)==9
beforeledger=json.loads((app/'data/reconstruction/1835_lodgers_seated.json').read_text());(out/'PROTECTED-CURRENT-A575-BEFORE.json').write_text(json.dumps({'protected':protected,'resident_hashes':residents,'capacity_changes':sorted(changed_caps)},indent=2)+'\n')
canonical=(app/'renderers/web/js/changelog.js').read_bytes();assert sha(canonical)=='e5eb3d494e369b4db76b1e99f95bdb2d7775b9c3145e96d1eb2edb1390141339'
expected=json.loads(Path('/tmp/tremont-T2385-app-prepared-20261026/expected.json').read_text());
for e in expected['outputs']:assert sha((app/e['path']).read_bytes())==e['sha256']
steps=[]
def command(name,cmd):
 free=shutil.disk_usage('/tmp').free;assert free>=536870912,(name,'external512MiBreserve',free);start=datetime.datetime.now(datetime.timezone.utc).isoformat();print(name,'START',start,flush=True)
 with(out/(name+'.log')).open('x')as log:r=subprocess.run(cmd,cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'free_before':free,'free_after':shutil.disk_usage('/tmp').free};steps.append(row);(out/'STEPS.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0,(name,r.returncode)
command('01-native-current-capacity-check',['python3','tools/build_lodging_model_1835.py','--check'])
command('02-native-current-lodgers-check',['python3','tools/seat_lodgers_1835.py','--check'])
command('03-native-current-downstream115',['node','tools/rederive.mjs','--tail','tools/rebuild_resident_index.py'])
def protections(label):
 changed={p for p,v in protected.items()if sha((repo/p).read_bytes())!=v};assert not changed,(label,'authored_assets_controls_changed',changed)
 changedpeople={p for p,v in residents.items()if sha((repo/p).read_bytes())!=v};assert not changedpeople,(label,'population_bytes_changed',changedpeople)
 ledger=json.loads((app/'data/reconstruction/1835_lodgers_seated.json').read_text());assert ledger==beforeledger,(label,'quota_ledger_changed')
 assert (app/'renderers/web/js/changelog.js').read_bytes()==canonical
 sys.path.insert(0,str(app/'tools'));import compile_scene as native
 caps=native.compile_lodging();occ=native.compile_lodging_occupancy();reports=[]
 for rel,raw in sidecars.items():
  newraw=(repo/rel).read_bytes()
  if newraw==raw:continue
  if '/1835/tremont_house_1.json' in rel:continue
  a=json.loads(raw);b=json.loads(newraw);key=b.get('id');assert key in changed_caps,(label,'unowned_sidecar_changed',rel)
  expectedcap=copy.deepcopy(caps[key]);expectedcap['occupancy']=occ[key];assert b.get('lodging')==expectedcap,(label,'capacity_not_native',rel)
  x=copy.deepcopy(a);y=copy.deepcopy(b);before=x.pop('lodging')['beds_ordinary'];after=y.pop('lodging')['beds_ordinary']
  for resident in x.get('residents',[]):
   if isinstance(resident.get('why'),str):resident['why']=resident['why'].replace(f'The current estimate is {before},',f'The current estimate is {after},')
   for person in resident.get('persons',[]):
    if isinstance(person.get('note'),str):person['note']=person['note'].replace(f'the current model reports {before}',f'the current model reports {after}')
  assert x==y,(label,'other_sidecar_identity_geometry_or_source_changed',rel);reports.append(rel)
 assert json.loads((app/'data/sidecars/1835/tremont_house_1.json').read_text())['attributes']['stories']['value']==2
 assert json.loads((app/'data/sidecars/1835/versions/tremont_house_1/gifford-reading.json').read_text())['attributes']['stories']['value']==3
 proof={'label':label,'protected_sources_assets_controls_exact':len(protected),'all_population_files_byte_exact':len(residents),'all_seats_mintedIDs_quotas_allocations_whole_ledger_exact':True,'only_native_capacity_reporting_other_sidecars':reports,'canonical_changelog_exact':True,'canonical_two_and_version_three_storeys':True};(out/(label+'-PROTECTIONS.json')).write_text(json.dumps(proof,indent=2)+'\n')
protections('after-native115')
def xlsx_members(b):
 with zipfile.ZipFile(io.BytesIO(b))as z:
  out={}
  for n in z.namelist():
   b=z.read(n)
   if n.endswith(('.xml','.rels')):
    r=ET.fromstring(b)
    if n=='docProps/core.xml':
     for node in list(r):
      if node.tag=='{http://purl.org/dc/terms/}modified':r.remove(node)
    out[n]=ET.canonicalize(ET.tostring(r,encoding='unicode'))
   else:out[n]=b.hex()
  return out
outside={p for p in g('diff',base,'--name-only','-z').decode().split('\0')if p and not p.startswith('chicago/4d/')};audit=[]
for rel in sorted(binary|outside):
 p=repo/rel;now=p.read_bytes();old=(out/'actual-a575-raw-baseline44'/rel).read_bytes()if rel in binary else g('show',base+':'+rel);equal=now==old;kind='EXACT_BYTES'
 if not equal and rel.endswith('.xlsx'):kind='ALL_XLSX_MEMBERS_EXCEPT_MODIFIED_TIMESTAMP';equal=xlsx_members(now)==xlsx_members(old)
 elif not equal and rel.endswith('.gz'):
  kind='GZIP_DECOMPRESSED_BYTES';equal=gzip.decompress(now)==gzip.decompress(old)
  if not equal:
   try:equal=json.loads(gzip.decompress(now))==json.loads(gzip.decompress(old));kind='GZIP_JSON_SEMANTICS'
   except(ValueError,UnicodeError):pass
 elif not equal:
  try:equal=json.loads(now)==json.loads(old);kind='JSON_SEMANTICS'
  except(ValueError,UnicodeError):kind='REAL_OR_UNCLASSIFIED'
 rec={'path':rel,'proof':kind,'equal':equal,'current_sha256':sha(now),'actual_a575_sha256':sha(old),'action':'UNCHANGED'if now==old else'RESTORE_WHOLE_EQUAL_ONLY'if equal else'RETAIN_REAL_NATIVE_CHANGE'};audit.append(rec)
 if now!=old:
  q=out/'regenerated-before-normalization'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(now)
  if equal:p.write_bytes(old)
(out/'ONE-ALL44-ACTUAL-A575-AND-OUTSIDE-AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
command('04-native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'])
command('05-native-final-publish',['bash','tools/publish.sh'])
for name,cmd in [('06-native-reconstruction-check',['python3','tools/reconstruct_residents_1835.py','--check']),('07-native-lodging-check',['python3','tools/build_lodging_model_1835.py','--check']),('08-native-boarders-check',['python3','tools/seat_lodgers_1835.py','--check']),('09-native-boarders-selftest',['python3','tools/seat_lodgers_1835.py','--self-test']),('10-strict-drawn-placement-fixtures',['node','tools/test_drawn_placement_census.mjs'])]:command(name,cmd)
protections('final')
for e in expected['outputs']:assert sha((app/e['path']).read_bytes())==e['sha256']
result={'status':'PASS_FRESH_A575_NATIVE_CLOSURE_ALL_INCOMING_PROTECTED','finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'branch':g('branch','--show-current').decode().strip(),'steps':steps,'protected_sources_assets':len(protected),'population_files_byte_exact':len(residents),'raw_actual_a575_binaries_captured':len(binary),'same_four_native_GLBS':True,'no_exports_no_app_no_codecommit':True,'pending':'Actual2jobcurrentFULL3questions then normalcodecommit/committedCLIDs/publicdevPR/full18/merge. No currentfull18 or opacitypredicate certificate implied; originalT2385OPEN/DIF.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
