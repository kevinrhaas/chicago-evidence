from pathlib import Path
import os,json,hashlib,subprocess,shutil,datetime
repo=Path('/tmp/tremont-picture-20261026');app=repo/'chicago/4d';out=Path('/tmp/tremont-T2385-a575-owned-transplant-20261026');assert not out.exists();out.mkdir();env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);probe=dict(env,GIT_NO_LAZY_FETCH='1')
def g(*a,check=True):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo,env=probe,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if check and p.returncode:raise RuntimeError((a,p.returncode,p.stderr.decode()))
 return p.stdout
sha=lambda b:hashlib.sha256(b).hexdigest()
base='a575dddeed356333423b20361a1f90f3b39a862f';oldhead='cf25a3f2bb653648d25502fe5fab914b8cb29453';oldtree='89c3b1dcdd5b27aea296747299d86902761dbace'
receipt={'public_commit':'e55a956162220c003e9d3984de16de39ae1fd284','availability_commit':'55ce0e17b2856dd1c7f86f7b17dd659ea771e3d8','manifest_sha256':'03f5d81623aefdbb1bd6c7775d7a9f1ee1e8d78b4721cc5e1d48039d6e03a8d7','archive_sha256':'f949490959bc7ac8fcb732a267d8820b9f71f8c19c6fbbc80e43d3f52dff94e4','all_members_independently_verified':73,'publisher':'/root/current_dev_objects','immutable_receipt':'https://raw.githubusercontent.com/kevinrhaas/chicago-evidence/55ce0e17b2856dd1c7f86f7b17dd659ea771e3d8/evidence/image-match-2026-10-23/resumed-20261023T2245/publications/e55a956162220c003e9d3984de16de39ae1fd284.json'}
(out/'PUBLIC-RECOVERY-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert g('write-tree').decode().strip()==oldtree and not g('diff','--name-only').strip();assert g('rev-parse','HEAD').decode().strip()==oldhead;assert g('rev-parse','MERGE_HEAD').decode().strip()=='132e0e85a9645055de1bfc4544942ec969b14511';assert g('rev-parse','refs/heads/checkpoint/t2385-capacity-before-a575-20261026^{tree}').decode().strip()==oldtree
owned=['data/structures/tremont_house_1.json','data/structures/versions/tremont_house_1/gifford-reading.json','data/sources/gale_1902_tremont_town_walk.json','docs/RESEARCH/tremont_house_1.md','tools/test_frame_tavern_picture_features.py','changelog.d/T-2385.json','assets/gltf/tremont_house_1__frame_1833.glb','assets/web/tremont_house_1__frame_1833.glb','assets/gltf/versions/tremont_house_1/gifford-reading/tremont_house_1__frame_1833.glb','assets/web/versions/tremont_house_1/gifford-reading/tremont_house_1__frame_1833.glb']
cap=['chicago/4d/data/reconstruction/1835_lodging_model.json','chicago/4d/docs/RESEARCH/1835_lodging_model.md','chicago/4d/data/reconstruction/1835_lodgers_seated.json']+[x['path']for x in json.loads(Path('/tmp/T2385-capacity-causal-finish-20261026/final-POPULATION-PROOF.json').read_text())['changed_reporting_only']]
for rel in cap:assert g('show',base+':'+rel)==g('show','55b54d320ed165b4d7a7346884d420d923092e4c:'+rel),('capacity_preimage_moved',rel)
owned += [p.removeprefix('chicago/4d/')for p in cap]
for rel in ['data/structures/tremont_house_1.json','docs/RESEARCH/tremont_house_1.md','tools/test_frame_tavern_picture_features.py']:
 assert g('show',base+':chicago/4d/'+rel)==g('show',oldhead+':chicago/4d/'+rel),('owned_preimage_moved',rel)
for rel in owned:
 p=app/rel;q=out/'owned-files'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
markers={'docs/LIBERTIES.md':b'\n### L-tremont-gale-envelope-2385 ', 'docs/STATUS.md':'\n## T-2385 — first Tremont evidence correction (2026-10-26)'.encode(),'docs/ROADMAP.md':'\n### T-2385 checkpoint — first Tremont (2026-10-26)'.encode()}
for rel,mark in markers.items():
 raw=(app/rel).read_bytes();assert raw.count(mark)==1;fragment=raw[raw.index(mark):];assert mark not in g('show',base+':chicago/4d/'+rel);q=out/'owned-appends'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(fragment)
books={n:json.loads((app/'assets'/n).read_text())for n in ['manifest.json','manifest.web.json','manifest.versions.json']};key='tremont_house_1__frame_1833.glb';vkey='versions/tremont_house_1/gifford-reading/'+key
rows={'manifest.json':('assets',key,books['manifest.json']['assets'][key]),'manifest.web.json':('masters',key,books['manifest.web.json']['masters'][key]),'manifest.versions.json':('assets',vkey,books['manifest.versions.json']['assets'][vkey])};(out/'owned-registry-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
donor=json.loads(Path('/workspace/green-tree-strict-four-tools-6a61.json').read_text());assert donor['donor']=='6a61ab6eca1f1ea2322302d131e847b383ac9c8b';assert set(donor['paths'])=={'chicago/4d/tools/'+n for n in ['smoke_renderer.mjs','drawn_placement_census.mjs','test_drawn_placement_census.mjs','measure_drawn_placement.mjs']}
for rel,d in donor['paths'].items():
 incoming=g('show',base+':'+rel);assert sha(incoming)==d['preimage_sha256'];blob=g('show',donor['donor']+':'+rel);assert sha(blob)==d['donor_sha256'];q=out/'strict-tools'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(blob)
# Preserve incoming canonical changelog and independently verify the folded dependency.
canonical=g('show',base+':chicago/4d/renderers/web/js/changelog.js');assert sha(canonical)=='e5eb3d494e369b4db76b1e99f95bdb2d7775b9c3145e96d1eb2edb1390141339';(out/'incoming-canonical-changelog.js').write_bytes(canonical);fragment=json.loads((app/'changelog.d/T-2376.json').read_text());(out/'folded-T2376-fragment.json').write_text(json.dumps(fragment,indent=2)+'\n')
script="import fs from 'node:fs';const p=process.argv[1];const raw=fs.readFileSync(p,'utf8');const m=await import('data:text/javascript;base64,'+Buffer.from(raw).toString('base64'));const rows=Object.values(m).find(Array.isArray);const f=JSON.parse(fs.readFileSync(process.argv[2]));const x=rows.find(x=>x.v===2302);if(!x||!['title','kind','items'].every(k=>JSON.stringify(x[k])===JSON.stringify(f[k])))throw Error('Folded dependency mismatch');console.log(JSON.stringify(x));"
r=subprocess.run(['node','--input-type=module','-e',script,str(out/'incoming-canonical-changelog.js'),str(out/'folded-T2376-fragment.json')],cwd=app,env=env,capture_output=True,text=True);(out/'T2376-FOLD-VERIFY.log').write_text(r.stdout+r.stderr);assert r.returncode==0,('foldcheck',r.stderr)
# Only now, after public recovery and every incoming/owned proof, clear OUR pending merge.
g('merge','--abort');assert g('rev-parse','HEAD').decode().strip()==oldhead;assert not g('status','--porcelain').strip(),('unexpected_after_abort',g('status','--porcelain').decode())
newbranch='steward/t2385-tremont-gale-a575';g('switch','-c',newbranch,base);assert not g('status','--porcelain').strip()
for rel in owned:
 dst=app/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(out/'owned-files'/rel,dst)
for rel in markers:
 dst=app/rel;before=dst.read_bytes();assert before==g('show',base+':chicago/4d/'+rel);dst.write_bytes(before+(out/'owned-appends'/rel).read_bytes());assert dst.read_bytes().startswith(before)
for n,(bucket,target,row)in rows.items():
 dst=app/'assets'/n;before=json.loads(dst.read_text());after=json.loads(json.dumps(before));after[bucket][target]=row
 assert {k:v for k,v in after[bucket].items()if k!=target}=={k:v for k,v in before[bucket].items()if k!=target};assert set(after[bucket])==set(before[bucket])|{target};dst.write_text(json.dumps(after,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
for rel,d in donor['paths'].items():
 dst=repo/rel;assert sha(dst.read_bytes())==d['preimage_sha256'];dst.write_bytes((out/'strict-tools'/rel).read_bytes());assert sha(dst.read_bytes())==d['donor_sha256']
allowed={'chicago/4d/'+p for p in owned}|{'chicago/4d/'+p for p in markers}|{'chicago/4d/assets/'+p for p in rows}|set(donor['paths'])
changed=set(g('diff','--name-only').decode().splitlines())|set(g('ls-files','--others','--exclude-standard').decode().splitlines());assert changed<=allowed,(changed-allowed)
assert (app/'renderers/web/js/changelog.js').read_bytes()==canonical
assert not (app/'changelog.d/T-2376.json').exists(),'folded_fragment_resurrected'
assert 'house_1828_prairie__draft_1904.glb'not in json.loads((app/'assets/manifest.json').read_text())['assets']
for rel in ['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py']:assert (app/rel).read_bytes()==g('show',oldhead+':chicago/4d/'+rel)
result={'status':'OWNED_ONLY_A575_TRANSPLANT_PASS_NO_NATIVE_OR_CODECOMMIT_YET','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'new_branch':newbranch,'old_branch_preserved':'steward/t2385-tremont-gale-1835','old_complete_tree':oldtree,'private_stash':'9e4885ba8f2296c4e647ff04d09f31ed8ddde968','public_recovery':receipt,'owned_fullfiles':owned,'appended_only':list(markers),'owned_registry_rows':rows,'strict_public_donor':donor['donor'],'strict_paths':donor['paths'],'changed_paths':sorted(changed),'incoming_all_others_preserved':True,'incoming_archived_draft_not_resurrected':True,'incoming_canonical_changelog_exact':True,'T2376_fragment_folded2302_verified':True,'native_frame_producer_recipe_exact_cf25':True,'pending':'Actual fresh-base native closure on leasedCPU0, full3questions with2jobs, normalcommit/committedCLIDs/publicdevPR/full18/currentmerge. OriginalT2385 staysOPEN/DIF.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'base':base,'new_branch':newbranch,'changed_paths':len(changed),'owned_fullfiles':len(owned),'public_recovery':receipt['public_commit']},indent=2))
