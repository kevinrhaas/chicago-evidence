"""Validate frozen six-path source bundle. Writes require explicit current native claim/lease.
No assets, match verdicts, claims, stages, commits, remote writes or qualification inferred.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess
P=argparse.ArgumentParser(description=__doc__);P.add_argument('--repo',type=Path,default=Path('/workspace/chicago'));P.add_argument('--expected-head',required=True);P.add_argument('--output',required=True,type=Path);P.add_argument('--apply',action='store_true');args=P.parse_args()
B=Path(__file__).parent/'bundle-v2';plan=json.loads((B/'PLAN.json').read_text());R=args.repo.resolve();E=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R,env=E,text=True).strip()
def bind(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert git('rev-parse','HEAD')==args.expected_head,'Current integration head changed'
assert not args.output.exists();branch=git('branch','--show-current');writes=[]
for row in plan['source_changes']:
 rel=Path(row['path']);assert not rel.is_absolute()and'..'not in rel.parts
 target=R/rel;before=target.read_bytes()if target.exists()else None;after=(B/'postimages'/rel).read_bytes()
 assert (None if before is None else bind(before))==row['before'],('Current preimage changed; reprepare fieldwise',str(rel))
 assert bind(after)==row['after'],('Frozen postimage changed',str(rel))
 writes.append((target,before,after,row))
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'READ_ONLY_SOURCE_BUNDLE_VALIDATED','head':args.expected_head,'branch':branch,'paths':[x[3]for x in writes],'all_preimages_and_postimages_exact':True,'assets_recipe_capture_grade_scene_app_fullgate_PR_merge_done':'NOT_PERFORMED'}
if args.apply:
 assert os.environ.get('SCHOOL_ADOPTION_LEASE')=='original-T2372-claimed-primary-released','Root must first take native original claim and release primary lease'
 assert branch.startswith('steward/t2372-'),'Use a new original-school steward branch after current four-case merge'
 assert git('status','--porcelain=v1')=='','Source adoption starts from clean current integration tree'
 args.output.mkdir(parents=True)
 for target,before,after,row in writes:
  backup=args.output/'preimages'/row['path'];backup.parent.mkdir(parents=True,exist_ok=True)
  if before is not None:backup.write_bytes(before)
  target.parent.mkdir(parents=True,exist_ok=True);tmp=target.with_name(target.name+'.t2372-adopting');assert not tmp.exists();tmp.write_bytes(after);os.replace(tmp,target)
 assert git('rev-parse','HEAD')==args.expected_head
 assert all(bind(target.read_bytes())==row['after']for target,_,_,row in writes)
 summary['status']='GUARDED_SIX_SOURCE_POSTIMAGES_ADOPTED_NO_NATIVE_QUALIFICATION'
else:args.output.mkdir(parents=True)
(args.output/'RESULT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'status':summary['status'],'head':summary['head'],'paths':len(writes)},indent=2))
