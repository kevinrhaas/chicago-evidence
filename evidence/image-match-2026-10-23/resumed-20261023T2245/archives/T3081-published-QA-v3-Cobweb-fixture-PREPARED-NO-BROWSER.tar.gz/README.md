# T-3081 QA v3 — updated Cobweb record binding, still unexecuted

This small revision preserves the frozen v1/v2 packages. It changes only Cobweb Castle's `record_sha256` fixture from `5dcbf4f18c071364c1fe8ef1da43973a597d7a67bf8ed611ed990704e435e71f` to `36a2cb6431851a3c36a90c865bf89861ef8abd7cadfda93544909bc0380edca8`, for the newly adopted reconstructed `form.chimney_head_m.value:5.05` claim. That claim cites `chicago_democrat_1833_1835`; the existing primary Wau-Bun source, its citation/URL, empty-Photos expectation and unresolved panorama warning all stay unchanged. The other four authored record hashes and all five doorway/source/camera/credit expectations are unchanged. `BINDING-REVISION.json` records the exact delta and existing authored claim, not a measured mesh height.

`qa-published.mjs`, `stage-pictures.mjs` and `preserve-picture.mjs` are byte-for-byte v2 copies. The runner has no config override option: it reads `models.json` beside its own `import.meta.url`. The copy here deliberately makes actual execution consume v3's reviewed binding rather than the obsolete v2 fixture. `run-sequential.sh` changes only `qa_dir` to this v3 directory. No assertion was removed or weakened. Original images and numerically unchanged provisional cameras remain referenced by the original frozen v1 packet; staging verifies and copies those to a fresh runtime directory before generating match files. See `/tmp/T3081-published-qa-v2-20261024/README.md` for the detailed methods, limits and planning costs.

Root must finish the official all82 bake, native derivation and full gate, then explicitly grant the shared heavy/browser slot. Neither command has been executed:

```sh
TMPDIR=/workspace/tmp-t3081 bash /tmp/T3081-published-qa-v3-20261024/run-sequential.sh published --execute-after-root-grant /tmp/T3081-daaf-actual-qa-20261024
```

This runs ten independent published cases sequentially: mobile school, Cobweb, Miller, Carpenter, Wolf, then desktop in that order. It stops at the first failure and refuses existing output directories. A separate root grant permits the five unchanged provisional source comparisons:

```sh
TMPDIR=/workspace/tmp-t3081 bash /tmp/T3081-published-qa-v3-20261024/run-sequential.sh pictures --execute-after-root-grant /tmp/T3081-daaf-actual-qa-20261024
```

Single-case dry mode is safe without a browser and demonstrates fixture selection:

```sh
TMPDIR=/workspace/tmp-t3081 node /tmp/T3081-published-qa-v3-20261024/qa-published.mjs --viewport mobile --ids cobweb_castle --out /tmp/T3081-qa-v3-dry-unused
```

For an actual case after root grant, add `--execute` and choose a fresh actual-output path. The unchanged harness reports actual live bounds and source-config hash; review Cobweb's max-Y against the reconstructed5.05m head after official assets settle. Root owns precise native/raw geometry checks. This preparation read no in-flight GLB, web asset or generated sidecar. The new height is an authored construction choice with a source/date qualification, not an image-derived or compliance claim. All picture gates remain open.

Validation here is JavaScript/shell syntax and authored-hash guarded dry mode for all five records only. Frozen v2 payload hashes verify, and a structural comparison proves the entire models fixture differs only in Cobweb's reviewed record hash. No browser, publish, Blender, fetch, full gate, camera fitting, accepted view, verdict change or app/source write occurred. Do not label this as actual application QA.
