#!/usr/bin/env bash
# Prepared only. Read README; root must grant the shared browser slot explicitly.
set -euo pipefail
if [[ $# != 3 || "$2" != --execute-after-root-grant ]]; then
  echo 'usage: bash run-sequential.sh published|pictures --execute-after-root-grant /absolute/new/output-root' >&2
  exit 2
fi
qa_dir=/tmp/T3081-published-qa-v3-20261024
app_dir=/tmp/chicago-log-integration/chicago/4d
run_dir=$3
if [[ "$run_dir" != /* ]]; then echo 'Output must be absolute' >&2; exit 2; fi
export PW_EXECUTABLE=/usr/bin/chromium
ids=(chappel_infant_school cobweb_castle miller_house philo_carpenter_log_shop wolf_point_tavern)
case "$1" in
 published)
  if [[ -e "$run_dir/published" ]]; then echo 'Refusing existing published run' >&2; exit 2; fi
  mkdir -p "$run_dir/published"
  for viewport in mobile desktop; do
   for id in "${ids[@]}"; do
    case_dir="$run_dir/published/$viewport-$id"
    # No pipe: preserve native stdout and an independent receipt per case.
    node "$qa_dir/qa-published.mjs" --app "$app_dir" --viewport "$viewport" --ids "$id" --out "$case_dir" --execute > "$case_dir.log" 2>&1
   done
  done
  ;;
 pictures)
  if [[ -e "$run_dir/pictures" || -e "$run_dir/picture-inputs" ]]; then echo 'Refusing existing picture run' >&2; exit 2; fi
  mkdir -p "$run_dir/pictures"
  node "$qa_dir/stage-pictures.mjs" --out "$run_dir/picture-inputs" > "$run_dir/pictures/STAGING.log" 2>&1
  cd "$app_dir"
  for id in "${ids[@]}"; do
   node tools/photo_match.mjs "$run_dir/picture-inputs/cameras/portable/$id.json" --out "$run_dir/pictures/$id" > "$run_dir/pictures/$id.log" 2>&1
   node "$qa_dir/preserve-picture.mjs" "$run_dir/picture-inputs/cameras/portable/$id.json" "$run_dir/pictures/$id" "$run_dir/pictures/$id.log" > "$run_dir/pictures/$id-preserve.log" 2>&1
  done
  ;;
 *) echo 'mode must be published or pictures' >&2; exit 2;;
esac
