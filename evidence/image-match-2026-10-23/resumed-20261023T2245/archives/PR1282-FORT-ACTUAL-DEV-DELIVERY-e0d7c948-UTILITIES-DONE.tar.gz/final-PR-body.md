Five first-fort ranges gain two-storey courtyard galleries, source-shaped openings and chimney counts. Their upper beams meet the existing canopy, closing the reviewed 30–58 mm gap without moving roofs, posts or footprints. Two blockhouses lose invented domestic chimneys. Metric dimensions, glazing and hidden features remain reconstructed or unresolved.

This group owns T-3105 (fort ranges), T-3119 (four Kinzie poplars and six Ouilmette currants with clearance) and T-3120 (1812 Light/Full woodland reach within unchanged caps). It has one What's-New entry with three items. Original T-2387/T-3041 remain open: all sixteen earlier and eight new same-camera comparisons still **DIFFERS**.

Hogan PR [#1283](https://github.com/kevinrhaas/chicago/pull/1283) is now merged into `dev`. This branch integrates its actual squash and automatic changelog fold. Six ancestry conflicts were resolved only after proving each incoming blob equals the Hogan source already integrated here. Against full-smoke-tested `308b738e`, the resolved tree changes exactly two automatic changelog-fold paths; every other blob is identical. The already-folded pending Hogan entry was removed after exact title/kind/items equality checks.

Validation:

- Genuine pinned Blender 4.5.3 exports and real web derivatives for all 25 fort-family models. Seven initial targets change; 18 defaults preserve physical geometry, normals, materials and confidence. The beam correction changes five beam regions; the other 20 model/web assets remain exact. Independent decoding verifies roof contact and no coplanar timber top; maximum web residual is 0.304 mm, within measured quantisation bounds.
- Native rebuild/population checks pass. All 26 protected population/policy files and 105 log/frame recipe sets remain exact to the upstream; independent Hogan preservation checks pass.
- Fourteen standard mobile/desktop app cases pass, with all 56 states directly reviewed. An additional actual published Fly inspection shows supported courtyard galleries. It establishes no on-foot access; the existing grounded courtyard failure remains recorded.
- **All 18 published smoke parts pass on `308b738e`: 829 desktop and 836 mobile assertions, zero failures or page errors.** Full 1904 measures 4,191 calls / 3,943,402 triangles against unchanged 7,800 / 4.6M caps; Light remains within its own caps.
- The resolved current-`dev` tree independently passes **1,065 check steps, including 384 self-tests**, with required readers and unchanged source. Its only served delta is the automatic Hogan release entry. Actual published mobile/desktop checks repeat the original unread/returning-visitor assertions and verify the folded entry exactly once, its exact text and no page overflow. This is targeted changed-data verification; the all-18 result above belongs to `308b738e`.

Roof proportions, materials, stack placement, cameras, context and the magazine-identification erratum remain open. The release-feed probe also records text extending beyond the inner panel at both sizes; its no-page-overflow result does not establish a clipping-free feed. No renderer CSS changes are included here. This bounded increment does not complete an original picture-match ticket.

[Recovery index and full-18 evidence](https://github.com/kevinrhaas/chicago-evidence/blob/c3b550f08c28429fa40b1d23127672c849c52e02/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md). The reconciliation and actual delivery receipts are checkpointed in the same evidence repository.

Fresh hosted gate, moving-frames (32 checks) and report all pass on the final resolved head `7a58448ab207e67de14fb7d792ca01258ce8f748` (tree `e75afb91d8710c7f05a1675255ef07ba785c27bd`).
