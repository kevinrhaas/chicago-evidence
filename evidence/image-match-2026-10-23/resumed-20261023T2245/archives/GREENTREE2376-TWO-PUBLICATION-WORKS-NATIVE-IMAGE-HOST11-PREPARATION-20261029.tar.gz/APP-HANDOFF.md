# Green Tree drawing copies — prepared, not published

Two credited public-domain publication works and four native image-store files.
All current imagehost rows are preserved entrywise against BASE-REF. The source
displays are byte-exact held JPEGs; native fetch_image generated thumbnails and
native sync_image_store generated scoped manifest/STORE rows. No app source or
existing images clone changed. Publisher owns fresh-main compare, normal PR,
expected-head merge and strict Pages HTTP200/byte readback.

After actual delivery: add stream-green-tree-picture-references.json to app
Prairie streams; merge APP-STORE-FOUR-ROWS into current STORE entrywise; rebuild
images via its native owner; name the Andreas library id in the existing
Andreas camera and the Trowbridge id in its forthcoming diagnostic camera.
Both comparison cameras must be diagnostic_only and never expose an invented
historic From this spot. Retrospective caption/date limits and canonical open
versus optional closed shoulder conflict remain in the structure and match.
The unverified1859 photograph supplies no geometry.
