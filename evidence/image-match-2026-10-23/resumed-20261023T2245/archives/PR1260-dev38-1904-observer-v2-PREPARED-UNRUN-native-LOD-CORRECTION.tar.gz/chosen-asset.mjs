import assert from 'node:assert/strict';

// The native record retains its base sidecar asset at every LOD. Its actual
// assetUrl/assetDetail are the parsed, committed load, not a guessed viewport URL.
export function expectedChosenAsset(model, actual, origin, files) {
  assert.equal(actual.declared_full, 'gltf/' + model.asset);
  assert.equal(actual.asset_detail, actual.detail);
  let asset=model.asset, sha256=model.web_sha256, lod='full';
  if(model.light_asset){
    assert.equal(actual.inspection_lod,true);
    assert.equal(actual.declared_light,'gltf/'+model.light_asset);
    if(['light','balanced'].includes(actual.detail)){
      asset=model.light_asset;sha256=model.light_web_sha256;lod='light';
    }
  }else assert.equal(actual.inspection_lod,false);
  const nativePath='gltf/'+asset, urlPath='/data/'+nativePath;
  assert.equal(actual.native_chosen_path,nativePath);
  const loaded=new URL(actual.asset_url);
  assert.equal(loaded.origin,origin);
  assert.equal(loaded.pathname,urlPath);
  const bound=files.find(f=>f.root==='site'&&f.path==='data/gltf/'+asset);
  assert(bound,'Chosen native derivative must have a frozen published binding');
  assert.equal(bound.sha256,sha256);
  assert(Number.isInteger(bound.bytes)&&bound.bytes>0);
  return {id:model.id,lod,asset,url_path:urlPath,sha256,bytes:bound.bytes,actual};
}

export function checkChosenTransfer(chosen, served, finishedPaths) {
  assert(finishedPaths.has(chosen.url_path),'Actual chosen derivative request did not finish');
  const rows=served.filter(r=>r.path===chosen.url_path);
  assert(rows.length,'Actual chosen derivative was not served');
  assert(rows.every(r=>r.completed&&r.read_complete&&r.sha256===chosen.sha256&&r.bytes===chosen.bytes),'Chosen derivative served bytes/SHA/completion mismatch');
  return rows;
}
