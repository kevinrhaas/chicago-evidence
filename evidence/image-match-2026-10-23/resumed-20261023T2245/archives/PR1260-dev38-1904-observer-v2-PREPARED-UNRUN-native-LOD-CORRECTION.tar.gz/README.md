# Observer V2 — PREPARED UNRUN, no app or trust changes

Based on the actual001 helper, retaining its added shadow/cull diagnostics. Originals/preparedV1/failedactual001 remain untouched. Only observer expectations and diagnostics change; native source/LOD policy/tier/caps/geometry/cameras and Photos rendering/assertions stay intact.

Actual001 classification: nativeFullspawn3,955,624triangles/4,158calls PASS underunchanged4,600,000/7,800caps; all233structuresstand. WholeQA FAIL is retained. Allfour exactrow/creditpredicates were TRUE. Glessner12/Ames11/Wheeler12 lazyimages allhad zero naturaldimensions, with36ERR_CERT_AUTHORITY_INVALIDrequests includingoneWheelerfullimage; Churchlink-onlyhadnoimagesandpassed. Page/HTTP/loadererrors0, oneexistingnativeERR_ABORTED is stillseparatelyclassified. This is evidence forenvironmentTLSfailure, not a Photosrow/creditregression finding.

Rootowns certificate/trust diagnosis. The initiallysuggested missingCA inference fromnicknames was WRONG: rootverifiedcurrentconfiguredCA fingerprintC71B...7FC3 is alreadytrusted asOpenAI-nebula-dns. No NSS/globaltrust change wasdone here. V2uses ignoreHTTPSErrors:false and keepsallTLS/request/imagefailures fatal; no certificatebypass, imageassertionremoval or errorfilterrelaxation.

Native scene-loader.js52–61 chooses sidecar.asset_lods.light forGlessnerLight/Balanced. The base sidecar.asset remainsFull atalltiers, soV1wronglyrequiredFullrequestevenonMobileLight. V2binds bothdeclaredderivatives butthenreadsactualnative detail, record.assetDetail, record.assetUrl, native detailAssetPath, base/lightdeclarations andversion. An independentboundedmodelrule requires the properchosenpath+localorigin andfrozenexpectedSHA/bytecount. ActualserverstreamSHA/bytes andbrowserrequestfinished MUST match theCHOSEN derivative. Full isnot required/claimedloadedwhenLightwaschosen. Otherthreebuildings keeptheirFullassetatalltiers. Bindingfiles asfrozeninputs doesnot prove theywerefetched. Noforcedtier/viewportFullsubstitute.

PureCPUtests acceptFull/Light/Balanced andnon-LODmobilecases; rejectwrong/unloadedFullonLight, wrongorigin/path, wrongdeclaredLOD, missingpublishedbinding, wrongSHA/bytecount, absent/unfinishedactualrequest. Photosnativeexactcreditpredicate, nativebudgetassertion, imagecomplete/naturaldimensionpredicate andunknownerrorfilters are heldexact againstactual001. Rich expected/actualphotoID-credit-linkdiagnostics plusrequesterrorcounts are now retained.

After root restores the EXACTsamecandidate code and repairs trust correctly, use a NEWoutput:

    python3 /workspace/PR1260-dev38-1904-probe-v2-observer-20261024/run.py --app /tmp/chicago-log-integration/chicago/4d --out /workspace/PR1260-shadow-ray-observer-v2-actual-001 --viewports desktop,mobile --execute-after-root-grant

The root candidate wrapper must copy chosen-asset.mjs together with probe.mjs/bind.py/run.py/models.json, or copythisentiretinyfolder. No browser run/binding happened during preparation. Desktopbudgetfirst/save/failclosed remains. If a LATERdesktopV2actuallyfullyPASSES and onlymobileobserverfails, preserveit and run--viewports mobile fresh withsamecandidatecode; originaldesktop001networkFAIL is NOTa wholeQApass. Bothviewports/eightactualcards,currentchosenbytebindings andproperTLS/images stillowed. PriorbudgetPASS alone isnot fullQA, freshstage14, merge ornewhead acceptance.
