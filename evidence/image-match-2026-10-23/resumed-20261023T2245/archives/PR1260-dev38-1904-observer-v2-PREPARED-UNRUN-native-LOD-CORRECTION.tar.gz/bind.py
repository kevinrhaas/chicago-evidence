from pathlib import Path
import argparse, hashlib, json, datetime

p = argparse.ArgumentParser()
p.add_argument('--app', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
assert not a.out.exists(), 'Use a new binding file'
app = a.app.resolve()
site = app.parent.parent / 'site/4d'
cfg = json.loads(Path(__file__).with_name('models.json').read_text())
def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()
files = {}
def bind(root, rel):
    base = app if root == 'app' else site
    q = base / rel
    files[(root, str(rel))] = {'root': root, 'path': str(rel), 'bytes': q.stat().st_size, 'sha256': sha(q)}
for q in (app / 'renderers/web/js').rglob('*'):
    if q.is_file():
        rel = q.relative_to(app / 'renderers/web/js')
        bind('app', 'renderers/web/js/' + str(rel))
        bind('site', 'walk/js/' + str(rel))
        if str(rel) == 'changelog.js':
            assert files[('site', 'walk/js/changelog.js')]['sha256'] == '2b276143a734ed7c952f38e4256034073daf1565b6f81f6ebb412c679cf0b341'
            bind('site', 'js/changelog.js')
            assert files[('app', 'renderers/web/js/changelog.js')]['sha256'] == files[('site', 'js/changelog.js')]['sha256']
        else:
            assert files[('app', 'renderers/web/js/' + str(rel))]['sha256'] == files[('site', 'walk/js/' + str(rel))]['sha256']
for rel in ['data/datum.json', 'data/scenes/1904.json', 'assets/manifest.json', 'assets/manifest.web.json']:
    bind('app', rel)
for rel in ['1904/index.html', 'build.json', 'data/pictures/1904.json']:
    bind('site', rel)
for m in cfg['models']:
    bind('app', 'data/structures/' + m['id'] + '.json')
    assert files[('app', 'data/structures/' + m['id'] + '.json')]['sha256'] == m['record_sha256']
    bind('app', 'data/sidecars/1904/' + m['id'] + '.json')
    bind('app', 'data/sources/' + m['source_id'] + '.json')
    for group in ['gltf', 'web']:
        rel = 'assets/' + group + '/' + m['asset']
        bind('app', rel)
        assert files[('app', rel)]['sha256'] == m[group + '_sha256']
    bind('site', 'data/gltf/' + m['asset'])
    assert files[('site', 'data/gltf/' + m['asset'])]['sha256'] == m['web_sha256']
for m in cfg['models']:
    if m.get('light_asset'):
        rel='data/gltf/'+m['light_asset']
        bind('site',rel)
        assert files[('site',rel)]['sha256']==m['light_web_sha256']
        sidecar=json.loads((app/'data/sidecars/1904'/(m['id']+'.json')).read_text())
        assert sidecar['asset_lods']['light']=='gltf/'+m['light_asset']
for rel, expected in cfg['glessner_package'].items():
    bind('app', rel)
    assert files[('app', rel)]['sha256'] == expected['sha256']
a.out.write_text(json.dumps({'status': 'BOUND_ONLY_NO_BROWSER', 'app': str(app), 'site': str(site), 'bound_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'files': list(files.values()), 'models': cfg['models'], 'limits': 'Actual final postpublish file binding only; no browser or accepted match.'}, indent=2) + '\n')
print('BOUND', len(files), 'files; no browser')
