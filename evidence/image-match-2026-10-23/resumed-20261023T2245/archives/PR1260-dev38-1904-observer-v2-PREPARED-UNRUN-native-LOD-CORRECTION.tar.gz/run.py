from pathlib import Path
import argparse, datetime, json, os, subprocess, sys

p=argparse.ArgumentParser()
p.add_argument('--app', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--viewports',default='desktop,mobile')
p.add_argument('--execute-after-root-grant', action='store_true')
a=p.parse_args()
if not a.execute_after_root_grant:
    print('PREPARED_UNRUN: after final publish/fullgate and explicit browser slot only; no binding/browser started.')
    sys.exit(0)
assert a.out.is_absolute() and not a.out.exists()
a.out.mkdir()
here=Path(__file__).resolve().parent
s={'status':'RUNNING','pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':[],'limits':'Bounded native1904 two-viewport entry/spawn plus four changed assets/cards; not fullstage14, oldhead acceptance, or image match.'}
def save():
    (a.out/'ORCHESTRATION.json').write_text(json.dumps(s,indent=2)+'\n')
save()
env={**os.environ,'TMPDIR':'/workspace/PR1260-dev38-probe-tmp','TMP':'/workspace/PR1260-dev38-probe-tmp','TEMP':'/workspace/PR1260-dev38-probe-tmp','PW_EXECUTABLE':'/usr/bin/chromium'}
Path(env['TMPDIR']).mkdir(exist_ok=True)
try:
    commands=[('bind',[sys.executable,str(here/'bind.py'),'--app',str(a.app),'--out',str(a.out/'bindings.json')])]
    viewports=a.viewports.split(',')
    assert viewports and len(set(viewports))==len(viewports) and all(v in ['desktop','mobile'] for v in viewports)
    for v in viewports:
        commands.append((v,['node',str(here/'probe.mjs'),'--bindings',str(a.out/'bindings.json'),'--viewport',v,'--out',str(a.out/v),'--execute']))
    for label,cmd in commands:
        row={'stage':label,'command':cmd,'status':'RUNNING','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        s['stages'].append(row);save()
        with (a.out/(label+'.log')).open('x') as log:
            child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT);row['pid']=child.pid;save();code=child.wait()
        row.update(status='PASS' if code==0 else 'FAILED',exit_code=code,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
        assert code==0, label+' failed; preserve exact outputs and stop, no automatic assertion/threshold repair'
    s['status']='PASS_BOUNDED_NATIVE1904_NOT_FULL_STAGE14'
except BaseException as exc:
    s.update(status='FAILED',error=str(exc));save();raise
finally:
    s['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(s,indent=2))
