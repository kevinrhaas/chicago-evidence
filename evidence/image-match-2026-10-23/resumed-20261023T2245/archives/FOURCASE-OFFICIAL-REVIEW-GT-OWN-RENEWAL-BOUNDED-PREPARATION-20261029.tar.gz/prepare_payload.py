from pathlib import Path
import json,importlib.util,hashlib,zlib,datetime,os
from urllib.request import Request,urlopen
os.sched_setaffinity(0,{1});os.nice(19)
O=Path(__file__).parent
sp=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);m.SOURCE=Path('/workspace/chicago/chicago/4d/tickets');m.G=m.SOURCE/'.git';m.REPO='kevinrhaas/chicago-tickets'
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
before=m.snapshot();save('PREPARE-SOURCE-BEFORE.json',before);assert not before['status']
head=m.api('git/ref/heads/main')['object']['sha'];commit=m.api('git/commits/'+head);tree=m.api('git/trees/'+commit['tree']['sha']+'?recursive=1');assert not tree.get('truncated');save('REMOTE-COMMIT.json',commit);save('REMOTE-TREE.json',tree)
leaves=[r for r in tree['tree']if r['type']!='tree'];assert all(r['type']=='blob'and r['mode']=='100644'for r in leaves)
known=m.indexed([r['sha']for r in leaves]);missing=[r for r in leaves if r['sha']not in known];assert len(missing)<=128 and sum(r['size']for r in missing)<1024**2
payload=O/'encoded-objects';payload.mkdir(exist_ok=False);rows=[]
for r in missing:
 with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+head+'/'+r['path'],headers={'User-Agent':'Chicago-ticket-native-endgame-bounded-preparation'}),timeout=60)as resp:assert resp.status==200;b=resp.read(r['size']+1)
 assert len(b)==r['size']and m.gitsha('blob',b)==r['sha'];raw=b'blob '+str(len(b)).encode()+b'\0'+b;enc=zlib.compress(raw);p=payload/r['sha'];p.write_bytes(enc);rows.append({'path':r['path'],'sha':r['sha'],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'encoded_bytes':len(enc),'payload':str(p)})
compare=m.api('compare/'+before['HEAD']+'...'+head);save('REMOTE-COMPARE.json',compare);assert compare['status']in {'ahead','identical'}
own={r['path']for r in leaves if any('/'+n+'-'in r['path']for n in ['T-2381','T-2373','T-2384','T-2377','T-2376'])};assert len(own)==5
assert not own&{r['filename']for r in compare['files']},'Ownrecords changed remotely: reread before nativeactions'
after=m.snapshot();save('PREPARE-SOURCE-AFTER.json',after);assert before==after
save('PAYLOAD.json',{'status':'BOUNDED_TICKET_TIP_BLOBS_PREPARED_NO_PRIMARY_IMPORT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_local_head':before['HEAD'],'remote_tip':head,'remote_tree':commit['tree']['sha'],'remote_leaves':len(leaves),'new_blob_count':len(rows),'new_blob_bytes':sum(r['bytes']for r in rows),'cap':1024**2,'rows':rows,'own_ticket_paths':sorted(own),'allfive_ownrecords_unchanged_in_remoteadvance':True,'source_HEAD_index_config_status_refs_unchanged':True,'scope':'ExternalencodedpayloadONLY. No primaryobject/ref/files/mirror writes, no native REVIEW/claim action, no hand-editedstates.'});print((O/'PAYLOAD.json').read_text())
