"""Root grants this only after fullgate closes, before native ticket CLI. No refs/files/mirror edits."""
from pathlib import Path
import json,importlib.util,hashlib,zlib,os,shutil,datetime,argparse
P=argparse.ArgumentParser(description=__doc__);P.add_argument('--output',required=True);a=P.parse_args();O=Path(a.output);O.mkdir(exist_ok=False);B=Path(__file__).parent
sp=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);m.SOURCE=Path('/workspace/chicago/chicago/4d/tickets');m.G=m.SOURCE/'.git';m.REPO='kevinrhaas/chicago-tickets'
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
p=json.loads((B/'PAYLOAD.json').read_text());assert p['status']=='BOUNDED_TICKET_TIP_BLOBS_PREPARED_NO_PRIMARY_IMPORT'and p['new_blob_bytes']<1024**2
before=m.snapshot();save('SOURCE-BEFORE.json',before);assert before['HEAD']==p['expected_local_head']and not before['status']and not(m.G/'MERGE_HEAD').exists();assert m.api('git/ref/heads/main')['object']['sha']==p['remote_tip'],'Remoteadvanced: prepare fresh exacttip'
new=[r for r in p['rows']if r['sha']not in m.indexed([r['sha']])];allocation=sum(((r['encoded_bytes']+4095)//4096)*4096 for r in new);assert shutil.disk_usage('/workspace').free>=512*1024**2+allocation+65536
rows=[]
for r in new:
 enc=Path(r['payload']).read_bytes();raw=zlib.decompress(enc);header,b=raw.split(b'\0',1);assert header==b'blob '+str(len(b)).encode()and len(b)==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256']and hashlib.sha1(raw).hexdigest()==r['sha']and len(enc)==r['encoded_bytes'];d=m.G/'objects'/r['sha'][:2]/r['sha'][2:];assert not d.exists();d.parent.mkdir(exist_ok=True);tmp=d.with_name(d.name+'.ticket-hydrate-'+str(os.getpid()));tmp.write_bytes(enc);assert tmp.read_bytes()==enc;tmp.rename(d);rows.append({k:r[k]for k in ['path','sha','bytes','sha256']});assert shutil.disk_usage('/workspace').free>=512*1024**2
leaves=[r for r in json.loads((B/'REMOTE-TREE.json').read_text())['tree']if r['type']!='tree'];assert {r['sha']for r in leaves}<=m.indexed([r['sha']for r in leaves]);after=m.snapshot();save('SOURCE-AFTER.json',after);assert before==after
save('RESULT.json',{'status':'BOUNDED_EXACT_TICKET_CURRENTTIP_BLOBS_HYDRATED_NO_REFS_FILES_OR_MIRROR_MUTATIONS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'remote_tip':p['remote_tip'],'old_HEAD':before['HEAD'],'rows':rows,'all_tip_blob_ids_available':len(leaves),'source_HEAD_index_config_status_refs_unchanged':True,'native_CLI_REVIEW_or_GTrenewal':'NOT_RUN; root next invokes officialcommands, neverhandeditstates'});print((O/'RESULT.json').read_text())
