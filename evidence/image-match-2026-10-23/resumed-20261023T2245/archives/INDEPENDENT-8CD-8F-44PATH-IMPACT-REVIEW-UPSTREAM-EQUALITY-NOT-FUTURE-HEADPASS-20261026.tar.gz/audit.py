import hashlib,json,os,pathlib,re,subprocess,datetime
OUT=pathlib.Path(__file__).parent
REPO=pathlib.Path('/tmp/jail-picture-c6')
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1')
BASE='a9c5bd4a9715e4d5634c536d0efcd516ea9c3f01'
OLD='8cd2db60777947a16399459fd2945eb804849a51'
NEW='8f70801833aa36dd304f80d92cb8981ce5723f27'
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args],env=ENV)
def blob(ref,path):return git('show',f'{ref}:{path}')
def js(ref,path):return json.loads(blob(ref,path))
def tree(ref):
 out={}
 for line in git('ls-tree','-r','--full-tree','-z',ref).split(b'\0'):
  if not line:continue
  left,path=line.split(b'\t',1);mode,kind,sha=left.decode().split()
  out[path.decode()]={'mode':mode,'kind':kind,'git_blob_sha1':sha}
 return out
def write(name,value):
 p=OUT/name;p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n');return p
B,O,N=map(tree,(BASE,OLD,NEW))
changed=[p for p in sorted(B.keys()|N.keys()) if B.get(p)!=N.get(p)]
write('UPSTREAM-DELTA.json',[{'path':p,'old':B.get(p),'new':N.get(p)} for p in changed])
canonical='chicago/4d/renderers/web/js/changelog.js'
runtime_changes=[p for p in changed if p.startswith('chicago/4d/renderers/')]
assert runtime_changes==[canonical],runtime_changes
renderer_inventory={p:O[p] for p in sorted(O) if p.startswith('chicago/4d/renderers/') and p!=canonical}
assert all(B.get(p)==N.get(p) for p in renderer_inventory)
write('ALREADY-TESTED-JAIL-OWNED-RENDERER-DELTA.json',[{'path':p,'old_upstream':B.get(p),'old_tested_candidate':O.get(p),'incoming_upstream':N.get(p),'required_after_merge':'retain old tested candidate blob'} for p in renderer_inventory if O.get(p)!=B.get(p)])
assert {p for p in N if p.startswith('chicago/4d/renderers/') and p!=canonical}==set(renderer_inventory)
write('UNCHANGED-RENDERERS-EXCEPT-CANONICAL.json',renderer_inventory)
assert B.get('chicago/4d/tools/smoke_renderer.mjs')==N.get('chicago/4d/tools/smoke_renderer.mjs')
assert not any(p.startswith('chicago/4d/generators/') for p in changed)
idxpath='chicago/4d/data/sidecars/1835/index.json'
assert B[idxpath]==N[idxpath]
idx=js(OLD,idxpath);newidx=js(NEW,idxpath)
assert idx['structures']==newidx['structures']
assert 'dent_house_1823_prairie' in idx['excluded_by_date'] and 'dent_house_1823_prairie' in newidx['excluded_by_date']
assert all(row['id']!='dent_house_1823_prairie' for row in idx['structures'])
active_sidecars={f"chicago/4d/data/{row['sidecar']}":O[f"chicago/4d/data/{row['sidecar']}"] for row in idx['structures']}
assert all(B.get(p)==N.get(p) for p in active_sidecars)
write('EXPECTED-POSTMERGE-ACTIVE1835-SIDECARS.json',active_sidecars)
manifest_path='chicago/4d/assets/manifest.json';web_path='chicago/4d/assets/manifest.web.json'
MB,MO,MN=(js(r,manifest_path) for r in (BASE,OLD,NEW));WB,WO,WN=(js(r,web_path) for r in (BASE,OLD,NEW))
master_changed=[k for k in sorted(MB['assets'].keys()|MN['assets'].keys()) if MB['assets'].get(k)!=MN['assets'].get(k)]
web_changed=[k for k in sorted(WB['masters'].keys()|WN['masters'].keys()) if WB['masters'].get(k)!=WN['masters'].get(k)]
expected=['dent_house_1823_prairie__as_mapped_1904.glb','dent_house_1823_prairie__draft_1904.glb']
assert master_changed==expected and web_changed==expected,(master_changed,web_changed)
assert {k:v for k,v in MB.items() if k!='assets'}=={k:v for k,v in MN.items() if k!='assets'}
assert {k:v for k,v in WB.items() if k!='masters'}=={k:v for k,v in WN.items() if k!='masters'}
active_assets=[]
for row in idx['structures']:
 if not row.get('asset'):continue
 name=pathlib.PurePosixPath(row['asset']).name
 master='chicago/4d/assets/gltf/'+name;web='chicago/4d/assets/web/'+name
 assert B[master]==N[master]==O[master] and B[web]==N[web]==O[web],name
 assert MB['assets'][name]==MN['assets'][name]==MO['assets'][name]
 assert WB['masters'][name]==WN['masters'][name]==WO['masters'][name]
 active_assets.append({'structure_id':row['id'],'master':{'path':master,**O[master]},'web':{'path':web,**O[web]},'master_registry_row':MO['assets'][name],'web_registry_master_sha256':WO['masters'][name]})
write('EXPECTED-POSTMERGE-ACTIVE1835-ASSETS-AND-ROWS.json',active_assets)
asset_changes=[p for p in changed if p.startswith('chicago/4d/assets/')]
allowed_assets={'chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json'}|{f'chicago/4d/assets/{kind}/{name}' for kind in ('gltf','web') for name in expected}
assert set(asset_changes)==allowed_assets
all_other_assets={p:O[p] for p in sorted(O) if p.startswith('chicago/4d/assets/') and p not in allowed_assets}
assert all(B.get(p)==N.get(p)==O.get(p) for p in all_other_assets)
assert {p for p in N if p.startswith('chicago/4d/assets/') and p not in allowed_assets}==set(all_other_assets)
write('EXPECTED-POSTMERGE-ALL-OTHER-ASSET-BLOBS.json',all_other_assets)
dent=js(NEW,'chicago/4d/data/structures/dent_house_1823_prairie.json')
assert all(x['documented_range']['from']>'1835-07-01' for x in dent['phases'])
write('DENT-DATE-AND-MANIFEST-ISOLATION.json',{'structure_id':dent['id'],'phases':[{'id':p['id'],'documented_range':p['documented_range']} for p in dent['phases']],'excluded_by_date_1835':True,'active_1835_registry_count':len(idx['structures']),'active_1835_glb_count':len(active_assets),'active_1835_assetless_ids':[r['id'] for r in idx['structures'] if not r.get('asset')],'master_registry_changed_keys':master_changed,'web_registry_changed_keys':web_changed,'all_other_master_registry_rows_equal':True,'all_other_web_registry_rows_equal':True,'manifest_top_level_metadata_equal':True,'runtime_asset_selection':'scene-loader.js:297-323 reads scene/datum and sidecars/YEAR/index.structures; it selects that scene rows, not every file in assets. No renderer reference to assets/manifest.json or manifest.web.json found.'})
# Physical guards deliberately retain OLD tested Jail data. They are NOT the incoming
# bare-dev data, which lacks Jail's already-tested palisade. Changed source/catalog/
# research/Prairie records have fresh UI/native checks and are separately classified.
def global_or_1904(p):
 rel=p.removeprefix('chicago/4d/')
 return (rel=='data/liberties.json' or rel.startswith(('data/sources/','data/research/','data/jaunts/','data/reference_views/','data/components/prairie_1904/','data/sidecars/1904/')) or bool(re.match(r'data/sidecars/[^/]+/sources/',rel)) or rel=='data/structures/dent_house_1823_prairie.json')
physical={p:O[p] for p in sorted(O) if p.startswith('chicago/4d/data/') and not global_or_1904(p)}
assert not [p for p in changed if p.startswith('chicago/4d/data/') and not global_or_1904(p)]
write('EXPECTED-POSTMERGE-PROTECTED-PHYSICAL-DATA.json',physical)
smoke=blob(OLD,'chicago/4d/tools/smoke_renderer.mjs').decode().splitlines(keepends=True)
starts={int(m[1]):i for i,line in enumerate(smoke) if (m:=re.match(r'^\s*if \(stageOn\((\d+)\)\) \{',line))}
labels={5:'scene-detail/call/triangle ceilings, shadow/furniture ladder',6:'entry/chrome, Guide controls, confidence/menu persistence',7:'walker navigation/compass/map/roads/live registry positions',8:'road-aid pixel liveness and batch/material merge',9:'facade-tone pixel liveness, shadow reach/brightness',10:'flora roots/terrain, structures anchors, trees and horizon',11:'community-wide sward, marsh substrate, flowers/pop-in census'}
rows=[]
for stage in range(5,12):
 a,b=starts[stage],starts[stage+1];body=''.join(smoke[a:b])
 direct=[{'line':a+i+1,'text':line.strip()} for i,line in enumerate(smoke[a:b]) if re.search(r'fetch\(|import\(|sources|libert|jaunt|catalog',line)]
 rows.append({'part':stage,'description':labels[stage],'start_line':a+1,'end_before_line':b+1,'body_utf8_sha256':hashlib.sha256(body.encode()).hexdigest(),'direct_fetch_import_or_shared_catalog_literals':direct,'api_roots_heuristic_only':sorted(set(re.findall(r'\b(?:a|api|app)\.([A-Za-z_$][\w$]*)',body))),'operative_input_assessment':'Unchanged renderer/smoke code plus all retained 1835 physical data/assets. Global HUD release metadata and lazy Guide catalog are separately covered by fresh13 and fresh12; this is an impact judgment, not global-hash equality.'})
write('PARTS5-11-CONSUMER-REVIEW.json',{'native_smoke_blob_at_old_candidate':O['chicago/4d/tools/smoke_renderer.mjs'],'incoming_smoke_code_change':False,'parts':rows,'nonzero_transitive_shared_metadata':'Stage6 opens Guide, whose teachers() asynchronously fetches catalogs. guide-view.js:105-133 isolates updates to the teachers fold and catches catalog failures; controls are mounted separately at186-205. Fresh12 must exercise same Guide mount and cross-year handout. HUD release badge is a shared DOM consumer at boot, covered by fresh13 and boot in every new invocation. Do not claim zero transitive metadata reads.'})
coverage=[]
for p in changed:
 if p.startswith('chicago/4d/assets/') or p.startswith('chicago/4d/data/sidecars/1904/') or p=='chicago/4d/data/structures/dent_house_1823_prairie.json':parts=[14,15];why='Changed1904asset/record/catalog; fresh1904scene plus arrival/jaunt, allcurrentbootchecks.'
 elif p==canonical:parts=[13];why='Canonical release notes and generatedrelease meta; freshnotes/unread/returningvisitor.'
 elif p.endswith('/data/liberties.json') or p.endswith('/docs/LIBERTIES.md'):parts=[3,4,12,14];why='SharedLiberties/cards/Inspect/Guide/Evidence; freshUIcoverage.'
 elif '/sources/' in p or p.startswith('chicago/4d/data/jaunts/') :parts=[3,4,12,14,15];why='Sharedsourceorjauntcatalog; freshcard/Inspect/Guide/Evidence/arrival.'
 else:parts=[];why='Generatedresearch/schema/tool/prose/image-match input: currentwhole-nativecheck; anyproducedruntimeoutputmustsatisfyphysicalguardsorfreshUIclassification.'
 coverage.append({'path':p,'fresh_parts':parts,'also_common_boot':True,'why':why})
write('CURRENT-DELTA-COVERAGE-ASSIGNMENT.json',coverage)
write('AUTHOR-POSTMERGE-GUARDS-REQUIRED.json',{'status':'FUTURE_HEAD_NOT_YET_ATTESTED','old_tested_candidate':OLD,'new_upstream':NEW,'requirements':['After authored resolution and supported re-derivation, compare actual stagedSOURCE+working files with every EXPECTED-POSTMERGE inventory; equality means path+mode+content, not only count. Keep already-tested Jail physical paths from8cd, not baredev8f.','Whole nativecheck/preflight PASS with requiredreaders/base, actualnativepublish, all44canonical audits, and no unmerged/index/source drift. Nativecheck is required before integration codecommit.','Entire renderer tree exceptcanonicalJS and whole tools/smoke_renderer.mjs must match8cd; if smokechanged, proveeachreusedbody AND allsharedhelpers unchanged or rerun affectedparts.','All685active master+WEBbytes and their registrysemanticrows mustmatch8cd; official ignoredGlessner three-file pinnedpackage mustremainexact andcheckpublished/protectedsource proofs current.','All active sidecars, 1835scene/index/terrain/datum/props/physicaldata ininventory mustmatch8cd. Compiler may rewrite globalcatalogs, sourcecards and1904records; enumerateeverynewchangedpath and assignfreshcoverage, never silentlybroadenallowedpaths.','Published physical delivery must be tied tocurrentSOURCE by check_published pluspack_boot_sidecars/defer_household_notes semanticchecks. ActualHTTPnewhead/build and activeWEB/protecteddata signatures mustmatch. No stale browser cache/old server tree.','Capture currentglobalhash withdirtyfalse andseparatechangeloghash honestly; globaldifference remainsqualified andisNOTreportedasequality. RetainoldrawactualPASS5-11 with exactoldcandidate/viewport/publishedproof.','Run allcurrent selectedparts1-2,3-4,12,13,14,15 on BOTHviewports againstactualpublishednewhead, nativeassertionsunchanged, zeroerrors; inspect terminalactualresults. Missing/running/failed isnotPASS.','Any changedoperativeinput in5-11, unexplainedpublished/indexdrift, or knownnewfailure invalidates thisnarrowcoverage decision; rerun affectedparts orfullmatrix.','PRbody names oldfullproofhead andcurrentintegrationchecks separately; no latestheadwhole18PASS claim. Normalready/merge onlywithrequiredcurrentchecks andexpectedHEAD.'],'not_a_waiver':'Thispacketdoesnotpassthefuturemerge,nativegate,anysmokeororiginalimageticket. Itpricesandexplainsscopeanddefinescheckswhichmustactuallypass.'})
summary={'status':'CLOSED_READ_ONLY_UPSTREAM_IMPACT_AUDIT_PASS_WITH_FUTURE_GUARDS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_tested_jail_candidate':OLD,'upstream_before':BASE,'incoming_upstream':NEW,'upstream_changed_paths':len(changed),'renderer_changed_paths':runtime_changes,'renderer_protected_paths':len(renderer_inventory),'active1835_registry_rows':len(idx['structures']),'active1835_master_and_web_pairs_equal':len(active_assets),'active1835_sidecars_no_incoming_change':len(active_sidecars),'all_other_asset_paths_protected':len(all_other_assets),'physical_data_paths_no_incoming_change':len(physical),'fresh_selected_parts':[1,2,3,4,12,13,14,15],'viewports':['desktop','mobile'],'reuse_parts':[5,6,7,8,9,10,11],'global_hash_equality_claimed':False,'future_merged_head_validated':False,'source_index_refs_or_runtime_files_written':False,'evidence_only_files_written':True}
write('SUMMARY.json',summary)
files=[]
for p in sorted(OUT.rglob('*')):
 if p.is_file() and p.name!='MANIFEST.json':files.append({'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':p.stat().st_mode&0o777})
write('MANIFEST.json',{'status':summary['status'],'files':files})
print(json.dumps({'summary':summary,'manifest':str(OUT/'MANIFEST.json'),'manifest_sha256':hashlib.sha256((OUT/'MANIFEST.json').read_bytes()).hexdigest(),'payload_bytes':sum(f['bytes'] for f in files)},indent=2))
