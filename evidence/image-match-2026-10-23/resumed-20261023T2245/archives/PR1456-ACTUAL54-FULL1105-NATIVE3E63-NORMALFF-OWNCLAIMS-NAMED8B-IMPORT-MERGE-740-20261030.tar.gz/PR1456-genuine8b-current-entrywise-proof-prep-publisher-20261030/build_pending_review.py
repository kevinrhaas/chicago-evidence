"""Prepared only. Actual staged8b entrywise review and PENDING root manifest; never sourcegate/commit/push."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess
R=Path('/workspace/t2372-parallel-native-20261030');A=R/'chicago/4d';TIP='8b4e98207c1afcff4878239cd700379447218cfb';BASE='54e4004add7ab5208d71a51282c008cda6e7edad';ORIGINAL='3746b23bf1298c34a29946b4cdb6ee2d98abff8f';DEP='40453bde8ba1812925d61fef118782a30323f98e';RIGHTS='chicago/4d/tools/rights_derivation_baseline.json'
OLD=Path('/workspace/PR1456-current37-school-clone-integration-first-fort-20261030');OLD_M=Path('/workspace/PR1456-root-approved-54-integration-20261030.json');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');sha=lambda b:hashlib.sha256(b).hexdigest();pf=lambda p:sha(Path(p).read_bytes())
def g(*a):return subprocess.check_output(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false',*a],env=E)
def raw(c,p):return g('show',c+':'+p)
def j(c,p):return json.loads(raw(c,p))
def entries(c=None):
 out={}
 for row in (g('ls-tree','-rz',c)if c else g('ls-files','--stage','-z')).split(b'\0'):
  if not row:continue
  meta,p=row.split(b'\t');x,y,z=meta.decode().split();assert c or z=='0';out[p.decode()]=dict(mode=x,blob=z if c else y)
 return out
def rows_by_id(d,key):
 rs=d[key];out={r['id']:r for r in rs};assert len(out)==len(rs);return out
def proof(path):return dict(path=str(path),sha256=pf(path))
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--checkpoint54',required=True,type=Path);a.add_argument('--owner-result',required=True,type=Path);a.add_argument('--repair-map',required=True,type=Path);a.add_argument('--message-file',required=True,type=Path);a.add_argument('--output',required=True,type=Path);a=a.parse_args();os.sched_setaffinity(0,{2});os.nice(19)
 cp=json.loads(a.checkpoint54.read_bytes());SOURCE=cp['head'];assert cp['status']=='ACTUAL_PR1456_GENUINE54_NATIVE_TWO_PARENT_CHECKPOINT_PASS'and cp['parents']==[ORIGINAL,BASE]and cp['tree']=='444505c7ca5a22c7e90c653a10f579630be6978c'
 assert g('rev-parse','HEAD').decode().strip()==SOURCE and g('rev-parse','MERGE_HEAD').decode().strip()==TIP and not g('ls-files','-u')and not g('diff','--name-only')and not g('ls-files','--others','--exclude-standard')
 owner=json.loads(a.owner_result.read_bytes());assert owner['status']=='ACTUAL_PR1456_NAMED8B_TWO_NATIVE_OWNERS_TWO_LAPS_FIXED_POINT_AND1904_CHECKS_PASS'and owner['source_head']==SOURCE and owner['merge_parent']==TIP and owner['second_lap_moved_nothing']is True and len(owner['steps'])==6
 for row in owner['steps']:
  rr=json.loads(Path(row['reaper']).read_bytes());assert row['exit']==rr['command_exit']==0 and rr['all_children_reaped']is True and not rr['leftover_cleanup']and pf(row['reaper'])==row['reaper_sha256']
 repair=json.loads(a.repair_map.read_bytes());fix=repair['new_owned_path_sha256'];assert set(fix)=={'chicago/4d/tools/smoke_renderer.mjs','chicago/4d/renderers/web/js/yard.js'}
 for row in repair['proof_files']:assert pf(row['path'])==row['sha256']
 o=a.output.resolve();assert not o.exists()and o.is_relative_to('/workspace')and not o.is_relative_to(R);o.mkdir();save=lambda n,d:(o/n).write_text(json.dumps(d,indent=2)+'\n')
 tree=g('write-tree').decode().strip();ix=entries();can=entries(TIP);m=json.loads(OLD_M.read_bytes());own=dict(m['owned_original']['reviewed_paths']);assert RIGHTS in own;del own[RIGHTS];mixed=set(m['canonical_foreign_entrywise']['mixed_paths'])|{RIGHTS};deps=m['required404_dependency_paths'];protected=m['protected404_performance_paths'];allowed=set(own)|mixed|set(deps)|set(fix);assert len(own)==49 and len(mixed)==14 and len(allowed)==67
 allsha={}
 for rel,row in ix.items():
  p=R/rel
  if row['mode']=='120000':assert p.is_symlink();b=os.readlink(p).encode()
  else:assert row['mode']in ['100644','100755']and p.is_file()and not p.is_symlink()and bool(p.stat().st_mode&0o111)==(row['mode']=='100755');b=p.read_bytes()
  assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['blob'],rel;allsha[rel]=sha(b)
 foreign_bad=[p for p in set(ix)|set(can)if p not in allowed and ix.get(p)!=can.get(p)];assert not foreign_bad,foreign_bad
 canonical_delta={p for p in set(ix)|set(can)if ix.get(p)!=can.get(p)};assert canonical_delta==allowed,(sorted(canonical_delta-allowed),sorted(allowed-canonical_delta))
 for p,h in own.items():assert allsha[p]==h==sha(raw(ORIGINAL,p))==sha(raw(SOURCE,p)),p
 for p,h in {**deps,**protected}.items():assert allsha[p]==h==sha(raw(DEP,p)),p
 for p,h in fix.items():assert allsha[p]==h,p
 old_asset=json.loads((OLD/'ENTRYWISE-ASSET-REGISTRY-PROOF.json').read_bytes());assets={}
 for p,key in [('chicago/4d/assets/manifest.json','assets'),('chicago/4d/assets/manifest.web.json','masters')]:
  current=json.loads((R/p).read_bytes());prior=j(SOURCE,p);canonical=j(TIP,p);ids=set(old_asset[p]['own_row_ids']);assert set(current[key])==set(canonical[key]);assert all(current[key][k]==(prior[key][k]if k in ids else canonical[key][k])for k in current[key]);assert {k:v for k,v in current.items()if k!=key}=={k:v for k,v in canonical.items()if k!=key}
  assets[p]=dict(own_row_ids=sorted(ids),own_count=len(ids),own_rows_exact_actual54CP=True,foreign_count=len(current[key])-len(ids),foreign_rows_exact8b=True,IDs_and_topmetadata_exact8b=True,sha256=allsha[p])
 p='chicago/4d/data/liberties.json';oldlib=json.loads((OLD/'ENTRYWISE-LIBERTY-PROOF.json').read_bytes());ids=set(oldlib['owned_original_changed_ids']);cur=json.loads((R/p).read_bytes());prior=j(SOURCE,p);canonical=j(TIP,p);cr=rows_by_id(cur,'liberties');pr=rows_by_id(prior,'liberties');ca=rows_by_id(canonical,'liberties');assert set(cr)==set(ca)|ids
 assert all(cr[k]==(pr[k]if k in ids else ca[k])for k in cr);assert cur['count']==len(cr);assert {k:v for k,v in cur.items()if k not in ['liberties','count']}=={k:v for k,v in canonical.items()if k not in ['liberties','count']}
 targets=oldlib['target_relevant_ids'];target_deltas=[k for k in targets if cr[k]!=pr[k]];assert all(k not in ids and cr[k]==ca[k]for k in target_deltas)
 liberties=dict(own4_IDs=sorted(ids),own_rows_exact_actual54CP=True,all_foreign_rows_exact8b=True,target_relevant_IDs=targets,target_relevant_changes_from54CP_inherited_exact8b=target_deltas,topmetadata_except_count_exact8b=True,count=len(cr),sha256=allsha[p])
 p='chicago/4d/data/sidecars/1835/sources/index.json';ids=set(json.loads((OLD/'ENTRYWISE-SOURCE-INDEX-PROOF.json').read_bytes())['own_changed_source_IDs']);cur=json.loads((R/p).read_bytes());prior=j(SOURCE,p);canonical=j(TIP,p);cr=rows_by_id(cur,'sources');pr=rows_by_id(prior,'sources');ca=rows_by_id(canonical,'sources');assert set(cr)==set(ca)and all(cr[k]==(pr[k]if k in ids else ca[k])for k in cr);assert {k:v for k,v in cur.items()if k!='sources'}=={k:v for k,v in canonical.items()if k!='sources'}
 sources=dict(own5_IDs=sorted(ids),own_rows_exact_actual54CP=True,foreign_rows_exact8b=True,foreign_count=len(cr)-len(ids),all_source_IDs_and_topmetadata_exact8b=True,sha256=allsha[p])
 canonical=j(TIP,RIGHTS);prior=j(SOURCE,RIGHTS);base=j(BASE,RIGHTS);cur=json.loads((R/RIGHTS).read_bytes());ids={k for k in set(prior['entries'])|set(base['entries'])if prior['entries'].get(k)!=base['entries'].get(k)};incoming={k for k in set(canonical['entries'])|set(base['entries'])if canonical['entries'].get(k)!=base['entries'].get(k)}
 assert not(ids&incoming),(ids&incoming);expected=dict(canonical['entries'])
 for k in ids:
  if k in prior['entries']:expected[k]=prior['entries'][k]
  else:expected.pop(k,None)
 assert cur['entries']==expected and {k:v for k,v in cur.items()if k!='entries'}=={k:v for k,v in canonical.items()if k!='entries'}
 rights=dict(original_own_changed_keys=sorted(ids),incoming_foreign_changed_keys=sorted(incoming),own_and_foreign_disjoint=True,own_exact_actual54CP_and_all_foreign_exact8b=True,topmetadata_exact8b=True,sha256=allsha[RIGHTS])
 libs=[]
 for row in json.loads((OLD/'LIBRARY-FIVE-CURRENT-ENTRYWISE-AUTHORITY.json').read_bytes())['rows']:
  p=row['path'];assert (R/p).read_bytes()==raw(SOURCE,p)==raw(ORIGINAL,p)and raw(TIP,p)==raw(BASE,p);libs.append(dict(path=p,whole_exact_actual54CP_and_original3746=True,foreign8b_baseline_exact54=True,sha256=allsha[p]))
 docs={};old_doc=json.loads((OLD/'DOCS-AND-404-DEPENDENCY-COMPOSITION.json').read_bytes())
 for p in ['chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md']:
  original=old_doc[p];prefix=raw(DEP,p)[:original['prefix_bytes']];suffix=raw(SOURCE,p)[-original['original_own_suffix_bytes']:];body=raw(TIP,p);assert sha(prefix)==original['prefix_sha256']and sha(suffix)==original['original_own_suffix_sha256']and body==raw(BASE,p)and (R/p).read_bytes()==prefix+body+suffix
  docs[p]=dict(construction='exact40453prefix + exact8bbody + exactoriginal3746appendednotes',prefix_sha256=sha(prefix),canonical_body_sha256=sha(body),own_suffix_sha256=sha(suffix),postimage_sha256=allsha[p],invalid_UTF8_preserved_as_raw_bytes=True)
 forecast=json.loads(Path('/workspace/PR1456-genuine54-publication-prep-first-fort-20261030/actual4445-vs-named8b/RESULT.json').read_bytes());forecast_rows={r['path']:r for r in forecast['native_content_results']}
 for p in ['chicago/4d/docs/LIBERTIES.md',RIGHTS]:assert allsha[p]==forecast_rows[p]['native_output_sha256']and forecast_rows[p]['native_exit']==0
 staged={p.decode()for p in g('diff','--cached','--name-only','-z').split(b'\0')if p};staged_map={p:allsha.get(p)for p in sorted(staged)}
 summary=dict(status='ACTUAL_STAGED_NAMED8B_ENTRYWISE_OWN_FOREIGN_SOURCE_REVIEW_READY_FOR_ROOT_REVIEW',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_head=SOURCE,merge_parent=TIP,tree=tree,all_tracked_count=len(ix),all_tracked_working_modes_and_blobs_exact_index=True,whole_own49_exact_actual54CP_and_original3746=True,all_nonallowed_mode_blob_deletions_exact8b=True,foreign_bad=foreign_bad,canonical_delta_exact67_allowed_paths=True,staged_delta_count=len(staged),assets=assets,liberties=liberties,source_index=sources,rights_baseline=rights,library5=libs,docs=docs,all4performance_exact40453=True,new_validation_fixes=fix,owner_result=proof(a.owner_result),checkpoint54=proof(a.checkpoint54),repair_proof_map=proof(a.repair_map),no_source_gate_commit_phone_publication_CI_merge_claimed=True)
 save('ALL-TRACKED-FINAL-SHA256.json',allsha);save('ENTRYWISE-FINAL-REVIEW.json',summary);save('STAGED-PATHS.json',staged_map)
 actual_alloc=int(subprocess.check_output(['du','-s','-B1',str(R)]).split()[0]);projected=actual_alloc+64*1048576;assert projected<=4600000000
 price=dict(native_transient_reserve_bytes=1557139456,publication_reserve_bytes=512090112,ignored_source_reserve_bytes=0,ticket_reserve_bytes=0,import_reserve_bytes=0,log_temp_reserve_bytes=100663296,guard_reserve_bytes=33554432,clone_projected_allocation_bytes=projected,clone_phase_limit_bytes=4600000000)
 save('CURRENT-RESOURCE-PRICE.json',dict(status='ACTUAL_POST_IMPORT_NATIVE_OWNER_STAGE_RESOURCE_PRICE',source_allocation=actual_alloc,clone_growth_reserve=64*1048576,prior54native1105PASS_hash=cp['source_gate_sha256'],source_and_ignored_dependencies_already_materialized_by54gate=True,publication_upper_reserved_even_though_existing=True,one_native_DRIFT_scratch_inherited_unchanged8b_source=True,prior_funding_price=proof(OLD/'NATIVE-GATE-RESOURCE-PRICE.json'),price=price,workspace_free=shutil.disk_usage('/workspace').free,shared_TMP_free=shutil.disk_usage('/tmp').free))
 m['status']='PREPARED_PR1456_GENUINE8B_INTEGRATION_STAGED_ROOT_REVIEW_PENDING';m['root_reviewed']=False;m['source_head']=SOURCE;m['merge_parent']=TIP;m['tree']=tree;m['expected_steps']=1108;m['staged_paths']=staged_map;m['source_config_sha256']=pf(R/'.git/config');m['owned_original']['reviewed_paths']=own;m['owned_original']['proof_files']=[proof(o/'ENTRYWISE-FINAL-REVIEW.json')];m['canonical_foreign_entrywise'].update(canonical_commit=TIP,mixed_paths={p:allsha[p]for p in sorted(mixed)},proof_files=[proof(o/'ENTRYWISE-FINAL-REVIEW.json')]);m['new_owned_path_sha256']=fix;m['new_owned_path_proof_files']=repair['proof_files'];m['checkpoint_message_sha256']=pf(a.message_file);m['resource_price']={**price,'proof_files':[proof(o/'CURRENT-RESOURCE-PRICE.json')]};m['qualification_limits']='Actual staged8b source reviewed mechanically, root direct review/approval still pending. No finalnative sourcegate/CP/phone/BOTH/publication/CI/merge claimed.'
 save('ROOT-REVIEW-PENDING-MANIFEST.json',m);save('BINDING.json',dict(head=SOURCE,merge_parent=TIP,tree=tree,config=m['source_config_sha256'],refs=sha(g('for-each-ref','--format=%(refname) %(objectname)')),index=sha(g('ls-files','--stage','-z')),flags=sha(g('ls-files','-v','-z')),all_tracked_sha256=pf(o/'ALL-TRACKED-FINAL-SHA256.json'),staged_paths_sha256=pf(o/'STAGED-PATHS.json'),no_conflicts_or_unstaged_or_untracked=True))
 print(json.dumps(dict(status=summary['status'],tree=tree,staged_delta_count=len(staged),whole_own49=len(own),mixed14=len(mixed),allowed67=len(allowed),pending_manifest=str(o/'ROOT-REVIEW-PENDING-MANIFEST.json'),pending_manifest_sha256=pf(o/'ROOT-REVIEW-PENDING-MANIFEST.json')),indent=2))
if __name__=='__main__':main()
