# Actual staged8b own/foreign entrywise proof and PENDING review — prepared only

No helper executed during preparation. Root authorizes execution ONLY after its actualnormal54CP+normalFFsave, genuine8bimport/merge, sixnativeownerchecks, exactreviewedtwofixapplication, and staging. This helper generates proofs/root-review-PENDINGmanifest and ordinarynativewrite-tree objects; it never sourcegates/commits/pushes/phones/merges.

Command after actualstaging:

    source /workspace/shared/resume-chicago-env.sh
    nice -n 19 taskset -c 2 python -B CAPSULE/build_pending_review.py --checkpoint54 ACTUAL54CP_RESULT --owner-result ACTUAL_NATIVE_OWNERS_RESULT --repair-map ROOT_ACCEPTED_TWO_FIX_MAP_JSON --message-file EXACT_FINAL_NATIVE_MESSAGE --output NEW_EXTERNAL_OUTPUT

Repairmap JSON has `new_owned_path_sha256` for EXACTtools/smoke_renderer.mjs andrenderers/web/js/yard.js and `proof_files` absolute path/SHA records of rootacceptedfrozen8654repair and7813fullrecordproof. Currentstaged/workingbytesmustmatchthosereviewedSHAs.

Source HEAD=actual54CP, MERGE_HEAD8b, no conflict/unstaged/untracked. Every tracked workingfilemode/blob is rehashed againstnativeindex; allindexed modes/blobs/deletions outsideexplicitclasses equal8b. Exactly67canonicaldelta paths expected. Correct finalclasses are49wholeown/14mixed/2performance dependencies/2validationrepairs: rights_derivation_baseline.json moves fromoldwholeown50 into mixed to preserve newforeign8bHibbardrows. The earliergateREADME examples50/13 are dated54counts; actualgatecode accepts the properdisjointvariableclasses.

Concreteentrywisechecks: MASTERown353/WEBown3 exactactual54CP, allotherrows andIDs/topmetadataexact8b; four original libertyrows exactactual54CP/allforeignexact8b andcount/topmetadata; five source-indexrowsexactactual54CP/allforeign/IDs/topmetadataexact8b; rightsbaselineownkeydeltasfrom54exactactual54CP/allforeign8b and disjointincomingforeignkeys; allfive libraryfileswholeexactoriginal3746/actual54CP with8bforeignbaselineunchanged54; rawSTATUS/ROADMAPexact404prefix+8bbody+originalappendedsuffix, invalidUTF8preserved. LIBERTIES.md/rightsbaselineexactcleanforecastnative3waybytes. Fourperformancefilesexact404, twonewfixpostimagesexactrootacceptedmap. All49remainingwholeownfilesexactoriginal3746andactual54CP.

Results include fullalltrackedSHAmap, compactconcreteENTRYWISE-FINAL-REVIEW, actualstageddelta map, actualnative tree/index/flags/ref/configbinding and currentresourceprice. Price usesactualcloneallocation+64MiBgrowth≤4.6GB; single1.557GBscratch reserve,512MBconservativepublicationreserve,96MiBlogs/32MiBguard; newignoredsource/import/ticketremainingprice0 because54nativePASSmaterializedthem and8bimportsarealreadyapplied. Actualworkfree/sharedTMPrecorded. Root must assessprice andfundingbeforeapproval; helperdoesnotrunanygate.

Manifest remains statusPREPARED_PR1456_GENUINE8B_INTEGRATION_STAGED_ROOT_REVIEW_PENDING/root_reviewedfalse. It cannot authorize preparedgate untilrootdirectlyreviews andwrites a SEPARATE approvedmanifest with ROOT_REVIEWED_PR1456_GENUINE8B_INTEGRATION_STAGED/root_reviewedtrue. Existingfrozenpendingproofsmustnotbeedited. source_head=actual54CP,merge_parent8b,actualtree/stagedmap/bytes/config/messageSHA; expected1108fromnative3additionalcalls.

Freezeactualoutputwiththeexactpostimages/restorationmapsandbankinGitHubcheckpointbeforelongruntime ifneeded. Allpublicincoming8bobjectpayloads are replaceablefromimmutableGitHub; originalsourceproofs/WIPmustremainrecoverable.
