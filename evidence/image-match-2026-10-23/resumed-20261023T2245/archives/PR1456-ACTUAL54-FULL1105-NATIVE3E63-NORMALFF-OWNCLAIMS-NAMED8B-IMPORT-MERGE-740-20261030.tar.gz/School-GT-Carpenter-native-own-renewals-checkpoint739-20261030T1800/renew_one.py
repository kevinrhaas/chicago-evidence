from pathlib import Path
import os,sys,json,hashlib,subprocess,urllib.request,datetime
O=Path(__file__).parent;R=Path('/workspace/chicago-tickets');A=Path('/workspace/chicago');G='/usr/local/bin/git';P=json.loads((O/'PLAN.json').read_text());tid=sys.argv[1];row=next(x for x in P['tickets'] if x['id']==tid)
assert sys.argv[2:]==['--root-phase','native-live-own-original-claim-renewal-readonly-source-gate']
def floor():
 for p,n in [('/workspace',545259520),('/tmp',1800000000)]:
  v=os.statvfs(p);assert v.f_bavail*v.f_frsize>=n,('FLOOR',p,v.f_bavail*v.f_frsize,n)
def get(url):return json.load(urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Chicago-exact-live-own-renewal'}),timeout=30))
def remote():
 h=get('https://api.github.com/repos/kevinrhaas/chicago-tickets/git/ref/heads/main')['object']['sha'];b=urllib.request.urlopen('https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+h+'/'+row['path'],timeout=30).read();assert hashlib.sha256(b).hexdigest()==row['sha256'],'Own target changed remotely; never steal';prs=get('https://api.github.com/repos/kevinrhaas/chicago/pulls?state=open&per_page=100');assert not any(tid in x['title']+' '+x['head']['ref'] for x in prs),'New target PR exists; stop/coordinate';return h,b
floor();assert datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(row['expires_at']),'LIVE-only plan expired; stop and reassess exact ownership';head,before=remote();D=O/tid;D.mkdir(exist_ok=True);(D/'BEFORE.md').write_bytes(before);(D/'ACTIVE.json').write_text(json.dumps(row)+'\n')
# Wrapper scoped only to this new task, existing full metadata clone and isolated app.
B=D/'bin';B.mkdir(exist_ok=True);shim='''#!/usr/bin/env python3
from pathlib import Path
import os,sys,subprocess,json,hashlib,urllib.request
O=Path(__file__).resolve().parent.parent;R=Path('/workspace/chicago-tickets');A=Path('/workspace/chicago');G='/usr/local/bin/git';a=sys.argv[1:];b=a[:];cwd=Path.cwd().resolve();row=json.loads((O/'ACTIVE.json').read_text());env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
if b[:1]==['-C']:cwd=Path(b[1]).resolve();b=b[2:]
assert cwd==R or cwd.is_relative_to(A),('FORBIDDEN_CONTEXT',cwd)
def get(x):return subprocess.check_output([G,'-C',str(cwd),*x],env=env).decode().strip()
def record(x):
 with (O/'GIT-AUDIT.jsonl').open('a') as f:f.write(json.dumps({'args':a,'cwd':str(cwd),**x})+'\\n')
if cwd==R:
 if b[:1]==['pull']:
  assert b in [['pull','--rebase','--quiet','origin','main'],['pull','--rebase','-q','origin','main']]
  assert get(['status','--porcelain'])==''
  q=subprocess.run([G,*a],env=env);assert q.returncode==0;head=get(['rev-parse','HEAD']);data=(R/row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'],'Target changed after native pull'
  (O/'BASE.json').write_text(json.dumps({'head':head})+'\\n');sys.exit(0)
 if b[:1]==['push']:
  assert b==['push','-q','origin','HEAD:main'],b
  base=json.loads((O/'BASE.json').read_text())['head']
  public=json.load(urllib.request.urlopen(urllib.request.Request('https://api.github.com/repos/kevinrhaas/chicago-tickets/git/ref/heads/main',headers={'User-Agent':'Chicago-exact-own-renewal-prepush-CAS'}),timeout=30))['object']['sha']
  assert public==base,'Public main changed before push; refuse rather than rebase unknown WIP'
  received=urllib.request.urlopen('https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+public+'/'+row['path'],timeout=30).read();assert hashlib.sha256(received).hexdigest()==row['sha256'],'Own target changed before push; never steal'
  plan=json.loads((O.parent/'PLAN.json').read_text())
  for path,h in plan['review_four'].items():
   r=urllib.request.urlopen('https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+public+'/'+path,timeout=30).read();assert hashlib.sha256(r).hexdigest()==h,'Review four changed; abort'
  paths=get(['diff','--name-only',base,'HEAD']).splitlines();assert paths==[row['path']],paths
  old=get(['show',base+':'+row['path']]);new=get(['show','HEAD:'+row['path']]);drop=lambda s:'\\n'.join(x for x in s.splitlines() if not x.startswith(('claimed_at:','claimed_by:')));assert drop(old)==drop(new),'Foreign target body/fields altered'
  assert row['claimed_at'] in old and row['claimed_by'] in old
  record({'normal_FF_guard':'PASS','base':base,'head':get(['rev-parse','HEAD']),'changed_paths':paths})
  q=subprocess.run([G,*a],env=env);record({'push_exit':q.returncode});sys.exit(q.returncode)
 assert b[0] in ['rev-parse','status','diff','log','add','commit','rebase','reset','ls-files','show','symbolic-ref','cat-file'],b
 os.execve(G,[G,*a],env)
assert b[0] in ['rev-parse','status','diff','log','for-each-ref','ls-tree','ls-remote','show','cat-file','symbolic-ref'],('No app writes/fetch/marker pushes',b)
os.execve(G,[G,'-c','protocol.https.allow=always',*a],env)
''';(B/'git').write_text(shim);(B/'git').chmod(0o700)
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PATH=str(B)+':'+os.environ['PATH'],CHICAGO_TICKETS_DIR=str(R),NODE_DISABLE_COMPILE_CACHE='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(D),GIT_AUTHOR_NAME='polecat-steward',GIT_AUTHOR_EMAIL='steward@polecat.live',GIT_COMMITTER_NAME='polecat-steward',GIT_COMMITTER_EMAIL='steward@polecat.live');env.pop('GITHUB_ACTIONS',None)
tool=A/'chicago/4d/tools/ticket.mjs';assert hashlib.sha256(tool.read_bytes()).hexdigest()=='34c9f9db3cd6f1091ef075ad1bf77874a9e3f064e9e3ea4e633dc6d5569c5e90'
def native(force=False):
 floor();remote();cmd=['taskset','-c','2','node',str(tool),'claim',tid,'--by',row['native_by']]+(['--force'] if force else []);q=subprocess.run(cmd,cwd=A/'chicago/4d',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(D/('NATIVE-LIVE-OWN-FORCE.log' if force else 'NATIVE-NO-FORCE.log')).write_text(q.stdout);return q
q=native()
if q.returncode:
 # Only reviewed historical OUR branches or our exact current live claim may cause this narrow exception.
 allowed={'T-2372':set(),'T-2376':{'steward/t2385-t2376-picture-correction-20261029','verification/t2376-cb93-6a61ab6eca1f-20261026','verification/t2376-pr1328-0c78d17b22cf-20261026'},'T-2382':{'steward/t2382-carpenter-picture-currentdev','verification/t2382-f311c2a9b762-source-cards-20261026'}}[tid]
 branches={x.strip() for x in q.stdout.splitlines() if x.startswith('  ') and x.strip().startswith(('steward/','verification/','claude/','agent/'))};assert branches<=allowed,('Unknown rival branch; do not force',branches-allowed)
 assert 'already being worked' in q.stdout or ('claimed' in q.stdout.lower() and row['claimed_by'] in q.stdout),q.stdout
 q=native(True)
assert q.returncode==0 and (tid+' claimed') in q.stdout,q.stdout
newhead=subprocess.check_output([G,'-C',str(R),'rev-parse','HEAD']).decode().strip();after=(R/row['path']).read_bytes();u='https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+newhead+'/'+row['path'];assert urllib.request.urlopen(u,timeout=30).read()==after
base=json.loads((D/'BASE.json').read_text())['head'];paths=subprocess.check_output([G,'-C',str(R),'diff','--name-only',base,newhead]).decode().splitlines();assert paths==[row['path']]
f=dict(line.split(':',1) for line in after.decode().split('---',2)[1].splitlines() if ':' in line);dt=datetime.datetime.fromisoformat(f['claimed_at'].strip().replace('Z','+00:00'));floor();result={'status':'ACTUAL_NATIVE_LIVE_SAME_OWNER_RENEWAL_NORMAL_FF_PASS','ticket':tid,'head':newhead,'claim_at':dt.isoformat(),'expires':(dt+datetime.timedelta(hours=3)).isoformat(),'immutable_url':u,'only_fields_changed':['claimed_at','claimed_by'],'no_primary_Git_or_app_marker_operations':True,'no_foreign_claim_steal':True};(D/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
