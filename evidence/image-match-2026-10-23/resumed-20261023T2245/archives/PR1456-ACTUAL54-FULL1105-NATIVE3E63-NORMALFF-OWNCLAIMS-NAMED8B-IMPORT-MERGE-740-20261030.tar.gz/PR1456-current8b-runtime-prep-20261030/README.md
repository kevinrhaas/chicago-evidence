# Final PR1456 actual8b phone and native stages2-3 BOTH — prepared only

No controller/helper, browser, meter, test, source, index, config, ref, publish or API action executed here. Source is the ordinary isolated /workspace/t2372-parallel-native-20261030 checkout. Root must review this frozen capsule and create a SEPARATE concrete root-approved plan only after actual final8b gate and checkpoint receipts exist. Future54CP/finalhead/tree are unknown; the template is false/pending and cannot execute.

The intermediate54 phone is skipped. These controllers accept only finalparents[ACTUAL54CP,8b4e98207c1afcff4878239cd700379447218cfb]. Actual54CP must independently be the real native commit whose parents are[3746b23b,54e4004] and whose real tree matches its receipt; normal54CP is accepted without requiring restart-recovery flags. Final8b sourcegate must have status ACTUAL_PR1456_GENUINE8B_FULL_SOURCE_PASS, exit0, allguards true, exact native expected1108(or actualmanifest count)footer, publish in timings and NEW actual sourcecheck reaper exit0/allreaped/no cleanup. The final genuine nativeCP status is ACTUAL_PR1456_GENUINE8B_NATIVE_TWO_PARENT_CHECKPOINT_PASS; allactualfilepaths/SHAs, manifest/rootreview, parent/tree/branch, sourcegate links, stagedmap and three NEWnativePRquestion reapers are joined strictly. The old interrupted54 gate cannot masquerade as final8b.

## Concrete root plan

Copy ROOT-PLAN-TEMPLATE-NOT-APPROVED.json OUTSIDE this frozen folder. Fill every exact actual path/SHA, actual source54CP/head/tree, root-reviewed finalmanifest, actual finalgate/CP/log/reaper/timings and three CPquestion reapers. runtime_capsule points to THIS CLOSED-MANIFEST and its actualSHA. Root sets root_approved true and the mode-specific exact status:

- Phone: ROOT_APPROVED_PR1456_CURRENT8B_PHONE_RUN; CPU_affinity[2], nice19.
- Smoke: ROOT_APPROVED_PR1456_CURRENT8B_SMOKE23_BOTH_RUN; root-scheduled CPUs (normally[0,1,3,4]), nice19.

Each plan has its own new external output. The helper requires the caller's explicit root-planSHA; it never fills unknown identities or authorizes itself. It checks every frozen capsule member before any runtime. Use no mutable source/ref/site/config operations while that actual checkout is leased for runtime; API-only checkpoint publication can proceed independently if it preserves all local refs.

## Shared actual-source guards

Exact actualHEAD/tree/parents/branch, canonical cached8b ref, clean source/index/ref/config, complete stageddelta from54CP, allown/mixed source maps, all4performance bytes independently equal resident40453 Git blobs, and both root-reviewed repair bytes are bound before/after. Allcurrent source rendererJS, native meter/smoke/projector tools, scenes/registries and original4MASTER/WEB are hashed; every published file is SHA-bound. Original4 WEBs and native/published sidecars must remain exactaccepted3746 bytes. Household notes follow the exact native split (full households still ship beside slim boot records), not a false source=published assertion. Changelog follows native projection: authoredfile exactat site/js/changelog.js, native WALK_SHIM exactat walk/js/changelog.js. No root alias, fixture/model substitute or private profile is used. Sourcebuild version can truthfully name54CP because native check publishes the exact final8bstagedtree before commit; the binding labels this explicitly rather than restamping it.

Workspace512MiB and sharedTMP1.8GB continuing floors plus128MiB entryreserve and root's <=4.6GBclonephasecap remain. Owned short TMPs are /workspace/p1456-p8b and /workspace/p1456-s23; each must be initially absent. They are retained after closure for root's exact0FD inventory/cleanup. Raw failures and reapers survive.

## Phone execution after root review

    source /workspace/shared/resume-chicago-env.sh
    nice -n 19 python -B /workspace/PR1456-current8b-runtime-prep-20261030/phone.py --root-plan ACTUAL_ROOT_PHONE_PLAN --root-plan-sha256 ACTUAL_PLAN_SHA --output EXACT_PLAN_OUTPUT --execute

Actual nativecommand is unchanged node tools/measure_memory.mjs --year1904 --onlymobile --gate --no-snapshot --json OUTPUT/PHONE.json (argv uses separate flag/value tokens). One complete1904/mobile row, zero pageerrors, actualnativeexit0/allreaped/no cleanup and <=400MiB are mandatory. No prior54/404/old398MiB reading is reused. Native ceiling and meter must remain exactcanonical8b bytes. PASS status ACTUAL_PR1456_GENUINE8B_FINAL_CHECKPOINT_PHONE400_PASS applies only to that actual measurement.

## Native published2-3 BOTH execution after root review

    source /workspace/shared/resume-chicago-env.sh
    nice -n 19 python -B /workspace/PR1456-current8b-runtime-prep-20261030/smoke23.py --root-plan ACTUAL_ROOT_SMOKE_PLAN --root-plan-sha256 ACTUAL_PLAN_SHA --output EXACT_PLAN_OUTPUT --execute

Exactly TWO genuine node tools/smoke_renderer.mjs --published calls run, desktop thenmobile, native SMOKE_STAGE=2-3/SMOKE_YEAR1835 and unchanged 1280x800/390x780 viewport semantics. The nativeparser selects both parts; no assert/wait/timeout is removed. Whole native stageaudit withpositive staged+always-on counts, zero failedsummary/FAILlines, SMOKEPASS/footer, suitecompletion, zero pageerrors/vendor checks and realexit0/allchildrenreaped/nocleanup are required on BOTH. First failedviewport stops further coverage and saves honestNQ. Each log/reaper/screenshot is retained. PASS is ACTUAL_PR1456_GENUINE8B_NATIVE_PUBLISHED_STAGES23_BOTH_PASS:2actualcalls/4logicalpairs, never4individualruns, ALL15rendererparts, new503passes, or relabeling the older failedbody. Dated othercoverage acceptance and finalCI/normaldevmerge remain root's separate scoped decisions.

Preparation validation: Python AST and read-only native source/projection/schema inspection only. Frozen members immutable after handoff; any later adaptation needs a new folder/version.
