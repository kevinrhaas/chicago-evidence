"""Prepared only. Two genuine published native2-3 calls, one per viewport, on finalPR1456."""
from runtime_common import *
args, plan, out, tmp, env, guard, binding = context('smoke23')
helper = pf(Path(__file__))
common = pf(Path(__file__).with_name('runtime_common.py'))
command = ['node', 'tools/smoke_renderer.mjs', '--published']
stage = '2-3'
binding.update(command=command, helper_sha256=helper, common_sha256=common, native_stage_selector=stage, logical_parts=[2, 3], viewports=['desktop', 'mobile'], planned_real_native_calls=2, planned_logical_coverage_pairs=4, whole15part_renderer_gate_not_claimed=True)
save(out, 'BINDING.json', binding)
steps, started, pending, failure = [], [], None, None
start = time.monotonic()
try:
    for view in ['desktop', 'mobile']:
        guard()
        shots = out / view
        shots.mkdir()
        local_env = dict(env, SMOKE_VIEWPORT=view, SMOKE_YEAR='1835', SMOKE_STAGE=stage, SMOKE_TIMING='1', SMOKE_SHOTS=str(shots))
        pending = view
        started.append(view)
        save(out, 'CURRENT-CALL.json', dict(viewport=view, stage_selector=stage, started=now(), command=command, log=str(out / (view + '.log'))))
        step, reap = native(out, view, command, local_env, binding['CPU_affinity'])
        pending = None if reap['all_children_reaped'] else view
        clean = re.sub(r'\x1b\[[0-9;]*m', '', Path(step['log']).read_text(errors='replace'))
        audit = re.findall(r'^(\d+) staged-section check\(s\) \(stage 2-3 of 15\), (\d+) always-on check\(s\)$', clean, re.M)
        summary = re.findall(r'^(\d+) passed, (\d+) failed$', clean, re.M)
        label = 'desktop 1280x800' if view == 'desktop' else 'mobile 390x780'
        lines = [line for line in clean.splitlines() if re.match(r'^  pass  ', line)]
        has = lambda text: any(text in line for line in lines)
        predicates = dict(native_exit=step['exit'] == 0 and reap['command_exit'] == 0, all_children_reaped=reap['all_children_reaped'] is True, no_reaper_cleanup=not reap['leftover_cleanup'], exact_native_stage_audit=len(audit) == 1 and int(audit[0][0]) > 0 and int(audit[0][1]) > 0, native_summary_zero_failed=bool(summary) and int(summary[-1][1]) == 0, no_FAIL_lines=not bool(re.search(r'^\s*FAIL\s', clean, re.M)), native_footer_PASS=bool(re.search(r'^SMOKE PASS$', clean, re.M)), native_suite_completed=has(label + ': the suite body ran to completion'), native_zero_page_errors=has(label + ': zero page errors'), native_vendor_no_page_error=has('vendor: meshopt import raises no page error'))
        step.update(viewport=view, stage_selector=stage, logical_parts=[2, 3], predicates=predicates, passed=all(predicates.values()), native_audit_staged_checks=int(audit[0][0]) if len(audit) == 1 else None, native_audit_always_on_checks=int(audit[0][1]) if len(audit) == 1 else None, native_summary=summary[-1] if summary else None, all_children_reaped=reap['all_children_reaped'], screenshots=[dict(path=str(p), sha256=pf(p), bytes=p.stat().st_size) for p in sorted(shots.glob('*.png'))], footer=clean.splitlines()[-20:])
        steps.append(step)
        save(out, 'STEPS.json', steps)
        guard()
        if not step['passed']: raise RuntimeError('Actual native ' + view + '2-3 failed; remaining viewport not qualified')
except BaseException as error:
    failure = type(error).__name__ + ': ' + str(error)
guards_exact, guard_error = True, None
try:
    guard()
    assert pf(Path(__file__)) == helper and pf(Path(__file__).with_name('runtime_common.py')) == common
except BaseException as error:
    guards_exact, guard_error = False, type(error).__name__ + ': ' + str(error)
reaped = pending is None and all(s['all_children_reaped'] for s in steps)
passed = failure is None and guards_exact and reaped and len(started) == len(steps) == 2 and all(s['passed'] for s in steps)
save(out, 'RESULT.json', dict(status='ACTUAL_PR1456_GENUINE8B_NATIVE_PUBLISHED_STAGES23_BOTH_PASS' if passed else 'ACTUAL_PR1456_GENUINE8B_NATIVE_PUBLISHED_STAGES23_BOTH_NOT_QUALIFIED', at=now(), head=binding['head'], tree=binding['tree'], parents=binding['parents'], binding_sha256=pf(out / 'BINDING.json'), stage_selector=stage, logical_required_parts=[2, 3], actual_real_native_calls=len(started), completed_native_call_records=len(steps), started_viewports=started, qualified_logical_pairs=[dict(viewport=s['viewport'], part=p, via_one_native_grouped_call=True) for s in steps if s['passed'] for p in [2, 3]] if guards_exact else [], four_individual_runs_not_claimed=True, all15_renderer_parts_not_claimed=True, prior503_passes_or_old_failed_body_not_relabelled=True, all_children_reaped=reaped, pending_or_unclosed_call=pending, guards_before_after_exact=guards_exact, guard_error=guard_error, failure=failure, total_actual_seconds=time.monotonic()-start, steps=steps, native_assertions_waits_timeouts_and_viewports_unchanged=True, owned_TMP_retained_for_exact_root_cleanup=str(tmp)))
print((out / 'RESULT.json').read_text())
raise SystemExit(0 if passed else 1)
