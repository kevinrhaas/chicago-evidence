# Actual final8b native source-qualified normalFF save — prepared only

No publication helper/native/API/source/index/ref/config/site/body write ran in preparation. Python AST and exactadaptationdiff reviewed. Root can save the finalsource-qualified8b repair immediately after fullsource/nativeCP+3nativequestions while actualphone/BOTH and requiredCI are pending. These remain finalmerge prerequisites, not reversible branchcheckpoint prerequisites.

Root command READONLY first:

    source /workspace/shared/resume-chicago-env.sh
    nice -n 19 taskset -c 2 python -B CAPSULE/publish_native.py --checkpoint ACTUAL_FINAL8B_CHECKPOINT_JSON --expect-head ACTUAL_FINAL8B_NATIVE_HEAD --expected-old ACTUAL54CP_HEAD --expected-lap ACTUAL_LIVE_OWN_LAP_SHA --output NEW_READONLY_OUTPUT

Review PLAN, then same args with a NEW output and --publish. Exactsource/nativeparent/remoteold/checkpoint/manifest/gate/threequestion/ownforeign/twofix/working/index/ref/config/nativeobject guards allremain. expected-old is mandatoryactual54CP; finalnativeparents exactly[ACTUAL54CP,8b4e98207c1afcff4878239cd700379447218cfb]. Prior54CP proof stillpins realparents[3746,54]/tree4445 and actualnormalFFpublication must already have saved that oldbranchhead. No finalhead/treeguess.

Gate status ACTUAL_PR1456_GENUINE8B_FULL_SOURCE_PASS with actualexit0/allguards, rawnativechecklog/reaper/timings hashchecks and freshnativeexit0/allreaped/nocleanup. CP ACTUAL_PR1456_GENUINE8B_NATIVE_TWO_PARENT_CHECKPOINT_PASS/revisionPR1456_GENUINE_8B, actualstagedmap/tree/parent/nativeCP and threefreshquestionreapers. Rootmanifest ROOT_REVIEWED_PR1456_GENUINE8B_INTEGRATION_STAGED includes explicitnewsmoke_renderer/yard twofixmap+proofs; allforeignnonallow indexedmodes/blobs/deletions exact8b.

Remoteparents[ACTUAL54CP,8b] and40453knownblobdonor must already be actualGitHubcommits. Newblobs missingfromthose actualpublictrees are measured and capped16MiB default/32MiB absolute. Exactnativerawcommit (message/authors/committer timestamps/parents/tree) recreated with exactnativeSHA, never rewritten. Sole code-ref update is force:false normalFF on ownPR1456branch with expectedold/liveownlap rechecks, then allchangedpath nativeblob bytes verified by immutableGitHubrawreads. SourceHEAD/indexsemantics/config/allrefs/workingstatus staysunchanged. No forcedref/admin/CI/statusfabrication/workflowdispatch/body/label/dev/main/production action. Ordinaryfinalmerge is separate after its actualruntime and freshrequiredCI are qualified.

Any later source/dev change is a new actualreview context; this helper does not automaticallychase it. Capsules immutable afterhandoff.
