# PR1456 genuine actual54CP + named8b full-source/native checkpoint — prepared only

No gate/checkpoint/helper execution or source/index/ref/config/site/API write occurred during preparation. Python AST only. Root performs actual import, genuine8b merge, two native owner settlement, two separately reviewed validation repairs, entrywise review and staging before this controller may execute. Final tree/head are unknown.

Root-approved JSON manifest contract (reuse original54manifest structure, then update actual facts):

- status ROOT_REVIEWED_PR1456_GENUINE8B_INTEGRATION_STAGED; root_reviewed true; source_head ACTUAL54CP; merge_parent 8b4e98207c1afcff4878239cd700379447218cfb; branch steward/t2381-t2373-t2384-t2377-early-pictures-20261029; actual stagedtree; COMPLETE staged_paths path→SHA256/null delta fromACTUAL54CP, not original65 or obsolete61.
- expected_steps from actual8bsource. Immutable54→8b diff adds jauntcheck/selftest and k01_dressings test, so1105+3=1108 expected. Native exact CHECK PASS footer and exit0 required, never a fabricated fixedcount.
- source_config_sha256 exact ordinaryclone config.
- owned_original remains originalsource_commit3746b23bf1298c34a29946b4cdb6ee2d98abff8f, tickets four originals, reviewed_paths actualwholeown50SHA/null and proof_files currentreview path/SHA records.
- canonical_foreign_entrywise canonical_commit8b, all_foreign_protected true, exact_paths selected exact canonical paths, mixed_paths actual13aggregate/docpostimages with SHA/null, proof_files currententrywise/liberty/index/registry/library/doc review path/SHA records. All indexed modes/blobs/deletions OUTSIDE explicitown/mixed/dependency/newrepair classes independently equal authoritative8b.
- required404_dependency_paths exact railway/lifecycle hashes; protected404_performance_paths exact spatial/confidence hashes. Actual40453 resident Git blobs independently determine their expected bytes.
- new_owned_path_sha256 contains EXACTLY chicago/4d/tools/smoke_renderer.mjs and chicago/4d/renderers/web/js/yard.js; values actualappliedreviewedSHA. new_owned_path_proof_files nonempty actualclosedregression/repair review path/SHA records. They are disjoint from wholeown/mixed/dependency classes. No finalhash guess.
- fixture_shim_sha256 and fixture_test_sha256 unchanged originalV2 values. Tiny exactfixture shim is REUSED from frozen /workspace/PR1456-genuine54-lean-gate-v2-secondfort-20261030/bin/node; no test/exception change.
- ignored_dependencies unchanged canonicalcleanmain/initialanchor/ticket4wholefilepins/immutable source_sha256 schema, mutable QUEUE never pinned. Actualnative tickets.sh may FFpull; exactfourreview/pr1456 whole files must remain pinned; actualbefore/after heads/QUEUE SHA recorded separately.
- resource_price retains all numeric prices, nonempty exactprice proof files; actualsingle1.557GB DRIFT scratch reserve≥1.5GB, logs≥96MiB/guard≥32MiB, actual remaining publication/ignoredsource/ticket/import prices, projectedclone≤4.6GB. Root has funded these. Workspace512MiB and sharedTMP1.8GB continuing floors. Native4workers do not manufacture4scratchcopies.
- checkpoint_message_sha256 exactroot-reviewed nativecommit message.

`common.configure` requires actual54CP file+SHA with genuineparents[3746,54]/tree4445, NORMALnative1105sourcePASS and three genuine freshnativePRquestionreapers. It resolves SOURCE dynamically from that actualreceipt and independently reads its realGit parents/tree. No priorhead/nativecommit is guessed.

Root gatecommand after allactualpreparation:

    source /workspace/shared/resume-chicago-env.sh
    nice -n 19 taskset -c 0,1,3,4 python -B CAPSULE/gate.py --reviewed-manifest ROOT_APPROVED_FINAL8B_JSON --prior-checkpoint ACTUAL54CP_RESULT --prior-checkpoint-sha256 ACTUAL54CP_RESULT_SHA --output NEW_EXTERNAL_OUTPUT --execute

Native unchanged bash tools/check.sh runs CHECK_JOBS4/C4D_GATE_REQUIRE_READERS1/nice19/affinity0,1,3,4 with ownedworkspaceTMP, native reaper, exact expectedfooter/publish and process/source guards. ALLtracked working modes/blobbytes are rehashed before/after, not only the stageddelta; exactnativeindex/ref/config/branch/MERGE_HEAD and own/mixed/foreign/source proof bindings remain. Actualnativefailure is NQ and retained. No assertion bypass/modelalias/sourcefixture or retagging exists.

Actual gatePASS status ACTUAL_PR1456_GENUINE8B_FULL_SOURCE_PASS; revision PR1456_GENUINE_8B. Binding includes head/source_head ACTUAL54CP, merge_parent8b, parents[ACTUAL54CP,8b], tree, manifest/path/SHA, priorCPpath/SHA, own/mixed/dependency/repair maps, allcontext/hash/resource/CPU/TMP/nativecheck/helper/shim facts. GATE-RESULT also gives native_check_log/native_reaper/native_timings paths+SHA, actualexit0 and allguards true. This fresh gate does not reuse or falsify old interrupted source/BOTH wrappers.

After actual PASS, unchanged source/context, and exactreviewed message:

    nice -n 19 taskset -c 0,1,3,4 python -B CAPSULE/checkpoint.py --gate-dir ACTUAL_GATE_OUTPUT --message-file EXACT_REVIEWED_MESSAGE --execute

Ordinary native commit only, parents exactly[ACTUAL54CP,8b], actualtree matchingrootreview. Then nativecheck-changelog-entry.mjs8bHEAD, resolve_id_collisions.mjs--base8b--check, check-changelog.mjs, each freshreaper0/allreaped/nocleanup. Rehash alltracked working modes/blobs again; sourcebranch is onlyref changed; config/index semantics/stagedmap/helpers/manifest/priorCP unchanged.

CP status ACTUAL_PR1456_GENUINE8B_NATIVE_TWO_PARENT_CHECKPOINT_PASS; revisionPR1456_GENUINE_8B; actualhead/tree/parents/branch/prbase, reviewed_manifest path/SHA, prior_checkpoint path/SHA, source_gate path/SHA, staged_paths and fourperformance/twofix maps, clean/onlyownbranchref true, steps threefreshnativequestionreceipts, tickets observations, resourcefacts. Phone/publishedBOTH/publication/CI/finalnormaldevmerge remain pending. No publication or merge exists in these controllers.

Capsule frozen after handoff; futureadaptation belongs a NEWdirectory/version.
