from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal,urllib.request,urllib.parse,zlib,base64
os.sched_setaffinity(0,{3});os.nice(19)
B=Path('/tmp/current-dev-a28-4220-bounded-import-cas-20261026T2316');P=Path('/workspace/T2382-currentdev-integration-20261026/upstream-T3177-a28-4220');C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='373851d158a7b6fc701b9cae1a651aa4b3823f97';FEATURE='a28c020372f4f10c98b904e63bda114ba2760a30';TIP='4220f39bc160816f2fc716606d854c0c9ad7bc05';TREE='026ea09dbe4c739241abb38cae080c60c06d9ccf';ENVELOPE=20*1024**2;FLOOR=128*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(repo,*args,input=None):return subprocess.check_output(['git','-C',str(repo),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
 files=[G/n for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()]
 return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{str(p):{'sha256':sha(p),'mode':p.stat().st_mode}for p in files},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
price=json.loads((P/'EXACT-BLOB-PRICE.json').read_text());apijson=json.loads((P/'tip-recursive-tree.json').read_text());assert price['base']==OLD and price['feature']==FEATURE and price['tip']==TIP and price['tip_tree']==TREE;assert not apijson.get('truncated');assert len(price['blobs'])==31 and sum(x['size']for x in price['blobs'])==14116337
for name in ['EXACT-BLOB-PRICE.json','tip-recursive-tree.json']:shutil.copy2(P/name,B/name)
before=snapshot();save('SOURCE-BEFORE.json',before);assert git(C,'rev-parse','refs/remotes/origin/dev').decode().strip()==OLD
fresh=api('git/ref/heads/dev');save('REMOTE-AT-START.json',fresh)
fc=api('git/commits/'+FEATURE);tc=api('git/commits/'+TIP);assert[par['sha']for par in fc['parents']]==[OLD]and[par['sha']for par in tc['parents']]==[FEATURE]and tc['tree']['sha']==TREE;save('FEATURE-COMMIT.json',fc);save('TIP-COMMIT.json',tc)
assert shutil.disk_usage('/workspace').free>=FLOOR+ENVELOPE and shutil.disk_usage('/tmp').free>=1024**3
# Explicit immutable commit metadata fetch into isolated small promisor only.
command=['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',TIP]
with(B/'metadata-fetch.log').open('xb')as log:
 p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);abort=None;peak=0
 while p.poll()is None:
  size=sum(f.stat().st_size for f in(R/'objects').rglob('*')if f.is_file());peak=max(peak,size)
  if size>32*1024**2:abort='Isolated metadata grew beyond32MiB'
  if b'filtering not recognized'in(B/'metadata-fetch.log').read_bytes().lower():abort='Server ignored filter'
  if abort:os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(.1)
 rc=p.wait()
save('METADATA-FETCH.json',{'exit':rc,'peak_bytes':peak,'abort':abort});assert rc==0 and not abort
assert git(R,'rev-parse',TIP+'^{tree}').decode().strip()==TREE
actual={}
for row in git(R,'ls-tree','-r','-z',TIP).split(b'\0'):
 if row:
  meta,name=row.split(b'\t',1);mode,kind,obj=meta.decode().split();actual[name.decode()]={'mode':mode,'type':kind,'sha':obj}
leaves=[row for row in apijson['tree']if row['type']!='tree'];assert len(actual)==len(leaves)
for row in leaves:assert actual[row['path']]=={k:row[k]for k in ['mode','type','sha']},row['path']
# Price actual missing tip objects and the one required intermediate entry blob before any source-common write.
missing=[]
for row in price['blobs']:
 check=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=(row['sha']+'\n').encode()).decode().strip()
 if check.endswith(' missing'):missing.append(dict(row,head=TIP))
pending_sha=price['intermediate_pending_blob_sha'];pending=api('git/blobs/'+pending_sha);assert pending['sha']==pending_sha and pending['encoding']=='base64';pending_data=base64.b64decode(pending['content']);assert len(pending_data)==pending['size']<=2048;assert hashlib.sha1(b'blob '+str(len(pending_data)).encode()+b'\0'+pending_data).hexdigest()==pending_sha
pending_needed=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=(pending_sha+'\n').encode()).decode().strip().endswith(' missing')
assert git(R,'rev-parse',FEATURE+':chicago/4d/changelog.d/T-3177.json').decode().strip()==pending_sha
new_meta={};newpacks=[]
for pack in sorted((R/'objects/pack').glob('*.pack')):
 if(G/'objects/pack'/pack.name).exists():continue
 lines=git(R,'verify-pack','-v',str(pack.with_suffix('.idx'))).decode().splitlines()
 for line in lines:
  cols=line.split()
  if len(cols)>4 and len(cols[0])==40 and cols[1]in['commit','tree','tag','blob']:
   assert cols[1]!='blob','Unexpected blob in filtered metadata'
   check=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=(cols[0]+'\n').encode()).decode().strip()
   if check.endswith(' missing'):new_meta[cols[0]]={'kind':cols[1],'size':int(cols[2])}
 newpacks.append(pack)
rawtotal=sum(x['size']for x in missing)+(len(pending_data)if pending_needed else 0)+sum(x['size']for x in new_meta.values());assert rawtotal<=ENVELOPE,('Actualnewobjectenvelopeexceeded',rawtotal,ENVELOPE)
save('ACTUAL-NEW-OBJECT-PRICE.json',{'missing_tip_blobs':missing,'pending_needed':pending_needed,'pending_sha':pending_sha,'pending_bytes':len(pending_data),'new_metadata_objects':new_meta,'actual_raw_new_object_bytes':rawtotal,'raw_envelope':ENVELOPE,'workspace_free':shutil.disk_usage('/workspace').free})
allocation=0;packrows=[]
for pack in newpacks:
 data=pack.read_bytes();assert hashlib.sha1(data[:-20]).digest()==data[-20:]
 for src in [pack,pack.with_suffix('.idx'),pack.with_suffix('.promisor')]:
  if not src.exists():continue
  dest=G/'objects/pack'/src.name;assert not dest.exists();tmp=dest.with_name('.'+dest.name+'.bounded4220-'+str(os.getpid()));shutil.copy2(src,tmp);assert sha(src)==sha(tmp);tmp.rename(dest);allocation+=dest.stat().st_blocks*512;packrows.append({'file':src.name,'bytes':src.stat().st_size,'sha256':sha(src)})
save('PACK-IMPORT.json',packrows)
def storeblob(row,data):
 global allocation
 raw=b'blob '+str(len(data)).encode()+b'\0'+data;assert len(data)==row['size']and hashlib.sha1(raw).hexdigest()==row['sha'];dest=G/'objects'/row['sha'][:2]/row['sha'][2:];assert not dest.exists();dest.parent.mkdir(exist_ok=True);temp=dest.with_name(dest.name+'.bounded4220-'+str(os.getpid()));encoded=zlib.compress(raw);temp.write_bytes(encoded);assert hashlib.sha1(zlib.decompress(temp.read_bytes())).hexdigest()==row['sha'];temp.rename(dest);allocation+=dest.stat().st_blocks*512;return {'path':row['path'],'sha':row['sha'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoded_bytes':len(encoded)}
rows=[]
for row in missing:
 url='https://raw.githubusercontent.com/kevinrhaas/chicago/'+TIP+'/'+urllib.parse.quote(row['path'],safe='/')
 with urllib.request.urlopen(url,timeout=90)as response:data=response.read(row['size']+65536)
 rows.append(storeblob(row,data));assert allocation<=ENVELOPE;save('DOWNLOAD-PROGRESS.json',{'complete':len(rows),'of':len(missing),'allocated_bytes':allocation})
if pending_needed:rows.append(storeblob({'path':'chicago/4d/changelog.d/T-3177.json@'+FEATURE,'sha':pending_sha,'size':len(pending_data)},pending_data))
save('BLOB-IMPORT.json',rows)
ids=sorted({r['sha']for r in leaves if r['type']=='blob'});batch=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();assert not any(x.endswith(' missing')for x in batch);sizes={r.split()[0]:int(r.split()[2])for r in batch};assert all(sizes[r['sha']]==r['size']for r in leaves if r['type']=='blob');assert git(C,'rev-parse',TIP+'^{tree}').decode().strip()==TREE;assert git(C,'merge-base',TIP,OLD).decode().strip()==OLD
assert snapshot()==before,'SourceHEAD/index/config/status/ref changed during objects-only import';assert shutil.disk_usage('/workspace').free>=FLOOR
remote=api('git/ref/heads/dev');save('REMOTE-BEFORE-CAS.json',remote);cas=remote['object']['sha']==TIP
if cas:
 assert snapshot()==before;git(C,'update-ref','refs/remotes/origin/dev',TIP,OLD)
after=snapshot();save('SOURCE-AFTER.json',after);assert after['metadata']==before['metadata']and after['HEAD']==before['HEAD']and after['status_sha256']==before['status_sha256'];expected=[x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+TIP)for x in before['refs']]if cas else before['refs'];assert after['refs']==expected
result={'status':'EXACT_A28_4220_BOUNDED_IMPORT_AND_EXPECTED_OLD_CAS_PASS'if cas else'PRICED4220_OBJECTS_READY_REMOTE_MOVED_NO_CAS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':OLD,'feature':FEATURE,'tip':TIP,'tip_tree':TREE,'new_tip_blob_count':len(missing),'required_intermediate_pending_bytes':len(pending_data),'raw_new_objects_total_including_metadata':rawtotal,'raw_new_envelope':ENVELOPE,'actual_source_allocated_bytes':allocation,'all_tip_unique_blobs_sizes_verified':len(ids),'cached_origin_dev':git(C,'rev-parse','origin/dev').decode().strip(),'fresh_remote_dev':remote['object']['sha'],'primary_HEAD_before_after':before['HEAD'],'HEAD_index_config_merge_state_unchanged':True,'working_status_hash_unchanged':True,'all_other_refs_unchanged':True,'workspace_free':shutil.disk_usage('/workspace').free,'TMP_free':shutil.disk_usage('/tmp').free,'workspace_floor':FLOOR,'no_source_common_fetch_GC_repack_or_worktree_edits':True,'authorization':'Rootdelegatednecessaryintegration after exactimpact/sizeinspection, <=20MiBnewrawobjects with WS>=128MiB and nativeTMPguard preserved.'};save('RESULT.json',result);print(json.dumps(result,indent=2))
