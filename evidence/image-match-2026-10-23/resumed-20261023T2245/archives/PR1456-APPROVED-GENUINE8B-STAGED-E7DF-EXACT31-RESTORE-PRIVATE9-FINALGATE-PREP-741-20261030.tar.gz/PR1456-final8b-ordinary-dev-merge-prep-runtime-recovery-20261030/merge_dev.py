"""Default read-only actual-proof merge plan; --merge permits one ordinary expected-head PR1456 PUT into dev."""
from pinned_imports import *
import argparse,datetime,json,os,re,time
from urllib.request import Request,urlopen
R=m.SOURCE;A=R/'chicago/4d';SITE=R/'site/4d';DEV='8b4e98207c1afcff4878239cd700379447218cfb';BRANCH=m.BRANCH
TARGETS={'miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832'}
sha=lambda b:hashlib.sha256(b).hexdigest();pf=lambda p:sha(Path(p).read_bytes())
def read(p):return json.loads(Path(p).read_bytes()),pf(p)
def pinned(row):
 p=Path(row['path']);assert p.is_absolute()and p.is_relative_to('/workspace')and p.is_file()and not p.is_symlink()and pf(p)==row['sha256'];return json.loads(p.read_bytes())if p.suffix=='.json'else None
def api(path,data=None,method=None):
 if data is None and method in [None,'GET']:path+=('&'if'?'in path else'?')+'codex_read='+str(time.time_ns())
 return m.api(path,data,method)
def reaped(path,expected_sha=None,command=None):
 r,h=read(path)
 if expected_sha is not None:assert h==expected_sha
 assert r['command_exit']==0 and r['all_children_reaped']is True and not r['leftover_cleanup']
 if command is not None:assert r['command'][-len(command):]==command
 return r
def exact_paths(root,values):
 for rel,h in values.items():
  p=root/rel;assert not Path(rel).is_absolute()and'..'not in Path(rel).parts
  if h is None:assert not p.exists()and not p.is_symlink()
  else:assert p.is_file()and not p.is_symlink()and pf(p)==h,rel
def tree_oid(leaves):
 root={}
 for path,row in leaves.items():
  v=root;a=path.split('/');assert all(x not in ['.','..','']for x in a)
  for name in a[:-1]:v=v.setdefault(name,{})
  assert a[-1]not in v;v[a[-1]]=row
 def emit(v):
  raw=bytearray()
  for name,row in sorted(v.items(),key=lambda x:(x[0]+('/'if isinstance(x[1],dict)else'')).encode()):
   mode,oid=('40000',emit(row))if isinstance(row,dict)else(row[0],row[2]);raw.extend(mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(oid))
  return m.gitsha('tree',bytes(raw))
 return emit(root)
def remote_leaves(tree):
 d=api('git/trees/'+tree+'?recursive=1');assert d['sha']==tree and d['truncated']is False;out={}
 for r in d['tree']:
  if r['type']=='tree':continue
  assert r['path']not in out and(r['mode'],r['type'])in [('100644','blob'),('100755','blob'),('120000','blob'),('160000','commit')];out[r['path']]=(r['mode'],r['type'],r['sha'])
 assert tree_oid(out)==tree;return out

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root-plan',required=True,type=Path);ap.add_argument('--root-plan-sha256',required=True);ap.add_argument('--output',required=True,type=Path);ap.add_argument('--merge',action='store_true');a=ap.parse_args();os.sched_setaffinity(0,{2});os.nice(19)
 plan,h=read(a.root_plan);assert h==a.root_plan_sha256 and plan['status']=='ROOT_APPROVED_PR1456_FINAL8B_ORDINARY_DEV_MERGE'and plan['root_approved']is True and plan['PR']==1456
 for flag in ['dated_original_consumer_reuse_accepted','no_currenthead_full15_smoke_PASS_claimed','no_qualification_restamping','no_PR1486_merge_prerequisite','ordinary_dev_merge_only']:assert plan[flag]is True,flag
 head,tree=plan['head'],plan['tree'];assert re.fullmatch('[0-9a-f]{40}',head)and re.fullmatch('[0-9a-f]{40}',tree)
 out=a.output.resolve();assert out.is_relative_to('/workspace')and not out.is_relative_to(R)and not out.is_relative_to('/workspace/chicago')and not out.exists();out.mkdir();save=lambda n,d:(out/n).write_text(json.dumps(d,indent=2)+'\n')
 source_gate=pinned(plan['source_gate']);cp=pinned(plan['native_checkpoint']);pub=pinned(plan['publication']);phone=pinned(plan['phone']);smoke=pinned(plan['smoke23']);reuse=pinned(plan['dated_consumer_reuse']);audit=pinned(plan['composition_audit'])
 assert cp['status']=='ACTUAL_PR1456_GENUINE8B_NATIVE_TWO_PARENT_CHECKPOINT_PASS'and cp['revision']=='PR1456_GENUINE_8B'and cp['head']==head and cp['tree']==tree and cp['parents'][1]==DEV and cp['branch']==BRANCH and cp['clean']is True and cp['only_own_branch_ref_changed']is True
 source=cp['parents'][0];assert re.fullmatch('[0-9a-f]{40}',source)and source!=head
 g.configure(cp['prior_checkpoint'],cp['prior_checkpoint_sha256']);assert g.SOURCE==source
 b=source_gate['binding'];manifest,msha=g.load(b['reviewed_manifest'])
 assert cp['reviewed_manifest_sha256']==msha==b['reviewed_manifest_sha256']and cp['prior_checkpoint_sha256']==b['prior_checkpoint_sha256']and cp['source_gate_sha256']==plan['source_gate']['sha256']and Path(cp['source_gate']).resolve()==Path(plan['source_gate']['path']).resolve()
 assert b['common_helper_sha256']==pf(g.__file__)and b['helper_sha256']==pf(Path(g.__file__).with_name('gate.py'))and cp['checkpoint_helper_sha256']==pf(Path(g.__file__).with_name('checkpoint.py'))and cp['common_helper_sha256']==b['common_helper_sha256']
 assert source_gate['status']=='ACTUAL_PR1456_GENUINE8B_FULL_SOURCE_PASS'and source_gate['exit']==0 and source_gate['guards']and all(v is True for v in source_gate['guards'].values())
 assert b['revision']=='PR1456_GENUINE_8B'and source_gate['revision']=='PR1456_GENUINE_8B'
 assert b['head']==b['source_head']==source and b['merge_parent']==DEV and b['parents']==[source,DEV]and b['tree']==tree==manifest['tree']and cp['staged_paths']==b['staged_paths']==manifest['staged_paths']
 for key in ['native_check_log','native_reaper','native_timings']:assert pf(source_gate[key])==source_gate[key+'_sha256']
 reaped(source_gate['native_reaper'],command=['bash','tools/check.sh']);clean=re.sub(r'\x1b\[[0-9;]*m','',Path(source_gate['native_check_log']).read_text(errors='replace'))
 assert re.search(r'^CHECK PASS — '+str(manifest['expected_steps'])+r' steps, none red\.$',clean,re.M)and'bash tools/publish.sh'in Path(source_gate['native_timings']).read_text()
 questions={'changelog-entry':['node','tools/check-changelog-entry.mjs',DEV,'HEAD'],'ticket-ids':['node','tools/resolve_id_collisions.mjs','--base',DEV,'--check'],'fold-history':['node','tools/check-changelog.mjs']}
 assert len(cp['steps'])==3 and{s['name']for s in cp['steps']}==set(questions)
 for s in cp['steps']:assert s['exit']==0;reaped(Path(cp['source_gate']).parent/(s['name']+'-REAPER.json'),s['reaper_sha256'],questions[s['name']])
 assert pub['status']=='ACTUAL_SOURCE_QUALIFIED_PR1456_GENUINE8B_NATIVE_NORMAL_FF_CHECKPOINT_AND_ALL_CHANGED_PATH_READBACK_PASS'and pub['head']==head and pub['tree']==tree and pub['parents']==[source,DEV]and pub['expected_old']==source and pub['branch']==BRANCH and pub['force']is False and pub['source_HEAD_index_semantics_config_status_allrefs_unchanged']is True
 assert pub['gate_sha256']==plan['source_gate']['sha256']and pub['checkpoint_sha256']==plan['native_checkpoint']['sha256']
 before=m.snapshot();save('SOURCE-BEFORE.json',before);assert before['HEAD']==head and not before['status']and not(R/'.git/MERGE_HEAD').exists()and m.git('branch','--show-current').decode().strip()==BRANCH and before['metadata']['config']==manifest['source_config_sha256']
 native=m.commit(head);assert native['tree']==tree and native['parents']==[source,DEV];qualified=m.leaves(tree);canonical=m.leaves(m.commit(DEV)['tree'])
 classes=[set(manifest['owned_original']['reviewed_paths']),set(manifest['canonical_foreign_entrywise']['mixed_paths']),set(manifest['required404_dependency_paths']),set(manifest['new_owned_path_sha256'])]
 assert sum(map(len,classes))==len(set().union(*classes));OWN=set().union(*classes);MIXED=classes[1];assert len(OWN)==67
 actual_own={p for p in set(qualified)|set(canonical)if qualified.get(p)!=canonical.get(p)};assert actual_own==OWN
 for p in set(qualified)|set(canonical):
  if p not in OWN:assert qualified.get(p)==canonical.get(p)
 own_sha={**manifest['owned_original']['reviewed_paths'],**manifest['canonical_foreign_entrywise']['mixed_paths'],**manifest['required404_dependency_paths'],**manifest['new_owned_path_sha256']}
 exact_paths(R,{**own_sha,**manifest['protected404_performance_paths'],**manifest['staged_paths']});g.full_working_bytes(g.entries())
 prior_leaves=m.leaves(m.commit(source)['tree']);needed={p for p,v in qualified.items()if v!=prior_leaves.get(p)}
 readback={r['path']:r for r in pub['readback']};assert needed==set(readback)
 for p,r in readback.items():assert r['blob']==qualified[p][2]and r['sha256']==sha(m.obj('blob',qualified[p][2]))
 pp=Path(plan['phone']['path']).parent;pb,pbh=read(pp/'PHONE-BINDING.json');sp=Path(plan['smoke23']['path']).parent;sb,sbh=read(sp/'BINDING.json')
 def runtime_binding(d,mode):
  assert d['revision']=='PR1456_GENUINE8B'and d['head']==head and d['tree']==tree and d['parents']==[source,DEV]and d['branch']==BRANCH
  assert d['source_gate']==plan['source_gate']and d['native_checkpoint']==plan['native_checkpoint']and d['reviewed_manifest']['sha256']==msha and d['source54_checkpoint']['sha256']==cp['prior_checkpoint_sha256']
  assert d['staged_paths']==manifest['staged_paths']and d['required404_dependency_paths']==manifest['required404_dependency_paths']and d['protected404_performance_paths']==manifest['protected404_performance_paths']and d['new_owned_path_sha256']==manifest['new_owned_path_sha256']
  assert d['source_config_sha256']==manifest['source_config_sha256']and d['memory_limit_bytes']==400*1048576 and d['current8b_final_checkpoint_not_intermediate54']is True and d['ordinary_native_clone_no_root_override_or_alias']is True
  runtime_plan,rph=read(d['root_plan']);assert runtime_plan['status']==('ROOT_APPROVED_PR1456_CURRENT8B_PHONE_RUN'if mode=='phone'else'ROOT_APPROVED_PR1456_CURRENT8B_SMOKE23_BOTH_RUN')
  assert rph==d['root_plan_sha256']and runtime_plan['root_approved']is True and runtime_plan['expected_head']==head and runtime_plan['expected_tree']==tree
  cap=pinned(runtime_plan['runtime_capsule']);assert cap['status']=='FROZEN_CURRENT8B_RUNTIME_PREPARATION_ONLY_NO_EXECUTION'
  cap_dir=Path(runtime_plan['runtime_capsule']['path']).parent
  for name,row in cap['members'].items():assert pf(cap_dir/name)==row['sha256']and(cap_dir/name).stat().st_size==row['bytes']
  assert d['common_sha256']==pf(cap_dir/'runtime_common.py')
  return cap_dir
 phonecapsule=runtime_binding(pb,'phone');smokecapsule=runtime_binding(sb,'smoke23');assert phonecapsule==smokecapsule
 assert pb['helper_sha256']==pf(phonecapsule/'phone.py')and sb['helper_sha256']==pf(smokecapsule/'smoke23.py')
 assert phone['status']=='ACTUAL_PR1456_GENUINE8B_FINAL_CHECKPOINT_PHONE400_PASS'and phone['head']==head and phone['tree']==tree and phone['parents']==[source,DEV]and phone['binding_sha256']==pbh and phone['source_published_guards_exact']is True and phone['all_children_reaped']is True and phone['errors']==[]and phone['unchanged_limit_MiB']==400
 measurement,mh=read(pp/'PHONE.json');assert mh==phone['actual_measurement_sha256']and len(measurement['rows'])==1;row=measurement['rows'][0];assert row['year']=='1904'and row['viewport']=='mobile'and row['errors']==[]and 0<row['totals']['total']<=400*1048576 and phone['actual_complete_1904_mobile_peak_MiB']==row['totals']['total']/1048576
 phonecmd=['node','tools/measure_memory.mjs','--year','1904','--only','mobile','--gate','--no-snapshot','--json',str(pp/'PHONE.json')];assert pb['command']==phone['step']['command']==phonecmd and pb['CPU_affinity']==[2]and phone['step']['exit']==0
 assert pf(phone['step']['log'])==phone['step']['log_sha256'];reaped(phone['step']['reaper'],phone['step']['reaper_sha256'],phonecmd)
 assert smoke['status']=='ACTUAL_PR1456_GENUINE8B_NATIVE_PUBLISHED_STAGES23_BOTH_PASS'and smoke['head']==head and smoke['tree']==tree and smoke['parents']==[source,DEV]and smoke['binding_sha256']==sbh
 assert smoke['stage_selector']=='2-3'and smoke['logical_required_parts']==[2,3]and smoke['actual_real_native_calls']==smoke['completed_native_call_records']==2 and smoke['started_viewports']==['desktop','mobile']and smoke['all_children_reaped']is True and smoke['guards_before_after_exact']is True and smoke['failure']is None and smoke['pending_or_unclosed_call']is None
 assert len(smoke['qualified_logical_pairs'])==4 and{(c['part'],c['viewport'])for c in smoke['qualified_logical_pairs']}=={(p,v)for p in[2,3]for v in['desktop','mobile']}
 steps,_=read(sp/'STEPS.json');assert steps==smoke['steps']and len(steps)==2 and[s['viewport']for s in steps]==['desktop','mobile'];cmd=['node','tools/smoke_renderer.mjs','--published'];assert sb['command']==cmd and sb['native_stage_selector']=='2-3'
 for s in steps:
  assert s['command']==cmd and s['exit']==0 and s['passed']is True and s['all_children_reaped']is True and all(v is True for v in s['predicates'].values());reaped(s['reaper'],s['reaper_sha256'],cmd);assert pf(s['log'])==s['log_sha256']
  text=re.sub(r'\x1b\[[0-9;]*m','',Path(s['log']).read_text(errors='replace'));audit_lines=re.findall(r'^(\d+) staged-section check\(s\) \(stage 2-3 of 15\), (\d+) always-on check\(s\)$',text,re.M);summary=re.findall(r'^(\d+) passed, (\d+) failed$',text,re.M)
  assert len(audit_lines)==1 and int(audit_lines[0][0])>0 and int(audit_lines[0][1])>0 and summary and int(summary[-1][0])>0 and int(summary[-1][1])==0 and re.search(r'^SMOKE PASS$',text,re.M)and not re.search(r'^\s*FAIL\s',text,re.M)
  label='desktop 1280x800'if s['viewport']=='desktop'else'mobile 390x780';assert all(any(required in line for line in text.splitlines()if line.startswith('  pass  '))for required in[label+': the suite body ran to completion',label+': zero page errors','vendor: meshopt import raises no page error'])
  for image in s['screenshots']:assert Path(image['path']).resolve().parent==sp.resolve()/s['viewport']and pf(image['path'])==image['sha256']and Path(image['path']).stat().st_size==image['bytes']
 assert pb['source_runtime_files']==sb['source_runtime_files']and pb['published_files']==sb['published_files']and pb['models']==sb['models']and pb['native_sidecar_projection']==sb['native_sidecar_projection']and pb['index_semantics']==sb['index_semantics']and pb['all_refs']==sb['all_refs']
 assert{r['structure_id']for r in pb['models'].values()}==TARGETS
 assert reuse['status']=='ROOT_APPROVED_PR1456_DATED_ORIGINAL4_CONSUMER_REUSE'and reuse['root_approved']is True and reuse['head']==head and reuse['tree']==tree and set(reuse['structure_ids'])==TARGETS
 for k in['accepted_original4_model_and_sidecar_bytes_preserved','dated_results_not_restamped','new_native23_BOTH_is_partial_coverage','remaining_dated_consumer_coverage_accepted']:assert reuse[k]is True
 assert reuse['proof_files']
 for p in reuse['proof_files']:pinned(p)
 current_dev=audit['current_dev'];assert re.fullmatch('[0-9a-f]{40}',current_dev)and audit['status']=='ROOT_APPROVED_PR1456_NAMED_DEV_COMPOSITION'and audit['root_approved']is True and audit['head']==head and audit['tree']==tree and audit['qualified_pr_base']==DEV and set(audit['owned_paths'])==OWN
 for k in['preserve_all_nonown_currentdev_leaves','mixed_foreign_entrywise_preservation_reviewed','no_qualification_restamping','no_PR1486_merge_prerequisite']:assert audit[k]is True
 assert audit['proof_files']
 for p in audit['proof_files']:pinned(p)
 dc=api('git/commits/'+current_dev);assert dc['tree']['sha']==audit['current_dev_tree'];dev=remote_leaves(dc['tree']['sha'])
 if current_dev!=DEV:
  compared=api('compare/'+DEV+'...'+current_dev);assert compared['status']=='ahead'and compared['merge_base_commit']['sha']==DEV
 expected=dict(dev)
 for p in OWN:
  if p in qualified:expected[p]=qualified[p]
  else:expected.pop(p,None)
 changed_mixed={p for p in OWN if dev.get(p)!=canonical.get(p)and dev.get(p)!=qualified.get(p)};assert changed_mixed<=MIXED
 assert set(audit['mixed_compositions'])==changed_mixed
 for path,row in audit['mixed_compositions'].items():
  assert row['root_reviewed']is True and row['original_own_entries_preserved']is True and row['currentdev_foreign_entries_preserved']is True and row['proof_files'];rawpath=Path(row['postimage']['path']);pinned(row['postimage']);raw=rawpath.read_bytes();mode=qualified[path][0];assert mode in['100644','100755']and row['mode']==mode and m.gitsha('blob',raw)==row['blob']
  for p in row['proof_files']:pinned(p)
  expected[path]=(mode,'blob',row['blob'])
 expected_tree=tree_oid(expected);assert expected_tree==audit['expected_merge_tree']
 def local_guard():
  assert pf(a.root_plan)==h and m.snapshot()==before and not(R/'.git/MERGE_HEAD').exists();g.full_working_bytes(g.entries());exact_paths(R,own_sha);exact_paths(A,pb['source_runtime_files']);assert g.index()==pb['index_semantics']and g.refs()==pb['all_refs']
  actual_pub={str(p.relative_to(SITE)):{'sha256':pf(p),'bytes':p.stat().st_size}for p in sorted(SITE.rglob('*'))if p.is_file()};assert actual_pub==pb['published_files']
  for key in ['source_gate','native_checkpoint','publication','phone','smoke23','dated_consumer_reuse','composition_audit']:pinned(plan[key])
  assert pf(b['reviewed_manifest'])==msha and pf(cp['prior_checkpoint'])==cp['prior_checkpoint_sha256']
 def live_lap():
  expected_lap=plan['own_lap'];assert re.fullmatch('[0-9a-f]{40}',expected_lap['sha'])and isinstance(expected_lap['actor'],str)and len(expected_lap['actor'])>=4 and'\n'not in expected_lap['actor'];marker=api('git/ref/heads/lap/pr-1456');assert marker['object']['sha']==expected_lap['sha'];mc=api('git/commits/'+expected_lap['sha']);assert mc['tree']['sha']=='4b825dc642cb6eb9a060e54bf8d69288fbee4904'and not mc['parents']and mc['message'].startswith('lap PR #1456 — '+expected_lap['actor'])
  age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(mc['committer']['date'].replace('Z','+00:00'))).total_seconds()/3600;assert 0<=age<=3;return dict(sha=expected_lap['sha'],actor=expected_lap['actor'],age_hours=age,message=mc['message'])
 def dev_guard():
  actual=api('git/ref/heads/dev')['object']['sha']
  if actual!=current_dev:
   save('REFUSED-UNCLASSIFIED-DEV.json',dict(expected=current_dev,actual=actual,no_write=True,compare=api('compare/'+current_dev+'...'+actual)));raise RuntimeError('Unclassified new dev tip; no merge attempted')
 def server_guard(label):
  dev_guard();lap=live_lap();pr=api('pulls/1456');checks=api('commits/'+head+'/check-runs?per_page=100');statuses=api('commits/'+head+'/status?per_page=100');files=api('pulls/1456/files?per_page=100');public=api('git/commits/'+head);save('SERVER-'+label+'.json',dict(PR=pr,checks=checks,statuses=statuses,files=files,head_commit=public,own_lap=lap))
  assert pr['state']=='open'and pr['merged']is False and pr['draft']is False and pr['head']['sha']==head and pr['head']['ref']==BRANCH and pr['base']['ref']=='dev'and pr['mergeable']is True and pr['mergeable_state']=='clean'and'hold'not in{r['name']for r in pr['labels']}
  assert public['tree']['sha']==tree and[x['sha']for x in public['parents']]==[source,DEV];assert len(files)==67 and{r['filename']for r in files}==OWN
  for f in files:
   if f['filename']in qualified:assert f['sha']==qualified[f['filename']][2]
   else:assert f['status']=='removed'
  runs=checks['check_runs'];assert checks['total_count']==len(runs)<=100 and runs and all(r['head_sha']==head and r['status']=='completed'and r['conclusion']in['success','skipped','neutral']for r in runs)and any(r['name']=='gate'and r['conclusion']=='success'for r in runs)
  legacy=statuses['statuses'];assert statuses['total_count']==len(legacy)<=100 and all(r['state']=='success'for r in legacy)
  return pr
 local_guard();pr=server_guard('READONLY')
 req=Request('https://api.github.com/repos/kevinrhaas/chicago?codex_read='+str(time.time_ns()),headers={'User-Agent':'Chicago-actual-PR1456-proof-normal-merge','Accept':'application/vnd.github+json'})
 with urlopen(req,timeout=120)as response:repo=json.load(response)
 assert repo['full_name']=='kevinrhaas/chicago';method=plan['merge_method']
 if method=='auto':method='merge'if repo.get('allow_merge_commit')else'squash'if repo.get('allow_squash_merge')else None
 assert method in['merge','squash']and repo.get('allow_merge_commit'if method=='merge'else'allow_squash_merge')is True
 result=dict(status='ACTUAL_PR1456_FINAL8B_ALL_PROOFS_AND_FRESH_SERVER_CHECKS_QUALIFIED_READONLY_NO_MERGE',head=head,tree=tree,parents=[source,DEV],current_dev=current_dev,expected_merge_tree=expected_tree,owned_path_count=len(OWN),whole_owned_count=len(classes[0]),mixed_count=len(MIXED),root_plan_sha256=h,merge_method=method,phone_peak_MiB=phone['actual_complete_1904_mobile_peak_MiB'],new_native23_calls=2,new_native23_logical_pairs=4,dated_consumer_reuse_explicit=True,no_currenthead_full15_smoke_claim=True,no_PR1486_merge_prerequisite=True,sole_possible_write=dict(method='PUT',path='pulls/1456/merge',body=dict(sha=head,merge_method=method)),no_admin_force_directdev_main_production_or_source_action=True);save('PLAN.json',result);local_guard()
 if not a.merge:print(json.dumps(result));return
 server_guard('FINAL');local_guard();dev_guard();live_lap()
 answer=api('pulls/1456/merge',dict(sha=head,merge_method=method),'PUT');save('MERGE-API.json',answer);assert answer.get('merged')is True
 merge_sha=answer['sha'];actual=api('git/commits/'+merge_sha);save('ACTUAL-MERGE-COMMIT.json',actual);parents=[p['sha']for p in actual['parents']];expected_parents=[current_dev,head]if method=='merge'else[current_dev]
 actual_leaves=remote_leaves(actual['tree']['sha']);post=dict(merge_sha=merge_sha,actual_parents=parents,expected_parents=expected_parents,actual_tree=actual['tree']['sha'],expected_tree=expected_tree,all_leaves_exact=actual_leaves==expected,all_nonown_currentdev_exact={p:v for p,v in actual_leaves.items()if p not in OWN}=={p:v for p,v in dev.items()if p not in OWN});save('POST-MERGE-TREE-AUDIT.json',post)
 assert parents==expected_parents and actual['tree']['sha']==expected_tree and post['all_leaves_exact']and post['all_nonown_currentdev_exact'],'Ordinary merge occurred but raced unexpected base/tree; raw result saved, no rollback/force attempted'
 immutable=[]
 from urllib.parse import quote
 for p in sorted(OWN):
  row=expected.get(p)
  if row is None:continue
  with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+merge_sha+'/'+quote(p,safe='/'),headers={'User-Agent':'Chicago-PR1456-merged-immutable-own-readback'}),timeout=120)as response:assert response.status==200;raw=response.read()
  assert m.gitsha('blob',raw)==row[2];immutable.append(dict(path=p,blob=row[2],bytes=len(raw),sha256=sha(raw)))
 after_pr=api('pulls/1456');assert after_pr['merged']is True and after_pr['state']=='closed'and after_pr['merge_commit_sha']==merge_sha and after_pr['head']['sha']==head and after_pr['base']['ref']=='dev'
 current_after=api('git/ref/heads/dev')['object']['sha'];later=None
 if current_after!=merge_sha:
  later=api('compare/'+merge_sha+'...'+current_after);assert later['status']=='ahead'and later['merge_base_commit']['sha']==merge_sha
 local_guard();save('RESULT.json',dict(status='ACTUAL_ORDINARY_PR1456_DEV_MERGE_VERIFIED_ALL_FOREIGN_AND_OWN_PATHS',PR=1456,PR_url=after_pr['html_url'],qualified_head=head,qualified_tree=tree,qualified_pr_base=DEV,root_plan_sha256=h,merge_method=method,merge_commit=merge_sha,merge_tree=actual['tree']['sha'],merge_parents=parents,root_approved_current_dev=current_dev,all_currentdev_nonown_modes_blobs_deletions_preserved=True,root_reviewed_mixed_foreign_entries_preserved=True,immutable_own_readback=immutable,current_dev_after=current_after,later_dev_advance=later,local_HEAD_index_config_allrefs_source_and_publication_unchanged=True,no_PR1486_merge_prerequisite=True,ticket_settlement_and_lap_release_separate=True));print((out/'RESULT.json').read_text())
if __name__=='__main__':main()
