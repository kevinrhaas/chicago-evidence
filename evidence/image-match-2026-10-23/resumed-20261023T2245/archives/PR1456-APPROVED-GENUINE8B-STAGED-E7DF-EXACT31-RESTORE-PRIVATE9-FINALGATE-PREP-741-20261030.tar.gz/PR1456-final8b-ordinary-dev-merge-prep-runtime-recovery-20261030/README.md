# PR1456 final actual8b ordinary dev merge guard — prepared, unexecuted

Future final54CP/head/tree are UNKNOWN until actual native operations. No helper main/API/source/index/ref/config/site write or runtime executed during preparation. AST and READONLY resident8b tree reconstruction only. This guard does NOT requirePR1486 to merge: final1456 already carries the reviewed exact404 performance dependencies and two actual validation repairs.

Default is read-only planning. Only explicit --merge permits ONE ordinary GitHub PUT pulls/1456/merge with expectedactualheadSHA and enabled merge/squashmethod. No administrator bypass/force/directdev/main/productionpush/CIstatus/dispatch/labels/body/tickets/lapmutation exists. Parent53/54 source history is never invented.

## Concrete root artifacts

Copy each template OUTSIDE this frozen folder, fill actual facts, review and set exact status/rootapproval; pendingfalse templates cannot execute:

- ROOT mergeplan: status ROOT_APPROVED_PR1456_FINAL8B_ORDINARY_DEV_MERGE; root_approvedtrue; actual finalhead/tree; sourcegate/nativeCP/publication/actualphone400/native2-3BOTH result paths+SHA; concrete datedconsumerreuse and composition audit paths+SHA; current ownlapSHA+actor; exact acceptance booleans. Merge method auto chooses enabledordinarymerge, squashfallback. Ownlap is independently required live≤3hours, exactmarkerSHA, nativeemptytree/rootlesscommit, messageprefix same root-namedactor. No hardcodedmarkerSHA.
- Dated consumer acceptance: ROOT_APPROVED_PR1456_DATED_ORIGINAL4_CONSUMER_REUSE/roottrue, exactfinalhead/tree/fourstructureIDs, explicit acceptedmodel+sidecarbytepreservation/datedresultsnotrestamped/new2-3BOTHpartial/remainingdatedcoverageaccepted flags, nonempty concrete immutable proof_files. Actualphone and native2-3BOTH remain separate mandatory fresh-head results. Old503pass3faildesktop is not relabelled; no currenthead full15 smoke claim.
- Named composition: ROOT_APPROVED_PR1456_NAMED_DEV_COMPOSITION/roottrue, exactqualifiedhead/tree/prbase8b, explicitcurrentdev/tree/expectedmergetree, owned_paths exact actual67 from manifest, proof_files and true scopedpreservation/norestamp/no1486dependency flags. Classes are derived dynamically, including49whole+14mixed+2dependency+2repair if those are actualfinalclasses; no50/13hardcode.

For unchangedcurrentdev8b: expectedmerge tree is qualifiedheadtree; mixed_compositions empty. For laterdev: everyNONOWN mode/type/blob/deletion is preserved EXACTCURRENTDEV. Nonmixedown paths may have unchangedcanonicalpreimages or already-identicalqualifiedheadbytes (e.g. separatelylanded1486); other owncode/model drift refuses and needs actualnewintegration. Changedmixed preimages may compose only through explicit root-reviewed actualpostimage/pathSHA/mode/Gitblob and concrete entrywiseprooffiles stating originalown and currentforeign entriespreserved. These override only actualMIXED paths; expectedtree reconstructs the entire prospectivemerge. The helper never writes/uploads these postimages or resolves a conflict: GitHub must already report serverclean. A newunclassifiedtip stops read-only, no automaticchase or rebase.

## Strict proof joins

Actualfinalgate ACTUAL_PR1456_GENUINE8B_FULL_SOURCE_PASS/exit0/allguards; exactmanifest/prior54CP/native8bparents/tree/stagedmap/helper/shim/proof bindings; realnativeexpected1108(or exactmanifestcount)footer/publish and newreaper0/allreaped/nocleanup. GenuinefinalCP [ACTUAL54CP,8b], threeactualfreshnativePRquestions/reapers, cleanonlyownref. Prior54CP itself is independently real [3746,54]/tree4445/normal1105PASS+threequestions. Source-qualified normalFFpub exactgate/CP/rawreadbacks and publicnativehead/tree/parents, never requiring runtimebefore saving abranch.

Actualfinalphone onecomplete1904/mobile row≤400MiB/errors0, exactnativecommand and freshreaper0/allreaped/nocleanup; currentlimit/meter/source/published/model/sidecar bindings match native2-3BOTH. Native2-3BOTH exactly2genuinecalls/4logicalpairs, positiveexactstageaudit/zerofailed/SMOKEPASS/suitecomplete/pageerrors0/vendor and screenshots/logs/reapers rehashed. Frozenruntimecapsule/helpers/rootplans and shared exactcurrentpublishedfiles/source/config/index/allrefs are checked again. Entiretrackedworkingtree modes/blobs are rehashed using unchangednativevalidator, not just Gitstat.

FreshGitHub PR1456 must be open/nondraft/exacthead/branch/baseDEV, mergeable=true/serverclean/nohold, actualsame-headchecks completed (gateSUCCESS mandatory), successful actuallegacycontexts and liveownlap. All67PRdiffpathnames/blobs match actualqualifiedOWN67; completeimmutable remote trees reconstruct their originalGitOIDs. No qualifiedphone/CI/dates are restamped to a newerdev.

## Root execution

Source shared environment, use separate unused external output for each call; detached own topcontroller/stdout is recommended to survive tool reconnects:

    source /workspace/shared/resume-chicago-env.sh
    nice -n 19 taskset -c 2 python -B /workspace/PR1456-final8b-ordinary-dev-merge-prep-runtime-recovery-20261030/merge_dev.py --root-plan ACTUAL_ROOT_MERGE_PLAN --root-plan-sha256 ACTUAL_PLAN_SHA --output NEW_READONLY_OUTPUT

Review PLAN.json; then same command with a NEW output and --merge. Source/refs/publication/proofs/currentdev/liveownlap/freshactualCI are rechecked immediatelybefore the sole PUT. Expectedhead is atomic atGitHub; expectedbase is NOT an atomicCAS. Remaining concurrentdevrace is exposed by exactpostmergeparent/tree/completemode/blob/deletion comparison, not hidden. MERGE-API and actualcommit/treeaudits are saved before final assertion, so anyunexpectedpostmergerace remains visible without rollback/force.

After success allcurrentdevnonown and root-reviewedmixedforeign preservation plus immutableOWN67rawreadback are verified at actualmergesha before laterfolds; laterdescendantdev is reported honestly. LocalHEAD/index/config/allrefs/working/publishedbytes remainexact. Ticketsettlement/laprelease are separate native steps.

Frozenafterhandoff. Any adaptation needs a newcapsule, never editing these handed-off files.
