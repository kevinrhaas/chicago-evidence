"""Import only pure helpers from frozen native transport/source validators; no main execution."""
from pathlib import Path
import hashlib,importlib.util,sys
sys.dont_write_bytecode=True
def pinned_import(name,path,expected):
 p=Path(path);assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=pinned_import('actual_final_native_transport','/workspace/PR1456-genuine8b-normal-FF-publication-prep-publisher-20261030/publish_native.py','5b1a823aea2542580cb6e0c16572cd0234d6d95a8806fc688e33341c1d4dd820')
g=pinned_import('actual_final_source_validator','/workspace/PR1456-genuine8b-native-gate-checkpoint-prep-publisher-20261030/common.py','cb706b92f4d34e2670b9635081eb1765687e342a571b7dac59b94a83f6716bb9')
