#!/usr/bin/env python3
"""Inherit exact prior bounded site proof only after all70 final input bytes match."""
import argparse
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/tmp/chicago-log-integration/chicago/4d')
OLD = Path('/tmp/log82-wolf-site-audit-20261023T2358')
OLD_SHA = 'd0833ab85ac77b0ef02cdbbf7b85cf5e3c8a157b9018a70a5f905a0be182c632'
INTERMEDIATE = Path('/tmp/T3081-base3fa-site-review')
INTERMEDIATE_SHA = 'b9571e3c860ce2f31bfd77a41febc64ef52136faf311b93b8b0ca5cc93b01a9e'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def git(*args, check=True):
    return subprocess.run(['git', '-C', str(ROOT), *args], capture_output=True, check=check)


def context():
    merge = git('rev-parse', '--verify', 'MERGE_HEAD', check=False)
    return {'head': git('rev-parse', 'HEAD').stdout.decode().strip(),
            'index_stage_sha256': sha(git('ls-files', '--stage', '-z').stdout),
            'merge_head': merge.stdout.decode().strip() if merge.returncode == 0 else None}


def validate_packet(directory, expected):
    manifest = (directory / 'MANIFEST.json').read_bytes()
    assert sha(manifest) == expected, str(directory)
    for entry in json.loads(manifest)['files']:
        raw = (directory / entry['path']).read_bytes()
        assert sha(raw) == entry['sha256'] and len(raw) == entry['bytes'], entry['path']


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tail-log', type=Path, required=True)
    parser.add_argument('--parent-session', required=True)
    parser.add_argument('--parent-exit', type=int, required=True)
    args = parser.parse_args()
    assert args.parent_exit == 0
    before = context()
    assert before['head'] == '3fa6e0e84f84a33ccb8ac82c4778f6468af3b029'
    assert before['merge_head'] == 'ff808a22d50fedf5474d33535748286b71794c8e'
    validate_packet(OLD, OLD_SHA)
    validate_packet(INTERMEDIATE, INTERMEDIATE_SHA)
    prior = json.loads((OLD / 'site-audit.json').read_bytes())
    bindings = prior['input_bindings']
    assert len(bindings) == 70
    observed = []
    for entry in bindings:
        data = (ROOT / entry['path']).read_bytes()
        actual = sha(data)
        assert actual == entry['sha256'] and len(data) == entry['bytes'], entry['path']
        observed.append({**entry, 'current_exact_prior_frozen_input': True})
    sc = json.loads((ROOT / 'data/sidecars/1835/wolf_point_tavern.json').read_bytes())
    assert sc['lodging']['enclosed_floor_m2'] == 61.5
    assert '62 m\u00b2' in sc['lodging']['note']
    assert not prior['current_objects_or_fence_segments_inside_body']
    assert not prior['current_objects_or_fence_segments_inside_actual_declared_doorway_zones']
    assert prior['native_entrance_total'] == 653
    tail = args.tail_log.read_bytes()
    last = tail.decode().splitlines()[-1]
    assert 'derived layer rebuilt' in last and 'in manifest order' in last and 'last one moved nothing' in last, last
    after = context()
    assert after == before, 'Target HEAD/index/MERGE_HEAD changed while reading'
    for entry in bindings:
        assert sha((ROOT / entry['path']).read_bytes()) == entry['sha256'], entry['path']
    receipt = {'status': 'PASS_FINAL_NEW_BASE_70_INPUT_BOUNDED_SITE_EQUIVALENCE',
               'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'target_context': after, 'prior_site_audit_manifest_sha256': OLD_SHA,
               'intermediate_metadata_stale_snapshot_manifest_sha256': INTERMEDIATE_SHA,
               'inputs': observed, 'exact_inputs': 70, 'changed_inputs': 0,
               'stale_metadata_resolved': {'lodging_enclosed_floor_m2': 61.5,
                                           'note_rounded_floor_area_m2': 62,
                                           'only_intermediate_changed_input_now_exact_prior': 'data/sidecars/1835/wolf_point_tavern.json'},
               'inherited_bounded_findings': {'native_entrances': 653, 'native_buildings': 651,
                   'wolf_entries': prior['wolf_native_entries'], 'objects_read': prior['current_native_objects_read'],
                   'body_hits': 0, 'both_doorway_zone_hits': 0, 'four_historical_coordinates_absent': True,
                   'occupied_body_river_clearance_m': prior['measurements']['occupied_body']['river_polygon']['distance_m'],
                   'primary_apron_river_clearance_m': prior['measurements']['wolf_point_tavern__door_1:apron']['river_polygon']['distance_m'],
                   'side_apron_river_clearance_m': prior['measurements']['wolf_point_tavern__side_xp_door_1:apron']['river_polygon']['distance_m']},
               'parent_tail': {'source': str(args.tail_log), 'bytes': len(tail), 'sha256': sha(tail),
                               'completion_marker': last, 'session': args.parent_session,
                               'parent_reported_exit': 0, 'audit_agent_reran_writers': False},
               'limits': 'Exact byte-equivalence inherits the frozen bounded2D source/data site proof. No new 3D/app/gate/image-match claim; no canonical edits, fetch, native writer, Blender, browser or full gate.'}
    (HERE / 'final-site-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    (HERE / 'final-native-tail.log').write_bytes(tail)
    (HERE / 'README.md').write_text(
        '# Final bounded site receipt after capacity metadata refresh\n\n'
        'All70 current native source/data inputs exactly match the prior frozen settled653-door site audit '
        f'(`{OLD_SHA}`). This inherits its exact2D geometry, both entrance/apron directions, river/bank/terrain '
        'diagnostics and zero object/body/doorway intersections. Both the current HEAD/index/MERGE_HEAD and '
        'the final parent-owned native-tail closing log are bound.\n\n'
        'The intermediate00:20:36 snapshot had stale84m² lodging metadata; the final Wolf sidecar is now '
        'byte-exact to the original61.5m² diagnostic, including its62m² rounded prose. It does not substitute '
        'an allocation basis for physical footprint area.\n\n'
        'Current653 entrances on651 buildings; both Wolf entries;3515 objects; zero body or either doorway '
        'zone intrusions; all4 historical coordinates absent. Model river clearances remain3.6879m(body), '
        '2.1746m(primary apron) and11.4517m(side apron). Historical40m/20m placement uncertainties remain.\n\n'
        'The old d083 packet and compact b957 intermediate packet are dependencies; their immutable manifests '
        'and every referenced file were checked. No duplicate terrain/input snapshot is stored here. '
        'No source write, native writer, Blender, browser or full gate ran in this receipt. Actual3D/app/fullgate '
        'and original image-match acceptance remain outside its bounded claim.\n')
    print(json.dumps({'status': receipt['status'], 'exact_inputs': 70, 'changed_inputs': 0,
                      'sidecar_lodging_floor_m2': sc['lodging']['enclosed_floor_m2']}))


if __name__ == '__main__':
    main()
