#!/usr/bin/env python3
"""Run two already-prepared native captures only after the parent allocates a lane."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys

PACKAGE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def verify_inputs():
    manifest = json.loads((PACKAGE / 'INPUT-MANIFEST.json').read_bytes())
    for row in manifest['files']:
        p = PACKAGE / row['path']
        if p.stat().st_size != row['bytes'] or sha(p) != row['sha256']:
            raise ValueError('frozen input changed: ' + row['path'])
    return manifest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--run-after-root-grant', action='store_true')
    args = ap.parse_args()
    if not args.run_after_root_grant:
        ap.error('prepared only: the parent must allocate the browser lane before execution')
    inputs = verify_inputs()
    playwright = Path('/workspace/node_modules/playwright/package.json')
    bound = json.loads((PACKAGE / 'source-bindings.json').read_bytes())
    if sha(playwright) != bound['shared_playwright_package_sha256']:
        raise ValueError('shared Playwright installation changed; re-review runtime binding')
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S-%fZ')
    run = Path('/workspace/T2373-8021-lighting-runs') / stamp
    run.mkdir(parents=True, exist_ok=False)
    native = run / 'native'
    shutil.copytree(PACKAGE / 'inputs/native', native)
    (native / 'node_modules').symlink_to('/workspace/node_modules', target_is_directory=True)
    (run / 'tmp').mkdir()
    env = dict(os.environ, PW_EXECUTABLE='/usr/bin/chromium', TMPDIR=str(run / 'tmp'),
               NODE_DISABLE_COMPILE_CACHE='1')
    receipt = {'status': 'RUNNING_NOT_REVIEWED', 'run': str(run),
               'prepared_manifest_sha256': sha(PACKAGE / 'MANIFEST.json'),
               'input_manifest_sha256': sha(PACKAGE / 'INPUT-MANIFEST.json'),
               'inputs': inputs, 'commands': [], 'review_status': 'UNREVIEWED'}
    code = 0
    try:
        for argv in (['node', '--version'], ['/usr/bin/chromium', '--version']):
            p = subprocess.run(argv, cwd=native, env=env, text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            receipt.setdefault('runtime', []).append({'argv': argv, 'exit': p.returncode,
                                                       'output': p.stdout})
            if p.returncode:
                raise RuntimeError('runtime version probe failed')
        for variant in ('overcast-baseline', 'directional-overcast'):
            argv = ['node', 'tools/photo_match.mjs',
                    f'docs/RESEARCH/{variant}/camera.json', '--glb',
                    'assets/gltf/chicago_lighthouse_1832__tower_1832.glb',
                    '--out', f'../reviews/{variant}']
            log = run / (variant + '.log')
            start = datetime.datetime.now(datetime.timezone.utc).isoformat()
            with log.open('wb') as f:
                p = subprocess.run(argv, cwd=native, env=env, stdout=f, stderr=subprocess.STDOUT)
            receipt['commands'].append({'argv': argv, 'cwd': str(native),
                                         'started_utc': start, 'exit': p.returncode,
                                         'log': log.name, 'log_sha256': sha(log)})
            if p.returncode:
                raise RuntimeError(variant + ' native capture failed')
            match = native / f'docs/RESEARCH/{variant}/camera.match.json'
            m = json.loads(match.read_bytes())
            camera = native / f'docs/RESEARCH/{variant}/camera.json'
            asset = native / 'assets/gltf/chicago_lighthouse_1832__tower_1832.glb'
            photo = native / 'data/sources/assets/chicago_harbor_lighthouse_1838.jpg'
            if not (m['glb_sha256'] == sha(asset) and m['camera_sha256'] == sha(camera)
                    and m['photo_sha256'] == sha(photo) and m['verdict'] == 'unreviewed'):
                raise ValueError('native match readback is not bound to fresh unreviewed inputs')
        receipt['status'] = 'CAPTURES_EXIT_ZERO_REVIEW_OWED'
    except Exception as error:
        receipt['status'] = 'FAILED_RETAINED_NOT_ACCEPTED'
        receipt['error'] = str(error)
        code = 1
    finally:
        try:
            verify_inputs()
            for row in inputs['files']:
                if row['path'].startswith('inputs/native/'):
                    p = native / Path(row['path']).relative_to('inputs/native')
                    if p.stat().st_size != row['bytes'] or sha(p) != row['sha256']:
                        raise ValueError('render changed copied frozen input: ' + row['path'])
            receipt['immutable_input_and_copied_glb_material_camera_guards'] = 'PASS'
        except Exception as error:
            receipt['immutable_input_and_copied_glb_material_camera_guards'] = 'FAIL'
            receipt['guard_error'] = str(error)
            receipt['status'] = 'FAILED_RETAINED_NOT_ACCEPTED'
            code = 1
        receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (run / 'execution-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        files = [{'path': str(p.relative_to(run)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
                 for p in sorted(run.rglob('*')) if p.is_file() and not p.is_symlink()]
        (run / 'OUTPUT-MANIFEST.json').write_text(json.dumps({'files': files}, indent=2) + '\n')
        print(json.dumps({'run': str(run), 'status': receipt['status'], 'exit': code}))
    return code


if __name__ == '__main__':
    sys.exit(main())
