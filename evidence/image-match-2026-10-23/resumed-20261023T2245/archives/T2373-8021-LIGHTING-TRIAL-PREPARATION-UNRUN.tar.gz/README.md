# T-2373 exact-8021 lighting diagnostic — PREPARED, UNRUN

This is a frozen research fixture, not an adopted building or an accepted camera. No render, browser, export, native writer or shared source edit was run during preparation. T-2373 remains OPEN; all original images remain DIFFERS/unresolved. The previously rendered 8,021-triangle prototype is still unadopted.

## Exact inputs and the controlled question

Use the actual saved prototype master `9d980cc3f8a954314785c0d8e206d965d4c439d2a5aa4cfc162587ee49166d8f`, 882,276 B/8,021 triangles. Full GLB bytes, JSON/BIN and material hashes are in `asset-bindings.json`. Nothing imports its old generator. No fort gallery/cupola/roof code is copied or adopted; the fort owner's newer gallery-clearance and canopy repair are outside this fixture.

The baseline camera is an exact copy of the actual prior camera, SHA `3934500d1ff4a94ef975de8d234395834acd22a619f574cdcbecf0cda0928ad2`. The candidate SHA `c28c27d7d3d389676cc628fc23fd1fbdc424117cecdb6a84aeb388b59be0c93c` has exactly one added JSON key: `sun_uvy: [-1.0,-0.35,1.2]`. Both retain `sky: overcast`; image dimensions, eye, focal length, principal point, yaw, square pixels, source/photo, solve text, geometry and materials are identical. The neutral overcast key moves from overhead to that direction; hemisphere/key colour and intensity remain fixed, and both have shadows disabled by the native CLI.

The old UNRUN source-light camera omitted `sky`, which would implicitly switch the native renderer to its sun preset (changing colour/intensity/hemisphere/shadows as well as direction). That historical proposal is retained verbatim in `historical/old-unrun-full-sun-preset.json` but is **not** a third command or approved trial. `camera-delta.json` distinguishes these hypotheses explicitly.

Two fresh captures are required so baseline and candidate use the same frozen renderer/vendor inputs. The saved old8021 comparison under the fixture's `historical/` is a held historic result, not a newly rendered baseline. A successful run here will not establish app/Bygrade rendering, a historic sun angle, a solved station, paint colour, date continuity, forty-foot datum or image acceptance. The cap may remain too dark because its finish is reconstructed; this diagnostic isolates illumination before another material choice.

## Native commands, after the root grants the browser lane

The runner first verifies every immutable input, copies the minimal fixture into a new owned directory under `/workspace/T2373-8021-lighting-runs/<UTC-unique>/native`, and links the already-installed shared `/workspace/node_modules`. It installs nothing. The native CLI/tools/vendor bytes are copied verbatim from the primary worktree and bound in `source-bindings.json`; no prototype producer or canonical manifest is used. `--glb` is an explicit **research override**, never a canonical phase/version acceptance selector.

From that fresh run's `native` directory, the exact commands are:

```bash
PW_EXECUTABLE=/usr/bin/chromium node tools/photo_match.mjs docs/RESEARCH/overcast-baseline/camera.json --glb assets/gltf/chicago_lighthouse_1832__tower_1832.glb --out ../reviews/overcast-baseline
PW_EXECUTABLE=/usr/bin/chromium node tools/photo_match.mjs docs/RESEARCH/directional-overcast/camera.json --glb assets/gltf/chicago_lighthouse_1832__tower_1832.glb --out ../reviews/directional-overcast
```

Prepared launcher, **do not run until root allocates the lane**:

```bash
python3 /tmp/T2373-8021-lighting-trial-prepared/run-prepared.py --run-after-root-grant
```

The launcher sets a run-local TMPDIR, records exact commands/runtime versions/exit codes and logs, and retains the CLI's raw rendered PNGs, side-by-side JPGs and unreviewed match records in the new run. It checks the frozen camera/photo/GLB/material bytes again afterward. It never changes the frozen package or canonical trees, and writes no native generated data except research match records in its own copied fixture. On failure it preserves the partial run and receipt; it does not rerun or overwrite old evidence.

Expected output layout is `reviews/{overcast-baseline,directional-overcast}/camera-side-by-side.jpg`, run-local `tmp/photo-match-*/camera-render.png`, and `native/docs/RESEARCH/<variant>/camera.match.json`, plus command logs, `execution-receipt.json` and `OUTPUT-MANIFEST.json`. The output manifest binds actual files including raw inputs/readbacks; it is created even on a command failure. No execution receipt or output result exists yet.

## Attribution and interpretation

Both views use the same held640×361 Castelnau harbour image and copied `castelnau_1842_chicago_harbor` source record. Credit: Francis de Castelnau, *Vues et souvenirs de l'Amérique du Nord* (Paris: Arthus Bertrand,1842), plate18 Chicago panel visibly4; the explanatory prose calls Chicago Fig1. The actual plate was previously located in the Library and Archives Canada microfiche via Internet Archive `cihm_43444`; Commons `File:Chicago1838.jpg` is the held reproduction. The1842 publication is public domain by age; exact panel draughtsman/lithographer is not newly adjudicated. Image identity/credit are copied unchanged, not a new rights research finding.

Depicted circa1838 is later than July1835. Continuity is inferred. Graphic hatch is not measured stonework, colour or sun. The source toe is partly occluded and camera remains provisional; no station, world placement, foundation, phase date, source confidence or grade changes. After actual execution, directly inspect both complete images and the original detail crops; record remaining crown/cage/aperture/material/context differences honestly. Do not mark matches or close the original ticket.

The separate read-only adoption plan is `/tmp/T2373-lighthouse-next-readonly-plan` manifest `b7ad44bf…` (archived remotely). If/when actual visible geometry is adopted into the final fort backend, selectively compose it and re-enumerate/rebake the full fort family (currently25 phases) through native writers. This lighting experiment needs **zero exports** and cannot satisfy that owed adoption/family refresh.

`MANIFEST.json` freezes this complete preparation; `INPUT-MANIFEST.json` specifically freezes copied inputs. Future execution outputs live outside this package and have their own manifest/timepoint.
