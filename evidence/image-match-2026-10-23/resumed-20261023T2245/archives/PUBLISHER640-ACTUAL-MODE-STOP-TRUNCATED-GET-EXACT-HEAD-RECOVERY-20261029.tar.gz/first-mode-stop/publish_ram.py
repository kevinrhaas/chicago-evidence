import os
os.sched_setaffinity(0, {1})
os.nice(19)
from pathlib import Path, PurePosixPath
import base64, datetime, gzip, hashlib, io, json, stat, tarfile, time
from urllib.request import Request, urlopen
from urllib.error import HTTPError

REPO = 'kevinrhaas/chicago-evidence'
API = 'https://api.github.com/repos/' + REPO + '/'
REL = 'evidence/image-match-2026-10-23/resumed-20261023T2245/'
OUT = Path('/tmp/checkpoint-oct29-fixed-c164-native-claims-host11-1935')
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda b: hashlib.sha256(b).hexdigest()
gitsha = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
dump = lambda d: (json.dumps(d, indent=2, ensure_ascii=False) + '\n').encode()

def api(path, data=None, method=None):
    req = Request(API + path, data=None if data is None else json.dumps(data).encode(),
                  headers={'User-Agent': 'Chicago-evidence-RAM-publisher', 'Accept': 'application/vnd.github+json',
                           'Content-Type': 'application/json'}, method=method or ('GET' if data is None else 'POST'))
    try:
        with urlopen(req, timeout=120) as r:
            return json.load(r)
    except HTTPError as e:
        body=e.read(65536).decode(errors='replace')
        print('API_ERROR', method, path, e.code, body, flush=True)
        raise

def raw(head, path):
    req = Request('https://raw.githubusercontent.com/' + REPO + '/' + head + '/' + path,
                  headers={'User-Agent': 'Chicago-evidence-RAM-publisher'})
    with urlopen(req, timeout=120) as r:
        assert r.status == 200
        return r.read()

def tree_files(tree):
    d = api('git/trees/' + tree + '?recursive=1')
    assert not d.get('truncated'), 'Refuse incomplete preservation audit'
    return {r['path']: (r['mode'], r['type'], r['sha']) for r in d['tree'] if r['type'] != 'tree'}

def create_blob(data):
    d = api('git/blobs', {'encoding': 'base64', 'content': base64.b64encode(data).decode()})
    assert d['sha'] == gitsha(data)
    return d['sha']

def readback(head, changed, blobs):
    rows = []
    for path, data in changed.items():
        received = raw(head, path)
        assert received == data and gitsha(received) == blobs[path], path
        rows.append({'path': path, 'bytes': len(data), 'sha256': sha(data), 'git_blob': blobs[path],
                     'status': 'PASS', 'method': 'STRICT_HTTPS_IMMUTABLE_COMMIT_PATH_SHA256_AND_GIT_BLOB_SHA1',
                     'immutable_raw_url': 'https://raw.githubusercontent.com/' + REPO + '/' + head + '/' + path})
    return rows

SPECS = [['FOURCASE-C164-EXACT-59PATH-FIXED-CANDIDATE-NEW-FULLGATE-PENDING-20261029', '/workspace/early-four-final-candidate-c164-closed-20261029', '2a74960380d5c4efccd545e1517b71726590447d19acaa084544fd47cce5b3fb', 'Closed exact59sourcepostimages+completebinarypatch ataccepted623e treec1648b...61members; concrete9gatefailurerepairs preserved. NEWFULLSOURCEGATE NOTYETPASSED; no finalnativecodecommits/PRmerge/originalDONE. PriorccbbactualFAIL9 remainsfailed.'], ['FOURCASE-623E-FIXED-ACTUAL-NATIVE-PACKAGE-PUBLISH-PHONE3958-20261029', '/workspace/early-four-623e-fixed-native-closure-root-20261029', '8208fa52813dd349df984e3904e6135732f2c33f1002dea199f656ae0e0ce426', 'Closed67members actualcurrentnativeconsumers+package5/publish andcurrent1904phone395.8MiB/unchanged400MiB PASS/allreaped. Separate datedchecks, notnewfullsourcePASS; MillerfinalBOTHbrowser/newgate pending atfreeze.'], ['FOURCASE-FIXED-NINE-PRIOR-FAILED-SOURCE-CHECKS-ACTUAL-REGRESSION-PASS-20261029', '/workspace/early-four-fixed-nine-regression-root-20261029', '36e218c6e9c87c9e7a29537cd422022835bbe7903094b30e82f41bb706b5c069', 'Closed19members actualall9previouslyfailedsourcechecks nowPASS withnarrowNodefixture/metadata/libertycoverage/chimneystack repairs. Actualfocusedchecks doNOTstandinforpendingfull1104stepverdict.'], ['FOURCASE-MILLER-10MM-ACTUAL-82-NATIVE-ONLY-WEB-353-RECIPES-20261029', '/workspace/early-four-miller-10mm-native-20261029', 'c5fe2e36a5dacdd0705d7ffc02de3acd7d76e4190e9cfe33e59feaa188106be0', 'Actual82nativebuild, onlyMillerWEB rebuilt, all353log/frame recipesfresh and352unchanged controlsbyteexact.12closedmembers. Stacktop10mmfix isgeometryboundedseparately; no fullattribute/WEBbyteidentityclaim andfinalBOTHapp/fullsourcegate stillseparate.'], ['FOURCASE-NATIVE-OWN-CLAIM-RENEWAL-REMOTE-FF-FOREIGN-PRESERVATION-20261029', '/workspace/early-four-own-claim-renewal-rest-20261029', '27bfce0ad583fdb0a24439dd614266009a9fe147ab4e953b1fc9096c84a9d65c', 'Actualnative3attemptpushfailure retained, thenexact16blob191KBhydrate andnativenormalmerge preserved3originalrenewalSHAs/all3217foreignpaths/allownfields except2claimfields. ExactnativeREST+normalforcefalsemainFFe055487... verifiedfourHTTPSpostimages; nativeboard/check3109PASS, mirrorstable. Fourclaimsrenew19:27:38→expire22:27:38UTC. No appsource/model/originalDONE action.'], ['GREENTREE2376-TWO-PUBLICATION-WORKS-NATIVE-IMAGE-HOST11-PREPARATION-20261029', '/tmp/green-tree-reference-image-host-20261029', '86d1ab1895f54210270b934631aabdadfd050ef9632095837ef7eeaff23a1c27', 'Closed31members4.58MB native4filederivedpipeline+5pathmanifestpostimage,1304oldrowspreserved. Andreas1884 andTrowbridge1902USpublicationPD basis/credits/retrospectivelimitsverified, helddisplaysbyteexact; no1859geometry. Preparationonly atfreeze; actualdelivery isseparatefollowingpacket.'], ['GREENTREE2376-IMAGES-PR11-MERGED-PAGES-ACTUAL-FOUR-DELIVERY-PASS-20261029', '/tmp/green-tree-reference-image-host-publication-20261029', '3aab353913bbf46a3ccc860ad0fe33a0d379ff7a59b6f6479d249ed10114445d', 'Actualstandardexpectedhead imagesPR11merged45e182f0..., all1304priorrows/unrelatedpathsexact. ActualPages40941072675SUCCESS andstrictTLSHTTP200nativebytes/hashes all4files1,584,609B PASS.26closedmembers, firstpendingPagespoll honestexit2 retained. No primaryapp/site/ticketmirrorwrites; appstream/STORE/model adoption separate.'], ['DEARBORN2375-THREE-HELD-ARTWORKS-AND-ACTUAL-1895-WIDTH-AUDIT-20261029', '/tmp/T2375-held-picture-audit-20261029', '077b1aaa2568f353df77f339af7542e32c1dfc7d0bd92d93e94aad00cb94d461', 'Finite25member13.26MB heldpictureaudit:Braunholdv4actualformaccepted; Bakercheck_requiredstill; Earle1849inventoryexclusionrefutedbyactualgallowsart/sourcepage1834creditpublished1902. ActualMoses1895p95width16fttextverified, contradictsoldrecordassertionwithoutgeometrychange. No actualnewBaker/Earlephoto/canonicalclaim/adoption/DONE.'], ['DEARBORN2375-HELD-PICTURE-PORTAL-AUDIT-ADDENDUM-20261029', '/tmp/T2375-held-picture-audit-portal-addendum-20261029', '696cae70c82c45fd3024bc8e24f3cd681dcf75f2c429af0a744398b313535d72', 'Tinyclosedheldpictureportaladdendum retainsfiniteoutstandingoriginalpicturework; no newticket, geometry/native/app/originalclosureclaim.'], ['ORIGINAL-REMAINING-NINE-READONLY-OFFICIAL-CACHED-AUDIT-20261029', '/tmp/original-remaining-audit-school-20261029', '119242a65b0eeebae6dc948554f65ab7073b23f8aef301d04e3acd26d25ccee7', 'Closed41members381876B readonly9remainingoriginalledger, actualoldpartialmergedPRscope andselectedMASTER/WEBbindings. Cachedofficialstates/datednativeclosinggate observations keptasdated; no source/claim/export/browser/PRmutation or completioninference.']]
assert SPECS, 'All requested manifests already durable'
payloads, records, archive_members = {}, [], {}
for spec in SPECS:
    name, source, expected, note = spec[:4]
    manifest_name = spec[4] if len(spec) > 4 else 'MANIFEST.json'
    root = Path(source)
    manifest_bytes = (root / manifest_name).read_bytes()
    assert sha(manifest_bytes) == expected
    manifest = json.loads(manifest_bytes)
    raw_rows = manifest.get('files', manifest.get('members'))
    assert raw_rows is not None
    rows = ([{'path': path, **value} for path, value in raw_rows.items()] if isinstance(raw_rows, dict) else list(raw_rows))
    normalized_rows = []
    for row in rows:
        row = dict(row)
        if PurePosixPath(row['path']).is_absolute():
            original_source = Path(row['path'])
            if 'relative_path' in row:
                row['path'] = row['relative_path']
                row['_immutable_author_source_path'] = str(original_source)
            else:
                row['path'] = str(original_source.relative_to(root))
        normalized_rows.append(row)
    rows = normalized_rows
    assert all(r['path'] != manifest_name for r in rows)
    rows.append({'path': manifest_name, 'bytes': len(manifest_bytes), 'sha256': expected})
    assert len({r['path'] for r in rows}) == len(rows)
    checked = []
    buf = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=buf, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tf:
            for r in sorted(rows, key=lambda r: r['path']):
                rel = PurePosixPath(r['path'])
                assert not rel.is_absolute() and '..' not in rel.parts
                p = Path(r['_immutable_author_source_path']) if '_immutable_author_source_path' in r else root / r['path']
                assert p.is_file() and not p.is_symlink()
                data = p.read_bytes()
                assert len(data) == r['bytes'] and sha(data) == r['sha256'], p
                mode = stat.S_IMODE(p.stat().st_mode)
                if 'mode' in r:
                    declared = int(r['mode'], 0) if isinstance(r['mode'], str) else r['mode']
                    assert mode == declared, 'Declared mode mismatch: ' + str(p)
                info = tarfile.TarInfo(r['path'])
                info.size, info.mode, info.mtime = len(data), mode, 0
                tf.addfile(info, io.BytesIO(data))
                checked.append({'source': str(p), 'path': r['path'], 'bytes': len(data), 'sha256': sha(data), 'mode': mode})
    archive = buf.getvalue()
    def check_tar(data, checked=checked):
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as tf:
            entries = tf.getmembers()
            assert len(entries) == len(checked)
            bypath = {r['path']: r for r in checked}
            assert {m.name for m in entries} == set(bypath)
            for m in entries:
                r = bypath[m.name]
                assert m.isfile() and m.size == r['bytes'] and m.mode == r['mode']
                b = tf.extractfile(m).read()
                assert sha(b) == r['sha256']
    check_tar(archive)
    filename = name + '.tar.gz'
    record = {'name': name, 'source_manifest_sha256': expected, 'source_manifest_filename': manifest_name, 'archive': '/workspace/chicago-evidence-metadata-20261024/archives/' + filename,
              'sha256': sha(archive), 'bytes': len(archive), 'source_file_count': len(checked),
              'source_bytes': sum(r['bytes'] for r in checked),
              'readback': 'PASS; every archived payload hash/size/mode and member list verified in RAM',
              'scope_note': note,
              'storage_note': 'Created and verified in RAM. No local tar or publisher Git-object/index copy. Immutable remote verification recorded separately after normal-FF publication.'}
    payloads[REL + 'archives/' + filename] = archive
    payloads[REL + 'archives/' + filename + '.manifest.json'] = dump({'created_utc': NOW, 'name': name, 'scope_note': note,
                                                                 'source_file_count': len(checked), 'files': checked})
    payloads[REL + 'archives/' + filename + '.receipt.json'] = dump(record)
    records.append(record)
    archive_members[REL + 'archives/' + filename] = check_tar
    print('PACKED', name, len(checked), len(archive), sha(archive), flush=True)

chunk_transports = {}
for path, data in list(payloads.items()):
    if len(data) <= 8 * 1024**2:
        continue
    assert path.endswith('.tar.gz')
    del payloads[path]
    parts = []
    for number, offset in enumerate(range(0, len(data), 8 * 1024**2)):
        part = data[offset:offset + 8 * 1024**2]
        part_path = path + '.part-' + str(number).zfill(4)
        payloads[part_path] = part
        parts.append({'index': number, 'path': part_path, 'bytes': len(part), 'sha256': sha(part), 'git_blob': gitsha(part)})
    transport = {'schema': 'CHICAGO_LOSSLESS_ARCHIVE_PARTS_V1', 'original_archive_path': path,
        'archive_bytes': len(data), 'archive_sha256': sha(data), 'parts': parts,
        'raw_chunk_limit_bytes': 8 * 1024**2,
        'restoration': 'Read each part from the SAME immutable publication commit in numerical index order. Verify each bytes/SHA256/Gitblob, concatenate exact bytes, verify archive_bytes and archive_sha256. Open gzip tar and verify every source member against the byte-exact original author source manifest listed as an archive member. No payload rewrite.',
        'reason': 'Proactive reuse of the established <=8MiBraw transport after previously documented GitDataHTTP422 on a large archive at checkpoint392. No new request failure is claimed. This avoids a large base64 blob POST and preserves every source byte.',
        'member_verification': 'Every source archive member hash/size/mode and exact complete member list verified before publication and independently after immutable remote part reassembly.'}
    manifest_path = path + '.parts.json'
    payloads[manifest_path] = dump(transport)
    chunk_transports[path] = transport
    rec = next(r for r in records if path.endswith('/' + r['name'] + '.tar.gz'))
    rec['remote_transport'] = {'kind': 'LOSSLESS_ORDERED_CHUNKS', 'manifest_path': manifest_path, 'manifest_sha256': sha(payloads[manifest_path]), 'parts': parts, 'archive_sha256': sha(data), 'archive_bytes': len(data)}
    payloads[path + '.receipt.json'] = dump(rec)
    print('CHUNKED', path, len(parts), len(data), sha(data), flush=True)
blob_ids = {p: create_blob(b) for p, b in payloads.items()}

for attempt in range(5):
    parent = api('git/ref/heads/main')['object']['sha']
    before_commit = api('git/commits/' + parent)
    before_files = tree_files(before_commit['tree']['sha'])
    index = json.loads(raw(parent, REL + 'ARCHIVES.json'))
    assert not {r['name'] for r in records} & {r['name'] for r in index}, 'New name unexpectedly already present'
    recovery = raw(parent, REL + 'RECOVERY.md').decode()
    heading = '\n<!-- OCT29_FIXED_C164_NATIVE_RENEWAL_HOST11_START -->\n## Fixed candidate saved; native checks, renewed claims and image delivery verified\n\nThe exact59path fixedcandidate ataccepted623e/treec164 is preserved withits completepatch. All9previouslyfailedfocusedchecks nowPASS; currentnative/package/publish andphone395.8/400MiB checks passed. These are concrete repairproofs. The NEWFULLSOURCEGATE is stillPENDING atfreeze, and the oldccbbgate remainsFAIL9. No final4nativecodecommits/appPRmerge/originalclosure is claimed. MillerfinalBOTHbrowser is a separate livejob and excluded.\n\nFouroriginalclaims nowactuallyrenewed onGitHub: e055487... preservesthreeoriginalnativerenewalcommits andall3217foreignpaths afterexactboundedmissingblobhydrate/nativeordinarymerge, followed bynormalforcefalseFF andstrictpostimageverification. Claims expire22:27:38UTC. The nativeboardmirror wasmade stable once forbrowserfreeze; do notrewrite it duringthebrowser/sourcegate.\n\nImagesPR11 actuallymerged andPagesrun40941072675succeeded. BothheldGreenTree publicationdrawings andtheir nativethumbnails are strictHTTP200/byteverifiedlive; sourcecredits/publicationagebasis andretrospectivelimits retained. Thatdelivery doesnotcloseT2376 oradoptappmodels. Bridgeheldpictureaudit retainsBaker/Earleoutstandingwork, theacceptedBraunholdform andtheactual16fttext contradiction withoutchanginggeometry. Remainingoriginalaudit isread-only/dated, notcompletion.\n\n' + '\n'.join('- [' + r['name'] + '](archives/' + r['name'] + ('.tar.gz.parts.json' if r.get('remote_transport') else '.tar.gz') + ') — ' + r['scope_note'] for r in records) + '\n<!-- OCT29_FIXED_C164_NATIVE_RENEWAL_HOST11_END -->\n\n'
    first_line, remainder = recovery.split('\n', 1)
    changed = dict(payloads)
    changed[REL + 'ARCHIVES.json'] = dump(index + records)
    changed[REL + 'RECOVERY.md'] = (first_line + '\n' + heading + remainder).encode()
    blobs = dict(blob_ids)
    for path in [REL + 'ARCHIVES.json', REL + 'RECOVERY.md']:
        blobs[path] = create_blob(changed[path])
    t = api('git/trees', {'base_tree': before_commit['tree']['sha'],
                         'tree': [{'path': p, 'mode': '100644', 'type': 'blob', 'sha': blobs[p]} for p in sorted(changed)]})
    c = api('git/commits', {'message': 'Checkpoint fixedc164 candidate, actualnative checks, renewedclaims andimagesPR11delivery',
                           'tree': t['sha'], 'parents': [parent]})
    try:
        api('git/refs/heads/main', {'sha': c['sha'], 'force': False}, 'PATCH')
    except HTTPError as e:
        if e.code in [409, 422] and api('git/ref/heads/main')['object']['sha'] != parent:
            print('Concurrent remote advance; rebuilding on fresh parent', flush=True)
            continue
        raise
    head = c['sha']
    after_files = tree_files(t['sha'])
    for p, entry in before_files.items():
        if p not in changed:
            assert after_files.get(p) == entry, 'Existing remote path changed: ' + p
    assert all(after_files[p] == ('100644', 'blob', blobs[p]) for p in changed)
    proof = readback(head, changed, blobs)
    for path, checker in archive_members.items():
        if path in chunk_transports:
            transport = chunk_transports[path]
            received_parts = [raw(head, part['path']) for part in transport['parts']]
            for received, part in zip(received_parts, transport['parts']):
                assert len(received) == part['bytes'] and sha(received) == part['sha256'] and gitsha(received) == part['git_blob']
            received_archive = b''.join(received_parts)
            assert len(received_archive) == transport['archive_bytes'] and sha(received_archive) == transport['archive_sha256']
            checker(received_archive)
            print('IMMUTABLE_REMOTE_CHUNK_REASSEMBLY_EVERY_SOURCE_MEMBER_PASS', transport['archive_sha256'], flush=True)
        else:
            checker(raw(head, path))
    receipt = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'repository': REPO,
               'status': 'PUBLISHED_NORMAL_FF_AND_FULL_IMMUTABLE_READBACK_PASS',
               'method': 'IN_RAM_GIT_DATA_REST_NORMAL_FF_FORCE_FALSE', 'parent': parent, 'commit': head,
               'tree': t['sha'], 'archives_count': len(index) + len(records), 'new_archive_records': records,
               'changed_paths': sorted(changed), 'readback': proof,
               'all_prior_remote_file_paths_independently_preserved': True,
               'prior_remote_files_checked': len(before_files),
               'local_publisher_worktree_unchanged': True, 'local_tar_copies_created': False,
               'index': 'https://github.com/' + REPO + '/blob/' + head + '/' + REL + 'RECOVERY.md'}
    receipt_bytes = dump(receipt)
    (OUT / 'PUBLICATION.json').write_bytes(receipt_bytes)
    print('PUBLICATION_PASS', head, len(index) + len(records), len(proof), flush=True)
    break
else:
    raise RuntimeError('Remote advanced too often; no forced update attempted')

receipt_path = REL + 'publications/' + head + '.json'
receipt_blob = create_blob(receipt_bytes)
for attempt in range(5):
    parent2 = api('git/ref/heads/main')['object']['sha']
    before2 = api('git/commits/' + parent2)
    files2 = tree_files(before2['tree']['sha'])
    ledger = json.loads(raw(parent2, REL + 'STORAGE-ARCHIVE-OMISSIONS.json'))
    existing = {r['name'] for r in ledger['files']}
    for record in records:
        filename = record['name'] + '.tar.gz'
        assert filename not in existing
        path = REL + 'archives/' + filename
        if path in chunk_transports:
            transport = record['remote_transport']
            manifest_path = transport['manifest_path']
            remote_proof = next(p for p in proof if p['path'] == manifest_path)
            ledger['files'].append({'name': filename, 'local_archive_path': record['archive'],
                'worktree_path': '/workspace/chicago-private-publisher-20261024/' + path,
                'git_path': manifest_path, 'sha256': record['sha256'], 'bytes': record['bytes'],
                'git_blob': None, 'transport_manifest_git_blob': blobs[manifest_path],
                'transport_manifest_sha256': transport['manifest_sha256'],
                'remote_transport': transport,
                'verified_committed_at': head, 'storage': 'REMOTE_ONLY_LOSSLESS_ORDERED_CHUNKS_NO_LOCAL_TAR_OR_GIT_COPY',
                'independent_remote_readback': {'status': 'PASS', 'each_chunk_sha256_size_git_blob': True, 'concatenated_archive_sha256_size': True, 'all_source_members_hash_size_mode': True, 'published_commit': head, 'receipt_file': receipt_path, 'receipt_sha256': sha(receipt_bytes)},
                'restore_url': remote_proof['immutable_raw_url'],
                'restoration': 'restore_url is the TRANSPORT MANIFEST, not the tar. Verify its transport_manifest_sha256, then download ordered parts from verified_committed_at. Verify every part and concatenated tar SHA/size. Original archive and every nested member were independently checked after immutable remote reassembly. No single-file tar Gitblob is claimed.'})
            continue
        remote_proof = next(p for p in proof if p['path'] == path)
        ledger['files'].append({'name': filename, 'local_archive_path': record['archive'],
            'worktree_path': '/workspace/chicago-private-publisher-20261024/' + path,
            'git_path': path, 'sha256': record['sha256'], 'bytes': record['bytes'],
            'git_blob': blobs[path], 'verified_committed_at': head,
            'storage': 'REMOTE_ONLY_API_PUBLICATION_NO_LOCAL_TAR_OR_OBJECT_COPY',
            'independent_remote_readback': {**remote_proof, 'published_commit': head,
                 'published_at': receipt['at'], 'receipt_file': receipt_path, 'receipt_sha256': sha(receipt_bytes)},
            'restore_url': remote_proof['immutable_raw_url'],
            'restoration': 'Download immutable strict-HTTPS restore_url and verify exact bytes/SHA256/Gitblob. Local publisher metadata/HEAD remain stale; no local Git object/index or tar presence claimed.'})
    for previous in ledger.get('additional_in_ram_publications', []):
        if previous.get('anchor_commit') == '27c49b89af454b76e87e9f124e39b8318b26633a':
            assert previous['count'] == 3
            if 'caption_correction' not in previous:
                previous['caption_correction'] = {'previous_scope_text': previous.get('scope'), 'reason': 'Correct reused publisher summary caption; actual three archive records and immutable source/readback receipts remain unchanged.'}
                previous['scope'] = 'Three finite obsolete publisher Git recovery/retirement, actual independent Miller diagnostic, and original17 progress prose archives. Every source member verified after immutable readback. No app acceptance inferred.'
    ledger['count'] = len(ledger['files'])
    ledger['status'] = 'AUTHORIZED_EXACT' + str(ledger['count']) + '_REMOTE_VERIFIED_ARCHIVE_TAR_OMISSIONS'
    ledger['extended_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    ledger.setdefault('additional_in_ram_publications', []).append({'count': len(records), 'anchor_commit': head,
        'total_bytes': sum(r['bytes'] for r in records), 'local_payloads_or_git_objects_written': False,
        'scope': 'Ten closed fixedc164sourcecandidate, actualnative/package/phone,9focusedregressions, Miller82native, ownclaimrenewal, imageshost11prep+actualdelivery, finiteBridgeheldpictureaudit+addendum andremainingoriginalaudit archives. NEWFULLSOURCEGATE pending; no appcodepublication/originalclosure inferred. Every member verified after immutable readback; prior paths and all scope limits preserved.'})
    changes2 = {receipt_path: receipt_bytes, REL + 'STORAGE-ARCHIVE-OMISSIONS.json': dump(ledger)}
    blobs2 = {receipt_path: receipt_blob, REL + 'STORAGE-ARCHIVE-OMISSIONS.json': create_blob(changes2[REL + 'STORAGE-ARCHIVE-OMISSIONS.json'])}
    t2 = api('git/trees', {'base_tree': before2['tree']['sha'], 'tree': [
        {'path': p, 'mode': '100644', 'type': 'blob', 'sha': blobs2[p]} for p in sorted(changes2)]})
    c2 = api('git/commits', {'message': 'Record immutable availability forfixedcandidate, renewedclaims andactualimagesdelivery',
                           'tree': t2['sha'], 'parents': [parent2]})
    try:
        api('git/refs/heads/main', {'sha': c2['sha'], 'force': False}, 'PATCH')
    except HTTPError as e:
        if e.code in [409, 422] and api('git/ref/heads/main')['object']['sha'] != parent2:
            continue
        raise
    after2 = tree_files(t2['sha'])
    assert all(after2.get(p) == entry for p, entry in files2.items() if p not in changes2)
    readback2 = readback(c2['sha'], changes2, blobs2)
    final = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'PASS',
             'publication': head, 'availability_commit': c2['sha'], 'availability_parent': parent2,
             'archives_count': receipt['archives_count'], 'omission_count': ledger['count'],
             'all_existing_paths_preserved': True, 'readback': readback2,
             'index': 'https://github.com/' + REPO + '/blob/' + c2['sha'] + '/' + REL + 'RECOVERY.md',
             'local_git_metadata_unchanged': True, 'local_tar_copies_created': False}
    (OUT / 'COMPLETE.json').write_bytes(dump(final))
    print(json.dumps(final, indent=2), flush=True)
    break
else:
    raise RuntimeError('Availability update raced; publication remains durable and local receipt preserved')
