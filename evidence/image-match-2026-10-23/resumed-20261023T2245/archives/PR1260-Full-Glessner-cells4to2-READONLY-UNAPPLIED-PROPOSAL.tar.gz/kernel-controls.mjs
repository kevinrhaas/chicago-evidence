// Small native-kernel fixtures only, not an asset scan or measured performance claim.
import fs from 'node:fs';import assert from 'node:assert/strict';
import {partitionTriangles} from '/tmp/chicago-log-integration/chicago/4d/renderers/web/js/jobs/spatial-kernel.js';
const out=new URL('./CPU-CONTROLS.json',import.meta.url),tests=[];const ok=(name,value)=>{assert(value,name);tests.push(name);};
let seed=3081;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
const n=192,pos=new Float32Array(n*9),uv=new Float32Array(n*6),confidence=new Uint8Array(n*3),tag=new Uint32Array(n*3),index=new Uint16Array(n*3);
for(let t=0;t<n;t++)for(let v=0;v<3;v++){const j=t*3+v;index[j]=j;for(let k=0;k<3;k++)pos[j*3+k]=(random()-.5)*40;uv[j*2]=random();uv[j*2+1]=random();confidence[j]=(t+v)%256;tag[j]=t;}
const attrs=[{name:'position',array:pos,itemSize:3},{name:'uv',array:uv,itemSize:2},{name:'confidence',array:confidence,itemSize:1},{name:'triangle_tag',array:tag,itemSize:1}];
const job={attributes:attrs,positionAt:0,index,count:index.length,heightM:2};const original=attrs.map(a=>Array.from(a.array));
const serialize=(arrays,ids)=>{const rows=[];for(let j=0;j<ids.length;j+=3){const row=[];for(let v=0;v<3;v++)for(let a=0;a<attrs.length;a++)for(let k=0;k<attrs[a].itemSize;k++)row.push(arrays[a][ids[j+v]*attrs[a].itemSize+k]);rows.push(JSON.stringify(row));}return rows;};
const expected=serialize(attrs.map(a=>a.array),index).sort(),pieces={};
for(const cellM of [4,2]){pieces[cellM]=partitionTriangles({...job,cellM}).pieces;const rows=pieces[cellM].flatMap(p=>serialize(p.arrays,p.index)).sort();ok(cellM+'m every triangle/winding/UV/confidence attribute exactly once',JSON.stringify(rows)===JSON.stringify(expected));}
ok('kernel input arrays unchanged',JSON.stringify(original)===JSON.stringify(attrs.map(a=>Array.from(a.array))));
const parentOf=t=>{const ids=[t*3,t*3+1,t*3+2],c=[0,1,2].map(k=>ids.reduce((s,j)=>s+pos[j*3+k],0)/3);return [Math.floor(c[0]/4),Math.floor(c[2]/4),Math.floor(c[1]/2)].join(':');};
ok('every2m child contains triangles from one4m parent even across negative/grid-crossing coordinates',pieces[2].every(p=>new Set(Array.from(p.arrays[3]).map(parentOf)).size===1));
let cullChecks=0;
for(const piece of pieces[2]){const p=piece.arrays[0],min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];for(let i=0;i<p.length;i++)min[i%3]=Math.min(min[i%3],p[i]),max[i%3]=Math.max(max[i%3],p[i]);const centre=min.map((x,i)=>(x+max[i])/2);let radius=0;for(let i=0;i<p.length;i+=3)radius=Math.max(radius,Math.hypot(p[i]-centre[0],p[i+1]-centre[1],p[i+2]-centre[2]));for(let axis=0;axis<3;axis++)for(const sign of [-1,1]){const plane=sign*centre[axis]+radius+.001;for(let i=axis;i<p.length;i+=3){assert(sign*p[i]<plane);cullChecks++;}}}
ok('all-corner conservative bounding sphere cannot discard a triangle crossing its rejected halfspace',cullChecks>0);
// Nested boxes alone do not imply nested spheres: do not promise monotonic driver cost.
const parentRadius=Math.sqrt(5),childRadius=Math.sqrt(4.25),childCentreY=.5;
ok('sphere false positives can change either way; no automatic cost-reduction claim',childCentreY+childRadius>parentRadius);
fs.writeFileSync(out,JSON.stringify({status:'PASS_SMALL_NATIVE_KERNEL_CONTROLS',tests,triangles:n,pieces4m:pieces[4].length,pieces2m:pieces[2].length,conservative_point_checks:cullChecks,limits:'Synthetic192-triangle CPU fixtures only. No browser, full Glessner partition/asset scan or measured cost saving.'},null,2)+'\n');console.log('PASS '+tests.length+' small native-kernel controls; no performance verdict.');
