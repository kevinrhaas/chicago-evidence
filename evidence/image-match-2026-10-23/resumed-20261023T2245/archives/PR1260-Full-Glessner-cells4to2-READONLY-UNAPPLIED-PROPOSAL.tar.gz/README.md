# Unapplied bounded Full-Glessner partition proposal

The latest1904 spawn overshoot is still an arithmetic expectation; a fresh actual measurement on the latest integrated tree is owed. This packet contains CPU/source analysis only: no browser, Blender, full gate, source/asset/workflow edit or measured saving.

## Smallest candidate

`proposal.patch` changes one existing field in `buildings.js:605`: opaque Full Glessner fallback `{cellM:4,heightM:2}` becomes `{cellM:2,heightM:2}`. The explicit Light/Balanced `spatialCells` argument still wins and stays4×2;1835 and other Full buildings do not enter this existing Glessner-only fallback. No new ID exemption, quality tier or budget change is added. The guarded preimage/candidate hashes are in SOURCE-BINDINGS.json; root must reconcile against its latest integration before adoption.

The existing native spatial kernel assigns each whole triangle once by centroid, keeps all its original corners, indices/winding and every attribute, and measures conservative bounds around the complete pieces. This is partition granularity, not decimation or an LOD. The structure-wide quantization scale still comes from all pieces and has the same maximum coordinate; positions, material/confidence/UV/normal data, placement, feet and full union bounds are preserved. Existing coalescing still joins contiguous drawn ranges sharing instance data after culling.

Full roof relief's `filterGlessnerRoof` changes roof_plane_1/2/3 to transparent. Those primitives deliberately remain outside this fallback, preserving their existing blended draw order. No alpha-fade, tile detail, texture, displacement, shader, shadow setting or visibility flag is modified. Current seasonal/wall wrappers preserve vertex positions. Unknown future position-changing shader behavior would require separate review.

## What is measured and what is not

Lightweight GLB JSON-header inspection finds31 primitives and1,385,233 source triangles in each current Glessner master/web. The master is200,174,356bytes, web44,836,544bytes; only their59KB/75KB JSON chunks were read, not a full binary decode. Large opaque granite/brick primitives are already eligible for the fallback; roof relief remains unchanged. Header/accessor/material metadata and source hashes are saved.

Six small native-kernel controls pass on a deterministic192-triangle fixture: both4m and2m preserve every triangle/winding/UV/confidence exactly once; input arrays stay unchanged; every2m child groups triangles from one4m parent, including negative coordinates and triangles crossing many grid boundaries; every child's bounding sphere contains its corners. These prove content/conservative-bounds behavior, not an actual Glessner cost result.

Three BatchedMesh uses per-piece **bounding spheres** (`three.core.js:27554`), not a box/frustum test. Child boxes being nested does not guarantee nested spheres, so actual submitted triangle counts can change either way. A fixture explicitly preserves that caveat. Tighter cells are a plausible lever for edge-of-view opaque work; savings, draw-call cost, allocation/boot overhead and pixels must be measured before adoption.

No defensible source-removal shortcut is established. The existing Glessner entry asset receipt reports thousands of “degenerate” faces only at a1mm measurement quantum, and explicitly says these are NOT zero-area source triangles; they include fine geometry and cannot be removed to meet a budget. Existing geometry research reports no coincident source faces. A future exact duplicate/zero-area scan would have to match all material/UV/normal/confidence attributes and exclude alpha-blended overlap; it was not run here. Do not treat quantized1mm counts as invisible work.

## Bounded adoption/measurement plan, only if latest actual overshoot is confirmed

1. Root finishes the latest merge/native derivation/publish and records one unchanged normal Full1904 spawn measurement. Bind the exact source/assets, pose, tier, DPR, actual loaded web hashes, page/request findings, colour/shadow counters, complete bounds and screenshot. Preserve all failures, including the prior people.json abort; change no assertions or budget.
2. On an explicitly granted exclusive slot, apply only this unique field in a reviewed isolated candidate, publish normally and repeat exactly that spawn. Require the real native budget to pass, with all source triangles/attributes still present. Record the actual driver calls as well as triangles: more partitions may cost draws even when they save triangles. Reject a candidate that only shifts the failure to calls/boot/memory or relies on altered pose/tier.
3. Reuse the normal Full Glessner inspection stands (Prairie front, north/service roof, courtyard, roofline and elevated/aloft view) for baseline/candidate comparisons. Require no lost visible surface/changed blended roof order or shadow artifact, identical asset/geometry totals and full instance bounds/feet/placement. A wider/aloft view must still draw every preserved piece; it cannot hide source geometry. Light/Balanced round-trip census stays exact because their branch did not change.
4. Run the existing spatial kernel and coalescing controls (`tools/check_spatial_batch.mjs`, `tools/test_batch_coalesce.mjs`) plus relevant normal native/published smoke coverage after adoption. Keep draw/triangle caps and source-camera/image gates unchanged. These checks have NOT been run here; all browser/gate/bake work awaits root authorization.

This one-field candidate is preferred over changing an asset or source contract. If actual latest spawn is within budget, no optimization is required for this blocker. If the candidate does not reduce actual work safely, preserve its result and stop rather than relaxing the cap or broadening into a refactor.
