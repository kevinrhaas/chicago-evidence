import os,pathlib,subprocess,json,hashlib,shutil,datetime
root=pathlib.Path('/tmp/st-mary-picture-20261025'); target=root/'site/4d'; out=pathlib.Path('/tmp/mary-merged-inactive-mirror-retirement-20261027T0119')
env=os.environ.copy(); n=int(env.get('GIT_CONFIG_COUNT','0'))
for key,value in [('gc.auto','0'),('maintenance.auto','false')]: env[f'GIT_CONFIG_KEY_{n}']=key;env[f'GIT_CONFIG_VALUE_{n}']=value;n+=1
env['GIT_CONFIG_COUNT']=str(n)
def git(*a):return subprocess.run(['git','-C',str(root),*a],env=env,text=True,capture_output=True,check=True).stdout
assert target.is_dir() and not target.is_symlink()
assert git('ls-files','--','site/4d')==''
ignore=git('check-ignore','-v','site/4d/index.html'); assert ignore
before={'head':git('rev-parse','HEAD'),'status':git('status','--porcelain=v1','--untracked-files=no')}
# Every readable live cwd/fd must be outside the retired generated mirror.
readers=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 for f in [p/'cwd',*(p/'fd').glob('*')]:
  try:s=os.readlink(f)
  except (OSError,PermissionError):continue
  if s==str(target) or s.startswith(str(target)+'/'):readers.append({'pid':p.name,'path':str(f),'target':s})
assert not readers,readers
items=[];raw=allocated=0
for base,dirs,files in os.walk(target,followlinks=False):
 for name in files:
  p=pathlib.Path(base)/name;s=p.lstat();items.append({'path':str(p.relative_to(target)),'size':s.st_size,'mode':oct(s.st_mode),'symlink':p.is_symlink()});raw+=s.st_size;allocated+=s.st_blocks*512
freebefore=shutil.disk_usage('/tmp').free
proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target':str(target),'reason':'Mary PR1334 actually merged d210; this ignored generated published mirror is inactive and reproducible with native publish.sh. Preserve all source/models/reference pictures/checkpoints/browser trust and protected caches. Recover TMP room for current Carpenter native scratch.','git_before':before,'ignore_rule':ignore.strip(),'readable_active_readers':readers,'files':items,'raw_bytes':raw,'allocated_bytes':allocated,'free_before':freebefore,'public_merged_source':'https://github.com/kevinrhaas/chicago/pull/1334','restore':'From unchanged worktree source: source /workspace/shared/resume-chicago-env.sh; unset GIT_NO_LAZY_FETCH CHICAGO_TICKETS_DIR; cd /tmp/st-mary-picture-20261025/chicago/4d; ./tools/publish.sh'}
(out/'BEFORE.json').write_text(json.dumps(proof,indent=2)+'\n')
shutil.rmtree(target)
after={'head':git('rev-parse','HEAD'),'status':git('status','--porcelain=v1','--untracked-files=no')};assert before==after
result={'status':'ONLY_IGNORED_INACTIVE_MERGED_MARY_SITE4D_RETIRED_PASS','free_after':shutil.disk_usage('/tmp').free,'actual_df_gain':shutil.disk_usage('/tmp').free-freebefore,'raw_bytes':raw,'allocated_bytes':allocated,'files':len(items),'source_head_status_unchanged':True,'only_target_absent':not target.exists(),'all_other_worktree_content_retained':True}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
