Recreate the ignored generated mirror from the unchanged merged Mary worktree using the native publisher:

```bash
source /workspace/shared/resume-chicago-env.sh
unset GIT_NO_LAZY_FETCH CHICAGO_TICKETS_DIR
cd /tmp/st-mary-picture-20261025/chicago/4d
./tools/publish.sh
```

The retired mirror contained only ignored generated output. Source, models, pictures, checkpoints and protected caches remain in place. Archive only the finite proof files in MANIFEST.json; mirror payloads are reproducible and intentionally excluded. The process check covered readable cwd/fd entries, subject to namespace/permission visibility.
