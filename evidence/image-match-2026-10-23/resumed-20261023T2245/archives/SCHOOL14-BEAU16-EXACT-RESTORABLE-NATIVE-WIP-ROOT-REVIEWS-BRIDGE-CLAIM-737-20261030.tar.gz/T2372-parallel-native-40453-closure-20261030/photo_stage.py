from pathlib import Path
import os,subprocess,json,hashlib,time,shutil
P=Path(__file__).resolve().parent;A=Path('/workspace/t2372-parallel-native-20261030/chicago/4d');TMP=Path('/workspace/t2372-tmp');pf=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert json.loads((P/'NATIVE-RESULT.json').read_bytes())['status']=='ACTUAL_SELECTED_NATIVE_SCHOOL_BUILD_WEB_COHERENT_1456_DEPENDENCY_PASS_WIP_ONLY'
assert not(P/'PHOTO-RESULT.json').exists();cam=A/'data/reference_views/chappel_infant_school/shore-drawing.json';match=cam.with_suffix('.match.json');side=A/'docs/RESEARCH/photo-match/chappel_infant_school/shore-drawing-side-by-side.jpg'
assert pf(cam)=='ca0926793cd9e12293b10693dd0e9bfcfce3ca2a0e16a85e3cfe670a1ed9aa28'
inputs={str(f):pf(f)for f in[cam,A/'assets/gltf/chappel_infant_school__log_1833.glb',A/'assets/web/chappel_infant_school__log_1833.glb',A/'tools/photo_match.mjs',A/'data/sources/eliza_chappel_school_shore_view.json']}
shutil.copyfile(match,P/'ACCEPTED-MATCH-BEFORE.json');shutil.copyfile(side,P/'ACCEPTED-SIDE-BEFORE.jpg')
e=dict(os.environ,TMPDIR=str(TMP),TMP=str(TMP),TEMP=str(TMP),PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',NODE_OPTIONS='--import='+str(P/'photo_http_provenance.mjs'))
argv=['python3','/workspace/shared/run-with-reaping.py',str(P/'PHOTO-REAPER.json'),'--','nice','-n','19','taskset','-c','2','node','tools/photo_match.mjs','data/reference_views/chappel_infant_school/shore-drawing.json'];t=time.monotonic()
with(P/'PHOTO.log').open('wb')as f:rc=subprocess.run(argv,cwd=A,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=360).returncode
r=json.loads((P/'PHOTO-REAPER.json').read_bytes());assert rc==0 and r['command_exit']==0 and r['all_children_reaped']is True
assert{f:pf(f)for f in inputs}==inputs
m=json.loads(match.read_bytes());old=json.loads((P/'ACCEPTED-MATCH-BEFORE.json').read_bytes());assert m['differences']==old['differences']and m['glb_sha256']==old['glb_sha256']and m['camera_sha256']==old['camera_sha256']and m['photo_sha256']==old['photo_sha256'];assert m['verdict']==old['verdict']=='matches'
shutil.copyfile(match,P/'ACTUAL-NATIVE.match.json');shutil.copyfile(side,P/'ACTUAL-NATIVE-side-by-side.jpg')
renders=list(TMP.glob('photo-match-*/shore-drawing-render.png'));assert len(renders)==1;shutil.copyfile(renders[0],P/'ACTUAL-NATIVE.png')
result=dict(status='ACTUAL_SELECTED_NATIVE_FIXED_CAMERA_CAPTURE_PASS_SAME_REVIEW_TUPLE_WIP_ONLY',seconds=time.monotonic()-t,actual_exit=rc,argv=argv,all_children_reaped=True,http_readback=pf(P/'PHOTO-HTTP-READBACK.json'),native_tool_source=inputs[str(A/'tools/photo_match.mjs')],camera_sha256=pf(cam),MASTER_sha256=inputs[str(A/'assets/gltf/chappel_infant_school__log_1833.glb')],side_by_side_sha256=pf(side),prior_reviewed_side_sha256=pf(P/'ACCEPTED-SIDE-BEFORE.jpg'),side_bytes_identical=pf(side)==pf(P/'ACCEPTED-SIDE-BEFORE.jpg'),seven_dispositions_preserved=len(m['differences'])==7,neutral_common_grade_only=True,app_terrain_ground_walk_BOTH_still_owed=True,no_original_DONE=True)
(P/'PHOTO-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
