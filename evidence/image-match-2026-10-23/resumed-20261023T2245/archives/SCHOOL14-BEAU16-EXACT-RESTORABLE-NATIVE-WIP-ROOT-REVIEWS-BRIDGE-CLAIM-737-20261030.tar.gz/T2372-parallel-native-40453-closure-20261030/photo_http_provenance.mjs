// External read-only provenance preflight. The native tool and renderer remain unchanged.
import http from 'node:http';import fs from 'node:fs';import crypto from 'node:crypto';
const P='/workspace/T2372-parallel-native-40453-closure-20261030';
const R='/workspace/t2372-parallel-native-20261030/chicago/4d';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
if(process.cwd()!==R)throw Error('Unexpected native photo cwd');
const original=http.Server.prototype.listen;
http.Server.prototype.listen=function(...args){
 const cb=args.at(-1);if(typeof cb!=='function')throw Error('Unexpected native listen signature');
 args[args.length-1]=async(...eventArgs)=>{
  try{
   const a=this.address();if(a.address!=='127.0.0.1'||!Number.isInteger(a.port)||a.port<=0)throw Error('Native photo server is not unique loopback');
   const base=`http://127.0.0.1:${a.port}`;const rows=[];
   for(const rel of ['assets/gltf/chappel_infant_school__log_1833.glb','tools/photo_match.mjs']){
    const res=await fetch(`${base}/${rel}`);if(res.status!==200)throw Error(`Native readback${res.status}`);const b=Buffer.from(await res.arrayBuffer());
    const expected=sha(fs.readFileSync(`${R}/${rel}`));if(sha(b)!==expected)throw Error('Native HTTP root/model differs from selected clone');rows.push({path:rel,bytes:b.length,sha256:expected});
   }
   fs.writeFileSync(`${P}/PHOTO-HTTP-READBACK.json`,JSON.stringify({status:'ACTUAL_NATIVE_RANDOM_LOOPBACK_CLONE_ROOT_MODEL_READBACK_PASS',cwd:process.cwd(),server:a,rows,native_tool_unmodified:true},null,2)+'\n',{flag:'wx'});
   cb(...eventArgs);
  }catch(e){console.error(e);process.exit(1);}
 };
 return original.apply(this,args);
};
