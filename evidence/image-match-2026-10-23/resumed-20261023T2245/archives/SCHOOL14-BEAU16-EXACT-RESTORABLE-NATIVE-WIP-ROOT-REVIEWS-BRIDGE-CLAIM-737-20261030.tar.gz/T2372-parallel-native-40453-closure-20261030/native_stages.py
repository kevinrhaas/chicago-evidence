from pathlib import Path
import os,subprocess,json,hashlib,time,sys
P=Path(__file__).resolve().parent; R=Path('/workspace/t2372-parallel-native-20261030');A=R/'chicago/4d';KEY='chappel_infant_school__log_1833.glb'
sha=lambda b:hashlib.sha256(b).hexdigest();pf=lambda p:sha(Path(p).read_bytes());enc=lambda x:json.dumps(x,sort_keys=True,separators=(',',':')).encode()
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip()=='40453bde8ba1812925d61fef118782a30323f98e'
assert pf(A/'data/structures/chappel_infant_school.json')=='bca1984c8d1993e107d502930380e5cec5b3443fca97249fbab7e6d8eac6e161'
assert pf(A/'generators/archetypes/log_dwelling.py')=='68199bef6a6bbe064c9fb6d4113629d7bf5961be8cefaa6b8b864b766c550716'
assert pf(A/'generators/archetypes/log_dwelling_params.py')=='fa27dffc479a72bfffea892631be8f3156df373d343fa536a22ae4f55c57fbad'
assert not(P/'NATIVE-RESULT.json').exists()
TMP=Path('/workspace/t2372-tmp');TMP.mkdir(exist_ok=False)
e=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',TMPDIR=str(TMP),TMP=str(TMP),TEMP=str(TMP),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
sys.path.insert(0,str(A/'generators'));import mesh_inputs
record=json.loads((A/'data/structures/chappel_infant_school.json').read_bytes());recipe=mesh_inputs.structure_inputs_sha(record,record['phases'][0]);doc=mesh_inputs.structure_inputs_doc(record,record['phases'][0]);(P/'PROSPECTIVE-RECIPE.json').write_text(json.dumps(dict(recipe_sha256=recipe,recipe_doc=doc),indent=2)+'\n')
commands=[('BUILD',['/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender','--background','--factory-startup','--threads','1','--python-expr','import sys; sys.dont_write_bytecode=True','--python',str(A/'generators/build.py'),'--','--only','chappel_infant_school','--scene','1835','--wrote',str(P/'WROTE.txt')]),('WEB',['bash','tools/web_derivatives.sh','--only',KEY])]
stages=[]
for name,cmd in commands:
 assert os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize>=1073741824
 argv=['python3','/workspace/shared/run-with-reaping.py',str(P/(name+'-REAPER.json')),'--','nice','-n','19','taskset','-c','2',*cmd];t=time.monotonic()
 with(P/(name+'.log')).open('wb')as f:rc=subprocess.run(argv,cwd=A,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=240).returncode
 reap=json.loads((P/(name+'-REAPER.json')).read_bytes());assert rc==0 and reap['command_exit']==0 and reap['all_children_reaped']is True
 stages.append(dict(stage=name,seconds=time.monotonic()-t,actual_exit=rc,argv=argv,reaper_sha256=pf(P/(name+'-REAPER.json'))))
assert(P/'WROTE.txt').read_text().splitlines()==[KEY]
expected={'MASTER':'fb141fef3f348b494ffbf1bc2479427d0cec499001605cdcb34ce52c93c0787a','WEB':'f120aa9abc970bb5b0b28f82c5fd176b268ba67923cea9b31de9967c8c9bf804'}
actual={'MASTER':pf(A/'assets/gltf'/KEY),'WEB':pf(A/'assets/web'/KEY)};assert actual==expected,(actual,expected)
before=json.loads((P/'REGISTRIES-BEFORE.json').read_bytes())
for n,table in [('manifest.json','assets'),('manifest.web.json','masters')]:
 old=before[n];new=json.loads((A/'assets'/n).read_bytes());assert enc([(k,v)for k,v in old[table].items()if k!=KEY])==enc([(k,v)for k,v in new[table].items()if k!=KEY]);assert enc({k:v for k,v in old.items()if k!=table})==enc({k:v for k,v in new.items()if k!=table})
 if table=='assets':assert new[table][KEY]['inputs_sha256']==recipe
 else:assert new[table][KEY]==actual['MASTER']
result=dict(status='ACTUAL_SELECTED_NATIVE_SCHOOL_BUILD_WEB_COHERENT_1456_DEPENDENCY_PASS_WIP_ONLY',base='40453bde8ba1812925d61fef118782a30323f98e',dependency='3746b23bf1298c34a29946b4cdb6ee2d98abff8f',future_canonical_PR_base='UNKNOWN',stages=stages,recipe_sha256=recipe,actual=actual,foreign_registry_rows_order_outer_metadata_exact=True,no_commit_PR_fullgate_or_DONE=True)
(P/'NATIVE-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
