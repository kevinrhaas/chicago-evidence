# Current fort-family scope

All25 recipes require a real canonical refresh if these two generator files are adopted. Seven records opt in;18 retain exact CPU raw geometry, materials, confidence and tone. No master/manifest is included in the authored patch.

| Structure | Phase | Scope |
|---|---|---|
| `chicago_lighthouse_1832` | `tower_1832` | exact old default |
| `first_fort_dearborn_blockhouse_nw` | `first_fort_1803` | five gallery/front or two chimney changes |
| `first_fort_dearborn_blockhouse_se` | `first_fort_1803` | five gallery/front or two chimney changes |
| `first_fort_dearborn_commanding_officers_barracks` | `first_fort_1803` | five gallery/front or two chimney changes |
| `first_fort_dearborn_flagstaff` | `first_fort_1803` | exact old default |
| `first_fort_dearborn_magazine` | `first_fort_1803` | exact old default |
| `first_fort_dearborn_north_range` | `first_fort_1803` | five gallery/front or two chimney changes |
| `first_fort_dearborn_officers_barracks` | `first_fort_1803` | five gallery/front or two chimney changes |
| `first_fort_dearborn_parade` | `first_fort_1803` | exact old default |
| `first_fort_dearborn_soldiers_barracks_se` | `first_fort_1803` | five gallery/front or two chimney changes |
| `first_fort_dearborn_soldiers_barracks_sw` | `first_fort_1803` | five gallery/front or two chimney changes |
| `fort_dearborn_artillery_house` | `log_1816` | exact old default |
| `fort_dearborn_barracks` | `log_1816` | exact old default |
| `fort_dearborn_blockhouse` | `log_1816` | exact old default |
| `fort_dearborn_commandants_quarters` | `brick_1816` | exact old default |
| `fort_dearborn_flagstaff` | `staff_1833_37` | exact old default |
| `fort_dearborn_guard_house` | `log_1816` | exact old default |
| `fort_dearborn_magazine` | `brick_1816` | exact old default |
| `fort_dearborn_officers_quarters` | `log_1816` | exact old default |
| `fort_dearborn_parade` | `parade_1816` | exact old default |
| `fort_dearborn_root_house` | `cellar_1816` | exact old default |
| `fort_dearborn_root_house_b` | `cellar_1816_b` | exact old default |
| `fort_dearborn_store_house` | `log_1816` | exact old default |
| `fort_dearborn_sutlers_store` | `log_1816` | exact old default |
| `lake_house_construction` | `shell_1835` | exact old default |
