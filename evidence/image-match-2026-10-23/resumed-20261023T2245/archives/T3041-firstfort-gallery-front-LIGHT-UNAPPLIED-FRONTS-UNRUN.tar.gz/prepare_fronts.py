"""Future heavy-granted preparation only; no exporter/producer/compiler stage."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,sys
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d')
if __import__('os').environ.get('CHICAGO_HEAVY_SLOT')!='T3041_FRONTS':raise SystemExit('Refusing: root must explicitly grant T3041_FRONTS before preparing/rendering fixtures')
subprocess.run([sys.executable,str(H/'verify_current.py')],check=True)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f');run=H/'front-runs'/stamp;run.mkdir(parents=True,exist_ok=False);bindings=json.loads((H/'front-bindings.json').read_text())
asset_names=[]
for kind,heldkind in [('baseline','baseline'),('proposed','galleries')]:
 root=run/kind;asset_names=[]
 historical_manifest=Path(bindings['fronts'][0]['held_actual_masters'][heldkind]['manifest_path'])
 manifest=json.loads(historical_manifest.read_text())
 for rel in ['tools/photo_match.mjs','tools/photo_match_group.mjs','renderers/web/js/keith-stone.js']:
  p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,p)
 vendor=root/'renderers/web/vendor/three-0.185.1';vendor.parent.mkdir(parents=True,exist_ok=True);vendor.symlink_to(R/'renderers/web/vendor/three-0.185.1',target_is_directory=True)
 deps=Path('/workspace/node_modules');assert deps.is_dir();(root/'node_modules').symlink_to(deps,target_is_directory=True)
 scene=root/'data/scenes/1812.json';scene.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/'data/scenes/1812.json',scene)
 source=root/'data/sources/whistler_1808_fort_dearborn_draught.json';source.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/'data/sources/whistler_1808_fort_dearborn_draught.json',source)
 for row in bindings['fronts']:
  state=Path(row['held_actual_masters'][heldkind]['path']).parents[2]
  for rel in ['data/structures/'+row['structure_id']+'.json','data/sidecars/1812/'+row['structure_id']+'.json']:
   dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(state/rel,dest)
  src=Path(row['held_actual_masters'][heldkind]['path']);asset=src.name;p=root/'assets/gltf'/asset;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,p);asset_names.append(asset)
  cam=root/'research-cameras'/(row['part']+'.json');cam.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(row['bound_camera'],cam)
  photo=root/'source-panels'/Path(row['source_crop']).name;photo.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(row['source_crop'],photo)
 (root/'assets/manifest.json').write_text(json.dumps({**manifest,'assets':{a:manifest['assets'][a] for a in sorted(set(asset_names))}},indent=2)+'\n')
 # Preserve the actual historic native recipe entries for these held masters.
 # They are not relabelled with current/narrow-module recipe hashes.
 (root/'HELD-RESEARCH-MASTERS-NOT-CANONICAL.txt').write_text('Five held actual masters copied for unrun front diagnostics; no export, recipe restamping, producer or compiler run.\n')
(run/'scope.json').write_text(json.dumps({'held_actual_masters_per_state':5,'new_exports':0,'native_comparisons_planned':10,'fronts':[r['part'] for r in bindings['fronts']],'camera_status':'UNSOLVED_FOLDED_ELEVATION_DIAGNOSTICS_NOT_ACCEPTED'},indent=2)+'\n');(H/'latest-front-run.txt').write_text(str(run)+'\n');print(run)
