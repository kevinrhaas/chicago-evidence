"""First-fort-only proposal; outputs under this owned/tmp directory, never applies."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,shutil,subprocess,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago');F=Path('/tmp/chicago-next-model/T-2387-face-layout-next');B=Path('/tmp/chicago-next-model/T-3041-build-resume-20261023/closed-build-evidence');OLD=Path('/tmp/chicago-next-model/fort-adoption-composer');sha=lambda b:hashlib.sha256(b).hexdigest();prefix='chicago/4d/'
assert H.is_relative_to(Path('/tmp'))
expected={'generators/archetypes/fort_structure.py':'d6b855f1e2c8052ce8d1d1fcee0fcad556eb280c8297a2edb998ffb4744efd76','generators/archetypes/fort_structure_params.py':'eeabc1cf39cc7b86fdbfa1d5015f4f2dfa165ef3cfdb3a38dc87a8b68d6e1a61','generators/archetypes/facade_openings.py':'cc46aaba7fe0caa134cbb2aecbc4daaec4b134b4265f11747d5a16e8cdafc6a1','tools/generate_business_signboards.py':'ed81a7dac49697556d2ccb9c7562ff9b183e59717f5117bb0d21312fbe3fa30c'}
for p,s in expected.items():assert sha((R/prefix/p).read_bytes())==s,(p,'new author changes require explicit recomposition')
outputs={};baseline={};strategies={}
def put(rel,new,strategy):
 rel=prefix+rel;old=(R/rel).read_bytes() if (R/rel).exists() else None;baseline[rel]=old;outputs[rel]=new if isinstance(new,bytes) else new.encode();strategies[rel]=strategy

def nodes(path):return {n.name:n for n in ast.parse(path.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def source_node(path,node):return ast.get_source_segment(path.read_text(),node)
pr=Path('generators/archetypes/fort_structure_params.py');gr=Path('generators/archetypes/fort_structure.py');fpr=F/'candidate'/prefix/pr;fgr=F/'candidate'/prefix/gr
s=(R/prefix/pr).read_text();s=s.replace('from dataclasses import dataclass, field','import math\nfrom dataclasses import dataclass, field');needle='"upper_overhang_m", "lantern",';assert s.count(needle)==1;s=s.replace(needle,needle+' "gallery_storeys", "face_openings",')
needle='    confidence: dict = field(default_factory=dict)';assert s.count(needle)==1;s=s.replace(needle,'    # Opt-in first-fort details; preserve every legacy positional argument.\n    gallery_storeys: int = field(default=1, kw_only=True)\n    face_openings: list | None = field(default=None, kw_only=True)\n\n'+needle)
cls=nodes(fpr)['FortStructureParams'];validate=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='validate');blocks=[]
for node in validate.body:
 text=source_node(fpr,node)
 if isinstance(node,ast.If) and ('self.face_openings' in text or 'self.gallery_storeys' in text):blocks.append('        '+text+'\n')
assert len(blocks)==3
s=s.replace('    def validate(self) -> None:\n','    def validate(self) -> None:\n'+''.join(blocks),1)
needle='        gallery=bool(val("gallery", False)),';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        gallery_storeys=val("gallery_storeys", 1),\n        face_openings=val("face_openings", None),')
fn=nodes(fpr)
for name in ['wall_openings','front_wall']:s+='\n\n'+source_node(fpr,fn[name])+'\n'
put(str(pr),s,'only two keyword-only fields, their validation/consumption and shared explicit front')
s=(R/prefix/gr).read_text();s=s.replace('from archetypes.fort_structure_params import FortStructureParams','from archetypes.fort_structure_params import FortStructureParams, wall_openings')
oldnodes=nodes(R/prefix/gr);newnodes=nodes(fgr)
for name in ['_openings','_gallery']:
 old=source_node(R/prefix/gr,oldnodes[name]);new=source_node(fgr,newnodes[name]);assert s.count(old)==1;s=s.replace(old,new)
for name in ['_gallery_two_storeys','_explicit_openings']:s+='\n\n'+source_node(fgr,newnodes[name])+'\n'
put(str(gr),s,'only first-fort gallery and explicit openings paths; no tower/cupola/Lake House changes')
for rel in ['generators/archetypes/facade_openings.py','tools/generate_business_signboards.py']:
 put(rel,(F/'candidate'/prefix/rel).read_bytes(),'existing narrow fort front resolver registration')
ids=['first_fort_dearborn_'+x for x in ['north_range','soldiers_barracks_sw','soldiers_barracks_se','officers_barracks','commanding_officers_barracks','blockhouse_nw','blockhouse_se']]
record_deltas=[]
for sid in ids:
 rel='data/structures/'+sid+'.json';before=json.loads((B/'baseline'/rel).read_text());proposed=json.loads((B/'galleries'/rel).read_text());current=json.loads((R/prefix/rel).read_text());out=copy.deepcopy(current);deltas=[]
 for oldph in before['phases']:
  nph=next(p for p in proposed['phases'] if p['id']==oldph['id']);oph=next(p for p in out['phases'] if p['id']==oldph['id'])
  for key in ['gallery_storeys','face_openings','chimneys']:
   old,new=oldph['form'].get(key),nph['form'].get(key)
   if old==new:continue
   assert oph['form'].get(key) in [old,new],(sid,key,'independent intended-leaf edit')
   oph['form'][key]=copy.deepcopy(new);deltas.append({'phase':oldph['id'],'attribute':key})
 # No phase/day/placement/height/roof/cupola change is admitted.
 assert [p['id'] for p in out['phases']]==[p['id'] for p in current['phases']]
 for a,b in zip(current['phases'],out['phases']):
  for k in a:
   if k!='form':assert a[k]==b[k]
 put(rel,json.dumps(out,ensure_ascii=False,indent=2)+'\n','guarded target-form leaf merge onto current record')
 record_deltas.append({'structure_id':sid,'changes':deltas})
# The sole new source actually needed by the five gallery records.
rel='data/sources/currey_1912_first_fort_birdseye.json';src=Path('/tmp/chicago-next-model/fort-selective-integration/payload/proposed')/prefix/rel;j=json.loads(src.read_text());j['locator']='Printed page 27, numbered bird’s-eye reconstruction; caption and list of illustrations in the inspected Gutenberg edition.'
assert not (R/prefix/rel).exists(),'existing Currey source requires field review, not replacement'
put(rel,json.dumps(j,ensure_ascii=False,indent=2)+'\n','register independently inspected1912 public-domain plate; no Getty derivation')
# Three append-only admission fragments, scoped to the seven records only.
frags=[]
for name in ['first-fort-galleries.md','first-fort-face-layout.md','first-fort-chimneys-3041.md']:
 text=(OLD/'normalized-liberty-fragments'/name).read_text();dest=H/'liberty-fragments'/name;dest.parent.mkdir(exist_ok=True);dest.write_text(text);frags.append(text.strip())
ledger=(R/prefix/'docs/LIBERTIES.md').read_text();newids=[re.search(r'^### (\S+)',text,re.M)[1] for text in frags]
for lid in newids:assert re.search(r'^### '+re.escape(lid)+r'\s',ledger,re.M) is None,('existing admission needs review',lid)
append='\n\n## Per-subject liberties\n\n'+'\n\n'.join(frags)+'\n';put('docs/LIBERTIES.md',ledger+append,'append three exact first-fort admissions to current prefix')
# New prose follows the existing READ declaration policy, never an ignored-field escape.
keys=json.loads((R/prefix/'data/reconstruction/name_pool_keys.json').read_text());read=keys['read']['structures'];ignored=keys.get('ignored',{}).get('structures',{});added=[]
def leaves(n,p=''):
 if isinstance(n,dict):
  for k,v in n.items():yield from leaves(v,p+'.'+k if p else k)
 elif isinstance(n,list):
  for v in n:yield from leaves(v,p+'[]')
 elif isinstance(n,str):yield p,n
for rel,data in list(outputs.items()):
 if '/data/structures/' not in rel:continue
 for key,text in leaves(json.loads(data)):
  if re.search(r'\b[A-Z][a-z]{2,}\b',text) and key not in read and key not in ignored:read.append(key);added.append(key)
if added:put('data/reconstruction/name_pool_keys.json',json.dumps(keys,ensure_ascii=False,indent=2)+'\n','append missing new note READ declarations only')
manifest=json.loads((R/prefix/'assets/manifest.json').read_text())['assets'];scope=[]
for asset,row in sorted(manifest.items()):
 if row.get('archetype')!='fort_structure':continue
 scope.append({'asset':asset,'structure_id':row['structure_id'],'phase_id':row['phase_id'],'current_master_sha256':sha((R/prefix/'assets/gltf'/asset).read_bytes()),'target_record':row['structure_id'] in ids})
assert len(scope)==25 and len([r for r in scope if r['target_record']])==7
patch='';rows=[]
for rel,new in outputs.items():
 old=baseline[rel];p=H/'candidate'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(new)
 if old is not None:
  b=H/'baseline'/rel;b.parent.mkdir(parents=True,exist_ok=True)
  # Full ledger is an exact-prefix guard, not a duplicated historical restoration.
  if not rel.endswith('docs/LIBERTIES.md'):b.write_bytes(old)
 if old!=new:
  patch+='diff --git a/'+rel+' b/'+rel+'\n'+('new file mode 100644\n' if old is None else '')
  patch+=''.join(difflib.unified_diff((old or b'').decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel if old is not None else '/dev/null',tofile='b/'+rel))
 rows.append({'path':rel,'current_sha256':sha(old) if old is not None else None,'candidate_sha256':sha(new),'strategy':strategies[rel]})
(H/'first-fort-only.patch').write_text(patch);(H/'review-manifest.json').write_text(json.dumps({'source_head':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'files':rows,'family':scope,'record_deltas':record_deltas,'liberty_ids':newids,'name_pool_read_paths':added,'no_canonical_writes':True,'not_adopted':True,'no_new_export_or_browser':True},indent=2)+'\n');(H/'structure-ids.txt').write_text(','.join(r['structure_id'] for r in scope)+'\n')
subprocess.run(['git','-C',str(R),'apply','--check',str(H/'first-fort-only.patch')],check=True)
print(json.dumps({'candidate_files':len(rows),'target_records':len(ids),'family':len(scope),'new_note_READ_paths':added,'patch_apply_check':'passed','root_writes':False},indent=2))
