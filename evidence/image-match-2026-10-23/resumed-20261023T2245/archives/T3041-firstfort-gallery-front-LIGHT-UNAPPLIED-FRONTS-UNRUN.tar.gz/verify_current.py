"""Read-only guards; never applies or refreshes an artifact."""
from pathlib import Path
import hashlib,json,subprocess
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago');D=R/'chicago/4d';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
m=json.loads((H/'review-manifest.json').read_text())
for row in m['files']:
 assert sha(R/row['path'])==row['current_sha256'],row['path']+':current authored preimage changed; rematerialize/review'
 assert sha(H/'candidate'/row['path'])==row['candidate_sha256'],row['path']+':candidate changed'
for row in json.loads((H/'read-only-dependencies.json').read_text())['files']:assert sha(D/row['path'])==row['sha256'],row['path']+':CPU/render dependency changed; rerun scoped proof'
live={(asset,r['structure_id'],r['phase_id']) for asset,r in json.loads((D/'assets/manifest.json').read_text())['assets'].items() if r.get('archetype')=='fort_structure'};expected={(r['asset'],r['structure_id'],r['phase_id']) for r in m['family']};assert live==expected,'Fort25 membership changed'
for row in m['family']:assert sha(D/'assets/gltf'/row['asset'])==row['current_master_sha256'],row['asset']+':master changed'
for row in json.loads((H/'front-bindings.json').read_text())['fronts']:
 assert sha(Path(row['bound_camera']))==row['bound_camera_sha256'];assert sha(Path(row['source_crop']))==row['source_crop_sha256']
 for master in row['held_actual_masters'].values():
  assert sha(Path(master['path']))==master['sha256']
  assert sha(Path(master['manifest_path']))==master['manifest_sha256']
  for key in ['record','sidecar']:assert sha(Path(master[key+'_path']))==master[key+'_sha256']
subprocess.run(['git','-C',str(R),'apply','--check',str(H/'first-fort-only.patch')],check=True)
print('PASS:14 authored preimages/candidates,25 family/master guards,38 CPU/render dependencies,5 camera/source/held-master bindings; patch applies. No writes.')
