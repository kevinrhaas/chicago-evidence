from pathlib import Path
from types import SimpleNamespace
import ast,copy,hashlib,importlib.util,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d');C=H/'candidate/chicago/4d';S=H/'proof-shadow';S.mkdir(exist_ok=True)
def load(p,name):
 sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m
overrides={str(p.relative_to(C)):p for p in C.rglob('*') if p.is_file()}
for rel in ['tools/compile_liberties.py','tools/validate.py','tools/replace_invented_residents.py']:
 p=H/'driver-copies'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,p);overrides[rel]=p
def mirror(src,dst,prefix=''):
 dst.mkdir(exist_ok=True);names={p.name for p in src.iterdir()}|{k[len(prefix):].split('/')[0] for k in overrides if k.startswith(prefix)}
 for name in names:
  rel=prefix+name;sp=src/name;dp=dst/name
  if rel in overrides:
   if dp.is_symlink():dp.unlink()
   shutil.copy2(overrides[rel],dp)
  elif any(k.startswith(rel+'/') for k in overrides):
   if dp.is_symlink():dp.unlink()
   mirror(sp,dp,rel+'/')
  elif not dp.exists() and not dp.is_symlink():dp.symlink_to(sp,target_is_directory=sp.is_dir())
mirror(R,S);sys.path[:0]=[str(S/'tools'),str(S/'generators')]
import jsonschema
manifest=json.loads((H/'review-manifest.json').read_text());structures={p.stem:json.loads(p.read_text()) for p in (S/'data/structures').glob('*.json')};family={r['structure_id']:structures[r['structure_id']] for r in manifest['family']}
for p in(C/'data/structures').glob('*.json'):jsonschema.validate(json.loads(p.read_text()),json.loads((S/'data/structures.schema.json').read_text()))
source=json.loads((C/'data/sources/currey_1912_first_fort_birdseye.json').read_text());jsonschema.validate(source,json.loads((S/'data/source.schema.json').read_text()))
lib=load(S/'tools/compile_liberties.py','narrow_fort_liberty_parser');doc,problems=lib.build();assert not problems,problems[:10]
entries=[e for e in doc['liberties'] if e['id'] in manifest['liberty_ids']];assert len(entries)==3 and all(e['section']!='resolved' for e in entries)
claims=[]
for e in entries:
 for c in e['covers']:
  assert c['domain']=='structure';rec=structures[c['structure']];node=next(ph for ph in rec['phases'] if ph['id']==c['phase'])
  for key in c['aspect'].split('.'):node=node[key]
  assert node['confidence'] in ['inferred','reconstructed'];claims.append(c)
assert len(claims)==12
params=load(C/'generators/archetypes/fort_structure_params.py','archetypes.fort_structure_params');import archetypes;archetypes.fort_structure_params=params
val=load(S/'tools/validate.py','narrow_fort_validator');rep=val.Report();val.check_liberties_coverage(family,doc,rep,consumed={'fort_structure':params.CONSUMED},forward_only=True);assert not rep.errors,rep.errors[:10]
facade=load(C/'generators/archetypes/facade_openings.py','narrow_fort_facade')
def funcs(path):return {n.name:n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
fns=funcs(C/'tools/generate_business_signboards.py');ns={'STRUCTURES':C/'data/structures','_RESOLVERS':{'fort_structure':params.from_phase},'_load':lambda p:json.loads(p.read_text()),'facade_openings':facade,'TARGET_DATE':'1812-08-14'};exec(compile('from __future__ import annotations\n'+ast.unparse(fns['_front_wall']),'<actual business-sign front reader>','exec'),ns)
fronts=[]
for row in manifest['record_deltas']:
 sid=row['structure_id'];rec=structures[sid];p=params.from_phase(rec['phases'][0],rec)
 if not any(x['attribute']=='face_openings' for x in row['changes']):continue
 front=ns['_front_wall'](sid);assert front==facade.front_wall('fort_structure',p)==params.front_wall(p);assert len(front['openings']) in [8,10]
 fronts.append(sid)
entrance=funcs(R/'tools/generate_entrances.py');ens={'gbs':SimpleNamespace(_front_wall=ns['_front_wall'],facade_openings=facade),'ENTRANCE_KINDS':('door','shop_door','open_bay'),'GROUND_Z_M':.30,'OPENING_GAP_M':.15,'SHOPFRONT':frozenset({'shop_door','show_window'})}
for name in ['front_doors','merged_openings']:exec(compile('from __future__ import annotations\n'+ast.unparse(entrance[name]),'<actual entrance reader>','exec'),ens)
for sid in fronts:
 doors,reader=ens['front_doors']({'id':sid,'archetype':'fort_structure'});assert len(doors)==1 and reader=='facade_openings.fort_structure';assert ens['merged_openings']({'id':sid,'archetype':'fort_structure'})==[]
ns['TARGET_DATE']='1835-07-01'
for sid in fronts:assert ns['_front_wall'](sid) is None and ens['front_doors']({'id':sid,'archetype':'fort_structure'})==([],None)
for row in manifest['family']:
 rec=json.loads((R/'data/structures'/(row['structure_id']+'.json')).read_text());p=params.from_phase(next(ph for ph in rec['phases'] if ph['id']==row['phase_id']),rec);assert facade.front_wall('fort_structure',p) is None
pictures=load(R/'tools/compile_pictures.py','narrow_fort_pictures');sources={p.stem:json.loads(p.read_text()) for p in (S/'data/sources').glob('*.json')};texts={sid:json.dumps(structures[sid]) for sid in fronts};cards=pictures.derive(None,'',sources,texts,{'1812':fronts},{})
for sid in fronts:assert any(e['id']==source['id'] and e['creator'] and e['url']==source['url'] for e in cards['1812']['by_structure'][sid])
r=subprocess.run([sys.executable,str(S/'tools/replace_invented_residents.py'),'--self-test'],capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});(H/'name-pool-cli-selftest.log').write_text(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr)[-4000:]
# Every property was actually checked above; no declaration bypass or policy change.
report={'status':'PASS','full_proposed_ledger_entries':doc['count'],'native_parser_problems':0,'new_admissions':manifest['liberty_ids'],'exact_reverse_checked_claims':len(claims),'actual25_family_forward_coverage_errors':0,'seven_structure_and_one_source_schemas_pass':True,'shared_facade_signboard_entrance_readers_1812_fivefronts_pass':True,'existing1835_entrance_producer_excludes_all5':True,'legacy_all25_fronts_stay_unread':True,'Currey_source_credit_URL_reachable_from_all5_Images_tabs_data':True,'source_picture_delivery':'existing link-only source entry, not a new image-store upload or screenshot proof','actual_name_pool_CLI_raw_and_parsed_selftest':'PASS; full transcript retained','only_new_note_READ_declarations':manifest['name_pool_read_paths'],'canonical_writes':False,'no_browser_export_fullgate':True}
(H/'source-consumer-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
