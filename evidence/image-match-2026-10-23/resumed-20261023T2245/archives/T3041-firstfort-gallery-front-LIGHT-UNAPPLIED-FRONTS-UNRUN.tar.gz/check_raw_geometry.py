"""Actual generator/mesh calls collected on CPU. No bpy runtime or exports."""
from pathlib import Path
from dataclasses import asdict,replace
from types import ModuleType
import ast,copy,hashlib,importlib.util,inspect,json,math,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d');C=H/'candidate/chicago/4d';B=H/'baseline/chicago/4d';F=Path('/tmp/chicago-next-model/T-3041-build-resume-20261023/closed-build-evidence/galleries');sys.path.insert(0,str(R/'generators'))
# Import-time bpy is a type-context dependency only. Fail if any runtime API is accessed.
class ForbiddenBpy(ModuleType):
 def __getattr__(self,name):raise AssertionError('CPU proof attempted bpy runtime: '+name)
sys.modules['bpy']=ForbiddenBpy('bpy')
import archetypes

def load(path,name):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m

def collect(self,materials=None):
 mats=list(materials or []);base=len(mats)
 for name,(_idx,rgba,rough) in sorted(self.named.items(),key=lambda kv:kv[1][0]):mats.append({'name':name,'rgba':list(rgba),'roughness':rough})
 return {'verts':self.verts,'faces':self.faces,'confidence':self.conf,'tone':self.tone,'material_index':[base+(mi-self.NAMED_BASE) if mi>=self.NAMED_BASE else mi for mi in self.mat_index],'materials':mats}

def generator(root,label):
 p=load(root/'generators/archetypes/fort_structure_params.py','archetypes.fort_structure_params');setattr(archetypes,'fort_structure_params',p)
 g=load(root/'generators/archetypes/fort_structure.py',label);g.TonedBuilder.to_object=collect
 g.simple_material=lambda name,rgba=(.8,.8,.8,1),roughness=.75:{'name':name,'rgba':list(rgba),'roughness':roughness}
 return p,g
old,og=generator(B,'fort_cpu_before');new,ng=generator(C,'fort_cpu_after');ref,rg=generator(F,'fort_cpu_rendered_gallery_reference')
assert old.FortStructureParams.__match_args__==new.FortStructureParams.__match_args__
assert len(old.FortStructureParams.__match_args__)==16
osig,nsig=inspect.signature(old.FortStructureParams),inspect.signature(new.FortStructureParams)
assert set(nsig.parameters)-set(osig.parameters)=={'gallery_storeys','face_openings'}
for k,v in osig.parameters.items():assert v==nsig.parameters[k],k
assert nsig.parameters['gallery_storeys'].kind==nsig.parameters['face_openings'].kind==inspect.Parameter.KEYWORD_ONLY
assert nsig.parameters['gallery_storeys'].default==1 and nsig.parameters['face_openings'].default is None
assert new.CONSUMED==old.CONSUMED|{'gallery_storeys','face_openings'}
assert not ({'lantern_profile','cupola','tower_diameter_m','tower_profile','tower_openings'}&new.CONSUMED)
def digest(raw):return hashlib.sha256(json.dumps(raw,separators=(',',':'),sort_keys=True).encode()).hexdigest()
def params(mod,rec,phase):return mod.from_phase(next(p for p in rec['phases'] if p['id']==phase),rec)
def build(mod,g,rec,row):return g.build(params(mod,rec,row['phase_id']),row['asset'].removesuffix('.glb'))
manifest=json.loads((H/'review-manifest.json').read_text());rows=[];targets=[]
for row in manifest['family']:
 rec=json.loads((R/'data/structures'/(row['structure_id']+'.json')).read_text());a,b=params(old,rec,row['phase_id']),params(new,rec,row['phase_id']);d=asdict(b);assert d.pop('gallery_storeys')==1 and d.pop('face_openings') is None;assert d==asdict(a)
 legacy=new.FortStructureParams(*[getattr(a,k) for k in a.__match_args__]);legacy.validate();d=asdict(legacy);d.pop('gallery_storeys');d.pop('face_openings');assert d==asdict(a)
 for name,prop in vars(old.FortStructureParams).items():
  if isinstance(prop,property):assert getattr(a,name)==getattr(b,name)
 before,default=build(old,og,rec,row),build(new,ng,rec,row);assert before==default,(row['structure_id'],'old default raw vertex/face/material/confidence/tone differs')
 prop=C/'data/structures'/(row['structure_id']+'.json');candidate=json.loads(prop.read_text()) if prop.exists() else rec;after=build(new,ng,candidate,row)
 if not row['target_record']:assert before==after,(row['structure_id'],'non-target changed')
 else:
  reference=json.loads((F/'data/structures'/(row['structure_id']+'.json')).read_text());expected=build(ref,rg,reference,row);assert after==expected,(row['structure_id'],'narrow helper differs from actual rendered gallery prototype')
  assert before!=after
  if 'blockhouse' not in row['structure_id']:
   p=params(new,candidate,row['phase_id']);front=new.front_wall(p);per=5 if row['structure_id'].endswith('officers_barracks') and not row['structure_id'].endswith('commanding_officers_barracks') else 4
   assert len(front['openings'])==per*2 and sum(o['kind']=='door' for o in front['openings'])==1
   assert sum(o['z0']<p.storey_height_m for o in front['openings'])==per
   assert p.gallery_storeys==2
  targets.append(row['structure_id'])
 assert len(after['verts'])==len(after['confidence'])==len(after['tone'])
 assert all(math.isfinite(v) for p in after['verts'] for v in p)
 assert all(math.isfinite(v) and 0<=v<=1 for v in after['confidence'])
 assert len(after['faces'])==len(after['material_index'])
 assert all(0<=i<len(after['materials']) for i in after['material_index'])
 assert all(len(poly)>=3 and all(0<=i<len(after['verts']) for i in poly) for poly in after['faces'])
 rows.append({'structure_id':row['structure_id'],'phase_id':row['phase_id'],'asset':row['asset'],'target_record':row['target_record'],'current_raw_sha256':digest(before),'disabled_new_options_raw_sha256':digest(default),'proposed_raw_sha256':digest(after),'current_triangles':sum(len(p)-2 for p in before['faces']),'proposed_triangles':sum(len(p)-2 for p in after['faces']),'exact_old_default':True,'exact_non_target':before==after,'equals_rendered_gallery_prototype':row['target_record']})
assert len(rows)==25 and len(targets)==7
# No helper or old API beyond the two opt-ins changed: complete non-target functions retain syntax.
def nodes(path):return {n.name:n for n in ast.parse(path.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=nodes(B/'generators/archetypes/fort_structure.py'),nodes(C/'generators/archetypes/fort_structure.py');assert set(b)==set(a)|{'_gallery_two_storeys','_explicit_openings'}
for name in a:
 if name not in {'_gallery','_openings'}:assert ast.dump(a[name])==ast.dump(b[name]),name
selected=json.loads((C/'data/structures/first_fort_dearborn_north_range.json').read_text());p=new.from_phase(selected['phases'][0],selected)
for change in [{'gallery_storeys':True},{'gallery_storeys':3},{'gallery_storeys':2,'gallery':False},{'gallery_storeys':2,'stories':1},{'face_openings':[{}]},{'face_openings':[dict(p.face_openings[0],u0=float('nan'))]},{'face_openings':[p.face_openings[0],p.face_openings[0]]}]:
 try:replace(p,**change).validate()
 except new.ParamError:pass
 else:raise AssertionError(('invalid accepted',change))
report={'status':'PASS','real_generator_build_and_MeshBuilder_calls_CPU_only':True,'bpy_runtime_forbidden':True,'all25_old_defaults_exact_raw_vertices_faces_materials_confidence_tone':True,'all18_non_targets_exact_with_candidate_data':True,'all7_targets_exact_to_previously_exported_rendered_gallery_prototype_under_same_current_common_code':True,'legacy16_positionals_and_all_original_properties_exact':True,'only2_new_fields_individually_keyword_only':True,'no_lighthouse_cupola_Lake_House_or_date_controls':True,'invalid_options_refuse':True,'family':rows,'limitations':'Raw generator parity, not new Blender normals/UV/export bytes, official bake, published output or fresh image acceptance. All25 recipes need real refresh because module bytes differ.'}
(H/'raw-geometry-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='family'},indent=2))
