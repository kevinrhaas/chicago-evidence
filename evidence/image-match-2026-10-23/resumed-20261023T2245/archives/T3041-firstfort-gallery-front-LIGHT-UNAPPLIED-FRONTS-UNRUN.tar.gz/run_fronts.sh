#!/usr/bin/env bash
# Future guarded ten-front comparison only, no Blender/producer/compiler.
set -euo pipefail
fort_packet="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ "${CHICAGO_HEAVY_SLOT:-}" != T3041_FRONTS ]]; then
  echo 'Refusing: root must explicitly grant T3041_FRONTS; no work started.' >&2
  exit 2
fi
export PYTHONDONTWRITEBYTECODE=1
python3 "$fort_packet/prepare_fronts.py"
fort_run="$(cat "$fort_packet/latest-front-run.txt")"
for fort_state in baseline proposed; do
  cd "$fort_run/$fort_state"
  for fort_part in north_range officers_barracks commanding_officers_barracks soldiers_barracks_sw soldiers_barracks_se; do
    python3 "$fort_packet/verify_current.py"
    PW_EXECUTABLE="${PW_EXECUTABLE:-/usr/bin/chromium}" node tools/photo_match.mjs "research-cameras/$fort_part.json" --out "$fort_run/reviews/$fort_state" > "$fort_run/$fort_state-$fort_part.log" 2>&1
  done
done
printf '%s\n' 'Ten actual native calls finished; direct source/image review still required. Original full fort Image gate remains OPEN.'
