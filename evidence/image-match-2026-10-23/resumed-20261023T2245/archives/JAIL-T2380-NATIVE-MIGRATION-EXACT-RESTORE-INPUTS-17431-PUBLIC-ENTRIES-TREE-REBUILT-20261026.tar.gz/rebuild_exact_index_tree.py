from pathlib import Path
import subprocess,os,tempfile,hashlib,json
ROOT=Path(__file__).resolve().parent
captured=ROOT/'actual70-with-Jail-exact.index'
expected='088345e9e37c00cbe5e9bfac8f68c124fd599ee9'
before=hashlib.sha256(captured.read_bytes()).hexdigest()
tmp=Path(tempfile.mkdtemp(prefix='jail-index-tree-rebuild-proof-',dir='/tmp'))
repo=tmp/'new-isolated.git'
subprocess.run(['git','init','--bare','-q',str(repo)],check=True)
def g(*args,input=None,index=captured):
 e=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_INDEX_FILE=str(index))
 return subprocess.check_output(['git','--git-dir='+str(repo),'-c','gc.auto=0','-c','maintenance.auto=false',*args],input=input,env=e)
entries=g('ls-files','--stage','-z')
assert len([x for x in entries.split(b'\0')if x])==17431
new_index=tmp/'rebuilt.index'
g('read-tree','--empty',index=new_index)
g('update-index','-z','--index-info',input=entries,index=new_index)
actual=g('write-tree','--missing-ok',index=new_index).decode().strip()
assert actual==expected,(actual,expected)
assert hashlib.sha256(captured.read_bytes()).hexdigest()==before
r={'status':'ACTUAL_FRESH_ISOLATED_GIT_TREE_RECONSTRUCTION_PASS','captured_index_sha256':before,'all_index_entries':17431,'expected_tree':expected,'actual_rebuilt_tree':actual,'no_old_unpublished_tree_object_or_alternate_used':True,'source_fixture_and_source_common_git_untouched':True,'source_captured_index_unchanged':True,'only_new_isolated_metadata_objects_written':True,'temporary_proof_repo':str(repo),'new_metadata_object_bytes':sum(p.stat().st_size for p in(repo/'objects').rglob('*')if p.is_file()),'restoration_instruction':'This program demonstrates rebuilding exactTREE088345 from capturedindex WITHOUT needing that unpublishedobject. Populate a NEW private source object store frompublic8cd/70matchingentries, materialize scope accordingto417listing, overlayactualV2helper+correspondingfullnormalizedHTML/canonicalfile, thenexecuteactualnativeCLIperRESTORE.md. Neverrestoreoveralivesourceworktree.'}
(ROOT/'TREE-RECONSTRUCTION-RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
