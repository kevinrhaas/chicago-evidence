#!/usr/bin/env python3
"""Dispatch the existing smoke workflow once per native matrix leg, with receipts."""
import argparse
import datetime
import json
from pathlib import Path
import subprocess
import time
from urllib.parse import quote

REPO = 'kevinrhaas/chicago'
STAGES = ['1-2', '3-4', '5', '6-7', '8', '9-12', '13', '14', '15']


def api(endpoint, payload=None):
    argv = ['gh', 'api', endpoint]
    data = None
    if payload is not None:
        argv += ['--method', 'POST', '--input', '-']
        data = json.dumps(payload).encode()
    out = subprocess.run(argv, input=data, capture_output=True, check=True).stdout
    return json.loads(out) if out.strip() else None


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--pr', type=int, required=True)
    p.add_argument('--branch', required=True)
    p.add_argument('--sha', required=True)
    p.add_argument('--packet', type=Path, required=True)
    a = p.parse_args()
    a.packet.mkdir(parents=True, exist_ok=True)
    bound = a.packet / 'BOUND_DISPATCH.json'
    if bound.exists():
        raise SystemExit('Existing dispatch receipt: inspect it; never dispatch duplicates.')
    pr = api(f'repos/{REPO}/pulls/{a.pr}')
    assert pr['state'] == 'open' and pr['base']['ref'] == 'dev'
    assert pr['head']['sha'] == a.sha and pr['head']['ref'] == a.branch
    workflow = f'repos/{REPO}/actions/workflows/chicago-4d-smoke.yml'
    runs_url = workflow + '/runs?event=workflow_dispatch&head_sha=' + a.sha + '&per_page=100'
    initial = api(runs_url)
    known = {r['id'] for r in initial['workflow_runs']}
    result = dict(status='DISPATCH_IN_PROGRESS_NOT_RESULTS', PR=a.pr, head=a.sha,
                  branch=a.branch, started=now(), initial_readback=pr,
                  coverage='All native 18 matrix legs, both viewports and stages1–15; each alone is staged, not the full gate.',
                  runs=[])

    def save():
        temp = bound.with_suffix('.json.tmp')
        temp.write_text(json.dumps(result, indent=2) + '\n')
        temp.replace(bound)

    save()
    for viewport in ['desktop', 'mobile']:
        for stage in STAGES:
            ref = api(f'repos/{REPO}/git/ref/heads/{quote(a.branch, safe="/")}')
            assert ref['object']['sha'] == a.sha, 'Branch moved: stop dispatching.'
            row = dict(viewport=viewport, stage=stage, requested=now(), dispatch_accepted=False)
            result['runs'].append(row)
            save()
            payload = {'ref': a.branch, 'inputs': {'viewport': viewport, 'stage': stage}}
            (a.packet / f'{viewport}-{stage}.json').write_text(json.dumps(payload, indent=2) + '\n')
            api(workflow + '/dispatches', payload)
            row['dispatch_accepted'] = True
            save()
            for attempt in range(12):
                observed = api(runs_url)
                new = [r for r in observed['workflow_runs'] if r['id'] not in known]
                if new:
                    assert len(new) == 1, 'Ambiguous run assignment; recover from receipts.'
                    r = new[0]
                    assert r['head_sha'] == a.sha and r['head_branch'] == a.branch
                    row.update(id=r['id'], url=r['html_url'], created_at=r['created_at'],
                               observed_head=r['head_sha'], run_number=r['run_number'])
                    known.add(r['id'])
                    save()
                    print(json.dumps({k: row[k] for k in ['viewport', 'stage', 'id', 'url']}), flush=True)
                    break
                time.sleep(2)
            else:
                raise RuntimeError('Accepted dispatch not yet located: recover, do not repeat.')
    result['status'] = 'DISPATCHED_NOT_RESULTS'
    result['finished_dispatch'] = now()
    save()
    print(json.dumps({'bound_receipt': str(bound), 'jobs': len(result['runs']), 'head': a.sha}))


if __name__ == '__main__':
    main()
