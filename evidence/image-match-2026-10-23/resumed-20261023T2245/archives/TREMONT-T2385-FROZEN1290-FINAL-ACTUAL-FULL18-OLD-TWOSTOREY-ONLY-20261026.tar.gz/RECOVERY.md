# Tremont: frozen 1290 full published smoke proof

All18 actual immutable workflow legs passed on1290, bothmobile390x780 anddesktop1280x800, stages1–15 covered once perviewport. Eachraw log is bound to its actualcheckout, workflowrun/job/attempt, nativepublish+smokestep, positivecounts andzeropageerrors. This is a frozen proof, not a latestDEV certificate. PR1337 staysDRAFT untilJail/Mary/Wolf land and a normalcurrentDEV ending meets policy. OriginalT2385 remainsOPEN/DIF. Do not rerun these immutablelegs solely to re-harvest them.
