from pathlib import Path
import subprocess,json,hashlib,os,sys,re,datetime
os.sched_setaffinity(0,{1,4});repo=Path('/tmp/st-mary-picture-20261025');app=repo/'chicago/4d';out=Path('/workspace/shared/st-mary-jail8cd-stack-runtime-20261026T1316');head='3f74a5514ed6ed3cd75a80512a6cccfbab4ed919';incoming='8cd2db60777947a16399459fd2945eb804849a51';common='a575dddeed356333423b20361a1f90f3b39a862f';env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None)
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo,env=env)
def blob(ref,p):return git('show',ref+':'+p)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,d):(out/n).write_text(json.dumps(d,indent=2)+'\n')
assert git('rev-parse','HEAD').decode().strip()==head and git('rev-parse','MERGE_HEAD').decode().strip()==incoming and git('merge-base',head,incoming).decode().strip()==common
writes={};docproof=[]
# Whole incoming liberties, followed by only exact own Mary entry.
p='chicago/4d/docs/LIBERTIES.md';ours=blob(head,p);new=blob(incoming,p);marker=b'### L-st-mary-chapel-front-2384';assert ours.count(marker)==1 and marker not in new;delta=ours[ours.index(marker):];writes[p]=new.rstrip(b'\n')+b'\n\n\n'+delta;docproof.append({'path':p,'whole_incoming_prefix':True,'incoming_sha256':sha(new),'own_suffix_sha256':sha(delta)})
# Preserve all incoming status and its existing generic-oracle note once.
m=json.loads(Path('/workspace/green-tree-strict-repair-donor-6a61.json').read_text());donor='6a61ab6eca1f1ea2322302d131e847b383ac9c8b'
for p in ['chicago/4d/docs/ROADMAP.md','chicago/4d/docs/STATUS.md']:
 old=blob(common,p);ours=blob(head,p);new=blob(incoming,p);assert ours.startswith(old),p;delta=ours[len(old):]
 if p.endswith('STATUS.md'):
  dbase=blob(m['base'],p);d=blob(donor,p);assert d.startswith(dbase);shared=d[len(dbase):];assert delta.count(shared)==1 and new.count(shared)==1;delta=delta.replace(shared,b'',1)
 writes[p]=new.rstrip(b'\n')+b'\n'+delta
 docproof.append({'path':p,'whole_incoming_prefix':True,'incoming_sha256':sha(new),'own_addition_sha256':sha(delta),'common_oracle_notes_once':True})
writes['chicago/4d/docs/STATUS.md']+=b'\n\nT-2384 cumulative draft checkpoint (2026-10-26): checked Jail PR #1333 head 8cd2db60 is integrated as an upstream dependency while this PR remains based on dev. The earlier Mary 3f74a551 source passed all eighteen native published groups; that old-base result does not certify the combined world. Supported native regeneration, current all-three preflight and a fresh exact-head eighteen-group matrix are pending for this cumulative candidate. Jail must land first; before ready/merge, actual dev must be integrated and the native global smoke-input hash compared with the frozen tested candidate, with a fresh stage 13 at both viewports when only the separately hashed changelog changes. The original Moss vertical sash setout remains open; no original image-match completion is claimed.\n'
# Native entrywise registry union: own271 FrameDwelling phases; every other row exact incoming.
sys.path.insert(0,str(app/'tools'));import merge_asset_registry as mar
family=json.loads(Path('/tmp/st-mary-runtime-20261025/ff-20affa/PREPARED.json').read_text())['family542'];names={Path(x).name for x in family if x.startswith('assets/gltf/')};assert len(names)==271;regproof=[]
for p in ['chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json']:
 old=blob(common,p).decode();ours=blob(head,p).decode();new=blob(incoming,p).decode();reemit={};result=mar.merge_texts(p,old,ours,new,reemit);assert not reemit,('UNEXPECTED_REEMIT',reemit);v=json.loads(result);ov=json.loads(ours);nv=json.loads(new);key=mar.REGISTRIES[p]['map'];expected=(set(ov[key])&names)|(set(nv[key])-names);assert set(v[key])==expected
 for k,row in v[key].items():assert row==(ov[key][k]if k in names else nv[key][k]),(p,k)
 writes[p]=result.encode();regproof.append({'path':p,'own271_exact':True,'all_other_incoming_exact':True,'native_threeway_no_reemit':True,'sha256':sha(result.encode())})
# Remove auto-merged duplicate ID using the complete exact checked incoming list.
p='chicago/4d/tools/smoke_renderer.mjs';current=(repo/p).read_text();new=blob(incoming,p).decode();pattern=r'const PLACED_1904 = \[.*?\]\.sort\(\);';a=re.search(pattern,current,re.S).group();b=re.search(pattern,new,re.S).group();assert a.count("'pullman_house_1729_prairie_ranges'")==2 and b.count("'pullman_house_1729_prairie_ranges'")==1;writes[p]=current.replace(a,b).encode();(out/'AUTO-MERGED-DUPLICATE-1904-LIST.txt').write_text(a+'\n');(out/'EXACT-INCOMING-1904-LIST.txt').write_text(b+'\n')
# Every actual published/master FrameDwelling file stays exactly the already checked own version.
for p,expectedsha in family.items():assert sha((app/p).read_bytes())==expectedsha,('OWN_FAMILY_CHANGED',p)
GT=json.loads(Path('/tmp/st-mary-runtime-20261025/checked-GT23-snapshot.json').read_text());assert all(sha((repo/p).read_bytes())==v['sha256']for p,v in GT['files46'].items())
for p,data in writes.items():(repo/p).write_bytes(data)
subprocess.run(['git','add','--',*writes],cwd=repo,env=env,check=True)
unmerged=git('diff','--name-only','--diff-filter=U').decode().splitlines();owned={p for step in json.loads((app/'tools/derived_manifest.json').read_text())['steps']for p in step.get('resolves',[])};assert set(unmerged)<=owned,(set(unmerged)-owned)
# Freeze all source placements/population/assets and selected enclosure code, after authored resolution.
oldpaths=json.loads(Path('/workspace/shared/T2380-integrate-a9c5-20261026T1235/PROTECTED-NORMAL-INTEGRATED-BEFORE.json').read_text());allpaths=set(git('ls-files','-z').decode().strip('\0').split('\0'));prefixes=['chicago/4d/data/reconstruction/','chicago/4d/data/residents/','chicago/4d/data/structures/','chicago/4d/assets/gltf/','chicago/4d/assets/web/'];paths=set(oldpaths)|{p for p in allpaths if any(p.startswith(t)for t in prefixes)};protected={p:sha((repo/p).read_bytes())for p in sorted(paths)};save('PROTECTED-NORMAL-INTEGRATED-BEFORE.json',protected)
art={}
for p in sorted(x for x in allpaths if x.endswith(('.xlsx','.gz'))):
 old=blob(incoming,p);now=(repo/p).read_bytes();assert old==now,p;art[p]={'incoming_sha256':sha(old),'incoming_bytes':len(old),'current_sha256':sha(now)}
assert len(art)==44;save('ALL44-ARTIFACTS-INCOMING-BEFORE.json',{'actual_count':44,'xlsx':23,'gz':21,'basis':incoming,'paths':art});save('AUTHORED-RESULT.json',{'status':'CHECKED_JAIL8CD_PLUS_OWN_MARY_ENTRYWISE_NO_BAKE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'incoming':incoming,'common':common,'doc_proof':docproof,'registries':regproof,'own_family542_exact':True,'GreenTree46_exact':True,'all588_exact':True,'protected_count':len(protected),'all44_exact':True,'remaining_native_owned':unmerged,'canonical_incoming_exact':(app/'renderers/web/js/changelog.js').read_bytes()==blob(incoming,'chicago/4d/renderers/web/js/changelog.js')});print((out/'AUTHORED-RESULT.json').read_text())
