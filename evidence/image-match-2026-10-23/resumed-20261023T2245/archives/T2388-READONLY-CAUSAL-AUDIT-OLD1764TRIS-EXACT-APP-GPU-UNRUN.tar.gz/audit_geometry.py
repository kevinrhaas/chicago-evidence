from pathlib import Path
import json,struct,collections,math,numpy as np
from scipy.spatial import cKDTree
O=Path(__file__).resolve().parent;R=Path('/workspace/T2388-private-actual-milestone-20261024');A=R/'T2388-private-gallery-existing-actual-003';K='fort_dearborn_officers_quarters__log_1816.glb'
paths={'before':A/'baseline-held/gltf.glb','after':R/'exact-private-owned-state/chicago/4d/assets/gltf'/K}
def glb(path):
 b=path.read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);off=20+n;blen=struct.unpack_from('<I',b,off)[0];return j,b[off+8:off+8+blen]
def decode(j,buffer,i):
 a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];kind={5120:'b',5121:'B',5122:'h',5123:'H',5125:'I',5126:'f'}[a['componentType']];width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];size=struct.calcsize(kind);stride=v.get('byteStride',size*width);off=v.get('byteOffset',0)+a.get('byteOffset',0);return [struct.unpack_from('<'+kind*width,buffer,off+k*stride)for k in range(a['count'])]
def canonical(t):return min(t,t[1:]+t[:1],t[2:]+t[:2])
data={};allpoints={};physical={};triangles={};summary={}
for leg,path in paths.items():
 j,buffer=glb(path);assert all(not any(k in node for k in ['matrix','translation','rotation','scale'])for node in j['nodes']);physical[leg]={};triangles[leg]={};allpoints[leg]=[];summary[leg]={}
 for mesh in j['meshes']:
  for p in mesh['primitives']:
   name=j['materials'][p['material']]['name'];attrs={k:decode(j,buffer,i)for k,i in p['attributes'].items()if not k.startswith('TEXCOORD')};pos=attrs['POSITION'];allpoints[leg].extend(pos);inds=[x[0]for x in decode(j,buffer,p['indices'])];names=sorted(attrs);records=[tuple((n,attrs[n][i])for n in names)for i in range(len(pos))];triples=[tuple(pos[i]for i in inds[k:k+3])for k in range(0,len(inds),3)];triangles[leg][name]=triples;physical[leg][name]=collections.Counter(canonical(tuple(records[i]for i in inds[k:k+3]))for k in range(0,len(inds),3));summary[leg][name]={'vertices':len(pos),'triangles':len(inds)//3,'bounds_min':[min(v[i]for v in pos)for i in range(3)],'bounds_max':[max(v[i]for v in pos)for i in range(3)]}
 data[leg]={'nodes':j['nodes'],'scenes':j['scenes'],'materials':j['materials']}
comparisons={}
for name in physical['before']:
 old=physical['before'][name];new=physical['after'][name];comparisons[name]={'old_triangles':sum(old.values()),'new_triangles':sum(new.values()),'removed_physical_triangles':sum((old-new).values()),'added_physical_triangles':sum((new-old).values()),'comparison':'Exact cyclic-oriented POSITION/NORMAL/_CONFIDENCE/_TONE (all non-UV attributes), same materialrole'}
 assert not old-new,(name,'old physical surface changed')
assert comparisons['roof_shingle']['added_physical_triangles']==2
assert all(comparisons[k]['added_physical_triangles']==0 for k in ['log','glass','door','door_panel','chimney'])
oldroof=collections.Counter(canonical(t)for t in triangles['before']['roof_shingle']);newroof=collections.Counter(canonical(t)for t in triangles['after']['roof_shingle']);canopy=list((newroof-oldroof).elements());assert len(canopy)==2
cams=json.loads((O/'DECODED-WEB-AND-MATRICES.json').read_text());cm=cams['camera_matrices'];assert cm['before']['projection']==cm['after']['projection']and cm['before']['camera_world']==cm['after']['camera_world']and cm['before']['camera_world_inverse']==cm['after']['camera_world_inverse']
for a,b in zip(cm['before']['recorded_group_members'],cm['after']['recorded_group_members']):assert a['matrix']==b['matrix']and a['placement']==b['placement']
proj=np.array(cm['before']['projection']).reshape(4,4,order='F');view=np.array(cm['before']['camera_world_inverse']).reshape(4,4,order='F');eye=np.array(cm['before']['camera_world']).reshape(4,4,order='F')[:3,3]
def project(p):
 q=proj@view@np.array([*p,1]);q=q[:3]/q[3];return [(q[0]+1)*811/2,(1-q[1])*572/2]
def hit(p,t):
 orig=eye;d=np.array(p)-orig;a,b,c=map(np.array,t);e1,e2=b-a,c-a;h=np.cross(d,e2);det=np.dot(e1,h)
 if abs(det)<1e-12:return None
 inv=1/det;s=orig-a;u=inv*np.dot(s,h)
 if not -1e-10<=u<=1+1e-10:return None
 q=np.cross(s,e1);v=inv*np.dot(d,q)
 if v< -1e-10 or u+v>1+1e-10:return None
 dist=inv*np.dot(e2,q)
 return float(dist)if 0<dist<1-1e-9 else None
# Actual unchanged upper-front glass positions, sampled at90% of pane height.
glass=[p for t in triangles['before']['glass']for p in t if p[1]>3 and abs(p[2]+9.175000190734863)<1e-6];xs=sorted(set(p[0]for p in glass));ys=sorted(set(p[1]for p in glass));assert len(xs)==10 and len(ys)==2
samples=[]
for a,b in zip(xs[::2],xs[1::2]):
 p=((a+b)/2,ys[0]+.9*(ys[1]-ys[0]),glass[0][2]);pixel=project(p);hits=[x for t in canopy if(x:=hit(p,t))is not None];samples.append({'unchanged_upper_glass_point':p,'pixel_before_equals_after':pixel,'in_frame':bool(0<=pixel[0]<811 and 0<=pixel[1]<572),'new_canopy_occludes':bool(hits),'ray_fraction_first_hit':min(hits)if hits else None})
projected_canopy=[project(p)for t in canopy for p in t]
# Distinguish native WebGL quantization encoding from authored origin using real decoded compressed bytes.
web={}
for leg in ['before','after']:
 w=cams[leg];body=[]
 for p in w['primitives']:
  if p['material']=='log':body.extend(p['positions'])
 master=[p for t in triangles[leg]['log']for p in t];dist=cKDTree(np.array(master)).query(np.array(body))[0];rev=cKDTree(np.array(body)).query(np.array(master))[0]
 web[leg]={'nodes':w['nodes'],'log_bounds_min':np.min(body,axis=0).tolist(),'log_bounds_max':np.max(body,axis=0).tolist(),'max_body_vertex_distance_to_same_master_m':float(max(dist.max(),rev.max())),'all_primitive_max_abs_coordinate_m':max(abs(v)for p in w['primitives']for xyz in p['positions']for v in xyz)}
result={'status':'PASS_CAUSE_IS_NEW_GALLERY_GEOMETRY_OCCLUSION_NOT_MASTER_BODY_SHIFT_OR_CAMERA_RECENTERING','scope':'READONLY closedGLBs/capturedplacements +CPUprojection/meshoptdecode. No freshGPU/browser/nativewriter or canonicalchange.','main_physical_geometry_comparison':comparisons,'bounds':summary,'master_nodes_scenes_materials_identical':data['before']==data['after'],'master_node_transform':'identity before and after; no normalizationTRS metadata','overall_master_bounds':{leg:{'min':np.min(allpoints[leg],axis=0).tolist(),'max':np.max(allpoints[leg],axis=0).tolist(),'size':(np.max(allpoints[leg],axis=0)-np.min(allpoints[leg],axis=0)).tolist(),'native_batch_positionScale_master':max(abs(v)for xyz in allpoints[leg]for v in xyz)}for leg in allpoints},'camera_and_captured_group_matrices_exact':True,'matrix_method_limit':cm['method'],'new_canopy_projected_bounds_px':{'min':np.min(projected_canopy,axis=0).tolist(),'max':np.max(projected_canopy,axis=0).tolist()},'unchanged_upper_window_occlusion_samples':samples,'compressed_web_world_coordinate_readback':web,'native_app_gpu_readback':'NOTRUN; staticcodepath andactualbyteCPUdecode only','acceptance':'OriginalimagesDIFFERS/privatehypothesisunadopted; no camera/geometryfix proposed'}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'physical_deltas':comparisons,'occlusion_samples':samples,'web':{k:{x:y for x,y in v.items()if x!='nodes'}for k,v in web.items()}},indent=2))
