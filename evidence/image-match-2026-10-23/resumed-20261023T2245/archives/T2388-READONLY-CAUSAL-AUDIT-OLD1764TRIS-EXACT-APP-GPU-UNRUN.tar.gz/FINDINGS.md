# T-2388 causal audit: unchanged building, new canopy occlusion

The existing building did not shift or recenter in the private photo comparison. Every one of the baseline master's **1,764 physical triangles** remains exactly in the candidate, including positions, normals, confidence, tone and material role. The candidate adds 1,618 triangles: two for the gallery canopy and 1,616 for gallery trim/posts/deck/rails. UVs are excluded from this comparison because the normal export unwraps them again; the plain materials and master scene/node metadata are identical.

The baseline/candidate pair is still DIFFERS and remains an unfitted 1855 diagnostic bracket. This is a read-only cause analysis, not a new rendering, geometry fix, historical ruling or adoption.

| Physical part | Before → after triangles | Removed or moved old triangles |
| --- | ---: | ---: |
| Log body and gables | 494 → 494 | 0 |
| Main roof plus new canopy | 16 → 18 | 0; exactly two canopy triangles added |
| Existing trim plus gallery | 1,170 → 2,786 | 0; 1,616 gallery triangles added |
| Chimneys | 40 → 40 | 0 |
| Glass | 34 → 34 | 0 |
| Door and panel | 10 → 10 | 0 |

Both master nodes have identity transforms: no matrix, translation, rotation or scale. Scenes, node extras and material metadata are identical. The body's bounds remain x −0.239999995…18.530000687 m, y 0…7.882503986 m, z −9.380000114…0.239999995 m. The old main roof's physical triangles are exact; the canopy enlarges the overall z extent toward the camera.

The complete model's bounds change only in depth: x remains −0.300000012…18.590000153 m and y remains 0…8.662504196 m. Overall z changes from −9.439999580…0.300000012 m to −11.390000343…0.300000012 m, giving depth 9.739999592 → 11.690000355 m. That is new front geometry, not an origin shift. Master bounds and per-material bounds are saved in RESULT.json.

The captured group receipts record B at [0,0,0] with rotation 0 in both runs, and A at [−15.048011524,0,−15.244075871] with rotation −π/2 in both. Scene positions/bearings and A's GLB are exact. The camera eye in glTF space is [20,10,−32] m. Independently replaying the exact unchanged Three.js camera math from the actual capture inputs produces identical projection, view and camera-world matrices. The complete arrays and member matrices are in DECODED-WEB-AND-MATRICES.json. This is CPU replay of the executed source and captured applied placements, not a new GPU matrix readback.

`tools/photo_match.mjs` lines 100–115 constructs the camera; lines 118–122 directly loads and places the GLBs. `tools/photo_match_group.mjs` lines 49–55 computes the captured relative placements. There is no bounding-box centering or camera auto-fit. `generators/common/mesh.py` leaves the emitted object at its default origin; `generators/emit.py` unwraps and exports it without recentering. The actual identity master nodes and exact world-coordinate triangles independently confirm that source behavior.

The canopy explains the apparent movement. Its actual triangles project over x −233.35…432.69 px and y 233.54…371.75 px in the 811×572 render pane. Rays to four in-frame, unchanged upper-window head samples hit the added canopy at 0.927328 of their range. Those same samples project to exactly the same pixels before and after, but the new foreground plane hides them. The new gray canopy also covers part of the old roof/eave region and changes the silhouette readers perceive. This is geometric occlusion, not evidence that the old roof or windows moved. It does not claim every changed pixel has been classified or that the gallery matches the source.

The web encoding does change its node translation, legitimately: z −4.569999784 → −5.545000166 m, with unchanged uniform scale 9.445000082. That transform dequantizes the compressed coordinate buffer. Actual Meshopt CPU decode, including the node transform, restores the unchanged log body within 0.837 mm before and 0.829 mm after of its respective exact master. It does not move the body by 0.975 m. Native `collectMeshes()` in buildings.js lines 101–111 preserves that dequantization by taking geometry in the parent's frame; `normalizeGeometry()` applies it at lines 168–210.

Native batching uses the largest absolute coordinate, not a new bounding-box center. That scale is exactly 18.590000153 m in both decoded assets, so the packing scale/grid does not shift. The source paths are buildings.js lines 750–768 and compact-attributes.js lines 156–189.

There is a separate future native-app grounding concern. Running the existing `building-feet.js` routine over the actual decoded geometry yields 74 → 84 contact cells, with no old cells removed. Sampled front reach expands from z −9.212223… to −11.099526… m as the posts gain feet outside the old wall. Native `groundUnder()` (buildings.js lines 672–700) samples the lowest terrain under those feet, so additional downhill samples could change the app's vertical anchor. No terrain or app GPU readback was performed here. That possibility cannot explain the current photo pair, which uses a common flat grade plane, but it must not be assumed absent in a future canonical app trial.

No camera/geometry correction is proposed or applied. Current five private changes remain byte-exact to the recoverable actual milestone; both original pairs remain immutable DIFFERS. Historical same-range identity and 1835 continuity remain unresolved working reconstruction, with stairs absent and 1855 only a diagnostic appearance bracket.
