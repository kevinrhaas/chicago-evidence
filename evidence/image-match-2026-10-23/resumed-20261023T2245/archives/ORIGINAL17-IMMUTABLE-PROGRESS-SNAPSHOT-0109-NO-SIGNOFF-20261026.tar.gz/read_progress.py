from pathlib import Path
import urllib.request,urllib.parse,json,base64,hashlib,datetime,re,concurrent.futures,os
import yaml

B=Path('/tmp/original-ticket-progress-20261026-0109');assert not B.exists();B.mkdir()
if 2 in os.sched_getaffinity(0):os.sched_setaffinity(0,{2})
def now():return datetime.datetime.now(datetime.timezone.utc)
def get(url):
 with urllib.request.urlopen(url,timeout=50)as r:
  data=r.read();meta={'url':url,'read_at':now().isoformat(),'http_status':r.status,'date':r.headers.get('Date'),'etag':r.headers.get('ETag'),'response_bytes':len(data),'response_sha256':hashlib.sha256(data).hexdigest()}
 return data,meta
def serial(x):return x.isoformat()if isinstance(x,(datetime.date,datetime.datetime))else str(x)
api='https://api.github.com/repos/kevinrhaas/chicago-tickets/'
raw,meta=get(api+'git/ref/heads/main');ref=json.loads(raw);head=ref['object']['sha'];(B/'TICKETS-MAIN-REF.json').write_bytes(raw);(B/'TICKETS-MAIN-REQUEST.json').write_text(json.dumps(meta,indent=2)+'\n')
local=Path('/workspace/chicago-tickets');paths={}
for p in (local/'T-2250-2499').iterdir():
 m=re.match(r'T-(\d+)-',p.name)
 if m and 2372<=int(m[1])<=2388:paths['T-'+m[1]]=str(p.relative_to(local))
assert len(paths)==17
extra=next((local/'T-3000-3249').glob('T-3041-*.md'));paths['T-3041']=str(extra.relative_to(local))
(B/'tickets').mkdir()
def one(item):
 tid,path=item;url=api+'contents/'+urllib.parse.quote(path,safe='/')+'?ref='+head
 raw,req=get(url);content=json.loads(raw);assert content['encoding']=='base64';data=base64.b64decode(content['content']);assert len(data)==content['size'];assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==content['sha']
 (B/'tickets'/(tid+'.md')).write_bytes(data);text=data.decode();assert text.startswith('---\n');fmraw=text.split('---',2)[1];fm=json.loads(json.dumps(yaml.safe_load(fmraw),default=serial));assert fm['id']==tid
 claim={'status':'none','age_hours':None}
 if fm.get('claimed_by')or fm.get('claimed_at'):
  try:
   at=datetime.datetime.fromisoformat(fm['claimed_at'].replace('Z','+00:00'));age=(now()-at).total_seconds()/3600;claim={'status':('live'if age<3 else'expired')if fm.get('state')=='claimed'else'claim_fields_on_nonclaimed_state','age_hours':round(age,3)}
  except Exception:claim={'status':'unparseable_or_missing_time','age_hours':None}
 return {'id':tid,'path':path,'immutable_head':head,'git_blob_sha1':content['sha'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'frontmatter':fm,'claim_assessment':claim,'request':req,'ancestry_lines':[line for line in text.splitlines()if re.search(r'(?i)split|T-3041|parent:',line)][:20]}
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:rows=list(pool.map(one,sorted(paths.items())))
raw,req=get('https://api.github.com/repos/kevinrhaas/chicago/pulls/1328');pr=json.loads(raw)
prsmall={k:pr.get(k)for k in ['number','title','state','draft','merged','merged_at','merge_commit_sha','mergeable','mergeable_state','html_url','updated_at']};prsmall['head']={k:pr['head'].get(k)for k in ['sha','ref']};prsmall['base']={k:pr['base'].get(k)for k in ['sha','ref']};prsmall['request']=req;(B/'PR1328.json').write_text(json.dumps(prsmall,indent=2)+'\n')
originals=[r for r in rows if r['id']!='T-3041'];counts={}
for row in originals:counts[row['frontmatter']['state']]=counts.get(row['frontmatter']['state'],0)+1
compact=[{'id':r['id'],'title':r['frontmatter']['title'],'state':r['frontmatter']['state'],'parent':r['frontmatter'].get('parent'),'pr':r['frontmatter'].get('pr'),'claimed_by':r['frontmatter'].get('claimed_by'),'claimed_run':r['frontmatter'].get('claimed_run'),'claimed_at':r['frontmatter'].get('claimed_at'),'claim':r['claim_assessment']}for r in rows]
progress={'observed_at':now().isoformat(),'tickets_main_immutable_head':head,'original_ids':[r['id']for r in originals],'original_count':len(originals),'original_state_counts':counts,'original_done_count':counts.get('done',0),'originals':compact[:-1]if compact[-1]['id']=='T-3041'else[r for r in compact if r['id']!='T-3041'],'ancestry_extra':[r for r in compact if r['id']=='T-3041'],'PR1328':prsmall,'prior_partial_delivery_PRs_reported_by_parent_not_reread_here':[1260,1282,1283,1286,1298,1300,1323],'scope':'Immutable source-ticket/frontmatter and fresh PR1328 metadata audit only; partial utility delivery is not original image-gate signoff; no app or image matching tested; no repository/ticket/ref/index mutations.'}
(B/'TICKET-READBACKS.json').write_text(json.dumps(rows,indent=2)+'\n');(B/'PROGRESS.json').write_text(json.dumps(progress,indent=2)+'\n')
print(json.dumps({'directory':str(B),'head':head,'counts':counts,'original_done':progress['original_done_count'],'tickets':compact,'PR1328':prsmall},indent=2))
