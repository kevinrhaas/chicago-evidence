# T-2386 — shallow roof-covering continuation, LIGHT / UNRUN

OriginalT-2386 is normally claimed by `Wolf Point roof-relief continuation` in tickets commit `f31e1d5815c29e7dacea12f45caef6a22c8a90be`. The original all-picture acceptance remains unchanged and the actual comparison still differs. This package is isolated: no canonical app files, shared prototypes, old frozen packet or accepted reference-view record were changed. No Blender/browser has run.

## Source and actual baseline

The full1920×1697 NYPL sheet and actual source/before/after crop were directly viewed. Source remains Rufus Blanchard / Chas. Shober &Co.,1867, NYPL I.N.Phelps Stokes Collection, depicting1833. Its old independent public-domain-by-age ruling, credit and retrospective date limitations are unchanged. The Newberry poster with conflicting metadata is not the modelling source.

The roof is visibly a dark textured field while the actual rounded-log/door-recess model still has a smooth neutral roof. The sheet does not recover individual shingle dimensions, courses, relief, timber species, original pigment or measured weathering. Existing log-building roofing programmeL266 bounds a shingle category; this attempt remains reconstructed, with no copied source pixels or new rights assertion.

Baseline is the **actual** reviewed `be265ed9a60c01298d7dc687e998b7ff50b4c0636020aff7094be176702f6268` master from the closed run `T-2386-door-log-relief-next/runs/20261023-141756-738729`. Its official export contract, receipt, actual visual-review record, bare render and full side-by-side are copied. The before image is the real original renderPNG, not a recreation or crop from aJPEG. The old verdict is **differs**. No before re-export/capture is requested.

Camera bytes stay SHA256 `2a96283300029b94481286f5b246c2c9c53efb6f505ab140ddef543288a48f82`: provisional square pixels, focal6000px, old eye/yaw/principal/light/common-plane gauge. Its few-pixel manual-pick residuals are not an independent metric solve. The numeric dimensions/physicalL/world origin and1833-to1835 continuity remain reconstructed/inferred as before.

## One visible surface choice

`compound_roof_covering=None|"shingle_relief"` is a new keyword-only, default-off control, refused outside the already validated bounded elbow. It replaces the opted-in roof's eight flat upper-envelope polygons with one clipped continuous skin. Shallow staggered joints choose240mm widths,180mm exposure along the slope,3mm joint half-width and6–8mm vertical depressions. These are model choices, not source measurements. Existing roof/dark material slots and actual material definitions are unchanged. Dark joint faces represent a recess/shadow proxy, not an attested coating.

The skin stays on or below the existing envelope by at most8mm. Actual ridge, valley, eave and gable boundaries are fixed; shared coplanar producer-cell borders are cancelled before boundary masking, so they do not become invented roof breaks. Every old underside,50mm closing edge band and gable face is exact. There is no duplicated upper plane, new substrate, open crack, raised silhouette or source-image texture. Coplanar same-material cells within each course band are merged only after plane and convex-area checks; this removes invisible grid faces without changing the surface/colour partitions.

All other form attributes, source metadata except appended reading note, position, footprint, dates, doors/windows, log relief, stack/pipe, sign pole/board/device, camera, palette and source image stay unchanged. Footprint collision remains solid and no interior is asserted. Site/river/terrain/vegetation/neighbours/trade props are absent from the isolated comparison; no app/world clearance claim follows.

## Light evidence and cost

`light-check.json` passes exact raw vertices/faces/material/confidence equality for all**81 frozen prior replay records**, plus the actualbe265Wolf output with the new control off. Original positional constructor API is unchanged; the new field is keyword-only. The producer/record/source schema and actual copied liberty parser/forward-cover checks pass, with one precise new Cover and note-reader path. Nine unsupported control/plan cases are refused.

Independent clipped-roof sampling found exactly one upper skin at6,678 interior points and no new roof at1,122 outside points. All new vertices stay within0–8mm below the original envelope, all skin faces face upward and chosen details emit reconstructed confidence1. This also checks exact preservation of every non-upper roof face, including gable surfaces and closing bands.

The final raw proposal has **40,622 triangles** (38,904 covering triangles), compared with the actual1,730-triangle baseline. The superseded dense grid in `history/dense-superseded/` cost77,360triangles; it is historical LIGHT evidence only and must not be exported/adopted. Coalescing removes roughlyhalf that cost, but no app/performance gate has been run. Keep this increased visible cost explicit in adoption decisions; do not waive a performance check. The screenshot has not been viewed because the actual trial is not yet authorized.

These are frozen historical81 records, not a claim to have recomposed or baked latestdev's canonical family. The integration owner must preserve newer canonical Hogan/other independent records and rerun current family guards before the official81refresh. `roof-covering-relief.patch` changes exactly two log modules, Wolf's record and its source-note append. It is selective composition input after be265, not a wholesale old-tree restore. All copied runtime support is execution material, never code to copy over currentdev.

## Bounded next actual command

Dry command (pure, already passed):

```sh
python3 /tmp/chicago-next-model/T-2386-roof-relief-next-20261023/run_next.py
```

Only after root explicitly grants the shared heavy slot:

```sh
python3 /tmp/chicago-next-model/T-2386-roof-relief-next-20261023/run_next.py \
  --execute-after-root-grant \
  --grant-note 'Root granted one Wolf Point shallow roof-covering export and comparison'
```

This verifies frozen inputs, cached pinned Blender4.5.3 archive/binary, actual official absolute `build.py` and `structure_id__phase_id` seed; then requests exactly **one** new export and **one** same-camera capture. It checks singleton output manifest, real recipe hash, decoded contract/triangle count and camera/photo/master bindings. New match verdict stays`unreviewed` until full source and after/detail images are directly inspected. Expected original verdict remains`differs` while known differences persist. Browser/server/process cleanup is scoped to this run.

No dependency install/fetch, live checkout reads, canonical edit, accepted-view enrollment or ticket completion is performed. Runtime-only dependencies are existing `/workspace/shared/blender-dl`, `/workspace/node_modules`, `/usr/bin/chromium`, Python jsonschema/Pillow and installed Node. Inputs are regular copied files; `snapshot.json` binds them. `ARTIFACTS.json` excludes future `runs/`, `latest-run.txt`, generated caches and its own manifest.

Full adoption remains one combined visible log-family integration: current-data/default parity, source/Covers/note consumption, official81canonical master+web bake, recipe freshness, native scene/source/grade/contact/entrance/trade-prop regeneration, full checks, performance and actual desktop/mobile card/app/image QA. No researchmaster may substitute for that bake. OriginalT-2386 closes only when every governed picture matches.
