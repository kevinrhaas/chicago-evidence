# Current Wolf Point roof continuation state

The prepared405-file package is a frozen **historical UNRUN input checkpoint**. Its README/status/manifests were deliberately preserved after the later run. The current actual result is:

`runs/20261023-230350-632477/visual-review.json`

One official pinned export and one same-camera capture completedexit0. Actual GLB SHA256 `cdd42b7fbd406b812988673551efdc05876ae6fb9237673bb2043696856a2f26`,40,622triangles,3,378,468bytes,9primitives; source/camera/master bindings passed. Direct review verdict is **differs**. The roof surface pattern is visible but reads coarse/jagged and remains pale beside the source's soft dark field. **This40k-cost roof skin is not recommended for canonical adoption yet.** No performance budget was approved. Before/after/further source/context differences remain open.

The actual306-file run packet is separately frozen by its own `ARTIFACTS.json` (SHA256 `d0a90da98b35d1a05f164e9a7f40f04a6972da0c79913cd7241d909f24238bae`). All405 prior prepared input hashes remain exact after execution. The before master/render are the real be265 prior actual outputs and were not regenerated. The new raw match file remainsunreviewed as emitted; the separate direct-review record statesdiffers. No accepted reference view, original-ticket completion or canonical edit was made. Browser/server/processes ended and the shared heavy slot was returned.

`roof_helper.txt` is one-time **dense creation input**, superseded by the coalesced final candidate and four-file patch; it is not an adoption file. The final candidate contains coalescing and costs40,622triangles; superseded dense code/history costs77,360. Use `inputs.json`, the final candidate and `roof-covering-relief.patch` for selective inspection, never restore the helper or a whole old tree over currentdev.

Root and the current81-family integration planner have the actual review and recommend leaving this roof field unadopted while carrying the earlier rounded-log/recess be265 baseline forward for separate guarded composition. No second trial or lighter/material alternative has been run. A later representation needs a new bounded choice, current defaults/source guards, explicit heavy-slot grant and direct actual comparison. It must also meet current app/detail budget before canonical adoption.

OriginalT-2386 remains claimed by this continuing task, with complete all-picture acceptance intact. The source stays the independently cleared1867 NYPL Blanchard/Shober sheet depicting1833, not the held Newberry poster. Citation, rights/date/identity limits and source-image bytes are preserved. Canonical shared81bake, native downstream regeneration, performance and desktop/mobile appQA remain separate obligations.
