### L-wolfpoint-shallow-roof-covering-2386 — one reconstructed shingle-joint skin

**Building:** Wolf Point Tavern.
**Decision:** The actual blind-door/rounded-log comparison still has a smooth roof, while the independently cleared Blanchard/Shober1867 NYPL sheet depicting1833 shows a dark textured roof field. The sheet does not resolve measured piece widths, courses, relief, timber species, pigment or exact roofing fabric. The existing log-building roofing argumentL266 bounds a shingle category; its use here remains a reconstructed exterior surface proxy, not an attested historical material identification.

Choose240mm piece widths and180mm exposure measured on the slope, with alternating half-width joint stations,3mm half-width joint bands,6mm side-joint and8mm butt-joint vertical depressions. These dimensions, repetition, shading and hidden details are chosen, not recovered from pixels. Use only the existing roof and dark palette slots. Dark joints represent a narrow recess/shadow, not a claim of black pigment, literal tar, painted lines, measured age or authentic colour. No image pixels are copied as textures and no new material definition is introduced.

Replace only the opted-in bounded elbow's eight original upper-envelope polygons with a continuous clipped partition. The covering stays on or at most8mm below the same upper envelope. Its true eave, gable, ridge and valley boundaries stay at their original elevations; coplanar producer-cell boundaries are cancelled before edge masking so they do not become invented roof breaks. Preserve every old underside,50mm closing edge band and gable face. There is no second hidden upper plane, raised silhouette, open crack or duplicated surface. All covering faces emit reconstructed confidence1.

The control is keyword-only and defaults off. All81 frozen prior log-family records keep exactly the same raw vertices, faces, materials and confidence with it off; the actual be265 Wolf Point geometry is also unchanged when disabled. Footprint/physical polygon, placement, dates, camera, logs, openings, stack/pipe and pole/board/device remain unchanged. The one opaque solid footprint still governs visitor collision; no interior or passable door is inferred. Source credit/1867 rights basis and retrospective1833-to1835 limitations remain unchanged.

Actual export and same-camera rendered comparison are still required; this prepared proposal is not a visual match. Roof tone, source/camera/metric ambiguity, exact fabrication, wider context and every original picture remain open. Canonical integration owes the guarded current81-family official bake, native consumer regeneration, normal freshness/schema/source/liberty checks, performance and desktop/mobile appQA. The old researchmaster is a comparison baseline, never a canonical asset or recipe substitute.

**Covers:** `wolf_point_tavern.log_frame_1828.form.compound_roof_covering`.
**Ticket:** T-2386.
**Recorded:** 2026-10-23.
