# Closed actual Wolf Point roof-joint trial

One official pinned export and one same-camera capture completedexit0. Full source and actual comparison/detail were directly inspected. Verdict **differs**.

Roof-joint marks are visible, but the result is still pale and the pattern reads coarse/jagged beside the source's soft dark field. This40,622-triangle/3,378,468-byte skin is **not recommended for canonical adoption yet**. The old1,730-triangle baseline and all frozen405inputs remain exact.

See `visual-review.json` for bindings/cost/limits and `reviews/` for actual images. Raw emitted match metadata remainsunreviewed; no accepted reference view or ticket closure was made. All old inputs/producer guards are unchanged; current81canonical bake, native consumers, budget and app QA remain separate obligations.
