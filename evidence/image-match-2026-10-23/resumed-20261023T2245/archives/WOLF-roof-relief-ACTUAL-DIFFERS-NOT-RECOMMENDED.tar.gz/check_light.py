"""Pure geometry/provenance proposal checks; no Blender, browser or publisher."""
from pathlib import Path
from types import ModuleType
from dataclasses import asdict, replace
from collections import Counter, defaultdict
import sys, json, math, inspect, hashlib
sys.dont_write_bytecode = True
H=Path(__file__).resolve().parent; O=H/'baseline'; N=H/'candidate'
sys.path.insert(0,str(N/'generators'));sys.modules['bpy']=ModuleType('bpy')
def load(name,path):
    m=ModuleType(name);m.__file__=str(path);sys.modules[name]=m
    exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
oldp=load('roof_old_params',O/'generators/archetypes/log_dwelling_params.py')
newp=load('roof_new_params',N/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=oldp
old=load('roof_old_mesh',O/'generators/archetypes/log_dwelling.py')
sys.modules['archetypes.log_dwelling_params']=newp
new=load('roof_new_mesh',N/'generators/archetypes/log_dwelling.py')
from common.mesh import MeshBuilder
class Raw(MeshBuilder):
    def to_object(self,materials=None): self.materials=materials;return self
for m in (old,new):m.MeshBuilder=Raw;m.simple_material=lambda *a,**kw:(a,kw)
def raw(b):return b.verts,b.faces,b.conf,b.mat_index,b.named,b.materials
def facekey(b,face,conf,mat):return tuple(tuple(b.verts[i]) for i in face),conf,mat
def faces(b):return Counter(facekey(b,f,c,m) for f,c,m in zip(b.faces,b.conf,b.mat_index))
assert 'compound_roof_covering' in newp.CONSUMED
a=inspect.signature(oldp.LogDwellingParams);b=inspect.signature(newp.LogDwellingParams)
assert [v for k,v in b.parameters.items() if k!='compound_roof_covering']==list(a.parameters.values())
assert b.parameters['compound_roof_covering'].kind==inspect.Parameter.KEYWORD_ONLY
assert b.parameters['compound_roof_covering'].default is None
scope=json.loads((H/'freshness-scope.json').read_text());count=0
for row in scope['assets']:
    r=json.loads((H/'parity-inputs'/f"{row['structure_id']}.json").read_text())
    ph=next(p for p in r['phases'] if p['id']==row['phase_id'])
    x,y=oldp.from_phase(ph,r),newp.from_phase(ph,r);d=asdict(y)
    assert d.pop('compound_roof_covering') is None and d==asdict(x)
    assert raw(old.build(x,Path(row['asset']).stem))==raw(new.build(y,Path(row['asset']).stem))
    count+=1
r=json.loads((N/'data/structures/wolf_point_tavern.json').read_text());ph=r['phases'][0]
br=json.loads((O/'data/structures/wolf_point_tavern.json').read_text())
x=oldp.from_phase(br['phases'][0],br);p=newp.from_phase(ph,r);p.validate()
assert raw(old.build(x,'wolf_point_tavern__log_frame_1828'))==raw(new.build(replace(p,compound_roof_covering=None),'wolf_point_tavern__log_frame_1828'))
old_form=br['phases'][0]['form'];new_form=dict(ph['form']);assert new_form.pop('compound_roof_covering')['confidence']=='reconstructed' and new_form==old_form
prior=dict(br['phases'][0]);current=dict(ph);prior.pop('form');current.pop('form');assert prior==current
assert oldp.side_access_faces(x)==newp.side_access_faces(p)
oldroof=Raw('wolf_point_tavern__log_frame_1828');old._elbow_roof(oldroof,x)
newroof=Raw('wolf_point_tavern__log_frame_1828');new._elbow_roof(newroof,p)
def normal(pts):
    a,b,c=pts[:3]
    return ((b[1]-a[1])*(c[2]-a[2])-(b[2]-a[2])*(c[1]-a[1]),
            (b[2]-a[2])*(c[0]-a[0])-(b[0]-a[0])*(c[2]-a[2]),
            (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))
tops=[];topcounter=Counter()
for f,c,m in zip(oldroof.faces,oldroof.conf,oldroof.mat_index):
    pts=[oldroof.verts[i] for i in f];n=normal(pts)
    if m==old.M_ROOF and n[2]>1e-9:
        aa,bb,dd=-n[0]/n[2],-n[1]/n[2],pts[0][2]+n[0]/n[2]*pts[0][0]+n[1]/n[2]*pts[0][1]
        tops.append(([(v[0],v[1]) for v in pts],lambda x,y,a=aa,b=bb,d=dd:a*x+b*y+d))
        topcounter[facekey(oldroof,f,c,m)]+=1
assert len(tops)==8
skin=Raw('skin');new._elbow_shingle_skin(skin,tops,p.roof_pitch_deg)
def roundedkey(b,f,c,m):return tuple(tuple(round(v,9) for v in b.verts[i]) for i in f),c,m
skinround=Counter(roundedkey(skin,f,c,m) for f,c,m in zip(skin.faces,skin.conf,skin.mat_index))
untouched=Counter()
for f,c,m in zip(newroof.faces,newroof.conf,newroof.mat_index):
    k=roundedkey(newroof,f,c,m)
    if skinround[k]:skinround[k]-=1
    else:untouched[facekey(newroof,f,c,m)]+=1
assert not +skinround, str(list((+skinround).items())[:2])
assert untouched==faces(oldroof)-topcounter, str(('new',list((untouched-(faces(oldroof)-topcounter)).items())[:1], 'old',list(((faces(oldroof)-topcounter)-untouched).items())[:1]))
assert sum(faces(newroof).values())-sum(faces(skin).values())==sum((faces(oldroof)-topcounter).values())
# In particular, the old underside,50mm closing edge bands and every gable face
# remain exact; only the8 old upper planes are replaced with one partitioned skin.
assert set(skin.conf)=={1.} and set(skin.mat_index)<= {new.M_ROOF,new.M_DARK}
assert old.build(x,'wolf_point_tavern__log_frame_1828').materials==new.build(p,'wolf_point_tavern__log_frame_1828').materials
def inside(poly,x,y):
    cross=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):cross.append((b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0]))
    return all(v>=-1e-10 for v in cross) or all(v<=1e-10 for v in cross)
def envelope(x,y):
    return max((z(x,y) for poly,z in tops if inside(poly,x,y)),default=None)
depths=[]
for v in skin.verts:
    top=envelope(*v[:2]);assert top is not None
    d=top-v[2];assert -1e-8<=d<=.008+1e-8,(v,d);depths.append(d)
for f in skin.faces:
    pts=[skin.verts[k] for k in f];assert normal(pts)[2]>1e-12
# Index the real clipped face polygons spatially, then use independent offset
# samples to detect holes or duplicate upper skins, including both valleys.
bins=defaultdict(set);cell=.13
for i,f in enumerate(skin.faces):
    pts=[skin.verts[k] for k in f]
    for ix in range(math.floor(min(v[0] for v in pts)/cell),math.floor(max(v[0] for v in pts)/cell)+1):
        for iy in range(math.floor(min(v[1] for v in pts)/cell),math.floor(max(v[1] for v in pts)/cell)+1):bins[ix,iy].add(i)
samples=0;outside=0
for ix in range(75):
    xx=-.12+(7.44/75)*(ix+.371)
    for iy in range(104):
        yy=-.12+(10.34/104)*(iy+.619);want=envelope(xx,yy)
        hits=[i for i in bins[math.floor(xx/cell),math.floor(yy/cell)] if inside([skin.verts[k][:2] for k in skin.faces[i]],xx,yy)]
        assert len(hits)==int(want is not None),(xx,yy,hits,want)
        if want is not None:samples+=1
        else:outside+=1
boundaries=[]
for poly,z in tops:
    for a,b in zip(poly,poly[1:]+poly[:1]):
        # Original eave/ridge/valley endpoints remain on their exact envelope.
        for v in (a,b):assert any(math.dist((v[0],v[1],z(*v)),s)<1e-8 for s in skin.verts)
        boundaries.append((a,b))
invalid=[replace(p,compound_roof_covering=v) for v in [False,True,'shingles','metal',0,[],{}]]+[replace(p,compound_joint=None),replace(p,compound_parts=())]
for bad in invalid:
    try:bad.validate()
    except (newp.ParamError,TypeError):pass
    else:raise AssertionError('unsupported covering/plan accepted')
import jsonschema
jsonschema.validate(r,json.loads((H/'structures.schema.json').read_text()))
jsonschema.validate(json.loads((N/'data/sources/blanchard_shober_1867_wolf_point.json').read_text()),json.loads((H/'source.schema.json').read_text()))
for rel in ['docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json','data/sources/assets/nypl-full.jpg']:
    assert (O/rel).read_bytes()==(N/rel).read_bytes()
oldsource=json.loads((O/'data/sources/blanchard_shober_1867_wolf_point.json').read_text());newsource=json.loads((N/'data/sources/blanchard_shober_1867_wolf_point.json').read_text());note=newsource.pop('note');assert note.startswith(oldsource.pop('note')) and newsource==oldsource
built=new.build(p,'wolf_point_tavern__log_frame_1828')
for v in built.verts:assert all(math.isfinite(a) for a in v)
out={'status':'PASS_LIGHT_ONLY_UNRENDERED','all81_raw_material_conf_defaults_exact':count,'prior_actual_Wolf_with_new_control_off_exact':True,'new_keyword_only_control':'compound_roof_covering=None|shingle_relief','chosen_reconstructed_width_m':.24,'chosen_reconstructed_slope_exposure_m':.18,'maximum_vertical_joint_depth_m':max(depths),'all_roof_details_reconstructed':True,'roof_palette_unchanged':True,'original_upper_planes_replaced':len(tops),'original_undersides_edge_bands_gables_exact':True,'actual_partition_samples_single_layer':samples,'outside_samples_without_new_roof':outside,'covering_vertices':len(skin.verts),'covering_triangles':sum(len(f)-2 for f in skin.faces),'vertices':len(built.verts),'triangles':sum(len(f)-2 for f in built.faces),'invalid_cases_refused':len(invalid),'physical_polygon_position_dates_otherform_exact':True,'camera_and_source_image_bytes_exact':True,'source_metadata_unchanged_except_appended_note':True,'schemas':'PASS','limits':'No export/capture or accepted match. Current81canonical integration/official shared-family bake, consumer freshness, performance and appQA remain owed.'}
(H/'light-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
