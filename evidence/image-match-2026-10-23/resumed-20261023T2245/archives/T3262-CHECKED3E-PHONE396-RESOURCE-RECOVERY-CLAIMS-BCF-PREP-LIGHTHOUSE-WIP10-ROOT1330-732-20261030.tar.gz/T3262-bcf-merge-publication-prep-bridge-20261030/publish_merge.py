"""Bounded native-commit transport. Default is read-only planning; no git push/fetch.

Run only after the actual checked final native commits exist. --publish additionally
requires the exact checked final tree, a passing gate receipt, and explicit expected
remote branch state. Native Git SHAs, trees, messages, author dates and parents stay exact.
"""
from pathlib import Path
import argparse,base64,datetime,hashlib,json,os,re,struct,subprocess,time
from urllib.request import Request,urlopen
from urllib.error import HTTPError

REPO='kevinrhaas/chicago';SOURCE=Path('/workspace/chicago');G=SOURCE/'.git'
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*args):
    return subprocess.check_output(['git','-C',str(SOURCE),'-c','gc.auto=0','-c','maintenance.auto=false','-c','protocol.allow=never',*args],env=ENV)
def shab(b):return hashlib.sha256(b).hexdigest()
def gitsha(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def api(path,data=None,method=None,missing=False):
    # Mutable branch/PR/dev reads must never reuse a cached pre-create404.
    actual_method=method or ('GET'if data is None else'POST')
    if actual_method=='GET':path+=('&'if'?'in path else'?')+'codex_read='+str(time.time_ns())
    req=Request('https://api.github.com/repos/'+REPO+'/'+path,data=None if data is None else json.dumps(data).encode(),headers={'User-Agent':'Chicago-standalone-phone-memory-native-transport','Accept':'application/vnd.github+json','Content-Type':'application/json'},method=actual_method)
    try:
        with urlopen(req,timeout=120)as r:return json.load(r)
    except HTTPError as e:
        if missing and e.code==404:return None
        raise
def indexed(wanted):
    wanted=set(wanted);found={s for s in wanted if(G/'objects'/s[:2]/s[2:]).is_file()}
    for p in(G/'objects/pack').glob('*.idx'):
        if wanted<=found:break
        with p.open('rb')as f:
            h=f.read(8);v2=h[:4]==b'\xfftOc';off=8 if v2 else 0
            if v2:assert struct.unpack('>I',h[4:])[0]==2
            f.seek(off);fan=struct.unpack('>256I',f.read(1024));tab=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
            for s in wanted-found:
                key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
                while a<z:
                    m=(a+z)//2;f.seek(tab+m*stride+delta)
                    if f.read(20)<key:a=m+1
                    else:z=m
                f.seek(tab+a*stride+delta)
                if a<fan[key[0]]and f.read(20)==key:found.add(s)
    return found
def obj(kind,s):
    assert s in indexed([s]),'Refuse unknown promisor-object read: '+s
    b=git('cat-file',kind,s);assert gitsha(kind,b)==s;return b
TREES={}
def leaves(s):
    if s in TREES:return TREES[s]
    b=obj('tree',s);i=0;out={}
    while i<len(b):
        n=b.index(b' ',i);mode=b[i:n].decode();z=b.index(b'\0',n+1);name=b[n+1:z].decode();child=b[z+1:z+21].hex();i=z+21
        assert name not in ('.','..')and'/'not in name
        if mode=='40000':out.update({name+'/'+p:v for p,v in leaves(child).items()})
        else:
            assert mode in('100644','100755','120000','160000')
            out[name]=(mode,'commit'if mode=='160000'else'blob',child)
    TREES[s]=out;return out
def commit(s):
    raw=obj('commit',s);header,msg=raw.split(b'\n\n',1);lines=header.decode().splitlines()
    return {'sha':s,'raw_sha256':shab(raw),'raw':raw,'lines':lines,'message':msg.decode(),'tree':next(x[5:]for x in lines if x.startswith('tree ')),'parents':[x[7:]for x in lines if x.startswith('parent ')]}
def native_payload(c):
    assert all(x.startswith(('tree ','parent ','author ','committer '))for x in c['lines']),'Unsupported signed/extra native header; do not rewrite native commit'
    p={'tree':c['tree'],'parents':c['parents'],'message':c['message']}
    for k in['author','committer']:
        line=next(x for x in c['lines']if x.startswith(k+' '));m=re.fullmatch(k+r' (.*) <([^>]+)> (\d+) ([+-]\d{4})',line);assert m
        zone=m[4];offset=(int(zone[1:3])*60+int(zone[3:]))*60*(1 if zone[0]=='+'else-1)
        dt=datetime.datetime.fromtimestamp(int(m[3]),datetime.timezone(datetime.timedelta(seconds=offset)))
        p[k]={'name':m[1],'email':m[2],'date':dt.isoformat()}
    return p
def snapshot():
    return {'HEAD':git('rev-parse','HEAD').decode().strip(),'refs':git('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:shab((G/n).read_bytes())for n in['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status':git('status','--porcelain','--untracked-files=all').decode()}
OLD='3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa'
INCOMING='bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9'
INITIAL='9117b2263cf0aeb5fea33dec4a87ee519c5b41af'
BRANCH='steward/t3262-phone-renderer-memory';TICKET='T-3262';PR=1486
DOCS={'chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md'}
OWN={'chicago/4d/renderers/web/js/railway.js','chicago/4d/renderers/web/js/spatial-batch.js','chicago/4d/tools/check_confidence_lane.mjs','chicago/4d/tools/test_rail_geometry_lifecycle.mjs','chicago/4d/changelog.d/T-3262.json'}|DOCS
FIXED=OWN-DOCS
def diff(old,new):return{p:new.get(p)for p in sorted(set(old)|set(new))if old.get(p)!=new.get(p)}
def working_digest(path,value):
    p=SOURCE/path
    if value is None:
        assert not p.exists()and not p.is_symlink();return None
    assert value[1]=='blob'and value[0]in ('100644','100755')and p.is_file()and not p.is_symlink()
    n=p.stat().st_size;gh=hashlib.sha1(b'blob '+str(n).encode()+b'\0');h=hashlib.sha256()
    with p.open('rb')as f:
        while True:
            b=f.read(1024*1024)
            if not b:break
            gh.update(b);h.update(b)
    assert gh.hexdigest()==value[2],'Working file must be exact committed native blob: '+path
    return h.hexdigest()
def main():
    from urllib.parse import quote
    a=argparse.ArgumentParser(description='Exact genuine currentdev merge publication to existingT3262PR1486; defaultreadonly plan.')
    for k in ['head','qualified-tree','gate-proof','output']:a.add_argument('--'+k,required=True)
    a.add_argument('--expected-old',default=OLD);a.add_argument('--incoming',default=INCOMING)
    a.add_argument('--max-total-bytes',type=int,default=4*1024**2);a.add_argument('--publish',action='store_true');args=a.parse_args()
    os.sched_setaffinity(0,{2});os.nice(19)
    assert args.expected_old==OLD and args.incoming==INCOMING
    assert re.fullmatch('[0-9a-f]{40}',args.head)and re.fullmatch('[0-9a-f]{40}',args.qualified_tree)and args.head not in [OLD,INCOMING,INITIAL]
    assert 0<args.max_total_bytes<=4*1024**2
    out=Path(args.output);out.mkdir(exist_ok=False);save=lambda n,x:(out/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
    before=snapshot();save('SOURCE-BEFORE.json',before)
    assert before['HEAD']==args.head and not before['status']and not(G/'MERGE_HEAD').exists()and git('branch','--show-current').decode().strip()==BRANCH
    old=commit(OLD);incoming=commit(INCOMING);initial=commit(INITIAL);head=commit(args.head)
    assert head['parents']==[OLD,INCOMING]and head['tree']==args.qualified_tree
    # Parent signatures/payloads are never reconstructed or written; their exact
    # already-published SHAs are referenced. Only the new unsigned native merge
    # receives the proven metadata-preserving GitData payload routine.
    payload=native_payload(head)
    ol=leaves(old['tree']);inc=leaves(incoming['tree']);init=leaves(initial['tree']);tip=leaves(head['tree'])
    assert set(diff(init,ol))==OWN,'Existing3e must remain the original seven-path unit on9117'
    canonical_delta=diff(init,inc);assert len(canonical_delta)==35,'Pinned canonical incoming delta must be exactly the reviewed35 paths'
    changes=diff(ol,tip);prdiff=diff(inc,tip)
    assert 1<=len(changes)<=64 and set(changes)<=set(canonical_delta)|DOCS
    assert set(prdiff)==OWN,'Actual PR diff against incoming currentdev must be exactly own seven'
    assert all(tip[p]==ol[p]and tip[p][:2]==('100644','blob')for p in FIXED),'Four code/test files and ownchangelog must remain exact3e'
    assert all(tip.get(p)==inc.get(p)for p in set(tip)|set(inc)if p not in OWN),'Every incoming non-own path/mode/blob/deletion is authoritative'
    assert all(tip[p][:2]==('100644','blob')for p in DOCS)
    changed_sha={p:working_digest(p,v)for p,v in changes.items()}
    all7_sha={p:working_digest(p,tip[p])for p in sorted(OWN)}
    ownbytes={p:obj('blob',tip[p][2])for p in OWN};assert sum(map(len,ownbytes.values()))<=args.max_total_bytes
    # No incoming Field/master/WEB payload may be uploaded. It already exists at
    # one of the genuine remote parents; only newly composed own DOCS can be new.
    known={v[2]for d in [ol,inc]for v in d.values()if v[1]=='blob'}
    unknown_paths={p for p,v in changes.items()if v is not None and v[2]not in known}
    assert unknown_paths<=DOCS,'Unknown remote blob outside composed own docs refuses'
    uploads={tip[p][2]:ownbytes[p]for p in unknown_paths};assert sum(map(len,uploads.values()))<=args.max_total_bytes
    gate_path=Path(args.gate_proof);gate_raw=gate_path.read_bytes();gate=json.loads(gate_raw)
    assert gate.get('status')=='ACTUAL_T3262_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_PASS'and gate.get('exit')==0
    required={'HEAD','staged_tree','tracked_working_bytes','no_untracked','no_conflicts','staged_path_sha256','all_children_reaped'}
    assert required<=set(gate.get('guards',{}))and all(v is True for v in gate['guards'].values())
    assert gate.get('config_unchanged')is True and any('CHECK PASS'in line for line in gate.get('footer',[]))
    b=gate.get('binding',{})
    assert b.get('revision')=='CURRENTDEV_BCF'and b.get('head')==OLD and b.get('source_head')==OLD and b.get('merge_parent')==INCOMING and b.get('pr_base')==INCOMING
    assert b.get('checked_final_staged_tree')==args.qualified_tree and b.get('all_staged_paths')==changed_sha and b.get('all7_source_sha256')==all7_sha
    assert b.get('branch')==BRANCH and b.get('ticket')==TICKET and b.get('source_config_sha256')==shab((G/'config').read_bytes())
    assert re.fullmatch('[0-9a-f]{64}',b.get('root_reviewed_manifest_sha256','')),'Actual root-reviewed docs/source manifest must be bound by the gate'
    for c in [old,incoming]:
        remote=api('git/commits/'+c['sha']);assert remote['sha']==c['sha']and remote['tree']['sha']==c['tree']and[p['sha']for p in remote['parents']]==c['parents']
    existing=api('git/commits/'+args.head,missing=True)
    if existing:assert existing['tree']['sha']==args.qualified_tree and[p['sha']for p in existing['parents']]==[OLD,INCOMING]
    branch_path='git/ref/heads/'+quote(BRANCH,safe='/')
    assert api(branch_path)['object']['sha']==OLD
    pr=api('pulls/'+str(PR));assert pr['state']=='open'and pr['head']['sha']==OLD and pr['head']['ref']==BRANCH and pr['base']['ref']=='dev'
    dev_before=api('git/ref/heads/dev')['object']['sha']
    incoming_audit=[{'path':p,'canonical_mode_type_blob':inc.get(p),'merged_mode_type_blob':tip.get(p)}for p in sorted(canonical_delta)if p not in OWN]
    plan={'status':'EXACT_NATIVE_GENUINE_CURRENTDEV_MERGE_FF_PUBLICATION_PLANNED_NO_WRITES','head':args.head,'tree':args.qualified_tree,'parents':[OLD,INCOMING],'expected_old':OLD,'incoming':INCOMING,'incoming_tree':incoming['tree'],'initial9117':INITIAL,'branch':BRANCH,'PR':PR,'force':False,'branch_creation_allowed':False,'new_PR_allowed':False,'changed_path_count':len(changes),'changed_paths':{p:{'mode_type_blob':v,'sha256':changed_sha[p]}for p,v in changes.items()},'canonical_incoming_delta_count':len(canonical_delta),'canonical_incoming_nonown_mode_blob_audit':incoming_audit,'PR_diff_exact_own7':sorted(OWN),'all7_source_sha256':all7_sha,'own_protected5_exact3e':sorted(FIXED),'new_unknown_blob_paths':sorted(unknown_paths),'new_upload_blob_bytes':sum(map(len,uploads.values())),'all7_postimage_bytes':sum(map(len,ownbytes.values())),'max_total_bytes':args.max_total_bytes,'gate':{'path':str(gate_path),'sha256':shab(gate_raw)},'root_reviewed_manifest_sha256':b['root_reviewed_manifest_sha256'],'current_dev_before':dev_before,'no_canonical_incoming_payload_upload':True,'parent_payloads_referenced_exact_never_recreated':True,'cache_bust_all_GETs':True}
    save('PLAN.json',plan);assert snapshot()==before
    if not args.publish:print(json.dumps({'status':plan['status'],'head':args.head,'changes':len(changes),'new_upload_blob_bytes':plan['new_upload_blob_bytes']}));return
    for s,body in uploads.items():made=api('git/blobs',{'encoding':'base64','content':base64.b64encode(body).decode()});assert made['sha']==s
    if not existing:
        entries=[{'path':p,'mode':'100644','type':'blob','sha':None}if v is None else{'path':p,'mode':v[0],'type':v[1],'sha':v[2]}for p,v in changes.items()]
        made=api('git/trees',{'base_tree':old['tree'],'tree':entries});assert made['sha']==args.qualified_tree
        made=api('git/commits',payload);save('NATIVE-MERGE-COMMIT.json',made);assert made['sha']==args.head,'Refuse native merge SHA rewrite'
    assert snapshot()==before and api(branch_path)['object']['sha']==OLD
    fresh=api('pulls/'+str(PR));assert fresh['state']=='open'and fresh['head']['sha']==OLD and fresh['head']['ref']==BRANCH and fresh['base']['ref']=='dev'
    made=api('git/refs/heads/'+quote(BRANCH,safe='/'),{'sha':args.head,'force':False},method='PATCH');assert made['object']['sha']==args.head
    assert api(branch_path)['object']['sha']==args.head
    public=api('git/commits/'+args.head);assert public['tree']['sha']==args.qualified_tree and[p['sha']for p in public['parents']]==[OLD,INCOMING]
    own_readback=[]
    for p in sorted(OWN):
        request=Request('https://raw.githubusercontent.com/'+REPO+'/'+args.head+'/'+quote(p,safe='/')+'?codex_read='+str(time.time_ns()),headers={'User-Agent':'Chicago-T3262-genuine-merge-native-FF'})
        with urlopen(request,timeout=120)as response:assert response.status==200;body=response.read()
        assert body==ownbytes[p]and gitsha('blob',body)==tip[p][2];own_readback.append({'path':p,'mode':tip[p][0],'git_blob':tip[p][2],'sha256':shab(body),'bytes':len(body)})
    # Bounded immutable tree lookups audit incoming modes/blobs/deletions without
    # downloading Field payloads or making a full new artifact inventory.
    tree_cache={}
    def remote_path(tree,path):
        parts=path.split('/')
        for i,name in enumerate(parts):
            if tree not in tree_cache:
                answer=api('git/trees/'+tree);assert answer['sha']==tree and not answer.get('truncated');tree_cache[tree]={r['path']:r for r in answer['tree']}
            row=tree_cache[tree].get(name)
            if row is None:return None
            if i==len(parts)-1:return(row['mode'],row['type'],row['sha'])
            assert row['type']=='tree';tree=row['sha']
    incoming_readback=[]
    for p in sorted(canonical_delta):
        if p in OWN:continue
        actual=remote_path(args.qualified_tree,p);expected=inc.get(p);assert actual==expected
        incoming_readback.append({'path':p,'canonical_mode_type_blob':expected,'immutable_merged_mode_type_blob':actual,'deletion':actual is None})
    save('IMMUTABLE-OWN7-AND-INCOMING-MODE-BLOB-READBACK.json',{'status':'OWN7_RAW_BYTES_AND_ALL_INCOMING_NONOWN_CHANGED_MODE_BLOB_DELETIONS_EXACT','head':args.head,'tree':args.qualified_tree,'own7':own_readback,'incoming_nonown':incoming_readback,'bounded_directory_tree_lookups':len(tree_cache),'no_incoming_master_WEB_payload_download_or_upload':True})
    attempts=[];final=None
    for i in range(12):
        current=api('pulls/'+str(PR));attempts.append({'attempt':i+1,'state':current['state'],'head':current['head']['sha']});assert current['state']=='open'and current['head']['ref']==BRANCH and current['base']['ref']=='dev'and current['head']['sha']in [OLD,args.head]
        if current['head']['sha']==args.head:final=current;break
        time.sleep(1)
    save('PR-HEAD-READBACK.json',{'attempts':attempts,'head':None if final is None else final['head']['sha']});assert final is not None
    assert api(branch_path)['object']['sha']==args.head
    after=snapshot();save('SOURCE-AFTER.json',after);assert after==before
    result={'status':'EXACT_NATIVE_GENUINE_CURRENTDEV_MERGE_FF_PR1486_OWN7_AND_CANONICAL_INCOMING_READBACK_PASS','head':args.head,'tree':args.qualified_tree,'parents':[OLD,INCOMING],'branch':BRANCH,'PR':PR,'PR_url':final['html_url'],'expected_old':OLD,'force':False,'branch_or_PR_created':False,'PR_metadata_API_write':False,'all7_source_sha256':all7_sha,'own7_immutable_raw_readback':own_readback,'canonical_incoming_nonown_immutable_mode_blob_readback':incoming_readback,'incoming_payloads_already_remote_not_uploaded':True,'new_upload_blob_paths':sorted(unknown_paths),'new_upload_blob_bytes':sum(map(len,uploads.values())),'source_HEAD_index_config_allrefs_status_unchanged':True,'current_dev_before':dev_before,'current_dev_after':api('git/ref/heads/dev')['object']['sha'],'no_merge_to_dev_main_ticket_state_or_production_action':True};save('RESULT.json',result);print(json.dumps({'status':result['status'],'head':args.head,'PR':final['html_url']}))
if __name__=='__main__':main()
