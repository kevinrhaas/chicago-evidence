# Genuine bcf current-dev merge: native FF publication — prepared, unrun

`publish_merge.py` derives from the reviewed V2 FF helper. It is fixed to source/expected remote head `3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa`, canonical incoming `bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9`, existing branch `steward/t3262-phone-renderer-memory` and PR1486. The actual future merged head/tree are unknown parameters; no commit ID is guessed.

## Source and payload boundary

The new native commit must have parents exactly `[3e,bcf]` in that order. The previous3e still differs from original9117 by exactly our seven paths; the canonical9117→bcf delta must be exactly the reviewed35 paths. The new first-parent diff is bounded to those incoming paths plus composed STATUS/ROADMAP, at most64. The actual PR diff against bcf must be exactly our seven paths.

Every incoming non-own path, mode, blob and deletion must equal canonical bcf. In particular, the old Field asset deletion and new phase/MASTER/WEB additions cannot be replaced with an old snapshot. Four code/test files and the own changelog must remain exactly3e; only own STATUS/ROADMAP are composed under the root-reviewed manifest and actual integration gate. The helper streams working hashes to check all first-parent changes and binds all seven final own source hashes.

The union of the two genuine remote parent trees supplies known blobs. Incoming Field payloads already exist remotely and are never uploaded by this transport. Any unknown blob must belong to own STATUS/ROADMAP; newly composed own docs and all seven own source postimages must fit the approved4MiB hard cap. The tree update references canonical incoming blob IDs directly, including deletions. No new full artifact inventory, model copy or fixture is produced.

## Gate, publication and verification

The actual integration gate must be `ACTUAL_T3262_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_PASS`, bind head/source_head3e, merge_parent/pr_basebcf, revisionCURRENTDEV_BCF, exact merged tree, actual staged hash/null-deletion map, all seven own hashes, branch/ticket/config and root-reviewed manifest SHA. Every source/reaper/incoming/docs/protected-code guard and actual CHECKPASS footer must pass. Publication begins only from the clean actual native merged HEAD, with no MERGE_HEAD.

Remote parent commits are referenced by their exact existing SHAs. Their signed payloads are never rewritten. Only the new unsigned native merge uses the existing author/committer/time/message/tree/parent-preserving GitData routine, and a rewritten SHA refuses.

Every GET carries `codex_read=time_ns`, including branch/PR/currentdev. The existing ref must freshly equal3e before the sole mutation: a normal PATCH with `force:false`. No branch or PR creation is possible. All seven own paths receive immutable raw-byte/Gitblob/hash readback. Bounded immutable directory-tree lookups check the incoming changed non-own modes/blobs and deletions against canonical bcf, without downloading or uploading Field MASTER/WEB payloads. The immutable new tree SHA plus local whole-tree comparison binds all other non-own paths. PR1486 must read back at the new head; only short fresh read-only GET polling allows its metadata to catch up.

Local HEAD/index/config/status/all refs remain exact. No PR title/body update, ticket state change, dev merge, main or production action is included. Currentdev is recorded freshly before/after; a later concurrent dev move is disclosed for the next qualification, not silently forced into this commit.

## Later invocation

After the funded canonical import, genuine merge, reviewed source composition, actual passing integration gate and native merged checkpoint:

```bash
source /workspace/shared/resume-chicago-env.sh
PYTHONDONTWRITEBYTECODE=1 python /workspace/T3262-bcf-merge-publication-prep-bridge-20261030/publish_merge.py \
  --expected-old 3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa \
  --incoming bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9 \
  --head ACTUAL_NEW_NATIVE_MERGE_HEAD --qualified-tree ACTUAL_REVIEWED_MERGE_TREE \
  --gate-proof ACTUAL_INTEGRATION_RUN/GATE-RESULT.json \
  --output /workspace/ACTUAL_MERGE_READONLY_PUBLICATION_PLAN
```

The default is read-only planning. Root reviews the actual plan, then uses a new output directory with `--publish`. If later readback fails after the FF, preserve all receipts and verify the published head; never recreate, reset or force the branch.

The3e phone measurement is separate and does not qualify newly added Field geometry. The actual new merged head needs its own current official phone result and required GitHub CI before a normal dev merge. No current or future phone pass is inferred here. This packet only syntax-parses the controller; no source, Git ref, API write or controller execution occurred.
