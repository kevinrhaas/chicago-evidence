from pathlib import Path
import os,importlib.util,json,concurrent.futures,datetime,hashlib
os.sched_setaffinity(0,{2});os.nice(19)
p=Path(__file__).parent;s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);base='9117b2263cf0aeb5fea33dec4a87ee519c5b41af';tip='bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9'
import urllib.request
paths=['chicago/4d/data/front_yards/1904.json','chicago/4d/data/components/prairie_1904/draft_prairie_1904.json','chicago/4d/data/jaunts/prairie-built-so-far.json','chicago/4d/data/sidecars/1904/index.json','chicago/4d/data/sidecars/1904/jaunts/catalog.json','chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/tools/derived_manifest.json']
def raw(z):
 ref,path=z
 with urllib.request.urlopen(urllib.request.Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+ref+'/'+path,headers={'User-Agent':'Chicago-bcf-readonly-runtime-scope'}),timeout=60)as f:b=f.read()
 return (ref,path),json.loads(b)
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:docs=dict(ex.map(raw,[(r,v)for r in [base,tip]for v in paths]))
def delta(a,b,path=''):
 if a==b:return []
 if isinstance(a,dict)and isinstance(b,dict):
  rows=[]
  for k in sorted(a.keys()|b.keys()):
   q=path+'/'+k
   if k not in a:rows.append({'path':q,'added':b[k]})
   elif k not in b:rows.append({'path':q,'removed':a[k]})
   else:rows.extend(delta(a[k],b[k],q))
  return rows
 if isinstance(a,list)and isinstance(b,list):
  old=[x for x in a if x not in b];new=[x for x in b if x not in a]
  return [{'path':path,'old_count':len(a),'new_count':len(b),'removed_rows':old,'added_rows':new}]
 return [{'path':path,'before':a,'after':b}]
changes={v:delta(docs[base,v],docs[tip,v])for v in paths}
(p/'FINITE-RUNTIME-CATALOG-DELTA.json').write_text(json.dumps(changes,indent=2)+'\n')
qs=[('oldWEB','contents/chicago/4d/assets/web/marshall_field_house_1905_prairie__draft_1904.glb?ref='+base),('newWEB','contents/chicago/4d/assets/web/marshall_field_house_1905_prairie__as_mapped_1904.glb?ref='+tip),('PR','pulls/1482')]
def api(z):return z[0],m.api(z[1])
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:apirows=dict(ex.map(api,qs))
small={k:{x:j[x]for x in ['path','sha','size']}for k,j in apirows.items()if k!='PR'};pr=apirows['PR'];small['PR1482']={k:pr[k]for k in ['number','html_url','merged','merge_commit_sha','body']};small['PR1482']['head']=pr['head']['sha'];(p/'WEB-SIZE-AND-INCOMING-PR.json').write_text(json.dumps(small,indent=2)+'\n')
print(json.dumps({'WEB':{k:v for k,v in small.items()if k!='PR1482'},'runtime_deltas':changes,'PRbody':pr['body']},indent=2))
