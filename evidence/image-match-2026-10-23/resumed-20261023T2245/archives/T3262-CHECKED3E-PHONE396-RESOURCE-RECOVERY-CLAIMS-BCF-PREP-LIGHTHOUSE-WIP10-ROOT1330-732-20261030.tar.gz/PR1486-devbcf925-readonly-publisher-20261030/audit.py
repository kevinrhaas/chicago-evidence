from pathlib import Path
import os,json,importlib.util,time,datetime,concurrent.futures
os.sched_setaffinity(0,{2});os.nice(19)
p=Path(__file__).parent;s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
base='9117b2263cf0aeb5fea33dec4a87ee519c5b41af';tip='bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9'
qs={'compare':'compare/'+base+'...'+tip,'commit':'git/commits/'+tip,'fresh':'git/ref/heads/dev?codex_read='+str(time.time_ns())}
def get(z):return z[0],m.api(z[1])
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:data=dict(ex.map(get,qs.items()))
j=data['compare'];assert j['merge_base_commit']['sha']==base and len(j['files'])<300
out={'status':'EXACT_IMMUTABLE_9117_TO_BCF925_READONLY_COMPARE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'tip':tip,'tree':data['commit']['tree']['sha'],'fresh_remote':data['fresh']['object']['sha'],'ahead':j['ahead_by'],'behind':j['behind_by'],'total_commits':j['total_commits'],'commits':[{'sha':c['sha'],'parents':[x['sha']for x in c['parents']],'subject':c['commit']['message'].splitlines()[0]}for c in j['commits']],'files':[{'path':r['filename'],'blob':r['sha'],'status':r['status'],'additions':r['additions'],'deletions':r['deletions']}for r in j['files']]}
(p/'COMPARE-SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n')
patches={r['filename']:r.get('patch')for r in j['files']if r['filename'].endswith(('.py','.js','.mjs'))or r['filename'].endswith(('assets/manifest.json','assets/manifest.web.json'))}
(p/'CODE-AND-MANIFEST-PATCHES.json').write_text(json.dumps(patches,indent=2)+'\n')
print(json.dumps(out,indent=2))
