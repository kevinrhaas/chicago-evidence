# T-3262 genuine current-dev integration: gate and checkpoint only

External helper preparation only. No primary merge/edit, owner, gate, commit, ref update, meter or runtime was executed here. Frozen standalone V2 helpers and their genuine receipts remain unchanged. No fixture/model copy or incoming object import is performed by these helpers.

Actual source parent is `3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa`; actual incoming/current-dev parent is `bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9`. Root performs the ordinary `git merge --no-commit --no-ff` after the bounded canonical import. The prospective merged tree and final checkpoint SHA are unknown until those actual operations.

The integration gate requires HEAD=3e, MERGE_HEAD=bcf, cached origin/dev=bcf and root's exact reviewed staged tree/map. Staged map size is 1–64, with SHA256 for present files and null for authoritative deletions. Every ordinary incoming path must match canonical bcf's real Git mode/blob/deletion; actual cached file blobs must match the working bytes. Assets are verified, never recopied or renamed. The prospective tree may differ from bcf in **only the original seven own paths**.

Four renderer/test files and own changelog stay byte/mode exact to actual 3e. STATUS and ROADMAP are handled entrywise: the exact own prefix from 3e over original 9117 is placed before the complete exact incoming bcf body when incoming changed that document. If incoming did not change it, exact 3e bytes remain. No blind old seven-hash requirement replaces document composition; `all7_source_sha256` records the actual final seven hashes.

Root must supply this real reviewed manifest after the genuine merge/composition:

```json
{
  "status": "ROOT_REVIEWED_T3262_BCF_MERGE_STAGED_PATHS",
  "root_reviewed": true,
  "head": "3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa",
  "merge_parent": "bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9",
  "tree": "ACTUAL_REVIEWED_40_CHARACTER_STAGED_TREE",
  "all_staged_paths": {
    "ACTUAL_PRESENT_PATH": "ACTUAL_SHA256",
    "ACTUAL_DELETED_PATH_IF_ANY": null
  }
}
```

The schema example is descriptive, not a fabricated review or executable input. Gate verifies the exact actual path set and every hash/mode/blob against real native Git state.

After root's source handoff:

```sh
python -B /workspace/T3262-currentdev-bcf-integration-controllers-secondfort-20261030/gate.py --expect-head 3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa --expect-merge-parent bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9 --expect-tree ACTUAL_TREE --expect-branch ACTUAL_BRANCH --ticket T-3262 --reviewed-manifest ACTUAL_ROOT_REVIEW_JSON --execute
python -B /workspace/T3262-currentdev-bcf-integration-controllers-secondfort-20261030/checkpoint.py --expect-head 3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa --expect-merge-parent bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9 --expect-tree ACTUAL_TREE --expect-branch ACTUAL_BRANCH --ticket T-3262 --execute
```

Gate runs the unchanged full ordinary-primary `tools/check.sh`, four workers/CPUs0,1,3,4, existing exact local-file scratch fixture shim, reaper, source/index/config/all-ref guards and real CHECK PASS footer. Workspace floor536,870,912 B plus8 MiB output reserve and shared TMP before/after floor1,800,000,000 B remain unchanged. Native source outcome is saved before the final resource recheck; a resource failure never automatically becomes a qualified GATE result or permits checkpointing. Any later exact owned cleanup/guard recovery belongs to root, with its own explicit receipt.

`GATE-RESULT.json` PASS status is `ACTUAL_T3262_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_PASS`. Binding has revision `CURRENTDEV_BCF`, head/source_head3e, merge_parent/pr_basebcf, checked_final_staged_tree, actual all_staged_paths, current all7_source_sha256, branch/ticket, source_config_sha256, index_semantics, all_refs_before, root_reviewed_manifest_sha256, authoritative incoming modes/blobs and document composition. All original source/index/config/ref guards plus MERGE_HEAD/current-origin/protected-five/document/incoming guards must be true.

Checkpoint creates one ordinary native **two-parent** commit, parents exactly `[3e, bcf]`, identical checked tree and a clean source. All three PR questions use bcf as the appropriate comparison base. Its status is `ACTUAL_T3262_CURRENTDEV_INTEGRATION_NATIVE_MERGE_CHECKPOINT_PASS`, with actual dynamic head/tree/parents, revision/pr_base, all7_source_sha256 and exact gate receipt SHA. Only the own branch ref may change; no remote publication is attempted.

No phone controller is launched or included in this gate/CP-only slice. `common.committed()` supplies the required fresh future phone binding: actual new two-parent head/tree, this integration gate+checkpoint SHA, current seven source hashes, native publication and current data/new incoming model outputs, exact400 MiB config and source/index/config/ref guards. A later official meter must use this **new integration context** and the unchanged full1904/mobile/--gate/--no-snapshot command; standalone3e's phone cannot qualify the enlarged merged scene. New-current-head CI and safe dev merge remain separate root/publisher work.
