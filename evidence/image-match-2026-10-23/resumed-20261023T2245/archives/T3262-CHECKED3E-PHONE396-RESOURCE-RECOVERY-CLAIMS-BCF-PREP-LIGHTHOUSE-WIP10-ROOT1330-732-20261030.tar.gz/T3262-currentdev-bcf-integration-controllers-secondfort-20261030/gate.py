"""Root-only genuine 3e+bcf ordinary native integration source gate. No source edits."""
from common import *
a=args(__doc__);assert a.expect_head==BASE['source_head'];current(a,True);assert a.reviewed_manifest
proof_path=Path(a.reviewed_manifest).resolve();proof_raw=proof_path.read_bytes();proof=json.loads(proof_raw)
assert proof['status']=='ROOT_REVIEWED_T3262_BCF_MERGE_STAGED_PATHS'and proof['root_reviewed']is True
assert proof['head']==a.expect_head and proof['merge_parent']==a.expect_merge_parent and proof['tree']==a.expect_tree
actual=g('diff','--cached','--name-only').decode().splitlines();rows=proof['all_staged_paths'];assert 1<=len(actual)<=64 and set(actual)==set(rows)
assert all(h is None or re.fullmatch('[0-9a-f]{64}',h)for h in rows.values());exact(rows)
assert set(g('diff','--name-only',a.expect_merge_parent).decode().splitlines())==set(BASE['own7_paths']),'Only own7 may differ from authoritative incoming tree'
own7={p:path_sha(p)for p in BASE['own7_paths']}
for p in BASE['own_exact5']:assert own7[p]==BASE['own3e_sha256'][p]
docs=docs_compose()
incoming={}
for record in g('ls-tree','-r','-z',a.expect_merge_parent,'--',*actual).split(b'\0'):
 if record:
  prefix,path=record.split(b'\t');mode,kind,oid=prefix.decode().split();assert kind=='blob';incoming[path.decode()]=dict(mode=mode,blob=oid)
indexed={}
for record in g('ls-files','--stage','-z','--',*actual).split(b'\0'):
 if record:
  prefix,path=record.split(b'\t');mode,oid,stage=prefix.decode().split();assert stage=='0';indexed[path.decode()]=dict(mode=mode,blob=oid)
for record in g('ls-files','--stage','-z','--',*BASE['own_exact5']).split(b'\0'):
 if record:
  prefix,path=record.split(b'\t');mode,oid,stage=prefix.decode().split();assert stage=='0'and mode==BASE['own3e_modes'][path.decode()]
for p,h in rows.items():
 if h is None:assert p not in indexed
 else:
  raw=(R/p).read_bytes();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert indexed[p]['blob']==oid,('Cached/working content mismatch',p)
classification={}
for p,h in rows.items():
 if p in docs:assert indexed[p]['mode']==incoming[p]['mode'];classification[p]='exact_own_prefix_plus_authoritative_incoming_document'
 elif p in BASE['own_exact5']:assert h==BASE['own3e_sha256'][p];classification[p]='protected_own_exact3e'
 else:
  assert incoming.get(p)==indexed.get(p),('Incoming mode/blob/deletion not authoritative',p)
  assert(h is None)==(p not in incoming);classification[p]='authoritative_incoming_mode_blob'if h is not None else'authoritative_incoming_deletion'
config=sha((R/'.git/config').read_bytes());assert config==BASE['source_config_sha256'];before_refs=refs();before_index=index();floors(8*1048576)
shim=Path('/workspace/early-four-node-fixture-scope-20261029/bin/node');assert sha(shim.read_bytes())==BASE['reviewed_fixture_shim_sha256']
assert sha((A/'tools/test_repo_file.mjs').read_bytes())=='3a481450fb9324d285a08492a526e657a39f51d64aa918ee3f39cb6418bc4289'
E['PATH']=str(shim.parent)+':'+E['PATH'];E.update(CHECK_JOBS='4',CHECK_TIMINGS=str(O/'TIMINGS.tsv'),C4D_GATE_REQUIRE_READERS='1',TMPDIR='/tmp',TMP='/tmp',TEMP='/tmp')
assert not(O/'GATE-RESULT.json').exists()
b=dict(revision='CURRENTDEV_BCF',head=a.expect_head,source_head=a.expect_head,merge_parent=a.expect_merge_parent,pr_base=a.expect_merge_parent,branch=a.expect_branch,ticket=a.ticket,
 checked_final_staged_tree=a.expect_tree,all_staged_paths=rows,all7_source_sha256=own7,exact_path_count=len(rows),own_path_count=7,
 authoritative_incoming_entries=incoming,staged_path_classification=classification,own_document_composition=docs,
 root_reviewed_manifest=str(proof_path),root_reviewed_manifest_sha256=sha(proof_raw),source_config_sha256=config,index_semantics=before_index,all_refs_before=before_refs,
 CHECK_JOBS=4,CPU_affinity=[0,1,3,4],workspace_floor_bytes=536870912,workspace_priced_log_output_reserve=8*1048576,caller_tmp_before_after_floor=1800000000,
 native_fixture_shim=str(shim),native_fixture_shim_sha256=BASE['reviewed_fixture_shim_sha256'],shim_scope='Unchanged exact test_repo_file.mjs local-file scratch fixture only; no source/runtime assertion bypass.',no_fixture_or_model_copy=True)
save('GATE-BINDING.json',b);start=time.monotonic();step,reaper=native('check',['bash','tools/check.sh']);current(a,True);exact(rows);exact(own7)
guards=dict(HEAD=g('rev-parse','HEAD').decode().strip()==a.expect_head,MERGE_HEAD=g('rev-parse','MERGE_HEAD').decode().strip()==a.expect_merge_parent,
 cached_origin_dev=g('rev-parse','origin/dev').decode().strip()==a.expect_merge_parent,staged_tree=g('write-tree').decode().strip()==a.expect_tree,
 tracked_working_bytes=not g('diff','--name-only'),no_untracked=not g('ls-files','--others','--exclude-standard'),no_conflicts=not g('ls-files','-u'),
 staged_path_sha256=all(path_sha(p)==h for p,h in rows.items()),source_hashes=all(path_sha(p)==h for p,h in own7.items()),
 all_refs_exact=refs()==before_refs,index_semantics_exact=index()==before_index,config_exact=sha((R/'.git/config').read_bytes())==config,
 protected_own5_exact=all(path_sha(p)==BASE['own3e_sha256'][p]for p in BASE['own_exact5']),own_docs_composed=docs_compose()==docs,
 incoming_authoritative=set(g('diff','--name-only',a.expect_merge_parent).decode().splitlines())==set(BASE['own7_paths']),all_children_reaped=reaper['all_children_reaped'])
text=(O/'check.log').read_text();clean=re.sub(r'\x1b\[[0-9;]*m','',text);passed=step['exit']==0 and reaper['command_exit']==0 and all(guards.values())and bool(re.search(r'^CHECK PASS — \d+ steps, none red\.$',clean,re.M))
save('NATIVE-SOURCE-RESULT-BEFORE-RESOURCE-RECHECK.json',dict(native_source_pass=passed,exit=step['exit'],guards=guards,footer=text.splitlines()[-15:],caller_resource_floors_not_yet_rechecked=True))
floors();save('GATE-RESULT.json',dict(status='ACTUAL_T3262_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_PASS'if passed else'ACTUAL_T3262_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_NOT_QUALIFIED',
 revision='CURRENTDEV_BCF',at=now(),exit=step['exit'],seconds=time.monotonic()-start,binding=b,guards=guards,config_unchanged=guards['config_exact'],footer=text.splitlines()[-15:],step=step,phone_commit_PR_CI_merge_pending=True))
print((O/'GATE-RESULT.json').read_text(),flush=True);raise SystemExit(0 if passed else 1)
