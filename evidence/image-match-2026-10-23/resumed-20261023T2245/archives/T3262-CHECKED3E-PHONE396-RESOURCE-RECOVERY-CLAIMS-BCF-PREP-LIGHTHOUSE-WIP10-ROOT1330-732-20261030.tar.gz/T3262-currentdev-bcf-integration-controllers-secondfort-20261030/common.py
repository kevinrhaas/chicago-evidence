from pathlib import Path
import argparse,datetime,hashlib,json,os,re,shutil,subprocess,time
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path(__file__).resolve().parent;BASE=json.loads((O/'BASE.json').read_bytes())
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
sha=lambda b:hashlib.sha256(b).hexdigest();g=lambda *a:subprocess.check_output(['git','-C',str(R),*a],env=E);now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n')
def args(doc):
 p=argparse.ArgumentParser(description=doc);p.add_argument('--expect-head',required=True);p.add_argument('--expect-tree',required=True);p.add_argument('--expect-merge-parent',default=BASE['merge_parent']);p.add_argument('--expect-branch',required=True);p.add_argument('--ticket',required=True);p.add_argument('--reviewed-manifest');p.add_argument('--execute',action='store_true');a=p.parse_args()
 assert a.execute and all(re.fullmatch('[0-9a-f]{40}',v)for v in [a.expect_head,a.expect_tree,a.expect_merge_parent]);assert a.ticket==BASE['ticket']and a.expect_merge_parent==BASE['merge_parent'];assert a.expect_branch.startswith('steward/')and not any(c in a.expect_branch for c in [' ','\n','..']);return a
def refs():return dict(line.split(' ',1)for line in g('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines())
def index():return dict(stage=sha(g('ls-files','--stage','-z')),flags=sha(g('ls-files','-v','-z')))
def path_sha(p):
 p=R/p
 if not p.exists():assert not p.is_symlink();return None
 assert p.is_file()and not p.is_symlink();return sha(p.read_bytes())
def exact(rows):
 assert all(path_sha(p)==h for p,h in rows.items());assert not g('diff','--name-only')and not g('ls-files','-u')and not g('ls-files','--others','--exclude-standard')
def current(a,merging):
 assert g('rev-parse','HEAD').decode().strip()==a.expect_head and g('symbolic-ref','--short','HEAD').decode().strip()==a.expect_branch and g('write-tree').decode().strip()==a.expect_tree
 assert g('rev-parse','origin/dev').decode().strip()==a.expect_merge_parent
 if merging:assert g('rev-parse','MERGE_HEAD').decode().strip()==a.expect_merge_parent
 else:assert not(R/'.git/MERGE_HEAD').exists()
def floors(reserve=0):assert shutil.disk_usage('/workspace').free>=536870912+reserve and shutil.disk_usage('/tmp').free>=1800000000
def native(name,cmd):
 floors();rp=O/(name+'-REAPER.json');assert not rp.exists();start=time.monotonic()
 with(O/(name+'.log')).open('x')as log:q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','taskset','-c','0,1,3,4',*cmd],cwd=A,env=E,stdout=log,stderr=subprocess.STDOUT)
 r=json.loads(rp.read_bytes());row=dict(name=name,command=cmd,exit=q.returncode,seconds=time.monotonic()-start,all_children_reaped=r['all_children_reaped']);assert r['all_children_reaped'];return row,r
def docs_compose():
 result={}
 for p in ['chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md']:
  ancestor=g('show',BASE['original_own_prefix_base']+':'+p);own=g('show',BASE['source_head']+':'+p);incoming=g('show',BASE['merge_parent']+':'+p)
  assert own.endswith(ancestor);prefix=own[:-len(ancestor)];assert 0<len(prefix)<=8192 and BASE['ticket'].encode()in prefix
  expected=own if incoming==ancestor else prefix+incoming;assert(R/p).read_bytes()==expected,('Own prefix + exact incoming document required',p)
  result[p]=dict(own_prefix_sha256=sha(prefix),own_prefix_bytes=len(prefix),incoming_body_sha256=sha(incoming),incoming_changed=incoming!=ancestor,composed_sha256=sha(expected))
 return result
def committed(a):
 """Fresh context binder for a LATER unchanged official400MiB phone; no phone is launched here."""
 gate=json.loads((O/'GATE-RESULT.json').read_bytes());cp=json.loads((O/'CHECKPOINT-RESULT.json').read_bytes());b=gate['binding']
 assert gate['status']=='ACTUAL_T3262_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_PASS'and gate['exit']==0 and all(gate['guards'].values())and gate['config_unchanged']
 assert b['revision']=='CURRENTDEV_BCF'and b['head']==BASE['source_head']and b['merge_parent']==BASE['merge_parent']
 assert cp['status']=='ACTUAL_T3262_CURRENTDEV_INTEGRATION_NATIVE_MERGE_CHECKPOINT_PASS'and cp['head']==a.expect_head and cp['tree']==a.expect_tree and cp['parents']==[b['head'],b['merge_parent']]and cp['source_gate_exact_tree']and cp['source_clean']
 assert cp['source_gate_sha256']==sha((O/'GATE-RESULT.json').read_bytes())and cp['all7_source_sha256']==b['all7_source_sha256']and a.expect_branch==cp['branch']==b['branch']and a.ticket==cp['ticket']==b['ticket']
 assert g('show','-s','--format=%P',a.expect_head).decode().strip().split()==cp['parents'];assert json.loads((O/'check-REAPER.json').read_bytes())['all_children_reaped']
 assert 'bash tools/publish.sh'in(O/'TIMINGS.tsv').read_text()and'published ../../site/4d'in(O/'check.log').read_text();current(a,False);exact(b['all_staged_paths']);exact(b['all7_source_sha256']);assert not g('status','--porcelain=v1')
 config=sha((R/'.git/config').read_bytes());assert config==b['source_config_sha256'];ix=index();rf=refs();ceil=(A/'tools/memory_ceilings.json').read_bytes()
 assert ceil==g('show',b['head']+':chicago/4d/tools/memory_ceilings.json')and json.loads(ceil)['ceilings']['1904']['mobile']['total_bytes']==400*1048576
 pubpaths={'site/4d/build.json','site/4d/data/scenes/1904.json','site/4d/walk/js/railway.js','site/4d/walk/js/spatial-batch.js','site/4d/walk/js/main.js','site/4d/data/sidecars/1904/people.json'}
 for p,h in b['all_staged_paths'].items():
  if p.startswith('chicago/4d/data/'):
   pub='site/4d/data/'+p.removeprefix('chicago/4d/data/')
   if h is not None and(R/pub).is_file():pubpaths.add(pub)
  if p.startswith('chicago/4d/assets/web/')and h is not None:
   pub='site/4d/data/gltf/'+p.removeprefix('chicago/4d/assets/web/');assert(R/pub).is_file();pubpaths.add(pub)
 pub={p:sha((R/p).read_bytes())for p in sorted(pubpaths)}
 for name in ['railway.js','spatial-batch.js']:assert(A/'renderers/web/js'/name).read_bytes()==(R/'site/4d/walk/js'/name).read_bytes()
 def guard():
  current(a,False);exact(b['all_staged_paths']);exact(b['all7_source_sha256']);assert not g('status','--porcelain=v1')and index()==ix and refs()==rf and sha((R/'.git/config').read_bytes())==config
  assert all(sha((R/p).read_bytes())==h for p,h in pub.items())and(A/'tools/memory_ceilings.json').read_bytes()==ceil
 guard();return guard,dict(revision='CURRENTDEV_BCF',head=a.expect_head,tree=a.expect_tree,base=b['head'],source_parent=b['head'],merge_parent=b['merge_parent'],pr_base=b['merge_parent'],parents=cp['parents'],branch=a.expect_branch,ticket=a.ticket,
  source_gate=str(O/'GATE-RESULT.json'),source_gate_sha256=sha((O/'GATE-RESULT.json').read_bytes()),native_checkpoint=str(O/'CHECKPOINT-RESULT.json'),native_checkpoint_sha256=sha((O/'CHECKPOINT-RESULT.json').read_bytes()),
  all7_source_sha256=b['all7_source_sha256'],incoming_staged_paths=b['all_staged_paths'],source_config_sha256=config,index_semantics=ix,all_refs=rf,critical_current_published_sha256=pub,memory_config_sha256=sha(ceil),memory_limit_bytes=400*1048576,ordinary_PRIMARY_native_publication_no_fixture=True)
