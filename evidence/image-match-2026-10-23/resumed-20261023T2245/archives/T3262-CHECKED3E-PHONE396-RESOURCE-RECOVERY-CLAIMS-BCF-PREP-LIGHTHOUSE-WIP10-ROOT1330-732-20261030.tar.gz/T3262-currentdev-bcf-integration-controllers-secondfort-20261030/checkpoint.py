"""Root-only ordinary native two-parent checkpoint after the actual genuine-merge fullgate."""
from common import *
a=args(__doc__);gate=json.loads((O/'GATE-RESULT.json').read_bytes());b=gate['binding']
assert gate['status']=='ACTUAL_T3262_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_PASS'and gate['exit']==0 and all(gate['guards'].values())and gate['config_unchanged']
assert b['revision']=='CURRENTDEV_BCF'and b['head']==a.expect_head==BASE['source_head']and b['merge_parent']==a.expect_merge_parent==BASE['merge_parent']
assert b['checked_final_staged_tree']==a.expect_tree and b['branch']==a.expect_branch and b['ticket']==a.ticket
current(a,True);exact(b['all_staged_paths']);exact(b['all7_source_sha256']);assert docs_compose()==b['own_document_composition']
assert refs()==b['all_refs_before']and index()==b['index_semantics']and sha((R/'.git/config').read_bytes())==b['source_config_sha256'];assert json.loads((O/'check-REAPER.json').read_bytes())['all_children_reaped'];floors()
q=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m',a.ticket+': Integrate current dev for current phone qualification'],cwd=R,env=E,capture_output=True,text=True)
(O/'NATIVE-COMMIT.log').write_text(q.stdout+q.stderr);assert q.returncode==0,q.stderr
head=g('rev-parse','HEAD').decode().strip();tree=g('rev-parse','HEAD^{tree}').decode().strip();parents=g('show','-s','--format=%P',head).decode().strip().split()
assert tree==a.expect_tree and parents==[b['head'],b['merge_parent']]and not g('status','--porcelain=v1')and not(R/'.git/MERGE_HEAD').exists()
after_refs=refs();assert after_refs=={**b['all_refs_before'],'refs/heads/'+a.expect_branch:head};steps=[]
for name,cmd in [('changelog-entry',['node','tools/check-changelog-entry.mjs',b['merge_parent'],'HEAD']),('ticket-ids',['node','tools/resolve_id_collisions.mjs','--base',b['merge_parent'],'--check']),('fold-history',['node','tools/check-changelog.mjs'])]:
 row,reaper=native(name,cmd);steps.append(row);save('CHECKPOINT-STEPS.json',steps);assert row['exit']==0 and reaper['command_exit']==0
assert not g('status','--porcelain=v1');exact(b['all_staged_paths']);exact(b['all7_source_sha256']);assert refs()==after_refs and sha((R/'.git/config').read_bytes())==b['source_config_sha256'];floors()
save('CHECKPOINT-RESULT.json',dict(status='ACTUAL_T3262_CURRENTDEV_INTEGRATION_NATIVE_MERGE_CHECKPOINT_PASS',revision='CURRENTDEV_BCF',at=now(),head=head,tree=tree,parents=parents,
 pr_base=b['merge_parent'],branch=a.expect_branch,ticket=a.ticket,all7_source_sha256=b['all7_source_sha256'],source_gate=str(O/'GATE-RESULT.json'),source_gate_sha256=sha((O/'GATE-RESULT.json').read_bytes()),
 source_gate_exact_tree=True,source_clean=True,only_own_branch_ref_changed=True,steps=steps,phone_NOT_run=True,required_current_phone_PR_CI_and_safe_dev_merge_pending=True))
print((O/'CHECKPOINT-RESULT.json').read_text(),flush=True)
