from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import quote
import argparse,base64,datetime,hashlib,importlib.util,json,os,stat,subprocess,zlib,time
P=Path('/workspace/PR1486-bcf925-canonical-price-publisher-20261030');O=Path(__file__).parent;price=json.loads((P/'RESULT.json').read_text());price.update(secondary_head='3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa',secondary_tree='a3bc0f126d0a1f3e944b287258d6e000e4f41bdc');TIP=price['tip'];OLD='9117b2263cf0aeb5fea33dec4a87ee519c5b41af';HEAD='3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa';BRANCH='steward/t3262-phone-renderer-memory';C=Path('/workspace/chicago');FLOOR=536870912;RESERVE=16777216;TMPFLOOR=1800000000;GUARD=1048576
sha=lambda b:hashlib.sha256(b).hexdigest();free=lambda p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize;save=lambda n,x:(O/n).write_text(json.dumps(x,indent=2)+'\n')
a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--source-phase-lease');a.add_argument('--funding-handshake-json');args=a.parse_args()
plan={'status':'DEFAULT_PLAN_ONLY_NO_SOURCE_OR_OBJECT_MUTATION','tip':TIP,'tree':price['tree'],'expected_HEAD':HEAD,'expected_branch':BRANCH,'expected_origin_dev':OLD,'only_intentional_ref_change':'origin/dev9117->exactbcf925 afterallcanonicalreadbacks andfreshsame-tip guard','objects':price['new_total_objects'],'raw_bytes':price['new_total_raw_bytes'],'allocation_upper':price['new_total_allocation_upper_4k'],'future_checkout_NET_reserve':13373440,'newcheckoutwrite_peak':28299264,'required_workspace':price['required_workspace_bytes']+13373440,'future_checkout_NET_reserve':13373440,'future_checkout_newwrite_peak':28299264,'working_reserve_covers_checkout_transient_excess':28299264-13373440<=RESERVE,'workspace_free':free('/workspace'),'tmp_free':free('/tmp'),'workspace_floor':FLOOR,'working_reserve':RESERVE,'tmp_floor':TMPFLOOR,'fetch':False,'method':'RAM canonical GitData reconstruction and verified immutable blobs; exclusive missing loose-object writes only; source/index/config/HEAD/otherrefs unchanged; onlyexactoriginCASaftercanonicalreadbacks; nativeindexstaging+flags exact/rawstatcacheSHA separate; no fetch/lazyfetch','execution_prerequisites':['Root conditional exactbcf925 canonical REST object import+origin9117 CAS grant on CPU2','Root explicit CLOSED3ephone+exactfundingreceipt+sourcephase importhandshake received: actualpricedallocation+WS512MiBfloor+16MiBworkingreserve+1MiBguard fits; callerTMP1.8GB','Primary clean3e/a3bc,7checkedpostimages/allresidentmodelbytes dynamically exact; nativeparents/signatures canonical; no isolatedrepo/fetch/lazyfetch','Otheragentscontinue; Rootsoleprimarysourcewriter paused only for its importhandshake, no newexternalruntimefixture','Ifactualremote tip advanced, preserve pricedbcf925 objects but doNOTCAS/retarget blindly; reportfresh tip'],'later_dev_unqualified':True,'required_native_PR1486_head':price['secondary_head'],'native_PR1486_tree':price['secondary_tree'],'primary_source_index_and_other_refs_unchanged':True};save('ACTUAL-EXECUTION-PLAN.json'if args.execute else'PLAN.json',plan)
if not args.execute:print(json.dumps(plan,indent=2));raise SystemExit(0)
assert args.source_phase_lease=='root-approved-exact-bcf925-canonical-import-and-origin9117-cas'
assert args.funding_handshake_json,'No import without Root explicit CLOSEDphone+funding+sourcelease handshake JSON'
handshake=json.loads(Path(args.funding_handshake_json).read_text());assert handshake['explicit_root_import_authorization'] is True and handshake['exact_tip']==TIP and handshake['expected_source_head']==HEAD and handshake['closed_phone_head']==HEAD and handshake['closed_phone_PASS'] is True and handshake['funding_verified'] is True and handshake['source_lease_released_to_import'] is True;
for name in['funding','phone']:
 path=Path(handshake[name+'_receipt_path']);assert sha(path.read_bytes())==handshake[name+'_receipt_sha256'],name+' actualreceipt checksum differs'
save('EXPLICIT-ROOT-FUNDING-PHONE-HANDSHAKE.json',handshake)
REQUIRED=price['required_workspace_bytes']+13373440
os.sched_setaffinity(0,{2});os.nice(19)
s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def state():
 x=m.snapshot();x['metadata'].pop('index',None);x['index_staging_sha256']=sha(m.git('ls-files','--stage','-z'));x['index_flags_sha256']=sha(m.git('ls-files','-v','-z'));paths=set(m.git('diff','--name-only','-z','HEAD').split(b'\0'))|set(m.git('ls-files','--others','--exclude-standard','-z').split(b'\0'));rows={}
 for raw in paths:
  if not raw:continue
  p=raw.decode();f=C/p
  if not f.exists()and not f.is_symlink():rows[p]={'deleted':True};continue
  assert not f.is_symlink()and f.is_file(),p
  b=f.read_bytes();rows[p]={'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(f.stat().st_mode)}
 x['workingbytes']=rows
 binding=json.loads((O/'CHECKED3E-SEVEN-POSTIMAGES.json').read_text());assert binding['head']==HEAD and binding['tree']==price['secondary_tree']and binding['branch']==BRANCH and len(binding['all7_source_sha256'])==7;x['checked7_source_sha256']={p:sha((C/p).read_bytes())for p in binding['all7_source_sha256']};assert x['checked7_source_sha256']==binding['all7_source_sha256'];return x

def resident_digest():
 native=m.commit(HEAD);assert native['tree']==price['secondary_tree'];expected=m.leaves(native['tree']);paths=sorted(x for x in m.git('ls-files','-z').split(b'\0')if x);assert set(map(os.fsdecode,paths))==set(expected)
 h=hashlib.sha256();mh=hashlib.sha256();counts={'tracked_paths':len(paths),'resident_files':0,'resident_symlinks':0,'absent':0,'regular_bytes':0,'model_files':0,'model_bytes':0}
 for rawpath in paths:
  path=C/os.fsdecode(rawpath);mode,kind,sid=expected[os.fsdecode(rawpath)];assert kind=='blob'and mode in('100644','100755','120000')
  if path.is_symlink():
   b=os.fsencode(os.readlink(path));assert mode=='120000'and m.gitsha('blob',b)==sid;row=b'link '+b;counts['resident_symlinks']+=1
  else:
   assert path.is_file(),str(path);a=path.stat();assert bool(a.st_mode&0o111)==(mode=='100755');fh=hashlib.sha256();gh=hashlib.sha1(b'blob '+str(a.st_size).encode()+b'\0')
   with path.open('rb')as f:
    while True:
     chunk=f.read(1024*1024)
     if not chunk:break
     fh.update(chunk);gh.update(chunk)
   z=path.stat();assert(a.st_ino,a.st_size,a.st_mtime_ns,a.st_mode)==(z.st_ino,z.st_size,z.st_mtime_ns,z.st_mode),'Concurrent resident mutation: '+str(path);assert gh.hexdigest()==sid,'Resident source differs from exactcurrent3e nativeHEAD: '+str(path)
   row=(str(stat.S_IMODE(a.st_mode))+' '+str(a.st_size)+' '+fh.hexdigest()).encode();counts['resident_files']+=1;counts['regular_bytes']+=a.st_size
   if os.fsdecode(rawpath).startswith('chicago/4d/assets/')and os.fsdecode(rawpath).endswith('.glb'):mh.update(rawpath+b'\0'+row+b'\0');counts['model_files']+=1;counts['model_bytes']+=a.st_size
  h.update(rawpath+b'\0'+row+b'\0')
 return {'status':'ALL_CURRENT3E_TRACKED_RESIDENT_AND_DYNAMIC_MODEL_BYTES_EXACT_NATIVE_HEAD','sha256':h.hexdigest(),'dynamic_model_sha256':mh.hexdigest(),**counts,'scope':'Allpresent current3e nativeHEAD preimages inclGitblobSHA, actualfilesystemmodes, symlinktargets. Dynamicmodelscope; no old3746/2073map reuse.'}


assert m.api('pulls/1486?codex_read='+str(time.time_ns()))['head']['sha']==price['secondary_head'],'Remote1486 head changed; reprice, do not guess';before=state();save('SOURCE-BEFORE.json',before);save('INDEX-RAW-CACHE-BEFORE.json',{'sha256':sha((m.G/'index').read_bytes()),'staging':before['index_staging_sha256'],'flags':before['index_flags_sha256'],'HEAD_tree':price['secondary_tree']});resident_before=resident_digest();save('ALL-TRACKED-RESIDENT-BEFORE.json',resident_before);assert before['HEAD']==HEAD and m.git('branch','--show-current').decode().strip()==BRANCH and m.git('rev-parse','origin/dev').decode().strip()==OLD and not(m.G/'MERGE_HEAD').exists() and not before['status'];assert free('/workspace')>=REQUIRED and free('/tmp')>=TMPFLOOR
remote=m.api('git/commits/'+TIP);assert remote['sha']==TIP and [r['sha']for r in remote['parents']]==price['parents'];tree=m.api('git/trees/'+remote['tree']['sha']+'?recursive=1');assert not tree['truncated']and tree['sha']==price['tree'];leaves={r['path']:r for r in tree['tree']if r['type']!='tree'};save('REMOTE-COMMIT.json',remote)
groups={}
for r in tree['tree']:
 parent,_,name=r['path'].rpartition('/');groups.setdefault(parent,[]).append((name,r))
roots={'':tree['sha'],**{r['path']:r['sha']for r in tree['tree']if r['type']=='tree'}};meta={}
for path,tid in roots.items():
 rows=sorted(groups[path],key=lambda x:x[0].encode()+(b'/'if x[1]['type']=='tree'else b''));b=b''.join((('40000'if r['type']=='tree'else r['mode']).encode()+b' '+name.encode()+b'\0'+bytes.fromhex(r['sha']))for name,r in rows);assert m.gitsha('tree',b)==tid;meta[tid]=('tree',b)
def reconstruct(c):
 v=c['verification'];payload=v.get('payload');sig=v.get('signature')
 if payload and sig:
  h,msg=payload.encode().split(b'\n\n',1)
  for signature in [sig.encode(),sig.encode().rstrip(b'\n')]:
   lines=signature.split(b'\n');gpg=b'gpgsig '+b'\n '.join(lines);raw=h+b'\n'+gpg+b'\n\n'+msg
   if m.gitsha('commit',raw)==c['sha']:return raw
 if not sig:
  def actor(k):
   x=c[k];dt=datetime.datetime.fromisoformat(x['date'].replace('Z','+00:00'));return k+' '+x['name']+' <'+x['email']+'> '+str(int(dt.timestamp()))+' +0000'
  h=['tree '+c['tree']['sha'],*['parent '+p['sha']for p in c['parents']],actor('author'),actor('committer')]
  for ending in ['', '\n']:
   raw=('\n'.join(h)+'\n\n'+c['message']+ending).encode()
   if m.gitsha('commit',raw)==c['sha']:return raw
 raise AssertionError('Canonical commit reconstruction refused; no assumed timezone/signature: '+c['sha'])

for cid,c in json.loads((P/'NEW-COMMIT-GITDATA.json').read_text()).items():meta[cid]=('commit',reconstruct(c))
for tid,j in json.loads((P/'EXTRA-TREE-GITDATA.json').read_text()).items():
 rows=sorted(j['tree'],key=lambda r:r['path'].encode()+(b'/'if r['type']=='tree'else b''));raw=b''.join((('40000'if r['type']=='tree'else r['mode']).encode()+b' '+r['path'].encode()+b'\0'+bytes.fromhex(r['sha']))for r in rows);assert m.gitsha('tree',raw)==tid;meta[tid]=('tree',raw)

payloads={};rows=[]
for r in price['rows']:
 sid=r['sha'];kind=r['kind']
 if kind in('tree','commit'):
  actualkind,b=meta[sid];assert actualkind==kind
 elif 'feature_commit'in r:
  j=m.api('git/blobs/'+sid);b=base64.b64decode(j['content']);assert len(b)==j['size']
 else:
  with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+r.get('origin_tip',TIP)+'/'+quote(r['path'],safe='/'),headers={'User-Agent':'Chicago-exact-bcf925-canonical-bounded-object-import'}),timeout=60)as f:b=f.read(r['bytes']+1);assert f.status==200
 assert len(b)==r['bytes']and sha(b)==r['sha256']and m.gitsha(kind,b)==sid
 enc=zlib.compress(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b);assert len(enc)==r['encoded_bytes']and sha(enc)==r['encoded_sha256'];payloads[sid]=enc;rows.append(r)
assert len(rows)==price['new_total_objects']and sum(r['bytes']for r in rows)==price['new_total_raw_bytes'];assert state()==before and free('/workspace')>=REQUIRED and free('/tmp')>=TMPFLOOR
written=[];already=[]
for r in rows:
 sid=r['sha']
 if sid in m.indexed([sid]):
  b=m.obj(r['kind'],sid);assert len(b)==r['bytes']and sha(b)==r['sha256'];already.append(sid);continue
 d=m.G/'objects'/sid[:2]/sid[2:];assert not d.exists();d.parent.mkdir(exist_ok=True);tmp=d.with_name(d.name+'.exact-bcf925-canonical-'+str(os.getpid()));enc=payloads[sid]
 with tmp.open('xb')as f:f.write(enc);f.flush();os.fsync(f.fileno())
 assert tmp.read_bytes()==enc;os.link(tmp,d);tmp.unlink();os.chmod(d,0o444);raw=zlib.decompress(d.read_bytes());header,b=raw.split(b'\0',1);assert header==r['kind'].encode()+b' '+str(len(b)).encode()and len(b)==r['bytes']and m.gitsha(r['kind'],b)==sid and sha(b)==r['sha256'];written.append(sid);assert free('/workspace')>=FLOOR+RESERVE+GUARD+13373440 and free('/tmp')>=TMPFLOOR
assert m.commit(TIP)['tree']==tree['sha']and m.commit(TIP)['parents']==[r['sha']for r in remote['parents']];assert m.leaves(tree['sha'])=={p:(r['mode'],r['type'],r['sha'])for p,r in leaves.items()};ids={r['sha']for r in leaves.values()};assert ids<=m.indexed(ids)
assert m.git('merge-base',OLD,TIP).decode().strip()==OLD and state()==before
secondary=m.commit(price['secondary_head']);assert secondary['tree']==price['secondary_tree'];secondary_tree=m.api('git/trees/'+secondary['tree']+'?recursive=1');assert not secondary_tree['truncated'];secondary_leaves={r['path']:r for r in secondary_tree['tree']if r['type']!='tree'};assert m.leaves(secondary['tree'])=={p:(r['mode'],r['type'],r['sha'])for p,r in secondary_leaves.items()};assert {r['sha']for r in secondary_leaves.values()}<=m.indexed(r['sha']for r in secondary_leaves.values());all_blobs={r['sha']:r for r in [*leaves.values(),*secondary_leaves.values()]if r['type']=='blob'};lines=subprocess.check_output(['git','-C',str(C),'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],input=('\n'.join(sorted(all_blobs))+'\n').encode(),env=m.ENV);observed={sid:int(size)for sid,kind,size in(map(str.split,lines.decode().splitlines()))if kind=='blob'};assert observed=={sid:r['size']for sid,r in all_blobs.items()};assert m.api('pulls/1486?codex_read='+str(time.time_ns()))['head']['sha']==price['secondary_head'],'Remote1486 changed during import; objects retained but no refCAS'
resident_after=resident_digest();save('ALL-TRACKED-RESIDENT-AFTER.json',resident_after);assert resident_after==resident_before;assert state()==before
fresh=m.api('git/ref/heads/dev?codex_read='+str(time.time_ns()))['object']['sha'];save('FRESH-DEV-BEFORE-CAS.json',{'tip':fresh,'priced_target':TIP,'same':fresh==TIP});cas=fresh==TIP
if cas:m.git('update-ref','refs/remotes/origin/dev',TIP,OLD)
after=state();save('SOURCE-AFTER.json',after);expected=json.loads(json.dumps(before))
if cas:expected['refs']=[x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+TIP)for x in expected['refs']]
assert after==expected,'Source/indexsemantics/config/HEAD/status/otherrefs changed outsideexactintendedCAS'
save('INDEX-RAW-CACHE-AFTER.json',{'sha256':sha((m.G/'index').read_bytes()),'staging':after['index_staging_sha256'],'flags':after['index_flags_sha256'],'HEAD_tree':price['secondary_tree'],'rawSHAunchanged_not_claimed':True,'import_never_writes_index':True})
save('RESULT.json',{'status':'ACTUAL_BCF925_CANONICAL_NATIVE_IMPORT_ORIGIN9117_EXPECTED_OLD_CAS_ALL_SOURCE_GUARDS_PASS'if cas else'EXACT_BCF925_CANONICAL_OBJECTS_READY_REMOTE_ADVANCED_NO_CAS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tip':TIP,'tree':tree['sha'],'old_origin_dev':OLD,'native_remote1486_head':price['secondary_head'],'native_remote1486_tree':price['secondary_tree'],'native_remote1486_all_tip_leaves_exact':len(secondary_leaves),'source_HEAD':HEAD,'source_branch':BRANCH,'written_objects':written,'already_exact':already,'all_tip_leaves_exact':len(leaves),'all_tip_objects_indexed':len(ids),'raw_bytes':price['new_total_raw_bytes'],'allocation_upper':price['new_total_allocation_upper_4k'],'future_checkout_NET_reserve':13373440,'newcheckoutwrite_peak':28299264,'source_HEAD_index_STAGING_and_flags_config_status_workingbytes_otherrefs_exact':True,'raw_index_SHA_unchanged_not_claimed':True,'semantic_index_staging_flags_exact_raw_cache_SHA_separate':True,'dynamic_current3e_models_exact':True,'checked7_source_postimages_exact':True,'all_tracked_resident_files_bytes_modes_exact':True,'resident_guard':resident_after,'origin_dev_CAS_performed':cas,'cached_origin_dev':m.git('rev-parse','origin/dev').decode().strip(),'fetch':False,'workspace_free':free('/workspace'),'tmp_free':free('/tmp'),'remote_dev':fresh,'later_dev_unqualified':fresh!=TIP,'merge_native_owners_gate_phone_commit_publication_not_yet_run':True});print((O/'RESULT.json').read_text())
