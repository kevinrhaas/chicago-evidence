from pathlib import Path
import sys,types,importlib.util,json,dataclasses,hashlib,math,time,copy,inspect
sys.dont_write_bytecode=True
out=Path(__file__).resolve().parent;root=Path('/workspace/chicago/chicago/4d');base=Path('/tmp/dearborn-profile-implemented-20261029/before/chicago/4d');cand=Path('/tmp/dearborn-profile-implemented-20261029/candidate/chicago/4d');start=time.monotonic()
sys.path.insert(0,str(root/'generators'));sys.modules['bpy']=types.ModuleType('bpy')
from common import mesh
mesh.MeshBuilder.to_object=lambda self,mats=None:{'verts':self.verts,'faces':self.faces,'confidence':self.conf,'materials':mats,'mat_index':self.mat_index,'named':self.named}
mesh.simple_material=lambda name,rgba,roughness=.75:{'name':name,'rgba':rgba,'roughness':roughness}
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=load('crib_old_params',base/'generators/archetypes/bridge_timber_params.py');new=load('crib_new_params',cand/'generators/archetypes/bridge_timber_params.py')
def producer(name,params):
 sys.modules['archetypes.bridge_timber_params']=params;return load(name,(cand if params is new else base)/'generators/archetypes/bridge_timber.py')
of=producer('crib_old_build',old);nf=producer('crib_new_build',new)
entries=json.loads((root/'assets/manifest.json').read_text())['assets'];rows=[];inputs={root/'assets/manifest.json',root/'generators/archetypes/bridge_timber.py',root/'generators/archetypes/bridge_timber_params.py',root/'generators/common/mesh.py',root/'generators/common/materials.py',root/'generators/common/logwork.py'}
records=[]
for asset,e in entries.items():
 if e.get('archetype')!='bridge_timber':continue
 rp=root/'data/structures'/f"{e['structure_id']}.json";inputs.add(rp);records.append((asset,e,rp))
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
for asset,e,rp in records:
 r=json.loads(rp.read_text());ph=next(p for p in r['phases'] if p['id']==e['phase_id']);a=old.from_phase(ph,r);b=new.from_phase(ph,r)
 d=dataclasses.asdict(b);assert d.pop('draw_bearing_supports') is False;assert d.pop('draw_profile') == 'flat';assert d.pop('draw_rise_m') == 0;assert d==dataclasses.asdict(a)
 ga=of.build(a,asset);gb=nf.build(b,asset);assert ga==gb,asset
 rows.append({'asset':asset,'verts':len(gb['verts']),'polygons':len(gb['faces']),'whole_raw_geometry_material_confidence_named_exact':True})
assert len(rows)==6
old_fields=dataclasses.fields(old.BridgeTimberParams);new_fields=dataclasses.fields(new.BridgeTimberParams);legacy=[f for f in new_fields if f.name not in ['draw_bearing_supports','draw_profile','draw_rise_m']]
assert [(f.name,f.default,f.default_factory,f.kw_only) for f in old_fields]==[(f.name,f.default,f.default_factory,f.kw_only) for f in legacy]
assert inspect.signature(new.BridgeTimberParams).parameters['draw_bearing_supports'].kind==inspect.Parameter.KEYWORD_ONLY
assert old.BridgeTimberParams.__match_args__==new.BridgeTimberParams.__match_args__
r=json.loads((cand/'data/structures/dearborn_street_drawbridge.json').read_text());p=new.from_phase(r['phases'][0],r)
before_record=copy.deepcopy(r)
for key in ['draw_bearing_supports','draw_profile','draw_rise_m']:before_record['phases'][0]['form'].pop(key)
a=old.from_phase(before_record['phases'][0],before_record);ga=of.build(a,'same');gb=nf.build(p,'same')
assert len(a.pier_x)==len(p.pier_x)==12
assert p.gallows_x==a.gallows_x and p.deck_height_m==a.deck_height_m
assert all(math.isfinite(k) for v in gb['verts'] for k in v)
assert set(gb['confidence']) <= {0.0,.5,1.0}
invalid=[]
for name,change in [('numeric1',{'draw_bearing_supports':1}),('string',{'draw_bearing_supports':'yes'}),('None',{'draw_bearing_supports':None}),('no_draw',{'draw_span_m':None}),('one_gallows',{'gallows_frames':1}),('no_survivors',{'draw_span_m':75.0}),('one_bay',{'pier_count':0}),('zero_rise',{'draw_rise_m':0}),('nan_rise',{'draw_rise_m':float('nan')}),('bool_rise',{'draw_rise_m':True}),('over3m_rise',{'draw_rise_m':3.01}),('overquarter_rise',{'draw_rise_m':2.,'draw_span_m':6.}),('flat_with_rise',{'draw_profile':'flat'}),('wrong_profile',{'draw_profile':'open'})]:
 try:dataclasses.replace(p,**change).validate()
 except new.ParamError:invalid.append(name)
 else:raise AssertionError(name)
# Independently intersect the actual native deck polygons at chosen non-gap floor points.
# This is not a render/export. Preserve gaps: do not invent a height when no deck face covers x/y.
def triangle_height(pt,tri):
 x,y=pt;(ax,ay,az),(bx,by,bz),(cx,cy,cz)=tri
 den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy)
 if abs(den)<1e-14:return None
 u=((by-cy)*(x-cx)+(cx-bx)*(y-cy))/den
 v=((cy-ay)*(x-cx)+(ax-cx)*(y-cy))/den;w=1-u-v
 if min(u,v,w)<-1e-9:return None
 return u*az+v*bz+w*cz
triangles=[]
for f,mat in zip(gb['faces'],gb['mat_index']):
 if mat != nf.M_DECK:continue
 pts=[gb['verts'][i] for i in f]
 for j in range(1,len(pts)-1):triangles.append([pts[0],pts[j],pts[j+1]])
physical=[];gaps=[]
for x in [i*p.span_m/120+0.001 for i in range(120)]:
 hits=[z for tri in triangles if (z:=triangle_height((x,p.width_m/2),tri)) is not None]
 expected=p.deck_height_m + new.draw_rise_m_at(p,x)
 if not hits:gaps.append(x);continue
 top=max(hits);assert abs(top-expected)<1e-10,(x,top,expected)
 physical.append({'x':x,'mesh_deck_top':top,'profile':expected})
assert len(physical)>110
profile=new.walk_surface_profile(p)
# Execute the exact candidate compiler's profile-owner function without its full-scene writer.
import ast
compile_ast=ast.parse((out/'candidate/chicago/4d/tools/compile_scene.py').read_text())
reader=[n for n in compile_ast.body if isinstance(n,ast.FunctionDef) and n.name in ['walk_surface_m','walk_surface_profile']]
namespace={'ROOT':root,'sys':sys};sys.modules['archetypes.bridge_timber_params']=new
exec(compile(ast.Module(body=reader,type_ignores=[]),'<bound native compiler profile reader>','exec'),namespace)
assert namespace['walk_surface_profile'](r,r['phases'][0])==profile
assert namespace['walk_surface_m'](r,r['phases'][0])==2.22
precise=copy.deepcopy(r);precise['phases'][0]['form']['deck_height_m']={'value':2.22222,'confidence':'reconstructed','note':'Finite precision regression fixture only, not adopted source.'}
precise_params=new.from_phase(precise['phases'][0],precise)
precise_profile=namespace['walk_surface_profile'](precise,precise['phases'][0])
precise_base=namespace['walk_surface_m'](precise,precise['phases'][0])
assert precise_base==precise_params.deck_height_m==2.22222
assert precise_profile['stations_m'][0][1]==precise_base==precise_profile['stations_m'][-1][1]
scalar_only=copy.deepcopy(precise);scalar_only['phases'][0]['form']['draw_profile']['value']='flat';scalar_only['phases'][0]['form']['draw_rise_m']['value']=0
assert namespace['walk_surface_m'](scalar_only,scalar_only['phases'][0])==2.2222
assert namespace['walk_surface_profile'](scalar_only,scalar_only['phases'][0]) is None
side=json.loads((root/'data/sidecars/1835/dearborn_street_drawbridge.json').read_text());side['placement']['walk_surface_m']=precise_base;side['placement']['walk_surface_profile']=precise_profile
(out/'FIVE-DECIMAL-COMPILER-FIXTURE.json').write_text(json.dumps({'source':'Exact candidate compiler functions executed with actual native params; isolated functions not fullscene compile.','sidecar':side,'scalar_only_legacy_base':2.2222,'physical_native_base':precise_params.deck_height_m,'physical_native_apex':precise_params.deck_height_m+precise_params.draw_rise_m},indent=2)+'\n')
for _,_,rp in records:
 record=json.loads(rp.read_text())
 assert namespace['walk_surface_profile'](record,record['phases'][0]) is None
assert all(new.walk_surface_profile(new.from_phase(json.loads(rp.read_text())['phases'][0])) is None for _,_,rp in records)
(out/'NATIVE-PROFILE-FIXTURE.json').write_text(json.dumps({'profile':profile,'sidecar':json.loads((root/'data/sidecars/1835/dearborn_street_drawbridge.json').read_text()),'physical_samples':physical,'raw_deck_gaps_no_height':gaps},indent=2)+'\n')
assert hashes=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
assert all((base/rel).read_bytes()==(root/rel).read_bytes() for rel in ['generators/archetypes/bridge_timber_params.py','data/structures/dearborn_street_drawbridge.json'])
result={'status':'PASS_PURE_ONLY_UNADOPTED','elapsed_s':time.monotonic()-start,'six_default_raw_controls':rows,'legacy_positional_count':len([f for f in old_fields if not f.kw_only]),'legacy_defaults_factories_match_args_exact':True,'new_keywords_CONSUMED':[x for x in ['draw_bearing_supports','draw_profile','draw_rise_m'] if x in new.CONSUMED],'candidate':{'vertices':len(gb['verts']),'polygons':len(gb['faces']),'fan_triangles':sum(len(f)-2 for f in gb['faces']),'support_count':len(p.pier_x),'profile':profile,'physical_floor_samples_compared':len(physical),'gaps_preserved_as_nohit':len(gaps),'max_floor_residual_m':max(abs(x['mesh_deck_top']-x['profile']) for x in physical)},'isolated_native_compiler_profile_function_matches_and_all6_defaults_omit':True,'legal_5decimal_profiled_scalar_exact_2_22222_legacy_scalar_only_2_2222':True,'invalid_controls_refused':invalid,'canonical_input_hashes_before_after_exact':hashes,'limits':'Pure native parameter/mesh lists only. No canonical claim/adoption/Blender/nativeexport/WEB/browser/wholeyardclearance/fullgate/imageacceptance.'}
(out/'PURE-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='canonical_input_hashes_before_after_exact'},indent=2))
