# Bridge profile precision correction — v2 increment

UNADOPTED. Apply this two-path increment after the immutable44-file minimum-profile packet. It changes only the compiler's scalar-height handling for a declared profile and one stale Dearborn bearing note. No canonical source, claim, export, browser or native pipeline action occurred.

The independently found counterexample was legal explicit `deck_height_m=2.22222`: the compiler rounded its scalar floor to2.2222 while the pure profile retained2.22222. The strict JS consumer correctly refused the contradictory endpoints. The corrected scalar reader obtains the exact first height from the same pure profile. All scalar-only floors keep their historical four-decimal return; the profile, mesh heights and strict JS tolerance remain unchanged. The note now states that approaches retain their height while the separately declared profile raises the centre.

`PRECISION-2PATH-INCREMENT.patch` and `SOURCE-BINDINGS.json` bind exact before/after bytes against the original candidate. The complete original remains required for other ten source paths and its append-only Liberty text. Do not overwrite shared source from a whole older snapshot.

Actual checks pass: the exact candidate compiler functions plus native parameter resolution produce scalar/profile2.22222; the actual JS helper accepts the compiled five-decimal descriptor and agrees at the native apex. An explicit scalar-only2.22222 case still returns2.2222. The existing small suite was rerun into this separate output directory: all six default raw meshes,20 legacy positional fields,116 physical floor samples/four gaps, native walker1024 steps, route grid/exact regression and human root hook pass. All61 executed JS file-module hashes remain exact. These are finite pure/Node fixture checks, not full scene compilation or app/export acceptance.

Original44-file packet and independent review remain immutable. Whole emitted-yard/horse/vehicle clearance, native MASTER/WEB production, camera/gallows/trestle fitting, actual app and full gates remain before adoption/PR. Root controls the native/browser lease. This correction awaits independent re-review.
