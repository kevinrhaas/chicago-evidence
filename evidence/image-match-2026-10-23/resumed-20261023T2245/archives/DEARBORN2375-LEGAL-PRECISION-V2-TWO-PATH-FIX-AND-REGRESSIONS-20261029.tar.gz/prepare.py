from pathlib import Path
import hashlib,json,difflib,datetime
out=Path(__file__).resolve().parent;original=Path('/tmp/dearborn-profile-implemented-20261029');base=original/'candidate/chicago/4d'
rels=['tools/compile_scene.py','data/structures/dearborn_street_drawbridge.json'];old={rel:(base/rel).read_bytes() for rel in rels};new={k:v.decode() for k,v in old.items()}
a='''        value = getattr(mod.from_phase(phase), "deck_height_m", None)
    except Exception:  # noqa: BLE001
        return None
    return round(float(value), 4) if value is not None else None
'''
b='''        params = mod.from_phase(phase)
        value = getattr(params, "deck_height_m", None)
        reader = getattr(mod, "walk_surface_profile", None)
        if callable(reader):
            profile = reader(params)
            if profile is not None:
                # A declared profile follows the mesh's exact parameter heights.
                # Rounding only its scalar base would contradict its endpoints.
                return float(profile["stations_m"][0][1])
    except Exception:  # noqa: BLE001
        return None
    # Preserve the historical four-decimal scalar contract for every flat deck.
    return round(float(value), 4) if value is not None else None
'''
assert new[rels[0]].count(a)==1;new[rels[0]]=new[rels[0]].replace(a,b)
a='The deck remains flat at its previous height.';b='The approaches retain their previous height; the separately declared closed-draw profile raises only the centre.';assert new[rels[1]].count(a)==1;new[rels[1]]=new[rels[1]].replace(a,b)
for rel in rels:
 for part,b in [('before',old[rel]),('candidate',new[rel].encode())]:
  p=out/part/'chicago/4d'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
patch=''.join(''.join(difflib.unified_diff(old[rel].decode().splitlines(True),new[rel].splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel)) for rel in rels);(out/'PRECISION-2PATH-INCREMENT.patch').write_text(patch)
proof={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'External unadopted two-path increment over immutable44fileoriginal. No canonical source/claim/native/browser writes.','original_manifest_sha256':hashlib.sha256((original/'MANIFEST.json').read_bytes()).hexdigest(),'preimages':{r:hashlib.sha256(b).hexdigest() for r,b in old.items()},'postimages':{r:hashlib.sha256(b.encode()).hexdigest() for r,b in new.items()},'change':'Profiled scalar base follows exact same pure profile endpoint; scalar-only4-decimal behavior retained. Stale flat-deck note updated for raisedcentre/flatapproaches.'};(out/'SOURCE-BINDINGS.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof['change'])
