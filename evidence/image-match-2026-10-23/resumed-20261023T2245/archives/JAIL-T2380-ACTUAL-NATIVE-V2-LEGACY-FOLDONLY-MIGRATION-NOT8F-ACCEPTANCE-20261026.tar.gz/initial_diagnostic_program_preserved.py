from pathlib import Path
import subprocess,json,hashlib,os,tempfile,shutil,datetime
os.sched_setaffinity(0,{2});repo=Path('/tmp/jail-picture-c6');source=repo/'chicago/4d/tools/dev-smoke-state.mjs';causal=Path('/workspace/shared/T2380-release-meta-causal-readonly-20261026T1443');out=Path('/workspace/shared/T2380-legacy-to-v2-native-migration-closed-20261026T1533');out.mkdir(mode=0o700);fixture=Path(tempfile.mkdtemp(prefix='jail-native-v2-migration-',dir='/tmp'));env=dict(os.environ);env['GIT_NO_LAZY_FETCH']='1';sha=lambda b:hashlib.sha256(b).hexdigest();old='8cd2db60777947a16399459fd2945eb804849a51';other='70a8de845adb5c20e16de3b1860efc51d2ea3a87'
def orig(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo,env=env)
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=fixture,env=env)
subprocess.run(['git','init','-q',str(fixture)],check=True);common=Path(orig('rev-parse','--git-common-dir').decode().strip());common=common if common.is_absolute()else repo/common;(fixture/'.git/objects/info/alternates').write_text(str((common/'objects').resolve())+'\n');git('update-ref','HEAD',old);git('read-tree',old)
current={}
for raw in orig('ls-files','--stage','-z').decode().strip('\0').split('\0'):
 left,path=raw.split('\t',1);mode,blob,stage=left.split();assert stage=='0';current[path]=(mode,blob)
entries={}
for raw in (causal/'EXACT_OLD_AND_CURRENT_GLOBAL_INDEX_LISTING.txt').read_text().splitlines():
 left,path=raw.split('\t',1);mode,blob,stage=left.split();assert stage=='0';entries[path]=(mode,blob)
for raw in orig('ls-tree','-rz',old).decode().strip('\0').split('\0'):
 left,path=raw.split('\t',1);mode,kind,blob=left.split()
 if path.endswith('.gitignore')or path=='.gitignore':entries[path]=(mode,blob)
copied=0;linked=0
for path,(mode,blob)in entries.items():
 dst=fixture/path;dst.parent.mkdir(parents=True,exist_ok=True);src=repo/path
 if mode!='120000'and current.get(path)==(mode,blob)and src.is_file()and not src.is_symlink():os.link(src,dst);linked+=1
 else:
  data=orig('cat-file','blob',blob);copied+=len(data);assert copied<64*1024**2,'Bounded privatefixture materialization only'
  if mode=='120000':os.symlink(data.decode(),dst)
  else:dst.write_bytes(data);dst.chmod(0o755 if mode=='100755' else 0o644)
helper=fixture/'chicago/4d/tools/dev-smoke-state.mjs';helper.parent.mkdir(parents=True,exist_ok=True);helper.write_bytes(source.read_bytes())
page=fixture/'site/4d/walk/index.html';page.parent.mkdir(parents=True,exist_ok=True);canonical=fixture/'chicago/4d/renderers/web/js/changelog.js';canonical.parent.mkdir(parents=True,exist_ok=True);assert not canonical.exists(),'Excludedcanonicalmustnotbehardlinked'
results=[]
for ref,html in [(old,'FROZEN8CD_NORMALIZED_PUBLISHED_HTML_RECONSTRUCTED.html'),(other,'ACTUAL70_NORMALIZED_PUBLISHED_HTML.html')]:
 git('update-ref','HEAD',ref);git('read-tree',ref);canonical.write_bytes(orig('show',ref+':chicago/4d/renderers/web/js/changelog.js'));page.write_bytes((causal/html).read_bytes());raw=subprocess.check_output(['node',str(helper),'hash','--json'],cwd=fixture,env=env);value=json.loads(raw);assert value['dirty']is False,value;assert value['hash']=='sha256:64d92f1d4534e605',value;(out/(ref[:8]+'-ACTUAL_NATIVE_V2_CLI.json')).write_bytes(raw);results.append({'immutable_index_ref':ref,'native_result':value,'normalized_published_html_sha256':sha(page.read_bytes()),'canonical_sha256':sha(canonical.read_bytes())})
assert results[0]['native_result']['hash']==results[1]['native_result']['hash']and results[0]['native_result']['changelogHash']!=results[1]['native_result']['changelogHash'];result={'status':'EXACT_LEGACY_TO_NATIVE_V2_MIGRATION_PROOF_NOT_CURRENT8F_ACCEPTANCE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_new_native_helper_sha256':sha(source.read_bytes()),'legacy_causal_manifest':'3a3c3450f77eab872cee85f71a809936080b6bfaed14078e91723d7a6cd5f17e','legacy_actual_frozen8cd':'sha256:c2750ca30058eb81','legacy_actual70':'sha256:856fabdf67d5e51a','legacy_fullSHA256_reproduced_in_causal_packet':True,'actual_new_native_CLI_old8cd_and70':results,'new_global_equal':'sha256:64d92f1d4534e605','new_notes_partitions_differ':True,'globally_hashed_actual_files_materialized_and_native_dirtyfalse':True,'private_fixture':str(fixture),'hardlinked_unchanged_files':linked,'old_blob_bytes_copied':copied,'source_index_refs_and_published_files_never_written':True,'no_oldCI_retag_or_currenthead_18_claim':True,'qualification':'Migration isONLY old8cd→70 fold-only world. Current8fDentdata/assets differs globally; useindependentcompleteactive1835closure/currentintegrationqualification, notthismigrationlicense.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');shutil.copy2(__file__,out/'reproduce_actual_native_cli.py');files=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'mode':oct(p.stat().st_mode&0o777)}for p in sorted(out.iterdir())if p.is_file()];m=out/'MANIFEST.json';m.write_text(json.dumps({'files':files},indent=2)+'\n');print(json.dumps(result,indent=2));print(str(m),sha(m.read_bytes()))
