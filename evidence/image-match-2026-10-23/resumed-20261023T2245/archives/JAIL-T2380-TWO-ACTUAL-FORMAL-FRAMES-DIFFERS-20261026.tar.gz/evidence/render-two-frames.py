import os,json,subprocess,datetime,hashlib
from pathlib import Path
app=Path('/tmp/jail-picture-c6/chicago/4d');out=Path('/tmp/T2380-two-official-frames-20261026');out.mkdir();os.sched_setaffinity(0,{4});env=dict(os.environ);env.update(PYTHONPATH='/workspace/shared/python',NODE_PATH='/workspace/shared/node/node_modules',PATH='/workspace/shared/tools/usr/bin:/workspace/shared/gltf-transform/node_modules/.bin:'+env['PATH'],PW_EXECUTABLE='/usr/bin/chromium',TMPDIR='/tmp/jail-native-tmp',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1');steps=[('compile-pictures',['python3','tools/compile_pictures.py']),('publish',['bash','tools/publish.sh']),('gale_1902',['node','tools/photo_match.mjs','data/reference_views/log_jail/gale_1902.json']),('andreas_1884_context',['node','tools/photo_match.mjs','data/reference_views/log_jail/andreas_1884_context.json'])];results=[]
for name,cmd in steps:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(out/(name+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
 rec={'name':name,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'command':cmd};results.append(rec);(out/'STEPS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(rec),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 if name=='compile-pictures':
  d=json.loads((app/'data/pictures/1835.json').read_text())['by_structure']['log_jail'];ids={v['id']for v in d};assert 'trowbridge_first_jail_gale_1902'in ids;assert all('spot'not in v for v in d if v['id']in{'trowbridge_first_jail_gale_1902','andreas_1884_v1'});(out/'PICTURE-OPT-OUT.json').write_text(json.dumps(d,indent=2)+'\n')
(out/'RESULT.json').write_text(json.dumps({'status':'PASS_RENDER_ONLY','affinity':sorted(os.sched_getaffinity(0)),'steps':results,'limits':'Only two actual source frame renders and native picture/publish. No app QA, fullcheck, accepted match or ticket completion.'},indent=2)+'\n')
