// Actual published Hogan scene/card review. No content or API is injected.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire('/workspace/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const root='/workspace/chicago/site';
const out=path.resolve(new URL('./front-qa/',import.meta.url).pathname);
fs.mkdirSync(out,{recursive:true});
const write=(name,v)=>fs.writeFileSync(path.join(out,name),typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon'};
const serverErrors=[];
const server=http.createServer((req,res)=>{
 try{
  let file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
  if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
  if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
  if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
  res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');
  const stream=fs.createReadStream(file);stream.on('error',e=>{serverErrors.push(e.message);res.destroy(e);});stream.pipe(res);
 }catch(e){serverErrors.push(e.message);res.writeHead(500).end();}
});
let browser;
const results=[];
async function settle(page){await page.locator('.navigator').evaluate(async n=>{getComputedStyle(n).width;await Promise.all(n.getAnimations().filter(a=>Number.isFinite(a.effect.getComputedTiming().endTime)).map(a=>a.finished));});}
async function pane(page,key){
 await page.locator(`#nav-app-inspect [data-insp-tab="${key}"]`).click();
 await page.waitForFunction(k=>document.querySelector(`#nav-app-inspect [data-insp-pane="${k}"]`)?.dataset.filled==='yes',key,{timeout:45000});
 await settle(page);
 return page.locator(`#nav-app-inspect [data-insp-pane="${key}"]`);
}
async function observe(page,target,label,key){
 const v=await target.evaluate(p=>({text:p.innerText,links:[...p.querySelectorAll('a')].filter(a=>a.checkVisibility()).map(a=>a.href),visible:p.checkVisibility(),pageOverflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1}));
 write(`${label}-${key}.json`,v);assert(v.visible);assert.equal(v.pageOverflow,false);assert.equal(v.paneOverflow,false);
 await page.screenshot({path:path.join(out,`${label}-${key}.png`)});return v;
}

try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 const context=await browser.newContext({viewport:{width:390,height:780},hasTouch:true,deviceScaleFactor:1});
 const page=await context.newPage(),errors=[],network=[];
 try{
  page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});});page.on('requestfailed',r=>network.push({url:r.url(),failure:r.failure()}));
  await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835&keep-geometry=1`);
  await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:240000,polling:1000});
  const pose=await page.evaluate(async()=>{
   const a=window.__chicago4d,until=Date.now()+90000;while(a.welcome?.state!=='world'&&Date.now()<until){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}if(a.welcome&&a.welcome.state!=='world')throw Error('welcome notworld');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.navigator.dock();a.setAnimationHold(true);
   const s=a.registry.get('hogan_store').sidecar,p=s.placement,t=p.rotation_deg*Math.PI/180,tx=6.858,ty=3.048;
   const world=(u,v)=>({e:p.local_e+u*Math.cos(t)+v*Math.sin(t),n:p.local_n-u*Math.sin(t)+v*Math.cos(t)}),aim=world(tx,ty);
   let stand=null;for(const scale of [1.5,1.7,1.3,2]){const trial=world(tx+(22.02240541992612-tx)*scale,ty+(13.700787264424813-ty)*scale);if(!a.router.blockedAt(trial.e,trial.n)){stand=trial;break;}}
   if(!stand)throw Error('No eligible source-front stand');
   const yaw=(Math.atan2(aim.e-stand.e,aim.n-stand.n)*180/Math.PI+360)%360;
   a.walker.teleport({local_e:stand.e,local_n:stand.n,yaw_deg:yaw,pitch_deg:2});
   const st=a.walker.state,localV=(st.e-p.local_e)*Math.sin(t)+(st.n-p.local_n)*Math.cos(t);
   if(!Number.isFinite(st.eyeY)||localV<=6.096||a.router.blockedAt(st.e,st.n))throw Error('Actual native walker didnot reach eligible fronthemisphere');
   return {placement:p,requestedStand:stand,actualState:{e:st.e,n:st.n,eyeY:st.eyeY},localV,yaw,source:'native walker at router-eligible point derived from retained placement and source-side vector; no building/camera intrinsic edit'};
  });
  write('front-pose.json',pose);await settle(page);
  for(const [label,width,height] of [['mobile',390,780],['desktop-resized',1280,800]]){
   await page.setViewportSize({width,height});
   await page.evaluate(async()=>{const a=window.__chicago4d;a.setConfidenceView(false);await a.capture(1);});
   await page.screenshot({path:path.join(out,`${label}-front-normal.png`)});
   await page.evaluate(async()=>{const a=window.__chicago4d;a.setConfidenceView(true);await a.capture(1);});
   await page.screenshot({path:path.join(out,`${label}-front-confidence.png`)});
   assert.deepEqual(errors,[]);assert.deepEqual(network,[]);assert.deepEqual(serverErrors,[]);
   console.log(`${label}: actual source-front view captured; no page/network errors`);
  }
  write('results.json',{status:'PASS frontview capture only',pose,errors,network,serverErrors,limits:'Additional same actual page resized mobileto1280; initialmainQA independently booted realmobile+desktop. This closes visiblefrontframing gap, not fullsmoke/image acceptance.'});
 }finally{await context.close();}
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));server.closeAllConnections();}
