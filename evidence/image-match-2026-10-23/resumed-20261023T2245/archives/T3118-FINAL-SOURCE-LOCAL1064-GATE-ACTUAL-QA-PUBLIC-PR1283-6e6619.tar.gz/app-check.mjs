// Actual published Hogan scene/card review. No content or API is injected.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire('/workspace/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const root='/workspace/chicago/site';
const out=path.resolve(new URL('./app-qa/',import.meta.url).pathname);
fs.mkdirSync(out,{recursive:true});
const write=(name,v)=>fs.writeFileSync(path.join(out,name),typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon'};
const serverErrors=[];
const server=http.createServer((req,res)=>{
 try{
  let file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
  if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
  if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
  if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
  res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');
  const stream=fs.createReadStream(file);stream.on('error',e=>{serverErrors.push(e.message);res.destroy(e);});stream.pipe(res);
 }catch(e){serverErrors.push(e.message);res.writeHead(500).end();}
});
let browser;
const results=[];
async function settle(page){await page.locator('.navigator').evaluate(async n=>{getComputedStyle(n).width;await Promise.all(n.getAnimations().filter(a=>Number.isFinite(a.effect.getComputedTiming().endTime)).map(a=>a.finished));});}
async function pane(page,key){
 await page.locator(`#nav-app-inspect [data-insp-tab="${key}"]`).click();
 await page.waitForFunction(k=>document.querySelector(`#nav-app-inspect [data-insp-pane="${k}"]`)?.dataset.filled==='yes',key,{timeout:45000});
 await settle(page);
 return page.locator(`#nav-app-inspect [data-insp-pane="${key}"]`);
}
async function observe(page,target,label,key){
 const v=await target.evaluate(p=>({text:p.innerText,links:[...p.querySelectorAll('a')].filter(a=>a.checkVisibility()).map(a=>a.href),visible:p.checkVisibility(),pageOverflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1}));
 write(`${label}-${key}.json`,v);assert(v.visible);assert.equal(v.pageOverflow,false);assert.equal(v.paneOverflow,false);
 await page.screenshot({path:path.join(out,`${label}-${key}.png`)});return v;
}
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 for(const [label,width,height,touch] of [['mobile',390,780,true],['desktop',1280,800,false]]){
  const context=await browser.newContext({viewport:{width,height},hasTouch:touch,deviceScaleFactor:1});
  const errors=[],network=[];let page;
  try{
   await context.addInitScript(()=>localStorage.setItem('chicago4d.researcher','on'));
   page=await context.newPage();page.setDefaultTimeout(90000);
   page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});});page.on('requestfailed',r=>network.push({url:r.url(),failure:r.failure()}));
   const response=await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835&keep-geometry=1`);assert.equal(response.status(),200);
   await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:240000,polling:1000});
   await page.evaluate(async()=>{const a=window.__chicago4d,until=Date.now()+90000;while(a.welcome?.state!=='world'&&Date.now()<until){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}if(a.welcome&&a.welcome.state!=='world')throw Error('welcome did not enter world');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.setAnimationHold(true);a.navigator.dock();assertFrame();function assertFrame(){if(!a.frame('hogan_store'))throw Error('Hogan cannot frame');}await a.capture(1);});
   const data=await page.evaluate(()=>{const a=window.__chicago4d,s=a.registry.get('hogan_store')?.sidecar;return {grade:s?.grade,attributes:s?.attributes,phase:s?.phase,problems:a.problems??[],expectedReviews:[...a.registry.values()].filter(r=>r.sidecar?.review_required).map(r=>r.sidecar.id).sort(),scene:a.scene?.id};});
   write(`${label}-diagnostic.json`,{data,errors,network});assert.equal(data.scene,'1835');assert.equal(data.phase,'log_1831');assert.equal(data.grade?.value,'attested');assert(data.grade.pictures.includes('cameron_c1900_first_post_office'));
   assert.equal(data.attributes.front_door_state.value,'recess');assert.equal(data.attributes.ridge_stack_head_m.value,.75);
   assert.deepEqual(data.attributes.end_openings.value,[{end:'+x',kind:'hatch',at:.5,z:3.35}]);
   for(const k of ['front_door_state','end_openings','ridge_stack_head_m','front_set_out','door_w_m','ridge_stack_w_m'])assert.equal(data.attributes[k].confidence,'reconstructed',k);
   assert.deepEqual(data.attributes.front_set_out.value,[['door',8.45],['window',11.55]]);assert.equal(data.attributes.ridge_stack_w_m.value,.65);
   assert.deepEqual(data.problems.filter(p=>/review_required is set/.test(p)).map(p=>p.split(':',1)[0]).sort(),data.expectedReviews);
   const unexpected=data.problems.filter(p=>!/provisional|PLACEHOLDER|placeholder|review_required is set/i.test(p));assert.deepEqual(unexpected,[]);
   await settle(page);
   await page.screenshot({path:path.join(out,`${label}-scene-normal.png`)});
   await page.evaluate(async()=>{const a=window.__chicago4d;a.setConfidenceView(true);await a.capture(1);});
   await page.screenshot({path:path.join(out,`${label}-scene-confidence.png`)});
   await page.evaluate(async()=>{const a=window.__chicago4d;a.setConfidenceView(false);a.pick('hogan_store');await a.navigator.select('inspect');a.navigator.open(2);});
   await page.waitForFunction(()=>document.querySelector('#nav-app-inspect')?.dataset.structure==='hogan_store',null,{timeout:30000});
   const photosPane=await pane(page,'photos');await photosPane.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});
   const photos=await observe(page,photosPane,label,'photos');assert.match(photos.text,/Cameron/i);assert(photos.links.some(h=>/commons\.wikimedia\.org/.test(h)));
   const sourcesPane=await pane(page,'sources');await sourcesPane.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});
   const sources=await observe(page,sourcesPane,label,'sources');assert.match(sources.text,/Cameron/i);assert.match(sources.text,/Chicago Historical Society/i);
   await sourcesPane.evaluate(p=>{const e=[...p.querySelectorAll('p,li,.src-body')].find(e=>/Chicago Historical Society/i.test(e.innerText));e?.scrollIntoView({block:'center'});});
   await page.screenshot({path:path.join(out,`${label}-source-credit.png`)});
   assert.deepEqual(errors,[]);assert.deepEqual(network,[]);assert.deepEqual(serverErrors,[]);
   const result={viewport:label,width,height,status:'PASS',errors,network,loaderUnexpected:unexpected,grade:data.grade,attributes:data.attributes,photos,sources,limits:'Targeted actual published Hogan normal/confidence/card QA; screenshots require visual review. Not full renderer smoke or accepted source-image match.'};
   results.push(result);write(`${label}-result.json`,result);console.log(`${label}: actual Hogan scene/grade/attributes/Images/source credit PASS, zero page/network/unexpected loader errors`);
  }catch(e){write(`${label}-failure.json`,{message:e.message,stack:e.stack,errors,network});if(page)await page.screenshot({path:path.join(out,`${label}-failure.png`)}).catch(()=>{});throw e;}
  finally{await context.close();}
 }
 write('results.json',{status:'PASS',results,serverErrors});
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));server.closeAllConnections();}
