#!/usr/bin/env bash
# Prepare-only wrapper. Execute only after the assigned exclusive heavy window.
set -euo pipefail
if [[ "${T3118_EXCLUSIVE_HEAVY_SLOT:-}" != "granted" ]]; then
  echo 'Not started: root has not assigned this invocation the exclusive heavy slot.' >&2
  exit 2
fi
TASK_ROOT=/workspace/chicago/chicago/4d
TASK_LOG_ROOT=/workspace/T3118-runtime/gate-runs
TASK_STAMP=$(date -u +%Y%m%dT%H%M%SZ)
TASK_RUN="$TASK_LOG_ROOT/$TASK_STAMP-$$"
mkdir -p "$TASK_RUN/tmp"
# Ticket fixtures select their own sandbox; never export a real clone override.
unset CHICAGO_TICKETS_DIR
export TMPDIR="$TASK_RUN/tmp"
export PYTHONPATH=/workspace/shared/python
export PATH=/workspace/shared/tools/usr/bin:/workspace/shared/tools:/workspace/node_modules/.bin:$PATH
export npm_config_cache=/workspace/shared/npm-cache
export CHECK_JOBS=4
export C4D_GATE_REQUIRE_READERS=1
export CHECK_TIMINGS="$TASK_RUN/check-timings.tsv"
cd "$TASK_ROOT"
if git -C "$TMPDIR" rev-parse --show-toplevel >"$TASK_RUN/tmp-git-root.txt" 2>/dev/null; then
  echo 'Refusing TMPDIR inside a Git repository.' >&2
  exit 2
fi
python3 - "$TASK_RUN/environment-receipt.json" <<'PY'
import json,os,sys
from pathlib import Path
assert 'CHICAGO_TICKETS_DIR' not in os.environ
import shutil
assert shutil.disk_usage(os.environ['TMPDIR']).free >= 2 * 1024**3, 'Need at least2GiB free in external TMPDIR before full gate'
Path(sys.argv[1]).write_text(json.dumps({
    'ticket_repository_override':'unset',
    'TMPDIR':os.environ['TMPDIR'],
    'CHECK_JOBS':os.environ['CHECK_JOBS'],
    'C4D_GATE_REQUIRE_READERS':os.environ['C4D_GATE_REQUIRE_READERS'],
    'gate_has_not_started':True},indent=2)+'\n')
PY
git rev-parse HEAD >"$TASK_RUN/head-before.txt"
git write-tree >"$TASK_RUN/index-tree-before.txt"
git status --porcelain=v1 >"$TASK_RUN/status-before.txt"
date -u +%FT%TZ >"$TASK_RUN/started.txt"
echo "Running native preflight; transcript $TASK_RUN/preflight.log"
set +e
./tools/preflight.sh >"$TASK_RUN/preflight.log" 2>&1
TASK_EXIT=$?
set -e
printf '%s\n' "$TASK_EXIT" >"$TASK_RUN/preflight.exit"
date -u +%FT%TZ >"$TASK_RUN/finished.txt"
# Native preflight owns fixed global log names; copy before releasing the slot.
for TASK_NAME in check cl ids; do
  if [[ -f "/tmp/preflight-$TASK_NAME.log" ]]; then
    cp "/tmp/preflight-$TASK_NAME.log" "$TASK_RUN/preflight-$TASK_NAME.log"
  fi
done
git rev-parse HEAD >"$TASK_RUN/head-after.txt"
git write-tree >"$TASK_RUN/index-tree-after.txt"
git status --porcelain=v1 >"$TASK_RUN/status-after.txt"
tail -16 "$TASK_RUN/preflight.log"
echo "Native preflight exit $TASK_EXIT; closed transcripts $TASK_RUN"
exit "$TASK_EXIT"
