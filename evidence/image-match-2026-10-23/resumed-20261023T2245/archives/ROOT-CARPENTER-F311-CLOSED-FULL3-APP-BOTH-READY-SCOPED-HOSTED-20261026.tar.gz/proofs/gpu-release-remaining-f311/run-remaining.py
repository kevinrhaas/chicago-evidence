from pathlib import Path
import subprocess,json,datetime,hashlib,os,shutil,sys
r=Path('/tmp/jail-picture-c6');p=Path(__file__).parent
b=json.loads((p/'BINDING.json').read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
def guards():
 assert git('rev-parse','HEAD')==b['head']
 assert git('rev-parse','HEAD^{tree}')==b['tree']
 assert not git('status','--porcelain')
 assert hashlib.sha256((r/'chicago/4d/tools/check_upload_release.mjs').read_bytes()).hexdigest()==b['script_sha256']
 assert hashlib.sha256((r/'site/4d/data/gltf/philo_carpenter_log_shop__log_1832.glb').read_bytes()).hexdigest()==b['selected_published_web_sha256']
guards()
assert shutil.disk_usage('/tmp').free>=1000000000
result=dict(status='RUNNING',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),binding=b,affinity=sorted(os.sched_getaffinity(0)),parts=[],scope='Remaining desktop and1904 native functional upload-release phases; exact hosted1835 assertions separately PASS. Hostedworkflow cancelled and retained. No performancecertificate.')
(p/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
for part in b['remaining']:
 env=dict(os.environ,CHECK_ONLY=part,CHECK_PORT='4389')
 log=p/(part+'.log')
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with log.open('w') as out:
  code=subprocess.call(['node','tools/check_upload_release.mjs',b['published_root']],cwd=r/'chicago/4d',env=env,stdout=out,stderr=subprocess.STDOUT)
 text=log.read_text()
 verdict=dict(part=part,exit=code,started=start,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),footer=text.splitlines()[-3:])
 result['parts'].append(verdict)
 (p/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
 if code or 'PASS upload release:' not in text:
  result['status']='FAIL';(p/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');raise SystemExit(code or 1)
 guards()
result['status']='REMAINING_BOTH_NATIVE_PHASES_PASS';result['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();result['post_guards']='exact clean source/script/model unchanged'
(p/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
