from pathlib import Path
import json, os, subprocess, time

root=Path('/workspace/T2382-currentdev-integration-20261026')
receipt=root/'current-full3-reaper.json'
deadline=time.monotonic()+1800
while True:
    result=json.loads(receipt.read_text())
    if result['all_children_reaped']:
        assert result['command_exit']==0, result
        break
    assert time.monotonic()<deadline, 'No final preflight receipt within orchestration window'
    time.sleep(5)
assert json.loads((root/'current-full3/RESULT.json').read_text())['status']=='ALL3_NATIVE_PREFLIGHT_PASS'
env=dict(os.environ)
env.update(CARPENTER_TRUST_PROFILE='/tmp/carpenter-browser-trust-20261026/profile',
           CARPENTER_APP_OUT=str(root/'published-app-review-quiet4-after-full3'))
print('Native gate reaped PASS; starting unchanged app harness on CPUs0,1,2,4', flush=True)
with (root/'published-app-review-quiet4.log').open('x') as log:
    q=subprocess.run(['python','/workspace/shared/run-with-reaping.py',
                      str(root/'published-app-review-quiet4-reaper.json'),'--',
                      'taskset','-c','0,1,2,4','nice','-n','10','node',
                      '/workspace/T2382-Carpenter-adoption-20261026/review-published.mjs'],
                     env=env,stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(q.returncode)
