from pathlib import Path
import subprocess, os, json, datetime
repo=Path('/tmp/jail-picture-c6'); app=repo/'chicago/4d'
out=Path('/workspace/T2382-currentdev-integration-20261026/committed-ending'); out.mkdir()
env=dict(os.environ)
for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR']: env.pop(k,None)
env['GIT_OPTIONAL_LOCKS']='0'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=repo,env=env).decode().strip()
def save(n,v): (out/n).write_text(json.dumps(v,indent=2)+'\n')
def run(n,cmd,cwd=repo):
    with (out/(n+'.log')).open('x') as f: q=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
    assert q.returncode==0,(n,q.returncode)
gate=json.loads((out.parent/'current-full3/RESULT.json').read_text())
reaper=json.loads((out.parent/'current-full3-reaper.json').read_text())
assert gate['status']=='ALL3_NATIVE_PREFLIGHT_PASS' and reaper['command_exit']==0 and reaper['all_children_reaped']
tree=gate['binding']['staged_tree']; base=gate['binding']['actual_dev']; jail='bbbe518720601b785e79628bf247ee4b9f9d4ed8'
assert git('rev-parse','HEAD')==gate['binding']['head'] and git('rev-parse','MERGE_HEAD')==gate['binding']['merge_head']
assert git('write-tree')==tree and not git('diff','--name-only') and not git('ls-files','--others','--exclude-standard')
save('BEFORE.json',dict(at=now(),tree=tree,head=git('rev-parse','HEAD'),merge_head=git('rev-parse','MERGE_HEAD'),scope='Actual full3 passed; app review is ongoing on the identical source tree. This is a checked codecommit, not a release verdict.'))
run('01-normal-checked-Wolf-merge-commit',['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m',"T-2382: show Carpenter's dark doorway and credited picture"])
first=git('rev-parse','HEAD'); assert git('rev-parse','HEAD^{tree}')==tree
save('FIRST-CHECKED-COMMIT.json',dict(at=now(),head=first,tree=tree,parents=git('show','-s','--format=%P','HEAD')))
with(out/'02-normal-checked-Jail-merge.log').open('x') as f: q=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','merge','--no-commit','--no-ff',jail],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
conflicts=git('diff','--name-only','--diff-filter=U').splitlines()
if conflicts:
    allowed=['chicago/4d/docs/ROADMAP.md','chicago/4d/docs/STATUS.md']
    assert all(p in allowed for p in conflicts),('unexpected conflicts; preserving actual state',conflicts)
    for p in conflicts:
        original=subprocess.check_output(['git','show',gate['binding']['head']+':'+p],cwd=repo,env=env)
        incoming=subprocess.check_output(['git','show',jail+':'+p],cwd=repo,env=env)
        checked=subprocess.check_output(['git','show',first+':'+p],cwd=repo,env=env)
        assert incoming.startswith(original) and checked.startswith(original)
        assert checked.endswith(incoming[len(original):])
        (repo/p).write_bytes(checked)
        subprocess.run(['git','add','--',p],cwd=repo,env=env,check=True)
assert not git('ls-files','-u') and git('write-tree')==tree and not git('diff','--name-only')
assert git('rev-parse','MERGE_HEAD')==jail
save('EXACT-TREE-ANCESTRY-PROOF.json',dict(at=now(),before_commit=first,incoming_checked_Jail=jail,gate_tree=tree,actual_merged_tree=git('write-tree'),all_source_blobs_modes_identical=True,authored_conflicts_preserved_exact_checked_blob=conflicts,scope='Normal ancestry attachment; no source, geometry, generated outputs, caps or assertions changed. Same-tree actual preflight remains applicable.'))
run('03-normal-Jail-ancestry-commit',['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','T-2382: attach the checked Jail memory fix without changing source'])
assert git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain=v1')
for name,command in [('04-committed-changelog',['node','tools/check-changelog-entry.mjs',base,'HEAD']),('05-committed-ids',['node','tools/resolve_id_collisions.mjs','--base',base,'--check']),('06-native-history',['node','tools/check-changelog.mjs'])]: run(name,command,app)
native=json.loads(subprocess.check_output(['node','tools/dev-smoke-state.mjs','hash','--json'],cwd=app,env=env)); assert native['dirty'] is False
save('RESULT.json',dict(status='CHECKED_SOURCE_IDENTICAL_NORMAL_ANCESTRY_AND_COMMITTED_ENDING_PASS',at=now(),head=git('rev-parse','HEAD'),tree=tree,first_checked_commit=first,incoming_checked_Jail=jail,actual_dev=base,native_hash=native,pending='Public draft PR, current app/hosted qualification, upstreams and eventual READY/expected-SHA dev merge. Original image ticket remains DIFFERS.'))
print((out/'RESULT.json').read_text(),flush=True)
