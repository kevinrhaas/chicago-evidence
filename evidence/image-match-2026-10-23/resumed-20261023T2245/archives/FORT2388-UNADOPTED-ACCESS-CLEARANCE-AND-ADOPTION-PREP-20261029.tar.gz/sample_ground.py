"""Master-only analytical sampling with actual native foot reader + terrain bytes."""
import sys,json,math,hashlib
from pathlib import Path
ROOT=Path('/workspace/chicago/chicago/4d');P=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tools'))
from heightfield import Heightfield
r=json.loads(Path('/tmp/T2388-gallery-access-implementation-20261029/prototype/fort_dearborn_commandants_quarters.json').read_text());p=r['phases'][0]['position'];datum=json.loads((ROOT/'data/datum.json').read_text());e0,n0=p['utm_e']-datum['origin_utm_e'],p['utm_n']-datum['origin_utm_n'];th=math.radians(p['rotation_deg']);c,s=math.cos(th),math.sin(th)
def enu(u,v):return (e0+u*c+v*s,n0-u*s+v*c)
epoch=ROOT/'data/terrain/epochs/e1834_harbor_cut';h=Heightfield.load(epoch);assert h
feet=json.loads((P/'ACTUAL-MASTER-FOOT-POINTS.json').read_text())['points_x_z'];foot_h=[h.height(*enu(x,-z)) for x,z in feet];base=min([h.height(e0,n0)]+foot_h)
d=7.62;ytop=d-3;bottom=ytop-4.32
samples=[]
for label,uv,z in [('stringer_low_tail',(-2.055,bottom),-.195),('first_tread_front',(-1.6,bottom),.18),('first_tread_back',(-1.6,bottom+.288),.18),('upper_landing',(-1.05,ytop),2.7),('approach_0_5m',(-1.6,bottom-.5),0)]:
 e,n=enu(*uv);ground=h.height(e,n);samples.append({'point':label,'local_u_v_m':uv,'local_ENU_m':[e,n],'model_local_z_m':z,'ground_world_y_m':ground,'model_world_y_m':base+z,'model_minus_ground_m':base+z-ground,'heightfield_covers':h.covers(e,n)})
out={'scope':'Analytical MASTER ground seating only; native master feet through unchanged building-feet.js plus native Heightfield. No compressedWEB/browser run, no actual walkway traversal.','source_master_foot_samples':len(feet),'master_based_building_base_world_y_m':base,'ground_under_master_foot_min_max_m':[min(foot_h),max(foot_h)],'samples':samples,'bindings':[{'path':str(q),'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}for q in [epoch/'heightfield.json',epoch/'heightfield.bin',ROOT/'tools/heightfield.py',ROOT/'renderers/web/js/building-feet.js',ROOT/'renderers/web/js/buildings.js']]}
(P/'ANALYTICAL-MASTER-GROUND.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2)[:3000])
