"""Read-only exact-plan checks; no Blender, GLB generation or app execution."""
import hashlib
import json
import math
import struct
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path('/workspace/chicago/chicago/4d')
OUT=Path(__file__).parent
RECORDS=ROOT/'data/structures'
A=json.loads(Path('/tmp/T2388-gallery-access-implementation-20261029/prototype/fort_dearborn_commandants_quarters.json').read_text())
records={p.stem:json.loads(p.read_text()) for p in RECORDS.glob('fort_dearborn*.json')}
datum=json.loads((ROOT/'data/datum.json').read_text())

def rect(x0,y0,x1,y1):return [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
def world(record,points):
    p=record['phases'][0]['position'];th=math.radians(p.get('rotation_deg',0));c,s=math.cos(th),math.sin(th)
    e0,n0=p['utm_e']-datum['origin_utm_e'],p['utm_n']-datum['origin_utm_n']
    return [(e0+u*c+v*s,n0-u*s+v*c) for u,v in points]
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(p):return abs(sum(p[i][0]*p[(i+1)%len(p)][1]-p[(i+1)%len(p)][0]*p[i][1] for i in range(len(p))))/2 if p else 0
def intersect(subject,clip):
    out=subject[:]
    for i,a in enumerate(clip):
        b=clip[(i+1)%len(clip)];inp,out=out,[]
        if not inp:break
        prev=inp[-1];pc=cross(a,b,prev)
        for cur in inp:
            cc=cross(a,b,cur)
            if (cc>=-1e-9)!=(pc>=-1e-9):
                t=pc/(pc-cc);out.append((prev[0]+t*(cur[0]-prev[0]),prev[1]+t*(cur[1]-prev[1])))
            if cc>=-1e-9:out.append(cur)
            prev,pc=cur,cc
    return out
def point_seg(p,a,b):
    vx,vy=b[0]-a[0],b[1]-a[1];t=max(0,min(1,((p[0]-a[0])*vx+(p[1]-a[1])*vy)/(vx*vx+vy*vy)))
    return math.hypot(p[0]-a[0]-t*vx,p[1]-a[1]-t*vy)
def dist(p,q):
    if area(intersect(p,q))>1e-8:return 0
    return min([point_seg(v,q[j],q[(j+1)%len(q)]) for v in p for j in range(len(q))]+[point_seg(v,p[j],p[(j+1)%len(p)]) for v in q for j in range(len(p))])
def body(r):return world(r,r['phases'][0]['footprint']['polygon'])
NATIVE=Path('/workspace/T2388-native-access-proof-20261029/candidate25')
def hull(points):
    pts=sorted(set(points))
    if len(pts)<3:return pts
    lower=[]
    for p in pts:
        while len(lower)>=2 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
        lower.append(p)
    upper=[]
    for p in reversed(pts):
        while len(upper)>=2 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
        upper.append(p)
    return lower[:-1]+upper[:-1]
def native_projection(r):
    p=NATIVE/(r['id']+'__'+r['phases'][0]['id']+'.glb')
    if not p.exists():return None
    b=p.read_bytes();n,t=struct.unpack_from('<II',b,12);d=json.loads(b[20:20+n]);binary=28+n
    assert all(not any(k in node for k in ['matrix','translation','rotation','scale']) for node in d['nodes'])
    pts=[]
    for mesh in d['meshes']:
        for prim in mesh['primitives']:
            a=d['accessors'][prim['attributes']['POSITION']];view=d['bufferViews'][a['bufferView']]
            assert a['componentType']==5126 and a['type']=='VEC3' and not a.get('sparse')
            stride=view.get('byteStride',12);base=binary+view.get('byteOffset',0)+a.get('byteOffset',0)
            for i in range(a['count']):
                x,y,z=struct.unpack_from('<fff',b,base+i*stride);pts.append((x,-z))
    return world(r,hull(pts))
def form(r,key,default=None):return r['phases'][0].get('form',{}).get(key,{}).get('value',default)
def addition_plans(r,end):
    fp=r['phases'][0]['footprint']['polygon'];w=max(x for x,y in fp);d=max(y for x,y in fp)
    # Exact proposed numeric bounds, plus conservative roof/rail plan envelope.
    ret,run,sw,reach=3.0,4.32,1.0,2.1;yt=d-ret;yb=yt-run
    mirror=lambda p:[(x if end=='min' else w-x,y) for x,y in p]
    shapes={'return_deck':rect(-reach,yt,0,d+reach),'stair_treads':rect(-reach,yb,-reach+sw,yt),'roof_and_rail_envelope':rect(-reach-.15,yb-.0275,0,d+reach+.15)}
    # Mirroring reverses orientation, needed by the convex clip operation.
    return {k:world(r,p if end=='min' else list(reversed(mirror(p)))) for k,p in shapes.items()}
def assess(r,end):
    shapes=addition_plans(r,end); enclosure=body(records['fort_dearborn_palisade']);rows=[]
    for sid,other in records.items():
        if sid in [r['id'],'fort_dearborn_palisade','fort_dearborn_parade','fort_dearborn_garrison_garden']:continue
        pieces={'body':body(other)}
        native=native_projection(other)
        if native:pieces['actual_native_entire_mesh_projection_hull']=native
        if form(other,'gallery',False):
            fp=other['phases'][0]['footprint']['polygon'];w=max(x for x,y in fp);d=max(y for x,y in fp)
            pieces['existing_front_gallery']=world(other,rect(0,d,w,d+2.25))
        for name,p in pieces.items():
            for sk,q in shapes.items():rows.append({'neighbor':sid,'piece':name,'new_piece':sk,'distance_m':dist(p,q),'overlap_m2':area(intersect(p,q))})
    p_rows=[]
    for name,p in shapes.items():
        inside=area(intersect(p,enclosure));
        p_rows.append({'new_piece':name,'area_m2':area(p),'inside_palisade_m2':inside,'outside_palisade_m2':max(0,area(p)-inside),'wall_distance_m':min(point_seg(v,enclosure[j],enclosure[(j+1)%4]) for v in p for j in range(4))})
    return {'end':end,'new_plan_local_ENU_m':shapes,'nearest_neighbors':sorted(rows,key=lambda x:x['distance_m'])[:12],'any_positive_neighbor_overlap':any(x['overlap_m2']>1e-8 for x in rows),'palisade':p_rows}

bindings=[]
for p in sorted(list(RECORDS.glob('fort_dearborn*.json'))+[ROOT/'data/datum.json',ROOT/'renderers/web/js/angles.js',ROOT/'renderers/web/js/buildings.js',ROOT/'renderers/web/js/walker.js',Path('/tmp/T2388-gallery-access-implementation-20261029/prototype/fort_dearborn_commandants_quarters.json')]):
    b=p.read_bytes();bindings.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
result={'at':datetime.now(timezone.utc).isoformat(),'scope':'Analytical pure ENU plan clearance only; no terrain-height sampling, collision/walking run, native bake or browser acceptance.','coordinate_rule':'GLB-CONTRACT: e=e0+u*cos(bearing)+v*sin(bearing); n=n0-u*sin(bearing)+v*cos(bearing).','A_proposed':assess(A,'min'),'A_alternate_end':assess(A,'max'),'B_same_dimension_hypotheses':{end:assess(records['fort_dearborn_officers_quarters'],end) for end in ['min','max']},'bindings':bindings}
(OUT/'PLAN-CLEARANCE.json').write_text(json.dumps(result,indent=2)+'\n')
for key in ['A_proposed','A_alternate_end']:
    a=result[key];print(key,'overlap=',a['any_positive_neighbor_overlap'],'nearest=',a['nearest_neighbors'][0],'palisade=',a['palisade'])
for end,a in result['B_same_dimension_hypotheses'].items():print('B',end,'overlap=',a['any_positive_neighbor_overlap'],'nearest=',a['nearest_neighbors'][0],'palisade=',a['palisade'])
