# One role-candidate comparison after the checked parent and phone

Preparation only. No fixture, browser, native capture, model/source/identity/grade change or primary/Git/ticket/site write. All original readiness, V2 preparation, actual NE40 baseline closure and finite orientation packets remain immutable and SHA-guarded. This controller reuses the proven V2 native capture protocol.

Read-only rehearsal:

```sh
source /workspace/shared/resume-chicago-env.sh
python /workspace/T2378-candidate-controller-20261030/capture.py
```

After the final source gate, phone, native checked commit and a separate root CPU/source grant, use the ACTUAL full40-character checked commit SHA:

```sh
source /workspace/shared/resume-chicago-env.sh
T2378_CANDIDATE_CPU_LEASE=root-one-current-master-role-candidate python /workspace/T2378-candidate-controller-20261030/capture.py --execute --expected-head ACTUAL_CHECKED_COMMIT_SHA --cpu 0,1,3,4
```

`ACTUAL_CHECKED_COMMIT_SHA` is a documented placeholder, not a runnable/accepted SHA. Execution requires a real40-hex argument exactly equal to current primary HEAD, no active merge and no tracked uncommitted changes before any execution directory is created; final HEAD/index/config/status must remain exact. The future integration commit is currently unknown and is neither guessed nor silently rebound. The source gate/phone are coordinator evidence, not assertions forged by this controller. Launch is to be scheduled by root only in the subsequent CI window.

The ONLY camera is the closed `/workspace/T2378-orientation-review-20261030/keyed-1831-one-role-candidate.json`. Its intrinsic/extrinsic/basis/light/near/solve fields are unchanged; only `photo` is rebased to the fixture's native relative source link. It remains a conditional MODEL-frame NW53.9726°/yaw126.0274° role test. Same whole1920×1042 source image, unchanged69cb MASTER and current WEB/native recipe binding; source identity proposal,1857credit/1881key,1831depiction and1835survival uncertainty remain unchanged. No new camera fitting or form choice occurs.

Execution owns only `/workspace/T2378-native-role-candidate-exec-20261030/`, refuses a second run, copies four unchanged native photo-match modules, writes the one relative camera and creates14 finite links for its exact browser dependencies/oneMASTER/oneoriginal photo. No full runtime, all-model alias tree or partial registry is created. Native `--glb` names exactly the guarded current MASTER.

Use the proven V2 resource layout unchanged: command-scoped TMPDIR=`EXEC/tmp`, XDG_CACHE_HOME=`EXEC/cache`, XDG_CONFIG_HOME=`EXEC/config`. Workspace must have536,870,912B+24MiB=562,036,736B free; shared TMP must retain its unchanged1,800,000,000B floor, with no extra reserve because owned payload is in workspace. The <0.25MiB fixture, outputs and20MiB browser scratch fit the24MiB allowance. Fresh Node env/path proof creates no directory. Native photo_match and Playwright profile/artifact helpers use os.tmpdir, and Playwright passes the inherited environment to normal Chromium. Debian's literal `/tmp/chromiumargs` branch remains inactive because the unchanged normal launch has no `-g`/`--debug`; no executable/argument workaround is introduced.

One240s deadline,0.2s floor monitor and the unchanged owned shared subreaper guard the later native command. Preserve the raw match as `unreviewed`; bind camera/photo/GLB SHA, raw PNG, whole-source comparison, native exit and reaping receipt. Root must directly inspect the single comparison to accept or reject the visible gable/eaves role assignment. No geometry, identity or source-grade decision, matches claim, app qualification or original-ticket closure follows automatically. No additional fit loop is authorized by this preparation.

`CONTROLLER-ONLY.diff` is the exact V2-to-candidate change, and `READONLY-PLAN-REHEARSAL.json` records current selected-input/path checks while the final integration remains in progress. Include the small packet with the next substantive checkpoint, not a standalone archive.
