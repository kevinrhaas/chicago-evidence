#!/usr/bin/env python3
"""Default is read-only validation. --execute needs an explicit root CPU lease.

One unchanged current-model native comparison; no camera fitting or geometry edits.
"""
import argparse, datetime, hashlib, json, os, pathlib, re, shutil, signal, subprocess, sys, time

P = pathlib.Path(__file__).resolve().parent
A = pathlib.Path('/workspace/chicago/chicago/4d')
REPO = A.parents[1]
READY = pathlib.Path('/workspace/T2378-current-readiness-20261030')
EXEC = pathlib.Path('/workspace/T2378-native-role-candidate-exec-20261030')
ROOT = EXEC / 'runtime'
FLOORS = {'/workspace': 536870912, '/tmp': 1800000000}
RESERVES = {'/workspace': 24 * 1024**2, '/tmp': 0}
sha = lambda p: hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
plan = json.loads((P / 'PLAN.json').read_text())
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--execute', action='store_true')
ap.add_argument('--cpu', default='0,1,3,4')
ap.add_argument('--expected-head', help='Actual checked primary commit SHA supplied by root; required only for execution')
args = ap.parse_args()
allowed_cpus = os.sched_getaffinity(0)
os.sched_setaffinity(0, {2})
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_NO_LAZY_FETCH='1',
           GIT_OPTIONAL_LOCKS='0', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
           MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', NODE_DISABLE_COMPILE_CACHE='1')
env.update(TMPDIR=str(EXEC / 'tmp'), XDG_CACHE_HOME=str(EXEC / 'cache'),
           XDG_CONFIG_HOME=str(EXEC / 'config'))
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
sys.dont_write_bytecode = True

def validate(check_resources=False):
    assert sha(READY / 'CLOSED-MANIFEST.json') == plan['readiness_manifest_sha256']
    closed = json.loads((READY / 'CLOSED-MANIFEST.json').read_text())
    for row in closed['files']:
        assert sha(READY / row['path']) == row['sha256'], row['path']
    for row in plan['guards']:
        assert sha(row['source']) == row['sha256'], row['source']
    assert sha(P / 'capture.py') == plan['controller_sha256']
    sys.path.insert(0, str(A / 'generators'))
    import mesh_inputs
    record = json.loads((A / 'data/structures/jb_beaubien_homestead.json').read_text())
    recipe = mesh_inputs.structure_inputs_sha(record, record['phases'][0])
    assert recipe == plan['native_inputs_sha256']
    manifest = json.loads((A / 'assets/manifest.json').read_text())
    row = manifest['assets'][plan['asset']]
    assert row == plan['native_manifest_row']
    web = json.loads((A / 'assets/manifest.web.json').read_text())
    assert web['masters'][plan['asset']] == plan['master_sha256']
    if check_resources:
        for mount, reserve in RESERVES.items():
            assert shutil.disk_usage(mount).free >= FLOORS[mount] + reserve, mount + ' reserve unavailable'
    return recipe

def git_state():
    def git(*a):
        return subprocess.check_output(['git', '-C', str(REPO), *a], env=env)
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'index': sha(REPO / '.git/index'), 'config': sha(REPO / '.git/config'),
            'status': hashlib.sha256(git('status', '--porcelain=v1', '-uno')).hexdigest()}

validate()
command = ['node', 'tools/photo_match.mjs', plan['camera_relative'],
           '--glb', 'assets/gltf/' + plan['asset'],
           '--out', 'docs/RESEARCH/photo-match/jb_beaubien_homestead']
if not args.execute:
    print(json.dumps({'status': 'READ_ONLY_PLAN_PASS; FIXTURE/BROWSER/NATIVE_CAPTURE_UNRUN',
                      'native_command': command, 'native_cwd_NOT_CREATED': str(ROOT),
                      'guards': len(plan['guards']), 'workspace_reserve_B': RESERVES['/workspace'],
                      'TMP_reserve_B': RESERVES['/tmp'], 'camera_frame': plan['source_frame_proof'],
                      'owned_scratch_environment': {k: env[k] for k in ['TMPDIR', 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME']},
                      'current_resources': {m: {'free_B': shutil.disk_usage(m).free,
                                               'execute_required_B': FLOORS[m] + RESERVES[m],
                                               'execute_fits_now': shutil.disk_usage(m).free >= FLOORS[m] + RESERVES[m]}
                                            for m in FLOORS},
                      'expected_head': args.expected_head,
                      'requires': 'Root CPU/source lease AFTER final phone, --execute and explicit actual --expected-head; no guessed future SHA'}, indent=2))
    raise SystemExit(0)

assert os.environ.get('T2378_CANDIDATE_CPU_LEASE') == 'root-one-current-master-role-candidate'
assert args.expected_head and re.fullmatch(r'[0-9a-f]{40}', args.expected_head), 'Root must supply actual checked commit SHA'
validate(check_resources=True)
cpus = {int(c) for c in args.cpu.split(',')}
assert cpus and cpus <= allowed_cpus
assert not EXEC.exists(), 'Refusing to overwrite an execution or create a second trial'
before = git_state()
assert before['head'] == args.expected_head, 'Primary HEAD is not the actual checked parent supplied by root'
assert not (REPO / '.git/MERGE_HEAD').exists(), 'Integration merge is still active'
assert subprocess.run(['git', '-C', str(REPO), 'diff', '--quiet', 'HEAD'], env=env).returncode == 0, 'Checked parent has tracked uncommitted changes'
EXEC.mkdir(mode=0o700)
for scratch in ['tmp', 'cache', 'config']:
    (EXEC / scratch).mkdir(mode=0o700)
for row in plan['fixture_files']:
    target = ROOT / row['target']
    target.parent.mkdir(parents=True, exist_ok=True)
    if row['kind'] == 'native_copy':
        assert sha(row['source']) == row['sha256']
        shutil.copyfile(row['source'], target)
        assert sha(target) == row['sha256']
    elif row['kind'] == 'guarded_link':
        assert sha(row['source']) == row['sha256']
        target.symlink_to(row['source'])
    else:
        raise AssertionError(row['kind'])
camera = ROOT / plan['camera_relative']
camera.parent.mkdir(parents=True, exist_ok=True)
camera.write_text(json.dumps(plan['canonical_relative_camera'], indent=2) + '\n')
assert sha(camera) == plan['canonical_relative_camera_sha256']
assert pathlib.Path(camera.parent / plan['canonical_relative_camera']['photo']).resolve() == pathlib.Path(plan['original_photo']).resolve()
validate(check_resources=True)
reaper = EXEC / 'REAPER.json'
log = EXEC / 'native.log'
wrapped = ['python3', '/workspace/shared/run-with-reaping.py', str(reaper), '--',
           'nice', '-n', '19', 'taskset', '-c', args.cpu, *command]
minimum = {m: shutil.disk_usage(m).free for m in FLOORS}
started = time.monotonic(); stopped = None
with log.open('x') as stream:
    child = subprocess.Popen(wrapped, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    while child.poll() is None:
        for m in FLOORS:
            minimum[m] = min(minimum[m], shutil.disk_usage(m).free)
        reason = next((m + ' floor breached' for m in FLOORS if minimum[m] < FLOORS[m]), None)
        if time.monotonic() - started > 240:
            reason = reason or 'one-trial 240 second deadline exceeded'
        if reason and stopped is None:
            stopped = reason
            child.send_signal(signal.SIGTERM)  # shared subreaper forwards only to its owned command
        time.sleep(0.2)
    code = child.wait()
rp = json.loads(reaper.read_text())
result = {'status': 'NATIVE_COMPARISON_FAILED' if code or stopped else 'NATIVE_COMPARISON_COMPLETE_UNREVIEWED',
          'native_exit_code': code, 'stop_reason': stopped, 'seconds': time.monotonic() - started,
          'all_children_reaped': rp['all_children_reaped'], 'minimum_free_B': minimum,
          'source_frame_proof': plan['source_frame_proof'], 'primary_Git_unchanged': git_state() == before,
          'expected_checked_parent_HEAD': args.expected_head, 'actual_parent_HEAD': before['head'],
          'matches_claimed': False, 'geometry_changed': False, 'identity_patch_applied': False}
(EXEC / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
for row in plan['guards']:
    assert sha(row['source']) == row['sha256'], row['source']
assert git_state() == before
assert code == 0 and stopped is None and rp['command_exit'] == 0 and rp['all_children_reaped'], result
match = camera.with_suffix('.match.json'); rec = json.loads(match.read_text())
assert rec['verdict'] == 'unreviewed'
assert rec['camera_sha256'] == plan['canonical_relative_camera_sha256']
assert rec['glb_sha256'] == plan['master_sha256']
assert rec['photo_sha256'] == plan['photo_sha256']
side = ROOT / rec['side_by_side']; assert side.is_file()
render = re.search(r'\n\s+(/[^\n]+-render\.png)\n', log.read_text())
assert render and pathlib.Path(render.group(1)).is_relative_to(EXEC / 'tmp')
raw = pathlib.Path(render.group(1)); assert raw.is_file()
result['outputs'] = [{'path': str(x), 'bytes': x.stat().st_size, 'sha256': sha(x)}
                     for x in [match, side, raw, log, reaper]]
result['unchanged_primary_selected_sources_MASTER_WEB_and_closed_readiness'] = True
result['limits'] = 'ONE isolated current MASTER ROLE CANDIDATE only, against preserved actual NE40 baseline. Camera remains diagnostic. Root directly reviews accept/reject face roles; no fit loop, geometry/identity/grade decision, matches/app/terrain/WEB/Images acceptance or original-ticket closure.'
(EXEC / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
