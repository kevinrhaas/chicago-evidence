"""Exactly one canonical incoming ledger; only gzip OS byte9 FF->03 is classified."""
import gzip,hashlib
PATH='chicago/4d/data/research/research_spend_ledger.json.gz'
BLOB='441149eb92b7d44d75d641a3747c6e1fb6667362'
SHA256='07799e9fc7359bcedd4be6e0f5674f26686e0462fb7017d25b1d804aa8c281db'
NATIVE_SHA256='6aa7435e57c028602a30b870ebe086be5c49ffa3bbce76012ce6475d0b350217'
SIZE=610454
PAYLOAD_SIZE=12958902
PAYLOAD_SHA256='a4c16a8b62ef12bf44272f730f5c5ab41ec90fe177c772bb6f3415a879bf5775'
def classify(path,original,native):
 assert path==PATH,'No other gzip path may be normalized'
 sha=lambda b:hashlib.sha256(b).hexdigest()
 assert len(original)==len(native)==SIZE and sha(original)==SHA256
 assert hashlib.sha1(b'blob '+str(len(original)).encode()+b'\0'+original).hexdigest()==BLOB
 assert original[:10]==bytes.fromhex('1f8b08000000000002ff') and native[:10]==bytes.fromhex('1f8b0800000000000203'),'Exact gzip magic/method/flags/mtime/XFL/OS bytes required'
 assert original[:9]==native[:9] and original[10:]==native[10:],'No byte except gzip OS offset9 may differ'
 assert original[9]==255 and native[9]==3 and sha(native)==NATIVE_SHA256
 left,right=gzip.decompress(original),gzip.decompress(native)
 assert left==right and len(left)==PAYLOAD_SIZE and sha(left)==PAYLOAD_SHA256
 return {'classification':'EXACT_FIXED_LEDGER_GZIP_OS_BYTE_ONLY_NO_PAYLOAD_CHANGE','all_bytes_equal_except_offset9_OS':True,'baseline_OS':255,'native_OS':3,'decompressed_bytes':len(left),'decompressed_sha256':sha(left)}
