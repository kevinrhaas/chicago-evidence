# V2 close/gate/checkpoint helper copies — prepared, not launched

Root owns the active native61V2 run. This new packet changes no frozen16-file helper, primary file, index, ref or native result. `full_gate/run.py` is byte-identical to the frozen gate. Read-only symlinks to the original `inherited_workbook.py` and API proof preserve its exact narrow guard and relative proof lookup; target bytes are bound in this manifest. The checkpoint changes only its gate receipt path to this V2 folder.

`full_gate/close_and_check.py` points to `/workspace/PR1456-final1af-native61-v2-root-20261030/`. Its only classifier addition concerns exact4D path `data/research/research_spend_ledger.json.gz`: baseline441149eb92b7d44d75d641a3747c6e1fb6667362, SHA07799e9fc7359bcedd4be6e0f5674f26686e0462fb7017d25b1d804aa8c281db,610454B. It preserves actual native raw bytes before proof. `ledger_os.py` requires exact baseline Gitblob/SHA/size/header, native headerFF→03 at OS offset9 only, every other byte identical, nativeSHA6aa7435e…, and equal12,958,902B decompressed payload/SHAa4c16a8b…. Only then can the canonical incoming bytes be restored/staged. Every other gzip path/change still stops. Workbook ZIP/C14N classifier is unchanged, baseline remains incoming3ce2…, and all postclassification/gate/checkpoint scope/index/source/config/model/authored/reaper guards remain intact.

Seven pure tests accepted the actual retainedV1 OS-only pair and rejected another gzip path, changedmtime, payload, CRC/footer, wrongOS and unchangedFF input. Four Python files parse. Original16 hashes remain exact. The helpers' mutating main programs were never invoked here.

Read-only DRIFT_ROOTS crosscheck exactly matches root's scratch price:11646files,1,513,614,404B raw,1,538,777,088B allocated upper bound, no directory symlinks. With128MiB reserve the requirement is1,672,994,816B. `tools/synthesize_resident_research.py` really copies only data+docs/RESEARCH into native TemporaryDirectory. Root's before-run1,800,073,216B free covers that with127,078,400B margin. Temporary occupancy is not the caller start/end1.8GB threshold; no lower floor or skipped stage is proposed. No extra scratch/heavy consumer was started by this preparation.

After actual native61V2 PASS, root's reviewed close/gate command is:

```text
source /workspace/shared/resume-chicago-env.sh
TMPDIR=/tmp PYTHONDONTWRITEBYTECODE=1 python /workspace/PR1456-next1af-v2-helper-prep-first-fort-20261030/full_gate/close_and_check.py
```

It classifies actual closed native output, freezes the real tree and runs the unchanged full source gate, with existing0,1,3,4 reaper and caller floor checks. Fresh gate files are produced in this packet's `full_gate/`. No native owner is skipped or rerun by this helper.

After exact full source-gate PASS, the ordinary source-only checkpoint command is:

```text
source /workspace/shared/resume-chicago-env.sh
TMPDIR=/tmp PYTHONDONTWRITEBYTECODE=1 python /workspace/PR1456-next1af-v2-helper-prep-first-fort-20261030/checkpoint/run.py
```

Fresh same-head final phone is still owed. Existing reviewed dynamic runtime controller needs this V2 checkpoint/gate receipt path as its parameter. Existing reviewed transport helper remains unchanged and accepts the actual V2 `full_gate/RESULT.json` via its `--gate-proof` argument; it still allows only the fixed inherited workbook outside4D+five existing library paths, genuine native parents/SHAs,192path bound, nonforce CAS and immutable readback. This packet performs no publication or merge.
