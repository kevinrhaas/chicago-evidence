from pathlib import Path
import hashlib,json,ast,difflib
O=Path(__file__).resolve().parent;proof=O/'INHERITED-WORKBOOK-API-PROOF.json';PH=hashlib.sha256(proof.read_bytes()).hexdigest();HEAD='4b22bc35474809cd03d55368ec5d61b0be842059';INCOMING='1af81836ce5d456c89874aba1328408d06888344';FIXED='chicago/reference/resident-research/final/audit/resident_audit_master.xlsx'
shared='''"""One exact inherited1af workbook exception; never a directory whitelist."""
from pathlib import Path
import hashlib,json
PATH='chicago/reference/resident-research/final/audit/resident_audit_master.xlsx'
MODE='100644'
BLOB='3ce2acfccf196a4ed74e745567f227073cf234b0'
SHA256='630e9344725fb8bf57edbc6f34225e6b6f2a35734bfa917a31cea16c74aa8eef'
INCOMING='1af81836ce5d456c89874aba1328408d06888344'
PROOF_SHA256='__PROOF_SHA__'
LIBRARY={'chicago/prairie_1904_v1/data/images.json','chicago/prairie_1904_v1/research/images/STORE.json','chicago/prairie_1904_v1/research/images/stream-early-chicago-lighthouse-reference.json','chicago/prairie_1904_v1/research/images/stream-early-chicago-miller-hogan-references.json','chicago/prairie_1904_v1/research/images/stream-st-mary-reference.json'}
def proof():
 p=Path(__file__).parent/'INHERITED-WORKBOOK-API-PROOF.json';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==PROOF_SHA256
 d=json.loads(raw);assert d['status']=='READONLY_API_1AF_INHERITS_EXACT_CLASSIFIED1449_WORKBOOK'and d['incoming']==INCOMING and d['path']==PATH and d['mode']==MODE and d['blob']==BLOB and d['sha256']==SHA256
 assert d['1449_ancestor_proved']['status']=='ahead'and d['strict_prior_classification']['changed_cells']==0 and d['strict_prior_classification']['all_canonical_members_except_core_modified_equal']
 prior=Path(d['strict_prior_classification']['path']);assert hashlib.sha256(prior.read_bytes()).hexdigest()==d['strict_prior_classification']['sha256'];return d
def allowed(path,digest=None):
 if path==PATH:return digest==SHA256
 return path.startswith('chicago/4d/')or path in LIBRARY
def verify(root,git,working=True,index=True):
 proof();p=git('ls-tree',INCOMING,'--',PATH).decode().strip();assert p==MODE+' blob '+BLOB+'\\t'+PATH
 if index:
  p=git('ls-files','--stage','--',PATH).decode().strip();assert p==MODE+' '+BLOB+' 0\\t'+PATH
 if working:assert hashlib.sha256((root/PATH).read_bytes()).hexdigest()==SHA256
 return {'path':PATH,'mode':MODE,'inherited_blob':BLOB,'sha256':SHA256,'incoming':INCOMING,'proof_sha256':PROOF_SHA256}
'''.replace('__PROOF_SHA__',PH);(O/'inherited_workbook.py').write_text(shared)
rows=[]
def emit(source,relative,edits):
 p=Path(source);old=p.read_text();s=old
 for before,after in edits:
  assert before in s,('replacement absent',relative,before[:80]);s=s.replace(before,after)
 dest=O/relative;dest.parent.mkdir(exist_ok=True);dest.write_text(s);ast.parse(s);diff=''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile=source,tofile=str(dest)));(O/(relative.replace('/','__')+'.diff')).write_text(diff);rows.append({'source':source,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'copy':str(dest),'copy_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'diff_file':relative.replace('/','__')+'.diff'})
imp="import sys\nsys.path.insert(0,str(Path(__file__).resolve().parent.parent))\nimport inherited_workbook as IW\n"
emit('/workspace/PR1456-final944-full-gate-gt-20261030/run.py','full_gate/run.py',[
 ('from pathlib import Path\n','from pathlib import Path\n'+imp),
 ("assert all((rel.startswith('chicago/4d/') or rel in library) and re.fullmatch('[0-9a-f]{64}', digest)","inherited = IW.verify(R, git)\nassert library == IW.LIBRARY\nassert all(IW.allowed(rel, digest) and re.fullmatch('[0-9a-f]{64}', digest)"),
 ("scope='Actual genuine native1456+currentdev merge plus root-reviewed3line existing compactNormals reuse. GT WIP is safely archived and excluded.',","scope='Actual genuine4b22+1af merge; exact inherited workbook path/mode/blob/SHA is separately verified. Existing four-building and railway guards retained.',\n               inherited_workbook=inherited,"),
 ("text = (O / 'check.log').read_text()","IW.verify(R, git)\ntext = (O / 'check.log').read_text()")])
emit('/workspace/PR1456-final944-full-gate-gt-20261030/close_and_check.py','full_gate/close_and_check.py',[
 ('from pathlib import Path\n','from pathlib import Path\n'+imp),
 ("N=Path('/workspace/PR1456-final944-native61-gt-20261030')","N=Path('/workspace/PR1456-final1af-native61-root-20261030')"),
 ("baselines=json.loads((N/'BEFORE44.json').read_bytes());changed=", "baselines=json.loads((N/'BEFORE44.json').read_bytes());IW.verify(R,g,working=False,index=False);assert baselines[IW.PATH]['oid']==IW.BLOB and baselines[IW.PATH]['sha256']==IW.SHA256;changed="),
 ("assert head=='22ed686fc15735d191c1392b90284dc4098a699a'and parent=='944fc1dcd27aee0fc051323d98fc5f3f24f0753e'",f"assert head=='{HEAD}'and parent=='{INCOMING}';IW.verify(R,g)"),
 ("and all(p.startswith('chicago/4d/')for p in paths)","and all(IW.allowed(p,sha((R/p).read_bytes()))for p in paths)"),
 ("ACTUAL_FINAL944_NATIVE_OWNERS_CLOSED_STAGED_BINDING","ACTUAL_FINAL1AF_NATIVE_OWNERS_CLOSED_STAGED_BINDING")])
emit('/workspace/PR1456-final944-checked-source-checkpoint-gt-20261030/run.py','checkpoint/run.py',[
 ('from pathlib import Path\n','from pathlib import Path\n'+imp),
 ("G=Path('/workspace/PR1456-final944-full-gate-gt-20261030')","G=Path('/workspace/PR1456-next1af-helper-prep-first-fort-20261030/full_gate')"),
 ("b['head']=='22ed686fc15735d191c1392b90284dc4098a699a'and b['merge_parent']=='944fc1dcd27aee0fc051323d98fc5f3f24f0753e'",f"b['head']=='{HEAD}'and b['merge_parent']=='{INCOMING}'"),
 ("q=subprocess.run(['git','-c'","IW.verify(R,g);assert all(IW.allowed(p,h)for p,h in b['all_staged_paths'].items())\nq=subprocess.run(['git','-c'"),
 ("Merge current dev and retain exact uniform railway grades","Merge current dev preserving uniform railway grades and inherited metadata"),
 ("ACTUAL_CHECKED_CURRENT944_SOURCE_ONLY_NATIVE_MERGE_CHECKPOINT","ACTUAL_CHECKED_CURRENT1AF_SOURCE_ONLY_NATIVE_MERGE_CHECKPOINT"),
 ("current944","current1af")])
emit('/workspace/four-case-code-rest-transport-v6-192path-bound-20261030/publish_native.py','transport/publish_native.py',[
 ('from pathlib import Path\n','from pathlib import Path\n'+imp),
 ("and all(p.startswith('chicago/4d/') or p in LIBRARY_OUTPUTS for p in checked_paths)","and all(IW.allowed(p,h)for p,h in checked_paths.items())"),
 ("assert all(re.fullmatch('[0-9a-f]{64}',h)","IW.verify(SOURCE,git);assert LIBRARY_OUTPUTS==IW.LIBRARY\n    assert all(re.fullmatch('[0-9a-f]{64}',h)"),
 ("assert changes and all(p.startswith('chicago/4d/')or p in LIBRARY_OUTPUTS for p in changes),'Code transport scope is only Chicago4D and the five owned native library outputs'","assert changes and all(IW.allowed(p,IW.SHA256 if p==IW.PATH and changes[p]==(IW.MODE,'blob',IW.BLOB)else None)for p in changes),'Code transport scope is Chicago4D, exact five library outputs, and one fixed inherited workbook'\n        if IW.PATH in changes:\n            assert c['parents']==[args.base,IW.INCOMING] and changes[IW.PATH]==(IW.MODE,'blob',IW.BLOB),'Workbook exception only for the genuine current1af merge with exact inherited blob'\n            assert IW.INCOMING in available and leaves(available[IW.INCOMING]['tree'])[IW.PATH]==(IW.MODE,'blob',IW.BLOB)")])
(O/'HELPER-DIFFS.json').write_text(json.dumps({'status':'PREPARED_COPIES_ONLY_NEVER_EXECUTED','helpers':rows,'shared_guard_sha256':hashlib.sha256((O/'inherited_workbook.py').read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps({'external_helpers':len(rows),'syntax':'PASS','primary_writes':False,'executed_helpers':False}))
