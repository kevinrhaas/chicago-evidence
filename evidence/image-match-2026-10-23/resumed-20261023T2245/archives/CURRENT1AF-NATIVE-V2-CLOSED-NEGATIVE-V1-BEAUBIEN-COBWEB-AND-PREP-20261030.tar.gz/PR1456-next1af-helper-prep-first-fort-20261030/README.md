# Current1af external helper copies — review before launch

Prepared only. No primary source/index/ref write, native owner, full gate, commit, publication or PR action was run by this agent. Root independently imported and merged1af and owns native frontyards/native61. Read AGENTS and all source helper bodies. Helpers are fresh external copies of the exact944/v6 scripts; unified reviewed differences are beside them.

Only new outside4D path permitted is `chicago/reference/resident-research/final/audit/resident_audit_master.xlsx`, mode100644, blob3ce2acfccf196a4ed74e745567f227073cf234b0, SHA256630e9344725fb8bf57edbc6f34225e6b6f2a35734bfa917a31cea16c74aa8eef. Existing five library paths remain exact and unchanged. `INHERITED-WORKBOOK-API-PROOF.json` proves immutable1af ancestry from1449 and the exact workbook tree entry/raw hash; it binds the existing strict canonical/timestamp-only classification. Workbook raw bytes were read in RAM only. The shared guard verifies fixed incoming tree, stage0 index and working bytes at gate/commit/transport.

Native exporter189 can rewrite XLSX container timestamps and stage its native output. Accordingly close/check first checks the immutable incoming tree plus BEFORE44's exact3ce baseline, then uses the unchanged strict ZIP/C14N equality classifier (only core.modified removed). It preserves raw native output before asserting equality; only proven serialization-only changes are restored/staged to the incoming3ce baseline. **Index/working exact guards are enforced after that classification and throughout gate/checkpoint/transport**. Semantic workbook changes or changed gzip outputs stop. Old4b22 workbook532ca0… is never substituted as this merge baseline.

Actual incoming manifest95fae70b… was read and compared with the merged working manifest:204steps, tail starts144 at compile_liberties, so the correct tail still contains61 actual commands. compile_source_use is152 (516resolves, including new incoming source-detail records), workbook export189. `NATIVE-COMMANDS.json` contains the exact actual command list. Root completed native frontyard owner19 preserving its union; these helpers propose no frontyard rerun or model rebuild.

After root's native61 closes and root reviews this diff, the next command is:

```text
source /workspace/shared/resume-chicago-env.sh
python /workspace/PR1456-next1af-helper-prep-first-fort-20261030/full_gate/close_and_check.py
```

That command intentionally performs the reviewed classification/native staging, freezes the real tree and launches its copied actual full gate on0,1,3,4 using the unchanged reaper/readers/Node fixture exception/config/source/path guards. It expects native receipts at `/workspace/PR1456-final1af-native61-root-20261030/`. It retains4b22 native HEAD +incoming1af MERGE_HEAD, current native railwaya9 and incoming railway3117, exact authored/model/frontyard guards, all44binary checks, no conflicts/untracked,256staged-path gate bound and proper PASS footer. It was **not executed** here.

After actual source-gate PASS and root approval, the ordinary source-only checkpoint command is:

```text
source /workspace/shared/resume-chicago-env.sh
python /workspace/PR1456-next1af-helper-prep-first-fort-20261030/checkpoint/run.py
```

The copied checkpoint still requires exact checked tree/HEAD/parents/config/path bytes and reaper, creates one genuine native merge commit, then asks native changelog-entry/IDs/fold/four-original-image gates. It claims no fresh phone, CI or dev-merge acceptance. Fresh exact-head phone remains owed.

Transport is the copied v6 helper at `transport/publish_native.py`, retaining the192checked-path/64MiB/finiteDAG/exactnativeSHA/tree/parent/remoteCAS/nonforce/readback/source-snapshot guards. Its extra workbook diff predicate requires the leaf be exactly100644/blob3ce… and the native commit parents exactly`[--base,1af81836ce5d456c89874aba1328408d06888344]`, with the second parent's tree independently carrying that leaf. It cannot delete, modify, chmod or introduce any other reference path. Root should first invoke it without `--publish`, using actual new commit/tree/path count and current remote-old4b22; then publish only after actual phone/CI policy permits. No guessed head/tree/count is supplied.

```text
python /workspace/PR1456-next1af-helper-prep-first-fort-20261030/transport/publish_native.py --base 4b22bc35474809cd03d55368ec5d61b0be842059 --head ACTUAL_CHECKED_NEW_HEAD --qualified-tree ACTUAL_CHECKED_TREE --gate-proof /workspace/PR1456-next1af-helper-prep-first-fort-20261030/full_gate/RESULT.json --expected-old 4b22bc35474809cd03d55368ec5d61b0be842059 --expected-new-commits 1 --expected-checked-paths ACTUAL_COUNT --output NEW_PLAN_DIRECTORY
```

All four copies parse. Eleven small guard checks prove exact workbook acceptance and wrong hash/path/mode/blob refusals while preserving prior4D/five-library scope. Those checks used fake tree/index responses; no primary Git write or helper main ran. `REVIEW.json` and `HELPER-DIFFS.json` bind the review. The existing strict timestamp-only classification and prior helpers remain untouched.
