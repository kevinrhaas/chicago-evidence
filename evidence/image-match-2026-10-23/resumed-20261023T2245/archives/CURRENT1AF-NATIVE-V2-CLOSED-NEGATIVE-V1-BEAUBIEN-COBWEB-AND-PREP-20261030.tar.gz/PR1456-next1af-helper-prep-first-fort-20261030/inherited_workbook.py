"""One exact inherited1af workbook exception; never a directory whitelist."""
from pathlib import Path
import hashlib,json
PATH='chicago/reference/resident-research/final/audit/resident_audit_master.xlsx'
MODE='100644'
BLOB='3ce2acfccf196a4ed74e745567f227073cf234b0'
SHA256='630e9344725fb8bf57edbc6f34225e6b6f2a35734bfa917a31cea16c74aa8eef'
INCOMING='1af81836ce5d456c89874aba1328408d06888344'
PROOF_SHA256='32845ca6369514959a31f38353d406649911288fd5edd5f11edc6de78b02ee08'
LIBRARY={'chicago/prairie_1904_v1/data/images.json','chicago/prairie_1904_v1/research/images/STORE.json','chicago/prairie_1904_v1/research/images/stream-early-chicago-lighthouse-reference.json','chicago/prairie_1904_v1/research/images/stream-early-chicago-miller-hogan-references.json','chicago/prairie_1904_v1/research/images/stream-st-mary-reference.json'}
def proof():
 p=Path(__file__).parent/'INHERITED-WORKBOOK-API-PROOF.json';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==PROOF_SHA256
 d=json.loads(raw);assert d['status']=='READONLY_API_1AF_INHERITS_EXACT_CLASSIFIED1449_WORKBOOK'and d['incoming']==INCOMING and d['path']==PATH and d['mode']==MODE and d['blob']==BLOB and d['sha256']==SHA256
 assert d['1449_ancestor_proved']['status']=='ahead'and d['strict_prior_classification']['changed_cells']==0 and d['strict_prior_classification']['all_canonical_members_except_core_modified_equal']
 prior=Path(d['strict_prior_classification']['path']);assert hashlib.sha256(prior.read_bytes()).hexdigest()==d['strict_prior_classification']['sha256'];return d
def allowed(path,digest=None):
 if path==PATH:return digest==SHA256
 return path.startswith('chicago/4d/')or path in LIBRARY
def verify(root,git,working=True,index=True):
 proof();p=git('ls-tree',INCOMING,'--',PATH).decode().strip();assert p==MODE+' blob '+BLOB+'\t'+PATH
 if index:
  p=git('ls-files','--stage','--',PATH).decode().strip();assert p==MODE+' '+BLOB+' 0\t'+PATH
 if working:assert hashlib.sha256((root/PATH).read_bytes()).hexdigest()==SHA256
 return {'path':PATH,'mode':MODE,'inherited_blob':BLOB,'sha256':SHA256,'incoming':INCOMING,'proof_sha256':PROOF_SHA256}
