"""Classify the closed native owner output, freeze the real merge tree, then gate.
No new permission pause when every root-approved predicate holds.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import inherited_workbook as IW
import datetime,hashlib,io,json,os,shutil,subprocess,zipfile
import xml.etree.ElementTree as ET
R=Path('/workspace/chicago');N=Path('/workspace/PR1456-final1af-native61-root-20261030');O=Path(__file__).parent;E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');g=lambda *a:subprocess.check_output(['git','-C',str(R),*a],env=E);sha=lambda b:hashlib.sha256(b).hexdigest();result=json.loads((N/'RESULT.json').read_bytes());assert result['exit']==0 and all(result['guards'].values())and result['last_native_lap_moved_nothing']
baselines=json.loads((N/'BEFORE44.json').read_bytes());IW.verify(R,g,working=False,index=False);assert baselines[IW.PATH]['oid']==IW.BLOB and baselines[IW.PATH]['sha256']==IW.SHA256;changed=[p for p,r in baselines.items()if sha((R/p).read_bytes())!=r['sha256']]
def workbook(b):
 with zipfile.ZipFile(io.BytesIO(b))as archive:
  names=archive.namelist();assert len(names)==len(set(names));out={}
  for name in names:
   value=archive.read(name)
   if name.endswith(('.xml','.rels')):
    root=ET.fromstring(value)
    if name=='docProps/core.xml':
     for child in list(root):
      if child.tag=='{http://purl.org/dc/terms/}modified':root.remove(child)
    value=ET.canonicalize(ET.tostring(root,encoding='unicode'),rewrite_prefixes=True)
   out[name]=value
  return out
rows=[]
for rel in changed:
 assert rel.endswith('.xlsx'),'Unexpected binary change needs semantic review: '+rel
 original=g('cat-file','blob',baselines[rel]['oid']);native=(R/rel).read_bytes();assert sha(original)==baselines[rel]['sha256'];left,right=workbook(original),workbook(native);raw=N/('RAW-NATIVE-'+Path(rel).name);assert not raw.exists();assert shutil.disk_usage('/workspace').free>=536870912+len(native)+1048576;raw.write_bytes(native);assert left==right,('Genuine workbook semantic change',rel,[k for k in set(left)|set(right)if left.get(k)!=right.get(k)]);(R/rel).write_bytes(original);g('add','--',rel);rows.append({'path':rel,'baseline_oid':baselines[rel]['oid'],'baseline_sha256':sha(original),'native_sha256':sha(native),'all_canonical_members_except_core_modified_equal':len(left),'raw_native_preserved':str(raw),'serialization_only_baseline_restored':True})
(N/'BINARY-SEMANTIC-CLASSIFICATION.json').write_text(json.dumps({'status':'ALL44_CANONICAL_BINARY_BYTES_EXACT_AFTER_PROVEN_SERIALIZATION_ONLY_CLASSIFICATION','changed_native_records':rows},indent=2)+'\n');assert all(sha((R/p).read_bytes())==r['sha256']for p,r in baselines.items());models=json.loads((N/'BEFORE-MODELS.json').read_bytes());authored=json.loads((N/'BEFORE-AUTHORED.json').read_bytes());assert all(sha((R/p).read_bytes())==v for p,v in models.items())and all(sha((R/p).read_bytes())==v for p,v in authored.items());assert not g('diff','--name-only')and not g('ls-files','-u')and not g('ls-files','--others','--exclude-standard');head=g('rev-parse','HEAD').decode().strip();parent=g('rev-parse','MERGE_HEAD').decode().strip();assert head=='4b22bc35474809cd03d55368ec5d61b0be842059'and parent=='1af81836ce5d456c89874aba1328408d06888344';IW.verify(R,g);paths=g('diff','--cached','--name-only').decode().splitlines();assert 1<=len(paths)<=256 and all(IW.allowed(p,sha((R/p).read_bytes()))for p in paths);tree=g('write-tree').decode().strip();binding={'status':'ACTUAL_FINAL1AF_NATIVE_OWNERS_CLOSED_STAGED_BINDING','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'merge_parent':parent,'tree':tree,'path_count':len(paths),'all_staged_paths':{p:sha((R/p).read_bytes())for p in paths},'native61_last_lap_unchanged':True,'all_models_exact':len(models),'all_authored_and_retained_frontyard_exact':True,'all44_canonical_binary_bytes_exact':True,'railway_exact_retained_sha256':sha((R/'chicago/4d/renderers/web/js/railway.js').read_bytes()),'required_new_test_present':'tools/test_k01_rear_veranda.py'in(R/'chicago/4d/tools/check.sh').read_text(),'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free};assert binding['required_new_test_present'];(O/'ACTUAL-STAGED-BINDINGS.json').write_text(json.dumps(binding,indent=2)+'\n');(N/'CLOSED-FINAL.json').write_text(json.dumps(binding,indent=2)+'\n');print(json.dumps({k:v for k,v in binding.items()if k!='all_staged_paths'},indent=2),flush=True)
subprocess.run(['python3',str(O/'run.py'),'--expect-head',head,'--expect-tree',tree,'--expect-merge-parent',parent,'--reviewed-staged-bindings',str(O/'ACTUAL-STAGED-BINDINGS.json')],env=E,check=True)
