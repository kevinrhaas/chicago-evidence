Give the Miller House its pictured low log wing beside the tall range, add Hogan’s horizontal gable courses and chimney cap, raise St Mary’s front sash, and add the credited Castelnau harbour view to the lighthouse’s Images card. Sources retain disputed dates and unresolved picture conflicts; comparison cameras remain diagnostic.

Two necessary integration fixes accompany these four parcels: the PR-lap controller preserves freshly rebuilt derived files, and generated railway buffers use the existing compact-normal representation. Foreign building updates are preserved as integration inputs.

The current checked source checkpoint is [`22ed686f`](https://github.com/kevinrhaas/chicago/commit/22ed686fc15735d191c1392b90284dc4098a699a), tree `df5a6513833bdcf75889cac821bbcb5359ee7a0d`, with genuine parents `64d5710e` and dev `830722b9`.

- **1,105 source checks passed in 788.045 s**, with all seven guards, configuration and reapers exact. The committed four PR questions and four image gates passed.
- Normal fast-forward publication preserved the native commit, tree and parents; all **134 changed paths** were independently read back from immutable GitHub paths.
- The **final same-head Light-mobile measurement failed: 400.148044 MiB / 400 MiB**, with no page errors and all children reaped. This is a source-only checkpoint; the earlier 399.956466 MiB candidate trial does not substitute for final acceptance.

The normal-buffer candidate passed 122 native checks and six reviewed paired views. Its raw visual runner retains inherited AIR/NORTH triangle-budget failures, with assertions unchanged. Scoped visual acceptance is not a whole performance-smoke pass.

Dated Full-detail desktop/mobile app evidence is reused with explicitly reviewed consumer qualifications: the 1835-inactive street-tree/rail changes, the active elm crop/lightness adjustment, and the raycast near-plane fallback/oracle correction. This does not claim a fresh current desktop/mobile matrix or frame-rate measurement.

Newer dev `944fc1dc` is being integrated and the phone allocation failure is being repaired. This PR currently conflicts with that newer base, so its required GitHub gate is absent. Neither an earlier gate nor a candidate phone pass is final acceptance. The four tickets remain in official review until the qualified PR actually merges to `dev` and the official ticket workflow settles them. No main/production promotion is included.

[Checkpoint 720](https://github.com/kevinrhaas/chicago-evidence/blob/6ada3205ed4a1d589f14523172a669c402b01508/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md) preserves the exact source publication, failed final phone, bounded visual evidence and current-dev import, with links to the dated app cases and provenance.
