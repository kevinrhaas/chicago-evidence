Give the Miller House its pictured low log wing beside the tall range, add Hogan’s horizontal gable courses and chimney cap, raise St Mary’s front sash, and add the credited Castelnau harbour view to the lighthouse’s Images card. Source records retain disputed dates and unresolved picture limits.

Integration repairs preserve freshly rebuilt derived files and reduce railway buffer memory through the existing compact-normal format and exact uniform confidence values. Mixed confidence buffers retain their original representation. Native geometry, confidence grades, bounds, materials and picking behavior are checked against their controls.

The current published head is [`4b22bc35`](https://github.com/kevinrhaas/chicago/commit/4b22bc35474809cd03d55368ec5d61b0be842059), with genuine parents `22ed686f` and dev `944fc1dc`.

- **1,105 source checks passed in 791.450 s**; all source/configuration guards and reapers passed. The committed PR questions and four original image gates passed.
- The final same-head complete mobile memory gate passed at **398.584 MiB / 400 MiB**, with no page errors and all children reaped.
- The native commit, tree, parents and all **28 changed paths** were independently verified through immutable GitHub readback.

Dated desktop/mobile app evidence is reused with explicit consumer qualifications: inactive 1835 street-tree and railway paths, the active elm crop/atlas adjustment, and the raycast near-plane fallback/oracle correction. This does not claim a fresh complete desktop/mobile matrix or frame-rate measurement. Uniform-ground confidence visual comparison covers AIR and SOUTH in nine modes with zero candidate/control pixel differences; NORTH was not run. Raw visual timeouts and inherited triangle/draw-budget failures remain disclosed in the evidence.

**Not merge-ready yet:** newer dev `1af81836` is being integrated concurrently. Its composed tree still needs its own complete source gate, final same-head phone check and GitHub’s required check. The four tickets remain in review until the qualified PR merges to `dev` and the official workflow settles them. No main/production promotion is included.

[Checkpoint 721](https://github.com/kevinrhaas/chicago-evidence/blob/c597c45eaac5132c525c2d541911ee58f4675387/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md) preserves the current checked publication, phone pass, source provenance, qualified comparisons and earlier negative receipts.
