# Agency-House is Wolcott's/Cobweb; the complete pictured outline is unresolved

The nominal subject identification is stronger than the Oct29 disposition recorded. **The keyed panorama is usable as contextual evidence of the Indian Agency/Cobweb establishment. It is not a secure full-compound form reference from which to remove the text-attested wings or tails.** This finite comparison produces no new camera, render, geometry, match verdict, grade or ticket change.

I directly reviewed the whole keyed original, its original Wentworth1881 reproduction and annotation on printedp86, Hubbard's continuation on printedp87, both actual Oct29 native comparison images, and the held dependent unkeyed composition. The two diagnostic renders remain visibly unlike the small isolated house under their arbitrary poses; neither supplies an identity or metric-form solution.

## The additional direct identification evidence

John Wentworth, *Fort Dearborn*, Fergus Historical Series No.16 (1881), printedp86, immediately under the SAME keyed cut, states:

> The Agency-House—Dr. Wolcott's—was at the S.-W. cor. of North-Water and North-State—formerly Wolcott—Streets.

This is a direct agency/resident/site crosswalk. It is no longer accurate to characterize the evidence as only an unleadered label with no source relating it to Cobweb Castle. Wau-Bun explicitly names the north-bank Agency House “Cobweb Castle” and places it at the southwest corner of Wolcott and North Water. The existing canonical Cobweb record is that building, distinct from the first, south-bank agency house of1803–4 and the1812 Burns house previously near the later agency site.

Hubbard's letter of20July1881 on printedp87 says:

> The Agency house was at the corner of North-Water and North-State Streets.

That is another attributed statement in the SAME1881 publication, not a second independent publication/survey or independent verification of the engraving. His surrounding criticism says the cut is unlike the fort and surroundings as he recalled them, corrects terrain/river/fort geometry, and treats the viewpoint as apparently northeast. None of this proves every building outline accurate.

The small isolated north-bank house left of the poplars remains the **preferred inferred visual subject** for the Agency-House key: the key is below that region, while the farther-right Kinzie group is separately named, and the published corner crosswalk agrees with the intended north-bank agency site. There is still no leader defining which visible or concealed adjoining masses belong to that house. We have not converted key spacing into a survey coordinate or component boundary.

## Bounded1856 edition comparison

Internet Archive item `waubunearlydayin00kinz_0` has metadata date1856 and Derby & Jackson/H.W.Derby publication. Its bounded777,819B OCR was read in RAM; exact relevant excerpts and full response SHA are saved, not a full-book copy. It repeats Agency House=Cobweb Castle at the same corner and the compound description. No searched key/illustration text resolves attachment visibility; OCR absence does not prove a plate/key absent.

Two actual page images were retained and visually checked against their PRINTED numerals. Endpoint n196 is printed185; n197 is printed186. Printed185 names the Agency House/Cobweb corner, hewed/squared logs, centre, two wings and two tails; printed186 continues the rear-addition explanation, front symmetry and odd-shaped roof, then distinguishes the collection of employees' log buildings around the Agency House. The initially requested n198 proved to be printed187; its unneeded owned raw payload was removed before closure, with URL/hash/printed-number correction retained in the fetch receipt. No187 page is cited as185/186. These page numbers belong to this1856 edition, not the local EPUB's later footnotes or1901 printing.

The first1856 text and the1881 key therefore agree on SUBJECT/site. They do not prove that the tiny one-main-gable outline depicts every addition, an earlier phase before additions, a simplified artistic summary, or a particular component behind another. The text explicitly describes the1831 compound with centre, two wings, two rear tails, front symmetry and odd-shaped roof. A monochrome contextual thumbnail does not establish absence of unshown fabric.

## Ruling and exact remaining gap

Retain the1831 centre/wings/tails composition and the existing declared reconstructed five-room realization. Its exact13×9m envelope, roof directions/intersections/pitch, openings and two outer stack positions remain inferred/reconstructed. Neither the1881 annotation nor the edition check upgrades those numbers. The undated “afterward clapboarded part way up” account remains undated; it is not new proof of siding on1July1835. Survival of the1831 fabric through1835 remains a continuity assumption, with the current review/removal prose/flags preserved.

Do not carry forward the previously proposed `not_pictured` reason as an assertion that no published identification exists. This run supplies one. It also does not authorize a new `pictured`/`not_pictured` entry or whole-structure grade: any future ruling must assess whether this small contextual view provides reasonable whole-building appearance, and explicitly explain the compound-coverage limit instead of denying the named subject. No formal grade is changed here.

The unresolved gap is **component coverage**, not the nominal agency identity: no edition/key found in this finite comparison maps the tiny drawn outline to all five parts or establishes which part/phase the outline shows. Without that mapping, a single-gable replacement would discard the strongest1831 physical evidence, while rescaling the compound to this thumbnail would manufacture dimensions. No further arbitrary camera trial, geometry change, new picture ticket or split is proposed. Original T2374 remains OPEN. The existing finite native result can be documented accurately without claiming a source match.

The next useful source addition would be a dated plan/view or explicit text explaining the drawn agency outline/alteration and its component extent. This packet does not start an unbounded search for it. Source metadata/dossier can later be updated fieldwise with the1881 annotation and this limited ruling when the coordinator next has a source-write window; do not apply a wholesale old record or source replacement.

Printed Wau-Bun1857 credit, depicted1831, the1856 text edition and verified1881 reproduction remain separate. Existing public-domain rights rest on the nineteenth-century publication/inventory; this review buys no modern surrogate or license and makes no broad owner-use upgrade. Raw pages/held whole images and every cited existing receipt are SHA-bound in `BINDINGS.json`. Small text plus the two new original page images should join the next substantive recovery checkpoint, with no standalone archive.
