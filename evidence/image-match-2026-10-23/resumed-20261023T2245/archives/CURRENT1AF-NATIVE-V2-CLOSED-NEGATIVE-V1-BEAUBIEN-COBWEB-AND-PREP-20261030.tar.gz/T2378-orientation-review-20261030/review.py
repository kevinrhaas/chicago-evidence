"""ONE finite CPU camera-role calculation; not a native render or fit loop."""
import dataclasses, hashlib, json, math, os, pathlib, struct, sys

os.sched_setaffinity(0, {2})
sys.dont_write_bytecode = True
P = pathlib.Path(__file__).parent
A = pathlib.Path('/workspace/chicago/chicago/4d')
R = pathlib.Path('/workspace/T2378-current-readiness-20261030')
C = pathlib.Path('/workspace/T2378-actual-baseline-closure-root-20261030')
sha = lambda p: hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def emit(name, value):
    (P / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

rec_path = A / 'data/structures/jb_beaubien_homestead.json'
master_path = A / 'assets/gltf/jb_beaubien_homestead__log_1822.glb'
guards = [rec_path, master_path, A/'assets/web/jb_beaubien_homestead__log_1822.glb',
          A/'generators/archetypes/log_dwelling.py', A/'generators/archetypes/log_dwelling_params.py',
          R/'CLOSED-MANIFEST.json', C/'CLOSED-MANIFEST.json', C/'native-camera.json',
          C/'keyed-1831-diagnostic.match.json', C/'keyed-1831-diagnostic-side-by-side.jpg',
          C/'keyed-1831-diagnostic-render.png',
          pathlib.Path('/workspace/T2378-readiness-bd316-20261024/known-ticket-whole-panorama.jpg'),
          pathlib.Path('/workspace/T2378-readiness-bd316-20261024/dependent-unkeyed-whole-panorama.jpg'),
          pathlib.Path('/workspace/T2378-readiness-bd316-20261024/already-fetched-1881-printed-p86.jpg'),
          pathlib.Path('/workspace/T2378-readiness-bd316-20261024/already-fetched-1881-printed-p87.jpg')]
before = {str(p): sha(p) for p in guards}
assert sha(master_path) == '69cb6bfcc2e71aaaa48a424f11e9231294335b178df7b22611aae500162156b1'
rec = json.loads(rec_path.read_text()); ph = rec['phases'][0]
sys.path.insert(0, str(A/'generators')); import mesh_inputs
inputs = mesh_inputs.structure_inputs_sha(rec, ph)
assert inputs == json.loads((A/'assets/manifest.json').read_text())['assets'][master_path.name]['inputs_sha256']
params = mesh_inputs.resolve_params('log_dwelling', ph, rec)
old = json.loads((C/'native-camera.json').read_text())
seed = json.loads((R/'keyed-1831-diagnostic-seed.json').read_text())

# By-eye physical face-role assignment in the KEYED whole original, not a traced
# source rectangle or a pixel-precise camera solve. Endpoints uncertain +/-8px.
# Source long wall extends left of the visible right-hand gable.
long_px, gable_px = 64., 44.
theta = math.atan(params.width_m * gable_px / (params.depth_m * long_px))
distance = 300.
center = (params.width_m/2, params.depth_m/2)
candidate = {**seed,
    'eye': [center[0]-distance*math.sin(theta), center[1]+distance*math.cos(theta), 2.5],
    'yaw_deg': 180.-math.degrees(theta),
    'basis_right_up_forward': [[-math.cos(theta), -math.sin(theta), 0.], [0.,0.,1.],
                               [math.sin(theta), -math.cos(theta), 0.]],
    'solve': 'UNRENDERED ONE-CANDIDATE ROLE TEST, NOT A SOLVED OR ACCEPTED CAMERA. '
             'Current native NE40 baseline rendered the max-u gable on screen-left; '
             'both held Wau-Bun-derived compositions instead show a main-house gable on screen-right '
             'with the long eaves wall extending left. Hypothesis: source long eaves wall maps '
             'to current max-v front, and source right gable maps to current min-u end. '
             'Approximate keyed-image face widths64px long wall and44px gable, each +/-8px, '
             'combined with the CURRENT RECONSTRUCTED 2:1 footprint give angle53.9726deg west of '
             'model north (yaw126.0274deg); this is an analytic finite seed, not an evidence-grade '
             'dimension or calibrated source camera. The model rotation0 is unattested, so this '
             'MODEL-frame NW pose does not contradict or replace Hubbard\'s apparent historical NE '
             'panorama viewpoint: historical house bearing remains unresolved. '
             'Distance300m/eye2.5m remain reconstructed diagnostic choices. Lens/near/overcast '
             'settings are retained from the baseline except focal/principal horizontal scaling '
             'normalizes this candidate\'s full current-model envelope to the SAME rough x204..312 '
             'and y440 ground; source roof/eaves vertical controls are WITHHELD. '
             'No new story count, height, stack count, openings, paint, material or position follows. '
             'Source angle/roll/elevation remain uncalibrated; drawing edges are approximate. '
             'Near250/far500 retains actual current model vertices; flat native grade is not app terrain. '
             'Verified Wentworth1881 p86 key/annotation, printed Wau-Bun1857 credit and depicted1831 '
             'remain separate; identity is inferred and unchanged fabric to July1835 is unproved. '
             'Hubbard p87 criticism remains. Never transfer the separate Factor House description '
             'or publish this invented pose as From this spot.'}

blob = master_path.read_bytes(); n = struct.unpack_from('<I', blob,12)[0]
doc = json.loads(blob[20:20+n]); binary = blob[28+n:]
all_vertices=[]; roof=[]
for pr in doc['meshes'][0]['primitives']:
    a=doc['accessors'][pr['attributes']['POSITION']]; v=doc['bufferViews'][a['bufferView']]
    start=a.get('byteOffset',0)+v.get('byteOffset',0)
    pts=[]
    for i in range(a['count']):
        x,y,z=struct.unpack_from('<fff',binary,start+i*v.get('byteStride',12))
        pts.append((x,-z,y))
    all_vertices.extend(pts)
    if doc['materials'][pr['material']].get('name')=='roof_shingle': roof=sorted(set(pts))

def project(v, cam, unit=False):
    delta=[v[i]-cam['eye'][i] for i in range(3)]
    right,up,forward=cam['basis_right_up_forward']
    depth=sum(delta[i]*forward[i] for i in range(3)); assert 250 < depth < 500
    x=sum(delta[i]*right[i] for i in range(3))/depth
    y=-sum(delta[i]*up[i] for i in range(3))/depth
    return [x,y,depth] if unit else [cam['principal_px'][0]+cam['focal_px']*x,
                                    cam['principal_px'][1]+cam['focal_px']*y,depth]

uv=[project(v,candidate,True) for v in all_vertices]
candidate['focal_px']=108./(max(q[0] for q in uv)-min(q[0] for q in uv))
candidate['principal_px']=[258.-candidate['focal_px']*(max(q[0] for q in uv)+min(q[0] for q in uv))/2,
                           440.-candidate['focal_px']*max(q[1] for q in uv)]
emit('keyed-1831-one-role-candidate.json', candidate)
controls={'gable_min_u_wall_center': [0., params.depth_m/2,1.25],
          'gable_max_u_wall_center': [params.width_m,params.depth_m/2,1.25],
          'front_eaves_min_u': [0.,params.depth_m,2.5],
          'front_eaves_max_u': [params.width_m,params.depth_m,2.5],
          'roof_ridge_min_u': min((q for q in roof if q[2]>4),key=lambda q:q[0]),
          'roof_ridge_max_u': max((q for q in roof if q[2]>4),key=lambda q:q[0])}
projection={}
for name,cam in [('actual_NE40_baseline',old),('ONE_UNRENDERED_model_NW_role_candidate',candidate)]:
    q=[project(v,cam) for v in all_vertices]
    projection[name]={'control_px_depth':{k:project(v,cam) for k,v in controls.items()},
                      'all_vertex_pixel_bbox':[[min(v[i] for v in q) for i in range(2)],
                                               [max(v[i] for v in q) for i in range(2)]],
                      'depth_range_m':[min(v[2] for v in q),max(v[2] for v in q)]}
emit('ROLE-CONTROLS-NOT-A-RENDER.json',{'source_role_hypotheses':{
    'keyed_original':{'long_eaves_wall_x':[204,268],'right_gable_x':[268,312],
                       'manual_endpoint_uncertainty_px':8,'metric_lengths_attested':False},
    'dependent_original':'Analogous main house aroundx296..383; broad roof plane/longwall left and visible gable on right; not an independent witness or second solved camera.',
    'physically_assigned_model_faces':'longwall=max-v; right gable=min-u, conditional on current footprint convention',
    'unresolved':'App historical bearing, exact source corner, vertical camera pose/roll/roof/stacks/openings, current reconstructed footprint ratio.'},
    'finite_one_angle_deg':math.degrees(theta),
    'angle_bounds_from_manual_width_error_deg':[math.degrees(math.atan(2*36/72)),math.degrees(math.atan(2*52/56))],
    'controls_model_uvheight_m':controls,'actual_CPU_projection_ONLY':projection,
    'native_candidate_render_run':False,'geometry_defect_proven':False,
    'meaning':'The one candidate puts min-u gable right and longwall left. Envelope height remains far below rough source at this uncalibrated low camera. That is still a proportion/camera question, not a source-attested height or two-storey prescription.'})
emit('BINDINGS.json',{'guarded_paths':before,'guarded_paths_exact_after':before=={str(p):sha(p) for p in guards},
    'native_inputs_sha256':inputs,'candidate_sha256':sha(P/'keyed-1831-one-role-candidate.json'),
    'source_model_unchanged':True,'prior_closed_packets_unchanged':True,
    'primary_Git_ticket_site_writes':False,'native_candidate_render_run':False,
    'not_a_reading':'Finite rereview of held originals and actual current model; no new research-spend reading or remote fetch.'})
assert before=={str(p):sha(p) for p in guards}
print('PASS ONE conditional model-frame camera candidate; CPU controls only; no native render or source/model writes')
