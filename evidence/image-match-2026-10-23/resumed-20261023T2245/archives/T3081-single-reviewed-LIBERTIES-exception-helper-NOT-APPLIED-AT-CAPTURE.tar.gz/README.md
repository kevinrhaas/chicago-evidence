# One bounded T3081 LIBERTIES graft exception

This separate staging wrapper leaves the frozen general graft helper unchanged.
It supersedes only that helper's old-raw-prefix precondition for LIBERTIES, and
only for the exact incoming document reviewed by root. All other JSON, document,
code, native writer, preimage and target-context guards remain in force.

The only accepted incoming LIBERTIES SHA256 is:

`d872bfe51b324e72bd47b8682ee5363d943edbce119fb3849a7fef4ed5a33079`

It must equal, byte for byte:

1. The **entire** raw LIBERTIES document at parent
   `a2192528415d04f3b83424447a0b08a766d73825`, 2,943,034 bytes, SHA
   `b61665c79dd760c2531797c907d214903d0341bf865e3a9d084870a050c3c866`;
2. Followed by only the 2,849-byte Glessner appendix from dev
   `e5ed3ff6e5a62f70ae8a1c3c0c88c29e977cf02a`, SHA
   `f2afc417785d5d31c8b2b0cafa42b575d9da1c59f0fe36b759318a8da211a61a`.

The helper reads the pinned Git blobs and proves this formula on every run. It
accepts no other SHA, even when one is supplied with the reviewed-SHA option.
The newer actual parent `96ca50cbc8150f93576cbbd699b4359d73b6de01`
already has precisely these incoming bytes. A read-only stage onto that explicit
commit passes all 18 authored files with zero conflicts.

The parent audit is verified from
`/tmp/frame1239-resumed-readonly-20261023/closed-review/MANIFEST.json`, SHA
`b7f17d99f1fcaad9298a0c28f289818b13e7c7dc54512edf1394652437fb6f7c`.
Every manifest input is checked; the receipt separately binds `review.json`,
`raw-line-preservation-review.json` and `Hogan-liberty-block-review.json`. That
audit documents the legitimate population-scope updates and relocated Hogan
block. This exception does not approve new history changes, source loss or rights
changes.

## Stage the actual final target without writing it

After root resolves its parent96/current-dev merge and reviews the actual incoming
liberty diff against the frozen audit:

```sh
python3 /tmp/log82-reviewed-liberties-graft-20261023T2350/graft_reviewed_liberties.py --repo /tmp/chicago-log-integration --target-worktree --reviewed-liberties-sha256 d872bfe51b324e72bd47b8682ee5363d943edbce119fb3849a7fef4ed5a33079 --out /tmp/t3081-graft-actual-merged
```

For an already assembled clean target commit, replace `--target-worktree` with
`--target-ref EXACT_COMMIT`. Worktree mode binds HEAD, the complete staged-index
fingerprint, MERGE_HEAD and all 18 touched working-file preimages. Staging performs
no fetch, checkout, source write, index write, commit or population derivation.
Output must be a fresh directory outside the target worktree.

The report and `reviewed-liberties-receipt.json` bind that actual target context,
incoming SHA, entire-parent prefix, Glessner append, pinned root packet and frozen
helper/audit hashes. Copies of the exact incoming raw document and selected append
are included beside the overlay. The result must retain every incoming byte as
its exact prefix and append only the 12 selected liberties. Duplicate ids and
same-heading/different-fragment refusals run against the **entire** incoming
document. The other three document appends retain the original raw-prefix rule.

## Root's later explicit application

Review the actual staged overlay, graft patch and bound receipt. Apply only that
actual stage with the unchanged general helper:

```sh
python3 /tmp/log82-graft-prep-20261023T2340/graft_t3081.py --repo /tmp/chicago-log-integration --apply-staged /tmp/t3081-graft-actual-merged
```

Its original target HEAD/index/MERGE_HEAD and all-preimages-before-writing guards
still apply. Unrelated files and generated assets remain outside the overlay.
The wrapper has no application option and cannot write the target by itself.
Never copy `anticipated-liberty-result.md` wholesale into a different/newer
incoming document: that file is only a raw proof of the pinned formula before the
actual merge context exists. If incoming liberty history advances, this helper
must refuse; prepare a separately reviewed bounded exception rather than editing
its SHA option to bypass the refusal.

The root checkpoint packet remains pinned to manifest
`b9ad8b12f72c054d056ef3be19d5d273a9281cc1bbb585c322f2b2f2b60f818b`.
Recovered locations can be passed with `--packet`, `--original-helper` and
`--parent-audit-manifest`; their expected hashes do not change. Root's later
STATUS default-off/five-opt-in clarification stays an explicit post-graft edit.

## Evidence

`verification.json`: 23 LIGHT checks pass, using actual pinned Git blobs and the
root-resolved preview. Altered/missing/extra incoming bytes and all 12 reused
liberty ids refuse. The old helper hash remains exact. `stage-parent96/report.json`
is a read-only concrete 18-file success on actual parent96; its bound receipt SHA
is `3ce0d1958eaf826f339fd64ab6877b05fce0d1bcbbc924cdcd3118ad9c268dfc`.

No canonical application, check.sh/preflight, Blender/browser, image verdict or
merge approval is claimed. The final merged context, official asset freshness,
ordered consumers, site clearances and full gates remain root's responsibility.
