#!/usr/bin/env python3
"""LIGHT actual-blob preservation and negative controls; no canonical writes."""
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
root = Path(__file__).parent
spec = importlib.util.spec_from_file_location('bounded', root / 'graft_reviewed_liberties.py')
w = importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)
g = w.load_original(w.ORIGINAL)
repo = Path('/tmp/chicago-log-integration')
before = g.blob(repo, g.BASE, w.LIBRARY)
after = (Path(g.PACKET) / w.LIBRARY).read_bytes()
fragment = after[len(before):]
incoming = Path('/tmp/log82-parent-liberty-resolved-preview.md').read_bytes()
checks = []


def ok(name, value):
    assert value, name
    checks.append(name)


def refused(name, fn):
    try:
        fn()
    except (ValueError, g.Conflict):
        checks.append(name)
    else:
        raise AssertionError(name + ' did not refuse')


audit = w.validate_audit(w.AUDIT_PATH)
ok('frozen original helper and parent audit inputs verified', len(audit) == 3)
binding = w.validate_incoming(g, repo, before, incoming)
ok('exact full a219 prefix plus exact e5 Glessner append', binding['incoming_exact_parent_plus_glessner_append'])
parent = g.blob(repo, w.PARENT_COMMIT, w.LIBRARY)
refused('parent alone is not the merged exception', lambda: w.validate_incoming(g, repo, before, parent))
refused('single incoming byte alteration refuses', lambda: w.validate_incoming(g, repo, before, b'X' + incoming[1:]))
refused('different extra append refuses', lambda: w.validate_incoming(g, repo, before, incoming + b'\nOther history\n'))
refused('missing Glessner bytes refuses', lambda: w.validate_incoming(g, repo, before, incoming[:-1]))
result = g.append_doc(b'', fragment, incoming, 'docs/LIBERTIES.md')
ok('entire actual reviewed incoming raw document preserved exact', result[:len(incoming)] == incoming)
ok('only exact 12-entry fragment appended', result[len(incoming):] == fragment)
ok('native id/heading guard remains idempotent', g.append_doc(b'', fragment, result, 'docs/LIBERTIES.md') == result)
first_id = b'L-school-picture-form-2372'
import re
ids = re.findall(rb'(?m)^#{2,4} (L-[A-Za-z0-9_-]+)\b', fragment)
ok('exactly twelve unique native liberty ids', len(ids) == len(set(ids)) == 12)
for identity in ids:
    refused('existing differing liberty id refuses: ' + identity.decode(), lambda identity=identity:
            g.append_doc(b'', fragment, incoming + b'\n### ' + identity + b': changed title\nOther text\n', 'docs/LIBERTIES.md'))
refused('other documents retain raw base-prefix guard', lambda:
        g.append_doc(b'original\n', b'original\n\nNew section\n', b'rewritten\n', 'docs/STATUS.md'))
(root / 'anticipated-liberty-result.md').write_bytes(result)
receipt = {'status': 'ANTICIPATED_INPUT_PROOF_ONLY_NOT_APPLYABLE',
           'target_context': 'Root actual HEAD/index/MERGE_HEAD not assembled; helper must bind them later.',
           'source_base_commit': g.BASE, 'source_base_raw_sha256': w.sha(before),
           'parent_audit_manifest_sha256': w.AUDIT_SHA, 'parent_audit_inputs': audit,
           'incoming_history_binding': binding,
           'reviewed_incoming_sha256': w.sha(incoming), 'reviewed_incoming_bytes': len(incoming),
           'selected_append_bytes': len(fragment), 'selected_append_sha256': w.sha(fragment),
           'selected_liberty_ids': [x.decode() for x in ids],
           'result_bytes': len(result), 'result_sha256': w.sha(result),
           'entire_incoming_raw_prefix_exact': True, 'only_exact_selected_append_added': True,
           'root_review_requirement': 'Check actual final merged incoming diff against b7f, then run bounded stage on actual target; apply only that stage after reviewing its bound receipt.'}
(root / 'anticipated-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
summary = {'status': 'PASS', 'checks': len(checks), 'passed': checks,
           'limits': 'LIGHT actual Git blobs and own /tmp result only. No canonical writes, fetch, checkout, target stage/application, browser, Blender or full gates.'}
(root / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'checks': len(checks), 'result_sha256': w.sha(result)}))
