"""Prepare three raw-preserving authored files only; execute no native stage/test."""
from pathlib import Path
import json,hashlib,difflib,datetime,sys,importlib.util
sys.dont_write_bytecode=True
root=Path('/tmp/chicago-log-integration/chicago/4d');out=Path(__file__).resolve().parent
paths=['tools/derived_manifest.json','tools/writer_inventory.json','tools/rederive.mjs']
before={p:(root/p).read_bytes() for p in paths};after=dict(before)
helper=Path('/tmp/log82-graft-prep-20261023T2340/graft_t3081.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='84d80a4e5618fb287940e70e49af744d57064d95abeaa91d02cb9d65606ab5ee'
spec=importlib.util.spec_from_file_location('frozen_graft_spans',helper)
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
p=paths[0];text=before[p].decode();spans=g.list_spans(text,'steps')
indices=[i for i,(s,_,_) in enumerate(spans) if s['command']==['python3','tools/generate_yard_outbuildings.py']]
assert len(indices)==1;i=indices[0]
assert spans[i+1][0]['command']==['python3','tools/generate_kept_ground.py']
assert not any(s['command']==['python3','tools/generate_woodpiles.py'] for s,_,_ in spans)
step={'why':"T-3081: woodpiles follow the last physical obstacle writer, generate_yard_outbuildings.py, and precede kept-ground and closing audits. Ground reads current compiled footprints and exact-phase doorway zones, dooryard pickets and plantings, frontage walks, trade goods, wagons and outbuildings. It skips its own output. The goods world and trade-yard/outbuilding writers do not read woodpiles, so this adds no physical feedback cycle. Existing repeated scene-tail settlement remains required for the wider scene/record cycle. The earlier clean-tree reproduction measurement in writer_inventory.json remains historical; final current derivation is checked normally.",
      'command':['python3','tools/generate_woodpiles.py'],
      'resolves':['chicago/4d/data/yard/town_woodpiles.json']}
_,start,end=spans[i];indent=text[text.rfind('\n',0,start)+1:start];assert indent.isspace()
fragment='\n'.join(indent+x for x in json.dumps(step,indent=2).splitlines())
insertion=',\n'+fragment;result=text[:end]+insertion+text[end:];after[p]=result.encode()
expected=json.loads(before[p]);expected['steps'].insert(i+1,step)
assert json.loads(after[p])==expected and len(expected['steps'])==202
assert (result[:end]+result[end+len(insertion):]).encode()==before[p]
new_steps=expected['steps']
p=paths[1];text=before[p].decode();anchor='    "generate_woodpiles.py": '
pos=text.index(anchor)+len(anchor);old,end=json.JSONDecoder().raw_decode(text,pos)
assert old['placement']=='pending';new=dict(old);new['placement']='manifest'
new['placed']="T-3081: after generate_yard_outbuildings and before generate_kept_ground, after every current physical obstacle input. The writer uses compiled footprints, exact-phase doorway zones, pickets/plantings, frontage walks, trade goods, wagons and outbuildings, and excludes its own output. The pre-existing repeated scene tail settles wider upstream record changes; no woodpile-to-goods/outbuilding feedback read was found. The measured/finding fields retain the historical clean-tree result."
lines=json.dumps(new,indent=2).splitlines();value='\n'.join([lines[0]]+['    '+x for x in lines[1:]])
after[p]=(text[:pos]+value+text[end:]).encode()
expected=json.loads(before[p]);expected['tools']['generate_woodpiles.py']=new
assert json.loads(after[p])==expected
p=paths[2];anchor=b"  check_('a name no step runs is refused, not silently skipped', tailFrom('tools/no_such.py', real) === -1);"
assert before[p].count(anchor)==1
extra=b"  const woodpile = real.steps.findIndex((st) => (st.command ?? []).includes('tools/generate_woodpiles.py'));\n  check_('woodpiles rebuild after outbuildings and before kept ground (T-3081)',\n    woodpile >= 0\n    && (real.steps[woodpile - 1]?.command ?? []).includes('tools/generate_yard_outbuildings.py')\n    && (real.steps[woodpile + 1]?.command ?? []).includes('tools/generate_kept_ground.py'));\n"
after[p]=before[p].replace(anchor,extra+anchor)
scene=next(j for j,s in enumerate(new_steps) if s['command'][:2]==['python3','tools/compile_scene.py'])
for off,name in [(1,'generate_entrances.py'),(2,'jaunt_built_so_far.py'),(3,'compile_jaunts.py'),(4,'compile_source_use.py')]:
 assert new_steps[scene+off]['command'][1]=='tools/'+name
files=[];patch=[]
for path in paths:
 assert(root/path).read_bytes()==before[path]
 for label,items in [('before',before),('candidate',after)]:
  dest=out/label/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(items[path])
 files.append({'path':path,'before_sha256':hashlib.sha256(before[path]).hexdigest(),
               'after_sha256':hashlib.sha256(after[path]).hexdigest()})
 patch.extend(difflib.diff_bytes(difflib.unified_diff,before[path].splitlines(keepends=True),
                               after[path].splitlines(keepends=True),
                               fromfile=('a/chicago/4d/'+path).encode(),tofile=('b/chicago/4d/'+path).encode()))
(out/'proposal.patch').write_bytes(b''.join(patch))
(out/'input-guards.json').write_text(json.dumps({'status':'UNAPPLIED_3PATH_NATIVE_PROPOSAL',
 'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,
 'new_steps':202,'new_woodpile_step_1based':i+2,'existing_jaunt_offsets_exact':[1,2,3,4],
 'raw_manifest_only_insertion':True,'no_native_execution_or_tests':True},indent=2)+'\n')
print(json.dumps({'paths':len(files),'new_steps':202,'woodpile_step':i+2,'patch_bytes':sum(map(len,patch))}))
