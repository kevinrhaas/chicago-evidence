# Minimal native woodpile ordering proposal — T3081

UNAPPLIED three-path proposal; no canonical mutation, native execution, test,
Blender, browser or fetch. The actual geometry/web binding guards are untouched.

Insert the existing bare command `python3 tools/generate_woodpiles.py` immediately
after `generate_yard_outbuildings.py`, before `generate_kept_ground.py`. It becomes
step180 of202. The new owner is only
`chicago/4d/data/yard/town_woodpiles.json`.

The other changes mark only its writer-inventory row `manifest`, preserving the
historical2026-10-02 clean-tree measurement/finding, and add one explicit native
self-test assertion that woodpiles follow outbuildings and precede kept ground.
The existing entrance/built-so-far/jaunts/source-use checks remain unchanged at
scene offsets+1/+2/+3/+4. Compile-liberties remains step142, so its tail is61steps.

Exactly three authored paths:

- `tools/derived_manifest.json`: one raw insertion, not full reserialization;
- `tools/writer_inventory.json`: only the woodpile row's placement/placed fields;
- `tools/rederive.mjs`: one new dependency-order assertion.

Root may inspect `proposal.patch` and `input-guards.json`, then explicitly apply:

```sh
python3 /tmp/T3081-woodpile-native-proposal/apply_guarded.py --project-root /tmp/chicago-log-integration/chicago/4d
```

All three current preimages and candidate hashes must match before the first
write. The helper stages/commits nothing and has not been invoked here. Root owns
the native manifest/self-test checks and settled61-step tail.

## Physical dependencies and absence of a new feedback cycle

`generate_woodpiles.Ground` (lines136–182) reads dooryard.world() plus plantings,
pickets, other yard goods/wagons/outbuildings, and exact current doorway zones.
It explicitly skips its own output at157–158; in-run `self.piles` starts empty.
dooryard.world() (generate_dooryard_plantings.py:388–451) reads compiled sidecars,
building obstructions, raw terrain, streets, enclosure runs and frontage walks.
It does not read yard woodpiles. The following current writers supply obstacles:

| Existing step | Writer/input |
| ---: | --- |
| 146–147 | compiled sidecars and entrance state |
| 153/155 | dooryard pickets and plantings |
| 158/160/161 | frontage walks, lot goods and lot-line fences |
| 163–166/170 | planted rows/groves/fruit and river works where present |
| 177 | trade goods, frontage wagons and related placed objects |
| 178 | trade-yard lots and wagons |
| 179 | yard outbuilding footprints — the last actual physical obstacle input |

Kept-ground's later yard records contain no `items`, `outbuildings`, wagon centers
or fence runs consumed by Ground. Its town_yard_paths has `runs: []`; neither
therefore extends the physical dependency beyond179. The new writer sits before
kept ground and all closing/audit consumers.

No woodpile-to-goods/outbuilding feedback was found:

- generate_yard_goods._town_world (1225–1310) reads sidecars, streets, frontage,
  enclosures, wharves/hulls and terrain; it does not read yard/woodpile JSON.
- generate_trade_yards (329–333) reads a fixed four-file yard list, excluding
  woodpiles; generate_yard_outbuildings reads trade-goods wagons (178–182).
- generate_kept_ground (204–214) reads outbuildings and trade-yard ground, not
  piles. Ground's own pile avoidance is only the current in-memory placement run.

The wider pre-existing scene/structure fixed point still requires the native
runner's repeated tail until a lap moves nothing. No new need to restart the full
upstream pass was found for the changed head/woodpile inputs. The note-reader
declaration is read by replace_invented_residents.harvest_names, which is not a
manifest stage and remains checked by normal preflight. No new stage or bypass is
added for it.

## Placement-policy JSON: production tables versus the changed report field

The complete JSON is a real production input. placement_policy_1835.constant()
(703–712) reads its `constants` through policy(), even when callers import a Python
function. Seating reads its `clauses`; seat_platted_ground also consumes
`multi_building_lot`. These must stay unchanged.

The particular changed value `outliers[wolf_point_tavern].setback_m` is the rounded
diagnostic produced by outliers() (952–965) and build() (1133–1143). No producer or
seating read of that cached outlier/setback field was found. measure_face_rule
imports outliers() and remeasures the tree rather than consuming cached outliers.

For the observed39.76→42.15m diagnostic alone, normal
`python3 tools/placement_policy_1835.py --build` after settled native derivation is
sufficient; no second manifest writer is proposed. Root must confirm the complete
semantic diff contains only that field and retains all production tables,
constants, clauses and the same19 outlier ids. It is not permission to update a
changed policy rule after its consumers have run.

No command, test, clean-tree measurement or convergence pass was executed by this
preparation. Source inspection supports the slot; actual current derivation and
all checks remain root-owned. The historical reproduction finding is retained as
history, not promoted to a new measured pass.
