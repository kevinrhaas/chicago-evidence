"""Explicit root adoption of the reviewed3-path proposal; not run by preparation."""
import argparse,hashlib,json
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--project-root',type=Path,required=True)
args=ap.parse_args();root=args.project_root.resolve();packet=Path(__file__).resolve().parent
entries=json.loads((packet/'input-guards.json').read_bytes())['files']
assert len(entries)==3 and {e['path'] for e in entries}=={'tools/derived_manifest.json','tools/writer_inventory.json','tools/rederive.mjs'}
writes=[]
for entry in entries:
 target=root/entry['path'];source=packet/'candidate'/entry['path']
 assert not target.is_symlink() and not source.is_symlink()
 old=target.read_bytes();new=source.read_bytes()
 assert hashlib.sha256(old).hexdigest()==entry['before_sha256'],entry['path']+' preimage drift'
 assert hashlib.sha256(new).hexdigest()==entry['after_sha256'],entry['path']+' candidate drift'
 writes.append((target,old,new))
done=[]
try:
 for target,old,new in writes:
  assert target.read_bytes()==old,target
  target.write_bytes(new);done.append((target,old))
except Exception:
 for target,old in reversed(done):target.write_bytes(old)
 raise
print('Applied3 authored files uncommitted; no native writer/test executed.')
