// Isolated one-capture pictorial flag pose; never a canonical or global wind edit.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import http from 'node:http';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const here=path.dirname(fileURLToPath(import.meta.url)),root=path.join(here,'fixture');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const inputs=JSON.parse(fs.readFileSync(path.join(here,'INPUTS-v2.json')));
for(const [rel,row] of Object.entries(inputs.files)) assert.equal(sha(fs.readFileSync(path.join(here,rel))),row.sha256,`frozen input changed:${rel}`);
const frozen=JSON.parse(fs.readFileSync(path.join(here,'frozen-inputs.json')));
for(const [rel,row] of Object.entries(frozen.files))assert.equal(sha(fs.readFileSync(path.join(root,rel))),row.sha256,`production input changed:${rel}`);
assert.equal(frozen.files['assets/gltf/tremont_house_1__frame_1833.glb'].sha256,'ed3c2605c9c3c584511e3e093a4b57facff7854b29e9a73354891297708a244a');
assert.equal(frozen.files['camera.json'].sha256,'16830ecda2efde0b4ccdb028bc559fb88529711a11b9cb0f05adbf4e8294bda2');
assert.match(fs.readFileSync(path.join(root,'renderers/web/js/flags.js'),'utf8'),/const WIND_FROM_DEG = 225;/);
// Saved JSON represents both finite signed zeroes as0. Preserve every other
// numeric value, array member and object key exactly; no epsilon or dropped key.
const jsonSignedZero=v=>{
 if(typeof v==='number'){assert(Number.isFinite(v),'nonfinite held value');return Object.is(v,-0)?0:v;}
 if(Array.isArray(v))return v.map(jsonSignedZero);
 if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,jsonSignedZero(x)]));
 return v;
};
// Refusal guards: this repair cannot hide a changed finite coefficient/key.
assert.deepEqual(jsonSignedZero([-0,0,1]),[0,0,1]);
for(const invalid of [NaN,Infinity,-Infinity])assert.throws(()=>jsonSignedZero({matrix:[invalid]}));
assert.notDeepEqual(jsonSignedZero([1e-12]),[0]);
assert.notDeepEqual(jsonSignedZero([{extra:undefined}]),[{}]);
const baseline=JSON.parse(fs.readFileSync(path.join(here,'baseline/normal.json')));
assert.equal(baseline.materialStudy.factor,.25);assert(Math.abs(baseline.actualWindToBearingDeg-45)<1e-6);
console.log('Dry PASS:328 production inputs, exact reviewed0.25 baseline, one explicit105.6degree pictorial pose; browser not launched yet.');
if(!process.argv.includes('--capture'))process.exit(0);
const out=path.join(here,'runs',new Date().toISOString().replaceAll(':','-'));assert(!fs.existsSync(out));fs.mkdirSync(out,{recursive:true});
const require=createRequire('/workspace/package.json'),{chromium}=require('playwright');
const requests=[],errors=[],mime={'.js':'text/javascript','.mjs':'text/javascript','.html':'text/html','.json':'application/json','.glb':'model/gltf-binary','.jpg':'image/jpeg','.png':'image/png','.bin':'application/octet-stream'};
const server=http.createServer((req,res)=>{let rel;try{rel=decodeURIComponent(new URL(req.url,'http://localhost').pathname);}catch{res.writeHead(400);res.end();return;}const file=path.resolve(root,'.'+rel);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){requests.push({path:rel,status:404});res.writeHead(404);res.end();return;}requests.push({path:rel,status:200,sha256:sha(fs.readFileSync(file))});res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});fs.createReadStream(file).pipe(res);});
let browser;
try{
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});const base=`http://127.0.0.1:${server.address().port}`;
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 const page=await browser.newPage({viewport:{width:1637,height:796},deviceScaleFactor:1});page.on('pageerror',e=>errors.push(e.stack||e.message));
 await page.route('**/*',route=>{const url=new URL(route.request().url());if(url.origin===base||['data:','blob:'].includes(url.protocol))return route.continue();errors.push(`external request refused:${url.href}`);return route.abort();});
 await page.goto(base+'/renderers/web/index.html?roof_factor=.25&flag_pose_to=105.6',{waitUntil:'domcontentloaded',timeout:180000});
 await page.waitForFunction(()=>window.__diagnostic?.ready||window.__diagnostic?.error,null,{timeout:180000,polling:250});
 const error=await page.evaluate(()=>window.__diagnostic.error);assert(!error,error);
 const proof=await page.evaluate(()=>window.__diagnostic.render(false));assert.deepEqual(errors,[]);assert.equal(proof.nativeProblems.length,0);
 assert.equal(proof.globalNativeWindFromDeg,225);assert(Math.abs(proof.actualFlagFlyBearingDeg-105.6)<1e-6);assert.equal(proof.poseStudy.requestedFlyToBearingDeg,105.6);
 assert.deepEqual(proof.materialStudy,baseline.materialStudy,'roof and all source/native materials or geometry changed');
 assert.deepEqual(proof.actualRoofGpu.colorTextureData,baseline.actualRoofGpu.colorTextureData,'native roof GPU instance colours changed');
 for(const key of ['renderSettings','buildingMatrix','bounds','holder','clothVertices','clothConfidenceValues','cameraControls','projectionMatrix','anchor','targetDate','phase','drawn'])assert.deepEqual(jsonSignedZero(proof[key]),baseline[key],`held native input changed:${key}`);
 for(const key of ['gpuProjectionMatrix','actualCameraWorldMatrix','flagTime','mode','gradeModes','gradeOpacity','hiddenLevels','vertexShaderSha256','fragmentShaderSha256'])assert.deepEqual(jsonSignedZero(proof.draw[key]),baseline.draw[key],`held linked flag state changed:${key}`);
 assert.notDeepEqual(proof.draw.actualFlagWorldMatrix,baseline.draw.actualFlagWorldMatrix,'pose transform did not change');
 assert.notDeepEqual(proof.draw.gpuModelViewMatrix,baseline.draw.gpuModelViewMatrix,'GPU did not consume pose transform');
 assert.deepEqual(proof.poseStudy.originalNativeHolder.position,proof.poseStudy.modifiedHolder.position);
 assert.deepEqual(proof.poseStudy.originalNativeHolder.position,baseline.holder);
 proof.scope='UNADOPTED research: one explicit single-flag holder appearance pose atTO105.6; roof factor held0.25; no global wind, geometry, camera, clock, grade or lighting edit. Source is undated and no historical weather claim follows.';
 proof.baselineSha256=inputs.files['baseline/normal.json'].sha256;proof.inputMasterSha256=frozen.files['assets/gltf/tremont_house_1__frame_1833.glb'].sha256;
 fs.writeFileSync(path.join(out,'pose.json'),JSON.stringify(proof,null,2)+'\n');await page.screenshot({path:path.join(out,'pose.png'),timeout:180000});
 await page.setContent('<!doctype html><style>html,body{margin:0}div{display:flex;gap:24px}img{width:1637px;height:796px;display:block}</style><div><img id="source"><img id="native"></div>');await page.setViewportSize({width:3298,height:796});
 await page.evaluate(({source,native})=>{document.querySelector('#source').src=source;document.querySelector('#native').src=native;},{source:'data:image/jpeg;base64,'+fs.readFileSync(path.join(root,'source.jpg')).toString('base64'),native:'data:image/png;base64,'+fs.readFileSync(path.join(out,'pose.png')).toString('base64')});
 await page.waitForFunction(()=>[...document.images].every(i=>i.complete&&i.naturalWidth===1637));await page.screenshot({path:path.join(out,'source-vs-pose.png'),timeout:180000});
 assert.deepEqual(requests.filter(x=>x.status>=400),[]);assert.deepEqual(errors,[]);
 fs.writeFileSync(path.join(out,'requests.json'),JSON.stringify(requests,null,2)+'\n');fs.writeFileSync(path.join(out,'run.json'),JSON.stringify({status:'one actual pose captured; visual review required',errors,roofHeld:.25,globalNativeWindFromDeg:225,pictorialFlyToBearingDeg:105.6,canonicalAdoption:false},null,2)+'\n');console.log('Pose capture complete:'+out);
}catch(error){fs.writeFileSync(path.join(out,'failure.json'),JSON.stringify({error:error.stack||error.message,errors,requests},null,2)+'\n');throw error;}
finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));}
