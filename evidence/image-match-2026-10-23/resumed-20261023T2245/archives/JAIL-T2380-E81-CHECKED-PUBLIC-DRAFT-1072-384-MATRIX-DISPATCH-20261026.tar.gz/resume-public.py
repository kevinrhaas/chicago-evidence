from pathlib import Path
import subprocess,json,os,datetime,hashlib,re
os.sched_setaffinity(0,{1});repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';packet=Path('/workspace/shared/T2380-integrate-a575-20261026');c=json.loads((packet/'checked-commit/RESULT.json').read_text());assert c['status']=='ACTUAL_CHECKED_TREE_NORMAL_COMMIT_AND_COMMITTED_GATES_PASS';head=c['head'];branch='steward/t2380-jail-palisade';actor='Codex jail picture 2026-10-25';out=packet/'updated-public';assert out.is_dir();env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None)
def api(p):return json.loads(subprocess.check_output(['gh','api',p],cwd=repo,env=env))
pr=api('repos/kevinrhaas/chicago/pulls/1333');assert pr['state']=='open' and pr['base']['ref']=='dev' and pr['head']['sha']==head and pr['head']['ref']==branch
ref=api('repos/kevinrhaas/chicago/git/ref/heads/'+branch);assert ref['object']['sha']==head
(out/'FRESH-VERIFIED-PUBLIC-HEAD.json').write_text(json.dumps({'pr':pr['number'],'pr_head':pr['head']['sha'],'branch_head':ref['object']['sha'],'state':pr['state']},indent=2)+'\n')
# Refresh ONLY our own live lap through the native compare-and-swap tool.
r=api('repos/kevinrhaas/chicago/git/ref/heads/lap/pr-1333');lap=api('repos/kevinrhaas/chicago/git/commits/'+r['object']['sha']);assert lap['message'].splitlines()[0].startswith('lap PR #1333 — '+actor+' ')
with(out/'native-own-lap-renew.log').open('x')as f:p=subprocess.run(['node','tools/ticket.mjs','lap','1333','--force','--by',actor],cwd=app,env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0,p.returncode
with(out/'native-own-lap-status.log').open('x')as f:p=subprocess.run(['node','tools/ticket.mjs','lap','1333','--status'],cwd=app,env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==3 and actor in(out/'native-own-lap-status.log').read_text();r=api('repos/kevinrhaas/chicago/git/ref/heads/lap/pr-1333');lap=api('repos/kevinrhaas/chicago/git/commits/'+r['object']['sha']);assert lap['message'].splitlines()[0].startswith('lap PR #1333 — '+actor+' ');taken=datetime.datetime.fromisoformat(lap['committer']['date'].replace('Z','+00:00'));expiry=taken+datetime.timedelta(hours=3)
body=f'''The log jail lacked the high plank palisade described by Gale and shown in the credited 1902 plate. This adds a pointed board enclosure through the native renderer and preserves the tested entrance approach. Height, outline, stock and July continuity are reconstructed. Source comparisons reuse the actual enclosure meshes and bind their inputs; provisional cameras retain credits without a historical “From this spot” action.

Both original comparisons remain **DIFFERS**. The missing keeper house and unresolved full-compound/gate relationship remain open on T-2380.

Dependency #1328 is merged and its fold is integrated at `a575ddde`. Its release entry is removed only after the native reader confirmed exact title/kind/items already folded as v2302; incoming canonical history remains byte-exact.

Four reviewed smoke and placement checks also account for the existing lighthouse translucent batch, footprints with offset origins and already-landed 1904 buildings. These are the exact checked public `6a61ab6e` repairs. Renderer assets, positions, tolerances and frame ceilings are unchanged by those repairs.

Validation:

- Native 202-step resolution, seven-step second pass and one 57-step fixed-point lap passed, followed by package tail and publish. All 5,347 protected inputs stayed exact. All 44 XLSX/gzip artifacts were audited; three gzip files and two workbooks were restored to exact incoming bytes after whole-content equality, excluding only workbook modification timestamps. All 5,454 incoming source/generator/asset paths remain byte-exact.
- Actual 390×780 and 1280×800 normal/By Grade views, pointed tops, source credits/Lib, grounding, budgets and nine-step gateway paths were reviewed earlier. Captures used `9f7`; the selected jail master/web, fence JSON/renderer and sidecar remain byte-identical in the current published mirror. The separate coarse planner mismatch and readiness retry remain qualified. These are selected-shape evidence, not fresh whole-app performance results.
- All three required preflight questions passed on tree `{c['tree']}`. Actual native whole-check footer: {next(line for line in c['whole_footer'].splitlines() if 'CHECK PASS' in line)}. Committed-head changelog, IDs and native history checks passed on `{head}`.

Fresh full 18-group published coverage of this exact head is pending. No merge readiness or original image-match completion is claimed. Recovery and preserved failures are in [chicago-evidence](https://github.com/kevinrhaas/chicago-evidence).
''';(out/'PR-BODY.md').write_text(body)
p=subprocess.run(['gh','pr','edit','1333','--repo','kevinrhaas/chicago','--body-file',str(out/'PR-BODY.md')],cwd=repo,env=env,capture_output=True,text=True);(out/'edit-pr.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
x={'status':'NORMAL_FF_PUSH_UPDATED_PR1333_EXACT_OWN_LAP_HELD','closed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'tree':c['tree'],'base':c['actual_committed_base'],'pr':1333,'url':'https://github.com/kevinrhaas/chicago/pull/1333','lap_marker':r['object']['sha'],'lap_taken':lap['committer']['date'],'lap_expires_after':expiry.isoformat().replace('+00:00','Z'),'body_sha256':hashlib.sha256(body.encode()).hexdigest(),'pending':'ONE full18 finalcheckedhead batch +ordinaryCI/report/warranted actualPASS beforemergeDEV; originalT2380DIFFERS.'};(out/'RESULT.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
