# Miller and Hogan credited inline references

Image-host PR9 is merged normally at65aead907a167abe911004c676d5f84416dc4e46, exactly checkedtree0ea8dcadf228809da8eeda71f73bec85025040df and expectedparents. NativePillow pipeline produced the four new files (777375B); native scoped sync generated the four provenance rows. All1298 prior host rows and previous image paths are unchanged. Actual Pages run40895796233 completed SUCCESS on the exact merged commit; all4 public HTTPS URLs returned200/imageJPEG with exact native SHA256 and byte counts. See PUBLIC-HTTPS-BYTE-VERIFICATION.json.

Apply `stream-early-chicago-miller-hogan-references.json` as a NEW stream under chicago/prairie_1904_v1/research/images. Union ONLY the four file rows in `APP-STORE-FOUR-ROWS.json` into the actual current STORE; preserve every other row and recompute totalbytes from allrows. Do not replace STORE wholesale with the tiny scoped output.

`APP-CAMERA-ENTRYWISE-DELTAS.json` adds ONLY each camera's existing library_image opt-in. The expected camera preimages are guards at handoff time; if owner edited metadata meanwhile, apply by semantic field after confirming source/photo/numeric rays, never overwrite the entire camera. This metadata changes each cameraSHA and needs a genuine final native capture. `APP-GRADE-ALIASES-ENTRYWISE.json` changes ONLY each existing pictured-ruling alias from sourceid to libraryid, preservingattestedstructuregrade and all other rulings. It prevents counting the same held composition twice. Run native library builder before sidecar/publish/actualbothapp review. No compiler/API/renderer change or historicalSpot.

NYPL lithograph publication1867 is printed in the heldsheet. Cameronrights remain the existing localinventory/publicdomain metadata with explicit unverified originalpublication/holding caveats; no new rightsfinding. Both records also carry owner-approved reference-copy credit. No Alamylicensedcopy was fetched. No imagepixel texture or trace. The entireheldpicture and caption are retained in the display derivative.

No appsourcefile was written by this hosting unit. The groupowner owns the actualnative/build/app/gate/merge and originalticketacceptance.
