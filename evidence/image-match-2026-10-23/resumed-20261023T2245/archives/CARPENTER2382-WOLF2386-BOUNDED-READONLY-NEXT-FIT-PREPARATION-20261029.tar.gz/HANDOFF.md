# Next original image-ticket work after School, Green Tree and Dearborn bridge

External read-only preparation. No primary source/index/ref, ticket, model, camera or match record was changed. No Blender, native render or browser was run by this preparation.

## Carpenter T-2382: one finite two-control trial

The actual PR1348 (`d3a1f4db…`) changed the dark doorway and deliberately left the original OPEN. Current canonical Andreas match still has two broad OPEN rows: annex apparent size/height/relation to the hotel; and roof/eave/stack/window/log/source-camera fit. It is not closure-ready.

The current annex MASTER is exactly `d9a216cea551ad194fa05950543e465cad46fb866a5f547ebdf292c562db63a3`, and its actual grouped side-by-side was directly inspected. Its existing camera comes from a five-main-wall hotel fit with poorly constrained off-image principal point. It projects the annex free-front corner near x239 while the source corner is approximately x480; the hotel-junction corner is near x889 in both. Shrinking the documented 16×20ft building just to satisfy that camera would be unjustified.

`Carpenter-WALL-CAMERA-PURE-RESULT.json` contains six independently selected approximate annex wall corners (±10px), their exact current local coordinates, all before/trial projections and the withheld roof/stack predictions. The camera keeps current documented-size orientation6.096×4.877m and inferred2.5m eaves. It fixes the old focal4730.3525 and fits eye/yaw/principal with ordinary square pixels and no image warp. The wall fit is RMS9.64px/max13.46px. Its very low0.472m eye and principal near the image edge are diagnostic framing parameters, not historical or visitor camera measurements.

With that camera, the withheld35° roof apex projects near y666.5 against approximate source y731. A21.49° trial lowers the reconstructed ridge0.747m. Moving the existing stack fraction.80→.94 moves it0.853m toward the free gable, projecting x366.15 against approximate source x366. Keep its.55m width/.65m head and all other controls; the remaining roughly.15m head residual is withinT3153/camera uncertainty. No cap micro-edit, footprint swap, placement movement or opening change is proposed.

`Carpenter-PROPOSED-STRUCTURE-UNEXPORTED.json` changes only those two numeric controls and their provenance/confidence prose. Current native parameter resolution/validation actually passed; this proves parameter admissibility, not a mesh or image match. `CARPENTER-FINITE-TWO-CONTROL-PLAN.json` records the six exact leaf edits, input hashes, arithmetic, source/date limits and required finite actual run. The hotel stays an unchanged holdout, with its own unresolvedT-2383 geometry. Do not use an annex-only fit to claim the hotel matches.

Next, after actual original claim and primary lease, revalidate hashes and run actual current-producer MASTER/WEB and bounded native before/after captures on the existing and proposed diagnostic cameras. Directly inspect the hotel holdout and source. Stop this finite bracket at an honest verdict; do not turn wall-point residuals into MATCHES. Original closure still needs its derivative pictures, native derived/clearance, both app viewports, fullcheck, normal dev PR merge and official settlement.

## Wolf T-2386: current geometry is nearer signoff; finite picture coverage remains

Actual PR1336 (`130dd237…`) merged the dark roof repair and preserved the original OPEN. Its current MASTER225f3e104… and WEBfdc5ef22… are already genuine native outputs. The selected immutable recovery includes the actual current-master NYPL comparison. I directly inspected it: two outward gables, two dark doors, right-gable sash, broad roof head plus pipe and leaning sign/pole agree in broad visible form. No additional visitor-noticeable geometry change was established here. The isolated render omits procedural app shingle maps; roof pigment/weathering remains reconstructed, and exact print RGB is not a metric colour target.

The eight original files contain nine compositions. Canonical `reference_views/wolf_point_tavern/` is still absent. The useful next work is one current-master capture per usable composition with explicit governance, not another geometry variant loop:

| File/composition | Finite action | Limits |
|---|---|---|
| `chicago_wolf_point_1833_nypl.jpg` | Enroll current independent1867Blanchard/Shober source and existing numeric camera; one actual canonical capture and review. | Current recovered actual view is external, rawUNREVIEWED; changing canonical camera/photo paths requires genuine new capture. Retrospective1833 does not proveJuly1835. |
| `chicago_wolf_point_1830.jpg` | One separate fit/capture from its own gables. | Andreas1884 scene1830; earlier bare signpole/date and sparse hatch detail are source disagreement, not a new count defect. |
| `chicago_wolf_point_1830_and_1833_engravings.jpg`, LEFT | One fit/capture with explicit traceable full-source/crop. | Distinct oval1830 plate; context changes do not move world coordinates. |
| Same file, RIGHT | One independent framing/capture. | Closer single-gable crop; leave the partner naturally occluded/off-frame, never hide it artificially. |
| `chicago_wolf_point_1832.jpg` | One capture if its decorative vignette has usable identified Wolf silhouette. | Miller/Davis1857; no metric or fine pane/material claim. |
| `chicago_town_view_1833_colbert.jpg` | One separate frame/capture using partial gables and right door/sash. | Colbert/Chamberlin1871; left edge is cropped. |
| `chicago_wolf_point_1833_hammon.jpg` | One independent one-gable postcard frame/capture. | Widney/Hammonc1908; crop/printing differences withinT3153, no invented missing partner. |
| `chicago_wolf_tavern_miller_house_1832.jpg` | Resolve the existing source-edition record and record an allowed independent cross-check/capture when appropriate. | Old1892/1935catalog conflict is already recorded. Do not invent a blanket blocker for nineteenth-century artwork or treat holding/catalog dates as original publication. The proven1867NYPL source already independently governs geometry. No rights upgrade or new finding is claimed by this preparation. |
| `chicago_wolf_point_1833.jpg` | Explicit contextual/non-actionable disposition unless Wolf can actually be identified. | Herriott1902 tiny birdseye: no currently secure measurable Wolf target. No invented roof identity or camera. |

The recovery's `ALL8-T3153-COVERAGE-REVIEW.json` predates the final roof repair and binds the earlier master; it is a source inventory, not current-master proof. The recovered deep-brown native match is bound to the actual current MASTER. Preserve that distinction. Use nineteenth-century public-domain artwork provenance directly where established; unrelated modern text-source `check_required` flags do not block geometry derived independently from the cleared picture.

Immutable archive recovery is selected-member only. The first script recovered two priced archives then correctly refused the next11,084,127-byte archive against its8MiB cap; the separately priced continuation recovered that bounded archive and readiness packet with completearchiveSHA and selected-memberSHA checks. Both scripts and refusal/continuation receipts are retained. No full old worktree, model family or credential/profile was restored.
