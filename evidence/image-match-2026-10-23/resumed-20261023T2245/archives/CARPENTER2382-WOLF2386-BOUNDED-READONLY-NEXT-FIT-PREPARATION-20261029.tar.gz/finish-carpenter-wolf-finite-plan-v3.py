from pathlib import Path
import json,hashlib,copy,datetime,math,sys,os
O=Path('/workspace/next-original-Carpenter-Wolf-readonly-v3-20261029');R=Path('/workspace/chicago');A=R/'chicago/4d'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rel='chicago/4d/data/structures/philo_carpenter_log_shop.json';old=json.loads((R/rel).read_text());d=copy.deepcopy(old);f=d['phases'][0]['form']
f['roof_pitch_deg']['value']=21.49;f['roof_pitch_deg']['confidence']='reconstructed';f['roof_pitch_deg']['sources']=['andreas_1884_sauganash_hotel_plate'];f['roof_pitch_deg']['note']+=' T-2382 finite external proposal2026-10-29:21.49degrees is a reconstructed local appearance trial, not a measured historical pitch. Six approximate manual annex wallcorner picks on Andreas1884 were independently fit to the retained6.096by4.877m rectangle and inferred2.5m eave with ordinarysquarepixels, fixedexistingf4730.35 and an annex-only unrendered diagnosticcamera. The old35degree ridge projects nearimagey666.5 against the manually read freegable apex near731;21.49 lowers the chosenridge about0.747m without changing footprint,frontline,placement,eaves,openings or hotel. Cameraidentity/date/calibration and the hotelholdout remain unresolved; actualnativeproduction and direct before/after review are still required. This proposal supersedes no accepted match.'
f['chimney_ridge_at']['value']=[.94];f['chimney_ridge_at']['note']+=' T-2382 finite external proposal2026-10-29: move the existingroofpiercingstack fraction from.80 to.94, toward the exposed local+x gable, retaining its.55mwidth/.65mhead and count. In the annex-only wallfit diagnostic, old.80 projects aroundx426 while .94 projects aroundx366, the approximate manually read picturestation. The0.85344m shift is a visitorvisible candidate, not a historicalmeasurement or acceptedrender. The same.65mhead after the proposedroofchange projects roughly0.15m below the approximate picturedtop, withinT3153/camera uncertainty; no new cap/detail change or finefit loop is proposed. Actualnativecapture and hotelholdout review remain required.'
post=O/'Carpenter-PROPOSED-STRUCTURE-UNEXPORTED.json';post.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
# Validate on current native parameter reader with no Blender or file mutation.
os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True;sys.path.insert(0,str(A/'generators'))
from archetypes.log_dwelling_params import from_phase
p=from_phase(d['phases'][0],d);p.validate()
changed=[]
def leaves(x,y,path=()):
 if type(x)is not type(y):changed.append({'path':list(path),'old':x,'new':y});return
 if isinstance(x,dict):
  for k in sorted(set(x)|set(y)):
   if k not in x:changed.append({'path':list(path+(k,)),'old':'EXPECTED_ABSENT','new':y[k]})
   elif k not in y:raise AssertionError('Unexpected removal')
   else:leaves(x[k],y[k],path+(k,))
 elif isinstance(x,list):
  if len(x)!=len(y):changed.append({'path':list(path),'old':x,'new':y})
  else:
   for i,(a,b)in enumerate(zip(x,y)):leaves(a,b,path+(i,))
 elif x!=y:changed.append({'path':list(path),'old':x,'new':y})
leaves(old,d)
assert len(changed)==6
assert d['phases'][0]['position']==old['phases'][0]['position'] and d['phases'][0]['footprint']==old['phases'][0]['footprint']
bindings=[]
for q in [R/rel,A/'data/structures/sauganash_hotel.json',A/'data/reference_views/philo_carpenter_log_shop/andreas-1884.json',A/'data/reference_views/philo_carpenter_log_shop/andreas-1884.match.json',A/'assets/gltf/philo_carpenter_log_shop__log_1832.glb',A/'assets/web/philo_carpenter_log_shop__log_1832.glb',A/'assets/gltf/sauganash_hotel__frame_1831.glb',A/'generators/archetypes/log_dwelling.py',A/'generators/archetypes/log_dwelling_params.py',A/'generators/archetypes/frame_dwelling.py',A/'tools/photo_match.mjs',R/'chicago/reference/images/chicago/chicago_sauganash_hotel_1831.jpg']:
 bindings.append({'path':str(q.relative_to(R)),'bytes':q.stat().st_size,'sha256':sha(q)})
assert next(x['sha256']for x in bindings if x['path'].endswith('gltf/philo_carpenter_log_shop__log_1832.glb'))=='d9a216cea551ad194fa05950543e465cad46fb866a5f547ebdf292c562db63a3'
(O/'CARPENTER-FINITE-TWO-CONTROL-PLAN.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EXTERNAL_AUTHORED_CANDIDATE_NATIVE_PARAMS_VALIDATE_PASS_UNEXPORTED','changes':changed,'only2physical_controls_changed':['roof_pitch_deg35.0to21.49','chimney_ridge_at0.80to0.94'],'current_inputs':bindings,'native_parameter_reader_validate':'PASS','eaves_footprint_position_frontline_openings_hotelsource_unchanged':True,'candidate_ridge_drop_m':math.tan(math.radians(35))*4.877/2-math.tan(math.radians(21.49))*4.877/2,'candidate_stack_shift_m':(.94-.80)*6.096,'head_cap_width_and_count_unchanged':True,'roof_top_clearance_existing_head_m':.65,'required_floor_m':.4572,'candidate_camera':'Carpenter-ANNEX-WALL-camera-PROPOSED-UNRENDERED.json','camera_warning':'Eye0.472m is an unconstrained diagnosticframing solution, not visitorcamera/historicaleyeheight. Provisional offcentre principalcx1960.5 remains poorlyconditioned. Ordinaryperspective/noimagewarp; nohistoricalFromthisspot.','source_governance':'Braunhold/Andreas1884 publicdomain retrospectivepre1834image governs picturedappearance. ExistingCarpenterannexidentity is captionbased; no independentidentity,date,metricdimension or July1835newfinding. Petford/Trowbridgederivatives remain separateactualcomparisoncoverage; no newrightsblocker invented.','finite_execution':['Revalidate all current inputs, take native originalT2382claim and clean branch/primary lease after School/GT/Bridge.','Run actual currentnative unchangedproducer on proposedrecord, actualWEB binding, preserve allother81log/271framepairs; no handwrittenrecipes.','Run exactlyone frozen currentcamera before/after AND one proposedannexwallcamera before/after, hotelrendered as unchangedholdout. Inspectactualnative pairedresults; diagnosticwallfit does not accepthotel.','If proposed form improves source and no new streetvisibledefect appears, adopt only actualqualifiedcamera/metadata and2authoredcontrols; if camera/model conflict remains, retainexplicitDIFFERS and stopfinitebracket ratherthan continuingunboundedfits.','Complete derivativepicturecoverage, nativecurrentowners/clearance/BOTHapp/fullcheck/PRdevmerge andoriginalticketsettlement onlyafteractualproof.'],'canonical_mutations':False,'native_export_capture_app_fullgate_PR_merge_ticketclosure':False},indent=2)+'\n')
# Bind first recovery's partial-stage files after the later independent11MB archive refusal.
rows=[]
for n in ['deep-brown82','deep-brown82-native-closure']:
 original=Path('/tmp')/('WolfPoint-T2386-'+n+'-20261026');manifest=json.loads((original/'MANIFEST.json').read_text());idx={r['path']:r for r in manifest['files']}
 for q in (O/n).rglob('*'):
  if q.is_file():
   key=str(q.relative_to(O/n));assert q.stat().st_size==idx[key]['bytes'] and sha(q)==idx[key]['sha256'];rows.append({'packet':n,'path':key,'bytes':q.stat().st_size,'sha256':sha(q)})
(O/'FIRST-RECOVERY-ATTEMPT.json').write_text(json.dumps({'status':'FIRST2BOUNDED_ARCHIVES_AND_SELECTED_FILES_VERIFIED_THEN_NEXT11MB_ARCHIVE_REFUSED_8MIB_CAP','first_script':'/tmp/restore-school-agent-wolf-selection-v3.py','first_two_archives_bytes':[4200447,7030664],'partial_selected_files_verified_against_original_immutable_manifests':rows,'subsequent_recovery':'Known nativeclosure11084127B explicitlypriced and recoveredseparately with completearchiveSHA; receiptRESTORE-RECEIPT.json. No primaryfiles restored.'},indent=2)+'\n')
print(len(changed),p.roof_pitch_deg,p.chimney_ridge_at)
