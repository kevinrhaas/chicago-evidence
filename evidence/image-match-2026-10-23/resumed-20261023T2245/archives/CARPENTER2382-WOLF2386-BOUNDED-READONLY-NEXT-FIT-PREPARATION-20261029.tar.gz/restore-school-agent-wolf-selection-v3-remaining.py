from pathlib import Path
import json,hashlib,urllib.request,tarfile,io,datetime
O=Path('/workspace/next-original-Carpenter-Wolf-readonly-v3-20261029');assert O.exists()
selections={
'native-closure':['ALL8-T3153-COVERAGE-REVIEW.json','README.md'],
'readiness-review':['REVIEW.json','SUMMARY.md','retained-light-plan/README.md']}
receipts=[]
for name,want in selections.items():
 p=Path('/tmp')/('WolfPoint-T2386-'+name+'-20261026');m=json.loads((p/'MANIFEST.json').read_text());idx={r['path']:r for r in m['files']};r=json.loads((p/'PAYLOADS-RESTORE.json').read_text());assert r['archive_bytes']<=11084127, 'Actual known largest native closure archive11084127B; no broad restore'
 req=urllib.request.Request(r['immutable_archive_url'],headers={'User-Agent':'Chicago-bounded-immutable-selected-recovery'})
 with urllib.request.urlopen(req,timeout=90) as response:
  assert response.status==200;raw=response.read(r['archive_bytes']+1)
 assert len(raw)==r['archive_bytes'] and hashlib.sha256(raw).hexdigest()==r['archive_sha256']
 rows=[]
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as t:
  members=t.getmembers()
  for rel in want:
   matches=[x for x in members if x.name==rel or x.name.endswith('/'+rel)];assert len(matches)==1,(rel,[x.name for x in matches]);x=matches[0];assert x.isfile() and not x.issym();row=idx[rel];assert x.size==row['bytes'];b=t.extractfile(x).read();assert hashlib.sha256(b).hexdigest()==row['sha256']
   dest=O/name/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);rows.append({'path':rel,**row})
 receipts.append({'packet':str(p),'archive_bytes':len(raw),'archive_sha256':r['archive_sha256'],'immutable_archive_url':r['immutable_archive_url'],'selected':rows,'only_selected_members_written':True})
(O/'RESTORE-RECEIPT.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_BOUNDED_IMMUTABLE_ARCHIVE_SHA_AND_SELECTED_MEMBER_SHA_PASS','archives':receipts},indent=2)+'\n');print(O)
