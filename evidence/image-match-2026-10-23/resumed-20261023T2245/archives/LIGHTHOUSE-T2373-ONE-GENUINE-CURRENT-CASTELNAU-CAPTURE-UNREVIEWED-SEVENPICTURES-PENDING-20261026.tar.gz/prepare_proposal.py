"""Prepare external source/camera proposal; never write a source worktree."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess

OUT = Path(__file__).resolve().parent
REPO = Path('/workspace/chicago')
APP = REPO / 'chicago/4d'
OLD = Path('/workspace/T2373-8021-lighting-runs/20261024T152428-562158Z')
SID = 'chicago_lighthouse_1832'


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def write(name, value):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def copy(source, relative):
    target = OUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    return target


rows = []
base = REPO / 'chicago/reference/images/chicago'
specs = [
    ('chicago_harbor_lighthouse_1838.jpg', 'castelnau_1842_chicago_harbor',
     '1842 publication; circa1838 depicted date is the inventory attribution, after July1835',
     'Existing source record: public_domain; cross_check. No new rights finding.',
     'Governing broad-form picture. Shaft toe hidden in foliage; no measured diameter, 40ft datum or calibrated camera. Transfer into1835 is inferred continuity.',
     'PROPOSED exact-current canonical comparison; status remains unreviewed until native render and actual review.'),
    ('chicago_dearborn_drawbridge_1834.png', 'andreas_1884_dearborn_drawbridge_plate',
     '1884 publication; caption1834 dates the bridge, not every background feature',
     'Existing source record: public_domain; cross_check.',
     'Distant tapered tower with gallery and rounded cap; fine apertures, member counts, unseen base and scale not established.',
     'Cross-check existing broad form; drawing/count differences or unresolved tiny detail are not automatic new geometry blockers.'),
    ('chicago_dearborn_street_bridge_1834.jpg', 'dearborn_street_bridge_1834_engraving',
     'Retrospective Baker–Co plate; depicted bridge stood1834–1839; publication unresolved',
     'Existing 4D source record remains check_required/cross_check; this takes precedence over a broader inventory label.',
     'Distant stylized tower; cap silhouette differs from Castelnau. No independent metre or member-count control.',
     'Read-only cross-check; no new geometry, copied asset, public-domain finding or source-date inference derived here.'),
    ('eliza-chappel-school/21617595_10203558686525015_5452300313452439832_n.jpg', 'eliza_chappel_school_shore_view',
     'Depicted subject/date unresolved; lighthouse appearance is not a reliable terminus post quem',
     'Existing source: owner-approved attributed project-reference use; NOT a public-domain finding.',
     'Tiny roughly12px shaft. Broad conical-light shape only; facade details, colour and exact tower identity cannot be read independently.',
     'Tiny-view NOT SHOWN limits; no geometry prescription or new chronology from this drawing.'),
    ('chicago_fort_dearborn_river_mouth_1830.jpg', None,
     'Inventory identifies1856 Kellogg/Blanchard lithograph of circa1836–1849 setting, NOT1830; includes Lake House',
     'Existing IMAGE_SOURCES inventory records NYPL public-domain statement; not newly reverified here. No new4D source created.',
     'Lighthouse broad form visible, including a lower aperture. Different quarter/depic­tion date; exact-current angle still needs review before accepting its finer topology.',
     'Do not infer a new hole or height from an uncalibrated drawing alone, or call this exact-current match complete. Preserve this cross-view review obligation.'),
    ('chicago_flood_engraving_1849.jpg', None,
     'Inventory: R.N.White wood engraving of March1849 flood, published1849',
     'Existing inventory: public domain by publication; no new rights finding.',
     'Dense harbour panorama; small partially obscured tower/context. No independently resolved1835 member count, aperture setting or metric scale.',
     'Tiny/context view; do not mistake a civic roof or another distant structure for a newly identified1835 lantern.'),
    ('licensed_previews/chicago_fort_dearborn_1892_peck_hindman.jpg', None,
     'CharlesPeck painting signed1892; inventory depicts circa1830–1837 fort/lighthouse context',
     'Inventory says painting is public domain; held item is an auction-photo preview. No new redistribution or reproduction-rights finding.',
     'Retrospective broad-form corroboration. Tiny auction preview cannot establish precise rail/cage count or1835 dimensions.',
     'Retain preview/source credit; do not use the1892 creation date as a scene date or invent a new licensed copy.'),
]
for name, sid, date, rights, shows, action in specs:
    p = base / name
    rows.append({'file': str(p), 'sha256': digest(p), 'bytes': p.stat().st_size,
                 'source_id': sid, 'identity_date': date, 'rights_boundary': rights,
                 'what_is_visible_and_limited': shows, 'proposal_disposition': action})
write('ALL-REQUIRED-PICTURE-MAP.json', {
    'scope': 'All seven distinct held files behind originalT2373; source-record URLs for Castelnau/Andreas/Baker/school duplicate these files rather than adding unviewed pictures.',
    'not_a_new_reading_unit': 'Finite re-review of existing held pictures/source records and the existing image inventory; no source, identity/date or rights upgrade.',
    'pictures': rows,
    'later_light_boundary': 'Failed unfinished1831 tower (50ft/3ftwalls), completed1832 tower (40ft), and later NorthPier light are distinct. Current1859 upper bound is not proof of the1832 tower demolition date or permission to import a later tower into1835.',
    'remaining_acceptance': 'No exact-current matches verdict. The seven-picture review must remain bounded by what each image actually resolves; no feature may be marked fixed or within tolerance solely to clear the gate.',
})

for mode in ['overcast-baseline', 'directional-overcast']:
    root = OLD / 'native/docs/RESEARCH' / mode
    for name in ['camera.json', 'camera.match.json']:
        copy(root / name, 'recovered/' + mode + '/' + name)
    copy(OLD / 'reviews' / mode / 'camera-side-by-side.jpg', 'recovered/' + mode + '/camera-side-by-side.jpg')
copy(OLD / 'native/historical/old-actual-8021-side-by-side.jpg', 'recovered/historical/old-actual-8021-side-by-side.jpg')
copy(OLD / 'execution-receipt.json', 'recovered/execution-receipt.json')

camera = json.loads((OLD / 'native/docs/RESEARCH/overcast-baseline/camera.json').read_text())
camera['photo'] = '../../../../reference/images/chicago/chicago_harbor_lighthouse_1838.jpg'
camera['diagnostic_only'] = True
camera['solve'] = ('Retained provisional square-pixel Castelnau framing, not an independently calibrated historical viewing station. '
                   'The weak/partly hidden shaft toe was read at source y200±8 and finial y38±3; gallery abouty89±2. '
                   'Focal length, distance, eye and principal point reproduce the earlier actual8021 comparison rays; no model/placement changes follow. '
                   'Object-grade/eyeheight/principal-point degeneracy and the nominal40ft historical datum remain unresolved. '
                   'Publication1842 and attributed circa1838 depiction do not independently prove every July1835 fitting; transfer is inferred continuity. '
                   'Use for finite broad-form review underT3153, without turning tiny hatch/member-count, hidden-toe or camera-fit differences into a measured geometry error. '
                   'Diagnostic-only suppresses an invented historical From this spot. Overcast neutral lighting is retained exactly from the earlier baseline, not fitted to conceal model changes.')
cp = 'proposal/chicago/4d/data/reference_views/' + SID + '/castelnau-1842.json'
write(cp, camera)
copy(base / 'chicago_harbor_lighthouse_1838.jpg', 'proposal/chicago/reference/images/chicago/chicago_harbor_lighthouse_1838.jpg')
copy(APP / 'data/structures/chicago_lighthouse_1832.json', 'bindings/current-lighthouse-record.json')
copy(APP / 'data/sources/castelnau_1842_chicago_harbor.json', 'bindings/castelnau-source.json')
copy(APP / 'assets/gltf/chicago_lighthouse_1832__tower_1832.glb', 'bindings/exact-current-master.glb')
copy(OLD / 'native/assets/gltf/chicago_lighthouse_1832__tower_1832.glb', 'bindings/prior-comparison-master.glb')

paths = ['data/structures/chicago_lighthouse_1832.json', 'assets/gltf/chicago_lighthouse_1832__tower_1832.glb',
         'assets/web/chicago_lighthouse_1832__tower_1832.glb', 'data/sources/castelnau_1842_chicago_harbor.json',
         'tools/photo_match.mjs', 'tools/photo_match_group.mjs', 'renderers/web/js/keith-stone.js']
bound = {p: {'sha256': digest(APP / p), 'bytes': (APP / p).stat().st_size} for p in paths}
write('CURRENT-INPUT-BINDING.json', {
    'prepared_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_repo': str(REPO), 'source_app': str(APP),
    'observed_head': subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD']).decode().strip(),
    'actual_dev_record_confirmation': 'Read liveGitHub contents endpoint ref=dev: blobac36f2fbc1acfae4e0c1e7c3cfe741e13a07e990 equals the local canonical record. This is not a latest-whole-tree certification.',
    'bound': bound, 'photo': rows[0],
    'camera_proposal': cp, 'camera_sha256': digest(OUT / cp),
    'render_status': 'NOT RUN. Await explicit CPU lease; no browser launched by preparation.',
    'native_cli_note': '--out controls the JPEG directory, but photo_match always writes <camera>.match.json beside its input camera. Therefore the camera itself MUST be external too.',
})
print('Prepared', len(rows), 'distinct-picture mappings and external canonical-camera proposal; no source worktree writes.')
