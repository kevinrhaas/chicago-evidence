"""Optional fresh native capture, AFTER an explicit Root CPU lease.

Only this external proposal and native temporary image outputs may be written.
This does not review or accept the picture and does not modify source records.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import tempfile

OUT = Path(__file__).resolve().parent
assert os.environ.get('LIGHTHOUSE_RENDER_CPU_LEASE') == 'root-granted', 'Await explicit Root CPU lease; current capture has NOT run.'
binding = json.loads((OUT / 'CURRENT-INPUT-BINDING.json').read_text())
app = Path(binding['source_app'])
camera = OUT / binding['camera_proposal']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(camera) == binding['camera_sha256']
for name, expected in binding['bound'].items():
    assert sha(app / name) == expected['sha256'], 'Current input changed: ' + name
assert sha(Path(binding['photo']['file'])) == binding['photo']['sha256']
camera_value = json.loads(camera.read_text())
assert sha((camera.parent / camera_value['photo']).resolve()) == binding['photo']['sha256']
assert not camera.with_suffix('.match.json').exists(), 'Existing native result must be preserved; do not overwrite.'
result_dir = OUT / 'fresh-native-render'
result_dir.mkdir(exist_ok=False)
runtime = Path(tempfile.mkdtemp(prefix='lhcur-'))
assert shutil.disk_usage(runtime).free >= 512 * 1024**2
env = dict(os.environ, TMPDIR=str(runtime), OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
env.pop('GIT_NO_LAZY_FETCH', None)
command = ['python3', '/workspace/shared/run-with-reaping.py', str(result_dir / 'native-reaper.json'), '--',
           'taskset', '-c', '3', 'node', 'tools/photo_match.mjs', str(camera), '--glb',
           'assets/gltf/chicago_lighthouse_1832__tower_1832.glb', '--out', str(result_dir / 'comparisons')]
with (result_dir / 'native.log').open('x') as log:
    process = subprocess.run(command, cwd=app, env=env, stdout=log, stderr=subprocess.STDOUT)
unchanged = all(sha(app / name) == expected['sha256'] for name, expected in binding['bound'].items())
receipt = {'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': command,
           'cwd': str(app), 'exit': process.returncode, 'bound_source_inputs_unchanged': unchanged,
           'runtime_tmpdir': str(runtime), 'acceptance': 'UNREVIEWED. Native capture is not a matches verdict.',
           'source_repo_writes_requested': False,
           'native_match_path': str(camera.with_suffix('.match.json'))}
(result_dir / 'RESULT.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(process.returncode if process.returncode else (0 if unchanged else 1))
