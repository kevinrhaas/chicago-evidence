"""Read two native GLBs; compare all drawn triangle attributes/material values.

Ignore only material names, primitive/batch order, index numbering and cyclic
triangle start. Preserve winding, duplicate triangles, all vertex attributes,
all material properties other than names, and scene/node transforms.
No source repository writes or rendering.
"""
from collections import Counter
from pathlib import Path
import hashlib
import json
import struct

OUT = Path(__file__).resolve().parent
OLD = Path('/workspace/T2373-8021-lighting-runs/20261024T152428-562158Z/native/assets/gltf/chicago_lighthouse_1832__tower_1832.glb')
CURRENT = Path('/workspace/chicago/chicago/4d/assets/gltf/chicago_lighthouse_1832__tower_1832.glb')
COMPONENT = {5120: ('b', 1), 5121: ('B', 1), 5122: ('h', 2), 5123: ('H', 2), 5125: ('I', 4), 5126: ('f', 4)}
WIDTH = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT2': 4, 'MAT3': 9, 'MAT4': 16}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read(path):
    raw = path.read_bytes()
    magic, version, total = struct.unpack_from('<III', raw)
    assert magic == 0x46546C67 and version == 2 and total == len(raw)
    chunks = {}
    pos = 12
    while pos < len(raw):
        length, kind = struct.unpack_from('<II', raw, pos)
        chunks[kind] = raw[pos + 8:pos + 8 + length]
        pos += length + 8
    return raw, json.loads(chunks[0x4E4F534A]), chunks[0x004E4942]


def rows(doc, binary, number):
    a = doc['accessors'][number]
    assert 'sparse' not in a
    view = doc['bufferViews'][a['bufferView']]
    assert view.get('buffer', 0) == 0
    size = COMPONENT[a['componentType']][1] * WIDTH[a['type']]
    stride = view.get('byteStride', size)
    start = view.get('byteOffset', 0) + a.get('byteOffset', 0)
    return [binary[start + i * stride:start + i * stride + size] for i in range(a['count'])]


def surfaces(doc, binary):
    counter = Counter()
    material_usage = Counter()
    attribute_schemas = set()
    for mi, mesh in enumerate(doc['meshes']):
        assert not mesh.get('weights')
        for primitive in mesh['primitives']:
            assert primitive.get('mode', 4) == 4
            assert not primitive.get('targets') and not primitive.get('extensions')
            attrs = primitive['attributes']
            names = sorted(attrs)
            schema = [(n, doc['accessors'][attrs[n]]['componentType'], doc['accessors'][attrs[n]]['type'],
                       doc['accessors'][attrs[n]].get('normalized', False)) for n in names]
            attribute_schemas.add(json.dumps(schema, separators=(',', ':')))
            values = [rows(doc, binary, attrs[n]) for n in names]
            assert len({len(v) for v in values}) == 1
            vertices = [b''.join(v[i] for v in values) for i in range(len(values[0]))]
            if 'indices' in primitive:
                acc = doc['accessors'][primitive['indices']]
                assert acc['type'] == 'SCALAR' and not acc.get('normalized', False)
                code = COMPONENT[acc['componentType']][0]
                indices = [struct.unpack('<' + code, value)[0] for value in rows(doc, binary, primitive['indices'])]
            else:
                indices = list(range(len(vertices)))
            assert len(indices) % 3 == 0
            material = dict(doc['materials'][primitive['material']])
            label = material.pop('name', None)
            material_bytes = json.dumps(material, sort_keys=True, separators=(',', ':')).encode()
            prefix = json.dumps([mi, schema], separators=(',', ':')).encode() + b'\0' + material_bytes + b'\0'
            for i in range(0, len(indices), 3):
                v = [vertices[j] for j in indices[i:i + 3]]
                triangle = min(v[0] + v[1] + v[2], v[1] + v[2] + v[0], v[2] + v[0] + v[1])
                counter[sha(prefix + triangle)] += 1
                material_usage[label] += 1
    return counter, material_usage, sorted(attribute_schemas)


def main():
    old_raw, a, old_bin = read(OLD)
    new_raw, b, new_bin = read(CURRENT)
    assert sha(new_raw) == 'ae855793a983ff884b2653479c74fe517d3f8f2f14b6eae606f972a68373224d'
    ac, am, ass = surfaces(a, old_bin)
    bc, bm, bss = surfaces(b, new_bin)
    scene_nodes_exact = all(a.get(k) == b.get(k) for k in ('scene', 'scenes', 'nodes', 'skins', 'animations'))
    missing, added = ac - bc, bc - ac
    result = {
        'status': 'PASS' if ac == bc and scene_nodes_exact and ass == bss else 'DIFFERS',
        'scope': 'Read-only decoded drawn surfaces, not current render/app/image-gate acceptance',
        'old': {'path': str(OLD), 'sha256': sha(old_raw), 'bytes': len(old_raw), 'triangles': sum(ac.values()),
                'material_batches': len(a['materials']), 'triangles_by_material_name': dict(am)},
        'current': {'path': str(CURRENT), 'sha256': sha(new_raw), 'bytes': len(new_raw), 'triangles': sum(bc.values()),
                    'material_batches': len(b['materials']), 'triangles_by_material_name': dict(bm)},
        'scene_nodes_skins_animation_exact': scene_nodes_exact,
        'all_attribute_schemas_equal': ass == bss,
        'attribute_schemas': ass,
        'drawn_surface_counter_equal': ac == bc,
        'missing_triangles': sum(missing.values()), 'added_triangles': sum(added.values()),
        'ignored_only': ['material names', 'material/batch order', 'accessor/index numbering', 'cyclic triangle start'],
        'preserved': ['triangle winding and multiplicity', 'all vertex attribute component bytes',
                      'all PBR/alpha/doubleSided/material extras except name', 'scene and node transforms'],
        'old_counter_sha256': sha(json.dumps(sorted(ac.items()), separators=(',', ':')).encode()),
        'current_counter_sha256': sha(json.dumps(sorted(bc.items()), separators=(',', ':')).encode()),
        'no_repo_index_ref_or_asset_writes': True,
        'comparison_is_not': 'Not a same-camera current screenshot, matches verdict, derived recipe freshness or release gate',
    }
    (OUT / 'EXACT-DRAWN-SURFACE-COMPARISON.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'drawn_surface_counter_equal', 'missing_triangles', 'added_triangles', 'scene_nodes_skins_animation_exact']}))


if __name__ == '__main__':
    main()
