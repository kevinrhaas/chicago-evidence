# T-2373 — finite exact-current lighthouse enrollment proposal

This is **external preparation**, not a source edit, geometry proposal, accepted camera,
`matches` verdict, ticket claim, new release gate or demand for a new bake. Existing safe
PR landings retain priority. No browser/render was started by preparation.

## What is established

The actual current canonical lighthouse master is `ae855793a983ff884b2653479c74fe517d3f8f2f14b6eae606f972a68373224d`
(881,200 bytes). The earlier actual comparison used `9d980cc3f8a954314785c0d8e206d965d4c439d2a5aa4cfc162587ee49166d8f`
(882,276 bytes). They are not byte-identical.

`compare_drawn_surfaces.py` reads both complete native GLBs. The resulting
`EXACT-DRAWN-SURFACE-COMPARISON.json` establishes exactly **8,021 identical drawn
triangles**, including winding, duplicate multiplicity, every POSITION/NORMAL/UV/confidence
component byte, all material/PBR/alpha/double-sided values except names, and scene/node
transforms. It ignores only material names, primitive/material order, index numbering and
cyclic triangle start. Eleven material batches become ten because a duplicate stock stone
tone merges. No triangle or surface appearance parameter is added or missing. This does
not establish current screenshot equality, runtime/app acceptance or recipe freshness.

The local canonical structure record was independently compared with the live GitHub
`contents/.../chicago_lighthouse_1832.json?ref=dev` response: both are Git blob
`ac36f2fbc1acfae4e0c1e7c3cfe741e13a07e990`. The packet is based on a landed canonical
record, not an unmerged shape proposal. `CURRENT-INPUT-BINDING.json` dates the observation
and binds the exact relevant current bytes; it is not a latest-whole-tree certificate.

## Pictures and limits

`ALL-REQUIRED-PICTURE-MAP.json` accounts for the seven distinct held picture files named
by the original ticket or its cited illustration sources. The already-existing source
inventory is `chicago/reference/images/IMAGE_SOURCES.md`; source URLs that identify the
same local picture are duplicates, not additional unseen compositions.

The existing Castelnau source is the cleared governing broad-form picture: published1842,
attributed circa1838, transferred to July1835 as inferred continuity. Existing Andreas,
Baker, school, Kellogg, flood and Peck views retain their individual identity/date/rights
boundaries. In particular, the Baker source stays `check_required`, the school remains
owner-approved attributed reference use, and the auction preview creates no new
reproduction licence. No new source record or rights finding is proposed here.

The Kellogg file named `...river_mouth_1830.jpg` is inventoried as an1856 print depicting
circa1836–1849 (including the Lake House). Do not date it1830 by filename. Its visible
lower aperture deserves a bounded exact-current cross-view review; no independently
calibrated missing opening or displacement is established by this preparation.

No reviewed picture supplies an independent >0.3m new correction to prescribe. Preserve
the unresolved40ft datum: the nominal12.19m control versus reconstructed12.84968m top is
not itself a proved0.66m picture error. Do not import the unfinished1831 tower's50ft/3ft
wall specifications, or a later NorthPier/1859 light, into this1832 tower.

## Recovered comparisons and proposed camera

`recovered/` preserves both native old cameras, their honest UNREVIEWED match records,
actual JPEGs and the original native execution receipt. None is relabelled as current.

The only proposed canonical enrollment is:

`proposal/chicago/4d/data/reference_views/chicago_lighthouse_1832/castelnau-1842.json`

It keeps the old overcast camera rays and square pixels, uses the existing held picture
through a portable relative path, explains the hidden-toe/framing/date limits, and sets
`diagnostic_only: true` so an invented pose is not offered as a historical **From this spot**.
The proposal tree contains an exact copy of that held picture solely to make its relative
path resolve during an external capture. The source repository's existing picture is not
replaced. No GLB, placement, source date, height or producer field is changed.

## Next finite action, after a CPU lease

The current native CLI supports external camera files and `--out`. **`--out` alone is
insufficient:** the tool always writes `<camera>.match.json` beside its input camera.
Both camera and output must remain external until the original case is claimed and the
author deliberately adopts the reviewed result.

After Root grants the CPU3 lease, source the normal restored environment and invoke:

```sh
source /workspace/shared/resume-chicago-env.sh
LIGHTHOUSE_RENDER_CPU_LEASE=root-granted python3 /tmp/lighthouse-current-enrollment-proposal-20261026/run_exact_current_photo.py
```

The optional launcher rechecks exact relevant source inputs, pins the native capture to
CPU3, uses the existing reaping wrapper and a short external temporary directory, and
writes only external results. It refuses if the current bound inputs changed or a native
match already exists. A changed input needs a consciously rebound proposal, not a silent
replacement. There is **no lease yet** and no native result is claimed.

Review the fresh complete source/render side-by-side. Mark actual missing or wrong-shape,
count, material/colour or independently established >0.3m differences OPEN. UnderT3153,
pixel/camera-fit uncertainty, unresolved tiny details and conflicting picture readings
are not invented geometry blockers. Features an image does not resolve are NOT SHOWN;
they do not prove historical absence. Keep any genuinely visible remaining gap on the
original case and file no photo follow-up.

If adoption follows, claim/resume the original normally first. Copy the portable camera
to its intended canonical path and place the actual JPEG under
`docs/RESEARCH/photo-match/chicago_lighthouse_1832/`. The native external match's
`side_by_side` path will point outside the repository; preserve that original receipt and
normalize only the candidate's path to the adopted JPEG. Verify that master, camera and
photo hashes remain exact. Do not copy an old match or declare `matches` before actual
fresh review. The other mapped pictures still require their bounded documented review;
one Castelnau enrollment must not be called automatic seven-picture completion.

Actual published phone/desktop review and normal code/PR policy still apply when the
author finishes the original. This packet introduces no new gate, performance assertion,
geometry/API change, follow-up ticket or blanket acceptance waiver.
