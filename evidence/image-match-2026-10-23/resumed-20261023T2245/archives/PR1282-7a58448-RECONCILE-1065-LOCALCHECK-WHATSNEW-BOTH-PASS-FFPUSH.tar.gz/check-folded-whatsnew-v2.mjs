// Targeted verification of the sole served delta after dev's automatic Hogan fold.
// Complete renderer coverage on 308b is retained separately; this is not a replacement matrix.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {CHANGELOG} from '/workspace/chicago/chicago/4d/renderers/web/js/changelog.js';
const {chromium}=createRequire('/workspace/node_modules/playwright/package.json')('playwright');
const root='/workspace/chicago/site';
const out='/workspace/PR1282-current-dev-reconcile-20261024/whatsnew-actual-v2';
fs.mkdirSync(out,{recursive:true});
const write=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n');
const expected=JSON.parse(fs.readFileSync('/workspace/PR1282-current-dev-reconcile-20261024/folded-Hogan-entry-proof.json','utf8')).actual_folded;
assert.deepEqual(CHANGELOG.find(e=>e.title===expected.title),expected);
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon'};
const serverErrors=[];
const server=http.createServer((req,res)=>{
  try{
    let file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
    if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
    if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
    if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
    res.setHeader('Content-Type',mime[path.extname(file)]||'application/octet-stream');
    const stream=fs.createReadStream(file);stream.on('error',e=>{serverErrors.push(e.message);res.destroy(e);});stream.pipe(res);
  }catch(e){serverErrors.push(e.message);res.writeHead(500).end();}
});
let browser;
const results=[];
async function boot(page){
  await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:240000,polling:1000});
  await page.evaluate(async()=>{
    const a=window.__chicago4d,until=Date.now()+90000;
    while(a.welcome?.state!=='world'&&Date.now()<until){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}
    if(a.welcome&&a.welcome.state!=='world')throw Error('welcome did not enter world');
    document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.setAnimationHold(true);a.navigator.dock();await a.capture(1);
  });
}
async function openWhatsnew(page,touch){
  const opened=()=>page.waitForFunction(()=>{const r=document.getElementById('navigator')?.getBoundingClientRect();return r&&(innerWidth>620?r.width>=380:r.height>=innerHeight*.4);},null,{timeout:60000,polling:100});
  if(touch&&await page.evaluate(()=>window.__chicago4d.navigator?.level===0)){await page.locator('#nav-grip').click();await opened();}
  await page.locator('#nav-rail [data-app="settings"]').click();await opened();
  await page.waitForFunction(()=>{const p=document.getElementById('panel');return p&&!p.hidden&&!!p.closest('.nav-screen:not([hidden])');},null,{timeout:60000,polling:100});
  if(await page.evaluate(()=>window.__chicago4d.hud.tab)!=='whatsnew')await page.locator('.panel-tab[data-tab="whatsnew"]').click();
  await page.waitForFunction(()=>document.querySelector('#whatsnew .wn-entry')&&document.getElementById('help-dot')?.hasAttribute('hidden'),null,{timeout:20000});
}
try{
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
  for(const [label,width,height,touch] of [['mobile',390,780,true],['desktop',1280,800,false]]){
    const context=await browser.newContext({viewport:{width,height},hasTouch:touch,deviceScaleFactor:1});
    const errors=[],network=[],aborted=[];let page;
    try{
      page=await context.newPage();page.setDefaultTimeout(90000);
      page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});});page.on('requestfailed',r=>{const item={url:r.url(),failure:r.failure()};if(/ERR_ABORTED/.test(r.failure()?.errorText||''))aborted.push(item);else network.push(item);});
      const response=await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1812&keep-geometry=1`);assert.equal(response.status(),200);await boot(page);
      const unread=await page.evaluate(()=>({chip:!document.getElementById('help-dot')?.hasAttribute('hidden'),tab:!document.getElementById('whatsnew-dot')?.hasAttribute('hidden')}));assert(unread.chip&&unread.tab);
      await openWhatsnew(page,touch);
      const first=await page.evaluate(title=>{const host=document.getElementById('whatsnew');const matching=[...host.querySelectorAll('.wn-entry')].filter(e=>e.querySelector('.wn-title')?.textContent===title);return {entries:host.querySelectorAll('.wn-entry').length,items:host.querySelectorAll('.wn-items li').length,newest:host.querySelector('.wn-title')?.textContent||'',dated:/CT$/.test(host.querySelector('.wn-meta')?.textContent||''),cleared:document.getElementById('help-dot')?.hasAttribute('hidden'),seen:localStorage.getItem('chicago4d.whatsnew.seen'),flagged:host.querySelectorAll('.wn-entry.is-new').length,matching:matching.length,foldedItems:matching[0]?[...matching[0].querySelectorAll('.wn-items li')].map(e=>e.textContent):[],panelWidths:[host,...(function*(n){for(let p=n.parentElement;p;p=p.parentElement)yield p;})(host)].map(n=>({id:n.id,classes:n.className,clientWidth:n.clientWidth,scrollWidth:n.scrollWidth})),pageOverflow:document.documentElement.scrollWidth>innerWidth+1};},expected.title);
      write(`${label}-first.json`,first);assert(first.entries>=5&&first.items>=first.entries);assert(first.newest.length>4&&first.dated);assert(first.cleared&&Number(first.seen)>0);assert.equal(first.flagged,0);assert.equal(first.newest,expected.title);assert.equal(first.matching,1);assert.deepEqual(first.foldedItems,expected.items);assert.equal(first.pageOverflow,false);
      await page.screenshot({path:path.join(out,`${label}-folded-entry.png`)});
      await page.evaluate(()=>localStorage.setItem('chicago4d.whatsnew.seen','3'));await page.reload({waitUntil:'domcontentloaded'});await boot(page);await openWhatsnew(page,touch);
      const returning=await page.evaluate(()=>({flagged:[...document.querySelectorAll('#whatsnew .wn-entry.is-new .wn-title')].map(n=>n.textContent),total:document.querySelectorAll('#whatsnew .wn-entry').length}));write(`${label}-returning.json`,returning);assert.equal(returning.flagged.length,returning.total-3);assert(returning.flagged.length>0&&returning.flagged.includes(expected.title));
      const data=await page.evaluate(()=>{const a=window.__chicago4d;return {scene:a.scene?.id,problems:a.problems??[],reviews:[...a.registry.values()].filter(r=>r.sidecar?.review_required).map(r=>r.sidecar.id).sort()};});assert.equal(data.scene,'1812');assert.deepEqual(data.problems.filter(p=>/review_required is set/.test(p)).map(p=>p.split(':',1)[0]).sort(),data.reviews);assert.deepEqual(data.problems.filter(p=>!/provisional|PLACEHOLDER|placeholder|review_required is set/i.test(p)),[]);
      assert.deepEqual(errors,[]);assert.deepEqual(network,[]);assert.deepEqual(serverErrors,[]);results.push({viewport:label,status:'PASS',first,returning,data,errors,network,aborted});write(`${label}-result.json`,results.at(-1));console.log(`${label}: folded Hogan entry + original unread/returning-visitor assertions PASS; zero page/HTTP/hard network errors (canonical ERR_ABORTED classification retained)`);
    }catch(e){write(`${label}-failure.json`,{message:e.message,stack:e.stack,errors,network});if(page)await page.screenshot({path:path.join(out,`${label}-failure.png`)}).catch(()=>{});throw e;}
    finally{await context.close();}
  }
  write('results.json',{status:'PASS',expected,results,serverErrors,scope:'Only automatic Hogan changelog fold differs from full18-tested308b; actual published1812 boots and original relevant What-is-new assertions, both viewports. Not a new full18 matrix or source-image acceptance.'});
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));server.closeAllConnections();}
