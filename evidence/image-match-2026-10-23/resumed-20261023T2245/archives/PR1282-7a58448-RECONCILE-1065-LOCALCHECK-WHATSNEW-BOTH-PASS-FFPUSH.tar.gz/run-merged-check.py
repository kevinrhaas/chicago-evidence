from pathlib import Path
import datetime
import json
import os
import re
import shutil
import subprocess

repo = Path('/workspace/chicago')
out = Path('/workspace/PR1282-current-dev-reconcile-20261024')
env = os.environ.copy()
env.pop('CHICAGO_TICKETS_DIR', None)


def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args], env=env)


head = '308b738e6e6716a7a1411aa6c178e196eb17a719'
hogan = '6e66191ebaea1f9d4d15c7a1ac9042a341d3714b'
squash = 'cbf612cdb3c0b87c4663da99e2ae1c8a79462e84'
base = '33a99a557bd53aa637cc7173589d610f8a15f14b'
assert git('rev-parse', hogan + '^{tree}') == git('rev-parse', squash + '^{tree}')
assert git('rev-parse', 'MERGE_HEAD').decode().strip() == base
conflicts = re.findall(r'CONFLICT \(content\): Merge conflict in (.+)', (out / 'merge.stdout.log').read_text())
assert len(conflicts) == 6
proof = []
for path in conflicts:
    upstream = git('rev-parse', base + ':' + path).decode().strip()
    integrated = git('rev-parse', hogan + ':' + path).decode().strip()
    tested = git('rev-parse', head + ':' + path).decode().strip()
    resolved = git('rev-parse', ':' + path).decode().strip()
    assert upstream == integrated and tested == resolved
    proof.append(dict(path=path, upstream_and_Hogan_same_blob=upstream, tested_and_resolved_same_blob=tested))
paths = git('diff', head, '--name-only').decode().splitlines()
assert paths == ['chicago/4d/changelog.d/T-3118.json', 'chicago/4d/renderers/web/js/changelog.js']
assert not git('diff', '--name-only')
assert not git('diff', '--name-only', '--diff-filter=U')
tree = git('write-tree').decode().strip()
(out / 'exact-merge-parity.json').write_text(json.dumps(dict(
    tested_source=head, tested_tree='4cc2f87e5809f849406ca262cfdee17e3a46d10a', actual_dev=base,
    merged_tree=tree, different_paths=paths, all_other_blobs_exact=True,
    conflict_resolution='Six incoming blobs exactly equal already-integrated6e ancestor; tested308b is the authoritative superset. The exact already-folded pending entry is removed only after title/kind/items equality proof.',
    conflict_blob_proof=proof, commit_made=False, public_head_changed=False), indent=2) + '\n')
assert shutil.disk_usage('/workspace').free >= 2 * 1024 ** 3
tmp = out / 'tmp'
tmp.mkdir(exist_ok=True)
assert not str(tmp).startswith(str(repo) + '/')
env.update(TMPDIR=str(tmp), CHECK_JOBS='4', C4D_GATE_REQUIRE_READERS='1', PYTHONDONTWRITEBYTECODE='1', npm_config_cache='/workspace/shared/npm-cache', PATH='/workspace/shared/tools/usr/bin:' + env['PATH'])
assert 'CHICAGO_TICKETS_DIR' not in env
(out / 'gate-start.json').write_text(json.dumps(dict(started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), merged_tree=tree, CHICAGO_TICKETS_DIR_present=False, TMPDIR=str(tmp), readers_required=True, jobs=4), indent=2) + '\n')
print(json.dumps(dict(merged_tree=tree, changed_paths=paths, all_other_blobs_exact=True, gate='STARTED')), flush=True)
with (out / 'merged-check.log').open('w') as log:
    result = subprocess.run(['bash', 'tools/check.sh'], cwd=repo / 'chicago/4d', env=env, stdout=log, stderr=subprocess.STDOUT)
receipt = dict(exit=result.returncode, ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), tree_unchanged=git('write-tree').decode().strip() == tree, unstaged_paths=git('diff', '--name-only').decode().splitlines())
(out / 'gate-exit.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(result.returncode)
