# T-2379: the roof `none`/`flat` split is a bounded future S mate

On frozen fort builder SHA256 `fc645a66b889e8ca837520e73d2bdee4806b0892e33591099714bff10178d64e` and params `81d6a7fbb345082d60272429f0cb92dee751d3c1cbe40624017f572d6e523a5d`, only **Lake House** among the actual 25 current fort records changes geometry under the minimal split. This is a static AST/JSON conclusion, not a new output-parity test or bake. The complete per-record matrix and preimages are in ROLE-MATRIX.json.

| Actual form values | Count | Dispatch / generic `_roof` effect |
|---|---:|---|
| `none`: Lake House / magazine | 1 | `_building` calls `_roof`; the erroneous cover is removed |
| `none`: lighthouse / tower | 1 | `_tower` bypasses `_roof`; its separately generated lantern/crown is unchanged |
| `none`: first/second fort flagstaffs | 2 | `_flagstaff` bypasses `_roof` |
| `none`: first/second fort parades | 2 | `_parade` bypasses `_roof` |
| `flat`: the two second-fort root houses | 2 | `_root_house` bypasses `_roof`; its banked earth top remains |
| `gable` / `pyramid` / `shed` | 13 / 3 / 1 | `_building` calls `_roof`; branches are untouched |

The sole generic `_roof` call is `_building`, line304. `build`, line179, routes parade/root_house/tower/flagstaff to separate builders and only the remaining eight kinds to `_building`. The resolver reads `form.kind.value` and `form.roof_type.value` directly, defaulting to `quarters`/`gable`; every current row explicitly states both. The six raw `none` values are therefore **not six affected roof consumers**. No current ordinary-building `flat` row exercises the generic flat-cap branch. Future implementation should include a focused flat-building positive control; the two real flat root houses cannot prove that branch by themselves. No test group was run or prepared here.

## Smallest coherent change

Use only the local `_roof` split already described by the saved two-file proposal: `none` returns the existing `eave_z` without `add_poly`; `flat` retains the exact old polygon and return; pitched branches remain unchanged. Do not restore the old whole proposed module over the accepted fort helpers. For Lake House, `kind=magazine`, one storey, 4m wall, 24×15m footprint, no jetty/gallery/chimneys means exactly one 360m² quad/four raw vertices/two triangles disappear, while the returned height stays4m. The saved old actual trial showed132→128 vertices and66→64 triangles with identical bounds; that supports the direction, not current-fc645 native acceptance. Wall thickness, excavation, floor, scaffold, openings, placement and dates are outside this S.

A builder-byte change still invalidates **all25 shared recipes**. A later Lighthouse M touching this backend already owes that same25-family pinned refresh; the S can share it. Current static paths isolate the other24 models, including all current fort refinements, but actual stream/material/confidence/default checks and real exports remain owed. Re-audit the final composed M call graph: a new lighthouse helper must not newly route its `none` selector through generic `_roof` and accidentally lose its lantern crown. The old trial GLB cannot be installed or its checksum restamped.

The visible cap removal is established only in the historical overhead/high-oblique diagnostics. A ground-level view below the4m wall may hide it; do not substitute an unchanged street silhouette for an above-wall native inspection. Existing footprint collision remains solid and this creates no promised walkthrough/interior.

## July1835 evidence limits

The held June10,1835 Chicago Democrat notice, p2 col5, `chicago_democrat_1835_06_10#c001`, says a new house is building in Kinzie's Addition, understood to be named Lake House. The record already cites this in `function`. The held reading is **transcription-mediated**, with bracketed supplies and clipped/interleaved lines; no newspaper scan was read in this audit. It supports an active project three weeks before July1, not wall height, storeys reached, exact footprint/location, material inventory, scaffold or roof presence.

Andreas reports autumn1836 completion/opening; Martineau describes a hotel still building in June1836. Neither establishes absence of a roof in July1835. Bonnell's retrospective letter prints August25,1835, while its “forty years ago” in1876 implies1836 and Andreas's introduction says1837. This conflict remains a limit, not a measured July progress schedule. The existing one-storey/4m shell and24×15m plan are explicitly reconstructed, with a stated0–2-storey progress range. Keep those values for this bounded fix. Change `roof_type`'s current inferred confidence and overstrong note to **reconstructed**: an open shell is a chosen July worksite representation, not proved by the eventual opening date. Existing June10/Andreas sources suffice, retaining transcription limits.

Current dossier/research-note claims that no contemporary project evidence exists / the start rests only on modern compilations lag the already-cited June10 notice. Correct that narrow prose if adopting the S; do not convert the inferred January1 start into a supposedly observed date or expand into a chronology rewrite. `data/exclusions.json:lake_house_finished` excludes the completed hotel until earliest_scene1837 (the first July1 scene after an autumn1836 opening); it does not exclude the construction site. Its phrase “partial three-story shell” is not July-stage evidence and must not override the reconstructed one-storey choice.

The ticket's `chicago_fort_dearborn_river_mouth_1830.jpg` is inventory-labelled a Kellogg/Blanchard lithograph published1856, depicting ca1836–1849 with the completed hotel, second fort and1832 lighthouse. Its filename is not an1830 construction date. Do not infer an early frame, roof/staging or use T-3105's1812 first fort as a control from that later print. No new image reading/catalogue verification is claimed here; this uses the cited inventory and frozen plan. Optional later-picture card context has its own grade/source-index/date obligations and is not needed to make the consumer bugfix a small mate.

Conclusion: **ready as a narrowly scoped S implementation candidate**, paired with a later M backend refresh if selected. Not adopted, not ticketed/claimed here, no new native writer/test/build/browser/fullgate, and no accepted source-camera match. OriginalT-2379 remains OPEN/DIFFERS.
