"""Read-only AST/JSON inventory; no imports of project code and no geometry execution."""
from pathlib import Path
from collections import Counter
import ast,json,hashlib
R=Path('/tmp/chicago-log-integration/chicago/4d');O=Path(__file__).resolve().parent;P=Path('/workspace/T2379-LakeHouse-H9-T3105-plan-20261024')
sha=lambda b:hashlib.sha256(b).hexdigest()
b=R/'generators/archetypes/fort_structure.py';p=R/'generators/archetypes/fort_structure_params.py';code=b.read_bytes();params=p.read_bytes();assert sha(code)=='fc645a66b889e8ca837520e73d2bdee4806b0892e33591099714bff10178d64e';assert sha(params)=='81d6a7fbb345082d60272429f0cb92dee751d3c1cbe40624017f572d6e523a5d'
tree=ast.parse(code);functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)};roof=functions['_roof'];calls=[]
for fn,node in functions.items():
 for c in ast.walk(node):
  if isinstance(c,ast.Call) and isinstance(c.func,ast.Name) and c.func.id=='_roof':calls.append({'caller':fn,'line':c.lineno,'call':ast.unparse(c)})
assert len(calls)==1 and calls[0]['caller']=='_building'
# Read the actual kind dispatch rather than treating every roof_type=none as a generic roof call.
dispatch={};branch=next(n for n in functions['build'].body if isinstance(n,ast.If))
while isinstance(branch,ast.If):
 test=branch.test;assert isinstance(test,ast.Compare) and isinstance(test.left,ast.Attribute) and test.left.attr=='kind';kind=ast.literal_eval(test.comparators[0]);expr=branch.body[0];assert isinstance(expr,ast.Expr) and isinstance(expr.value,ast.Call);dispatch[kind]=expr.value.func.id
 branch=branch.orelse[0] if len(branch.orelse)==1 else branch.orelse
assert isinstance(branch,ast.Expr) and branch.value.func.id=='_building'
assert dispatch=={'parade':'_parade','root_house':'_root_house','tower':'_tower','flagstaff':'_flagstaff'}
pt=ast.parse(params);from_phase=next(n for n in pt.body if isinstance(n,ast.FunctionDef) and n.name=='from_phase')
resolved_defaults={}
for n in ast.walk(from_phase):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='val' and len(n.args)>=2 and isinstance(n.args[0],ast.Constant) and n.args[0].value in ('kind','roof_type'):
  resolved_defaults[n.args[0].value]=ast.literal_eval(n.args[1])
assert resolved_defaults=={'kind':'quarters','roof_type':'gable'}
manifest=json.loads((R/'assets/manifest.json').read_text())['assets'];rows=[]
for asset,item in sorted(manifest.items()):
 if item.get('archetype')!='fort_structure':continue
 record_path=R/'data/structures'/f"{item['structure_id']}.json";raw=record_path.read_bytes();record=json.loads(raw);phase=next(x for x in record['phases'] if x['id']==item['phase_id']);form=phase.get('form',{})
 def value(k):
  attr=form.get(k);return resolved_defaults[k] if attr is None else attr.get('value',resolved_defaults[k])
 kind=value('kind');roof_type=value('roof_type');helper=dispatch.get(kind,'_building');rows.append({'asset':asset,'structure':record['id'],'phase':phase['id'],'record_sha256':sha(raw),'kind':kind,'roof_type':roof_type,'kind_explicit':'kind' in form,'roof_type_explicit':'roof_type' in form,'build_dispatch':helper,'calls_generic_roof':helper=='_building','none_split_geometry_delta':helper=='_building' and roof_type=='none'})
assert len(rows)==25;affected=[x['structure'] for x in rows if x['none_split_geometry_delta']];assert affected==['lake_house_construction'];assert sum(x['calls_generic_roof'] for x in rows)==18
plan=json.loads((P/'PUBLIC-H9-fort25-registry.json').read_text());planids={x['structure_id'] for x in plan};assert {x['structure'] for x in rows}==planids
roof_ast=ast.dump(roof,include_attributes=False);old=ast.parse((P/'PUBLIC-H9-roof-function.py').read_text());assert roof_ast==ast.dump(old.body[0],include_attributes=False)
proof={'status':'PASS static dispatch/data audit only','backend_sha256':sha(code),'params_sha256':sha(params),'generic_roof_AST_sha256':sha(roof_ast.encode()),'generic_roof_AST_equal_saved_publicH9':True,'generic_roof_call_sites':calls,'actual_dispatch':dispatch,'unmatched_kind_dispatch':'_building','resolver_defaults_from_AST':resolved_defaults,'roof_totals':dict(Counter(x['roof_type'] for x in rows)),'dispatch_totals':dict(Counter(x['build_dispatch'] for x in rows)),'actual_generic_roof_callers':18,'none_generic_roof_callers':affected,'flat_generic_roof_callers':[],'non_target_current_geometry_paths_statically_unchanged':24,'all25_shared_recipe_refresh_still_owed_for_any_builder_edit':True,'scope':'Current25 canonical manifest records/phases, same identity set as frozen H9 plan. No project module/parameter/generator/native/test/Blender/browser execution. Re-audit new Lighthouse M composition if it adds generic roof callers.'}
(O/'ROLE-MATRIX.json').write_text(json.dumps({'authority':proof['backend_sha256'],'records':rows},indent=2)+'\n');(O/'AST-PROOF.json').write_text(json.dumps(proof,indent=2)+'\n')
fragments={'build':functions['build'],'_building':functions['_building'],'_roof':roof,'_tower':functions['_tower'],'_root_house':functions['_root_house']}
text=code.decode();lines=text.splitlines(True);(O/'DISPATCH-AND-ROOF-EXCERPTS.txt').write_text(''.join(f'\n# {name}, original lines {node.lineno}-{node.end_lineno}\n'+''.join(lines[node.lineno-1:node.end_lineno]) for name,node in fragments.items()))
assert b.read_bytes()==code and p.read_bytes()==params
print(json.dumps(proof,indent=2))
