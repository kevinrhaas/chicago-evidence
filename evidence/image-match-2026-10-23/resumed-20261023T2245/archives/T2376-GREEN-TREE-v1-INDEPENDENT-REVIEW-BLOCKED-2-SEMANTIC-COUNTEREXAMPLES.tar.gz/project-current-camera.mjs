import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
const THREE=await import(pathToFileURL('/tmp/chicago-log-integration/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js'));
const cameraPath='/tmp/chicago-next-model/frame-gable-cladding/preview-root/review/green-tree/andreas_1884_south.provisional.json';
const c=JSON.parse(fs.readFileSync(cameraPath));
const [W,H]=c.image_px,[cx,cy]=c.principal_px,f=c.focal_px;
const FW=2*Math.max(cx,W-cx),FH=2*Math.max(cy,H-cy);
const cam=new THREE.PerspectiveCamera(2*Math.atan(FH/2/f)*180/Math.PI,FW/FH,.1,500);
cam.setViewOffset(FW,FH,FW/2-cx,FH/2-cy,W,H);
const [u,v,y]=c.eye,t=c.yaw_deg*Math.PI/180;
cam.position.set(u,y,-v);cam.lookAt(u+Math.sin(t),y,-v-Math.cos(t));cam.updateMatrixWorld(true);
const stations=[['sash',.22],['sash',.50],['door',.80]];
const projected=stations.map(([role,at])=>{
 const p=new THREE.Vector3(7.62*at,role==='door'?1.05:1.425,-12.19).project(cam);
 return {role,fraction:at,screen_x:(p.x+1)*W/2,screen_y:(1-p.y)*H/2};
});
const ordered=[...projected].sort((a,b)=>a.screen_x-b.screen_x).map(p=>p.role);
if(ordered.join(',')!=='door,sash,sash')throw Error('unexpected projection; recheck counterexample');
fs.writeFileSync(new URL('native-three-projection.json',import.meta.url),JSON.stringify({
 scope:'CPU native Three camera/projection only; no browser/render',cameraPath,
 projected,actual_screen_left_to_right:ordered,required_source_screen_left_to_right:['sash','sash','door'],
 source_goal_passes:false,counterexample_detected:true},null,2)+'\n');
console.log('CONFIRMED v1 SCREEN order door,sash,sash — opposite source');
