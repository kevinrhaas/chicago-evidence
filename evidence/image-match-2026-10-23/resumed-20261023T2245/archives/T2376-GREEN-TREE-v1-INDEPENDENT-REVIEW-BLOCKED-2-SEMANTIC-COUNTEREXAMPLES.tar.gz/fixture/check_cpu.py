"""Existing frame accumulator adapter, bounded serial CPU proof, no bpy/export/browser."""
import pathlib,sys,types,importlib.util,dataclasses,inspect,json,hashlib,pickle,copy,math,os,collections
sys.dont_write_bytecode=True
P=pathlib.Path(__file__).parent;os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
sys.path[:0]=[str(P/'cpu-deps/generators'),str(P/'baseline/generators')];sys.modules.setdefault('bpy',types.ModuleType('bpy'))
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
oldp=load('old_frame_params',P/'baseline/generators/archetypes/frame_tavern_params.py');newp=load('new_frame_params',P/'candidate/generators/archetypes/frame_tavern_params.py')
old=load('old_frame_builder',P/'baseline/generators/archetypes/frame_tavern.py');new=load('new_frame_builder',P/'candidate/generators/archetypes/frame_tavern.py')
from common.mesh import MeshBuilder
MeshBuilder.to_object=lambda self,mats=None:(self,list(mats or []))
for module in (old,new):module.simple_material=lambda n,*a,**kw:(n,a,kw)
def raw(res):
 b,m=res;return (b.verts,b.faces,b.conf,b.mat_index,b.named,m)
def digest(x):return hashlib.sha256(pickle.dumps(x,protocol=4)).hexdigest()
a=inspect.signature(oldp.FrameTavernParams).parameters;b=inspect.signature(newp.FrameTavernParams).parameters
pos=lambda x:[(k,v) for k,v in x.items() if v.kind==inspect.Parameter.POSITIONAL_OR_KEYWORD]
assert len(pos(a))==40 and pos(a)==pos(b)
assert [(k,v) for k,v in a.items()]==[(k,v) for k,v in b.items() if k!='front_ground_layout']
assert b['front_ground_layout'].kind==inspect.Parameter.KEYWORD_ONLY and b['front_ground_layout'].default is None
assert newp.CONSUMED==oldp.CONSUMED|{'front_ground_layout'}
family=json.load(open(P/'family23.json'));defaults=[];records={}
for name,row in family.items():
 rec=json.load(open(P/'cpu-deps/data/structures'/f'{row["structure_id"]}.json'));ph=next(x for x in rec['phases'] if x['id']==row['phase_id']);records[name]=(rec,ph)
 ap=oldp.from_phase(ph,rec);bp=newp.from_phase(ph,rec);d=dataclasses.asdict(bp);assert d.pop('front_ground_layout') is None;assert d==dataclasses.asdict(ap)
 ar=raw(old.build(ap,name));br=raw(new.build(bp,name));assert ar==br,name
 defaults.append({'name':name,'raw_equal':True,'vertices':len(ar[0]),'faces':len(ar[1]),'raw_stream_sha256':digest(ar)})
 print('DEFAULT PASS',name,flush=True)
assert len(defaults)==23
rec=json.load(open(P/'candidate/data/structures/green_tree_tavern.json'));ph=rec['phases'][0];bp=newp.from_phase(ph,rec);assert bp.front_ground_layout==[.22,.5,.8]
original,oph=records['green_tree_tavern__frame_1833.glb'];clean=copy.deepcopy(rec);del clean['phases'][0]['form']['front_ground_layout'];assert clean==original
import jsonschema
jsonschema.validate(rec,json.load(open(P/'cpu-deps/data/structures.schema.json')))
# Compare every actual opening call and remove exactly the ground-front emitted
# faces before requiring complete physical/material/confidence equality elsewhere.
def observed(module,params):
 calls=[];faces=set();saved={k:getattr(module,k) for k in ('_door','_win')}
 for kind,fn in saved.items():
  def wrapper(*args,_kind=kind,_fn=fn,**kw):
   builder=args[0];start=len(builder.faces);result=_fn(*args,**kw);fields=args[2:10];calls.append((_kind,fields,kw))
   if fields[0]=='y' and fields[1]==params.depth_m and fields[2]==1 and fields[5]<params.wall_height_m/params.stories:
    faces.update(range(start,len(builder.faces)))
   return result
  setattr(module,kind,wrapper)
 try:result=module.build(params,'green_tree_tavern__frame_1833.glb')
 finally:
  for k,v in saved.items():setattr(module,k,v)
 return result,calls,faces
before,bc,bf=observed(old,oldp.from_phase(oph,original));after,ac,af=observed(new,bp)
def rest(res,omit):
 mesh,mats=res
 return ([(tuple((tuple(mesh.verts[j]),mesh.conf[j]) for j in f),mesh.mat_index[i]) for i,f in enumerate(mesh.faces) if i not in omit],mesh.named,mats)
assert rest(before,bf)==rest(after,af),'non-ground-front geometry/material/confidence changed'
def outside(calls):
 return [x for x in calls if not(x[1][0]=='y' and x[1][1]==bp.depth_m and x[1][2]==1 and x[1][5]<bp.wall_height_m/bp.stories)]
assert outside(bc)==outside(ac)
ground=[c for c in ac if c not in outside(ac)];assert len(ground)==3
windows=[c for c in ground if c[0]=='_win'];doors=[c for c in ground if c[0]=='_door'];assert len(windows)==2 and len(doors)==1
for call,at,width in zip(windows+doors,(.22,.5,.8),(.85,.85,1.20)):
 assert call[1][3:5]==(bp.width_m*at-width/2,bp.width_m*at+width/2)
assert all(c[1][-1]==1.0 for c in ground),'new reconstructed ground confidence not applied'
assert raw(before)!=raw(after),'target did not visibly change geometry'
# Target-only adoption: all 22 non-target records are absent the optional field,
# hence exactly the same already-proved default streams, not another bake.
assert all(name=='green_tree_tavern__frame_1833.glb' or records[name][1]['form'].get('front_ground_layout') is None for name in family)
bad=[False,True,1,'right',{},(),[],[.22,.5],[.22,.5,.8,1],[True,.5,.8],[float('nan'),.5,.8],[.22,float('inf'),.8],['.22',.5,.8],[.5,.22,.8],[-.1,.5,.8],[.22,.5,1],[.22,.24,.8],[.22,.5,.6]];faults=[]
for value in bad:
 try:dataclasses.replace(bp,front_ground_layout=value).validate()
 except newp.ParamError:faults.append(repr(value))
 else:raise AssertionError(('invalid control accepted',value))
for change in ({'elevation_scheme':'frontage'},{'elevation_scheme':'corner_gable'},{'wall_height_m':4.0}):
 try:dataclasses.replace(bp,**change).validate()
 except newp.ParamError:faults.append(str(change))
 else:raise AssertionError(('invalid combination accepted',change))
for value in ([True,.5,.8],['.22',.5,.8],[float('nan'),.5,.8]):
 badrec=copy.deepcopy(rec);badrec['phases'][0]['form']['front_ground_layout']['value']=value
 try:newp.from_phase(badrec['phases'][0],badrec)
 except newp.ParamError:pass
 else:raise AssertionError('data reader coerced a bad station')
# The opt-in cannot change upper floor, side entrance, ell, roof or any other
# face: real accumulated face streams above checked all unaffected faces exact.
receipt={'scope':'CPU_ONLY_NO_BLENDER_NO_CAPTURE_NO_MATCH','affinity':list(os.sched_getaffinity(0)),'legacy40_exact':True,'new_field_keyword_only_default_None':True,'default23':defaults,'adopted_non_target_default22':22,'target_only_added_form_field':True,'target_unchanged_all_faces_excluding_three_front_ground_opening_kits':True,'target_unchanged_all_other_opening_calls':True,'ground_calls_before':[(c[0],c[1]) for c in bc if c not in outside(bc)],'ground_calls_after':[(c[0],c[1]) for c in ground],'ground_faces_before_after':[len(bf),len(af)],'raw_target_before':digest(raw(before)),'raw_target_after':digest(raw(after)),'vertices_before_after':[len(before[0].verts),len(after[0].verts)],'faces_before_after':[len(before[0].faces),len(after[0].faces)],'faults_rejected':faults,'schema_PASS':True,'stock_sections_reconstructed':True,'original_T2376':'OPEN/DIFFERS','official_exports_app_native_gate':'UNRUN'}
(P/'CPU-PROOF.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PASS 40API/23default streams/22unaffected/target ground-only/schema/21faults; no export or match',flush=True)
