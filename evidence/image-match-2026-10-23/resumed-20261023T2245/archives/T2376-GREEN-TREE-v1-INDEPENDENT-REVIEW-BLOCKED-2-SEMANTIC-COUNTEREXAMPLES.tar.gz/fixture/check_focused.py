import pathlib,sys,types,importlib.util,unittest,os
sys.dont_write_bytecode=True
P=pathlib.Path(__file__).parent;os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});sys.path[:0]=[str(P/'candidate/generators'),str(P/'cpu-deps/generators')];sys.modules.setdefault('bpy',types.ModuleType('bpy'))
path=P/'candidate/tools/test_frame_tavern_picture_features.py'
for f in (P/'candidate').rglob('*.py'):compile(f.read_text(),str(f),'exec')
spec=importlib.util.spec_from_file_location('focused_picture_checks',path);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);module.ROOT=P/'candidate'
suite=unittest.TestSuite(module.PictureFeatures(n) for n in ['test_green_tree_front_ground_layout_is_sparse_and_reconstructed','test_front_ground_layout_refuses_bad_shape_spacing_or_grade'])
result=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(0 if result.wasSuccessful() else 1)
