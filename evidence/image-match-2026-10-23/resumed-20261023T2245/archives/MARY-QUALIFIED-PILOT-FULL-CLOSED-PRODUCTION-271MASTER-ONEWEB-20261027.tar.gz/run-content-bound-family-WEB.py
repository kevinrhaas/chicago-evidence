"""Prepared only. Run on its own finite CPU1 lease, never during quiet app/full4."""
from pathlib import Path
import os,subprocess,json,hashlib,datetime,importlib.util,time
O=Path(__file__).parent;A=Path('/tmp/st-mary-picture-20261025/chicago/4d');B=O/'content-bound-WEB';B.mkdir();os.sched_setaffinity(0,{1});env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');base=json.loads((O/'FAMILY-BEFORE.json').read_text());batch=json.loads((O/'genuine271-MASTER/RESULT.json').read_text());assert batch['MASTER_executed']==271 and batch['WEB_executed']==0;family=set(base['family_rows']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('native_stale',A/'tools/stale_derivatives.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);selected=[k for k in mod.stale(A)if k in family];assert selected==batch['native_content_stale_family_WEB_names']
if batch['all270_default_MASTER_byte_exact']:assert selected==['st_marys_church__frame_1833.glb']
else:assert(O/'genuine271-MASTER/ACTUAL-DEFAULT-CONTRACT-CLASSIFIED.json').exists(),'Real UV/order/default contract classification required before longerWEBphase'
# Native production uses unchanged pinned4.5.0 pipeline. No source-script or pin edits.
transform=(A/'tools/web_derivatives.sh').read_text();assert all(f'GT_{part}_VERSION="4.5.0"'in transform for part in ['CLI','CORE','FUNCTIONS','EXTENSIONS']);assert sha(A/'tools/web_derivatives.sh')==base['transform_source_sha256']
pre=json.loads((A/'assets/manifest.web.json').read_text());t=time.monotonic()
if selected:
 with(B/'native-selected-WEB.log').open('x')as log:p=subprocess.run(['bash','tools/web_derivatives.sh','--only',','.join(selected)],cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert p.returncode==0,p.returncode
post=json.loads((A/'assets/manifest.web.json').read_text());assert{k:v for k,v in pre['masters'].items()if k not in selected}=={k:v for k,v in post['masters'].items()if k not in selected}
for k in family:assert post['masters'][k]==sha(A/'assets/gltf'/k)
controls=[]
for k in family-{'st_marys_church__frame_1833.glb'}:controls.append({'asset':k,'MASTER_byte_exact':sha(A/'assets/gltf'/k)==base['file_hashes']['assets/gltf/'+k]['sha256'],'WEB_byte_exact':sha(A/'assets/web'/k)==base['file_hashes']['assets/web/'+k]['sha256']})
assert all(x['WEB_byte_exact']for x in controls)
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CONTENT_BOUND_FAMILY_WEB_COMPLETE_ALL271_BINDINGS_CURRENT','seconds':round(time.monotonic()-t,3),'native_WEB_executed_count':len(selected),'native_WEB_executed_names':selected,'MASTER_executed_count':271,'all271_from_MASTER_sha_bindings_current':True,'all270_default_WEB_byte_exact':True,'all270_default_MASTER_byte_exact':all(x['MASTER_byte_exact']for x in controls),'source_transform_sha256':sha(A/'tools/web_derivatives.sh'),'pipeline_pin':'4.5.0','no_new271_WEB_execution_claim':len(selected)!=271,'controls':controls,'canonical_photo_review_andowning_native_app_full3_PR_pending':True};(B/'RESULT.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items()if k!='controls'},indent=2),flush=True)
