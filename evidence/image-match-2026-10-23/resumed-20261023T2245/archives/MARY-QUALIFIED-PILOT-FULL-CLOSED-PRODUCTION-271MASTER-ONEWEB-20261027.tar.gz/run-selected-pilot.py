"""Prepared only. Requires source adoption and an explicitly free CPU1/browser lease."""
from pathlib import Path
import subprocess,json,hashlib,datetime,os,time
R=Path('/tmp/st-mary-picture-20261025');A=R/'chicago/4d';O=Path(__file__).parent;P=O/'pilot';P.mkdir();os.sched_setaffinity(0,{1});env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',PW_EXECUTABLE='/usr/bin/chromium')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();adopt=json.loads((O/'ADOPTED-SOURCE.json').read_text());assert all(sha(A/p)==h for p,h in adopt['owned'].items());family=json.loads((O/'FAMILY-BEFORE.json').read_text());assert len(family['family_rows'])==271
cam=A/'data/reference_views/st_marys_church/moss-engraving.json';match=cam.with_name('moss-engraving.match.json');pic=A/'docs/RESEARCH/photo-match/st_marys_church/moss-engraving-side-by-side.jpg';before={str(p):sha(p)for p in [cam,A.parent/'reference/images/chicago/chicago_st_marys_church_1843.jpg']};(P/'before-match.json').write_bytes(match.read_bytes());(P/'before-side-by-side.jpg').write_bytes(pic.read_bytes());steps=[]
def cmd(n,c):
 t=time.monotonic();print('START',n,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
 with(P/(n+'.log')).open('x')as f:r=subprocess.run(c,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT)
 steps.append({'name':n,'command':c,'exit':r.returncode,'seconds':round(time.monotonic()-t,3)});(P/'STEPS.json').write_text(json.dumps(steps,indent=2));assert r.returncode==0,(n,r.returncode)
blender='/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender';v=subprocess.check_output([blender,'--version'],env=env).decode();assert v.startswith('Blender 4.5.3');(P/'BLENDER-VERSION.txt').write_text(v)
cmd('selected-native-Mary-master',[blender,'-b','-noaudio','--threads','1','--factory-startup','--python-exit-code','1','--python',str(A/'generators/build.py'),'--','--only','st_marys_church','--wrote',str(P/'WROTE.txt')]);assert(P/'WROTE.txt').read_text().splitlines()==['st_marys_church__frame_1833.glb']
assert all(sha(A/p)==h for p,h in adopt['owned'].items());assert all(sha(Path(p))==h for p,h in before.items())
for p,row in family['file_hashes'].items():
 if p!='assets/gltf/st_marys_church__frame_1833.glb':assert sha(A/p)==row['sha256'],p
cmd('same-camera-native-photo',['node','tools/photo_match.mjs','data/reference_views/st_marys_church/moss-engraving.json'])
assert all(sha(Path(p))==h for p,h in before.items());j=json.loads(match.read_text());assert j['verdict']=='unreviewed';assert j['glb_sha256']==sha(A/'assets/gltf/st_marys_church__frame_1833.glb');assert j['camera_sha256']==sha(cam)
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SELECTED_PINNED_MASTER_AND_SAME_CAMERA_PHOTO_COMPLETE_REVIEW_PENDING','steps':steps,'MASTER_sha256':j['glb_sha256'],'camera_and_source_photo_exact':True,'all_other541_family_files_exact':True,'canon_match_verdict':j['verdict'],'source_adopted_uncommitted':True,'family270_controls_andfinal_canonical_review_WEB_native_app_full3_PR_pending':True};(P/'RESULT.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)
