from pathlib import Path
import json,hashlib,subprocess,datetime
repo=Path('/tmp/jail-picture-c6');out=Path(__file__).parent
old=json.loads((out/'OWN-PHILO-OVERLAY.json').read_text())
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo).decode().strip()
assert git('rev-parse','HEAD')==old['head']
incoming=git('rev-parse','MERGE_HEAD');assert incoming!=old['real_merge'],'Do not reapply into obsolete merge'
for p,v in old['protected_own_inputs'].items():assert hashlib.sha256((repo/p).read_bytes()).hexdigest()==v['sha256'],p
p='chicago/4d/data/structure_grades.json';d=json.loads((repo/p).read_text());indices=[i for i,r in enumerate(d['pictured']) if r.get('scene')=='1835' and r.get('structure')=='philo_carpenter_log_shop'];assert len(indices)==1;before=d['pictured'][indices[0]];d['pictured'][indices[0]]=old['pictured_row'];(repo/p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
changes=[p]
for p,paragraphs in old['doc_paragraphs'].items():
 raw=(repo/p).read_bytes();before=paragraphs['before'].encode();after=paragraphs['after'].encode()
 if after in raw:assert raw.count(after)==1
 else:
  assert raw.count(before)==1,(p,'No unique original paragraph; preserve actual merge')
  (repo/p).write_bytes(raw.replace(before,after,1))
 changes.append(p)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',*changes],cwd=repo,check=True)
r={'status':'OWNED_PHILO_OVERLAY_APPLIED_NATIVE_PENDING','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':old['head'],'incoming':incoming,'modified_existing_paths':changes,'all_protected_Philo_input_model_bytes_exact':True,'scope':'Only existing Philo pictured-rule alias and two exact existing prose paragraphs transferred. Native regenerated sidecar, remaining merge resolution, all44/full3/app and release remain required.'}
(out/'OWN-PHILO-OVERLAY-APPLIED.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
