from pathlib import Path
import os,subprocess,json,datetime,shutil,re
repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';root=Path(__file__).parent;out=root/'whole3';out.mkdir()
env=dict(os.environ)
for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR']:env.pop(k,None)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo,env=env).decode().strip()
closed=json.loads((root/'CLOSED-READY-FOR-FULL3.json').read_text());assert closed['status']=='PASS'
assert not git('ls-files','-u') and not git('diff','--no-renames','--name-only') and not git('ls-files','--others','--exclude-standard')
head,incoming,tree=git('rev-parse','HEAD'),git('rev-parse','MERGE_HEAD'),git('write-tree');assert tree==closed['tree'];base=closed['actual_dev']
remote=subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/dev','--jq','.object.sha'],env=env,text=True).strip();assert remote==base and git('rev-parse','origin/dev')==base
os.sched_setaffinity(0,{0,1,3,4});env.update(CHECK_JOBS='4',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',GITHUB_BASE_REF='dev',C4D_RULINGS_BASE=base,TMPDIR=str(root/'check-tmp'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',NPM_CONFIG_PREFIX='/tmp/T2382-runtime-prefix')
Path(env['TMPDIR']).mkdir(exist_ok=True);free=shutil.disk_usage(env['TMPDIR']).free;assert free>=1800000000
binding={'at':now(),'head':head,'merge_head':incoming,'staged_tree':tree,'actual_dev':base,'fresh_remote_dev':remote,'actual_merge_base':git('merge-base',base,'HEAD'),'affinity':sorted(os.sched_getaffinity(0)),'CHECK_JOBS':4,'tmp_free_bytes':free,'caller_startup_floor_bytes':1800000000,'native_resource_guards_unchanged':True,'scope':'Actual three native preflight questions on final complete current upstream plus Philo alias source tree; earlier f311 and intermediate whole3 remain separately dated.'}
(out/'BINDING.json').write_text(json.dumps(binding,indent=2)+'\n');steps=[]
for label,cmd in [('1-wholecheck',['bash','tools/check.sh']),('2-changelog',['node','tools/check-changelog-entry.mjs',binding['actual_merge_base'],'HEAD']),('3-ids',['node','tools/resolve_id_collisions.mjs','--base',base,'--check'])]:
 print('START',label,now(),flush=True);start=now()
 with (out/(label+'.log')).open('x') as f:code=subprocess.call(cmd,cwd=app,env=env,stdout=f,stderr=subprocess.STDOUT)
 steps.append({'name':label,'command':cmd,'started':start,'finished':now(),'exit':code});(out/'STEPS.json').write_text(json.dumps(steps,indent=2)+'\n');print('CLOSED',label,code,now(),flush=True)
guards={'head':git('rev-parse','HEAD')==head,'incoming':git('rev-parse','MERGE_HEAD')==incoming,'tree':git('write-tree')==tree,'working_bytes':not git('diff','--no-renames','--name-only'),'no_untracked':not git('ls-files','--others','--exclude-standard')}
log=re.sub(r'\x1b\[[0-9;]*m','',(out/'1-wholecheck.log').read_text(errors='replace'));footer=bool(re.search(r'^CHECK PASS — \d+ steps, none red\.$',log,re.M));passed=all(x['exit']==0 for x in steps) and all(guards.values()) and footer
result={'status':'ALL3_NATIVE_PREFLIGHT_PASS' if passed else 'ACTUAL_FAILURE_RETAINED','at':now(),'binding':binding,'steps':steps,'guards':guards,'native_footer':log.strip().splitlines()[-4:],'pending':'Actual scoped published app review and checked normal codecommit/publicFF/standardexpectedhead devmerge. Original T2382 remains OPEN/DIFFERS.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True);raise SystemExit(0 if passed else 1)
