from pathlib import Path
import subprocess,os,json,hashlib,datetime,shutil,gzip,zipfile,io
import xml.etree.ElementTree as ET
repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';out=Path(__file__).parent
head='f311c2a9b7628e22835973933c9de41b83a2b531';incoming='130dd2378a8269e8a1cf668f2eb5ddd99d89eefc';base='e5b9a0fbb145545c95079ccc7e7a3e08ffa050a5'
env=dict(os.environ)
for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR']:env.pop(k,None)
n=int(env.get('GIT_CONFIG_COUNT','0'))
for k,v in [('gc.auto','0'),('maintenance.auto','false')]:env['GIT_CONFIG_KEY_'+str(n)]=k;env['GIT_CONFIG_VALUE_'+str(n)]=v;n+=1
env['GIT_CONFIG_COUNT']=str(n);env.update(NPM_CONFIG_PREFIX='/tmp/T2382-runtime-prefix',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1');os.sched_setaffinity(0,{0,1,3,4})
def git(*a):return subprocess.check_output(['git',*a],cwd=repo,env=env).decode().strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def save(n,d):(out/n).write_text(json.dumps(d,indent=2)+'\n')
assert git('rev-parse','HEAD')==head and git('rev-parse','MERGE_HEAD')==incoming and git('rev-parse','origin/dev')==base
remote=subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/dev','--jq','.object.sha'],env=env,text=True).strip();assert remote==base
unmerged=git('diff','--no-renames','--name-only','--diff-filter=U').splitlines();assert set(unmerged)=={'chicago/4d/data/liberties.json','chicago/4d/data/sidecars/1812/sources/uses.json','chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/data/sidecars/1904/sources/uses.json','chicago/4d/docs/measurements/source_use_coverage.md'}
old=json.loads(Path('/workspace/T2382-currentdev-integration-20261026/normal-dev4220-integration/PROTECTED-INPUTS-BEFORE-NATIVE.json').read_text());names=sorted(set(git('ls-files').splitlines()))
protected_prefixes=['chicago/4d/data/structures/','chicago/4d/data/reference_views/','chicago/4d/data/sources/','chicago/4d/data/residents/','chicago/4d/generators/','chicago/4d/renderers/','chicago/prairie_1904_v1/research/images/stream-','chicago/4d/changelog.d/']
protected=set(p for p in names if any(p.startswith(q) for q in protected_prefixes));protected.update(p for p in json.loads(Path('/tmp/Wolf1336-currentMary-ending-20261027T0045/PROTECTED-AUTHORED-MODELS-BEFORE-NATIVE.json').read_text()) if (repo/p).is_file());protected.update(['chicago/4d/docs/LIBERTIES.md','chicago/4d/docs/ROADMAP.md','chicago/4d/docs/STATUS.md','chicago/4d/data/structure_grades.json','chicago/prairie_1904_v1/research/images/STORE.json']);protected.update(old['models'])
protected={p:{'bytes':(repo/p).stat().st_size,'sha256':sha(repo/p)} for p in sorted(protected) if (repo/p).is_file()}
model_paths=list(old['models']);binary_paths=old['binary_paths'];snap=out/'binary-baseline';snap.mkdir(exist_ok=True)
for p in binary_paths:
 q=snap/p;q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists():assert q.read_bytes()==(repo/p).read_bytes(),p
 else:shutil.copyfile(repo/p,q)
free=shutil.disk_usage('/tmp').free;assert free>=1800000000
binding={'status':'NATIVE_FROZEN_BEFORE_OWNING_RESOLUTION','at':now(),'head':head,'incoming':incoming,'actual_dev':base,'fresh_remote_dev':remote,'protected':protected,'model_paths':model_paths,'binary_paths':binary_paths,'unmerged_native_paths':unmerged,'tmp_free_bytes':free,'caller_startup_floor_bytes':1800000000,'known_merge_changed_paths':git('diff','--no-renames','HEAD','--name-only').splitlines(),'fold_proof':'FOLD-AND-EXACT-DUPLICATE-PROSE.json','scope':'ActualcompletecheckedWolf/current80dd/e5b9 plus ownPhilo appearance and canonicalalias. Every source/model input guarded; only nativegenerated ownership and genuinefold effects adopted. No publicnewC6/currentfull3/merge claim.'};save('BEFORE-NATIVE.json',binding);print('FROZEN',len(protected),'inputs/models',len(model_paths),'models',free,'tmpfree',now(),flush=True)
steps=[]
def run(name,cmd):
 print('START',name,now(),flush=True);start=now()
 with (out/(name+'.log')).open('x') as f:code=subprocess.call(cmd,cwd=app,env=env,stdout=f,stderr=subprocess.STDOUT)
 steps.append({'name':name,'command':cmd,'started':start,'finished':now(),'exit':code});save('NATIVE-STEPS.json',steps);print('CLOSED',name,code,now(),flush=True);assert code==0,(name,code)
def xml(n):
 text=n.text if n.text is not None and (n.text.strip() or not len(n)) else None
 return n.tag,tuple(sorted(n.attrib.items())),text,n.tail if n.tail and n.tail.strip() else None,tuple(xml(c) for c in n)
def equivalent(a,b,p):
 if p.endswith('.gz'):return gzip.decompress(a)==gzip.decompress(b),'exact decompressed stream'
 with zipfile.ZipFile(io.BytesIO(a)) as aa,zipfile.ZipFile(io.BytesIO(b)) as bb:
  if sorted(aa.namelist())!=sorted(bb.namelist()):return False,'ZIP member names differ'
  for name in aa.namelist():
   x,y=aa.read(name),bb.read(name)
   if (xml(ET.fromstring(x))!=xml(ET.fromstring(y))) if name.endswith(('.xml','.rels')) else x!=y:return False,'member differs: '+name
 return True,'all XML values/attributes and all other members exact'
def audit(label):
 changed=[p for p,v in protected.items() if sha(repo/p)!=v['sha256']];rows=[];restore={}
 for p in binary_paths:
  before=(snap/p).read_bytes();after=(repo/p).read_bytes();row={'path':p,'baseline_sha256':hashlib.sha256(before).hexdigest(),'generated_sha256':hashlib.sha256(after).hexdigest(),'byte_equal':before==after}
  if before!=after:
   raw=out/('raw-serialization-'+label)/p;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_bytes(after);eq,reason=equivalent(before,after,p);row.update(semantic_equal=eq,comparison=reason,raw_saved=str(raw))
   if eq:restore[p]=before
  rows.append(row)
 passed=not changed and all(x.get('semantic_equal',True) for x in rows);result={'status':'PASS' if passed else 'ACTUAL_AUDIT_FAILURE_RETAINED','at':now(),'protected_count':len(protected),'changed_protected_paths':changed,'model_count':len(model_paths),'all_models_byte_exact':not any(p in model_paths for p in changed),'all44_count':len(rows),'records':rows,'restored_serialization_only':[]};save('ALL44-'+label+'.json',result);assert passed,('Protected/source/binary semantic failure',changed)
 for p,b in restore.items():(repo/p).write_bytes(b);subprocess.run(['git','add','--',p],cwd=repo,env=env,check=True)
 result['restored_serialization_only']=list(restore);save('ALL44-'+label+'.json',result);print('AUDIT_PASS',label,'all44/inputs/models',now(),flush=True)
run('native-resolve',['node','tools/rederive.mjs','--resolve']);audit('after-resolve')
assert not git('ls-files','-u')
run('native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']);audit('after-package')
run('native-publish',['bash','tools/publish.sh']);audit('after-publish')
for sid,picture in [('philo_carpenter_log_shop','early-andreas-1884-sauganash'),('st_marys_church','early-moss-1884-st-marys')]:
 grade=json.loads((app/f'data/sidecars/1835/{sid}.json').read_text())['grade'];assert grade=={'value':'attested','why':'Pictured: a picture on the Images tab shows it.','pictures':[picture]},(sid,grade)
assert not git('ls-files','-u')
subprocess.run(['git','add','-u'],cwd=repo,env=env,check=True);assert not git('diff','--no-renames','--name-only') and not git('ls-files','--others','--exclude-standard')
r={'status':'PASS','at':now(),'head':head,'incoming':incoming,'actual_dev':base,'tree':git('write-tree'),'steps':steps,'all_protected_input_model_bytes_exact':len(protected),'models_exact':len(model_paths),'all44_audits_pass':True,'source_fold_changelog_exact':sha(app/'renderers/web/js/changelog.js'),'current_full3_app_codecommit_publicpush_devmerge_pending':True};save('CLOSED-READY-FOR-FULL3.json',r);print(json.dumps(r,indent=2),flush=True)
