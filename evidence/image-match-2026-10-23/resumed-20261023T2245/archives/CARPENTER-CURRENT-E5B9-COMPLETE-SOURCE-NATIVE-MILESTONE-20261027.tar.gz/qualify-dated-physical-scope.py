from pathlib import Path
import subprocess,json,hashlib,datetime
r=Path('/tmp/jail-picture-c6');o=Path(__file__).parent;old='f311c2a9b7628e22835973933c9de41b83a2b531';closed=json.loads((o/'CLOSED-READY-FOR-FULL3.json').read_text());assert closed['status']=='PASS';tree=closed['tree']
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=r)
def ls(ref):
 out={}
 for row in git('ls-tree','-rz',ref).split(b'\0'):
  if row:m,p=row.split(b'\t',1);out[p.decode()]=m.split()[2].decode()
 return out
before,after=ls(old),ls(tree);changed=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
models=[p for p in changed if p.endswith('.glb')];expect={f'chicago/4d/assets/{kind}/{sid}.glb' for kind in ['gltf','web'] for sid in ['dent_house_1823_prairie__as_mapped_1904','doane_house_1827_prairie__as_mapped_1904','pullman_house_1729_prairie__as_mapped_1904','pullman_house_1729_prairie_conservatory__as_standing_1904']};assert set(models)==expect,models
renderer=[p for p in changed if p.startswith('chicago/4d/renderers/')];assert renderer==['chicago/4d/renderers/web/js/changelog.js'],renderer
sides=[p for p in changed if p.startswith('chicago/4d/data/sidecars/1835/') and '/sources/' not in p];known=set()
objects=Path('/workspace/chicago/.git/objects')
for ix in (objects/'pack').glob('*.idx'):
 with ix.open('rb') as f:
  result=subprocess.run(['git','show-index'],stdin=f,stdout=subprocess.PIPE,check=True)
 known.update(l.split()[1].decode() for l in result.stdout.splitlines())
def blob(oid):
 assert oid in known or (objects/oid[:2]/oid[2:]).exists(),('No unknown promisor blob read',oid)
 return git('cat-file','blob',oid)
def diff(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):return sum((diff(a.get(k),b.get(k),path+'/'+k) for k in sorted(set(a)|set(b))),[])
 if isinstance(a,list):
  if len(a)!=len(b):return [path]
  return sum((diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [path]
rows=[]
for p in sides:
 assert p in before and p in after,p;a=json.loads(blob(before[p]));b=json.loads(blob(after[p]));keys=diff(a,b);rows.append({'path':p,'changed_JSON_fields':keys,'old_blob':before[p],'current_blob':after[p]});assert p.endswith(('philo_carpenter_log_shop.json','st_marys_church.json')),p;assert all(k.startswith(('/grade/why','/grade/pictures')) for k in keys),rows[-1]
philo='chicago/4d/assets/web/philo_carpenter_log_shop__log_1832.glb';assert before[philo]==after[philo];record='chicago/4d/data/structures/philo_carpenter_log_shop.json';assert before[record]==after[record]
result={'status':'EXACT_PHYSICAL_AND_RENDERER_SCOPE_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'dated_baseline_commit':old,'current_checked_candidate_tree':tree,'source_entries':len(after),'changed_model_paths':models,'all_other_model_bytes_exact_by_blob_id':True,'renderer_source_changes_only_actual_incoming_changelog':renderer,'1835_non_source_sidecar_changes':rows,'target_Philo_record_camera_photo_master_WEB_same_as_dated_qualified_f311':all(before[p]==after[p] for p in ['chicago/4d/data/structures/philo_carpenter_log_shop.json','chicago/4d/data/reference_views/philo_carpenter_log_shop/andreas-1884.json','chicago/4d/data/reference_views/philo_carpenter_log_shop/andreas-1884.match.json','chicago/4d/assets/gltf/philo_carpenter_log_shop__log_1832.glb',philo]),'scope':'Dated f311 actual1835 Normal/ByGrade/ground and other unchanged consumers retain their original date/binding; final Photos/Sources/Research alias behavior is tested freshly at bothviewports. Four1904 incoming pairs belong to actuallyqualifiedcurrentupstream; no globalworld/full18/currentalltimings equality claimed. Full3 currentnative and checkedcommit/publicmerge remain separate.'};(o/'DATED-PHYSICAL-CONSUMER-SCOPE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
