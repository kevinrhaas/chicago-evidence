from pathlib import Path
import json,hashlib,subprocess,datetime,re
repo=Path('/tmp/jail-picture-c6');out=Path(__file__).parent
# Preserve bytes, including an inherited non-UTF8 span in ROADMAP shared by HEAD/dev.
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo)
def resolve(raw):
 lines=raw.splitlines(keepends=True);result=[];hunks=[];i=0
 while i<len(lines):
  if not lines[i].startswith(b'<<<<<<< '):result.append(lines[i]);i+=1;continue
  start=i;i+=1;left=[]
  while not lines[i].startswith(b'======='):left.append(lines[i]);i+=1
  i+=1;right=[]
  while not lines[i].startswith(b'>>>>>>> '):right.append(lines[i]);i+=1
  i+=1;a=b''.join(left);b=b''.join(right)
  hunks.append({'ours':a,'theirs':b,'start':start})
  # Every non-empty author chunk is retained in order; exact repeated Jail blocks
  # introduced by different historical placement are removed below, only as wholes.
  result.extend(left);result.extend(right)
 return b''.join(result),hunks
records=[];changed=[]
for p in ['chicago/4d/docs/LIBERTIES.md','chicago/4d/docs/ROADMAP.md','chicago/4d/docs/STATUS.md']:
 raw=(repo/p).read_bytes();new,hunks=resolve(raw);removed=[]
 for h in hunks:
  for side in ['ours','theirs']:
   chunk=h[side]
   # These are exact old Jail paragraphs/header preserved at both parents' distinct
   # insertion positions. Keep the first full occurrence, remove only a later byte-
   # identical copy; no unique words or dated failure record is discarded.
   if chunk.strip() and b'T-2380' in chunk and b'T-2382' not in chunk and b'T-2386' not in chunk:
    if new.count(chunk)==2:
     first=new.find(chunk);last=new.find(chunk,first+len(chunk));assert last>=0
     new=new[:last]+new[last+len(chunk):];removed.append({'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest(),'reason':'Exact whole Jail block repeated at distinct historical insertion positions; first full block retained'})
 # For STATUS the larger ours chunk also contains an exact Jail tail after the own
 # Carpenter paragraphs. Its block is the first non-empty incoming-only hunk.
 for h in hunks:
  chunk=h['theirs']
  if p.endswith('STATUS.md') and not h['ours'].strip() and b'### T-2380 ' in chunk and new.count(chunk)==2:
   first=new.find(chunk);last=new.find(chunk,first+len(chunk));new=new[:last]+new[last+len(chunk):];removed.append({'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest(),'reason':'Exact full repeated Jail status block retained once'})
 assert not any(line.startswith((b'<<<<<<< ',b'>>>>>>> ')) for line in new.splitlines())
 for h in hunks:
  for side in ['ours','theirs']:
   for line in h[side].splitlines():
    if line.strip():assert line in new,(p,'Lost unique authored line',line[:100])
 (repo/p).write_bytes(new);changed.append(p);records.append({'path':p,'resolved_hunks':len(hunks),'whole_exact_duplicate_blocks_removed':removed,'all_nonblank_authored_conflict_lines_preserved':True,'sha256':hashlib.sha256(new).hexdigest()})
p='chicago/prairie_1904_v1/research/images/STORE.json';a=json.loads(git('show',':2:'+p));b=json.loads(git('show',':3:'+p));assert all(a[k]==b[k] for k in set(a)|set(b) if k not in ['files','bytes']);common=set(a['files'])&set(b['files']);assert all(a['files'][k]==b['files'][k] for k in common);result=dict(b);result['files']={k:(a['files']|b['files'])[k] for k in sorted(set(a['files'])|set(b['files']))};result['bytes']=sum(v['bytes'] for v in result['files'].values());assert all(result['files'][k]==v for d in [a,b] for k,v in d['files'].items());(repo/p).write_text(json.dumps(result,indent=1,ensure_ascii=False)+'\n');changed.append(p);records.append({'path':p,'source2_rows':len(a['files']),'source3_rows':len(b['files']),'common_rows_all_exact':len(common),'union_rows':len(result['files']),'bytes':result['bytes'],'own_Sauganash_and_incoming_Moss_preserved':all(k in result['files'] for k in ['early-andreas-1884-sauganash.jpg','early-andreas-1884-sauganash-thumb.jpg','early-moss-1884-st-marys.jpg','early-moss-1884-st-marys-thumb.jpg'])})
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',*changed],cwd=repo,check=True)
r={'status':'AUTHORED_DOCS_EXACT_LINES_AND_STORE_WHOLE_ROW_UNION_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD').decode().strip(),'incoming':git('rev-parse','MERGE_HEAD').decode().strip(),'records':records,'native_generated_conflicts_left':git('diff','--no-renames','--name-only','--diff-filter=U').decode().splitlines(),'scope':'Source author conflict resolution only. No current native/full3/app qualification claim. Own Philo alias overlay and folded duplicate entry check remain separate.'};(out/'AUTHORED-MERGE-RESOLUTION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
