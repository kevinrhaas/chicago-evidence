# T-2374 finite camera/form bracket — external preparation only

The unchanged current Cobweb MASTER is `af1f33c0f5d75fc8c40e6cbb589adfd7d29d551572c2775e236bb260f6ee561f` (139,824 bytes), exactly the model in the actual PR1260 source comparison. Its current WEB is31,804 bytes, SHA256 `49cfcb869c0a39bd936c2c22428179538c37c5a380b9f27c53fab019719b8dcd`. The record genuinely builds five compound rooms and two outer-wing heads; the old ticket/dossier bounding-box limitation is historical. No model export or geometry change is needed to test a new camera against this exact already-generated model.

I directly viewed the full original1920×1042 source sheet and the old actual side-by-side. The defensible **conditional** subject is the small isolated gabled house left of the poplar group, above the printed Agency-House key. The key has no leader, and its alignment does not prove identity with the five-part residence described in Wau-Bun. The model's composition has textual support; every arrangement/dimension/roof/opening/head and July1835 persistence remains inferred/reconstructed. Do not discard the textual composition or move its geographic placement just to force the ambiguous tiny drawing.

The existing specific illustration record `kinzie_1857_chicago_1831_panorama` retains its public-domain basis from the existing nineteenth-century source inventory. This preparation adds no new rights or edition finding, acquires no licensed surrogate, and does not borrow the text book's identity to silently attest the illustration. The existing independently inspected Wentworth1881 pages86–87/key and Hubbard criticism are useful dated context, not new research performed here. No original source/record was edited.

## Two finite diagnostic poses

The old188.3° preview is nearly straight-front. The source house reads as a gable on the left with a receding side on the right. Two bounded end-oblique possibilities,70° and110°, view the near wing end/rear and end/front respectively. They are alternatives for one conditional local composition, not two historical camera stations or a global panorama solve.

Both preserve focal2200px, pixel-aspect1, ordinary perspective, all geometry and the complete source image. A simple full-vertex projection fits only the model's horizontal extent to the approximate manually read source rectangle `[1403,346,1490,401]` and anchors the bottom at401. This is not corner measurement or metric calibration. **No independent vertical rescaling, camera pitch trick, arbitrary source crop or pixel edit is used.** Whole-asset projected height is about40.29/41.17px against the source's approximate55px. That possible large aspect discrepancy is a reason to inspect one finite actual bracket, not a camera-only pass or authority to invent geometry.

`PURE-PROJECTION.json` records all values, using actual float32 positions from the native GLB with a strict identity-node-transform guard. It does not model visibility, native materials or occlusion. `cameras/*.json` preserve these limits, set `diagnostic_only:true` and remain external. A hypothetical canonical adoption would need its own real native capture after changing the photo path/camera bytes. `PROPOSED-NOT-PICTURED-RULING.json` supplies an explicit source-identity rule to retain the current inferred grade if such a diagnostic is ever enrolled; it is not applied.

## Actual execution, only after the root CPU/GPU grant

`run_camera_trial.py` is syntax checked and **UNRUN**. Its sole action is the two native photo_match captures on the frozen current MASTER. It requires `COBWEB_CAMERA_LEASE=explicit-root-after-fourcase-gate`, a new `--out` directory, source/static/model preimage equality, full immutable packet verification and the unchanged512MiB native scratch guard. It copies the small frozen runtime into that new output, so this preparation remains immutable. It runs each actual native command through the all-children reaper and keeps raw PNG, tool match, side-by-side, stdout and exit/cleanup receipts. Native tool scripts and their twelve statically imported renderer modules are frozen byte-exact; no renderer or tool code is changed. Full app, data population and browser profile directories are not copied.

Example after the actual root lease, with source still exact:

```
COBWEB_CAMERA_LEASE=explicit-root-after-fourcase-gate python3 /workspace/cobweb-finite-camera-prep-20261029/run_camera_trial.py --out /workspace/T2374-finite-native-camera-trial-20261029 --cpus 0,1
```

If source/renderer inputs have moved, the helper refuses. Review which consumer changed and prepare a newly named, accurately bound packet instead of overriding the guard. The native photo tool will generate unreviewed matches beside the copied cameras in the new output; do not copy an old verdict onto them.

After capture, directly inspect both results against the unaltered held sheet, then stop this finite bracket. ApplyT3153 to actual visible form. An approximate full-box mismatch may be camera/subject/occlusion rather than a permissible new model dimension. The tiny picture cannot supply centimetre controls, hidden tails, detailed joints or authentic monochrome colour. Research/identity/date uncertainty belongs in notes/rulings and is not itself an open geometry defect. If the actual form cannot be accepted, keep originalT2374 open with its concrete visible discrepancy and next supported modelling choice; create no new photo follow-up ticket.

This packet makes no claim, canonical camera, source/grade/scene/liberty change, browser capture, native export, app review, full gate, code commit, PR, merge or original completion. The original remains OPEN/M. School's accepted external candidate and checkpoint625 remain intact and higher-confidence work; this finite bracket does not displace its adoption.
