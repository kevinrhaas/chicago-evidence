from pathlib import Path
import copy,datetime,hashlib,json,math,os,re,shutil,struct,subprocess
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');assert not(P/'INPUTS.json').exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(P/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def copyin(src,rel):
 dst=P/rel;dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();shutil.copyfile(src,dst);assert sha(src)==sha(dst);return {'source':str(src),'relative_path':rel,'bytes':src.stat().st_size,'sha256':sha(src)}
selected=[(A/'assets/gltf/cobweb_castle__log_1820.glb','runtime/assets/gltf/cobweb_castle__log_1820.glb'),(A/'assets/web/cobweb_castle__log_1820.glb','runtime/assets/web/cobweb_castle__log_1820.glb'),(A.parent/'reference/images/chicago/chicago_fort_dearborn_1831_1.jpg','source.jpg'),(A/'data/structures/cobweb_castle.json','CURRENT-STRUCTURE.json'),(A/'data/sources/kinzie_1857_chicago_1831_panorama.json','CURRENT-SOURCE.json'),(A/'docs/RESEARCH/cobweb_castle.md','CURRENT-DOSSIER.md')]
selected +=[(A/'tools'/n,'runtime/tools/'+n)for n in ['photo_match.mjs','photo_match_group.mjs','photo_match_flora.mjs','photo_match_enclosures.mjs']]
rows=[copyin(*x)for x in selected];assert rows[0]['sha256']=='af1f33c0f5d75fc8c40e6cbb589adfd7d29d551572c2775e236bb260f6ee561f';assert rows[2]['sha256']=='624d8f1f52a75bf30653e8cbf37a388478b0ddf5a02f1fadf727cf2144b84c3f'
# Copy only known statically imported photo renderer closure, verifying against current source.
old=json.loads(Path('/workspace/T2372-native-fit-trial-20261029/STATIC-RENDERER-BINDINGS.json').read_text())
for row in old['bindings']:rows.append(copyin(A/row['relative_path'],'runtime/'+row['relative_path']))
# Read exact native GLB positions. This is pure projection, not a native render.
b=(P/'runtime/assets/gltf/cobweb_castle__log_1820.glb').read_bytes();length,kind=struct.unpack_from('<II',b,12);j=json.loads(b[20:20+length]);offset=20+length;blen,bkind=struct.unpack_from('<II',b,offset);binary=b[offset+8:offset+8+blen];assert bkind==0x004e4942
assert len(j['nodes'])==1 and set(j['nodes'][0])<= {'extras','mesh','name'},'Refuse unhandled scene transform'
vertices=[]
for prim in j['meshes'][0]['primitives']:
 acc=j['accessors'][prim['attributes']['POSITION']];assert acc['componentType']==5126 and acc['type']=='VEC3';view=j['bufferViews'][acc['bufferView']];base=view.get('byteOffset',0)+acc.get('byteOffset',0);stride=view.get('byteStride',12)
 for k in range(acc['count']):
  x,y,z=struct.unpack_from('<fff',binary,base+k*stride);vertices.append((x,-z,y))
box=[1403.,346.,1490.,401.];cx0=(box[0]+box[2])/2;targetW=box[2]-box[0];projections=[]
(P/'cameras').mkdir()
for name,yaw in [('end-rear-70',70.),('end-front-110',110.)]:
 t=math.radians(yaw);s,c=math.sin(t),math.cos(t);f=2200.;h=2.;D=330.
 def proj(dist):
  eye=(6.5-dist*s,4.5-dist*c,h);points=[]
  for U,V,Z in vertices:
   du,dv=U-eye[0],V-eye[1];dep=du*s+dv*c;assert dep>0
   points.append((f*(du*c-dv*s)/dep,-f*(Z-h)/dep))
  return eye,points
 for _ in range(5):
  eye,pts=proj(D);D*= (max(x for x,y in pts)-min(x for x,y in pts))/targetW
 eye,pts=proj(D);px=cx0-(min(x for x,y in pts)+max(x for x,y in pts))/2;py=box[3]-max(y for x,y in pts);pred=[min(x+px for x,y in pts),min(y+py for x,y in pts),max(x+px for x,y in pts),max(y+py for x,y in pts)]
 cam={'structure_id':'cobweb_castle','source_id':'kinzie_1857_chicago_1831_panorama','photo':'../source.jpg','image_px':[1920,1042],'principal_px':[px,py],'focal_px':f,'eye':list(eye),'yaw_deg':yaw,'sky':'overcast','diagnostic_only':True,'solve':{'status':'finite_conditional_local_house_diagnostic_PREPARED_UNRENDERED','subject':'Conditional identification of the small isolated gabled house left of the poplar group, above the Agency-House key. The printed key has no leader; this does not establish that the five-part Cobweb model is the pictured building.','pose':'One of a finite two-pose end-oblique bracket:70deg views the near wing end/rear;110deg views the near wing end/front. The old188.3deg near-front framing did not test the pictured gable-left/long-side-right composition. Both are reconstructed local diagnostic alternatives, not two historical stations.','fit':'Fit only current whole-asset horizontal projected bounds to a manually read approximate image rectangle [1403,346,1490,401], with bottom anchored at401. No vertical scaling, pixel-aspect distortion, model translation, survey change or geometry edit. Bounds include hidden vertices; silhouette and occlusion still require actual native capture.','scale':'The2200px focal choice and numerical distance are a degenerate reconstructed framing convention, not metres recovered from the retrospective wood engraving. No metric survey camera, residual or identity follows.','source':'Specific existing public-domain kinzie_1857_chicago_1831_panorama illustration record; printed Wau-Bun1857 credit is not a new publication finding. Existing1881 Wentworth annotation and Hubbard criticism remain context; no independent new source/rights retrieval.','limits':'No render/pass/matches verdict. Artist/retrospective scene/subject/1835 continuity uncertainty is recorded separately and must not be converted into a visible defect. Material, roof/wall/stack counts and camera disagreement require direct T3153 review. Native neutral/master review omits app procedural surfaces and terrain. No historic From this spot, attested grade or occupation/person/removal narration.','bounds_prediction':pred}}
 save('cameras/'+name+'.json',cam);projections.append({'view':name,'yaw_deg':yaw,'distance_convention_m':D,'predicted_all_vertex_bbox_px':pred,'source_box_approx_px':box,'predicted_height_px':pred[3]-pred[1],'source_height_approx_px':box[3]-box[1],'interpretation':'PURE geometric bound only. A vertical silhouette mismatch remains possible; no camera-only acceptance is inferred.'})
save('PURE-PROJECTION.json',{'status':'PURE_FULL_VERTEX_PROJECTIONS_ONLY_NO_NATIVE_CAPTURE','native_position_vertices':len(vertices),'source_box_approximate_manual_read':box,'two_finite_poses':projections})
save('PROPOSED-NOT-PICTURED-RULING.json',{'operation':'append to not_pictured only if a future actual accepted diagnostic camera using thissource is enrolled; preserve everyotherrow','row':{'scene':'1835','structure':'cobweb_castle','picture':'kinzie_1857_chicago_1831_panorama','why':'Conditional local form comparison against the small isolated house above the unleadered Agency-House key. The retrospective panorama does not securely identify that small house as the five-part residence described in Wau-Bun or establish its form on1835-07-01. The diagnostic camera is reconstructed and is not a historical station or identity proof; preserve the existing inferred whole-structure grade. This ruling does not deny that an agency house existed or identify another pictured building.'}})
save('INPUTS.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FROZEN_CURRENT_MASTER_AND_CLEARED_PANORAMA_TWO_FINITE_CAMERAS_UNRUN','bindings':rows,'current_model_equals_old_actual_PR1260_cobweb_MASTER':True,'native_export_needed_for_camera_only_trial':False,'source_record_and_geometry_unchanged':True,'original_T2374':'OPEN; unclaimed by this preparation'})
print(json.dumps({'status':'PREPARED_UNRENDERED','members_frozen':len(rows),'frozen_bytes':sum(x['bytes']for x in rows),'predictions':projections},indent=2))
