from pathlib import Path
import datetime as dt,hashlib,json,os,subprocess,sys,time

OUT=Path(__file__).resolve().parent
CLONE=Path('/tmp/tremont-T2385-tickets-20261023T2247')
CONTEXT=Path('/tmp/tremont-T2385-claim-context/chicago/4d')
LIVE_TOOL=Path('/workspace/chicago/chicago/4d/tools/ticket.mjs')
expected_doc=json.loads((OUT/'EXPECTED-OWN-MARKER.json').read_text())
expected=expected_doc['expected']
expiry=dt.datetime.fromisoformat(expected['claimed_at'].replace('Z','+00:00'))+dt.timedelta(hours=3)
now=lambda:dt.datetime.now(dt.timezone.utc)
state={'status':'WAITING_FOR_ACTUAL_NATIVE_EXPIRY','pid':os.getpid(),'expected_marker':expected,'native_expiry':expiry.isoformat(),'not_before_utc':(expiry+dt.timedelta(seconds=2)).isoformat(),'started_utc':now().isoformat(),'force_used':False,'manual_timestamp_or_marker_edit':False,'code_migration_target':None}
def save():
 state['heartbeat_utc']=now().isoformat()
 (OUT/'WATCH-STATE.json').write_text(json.dumps(state,indent=2)+'\n')
def run(argv,cwd,log):
 with(OUT/log).open('x')as stream:
  child=subprocess.Popen(argv,cwd=cwd,env={**os.environ,'CHICAGO_TICKETS_DIR':str(CLONE)},stdout=stream,stderr=subprocess.STDOUT)
  state['active_child_pid']=child.pid;save();code=child.wait()
 state.pop('active_child_pid',None);save();return code
def read_marker():
 ticket=next(CLONE.rglob('T-3082-*.md'))
 fields=dict(line.split(': ',1)for line in ticket.read_text().split('---',2)[1].strip().splitlines()if': 'in line)
 return ticket,fields,{key:fields[key]for key in expected}
assert not(OUT/'WATCH-STATE.json').exists(),'Do not overwrite another watcher or attempt'
save()
try:
 # No long blocking tool call: this background controller sleeps in <=30s intervals.
 while now()<expiry+dt.timedelta(seconds=2):
  save();time.sleep(min(30,max(.1,(expiry+dt.timedelta(seconds=2)-now()).total_seconds())))
 assert now()>=expiry
 for path in [CONTEXT/'tools/ticket.mjs',LIVE_TOOL]:
  assert hashlib.sha256(path.read_bytes()).hexdigest()==expected_doc['tool_sha256'],'Native ticket tool changed: stop for review, no claim'
 state['status']='CHECKING_FRESH_REMOTE_OWNER';save()
 code=run(['git','pull','--rebase','--quiet','origin','main'],CLONE,'fresh-pull-before.log');state['pull_before_exit']=code;save();assert code==0,'Cannot establish fresh remote owner; stop without claim'
 ticket,fields,marker=read_marker();state['actual_marker_before']=marker
 state['before_remote_main']=subprocess.check_output(['git','-C',str(CLONE),'rev-parse','HEAD'],text=True).strip()
 state['age_hours_at_native_call']=(now()-dt.datetime.fromisoformat(marker['claimed_at'].replace('Z','+00:00'))).total_seconds()/3600;save()
 assert marker==expected,'Owner/state/marker changed: STOP, never steal even if another marker is expired'
 assert state['age_hours_at_native_call']>=3,'Actual normal expiry has not elapsed'
 state['status']='NORMAL_SAME_OWNER_EXPIRED_CAS_CLAIM';save()
 argv=['node','tools/ticket.mjs','claim','T-3082','--by','Codex Tremont roof continuation 10/23/2026']
 state['command']=argv;code=run(argv,CONTEXT,'normal-claim.log');state['claim_exit_code']=code;save();assert code==0,'Normal claim failed; no force or automatic retry'
 ticket,after,after_marker=read_marker();state['after_local_marker']=after_marker
 claim_commit=subprocess.check_output(['git','-C',str(CLONE),'rev-parse','HEAD'],text=True).strip();state['claim_commit']=claim_commit;save()
 assert after_marker['id']=='T-3082'and after_marker['state']=='claimed'
 assert after_marker['claimed_by'].startswith('Codex Tremont roof continuation 10/23/2026')
 new_at=dt.datetime.fromisoformat(after_marker['claimed_at'].replace('Z','+00:00'));assert new_at>=expiry and new_at>dt.datetime.fromisoformat(expected['claimed_at'].replace('Z','+00:00'))
 state['status']='VERIFYING_REMOTE_READBACK';save()
 code=run(['git','pull','--rebase','--quiet','origin','main'],CLONE,'fresh-pull-readback.log');state['pull_readback_exit']=code;save();assert code==0,'Claim command succeeded but independent remote readback failed; do not claim verified'
 _,_,remote_marker=read_marker();state['remote_marker_readback']=remote_marker;save();assert remote_marker==after_marker,'Remote marker changed after claim: stop, no retake'
 assert subprocess.run(['git','-C',str(CLONE),'merge-base','--is-ancestor',claim_commit,'HEAD']).returncode==0,'Remote history does not contain our claim commit'
 state.update(status='PASS_NORMAL_EXPIRED_OWN_CAS_REFRESH_REMOTE_READBACK',new_native_expiry=(new_at+dt.timedelta(hours=3)).isoformat(),readback_main=subprocess.check_output(['git','-C',str(CLONE),'rev-parse','HEAD'],text=True).strip(),remote_readback_verified=True)
 (OUT/'T-3082-readback.md').write_bytes(ticket.read_bytes())
except BaseException as exc:
 state.update(status='STOPPED_NO_FORCE_OR_RETRY',error=str(exc));raise
finally:
 state['finished_utc']=now().isoformat();save()
 files=[]
 for file in sorted(OUT.iterdir()):
  if file.is_file()and file.name!='CLOSED-MANIFEST.json':
   data=file.read_bytes();files.append({'path':file.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 manifest={'status':'CLOSED operational claim guard/normal attempt only; no source/head/heavy/PR action','outcome':state['status'],'closed_utc':now().isoformat(),'files':files,'file_count':len(files),'total_bytes':sum(row['bytes']for row in files)}
 (OUT/'CLOSED-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(state,indent=2))
