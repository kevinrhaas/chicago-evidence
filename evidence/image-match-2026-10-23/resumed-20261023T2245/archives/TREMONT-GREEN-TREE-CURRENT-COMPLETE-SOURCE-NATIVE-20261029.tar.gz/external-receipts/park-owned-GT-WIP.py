from pathlib import Path
import subprocess,os,json,hashlib,datetime,shutil,tempfile
repo=Path('/tmp/chicago-green-tree-integration');out=Path('/workspace/T2385-resume-20261029/GT-DONOR-PARKING');out.mkdir(exist_ok=False)
env=dict(os.environ);h=lambda b:hashlib.sha256(b).hexdigest()
def g(*a,env=env):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo,env=env)
head=g('rev-parse','HEAD').decode().strip();assert head=='a9c5bd4a9715e4d5634c536d0efcd516ea9c3f01'
assert not g('ls-files','-u');tracked=g('diff','--name-only','HEAD','-z').decode().split('\0');tracked=[p for p in tracked if p];untracked=[p for p in g('ls-files','--others','--exclude-standard','-z').decode().split('\0')if p];assert untracked==['chicago/4d/changelog.d/T-2376.json'];assert len(tracked)==20
patch=g('diff','--binary','--full-index','HEAD','--');(out/'GT-complete-owned-tracked-WIP.patch').write_bytes(patch)
entries=[]
for p in tracked+untracked:
 b=(repo/p).read_bytes();entries.append({'path':p,'bytes':len(b),'sha256':h(b),'untracked':p in untracked})
for p in untracked:
 q=out/'untracked'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/p,q)
private=dict(env,GIT_INDEX_FILE=str(out/'verification.index'))
g('read-tree',head,env=private);subprocess.run(['git','apply','--cached','--binary',str(out/'GT-complete-owned-tracked-WIP.patch')],cwd=repo,env=private,check=True);tree=g('write-tree',env=private).decode().strip()
checkpoint=g('stash','create','T-2376 complete owned pre-current baseline WIP 2026-10-29').decode().strip();assert checkpoint
assert g('rev-parse',checkpoint+'^{tree}').decode().strip()==tree
g('update-ref','refs/checkpoints/t2376-complete-pre-current-20261029',checkpoint,'0'*40)
before={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'tracked_paths':tracked,'untracked_paths':untracked,'all_current_members':entries,'patch_sha256':h(patch),'verified_tracked_tree':tree,'private_stash_checkpoint':checkpoint,'stash_ref':'refs/checkpoints/t2376-complete-pre-current-20261029','scope':'Owned GT checkout only; complete tracked patch privately reconstructed exactstash tree, untracked entry separately copied. OldcorrectedTGTdonor untouched. This is private WIP recovery, not a qualifiedcodecommit.'};(out/'BEFORE-RESTORE.json').write_text(json.dumps(before,indent=2)+'\n')
assert all(h((repo/x['path']).read_bytes())==x['sha256']for x in entries)
g('restore','--source',head,'--staged','--worktree','--',*tracked)
for p in untracked:
 assert h((out/'untracked'/p).read_bytes())==h((repo/p).read_bytes());os.replace(repo/p,out/('PARKED-'+Path(p).name))
assert not g('status','--porcelain=v1');assert g('rev-parse','HEAD').decode().strip()==head
(out/'RESULT.json').write_text(json.dumps({'status':'PASS_OWNED_GT_WIP_PRIVATELY_PRESERVED_AND_CHECKOUT_CLEAN','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'checkpoint':checkpoint,'verified_tree':tree,'members':len(entries),'tracked_patch_reconstructs_exactly':True,'untracked_entry_restored_from_verified_saved_copy':True,'old_corrected_TGT_donor_untouched':True},indent=2)+'\n')
print((out/'RESULT.json').read_text())
