from pathlib import Path
import subprocess,json,os,hashlib,shutil,datetime
repo=Path('/tmp/tremont-picture-20261026');preview=repo/'site/4d';out=Path('/workspace/T2385-resume-20261029');h=lambda b:hashlib.sha256(b).hexdigest()
def g(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo)
def snap():
 common=Path(g('rev-parse','--git-common-dir').decode().strip());common=common if common.is_absolute()else repo/common
 index=Path(g('rev-parse','--git-path','index').decode().strip());index=index if index.is_absolute()else repo/index
 return {'head':g('rev-parse','HEAD').decode().strip(),'merge_head':g('rev-parse','MERGE_HEAD').decode().strip(),'status_sha256':h(g('status','--porcelain=v1','-z')),'index_sha256':h(index.read_bytes()),'config_sha256':h((common/'config').read_bytes())}
assert preview.is_dir() and not preview.is_symlink();assert not g('ls-files','-z','--','site/4d');assert subprocess.run(['git','check-ignore','-q','site/4d/index.html'],cwd=repo).returncode==0
readers=[];unreadable=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 for q in [p/'cwd',*(p/'fd').glob('*')]:
  try:t=os.readlink(q)
  except (FileNotFoundError,PermissionError,OSError):continue
  if t==str(preview)or t.startswith(str(preview)+'/'):readers.append({'pid':p.name,'fd':str(q),'target':t})
assert not readers,readers
files=[p for p in preview.rglob('*')if p.is_file()];raw=sum(p.stat().st_size for p in files);before=snap();free=shutil.disk_usage('/tmp').free
(out/'PREVIEW-RETIREMENT-BEFORE.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':before,'preview':str(preview),'files':len(files),'logical_bytes':raw,'readers':readers,'restore':'Native bash tools/publish.sh regenerates this ignored preview.'},indent=2)+'\n')
shutil.rmtree(preview);after=snap();assert before==after
r={'status':'PASS_EXACT_GENERATED_IGNORED_PREVIEW_ONLY_RETIRED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_identical':True,'actual_tmp_free_gain':shutil.disk_usage('/tmp').free-free,'files':len(files),'logical_bytes':raw,'free_after':shutil.disk_usage('/tmp').free};(out/'PREVIEW-RETIREMENT-RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
