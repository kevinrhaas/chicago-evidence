from pathlib import Path
import os,json,hashlib,subprocess,datetime,shutil,fnmatch,zipfile,io,gzip,xml.etree.ElementTree as ET,tempfile
repo=Path('/tmp/chicago-green-tree-integration');app=repo/'chicago/4d';home=Path('/workspace/T2385-resume-20261029');out=home/'CURRENT-NATIVE-CLOSURE';out.mkdir(exist_ok=False);scratch=home/'native-scratch';scratch.mkdir(exist_ok=True)
env=dict(os.environ,TMPDIR=str(scratch),NPM_CONFIG_PREFIX='/tmp/T2385-runtime-prefix',PRAIRIE_IMAGE_STORE='/workspace/T2385-integrate-checked-Jail-b3-20261026/image-card/native-store/prairie-1904/files',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',CHECK_JOBS='1');env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None)
def g(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo,env=env)
h=lambda b:hashlib.sha256(b).hexdigest();base=g('rev-parse','HEAD').decode().strip();assert base=='c0936cb192873b8c09a747e4ed3d64b3c6f5115c';env['C4D_RULINGS_BASE']=base;assert not g('ls-files','-u');assert shutil.disk_usage(scratch).free>=1_800_000_000
assert json.loads((home/'CURRENT-SELECTED-CONTINUATION/RESULT.json').read_bytes())['status'].startswith('PASS_');assert json.loads((home/'CURRENT-SELECTED-CONTINUATION-reaper.json').read_bytes())['all_children_reaped'];assert json.loads((app/'data/reference_views/tremont_house_1/gifford.match.json').read_bytes())['verdict']=='matches'
manifest=json.loads((app/'tools/derived_manifest.json').read_bytes());gen={p for s in manifest['steps']for p in s.get('resolves',[])}
def generated(p):return p in {'chicago/4d/data/frontage/town_street_edge.json','chicago/4d/data/signage/town_business_signboards.json','chicago/4d/data/yard/town_trade_goods.json'}or any(p==q or p.startswith(q.rstrip('/')+'/')or fnmatch.fnmatch(p,q)for q in gen)
paths={p for p in(g('ls-files','-z')+g('ls-files','--others','--exclude-standard','-z')).decode().split('\0')if p}
protected={p:h((repo/p).read_bytes())for p in paths if p.startswith('chicago/4d/')and(repo/p).is_file()and not generated(p)and not p.startswith('chicago/4d/data/sidecars/')}
for p in paths:
 if(p.startswith('.github/workflows/')or(p.startswith('chicago/prairie_1904_v1/')and p not in ['chicago/prairie_1904_v1/research/images/STORE.json','chicago/prairie_1904_v1/research/images/images.json']))and(repo/p).is_file():protected[p]=h((repo/p).read_bytes())
for p in ['chicago/4d/docs/LIBERTIES.md','chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md','chicago/4d/tools/smoke_renderer.mjs','chicago/4d/tools/drawn_placement_census.mjs','chicago/4d/tools/test_drawn_placement_census.mjs','chicago/4d/tools/measure_drawn_placement.mjs']:
 protected[p]=h((repo/p).read_bytes())
(out/'PROTECTED-SOURCE-BEFORE.json').write_text(json.dumps(protected,indent=2)+'\n');all_glb={str(p.relative_to(app)):h(p.read_bytes())for root in ['assets/gltf','assets/web']for p in(app/root).rglob('*.glb')};(out/'ALL-GLB-BEFORE.json').write_text(json.dumps(all_glb,indent=2)+'\n')
rows=[]
for p in g('ls-tree','-r','--name-only',base).decode().splitlines():
 if p.lower().endswith(('.xlsx','.gz')):
  b=g('show',base+':'+p);rows.append({'path':p,'sha256':h(b),'bytes':len(b)});assert(repo/p).read_bytes()==b
assert len(rows)==44;(out/'ALL44-ACTUAL-CURRENT-BEFORE.json').write_text(json.dumps(rows,indent=2)+'\n')
steps=[]
def run(n,args,cwd=app):
 assert shutil.disk_usage(scratch).free>=536870912
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();print('START',n,start,flush=True)
 with(out/(n+'.log')).open('x')as f:q=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':n,'command':args,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':q.returncode};steps.append(row);(out/'STEPS.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True);assert q.returncode==0,(n,q.returncode)
store=repo/'chicago/prairie_1904_v1/research/images/STORE.json';storebefore=json.loads(store.read_bytes());run('01-image-store-union',['python3','tools/sync_image_store.py'],repo/'chicago/prairie_1904_v1');run('02-image-store-check',['python3','tools/sync_image_store.py','--check'],repo/'chicago/prairie_1904_v1');storeafter=json.loads(store.read_bytes());assert all(storeafter['files'].get(k)==v for k,v in storebefore['files'].items());assert all(k in storeafter['files']for k in ['early-gifford-first-tremont.jpg','early-gifford-first-tremont-thumb.jpg','early-moss-1884-st-marys.jpg','early-moss-1884-st-marys-thumb.jpg','early-andreas-1884-sauganash.jpg','early-andreas-1884-sauganash-thumb.jpg']);(out/'IMAGE-STORE-EXACT-PRIOR-ROWS-PROOF.json').write_text(json.dumps({'all_prior_rows_exact':True,'before':len(storebefore['files']),'after':len(storeafter['files'])},indent=2)+'\n');run('03-native-library-build',['python3','tools/build_images.py'],repo/'chicago/prairie_1904_v1');run('04-native-library-check',['python3','tools/build_images.py','--check'],repo/'chicago/prairie_1904_v1')
run('05-current-native-metadata-tail',['node','tools/rederive.mjs','--tail','tools/compile_liberties.py'])
def canonical_xlsx(b):
 with zipfile.ZipFile(io.BytesIO(b))as z:
  ans={}
  for n in sorted(z.namelist()):
   raw=z.read(n)
   if n.endswith(('.xml','.rels')):
    root=ET.fromstring(raw)
    if n=='docProps/core.xml':
     for node in list(root):
      if node.tag=='{http://purl.org/dc/terms/}modified':root.remove(node)
    ans[n]=ET.canonicalize(ET.tostring(root,encoding='unicode'))
   else:ans[n]=raw
  return ans
proof=[]
for row in rows:
 p=repo/row['path'];old=g('show',base+':'+row['path']);now=p.read_bytes();same=old==now;kind='EXACT_BYTES'
 if not same:
  q=out/'raw-regenerated44'/row['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(now);same=canonical_xlsx(old)==canonical_xlsx(now)if p.suffix=='.xlsx'else gzip.decompress(old)==gzip.decompress(now);kind='ALL_XLSX_MEMBERS_CANONICAL_XML_EXCEPT_CORE_MODIFIED'if p.suffix=='.xlsx'else'GZIP_DECOMPRESSED_BYTES'
  if same:
   fd,tmp=tempfile.mkstemp(dir=p.parent,prefix='.t2385-serialization-');os.close(fd);Path(tmp).write_bytes(old);shutil.copymode(p,tmp);os.replace(tmp,p)
 proof.append({**row,'current_before_normalization_sha256':h(now),'equivalent':same,'proof':kind,'action':'UNCHANGED'if now==old else'RESTORE_PROVEN_SERIALIZATION_ONLY'if same else'KEEP_REAL_CHANGE'})
(out/'ONE-ALL44-ACTUAL-CURRENT-AUDIT.json').write_text(json.dumps(proof,indent=2)+'\n');assert all(x['equivalent']for x in proof),'Preserve/review actualbinarychange, never discard'
run('06-current-native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']);run('07-current-native-publish',['bash','tools/publish.sh'])
for n,args in [('08-native-lodging-check',['python3','tools/build_lodging_model_1835.py','--check']),('09-native-boarders-check',['python3','tools/seat_lodgers_1835.py','--check']),('10-native-business-check',['python3','tools/reconstruct_businesses_1835.py','--check']),('11-native-staffing-check',['python3','tools/staffing_mint_order_1835.py','--check']),('12-strict-placement-fixtures',['node','tools/test_drawn_placement_census.mjs']),('13-independent-farwalk-census',['node','tools/check_far_plank_tops.mjs','--json']),('14-original-Tremont-image-gate',['node','tools/image_gate.mjs','--structure','tremont_house_1'])]:run(n,args)
changed=[p for p,v in protected.items()if not(repo/p).exists()or h((repo/p).read_bytes())!=v];assert not changed,changed;assert all(h((app/p).read_bytes())==v for p,v in all_glb.items());assert all(h((repo/x['path']).read_bytes())==x['sha256']for x in rows)
result={'status':'PASS_CURRENT_TREMONT_GT_NATIVE_IMAGE_METADATA_ALL44_PACKAGE_PUBLISH','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_base':base,'source_app':str(app),'protected_authored':len(protected),'all_GLBS_exact':len(all_glb),'all44_current_byteexact_after_only_proven_normalization':True,'all_previous_STORE_rows_exact':True,'steps':steps,'pending':'ActualBOTHpublishedapp,currentphone400,finalnativefull3,2ticketcommits/newPRnormalqualifiedDEVmerge. T2376annexOPEN;T2385onlyDONEafteractualcodeandacceptance.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
