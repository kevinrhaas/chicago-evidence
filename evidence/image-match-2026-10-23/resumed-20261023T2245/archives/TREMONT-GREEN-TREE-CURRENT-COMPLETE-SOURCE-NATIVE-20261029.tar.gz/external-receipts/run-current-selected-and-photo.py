from pathlib import Path
import os,json,subprocess,hashlib,datetime,shutil
repo=Path('/tmp/chicago-green-tree-integration');app=repo/'chicago/4d';home=Path('/workspace/T2385-resume-20261029');out=home/'CURRENT-SELECTED-PRODUCTION';out.mkdir(exist_ok=False);scratch=home/'native-scratch';scratch.mkdir(exist_ok=True)
env=dict(os.environ,TMPDIR=str(scratch),BLENDER_CACHE='/workspace/shared/blender-dl',NPM_CONFIG_PREFIX='/tmp/T2385-runtime-prefix',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None)
def g(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo,env=env)
h=lambda b:hashlib.sha256(b).hexdigest();base=g('rev-parse','HEAD').decode().strip();assert base.startswith('c093');assert g('rev-parse','--abbrev-ref','HEAD').decode().strip()=='steward/t2385-t2376-picture-correction-20261029';assert not g('ls-files','-u');assert shutil.disk_usage(scratch).free>=1_800_000_000
assert json.loads((app/'data/structures/tremont_house_1.json').read_bytes())['phases'][0]['form']['stories']['value']==3
before={str(p.relative_to(app)):h(p.read_bytes())for root in ['assets/gltf','assets/web']for p in (app/root).rglob('*.glb')};(out/'ALL-GLB-BEFORE.json').write_text(json.dumps(before,indent=2)+'\n');steps=[]
def run(n,args):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();print('START',n,start,flush=True)
 with(out/(n+'.log')).open('x')as log:q=subprocess.run(args,cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':n,'args':args,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':q.returncode};steps.append(row);(out/'STEPS.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True);assert q.returncode==0,(n,q.returncode)
run('01-genuine-current-selected-bake',['bash','tools/bake.sh','--only','tremont_house_1,green_tree_tavern'])
after={str(p.relative_to(app)):h(p.read_bytes())for root in ['assets/gltf','assets/web']for p in (app/root).rglob('*.glb')};unexpected=[p for p,v in before.items()if after.get(p)!=v and not any(k in p for k in ['tremont_house_1/','tremont_house_1__','green_tree_tavern__'])];assert not unexpected,unexpected
(out/'ALL-OTHER-GLB-PROTECTION.json').write_text(json.dumps({'all_before':len(before),'all_after':len(after),'unexpected_changes':unexpected,'actual_changed':{p:{'before':before.get(p),'after':v}for p,v in after.items()if before.get(p)!=v},'unchanged_nonselected':sum(1 for p,v in before.items()if after.get(p)==v)},indent=2)+'\n')
run('02-strict-picture-feature-fixtures',['python3','tools/test_frame_tavern_picture_features.py'])
run('03-genuine-current-Gifford-photo',['node','tools/photo_match.mjs','data/reference_views/tremont_house_1/gifford.json'])
run('04-genuine-current-GT-photo',['node','tools/photo_match.mjs','data/reference_views/green_tree_tavern/andreas_1838.json'])
r={'status':'ACTUAL_CURRENT_SELECTED_NATIVE_AND_PHOTO_PRODUCTION_PASS_REVIEW_PENDING','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_base':base,'steps':steps,'all_other_GLBS_exact':True,'source_app':str(app),'scratch':str(scratch),'WS_free':shutil.disk_usage(scratch).free,'TMP_free':shutil.disk_usage('/tmp').free,'original_DONE':False};(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
