# Tremont: actual pictured canonical pair and fresh comparison

The native canonical+Gale pair passed and both native/photo commands are fully reaped. Canonical63b1802b… is the pictured three-storey form with yellow finish; its5,552material-named geometric triangles are exact to currentdev’s original3-storey model. Gale’s3,400geometric triangles exactly retain the old2-storey proposal as an optional native version. All22 otherFT rows, unrelatedversions and everyotherassetfile are exact.

Actual fresh canonical visual review finds no independently established architectural gap over the stopping bar. Generic neutral-render context/cloth omissions are not inventedOPEN blockers. The formal reference remainsunreviewed pending integrated current-canonical app/flag checks in bothviewports; no originalDONE or whole-gatepass is claimed. Exact pigment remains a liberty.

Reconstruct this WIP on public1290 from the complete18-source archive and three explicitdeletions in its inventory. The private stashSHA306e1df57da8e7694e66d2d9da95b47f1f9193b0 and namedcheckpointref retain the exact same tree locally, without sharedrefs/stash. Before globalnative, normalmerge checkedJailb3 and reapply only this exact privatepayload with authored/registry ownership guards. No force or promotiontool. The old1290 full18 certificate is historical and cannot certify this revision.
