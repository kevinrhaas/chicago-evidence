"""Prepared orchestration of existing native writers; run only in an assigned CPU window."""
from pathlib import Path
from collections import Counter
import argparse,datetime,hashlib,json,os,shutil,stat,struct,subprocess,sys,tempfile

ap=argparse.ArgumentParser();ap.add_argument('--cpu',type=int,required=True);args=ap.parse_args()
assert args.cpu in os.sched_getaffinity(0);os.sched_setaffinity(0,{args.cpu})
ROOT=Path('/tmp/tremont-picture-20261026/chicago/4d')
HOLDER=Path('/workspace/T2385-picture-yellow-adoption-20261026T1900')
OUT=HOLDER/'native-canonical-and-gale';assert not OUT.exists();OUT.mkdir()
NAME='tremont_house_1__frame_1833.glb'
VKEY='versions/tremont_house_1/gale-reading/'+NAME
RECIPES={NAME:'a3a68fd5ce5684517f12b99dc6874c9de2107f0a6e185f4103ed7d96f4f1365c',VKEY:'717398e00f8c2d31353e07b3afbae89cd2679969283210b5572ef6f1f35ba70f'}
BLENDER='/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender'
def save(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def describe(path):
    b=path.read_bytes();s=path.stat()
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':stat.S_IMODE(s.st_mode),'links':s.st_nlink}
def run(label,cmd):
    with (OUT/(label+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    assert p.returncode==0,(label,p.returncode)
def geometry(path):
    b=path.read_bytes();assert b[:4]==b'glTF';n,kind=struct.unpack_from('<II',b,12);assert kind==0x4e4f534a
    j=json.loads(b[20:20+n]);start_bin=20+n+8
    def read(ai):
        a=j['accessors'][ai];v=j['bufferViews'][a['bufferView']]
        code={5121:'B',5123:'H',5125:'I',5126:'f'}[a['componentType']];num={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
        fmt='<'+code*num;size=struct.calcsize(fmt);start=start_bin+v.get('byteOffset',0)+a.get('byteOffset',0)
        return [struct.unpack_from(fmt,b,start+i*v.get('byteStride',size))for i in range(a['count'])]
    result=Counter()
    for mesh in j.get('meshes',[]):
        for p in mesh['primitives']:
            assert p.get('mode',4)==4;ps=read(p['attributes']['POSITION']);ix=[v[0]for v in read(p['indices'])];mat=j['materials'][p['material']]['name']
            for i in range(0,len(ix),3):result[(mat,tuple(sorted(ps[k]for k in ix[i:i+3])))]+=1
    return result,j

sys.path.insert(0,str(ROOT/'generators'))
from mesh_inputs import structure_inputs_sha,structure_inputs_doc
from archetypes.frame_tavern_params import from_phase
records={NAME:json.loads((ROOT/'data/structures/tremont_house_1.json').read_text()),VKEY:json.loads((ROOT/'data/structures/versions/tremont_house_1/gale-reading.json').read_text())}
for key,r in records.items():
    from_phase(r['phases'][0],r).validate();assert structure_inputs_sha(r,r['phases'][0])==RECIPES[key]
    save(('canonical'if key==NAME else'gale')+'-actual-recipe.json',structure_inputs_doc(r,r['phases'][0]))
assert not(ROOT/'data/structures/versions/tremont_house_1/gifford-reading.json').exists()
old_three=HOLDER/'withdrawn-public1290/chicago/4d/assets/gltf/versions/tremont_house_1/gifford-reading'/NAME
assert describe(old_three)['sha256']=='35976a58a4b5911cf663df9d95efc0ad751ebda49ec3390eb43442800e5d09f9'
old_two=ROOT/'assets/gltf'/NAME
assert describe(old_two)['sha256']=='5621bb14b76916ce1cb7bdef3a0ff3973d73ac1e062390bf886bc4c8af180ef7'
before_three,old_three_json=geometry(old_three);before_two,old_two_json=geometry(old_two)
shutil.copy2(old_two,OUT/'before-two-storey-canonical.glb')
all_before={p.relative_to(ROOT).as_posix():describe(p)for p in sorted((ROOT/'assets').rglob('*'))if p.is_file()}
save('ALL-ASSET-FILES-BEFORE.json',all_before)
mp=ROOT/'assets/manifest.json';wp=ROOT/'assets/manifest.web.json';vp=ROOT/'assets/manifest.versions.json'
mb=json.loads(mp.read_text());wb=json.loads(wp.read_text());vb=json.loads(vp.read_text())
frame={k:v for k,v in mb['assets'].items()if v.get('archetype')=='frame_tavern'};assert len(frame)==23 and NAME in frame
save('MASTER-MANIFEST-BEFORE.json',mb);save('WEB-MANIFEST-BEFORE.json',wb);save('VERSION-MANIFEST-BEFORE.json',vb)
assert VKEY not in vb['assets']
for tier in ('gltf','web'):
    target=ROOT/'assets'/tier/NAME
    if target.stat().st_nlink>1:
        fd,tmp=tempfile.mkstemp(dir=target.parent,prefix='.t2385-target-');os.close(fd);shutil.copy2(target,tmp);os.replace(tmp,target)
    assert target.stat().st_nlink==1
    assert describe(target)['sha256']==all_before[target.relative_to(ROOT).as_posix()]['sha256']
    assert not(ROOT/'assets'/tier/VKEY).exists()
versions={}
for pkg in ('cli','core','extensions','functions'):
    v=json.loads((Path('/workspace/shared/gltf-transform/node_modules/@gltf-transform')/pkg/'package.json').read_text())['version'];assert v=='4.5.0';versions[pkg]=v
save('GLTF-PINS.json',versions)
env={**os.environ,'PWD':str(ROOT),'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
run('blender-version',[BLENDER,'--version']);assert 'Blender 4.5.3'in(OUT/'blender-version.log').read_text()
cmd=[BLENDER,'-b','-noaudio','--factory-startup','--threads','1','--python-exit-code','1','--python',str(ROOT/'generators/build.py'),'--','--only','tremont_house_1','--scene','1835','--wrote',str(OUT/'masters-wrote.txt')]
save('NATIVE-COMMAND.json',cmd);run('native-canonical-plus-gale',cmd)
wrote=(OUT/'masters-wrote.txt').read_text().splitlines();assert len(wrote)==2 and set(wrote)==set(RECIPES),wrote
webcmd=['bash','tools/web_derivatives.sh','--only',','.join(wrote)];save('WEB-COMMAND.json',webcmd);run('native-WEB-pair',webcmd)
all_after={p.relative_to(ROOT).as_posix():describe(p)for p in sorted((ROOT/'assets').rglob('*'))if p.is_file()}
save('ALL-ASSET-FILES-AFTER.json',all_after)
added=set(all_after)-set(all_before);removed=set(all_before)-set(all_after)
changed={p for p in set(all_before)&set(all_after)if any(all_before[p][k]!=all_after[p][k]for k in ('bytes','sha256','mode'))}
assert not removed
assert added=={'assets/gltf/'+VKEY,'assets/web/'+VKEY},added
assert changed=={'assets/gltf/'+NAME,'assets/web/'+NAME,'assets/manifest.json','assets/manifest.web.json','assets/manifest.versions.json'},changed
ma=json.loads(mp.read_text());wa=json.loads(wp.read_text());va=json.loads(vp.read_text())
assert set(ma['assets'])==set(mb['assets']) and {k for k in mb['assets']if mb['assets'][k]!=ma['assets'][k]}=={NAME}
assert set(wa['masters'])==set(wb['masters']) and {k for k in wb['masters']if wb['masters'][k]!=wa['masters'][k]}=={NAME}
assert set(va['assets'])-set(vb['assets'])=={VKEY} and all(va['assets'][k]==v for k,v in vb['assets'].items())
assert ma['assets'][NAME]['inputs_sha256']==RECIPES[NAME]
assert va['assets'][VKEY]['inputs_sha256']==RECIPES[VKEY]
assert wa['masters'][NAME]==all_after['assets/gltf/'+NAME]['sha256']
assert va['assets'][VKEY]['web_master_sha256']==all_after['assets/gltf/'+VKEY]['sha256']
new_three,new_three_json=geometry(ROOT/'assets/gltf'/NAME);new_two,new_two_json=geometry(ROOT/'assets/gltf'/VKEY)
assert new_three==before_three,'Canonical positions/triangles must remain exact currentdev pictured3-storey form'
assert new_two==before_two,'Optional Gale geometry must retain the exact prior2-storey proposal'
save('GEOMETRY-RETENTION.json',{'method':'Independent exact material-named triangle multiset decoded from actual GLB position/index buffers.','canonical_matches_currentdev_three_storey_geometry':True,'canonical_triangles':sum(new_three.values()),'Gale_matches_preserved_two_storey_geometry':True,'Gale_triangles':sum(new_two.values()),'canonical_materials_before':old_three_json['materials'],'canonical_materials_after':new_three_json['materials'],'canonical_note':'Yellow paint/trim palette and paint confidence may change; all material-named geometric triangles are exact.','Gale_materials_exact':old_two_json['materials']==new_two_json['materials']})
save('RESULT.json',{'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EXACT_NATIVE_CANONICAL_AND_GALE_PAIR_BUILT_NO_GLOBAL_OR_ACCEPTANCE_GATE','cpu':args.cpu,'physical_files_before':len(all_before),'added':sorted(added),'changed':sorted(changed),'all22_other_frame_tavern_assets_rows_and_unrelated_versions_exact':True,'canonical':{'input':RECIPES[NAME],'master':all_after['assets/gltf/'+NAME],'WEB':all_after['assets/web/'+NAME]},'Gale':{'input':RECIPES[VKEY],'master':all_after['assets/gltf/'+VKEY],'WEB':all_after['assets/web/'+VKEY]},'fresh_photo_app_or_global_gate_PASS':False,'old1290_matrix_certifies_this_WIP':False,'original_DONE':False})
print((OUT/'RESULT.json').read_text(),flush=True)
