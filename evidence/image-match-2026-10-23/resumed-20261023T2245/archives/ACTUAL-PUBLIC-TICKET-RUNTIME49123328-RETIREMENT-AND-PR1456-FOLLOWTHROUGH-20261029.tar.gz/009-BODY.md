Give the Miller House its pictured low log wing beside the tall range, add Hogan’s horizontal gable courses and chimney cap, raise St Mary’s front sash, and add the credited Castelnau harbour view to the lighthouse card. Sources retain disputed dates, unresolved details and picture conflicts; comparison cameras remain diagnostic.

Validation at native head `b20f4200`, merging `EC16` into the four-building branch:

- All 1,104 foreground checks passed on exact tree `d630e015`. Native regeneration and publication passed; all 44 derived outputs were audited. The merge preserves 533 relevant source bindings, three reviewed upstream K helpers, all 706 log/frame models and all 353 fresh recipes. Four image gates and committed PR checks passed.
- The current 1904 phone measurement passed at **395.68 MiB / 400 MiB**.
- Desktop/mobile app evidence is bound through 305 unchanged published inputs. Miller’s updated Full-detail runs passed both viewports with zero page errors, credited image viewing and clear approaches to both doors. This is dated evidence for unchanged consumers; no fresh whole-app matrix or frame-rate measurement is claimed.
- Both sets of documentation appendices are preserved in chronological order. A native next-append merge test passed. All 60 changed paths in the native merge were read back from GitHub byte-for-byte.

T-2381, T-2373, T-2384 and T-2377 remain in official review for this PR. Newer `dev` includes separate Pullman glasshouse work; the native PR lap must integrate it and required CI must pass on the final head before merging.

Recovery and exact receipts: [checkpoint 695](https://github.com/kevinrhaas/chicago-evidence/blob/7b56439590f6850acb5a6ac64a284c8a33ec2f3b/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md).
