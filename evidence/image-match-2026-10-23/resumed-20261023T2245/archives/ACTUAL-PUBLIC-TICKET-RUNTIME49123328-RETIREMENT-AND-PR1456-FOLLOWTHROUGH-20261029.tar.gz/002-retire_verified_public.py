from pathlib import Path
import json,hashlib,os,subprocess,stat,datetime
O=Path(__file__).parent;R=Path('/workspace/isolated-gt-ticket-renewal-native-v4-20261029/repo');B=json.loads((O/'BINDING.json').read_text());P=Path('/tmp/checkpoint-oct29-public-ticket-runtime-retirement-resume');C=json.loads((P/'COMPLETE.json').read_text());A=json.loads((P/'PUBLICATION.json').read_text());reaper=json.loads((P/'reaper.json').read_text())
assert C['status']=='PASS' and A['status']=='PUBLISHED_NORMAL_FF_AND_FULL_IMMUTABLE_READBACK_PASS' and reaper['command_exit']==0 and reaper['all_children_reaped']
assert C['archives_count']==696 and A['new_archive_records'][0]['source_file_count']==3223
sha=lambda b:hashlib.sha256(b).hexdigest();env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
g=lambda *x:subprocess.check_output(['git','-C',str(R),*x],env=env)
def metadata():return {p:sha((R/'.git'/p).read_bytes())for p in B['metadata']}
assert g('rev-parse','HEAD').decode().strip()==B['HEAD'] and metadata()==B['metadata'] and g('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines()==B['refs']
assert g('status','--porcelain','--untracked-files=all').decode()==B['status_porcelain']==''
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  cwd=(p/'cwd').resolve();inside=cwd==R or R in cwd.parents
  if inside:active.append({'pid':int(p.name),'comm':(p/'comm').read_text().strip()})
 except OSError:pass
assert not active,active
for x in B['files']:
 f=R/x['path'];s=f.stat();assert f.is_file() and not f.is_symlink() and s.st_nlink==1 and s.st_size==x['bytes'] and stat.S_IMODE(s.st_mode)==x['mode'] and sha(f.read_bytes())==x['sha256']
assert len(B['files'])==3221 and sum(x['allocated_bytes']for x in B['files'])==49123328
freebefore=os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize
for i,x in enumerate(B['files']):
 f=R/x['path'];assert not f.is_symlink() and f.stat().st_size==x['bytes'];f.unlink()
 assert not f.exists()
assert metadata()==B['metadata'] and g('rev-parse','HEAD').decode().strip()==B['HEAD'] and g('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines()==B['refs']
freeafter=os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize
result={'status':'ACTUAL_VERIFIED_DUPLICATE_PUBLIC_WORKFILES_RETIRED_AFTER_FULL_IMMUTABLE_ARCHIVE_READBACK','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtime_repo':str(R),'native_HEAD':B['HEAD'],'public_files_retired':3221,'source_bytes_preserved':42512628,'allocated_bytes_retired':49123328,'workspace_free_before':freebefore,'workspace_free_after':freeafter,'concurrent_workspace_free_delta':freeafter-freebefore,'unchanged_git_metadata_refs':True,'all_private_git_objects_config_alternates_preserved':True,'all_untracked_files_profiles_checkpoints_primary_app_and_primary_ticket_cache_preserved':True,'immutable_archive_publication':C['publication'],'immutable_archive_availability':C['availability_commit'],'archive_sha256':A['new_archive_records'][0]['sha256'],'archive_bytes':A['new_archive_records'][0]['bytes'],'archive_source_member_count':3223,'binding_sha256':sha((O/'BINDING.json').read_bytes()),'index':C['index'],'runtime_now_unusable_for_native_commands_until_exact_restoration':True}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
