# T-2375: owner’s Tribune lead, actual issue checked

Owner supplied this bibliographic credit: **“the dearborn bridge photo is from
Chicago Tribune Editorial February 15, 1880.”** The credit is recorded verbatim in
OWNER-LEAD.json and the proposed source note. This is a serious source lead, not a
fabricated claim that an archive page was inspected.

The actual issue was independently located at Internet Archive:
`per_chicago-daily-tribune_the-chicago-daily-tribun_1880-02-15_40`.
Its actual n3 / printed p.4 has the **DEARBORN-STREET BRIDGE** editorial, dated by
the page masthead Sunday, February15,1880. The editorial’s opening and body match
Chicagology’s transcription. It discusses a proposed1880 crossing and river
navigation. That dated US editorial is public domain by age and gets a distinct
text-only source record. It supplies noJuly1835 geometry or coordinates.

The exact Baker-Co engraving was **not located** in this scanned issue. The
editorial page and following page were directly viewed as large JPEGs. All other
fourteen page overviews were directly viewed as medium JPEGs, a bounded1.40MB
additional download. None shows the recognizable Baker bridge illustration. The
full issue OCR has no “OldPoint”, “firstbridge”, “1834” or “oldDearborn” caption;
its Baker occurrence is an unrelated hotel guest. This does not prove that no
variant edition exists or identify the engraving’s original publication.

Chicagology places the Baker image/caption *before a rule and the next editorial
heading*. Adjacency on that web page establishes neither a positive image-to-issue
match nor the print’s publication date. The earlier canonical artwork record
already locates the image above this editorial; the new owner credit is retained
alongside the actual independent check. We do not silently turn the editorial’s
verified1880 date into a verified date for a different asset.

The separate Baker artwork retains its current check_required status in this
external proposal. This is not a blocker for bridge geometry independently based
on the cleared Andreas1884 plate, Norton/Moses text and newly verified Earle
c1902 original volume. No new Baker-derived camera/side-by-side is asserted.
No follow-up ticket or repeated user question is created.

Four proposed paths: new verified editorial source; append/update the existing
Baker source without removing its historical provenance; correct the two
inventory entries to retain the owner credit and honest verification limits.
The patch passes actual `git apply --check` and is unapplied. The two shared
inventory changes also compose with the separate immutable Earle correction
packet in a disposable external mirror, without whole-file overwrites. Recheck
current preimages and adopt fieldwise after the normal ticket/source lease.

The closed Earle packet is unchanged. Original bridge closure still requires
canonical adoption, actual Earle fitting/rendering and a finite Baker source/view
disposition, current native recipes/WEB/consumer checks, ground/app evidence,
actual full gate, policy PR/CI/merge to dev and official settlement.
