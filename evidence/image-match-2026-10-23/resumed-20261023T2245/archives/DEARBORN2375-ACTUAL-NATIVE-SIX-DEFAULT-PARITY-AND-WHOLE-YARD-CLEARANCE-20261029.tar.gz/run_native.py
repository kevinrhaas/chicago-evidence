from pathlib import Path
import sys,json,importlib.util,hashlib,time,datetime,shutil
import bpy
assert bpy.app.version[:3]==(4,5,3),bpy.app.version
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(A/'generators'));import emit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs=json.loads((P/'INPUTS.json').read_text());outcomes=[]
assert (P/'ROOT-CPU-GRANT.json').is_file(),'No root grant; refusing actual native work'
for path,h in inputs['producer_current_bindings'].items():assert sha(Path(path))==h,path
for rel,h in inputs['packet_input_bindings'].items():assert sha(P/rel)==h,rel
for e in inputs['family']:
 assert sha(Path(e['canonical_record']))==e['record_sha256'];assert sha(Path(e['current_master']))==e['current_master_sha256']
def use(label):
 for name in ['bridge_timber_params','bridge_timber']:
  fullname='archetypes.'+name;spec=importlib.util.spec_from_file_location(fullname,P/'inputs'/label/(name+'.py'));mod=importlib.util.module_from_spec(spec);sys.modules[fullname]=mod;spec.loader.exec_module(mod)
 params=sys.modules['archetypes.bridge_timber_params'];arch=sys.modules['archetypes.bridge_timber'];emit.ARCHETYPES['bridge_timber']=(params.from_phase,arch.build)
for label in ['old','candidate']:
 use(label);target=P/('old6' if label=='old' else 'candidate-default6');target.mkdir(exist_ok=True)
 for e in inputs['family']:
  r=json.loads(Path(e['record']).read_text());phase=next(x for x in r['phases'] if x['id']==e['phase']);t=time.monotonic();dest=target/e['asset'];made=emit.emit_structure(r,phase,'bridge_timber',dest,bake=True,ao=False)
  row={'label':label,'asset':e['asset'],'seconds':time.monotonic()-t,'sha256':sha(dest),'bytes':dest.stat().st_size,'triangles':made.tris,'exact_current_master':sha(dest)==e['current_master_sha256']};outcomes.append(row);print(json.dumps(row),flush=True)
for e in inputs['family']:
 old=P/'old6'/e['asset'];new=P/'candidate-default6'/e['asset'];assert old.read_bytes()==new.read_bytes(),e['asset']+' candidate default differs'
 # Record current equality honestly; preserve any mismatch for exact decoded analysis.
 if sha(old)!=e['current_master_sha256']:
  d=P/'current-master-controls'/e['asset'];d.parent.mkdir(exist_ok=True);shutil.copyfile(e['current_master'],d)
use('candidate');r=json.loads((P/'inputs/candidate/dearborn_street_drawbridge.json').read_text());dest=P/'candidate/assets/gltf'/(r['id']+'__'+r['phases'][0]['id']+'.glb');t=time.monotonic();made=emit.emit_structure(r,r['phases'][0],'bridge_timber',dest,bake=True,ao=False)
for path,h in inputs['producer_current_bindings'].items():assert sha(Path(path))==h,path
for e in inputs['family']:
 assert sha(Path(e['canonical_record']))==e['record_sha256'];assert sha(Path(e['current_master']))==e['current_master_sha256']
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'NATIVE_EXPORTS_COMPLETE_NOT_ADOPTED','default_rows':outcomes,'all6_old_newdefault_master_bytes_exact':True,'all6_current_master_bytes_exact':all(x['exact_current_master'] for x in outcomes),'candidate':{'path':str(dest),'seconds':time.monotonic()-t,'sha256':sha(dest),'bytes':dest.stat().st_size,'triangles':made.tris},'all_producer_record_current_master_inputs_unchanged':True,'WEB':'PENDING','whole_yard_actual_terrain_app_camera_acceptance':'UNRUN'};(P/'ACTUAL-NATIVE-EXPORT-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'default_exports':12,'trial':result['candidate'],'all_current_exact':result['all6_current_master_bytes_exact']}),flush=True)
