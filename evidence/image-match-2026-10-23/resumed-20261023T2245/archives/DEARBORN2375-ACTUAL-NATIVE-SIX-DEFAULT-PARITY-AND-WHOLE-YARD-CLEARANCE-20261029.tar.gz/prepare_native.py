from pathlib import Path
import json,hashlib,shutil,datetime
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');V1=Path('/tmp/dearborn-profile-implemented-20261029');V2=Path('/tmp/dearborn-profile-precision-v2-20261029');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label,src in [('old',V1/'before/chicago/4d'),('candidate',V1/'candidate/chicago/4d')]:
 for name in ['bridge_timber_params.py','bridge_timber.py']:
  f=src/'generators/archetypes'/name;shutil.copyfile(f,P/'inputs'/label/name)
  if label=='old':assert f.read_bytes()==(A/'generators/archetypes'/name).read_bytes()
shutil.copyfile(V2/'candidate/chicago/4d/data/structures/dearborn_street_drawbridge.json',P/'inputs/candidate/dearborn_street_drawbridge.json')
entries=json.loads((A/'assets/manifest.json').read_text())['assets'];family=[]
for asset,e in entries.items():
 if e.get('archetype')!='bridge_timber':continue
 record=A/'data/structures'/(e['structure_id']+'.json');saved=P/'inputs/records'/record.name;shutil.copyfile(record,saved);master=A/'assets/gltf'/asset
 family.append({'asset':asset,'id':e['structure_id'],'phase':e['phase_id'],'record':str(saved),'canonical_record':str(record),'record_sha256':sha(record),'current_master':str(master),'current_master_sha256':sha(master),'bytes':master.stat().st_size,'native_registry_row':e})
assert len(family)==6
# Freeze the native WEB entrypoint and only its actual local helpers, not a runtime copy.
for rel in ['tools/web_derivatives.sh','tools/web_derivative_baseline.json','tools/structure_versions.py']:shutil.copyfile(A/rel,P/'candidate'/rel)
producer_inputs={str(p):sha(p) for p in sorted((A/'generators').rglob('*.py')) if '__pycache__' not in p.parts}
for rel in ['tools/web_derivatives.sh','tools/web_derivative_baseline.json','tools/structure_versions.py','generators/blender.pin']:producer_inputs[str(A/rel)]=sha(A/rel)
r={'prepared_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PREPARED_UNRUN_AWAITING_ROOT_CPU_GRANT','source_root':str(A),'family':family,'producer_current_bindings':producer_inputs,'packet_input_bindings':{str(p.relative_to(P)):sha(p) for p in (P/'inputs').rglob('*') if p.is_file()},'scope':'No canonical source writes, Git worktree, claim, exports, WEB, browser, whole-yard clearance, gate or acceptance. Native old6/newdefault6/trial1 will run only under rootgrant.'};(P/'INPUTS.json').write_text(json.dumps(r,indent=2)+'\n');print('PREPARED',len(family),'masters',sum(x['bytes'] for x in family),'bytes; no native process')
