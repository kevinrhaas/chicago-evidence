import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {register} from 'node:module';import {pathToFileURL,fileURLToPath} from 'node:url';
const P=fileURLToPath(new URL('.',import.meta.url));const input=JSON.parse(fs.readFileSync(P+'YARD-INPUTS.json'));const root=input.native_root;const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
assert(fs.existsSync(P+'ROOT-CPU-GRANT.json'),'No root CPU grant; refusing actual whole-yard native capture');
for(const [p,h]of Object.entries(input.current_bindings))assert.equal(sha(p),h,p);
const vendor=pathToFileURL(root+'/renderers/web/vendor/three-0.185.1/').href;
register(`data:text/javascript,${encodeURIComponent(`export function resolve(s,c,next){if(s==='three')return{url:'${vendor}three.module.js',shortCircuit:true};if(s.startsWith('three/addons/'))return{url:'${vendor}addons/'+s.slice(13),shortCircuit:true};return next(s,c);}`)}`,import.meta.url);
const THREE=await import('three');const {Heightfield}=await import(pathToFileURL(root+'/renderers/web/js/terrain.js'));const compact=await import(pathToFileURL(root+'/renderers/web/js/compact-streams.js'));
const source=fs.readFileSync(P+'inputs/yard-native.js','utf8');assert.equal(crypto.createHash('sha256').update(source).digest('hex'),input.current_bindings[root+'/renderers/web/js/yard.js']);
const stripped=source.replace(/^import[^;]+;\n/gm,'').replace(/^export /gm,'');
const native=new Function('THREE','compactStreams','COLOR_LANE_CONFIDENCE',stripped+'\nreturn{buildItem,buildStack,buildCart,buildWagon,buildShed,buildOutbuilding,readForm,LEVEL,WOOD_KINDS,STACK_KINDS,ENDGRAIN,GOODS_COLOUR,CANVAS_COLOUR,BRICK_LINEAR,STONE_COLOUR,HAY_COLOUR,HIDE_COLOUR,BARK_COLOUR,SPLIT_COLOUR,IRON_COLOUR};')(THREE,compact.compactStreams,compact.COLOR_LANE_CONFIDENCE);
const meta=JSON.parse(fs.readFileSync(input.native_terrain_meta));const raw=fs.readFileSync(path.join(path.dirname(input.native_terrain_meta),meta.bin));const hf=new Heightfield();hf.adopt(meta,raw.buffer.slice(raw.byteOffset,raw.byteOffset+raw.byteLength));let outsideSamples=0;
const terrain={surfaceHeight:(e,n)=>{if(e<hf.originE||e>hf.originE+hf.widthM||n<hf.originN||n>hf.originN+hf.depthM)outsideSamples++;return hf.sample(e,n);}};
const side=JSON.parse(fs.readFileSync(P+'inputs/dearborn-sidecar.json'));const t=side.placement.rotation_deg*Math.PI/180,cs=Math.cos(t),sn=Math.sin(t),E=side.placement.local_e,N=side.placement.local_n;const span=Math.max(...side.footprint.polygon.map(p=>p[0])),width=Math.max(...side.footprint.polygon.map(p=>p[1]));const guard={x:[-1,span+1],v:[-1,width+1]};
const rect={u0:.1,v0:.1,u1:.9,v1:.9};const palette=atlas=>{
 const tone=hex=>{const c=new THREE.Color(hex);return[c.r,c.g,c.b];};
 const split=tone(native.SPLIT_COLOUR);
 return{timber:tone(native.GOODS_COLOUR),canvas:tone(native.CANVAS_COLOUR),brick:[...native.BRICK_LINEAR],stone:tone(native.STONE_COLOUR),hay:tone(native.HAY_COLOUR),hide:tone(native.HIDE_COLOUR),bark:tone(native.BARK_COLOUR),split,white:atlas?[1,1,1]:split,iron:tone(native.IRON_COLOUR)};
};
const cases=[];let attempted=0,totalTriangles=0,atlasStatesDifferent=0;const problems=[];
function capture(builder,item,form,level,who,woodpile,atlas){
 const tones=palette(atlas);const buf={pos:[],nrm:[],conf:[],col:[],uv:[],uv1:[],...tones,tint:tones.timber,blank:[0,0],wood:atlas?{end:native.ENDGRAIN.map(()=>rect),sides:rect,round:rect}:null};buf.bare=new Set([buf.canvas,buf.brick,buf.stone,buf.hay,buf.hide,buf.white,buf.bark,buf.split,buf.iron]);if(woodpile)buf.grainOn=false;
 const issues=[];const marks=atlas?()=>rect:null;
 const ok=builder===native.buildOutbuilding?builder(buf,item,terrain,level,issues):builder(buf,item,form,terrain,level,issues,who,marks);
 assert(buf.pos.every(Number.isFinite));assert.equal(buf.pos.length%9,0);
 const bounds=[[Infinity,-Infinity],[Infinity,-Infinity],[Infinity,-Infinity]],worldBounds=[[Infinity,-Infinity],[Infinity,-Infinity],[Infinity,-Infinity]];
 for(let i=0;i<buf.pos.length;i+=3){const e=buf.pos[i],n=-buf.pos[i+2],h=buf.pos[i+1],x=(e-E)*cs-(n-N)*sn,v=(e-E)*sn+(n-N)*cs;
  for(const [array,p]of [[bounds,[x,v,h]],[worldBounds,[e,n,h]]])for(let k=0;k<3;k++){array[k][0]=Math.min(array[k][0],p[k]);array[k][1]=Math.max(array[k][1],p[k]);}
 }
 const bytes=Buffer.from(new Float64Array(buf.pos).buffer);return{ok,issues,vertices:buf.pos.length/3,triangles:buf.pos.length/9,position_float64_sha256:crypto.createHash('sha256').update(bytes).digest('hex'),bridge_local_bounds:bounds,world_ENH_bounds:worldBounds};
}
function add(record,pointer,builder,item,form,level,who,woodpile=false){
 attempted++;const a=capture(builder,item,form,level,who,woodpile,false),b=capture(builder,item,form,level,who,woodpile,true);if(a.position_float64_sha256!==b.position_float64_sha256)atlasStatesDifferent++;
 for(const c of [a,b]){totalTriangles+=c.triangles;if(c.vertices){const [x,v]=c.bridge_local_bounds;const dx=Math.max(guard.x[0]-x[1],x[0]-guard.x[1],0),dv=Math.max(guard.v[0]-v[1],v[0]-guard.v[1],0);c.whole_geometry_guard_gap_lower_bound_m=Math.hypot(dx,dv);assert(c.whole_geometry_guard_gap_lower_bound_m>0,JSON.stringify({record,pointer,item,bounds:c.bridge_local_bounds,guard}));}problems.push(...c.issues);}
 cases.push({record,pointer,id:item.id??who,kind:item.kind??null,anchor:item.at_local_enu_m,states:{atlas_absent:a,atlas_present:b}});
}
for(const row of input.records){assert.equal(sha(row.path),row.sha256);const record=JSON.parse(fs.readFileSync(row.path));const f=native.readForm(record),level=native.LEVEL[record.existence?.confidence]??1;const anchor=items=>items.some(it=>Array.isArray(it.at_local_enu_m)&&it.at_local_enu_m.length===2);
 for(const [i,g]of(record.frontages??[]).entries()){if(!anchor(g.items??[]))continue;for(const[j,item]of(g.items??[]).entries())add(row.id,`frontages/${i}/items/${j}`,native.buildItem,item,f,native.LEVEL[g.confidence]??level,g.structure_id);}
 for(const[i,g]of(record.lots??[]).entries()){if(!anchor(g.items??[]))continue;const woodpile=(g.items??[]).some(it=>native.WOOD_KINDS.has(it.kind));for(const[j,item]of(g.items??[]).entries()){const fn=native.STACK_KINDS.has(item.kind)||native.WOOD_KINDS.has(item.kind)?native.buildStack:native.buildItem;add(row.id,`lots/${i}/items/${j}`,fn,item,f,native.LEVEL[g.confidence]??level,g.structure_id,woodpile);}}
 for(const[key,fn]of[['wagons',null],['benches',native.buildItem],['sheds',native.buildShed],['outbuildings',native.buildOutbuilding]])for(const[i,item]of(record[key]??[]).entries()){const at=item.at_local_enu_m;if(!Array.isArray(at)||at.length!==2)continue;add(row.id,`${key}/${i}`,fn??(item.kind==='cart'?native.buildCart:native.buildWagon),item,f,native.LEVEL[item.confidence]??level,item.belongs_to??item.id);}
}
assert.equal(outsideSamples,0,'Native heightfield must cover every requested support sample; no guessed clamp/fallback terrain');
for(const[p,h]of Object.entries(input.current_bindings))assert.equal(sha(p),h,p);
const gap=Math.min(...cases.flatMap(c=>Object.values(c.states).filter(s=>s.vertices).map(s=>s.whole_geometry_guard_gap_lower_bound_m)));
const result={at:new Date().toISOString(),status:'ALL_INDEXED_NATIVE_YARD_FLOAT_GEOMETRY_CLEARS_EXPANDED_FULL_BRIDGE_RECTANGLE',attempted_items:attempted,records:input.records.length,native_atlas_presence_states:2,atlas_presence_changes_native_positions_for_items:atlasStatesDifferent,total_triangles_both_states:totalTriangles,guard_bridge_local_rect:guard,min_whole_emitted_geometry_gap_lower_bound_m:gap,actual_native_Heightfield_adopt_and_sample:true,outside_heightfield_samples:outsideSamples,source_record_inputs_before_after_exact:true,problems,cases,scope:'Every native float position emitted by unchanged builders for conservative all-indexedhostsuperset; actualworldE/N converted to rigidbridgeframe; eachtriangle lies inside its vertexAABB, disjoint from entirebridgefootprint expanded1m. Actualatlascoordinatevalues affectUV only; truthypresence and actualENDGRAINcount preserve nativeRNG paths, both presence/fallbackstates captured. No shader/appquantization/horse/parkedasset/collision/GPU/fullpicture acceptance.'};
fs.writeFileSync(P+'ACTUAL-WHOLE-YARD-CLEARANCE.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,cases:undefined},null,2));
