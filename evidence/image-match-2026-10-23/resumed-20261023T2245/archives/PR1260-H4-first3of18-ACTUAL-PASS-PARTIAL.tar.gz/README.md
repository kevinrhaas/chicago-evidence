First3 completed smoke groups on the NEW exact head5d9d44646f49c69a4add36ece56bfbdab8caad70. This is partial coverage, not a full smoke PASS.

Actual transcripts verify exact checkout, requested viewport/stage, terminal success, zero failed checks and zero page errors: desktop15(34/0), mobile15(34/0), mobile8(21/0). Snapshot06:25 shows3 successes,10 running and5 queued. Hosted gate and moving-frames are still running; report passed. The earlier6bf matrix remains historical and is not borrowed.

Original18-run binding is preserved as request provenance, not results. Raw completed job logs and metadata supply the actual result evidence. The durable observer polls only GET requests every five minutes, writes its own /tmp evidence, and stops after collecting all18 terminal logs. No source/label/claim/lap/merge/dispatch/cancellation or heavy work was performed by this observer. No final approval is implied.
