"""Durable read-only polling schedule for the already-bound PR1260 head."""
import pathlib,json,subprocess,time,datetime,os
OUT=pathlib.Path('/tmp/PR1260-head5d9d4464-watch')
HEAD='5d9d44646f49c69a4add36ece56bfbdab8caad70'
CMD=['python','/tmp/PR1260-next-head-watch/watch_controller.py','--dispatch','/workspace/T3081-PR1260-smoke-newhead03/DISPATCH.json','--head',HEAD,'--out',str(OUT),'--harvest']
STATE=OUT/'WATCHER_STATE.json'

def utc():return datetime.datetime.now(datetime.timezone.utc)
def state(phase,**values):
    data={'pid':os.getpid(),'expected_head':HEAD,'phase':phase,'heartbeat_at':utc().isoformat(),**values}
    temp=STATE.with_suffix('.tmp');temp.write_text(json.dumps(data,indent=2)+'\n');temp.replace(STATE)

def latest_time():
    snapshots=sorted(OUT.glob('snapshot-*.json'))
    return datetime.datetime.fromisoformat(json.loads(snapshots[-1].read_text())['at']) if snapshots else utc()-datetime.timedelta(seconds=300)

next_due=latest_time()+datetime.timedelta(seconds=300)
print(json.dumps({'observer_started':utc().isoformat(),'pid':os.getpid(),'next_poll':next_due.isoformat(),'scope':'GET-only observer; no source/CI mutations'}),flush=True)
last_summary=None
while True:
    delay=(next_due-utc()).total_seconds()
    if delay>0:
        state('WAITING',next_poll_at=next_due.isoformat(),last_summary=last_summary)
        time.sleep(min(45,delay));continue
    started=utc();state('POLL_RUNNING',poll_started_at=started.isoformat(),last_summary=last_summary)
    q=subprocess.run(CMD,capture_output=True,text=True)
    stamp=started.strftime('%Y%m%d-%H%M%S-%f');(OUT/('observer-output-'+stamp+'.json')).write_text(q.stdout)
    if q.stderr:(OUT/('observer-stderr-'+stamp+'.txt')).write_text(q.stderr)
    if q.returncode:
        event={'at':utc().isoformat(),'exit':q.returncode,'stderr':q.stderr[-1000:],'status':'READ_ERROR_NOT_A_CI_VERDICT'}
    else:
        try:
            parsed=json.loads(q.stdout);last_summary=parsed
            event={k:parsed.get(k) for k in ['at','counts','actual_terminal_log_count','actual_verified_successes','all_18_success','read_errors','log_read_errors']}
            event['failed_runs']=[{k:r.get(k) for k in ['id','viewport','stage','conclusion']} for r in parsed.get('failed_runs',[])]
            event['PR_head']=parsed.get('PR_head');event['dev']=parsed.get('dev');event['required_checks']=parsed.get('required_checks',[])
        except Exception as e:event={'at':utc().isoformat(),'status':'UNREADABLE_OUTPUT_NOT_A_CI_VERDICT','error':str(e)}
    with (OUT/'OBSERVER_EVENTS.jsonl').open('a') as f:f.write(json.dumps(event)+'\n')
    print(json.dumps(event),flush=True)
    if q.returncode==0 and last_summary and last_summary.get('actual_terminal_log_count')==18 and not last_summary.get('read_errors') and not last_summary.get('log_read_errors'):
        state('COMPLETE_18_TERMINAL_LOGS',completed_at=utc().isoformat(),last_summary=last_summary)
        break
    next_due=started+datetime.timedelta(seconds=300)
