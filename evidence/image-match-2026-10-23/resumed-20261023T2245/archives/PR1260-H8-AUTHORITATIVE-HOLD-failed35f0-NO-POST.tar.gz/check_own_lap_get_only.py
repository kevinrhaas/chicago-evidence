"""GET-only ownership evidence. Contains no reclaim, release or other mutation."""
import pathlib,datetime,json,subprocess,argparse
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',required=True);a=ap.parse_args();out=pathlib.Path(a.out);out.mkdir(exist_ok=False)
def get(path):
    q=subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/'+path],capture_output=True,text=True)
    if q.returncode:raise RuntimeError(q.stderr[-800:])
    return json.loads(q.stdout)
expected='f83eef4a32a34ce0b3ccb68c859b310a87e82fe3'
ref=get('git/ref/heads/lap/pr-1260');pr=get('pulls/1260');commit=get('git/commits/'+ref['object']['sha']);now=datetime.datetime.now(datetime.timezone.utc);stamp=datetime.datetime.fromisoformat(commit['committer']['date'].replace('Z','+00:00'));expiry=stamp+datetime.timedelta(hours=3)
r={'at':now.isoformat(),'expected_own_marker':expected,'ref':ref,'commit':commit,'PR':{k:pr[k] for k in ['state','merged','merged_at']},'marker_exact':ref['object']['sha']==expected,'expected_owner_prefix':commit['message'].startswith('lap PR #1260 — continuing root owner '),'expected_empty_tree':commit['tree']['sha']=='4b825dc642cb6eb9a060e54bf8d69288fbee4904' and not commit.get('parents'),'expiry':expiry.isoformat(),'strictly_stale':now>expiry,'normal_reclaim_armed':False,'required_before_any_reclaim':'Fresh parent follow-up authorization, exact unchanged own marker, open/unmerged PR, positive nativeSTALE, normal CAS only; no force/release/manual timestamps'}
(out/'GET_ONLY_OWNERSHIP.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['at','marker_exact','expected_owner_prefix','expected_empty_tree','expiry','strictly_stale','normal_reclaim_armed']},indent=2))
