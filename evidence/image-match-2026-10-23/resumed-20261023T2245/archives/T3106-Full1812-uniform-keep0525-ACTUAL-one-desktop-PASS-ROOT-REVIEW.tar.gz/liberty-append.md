

### L-1812-full-flora-3106 — Finish the Full woodland sweep

**Decision:** The combined first-fort desktop application case exposed 1812 Full reaching its unchanged 4700-tree backstop at effective keep 0.700. That native failure is retained. Apply the same existing uniform acceptance thinning used for 1812 Light to Full alone: multiply Full keep by 0.75, giving 0.525. The choice is a renderer density reconstruction, not a change to source species densities or the historical wood's extent. No position predicate clips the north end, and no stated planting is thinned. Keep the 4700 cap, its hard failure report, all collision/water/plot rules, the repaired garden stems, 1812 Light at 0.225, Balanced at 0.500 and every other scene unchanged. Actual Full app count, northern reach and declared plantings must pass before canonical adoption; neither a cap increase nor an exception to a failing loader message substitutes for that proof. L-1812-flora-3106's other choices remain.

**Ticket:** T-3106, prerequisite for T-3105.
**Recorded:** 2026-10-24.
