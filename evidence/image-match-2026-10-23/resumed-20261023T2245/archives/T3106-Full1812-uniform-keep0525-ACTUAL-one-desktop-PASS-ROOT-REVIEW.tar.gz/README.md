# T-3106 Full-only follow-up

RESULT.json is the bounded verdict. This packet extends the already archived Light/planting repair; that earlier packet remains immutable. Original canonical Full4700cap failure stays FAIL. No cleanDAFull browser is represented as run: exact frozen native-planter input binding plus actual Full sweep/count establish scope.

runtime-full-increment.patch is the one-file change from the previousT3106 native trees.js. SOURCE-FINAL.json binds exact preimages. liberty-append.md is append-only source admission; status-roadmap-append.md records actual proof. Native742liberty output and a five-file incremental patch reconstruct the isolated worktree, but canonical combined output must be regenerated rather than hand-merged.

The one actual desktopFull browser PASSes:3738/4700trees, zero hard flora errors, all72stated plantings byte/semantic exact to failedcase, north1117.747m, topdecile2509. Light remains0.225, Balanced0.500 and everyother scene unchanged. No fullgate, codecommit, push, PR, merge or image acceptance. Browser/export/heavy lane CLEAR.
