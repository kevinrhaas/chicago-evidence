"""Read-only continuation: run only after native combined publish closes."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, subprocess
P=argparse.ArgumentParser();P.add_argument('--publish-reaper',required=True);P.add_argument('--publish-log',required=True);args=P.parse_args()
R=Path('/workspace/chicago');A=R/'chicago/4d';S=R/'site/4d';O=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
save=lambda n,d:(O/n).write_text(json.dumps(d,indent=2)+'\n')
assert not (O/'POSTPUBLISH-RESULT.json').exists()
receipt=Path(args.publish_reaper);rp=load(receipt)
assert rp['command_exit']==0 and rp['all_children_reaped']is True and any('publish.sh' in x for x in rp['command'])
assert Path(args.publish_log).is_file()
native=load(O/'RESULT.json');assert native['status']=='ACTUAL_BE501_COMPOSITE_NATIVE_EARLY_INPUTS_PASS_PUBLISHED_PENDING'
protected=load(O/'PROTECTED.json')+load(O/'EXTRA-PHYSICAL-LIBRARY.json')
for row in protected:assert sha(R/row['path'])==row['sha256'],row['path']
for rel,digest in load(O/'ALL706.json').items():assert sha(R/rel)==digest,rel
priorpath=Path('/workspace/early-four-623e-dated-app-reuse-20261029/RESULT.json');prior=load(priorpath)
seen={};bindings=[]
for name,digest in prior['selected_current_input_hashes'].items():
 p=Path(name);got=sha(p);assert got==digest,name
 seen[name]=got;bindings.append({'path':name,'sha256':got,'current_bytes':p.stat().st_size,'dated_selected_current_bytes_exact':True})
# Library globals/grades are explicitly bound to checked native source above.
# Native liberties intentionally contain incoming unrelated1904 records, so retain
# only the exact29 four-target rows and assert its published consumer matches native.
lib=load(A/'data/liberties.json');assert load(S/'data/liberties.json')==lib
subjects={'miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832'}
relevant=lambda x:bool(subjects.intersection(x.get('subjects',[])))or any(c.get('structure')in subjects for c in x.get('covers',[]))
rows={x['id']:x for x in lib['liberties']if relevant(x)}
env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
old=json.loads(subprocess.check_output(['git','show','f683573f3f17db531d5513faed51a05fe4108021:chicago/4d/data/liberties.json'],cwd=R,env=env))
assert rows=={x['id']:x for x in old['liberties']if relevant(x)} and len(rows)==29
save('POSTPUBLISH-BINDINGS.json',bindings)
result={'schema':'CHICAGO_EARLY_FOUR_COMPOSITE_INPUT_REUSE_V1','status':'ACTUAL_COMPOSITE_EARLY_SOURCE_AND_PUBLISHED_INPUT_REUSE_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'own_checked_head':native['own_checked_head'],'accepted_upstream':native['accepted_upstream'],
 'source_native_audit':{'path':str(O/'RESULT.json'),'sha256':sha(O/'RESULT.json')},
 'actual_native_publish_reaper':{'path':str(receipt),'sha256':sha(receipt)},'actual_native_publish_log':{'path':args.publish_log,'sha256':sha(Path(args.publish_log))},
 'protected_source_bindings_exact':len(load(O/'PROTECTED.json')),'extra_physical_library_bindings_exact':12,'all706_log_frame_models_exact':True,'all353_recipes_actual_fresh_at_native_audit':True,
 'published_and_selected_native_dated_bindings_exact':len(bindings),'published_renderer_picture_bindings_exact':prior['renderer_and_picture_bindings_count'],'published_terrain_bindings_exact':len(prior['terrain_and_heightfield_bindings']),
 'four_native_and_published_sidecar_WEB_camera_grade_photo_STORE_inputs_preserved':True,'all29_early_relevant_liberty_rows_exact_and_native_published_full_output_equal':True,
 'dated_actual_app_evidence':{'selected_reuse_receipt':str(priorpath),'selected_reuse_receipt_sha256':sha(priorpath),'current_Miller_Full_BOTH_manifest':'/workspace/miller-current-final-app-closed-root-20261029/MANIFEST.json','current_Miller_Full_BOTH_manifest_sha256':sha(Path('/workspace/miller-current-final-app-closed-root-20261029/MANIFEST.json'))},
 'limits':['No new browser invocation or whole renderer matrix is claimed. Dated actual app proofs apply only to byte-exact selected consumers.','Unrelated incoming1904 geometry and global native liberties intentionally change; required current gate and phone evidence are separate.','Miller new10mm stack stays bound to fresh Full BOTH proofs; no equivalence to old450mm model is claimed.']}
assert_stable=all(sha(Path(p))==digest for p,digest in seen.items());assert assert_stable
save('POSTPUBLISH-RESULT.json',result);print(json.dumps(result,indent=2))
