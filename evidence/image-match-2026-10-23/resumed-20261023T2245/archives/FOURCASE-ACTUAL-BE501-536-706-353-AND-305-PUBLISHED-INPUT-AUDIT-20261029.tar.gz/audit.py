from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True
R=Path('/workspace/chicago'); A=R/'chicago/4d'; O=Path(__file__).parent
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1')
OLD='f683573f3f17db531d5513faed51a05fe4108021';UP='be501b034cd24410843eedced9e1bf1b52a4ff4f'
g=lambda *args:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=R,env=E)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
save=lambda n,d:(O/n).write_text(json.dumps(d,indent=2)+'\n')
def tree(ref):
 d={}
 for row in g('ls-tree','-r',ref).decode().splitlines():
  meta,p=row.split('\t',1); mode,kind,blob=meta.split();d[p]=(mode,kind,blob)
 return d
def blobsha(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
head=g('rev-parse','HEAD').decode().strip();assert head==OLD
assert g('rev-parse','MERGE_HEAD').decode().strip()==UP
before=load(Path('/workspace/early-four-be501-native-lap-root-20261029/BEFORE.json'))
old=tree(OLD); incoming=tree(UP); staged={}
for row in g('ls-files','--stage').decode().splitlines():
 meta,p=row.split('\t',1);mode,b,s=meta.split();assert s=='0';staged[p]=(mode,'blob',b)
ids=['miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832']
protected=[p for p in set(old)|set(staged)if p.startswith('chicago/4d/generators/archetypes/')or(p.startswith('chicago/4d/renderers/web/')and p!='chicago/4d/renderers/web/js/changelog.js')or any('/'+s+'/'in p or p.endswith('/'+s+'.json')for s in ids)]
assert len(protected)>=527
rows=[]
for p in sorted(protected):
 assert old.get(p)==staged.get(p),p
 assert blobsha((R/p).read_bytes())==old[p][2],p
 rows.append({'path':p,'git_blob':old[p][2],'sha256':sha(R/p)})
save('PROTECTED.json',rows)
extra=['data/structure_grades.json','data/enclosures/town_entrance_aprons.json','data/signage/town_business_signboards.json','data/yard/town_trade_goods.json','data/yard/town_woodpiles.json','data/reconstruction/name_pool_keys.json','data/reconstruction/1835_placement_policy.json']
extra=['chicago/4d/'+p for p in extra]+['chicago/prairie_1904_v1/data/images.json','chicago/prairie_1904_v1/research/images/STORE.json','chicago/prairie_1904_v1/research/images/stream-early-chicago-lighthouse-reference.json','chicago/prairie_1904_v1/research/images/stream-early-chicago-miller-hogan-references.json','chicago/prairie_1904_v1/research/images/stream-st-mary-reference.json']
for p in extra:assert old[p]==staged[p] and blobsha((R/p).read_bytes())==old[p][2],p
save('EXTRA-PHYSICAL-LIBRARY.json',[{'path':p,'sha256':sha(R/p)}for p in extra])
models=before['all706_native_model_bindings']; assert len(models)==706
for p,h in models.items():assert sha(R/p)==h,p
save('ALL706.json',models)
current=load(A/'assets/manifest.json')['assets']; prior=json.loads(g('show',OLD+':chicago/4d/assets/manifest.json'))['assets']
family={k:v for k,v in prior.items()if v.get('archetype')in {'log_dwelling','frame_dwelling'}};assert len(family)==353
sys.path.insert(0,str(A/'generators'));import mesh_inputs
fresh=[]
for n,row in sorted(family.items()):
 assert current[n]==row,n
 st=load(A/'data/structures'/(row['structure_id']+'.json'));phase=next(x for x in st['phases']if x['id']==row['phase_id'])
 got=mesh_inputs.structure_inputs_sha(st,phase,row['archetype']);assert got==row['inputs_sha256'],n
 fresh.append({'name':n,'inputs_sha256':got,'manifest_row_exact':True})
save('ALL353-FRESH.json',fresh)
# Both authored registries' changed entries must survive; unchanged incoming entries
# are allowed to differ where the four-ticket branch deliberately changed them.
base=g('merge-base',OLD,UP).decode().strip();registry=[]
for p in ['chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json']:
 b=json.loads(g('show',base+':'+p));o=json.loads(g('show',OLD+':'+p));u=json.loads(g('show',UP+':'+p));c=load(R/p)
 key='assets' if 'assets' in b else 'masters'
 b=b[key];o=o[key];u=u[key];c=c[key]
 for side,doc in [('own',o),('incoming',u)]:
  changes={k:v for k,v in doc.items()if b.get(k)!=v}
  for k,v in changes.items():assert c[k]==v,(p,side,k)
  registry.append({'path':p,'side':side,'all_changed_entries_preserved':True,'entries':sorted(changes)})
save('ASSET-REGISTRY-UNION.json',registry)
# Full native four-sidecar objects are byte-bound in the protected set, then
# compared to frozen actual dated native consumer postimages.
F=Path('/workspace/early-four-623e-dated-app-reuse-20261029'); cases=[]
for label,sid in zip(['miller','hogan','mary','lighthouse'],ids):
 p=A/'data/sidecars/1835'/(sid+'.json');assert load(p)==load(F/label/'CURRENT-native-sidecar.json')
 cases.append({'structure':sid,'native_sidecar_sha256':sha(p),'dated_full_native_object_exact':True})
lib=load(A/'data/liberties.json')['liberties'];oldlib=json.loads(g('show',OLD+':chicago/4d/data/liberties.json'))['liberties']
relevant=lambda x:bool(set(ids)&set(x.get('subjects',[])))or any(c.get('structure')in ids for c in x.get('covers',[]))
lr={x['id']:x for x in lib if relevant(x)};olr={x['id']:x for x in oldlib if relevant(x)};assert lr==olr
save('CASES-NATIVE.json',cases)
result={'status':'ACTUAL_BE501_COMPOSITE_NATIVE_EARLY_INPUTS_PASS_PUBLISHED_PENDING','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'own_checked_head':OLD,'accepted_upstream':UP,'primary_HEAD_unchanged':g('rev-parse','HEAD').decode().strip()==head,'protected_binding_count':len(rows),'all_protected_source_and_index_objects_exact':True,'extra_physical_library_input_count':len(extra),'all706_log_frame_model_bytes_exact':True,'all353_manifest_rows_exact_and_actual_native_recipes_fresh':True,'both_asset_registry_sides_changed_entries_preserved':True,'full_four_native_sidecars_exact_to_dated_current_inputs':True,'relevant_liberty_rows_exact':len(lr),'native_picture_library_STORE_grade_camera_WEB_inputs_exact':True,'published_proof':'PENDING until root closes native current publish; no current published claim','limits':['Read-only source/index/ref audit; no producer, renderer, fetch, source writes or qualification relabeling.','Global native liberty output and incoming unrelated1904 geometry intentionally differ.','Current gate/phone/published-byte evidence are separate actual root runs.']}
save('RESULT.json',result);print(json.dumps(result,indent=2))
