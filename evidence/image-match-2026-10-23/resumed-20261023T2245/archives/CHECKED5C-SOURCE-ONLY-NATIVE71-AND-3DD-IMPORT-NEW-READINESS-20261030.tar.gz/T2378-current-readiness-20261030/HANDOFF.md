# T-2378: current-model diagnostic capture is the next action

This small readiness packet supersedes the Oct24 inventory only for current bindings and one concrete camera seed. It makes no primary, ticket, site or Git changes. No Blender/browser/native render ran. The original ticket remains unfinished, and no match verdict exists.

The useful next step is ONE actual native `photo_match` baseline from `keyed-1831-diagnostic-seed.json`, after the coordinator grants browser CPU and resource headroom. The house in the keyed image appears tall and compact relative to the current low, long model. This merits the bounded baseline rather than another unbounded research cycle. The camera fits only the rough horizontal envelope and ground; source roof height is withheld to make that comparison useful. It is a diagnostic seed, not a solved camera or a historical viewing location. Use the actual comparison to adjust this one camera within the picture's broad uncertainty before selecting at most one visible form correction. Do not change coordinates or a shared producer to rescue a panorama fit.

## Held pictures and publication

1. Keyed whole panorama, `/workspace/T2378-readiness-bd316-20261024/known-ticket-whole-panorama.jpg`, 1920×1042. This is the ticket's `chicago_fort_dearborn_1831_1.jpg`; source `kinzie_1857_chicago_1831_panorama`. The Beaubien house is the large left-of-fort member near x204–312, not the isolated foreground wash-house, north-bank Kinzie group, or separately keyed Dean house. Rough pixel box is an inspection aid with about8px uncertainty, not calibrated source geometry.
2. Unkeyed whole panorama, `dependent-unkeyed-whole-panorama.jpg`, 1920×1115, `chicago_fort_dearborn_1831_2.jpg`; inventory credits Napoleon Sarony after Kinzie, made1856, describes1831. It shows the analogous group and is still owed its own later camera/capture. The two compositions are dependent Wau-Bun-derived evidence, not two independent witnesses. No whole-book source is silently relabeled an illustration. If registered, create an accurately credited illustration record for this actual cut and keep its date distinct from the keyed reproduction.
3. Already-fetched Wentworth1881 printedp86 reproduces picture1 and explicitly annotates: “Gen. Beaubien's house was near the N.-E. cor. Michigan Avenue and South-Water Street.” Printedp87 carries Hubbard's20July1881 criticism: the cut is “certainly unlike the Fort and surroundings, as I recollect them.” These are publication/identity evidence, not two additional independent house pictures. Both pages and both whole panoramas were visually reread in this run. Their bytes are bound in `SOURCE-INVENTORY.json`.

The p86 annotation supports admitting the existing three-path source-only correction as an INFERRED working identification of the sale-located dwelling. It remains UNAPPLIED. It is the same Wentworth witness as the1839 sale narrative, not contemporary corroboration. Printed1857 Wau-Bun credit, verified1881 reproduction, and depicted1831 are separate dates. The exact original edition remains unresolved.

Existing source/inventory records license both underlying nineteenth-century illustrations as public domain. This run changes no rights status and acquires no modern Getty/Alamy surrogate or license. No remote research fetch was made. Owner's general reference-use approval is not invented proof of public-domain status.

## Current model and confidence

`CURRENT-BINDINGS.json` and `CURRENT-RECIPE.json` hold the newly recomputed native recipe, current MASTER/WEB hashes, selected manifest row, producer/preimages and parameters. Current MASTER is byte-exact to the Oct24 inspected49,644B model: one storey,2.5m wall,35°gable, one stack, reconstructed12.192×6.096m footprint. Recipe hash has changed with upstream default-preserving shared work; do not reuse the old c301 input hash. The actual current recomputation equals the native manifest. No old prototype was substituted.

No canonical Beaubien camera folder exists. The current Images index carries one credited link for the keyed panorama; the sidecar remains inferred because there is neither a pictured ruling nor a camera. Adding a canonical diagnostic camera can change the derived structure grade: make an explicit identity/pictured ruling decision and run native grade/scene owners instead of allowing an accidental confidence promotion. Per-attribute confidence remains separate.

Preserve this dwelling, the separately modeled U.S. Factor's House about140m south, and the Dean house as separate identities. Never borrow Hubbard's two-storey squared-log Factory description. The1822 phase bound is not this house's construction date. The1831 picture's identity is inferred and survival of its visible fabric to July1835 remains a declared assumption. Do not introduce a later house or silently backdate later changes. Keep the owner's folded house/barn/trading-post arrangement, existing occupants and review/removal prose/flags; no new figures are proposed.

## Native execution and stopping rule

After an explicit CPU/resource grant, from `/workspace/chicago/chicago/4d` with shared resume environment and primary stable:

```sh
node tools/photo_match.mjs /workspace/T2378-current-readiness-20261030/keyed-1831-diagnostic-seed.json --out /workspace/T2378-current-readiness-20261030/native-baseline
```

Recheck the guarded record/producers/MASTER/WEB before execution. The command writes a match beside the EXTERNAL seed and output to the external directory. It loads the actual current master without `--glb`. A source wrapper must also enforce existing workspace/TMP floors and reap only this job's children; this packet grants no CPU lease. `near_m250` and far500 retain all actual vertices per the arithmetic check. Native perspective, lighting/materials, image residuals, page-error checks and reaping are still UNRUN. No screenshot, render or match is claimed from the projection JSON.

Inspect massing/roof and stack ownership first. The broad source/model proportion difference may be street-noticeable, but is not yet a proven geometry defect. Source ink, perspective freedom and the dependent second composition do not justify an exact story count, white paint, bay count or stack count before that comparison. Use existing data-only controls if one clear correction survives: those can need only this one MASTER plus its normal WEB derivative. A shared log-producer edit would affect the whole current native family and is not proposed.

Use T3153: only missing/wrong form/material/count or greater-than0.3m differences stay open; pixel/camera disagreement is within tolerance. One original sign-off, no new photo tickets/splits. The second held composition, all actual before/after source captures, full app Images/Liberties/ground/access at390×780 and desktop, applicable gate/smoke/PR/dev merge remain owed before original-ticket closure.

This packet should join the coordinator's next substantive recovery checkpoint; it needs no standalone archive or publication.
