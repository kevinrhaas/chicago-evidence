"""Read-only native recipe/GLB audit and ONE unrendered diagnostic camera seed.

No primary writes, Git mutation, Blender, browser, network, or image editing.
"""
import dataclasses, datetime, hashlib, json, math, os, pathlib, struct, subprocess, sys

os.sched_setaffinity(0, {2})
P = pathlib.Path(__file__).parent
R = pathlib.Path('/workspace/chicago/chicago/4d')
OLD = pathlib.Path('/workspace/T2378-readiness-bd316-20261024')
SID = 'jb_beaubien_homestead'
ASSET = SID + '__log_1822.glb'
sha = lambda b: hashlib.sha256(b).hexdigest()
def binding(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}
def emit(name, value):
    (P / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

paths = ['data/structures/' + SID + '.json', 'data/sources/kinzie_1857_chicago_1831_panorama.json',
         'data/sources/kinzie_waubun_1856.json', 'data/sources/wentworth_1881_fort_dearborn.json',
         'docs/RESEARCH/jb_beaubien_homestead.md', 'generators/archetypes/log_dwelling.py',
         'generators/archetypes/log_dwelling_params.py', 'generators/mesh_inputs.py',
         'tools/photo_match.mjs', 'tools/photo_match_group.mjs',
         'assets/gltf/' + ASSET, 'assets/web/' + ASSET]
before = {p: binding(R / p) for p in paths}
rec = json.loads((R / paths[0]).read_text()); ph = rec['phases'][0]
sys.path.insert(0, str(R / 'generators'))
import mesh_inputs
params = mesh_inputs.resolve_params('log_dwelling', ph, rec)
recipe = mesh_inputs.structure_inputs_doc(rec, ph)
actual = mesh_inputs.structure_inputs_sha(rec, ph)
manifest = json.loads((R / 'assets/manifest.json').read_text())
web = json.loads((R / 'assets/manifest.web.json').read_text())
assert actual == manifest['assets'][ASSET]['inputs_sha256']
master = (R / 'assets/gltf' / ASSET).read_bytes()
assert sha(master) == web['masters'][ASSET]
assert master == (OLD / 'current-master.glb').read_bytes()
n = struct.unpack_from('<I', master, 12)[0]
gltf = json.loads(master[20:20+n]); off = 20 + n
binary = master[off+8:]
vertices = []
for primitive in gltf['meshes'][0]['primitives']:
    a = gltf['accessors'][primitive['attributes']['POSITION']]
    v = gltf['bufferViews'][a['bufferView']]
    assert a['componentType'] == 5126 and a['type'] == 'VEC3'
    start = a.get('byteOffset', 0) + v.get('byteOffset', 0)
    for i in range(a['count']):
        x, y, z = struct.unpack_from('<fff', binary, start+i*v.get('byteStride', 12))
        vertices.append((x, -z, y))

# Deliberately finite, unpitched NE trial: an invented 300 m distance, 40-degree
# oblique, 2.5 m eye, current reconstructed footprint. Horizontal envelope only
# is scaled to the approximately hand-read house width in the keyed panorama.
# The datum is NOT an inferred historical viewpoint or a surveyed scene control.
theta = math.radians(40); distance = 300.; center = (params.width_m/2, params.depth_m/2, 2.5)
right = (-math.cos(theta), math.sin(theta), 0.)
up = (0., 0., 1.)
forward = (-math.sin(theta), -math.cos(theta), 0.)
eye = [center[0]+distance*math.sin(theta), center[1]+distance*math.cos(theta), center[2]]
def unit_project(v):
    d = [v[i]-eye[i] for i in range(3)]
    z = sum(d[i]*forward[i] for i in range(3))
    assert 0 < z < 500
    return [sum(d[i]*right[i] for i in range(3))/z, -d[2]/z, z]
q = [unit_project(v) for v in vertices]
focal = 108. / (max(v[0] for v in q)-min(v[0] for v in q))
cx = 258. - focal*(max(v[0] for v in q)+min(v[0] for v in q))/2
cy = 440. - focal*max(v[1] for v in q)
camera = {'structure_id': SID, 'source_id': 'kinzie_1857_chicago_1831_panorama',
          'photo': '../T2378-readiness-bd316-20261024/known-ticket-whole-panorama.jpg',
          'image_px': [1920, 1042], 'principal_px': [cx, cy], 'focal_px': focal,
          'eye': eye, 'yaw_deg': 220., 'basis_right_up_forward': [right, up, forward],
          'near_m': 250., 'sky': 'overcast', 'diagnostic_only': True,
          'solve': 'UNRENDERED DIAGNOSTIC SEED, NOT A SOLVED OR ACCEPTED CAMERA. '
                   'One current-model trial, isolated house only; no scene placement or compound context. '
                   'Uses current 12.192 x 6.096 m reconstructed footprint as a convenience scale, '
                   'not a source dimension. Assumed NE oblique 40 degrees and 300 m distance, '
                   'horizontal camera at 2.5 m; basis is right/up/forward in u/v/height. '
                   'Fits only rough full-house horizontal envelope x204..312 and ground y440 '
                   'read by eye from the original keyed 1920x1042 image. '
                   'Source roof near y350 is WITHHELD from this fit: compare after actual photo_match. '
                   'No homologous-point residual or independent camera controls yet exist. '
                   'Monochrome print does not attest paint; overcast lighting is a diagnostic choice. '
                   'Near plane250m is ahead of the complete current-model depth range and far500m retains all vertices. '
                   'Common native flat review ground does not reproduce app terrain. '
                   'Wentworth1881 p86 supports only an inferred identity; depicted1831 fabric survival '
                   'to July1835 is an explicit assumption. Hubbard p87 criticizes fort/geography; '
                   'do not alter surveyed coordinates to fit. Never publish this pose as From this spot.'}
emit('keyed-1831-diagnostic-seed.json', camera)
projected = [[cx+focal*x, cy+focal*y] for x,y,z in q]
emit('CURRENT-RECIPE.json', recipe)
emit('PROJECTION-NOT-RENDER.json', {
    'method': 'CPU arithmetic on actual current MASTER vertices; NO raster, material, native render or match',
    'camera_fit_status': 'UNFITTED seed; only rough horizontal envelope/ground normalization',
    'approximate_source_envelope_hand_read_px': [204, 350, 312, 440],
    'source_envelope_uncertainty_px': 8,
    'source_top_is_withheld_from_fit': True,
    'current_projected_all_vertices_bbox_px': [[min(v[i] for v in projected) for i in range(2)],
                                               [max(v[i] for v in projected) for i in range(2)]],
    'depth_range_m': [min(v[2] for v in q), max(v[2] for v in q)],
    'source_to_model_interpretation': 'Tall/compact source silhouette versus long/low current model is a visible-form hypothesis to inspect in ONE actual baseline. Camera freedom and ambiguous small ink details prevent choosing a metric height or two storeys from this arithmetic.',
    'native_render_run': False, 'matches_claimed': False})
picture_data = json.loads((R / 'data/pictures/1835.json').read_text())
sidecar = json.loads((R / ('data/sidecars/1835/' + SID + '.json')).read_text())
emit('CURRENT-BINDINGS.json', {
    'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),
    'primary_has_concurrent_native_writer': True,
    'guards': before, 'native_recipe_sha256': actual,
    'manifest_row': manifest['assets'][ASSET],
    'native_web_master_binding': web['masters'][ASSET],
    'current_master_exact_prior_Oct24': True,
    'native_family_count': sum(v.get('archetype') == 'log_dwelling' for v in manifest['assets'].values()),
    'params': dataclasses.asdict(params),
    'sidecar_observed_grade': sidecar['grade'], 'sidecar_placement': sidecar['placement'],
    'sidecar_review_required': sidecar['review_required'],
    'current_credited_images_rows': picture_data['by_structure'].get(SID),
    'canonical_camera_folder_exists': (R / ('data/reference_views/' + SID)).exists(),
    'prior_identity_patch': binding(OLD / 'prior-T-2378-primary-source.patch'),
    'guarded_paths_byteexact_after_read': all(binding(R/p) == v for p,v in before.items()),
    'writes': 'ONLY this external readiness directory; no primary/Git/ticket/site write'})
assert all(binding(R/p) == v for p,v in before.items())
result = subprocess.run(['git','-C',str(R.parents[1]),'apply','--check',str(OLD/'prior-T-2378-primary-source.patch')],capture_output=True,text=True)
emit('IDENTITY-PATCH-CHECK.json', {'command': result.args, 'exit_code': result.returncode,
                                 'stdout': result.stdout, 'stderr': result.stderr, 'applied': False})
print('PASS native recipe fresh; MASTER prior-exact; guarded reads exact; ONE seed prepared, native rendering UNRUN')
