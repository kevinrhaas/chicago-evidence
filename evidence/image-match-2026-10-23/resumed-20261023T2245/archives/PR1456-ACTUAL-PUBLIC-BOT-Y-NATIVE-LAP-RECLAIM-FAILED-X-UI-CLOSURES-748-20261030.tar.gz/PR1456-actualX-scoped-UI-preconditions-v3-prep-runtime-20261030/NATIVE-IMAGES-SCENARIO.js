    const images = await page.evaluate(async () => {
      const api = window.__chicago4d;
      api.pick('sauganash_hotel');
      document.querySelector('#popup [data-pop-tab="evidence"]')?.click();
      const pane = () => document.querySelector('#popup [data-pop-pane="images"]');
      const deadline = Date.now() + 20_000;
      while (/LOADING IMAGE INDEX/.test(pane()?.textContent ?? 'LOADING IMAGE INDEX') && Date.now() < deadline) {
        await new Promise((r) => setTimeout(r, 100));
      }
      const srcBefore = pane()?.querySelectorAll('img[src]').length ?? -1;
      document.querySelector('#popup [data-pop-tab="images"]')?.click();
      const p = pane();
      const items = [...(p?.querySelectorAll('.pop-pic-list li, .pop-pic-tile') ?? [])];
      const out = {
        shown: !!p && !p.hasAttribute('hidden'),
        srcBefore,
        status: p?.querySelector('.pop-pic-status')?.textContent.trim() ?? p?.textContent.trim().slice(0, 80),
        items: items.length,
        uncredited: items.filter((li) => !(li.querySelector('.pop-pic-meta, .pop-pic-tile-credit')?.textContent.trim())).length,
        tabCount: document.querySelector('#popup [data-pop-tab="images"] .pop-count')?.textContent.trim() ?? '',
      };
      document.querySelector('#popup [data-pop-tab="evidence"]')?.click();
      api.popup.close();
      return out;
    });
    check(`${label}: the Images tab lists the building's pictures, each credited, and loads none until opened (T-2389)`,
      images.shown && images.srcBefore === 0 && images.items >= 2 && images.uncredited === 0
      && images.tabCount === String(images.items),
      JSON.stringify(images));

