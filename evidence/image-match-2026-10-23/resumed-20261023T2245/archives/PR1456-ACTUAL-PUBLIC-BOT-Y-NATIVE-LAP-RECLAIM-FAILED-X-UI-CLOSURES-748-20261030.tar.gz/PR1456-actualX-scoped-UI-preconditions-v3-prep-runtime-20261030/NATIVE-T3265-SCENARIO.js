        const inspectTabs1904 = await page.evaluate(async () => {
          const a = window.__chicago4d;
          const wait = (f, n = 100) => new Promise(async (res) => { for (let i = 0; i < n && !f(); i++) await new Promise((r) => setTimeout(r, 100)); res(f()); });
          const root = () => document.getElementById('nav-app-inspect');
          async function open(id) {
            a.pick(id);
            await a.navigator.select('inspect');
            a.navigator.open(2);   // as a visitor opens the sheet to read it (a phone docks it otherwise)
            await wait(() => root()?.dataset.structure === id && !!root().querySelector('.insp-tabs'));
          }
          async function tab(key) {
            root().querySelector(`[data-insp-tab="${key}"]`)?.click();
            await wait(() => ['yes', 'failed'].includes(root().querySelector(`[data-insp-pane="${key}"]`)?.dataset.filled ?? (key === 'overview' ? 'yes' : '')));
            const pane = root().querySelector(`[data-insp-pane="${key}"]`);
            return { shown: !!pane && !pane.hidden && pane.checkVisibility(), filled: key === 'overview' ? 'yes' : pane?.dataset.filled,
              text: pane?.innerText ?? '', html: pane?.innerHTML ?? '',
              selected: root().querySelector(`[data-insp-tab="${key}"]`)?.getAttribute('aria-selected') };
          }
          const current = () => root().querySelector('.insp-tab[aria-selected="true"]')?.dataset.inspTab ?? null;
          await open('glessner_house');
          const people = await tab('people');
          const out = { people: [...root().querySelectorAll('[data-insp-pane="people"] [data-person-card] .nav-person-name')].map((n) => n.textContent.trim()) };
          // T-3265: a person opens their own card in place (never the full People list), with
          // their story, How we know and the census line; Back returns to the household, on them.
          const pane = root().querySelector('[data-insp-pane="people"]');
          pane.querySelector('[data-person-card="pa1904_glessner_john_j_c1900_august_billings"]')?.click();
          await wait(() => !!pane.querySelector('.insp-person-card .insp-person-census'));
          const card = pane.querySelector('.insp-person-card');
          out.card = { app: a.navigator.app, listHidden: !!pane.querySelector('.insp-people-home')?.hidden,
            name: card?.querySelector('.insp-person-name')?.textContent ?? '',
            back: card?.querySelector('[data-person-back]')?.textContent.trim() ?? '',
            lead: card?.querySelector('.insp-person-story [data-composed]')?.textContent ?? '',
            why: card?.querySelector('.insp-person-why-title')?.textContent ?? '',
            leaf: card?.querySelector('.insp-person-leaf')?.getAttribute('href') ?? '',
            sources: card?.querySelectorAll('.insp-person-sources li').length ?? 0 };
          card?.querySelector('[data-person-back]')?.click();
          out.back = { card: !!pane.querySelector('.insp-person-card'), listShown: !pane.querySelector('.insp-people-home')?.hidden,
            focus: document.activeElement?.dataset?.personCard ?? null };
          out.story = (await tab('story')).text.includes('1885');
          await tab('photos');
          await open('pullman_house_1729_prairie');
          out.newOpensOn = current();
          await tab('design');
          await open('pullman_house_1729_prairie');
          out.sameKeeps = current();
          await a.navigator.select('home'); a.navigator.dock(); a.popup.close();
          return out;
        });
        check(`${label}: a person on Inspect's People tab opens their own card, with Back to the household (T-3265)`,
          inspectTabs1904.card?.app === 'inspect' && inspectTabs1904.card.listHidden && inspectTabs1904.card.name === 'August Billings'
          && inspectTabs1904.card.back === 'The Glessner household' && /found August Billings/.test(inspectTabs1904.card.lead)
          && /^Inferred/.test(inspectTabs1904.card.why) && /12thcensusofpopu245unit\/page\/n803/.test(inspectTabs1904.card.leaf)
          && inspectTabs1904.card.sources >= 1 && !inspectTabs1904.back.card && inspectTabs1904.back.listShown
          && inspectTabs1904.back.focus === 'pa1904_glessner_john_j_c1900_august_billings',
          JSON.stringify({ card: inspectTabs1904.card, back: inspectTabs1904.back }));
        check(`${label}: Inspect's People tab lists the Glessner household; a new building opens on Overview and the same keeps its tab (T-2639)`,
          inspectTabs1904.people.includes('John J. Glessner') && inspectTabs1904.people.includes('Frances M. Glessner')
          && inspectTabs1904.story && inspectTabs1904.newOpensOn === 'overview' && inspectTabs1904.sameKeeps === 'design',
          JSON.stringify(inspectTabs1904));
