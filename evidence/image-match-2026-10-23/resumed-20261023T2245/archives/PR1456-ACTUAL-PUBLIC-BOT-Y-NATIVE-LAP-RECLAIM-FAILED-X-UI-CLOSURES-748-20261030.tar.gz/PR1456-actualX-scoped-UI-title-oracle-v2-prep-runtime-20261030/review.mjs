/** Scoped native-app review: original4 People/Images plus unmodified native T3265/T2639. */
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire('/workspace/shared/node/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const plan=JSON.parse(fs.readFileSync(process.env.PR1456_UI_EXPECTED));
const out=process.env.PR1456_UI_OUT, viewport=process.env.PR1456_UI_VIEWPORT;
assert(['desktop','mobile'].includes(viewport)); assert(out); fs.mkdirSync(out);
const root=plan.site_parent, sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const save=(n,d)=>fs.writeFileSync(path.join(out,n),JSON.stringify(d,null,2)+'\n');
const cases=[], nativeChecks=[], errors=[], network=[], cancelled=[], serverErrors=[];
function guard(){for(const[p,s]of Object.entries(plan.immutable_selected_input_bindings))assert.equal(sha(fs.readFileSync(p)),s,p);}
guard();
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon','.ktx2':'image/ktx2'};
const server=http.createServer((req,res)=>{try{let f=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));if(!f.startsWith(root+path.sep)){res.writeHead(403).end();return;}if(fs.existsSync(f)&&fs.statSync(f).isDirectory())f=path.join(f,'index.html');if(!fs.existsSync(f)||!fs.statSync(f).isFile()){res.writeHead(404).end();return;}res.setHeader('Content-Type',types[path.extname(f)]||'application/octet-stream');fs.createReadStream(f).on('error',e=>{serverErrors.push(e.message);res.destroy(e);}).pipe(res);}catch(e){serverErrors.push(e.message);res.writeHead(500).end();}});
let browser,context,page;
const mobile=viewport==='mobile', label=mobile?'mobile 390x780':'desktop 1280x800';
const check=(name,pass,detail='')=>{nativeChecks.push({name,pass:!!pass,detail});assert(pass,`${name}: ${detail}`);};
const nativeScenario=async name=>{const row=plan.native_scenarios[name],text=fs.readFileSync(row.path,'utf8');assert.equal(sha(Buffer.from(text)),row.sha256);const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;await new AsyncFunction('page','check','label',text)(page,check,label);};
const capture=async name=>{const p=path.join(out,name+'.jpg');await page.evaluate(()=>window.__chicago4d.capture(1));await page.screenshot({path:p,type:'jpeg',quality:90});return {path:p,sha256:sha(fs.readFileSync(p)),bytes:fs.statSync(p).size};};
async function boot(year){
  context=await browser.newContext({viewport:{width:mobile?390:1280,height:mobile?780:800},hasTouch:mobile,isMobile:false,deviceScaleFactor:mobile?2:1});
  page=await context.newPage();page.setDefaultTimeout(90000);
  page.on('pageerror',e=>errors.push(e.message));
  page.on('requestfailed',r=>(r.failure()?.errorText==='net::ERR_ABORTED'?cancelled:network).push({url:r.url(),failure:r.failure()}));
  page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});});
  await context.addInitScript(()=>{localStorage.setItem('chicago4d.researcher','on');localStorage.setItem('chicago4d.settings',JSON.stringify({detail:'full'}));});
  assert.equal((await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=${year}&keep-geometry=1`)).status(),200);
  await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:240000,polling:1000});
  await page.evaluate(async()=>{const a=window.__chicago4d,end=Date.now()+90000;while(a.welcome?.state!=='world'&&Date.now()<end){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}if(a.welcome?.state!=='world')throw Error('Welcome did not enter world');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.setAnimationHold(true);a.popup.close();a.navigator.dock();await a.capture(1);});
}
try{
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
  await boot(1835);
  for(const c of plan.cases){
    guard();
    await page.evaluate(async sid=>{const a=window.__chicago4d;a.setConfidenceView(false);a.pick(sid);await a.navigator.select('inspect');a.navigator.open(2);},c.sid);
    await page.waitForFunction(sid=>document.querySelector('#nav-app-inspect')?.dataset.structure===sid,c.sid);
    await page.locator('#nav-app-inspect [data-insp-tab="people"]').click();
    await page.waitForFunction(()=>document.querySelector('#nav-app-inspect [data-insp-pane="people"]')?.dataset.filled==='yes');
    const observed=await page.locator('#nav-app-inspect [data-insp-pane="people"]').evaluate(p=>({text:p.innerText,visible:p.checkVisibility(),overflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1,resident_people:[...p.querySelectorAll('.res-people > li')].map(s=>({name:s.querySelector('.res-name')?.textContent.trim(),role:s.querySelector('.res-role')?.textContent.trim()})),person_links:[...p.querySelectorAll('.insp-person-link')].map(b=>({id:b.dataset.person??b.dataset.personCard,name:b.querySelector('.nav-person-name')?.textContent??null,role:b.querySelector('.nav-sub')?.textContent??null})),empty:p.innerText.includes('Nobody in our records lives or works here.')}));
    // Same accepted original-four People assertions; new native data-person-card selector
    // is supported alongside old data-person. No expected names, roles or order changed.
    assert(observed.visible&&!observed.overflow&&!observed.paneOverflow);
    if(c.resident_households.length){const expected=c.resident_households.flatMap(h=>h.persons);assert.deepEqual(observed.resident_people.map(r=>r.name),expected.map(r=>r.name));assert.deepEqual(observed.resident_people.map(r=>r.role),expected.map(r=>((r.occupation?r.occupation.replaceAll('_',' '):'')+(r.relationship&&r.relationship!=='head'?' · '+r.relationship.replaceAll('_',' '):'')).trim()));assert.deepEqual(observed.person_links.map(r=>r.id),c.expected_household_people_links);}
    else{const rank={head:0,wife:1,husband:1,son:2,daughter:2,child:2,servant:4},expected=[...c.directory_here].sort((a,b)=>(rank[a.relationship]??3)-(rank[b.relationship]??3)||a.name.localeCompare(b.name));assert.deepEqual(observed.person_links.map(r=>r.id),expected.map(r=>r.id));assert.deepEqual(observed.person_links.map(r=>r.name),expected.map(r=>r.name));assert.deepEqual(observed.person_links.map(r=>r.role),expected.map(r=>[r.household_name,r.relationship==='head'?'head of the household':r.relationship].filter(Boolean).join(' · ')));if(!expected.length)assert(observed.empty);}
    const runtime=await page.evaluate(sid=>{const a=window.__chicago4d,r=a.registry.get(sid);return{scene:a.scene.id,detail:a.detail,world:a.welcome.state,sidecar:{id:r?.sidecar?.id,phase:r?.sidecar?.phase,grade:r?.sidecar?.grade,placement:r?.sidecar?.placement},legacy1835PeopleSection:!!document.querySelector('.panel-tab[data-tab="people"]')&&!document.querySelector('.panel-tab[data-tab="people"]').hidden};},c.sid);
    assert.equal(runtime.scene,'1835');assert.equal(runtime.world,'world');assert.equal(runtime.detail,'full');assert.deepEqual(runtime.sidecar,{id:c.sid,phase:c.phase,grade:c.grade,placement:c.placement});assert(runtime.legacy1835PeopleSection);
    await page.evaluate(()=>{const root=document.querySelector('#nav-app-inspect');root.scrollTop=0;root.querySelector('[data-insp-pane="people"] .res-people > li, [data-insp-pane="people"] .nav-person')?.scrollIntoView({block:'start'});});
    const peopleCapture=await capture(c.sid+'-People');
    const people={sid:c.sid,status:'PASS',kind:'People',observed,runtime,capture:peopleCapture};save(c.sid+'-People-RESULT.json',people);cases.push(people);
    // Additional original-four Images checks use the exact actual published picture index.
    const images=await page.evaluate(async sid=>{const a=window.__chicago4d;await a.navigator.select('home');a.navigator.dock();a.popup.close();a.pick(sid);document.querySelector('#popup [data-pop-tab="evidence"]')?.click();const pane=()=>document.querySelector('#popup [data-pop-pane="images"]');const end=Date.now()+20000;while(/LOADING IMAGE INDEX/.test(pane()?.textContent??'LOADING IMAGE INDEX')&&Date.now()<end)await new Promise(r=>setTimeout(r,100));const srcBefore=pane()?.querySelectorAll('img[src]').length??-1;document.querySelector('#popup [data-pop-tab="images"]')?.click();const p=pane(),items=[...(p?.querySelectorAll('.pop-pic-list li, .pop-pic-tile')??[])];return{shown:!!p&&!p.hasAttribute('hidden'),srcBefore,items:items.length,uncredited:items.filter(li=>!(li.querySelector('.pop-pic-meta, .pop-pic-tile-credit')?.textContent.trim())).length,tabCount:document.querySelector('#popup [data-pop-tab="images"] .pop-count')?.textContent.trim()??'',text:p?.innerText??'',held_title_labels:[...(p?.querySelectorAll('.pop-pic-tile')??[])].map(b=>b.getAttribute('aria-label')),linked_titles:[...(p?.querySelectorAll('.pop-pic-list li')??[])].map(li=>li.querySelector('a')?.textContent.trim()??[...li.childNodes].filter(n=>n.nodeType===Node.TEXT_NODE).map(n=>n.textContent).join('').trim())};},c.sid);
    assert(images.shown&&images.srcBefore===0&&images.items===c.expected_pictures.length&&images.items>0&&images.uncredited===0&&images.tabCount===String(images.items));
    for(const pic of c.expected_pictures){const title=pic.title??pic.id,label=`Open ${pic.kind??'picture'}: ${title}`;assert(images.held_title_labels.includes(label)||images.linked_titles.includes(title),`Missing picture ${pic.id}`);}
    const imageCapture=await capture(c.sid+'-Images');
    const image={sid:c.sid,status:'PASS',kind:'Images',observed:images,expected_picture_ids:c.expected_pictures.map(p=>p.id),capture:imageCapture};save(c.sid+'-Images-RESULT.json',image);cases.push(image);
    await page.evaluate(()=>window.__chicago4d.popup.close());guard();
  }
  // Exact native Images witness is retained unchanged (Sauganash has >=2 pictures).
  await nativeScenario('Images');
  assert.equal(nativeChecks.length,1);assert(nativeChecks[0].name.includes('Images tab'));
  await context.close();context=null;
  await boot(1904);
  // Exact current native T3265 and adjacent T2639 scenario/assertions; no edited thresholds.
  await nativeScenario('T3265');
  assert.equal(nativeChecks.length,3);assert(nativeChecks[1].name.includes('T-3265'));assert(nativeChecks[2].name.includes('T-2639'));
  assert.deepEqual(errors,[]);assert.deepEqual(network,[]);assert.deepEqual(serverErrors,[]);guard();
  save('RESULT.json',{status:'ACTUAL_PR1456_NAMED_DEV_ORIGINAL4_PEOPLE_IMAGES_AND_NATIVE_T3265_VIEWPORT_PASS',viewport,head:plan.head,tree:plan.tree,people_captures:4,images_captures:4,native_T3265_cases:1,cases,native_checks:nativeChecks,errors,network_errors:network,cancelled,serverErrors,world_boots:2,source_and_published_input_guards_passed:true,limits:'Actual finalhead originalfour1835People/Images and exact native1904T3265/T2639 only; no finalhead2-3BODY/full15 claim.'});
}catch(e){save('FAIL.json',{message:e.message,stack:e.stack,cases,nativeChecks,errors,network,cancelled,serverErrors});if(page)await page.screenshot({path:path.join(out,'FAIL.jpg'),type:'jpeg',quality:90}).catch(()=>{});throw e;}
finally{if(context)await context.close();if(browser)await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));}
