"""Strict prepared-only actual official LAP bot-head runtime; no local CP-before-gate claim."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, re, shutil, subprocess, time
from bot_runtime_authority import validate_bot_runtime_authority

R = Path('/workspace/t2372-parallel-native-20261030')
A = R / 'chicago/4d'
SITE = R / 'site/4d'
DEV = None
ANCESTOR8B = '8b4e98207c1afcff4878239cd700379447218cfb'
SOURCE54 = '3e63ad191b0c264fa3d6a0707db9ffeed7e4de79'
DEP404 = '40453bde8ba1812925d61fef118782a30323f98e'
OLD = '3746b23bf1298c34a29946b4cdb6ee2d98abff8f'
OLDDEV = '54e4004add7ab5208d71a51282c008cda6e7edad'
BRANCH = 'steward/t2381-t2373-t2384-t2377-early-pictures-20261029'
TARGETS = {'miller_house', 'hogan_store', 'st_marys_church', 'chicago_lighthouse_1832'}
PRIOR = Path('/workspace/PR1456-currentbc7-runtime-audit-v2-first-fort-20261030/BODY-PEOPLE-REUSE.json')
PRIOR_SHA = '164299a5d7344873139583564ddc45af8567033b737e48fb10977046b260ff1d'
E = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
sha = lambda b: hashlib.sha256(b).hexdigest()
pf = lambda p: sha(Path(p).read_bytes())
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

def git(*args):
    return subprocess.check_output(['git', '-C', str(R), *args], env=E)

def save(out, name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

def refs():
    return dict(line.split(' ', 1) for line in git('for-each-ref', '--format=%(refname) %(objectname)').decode().splitlines())

def index():
    return {'stage': sha(git('ls-files', '--stage', '-z')), 'flags': sha(git('ls-files', '-v', '-z'))}

def pinned(row):
    p = Path(row['path']).resolve()
    assert p.is_absolute() and p.is_relative_to('/workspace') and p.is_file() and not p.is_symlink()
    assert re.fullmatch('[0-9a-f]{64}', row['sha256']) and pf(p) == row['sha256']
    return p, json.loads(p.read_bytes()) if p.suffix == '.json' else None

def path_sha(rel):
    p = R / rel
    if not p.exists():
        assert not p.is_symlink()
        return None
    assert p.is_file() and not p.is_symlink()
    return pf(p)

def published():
    return {str(p.relative_to(SITE)): {'sha256': pf(p), 'bytes': p.stat().st_size} for p in sorted(SITE.rglob('*')) if p.is_file()}

def floors(extra=0, cap=4600000000):
    w, t = shutil.disk_usage('/workspace').free, shutil.disk_usage('/tmp').free
    alloc = int(subprocess.check_output(['du', '-s', '-B1', str(R)]).split()[0])
    assert w >= 536870912 + extra and t >= 1800000000 and alloc <= cap
    return dict(workspace_free=w, workspace_floor=536870912, additional_entry_reserve=extra, shared_TMP_free=t, shared_TMP_floor=1800000000, clone_allocation=alloc, clone_phase_limit=cap)

def context(mode):
    global DEV
    assert mode in ['phone', 'scoped_ui']
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root-plan', required=True, type=Path)
    ap.add_argument('--root-plan-sha256', required=True)
    ap.add_argument('--output', required=True, type=Path)
    ap.add_argument('--execute', action='store_true')
    ap.add_argument('--preflight-only', action='store_true')
    args = ap.parse_args()
    assert args.execute and pf(args.root_plan) == args.root_plan_sha256
    plan = json.loads(args.root_plan.read_bytes())
    statuses = {'phone': 'ROOT_APPROVED_PR1456_OFFICIAL_LAP_BOT_HEAD_PHONE_RUN', 'scoped_ui': 'ROOT_APPROVED_PR1456_OFFICIAL_LAP_BOT_HEAD_SCOPED_UI_RUN'}
    assert plan['status'] == statuses[mode] and plan['root_approved'] is True and plan['PR'] == 1456
    assert plan['allow_pending_CI_for_readonly_runtime_only'] is True
    capsule_path, capsule = pinned(plan['runtime_capsule'])
    assert capsule_path == Path(__file__).with_name('CLOSED-MANIFEST.json').resolve()
    assert capsule['status'] == 'FROZEN_OFFICIAL_LAP_BOT_HEAD_RUNTIME_PREPARATION_ONLY_NO_EXECUTION'
    for name, row in capsule['members'].items():
        p = Path(__file__).parent / name
        assert p.is_file() and not p.is_symlink() and p.stat().st_size == row['bytes'] and pf(p) == row['sha256']
    bot_authority = validate_bot_runtime_authority(plan, git, require_ci_pass=False, require_questions=True)
    head, tree, actual_parents = bot_authority['head'], bot_authority['tree'], bot_authority['parents']
    source, DEV = bot_authority['source_checkpoint_head'], bot_authority['canonical_dev']
    m, predecessor_context = bot_authority['reviewed_manifest'], bot_authority['predecessor_context']
    assert head == plan['expected_head'] and tree == plan['expected_tree'] and head != source
    assert predecessor_context['head'] == source and predecessor_context['anchor_head'] == SOURCE54
    assert git('show', '-s', '--format=%P', head).decode().strip().split() == actual_parents
    assert git('rev-parse', head + '^{tree}').decode().strip() == tree
    assert plan['branch'] == BRANCH and plan['native_assertions_waits_timeouts_and_ceilings_unchanged'] is True
    assert m['status'] == 'ROOT_REVIEWED_PR1456_NATIVE_LAP_HEAD' and m['root_reviewed'] is True
    assert m['source_checkpoint_head'] == source and m['canonical_dev'] == DEV and m['tree'] == tree
    assert m['actual_parents'] == actual_parents and m['lap_merge_commit'] == bot_authority['lap_merge_commit']
    changed_paths = m['changed_paths_from_checkpoint']
    assert set(git('diff', '--name-only', source, head).decode().splitlines()) == set(changed_paths)
    out = args.output.resolve()
    assert str(out) == plan['output'] and out.is_relative_to('/workspace') and not out.is_relative_to(R) and not out.is_relative_to('/workspace/chicago') and not out.exists()
    cpu = plan['CPU_affinity']
    assert cpu and len(set(cpu)) == len(cpu) and all(type(c) is int and 0 <= c <= 4 for c in cpu) and plan['nice'] == 19
    assert cpu == ([2] if mode == 'phone' else [0, 1, 3, 4])
    cap = m['resource_price']['clone_phase_limit_bytes']
    assert 0 < cap <= 4600000000
    resource = floors(128 * 1048576, cap)
    config, ix, rf = pf(R / '.git/config'), index(), refs()
    assert config == m['source_config_sha256']
    original_source = dict(changed_paths)
    for section in ['owned_original', 'canonical_foreign_entrywise']:
        if section in m:
            for key in ['reviewed_paths', 'mixed_paths']:
                original_source.update(m[section].get(key, {}))
    assert set(m['required404_dependency_paths']) == {'chicago/4d/renderers/web/js/railway.js', 'chicago/4d/tools/test_rail_geometry_lifecycle.mjs'}
    assert set(m['protected404_performance_paths']) == {'chicago/4d/renderers/web/js/spatial-batch.js', 'chicago/4d/tools/check_confidence_lane.mjs'}
    for section in ['required404_dependency_paths', 'protected404_performance_paths']:
        for rel, digest in m[section].items():
            assert digest == sha(git('show', DEP404 + ':' + rel))
            original_source[rel] = digest
    assert set(m['new_owned_path_sha256']) == {'chicago/4d/tools/smoke_renderer.mjs', 'chicago/4d/renderers/web/js/yard.js'}
    original_source.update(m['new_owned_path_sha256'])
    for rel, digest in original_source.items():
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts and (digest is None or re.fullmatch('[0-9a-f]{64}', digest))
    # Current sources and native consumer files are explicit before/after byte bindings.
    runtime_source = {}
    for p in sorted((A / 'renderers/web').rglob('*')):
        if p.is_file() and p.suffix in ['.js', '.css']: runtime_source[str(p.relative_to(A))] = pf(p)
    for rel in ['tools/measure_memory.mjs', 'tools/memory_ceilings.json', 'tools/smoke_renderer.mjs', 'tools/defer_household_notes.mjs', 'tools/changelog_shim.mjs', 'tools/stamp-changelog.mjs', 'assets/manifest.json', 'assets/manifest.web.json', 'data/scenes/1835.json', 'data/scenes/1904.json']:
        runtime_source[rel] = pf(A / rel)
    assert (A / 'tools/memory_ceilings.json').read_bytes() == git('show', DEV + ':chicago/4d/tools/memory_ceilings.json')
    assert json.loads((A / 'tools/memory_ceilings.json').read_bytes())['ceilings']['1904']['mobile']['total_bytes'] == 400 * 1048576
    assert (A / 'tools/measure_memory.mjs').read_bytes() == git('show', DEV + ':chicago/4d/tools/measure_memory.mjs') == git('show', ANCESTOR8B + ':chicago/4d/tools/measure_memory.mjs')
    pub = published()
    assert len(pub) > 100 and (SITE / '1904/index.html').is_file()
    for rel, digest in runtime_source.items():
        if rel.startswith('renderers/web/js/') and rel != 'renderers/web/js/changelog.js':
            assert pf(SITE / 'walk/js' / rel.removeprefix('renderers/web/js/')) == digest
    for rel, digest in runtime_source.items():
        if rel.startswith('renderers/web/css/'):
            assert pf(SITE / 'walk/css' / rel.removeprefix('renderers/web/css/')) == digest
    assert (SITE / 'js/changelog.js').read_bytes() == (A / 'renderers/web/js/changelog.js').read_bytes()
    shim_source = (A / 'tools/changelog_shim.mjs').read_text()
    assert shim_source.encode() == git('show', DEV + ':chicago/4d/tools/changelog_shim.mjs')
    shim = re.search(r'^export const WALK_SHIM = `(.*)`;\s*$', shim_source, re.M | re.S)
    assert shim and '\\' not in shim.group(1) and '${' not in shim.group(1)
    assert (SITE / 'walk/js/changelog.js').read_bytes() == shim.group(1).encode()
    reg = json.loads((A / 'assets/manifest.json').read_bytes())['assets']
    web = json.loads((A / 'assets/manifest.web.json').read_bytes())['masters']
    models, found = {}, set()
    for name, row in reg.items():
        if row.get('structure_id') not in TARGETS: continue
        found.add(row['structure_id'])
        master, derivative, delivered = A / 'assets/gltf' / name, A / 'assets/web' / name, SITE / 'data/gltf' / name
        assert pf(master) == web[name] and pf(derivative) == pf(delivered)
        models[name] = dict(structure_id=row['structure_id'], MASTER=pf(master), WEB=pf(derivative), published=pf(delivered))
        for prefix in ['assets/gltf', 'assets/web']: runtime_source[prefix + '/' + name] = pf(A / prefix / name)
    assert found == TARGETS
    assert pf(PRIOR) == PRIOR_SHA
    prior_rows = {r['path']: r['current_sha256'] for r in json.loads(PRIOR.read_bytes())['rows']}
    for name, model in models.items():
        assert model['WEB'] == prior_rows['/workspace/chicago/site/4d/data/gltf/' + name]
    projector = (A / 'tools/defer_household_notes.mjs').read_bytes()
    assert projector == git('show', OLD + ':chicago/4d/tools/defer_household_notes.mjs') == git('show', DEV + ':chicago/4d/tools/defer_household_notes.mjs')
    sidecars = {}
    for sid in sorted(TARGETS):
        rel = 'data/sidecars/1835/' + sid + '.json'
        native, shipped = (A / rel).read_bytes(), (SITE / rel).read_bytes()
        assert sha(native) == prior_rows['/workspace/chicago/chicago/4d/' + rel] and sha(shipped) == prior_rows['/workspace/chicago/site/4d/' + rel]
        rec = json.loads(native)
        full = rec.get('residents')
        deferred = isinstance(full, list) and len(full) > 0
        if deferred:
            slim = []
            for household in full:
                h = {k: v for k, v in household.items() if k not in ['why', 'research_note']}
                if isinstance(household.get('persons'), list): h['persons'] = [{k: v for k, v in p.items() if k != 'note'} for p in household['persons']]
                slim.append(h)
            assert json.loads(shipped) == {**rec, 'residents': slim}
            assert json.loads((SITE / ('data/sidecars/1835/households/' + sid + '.json')).read_bytes()) == {'id': rec['id'], 'residents': full}
        else: assert native == shipped
        runtime_source[rel] = sha(native)
        sidecars[sid] = dict(source_sha256=sha(native), published_sha256=sha(shipped), native_household_notes_deferred=deferred, accepted3746_source_and_published_bytes_exact=True)
    for rel in ['data/scenes/1835.json', 'data/scenes/1904.json']:
        assert (A / rel).read_bytes() == (SITE / rel).read_bytes()
    source_1835 = {}
    for rel in ['data/scenes/1835.json', 'data/pictures/1835.json', 'data/sidecars/1835/people.json', 'data/inspect/1835.json', 'data/signage/town_business_signboards.json', 'data/yard/town_trade_goods.json', 'data/yard/town_woodpiles.json', 'data/enclosures/town_entrance_aprons.json']:
        assert (A / rel).is_file()
        source_1835[rel] = pf(A / rel)
    for sid in TARGETS:
        rel = 'data/sidecars/1835/' + sid + '.json'
        source_1835[rel] = pf(A / rel)
        for camera in (A / 'data/reference_views' / sid).glob('*.json'):
            if not camera.name.endswith('.match.json'): source_1835[str(camera.relative_to(A))] = pf(camera)
    source_to_published_map = {}
    for rel in runtime_source:
        if rel.startswith('renderers/web/js/'):
            source_to_published_map[rel] = 'js/changelog.js' if rel == 'renderers/web/js/changelog.js' else 'walk/js/' + rel.removeprefix('renderers/web/js/')
        elif rel.startswith('renderers/web/css/'):
            source_to_published_map[rel] = 'walk/css/' + rel.removeprefix('renderers/web/css/')
    native_scenarios = {}
    native_smoke = (A / 'tools/smoke_renderer.mjs').read_bytes()
    for name, filename in [('Images', 'NATIVE-IMAGES-SCENARIO.js'), ('T3265', 'NATIVE-T3265-SCENARIO.js')]:
        scenario = Path(__file__).with_name(filename)
        raw = scenario.read_bytes()
        assert native_smoke.count(raw) == 1, 'Exact native scenario is not present once: ' + name
        native_scenarios[name] = dict(path=str(scenario), sha256=pf(scenario), bytes=len(raw), exact_current_native_source_slice=True)
    expected_case_path = Path(__file__).with_name('ORIGINAL4-EXPECTED-CASES.json')
    expected_case_data = json.loads(expected_case_path.read_bytes())
    assert {c['sid'] for c in expected_case_data['cases']} == TARGETS and len(expected_case_data['cases']) == 4
    assert expected_case_data['scene'] == '1835'
    version = json.loads((SITE / 'build.json').read_bytes()).get('version')
    assert isinstance(version, str) and version and head.startswith(version)
    publication_kind = 'native_publication_of_actual_imported_official_LAP_bot_head' 
    dated_staged = None
    if plan.get('dated_staged_BOTH') is not None:
        dated_path, dated = pinned(plan['dated_staged_BOTH'])
        assert dated['source_head'] == SOURCE54 and dated['merge_parent'] == ANCESTOR8B and dated['staged_tree'] == 'e7df4262112da841da674ded1b1359247946c9fa'
        assert dated['actual8b_commit'] is None and dated['checked_staged_tree_not_committed'] is True
        assert dated['status'] in ['ACTUAL_STAGED8B_PUBLISHED_STAGES23_BOTH_PASS', 'ACTUAL_STAGED8B_PUBLISHED_STAGES23_BOTH_NOT_QUALIFIED']
        dated_staged = dict(path=str(dated_path), sha256=plan['dated_staged_BOTH']['sha256'], status=dated['status'], source_head=dated['source_head'], staged_tree=dated['staged_tree'], merge_parent=dated['merge_parent'], scope='DATED staged8b2-3 only; no final named-dev browser PASS or consumer equivalence is asserted by this phone reading')
    authority = [plan['runtime_capsule']] + bot_authority['authority_pins']

    if dated_staged is not None: authority.append(plan['dated_staged_BOTH'])

    def guard():
        assert pf(args.root_plan) == args.root_plan_sha256
        assert validate_bot_runtime_authority(plan, git, require_ci_pass=False, require_questions=True) == bot_authority
        for row in authority: assert pf(row['path']) == row['sha256']
        assert git('rev-parse', 'HEAD').decode().strip() == head and git('rev-parse', 'HEAD^{tree}').decode().strip() == tree
        assert git('show', '-s', '--format=%P', head).decode().strip().split() == actual_parents
        assert git('branch', '--show-current').decode().strip() == BRANCH and git('rev-parse', 'origin/dev').decode().strip() == DEV and not (R / '.git/MERGE_HEAD').exists()
        assert not git('status', '--porcelain=v1', '--untracked-files=all') and not git('ls-files', '-u')
        assert set(git('diff', '--name-only', source, head).decode().splitlines()) == set(changed_paths)
        assert index() == ix and refs() == rf and pf(R / '.git/config') == config
        assert all(path_sha(p) == digest for p, digest in original_source.items())
        assert all(pf(A / p) == digest for p, digest in {**runtime_source, **source_1835}.items())
        assert published() == pub and pf(PRIOR) == PRIOR_SHA
        floors(0, cap)

    guard()
    if args.preflight_only:
        print(json.dumps(dict(status='ACTUAL_OFFICIAL_LAP_BOT_HEAD_READONLY_RUNTIME_PREFLIGHT_PASS_NO_MEASUREMENT', mode=mode, at=now(), root_plan=str(args.root_plan.resolve()), root_plan_sha256=args.root_plan_sha256, source_checkpoint_head=source, source_anchor=SOURCE54, head=head, tree=tree, parents=actual_parents, canonical_dev=DEV, lap_merge_commit=bot_authority['lap_merge_commit'], source_config_sha256=config, index_semantics=ix, all_refs=rf, published_member_count=len(pub), source_runtime_count=len(runtime_source), original4_models=models, native_sidecar_projection=sidecars, source_to_published_map=source_to_published_map, native_scenarios=native_scenarios, CI_summary=bot_authority.get('CI_summary'), actual_CI_PASS_at_merge_still_required=True, no_generic_local_CP_or_precommit_gate_for_bot_head_claimed=True, dated_staged_BOTH_separate_proof=dated_staged, source_published_and_resource_guard_actually_called=True, output_directory_created=False, owned_TMP_created=False, browser_or_meter_or_native_tests_launched=False), indent=2))
        raise SystemExit(0)
    out.mkdir(mode=0o700)
    tmp = Path('/workspace/p1456-bp2' if mode == 'phone' else '/workspace/p1456-bu2')
    assert not tmp.exists()
    tmp.mkdir(mode=0o700)
    (tmp / 'OWNER.json').write_text(json.dumps(dict(owner='PR1456_NAMED_DEV_' + mode, head=head, output=str(out))) + '\n')
    env = dict(E, TMPDIR=str(tmp), TMP=str(tmp), TEMP=str(tmp), NODE_COMPILE_CACHE=str(tmp / 'node-compile-cache'))
    for key in ['SMOKE_ROOT', 'SMOKE_ENTRY', 'SMOKE_TARGET', 'SMOKE_YEAR', 'SMOKE_PORT', 'SMOKE_STAGE', 'SMOKE_VIEWPORT', 'SMOKE_SHOTS']:
        env.pop(key, None)
    binding = dict(revision='PR1456_OFFICIAL_LAP_BOT_HEAD', head=head, tree=tree, parents=actual_parents, source_checkpoint_head=source, source_anchor=SOURCE54, canonical_dev=DEV, lap_merge_commit=bot_authority['lap_merge_commit'], branch=BRANCH, root_plan=str(args.root_plan.resolve()), root_plan_sha256=args.root_plan_sha256, runtime_capsule=plan['runtime_capsule'], source54_checkpoint=plan['source54_checkpoint'], source_predecessor_checkpoint=plan['source_predecessor_checkpoint'], source_predecessor_publication=plan['source_predecessor_publication'], source_predecessor_merge_parent=plan['source_predecessor_merge_parent'], source_chain_context=predecessor_context, lap_provenance=plan['lap_provenance'], reviewed_manifest=plan['reviewed_manifest'], ci_source_gate=plan['ci_source_gate'], native_pr_questions=plan['native_pr_questions'], CI_summary=bot_authority.get('CI_summary'), actual_CI_PASS_at_merge_still_required=True, no_generic_local_CP_or_precommit_gate_for_bot_head_claimed=True, source_config_sha256=config, index_semantics=ix, all_refs=rf, changed_paths_from_checkpoint=changed_paths, required404_dependency_paths=m['required404_dependency_paths'], protected404_performance_paths=m['protected404_performance_paths'], new_owned_path_sha256=m['new_owned_path_sha256'], source_to_published_map=source_to_published_map, native_scenarios=native_scenarios, original4_expected_cases_sha256=pf(expected_case_path), source_runtime_files=runtime_source, source_1835_files=source_1835, models=models, native_sidecar_projection=sidecars, native_changelog_projection='Authored JS equals site/js/changelog.js; walk/js/changelog.js equals exact native WALK_SHIM re-export', published_files=pub, published_build_version=version, publication_kind=publication_kind, CPU_affinity=cpu, nice=19, TMPDIR=str(tmp), memory_limit_bytes=400 * 1048576, ordinary_native_clone_no_root_override_or_alias=True, dated_staged_BOTH_separate_proof=dated_staged, dated_browser_proof_not_used_as_current_phone_or_UI_measurement=True, resource_before=resource)
    return args, plan, out, tmp, env, guard, binding

def native(out, name, command, env, cpu):
    rp = out / (name + '-REAPER.json')
    assert not rp.exists()
    argv = ['python3', '/workspace/shared/run-with-reaping.py', str(rp), '--', 'nice', '-n', '19', 'taskset', '-c', ','.join(str(c) for c in cpu), *command]
    start = time.monotonic()
    with (out / (name + '.log')).open('xb') as log:
        q = subprocess.run(argv, cwd=A, env=env, stdout=log, stderr=subprocess.STDOUT)
    reaper = json.loads(rp.read_bytes())
    return dict(command=command, argv=argv, exit=q.returncode, seconds=time.monotonic()-start, reaper=str(rp), reaper_sha256=pf(rp), log=str(out / (name + '.log')), log_sha256=pf(out / (name + '.log'))), reaper
