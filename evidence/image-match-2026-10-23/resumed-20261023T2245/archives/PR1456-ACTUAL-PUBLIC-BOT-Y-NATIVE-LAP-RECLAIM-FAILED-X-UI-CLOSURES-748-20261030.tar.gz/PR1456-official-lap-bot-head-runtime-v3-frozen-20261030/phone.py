"""Prepared only. Official1904mobile400MiB on actual imported LAP bot head; CI may remain pending."""
from runtime_common import *
args, plan, out, tmp, env, guard, binding = context('phone')
helper = pf(Path(__file__))
common = pf(Path(__file__).with_name('runtime_common.py'))
command = ['node', 'tools/measure_memory.mjs', '--year', '1904', '--only', 'mobile', '--gate', '--no-snapshot', '--json', str(out / 'PHONE.json')]
binding.update(command=command, helper_sha256=helper, common_sha256=common, prior_phone_results_not_reused=True)
save(out, 'PHONE-BINDING.json', binding)
step, reaper = native(out, 'PHONE', command, env, binding['CPU_affinity'])
raw = json.loads((out / 'PHONE.json').read_bytes()) if (out / 'PHONE.json').exists() else {}
rows = raw.get('rows', [])
peak = rows[0]['totals']['total'] / 1048576 if len(rows) == 1 else None
guard_error = None
try:
    guard()
    assert pf(Path(__file__)) == helper and pf(Path(__file__).with_name('runtime_common.py')) == common
except Exception as error:
    guard_error = repr(error)
passed = step['exit'] == 0 and reaper['command_exit'] == 0 and reaper['all_children_reaped'] is True and not reaper['leftover_cleanup'] and guard_error is None and len(rows) == 1 and rows[0]['year'] == '1904' and rows[0]['viewport'] == 'mobile' and not rows[0]['errors'] and peak is not None and 0 < peak <= 400
save(out, 'PHONE-RESULT.json', dict(revision='PR1456_OFFICIAL_LAP_BOT_HEAD', status='ACTUAL_PR1456_OFFICIAL_LAP_BOT_HEAD_PHONE400_PASS' if passed else 'ACTUAL_PR1456_OFFICIAL_LAP_BOT_HEAD_PHONE_NOT_QUALIFIED', at=now(), head=binding['head'], tree=binding['tree'], parents=binding['parents'], source_checkpoint_head=binding['source_checkpoint_head'], source_anchor=binding['source_anchor'], canonical_dev=binding['canonical_dev'], lap_merge_commit=binding['lap_merge_commit'], CI_summary=binding['CI_summary'], actual_CI_PASS_at_merge_still_required=True, no_generic_local_CP_or_precommit_gate_for_bot_head_claimed=True, binding_sha256=pf(out / 'PHONE-BINDING.json'), actual_complete_1904_mobile_peak_MiB=peak, unchanged_limit_MiB=400, step=step, all_children_reaped=reaper['all_children_reaped'], source_published_guards_exact=guard_error is None, guard_error=guard_error, actual_measurement_sha256=pf(out / 'PHONE.json') if (out / 'PHONE.json').exists() else None, errors=rows[0]['errors'] if len(rows) == 1 else ['no complete actual row'], intermediate54_phone_not_run_or_reused=True, published_browser_coverage_separate_not_claimed=True, dated_staged_BOTH_separate_proof=binding['dated_staged_BOTH_separate_proof'], owned_TMP_retained_for_exact_root_cleanup=str(tmp)))
print((out / 'PHONE-RESULT.json').read_text())
raise SystemExit(0 if passed else 1)
