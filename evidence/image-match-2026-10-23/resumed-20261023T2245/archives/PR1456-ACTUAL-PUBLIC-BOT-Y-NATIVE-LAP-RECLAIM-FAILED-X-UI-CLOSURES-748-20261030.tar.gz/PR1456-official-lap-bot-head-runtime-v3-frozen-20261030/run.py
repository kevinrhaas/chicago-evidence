"""Prepared only: actual finalhead original4People/Images and unchanged nativeT3265 BOTH."""
from runtime_common import *
args, plan, out, tmp, env, guard, binding = context('scoped_ui')
helper = pf(Path(__file__))
common = pf(Path(__file__).with_name('runtime_common.py'))
review = Path(__file__).with_name('review.mjs')
case_path = Path(__file__).with_name('ORIGINAL4-EXPECTED-CASES.json')
cases = json.loads(case_path.read_bytes())['cases']
pics = json.loads((SITE / 'data/pictures/1835.json').read_bytes())
for case in cases:
    case['expected_pictures'] = pics['by_structure'][case['sid']]
    assert case['expected_pictures']
selected = {str(A / rel): digest for rel, digest in binding['source_runtime_files'].items()}
selected.update({str(A / rel): digest for rel, digest in binding['source_1835_files'].items()})
for source, delivered in binding['source_to_published_map'].items():
    selected[str(SITE / delivered)] = pf(SITE / delivered)
for rel in ['data/pictures/1835.json', 'data/sidecars/1835/people.json', 'data/scenes/1835.json', 'data/scenes/1904.json']:
    selected[str(SITE / rel)] = pf(SITE / rel)
for sid, row in binding['native_sidecar_projection'].items():
    selected[str(SITE / 'data/sidecars/1835' / (sid + '.json'))] = row['published_sha256']
for name, row in binding['models'].items():
    selected[str(SITE / 'data/gltf' / name)] = row['published']
expected = dict(head=binding['head'], tree=binding['tree'], site_parent=str(SITE.parent), cases=cases,
                native_scenarios=binding['native_scenarios'], immutable_selected_input_bindings=selected)
save(out, 'EXPECTED.json', expected)
binding.update(helper_sha256=helper, common_sha256=common, review_sha256=pf(review),
               actual_expected_sha256=pf(out / 'EXPECTED.json'), original4_People_captures_required=8,
               original4_Images_captures_required=8, native_T3265_viewport_cases_required=2,
               actual_stage23_rerun_NOT_claimed=True, native_Images_and_T3265_scenarios_unmodified=True,
               source_CSS_and_JS_before_after_bound=True)
save(out, 'UI-BINDING.json', binding)
env.update(PR1456_UI_EXPECTED=str(out / 'EXPECTED.json'))
steps, viewports, failure, guard_error = [], [], None, None
for viewport in ['desktop', 'mobile']:
    try:
        guard()
        env.update(PR1456_UI_VIEWPORT=viewport, PR1456_UI_OUT=str(out / viewport))
        command = ['node', str(review)]
        save(out, 'CURRENT-CALL.json', dict(viewport=viewport, started=now(), command=command,
             source_head=binding['head'], scope='four1835People + four1835Images + exact native1904T3265/T2639'))
        step, reap = native(out, viewport, command, env, binding['CPU_affinity'])
        step.update(viewport=viewport)
        steps.append(step)
        save(out, 'UI-STEPS.json', steps)
        assert step['exit'] == 0 and reap['command_exit'] == 0 and reap['all_children_reaped'] is True and not reap['leftover_cleanup']
        row_path = out / viewport / 'RESULT.json'
        row = json.loads(row_path.read_bytes())
        assert row['status'] == 'ACTUAL_PR1456_OFFICIAL_LAP_BOT_HEAD_ORIGINAL4_PEOPLE_IMAGES_AND_NATIVE_T3265_VIEWPORT_PASS'
        assert row['viewport'] == viewport and row['head'] == binding['head'] and row['tree'] == binding['tree']
        assert row['people_captures'] == row['images_captures'] == 4 and row['native_T3265_cases'] == 1
        assert row['errors'] == row['network_errors'] == row['serverErrors'] == [] and row['source_and_published_input_guards_passed'] is True
        assert len(row['native_checks']) == 3 and all(x['pass'] is True for x in row['native_checks'])
        assert {(x['sid'], x['kind']) for x in row['cases']} == {(sid, kind) for sid in TARGETS for kind in ['People', 'Images']}
        for case in row['cases']:
            capture = case['capture']; path = Path(capture['path'])
            assert case['status'] == 'PASS' and path.is_relative_to(out / viewport) and path.is_file() and not path.is_symlink()
            assert path.stat().st_size == capture['bytes'] and pf(path) == capture['sha256']
        viewports.append(dict(viewport=viewport, path=str(row_path), sha256=pf(row_path), result=row))
        guard()
    except Exception as error:
        failure = repr(error)
        break
try:
    guard()
    assert pf(Path(__file__)) == helper and pf(Path(__file__).with_name('runtime_common.py')) == common
    assert pf(review) == binding['review_sha256'] and pf(out / 'EXPECTED.json') == binding['actual_expected_sha256']
except Exception as error:
    guard_error = repr(error)
passed = failure is None and guard_error is None and len(viewports) == len(steps) == 2
all_reaped = bool(steps) and all(json.loads(Path(x['reaper']).read_bytes())['all_children_reaped'] is True for x in steps)
save(out, 'UI-RESULT.json', dict(status='ACTUAL_PR1456_OFFICIAL_LAP_BOT_HEAD_ORIGINAL4_PEOPLE_IMAGES_AND_NATIVE_T3265_BOTH_PASS' if passed else 'ACTUAL_PR1456_OFFICIAL_LAP_BOT_HEAD_ORIGINAL4_PEOPLE_IMAGES_AND_NATIVE_T3265_BOTH_NOT_QUALIFIED', at=now(),
     head=binding['head'], tree=binding['tree'], parents=binding['parents'], source_checkpoint_head=binding['source_checkpoint_head'], source_anchor=binding['source_anchor'], canonical_dev=binding['canonical_dev'], lap_merge_commit=binding['lap_merge_commit'],
     binding_sha256=pf(out / 'UI-BINDING.json'), ci_source_gate=plan['ci_source_gate'], CI_summary=binding['CI_summary'], actual_CI_PASS_at_merge_still_required=True, no_generic_local_CP_or_precommit_gate_for_bot_head_claimed=True,
     original4_People_captures=sum(x['result']['people_captures'] for x in viewports), original4_Images_captures=sum(x['result']['images_captures'] for x in viewports),
     native_T3265_viewport_cases=sum(x['result']['native_T3265_cases'] for x in viewports), viewports=viewports, steps=steps,
     all_children_reaped=all_reaped, all_started_steps_reaped=all_reaped, both_viewports_started=len(steps) == 2, source_published_guards_exact=guard_error is None, failure=failure, guard_error=guard_error,
     errors=[e for x in viewports for e in x['result']['errors']], network_errors=[e for x in viewports for e in x['result']['network_errors']],
     old_staged23_not_relabelled=True, current_UI_only_no_fresh_geometry_BODY_or_all15_claim=True,
     native_Images_and_T3265_scenarios_unmodified=True, source_CSS_and_JS_before_after_bound=True, owned_TMP_retained_for_exact_root_cleanup=str(tmp)))
print((out / 'UI-RESULT.json').read_text())
raise SystemExit(0 if passed else 1)
