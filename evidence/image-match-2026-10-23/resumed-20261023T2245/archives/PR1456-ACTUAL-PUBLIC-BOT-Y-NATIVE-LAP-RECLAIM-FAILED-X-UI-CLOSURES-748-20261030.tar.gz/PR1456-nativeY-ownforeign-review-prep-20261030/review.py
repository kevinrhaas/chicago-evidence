"""Read-only actual native bot-head own/foreign review against fixed canonical 3de."""
from pathlib import Path
import argparse,copy,datetime,hashlib,json,os,subprocess
R=Path('/workspace/t2372-parallel-native-20261030');X='a3ce922cf74d367f3e9656eaf5ab510903bc689a';D='3de1877c4e9260cd9b94ea3d4af319525973b677';OLDDEV='8fbbe09b8b6ca4f96d8a9e2dd1b74a415d18ae4a';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
S=Path('/workspace/PR1456-cd8d-base8fb-current3de-native3way-readonly-publisher-20261030')
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):return dict(path=str(p),sha256=sha(p.read_bytes()))
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def blob(rev,p):return git('show',rev+':'+p)
def tree(rev):
 out={}
 for row in git('ls-tree','-rz',rev).split(b'\0'):
  if row:
   k,p=row.split(b'\t',1);mode,kind,oid=k.decode().split();out[p.decode()]=(mode,kind,oid)
 return out
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--head',required=True);ap.add_argument('--output',required=True,type=Path);a=ap.parse_args();assert len(a.head)==40 and a.head!=X;git('merge-base','--is-ancestor',X,a.head);git('merge-base','--is-ancestor',D,a.head)
 out=a.output.resolve();assert out.is_relative_to('/workspace')and not out.is_relative_to(R)and not out.exists();out.mkdir()
 old=json.loads(Path('/workspace/PR1456-root-approved-genuine8fb-integration-20261030.json').read_bytes());entry=json.loads(Path('/workspace/PR1456-genuine8fb-direct3e63-actual-publisher-20261030/final-staged-review/ENTRYWISE-FINAL-REVIEW.json').read_bytes());native=json.loads((S/'RESULT.json').read_bytes());assert native['current_named_tip']==D
 for r in json.loads((S/'CLOSED-MANIFEST.json').read_bytes())['files']:
  assert sha(Path(r['path']).read_bytes())==r['sha256']
 before=dict(status=git('status','--porcelain=v1','--untracked-files=all').decode(),refs=sha(git('for-each-ref')),index=sha(git('ls-files','--stage','-z')),config=sha((R/'.git/config').read_bytes()))
 x,d,y=tree(X),tree(D),tree(a.head);own=old['owned_original']['reviewed_paths'];mixed=old['canonical_foreign_entrywise']['mixed_paths'];deps=old['required404_dependency_paths'];new=old['new_owned_path_sha256'];allowed=set(own)|set(mixed)|set(deps)|set(new);assert len(allowed)==67
 badown={p:{'expected':x.get(p),'actual':y.get(p)}for p in set(own)|set(deps)|set(new)if x.get(p)!=y.get(p)}
 extra={p:{'canonical':d.get(p),'actual':y.get(p)}for p in set(d)|set(y)if p not in allowed and d.get(p)!=y.get(p)}
 expected={}
 for row in native['rows']:
  p=row['path'];assert x[p][2]==row['ours_blob']and d[p][2]==row['incoming_blob'];f=Path(row['merged_postimage'])
  if p.endswith('/data/liberties.json'):f=S/'3/PROPOSED-COUNT-ONLY-RESOLUTION.json'
  if p.endswith('/docs/measurements/source_use_coverage.md'):f=S/'5/PROPOSED-COUNT-ONLY-RESOLUTION.md'
  expected[p]=f.read_bytes()
 mixedproof={}
 for p in mixed:
  if p in expected:want=expected[p]
  else:
   assert d.get(p)==tree(OLDDEV).get(p),('Canonical mixed path drift requires fresh review',p);want=blob(X,p)
  actual=blob(a.head,p);mixedproof[p]=dict(exact=actual==want,expected_sha256=sha(want),actual_sha256=sha(actual))
 # Independent semantic overlays: original own registry rows, canonical foreign rows.
 semantic={}
 for rel,key,ownids in [('chicago/4d/assets/manifest.json','assets',entry['assets']['chicago/4d/assets/manifest.json']['own_row_ids']),('chicago/4d/assets/manifest.web.json','masters',entry['assets']['chicago/4d/assets/manifest.web.json']['own_row_ids'])]:
  xx,dd,yy=[json.loads(blob(rev,rel))for rev in [X,D,a.head]];assert isinstance(xx[key],dict);want=dict(dd[key]);want.update({k:xx[key][k]for k in ownids});semantic[rel]=dict(own_count=len(ownids),all_rows_exact=want==yy[key],metadata_exact={k:v for k,v in dd.items()if k!=key}=={k:v for k,v in yy.items()if k!=key})
 p='chicago/4d/data/liberties.json';xx,dd,yy=[json.loads(blob(rev,p))for rev in [X,D,a.head]];ids=entry['liberties']['own4_IDs'];xm={r['id']:r for r in xx['liberties']};dm={r['id']:r for r in dd['liberties']};ym={r['id']:r for r in yy['liberties']};want=dict(dm);want.update({k:xm[k]for k in ids});semantic[p]=dict(own_count=4,all_rows_exact=want==ym,count_exact=yy['count']==len(yy['liberties'])==889,metadata_exact={k:v for k,v in dd.items()if k not in ['count','liberties']}=={k:v for k,v in yy.items()if k not in ['count','liberties']})
 after=dict(status=git('status','--porcelain=v1','--untracked-files=all').decode(),refs=sha(git('for-each-ref')),index=sha(git('ls-files','--stage','-z')),config=sha((R/'.git/config').read_bytes()));guards=before==after
 passed=not badown and not extra and all(r['exact']for r in mixedproof.values())and all(all(v is True for k,v in r.items()if k not in ['own_count'])for r in semantic.values())and guards
 proof=dict(status='ACTUAL_NATIVE_Y_OWN49_MIXED14_DEPENDENCY2_REPAIR2_AND_ALL_CANONICAL_FOREIGN_PASS'if passed else'ACTUAL_NATIVE_Y_REVIEW_REQUIRES_CONTENT_REVIEW',head=a.head,tree=git('rev-parse',a.head+'^{tree}').decode().strip(),canonical_dev=D,source_checkpoint_head=X,own_mismatches=badown,foreign_outside67_differences=extra,mixed=mixedproof,semantic=semantic,source_readonly_guards_exact=guards,all_original4_inputs_preserved=not badown,all_nonown_currentdev_leaves_preserved_except_native_derived=not extra)
 (out/'OWN-FOREIGN-PROOF.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:proof[k]for k in ['status','head','tree','own_mismatches','foreign_outside67_differences','source_readonly_guards_exact']},indent=2));assert passed
 assert blob(a.head,'chicago/4d/tools/check.sh')==blob(X,'chicago/4d/tools/check.sh'),'Native step count changed; reprice actual check before qualification'
 resource=dict(workspace_free=__import__('shutil').disk_usage('/workspace').free,shared_tmp_free=__import__('shutil').disk_usage('/tmp').free,clone_allocation=int(subprocess.check_output(['du','-s','-B1',str(R)]).split()[0]),clone_phase_limit_bytes=4600000000);(out/'RESOURCE.json').write_text(json.dumps(resource,indent=2)+'\n');assert resource['workspace_free']>=536870912 and resource['shared_tmp_free']>=1800000000 and resource['clone_allocation']<=4600000000
 m=copy.deepcopy(old);m.update(status='ROOT_REVIEW_REQUIRED_PR1456_NATIVE_LAP_HEAD',root_reviewed=False,head=a.head,tree=proof['tree'],actual_parents=git('show','-s','--format=%P',a.head).decode().strip().split(),source_checkpoint_head=X,canonical_dev=D,branch=old['branch'],source_config_sha256=before['config'],native_lap_derived_changes_reviewed=True,all_nonown_currentdev_leaves_preserved_except_native_derived=True,all_original4_inputs_preserved=True,additional_native_generated_paths={},additional_native_generated_proof_files=[],changed_paths_from_checkpoint={p:sha(blob(a.head,p))if p in y else None for p in set(x)|set(y)if x.get(p)!=y.get(p)},native_check_sha256=sha(blob(a.head,'chicago/4d/tools/check.sh')),expected_steps=1109,resource_price={**old['resource_price'],'proof_files':[pin(out/'RESOURCE.json')],**resource})
 for stale in ['merge_parent','checkpoint_message_sha256','staged_paths','fixture_shim_sha256','fixture_test_sha256']:m.pop(stale,None)
 m['source_head']=X;m['qualification_limits']='Actual native bot-head input/foreign preservation reviewed; root approval, actual CI source gate, scoped UI bridge, fresh officialphone400 and normal PR merge remain separate.'
 commits=git('rev-list','--first-parent','--reverse',X+'..'+a.head).decode().splitlines();merges=[c for c in commits if len(git('show','-s','--format=%P',c).decode().split())==2];assert len(merges)==1;m['lap_merge_commit']=merges[0]
 m['owned_original']['proof_files']=[pin(out/'OWN-FOREIGN-PROOF.json')];m['canonical_foreign_entrywise'].update(canonical_commit=D,all_foreign_protected=True,mixed_paths={p:sha(blob(a.head,p))for p in mixed},proof_files=[pin(out/'OWN-FOREIGN-PROOF.json')]);m['new_owned_path_proof_files']=[pin(out/'OWN-FOREIGN-PROOF.json')];(out/'ROOT-REVIEW-DRAFT.json').write_text(json.dumps(m,indent=2)+'\n');print('Root review draft',out/'ROOT-REVIEW-DRAFT.json')
if __name__=='__main__':main()
