"""Read-only exact scoped UI consumer bridge. No browser PASS is inferred."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess
R=Path('/workspace/t2372-parallel-native-20261030');X='a3ce922cf74d367f3e9656eaf5ab510903bc689a';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
sha=lambda b:hashlib.sha256(b).hexdigest()
def tree(rev):
 d={}
 for x in git('ls-tree','-rz',rev).split(b'\0'):
  if x:
   a,p=x.split(b'\t',1);mode,kind,oid=a.decode().split();d[p.decode()]=(mode,kind,oid)
 return d
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--head',required=True);ap.add_argument('--output',required=True,type=Path);ap.add_argument('--source-ui-binding',type=Path);a=ap.parse_args();assert len(a.head)==40 and all(x in '0123456789abcdef' for x in a.head);git('merge-base','--is-ancestor',X,a.head)
 out=a.output.resolve();assert out.is_relative_to('/workspace')and not out.is_relative_to(R)and not out.exists();out.mkdir()
 before=git('status','--porcelain=v1','--untracked-files=all');refs=git('for-each-ref');index=git('ls-files','--stage','-z');config=(R/'.git/config').read_bytes();old,new=tree(X),tree(a.head)
 targets=['miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832'];prefix='chicago/4d/'
 exact={p for p in set(old)|set(new) if p.startswith(prefix+'renderers/web/')and p.endswith(('.js','.css'))and p!=prefix+'renderers/web/js/changelog.js'}
 for sid in targets:
  exact|={p for p in set(old)|set(new) if p.startswith((prefix+'assets/gltf/'+sid+'__',prefix+'assets/web/'+sid+'__',prefix+'data/reference_views/'+sid+'/'))}
  exact.add(prefix+'data/sidecars/1835/'+sid+'.json')
 exact|={prefix+p for p in ['data/scenes/1835.json','data/sidecars/1835/people.json','data/sidecars/1835/residents_sources.json','data/sidecars/1904/people.json','data/sidecars/1904/residents_sources.json','data/sidecars/1904/glessner_house.json','data/sidecars/1904/pullman_house_1729_prairie.json','data/sidecars/1835/sources/index.json','tools/defer_household_notes.mjs','tools/changelog_shim.mjs']}
 entry=json.loads(Path('/workspace/PR1456-genuine8fb-direct3e63-actual-publisher-20261030/final-staged-review/ENTRYWISE-FINAL-REVIEW.json').read_bytes());sources=entry['source_index']['own5_IDs'];exact|={prefix+'data/sidecars/1835/sources/'+s+'.json'for s in sources}
 assert all(p in old for p in [prefix+'data/scenes/1835.json',prefix+'data/sidecars/1904/glessner_house.json'])
 bad={p:{'X':old.get(p),'Y':new.get(p)}for p in sorted(exact)if old.get(p)!=new.get(p)}
 liberties=[]
 def obj(rev,p):return json.loads(git('show',rev+':'+prefix+p))
 for key in entry['liberties']['target_relevant_IDs']:
  rows=[]
  for rev in [X,a.head]:
   rr=[r for r in obj(rev,'data/liberties.json')['liberties']if r['id']==key];assert len(rr)==1;rows.append(rr[0])
  liberties.append(dict(id=key,exact=rows[0]==rows[1],X_sha256=sha(json.dumps(rows[0],sort_keys=True).encode()),Y_sha256=sha(json.dumps(rows[1],sort_keys=True).encode())))
 native=[]
 for name in ['NATIVE-IMAGES-SCENARIO.js','NATIVE-T3265-SCENARIO.js']:
  b=(Path('/workspace/PR1456-official-lap-bot-head-runtime-v2-frozen-20261030')/name).read_bytes();xx=git('show',X+':'+prefix+'tools/smoke_renderer.mjs');yy=git('show',a.head+':'+prefix+'tools/smoke_renderer.mjs');native.append(dict(name=name,sha256=sha(b),bytes=len(b),exact_native_slices_in_X_and_Y=xx.count(b)==yy.count(b)==1))
 guards=(before==git('status','--porcelain=v1','--untracked-files=all')and refs==git('for-each-ref')and index==git('ls-files','--stage','-z')and config==(R/'.git/config').read_bytes())
 generated=None
 if a.source_ui_binding is not None:
  binding=json.loads(a.source_ui_binding.read_bytes());assert binding['head']==X and a.head!=X;assert git('rev-parse','HEAD').decode().strip()==a.head
  picture_paths=['data/pictures/1835.json','data/pictures/1904.json'];src={}
  for rel in picture_paths:
   key=rel;expected=binding['source_1835_files'].get(key)if rel.endswith('1835.json')else None
   pub=binding['published_files'][rel]['sha256'];actual=sha((R/'site/4d'/rel).read_bytes());assert expected is None or actual==expected
   src[rel]=dict(X_published_sha256=pub,Y_source_sha256=sha((R/'chicago/4d'/rel).read_bytes()),Y_published_sha256=actual,exact=pub==actual==sha((R/'chicago/4d'/rel).read_bytes()))
  generated=dict(source_X_UI_binding={'path':str(a.source_ui_binding.resolve()),'sha256':sha(a.source_ui_binding.read_bytes())},pictures=src,all_exact=all(r['exact']for r in src.values()))
 passed=not bad and all(x['exact']for x in liberties)and all(x['exact_native_slices_in_X_and_Y']for x in native)and guards and (generated is None or generated['all_exact'])
 result=dict(status=('ACTUAL_PR1456_X_TO_NATIVE_Y_SCOPED_UI_CONSUMERS_EXACT'if a.head!=X else'PR1456_X_CONSUMER_SCOPE_READONLY_PREPARATION_SELF_BINDING_PASS')if passed else'PR1456_SCOPED_UI_CONSUMER_BRIDGE_REFUSED',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_head=X,target_head=a.head,target_tree=git('rev-parse',a.head+'^{tree}').decode().strip(),exact_source_consumer_count=len(exact),exact_source_consumers={p:old.get(p)for p in sorted(exact)},consumer_differences=bad,target_liberty_rows=liberties,native_scenarios=native,generated_picture_projection=generated,source_refs_index_config_unchanged=guards,qualification='Source consumer equivalence only; requires actual corrected X UI PASS and final Y native publication projection guards. No freshY UI or all15 smoke PASS claimed. Fresh Y officialphone400 and actual CI still required.',excluded='Global changelog and unrelated new physical scene assets; these are not original4 cards or nativeGlessner personcard consumers. Fresh Y officialphone covers retained fullworld.')
 (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['status','source_head','target_head','exact_source_consumer_count','consumer_differences','source_refs_index_config_unchanged']},indent=2));assert passed
if __name__=='__main__':main()
