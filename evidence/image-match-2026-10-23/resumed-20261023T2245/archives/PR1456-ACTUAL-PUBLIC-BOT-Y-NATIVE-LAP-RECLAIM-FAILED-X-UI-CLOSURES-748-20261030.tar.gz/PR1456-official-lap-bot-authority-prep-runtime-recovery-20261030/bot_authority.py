"""Actual repository-native LAP provenance, observed CI and native PR questions.

A bot commit is never a generic local CP or a local-gated commit. Pending CI can
support read-only runtime validation; a merge must request require_ci_pass=True.
"""
from pathlib import Path
import hashlib,importlib.util,json,re,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
assert hashlib.sha256((P/'chain_validator.py').read_bytes()).hexdigest()=='1c05d6c0ae4d64e7978c1f3f14803affa1e8a83f458716e11b1892f39f36fdc4'
spec=importlib.util.spec_from_file_location('pr1456_shared_native_predecessor_chain',P/'chain_validator.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
BRANCH=C.BRANCH;R=Path('/workspace/t2372-parallel-native-20261030');A=R/'chicago/4d'
sha=lambda b:hashlib.sha256(b).hexdigest()
ref=lambda p:{'path':str(Path(p).resolve()),'sha256':sha(Path(p).read_bytes())}
def read(row):return C.pinned(row)[1]
def raw(row):C.pinned_bytes(row);return Path(row['path']).read_bytes()
def leaves(git,revision):
 out={}
 for line in git('ls-tree','-rz',revision).split(b'\0'):
  if not line:continue
  meta,path=line.split(b'\t',1);mode,kind,blob=meta.decode().split();assert kind=='blob'and mode in['100644','100755','120000'];name=path.decode();assert name not in out;out[name]=(mode,kind,blob)
 return out
def snapshot(git):
 return dict(HEAD=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),branch=git('branch','--show-current').decode().strip(),status=git('status','--porcelain=v1','--untracked-files=all').decode(),index_semantics={'stage':sha(git('ls-files','--stage','-z')),'flags':sha(git('ls-files','-v','-z'))},all_refs=dict(x.split(' ',1)for x in git('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines()),source_config_sha256=sha((R/'.git/config').read_bytes()))
def logtext(row):
 text=raw(row).decode(errors='replace');text=re.sub(r'\x1b\[[0-9;]*m','',text);return '\n'.join(re.sub(r'^\d{4}-\d\d-\d\dT\S+Z\s+','',line)for line in text.splitlines())
def ci_proof(plan,head,tree,count,*,require_pass):
 ci=read(plan['ci_source_gate']);assert ci['status']=='ACTUAL_PR1456_OFFICIAL_LAP_HEAD_CI_SOURCE_GATE_OBSERVED'and ci['head']==head and ci['tree']==tree and ci['expected_steps']==count and type(ci['passed'])is bool
 checks=read(ci['check_runs']);assert checks['total_count']==len(checks['check_runs'])<=100
 for row in checks['check_runs']:assert row['head_sha']==head
 if not ci['passed']:
  assert not require_pass,'Actual bot-head CI source gate has not passed';return ci,dict(passed=False,head=head,tree=tree,qualification='Read-only runtime validation only; no source-gate or merge PASS inferred')
 job=read(ci['job']);run=read(ci['workflow_run']);checkout=read(ci['checkout_git_commit']);text=logtext(ci['job_log']);selected=[r for r in checks['check_runs']if r['id']==ci['selected_check_run_id']];assert len(selected)==1;check=selected[0]
 assert check['name']=='gate'and check['status']=='completed'and check['conclusion']=='success'and job['name']=='gate'and job['head_sha']==head and job['status']=='completed'and job['conclusion']=='success'and str(job['id'])in check['details_url'].split('/')
 assert run['path']=='.github/workflows/chicago-4d-check.yml'and run['head_sha']==head and run['status']=='completed'and run['conclusion']=='success'and job['run_id']==run['id']
 required={'Run actions/checkout@v4','Install validator dependencies','Run the gate'};steps={s['name']:s for s in job['steps']};assert required<=set(steps)and all(steps[n]['status']=='completed'and steps[n]['conclusion']=='success'for n in required)
 found=[];lines=text.splitlines()
 for n,line in enumerate(lines):
  if 'git log -1 --format=%H'in line.replace('"',''):
   values=[v.strip()for v in lines[n+1:n+5]if re.fullmatch('[0-9a-f]{40}',v.strip())];assert len(values)==1;found.extend(values)
 assert len(set(found))==1 and found[0]==ci['checkout_commit']==checkout['sha']and checkout['tree']['sha']==ci['checkout_tree']==tree
 if checkout['sha']!=head:assert len(checkout['parents'])==2 and checkout['parents'][1]['sha']==head
 assert re.search(r'^CHECK PASS — '+str(count)+r' steps, none red\.$',text,re.M)
 return ci,dict(passed=True,head=head,tree=tree,checkout_commit=checkout['sha'],checkout_tree=tree,full_native_steps=count,workflow_run_id=run['id'],job_id=job['id'],job_log_sha256=ci['job_log']['sha256'],local_gate_before_bot_commit_NOT_claimed=True)
def validate_bot_runtime_authority(plan,git,*,require_ci_pass=False,require_questions=True):
 assert callable(git)and plan['PR']==1456 and plan['branch']==BRANCH
 predecessor=C.validate_predecessor(plan['source_predecessor_checkpoint'],plan['source_predecessor_publication'],git,expected_immediate_merge_parent=plan.get('source_predecessor_merge_parent',C.DEFAULT_PREVIOUS_DEV));x=predecessor['head'];assert predecessor['anchor_head']==C.ANCHOR
 anchor=read(plan['source54_checkpoint']);assert plan['source54_checkpoint']['sha256']==C.ANCHOR_CP_SHA256 and anchor['head']==C.ANCHOR
 lap=read(plan['lap_provenance']);assert lap['status']=='ACTUAL_NATIVE_PR1456_OFFICIAL_LAP_PUSH_AND_OWN_LOCK_REACQUIRE_PASS'and lap['repo']=='kevinrhaas/chicago'and lap['PR']==1456 and lap['branch']==BRANCH and lap['base']=='dev'and lap['before_head']==x and lap['normal_fast_forward']is True and lap['workflowpath']=='.github/workflows/chicago-4d-pr-lap.yml'
 head,tree=plan['expected_head'],plan['expected_tree'];assert re.fullmatch('[0-9a-f]{40}',head)and re.fullmatch('[0-9a-f]{40}',tree)and lap['bot_head']==head and lap['bot_tree']==tree and head!=x
 actual=C._native(git,head);assert actual['tree']==tree;git('merge-base','--is-ancestor',x,head)
 run=read(lap['workflow_run']);text=logtext(lap['actual_job_log']);assert run['path']==lap['workflowpath']and run['event']in['push','workflow_dispatch']and run['head_branch']=='dev'and run['status']=='completed'and run['conclusion']=='success'
 assert re.search(r'^=== PR #1456\s+\('+re.escape(BRANCH)+r'\)',text,re.M)and re.search(r'^\s*pushed '+re.escape(x[:7])+r'[0-9a-f]* → '+re.escape(head[:7])+r'[0-9a-f]*\s*$',text,re.M)
 lock=lap['reacquired_own_lap'];assert re.fullmatch('[0-9a-f]{40}',lock['sha'])and isinstance(lock['actor'],str)and len(lock['actor'])>3
 review=read(plan['reviewed_manifest']);assert review['status']=='ROOT_REVIEWED_PR1456_NATIVE_LAP_HEAD'and review['root_reviewed']is True and review['head']==head and review['tree']==tree and review['actual_parents']==actual['parents']and review['source_checkpoint_head']==x and review['branch']==BRANCH
 dev=review['canonical_dev'];assert re.fullmatch('[0-9a-f]{40}',dev);git('merge-base','--is-ancestor',C.DEFAULT_PREVIOUS_DEV,dev);git('merge-base','--is-ancestor',dev,head)
 path=git('rev-list','--first-parent','--reverse',x+'..'+head).decode().splitlines();assert 1<=len(path)<=2;previous=x;merges=[]
 for commit in path:
  c=C._native(git,commit);assert c['parents'][0]==previous;identity=git('show','-s','--format=%cn%x00%ce',commit).decode().strip().split('\0');assert identity==['polecat-steward','steward@polecat.live']
  if len(c['parents'])==2:assert c['parents'][1]==dev;merges.append(commit)
  else:assert len(c['parents'])==1
  previous=commit
 assert previous==head and len(merges)<=1
 if not merges:git('merge-base','--is-ancestor',dev,x)
 merge=merges[0]if merges else None;assert review['lap_merge_commit']==merge
 subject=git('show','-s','--format=%s',head).decode();assert subject.startswith(('Lap onto dev:','Lap: re-derived against dev'))or(head==merge and subject.startswith('Merge '))
 own=review['owned_original'];foreign=review['canonical_foreign_entrywise'];assert own['source_commit']==C.ANCHOR_PARENTS[0]and set(own['tickets'])==C.TICKETS and foreign['canonical_commit']==dev and foreign['all_foreign_protected']is True
 for flag in['native_lap_derived_changes_reviewed','all_nonown_currentdev_leaves_preserved_except_native_derived','all_original4_inputs_preserved']:assert review[flag]is True
 for group in[own['proof_files'],foreign['proof_files'],review['new_owned_path_proof_files'],review['resource_price']['proof_files']]:
  assert group
  for row in group:C.pinned_bytes(row)
 qualified=leaves(git,head);base=leaves(git,dev);old=leaves(git,x);classes=[set(own['reviewed_paths']),set(foreign['mixed_paths']),set(review['required404_dependency_paths']),set(review['new_owned_path_sha256'])];owned=set().union(*classes);assert sum(map(len,classes))==len(owned)==67
 extra=review.get('additional_native_generated_paths',{});assert not(set(extra)&owned)
 if extra:
  assert review['additional_native_generated_proof_files']
  for row in review['additional_native_generated_proof_files']:C.pinned_bytes(row)
 allowed=owned|set(extra)
 for rel in set(qualified)|set(base):
  if rel not in allowed:assert qualified.get(rel)==base.get(rel),('Unreviewed foreign leaf changed',rel)
 rows={**own['reviewed_paths'],**foreign['mixed_paths'],**review['required404_dependency_paths'],**review['new_owned_path_sha256'],**review['protected404_performance_paths'],**extra}
 for rel,h in rows.items():
  assert not Path(rel).is_absolute()and'..'not in Path(rel).parts
  if h is None:assert rel not in qualified
  else:assert sha(git('show',head+':'+rel))==h
  if rel in own['reviewed_paths']:assert qualified.get(rel)==old.get(rel),('Original-four source input changed by lap',rel)
 delta={p for p in set(old)|set(qualified)if old.get(p)!=qualified.get(p)};assert delta==set(review['changed_paths_from_checkpoint'])
 for rel,h in review['changed_paths_from_checkpoint'].items():assert(h is None and rel not in qualified)or(h is not None and sha(git('show',head+':'+rel))==h)
 checkblob=qualified['chicago/4d/tools/check.sh'][2];assert sha(git('show',head+':chicago/4d/tools/check.sh'))==review['native_check_sha256']
 count=review['expected_steps'];assert type(count)is int and 1000<=count<=1500
 ci,summary=ci_proof(plan,head,tree,count,require_pass=require_ci_pass)
 questions=None
 if require_questions:
  questions=read(plan['native_pr_questions']);assert questions['status']=='ACTUAL_PR1456_OFFICIAL_LAP_HEAD_NATIVE_PR_QUESTIONS_PASS'and questions['head']==head and questions['tree']==tree and questions['canonical_dev']==dev and questions['reviewed_manifest']==plan['reviewed_manifest']and questions['source_before']==questions['source_after']and questions['source_before']['HEAD']==head and questions['source_before']['tree']==tree and questions['source_before']['branch']==BRANCH and not questions['source_before']['status']
  cmd={'changelog-entry':['node','tools/check-changelog-entry.mjs',dev,'HEAD'],'ticket-ids':['node','tools/resolve_id_collisions.mjs','--base',dev,'--check'],'fold-history':['node','tools/check-changelog.mjs']};assert len(questions['steps'])==3 and{s['name']for s in questions['steps']}==set(cmd)
  for s in questions['steps']:assert s['exit']==0 and s['command']==cmd[s['name']];C._reaped(s['reaper'],s['reaper_sha256'],cmd[s['name']]);assert sha(Path(s['log']).read_bytes())==s['log_sha256']
  assert questions['all_children_reaped']is True and questions['source_tracked_working_modes_blobs_exact_before_after']is True
 authority=[plan[k]for k in['source54_checkpoint','source_predecessor_checkpoint','source_predecessor_publication','lap_provenance','reviewed_manifest','ci_source_gate']]+([plan['native_pr_questions']]if require_questions else[])
 return dict(head=head,tree=tree,parents=actual['parents'],source_checkpoint_head=x,canonical_dev=dev,lap_merge_commit=merge,reviewed_manifest=review,predecessor_context=predecessor,authority_pins=authority,CI_proof=ci,CI_summary=summary,native_question_proofs=questions,lap_provenance=lap,source_anchor=C.ANCHOR,bot_commit_not_generic_local_CP=True,CI_pending_allowed_only_for_runtime_validation=not require_ci_pass)
