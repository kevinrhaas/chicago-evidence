"""Bounded read-only actual bot-head CI checkout/full-source-gate observer."""
from pathlib import Path
import argparse,datetime,hashlib,io,json,os,re,time,zipfile
from urllib.request import Request,urlopen
import bot_authority as B
REPO='kevinrhaas/chicago'
def api(path):
 with urlopen(Request('https://api.github.com/repos/'+REPO+'/'+path+('&'if'?'in path else'?')+'codex_read='+str(time.time_ns()),headers={'User-Agent':'Chicago-PR1456-native-lap-actual-CI-readonly','Accept':'application/vnd.github+json'}),timeout=90)as r:return json.load(r)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--head',required=True);ap.add_argument('--tree',required=True);ap.add_argument('--expected-steps',required=True,type=int);ap.add_argument('--output',required=True,type=Path);a=ap.parse_args();os.sched_setaffinity(0,{2});os.nice(19);assert re.fullmatch('[0-9a-f]{40}',a.head)and re.fullmatch('[0-9a-f]{40}',a.tree)and 1000<=a.expected_steps<=1500
 out=a.output.resolve();assert out.is_relative_to('/workspace')and not out.is_relative_to(B.R)and not out.is_relative_to('/workspace/chicago')and not out.exists();out.mkdir();save=lambda n,d:(out/n).write_text(json.dumps(d,indent=2)+'\n')
 commit=api('git/commits/'+a.head);assert commit['sha']==a.head and commit['tree']['sha']==a.tree;save('PUBLIC-BOT-COMMIT.json',commit);checks=api('commits/'+a.head+'/check-runs?per_page=100');assert checks['total_count']==len(checks['check_runs'])<=100;save('CHECK-RUNS.json',checks)
 obs=dict(status='ACTUAL_PR1456_OFFICIAL_LAP_HEAD_CI_SOURCE_GATE_OBSERVED',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=a.head,tree=a.tree,expected_steps=a.expected_steps,passed=False,check_runs=B.ref(out/'CHECK-RUNS.json'),public_head_commit=B.ref(out/'PUBLIC-BOT-COMMIT.json'),selected_check_run_id=None,job=None,workflow_run=None,job_log=None,checkout_git_commit=None,checkout_commit=None,checkout_tree=None,read_error=None,read_only_no_dispatch_or_rerun=True)
 gates=sorted([r for r in checks['check_runs']if r['name']=='gate'],key=lambda r:(r.get('started_at')or'',r['id']))
 if gates:
  gate=gates[-1];obs['selected_check_run_id']=gate['id'];m=re.search(r'/actions/runs/(\d+)/job/(\d+)',gate.get('details_url',''))
  if m:
   run=api('actions/runs/'+m[1]);job=api('actions/jobs/'+m[2]);save('WORKFLOW-RUN.json',run);save('JOB.json',job);obs.update(job=B.ref(out/'JOB.json'),workflow_run=B.ref(out/'WORKFLOW-RUN.json'))
   if gate['status']=='completed'and gate['conclusion']=='success'and job['status']=='completed'and job['conclusion']=='success'and run['status']=='completed'and run['conclusion']=='success':
    try:
     with urlopen(Request('https://api.github.com/repos/'+REPO+'/actions/jobs/'+m[2]+'/logs',headers={'User-Agent':'Chicago-PR1456-actual-checkout-source-log-readonly','Accept':'application/vnd.github+json'}),timeout=90)as response:data=response.read(32*1024*1024+1)
     assert len(data)<=32*1024*1024
     if data.startswith(b'PK'):
      with zipfile.ZipFile(io.BytesIO(data))as z:
       assert sum(i.file_size for i in z.infolist())<=64*1024*1024;data=b'\n'.join(z.read(n)for n in z.namelist()if n.endswith('.txt'))
     (out/'JOB.log').write_bytes(data);obs['job_log']=B.ref(out/'JOB.log');text=B.logtext(obs['job_log']);lines=text.splitlines();found=[]
     for i,line in enumerate(lines):
      if 'git log -1 --format=%H'in line.replace('"',''):found.extend(v.strip()for v in lines[i+1:i+5]if re.fullmatch('[0-9a-f]{40}',v.strip()))
     assert len(set(found))==1 and found;checkout=api('git/commits/'+found[0]);save('CHECKOUT-GIT-COMMIT.json',checkout);obs.update(checkout_git_commit=B.ref(out/'CHECKOUT-GIT-COMMIT.json'),checkout_commit=checkout['sha'],checkout_tree=checkout['tree']['sha']);assert checkout['tree']['sha']==a.tree and re.search(r'^CHECK PASS — '+str(a.expected_steps)+r' steps, none red\.$',text,re.M);obs['passed']=True
    except Exception as e:obs['read_error']=dict(type=type(e).__name__,HTTP_status=getattr(e,'code',None),not_a_claim_of_product_failure=True)
 save('RESULT.json',obs)
 # Re-use the strict pure join to prove a PASS observation, not merely its label.
 if obs['passed']:B.ci_proof({'ci_source_gate':B.ref(out/'RESULT.json')},a.head,a.tree,a.expected_steps,require_pass=True)
 print(json.dumps({k:obs[k]for k in['status','head','tree','passed','checkout_commit','checkout_tree','selected_check_run_id','read_error']},indent=2))
if __name__=='__main__':main()
