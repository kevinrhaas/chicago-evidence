"""Read-only native CP ancestry and actual normal-FF predecessor publication proof.

No network, refs, checkout, configuration, runtime, CI or source mutation. The git
callback must execute ordinary read-only commands in the actual source clone.
"""
from pathlib import Path
import datetime,hashlib,json,math,re
BRANCH='steward/t2381-t2373-t2384-t2377-early-pictures-20261029'
ANCHOR='3e63ad191b0c264fa3d6a0707db9ffeed7e4de79'
ANCHOR_TREE='444505c7ca5a22c7e90c653a10f579630be6978c'
ANCHOR_PARENTS=['3746b23bf1298c34a29946b4cdb6ee2d98abff8f','54e4004add7ab5208d71a51282c008cda6e7edad']
ANCHOR_CP_SHA256='6d1e34851ef788b6b519692ea745274e3aea89f4b1c90146de34bede4030fcbf'
ANCHOR_GATE_SHA256='d8ae95116ef23662feddb8114e30605d79c9db489b44c6f760198e1d2f908e33'
ANCESTOR8B='8b4e98207c1afcff4878239cd700379447218cfb'
DEFAULT_PREVIOUS_DEV='8fbbe09b8b6ca4f96d8a9e2dd1b74a415d18ae4a'
TICKETS={'T-2381','T-2373','T-2384','T-2377'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def pinned(row):
 assert isinstance(row,dict)and re.fullmatch('[0-9a-f]{64}',row['sha256']);p=Path(row['path']);assert p.is_absolute()and p.is_relative_to('/workspace')and p.is_file()and not p.is_symlink();raw=p.read_bytes();assert sha(raw)==row['sha256'];return p,json.loads(raw)
def _ref(path,digest):return {'path':str(Path(path).resolve()),'sha256':digest}
def _reaped(path,digest,command):
 p,r=pinned(_ref(path,digest));assert r['command_exit']==0 and r['all_children_reaped']is True and not r['leftover_cleanup']and r['command'][-len(command):]==command;return r
def _native(git,head):
 assert re.fullmatch('[0-9a-f]{40}',head);return dict(tree=git('rev-parse',head+'^{tree}').decode().strip(),parents=git('show','-s','--format=%P',head).decode().strip().split(),committer_unix=int(git('show','-s','--format=%ct',head).decode().strip()))
def validate_predecessor(checkpoint_pin,publication_pin,git,*,expected_immediate_merge_parent=DEFAULT_PREVIOUS_DEV,max_depth=8):
 assert callable(git)and type(max_depth)is int and 1<=max_depth<=16
 if expected_immediate_merge_parent is not None:assert re.fullmatch('[0-9a-f]{40}',expected_immediate_merge_parent)
 chain=[];seen=set();pin=dict(checkpoint_pin);immediate=None
 while True:
  assert len(chain)<max_depth;p,cp=pinned(pin);head=cp['head'];assert head not in seen;seen.add(head)
  native=_native(git,head);assert re.fullmatch('[0-9a-f]{40}',cp['tree'])and len(cp['parents'])==2 and all(re.fullmatch('[0-9a-f]{40}',x)for x in cp['parents'])and head not in cp['parents']and native['tree']==cp['tree']and native['parents']==cp['parents']and cp['branch']==BRANCH and cp['clean']is True and cp['only_own_branch_ref_changed']is True
  anchor=head==ANCHOR;expected_status='ACTUAL_PR1456_GENUINE54_NATIVE_TWO_PARENT_CHECKPOINT_PASS'if anchor else'ACTUAL_PR1456_GENUINE_NAMED_DEV_NATIVE_TWO_PARENT_CHECKPOINT_PASS';assert cp['status']==expected_status
  if anchor:assert pin['sha256']==ANCHOR_CP_SHA256 and cp['tree']==ANCHOR_TREE and cp['parents']==ANCHOR_PARENTS and cp['revision']=='PR1456_GENUINE_54'
  else:assert cp['revision']=='PR1456_GENUINE_NAMED_DEV';git('merge-base','--is-ancestor',ANCESTOR8B,cp['parents'][1])
  gate_pin=_ref(cp['source_gate'],cp['source_gate_sha256']);gp,gate=pinned(gate_pin);b=gate['binding'];assert gate['guards']and all(v is True for v in gate['guards'].values())and gate['step']['exit']==0 and gate.get('exit',0)==0
  assert gate['status']==('ACTUAL_PR1456_GENUINE54_FULL1105_SOURCE_PASS'if anchor else'ACTUAL_PR1456_GENUINE_NAMED_DEV_FULL_SOURCE_PASS')
  assert b['head']==b['source_head']==cp['parents'][0]and b['merge_parent']==cp['parents'][1]and b['parents']==cp['parents']and b['tree']==cp['tree']and b['branch']==BRANCH and b['reviewed_manifest_sha256']==cp['reviewed_manifest_sha256']
  mp,manifest=pinned(_ref(b['reviewed_manifest'],b['reviewed_manifest_sha256']));assert manifest['root_reviewed']is True and manifest['status']==('ROOT_REVIEWED_PR1456_GENUINE_54_INTEGRATION_STAGED'if anchor else'ROOT_REVIEWED_PR1456_GENUINE_NAMED_DEV_INTEGRATION_STAGED')and manifest['source_head']==cp['parents'][0]and manifest['merge_parent']==cp['parents'][1]and manifest['tree']==cp['tree']and manifest['branch']==BRANCH
  assert manifest['owned_original']['source_commit']==ANCHOR_PARENTS[0]and set(manifest['owned_original']['tickets'])==TICKETS and manifest['canonical_foreign_entrywise']['canonical_commit']==cp['parents'][1]and manifest['canonical_foreign_entrywise']['all_foreign_protected']is True
  for group in[manifest['owned_original']['proof_files'],manifest['canonical_foreign_entrywise']['proof_files'],manifest['resource_price']['proof_files']]+([manifest['new_owned_path_proof_files']]if not anchor else[]):
   assert group
   for row in group:pinned_bytes(row)
  if cp.get('reviewed_manifest')is not None:assert Path(cp['reviewed_manifest']).resolve()==mp.resolve()
  count=manifest['expected_steps'];assert type(count)is int and 1000<=count<=1500
  if anchor:assert gate_pin['sha256']==ANCHOR_GATE_SHA256 and count==1105;log=gp.parent/'check.log';timings=gp.parent/'TIMINGS.tsv';reap=gp.parent/'check-REAPER.json'
  else:
   assert b['staged_paths']==cp['staged_paths']==manifest['staged_paths']
   assert cp['prior_checkpoint']==b['prior_checkpoint']and cp['prior_checkpoint_sha256']==b['prior_checkpoint_sha256']
   log,timings,reap=(Path(gate[k])for k in['native_check_log','native_timings','native_reaper'])
   for key,path in[('native_check_log',log),('native_timings',timings),('native_reaper',reap)]:assert sha(path.read_bytes())==gate[key+'_sha256']
  _reaped(reap,gate['step']['reaper_sha256'],['bash','tools/check.sh']);clean=re.sub(r'\x1b\[[0-9;]*m','',log.read_text(errors='replace'));assert re.search(r'^CHECK PASS — '+str(count)+r' steps, none red\.$',clean,re.M)and'bash tools/publish.sh'in timings.read_text()
  questions={'changelog-entry':['node','tools/check-changelog-entry.mjs',cp['parents'][1],'HEAD'],'ticket-ids':['node','tools/resolve_id_collisions.mjs','--base',cp['parents'][1],'--check'],'fold-history':['node','tools/check-changelog.mjs']};assert len(cp['steps'])==3 and{s['name']for s in cp['steps']}==set(questions)
  for step in cp['steps']:assert step['exit']==0;_reaped(gp.parent/(step['name']+'-REAPER.json'),step['reaper_sha256'],questions[step['name']])
  gt=datetime.datetime.fromisoformat(gate['at'].replace('Z','+00:00')).timestamp();ct=datetime.datetime.fromisoformat(cp['at'].replace('Z','+00:00')).timestamp();assert gt<=ct and math.floor(gt)<=native['committer_unix']<=math.ceil(ct)
  node=dict(path=str(p),sha256=pin['sha256'],head=head,tree=cp['tree'],parents=cp['parents'],branch=BRANCH,source_gate_sha256=gate_pin['sha256'],native_full_gate_steps=count,reviewed_manifest_sha256=b['reviewed_manifest_sha256']);chain.append(node)
  if immediate is None:
   immediate=dict(node);immediate_cp=cp;immediate_manifest=manifest
   if expected_immediate_merge_parent is not None:assert cp['parents'][1]==expected_immediate_merge_parent
  if anchor:break
  prior_pin=_ref(cp['prior_checkpoint'],cp['prior_checkpoint_sha256']);_,prior=pinned(prior_pin);assert prior['head']==cp['parents'][0];pin=prior_pin
 pp,pub=pinned(publication_pin);cp=immediate_cp;expected_pub='ACTUAL_SOURCE_QUALIFIED_PR1456_NATIVE_NORMAL_FF_CHECKPOINT_AND_ALL_CHANGED_PATH_READBACK_PASS'if cp['head']==ANCHOR else'ACTUAL_SOURCE_QUALIFIED_PR1456_GENUINE_NAMED_DEV_NATIVE_NORMAL_FF_CHECKPOINT_AND_ALL_CHANGED_PATH_READBACK_PASS'
 assert pub['status']==expected_pub and pub['head']==cp['head']and pub['tree']==cp['tree']and pub['parents']==cp['parents']and pub['expected_old']==cp['parents'][0]and pub['branch']==BRANCH and pub['force']is False and pub['source_HEAD_index_semantics_config_status_allrefs_unchanged']is True and pub['gate_sha256']==cp['source_gate_sha256']and pub['checkpoint_sha256']==checkpoint_pin['sha256']
 rows=pub['readback'];assert rows and len(rows)==len({r['path']for r in rows});expected={p for p,h in immediate_manifest['staged_paths'].items()if h is not None};assert{r['path']for r in rows}==expected
 for row in rows:
  rel=row['path'];assert not Path(rel).is_absolute()and'..'not in Path(rel).parts;raw=git('show',cp['head']+':'+rel);blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==row['blob']and sha(raw)==row['sha256']and len(raw)==row['bytes']
 return dict(path=immediate['path'],sha256=immediate['sha256'],head=immediate['head'],tree=immediate['tree'],parents=immediate['parents'],branch=BRANCH,source_gate_sha256=immediate['source_gate_sha256'],publication=dict(path=str(pp),sha256=publication_pin['sha256']),anchor_head=ANCHOR,chain=chain)
def pinned_bytes(row):
 assert re.fullmatch('[0-9a-f]{64}',row['sha256']);p=Path(row['path']);assert p.is_absolute()and p.is_relative_to('/workspace')and p.is_file()and not p.is_symlink()and sha(p.read_bytes())==row['sha256']
