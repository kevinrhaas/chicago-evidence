"""Run only the three native PR questions on the imported clean official LAP head."""
import argparse,datetime,json,os,subprocess,time
from pathlib import Path
import bot_authority as B
P=Path(__file__).resolve().parent;R=B.R;A=B.A
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def working():
 expected=B.leaves(git,'HEAD');actual={}
 for line in git('ls-files','--stage','-z').split(b'\0'):
  if not line:continue
  meta,rel=line.split(b'\t',1);mode,blob,stage=meta.decode().split();assert stage=='0';rel=rel.decode();actual[rel]=(mode,'blob',blob);p=R/rel
  if mode=='120000':assert p.is_symlink();raw=os.readlink(p).encode()
  else:assert mode in['100644','100755']and p.is_file()and not p.is_symlink()and bool(p.stat().st_mode&0o111)==(mode=='100755');raw=p.read_bytes()
  assert B.hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 assert actual==expected

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root-plan',required=True,type=Path);ap.add_argument('--root-plan-sha256',required=True);ap.add_argument('--output',required=True,type=Path);ap.add_argument('--execute',action='store_true');a=ap.parse_args();assert a.execute;os.sched_setaffinity(0,{2});os.nice(19)
 assert B.sha(a.root_plan.read_bytes())==a.root_plan_sha256;plan=json.loads(a.root_plan.read_bytes());assert plan['status']=='ROOT_APPROVED_PR1456_OFFICIAL_LAP_HEAD_NATIVE_PR_QUESTIONS'and plan['root_approved']is True
 cap=plan['bot_authority_capsule'];manifest=B.read(cap);assert Path(cap['path']).parent==P
 for name,row in manifest['members'].items():assert B.sha((P/name).read_bytes())==row['sha256']
 q=B.validate_bot_runtime_authority(plan,git,require_ci_pass=False,require_questions=False);before=B.snapshot(git);assert before['HEAD']==q['head']and before['tree']==q['tree']and before['branch']==B.BRANCH and not before['status']and not(R/'.git/MERGE_HEAD').exists()and before['source_config_sha256']==q['reviewed_manifest']['source_config_sha256'];working()
 out=a.output.resolve();assert out.is_relative_to('/workspace')and not out.is_relative_to(R)and not out.is_relative_to('/workspace/chicago')and not out.exists();out.mkdir();tmp=out/'tmp';tmp.mkdir();env=dict(E,TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),NODE_COMPILE_CACHE=str(tmp/'node-compile-cache'));save=lambda n,d:(out/n).write_text(json.dumps(d,indent=2)+'\n');save('SOURCE-BEFORE.json',before)
 commands=[('changelog-entry',['node','tools/check-changelog-entry.mjs',q['canonical_dev'],'HEAD']),('ticket-ids',['node','tools/resolve_id_collisions.mjs','--base',q['canonical_dev'],'--check']),('fold-history',['node','tools/check-changelog.mjs'])];steps=[]
 for name,cmd in commands:
  rp=out/(name+'-REAPER.json');log=out/(name+'.log');start=time.monotonic();argv=['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','nice','-n','19','taskset','-c','2',*cmd]
  with log.open('xb')as f:result=subprocess.run(argv,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT)
  row=dict(name=name,command=cmd,argv=argv,exit=result.returncode,seconds=time.monotonic()-start,reaper=str(rp),reaper_sha256=B.sha(rp.read_bytes()),log=str(log),log_sha256=B.sha(log.read_bytes()));steps.append(row);save('STEPS.json',steps);assert row['exit']==0;B.C._reaped(rp,row['reaper_sha256'],cmd);assert B.snapshot(git)==before;working()
 after=B.snapshot(git);assert after==before and B.sha(a.root_plan.read_bytes())==a.root_plan_sha256
 for name,row in manifest['members'].items():assert B.sha((P/name).read_bytes())==row['sha256']
 save('RESULT.json',dict(status='ACTUAL_PR1456_OFFICIAL_LAP_HEAD_NATIVE_PR_QUESTIONS_PASS',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=q['head'],tree=q['tree'],canonical_dev=q['canonical_dev'],reviewed_manifest=plan['reviewed_manifest'],root_plan={'path':str(a.root_plan.resolve()),'sha256':a.root_plan_sha256},helper_sha256=B.sha(Path(__file__).read_bytes()),bot_authority_capsule=cap,source_before=before,source_after=after,steps=steps,all_children_reaped=True,source_tracked_working_modes_blobs_exact_before_after=True,local_generic_CP_or_local_full_gate_before_bot_commit_NOT_claimed=True,CI_pass_not_inferred_from_questions=True));print((out/'RESULT.json').read_text())
if __name__=='__main__':main()
