# Whistler five-front identity and proposed native grade rulings

LIGHT source review only, unapplied. Actually viewed the uncropped 1600×2290 Whistler sheet, existing garrison/south details and all five prepared front crops. Independently reread Quaife 1913's actual publication, note 413 and pp. 164–165, via its registered Gutenberg URL. No new camera, image edit, render, Blender export, producer, full gate, claim or canonical write occurred. The original T-2387/T-3041 image gates remain open; all nine held compound verdicts remain **differs**, and the five individual-front comparisons are **UNRUN**.

`proposed-pictured-rulings.json` is an additive fragment for the EXISTING `data/structure_grades.json` mechanism, exactly five `scene:1812` / `picture:whistler_1808_fort_dearborn_draught` entries. It is not a replacement for the current whole ruling file and contains no fake cameras or negative blanket exclusions.

| Existing target suffix | Identification on complete sheet and publication | Actual whole-front evidence |
|---|---|---|
| `north_range` | One northern roof over plan compartments 12 Soldiers Barracks and 13 Contractors Store; p. 165 explicitly describes this combined building opposite the south gateway. | Four openings on each of two storeys and complete roof. Interior room division does not imply two buildings. |
| `officers_barracks` | Western plan range 11 Officers Barracks; p. 165 places subordinate officers opposite east commanding quarters. | Whole five-bay, two-storey folded front, roof and drawn stacks. |
| `commanding_officers_barracks` | Eastern plan range 10 Comm'g Officers Barracks; p. 165 explicitly names commanding quarters on the east. | Whole four-bay, two-storey folded front and roof. |
| `soldiers_barracks_sw` | Southern plan compartments 12 west of the main gateway; p. 165 identifies soldiers' barracks flanking both sides of the south gate. | Separate four-bay two-storey front and roof. Gatehouse touches inner end; barracks front remains separately readable. |
| `soldiers_barracks_se` | Other southern compartments 12 east of the same main gateway. | Other separate four-bay two-storey front and roof, also distinguishable from adjoining gatehouse. |

These are reasonable whole facade pictures under rule 12 even though the combined sheet is typed `map`; the plan alone is NOT the appearance evidence. Each ruling explicitly rests on its folded elevation and plan/index identity. The same original sheet supports all five, but each identification was separately checked. Quarter turns only orient these existing crops upright; no perspective or scan-aspect correction is used.

The drawing is January 25, 1808; Whistler's accompanying index is signed February 20, 1808. The consulted reproduction was published in 1913, not a 1913 depicted building phase. Appearance continuity to the existing 1812 scene remains inferred. Attested structure grades do not attest metric heights, opening types, exact sash/door/gallery details, true bearing, hidden elevations, unchanged 1812 fittings or a completed model match. Existing per-attribute confidence and coordinates remain untouched.

## Historical handoff errata — preserve old evidence unchanged

The frozen `/tmp/chicago-next-model/T-2387-coverage-audit/README.md` accidentally reverses the two officers' index numbers. Correct publication text: **10 commanding officers; 11 officers**. Existing canonical records, current crop identities, source-counted 4/5 front layouts and positions are already correct, so no geometry/camera/record reassignment is needed.

Two other index references in that old prose also must not propagate: **1 means Block Houses (both corners); 2 means cannon port holes**, not a second blockhouse identity; **20 means Armerers Shop**, not the flagstaff. The staff is separately lettered Flag Staff and 75 feete in the actual sheet. Existing canonical blockhouse and staff records state these correctly. This new erratum does not rewrite or invalidate the preserved actual images/exports/render receipts. Keep the separate magazine-identification erratum open too.

## Explicitly unadjudicated

`unadjudicated-members.json` records why the two chimney-only blockhouse targets remain inferred in this bounded packet: their whole built appearance is not adjudicated by the five range crops, and Whistler expressly distinguishes drawn cupolas as not yet built. Do not invent cupola completion dates or treat this as a finding that no retrospective blockhouse picture exists. The other 23 inventory records retain their existing grades; Currey's partly concealed courtyard ranges receive no blanket individual-picture ruling. No new `not_pictured` rule suppresses future evidence.

## Proof and adoption limits

`verify_rulings.py` / `native-grade-proof.json`: PASS native `check_rulings`, registered source, actual 1812 membership and all 30 inventory grades. Exactly the five source-identified ranges become attested; the other 25 stay byte-equal as grade objects, including both blockhouses staying inferred. All five crop pixel derivations exactly match the original source crop boxes, declared quarter turns and nearest 3× enlargement. The source original SHA remains `4568caacfde738aa5273411ac27a61a2a350dc78b715ea75ee8eab66af72bfb1`.

Native test base is the earlier committed 6bf object snapshot, not the root dirty tree. After the parent announces the next published head, merge these five reviewed entries additively against that head and rerun native membership/source/duplicate guards. Rematerialize a NEW ten-front runner only after refreshing its guards; keep historic masters, source crops, camera fields and all old evidence immutable. Actual comparisons and production adoption still require an explicit root grant.
