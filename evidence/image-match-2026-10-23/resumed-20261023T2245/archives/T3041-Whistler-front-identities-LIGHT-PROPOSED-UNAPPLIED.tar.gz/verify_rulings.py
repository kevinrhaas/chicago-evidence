"""CPU-only identity/grade admission proof, without writing canonical data."""
from pathlib import Path
import hashlib,importlib.util,json,sys
from PIL import Image
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;P=Path('/tmp/chicago-next-model/T3041-gallery-front-adoption-20261024');R=Path('/tmp/chicago-next-model/T3041-native-readiness-20261024/published6bf/chicago/4d')
sys.path.insert(0,str(R/'tools'))
import grade_structures as native
bindings=json.loads((P/'front-bindings.json').read_text());proposed=json.loads((H/'proposed-pictured-rulings.json').read_text());base=json.loads((R/'data/structure_grades.json').read_text());merged={**base,'pictured':base['pictured']+proposed['pictured']};sources={p.stem:json.loads(p.read_text())for p in(R/'data/sources').glob('*.json')}
scene_ids={e['id']for e in json.loads((R/'data/sidecars/1812/index.json').read_text())['structures']};assert len(proposed['pictured'])==5;assert not native.check_rulings(proposed,{'1812':scene_ids},sources)
expected={r['structure_id']for r in bindings['fronts']};assert {r['structure']for r in proposed['pictured']}==expected
for row in proposed['pictured']:
 assert row['scene']=='1812' and row['picture']=='whistler_1808_fort_dearborn_draught' and row['picture'] in sources
 assert not any(e['scene']==row['scene'] and e['structure']==row['structure'] and e['picture']==row['picture']for e in base['pictured'])
# Verify every prepared crop's complete pixel provenance without producing/editing any image.
image_rows=[]
for row in bindings['fronts']:
 src=Path(row['source_derivation']['source_original']);crop=Path(row['source_crop']);assert hashlib.sha256(src.read_bytes()).hexdigest()==row['source_derivation']['original_sha256'];assert hashlib.sha256(crop.read_bytes()).hexdigest()==row['source_crop_sha256']
 with Image.open(src) as original,Image.open(crop) as existing:
  view=original.crop(row['source_derivation']['crop_box_original_px']).rotate(row['source_derivation']['quarter_turn_CCW_deg'],expand=True)
  view=view.resize((view.width*3,view.height*3),Image.Resampling.NEAREST);assert view.size==existing.size and view.convert('RGBA').tobytes()==existing.convert('RGBA').tobytes()
 image_rows.append({'part':row['part'],'source_sha256':row['source_derivation']['original_sha256'],'crop_sha256':row['source_crop_sha256'],'pixel_exact_declared_crop_quarter_turn_nearest3x':True})
inventory=json.loads(Path('/tmp/chicago-next-model/T-2387-coverage-audit/inventory.json').read_text());rows=[]
for recrow in inventory['rows']:
 sid=recrow['id'];rec=json.loads((R/'data/structures'/f'{sid}.json').read_text());phase=next(p for p in rec['phases']if p['id']==recrow['phase']);exist=phase['documented_range'].get('confidence','reconstructed')
 before=native.grade_structure(sid,exist,[],[],base,'1812');after=native.grade_structure(sid,exist,[],[],merged,'1812')
 if sid in expected:assert after['value']=='attested' and after['pictures']==['whistler_1808_fort_dearborn_draught']
 else:assert before==after
 rows.append({'structure':sid,'scope':recrow['scope'],'before':before,'proposed_after':after,'changed':before!=after})
assert sum(r['changed']for r in rows)==5 and len(rows)==30
# No generator/recipe, canonical camera, render acceptance or metric-position file is authored here.
report={'status':'PASS','actual_native_fragment_check_rulings_faults':0,'registered_source_picture_and_real1812_membership_verified':True,'new_existing_mechanism_pictured_rulings':5,'all30_checked':30,'changed_native_grades':5,'other25_grades_exact_unchanged':True,'two_chimney_only_blockhouses_still_inferred':all(r['proposed_after']['value']=='inferred'for r in rows if r['structure']in ['first_fort_dearborn_blockhouse_nw','first_fort_dearborn_blockhouse_se']),'five_source_crop_derivations':image_rows,'all30_grades':rows,'limitations':'This is a proposed source-identity/grade admission only. No canonical data, camera, mesh, sidecar or Image gate verdict changed. Five rendered front comparisons remain UNRUN; full original image matches remain open/differs.'}
(H/'native-grade-proof.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ['all30_grades','five_source_crop_derivations']},indent=2))
