from pathlib import Path
import sys,types,importlib.util,json,dataclasses,hashlib,math,time,copy,inspect
sys.dont_write_bytecode=True
out=Path(__file__).resolve().parent;root=Path('/workspace/chicago/chicago/4d');base=Path('/tmp/dearborn-profile-implemented-20261029/before/chicago/4d');cand=out/'candidate/chicago/4d';start=time.monotonic()
sys.path.insert(0,str(root/'generators'));sys.modules['bpy']=types.ModuleType('bpy')
from common import mesh
mesh.MeshBuilder.to_object=lambda self,mats=None:{'verts':self.verts,'faces':self.faces,'confidence':self.conf,'materials':mats,'mat_index':self.mat_index,'named':self.named}
mesh.simple_material=lambda name,rgba,roughness=.75:{'name':name,'rgba':rgba,'roughness':roughness}
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=load('crib_old_params',base/'generators/archetypes/bridge_timber_params.py');new=load('crib_new_params',cand/'generators/archetypes/bridge_timber_params.py')
def producer(name,params):
 sys.modules['archetypes.bridge_timber_params']=params;return load(name,(cand if params is new else base)/'generators/archetypes/bridge_timber.py')
of=producer('crib_old_build',old);nf=producer('crib_new_build',new)
entries=json.loads((root/'assets/manifest.json').read_text())['assets'];rows=[];inputs={root/'assets/manifest.json',root/'generators/archetypes/bridge_timber.py',root/'generators/archetypes/bridge_timber_params.py',root/'generators/common/mesh.py',root/'generators/common/materials.py',root/'generators/common/logwork.py'}
records=[]
for asset,e in entries.items():
 if e.get('archetype')!='bridge_timber':continue
 rp=root/'data/structures'/f"{e['structure_id']}.json";inputs.add(rp);records.append((asset,e,rp))
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
for asset,e,rp in records:
 r=json.loads(rp.read_text());ph=next(p for p in r['phases'] if p['id']==e['phase_id']);a=old.from_phase(ph,r);b=new.from_phase(ph,r)
 d=dataclasses.asdict(b);assert d.pop('draw_bearing_supports') is False;assert d.pop('draw_profile') == 'flat';assert d.pop('draw_rise_m') == 0;assert d.pop('gallows_shore_attach_m') is None;assert d.pop('draw_bearing_platform_m') is None;assert d.pop('draw_bearing_platform_offset_m') == 0.0;assert d==dataclasses.asdict(a)
 ga=of.build(a,asset);gb=nf.build(b,asset);assert ga==gb,asset
 rows.append({'asset':asset,'verts':len(gb['verts']),'polygons':len(gb['faces']),'whole_raw_geometry_material_confidence_named_exact':True})
assert len(rows)==6
old_fields=dataclasses.fields(old.BridgeTimberParams);new_fields=dataclasses.fields(new.BridgeTimberParams);legacy=[f for f in new_fields if f.name not in ['draw_bearing_supports','draw_profile','draw_rise_m','gallows_shore_attach_m','draw_bearing_platform_m','draw_bearing_platform_offset_m']]
assert [(f.name,f.default,f.default_factory,f.kw_only) for f in old_fields]==[(f.name,f.default,f.default_factory,f.kw_only) for f in legacy]
assert inspect.signature(new.BridgeTimberParams).parameters['draw_bearing_supports'].kind==inspect.Parameter.KEYWORD_ONLY
assert old.BridgeTimberParams.__match_args__==new.BridgeTimberParams.__match_args__
r=json.loads((cand/'data/structures/dearborn_street_drawbridge.json').read_text());p=new.from_phase(r['phases'][0],r)
before_record=copy.deepcopy(r)
for key in ['draw_bearing_supports','draw_profile','draw_rise_m','gallows_shore_attach_m','draw_bearing_platform_m','draw_bearing_platform_offset_m']:before_record['phases'][0]['form'].pop(key)
a=old.from_phase(before_record['phases'][0],before_record);ga=of.build(a,'same');gb=nf.build(p,'same')
assert len(a.pier_x)==len(p.pier_x)==12
assert p.gallows_x==a.gallows_x and p.deck_height_m==a.deck_height_m
assert all(math.isfinite(k) for v in gb['verts'] for k in v)
plan_bounds=[[min(v[k] for v in gb['verts']),max(v[k] for v in gb['verts'])] for k in [0,1]]
assert plan_bounds[0][0]>=-1 and plan_bounds[0][1]<=p.span_m+1 and plan_bounds[1][0]>=-3 and plan_bounds[1][1]<=p.width_m+1
assert set(gb['confidence']) <= {0.0,.5,1.0}
invalid=[]
for name,change in [('numeric1',{'draw_bearing_supports':1}),('string',{'draw_bearing_supports':'yes'}),('None',{'draw_bearing_supports':None}),('no_draw',{'draw_span_m':None}),('one_gallows',{'gallows_frames':1}),('no_survivors',{'draw_span_m':75.0}),('one_bay',{'pier_count':0}),('zero_rise',{'draw_rise_m':0}),('nan_rise',{'draw_rise_m':float('nan')}),('bool_rise',{'draw_rise_m':True}),('over3m_rise',{'draw_rise_m':3.01}),('overquarter_rise',{'draw_rise_m':2.,'draw_span_m':6.}),('flat_with_rise',{'draw_profile':'flat'}),('wrong_profile',{'draw_profile':'open'})]:
 try:dataclasses.replace(p,**change).validate()
 except new.ParamError:invalid.append(name)
 else:raise AssertionError(name)
# Independently intersect the actual native deck polygons at chosen non-gap floor points.
# This is not a render/export. Preserve gaps: do not invent a height when no deck face covers x/y.
def triangle_height(pt,tri):
 x,y=pt;(ax,ay,az),(bx,by,bz),(cx,cy,cz)=tri
 den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy)
 if abs(den)<1e-14:return None
 u=((by-cy)*(x-cx)+(cx-bx)*(y-cy))/den
 v=((cy-ay)*(x-cx)+(ax-cx)*(y-cy))/den;w=1-u-v
 if min(u,v,w)<-1e-9:return None
 return u*az+v*bz+w*cz
triangles=[]
for f,mat in zip(gb['faces'],gb['mat_index']):
 if mat != nf.M_DECK:continue
 pts=[gb['verts'][i] for i in f]
 # Pile-platform cap is M_DECK too, but lies below the bridge floor; it is
 # not a walking-surface face and must not convert the original plank gaps into hits.
 if max(q[2] for q in pts)<p.deck_height_m-p.plank_t_m-1e-9:continue
 for j in range(1,len(pts)-1):triangles.append([pts[0],pts[j],pts[j+1]])
physical=[];gaps=[]
for x in [i*p.span_m/120+0.001 for i in range(120)]:
 hits=[z for tri in triangles if (z:=triangle_height((x,p.width_m/2),tri)) is not None]
 expected=p.deck_height_m + new.draw_rise_m_at(p,x)
 if not hits:gaps.append(x);continue
 top=max(hits);assert abs(top-expected)<1e-10,(x,top,expected)
 physical.append({'x':x,'mesh_deck_top':top,'profile':expected})
assert len(physical)>110
profile=new.walk_surface_profile(p)
# Execute the exact candidate compiler's profile-owner function without its full-scene writer.
import ast
compile_ast=ast.parse(Path('/tmp/dearborn-profile-precision-v2-20261029/candidate/chicago/4d/tools/compile_scene.py').read_text())
reader=[n for n in compile_ast.body if isinstance(n,ast.FunctionDef) and n.name in ['walk_surface_m','walk_surface_profile']]
namespace={'ROOT':root,'sys':sys};sys.modules['archetypes.bridge_timber_params']=new
exec(compile(ast.Module(body=reader,type_ignores=[]),'<bound native compiler profile reader>','exec'),namespace)
assert namespace['walk_surface_profile'](r,r['phases'][0])==profile
assert namespace['walk_surface_m'](r,r['phases'][0])==2.22
precise=copy.deepcopy(r);precise['phases'][0]['form']['deck_height_m']={'value':2.22222,'confidence':'reconstructed','note':'Finite precision regression fixture only, not adopted source.'}
precise_params=new.from_phase(precise['phases'][0],precise)
precise_profile=namespace['walk_surface_profile'](precise,precise['phases'][0])
precise_base=namespace['walk_surface_m'](precise,precise['phases'][0])
assert precise_base==precise_params.deck_height_m==2.22222
assert precise_profile['stations_m'][0][1]==precise_base==precise_profile['stations_m'][-1][1]
scalar_only=copy.deepcopy(precise);scalar_only['phases'][0]['form']['draw_profile']['value']='flat';scalar_only['phases'][0]['form']['draw_rise_m']['value']=0
assert namespace['walk_surface_m'](scalar_only,scalar_only['phases'][0])==2.2222
assert namespace['walk_surface_profile'](scalar_only,scalar_only['phases'][0]) is None
side=json.loads((root/'data/sidecars/1835/dearborn_street_drawbridge.json').read_text());side['footprint']=copy.deepcopy(r['phases'][0]['footprint']);side['placement']['walk_surface_m']=precise_base;side['placement']['walk_surface_profile']=precise_profile
(out/'FIVE-DECIMAL-COMPILER-FIXTURE.json').write_text(json.dumps({'source':'Exact candidate compiler functions executed with actual native params; isolated functions not fullscene compile.','sidecar':side,'scalar_only_legacy_base':2.2222,'physical_native_base':precise_params.deck_height_m,'physical_native_apex':precise_params.deck_height_m+precise_params.draw_rise_m},indent=2)+'\n')
for _,_,rp in records:
 record=json.loads(rp.read_text())
 assert namespace['walk_surface_profile'](record,record['phases'][0]) is None
assert all(new.walk_surface_profile(new.from_phase(json.loads(rp.read_text())['phases'][0])) is None for _,_,rp in records)
selected_sidecar=json.loads((root/'data/sidecars/1835/dearborn_street_drawbridge.json').read_text())
selected_sidecar['footprint']=copy.deepcopy(r['phases'][0]['footprint'])
selected_sidecar['attributes']['width_m']=copy.deepcopy(r['phases'][0]['form']['width_m'])
selected_sidecar['placement']['position_note']=r['phases'][0]['position']['note']
(out/'NATIVE-PROFILE-FIXTURE.json').write_text(json.dumps({'profile':profile,'sidecar':selected_sidecar,'physical_samples':physical,'raw_deck_gaps_no_height':gaps},indent=2)+'\n')
# Existing native pier helpers distinguish the two opted-in platforms from ten approach bents.
static=[]
for xp in p.pier_x:
 body=mesh.MeshBuilder('platform');plain=mesh.MeshBuilder('general');nf._pier(body,p,xp,p.deck_height_m-p.plank_t_m-p.stringer_d_m,1.);nf._pier(plain,dataclasses.replace(p,draw_bearing_platform_m=None,draw_bearing_platform_offset_m=0.0),xp,p.deck_height_m-p.plank_t_m-p.stringer_d_m,1.)
 at_bearing=any(abs(xp-g)<1e-8 for g in p.gallows_x)
 if not at_bearing:assert body.verts==plain.verts and body.faces==plain.faces and body.conf==plain.conf and body.mat_index==plain.mat_index
 else:
  bounds=[[min(q[k] for q in body.verts),max(q[k] for q in body.verts)] for k in range(3)]
  assert bounds[1][0]<-2.4 and bounds[1][1]>p.width_m+.43
  assert abs(bounds[0][0]-(xp-1.8))<1e-10 and abs(bounds[0][1]-(xp+1.8))<1e-10
  assert abs(bounds[1][0]-(-2.4759))<1e-10 and abs(bounds[1][1]-5.3529)<1e-10
  assert max(q[2] for q in body.verts)==p.deck_height_m-p.plank_t_m-p.stringer_d_m
  assert nf.M_FILL not in body.mat_index and nf.M_DECK in body.mat_index
  assert set(body.conf)=={1.0}
 static.append({'x':xp,'selected_bearing':at_bearing,'vertices':len(body.verts),'all_other_approach_native_geometry_exact':not at_bearing})
# The height option changes only the two shore struts; posts/head/knees remain exact.
shore=mesh.MeshBuilder('shore');oldshore=mesh.MeshBuilder('shore');bearing=p.deck_height_m-p.plank_t_m-p.stringer_d_m
nf._gallows(shore,p,p.gallows_x[0],p.deck_height_m,bearing,1.)
nf._gallows(oldshore,dataclasses.replace(p,gallows_shore_attach_m=None),p.gallows_x[0],p.deck_height_m,bearing,1.)
assert shore.faces==oldshore.faces and shore.conf==oldshore.conf and shore.mat_index==oldshore.mat_index
assert shore.verts[:-48]==oldshore.verts[:-48] and shore.verts[-48:]!=oldshore.verts[-48:]
assert max(q[2] for q in shore.verts[-48:])-max(q[2] for q in oldshore.verts[-48:])>2.5
for name,change in [('bad_platform_offset_bool',{'draw_bearing_platform_offset_m':True}),('bad_platform_offset_nan',{'draw_bearing_platform_offset_m':float('nan')}),('bad_platform_offset_far',{'draw_bearing_platform_offset_m':1.51}),('offset_without_platform',{'draw_bearing_platform_m':None}),('platform_post_unsupported',{'draw_bearing_platform_m':[3.6,4.4]}),('boolean_attach',{'gallows_shore_attach_m':True}),('infinite_attach',{'gallows_shore_attach_m':float('inf')}),('above_head',{'gallows_shore_attach_m':6.05}),('too_low_attach',{'gallows_shore_attach_m':.49}),('unbraced_attach',{'gallows_braced':False}),('bad_platform_type',{'draw_bearing_platform_m':True}),('bad_platform_len',{'draw_bearing_platform_m':[3.,4.,5.]}),('bool_platform_dim',{'draw_bearing_platform_m':[True,4.4]}),('nonfinite_platform_dim',{'draw_bearing_platform_m':[3.6,float('nan')]}),('platform_along_short',{'draw_bearing_platform_m':[1.49,7.8288]}),('platform_along_long',{'draw_bearing_platform_m':[6.01,7.8288]}),('platform_width_small',{'draw_bearing_platform_m':[3.6,3.5]}),('platform_width_large',{'draw_bearing_platform_m':[3.6,8.]}),('platform_unaligned',{'draw_bearing_supports':False}),('platform_crosses_other_support',{'draw_bearing_platform_m':[6.,7.8288],'pier_count':30}),('platform_exceeds_approach',{'span_m':21.})]:
 try:dataclasses.replace(p,**change).validate()
 except new.ParamError:invalid.append(name)
 else:raise AssertionError(name)

# The platform remains open under a boarded cap, with finite distinct perimeter
# pile positions; every post footprint stays inside the top polygon.
captures=[]
saved_log=nf.log_prism
def counted_log(builder,a,b,r,c,m):
 captures.append((a,b,r,c,m));return saved_log(builder,a,b,r,c,m)
nf.log_prism=counted_log
isolated=mesh.MeshBuilder('isolated-platform')
nf._piled_platform(isolated,0,-2.4759,3.6,5.3529,p.deck_height_m-p.plank_t_m-p.stringer_d_m,1.)
nf.log_prism=saved_log
assert len(captures)==46 and len({(a[0],a[1]) for a,b,r,c,m in captures})==46
assert all(a[:2]==b[:2] and a[2]==-.55 and abs(r-.15)<1e-15 and c==1 and m==nf.M_LOG for a,b,r,c,m in captures)
assert nf.M_FILL not in isolated.mat_index
assert len(isolated.faces)==46*8+2*6+14*6


cross_sections=[]
for y in [.15,p.width_m/2,p.width_m-.15]:
 hits_count=0;gaps_count=0;residual=0.
 for x in [i*p.span_m/120+0.001 for i in range(120)]:
  zs=[z for tri in triangles if (z:=triangle_height((x,y),tri)) is not None]
  if not zs:gaps_count+=1;continue
  residual=max(residual,abs(max(zs)-(p.deck_height_m+new.draw_rise_m_at(p,x))));hits_count+=1
 assert hits_count==116 and gaps_count==4 and residual<1e-10
 cross_sections.append({'local_v':y,'actual_native_main_floor_hits':hits_count,'original_plank_gaps':gaps_count,'max_floor_residual_m':residual})
assert p.width_m==4.877 and r['phases'][0]['form']['width_m']['value']==4.8768
assert r['phases'][0]['footprint']['polygon'][2][1]==4.8768
(out/'WIDENED-NATIVE-FLOOR-CONTROLS.json').write_text(json.dumps({'status':'PASS_ACTUAL_PURE_NATIVE_VERTEX_FLOOR_INTERSECTIONS','selected_record_width_m':4.8768,'resolved_native_width_m':p.width_m,'resolution_delta_m':p.width_m-4.8768,'three_cross_sections':cross_sections,'unique_perimeter_piles_each_platform':len(captures),'native_producer_source_unchanged_from_v4':True,'limits':'Actual native Python builder raw streams only; no Blender/GLB/browser/currentproductioncompile.'},indent=2)+'\n')

assert hashes=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
assert all((base/rel).read_bytes()==(root/rel).read_bytes() for rel in ['generators/archetypes/bridge_timber_params.py','data/structures/dearborn_street_drawbridge.json'])
result={'status':'PASS_PURE_ONLY_UNADOPTED','elapsed_s':time.monotonic()-start,'six_default_raw_controls':rows,'legacy_positional_count':len([f for f in old_fields if not f.kw_only]),'legacy_defaults_factories_match_args_exact':True,'new_keywords_CONSUMED':[x for x in ['draw_bearing_supports','draw_profile','draw_rise_m','gallows_shore_attach_m','draw_bearing_platform_m','draw_bearing_platform_offset_m'] if x in new.CONSUMED],'candidate':{'vertices':len(gb['verts']),'polygons':len(gb['faces']),'fan_triangles':sum(len(f)-2 for f in gb['faces']),'support_count':len(p.pier_x),'whole_mesh_plan_bounds':plan_bounds,'profile':profile,'physical_floor_samples_compared':len(physical),'gaps_preserved_as_nohit':len(gaps),'max_floor_residual_m':max(abs(x['mesh_deck_top']-x['profile']) for x in physical)},'isolated_native_compiler_profile_function_matches_and_all6_defaults_omit':True,'legal_5decimal_profiled_scalar_exact_2_22222_legacy_scalar_only_2_2222':True,'new_static_geometry':{'bearing_and_approach_rows':static,'ten_unselected_approach_bent_streams_exact':True,'only_two_shore_struts_changed_posts_head_knees_exact':True},'invalid_controls_refused':invalid,'canonical_input_hashes_before_after_exact':hashes,'limits':'Pure native parameter/mesh lists only. No canonical claim/adoption/Blender/nativeexport/WEB/browser/wholeyardclearance/fullgate/imageacceptance.'}
(out/'PURE-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='canonical_input_hashes_before_after_exact'},indent=2))
