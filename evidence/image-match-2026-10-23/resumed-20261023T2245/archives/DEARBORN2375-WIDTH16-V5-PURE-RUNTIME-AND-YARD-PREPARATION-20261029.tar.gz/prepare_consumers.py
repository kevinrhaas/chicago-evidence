from pathlib import Path
import shutil
O=Path(__file__).resolve().parent;V1=Path('/tmp/dearborn-profile-implemented-20261029');V2=Path('/tmp/dearborn-profile-precision-v2-20261029');V4=Path('/tmp/dearborn-piled-platform-v4-20261029')
for part in ['before','candidate']:
 for f in (V1/part).rglob('*'):
  if not f.is_file():continue
  d=O/part/f.relative_to(V1/part)
  if d.exists():continue
  d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,d)
for rel in ['tools/compile_scene.py']:
 shutil.copyfile(V2/'candidate/chicago/4d'/rel,O/'candidate/chicago/4d'/rel)
shutil.copyfile(V4/'candidate/chicago/4d/data/reconstruction/name_pool_keys.json',O/'candidate/chicago/4d/data/reconstruction/name_pool_keys.json')
s=(V1/'verify_consumers.mjs').read_text().replace('1.524','2.4384')
s=s.replace("assert(!r.clearSegment(lo+.1,5,hi-.1,5)","assert(!r.clearSegment(lo+.1,5.5,hi-.1,5.5)")
needle='const result={status:'
extra='''// Selected width must reach the new strip; keepout surface uses the declared
// full polygon rather than a stale 10ft fallback. Controls prove both sides.
const oldWidthSide=structuredClone(profileside);oldWidthSide.footprint.polygon=[[0,0],[span,0],[span,3.048],[0,3.048]];
const oldWidthDeck=deckFromSidecar('old-width-control',oldWidthSide);
assert.equal(helper.insideDeck(centre,4.4,oldWidthDeck.pts),false);
const oldWidthWalker=newer.createWalker({camera:new THREE.PerspectiveCamera(),terrain,decks:[oldWidthDeck]});
assert.equal(oldWidthWalker.surfaceAt(centre,4.4),4);
assert.equal(w.surfaceAt(centre,4.4),3.42);
assert.equal(deckHeightAt(deck,centre,4.4),3.42);
assert.equal(helper.insideDeck(centre,4.8771,deck.pts),false);
assert.equal(helper.insideDeck(centre,-.01,deck.pts),false);
assert(r.clearSegment(lo+.1,4.4,hi-.1,4.4),'newly widened strip is continuous in exact router');
assert(!r.clearSegment(lo+.1,5.5,hi-.1,5.5),'outside widened footprint stays water');
const wideTraverse=newer.createWalker({camera:new THREE.PerspectiveCamera(),terrain,decks:[deck],spawn:{local_e:-.1,local_n:4.4,yaw_deg:90}});
const wideIntent=createIntent();let wideSteps=0,wideResidual=0;
for(let i=0;i<2200;i++){
 wideIntent.forward=1;wideTraverse.update(1/60,wideIntent);
 const {e,n,groundY}=wideTraverse.state;
 if(e>0&&e<span){wideResidual=Math.max(wideResidual,Math.abs(groundY-expected(e)));wideSteps++;assert.equal(wideTraverse.state.blocked,false);}
 if(e>span+.1)break;
}
assert(wideTraverse.state.e>span+.1&&wideSteps>1000&&wideResidual<1e-10,'new width native walker reaches both banks');
const widePlan=r.plan({e:.5,n:4.4},{e:span-.5,n:4.4});assert(widePlan,'new width fallback grid routes bank to bank');
'''
assert needle in s;s=s.replace(needle,extra+'\n'+needle)
s=s.replace("const dependencies=new Map();", "result.selected_width_m=4.8768;result.widened_strip_native_walker_steps=wideSteps;result.widened_strip_max_floor_residual_m=wideResidual;result.widened_strip_grid_exact_router_pass=true;result.old10foot_control_rejects_new_strip=true;\nconst dependencies=new Map();")
(O/'verify_consumers.mjs').write_text(s)
print('prepared v5 boundNode actual widened runtime controls')
