from pathlib import Path
import shutil
O=Path(__file__).resolve().parent;V=Path('/tmp/dearborn-piled-platform-v4-20261029')
for name in ['bridge_timber.py','bridge_timber_params.py']:
 d=O/'candidate/chicago/4d/generators/archetypes'/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(V/'candidate/chicago/4d/generators/archetypes'/name,d)
s=(V/'verify_pure.py').read_text()
s=s.replace("abs(bounds[1][0]-(-2.476))", "abs(bounds[1][0]-(-2.4759))")
s=s.replace("abs(bounds[1][1]-3.524)", "abs(bounds[1][1]-5.3529)")
s=s.replace("p.width_m+.43", "p.width_m+.43")
s=s.replace("('platform_along_short',{'draw_bearing_platform_m':[1.49,4.4]})", "('platform_along_short',{'draw_bearing_platform_m':[1.49,7.8288]})")
s=s.replace("('platform_along_long',{'draw_bearing_platform_m':[6.01,4.4]})", "('platform_along_long',{'draw_bearing_platform_m':[6.01,7.8288]})")
s=s.replace("('platform_width_large',{'draw_bearing_platform_m':[3.6,7.]})", "('platform_width_large',{'draw_bearing_platform_m':[3.6,8.]})")
s=s.replace("('platform_crosses_other_support',{'draw_bearing_platform_m':[6.,6.],'pier_count':30})", "('platform_crosses_other_support',{'draw_bearing_platform_m':[6.,7.8288],'pier_count':30})")
s=s.replace("nf._piled_platform(isolated,0,-2.476,3.6,3.524,", "nf._piled_platform(isolated,0,-2.4759,3.6,5.3529,")
s=s.replace("len(captures)==38", "len(captures)==46").replace("in captures})==38", "in captures})==46").replace("38*8+2*6+14*6", "46*8+2*6+14*6")
# The native source producer/legacy six records stay untouched. The selected
# fixture adopts only declared record width/metadata, no full compiler claim.
needle="side=json.loads((root/'data/sidecars/1835/dearborn_street_drawbridge.json').read_text());side['placement']['walk_surface_m']=precise_base;"
s=s.replace(needle,"side=json.loads((root/'data/sidecars/1835/dearborn_street_drawbridge.json').read_text());side['footprint']=copy.deepcopy(r['phases'][0]['footprint']);side['placement']['walk_surface_m']=precise_base;")
old="(out/'NATIVE-PROFILE-FIXTURE.json').write_text(json.dumps({'profile':profile,'sidecar':json.loads((root/'data/sidecars/1835/dearborn_street_drawbridge.json').read_text()),'physical_samples':physical,'raw_deck_gaps_no_height':gaps},indent=2)+'\\n')"
new="""selected_sidecar=json.loads((root/'data/sidecars/1835/dearborn_street_drawbridge.json').read_text())
selected_sidecar['footprint']=copy.deepcopy(r['phases'][0]['footprint'])
selected_sidecar['attributes']['width_m']=copy.deepcopy(r['phases'][0]['form']['width_m'])
selected_sidecar['placement']['position_note']=r['phases'][0]['position']['note']
(out/'NATIVE-PROFILE-FIXTURE.json').write_text(json.dumps({'profile':profile,'sidecar':selected_sidecar,'physical_samples':physical,'raw_deck_gaps_no_height':gaps},indent=2)+'\\n')"""
assert old in s;s=s.replace(old,new)
needle="assert hashes=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}"
extra="""
cross_sections=[]
for y in [.15,p.width_m/2,p.width_m-.15]:
 hits_count=0;gaps_count=0;residual=0.
 for x in [i*p.span_m/120+0.001 for i in range(120)]:
  zs=[z for tri in triangles if (z:=triangle_height((x,y),tri)) is not None]
  if not zs:gaps_count+=1;continue
  residual=max(residual,abs(max(zs)-(p.deck_height_m+new.draw_rise_m_at(p,x))));hits_count+=1
 assert hits_count==116 and gaps_count==4 and residual<1e-10
 cross_sections.append({'local_v':y,'actual_native_main_floor_hits':hits_count,'original_plank_gaps':gaps_count,'max_floor_residual_m':residual})
assert p.width_m==4.877 and r['phases'][0]['form']['width_m']['value']==4.8768
assert r['phases'][0]['footprint']['polygon'][2][1]==4.8768
(out/'WIDENED-NATIVE-FLOOR-CONTROLS.json').write_text(json.dumps({'status':'PASS_ACTUAL_PURE_NATIVE_VERTEX_FLOOR_INTERSECTIONS','selected_record_width_m':4.8768,'resolved_native_width_m':p.width_m,'resolution_delta_m':p.width_m-4.8768,'three_cross_sections':cross_sections,'unique_perimeter_piles_each_platform':len(captures),'native_producer_source_unchanged_from_v4':True,'limits':'Actual native Python builder raw streams only; no Blender/GLB/browser/currentproductioncompile.'},indent=2)+'\\n')
"""
s=s.replace(needle,extra+'\n'+needle)
(O/'verify_pure.py').write_text(s)
print('prepared v5 pure mesh and width fixture')
