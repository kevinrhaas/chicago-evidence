# Dearborn sixteen-foot width — v5

UNADOPTED external selected-record correction over the closed v4 proposal.
No canonical source, native ticket claim, GLB/WEB, camera, image verdict, app,
full gate or PR is changed here. Actual native v4 stays immutable and dated.

The original record chose the neighbouring branch bridges' ten-foot default
and said nobody ever stated a width for Dearborn. The actually read1895
Moses/Kirkland volume1 printedp95 explicitly says it was300feetlong, sixteen
inwidth, andhadadoubledraw. Sourcepage bytes/hash and metadata are included.
The historical absolute claim is retained, then superseded by a dated inline
appendix. Adopt16ft=4.8768m at INFERRED secondary-text confidence, with the
already-existing volume source ID. This is not a contemporary specification,
survey, attested number or camera fit. It is stronger evidence than importing
the branches' documented width. The1895text's300foot overall extent does not
replace the separately traced76.33m watergap, origin, bearing or bank controls;
its doubledraw wording does not settle machinery. Sourceaccessnotes retain the
old OCR-only reading as history and append this focused page-image reread.

The selected form and declared footprint positive-v extent both become4.8768m.
The old native resolver rounds all widths to3decimals, yielding4.877m physical
width, only0.2mm greater; no shared resolver or legacy output is changed.
Mappedorigin, rotation, tracedspan and raised-floor x-profile remain exact.
The selected reconstructed cap width grows6→7.8288m to keep the v4foreground
projection and support both posts on the widerdeck; -1moffset,3.6malong size,
sections and every numeric foundation choice stay reconstructed. Its46derived
perimeter piles replace38solely because the cap is wider; neither is attested.

Actual pure native raw-stream controls pass all6current legacy outputs with
unchanged fields/defaults/positions/material/confidence/named streams. Selected
native mesh has28048vertices/6818polygons/14412fantriangles. All348physical main
deck hits over3transverse tracks match the scalar/profile floor to floating
precision; original4plank gaps remain on each track. Ten ordinary approach
bents and highraker controls retain their established scope.35badcontrolsrefuse.

Actual bound Node execution passes61modulehash bindings:1024walker steps
through each of the widened centre and newlyoccupied v=4.4mstrip, actual native
grid/exact router, humanfloor callback and all previous regression controls.
The old10foot polygon rejects that strip while the selected polygon permits
it. Water beyond the newedge stays blocked. The height helper intentionally
does not perform polygon checks; its native callers own that check. The first
added control incorrectly expected helper-null outsidev, refused, and was
corrected to test the actual native walker/polygon contract. Rawfailurekept.

The exact compiler footprint AST slice and actual walkprofile functions were
executed without fullscene writes. They emit the selected record's entire
footprint metadata and profile. Six existing native keepout/worldpolygon helper
functions place the widened polygon identically. The native navigation outline
reader separately draws the newwidth at the correct world corners. This is
bound function proof, not a claimed fullscene compilation or map screenshot.

Every prior actual1421native yard item bound in BOTH native atlas RNG states
was recompared to the whole NEW mesh plus1m rectangle.17code/terrainbindings
and8records remain exact. WIDER-WHOLE-YARD-CLEARANCE records the newminimum
gap; it is actual prior emittedgeometry arithmetic, not a new yard render.
Parked/horse wholeasset bounds and current published ground/approach remain
separate required checks.

Candidate source includes byte-exact reused v1runtime/contract, v2precision
compiler and v4producer/name-reader postimages to make this final proposal
reviewable. SOURCE-2PATH-INCREMENT.patch describes only this v5record and source
note change. Intermediate inherited source is not called newly executed.

Next: root grants a finite actual native/Web/Andreasphoto window. Export6new
default controls byte-exact against old actual/current, then selected wider
MASTER, genuineWEB and one new samecamera image. Use only clearedAndreas for
new geometry/comparison. Bakercheck_required stays. Earlewrong1849exclusion
must be corrected; allheldview/source dispositions, canonicalclaim/adoption,
current published/BOTH app proof, fullgate/PR/devmerge/originalclosure remain.
