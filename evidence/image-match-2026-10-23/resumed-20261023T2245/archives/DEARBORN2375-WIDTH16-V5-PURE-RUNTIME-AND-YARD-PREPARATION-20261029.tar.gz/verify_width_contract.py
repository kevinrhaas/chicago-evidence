from pathlib import Path
import ast,json,sys,math,hashlib,importlib.util,datetime,copy
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');C=O/'candidate/chicago/4d';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=json.loads((C/'data/structures/dearborn_street_drawbridge.json').read_text());phase=record['phases'][0];fixture=json.loads((O/'NATIVE-PROFILE-FIXTURE.json').read_text());side=fixture['sidecar']
sys.path.insert(0,str(A/'generators'));import archetypes
name='archetypes.bridge_timber_params';spec=importlib.util.spec_from_file_location(name,C/'generators/archetypes/bridge_timber_params.py');mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
compiler=C/'tools/compile_scene.py';tree=ast.parse(compiler.read_text());scope={'ROOT':A,'sys':sys}
funcs=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in ['walk_surface_m','walk_surface_profile','walk_passages']]
exec(compile(ast.Module(body=funcs,type_ignores=[]),str(compiler),'exec'),scope)
assert scope['walk_passages'](record,phase)is None
footprints=[x for x in ast.walk(tree)if isinstance(x,ast.Dict)and {'polygon','confidence','sources','note'}<=set(k.value for k in x.keys if isinstance(k,ast.Constant))]
assert len(footprints)==1
emitted=eval(compile(ast.Expression(footprints[0]),str(compiler),'eval'),dict(scope,phase=phase,st=record))
assert emitted==side['footprint']==phase['footprint']
assert scope['walk_surface_m'](record,phase)==2.22 and scope['walk_surface_profile'](record,phase)==fixture['profile']
bindings={str(compiler):sha(compiler)};rows=[]
helpers=[('generate_dooryard_plantings.py',['footprint_world']),('generate_dooryard_pickets.py',['footprint_world']),('generate_yard_goods.py',['_footprint_world','_to_enu']),('generate_lot_building_material.py',['_footprint_world','_to_enu']),('generate_fort_trees.py',['footprint_world']),('check_structure_clearance.py',['placed','to_world'])]
def area(pts):return abs(sum(a[0]*b[1]-b[0]*a[1]for a,b in zip(pts,pts[1:]+pts[:1])))/2
p=side['placement'];t=math.radians(p['rotation_deg']);expected=[(p['local_e']+u*math.cos(t)+v*math.sin(t),p['local_n']-u*math.sin(t)+v*math.cos(t))for u,v in phase['footprint']['polygon']]
for filename,names in helpers:
 path=A/'tools'/filename;bindings[str(path)]=sha(path);t=ast.parse(path.read_text());selected=[x for x in t.body if isinstance(x,ast.FunctionDef)and x.name in names];assert len(selected)==len(names)
 ns={'math':math};exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'),ns)
 fn=ns['placed'if filename=='check_structure_clearance.py'else names[0]];actual=fn(side)
 assert len(actual)==4 and max(math.dist(a,b)for a,b in zip(actual,expected))<1e-10
 assert abs(math.dist(actual[1],actual[2])-4.8768)<1e-11
 rows.append({'path':str(path),'function':fn.__name__,'all_widened_world_corners_exact':True,'width_m':math.dist(actual[1],actual[2]),'area_m2':area(actual)})
oldside=copy.deepcopy(side);oldside['footprint']['polygon']=[[0,0],[76.33,0],[76.33,3.048],[0,3.048]]
oldarea=76.33*3.048;newarea=area(expected);assert abs((newarea-oldarea)-76.33*1.8288)<1e-8
assert all(sha(Path(path))==h for path,h in bindings.items())
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_BOUND_NATIVE_COMPILER_FOOTPRINT_AND_EXISTING_KEEPOUT_READERS','compiler_exact_footprint_AST_executed_and_all_fields_equal_selected_record':True,'compiler_native_profile_scalar_exact':True,'no_fullscene_compile_claim':True,'declared_width_m':4.8768,'native_width_rounding_m':4.877,'source_mapped_origin_and_rotation_unchanged':True,'helpers':rows,'additional_occupied_deck_area_m2':newarea-oldarea,'bound_source_sha256':bindings,'limits':'Exact native functions/AST slice only, no fullscene writes/export/browser/currentpublishedgroundproof. Water-anchored bridge stays excluded from walled-building collision rules; yard safety separately tests complete candidate mesh rectangle.'}
(O/'WIDTH-COMPILER-KEEPOUT-PROOF.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
