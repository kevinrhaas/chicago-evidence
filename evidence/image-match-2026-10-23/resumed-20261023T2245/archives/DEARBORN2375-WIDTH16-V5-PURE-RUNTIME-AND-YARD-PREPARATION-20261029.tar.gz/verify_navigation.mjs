import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const O=fileURLToPath(new URL('.',import.meta.url));
const source='/workspace/chicago/chicago/4d/renderers/web/js/navigation.js';
const bytes=fs.readFileSync(source),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const text=bytes.toString('utf8'),actual=text.match(/function structureOutlines\(registry\) \{[\s\S]*?\n\}/)[0];
assert(text.includes('const DEG = Math.PI / 180;'));
const fn=new Function(`const DEG=Math.PI/180;return (${actual});`)();
const side=JSON.parse(fs.readFileSync(O+'NATIVE-PROFILE-FIXTURE.json')).sidecar;
const ring=fn(new Map([[side.id,{id:side.id,sidecar:side}]]))[0];
assert.equal(ring.length,4);assert.equal(ring.id,side.id);
assert(Math.abs(Math.hypot(ring[2][0]-ring[1][0],ring[2][1]-ring[1][1])-4.8768)<1e-11);
const p=side.placement,t=p.rotation_deg*Math.PI/180;
for(let i=0;i<4;i++){
 const [u,v]=side.footprint.polygon[i];
 assert(Math.hypot(ring[i][0]-(p.local_e+u*Math.cos(t)+v*Math.sin(t)),ring[i][1]-(p.local_n-u*Math.sin(t)+v*Math.cos(t)))<1e-10);
}
const old=structuredClone(side);old.footprint.polygon=[[0,0],[76.33,0],[76.33,3.048],[0,3.048]];
const prior=fn(new Map([[old.id,{id:old.id,sidecar:old}]]))[0];
assert(Math.abs(Math.hypot(ring[2][0]-prior[2][0],ring[2][1]-prior[2][1])-1.8288)<1e-11);
assert.equal(sha(fs.readFileSync(source)),sha(bytes));
const result={status:'PASS_EXACT_NATIVE_NAVIGATION_OUTLINE_READER',source,sha256:sha(bytes),selected_width_m:4.8768,positive_v_edge_delta_m:1.8288,all_world_corner_transforms_equal_compiler_footprint:true,limits:'Exact native pure function extracted; no DOM/map raster/browser screenshot or current fullscene compile claimed.'};
fs.writeFileSync(O+'NAVIGATION-WIDTH-PROOF.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
