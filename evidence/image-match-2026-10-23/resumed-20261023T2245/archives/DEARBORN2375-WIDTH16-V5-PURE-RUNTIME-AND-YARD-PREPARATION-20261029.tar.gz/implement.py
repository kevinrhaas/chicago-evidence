from pathlib import Path
import json,hashlib,datetime,difflib,copy
O=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');V4=Path('/tmp/dearborn-piled-platform-v4-20261029/candidate/chicago/4d')
r='data/structures/dearborn_street_drawbridge.json';old=(V4/r).read_text();record=json.loads(old);prior=copy.deepcopy(record);phase=record['phases'][0];form=phase['form']
form['width_m']['value']=4.8768;form['width_m']['confidence']='inferred';form['width_m']['sources']=['moses_kirkland_history_of_chicago_v1']
form['width_m']['note']+=' CURRENT SOURCE-VERIFIED CORRECTION, T-2375, 2026-10-29: the preceding absolute NOBODY EVER WROTE statement is superseded. Moses and Kirkland, History of Chicago, Illinois, volume1 (Munsell,1895), printedp95, actually read from https://archive.org/download/historyofchicago01mose/page/95_large.jpg, says of the1834Dearborn crossing: “It was300feet inlength, bysixteen inwidth, andhadadoubledraw.” Adopt sixteenfeet =4.8768m as an inferred width from retrospective secondary text, stronger than borrowing the branchbridges’ tenfoot default. This is not a contemporary trustee specification, surveyed width or a photographed measurement. The same sentence’s300foot total length includes a different extent from the independently traced76.33m watergap; it does not move that traced length or the source origin. The unresolved liftingmechanism is not established by the words doubledraw. Existing native parameter resolution rounds the selected width to4.877m, a0.2mm serialization precision difference. No dimension is fitted from the provisional drawing camera. The prior chosen tenfoot geometry and old reasoning are retained above as history, not current evidence.'
phase['footprint']['polygon']=[[0.0,0.0],[76.33,0.0],[76.33,4.8768],[0.0,4.8768]]
phase['footprint']['confidence']='inferred';phase['footprint']['sources']=['wright_1834','moses_kirkland_history_of_chicago_v1']
phase['footprint']['note']+=' CURRENT WIDTH CORRECTION, T-2375, 2026-10-29: the former tenfoot/whollyinventedwidth paragraph is historical. Width now follows the explicitly stated sixteenfeet in Moses/Kirkland1895vol1p95, directly read in the source scan, at inferred secondary confidence. The other axis remains the76.33m independently traced bank-to-bank watergap on Wright1834. Neither source attests this complete rectangle as a survey: length is traced and width is retrospective text. Localorigin[0,0], mappedposition, rotation, tracedriverbanks and span are unchanged. Extending only localpositive-v avoids silently moving any geographiccontrol while implementing the stronger width evidence; no shift of the street, bank, heightfield or modelorigin is inferred from a picture.'
form['draw_bearing_platform_m']['value']=[3.6,7.8288]
form['draw_bearing_platform_m']['note']+=' CURRENT SIXTEENFOOT WIDTH ACCOMMODATION: retain the reconstructed along-bearing3.6m plan and -1.0m transverse offset. Across size grows6.0m by the selected1.8288m deck-width increase to7.8288m, preserving the previously chosen source-camera-side projection and ensuring both gallows post footprints remain supported. The platform dimensions and38-to46 derivedpilecount are reconstructed construction choices, not independently attested by the1895width text or a foundation survey. Native3decimalwidth resolution differs0.2mm; actual vertex bounds and containment must be checked.'
phase['position']['note']+=' CURRENT WIDTH CORRECTION, T-2375: the16foot widening changes only the footprint positive-v extent, not this mappedorigin, bearing, traced76.33mwatergap or riverbank controls. The placement and uncertainty remain independently stated; no new source-coordinate derivation is claimed.'

def replace(a,b):
 global old
 assert old.count(a)==1,(a[:100],old.count(a));old=old.replace(a,b)
def block(obj,indent):
 return '\n'.join((' '*indent+s if i else s)for i,s in enumerate(json.dumps(obj,indent=2,ensure_ascii=False).splitlines()))
# Existing record uses literal escaped sequences within notes, so replace the
# JSON token actually present, preserving all other pre-existing byte choices.
def strtoken(text):
 a=json.dumps(text,ensure_ascii=False)
 if a not in old:a=json.dumps(text,ensure_ascii=True)
 assert a in old,(text[:60],a[:60]);return a
def replace_object(key,before,after,indent):
 global old
 marker=json.dumps(key)+': ';assert old.count(marker)==1,(key,old.count(marker))
 start=old.index(marker)+len(marker);decoded,length=json.JSONDecoder().raw_decode(old[start:]);assert decoded==before
 old=old[:start]+block(after,indent)+old[start+length:]
for key in ['width_m','draw_bearing_platform_m']:
 replace_object(key,prior['phases'][0]['form'][key],form[key],8)
for key in ['footprint','position']:
 replace_object(key,prior['phases'][0][key],phase[key],6)
assert json.loads(old)==record
s='data/sources/moses_kirkland_history_of_chicago_v1.json';source_before=(A/s).read_text();source=json.loads(source_before);source['access_notes']+=' CURRENT PAGE-IMAGE VERIFICATION, T-2375, 2026-10-29: the earlier NO PAGE IMAGE WAS READ sentence describes the2026-09-05OCRreading, not this later reread. Printedp95 was actually read at https://archive.org/download/historyofchicago01mose/page/95_large.jpg (served2032x2888JPEG,770184bytes,SHA2564b9b2f70e44dbc09933b217f61c7ad250525f1d17eb4c33bbccf79942d163fc2). It explicitly states the1834Dearborn bridge was300feetlong,bysixteeninwidth,andhadadoubledraw. This verifies that secondary printed assertion, not a contemporary survey or the precise1835form. No claim is added to the earlier twenty-passage reading denominator: this is a focused rereading of an alreadyheld volume for an existing original picture ticket. An adjacent unnumbered EARLYSCENEScomposite at /page/n128_large.jpg reproduces theBraunholdDearborncomposition; it is not evidence of the separateBaker-Coengraving publication.'
source_after=source_before.replace(json.dumps(json.loads(source_before)['access_notes'],ensure_ascii=False),json.dumps(source['access_notes'],ensure_ascii=False));assert json.loads(source_after)==source
files={r:((V4/r).read_bytes(),old.encode()),s:((A/s).read_bytes(),source_after.encode())}
for rel,(a,b)in files.items():
 for part,data in [('before',a),('candidate',b)]:
  dest=O/part/'chicago/4d'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
(O/'SOURCE-2PATH-INCREMENT.patch').write_text(''.join(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel))for rel,(a,b)in files.items()))
(O/'SOURCE-BINDINGS.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'UNADOPTED selected16footwidth v5record+focusedsource-rereadappendix. Existing nativeproducer/runtime bytes unchanged from v4; no actualnative/browser.','preimages':{rel:hashlib.sha256(a).hexdigest()for rel,(a,b)in files.items()},'postimages':{rel:hashlib.sha256(b).hexdigest()for rel,(a,b)in files.items()}},indent=2)+'\n')
print('V5 selected width source prepared; no native/browser')
