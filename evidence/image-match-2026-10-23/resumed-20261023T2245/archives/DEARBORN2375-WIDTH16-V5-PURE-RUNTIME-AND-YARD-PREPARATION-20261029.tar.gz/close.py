from pathlib import Path
import json,hashlib,math,datetime,stat,shutil,ast
O=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((O/'PURE-PROOF.json').read_text());consumer=json.loads((O/'CONSUMER-PROOF.json').read_text());width=json.loads((O/'WIDTH-COMPILER-KEEPOUT-PROOF.json').read_text());nav=json.loads((O/'NAVIGATION-WIDTH-PROOF.json').read_text())
assert proof['status']=='PASS_PURE_ONLY_UNADOPTED' and consumer['status']=='PASS_BOUND_NODE_CONSUMERS_ONLY'
assert width['status']=='PASS_BOUND_NATIVE_COMPILER_FOOTPRINT_AND_EXISTING_KEEPOUT_READERS' and nav['status']=='PASS_EXACT_NATIVE_NAVIGATION_OUTLINE_READER'
for p in (O/'candidate').rglob('*.py'):ast.parse(p.read_text())
Y=Path('/workspace/T2375-native-profile-trial-20261029');inputs=json.loads((Y/'YARD-INPUTS.json').read_text());actual=json.loads((Y/'ACTUAL-WHOLE-YARD-CLEARANCE.json').read_text())
for p,h in inputs['current_bindings'].items():assert sha(Path(p))==h,p
for row in inputs['records']:assert sha(Path(row['canonical']))==row['sha256']
bounds=proof['candidate']['whole_mesh_plan_bounds'];guard=[[a-1,b+1]for a,b in bounds];rows=[]
for case in actual['cases']:
 for state,row in case['states'].items():
  b=row['bridge_local_bounds'];gap=math.hypot(*(max(guard[k][0]-b[k][1],b[k][0]-guard[k][1],0)for k in range(2)));assert gap>0
  rows.append({'record':case['record'],'pointer':case['pointer'],'state':state,'gap_lower_bound_m':gap})
assert len(rows)==2842
yard={'status':'PASS_NEW_WIDER_FULL_MESH_PLUS1M_AGAINST_PRIOR_ACTUAL_NATIVE_YARD_BOUNDS_EXACT_INPUTS','prior_manifest':str(Y/'MANIFEST.json'),'prior_manifest_sha256':sha(Y/'MANIFEST.json'),'all17_native_yard_code_terrain_bindings_and8_source_records_exact':True,'full_new_pure_mesh_bounds':bounds,'whole_mesh_plus1m_guard':guard,'actual_old_native_item_bounds_recompared':len(rows),'two_native_atlas_rng_states':True,'minimum_whole_emitted_geometry_gap_lower_bound_m':min(r['gap_lower_bound_m']for r in rows),'cases':rows,'limits':'Arithmeticonactualpriorwholeemittedfloatbounds, notnewnativeyard/browser/quantizedcapture. Allnativecode/recordterraininputs exact. Parkedmodels/horsecompleteassetseparate.'}
(O/'WIDER-WHOLE-YARD-CLEARANCE.json').write_text(json.dumps(yard,indent=2)+'\n')
evidence=Path('/tmp/T2375-held-picture-audit-20261029');target=O/'source-page-evidence';target.mkdir(exist_ok=True)
for name in ['moses-v1-page-95-served.jpg','moses-v1-IA-metadata.json']:shutil.copyfile(evidence/name,target/name)
assert sha(target/'moses-v1-page-95-served.jpg')=='4b9b2f70e44dbc09933b217f61c7ad250525f1d17eb4c33bbccf79942d163fc2'
record=json.loads((O/'candidate/chicago/4d/data/structures/dearborn_street_drawbridge.json').read_text());phase=record['phases'][0];form=phase['form']
original=json.loads((O/'before/chicago/4d/data/structures/dearborn_street_drawbridge.json').read_text());assert phase['position']['utm_e']==original['phases'][0]['position']['utm_e'] and phase['position']['utm_n']==original['phases'][0]['position']['utm_n'] and phase['position']['rotation_deg']==original['phases'][0]['position']['rotation_deg']
assert form['width_m']['value']==4.8768 and form['width_m']['confidence']=='inferred' and form['width_m']['sources']==['moses_kirkland_history_of_chicago_v1']
(O/'HANDOFF.md').write_text('''# Dearborn sixteen-foot width — v5

UNADOPTED external selected-record correction over the closed v4 proposal.
No canonical source, native ticket claim, GLB/WEB, camera, image verdict, app,
full gate or PR is changed here. Actual native v4 stays immutable and dated.

The original record chose the neighbouring branch bridges' ten-foot default
and said nobody ever stated a width for Dearborn. The actually read1895
Moses/Kirkland volume1 printedp95 explicitly says it was300feetlong, sixteen
inwidth, andhadadoubledraw. Sourcepage bytes/hash and metadata are included.
The historical absolute claim is retained, then superseded by a dated inline
appendix. Adopt16ft=4.8768m at INFERRED secondary-text confidence, with the
already-existing volume source ID. This is not a contemporary specification,
survey, attested number or camera fit. It is stronger evidence than importing
the branches' documented width. The1895text's300foot overall extent does not
replace the separately traced76.33m watergap, origin, bearing or bank controls;
its doubledraw wording does not settle machinery. Sourceaccessnotes retain the
old OCR-only reading as history and append this focused page-image reread.

The selected form and declared footprint positive-v extent both become4.8768m.
The old native resolver rounds all widths to3decimals, yielding4.877m physical
width, only0.2mm greater; no shared resolver or legacy output is changed.
Mappedorigin, rotation, tracedspan and raised-floor x-profile remain exact.
The selected reconstructed cap width grows6→7.8288m to keep the v4foreground
projection and support both posts on the widerdeck; -1moffset,3.6malong size,
sections and every numeric foundation choice stay reconstructed. Its46derived
perimeter piles replace38solely because the cap is wider; neither is attested.

Actual pure native raw-stream controls pass all6current legacy outputs with
unchanged fields/defaults/positions/material/confidence/named streams. Selected
native mesh has28048vertices/6818polygons/14412fantriangles. All348physical main
deck hits over3transverse tracks match the scalar/profile floor to floating
precision; original4plank gaps remain on each track. Ten ordinary approach
bents and highraker controls retain their established scope.35badcontrolsrefuse.

Actual bound Node execution passes61modulehash bindings:1024walker steps
through each of the widened centre and newlyoccupied v=4.4mstrip, actual native
grid/exact router, humanfloor callback and all previous regression controls.
The old10foot polygon rejects that strip while the selected polygon permits
it. Water beyond the newedge stays blocked. The height helper intentionally
does not perform polygon checks; its native callers own that check. The first
added control incorrectly expected helper-null outsidev, refused, and was
corrected to test the actual native walker/polygon contract. Rawfailurekept.

The exact compiler footprint AST slice and actual walkprofile functions were
executed without fullscene writes. They emit the selected record's entire
footprint metadata and profile. Six existing native keepout/worldpolygon helper
functions place the widened polygon identically. The native navigation outline
reader separately draws the newwidth at the correct world corners. This is
bound function proof, not a claimed fullscene compilation or map screenshot.

Every prior actual1421native yard item bound in BOTH native atlas RNG states
was recompared to the whole NEW mesh plus1m rectangle.17code/terrainbindings
and8records remain exact. WIDER-WHOLE-YARD-CLEARANCE records the newminimum
gap; it is actual prior emittedgeometry arithmetic, not a new yard render.
Parked/horse wholeasset bounds and current published ground/approach remain
separate required checks.

Candidate source includes byte-exact reused v1runtime/contract, v2precision
compiler and v4producer/name-reader postimages to make this final proposal
reviewable. SOURCE-2PATH-INCREMENT.patch describes only this v5record and source
note change. Intermediate inherited source is not called newly executed.

Next: root grants a finite actual native/Web/Andreasphoto window. Export6new
default controls byte-exact against old actual/current, then selected wider
MASTER, genuineWEB and one new samecamera image. Use only clearedAndreas for
new geometry/comparison. Bakercheck_required stays. Earlewrong1849exclusion
must be corrected; allheldview/source dispositions, canonicalclaim/adoption,
current published/BOTH app proof, fullgate/PR/devmerge/originalclosure remain.
''')
(O/'LIBERTY-APPEND.md').write_text('''
### L-dearborn-sixteen-foot-width-2375 — Secondary width and foundation extent

**Covers:** selectedDearborn width/footprint and reconstructed bearing caps.
**Evidence:** actual Moses/Kirkland1895vol1p95 says sixteenfeetwide. Adopt
4.8768m inferred from retrospective secondary text; no contemporary survey,
attested dimension, tracedcoordinate or drawing-derived metric claim.
**Decision:** supersede old tenfoot branchproxy and absolute no-written-width
claim, while retaining old text as history.76.33m tracedwatergap, origin and
bearing stay. Existing native3decimal resolver yields4.877m (0.2mmprecision).
**Invented:** widened caps3.6×7.8288m at−1mtransverseoffset,46perimeterpiles,
sections and seating. Numerical foundations remain reconstructed; neither the
1895width text nor retrospective picture attests these specifications.
**Limits:** new actual export/photo/currentapp stillowed; Bakerhold unchanged.
**Ticket:** T-2375. **Recorded:**2026-10-29.
''')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'V5_SELECTED16FOOTWIDTH_PURE_NATIVE_RUNTIME_COMPILER_NAV_KEEPOUT_PASS_UNADOPTED','record_width_m':4.8768,'native_resolved_width_m':4.877,'six_legacy_controls_exact':True,'actual_bound_native_walker_steps_centre':consumer['actual_native_walker_steps_on_span'],'actual_bound_native_walker_steps_new_strip':consumer['widened_strip_native_walker_steps'],'bound_runtime_modules':consumer['executed_file_module_bindings'],'full_wider_mesh_plus1m_actual_old_yard_min_gap_m':yard['minimum_whole_emitted_geometry_gap_lower_bound_m'],'no_native_export_browser_photo_canonical_adoption_claim_done':True}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
files=[]
for p in sorted(O.rglob('*')):
 if p.is_file()and p.name!='MANIFEST.json':files.append({'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(stat.S_IMODE(p.stat().st_mode))})
(O/'MANIFEST.json').write_text(json.dumps({'closed_at':result['at'],'scope':'ClosedUNADOPTEDv5selected16footwidth+focusedsourceappendices; actualpure/Node/compiler/nav/keepout/newyardarithmeticPASS. No new native/WEB/photo/app/claim/adoption/gate/PR/DONE.','files':files},indent=2)+'\n')
print(json.dumps({'manifest':str(O/'MANIFEST.json'),'sha256':sha(O/'MANIFEST.json'),'files':len(files),'bytes':sum(x['bytes']for x in files),'result':result},indent=2))
