
### L-dearborn-sixteen-foot-width-2375 — Secondary width and foundation extent

**Covers:** selectedDearborn width/footprint and reconstructed bearing caps.
**Evidence:** actual Moses/Kirkland1895vol1p95 says sixteenfeetwide. Adopt
4.8768m inferred from retrospective secondary text; no contemporary survey,
attested dimension, tracedcoordinate or drawing-derived metric claim.
**Decision:** supersede old tenfoot branchproxy and absolute no-written-width
claim, while retaining old text as history.76.33m tracedwatergap, origin and
bearing stay. Existing native3decimal resolver yields4.877m (0.2mmprecision).
**Invented:** widened caps3.6×7.8288m at−1mtransverseoffset,46perimeterpiles,
sections and seating. Numerical foundations remain reconstructed; neither the
1895width text nor retrospective picture attests these specifications.
**Limits:** new actual export/photo/currentapp stillowed; Bakerhold unchanged.
**Ticket:** T-2375. **Recorded:**2026-10-29.
