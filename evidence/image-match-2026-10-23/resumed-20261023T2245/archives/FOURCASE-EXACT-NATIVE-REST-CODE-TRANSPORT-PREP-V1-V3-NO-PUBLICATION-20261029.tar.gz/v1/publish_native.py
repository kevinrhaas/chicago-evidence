"""Bounded native-commit transport. Default is read-only planning; no git push/fetch.

Run only after the actual checked final native commits exist. --publish additionally
requires the exact checked final tree, a passing gate receipt, and explicit expected
remote branch state. Native Git SHAs, trees, messages, author dates and parents stay exact.
"""
from pathlib import Path
import argparse,base64,datetime,hashlib,json,os,re,struct,subprocess
from urllib.request import Request,urlopen
from urllib.error import HTTPError

REPO='kevinrhaas/chicago';SOURCE=Path('/workspace/chicago');G=SOURCE/'.git'
BRANCH='steward/t2381-t2373-t2384-t2377-early-pictures-20261029'
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*args):
    return subprocess.check_output(['git','-C',str(SOURCE),'-c','gc.auto=0','-c','maintenance.auto=false',*args],env=ENV)
def shab(b):return hashlib.sha256(b).hexdigest()
def gitsha(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def api(path,data=None,method=None,missing=False):
    req=Request('https://api.github.com/repos/'+REPO+'/'+path,data=None if data is None else json.dumps(data).encode(),headers={'User-Agent':'Chicago-four-case-exact-native-transport','Accept':'application/vnd.github+json','Content-Type':'application/json'},method=method or('GET'if data is None else'POST'))
    try:
        with urlopen(req,timeout=120)as r:return json.load(r)
    except HTTPError as e:
        if missing and e.code==404:return None
        raise
def indexed(wanted):
    wanted=set(wanted);found={s for s in wanted if(G/'objects'/s[:2]/s[2:]).is_file()}
    for p in(G/'objects/pack').glob('*.idx'):
        if wanted<=found:break
        with p.open('rb')as f:
            h=f.read(8);v2=h[:4]==b'\xfftOc';off=8 if v2 else 0
            if v2:assert struct.unpack('>I',h[4:])[0]==2
            f.seek(off);fan=struct.unpack('>256I',f.read(1024));tab=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
            for s in wanted-found:
                key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
                while a<z:
                    m=(a+z)//2;f.seek(tab+m*stride+delta)
                    if f.read(20)<key:a=m+1
                    else:z=m
                f.seek(tab+a*stride+delta)
                if a<fan[key[0]]and f.read(20)==key:found.add(s)
    return found
def obj(kind,s):
    assert s in indexed([s]),'Refuse unknown promisor-object read: '+s
    b=git('cat-file',kind,s);assert gitsha(kind,b)==s;return b
TREES={}
def leaves(s):
    if s in TREES:return TREES[s]
    b=obj('tree',s);i=0;out={}
    while i<len(b):
        n=b.index(b' ',i);mode=b[i:n].decode();z=b.index(b'\0',n+1);name=b[n+1:z].decode();child=b[z+1:z+21].hex();i=z+21
        assert name not in ('.','..')and'/'not in name
        if mode=='40000':out.update({name+'/'+p:v for p,v in leaves(child).items()})
        else:
            assert mode in('100644','100755','120000','160000')
            out[name]=(mode,'commit'if mode=='160000'else'blob',child)
    TREES[s]=out;return out
def commit(s):
    raw=obj('commit',s);header,msg=raw.split(b'\n\n',1);lines=header.decode().splitlines()
    return {'sha':s,'raw_sha256':shab(raw),'raw':raw,'lines':lines,'message':msg.decode(),'tree':next(x[5:]for x in lines if x.startswith('tree ')),'parents':[x[7:]for x in lines if x.startswith('parent ')]}
def native_payload(c):
    assert all(x.startswith(('tree ','parent ','author ','committer '))for x in c['lines']),'Unsupported signed/extra native header; do not rewrite native commit'
    p={'tree':c['tree'],'parents':c['parents'],'message':c['message']}
    for k in['author','committer']:
        line=next(x for x in c['lines']if x.startswith(k+' '));m=re.fullmatch(k+r' (.*) <([^>]+)> (\d+) ([+-]\d{4})',line);assert m
        zone=m[4];offset=(int(zone[1:3])*60+int(zone[3:]))*60*(1 if zone[0]=='+'else-1)
        dt=datetime.datetime.fromtimestamp(int(m[3]),datetime.timezone(datetime.timedelta(seconds=offset)))
        p[k]={'name':m[1],'email':m[2],'date':dt.isoformat()}
    return p
def snapshot():
    return {'HEAD':git('rev-parse','HEAD').decode().strip(),'refs':git('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:shab((G/n).read_bytes())for n in['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status':git('status','--porcelain','--untracked-files=all').decode()}
def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--base',required=True);a.add_argument('--head',required=True);a.add_argument('--qualified-tree',required=True);a.add_argument('--gate-proof',required=True);a.add_argument('--expected-old',required=True,help='absent or exact current remote branch SHA');a.add_argument('--expected-new-commits',type=int,default=4);a.add_argument('--max-total-bytes',type=int,default=64*1024**2);a.add_argument('--output',required=True);a.add_argument('--publish',action='store_true');args=a.parse_args()
    os.sched_setaffinity(0,{1});os.nice(19);out=Path(args.output);out.mkdir(exist_ok=False)
    save=lambda n,x:(out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
    for x in[args.base,args.head,args.qualified_tree]:assert re.fullmatch('[0-9a-f]{40}',x)
    before=snapshot();save('SOURCE-BEFORE.json',before);assert before['HEAD']==args.head and not before['status'],'Final native commits must be HEAD on a clean author tree'
    assert git('branch','--show-current').decode().strip()==BRANCH
    base=commit(args.base);head=commit(args.head);assert head['tree']==args.qualified_tree
    gate_path=Path(args.gate_proof);gate_bytes=gate_path.read_bytes();gate=json.loads(gate_bytes)
    assert str(gate.get('status','')).startswith('PASS')or(gate.get('command_exit')==0 and gate.get('all_children_reaped')is True),'Gate receipt must actually pass'
    # GIT_NO_LAZY_FETCH is always set; every subsequent object body is checked by
    # loose/index membership before cat-file, and each canonical SHA is rehashed.
    ids=git('rev-list','--reverse','--topo-order',args.base+'..'+args.head).decode().splitlines();assert 1<=len(ids)<=16
    cs=[commit(s)for s in ids];available={args.base:base};available.update({c['sha']:c for c in cs})
    remote_base=api('git/commits/'+args.base);assert remote_base['tree']['sha']==base['tree']
    remote={};new=[]
    for c in cs:
        r=api('git/commits/'+c['sha'],missing=True)
        if r:
            assert r['sha']==c['sha']and r['tree']['sha']==c['tree']and[p['sha']for p in r['parents']]==c['parents'];remote[c['sha']]=r
        else:native_payload(c);new.append(c)
    assert len(new)==args.expected_new_commits
    remote_ref=api('git/ref/heads/'+BRANCH,missing=True);actual_old=None if remote_ref is None else remote_ref['object']['sha'];expected=None if args.expected_old=='absent'else args.expected_old
    assert actual_old==expected,'Remote branch changed; preserve it and re-review'
    if expected is not None:assert expected in available,'Expected old must be in this bounded native DAG'
    known_remote_blobs={v[2]for v in leaves(base['tree']).values()if v[1]=='blob'}
    for c in cs:
        if c['sha']in remote:known_remote_blobs.update(v[2]for v in leaves(c['tree']).values()if v[1]=='blob')
    needed={};diffs={}
    for c in new:
        assert c['parents']and all(p in available for p in c['parents']),'Bounded parents must be base or supplied DAG'
        old=leaves(available[c['parents'][0]]['tree']);cur=leaves(c['tree']);changes={p:cur.get(p)for p in sorted(set(old)|set(cur))if old.get(p)!=cur.get(p)}
        assert changes and all(p.startswith('chicago/4d/')for p in changes),'Code transport scope is only Chicago4D'
        for p,v in changes.items():
            if v is None:continue
            assert v[1]=='blob'and v[0]in('100644','100755'),'No new links/submodules in this unit'
            if v[2]not in known_remote_blobs:
                b=obj('blob',v[2]);needed[v[2]]={'bytes':len(b),'sha256':shab(b)}
        diffs[c['sha']]=changes
    total=sum(x['bytes']for x in needed.values());assert total<=args.max_total_bytes
    plan={'status':'EXACT_NATIVE_BOUNDED_TRANSPORT_PLANNED_NO_REMOTE_WRITES','base':args.base,'head':args.head,'qualified_final_tree':args.qualified_tree,'branch':BRANCH,'expected_old':expected,'native_new_commits':[{'sha':c['sha'],'tree':c['tree'],'parents':c['parents'],'raw_sha256':c['raw_sha256']}for c in new],'already_remote_commits':list(remote),'new_blobs':needed,'new_blob_bytes':total,'changed_paths':{s:list(d)for s,d in diffs.items()},'gate_receipt':{'path':str(gate_path),'bytes':len(gate_bytes),'sha256':shab(gate_bytes)},'force':False}
    save('PLAN.json',plan);assert snapshot()==before
    if not args.publish:print(json.dumps({'status':plan['status'],'new_blob_bytes':total,'new_commits':len(new)}),flush=True);return
    for s,row in needed.items():
        b=obj('blob',s);assert len(b)==row['bytes']and shab(b)==row['sha256']
        r=api('git/blobs',{'encoding':'base64','content':base64.b64encode(b).decode()});assert r['sha']==s
    for c in cs:
        if c['sha']in remote:continue
        entries=[]
        for p,v in diffs[c['sha']].items():entries.append({'path':p,'mode':'100644','type':'blob','sha':None}if v is None else{'path':p,'mode':v[0],'type':v[1],'sha':v[2]})
        tree=api('git/trees',{'base_tree':available[c['parents'][0]]['tree'],'tree':entries});assert tree['sha']==c['tree']
        r=api('git/commits',native_payload(c));save('COMMIT-'+c['sha']+'.json',r);assert r['sha']==c['sha'],'Refuse native SHA rewrite'
    fresh=api('git/ref/heads/'+BRANCH,missing=True);assert(None if fresh is None else fresh['object']['sha'])==expected
    assert snapshot()==before
    if expected is None:r=api('git/refs',{'ref':'refs/heads/'+BRANCH,'sha':args.head})
    else:r=api('git/refs/heads/'+BRANCH,{'sha':args.head,'force':False},'PATCH')
    assert r['object']['sha']==args.head
    final=api('git/ref/heads/'+BRANCH);assert final['object']['sha']==args.head
    public=api('git/commits/'+args.head);assert public['tree']['sha']==args.qualified_tree and[p['sha']for p in public['parents']]==head['parents']
    readback=[]
    final_paths={p for d in diffs.values()for p in d};tip_leaves=leaves(head['tree'])
    from urllib.parse import quote
    for p in sorted(final_paths):
        if p not in tip_leaves:continue
        s=tip_leaves[p][2];expected_bytes=obj('blob',s)
        with urlopen(Request('https://raw.githubusercontent.com/'+REPO+'/'+args.head+'/'+quote(p,safe='/'),headers={'User-Agent':'Chicago-four-case-exact-native-transport'}),timeout=120)as response:assert response.status==200;b=response.read()
        assert b==expected_bytes and gitsha('blob',b)==s;readback.append({'path':p,'bytes':len(b),'sha256':shab(b),'git_blob':s})
    after=snapshot();save('SOURCE-AFTER.json',after);assert after==before
    save('RESULT.json',{'status':'EXACT_NATIVE_COMMITS_BRANCH_AND_IMMUTABLE_READBACK_PASS','base':args.base,'head':args.head,'tree':args.qualified_tree,'branch':BRANCH,'native_commit_SHAs_preserved':True,'expected_old':expected,'force':False,'new_blob_bytes':total,'readback':readback,'source_HEAD_index_config_status_allrefs_unchanged':True,'scope':'Code branch checkpoint only. No PR or merge or production promotion.'})
    print(json.dumps({'status':'EXACT_NATIVE_COMMITS_BRANCH_AND_IMMUTABLE_READBACK_PASS','head':args.head,'tree':args.qualified_tree}),flush=True)
if __name__=='__main__':main()
