# Exact native four-case code transport

V2 preparation: `publish_native.py` is prepared only. It has not created remote code blobs, trees, commits, branches, PRs or merges. The final native commits do not yet exist and must be created only after the actual source gate passes.

The script preserves native commit SHA/tree/message/parents/author and committer dates. It reads object bodies only after loose/index membership, rehashes them, and never fetches, pushes, stages, commits or resets local source. It prices new blobs before any upload (default64MiB), reuses already-remote immutable ancestors, and limits the unpublished native DAG to16 commits. V2 walks explicit native parents only and stops at independently verified immutable remote commits; it does not run rev-list or traverse historical parents. Source must be clean at the supplied exact HEAD on the expected steward branch. A passing gate receipt and exact qualified final tree are required even for a plan.

First invoke without `--publish`, using actual values supplied by root:

```
python3 publish_native.py \
  --base 2cb3f591104a2e770ecf5dc42db90d4090cbbe34 \
  --head NATIVE_FINAL_HEAD \
  --qualified-tree ACTUALLY_CHECKED_FINAL_TREE \
  --gate-proof ACTUAL_PASS_RECEIPT.json \
  --expected-old absent \
  --expected-new-commits 4 \
  --output /workspace/four-case-code-rest-transport-v2-20261029/actual-plan
```

This only performs local reads and remote GETs. Review `PLAN.json` before publication. After root authorizes the concrete checked result, rerun with the same exact arguments, a NEW output directory, and `--publish`, through the shared all-children reaper. A directory is never overwritten.

`--expected-old absent` requires the branch not to exist; GitHub’s create-ref operation refuses an existing name. An existing branch requires its exact expected current SHA and a fresh read immediately before a normal `force:false` fast-forward update. No force rewrite is supported or implied. This is a guarded expected-old read plus GitHub fast-forward protection; no unsupported atomic compare-and-swap API is claimed for updates.

Every created tree and commit must equal the native SHA before the branch is written. New unsigned native commits use the same exact REST identity/date/message transport already proven by the native ticket-claim workflow. Existing signed remote commits can be reused; a new signed/extra-header commit refuses rather than rewriting it. Ordinary cloud native commits use UTC and no GPG signature.

After publication, strict HTTPS reads of every final changed file must equal native bytes, and branch head/tree/parents plus all local source HEAD/index/config/status/refs must remain exact. The result is a code-branch checkpoint only. Opening the PR, ticket review state, expected-head merge and official ticket completion remain separate authorized root actions.

Preparation validation round-tripped a genuine existing native two-parent app commit byte-for-byte and walked the complete known18031-entry current base tree, without remote writes. No final-tree or gate qualification is inferred from that control.
