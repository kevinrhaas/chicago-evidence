#!/usr/bin/env python3
"""Compose saved GT outputs with current registries; writes only this external packet."""
from pathlib import Path
import copy, datetime, hashlib, importlib.util, json, os, subprocess, sys
P=Path(__file__).resolve().parent
R=Path('/workspace/chicago'); A=R/'chicago/4d'
W=Path('/workspace/T2376-entire-primary-WIP-before-four-repair-20261029')
K=Path('/workspace/T2376-kurz-library-host-preparation-20261029/candidate-v1-native-JPEG')
HEAD='b20f4200495c38f57f268d24870313e53ed366d9'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
def git(*args):
 return subprocess.check_output(['git','-C',str(R),*args],env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0'))
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain')
before_index=sha((R/'.git/index').read_bytes())
before_refs=git('show-ref');before_config=sha((R/'.git/config').read_bytes())
rows=read(P/'RESULT.json')['rows']; paths={x['path']:x for x in rows}
assert not (P/'ADOPTION.json').exists()
def write(path,b):
 dst=P/'postimages'/path;dst.parent.mkdir(parents=True,exist_ok=True)
 # Never edit an inode hardlinked to a durable prior packet.
 if dst.exists():dst.unlink()
 dst.write_bytes(b);dst.chmod(0o644)
def link(path,src):
 dst=P/'postimages'/path;dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists():dst.unlink()
 os.link(src,dst)
def emit(j,indent=2):return (json.dumps(j,indent=indent)+'\n').encode()
registry_proof=[]
for name,key in [('manifest.json','assets'),('manifest.web.json','masters'),('manifest.versions.json','assets')]:
 path='chicago/4d/assets/'+name
 base=read(W/'preimages'/path);own=read(W/'postimages'/path);cur=read(R/path)
 assert set(base)==set(own)==set(cur)
 result=copy.deepcopy(cur);changed=[]
 for k in set(base[key])|set(own[key]):
  b=base[key].get(k);o=own[key].get(k)
  if b==o:continue
  assert cur[key].get(k) in [b,o],(path,k,'registry collision')
  assert o is not None,'Unexpected GT registry deletion'
  if key=='assets':assert o['archetype']=='frame_tavern'
  elif name=='manifest.web.json':assert 'green_tree_tavern' in k
  result[key][k]=copy.deepcopy(o);changed.append(k)
 for k,v in cur.items():
  if k!=key:assert own[k]==base[k] or own[k]==v,(path,k)
 foreign=[k for k in cur[key] if k not in changed]
 assert all(result[key][k]==cur[key][k] for k in foreign)
 write(path,emit(result));registry_proof.append({'path':path,'changed_keys':sorted(changed),'foreign_rows_retained_exact':len(foreign)})
review_paths=[
 'chicago/4d/data/reference_views/green_tree_tavern/andreas_1838.match.json',
 'chicago/4d/data/reference_views/green_tree_tavern/trowbridge_1902.match.json',
 'chicago/4d/docs/RESEARCH/green-tree-annex-T-2376/andreas-reading.match.json']
for path in review_paths:link(path,W/'postimages'/path)
for row in read(W/'RESULT.json')['rows']:
 path=row['path']
 if not (P/'postimages'/path).exists():link(path,W/'postimages'/path)
# Third published picture metadata: union only its two STORE rows, preserving all current rows.
store_path='chicago/prairie_1904_v1/research/images/STORE.json'
store=read(P/'postimages'/store_path);pending=read(K/'chicago'/store_path)
new_keys=['early-green-tree-kurz-allison-1893.jpg','early-green-tree-kurz-allison-1893-thumb.jpg']
old_store=copy.deepcopy(store)
for k in new_keys:
 assert k not in store['files'] or store['files'][k]==pending['files'][k]
 store['files'][k]=pending['files'][k]
assert all(store['files'][k]==v for k,v in old_store['files'].items())
store['bytes']=sum(v['bytes']for v in store['files'].values());write(store_path,emit(store,1))
for path in ['chicago/prairie_1904_v1/research/images/stream-green-tree-picture-references.json','chicago/4d/data/reference_views/green_tree_tavern/kurz_panel_11.json']:
 expected=next(r['sha256']for r in read(K/'RESULT.json')['app_preimages']if r['path']==path)
 assert sha((P/'postimages'/path).read_bytes())==expected,path
 link(path,K/'chicago'/path)
# Ask the native recipe using current common code and exact candidate frame producer/params.
sys.dont_write_bytecode=True;sys.path.insert(0,str(A/'generators'))
import mesh_inputs
spec=importlib.util.spec_from_file_location('gt_candidate_params',P/'postimages/chicago/4d/generators/archetypes/frame_tavern_params.py')
params=importlib.util.module_from_spec(spec);sys.modules[spec.name]=params;spec.loader.exec_module(params)
old_resolve=mesh_inputs.resolve_params;old_sha=mesh_inputs._sha_file
mesh_inputs.resolve_params=lambda arch,phase,record:params.from_phase(phase,record)if arch=='frame_tavern'else old_resolve(arch,phase,record)
mesh_inputs._sha_file=lambda p:sha((P/'postimages/chicago/4d/generators/archetypes/frame_tavern.py').read_bytes())if p==A/'generators/archetypes/frame_tavern.py'else old_sha(p)
native=[]
registries={n:read(P/'postimages/chicago/4d/assets'/n)for n in ['manifest.json','manifest.versions.json']}
for proof in registry_proof:
 if not proof['path'].endswith(('manifest.json','manifest.versions.json')):continue
 name=Path(proof['path']).name
 for key in proof['changed_keys']:
  row=registries[name]['assets'][key];sid=row['structure_id']
  rp='data/structures/'+sid+'.json' if 'version_label'not in row else 'data/structures/versions/'+sid+'/'+row['version_label']+'.json'
  f=P/'postimages/chicago/4d'/rp
  if not f.exists():f=A/rp
  record=read(f);phase=next(p for p in record['phases']if p['id']==row['phase_id'])
  doc=mesh_inputs.structure_inputs_doc(record,phase,row['archetype'])
  actual=sha(json.dumps(doc,sort_keys=True).encode());assert actual==row['inputs_sha256'],(key,actual,row['inputs_sha256'])
  native.append({'asset':key,'inputs_sha256':actual,'current_native_recipe_exact':True})
default_rows=read(Path('/workspace/T2376-current-four-before-adoption-20261029/INPUTS.json'))['rows']
for row in default_rows:
 assert sha((A/row['record_path']).read_bytes())==row['record_sha256'],row['record_path']
 assert sha((A/row['master_path']).read_bytes())==row['master_sha256'],row['master_path']
assert len(default_rows)==25
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain')
assert sha((R/'.git/index').read_bytes())==before_index
assert git('show-ref')==before_refs
assert sha((R/'.git/config').read_bytes())==before_config
adoption=[]
for f in sorted((P/'postimages').rglob('*')):
 if not f.is_file():continue
 path=f.relative_to(P/'postimages').as_posix();cur=R/path
 adoption.append({'path':path,'preimage_sha256':sha(cur.read_bytes())if cur.exists()else None,'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size,'mode':paths.get(path,{}).get('git_mode','100644')})
result={'status':'EXTERNAL_RECOVERY_REBIND_NATIVE_INPUT_PARITY_PASS_NOT_ADOPTED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':HEAD,'rows':adoption,'registries':registry_proof,'native_recipe_rows':native,'all25_pre_GT_records_and_masters_current_exact':True,'source_index_refs_config_unchanged':True,'limits':'Saved native outputs are reused only with exact current resolved recipes and byte-matched saved production proof. Native owners, Kurz metadata-bound recapture and direct review, published app BOTH canonical/optional, phone, complete gate, PR and dev merge remain pending. Kurz raw match remains unreviewed until actual metadata-bound capture. Rebind if actual clean source HEAD differs.'}
(P/'ADOPTION.json').write_bytes(emit(result));print(json.dumps({'status':result['status'],'files':len(adoption),'native_recipe_rows':len(native),'registry_changes':[(x['path'],len(x['changed_keys']))for x in registry_proof]}))
