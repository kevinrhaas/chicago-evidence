"""Freeze a completed native-owner/published GT candidate; deliberately not run yet."""
from pathlib import Path
import os,json,hashlib,datetime
assert os.environ.get('GT_APP_READY')=='current-native-owner-tail-publish-closed'
R=Path(os.environ.get('GT_APP_REPO_ROOT','/tmp/chicago-green-tree-integration'));A=R/'chicago/4d';O=Path(os.environ['GT_APP_HOME']);assert not O.exists();O.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted((R/'site/4d').rglob('*'))if p.is_file()]
assert paths;(O/'SOURCE-BINDINGS.json').write_text(json.dumps({'paths':paths,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Frozen actual published inputs; no browser acceptance.'},indent=2)+'\n')
images=json.loads((R/'chicago/prairie_1904_v1/data/images.json').read_text())['images'];store=json.loads((R/'chicago/prairie_1904_v1/research/images/STORE.json').read_text());photos=[]
for iid in ['early-green-tree-andreas-1884','early-green-tree-trowbridge-1902','early-green-tree-kurz-allison-1893']:
 rows=[r for r in images if r['id']==iid];assert len(rows)==1;r=rows[0];display=Path(r['local']['display']).name;thumb=Path(r['local']['thumb']).name;photos.append({'id':iid,'display':display,'thumb':thumb,'base_url':store['base_url'],'display_binding':store['files'][display],'thumb_binding':store['files'][thumb]})
for cam in (A/'data/reference_views/green_tree_tavern').glob('*.json'):
 if cam.name.endswith('.match.json'):continue
 j=json.loads(cam.read_text());assert j['diagnostic_only']is True
frontage=json.loads((A/'data/frontage/green_tree_frontage.json').read_text());assert len(frontage['posts'])==1
entrances=[x for x in json.loads((A/'data/enclosures/town_entrance_aprons.json').read_text())['entrances']if x['structure_id']=='green_tree_tavern'];assert any(x['read_by']=='frame_tavern.left_annex_parts'for x in entrances)
cases=[]
for label,sub in [('canonical',''),('andreas','versions/green_tree_tavern/andreas-reading/')]:
 side=json.loads((A/'data/sidecars/1835'/('green_tree_tavern.json'if not sub else'versions/green_tree_tavern/andreas-reading.json')).read_text());web=A/'assets/web'/sub/'green_tree_tavern__frame_1833.glb';assert web.read_bytes()==(R/'site/4d/data/gltf'/sub/'green_tree_tavern__frame_1833.glb').read_bytes();assert len(side['footprint']['additional_polygons'])==(2 if label=='canonical' else 3)
 cases.append({'label':label,'sidecar':side,'WEB_sha256':sha(web),'WEB_path_suffix':'/gltf/'+sub+'green_tree_tavern__frame_1833.glb','version':None if label=='canonical'else'andreas-reading'})
import sys, math
sys.path.insert(0,str(A/'tools'));import generate_frontage_works as gf
door=next(d for d in entrances if d['read_by']=='frame_tavern.left_annex_parts');bearing=math.radians(door['bearing_deg']);target=(door['at_local_enu_m'][0]+math.sin(bearing),door['at_local_enu_m'][1]+math.cos(bearing));public_start=gf._nearest_on_path(target,gf._streets()['lake']['path'])[1]
expected={'public_start':{'e':public_start[0],'n':public_start[1],'street':'lake','basis':'Nearest point on actual committed Lake Street travelled centreline; no invented second frontage.'},'cases':cases,'photos':photos,'entrances':entrances,'frontage':frontage,'native_sign':json.loads(Path('/workspace/T2376-annex-20261029/canonical-open-native/ACTUAL-NATIVE-SIGN-FULL-VERTICES.json').read_text()),'limits':'Fresh browser for each viewport/version. These are target consumer probes; no full renderer matrix or FPS claim.'}
(O/'APP-EXPECTED.json').write_text(json.dumps(expected,indent=2)+'\n');print(O)
