#!/usr/bin/env python3
"""Run official complete owners and retain exact model + serialization evidence."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,os,shutil,subprocess,time,zipfile
import xml.etree.ElementTree as ET
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path('/workspace/T2376-b20f-native-owners-20261029')
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def dump(n,j):(O/n).write_text(json.dumps(j,indent=2)+'\n')
assert os.environ.get('GT_OWNERS_READY')=='sole-leased-adoption-kurz-review-closed'
assert git('rev-parse','HEAD').decode().strip()=='b20f4200495c38f57f268d24870313e53ed366d9'
assert git('branch','--show-current').decode().strip()=='steward/t2376-green-tree-current-four-20261029'
assert not O.exists();assert shutil.disk_usage('/workspace').free>=536870912+32000000
assert shutil.disk_usage('/tmp').free>=1800000000
O.mkdir(mode=0o700)
all44=git('ls-files','*.gz','*.xlsx').decode().splitlines();assert len(all44)==44
for rel in all44:
 p=O/'before44'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/rel).read_bytes())
models={str(p.relative_to(R)):sha(p.read_bytes())for folder in ['gltf','web']for p in(A/'assets'/folder).rglob('*.glb')if not p.is_symlink()}
dump('BEFORE-MODELS.json',models)
authored={r['path']:sha((R/r['path']).read_bytes())for r in json.loads(Path('/workspace/T2376-b20f-authored-rebind-20261029/ADOPTION.json').read_text())['rows']}
dump('BINDING.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD').decode().strip(),'all48_adopted_path_current_sha256':authored,'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free,'workspace_floor':536870912,'unchanged_tmp_caller_floor':1800000000,'command':'node tools/rederive.mjs --run (official204 + second7 + settledtail)'})
start=time.monotonic()
with(O/'owners.log').open('x')as f:
 q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(O/'REAPER.json'),'--','nice','-n','19','taskset','-c','0,1,3,4','node','tools/rederive.mjs','--run'],cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
rp=json.loads((O/'REAPER.json').read_text());dump('OWNERS-EXIT.json',{'exit':q.returncode,'seconds':time.monotonic()-start,'all_children_reaped':rp['all_children_reaped']});assert q.returncode==0 and rp['all_children_reaped']
def unique(pairs):
 d={}
 for k,v in pairs:assert k not in d;d[k]=v
 return d
def canon(b):return json.dumps(json.loads(b,object_pairs_hook=unique),sort_keys=True,separators=(',',':'))
def workbook(b):
 with zipfile.ZipFile(io.BytesIO(b))as z:
  names=z.namelist();assert len(names)==len(set(names));out={}
  for n in names:
   v=z.read(n)
   if n.endswith(('.xml','.rels')):
    r=ET.fromstring(v)
    if n=='docProps/core.xml':
     for c in list(r):
      if c.tag=='{http://purl.org/dc/terms/}modified':r.remove(c)
    v=ET.canonicalize(ET.tostring(r,encoding='unicode'),rewrite_prefixes=True)
   out[n]=v
  return out
rows=[]
for rel in all44:
 p=R/rel;b=(O/'before44'/rel).read_bytes();v=p.read_bytes();exact=b==v;equal=exact;method='EXACT_BYTES'
 if not exact:
  raw=O/'raw-native44'/rel;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_bytes(v)
  if rel.endswith('.gz'):
   x,y=gzip.decompress(b),gzip.decompress(v);equal=x==y;method='DECOMPRESSED_EXACT'
   if not equal:equal=canon(x)==canon(y);method='DUPLICATE_FREE_JSON_ALL_VALUES_TYPES_ARRAY_ORDER'
  else:equal=workbook(b)==workbook(v);method='ALL_XLSX_MEMBERS_CANONICAL_XML_EXCEPT_CORE_MODIFIED'
  if equal:p.write_bytes(b)
 rows.append({'path':rel,'before_sha256':sha(b),'native_sha256':sha(v),'equal':equal,'method':method,'serialization_only_restored':not exact and equal,'real_native_change_retained':not equal})
dump('ALL44.json',rows)
for rel,digest in models.items():assert sha((R/rel).read_bytes())==digest,'Owner unexpectedly changed model '+rel
for rel,digest in authored.items():assert sha((R/rel).read_bytes())==digest,'Owner unexpectedly changed adopted source '+rel
dump('RESULT.json',{'status':'ACTUAL_GT_COMPLETE_204_PLUS7_SETTLED_NATIVE_OWNERS_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_model_bytes_exact':len(models),'all48_adopted_source_paths_exact':True,'all44_audited':44,'real_native_changes_retained':[x['path']for x in rows if not x['equal']],'all_children_reaped':True,'limits':'Native owner fixedpoint only. Publish/app BOTH eachversion/phone/fullgate/commit/PR/devmerge remain.'})
print((O/'RESULT.json').read_text())
