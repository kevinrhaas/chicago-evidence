#!/usr/bin/env python3
"""Apply one reviewed packet only after a root-granted source lease; PLAN is default."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, subprocess, tempfile
P=Path(__file__).resolve().parent;R=Path('/workspace/chicago')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0'))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--apply',action='store_true');ap.add_argument('--expected-branch',required=True);a=ap.parse_args()
 j=json.loads((P/'ADOPTION.json').read_text());assert git('rev-parse','HEAD').decode().strip()==j['head']
 assert git('branch','--show-current').decode().strip()==a.expected_branch
 assert not git('status','--porcelain')
 for row in j['rows']:
  f=R/row['path'];assert not f.is_symlink()
  assert(sha(f.read_bytes())if f.exists()else None)==row['preimage_sha256'],row['path']
  assert sha((P/'postimages'/row['path']).read_bytes())==row['sha256'],row['path']
 print(json.dumps({'status':'PLAN_ALL48_CURRENT_PREIMAGES_AND_POSTIMAGES_PASS','head':j['head'],'paths':len(j['rows']),'apply':a.apply}),flush=True)
 if not a.apply:return
 assert os.environ.get('GT_ADOPTION_READY')=='root-leased-b20f-recovery-input-parity-reviewed'
 assert not (P/'APPLIED.json').exists()
 assert os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize>536870912+4000000
 before={'index_sha256':sha((R/'.git/index').read_bytes()),'refs':git('show-ref'),'config_sha256':sha((R/'.git/config').read_bytes())}
 for row in j['rows']:
  dst=R/row['path'];dst.parent.mkdir(parents=True,exist_ok=True)
  fd,tmp=tempfile.mkstemp(prefix='.gt-recover-',dir=str(dst.parent))
  try:
   with os.fdopen(fd,'wb')as f:f.write((P/'postimages'/row['path']).read_bytes());f.flush();os.fsync(f.fileno())
   os.chmod(tmp,0o755 if row['mode']=='100755'else 0o644);os.replace(tmp,dst)
  finally:
   if os.path.exists(tmp):os.unlink(tmp)
 for row in j['rows']:assert sha((R/row['path']).read_bytes())==row['sha256'],row['path']
 assert git('rev-parse','HEAD').decode().strip()==j['head']
 assert sha((R/'.git/index').read_bytes())==before['index_sha256']
 assert git('show-ref')==before['refs']
 assert sha((R/'.git/config').read_bytes())==before['config_sha256']
 result={'status':'ACTUAL48_RECOVERY_ADOPTED_HEAD_INDEX_REFS_CONFIG_UNCHANGED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':j['head'],'branch':a.expected_branch,'adoption_sha256':sha((P/'ADOPTION.json').read_bytes()),'rows':j['rows'],'limits':'Native outputs reused under exact resolved26 recipes and25 unchanged complete old records. Current owner fixedpoint/Kurz capture/app/phone/fullgate/PR/merge pending.'}
 (P/'APPLIED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'paths':len(j['rows'])}))
if __name__=='__main__':main()
