import os
os.sched_setaffinity(0, {1})
os.nice(19)
from pathlib import Path, PurePosixPath
import base64, datetime, gzip, hashlib, io, json, stat, tarfile, time
from urllib.request import Request, urlopen
from urllib.error import HTTPError

REPO = 'kevinrhaas/chicago-evidence'
API = 'https://api.github.com/repos/' + REPO + '/'
REL = 'evidence/image-match-2026-10-23/resumed-20261023T2245/'
OUT = Path('/tmp/checkpoint-oct29-actual-four-pass-PR1456-and-next-native-2034')
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda b: hashlib.sha256(b).hexdigest()
gitsha = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
dump = lambda d: (json.dumps(d, indent=2, ensure_ascii=False) + '\n').encode()

def api(path, data=None, method=None):
    import http.client
    for attempt in range(4):
        req = Request(API + path, data=None if data is None else json.dumps(data).encode(),
                      headers={'User-Agent':'Chicago-evidence-RAM-publisher','Accept':'application/vnd.github+json','Content-Type':'application/json'}, method=method or ('GET' if data is None else 'POST'))
        try:
            with urlopen(req, timeout=60) as r: return json.load(r)
        except (http.client.IncompleteRead, TimeoutError, ConnectionError) as e:
            if data is not None or attempt == 3: raise
            print('STRICT_GET_RETRY',path,type(e).__name__,attempt+1,flush=True);time.sleep(1)
        except HTTPError as e:
            print('API_ERROR',method,path,e.code,e.read(65536).decode(errors='replace'),flush=True);raise

def raw(head,path):
    import http.client
    for attempt in range(4):
        req = Request('https://raw.githubusercontent.com/' + REPO + '/' + head + '/' + path,headers={'User-Agent':'Chicago-evidence-RAM-publisher'})
        try:
            with urlopen(req,timeout=60) as r:
                assert r.status==200
                return r.read()
        except (http.client.IncompleteRead, TimeoutError, ConnectionError) as e:
            if attempt == 3: raise
            print('STRICT_RAW_GET_RETRY',path,type(e).__name__,attempt+1,flush=True);time.sleep(1)

def tree_files(tree):
    d = api('git/trees/' + tree + '?recursive=1')
    assert not d.get('truncated'), 'Refuse incomplete preservation audit'
    return {r['path']: (r['mode'], r['type'], r['sha']) for r in d['tree'] if r['type'] != 'tree'}

def create_blob(data):
    d = api('git/blobs', {'encoding': 'base64', 'content': base64.b64encode(data).decode()})
    assert d['sha'] == gitsha(data)
    return d['sha']

def readback(head, changed, blobs):
    rows = []
    for path, data in changed.items():
        received = raw(head, path)
        assert received == data and gitsha(received) == blobs[path], path
        rows.append({'path': path, 'bytes': len(data), 'sha256': sha(data), 'git_blob': blobs[path],
                     'status': 'PASS', 'method': 'STRICT_HTTPS_IMMUTABLE_COMMIT_PATH_SHA256_AND_GIT_BLOB_SHA1',
                     'immutable_raw_url': 'https://raw.githubusercontent.com/' + REPO + '/' + head + '/' + path})
    return rows

SPECS = [('FOURCASE-ACTUAL-FINAL-C164-FULLSOURCE1104-PASS-20261029', '/workspace/early-four-full-gate-v2-root-20261029', 'edcfbe862b594880f1eb8108ae2787ba08e945e76eec9dd8874424307d496560', 'ACTUAL final c164sourcePASS: all1104steps/395selftests, sevenexact sourceguards true, allchildrenreaped. Original623ebase andc164stagedtree; this datedreceipt does not qualify laterupstreamBE501/9400 composites. Originalninefailure receipt remainspriorarchives, neverrelabeled.'), ('FOURCASE-ACTUAL-NATIVE-FOUR-COMMITS-20261029', '/workspace/early-four-native-code-commits-v2-root-20261029', 'd88dd299c1613baf49f1e35425cb4633a27a431aab081b3613744dc38cc4e50e', 'Actualfour native one-ticketcommits afterfullgatePASS, finalf683/treec164, exact59ownedpaths. No PRmerge orofficialoriginalclosure implied.'), ('FOURCASE-ACTUAL-COMMITTED-THREE-PR-QUESTIONS-20261029', '/workspace/early-four-postcommit-questions-v2-root-20261029', '844eea7b35f40fb49906e14f496182e882020fab73c287e2b88fc61ee98d8470', 'Actualnative committed check-changelog-entry, resolve_id_collisions --check andchangelog PASS atf683. Not requiredGitHubgate.'), ('FOURCASE-ACTUAL-NATIVE-CODE-PUBLICATION-READBACK-20261029', '/workspace/early-four-v2-code-publication-20261029', '67a82f3489214dde917a1b4ce705751d052f5f487ee8283aacbe35133e87d14c', 'ActualnormalFF exactfour native commits published;59immutableHTTPSchangedpaths allbytes/SHA/Gitblob/mode/tree/parents verified; allsource HEAD/index/config/status/refs unchanged. Branchcheckpointonly, noPRmerge.'), ('FOURCASE-ACTUAL-PR1456-READY-CREATED-GATE-PENDING-20261029', '/workspace/early-four-actual-PR-frozen-publisher-v3-20261029', 'b1ea914f8267e0f915bc36f953f26a20dad52db3d0f69ada4fa488edd778b972', 'Actual PR1456 open/ready into dev, nativeownlap held. Readonly20:32UTC headf683 dirty/currentdev9400; warranted/report success, requiredgate absent. CombinedBE501fullgateLIVEexcluded. No originalDONE ornewcombinedPASS/mergeclaim.'), ('FOURCASE-623E-DATED-APP-REUSE-EXACT-INPUT-PROOF-20261029', '/workspace/early-four-623e-dated-app-reuse-20261029', 'd49a3f5cda7b9a77f798d1d49b424c2c73cfc85b95ca454eb39a8a4240e01700', 'Actual21member datedappinputproof:255JS/pictures,26terrain, Hogan/Mary/Lighthouse native+publishedsidecars/WEB exact; fourcameras/grades/STORE/props/placement exact. Miller10mm/sourceWEBdelta separatelyactualfreshFullBOTH;29libertyrows27exact,2coverageonly corrections. Rawfailedrepresentationassumption preserved. No globalmatrix/FPSclaim.'), ('DEARBORN2375-ACTUAL-WIDTH16-V5-NATIVE-WEB-PHOTO-20261029', '/workspace/T2375-native-v5-width16-20261029', 'e6d92e6318d654ea08f80611a86c2e021a9b965703feff64755dfa9efbc88a25', 'ActualV5nativeMASTER/Web/Andreasphoto andsixlegacyMASTERparity; allreaped1/1/4.174members11.86MB. Rootdirectlyviewedcomparison; externalonly no canonicalclaim/adoption/currentapp/fullgate/originalDONE. Prematuremanifest/loghashstop preserved; closedafterwriterfinished withoutnativererun. Width16ftinferred viaretrospectiveNorton/Moses, notcontemporarysurvey.'), ('COBWEB2374-ACTUAL-FINITE-TWO-CAMERAS-NO-FALSE-PASS-20261029', '/workspace/T2374-finite-native-camera-trial-20261029', 'c471c50235e122c66fd497b789a5f817ba67ada6817143576a9700051821847f', 'Actualtwofinite70rear/110front nativecaptures onexistingPR1260MASTER exact, allreaped; rootdirectlyviewed. Conditionalpanoramaidentity and silhouette conflict persist; no cameraonlyMATCHES, no canonicalclaim/export/sourcegradechange orDONE. Do notoverrideattestedcentre/twowings/twotails fromambiguoussubject.'), ('CURRENTDEV-BE501-ACTUAL-BOUNDED-OBJECT-IMPORT-20261029', '/tmp/current-dev-be501-bounded-import-20261029', '2f83ce04b5bb09c0ab83d061a0b62e0f67008c81b6512e8747487eeeb8c68c51', 'ActualboundedBE501metadata/blobs import andexactcachedorigin/devCAS;80objects15.9MBraw/6.2MBallocated;18036entries/17521blobIDsandsizesverified. Source/index/config/MERGE/status andallotherrefs preserved. Availabilityonly, notsourceadoptionorcombinedgatePASS.'), ('CURRENTDEV-9400-READONLY-SCOPE-THREE-K-EXCEPTIONS-20261029', '/tmp/current-dev-9400-readonly-price-20261029', '6d031ecf099b1967fd921c4bef7f96b65d53f5fa41e9eccec5ee049253f5d84d', 'Actualread-only9400scope/price:44missingblobs37.54MB,524/527protectedexact; threeK01/K03helpers changed, no directlog/frame dependency. NO9400primaryobjectimport/ref/sourceadoption orqualification. Laternewdev remainsunqualifiedbyoldc164checks.'), ('FOURCASE-NATIVE-MERGE-TRANSPORT-V2-PREPARATION-20261029', '/workspace/early-four-native-merge-transport-v2-prep-20261029', '0af89e03669c5270dd0a83aa8e2a4a7539bd2016b247b999acb235b4a4cc7974', 'Syntaxchecked strongerone-native-merge transportpreparation only. Preservesactualcomposite12checks/current400MiBphone/6hashedreceipts/527bindings/353rows706models/expectedoldnormalFF. Permitsbehind9400branchcheckpoint withscopedexceptions; currentrequiredCI/cleanmergeabilitymandatory. Noactualplan/publication/PRmerge.')]
assert SPECS, 'All requested manifests already durable'
payloads, records, archive_members = {}, [], {}
for spec in SPECS:
    name, source, expected, note = spec[:4]
    manifest_name = spec[4] if len(spec) > 4 else 'MANIFEST.json'
    root = Path(source)
    manifest_bytes = (root / manifest_name).read_bytes()
    assert sha(manifest_bytes) == expected
    manifest = json.loads(manifest_bytes)
    raw_rows = manifest.get('files', manifest.get('members'))
    assert raw_rows is not None
    rows = ([{'path': path, **value} for path, value in raw_rows.items()] if isinstance(raw_rows, dict) else list(raw_rows))
    normalized_rows = []
    for row in rows:
        row = dict(row)
        if PurePosixPath(row['path']).is_absolute():
            original_source = Path(row['path'])
            if 'relative_path' in row:
                row['path'] = row['relative_path']
                row['_immutable_author_source_path'] = str(original_source)
            else:
                row['path'] = str(original_source.relative_to(root))
        normalized_rows.append(row)
    rows = normalized_rows
    assert all(r['path'] != manifest_name for r in rows)
    rows.append({'path': manifest_name, 'bytes': len(manifest_bytes), 'sha256': expected})
    assert len({r['path'] for r in rows}) == len(rows)
    checked = []
    buf = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=buf, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tf:
            for r in sorted(rows, key=lambda r: r['path']):
                rel = PurePosixPath(r['path'])
                assert not rel.is_absolute() and '..' not in rel.parts
                p = Path(r['_immutable_author_source_path']) if '_immutable_author_source_path' in r else root / r['path']
                assert p.is_file() and not p.is_symlink()
                data = p.read_bytes()
                assert len(data) == r['bytes'] and sha(data) == r['sha256'], p
                mode = stat.S_IMODE(p.stat().st_mode)
                if 'mode' in r:
                    if isinstance(r['mode'], str) and r['mode'] in ('100644', '100755'):
                        # Git regular-file modes encode executable status, not Unix
                        # owner/group access bits. Preserve the actual FS mode in tar.
                        assert stat.S_ISREG(p.stat().st_mode)
                        actual_git_mode = '100755' if mode & 0o111 else '100644'
                        assert actual_git_mode == r['mode'], 'Declared Git executable mode mismatch: ' + str(p)
                    else:
                        declared = int(r['mode'], 0) if isinstance(r['mode'], str) else r['mode']
                        assert mode == declared, 'Declared Unix permission mode mismatch: ' + str(p)
                info = tarfile.TarInfo(r['path'])
                info.size, info.mode, info.mtime = len(data), mode, 0
                tf.addfile(info, io.BytesIO(data))
                checked.append({'source': str(p), 'path': r['path'], 'bytes': len(data), 'sha256': sha(data), 'mode': mode})
    archive = buf.getvalue()
    def check_tar(data, checked=checked):
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as tf:
            entries = tf.getmembers()
            assert len(entries) == len(checked)
            bypath = {r['path']: r for r in checked}
            assert {m.name for m in entries} == set(bypath)
            for m in entries:
                r = bypath[m.name]
                assert m.isfile() and m.size == r['bytes'] and m.mode == r['mode']
                b = tf.extractfile(m).read()
                assert sha(b) == r['sha256']
    check_tar(archive)
    filename = name + '.tar.gz'
    record = {'name': name, 'source_manifest_sha256': expected, 'source_manifest_filename': manifest_name, 'archive': '/workspace/chicago-evidence-metadata-20261024/archives/' + filename,
              'sha256': sha(archive), 'bytes': len(archive), 'source_file_count': len(checked),
              'source_bytes': sum(r['bytes'] for r in checked),
              'readback': 'PASS; every archived payload hash/size/mode and member list verified in RAM',
              'scope_note': note,
              'storage_note': 'Created and verified in RAM. No local tar or publisher Git-object/index copy. Immutable remote verification recorded separately after normal-FF publication.'}
    payloads[REL + 'archives/' + filename] = archive
    payloads[REL + 'archives/' + filename + '.manifest.json'] = dump({'created_utc': NOW, 'name': name, 'scope_note': note,
                                                                 'source_file_count': len(checked), 'files': checked})
    payloads[REL + 'archives/' + filename + '.receipt.json'] = dump(record)
    records.append(record)
    archive_members[REL + 'archives/' + filename] = check_tar
    print('PACKED', name, len(checked), len(archive), sha(archive), flush=True)

chunk_transports = {}
for path, data in list(payloads.items()):
    if len(data) <= 8 * 1024**2:
        continue
    assert path.endswith('.tar.gz')
    del payloads[path]
    parts = []
    for number, offset in enumerate(range(0, len(data), 8 * 1024**2)):
        part = data[offset:offset + 8 * 1024**2]
        part_path = path + '.part-' + str(number).zfill(4)
        payloads[part_path] = part
        parts.append({'index': number, 'path': part_path, 'bytes': len(part), 'sha256': sha(part), 'git_blob': gitsha(part)})
    transport = {'schema': 'CHICAGO_LOSSLESS_ARCHIVE_PARTS_V1', 'original_archive_path': path,
        'archive_bytes': len(data), 'archive_sha256': sha(data), 'parts': parts,
        'raw_chunk_limit_bytes': 8 * 1024**2,
        'restoration': 'Read each part from the SAME immutable publication commit in numerical index order. Verify each bytes/SHA256/Gitblob, concatenate exact bytes, verify archive_bytes and archive_sha256. Open gzip tar and verify every source member against the byte-exact original author source manifest listed as an archive member. No payload rewrite.',
        'reason': 'Proactive reuse of the established <=8MiBraw transport after previously documented GitDataHTTP422 on a large archive at checkpoint392. No new request failure is claimed. This avoids a large base64 blob POST and preserves every source byte.',
        'member_verification': 'Every source archive member hash/size/mode and exact complete member list verified before publication and independently after immutable remote part reassembly.'}
    manifest_path = path + '.parts.json'
    payloads[manifest_path] = dump(transport)
    chunk_transports[path] = transport
    rec = next(r for r in records if path.endswith('/' + r['name'] + '.tar.gz'))
    rec['remote_transport'] = {'kind': 'LOSSLESS_ORDERED_CHUNKS', 'manifest_path': manifest_path, 'manifest_sha256': sha(payloads[manifest_path]), 'parts': parts, 'archive_sha256': sha(data), 'archive_bytes': len(data)}
    payloads[path + '.receipt.json'] = dump(rec)
    print('CHUNKED', path, len(parts), len(data), sha(data), flush=True)
blob_ids = {p: create_blob(b) for p, b in payloads.items()}

for attempt in range(5):
    parent = api('git/ref/heads/main')['object']['sha']
    before_commit = api('git/commits/' + parent)
    before_files = tree_files(before_commit['tree']['sha'])
    index = json.loads(raw(parent, REL + 'ARCHIVES.json'))
    assert not {r['name'] for r in records} & {r['name'] for r in index}, 'New name unexpectedly already present'
    recovery = raw(parent, REL + 'RECOVERY.md').decode()
    heading = ('\n<!-- OCT29_ACTUAL_FOUR_SOURCE_PASS_PR1456_NEXT_NATIVE_START -->\n## Four-building source changes passed and PR1456 is open; combined-branch checks are running\n\nThe actual final c164source gate passed1104steps/395selftests, all sevenunchangedsourceguards, andallchildrenreaped. Four nativeone-ticketcommits andthreeactualcommittedPRquestions passed, thenall59ownedchangedpaths werepublished withstrictimmutablebyte/SHA/Gitblob/tree/parentreadback. PR1456 isready into dev. Itwasstilldirty at20:32UTC/currentdev9400, withrequiredgateabsent. NativeBE501resolverhascompleted; the newcombinedfullgate isLIVE andexcludedfromthisclosedcheckpoint. No combinedPASS, PRmerge ororiginalticketDONE isclaimed.\n\nFreshFullMillerBOTH wascheckpoint649; thisadditionpreservesthe honestdatedotherthreeappinputreuseproof. ActualexternalDearbornV5native/Web/photo andCobwebtwofinitecapturesareclosed. Dearbornstillneeds canonicaladoption/app/sourceidentitydispositions; Cobwebconditionalpanorama remainsaform/identity conflict, nevercamerawavedthrough. Currentdev9400scope records threeunrelatedKhelperexceptions, not527allunchanged, andhasnotbeenimported/adopted. Strongertransportpreparation isnotpublicationorqualification. Priorfailurehistory andallpriorremotepathsremainpreserved.\n\n' + '\n'.join('- [' + r['name'] + '](archives/' + r['name'] + ('.tar.gz.parts.json' if r.get('remote_transport') else '.tar.gz') + ') — ' + r['scope_note'] for r in records) + '\n<!-- OCT29_ACTUAL_FOUR_SOURCE_PASS_PR1456_NEXT_NATIVE_END -->\n\n')
    first_line, remainder = recovery.split('\n', 1)
    changed = dict(payloads)
    changed[REL + 'ARCHIVES.json'] = dump(index + records)
    changed[REL + 'RECOVERY.md'] = (first_line + '\n' + heading + remainder).encode()
    blobs = dict(blob_ids)
    for path in [REL + 'ARCHIVES.json', REL + 'RECOVERY.md']:
        blobs[path] = create_blob(changed[path])
    t = api('git/trees', {'base_tree': before_commit['tree']['sha'],
                         'tree': [{'path': p, 'mode': '100644', 'type': 'blob', 'sha': blobs[p]} for p in sorted(changed)]})
    c = api('git/commits', {'message': 'Checkpoint actualfourbuilding sourcePASS PR1456 andclosednative nextwork',
                           'tree': t['sha'], 'parents': [parent]})
    try:
        api('git/refs/heads/main', {'sha': c['sha'], 'force': False}, 'PATCH')
    except HTTPError as e:
        if e.code in [409, 422] and api('git/ref/heads/main')['object']['sha'] != parent:
            print('Concurrent remote advance; rebuilding on fresh parent', flush=True)
            continue
        raise
    head = c['sha']
    after_files = tree_files(t['sha'])
    for p, entry in before_files.items():
        if p not in changed:
            assert after_files.get(p) == entry, 'Existing remote path changed: ' + p
    assert all(after_files[p] == ('100644', 'blob', blobs[p]) for p in changed)
    proof = readback(head, changed, blobs)
    for path, checker in archive_members.items():
        if path in chunk_transports:
            transport = chunk_transports[path]
            received_parts = [raw(head, part['path']) for part in transport['parts']]
            for received, part in zip(received_parts, transport['parts']):
                assert len(received) == part['bytes'] and sha(received) == part['sha256'] and gitsha(received) == part['git_blob']
            received_archive = b''.join(received_parts)
            assert len(received_archive) == transport['archive_bytes'] and sha(received_archive) == transport['archive_sha256']
            checker(received_archive)
            print('IMMUTABLE_REMOTE_CHUNK_REASSEMBLY_EVERY_SOURCE_MEMBER_PASS', transport['archive_sha256'], flush=True)
        else:
            checker(raw(head, path))
    receipt = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'repository': REPO,
               'status': 'PUBLISHED_NORMAL_FF_AND_FULL_IMMUTABLE_READBACK_PASS',
               'method': 'IN_RAM_GIT_DATA_REST_NORMAL_FF_FORCE_FALSE', 'parent': parent, 'commit': head,
               'tree': t['sha'], 'archives_count': len(index) + len(records), 'new_archive_records': records,
               'changed_paths': sorted(changed), 'readback': proof,
               'all_prior_remote_file_paths_independently_preserved': True,
               'prior_remote_files_checked': len(before_files),
               'local_publisher_worktree_unchanged': True, 'local_tar_copies_created': False,
               'index': 'https://github.com/' + REPO + '/blob/' + head + '/' + REL + 'RECOVERY.md'}
    receipt_bytes = dump(receipt)
    (OUT / 'PUBLICATION.json').write_bytes(receipt_bytes)
    print('PUBLICATION_PASS', head, len(index) + len(records), len(proof), flush=True)
    break
else:
    raise RuntimeError('Remote advanced too often; no forced update attempted')

receipt_path = REL + 'publications/' + head + '.json'
receipt_blob = create_blob(receipt_bytes)
for attempt in range(5):
    parent2 = api('git/ref/heads/main')['object']['sha']
    before2 = api('git/commits/' + parent2)
    files2 = tree_files(before2['tree']['sha'])
    ledger = json.loads(raw(parent2, REL + 'STORAGE-ARCHIVE-OMISSIONS.json'))
    existing = {r['name'] for r in ledger['files']}
    for record in records:
        filename = record['name'] + '.tar.gz'
        assert filename not in existing
        path = REL + 'archives/' + filename
        if path in chunk_transports:
            transport = record['remote_transport']
            manifest_path = transport['manifest_path']
            remote_proof = next(p for p in proof if p['path'] == manifest_path)
            ledger['files'].append({'name': filename, 'local_archive_path': record['archive'],
                'worktree_path': '/workspace/chicago-private-publisher-20261024/' + path,
                'git_path': manifest_path, 'sha256': record['sha256'], 'bytes': record['bytes'],
                'git_blob': None, 'transport_manifest_git_blob': blobs[manifest_path],
                'transport_manifest_sha256': transport['manifest_sha256'],
                'remote_transport': transport,
                'verified_committed_at': head, 'storage': 'REMOTE_ONLY_LOSSLESS_ORDERED_CHUNKS_NO_LOCAL_TAR_OR_GIT_COPY',
                'independent_remote_readback': {'status': 'PASS', 'each_chunk_sha256_size_git_blob': True, 'concatenated_archive_sha256_size': True, 'all_source_members_hash_size_mode': True, 'published_commit': head, 'receipt_file': receipt_path, 'receipt_sha256': sha(receipt_bytes)},
                'restore_url': remote_proof['immutable_raw_url'],
                'restoration': 'restore_url is the TRANSPORT MANIFEST, not the tar. Verify its transport_manifest_sha256, then download ordered parts from verified_committed_at. Verify every part and concatenated tar SHA/size. Original archive and every nested member were independently checked after immutable remote reassembly. No single-file tar Gitblob is claimed.'})
            continue
        remote_proof = next(p for p in proof if p['path'] == path)
        ledger['files'].append({'name': filename, 'local_archive_path': record['archive'],
            'worktree_path': '/workspace/chicago-private-publisher-20261024/' + path,
            'git_path': path, 'sha256': record['sha256'], 'bytes': record['bytes'],
            'git_blob': blobs[path], 'verified_committed_at': head,
            'storage': 'REMOTE_ONLY_API_PUBLICATION_NO_LOCAL_TAR_OR_OBJECT_COPY',
            'independent_remote_readback': {**remote_proof, 'published_commit': head,
                 'published_at': receipt['at'], 'receipt_file': receipt_path, 'receipt_sha256': sha(receipt_bytes)},
            'restore_url': remote_proof['immutable_raw_url'],
            'restoration': 'Download immutable strict-HTTPS restore_url and verify exact bytes/SHA256/Gitblob. Local publisher metadata/HEAD remain stale; no local Git object/index or tar presence claimed.'})
    for previous in ledger.get('additional_in_ram_publications', []):
        if previous.get('anchor_commit') == '27c49b89af454b76e87e9f124e39b8318b26633a':
            assert previous['count'] == 3
            if 'caption_correction' not in previous:
                previous['caption_correction'] = {'previous_scope_text': previous.get('scope'), 'reason': 'Correct reused publisher summary caption; actual three archive records and immutable source/readback receipts remain unchanged.'}
                previous['scope'] = 'Three finite obsolete publisher Git recovery/retirement, actual independent Miller diagnostic, and original17 progress prose archives. Every source member verified after immutable readback. No app acceptance inferred.'
    ledger['count'] = len(ledger['files'])
    ledger['status'] = 'AUTHORIZED_EXACT' + str(ledger['count']) + '_REMOTE_VERIFIED_ARCHIVE_TAR_OMISSIONS'
    ledger['extended_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    ledger.setdefault('additional_in_ram_publications', []).append({'count': len(records), 'anchor_commit': head,
        'total_bytes': sum(r['bytes'] for r in records), 'local_payloads_or_git_objects_written': False,
        'scope': 'Nine closed actualcurrentMillerFullBOTH, floorcachepreservation, rootrepairreceipts, Cobwebcamera andBridgeV5width/sourcepreparations, publisher640recovery andpendingPRpayload archives. ActualFULLSOURCEV2RUNNING/notpassed atfreeze; no codepublication/appPR/originalclosure. Every member verified after immutable readback; prior paths and all scope limits preserved.'})
    changes2 = {receipt_path: receipt_bytes, REL + 'STORAGE-ARCHIVE-OMISSIONS.json': dump(ledger)}
    blobs2 = {receipt_path: receipt_blob, REL + 'STORAGE-ARCHIVE-OMISSIONS.json': create_blob(changes2[REL + 'STORAGE-ARCHIVE-OMISSIONS.json'])}
    t2 = api('git/trees', {'base_tree': before2['tree']['sha'], 'tree': [
        {'path': p, 'mode': '100644', 'type': 'blob', 'sha': blobs2[p]} for p in sorted(changes2)]})
    c2 = api('git/commits', {'message': 'Record immutable availability forcurrentFullBOTH andfinite preparations',
                           'tree': t2['sha'], 'parents': [parent2]})
    try:
        api('git/refs/heads/main', {'sha': c2['sha'], 'force': False}, 'PATCH')
    except HTTPError as e:
        if e.code in [409, 422] and api('git/ref/heads/main')['object']['sha'] != parent2:
            continue
        raise
    after2 = tree_files(t2['sha'])
    assert all(after2.get(p) == entry for p, entry in files2.items() if p not in changes2)
    readback2 = readback(c2['sha'], changes2, blobs2)
    final = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'PASS',
             'publication': head, 'availability_commit': c2['sha'], 'availability_parent': parent2,
             'archives_count': receipt['archives_count'], 'omission_count': ledger['count'],
             'all_existing_paths_preserved': True, 'readback': readback2,
             'index': 'https://github.com/' + REPO + '/blob/' + c2['sha'] + '/' + REL + 'RECOVERY.md',
             'local_git_metadata_unchanged': True, 'local_tar_copies_created': False}
    (OUT / 'COMPLETE.json').write_bytes(dump(final))
    print(json.dumps(final, indent=2), flush=True)
    break
else:
    raise RuntimeError('Availability update raced; publication remains durable and local receipt preserved')
