---
id: T-0470
title: Map the 15 August 1812 evacuation route and battle-location confidence zone
state: done
epic: SOUTH_TIME
requested_by: owner
seen: false
effort: S
legacy_id: null
parent: null
opened: 2026-09-01
closed: 2026-10-04
pr: 384
claimed_by: run 10/3/2026, 11:14:01 PM CT
blocked_on: null
needs_bake: false
closed_at: 2026-10-04T06:53:21Z
claimed_run: https://github.com/kevinrhaas/polecat-platform/actions/runs/37176233882
claimed_at: 2026-10-04T04:14:01.586Z
decision: null
decision_answer: null
---

Georeference the Fort Dearborn evacuation route south along the 1812 lakeshore and represent the battle site as an evidence-weighted corridor/zone rather than one falsely exact pin. Reconcile the traditional 18th/Prairie-Calumet marker area with historical accounts, maps and later scholarship.

The output is documentary geography: route polyline(s), uncertainty envelope, dated interpretive records and source notes. It may be visible as a route/interpretive overlay or card, but it must not imply that every reported phase of the fighting can be located to modern-lot precision.

Acceptance: a visitor can follow a sourced route from the first fort to the approximate battle area; the confidence/uncertainty is visible in the evidence model; exact and approximate claims are distinguished; and the route uses the reconstructed 1812 shoreline rather than modern streets as its primary geography.