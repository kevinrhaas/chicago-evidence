---
id: T-0476
title: Fill the 1904 Prairie Avenue corridor with documented residences and outbuildings
state: split
epic: SOUTH_TIME
requested_by: owner
seen: false
effort: M
legacy_id: null
opened: 2026-09-01
closed: 2026-10-16
pr: null
claimed_by: null
blocked_on: null
needs_bake: true
---

After the landmark core, populate the rest of the chosen 1880s Prairie Avenue corridor with the documented residences, carriage houses, stables, fences and other parcel structures visible in period atlases/fire-insurance maps. The goal is a historically dense residential district, not a few isolated hero houses in empty blocks.

Use a one-run batch sized to the available evidence and geometry budget. Where a footprint is documented but architecture is not, build a period-bounded reconstructed massing and label it honestly rather than omitting the building. Preserve parcel-level distinctions between documented, inferred and reconstructed components.

Acceptance: one coherent multi-parcel batch visibly increases the corridor's density; every added structure is dated to the chosen scene and tied to a parcel/source; reconstructed forms carry their liberty; and closing this ticket creates the next corridor-infill batch if the period map still contains unbuilt occupied parcels.

## Owner ruling, 2026-09-26: Prairie Avenue is centred on 1904

The owner, working with Glessner House, set **1904** as the year of the Prairie Avenue model. This supersedes the "1880s" framing and T-1249's 1 July 1888 date *for the Prairie Avenue scene*. T-1249's epoch record and `data/terrain/1880s_scene_date_constraints.json` may stay as they are; the owner said "you can leave the 1888 scene if you need to". Nothing here needs to delete them, but nothing Prairie Avenue builds is dated 1888. The scene date defaults to **1904-07-01** (the project's day-of-year convention, as 1835-07-01); a run may argue another day in writing.

**Sources, committed at `chicago/reference/prairie-avenue/sanborn-1911-and-robinson-1886/`** (read its README first): the Sanborn **1911** Chicago vol. 3 **key** and **sheets 20, 28 and 35** (E. 16th to E. 22nd St., Indiana Av. to the IC tracks and Lake Michigan), and **Robinson's 1886 atlas, plate 10** (16th to 18th St.). Glessner House's reading is that on these sheets only two things changed between 1904 and 1911: **1609–1611 Prairie** (two rowhouses in 1904, a commercial building by 1911) and **1620 Prairie** (a house in 1904, an empty lot by 1911). For both, the 1886 Robinson outlines stand in. Each ticket that spends a sheet writes its own `data/sources/*.json` record, in the house format, before citing it.

**For this ticket (1904 corridor infill):** every dwelling, barn, stable, green house and garage on sheets 20, 28 and 35 is a footprint candidate, with material from the key's colours and stories from the sheet ("2B", "3SB"). Two corrections to 1911: **1609–1611** are two rowhouses in 1904 (Robinson outlines), not the 1911 commercial building; **1620** has a house in 1904 (Robinson outline), not the 1911 empty lot. **The 1911 "Garage" labels:** rule each one as a 1904 carriage house or stable, or as a post-1904 build, in writing. A 1911 motor garage is not built into 1904 by default.

## Owner, 2026-09-28: the Prairie Avenue 1904 research library is a source here

The research library committed with T-1633 (#82), **`chicago/prairie_1904_v1/`**, can be browsed at
**https://chicago.polecat.live/prairie-1904/viewer/** (dev mirror `/4d/dev/prairie-1904/viewer/`).
Read its `README.md` and `docs/research-gaps.md` before starting. It holds `data/buildings.csv`,
`building_events.csv`, `assertions.csv`, `sources.csv`, `map_frontages.csv` (1911 frontage
readings, 91 of them still tentative), `measurements.csv` and `address_crosswalk.csv`; the five
original map JPEGs with checksums under `maps/originals/`; and dossiers under `research/`
(`glessner-dossier.json`, `glessner-chronology-supplement.json`, `civic-dossier.json`,
`dimensional-claims.json`, `map-inventory.json`). It **supports** this ticket and does not close
its acceptance. A tentative reading stays tentative until this ticket resolves it against the
sheets, and every value taken from the library cites the library row or dossier entry it came from.

**For this ticket:** research-gaps item **1** is this ticket's denominator: the 91 tentative frontages, the three 1904 corrections, the 1700/1702 shared structure, the 1916/1930 alias, and the unnamed rear stables, enumerated separately.

## Architectural assessment and implementation decomposition — 2026-10-01

The owner-requested [T-1837 study](../evidence/T-1837-prairie-1904-architectural-study/README.md) now supplies the source-pinned building/frontage registers, common components, dated reconstruction decisions and [110 staged child tickets](../evidence/T-1837-prairie-1904-architectural-study/TICKET-PLAN.md). This umbrella retains programme ownership; use those children for actual execution rather than filing duplicate building/component work. The existing 2026-09-30 construction hold remains unchanged.

## Owner resumed and queued the programme — 2026-10-01

Owner: “Go”, then “Push the tickets to dev queue in one group below”. The inherited construction hold is lifted for all 110 implementation tickets, T-1840–T-1949. They are open in one contiguous, dependency-ordered group at the bottom of the dev queue. Existing unrelated queue rows retain their order. The legacy umbrella tickets remain scope references; execute the named child packages and their dependencies, not duplicate umbrella builds.

## Closed as split — 2026-10-16

Verified on the owner's instruction ("verify the old tickets, maybe they were replaced"). This umbrella's scope was decomposed on 2026-10-01 into the T-1837 Prairie Avenue 1904 architectural programme — T-1837 is `split` into 110 children (T-1840..T-1949, 74 still open, 5 done, 31 split further), the district draft pass T-2159..T-2163, and the Glessner group T-2201..T-2228 with the photo-match pieces that followed. Since then it has stood open only as a scope reference, outside QUEUE.md, so `check` reported it as an open ticket missing from the queue. Nothing in tools/ or data/ hands work to it by id (the mentions are prose citations in liberties.json, a Glessner spec note and an old gate log). The children carry the work; this file keeps the scope and links.
