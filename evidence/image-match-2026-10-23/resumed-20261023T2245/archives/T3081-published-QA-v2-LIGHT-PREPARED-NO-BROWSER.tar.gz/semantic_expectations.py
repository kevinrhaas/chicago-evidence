import json
from pathlib import Path
root=Path('/tmp/T3081-published-qa-v2-20261024')
p=root/'models.json';d=json.loads(p.read_text())
for m in d['models']:
 m['photos_expectation']={'kind':'empty_unresolved_subject','empty_text':'No photograph or drawing of this building is on file yet.','reason':'Root review: Wau-Bun is a book/text inventory source; tiny panorama subject has no accepted join. Zero Photos is expected. No picture/source join invented.'} if m['id']=='cobweb_castle' else {'kind':'credited_pictures'}
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=root/'qa-published.mjs';s=p.read_text()
old="if(row.cards.photos.photo_tiles+row.cards.photos.link_only<1||!row.cards.photos.published_row_checks?.pass)row.failures.push('Photos pictures/links/credits do not match their published rows');"
new="""if(!row.cards.photos.published_row_checks?.pass)row.failures.push('Photos pictures/links/credits do not match their published rows');
  if(m.photos_expectation.kind==='empty_unresolved_subject'){
   if(row.cards.photos.photo_tiles||row.cards.photos.link_only||!row.cards.photos.text.includes(m.photos_expectation.empty_text))row.failures.push('Expected honest empty Photos state for unresolved panorama subject');
   if(!sc.text.includes(m.primary_source.citation_prefix)||!sc.links.some(x=>x.href===m.primary_source.url)||!/panorama/i.test(sc.text)||!/reconstructed/i.test(sc.text))row.failures.push('Empty Photos must retain credited Wau-Bun book URL and visible panorama/reconstruction uncertainty in Sources');
  }else if(row.cards.photos.photo_tiles+row.cards.photos.link_only<1)row.failures.push('Expected credited pictures or links are missing');"""
assert old in s;s=s.replace(old,new)
old="await page.evaluate(key=>{const r=document.getElementById('nav-app-inspect');r.querySelector('[data-insp-tab=\"'+key+'\"]')?.click();const p=r.querySelector('[data-insp-pane=\"'+key+'\"]');p?.querySelector('.ph-credit,.ph-link-list .nav-sub,summary')?.scrollIntoView({block:'center'});},key);"
new="""await page.evaluate(({key,credits,primary})=>{
    const r=document.getElementById('nav-app-inspect');r.querySelector('[data-insp-tab="'+key+'"]')?.click();const p=r.querySelector('[data-insp-pane="'+key+'"]');
    const target=key==='photos'?(p.querySelector('.ph-credit')||[...p.querySelectorAll('.ph-link-list .nav-sub')].find(n=>credits.includes(n.textContent.trim()))||p.querySelector('.nav-sub')):
     ([...p.querySelectorAll('a[href]')].find(a=>a.href===primary.url)||[...p.querySelectorAll('.cites li')].find(n=>n.textContent.includes(primary.citation_prefix))||p.querySelector('summary'));
    target?.scrollIntoView({block:'center'});
   },{key,credits:row.cards.photos.published_row_checks.expected_links.map(p=>p.credit),primary:m.primary_source});"""
assert old in s;s=s.replace(old,new)
p.write_text(s)
