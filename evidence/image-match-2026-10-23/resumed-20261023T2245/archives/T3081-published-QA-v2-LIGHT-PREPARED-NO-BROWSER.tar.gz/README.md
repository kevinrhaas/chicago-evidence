# T-3081 published QA v2 — prepared, no browser execution

This is an external helper revision, not an app/source/generator change. Original frozen 19-file packet remains untouched, manifest SHA256 `157c19c04f654ab8a3c30c7cc6bae94913ddeeb47aa438e2b14f4b6efe84f5d3`, archived in private evidence commit `11f8089fc07bf5634b08b4b7c1a65fe37f4e0dd8`. Parent owns the new base, native derivation, full preflight, publisher and full 15-part smoke. Execute neither command until parent explicitly grants the shared browser slot after those native prerequisites.

Two sequential batches, from any directory, use a new output root:

```sh
bash /tmp/T3081-published-qa-v2-20261024/run-sequential.sh published --execute-after-root-grant /tmp/T3081-actual-qa-20261024
```

This runs ten cases in order: mobile school, Cobweb, Miller, Carpenter, Wolf; then desktop in the same order. Each case starts a fresh browser/server and closes them. Each has its own actual JSON receipt, native-model/Photos/Sources screenshots and stdout file. It stops on the first failed case; inspect the failure before manually resuming another case with the exact helper arguments. No pipe hides foreground stdout. A single-case reproduction is:

```sh
PW_EXECUTABLE=/usr/bin/chromium node /tmp/T3081-published-qa-v2-20261024/qa-published.mjs --app /tmp/chicago-log-integration/chicago/4d --viewport mobile --ids chappel_infant_school --out /tmp/T3081-actual-qa-20261024/published/mobile-chappel_infant_school --execute
```

After another explicit parent grant for the five photo comparisons:

```sh
bash /tmp/T3081-published-qa-v2-20261024/run-sequential.sh pictures --execute-after-root-grant /tmp/T3081-actual-qa-20261024
```

This verifies every frozen original hash, copies the five unchanged portable cameras and source bytes to a fresh runtime input directory, then runs the native photo matcher once per target in school/Cobweb/Miller/Carpenter/Wolf order. Match files are written beside runtime copies, never into the frozen package. It retains each native byte-original bare PNG, side-by-side JPEG, source image, camera, unreviewed match and exact source/camera/GLB bindings. Carpenter remains a Sauganash-anchored two-member group. No Blender or alternate preview GLB is involved. Every camera stays provisional; inspect full source and actual plus useful details before recording honest differences. No helper accepts an image match, creates an accepted reference view or closes an original ticket.

The ten app cases measure actual published compressed web assets and HTTP response hashes, live instance bounds/placement matrices/feet, native 0.15m maximum hover ceiling, finite contact samples, burial as reported, selected phase, native stand collision and draw budget, and exact authored primary/side entry stations/widths/bearings. School width remains 1.20m; Wolf has two distinct primary/+X doors. These are exterior/contact checks and do not establish walk-through interiors or each prop's full three-dimensional clearance.

V2 corrects an overbroad prepared harness assumption using native Photos semantics. Link-only rows can have separate title, credit and holder spans, so counting all `.nav-sub` nodes as credits falsely fails valid links. Each displayed tile/link now has its expected native published-picture-row ID/credit/URL recorded and compared individually. Sources/Photos must actually be selected and visible. Held thumbnails are brought into view and must load. Errors and unfinished requests remain unfiltered, including uncategorized page/request/HTTP/cleanup errors; any fails the receipt. An existing output directory is refused.

Cobweb is intentionally different under the parent's explicit source review: `kinzie_waubun_1856` is a book/text inventory source, and the tiny panorama subject has no accepted join to this building. The actual Photos card must show exactly “No photograph or drawing of this building is on file yet.” with no tiles or links. The Sources card must retain the credited Kinzie Wau-Bun citation and its actual Authorama URL, and show the panorama/reconstruction uncertainty. The other four still require their credited pictures or links. This does not assert that a picture match exists or invent a panorama join.

The mobile context matches the native smoke: CSS 390×780, touch true, `isMobile:false`, device scale2. Desktop is CSS1280×800, scale1. Light/full detail is selected behind the native welcome before entering, to avoid paying for full-scene draws during the switch; actual frames and screenshots remain drawn. No native assertions, smoke timeouts or application code were changed.

Cost is unmeasured for this helper. It requests ten native town boots, about twenty explicitly requested town steps, thirty application screenshots, and five isolated master-camera renders with two captures each. The native smoke's historical boot comments measured mobile35–53s and desktop68–120s on steward machines; ten boots alone therefore cost roughly9–15min under those historical conditions. Reserve about20–40min for the app batch and5–15min for the picture batch, plus direct image review; slow failures can consume their existing240s boot bound. These are planning allowances, not a performance result. The source cameras are640×368,1920×1042,1920×1697,2017×1296 and1920×1697 respectively. Expect tens of MB of actual screenshots. Run no cases concurrently, and archive only a closed runtime packet through the parent's evidence writer.

Validation completed here: JS syntax for all three modules; shell syntax; authored-hash guarded dry mode over all five records; native pure `photosTab`/`creditOf` read of existing published rows (four credited link-only cases, Cobweb empty); all original19 hashes verified; LIGHT staging/source-path hash check for all five copied cameras. No browser, publish, Blender, full gate, fetch, image acceptance or canonical change was executed. Actual browser behavior remains untested and may expose further harness or app failures. The original full source/camera limitations remain in the archived v1 README.
