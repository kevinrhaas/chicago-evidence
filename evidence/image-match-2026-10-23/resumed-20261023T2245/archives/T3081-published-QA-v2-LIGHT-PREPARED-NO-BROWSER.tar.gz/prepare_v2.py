from pathlib import Path
p=Path('/tmp/T3081-published-qa-v2-20261024/qa-published.mjs')
s=p.read_text()
s=s.replace("// Prepared only. Actual execution requires root's shared browser slot after native publish.","// V2 prepared only. Frozen V1 is preserved; requires root's browser slot after native publish.")
s=s.replace("fs.mkdirSync(out,{recursive:true});", "if(fs.existsSync(out))throw Error('Refusing to overwrite existing run: '+out);\nfs.mkdirSync(out,{recursive:true});")
s=s.replace("context=await browser.newContext({viewport,deviceScaleFactor:1,isMobile:viewportName==='mobile',hasTouch:viewportName==='mobile'});", "context=await browser.newContext({viewport,deviceScaleFactor:viewportName==='mobile'?2:1,isMobile:false,hasTouch:viewportName==='mobile'});\n report.browser_context={viewport,deviceScaleFactor:viewportName==='mobile'?2:1,isMobile:false,hasTouch:viewportName==='mobile'};")
s=s.replace("const a=__chicago4d;if(!a.welcome.enter('spawn'))throw Error('welcome entry failed');", "const a=__chicago4d;await a.setDetail(detail);\n  if(!a.welcome.enter('spawn'))throw Error('welcome entry failed');")
s=s.replace("await a.setDetail(detail);a.renderer.setAnimationLoop(null);a.step();", "a.renderer.setAnimationLoop(null);a.setAnimationHold(true);a.step();")
s=s.replace("const apron=JSON.parse", "const pictures=JSON.parse(fs.readFileSync(path.join(site,'data/pictures/1835.json'),'utf8'));\n report.published_pictures_sha256=sha(fs.readFileSync(path.join(site,'data/pictures/1835.json')));\n const apron=JSON.parse")
s=s.replace("if(row.geometry.max_gap_m>.15)", "if(!row.geometry.samples.length||row.geometry.samples.some(p=>!Object.values(p).every(Number.isFinite)))row.failures.push('Nonfinite or empty actual contact samples');\n  if(row.geometry.max_gap_m>.15)")
s=s.replace("row.cards=await page.evaluate(async id=>{", "row.cards=await page.evaluate(async ({id,pictures})=>{\n   const {photosTab,creditOf}=await import('/walk/js/photos-tab.js');\n   const tab=photosTab(pictures,id,1835);if(!tab)throw Error('Published picture rows absent: '+id);\n   const expectedTiles=tab.count<=12?tab.all:tab.best;")
s=s.replace("out[key]={filled:", "out[key]={selected:root().querySelector('[data-insp-tab=\"'+key+'\"]')?.getAttribute('aria-selected'),filled:")
needle="photo_tiles:pane().querySelectorAll('.ph-item').length,link_only:pane().querySelectorAll('.ph-link-list li').length,overflow:document.documentElement.scrollWidth>innerWidth};"
replacement="""photo_tiles:pane().querySelectorAll('.ph-item').length,link_only:pane().querySelectorAll('.ph-link-list li').length,overflow:document.documentElement.scrollWidth>innerWidth};
    if(key==='photos'){
     const gotTiles=[...pane().querySelectorAll('.ph-item')],gotLinks=[...pane().querySelectorAll('.ph-link-list li')];
     out[key].published_row_checks={expected_tiles:expectedTiles.map(p=>({id:p.id,credit:creditOf(p)})),expected_links:tab.links.map(p=>({id:p.id,title:p.title,url:p.url,credit:creditOf(p)})),
      tiles:gotTiles.map((li,i)=>({id:li.dataset.photo,credit:li.querySelector('.ph-credit')?.textContent.trim()??'',expected_id:expectedTiles[i]?.id,expected_credit:expectedTiles[i]?creditOf(expectedTiles[i]):null})),
      links:gotLinks.map((li,i)=>({expected_id:tab.links[i]?.id,expected_credit:tab.links[i]?creditOf(tab.links[i]):null,expected_url:tab.links[i]?.url??null,href:li.querySelector('a')?.href??null,lines:[...li.querySelectorAll('.nav-sub')].map(n=>n.textContent.trim())}))};
     const c=out[key].published_row_checks;
     c.pass=gotTiles.length===expectedTiles.length&&gotLinks.length===tab.links.length&&
      c.tiles.every(r=>r.id===r.expected_id&&r.credit&&r.credit===r.expected_credit)&&
      c.links.every(r=>r.expected_credit&&r.lines.includes(r.expected_credit)&&(!/^https?:\\/\\//.test(String(r.expected_url??''))||r.href===new URL(r.expected_url,location.href).href));
     // Lazy thumbnails are checked only after each is actually brought into view.
     out[key].images=[];
     for(const img of pane().querySelectorAll('.ph-thumb')){
      img.scrollIntoView({block:'center'});await wait(()=>img.complete);
      out[key].images.push({src:img.currentSrc||img.src,complete:img.complete,naturalWidth:img.naturalWidth,naturalHeight:img.naturalHeight});
     }
    }"""
assert needle in s
s=s.replace(needle,replacement)
s=s.replace("},m.id);\n  for(const [key,card]", "},{id:m.id,pictures});\n  for(const [key,card]")
s=s.replace("if(card.filled!=='yes'||!card.shown||!card.text.trim()||card.overflow)", "if(card.selected!=='true'||card.filled!=='yes'||!card.shown||!card.text.trim()||card.overflow)")
old="if(row.cards.photos.photo_tiles+row.cards.photos.link_only<1||row.cards.photos.credits.length!==row.cards.photos.photo_tiles+row.cards.photos.link_only||row.cards.photos.credits.some(x=>!x))row.failures.push('Photos lacks pictures/links or explicit credit');"
new="if(row.cards.photos.photo_tiles+row.cards.photos.link_only<1||!row.cards.photos.published_row_checks?.pass)row.failures.push('Photos pictures/links/credits do not match their published rows');\n  if(row.cards.photos.images.some(x=>!x.complete||x.naturalWidth<=0||x.naturalHeight<=0))row.failures.push('Displayed picture thumbnail failed to load');"
assert old in s
s=s.replace(old,new)
p.write_text(s)
