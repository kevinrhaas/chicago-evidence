// LIGHT staging only; preserves frozen input bytes and launches no browser.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const original='/tmp/T3081-published-qa-20261023';
const manifest=JSON.parse(fs.readFileSync(path.join(original,'MANIFEST.json'),'utf8'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
if(sha(fs.readFileSync(path.join(original,'MANIFEST.json')))!=='157c19c04f654ab8a3c30c7cc6bae94913ddeeb47aa438e2b14f4b6efe84f5d3')throw Error('Frozen manifest drift');
for(const f of manifest.files){const b=fs.readFileSync(path.join(original,f.path));if(b.length!==f.bytes||sha(b)!==f.sha256)throw Error('Frozen input drift: '+f.path);}
const i=process.argv.indexOf('--out');if(i<0||!process.argv[i+1])throw Error('usage: node stage-pictures.mjs --out <NEW runtime input directory>');
const out=path.resolve(process.argv[i+1]);if(fs.existsSync(out))throw Error('Refusing existing runtime input directory');
fs.mkdirSync(out,{recursive:true});
for(const f of manifest.files.filter(f=>f.path.startsWith('cameras/portable/')||f.path.startsWith('sources/'))){
 const dest=path.join(out,f.path);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(path.join(original,f.path),dest);
}
fs.writeFileSync(path.join(out,'STAGED.json'),JSON.stringify({status:'STAGED_NOT_RENDERED',original_manifest_sha256:'157c19c04f654ab8a3c30c7cc6bae94913ddeeb47aa438e2b14f4b6efe84f5d3',files:manifest.files.filter(f=>f.path.startsWith('cameras/portable/')||f.path.startsWith('sources/'))},null,2)+'\n');
console.log(JSON.stringify({status:'STAGED_NOT_RENDERED',out},null,2));
