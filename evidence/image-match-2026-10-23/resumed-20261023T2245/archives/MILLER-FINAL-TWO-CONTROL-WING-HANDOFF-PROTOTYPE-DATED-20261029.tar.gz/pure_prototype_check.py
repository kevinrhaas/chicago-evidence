from pathlib import Path
import sys,importlib.util,json,dataclasses,copy,hashlib,datetime
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d')
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
old=load('old_log_params',P/'frozen-inputs/log_dwelling_params.py');new=load('new_log_params',P/'prototype/generators/archetypes/log_dwelling_params.py')
family=json.loads(Path('/tmp/miller-revised-three-window-closed-checkpoint-20261027T0317/evidence/BASELINE.json').read_text())['family'];proof=[]
for key,entry in family.items():
 path=A/'data/structures'/(entry['structure_id']+'.json');raw=path.read_bytes();record=json.loads(raw);phase=next(p for p in record['phases']if p['id']==entry['phase_id']);a=old.from_phase(phase,record);b=new.from_phase(phase,record);ad=dataclasses.asdict(a);bd=dataclasses.asdict(b);assert bd.pop('frame_addition_front_set_out')is None;assert bd.pop('frame_addition_roof_pitch_deg')is None;assert ad==bd,key;assert b.resolved_addition_roof_pitch_deg==a.roof_pitch_deg
 for fn in ['core_extent','addition_extent','core_front_rects','addition_front_rects','front_wall']:
  assert getattr(old,fn)(a)==getattr(new,fn)(b),(key,fn)
 assert path.read_bytes()==raw
 proof.append({'id':entry['structure_id'],'phase':entry['phase_id'],'source_sha256':hashlib.sha256(raw).hexdigest(),'params_and_five_readers_exact':True})
r=json.loads((P/'ADOPTION/miller_house.json').read_text());params=new.from_phase(r['phases'][0],r);main=new.addition_front_rects(params);core=new.core_front_rects(params)
assert len(main)==6 and sum(x[0]=='door'for x in main)==1 and sum(x[0]=='window'and x[3]>2.6 for x in main)==3
assert len(core)==2 and {x[0]for x in core}=={'door','window'}
assert new.core_extent(params)==(0.,0.,6.,6.)and new.addition_extent(params)==(6.,0.,15.,6.)
assert params.frame_addition_ridge_stack==(.4,.45,.45);assert params.roof_pitch_deg==25.0 and params.resolved_addition_roof_pitch_deg==38.0
# Actual new validator refuses malformed shapes and mutually redundant controls.
refused=[]
for name,modify in [('overlap',lambda f:f['frame_addition_front_set_out']['value'].append(copy.deepcopy(f['frame_addition_front_set_out']['value'][0]))),('badbool',lambda f:f['frame_addition_front_set_out']['value'][0].update(u0=True)),('count_and_explicit',lambda f:f.update(frame_addition_upper_windows={'value':3})),('no_door',lambda f:f['frame_addition_front_set_out']['value'].pop(0)),('no_upper_windows',lambda f:f['frame_addition_front_set_out'].update(value=[x for x in f['frame_addition_front_set_out']['value']if x['z0']<2.6])),('pitch_bool',lambda f:f.update(frame_addition_roof_pitch_deg={'value':True})),('pitch_nan',lambda f:f.update(frame_addition_roof_pitch_deg={'value':float('nan')})),('pitch_range',lambda f:f.update(frame_addition_roof_pitch_deg={'value':14}))]:
 bad=copy.deepcopy(r);modify(bad['phases'][0]['form'])
 try:new.from_phase(bad['phases'][0],bad);raise AssertionError('accepted '+name)
 except new.ParamError as e:refused.append({'name':name,'reason':str(e)})
try:
 dataclasses.replace(params,frame_addition_front_set_out=(None,)).validate();raise AssertionError('accepted malformed direct row')
except new.ParamError as e:refused.append({'name':'malformed_direct_row','reason':str(e)})
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_PURE_PROTOTYPE_ONLY','default_records':len(proof),'default_params_and_five_reader_captures':proof,'candidate_main_front':main,'candidate_core_front':core,'candidate_front_wall':new.front_wall(params),'candidate_short_ridge_flue_tuple_exact':True,'candidate_core_pitch_deg':params.roof_pitch_deg,'candidate_main_pitch_deg':params.resolved_addition_roof_pitch_deg,'invalid_optins_refused':refused,'geometry_vertices_default_parity':'UNRUN','candidate_native_mesh_and_image':'UNRUN','primary_source_write':False};(P/'PURE-PROTOTYPE-RESULT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'defaults':len(proof),'readers_per_record':5,'main_rectangles':len(main),'core_rectangles':len(core),'invalid_refused':len(refused),'status':out['status']}))
