from pathlib import Path
import sys,importlib.util,json,hashlib
P=Path('/tmp/Miller-next-wing-investigation-20261029');A=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(A/'generators'));import emit
for name in ['log_dwelling_params','log_dwelling']:
 fullname='archetypes.'+name;s=importlib.util.spec_from_file_location(fullname,P/'prototype/generators/archetypes'/(name+'.py'));m=importlib.util.module_from_spec(s);sys.modules[fullname]=m;s.loader.exec_module(m)
params=sys.modules['archetypes.log_dwelling_params'];arch=sys.modules['archetypes.log_dwelling'];emit.ARCHETYPES['log_dwelling']=(params.from_phase,arch.build)
r=json.loads((P/'CANDIDATE-UNSUPPORTED-UNTIL-KIT-CHANGE.json').read_text());out=P/'pilot-app/assets/gltf/miller_house__log_frame_1827.glb';out.parent.mkdir(parents=True,exist_ok=True)
made=emit.emit_structure(r,r['phases'][0],'log_dwelling',out,bake=True,ao=False);assert out.exists();(P/'PILOT-MADE.json').write_text(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'native':'emit.emit_structure with external prototype archetype; external asset only; no manifest/source writes'},indent=2)+'\n')
