### L-miller-adjacent-wing-2381 — the pictured lower wing and independent roof

**Covers:** `miller_house.log_frame_1827.footprint`, `miller_house.log_frame_1827.position`, `miller_house.log_frame_1827.form.frame_addition_side`, `miller_house.log_frame_1827.form.front_set_out`, `miller_house.log_frame_1827.form.frame_addition_front_set_out`, `miller_house.log_frame_1827.form.roof_pitch_deg`, `miller_house.log_frame_1827.form.frame_addition_roof_pitch_deg`.

**Decision:** Read the low cabin beside the tall range rather than wholly behind it. Pictured adjacent form and visible opening counts rest on the cleared1867 retrospective1833 lithograph. The15x6 m rectangle,6x6 m core,9x6 m range, low door/window stations and pitches are reconstructed. Declared area changes84→90m2; generated wall-plan area99→90m2. The local-origin countertranslation(-6,+5)m keeps the main wall box and six front apertures at their previous world locations. It does not preserve every main-roof endpoint: the existing END route trims0.26m at the buried joint and shifts the same fractional short-flue station0.156m. Those below-foot changes do not claim exact historic joinery.

The core uses a reconstructed25-degree first fit because the clearer drawings consistently show less relative rise on that lower roof. The main addition retains38 degrees with a separate default-None control; its ridge-flue foot uses that same resolved pitch. Neither angle is measured from the picture. Unknown camera controls or an unresolved low chimney are not independent open differences. The actual earlier38-degree-core side-wing pilot fixed the missing wing but did not certify this final25-degree proposal; the final native production/capture must do that.

**Source and limits:** `blanchard_shober_1867_wolf_point`, existing cleared NYPL surrogate. Other held variants are comparative inspection, not independent measured witnesses or new rights grants. The later drawing is not proof of an unchanged July1835 condition, and fronting the river does not attest that one block stood physically ahead of the other. The low core's retained inferred stack is not visibly resolved well enough to establish absence.

**Ticket:** T-2381.

**Recorded:** 2026-10-29.

Adoption note: the earlier L-miller-frame-ridge-stack-2381 Covers still names the replaced `frame_addition_upper_windows`. Preserve its complete historical decision text, migrate that obsolete Covers reference consistently to the explicit front-set-out field (or retain only its still-live ridge-stack coverage with an appended explanation), following the repository's existing cover-migration practice. Do not silently erase the earlier inference. Compile the actual liberty registry after that reconciliation; no liberty compilation has run in this packet.
