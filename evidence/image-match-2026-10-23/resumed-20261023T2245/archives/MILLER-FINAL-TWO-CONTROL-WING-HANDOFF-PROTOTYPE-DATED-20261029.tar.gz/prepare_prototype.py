from pathlib import Path
import shutil
P=Path(__file__).resolve().parent;D=P/'prototype/generators/archetypes';D.mkdir(parents=True,exist_ok=True)
s=(P/'frozen-inputs/log_dwelling_params.py').read_text()
def replace(old,new):
 global s
 assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new)
replace('"frame_addition_upper_windows",','"frame_addition_upper_windows", "frame_addition_front_set_out", "frame_addition_roof_pitch_deg",')
replace('    frame_addition_upper_windows: int | None = field(default=None, kw_only=True)','    frame_addition_upper_windows: int | None = field(default=None, kw_only=True)\n    # Opt-in front rectangles of the frame range, local to its own x origin.\n    frame_addition_front_set_out: tuple | None = field(default=None, kw_only=True)\n    frame_addition_roof_pitch_deg: float | None = field(default=None, kw_only=True)')
replace('    @property\n    def addition_height_m(self) -> float:', '''    @property
    def resolved_addition_roof_pitch_deg(self) -> float:
        return self.roof_pitch_deg if self.frame_addition_roof_pitch_deg is None else self.frame_addition_roof_pitch_deg

    @property
    def addition_height_m(self) -> float:''')
replace('        if self.frame_addition_upper_windows is not None:\n','''        if self.frame_addition_roof_pitch_deg is not None:
            v = self.frame_addition_roof_pitch_deg
            if not self.frame_addition or isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not 15 <= v <= 55:
                raise ParamError("frame_addition_roof_pitch_deg needs an addition and a finite15..55 degree pitch")
        if self.frame_addition_front_set_out is not None:
            if not self.frame_addition or self.frame_addition_side != "end" or self.frame_addition_stories != 2:
                raise ParamError("frame_addition_front_set_out needs a two-storey end addition")
            if self.frame_addition_upper_windows is not None:
                raise ParamError("use either explicit frame front set-out or upper count, never both")
            spec = self.frame_addition_front_set_out
            if not isinstance(spec, tuple) or not 1 <= len(spec) <= 12:
                raise ParamError("frame_addition_front_set_out needs 1..12 rectangles")
            for row in spec:
                if not isinstance(row, (tuple, list)) or len(row) != 5 or row[0] not in ("window", "door"):
                    raise ParamError("frame front rectangle is (kind,u0,u1,z0,z1)")
                kind, u0, u1, z0, z1 = row
                if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in row[1:]):
                    raise ParamError("frame front rectangle needs finite numeric coordinates")
                if not 0.15 <= u0 < u1 <= self.frame_addition_width_m-0.15 or not 0 <= z0 < z1 <= self.addition_height_m-0.15:
                    raise ParamError("frame front rectangle exceeds wall bounds")
                if kind == "door" and (z0 > 0.05 or z1 > self.addition_height_m/2-0.15):
                    raise ParamError("frame front door must stand on ground below upper floor")
            for story in range(2):
                lo, hi = story*self.addition_height_m/2, (story+1)*self.addition_height_m/2
                if not any(row[0] == "window" and lo <= row[3] < row[4] <= hi for row in spec):
                    raise ParamError("explicit frame front needs a window band in each storey")
            if sum(row[0] == "door" for row in spec) != 1:
                raise ParamError("explicit frame front needs one ground door")
            for i, a in enumerate(spec):
                for b in spec[i+1:]:
                    if max(a[3],b[3]) < min(a[4],b[4]) and max(a[1]-b[2],b[1]-a[2]) < 0.15:
                        raise ParamError("frame front rectangles overlap or lack pier clearance")
        if self.frame_addition_upper_windows is not None:
''')
replace('        if self.stories != 1 or self.frame_addition:\n','        if self.stories != 1 or (self.frame_addition and self.frame_addition_side != "end"):\n')
replace('        frame_addition_upper_windows=val("frame_addition_upper_windows"),','''        frame_addition_upper_windows=val("frame_addition_upper_windows"),
        frame_addition_roof_pitch_deg=val("frame_addition_roof_pitch_deg"),
        frame_addition_front_set_out=(None if val("frame_addition_front_set_out") is None else
            tuple((o["kind"], o["u0"], o["u1"], o["z0"], o["z1"])
                  for o in val("frame_addition_front_set_out"))),''')
replace('    ax0, _ay0, ax1, _ay1 = addition_extent(p)\n    az = p.addition_height_m','''    ax0, _ay0, ax1, _ay1 = addition_extent(p)
    if p.frame_addition_front_set_out is not None:
        return [(kind, ax0+u0, ax0+u1, z0, z1)
                for kind,u0,u1,z0,z1 in p.frame_addition_front_set_out]
    az = p.addition_height_m''')
replace('            u1 = p.width_m\n    openings =','''            u1 = p.width_m
            if p.frame_addition_front_set_out is not None:
                # Bounding envelope of the explicitly mixed-height front.
                top = max(top, p.addition_height_m)
    openings =''')
(D/'log_dwelling_params.py').write_text(s)
s=(P/'frozen-inputs/log_dwelling.py').read_text();old='            z0, z1 = front_rects[2 * story][3:]';new='''            if p.frame_addition_front_set_out is None:
                z0, z1 = front_rects[2 * story][3:]
            else:
                lo, hi = story*p.addition_height_m/p.frame_addition_stories, (story+1)*p.addition_height_m/p.frame_addition_stories
                rect = next(r for r in front_rects if r[0] == "window" and lo <= r[3] < r[4] <= hi)
                z0, z1 = rect[3:]''';assert s.count(old)==1;s=s.replace(old,new);assert s.count('az, p.roof_pitch_deg, c, M_ROOF,') == 1
s=s.replace('az, p.roof_pitch_deg, c, M_ROOF,','az, p.resolved_addition_roof_pitch_deg, c, M_ROOF,')
assert s.count('foot = add_ridge_z - half * math.tan(math.radians(p.roof_pitch_deg)) - 0.25') == 1
s=s.replace('foot = add_ridge_z - half * math.tan(math.radians(p.roof_pitch_deg)) - 0.25','foot = add_ridge_z - half * math.tan(math.radians(p.resolved_addition_roof_pitch_deg)) - 0.25')
(D/'log_dwelling.py').write_text(s)
(D/'__init__.py').write_text('');shutil.copytree('/workspace/chicago/chicago/4d/generators/common',D.parent/'common',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
print('External prototype only; no source write')
