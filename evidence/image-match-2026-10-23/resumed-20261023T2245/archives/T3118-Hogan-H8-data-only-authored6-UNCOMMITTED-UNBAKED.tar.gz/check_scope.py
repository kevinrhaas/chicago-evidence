import sys,json,hashlib,copy
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/workspace/chicago/chicago/4d');O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'generators'));import mesh_inputs
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((O/'before-receipt.json').read_text());changed=[]
for p,h in base['code_preimages'].items():assert sha(R/p)==h,p
for row in base['family']:
 p=R/row['record'];r=json.loads(p.read_text());ph=next(x for x in r['phases'] if row['asset']==r['id']+'__'+x['id']+'.glb')
 current=mesh_inputs.structure_inputs_sha(r,ph)
 if current!=row['input_sha256']:changed.append({'asset':row['asset'],'before':row['input_sha256'],'candidate':current})
 if r['id']!='hogan_store':assert sha(p)==row['record_sha256'],str(p)
 assert sha(R/'assets/gltf'/row['asset'])==row['master_sha256']
 assert sha(R/'assets/web'/row['asset'])==row['web_sha256']
assert len(changed)==1 and changed[0]['asset']=='hogan_store__log_1831.glb'
old=json.loads((O/'before/data/structures/hogan_store.json').read_text());new=json.loads((R/'data/structures/hogan_store.json').read_text())
oldph=copy.deepcopy(old);newph=copy.deepcopy(new)
for d in [oldph,newph]:d['phases'][0].pop('form')
assert oldph==newph,'non-form Hogan data changed'
of=old['phases'][0]['form'];nf=new['phases'][0]['form']
assert {k for k in of.keys()|nf.keys() if of.get(k)!=nf.get(k)}=={'door_w_m','end_openings','chimneys','ridge_stack_w_m','front_door_state','ridge_stack_head_m'}
for k in ['door_w_m','chimneys','ridge_stack_w_m']:
 a=copy.deepcopy(of[k]);b=copy.deepcopy(nf[k]);a.pop('note');b.pop('note');assert a==b
from archetypes.log_dwelling_params import from_phase,ParamError
p=from_phase(new['phases'][0],new);p.validate()
negative=0
for attr,value in [('front_door_state','open'),('ridge_stack_head_m',0.1)]:
 bad=copy.deepcopy(new);bad['phases'][0]['form'][attr]['value']=value
 try:from_phase(bad['phases'][0],bad).validate()
 except ParamError:negative+=1
 else:raise AssertionError('invalid candidate accepted: '+attr)
source=R/'data/sources/cameron_c1900_first_post_office.json'
assert sha(source)==base['snapshot_sha256'][str(source.relative_to(R))]
s=json.loads(source.read_text());assert s['rights_status']=='public_domain' and s['asset_use']=='cross_check'
assert 'not been independently established' in s['rights_note']
assert (R/'docs/LIBERTIES.md').read_bytes().startswith((O/'before/docs/LIBERTIES.md').read_bytes())
report={'status':'PASS light scope only','base':base['head'],'log_family':len(base['family']),'unchanged_non_target_recipes':len(base['family'])-1,'changed_recipe':changed,'all_current_master_web_bytes_preserved_until_bake':True,'all_generator_common_pipeline_code_exact':len(base['code_preimages']),'non_form_data_exact':True,'negative_parameter_controls':negative,'source_record_exact':sha(source),'source_admission':'Existing attributed public-domain inventory surrogate; retrospective1833appearance, no new clearance, scale/location/July1835 continuity claim or image-pixel texture. Original publication and holding remain independently unverified.','limits':'No official build/derivative/native full acceptance/browser/gates. H8 depends on PR1260 merge; original T2377 differs.'}
(O/'scope-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
