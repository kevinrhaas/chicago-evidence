"""Record actual generator streams; only Blender emission/material creation replaced."""
import sys, json, hashlib
from pathlib import Path
from types import ModuleType
sys.dont_write_bytecode=True
root=Path(sys.argv[1]); record=Path(sys.argv[2]); out=Path(sys.argv[3])
sys.path.insert(0,str(root/'generators'));sys.modules['bpy']=ModuleType('bpy')
from archetypes import log_dwelling as b
from archetypes.log_dwelling_params import from_phase
from common.mesh import MeshBuilder
class Raw(MeshBuilder):
    def to_object(self,mats=None): self.materials=mats;return self
b.MeshBuilder=Raw;b.simple_material=lambda *args,**kwargs:(args,kwargs)
r=json.loads(record.read_text());p=from_phase(r['phases'][0],r);p.validate()
obj=b.build(p,'hogan_store__log_1831')
raw=[obj.verts,obj.faces,obj.conf,obj.mat_index,obj.named,obj.materials]
out.write_text(json.dumps(raw,sort_keys=True)+'\n')
print(json.dumps({'raw_sha256':hashlib.sha256(json.dumps(raw,sort_keys=True).encode()).hexdigest(),'vertices':len(obj.verts),'faces':len(obj.faces),'triangles':sum(len(f)-2 for f in obj.faces)}))
