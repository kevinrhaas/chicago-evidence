from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal,zlib,urllib.request,urllib.parse
os.sched_setaffinity(0,{3});os.nice(19)
B=Path(__file__).parent; C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');P=Path('/workspace/T2382-currentdev-integration-20261026/upstream-T3175-894f')
OLD='4220f39bc160816f2fc716606d854c0c9ad7bc05';FEATURE='894f14a209623a6ea404a792f3f1a9a718312c91';TIP='6c103072dae94ed58cc8fc06462aef2638be736f';TREE='f920b03fc345303ef3e2b8104ad15703552de27a';ENV=32*1024**2;FLOOR=128*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(r,*args,input=None):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,o):(B/n).write_text(json.dumps(o,indent=2)+'\n')
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():
 return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:sha(G/n)for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
before=snap();save('SOURCE-BEFORE.json',before);assert git(C,'rev-parse','origin/dev').decode().strip()==OLD
fresh=api('git/ref/heads/dev');save('REMOTE-AT-START.json',fresh);assert fresh['object']['sha']==TIP,('Tipmoved',fresh['object']['sha'])
fc=api('git/commits/'+FEATURE);tc=api('git/commits/'+TIP);assert[p['sha']for p in fc['parents']]==[OLD];assert[p['sha']for p in tc['parents']]==[FEATURE]and tc['tree']['sha']==TREE
save('FEATURE-COMMIT.json',fc);save('TIP-COMMIT.json',tc)
compare=api('compare/'+FEATURE+'...'+TIP);save('FOLD-COMPARE.json',compare);assert{(f['filename'],f['status'])for f in compare['files']}=={('chicago/4d/changelog.d/T-3175.json','removed'),('chicago/4d/renderers/web/js/changelog.js','modified')}
tree=api('git/trees/'+TREE+'?recursive=1');assert not tree.get('truncated');save('TIP-RECURSIVE-TREE.json',tree);leaves=[r for r in tree['tree']if r['type']!='tree'];blobrows=[r for r in leaves if r['type']=='blob'];foldrow=next(r for r in blobrows if r['path']=='chicago/4d/renderers/web/js/changelog.js');assert foldrow['sha']=='8c0a9bde2ef0437133caab3d1df80ef41dc3cacf'
price=json.loads((P/'EXACT-BLOB-PRICE.json').read_text());assert price['new_raw_bytes']==22159673 and price['tip']==FEATURE
shutil.copy2(P/'EXACT-BLOB-PRICE.json',B/'FEATURE-EXACT-BLOB-PRICE.json');shutil.copy2(P/'UNINTENDED-EXACT-BLOB-IMPORT-RECEIPT.json',B/'PRIOR-UNINTENDED-EXACT-BLOB-IMPORT-RECEIPT.json')
# Only isolated, filtered immutable metadata fetch. Never source-common fetch.
assert shutil.disk_usage('/tmp').free>=1024**3
with(B/'metadata-fetch.log').open('xb')as log:
 p=subprocess.Popen(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',TIP],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);abort=None;peak=0
 while p.poll()is None:
  size=sum(f.stat().st_size for f in(R/'objects').rglob('*')if f.is_file());peak=max(peak,size)
  if size>32*1024**2 or b'filtering not recognized'in(B/'metadata-fetch.log').read_bytes().lower():abort='isolation/filter bound';os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(.15)
 rc=p.wait()
save('METADATA-FETCH.json',{'exit':rc,'peak_bytes':peak,'abort':abort});assert rc==0 and not abort
actual={}
for row in git(R,'ls-tree','-r','-z',TIP).split(b'\0'):
 if row:
  a,name=row.split(b'\t',1);mode,kind,obj=a.decode().split();actual[name.decode()]={'mode':mode,'type':kind,'sha':obj}
assert actual=={r['path']:{k:r[k]for k in ['mode','type','sha']}for r in leaves}
# No-lazy-fetch is mandatory (Git2.52 supports it); availability is never inferred from a fetching cat-file.
def checks(repo,ids):
 lines=git(repo,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();return dict(zip(ids,lines))
meta={};packs=[]
for pack in sorted((R/'objects/pack').glob('*.pack')):
 if(G/'objects/pack'/pack.name).exists():continue
 ids=[]
 for line in git(R,'verify-pack','-v',str(pack.with_suffix('.idx'))).decode().splitlines():
  c=line.split()
  if len(c)>4 and len(c[0])==40 and c[1]in ['commit','tree','tag','blob']:assert c[1]!='blob';ids.append(c[0])
 local=checks(C,ids);canonical=checks(R,ids)
 for obj in ids:
  if local[obj].endswith(' missing'):
   objid,kind,size=canonical[obj].split();meta[obj]={'kind':kind,'canonical_bytes':int(size)}
 packs.append(pack)
featurechecks=checks(C,[r['sha']for r in price['blobs']]);assert all(not x.endswith(' missing')for x in featurechecks.values()),'Priced14payloadnotlocal'
for row in price['blobs']:assert int(featurechecks[row['sha']].split()[2])==row['bytes']
fold_missing=checks(C,[foldrow['sha']])[foldrow['sha']].endswith(' missing');canonical_total=price['new_raw_bytes']+foldrow['size']+sum(r['canonical_bytes']for r in meta.values());assert canonical_total<=ENV
save('CANONICAL-RAW-OBJECT-PRICE.json',{'already_imported_feature_blobs_raw':price['new_raw_bytes'],'fold_blob':foldrow,'fold_missing':fold_missing,'new_metadata_objects':meta,'canonical_raw_envelope_total':canonical_total,'envelope':ENV,'workspace_free':shutil.disk_usage('/workspace').free,'no_source_writes_yet':True})
if os.environ.get('PRICE_ONLY')=='1':print('PRICE_ONLY_READY',canonical_total);raise SystemExit(0)
assert shutil.disk_usage('/workspace').free>=FLOOR+ENV,'Workspacecapacityguard'
assert snap()==before,'Sourcechangedbeforeimport'
allocation=0;imported=[]
for pack in packs:
 data=pack.read_bytes();assert hashlib.sha1(data[:-20]).digest()==data[-20:]
 for src in [pack,pack.with_suffix('.idx'),pack.with_suffix('.promisor')]:
  if not src.exists():continue
  dest=G/'objects/pack'/src.name;assert not dest.exists();tmp=dest.with_name('.'+dest.name+'.bounded894-'+str(os.getpid()));shutil.copy2(src,tmp);assert sha(src)==sha(tmp);tmp.rename(dest);allocation+=dest.stat().st_blocks*512;imported.append({'name':src.name,'bytes':src.stat().st_size,'sha256':sha(src)})
save('PACK-IMPORT.json',imported)
if fold_missing:
 with urllib.request.urlopen('https://raw.githubusercontent.com/kevinrhaas/chicago/'+TIP+'/'+foldrow['path'],timeout=90)as response:data=response.read(foldrow['size']+65536)
 raw=b'blob '+str(len(data)).encode()+b'\0'+data;assert len(data)==foldrow['size']and hashlib.sha1(raw).hexdigest()==foldrow['sha'];dest=G/'objects'/foldrow['sha'][:2]/foldrow['sha'][2:];assert not dest.exists();dest.parent.mkdir(exist_ok=True);tmp=dest.with_name(dest.name+'.bounded894-'+str(os.getpid()));encoded=zlib.compress(raw);tmp.write_bytes(encoded);assert hashlib.sha1(zlib.decompress(tmp.read_bytes())).hexdigest()==foldrow['sha'];tmp.rename(dest);allocation+=dest.stat().st_blocks*512;save('FOLD-BLOB-IMPORT.json',{'path':foldrow['path'],'sha':foldrow['sha'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoded_bytes':len(encoded)})
ids=sorted({r['sha']for r in blobrows});allchecks=checks(C,ids);assert not any(x.endswith(' missing')for x in allchecks.values());assert all(int(allchecks[r['sha']].split()[2])==r['size']for r in blobrows);assert git(C,'rev-parse',TIP+'^{tree}').decode().strip()==TREE;assert git(C,'merge-base',TIP,OLD).decode().strip()==OLD;assert snap()==before
remote=api('git/ref/heads/dev');save('REMOTE-BEFORE-CAS.json',remote);cas=remote['object']['sha']==TIP
assert shutil.disk_usage('/workspace').free>=FLOOR
if cas:git(C,'update-ref','refs/remotes/origin/dev',TIP,OLD)
after=snap();save('SOURCE-AFTER.json',after);assert after['metadata']==before['metadata']and after['HEAD']==before['HEAD']and after['status_sha256']==before['status_sha256'];assert after['refs']==([x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+TIP)for x in before['refs']]if cas else before['refs'])
result={'status':'EXACT_DOANE894_GENUINE_FOLD6C10_BOUNDED_IMPORT_EXPECTED_OLD_CAS_PASS'if cas else'EXACT_OBJECTS_READY_REMOTE_MOVED_NO_CAS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old':OLD,'feature':FEATURE,'tip':TIP,'tree':TREE,'canonical_raw_including_prior_payloads':canonical_total,'envelope':ENV,'new_source_allocated_bytes':allocation,'all_tip_unique_blobs_verified':len(ids),'cached_origin_dev':git(C,'rev-parse','origin/dev').decode().strip(),'fresh_remote_dev':remote['object']['sha'],'source_HEAD_index_config_merge_status_unchanged':True,'other_refs_unchanged':True,'source_HEAD':before['HEAD'],'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free,'no_source_common_fetch_gc_repack_worktree_edit':True,'prior_unintended_14_payload_import_disclosed_separately':True};save('RESULT.json',result);print(json.dumps(result,indent=2))
