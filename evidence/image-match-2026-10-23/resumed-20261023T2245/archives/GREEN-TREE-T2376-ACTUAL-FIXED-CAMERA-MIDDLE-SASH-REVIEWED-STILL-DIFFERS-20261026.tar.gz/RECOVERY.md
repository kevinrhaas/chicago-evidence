# Green Tree: actual middle-sash comparison reviewed

This packet supplements durable456 native/WIP checkpoint b00403df. Its all21-source archive is the complete current working state on public basea9c5 and includes the untracked release entry, genuine selected master/WEB, both registries and the new canonical side-by-side. Every member has hash/size/mode in CURRENT21-SOURCE-INVENTORY.json.

The native photo command passed and all four children were reaped. The original drawing and provisional camera are byte-exact to the earlier comparison. Actual before/after review shows the central lower door replaced by the seventh sash; that bounded discrepancy is fixed. The whole registered verdict is DIFFERS, with enclosed-annex massing still OPEN. Gray’s later entrance recollection remains counterevidence; no exact July1835 absence or original ticket completion is claimed.

No current global/native/preflight or published-app pass is claimed. Final integration and checks wait for ROOT checkedCarpenter, preserving all upstream work and reusing this genuine target bake only if its exact recipe remains38d1d02c87618a7a6af8b67bef60a97f3c8a72e3bfc3a882802040ea1c04167d.
