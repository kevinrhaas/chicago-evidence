"""Run under Blender only after current clean-dev snapshots and explicitly leased GT adoption."""
from pathlib import Path
import datetime,hashlib,json,os,sys,time
assert os.environ.get('GT_NATIVE_READY')=='leased-current-authored-source-adopted','Require explicit final source writer lease'
r=Path(os.environ['GT_NATIVE_REPO_ROOT']).resolve();a=r/'chicago/4d';f=Path(os.environ['GT_NATIVE_BEFORE']).resolve();out=Path(os.environ['GT_NATIVE_OUT']).resolve();assert not out.exists() and r not in out.parents;out.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs=json.loads((f/'INPUTS.json').read_text());assert inputs['status']=='ACTUAL_CURRENT_CLEAN_PRE_GT_DEFAULTS_CAPTURED_NO_GT_NATIVE_PASS' and inputs['repo']==str(r)
sys.path.insert(0,str(a/'generators'));import emit
rows=[]
for e in inputs['rows']:
 old=f/e['record_snapshot'];master=f/e['master_snapshot'];assert sha(old)==e['record_sha256'] and sha(master)==e['master_sha256'];st=json.loads(old.read_text());ph=next(x for x in st['phases']if x['id']==e['phase']);dest=out/'None-controls'/e['control_asset'];dest.parent.mkdir(exist_ok=True);emit.emit_structure(st,ph,'frame_tavern',dest,bake=True,ao=False);assert dest.read_bytes()==master.read_bytes(),'Current producer default changed '+e['control_asset'];rows.append({'asset':e['control_asset'],'sha256':sha(dest),'bytes':dest.stat().st_size,'actual_current_native_pre_GT_default_exact':True})
# This uses complete pre-adoption records. In particular the old GT rear_ell is NOT
# taken from the intentionally changed canonical record, and no field is toggled.
for e in inputs['rows']:
 if e['id']!='green_tree_tavern':assert sha(a/e['record_path'])==e['record_sha256'],'Foreign record changed since capture'
ids=sorted({e['id']for e in inputs['rows']});import build
sys.argv=['blender','--','--only',','.join(ids),'--wrote',str(out/'PRODUCTION-WROTE.txt')];t=time.monotonic();assert build.main()==0;seconds=time.monotonic()-t
for e in inputs['rows']:
 if e['id']!='green_tree_tavern':assert sha(a/e['master_path'])==e['master_sha256'],'Foreign native master changed '+e['master_path']
candidates=[]
for path in ['assets/gltf/green_tree_tavern__frame_1833.glb','assets/gltf/versions/green_tree_tavern/andreas-reading/green_tree_tavern__frame_1833.glb']:
 q=a/path;candidates.append({'path':path,'sha256':sha(q),'bytes':q.stat().st_size})
result={'status':'ACTUAL_CURRENT25_NONE_CONTROLS_AND23_ID_NATIVE_PRODUCTION_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pre_GT_head':inputs['head'],'pre_GT_inputs_sha256':sha(f/'INPUTS.json'),'repo':str(r),'production_seconds':seconds,'rows':rows,'all24_other_official_masters_unchanged':True,'candidates':candidates,'limits':'No WEB/photo/feet/owner-tail/publish/BOTH/phone/source-gate/PR/devmerge/ticket-completion claim. Outer reaper must separately close Blender children.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='rows'}))
