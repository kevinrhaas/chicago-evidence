#!/usr/bin/env python3
"""Read-only repositories; write candidate authored postimages only into a new external output."""
from pathlib import Path
import argparse,copy,datetime,hashlib,json,os,subprocess
BASE='7c5f2109cc1db6a86e23d76b4127385b587adcee'
OWN=Path('/tmp/chicago-green-tree-integration')
SAVED=Path('/workspace/T2376-current-source-checkpoint-20261029/SOURCE-STATE.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(b):
 def unique(pairs):
  d={}
  for k,v in pairs:
   if k in d:raise AssertionError('Duplicate JSON key '+k)
   d[k]=v
  return d
 return json.loads(b,object_pairs_hook=unique)
def git(root,*args):
 env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
 return subprocess.check_output(['git','-C',str(root),*args],env=env)
def keyed(v):
 if not isinstance(v,list):return None
 if all(isinstance(x,dict) and all(k in x for k in ('scene','structure','picture'))for x in v):
  out={tuple(x[k]for k in ('scene','structure','picture')):x for x in v}
  assert len(out)==len(v),'Duplicate grade row'
  return out
 return None
def union(b,o,c,path=''):
 if o==b:return copy.deepcopy(c)
 if c==b or c==o:return copy.deepcopy(o)
 if isinstance(b,dict) and isinstance(o,dict) and isinstance(c,dict):
  r=copy.deepcopy(c)
  for k in set(b)|set(o):
   p=path+'/'+str(k)
   if k in b and k not in o:
    assert k not in c or c[k]==b[k],'Shared deletion collision '+p
    r.pop(k,None)
   elif k not in b:
    assert k not in c or c[k]==o[k],'Shared addition collision '+p
    r[k]=copy.deepcopy(o[k])
   elif o[k]!=b[k]:
    assert k in c,'Shared missing key '+p
    r[k]=union(b[k],o[k],c[k],p)
  return r
 bm,om,cm=keyed(b),keyed(o),keyed(c)
 if bm is not None and om is not None and cm is not None:
  result=union(bm,om,cm,path)
  order=[tuple(x[k]for k in ('scene','structure','picture'))for x in c]
  order +=[k for k in om if k not in cm]
  return[result[k]for k in order if k in result]
 raise AssertionError('Shared leaf collision '+path)
def main():
 p=argparse.ArgumentParser();p.add_argument('--target',required=True);p.add_argument('--expected-head',required=True);p.add_argument('--out',required=True);a=p.parse_args()
 target=Path(a.target).resolve();out=Path(a.out).resolve();assert not out.exists(),'Output must be new'
 assert target!=out and target not in out.parents and OWN not in out.parents,'Output must be outside both repos'
 head=git(target,'rev-parse','HEAD').decode().strip();assert head==a.expected_head,(head,a.expected_head)
 paths=[x['path']for x in load(SAVED.read_bytes())['source_files']]
 excluded=[x for x in paths if x.startswith('chicago/4d/assets/') or x.startswith('chicago/4d/data/sidecars/') or x in ['chicago/4d/data/frontage/green_tree_frontage.json','chicago/4d/data/liberties.json','chicago/prairie_1904_v1/data/images.json']]
 paths=[x for x in paths if x not in excluded]
 paths +=['chicago/4d/data/reference_views/green_tree_tavern/trowbridge_1902.match.json','chicago/4d/docs/RESEARCH/green-tree-annex-T-2376/andreas-reading.match.json','chicago/4d/data/reconstruction/name_pool_keys.json']
 base_rows={}
 for line in git(OWN,'ls-tree','-r',BASE,'--',*paths).decode().splitlines():
  meta,path=line.split('\t');mode,kind,obj=meta.split();assert kind=='blob';base_rows[path]=(mode,obj)
 before={};own_before={};candidates=[];decisions=[]
 for path in paths:
  own=OWN/path;cur=target/path;assert own.is_file() and not own.is_symlink(),path
  ob=own.read_bytes();cb=cur.read_bytes()if cur.exists()else None
  assert not cur.is_symlink(),path
  bb=git(OWN,'cat-file','blob',base_rows[path][1])if path in base_rows else None
  before[path]=sha(cb)if cb is not None else None;own_before[path]=sha(ob)
  if cb==bb or cb==ob:
   result=ob;decision='OWN_ONLY_OR_ALREADY_PRESENT_EXACT'
  elif path.endswith('/docs/LIBERTIES.md'):
   assert bb is not None and ob.startswith(bb),'Own Liberty history prefix changed'
   suffix=ob[len(bb):];result=cb if cb.endswith(suffix) else cb+suffix;assert result.startswith(cb)
   decision='CURRENT_FULL_PREFIX_PRESERVED_OWN_APPEND_ONLY_SUFFIX'
  elif path.endswith('/structure_grades.json'):
   result=(json.dumps(union(load(bb),load(ob),load(cb)),ensure_ascii=False,indent=2)+'\n').encode();decision='KEYED_SCENE_STRUCTURE_PICTURE_THREE_WAY_UNION'
  elif path.endswith('/name_pool_keys.json'):
   b,o,c=load(bb),load(ob),load(cb);k='phases[].form.enclosed_left_annex.note'
   assert o['read']['structures']==b['read']['structures']+[k]
   old=copy.deepcopy(o);old['read']['structures'].remove(k);assert old==b,'Unexpected own name-pool edit'
   d=copy.deepcopy(c)
   if k not in d['read']['structures']:d['read']['structures'].append(k)
   result=(json.dumps(d,indent=2)+'\n').encode();decision='ONE_READ_KEY_ADDED_ALL_CURRENT_DECLARATIONS_PRESERVED'
  elif path.endswith('/STORE.json'):
   b,o,c=load(bb),load(ob),load(cb)
   assert set(b)==set(o)==set(c),'Unexpected STORE shape'
   bb2=copy.deepcopy(b);oo2=copy.deepcopy(o);cc2=copy.deepcopy(c)
   for d in [bb2,oo2,cc2]:d.pop('bytes')
   d=union(bb2,oo2,cc2);d['bytes']=sum(x['bytes']for x in d['files'].values())
   result=(json.dumps(d,ensure_ascii=True,indent=1)+'\n').encode();decision='STORE_PER_FILE_COLLISION_REFUSAL_CURRENT_ROWS_RETAINED_TOTAL_RECALCULATED'
  else:raise AssertionError('Unexpected overlapping source path '+path)
  candidates.append((path,result));decisions.append({'path':path,'base_sha256':sha(bb)if bb else None,'own_sha256':sha(ob),'current_sha256':before[path],'candidate_sha256':sha(result),'bytes':len(result),'decision':decision,'git_mode':base_rows.get(path,('100644',None))[0]})
 # Exact source reads and head must remain stable. No staging/config/ref/source mutation occurs here.
 assert git(target,'rev-parse','HEAD').decode().strip()==head,'Target head moved; rebind after merge'
 for path in paths:
  cur=target/path;assert(sha(cur.read_bytes())if cur.exists()else None)==before[path],path+' current changed during read'
  assert sha((OWN/path).read_bytes())==own_before[path],path+' own changed during read'
 protected=[]
 for name in ['frame_dwelling.py','frame_dwelling_params.py','log_dwelling.py','log_dwelling_params.py']:
  path='chicago/4d/generators/archetypes/'+name;assert path not in paths;protected.append({'path':path,'sha256':sha((target/path).read_bytes()),'adoption':'RETAIN_CURRENT_VERBATIM_NO_GT_EDIT'})
 out.mkdir(mode=0o700,parents=False)
 for path,b in candidates:
  dst=out/'postimages'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);dst.chmod(0o644)
 result={'status':'READ_ONLY_AUTHORED_SOURCE_UNION_CANDIDATES_NO_ADOPTION_OR_GENERATED_PROOF','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'own_base':BASE,'observed_target_head':head,'target':str(target),'candidate_count':len(candidates),'rows':decisions,'protected_producers':protected,'excluded_generated_source_state_paths':excluded,'limits':'Target may have an uncommitted upstream merge. This packet is preparation, not an integration result. Re-run against actual merged clean dev before adoption. Generated native/WEB/manifest/feet/frontage/sidecar/images outputs must come from current native owners, never this dated packet. Camera match states deliberately remain stale/unreviewed until actual fresh comparison. Authored STATUS/ROADMAP qualification notes remain owed.'}
 (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'candidate_count':len(candidates),'target_head':head,'result':str(out/'RESULT.json')}))
if __name__=='__main__':main()
