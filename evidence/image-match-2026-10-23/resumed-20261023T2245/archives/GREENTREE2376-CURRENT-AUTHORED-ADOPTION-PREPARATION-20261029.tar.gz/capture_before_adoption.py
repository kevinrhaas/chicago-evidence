#!/usr/bin/env python3
"""Capture actual current pre-GT defaults for later current-producer controls; no repo writes."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--expected-head',required=True);p.add_argument('--out',required=True);a=p.parse_args()
r=Path(a.repo).resolve();d=r/'chicago/4d';out=Path(a.out).resolve();assert not out.exists() and r not in out.parents
sha=lambda b:hashlib.sha256(b).hexdigest()
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*args):return subprocess.check_output(['git','-C',str(r),*args],env=env).decode().strip()
assert git('rev-parse','HEAD')==a.expected_head
assert git('status','--porcelain','--untracked-files=no')=='','Require actual clean completed dev before recording old defaults'
old=json.loads(Path('/workspace/T2376-annex-20261029/native/INPUTS.json').read_text());rows=[];payload={}
for i,e in enumerate(old['family']):
 rp=Path(e['record']).relative_to('/tmp/chicago-green-tree-integration/chicago/4d');mp=Path(e['current_master']).relative_to('/tmp/chicago-green-tree-integration/chicago/4d');raw=(d/rp).read_bytes();model=(d/mp).read_bytes();st=json.loads(raw);ph=next(x for x in st['phases']if x['id']==e['phase']);assert st['archetype']=='frame_tavern'
 if st['id']=='green_tree_tavern':assert ph['form'].get('enclosed_left_annex') is None,'Capture must precede GT authored adoption'
 key=f'{i:02d}-{e["asset"]}';rr='records/'+key+'.json';mm='masters/'+key
 payload[rr]=raw;payload[mm]=model;rows.append({'id':st['id'],'phase':e['phase'],'record_path':str(rp),'master_path':str(mp),'record_snapshot':rr,'master_snapshot':mm,'record_sha256':sha(raw),'master_sha256':sha(model),'master_bytes':len(model),'control_asset':e['asset']})
assert len(rows)==25 and len(set(x['id']for x in rows))==23
assert git('rev-parse','HEAD')==a.expected_head and git('status','--porcelain','--untracked-files=no')==''
for x in rows:assert sha((d/x['record_path']).read_bytes())==x['record_sha256'] and sha((d/x['master_path']).read_bytes())==x['master_sha256']
out.mkdir(mode=0o700)
for path,raw in payload.items():q=out/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
result={'status':'ACTUAL_CURRENT_CLEAN_PRE_GT_DEFAULTS_CAPTURED_NO_GT_NATIVE_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repo':str(r),'head':a.expected_head,'rows':rows};(out/'INPUTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'records':25,'ids':23,'head':a.expected_head}))
