import sys,pathlib,types,json,hashlib,pickle
sys.dont_write_bytecode=True
root=pathlib.Path(sys.argv[1]);sys.path.insert(0,str(root/'generators'))
sys.modules['bpy']=types.ModuleType('bpy')
import mesh_inputs
from archetypes import frame_tavern_params as params, frame_tavern as builder
from common.mesh import MeshBuilder
MeshBuilder.to_object=lambda self,mats=None:(self,list(mats or []))
builder.simple_material=lambda n,*a,**kw:(n,a,kw)
record=json.loads((root/'record.json').read_text());phase=record['phases'][0]
p=params.from_phase(phase,record)
mesh,materials=builder.build(p,'green_tree_tavern__frame_1833.glb')
raw=(mesh.verts,mesh.faces,mesh.conf,mesh.mat_index,mesh.named,materials)
doc=mesh_inputs.structure_inputs_doc(record,phase)
result={'native_inputs_sha':mesh_inputs.structure_inputs_sha(record,phase),
 'native_document':doc,'code_shas':doc['code'],
 'raw_sha':hashlib.sha256(pickle.dumps(raw,protocol=4)).hexdigest(),
 'vertices':len(mesh.verts),'faces':len(mesh.faces),'stations':params.front_ground_stations(p),
 'params_module_sha':hashlib.sha256((root/'generators/archetypes/frame_tavern_params.py').read_bytes()).hexdigest()}
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
