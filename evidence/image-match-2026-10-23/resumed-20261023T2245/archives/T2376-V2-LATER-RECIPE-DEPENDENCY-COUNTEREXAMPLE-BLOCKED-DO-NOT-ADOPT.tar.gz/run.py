import pathlib, shutil, hashlib, json, subprocess, sys, os
P=pathlib.Path(__file__).parent
F=pathlib.Path('/tmp/T2376-front-ground-independent-review-v2/fixture')
N=pathlib.Path('/tmp/chicago-log-integration/chicago/4d')
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for case in ('before','after'):
    root=P/case
    (root/'generators/archetypes').mkdir(parents=True)
    for name in ('mesh_inputs.py','code_inputs.py','emit.py','blender.pin'):
        shutil.copyfile(N/'generators'/name,root/'generators'/name)
    shutil.copytree(F/'cpu-deps/generators/common',root/'generators/common')
    for name in ('frame_tavern.py','frame_tavern_params.py'):
        shutil.copyfile(F/'candidate/generators/archetypes'/name,root/'generators/archetypes'/name)
    shutil.copyfile(F/'candidate/data/structures/green_tree_tavern.json',root/'record.json')
p=P/'after/generators/archetypes/frame_tavern_params.py'
s=p.read_text();old='return params.width_m * door, (params.width_m * sash_a, params.width_m * sash_b)'
assert s.count(old)==1
p.write_text(s.replace(old,'return params.width_m * (door + .01), (params.width_m * sash_a, params.width_m * sash_b)'))
for case in ('before','after'):
    run=subprocess.run([sys.executable,str(P/'worker.py'),str(P/case)],capture_output=True,text=True,
                       env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','NODE_DISABLE_COMPILE_CACHE':'1'})
    (P/f'{case}.log').write_text(run.stdout+run.stderr)
    assert run.returncode==0,run.stderr
before=json.loads((P/'before/result.json').read_text());after=json.loads((P/'after/result.json').read_text())
assert before['native_inputs_sha']==after['native_inputs_sha']
assert before['raw_sha']!=after['raw_sha']
assert before['native_document']==after['native_document']
assert before['code_shas']==after['code_shas']
assert before['params_module_sha']!=after['params_module_sha']
assert before['vertices']==after['vertices'] and before['faces']==after['faces']
assert abs(after['stations'][0]-before['stations'][0]-.0762)<1e-12
assert before['stations'][1]==after['stations'][1]
receipt={'scope':'EXTERNAL_CPU_FRESHNESS_COUNTEREXAMPLE_NO_CANONICAL_EDITS_NO_EXPORT',
 'result':'CONFIRMED_NEW_HELPER_ONLY_GEOMETRY_CHANGE_ESCAPES_NATIVE_RECIPE',
 'fault':'only explicit front_ground_stations door calculation adds .01 fraction',
 'door_shift_m':after['stations'][0]-before['stations'][0],
 'native_inputs_sha_before_after':[before['native_inputs_sha'],after['native_inputs_sha']],
 'raw_sha_before_after':[before['raw_sha'],after['raw_sha']],
 'actual_native_recipe_documents_equal':True,'builder_common_emit_pin_bytes_equal':True,
 'only_params_helper_bytes_differ':True,'vertices_faces_equal':[before['vertices'],before['faces']],
 'source_v2_manifest_sha256':sha(F/'UPSTREAM-ORIGINAL-MANIFEST.json'),
 'current_native_recipe_sha256':sha(N/'generators/mesh_inputs.py'),
 'original_source_unchanged':True,'no_blender_browser_native_writer':True}
(P/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
