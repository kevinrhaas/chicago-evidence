# T-3082 stacked on committed PR1260

The concrete stack plan and exact preimages passed before clearing any current state. The complete previous owned state was independently archived and read back at86136555. The standard owned-only migration preserved all old refs, atomically held the original untracked entry, and created v4 directly from exact6bf. No old026 merge was carried because026 is already an ancestor.

Four authored source preimages match exactly. Both human fixture edits already exist byte-for-byte in6bf and were left untouched. Every current23 native recipe hash and full finite serialized input document was recomputed in an exact6bf candidate and then again on the actual canonical stack BEFORE any asset/row transfer; all match the genuine official exports. Only those46 genuine frame files and23 native producer rows were transferred.

All164 incoming log master/web files were checked against exact6bf Git blobs and rehashed unchanged after transfer. All82 log rows/web hashes, all unrelated registry entries and the versions manifest remain exact. Full target LIBERTIES/STATUS/ROADMAP were preserved raw, then own suffixes appended once. Only the two target GLBs and two registries differ under assets; native fixture files have zero owned diff. The exact migration/proofs and incoming documents are selected here; candidate/ remains an unfrozen disposable fixture excluded from selection.

Main worktree is on steward/t3082-tremont-quarter-roof-stack1260-v4 at6bf, uncommitted. The eventual PR targets dev with explicit dependency on1260. The parent requested combined runtime validation on this stack. No native/downstream/browser, gate, publish, materialize, Blender or new heavy run occurred in this migration. Those remain pending the next parent grant. Earlier genuine export receipts and all46 outputs remain independently archived at0cfce6af.

OriginalT2385 stays open/claimed/DIFFERS; quarter-linear roof is a reconstructed contrast choice. Rights/attribution stay within standing owner-approved project-use limits without upgrade. Broad-left flag research remains unadopted and global native wind unchanged. Old Glessner cache remains held intact.
