# T-3082 stack onto PR1260

Create a fresh topic from exact6bf only after the whole current state has independent remote recovery proof. Four frame/Tremont source preimages match; both human fixture fixes are already identical in target. All23 exact candidate native recipe hashes and full finite serialized documents match the genuine official exports. Repeat that proof on the actual canonical tree before asset transfer.

Retain complete incoming raw LIBERTIES/STATUS/ROADMAP and all82 log master/web assets and rows, plus every unrelated registry entry. Append only own exact doc suffixes and oneT3082entry; target fixtures remain untouched. Copy only actual23 frame producer rows and46 actual frame files after recipe proof. No fabricated recipe stamp, copied old whole manifest, reconstructed parent docs or original image-match completion.

Use standard merge quit/owned-only verified restore and atomically hold the untracked original entry, preserving all old refs.026ace is already an ancestor of6bf, so the fresh v4 topic needs no old fold merge. Final PR targets dev, explicitly dependent on1260, and combined native/gate/published smoke validation comes only under the next parent grant. No clearing has occurred while recovery publication is pending.
