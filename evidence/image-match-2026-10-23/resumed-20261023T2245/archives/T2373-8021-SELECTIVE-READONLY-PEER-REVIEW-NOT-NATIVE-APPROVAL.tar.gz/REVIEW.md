# Lighthouse selective semantic/source review

No substantive blocker found in proposal manifest268720f18cf198c9cf9d21e7a15d6ad716cd605763eae5603ef8f1b00a564d44. This is read-only review, not native/render/gate or image acceptance.

The preimage and candidate both retain wall_height_m12.19, not14.1. It represents the rounded forty-foot statement with an unresolved historic datum. It is consumed: _tower passes h into _birdcage_clear_detail, whose maximum=h+r1*0.7=12.84968. Explicit profile gallery8.719767307/cap11.0/rail1.0 are reconstructed subdivision, not measured wall heights. Changing nominal h changes the top/finial, so this control is not ignored. The record, liberty and notes distinguish those meanings.

compile_scene copies authored attributes to the sidecar without relabelling12.19 as decoded maximum. main.js framing/focus and confidence-overlays prefer decoded bounds, using nominal wall height as fallback; building-body-bounds is sign-only and excludes this tower. smoke_renderer uses a broad height agreement check, not equality of total maximum and nominal wall height. Actual native sidecar/export/readback remains owed.

Physical polygon1.28..4.32 genuinely derives minima1.28/span3.04 and retains centre2.8,2.8 from old0..5.6. Position/bearing/date objects match the preimage. Resolver derives minima; tower uses min+span/2. Diameter/offset validation remains present. Decimal arithmetic confirms the centre; ordinary binary arithmetic has an immaterial floating-point roundoff.

Viewed the actual held640x361 Castelnau image: distinct far-right lighthouse, near-whole shaft, gallery, framed lantern, rounded crown and finial; lower toe partly occluded. The record carefully separates1842 publication, described circa1838 state and July1835 scene. Applying visible details to1835 remains inferred continuity, not attested fittings, member counts, paint, material, measured diameter or camera. Original plate/title verification is inherited evidence, not independently repeated in this review.

The six new controls cite only cleared Castelnau and lighthousefriends for written lantern type. Baker remains check_required, Peck credit unresolved, and school project-use approval is explicitly not used to clear those sources. No new candidate control derives from them. First-tower50ft/3ft dimensions remain excluded from the second tower.

The separate named whole-appearance ruling is reasonable under grade_structures.py's explicit scene-view ruling rule: substantially the whole recognizable tower is shown, not an incidental corner. The1832 phase spans the circa1838 depiction. Whole-building Pictured is distinct from attesting unchanged1835 details; retain all existing per-field grades, inferred continuity, uncertain metrics and unsolved camera. This optional ruling is outside the patch and remains root's separate selection.

No correction requested. Preserve frozen originals. Current-base guards, genuine25-family official refresh/derivatives, native sidecars/source/grade readers and ordered tail, actual desktop/mobile normal/Bygrade/Images/placement/alpha/budget QA, full policy gates and original comparisons are still owed. All seven original source views stay differs or unresolved. No claims, canonical writes, generators, geometry/API tests, Blender, browser or gates were run here.
