# Conditional V3 postcheck-resource recovery — prepared, never executed

This is a narrow adaptation of `recover_closed_bcf_gate.py` for the actual V3 controller, source HEAD89ad, incoming237, staged tree `2b609b8461f000730de75dd4672275ca5115fa8d`, 17 staged paths, seven own paths, four reviewed postimages and all18 guards. Preparation read only frozen controller source/static review metadata; it did not read active outcomes, inspect TMP/processes, delete anything, run Git or alter gate outputs.

**Do not execute if the genuine gate passes its resource postcheck.** The helper refuses an existing GATE-RESULT, an unclosed/failed native check, a current TMP floor that already passes, or any missing approval/proof. It cannot run another gate, test, browser or meter. Root must first review the actual closed controller failure and grant this specific recovery.

Required later approval JSON fields:

```json
{
  "status": "ROOT_APPROVED_EXACT_FIVE_CLOSED_V3_GATE_FIXTURE_RECOVERY",
  "root_approved": true,
  "controller_closed": true,
  "original_controller_exit": 1,
  "head": "89ad07fd2b43679c028715dbf30830b7dacf2a54",
  "merge_parent": "2378484c31b91a1b8d28fd8430d2b4d1a783bdaa",
  "tree": "2b609b8461f000730de75dd4672275ca5115fa8d",
  "gate_binding_sha256": "ACTUAL_CLOSED_BINDING_SHA256",
  "native_source_result_sha256": "ACTUAL_CLOSED_NATIVE_RESULT_SHA256",
  "native_reaper_sha256": "ACTUAL_CLOSED_REAPER_SHA256",
  "raw_controller_failure": {"path": "ACTUAL_PRESERVED_RAW_FAILURE", "sha256": "ACTUAL_SHA256"},
  "closed_content_and_reaper_window_reviewed": true,
  "zero_candidate_FDs_reviewed": true,
  "TMP_at_controller_halt": "ACTUAL_INTEGER_BELOW_1800000000",
  "workspace_at_controller_halt": "ACTUAL_INTEGER_AT_LEAST_536870912",
  "leak_roots": ["THE_FIVE_ACTUAL_REVIEWED_TMP_ROOTS"]
}
```

The placeholders are not approvals or guessed evidence. Root provides real numeric observations and exactly five unique paths after closure. The helper verifies the actual native0/reaper closure/no leftover kill, exact full1105 PASS footer, all18 raw guards, actual root review/hash maps and frozen controller bytes. It retains exact raw failure/binding/result/reaper/approval bytes externally.

Only five private `tmp.XXXXXXXXXX` directories created within the **actual reaper started/observed UNIX mtime window** qualify. Each must have exactly four empty merge-driver files, `lock/tools/ticket.mjs`, and only `lock`/`lock/tools` directories; same UID/device, private modes, no symlinks and single-link files. The CLI must equal the immutable native public CLI with precisely the documented **57-byte** status-only line inserted after its shebang:

`if (!process.argv.includes('--status')) process.exit(0);`

This construction is in native `tools/test_pr_lap_lock.mjs`; its actual bytes/hash and public native CLI URL are recorded. Profiles, caches, source, models, other TMP paths and unknown residue never qualify. Candidate roots must equal root's approved list. Current process-FD scanning must find zero candidate references, and is repeated immediately before cleanup.

The restore map records exact root/file/directory modes, UID/GID, inspection timestamps, allocation, sizes, hashes and reconstructible content rules. Content/modes and atime/mtime can be restored; inode/device/ctime/allocation record observed lineage rather than a promise to recreate kernel identity. No private contents or five duplicate CLI blobs are archived. Only after the map is preserved and all18 guards rechecked does the helper retire those exact five roots. Their recorded allocation must be sufficient to restore the unchanged floor.

After cleanup it requires workspace≥536,870,912 B and shared TMP≥1,800,000,000 B, then recomputes all18 guards including current source/own4/raw-doc composition, canonical incoming, refs, index semantics and config. The staged tree is proven by unchanged **complete index content and flags matching the real checked tree**, avoiding `write-tree` or any Git-object/index/ref writes during recovery. Only then is the normal V3 GATE PASS written, explicitly retaining original resource failure/recovery, restore-map SHA and `native_check_was_not_rerun:true`.

Only after root's later explicit approval:

`python -B /workspace/T3262-v3-resource-recovery-prep-secondfort-20261030/recover_closed_v3_gate.py --root-approval ACTUAL_ROOT_APPROVAL_JSON --execute-resource-recovery`

This command has **not** run. If any condition fails, stop and retain evidence; do not broaden cleanup, weaken floors or rerun/relabel the source check through this helper.
