"""Prepared conditional recovery ONLY. Never run unless root grants after actual closed gate/floor failure."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,shutil,stat,sys,time

O=Path(__file__).resolve().parent;CFG=json.loads((O/'CONFIG.json').read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root-approval',required=True,type=Path);ap.add_argument('--execute-resource-recovery',action='store_true');a=ap.parse_args()
assert a.execute_resource_recovery,'Frozen preparation only; actual closed raw receipt plus explicit later root grant are required'
approval_raw=a.root_approval.read_bytes();approval=json.loads(approval_raw)
assert approval['status']=='ROOT_APPROVED_EXACT_FIVE_CLOSED_V3_GATE_FIXTURE_RECOVERY'and approval['root_approved']is True
assert approval['controller_closed']is True and approval['original_controller_exit']==1
assert approval['closed_content_and_reaper_window_reviewed']is True and approval['zero_candidate_FDs_reviewed']is True
assert approval['head']==CFG['head']and approval['merge_parent']==CFG['merge_parent']and approval['tree']==CFG['tree']
S=Path(CFG['controller']);assert not(S/'GATE-RESULT.json').exists(),'Already qualified: resource recovery is forbidden'
for name,h in CFG['frozen_controller_hashes'].items():assert sha((S/name).read_bytes())==h
sys.path.insert(0,str(S));import common as C
braw=(S/'GATE-BINDING.json').read_bytes();rrraw=(S/'NATIVE-SOURCE-RESULT-BEFORE-RESOURCE-RECHECK.json').read_bytes();rpraw=(S/'check-REAPER.json').read_bytes()
for key,raw in [('gate_binding_sha256',braw),('native_source_result_sha256',rrraw),('native_reaper_sha256',rpraw)]:assert sha(raw)==approval[key]
b=json.loads(braw);rawresult=json.loads(rrraw);rp=json.loads(rpraw)
assert b['revision']=='V3_CURRENTDEV_237'and b['head']==CFG['head']and b['merge_parent']==CFG['merge_parent']and b['checked_final_staged_tree']==CFG['tree']
assert len(b['all_staged_paths'])==17 and len(b['all7_source_sha256'])==7 and len(b['own4_postimages'])==4
assert sha(Path(CFG['root_review_manifest']).read_bytes())==CFG['root_review_manifest_sha256']==b['root_reviewed_manifest_sha256']
review=json.loads(Path(CFG['root_review_manifest']).read_bytes());assert review['all_staged_paths']==b['all_staged_paths']and review['own4_postimages']==b['own4_postimages']
assert rawresult['native_source_pass']is True and rawresult['exit']==0 and rawresult['caller_resource_floors_not_yet_rechecked']is True
assert set(rawresult['guards'])==set(CFG['guard_names'])and len(rawresult['guards'])==18 and all(rawresult['guards'].values())
assert rp['command_exit']==0 and rp['all_children_reaped']is True and not rp['leftover_cleanup']and rp['command'][-2:]==['bash','tools/check.sh']
assert rp['started_unix']<=rp['observed_unix']<=time.time()
log=(S/'check.log').read_bytes();clean=re.sub(rb'\x1b\[[0-9;]*m',b'',log);assert re.search(rb'^CHECK PASS \xe2\x80\x94 1105 steps, none red\.$',clean,re.M)
failure=Path(approval['raw_controller_failure']['path']).read_bytes();assert sha(failure)==approval['raw_controller_failure']['sha256']and b'AssertionError'in failure and b'floors'in failure
assert shutil.disk_usage('/workspace').free>=536870912+2*1048576
tmp_before=shutil.disk_usage('/tmp').free;assert tmp_before<1800000000,'No current shared-TMP floor failure: do not clean or relabel anything'
assert approval['TMP_at_controller_halt']<1800000000 and approval['workspace_at_controller_halt']>=536870912

def guards():
 # Same full index entries+flags as the actual checked tree proves that tree
 # without invoking write-tree or mutating ANY Git object/ref/index metadata.
 ix=C.index();same_index=ix==b['index_semantics'];C.exact(b['all_staged_paths']);C.exact(b['all7_source_sha256'])
 return dict(HEAD=C.g('rev-parse','HEAD').decode().strip()==b['head'],MERGE_HEAD=C.g('rev-parse','MERGE_HEAD').decode().strip()==b['merge_parent'],
  cached_origin_dev=C.g('rev-parse','origin/dev').decode().strip()==b['merge_parent'],staged_tree=same_index and b['checked_final_staged_tree']==CFG['tree'],
  tracked_working_bytes=not C.g('diff','--name-only'),no_untracked=not C.g('ls-files','--others','--exclude-standard'),no_conflicts=not C.g('ls-files','-u'),
  staged_path_sha256=all(C.path_sha(p)==h for p,h in b['all_staged_paths'].items()),source_hashes=all(C.path_sha(p)==h for p,h in b['all7_source_sha256'].items()),
  all_refs_exact=C.refs()==b['all_refs_before'],index_semantics_exact=same_index,config_exact=sha((C.R/'.git/config').read_bytes())==b['source_config_sha256'],
  protected_own3_exact=all(C.path_sha(p)==C.BASE['own_parent_sha256'][p]for p in C.BASE['own_exact3']),own_docs_composed=C.docs_compose()==b['own_document_composition'],
  own4_reviewed_exact=b['own4_postimages']=={p:C.path_sha(p)for p in C.BASE['own4_paths']},candidate_code_exact=all(C.path_sha(p)==h for p,h in C.BASE['candidate_code_postimages'].items()),
  incoming_authoritative=set(C.g('diff','--name-only',b['merge_parent']).decode().splitlines())==set(C.BASE['own7_paths']),all_children_reaped=rp['all_children_reaped'])
before=guards();assert set(before)==set(CFG['guard_names'])and all(before.values())
cli=(C.A/'tools/ticket.mjs').read_bytes();assert cli==C.g('show',b['head']+':chicago/4d/tools/ticket.mjs')
shim=b"if (!process.argv.includes('--status')) process.exit(0);\n";assert len(shim)==57
assert cli.startswith(b'#!/usr/bin/env node\n');variant=cli.replace(b'#!/usr/bin/env node\n',b'#!/usr/bin/env node\n'+shim,1);assert len(variant)==len(cli)+57
test=C.A/'tools/test_pr_lap_lock.mjs';test_bytes=test.read_bytes();assert test_bytes==C.g('show',b['head']+':chicago/4d/tools/test_pr_lap_lock.mjs')
assert shim.rstrip(b'\n')in test_bytes and b'rest.join'in test_bytes
expected={'merge-smoke-state.mjs','merge-generated.mjs','merge-changelog.mjs','merge-queue.mjs','lock/tools/ticket.mjs'};expected_dirs={'lock','lock/tools'};rows=[]
def attrs(p):
 s=p.lstat();return dict(mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,atime_ns=s.st_atime_ns,device=s.st_dev,inode=s.st_ino,allocated=s.st_blocks*512)
for p in Path('/tmp').iterdir():
 if not re.fullmatch(r'tmp\.[A-Za-z0-9]{10}',p.name)or p.is_symlink()or not p.is_dir():continue
 st=p.stat()
 if not(rp['started_unix']<=st.st_mtime<=rp['observed_unix']):continue
 paths=list(p.rglob('*'));files=[f for f in paths if f.is_file()];dirs=[f for f in paths if f.is_dir()]
 if any(f.is_symlink()for f in paths)or {str(f.relative_to(p))for f in files}!=expected or {str(f.relative_to(p))for f in dirs}!=expected_dirs:continue
 if(p/'lock/tools/ticket.mjs').read_bytes()!=variant or any((p/n).stat().st_size for n in expected-{'lock/tools/ticket.mjs'}):continue
 assert st.st_uid==os.geteuid()and stat.S_IMODE(st.st_mode)==0o700 and st.st_dev==Path('/tmp').stat().st_dev
 assert all(f.stat().st_uid==os.geteuid()and f.stat().st_nlink==1 and stat.S_IMODE(f.stat().st_mode)==0o600 and f.stat().st_dev==st.st_dev for f in files)
 assert all(f.stat().st_uid==os.geteuid()and stat.S_IMODE(f.stat().st_mode)==0o700 and f.stat().st_dev==st.st_dev for f in dirs)
 rows.append(dict(root=str(p),root_stat=attrs(p),files=[dict(relative=str(f.relative_to(p)),bytes=f.stat().st_size,sha256=sha(f.read_bytes()),stat=attrs(f),content_kind='native_cli_plus_exact57B_status_only_shim'if str(f.relative_to(p))=='lock/tools/ticket.mjs'else'empty')for f in files],dirs=[dict(relative=str(f.relative_to(p)),stat=attrs(f))for f in dirs]))
assert len(rows)==5 and {r['root']for r in rows}==set(approval['leak_roots'])and len(set(approval['leak_roots']))==5
assert tmp_before+sum(r['root_stat']['allocated']+sum(f['stat']['allocated']for f in r['files'])+sum(d['stat']['allocated']for d in r['dirs'])for r in rows)>=1800000000,'Exact five alone cannot restore caller floor; stop without cleanup'
roots=[Path(r['root'])for r in rows]
def candidate_fds():
 found=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   for fd in(proc/'fd').iterdir():
    try:
     target=Path(os.readlink(fd))
     if any(target==root or target.is_relative_to(root)for root in roots):found.append(str(fd))
    except OSError:pass
  except OSError:pass
 return found
assert not candidate_fds();restore=dict(status='FIVE_EXACT_OWN_CLOSED_V3_NATIVE_GATE_SYNTHETIC_DRIVER_FIXTURES',rows=rows,
 reaper_window=dict(started_unix=rp['started_unix'],observed_unix=rp['observed_unix']),zero_candidate_FDs=True,native_cli_sha256=sha(cli),native_cli_bytes=len(cli),
 public_cli='https://raw.githubusercontent.com/kevinrhaas/chicago/'+b['head']+'/chicago/4d/tools/ticket.mjs',native_test_path=str(test),native_test_sha256=sha(test_bytes),
 variant_added_bytes=57,exact_status_only_line=shim.decode(),restore_rule='Recreate only listed roots/directories/files with recorded modes/uid/gid and atime/mtime; empty files have zero bytes, CLI file is immutable public native CLI with the literal57B line inserted after its shebang. Verify bytecount/SHA before restoring atime/mtime. Device/inode/ctime/allocation are observed lineage, not a promise to recreate kernel identity.',
 staged_tree_rechecked_by_exact_full_index_content_and_flags_no_Git_write=True,no_private_profile_cache_source_model_or_other_TMP_deletion=True)
for n,raw in [('RAW-GATE-BINDING.json',braw),('RAW-NATIVE-SOURCE-RESULT.json',rrraw),('RAW-CHECK-REAPER.json',rpraw),('ORIGINAL-CONTROLLER-RESOURCE-FAILURE.raw',failure),('ROOT-APPROVAL.json',approval_raw)]:assert not(O/n).exists();(O/n).write_bytes(raw)
restore_path=O/'V3-OWN-TMP-FIXTURE-RESTORE.json';assert not restore_path.exists();restore_path.write_text(json.dumps(restore,indent=2)+'\n')
assert not candidate_fds()and all(guards().values())
for p in roots:shutil.rmtree(p)
C.floors();after=guards();assert set(after)==set(CFG['guard_names'])and all(after.values())and after==before
incident=dict(original_controller_exit=1,reason='Actual native1105/full18-source-guards passed; only postcheck caller TMPfloor failed. Exactly five publicly reconstructible own closed fixtures retired, all current18guards rechecked. No native test/meter rerun and no floor waiver.',
 TMP_at_controller_halt=approval['TMP_at_controller_halt'],TMP_before_cleanup=tmp_before,TMP_after_cleanup=shutil.disk_usage('/tmp').free,caller_TMP_floor=1800000000,
 retired_only_roots=[str(p)for p in roots],restore=str(restore_path),restore_sha256=sha(restore_path.read_bytes()),original_raw_failure_sha256=sha(failure),root_approval_sha256=sha(approval_raw),no_source_Git_index_config_ref_or_test_mutation=True)
(O/'V3-CONTROLLER-RESOURCE-HALT-AND-RECOVERY.json').write_text(json.dumps(incident,indent=2)+'\n')
result=dict(status='ACTUAL_T3262_V3_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_PASS',revision='V3_CURRENTDEV_237',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=0,
 seconds=rp['observed_unix']-rp['started_unix'],binding=b,guards=after,config_unchanged=after['config_exact'],footer=log.decode(errors='replace').splitlines()[-15:],
 step=dict(name='check',command=['bash','tools/check.sh'],exit=0,seconds=rp['observed_unix']-rp['started_unix'],all_children_reaped=True),original_controller_resource_halt_recovered=incident,native_check_was_not_rerun=True,phone_commit_PR_CI_merge_pending=True)
assert not(S/'GATE-RESULT.json').exists();(S/'GATE-RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],native_seconds=result['seconds'],all18guards=True,TMP_after_cleanup=incident['TMP_after_cleanup'],no_source_Git_mutation_or_native_rerun=True),indent=2))
