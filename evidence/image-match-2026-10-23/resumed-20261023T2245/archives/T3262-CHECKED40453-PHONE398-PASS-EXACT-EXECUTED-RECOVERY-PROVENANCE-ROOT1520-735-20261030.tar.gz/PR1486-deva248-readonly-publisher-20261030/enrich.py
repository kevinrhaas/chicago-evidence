from pathlib import Path
import os,json,importlib.util,concurrent.futures,datetime
os.sched_setaffinity(0,{2});os.nice(19)
p=Path(__file__).parent;s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);base='2378484c31b91a1b8d28fd8430d2b4d1a783bdaa';tip='a24805f821224e423d114e89d91326a75a44b837'
paths=['chicago/4d/assets/web/pullman_house_1729_prairie_ranges__draft_1904.glb','chicago/4d/data/research/convergence_coverage.json.gz','chicago/4d/data/research/location_reconciliation.json.gz','chicago/4d/data/research/research_spend_ledger.json.gz']
qs=[((ref,path),'contents/'+path+'?ref='+ref)for ref in [base,tip]for path in paths]+[(('PR','1488'),'pulls/1488'),(('dir','JS'),'contents/chicago/4d/renderers/web/js?ref='+tip)]
def f(z):return z[0],m.api(z[1])
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:r=dict(ex.map(f,qs))
rows=[]
for path in paths:
 a,b=r[base,path],r[tip,path];rows.append({'path':path,'old_bytes':a['size'],'new_bytes':b['size'],'delta_bytes':b['size']-a['size'],'old_blob':a['sha'],'new_blob':b['sha']})
pr=r['PR','1488'];proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'tip':tip,'metadata_only_size_reads':rows,'PR1488':{k:pr[k]for k in ['number','html_url','merged','merge_commit_sha','body']},'research_named_JS_candidates':[{'name':x['name'],'path':x['path'],'blob':x['sha'],'bytes':x['size']}for x in r['dir','JS']if'research'in x['name'].lower()or'converg'in x['name'].lower()or'spend'in x['name'].lower()]}
(p/'PHYSICAL-SIZES-AND-IMMUTABLE-PR.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
