from pathlib import Path
from urllib.request import Request,urlopen
import os,json,gzip,hashlib,concurrent.futures,datetime
os.sched_setaffinity(0,{2});os.nice(19)
p=Path(__file__).parent;base='2378484c31b91a1b8d28fd8430d2b4d1a783bdaa';tip='a24805f821224e423d114e89d91326a75a44b837';paths=['chicago/4d/data/research/convergence_coverage.json.gz','chicago/4d/data/research/location_reconciliation.json.gz','chicago/4d/data/research/research_spend_ledger.json.gz']
def get(z):
 ref,path=z
 with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+ref+'/'+path,headers={'User-Agent':'Chicago-exact-gzip-semantic-readonly'}),timeout=60)as f:raw=f.read(2*1024**2+1);assert len(raw)<=2*1024**2
 return z,raw
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:raws=dict(ex.map(get,[(ref,path)for ref in [base,tip]for path in paths]))
rows=[]
for path in paths:
 a,b=raws[base,path],raws[tip,path];da,db=gzip.decompress(a),gzip.decompress(b);diff=[i for i in range(min(len(a),len(b)))if a[i]!=b[i]];rows.append({'path':path,'compressed_size_equal':len(a)==len(b),'compressed_bytes':len(a),'old_gitblob':hashlib.sha1(b'blob '+str(len(a)).encode()+b'\0'+a).hexdigest(),'new_gitblob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'old_raw_sha256':hashlib.sha256(a).hexdigest(),'new_raw_sha256':hashlib.sha256(b).hexdigest(),'changed_byte_offsets':diff if len(diff)<=100 else {'count':len(diff)},'old_gzip_header_hex':a[:10].hex(),'new_gzip_header_hex':b[:10].hex(),'compressed_deflate_and_trailer_equal':a[10:]==b[10:],'decoded_bytes_equal':da==db,'decoded_bytes':len(da),'decoded_sha256_before':hashlib.sha256(da).hexdigest(),'decoded_sha256_after':hashlib.sha256(db).hexdigest()})
proof={'status':'EXACT_IMMUTABLE_GZIP_BYTE_AND_DECODED_CONTENT_COMPARISON_RAM_ONLY','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'tip':tip,'files':rows,'no_raw_gzip_or_expanded_payload_files_saved':True};(p/'GZIP-SEMANTIC-AND-RAW-BYTE-PROOF.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
