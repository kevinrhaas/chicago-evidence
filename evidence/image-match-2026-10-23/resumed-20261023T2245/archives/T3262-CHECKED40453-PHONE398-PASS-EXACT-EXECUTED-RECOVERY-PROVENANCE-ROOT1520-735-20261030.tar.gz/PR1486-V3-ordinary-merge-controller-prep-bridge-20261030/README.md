# PR1486 ordinary merge guard — prepared, unrun

`merge_ready.py` is read-only by default. Only explicit `--merge` can issue one ordinary REST PUT to merge PR1486 at the exact caller-supplied V3 head SHA. No current or future head is guessed. Its reviewed native-transport dependency is pinned by SHA; every mutable GET bypasses caches.

Before any merge it requires all actual receipts on the same head/tree/seven source hashes:

- The V3 full-source PASS, every guard, exact reviewed tree/config and raw source reaper.
- The native checkpoint with parents exactly `[89ad,237]`, clean source and all three native checkpoint checks/reapers.
- Official PHONE-V3 PASS at or below the unchanged400MiB ceiling, zero errors, exact meter argv, raw measurement SHA/row and actual reaper. No previous400.997failure is reused.
- FULL20-cell published smoke PASS: every stage14,1–3,7–12 on desktop and mobile, unique20cells, all actual `SMOKE PASS` logs/reapers, unchanged waits/assertions/timeouts and exact source/data/published bindings. Partial REQUESTED_SMOKE_LEGS results refuse. Reported screenshot files must still exist with their exact hashes/sizes in the bound stage/viewport directories.
- The verified normal-FF V3 publication receipt, exact head/tree/parents/all7 and actual immutable seven-file readback, with matching source-gate SHA.

The current clean primary HEAD/native tree/source files must still match. No test, phone, smoke, rebuild or renderer is launched by this controller.

## GitHub conditions

Fresh PR1486 must be open, non-draft, unmerged, on the exact head and dev base, without ownerhold, and GitHub must call it mergeable/clean. The immutable head commit must have the expected tree/parents; server PRfiles must be exactly the seven native blobs. Every actual head check run must be completed with success/skipped/neutral, with a real successful `gate`; pending, failed, cancelled or unknown runs refuse. Any actual legacy status must succeed. GitHub's aggregate legacy statepending with an empty status list is recorded as returned, not invented as a pending job or backfilled as success; real check runs and serverclean remain required.

Current dev must remain exactly `2378484c31b91a1b8d28fd8430d2b4d1a783bdaa`. Any advance produces a bounded read-only delta/own-path-overlap report and stops for root classification. The controller does not integrate it. All GitHub conditions and current dev are checked again immediately before the sole PUT.

Method `auto` prefers repository-enabled ordinary merge commits, then enabled squash. The repository's native merge-ready.sh uses squash; root may choose `--merge-method squash` to follow that practice. There is no rebase/admin/override option and no automatic fallback/retry after a rejected mutation. Normal server rules still apply.

After a successful PUT, it verifies GitHub's actual merge commit/tree/parents and immutable raw bytes for all seven own paths. That includes changelog.d/T-3262.json **at the immutable merge commit**, even if the normal later fold removes it from dev. A fresh PR must say mergedtrue/closed with that merge SHA. Current dev is read back; any later descendant fold/other commit is reported without forcing, rewriting or dispatching it. All local HEAD/index/config/status/refs remain unchanged.

## Later invocation

Only after every actual prerequisite has closed:

```bash
source /workspace/shared/resume-chicago-env.sh
PYTHONDONTWRITEBYTECODE=1 python /workspace/PR1486-V3-ordinary-merge-controller-prep-bridge-20261030/merge_ready.py \
  --head ACTUAL_V3_NATIVE_HEAD --tree ACTUAL_V3_TREE \
  --gate ACTUAL_V3_RUN/GATE-RESULT.json \
  --checkpoint ACTUAL_V3_RUN/CHECKPOINT-RESULT.json \
  --phone ACTUAL_V3_RUN/PHONE-V3-RESULT.json \
  --smoke ACTUAL_V3_RUN/SMOKE-V3-RESULT.json \
  --publication ACTUAL_V3_PUBLICATION/RESULT.json \
  --output /workspace/ACTUAL_V3_MERGE_READONLY_PLAN
```

Root reviews the actual plan and selects the method. Use a new output directory and add `--merge` only for the actual authorized action. If PUT/readback returns an error, preserve partial receipts and inspect fresh PR/dev state before any further action; never blindly retry a mutation or force a ref.

This implements the existing explicit user authorization to merge safe, completed PRs. It does not edit the PR body, close tickets, release laps, merge original picture work, dispatch/retry CI or touch main/production. Those follow separately. The source has only been syntax-parsed in preparation; no controller execution or API/source write occurred.
