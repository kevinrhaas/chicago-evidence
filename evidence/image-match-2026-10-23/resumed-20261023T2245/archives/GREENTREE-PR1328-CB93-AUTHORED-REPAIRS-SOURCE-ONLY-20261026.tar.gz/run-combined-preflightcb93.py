from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import urllib.request

R=Path('/tmp/chicago-green-tree-integration')
A=R/'chicago/4d'
H=Path('/tmp/green-tree-T2376-20261025')
BASE='132e0e85a9645055de1bfc4544942ec969b14511'
HEAD_BEFORE='0c78d17b22cf91782e2c7fe7e200c19dcc8a4534'
INCOMING='cb93ad9cd5ea38654737e05002b1f1904be14e54'
O=H/('combinedcb93-preflight-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
assert not O.exists()
O.mkdir()
env=dict(os.environ)
env.pop('CHICAGO_TICKETS_DIR',None)
env.pop('GIT_NO_LAZY_FETCH',None)
os.sched_setaffinity(0,{0,1})
env.update(TMPDIR='/tmp/gt-check',CHECK_JOBS='2',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',PYTHONDONTWRITEBYTECODE='1',CHECK_TIMINGS=str(O/'timings.tsv'))
Path(env['TMPDIR']).mkdir(exist_ok=True)
temp_free_bytes=shutil.disk_usage(env['TMPDIR']).free
assert temp_free_bytes>=int(1.5*1024**3),'Root-approved orchestration floor1.5GiB on actual temporary filesystem; native assertions unchanged'
def git(*args):
    return subprocess.check_output(['git','-c','core.preloadIndex=false',*args],cwd=R,env={**env,'GIT_NO_LAZY_FETCH':'1'})
assert git('rev-parse','HEAD').decode().strip()==HEAD_BEFORE
assert git('rev-parse','MERGE_HEAD').decode().strip()==INCOMING
assert git('merge-base','origin/dev','HEAD').decode().strip()==BASE
assert not git('diff','--name-only','--diff-filter=U').strip()
remote=json.loads(urllib.request.urlopen('https://api.github.com/repos/kevinrhaas/chicago/git/ref/heads/dev').read())
(O/'fresh-remote-base.json').write_text(json.dumps(remote,indent=2)+'\n')
remote_head=remote['object']['sha']
if remote_head!=BASE:
    comparison=json.loads(urllib.request.urlopen('https://api.github.com/repos/kevinrhaas/chicago/compare/'+BASE+'...'+remote_head).read())
    (O/'fresh-remote-merge-base.json').write_text(json.dumps(comparison,indent=2)+'\n')
    assert comparison['merge_base_commit']['sha']==BASE,'The actual fresh remote merge base changed'
paths=git('diff','HEAD','--name-only','-z').decode().split('\0')+git('ls-files','--others','--exclude-standard','-z').decode().split('\0')
paths += list(json.loads((H/'final-preflight-20261026T002618Z/SOURCE-BINDING.json').read_text())['paths'])
paths=sorted(set(p for p in paths if p))
assert paths and all(p.startswith('chicago/4d/')for p in paths),paths
subprocess.run(['git','add','-A','--','chicago/4d'],cwd=R,env=env,check=True)
assert all(p.startswith('chicago/4d/')for p in git('diff','--cached','--name-only').decode().splitlines())
tree=git('write-tree').decode().strip()
bound={p:hashlib.sha256((R/p).read_bytes()).hexdigest()if(R/p).is_file()else None for p in paths}
(O/'SOURCE-BINDING.json').write_text(json.dumps({'base':BASE,'head':HEAD_BEFORE,'incoming_merge_parent':INCOMING,'fresh_remote_head':remote_head,'staged_tree':tree,'paths':bound,'temp_free_bytes':temp_free_bytes,'orchestration_floor_bytes':int(1.5*1024**3),'orchestration_floor_authority':'Root2026-10-26 storage coordination: supported1.5GiB custom-driver floor, native checks/assertions unchanged, no new exports/bulk copies','all_required_readers':True,'all_required_base':True,'jobs':2,'cpu_affinity':sorted(os.sched_getaffinity(0)),'ticket_environment_override_absent':True,'scope':'Actual native-fixed-point source union of incomingcb93 and checked0c78, including strict authorized baseline contract repairs. The native precommit merge base is132 because the normal merge is intentionally uncommitted until this complete check passes. Both parents, fresh remote lineage and staged source tree are bound. Actual committed merge-head CL/IDs must repeat against the resulting merge base after the normal merge commit.'},indent=2)+'\n')
(O/'source.binary.patch').write_bytes(git('diff','--cached','--binary'))
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
commands=[['bash','tools/check.sh'],['node','tools/check-changelog-entry.mjs',BASE,'HEAD'],['node','tools/resolve_id_collisions.mjs','--base','origin/dev','--check']]
results=[]
for i,command in enumerate(commands):
    log=O/['check.log','changelog-entry.log','ids.log'][i]
    with log.open('x')as stream:
        process=subprocess.run(command,cwd=A,env=env,stdout=stream,stderr=subprocess.STDOUT)
    results.append({'command':command,'exit_code':process.returncode,'log':str(log)})
    print('ACTUAL_REQUIRED_COMMAND',i,process.returncode,str(log),flush=True)
    if process.returncode:
        break
unchanged=all((hashlib.sha256((R/p).read_bytes()).hexdigest()if(R/p).is_file()else None)==value for p,value in bound.items())
same_tree=git('write-tree').decode().strip()==tree
work_index_clean=subprocess.run(['git','diff','--quiet'],cwd=R,env=env).returncode==0
text=re.sub(r'\x1b\[[0-9;]*m','',(O/'check.log').read_text(errors='replace'))
footer=text.splitlines()[-4:]
gate=re.search(r'CHECK PASS — (\d+) steps, none red\.', '\n'.join(footer))
selftests=re.search(r'(\d+) of them are self-tests','\n'.join(footer))
passed=len(results)==3 and all(r['exit_code']==0 for r in results)and unchanged and same_tree and work_index_clean and bool(gate)and bool(selftests)
result={'status':'PASS'if passed else'FAIL','started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'staged_tree':tree,'jobs':2,'cpu_affinity':sorted(os.sched_getaffinity(0)),'source_unchanged':unchanged,'index_tree_unchanged':same_tree,'working_index_clean':work_index_clean,'actual_gate_steps':int(gate[1])if gate else None,'actual_self_tests':int(selftests[1])if selftests else None,'footer':footer,'commands':results,'incoming_merge_parent':INCOMING,'head_before_merge':HEAD_BEFORE,'committed_HEAD_PR_event_checks':'OWED after normal checked merge commit'}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
raise SystemExit(0 if passed else 1)
