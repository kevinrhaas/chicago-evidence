One exact-own-marker expiry guard for root PR1260.

One normal native reclaim occurred only after exact own f83 was stale and PR1260 was open; new owner, marker, timestamp and HELD status were independently verified.

Status: VERIFIED_NORMAL_NATIVE_OWN_EXPIRY_RECLAIM. All exact native argv/outputs/exits and independent old/new observations are in OPERATION_RECEIPT.json. The guard never runs before10:48:35UTC, never takes a changed marker, and stops on a closed PR or unreadable/error state. No force/release/manual timestamp, CI dispatch/rerun/cancel, label, merge or checked-source edit is performed. A normal native invocation, if any, uses its existing server-side compare-and-swap. No public PR head is assumed for lease eligibility. This receipt is operational evidence, not a test PASS or merge approval.
