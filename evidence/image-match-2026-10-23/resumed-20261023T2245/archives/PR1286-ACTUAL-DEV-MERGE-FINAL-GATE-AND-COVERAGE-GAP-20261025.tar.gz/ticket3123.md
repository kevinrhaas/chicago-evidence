---
id: T-3123
title: Lake House: distinguish an omitted roof cap from a flat roof and state reconstruction
state: done
epic: META
requested_by: steward
seen: false
effort: S
legacy_id: null
parent: null
opened: 2026-10-24
closed: 2026-10-25
pr: 1298
claimed_by: run 10/25/2026, 2:31:53 AM CT
blocked_on: null
needs_bake: true
closed_at: 2026-10-25T09:45:17Z
claimed_run: https://github.com/kevinrhaas/polecat-platform/actions/runs/40172812402
claimed_at: 2026-10-25T07:31:53.544Z
decision: null
decision_answer: null
---

Correct the fort producer's omitted-roof semantics for the existing Lake House construction model, with an honest confidence statement. This is one bounded semantic/model correction, not a reconstruction of the later completed hotel.

**Acceptance:**

- Make roof_type none omit the cap and keep flat roof output unchanged, with a meaningful positive flat control and an inventory proving which actual phases dispatch to this path. Preserve all dimensions, placement, dates and non-target raw geometry/material/confidence streams.
- State explicitly that the selected roof absence in July 1835 is reconstructed. A description of unfinished construction in 1836 does not establish the July 1835 roof stage. Correct only directly contradictory current notes using already admitted evidence; no scaffold, new phase or new research claim.
- Include this producer change in the group's genuine all-25 official master/web refresh, ordered native checks, actual mobile/desktop normal/ByGrade/Sources/Images and visible roof review, protected-input proofs and full preflight/CI.
- Original T-2379 and its complete picture-match scope stay open/DIFFERS; the later completed hotel is not declared matched or backdated.

One S utility grouped with T-3122 M and T-3124 S; one commit and one shared changelog item for this utility.

**Released 2026-10-24** (claim of Codex fort-family profile and piazza; parallel Chicago 4D 10/24/2026, 11:33:19 AM CT): Normal renewal of this same continuing group before its three-hour claim window: checked T3123 source checkpoint bd316f7f4 is pushed; lighthouse and officers piazza remain in progress on the same branch, waiting for the coordinated heavy lane. No rival claim is overridden.
