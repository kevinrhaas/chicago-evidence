import pathlib,json,subprocess,datetime,hashlib,sys
P=pathlib.Path('/tmp/PR1260-own-lap-expiry-reclaim')
APP=pathlib.Path('/tmp/chicago-log-integration/chicago/4d')
initial=json.loads((P/'initial-verification.json').read_text())
EXPECTED=initial['expected_original_marker']
EARLIEST=datetime.datetime.fromisoformat(initial['earliest_planned_reclaim_after'])
R={'operation':'ONE normal native expiry reclaim of same authorized root task','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_old_marker':EXPECTED,'native_command':['node','tools/ticket.mjs','lap','1260','--by','continuing root owner'],'normal_attempts':0,'force_release_or_manual_timestamp':False}
def save():
 (P/'RECLAIM_RECEIPT.json').write_text(json.dumps(R,indent=2)+'\n')
def stop(reason):
 R['status']='STOP_NO_OVERRIDE';R['reason']=reason;R['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(R,indent=2));sys.exit(4)
def api(path):
 q=subprocess.run(['gh','api','repos/kevinrhaas/chicago/'+path],capture_output=True,text=True)
 return {'exit':q.returncode,'stderr':q.stderr[-1000:],'data':json.loads(q.stdout) if q.returncode==0 else None}
def native_status():
 q=subprocess.run(['node','tools/ticket.mjs','lap','1260','--status'],cwd=APP,capture_output=True,text=True)
 return {'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
def source_context():
 head=subprocess.run(['git','rev-parse','HEAD'],cwd=APP,capture_output=True,text=True,check=True).stdout.strip()
 index=subprocess.run(['git','rev-parse','--git-path','index'],cwd=APP,capture_output=True,text=True,check=True).stdout.strip();index=pathlib.Path(index)
 if not index.is_absolute():index=APP/index
 return {'HEAD':head,'index_sha256':hashlib.sha256(index.read_bytes()).hexdigest(),'ticket_mjs_sha256':hashlib.sha256((APP/'tools/ticket.mjs').read_bytes()).hexdigest()}
if datetime.datetime.now(datetime.timezone.utc)<EARLIEST:stop('Before strictly permitted expiry time; no mutation attempted')
if (P/'normal-attempt-started.json').exists():stop('Attempt sentinel already exists; no second normal attempt allowed')
R['source_before']=source_context()
if R['source_before']['ticket_mjs_sha256']!=initial['ticket_mjs_sha256']:stop('Native tool bytes changed since initial TTL review')
R['independent_ref_before_status']=api('git/ref/heads/lap/pr-1260')
if R['independent_ref_before_status']['exit']!=0:stop('Independent marker read unknown before native status')
if R['independent_ref_before_status']['data']['object']['sha']!=EXPECTED:stop('Marker changed before native stale check')
R['native_pre_status']=native_status()
if R['native_pre_status']['exit']!=0 or not R['native_pre_status']['stdout'].startswith('stale lap/pr-1260 '):stop('Native status is not positively stale; no takeover attempted')
R['independent_ref_immediately_before_attempt']=api('git/ref/heads/lap/pr-1260')
if R['independent_ref_immediately_before_attempt']['exit']!=0:stop('Independent immediate marker read unknown')
if R['independent_ref_immediately_before_attempt']['data']['object']['sha']!=EXPECTED:stop('Marker changed immediately before attempt')
if datetime.datetime.now(datetime.timezone.utc)<EARLIEST:stop('Clock no longer beyond expiry')
R['attempt_started_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(P/'normal-attempt-started.json').write_text(json.dumps({'at':R['attempt_started_at'],'expected_old_marker':EXPECTED})+'\n');R['normal_attempts']=1;save()
q=subprocess.run(R['native_command'],cwd=APP,capture_output=True,text=True)
R['native_attempt']={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};save()
R['independent_ref_after_attempt']=api('git/ref/heads/lap/pr-1260')
if q.returncode!=0:stop('Native normal attempt rejected/failed; no retry or override')
if 'taken — this run laps it' not in q.stdout or 'lock not taken' in q.stderr:stop('Native output does not positively establish ownership')
if R['independent_ref_after_attempt']['exit']!=0:stop('Independent post-attempt ref unreadable; no retry')
new=R['independent_ref_after_attempt']['data']['object']['sha'];R['new_marker']=new
if new==EXPECTED:stop('Marker remained original despite reported success')
R['independent_new_commit']=api('git/commits/'+new)
if R['independent_new_commit']['exit']!=0:stop('New marker commit unreadable')
c=R['independent_new_commit']['data']
if not c['message'].startswith('lap PR #1260 — continuing root owner '):stop('Readback owner is another holder; no override')
if c.get('parents') or c['tree']['sha']!='4b825dc642cb6eb9a060e54bf8d69288fbee4904':stop('Readback is not native parentless empty-tree marker')
created=datetime.datetime.fromisoformat(c['committer']['date'].replace('Z','+00:00'))
if created<EARLIEST:stop('New native marker timestamp precedes permitted renewal boundary')
R['new_marker_created_at']=created.isoformat();R['new_expiry_boundary']=(created+datetime.timedelta(hours=3)).isoformat();R['native_post_status']=native_status()
if R['native_post_status']['exit']!=3 or not R['native_post_status']['stdout'].startswith('held lap/pr-1260 '):stop('Post-native status is not held')
R['source_after']=source_context();R['source_HEAD_and_index_unchanged_during_operation']=R['source_before']==R['source_after'];R['status']='NORMAL_NATIVE_EXPIRY_RECLAIM_VERIFIED';R['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(R,indent=2))
