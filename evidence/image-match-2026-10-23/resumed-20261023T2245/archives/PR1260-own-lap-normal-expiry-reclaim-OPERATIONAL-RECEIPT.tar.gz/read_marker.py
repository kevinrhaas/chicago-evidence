import pathlib,json,subprocess,datetime,sys
P=pathlib.Path('/tmp/PR1260-own-lap-expiry-reclaim');v=json.loads((P/'initial-verification.json').read_text());expected=v['expected_original_marker'];now=datetime.datetime.now(datetime.timezone.utc);q=subprocess.run(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/lap/pr-1260'],capture_output=True,text=True);row={'at':now.isoformat(),'read_exit':q.returncode}
if q.returncode:
 row.update({'decision':'STOP_UNREADABLE','stderr':q.stderr[-500:]})
else:
 r=json.loads(q.stdout);sha=r.get('object',{}).get('sha');row.update({'observed_sha':sha,'expected_original_sha':expected,'still_exact_own_original':sha==expected,'seconds_until_earliest_reclaim':max(0,(datetime.datetime.fromisoformat(v['earliest_planned_reclaim_after'])-now).total_seconds()),'decision':'STOP_CHANGED_REF' if sha!=expected else 'READY_FOR_FRESH_NATIVE_STATUS' if now>=datetime.datetime.fromisoformat(v['earliest_planned_reclaim_after']) else 'WAIT_OWN_FRESH'})
with (P/'marker-watch.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
print(json.dumps(row));sys.exit(0 if row['decision'].startswith(('WAIT','READY')) else 4)
