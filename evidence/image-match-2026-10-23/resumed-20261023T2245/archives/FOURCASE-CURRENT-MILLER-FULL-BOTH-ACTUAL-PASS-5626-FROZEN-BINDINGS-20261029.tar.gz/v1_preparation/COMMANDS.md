Run only after the root phone meter finishes and root grants the browser lease. The two invocations use separate fresh browser processes and separate trusted profiles. They share the same frozen current native/published inputs. Each output directory must be new. Do not run another publish or source writer during either invocation.

```bash
source /workspace/shared/resume-chicago-env.sh
EARLY_GROUP_APP_HOME=/workspace/miller-current-final-app-inputs-root-20261029 \
EARLY_GROUP_APP_OUT=/workspace/miller-current-final-app-mobile-root-20261029 \
EARLY_GROUP_VIEWPORT=mobile \
EARLY_GROUP_TRUST_PROFILE=/tmp/miller-current-final-app-trust-20261029/mobile \
GIT_NO_LAZY_FETCH=1 \
python3 /workspace/shared/run-with-reaping.py /workspace/miller-current-final-app-mobile-reaper-root-20261029.json -- \
node /workspace/miller-current-final-app-preparation-20261029/review-published-miller-current.mjs \
> /workspace/miller-current-final-app-mobile-controller-root-20261029.log 2>&1
```

After the mobile invocation exits and its actual result/reaper are read, start desktop with a new process:

```bash
source /workspace/shared/resume-chicago-env.sh
EARLY_GROUP_APP_HOME=/workspace/miller-current-final-app-inputs-root-20261029 \
EARLY_GROUP_APP_OUT=/workspace/miller-current-final-app-desktop-root-20261029 \
EARLY_GROUP_VIEWPORT=desktop \
EARLY_GROUP_TRUST_PROFILE=/tmp/miller-current-final-app-trust-20261029/desktop \
GIT_NO_LAZY_FETCH=1 \
python3 /workspace/shared/run-with-reaping.py /workspace/miller-current-final-app-desktop-reaper-root-20261029.json -- \
node /workspace/miller-current-final-app-preparation-20261029/review-published-miller-current.mjs \
> /workspace/miller-current-final-app-desktop-controller-root-20261029.log 2>&1
```

Each successful invocation writes RESULT.json with `PASS_CURRENT_MILLER_TARGETED_PUBLISHED_APP` and exactly its actual viewport. BOTH requires the two independent actual PASS results and all-children-reaped true for both. This preparation is not an app verdict. Native Full detail is asserted; no local-storage detail override was added. Current Miller Normal/ByGrade, native full image response bytes and credits, viewer close/release, singular attested wording, Sources/liberty/Research, model bounds/feet/exact attributes/placement, exact served WEB, zero errors, native consumed sign/frontage/woodpile rows and emitted ownership ranges, and both doors at 3 m and 2 m retain their existing assertions. Pictures are diagnostic; no historic From-this-spot, prompt-free screenshot, FPS, full renderer matrix or automatic original completion claim.

The profiles under /tmp/miller-current-final-app-trust-20261029 contain certificate trust material and later browser state. They are excluded from every checkpoint/archive. Only hash/path metadata is in this preparation packet. Do not copy profile files into evidence.
