import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {reviewHeldPicture} from './held-picture-review.mjs';
const require=createRequire('/workspace/shared/node/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const home=process.env.EARLY_GROUP_APP_HOME,out=process.env.EARLY_GROUP_APP_OUT;
assert(home&&out,'Freeze current final source and choose a new output directory');fs.mkdirSync(out);
assert(['mobile','desktop'].includes(process.env.EARLY_GROUP_VIEWPORT),'One explicit viewport per fresh browser invocation is required');
const root='/workspace/chicago/site';
const cases=[['miller','miller_house',/Blanchard|Shober/i,[/roof flue and upper windows/i,/pictured lower wing and independent roof/i]],['hogan','hogan_store',/Cameron/i,/pictured end courses and stack cap/i],['mary','st_marys_church',/Moss|Andreas/i,/high front windows/i],['lighthouse','chicago_lighthouse_1832',/Castelnau/i,null]].filter(([label])=>label==='miller').map(([label,sid,credit,liberty])=>({label,sid,credit,liberty,expected:JSON.parse(fs.readFileSync(path.join(home,label,'APP-EXPECTED.json')))}));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const bindings=JSON.parse(fs.readFileSync(path.join(home,'miller/SOURCE-BINDINGS.json'))).paths;
function guard(){for(const p of bindings)assert.equal(sha(fs.readFileSync(p.path)),p.sha256,p.path);}
guard();
const save=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n');
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon'};
const serverErrors=[];
const server=http.createServer((req,res)=>{try{
 let f=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));if(!f.startsWith(root+path.sep)){res.writeHead(403).end();return;}
 if(fs.existsSync(f)&&fs.statSync(f).isDirectory())f=path.join(f,'index.html');if(!fs.existsSync(f)||!fs.statSync(f).isFile()){res.writeHead(404).end();return;}
 res.setHeader('Content-Type',types[path.extname(f)]||'application/octet-stream');fs.createReadStream(f).on('error',e=>{serverErrors.push(e.message);res.destroy(e);}).pipe(res);
}catch(e){serverErrors.push(e.message);res.writeHead(500).end();}});
async function pane(page,key){await page.locator(`#nav-app-inspect [data-insp-tab="${key}"]`).click();await page.waitForFunction(k=>document.querySelector(`#nav-app-inspect [data-insp-pane="${k}"]`)?.dataset.filled==='yes',key,{timeout:90000});const p=page.locator(`#nav-app-inspect [data-insp-pane="${key}"]`);await p.evaluate(x=>{for(const d of x.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});return p;}
async function observed(page,p,label,key){const x=await p.evaluate(p=>({text:p.innerText,visible:p.checkVisibility(),overflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1}));assert(x.visible&&!x.overflow&&!x.paneOverflow);save(label+'-'+key+'.json',x);return x;}
let browser;const results=[];
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const launch={executablePath:process.env.PW_EXECUTABLE||'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']};
 if(process.env.EARLY_GROUP_TRUST_PROFILE){const persistent=await chromium.launchPersistentContext(process.env.EARLY_GROUP_TRUST_PROFILE,{...launch,ignoreHTTPSErrors:false});browser=persistent.browser();}else browser=await chromium.launch(launch);
 for(const[viewport,width,height,touch]of[['mobile',390,780,true],['desktop',1280,800,false]].filter(v=>!process.env.EARLY_GROUP_VIEWPORT||v[0]===process.env.EARLY_GROUP_VIEWPORT)){
  const context=await browser.newContext({viewport:{width,height},hasTouch:touch,deviceScaleFactor:touch?2:1});const page=await context.newPage();page.setDefaultTimeout(180000);
  const errors=[],network=[],cancelled=[],served={},responseWork=[];
  const pictureURLs=new Set(cases.map(c=>new URL(c.expected.photo.display,c.expected.photo.base_url).href)),pictureResponses=new Map(),pictureWaiters=new Map();
  const pictureDelivery=url=>{
   if(pictureResponses.has(url))return Promise.resolve(pictureResponses.get(url));
   return new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('No actual browser full-picture response: '+url)),90000);(pictureWaiters.get(url)??pictureWaiters.set(url,[]).get(url)).push(r=>{clearTimeout(timer);resolve(r);});});
  };
  page.on('response',r=>{if(!pictureURLs.has(r.url()))return;pictureResponses.set(r.url(),r);for(const resolve of pictureWaiters.get(r.url())??[])resolve(r);pictureWaiters.delete(r.url());});
  page.on('pageerror',e=>errors.push(e.message));
  page.on('requestfailed',r=>(r.failure()?.errorText==='net::ERR_ABORTED'?cancelled:network).push({url:r.url(),failure:r.failure()}));
  page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});for(const c of cases){const name=path.basename(c.expected.sidecar.asset);if(new URL(r.url()).pathname.endsWith('/'+name))responseWork.push(r.body().then(b=>{(served[c.sid]??=[]).push({url:r.url(),status:r.status(),bytes:b.length,sha256:sha(b)});}));}});
  const start=Date.now();const completed=[];
  try{
   await context.addInitScript(()=>localStorage.setItem('chicago4d.researcher','on'));
   assert.equal((await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835&keep-geometry=1`)).status(),200);
   await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:600000,polling:1000});
   await page.evaluate(async()=>{const a=window.__chicago4d,end=Date.now()+90000;while(a.welcome?.state!=='world'&&Date.now()<end){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}if(a.welcome?.state!=='world')throw Error('Welcome did not enter world');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.setAnimationHold(true);a.popup.close();a.navigator.dock();await a.capture(1);});
   save(viewport+'-WORLD-READY.json',{at:new Date().toISOString(),milliseconds:Date.now()-start,scope:'One actual Miller scene boot at this viewport; no FPS claim.'});
   for(const c of cases){
    const label=viewport+'-'+c.label,expected=c.expected;save('PHASE.json',{at:new Date().toISOString(),viewport,case:c.label,phase:'body'});
    const diag=await page.evaluate(sid=>{const a=window.__chicago4d,r=a.registry.get(sid);return{scene:a.scene.id,sidecar:r?.sidecar,bounds:a.buildings.instanceBounds()[sid],feet:a.buildings.feetOf(sid),problems:a.problems??[],flagged:[...a.registry.values()].filter(r=>r.sidecar?.review_required).map(r=>r.sidecar.id).sort()};},c.sid);
    assert.equal(diag.scene,'1835');assert.equal(diag.sidecar.id,c.sid);assert.equal(diag.sidecar.phase,expected.sidecar.phase);assert.deepEqual(diag.sidecar.grade,expected.grade);assert.deepEqual(diag.sidecar.placement,expected.placement);
    for(const[k,v]of Object.entries(expected.attributes)){assert.deepEqual(diag.sidecar.attributes[k]?.value,v.value,c.sid+'/'+k);assert.equal(diag.sidecar.attributes[k]?.confidence,v.confidence,c.sid+'/'+k);}
    assert(diag.bounds.size.every(v=>Number.isFinite(v)&&v>0));assert(diag.feet.length&&diag.feet.flat().every(Number.isFinite));
    assert.deepEqual(diag.problems.filter(p=>/review_required is set/.test(p)).map(p=>p.split(':',1)[0]).sort(),diag.flagged);assert.deepEqual(diag.problems.filter(p=>!/provisional|PLACEHOLDER|placeholder|review_required is set/i.test(p)),[]);save(label+'-runtime.json',diag);
    if(c.label==='miller'){
     const props=await page.evaluate(sid=>{const a=window.__chicago4d,spans=[];a.yard.group.traverse(m=>{const own=(m.userData?.spans??[]).filter(s=>s.id===sid);if(own.length)spans.push({mesh:m.name,vertices:m.geometry?.getAttribute('position')?.count??0,visible:m.visible,parentVisible:m.parent?.visible,spans:own,items:(m.userData?.lotItemSpans??[]).filter(s=>s.id===sid)});});return{rows:{signs:a.signage.signs.filter(s=>s.structure_id===sid),frontages:a.yard.frontages.filter(s=>s.structure_id===sid),woodpiles:a.yard.woodpiles.filter(s=>s.structure_id===sid)},signSpans:a.signage.spans.filter(s=>s.id===sid),yardSpans:spans,detail:a.detail,scope:'Actual consumed native Miller sign/frontage/woodpile rows and emitted ownership ranges. Visibility flags retained; far/tier visibility is not inferred from record presence.'};},c.sid);
     assert.equal(props.detail,'full','Miller review retains native Full detail');assert.deepEqual(props.rows,expected.changed_props);assert.equal(props.signSpans.length,1);assert(props.signSpans.every(s=>s.to>s.from));assert.equal(props.yardSpans.flatMap(m=>m.spans).length,2);assert(props.yardSpans.every(m=>m.vertices>0&&m.spans.every(s=>s.to>s.from&&s.to*3<=m.vertices)));assert.equal(props.yardSpans.flatMap(m=>m.items).length,2);save(label+'-changed-props.json',props);
    }
    if(c.label!=='lighthouse'){
    const pose=await page.evaluate(async sid=>{const a=window.__chicago4d,s=a.registry.get(sid).sidecar,b=a.buildings.instanceBounds()[sid],m=a.buildings.matrixOf(sid).elements,poly=s.footprint.polygon;
     const loU=Math.min(...poly.map(p=>p[0])),hiU=Math.max(...poly.map(p=>p[0])),hiV=Math.max(...poly.map(p=>p[1]));const w=(u,v,y)=>({e:m[0]*u+m[4]*y-m[8]*v+m[12],n:-(m[2]*u+m[6]*y-m[10]*v+m[14]),y:m[1]*u+m[5]*y-m[9]*v+m[13]});
     const midU=(b.min[0]+b.max[0])/2,midV=-(b.min[2]+b.max[2])/2,aim=w(midU,midV,(b.min[1]+b.max[1])/2),wall=w((loU+hiU)/2,hiV,b.min[1]),front=w((loU+hiU)/2,hiV+1,b.min[1]),right=w((loU+hiU)/2+1,hiV,b.min[1]);
     a.popup.close();a.navigator.dock();a.setFly(true);let result;
     for(let scale=1;scale<=4;scale+=.25){const d=1.5*Math.max(...b.size)*scale,e=wall.e+(front.e-wall.e)*d+(right.e-wall.e)*.32*d,n=wall.n+(front.n-wall.n)*d+(right.n-wall.n)*.32*d,eye={e,n,y:a.walker.surfaceAt(e,n)+2.5};
      a.walker.teleport({local_e:e,local_n:n,yaw_deg:Math.atan2(aim.e-e,aim.n-n)*180/Math.PI,pitch_deg:Math.atan2(aim.y-eye.y,Math.hypot(aim.e-e,aim.n-n))*180/Math.PI,altitude_m:eye.y-a.walker.surfaceAt(e,n)});await a.capture(1);const corners=[];
      for(const u of[b.min[0],b.max[0]])for(const v of[-b.max[2],-b.min[2]])for(const y of[b.min[1],b.max[1]]){const p=w(u,v,y);corners.push(a.project(p.e,p.n,p.y));}result={scale,eye,aim,corners};if(corners.every(p=>Math.abs(p.x)<.88&&Math.abs(p.y)<.88&&p.z>-1&&p.z<1))break;
     }if(!result.corners.every(p=>Math.abs(p.x)<.88&&Math.abs(p.y)<.88&&p.z>-1&&p.z<1))throw Error('Full target does not fit viewport');return result;},c.sid);save(label+'-pose.json',pose);
    for(const[mode,on]of[['normal',false],['ByGrade',true]]){await page.evaluate(async on=>{const a=window.__chicago4d;a.setConfidenceView(on);await a.capture(1);},on);const state=await page.evaluate(()=>{const a=window.__chicago4d;return{...a.stats(),confidenceView:a.confidenceView,world:a.welcome.state,homeHidden:document.getElementById('gate').hidden,flying:a.walker.state.flying,hudFlying:a.hud.flying,intentFlying:a.intent.flying};});assert.equal(state.world,'world');assert(state.homeHidden&&state.withinBudget&&state.flying&&state.hudFlying&&state.intentFlying);assert.equal(state.confidenceView,on);save(label+'-'+mode+'.json',state);if(!on||c.label==='miller')await page.screenshot({path:path.join(out,label+'-'+mode+'.png')});}
    }
    await page.evaluate(async sid=>{const a=window.__chicago4d;a.setConfidenceView(false);a.pick(sid);await a.navigator.select('inspect');a.navigator.open(2);},c.sid);await page.waitForFunction(sid=>document.querySelector('#nav-app-inspect')?.dataset.structure===sid,c.sid);
    const photos=await pane(page,'photos');await reviewHeldPicture(page,photos,expected,label,out,pictureDelivery);const photoText=await observed(page,photos,label,'photos');assert.match(photoText.text,c.credit);assert.doesNotMatch(photoText.text,/From this spot/i);
    const sources=await pane(page,'sources');const sourceText=await observed(page,sources,label,'sources');assert.match(sourceText.text,c.credit);
    if(c.liberty){for(const pattern of[ c.liberty ].flat()){const liberty=sources.locator('.src-lib > summary').filter({hasText:pattern});assert.equal(await liberty.count(),1,'one exact named liberty heading');await liberty.scrollIntoViewIfNeeded();assert(await liberty.isVisible());}}
    const research=await pane(page,'research');const researchText=await observed(page,research,label,'research');assert.match(researchText.text,/Attested\. Pictured: a picture on the Images tab shows it\./);assert.doesNotMatch(researchText.text,/Pictured: 2 of the pictures/);
    let ground={scope:c.label==='lighthouse'?'Physical lighthouse inputs unchanged; dated body proof retained separately. No new body/ground pose claimed.':'Footprint, placement, native exterior doors and ground-only geometry unchanged; prior ground proof retained separately. No new approach probe claimed.'};
    if(c.label==='miller'){
    ground=await page.evaluate(async({sid,expectedDoors})=>{const a=window.__chicago4d,doc=await fetch('../data/enclosures/town_entrance_aprons.json').then(r=>{if(!r.ok)throw Error('Native entrances missing');return r.json();}),doors=doc.entrances.filter(d=>d.structure_id===sid);if(JSON.stringify(doors)!==JSON.stringify(expectedDoors))throw Error('Native entrance binding changed');a.setFly(false);a.navigator.dock();a.popup.close();const probes=[];
     if(doors.length){for(const d of doors){const b=d.bearing_deg*Math.PI/180;for(const distance of[3,2])probes.push({id:d.id,distance,e:d.at_local_enu_m[0]+Math.sin(b)*distance,n:d.at_local_enu_m[1]+Math.cos(b)*distance,yaw:(d.bearing_deg+180)%360});}}
     else{const p=a.registry.get(sid).sidecar.placement,b=a.buildings.instanceBounds()[sid],radius=Math.hypot(b.size[0],b.size[2])/2+3;for(const[e,n]of[[p.local_e+radius,p.local_n],[p.local_e-radius,p.local_n],[p.local_e,p.local_n+radius],[p.local_e,p.local_n-radius]])if(!a.terrain.isWater(e,n)&&!a.router.blockedAt(e,n)){probes.push({id:'dry exterior approach, no compiled door',e,n,yaw:Math.atan2(p.local_e-e,p.local_n-n)*180/Math.PI});break;}}
     if(!probes.length)throw Error('No dry exterior approach');const samples=[];for(const p of probes){a.walker.teleport({local_e:p.e,local_n:p.n,yaw_deg:p.yaw});await a.capture(1);samples.push({...p,water:a.terrain.isWater(p.e,p.n),blocked:a.router.blockedAt(p.e,p.n),surface:a.walker.surfaceAt(p.e,p.n),ground:a.walker.state.groundY,eye:a.walker.state.eyeY,eActual:a.walker.state.e,nActual:a.walker.state.n,flying:a.walker.state.flying,hudFlying:a.hud.flying,intentFlying:a.intent.flying});}return{doors,samples,scope:'Actual native exterior approaches; no indoor traversal claim.'};},{sid:c.sid,expectedDoors:expected.entrances});
    for(const p of ground.samples){assert(!p.water&&!p.blocked);assert(!p.flying&&!p.hudFlying&&!p.intentFlying);assert(Math.abs(p.ground-p.surface)<1e-6);assert(p.eye>p.ground);assert(Math.hypot(p.eActual-p.e,p.nActual-p.n)<.01);}save(label+'-ground.json',ground);await page.screenshot({path:path.join(out,label+'-ground.png')});
    }
    await Promise.all(responseWork);assert(served[c.sid]?.length);assert(served[c.sid].every(r=>r.status===200&&r.sha256===expected.WEB_sha256));assert.deepEqual(errors,[]);assert.deepEqual(network,[]);assert.deepEqual(serverErrors,[]);
    const result={viewport,case:c.label,status:'PASS',selected_WEB:served[c.sid],credited_picture:expected.photo,actual_new_body_modes:c.label!=='lighthouse',actual_new_ground:c.label==='miller',ground_scope:ground.scope};completed.push(result);save(label+'-RESULT.json',result);console.log(label+': targeted changed consumers/grade/WEB/picture/source/research PASS');
   }
   const result={viewport,status:'PASS',world_boots:1,cases:completed,errors,network,cancelled,served,elapsed_ms:Date.now()-start};results.push(result);save(viewport+'-RESULT.json',result);guard();
  }catch(e){save(viewport+'-FAIL.json',{message:e.message,stack:e.stack,completed,errors,network,cancelled,served});await page.screenshot({path:path.join(out,viewport+'-FAIL.png')}).catch(()=>{});throw e;}finally{await context.close();}
 }
 assert.equal(results.length,process.env.EARLY_GROUP_VIEWPORT?1:2);guard();save('RESULT.json',{status:'PASS_CURRENT_MILLER_TARGETED_PUBLISHED_APP',actual_viewports:results.map(r=>r.viewport),both_viewports_in_this_invocation:results.length===2,results,scope:'Miller only at the single actual_viewport listed above, in a fresh browser invocation. Actual full picture open/credit/close with delivered-byte proof; exact model/record/grade and zero errors. Actual Normal/ByGrade, native sign/frontage/woodpile consumed rows and emitted ownership ranges, and both exterior door approaches at3m/2m. Full detail retained. Other three original cases remain separately dated/inputbound; no general renderer matrix, FPS, historical camera, prompt-free screenshot or automatic originalDONE claim. Two independently successful invocations are required for BOTH.'});
}finally{if(browser)await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));}
