"""Plan the native GT smoke grid; --dispatch requires root's concrete exact-head grant."""
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import quote
import json,hashlib,argparse,datetime,time,importlib.util,re
P=argparse.ArgumentParser(description=__doc__)
for n in ['head','ref','pr','qualification','output']:P.add_argument('--'+n,required=True)
P.add_argument('--dispatch',action='store_true');P.add_argument('--grant');P.add_argument('--resume-ledger');a=P.parse_args();assert re.fullmatch('[0-9a-f]{40}',a.head) and a.ref.startswith('steward/t2376-') and str(a.pr).isdigit()
O=Path(a.output);O.mkdir(exist_ok=False);save=lambda n,x:(O/n).write_text(json.dumps(x,indent=2)+'\n');sha=lambda b:hashlib.sha256(b).hexdigest()
s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);qpath=Path(a.qualification);qraw=qpath.read_bytes();q=json.loads(qraw)
assert q['schema']=='CHICAGO_GT_NATIVE_FULL_SMOKE_DISPATCH_V1' and q['status']=='ACTUAL_GT_CHECKED_PUSHED_DRAFT_READY_FOR_NATIVE_FULL_SMOKE'
required={'current_upstream_composition_checked','native_owners_settled_current','four_targeted_Full_app_cases_pass','all_three_credited_pictures_open_at_both_viewports','actual_fullcheck_pass','actual_phone_pass','native_one_ticket_commit_actual','immutable_pushed_head_tree_readback_pass','draft_PR_open_into_dev','all30_parts_required_by_changed_shared_renderer_inputs','remote_GT_head_frozen_during_smokes'}
assert set(q['checks'])==required and all(v is True for v in q['checks'].values());assert q['binding']['head']==a.head and q['binding']['ref']==a.ref and q['binding']['pr']==int(a.pr)
assert {'fullgate','phone','targeted_app','native_commit','publication','smoke_budget'}<=set(q['evidence'])
for r in q['evidence'].values():
 p=Path(r['path']);assert p.is_file() and not p.is_symlink() and str(p).startswith('/workspace/')and not any(x in str(p).lower()for x in ['profile','certdb','cookies','key4.db']);b=p.read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
def guard():
 p=m.api('pulls/'+a.pr);assert p['state']=='open' and p['draft']is True and p['head']['sha']==a.head and p['head']['ref']==a.ref and p['head']['repo']['full_name']==m.REPO and p['base']['ref']=='dev' and p['base']['repo']['full_name']==m.REPO and'hold'not in {x['name']for x in p['labels']};assert m.api('git/ref/heads/'+a.ref)['object']['sha']==a.head;return p
pr=guard();save('PR-BEFORE.json',pr);native=m.api('git/commits/'+a.head);assert native['tree']['sha']==q['binding']['tree'];workflow=m.api('actions/workflows/chicago-4d-smoke.yml');assert workflow['state']=='active' and workflow['path']=='.github/workflows/chicago-4d-smoke.yml';save('WORKFLOW.json',workflow)
with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+a.head+'/'+workflow['path'],headers={'User-Agent':'GT-native-smoke-exact-workflow-guard'}),timeout=60)as f:actual=f.read()
reviewed=(Path(__file__).parent/'NATIVE-WORKFLOW-72c03.yml').read_bytes();assert actual==reviewed and sha(actual)==q['binding']['native_workflow_sha256'];assert b'concurrency:'not in actual and b'runs-on: ubuntu-24.04'in actual and b'timeout-minutes: 150'in actual;save('NATIVE-WORKFLOW-BINDING.json',{'head':a.head,'path':workflow['path'],'sha256':sha(actual),'public_standard_ubuntu_runner':True,'workflow_unmodified':True})
schedule=[('desktop',13),('mobile',13)]+[(v,n)for n in range(1,16)if n!=13 for v in ['desktop','mobile']];assert len(schedule)==30 and len(set(schedule))==30
plan={'status':'PLAN_ONLY_NO_DISPATCH','head':a.head,'tree':native['tree']['sha'],'ref':a.ref,'PR':int(a.pr),'workflow_id':workflow['id'],'workflow_path':workflow['path'],'qualification_path':str(qpath),'qualification_sha256':sha(qraw),'native_workflow_sha256':sha(actual),'keep_PR_draft':True,'schedule':[{'viewport':v,'stage':str(n),'body':{'ref':a.ref,'inputs':{'viewport':v,'stage':str(n)}}}for v,n in schedule],'mapping':'Sequential exact request; BEFORE/AFTER workflow_id+workflow_dispatch+head+branch run-ID sets must identify exactly one new run. No title-based inference. Raw completion logs must independently prove viewport/stage/published command.','no_workflow_changes_premium_runner_or_source_writes':True};save('PLAN.json',plan)
prior=[]
if a.resume_ledger:
 priorpath=Path(a.resume_ledger);priorraw=priorpath.read_bytes();old=json.loads(priorraw)
 assert old['head']==a.head and old['tree']==native['tree']['sha']and old['ref']==a.ref and old['PR']==int(a.pr) and old['workflow_id']==workflow['id']and old['qualification_sha256']==sha(qraw)
 assert old['status']in {'DISPATCHING_NOT_A_SMOKE_PASS','ALL30_NATIVE_WORKFLOW_DISPATCHES_UNIQUELY_BOUND_RESULTS_PENDING'}
 prior=old['dispatches'];pairs=set();attempts=list(priorpath.parent.glob('*-ATTEMPT.json'));assert len(attempts)==len(prior),'An unfinished/unknown POST attempt exists: reconcile its actual run before resuming; never redispatch blindly'
 for r in prior:
  pair=(r['request']['inputs']['viewport'],int(r['request']['inputs']['stage']));assert pair in schedule and pair not in pairs and r['HTTP']==204 and r['status']=='ACTUAL_204_AND_UNIQUE_EXACT_HEAD_RUN_ID_BOUND_NOT_SMOKE_RESULT';pairs.add(pair)
  run=m.api('actions/runs/'+str(r['run_id']));assert run['head_sha']==a.head and run['head_branch']==a.ref and run['workflow_id']==workflow['id']and run['event']=='workflow_dispatch'
 assert len({r['run_id']for r in prior})==len(prior)
 plan['resume_ledger']={'path':str(priorpath),'sha256':sha(priorraw),'already_uniquely_bound':len(prior),'no_blind_retry':True};save('PLAN.json',plan)
if not a.dispatch:print(json.dumps(plan,indent=2));raise SystemExit(0)
assert a.grant=='root-reviewed-GT-'+a.head+'-PR'+a.pr+'-30-native-smokes'
def runs():
 url='actions/workflows/chicago-4d-smoke.yml/runs?event=workflow_dispatch&head_sha='+a.head+'&branch='+quote(a.ref,safe='')+'&per_page=100';r=m.api(url);assert r['total_count']<=100,'Require explicit pagination review for an unexpected crowded exact-head queue'
 return {x['id']:x for x in r['workflow_runs']if x['workflow_id']==workflow['id']and x['event']=='workflow_dispatch'and x['head_sha']==a.head and x['head_branch']==a.ref}
ledger={'status':'DISPATCHING_NOT_A_SMOKE_PASS','head':a.head,'tree':native['tree']['sha'],'ref':a.ref,'PR':int(a.pr),'workflow_id':workflow['id'],'native_workflow_sha256':sha(actual),'qualification_sha256':sha(qraw),'dispatches':list(prior)};save('DISPATCHES.json',ledger)
for number,(viewport,stage) in enumerate(schedule,1):
 if any(r['request']['inputs']=={'viewport':viewport,'stage':str(stage)}for r in prior):continue
 guard();before=runs();body={'ref':a.ref,'inputs':{'viewport':viewport,'stage':str(stage)}};attempt={'sequence':number,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':body,'before_exact_head_run_ids':sorted(before)};name=str(number).zfill(2)+'-ATTEMPT.json';save(name,attempt)
 try:
  req=Request('https://api.github.com/repos/'+m.REPO+'/actions/workflows/chicago-4d-smoke.yml/dispatches',data=json.dumps(body).encode(),headers={'User-Agent':'GT-root-granted-native-30-part-smoke','Accept':'application/vnd.github+json','Content-Type':'application/json'},method='POST')
  with urlopen(req,timeout=60)as f:assert f.status==204 and f.read()==b''
 except Exception as e:
  attempt.update(status='UNKNOWN_OR_FAILED_ACCEPTANCE_STOP_DO_NOT_RETRY_BLINDLY',error_type=type(e).__name__);save(name,attempt);raise
 attempt['HTTP']=204;save(name,attempt);deadline=time.monotonic()+120;new={}
 while time.monotonic()<deadline:
  after=runs();new={k:v for k,v in after.items()if k not in before}
  if len(new)>1:
   attempt.update(status='AMBIGUOUS_NEW_RUN_IDS_STOP_NO_INPUT_MAPPING_CLAIM',new_run_ids=sorted(new));save(name,attempt);raise RuntimeError('More than one new exact-head native workflow run; manual attribution required')
  if len(new)==1:break
  time.sleep(2)
 if len(new)!=1:
  attempt.update(status='ACTUAL_204_NO_UNIQUE_RUN_OBSERVED_STOP_RESULTS_UNKNOWN');save(name,attempt);raise RuntimeError('204 accepted but no unique exact-head run discovered; do not redispatch blindly')
 rid,run=next(iter(new.items()));assert run['run_attempt']==1;guard();attempt.update(status='ACTUAL_204_AND_UNIQUE_EXACT_HEAD_RUN_ID_BOUND_NOT_SMOKE_RESULT',run_id=rid,run_head=run['head_sha'],run_branch=run['head_branch'],workflow_id=run['workflow_id'],run_created_at=run['created_at'],run_html_url=run['html_url']);save(name,attempt);save(str(number).zfill(2)+'-RUN-CREATED.json',run);ledger['dispatches'].append(attempt);save('DISPATCHES.json',ledger);print(json.dumps({'sequence':number,'viewport':viewport,'stage':stage,'run_id':rid,'head':a.head,'result':'CREATED_NOT_PASSED'}),flush=True)
ledger['status']='ALL30_NATIVE_WORKFLOW_DISPATCHES_UNIQUELY_BOUND_RESULTS_PENDING';ledger['finished_dispatching_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('DISPATCHES.json',ledger);save('PR-AFTER-DISPATCH.json',guard());print('ALL30_CREATED_NO_SMOKE_PASS_CLAIM',flush=True)
