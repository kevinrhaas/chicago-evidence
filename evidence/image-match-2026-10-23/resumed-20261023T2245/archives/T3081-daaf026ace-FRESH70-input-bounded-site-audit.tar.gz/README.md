# Fresh bounded site audit on daaf + landed dev

Actual live source/data capture:2026-10-24 01:24:42 UTC. All70 site inputs were
read afresh and remained stable through measurement. Root was told capture was
complete before starting full preflight; subsequent closure used frozen copies.
The target is daaf276c with uncommitted incoming026ace; full ids/index fingerprint
are bound in `final-site-receipt.json`.

| Current finding | Result |
| --- | --- |
| Native entrances/buildings | 653 / 651 |
| Wolf primary and additional entries | Both present; exact native apron rings |
| Placed point/fence records read | 3,515 |
| Intersections with Wolf's occupied body | 0 |
| Intersections with either actual doorway zone | 0 |
| Historical four goods intrusion coordinates | All absent |
| Body distance from river/west-bank line | 3.6879m |
| East-facing primary apron distance | 2.1746m |
| South-facing additional apron distance | 11.4517m |
| Native water polygons | All body/apron/doorway regions disjoint |

The reviewed measurement logic uses the authoritative concave footprint, actual
selected-phase entrance rectangles, the current traced EPSG:26916 river/bank
geometry transformed by the project datum, and the existing native point/segment
and raw bilinear terrain readers. No shoreline, tolerance or exception was added.
Both3.4m apron paths retain bearings90°/180°. All terrain and clearance metrics
reproduce exactly from the newly captured regular-file snapshot.

This is a fresh measurement, not an assumption that the previous70 inputs match.
Only68 were byte-exact to the frozen d083 audit. The two changed inputs are stored
under `changed-inputs/`:

- `generators/archetypes/log_dwelling_params.py`: the adopted existing-head
  support for Cobweb's chimney correction;
- `data/yard/town_woodpiles.json`: exactly one of397 woodpile lots changes,
  comprising only Wolf's three item centres. Cordwood(-72.94,-44.04) moves to
  (-74.49,-46.44); cordwood(-75.73,-44.04) to(-77.28,-46.44); chopping block
  (-72.17,-42.33) to(-73.72,-44.73). Seeds, kinds, dimensions, household/class and
  other lot fields remain unchanged. `woodpile-row-delta.json` preserves both rows.

The changed placements were included in the fresh3,515-object intersection check.
All prior site metrics remain exact, but the new source and woodpile bytes are
explicitly retained. `input-reuse.json` references only the68 proven-exact old
inputs under prior manifest
`d0833ab85ac77b0ef02cdbbf7b85cf5e3c8a157b9018a70a5f905a0be182c632`.
Keep that immutable packet with this compact addendum. To reproduce, materialize
its input directory in a fresh folder, overlay the two changed files, and run a
copy of the unchanged `audit_site.py` using `--root ASSEMBLED_INPUTS` and the bound
HEAD. Do not rerun inside a closed packet.

Parent-owned native receipt/focused check logs are copied under `history/`, with
their hashes and provenance in the receipt. The actual native tail reports61
steps in the202-step manifest, two laps, last lap moved nothing; its parent
receipt says all22 lodger cards plus ledger/order book remained exact. Those
commands were not rerun by this audit agent, and no full-gate verdict is claimed.

This instrument measures2D occupied ground, object centres/fence segments and
sampled raw terrain. It does not certify prop mesh radii, roof/eave contact,
actual3D terrain seating, walker passage, published app appearance or any original
image match. The roughly40m along-bank/20m across-bank placement uncertainty stays
in force; the model clearances are not historical surveyed setbacks. No native
writer, Blender, browser, fetch or canonical edit ran for this audit.
