#!/usr/bin/env python3
"""Read current native Wolf footprint/water/entries/objects; write only own receipt."""
import collections
import argparse
import datetime
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ap = argparse.ArgumentParser()
ap.add_argument('--root', type=Path, default=Path('/tmp/chicago-log-integration/chicago/4d'))
ap.add_argument('--frozen-head', help='Original bound HEAD when rereading an archived input snapshot')
args = ap.parse_args()
ROOT = args.root.resolve()
OUT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / 'tools'), str(ROOT / 'generators')]
import check_structure_clearance as c
import generate_entrances as en
import generate_business_signboards as gbs
import generate_frontage_works as gfw
import measure_doorways as doorways
from archetypes.log_dwelling_params import from_phase, side_access_faces
from heightfield import Heightfield

PATHS = [ROOT / p for p in [
    'data/datum.json',
    'data/streets/1835.json',
    'data/structures/wolf_point_tavern.json', 'data/sidecars/1835/wolf_point_tavern.json',
    'data/enclosures/town_entrance_aprons.json', 'data/terrain/epochs/e1834_harbor_cut/river.geojson',
    'data/terrain/epochs/e1834_harbor_cut/branches.geojson',
    'data/terrain/epochs/e1834_harbor_cut/shoreline.geojson',
    'data/terrain/epochs/e1834_harbor_cut/heightfield.json',
    'data/terrain/epochs/e1834_harbor_cut/heightfield.bin',
    'tools/check_structure_clearance.py', 'tools/generate_entrances.py',
    'tools/generate_business_signboards.py', 'tools/generate_frontage_works.py',
    'tools/measure_doorways.py', 'tools/heightfield.py',
    'generators/archetypes/log_dwelling_params.py']]
for sub in ['yard', 'frontage', 'enclosures', 'wells', 'flora/plantings']:
    PATHS += sorted((ROOT / 'data' / sub).glob('*.json'))
PATHS += [ROOT / 'data/signage/town_business_signboards.json']
for module in list(sys.modules.values()):
    filename = getattr(module, '__file__', None)
    if filename:
        path = Path(filename).resolve()
        if ROOT in path.parents and path.suffix == '.py':
            PATHS.append(path)
PATHS = sorted(set(PATHS))
RAW = {p: p.read_bytes() for p in PATHS}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def load(p):
    return json.loads(RAW[ROOT / p])


def closed(poly):
    return list(poly) + [poly[0]] if poly[0] != poly[-1] else list(poly)


def polygon_water(poly, water):
    edges = list(zip(closed(poly), closed(poly)[1:]))
    water_edges = list(zip(closed(water), closed(water)[1:]))
    crossings = sum(gfw._segments_cross(a, b, x, y) for a, b in edges for x, y in water_edges)
    body_inside = [p for p in poly if c.inside(p, water)]
    water_inside = [p for p in water if c.inside(p, poly)]
    nearest = []
    for p in poly:
        d, q = gbs._nearest_on_path(p, closed(water))
        nearest.append((d, p, q))
    for p in water:
        d, q = gbs._nearest_on_path(p, closed(poly))
        nearest.append((d, q, p))
    d, p, q = min(nearest, key=lambda x: x[0])
    return {'proper_edge_crossings': crossings, 'region_vertices_inside_water': body_inside,
            'water_vertices_inside_region': water_inside,
            'disjoint': not crossings and not body_inside and not water_inside and d > 0,
            'distance_m': d, 'nearest_region_point': p, 'nearest_water_edge_point': q}


def bank_distance(poly, line):
    candidates = [(gbs._nearest_on_path(p, line)[0], p, gbs._nearest_on_path(p, line)[1]) for p in poly]
    candidates += [(gbs._nearest_on_path(p, closed(poly))[0], gbs._nearest_on_path(p, closed(poly))[1], p) for p in line]
    d, p, q = min(candidates, key=lambda x: x[0])
    return {'distance_m': d, 'nearest_region_point': p, 'nearest_bank_point': q}


sc = load('data/sidecars/1835/wolf_point_tavern.json')
record = load('data/structures/wolf_point_tavern.json')
phase = next(p for p in record['phases'] if p['id'] == sc['phase'])
params = from_phase(phase, record)
poly = c.placed(sc)
river = load('data/terrain/epochs/e1834_harbor_cut/river.geojson')
datum = load('data/datum.json')
assert river['crs']['properties']['name'] == 'urn:ogc:def:crs:EPSG::26916'
assert datum['crs'] == 'EPSG:26916'
def localize(coords):
    if len(coords) >= 2 and isinstance(coords[0], (int, float)):
        return [coords[0] - datum['origin_utm_e'], coords[1] - datum['origin_utm_n']]
    return [localize(v) for v in coords]
features = {f['id']: {**f, 'geometry': {**f['geometry'], 'coordinates': localize(f['geometry']['coordinates'])}}
            for f in river['features']}
all_hydro_features = dict(features)
for filename in ['branches.geojson', 'shoreline.geojson']:
    doc = load('data/terrain/epochs/e1834_harbor_cut/' + filename)
    assert doc['crs']['properties']['name'] == river['crs']['properties']['name']
    for f in doc['features']:
        all_hydro_features[f['id']] = {**f, 'geometry': {**f['geometry'], 'coordinates': localize(f['geometry']['coordinates'])},
                                       'source_file': filename}
water = features['chicago_river_forks']['geometry']['coordinates'][0]
aprons = load('data/enclosures/town_entrance_aprons.json')
native_entrances = [e for e in aprons['entrances'] if e['structure_id'] == 'wolf_point_tavern']
native_rings = aprons['ground']['interior_local_enu_m']
streets = en._streets()
place = sc['placement']
fu0, fu1, vmax = gbs._front_edge(sc['footprint']['polygon'])
primary_doors, reader = en.front_doors(sc)
bearing = float(place['rotation_deg'])
outward = (math.sin(math.radians(bearing)), math.cos(math.radians(bearing)))


def front_map(along, out):
    e, n = gbs._to_enu(along, vmax, place)
    return e + outward[0] * out, n + outward[1] * out


def entry(id_, face, door, mapping, direction, bearing_, low, high, reverse=False):
    station = (door['u0'] + door['u1']) / 2
    at = mapping(station, 0)
    width = door['u1'] - door['u0']
    depth = en.path_depth(at, direction, streets)
    ring = en._front_ring(low, high, [(station, width / 2, depth)], mapping)
    if reverse:
        ring.reverse()
    hw = width / 2 + en.DOORWAY_SIDE_M
    zone = [mapping(station + s, t) for s, t in [(-hw, 0), (hw, 0), (hw, en.DOORWAY_OUT_M), (-hw, en.DOORWAY_OUT_M)]]
    return {'id': id_, 'face': face, 'at_local_enu_m': at, 'outward_unit_enu': direction,
            'bearing_deg': bearing_, 'width_m': width, 'path_depth_m': depth,
            'path_end_local_enu_m': mapping(station, depth), 'apron_ring': ring,
            'doorway_zone': zone, 'native_entrance_present': any(e['id'] == id_ for e in native_entrances),
            'native_apron_ring_exact_present': ring in native_rings}


entries = [entry('wolf_point_tavern__door_' + str(i + 1), '+y', d, front_map,
                 outward, bearing, fu0, fu1) for i, d in enumerate(primary_doors)]
declared_faces = side_access_faces(params)
for face in declared_faces:
    side_bearing = (bearing + 90) % 360
    direction = (math.sin(math.radians(side_bearing)), math.cos(math.radians(side_bearing)))
    def side_map(along, out, plane=face['plane_m']):
        return gbs._to_enu(plane + out, along, place)
    for i, door in enumerate(face['openings']):
        entries.append(entry('wolf_point_tavern__side_xp_' + door['kind'] + '_' + str(i + 1),
                             '+x', door, side_map, direction, side_bearing, face['u0'], face['u1'], True))

hf = Heightfield.load(ROOT / 'data/terrain/epochs/e1834_harbor_cut')


def heights(ring):
    samples = []
    for a, b in zip(closed(ring), closed(ring)[1:]):
        n = max(1, math.ceil(math.dist(a, b) / c.SAMPLE_M))
        for k in range(n + 1):
            p = [a[j] + (b[j] - a[j]) * k / n for j in (0, 1)]
            samples.append((hf.height(*p), p, hf.covers(*p)))
    minimum = min(samples)
    maximum = max(samples)
    return {'boundary_sample_step_at_most_m': c.SAMPLE_M, 'sample_count': len(samples),
            'all_within_actual_heightfield': all(x[2] for x in samples),
            'min_sampled_raw_ground_m': minimum[0], 'min_sampled_at': minimum[1],
            'max_sampled_raw_ground_m': maximum[0], 'water_surface_m': hf.meta['water_surface_m'],
            'limits': 'Raw native bilinear terrain samples on boundary; not mesh-to-terrain contact or exact surface-extrema certification.'}


regions = {'occupied_body': poly}
for e in entries:
    regions[e['id'] + ':apron'] = e['apron_ring']
    regions[e['id'] + ':doorway'] = e['doorway_zone']
measurements = {}
for label, region in regions.items():
    measurements[label] = {'ring': region, 'river_polygon': polygon_water(region, water),
                           'all_native_water_outer_rings': {name: polygon_water(region, f['geometry']['coordinates'][0])
                                                           for name, f in all_hydro_features.items()
                                                           if f['geometry']['type'] == 'Polygon' and f['properties'].get('kind') == 'water'},
                           'division_shores': {name: bank_distance(region, f['geometry']['coordinates'])
                                               for name, f in features.items() if f['geometry']['type'] == 'LineString'},
                           'sampled_raw_terrain': heights(region)}

objects = doorways.objects()
body_hits, zone_hits = [], []
body_box = c.bbox(poly)
for layer, oid, kind, point, segment, serves in objects:
    if point is not None:
        if c.inside(point, poly):
            body_hits.append({'layer': layer, 'id': oid, 'kind': kind, 'point': point,
                              'depth_m': c.depth_inside(point, poly)})
    else:
        a, b = segment
        if not c.boxes_apart(body_box, c.bbox(segment)) and doorways._seg_inside(a, b, poly):
            body_hits.append({'layer': layer, 'id': oid, 'kind': kind, 'segment': segment})
    for e in entries:
        if serves == 'wolf_point_tavern':
            continue  # Native doorway reader's own-stoop floor exemption only.
        zone = e['doorway_zone']
        if point is not None and doorways._inside(point, zone):
            zone_hits.append({'entry': e['id'], 'layer': layer, 'id': oid, 'kind': kind, 'point': point})
        elif segment and not c.boxes_apart(c.bbox(zone), c.bbox(segment)) and doorways._seg_inside(*segment, zone):
            zone_hits.append({'entry': e['id'], 'layer': layer, 'id': oid, 'kind': kind, 'segment': segment})

historical_path = OUT / 'history/object-check.json'
if not historical_path.exists():
    historical_path = Path('/tmp/chicago-next-model/T-2386-entry-site/object-check.json')
historical = json.loads(historical_path.read_bytes())
old_four = next(x for x in historical['cases'] if x['option'] == 'centre_preserving_rebase')['native_points_or_fence_lines_inside_new_body']
current_points = collections.Counter((layer, oid, kind, tuple(point)) for layer, oid, kind, point, segment, serves in objects if point)
old_comparison = []
for item in old_four:
    key = (item['layer'], item['id'], item['kind'], tuple(item['point']))
    old_comparison.append({**item, 'same_instance_coordinate_in_current_output': bool(current_points[key])})
current_goods = [{'layer': layer, 'id': oid, 'kind': kind, 'at_local_enu_m': point,
                  'inside_occupied_body': c.inside(point, poly), 'body_edge_distance_m': c.edge_distance(point, poly)}
                 for layer, oid, kind, point, segment, serves in objects
                 if layer == 'town_trade_goods.json' and oid == 'wolf_point_tavern' and point]
native_side_faces = en.side_access_faces(sc)
input_bindings = [{'path': str(p.relative_to(ROOT)), 'bytes': len(b), 'sha256': sha(b)} for p, b in RAW.items()]
for p, before_bytes in RAW.items():
    if p.read_bytes() != before_bytes:
        raise SystemExit('REFUSED: an audited input changed while measuring: ' + str(p))
report = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'git_head': args.frozen_head or subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD']).decode().strip(),
          'status': 'NATIVE_SIDE_ENTRY_MISSING' if len(native_entrances) != len(entries) else 'BOUNDED_2D_SITE_AUDIT_COMPLETE',
          'occupied_body_local_enu_m': poly, 'placement': {k: place[k] for k in ['local_e', 'local_n', 'rotation_deg']},
          'river_source': 'data/terrain/epochs/e1834_harbor_cut/river.geojson',
          'river_frame_conversion': {'source_crs': datum['crs'], 'local_enu_equals_utm_minus':
                                     [datum['origin_utm_e'], datum['origin_utm_n']],
                                     'authority': 'river.geojson _doc and data/datum.json'},
          'water_feature': 'chicago_river_forks', 'historical_position_uncertainty_m': phase['position'].get('uncertainty_m'),
          'native_entrance_total': len(aprons['entrances']), 'native_buildings_total': len(aprons['belongs_to']),
          'wolf_native_entries': native_entrances, 'actual_declared_entries': entries,
          'consumer_diagnostic': {'native_side_faces': native_side_faces, 'actual_selected_params_side_faces': declared_faces,
                                 'sidecar_has_top_level_form': 'form' in sc, 'sidecar_attributes_has_compound_joint': 'compound_joint' in sc.get('attributes', {}),
                                 'explanation': ('Current fixed consumer resolves the exact sidecar phase id through the real record and builder params reader; both declared faces are present.'
                                                 if native_side_faces == declared_faces else
                                                 'Compiled sidecars carry form under attributes; a top-level form guard / from_phase(sc) can silently lose compound metadata.')},
          'measurements': measurements, 'current_native_objects_read': len(objects),
          'current_objects_or_fence_segments_inside_body': body_hits,
          'current_objects_or_fence_segments_inside_actual_declared_doorway_zones': zone_hits,
          'native_prop_threshold_m_unchanged': c.PROP_TOL_M,
          'old_four_history_file_sha256': sha(historical_path.read_bytes()), 'old_four_comparison': old_comparison,
          'current_wolf_trade_goods': current_goods, 'input_bindings': input_bindings,
          'limits': 'Read-only LIGHT 2D footprint, native point/segment and raw heightfield diagnostic. No writers, fetch, Blender, browser, full gate, new shoreline, tolerance, exemption or allowance. Points do not certify barrel radii, crate meshes, roof/eaves, source agreement, collision passages or 3D terrain contact. Actual app/3D contact QA and full gates remain owed.'}
(OUT / 'site-audit.json').write_text(json.dumps(report, indent=2) + '\n')
for p, b in RAW.items():
    destination = OUT / 'inputs' / p.relative_to(ROOT)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(b)
(OUT / 'history').mkdir(exist_ok=True)
(OUT / 'history/object-check.json').write_bytes(historical_path.read_bytes())
print(json.dumps({'status': report['status'], 'objects': len(objects), 'body_hits': len(body_hits), 'door_zone_hits': len(zone_hits),
                  'native_wolf_entries': len(native_entrances), 'actual_declared_entries': len(entries),
                  'region_river_distances_m': {k: v['river_polygon']['distance_m'] for k, v in measurements.items()}}, indent=2))
