from pathlib import Path
import json,os,subprocess
W=Path('/workspace');E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
def run(rel):subprocess.run(['python3',str(W/rel)],env=E,check=True)
run('PR1456-final845-native-source-gt-20261030/merge.py')
run('PR1456-final845-pullman-ground-audit-gt-20261030/audit.py')
audit=json.loads((W/'PR1456-final845-pullman-ground-audit-gt-20261030/RESULT.json').read_bytes())
if audit['official_frontyard_owner_needed']:run('PR1456-final845-early-frontyard-gt-20261030/run.py')
run('PR1456-final845-preliminary-native-owners-gt-20261030/run.py')
run('PR1456-final845-ungated-failfast-phone-gt-20261030/run.py')
