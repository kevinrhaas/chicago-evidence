"""Root-authorized diagnostic only: UNCOMMITTED/UNGATED845 WORKTREE.
No source gate/final checked-head phone claim. Retain actual native failure.
"""
from pathlib import Path
import datetime,hashlib,json,os,shutil,struct,subprocess,time
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path(__file__).parent
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
HEAD='64d5710e7707683aa1dbaca1efacbbe1854970c0';PARENT='845446b26378b90a3dc455a4a456e5927c0123e8'
CONFIG='5536e1343e7abdacddfce3d5438e08872ad6a33295900466b529df5e0c57e730'
g=lambda *a:subprocess.check_output(['git','-C',str(R),*a],env=E)
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n')
def consumer_map():
 paths={R/p.decode()for p in g('ls-files','-z','--','chicago/4d').split(b'\0')if p}
 paths.update(p for p in(R/'site/4d').rglob('*')if p.is_file())
 out={}
 for p in sorted(paths):
  assert p.is_file(),p
  with p.open('rb')as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
  out[p.relative_to(R).as_posix()]={'sha256':digest,'bytes':p.stat().st_size,'mode':p.lstat().st_mode,'symlink_target':os.readlink(p)if p.is_symlink()else None}
 return out
def git_state():
 return {'HEAD':g('rev-parse','HEAD').decode().strip(),'MERGE_HEAD':g('rev-parse','MERGE_HEAD').decode().strip(),'origin_dev':g('rev-parse','origin/dev').decode().strip(),'tree':g('write-tree').decode().strip(),'index_sha256':sha((R/'.git/index').read_bytes()),'config_sha256':sha((R/'.git/config').read_bytes()),'status':g('status','--porcelain=v1').decode(),'allrefs':sha(g('for-each-ref','--format=%(refname) %(objectname)')),'all_staged_paths':{p:sha((R/p).read_bytes())for p in g('diff','--cached','--name-only').decode().splitlines()}}
assert not(O/'BINDING.json').exists()
assert not g('ls-files','-u')and not g('diff','--name-only')and not g('ls-files','--others','--exclude-standard')
state=git_state();assert state['HEAD']==HEAD and state['MERGE_HEAD']==PARENT and state['origin_dev']==PARENT and state['config_sha256']==CONFIG
rows=consumer_map();save('ALL-CONSUMER-BINDINGS.json',rows)
def fawn_payloads(path):
 b=path.read_bytes();assert b[:4]==b'glTF';n,kind=struct.unpack_from('<II',b,12);assert kind==0x4e4f534a;j=json.loads(b[20:20+n]);start=28+n;out={}
 for im in j['images']:
  if im.get('name','').startswith('sandstone_fawn_'):
   assert im['mimeType']=='image/ktx2'and'bufferView'in im;view=j['bufferViews'][im['bufferView']];assert view['buffer']==0;a=start+view.get('byteOffset',0);raw=b[a:a+view['byteLength']];assert raw[:12]==b'\xabKTX 20\xbb\r\n\x1a\n';out[im['name']]={'bytes':len(raw),'sha256':sha(raw),'width':struct.unpack_from('<I',raw,20)[0],'height':struct.unpack_from('<I',raw,24)[0]}
 assert set(out)=={'sandstone_fawn_basecolor','sandstone_fawn_normal_gl'}
 return out
name='pullman_house_1729_prairie__as_mapped_1904.glb';native_fawn=fawn_payloads(A/'assets/web'/name);published_fawn=fawn_payloads(R/'site/4d/data/gltf'/name);assert native_fawn==published_fawn
assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
save('BINDING.json',{'status':'UNCOMMITTED_UNGATED845_WORKTREE_DIAGNOSTIC_ONLY','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':state,'all_native_and_published_consumer_files':len(rows),'consumer_bindings_sha256':sha((O/'ALL-CONSUMER-BINDINGS.json').read_bytes()),'new_fawn_embedded_KTX2_images_native_published_exact':native_fawn,'source_gate_and_final_checked_head_phone_NOT_RUN':True})
start=time.monotonic();rp=O/'PHONE-REAPER.json'
with(O/'phone.log').open('x')as log:
 q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','taskset','-c','0,1,3,4','timeout','150s','node','tools/measure_memory.mjs','--year','1904','--only','mobile','--gate','--no-snapshot','--json',str(O/'PHONE.json')],cwd=A,env=E,stdout=log,stderr=subprocess.STDOUT)
reaper=json.loads(rp.read_bytes());guards={'git_state_exact':git_state()==state,'all_consumer_bytes_modes_links_and_fileset_exact':consumer_map()==rows,'all_children_reaped':reaper['all_children_reaped']}
phone=json.loads((O/'PHONE.json').read_bytes())if(O/'PHONE.json').exists()else None
row=phone['rows'][0]if phone and len(phone['rows'])==1 else None
peak=row['totals']['total']/1048576 if row else None
passed=q.returncode==0 and all(guards.values())and peak is not None and peak<=400 and not row['errors']
save('RESULT.json',{'status':'ACTUAL_UNCOMMITTED_UNGATED845_DIAGNOSTIC_PHONE_PASS'if passed else'ACTUAL_UNCOMMITTED_UNGATED845_DIAGNOSTIC_PHONE_FAILED_OR_UNQUALIFIED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':q.returncode,'seconds':time.monotonic()-start,'head':HEAD,'merge_parent':PARENT,'staged_tree':state['tree'],'peak_MiB':peak,'unchanged_limit_MiB':400,'guards':guards,'errors':row.get('errors')if row else None,'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free,'limits':'Diagnostic on actual published but UNCOMMITTED/UNGATED845 composition. Full61/full1105/ordinary checked native commit/final same-head phone/current CI/dev merge still owed. No source/Git/ref/model/material edits by phone.'})
print((O/'RESULT.json').read_text(),flush=True)
raise SystemExit(0 if all(guards.values())else 1)
