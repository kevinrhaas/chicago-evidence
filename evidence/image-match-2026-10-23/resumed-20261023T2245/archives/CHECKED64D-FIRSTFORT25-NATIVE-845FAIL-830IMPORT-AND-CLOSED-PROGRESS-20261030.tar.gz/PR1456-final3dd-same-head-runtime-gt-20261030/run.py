"""Run only after the actual composed source gate: dated-body bindings, fresh
complete native phone, ordinary native commit, PR-event questions. No remote writes.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,shutil,subprocess,time
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path(__file__).parent;G=Path('/workspace/PR1456-final3dd-full-gate-gt-20261030');Q=Path('/workspace/PR1456-current87-inactive1835-consumer-audit-root-20261029');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();steps=[]
def g(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def frozen(binding):
 assert g('rev-parse','HEAD').decode().strip()==args.checked_head
 assert g('rev-parse','HEAD^{tree}').decode().strip()==binding['checked_final_staged_tree']
 assert not(R/'.git/MERGE_HEAD').exists()and not g('status','--porcelain=v1')
 assert not g('diff','--cached','--name-only')and not g('diff','--name-only')
 assert all(sha((R/p).read_bytes())==digest for p,digest in binding['all_staged_paths'].items())
def run(name,cmd):
 assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
 started=time.monotonic();rp=O/(name+'-REAPER.json');assert not rp.exists()
 with(O/(name+'.log')).open('x')as f:q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','taskset','-c','0,1,3,4',*cmd],cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
 reaper=json.loads(rp.read_bytes());row={'name':name,'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-started,'all_children_reaped':reaper['all_children_reaped']};steps.append(row);save('STEPS.json',steps);print(json.dumps(row),flush=True);assert q.returncode==0 and reaper['all_children_reaped'],row

args=argparse.ArgumentParser();args.add_argument('--oracle-caller-proof',required=True);args.add_argument('--expect-merge-parent',required=True);args.add_argument('--checked-head',required=True);args.add_argument('--native-checkpoint-receipt',required=True);args=args.parse_args();assert re.fullmatch('[0-9a-f]{40}',args.expect_merge_parent);oracle_raw=Path(args.oracle_caller_proof).read_bytes();oracle=json.loads(oracle_raw);assert oracle['status']=='ACTUAL_ROOT_ACCEPTED_34DD_GPU_ORACLE_DATED_BODY_EXCEPTION' and oracle['root_reviewed']is True and oracle['after_sha256']=='d5a44866af03c70eff7ab2d193daf55d23dfbc8a64b4ce2f585ad9c97a3acb86'
gate=json.loads((G/'RESULT.json').read_bytes());assert gate['status']=='ACTUAL_FINAL_FOUR_CHECK_PASS_SOURCE_UNCHANGED'and gate['exit']==0 and all(gate['guards'].values())and gate['config_unchanged'];b=gate['binding'];frozen(b);assert b['head']=='5c4b2ea611e729a7fb9fd31da835f321c6f5685c'and b['merge_parent']==args.expect_merge_parent
checkpoint_raw=Path(args.native_checkpoint_receipt).read_bytes();checkpoint=json.loads(checkpoint_raw);assert checkpoint['status']=='ACTUAL_CHECKED_CURRENT3DD_SOURCE_ONLY_NATIVE_MERGE_CHECKPOINT'and checkpoint['head']==args.checked_head and checkpoint['tree']==b['checked_final_staged_tree']and checkpoint['parents']==[b['head'],b['merge_parent']]and checkpoint['source_gate_exact_tree']is True;assert checkpoint['full_source_gate']==str(G/'RESULT.json');assert g('show','-s','--format=%P',args.checked_head).decode().strip().split()==checkpoint['parents']
assert sha((R/'.git/config').read_bytes())==b['primary_config_sha256'];config=b['primary_config_sha256'];reaper=json.loads((G/'REAPER.json').read_bytes());assert reaper['command_exit']==0 and reaper['all_children_reaped'];assert 'bash tools/publish.sh'in(G/'TIMINGS.tsv').read_text()and'published ../../site/4d'in(G/'check.log').read_text()
save('NATIVE-PUBLISH-REUSE.json',{'status':'ACTUAL_SAME_FROZEN_FULL_GATE_NATIVE_PUBLISH_REUSED','tree':b['checked_final_staged_tree'],'full_gate':str(G/'RESULT.json'),'full_gate_sha256':sha((G/'RESULT.json').read_bytes()),'native_publish_timings_sha256':sha((G/'TIMINGS.tsv').read_bytes()),'no_redundant_publish':True})
# Existing three exceptions plus the separately reviewed exact oracle caller proof.
old_receipt=json.loads((Q/'RESULT.json').read_bytes());oldraw=(Q/'305-CONSUMER-BINDINGS.json').read_bytes();assert sha(oldraw)==old_receipt['bindings_sha256'];old=json.loads(oldraw);assert len(old)==305
exceptions={'street-trees.js':'ef5c73955a6115626351f540aba6748c412bba66ea021b2ef5ad44019cc15cc6','railway.js':'e1c0fea0e26bf9f1062a6c91fe5ab4c70347f5ddec0adfa4a1c4d12f46cf2b5d','tree-model.js':'85538f7bd18f0aa0a349a52e9faa7b4cd11ac4da7929fe278a9efecfba3d37e8','gpu-pick.js':'d5a44866af03c70eff7ab2d193daf55d23dfbc8a64b4ce2f585ad9c97a3acb86'}
rows=[]
for row in old:
 p=Path(row['path']);current=p.read_bytes();digest=sha(current);exact=digest==row['expected_sha256'];record={'path':str(p),'old_expected_sha256':row['expected_sha256'],'current_sha256':digest,'bytes':len(current),'exact':exact}
 if not exact:assert p.name in exceptions and digest==exceptions[p.name],str(p)
 rows.append(record)
assert sum(r['exact']for r in rows)==301 and len([r for r in rows if not r['exact']])==4
for name,digest in exceptions.items():assert sha((A/'renderers/web/js'/name).read_bytes())==digest and sha((R/'site/4d/walk/js'/name).read_bytes())==digest
route=old_receipt['actual1835_inactive_route'];assert all(sha(Path(p).read_bytes())==route['scene_sha256']for p in [route['native_scene'],route['published_scene']]);scene=json.loads(Path(route['native_scene']).read_bytes());assert 'railway'not in scene['layers']and'street_trees'not in scene['layers'];assert all(sha((R/p).read_bytes())==route['unchanged_main_layer_dispatch_sha256']for p in ['chicago/4d/renderers/web/js/main.js','site/4d/walk/js/main.js'])
rail=(A/'renderers/web/js/railway.js').read_text();assert 'if (!dataBase || !terrain) return out;'in rail
before=g('show','dd1dfd88808ee36187825706cb71a5ad70bdd262:chicago/4d/renderers/web/js/tree-model.js');after=(A/'renderers/web/js/tree-model.js').read_bytes();needle=b'[0.198, 0.838, 0.002, 1.000]';assert before.count(needle)==1 and before.replace(needle,b'[0.198, 0.830, 0.002, 1.000]')==after
textures={}
for ext in ['webp','ktx2']:
 source=A/('assets/textures/trees/leaf_atlas.'+ext);published=R/('site/4d/data/textures/trees/leaf_atlas.'+ext);assert source.read_bytes()==published.read_bytes();textures[ext]={'bytes':source.stat().st_size,'sha256':sha(source.read_bytes()),'source_published_exact':True}
subjects={'miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832'}
def selected(doc):return {x['id']:x for x in doc['liberties']if subjects.intersection(x.get('subjects',[]))or any(c.get('structure')in subjects for c in x.get('covers',[]))}
native=json.loads((A/'data/liberties.json').read_bytes());pub=json.loads((R/'site/4d/data/liberties.json').read_bytes());prior=json.loads(g('show','dd1dfd88808ee36187825706cb71a5ad70bdd262:chicago/4d/data/liberties.json'));assert native==pub and selected(native)==selected(prior)and len(selected(native))==29
save('BODY-CONSUMER-REUSE.json',{'status':'ACTUAL301_OF305_EXACT_FOUR_PRECISE_ROOT_ACCEPTED_EXCEPTIONS_ALL29_FOUR_TARGET_LIBERTIES_EXACT','at':now(),'tree':b['checked_final_staged_tree'],'rows':rows,'exceptions':{'street-trees.js':'Existing root-reviewed changed treeCard metadata branch is inactive1835; street_trees absent/null layer dispatch.','railway.js':'1904far-ground allocation plus reviewed3line normal packing; railway absent/null1835dispatch returns before geometry/fetch.','tree-model.js':'ACTIVE1835 timber. Exact sole source delta elmLEAF_CROP .838->.830 plus creditedatlaslightness: subcentimeter/photometric environment exception withinT3153; body/camera/card/ground/placement unchanged.','gpu-pick.js':'Root-reviewed corrected raycast oracle/no-renderer near-plane clamp. Renderer-backed GPU picks and directID dated-harness selection unchanged; no geometry/frame/card/ground/placement change. No new browser execution.'},'oracle_caller_proof':{'path':args.oracle_caller_proof,'sha256':sha(oracle_raw)},'native_published_leaf_atlas_bindings':textures,'all29_four_building_liberty_rows_fields_exact':True,'current_native_and_published_full_liberty_count':len(native['liberties']),'limits':'Dated four-building BODY/app reuse, not305-file equality, nottree-modelinactive, notfreshBOTHbrowser/fullenvironment validation. Current complete1904nativephone still separately required.'})
# New foreign tour records may extend the catalog; keep each original target's
# actual lookup metadata, source descriptions, names and claim edges exact.
index_rel='chicago/4d/data/sidecars/1835/sources/index.json'
base_index=json.loads(g('show','2b01c06042660e811bdff90619b0ea2edf953fd9:'+index_rel))
current_index=json.loads((R/index_rel).read_bytes())
assert current_index==json.loads((R/'site/4d/data/sidecars/1835/sources/index.json').read_bytes())
base_sources={r['source_id']:r for r in base_index['sources']};current_sources={r['source_id']:r for r in current_index['sources']};target_sources={}
def source_ids(value,out):
 if isinstance(value,dict):
  for key,item in value.items():
   if key in ['sources','source_ids']and isinstance(item,list):out.update(x for x in item if isinstance(x,str)and x in base_sources)
   if key in ['source_id','source']and isinstance(item,str)and item in base_sources:out.add(item)
   source_ids(item,out)
 elif isinstance(value,list):
  for item in value:source_ids(item,out)
for sid in sorted(subjects):
 rel='chicago/4d/data/sidecars/1835/'+sid+'.json';old_side=json.loads(g('show','2b01c06042660e811bdff90619b0ea2edf953fd9:'+rel));current_side=json.loads((R/rel).read_bytes());old_ids=set();new_ids=set();source_ids(old_side,old_ids);source_ids(current_side,new_ids);assert old_ids==new_ids and old_ids;target_sources[sid]=sorted(old_ids)
lookup_rows=[]
for source_id in sorted(set().union(*(set(v)for v in target_sources.values()))):
 assert source_id in current_sources
 old_meta={k:v for k,v in base_sources[source_id].items()if k!='counts'};new_meta={k:v for k,v in current_sources[source_id].items()if k!='counts'};assert old_meta==new_meta
 rel='chicago/4d/data/sidecars/1835/sources/'+source_id+'.json';old_detail=json.loads(g('show','2b01c06042660e811bdff90619b0ea2edf953fd9:'+rel));new_detail=json.loads((R/rel).read_bytes());assert new_detail==json.loads((R/'site/4d/data/sidecars/1835/sources'/(source_id+'.json')).read_bytes());assert old_detail['source']==new_detail['source'];selected_edges=lambda d:[e for e in d['edges']if e.get('entity_id')in subjects];assert selected_edges(old_detail)==selected_edges(new_detail);assert {k:v for k,v in old_detail['names'].items()if k in subjects}=={k:v for k,v in new_detail['names'].items()if k in subjects}
 lookup_rows.append({'source_id':source_id,'lookup_metadata_except_global_counts_exact':True,'source_description_exact':True,'target_claim_edges_exact':len(selected_edges(new_detail)),'target_names_exact':True,'native_published_detail_exact':True,'foreign_aggregate_count_change_allowed':base_sources[source_id].get('counts')!=current_sources[source_id].get('counts')})
expected_new={'chicago_park_district_buckingham_fountain','encyclopedia_chicago_fernando_jones_scrapbook','encyclopedia_chicago_worlds_of_prairie_avenue','jwa_encyclopedia_hannah_greenebaum_solomon','nlm_visible_proofs_frances_glessner_lee','nprillinois_2019_illinois_led_suffrage'};assert expected_new<=set(current_sources);assert set(current_sources)-set(base_sources)==expected_new
save('SOURCE-INDEX-TARGET-LOOKUPS.json',{'status':'ACTUAL_FOUR_TARGET_SOURCE_LOOKUPS_AND_CLAIM_EDGES_EXACT_WITH_SIX_NEW_FOREIGN_RECORDS','tree':b['checked_final_staged_tree'],'target_source_ids':target_sources,'lookups':lookup_rows,'base_catalog_count':len(base_sources),'current_catalog_count':len(current_sources),'new_foreign_ids':sorted(expected_new),'native_published_catalog_exact':True,'whole_catalog_equality_to_old_base_not_claimed':True})
frozen(b)
run('CURRENT-PHONE-1904',['node','tools/measure_memory.mjs','--year','1904','--only','mobile','--gate','--no-snapshot','--json',str(O/'CURRENT-PHONE-1904.json')]);phone=json.loads((O/'CURRENT-PHONE-1904.json').read_bytes());assert len(phone['rows'])==1;row=phone['rows'][0];peak=row['totals']['total']/1048576;assert 0<peak<=400 and not row['errors'];frozen(b)
# The source-checked ordinary native commit was already checkpointed so its
# GitHub CI can run concurrently with this unchanged same-head phone proof.
head=args.checked_head;tree=b['checked_final_staged_tree'];parents=checkpoint['parents'];frozen(b)
assert sha((R/'.git/config').read_bytes())==config
save('RESULT.json',{'status':'ACTUAL_CHECKED3DD_SAME_HEAD_FRESH_COMPLETE_PHONE_BODY_AND_SOURCE_LOOKUPS_PASS','at':now(),'head':head,'tree':tree,'parents':parents,'full_gate':str(G/'RESULT.json'),'full_gate_exact_tree':True,'native_checkpoint_receipt':args.native_checkpoint_receipt,'native_checkpoint_receipt_sha256':sha(checkpoint_raw),'native_publish_reused_from_actual_fullgate':True,'body_consumer_reuse':str(O/'BODY-CONSUMER-REUSE.json'),'source_index_target_lookups':str(O/'SOURCE-INDEX-TARGET-LOOKUPS.json'),'actual_complete_1904_mobile_peak_MiB':peak,'phone_unchanged_limit_MiB':400,'all_children_reaped':all(r['all_children_reaped']for r in steps),'steps':steps,'source_clean_same_native_head_tree':True,'no_source_Git_or_remote_mutations_in_this_runtime_phase':True,'visual_disclosure':'Earlier external normal-precision visual rawexit1 retained: AIR/NORTHtrianglecapsfailed both baseline andcandidate. No assertionweakened; notanall-budgetPASS.','required_current_GitHub_CI_and_normal_dev_merge_pending':True});print((O/'RESULT.json').read_text(),flush=True)
