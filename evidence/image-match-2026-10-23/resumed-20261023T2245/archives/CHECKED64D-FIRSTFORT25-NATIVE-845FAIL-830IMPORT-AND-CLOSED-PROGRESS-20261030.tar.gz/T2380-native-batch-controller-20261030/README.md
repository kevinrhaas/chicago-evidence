# T2380 executable native selected-owner controller — PREPARED, UNRUN

First execution is **one keeper MASTER + official WEB + one full Gale compound capture**. Root directly reviews that first actual result before271default controls. This avoids spending the full family run on a candidate that still needs a visible source correction. No fixture or heavy job has been created; the closed13payload implementation packet is unchanged.

Actual lightweight preflight pins271current MASTER+WEB baselines/records, recomputes all271current native recipes (zero pre-existing stale rows) and271candidate expected recipe hashes. Keeper expected full native recipe is4217b97083bebb4a3a6849adfdb7755d77d6041fad0238d72f0ee72bf48073f3. Its complete expected document is in PLAN.json. Native recipe preflight in the eventual regular fixture recomputes actual full docs and must equal those hashes before any Blender output. Input/docs hashes are planning evidence; they are not native output evidence.

`controller.py` without flags is read-only/pure preflight. `--execute` refuses before making a fixture unless root explicitly grants and the grant variable is set. Keeper phase defaults first; the later defaults phase independently requires root's actual first-capture review. Native phases run the unchanged pinned build.py/emit pipeline and official WEB script under run-with-reaping.py, nice19, CPU3,4/threads2. All selected outputs must be owned regular files. Foreign masters are read-only links only; official WEB needs them present to retain foreign registry rows. A selected path is unlinked before generation, so neither producer can write through a selected source symlink. Every unselected registry row and metadata field is compared exact against its real before-batch value; versions stay exact. All primary registries/producers and all271baseline MASTER/WEB remain untouched.

The native sidecar projection uses the actual compiler's nested build_sidecar function unchanged. A pure preflight actually reproduced the ENTIRE current jail sidecar exactly (5.414s), then derived candidate placement457.71/-274.57 without typing sidecar fields. Current native grade remains reconstructed because the candidate is not adopted into current source/camera joins; it is recorded as such and never manually promoted. Future canonical source/grade ownership remains owed. Capture uses this real native sidecar, current original-core sidecar/model, native palisade renderer and full uncropped1902page. The sole enclosure data adapter adds keeper ownership, preserving all existing palisade geometry. Native capture remains UNREVIEWED until root directly views it. No source-image verdict is predeclared.

## Resource and time envelope

Future scaffold131regularfiles5,273,523B. Largest8default MASTER+WEB payload931,676B; no full22.29MB modelcopy. A conservative future extra filesystem reserve is18,788,111B including12MiB for links/manifests/logs/native scratch/browser. Before execution it must fit ON TOP OF unchanged workspace536,870,912B and TMP1,800,000,000B floors. Continuous guards stop/reap owned jobs if actual floors or primary source guards fail. This estimate is a reserve, not a waiver if actual native usage is higher.

Measured prior official one-asset controls: Carpenter0.837s build/2.895sWEB; School0.744s build.271times single WEB is about785s before batched-startup amortization, plus builds/capture. The full family is not promised inside a10minute CI window. Once keeper is accepted, first8controls calibrate actual rate; controller writes remaining estimate from actual time and stops at closed-batch boundary by maximum batch count/deadline. Maximum34batches of8,271actualdefault builds and271actualofficialWEBderivatives. No `--no-bake`, AO, scene restriction, fake manifest restamp or hash-only control.

After BOTH generated default outputs match pinned primary SHA/bytes/mode, genuine native recipe/WEBbindings/reaper/results close before owned identical duplicates retire. Retained exact primary baseline files are full restore authority, so root waived34GitHubroundtrip retire latency; retirement receipts state actual SHA/bytes/mode/authority. All failed/mismatching outputs are retained, keeper outputs always retained. Closed receipts and candidate authority can be checkpointed after each meaningful batch. Interrupted/incomplete batches never count as PASS.

## Invocation after explicit root grant

Use the shared environment and preserve its Git/network guards. No Git operation is needed.

```
T2380_NATIVE_CPU=root-approved-after-phone-and-firstfort PYTHONDONTWRITEBYTECODE=1 python3 /workspace/T2380-native-batch-controller-20261030/controller.py --execute --phase keeper --seconds 540
```

Only after actual direct first-capture acceptance and a fresh CPU grant:

```
T2380_NATIVE_CPU=root-approved-after-phone-and-firstfort T2380_DEFAULT_CONTROLS=root-reviewed-first-keeper PYTHONDONTWRITEBYTECODE=1 python3 /workspace/T2380-native-batch-controller-20261030/controller.py --execute --phase defaults --max-batches 1 --seconds 540
```

A failed stage preserves scratch/receipt and refuses blind rerun. A successful partial defaults invocation resumes only later batches, on the exact same primary source/baselines. Source adoption, native full check/publish, original2picture review, BOTH appground/walking, PR/devmerge and low hung gate remain later work. OriginalT2380 remains OPEN.
