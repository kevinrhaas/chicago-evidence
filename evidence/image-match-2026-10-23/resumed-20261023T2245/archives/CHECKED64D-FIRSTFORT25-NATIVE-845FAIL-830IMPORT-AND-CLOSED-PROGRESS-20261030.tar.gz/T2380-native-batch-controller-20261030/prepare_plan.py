from pathlib import Path
import ast,copy,datetime,hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');I=Path('/workspace/T2380-compound-readiness-20261030/implementation')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def bound(p):return {'source':str(p),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777),'sha256':sha(p)}
sys.path.insert(0,str(A/'generators'));import mesh_inputs
# Cache repeated code hashes locally; returned native bytes/recipe documents are unchanged.
cache={};orig=mesh_inputs._sha_file
mesh_inputs._sha_file=lambda p:cache.setdefault(str(p),orig(p)) if str(p) not in cache else cache[str(p)]
spec=importlib.util.spec_from_file_location('keeper_candidate_params',I/'postimages/generators/archetypes/frame_dwelling_params.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
base=json.loads((I/'BASELINE271-MASTERWEB.json').read_text())['assets'];manifest=json.loads((A/'assets/manifest.json').read_text());web=json.loads((A/'assets/manifest.web.json').read_text());oldplan=json.loads(Path('/workspace/T2382-native-selected-bake-prep-20261030/PLAN.json').read_text())
copies=[]
for old in oldplan['copies']:
 src=Path(old['source'])
 if not str(src).startswith(str(A)+'/'):continue
 rel=str(src.relative_to(A));copies.append({**bound(src),'relative':rel,'postimage':str(I/'postimages'/rel) if (I/'postimages'/rel).is_file() else None})
for rel in ['tools/compile_scene.py','tools/grade_structures.py','tools/photo_match.mjs','tools/photo_match_group.mjs','tools/photo_match_enclosures.mjs','tools/photo_match_flora.mjs']:
 src=A/rel;copies.append({**bound(src),'relative':rel,'postimage':None})
family=[];stale=[]
for row in base:
 source=A/'data/structures'/f"{row['structure_id']}.json";record=json.loads(source.read_text());phase=next(x for x in record['phases'] if x['id']==row['phase_id']);doc=mesh_inputs.structure_inputs_doc(record,phase);oldsha=hashlib.sha256(json.dumps(doc,sort_keys=True).encode()).hexdigest();new=copy.deepcopy(doc);new['params']=mesh_inputs._params_doc(m.from_phase(phase,record));new['code']['archetypes/frame_dwelling.py']=sha(I/'postimages/generators/archetypes/frame_dwelling.py');newsha=hashlib.sha256(json.dumps(new,sort_keys=True).encode()).hexdigest()
 assert sha(A/'assets/gltf'/row['master'])==row['master_sha256'];assert sha(A/'assets/web'/row['master'])==row['web_sha256']
 if oldsha!=manifest['assets'][row['master']]['inputs_sha256']:stale.append(row['master'])
 family.append({**row,'record':bound(source),'native_current_recipe':oldsha,'native_candidate_expected_recipe':newsha,'current_recipe_matches_actual_registry':oldsha==manifest['assets'][row['master']]['inputs_sha256']})
keeper=json.loads((I/'log_jail_keeper_house.json').read_text());ph=keeper['phases'][0];doc=mesh_inputs.structure_inputs_doc(keeper,ph);doc['params']=mesh_inputs._params_doc(m.from_phase(ph,keeper));doc['code']['archetypes/frame_dwelling.py']=sha(I/'postimages/generators/archetypes/frame_dwelling.py');ksha=hashlib.sha256(json.dumps(doc,sort_keys=True).encode()).hexdigest()
readlinks=[]
for rel in ['data/scenes','data/datum.json','assets/textures','docs','renderers']:
 readlinks.append({'relative':rel,'source':str(A/rel)})
# Native WEB prunes records for missing masters. Read links preserve all foreign rows;
# every selected path must be UNLINKED before official generation and become regular.
masters=[{'relative':str(p.relative_to(A)),'source':str(p),'bytes':p.stat().st_size} for p in sorted((A/'assets/gltf').rglob('*.glb'))]
# All modules actually read by native recipe plus narrow static browser dependencies.
closure={**mesh_inputs._code_shas('frame_dwelling'),'mesh_inputs.py':sha(A/'generators/mesh_inputs.py'),'code_inputs.py':sha(A/'generators/code_inputs.py'),'blender.pin':sha(A/'generators/blender.pin')}
scaffold=sum(x['bytes'] for x in copies)+sum(Path(x['postimage']).stat().st_size-x['bytes'] for x in copies if x['postimage']);bs=[family[i:i+8] for i in range(0,len(family),8)]
plan={'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PREPARED_EXECUTABLE_UNRUN_NO_FIXTURE','primary':str(A),'implementation_manifest':bound(I/'IMPLEMENTATION-CLOSED-MANIFEST.json'),'candidate':bound(I/'log_jail_keeper_house.json'),'copies':copies,'read_links':readlinks,'master_read_links':masters,'family':family,'expected_keeper_recipe_doc':doc,'expected_keeper_recipe_sha256':ksha,'keeper_output':'log_jail_keeper_house__frame_1835.glb','native_current_stale_rows':stale,'current_registry_sha256':{'manifest.json':sha(A/'assets/manifest.json'),'manifest.web.json':sha(A/'assets/manifest.web.json'),'manifest.versions.json':sha(A/'assets/manifest.versions.json')},'source_closure':closure,'reaper':bound(Path('/workspace/shared/run-with-reaping.py')),'blender':'/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender','blender_pin':(A/'generators/blender.pin').read_text(),'reaper_cpu':'3,4','threads':2,'batch_size':8,'batches':[[x['structure_id'] for x in b] for b in bs],'regular_scaffold_bytes':scaffold,'largest_default_batch_master_web_bytes':max(sum(x['master_bytes']+x['web_bytes'] for x in b) for b in bs),'future_extra_fs_envelope_bytes':scaffold+max(sum(x['master_bytes']+x['web_bytes'] for x in b) for b in bs)+12*1024*1024,'workspace_floor':536870912,'tmp_floor':1800000000,'grant_required':'T2380_NATIVE_CPU=root-approved-after-phone-and-firstfort; root must explicitly grant before execute','retire_defaults':'Only after actual MASTER and official WEB compare equal SHA+bytes+mode to pinned primary baseline, with native recipes/rows/log/reaper closed. Primary exact payload is full restore authority, so no34roundtrip GitHub checkpoint latency. Retain all failed/mismatch outputs; keeper outputs always retained.','measured_priors':{'carpenter_master_s':0.837,'carpenter_web_s':2.895,'school_master_s':0.744,'basis':'actual official closed selected native receipts; one-asset measurements, not271time proof'},'estimate':'271 x singleAssetWEB2.895s≈785s before amortization; native batched startups differ. Cannot promise full271pluscapture inside10min. Run/calibrate first8 then estimate actual remaining and checkpoint/pause at batch boundary if lease ends.','no_heavy_executed':True,'no_fixture_created':True}
(P/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
(P/'BASELINE271.json').write_text(json.dumps({'assets':family},indent=2)+'\n')
print(json.dumps({'copies':len(copies),'scaffold_bytes':scaffold,'families':len(family),'preexisting_stale_rows':stale,'keeper_recipe':ksha,'future_extra_fs_envelope_bytes':plan['future_extra_fs_envelope_bytes'],'no_fixture':True},indent=2))
