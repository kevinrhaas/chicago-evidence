# T2386 — stop camera math; capture the six pending compositions

This small supplement leaves every member of the closed45-file source packet unchanged. I directly viewed the actual full Andreas, paired engravings (two compositions), Miller/Davis, Colbert and Hammon source files. All six old finite camera seeds and their approximate manual controls remain unchanged. No geometry, source catalog, canonical camera, match, primary Git/index/config/site or ticket was written. No browser, native renderer or Blender ran.

Three paired-gable fits retain control/artwork ambiguity. Their manual eave/apex identities are approximate readings of small hatched, retrospective drawings, not surveyed or held-out control. The model gauge and relative gable spacing are reconstructed from the governing NYPL interpretation. A source-picture residual by itself does not establish a street-visible model defect. One-gable partial fits underconstrain the partner and cannot prove it absent. Do not hide the partner or invent a picture-derived world position.

## Actual finite camera experiment, rejected

`fit.py` ran on CPU2 with one numerical thread. It kept the old six selected gable points, source pixels, aspect and model geometry fixed, and allowed the native camera's orthonormal basis (pitch±8°, roll±3°), focal300–12000px, eye0.8–4m and radial distance12–420m. The math follows the native projection convention; this was an analytic experiment, not execution of a native camera solver or renderer.

| Composition | Old max residual | New bounded max | Decision |
|---|---:|---:|---|
| Andreas1830 |25.498px|25.448px|Reject alternative; distance, eye and pitch hit bounds|
| pairedLEFT1830 |26.620px|26.644px|Reject alternative; distance and pitch hit bounds|
| Miller/Davis1857 |21.514px|22.218px|Reject alternative; distance, eye and pitch hit bounds|

The tiny RMS reduction does not settle the high residuals. All three extra-parameter alternatives are preserved in `PHYSICAL-CAMERA-MATH.json` as rejected diagnostics. No replacement camera is emitted. There is no further math or geometry loop before real source comparisons. Source/manual-control disagreement and subpixel fitting are qualified explicitly under T3153; they are not predeclared `matches`.

## Finite native batch, not executed

`capture-six.py` defaults to a read-only plan. It verified all45 old closed members and all8 bound current model/tool inputs; `READONLY-PLAN.json` records the six unchanged cameras, source hashes and bibliography hashes. Execution requires root's actual frozen checked head/tree, reviewed source bibliography and exclusive CPU grant. This review is routine source admission already requested by root, not a new owner question. No fixture exists yet.

The script copies only six small unchanged camera JSONs into an owned canonical-relative tree and resolves five photos through explicit links to the existing public files. It invokes unchanged `node tools/photo_match.mjs` on the exact225f MASTER, serially, through root's existing reaper; no runtime tree, model, source-photo or vendor copy. The first three lower-residual views precede the three warned ones. Native match outputs must remain `unreviewed` until actual direct comparison. Native temporary PNGs are retained byte-exactly and their now-duplicated temporary files retired only after hash/size verification and reaping. Unexpected private temporary leftovers are retained and cause a stop.

Before and after each frame it checks unchanged workspace536870912B/TMP1800000000B floors, full current HEAD/tree/index/config/ref/status/changed-working-byte bindings, selected model/tool inputs, exact camera/photo/GLB match hashes and all descendants reaped. Old45 members are checked again at completion. Failure stops, retaining actual output; it does not retry or relabel a frame. Conservative workspace reserve10MiB. Native NYPL measured2.236s; six frames estimate13.4s plus startup/copies, with actual first-frame calibration. No batch timing or PASS is claimed.

Root can execute after its CPU/source grant and bibliography review:

```text
source /workspace/shared/resume-chicago-env.sh
python3 /workspace/T2386-wolf-fit-supplement-20261030/capture-six.py --execute --expect-head <actual full checked HEAD> --expect-tree <actual full checked tree> --sources-reviewed --cpus 0,1,3,4
```

The five bibliography drafts remain in the original closed packet: Andreas1884; anonymous nineteenth-century pair with exact editions unresolved; Miller after George Davis, ChicagoMagazine15May1857; Bureau of Illustration for Colbert/Chamberlin1871; and Widney/Hammon circa1908. Attribution and original-verification limits stay explicit. The uncleared poster's date/rights conflict and unkeyed Herriott context retain their existing dispositions; no new camera or rights upgrade is introduced.

After actual six-frame review, the original still needs current native app BOTH viewport/roof normal+ORM review, credited card Images coverage, source/metadata adoption, final source gate/preflight/current CI, policy PR/dev merge and ticket settlement. The accepted NYPL frame alone did not close it, and this unrun supplement does not either.
