"""Read-only plan by default. Execute only under root's exclusive CPU/source lease."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,stat,subprocess,time,datetime
O=Path(__file__).parent;OLD=Path('/workspace/T2386-current-picture-closure-prep-20261030');A=Path('/workspace/chicago/chicago/4d');R=A.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--expect-head');p.add_argument('--expect-tree');p.add_argument('--sources-reviewed',action='store_true');p.add_argument('--cpus',default='0,1,3,4');args=p.parse_args()
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
def git(*cmd):return subprocess.check_output(['git','-C',str(R),*cmd],env=E)
def floors():return {'workspace':shutil.disk_usage('/workspace').free,'tmp':shutil.disk_usage('/tmp').free}
def enough():
 f=floors();assert f['workspace']>=536870912 and f['tmp']>=1800000000,f
 return f
def snapshot():
 changed=sorted(set(x.decode()for x in git('diff','--name-only','-z','HEAD').split(b'\0')if x)|set(x.decode()for x in git('ls-files','--others','--exclude-standard','-z').split(b'\0')if x))
 return {'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'index':sha(R/'.git/index'),'config':sha(R/'.git/config'),'refs':hashlib.sha256(git('for-each-ref','--format=%(refname) %(objectname)')).hexdigest(),'status':git('status','--porcelain=v1','-z').decode(),'working':{n:sha(R/n) if (R/n).is_file() else None for n in changed}}
oldmanifest=OLD/'CLOSED-MANIFEST.json';oldm=json.loads(oldmanifest.read_text())
for row in oldm['members']:
 q=OLD/row['path'];assert q.is_file() and q.stat().st_size==row['bytes'] and sha(q)==row['sha256']
binding=json.loads((OLD/'FIRST-CAPTURE-BINDING.json').read_text())
for row in binding['inputs']:assert sha(Path(row['path']))==row['sha256'],row['path']
fits=json.loads((OLD/'SIX-FINITE-CAMERA-PREP.json').read_text())['fits'];byview={x['view']:x for x in fits};views=['pair-right-1833','colbert-1871','hammon-c1908','andreas-1830','pair-left-1830','miller-davis-1857'];rows=[]
for name in views:
 row=byview[name];cam=OLD/row['camera_postimage'];src=OLD/row['source_postimage'];assert sha(cam)==row['camera_sha256'] and sha(Path(row['source_file']))==row['source_sha256'];rows.append({**row,'source_record_sha256':sha(src)})
plan={'status':'READONLY_PLAN_COMPLETE_SIX_NATIVE_CAPTURES_UNRUN','views':rows,'native_command':['node','tools/photo_match.mjs','<owned canonical-relative copied camera>','--glb','assets/gltf/wolf_point_tavern__log_frame_1828.glb','--out','<owned per-view output>'],'cwd':str(A),'old_closed_manifest_sha256':sha(oldmanifest),'capture_count':6,'conservative_owned_workspace_reserve_bytes':10*1024*1024,'measured_single_native_NYPL_seconds':2.236,'estimated_seconds':'~13.4s plus startup/copy/cleanup; first new frame calibrates, no promised batch time','floors_now':floors(),'rejected_camera_alternatives':'PHYSICAL-CAMERA-MATH.json; use ORIGINAL finite seeds, not the fitted boundary alternatives','source_review_required':'Review the five existing closed source-specific bibliography drafts before executing --sources-reviewed; this is routine root source admission, no new owner question.','remaining_after':'Direct native-pair review, qualified T3153 rulings, app BOTH/roof maps/card Images/metadata/current fullgate/PR/dev merge. No matches or original completion claimed.'}
if not args.execute:print(json.dumps(plan,indent=2));raise SystemExit(0)
assert args.expect_head and args.expect_tree and args.sources_reviewed,'actual head/tree and root source review required'
assert not (O/'run').exists(),'one finite batch; preserve old run rather than overwrite'
enough();assert shutil.disk_usage('/workspace').free>=536870912+plan['conservative_owned_workspace_reserve_bytes']
before=snapshot();assert before['head']==args.expect_head and before['tree']==args.expect_tree
run=O/'run';run.mkdir(mode=0o700);(run/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n');(run/'BEFORE.json').write_text(json.dumps(before,indent=2)+'\n');results=[]
try:
 for row in rows:
  enough();assert snapshot()==before
  name=row['view'];camera=run/'inputs/data/reference_views/wolf_point_tavern'/f'{name}.json';camera.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(OLD/row['camera_postimage'],camera);assert sha(camera)==row['camera_sha256']
  photo=Path(row['source_file']);link=run/'inputs/reference/images/chicago'/photo.name;link.parent.mkdir(parents=True,exist_ok=True)
  if not link.exists():link.symlink_to(photo)
  assert camera.parent.joinpath(json.loads(camera.read_text())['photo']).resolve()==photo.resolve()
  out=run/'frames'/name;out.mkdir(parents=True);tmp=Path('/tmp')/f"wolf-six-{os.getpid()}-{name}";assert not tmp.exists();tmp.mkdir(mode=0o700);env=dict(E,TMPDIR=str(tmp));start=time.monotonic();log=out/'native.log';reaper=out/'REAPER.json'
  command=['python3','/workspace/shared/run-with-reaping.py',str(reaper),'--','taskset','-c',args.cpus,'nice','-n','19','node','tools/photo_match.mjs',str(camera),'--glb','assets/gltf/wolf_point_tavern__log_frame_1828.glb','--out',str(out)]
  with log.open('x')as f:ret=subprocess.run(command,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT)
  rp=json.loads(reaper.read_text());assert ret.returncode==0 and rp['all_children_reaped'],(name,ret.returncode,rp)
  match=camera.with_suffix('.match.json');m=json.loads(match.read_text());assert m['verdict']=='unreviewed' and m['camera_sha256']==row['camera_sha256'] and m['photo_sha256']==row['source_sha256'] and m['glb_sha256']=='225f3e1041d02cdaa627d3d73c5f6448aff9b12c66f4a545462db45bbf8e0d59'
  pngs=list(tmp.glob(f'photo-match-*/{name}-render.png'));assert len(pngs)==1
  native_png=pngs[0];kept=out/native_png.name;shutil.copy2(native_png,kept);assert sha(native_png)==sha(kept);mapping={'native_tmp':str(native_png),'retained':str(kept),'sha256':sha(kept),'bytes':kept.stat().st_size,'mode':stat.S_IMODE(kept.stat().st_mode)};native_png.unlink();native_png.parent.rmdir()
  if not any(tmp.iterdir()):tmp.rmdir()
  else:raise AssertionError(f'owned tmp leftovers retained: {tmp}')
  assert snapshot()==before
  for original in binding['inputs']:assert sha(Path(original['path']))==original['sha256']
  enough();results.append({'view':name,'native_exit':ret.returncode,'seconds':time.monotonic()-start,'all_children_reaped':True,'native_match':str(match),'side_by_side':str(A/m['side_by_side']),'retained_native_render':mapping,'verdict':'unreviewed','source_and_Git_unchanged':True});(run/'CLOSED-FRAMES.json').write_text(json.dumps(results,indent=2)+'\n')
except BaseException as error:
 (run/'FAILURE.json').write_text(json.dumps({'error':repr(error),'closed_frames':results,'source_unchanged':snapshot()==before,'limits':'Failure retained; no frame relabelled or retries authorized.'},indent=2)+'\n');raise
assert snapshot()==before
for row in oldm['members']:assert sha(OLD/row['path'])==row['sha256']
result={'status':'ACTUAL_SIX_NATIVE_DIAGNOSTIC_FRAMES_UNREVIEWED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frames':results,'all_source_Git_old_packet_inputs_unchanged':True,'current_native_capture_count':6,'no_geometry_changes':True,'no_canonical_writes_or_original_completion':True};(run/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
