"""Bounded physical-camera comparison only; old controls and model unchanged."""
import os
os.sched_setaffinity(0,{2}); os.nice(15)
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import ast,json,math,hashlib,time
import numpy as np
from scipy.optimize import least_squares
O=Path(__file__).parent;P=Path('/workspace/T2386-current-picture-closure-prep-20261030')
tree=ast.parse((P/'prepare-six-finite-cameras.py').read_text())
specs=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='specs' for t in n.targets))
old=json.loads((P/'SIX-FINITE-CAMERA-PREP.json').read_text());points=old['model_template_uvy']; rows=[];start=time.monotonic()
for spec in specs:
 if spec['view'] not in ('andreas-1830','pair-left-1830','miller-davis-1857'):continue
 cam=json.loads((P/'six-view-postimages/data/reference_views/wolf_point_tavern'/f"{spec['view']}.json").read_text());names=list(spec['points']);xyz=np.array([points[n] for n in names]);uv=np.array([spec['points'][n] for n in names],float);center=np.array([3.6,5.0])
 # Native basis: yaw plus bounded pitch/roll; orthonormal (east,north,up).
 # q=(yaw,d,eyeheight,cx,cy,focal,pitch,roll). No point/geometry/scan-aspect changes.
 def project(q):
  yaw,d,h,cx,cy,focal,pitch,roll=q;t,p,r=np.radians([yaw,pitch,roll]);f=np.array([math.sin(t)*math.cos(p),math.cos(t)*math.cos(p),math.sin(p)]);right=np.array([math.cos(t),-math.sin(t),0.]);up=np.cross(right,f);rr=right*math.cos(r)+up*math.sin(r);uu=up*math.cos(r)-right*math.sin(r);eye=np.r_[center-d*np.array([math.sin(t),math.cos(t)]),h];delta=xyz-eye;z=delta@f;proj=np.c_[cx+focal*(delta@rr)/z,cy-focal*(delta@uu)/z];return proj,eye,z,[rr.tolist(),uu.tolist(),f.tolist()]
 def residual(q):return (project(q)[0]-uv).ravel()
 q0=[cam['yaw_deg'],math.dist(cam['eye'][:2],center),cam['eye'][2],*cam['principal_px'],cam['focal_px'],0,0]
 lower=[185,12,0.8,-4000,-4000,300,-8,-3];upper=[265,420,4.,5000,5000,12000,8,3]
 res=least_squares(residual,q0,bounds=(lower,upper),max_nfev=180,ftol=1e-9,xtol=1e-9,gtol=1e-9);proj,eye,z,basis=project(res.x);err=np.linalg.norm(proj-uv,axis=1)
 near=max(.1,min(200.,float(min(z))*.65)); out={'view':spec['view'],'old_rms_px':cam['solve']['conditional_fit_residuals_px']['rms_point_distance'],'old_max_px':cam['solve']['conditional_fit_residuals_px']['max_point_distance'],'rms_px':float(np.sqrt(np.mean(err**2))),'max_px':float(max(err)),'q':res.x.tolist(),'eye':eye.tolist(),'basis':basis,'near_m':near,'depths':z.tolist(),'orthonormal_error':float(np.max(np.abs(np.array(basis)@np.array(basis).T-np.eye(3)))),'controls':[{'name':n,'pixel':spec['points'][n],'fitted':proj[i].tolist(),'residual':float(err[i])} for i,n in enumerate(names)],'nfev':res.nfev,'success':bool(res.success),'on_bound':[i for i,(v,lo,hi)in enumerate(zip(res.x,lower,upper))if min(v-lo,hi-v)<1e-3],'native_capture':'UNRUN','verdict':'UNASSIGNED','geometry_changes':False,'controls_changes':False};rows.append(out)
result={'status':'BOUNDED_NATIVE_PHYSICAL_CAMERA_MATH_ONLY_NO_CAPTURE','seconds':time.monotonic()-start,'rows':rows,'model_sha256':'225f3e1041d02cdaa627d3d73c5f6448aff9b12c66f4a545462db45bbf8e0d59','source_and_controls_unchanged':True,'no_primary_or_old_packet_writes':True};(O/'PHYSICAL-CAMERA-MATH.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items() if k in ['view','old_rms_px','old_max_px','rms_px','max_px','q','on_bound','success']} for r in rows],indent=2))
