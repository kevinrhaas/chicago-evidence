"""Actual native source gate after the genuine2b01+reviewed-currentdev merge.

Requires the actual native1456 head, exact imported currentdev merge parent,
reviewed staged-path bindings and three-line repair. It never stages, commits,
publishes remotely, or changes refs itself.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

R = Path('/workspace/chicago')
A = R / 'chicago/4d'
O = Path(__file__).parent
REL = 'chicago/4d/renderers/web/js/railway.js'
E = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0',
         CHECK_JOBS='4', CHECK_TIMINGS=str(O / 'TIMINGS.tsv'),
         C4D_GATE_REQUIRE_READERS='1', OMP_NUM_THREADS='1',
         OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
E['PATH'] = '/workspace/early-four-node-fixture-scope-20261029/bin:' + E['PATH']
SHA = lambda b: hashlib.sha256(b).hexdigest()
NOW = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):
    return subprocess.check_output(['git', '-C', str(R), *args], env=E)
def save(name, value):
    (O / name).write_text(json.dumps(value, indent=2) + '\n')

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--expect-head', required=True)
p.add_argument('--expect-tree', required=True)
p.add_argument('--expect-merge-parent', required=True)
p.add_argument('--reviewed-staged-bindings', required=True)
a = p.parse_args()
assert all(re.fullmatch('[0-9a-f]{40}', s) for s in [a.expect_head, a.expect_tree, a.expect_merge_parent])
assert git('rev-parse', 'HEAD').decode().strip() == a.expect_head
assert git('symbolic-ref', '--short', 'HEAD').decode().strip() == 'steward/t2381-t2373-t2384-t2377-early-pictures-20261029'
assert git('rev-parse', 'MERGE_HEAD').decode().strip() == a.expect_merge_parent
assert git('rev-parse', 'origin/dev').decode().strip() == a.expect_merge_parent
assert not git('diff', '--name-only') and not git('ls-files', '-u')
assert not git('ls-files', '--others', '--exclude-standard')
reviewed_bytes = Path(a.reviewed_staged_bindings).read_bytes()
reviewed = json.loads(reviewed_bytes)
assert reviewed['head'] == a.expect_head and reviewed['merge_parent'] == a.expect_merge_parent
assert reviewed['tree'] == a.expect_tree
rows = reviewed['all_staged_paths']
assert 1 <= len(rows) <= 128
# This parent already contains the checked railway repair; it need not be a
# changed path in this later genuine currentdev merge. Its exact bytes are
# still required below and protected by the staged-tree/working-tree guards.
assert set(rows) == set(git('diff', '--cached', '--name-only').decode().splitlines())
library = {'chicago/prairie_1904_v1/data/images.json', 'chicago/prairie_1904_v1/research/images/STORE.json',
           'chicago/prairie_1904_v1/research/images/stream-early-chicago-lighthouse-reference.json',
           'chicago/prairie_1904_v1/research/images/stream-early-chicago-miller-hogan-references.json',
           'chicago/prairie_1904_v1/research/images/stream-st-mary-reference.json'}
assert all((rel.startswith('chicago/4d/') or rel in library) and re.fullmatch('[0-9a-f]{64}', digest)
           and SHA((R / rel).read_bytes()) == digest for rel, digest in rows.items())
assert SHA(git('show', a.expect_merge_parent + ':' + REL)) == '3117e6d7e6fd52766a2f71a488e6af06f556227b4031fa82667370d73beab5f8'
assert SHA((R / REL).read_bytes()) == 'e1c0fea0e26bf9f1062a6c91fe5ab4c70347f5ddec0adfa4a1c4d12f46cf2b5d'
assert git('write-tree').decode().strip() == a.expect_tree
config = SHA((R / '.git/config').read_bytes())
assert config == '5536e1343e7abdacddfce3d5438e08872ad6a33295900466b529df5e0c57e730'
assert shutil.disk_usage('/workspace').free >= 536870912
assert shutil.disk_usage('/tmp').free >= 1800000000
assert not (O / 'BINDING.json').exists() and not (O / 'REAPER.json').exists()
binding = dict(started=NOW(), head=a.expect_head, merge_parent=a.expect_merge_parent,
               checked_final_staged_tree=a.expect_tree, all_staged_paths=rows, CHECK_JOBS=4,
               reviewed_staged_bindings_sha256=SHA(reviewed_bytes),
               controller_affinity=sorted(os.sched_getaffinity(0)), check_worker_affinity=[0, 1, 3, 4],
               workspace_free_before=shutil.disk_usage('/workspace').free,
               tmp_free_before=shutil.disk_usage('/tmp').free,
               workspace_floor_bytes=536870912, unchanged_caller_floor=1800000000,
               scope='Actual genuine native1456+currentdev merge plus root-reviewed3line existing compactNormals reuse. GT WIP is safely archived and excluded.',
               external_node_fixture_exception=dict(shim='/workspace/early-four-node-fixture-scope-20261029/bin/node',
                   sha256=SHA(Path('/workspace/early-four-node-fixture-scope-20261029/bin/node').read_bytes()),
                   scope='Existing reviewed exact test_repo_file.mjs local-file scratch Git fixture only; all other node calls preserve GIT_NO_LAZY_FETCH.'),
               primary_config_sha256=config)
save('BINDING.json', binding)
started = time.monotonic()
with (O / 'check.log').open('x') as log:
    command = ['python3', '/workspace/shared/run-with-reaping.py', str(O / 'REAPER.json'),
               '--', 'taskset', '-c', '0,1,3,4', 'bash', 'tools/check.sh']
    result = subprocess.run(command, cwd=A, env=E, stdout=log, stderr=subprocess.STDOUT)
reaper = json.loads((O / 'REAPER.json').read_bytes())
guards = dict(HEAD=git('rev-parse', 'HEAD').decode().strip() == a.expect_head
                   and git('rev-parse', 'MERGE_HEAD').decode().strip() == a.expect_merge_parent,
              staged_tree=git('write-tree').decode().strip() == a.expect_tree,
              tracked_working_bytes=not git('diff', '--name-only'),
              no_untracked=not git('ls-files', '--others', '--exclude-standard'),
              no_conflicts=not git('ls-files', '-u'),
              staged_path_sha256=all(SHA((R / rel).read_bytes()) == digest for rel, digest in binding['all_staged_paths'].items()),
              all_children_reaped=reaper['all_children_reaped'])
text = (O / 'check.log').read_text()
clean = re.sub(r'\x1b\[[0-9;]*m', '', text)
passed = result.returncode == 0 and all(guards.values()) and bool(re.search(r'^CHECK PASS — \d+ steps, none red\.$', clean, re.M))
unchanged_config = SHA((R / '.git/config').read_bytes()) == config
passed = passed and unchanged_config
save('RESULT.json', dict(status='ACTUAL_FINAL_FOUR_CHECK_PASS_SOURCE_UNCHANGED' if passed else 'ACTUAL_FINAL_FOUR_CHECK_NOT_QUALIFIED',
                         finished=NOW(), elapsed_seconds=time.monotonic() - started,
                         exit=result.returncode, binding=binding, guards=guards,
                         footer=text.splitlines()[-15:], config_unchanged=unchanged_config,
                         limits='Actual complete source gate only. Fresh current native phone, native ordinary commit, PR-event questions, remote publication/new CI and merge remain pending. Inherited AIR/NORTH triangle failures from external same-frame visual probe remain disclosed.'))
print(json.dumps(dict(passed=passed, exit=result.returncode, guards=guards,
                      elapsed_seconds=time.monotonic() - started)), flush=True)
raise SystemExit(0 if passed else 1)
