"""Run only native manifest owners of actual generated conflicts before diagnostic phone.
Full61/source1105/final checked-head phone remain owed.
"""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path(__file__).parent
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
g=lambda *a:subprocess.check_output(['git','-C',str(R),*a],env=E);sha=lambda b:hashlib.sha256(b).hexdigest();save=lambda n,d:(O/n).write_text(json.dumps(d,indent=2)+'\n')
head='64d5710e7707683aa1dbaca1efacbbe1854970c0';parent='845446b26378b90a3dc455a4a456e5927c0123e8'
assert g('rev-parse','HEAD').decode().strip()==head and g('rev-parse','MERGE_HEAD').decode().strip()==parent and g('rev-parse','origin/dev').decode().strip()==parent
manifest=json.loads((A/'tools/derived_manifest.json').read_bytes());owned={p for s in manifest['steps']for p in s.get('resolves',[])}
unmerged=g('diff','--name-only','--diff-filter=U').decode().splitlines();known={'chicago/4d/data/liberties.json','chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/docs/measurements/source_use_coverage.md'};assert set(unmerged)<=known
commands=[]
for step in manifest['steps']:
 if set(step.get('resolves',[]))&set(unmerged):
  assert step['command']in [['python3','tools/compile_liberties.py'],['python3','tools/compile_source_use.py']],step['command']
  commands.append(step['command'])
assert set(unmerged)<={p for step in manifest['steps']if step['command']in commands for p in step.get('resolves',[])}
paths=g('diff','--cached','--name-only').decode().splitlines();authored={p:sha((R/p).read_bytes())for p in paths if p not in owned};models={p.relative_to(R).as_posix():sha(p.read_bytes())for folder in ['gltf','web']for p in(A/'assets'/folder).rglob('*.glb')if not p.is_symlink()};config=sha((R/'.git/config').read_bytes());assert config=='5536e1343e7abdacddfce3d5438e08872ad6a33295900466b529df5e0c57e730';save('BINDING.json',{'head':head,'merge_parent':parent,'actual_generated_conflicts':unmerged,'manifest_mapped_official_commands':commands,'all_models':len(models),'authored_staged':authored,'no_full61_or_gate_claim':True})
if unmerged:g('checkout','--ours','--',*unmerged)
steps=[]
for n,cmd in enumerate(commands+[['bash','tools/publish.sh']]):
 assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
 rp=O/('STEP-'+str(n)+'-REAPER.json');start=time.monotonic()
 with(O/('STEP-'+str(n)+'.log')).open('x')as log:q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','taskset','-c','0,1,3,4',*cmd],cwd=A,env=E,stdout=log,stderr=subprocess.STDOUT)
 reap=json.loads(rp.read_bytes());steps.append({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-start,'all_children_reaped':reap['all_children_reaped']});save('STEPS.json',steps);assert q.returncode==0 and reap['all_children_reaped']
 if cmd!=['bash','tools/publish.sh']:
  owning={p for st in manifest['steps']if st['command']==cmd for p in st.get('resolves',[])}
  stage=[p for p in g('diff','--name-only').decode().splitlines()if p in owning]
  if stage:g('add','--',*stage)
assert all(sha((R/p).read_bytes())==v for p,v in models.items())and all(sha((R/p).read_bytes())==v for p,v in authored.items())
assert not g('ls-files','-u')and not g('diff','--name-only')and not g('ls-files','--others','--exclude-standard')
assert g('rev-parse','HEAD').decode().strip()==head and g('rev-parse','MERGE_HEAD').decode().strip()==parent and sha((R/'.git/config').read_bytes())==config
tree=g('write-tree').decode().strip();save('RESULT.json',{'status':'ACTUAL_PRELIMINARY_CONFLICT_OWNERS_AND_NATIVE_PUBLISH_PASS_UNGATED845_ONLY','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'merge_parent':parent,'tree':tree,'all_staged_paths':{p:sha((R/p).read_bytes())for p in g('diff','--cached','--name-only').decode().splitlines()},'steps':steps,'all_models_exact':len(models),'all_authored_inputs_exact':True,'full61_sourcegate_and_final_phone_NOT_RUN':True});print((O/'RESULT.json').read_text(),flush=True)
