from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import quote
import argparse,base64,datetime,hashlib,importlib.util,json,os,stat,subprocess,zlib
P=Path('/workspace/currentdev845-incremental-price-publisher-20261030');O=Path(__file__).parent;price=json.loads((P/'RESULT.json').read_text());price.update(secondary_head='64d5710e7707683aa1dbaca1efacbbe1854970c0',secondary_tree='36fa4adc9428a2cfe7a925ab6bf64fb1307288f5');TIP=price['tip'];OLD='3dd3c8c0d8acb1728a618c9808354730918fbe00';HEAD='64d5710e7707683aa1dbaca1efacbbe1854970c0';BRANCH='steward/t2381-t2373-t2384-t2377-early-pictures-20261029';C=Path('/workspace/chicago');FLOOR=536870912;RESERVE=16777216;TMPFLOOR=1800000000;GUARD=1048576
sha=lambda b:hashlib.sha256(b).hexdigest();free=lambda p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize;save=lambda n,x:(O/n).write_text(json.dumps(x,indent=2)+'\n')
a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--source-phase-lease');args=a.parse_args()
plan={'status':'DEFAULT_PLAN_ONLY_NO_SOURCE_OR_OBJECT_MUTATION','tip':TIP,'tree':price['tree'],'expected_HEAD':HEAD,'expected_branch':BRANCH,'expected_origin_dev':OLD,'CAS_origin_dev_target':TIP,'objects':price['new_total_objects'],'raw_bytes':price['new_total_raw_bytes'],'allocation_upper':price['new_total_allocation_upper_4k'],'required_workspace':price['required_workspace_bytes'],'workspace_free':free('/workspace'),'tmp_free':free('/tmp'),'workspace_floor':FLOOR,'working_reserve':RESERVE,'tmp_floor':TMPFLOOR,'fetch':False,'method':'RAM canonical GitData reconstruction and verified immutable blobs, one-copy exclusive loose object writes, exact native SHA readback; source bytes/index/config/HEAD/otherrefs guarded','execution_prerequisites':['root reviewed concrete incremental845 current code/source owner scope','Carpenter BOTH app/browser source guard and reaper closed','actual current3dd source gate and fresh398.8662phone, checked64d publication durable; no845phone claimed; GT67already713','sole primary writer grants source phase lease'],'later_dev_unqualified':True,'required_native_PR1456_head':price['secondary_head'],'native_PR1456_tree':price['secondary_tree'],'primary_branch_repair_will_descend_native_remote_head':True};save('PLAN.json',plan)
if not args.execute:print(json.dumps(plan,indent=2));raise SystemExit(0)
assert args.source_phase_lease=='root-closed64d-source-phase-incremental845-import'
os.sched_setaffinity(0,{1});os.nice(19)
s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def state():
 x=m.snapshot();paths=set(m.git('diff','--name-only','-z','HEAD').split(b'\0'))|set(m.git('ls-files','--others','--exclude-standard','-z').split(b'\0'));rows={}
 for raw in paths:
  if not raw:continue
  p=raw.decode();f=C/p
  if not f.exists()and not f.is_symlink():rows[p]={'deleted':True};continue
  assert not f.is_symlink()and f.is_file(),p
  b=f.read_bytes();rows[p]={'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(f.stat().st_mode)}
 x['workingbytes']=rows;return x
marker=json.loads(Path('/workspace/PR1456-own-lap-renewal-20261030T0348/NEW-MARKER.json').read_text());assert m.api('git/ref/heads/lap/pr-1456')['object']['sha']==marker['sha'],'Owned1456lap changed';assert m.api('pulls/1456')['head']['sha']==price['secondary_head'],'Remote1456 head changed; reprice, do not guess';before=state();save('SOURCE-BEFORE.json',before);assert before['HEAD']==HEAD and m.git('branch','--show-current').decode().strip()==BRANCH and m.git('rev-parse','origin/dev').decode().strip()==OLD and not(m.G/'MERGE_HEAD').exists() and not before['status'];assert free('/workspace')>=price['required_workspace_bytes']and free('/tmp')>=TMPFLOOR
remote=m.api('git/commits/'+TIP);tree=m.api('git/trees/'+remote['tree']['sha']+'?recursive=1');assert not tree['truncated']and tree['sha']==price['tree'];leaves={r['path']:r for r in tree['tree']if r['type']!='tree'};save('REMOTE-COMMIT.json',remote)
groups={}
for r in tree['tree']:
 parent,_,name=r['path'].rpartition('/');groups.setdefault(parent,[]).append((name,r))
roots={'':tree['sha'],**{r['path']:r['sha']for r in tree['tree']if r['type']=='tree'}};meta={}
for path,tid in roots.items():
 rows=sorted(groups[path],key=lambda x:x[0].encode()+(b'/'if x[1]['type']=='tree'else b''));b=b''.join((('40000'if r['type']=='tree'else r['mode']).encode()+b' '+name.encode()+b'\0'+bytes.fromhex(r['sha']))for name,r in rows);assert m.gitsha('tree',b)==tid;meta[tid]=('tree',b)
def reconstruct(c):
 v=c['verification'];payload=v.get('payload');sig=v.get('signature')
 if payload and sig:
  h,msg=payload.encode().split(b'\n\n',1)
  for signature in [sig.encode(),sig.encode().rstrip(b'\n')]:
   lines=signature.split(b'\n');gpg=b'gpgsig '+b'\n '.join(lines);raw=h+b'\n'+gpg+b'\n\n'+msg
   if m.gitsha('commit',raw)==c['sha']:return raw
 if not sig:
  def actor(k):
   x=c[k];dt=datetime.datetime.fromisoformat(x['date'].replace('Z','+00:00'));return k+' '+x['name']+' <'+x['email']+'> '+str(int(dt.timestamp()))+' +0000'
  h=['tree '+c['tree']['sha'],*['parent '+p['sha']for p in c['parents']],actor('author'),actor('committer')]
  for ending in ['', '\n']:
   raw=('\n'.join(h)+'\n\n'+c['message']+ending).encode()
   if m.gitsha('commit',raw)==c['sha']:return raw
 raise AssertionError('Canonical commit reconstruction refused; no assumed timezone/signature: '+c['sha'])

for cid,c in json.loads((P/'NEW-COMMIT-GITDATA.json').read_text()).items():meta[cid]=('commit',reconstruct(c))
payloads={};rows=[]
for r in price['rows']:
 sid=r['sha'];kind=r['kind']
 if kind in('tree','commit'):
  actualkind,b=meta[sid];assert actualkind==kind
 elif 'feature_commit'in r:
  j=m.api('git/blobs/'+sid);b=base64.b64decode(j['content']);assert len(b)==j['size']
 else:
  with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+r.get('origin_tip',TIP)+'/'+quote(r['path'],safe='/'),headers={'User-Agent':'Chicago-incremental845-bounded-object-import'}),timeout=60)as f:b=f.read(r['bytes']+1);assert f.status==200
 assert len(b)==r['bytes']and sha(b)==r['sha256']and m.gitsha(kind,b)==sid
 enc=zlib.compress(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b);assert len(enc)==r['encoded_bytes']and sha(enc)==r['encoded_sha256'];payloads[sid]=enc;rows.append(r)
assert len(rows)==price['new_total_objects']and sum(r['bytes']for r in rows)==price['new_total_raw_bytes'];assert state()==before and free('/workspace')>=price['required_workspace_bytes']and free('/tmp')>=TMPFLOOR
written=[];already=[]
for r in rows:
 sid=r['sha']
 if sid in m.indexed([sid]):
  b=m.obj(r['kind'],sid);assert len(b)==r['bytes']and sha(b)==r['sha256'];already.append(sid);continue
 d=m.G/'objects'/sid[:2]/sid[2:];assert not d.exists();d.parent.mkdir(exist_ok=True);tmp=d.with_name(d.name+'.incremental845-'+str(os.getpid()));enc=payloads[sid]
 with tmp.open('xb')as f:f.write(enc);f.flush();os.fsync(f.fileno())
 assert tmp.read_bytes()==enc;os.link(tmp,d);tmp.unlink();os.chmod(d,0o444);raw=zlib.decompress(d.read_bytes());header,b=raw.split(b'\0',1);assert header==r['kind'].encode()+b' '+str(len(b)).encode()and len(b)==r['bytes']and m.gitsha(r['kind'],b)==sid and sha(b)==r['sha256'];written.append(sid);assert free('/workspace')>=FLOOR+RESERVE and free('/tmp')>=TMPFLOOR
assert m.commit(TIP)['tree']==tree['sha'];assert m.leaves(tree['sha'])=={p:(r['mode'],r['type'],r['sha'])for p,r in leaves.items()};ids={r['sha']for r in leaves.values()};assert ids<=m.indexed(ids)
assert m.git('merge-base',OLD,TIP).decode().strip()==OLD and state()==before
secondary=m.commit(price['secondary_head']);assert secondary['tree']==price['secondary_tree'];secondary_tree=m.api('git/trees/'+secondary['tree']+'?recursive=1');assert not secondary_tree['truncated'];secondary_leaves={r['path']:r for r in secondary_tree['tree']if r['type']!='tree'};assert m.leaves(secondary['tree'])=={p:(r['mode'],r['type'],r['sha'])for p,r in secondary_leaves.items()};assert {r['sha']for r in secondary_leaves.values()}<=m.indexed(r['sha']for r in secondary_leaves.values());all_blobs={r['sha']:r for r in [*leaves.values(),*secondary_leaves.values()]if r['type']=='blob'};lines=subprocess.check_output(['git','-C',str(C),'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],input=('\n'.join(sorted(all_blobs))+'\n').encode(),env=m.ENV);observed={sid:int(size)for sid,kind,size in(map(str.split,lines.decode().splitlines()))if kind=='blob'};assert observed=={sid:r['size']for sid,r in all_blobs.items()};assert m.api('pulls/1456')['head']['sha']==price['secondary_head'],'Remote1456 changed during import; objects retained but no refCAS';fresh=m.api('git/ref/heads/dev')['object']['sha'];assert fresh==TIP or m.api('compare/'+TIP+'...'+fresh)['status']=='ahead'
m.git('update-ref','refs/remotes/origin/dev',TIP,OLD);after=state();save('SOURCE-AFTER.json',after);expected=json.loads(json.dumps(before));expected['refs']=[x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+TIP)for x in expected['refs']];assert after==expected
save('RESULT.json',{'status':'ACTUAL_INCREMENTAL845_CANONICAL_IMPORT_ORIGIN3DD_CAS_ALL_SOURCE_GUARDS_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tip':TIP,'tree':tree['sha'],'old_origin_dev':OLD,'native_remote1456_head':price['secondary_head'],'native_remote1456_tree':price['secondary_tree'],'native_remote1456_all_tip_leaves_exact':len(secondary_leaves),'source_HEAD':HEAD,'source_branch':BRANCH,'written_objects':written,'already_exact':already,'all_tip_leaves_exact':len(leaves),'all_tip_objects_indexed':len(ids),'raw_bytes':price['new_total_raw_bytes'],'allocation_upper':price['new_total_allocation_upper_4k'],'source_HEAD_index_config_status_workingbytes_otherrefs_exact':True,'fetch':False,'workspace_free':free('/workspace'),'tmp_free':free('/tmp'),'remote_dev':fresh,'later_dev_unqualified':fresh!=TIP,'merge_native_owners_gate_phone_commit_publication_not_yet_run':True});print((O/'RESULT.json').read_text())
