"""Produce only external T2380 code/record candidates; never write the app tree."""
from pathlib import Path
import ast, difflib, hashlib, json
ROOT=Path('/workspace/chicago/chicago/4d')
OUT=Path(__file__).resolve().parent
BIND=json.loads(OUT.parent.joinpath('CURRENT-BINDINGS.json').read_text())
expected={Path(x['path']):x['sha256'] for x in BIND['files']}
def change(src, old, new):
 assert src.count(old)==1,repr(old[:90])
 return src.replace(old,new)
post={}
for rel in ['generators/archetypes/frame_dwelling_params.py','generators/archetypes/frame_dwelling.py']:
 p=ROOT/rel; raw=p.read_bytes(); assert hashlib.sha256(raw).hexdigest()==expected[p]
 post[rel]=raw.decode()
key='generators/archetypes/frame_dwelling_params.py';s=post[key]
s=change(s,'"trim", "chimney_head", "tower", "chimney_placement", "front_window_sill_m",','"trim", "chimney_head", "tower", "chimney_placement", "front_window_sill_m",\n    "picture_layout",')
s=change(s,'    # ---------------------------------------------------------------- derived\n','''    # T-2380: one opt-in retrospective keeper-house layout. None retains all
    # existing house paths; adding a loft light does not assert a habitable half storey.
    picture_layout: str | None = field(default=None, kw_only=True)

    # ---------------------------------------------------------------- derived

    @property
    def keeper_front_stations(self) -> tuple:
        """Gale's two sash followed by end door; numeric set-out reconstructed."""
        if self.picture_layout != "keeper_gale_1902":
            return ()
        return tuple((self.width_m * u, kind) for u, kind in
                     ((1.2 / 6.4, "window"), (3.15 / 6.4, "window"),
                      (5.45 / 6.4, "door")))

    @property
    def keeper_gable_sash_centres(self) -> tuple:
        """Two pictured west-end ground sash, independent of stack suppression."""
        if self.picture_layout != "keeper_gale_1902":
            return ()
        return (self.depth_m * (1.25 / 4.6), self.depth_m * (3.35 / 4.6))

    @property
    def keeper_loft_opening(self) -> tuple:
        """(centre-v, bottom-z, width, height); small light, not a storey claim."""
        if self.picture_layout != "keeper_gale_1902":
            return ()
        return (self.depth_m / 2, self.wall_height_m + 0.17, 0.42, 0.45)
''')
s=change(s,'        if self.chimney_placement == "far_gable":\n','''        if self.picture_layout == "keeper_gale_1902":
            return (self.width_m * (0.90 / 6.4),)
        if self.chimney_placement == "far_gable":
''')
s=change(s,'    def _validate_facade(self) -> None:\n','''    def _validate_facade(self) -> None:
        if self.picture_layout is not None:
            if self.picture_layout != "keeper_gale_1902":
                raise ParamError("picture_layout must be None or keeper_gale_1902")
            if (self.stories != 1.0 or self.ell or self.roof_type != "gable"
                    or self.plan != "hall_parlour" or self.bays != 3
                    or self.chimneys != 1 or self.stovepipes or self.tower
                    or self.chimney_placement != "house"
                    or self.front_window_sill_m is not None):
                raise ParamError("keeper_gale_1902 needs one-storey rectangular gabled "
                                 "hall_parlour, three front bays and one existing stack")
            stations = self.keeper_front_stations
            for i, (cx, kind) in enumerate(stations):
                half = _opening_w(self, kind) / 2
                if cx - half < 0.35 or cx + half > self.width_m - 0.35:
                    raise ParamError("keeper_gale_1902 front opening crosses corner trim")
                if i and _clash(stations[i - 1], stations[i], self):
                    raise ParamError("keeper_gale_1902 front openings overlap")
            g = self.keeper_gable_sash_centres
            if (g[0] - self.window_w_m / 2 < 0.35
                    or g[1] + self.window_w_m / 2 > self.depth_m - 0.35
                    or g[1] - g[0] < self.window_w_m + OPENING_GAP_M):
                raise ParamError("keeper_gale_1902 gable sash do not fit")
            _v, bottom, width, height = self.keeper_loft_opening
            # The cap is a gable, so ensure both loft-light upper corners fit
            # inside its wall-plane triangle, rather than only below the ridge.
            available = self.wall_height_m + (self.depth_m / 2 - width / 2) * math.tan(
                math.radians(self.roof_pitch_deg))
            if bottom + height + 0.10 > available:
                raise ParamError("keeper_gale_1902 loft light crosses the roof slope")
''')
s=change(s,'        front_window_sill_m=val("front_window_sill_m"),\n','        front_window_sill_m=val("front_window_sill_m"),\n        picture_layout=val("picture_layout"),\n')
s=change(s,'    if p.plan == "chapel_side":\n        return list(p.chapel_front_stations)\n','''    if p.picture_layout == "keeper_gale_1902":
        return list(p.keeper_front_stations)
    if p.plan == "chapel_side":
        return list(p.chapel_front_stations)
''')
post[key]=s
key='generators/archetypes/frame_dwelling.py';s=post[key]
s=change(s,'    # main range — omit the bottom, it is never seen and costs two triangles per\n','''    if params.picture_layout is not None:
        c_fen = max(c_fen, params.conf("picture_layout", "reconstructed"))

    # main range — omit the bottom, it is never seen and costs two triangles per
''')
s=change(s,'    if p.roof_type != "gable" or p.chapel_blank_gables:\n','''    if p.picture_layout == "keeper_gale_1902":
        _keeper_gale_gable(b, p, wall_z, c_fen, c_mass)
        # The unseen east gable is still reconstructed using the old house rule.
        # Generate it below, while suppressing only the replaced west end.
    if p.roof_type != "gable" or p.chapel_blank_gables:
''')
s=change(s,'    for x, out in ((0.0, -1), (w, 1)):\n        top = wall_z','''    for x, out in ((0.0, -1), (w, 1)):
        if p.picture_layout == "keeper_gale_1902" and out == -1:
            continue
        top = wall_z''')
s=change(s,'    for x, out in ((0.0, -1), (w, 1)):\n        if any(abs(sx - x)','''    for x, out in ((0.0, -1), (w, 1)):
        if p.picture_layout == "keeper_gale_1902" and out == -1:
            continue
        if any(abs(sx - x)''')
s=change(s,'# -------------------------------------------------------------------- the ell\n','''def _keeper_gale_gable(b: MeshBuilder, p: FrameDwellingParams, wall_z: float,
                       c_fen: float, c_mass: float) -> None:
    """The pictured west end only: two ground sash and a separate small loft light.

    Source topology is inferred; every set-out dimension is reconstructed. The
    optional source layout does not change the generic house's far-end arithmetic.
    """
    conf = max(c_fen, p.conf("picture_layout", "reconstructed"))
    sill = p.front_sill_m
    sash = _sash(p, sill, wall_z - 0.28)
    for v in p.keeper_gable_sash_centres:
        _window(b, p, "x", 0.0, v, sill, sash, -1, conf)
        if p.shutters:
            # Native panel primitive on x-normal end, same stock as front shutters.
            shutter_conf = max(conf, p.conf("shutters", "reconstructed"))
            for side in (-1, 1):
                v0 = v + side * (p.window_w_m / 2 + openings.CASING_W_M + 0.012)
                v1 = v0 + side * p.window_w_m * 0.5
                _panel(b, "x", -(CLAPBOARD_LIP_M + 0.008), min(v0, v1), max(v0, v1),
                       sill, sill + sash[0], -1, shutter_conf, M_SHUTTER)
    v, z0, width, height = p.keeper_loft_opening
    _fixed_light(b, p, "x", 0.0, v - width / 2, v + width / 2,
                 z0, z0 + height, -1, max(conf, c_mass))


# -------------------------------------------------------------------- the ell
''')
s=change(s,'''              (params.worst_conf("chimneys", "chimney_placement")
               if params.chimney_placement != "house"
               else params.conf("chimneys", "reconstructed")),''','''              (params.worst_conf("chimneys", "picture_layout")
               if params.picture_layout is not None else
               (params.worst_conf("chimneys", "chimney_placement")
                if params.chimney_placement != "house"
                else params.conf("chimneys", "reconstructed"))),''')
s=change(s,'    if params.tower:\n','''    if params.picture_layout == "keeper_gale_1902":
        _keeper_front_rail(b, params, d, params.conf("picture_layout", "reconstructed"))

    if params.tower:
''')
s=change(s,'def _keeper_gale_gable(','''def _keeper_front_rail(b: MeshBuilder, p: FrameDwellingParams, d: float,
                       conf: float) -> None:
    """Low unroofed front rail in Gale; exact stock/set-out reconstructed.

    Keep the native doorway's full safety band clear. This rail is part of the
    pictured keeper-house frontage; the separate compound gate remains pending.
    """
    door = next(cx for cx, kind in p.keeper_front_stations if kind == "door")
    a, end = 0.12, door - DOOR_W_M / 2 - 0.40
    y = d + 0.60
    for z in (0.30, 0.80):
        b.add_box(a, y - 0.035, z - 0.035, end, y + 0.035, z + 0.035,
                  conf, M_TRIM)
    for x in (a, end / 3, end * 2 / 3, end):
        b.add_box(x - 0.045, y - 0.045, 0.0, x + 0.045, y + 0.045, 0.88,
                  conf, M_TRIM, skip=("bottom",))


def _keeper_gale_gable(''')
post[key]=s
for rel,src in post.items():
 ast.parse(src)
 target=OUT/'postimages'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(src)
 diff=''.join(difflib.unified_diff((ROOT/rel).read_text().splitlines(True),src.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 (OUT/(Path(rel).stem+'.diff')).write_text(diff)
print('prepared',list(post))
