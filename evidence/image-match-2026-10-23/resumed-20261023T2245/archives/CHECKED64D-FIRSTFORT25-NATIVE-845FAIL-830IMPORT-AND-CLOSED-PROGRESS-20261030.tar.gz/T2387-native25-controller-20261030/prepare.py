from pathlib import Path
import json,hashlib,datetime,shutil,ast
P=Path(__file__).resolve().parent; A=Path('/workspace/chicago/chicago/4d'); I=Path('/workspace/T2387-first-fort-readiness-20261030')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def b(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'mode':p.stat().st_mode&0o777}
old=json.loads((I/'OFFICIAL-25FAMILY-BAKE-PLAN.json').read_text()); copies=[]
for p in sorted((A/'generators').rglob('*')):
 if not p.is_file() or '__pycache__'in p.parts or p.suffix not in ['.py','.pin']:continue
 rel=str(p.relative_to(A));post=I/'candidate'/p.name if rel in ['generators/archetypes/fort_structure.py','generators/archetypes/fort_structure_params.py']else p
 copies.append({'rel':rel,'source':b(p),'postimage':b(post)})
for rel in ['tools/web_derivatives.sh','tools/structure_versions.py','tools/web_derivative_baseline.json','tools/photo_match.mjs','tools/photo_match_group.mjs','tools/photo_match_enclosures.mjs','tools/photo_match_flora.mjs']:
 p=A/rel;copies.append({'rel':rel,'source':b(p),'postimage':b(p)})
regs=['assets/manifest.json','assets/manifest.web.json','assets/manifest.versions.json']; group=json.loads((I/'CURRENT-GROUP30-BINDING.json').read_text()); reads=[]
for r in old['family']:reads.append(b(A/'data/structures'/(r['id']+'.json')))
for r in group['rendered_members']:reads += [b(A/'data/sidecars/1812'/(r['structure_id']+'.json')),b(A/r['glb'])]
reads += [b(A/'data/datum.json'),b(A/'data/sources/assets/prefire_views_kevin_2026_08/p4_0.png')]
reads += [b(p)for p in sorted((A/'data/scenes').glob('*.json'))]
# Narrow browser runtime file bindings; runtime directories themselves are linked read-only.
for rel in ['renderers/web/js/keith-stone.js','renderers/web/vendor/three-0.185.1/three.module.js','renderers/web/vendor/three-0.185.1/three.core.js','renderers/web/vendor/three-0.185.1/addons/loaders/GLTFLoader.js','renderers/web/vendor/three-0.185.1/addons/loaders/KTX2Loader.js','renderers/web/vendor/three-0.185.1/addons/libs/meshopt_decoder.module.js']:
 reads.append(b(A/rel))
scaffold=sum(r['postimage']['bytes']for r in copies)+sum((A/r).stat().st_size for r in regs)
masters=list((A/'assets/gltf').rglob('*.glb')); symlink_envelope=len(masters)*4096
plan={'status':'PREPARED_UNRUN_NO_FIXTURE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'primary':str(A),'readiness_manifest':b(I/'MANIFEST.json'),'readiness_plan':b(I/'OFFICIAL-25FAMILY-BAKE-PLAN.json'),'camera':b(I/'camera-proposals/first-fort-panel-1-CANONICAL-PROPOSAL-UNFITTED.json'),'copies':copies,'reads':reads,'family':old['family'],'candidate_records':[b(I/'candidate'/f'{sid}.json')for sid in ['first_fort_dearborn_blockhouse_nw','first_fort_dearborn_blockhouse_se']],'regs':regs,'reaper':b(Path('/workspace/shared/run-with-reaping.py')),'blender':'/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender','cpu':'0,1,3,4','threads':4,'workspace_floor':536870912,'tmp_floor':1800000000,'start_extra_reserve':24*1024*1024,'capture_extra_reserve':10*1024*1024,'scaffold_bytes':scaffold,'foreign_MASTER_symlink_fs_upper_estimate':symlink_envelope,'family_MASTER_WEB_bytes':old['total_master_bytes']+old['total_web_bytes'],'native_group_sha256':group['group_sha256'],'no_fort_versions':True,'grant':'T2387_NATIVE_CPU=root-approved-after-1456-phone','timing_basis':{'prior_exact50fort_exports_wall_s':6.278,'prior_candidate25_emit_sum_s':2.445,'prior_official_single_WEB_wall_s':3.062,'estimated_this_BUILD_s':[4,15],'estimated_WEB25_s':[45,100],'estimated_two_group_captures_s':[5,30],'estimated_total_s':[60,180],'bounds_are_estimates_not_guarantees':True}}
(P/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'copies':len(copies),'scaffold_bytes':scaffold,'symlink_upper_bytes':symlink_envelope,'reserve':plan['start_extra_reserve'],'workspace_free':shutil.disk_usage('/workspace').free,'TMP_free':shutil.disk_usage('/tmp').free,'no_fixture':True}))
