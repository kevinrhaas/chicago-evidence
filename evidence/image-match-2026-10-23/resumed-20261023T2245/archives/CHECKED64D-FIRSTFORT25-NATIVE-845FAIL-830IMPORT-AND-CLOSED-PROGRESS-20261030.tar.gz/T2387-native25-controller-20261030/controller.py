"""Finite two-cupola official25 build/WEB plus full30 diagnostic pair. UNRUN until root grant."""
from __future__ import annotations
import argparse,ast,copy,datetime,hashlib,json,os,pathlib,shutil,signal,stat,subprocess,sys,time
sys.dont_write_bytecode=True
P=pathlib.Path(__file__).resolve().parent; PLAN=json.loads((P/'PLAN.json').read_text()); A=pathlib.Path(PLAN['primary']); I=pathlib.Path(PLAN['readiness_manifest']['path']).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def need(c,m):
 if not c:raise RuntimeError(m)
def bound(r):
 p=pathlib.Path(r['path']);need(p.is_file() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],'bound input changed: '+str(p))
def floors(extra=0):
 need(shutil.disk_usage('/workspace').free>=PLAN['workspace_floor']+extra,'workspace floor/reserve');need(shutil.disk_usage('/tmp').free>=PLAN['tmp_floor'],'TMP floor')
def guard_inputs():
 for r in [PLAN['readiness_manifest'],PLAN['readiness_plan'],PLAN['camera'],PLAN['reaper'],*PLAN['reads'],*PLAN['candidate_records']]:bound(r)
 for r in PLAN['copies']:bound(r['source']);bound(r['postimage'])
 man=json.loads((A/'assets/manifest.json').read_text())['assets']
 for r in PLAN['family']:
  need(sha(A/'data/structures'/(r['id']+'.json'))==r['record_sha256'],'family record changed '+r['id'])
  for sub,key in [('gltf','master_sha256'),('web','web_sha256')]:need(sha(A/'assets'/sub/r['asset'])==r[key],'family asset changed '+r['asset'])
  need(man[r['asset']]['inputs_sha256']==r['current_native_recipe_sha256'],'current native recipe changed '+r['asset'])
def preflight():
 guard_inputs();floors();need(len(PLAN['family'])==25 and sum(r['role'].startswith('default')for r in PLAN['family'])==23,'family scope')
 for r in PLAN['copies']:
  if r['postimage']['path'].endswith('.py'):ast.parse(pathlib.Path(r['postimage']['path']).read_text())
 return {'status':'PURE_PREFLIGHT_PASS_NO_FIXTURE_NO_HEAVY','at':now(),'family':25,'defaultNone':23,'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free,'start_extra_reserve':PLAN['start_extra_reserve'],'start_fits':shutil.disk_usage('/workspace').free>=PLAN['workspace_floor']+PLAN['start_extra_reserve']}
class Run:
 def __init__(self,args):
  self.args=args;self.R=P/'run';self.F=self.R/'fixture';self.D=self.R/'receipts';self.C=self.R/'closed-authority';self.tmp=self.R/'tmp';self.deadline=time.monotonic()+args.seconds
  self.E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',NODE_DISABLE_COMPILE_CACHE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PW_EXECUTABLE='/usr/bin/chromium',TMPDIR=str(self.tmp),XDG_CACHE_HOME=str(self.tmp/'xdg-cache'))
 def gitstate(self):
  repo=A.parent.parent;g=lambda args:subprocess.check_output(['git','-C',str(repo),*args],env=self.E)
  return {'head':g(['rev-parse','HEAD']).decode().strip(),'status_sha256':hashlib.sha256(g(['status','--porcelain=v1','-uno'])).hexdigest(),'index_sha256':sha(repo/'.git/index'),'config_sha256':sha(repo/'.git/config')}
 def primary_guard(self,full=False):
  for rel,h in self.initial['registries'].items():need(sha(A/rel)==h,'primary registry changed during source lease')
  need(self.gitstate()==self.initial['git'],'primary Git/source status changed during source lease')
  if full:guard_inputs()
 def link(self,source,rel):
  q=self.F/rel;q.parent.mkdir(parents=True,exist_ok=True);need(not q.exists()and not q.is_symlink(),'existing link slot '+str(q));q.symlink_to(source,target_is_directory=pathlib.Path(source).is_dir())
 def setup(self):
  guard_inputs();floors(PLAN['start_extra_reserve']);need(not self.R.exists(),'run directory exists; use --capture-only to resume closed family')
  self.D.mkdir(parents=True);self.tmp.mkdir();self.C.mkdir();self.initial={'at':now(),'git':self.gitstate(),'registries':{r:sha(A/r)for r in PLAN['regs']},'primary_freeze_required':True}
  save(self.R/'INITIAL.json',self.initial)
  for r in PLAN['copies']:
   dest=self.F/r['rel'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r['postimage']['path'],dest);dest.chmod(r['postimage']['mode'])
  for rel in PLAN['regs']:
   q=self.F/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(A/rel,q)
  # Owned source/output dirs; read-only foreign links retain every registry row.
  for rel in ['assets/gltf','assets/web','assets/bakes','data/structures','data/reference_views']:(self.F/rel).mkdir(parents=True,exist_ok=True)
  for rel in ['data/scenes','data/datum.json','data/sidecars','data/sources','assets/textures','docs','renderers']:self.link(A/rel,rel)
  for src in sorted((A/'assets/gltf').rglob('*.glb')):self.link(src,str(src.relative_to(A)))
  for r in PLAN['family']:self.link(A/'data/structures'/(r['id']+'.json'),'data/structures/'+r['id']+'.json')
  for r in PLAN['candidate_records']:
   q=self.F/'data/structures'/pathlib.Path(r['path']).name;need(q.is_symlink(),'candidate source slot not read link');q.unlink();shutil.copyfile(r['path'],q)
  # Current native runtime is read-only; no node/npm/runtime copy.
  self.link('/workspace/shared/node/node_modules','node_modules')
  self.regs={r:json.loads((self.F/r).read_text())for r in PLAN['regs']};self.primary_guard(True);save(self.R/'FIXTURE-READY.json',{'status':'SMALL_OWNED_FIXTURE_PREPARED','at':now(),'primary_unmodified':True,'cpu':PLAN['cpu']})
 def resume(self):
  need((self.R/'FAMILY-CLOSED.json').exists(),'no closed family to resume');self.initial=json.loads((self.R/'INITIAL.json').read_text());self.regs={r:json.loads((self.F/r).read_text())for r in PLAN['regs']};self.primary_guard(True)
 def stage(self,label,argv,limit):
  floors();self.primary_guard();need(time.monotonic()<self.deadline,'controller lease expired');log=self.D/(label+'.log');reap=self.D/(label+'-REAPER.json');need(not log.exists()and not reap.exists(),'stage already exists '+label)
  full=[sys.executable,PLAN['reaper']['path'],str(reap),'--','nice','-n','19','taskset','-c',PLAN['cpu'],*argv];started=time.monotonic();why=None;minimum={'workspace':shutil.disk_usage('/workspace').free,'tmp':shutil.disk_usage('/tmp').free}
  with log.open('x')as f:
   proc=subprocess.Popen(full,cwd=self.F,env=self.E,stdout=f,stderr=subprocess.STDOUT)
   while proc.poll()is None:
    try:
     floors();minimum={k:min(v,shutil.disk_usage('/workspace'if k=='workspace'else'/tmp').free)for k,v in minimum.items()};need(time.monotonic()-started<limit and time.monotonic()<self.deadline,'native stage/lease timeout')
     for rel,h in self.initial['registries'].items():need(sha(A/rel)==h,'primary source lease changed')
    except Exception as e:why=str(e);proc.send_signal(signal.SIGTERM);break
    time.sleep(.5)
   try:proc.wait(timeout=20)
   except subprocess.TimeoutExpired:raise RuntimeError('owned reaper did not finish: preserve state and notify root')
  result=json.loads(reap.read_text());row={'stage':label,'at':now(),'argv':full,'seconds':round(time.monotonic()-started,3),'exit':proc.returncode,'reaper_command_exit':result['command_exit'],'all_children_reaped':result['all_children_reaped'],'stop_reason':why,'minimum_free_bytes':minimum};save(self.D/(label+'-RESULT.json'),row);print(json.dumps(row),flush=True)
  need(proc.returncode==0 and result['command_exit']==0 and result['all_children_reaped']and why is None,'native stage failed; preserve outputs '+label);floors();self.primary_guard(True);return row
 def actual_recipes(self):
  code='''import sys,json;from pathlib import Path;sys.dont_write_bytecode=True;sys.path.insert(0,"generators");import mesh_inputs;out={}
for p in sorted(Path("data/structures").glob("*.json")):
 r=json.loads(p.read_text())
 for ph in r["phases"]:out[r["id"]+":"+ph["id"]]=mesh_inputs.structure_inputs_sha(r,ph)
print(json.dumps(out))'''
  got=json.loads(subprocess.check_output([sys.executable,'-c',code],cwd=self.F,env=self.E,text=True));wanted={r['id']+':'+r['phase']:r['proposed_recipe_sha256_EXPECTED_NOT_BUILT']for r in PLAN['family']};need(got==wanted,'ACTUAL native fixture recipes differ');save(self.R/'ACTUAL-NATIVE-RECIPE-PREFLIGHT.json',{'status':'ALL25_EXPECTED_EXACT','hashes':got})
 def registry_guard(self,names):
  out={r:json.loads((self.F/r).read_text())for r in PLAN['regs']}
  for rel,key in [('assets/manifest.json','assets'),('assets/manifest.web.json','masters')]:
   old=self.regs[rel];new=out[rel];need(set(old[key])==set(new[key]),'registry key set changed '+rel);need({k:v for k,v in old[key].items()if k not in names}=={k:v for k,v in new[key].items()if k not in names},'foreign registry rows changed '+rel);need({k:v for k,v in old.items()if k!=key}=={k:v for k,v in new.items()if k!=key},'registry metadata changed '+rel)
  need(out['assets/manifest.versions.json']==self.regs['assets/manifest.versions.json'],'versions changed');return out
 def family(self):
  self.actual_recipes();names=[r['asset']for r in PLAN['family']]
  for name in names:
   q=self.F/'assets/gltf'/name;need(q.is_symlink()and q.resolve()==A/'assets/gltf'/name,'selected MASTER slot unsafe');q.unlink();need(not (self.F/'assets/web'/name).exists(),'WEB slot already exists')
  ids=','.join(r['id']for r in PLAN['family']);wrote=self.R/'WROTE.txt'
  build=self.stage('BUILD25',[PLAN['blender'],'--background','--factory-startup','--threads',str(PLAN['threads']),'--python-exit-code','1','--python-expr','import sys;sys.dont_write_bytecode=True','--python',str(self.F/'generators/build.py'),'--','--only',ids,'--wrote',str(wrote)],90)
  need(wrote.read_text().splitlines()==names,'official WROTE did not equal25 expected');need(all((self.F/'assets/gltf'/n).is_file()and not(self.F/'assets/gltf'/n).is_symlink()for n in names),'MASTER not owned regular')
  web=self.stage('WEB25',['bash','tools/web_derivatives.sh','--only',','.join(wrote.read_text().splitlines())],180);out=self.registry_guard(set(names));rows=[]
  for r in PLAN['family']:
   n=r['asset'];m=self.F/'assets/gltf'/n;w=self.F/'assets/web'/n;need(m.is_file()and w.is_file()and not m.is_symlink()and not w.is_symlink(),'outputs not regular '+n);entry=out['assets/manifest.json']['assets'][n];need(entry['inputs_sha256']==r['proposed_recipe_sha256_EXPECTED_NOT_BUILT']and entry['bytes']==m.stat().st_size,'native entry incorrect '+n);need(out['assets/manifest.web.json']['masters'][n]==sha(m),'WEB MASTER binding incorrect '+n)
   sameM=m.read_bytes()==(A/'assets/gltf'/n).read_bytes();sameW=w.read_bytes()==(A/'assets/web'/n).read_bytes();default=r['role'].startswith('default');need(sameM and sameW if default else not sameM and not sameW,'default23parity / two opt-in changes failed '+n)
   rows.append({'asset':n,'id':r['id'],'default_None':default,'MASTER_sha256':sha(m),'MASTER_bytes':m.stat().st_size,'WEB_sha256':sha(w),'WEB_bytes':w.stat().st_size,'MASTER_exact_primary':sameM,'WEB_exact_primary':sameW,'native_entry':entry,'WEB_master_binding':out['assets/manifest.web.json']['masters'][n]})
  save(self.C/'NATIVE25-ENTRIES.json',{'status':'GENUINE_OFFICIAL25_BUILD_AND_WEB_PASS','rows':rows,'foreign_rows_exact':True,'versions_exact':True});save(self.R/'FAMILY-CLOSED.json',{'status':'ACTUAL_OFFICIAL25_BUILD_WEB_AND23DEFAULT_BYTEPARITY_PASS','at':now(),'stages':[build,web],'all25_recipe_hashes_actual_exact':True,'default23_MASTER_WEB_bytes_exact':True,'two_opt_in_MASTER_WEB_changed':True,'primary_unmodified':True,'native_captures':'PENDING','original_DONE':False})
  # Close two changed payloads before any photo stage; no all-or-nothing capture loss.
  retired=[]
  for r in rows:
   for sub in ['gltf','web']:
    q=self.F/'assets'/sub/r['asset']
    if r['default_None']:
     need(q.read_bytes()==(A/'assets'/sub/r['asset']).read_bytes(),'default restore-authority bytes changed');retired.append({'asset':r['asset'],'sub':sub,'sha256':sha(q),'bytes':q.stat().st_size,'restore_authority':str(A/'assets'/sub/r['asset'])});q.unlink();q.symlink_to(A/'assets'/sub/r['asset'])
    else:
     dest=self.C/('native-master'if sub=='gltf'else'native-web')/r['asset'];dest.parent.mkdir(exist_ok=True);q.rename(dest);q.symlink_to(dest)
  save(self.C/'DEFAULT23-RESTORE-AUTHORITY.json',{'status':'RETIRED_AFTER_NATIVE_PARITY_WITH_EXACT_PRIMARY_RESTORE_AUTHORITY','rows':retired});self.close_manifest('FAMILY_NATIVE_CLOSED_CAPTURE_PENDING')
 def group(self,label):
  code='''import fs from "node:fs";import{renderGroup,groupReview}from"./tools/photo_match_group.mjs";const c=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));console.log(JSON.stringify(groupReview(process.cwd(),renderGroup(process.cwd(),c))));'''
  return json.loads(subprocess.check_output(['node','--input-type=module','-e',code,str(self.camfile)],cwd=self.F,env=self.E,text=True))
 def capture(self):
  floors(PLAN['capture_extra_reserve']);need((self.R/'FAMILY-CLOSED.json').exists(),'family must close first');cam=json.loads(pathlib.Path(PLAN['camera']['path']).read_text());cam['photo']=str(A/'data/sources/assets/prefire_views_kevin_2026_08/p4_0.png');need(len(cam['also_render'])==29 and not cam.get('enclosures')and not cam.get('flora'),'scope must be exact original30 only')
  capture_rows=[]
  for label in ['before','after']:
   for r in PLAN['family']:
    if r['role'].startswith('default'):continue
    q=self.F/'assets/gltf'/r['asset'];need(q.is_symlink(),'candidate capture slot must be guarded link');q.unlink();q.symlink_to(A/'assets/gltf'/r['asset']if label=='before'else self.C/'native-master'/r['asset'])
   camdir=self.F/'data/reference_views'/cam['structure_id']/label;camdir.mkdir(parents=True,exist_ok=False);self.camfile=camdir/'first-fort-panel-1.json';save(self.camfile,cam);need((camdir/pathlib.Path(cam['photo'])).resolve()==(A/'data/sources/assets/prefire_views_kevin_2026_08/p4_0.png').resolve(),'camera photo path escapes expected source');need((camdir/pathlib.Path(cam['photo'])).is_file(),'camera source picture missing');g=self.group(label);need(len(g['rendered_members'])==30,'group omitted member')
   if label=='before':need(g['group_sha256']==PLAN['native_group_sha256'],'baseline native group changed')
   else:
    before=capture_rows[0]['group'];old={r['structure_id']:r for r in before['rendered_members']};diff=[]
    for r in g['rendered_members']:
     o=old[r['structure_id']];need({k:v for k,v in r.items()if k!='glb_sha256'}=={k:v for k,v in o.items()if k!='glb_sha256'},'placement/path changed');
     if r['glb_sha256']!=o['glb_sha256']:diff.append(r['structure_id'])
    need(set(diff)=={pathlib.Path(r['path']).stem for r in PLAN['candidate_records']},'full30 group changed beyond two opt-ins')
   stage=self.stage('PHOTO_'+label,['node','tools/photo_match.mjs',str(self.camfile),'--out',str(self.R/'capture'/label)],75);match=json.loads(self.camfile.with_suffix('.match.json').read_text());need(match['verdict']=='unreviewed'and match['group_sha256']==g['group_sha256'],'native capture binding/verdict unexpected');need(len(match['rendered_members'])==30,'actual capture missing30');log=(self.D/('PHOTO_'+label+'.log')).read_text();raws=[pathlib.Path(line.strip())for line in log.splitlines()if line.strip().endswith('-render.png')];need(len(raws)==1 and raws[0].is_file(),'native raw render not found');dest=self.R/'capture'/label/'first-fort-panel-1-render.png';raws[0].rename(dest);shutil.copyfile(self.camfile,dest.parent/'native-camera.json');shutil.copyfile(self.camfile.with_suffix('.match.json'),dest.parent/'native.match.json');capture_rows.append({'label':label,'stage':stage,'group':g,'match':match,'raw_render':str(dest),'side_by_side':str(self.F/match['side_by_side'])})
  save(self.R/'CAPTURE-CLOSED.json',{'status':'ACTUAL_NATIVE30_BEFORE_AFTER_CAPTURED_UNREVIEWED_UNFITTED_CAMERA','at':now(),'captures':capture_rows,'only_two_model_payloads_changed':True,'camera_bytes_identical':sha(self.F/'data/reference_views'/cam['structure_id']/'before/first-fort-panel-1.json')==sha(self.camfile),'source_camera_disagreement_unresolved':True,'matches_claimed':False,'root_visual_review':'PENDING','original_DONE':False});self.close_manifest('FAMILY25_AND30_BEFORE_AFTER_NATIVE_CLOSED_UNREVIEWED')
 def retire(self):
  need(self.args.root_viewed,'explicit root native-pair view not acknowledged');need((self.R/'CAPTURE-CLOSED.json').exists(),'full native pair must close before retirement');self.resume()
  manifest=json.loads((self.R/'CLOSED-MANIFEST.json').read_text())
  for r in manifest['members']:q=P/r['path'];need(q.is_file()and q.stat().st_size==r['bytes']and sha(q)==r['sha256'],'closed authority changed before retirement')
  for r in self.D.glob('*-REAPER.json'):
   x=json.loads(r.read_text());need(x['command_exit']==0 and x['all_children_reaped'],'native owned child not closed')
  before=shutil.disk_usage('/workspace').free
  for q in [self.F,self.tmp]:
   need(q.parent==self.R and not q.is_symlink(),'retirement boundary unsafe');shutil.rmtree(q)
  save(self.R/'FIXTURE-RETIRED.json',{'status':'OWN_DISPOSABLE_FIXTURE_AND_SCRATCH_RETIRED_AFTER_VERIFIED_CLOSED_AUTHORITY_AND_ROOT_NATIVE_PAIR_VIEW','at':now(),'removed':[str(self.F),str(self.tmp)],'native_code_restore_authority':self.initial['git']['head'],'code_bindings':'PLAN.json copies/source/postimage hashes; unchanged native sources pinned at source parent, candidate bytes retained in immutable readiness packet','default23_restore_authority':'closed-authority/DEFAULT23-RESTORE-AUTHORITY.json','closed_changed_MASTER_WEB_recipes_logs_camera_native_matches_raw_and_side_by_sides_preserved':True,'workspace_free_before':before,'workspace_free_after':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free});self.close_manifest('NATIVE25_AND30PAIR_AUTHORITY_CLOSED_OWN_FIXTURE_RETIRED');print(json.dumps({'retired_own_fixture':True,'workspace_free':shutil.disk_usage('/workspace').free}),flush=True)
 def close_manifest(self,status):
  self.primary_guard(True);files=[]
  # Do not duplicate fixture registries or runtime/models; retain narrow authoritative entries.
  for p in sorted(self.R.rglob('*')):
   if not p.is_file()or p.is_symlink()or self.F in p.parents or self.tmp in p.parents or p.name=='CLOSED-MANIFEST.json':continue
   files.append({'path':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':sha(p)})
  save(self.R/'CLOSED-MANIFEST.json',{'status':status,'at':now(),'members':files,'bytes':sum(x['bytes']for x in files),'fixture_disposable_excluded':True,'native_tmp_profiles_excluded':True,'all_primary_inputs_Git_assets_registries_exact':True})
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--retire-fixture',action='store_true');ap.add_argument('--root-viewed',action='store_true');ap.add_argument('--family-only',action='store_true');ap.add_argument('--capture-only',action='store_true');ap.add_argument('--seconds',type=int,default=330);args=ap.parse_args()
 if not args.execute and not args.retire_fixture:print(json.dumps(preflight(),indent=2));return
 need(os.environ.get('T2387_NATIVE_CPU')=='root-approved-after-1456-phone','explicit root CPU grant missing; no fixture/heavy work');need(not(args.family_only and args.capture_only),'conflicting phase flags');run=Run(args)
 if args.retire_fixture:run.retire();return
 if args.capture_only:run.resume()
 else:run.setup();run.family()
 if not args.family_only:run.capture()
 print(json.dumps({'status':'EXECUTION_PHASE_CLOSED','family':str(run.R/'FAMILY-CLOSED.json'),'capture':str(run.R/'CAPTURE-CLOSED.json')if(run.R/'CAPTURE-CLOSED.json').exists()else'PENDING','no_original_DONE':True}),flush=True)
if __name__=='__main__':main()
