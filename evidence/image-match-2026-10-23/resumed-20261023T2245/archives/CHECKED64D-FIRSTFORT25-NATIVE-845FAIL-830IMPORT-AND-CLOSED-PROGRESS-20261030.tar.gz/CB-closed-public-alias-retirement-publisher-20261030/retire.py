from pathlib import Path,PurePosixPath
from urllib.request import Request,urlopen
import os,sys,json,hashlib,stat,gzip,io,tarfile,datetime
O=Path(__file__).parent;W=Path('/workspace');P=W/'checked2b-owners-phone-CBapp-and-renewal-checkpoint-publisher-20261030';pub=json.loads((P/'PUBLICATION.json').read_text());rec=pub['new_archive_records'][0];ANCHOR=pub['commit'];ROOT=W/'T2382-published-BOTH-current2b01-20261030';h=lambda b:hashlib.sha256(b).hexdigest();gs=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();dump=lambda n,j:(O/n).write_text(json.dumps(j,indent=2)+'\n');free=lambda p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize
os.sched_setaffinity(0,{1});os.nice(19)
def raw(path):
 with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago-evidence/'+ANCHOR+'/'+path,headers={'User-Agent':'Chicago-exact716-owned-alias-retirement'}),timeout=60)as r:assert r.status==200;return r.read()
tr=rec['remote_transport'];parts=[]
for row in tr['parts']:
 b=raw(row['path']);assert len(b)==row['bytes']and h(b)==row['sha256']and gs(b)==row['git_blob'];parts.append(b)
archive=b''.join(parts);assert len(archive)==rec['bytes']and h(archive)==rec['sha256'];del parts
sidepath=next(r['path']for r in pub['readback']if r['path'].endswith(rec['name']+'.tar.gz.manifest.json'));sidebytes=raw(sidepath);sideproof=next(r for r in pub['readback']if r['path']==sidepath);assert h(sidebytes)==sideproof['sha256']and len(sidebytes)==sideproof['bytes']and gs(sidebytes)==sideproof['git_blob'];side=json.loads(sidebytes);expected={r['path']:r for r in side['files']};member='checked2b-owners-phone-CBapp-and-renewal-checkpoint-publisher-20261030/CB-RUNTIME-SYMLINKS.json.gz';remote_inventory=None
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz')as tf:
 entries=tf.getmembers();assert len(entries)==len(expected)and{m.name for m in entries}==set(expected)
 for m in entries:
  r=expected[m.name];assert m.isfile()and m.size==r['bytes']and m.mode==r['mode'];b=tf.extractfile(m).read();assert h(b)==r['sha256']
  if m.name==member:remote_inventory=b
assert remote_inventory is not None and remote_inventory==(P/'CB-RUNTIME-SYMLINKS.json.gz').read_bytes();inventory=json.loads(gzip.decompress(remote_inventory));links=inventory['links'];assert len(links)==1804 and len({r['path']for r in links})==1804
owned_roots=[Path(r['path'])for r in json.loads((P/'CB-RUNTIME-RESTORE.json').read_text())['roots']];assert set(owned_roots)=={ROOT/'site',Path(str(ROOT)+'-inputs')/'curation'}
def live_related():
 ancestors=set();pid=os.getpid()
 while pid>1 and pid not in ancestors:
  ancestors.add(pid)
  try:pid=int(Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()[1])
  except (FileNotFoundError,ProcessLookupError,PermissionError):break
 out=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit()or int(proc.name)in ancestors:continue
  try:
   cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace');cwd=os.readlink(proc/'cwd')
   if str(ROOT)in cmd or str(ROOT)in cwd:out.append({'pid':int(proc.name),'cmdline':cmd,'cwd':cwd})
  except (FileNotFoundError,ProcessLookupError,PermissionError,OSError):continue
 return out
assert not live_related(),'An active CB packet consumer exists; do not retire'
verified=[]
for r in links:
 p=Path(r['path']);assert p.is_absolute()and any(p.is_relative_to(root)for root in owned_roots)
 for parent in p.parents:
  if parent==W:break
  assert stat.S_ISDIR(parent.lstat().st_mode)and not parent.is_symlink(),parent
 s=p.lstat();assert stat.S_ISLNK(s.st_mode)and stat.S_IMODE(s.st_mode)==0o777 and s.st_nlink==1 and os.readlink(p)==r['target'],p
 verified.append({'path':str(p),'target':r['target'],'mode':stat.S_IMODE(s.st_mode),'dev':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512})
proof=(json.dumps({'status':'ALL_1804_LOCAL_LINKS_EXACT_716_PATH_TARGET_AND_LINUX_0777_MODE','inventory_mode_limit':'716 inventory stores path+target, no perlink mode. Linux symlinks have0777 permission mode; every actual mode is verified and captured here.','rows':verified},indent=2)+'\n').encode();gz=gzip.compress(proof,mtime=0);(O/'VERIFIED-LOCAL-ALIASES.json.gz').write_bytes(gz)
pre={'status':'STRICT_IMMUTABLE716_ALL_MEMBERS_AND_LOCAL1804_ALIAS_PREFLIGHT_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'anchor':ANCHOR,'archive_sha256':h(archive),'archive_bytes':len(archive),'all_archive_members_verified':len(expected),'inventory_member':member,'inventory_gzip_sha256':h(remote_inventory),'inventory_gzip_bytes':len(remote_inventory),'local_perlink_proof_sha256':h(gz),'local_perlink_proof_bytes':len(gz),'links':len(links),'ordinary_ancestors_exact':True,'no_live_CB_packet_consumer':True,'only_symlink_unlink_authorized':True,'expected_link_allocated_bytes':sum(r['allocated_bytes']for r in verified)};dump('PREFLIGHT.json',pre);print(json.dumps(pre),flush=True)
assert not live_related();before=free('/workspace');beforetmp=free('/tmp');removed=[]
for r in verified:
 p=Path(r['path']);s=p.lstat();assert stat.S_ISLNK(s.st_mode)and stat.S_IMODE(s.st_mode)==r['mode']and s.st_dev==r['dev']and s.st_ino==r['inode']and s.st_nlink==1 and os.readlink(p)==r['target'];p.unlink();removed.append(r['path'])
after=free('/workspace');aftertmp=free('/tmp');assert len(removed)==1804 and all(not Path(p).is_symlink()and not Path(p).exists()for p in removed)
result={'status':'ACTUAL_ONLY1804_OWN_CLOSED_PUBLIC_ALIAS_SYMLINKS_RETIRED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'links_retired':len(removed),'workspace_before':before,'workspace_after':after,'observed_workspace_reclaimed':after-before,'sum_link_allocations_before':pre['expected_link_allocated_bytes'],'tmp_before':beforetmp,'tmp_after':aftertmp,'target_or_ordinary_or_directory_or_private_files_removed':False,'primary_source_Git_mirror_target_operations':False,'no_live_consumer_confirmed':True,'restore':{'publication_anchor':ANCHOR,'complete_availability_commit':'00f1d72aeae3bced9f73ab30b01dc99d7974ee90','archive_sha256':rec['sha256'],'transport':tr,'inventory_member':member,'inventory_gzip_sha256':h(remote_inventory),'inventory_gzip_bytes':len(remote_inventory),'instructions':'Read immutable716chunks at publication anchor, verify each bytes/SHA/Gitblob and concatenatedarchiveSHA/size, then gzip inventorymemberSHA/size. Restore ONLY each declared absent owned alias using its exact original target; preserve Linux0777linkmode, ordinary parents, no foreign path overwrite. Never copy/mutate target. For datedCB2b runtime, also restore26ordinarypayloads using716CB-RUNTIME-RESTORE.json and verify all5631datedbaselinebindings; recreating aliases against current source alone does not recreate the dated2b accepted case.'}}
dump('RESULT.json',result);print(json.dumps({k:v for k,v in result.items()if k!='restore'},indent=2),flush=True)
