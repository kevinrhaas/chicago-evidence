from pathlib import Path
import copy,dataclasses,datetime,hashlib,json,os,stat,subprocess,sys,tarfile

ROOT=Path('/tmp/chicago-green-tree-integration/chicago/4d')
REPO=ROOT.parent.parent
OUT=Path('/workspace/T2376-south-sash-adoption-20261026')
PROP=Path('/workspace/T2376-south-middle-sash-proposal-20261026')
EXPECTED_HEAD='a9c5bd4a9715e4d5634c536d0efcd516ea9c3f01'
TARGET='green_tree_tavern__frame_1833.glb'
def digest(b):return hashlib.sha256(b).hexdigest()
def dump(name,obj):
    p=OUT/name;assert not p.exists(),p
    p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def describe(p):
    b=p.read_bytes();s=p.stat()
    return {'bytes':len(b),'sha256':digest(b),'mode':stat.S_IMODE(s.st_mode),'links':s.st_nlink}
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()

assert subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD']).decode().strip()==EXPECTED_HEAD
prior=json.loads(Path('/workspace/shared/T2376-wagonbay-a9c5-prepared-checkpoint-20261026/STATE.json').read_text())['source']
assert len(prior)==14
for name,expected in prior.items():
    actual=describe(REPO/name)
    assert all(actual[k]==expected[k]for k in ('bytes','sha256','mode')),(name,actual,expected)
dump('ALL14-WAGON-BAY-PREIMAGE.json',prior)
# Preserve every existing authored/generated WIP byte before the small new adoption.
with tarfile.open(OUT/'all14-before.tar.gz','w:gz') as archive:
    for name in sorted(prior):archive.add(REPO/name,arcname=name,recursive=False)

record_path=ROOT/'data/structures/green_tree_tavern.json'
old_bytes=record_path.read_bytes();assert digest(old_bytes)=='7ee5fc41e5c489a21a6044d082c6cd746fce538870020a0fac1067a125c10167'
record=json.loads(old_bytes);patch=json.loads((PROP/'owned-attribute-only.jsonpatch').read_text())
assert record['phases'][0]['form']['side_entrance']==patch[0]['value']
proposed=copy.deepcopy(record);proposed['phases'][0]['form']['side_entrance']=patch[1]['value']
reverted=copy.deepcopy(proposed);reverted['phases'][0]['form']['side_entrance']=patch[0]['value'];assert reverted==record
sys.path.insert(0,str(ROOT/'generators'))
from mesh_inputs import structure_inputs_doc,structure_inputs_sha
from archetypes.frame_tavern_params import from_phase
params_before=from_phase(record['phases'][0],record);params_before.validate()
params_after=from_phase(proposed['phases'][0],proposed);params_after.validate()
pb=dataclasses.asdict(params_before);pa=dataclasses.asdict(params_after)
changed={k:{'before':pb[k],'after':pa[k]}for k in pb if pb[k]!=pa[k]}
assert changed=={'side_entrance_face':{'before':'x_min','after':None}},changed
before_recipe=structure_inputs_doc(record,record['phases'][0]);after_recipe=structure_inputs_doc(proposed,proposed['phases'][0])
old_input=structure_inputs_sha(record,record['phases'][0]);new_input=structure_inputs_sha(proposed,proposed['phases'][0])
assert old_input=='fd6b452a11527dc4d4c5b518e0584bdf97042b71fa461c21324121e83ea35bdb'
assert new_input=='38d1d02c87618a7a6af8b67bef60a97f3c8a72e3bfc3a882802040ea1c04167d'
assert before_recipe['code']==after_recipe['code']
dump('RECIPE-BEFORE.json',before_recipe);dump('RECIPE-AFTER.json',after_recipe)
manifest_path=ROOT/'assets/manifest.json';web_manifest_path=ROOT/'assets/manifest.web.json'
master=json.loads(manifest_path.read_text());web=json.loads(web_manifest_path.read_text())
assert master['assets'][TARGET]['inputs_sha256']==old_input
frame_rows={k:v for k,v in master['assets'].items()if v.get('archetype')=='frame_tavern'}
assert len(frame_rows)==23 and TARGET in frame_rows
asset_guard={}
for name in sorted(frame_rows):
    for tier in ('gltf','web'):
        p=ROOT/'assets'/tier/name
        asset_guard[p.relative_to(ROOT).as_posix()]=describe(p)
assert asset_guard['assets/gltf/'+TARGET]['sha256']=='d2ce4d0ac6bcd66111382dc93504d3b5467287438ceb280a47672898954a0c5d'
assert asset_guard['assets/web/'+TARGET]['sha256']=='e2278182f3d3b7d5ad85e13740c7c3b5fb7b0b014445b29a7139ef8a5f338fd1'
assert web['masters'][TARGET]==asset_guard['assets/gltf/'+TARGET]['sha256']
dump('ALL23-FRAME-TAVERN-ASSET-PREIMAGES.json',asset_guard)
dump('FRAME-TAVERN-REGISTRY-PREIMAGES.json',{'master':frame_rows,'web':{k:web['masters'][k]for k in frame_rows},'whole_master_registry':describe(manifest_path),'whole_web_registry':describe(web_manifest_path)})
for sid in patch[1]['value']['sources']:
    s=json.loads((ROOT/'data/sources'/f'{sid}.json').read_text());assert s['rights_status']=='public_domain' and s['verified']
(OUT/'record-before.json').write_bytes(old_bytes)
new_bytes=(json.dumps(proposed,indent=2,ensure_ascii=False)+'\n').encode()
assert digest(new_bytes)=='7e383f099f5ba26c4fa63295524d5e7855c5d02b6ae4a9ebb9bd00d7e46c140b'

# All guards precede any source mutation. This is the sole form-attribute change.
record_path.write_bytes(new_bytes)
lib=ROOT/'docs/LIBERTIES.md';lib_before=lib.read_bytes()
header=b'### L-green-tree-seven-bays-T-2376'
start=lib_before.index(header);end=lib_before.index(b'\n### ',start+len(header))
field=(PROP/'LIBERTY-AMENDMENT.draft.md').read_text().split('\n\n',1)[1].strip()
addition=('\n'+field+'\n').encode();lib.write_bytes(lib_before[:end]+addition+lib_before[end:])
assert lib.read_bytes().replace(addition,b'',1)==lib_before

dossier=ROOT/'docs/RESEARCH/green_tree_tavern.md';dossier_before=dossier.read_bytes()
appended=('\n\n## T-2376 — the pictured middle south-wall sash (2026-10-26)\n\n'
 '`not_a_reading`: re-reading the already held Andreas reproduction and the original Trowbridge/Gale plate, not a new publication or research unit.\n\n'
 'This amendment supersedes the earlier decision above to retain the central long-side entrance. Both pictures show seven sash stations on each floor of the long elevation, including a visible sash at the fourth lower station. Trowbridge\'s nearest lower sash is partly obscured by the sign and people; no hidden panes are asserted. The existing `side_entrance` form value is now `null`, so the unchanged archetype supplies its normal sash at that station. Only the resolved `side_entrance_face` changes, from `x_min` to no special substitution. The existing seven stations, 0.85 × 1.35 m sash, 0.75 m sill, primary entrance, footprint and geographic placement stay unchanged.\n\n'
 'This inferred picture-priority choice does not prove a side door was absent on 1 July 1835. Gray\'s explicit later recollection of an entrance "on the Lake street front about the middle of the long side" remains substantial counterevidence: his landlord period was 1838–41 and the recollection was published in 1883. No alteration date is known. The original Andreas plate is undated despite the reproduction\'s 1838 label; Trowbridge\'s 1835 title is retrospective. Only the two verified public-domain illustration records govern the new geometry; no check-required photograph or text supplies a new derived asset.\n\n'
 'At this record-adoption checkpoint the committed master still contains the previous doorway. Its honest recipe is therefore stale until a canonical one-target export and WEB derivative are completed. The long-wall difference stays OPEN and its comparison is unreviewed; actual native export, photo review, published desktop/mobile app checks and final whole gates remain owed. The separate enclosed-annex massing remains OPEN. No new ticket or image-match completion is claimed.\n').encode()
dossier.write_bytes(dossier_before+appended)

source=ROOT/'data/sources/trowbridge_green_tree_1902.json';source_before=json.loads(source.read_text());s=copy.deepcopy(source_before)
s['note']+='\n\nT-2376 MIDDLE SASH RE-READING, 2026-10-26: the same held original plate at Gale n55 and its upright reproduction show seven long-elevation sash stations on each floor, including a visible middle lower sash. The nearest lower sash is partly hidden by the hanging sign and people; its hidden panes are not asserted. This picture-led opening rhythm supplies the inferred choice to retain the normal middle sash in the 1835 model. Gray\'s later long-side entrance recollection remains explicit counterevidence in the structure and Liberty notes; the illustration does not prove historical absence of that door on 1 July 1835 or date an alteration. No geographic, metric or additional rights finding is made.'
source.write_text(json.dumps(s,indent=2,ensure_ascii=False)+'\n')

match=ROOT/'data/reference_views/green_tree_tavern/andreas_1838.match.json';m=json.loads(match.read_text());m['verdict']='unreviewed'
matching=[d for d in m['differences']if 'central wide side entrance' in d['what']];assert len(matching)==1
matching[0]['what']='The form record now selects the pictured middle lower sash instead of the central wide side entrance, preserving Gray\'s later doorway recollection as counterevidence. At this checkpoint the retained master is still the old doorway build: the canonical one-target export and actual fixed-camera comparison remain owed. This stays open until the new master and WEB are inspected.'
assert matching[0]['status']=='open'
match.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')

entry={'title':"Green Tree's wagon bay and windows follow the drawings",'kind':'improvement','items':[
 "The Green Tree Tavern's existing open wagon bay and covered wagon move to the front gable along the same north wall, following Trowbridge's retrospective drawing. Its dimensions and exact July-1835 presence remain reconstructed. The vacated space also lets the existing household-fuel rule supply two reconstructed wood ricks and a chopping block.",
 "The south wall follows the pictured seven-window rhythm on both floors: the middle lower doorway gives way to the stock sash. Gray's later account of a side entrance remains explicit counterevidence; neither drawing proves that door was absent in July 1835. The enclosed-annex difference remains under review."
]}
(ROOT/'changelog.d/T-2376.json').write_text(json.dumps(entry,indent=2,ensure_ascii=False)+'\n')
for name in ('STATUS.md','ROADMAP.md'):
    p=ROOT/'docs'/name;before=p.read_bytes()
    text=('\n\n### T-2376: pictured middle sash adopted; native export pending (2026-10-26)\n\n'
      'The existing Green Tree wagon-bay unit now also adopts the already approved `side_entrance: null` form choice: seven stock south-wall sash per floor, replacing the lower middle doorway. The attribute remains inferred, governed only by the two verified public-domain illustrations; Gray\'s later doorway account is retained as counterevidence. Pure parameter validation changes only `side_entrance_face`; the actual new recipe is 38d1d02c87618a7a6af8b67bef60a97f3c8a72e3bfc3a882802040ea1c04167d. All 14 prior wagon-bay WIP files were preserved before adoption, and all 23 frame-tavern master/WEB preimages and producer recipe were guarded.\n\n'
      'No Blender/Draco export, global regeneration, published app test or whole preflight has run for this sash adoption yet. The selected master/WEB remain the old bytes and are honestly stale; all other frame-tavern assets remain exact. Original T-2376 remains OPEN/DIF, including the enclosed-annex mass. Final native/global gates and PR base wait for the checked Carpenter descendant of checked Tremont. No new ticket is filed.\n').encode()
    p.write_bytes(before+text);assert p.read_bytes().startswith(before)

for name,old in asset_guard.items():assert describe(ROOT/name)==old,name
assert describe(manifest_path)==json.loads((OUT/'FRAME-TAVERN-REGISTRY-PREIMAGES.json').read_text())['whole_master_registry']
assert describe(web_manifest_path)==json.loads((OUT/'FRAME-TAVERN-REGISTRY-PREIMAGES.json').read_text())['whole_web_registry']
allowed_changed={
 'chicago/4d/data/reference_views/green_tree_tavern/andreas_1838.match.json',
 'chicago/4d/data/sources/trowbridge_green_tree_1902.json','chicago/4d/docs/LIBERTIES.md',
 'chicago/4d/docs/RESEARCH/green_tree_tavern.md','chicago/4d/docs/STATUS.md','chicago/4d/changelog.d/T-2376.json',
}
for name,old in prior.items():
    if name not in allowed_changed:
        actual=describe(REPO/name);assert all(actual[k]==old[k]for k in ('bytes','sha256','mode')),name
dump('RECORD-ADOPTION.json',{'created':stamp(),'status':'OWNED_ATTRIBUTE_ADOPTED_NO_BAKE_OR_GLOBAL_GATE','HEAD':EXPECTED_HEAD,'record_before_sha256':digest(old_bytes),'record_after_sha256':digest(new_bytes),'only_form_attribute':'phases[0].form.side_entrance','only_resolved_param_change':changed,'before_input_sha256':old_input,'after_input_sha256':new_input,'all23_frame_master_and_WEB_exact':True,'all22_other_frame_assets_protected':True,'registries_exact':True,'all14_prior_WIP_preserved_in_archive':True,'all8_unrelated_prior_WIP_byte_exact':True,'native_export_PASS':False,'original_DONE':False,'requires_CPU_lease_before_export':True,'final_global_base':'ROOT checked Carpenter descendant of checked Tremont1290'})
print((OUT/'RECORD-ADOPTION.json').read_text(),flush=True)
