# Green Tree: wagon bay plus middle sash

The current20-source archive reconstructs the complete owned working state on public basea9c5, including the untracked changelog entry, actual new master/WEB and both registries. The tracked patch is supplemental. The all14-before archive preserves every pre-adoption wagon-bay WIP file.

The canonical selected export passed. Exact recipe38d1d02c87618a7a6af8b67bef60a97f3c8a72e3bfc3a882802040ea1c04167d; all other2,067 physicalGLBs and22other frame-tavern rows remain exact. Independent actual triangle comparison confines56 changedtriangles to the central south opening, with2,522 unchanged. Failed harness attempts are preserved separately and stopped before asset writes; they are not native passes.

No global native derivation, whole preflight, new-master photo or published-app pass is claimed. No codecommit/PR yet, and originalT2376 remainsOPEN/DIF. Final integration base must be ROOT checkedCarpenter, a descendant of checkedTremont1290. Preserve all upstream work; reuse this genuine export only after recomputing exactly the same recipe at that base. Do not copy the old whole smoke file.
