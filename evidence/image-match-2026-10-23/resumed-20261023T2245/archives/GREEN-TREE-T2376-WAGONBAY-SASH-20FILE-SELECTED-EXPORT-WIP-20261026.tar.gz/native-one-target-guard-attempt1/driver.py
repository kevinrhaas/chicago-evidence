"""Prepared only. Run after a CPU window is assigned; never run global native here."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,stat,struct,subprocess,sys,tempfile

ap=argparse.ArgumentParser()
ap.add_argument('--cpu',type=int,required=True,help='One CPU explicitly assigned for this target export')
args=ap.parse_args()
assert args.cpu in os.sched_getaffinity(0)
os.sched_setaffinity(0,{args.cpu})
ROOT=Path('/tmp/chicago-green-tree-integration/chicago/4d')
HOLDER=Path('/workspace/T2376-south-sash-adoption-20261026')
OUT=HOLDER/'native-one-target'
assert not OUT.exists(),'Never overwrite a native attempt'
OUT.mkdir()
TARGET='green_tree_tavern__frame_1833.glb'
BLENDER='/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender'
NEW_INPUT='38d1d02c87618a7a6af8b67bef60a97f3c8a72e3bfc3a882802040ea1c04167d'
def save(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def inventory(path):
    b=path.read_bytes();s=path.stat()
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':stat.S_IMODE(s.st_mode),'links':s.st_nlink}
def run(label,cmd):
    with (OUT/(label+'.log')).open('x') as log:
        p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    assert p.returncode==0,(label,p.returncode)
def json_glb(path):
    b=path.read_bytes();assert b[:4]==b'glTF' and struct.unpack_from('<I',b,4)[0]==2
    n,kind=struct.unpack_from('<II',b,12);assert kind==0x4e4f534a
    return json.loads(b[20:20+n])
def glb_geometry(path):
    j=json_glb(path);n=0;bounds=[]
    for mesh in j.get('meshes',[]):
        for p in mesh['primitives']:
            a=j['accessors'][p['attributes']['POSITION']]
            bounds.append({'min':a.get('min'),'max':a.get('max')})
            count=j['accessors'][p['indices']]['count'] if 'indices'in p else a['count']
            if p.get('mode',4)==4:n+=count//3
    return {'triangles':n,'position_bounds':bounds,'nodes':[x.get('name')for x in j.get('nodes',[])],'materials':[x.get('name')for x in j.get('materials',[])]}

record=json.loads((ROOT/'data/structures/green_tree_tavern.json').read_text())
assert record['phases'][0]['form']['side_entrance']['value'] is None
sys.path.insert(0,str(ROOT/'generators'))
from mesh_inputs import structure_inputs_sha,structure_inputs_doc
assert structure_inputs_sha(record,record['phases'][0])==NEW_INPUT
assert structure_inputs_doc(record,record['phases'][0])==json.loads((HOLDER/'RECIPE-AFTER.json').read_text())
save('ACTUAL-RECIPE.json',structure_inputs_doc(record,record['phases'][0]))
old_frames=json.loads((HOLDER/'ALL23-FRAME-TAVERN-ASSET-PREIMAGES.json').read_text())
for rel,expected in old_frames.items():
    actual=inventory(ROOT/rel)
    assert all(actual[k]==expected[k]for k in ('bytes','sha256','mode')),rel
all_before={p.relative_to(ROOT).as_posix():inventory(p)for tier in ('gltf','web')for p in sorted((ROOT/'assets'/tier).rglob('*.glb'))}
save('ALL-PHYSICAL-ASSETS-BEFORE.json',all_before)
master_path=ROOT/'assets/manifest.json';web_path=ROOT/'assets/manifest.web.json'
master_before=json.loads(master_path.read_text());web_before=json.loads(web_path.read_text())
save('MASTER-REGISTRY-BEFORE.json',master_before);save('WEB-REGISTRY-BEFORE.json',web_before)
before_geometry=glb_geometry(ROOT/'assets/gltf'/TARGET);save('GEOMETRY-BEFORE.json',before_geometry)
for tier in ('gltf','web'):
    p=ROOT/'assets'/tier/TARGET;shutil.copy2(p,OUT/('before-'+tier+'.glb'))
    # Canonical writers may truncate their target. Break only this selected inode.
    if p.stat().st_nlink>1:
        fd,temp=tempfile.mkstemp(dir=p.parent,prefix='.t2376-target-')
        os.close(fd);shutil.copy2(p,temp);os.replace(temp,p)
    assert inventory(p)['sha256']==all_before[p.relative_to(ROOT).as_posix()]['sha256']
    assert p.stat().st_nlink==1
versions={}
for pkg in ('cli','core','extensions','functions'):
    version=json.loads((Path('/workspace/shared/gltf-transform/node_modules/@gltf-transform')/pkg/'package.json').read_text())['version']
    assert version=='4.5.0';versions[pkg]=version
save('TOOLCHAIN-VERSIONS.json',versions)
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
run('blender-version',[BLENDER,'--version'])
assert 'Blender 4.5.3'in(OUT/'blender-version.log').read_text()
commands=[
 [BLENDER,'-b','-noaudio','--factory-startup','--threads','1','--python','generators/build.py','--','--only','green_tree_tavern','--scene','1835','--wrote',str(OUT/'masters-wrote.txt')],
 ['bash','tools/web_derivatives.sh','--only',TARGET],
]
save('CANONICAL-COMMANDS.json',commands)
run('native-master',commands[0])
wrote=(OUT/'masters-wrote.txt').read_text().splitlines();assert len(wrote)==1 and Path(wrote[0]).name==TARGET,wrote
run('native-WEB',commands[1])
all_after={p.relative_to(ROOT).as_posix():inventory(p)for tier in ('gltf','web')for p in sorted((ROOT/'assets'/tier).rglob('*.glb'))}
save('ALL-PHYSICAL-ASSETS-AFTER.json',all_after)
assert set(all_before)==set(all_after)
allowed={'assets/gltf/'+TARGET,'assets/web/'+TARGET}
changed={p for p in all_before if any(all_before[p][k]!=all_after[p][k]for k in ('bytes','sha256','mode'))}
assert changed==allowed,changed
master_after=json.loads(master_path.read_text());web_after=json.loads(web_path.read_text())
assert set(master_after['assets'])==set(master_before['assets'])
assert {k for k in master_before['assets']if master_before['assets'][k]!=master_after['assets'][k]}=={TARGET}
assert set(web_before['masters'])==set(web_after['masters'])
assert {k for k in web_before['masters']if web_before['masters'][k]!=web_after['masters'][k]}=={TARGET}
assert master_after['assets'][TARGET]['inputs_sha256']==NEW_INPUT
assert web_after['masters'][TARGET]==all_after['assets/gltf/'+TARGET]['sha256']
save('GEOMETRY-AFTER.json',glb_geometry(ROOT/'assets/gltf'/TARGET))
save('SELECTED-TARGET-ONLY-PROOF.json',{
 'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'CANONICAL_ONE_TARGET_MASTER_AND_WEB_PASS_NO_GLOBAL_GATE',
 'cpu':args.cpu,'recipe':NEW_INPUT,'physical_asset_count':len(all_before),
 'changed_physical_paths':sorted(changed),'all_other_physical_assets_exact':True,
 'all22_other_frame_tavern_master_WEB_and_registry_rows_exact':True,
 'master':all_after['assets/gltf/'+TARGET],'WEB':all_after['assets/web/'+TARGET],
 'whole_preflight_or_app_or_photo_PASS':False,'original_DONE':False,
 'next':'Actual fixed-camera review, source-based native/global closure and finalPR base remain owed on checked Carpenter. Reuse export there only if exact actual recipe remains unchanged.'
})
print((OUT/'SELECTED-TARGET-ONLY-PROOF.json').read_text(),flush=True)
