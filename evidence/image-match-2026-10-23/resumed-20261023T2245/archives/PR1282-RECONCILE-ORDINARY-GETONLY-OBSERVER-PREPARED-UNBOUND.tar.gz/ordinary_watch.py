"""GET-only ordinary CI and commit-tree observer; start only on root's public SHA."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, re, subprocess, time

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--head', required=True)
ap.add_argument('--tree', required=True)
ap.add_argument('--pr', type=int, default=1282)
ap.add_argument('--parents', nargs='+', required=True)
ap.add_argument('--out', required=True)
a = ap.parse_args()
assert all(re.fullmatch('[0-9a-f]{40}', x) for x in [a.head, a.tree, *a.parents])
p = Path(a.out)
assert p.is_absolute() and str(p).startswith('/tmp/')
p.mkdir(exist_ok=False)
(p/'OBSERVER_LOCK.json').write_text(json.dumps({'pid':os.getpid(), 'head':a.head, 'scope':'GET only'})+'\n')

def now(): return datetime.datetime.now(datetime.timezone.utc)
def save(name, value):
    (p/name).write_text(json.dumps(value, indent=2)+'\n')
def get(endpoint):
    q = subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/'+endpoint], capture_output=True, timeout=60)
    if q.returncode: raise RuntimeError(endpoint+': '+q.stderr.decode('utf8','replace'))
    return q.stdout
def getjson(endpoint): return json.loads(get(endpoint))
def commit(sha):
    path = p/('commit-'+sha+'.json')
    if not path.exists(): path.write_bytes(get('git/commits/'+sha))
    return json.loads(path.read_text())
def heartbeat(value):
    tmp = p/'WATCHER_STATE.tmp'
    tmp.write_text(json.dumps({'pid':os.getpid(), 'heartbeat':now().isoformat(), **value},indent=2)+'\n')
    tmp.replace(p/'WATCHER_STATE.json')

last_signature = None
while True:
    started = now()
    result = {'at':started.isoformat(), 'PR':a.pr, 'head':a.head, 'expected_tree':a.tree, 'expected_parents':a.parents, 'scope':'ordinary CI only; prior308b full18 remains separate'}
    heartbeat({'phase':'POLL_RUNNING', 'head':a.head})
    try:
        source = commit(a.head)
        result['source_tree_matches'] = source['tree']['sha'] == a.tree
        result['source_parents_match'] = [x['sha'] for x in source['parents']] == a.parents
        assert result['source_tree_matches'] and result['source_parents_match'], 'Source tree/parents differ from root binding'
        pr = getjson('pulls/'+str(a.pr))
        result['PR'] = {k:pr.get(k) for k in ['number','state','merged','draft','mergeable','mergeable_state','merge_commit_sha']}
        result['current_PR_head'] = pr['head']['sha']
        result['head_is_current'] = pr['head']['sha'] == a.head
        result['PR_base'] = pr['base']['sha']
        result['dev'] = getjson('git/ref/heads/dev')['object']['sha']
        checks = getjson('commits/'+a.head+'/check-runs?per_page=100')
        save('check-runs-'+started.strftime('%Y%m%dT%H%M%SZ')+'.json', checks)
        result['checks'] = [{k:r.get(k) for k in ['id','name','head_sha','status','conclusion','started_at','completed_at','details_url']} for r in checks['check_runs']]
        result['missing_expected_checks'] = sorted({'gate','report'}-{r['name'] for r in result['checks']})
        result['moving_check_present'] = any(r['name']=='moving-frames' for r in result['checks'])
        result['actual_ordinary_logs'] = []
        for check in checks['check_runs']:
            assert check['head_sha'] == a.head
            if check['name'] not in {'gate','moving-frames','report'} or check['status'] != 'completed': continue
            match = re.search(r'/actions/runs/(\d+)/job/(\d+)', check['details_url'] or '')
            if not match:
                result.setdefault('log_errors', []).append({'check':check['id'], 'error':'No run/job URL binding'})
                continue
            run, job = map(int, match.groups())
            logpath = p/f'run{run}-job{job}.log'
            if not logpath.exists():
                save(f'run{run}.json', getjson(f'actions/runs/{run}'))
                save(f'run{run}-jobs.json', getjson(f'actions/runs/{run}/jobs'))
                logpath.write_bytes(get(f'actions/jobs/{job}/logs'))
            raw = logpath.read_bytes()
            text = raw.decode('utf8','replace')
            clean = re.sub(r'\x1b\[[0-9;]*m', '', text)
            actual = re.findall(r'^\S+ ([0-9a-f]{40})\s*$', text, re.M)
            row = {'check':check['name'], 'check_id':check['id'], 'run':run, 'job':job, 'conclusion':check['conclusion'], 'raw_path':str(logpath), 'sha256':hashlib.sha256(raw).hexdigest()}
            if actual:
                c = commit(actual[0])
                row.update(actual_checkout=actual[0], actual_tree=c['tree']['sha'], actual_parents=[x['sha'] for x in c['parents']], whole_tree_equals_source=c['tree']['sha']==source['tree']['sha'])
            elif check['name'] in {'gate','moving-frames'}:
                result.setdefault('log_errors', []).append({'check':check['id'], 'error':'No actual checkout in raw log'})
            if check['name'] == 'gate':
                steps = re.search(r'CHECK PASS.*?(\d+) steps, none red', clean)
                tests = re.search(r'\n\S+\s+(\d+) of them are self-tests', clean)
                row.update(actual_CHECK_PASS=bool(steps), actual_steps=int(steps[1]) if steps else None, actual_selftests=int(tests[1]) if tests else None)
            if check['name'] == 'moving-frames':
                m = re.search(r'PASS upload release: (\d+) checks', clean)
                row['actual_upload_release_checks'] = int(m[1]) if m else None
            result['actual_ordinary_logs'].append(row)
        result['all_present_checks_success'] = bool(result['checks']) and all(r['status']=='completed' and r['conclusion']=='success' for r in result['checks'])
        native = [r for r in result['actual_ordinary_logs'] if r['check'] in {'gate','moving-frames'}]
        result['actual_native_verdicts_verified'] = any(r['check']=='gate' and r.get('actual_CHECK_PASS') and r.get('actual_steps')==1065 and r.get('actual_selftests')==384 for r in native) and all(r.get('whole_tree_equals_source') and (r['check']!='moving-frames' or r.get('actual_upload_release_checks')==32) for r in native)
        signature = tuple(sorted((r['id'],r['conclusion']) for r in result['checks']))
        complete = result['all_present_checks_success'] and result['actual_native_verdicts_verified'] and result['head_is_current'] and not result['missing_expected_checks'] and not result.get('log_errors') and signature == last_signature
        result['phase'] = 'COMPLETE_STABLE_ORDINARY_CI' if complete else 'WAITING'
        last_signature = signature if result['all_present_checks_success'] else None
    except Exception as e:
        result.update(phase='READ_ERROR_NOT_CI_VERDICT', read_error=str(e))
        complete = False
        last_signature = None
    stamp = started.strftime('%Y%m%dT%H%M%SZ')
    save('snapshot-'+stamp+'.json', result)
    with (p/'EVENTS.jsonl').open('a') as f: f.write(json.dumps(result)+'\n')
    heartbeat(result)
    print(json.dumps(result), flush=True)
    if complete: break
    due = started + datetime.timedelta(seconds=300)
    while now() < due:
        heartbeat({**result, 'next_poll':due.isoformat()})
        time.sleep(min(45,max(0,(due-now()).total_seconds())))
