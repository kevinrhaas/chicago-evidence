# T-2372: guarded current school source preparation

This packet prepares the already accepted school form without modifying primary files. The current record still has the old broad front; a new canonical camera and library stream are absent. The only shared overlaps are the grade rulings, image STORE and Liberty document. Their postimages preserve all current GT/foreign values, ordering and metadata. The2641B reviewed Liberty suffix is stored separately instead of duplicating the current3.4MB whole document. All20 accepted structural leaf changes remain exact.

## Attribution and original picture coverage

Original T2372 lists one artwork, `eliza_chappel_school_shore_view`. The current source catalogue already records the owner-supplied [Illinois History Journal page](https://drloihjournal.blogspot.com/2018/01/eliza-chappell-the-first-chicago-teacher-paid-by-public-funds-in-1833.html), the unidentified artist, and the owner's explicit attributed project-reference approval. Its `rights_status` is `cleared` for that project scope; its rights note explicitly does **not** establish original publication, verified public domain or general redistribution permission. This source file is preserved byte-exact by the packet. Do not reopen the answered credit question or reclassify the drawing as a surveyed1833/1835 photograph.

The held640×368 shore image and the hosted full/thumbnail pair are the same reproduction, not three independent pictures. Hosting was already completed in chicago-images PR10. The proposed stream retains that attribution and those historical/rights limits; neither a new rights claim nor new hosting is needed. The William Mark Young1844 Rumsey plate was already examined and excluded from this subject; do not restart that source search.

The local diagnostic camera is unchanged numerically from the accepted external fit. School/annex identity remains conditional, the shore drawing has inconsistent perspective, and the pictured lighthouse/people are not metric controls. The new not_pictured ruling preserves the inferred structure grade despite the deliberately adopted form reference. Do not attach this drawing as a fifth Sauganash-annex view.

## Geometry and canonical ownership

The accepted body is4.572×8.778m,41° pitch,2.30m recess, door station2.47m and window stations0.95/3.73m, retaining0.85m lights and the2.50m eave. The approximately0.26m apex residual is withinT3153. Footprint, hidden depth, alignment and numeric camera remain reconstructed choices.

Actual current full native input SHA is `2fe83632046f2462e58524944e13e970ace9824693f5141f3769c1b726537f44`. All six geometry-code modules, the log parameter reader and the recorded Blender pin equal the actual accepted18:17 prototype; resolving its original trial record and the final prose-updated source record gives identical input documents. The generic warning that Miller later changed this producer is stale for this particular frozen prototype. These exact checks are recorded in current-packet/PLAN.json and CURRENT-CANDIDATE-RECIPE-DOC.json.

Nevertheless, the accepted trial used direct emit, without a canonical build/manifest ownership receipt. After guarded adoption, run the official cheap single-record command from chicago/4d:

```bash
bash tools/bake.sh --only chappel_infant_school
```

No producer changes or family bake are proposed. The previous actual emit was0.136s; its accepted MASTER wasfb141fef… (49,864B/524triangles), WEBf120aa9a… (18,612B). Do not type a recipe or copy an old whole registry. Require all foreign model/manifest entries to remain exact through the official owner.

## Prepare or validate safely

The existing current-packet is bound to the GT-authored state observed00:24 on nativedd1. Once other originals or dev changes land, prepare a **new** packet with the same script; it preserves their current shared tables automatically and refuses third values for the school-owned keys:

```bash
python3 prepare_current.py --output /workspace/T2372-currentGT-guarded-source-prep-20261030/rebound-UNIQUE
python3 apply_plan.py --packet /workspace/T2372-currentGT-guarded-source-prep-20261030/rebound-UNIQUE --expected-head ACTUAL_HEAD
```

Both commands above only prepare external files/read primary. The actual dated six-path validation passed; native canonical production/capture/app/gates remain unrun. A future application additionally requires the native original claim, sole primary lease, clean `steward/t2372-*` branch, explicit expected head, exact source/catalogue/input guards, unchanged resource floors and `SCHOOL_ADOPTION_LEASE=original-T2372-claimed-primary-released`. Only the primary writer may then add `--apply`. The helper applies six source files atomically with a journal; it never stages, claims, commits or updates refs. No apply ran during this preparation.

## Actual remaining geometry/ground work

Current native footprint-placement arithmetic preserves the front E816.406m exactly and the doorway within1mm after sidecar rounding. The rear moves3.292m west; the north/south envelope also narrows. The nearest current building envelope is26.36m away; the same platted lot also names `south_bank_shed_dearborn_e2`,34.825m from the candidate footprint. These are **RAM sidecar-envelope checks**, not actual model grounding, props or walking proofs. PLACEMENT-READINESS.json records the complete current coordinates and limits.

The five current school-linked generated records are entrance aprons, lot-line rails, alley lanes, yard paths and kept ground. Native owners include149entrances,163lot-line fences and183kept ground/yard paths. Compile scene after adoption, then rebuild those records and the official image library, retaining every foreign record. A normal settled tail from Libcompiler144 covers the listed manifest owners and source/grade/picture readers.

**One additional explicit owner is essential:** `tools/generate_alley_lanes.py` is checked directly by check.sh but absent from the204-step derived manifest. The native RAM `blocked_spans` calculation shows the old school cut−2.65..3.85m disappears with the narrowed front. Run this official owner after current scene regeneration:

```bash
python3 tools/generate_alley_lanes.py
python3 tools/generate_alley_lanes.py --check
```

A61-step tail alone would miss that real6.5m alley-mouth change. ALLEY-OWNER-READINESS.json records the actual old/candidate native calculation, without claiming the owner has run. Recheck it after any later current-code change. Check the new rear against rails, ground patches, pathways and any remaining props; never hand-delete them to make a screenshot clear. Preserve the school's former-use/date qualifications.

Finish actual metadata-bound `photo_match.mjs` on the adopted canonical camera/MASTER and directly review the new side-by-side. Recompute the match record against those actual hashes; do not copy the external MATCHES verdict as a new capture. Then publish and check Full390×780/1280×800 Normal/ByGrade, credited full Images/Sources/Research, terrain contact, rear envelope and a real street-to-door approach with no clipping/errors. Run the native relevant published smoke, phone budget, complete foreground source/preflight gate, normal dev PR/currentCI/merge and official ticket settlement. No new photo follow-up tickets or geometry tuning loop is called for by this preparation.
