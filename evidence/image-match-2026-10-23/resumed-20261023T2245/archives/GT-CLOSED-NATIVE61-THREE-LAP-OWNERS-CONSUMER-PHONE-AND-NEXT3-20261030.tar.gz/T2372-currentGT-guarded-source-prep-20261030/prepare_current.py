"""Rebind the accepted School source-only proposal without writing the checkout.

The three direct payloads remain exact reviewed donors. Shared tables are merged
entrywise, and the Liberty fragment is appended to current bytes, never restored
from the old whole document. A new output directory is required for each plan.
"""
from pathlib import Path
import argparse
import copy
import datetime
import hashlib
import json
import os
import stat
import subprocess
import sys

sys.dont_write_bytecode = True
REPO = Path('/workspace/chicago')
APP = REPO / 'chicago/4d'
OLD = Path('/workspace/T2372-reprepared-BE501-school-agent-v3-20261029/bundle-v2')
TRIAL = Path('/workspace/T2372-native-fit-trial-20261029')
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
SHA = lambda b: hashlib.sha256(b).hexdigest()
ENC = lambda x, indent=2: (json.dumps(x, indent=indent, ensure_ascii=False) + '\n').encode()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env=ENV)


def state():
    return {'HEAD': git('rev-parse', 'HEAD').decode().strip(),
            'branch': git('branch', '--show-current').decode().strip(),
            'index_sha256': SHA((REPO / '.git/index').read_bytes()),
            'config_sha256': SHA((REPO / '.git/config').read_bytes()),
            'refs_sha256': SHA(git('show-ref'))}


def bound(path):
    if not path.exists():
        return None
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': SHA(data), 'mode': oct(stat.S_IMODE(path.stat().st_mode))}


def key(row):
    return (row.get('scene'), row.get('structure'), row.get('picture'))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    out = args.output.resolve()
    assert out.parent == Path(__file__).resolve().parent and not out.exists()
    before = state()
    old_plan = json.loads((OLD / 'PLAN.json').read_text())
    old_rows = {row['path']: row for row in old_plan['source_changes']}
    original = {rel: bound(REPO / rel) for rel in old_rows}
    payloads = []
    proofs = {}
    direct = ['chicago/4d/data/structures/chappel_infant_school.json',
              'chicago/4d/data/reference_views/chappel_infant_school/shore-drawing.json',
              'chicago/prairie_1904_v1/research/images/stream-eliza-chappel-school-reference.json']
    for rel in direct:
        row = old_rows[rel]
        actual = original[rel]
        assert (None if actual is None else {k: actual[k] for k in ['bytes', 'sha256']}) == row['before'], rel
        donor = OLD / 'postimages' / rel
        data = donor.read_bytes()
        assert {'bytes': len(data), 'sha256': SHA(data)} == row['after']
        mode = original[rel]['mode'] if original[rel] else '0o644'
        payloads.append((rel, data, mode, 'exact_reviewed_direct_donor', donor))

    # One qualified non-identification ruling, preserving every current foreign row.
    rel = 'chicago/4d/data/structure_grades.json'
    current = json.loads((REPO / rel).read_text())
    old_own = json.loads((OLD / 'postimages' / rel).read_text())
    own = [r for r in old_own['not_pictured'] if r.get('structure') == 'chappel_infant_school']
    assert len(own) == 1
    target_key = key(own[0])
    assert not [r for r in current['pictured'] if key(r) == target_key]
    existing = [r for r in current['not_pictured'] if key(r) == target_key]
    assert not existing or existing == own, 'Conflicting school ruling requires review'
    merged = copy.deepcopy(current)
    if not existing:
        merged['not_pictured'].append(copy.deepcopy(own[0]))
    assert current['pictured'] == merged['pictured']
    assert [r for r in current['not_pictured'] if key(r) != target_key] == [
        r for r in merged['not_pictured'] if key(r) != target_key]
    for k in current:
        if k not in ['pictured', 'not_pictured']:
            assert merged[k] == current[k]
    payloads.append((rel, ENC(merged), original[rel]['mode'], 'entrywise_school_nonidentification_ruling', None))
    proofs['grades'] = {'target_key': list(target_key), 'foreign_lists_and_metadata_exact': True,
                        'existing_target_already_equal': bool(existing)}

    # Exactly two hosted, attributed image files. All existing GT/foreign files survive.
    rel = 'chicago/prairie_1904_v1/research/images/STORE.json'
    current = json.loads((REPO / rel).read_text())
    old_own = json.loads((OLD / 'postimages' / rel).read_text())
    names = ['early-eliza-chappel-school-shore-reference.jpg',
             'early-eliza-chappel-school-shore-reference-thumb.jpg']
    merged = copy.deepcopy(current)
    for name in names:
        own_row = old_own['files'][name]
        assert name not in merged['files'] or merged['files'][name] == own_row, name
        merged['files'][name] = copy.deepcopy(own_row)
    assert [(k, v) for k, v in current['files'].items() if k not in names] == [
        (k, v) for k, v in merged['files'].items() if k not in names]
    for k in current:
        if k not in ['files', 'bytes']:
            assert merged[k] == current[k]
    merged['bytes'] = sum(v['bytes'] for v in merged['files'].values())
    payloads.append((rel, ENC(merged, 1), original[rel]['mode'], 'entrywise_two_hosted_image_files', None))
    proofs['STORE'] = {'foreign_existing_rows_exact': len(current['files']), 'owned_names': names,
                       'result_rows': len(merged['files']), 'metadata_preserved_except_total_bytes': True}

    # Append the exact reviewed fragment only. Do not copy the historical wholeLib.
    rel = 'chicago/4d/docs/LIBERTIES.md'
    old_row = old_rows[rel]
    old_own = (OLD / 'postimages' / rel).read_bytes()
    assert len(old_own) == old_row['after']['bytes'] and SHA(old_own) == old_row['after']['sha256']
    fragment = old_own[old_row['before']['bytes']:]
    heading = b'### L-T2372-narrow-school-front '
    assert fragment.count(heading) == 1
    current = (REPO / rel).read_bytes()
    assert heading not in current, 'School Liberty already exists; inspect existing work'
    combined = current + fragment
    assert combined[:len(current)] == current
    payloads.append((rel, combined, original[rel]['mode'], 'append_exact_reviewed_school_fragment', None))
    proofs['Liberty'] = {'id': 'L-T2372-narrow-school-front', 'fragment_bytes': len(fragment),
                          'fragment_sha256': SHA(fragment), 'all_current_bytes_preserved': True,
                          'current_sha256': SHA(current), 'combined_sha256': SHA(combined),
                          'current_entries': current.count(b'\n### L-'),
                          'result_entries': combined.count(b'\n### L-')}

    # Read-only native full recipe and actual frozen-code/pin parity.
    sys.path.insert(0, str(APP / 'generators'))
    import mesh_inputs
    candidate = json.loads(next(data for rel, data, _, _, _ in payloads if rel.endswith('structures/chappel_infant_school.json')))
    old_candidate = json.loads((TRIAL / 'PROPOSED-STRUCTURE.json').read_text())
    current_doc = mesh_inputs.structure_inputs_doc(candidate, candidate['phases'][0])
    old_doc_on_current = mesh_inputs.structure_inputs_doc(old_candidate, old_candidate['phases'][0])
    assert current_doc == old_doc_on_current
    trial_inputs = json.loads((TRIAL / 'INPUTS.json').read_text())
    assert current_doc['blender_pin'] == trial_inputs['native_pin'].strip()
    code_parity = []
    for name, digest in current_doc['code'].items():
        frozen = TRIAL / 'frozen/generators' / name
        assert SHA(frozen.read_bytes()) == digest
        recorded = [r for r in trial_inputs['source_bindings'] if r['frozen'] == str(frozen)]
        assert len(recorded) == 1 and recorded[0]['sha256'] == digest
        code_parity.append({'module': name, 'sha256': digest, 'frozen_trial_binding_exact': True})
    assert len(code_parity) == 6
    reader = 'generators/archetypes/log_dwelling_params.py'
    assert (APP / reader).read_bytes() == (TRIAL / 'frozen' / reader).read_bytes()
    proofs['native_geometry'] = {'candidate_full_recipe_sha256': SHA(json.dumps(current_doc, sort_keys=True).encode()),
        'same_resolved_doc_as_actual_old_trial_record': True, 'all_six_code_inputs_exact': code_parity,
        'parameter_reader_exact': True, 'recorded_pin_text_exact': True,
        'canonical_bake_required': True,
        'reason': 'Actual accepted trial was direct emit, with no canonical build/manifest ownership receipt. Run official single-record bake; no producer or family bake change is proposed.'}

    # Source attribution and historical limits stay exactly as currently recorded.
    source = APP / 'data/sources/eliza_chappel_school_shore_view.json'
    src = json.loads(source.read_text())
    assert src['rights_status'] == 'cleared'
    assert 'owner' in src['rights_note'] and 'does not establish' in src['rights_note']
    proofs['source'] = {'path': str(source.relative_to(REPO)), 'sha256': SHA(source.read_bytes()),
        'rights_status': src['rights_status'], 'rights_note': src['rights_note'], 'url': src['url'],
        'source_catalogue_is_unchanged': True,
        'scope': 'Owner-approved attributed project reference/display, not verified PD/original publication/subject/date.'}
    assert all(bound(REPO / rel) == original[rel] for rel in old_rows)
    assert state() == before, 'Primary Git state changed during read-only preparation'

    out.mkdir()
    rows = []
    for rel, data, mode, action, donor in payloads:
        row = {'path': rel, 'before': original[rel],
               'after': {'bytes': len(data), 'sha256': SHA(data), 'mode': mode}, 'action': action}
        if rel.endswith('docs/LIBERTIES.md'):
            dest = out / 'fragments/LIBERTY-APPEND.md'
            dest.parent.mkdir(parents=True)
            dest.write_bytes(fragment)
            row['fragment'] = str(dest)
            row['fragment_sha256'] = SHA(fragment)
        else:
            dest = out / 'postimages' / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            row['postimage'] = str(dest)
        if donor:
            row['accepted_donor'] = str(donor)
        rows.append(row)
    (out / 'CURRENT-CANDIDATE-RECIPE-DOC.json').write_bytes(ENC(current_doc))
    plan = {'status': 'READ_ONLY_CURRENT_SCHOOL_SIX_SOURCE_PATHS_PREPARED_NOT_APPLIED',
            'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'primary_before_after': before,
            'source_paths': rows, 'proofs': proofs,
            'old20_structural_leaf_changes_preserved': len(old_plan['leaf_changes']) == 20,
            'large_Liberty_postimage_not_duplicated': True,
            'pending': ['native claim/current clean school branch', 'official single-record bake',
                        'owning regeneration/library build/publish', 'fresh metadata-bound native picture and reviewed match',
                        'actual grounding/rear-envelope/neighbour/props/exterior access',
                        'published Full BOTH app/appropriate native smoke/phone/full check', 'PR/current CI/dev merge/official DONE']}
    assert len(rows) == 6 and plan['old20_structural_leaf_changes_preserved']
    (out / 'PLAN.json').write_bytes(ENC(plan))
    print(json.dumps({'status': plan['status'], 'paths': len(rows),
                      'aggregate_overlaps': ['grades', 'STORE', 'Liberty'],
                      'full_recipe_sha256': proofs['native_geometry']['candidate_full_recipe_sha256'],
                      'no_primary_writes': True}, indent=2))


if __name__ == '__main__':
    main()
