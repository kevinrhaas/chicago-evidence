"""Default read-only validation; source application requires a fresh explicit lease.

Use prepare_current.py to rebind aggregate tables after unrelated work lands.
This script never stages, commits, updates refs, claims a ticket or runs an owner.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
REPO = Path('/workspace/chicago')
HOME = Path(__file__).resolve().parent
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
SHA = lambda b: hashlib.sha256(b).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env=ENV)


def state():
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'branch': git('branch', '--show-current').decode().strip(),
            'index_sha256': SHA((REPO / '.git/index').read_bytes()),
            'config_sha256': SHA((REPO / '.git/config').read_bytes()),
            'refs_sha256': SHA(git('show-ref'))}


def bind(path):
    if not path.exists():
        return None
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': SHA(raw), 'mode': oct(stat.S_IMODE(path.stat().st_mode))}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--packet', type=Path, default=HOME / 'current-packet')
    p.add_argument('--expected-head', required=True)
    p.add_argument('--report', type=Path)
    p.add_argument('--apply', action='store_true')
    args = p.parse_args()
    packet = args.packet.resolve()
    assert packet.is_relative_to(HOME)
    plan = json.loads((packet / 'PLAN.json').read_text())
    before = state()
    assert before['head'] == args.expected_head
    source = REPO / plan['proofs']['source']['path']
    assert SHA(source.read_bytes()) == plan['proofs']['source']['sha256']
    prepared = []
    for row in plan['source_paths']:
        rel = Path(row['path'])
        assert not rel.is_absolute() and '..' not in rel.parts
        dest = REPO / rel
        for path in [dest, *dest.parents]:
            if path == REPO.parent:
                break
            assert not path.is_symlink(), path
        assert bind(dest) == row['before'], ('Current source changed; rerun prepare_current.py', row['path'])
        if 'fragment' in row:
            fragment_path = Path(row['fragment'])
            assert fragment_path.resolve().is_relative_to(packet)
            fragment = fragment_path.read_bytes()
            assert SHA(fragment) == row['fragment_sha256']
            raw = dest.read_bytes() + fragment
        else:
            donor = Path(row['postimage'])
            assert donor.resolve().is_relative_to(packet)
            raw = donor.read_bytes()
        assert len(raw) == row['after']['bytes'] and SHA(raw) == row['after']['sha256']
        prepared.append((dest, raw, int(row['after']['mode'], 8), row))
    assert len(prepared) == 6
    sys.path.insert(0, str(REPO / 'chicago/4d/generators'))
    import mesh_inputs
    record = json.loads(next(raw for dest, raw, _, _ in prepared if dest.name == 'chappel_infant_school.json'))
    doc = mesh_inputs.structure_inputs_doc(record, record['phases'][0])
    # Native recipe hashing serializes tuples as JSON arrays. Compare that same
    # representation, rather than Python tuple/list container classes.
    recorded_doc = json.loads((packet / 'CURRENT-CANDIDATE-RECIPE-DOC.json').read_text())
    assert json.dumps(doc, sort_keys=True) == json.dumps(recorded_doc, sort_keys=True)
    assert state() == before, 'Primary Git state changed during validation'
    result = {'status': 'READ_ONLY_SCHOOL_SIX_PATHS_CURRENT_PREIMAGES_AND_NATIVE_INPUTS_PASS',
              'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'apply_requested': args.apply,
              'head': before['head'], 'paths': len(prepared),
              'no_native_production_capture_grade_app_gate_PR_or_DONE_claim': True}
    if args.apply:
        assert os.environ.get('SCHOOL_ADOPTION_LEASE') == 'original-T2372-claimed-primary-released'
        assert before['branch'].startswith('steward/t2372-')
        assert not git('status', '--porcelain=v1', '--untracked-files=all'), 'Application requires a clean current school branch'
        needed = sum(((len(raw) + 4095) // 4096) * 4096 for _, raw, _, _ in prepared)
        assert shutil.disk_usage('/workspace').free >= 536870912 + needed + 4 * 1024**2
        assert shutil.disk_usage('/tmp').free >= 1800000000
        assert state() == before
        for dest, _, _, row in prepared:
            assert bind(dest) == row['before']
        journal = HOME / ('APPLIED-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S') + '.jsonl')
        assert not journal.exists()
        with journal.open('x') as log:
            log.write(json.dumps({'status': 'STARTED', 'head': before['head']}) + '\n')
            log.flush()
            os.fsync(log.fileno())
            for dest, raw, mode, row in prepared:
                dest.parent.mkdir(parents=True, exist_ok=True)
                fd, temp = tempfile.mkstemp(prefix='.school-adopting-', dir=str(dest.parent))
                try:
                    with os.fdopen(fd, 'wb') as f:
                        f.write(raw)
                        f.flush()
                        os.fsync(f.fileno())
                    os.chmod(temp, mode)
                    os.replace(temp, dest)
                finally:
                    if os.path.exists(temp):
                        os.unlink(temp)
                assert bind(dest) == row['after']
                log.write(json.dumps({'path': row['path'], 'sha256': row['after']['sha256']}) + '\n')
                log.flush()
                os.fsync(log.fileno())
            assert state() == before, 'Unexpected Git metadata mutation'
            assert shutil.disk_usage('/workspace').free >= 536870912
            assert shutil.disk_usage('/tmp').free >= 1800000000
            log.write(json.dumps({'status': 'SIX_SOURCE_PATHS_APPLIED_GIT_METADATA_EXACT_NATIVE_WORK_PENDING'}) + '\n')
            log.flush()
            os.fsync(log.fileno())
        result['status'] = 'SIX_SOURCE_PATHS_APPLIED_NATIVE_WORK_PENDING'
        result['journal'] = str(journal)
    if args.report:
        target = args.report.resolve()
        assert target.is_relative_to(HOME) and not target.exists()
        target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
