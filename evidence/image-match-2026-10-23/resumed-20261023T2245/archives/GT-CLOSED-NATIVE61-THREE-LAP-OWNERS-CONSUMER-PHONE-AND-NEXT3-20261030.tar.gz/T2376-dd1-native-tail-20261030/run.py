from pathlib import Path
import datetime,gzip,hashlib,io,json,os,re,shutil,subprocess,time,zipfile
import xml.etree.ElementTree as ET
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path(__file__).parent;E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();steps=[]
def g(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def save(n,j):(O/n).write_text(json.dumps(j,indent=2)+'\n')
assert g('rev-parse','HEAD').decode().strip()=='dd1dfd88808ee36187825706cb71a5ad70bdd262'
assert g('branch','--show-current').decode().strip()=='steward/t2376-green-tree-current87-20261030'
models={p.relative_to(R).as_posix():sha(p.read_bytes())for d in ['gltf','web']for p in(A/'assets'/d).rglob('*.glb')if not p.is_symlink()};save('BEFORE-MODELS.json',models)
source={r['path']:r['sha256']for r in map(json.loads,Path('/workspace/T2376-current87-guarded-replay-helper-carpenter-20261029/APPLIED-20261030T000515.jsonl').read_text().splitlines())if'path'in r};assert len(source)==51
before44={}
for line in g('ls-files','--stage','--','*.gz','*.xlsx').splitlines():
 meta,raw=line.split(b'\t',1);mode,oid,stage=meta.decode().split();rel=raw.decode();assert stage=='0';q=g('cat-file','--batch-check=%(objectname) %(objecttype)',)if False else None
 base=g('cat-file','blob',oid);assert base==(R/rel).read_bytes(),rel;before44[rel]={'oid':oid,'sha256':sha(base),'mode':oct((R/rel).stat().st_mode&0o777)}
assert len(before44)==44;save('BEFORE44-CANONICAL-OBJECTS.json',before44)
libp=R/'chicago/prairie_1904_v1/data/images.json';oldlib=json.loads(libp.read_text());oldplan=sha((R/'chicago/prairie_1904_v1/data/site-plan.json').read_bytes())
save('BINDING.json',{'at':now(),'head':g('rev-parse','HEAD').decode().strip(),'all51_source':source,'all_models':len(models),'native44_baselines':'Immutable verified current Git blob objects; no duplicate active-file snapshots/hardlinks. Preserve nativechangedraw bytes before semantic-only restoration.','workspace_floor':536870912,'tmp_caller_floor':1800000000,'old_library_records':len(oldlib['images'])})
def run(name,cmd):
 ws=shutil.disk_usage('/workspace').free;tm=shutil.disk_usage('/tmp').free;assert ws>=536870912 and tm>=1800000000,(name,ws,tm);start=time.monotonic();rp=O/(name+'-REAPER.json')
 with(O/(name+'.log')).open('x')as f:q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','nice','-n','19','taskset','-c','0,1,3,4',*cmd],cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
 r=json.loads(rp.read_text());row={'name':name,'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-start,'all_children_reaped':r['all_children_reaped'],'workspace_free_before':ws,'tmp_free_before':tm};steps.append(row);save('STEPS.json',steps);print(json.dumps(row),flush=True);assert q.returncode==0 and r['all_children_reaped'],row
run('library',['python3','../prairie_1904_v1/tools/build_images.py']);newlib=json.loads(libp.read_text());old={x['id']:x for x in oldlib['images']};new={x['id']:x for x in newlib['images']};assert len(new)==len(old)+3 and all(new[k]==v for k,v in old.items());assert all(newlib['by_building'][k]==v for k,v in oldlib['by_building'].items()if k!='green_tree_tavern');assert all(newlib['by_parcel'][k]==v for k,v in oldlib['by_parcel'].items());assert sha((R/'chicago/prairie_1904_v1/data/site-plan.json').read_bytes())==oldplan;save('LIBRARY.json',{'status':'ACTUAL_OFFICIAL_LIBRARY_ADD_ONLY3_GT_ALL952_FOREIGN_RECORDS_AND_SITEPLAN_EXACT','old':len(old),'new':len(new),'added_ids':sorted(set(new)-set(old)),'all_foreign_building_and_parcel_lookups_exact':True})
run('pre-tail-publish',['bash','tools/publish.sh'])
run('native-61-settled-tail',['node','tools/rederive.mjs','--tail','tools/compile_liberties.py']);text=(O/'native-61-settled-tail.log').read_text();assert '61 step(s) in manifest order' in text and 'the last one moved nothing' in text

def unique(pairs):
 d={}
 for k,v in pairs:assert k not in d;d[k]=v
 return d
def canon(b):return json.dumps(json.loads(b,object_pairs_hook=unique),sort_keys=True,separators=(',',':'))
def workbook(b):
 with zipfile.ZipFile(io.BytesIO(b))as z:
  names=z.namelist();assert len(names)==len(set(names));out={}
  for n in names:
   v=z.read(n)
   if n.endswith(('.xml','.rels')):
    r=ET.fromstring(v)
    if n=='docProps/core.xml':
     for c in list(r):
      if c.tag=='{http://purl.org/dc/terms/}modified':r.remove(c)
    v=ET.canonicalize(ET.tostring(r,encoding='unicode'),rewrite_prefixes=True)
   out[n]=v
  return out
rows=[]
for rel,info in before44.items():
 p=R/rel;base=g('cat-file','blob',info['oid']);assert sha(base)==info['sha256'];native=p.read_bytes();exact=base==native;equal=exact;method='EXACT_BYTES'
 if not exact:
  raw=O/'raw-native44'/rel;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_bytes(native)
  if rel.endswith('.gz'):
   x,y=gzip.decompress(base),gzip.decompress(native);equal=x==y;method='DECOMPRESSED_EXACT'
   if not equal:equal=canon(x)==canon(y);method='DUPLICATE_FREE_JSON_ALL_VALUES_TYPES_ARRAY_ORDER'
  else:equal=workbook(base)==workbook(native);method='ALL_XLSX_MEMBERS_CANONICAL_XML_EXCEPT_CORE_MODIFIED'
  if equal:p.write_bytes(base)
 rows.append({'path':rel,'before_sha256':sha(base),'native_sha256':sha(native),'equal':equal,'method':method,'serialization_only_restored':not exact and equal,'real_native_change_retained':not equal})
save('ALL44.json',rows)
assert all(sha((R/p).read_bytes())==s for p,s in models.items()),'Native owner changed model bytes'
assert all(sha((R/p).read_bytes())==s for p,s in source.items()),'Native owner changed exact authored/registry51 source'
run('final-publish',['bash','tools/publish.sh'])
assert all(sha((R/p).read_bytes())==s for p,s in models.items())and all(sha((R/p).read_bytes())==s for p,s in source.items())
save('RESULT.json',{'status':'ACTUAL_GT_CURRENT_DD1_LIBRARY_NATIVE61_SETTLED_OWNERS_AND_PUBLISH_PASS','at':now(),'all_model_bytes_exact':len(models),'all51_authored_registry_source_exact':True,'all44_audited':len(rows),'real_native_changes_retained':[r['path']for r in rows if not r['equal']],'all_children_reaped':all(r['all_children_reaped']for r in steps),'steps':steps,'last_native_lap_moved_nothing':True,'limits':'Current native owners/publish only. Consumer bindings/phone, actual1456dev landing integration, final source gate/commit/PR/native broad smoke/dev merge remain pending.'});print((O/'RESULT.json').read_text(),flush=True)
