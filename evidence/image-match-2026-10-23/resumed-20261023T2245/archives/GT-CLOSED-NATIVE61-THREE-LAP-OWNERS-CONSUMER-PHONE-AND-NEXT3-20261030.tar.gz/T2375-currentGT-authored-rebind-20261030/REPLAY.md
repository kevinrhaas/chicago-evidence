# T-2375: current Green Tree source rebind

This is an external proposal, not an adoption or a closed ticket. `RESULT.json`
binds all20 postimages to the actual current authored source at00:14UTC,30October.
Primary HEAD was `dd1dfd88808ee36187825706cb71a5ad70bdd262`, with the accepted
Green Tree WIP on `steward/t2376-green-tree-current87-20261030`. Source/index/config/
refs were byte-identical before and after preparation. No Blender, browser, gate,
ticket, commit, PR or primary write ran.

The only overlaps with the old thirteen-path source packet were name_pool_keys,
GLB-CONTRACT, main, walker and compile_scene. The whitelist adds exactly six bridge
note readers while retaining every Green Tree/foreign entry and list order. Main
and compiler changes merged cleanly. Walker's only conflict was two independent
imports; the proposed file retains BOTH the Green Tree occupied-polygons helper
and the bridge deck-surface sampler. Its compound-footprint loop is preserved.
The bridge walk-surface contract appends after the complete current GT contract.

The other seven existing source preimages and the new deck-surface absence guard
still match the accepted V5 packet exactly. The bridge producers and selected
record are byte-identical to those used by actual V5 native output c7408d42… and
WEB f7abac99…. No new geometry choice is proposed.

## Use after the normal claim and source lease

Re-read actual current HEAD and every `RESULT.json.paths` preimage/absence guard.
The exact20 postimages live under `postimages/<repo-relative-path>`, with final
modes in the manifest. A later GT commit/fold changes the HEAD guard but need not
change these authored paths; prove each bound current SHA again. If any path has
moved, rebase ONLY that delta over incoming values. Never restore an old whole
main/walker/compiler, manifest, whitelist or Liberty document.

This packet contains the source/runtime13 paths,3 source records,2 composed
reference inventories, and2 source-specific cameras. It deliberately contains no
derived model, recipe, sidecar, library, rights baseline or matches postimage.
`SOURCE-COVERAGE.json` records all three held pictures and the precise remaining
canonical work. `LIBERTY-ENTRY.md` and `changelog-proposal.json` are separately
labelled proposed append/entry payloads, not whole-file replacements or published
claims. Their absence/collision and the current chronological Liberty tail must
be checked when the actual ticket is claimed.

## Native ownership and recipe proof

All six proposed bridge-family input documents were actually resolved with the
current native `mesh_inputs.structure_inputs_doc`, using the unchanged accepted
bridge parameter module and record. Every parameter/confidence/property value,
all six geometry-code module hashes and the complete Blender pin match the bound
actual V5 emitter inputs. Those full documents/hashes are in `RESULT.json.native6`.
The pinned binary version was also actually asserted4.5.3 in the historical run.

The V5 run used native `emit.emit_structure` directly. It did NOT record canonical
MASTER recipe rows through build.py, so this packet does not invent a historical
manifest hash or recommend hand-stamping one. Run the cheap official six-record
build after the guarded source adoption, from `chicago/4d` with the pinned shared
environment active:

```bash
BLENDER_CACHE=/workspace/shared/blender-dl bash tools/bake.sh --only dearborn_street_drawbridge,lasalle_slough_crossing,north_branch_bridge,north_water_slough_crossing,slough_log_bridge,south_branch_raft_bridge
```

The historical actual native6-control+candidate export took1.66s in one Blender
session, with the candidate emit itself0.255s and its WEB generation3.11s. The
official orchestration may take longer; no future timing or pass is claimed.
All five foreign bridge MASTERs must stay byte-identical to current values. The
selected Dearborn MASTER should reproduce c7408d424c67488f56650e190fdd7af6a23a667c67f005dff1849ef20c3b2f84
(1,101,020B/14,412triangles), with the expected current WEB136,752B SHA
f7abac99a73e858b055c5668a61e093a7786385cb542cecb3245ebc55d7907ab.
Let native producers own all registry/freshness changes; preserve every unrelated
manifest row.

The V5 platform is3.6×7.8288m, offset−1.0m. Its pure builder computes46 perimeter
piles PER cap (nx8,ny17),92 across two caps. The earlier38-per-cap figure describes
the narrower V4 trial. Counts, cap/pile scantlings, stopping depth, profile rise,
brace height and signed offset remain reconstructed; no source measures them.

## Cameras, attribution and rights

The Andreas camera retains the exact accepted V5 numeric framing and corrects its
old flat-deck preview prose. The Earle camera retains the actually rendered,
corrected four-control framing, replacing the source proposal's unfitted seed.
Both canonical proposals point at the existing exact credited source files and
are `diagnostic_only`: neither is a geographic/historical From-this-spot claim.
No `matches` record has been copied or promoted. After native compilation and
publication, capture the two actual canonical comparisons:

```bash
node tools/photo_match.mjs data/reference_views/dearborn_street_drawbridge/andreas_1884.json --out docs/RESEARCH/photo-match/dearborn_street_drawbridge
node tools/photo_match.mjs data/reference_views/dearborn_street_drawbridge/earle_1902_lunette.json --out docs/RESEARCH/photo-match/dearborn_street_drawbridge
```

Use a genuinely short private browser TMPDIR under the documented disk/CPU lease;
the earlier deep-path Unix-socket failure remains historical evidence. Directly
review current output before recording fixed/within-tolerance/not-shown/matches.
Do not reopen camera/geometry loops over genuine retrospective projection/tone
conflicts under T3153.

The owner's Tribune credit is retained verbatim in the qualified Baker source
proposal. The actual15February1880 editorial is independently verified, text-only,
and supplies no1835 coordinates/form. The exact Baker engraving was not found in
the16 scanned pages. Its original publication/rights stay qualified rather than
being silently dated1880. The geometry rests independently on cleared
Andreas1884/Norton-Moses text and the verified Earle c1902 original volume. No new
Baker-derived camera/comparison asset is proposed.

The old active Baker lifting-gear source is replaced with the independently
cleared Andreas citation, with its historical route retained in prose. Run the
normal `python3 tools/measure_rights_derivation.py --update` and `--gate` only
after the legitimate source repair is adopted; inspect the exact baseline delta
and preserve every foreign exemption. This packet has not restamped the baseline.

## Remaining closure work

Run the official current derived owners/mandatory settled tail and publish, then
validate native source use, sidecars, grades, picture/source cards and current
library links. Preserve declared mapped origin/bearing/76.33m water gap, the
attested18.288m draw, other bridge models and all unrelated scene records.

Rebind the existing actual runtime proof to current inputs: profile sampler,
walker/router/humans/anchor agreement, deck endpoints and landside transition,
and complete current prop/horse/vehicle/yard extents. Earlier pure/native proofs
passed1024+1024 controls,348 floor hits,three tracks/four8mm gaps each and a finite
25.77m yard-clearance bound; these are dated input-bound proofs, not fresh app
visits. Verify current app walking across the deck and street approaches, body,
Normal/ByGrade, credited full cleared images/Sources/Research on desktop and
390×780 with zero errors. Do not claim horse/vehicle contact from a human-root
height sampler, or interior/whole-body clearance from a nominal deck-top proxy.

The shared runtime changes require a fresh native `smoke_budget.mjs --for-diff`
reading and the relevant published BOTH-viewport smoke, current phone budget,
foreground full check/preflight, then a checked dev PR and actual CI/merge.
`image_gate --structure dearborn_street_drawbridge` must pass the actual current
canonical views before official original-ticket closure. No new photo follow-up
tickets and no original DONE claim are made here.
