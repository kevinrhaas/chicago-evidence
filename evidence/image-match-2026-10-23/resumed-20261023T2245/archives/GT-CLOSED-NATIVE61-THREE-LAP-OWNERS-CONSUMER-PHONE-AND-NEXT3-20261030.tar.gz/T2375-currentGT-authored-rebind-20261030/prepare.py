"""Bounded external-only rebind. Never writes the application or its Git state."""
from pathlib import Path
import ast, copy, datetime, difflib, hashlib, importlib.util, json, os, re, stat, subprocess, sys
sys.dont_write_bytecode = True
R = Path('/workspace/chicago'); A = R / 'chicago/4d'; O = Path(__file__).resolve().parent
P = Path('/tmp/dearborn-final13-path-adoption-packet-20261029')
V = Path('/workspace/T2375-native-v5-width16-20261029')
E = Path('/workspace/T2375-earle-identity-view-prep-20261029')
T = Path('/workspace/T2375-baker-owner-tribune1880-addendum-20261029')
COMPOSED = T / 'external-composition-replay'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
sha = lambda b: hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git', '-C', str(R), *args], env=ENV)
def state():
    return {'HEAD': git('rev-parse', 'HEAD').decode().strip(), 'branch': git('branch','--show-current').decode().strip(),
            'index':sha((R/'.git/index').read_bytes()), 'config':sha((R/'.git/config').read_bytes()), 'refs':sha(git('show-ref'))}
def raw(p): return p.read_bytes() if p.exists() else None
before = state(); made = {}; rows = []; merges = []
def put(rel, body, reason, donor=None):
    assert rel not in made
    cur = raw(R/rel); mode = stat.S_IMODE((R/rel).stat().st_mode) if cur is not None else 0o644
    made[rel] = body
    rows.append({'path':rel, 'before_sha256':sha(cur) if cur is not None else None, 'before_bytes':len(cur) if cur is not None else None,
                 'after_sha256':sha(body),'after_bytes':len(body),'mode':oct(mode),'composition':reason,'donor':str(donor) if donor else None})

source = json.loads((P/'RESULT.json').read_text())
for item in source['paths']:
    rel='chicago/4d/'+item['path']; current=raw(R/rel); own=P/'candidate'/rel; final=own.read_bytes()
    assert sha(final)==item['after_sha256']
    oldfile=P/'before'/rel; old=raw(oldfile)
    assert (sha(old) if old is not None else None)==item['before_sha256']
    overlaps=(sha(current) if current is not None else None)!=item['before_sha256']
    if not overlaps:
        body=final; reason='exact_accepted_V5_postimage_current_preimage_exact'
    elif rel.endswith('name_pool_keys.json'):
        b,o,c=map(json.loads,[old,final,current]); assert b.keys()==o.keys()
        added=[x for x in o['read']['structures'] if x not in b['read']['structures']]
        assert len(added)==6 and set(b['read']['structures']).issubset(o['read']['structures'])
        check=copy.deepcopy(o);check['read']['structures']=b['read']['structures'];assert check==b
        result=copy.deepcopy(c);result['read']['structures'] += [x for x in added if x not in result['read']['structures']]
        assert result['read']['structures'][:len(c['read']['structures'])]==c['read']['structures']
        check=copy.deepcopy(result);check['read']['structures']=c['read']['structures'];assert check==c
        body=(json.dumps(result,indent=2)+'\n').encode();reason='six_note_readers_union_preserving_all_current_GT_and_foreign_values_order'
    elif rel.endswith('docs/GLB-CONTRACT.md'):
        assert final.startswith(old); suffix=final[len(old):]
        assert b'## Optional span walk-surface profile (T-2375)' in suffix
        assert b'## Optional span walk-surface profile (T-2375)' not in current
        body=current+suffix;reason='append_exact_bridge_contract_after_current_GT_contract_preserving_all_current_bytes'
    else:
        q=subprocess.run(['git','merge-file','-p','-L','CURRENT_GT','-L','BASE','-L','BRIDGE',str(R/rel),str(oldfile),str(own)],env=ENV,capture_output=True)
        body=q.stdout
        if q.returncode:
            assert rel.endswith('renderers/web/js/walker.js') and q.returncode==1
            # Both proposals add an independent import at the same old line.
            pattern=rb"<<<<<<< CURRENT_GT\n(import \{ occupiedPolygons \} from './occupied-footprints.js';\n)=======\n(import \{ deckFromSidecar, deckHeightAt \} from './deck-surface.js';\n)>>>>>>> BRIDGE\n"
            body,count=re.subn(pattern,lambda m:m[1]+m[2],body);assert count==1
            reason='three_way_merge_plus_both_independent_imports_preserves_GT_occupied_footprints_and_bridge_profile_sampler'
        else: reason='clean_three_way_merge_preserving_current_GT_changes_and_exact_bridge_delta'
        assert b'<<<<<<<' not in body and b'>>>>>>>' not in body
        merges.append({'path':rel,'native_merge_file_exit':q.returncode,'manual_resolution':'two independent imports' if q.returncode else None})
    put(rel,body,reason,own)

# Existing source-proposal composition already joined Earle and the owner's
# qualified Tribune lead. Current source/inventory preimages still match.
ep=json.loads((E/'PROPOSAL-PATHS.json').read_text());tp=json.loads((T/'PROPOSAL-PATHS.json').read_text())
declared={x['path']:x for x in ep+tp}
for rel in sorted(declared):
    if '/reference_views/' in rel: continue
    row=declared[rel];cur=raw(R/rel)
    assert (sha(cur) if cur is not None else None)==row['before_sha256'],rel
    donor=COMPOSED/rel;body=donor.read_bytes()
    if rel.endswith('earle_chicago_national_bank_1902_dearborn_bridge.json'):
        doc=json.loads(body);doc['note'] += '\n\nSUBSEQUENT DIAGNOSTIC COMPARISON: the accepted sixteen-foot V5 bridge was actually rendered against this identified Earle image on 2026-10-29, including a corrected finite four-point framing. Both gallows, high outer braces, closed peaked deck, chains, boarded parapets and piled caps were compared. The camera is a reconstructed diagnostic fit; it establishes no historical viewpoint, metric dimensions or exact July-1835 condition. Fresh canonical metadata-bound capture remains a separate adoption step.'
        body=(json.dumps(doc,indent=2)+'\n').encode()
    if rel.endswith('.md'):
        # Preserve all untouched inventory lines, removing trailing whitespace
        # only on genuinely new/replaced source lines from the old proposal.
        oldlines=cur.decode().splitlines(True);newlines=body.decode().splitlines(True);clean=[]
        for tag,a,b,c,d in difflib.SequenceMatcher(a=oldlines,b=newlines,autojunk=False).get_opcodes():
            clean.extend(newlines[c:d] if tag=='equal' else [s.rstrip('\n').rstrip(' \t')+('\n'if s.endswith('\n')else'')for s in newlines[c:d]])
        body=''.join(clean).encode()
    put(rel,body,'guarded_existing_Earle_and_qualified_owner_Tribune_source_composition',donor)

# Two source-specific cameras, with the accepted numeric framing preserved.
# No unreviewed match record is promoted or invented by this source packet.
for name,donor,photo in [
 ('andreas_1884.json',V/'source-camera.json','../../../../reference/images/chicago/chicago_dearborn_drawbridge_1834.png'),
 ('earle_1902_lunette.json',Path('/workspace/T2375-earle-native-camera-trial-v1-20261029/corrected-camera/earle_1902_lunette.json'),'../../../../reference/images/chicago/chicago_first_swing_bridge_1849_earle.jpg')]:
    rel='chicago/4d/data/reference_views/dearborn_street_drawbridge/'+name
    assert not (R/rel).exists();doc=json.loads(donor.read_text());doc['photo']=photo;doc['diagnostic_only']=True
    if name.startswith('andreas'):
        doc['solve']='RECONSTRUCTED DIAGNOSTIC FRAMING. Numeric pose/focal/principal retained from the actual V5 Andreas comparison accepted under T3153. Its original provisional fit used eight approximate upright centres, not surveyed controls. The later V5 model supplies the peaked closed deck, high rakers, sixteen-foot width and piled caps; older flat-deck preview prose is superseded. Drawing perspective differences are not a measurement or a reason to move the independently mapped bridge origin, bearing or banks. No authentic historical From-this-spot location follows. Fresh canonical metadata-bound capture and explicit review are required before a current matches verdict.'
    else:
        doc['solve']='RECONSTRUCTED DIAGNOSTIC FRAMING. Numeric corrected camera retained from the actual accepted 2026-10-29 V5 Earle comparison. Approximate controls: far post deck/head (300,620)/(300,405), near post deck/head (1020,635)/(1020,200), roughly20px picking uncertainty. Corrected native capture actually completed in4.624s; the first lower-head-pick capture remains historical evidence of a camera error. Weakly constrained four-point fitting and nearzero residual do not establish a surveyed camera or metric geometry. Preserve the independently mapped origin/bearing/water gap, the separately sourced16ft width and reconstructed profile/piles/rakers. Andreas/Earle projection and tone differences remain within tolerance under T3153. Fresh canonical metadata-bound capture and explicit review are required before a current matches verdict.'
    body=(json.dumps(doc,indent=2)+'\n').encode();put(rel,body,'accepted_numeric_diagnostic_camera_rebound_to_canonical_photo_path_no_match_verdict',donor)
    picture=((R/rel).parent/photo).resolve();assert picture.is_file()

# Reconstruct the whole native input document of the actual V5 export. The
# archival run used direct emit, not build.py's manifest writer; keep that limit.
sys.path.insert(0,str(A/'generators'));import mesh_inputs
spec=importlib.util.spec_from_file_location('bridge_current_candidate_params',P/'candidate/chicago/4d/generators/archetypes/bridge_timber_params.py')
params=importlib.util.module_from_spec(spec);sys.modules[spec.name]=params;spec.loader.exec_module(params)
oldresolve=mesh_inputs.resolve_params;oldsha=mesh_inputs._sha_file
mesh_inputs.resolve_params=lambda arch,phase,record:params.from_phase(phase,record)if arch=='bridge_timber'else oldresolve(arch,phase,record)
F=V/'frozen-native-source';inp=json.loads((V/'INPUTS.json').read_text())
builder=P/'candidate/chicago/4d/generators/archetypes/bridge_timber.py'
assert builder.read_bytes()==(V/'inputs/candidate/bridge_timber.py').read_bytes()
assert (P/'candidate/chicago/4d/generators/archetypes/bridge_timber_params.py').read_bytes()==(V/'inputs/candidate/bridge_timber_params.py').read_bytes()
assert made['chicago/4d/data/structures/dearborn_street_drawbridge.json']==(V/'inputs/candidate/dearborn_street_drawbridge.json').read_bytes()
assert (A/'generators/blender.pin').read_bytes()==(F/'generators/blender.pin').read_bytes()
native=[]
for item in inp['family']:
    rp=Path(item['canonical_record']);assert sha(rp.read_bytes())==item['record_sha256']
    assert sha(Path(item['current_master']).read_bytes())==item['current_master_sha256']
    r=json.loads(made['chicago/4d/data/structures/dearborn_street_drawbridge.json']) if item['id']=='dearborn_street_drawbridge' else json.loads(rp.read_text())
    phase=next(p for p in r['phases']if p['id']==item['phase'])
    mesh_inputs._sha_file=lambda p:sha(builder.read_bytes())if p==A/'generators/archetypes/bridge_timber.py'else oldsha(p)
    now=mesh_inputs.structure_inputs_doc(r,phase,'bridge_timber')
    for code,h in now['code'].items():
        if code=='archetypes/bridge_timber.py':assert h==sha((V/'inputs/candidate/bridge_timber.py').read_bytes())
        else:
            assert sha((F/'generators'/code).read_bytes())==h
            assert inp['producer_current_bindings'][str(A/'generators'/code)]==h
    hist=copy.deepcopy(now);hist['code']={code:sha((V/'inputs/candidate/bridge_timber.py').read_bytes())if code=='archetypes/bridge_timber.py'else sha((F/'generators'/code).read_bytes())for code in now['code']};hist['blender_pin']=(F/'generators/blender.pin').read_text().strip()
    assert hist==now
    native.append({'id':item['id'],'phase':item['phase'],'proposed_inputs_sha256':sha(json.dumps(now,sort_keys=True).encode()),'full_historical_bound_input_document_equal':True,'code_modules':now['code'],'blender_pin_sha256':sha((A/'generators/blender.pin').read_bytes()),'params':now['params'],'historical_native_manifest_recipe':None})
mesh_inputs._sha_file=oldsha;mesh_inputs.resolve_params=oldresolve

assert len(rows)==20
for row in rows:
    f=R/row['path'];assert (sha(f.read_bytes())if f.exists()else None)==row['before_sha256'],row['path']
assert state()==before,'Primary Git state changed; no source mutation was attempted'
for rel,body in made.items():
    if rel.endswith('.json'):json.loads(body)
    if rel.endswith('.py'):ast.parse(body)
    p=O/'postimages'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body);p.chmod(int(next(x['mode']for x in rows if x['path']==rel),8))
result={'status':'EXTERNAL20_AUTHORED_POSTIMAGES_CURRENT_GT_REBOUND_FULL6_NATIVE_INPUT_PARITY_NO_CANONICAL_ADOPTION',
        'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'primary_state':before,'primary_state_unchanged':True,'paths':rows,'clean_three_way_merges':merges,'native6':native,
        'native_parity_limit':'V5 direct emit and WEB export are actual, complete6-code+pin+params input parity is reconstructed from its bound snapshot. No historical canonical manifest recipe was recorded. Use the cheap official six-record bake to own current canonical rows; do not hand stamp metadata.',
        'total_postimage_bytes':sum(len(x)for x in made.values()),'camera_matches_promoted':0,'scope':'No primary source/index/ref/config/ticket writes; no Blender/browser/fullgate/new PR/DONE or new photo follow-up. Proposed source/camera postimages only.'}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['paths','native6']},indent=2))
