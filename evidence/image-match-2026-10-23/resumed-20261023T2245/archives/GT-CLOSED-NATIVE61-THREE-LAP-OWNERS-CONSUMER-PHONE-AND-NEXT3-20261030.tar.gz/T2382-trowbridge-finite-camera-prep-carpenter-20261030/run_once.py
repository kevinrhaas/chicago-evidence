"""One external native photo capture; requires the GT writer's explicit CPU lease."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time

P = Path(__file__).resolve().parent
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--view', choices=['trowbridge', 'kurz14'], default='trowbridge')
args = ap.parse_args()
CASE = P if args.view == 'trowbridge' else P / 'kurz14-capture'
CASE.mkdir(exist_ok=True)
RUNTIME = Path('/workspace/T2382-native-gable-addon-school-agent-v3-20261029/runtime')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert os.environ.get('CARPENTER_TROWBRIDGE_CPU_LEASE') == 'gt-writer-tail-closed-one-native-capture'
assert not (CASE / 'ACTUAL-CAPTURE.json').exists(), 'One finite actual attempt per source only'
assert not (CASE / 'NATIVE.log').exists(), 'Do not replace a failed attempt'
binding = json.loads((P / 'BINDINGS.json').read_text())
camera = P / ('trowbridge-1902-external.json' if args.view == 'trowbridge' else 'kurz-panel14-external.json')
camera_sha = binding['camera_sha256' if args.view == 'trowbridge' else 'kurz14_camera_sha256']
picture_sha = binding['picture_sha256' if args.view == 'trowbridge' else 'kurz14_picture_sha256']
assert sha(camera) == camera_sha
assert sha(Path(json.loads(camera.read_text())['photo'])) == picture_sha
assert sha(RUNTIME / 'assets/gltf/philo_carpenter_log_shop__log_1832.glb') == binding['MASTER']['sha256']
assert sha(RUNTIME / 'assets/gltf/sauganash_hotel__frame_1831.glb') == binding['hotel_holdout_sha256']
for row in binding['source_guards']:
    assert sha(Path('/workspace/chicago') / row['path']) == row['sha256']
old_manifest = Path('/workspace/T2382-native-gable-addon-school-agent-v3-20261029/MANIFEST.json')
old_members = json.loads(old_manifest.read_text())['members']
for row in old_members:
    assert sha(Path(row['path'])) == row['sha256'], row['path']
workspace_floor, tmp_floor = 536870912, 1800000000
assert shutil.disk_usage('/workspace').free >= workspace_floor
assert shutil.disk_usage('/tmp').free >= tmp_floor
scratch = Path('/tmp/c2382t30' if args.view == 'trowbridge' else '/tmp/c2382k30')
assert not scratch.exists()
scratch.mkdir(mode=0o700)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1',
           OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1',
           PW_EXECUTABLE='/usr/bin/chromium', TMPDIR=str(scratch),
           NODE_PATH='/workspace/shared/node/node_modules' + (':' + os.environ['NODE_PATH'] if os.environ.get('NODE_PATH') else ''),
           GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
cmd = ['python3', '/workspace/shared/run-with-reaping.py', str(CASE / 'REAPER.json'), '--',
       'nice', '-n', '19', 'taskset', '-c', '3,4', 'node', 'tools/photo_match.mjs',
       str(camera), '--glb', 'assets/gltf/philo_carpenter_log_shop__log_1832.glb',
       '--out', str(CASE / 'outputs')]
samples = []
start = time.monotonic()
breach = None
with (CASE / 'NATIVE.log').open('x') as log:
    proc = subprocess.Popen(cmd, cwd=RUNTIME, env=env, stdout=log, stderr=subprocess.STDOUT)
    while proc.poll() is None:
        sample = {'seconds': round(time.monotonic() - start, 3),
                  'workspace_free': shutil.disk_usage('/workspace').free,
                  'tmp_free': shutil.disk_usage('/tmp').free}
        samples.append(sample)
        if sample['workspace_free'] < workspace_floor or sample['tmp_free'] < tmp_floor or sample['seconds'] > 120:
            breach = sample
            proc.send_signal(signal.SIGTERM)
            break
        time.sleep(0.25)
    exit_code = proc.wait(timeout=45)
reaped = json.loads((CASE / 'REAPER.json').read_text())
result = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': cmd,
          'cwd': str(RUNTIME), 'actual_exit': exit_code, 'seconds': round(time.monotonic() - start, 3),
          'all_children_reaped': reaped['all_children_reaped'], 'resource_breach': breach,
          'resource_samples': samples, 'canonical_primary_changes': False,
          'view': args.view, 'verdict': 'UNREVIEWED_EXTERNAL_BODY_COMPARISON_ONLY'}
if exit_code == 0 and breach is None and reaped['all_children_reaped']:
    match_file = camera.with_suffix('.match.json')
    match = json.loads(match_file.read_text())
    assert match['glb_sha256'] == binding['MASTER']['sha256']
    assert match['camera_sha256'] == camera_sha
    assert match['photo_sha256'] == picture_sha
    assert match['verdict'] == 'unreviewed'
    assert len(match['rendered_members']) == 2
    assert match['rendered_members'][1]['glb_sha256'] == binding['hotel_holdout_sha256']
    result['match'] = {'path': str(match_file), 'sha256': sha(match_file)}
    side = CASE / 'outputs' / (camera.stem + '-side-by-side.jpg')
    assert side.is_file()
    result['side_by_side'] = {'path': str(side), 'sha256': sha(side), 'bytes': side.stat().st_size}
    hit = re.search(r'\n\s+(/[^\n]+-render\.png)\n', (CASE / 'NATIVE.log').read_text())
    assert hit and Path(hit.group(1)).is_file()
    result['raw_native_png'] = {'path': hit.group(1), 'sha256': sha(Path(hit.group(1)))}
    result['status'] = 'ACTUAL_NATIVE_SOURCE_BODY_CAPTURE_PASS_UNREVIEWED'
else:
    result['status'] = 'ACTUAL_CAPTURE_REFUSED_OR_FAILED_NO_PASS'
for row in old_members:
    assert sha(Path(row['path'])) == row['sha256'], row['path']
result['all_old_native_prototype_members_exact'] = True
(CASE / 'ACTUAL-CAPTURE.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
assert result['status'] == 'ACTUAL_NATIVE_SOURCE_BODY_CAPTURE_PASS_UNREVIEWED'
