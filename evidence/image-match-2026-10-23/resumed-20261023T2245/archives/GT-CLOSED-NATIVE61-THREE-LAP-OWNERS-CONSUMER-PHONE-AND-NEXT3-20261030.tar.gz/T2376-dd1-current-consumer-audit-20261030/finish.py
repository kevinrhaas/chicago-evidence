from pathlib import Path
import datetime,hashlib,json
R=Path('/workspace/chicago');S=R/'site/4d';O=Path(__file__).parent;F=Path('/workspace/T2376-b20f-app-v6-20261029/frozen');sha=lambda b:hashlib.sha256(b).hexdigest();c=json.loads((O/'CENSUS.json').read_text());f=json.loads((F/'SOURCE-BINDINGS.json').read_text());old={r['path']:r for r in f['paths']};changed={r['path']:r for r in c['changed']};assert len(changed)==34
for r in f['paths']:
 p=Path(r['path']);want=changed[str(p)]['current_sha256']if str(p)in changed else r['sha256'];assert sha(p.read_bytes())==want,str(p)
e=json.loads((F/'APP-EXPECTED.json').read_text());targets=[]
for x in e['cases']:
 p=S/'data/sidecars/1835'/('green_tree_tavern.json'if x['label']=='canonical'else'versions/green_tree_tavern/andreas-reading.json');assert json.loads(p.read_text())==x['sidecar'];web=S/'data'/x['WEB_path_suffix'].lstrip('/');assert sha(web.read_bytes())==x['WEB_sha256'];targets.append({'label':x['label'],'published_sidecar_sha256':sha(p.read_bytes()),'WEB_sha256':x['WEB_sha256']})
lib=json.loads((S/'data/liberties.json').read_text());q=json.loads((O/'LIBERTY-TARGET-RECONSTRUCTION.json').read_text());rel=lambda x:'green_tree_tavern'in x.get('subjects',[])or any(z.get('structure')=='green_tree_tavern'for z in x.get('covers',[]));assert[x['id']for x in lib['liberties']if rel(x)]==q['target_ids']
assert all(r['only_build_commit_stamp_changed_exact_reconstruction']for r in json.loads((O/'PREBUILT-STAMP-RECONSTRUCTION.json').read_text()));assert len(json.loads((O/'BUILD-HTML-RECONSTRUCTION.json').read_text())['all5_html_old_SHA_exact'])==5;assert len(json.loads((O/'SOURCE-INDEX-RECONSTRUCTION.json').read_text())['all_target10_sources_unmodified'])==10
four=json.loads(Path('/workspace/PR1456-current87-inactive1835-consumer-audit-root-20261029/RESULT.json').read_text());mod=four['changed_module'];assert sha(Path(mod['source_path']).read_bytes())==sha(Path(mod['published_path']).read_bytes())==mod['current_sha256'];assert sha((S/'data/scenes/1835.json').read_bytes())==four['actual1835_inactive_route']['scene_sha256'];assert'street_trees'not in json.loads((S/'data/scenes/1835.json').read_text())['layers'];assert str(S/'walk/js/main.js')not in changed
modern={'hibbard_house_1701_prairie__as_mapped_1904.glb','pullman_glasshouse_1800_calumet_pavilion__as_standing_1904.glb'};active=[]
for p in(S/'data/sidecars/1835').glob('*.json'):
 j=json.loads(p.read_text())
 if isinstance(j.get('asset'),str):active.append(j['asset'])
assert len(list((S/'data/sidecars/1835').glob('*.json')))>600 and active and not any(Path(p).name in modern for p in active)
def category(path):
 rel=str(Path(path).relative_to(S))
 if rel.endswith('/index.html')or rel=='build.json':return'Only buildstamp/release-badge metadata; exact old wholeSHA reconstructed'
 if rel.startswith('data/prebuilt/'):return'Only buildcommit stamp; exact old wholeSHA reconstructed; all renderdata/binaries exact'
 if rel=='data/liberties.json':return'All22 GTrows/fields/order exact;3unrelatednew1904Libentries and unrelatedHibbardedit'
 if '/sources/'in rel:return'Only3non-GT1904sourcecards/indexrows; old wholeindexSHA reconstructed, all10GTsources exact'
 if rel=='walk/js/street-trees.js':return'Root-reviewed sole treeCard change; unchanged earlyreturn beforefetch/treeCard for actual1835scene withoutstreet_trees'
 if rel=='js/changelog.js':return'Unopened WhatsNew releasefeed; no body/frame/Images/Research route uses this lazyfeed'
 if rel.startswith('packs/'):return'Offline-download manifests outside dated online body/card cases; current native checks validate separately'
 if rel=='tickets.json':return'Queue/claim metadata, no geometry/camera/sidecar/creditedimage change; no claim of queuebyteequality'
 if '1904'in rel or Path(rel).name in modern:return'Unloaded1904-only data/model; native1835activeassets exclude both changedmodels'
 raise AssertionError('Undisposed consumer '+rel)
disposed=[{**r,'disposition':category(r['path'])}for r in c['changed']];(O/'DISPOSITIONS.json').write_text(json.dumps(disposed,indent=2)+'\n')
proofs=[p for p in O.glob('*.json')if p.name!='RESULT.json'];result={'status':'DATED_DD1_GT_TARGETED_FULL_BOTH_CASE_REUSE_QUALIFIED_BY_EXACT_PAYLOADS_AND_EXPLICIT34_DISPOSITIONS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_base':'dd1dfd88808ee36187825706cb71a5ad70bdd262','frozen_total':5632,'byte_exact':5598,'explicit_differences':34,'cases':targets,'canonical_mobile_actual':'/workspace/T2376-b20f-app-v5-20261029/canonical-mobile/RESULT.json','canonical_desktop_honest_two_invocation_composite':'/workspace/T2376-canonical-desktop-composite-20261029/RESULT.json','optional_BOTH_actual':'/workspace/T2376-b20f-app-v6-20261029/RESULT.json','actual_source_fixedpoint':'/workspace/T2376-dd1-native-tail-20261030/RESULT.json','actual_phone':'/workspace/T2376-dd1-phone-20261030/RESULT.json','actual1835_asset_count':len(active),'all_target_photos_library_sidecars_entrances_sign_yard_terrain_collision_renderer_payloads_exact':True,'all22_target_liberties_and10source_index_entries_exact':True,'proofs':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in proofs],'limits':['Dated actual browser invocations are not relabelled new browser runs. Canonicaldesktop retains honest2-invocation qualification.','Metadata/1904/inactive branches explicitly excepted; not5632whole-byte-equality. No current1904visual/offline/WhatsNew/queuepixel claim.','Incominga7ffnewruntime remains UNQUALIFIED; this is dateddd1currentlyfrozenpublishedsnapshot only. Rebind after actualcurrentdevcomposition.','Finalcurrent sourcegate/PR/native30broadsmokes/devmerge remain pending.']};(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in['status','frozen_total','byte_exact','explicit_differences','actual1835_asset_count']},indent=2))
