from pathlib import Path
from zoneinfo import ZoneInfo
from types import SimpleNamespace
import datetime,hashlib,importlib.util,json,math,os,re,subprocess,sys
os.sched_setaffinity(0,{0,1});sys.dont_write_bytecode=True;R=Path('/workspace/chicago');O=Path(__file__).parent;F=json.loads(Path('/workspace/T2376-b20f-app-v6-20261029/frozen/SOURCE-BINDINGS.json').read_text());rows={r['path']:r for r in F['paths']};sha=lambda b:hashlib.sha256(b).hexdigest();E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');current=json.loads((R/'site/4d/build.json').read_text());rp=json.loads(Path('/workspace/T2376-b20f-postowners-v2-20261029/publish-REAPER.json').read_text());match=[]
for n in range(math.floor(rp['started_unix']),math.ceil(rp['observed_unix'])+1):
 dt=datetime.datetime.fromtimestamp(n,datetime.timezone.utc);ct=dt.astimezone(ZoneInfo('America/Chicago'));j={'version':'b20f420049','built_utc':dt.strftime('%Y-%m-%dT%H:%M:%SZ'),'built_ct':ct.strftime('%b %-d, %Y, %-I:%M %p CT')};raw=(json.dumps(j,indent=2)+'\n').encode()
 if sha(raw)==rows[str(R/'site/4d/build.json')]['sha256']:match.append(j)
assert len(match)==1;old=match[0];log=subprocess.check_output(['git','-C',str(R),'show','b20f4200495c38f57f268d24870313e53ed366d9:chicago/4d/renderers/web/js/changelog.js'],env=E).decode();vs=sorted({int(v)for v in re.findall(r'^\s*\{\s*v:\s*(\d+|null)\s*,',log,re.M)if v!='null'});runs=[]
for v in vs:
 if runs and v==runs[-1][1]+1:runs[-1][1]=v
 else:runs.append([v,v])
releases=','.join(f'{a}-{b}'if a!=b else str(a)for a,b in runs);html=[]
for r in rows.values():
 if r['path']not in {str(R/('site/4d/'+x+'/index.html'))for x in ['1812','1835','1880','1904','walk']}:continue
 raw=Path(r['path']).read_bytes()
 for k in current:raw=raw.replace(current[k].encode(),old[k].encode())
 raw,n=re.subn(rb'(<meta name="c4d-releases" content=")[^"]*(">)',lambda m:m[1]+releases.encode()+m[2],raw);assert n==1 and sha(raw)==r['sha256'],r['path'];html.append(r['path'])
(O/'BUILD-HTML-RECONSTRUCTION.json').write_text(json.dumps({'status':'ACTUAL_OLD_BUILD_AND_ALL5_PAGE_BYTES_RECONSTRUCTED_EXACT_BY_ONLY_BUILDSTAMP_AND_RELEASE_RANGE','old_build':old,'current_build':current,'old_release_range':releases,'matched_frozen_old_build_sha256':rows[str(R/'site/4d/build.json')]['sha256'],'all5_html_old_SHA_exact':html,'scope':'Only non-geometric buildstamp and latestreleasebadge metadata. Full HTML body/code/routes otherwise exact.'},indent=2)+'\n');print('PASS old build and five HTML exact stamp+release metadata reconstruction',flush=True)
sys.path.insert(0,str(R/'chicago/4d/tools'));spec=importlib.util.spec_from_file_location('gt_reuse_lib',R/'chicago/4d/tools/compile_liberties.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);oldmd=Path('/workspace/T2376-b20f-authored-rebind-20261029/postimages/chicago/4d/docs/LIBERTIES.md').read_text();m.SOURCE=SimpleNamespace(read_text=lambda:oldmd);doc,problems=m.build();assert not problems,problems[:3];raw=(json.dumps(doc,indent=2,ensure_ascii=False)+'\n').encode();assert sha(raw)==rows[str(R/'site/4d/data/liberties.json')]['sha256']
now=json.loads((R/'site/4d/data/liberties.json').read_text());target=lambda x:'green_tree_tavern'in x.get('subjects',[])or any(c.get('structure')=='green_tree_tavern'for c in x.get('covers',[]));a={x['id']:x for x in doc['liberties']if target(x)};b={x['id']:x for x in now['liberties']if target(x)};assert a==b and a
(O/'LIBERTY-TARGET-RECONSTRUCTION.json').write_text(json.dumps({'status':'ACTUAL_OLD_FROZEN_GT_LIB_JSON_RECONSTRUCTED_BY_NATIVE_COMPILER_AND_ALL_GT_ROWS_EXACT','old_count':doc['count'],'current_count':now['count'],'old_frozen_sha256_exact':sha(raw),'target_ids':list(a),'all_target_rows_fields_and_order_exact':True,'source_native_and_published_full_current_equal':json.loads((R/'chicago/4d/data/liberties.json').read_text())==now,'native_compiler_source':str(R/'chicago/4d/tools/compile_liberties.py')},indent=2)+'\n');print(json.dumps({'PASS_GT_Lib_rows':len(a),'old_count':doc['count'],'new_count':now['count']}),flush=True)
