#!/usr/bin/env python3
"""Read-only by default; parent-only adoption after concrete review."""
from pathlib import Path
import json,hashlib,argparse,os
p=argparse.ArgumentParser();p.add_argument('target',type=Path);p.add_argument('--apply',action='store_true');a=p.parse_args();packet=Path(__file__).resolve().parent;guard=json.loads((packet/'source-guard.json').read_text());candidate=packet/'batch-frustum-box.js';before=hashlib.sha256(a.target.read_bytes()).hexdigest();after=hashlib.sha256(candidate.read_bytes()).hexdigest()
if before!=guard['before_sha256']:raise SystemExit('REFUSED unknown helper preimage')
if after!=guard['after_sha256']:raise SystemExit('REFUSED changed candidate')
if a.apply:
 tmp=a.target.with_name(a.target.name+'.oriented.tmp')
 with tmp.open('xb')as f:f.write(candidate.read_bytes())
 os.chmod(tmp,a.target.stat().st_mode);os.replace(tmp,a.target)
print(json.dumps({'status':'APPLIED'if a.apply else'PASS_READONLY_GUARD','before_sha256':before,'after_sha256':after}))
