import fs from'node:fs';import assert from'node:assert/strict';import crypto from'node:crypto';import {pathToFileURL}from'node:url';
const here=new URL('./',import.meta.url),vendor=pathToFileURL('/tmp/chicago-log-integration/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js').href,T=await import(vendor);
const read=n=>fs.readFileSync(new URL(n,here),'utf8');
async function helper(text,expose=false){return import('data:text/javascript;base64,'+Buffer.from(text.replace("from 'three'",'from '+JSON.stringify(vendor))+(expose?'\nexport { affineBoxOutside };':'')).toString('base64'));}
const old=await helper(read('before.js')),next=await helper(read('batch-frustum-box.js'),true),checks=[];
const test=(name,fn)=>{fn();checks.push(name);console.log('PASS '+name);};
function fixture(module,rotation=Math.PI/4,x=14){const geometry=new T.PlaneGeometry(20,.2),m=new T.MeshStandardMaterial(),b=new T.BatchedMesh(1,4,6,m),id=b.addInstance(b.addGeometry(geometry)),matrix=new T.Matrix4().makeRotationY(rotation);matrix.setPosition(x,0,-10);b.setMatrixAt(id,matrix);b.updateMatrixWorld(true);const depth=new T.MeshDepthMaterial(),stats={};const f=module.installFrustumBoxCull(b,true,depth,null,stats);f.seal();return{b,m,depth,stats};}
function camera(){const c=new T.PerspectiveCamera(60,1,.1,100);c.updateMatrixWorld(true);return c;}
const c=camera();const draw=o=>{o.b.onBeforeRender(null,null,c,o.b.geometry,o.m);return o.b._multiDrawCount;};
test('rotated thin actual native primitive survives worldAABB but its affine box rejects',()=>{const a=fixture(old),b=fixture(next);assert.equal(draw(a),1);assert.equal(draw(b),0);assert.equal(b.stats.orientedBoxRejected,1);});
test('same primitive crossing view boundary remains',()=>{for(const x of[0,4,8])assert.equal(draw(fixture(next,Math.PI/4,x)),1);});
const hash=a=>crypto.createHash('sha256').update(Buffer.from(a.buffer,a.byteOffset,a.byteLength)).digest('hex');
test('extra rejection changes no stored geometry/index/matrices or visibility',()=>{const o=fixture(next),arrays=[o.b.geometry.attributes.position.array,o.b.geometry.index.array,o.b._matricesTexture.image.data],before=arrays.map(hash),visible=o.b.getVisibleAt(0);draw(o);assert.deepEqual(arrays.map(hash),before);assert.equal(o.b.getVisibleAt(0),visible);});
let seed=31693;const rand=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/2**32);
let separated=0;
test('2000 seeded finite affine supports match independently transformed eight corners',()=>{for(let i=0;i<2000;i++){
 const min=new T.Vector3(-rand()*2,-rand()*2,-rand()*2),max=new T.Vector3(rand()*2,rand()*2,rand()*2),box=new T.Box3(min,max),m=new T.Matrix4().set((rand()-.5)*5,(rand()-.5)*2,(rand()-.5)*2,(rand()-.5)*20,(rand()-.5)*2,(rand()-.5)*5,(rand()-.5)*2,(rand()-.5)*20,(rand()-.5)*2,(rand()-.5)*2,(rand()-.5)*5,(rand()-.5)*20,0,0,0,1);
 const plane=new T.Plane(new T.Vector3(rand()-.5,rand()-.5,rand()-.5).normalize(),(rand()-.5)*20),frustum={planes:[plane]},points=[];
 for(const x of[min.x,max.x])for(const y of[min.y,max.y])for(const z of[min.z,max.z])points.push(new T.Vector3(x,y,z).applyMatrix4(m));
 const fringe=1e-4+32*2**-23*Math.max(1,...points.flatMap(p=>p.toArray().map(Math.abs)),Math.abs(plane.constant));
 const actual=Math.max(...points.map(p=>plane.distanceToPoint(p))),limit=-fringe*(Math.abs(plane.normal.x)+Math.abs(plane.normal.y)+Math.abs(plane.normal.z));
 const result=next.affineBoxOutside(frustum,box,m,fringe);assert.equal(result,actual<limit);if(result){assert(points.every(p=>plane.distanceToPoint(p)<0));separated++;}
 }});
test('same conservative numerical fringe retains grazing oriented boxes',()=>{for(let i=0;i<300;i++){
 const box=new T.Box3(new T.Vector3(-1,-2,-3),new T.Vector3(2,3,4)),m=new T.Matrix4().makeRotationY(rand()*Math.PI);m.setPosition(12,-8,-20);
 const n=new T.Vector3(rand()-.5,rand()-.5,rand()-.5).normalize(),plane=new T.Plane(n,0),points=[];
 for(const x of[-1,2])for(const y of[-2,3])for(const z of[-3,4])points.push(new T.Vector3(x,y,z).applyMatrix4(m));
 const max=Math.max(...points.map(p=>n.dot(p))),fringe=.001;plane.constant=-max-fringe*.5;
 assert.equal(next.affineBoxOutside({planes:[plane]},box,m,fringe),false);
 }});
test('nonfinite support arithmetic fails open',()=>{const box=new T.Box3(new T.Vector3(-1,-1,-1),new T.Vector3(1,1,1));assert.equal(next.affineBoxOutside({planes:[new T.Plane(new T.Vector3(1,1,1),0)]},box,new T.Matrix4().multiplyScalar(NaN),.001),false);});
fs.writeFileSync(new URL('oriented-controls.json',here),JSON.stringify({status:'PASS_CONTINGENCY_CPU_ONLY',checks,random_affine_controls:2000,grazing_controls:300,independently_separated_boxes:separated,limits:'No actual scene budget saving, browser/GPU/shadow pixels or need established. Existing47 native controls run separately.'},null,2)+'\n');console.log('PASS '+checks.length+' additional controls');
