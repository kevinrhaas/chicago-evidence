# Minimal affine-box support candidate — UNAPPLIED / actual saving UNMEASURED

Actual new-base entry probe now fails at4,666,158 triangles,66,158 above the unchanged4.6M cap, while calls5097 are within7800. Root's original actual failure remains authoritative. This candidate has **no measured scene saving** and may save too little or nothing; the small building yaw limits expected opportunity. No caps, camera, tier, source geometry, asset, material, picking, transparency or default partition setting changes are proposed.

## One tracked path

Only `renderers/web/js/batch-frustum-box.js`. `buildings.js` is a copied read-only test fixture, not an authored change.

The existing helper asks the cached box of actual stored geometry, transforms it through the current instance matrix, and then constructs a looser batch-frame axis-aligned box. Keep that exact existing AABB test and numerical fringe, then test the same original box's affine image by plane support. This is simpler than a new45-degree vertex-bound cache: no geometry scan, no new bounds metadata or invalidation framework, and no per-frame vertex work.

For a batch-frame plane `(n,d)`, current instance transform `x=A*p+t` and local source box `[L,U]`, define `c=A^T*n`. The exact maximum signed plane value over the affine box is:

`s = n·t + d + Σ c_i * (c_i >= 0 ? U_i : L_i)`.

Reject only when `s < -fringe*||n||_1`. This uses the same batch-axis numerical expansion as the old AABB test. The affine box contains every source vertex and every linear triangle between them; if its maximum is negative beyond that unchanged fringe, no point of it crosses that plane. Negative scales, rotations and shear are handled by the current matrix directly. No decomposition or assumed orthogonal basis is used. Nonfinite support arithmetic fails open.

All existing source-material/hook, position/index identity/epoch/format, morph, camera/depth convention, full-range/unknown-entry, finite affine transform, shadow, picking and transparent-batch guards remain unchanged. Retained list order, geometry/index/instance arrays, visibility and existing coalescing remain unchanged. Only prepared lists of the already eligible Full rigid opaque path can lose a provably outside entry. Light/Balanced and other ineligible defaults remain unchanged. Existing `boxRejected` counts both phases; optional diagnostic `orientedBoxRejected` counts only supplemental rejections.

Cost is up to6 additional small plane-support evaluations for an entry that survives the existing AABB test. One reusable Box3 copy is kept by the closure; there is no per-instance vertex/array allocation or cache. That CPU cost remains an actual device risk and is not qualified by this proof.

## CPU evidence

-All47 existing actual vendored Three/coalescer controls PASS against the candidate, including normalized Int16/dequantization, source byte identity, current matrices, source/transparent/shadow/pick/unknown fail-open conditions, four coordinate/depth conventions and100 seeded transformed actual-vertex separation controls.
-Six additional controls PASS: an actual native rotated20m thin primitive retained by the old world-AABB is correctly rejected by the affine box; crossing primitives stay; source/index/matrix/visibility exact;2,000 seeded affine/reflection/shear supports equal independently transformed eight-corner maxima;300 fringe/grazing cases retained; nonfinite support fails open.
-The first attempted47-control run lacked the copied `buildings.candidate.js` integration fixture; its missing-file transcript is retained. Copying the unchanged actual source resolved that fixture issue; no production/test assertion changed. This was not an actual scene-budget run.

`source-guard.json` pins exact old/new helper bytes. `apply-guard.py <exact-target-file>` checks hashes read-only by default; only root should add `--apply` after review. Unknown preimages refuse. No canonical path was written. Syntax, all53 CPU controls and read-only guard pass.

## Owed next decision

Root may adopt for one bounded actual identical1904Full arrival/spawn comparison and the existing relevant supplemental checks. Require the real cap to pass unchanged and retain every raw failure/counter. Read the supplemental rejection counter without treating it as a measured saving until the complete native renderer counters are captured. If saving is inadequate or cost/content/shadow/picking regresses, reject/revert this exact candidate. Do not chain unreviewed cull/cache/partition changes, loosen fringe/caps or alter the pose.

No Blender/browser/full gate/native writer/publication/image/contact acceptance occurred here. Human fixture diagnosis is resolved separately by H7's supported-host evidence; no fixture change is part of this candidate.
