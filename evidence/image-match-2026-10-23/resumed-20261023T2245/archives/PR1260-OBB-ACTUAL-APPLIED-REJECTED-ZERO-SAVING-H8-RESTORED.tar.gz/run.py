from pathlib import Path
import subprocess,json,os,datetime,hashlib,shutil
r=Path('/tmp/chicago-log-integration/chicago/4d');o=Path(__file__).resolve().parent;p=Path('/tmp/PR1260-oriented-box-contingency');target=r/'renderers/web/js/batch-frustum-box.js';guard=json.loads((p/'source-guard.json').read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env={**os.environ,'TMPDIR':'/workspace/tmp-t3081','PW_EXECUTABLE':'/usr/bin/chromium'};s={'status':'RUNNING','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'stages':[]};save=lambda:(o/'STATE.json').write_text(json.dumps(s,indent=2)+'\n');save()
def stage(name,cmd):
 row={'name':name,'command':cmd};s['stages'].append(row);save()
 with(o/(name+'.log')).open('x')as f:code=subprocess.call(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 row['exit']=code;save();return code
applied=False
try:
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r).strip();assert sha(target)==guard['before_sha256']
 helper=o/'helper';helper.mkdir()
 old=Path('/workspace/PR1260-dev38-1904-probe-v1-prepared-20261024')
 for n in ['run.py','bind.py','models.json','probe.mjs']:shutil.copy2(old/n,helper/n)
 q=helper/'probe.mjs';t=q.read_text();needle='detail:a.detail,';assert t.count(needle)==1;t=t.replace(needle,'detail:a.detail,cull_counts:{boxRejected:a.buildings.coalesce.boxRejected,orientedBoxRejected:a.buildings.coalesce.orientedBoxRejected},');q.write_text(t)
 assert stage('apply',['python3',str(p/'apply-guard.py'),str(target),'--apply'])==0;applied=True
 assert stage('publish',['bash','tools/publish.sh'])==0
 assert stage('mirror',['node','tools/check_published.mjs'])==0
 code=stage('actual',['python3',str(helper/'run.py'),'--app',str(r),'--out',str(o/'actual'),'--execute-after-root-grant'])
 assert code==0,'ActualcandidateFAIL; preserve and restore exactH8'
 s['status']='ACTUAL_PASS_PENDING_ROOT_REVIEW_NOT_FULL_STAGE14'
except BaseException as e:
 s.update(status='FAILED',error=str(e));save()
 if applied:
  assert sha(target)==guard['after_sha256'];assert sha(p/'before.js')==guard['before_sha256'];target.write_bytes((p/'before.js').read_bytes());s['exact_helper_reverted']=True;save()
  assert stage('restore-publish',['bash','tools/publish.sh'])==0
  assert stage('restore-mirror',['node','tools/check_published.mjs'])==0
  assert not subprocess.check_output(['git','status','--porcelain'],cwd=r).strip();s['status']='REJECTED_ACTUAL_FAIL_EXACT_H8_RESTORED'
finally:s['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(s))
