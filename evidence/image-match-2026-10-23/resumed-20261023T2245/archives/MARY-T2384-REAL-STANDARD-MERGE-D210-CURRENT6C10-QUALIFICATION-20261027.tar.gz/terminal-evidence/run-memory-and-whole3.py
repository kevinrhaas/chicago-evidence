from pathlib import Path
import subprocess,json,os,datetime
R=Path('/tmp/st-mary-picture-20261025');A=R/'chicago/4d';O=Path('/tmp/Mary1334-current6c10-ending-20261027T0020');os.sched_setaffinity(0,{0,1,3,4});env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(MARY_GATE_CPUS='0,1,3,4',MARY_GATE_JOBS='4',PW_EXECUTABLE='/usr/bin/chromium');steps=[]
for name,reaper,cmd in [('current1904phone','current-1904-phone-memory-reaper.json',['taskset','-c','0,1,3,4','node','tools/measure_memory.mjs','--gate','--year','1904','--only','mobile','--json',str(O/'current-1904-phone-memory.json')]),('currentwhole3','whole3-reaper.json',['python3',str(O/'run-current-whole3.py')])]:
 print('START',name,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
 with(O/(name+'-controller.log')).open('x')as log:p=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(O/reaper),'--',*cmd],cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT)
 r=json.loads((O/reaper).read_text());steps.append({'name':name,'exit':p.returncode,'reaper_command_exit':r['command_exit'],'all_children_reaped':r['all_children_reaped'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat()});(O/'PIPELINE-STEPS.json').write_text(json.dumps(steps,indent=2)+'\n');print('CLOSED',name,p.returncode,flush=True);assert p.returncode==0 and r['command_exit']==0 and r['all_children_reaped'],name
print('CURRENT6C10_PHONE_AND_WHOLE3_PASS',flush=True)
