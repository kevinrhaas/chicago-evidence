from pathlib import Path
import os,subprocess,json,datetime,time,hashlib,zipfile,gzip,io,xml.etree.ElementTree as ET,shutil
R=Path('/tmp/st-mary-picture-20261025');A=R/'chicago/4d';O=Path('/tmp/Mary1334-current6c10-ending-20261027T0020');incoming='6c103072dae94ed58cc8fc06462aef2638be736f';head='558462162c67537b97c0156c7df7bd89ad495b37';os.sched_setaffinity(0,{3});env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(PYTHONPATH='/workspace/shared/python',NODE_PATH='/workspace/shared/node/node_modules',PW_EXECUTABLE='/usr/bin/chromium',TMPDIR='/tmp/Mary1334-current6c10-native-tmp-20261027',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',CHECK_JOBS='1',C4D_RULINGS_BASE=incoming);Path(env['TMPDIR']).mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=R,env=env)
def save(name,value):(O/name).write_text(json.dumps(value,indent=2)+'\n')
def sha(data):return hashlib.sha256(data).hexdigest()
print('Current6c10 normal merge has ZERO conflicts; native --resolve will confirm actual minimum; package/publish/all44 then current gate, no blanket obsolete rederivation.',flush=True)
assert git('rev-parse','HEAD').decode().strip()==head;assert git('rev-parse','MERGE_HEAD').decode().strip()==incoming
assert shutil.disk_usage(env['TMPDIR']).free>=1800000000
protected=json.loads((O/'PROTECTED-AUTHORED-MODELS-BEFORE-NATIVE.json').read_text())
def check_protected():
 bad=[]
 for path,digest in protected.items():
  f=R/path;data=os.readlink(f).encode() if f.is_symlink() else f.read_bytes()
  if sha(data)!=digest:bad.append(path)
 assert not bad,bad
extra=json.loads((O/'OWN-EXTRA-PRAIRIE-BEFORE-NATIVE.json').read_text())
for p,h in extra.items():assert sha((R/p).read_bytes())==h,p
check_protected();steps=[]
def command(name,cmd):
 print('START',name,now(),flush=True)
 with(O/(name+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit':p.returncode,'closed_at':now()};steps.append(row);save('NATIVE-STEPS.json',steps);print('CLOSED',name,p.returncode,now(),flush=True);assert p.returncode==0,(name,p.returncode)
command('native-resolve',['node','tools/rederive.mjs','--resolve']);assert not git('diff','--name-only','--diff-filter=U').strip();check_protected()
def xlsx(data):
 with zipfile.ZipFile(io.BytesIO(data))as archive:
  result={}
  for name in archive.namelist():
   value=archive.read(name)
   if name.endswith(('.xml','.rels')):
    root=ET.fromstring(value)
    if name=='docProps/core.xml':
     for element in list(root):
      if element.tag=='{http://purl.org/dc/terms/}modified':root.remove(element)
    result[name]=ET.canonicalize(ET.tostring(root,encoding='unicode'))
   else:result[name]=value.hex()
  return result
rows=[];artifacts=json.loads((O/'ALL44-INCOMING-METADATA.json').read_text());known={row['path']for row in artifacts}
for row in artifacts:
 path=row['path'];f=R/path;actual=f.read_bytes();before=git('show',incoming+':'+path);equal=actual==before;kind='BYTE_EXACT'
 if not equal:
  raw=O/'raw-regenerated-artifacts'/path;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_bytes(actual)
  if path.endswith('.xlsx'):equal=xlsx(actual)==xlsx(before);kind='ALL_ZIP_MEMBERS_C14N_EXCEPT_CORE_MODIFIED'
  elif path.endswith('.gz'):
   equal=gzip.decompress(actual)==gzip.decompress(before);kind='GZIP_DECOMPRESSED_BYTES'
   if not equal:
    try:equal=json.loads(gzip.decompress(actual))==json.loads(gzip.decompress(before));kind='GZIP_JSON_ALL_FIELDS'
    except(ValueError,UnicodeError):pass
  if equal:f.write_bytes(before)
 rows.append({'path':path,'regenerated_sha256':sha(actual),'incoming_sha256':sha(before),'comparison':kind,'equal':equal,'restored_serialization_only':actual!=before and equal})
save('ALL44-NATIVE-AUDIT.json',rows);assert len(rows)==44 and all(row['equal']for row in rows)
changed=git('diff','--name-only',incoming).decode().splitlines();unexpected=[p for p in changed if (p.endswith(('.xlsx','.gz'))or not p.startswith('chicago/4d/'))and p not in known and p not in extra];assert not unexpected,unexpected
for p,h in extra.items():assert sha((R/p).read_bytes())==h,p
command('native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']);command('native-publish',['bash','tools/publish.sh']);check_protected();assert not git('diff','--name-only','--diff-filter=U').strip()
result={'at':now(),'status':'MARY_CURRENT6C10_ZERO_CONFLICT_RESOLVE_PACKAGE_PUBLISH_ALL44_PASS','head':head,'incoming':incoming,'cpu_affinity':[3],'protected_paths_exact':len(protected),'all44_audited':True,'steps':steps,'optional_sill_API_not_adopted':True,'current6c10_full3_pending':True,'dated776_both_app_and_CI_PASS_not_relabelled':True,'operational_startup_bytes':1800000000,'serialized_one_copy_heavy_native':True};save('NATIVE-RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
