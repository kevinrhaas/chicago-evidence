from pathlib import Path
import subprocess,json,datetime,time,os
R=Path('/tmp/st-mary-picture-20261025');A=R/'chicago/4d';B=Path('/tmp/Mary1334-current6c10-ending-20261027T0020');O=B/'qualified-public-merge';O.mkdir();base='6c103072dae94ed58cc8fc06462aef2638be736f';prior='558462162c67537b97c0156c7df7bd89ad495b37';public='776716a356cdb00dfd1083e45b5bc6cf560f2bf9';branch='steward/t2384-st-mary-picture';claim='bb60d945d97cb4b566d60323f78f44e08e682782';env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env['C4D_RULINGS_BASE']=base

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R,env=env).decode().strip()
def api(p,body=None,method=None):
 c=['gh','api','repos/kevinrhaas/chicago/'+p,'-H','Cache-Control: no-cache'];inp=None
 if method:c+=['--method',method]
 if body is not None:c+=['--input','-'];inp=json.dumps(body).encode()
 raw=subprocess.check_output(c,cwd=R,env=env,input=inp);return json.loads(raw)if raw.strip()else None
def command(n,cmd,cwd=A):
 print('START',n,now(),flush=True)
 with(O/(n+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert p.returncode==0,(n,p.returncode)

f=json.loads((B/'FROZEN-CANDIDATE.json').read_text());gate=json.loads((B/'whole3/RESULT.json').read_text());reap=json.loads((B/'whole3-reaper.json').read_text());mem=json.loads((B/'current-1904-phone-memory-reaper.json').read_text());scope=json.loads((B/'EXACT-776-BOTH-APP-CONSUMER-SCOPE.json').read_text());oldapp=Path('/tmp/Mary1334-currentdev-ending-20261026T2110/image-card');app=json.loads((oldapp/'CURRENT-APP-RESULT.json').read_text());ar=json.loads((oldapp/'current-app-v2-reaper.json').read_text())
assert gate['status']=='CURRENT_WHOLE3_PASS'and gate['candidate_frozen']and gate['candidate_tree']==f['candidate_tree'];assert reap['command_exit']==0 and reap['all_children_reaped'];assert mem['command_exit']==0 and mem['all_children_reaped'];assert app['status']=='CURRENT_PUBLIC776_PUBLISHED_BOTH_VIEWPORTS_TARGET_APP_PASS'and ar['command_exit']==0 and ar['all_children_reaped'];assert scope['current_tree']==f['candidate_tree']and scope['all_active_physical_record_sidecar_MASTER_WEB_paths_exact']==2742
assert git('write-tree')==f['candidate_tree']and not git('diff','--name-only');assert git('rev-parse','HEAD')==prior and git('rev-parse','MERGE_HEAD')==base
pr=api('pulls/1334');save('PR-before.json',pr);assert pr['state']=='open'and pr['head']['sha']==public and pr['head']['ref']==branch;assert 'hold'not in [x['name']for x in pr['labels']];assert api('git/ref/heads/lap/pr-1334')['object']['sha']==claim;assert api('git/ref/heads/dev')['object']['sha']==base,'REAL_NEW_DEV_CHANGED_INSPECT_NO_RELABEL'
command('normal-current-codecommit',['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m',"T-2384: keep the checked chapel picture current with dev"],R);head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');assert tree==f['candidate_tree'];assert git('show','-s','--format=%P','HEAD')==prior+' '+base
for n,c in [('committed-changelog',['node','tools/check-changelog-entry.mjs',base,'HEAD']),('committed-ids',['node','tools/resolve_id_collisions.mjs','--base',base,'--check']),('committed-native-history',['node','tools/check-changelog.mjs'])]:command(n,c)
assert not git('status','--porcelain');native=json.loads(subprocess.check_output(['node','tools/dev-smoke-state.mjs','hash','--json'],cwd=A,env=env));assert native['dirty']is False;save('CLEAN-CURRENT-COMMITTED.json',{'at':now(),'head':head,'tree':tree,'native':native,'parents':[prior,base],'full3_and_current_phone_and_exact_both_app_consumers_PASS':True})
assert api('pulls/1334')['head']['sha']==public;assert api('git/ref/heads/dev')['object']['sha']==base;command('normal-expected-public-FF',['git','-c','gc.auto=0','-c','maintenance.auto=false','push','origin','HEAD:refs/heads/'+branch],R)
converged=False
for i in range(20):
 br=api('git/ref/heads/'+branch)['object']['sha'];p=api('pulls/1334');assert br in[public,head]and p['head']['sha']in[public,head],'FOREIGN_HEAD_STOP_NO_FORCE'
 if br==head and p['head']['sha']==head:converged=True;break
 time.sleep(.5)
assert converged,'PUSH_DONE_METADATA_READBACK_PENDING_NO_RECOMMIT_OR_REPUSH';save('CURRENT-PUBLIC-HEAD-EXACT.json',{'at':now(),'head':head,'tree':tree,'normal_FF_from':public})
body="""St Mary's gains its pictured open belfry/cross, five long-wall sash, far-end door and chimney, and lower body roof. These are reconstructed for1835 from the undated Moss engraving, retaining the original footprint, position, body height and dates. Its Images card displays the credited public-domain engraving once; the provisional camera offers no invented historical “From this spot.”

Original T-2384 remains **OPEN/DIFFERS** for the noticeable sash-height gap. The optional sill API/family rebake is not adopted and no photo follow-up is filed. Publication1884 is verified; the depicted year is not.

This revision normally incorporates actual current dev6c10, including the incoming conservatory and Doane changes. Current native whole3 passed1077steps/388self-tests; committed changelog/IDs/history and clean native source hash passed. The unchanged400MiB1904phone memory gate passed384.3MiB on the actual newDoane inputs. All44 binary artifacts after package/publish and all4463 protected authored/model inputs passed. The clean merge needed no conflict rebuild; the actual native liberties check confirmed796 matching records.

The genuine same-camera comparison remainsDIFFERS. Actual published phone and desktop app reviews on checked776 both passed normal/ByGrade, target WEB hash, grounding, Sources, the single visible loaded credited image, and zero page/network errors. Their precise scope is retained: all2742 active1835 physical/record/sidecar/model paths, sceneindex, all renderer code/styles except canonical changelog, Moss camera/match/source and four Prairie image inputs are byte-exact in this revision. No current whole18 or global-equality claim is made.

Image-store [PR6](https://github.com/kevinrhaas/chicago-images/pull/6) is merged and both public JPEGs are strict-HTTPS/hash-exact. Dated776 native CI and allnine frame/memoryjobs passed; desktop still-frame measurements had no runner calibration and are not called held. New advisory CI is not relabelled as passed. A standard expected-head merge commit preserves the actual checked 776/558/final ancestry for the stacked Wolf Point and Carpenter work while producing this exact checked tree. The repository permits merge commits; workflows, configuration and protections are unchanged, and no admin or force bypass is used.
"""
for a,b in {'for1835':'for 1835','Publication1884':'Publication 1884','dev6c10':'dev 6c10','passed1077steps/388self-tests':'passed 1,077 steps, including 388 self-tests','unchanged400MiB1904phone':'unchanged 400 MiB 1904 phone','passed384.3MiB':'passed 384.3 MiB','newDoane':'new Doane','All44':'All 44','all4463':'all 4,463','confirmed796':'confirmed 796','remainsDIFFERS':'remains DIFFERS','checked776':'checked 776','all2742 active1835':'all 2,742 active 1835','sceneindex':'scene index','whole18':'whole 18','PR6':'PR 6','Dated776':'Dated 776','allnine':'all nine','memoryjobs':'memory jobs'}.items():body=body.replace(a,b)
(O/'PR-final-body.md').write_text(body);api('pulls/1334',{'body':body},'PATCH');p=api('pulls/1334');assert p['head']['sha']==head
if p['draft']:
 req={'query':'mutation($id:ID!){markPullRequestReadyForReview(input:{pullRequestId:$id}){pullRequest{id isDraft}}}','variables':{'id':p['node_id']}};save('READY-request.json',req);v=json.loads(subprocess.check_output(['gh','api','graphql','--input',str(O/'READY-request.json')],cwd=R,env=env));save('READY-response.json',v);assert v['data']['markPullRequestReadyForReview']['pullRequest']['isDraft']is False
for label in ['resume','stuck']:
 if label in[x['name']for x in p['labels']]:api('issues/1334/labels/'+label,method='DELETE')
assert api('git/ref/heads/dev')['object']['sha']==base,'REAL_NEW_DEV_CHANGED_BEFORE_MERGE_INSPECT';assert api('git/ref/heads/lap/pr-1334')['object']['sha']==claim;p=api('pulls/1334');assert p['head']['sha']==head and p['state']=='open'and not p['draft']and 'hold'not in[x['name']for x in p['labels']];save('PR-qualified-premerge.json',p)
request={'sha':head,'merge_method':'merge','commit_title':p['title']+' (#1334)'};save('MERGE-request.json',request);c=['gh','api','repos/kevinrhaas/chicago/pulls/1334/merge','--method','PUT','--input',str(O/'MERGE-request.json')];z=subprocess.run(c,cwd=R,env=env,stdout=(O/'MERGE-response.stdout').open('w'),stderr=(O/'MERGE-response.stderr').open('w'));assert z.returncode==0,'STANDARD_MERGE_REFUSED_RETAIN_REASON_NO_ADMIN_FORCE';m=json.loads((O/'MERGE-response.stdout').read_text());save('MERGE-response.json',m);assert m['merged']is True;msha=m['sha'];commit=api('git/commits/'+msha);save('MERGE-immutable-commit.json',commit);assert commit['tree']['sha']==tree and[x['sha']for x in commit['parents']]==[base,head]
merged=False
for i in range(20):
 p=api('pulls/1334')
 if p['merged']and p['state']=='closed':merged=True;break
 time.sleep(.5)
assert merged,'AUTHORITATIVE_MERGE_TRUE_PR_READBACK_PENDING';save('PR-MERGED.json',p)
command('normal-own-lap-release-after-merge',['node','tools/ticket.mjs','lap','1334','--release']);save('RESULT.json',{'at':now(),'status':'CURRENT6C10_QUALIFIED_PR1334_STANDARD_EXPECTED_HEAD_MERGE_COMMIT_DEV','head':head,'tree':tree,'prior_dev':base,'merge_sha':msha,'current_local_native1077_388_and_phone384_3of400_PASS':True,'both_actual_published_app_precise_consumer_scope_retained':True,'original_T2384_OPEN_DIFFERS_sash_gap':True,'no_admin_force_or_pending_status_forgery':True,'own_lap_normally_released_after_verified_merge':True,'standard_merge_commit_parents_preserve_checked776_558_and_current_author_ancestry':[base,head]});print(json.dumps(json.loads((O/'RESULT.json').read_text()),indent=2),flush=True)
