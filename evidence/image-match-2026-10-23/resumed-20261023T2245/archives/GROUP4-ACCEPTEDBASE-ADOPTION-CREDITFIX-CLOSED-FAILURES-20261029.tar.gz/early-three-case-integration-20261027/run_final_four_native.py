"""Actual current-base group closure. Each invocation is a separately leased stage.

Does not fetch, retire caches, commit, or claim a gate that it did not execute.
"""
from pathlib import Path
import argparse,datetime,gzip,hashlib,io,json,os,shutil,subprocess,sys,time,zipfile,xml.etree.ElementTree as ET
R=Path('/workspace/chicago'); A=R/'chicago/4d'
p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['snapshot','early-capacity','glessner','images','tail','package-publish','audit']);p.add_argument('--out',required=True,type=Path);p.add_argument('--accepted-base',required=True);p.add_argument('--cpus',default='3,4');p.add_argument('--attempt',default='',help='Consciously named new native attempt; preserve all prior logs.');args=p.parse_args();O=args.out
assert os.environ.get('EARLY_GROUP_NATIVE_LEASE')=='sole-coordinated-current-native'
assert os.environ.get('EARLY_GROUP_ACCEPTED_PREDECESSOR')=='actual-qualified-TGT-merge-verified'
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',NPM_CONFIG_PREFIX='/tmp/early-four-runtime-prefix',PW_EXECUTABLE='/usr/bin/chromium')
for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR']:E.pop(k,None)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,d):(O/name).write_text(json.dumps(d,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R,env=E).decode().strip()
assert git('rev-parse','HEAD')==args.accepted_base
assert not git('ls-files','-u')
def run(name,cmd,cwd=A,allow_failure=False):
 name+=('-'+args.attempt)if args.attempt else''
 log=O/(name+'.log');receipt=O/(name+'-reaper.json');assert not log.exists()and not receipt.exists()
 command=['python3','/workspace/shared/run-with-reaping.py',str(receipt),'--','taskset','-c',args.cpus,*cmd];t=time.monotonic()
 with log.open('x')as f:q=subprocess.run(command,cwd=cwd,env=E,stdout=f,stderr=subprocess.STDOUT)
 reaper=json.loads(receipt.read_text());row={'at':now(),'command':command,'cwd':str(cwd),'exit':q.returncode,'seconds':round(time.monotonic()-t,3),'all_children_reaped':reaper.get('all_children_reaped')};save(name+'-result.json',row);print(json.dumps(row),flush=True)
 assert reaper.get('all_children_reaped')and reaper.get('command_exit')==q.returncode,row
 assert allow_failure or q.returncode==0,row
 return q.returncode
def protected():
 b=json.loads((O/'BASELINE.json').read_text());bad=[rel for rel,h in b['physical_inputs_and_outputs'].items()if sha(R/rel)!=h];assert not bad,bad
def unique(pairs):
 d={}
 for k,v in pairs:assert k not in d,k;d[k]=v
 return d
def canonical_json(raw):return json.dumps(json.loads(raw,object_pairs_hook=unique),sort_keys=True,separators=(',',':'))
def workbook(raw):
 with zipfile.ZipFile(io.BytesIO(raw))as z:
  names=z.namelist();assert len(names)==len(set(names));d={}
  for name in names:
   raw=z.read(name)
   if name.endswith(('.xml','.rels')):
    root=ET.fromstring(raw)
    if name=='docProps/core.xml':
     for c in list(root):
      if c.tag=='{http://purl.org/dc/terms/}modified':root.remove(c)
    raw=ET.canonicalize(ET.tostring(root,encoding='unicode'),rewrite_prefixes=True)
   d[name]=raw
  return d
def audit(label):
 b=json.loads((O/'BASELINE.json').read_text());rows=[]
 for rel in b['all44']:
  f=R/rel;before=(O/'before'/rel).read_bytes();actual=f.read_bytes();same=before==actual;equal=same;method='EXACT_BYTES'
  if not same:
   raw=O/('raw-native-'+label)/rel;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_bytes(actual)
   if rel.endswith('.gz'):
    x,y=gzip.decompress(actual),gzip.decompress(before);equal=x==y;method='GZIP_DECOMPRESSED_EXACT_BYTES'
    if not equal:
     try:equal=canonical_json(x)==canonical_json(y);method='DUPLICATE_FREE_JSON_ALL_VALUES_TYPES_AND_ARRAY_ORDER'
     except(ValueError,UnicodeError,AssertionError):pass
   elif rel.endswith('.xlsx'):equal=workbook(actual)==workbook(before);method='EVERY_MEMBER_EXACT_OR_CANONICAL_XML_EXCEPT_CORE_MODIFIED'
   if equal:f.write_bytes(before)
  rows.append({'path':rel,'before_sha256':hashlib.sha256(before).hexdigest(),'native_sha256':hashlib.sha256(actual).hexdigest(),'equal':equal,'method':method,'serialization_only_restored':not same and equal})
 save('ALL44-'+label+'.json',{'at':now(),'all44_compared':len(rows)==44,'rows':rows,'real_content_changes_retained_for_review':[x['path']for x in rows if not x['equal']]})
 assert len(rows)==44
if args.stage=='snapshot':
 assert not O.exists();O.mkdir(parents=True)
 receipt=json.loads(Path('/tmp/early-four-final-wing-production-20261029/RESULT.json').read_text());assert len(receipt['proof'])==353
 physical={}
 for x in receipt['proof']:
  for kind,key in [('gltf','MASTER_sha256'),('web','WEB_sha256')]:
   rel='chicago/4d/assets/'+kind+'/'+x['name'];assert sha(R/rel)==x[key];physical[rel]=x[key]
 for rel in ['generators/archetypes/'+n+'.py'for n in ['log_dwelling','log_dwelling_params','frame_dwelling','frame_dwelling_params']]+['data/structures/'+s+'.json'for s in ['miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832']]:physical['chicago/4d/'+rel]=sha(A/rel)
 all44=git('ls-files','*.xlsx','*.gz').splitlines();assert len(all44)==44
 for rel in all44:
  dest=O/'before'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,dest)
 save('BASELINE.json',{'at':now(),'accepted_base':args.accepted_base,'actual_branch':git('branch','--show-current'),'all44':all44,'physical_inputs_and_outputs':physical,'status':'CURRENT_ACCEPTED_BASELINE_ONLY_NO_GLOBAL_GATE'})
else:
 assert O.is_dir();protected()
 if args.stage=='early-capacity':
  for name in ['build_lodging_model_1835','seat_lodgers_1835','build_staffing_model_1835','compile_businesses']:
   if run(name+'-initial-check',['python3','tools/'+name+'.py','--check'],allow_failure=True):
    run(name+'-native-build',['python3','tools/'+name+'.py','--build']);run(name+'-final-check',['python3','tools/'+name+'.py','--check'])
 elif args.stage=='glessner':
  sys.path.insert(0,str(A/'tools'));import recover_glessner_v4 as recovery
  manifest=json.loads((recovery.RECOVERY/'manifest.json').read_text());targets=recovery.targets();assert set(manifest['files'])==set(targets),'Inspect broader archive before restoring'
  prior=[]
  for rel in targets:
   f=A/rel
   if f.exists():
    dest=Path(os.environ.get('EARLY_GROUP_GLESSNER_BACKUP','/workspace/early-four-glessner-prior-20261029'))/rel;dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();assert f.stat().st_dev==dest.parent.stat().st_dev;os.link(f,dest);prior.append({'path':rel,'before_sha256':sha(f),'backup':str(dest)})
  save('GLESSNER-PRIOR.json',prior);run('native-glessner-current-restore',['python3','tools/recover_glessner_v4.py','--restore']);run('native-glessner-current-check',['python3','tools/recover_glessner_v4.py','--check'])
 elif args.stage=='images':
  store=R/'../chicago-images/prairie-1904/files';stage=Path(os.environ.get('EARLY_GROUP_IMAGE_STAGE','/workspace/early-four-native-image-stage-20261029/files'));assert not stage.exists();stage.mkdir(parents=True);assert store.stat().st_dev==stage.stat().st_dev;expected=json.loads((A.parent/'prairie_1904_v1/research/images/STORE.json').read_text())['files']
  for name,entry in expected.items():
   src=store/name;assert src.is_file()and src.stat().st_size==entry['bytes']and sha(src)==entry['sha256'],name;os.link(src,stage/name)
  E['PRAIRIE_IMAGE_STORE']=str(stage)
  run('native-image-store-sync',['python3','tools/sync_image_store.py'],cwd=A.parent/'prairie_1904_v1');run('native-image-store-check',['python3','tools/sync_image_store.py','--check'],cwd=A.parent/'prairie_1904_v1')
  run('native-images-build',['python3','tools/build_images.py'],cwd=A.parent/'prairie_1904_v1');run('native-images-check',['python3','tools/build_images.py','--check'],cwd=A.parent/'prairie_1904_v1')
 elif args.stage=='tail':
  scratch=Path(E.get('TMPDIR','/tmp'));free=shutil.disk_usage(scratch).free;assert free>=1800000000,('Native1.509GB scratch/writers need current callerfloor',scratch,free)
  run('native-compile-liberties-owning-tail',['node','tools/rederive.mjs','--tail','tools/compile_liberties.py']);audit('after-owning-tail')
 elif args.stage=='package-publish':
  run('native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']);audit('after-package5');run('native-current-publish',['bash','tools/publish.sh'])
 else:audit('manual-review')
 protected();save('STAGE-'+args.stage+('-'+args.attempt if args.attempt else'')+'.json',{'at':now(),'status':'PASS_ACTUAL_STAGE','stage':args.stage,'accepted_base':args.accepted_base,'physical_inputs_and_706_model_files_exact':True,'whole_gate_and_apps_PR_merge_not_claimed':True})
