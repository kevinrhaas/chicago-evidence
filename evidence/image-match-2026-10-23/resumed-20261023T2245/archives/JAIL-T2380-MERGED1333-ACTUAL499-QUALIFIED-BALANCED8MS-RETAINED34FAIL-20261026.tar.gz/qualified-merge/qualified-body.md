Adds the log jail’s pointed plank palisade, with its entrance passage aligned to the native jail door. Gale’s retrospective description supports the enclosure; its dimensions and layout are reconstructed. The original T-2380 picture match remains OPEN/DIFFERS because the keeper house, full compound and conflicting roof depictions remain unresolved.

The current-dev ending also repairs the 1904 phone memory failure. Light’s existing mip policy now reaches initial and reloaded GLB textures. Transient scalar readers release their source context, and far rail sections are built inside their existing drawing reach and disposed outside it. Native rail geometry, visibility and measured GPU allocations stay exact. Light deliberately reduces fine texture detail, as recorded in the liberty.

Checked head: `bbbe518720601b785e79628bf247ee4b9f9d4ed8` (tree `897824de45d16cd90fe2400cd3b8aace341d42ea`), integrated with dev `ecfff9f56ce359b70aa520e97d1923c12a6dafb2`.

- Final native preflight: **1,077 steps / 388 self-tests PASS**, plus changelog, IDs, committed history and a clean native input hash.
- Actual phone memory: **384.0 / 400 MiB PASS**. Deferred rails release exactly **12,183,792 CPU bytes** at spawn; actual GPU buffer and texture bytes remain exact. The earlier hosted **403.3 / 400 FAIL** and insufficient static-array experiment are retained.
- Actual published phone walking, delayed upload, leaving/returning, rail picking and Full→Light passed. Five held native baseline/candidate frames have identical visible rail geometry and **zero differing pixels**, with positive street controls. Page/network/console error lists are empty. An extra first-pose raw GL1281 diagnostic occurs in both the frozen baseline and candidate and remains qualified.
- Current hosted native gate, all six memory readings, both still frames and the memory self-test PASS. The moving workflow has one retained Balanced-flight failure (34.2 > 32 ms); its other 11 readings passed. One unchanged current published Balanced-tier foreground run, with all four moves and verification, PASS: flight worst8.3/p951.6ms. This is explicit same-source scoped qualification; the failed workflow remains a failure.
- Published coverage uses the actual b3fb groups **1–2, 3–4, 12, 13, 14, 15 in both viewports**. All twelve groups reached positive SMOKE PASS, zero failures and zero page errors; dated actual 8cd parts 5–11 are supported by the complete active-input and consumer-impact proof. Neither 1835 nor 1812 consumes the changed rail layer. This is not a current whole-18 or global-hash-equality claim.

Recovery, exact frozen patch, readings and comparison evidence: https://github.com/kevinrhaas/chicago-evidence/blob/a06c32c477cc1ca8252088973eefeae27d7f1d12/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md

The declared ending is qualified by the actual results above. The original image ticket stays open; this is the normal checked-SHA squash merge to dev, with production untouched.
