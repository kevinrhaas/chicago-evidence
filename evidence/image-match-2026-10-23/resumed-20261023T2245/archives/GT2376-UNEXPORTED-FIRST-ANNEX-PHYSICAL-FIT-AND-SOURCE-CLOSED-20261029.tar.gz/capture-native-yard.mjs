import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import crypto from 'node:crypto';
const root='/tmp/chicago-green-tree-integration/chicago/4d';
const out='/workspace/T2376-annex-20261029';
const THREE=await import(pathToFileURL(path.join(root,'renderers/web/vendor/three-0.185.1/three.module.js')));
const compact=await import(pathToFileURL(path.join(root,'renderers/web/js/compact-streams.js')));
const source=fs.readFileSync(path.join(root,'renderers/web/js/yard.js'),'utf8');
const stripped=source.replace(/^import[^;]+;\n/gm,'').replace(/^export /gm,'');
const native=new Function('THREE','compactStreams','COLOR_LANE_CONFIDENCE',stripped+'\nreturn {buildShed,buildWagon,readForm};')(THREE,compact.compactStreams,compact.COLOR_LANE_CONFIDENCE);
const record=JSON.parse(fs.readFileSync(path.join(root,'data/yard/town_trade_goods.json')));
const sc=JSON.parse(fs.readFileSync(path.join(root,'data/sidecars/1835/green_tree_tavern.json')));
const meta=JSON.parse(fs.readFileSync(path.join(root,'data/terrain/epochs/e1834_harbor_cut/heightfield.json')));
const raw=fs.readFileSync(path.join(root,'data/terrain/epochs/e1834_harbor_cut',meta.bin));
const H=(e,n)=>{
 const x=Math.max(0,Math.min(meta.cols-1,(e-meta.origin_e)/meta.cell_m));const y=Math.max(0,Math.min(meta.rows-1,(n-meta.origin_n)/meta.cell_m));
 const ix=Math.floor(x),iy=Math.floor(y),tx=x-ix,ty=y-iy;
 const at=(a,b)=>raw.readInt16LE(2*(b*meta.cols+a))*meta.scale+meta.offset;
 return (at(ix,iy)*(1-tx)+at(Math.min(ix+1,meta.cols-1),iy)*tx)*(1-ty)+(at(ix,Math.min(iy+1,meta.rows-1))*(1-tx)+at(Math.min(ix+1,meta.cols-1),Math.min(iy+1,meta.rows-1))*tx)*ty;
};
const form=native.readForm(record), terrain={surfaceHeight:H};
const lists=Object.values(record).filter(Array.isArray).flat();
const objects=[];
for(const id of ['green_tree_tavern_wagon_shed','green_tree_tavern_shed_wagon']){
 const item=lists.find(x=>x?.id===id);if(!item)throw Error('missing '+id);
 const timber=[.4,.3,.2],canvas=[.7,.7,.6];
 const buf={pos:[],nrm:[],conf:[],col:[],uv:[],uv1:[],tint:timber,timber,canvas,iron:[.1,.1,.1],blank:[0,0],grainOn:false};
 const problems=[];const ok=(id.endsWith('wagon_shed')?native.buildShed:native.buildWagon)(buf,item,form,terrain,1,problems);
 if(!ok||problems.length||buf.pos.some(v=>!Number.isFinite(v)))throw Error(JSON.stringify({id,problems,ok}));
 const vertices=[];const e=sc.placement.local_e,n=sc.placement.local_n,th=sc.placement.rotation_deg*Math.PI/180,cs=Math.cos(th),sn=Math.sin(th);
 for(let i=0;i<buf.pos.length;i+=3){const de=buf.pos[i]-e,dn=-buf.pos[i+2]-n;vertices.push([de*cs-dn*sn,de*sn+dn*cs,buf.pos[i+1]]);}
 objects.push({id,triangles:vertices.length/3,item,vertices,bounds:[0,1,2].map(k=>[Math.min(...vertices.map(p=>p[k])),Math.max(...vertices.map(p=>p[k]))])});
}
const result={status:'ACTUAL_NATIVE_YARD_FUNCTIONS_FULL_FLOAT_VERTICES_CAPTURED_NO_BROWSER',at:new Date().toISOString(),yard_source_sha256:crypto.createHash('sha256').update(source).digest('hex'),record_sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'data/yard/town_trade_goods.json'))).digest('hex'),placement:{e:sc.placement.local_e,n:sc.placement.local_n,rotation:sc.placement.rotation_deg},scope:'NativeyardbuildShed/buildWagonandhelpersunmodifiedexecutedinNode;onlymoduleimports/exportsremovedtoexposetheprivatefunctions. Realcommittedbilinearheightfield;noGLB/browser/quantizedpositions/appclaim.',objects};
fs.writeFileSync(path.join(out,'ACTUAL-NATIVE-YARD-FULL-VERTICES.json'),JSON.stringify(result));
console.log(JSON.stringify({...result,objects:objects.map(({vertices,...x})=>x)}));
