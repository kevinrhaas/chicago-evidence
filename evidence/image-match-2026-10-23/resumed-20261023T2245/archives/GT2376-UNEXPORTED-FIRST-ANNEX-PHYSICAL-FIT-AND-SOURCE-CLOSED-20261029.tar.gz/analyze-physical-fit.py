from pathlib import Path
import sys,types,json,math,hashlib,array,datetime
r=Path('/tmp/chicago-green-tree-integration/chicago/4d');h=Path('/workspace/T2376-annex-20261029');sys.path.insert(0,str(r/'generators'));sys.modules['bpy']=types.ModuleType('bpy')
from common import mesh
mesh.MeshBuilder.to_object=lambda self,mats=None:{'verts':self.verts,'faces':self.faces}
mesh.simple_material=lambda *a,**kw:None
from archetypes.frame_tavern_params import from_phase
from archetypes.frame_tavern import build
j=json.loads((r/'data/structures/versions/green_tree_tavern/andreas-reading.json').read_text());p=from_phase(j['phases'][0],j);obj=build(p,'green_tree_tavern__frame_1833');g=p.enclosed_left_annex
sc=json.loads((r/'data/sidecars/1835/green_tree_tavern.json').read_text());place=sc['placement'];th=math.radians(place['rotation_deg']);cs,sn=math.cos(th),math.sin(th)
def world(u,v):return place['local_e']+u*cs+v*sn,place['local_n']-u*sn+v*cs
meta=json.loads((r/'data/terrain/epochs/e1834_harbor_cut/heightfield.json').read_text());raw=array.array('h');raw.frombytes((r/'data/terrain/epochs/e1834_harbor_cut'/meta['bin']).read_bytes())
def H(e,n):
 x=max(0,min(meta['cols']-1,(e-meta['origin_e'])/meta['cell_m']));y=max(0,min(meta['rows']-1,(n-meta['origin_n'])/meta['cell_m']));a,b=math.floor(x),math.floor(y);tx,ty=x-a,y-b
 def at(i,k):return raw[k*meta['cols']+i]*meta['scale']+meta['offset']
 return (at(a,b)*(1-tx)+at(min(a+1,meta['cols']-1),b)*tx)*(1-ty)+(at(a,min(b+1,meta['rows']-1))*(1-tx)+at(min(a+1,meta['cols']-1),min(b+1,meta['rows']-1))*tx)*ty
feet={}
for f in obj['faces']:
 for a,b in zip(f,list(f[1:])+[f[0]]):
  a,b=obj['verts'][a],obj['verts'][b]
  if abs(a[2])>.05 or abs(b[2])>.05:continue
  steps=max(1,math.ceil(math.hypot(b[0]-a[0],b[1]-a[1])))
  for i in range(steps+1):
   u,v=a[0]+(b[0]-a[0])*i/steps,a[1]+(b[1]-a[1])*i/steps;feet.setdefault((math.floor(u/.5+.5),math.floor(-v/.5+.5)),(u,v))
heights=[H(*world(u,v))for u,v in feet.values()];base=min([H(*world(0,0)),*heights]);relief=max(heights)-base
yard=json.loads((h/'ACTUAL-NATIVE-YARD-FULL-VERTICES.json').read_text());shoulder=g['shoulder'];x0=p.width_m;x1=x0+shoulder['span_m'];v1=p.depth_m-g['front_setback_m'];v0=v1-shoulder['depth_m'];out=[]
for o in yard['objects']:
 margins=[]
 for u,v,z in o['vertices']:
  roof=base+shoulder['roof_high_m']+(u-x0)*(shoulder['roof_low_m']-shoulder['roof_high_m'])/(x1-x0)
  margins.append(min(u-x0,x1-u,v-v0,v1-v,z-base,roof-z))
 out.append({'id':o['id'],'vertices':len(margins),'all_vertices_inside_closed_convex_shoulder':min(margins)>=-1e-8,'minimum_margin_m':min(margins),'lowest_y':min(v[2]for v in o['vertices']),'highest_y':max(v[2]for v in o['vertices'])})
result={'status':'PRELIMINARY_NATIVE_GEOMETRY_AND_YARD_CONTAINMENT_NOT_APP','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'record_sha256':hashlib.sha256((r/'data/structures/versions/green_tree_tavern/andreas-reading.json').read_bytes()).hexdigest(),'shoulder_box':[x0,v0,x1,v1],'params':g,'foot_points':len(feet),'terrain_base_y':base,'whole_native_foot_relief_m':relief,'street_step_rule_m':.35,'objects':out,'limits':'Pureparameter/nativeMeshBuilderfeetandnativeyardfloatgeometry;notexported/quantized/app. ActualGLBfeet/physicalfootprintneighborclearance/walkapproach/shadow/samecameraandpublishedappstillowed.'}
(h/'PRELIMINARY-PHYSICAL-FIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
