# T-3123 real cache fix, complete PASS and source checkpoint

The native filesystem self-test failed when SITE was a symlink. Root authorized
a zero-code cache-layout correction: every one of 5,383 generated files was
identified and hashed, copied into the owner's real site directory, and rehashed
before the old central generated copy was removed. The central path became an
alias to the real directory. All 379,553,878 bytes and the 18 source inputs stayed
exact. Source models, source photos and held GLBs were untouched.

The original self-test then passed unchanged. Normal publication and the actual
published-file check passed with 2,175 copies plus 3,208 declared transforms and
no unmapped files. The native footer reads 201.39 MB; full ownership inventory
bytes are authoritative. A fresh complete required-reader check passed all 1,065
steps and 384 self-tests with the 18 source inputs unchanged. The original failed
gate remains separately preserved; no test or model code was weakened for it.

Normal T-3123 commit bd316f7f4 was pushed to the new three-utility branch and its
remote hash independently read back. Every committed source/artifact matches the
tested binding. This is the atomic roof checkpoint, not final group acceptance.
Lighthouse T-3122 and officers piazza T-3124 remain pending; original picture
tickets remain open/DIFFERS. Actual later dev/Ames integration, group app/source
reviews, final preflight and CI are still owed before readiness or merge.

Cache ownership may subsequently move under the exclusive lease protocol. This
packet records the closed correction, not a claim over a later live cache.
