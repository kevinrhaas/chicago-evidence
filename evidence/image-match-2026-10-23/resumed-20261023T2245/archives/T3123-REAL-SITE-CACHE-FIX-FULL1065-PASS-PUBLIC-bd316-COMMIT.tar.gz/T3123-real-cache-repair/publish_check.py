from pathlib import Path
import subprocess,os,json,hashlib,datetime
A=Path('/tmp/chicago-log-integration/chicago/4d');R=A.parents[1];H=Path('/workspace/T3122-T3123-T3124-integration-20261024');O=H/'T3123-real-cache-repair';binding=json.loads((H/'T3123-percommit-check/SOURCE-BINDING.json').read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def guard():
 for p,h in binding['paths'].items():assert sha(R/p)==h,p
 assert not(R/'site/4d').is_symlink()and(R/'site/4d').is_dir();assert Path('/workspace/dearborn-board-published-20261024').resolve()==R/'site/4d'
guard();E=dict(os.environ);E.pop('CHICAGO_TICKETS_DIR',None);assert 'CHICAGO_TICKETS_DIR'not in E;E.update(TMPDIR='/workspace/T3122-tmp',PATH='/workspace/shared/tools/usr/bin:'+E['PATH'],PYTHONDONTWRITEBYTECODE='1',npm_config_cache='/workspace/shared/npm-cache');state={'status':'RUNNING','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'input_source_sha256':binding['source_sha256'],'all18_input_exact':True}
for label,cmd in [('native-publish-real',['bash','tools/publish.sh']),('check-published-real',['node','tools/check_published.mjs'])]:
 with(O/(label+'.log')).open('x')as f:p=subprocess.run(cmd,cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
 state['steps'].append({'label':label,'command':cmd,'exit_code':p.returncode});state['status']='RUNNING'if p.returncode==0 else'FAIL';(O/'PUBLISH-CHECK.json').write_text(json.dumps(state,indent=2)+'\n');guard()
 if p.returncode:raise SystemExit(p.returncode)
state.update(status='PASS_REAL_SITE_PUBLISH_AND_AUTHORITATIVE_CHECK',finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_unchanged=True,real_site_footer=(O/'native-publish-real.log').read_text().splitlines()[-1]);(O/'PUBLISH-CHECK.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state,indent=2))
