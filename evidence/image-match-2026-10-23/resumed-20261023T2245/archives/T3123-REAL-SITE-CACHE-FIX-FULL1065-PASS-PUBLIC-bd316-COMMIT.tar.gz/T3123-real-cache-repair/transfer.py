from pathlib import Path
import json,hashlib,shutil,datetime
H=Path('/workspace/T3122-T3123-T3124-integration-20261024');O=H/'T3123-real-cache-repair';C=Path('/workspace/dearborn-board-published-20261024');S=Path('/tmp/chicago-log-integration/site/4d');R=Path('/tmp/chicago-log-integration');sha=lambda b:hashlib.sha256(b).hexdigest();d=json.loads((O/'INVENTORY.json').read_bytes());assert d['status']=='PASS_CURRENT_SHARED_CACHE_ALL_PATHS_NATIVE_GENERATED'and not d['problems'];assert C.is_dir()and not C.is_symlink()and S.is_symlink()and S.resolve()==C
binding=json.loads((H/'T3123-percommit-check/SOURCE-BINDING.json').read_bytes())
for p,h in binding['paths'].items():assert sha((R/p).read_bytes())==h,p
rows={x['path']:x for x in d['rows']};assert {p.relative_to(C).as_posix()for p in C.rglob('*')if p.is_file()}==set(rows)
for name,row in rows.items():
 p=C/name;st=p.lstat();assert not p.is_symlink()and st.st_ino==row['inode']and st.st_mtime_ns==int(row['mtime_ns'])and st.st_size==row['bytes']and sha(p.read_bytes())==row['sha256'],name
assert shutil.disk_usage('/tmp').free>d['bytes']+64*1024**2
start=datetime.datetime.now(datetime.timezone.utc).isoformat();S.unlink();shutil.copytree(C,S,copy_function=shutil.copy2,symlinks=False)
assert S.is_dir()and not S.is_symlink();assert {p.relative_to(S).as_posix()for p in S.rglob('*')if p.is_file()}==set(rows)
for name,row in rows.items():
 p=S/name;assert p.is_file()and not p.is_symlink()and p.stat().st_size==row['bytes']and sha(p.read_bytes())==row['sha256'],name
# Retain the source until every destination byte has passed its independent read.
for name,row in rows.items():assert sha((C/name).read_bytes())==row['sha256']
shutil.rmtree(C);C.symlink_to(S,target_is_directory=True)
for p,h in binding['paths'].items():assert sha((R/p).read_bytes())==h,p
out={'status':'PASS_COMPLETE_NATIVE_CACHE_COPIED_AND_VERIFIED_REAL_OWNER_SITE_CENTRAL_ALIAS_ONLY','start':start,'finish':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(rows),'bytes':d['bytes'],'real_owner_site':str(S),'central_alias':str(C),'central_resolves':str(C.resolve()),'all18_source_binding_exact':True,'tmp_free':shutil.disk_usage('/tmp').free,'workspace_free':shutil.disk_usage('/workspace').free,'source_old_cache_preserved_until_all_destination_SHA_checks':True,'source_models_and_held_GLBS':'UNTOUCHED','remaining':'Sole failed unchanged native self-test, native publish/published validation then complete required-reader check; no acceptance inherited from first failed gate'};(O/'TRANSFER.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
