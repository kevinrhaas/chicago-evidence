ACTUAL old6bf desktop14 failure and bounded baseline/source-count review.

Run40051604125/job120745282473 exact6bf,desktop14,139PASS1FAIL,zero pageerrors. Actual1904spawn5113drawcalls/4,600,491triangles vs7800/4,600,000 limit:491triangleovershoot. No budget/tolerance waiver.

Standing desktop14record latest10/16PASS128/0 on378a925dirty,olderfailuresreadytimeout/browserclosed; no matching6bfbaseline or knowntrianglefailure. Nativeask read-only on currentrootindex is explicitlyDIRTY/different; historicalPASS dates butdoesnotattribute/waive actualFAIL.

T3081own026ace→6bf:2411904sidecars+structure IDs,233referencedmaster/webpairs,allrenderers/smoke/state guards:1385existingtrackedpaths exact. TwoGlessnerGLBs intentionallyuntrackedbothcommits,NOTassetbytescompared; their master/web/Lightmanifestcontracts exact separately. Only1904datapathchange sourceusescounts.

ACTUAL KimballGLBindex/accessor counts old6bfmaster/web114135→exactincoming8e5amaster/web113414 (721fewertriangles,one mesh/node). NewfileGitblobidentities matchREST8e5a. Arithmetic exceeds491overshoot but is NOTcurrent-cameraPASS; actualnewheadstage14 remainsrequired. No producer/browser/heavyjobs/sourcewrites/lap/merge/retry byreview. Rootownsremediation.
