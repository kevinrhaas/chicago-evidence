Prepared read-only PR1260 CI watcher. No new-head API poll or dispatch has occurred.

The controller requires a full exact head and an18-run dispatch receipt whose entries were accepted and observed on that head. It validates nine standard groups for each viewport before making any API request. Every network command explicitly uses GET. It cannot dispatch, cancel, merge, claim, renew a lap, or write checked source.

When the root provides the actual binding, invoke with its real receipt and a new evidence directory under /tmp:

    python watch_controller.py --dispatch RECEIPT.json --head FULL_SHA --out /tmp/NEW_EVIDENCE --harvest

Poll about every five minutes. Snapshots retain exact metadata and PR/dev context. Completed logs and job metadata are preserved without overwrite; transcript head/viewport/stage, terminal counts, zero page errors and real SMOKE PASS are checked separately from metadata success. Failed logs remain available in full. A future head change is reported separately from the bound runs.

Only Python AST syntax validation has been performed on this prepared controller. No operational execution or test-PASS claim is implied. Earlier old-head6bf coverage remains frozen with15successes and3failures. Await explicit actual new-head/receipt binding from the root before starting this controller.
