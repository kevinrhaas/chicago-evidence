"""Small CPU-only native GLB vertex inspection, no Blender/browser/render engine."""
import pathlib,json,hashlib,struct,subprocess,sys,dataclasses,os
P=pathlib.Path(__file__).parent;R=pathlib.Path('/tmp/chicago-log-integration');REF='bd316f7f45668e906a49beeefa01a1b72ee2e5d8';A='chicago/4d/';os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
sha=lambda b:hashlib.sha256(b).hexdigest()
def source(path):return subprocess.check_output(['git','-C',str(R),'show',REF+':'+A+path])
paths=['data/structures/jb_beaubien_homestead.json','data/sources/kinzie_1857_chicago_1831_panorama.json','data/sources/kinzie_waubun_1856.json','data/sources/wentworth_1881_fort_dearborn.json','data/structure_grades.json','generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py','generators/mesh_inputs.py','tools/generate_entrances.py','generators/archetypes/facade_openings.py','docs/RESEARCH/jb_beaubien_homestead.md','assets/manifest.json','assets/manifest.web.json']
# Read committed master and all relevant source bytes; do not touch native writers.
guards={p:{'sha256':sha(source(p)),'bytes':len(source(p)),'observed_worktree_sha256':sha((R/A/p).read_bytes())} for p in paths}
rec=json.loads(source(paths[0]));ph=rec['phases'][0];(P/'current-record.json').write_bytes(source(paths[0]));(P/'current-source.json').write_bytes(source(paths[1]));(P/'current-dossier.md').write_bytes(source('docs/RESEARCH/jb_beaubien_homestead.md'))
# Core log inputs used by the lightweight native resolver must be exact.
for p in ['data/structures/jb_beaubien_homestead.json','generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py','generators/mesh_inputs.py']:
 assert guards[p]['sha256']==guards[p]['observed_worktree_sha256'],p
sys.path.insert(0,str(R/A/'generators'));import mesh_inputs
params=mesh_inputs.resolve_params('log_dwelling',ph,rec);inputs=mesh_inputs.structure_inputs_sha(rec,ph);m=json.loads(source('assets/manifest.json'))['assets'];target='jb_beaubien_homestead__log_1822.glb';assert inputs==m[target]['inputs_sha256']
family={k:v for k,v in m.items() if v.get('archetype')=='log_dwelling'};assert len(family)==82
blob=source('assets/gltf/'+target);(P/'current-master.glb').write_bytes(blob);old=pathlib.Path('/workspace/primary-human-runner-compat/chicago/4d/assets/gltf')/target;assert blob==old.read_bytes();n,t=struct.unpack_from('<II',blob,12);doc=json.loads(blob[20:20+n]);off=20+n;bn,bt=struct.unpack_from('<II',blob,off);binary=blob[off+8:off+8+bn]
widths={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4};formats={5126:('f',4),5125:('I',4),5123:('H',2),5121:('B',1)}
def accessor(i):
 a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];fmt,size=formats[a['componentType']];width=widths[a['type']];stride=v.get('byteStride',size*width);start=v.get('byteOffset',0)+a.get('byteOffset',0);return [struct.unpack_from('<'+fmt*width,binary,start+j*stride) for j in range(a['count'])]
tri=[];parts=[]
for prim in doc['meshes'][0]['primitives']:
 v=accessor(prim['attributes']['POSITION']);idx=[q[0] for q in accessor(prim['indices'])];part=[tuple(v[idx[i+j]] for j in range(3)) for i in range(0,len(idx),3)];tri.extend(part);parts.append({'material':doc['materials'][prim['material']].get('name'),'triangles':len(part),'bbox':[[min(q[a] for q in v) for a in range(3)],[max(q[a] for q in v) for a in range(3)]]})
# An explicitly labelled analytical wireframe shows actual decoded master vertices.
# It is not a native/app/photo_match rendered comparison or fitted source camera.
cache=pathlib.Path('/workspace/T2378-plot-runtime-cache');cache.mkdir(exist_ok=True);os.environ['MPLCONFIGDIR']=str(cache/'mpl');os.environ['XDG_CACHE_HOME']=str(cache)
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
fig=plt.figure(figsize=(9,4));
for i,azim in enumerate([35,215]):
 ax=fig.add_subplot(1,2,i+1,projection='3d');ax.add_collection3d(Poly3DCollection([[(x,-z,y) for x,y,z in face] for face in tri],facecolor=(.8,.8,.8,.25),edgecolor=(.15,.15,.15,.45),linewidth=.15));ax.set_xlim(-1,13.5);ax.set_ylim(-1,7);ax.set_zlim(0,6);ax.set_box_aspect((14.5,8,6));ax.view_init(elev=18,azim=azim);ax.set_xlabel('u (m)');ax.set_ylabel('v (m)');ax.set_zlabel('height (m)')
fig.suptitle('Actual current Beaubien GLB vertices — CPU inspection diagram\nUnfitted orthographic views; no native engine, materials or source-image match');fig.tight_layout();fig.savefig(P/'current-master-CPU-vertex-inspection.png',dpi=120);plt.close(fig)
(P/'CURRENT-BINDINGS.json').write_text(json.dumps({'ref':REF,'tree':subprocess.check_output(['git','-C',str(R),'rev-parse',REF+'^{tree}'],text=True).strip(),'guards':guards,'current_master_sha256':sha(blob),'current_master_bytes':len(blob),'current_master_exact_older308b':True,'actual_recomputed_inputs_sha256':inputs,'manifest_row':m[target],'family82':list(family),'parameters':dataclasses.asdict(params),'decoded_nodes':doc['nodes'],'decoded_parts':parts,'triangles':len(tri),'whole_source_flags_occupants_unchanged':True,'model_view':'analytical CPU vertex-only diagram; NOT native material/render/photo camera','existing_accepted_camera_or_Beaubien_actual_model_source_pair_found':False,'canonical_writes_Blender_browser_native_pipeline':'none'},indent=2)+'\n');print('PASS current master native recipe fresh/exact older308b;82family; decoded',len(tri),'triangles; CPU diagram only')
