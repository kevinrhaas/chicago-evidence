# T-2378: the keyed panorama has an explicit retrospective corner annotation

Read-only research, 23 October 2026. No model change, accepted camera or match.

## Actual source read

John Wentworth, *Early Chicago and Fort Dearborn* (Fergus Historical Series,
1881), printed pp. 86–87, Archive identifier `earlychicagofort00wentiala`.
Commons identifies this publication as the source of the exact keyed local cut.
The downloaded printed pages were opened visually, not accepted from OCR alone:

- `earlychicagofort00wentiala-p86-actual.jpg`, fetched from
  https://archive.org/download/earlychicagofort00wentiala/page/n95.jpg
- `earlychicagofort00wentiala-p87-actual.jpg`, fetched from
  https://archive.org/download/earlychicagofort00wentiala/page/n96.jpg

The archive's page-number JSON leaf numbers do not correspond directly to this
page-image endpoint: the initial requests n102/n103 delivered printed93/94.
Those files are retained clearly renamed `p93-initial-wrong-leaf` and
`p94-initial-wrong-leaf`; never cite them as86/87. Actual printed numerals were
checked in the subsequently retrieved pages. FETCH-MANIFEST hashes all inputs.

## Directly relevant new annotation

Under the same keyed cut on printed p.86:

> Gen. Beaubien’s house was near the N.-E. cor. Michigan Avenue and South-Water Street.

This is stronger than the image's bare “Gen. J. B. Beaubien’s” key: it explicitly
locates that pictured house at the same retrospective corner used by the current
homestead record. It supports an **inferred working identification** of the keyed
house with the sale-located residence, while leaving the precise building lineage
(old factory versus new residence) unresolved. It is Wentworth's1881 annotation,
not a contemporary1831 survey and not independent corroboration of Wentworth's
sale narrative. Do not transfer the FactoryHouse's separately documented squared
log fabric or two storeys to this record.

## Strong caveat on the very next page

Hubbard's letter dated20July1881 begins under the cut and continues on p.87:

> It is certainly unlike the Fort and surroundings, as I recollect them.

He describes the probable northeast view but corrects its high fort ground,
sharp point/river bends, blockhouse height and omission of the circa1824–25 brick
building. His comment about engraving from Kinzie's sketch without her correction
is explicitly speculation (“probably”), not established publication history.

Consequences: do not force surveyed coordinates/terrain or every compound member
to the drawing; do not use a good or bad common-camera fit as proof of the identity.
An isolated Beaubien form trial can now be argued against the keyed house as an
inferred identification, but must preserve the depicted1831 versus scene1835
survival assumption and the drawing's known contradictions. No numerical form
change or image acceptance is established by this handoff.

## Publication limits

The page reproduces the credit “From Wau-Bun ... Chicago,1857”. Archive metadata
also yields1856 editions of Wau-Bun. That does not by itself identify which edition
first carried this cut. The exact keyed reproduction IS now directly verified in
the1881 publication. Keep1857 as the printed credit rather than silently resolving
the edition discrepancy.
