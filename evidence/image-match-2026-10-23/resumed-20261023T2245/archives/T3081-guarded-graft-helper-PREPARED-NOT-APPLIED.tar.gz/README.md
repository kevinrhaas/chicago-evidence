# T3081 guarded graft preparation

This helper transfers only the 18 authored files in root's closed checkpoint
`/tmp/log82-authored-checkpoint-20261023T2324`, manifest SHA256
`b9ad8b12f72c054d056ef3be19d5d273a9281cc1bbb585c322f2b2f2b60f818b`,
from base `5f15de2ba89a9aeef602b01462c0c688fe27280e` onto a future target.
It verifies every packet input, including the checkpoint's patch and README.
The old full-file authored patch is never applied to the target.

## Stage without changing the target

Use an existing explicit future commit containing current dev and PR1239:

```sh
python3 /tmp/log82-graft-prep-20261023T2340/graft_t3081.py --repo /tmp/chicago-log-integration --target-ref FUTURE_COMMIT --out /tmp/t3081-graft-future
```

Or use a resolved, uncommitted merge of those inputs:

```sh
python3 /tmp/log82-graft-prep-20261023T2340/graft_t3081.py --repo /tmp/chicago-log-integration --target-worktree --out /tmp/t3081-graft-uncommitted
```

Worktree mode refuses unresolved merges and fingerprints HEAD, the entire staged
index listing, MERGE_HEAD and all 18 touched working-file preimages. It does not
write-tree, check out, fetch, stage, commit or run population consumers. The index
and merge fingerprint and touched preimages must remain stable during staging.
Unrelated generated working files can remain dirty.

The output is an 18-file overlay, `report.json` and a reviewable `graft.patch`.
A single conflict prevents the entire overlay from being emitted. Stage into a
fresh outside-worktree directory every time; failed stages are retained for review.

## Preservation and conflict rules

- JSON objects merge only authored fields. Stable `id` rows, including phases,
  merge by identity, so an inserted phase cannot shift an update onto another row.
  Picture-grade rows merge by `(scene, structure)`; all incoming Glessner/Hogan or
  other unrelated rows and edits remain. A differing concurrent addition at the
  same key/row identity is refused.
- Pure array additions commute with independent incoming additions/removals.
  Identical additions are idempotent. Non-keyed non-append arrays, including the
  Wolf footprint polygon and replaced source/prose lists, are atomic: an incoming
  change to the same array is refused for explicit field review. Scalar and prose
  changes to the same JSON field are also refused.
- LIBERTIES, Cobweb's dossier, STATUS and ROADMAP retain the complete current raw
  byte prefix and append only the exact checkpoint fragment. Existing non-UTF8
  history is never decoded or normalized. A rewritten base prefix, partial/different
  same-heading append or reused liberty id is refused. Exact existing fragments
  are idempotent.
- The native manifest inserts only the single entrance-apron writer immediately
  after the current compile_scene step. It preserves all other current bytes,
  metadata and writers. A conflicting or differently ordered existing entrance
  writer is refused. The helper checks that the packet's manifest itself contains
  no other semantic change.
- The three Python files use a three-way textual merge with the original base;
  conflict markers cause refusal. Each result is syntax-compiled without execution.
  Independent incoming code survives. Semantic interactions still need engineering
  review and the full gates after the future base is assembled.
- New source/changelog files are added only when absent, or accepted when already
  identical. The overlay includes no assets, Hogan record/source, Glessner files,
  population outputs, reference views or image-match verdicts.

## Explicit later application by root

Review the overlay, patch and report first. This preparation has not applied any
overlay to the canonical worktree. When root is ready:

```sh
python3 /tmp/log82-graft-prep-20261023T2340/graft_t3081.py --repo /tmp/chicago-log-integration --apply-staged /tmp/t3081-graft-future
```

Application requires the exact staged target HEAD and every touched file's
preimage; worktree mode also requires the exact index/MERGE_HEAD snapshot. All
preimages and output hashes are checked before the first write. Commit-mode
staging refuses application into a subsequently started merge. No file is staged
or committed, and unrelated dirty outputs are untouched. Root must serialize
source authors while applying. If the target or index changes, restage.

For a recovered checkpoint at another location, pass `--packet RECOVERED_DIR` to
both stage and application; the pinned manifest and all input hashes still apply.

## Validation and remaining obligations

`verification.json` records 45 passing LIGHT checks, including independent phase
insertion, same-field refusals, grade-row preservation/conflicts, append/non-append
arrays, raw non-UTF8 history, native writer preservation/idempotence and code
three-way conflicts, plus application/preimage/HEAD/index guards in a disposable isolated repository. Actual base5f staging reproduces all 18 packet files byte for
byte. A read-only stage of the active authored worktree correctly refused only
STATUS, where root intentionally clarified the default-off statement after the
checkpoint: it did not overwrite that edit or append a duplicate section.

The fixed checkpoint STATUS wording says all 82 existing records retain raw
defaults. Root's intended clarification should say this is the default-off
producer audit; five selected records intentionally opt in to visible changes.
When staging onto a clean future base, reapply that explicit clarification after
the graft. If the target already carries the edited T3081 section, resolve its
fragment manually or close a new reviewed packet; do not defeat the same-heading
guard. Future evidence/gate outcomes require further honest STATUS updates.

An actual official 82-asset bake can be preserved separately before this graft,
but its freshness must be rechecked against the final future producer, records,
seed names, source/recipe inputs and tool versions. Never graft whole old bake or
native manifests over incoming results. Rerun default parity if composed code
changes. Native ordered derivation, Wolf doorway/yard/terrain/river clearances,
population invariants under PR1239 V2, source-card/app review, published mobile and
desktop smokes and full preflight remain root's obligations. Original image gates
stay open. This helper conveys no bake, match, merge or rights approval.
