#!/usr/bin/env python3
"""LIGHT preservation and refusal checks; writes fixtures only beside this file."""
import copy
import contextlib
import importlib.util
import io
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True
root = Path(__file__).parent
spec = importlib.util.spec_from_file_location('graft', root / 'graft_t3081.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
passed = []


def ok(name, condition):
    assert condition, name
    passed.append(name)


def refused(name, function):
    try:
        function()
    except g.Conflict:
        passed.append(name)
    else:
        raise AssertionError(name + ' did not refuse')


base = {'phases': [{'id': 'one', 'form': {'height': 3}, 'incoming': 'old'}]}
ours = copy.deepcopy(base)
ours['phases'][0]['form']['roof'] = 'y'
theirs = copy.deepcopy(base)
theirs['phases'][0]['incoming'] = 'new'
theirs['phases'].insert(0, {'id': 'new_phase', 'form': {'height': 2}})
merged = g.merge_json(base, ours, theirs)
ok('phase identity survives incoming insertion; distinct field retained',
   merged['phases'][1]['form'] == {'height': 3, 'roof': 'y'} and merged['phases'][0] == theirs['phases'][0]
   and merged['phases'][1]['incoming'] == 'new')
theirs['phases'][1]['form']['roof'] = 'x'
refused('same added field conflict refuses', lambda: g.merge_json(base, ours, theirs))
refused('changed phase removed incoming refuses', lambda: g.merge_json(base, ours, {'phases': []}))

row = {'scene': '1835', 'structure': 'existing', 'picture': 'old'}
new = {'scene': '1835', 'structure': 'miller', 'picture': 'ours'}
incoming = {'scene': '1835', 'structure': 'glessner', 'picture': 'theirs'}
changed = dict(row, picture='better')
merged = g.merge_json([row], [row, new], [changed, incoming])
ok('grade rows preserve incoming changed and new rows', merged == [changed, incoming, new])
refused('same grade identity conflict refuses',
        lambda: g.merge_json([row], [row, new], [row, dict(new, picture='different')]))
ok('primitive append preserves concurrent additions and removals',
   g.merge_json(['base'], ['base', 'ours'], ['theirs']) == ['theirs', 'ours'])
ok('identical append is idempotent', g.merge_json(['base'], ['base', 'ours'], ['base', 'ours']) == ['base', 'ours'])
refused('nonappend polygon conflict refuses',
        lambda: g.merge_json([[0, 0], [1, 1]], [[0, 0], [2, 2]], [[0, 0], [3, 3]]))
ok('uncontested nonappend array replacement accepted',
   g.merge_json(['before'], ['after'], ['before']) == ['after'])
refused('same scalar field conflict refuses', lambda: g.merge_json('before', 'after', 'incoming'))

raw = b'historical non-UTF8 byte: \xff\n'
fragment = b'\n### L-example-3081: architectural detail\n\nDecision here.\n'
incoming_raw = raw + b'\n### L-incoming-9999: another liberty\n\nKeep me.\n'
merged = g.append_doc(raw, raw + fragment, incoming_raw, 'docs/LIBERTIES.md')
ok('raw nonUTF8 history and incoming liberty exact', merged == incoming_raw + fragment)
ok('raw append idempotent', g.append_doc(raw, raw + fragment, merged, 'docs/LIBERTIES.md') == merged)
refused('changed same liberty id refuses duplicate', lambda: g.append_doc(
    raw, raw + fragment, incoming_raw + b'### L-example-3081: edited title\nDifferent\n', 'docs/LIBERTIES.md'))
refused('raw history rewrite refuses', lambda: g.append_doc(raw, raw + fragment, b'changed\n', 'docs/LIBERTIES.md'))

packet = Path(g.PACKET)
repo = Path('/tmp/chicago-log-integration')
manifest_path = g.PREFIX + g.MANIFEST
before = g.blob(repo, g.BASE, manifest_path)
after = (packet / manifest_path).read_bytes()
obj = json.loads(before)
obj['future_metadata'] = {'glessner': 'retain'}
obj['steps'].insert(0, {'command': ['python3', 'tools/new_incoming.py'], 'resolves': ['incoming.json']})
latest = (json.dumps(obj, ensure_ascii=True, indent=3) + '\n').encode()
merged = g.insert_writer(before, after, latest)
decoded = json.loads(merged)
ok('native insertion preserves incoming metadata and writer', decoded['future_metadata'] == obj['future_metadata']
   and decoded['steps'][0] == obj['steps'][0] and len(decoded['steps']) == len(obj['steps']) + 1)
ok('native insertion idempotent', g.insert_writer(before, after, merged) == merged)
bad = copy.deepcopy(decoded)
next(x for x in bad['steps'] if 'tools/generate_entrances.py' in x.get('command', []))['why'] = 'different'
refused('existing competing native writer refuses', lambda: g.insert_writer(before, after, json.dumps(bad).encode()))

with tempfile.TemporaryDirectory(prefix='code-fixture-', dir=root) as td:
    old = b'a = 1\nb = 2\nc = 3\nd = 4\ne = 5\nf = 6\ng = 7\nh = 8\ni = 9\nj = 10\n'
    ours = old.replace(b'a = 1', b'a = 11')
    theirs = old.replace(b'j = 10', b'j = 20')
    merged = g.merge_code(old, ours, theirs, 'fixture.py', Path(td))
    ok('code three-way retains independent incoming hunk', b'a = 11' in merged and b'j = 20' in merged)
    refused('code same-line conflict refuses', lambda: g.merge_code(old, ours, old.replace(b'a = 1', b'a = 12'),
                                                                    'conflict.py', Path(td)))

stage = root / 'stage-base5f-final'
report = json.loads((stage / 'report.json').read_bytes())
ok('actual base5f stage has eighteen successful files', report['status'] == 'STAGED_NOT_APPLIED' and len(report['files']) == 18)
for entry in report['files']:
    ok('base5f output exact packet: ' + entry['path'],
       (stage / 'overlay' / entry['path']).read_bytes() == (packet / entry['path']).read_bytes())
live = json.loads((root / 'stage-live-readonly/report.json').read_bytes())
ok('actual changed STATUS refuses rather than overwrites', live['status'] == 'CONFLICT'
   and len(live['conflicts']) == 1 and live['conflicts'][0]['path'].endswith('/docs/STATUS.md'))

# Exercise explicit application only in a disposable independent repository.
# No shared Git refs/index or target source file is written.
with tempfile.TemporaryDirectory(prefix='apply-fixture-', dir=root) as td:
    fixture = Path(td) / 'repo'
    fixture.mkdir()
    subprocess.run(['git', 'init', '-q', str(fixture)], check=True, capture_output=True)
    for entry in report['files']:
        original = g.blob(repo, g.BASE, entry['path'])
        if original is not None:
            p = fixture / entry['path']
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(original)
    sentinel = fixture / 'incoming-glessner-hogan.txt'
    sentinel.write_bytes(b'independent incoming entries and assets must remain exact\n')
    subprocess.run(['git', '-C', str(fixture), 'add', '.'], check=True, capture_output=True)
    subprocess.run(['git', '-C', str(fixture), '-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid',
                    'commit', '-qm', 'isolated synthetic fixture'], check=True, capture_output=True)
    staged = Path(td) / 'stage'
    staged.mkdir()
    shutil.copytree(stage / 'overlay', staged / 'overlay')
    fixture_report = copy.deepcopy(report)
    fixture_report['target_commit'] = g.run(fixture, 'rev-parse', 'HEAD').stdout.decode().strip()
    rp = staged / 'report.json'
    rp.write_text(json.dumps(fixture_report))
    victim = fixture / next(e['path'] for e in report['files'] if e['before_sha256'] is not None)
    saved = victim.read_bytes()
    victim.write_bytes(saved + b'\nINCOMING CONFLICT\n')
    refused('apply rejects stale working-file preimage', lambda: g.apply_overlay(fixture, staged, packet))
    ok('failed apply has no partial new files', not (fixture / 'chicago/4d/changelog.d/T-3081.json').exists())
    victim.write_bytes(saved)
    fixture_report['target_commit'] = '0' * 40
    rp.write_text(json.dumps(fixture_report))
    refused('apply rejects changed HEAD', lambda: g.apply_overlay(fixture, staged, packet))
    fixture_report['target_commit'] = g.run(fixture, 'rev-parse', 'HEAD').stdout.decode().strip()
    fixture_report['target_mode'] = 'guarded_worktree'
    fixture_report['target_worktree_state'] = g.worktree_state(fixture)
    rp.write_text(json.dumps(fixture_report))
    sentinel.write_bytes(b'new incoming index change\n')
    g.run(fixture, 'add', sentinel.name)
    refused('worktree apply rejects changed index fingerprint', lambda: g.apply_overlay(fixture, staged, packet))
    g.run(fixture, 'reset', '-q', 'HEAD', '--', sentinel.name)
    sentinel.write_bytes(b'independent incoming entries and assets must remain exact\n')
    with contextlib.redirect_stdout(io.StringIO()):
        g.apply_overlay(fixture, staged, packet)
    ok('isolated apply produces all eighteen exact authored files',
       all((fixture / e['path']).read_bytes() == (packet / e['path']).read_bytes() for e in report['files']))
    ok('isolated apply preserves unrelated file and index',
       sentinel.read_bytes() == b'independent incoming entries and assets must remain exact\n'
       and g.worktree_state(fixture) == fixture_report['target_worktree_state'])
result = {'status': 'PASS', 'checks': len(passed), 'passed': passed,
          'limits': 'LIGHT fixtures, an isolated disposable-repository application, and read-only real staging only; no canonical target application, fetch, checkout, Blender, browser or full gates.'}
(root / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'checks': len(passed)}))
