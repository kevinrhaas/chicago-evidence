#!/usr/bin/env python3
"""Stage T3081 onto an explicit Git commit; never check out, fetch or write its tree."""
from __future__ import annotations

import argparse
import copy
import difflib
import hashlib
import json
import re
import subprocess
from pathlib import Path

BASE = '5f15de2ba89a9aeef602b01462c0c688fe27280e'
PACKET_SHA = 'b9ad8b12f72c054d056ef3be19d5d273a9281cc1bbb585c322f2b2f2b60f818b'
PACKET = '/tmp/log82-authored-checkpoint-20261023T2324'
PREFIX = 'chicago/4d/'
DOCS = {'docs/LIBERTIES.md', 'docs/RESEARCH/cobweb_castle.md', 'docs/STATUS.md', 'docs/ROADMAP.md'}
CODE = {'generators/archetypes/log_dwelling.py', 'generators/archetypes/log_dwelling_params.py', 'tools/generate_entrances.py'}
MANIFEST = 'tools/derived_manifest.json'
MISSING = object()


class Conflict(Exception):
    pass


def sha(b):
    return hashlib.sha256(b).hexdigest()


def run(repo, *args, check=True):
    return subprocess.run(['git', '-C', str(repo), *args], capture_output=True, check=check)


def blob(repo, ref, path):
    result = run(repo, 'show', ref + ':' + path, check=False)
    if result.returncode == 0:
        return result.stdout
    # Distinguish an absent path from a broken Git invocation/ref.
    listing = run(repo, 'ls-tree', ref, '--', path)
    if listing.stdout:
        raise Conflict('Cannot read existing Git blob: ' + path)
    return None


def worktree_state(repo):
    """Read-only index fingerprint; do not write-tree or create an ungated commit."""
    unresolved = run(repo, 'diff', '--name-only', '--diff-filter=U').stdout
    if unresolved:
        raise Conflict('Target worktree has unresolved merge paths')
    merge = run(repo, 'rev-parse', '--verify', 'MERGE_HEAD', check=False)
    return {'head': run(repo, 'rev-parse', 'HEAD').stdout.decode().strip(),
            'index_stage_sha256': sha(run(repo, 'ls-files', '--stage', '-z').stdout),
            'merge_head': merge.stdout.decode().strip() if merge.returncode == 0 else None}


def working_blob(repo, path):
    target = repo / path
    if target.is_symlink() or any(p.is_symlink() for p in target.parents if p != repo.parent):
        raise Conflict('Symlink target path refused: ' + path)
    return target.read_bytes() if target.exists() else None


def keyed_spec(before, after, current):
    """Use explicit stable row keys, never positional matching of phase records."""
    for keys in [('id',), ('scene', 'structure')]:
        rows = before + after + current
        if rows and all(isinstance(row, dict) and all(k in row for k in keys) for row in rows):
            try:
                if all(len({tuple(row[k] for k in keys) for row in seq}) == len(seq)
                       for seq in (before, after, current)):
                    return keys
            except TypeError:
                pass
    return None


def merge_json(before, after, current, path=''):
    """Keep incoming fields; refuse conflicting edits rather than choosing a side."""
    if before == after:
        return copy.deepcopy(current)
    if current == after:
        return copy.deepcopy(current)
    if current == before:
        return copy.deepcopy(after)
    if isinstance(before, dict) and isinstance(after, dict) and isinstance(current, dict):
        result = copy.deepcopy(current)
        for key in list(before) + [k for k in after if k not in before]:
            old, new, now = before.get(key, MISSING), after.get(key, MISSING), current.get(key, MISSING)
            location = path + '/' + key.replace('~', '~0').replace('/', '~1')
            if old == new:
                continue
            if old is MISSING:
                if now is MISSING:
                    result[key] = copy.deepcopy(new)
                elif now != new:
                    raise Conflict(location + ': both sides added different values')
            elif new is MISSING:
                if now == old:
                    result.pop(key, None)
                elif now is not MISSING:
                    raise Conflict(location + ': deletion conflicts with incoming change')
            elif now is MISSING:
                raise Conflict(location + ': incoming deletion conflicts with authored change')
            else:
                result[key] = merge_json(old, new, now, location)
        return result
    if isinstance(before, list) and isinstance(after, list) and isinstance(current, list):
        keys = keyed_spec(before, after, current)
        if keys:
            key = lambda row: tuple(row[k] for k in keys)
            old_map = {key(row): row for row in before}
            new_map = {key(row): row for row in after}
            now_map = {key(row): row for row in current}
            result = []
            for row in current:
                identity = key(row)
                if identity in old_map and identity in new_map:
                    result.append(merge_json(old_map[identity], new_map[identity], row,
                                             path + '/row=' + repr(identity)))
                elif identity in old_map:  # Authored deletion.
                    if row != old_map[identity]:
                        raise Conflict(path + ': row deletion conflicts with incoming change ' + repr(identity))
                elif identity in new_map:
                    if row != new_map[identity]:
                        raise Conflict(path + ': both sides added different row ' + repr(identity))
                    result.append(copy.deepcopy(row))
                else:
                    result.append(copy.deepcopy(row))
            for row in after:
                identity = key(row)
                if identity not in now_map:
                    if identity not in old_map:
                        result.append(copy.deepcopy(row))
                    elif row != old_map[identity]:
                        raise Conflict(path + ': changed row was removed incoming ' + repr(identity))
            return result
        if after[:len(before)] == before:
            # Pure append operations commute. Preserve all current order/values,
            # including independent additions/removals; never resurrect old rows.
            additions = after[len(before):]
            if len({json.dumps(x, sort_keys=True) for x in additions}) != len(additions):
                raise Conflict(path + ': authored append contains duplicates')
            result = copy.deepcopy(current)
            for value in additions:
                if value not in result:
                    result.append(copy.deepcopy(value))
            return result
        # Non-keyed replacement/reordering is atomic. A polygon, sash source-list
        # or prose-list cannot safely be merged by numeric index.
        raise Conflict(path + ': non-append array changed incoming; explicit field review required')
    raise Conflict(path + ': authored and incoming edits change the same field')


def append_doc(before, after, current, path):
    if not after.startswith(before):
        raise Conflict(path + ': packet is not a raw append to base')
    if not current.startswith(before):
        raise Conflict(path + ': incoming history rewrites the raw base prefix')
    addition = after[len(before):]
    if not addition:
        return current
    suffix = current[len(before):]
    if addition in suffix:
        if suffix.count(addition) != 1:
            raise Conflict(path + ': duplicate exact authored fragment')
        return current
    # Reject overlapping/differently edited entries instead of appending a second
    # liberty id or T3081 heading. Decode only the appended ASCII markers.
    markers = re.findall(rb'(?m)^#{2,4} .+$', addition)
    if path == 'docs/LIBERTIES.md':
        markers = [m for m in markers if re.search(rb'\bL-[A-Za-z0-9_-]+', m)]
        if not markers:
            raise Conflict(path + ': missing native liberty headings')
    for marker in markers:
        liberty_id = re.search(rb'\bL-[A-Za-z0-9_-]+', marker) if path == 'docs/LIBERTIES.md' else None
        if marker in suffix or (liberty_id and liberty_id.group() in suffix):
            raise Conflict(path + ': matching heading with nonidentical fragment: ' + repr(marker))
    return current + addition


def list_spans(text, member):
    """Find top-level array item spans without reserializing any current bytes."""
    decoder = json.JSONDecoder()
    i = 0
    while text[i].isspace():
        i += 1
    if text[i] != '{':
        raise Conflict('Native manifest must be a JSON object')
    i += 1
    while True:
        while text[i].isspace() or text[i] == ',':
            i += 1
        if text[i] == '}':
            break
        key, end = decoder.raw_decode(text, i)
        i = end
        while text[i].isspace():
            i += 1
        if text[i] != ':':
            raise Conflict('Invalid top-level JSON delimiter')
        i += 1
        while text[i].isspace():
            i += 1
        if key != member:
            _, i = decoder.raw_decode(text, i)
            continue
        if text[i] != '[':
            raise Conflict('Native steps must be an array')
        i += 1
        spans = []
        while True:
            while text[i].isspace() or text[i] == ',':
                i += 1
            if text[i] == ']':
                return spans
            value, end = decoder.raw_decode(text, i)
            spans.append((value, i, end))
            i = end
    raise Conflict('Missing top-level ' + member)


def insert_writer(before, after, current):
    old, proposed, latest = map(json.loads, (before, after, current))
    old_steps, new_steps = old['steps'], proposed['steps']
    entries = [x for x in new_steps if x.get('command') == ['python3', 'tools/generate_entrances.py']]
    if len(entries) != 1:
        raise Conflict('Packet must have exactly one entrance writer')
    writer = entries[0]
    stripped = dict(proposed, steps=[x for x in new_steps if x is not writer])
    if stripped != old:
        raise Conflict('Packet manifest changes more than the single native writer')
    scene_indexes = [i for i, x in enumerate(latest['steps'])
                     if x.get('command', [])[:2] == ['python3', 'tools/compile_scene.py']]
    if len(scene_indexes) != 1:
        raise Conflict('Latest native manifest needs exactly one compile_scene writer')
    scene_index = scene_indexes[0]
    existing = [(i, x) for i, x in enumerate(latest['steps'])
                if 'tools/generate_entrances.py' in x.get('command', []) or
                'chicago/4d/data/enclosures/town_entrance_aprons.json' in x.get('resolves', [])]
    if existing:
        if existing != [(scene_index + 1, writer)]:
            raise Conflict('Existing entrance writer differs or is ordered differently')
        return current
    text = current.decode('utf-8')
    spans = list_spans(text, 'steps')
    _, start, end = spans[scene_index]
    indent = re.match(r'[ \t]*', text[text.rfind('\n', 0, start) + 1:start]).group()
    encoded = json.dumps(writer, ensure_ascii=False, indent=2)
    fragment = '\n'.join(indent + line for line in encoded.splitlines())
    result_text = text[:end] + ',\n' + fragment + text[end:]
    result = result_text.encode('utf-8')
    expected = copy.deepcopy(latest)
    expected['steps'].insert(scene_index + 1, writer)
    if json.loads(result) != expected:
        raise Conflict('Native raw insertion changed unrelated semantics')
    # Deleting the exact inserted span must restore the latest raw bytes.
    if (result_text[:end] + result_text[end + len(',\n' + fragment):]).encode('utf-8') != current:
        raise Conflict('Native raw insertion failed byte-preservation guard')
    return result


def merge_code(before, after, current, path, scratch):
    if current == before:
        result = after
    elif current == after:
        result = current
    else:
        paths = []
        for label, data in [('current', current), ('base', before), ('authored', after)]:
            p = scratch / (Path(path).name + '.' + label)
            p.write_bytes(data)
            paths.append(str(p))
        merged = subprocess.run(['git', 'merge-file', '-p', *paths], capture_output=True)
        if merged.returncode != 0:
            raise Conflict(path + ': three-way textual conflict; manual engineering review required')
        result = merged.stdout
    compile(result, path, 'exec')
    return result


def validate_packet(packet):
    manifest_bytes = (packet / 'MANIFEST.json').read_bytes()
    if sha(manifest_bytes) != PACKET_SHA:
        raise Conflict('Root checkpoint manifest changed; refusing unpinned input')
    manifest = json.loads(manifest_bytes)
    for entry in manifest['files']:
        path = packet / entry['path']
        if path.is_symlink() or not path.is_file():
            raise Conflict('Missing/nonregular packet input: ' + entry['path'])
        data = path.read_bytes()
        if len(data) != entry['bytes'] or sha(data) != entry['sha256']:
            raise Conflict('Packet input hash mismatch: ' + entry['path'])
    paths = [e['path'] for e in manifest['files'] if e['path'].startswith(PREFIX)]
    if len(paths) != 18:
        raise Conflict('Expected exactly 18 authored files')
    return paths


def stage(repo, target, packet, output, use_worktree=False):
    paths = validate_packet(packet)
    state = worktree_state(repo) if use_worktree else None
    commit = state['head'] if state else run(repo, 'rev-parse', '--verify', target + '^{commit}').stdout.decode().strip()
    run(repo, 'cat-file', '-e', BASE + '^{commit}')
    if output.exists():
        raise Conflict('Output already exists; choose a new directory')
    output.mkdir(parents=True)
    scratch = output / 'scratch'
    scratch.mkdir()
    planned, conflicts = [], []
    # Compute all files before exposing an applyable overlay.
    for path in paths:
        before = blob(repo, BASE, path)
        current = working_blob(repo, path) if use_worktree else blob(repo, commit, path)
        after = (packet / path).read_bytes()
        rel = path[len(PREFIX):]
        try:
            if before is None:
                if current is not None and current != after:
                    raise Conflict('Both sides created different file')
                merged = after
                strategy = 'new-file exact guard'
            elif current is None:
                raise Conflict('Incoming base deleted an authored file')
            elif rel in DOCS:
                merged = append_doc(before, after, current, rel)
                strategy = 'raw-prefix-preserving append'
            elif rel == MANIFEST:
                merged = insert_writer(before, after, current)
                strategy = 'single raw native-writer insertion'
            elif rel in CODE:
                merged = merge_code(before, after, current, rel, scratch)
                strategy = 'three-way code merge + syntax compilation'
            elif rel.endswith('.json'):
                value = merge_json(json.loads(before), json.loads(after), json.loads(current))
                if value == json.loads(current):
                    merged = current
                elif current == before:
                    merged = after  # Exact packet bytes on unchanged current file.
                else:
                    # Field preservation is semantic. Formatting of JSON may change;
                    # raw document history and native manifest use other paths above.
                    merged = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
                strategy = 'field merge; stable row keys; append/atomic-array guards'
            else:
                raise Conflict('Unclassified authored file')
            planned.append((path, current, merged, strategy))
        except (Conflict, SyntaxError, UnicodeError, json.JSONDecodeError) as e:
            conflicts.append({'path': path, 'reason': str(e)})
    report = {'status': 'CONFLICT' if conflicts else 'STAGED_NOT_APPLIED', 'source_base': BASE,
              'target_commit': commit, 'packet_manifest_sha256': PACKET_SHA,
              'target_mode': 'guarded_worktree' if use_worktree else 'commit',
              'target_worktree_state': state,
              'conflicts': conflicts, 'files': []}
    if state:
        if worktree_state(repo) != state:
            raise Conflict('Target HEAD/index/MERGE_HEAD changed while staging; retry')
        for path, current, _, _ in planned:
            if working_blob(repo, path) != current:
                raise Conflict('Target authored file changed while staging: ' + path)
    if not conflicts:
        overlay = output / 'overlay'
        patch = []
        for path, current, merged, strategy in planned:
            destination = overlay / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(merged)
            report['files'].append({'path': path, 'before_sha256': sha(current) if current is not None else None,
                                    'after_sha256': sha(merged), 'bytes': len(merged),
                                    'changed': current != merged, 'strategy': strategy})
            if current != merged:
                patch.extend(difflib.diff_bytes(difflib.unified_diff, (current or b'').splitlines(keepends=True),
                                               merged.splitlines(keepends=True),
                                               fromfile=('a/' + path).encode() if current is not None else b'/dev/null',
                                               tofile=('b/' + path).encode()))
        (output / 'graft.patch').write_bytes(b''.join(patch))
        # Overlay scope cannot include Hogan, Glessner, generated assets or any
        # unrelated target file; they are preserved by construction.
        assert len(report['files']) == 18
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'report': str(output / 'report.json'),
                      'target_commit': commit, 'conflicts': conflicts}, indent=2))
    return 1 if conflicts else 0


def apply_overlay(repo, staged, packet):
    """Explicit owner-only action: require exact HEAD and all touched preimages."""
    report = json.loads((staged / 'report.json').read_bytes())
    if report.get('status') != 'STAGED_NOT_APPLIED' or report.get('packet_manifest_sha256') != PACKET_SHA:
        raise Conflict('Only successful pinned stage reports can be applied')
    head = run(repo, 'rev-parse', 'HEAD').stdout.decode().strip()
    if head != report['target_commit']:
        raise Conflict('Target HEAD changed since staging; restage onto exact new commit')
    if report.get('target_mode') == 'guarded_worktree':
        if worktree_state(repo) != report['target_worktree_state']:
            raise Conflict('Target HEAD/index/MERGE_HEAD changed since worktree staging; restage')
    else:
        if worktree_state(repo)['merge_head'] is not None:
            raise Conflict('Commit-mode stage cannot apply into an in-progress merge; use --target-worktree')
    paths = validate_packet(packet)
    if {e['path'] for e in report['files']} != set(paths):
        raise Conflict('Overlay does not have the exact authored scope')
    writes = []
    for entry in report['files']:
        path = repo / entry['path']
        data_path = staged / 'overlay' / entry['path']
        before = working_blob(repo, entry['path'])
        if (sha(before) if before is not None else None) != entry['before_sha256']:
            raise Conflict('Working file changed since stage: ' + entry['path'])
        index = run(repo, 'diff', '--cached', '--quiet', '--', entry['path'], check=False)
        if index.returncode and report.get('target_mode') != 'guarded_worktree':
            raise Conflict('Authored target has staged changes: ' + entry['path'])
        data = data_path.read_bytes()
        if sha(data) != entry['after_sha256'] or len(data) != entry['bytes']:
            raise Conflict('Staged overlay hash mismatch: ' + entry['path'])
        writes.append((path, data, before))
    # All 18 preimages are checked before any write. Roll back only our own bytes
    # if an OS-level write fails. Other dirty/generated files are untouched.
    final_state = worktree_state(repo)
    if final_state['head'] != head:
        raise Conflict('Target HEAD changed during apply validation')
    if report.get('target_mode') == 'guarded_worktree':
        if final_state != report['target_worktree_state']:
            raise Conflict('Target HEAD/index/MERGE_HEAD changed during apply validation')
    elif final_state['merge_head'] is not None:
        raise Conflict('A merge began during commit-mode apply validation')
    done = []
    try:
        for path, data, before in writes:
            if data == before:
                continue
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            done.append((path, before))
    except Exception:
        for path, before in reversed(done):
            if before is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(before)
        raise
    print(json.dumps({'status': 'APPLIED_UNCOMMITTED', 'files_written': len(done), 'head': head}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--target-ref', help='Existing future base commit; no fetch or checkout performed')
    parser.add_argument('--target-worktree', action='store_true', help='Read current target files with HEAD/index/MERGE_HEAD guards; supports an uncommitted resolved merge')
    parser.add_argument('--packet', type=Path, default=Path(PACKET))
    parser.add_argument('--out', type=Path, help='New outside-worktree stage directory')
    parser.add_argument('--apply-staged', type=Path, help='Explicitly write a prior successful overlay into --repo')
    args = parser.parse_args()
    repo = args.repo.resolve()
    try:
        if args.apply_staged:
            if args.target_ref or args.target_worktree or args.out:
                parser.error('--apply-staged excludes staging options')
            apply_overlay(repo, args.apply_staged.resolve(), args.packet.resolve())
            return 0
        if not args.out or bool(args.target_ref) == args.target_worktree:
            parser.error('Staging requires --out and exactly one of --target-ref/--target-worktree')
        output = args.out.resolve()
        if output == repo or repo in output.parents:
            raise Conflict('Staging output must be outside target worktree')
        return stage(repo, args.target_ref, args.packet.resolve(), output, args.target_worktree)
    except (Conflict, subprocess.CalledProcessError) as e:
        parser.exit(2, 'REFUSED: ' + str(e) + '\n')


if __name__ == '__main__':
    raise SystemExit(main())
