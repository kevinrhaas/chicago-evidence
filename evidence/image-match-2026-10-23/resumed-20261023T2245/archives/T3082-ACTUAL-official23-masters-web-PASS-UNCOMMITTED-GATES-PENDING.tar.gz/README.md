# T-3082 actual official 23-family export checkpoint

Both actual native producer phases completed with exit0 under the parent's
exclusive heavy grant: pinned Blender masters, then the native selected web
derivative command. ORCHESTRATION.json and both receipts/logs are preserved in
verification/. No downstream, publisher, Glessner materializer/repacker, browser,
full gate, code commit, PR or merge ran under this grant.

The written list is exactly the current23 frame masters, all normal UV/export
with no --no-bake or --ao. Every frozen producer/input and protected file held;
unrelated master and web manifest entries remain exact. All23 master recipe
stamps now equal the actual candidate input recipes, and all23 web entries name
their actual new master hashes. Root HEAD remains3fa, with ff808 staged as a
normal uncommitted merge, on the isolated T-3082 v2 topic.

Actual export readback is stronger than the earlier CPU proof: all22 non-target
masters and all22 non-target derivatives are byte-identical to3fa. For Tremont,
both the master and derivative retain exact binary chunks and all JSON except
three numbers: roof material RGB is precisely one quarter of its old values.
Geometry, UVs, confidence streams, nonroof materials, alpha and roughness remain
exact in the exported bytes. EXPORTED-SEMANTICS.json records all46 hashes and
the six precise master/web JSON scalar differences.

tree/ contains the actual46 GLBs, native manifests, four authored source files
and the one T-3082 changelog entry. current-full-diff.patch and current-status.txt
capture the uncommitted state, including the separately incoming fold; the
untracked entry is copied separately. Earlier authored and migrated preparation
checkpoints retain raw doc append guards and ticket claim/acceptance. Neither
the live code tree nor held Glessner outputs is needed to recover these exports.

The original T-2385 image-match ticket remains open/claimed and DIFFERS. The
quarter-linear roof is a reconstructed image-relative contrast choice, not a
finding about pigment, calibrated reflectance or historical weathering. Source
attribution and standing owner-approved project-use rights limits are unchanged;
there is no rights upgrade. The separately reviewed broad-left flag pose remains
unadopted. Canonical flag/global wind, source camera, time and lights were not
changed by this producer run.

Native source/render review, the actual name-pool/seating check, the ordered
downstream fixed point, preflight/full check and published mobile/desktop smoke
remain pending. Latest-parent migration may reuse these outputs only after an
actual current23 input-recipe proof; unchanged-looking code is not that proof.
No complete picture-match or original-ticket closure follows from this export.
