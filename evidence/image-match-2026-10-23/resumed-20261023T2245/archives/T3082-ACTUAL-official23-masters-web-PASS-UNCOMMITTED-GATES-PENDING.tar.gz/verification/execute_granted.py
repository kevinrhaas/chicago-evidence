from pathlib import Path
import datetime,json,os,subprocess,sys
run=Path(__file__).resolve().parent
runner=Path('/tmp/chicago-next-model/T-3082-official23-prep-3fa-20261024/run_official23.py')
state={'status':'RUNNING','root_exclusive_grant':True,'orchestrator_pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phases':[]}
def save():
 (run/'ORCHESTRATION.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for phase in ['masters','web']:
  argv=[sys.executable,str(runner),phase,'--run-id',run.name,'--root-heavy-granted']
  row={'phase':phase,'command':argv,'status':'RUNNING','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  state['phases'].append(row);save()
  with (run/('official-'+phase+'-runner.log')).open('x') as log:
   proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'TMPDIR':'/workspace/T3082-official23-tmp','PATH':'/workspace/shared/tools/usr/bin:'+os.environ.get('PATH',''),'PYTHONDONTWRITEBYTECODE':'1'})
   row['worker_pid']=proc.pid;save();code=proc.wait()
  row.update(exit_code=code,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='PASS' if code==0 else 'FAILED');save()
  assert code==0,phase+' worker failed; preserve receipt/log and stop'
  receipt=json.loads((run/('official-'+phase+'-receipt.json')).read_text());assert receipt['status']=='PASS'
 state['status']='PASS'
except BaseException as exc:
 state.update(status='FAILED',error=str(exc));save();raise
finally:
 state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(state,indent=2))
