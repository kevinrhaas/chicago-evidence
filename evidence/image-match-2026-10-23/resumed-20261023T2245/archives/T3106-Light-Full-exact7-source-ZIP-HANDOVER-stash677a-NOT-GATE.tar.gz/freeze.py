import pathlib,subprocess,json,hashlib,os,stat,zipfile,datetime
repo=pathlib.Path('/workspace/chicago');out=pathlib.Path('/workspace/T3106-source-handover-20261024')
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(b):return hashlib.sha256(b).hexdigest()
status=git('status','--porcelain=v1','-z','--untracked-files=all');(out/'status-before.z').write_bytes(status)
changes=git('diff','HEAD','--name-only','-z').split(b'\0');untracked=git('ls-files','--others','--exclude-standard','-z').split(b'\0');paths=sorted({os.fsdecode(p)for p in changes+untracked if p});assert len(paths)==7,paths
assert not git('diff','--cached','--name-only'), 'Preserve staged index separately if any staged change appears'
patch=git('diff','--binary','HEAD');(out/'all-dirty-source.patch').write_bytes(patch)
head=git('rev-parse','HEAD').decode().strip();branch=git('branch','--show-current').decode().strip();rows=[];payloads={}
for path in paths:
 p=repo/path;mode=stat.S_IMODE(p.lstat().st_mode);is_link=p.is_symlink();data=os.readlink(p).encode()if is_link else p.read_bytes()
 try:
  before=git('show',head+':'+path);entry=git('ls-tree',head,'--',path).decode().strip();git_mode,_,blob=entry.split('\t')[0].split();pre={'sha256':sha(before),'bytes':len(before),'git_mode':git_mode,'git_blob':blob};payloads['preimages/'+path]=(before,int(git_mode,8))
 except subprocess.CalledProcessError:pre=None
 rows.append({'path':path,'sha256':sha(data),'bytes':len(data),'posix_mode':oct(mode),'kind':'symlink'if is_link else'file','preimage':pre});payloads['source/'+path]=(data,(stat.S_IFLNK if is_link else stat.S_IFREG)|mode)
proofs={
 'light-MANIFEST.json':'/workspace/T3106-flora-prerequisite-20261024/MANIFEST.json',
 'light-RESULT.json':'/workspace/T3106-flora-prerequisite-20261024/RESULT.json',
 'light-NATIVE-CHECKS.json':'/workspace/T3106-flora-prerequisite-20261024/NATIVE-CHECKS.json',
 'light-SHRUB-ENVELOPE.json':'/workspace/T3106-flora-prerequisite-20261024/SHRUB-ENVELOPE.json',
 'light-app-QA-RESULT.json':'/workspace/T3106-flora-prerequisite-20261024/browser/QA-RESULT.json',
 'full-MANIFEST.json':'/workspace/T3106-full-flora-prerequisite-20261024/MANIFEST.json',
 'full-RESULT.json':'/workspace/T3106-full-flora-prerequisite-20261024/RESULT.json',
 'full-SOURCE-GUARDS.json':'/workspace/T3106-full-flora-prerequisite-20261024/SOURCE-GUARDS.json',
 'full-KEEP-CONTROLS.json':'/workspace/T3106-full-flora-prerequisite-20261024/KEEP-CONTROLS.json',
 'full-app-QA-RESULT.json':'/workspace/T3106-full-flora-prerequisite-20261024/browser/QA-RESULT.json'}
pr=[]
for name,path in proofs.items():
 b=pathlib.Path(path).read_bytes();payloads['native-proof/'+name]=(b,stat.S_IFREG|0o644);pr.append({'name':name,'original_path':path,'sha256':sha(b),'bytes':len(b)})
source={'status':'FROZEN_BEFORE_STASH','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repo':str(repo),'head':head,'branch':branch,'tracked_and_needed_untracked_paths':rows,'untracked_needed':[os.fsdecode(p)for p in untracked if p],'all_dirty_source_patch_sha256':sha(patch),'native_proof':pr,'limits':'Source recovery only; prior scoped native/mobile/desktop verdicts retained verbatim. No new check.sh/PR/merge/release acceptance. Ignored generated site/outputs are not source and are not stashed.'}
sourceb=(json.dumps(source,indent=2)+'\n').encode();(out/'SOURCE-MANIFEST.json').write_bytes(sourceb);payloads['SOURCE-MANIFEST.json']=(sourceb,stat.S_IFREG|0o644);payloads['all-dirty-source.patch']=(patch,stat.S_IFREG|0o644);payloads['status-before.z']=(status,stat.S_IFREG|0o644)
zip_path=out/'source-bundle.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for name,(b,mode)in sorted(payloads.items()):
  info=zipfile.ZipInfo(name);info.create_system=3;info.external_attr=mode<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
with zipfile.ZipFile(zip_path)as z:
 assert z.testzip()is None
 for name,(b,mode)in payloads.items():assert z.read(name)==b and (z.getinfo(name).external_attr>>16)==mode,(name,mode)
receipt={'status':'SOURCE_ZIP_HASH_MODE_CRC_PASS_BEFORE_STASH','zip_sha256':sha(zip_path.read_bytes()),'zip_bytes':zip_path.stat().st_size,'members':len(payloads),'source_manifest_sha256':sha(sourceb),'source_paths':len(rows),'needed_untracked':len(source['untracked_needed'])};(out/'ZIP-VERIFICATION.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
