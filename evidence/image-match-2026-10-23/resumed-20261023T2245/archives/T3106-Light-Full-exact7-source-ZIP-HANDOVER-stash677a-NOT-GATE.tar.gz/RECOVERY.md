# T-3106 clean source handover

All seven dirty tracked files, zero needed untracked files, are saved byte-for-byte in source-bundle.zip and named Git stash677a03673c6800df1121a5e6ede7f5699fafbab3. HANDOVER.json binds stash parent/tree and verified path hashes/modes. SOURCE-MANIFEST.json binds exact source bytes, POSIX permissions, Git preimages and the combined binary patch. ZIP CRC/hash/modes were verified; native proof JSON from both earlier closed packets is embedded.

/workspace/chicago remains on steward/t3106-1812-flora-prerequisite atda65119e52d6bb615bcdd72ef6dd14230e30414e with clean tracked/untracked status. No branch switch occurred. Ignored generated mirrors remain and must be regenerated for the next selected source.

For recovery, inspect the named stash by its full SHA and source manifest, or extract ZIP source/ entries with recorded permissions. Existing checkpoints397dc5 and79166 remain immutable. This is source preservation/handover only; it adds no PR, full gate or image-acceptance claim.
