import { readFileSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const base=new URL('./',import.meta.url);
const read=(folder,path)=>readFileSync(new URL(`${folder}/${path}`,base),'utf8');
const path='renderers/web/js/popup.js';
const escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
function renderer(text){const start=text.indexOf('function heldFlagHtml(s) {');const end=text.indexOf('\n}\n',start)+2;assert(start>=0&&end>start);return new Function('escapeHtml',`return (${text.slice(start,end)});`)(escape);}
const before=renderer(read('before',path)), after=renderer(read('candidate',path));
const reason='A review reason <script> & "quoted"';
const s=Object.freeze({review_required:true,touches_removal:true,review_reason:reason,confidence:'inferred',sources:Object.freeze(['existing_source'])});
const old=before(s), now=after(s);
assert(now.includes('<strong>Historical review context.</strong>'));
assert(!/held pending consultation|stops there until|been consulted/i.test(now));
const why=html=>html.match(/<em class="pop-held-why">(.*?)<\/em>/s)?.[1];
assert.equal(why(now),why(old));assert.equal(why(now),escape(reason));
assert.equal(s.review_reason,reason);assert.equal(s.review_required,true);assert.equal(s.touches_removal,true);
// Both existing surfaces retain exactly their old boolean conditions and call sites.
for(const text of [read('before',path),read('candidate',path)]) {
 assert.equal((text.match(/if \(s\.review_required === true\) flags\.push\(heldFlagHtml\(s\)\);/g)||[]).length,1);
 assert.equal((text.match(/s\.review_required === true \? `<div class="pop-flags">\$\{heldFlagHtml\(s\)\}<\/div>` : ''/g)||[]).length,1);
}
const lp='renderers/web/js/scene-loader.js';
// Loader executable bytes differ only in one diagnostic literal; comments excluded.
const strip=t=>t.replace(/^\s*\/\/.*$/gm,'');
const oldLiteral='review_required is set — this scene cannot be released';
const newLiteral='review_required is set — review annotation retained; this flag does not block scene release';
assert.equal(strip(read('before',lp)).replace(oldLiteral,newLiteral),strip(read('candidate',lp)));
const smoke='tools/smoke_renderer.mjs';
// All hard-problem filters remain byte-exact. No additional message is ignored.
const filters=t=>t.split('\n').filter(l=>/problems\.filter|reportedReviews|expectedReviews|JSON\.stringify\(reportedReviews\)/.test(l));
assert.deepEqual(filters(read('before',smoke)),filters(read('candidate',smoke)));
writeFileSync(new URL('light-checks.json',base),JSON.stringify({status:'PASS',scope:'pure extracted renderer and static diagnostic/control-flow checks; no browser/native/fullgate',reason_html_identical:true,flags_confidence_sources_unchanged:true,loader_control_flow_exact_except_diagnostic_literal:true,unexpected_error_filters_exact:true,boolean_conditions_both_surfaces_exact:true},null,2)+'\n');
console.log('PASS: reason/escaping/flags preserved, both surfaces unchanged, loader control-flow and hard-error filters exact');
