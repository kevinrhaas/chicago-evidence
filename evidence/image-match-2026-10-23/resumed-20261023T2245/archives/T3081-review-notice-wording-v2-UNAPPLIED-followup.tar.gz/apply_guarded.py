#!/usr/bin/env python3
"""Apply only to a separately approved follow-up checkout. Default is read-only."""
from pathlib import Path
import argparse, hashlib, json, os
p=argparse.ArgumentParser();p.add_argument('project_root',type=Path);p.add_argument('--apply',action='store_true');a=p.parse_args()
packet=Path(__file__).resolve().parent; guards=json.loads((packet/'input-guards.json').read_text()); pending=[]
for rel,g in guards.items():
 target=a.project_root/rel; candidate=packet/'candidate'/rel
 if hashlib.sha256(target.read_bytes()).hexdigest()!=g['before_sha256']:raise SystemExit('REFUSED changed preimage: '+rel)
 data=candidate.read_bytes()
 if hashlib.sha256(data).hexdigest()!=g['after_sha256']:raise SystemExit('REFUSED changed candidate: '+rel)
 pending.append((target,data))
if not a.apply:print('PASS: all 3 preimages/candidates exact; no writes (use --apply only in follow-up checkout)')
else:
 for target,data in pending:
  tmp=target.with_name(target.name+'.review-wording.tmp')
  with tmp.open('xb') as f:f.write(data)
  os.chmod(tmp,target.stat().st_mode);os.replace(tmp,target)
 print('APPLIED 3 wording/test-source files; run required checks before commit')
