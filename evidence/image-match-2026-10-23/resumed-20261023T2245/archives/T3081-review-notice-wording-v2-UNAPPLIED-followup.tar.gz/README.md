# Retained-review wording follow-up — UNAPPLIED

The floating popup and loader contain stale wording, not a current release veto. No new owner permission is needed. This v2 follows the parent’s instruction to use historical context rather than an approval-sounding heading. Authority: [AGENTS.md:130–146](https://github.com/kevinrhaas/chicago/blob/daaf276c4d3310f050dc96bbb67e8cfe80078388/chicago/4d/AGENTS.md#L130-L146). It explicitly retains `review_required`, `touches_removal`, their explanatory prose, and says **“They do not block a scene from being marked `released`”** (owner: **“Yes lift that”**). The former consultation prerequisite is superseded. Portable-human/source/date contracts remain unchanged.

## Exact trace

- `renderers/web/js/popup.js:898–906`, `heldFlagHtml`: synthesizes “Held pending consultation” and “stops there until … consulted”; the function is called by floating-card head at972 and Inspect People at1578. That standing text is not the record’s reason. `.pop-held-why` renders the existing escaped, trimmed `review_reason` unchanged. All data/reasons/confidence remain untouched, including historical prose that independently still describes the former policy.
- `renderers/web/js/scene-loader.js:435–438`: appends “review_required is set — this scene cannot be released” to `problems`, then continues to asset/registry creation. No return/throw/skip or released-state change occurs in this branch. `main.js:1961` copies those diagnostics; `5489–5499` marks readiness through the boot barrier independently and prints problems in DEBUG. Actual asset failures, index mismatches and boot-barrier failures remain independent.
- `tools/validate.py:586–588` already lifts review annotations as release vetoes. `tools/test_validate.py:90–124` already asserts flagged structure/household/person/card release, flags retained, reasons required and the independent date gate. `tools/measure_review_constraint.py:137–143,279–319` exercises the actual validator with released=True and fails if a review flag still blocks release. These are evidence and remain unchanged; not rerun here.

## Minimal proposed adoption

Exactly three tracked files in `proposal.patch`, guarded against exact before/after SHA256s in `input-guards.json`:

1. `renderers/web/js/popup.js`: the heading becomes **“Historical review context.”**, followed by **“The reason for review is recorded below. Sources remain available with this record.”** Both existing surfaces, flags, reason interpolation/escaping, CSS classes and internal helper name stay unchanged; nearby comments align with the owner ruling.
2. `renderers/web/js/scene-loader.js`: retains the same boolean branch and one diagnostic, now **“review_required is set — review annotation retained; this flag does not block scene release”**. The existing prefix is retained; no problem is removed or ignored. Comment corrected.
3. `tools/smoke_renderer.mjs`: update the two popup-text expectations (currently9259 and9928) and stale review-blocker labels/comments. Exact flagged-ID assertions, reason equality, unflagged control, DOM accessibility, unexpected-error filters and every other check remain byte-exact. No gate is weakened. Keeping the old private helper/CSS names avoids unrelated churn.

`apply_guarded.py <project_root>` checks all three preimages before any write; default is read-only. Only the parent should apply with `--apply` in a coordinated follow-up checkout, such as T3082 before its native/fullgate run. PR1260 and its current exact6bf verification must stay untouched. No live PR or QA was modified here. It does not create a ticket, claim work, stage, commit or run gates. The project’s required checks still precede any eventual commit.

## Published QA map — future run only

Do **not** mutate `/tmp/T3081-published-qa-v4-20261024` or its current receipts/manifests. Its `models.json:189–222` freezes exact14 review IDs and the exact old messages. `review-notices.mjs:4–10` compares both IDs and complete messages and rejects every other problem; `qa-published.mjs:115–116` propagates those failures. This exact gate correctly rejects the proposed wording while its old expectations are in force.

For a new, separately versioned QA packet after this wording ships, use `future-notice-expectations.json` as the bounded update of **only** `scene_review_notices.legacy_messages` and the explanatory `semantics` text. IDs and all five models/cameras/source/credit/geometry/contact expectations remain unchanged. The property name `legacy_messages` can stay to avoid unrelated harness changes. The original `checkReviewNotices` function requires no code change: preserving its exact matching keeps missing, duplicated, altered or new notices and unexpected problems as failures. Rebind the new packet’s authored source hashes and fresh runtime evidence; do not relabel old results. Fresh mobile/desktop card verification and the ordinary relevant checks remain owed by that follow-up; none was run here.

## Bounded LIGHT verification

- All3 candidate JS syntax checks PASS (`node --check`).
- `check_proposal.mjs`: same escaped full reason; frozen input flags/source/confidence unchanged; both exact boolean call-sites preserved; loader executable bytes differ only in its diagnostic literal; existing hard-problem filters and exact flagged-ID comparisons preserved.
- `check_future_notices.mjs`: same14 IDs; future exact messages pass; missing/duplicate/changed/new/unknown notices and registry drift fail. The original v4 expectation correctly rejects future wording. No catch-all allowlist is introduced.
- Guarded apply dry-run against captured worktree preimages PASS, no writes. No native writers, full suites/gates, browsers, assets, record changes or release-policy edits.

The packet is an UNAPPLIED follow-up proposal. It does not change the current image gate, source confidence, historical record prose, consultation history, review flag propagation or the full PR1260 QA verdict.
