// Retained flags are evidence, not new permission requirements. No catch-all allowlist.
export function checkReviewNotices(expected,declared,problems){
 const sort=x=>[...x].sort(),same=(a,b)=>JSON.stringify(sort(a))===JSON.stringify(sort(b));
 const reported=problems.filter(p=>/review_required is set/.test(p));
 const reportedIds=reported.map(p=>p.split(':',1)[0]);
 const unexpected=problems.filter(p=>!expected.legacy_messages.includes(p));
 const failures=[];
 if(!same(declared,expected.ids))failures.push('Registry review flags differ from the frozen exact scene scene set');
 if(!same(reportedIds,expected.ids)||!same(reported,expected.legacy_messages))failures.push('Reported review notices differ from their frozen exact scene IDs/messages');
 if(unexpected.length)failures.push('Unexpected native app problems: '+unexpected.join(' | '));
 return {expected_ids:expected.ids,registry_declared_ids:declared,reported_ids:reportedIds,legacy_messages:reported,unexpected_problems:unexpected,semantics:expected.semantics,failures};
}
