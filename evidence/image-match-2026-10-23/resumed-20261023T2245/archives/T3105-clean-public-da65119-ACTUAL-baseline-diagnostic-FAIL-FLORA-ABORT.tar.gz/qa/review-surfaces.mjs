// Passed directly to Playwright evaluate: no module closures inside the page function.
export async function readReviewSurfaceInPage({id,surface}) {
 const a=window.__chicago4d,record=a.registry.get(id);
 if(!record?.sidecar)throw Error('Missing actual review record: '+id);
 const overlay=await a.readerText();
 const {say}=await import('/walk/js/reader-text.js');
 if(surface==='popup'&&!a.pick(id))throw Error('Native popup did not open: '+id);
 const root=surface==='popup'?document.getElementById('popup'):
  document.querySelector('#nav-app-inspect [data-insp-pane="people"]');
 if(!root)throw Error('Missing actual review surface '+surface);
 const nodes=[...root.querySelectorAll('.pop-flag-held')],node=nodes[0];
 if(node)node.scrollIntoView({block:'center'});
 const clean=node?.cloneNode(true);clean?.querySelectorAll('.pop-held-why').forEach(n=>n.remove());
 const normalize=s=>String(s??'').replace(/\s+/g,' ').trim();
 return {surface,id,raw_review_required:record.sidecar.review_required??null,
  raw_touches_removal:record.sidecar.touches_removal??null,
  raw_reason:record.sidecar.review_reason??null,
  reader_reason:say(record.sidecar.review_reason??'',overlay,'review_reason').trim(),
  node_count:nodes.length,heading:node?.querySelector('strong')?.textContent?.trim()??'',
  standing_text:normalize(clean?.textContent),rendered_reason:node?.querySelector('.pop-held-why')?.textContent?.trim()??'',
  reason_count:node?.querySelectorAll('.pop-held-why').length??0,
  inside_folded_details:!!node?.closest('details'),
  visible:!!node&&node.getClientRects().length>0&&getComputedStyle(node).visibility!=='hidden'};
}

export function checkReviewSurface(expected,actual) {
 const failures=[],where=actual.surface+': ';
 if(actual.raw_review_required!==expected.review_required)failures.push(where+'review flag changed');
 if(actual.raw_touches_removal!==expected.touches_removal)failures.push(where+'removal flag changed');
 if(actual.raw_reason!==expected.review_reason)failures.push(where+'raw recorded reason changed');
 if(expected.review_required===true){
  if(actual.node_count!==1||!actual.visible||actual.inside_folded_details)failures.push(where+'review context missing, duplicated, hidden or folded');
  if(actual.heading!=='Historical review context.')failures.push(where+'review heading is not the approved exact wording');
  if(actual.standing_text!=='Historical review context. The reason for review is recorded below. Sources remain available with this record.')failures.push(where+'synthesized review text changed or retains a false consultation hold');
  if(actual.reason_count!==1||!actual.reader_reason||actual.rendered_reason!==actual.reader_reason)failures.push(where+'record reason is not preserved through the native reader overlay');
 }else if(actual.node_count!==0)failures.push(where+'unflagged control acquired a review annotation');
 return failures;
}
