import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire('/workspace/shared/node/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const root='/tmp/st-mary-picture-20261025/site',sid='st_marys_church';
const home='/tmp/st-mary-runtime-20261025',out=process.env.ST_MARY_APP_OUT||path.join(home,'app-qa');fs.mkdirSync(out);
const expected=JSON.parse(fs.readFileSync(path.join(home,'APP-EXPECTED.json')));
const expectedWEB='9058e91e464a1fbbf773eddfaffddf73304e67f3712cc9ca8e47ae7820465207';
const write=(name,x)=>fs.writeFileSync(path.join(out,name),JSON.stringify(x,null,2)+'\n');
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon'};
const serverErrors=[];
const server=http.createServer((req,res)=>{try{
 let file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
 if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
 if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
 if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
 res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');
 const stream=fs.createReadStream(file);stream.on('error',e=>{serverErrors.push(e.message);res.destroy(e);});stream.pipe(res);
}catch(e){serverErrors.push(e.message);res.writeHead(500).end();}});
async function settle(page){await page.locator('.navigator').evaluate(async n=>{
 for(let k=0;k<4;k++){const active=n.getAnimations().filter(a=>Number.isFinite(a.effect.getComputedTiming().endTime));if(!active.length)return;await Promise.all(active.map(a=>a.finished.catch(e=>{if(e.name!=='AbortError')throw e;})));}
});}
async function pane(page,key){await page.locator(`#nav-app-inspect [data-insp-tab="${key}"]`).click();await page.waitForFunction(k=>document.querySelector(`#nav-app-inspect [data-insp-pane="${k}"]`)?.dataset.filled==='yes',key,{timeout:45000});await settle(page);return page.locator(`#nav-app-inspect [data-insp-pane="${key}"]`);}
async function observe(page,target,label,key){
 const x=await target.evaluate(p=>({text:p.innerText,links:[...p.querySelectorAll('a')].filter(a=>a.checkVisibility()).map(a=>a.href),visible:p.checkVisibility(),pageOverflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1}));
 write(`${label}-${key}.json`,x);assert(x.visible);assert(!x.pageOverflow);assert(!x.paneOverflow);await page.screenshot({path:path.join(out,`${label}-${key}.png`)});return x;
}
let browser;const results=[];
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE||'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 for(const [label,width,height,touch] of [['mobile',390,780,true],['desktop',1280,800,false]]){
  const context=await browser.newContext({viewport:{width,height},hasTouch:touch,deviceScaleFactor:touch?2:1});const errors=[],network=[],cancelled=[],responses=[],responseWork=[];let page;
  try{
   await context.addInitScript(()=>localStorage.setItem('chicago4d.researcher','on'));
   page=await context.newPage();page.setDefaultTimeout(90000);page.on('pageerror',e=>errors.push(e.message));
   page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});if(r.url().endsWith('st_marys_church__frame_1833.glb'))responseWork.push(r.body().then(b=>responses.push({url:r.url(),status:r.status(),bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')})));});
   page.on('requestfailed',r=>{const v={url:r.url(),failure:r.failure()};if(r.failure()?.errorText==='net::ERR_ABORTED')cancelled.push(v);else network.push(v);});
   const navStart=Date.now();const response=await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835&keep-geometry=1`);assert.equal(response.status(),200);
   await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:240000,polling:1000});const readyAt=Date.now();console.log(`${label}: actual APIready after ${readyAt-navStart}ms`);
   await page.evaluate(async sid=>{const a=window.__chicago4d,end=Date.now()+90000;while(a.welcome?.state!=='world'&&Date.now()<end){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}if(a.welcome&&a.welcome.state!=='world')throw Error('welcome did not enter world');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.setAnimationHold(true);a.navigator.dock();if(!a.frame(sid))throw Error('St Mary cannot frame');await a.capture(1);},sid);const worldAt=Date.now();console.log(`${label}: actual welcome/world/firsttargetcapture after ${worldAt-navStart}ms`);
   const data=await page.evaluate(sid=>{const a=window.__chicago4d,s=a.registry.get(sid)?.sidecar;return{grade:s?.grade,attributes:s?.attributes,phase:s?.phase,placement:s?.placement,bounds:a.buildings.instanceBounds()[sid],matrix:a.buildings.matrixOf(sid)?.elements,feet:a.buildings.feetOf(sid),problems:a.problems??[],expectedReviews:[...a.registry.values()].filter(r=>r.sidecar?.review_required).map(r=>r.sidecar.id).sort(),scene:a.scene?.id};},sid);
   write(`${label}-diagnostic.json`,{data,errors,network});assert.equal(data.scene,'1835');assert.equal(data.phase,'frame_1833');assert.deepEqual(data.grade,expected.grade);
   for(const[k,v]of Object.entries(expected.attributes)){assert.deepEqual(data.attributes[k]?.value,v.value,k+' value');assert.equal(data.attributes[k]?.confidence,v.confidence,k+' confidence');}
   for(const[k,v]of Object.entries(expected.placement))assert.deepEqual(data.placement[k],v,'placement '+k);
   assert(data.bounds.size.every(x=>Number.isFinite(x)&&x>0));assert.deepEqual(data.problems.filter(p=>/review_required is set/.test(p)).map(p=>p.split(':',1)[0]).sort(),data.expectedReviews);
   const unexpected=data.problems.filter(p=>!/provisional|PLACEHOLDER|placeholder|review_required is set/i.test(p));assert.deepEqual(unexpected,[]);
   const poses=[];
   for(const kind of ['full']){
    const pose=await page.evaluate(async({sid,kind,mobile})=>{
     const a=window.__chicago4d,s=a.registry.get(sid).sidecar,b=a.buildings.instanceBounds()[sid],m=a.buildings.matrixOf(sid).elements,poly=s.footprint.polygon;
     const loU=Math.min(...poly.map(x=>x[0])),hiU=Math.max(...poly.map(x=>x[0])),hiV=Math.max(...poly.map(x=>x[1]));
     const world=(u,v,y)=>({e:m[0]*u+m[4]*y-m[8]*v+m[12],n:-(m[2]*u+m[6]*y-m[10]*v+m[14]),y:m[1]*u+m[5]*y-m[9]*v+m[13]});
     const midU=(b.min[0]+b.max[0])/2,midV=-(b.min[2]+b.max[2])/2;
     const aim=kind==='full'?world(midU,midV,(b.min[1]+b.max[1])/2):world((loU+hiU)/2,hiV,2.4);a.setFly(true);let result;
     for(let scale=1;scale<=3;scale+=.25){
      const eye=kind==='full'?world(midU-18*scale,hiV+20*scale,9*scale):world((loU+hiU)/2,hiV+(mobile?18:10),2.4);
      const yaw=Math.atan2(aim.e-eye.e,aim.n-eye.n)*180/Math.PI,pitch=Math.atan2(aim.y-eye.y,Math.hypot(aim.e-eye.e,aim.n-eye.n))*180/Math.PI;
      a.walker.teleport({local_e:eye.e,local_n:eye.n,yaw_deg:yaw,pitch_deg:pitch,altitude_m:eye.y-a.walker.surfaceAt(eye.e,eye.n)});await a.capture(1);
      const corners=[];for(const u of [b.min[0],b.max[0]])for(const v of [-b.max[2],-b.min[2]])for(const y of [b.min[1],b.max[1]]){const w=world(u,v,y);corners.push({...w,...a.project(w.e,w.n,w.y)});}
      result={kind,eye,aim,yaw,pitch,scale,corners,state:{...a.walker.state},liveFly:{walker:a.walker.state.flying,hud:a.hud.flying,intent:a.intent.flying}};
      if(kind==='front'||corners.every(c=>Math.abs(c.x)<.88&&Math.abs(c.y)<.88&&c.z>-1&&c.z<1))break;
     }
     if(kind==='full'&&!result.corners.every(c=>Math.abs(c.x)<.88&&Math.abs(c.y)<.88&&c.z>-1&&c.z<1))throw Error('full model does not fit view');return result;
    },{sid,kind,mobile:touch});poses.push(pose);write(`${label}-${kind}-pose.json`,pose);
    for(const[view,on]of[['normal',false],['confidence',true]]){await page.evaluate(async on=>{const a=window.__chicago4d;a.setConfidenceView(on);await a.capture(1);},on);await page.screenshot({path:path.join(out,`${label}-${kind}-${view}.png`)});const x=await page.evaluate(()=>{const a=window.__chicago4d;return{...a.stats(),confidenceView:a.confidenceView,flying:a.walker.state.flying,hudFlying:a.hud.flying,intentFlying:a.intent.flying};});write(`${label}-${kind}-${view}-stats.json`,x);assert.equal(x.confidenceView,on);assert(x.flying&&x.hudFlying&&x.intentFlying);assert(x.withinBudget,`${label}/${kind}/${view} budget`);}
   }
   await page.evaluate(async sid=>{const a=window.__chicago4d;a.setConfidenceView(false);a.pick(sid);await a.navigator.select('inspect');a.navigator.open(2);},sid);await page.waitForFunction(sid=>document.querySelector('#nav-app-inspect')?.dataset.structure===sid,sid);
   const photosPane=await pane(page,'photos');await photosPane.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});const photos=await observe(page,photosPane,label,'photos');assert.match(photos.text,/Andreas/i);assert(photos.text.includes("Saint Mary's Church"));assert.match(photos.text,/Moss Engraving Co/i);
   const sourcesPane=await pane(page,'sources');await sourcesPane.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});const sources=await observe(page,sourcesPane,label,'sources');assert.match(sources.text,/Andreas/i);assert.match(sources.text,/A pictured chapel form for St Mary/i);
   const liberty=sourcesPane.locator('.src-lib').filter({hasText:'A pictured chapel form for St Mary'});assert.equal(await liberty.count(),1);await liberty.locator(':scope > summary').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(out,`${label}-building-liberty.png`)});write(`${label}-building-liberty.json`,{visible:await liberty.isVisible(),text:await liberty.innerText()});
   const contacts=await page.evaluate(async sid=>{
    const a=window.__chicago4d,s=a.registry.get(sid).sidecar,m=a.buildings.matrixOf(sid).elements,poly=s.footprint.polygon,us=poly.map(x=>x[0]),u=9.5504+Math.min(...us),v=Math.max(...poly.map(x=>x[1]));
    const expected={e:m[0]*u-m[8]*v+m[12],n:-(m[2]*u-m[10]*v+m[14])};const doc=await fetch('../data/enclosures/town_entrance_aprons.json').then(r=>{if(!r.ok)throw Error('native entrances unavailable');return r.json();});const doors=doc.entrances.filter(x=>x.structure_id===sid);if(doors.length!==1)throw Error('unexpected primary entrance count');const door=doors[0],angle=door.bearing_deg*Math.PI/180,outward={e:Math.sin(angle),n:Math.cos(angle)};a.setFly(false);a.navigator.dock();const samples=[];
    for(const distance of [3,2]){const e=door.at_local_enu_m[0]+outward.e*distance,n=door.at_local_enu_m[1]+outward.n*distance;a.walker.teleport({local_e:e,local_n:n,yaw_deg:(door.bearing_deg+180)%360});await a.capture(1);samples.push({distance,e,n,water:a.terrain.isWater(e,n),surface:a.walker.surfaceAt(e,n),routed:a.router.heightAt(e,n),blocked:a.router.blockedAt(e,n),ground:a.walker.state.groundY,eye:a.walker.state.eyeY,actualE:a.walker.state.e,actualN:a.walker.state.n,flying:a.walker.state.flying,hudFlying:a.hud.flying,intentFlying:a.intent.flying});}
    const innerE=door.at_local_enu_m[0]+outward.e,innerN=door.at_local_enu_m[1]+outward.n;
    return{expected,door,samples,conservativeInnerProbe:{distance:1,e:innerE,n:innerN,blocked:a.router.blockedAt(innerE,innerN),why:'Unchanged route.js uses radius+inflate+cell*sqrt(.5) footprint inflation; 1m is inside its conservative clearance. No visitor is placed there and no indoor traversal is claimed.'}};
   },sid);write(`${label}-ground-contacts.json`,contacts);assert(Math.hypot(contacts.expected.e-contacts.door.at_local_enu_m[0],contacts.expected.n-contacts.door.at_local_enu_m[1])<.011);assert.equal(contacts.door.width_m,.92);
   for(const c of contacts.samples){assert(!c.water);assert.equal(c.blocked,false);assert(!c.flying&&!c.hudFlying&&!c.intentFlying);assert(Math.abs(c.ground-c.surface)<1e-6);assert(c.eye>c.ground&&Number.isFinite(c.routed));assert(Math.hypot(c.actualE-c.e,c.actualN-c.n)<.01);}
   await page.screenshot({path:path.join(out,`${label}-ground-contact.png`)});await Promise.all(responseWork);assert(responses.length);assert(responses.every(r=>r.status===200&&r.sha256===expectedWEB));assert.deepEqual(errors,[]);assert.deepEqual(network,[]);assert.deepEqual(serverErrors,[]);
   const result={status:'PASS',timings:{navigation_to_api_ready_ms:readyAt-navStart,navigation_to_world_first_target_capture_ms:worldAt-navStart,viewport_total_ms:Date.now()-navStart},viewport:label,width,height,errors,network,cancelled,servedTargetWEB:responses,loaderUnexpected:unexpected,poses,contacts,photos,sources,limit:'Actual targeted published app review, not full renderer smoke or source-picture acceptance.'};results.push(result);write(`${label}-result.json`,result);console.log(`${label}: actual app/grade/Images/Sources/liberty/grounded entry PASS`);
  }catch(e){write(`${label}-failure.json`,{message:e.message,stack:e.stack,errors,network,cancelled,responses});if(page)await page.screenshot({path:path.join(out,`${label}-failure.png`)}).catch(()=>{});throw e;}
  finally{await context.close();}
 }
 write('results.json',{status:'PASS',results,serverErrors});
}finally{if(browser)await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));}
