from pathlib import Path
import json,numpy as np
from PIL import Image
from scipy.ndimage import map_coordinates,binary_closing,binary_opening,label,find_objects
src=Path('/tmp/st-mary-picture-20261025/chicago/reference/images/chicago/chicago_st_marys_church_1843.jpg');I=np.asarray(Image.open(src).convert('L'))
# The four same-wall corners already recorded in the original coarse landmark file;
# this is a planar ratio measurement, not a changed model or camera fit.
xy=np.array([[1060,2329],[136,2146],[136,1748],[1060,1548]],float);uv=np.array([[0,0],[1,0],[1,1],[0,1]],float)
M=[];b=[]
for(x,y),(u,v)in zip(xy,uv):M.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);b.extend([u,v])
h=np.r_[np.linalg.solve(np.array(M),np.array(b)),1].reshape(3,3);inv=np.linalg.inv(h);N=800;yy,xx=np.mgrid[0:N,0:N];q=np.stack([xx.ravel()/(N-1),1-yy.ravel()/(N-1),np.ones(N*N)]);p=inv@q;p/=p[2];rect=map_coordinates(I,[p[1],p[0]],order=1).reshape(N,N)
rows=[]
for threshold in [100,140,180]:
 bw=rect<threshold;vertical=binary_opening(binary_closing(bw,structure=np.ones((5,1))),structure=np.ones((32,1)));lab,num=label(vertical)
 comps=[]
 for n,sl in enumerate(find_objects(lab),1):
  if sl is None:continue
  y,x=sl;height=y.stop-y.start;width=x.stop-x.start
  if height>=130 and x.start>30 and x.stop<N-20 and y.start<500:
   comps.append({'x':(x.start,x.stop),'y':(y.start,y.stop),'height':height,'width':width,'sill_fraction':1-y.stop/(N-1),'head_fraction':1-y.start/(N-1)})
 rows.append({'threshold':threshold,'components':comps})
out=Path('/tmp/Mary1334-sash-proportion-proposal-20261026');out.mkdir(exist_ok=True);(out/'PLANAR-VERTICAL-STROKES.json').write_text(json.dumps({'source':str(src),'source_px':[I.shape[1],I.shape[0]],'existing_samewall_quad_px':xy.tolist(),'source_to_wall_fraction_homography':h.tolist(),'measurement_only_no_camera_or_geometry_changes':True,'grid':N,'threshold_readings':rows},indent=2)+'\n');print(json.dumps(rows,indent=2))
