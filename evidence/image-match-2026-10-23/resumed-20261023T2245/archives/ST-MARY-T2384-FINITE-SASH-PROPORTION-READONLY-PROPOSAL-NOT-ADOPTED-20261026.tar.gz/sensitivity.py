from pathlib import Path
import json,numpy as np
P=Path('/tmp/Mary1334-sash-proportion-proposal-20261026');d=json.loads((P/'PLANAR-VERTICAL-STROKES.json').read_text());quad=np.array(d['existing_samewall_quad_px']);uv=np.array([[0,0],[1,0],[1,1],[0,1]])
def H(xy):
 A=[];b=[]
 for(x,y),(u,v)in zip(xy,uv):A.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);b.extend([u,v])
 return np.r_[np.linalg.solve(A,b),1].reshape(3,3)
h=H(quad);inv=np.linalg.inv(h);endpoints=[];summary=[]
for row in d['threshold_readings']:
 comps=[c for c in row['components'] if c['height']>=330 and c['y'][0]<110 and c['y'][1]>430 and c['x'][1]<620]
 summary.append({'threshold':row['threshold'],'count':len(comps),'sill_range':[min(c['sill_fraction']for c in comps),max(c['sill_fraction']for c in comps)],'head_range':[min(c['head_fraction']for c in comps),max(c['head_fraction']for c in comps)]})
 if row['threshold']==140:
  for c in comps:
   x=sum(c['x'])/2/799
   for z in [c['sill_fraction'],c['head_fraction']]:
    p=inv@np.array([x,z,1]);endpoints.append(p/p[2])
pts=np.array(endpoints).T;rng=np.random.default_rng(2384);bands=[]
for jitter in [10,20]:
 vals=[]
 for _ in range(1000):
  q=quad+rng.uniform(-jitter,jitter,(4,2));p=H(q)@pts;p/=p[2];vals.append(p[1])
 vals=np.array(vals);s=vals[:,0::2];heads=vals[:,1::2];centres=(s+heads)/2
 bands.append({'corner_jitter_px':jitter,'samples':1000,'sill_global_range': [float(s.min()),float(s.max())],'head_global_range':[float(heads.min()),float(heads.max())],'median_centre_sample_range':[float(np.median(centres,axis=1).min()),float(np.median(centres,axis=1).max())],'median_centre_implied_translation_m_at_retained_wall3_2': [float((np.median(centres,axis=1).min()-(.95+1.4322/2)/3.2)*3.2),float((np.median(centres,axis=1).max()-(.95+1.4322/2)/3.2)*3.2)]})
out={'method':'Existing four same-facade base/eave landmarks; threshold-separated long casing strokes; seeded corner-jitter sensitivity. Not surveyed metric or probability/confidence interval. Thresholds are alternative raster readings, not independent observations.','seed':2384,'thresholds':summary,'sensitivity':bands,'proposed_sill_m':1.4,'delta_m':.45,'retained_wall_m':3.2,'retained_sash_size_m':[.7656,1.4322],'proposed_head_m':2.8322,'head_limit_m':2.92,'old_sill_m':.95,'reconstruction_grade':'reconstructed','source_date_limit':'Undated appearance in Andreas1884, not a calibrated1835 elevation; source filename1843 is not depiction date.','no_source_or_camera_edits':True}
(P/'PROPORTION-SENSITIVITY.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
