
## L-green-tree-enclosed-left-reading-2376 — optional undated enclosed annex group

**Covers:** optional candidate `green_tree_tavern` version `andreas-reading`, the optional `enclosed_left_annex` group only; not the canonical Trowbridge open wagon bay.

**Decision:** The Andreas and Kurz depictions show three lower enclosed facades/roof categories beside the main inn: shoulder, low connector and farther-left gabled range. That occurrence is inferred retrospective form. All spans, depths, heights, slopes, local side assignment/setback, opening stations/sections, timber profiles/colors and hidden treatment are reconstructed first diagnostic fits, not dimensions measured from a drawing. No tenant identity, authentic interior or chronology is invented. The existing corrected main block and default open-bay reconstruction remain unchanged. The proposed optional geometry has a known12.96m² overlap with the procedural bay; it is not app-qualified until a future owned run resolves that concrete integration conflict without silently hiding or re-dating canonical props.

**Source:** `andreas_1884_green_tree_hotel_plate`, `kurz_allison_1893` panel11, and the already-held testimony under `chicagology_prefire127`. The original Andreas plate gives no1838 date. Taylor's1834arrival does not date his recalled lodging; noJuly1835continuity is asserted. The unverified/check_required1859 photograph supplies no geometry or derived asset.

**Recorded:** 2026-10-29, external implemented model-only next-batch candidate; no export or app qualification.

**Ticket:** T-2376, the original image-match case; no new photo follow-up.
