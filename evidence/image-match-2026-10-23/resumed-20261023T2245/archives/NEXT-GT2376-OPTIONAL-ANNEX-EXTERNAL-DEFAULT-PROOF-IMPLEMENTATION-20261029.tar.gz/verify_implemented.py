from pathlib import Path
import sys,types,importlib.util,json,math,hashlib,time,dataclasses,copy
sys.dont_write_bytecode=True
out=Path('/tmp/green-tree-enclosed-annex-next-20261029');root=Path('/tmp/tremont-picture-20261026/chicago/4d');base=out/'implementation-base/chicago/4d';cand=out/'implemented/chicago/4d';start=time.monotonic()
sys.path.insert(0,str(root/'generators'));sys.modules['bpy']=types.ModuleType('bpy')
from common import mesh
# Actual native accumulation methods; only final Blender material/object creation
# is replaced in this process. No .blend, export, native worker or app write.
def capture(self,mats=None):return {'verts':self.verts,'faces':self.faces,'confidence':self.conf,'materials':mats,'mat_index':self.mat_index,'named':self.named}
mesh.MeshBuilder.to_object=capture
mesh.simple_material=lambda name,rgba,roughness=.75: {'name':name,'rgba':rgba,'roughness':roughness}
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=module('annex_old_params',base/'generators/archetypes/frame_tavern_params.py');new=module('annex_new_params',cand/'generators/archetypes/frame_tavern_params.py')
def producer(name,path,params):
 sys.modules['archetypes.frame_tavern_params']=params
 return module(name,path)
of=producer('annex_old_producer',base/'generators/archetypes/frame_tavern.py',old);nf=producer('annex_new_producer',cand/'generators/archetypes/frame_tavern.py',new)
entries=json.loads((root/'assets/manifest.json').read_text())['assets'];compared=[]
input_paths={root/'assets/manifest.json',root/'generators/common/mesh.py',root/'generators/common/openings.py',root/'generators/common/materials.py'}
for e in entries.values():
 if e.get('archetype')=='frame_tavern':input_paths.add(root/'data/structures'/f"{e['structure_id']}.json")
for rp in (root/'data/structures/versions').rglob('*.json'):
 if json.loads(rp.read_text()).get('archetype')=='frame_tavern':input_paths.add(rp)
input_paths.update([base/'generators/archetypes/frame_tavern_params.py',base/'generators/archetypes/frame_tavern.py',cand/'generators/archetypes/frame_tavern_params.py',cand/'generators/archetypes/frame_tavern.py',cand/'data/structures/versions/green_tree_tavern/andreas-reading.json'])
input_before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in input_paths}
for name,e in entries.items():
 if e.get('archetype')!='frame_tavern':continue
 r=json.loads((root/'data/structures'/f"{e['structure_id']}.json").read_text());ph=next(ph for ph in r['phases'] if ph['id']==e['phase_id']);a=old.from_phase(ph,r);b=new.from_phase(ph,r)
 d=dataclasses.asdict(b);assert d.pop('enclosed_left_annex') is None;assert d==dataclasses.asdict(a)
 before=of.build(a,name);after=nf.build(b,name);assert before==after,name
 compared.append({'asset':name,'vertices':len(after['verts']),'polygons':len(after['faces'])})
for rp in (root/'data/structures/versions').rglob('*.json'):
 r=json.loads(rp.read_text())
 if r.get('archetype')!='frame_tavern':continue
 for ph in r['phases']:
  a=old.from_phase(ph,r);b=new.from_phase(ph,r);assert of.build(a,'version-default-control')==nf.build(b,'version-default-control'),str(rp)
  compared.append({'version_control':str(rp.relative_to(root)),'phase':ph['id']})
r=json.loads((cand/'data/structures/versions/green_tree_tavern/andreas-reading.json').read_text());p=new.from_phase(r['phases'][0],r);obj=nf.build(p,'green_tree_tavern__frame_1833')
assert all(math.isfinite(v) for pt in obj['verts'] for v in pt)
assert all(0<=n<=1 for n in obj['confidence'])
# The new component itself must be finite, non-degenerate and entirely R.
b=mesh.MeshBuilder('annex-only-capture');nf._enclosed_left_annex(b,p,p.width_m,p.depth_m)
for f in b.faces:
 points=[b.verts[i] for i in f];assert len(set(points))>=3
 n=[0.,0.,0.]
 for a,c in zip(points,points[1:]+points[:1]):
  n[0]+=(a[1]-c[1])*(a[2]+c[2]);n[1]+=(a[2]-c[2])*(a[0]+c[0]);n[2]+=(a[0]-c[0])*(a[1]+c[1])
 assert sum(k*k for k in n)>1e-18,points
assert set(b.conf)=={1.0}
invalid=[]
def case(name,edit):
 q=copy.deepcopy(p.enclosed_left_annex);edit(q);invalid.append((name,{'enclosed_left_annex':q}))
case('missing group part',lambda q:q.pop('connector'))
case('extra unsupported part',lambda q:q.update(extra={}))
case('wrong attach face',lambda q:q.update(attach_face='x_min'))
case('boolean setback',lambda q:q.update(front_setback_m=True))
case('non-finite span',lambda q:q['shoulder'].update(span_m=float('nan')))
case('negative depth',lambda q:q['connector'].update(depth_m=-1))
case('wrong connector roof',lambda q:q['connector'].update(roof='gable'))
case('invented connector opening',lambda q:q['connector'].update(front_openings=['door']))
case('roof inverted',lambda q:q['shoulder'].update(roof_high_m=2))
case('roof crosses main eave',lambda q:q['shoulder'].update(front_gable_peak_m=6))
case('wrong boarding axis',lambda q:q['boarding_range'].update(ridge_axis='x'))
case('door and window overlap',lambda q:q['boarding_range'].update(front_door=[.65,1.,2.]))
case('light breaks roof',lambda q:q['boarding_range'].update(front_gable_light=[.5,4.1,.65,.7]))
case('boolean opening width',lambda q:q['shoulder'].update(front_window=[.5,.7,True,1.5]))
for name,fields in [('nonmapping group',{'enclosed_left_annex':[]}),('wrong scheme',{'elevation_scheme':'frontage'}),('log wing collision',{'log_wing':True}),('cross wing collision',{'cross_wing':True}),('gallery collision',{'gallery':True}),('claimed non-R metrics',{'confidence':{**p.confidence,'enclosed_left_annex':'inferred'}})]:invalid.append((name,fields))
for name,change in invalid:
 try:dataclasses.replace(p,**change).validate()
 except new.ParamError:pass
 else:raise AssertionError(name)
# Roof-only containment arithmetic does not establish app visibility/clearance.
head=2.95+3.2*math.tan(math.radians(12.));shoulder=p.enclosed_left_annex['shoulder'];roof_at_outer=shoulder['roof_high_m']+(shoulder['roof_low_m']-shoulder['roof_high_m'])*3.2/shoulder['span_m']
contain={'current_shed_head_m':head,'current_shed_outer_eave_m':2.95,'proposed_shoulder_roof_at_main_m':shoulder['roof_high_m'],'proposed_shoulder_roof_at_shed_outer_edge_m':roof_at_outer,'head_protrusion_without_roof_thickness_m':head-shoulder['roof_high_m'],'whole_bay_footprint_overlaps_shoulder_m2':12.96,'does_current_roof_fully_enclose_even_zero_thickness_shed':head<=shoulder['roof_high_m'] and 2.95<=roof_at_outer,'illustrative_roof_only_clearance_requirement_with_100mm_allowance':{'minimum_roof_at_main_m':head+.10,'minimum_roof_at_shed_outer_edge_m':3.05},'no_app_safe_or_hidden_prop_claim':True,'unmeasured':'Shed/post/roof thickness, actual occlusion, terrain and neighboring clearances still require actual native/app evidence. Raising an invented roof merely to hide props is not authorized by this arithmetic.'}
assert input_before=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in input_paths}
result={'input_hashes_before_after_exact':input_before,'status':'PASS_PURE_GEOMETRY_ONLY','elapsed_seconds':time.monotonic()-start,'current_default_and_existing_version_controls_exact':len(compared),'controls':compared,'new_optin_CONSUMED':'enclosed_left_annex' in new.CONSUMED,'candidate_full_raw_vertices':len(obj['verts']),'candidate_full_raw_polygons':len(obj['faces']),'new_group_vertices':len(b.verts),'new_group_polygons':len(b.faces),'new_group_finite_nondegenerate_R_geometry':True,'malformed_or_incompatible_groups_rejected':len(invalid),'roof_containment':contain,'scope':'Actual native pure parameter resolution and full native mesh-accumulation lists/material specifications, replacing only in-process Blender object/material creation. No export, GLB, master/WEB, app/camera/image match or clearance qualification.','source_files_unchanged':all((base/rel).read_bytes()==(root/rel).read_bytes() for rel in ['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py'])}
assert result['source_files_unchanged'];(out/'IMPLEMENTED-PURE-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='controls'},indent=2))
