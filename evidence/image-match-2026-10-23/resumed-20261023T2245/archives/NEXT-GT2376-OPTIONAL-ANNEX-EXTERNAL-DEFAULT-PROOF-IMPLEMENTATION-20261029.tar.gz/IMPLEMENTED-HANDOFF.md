# Implemented external Green Tree annex candidate

The previously closed six-file packet remains historical and unchanged. This implementation supersedes its **unimplemented-control** limitation only. It has not been exported, rendered, adopted, merged or accepted, and the known yard collision remains unresolved.

## Exact candidate

`implemented/chicago/4d/` contains only:

- `generators/archetypes/frame_tavern_params.py`
- `generators/archetypes/frame_tavern.py`
- `data/structures/versions/green_tree_tavern/andreas-reading.json`

`IMPLEMENTED-CANDIDATE.patch` is the12KB two-producer diff against the guarded copies in `implementation-base/chicago/4d/`. Install the optional full record separately, rebased fieldwise onto the actually merged corrective default before use. No application checkout file was written. Both original producer source files still match their captured preimages after execution.

The one new keyword-only `enclosed_left_annex` group defaultsNone and is declared CONSUMED. Its strict validation requires exactly the three supported component maps, +X attachment, two-storey gable_front frame, no gallery/log/cross wing, finite bounded R dimensions, fixed roof categories, valid opening sections/edge/rake clearances and non-overlapping door/sash. Unsupported extra components, booleans as dimensions, NaN, invented connector openings and incompatible compositions refuse. The metric attribute must remainR. Its note explicitly distinguishes **inferred pictured occurrence/form** from **reconstructed numeric layout and uncertain scene-date presence**; the whole grouped numeric value isR so no number receives an inferred/attested grade by accident.

The producer emits shoulder, low connector and left gabled boarding range, using native MeshBuilder roof/envelope operations, the existing frame siding stock/materials and the existing `_win`/`_door` kit. The shoulder has a small closed front-gable/dormer proxy; all hidden depth/sections areR. Gable caps use the framed wall material with clipped courses, rather than roof covering. No chimney, tenant, interior or new historical date is invented. The default main block and existing appendage controls are untouched.

## Actual bounded pure proof

Root granted a briefCPU1nice19 window. `verify_implemented.py` ran in0.264s and captured the **actual native full raw mesh-accumulation lists and material specifications**, replacing only the in-process final Blender object/material creation. It invoked no Blender executable/export, browser or application pipeline.

All **23 current canonical FrameTavern assets plus the one existing FrameTavern version control** retain exactly the same resolved parameters (apart from the new absentNone field), vertices, polygons, confidence, material indices/specifications and named material requests. All33 input hashes were identical before and after capture. Twenty malformed/incompatible groups refused. The candidate resolves/builds in pure Python:6,808 full raw vertices/1,704 polygons, including1,648 vertices/413 non-degenerate finite polygons in the new group. Every new vertex carriesR. These are raw native-builder observations, not measured GLB size, triangle budget, Blender-export parity, native asset freshness or app qualification.

`IMPLEMENTED-PURE-PROOF.json` and both raw logs preserve the actual results; the second run added the explicit before/after input guards, not a changed geometry specification. Native export/WEB/version-manifest/sidecar production and real same-ray picture review are still owed.

## Yard conflict is still real

The shoulder overlaps all12.96m² of the unchanged procedural wagon bay and its coupled wagon. With the chosen source-diagnostic roof, the bay's nominal inner head3.63018m is **30.18mm above** the shoulder's3.60m roof at the main wall even before thickness. The shoulder roof over the outer bay edge is3.06667m versus the bay's2.95m nominal eave. Therefore the present geometry does not even wholly enclose the zero-thickness roof proxy.

A purely geometric roof-only containment condition with a hypothetical100mm allowance would require at least3.73018m at the main wall and3.05m at the outer bay edge. That arithmetic does **not** justify raising the roof to hide props or claim app safety: actual timber/roof thickness, visibility, canonical-yard overlap, terrain grounding, street/neighbor clearance and date interpretation remain unresolved. No renderer/version API, hiding switch, canonical-yard removal or re-dating was introduced.

The optional structure version can be exported and reviewed through existing `photo_match.mjs --glb <version master>` as a model-only diagnostic. It must not be presented as app-qualified or originalT2376complete until the real overlap/ground/evidence question is resolved. Keep raw unreviewed comparisons; never reuse a version-master verdict for the canonical master. No current PR ending depends on this next-batch candidate.
