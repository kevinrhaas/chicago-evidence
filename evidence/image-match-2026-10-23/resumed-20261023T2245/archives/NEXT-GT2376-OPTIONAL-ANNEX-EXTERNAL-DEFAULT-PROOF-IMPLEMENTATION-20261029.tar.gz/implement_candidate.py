from pathlib import Path
import json,difflib,hashlib
out=Path('/tmp/green-tree-enclosed-annex-next-20261029');src=Path('/tmp/tremont-picture-20261026/chicago/4d');cand=out/'implemented/chicago/4d';base=out/'implementation-base/chicago/4d'
rels=['generators/archetypes/frame_tavern_params.py','generators/archetypes/frame_tavern.py']
def rep(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
for rel in rels:
 for p in [base/rel,cand/rel]:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((src/rel).read_bytes())
p=cand/rels[0];s=p.read_text();s=rep(s,'"cross_wing", "cross_wing_depth_m", "cross_wing_end",','"cross_wing", "cross_wing_depth_m", "cross_wing_end", "enclosed_left_annex",')
s=rep(s,'    rear_ell: bool = False\n','    # Optional undated enclosed side-group reading. All metric layout is R;\n    # None leaves every existing canonical/alternate geometry path unchanged.\n    enclosed_left_annex: dict | None = field(default=None, kw_only=True)\n\n    rear_ell: bool = False\n')
s=rep(s,'    def validate(self) -> None:\n','    def validate(self) -> None:\n        if self.enclosed_left_annex is not None:\n            _validate_enclosed_left_annex(self)\n')
s=rep(s,'        rear_ell=bool(val("rear_ell", False)),\n','        enclosed_left_annex=val("enclosed_left_annex"),\n        rear_ell=bool(val("rear_ell", False)),\n')
s+='''

def _validate_enclosed_left_annex(p: FrameTavernParams) -> None:
    """One bounded three-mass +X interpretation, not arbitrary compound geometry."""
    g = p.enclosed_left_annex
    if (p.elevation_scheme != "gable_front" or p.roof_type != "gable" or
            p.stories != 2 or p.log_wing or p.cross_wing or p.gallery):
        raise ParamError("enclosed_left_annex needs a simple two-storey gable-front frame block")
    if p.confidence.get("enclosed_left_annex", "reconstructed") != "reconstructed":
        raise ParamError("enclosed_left_annex metric layout must remain reconstructed")
    if not isinstance(g, dict) or set(g) != {"attach_face", "front_setback_m", "shoulder", "connector", "boarding_range"}:
        raise ParamError("enclosed_left_annex needs exactly the bounded three-part layout")
    def number(v, lo, hi, label):
        if isinstance(v, bool) or not isinstance(v, (int,float)) or not math.isfinite(v) or not lo <= v <= hi:
            raise ParamError(f"enclosed_left_annex {label} needs a finite number in {lo}..{hi}")
    if g["attach_face"] != "x_max":
        raise ParamError("enclosed_left_annex attaches only to x_max")
    number(g["front_setback_m"], 0., 2., "setback")
    common={"span_m", "depth_m", "wall_m", "roof"}
    extra={"shoulder":{"roof_high_m","roof_low_m","front_window","front_gable_light","front_gable_peak_m"},
           "connector":{"roof_low_m","roof_high_m","front_openings"},
           "boarding_range":{"roof_pitch_deg","ridge_axis","front_door","front_window","front_gable_light"}}
    roofs={"shoulder":"shed_with_front_gable","connector":"shed","boarding_range":"gable"}
    for name in ("shoulder","connector","boarding_range"):
        v=g[name]
        if not isinstance(v,dict) or set(v) != common|extra[name]:
            raise ParamError(f"enclosed_left_annex {name} has unsupported or missing fields")
        number(v["span_m"], 1.5, 6., name+" span")
        number(v["depth_m"], 2., min(8.,p.depth_m-g["front_setback_m"]), name+" depth")
        number(v["wall_m"], 1.8, min(3.5,p.wall_height_m-.5), name+" wall")
        if v["roof"] != roofs[name]:
            raise ParamError(f"enclosed_left_annex {name} roof category is fixed")
        if name != "boarding_range":
            number(v["roof_low_m"], v["wall_m"]+.05, p.wall_height_m-.3, name+" roof low")
            number(v["roof_high_m"], v["roof_low_m"]+.05, p.wall_height_m-.2, name+" roof high")
        else:
            number(v["roof_pitch_deg"], 25., 40., name+" pitch")
            if v["ridge_axis"] != "y":
                raise ParamError("enclosed_left_annex boarding range ridge is y")
        if name == "connector":
            if v["front_openings"] != []:
                raise ParamError("enclosed_left_annex low connector has no stated front opening")
            continue
        def opening(key, count):
            a=v[key]
            if not isinstance(a,(list,tuple)) or len(a)!=count:
                raise ParamError(f"enclosed_left_annex {name} {key} has wrong section")
            for n in a:number(n, .01, 5., name+" "+key)
            number(a[0], .15, .85, name+" opening fraction")
            width=a[1] if key=="front_door" else a[2]
            if width/2+.15 > min(a[0],1-a[0])*v["span_m"]:
                raise ParamError("enclosed_left_annex opening breaks its facade edge")
            return a
        w=opening("front_window",4)
        if w[1]+w[3]+.15 > v["wall_m"]:
            raise ParamError("enclosed_left_annex lower sash breaks its eave band")
        light=opening("front_gable_light",4)
        if name=="shoulder":
            number(v["front_gable_peak_m"],max(v["roof_high_m"],light[1]+light[3]+.2),p.wall_height_m-.1,"shoulder peak")
            if light[1]-.1 < v["roof_low_m"] or light[2]+.5 > v["span_m"]:
                raise ParamError("enclosed_left_annex shoulder light breaks its bounded dormer")
        else:
            door=opening("front_door",3)
            if door[2]+.15>v["wall_m"]:
                raise ParamError("enclosed_left_annex door breaks its eave band")
            if abs(door[0]-w[0])*v["span_m"] <= (door[1]+w[2])/2+.15:
                raise ParamError("enclosed_left_annex door and sash overlap")
            edge_z=light[1]+light[3]+.15
            reach=abs((light[0]-.5)*v["span_m"])+light[2]/2+.1
            roof_z=v["wall_m"]+((v["span_m"]+.5)/2-reach)*math.tan(math.radians(v["roof_pitch_deg"]))
            if light[1]-.1<v["wall_m"] or edge_z>roof_z:
                raise ParamError("enclosed_left_annex upper light breaks its gable rake")
'''
p.write_text(s)
p=cand/rels[1];s=p.read_text();s=rep(s,'    if params.cross_wing:\n        _cross_wing(b, params, w, d, wall_z, ridge_z)\n','    if params.cross_wing:\n        _cross_wing(b, params, w, d, wall_z, ridge_z)\n    if params.enclosed_left_annex is not None:\n        _enclosed_left_annex(b, params, w, d)\n')
s+='''

def _enclosed_left_annex(b: MeshBuilder, p: FrameTavernParams, w: float, d: float) -> None:
    """Optional undated enclosed shoulder, low link and left gabled range.

    Pictured occurrence is inferred; every numeric layout/section and hidden face
    is reconstructed. This model-only version does NOT suppress procedural yard
    props, solve its known wagon-bay collision or date the enclosed group to1835.
    """
    g=p.enclosed_left_annex
    c=p.conf("enclosed_left_annex", "reconstructed")
    front=d-g["front_setback_m"]
    x=w
    for name in ("shoulder","connector","boarding_range"):
        v=g[name];x0=x;x1=x+v["span_m"];y0=front-v["depth_m"];h=v["wall_m"]
        b.add_box(x0,y0,0,x1,front,h,c,M_WALL,skip=("bottom",))
        _annex_courses(b,p,x0,y0,x1,front,h,c)
        if name=="boarding_range":
            _annex_gable_roof(b,p,x0,y0,x1,front,h,v["roof_pitch_deg"],c)
        else:
            # Shoulder falls away from the main block. The low connector rises
            # toward the farther boarding range, a declared diagnostic first fit.
            z0,z1=((v["roof_high_m"],v["roof_low_m"]) if name=="shoulder"
                   else (v["roof_low_m"],v["roof_high_m"]))
            _annex_shed_roof(b,x0,y0,x1,front,h,z0,z1,c)
        if name != "connector":
            f,z,ww,hh=v["front_window"];cx=x0+f*v["span_m"]
            _win(b,p,"y",front,+1,cx-ww/2,cx+ww/2,z,z+hh,c)
            f,z,ww,hh=v["front_gable_light"];cx=x0+f*v["span_m"]
            if name=="shoulder":
                # A small closed dormer proxy over this lower roof. Its unseen
                # depth and 250mm side cheeks remain reconstructed.
                a0,a1=cx-ww/2-.25,cx+ww/2+.25
                yf=front+ROOF_OVERHANG+.02;yb=yf-.9;head=z+hh+.15
                b.add_box(a0,yb,v["roof_low_m"],a1,yf,head,c,M_WALL,skip=("bottom",))
                pitch=math.degrees(math.atan((v["front_gable_peak_m"]-head)/((a1-a0+.1)/2)))
                _annex_gable_roof(b,p,a0,yb,a1,yf,head,pitch,c,overhang=.05)
                _win(b,p,"y",yf,+1,cx-ww/2,cx+ww/2,z,z+hh,c,skin=0.)
            else:
                _win(b,p,"y",front+ROOF_OVERHANG,+1,cx-ww/2,cx+ww/2,z,z+hh,c,skin=0.)
                f,ww,hh=v["front_door"];cx=x0+f*v["span_m"]
                _door(b,p,"y",front,+1,cx-ww/2,cx+ww/2,0.,hh,c,kind="back")
        x=x1


def _annex_courses(b,p,x0,y0,x1,y1,wall_z,c):
    """The existing frame stock and material, translated onto bounded annex walls."""
    lip=.018
    for z in materials.course_lines(0.,wall_z,p.siding_exposure_m,p.siding_lay_m,p.siding_seed):
        for y,out in ((y0,-1),(y1,+1)):
            pts=[(x0,y,z),(x1,y,z),(x1,y+out*lip,z-.02),(x0,y+out*lip,z-.02)]
            b.add_poly(list(reversed(pts)) if out<0 else pts,c,M_WALL)
        for x,out in ((x0,-1),(x1,+1)):
            pts=[(x,y0,z),(x,y1,z),(x+out*lip,y1,z-.02),(x+out*lip,y0,z-.02)]
            b.add_poly(list(reversed(pts)) if out>0 else pts,c,M_WALL)


def _annex_shed_roof(b,x0,y0,x1,y1,wall_z,z0,z1,c):
    """Closed shallow roof and upper wall infill, fixed +X slope topology."""
    slope=(z1-z0)/(x1-x0);o=ROOF_OVERHANG
    b.add_poly([(x0-o,y0-o,z0-o*slope),(x1+o,y0-o,z1+o*slope),
                (x1+o,y1+o,z1+o*slope),(x0-o,y1+o,z0-o*slope)],c,M_ROOF)
    b.add_poly([(x0,y0,wall_z),(x1,y0,wall_z),(x1,y0,z1),(x0,y0,z0)],c,M_WALL)
    b.add_poly([(x1,y1,wall_z),(x0,y1,wall_z),(x0,y1,z0),(x1,y1,z1)],c,M_WALL)
    b.add_poly([(x0,y1,wall_z),(x0,y0,wall_z),(x0,y0,z0),(x0,y1,z0)],c,M_WALL)
    b.add_poly([(x1,y0,wall_z),(x1,y1,wall_z),(x1,y1,z1),(x1,y0,z1)],c,M_WALL)


def _annex_gable_roof(b,p,x0,y0,x1,y1,eave,pitch,c,overhang=ROOF_OVERHANG):
    """Native roof envelope; end triangles use the existing framed wall material."""
    ridge=b.add_gable_roof(x0,y0,x1,y1,eave,pitch,c,M_ROOF,overhang=overhang,ridge_along_x=False)
    b.mat_index[-2:]=[M_WALL,M_WALL]
    # Same stock course rhythm, clipped to the two triangular wall faces.
    mid=(x0+x1)/2;half=(x1-x0+2*overhang)/2
    for z in materials.course_lines(eave,ridge,p.siding_exposure_m,p.siding_lay_m,p.siding_seed):
        zlow=max(eave,z-.02);a=half*(1-(zlow-eave)/(ridge-eave));q=half*(1-(z-eave)/(ridge-eave))
        for y,out in ((y0-overhang,-1),(y1+overhang,+1)):
            pts=[(mid-a,y,zlow),(mid+a,y,zlow),(mid+q,y+out*.018,z),(mid-q,y+out*.018,z)]
            b.add_poly(list(reversed(pts)) if out>0 else pts,c,M_WALL)
    return ridge
''';p.write_text(s)
vp=out/'candidate/data/structures/versions/green_tree_tavern/andreas-reading.json';rec=json.loads(vp.read_text());attribute=rec['phases'][0]['form']['enclosed_left_annex'];attribute['note']=attribute['note'].replace('PROPOSED NOT-YET-IMPLEMENTED version-only group control.','EXTERNAL IMPLEMENTED model-only version candidate, not exported or app-qualified.').replace('requires a producer implementation, genuine version master/WEB','requires genuine version master/WEB');target=cand/'data/structures/versions/green_tree_tavern/andreas-reading.json';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(rec,indent=2)+'\n')
patch=''
for rel in rels:
 patch+=''.join(difflib.unified_diff((base/rel).read_text().splitlines(True),(cand/rel).read_text().splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel))
(out/'IMPLEMENTED-CANDIDATE.patch').write_text(patch)
print('Externalcandidateprepared',len(patch),'byteproducerpatch')
