# T-2376 next finite step: enclosed left annex reading

This is an external, unimplemented next-batch proposal. It changes no canonical/source/producer/renderer file, takes no claim, starts no bake/browser and creates no ticket. It must not delay the current Tremont/Green Tree correction or the qualified four-case app group.

I read the closed Oct26 proposal and the coordination ruling first. The earlier proposal concerned moving the genuine **open** Trowbridge wagon bay by8.14m; it did not model the Andreas enclosed group. I directly viewed the held Andreas reproduction and Kurz panel11. The closed historical ruling is preserved: the enclosed left group is genuine, not dismissed as a neighbor; Taylor's arrival in1834 does not date his later recalled lodging in the left addition; Andreas's original1884 plate gives no1838 depicted date, despite the local reproduction caption. No1859 check_required image was used.

## Visible geometry and the one missing control

The pictures show three lower facades/silhouettes beside the main inn: an enclosed shoulder touching the main block (tall front light and a smaller gable/dormer-like upper opening), a distinctly lower covered connector, and a farther-left gabled range (door plus a lower sash, with a small upper light). Their overall depth, attachment plan and July1835 continuity are not given. The rear roof visible behind them cannot be dated or assigned a new independent building identity merely from this perspective.

None of the present controls produces that group:

- `rear_ell` is a narrow **rear -Y** tail, with an axis-continuing lower gable and a carriage opening. It cannot move a three-part enclosed chain to the side.
- `log_wing` projects in +Y and is explicitly log fabric; using it would give the pictured framed group the wrong material and placement.
- `cross_wing` has the main block's full height and a shared-apex constraint, so scaling it down would break its existing Sauganash contract.

Propose one optional keyword-only `enclosed_left_annex` group, defaultNone, carrying only this bounded three-mass topology. The prototype stores all numeric layout in one explicit form value; it does not introduce a generic arbitrary-compound API. Its consumer is restricted to simple gable_front frame blocks and +X attachment, refuses simultaneous log/cross wings and unsupported compositions, and declares the new field CONSUMED. Existing defaults/records must retain exact geometry. It adds no chimney, gallery, hidden room, tenant identity or dated alteration.

The pictured presence and relative roof categories support inferred form. **Every number is a reconstructed first fit:**

| part | +X span | depth behind the existing front plane | wall height | proposed roof category |
|---|---:|---:|---:|---|
| shoulder |3.60m|5.00m|2.80m|low roof with small front gable/dormer-like opening|
| low connector |3.00m|4.50m|2.10m|shallow enclosed roof, no invented front opening|
| boarding range |4.50m|5.50m|2.60m|gable alongY,34° first fit|

The complete prototype includes the reconstructed roof elevations, window/door stations and sections. These are deliberately **not** image-derived metre measurements. Use the main inn's existing timber/casing/opening kit and siding stock, with no paint-color inference from monochrome. Do not alter main-block dimensions, camera, geographic placement, chimney counts, seven-bay wall or corrected entry simply to improve the annex projection. The old rear_ell is retained in the prototype, not newly identified with a specific distant roof; its overlap/occlusion is an actual future pilot question.

## Optional version, chronology and integration price

The safest first diagnostic home is an optional full-record version labelled `andreas-reading`, based on the actual corrected Green Tree record. It depicts the **undated enclosed reading**, while the captioned1835 Trowbridge open-bay reconstruction remains the default. The version is not a claim that additions were erected/removed in a particular year, or that an1838/1859 alteration is proven. Its declared interpretation does not promote itself to canonical.

However, existing structure versions swap only the building/sidecar. They do not swap global procedural yard props. This is a concrete integration conflict, not an unspecified future check: the current bay occupies localU[7.62,10.82],V[8.14,12.19]. The proposed shoulder occupiesU[7.62,11.22],V[7.19,12.19], so it overlaps **all12.96m² of the bay**, including its coupled covered wagon. The overall proposed annex occupies56.25m² of new ground; terrain, neighbor and street clearance have not been checked.

Do not ship an app-qualified version with that unresolved overlap. Do not invent a renderer/version API to hide the bay, silently remove canonical props, move the inn, or date the two drawings into a chronology. The next run can first make a genuine version GLB and use existing `photo_match.mjs --glb assets/gltf/versions/...` for an isolated, explicitly diagnostic comparison. Full-app version qualification needs an explicit ground/placement/evidence-compatible resolution of the bay collision. If that resolution does not fit this bounded run, keep the proposal diagnostic and originalT2376 open; do not pretend the optional prototype has completed the case.

## Exact implementation boundary for a later owned run

Authored source paths, relative to chicago/4d:

1. `generators/archetypes/frame_tavern_params.py`: one defaultNone group, pure resolution/refusals and CONSUMED declaration.
2. `generators/archetypes/frame_tavern.py`: one bounded group producer called only on that opt-in; no existing wing contract/default changes.
3. `data/structures/versions/green_tree_tavern/andreas-reading.json`: the full-record prototype in this packet, rebased entrywise onto the actually merged corrective default before implementation.
4. `docs/LIBERTIES.md`: append the supplied dated/source-bound R geometry disclosure.
5. `docs/RESEARCH/green_tree_tavern.md` and `docs/STATUS.md`: one precise diagnostic interpretation/integration-limit statement; original discrepancies remain truthful.
6. One next-PR `changelog.d/T-2376.json` only when an actual visible qualified result exists.

Version master/WEB, manifest.versions and version sidecars belong to their native builders, not authored merges. No global yard/renderer/version API change is proposed. A source-specific diagnostic camera and match must bind the actual version master and retain the raw unreviewed result. Never apply a version-master verdict to the canonical model's image gate.

`PROPOSAL-RECEIPT.json` binds the actual corrective record and existing producer/source hashes, records the exact footprint-overlap arithmetic and all unrun work. The prototype is **not yet buildable** because the consumer is only proposed; it must not be copied into the application before that consumer and native outputs exist.
