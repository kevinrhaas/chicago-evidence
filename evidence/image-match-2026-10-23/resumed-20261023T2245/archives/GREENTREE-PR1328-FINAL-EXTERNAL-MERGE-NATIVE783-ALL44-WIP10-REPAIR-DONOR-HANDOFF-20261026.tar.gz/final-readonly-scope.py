from pathlib import Path
import subprocess,os,json,hashlib,datetime
r=Path('/tmp/chicago-green-tree-integration');h=Path('/tmp/green-tree-T2376-20261025');g=json.loads((h/'GUARDS-EB1-BEFORE.json').read_text());donor=json.loads(Path('/workspace/green-tree-strict-repair-donor-6a61.json').read_text());audit=json.loads((h/'ALL-BINARY-OUTSIDEEB1-READONLY-PARITY.json').read_text());assert audit['status']=='PASS';classified={}
for name,group in [('protected',g['protected']),('incoming_controls',g['asset_files'])]:
 semantic=[];raw=[]
 for p,value in group.items():
  got=hashlib.sha256((r/p).read_bytes()).hexdigest()if(r/p).is_file()else None
  if p in audit['changed']:
   assert audit['changed'][p]['equal']and got==audit['changed'][p]['generated_sha256'],p;semantic.append(p)
  else:assert got==value,p;raw.append(p)
 classified[name]={'raw_exact':len(raw),'retained_serialization_only_semantic_equal':len(semantic),'serialization_paths':semantic}
for p,row in donor['paths'].items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==row['donor_sha256'],p
def git(*args):return subprocess.check_output(['git',*args],cwd=r,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
diff=git('diff','--name-only',g['incoming']).decode().splitlines();assert set(diff)==set(donor['paths'])|set(audit['changed']),diff
proof={'status':'READONLY CLOSEDNATIVE_SCOPE_VERIFIED; nojoinedwholegate/commit/push/matrix','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'HEAD':git('rev-parse','HEAD').decode().strip(),'MERGE_HEAD':git('rev-parse','MERGE_HEAD').decode().strip(),'vs_external_EB1':diff,'five_code_files_exact_checked_public6a61':True,'all44_binaries_semantically_incoming_equal':True,'source_controls':classified,'native_run':'full202+7feedback+57tail/1stablelap PASS/allchildrenreaped','source_restored_or_staged_by_finalaudit':False,'actual_external_PR_merge':'b4731c94 tree7d2059cf, devfolda575','original2376':'OPEN/unclaimed/partial1328link; currentdevAndreasverdictdiffers','next':'Exactfourtools+STATUSnotes selectivecarryinMary1334; RootalsoauthorizesTremontfourtools. Freshfinalnative/whole3/full18remaincarriersresponsibility. No invisibleGTfollowup.'};(h/'FINAL-GT-CLOSED-SCOPE.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
