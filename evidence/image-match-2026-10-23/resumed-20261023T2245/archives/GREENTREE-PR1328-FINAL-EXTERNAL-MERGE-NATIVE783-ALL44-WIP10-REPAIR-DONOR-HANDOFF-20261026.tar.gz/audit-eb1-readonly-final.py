from pathlib import Path
import subprocess,json,hashlib,os,gzip,zipfile,io,shutil,datetime
import xml.etree.ElementTree as ET
r=Path('/tmp/chicago-green-tree-integration')
h=Path('/tmp/green-tree-T2376-20261025')
source=json.loads((h/'ALL-XLSX-GZIP-EB1-BASELINE.json').read_text())
inc=source['incoming']
hold=h/'nativeeb1-serialization-held'
assert not hold.exists()
hold.mkdir()
def git(*args):
 return subprocess.check_output(['git',*args],cwd=r,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
def xml_node(node):
 text=node.text
 if text is not None and not text.strip() and len(node)>0:
  text=None
 tail=node.tail if node.tail and node.tail.strip() else None
 return (node.tag,tuple(sorted(node.attrib.items())),text,tail,tuple(xml_node(child) for child in node))
def xlsx_semantics(a,b):
 za=zipfile.ZipFile(io.BytesIO(a));zb=zipfile.ZipFile(io.BytesIO(b))
 names=sorted(za.namelist())
 if names!=sorted(zb.namelist()):
  return False,{'reason':'ZIP member set differs'}
 parts={}
 for name in names:
  aa=za.read(name);bb=zb.read(name)
  if name.endswith(('.xml','.rels')):
   same=xml_node(ET.fromstring(aa))==xml_node(ET.fromstring(bb))
   kind='XML semantic tree (all leaf text preserved)'
  else:
   same=aa==bb
   kind='exact non-XML bytes'
  parts[name]={'equal':same,'comparison':kind}
 return all(x['equal'] for x in parts.values()),parts
changed={};expected={}
for p,record in source['records'].items():
 current=(r/p).read_bytes()
 if hashlib.sha256(current).hexdigest()==record['sha256']:
  continue
 baseline=git('show',inc+':'+p)
 assert hashlib.sha256(baseline).hexdigest()==record['sha256']
 saved=hold/p
 saved.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(r/p,saved)
 if p.endswith('.gz'):
  equal=gzip.decompress(current)==gzip.decompress(baseline)
  details='exact decompressed byte stream'
 else:
  equal,details=xlsx_semantics(current,baseline)
 changed[p]={'equal':equal,'comparison':details,'generated_sha256':hashlib.sha256(current).hexdigest(),'baseline_sha256':record['sha256'],'held':str(saved)}
 expected[p]=baseline
outside={p for mode in [[],['--cached']] for p in git('diff',*mode,inc,'--name-only').decode().splitlines() if not p.startswith('chicago/4d/')}
unknown=sorted(outside-set(changed))
proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'incoming':inc,'all_binary_paths_scanned':len(source['records']),'all_dirty_outside4d':sorted(outside),'unclassified_outside4d':unknown,'changed':changed,'status':'PASS' if not unknown and all(x['equal'] for x in changed.values()) else 'FAIL','action':'READONLY final proof after externalmerge: all generatedbytes retained; no source restore/stage/newgate/push/matrix. Mary will run its own freshnative/all44/gate.'}
(h/'ALL-BINARY-OUTSIDEEB1-READONLY-PARITY.json').write_text(json.dumps(proof,indent=2)+'\n')
assert proof['status']=='PASS',json.dumps(proof)

print(json.dumps({'status':proof['status'],'all_binary_scanned':len(source['records']),'changed':{p:record['equal']for p,record in changed.items()},'source_restored_or_staged':False,'held_directory':str(hold),'unknown_outside':unknown},indent=2))
