from pathlib import Path
import os,json,hashlib,subprocess,datetime,shutil
r=Path('/tmp/chicago-green-tree-integration');a=r/'chicago/4d';h=Path('/tmp/green-tree-T2376-20261025')
env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env['TMPDIR']='/tmp/gt-nativecb';env['PYTHONDONTWRITEBYTECODE']='1';Path(env['TMPDIR']).mkdir(exist_ok=True)
os.sched_setaffinity(0,{1})
env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
mem_limit=int(Path('/sys/fs/cgroup/memory.max').read_text());mem_current=int(Path('/sys/fs/cgroup/memory.current').read_text());assert mem_limit-mem_current>=512*1024**2,'Root-required512MiB caller reserve'

free=shutil.disk_usage(env['TMPDIR']).free;assert free>=512*1024**2
g=json.loads((h/'GUARDS-EB1-BEFORE.json').read_text());b=json.loads((h/'ALL-XLSX-GZIP-EB1-BASELINE.json').read_text());s=json.loads((h/'CB93-STRICT-SMOKE-REPAIRS-CONTRACT.json').read_text())
for group in [g['protected'],g['asset_files'],{p:x['sha256']for p,x in b['records'].items()}]:
 for p,value in group.items():assert (hashlib.sha256((r/p).read_bytes()).hexdigest()if(r/p).is_file()else None)==value,p
for p,value in s['source'].items():assert hashlib.sha256((a/p).read_bytes()).hexdigest()==value,p
for name,want in [('HEAD',g['own']),('MERGE_HEAD',g['incoming'])]:assert subprocess.check_output(['git','rev-parse',name],cwd=r).decode().strip()==want
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (h/'resolveeb1.log').open('x')as log:
 result=subprocess.run(['node','tools/rederive.mjs','--resolve'],cwd=a,env=env,stdout=log,stderr=subprocess.STDOUT)
proof={'command':['node','tools/rederive.mjs','--resolve'],'exit_code':result.returncode,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu_affinity':sorted(os.sched_getaffinity(0)),'temp_free_start':free,'cgroup_memory_limit_start':mem_limit,'cgroup_memory_current_start':mem_current,'caller_reserve_start':mem_limit-mem_current,'source_input_guard':True,'scope':'Actual preservedexternaleb1(0c78+ce892)+checked6a61; all approved strict native smoke repairs authored; no frame family rebake. Actual native Lib142 before feedback145 requires full202/cycle/owningtail, no hand-selected bypass.'}
(h/'RESOLVEEB1-RESULT.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2),flush=True);raise SystemExit(result.returncode)
