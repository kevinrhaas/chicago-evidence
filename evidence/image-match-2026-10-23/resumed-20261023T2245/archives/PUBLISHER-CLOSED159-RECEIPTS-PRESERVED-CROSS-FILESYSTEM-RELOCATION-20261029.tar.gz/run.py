from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal,zlib,urllib.request,urllib.parse,struct
os.sched_setaffinity(0,{1});os.nice(19)
B=Path(__file__).parent;C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='ec9f5c932763e3a40df8cb15496d888df50f6a37';TIP='7c5f2109cc1db6a86e23d76b4127385b587adcee';CAP=64*1024**2;ENVELOPE=CAP;FLOOR=512*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(r,*args,input=None):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:sha(G/n)for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
def indexed(ids):
 wanted=set(ids);found=set();obj=G/'objects'
 for s in wanted:
  if(obj/s[:2]/s[2:]).is_file():found.add(s)
 for idx in(obj/'pack').glob('*.idx'):
  remaining=wanted-found
  if not remaining:break
  with idx.open('rb')as f:
   head=f.read(8);v2=head[:4]==b'\xfftOc';off=8 if v2 else 0
   if v2:assert struct.unpack('>I',head[4:])[0]==2
   f.seek(off);fan=struct.unpack('>256I',f.read(1024));table=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
   for s in remaining:
    key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
    while a<z:
     m=(a+z)//2;f.seek(table+m*stride+delta);value=f.read(20)
     if value<key:a=m+1
     else:z=m
    f.seek(table+a*stride+delta)
    if a<fan[key[0]]and f.read(20)==key:found.add(s)
 return found




import stat
names=['current-dev-80dda-readonly-price-20261027T0130','current-dev-C6-Shipman-genuine00a0-bounded-import-20261027T0419','current-dev-C6-d3a1-Shipman05c4-fold-price-20261027T0417','current-dev-Dent80dd-bounded-import-cas-20261027T0133','current-dev-Jones408b-4030-bounded-import-cas-20261027T0414','current-dev-Jones408b-4030-readonly-price-20261027T0410','current-dev-Shipman05c4-C6-d3a1-price-20261027T0412','current-dev-T3161-fold407e-bounded-import-cas-20261027T0112','current-dev-T3161-fold407e-bounded-import-cas-20261027T0116','current-dev-Walker9ab-dfcbf-bounded-import-cas-20261027T0306','current-dev-Walker9ab-readonly-price-20261027T0300','current-dev-Wolf-fold-e5b9-bounded-import-cas-20261027T0210']
sources=[Path('/tmp')/n for n in names];destroot=Path('/workspace/shared/publisher-closed-import-receipts-20261029');destroot.mkdir(exist_ok=True)
def readers():
 hits=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  for key in ['cwd']:
   try:
    target=os.readlink(proc/key)
    if any(target==str(s)or target.startswith(str(s)+'/')for s in sources):hits.append([proc.name,key,target])
   except(OSError,PermissionError):pass
  try:
   for fd in(proc/'fd').iterdir():
    try:
     target=os.readlink(fd)
     if any(target==str(s)or target.startswith(str(s)+'/')for s in sources):hits.append([proc.name,fd.name,target])
    except(OSError,PermissionError):pass
  except(OSError,PermissionError):pass
 return hits
assert not readers()
def inventory(root):
 out=[]
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():out.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)})
 return out
before=snap();save('SOURCE-BEFORE.json',before);free_tmp=shutil.disk_usage('/tmp').free;free_ws=shutil.disk_usage('/workspace').free;records=[]
for source in sources:
 assert source.is_dir()and not source.is_symlink();dest=destroot/source.name;assert not dest.exists();rows=inventory(source);assert shutil.disk_usage('/workspace').free>=FLOOR+sum(r['bytes']for r in rows)
 shutil.copytree(source,dest,copy_function=shutil.copy2);assert inventory(dest)==rows and inventory(source)==rows and not readers()
 tomb=source.with_name(source.name+'.verified-relocation-'+str(os.getpid()));source.rename(tomb);source.symlink_to(dest,target_is_directory=True);assert inventory(source)==rows
 shutil.rmtree(tomb);records.append({'original_path':str(source),'new_path':str(dest),'files':rows,'source_path_now':'DIRECTORY_SYMLINK_FULLY_TRANSPARENT','verification':'Everyfilebytes/SHA256/mode exactly equal before/after; sourcepath continues resolving; no receipt/manifests/scripts lost.'})
 assert snap()==before
save('ALL-RELOCATED-FILE-HASH-SIZE-MODE-VERIFICATION.json',records);after=snap();save('SOURCE-AFTER.json',after);assert after==before
result={'status':'CLOSED_PUBLISHER_RECEIPTS_RELOCATED_PRESERVED_WITH_ORIGINAL_PATH_SYMLINKS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'directories':len(records),'files_preserved':sum(len(r['files'])for r in records),'TMP_free_before':free_tmp,'TMP_free_after':shutil.disk_usage('/tmp').free,'actual_TMP_df_gain':shutil.disk_usage('/tmp').free-free_tmp,'workspace_free_before':free_ws,'workspace_free_after':shutil.disk_usage('/workspace').free,'sourceHEAD_index_MERGE_config_status_allrefs_unchanged':True,'no_live_readers_writers':True,'scope':'OnlyownclosedimmutableOct27APIprice/importreceiptfolders moved acrossfilesystems. Everypayload/script/manifest/receipt preservedbycontent/mode andtransparentoldpath. No source/cache/recoveryarchive removed; no guardlowered.'};save('RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
