from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,stat,subprocess,zlib
R=Path('/workspace/chicago-private-publisher-20261024');G=R/'.git';D=G/'objects/pack';OUT=Path('/workspace/chicago-publisher-second-object-preserving-maintenance-20261024');assert not OUT.exists();OUT.mkdir()
ENV={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0'};KEEP='pack-69e7fd75c2992e6ec904541f63ee21eba58f2b16'
def git(*args,input=None):return subprocess.check_output(['git',*args],cwd=R,env=ENV,input=input)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def meta(p):
 s=p.stat();return {'path':str(p),'bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'inode':s.st_ino,'sha256':sha(p)}
def snapshot():
 paths=[G/'HEAD',G/'index',G/'config',G/'config.worktree',G/'packed-refs',G/'shallow',G/'info/sparse-checkout']
 return {'HEAD':git('rev-parse','HEAD').decode().strip(),'refs':git('show-ref').decode(),'status':git('status','--porcelain').decode(),'stage_sha256':hashlib.sha256(git('ls-files','--stage')).hexdigest(),'state_files':[meta(p) for p in paths if p.is_file()],'locks':[meta(p) for p in sorted(G.rglob('*.lock')) if p.is_file()],'free_workspace':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize}
def indexes():
 result={}
 for idx in sorted(D.glob('*.idx')):
  with idx.open('rb') as f:lines=subprocess.check_output(['git','show-index'],stdin=f,env=ENV).decode().splitlines()
  result[idx.stem]={line.split()[1] for line in lines}
 return result
def loose():
 result={}
 for sub in (G/'objects').iterdir():
  if sub.is_dir() and len(sub.name)==2 and all(c in '0123456789abcdef' for c in sub.name):
   for p in sub.iterdir():
    if p.is_file() and len(p.name)==38 and all(c in '0123456789abcdef' for c in p.name):result[sub.name+p.name]=p
 return result
def typed_objects(oids):
 proc=subprocess.Popen(['git','cat-file','--batch'],cwd=R,env=ENV,stdin=subprocess.PIPE,stdout=subprocess.PIPE);rows=[]
 try:
  for oid in sorted(oids):
   proc.stdin.write((oid+'\n').encode());proc.stdin.flush();parts=proc.stdout.readline().decode().strip().split();assert len(parts)==3 and parts[0]==oid
   typ=parts[1];n=int(parts[2]);data=proc.stdout.read(n);assert len(data)==n and proc.stdout.read(1)==b'\n';assert hashlib.sha1((typ+' '+str(n)+'\0').encode()+data).hexdigest()==oid
   rows.append({'oid':oid,'type':typ,'bytes':n,'content_sha256':hashlib.sha256(data).hexdigest()})
 finally:proc.stdin.close();assert proc.wait()==0
 return rows
before=snapshot();assert before['status']=='';assert not (G/'index.lock').exists() and not (G/'packed-refs.lock').exists();assert not list(D.glob('tmp_pack_*'));assert not (G/'objects/info/alternates').exists()
packs=indexes();lp=loose();allobjects=set().union(*packs.values())|set(lp);assert len(allobjects)==3191 and len(packs)==11 and len(lp)==446 and len(packs[KEEP])==1090;other=allobjects-packs[KEEP];assert len(other)==2101
keepfiles=[p for p in D.iterdir() if p.stem==KEEP];assert {p.suffix for p in keepfiles}>={'.pack','.idx','.promisor'};keepers=[meta(p) for p in keepfiles]
oldfiles=[p for p in D.iterdir() if p.name.startswith('pack-') and p.stem in packs and p.stem!=KEEP];assert all(p.suffix in ['.pack','.idx','.rev','.promisor'] for p in oldfiles);oldmeta=[meta(p) for p in oldfiles]
loosemeta=[]
for oid,p in sorted(lp.items()):
 data=p.read_bytes();assert hashlib.sha1(zlib.decompress(data)).hexdigest()==oid;loosemeta.append({'oid':oid,**meta(p)})
archive_roots=[R/'evidence/image-match-2026-10-23/resumed-20261023T2245/archives',Path('/workspace/T3081-emergency-archive-hold'),Path('/tmp/chicago-archive-reversible-hold-20261024')];archivefiles=[]
for root in archive_roots:
 assert root.is_dir()
 for p in sorted(root.glob('*.tar.gz')):assert not p.is_symlink();archivefiles.append(meta(p))
write('STATE-BEFORE.json',before);write('KEEPER-PACK-FILES.json',keepers);write('OLD-REDUNDANT-PACK-FILES.json',oldmeta);write('LOOSE-FILES.json',loosemeta);write('ALL-MATERIALIZED-ARCHIVE-FILES.json',archivefiles);write('OBJECT-SETS.json',{'all':sorted(allobjects),'keeper':sorted(packs[KEEP]),'standalone':sorted(other)})
original=typed_objects(allobjects);assert sum(x['bytes'] for x in original if x['oid'] in other)==56099818;write('ALL-TYPED-OBJECTS-BEFORE.json',original)
with (OUT/'keeper-verify-before.log').open('wb') as f:subprocess.run(['git','verify-pack','-v',str(D/(KEEP+'.idx'))],cwd=R,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
print(json.dumps({'phase':'BEFORE_FULL3191_TYPED_OBJECTS_AND_KEEPER_PASS','unique_other':2101,'uncompressed_bytes':56099818}),flush=True)
prefix=D/'object-preserving-second-20261024';digest=git('pack-objects','--window=0','--depth=0','--compression=1',str(prefix),input=('\n'.join(sorted(other))+'\n').encode()).decode().strip();assert len(digest)==40;newstem='pack-'+digest
for suffix in ['.pack','.idx','.rev']:
 made=D/(prefix.name+'-'+digest+suffix)
 if made.exists():
  dest=D/(newstem+suffix);assert not dest.exists();os.rename(made,dest)
newpack=D/(newstem+'.pack');newidx=D/(newstem+'.idx');assert newpack.exists() and newidx.exists();(D/(newstem+'.promisor')).write_bytes(b'')
with (OUT/'standalone-verify.log').open('wb') as f:subprocess.run(['git','verify-pack','-v',str(newidx)],cwd=R,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
lines=(OUT/'standalone-verify.log').read_text().splitlines();verifiedrows=[line.split() for line in lines if line.split() and line.split()[0] in other];assert len(verifiedrows)==2101 and all(len(row)==5 for row in verifiedrows),'New pack must have NO external or internal deltas'
newsets=indexes();assert newsets[newstem]==other and set(newsets)==set(packs)|{newstem} and set().union(*newsets.values())|set(loose())==allobjects;assert set(loose())==set(lp)
assert typed_objects(allobjects)==original;mid=snapshot();assert all(mid[k]==before[k] for k in before if k!='free_workspace')
for x in keepers+oldmeta+archivefiles:
 p=Path(x['path']);assert sha(p)==x['sha256'] and p.stat().st_size==x['bytes'] and oct(stat.S_IMODE(p.stat().st_mode))==x['mode']
write('PRE-UNLINK-REPLACEMENT-PROOF.json',{'status':'ALL3191_FULL_TYPED_HASHES_EXACT_NEW2101_NO_DELTA_PACK_INDEPENDENTLY_VERIFIED_BEFORE_UNLINK','new_pack':str(newpack),'new_pack_bytes':newpack.stat().st_size,'new_pack_sha256':sha(newpack),'new_idx_sha256':sha(newidx),'promisor_marker_preserved':True,'full_object_coverage':3191,'snapshot':mid})
# Each removed representation is now redundant; every present object, including
# unreachable history, remains in the retained keeper and verified standalone pack.
for x in oldmeta:
 p=Path(x['path']);assert sha(p)==x['sha256'] and p.stat().st_ino==x['inode'];p.unlink()
for x in loosemeta:
 p=Path(x['path']);assert sha(p)==x['sha256'] and p.stat().st_ino==x['inode'];p.unlink()
aftersets=indexes();assert set(aftersets)=={KEEP,newstem} and set().union(*aftersets.values())==allobjects and not loose();afterobjects=typed_objects(allobjects);assert afterobjects==original;write('ALL-TYPED-OBJECTS-AFTER.json',afterobjects)
for x in keepers+archivefiles:
 p=Path(x['path']);assert sha(p)==x['sha256'] and p.stat().st_size==x['bytes'] and oct(stat.S_IMODE(p.stat().st_mode))==x['mode']
with (OUT/'keeper-verify-after.log').open('wb') as f:subprocess.run(['git','verify-pack','-v',str(D/(KEEP+'.idx'))],cwd=R,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
after=snapshot();assert all(after[k]==before[k] for k in before if k!='free_workspace');write('STATE-AFTER.json',after)
receipt={'status':'SECOND_OBJECT_PRESERVING_DEDUPLICATION_FULL_PASS','at_utc':datetime.now(timezone.utc).isoformat(),'HEAD':before['HEAD'],'present_objects_before_after':3191,'keeper_objects':1090,'standalone_objects':2101,'standalone_pack_bytes':newpack.stat().st_size,'new_pack_sha256':sha(newpack),'all_typed_SHA1_content_SHA256_exact':True,'standalone_pack_zero_deltas_independently_verified':True,'keeper_bytes_modes_exact':True,'all_refs_HEAD_rawindex_configs_sparse_locks_exact':True,'all_materialized_archive_bytes_modes_exact':True,'materialized_archive_instances_checked':len(archivefiles),'deleted_only_redundant_pack_sidecars':len(oldmeta),'deleted_only_redundant_loose_representations':len(loosemeta),'promisor_semantics_retained':True,'no_GC_prune_reachability_reset_ref_index_rewrite_fetch_or_lazyfetch':True,'no_external_source_Git_or_archive_cache_mutation':True,'cause_of_repeat_promisor_pack_growth':'UNKNOWN; not claimed fixed','free_workspace_before':before['free_workspace'],'free_workspace_after':after['free_workspace'],'reclaimed_workspace_bytes':after['free_workspace']-before['free_workspace']}
write('RECEIPT.json',receipt);manifest={'status':'CLOSED_SECOND_OBJECT_PRESERVING_DEDUPLICATION','files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.iterdir()) if p.is_file()]};write('MANIFEST.json',manifest);print(json.dumps(receipt,indent=2),flush=True);print('MANIFEST_SHA256',sha(OUT/'MANIFEST.json'),flush=True)
