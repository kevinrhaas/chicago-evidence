from pathlib import Path
import subprocess,json,os,datetime,hashlib,time
repo=Path('/workspace/chicago');app=repo/'chicago/4d';P=Path('/workspace/shared/WolfPoint-T2386-Mary-bffc-stack-20261026T1402');c=json.loads((P/'checked-commit/RESULT.json').read_text());assert c['status']=='ACTUAL_CHECKED_TREE_NORMAL_COMMIT_AND_COMMITTED_GATES_PASS';head=c['head'];branch='steward/t2386-wolfpoint-picture';actor='T2386 Wolf Point native picture signoff';O=P/'updated-public';O.mkdir(mode=0o700);env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None)
def api(p):return json.loads(subprocess.check_output(['gh','api',p,'--header','Cache-Control: no-cache'],cwd=repo,env=env))
def save(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n')
pr=api('repos/kevinrhaas/chicago/pulls/1336');assert pr['state']=='open' and pr['draft'] and pr['base']['ref']=='dev' and pr['head']['ref']==branch and pr['head']['sha']==c['parents'][0];save('BEFORE-PR.json',pr)
r=api('repos/kevinrhaas/chicago/git/ref/heads/lap/pr-1336');lap=api('repos/kevinrhaas/chicago/git/commits/'+r['object']['sha']);assert lap['message'].splitlines()[0].startswith('lap PR #1336 — '+actor+' ');taken=datetime.datetime.fromisoformat(lap['committer']['date'].replace('Z','+00:00'));expiry=taken+datetime.timedelta(hours=3);assert expiry>datetime.datetime.now(datetime.timezone.utc)
with (O/'native-own-lap-status.log').open('x')as f:q=subprocess.run(['node','tools/ticket.mjs','lap','1336','--status'],cwd=app,env=env,stdout=f,stderr=subprocess.STDOUT)
assert q.returncode==3 and actor in (O/'native-own-lap-status.log').read_text()
with(O/'normal-ff-push.log').open('x')as f:q=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','push','origin','HEAD:refs/heads/'+branch],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
assert q.returncode==0
for _ in range(10):
 pr=api('repos/kevinrhaas/chicago/pulls/1336')
 if pr['head']['sha']==head:break
 time.sleep(1)
assert pr['head']['sha']==head and pr['draft'];ref=api('repos/kevinrhaas/chicago/git/ref/heads/'+branch);assert ref['object']['sha']==head;commit=api('repos/kevinrhaas/chicago/git/commits/'+head);assert commit['tree']['sha']==c['tree'];save('PUBLIC-COMMIT.json',commit)
native=json.loads((P/'NATIVE-RESULT.json').read_text());footer=next(x for x in c['whole_footer'].splitlines()if 'CHECK PASS' in x)
body=f'''Wolf Point Tavern's roof looked pale beside the dark roof in the credited NYPL print. This selects a darker reconstructed tone through a keyword-only LogDwelling option. The 1867 print is retrospective and labelled 1833; the choice makes no claim about exact pigment, weathering or July 1835 fabric.

Genuine Blender 4.5.3 and pinned glTF-Transform 4.5.0 builds refreshed all 82 canonical masters and web derivatives. The other 81 pairs stayed byte-identical. Wolf changes only roof base colour; actual positions, normals, UVs, confidence, counts, roughness and other material values remain exact. Shared finishes and all defaults are retained.

**Draft dependencies: #1333 and #1334 must land first, in that order.** This cumulative candidate normally merges checked Mary head `bffc4cff33670bde34e718751ea8712e087eef8b`, containing checked Jail `8cd2db60` and tested dev base `{c['actual_committed_base']}`. All PRs remain based on `dev`; before ready/merge, the final diff must contain only Wolf's own work. Newer remote changes are recorded separately and are not certified by this tested-base result. The exact 283-ID 1904 expectations and reviewed lighthouse-glass/independent-footprint assertions stay strict.

**Original T-2386 remains open.** Acceptance of all eight picture files/nine compositions is unfinished. The retained NYPL camera is provisional and its external match record is UNREVIEWED. The separate poster's rights limitation is unchanged. No follow-up ticket or original image-match completion is created.

Validation:

- All 82 real master/web pairs remain byte-exact through this normal integration; all 82 freshly computed native recipe hashes match. Both registries agree with native entrywise merge and retain all incoming rows. No re-export was required.
- Supported native regeneration/fixed point, the complete 44-artifact workbook/gzip audit, package tail and final publish passed. All {native['frozen_assets']:,} asset/registry files and {native['frozen_controls']:,} authored/source/people/generator controls remained exact. Serialization-only restores followed whole-content equality and retained regenerated raw bytes.
- All three native preflight questions passed: `{footer}`. Committed-head changelog, ending-ID and history checks passed against tested dev `{c['actual_committed_base']}`. The upstream dependency identity is recorded separately.
- Earlier actual mobile checks passed. Desktop normal/By Grade/Photos components completed before an agent interrupted the first run; a fresh run passed remaining Sources, new liberty, both native doorway approaches, HTTP assets/maps, caps and error checks on identical inputs. The interrupted wrapper remains qualified, with no performance claim. Old head `4fe7d4ba` passed all eighteen published native groups; those results do not certify this cumulative world.

**One fresh full eighteen-group matrix for exact head `{head}` is pending.** Native global smoke-input and separate changelog hashes were frozen on this clean committed candidate. After upstreams land, actual dev must be normally integrated and re-derived/published. Identical clean native global hashes license explicit matrix reuse, with stage 13 at both viewports when only the separate changelog hash differs; a changed global hash requires fresh applicable validation. Required hosted checks remain mandatory. This stays DRAFT; root owns readiness and merge. Recovery and preserved failures: [chicago-evidence](https://github.com/kevinrhaas/chicago-evidence).
'''
(O/'PR-BODY.md').write_text(body);request=O/'BODY-PATCH.json';request.write_text(json.dumps({'body':body}));updated=json.loads(subprocess.check_output(['gh','api','--method','PATCH','repos/kevinrhaas/chicago/pulls/1336','--input',str(request)],cwd=repo,env=env));assert updated['head']['sha']==head and updated['draft'] and updated['body']==body
fresh=api('repos/kevinrhaas/chicago/git/ref/heads/dev');save('FRESH-REMOTE-DEV.json',fresh);result={'status':'NORMAL_FF_PUSH_CHECKED_HEAD_PUBLIC_DRAFT','closed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'tree':c['tree'],'base':c['actual_committed_base'],'branch':branch,'PR':1336,'url':updated['html_url'],'draft':True,'lap_marker':r['object']['sha'],'lap_expires_after':expiry.isoformat(),'fresh_remote_dev':fresh['object']['sha'],'body_sha256':hashlib.sha256(body.encode()).hexdigest(),'incoming_checked_dependency':c['incoming_checked_dependency'],'pending':'ONE fresh native18/currenthostedchecks, then Jail→Maryfirst and latestdev/nativeglobalhashproof/revalidation. RootonlyREADY+merge; original2386DIF.'};save('RESULT.json',result);print(json.dumps(result,indent=2))
