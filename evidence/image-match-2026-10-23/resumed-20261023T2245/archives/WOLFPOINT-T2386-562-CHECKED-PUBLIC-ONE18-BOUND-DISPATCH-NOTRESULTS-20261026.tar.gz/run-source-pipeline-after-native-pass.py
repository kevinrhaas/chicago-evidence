from pathlib import Path
import subprocess,json,time,datetime,re,sys
P=Path('/workspace/shared/WolfPoint-T2386-Mary-bffc-stack-20261026T1402');(P/'source-pipeline-once-lock').mkdir();steps=[]
def save(name,data):(P/name).write_text(json.dumps(data,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
print('WAIT actualnative closure; then one whole3/commit/push/18. No READY/merge.',flush=True)
while True:
 try:r=json.loads((P/'native-reaper.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):time.sleep(5);continue
 if r.get('command_exit')is not None:break
 time.sleep(5)
assert r['command_exit']==0 and r['all_children_reaped'],('NATIVE_NOT_CLOSED_PASS',r)
native=json.loads((P/'NATIVE-RESULT.json').read_text());assert native['status']=='NATIVE_RESOLVE_FIXEDPOINT_ALL44_PROOF_PACKAGE5_FINAL_PUBLISH_PASS'
print('START one actualwhole3 after nativePASS',now(),flush=True)
with(P/'required-preflight-automatic.log').open('x')as f:q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(P/'required-preflight-reaper.json'),'--','python3',str(P/'required-preflight.py')],stdout=f,stderr=subprocess.STDOUT)
assert q.returncode==0,('WHOLE3_PROCESS_FAILED_NO_COMMIT',q.returncode)
while True:
 try:r=json.loads((P/'required-preflight-reaper.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):time.sleep(5);continue
 if r.get('command_exit')is not None:break
 time.sleep(5)
assert r['command_exit']==0 and r['all_children_reaped'],('WHOLE3_NOT_CLOSED_PASS',r)
pre=json.loads((P/'required-preflight/RESULT.json').read_text());assert pre['status']=='ALL3_NATIVE_PREFLIGHT_PASS'and all(pre['guards'].values())and all(s['exit']==0 for s in pre['steps']);save('FINISH-START-BINDING.json',{'at':now(),'actual_full3':pre,'root_authorization':'Rootexplicitnormalcheckedcommit/committedchecks/normalFFpush/onefreshfull18; rootaloneownsREADY+merge'})
for name,script in [('checked-commit','commit-checked.py'),('updated-public','push-checked.py'),('one-full18-dispatch','dispatch-one-full18.py')]:
 start=now();print('START',name,start,flush=True)
 with(P/(name+'-automatic.log')).open('x')as f:q=subprocess.run(['python3',str(P/script)],stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'script':script,'started':start,'finished':now(),'exit':q.returncode};steps.append(row);save('FINISH-STEPS.json',steps);print('CLOSED',name,q.returncode,flush=True);assert q.returncode==0,(name,q.returncode)
c=json.loads((P/'checked-commit/RESULT.json').read_text());d=json.loads((P/'full18-final/COMPLETE_DISPATCH.json').read_text());assert d['status']=='DISPATCHED_NOT_RESULTS'and d['head']==c['head']and d['tree']==c['tree']and len(d['runs'])==18 and len({x['id']for x in d['runs']})==18
footer=c['whole_footer'];candidate={'head':c['head'],'tree':c['tree'],'base':c['actual_committed_base'],'code_branch':'steward/t2386-wolfpoint-picture','PR':1336,'expected_gate_steps':int(re.search(r'CHECK PASS — (\d+) steps',footer)[1]),'expected_self_tests':int(re.search(r'(\d+) of them are self-tests',footer)[1])};save('FINAL-CANDIDATE.json',candidate)
save('FINISH-RESULT.json',{'status':'ACTUALFULL3_COMMITTED_ENDINGCHECKS_NORMALPUSH_DRAFT_ONE18DISPATCHED_NOT_RESULTS','at':now(),'candidate':candidate,'steps':steps,'source_frozen_no_ready_or_merge':True,'originalT2386':'DIFFERS/notDONE','next':'Read-onlysame18+hostedchecks; publishcheckpointandhandoffcheckedWolftoTremontactor. JailandMarymustlandfirst; rootaloneREADY+merge afterlatestdevintegration/equalnativeglobalhashproof/revalidation.'});print(json.dumps(json.loads((P/'FINISH-RESULT.json').read_text()),indent=2),flush=True)
