from pathlib import Path
import urllib.request,urllib.parse,json,time,datetime,hashlib
P=Path('/workspace/shared/WolfPoint-T2386-Mary-bffc-stack-20261026T1402/updated-public');C=json.loads((P/'RESULT.json').read_bytes());head=C['head'];branch=C['branch'];O=Path('/workspace/shared/WolfPoint-T2386-Mary-bffc-stack-20261026T1402/full18-final');O.mkdir(exist_ok=False);API='https://api.github.com/repos/kevinrhaas/chicago/'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def req(path,method='GET',data=None):
 raw=None if data is None else json.dumps(data).encode();request=urllib.request.Request(API+path,data=raw,method=method,headers={'Accept':'application/vnd.github+json','Content-Type':'application/json','Cache-Control':'no-cache','User-Agent':'WolfPoint-T2386-full18'})
 with urllib.request.urlopen(request,timeout=120)as response:
  b=response.read();return (json.loads(b)if b else None,{'status':response.status,'request_id':response.headers.get('X-GitHub-Request-Id'),'at':now()})
def get(path):return req(path)[0]
def save(name,value):(O/name).write_text(json.dumps(value,indent=2)+'\n')
freshdev=get('git/ref/heads/dev');save('FRESH-REMOTE-DEV-AT-DISPATCH-START.json',freshdev);assert C['base']=='a9c5bd4a9715e4d5634c536d0efcd516ea9c3f01';pr=get('pulls/'+str(C['PR']));assert pr['draft'] and pr['head']['sha']==head and pr['base']['ref']=='dev';save('INITIAL-PR.json',pr)
refpath='git/ref/heads/'+urllib.parse.quote(branch,safe='/');assert get(refpath)['object']['sha']==head
commit=get('git/commits/'+head);assert commit['tree']['sha']==C['tree'];save('PUBLIC-COMMIT.json',commit)
request=urllib.request.Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+head+'/.github/workflows/chicago-4d-smoke.yml',headers={'Cache-Control':'no-cache','User-Agent':'WolfPoint-T2386-full18'});workflow=urllib.request.urlopen(request,timeout=90).read();(O/'immutable-workflow.yml').write_bytes(workflow)
query='actions/workflows/chicago-4d-smoke.yml/runs?branch='+urllib.parse.quote(branch,safe='')+'&event=workflow_dispatch&per_page=100'
initial=get(query);save('INITIAL-RUNS.json',initial);known={r['id']for r in initial['workflow_runs']};same=[r for r in initial['workflow_runs']if r['head_sha']==head];assert not same,'Existing exact-head smoke found; no duplicate dispatch'
stages=['13','1-2','3-4','5','6-7','8','9-12','14','15'];plan=[{'viewport':v,'stage':s}for s in stages for v in ['desktop','mobile']];save('DISPATCH-PLAN.json',{'status':'PLAN_NOT_RESULTS','head':head,'tree':C['tree'],'branch':branch,'PR':C['PR'],'workflow_sha256':hashlib.sha256(workflow).hexdigest(),'groups':plan,'source_freeze':True,'long_part13_first_only_scheduling_no_assertion_change':True})
rows=[]
for item in plan:
 assert get(refpath)['object']['sha']==head,'Source ref moved; stop remaining dispatches'
 _,accepted=req('actions/workflows/chicago-4d-smoke.yml/dispatches','POST',{'ref':branch,'inputs':item});assert accepted['status']==204;save(item['viewport']+'-'+item['stage']+'-ACCEPTED.json',accepted)
 until=time.monotonic()+180;run=None
 while time.monotonic()<until:
  batch=get(query);new=[r for r in batch['workflow_runs']if r['id']not in known and r['head_sha']==head and r['head_branch']==branch and r['event']=='workflow_dispatch']
  assert len(new)<=1,'Ambiguous simultaneous dispatch; retain evidence, no invented mapping'
  if new:run=new[0];break
  time.sleep(3)
 assert run is not None,'Accepted dispatch not yet bound; stop and preserve receipt before any retry'
 known.add(run['id']);save(item['viewport']+'-'+item['stage']+'-RUN.json',run);row=dict(item,id=run['id'],url=run['html_url'],observed_head=run['head_sha'],dispatch_accepted=True,accepted_at=accepted['at'],created_at=run['created_at']);rows.append(row);save('BOUND_DISPATCH.json',{'status':'DISPATCH_IN_PROGRESS_NOT_RESULTS','head':head,'tree':C['tree'],'branch':branch,'PR':C['PR'],'runs':rows});print(json.dumps(row),flush=True)
assert len(rows)==18 and len({r['id']for r in rows})==18
assert get(refpath)['object']['sha']==head
result={'status':'DISPATCHED_NOT_RESULTS','started':min(r['accepted_at']for r in rows),'finished_dispatch':now(),'head':head,'tree':C['tree'],'base':C['base'],'branch':branch,'PR':C['PR'],'workflow_sha256':hashlib.sha256(workflow).hexdigest(),'runs':rows,'root_owns_ready_and_merge':True,'fresh_remote_dev_at_start':freshdev['object']['sha']};save('COMPLETE_DISPATCH.json',result);print(json.dumps({'status':result['status'],'PR':C['PR'],'head':head,'all18_unique_runIDs':[r['id']for r in rows]}),flush=True)
