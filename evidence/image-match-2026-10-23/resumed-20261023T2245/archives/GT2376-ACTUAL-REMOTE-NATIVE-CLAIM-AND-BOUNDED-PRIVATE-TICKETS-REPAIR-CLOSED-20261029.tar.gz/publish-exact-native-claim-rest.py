from pathlib import Path
import subprocess,json,os,datetime,re,hashlib
r=Path('/tmp/chicago-green-tree-integration/chicago/4d/tickets');h=Path('/workspace/T2376-annex-20261029/NATIVE-CLAIM-EXACT-REST-TRANSPORT');h.mkdir(exist_ok=False);env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=r,env=env)
def api(p,payload=None):
 args=['gh','api','repos/kevinrhaas/chicago-tickets/'+p]
 if payload is not None:args+=['--method','POST'if'/refs/'not in p else'PATCH','--input','-']
 return json.loads(subprocess.check_output(args,input=json.dumps(payload).encode()if payload is not None else None,env=env))
base='a30790141cfb8179c0a0889cb06229fe65cb392e';tip=git('rev-parse','HEAD').decode().strip();assert tip=='0295b4baa35f30bee07a2782805140a9ff809eb0'
assert api('git/ref/heads/main')['object']['sha']==base
raw=git('cat-file','commit',tip);head,msg=raw.split(b'\n\n',1);heads=head.decode().splitlines();assert [x for x in heads if x.startswith('parent ')]==['parent '+base];assert not any(x.startswith('gpgsig')for x in heads)
paths=git('diff','--name-only',base,tip).decode().splitlines();assert paths==['T-2250-2499/T-2376-match-the-green-tree-tavern-to-its-pictures.md'],paths
basecommit=api('git/commits/'+base);entries=[]
for p in paths:
 b=git('show',tip+':'+p);assert len(b)<30000
 j=api('git/blobs',{'encoding':'utf-8','content':b.decode()});assert j['sha']==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 entries.append({'path':p,'mode':'100644','type':'blob','sha':j['sha']})
tr=api('git/trees',{'base_tree':basecommit['tree']['sha'],'tree':entries});expectedtree=next(x[5:]for x in heads if x.startswith('tree '));assert tr['sha']==expectedtree
payload={'tree':tr['sha'],'parents':[base],'message':msg.decode()}
for kind in ['author','committer']:
 line=next(x for x in heads if x.startswith(kind+' '));m=re.fullmatch(kind+r' (.*) <([^>]+)> (\d+) ([+-]\d{4})',line);assert m
 zone=m[4];seconds=(int(zone[1:3])*60+int(zone[3:]))*60*(1 if zone[0]=='+'else-1);dt=datetime.datetime.fromtimestamp(int(m[3]),datetime.timezone(datetime.timedelta(seconds=seconds)))
 payload[kind]={'name':m[1],'email':m[2],'date':dt.isoformat()}
commit=api('git/commits',payload);(h/'API-COMMIT-CREATED.json').write_text(json.dumps(commit,indent=2)+'\n');assert commit['sha']==tip,(commit['sha'],tip)
assert api('git/ref/heads/main')['object']['sha']==base,'Remoteadvanced;stopbeforerefupdate'
ref=api('git/refs/heads/main',{'sha':tip,'force':False});assert ref['object']['sha']==tip
fresh=api('git/ref/heads/main');assert fresh['object']['sha']==tip
result={'status':'EXACT_NATIVE_CLAIM_COMMIT_PUBLISHED_BY_BOUNDED_REST_TRANSPORT_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'tip':tip,'tree':expectedtree,'paths':paths,'native_commit_SHA_unchanged':True,'fresh_remote_ref_SHA':fresh['object']['sha'],'force':False,'scope':'OnlynativeclaimcommitforT2376;working/nativeclaimandhistorypreserved. No appsourcefetchorother-ticketoverwrite.'}
(h/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
