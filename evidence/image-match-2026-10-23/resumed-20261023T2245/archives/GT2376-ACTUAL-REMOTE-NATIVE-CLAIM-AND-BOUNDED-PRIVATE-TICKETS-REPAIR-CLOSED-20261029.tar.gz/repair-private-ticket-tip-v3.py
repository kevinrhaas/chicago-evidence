from pathlib import Path
import subprocess,json,os,hashlib,base64,datetime,shutil,struct,itertools
r=Path('/tmp/chicago-green-tree-integration/chicago/4d/tickets')
h=Path('/workspace/T2376-annex-20261029/TICKETS-CURRENT-TIP-REPAIR-v3');h.mkdir(exist_ok=False)
env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def git(*a,input=None): return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=r,env=env,input=input)
def api(p): return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago-tickets/'+p],env=env))
def sha(kind,b): return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
head=git('rev-parse','HEAD').decode().strip();cached=git('rev-parse','refs/remotes/origin/main').decode().strip()
tip=api('git/ref/heads/main')['object']['sha'];c=api('git/commits/'+tip);t=api('git/trees/'+c['tree']['sha']+'?recursive=1');assert not t.get('truncated')
for n,x in [('API-COMMIT',c),('API-TREE',t)]: (h/(n+'.json')).write_text(json.dumps(x,indent=2)+'\n')
shutil.copy2(r/'.git/index',h/'ORIGINAL.index');(h/'ORIGINAL-HEAD.txt').write_text(head+'\n');(h/'ORIGINAL-ORIGIN.txt').write_text(cached+'\n')
entries={x['path']:x for x in t['tree'] if x['type']=='blob'};assert len(entries)<10000
diff=[]
for p,x in entries.items():
 f=r/p
 if not f.is_file(): diff.append({'path':p,'missing':True});continue
 b=f.read_bytes()
 if sha('blob',b)!=x['sha']:
  q=h/'ORIGINAL-WORKING'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,q);diff.append({'path':p,'bytes':len(b),'sha1':sha('blob',b)})
(h/'ORIGINAL-WORKING-DIFFERENCES.json').write_text(json.dumps(diff,indent=2)+'\n')
indexes=[]
for p in (r/'.git/objects/pack').glob('*.idx'):
 with p.open('rb') as f:
  assert f.read(8)==b'\xfftOc\x00\x00\x00\x02';fan=struct.unpack('>256I',f.read(1024));tab=f.read(20*fan[-1]);indexes.append(set(tab[i:i+20]for i in range(0,len(tab),20)))
def present(s):return(r/'.git/objects'/s[:2]/s[2:]).is_file()or any(bytes.fromhex(s)in x for x in indexes)
missing={x['sha']:x for x in entries.values()if not present(x['sha'])};price=sum(x['size']for x in missing.values())
assert len(missing)<=64 and price<=8*1024*1024 and all(x['size']<=4*1024*1024 for x in missing.values()),(len(missing),price)
objects={}
trees={'':c['tree']['sha'],**{x['path']:x['sha']for x in t['tree']if x['type']=='tree'}}
for path,s in trees.items():
 if present(s):continue
 prefix=path+'/'if path else'';kids=[x for x in t['tree']if x['path'].startswith(prefix)and'/'not in x['path'][len(prefix):]]
 kids.sort(key=lambda x:(x['path'][len(prefix):]+('/'if x['type']=='tree'else'')).encode())
 b=b''.join((('40000'if x['type']=='tree'else x['mode'])+' '+x['path'][len(prefix):]).encode()+b'\0'+bytes.fromhex(x['sha'])for x in kids)
 assert sha('tree',b)==s,(path,s);objects[s]=('tree',b)
if not present(tip):
 assert c['verification']['reason']=='unsigned',c['verification']['reason']
 epochs={k:int(datetime.datetime.fromisoformat(c[k]['date'].replace('Z','+00:00')).timestamp())for k in ['author','committer']}
 zones=['+0000']+[f'{"+"if m>=0 else"-"}{abs(m)//60:02}{abs(m)%60:02}'for m in range(-12*60,14*60+1,15)if m]
 found=None
 for az,cz,end in itertools.product(zones,zones,['\n','']):
  b=('tree '+c['tree']['sha']+'\n'+''.join('parent '+x['sha']+'\n'for x in c['parents'])+''.join(k+' '+c[k]['name']+' <'+c[k]['email']+'> '+str(epochs[k])+' '+z+'\n'for k,z in [('author',az),('committer',cz)])+'\n'+c['message']+end).encode()
  if sha('commit',b)==tip:found=b;break
 assert found is not None,'API commit could not be reconstructed exactly; stop without writing/reset'
 objects[tip]=('commit',found)
(h/'EXACT-PRICE.json').write_text(json.dumps({'tip':tip,'missing_blobs':missing,'blob_bytes':price,'metadata_objects':len(objects),'metadata_bytes':sum(len(b)for k,b in objects.values())},indent=2)+'\n')
print('EXACT_PRIVATE_PRICE',len(missing),price,'metadata',len(objects),sum(len(b)for k,b in objects.values()),flush=True)
for s,(kind,b) in objects.items(): assert git('hash-object','-w','-t',kind,'--stdin',input=b).decode().strip()==s
for s,x in missing.items():
 j=api('git/blobs/'+s);b=base64.b64decode(j['content']);assert len(b)==j['size']==x['size']and sha('blob',b)==s;assert git('hash-object','-w','--stdin',input=b).decode().strip()==s
assert api('git/ref/heads/main')['object']['sha']==tip,'Fresh remote advanced; exact imported bytes retained, state unchanged'
ref='refs/checkpoints/t2376-local-claim-before-exact-tip-repair-v3-20261029';git('update-ref',ref,head,'0'*40)
git('reset','--hard',tip);git('update-ref','refs/remotes/origin/main',tip,cached)
for p,x in entries.items():
 b=(r/p).read_bytes();assert len(b)==x['size']and sha('blob',b)==x['sha'],p
assert not git('status','--porcelain=v1').strip()
result={'status':'EXACT_BOUNDED_PRIVATE_TICKETS_TIP_REPAIR_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tip':tip,'old_head':head,'old_origin':cached,'saved_ref':ref,'all_tip_files':len(entries),'imported_blob_bytes':price,'imported_blob_count':len(missing),'imported_metadata_count':len(objects),'scope':'Onlyownedprivatechicago-ticketsclone. No fetch, no appsource/commonGitobjectsrefsHEADindexconfigmutation. Priorlocalclaimandworking/indexpreserved.'}
(h/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
