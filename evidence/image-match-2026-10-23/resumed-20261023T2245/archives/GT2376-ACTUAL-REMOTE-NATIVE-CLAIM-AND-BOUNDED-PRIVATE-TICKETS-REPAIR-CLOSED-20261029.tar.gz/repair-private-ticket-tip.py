from pathlib import Path
import subprocess,json,os,hashlib,base64,datetime,shutil,struct
r=Path('/tmp/chicago-green-tree-integration/chicago/4d/tickets');h=Path('/workspace/T2376-annex-20261029/TICKETS-CURRENT-TIP-REPAIR');h.mkdir(exist_ok=False);env=dict(os.environ,GIT_NO_LAZY_FETCH='1');sh=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,input=None):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],input=input,cwd=r,env=env)
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago-tickets/'+path],env=env))
head=git('rev-parse','HEAD').decode().strip();tip=git('rev-parse','refs/remotes/origin/main').decode().strip();remote=api('git/ref/heads/main')['object']['sha'];assert tip==remote,(tip,remote)
commit=api('git/commits/'+tip);tree=api('git/trees/'+commit['tree']['sha']+'?recursive=1');assert not tree.get('truncated');entries={x['path']:x for x in tree['tree']if x['type']=='blob'};assert len(entries)<10000
(h/'API-COMMIT.json').write_text(json.dumps(commit,indent=2)+'\n');(h/'API-TREE.json').write_text(json.dumps(tree,indent=2)+'\n');shutil.copy2(r/'.git/index',h/'ORIGINAL.index');(h/'ORIGINAL-HEAD.txt').write_text(head+'\n');(h/'ORIGINAL-MAIN-REF.txt').write_text((r/'.git/refs/heads/main').read_text()if(r/'.git/refs/heads/main').exists()else'packed ref\n')
# Preserve every working file that differs from the exact cached remote tree.
different=[]
for p,x in entries.items():
 f=r/p
 if not f.is_file():different.append({'path':p,'missing':True});continue
 b=f.read_bytes();sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 if sha!=x['sha']:
  q=h/'ORIGINAL-WORKING'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,q);different.append({'path':p,'bytes':len(b),'sha1':sha,'saved':str(q.relative_to(h))})
(h/'ORIGINAL-WORKING-DIFFERENCES.json').write_text(json.dumps(different,indent=2)+'\n')
# Membership uses existing loose paths and IDX SHA tables only. No missing-object query/fetch.
indexes=[]
for p in(r/'.git/objects/pack').glob('*.idx'):
 with p.open('rb')as f:
  if f.read(8)!=b'\xfftOc\x00\x00\x00\x02':continue
  fan=struct.unpack('>256I',f.read(1024));indexes.append(set(f.read(20*fan[-1])[i:i+20]for i in range(0,20*fan[-1],20)))
def present(sha):return(r/'.git/objects'/sha[:2]/sha[2:]).is_file()or any(bytes.fromhex(sha)in i for i in indexes)
missing={x['sha']:x for x in entries.values()if not present(x['sha'])};price=sum(x['size']for x in missing.values());assert len(missing)<=64 and price<=8*1024*1024 and all(x['size']<=4*1024*1024 for x in missing.values()),(len(missing),price)
(h/'EXACT-PRICE.json').write_text(json.dumps({'tip':tip,'missing_blobs':missing,'count':len(missing),'canonical_bytes':price,'private_working_saved':different},indent=2)+'\n');print('EXACT_PRIVATE_TIP_PRICE',len(missing),price,flush=True)
for sha,x in missing.items():
 j=api('git/blobs/'+sha);b=base64.b64decode(j['content']);assert j['size']==x['size']==len(b)and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==sha;assert git('hash-object','-w','--stdin',input=b).decode().strip()==sha
assert api('git/ref/heads/main')['object']['sha']==tip,'Fresh remote advanced; keep imported bytes and original state, stop before reset'
ref='refs/checkpoints/t2376-native-claim-before-private-tip-repair-20261029';git('update-ref',ref,head,'0'*40)
# This private clone's native recovery already requested this reset but missing blobs prevented it.
git('reset','--hard',tip)
for p,x in entries.items():
 b=(r/p).read_bytes();assert len(b)==x['size']and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['sha'],p
assert git('rev-parse','HEAD').decode().strip()==tip and not git('status','--porcelain=v1').strip()
(h/'RESULT.json').write_text(json.dumps({'status':'EXACT_BOUNDED_PRIVATE_TICKET_TIP_REPAIRED_NO_SOURCE_FETCH','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tip':tip,'tree':commit['tree']['sha'],'all_tip_files_SHA1_size_verified':len(entries),'imported_blobs':len(missing),'canonical_import_bytes':price,'old_HEAD_saved_ref':ref,'working_differences_saved':different,'app_source_scope':'NONE; onlyownedprivatechicago-ticketsclone touched. No sourcecommonGitobjects/refs/HEAD/index/config orfetch/GC/repack.'},indent=2)+'\n');print((h/'RESULT.json').read_text(),flush=True)
