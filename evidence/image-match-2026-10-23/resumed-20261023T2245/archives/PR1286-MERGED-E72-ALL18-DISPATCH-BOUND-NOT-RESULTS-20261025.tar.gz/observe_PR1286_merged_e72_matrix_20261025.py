from pathlib import Path
import concurrent.futures, datetime, hashlib, json, re, time, urllib.request, urllib.error

ROOT = Path('/tmp/PR1286-merged-e72-native-matrix-20261025')
D = json.loads((ROOT / 'COMPLETE_DISPATCH.json').read_text())
OUT = ROOT / 'observer'
OUT.mkdir(exist_ok=True)
HEAD = D['head']
API = 'https://api.github.com/repos/kevinrhaas/chicago/'
assert len(D['runs']) == 18 and len({x['id'] for x in D['runs']}) == 18
assert all(x['observed_head'] == HEAD and x['dispatch_accepted'] for x in D['runs'])

def get(path, raw=False):
    with urllib.request.urlopen(urllib.request.Request(API + path, headers={'Accept':'application/vnd.github+json'}), timeout=90) as r:
        b = r.read()
    return b if raw else json.loads(b)

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(name, data):
    p = OUT / name
    body = data if isinstance(data, bytes) else (json.dumps(data, indent=2) + '\n').encode()
    if p.exists():
        assert p.read_bytes() == body, 'Never overwrite preserved evidence'
    else:
        p.write_bytes(body)

def metadata(x):
    try:
        r = get('actions/runs/' + str(x['id']))
        assert r['head_sha'] == HEAD and r['head_branch'] == D['branch'] and r['event'] == 'workflow_dispatch'
        return x, r, None
    except Exception as e:
        return x, None, {'id':x['id'], 'type':type(e).__name__, 'HTTP':getattr(e, 'code', None)}

def harvest(x, run):
    result_path = OUT / ('verified-' + str(x['id']) + '.json')
    if result_path.exists():
        return json.loads(result_path.read_text())
    jobs = get('actions/runs/' + str(x['id']) + '/jobs?per_page=100')
    save('jobs-' + str(x['id']) + '.json', jobs)
    matches = [j for j in jobs['jobs'] if j['name'] == 'smoke' and j['status'] == 'completed']
    assert len(matches) == 1
    j = matches[0]
    raw = get('actions/jobs/' + str(j['id']) + '/logs', raw=True)
    name = 'run-' + str(x['id']) + '-job-' + str(j['id']) + '.log'
    save(name, raw)
    text = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode('utf-8','replace'))
    lines = text.splitlines()
    checkout = None
    for i,line in enumerate(lines[:-1]):
        if '[command]' in line and 'git log -1 --format=%H' in line:
            m = re.search(r'Z ([0-9a-f]{40})$', lines[i+1])
            if m:
                checkout = m.group(1)
    viewport = re.findall(r'SMOKE_VIEWPORT: ([^\s]+)', text)
    stages = re.findall(r'SMOKE_STAGE: ([^\s]+)', text)
    counts = [{'passed':int(a),'failed':int(b)} for a,b in re.findall(r'(\d+) passed, (\d+) failed', text)]
    summary = {'run':x['id'],'job':j['id'],'viewport':x['viewport'],'stage':x['stage'],
        'head':HEAD,'actual_checkout':checkout,'run_conclusion':run['conclusion'],'job_conclusion':j['conclusion'],
        'actual_viewport':viewport,'actual_stages':stages,'counts':counts,
        'smoke_pass':'SMOKE PASS' in text,'zero_page_errors':'zero page errors' in text,
        'suite_body_aborted':bool(re.search(r'FAIL[^\n]*the suite body ran to completion',text)),
        'log':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
        'failure_lines':[{'line':i+1,'text':line[:1200]} for i,line in enumerate(lines) if re.search(r'\bFAIL\b|FAILURES:|\bError:|TimeoutError',line) and 'self-test' not in line]}
    summary['verified_success'] = (checkout == HEAD and viewport == [x['viewport']] and stages == [x['stage']]
        and run['conclusion'] == 'success' and j['conclusion'] == 'success'
        and summary['smoke_pass'] and summary['zero_page_errors'] and counts and all(c['failed'] == 0 for c in counts)
        and not summary['suite_body_aborted'])
    summary['verified_success'] = bool(summary['verified_success'])
    save('verified-' + str(x['id']) + '.json', summary)
    return summary

while True:
    with concurrent.futures.ThreadPoolExecutor(4) as pool:
        meta = list(pool.map(metadata, D['runs']))
    rows, errors, results = [], [], []
    for x,run,error in meta:
        if error:
            errors.append(error)
            continue
        rows.append({'id':x['id'],'viewport':x['viewport'],'stage':x['stage'],'status':run['status'],
            'conclusion':run['conclusion'],'head_sha':run['head_sha'],'run_attempt':run['run_attempt']})
        if run['status'] == 'completed':
            try:
                results.append(harvest(x,run))
            except Exception as e:
                errors.append({'id':x['id'],'type':type(e).__name__,'HTTP':getattr(e,'code',None)})
    snapshot = {'at':stamp(),'head':HEAD,'branch':D['branch'],'runs':rows,'read_errors':errors,
        'verified_successes':sum(x['verified_success'] for x in results),'actual_log_results':results,
        'all_18_actual_logs_success':len(results) == 18 and all(x['verified_success'] for x in results),
        'actual_failures':[x for x in results if not x['verified_success']]}
    save('snapshot-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%f') + '.json',snapshot)
    (OUT / 'LATEST.json').write_text(json.dumps(snapshot,indent=2) + '\n')
    print(json.dumps({'at':snapshot['at'],'terminal':sum(x['status']=='completed' for x in rows),
        'verified_successes':snapshot['verified_successes'],'errors':errors,
        'actual_failures':[{'run':x['run'],'viewport':x['viewport'],'stage':x['stage']} for x in snapshot['actual_failures']]}),flush=True)
    if len(results) == 18 and not errors:
        save('FINAL_ACTUAL_RESULTS.json', snapshot)
        raise SystemExit(0 if snapshot['all_18_actual_logs_success'] else 1)
    time.sleep(60)
