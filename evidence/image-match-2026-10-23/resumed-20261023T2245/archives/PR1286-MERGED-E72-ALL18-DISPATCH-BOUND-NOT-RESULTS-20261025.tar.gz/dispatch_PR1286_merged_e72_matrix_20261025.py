from pathlib import Path
import datetime, hashlib, json, time, urllib.request, urllib.error, urllib.parse

BASE = 'https://api.github.com/repos/kevinrhaas/chicago/'
HEAD = 'e72b8ba35750b468d6eb368324bf4e3508c51de3'
BRANCH = 'verification/t3126-merged-e72-20261025'
OUT = Path('/tmp/PR1286-merged-e72-native-matrix-20261025')
OUT.mkdir(exist_ok=True)
PLAN = [(v, s) for v in ('desktop', 'mobile') for s in ('1-2','3-4','5','6-7','8','9-12','13','14','15')]

def api(path, data=None):
    req = urllib.request.Request(BASE + path, data=None if data is None else json.dumps(data).encode(),
        headers={'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json'},
        method='GET' if data is None else 'POST')
    with urllib.request.urlopen(req, timeout=90) as r:
        body = r.read()
        return r.status, json.loads(body) if body else None

def save(name, value):
    p = OUT / name
    assert not p.exists(), 'Never overwrite an earlier dispatch receipt'
    p.write_text(json.dumps(value, indent=2) + '\n')

if (OUT / 'COMPLETE_DISPATCH.json').exists():
    raise SystemExit('Already dispatched; refusing duplicate run')
try:
    status, ref = api('git/ref/heads/' + BRANCH)
except urllib.error.HTTPError as e:
    assert e.code == 404
    status, ref = api('git/refs', {'ref': 'refs/heads/' + BRANCH, 'sha': HEAD})
    assert status == 201
    save('created-verification-ref.json', ref)
assert ref['object']['sha'] == HEAD
query = 'actions/workflows/chicago-4d-smoke.yml/runs?branch=' + urllib.parse.quote(BRANCH, safe='') + '&event=workflow_dispatch&per_page=100'
_, before = api(query)
assert not before['workflow_runs'], 'Existing runs need reconciliation; do not dispatch duplicates'
save('PLAN.json', {'authorized_by': 'root 2026-10-25', 'PR': 1286, 'head': HEAD, 'tree': '4a262ea93fba930cbf833229f1538762a6763940', 'branch': BRANCH, 'legs': PLAN,
    'native_workflow_sha256': 'f0f6c6f5cf942af4e49609b7854bdd1472bd98e06159e687ed76893138e7a73c',
    'command': 'node tools/smoke_renderer.mjs --published', 'scope': 'Postmerge validation of actual merged tree; oldcef results not reused. Native caps/assertions unchanged.'})
seen = set()
runs = []
for viewport, stage in PLAN:
    _, current = api('git/ref/heads/' + BRANCH)
    assert current['object']['sha'] == HEAD, 'Verification ref moved; stop'
    payload = {'ref': BRANCH, 'inputs': {'viewport': viewport, 'stage': stage}}
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    status, response = api('actions/workflows/chicago-4d-smoke.yml/dispatches', payload)
    assert status == 204
    save('accepted-' + viewport + '-' + stage + '.json', {'accepted_at': started, 'HTTP': status, 'request': payload, 'response': response})
    deadline = time.monotonic() + 100
    while True:
        _, got = api(query)
        new = [x for x in got['workflow_runs'] if x['id'] not in seen]
        if new:
            assert len(new) == 1, 'Ambiguous run IDs; preserve receipts and reconcile'
            run = new[0]
            assert run['head_sha'] == HEAD and run['head_branch'] == BRANCH and run['event'] == 'workflow_dispatch'
            seen.add(run['id'])
            row = {'id': run['id'], 'viewport': viewport, 'stage': stage, 'dispatch_accepted': True, 'observed_head': run['head_sha'], 'created_at': run['created_at'], 'url': run['html_url']}
            runs.append(row)
            save('bound-' + viewport + '-' + stage + '.json', {'requested': row, 'actual_run': run})
            print(json.dumps(row), flush=True)
            break
        assert time.monotonic() < deadline, 'Dispatch accepted but run binding unavailable; do not retry dispatch'
        time.sleep(2)
save('COMPLETE_DISPATCH.json', {'PR': 1286, 'head': HEAD, 'tree': '4a262ea93fba930cbf833229f1538762a6763940', 'branch': BRANCH, 'runs': runs,
    'dispatched_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': '18_DISPATCH_ACCEPTED_HEAD_BOUND_NOT_PASS'})
print('COMPLETE18_DISPATCH_NOT_PASS', flush=True)
