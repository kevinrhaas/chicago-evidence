# Actual school doorway trial — differs

One official pinned-Blender export and one photo-match capture completed successfully on 23 October 2026, after root resumed the frozen door-only comparison. Direct inspection of the full source, original actual before-comparison, full new actual comparison and identical source/before/after detail shows a visibly darker recessed doorway, closer to the illustrated exterior opening.

The school still differs: its frontage is much broader under this unchanged provisional camera, its gable remains a plain roof-coloured triangle instead of the drawing’s continuing horizontal logs, roof covering and log/chink relief are absent, openings/tones and the visible rear stack differ, and world/people/ground context is absent. The dark blind proxy does not establish a room, historical passage, door swing or 1835 occupant. Artist/publication, building identity and date remain unresolved. No accepted reference view, canonical asset, source rights change or ticket completion follows.

New master `de08343a76201c4e7199066b12c285efc28c855b0a84fbcf318796aadba3f8a2`, 496 triangles, 47,672 bytes. Camera/source hashes and all frozen input guards pass. The original generated unreviewed match is preserved separately; the isolated research match now records `differs`.

Baseline limitation: its PNG is a lossless encoding of the old JPEG comparison’s decoded render pixels, not the missing original bare screenshot. Full original JPEG is retained. Actual new bare PNG is preserved byte-exact. All browser/server/export processes have exited. Shared log81 canonical integration and family rebuild/gates/app QA remain owed.
