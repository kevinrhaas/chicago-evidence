from pathlib import Path
from urllib.request import Request, urlopen
import os, json, hashlib, subprocess, datetime, re, sys

os.sched_setaffinity(0,{2})
os.nice(15)
O=Path(__file__).parent; R=O/'tickets'; A=O/'app'
label=sys.argv[1]; assert label in ('GT','CB')
OUT=O/('live-own-'+label.lower()+'-renewal-20261030T0740');OUT.mkdir(exist_ok=True)
assert not (OUT/'COMPLETE.json').exists(), 'Already completed; do not duplicate renewal'
config={
 'GT':('T-2376','T-2250-2499/T-2376-match-the-green-tree-tavern-to-its-pictures.md','GT-LIVE-OWN-PUBLISHED-RENEWAL.json','9ed1547ff634555c5e4d883065f0ad1589718800','Codex Green Tree optional Andreas annex 2026-10-29'),
 'CB':('T-2382','T-2250-2499/T-2382-match-philo-carpenter-s-log-shop-the-sauganash-s.md','CB-PUBLISHED-RENEWAL.json','eaa28e9a466d19ff8432f166c6d32c998cfa5e2b','Codex Carpenter picture match 2026-10-29'),
}
ticket,P,pointer,oldhead,by=config[label]
E=dict(os.environ,PATH=str(O/'bin')+':'+os.environ['PATH'],CHICAGO_TICKETS_DIR=str(R),GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',NODE_DISABLE_COMPILE_CACHE='1',TMPDIR=str(OUT))
def save(name,j): (OUT/name).write_text(json.dumps(j,indent=2)+'\n')
def api(repo,path):
 with urlopen(Request('https://api.github.com/repos/kevinrhaas/'+repo+'/'+path,headers={'User-Agent':'Chicago-live-own-original-renewals','Cache-Control':'no-cache'}),timeout=45) as f:return json.load(f)
def raw(head):
 with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+head+'/'+P,headers={'User-Agent':'Chicago-exact-live-own-ticket-guard'}),timeout=45) as f:return f.read()
def git(*args):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),'-c','protocol.https.allow=never','-c','protocol.http.allow=never','-c','gc.auto=0',*args],env=E)
def free(path):s=os.statvfs(path);return s.f_bavail*s.f_frsize
old=json.loads((O/pointer).read_bytes());assert old['head']==oldhead and old['path']==P
tip=api('chicago-tickets','git/ref/heads/main')['object']['sha'];body=raw(tip);oldbody=raw(oldhead)
assert body==oldbody and ('claimed_by: '+by).encode() in body
assert ('claimed_at: '+old['claim_at']).encode() in body
assert datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(old['expires_utc']), 'Expected LIVE same-owner claim expired; reassess TTL explicitly'
prs=api('chicago','pulls?state=open&per_page=100');assert not [p for p in prs if re.search(r'(?i)T-?'+ticket[2:]+r'\b',p['title'])], 'Unexpected open ticket PR; coordinate before renewal'
refs=subprocess.check_output(['/usr/local/bin/git','-c','protocol.https.allow=always','ls-remote','--heads','https://github.com/kevinrhaas/chicago.git'],env=E,text=True)
actual={n.removeprefix('refs/heads/'):sid for sid,n in map(str.split,refs.splitlines()) if re.search(r'(?i)t-?'+ticket[2:]+r'(?:[-_]|$)',n)}
if label=='GT':
 history=json.loads(Path('/workspace/GT-sparse-official-renewal-publisher-20261030/EXACT-OWN-BRANCH-REVIEW.json').read_bytes());expected={r['branch']:r['sha'] for r in history['rows']}
else:expected={'steward/t2382-carpenter-picture-currentdev':'b2920a32864bd2494237c0510c170ae42c8c25e3','verification/t2382-f311c2a9b762-source-cards-20261026':'f311c2a9b7628e22835973933c9de41b83a2b531'}
assert actual==expected, 'New or changed matching branch; do not force'
assert not git('status','--porcelain').strip() and (R/P).read_bytes()==body
pre={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'LIVE_SAME_OWNER_EXACT_PRIOR_PUBLISHED_BLOB_AND_BRANCHES','ticket':ticket,'remote_main':tip,'old_receipt':old,'old_blob':hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest(),'all_matching_code_branches':actual,'no_open_title_PR':True,'workspace_free':free('/workspace'),'tmp_free':free('/tmp'),'official_tool_sha256':hashlib.sha256((A/'chicago/4d/tools/ticket.mjs').read_bytes()).hexdigest()}
save('PREFLIGHT.json',pre)
if len(sys.argv)>2 and sys.argv[2]=='--preflight-only':print(json.dumps(pre));raise SystemExit(0)
assert pre['workspace_free']>=536870912+8*1024**2 and pre['tmp_free']>=1800000000, 'Unchanged caller resource floor unmet; official CLI not invoked'
bind=json.loads((O/'BINDING.json').read_bytes());save('PREVIOUS-BINDING.json',bind);(OUT/'BEFORE.md').write_bytes(body);save('PREVIOUS-RENEWAL.json',old)
bind.update(tip=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),path=P,old_blob=pre['old_blob'],old_sha256=hashlib.sha256(body).hexdigest(),active_ticket=ticket,claim_force_exception='Root-authorized LIVE SAME OWNER renewal of exact '+oldhead+' original claim only. Native --force overrides only our own still-live claim and unchanged reviewed cold historical branches; not dead/foreign takeover. No branch/lap/code ref changes; ordinary normalFF/forcefalse ticket publication and every foreign path/mode/blob exact.')
(O/'BINDING.json').write_text(json.dumps(bind,indent=2)+'\n');(O/'ACTIVE-BEFORE.md').write_bytes(body)
command=['node',str(A/'chicago/4d/tools/ticket.mjs'),'claim',ticket,'--by',by]
q=subprocess.run(command,cwd=A/'chicago/4d',env=E,capture_output=True,text=True,timeout=300);(OUT/'OFFICIAL-NO-FORCE.log').write_text(q.stdout+q.stderr)
save('OFFICIAL-NO-FORCE.json',{'exit':q.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()});print(q.stdout+q.stderr,flush=True)
if q.returncode:
 assert (R/P).read_bytes()==body and not git('status','--porcelain').strip(), 'Unexpected failed CLI mutation; preserve and inspect'
 fresh=api('chicago-tickets','git/ref/heads/main')['object']['sha'];assert raw(fresh)==body
 assert free('/workspace')>=536870912+8*1024**2 and free('/tmp')>=1800000000
 q=subprocess.run([*command,'--force'],cwd=A/'chicago/4d',env=E,capture_output=True,text=True,timeout=300);(OUT/'OFFICIAL-LIVE-OWN-FORCE.log').write_text(q.stdout+q.stderr);print(q.stdout+q.stderr,flush=True)
assert q.returncode==0, 'No successful renewal claimed; inspect retained native refusal or unpublished local commit'
pub=json.loads((O/'PUBLISHED-RENEWAL.json').read_bytes());assert pub['path']==P and pub['head']!=oldhead and not pub['force_push']
assert pub['claim_at']!=old['claim_at'] and pub['only_changed_fields']==['claimed_at','claimed_by'] and pub['primary_app_source_Git_site_and_nested_mirror_writes'] is False
save('COMPLETE.json',pub);(O/pointer).write_text(json.dumps(pub,indent=2)+'\n');print(json.dumps(pub),flush=True)
