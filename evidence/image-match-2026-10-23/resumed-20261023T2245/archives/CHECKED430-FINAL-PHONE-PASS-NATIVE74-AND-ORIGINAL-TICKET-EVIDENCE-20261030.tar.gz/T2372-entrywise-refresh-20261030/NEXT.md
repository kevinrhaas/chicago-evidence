# Current School12-path adoption refresh — prepared, not applied

Read-only preparation and validation actually passed on current primary HEAD
`4b22bc35474809cd03d55368ec5d61b0be842059`, with the later integration merge still
uncommitted and its full gate active. These are CURRENT SOURCE preimages, not a
claim that this older HEAD is the final checked/squashed dev result. The actual
1456 dev squash and changelog fold are unknown. Reprepare into a fresh output
against that actual current checkout, or revalidate every preimage and dependency
before adoption. No primary, Git, ticket, site, owner, app, browser or bake action
ran in this refresh. The School claim was reported renewed through10:15UTC; that
dated status is not a future claim renewal or a substitute for the writer's own
live claim/lease check.

## Concrete payload and entrywise preservation

`current-packet/ADOPTION-PLAN.json` binds12 actual postimages, including a
3701B Liberty suffix instead of a whole historical Liberty document. It contains
six authored source paths, four native model/registry paths and two already
qualified canonical picture artifacts. `PATH-SPLIT.json` names every path and its
owner category. This is a concrete prepared payload, not just a future plan.

The School record retains all20 final accepted leaf edits and is byte-exact to
the accepted native candidate `bca1984…`. Its research-note leaf includes the
already reviewed584B dated trial supersession missing from the older20-leaf
listing. No geometry value is newly chosen. Shared grade and image STORE tables
are rebuilt from CURRENT bytes entrywise: all foreign lists/order/metadata remain
exact, STORE1302→1304 adds only the two hosted School images, and the existing
3,441,429B Liberty prefix is unchanged. The exact older2641B School suffix remains
intact and is followed by1060B explicitly distinguishing completed native
bake/capture from pending app/owner qualification.

Both actual official-owner artifacts and their native registry entries are
preserved: MASTER `fb141fef3f348b494ffbf1bc2479427d0cec499001605cdcb34ce52c93c0787a`,
WEB `f120aa9abc970bb5b0b28f82c5fd176b268ba67923cea9b31de9967c8c9bf804`,
full native recipe `2fe83632046f2462e58524944e13e970ace9824693f5141f3769c1b726537f44`.
The current resolved recipe equals the actual selected-owner document; no repeat
bake is indicated while that exact recipe remains current. All foreign model
registry rows/order/metadata survive; no old whole registry or typed recipe hash
replaces them.

Canonical camera `ca092679…`, original source photo `1a63b75f…`, native reviewed
match with its seven dispositions, and actual side-by-side `905bfca7…` are unchanged.
The original raw unreviewed capture remains in its earlier closed packet. Actual
native capture/image-gate/root review were already completed; this refresh does
not pretend to rerun them. Native image-gate verification after adoption still
must bind those exact bytes. Source credit and the owner's approved attributed
project-reference use remain unchanged, with original publication/identity/date
and general rights limits explicit. No public-domain promotion, new rights
question or school/annex reidentification is made.

The current Women of Prairie Avenue jaunt and all12 source files it cites,
including the six recently added source records, are explicitly SHA-guarded and
are not adoption targets. Generated source catalog/usage outputs must come from
current native owners, not a historical catalog postimage. No jaunt/source row is
removed to fit the School work.

## Commands for the later separate School PR

Prepare a NEW external packet after actual dev squash/fold; replace the shown
head placeholder with the actual full commit SHA:

```sh
source /workspace/shared/resume-chicago-env.sh
python /workspace/T2372-entrywise-refresh-20261030/prepare.py --output /workspace/T2372-entrywise-refresh-20261030/rebound-ACTUAL --expected-head ACTUAL_CURRENT_HEAD
python /workspace/T2372-entrywise-refresh-20261030/apply_adoption.py --plan /workspace/T2372-entrywise-refresh-20261030/rebound-ACTUAL/ADOPTION-PLAN.json --expected-head ACTUAL_CURRENT_HEAD
```

The second command defaults to validation only. Actual application is reserved
for the sole primary writer on a clean claimed `steward/t2372-*` branch, no active
merge, explicit current head, unchanged dependencies/preimages and the existing
`SCHOOL_ADOPTION_LEASE=original-T2372-claimed-primary-released` plus `--apply`.
It writes12 paths by atomic replacement with a fsynced per-path journal; it never
stages, updates refs, claims tickets, runs owners or commits. Existing workspace
536,870,912B/TMP1,800,000,000B floors remain. Primary adoption did NOT run here.

The prior future wrapper had incompatible nested-output checks between its two
preparers. The new single direct preparer removes that dependency; its current
actual output and12-path validator have both run successfully. An initial wrong
expected-head literal was refused before output, corrected by reading actual Git
HEAD. The final receipt binds the real current head above.

## Owners and application checks still owed

After source adoption, build the current Prairie image library from current
streams/STORE, then run the settled native tail beginning at the CURRENT
`tools/compile_liberties.py` owner. The manifest currently has204 steps and this
is index143 (61 steps), including scene/structure grade147, entrances148, source
use151, lot-line fences162 and kept ground/yard paths182. Use the named native
tail, not a speculative full204 reconstruction or manual generated edits:

```sh
python3 ../prairie_1904_v1/tools/build_images.py
node tools/rederive.mjs --tail tools/compile_liberties.py
python3 tools/generate_alley_lanes.py
python3 tools/generate_alley_lanes.py --check
bash tools/publish.sh
node tools/image_gate.mjs --structure chappel_infant_school
```

Commands above are UNRUN in this refresh and belong to the later primary writer's
resource/CPU schedule. The explicit alley owner is essential: it is directly
checked by check.sh but absent from the204-step manifest, and the narrower school
removes the previously calculated6.5m alley-mouth cut. That arithmetic and the
26.36m nearest-envelope estimate are historical readiness calculations, not newly
run owners or terrain/access proof. Recheck current geometry with the actual
regenerated scene and retained props/rails/ground records. Publish runs the native
picture compiler; compile_scene uses the native structure grader. Retain current
source/jaunt/catalog additions through those owners.

Then perform Full390×780 and1280×800 Normal/ByGrade app acceptance: procedural
materials, credited full Images/Sources/Research/Liberties, front/door position,
new rear envelope, terrain contact, neighboring rails/paths/props, and a real
street-to-door walking approach. Complete relevant native published smokes,
phone budget, full foreground policy/preflight gate, checked commit, PR into dev,
actual current-head required CI, safe merge and official ticket settlement. No
app acceptance, PR, merge or T2372 completion is claimed here, and no new photo
follow-up ticket, split or geometry-tuning loop is proposed.
