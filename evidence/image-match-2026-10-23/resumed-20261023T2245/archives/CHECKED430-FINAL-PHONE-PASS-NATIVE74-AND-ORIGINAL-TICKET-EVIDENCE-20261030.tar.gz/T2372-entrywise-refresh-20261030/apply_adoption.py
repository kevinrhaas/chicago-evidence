"""Read-only validation by default. Applying requires original T2372 claim, clean school branch and explicit sole-writer lease.

Twelve exact source/native-owner/image postimages are written individually with atomic replace and a fsynced recovery journal. No staging, commit, refs, ticket or owner commands.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,stat,subprocess,sys,tempfile
sys.dont_write_bytecode=True
os.sched_setaffinity(0,{2})
P=Path(__file__).resolve().parent;R=Path('/workspace/chicago');A=R/'chicago/4d';SHA=lambda b:hashlib.sha256(b).hexdigest();PF=lambda p:SHA(p.read_bytes());E=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1')
SID='chappel_infant_school';NAME=SID+'__log_1833.glb';RECIPE='2fe83632046f2462e58524944e13e970ace9824693f5141f3769c1b726537f44'
def git(*args):return subprocess.check_output(['git','-C',str(R),*args],env=E)
def state():return {'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'index':PF(R/'.git/index'),'config':PF(R/'.git/config'),'refs':SHA(git('show-ref'))}
def bound(p):
 if not p.exists():return None
 assert p.is_file() and not p.is_symlink(),p
 return {'bytes':p.stat().st_size,'sha256':PF(p),'mode':oct(stat.S_IMODE(p.stat().st_mode))}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--plan',type=Path,default=P/'current-packet/ADOPTION-PLAN.json');ap.add_argument('--expected-head',required=True);ap.add_argument('--report',type=Path);ap.add_argument('--apply',action='store_true');args=ap.parse_args();assert args.plan.resolve().is_relative_to(P);plan=json.loads(args.plan.read_text());before=state();assert before['head']==args.expected_head
 for path,expected in plan['current_guarded_dependencies'].items():assert bound(Path(path))==expected,('Dependency changed; reprepare',path)
 assert len(plan['paths'])==12 and plan['recipe_sha256']==RECIPE
 receipt=Path(plan['actual_selected_owner_receipt']);assert PF(receipt)==plan['selected_owner_receipt_sha256']
 for row in json.loads(receipt.read_text())['members']:
  p=Path(row['path']);assert p.stat().st_size==row['bytes'] and PF(p)==row['sha256']
 prepared=[]
 for row in plan['paths']:
  rel=Path(row['path']);assert not rel.is_absolute() and '..' not in rel.parts and str(rel).startswith('chicago/')
  dest=R/rel
  for ancestor in [dest,*dest.parents]:
   if ancestor==R.parent:break
   assert not ancestor.is_symlink(),ancestor
  assert bound(dest)==row['before'],('Stale preimage; rebind entrywise to current primary before applying',row['path'])
  if 'fragment' in row:
   fragment=Path(row['fragment']).read_bytes();assert SHA(fragment)==row['fragment_sha256'];raw=dest.read_bytes()+fragment
  else:raw=Path(row['postimage']).read_bytes()
  assert len(raw)==row['after']['bytes'] and SHA(raw)==row['after']['sha256'],row['path']
  prepared.append((dest,raw,int(row['after']['mode'],8),row))
 docs={row['path']:raw for _,raw,_,row in prepared};record=json.loads(docs[f'chicago/4d/data/structures/{SID}.json'])
 # Independently recheck authored aggregate entry boundaries, not merely hashes.
 grades='chicago/4d/data/structure_grades.json';old=json.loads((R/grades).read_text());new=json.loads(docs[grades]);target=tuple(plan['source_rebind_proof']['grades']['target_key']);k=lambda r:(r.get('scene'),r.get('structure'),r.get('picture'))
 assert old['pictured']==new['pictured'];assert [r for r in old['not_pictured']if k(r)!=target]==[r for r in new['not_pictured']if k(r)!=target]
 assert {k:v for k,v in old.items()if k not in ['pictured','not_pictured']}=={k:v for k,v in new.items()if k not in ['pictured','not_pictured']}
 store='chicago/prairie_1904_v1/research/images/STORE.json';old=json.loads((R/store).read_text());new=json.loads(docs[store]);names=plan['source_rebind_proof']['STORE']['own_names']
 assert [(k,v)for k,v in old['files'].items()if k not in names]==[(k,v)for k,v in new['files'].items()if k not in names]
 assert {k:v for k,v in old.items()if k not in ['files','bytes']}=={k:v for k,v in new.items()if k not in ['files','bytes']}
 liberty='chicago/4d/docs/LIBERTIES.md';assert docs[liberty].startswith((R/liberty).read_bytes())
 sys.path.insert(0,str(A/'generators'));import mesh_inputs
 assert mesh_inputs.structure_inputs_sha(record,record['phases'][0])==RECIPE
 assert json.dumps(mesh_inputs.structure_inputs_doc(record,record['phases'][0]),sort_keys=True)==json.dumps(plan['native_recipe_doc'],sort_keys=True)
 native=json.loads((receipt.parent/'closed-authority/NATIVE-ENTRIES.json').read_text())
 for registry,key,expected in [('manifest.json','assets',native['master']),('manifest.web.json','masters',native['web_master_sha256'])]:
  old=json.loads((A/'assets'/registry).read_text());new=json.loads(docs['chicago/4d/assets/'+registry]);assert new[key][NAME]==expected
  assert list(old[key])==list(new[key]);assert {n:v for n,v in old[key].items()if n!=NAME}=={n:v for n,v in new[key].items()if n!=NAME};assert {n:v for n,v in old.items()if n!=key}=={n:v for n,v in new.items()if n!=key}
 camrel=f'chicago/4d/data/reference_views/{SID}/shore-drawing.json';match=json.loads(docs[f'chicago/4d/data/reference_views/{SID}/shore-drawing.match.json']);cam=json.loads(docs[camrel]);photo=((R/camrel).parent/cam['photo']).resolve()
 assert match['verdict']=='matches' and len(match['differences'])==7 and not any(x['status']=='open'for x in match['differences'])
 assert match['camera_sha256']==SHA(docs[camrel])==plan['camera']['sha256'];assert match['glb_sha256']==SHA(docs[f'chicago/4d/assets/gltf/{NAME}'])=='fb141fef3f348b494ffbf1bc2479427d0cec499001605cdcb34ce52c93c0787a';assert match['photo_sha256']==PF(photo)==plan['original_photo']['sha256']
 assert SHA(docs[f'chicago/4d/assets/web/{NAME}'])=='f120aa9abc970bb5b0b28f82c5fd176b268ba67923cea9b31de9967c8c9bf804'
 src=A/'data/sources/eliza_chappel_school_shore_view.json';assert PF(src)==plan['source_catalogue']['sha256'];assert cam['diagnostic_only'] is True
 assert state()==before
 result={'status':'READ_ONLY_TWELVE_SOURCE_NATIVE_ARTIFACT_IMAGE_ROWS_CURRENT_GUARDS_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'apply_requested':args.apply,'head':before['head'],'paths':12,'native_recipe_sha256':RECIPE,'all_foreign_registry_rows_and_order_exact':True,'foreign_grade_STORE_and_Liberty_bytes_exact':True,'fresh_camera_GLb_photo_match_bindings_exact':True,'source_credit_and_rights_limits_exact':True,'original_ticket_DONE':False}
 if args.apply:
  assert os.environ.get('SCHOOL_ADOPTION_LEASE')=='original-T2372-claimed-primary-released'
  assert before['branch'].startswith('steward/t2372-')
  assert not (R/'.git/MERGE_HEAD').exists(),'Primary merge must finish before separate school adoption'
  assert not git('status','--porcelain=v1','--untracked-files=all'),'Requires clean current school branch and native original claim/sole-writer lease'
  needed=sum(((len(raw)+4095)//4096)*4096 for _,raw,_,_ in prepared);assert shutil.disk_usage('/workspace').free>=536870912+needed+4*1024**2;assert shutil.disk_usage('/tmp').free>=1800000000
  assert state()==before
  for dest,_,_,row in prepared:assert bound(dest)==row['before']
  journal=P/('APPLIED-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')+'.jsonl')
  with journal.open('x')as log:
   def entry(row):log.write(json.dumps(row)+'\n');log.flush();os.fsync(log.fileno())
   entry({'status':'STARTED_TWELVE_PATH_ADOPTION','head':before['head'],'plan_sha256':PF(args.plan)})
   for dest,raw,mode,row in prepared:
    dest.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix='.school-adopting-',dir=dest.parent)
    try:
     with os.fdopen(fd,'wb')as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
     os.chmod(tmp,mode);os.replace(tmp,dest)
    finally:
     if os.path.exists(tmp):os.unlink(tmp)
    assert bound(dest)==row['after'];entry({'path':row['path'],'sha256':row['after']['sha256']})
   assert state()==before;assert shutil.disk_usage('/workspace').free>=536870912;assert shutil.disk_usage('/tmp').free>=1800000000
   entry({'status':'TWELVE_SOURCE_NATIVE_ARTIFACT_IMAGE_PATHS_APPLIED_GIT_METADATA_EXACT_OWNERS_AND_APP_PENDING'})
  result['status']='TWELVE_SOURCE_NATIVE_ARTIFACT_IMAGE_PATHS_APPLIED_OWNERS_AND_APP_PENDING';result['journal']=str(journal)
 if args.report:
  assert not args.report.exists();args.report.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
