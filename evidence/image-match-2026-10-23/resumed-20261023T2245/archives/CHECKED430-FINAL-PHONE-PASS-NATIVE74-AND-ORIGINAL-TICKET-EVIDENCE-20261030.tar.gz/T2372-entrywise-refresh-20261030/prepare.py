"""Prepare exactly12 School postimages entrywise; NEVER mutate primary or run owners.

Future squash/fold is unknown. Re-run into a fresh --output after it lands.
"""
import argparse, copy, datetime, hashlib, json, os, pathlib, stat, subprocess, sys
sys.dont_write_bytecode=True
os.sched_setaffinity(0,{2})
P=pathlib.Path(__file__).resolve().parent
R=pathlib.Path('/workspace/chicago'); A=R/'chicago/4d'
OLD=pathlib.Path('/workspace/T2372-reprepared-BE501-school-agent-v3-20261029/bundle-v2')
CANON=pathlib.Path('/workspace/T2372-canonical-registration-prep-20261030')
NATIVE=pathlib.Path('/workspace/T2372-native-selected-bake-reuse-20261030')
SID='chappel_infant_school'; NAME=SID+'__log_1833.glb'
SHA=lambda b:hashlib.sha256(b).hexdigest()
PF=lambda p:SHA(pathlib.Path(p).read_bytes())
ENC=lambda d,indent=2:(json.dumps(d,indent=indent,ensure_ascii=False)+'\n').encode()
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def state():
 g=lambda *a:subprocess.check_output(['git','-C',str(R),*a],env=E)
 return {'head':g('rev-parse','HEAD').decode().strip(),'branch':g('branch','--show-current').decode().strip(),
         'index':PF(R/'.git/index'),'config':PF(R/'.git/config'),'refs':SHA(g('show-ref')),
         'tracked_status':SHA(g('status','--porcelain=v1','-uno')),
         'active_merge':(R/'.git/MERGE_HEAD').exists()}
def bound(p):
 p=pathlib.Path(p)
 if not p.exists():return None
 assert p.is_file() and not p.is_symlink(),p
 return {'bytes':p.stat().st_size,'sha256':PF(p),'mode':oct(stat.S_IMODE(p.stat().st_mode))}
def key(r):return r.get('scene'),r.get('structure'),r.get('picture')
def get(d,path):
 for k in path:
  if isinstance(d,dict) and k not in d:return {'__expected_absent__':True}
  d=d[k]
 return d
def put(d,path,value):
 for k in path[:-1]:d=d[k]
 d[path[-1]]=copy.deepcopy(value)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=pathlib.Path,required=True);ap.add_argument('--expected-head',required=True);args=ap.parse_args()
 out=args.output.resolve();assert out.is_relative_to(P) and not out.exists()
 before=state();assert before['head']==args.expected_head
 template=json.loads((CANON/'ADOPTION-PLAN.json').read_text());assert template['total_paths']==12
 native=json.loads((NATIVE/'closed-authority/NATIVE-ENTRIES.json').read_text())
 oldplan=json.loads((OLD/'PLAN.json').read_text());edits=copy.deepcopy(oldplan['leaf_changes']);assert len(edits)==20
 reviewed=json.loads((NATIVE/'closed-authority/candidate'/f'{SID}.json').read_text())
 # The actual accepted native donor adds its already-reviewed dated trial
 # supersession to the research-note leaf after the old20-leaf plan was printed.
 note_edit=next(e for e in edits if e['path']==['research_note'])
 assert reviewed['research_note'].startswith(note_edit['new'])
 accepted_note_suffix=reviewed['research_note'][len(note_edit['new']):]
 assert accepted_note_suffix.startswith(' T-2372 external trial actually rendered')
 note_edit['new']=reviewed['research_note']
 rows=[];blobs={};proof={};guards={}
 def guard(p):
  p=pathlib.Path(p);guards[str(p)]=bound(p);assert guards[str(p)]
 def add(rel,raw,action,donor=None,fragment=False):
  prior=bound(R/rel);mode=prior['mode'] if prior else '0o644'
  row={'path':rel,'before':prior,'after':{'bytes':len(raw),'sha256':SHA(raw),'mode':mode},'action':action}
  if donor:row['accepted_donor']=str(donor);guard(donor)
  if fragment:row['fragment_kind']='append_only'
  blobs[rel]=raw;rows.append(row)
 for f in [CANON/'CLOSED-MANIFEST.json',CANON/'ADOPTION-PLAN.json',CANON/'CAPTURE-RESULT.json',
           CANON/'NATIVE-IMAGE-GATE.log',NATIVE/'CLOSED-MANIFEST.json',NATIVE/'closed-authority/NATIVE-ENTRIES.json',
           OLD/'PLAN.json']:guard(f)

 # Apply ONLY the accepted20 leaf edits to current School; retain unrelated leaves.
 rel=f'chicago/4d/data/structures/{SID}.json';current=json.loads((R/rel).read_text());merged=copy.deepcopy(current)
 for edit in edits:
  value=get(merged,edit['path']);assert value==edit['old'] or value==edit['new'],('School third-value conflict',edit['path'])
  put(merged,edit['path'],edit['new'])
 assert all(get(merged,e['path'])==e['new'] for e in edits)
 assert merged==reviewed,'Current School has additional values; review before carrying original form proof forward'
 add(rel,ENC(merged),'twenty_accepted_leaf_changes_current_record',NATIVE/'closed-authority/candidate'/f'{SID}.json')
 proof['school20']={'accepted_leaves':20,'all_final_accepted_values_exact':True,'reviewed_research_note_supersession_suffix_bytes':len(accepted_note_suffix.encode()),'current_unrelated_values_preserved':True,'result_exact_closed_accepted_candidate':True}
 # Exact already accepted canonical camera, stream, match and source comparison.
 direct=[f'chicago/4d/data/reference_views/{SID}/shore-drawing.json',
         'chicago/prairie_1904_v1/research/images/stream-eliza-chappel-school-reference.json']
 for rel in direct:
  donor=pathlib.Path(next(r for r in template['paths']if r['path']==rel)['postimage']);raw=donor.read_bytes()
  assert not (R/rel).exists() or (R/rel).read_bytes()==raw,('Existing own path differs',rel)
  add(rel,raw,'exact_closed_authored_camera_or_credited_stream',donor)

 # Grade ruling and STORE merge only their own entries; all current foreign order/metadata retained.
 rel='chicago/4d/data/structure_grades.json';current=json.loads((R/rel).read_text());ownall=json.loads((OLD/'postimages'/rel).read_text())
 own=[r for r in ownall['not_pictured']if r.get('structure')==SID];assert len(own)==1;target=key(own[0]);assert not [r for r in current['pictured']if key(r)==target]
 existing=[r for r in current['not_pictured']if key(r)==target];assert not existing or existing==own
 merged=copy.deepcopy(current)
 if not existing:merged['not_pictured'].append(copy.deepcopy(own[0]))
 assert current['pictured']==merged['pictured']
 assert [r for r in current['not_pictured']if key(r)!=target]==[r for r in merged['not_pictured']if key(r)!=target]
 assert {k:v for k,v in current.items()if k not in ['pictured','not_pictured']}=={k:v for k,v in merged.items()if k not in ['pictured','not_pictured']}
 add(rel,ENC(merged),'entrywise_school_nonidentification_ruling');proof['grades']={'target_key':target,'foreign_lists_order_metadata_exact':True,'before_not_pictured':len(current['not_pictured']),'after_not_pictured':len(merged['not_pictured'])}
 rel='chicago/prairie_1904_v1/research/images/STORE.json';current=json.loads((R/rel).read_text());donor=json.loads((OLD/'postimages'/rel).read_text());merged=copy.deepcopy(current)
 names=['early-eliza-chappel-school-shore-reference.jpg','early-eliza-chappel-school-shore-reference-thumb.jpg']
 for name in names:
  own=donor['files'][name];assert name not in merged['files'] or merged['files'][name]==own;merged['files'][name]=copy.deepcopy(own)
 assert [(k,v)for k,v in current['files'].items()if k not in names]==[(k,v)for k,v in merged['files'].items()if k not in names]
 assert {k:v for k,v in current.items()if k not in ['files','bytes']}=={k:v for k,v in merged.items()if k not in ['files','bytes']}
 merged['bytes']=sum(v['bytes']for v in merged['files'].values())
 add(rel,ENC(merged,1),'entrywise_two_hosted_credited_images');proof['STORE']={'before_rows':len(current['files']),'after_rows':len(merged['files']),'own_names':names,'foreign_rows_order_metadata_exact_except_total_bytes':True}

 # Keep exact old fragment, then explicitly supersede its historical native-pending prose.
 rel='chicago/4d/docs/LIBERTIES.md';current=(R/rel).read_bytes();fragment=pathlib.Path('/workspace/T2372-currentGT-guarded-source-prep-20261030/current-packet/fragments/LIBERTY-APPEND.md').read_bytes()
 assert SHA(fragment)=='34155a9c37fc4537021905beb0ae9a82e1148c04d862bdc2ad0ec845dd9f8a29'
 assert b'### L-T2372-narrow-school-front 'not in current
 qualification=(P/'NATIVE-QUALIFICATION-APPEND.md').read_bytes();guard(P/'NATIVE-QUALIFICATION-APPEND.md')
 suffix=fragment+qualification;add(rel,current+suffix,'append_current_bytes_plus_exact_reviewed_fragment_and_native_supersession',fragment=True)
 proof['Liberty']={'all_current_bytes_preserved':True,'old_exact_fragment_sha256':SHA(fragment),'qualification_sha256':SHA(qualification),'suffix_sha256':SHA(suffix),'current_bytes':len(current),'suffix_bytes':len(suffix)}

 # Actual native owner bytes and ONE native row per registry, no new bake or typed hash.
 sys.path.insert(0,str(A/'generators'));import mesh_inputs
 candidate=json.loads(blobs[f'chicago/4d/data/structures/{SID}.json']);doc=mesh_inputs.structure_inputs_doc(candidate,candidate['phases'][0]);recipe=mesh_inputs.structure_inputs_sha(candidate,candidate['phases'][0])
 assert recipe==template['recipe_sha256']==native['recipe_sha256']
 assert json.dumps(doc,sort_keys=True)==json.dumps(native['recipe_doc'],sort_keys=True)
 for category,kind in [('gltf','native-master'),('web','native-web')]:
  donor=NATIVE/'closed-authority'/kind/NAME;add(f'chicago/4d/assets/{category}/{NAME}',donor.read_bytes(),'exact_actual_native_selected_owner_bytes',donor)
 registry_proofs={}
 for registry,k,value in [('manifest.json','assets',native['master']),('manifest.web.json','masters',native['web_master_sha256'])]:
  rel='chicago/4d/assets/'+registry;current=json.loads((R/rel).read_text());merged=copy.deepcopy(current);assert NAME in current[k];merged[k][NAME]=copy.deepcopy(value)
  assert list(current[k])==list(merged[k]);assert {n:v for n,v in current[k].items()if n!=NAME}=={n:v for n,v in merged[k].items()if n!=NAME}
  assert {n:v for n,v in current.items()if n!=k}=={n:v for n,v in merged.items()if n!=k}
  add(rel,ENC(merged),'entrywise_actual_native_school_row_only');registry_proofs[registry]={'target':NAME,'foreign_rows_order_metadata_exact':True,'before_rows':len(current[k]),'after_rows':len(merged[k])}
 for rel in [f'chicago/4d/data/reference_views/{SID}/shore-drawing.match.json',f'chicago/4d/docs/RESEARCH/photo-match/{SID}/shore-drawing-side-by-side.jpg']:
  donor=pathlib.Path(next(r for r in template['paths']if r['path']==rel)['postimage']);add(rel,donor.read_bytes(),'exact_fresh_native_canonical_picture_registration',donor)
 assert len(rows)==12
 # Verify complete photo/camera/master/review tuple; no camera or verdict fabricated.
 camrel=f'chicago/4d/data/reference_views/{SID}/shore-drawing.json';cam=json.loads(blobs[camrel]);match=json.loads(blobs[camrel.replace('.json','.match.json')]);photo=((R/camrel).parent/cam['photo']).resolve();guard(photo)
 assert match['verdict']=='matches'and len(match['differences'])==7 and not any(r['status']=='open'for r in match['differences'])
 assert match['camera_sha256']==SHA(blobs[camrel])==template['camera']['sha256']
 assert match['photo_sha256']==PF(photo)==template['original_photo']['sha256']
 assert match['glb_sha256']==SHA(blobs[f'chicago/4d/assets/gltf/{NAME}'])==native['web_master_sha256']
 source=A/'data/sources/eliza_chappel_school_shore_view.json';assert PF(source)==template['source_catalogue']['sha256'];guard(source)
 for module,digest in doc['code'].items():guard(A/'generators'/module);assert PF(A/'generators'/module)==digest
 guard(A/'generators/archetypes/log_dwelling_params.py');guard(A/'generators/blender.pin')
 for module in template['native_modules']+template['reused_closed_static']:
  path=pathlib.Path(module['source']);assert PF(path)==module['sha256'];guard(path)
 # Explicit protection for the newly merged women jaunt and every source it cites.
 jaunt=A/'data/jaunts/prairie-notable-women.json';guard(jaunt);text=jaunt.read_text()
 protected=[]
 for path in (A/'data/sources').glob('*.json'):
  if '"'+path.stem+'"'in text:guard(path);protected.append(str(path.relative_to(R)))
 proof['women_jaunt_and_sources']={'jaunt':str(jaunt.relative_to(R)),'explicit_source_files':protected,'all_guarded_unchanged':True,'none_are_adoption_targets':True}
 assert state()==before
 for row in rows:assert bound(R/row['path'])==row['before']
 out.mkdir()
 for row in rows:
  rel=row['path'];raw=blobs[rel]
  if row.pop('fragment_kind',None):
   dest=out/'fragments/LIBERTY-APPEND.md';raw=suffix;row['fragment']=str(dest);row['fragment_sha256']=SHA(raw)
  else:dest=out/'postimages'/rel;row['postimage']=str(dest)
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);dest.chmod(int(row['after']['mode'],8))
 template.update(status='CURRENT_ENTRYWISE_TWELVE_SCHOOL_PATHS_PREPARED_NOT_APPLIED',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),primary_before_after=before,paths=rows,registry_proofs=registry_proofs,source_rebind_proof=proof,current_guarded_dependencies=guards,native_recipe_doc=doc,recipe_sha256=recipe)
 template['pending']=['Reprepare/revalidate after ACTUAL1456devsquash+fold; futureSHAunknown','Separate clean claimed schoolbranch/solewriter adoption','Native scene/grade/picture/library/Liberty/ground owners plus EXPLICITgenerate_alley_lanes.py then--check','PublishedBOTHmaterials/Images/Liberties/ground/street-doorapproach','Policygate/smokes/phone/PR/currentCI/devmerge/officialsettle']
 (out/'ADOPTION-PLAN.json').write_bytes(ENC(template));(out/'CURRENT-CANDIDATE-RECIPE-DOC.json').write_bytes(ENC(doc))
 print(json.dumps({'status':template['status'],'paths':12,'source_authored':6,'native_artifact_and_registry':4,'fresh_review_artifacts':2,'recipe':recipe,'no_new_bake_or_capture':True,'current_readonly_head':before['head'],'future_dev_squash_fold':'UNKNOWN; reprepare/revalidate required','output':str(out/'ADOPTION-PLAN.json')},indent=2))
if __name__=='__main__':main()
