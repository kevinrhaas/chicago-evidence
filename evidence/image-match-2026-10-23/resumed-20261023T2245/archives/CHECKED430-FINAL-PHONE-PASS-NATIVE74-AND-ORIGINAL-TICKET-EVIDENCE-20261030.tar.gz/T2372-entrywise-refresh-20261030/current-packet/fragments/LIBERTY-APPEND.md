
### L-T2372-narrow-school-front — a reconstructed reading of an unidentified school drawing

The owner approved attributed project reference use of the undated drawing reproduced
in the Digital Research Library of Illinois History Journal's 2018 Eliza Chappell article
(`eliza_chappel_school_shore_view`). Its original artist, publication, holding institution,
building identity and depicted date remain unresolved. We use the visible log gable front
as a declared design reference, without identifying it as the school or the Sauganash annex,
without placing the pictured people in July 1835, and without promoting its legal rights.

The old 7.315 × 5.486 m model was much broader than the pictured face at the doorway's
scale. The proposed front is 4.572 m (15 ft), with 8.778 m hidden depth to retain roughly
the previous 40.13 m² two-room school/lodging area. The depth is not drawn. The existing
250 mm overhang and a reconstructed 41° pitch put the ridge 2.2045 m above the unchanged
2.50 m eave. The existing 1.20 m wide recess becomes 2.30 m tall; the existing 0.85 m
lights hang from its 2.32 m common head. Their stations along the front are 0.95, 2.47
and 3.73 m, window–door–window. These are modelling choices, not measured dimensions.

An arithmetic origin compensation of (+1.1875, −3.292) m in the footprint frame keeps the
former doorway's world centre and east-facing front-wall line fixed; it supplies no new
survey precision. Hidden rear fabric, the partition, flue section and location remain
reconstructed. The proposed diagnostic local camera fits the facade composition only.
It cannot invert the inconsistent whole shore drawing to a historic station, and is not
offered as “From this spot.” The unresolved subject is explicitly ruled out of the native
whole-structure appearance grade, preserving `inferred` while the design itself is tested.

Status: **external native form reviewed; canonical adoption qualification pending**. The frozen external before/after actual native captures completed2026-10-29 18:18UTC, with both controllers/stages exit0 and allchildrenreaped. Direct review accepts the visible building form underT3153; the approximately7px/0.26m apex residual is within tolerance. Actual trial MASTERfb141fef3f348b494ffbf1bc2479427d0cec499001605cdcb34ce52c93c0787a and WEBf120aa9abc970bb5b0b28f82c5fd176b268ba67923cea9b31de9967c8c9bf804 are retained. This does not claim current canonical production/recipe freshness, a committed accepted camera/match, grade/scene owning regeneration, exterior grounding or mobile/desktop app acceptance. Those must run on adoption before PR/closure.

Superseding native qualification, 2026-10-30: the official selected-record build
and normal WEB owner actually completed and reproduced the reviewed MASTER and
WEB bytes, under native recipe2fe83632046f2462e58524944e13e970ace9824693f5141f3769c1b726537f44.
A fresh native canonical-path picture capture completed01:01:17UTC in1.881s,
with all children reaped; direct root review accepted its seven dispositions and
the native image gate passed. Earlier “pending production/render” prose above and
dated proposal notes describe their historical checkpoints. The accepted camera,
original photo and actual owner outputs are now qualified for guarded adoption
while this recipe remains exact; no repeat bake is required on that basis.
Primary scene/grade/picture/library/ground/alley regeneration, published materials,
Images/Liberties, terrain/access and desktop/mobile application acceptance remain
pending. No building identity, historic date/dimension, public-domain status,
whole-structure grade or original-ticket completion is promoted by this update.
