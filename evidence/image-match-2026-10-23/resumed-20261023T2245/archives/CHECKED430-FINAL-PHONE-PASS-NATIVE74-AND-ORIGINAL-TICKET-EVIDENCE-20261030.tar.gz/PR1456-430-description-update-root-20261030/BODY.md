Give the Miller House its pictured low log wing beside the tall range, add Hogan’s horizontal gable courses and chimney cap, raise St Mary’s front sash, and add the credited Castelnau harbour view to the lighthouse’s Images card. Source records retain disputed dates and unresolved picture limits.

Integration repairs preserve freshly rebuilt derived files and reduce railway buffer memory through the existing compact-normal format and exact uniform confidence values. Mixed confidence buffers retain their original representation. Native geometry, confidence grades, bounds, materials and picking behavior are checked against their controls.

The current published head is [`430557a7`](https://github.com/kevinrhaas/chicago/commit/430557a76ad9c8fc70f0fbfb353765bfe8c83857), with genuine parents `4b22bc35` and dev `1af81836`.

- **1,105 source checks passed in 847.250 s**; all source/configuration guards and reapers passed. The committed PR questions and four original image gates passed.
- The final same-head complete mobile memory gate passed at **399.373 MiB / 400 MiB**, with no page errors and all children reaped.
- The native commit, tree, parents and all **74 changed paths** were independently verified through immutable GitHub readback.

Dated desktop/mobile app evidence is reused with explicit consumer qualifications: inactive 1835 street-tree, railway and front-yard paths, the active elm crop/atlas adjustment plus an unused tree architecture entry, and the raycast near-plane fallback/oracle correction. This does not claim a fresh complete desktop/mobile matrix or frame-rate measurement. Uniform-ground confidence visual comparison covers AIR and SOUTH in nine modes with zero candidate/control pixel differences; NORTH was not run. Raw visual timeouts and inherited triangle/draw-budget failures remain disclosed in the evidence.

**Not merge-ready yet:** concurrent dev updates advanced the base to `4f941411` and created new conflicts. This published head has passed its complete source gate, native PR questions, four image gates and final phone check. The next integration still needs its own checks and GitHub’s required check before a normal merge. The four tickets remain in review until the qualified PR merges to `dev` and the official workflow settles them. No main/production promotion is included.

[Recovery index](https://github.com/kevinrhaas/chicago-evidence/blob/main/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md) preserves the supporting source work, qualified comparisons and earlier negative receipts. The current full-run receipts are being added to checkpoint 723.
