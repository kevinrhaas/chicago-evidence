"""ONE data-only Beaubien massing candidate. No mesh, render, fixture or primary write."""
import copy,dataclasses,difflib,hashlib,json,math,os,pathlib,subprocess,sys
os.sched_setaffinity(0,{2});sys.dont_write_bytecode=True
P=pathlib.Path(__file__).parent;A=pathlib.Path('/workspace/chicago/chicago/4d');R=A.parents[1]
SID='jb_beaubien_homestead';SRC='kinzie_1857_chicago_1831_panorama'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
enc=lambda d:json.dumps(d,indent=2,ensure_ascii=False)+'\n'
def emit(name,d):(P/name).write_text(enc(d))
record_path=A/'data/structures'/f'{SID}.json';original=json.loads(record_path.read_text());candidate=copy.deepcopy(original);form=candidate['phases'][0]['form']
guards=[record_path,A/'generators/archetypes/log_dwelling.py',A/'generators/archetypes/log_dwelling_params.py',
 A/'generators/mesh_inputs.py',A/'generators/blender.pin',A/'data/structures.schema.json',
 A/'data/sources'/f'{SRC}.json',A/'data/sources/wentworth_1881_fort_dearborn.json',
 A/'assets/gltf'/f'{SID}__log_1822.glb',A/'assets/web'/f'{SID}__log_1822.glb',
 pathlib.Path('/workspace/T2378-native-role-candidate-exec-20261030/RESULT.json'),
 pathlib.Path('/workspace/T2378-role-inspection-root-20261030/source-inspection-only.png'),
 pathlib.Path('/workspace/T2378-role-inspection-root-20261030/candidate-inspection-only.png'),
 pathlib.Path('/workspace/T2378-native-role-candidate-exec-20261030/runtime/data/reference_views/jb_beaubien_homestead/keyed-1831-role-candidate.json'),
 pathlib.Path('/workspace/T2378-orientation-review-20261030/CLOSED-MANIFEST.json'),
 pathlib.Path('/workspace/T2378-candidate-controller-20261030/CLOSED-MANIFEST.json')]
before={str(p):sha(p)for p in guards}
assert sha(A/'assets/gltf'/f'{SID}__log_1822.glb')=='69cb6bfcc2e71aaaa48a424f11e9231294335b178df7b22611aae500162156b1'
def revise(key,value,confidence,note):
 row=form[key];row['value']=value;row['confidence']=confidence;row['note']+='\n\nT-2378 ONE EXTERNAL MAIN-MASS PROTOTYPE, NOT ADOPTED: '+note
 row.setdefault('sources',[])
 if SRC not in row['sources']:row['sources'].append(SRC)
revise('stories',2,'inferred',
 'The keyed main block reads markedly taller than the one-storey proxy after the accepted diagnostic gable-right/longwall-left role test. Two storeys is the bounded visual interpretation used for this trial, not a measured floor count or printed description. This is based on the conditional Beaubien image identification, NOT Hubbard\'s two-storey Factor House140m away. T-0894\'s separation of that building remains valid. Native upper opening bands follow this two-storey parameter and remain reconstructed defaults, not newly attested bay/window counts.')
revise('wall_height_m',5.0,'reconstructed',
 'Choose5.0m, twice the previous2.5m one-storey wall, as ONE graphic-match main-block height with the existing reconstructed12.192x6.096m footprint and accepted diagnostic camera held fixed. This number is a model dimension, not a recovered historic measurement. Two plausible2.5m levels bound the choice. No identity, historic bearing, interior floor plan or July1835 form attestation follows.')
revise('roof_pitch_deg',50.0,'reconstructed',
 'Choose50degrees once to represent the conspicuously steep pictured gable over the now-taller main block. The source does not measure a roof angle. Existing250mm overhangs are retained, and the footprint/camera are unchanged controls. This is a picture-relative reconstruction, not evidence of a historic metric pitch; the previous35degree typological default is not privileged against the visible source.')
revise('chimneys',2,'inferred',
 'The main roof in the keyed image visibly carries two distinct stacks. Use count2 under the inferred pictured-subject identification, with their through-ridge disposition given separately. Do not count the narrow neighbouring low roof\'s separate pipe as a third main stack. The illustration is retrospective and does not independently attest unchanged count or fabric on1July1835.')
assert 'chimney_ridge_at'not in form
form['chimney_ridge_at']={'value':[0.16,0.84],'confidence':'reconstructed','sources':[SRC],
 'note':'T-2378 ONE EXTERNAL MAIN-MASS PROTOTYPE: both pictured main stacks rise through the roof near its two ridge ends, unlike the current exterior gable stack. Choose fractions0.16/0.84 along the unchanged native u-axis ridge as one approximate inset pair. Exact stations, shaft0.96m/default head0.95m, section/material and unseen flues are reconstructed; the picture supplies neither metric dimensions nor a heating plan. No frame addition or low projection is introduced by this control.'}
assert candidate['phases'][0]['position']==original['phases'][0]['position']
assert candidate['phases'][0]['footprint']==original['phases'][0]['footprint']
assert candidate['phases'][0]['documented_range']==original['phases'][0]['documented_range']
assert {k:v for k,v in form.items()if k not in ['stories','wall_height_m','roof_pitch_deg','chimneys','chimney_ridge_at']}=={k:v for k,v in original['phases'][0]['form'].items()if k not in ['stories','wall_height_m','roof_pitch_deg','chimneys','chimney_ridge_at']}
assert {k:v for k,v in candidate.items()if k!='phases'}=={k:v for k,v in original.items()if k!='phases'}
sys.path.insert(0,str(A/'generators'));import mesh_inputs
from archetypes.log_dwelling_params import core_extent,resolved_core_ridge_axis,front_openings
oldparams=mesh_inputs.resolve_params('log_dwelling',original['phases'][0],original)
params=mesh_inputs.resolve_params('log_dwelling',candidate['phases'][0],candidate);params.validate()
doc=mesh_inputs.structure_inputs_doc(candidate,candidate['phases'][0]);recipe=mesh_inputs.structure_inputs_sha(candidate,candidate['phases'][0])
import jsonschema
jsonschema.Draft202012Validator(json.loads((A/'data/structures.schema.json').read_text())).validate(candidate)
assert core_extent(params)==core_extent(oldparams)==(0.,0.,12.192,6.096)
assert resolved_core_ridge_axis(params)=='x' and not params.frame_addition and not params.lean_to
assert params.chimney_ridge_at==(0.16,0.84) and params.chimneys==2
for f,digest in doc['code'].items():assert sha(A/'generators'/f)==digest
path=P/'candidate/data/structures'/f'{SID}.json';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(enc(candidate))
camera=guards[13];(P/'CONTROL-CAMERA.json').write_bytes(camera.read_bytes())
assert sha(P/'CONTROL-CAMERA.json')==sha(camera)=='c914ab0a92c25ec883121a23b81441406935f46415687218725d3e0fcca9f134'
diff=[]
def leaves(a,b,p=()):
 if isinstance(a,dict)and isinstance(b,dict):
  for k in sorted(set(a)|set(b)):
   if k not in a:diff.append({'path':list(p+(k,)),'old_absent':True,'new':b[k]})
   elif k not in b:raise AssertionError('Unexpected removed field')
   else:leaves(a[k],b[k],p+(k,))
 elif a!=b:diff.append({'path':list(p),'old':a,'new':b})
leaves(original,candidate)
emit('FIELD-DIFF.json',{'owned_form_attributes':['stories','wall_height_m','roof_pitch_deg','chimneys','chimney_ridge_at'],'changes':diff,'fixed_footprint_position_scene_dates_flags_occupants_other_form':True})
(P/'CANDIDATE.diff').write_text(''.join(difflib.unified_diff(record_path.read_text().splitlines(True),enc(candidate).splitlines(True),fromfile='current/jb_beaubien_homestead.json',tofile='one-prototype/jb_beaubien_homestead.json')))
emit('NATIVE-RECIPE.json',doc)
ridge=5.+((6.096+.5)/2)*math.tan(math.radians(50.))
emit('PARAM-VALIDATION.json',{'native_from_phase_and_validate':'PASS','structure_JSON_schema':'PASS','source_ids_resolve':all((A/'data/sources'/f'{s}.json').exists()for key in ['stories','wall_height_m','roof_pitch_deg','chimneys','chimney_ridge_at']for s in form[key]['sources']),
 'native_recipe_sha256':recipe,'resolved_params':dataclasses.asdict(params),'core_extent_m':core_extent(params),'ridge_axis':'x',
 'arithmetic_height_estimate_NOT_A_MESH':{'eave_m':5.,'ridge_with_unchanged_overhang_m':ridge,'ridge_stack_head_m':ridge+.95},
 'native_two_storey_opening_bands_default_NOT_SOURCE_ATTESTATION':front_openings(params),
 'no_new_shared_code':True,'native_build_or_WEB_run':False,'native_candidate_photo_run':False})
assert before=={str(p):sha(p)for p in guards}
emit('BINDINGS.json',{'guarded_paths':before,'current_readonly_HEAD':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'all_guarded_paths_exact_after':True,
 'candidate_record':{'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)},'candidate_native_inputs_sha256':recipe,'camera_sha256':sha(camera),
 'source_photo_sha256':'624d8f1f52a75bf30653e8cbf37a388478b0ddf5a02f1fadf727cf2144b84c3f','candidate_count':1,'no_primary_Git_site_ticket_writes':True,'no_fixture_Blender_browser_native_bake_or_match_run':True})
print('PASS ONE data-only main-massing candidate; native params/schema/recipe verified; build/render UNRUN; inputs '+recipe)
