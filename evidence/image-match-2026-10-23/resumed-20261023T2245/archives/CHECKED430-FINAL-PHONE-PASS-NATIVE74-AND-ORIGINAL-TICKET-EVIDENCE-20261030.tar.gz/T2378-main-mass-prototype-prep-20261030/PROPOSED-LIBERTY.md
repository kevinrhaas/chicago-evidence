
### L-beaubien-tall-main-block-2378 — a picture-relative main mass, with the lower projection still unresolved

The keyed1831 panorama (`kinzie_1857_chicago_1831_panorama`) shows a tall main block
with a steep gable and two main-roof stacks, plus a lower roofed projection. The
published Wentworth1881 p86 annotation associates Beaubien's house with the same
retrospective northeast-corner locator as this record, permitting an inferred
working identity, not a surveyed site or a known building lineage. Printed1857
Wau-Bun credit, depicted1831 and verified1881 reproduction remain distinct.
Hubbard's1881 criticism of the cut's fort/geography and the unknown survival of
visible1831 fabric to1July1835 remain. The separate U.S. Factor's House supplies
no two-storey description to this trial.

ONE offbranch prototype interprets the main mass as two storeys, with a5.0m total
wall and50° roof. The two-storey interpretation is inferred from the tall pictured
block; the exact height/pitch are reconstructed graphic-match choices, bounded by
two2.5m levels, the existing reconstructed12.192×6.096m footprint, and the accepted
diagnostic gable-right/longwall-left camera held fixed. They are not historical
metric measurements or a recovered floor plan. Existing250mm overhangs remain.

Two main stacks are visually readable; their ridge positions at fractions0.16
and0.84 are reconstructed inset stations. The producer's existing0.96m shafts,
0.95m heads, section/material and hidden flues remain reconstructed defaults. No
white paint, particular cladding, opening count or original material is attested
from this monochrome image. Existing log finish/material choices are unchanged.
Two-storey native opening bands are a documented side effect of the existing
producer's storey parameter, not newly read upper-window evidence.

The low projection remains a visible OPEN gap in this original ticket. The
existing centered front-frame option subtracts its depth from the main core and
asserts a material/room split; the lean-to option places a gabled appendage against
a fixed main gable and outside the retained footprint. Neither states this
source's offset lower front roof without further attachment/layout choices. This
main-mass trial therefore does not silently stand one in, remove the pictured
projection or claim that the old unbroken box matches it. Its actual connection,
extent, roof form and possible overlap with a neighbouring building remain to be
resolved within T2378; no new ticket or split is created.

Status: **data-only prototype prepared; native build/WEB/source comparison UNRUN**.
No source identity or structure grade is promoted, no matches verdict is assigned,
and no actual mesh/app/ground/access qualification or original-ticket closure is
claimed. A later scheduled native comparison must use this ONE candidate with
the fixed footprint/camera before judging it; a pixel-perfect fit is not promised.
