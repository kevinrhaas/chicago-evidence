# One finite Beaubien main-massing prototype, not rendered

The accepted role test now correctly exposes the visible gable on the right and
longwall on the left. I directly viewed the original whole source and the root's
inspection crops. The source's tall main block, steep gable and two through-roof
main stacks differ visibly from the current low one-storey box with its exterior
gable stack. Those visible differences justify changing the old typological
guesses in ONE data-only prototype despite absent absolute dimensions.

Candidate form: stories2, wall5.0m, pitch50°, chimneys2, through-ridge fractions
0.16/0.84. Story/count readings remain inferred under the conditional image
identity; exact metric height/pitch/stack stations are reconstructed choices.
The footprint12.192×6.096m, placement/bearing, scene dates, function/occupants,
review/removal flags, existing construction/material and the accepted camera are
unchanged controls. The inherited footprint's historical factory rationale is
not revived as evidence. No Factor's House description or white-paint claim is
used. This proposes no structural grade change or identity adoption.

`candidate/data/structures/jb_beaubien_homestead.json` is the sole candidate.
`FIELD-DIFF.json` and `CANDIDATE.diff` show every change. `NATIVE-RECIPE.json` and
`PARAM-VALIDATION.json` contain actual lightweight native from_phase/validate and
JSON-schema results, not a typed registry entry. The one changed input recipe
requires ONE later native selected build and normal WEB derivative; no shared
producer edit or family bake is proposed. No fixture, Blender, browser, build,
derivative, comparison, application or primary write ran here.

`CONTROL-CAMERA.json` is byte-exact to the actual accepted role-test camera
`c914ab0a…`. Preserve every numeric field and the whole original1920×1042 source;
its relative photo path belongs in the same guarded canonical fixture layout.
Do not renormalize the camera or footprint after changing the candidate, so the
later comparison tests form rather than another pose. No grid or second candidate
was generated. Current-producer opening defaults add an upper band for stories2;
that is explicitly recorded as reconstructed, and the visible opening arrangement
is still a later comparison gap rather than claimed source evidence.

The lower front projection is deliberately a recorded remaining gap. Existing
front-frame parameters divide the retained footprint and shrink the main body;
their addition is centered rather than a freely offset projection. Native
lean_to attaches at a gable outside the retained footprint and also asserts a
gable roof/door. Turning either on would introduce a different attachment/layout
and change this trial's fixed main-body control. No such layout is smuggled into
the main-mass test. The same original ticket may address the projection after
direct review; no new follow-up ticket is proposed.

After a separate root CPU/resource/source grant, prepare only the selected native
builder's minimal offbranch fixture and run official ownership for this single
candidate, then one photo_match comparison under the frozen camera. Root is
scheduling the Jail trial and integration first; this packet grants no launch.
Review massing/stacks, opening side effects and lower projection honestly. No
matches, whole-structure attestation, app ground/material/Images/access proof,
PR or original-ticket completion follows from this preparation. All prior closed
packets remain untouched. Bank this small packet with the next substantive
checkpoint rather than opening a standalone archive.
