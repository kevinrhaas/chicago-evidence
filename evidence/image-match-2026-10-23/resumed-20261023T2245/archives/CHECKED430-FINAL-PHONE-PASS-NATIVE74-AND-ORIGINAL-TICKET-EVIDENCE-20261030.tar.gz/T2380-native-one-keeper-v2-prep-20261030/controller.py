"""UNRUN bounded official selected-owner controller. No primary or Git writes.

Keeper/capture FIRST; default controls require a later root-reviewed invocation.
All mutable outputs are ordinary files below run/fixture; no selected symlink writes.
"""
from __future__ import annotations
import argparse,ast,copy,datetime,hashlib,importlib.util,json,os,pathlib,re,shutil,signal,stat,subprocess,sys,time
sys.dont_write_bytecode=True
P=pathlib.Path(__file__).resolve().parent;PLAN=json.loads((P/'PLAN.json').read_text());A=pathlib.Path(PLAN['primary']);I=pathlib.Path(PLAN['implementation_manifest']['source']).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
REG={'assets/manifest.json','assets/manifest.web.json','assets/manifest.versions.json'}
ROOT=A.parents[1]
GIT_ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def save(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2)+'\n')
def refuse(c,m):
 if not c:raise RuntimeError(m)
def floors(extra=0):
 refuse(shutil.disk_usage('/workspace').free>=PLAN['workspace_floor']+extra,'workspace reserve/floor')
 refuse(shutil.disk_usage('/tmp').free>=PLAN['tmp_floor'],'TMP floor')
def validate_checked_state(expected,head,has_merge,status):
 refuse(isinstance(expected,str) and re.fullmatch('[0-9a-f]{40}',expected),'explicit actual checked --expected-head required')
 refuse(head==expected,'primary checked HEAD changed')
 refuse(not has_merge,'primary MERGE_HEAD exists; no keeper fixture during integration')
 refuse(not status,'primary is not clean; no keeper fixture during source gate or adoption')
 return {'head':head,'no_merge':True,'source_clean':True}
def checked_source_guard(expected):
 head=subprocess.check_output(['git','-C',str(ROOT),'-c','gc.auto=0','-c','maintenance.auto=false','rev-parse','HEAD'],env=GIT_ENV,text=True).strip()
 status=subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain=v1'],env=GIT_ENV)
 return validate_checked_state(expected,head,(ROOT/'.git/MERGE_HEAD').exists(),status)
def bound_guard(row,label):
 p=pathlib.Path(row['source']);refuse(p.is_file() and not p.is_symlink(),label+' must remain regular')
 refuse(p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and oct(stat.S_IMODE(p.stat().st_mode))==row['mode'],label+' bytes/mode changed')
def prototype_guard():
 bound_guard(PLAN['candidate'],'keeper candidate')
 bound_guard(PLAN['prototype_camera'],'unchanged full Gale prototype camera')
 bound_guard(PLAN['original_photo'],'unchanged full Gale original photo')
 for row in PLAN['core_capture_inputs']:bound_guard(row,'unchanged jail/core/palisade/source/grade input')
 for row in PLAN['copies']:
  if row['postimage']:bound_guard(row['postimage_binding'],'closed postimage '+row['relative'])
def roster_guard():
 actual=set()
 for path in (A/'data/structures').glob('*.json'):
  doc=json.loads(path.read_text())
  if doc.get('archetype')=='frame_dwelling':
   actual.update((doc['id'],ph['id'])for ph in doc['phases'])
 expected={(row['structure_id'],row['phase_id'])for row in PLAN['family']}
 refuse(actual==expected and len(actual)==271,'frame family roster changed; reprepare before native controls')
 for path in (A/'data/structures/versions').glob('*/*.json'):
  parent=A/'data/structures'/(path.parent.name+'.json')
  if parent.exists() and json.loads(parent.read_text()).get('archetype')=='frame_dwelling':
   refuse(not json.loads(path.read_text()).get('phases'),'new frame version requires a new full-family control plan')
 planned={row['relative']for row in PLAN['master_read_links']}
 current={str(path.relative_to(A))for path in (A/'assets/gltf').rglob('*.glb')}
 refuse(current==planned,'foreign MASTER inventory changed; refresh read-only links before execution')
def baseline_guard():
 prototype_guard();roster_guard()
 for r in PLAN['copies']:
  if r['relative'] not in REG:refuse(sha(pathlib.Path(r['source']))==r['sha256'],'producer drift '+r['relative'])
 refuse(sha(pathlib.Path(PLAN['candidate']['source']))==PLAN['candidate']['sha256'],'candidate drift')
 refuse(sha(pathlib.Path(PLAN['implementation_manifest']['source']))==PLAN['implementation_manifest']['sha256'],'closed implementation drift')
 for r in PLAN['family']:
  refuse(sha(pathlib.Path(r['record']['source']))==r['record']['sha256'],'family record drift '+r['structure_id'])
  for sub,key in [('gltf','master_sha256'),('web','web_sha256')]:refuse(sha(A/'assets'/sub/r['master'])==r[key],'primary baseline asset drift '+r['master'])
 manifest=json.loads((A/'assets/manifest.json').read_text())['assets']
 for r in PLAN['family']:refuse(manifest[r['master']]['inputs_sha256']==r['native_current_recipe'],'baseline recipe drift '+r['master'])
 refuse(sha(pathlib.Path(PLAN['reaper']['source']))==PLAN['reaper']['sha256'],'reaper drift')
def preflight(require_resources=True):
 baseline_guard();
 if require_resources:floors()
 refuse(len(PLAN['family'])==271 and not PLAN['native_current_stale_rows'],'base not fresh271')
 for r in PLAN['copies']:
  if r['postimage']:ast.parse(pathlib.Path(r['postimage']).read_text())
 return {'status':'PURE_PREFLIGHT_PASS_NO_FIXTURE_NO_HEAVY' if require_resources else 'READONLY_REHEARSAL_INPUT_GUARDS_PASS_EXECUTION_NOT_REQUESTED','resource_floors_enforced_here':require_resources,'execute_still_requires_actual_head_clean_source_CPU_grant_and_floors':True,'at':now(),'pinned_native_current_recipes':271,'pinned_native_candidate_expected_recipes':271,'keeper_expected_recipe':PLAN['expected_keeper_recipe_sha256'],'all_current_MASTER_WEB_exact':True,'global_dispatch_unchanged':True}
class Run:
 def __init__(self,args):
  self.args=args;self.R=P/'run';self.F=self.R/'fixture';self.D=self.R/'receipts';self.E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',NODE_DISABLE_COMPILE_CACHE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PW_EXECUTABLE='/usr/bin/chromium')
  self.deadline=time.monotonic()+args.seconds;self.before={};self.rawregs={};self.current_reg_sha={}
 def selected(self,rel):
  p=self.F/rel;refuse(p.parent.resolve().is_relative_to(self.F.resolve()),'selected parent escapes fixture')
  if p.is_symlink():p.unlink()
  refuse(not p.exists(),'selected ordinary output already exists '+str(p));return p
 def setup(self):
  checked=checked_source_guard(self.args.expected_head);baseline_guard();floors(PLAN['future_extra_fs_envelope_bytes']);self.R.mkdir(exist_ok=True);self.D.mkdir(exist_ok=True)
  self.rawregs={x:json.loads((A/x).read_text()) for x in REG};self.current_reg_sha={x:sha(A/x) for x in REG}
  if not self.F.exists():
   for row in PLAN['copies']:
    dest=self.F/row['relative'];dest.parent.mkdir(parents=True,exist_ok=True);source=pathlib.Path(row['postimage'] or row['source']);shutil.copyfile(source,dest);dest.chmod(int(row['mode'],8))
   for x in PLAN['read_links']:
    dest=self.F/x['relative'];dest.parent.mkdir(parents=True,exist_ok=True);dest.symlink_to(x['source'],target_is_directory=pathlib.Path(x['source']).is_dir())
   for row in PLAN['master_read_links']:
    dest=self.F/row['relative'];dest.parent.mkdir(parents=True,exist_ok=True);refuse(not dest.exists(),'unexpected fixture master');dest.symlink_to(row['source'])
   for row in PLAN['family']:
    dest=self.F/'data/structures'/f"{row['structure_id']}.json";dest.parent.mkdir(parents=True,exist_ok=True);dest.symlink_to(row['record']['source'])
   dest=self.F/'data/structures/log_jail_keeper_house.json';shutil.copyfile(PLAN['candidate']['source'],dest)
   # Read-only sources are needed by native sidecar projection and full original image.
   (self.F/'data/sources').symlink_to(A/'data/sources',target_is_directory=True)
   tmp=self.R/'tmp';tmp.mkdir();(self.R/'cache').mkdir();(self.R/'config').mkdir();self.E.update(TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),XDG_CACHE_HOME=str(self.R/'cache'),XDG_CONFIG_HOME=str(self.R/'config'))
   save(self.R/'INITIAL-REGISTRIES.json',self.rawregs)
   save(self.R/'EXECUTION-START.json',{'at':now(),'checked_primary_source':checked,'source_registry_bindings':self.current_reg_sha,'all271same_pinned_source_recipes':True,'write_boundary':str(self.F),'no_primary_writes':True})
  else:
   self.E.update(TMPDIR=str(self.R/'tmp'),TMP=str(self.R/'tmp'),TEMP=str(self.R/'tmp'),XDG_CACHE_HOME=str(self.R/'cache'),XDG_CONFIG_HOME=str(self.R/'config'));refuse((self.R/'INITIAL-REGISTRIES.json').exists(),'unrecognized fixture')
   refuse(json.loads((self.R/'EXECUTION-START.json').read_text())['checked_primary_source']==checked,'checked source changed since partial fixture')
   self.rawregs=json.loads((self.R/'INITIAL-REGISTRIES.json').read_text());old=json.loads((self.R/'EXECUTION-START.json').read_text())['source_registry_bindings'];refuse(old==self.current_reg_sha,'primary registry drift since partial batch')
  for row in PLAN['copies']:
   target=self.F/row['relative']
   if row['relative'] not in REG:refuse(not target.is_symlink() and sha(target)==sha(pathlib.Path(row['postimage'] or row['source'])),'fixture code closure')
  refuse(not (self.F/'assets').is_symlink(),'assets dir must be owned');refuse(not (self.F/'assets/gltf').is_symlink(),'gltf dir must be owned');refuse(not (self.F/'assets/web').is_symlink(),'web dir must be owned')
  self.primary_guard()
 def primary_guard(self):
  checked_source_guard(self.args.expected_head);prototype_guard()
  for rel,h in self.current_reg_sha.items():refuse(sha(A/rel)==h,'primary registry changed under source lease')
  for row in PLAN['copies']:
   if row['relative'] not in REG:refuse(sha(pathlib.Path(row['source']))==row['sha256'],'primary code drift')
 def recipe_preflight(self,ids):
  # New process uses the ACTUAL unchanged native recipe module and copied postimages.
  code='''import json,sys;from pathlib import Path;sys.dont_write_bytecode=True;sys.path.insert(0,"generators");import mesh_inputs;out={};ids=json.loads(sys.argv[1]);\nfor sid in ids:\n s=json.loads(Path("data/structures",sid+".json").read_text());\n for p in s["phases"]:out[sid+":"+p["id"]]={"sha256":mesh_inputs.structure_inputs_sha(s,p),"doc":mesh_inputs.structure_inputs_doc(s,p)}\nprint(json.dumps(out,sort_keys=True))'''
  text=subprocess.check_output([sys.executable,'-c',code,json.dumps(ids)],cwd=self.F,env=self.E,text=True);docs=json.loads(text)
  for sid in ids:
   if sid=='log_jail_keeper_house':key=sid+':frame_1835';wanted=PLAN['expected_keeper_recipe_sha256']
   else:
    row=next(r for r in PLAN['family'] if r['structure_id']==sid);key=sid+':'+row['phase_id'];wanted=row['native_candidate_expected_recipe']
   refuse(docs[key]['sha256']==wanted,'native complete candidate recipe differs '+key)
  return docs
 def stage(self,d,name,argv,limit):
  floors();self.primary_guard();reap=d/(name+'-REAPER.json');log=d/(name+'.log');refuse(not reap.exists() and not log.exists(),'existing stage receipt')
  full=[sys.executable,PLAN['reaper']['source'],str(reap),'--','nice','-n','19','taskset','-c',PLAN['reaper_cpu'],*argv]
  start=time.monotonic();why=None
  with log.open('x') as stream:
   proc=subprocess.Popen(full,cwd=self.F,env=self.E,stdout=stream,stderr=subprocess.STDOUT)
   while proc.poll() is None:
    try:floors();self.primary_guard();refuse(time.monotonic()-start<limit,'stage timeout');refuse(time.monotonic()<self.deadline,'bounded invocation deadline')
    except Exception as e:why=str(e);proc.send_signal(signal.SIGTERM);break
    time.sleep(.5)
   try:proc.wait(timeout=15)
   except subprocess.TimeoutExpired:
    # Do not kill an unknown process tree. Reaper receipt retains owned identity.
    raise RuntimeError('owned reaper did not close; preserve scratch and escalate to root')
  result=json.loads(reap.read_text());row={'stage':name,'argv':full,'seconds':round(time.monotonic()-start,3),'exit':proc.returncode,'reaper_exit':result['command_exit'],'all_children_reaped':result['all_children_reaped'],'interrupted_reason':why}
  save(d/(name+'-RESULT.json'),row);print(json.dumps(row),flush=True)
  refuse(proc.returncode==0 and result['command_exit']==0 and result['all_children_reaped'] and why is None,'native stage did not PASS; preserve outputs')
  floors();self.primary_guard();return row
 def registry_guard(self,allowed,base=None):
  after={x:json.loads((self.F/x).read_text()) for x in REG};base=self.rawregs if base is None else base
  for rel,key in [('assets/manifest.json','assets'),('assets/manifest.web.json','masters')]:
   old=base[rel];new=after[rel];refuse({k:v for k,v in old[key].items() if k not in allowed}=={k:v for k,v in new[key].items() if k not in allowed},'foreign native registry rows changed '+rel)
   refuse({k:v for k,v in old.items() if k!=key}=={k:v for k,v in new.items() if k!=key},'foreign registry metadata changed '+rel)
  refuse(after['assets/manifest.versions.json']==base['assets/manifest.versions.json'],'versions changed')
  return after
 def one(self,ids,label,keeper=False):
  d=self.D/label;d.mkdir(exist_ok=False);before={x:json.loads((self.F/x).read_text()) for x in REG};docs=self.recipe_preflight(ids);save(d/'ACTUAL-NATIVE-RECIPE-PREFLIGHT.json',docs)
  names=[PLAN['keeper_output']] if keeper else [next(r['master'] for r in PLAN['family'] if r['structure_id']==sid) for sid in ids]
  for name in names:
   self.selected('assets/gltf/'+name);self.selected('assets/web/'+name)
  wrote=d/'WROTE.txt';stages=[];argv=[PLAN['blender'],'--background','--factory-startup','--threads',str(PLAN['threads']),'--python',str(self.F/'generators/build.py'),'--','--only',','.join(ids),'--wrote',str(wrote)]
  stages.append(self.stage(d,'BUILD',argv,240));refuse(wrote.read_text().splitlines()==names,'native wrote list differs')
  for name in names:refuse((self.F/'assets/gltf'/name).is_file() and not (self.F/'assets/gltf'/name).is_symlink(),'MASTER not own regular file')
  stages.append(self.stage(d,'WEB',['bash','tools/web_derivatives.sh','--only',','.join(names)],240))
  regs=self.registry_guard(set(names),before);rows=[]
  for name in names:
   master=self.F/'assets/gltf'/name;web=self.F/'assets/web'/name;refuse(master.is_file() and web.is_file() and not master.is_symlink() and not web.is_symlink(),'selected ordinary MASTER/WEB')
   sid='log_jail_keeper_house' if keeper else next(r['structure_id'] for r in PLAN['family'] if r['master']==name);expected=PLAN['expected_keeper_recipe_sha256'] if keeper else next(r['native_candidate_expected_recipe'] for r in PLAN['family'] if r['master']==name)
   refuse(regs['assets/manifest.json']['assets'][name]['inputs_sha256']==expected,'actual native registered recipe')
   refuse(regs['assets/manifest.web.json']['masters'][name]==sha(master),'official WEB MASTER binding')
   row={'name':name,'actual_master':{'sha256':sha(master),'bytes':master.stat().st_size,'mode':oct(stat.S_IMODE(master.stat().st_mode))},'actual_web':{'sha256':sha(web),'bytes':web.stat().st_size,'mode':oct(stat.S_IMODE(web.stat().st_mode))},'native_master_entry':regs['assets/manifest.json']['assets'][name],'native_web_master_binding':regs['assets/manifest.web.json']['masters'][name],'recipe':docs[sid+':'+('frame_1835' if keeper else next(r['phase_id'] for r in PLAN['family'] if r['master']==name))]}
   if not keeper:
    base=next(r for r in PLAN['family'] if r['master']==name)
    for kind,sub,key,size in [('actual_master','gltf','master_sha256','master_bytes'),('actual_web','web','web_sha256','web_bytes')]:
     refuse(row[kind]['sha256']==base[key] and row[kind]['bytes']==base[size],'DEFAULT BYTE PARITY MISMATCH '+kind+' '+name)
     refuse(master.stat().st_mode&0o777==(A/'assets/gltf'/name).stat().st_mode&0o777,'default MASTER mode')
     refuse(web.stat().st_mode&0o777==(A/'assets/web'/name).stat().st_mode&0o777,'default WEB mode')
    row['default_MASTER_WEB_byte_parity']=True
   rows.append(row)
  receipt={'status':'ACTUAL_NATIVE_KEEPER_GENERATED_UNREVIEWED' if keeper else 'ACTUAL_NATIVE_DEFAULT_MASTER_WEB_BYTE_PARITY_PASS','at':now(),'stages':stages,'assets':rows,'foreign_rows_exact':True,'primary_unchanged':True,'all_children_reaped':True}
  save(d/'CLOSED-RESULT.json',receipt)
  if not keeper:
   # The exact primary baseline remains full restore authority. Only retire
   # our regular duplicates after BOTH native outputs+recipe+reaper prove equal.
   retired=[]
   for name in names:
    for sub in ['gltf','web']:
     q=self.F/'assets'/sub/name;origin=A/'assets'/sub/name;refuse(not q.is_symlink() and q.read_bytes()==origin.read_bytes(),'last exact restore-authority byte check');retired.append({'path':str(q),'bytes':q.stat().st_size,'sha256':sha(q),'mode':oct(stat.S_IMODE(q.stat().st_mode)),'restore_authority':str(origin)});q.unlink();q.symlink_to(origin)
   save(d/'OWNED-EXACT-DUPLICATES-RETIRED.json',{'after_closed_native_BOTH_parity_only':True,'retired':retired})
  return receipt
 def capture(self):
  # Extract the real compiler's one nested sidecar builder. Its byte-identical
  # control must recreate the existing jail sidecar before projecting candidate.
  sys.path.insert(0,str(A/'tools'));sys.path.insert(0,str(A/'generators'));spec=importlib.util.spec_from_file_location('keeper_native_compile_scene',A/'tools/compile_scene.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  tree=ast.parse((A/'tools/compile_scene.py').read_text());outer=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='compile_scene');node=next(n for n in outer.body if isinstance(n,ast.FunctionDef) and n.name=='build_sidecar')
  env=dict(vars(mod));env.update(scene_id='1835',scene=json.loads((A/'data/scenes/1835.json').read_text()),datum=json.loads((A/'data/datum.json').read_text()),sources={p.stem:json.loads(p.read_text()) for p in (A/'data/sources').glob('*.json')},residents=mod.compile_residents(),lodging=mod.compile_lodging(),structure_names={p.stem:json.loads(p.read_text()).get('name',p.stem) for p in (A/'data/structures').glob('*.json')},trade_roofs_unseatable={u['structure_id']:u for u in json.loads((A/'data/reconstruction/1835_trade_roof_seats.json').read_text()).get('unseatable',[])})
  exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(A/'tools/compile_scene.py'),'exec'),env)
  core=json.loads((A/'data/structures/log_jail.json').read_text());test=env['build_sidecar'](core,core['phases'][0]);actual=json.loads((A/'data/sidecars/1835/log_jail.json').read_text());refuse(test==actual,'native sidecar compiler control differs; preserve keeper outputs')
  record=json.loads(pathlib.Path(PLAN['candidate']['source']).read_text());side=env['build_sidecar'](record,record['phases'][0]);target=self.F/'data/sidecars/1835';target.mkdir(parents=True,exist_ok=True);save(target/'log_jail_keeper_house.json',side);save(target/'log_jail.json',actual)
  # Grade is the actual current native grader result, not manually made attested.
  # New source adoption/grade owner remains pending; this is diagnostic geometry QA.
  enc=json.loads((A/'data/enclosures/log_jail_palisade.json').read_text());enc['belongs_to']=enc.get('belongs_to',[])+['log_jail_keeper_house'];save(self.F/'data/enclosures/log_jail_palisade.json',enc);shutil.copyfile(A/'data/enclosures/index.json',self.F/'data/enclosures/index.json')
  cam=json.loads(pathlib.Path(PLAN['prototype_camera']['source']).read_text());camdir=self.F/'data/reference_views/log_jail_keeper_house';camdir.mkdir(parents=True,exist_ok=True);camfile=camdir/'gale_1902.json';save(camfile,cam)
  save(self.R/'NATIVE-COMPILER-CONTROL.json',{'current_log_jail_sidecar_exact':True,'compiler_sha256':sha(A/'tools/compile_scene.py'),'candidate_sidecar_sha256':sha(target/'log_jail_keeper_house.json'),'actual_current_native_grade':side['grade'],'grade_not_manually_overridden':True,'palisade_owner_extension_only':True,'canonical_adoption_pending':True})
  d=self.D/'KEEPER-CAPTURE';d.mkdir(exist_ok=False)
  self.stage(d,'PHOTO',['node','tools/photo_match.mjs',str(camfile),'--out',str(self.R/'capture')],90)
  match=json.loads(camdir.joinpath('gale_1902.match.json').read_text());refuse(match['verdict']=='unreviewed','must remain unreviewed before root view');refuse(len(match.get('rendered_members',[]))==2,'full keeper+core group missing');save(d/'CLOSED-RESULT.json',{'status':'ACTUAL_ONE_FULL_GALE_COMPOUND_NATIVE_CAPTURE_UNREVIEWED','at':now(),'match':match,'candidate_represented_by_real_NATIVE_MASTER_WEB':True,'original_DONE':False,'all_children_reaped':True})
 def run(self):
  self.setup()
  if self.args.phase=='keeper':
   self.one(['log_jail_keeper_house'],'KEEPER',True);self.capture();return
  refuse((self.D/'KEEPER-CAPTURE/CLOSED-RESULT.json').exists(),'keeper/capture must be first')
  refuse(os.environ.get('T2380_DEFAULT_CONTROLS')=='root-reviewed-first-keeper','need actual root review before defaults')
  n=0
  for index,ids in enumerate(PLAN['batches'],1):
   if (self.D/f'BATCH-{index:02}/CLOSED-RESULT.json').exists():continue
   if n>=self.args.max_batches or time.monotonic()>=self.deadline:break
   start=time.monotonic();self.one(ids,f'BATCH-{index:02}');n+=1
   done=len(list(self.D.glob('BATCH-*/CLOSED-RESULT.json')));last=time.monotonic()-start
   save(self.R/'PROGRESS.json',{'at':now(),'closed_batches':done,'total_batches':34,'last_actual_batch_seconds':round(last,3),'remaining_estimate_using_last_batch_seconds':round((34-done)*last,1),'native_all271_complete':done==34,'source_adoption':False,'next_original_ticket_state':'OPEN','checkpoint_ready':True})
   print((self.R/'PROGRESS.json').read_text(),flush=True)
  baseline_guard();self.primary_guard();floors()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--expected-head');ap.add_argument('--rehearse',action='store_true');ap.add_argument('--phase',choices=['keeper','defaults'],default='keeper');ap.add_argument('--max-batches',type=int,default=1);ap.add_argument('--seconds',type=int,default=540);args=ap.parse_args()
 if not args.execute:print(json.dumps(preflight(require_resources=not args.rehearse),indent=2));return
 refuse(not args.rehearse,'rehearsal may never execute')
 refuse(os.environ.get('T2380_NATIVE_CPU')=='root-approved-after-phone-and-firstfort','explicit root CPU grant absent; no fixture/heavy start')
 refuse(args.max_batches>0 and 0<args.seconds<=540,'bounded max_batches/deadline required')
 checked_source_guard(args.expected_head)
 run=Run(args)
 try:run.run()
 except BaseException as e:
  save(run.R/'STOPPED.json',{'at':now(),'error':str(e),'type':type(e).__name__,'preserve_all_failed_outputs':True,'no_result_pass_inferred':True});raise
if __name__=='__main__':main()
