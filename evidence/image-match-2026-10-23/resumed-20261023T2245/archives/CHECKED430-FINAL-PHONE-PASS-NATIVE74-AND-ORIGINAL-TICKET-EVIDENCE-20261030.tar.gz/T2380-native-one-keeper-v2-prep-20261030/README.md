# Jail keeper controller V2 — prepared, native run pending

This is an external controller refresh for T-2380. No primary source, registry, Git/index/ref, ticket or site file was changed. No fixture, Blender process, browser, new mesh, WEB derivative or picture verdict was created. The parent remains the sole source and CPU owner.

The accepted prototype remains exactly the closed implementation: `picture_layout: keeper_gale_1902`, two frame producer postimages, one keeper record, unchanged full Gale camera and original full-page photograph. Existing core, palisade, source records and grade table are pinned to the same 19 own inputs. No geometry or camera solve was revised. The picture/frame/date/rights limits in the original HANDOFF remain in force; no new rights question, grade promotion, completion or matches claim is made.

A fresh native recipe computation preserves **all 271 complete family rows** (source records, MASTER/WEB hashes and sizes, current recipe and proposed recipe), every frame recipe-closure SHA, and keeper recipe `4217b97083bebb4a3a6849adfdb7755d77d6041fad0238d72f0ee72bf48073f3`. Zero current family rows are stale. Only six old copy bindings changed: unrelated K01, K08, K13 and prairie_draft code plus the two current registry snapshots. The two actual frame postimages are unchanged and now receive explicit byte/size/mode guards in addition to their frozen implementation manifest.

The regular scaffold grows from 5,273,523 to **5,284,213 bytes**. The conservative extra filesystem envelope consequently grows by 10,690 bytes to **18,798,801 bytes**, on top of the unchanged workspace floor **536,870,912** and shared-TMP floor **1,800,000,000**. The fixture uses owned TMP/TEMP and XDG cache/config directories. Native stages retain CPU **3,4**, Blender **2 threads**, the official build/emit and WEB paths and owned reaper. Stage limits remain in place, with an added whole-invocation 540-second deadline. Actual excess usage or source drift still stops and reaps the owned stage.

V2 additionally requires the **actual checked 40-hex source HEAD**, no MERGE_HEAD and a clean source checkout before it creates a fixture, and rechecks that state during every native stage. Its family roster and complete foreign MASTER inventory must still match preparation; a future added/removed asset or changed producer requires another refresh. A resumed fixture must retain the same checked HEAD. The future commit is not guessed here.

## Checks actually run

- Read-only preparation and rehearsal on CPU2 passed, with no execution requested. The rehearsal deliberately reports that execution resource floors were not asserted while the parent's gate may be using transient scratch; every real execution and native stage still enforces them.
- Two syntax checks and eleven checked-state/prototype/CLI guards passed, including wrong/missing HEAD, active merge, dirty checkout, altered postimage/photo and missing CPU-grant refusals.
- All 29 files listed in the original readiness, implementation and V1 controller manifests remain exact. `IMMUTABLE-OLD-PACKETS-RECHECK.json` records them.
- The first preparer attempt stopped at an in-memory tuple-versus-JSON-list comparison before PLAN output. Its failure log is retained. Canonical JSON comparison now agrees with the exact native SHA and prior document; no source model or acceptance condition changed.

`PLAN.json`, the two reviewed diffs and `VALIDATION.json` contain the precise bindings. `READONLY-REHEARSAL.json` is preparation evidence only.

## Parent's later one-keeper invocation

After the parent has completed its phone/gate work and granted this one CPU/source phase, use the actual clean checked commit. This is an executable command template, not a launched job:

```bash
source /workspace/shared/resume-chicago-env.sh
T2380_NATIVE_CPU=root-approved-after-phone-and-firstfort PYTHONDONTWRITEBYTECODE=1 python /workspace/T2380-native-one-keeper-v2-prep-20261030/controller.py --execute --phase keeper --seconds 540 --expected-head ACTUAL_CHECKED40HEX
```

That generates exactly one genuine keeper MASTER, one official WEB derivative, and one native full-Gale compound capture with the current core and high pointed palisade. The capture remains **unreviewed** until the parent directly inspects it. Low hung gate/interface work and the independent Andreas comparison remain later visible work.

Only after direct first-capture review and a separate parent CPU phase may the preserved defaults path run, initially one batch of eight to measure the real rate:

```bash
T2380_NATIVE_CPU=root-approved-after-phone-and-firstfort T2380_DEFAULT_CONTROLS=root-reviewed-first-keeper PYTHONDONTWRITEBYTECODE=1 python /workspace/T2380-native-one-keeper-v2-prep-20261030/controller.py --execute --phase defaults --max-batches 1 --seconds 540 --expected-head SAME_ACTUAL_CHECKED40HEX
```

Every one of the 271 default MASTER+WEB pairs still needs actual native byte parity and genuine registrations before source adoption. Source changes, owners, both original image reviews, desktop/mobile app checks, full source gate, PR and dev merge remain pending. T-2380 stays open.
