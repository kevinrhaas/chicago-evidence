from pathlib import Path
import ast,copy,datetime,difflib,hashlib,importlib.util,json,os,stat,subprocess,sys
sys.dont_write_bytecode=True
os.sched_setaffinity(0,{2});os.nice(19)
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('keeper_v2_controller',P/'controller.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]
def checked(name,call,fail=False):
 try:call()
 except RuntimeError:
  assert fail,name;checks.append({'name':name,'expected_refusal':True,'pass':True});return
 assert not fail,name;checks.append({'name':name,'expected_refusal':False,'pass':True})
head='a'*40
checked('valid checked-source tuple',lambda:m.validate_checked_state(head,head,False,b''))
for name,args in [('missing checked head',(None,head,False,b'')),('bad checked head',('bad',head,False,b'')),('wrong actual head',(head,'b'*40,False,b'')),('active merge',(head,head,True,b'')),('dirty checkout',(head,head,False,b' M chicago/4d/data/structures/log_jail.json\n'))]:checked(name,lambda args=args:m.validate_checked_state(*args),True)
row=copy.deepcopy(m.PLAN['copies'][next(i for i,r in enumerate(m.PLAN['copies'])if r['postimage'])]['postimage_binding']);row['sha256']='0'*64
checked('changed keeper postimage refuses',lambda:m.bound_guard(row,'test immutable postimage'),True)
row=copy.deepcopy(m.PLAN['original_photo']);row['sha256']='0'*64
checked('changed original photo refuses',lambda:m.bound_guard(row,'test original photo'),True)
checked('actual immutable prototype and19core/source bindings',m.prototype_guard)
checked('actual271family and foreign MASTER inventory',m.roster_guard)
for rel in ['controller.py','prepare_plan.py']:ast.parse((P/rel).read_text())
# Negative CLI: no CPU grant can reach setup, even before any checked-head probe.
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('T2380_NATIVE_CPU',None)
res=subprocess.run([sys.executable,str(P/'controller.py'),'--execute','--expected-head',head],env=env,capture_output=True,text=True)
assert res.returncode!=0 and 'explicit root CPU grant absent' in res.stderr and not(P/'run').exists()
checks.append({'name':'CLI without CPU grant refuses before owned run or fixture','pass':True,'expected_refusal':True})
(P/'NO-GRANT-REFUSAL.json').write_text(json.dumps({'exit':res.returncode,'stderr':res.stderr,'owned_run_created':False,'native_or_browser_launched':False},indent=2)+'\n')
old=Path('/workspace/T2380-native-batch-controller-20261030')
packets=[(old,'CONTROLLER-CLOSED-MANIFEST.json'),(Path('/workspace/T2380-compound-readiness-20261030'),'CLOSED-MANIFEST.json'),(Path('/workspace/T2380-compound-readiness-20261030/implementation'),'IMPLEMENTATION-CLOSED-MANIFEST.json')]
immutable=[]
for folder,manifest in packets:
 j=json.loads((folder/manifest).read_text())
 for row in j['files']:
  f=folder/row['file'];raw=f.read_bytes();assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256'];immutable.append({'path':str(f),'sha256':row['sha256'],'bytes':len(raw)})
(P/'IMMUTABLE-OLD-PACKETS-RECHECK.json').write_text(json.dumps({'all_exact':True,'files':immutable},indent=2)+'\n')
(P/'CONTROLLER-DIFF.patch').write_text(''.join(difflib.unified_diff((old/'controller.py').read_text().splitlines(True),(P/'controller.py').read_text().splitlines(True),fromfile='closedV1/controller.py',tofile='preparedV2/controller.py')))
(P/'PREPARER-DIFF.patch').write_text(''.join(difflib.unified_diff((old/'prepare_plan.py').read_text().splitlines(True),(P/'prepare_plan.py').read_text().splitlines(True),fromfile='closedV1/prepare_plan.py',tofile='preparedV2/prepare_plan.py')))
plan=m.PLAN;original=json.loads((old/'PLAN.json').read_text());assert plan['family']==original['family']and plan['expected_keeper_recipe_sha256']==original['expected_keeper_recipe_sha256']and plan['source_closure']==original['source_closure']
result={'status':'READONLY_V2_PREPARATION_AND_NEGATIVE_GUARDS_PASS_NATIVE_UNRUN','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'syntax_pass':2,'family_rows_exact_to_closed_V1':271,'keeper_recipe_exact':plan['expected_keeper_recipe_sha256'],'original_packets_files_exact':len(immutable),'only_rebound_old_copy_rows':[r['relative']for r in plan['refresh_scope']['foreign_rows_rebound']],'source_recipe_closure_exact':True,'future_extra_fs_envelope_bytes':plan['future_extra_fs_envelope_bytes'],'original_extra_fs_envelope_bytes':original['future_extra_fs_envelope_bytes'],'workspace_floor':plan['workspace_floor'],'tmp_floor':plan['tmp_floor'],'fixture_or_native_or_browser_run':False,'primary_source_Git_index_ref_mutations':False,'CPU_affinity':sorted(os.sched_getaffinity(0)),'history':'Initial preparer comparison used tuple-valued in-memory native document against JSON-restored lists and correctly stopped before writing PLAN. Its negative log is retained; canonical JSON comparison now matches exact native SHA4217 and old doc.'}
(P/'VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='checks'},indent=2))
