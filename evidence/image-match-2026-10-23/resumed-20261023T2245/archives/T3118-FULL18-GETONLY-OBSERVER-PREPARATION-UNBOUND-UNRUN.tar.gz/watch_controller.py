"""Read-only T3118 final-head full18 CI observer. No dispatch, cancellation, merge, lap or source writes.
Requires an explicit closed dispatch receipt and full expected head before any API read.
"""
import argparse,concurrent.futures,datetime,hashlib,json,pathlib,re,subprocess

def api(path, raw=False):
    q=subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/'+path],capture_output=True)
    if q.returncode:
        raise RuntimeError(f'GET {path}: exit {q.returncode}: '+q.stderr.decode('utf-8','replace')[-500:])
    return q.stdout if raw else json.loads(q.stdout)

def once(path, data):
    if path.exists():
        if path.read_bytes()!=data: raise RuntimeError(f'Preserved evidence differs: {path}')
    else: path.write_bytes(data)

def bindings(args):
    if not re.fullmatch('[0-9a-f]{40}',args.head): raise ValueError('A full exact head SHA is required')
    source=pathlib.Path(args.dispatch);raw=source.read_bytes();d=json.loads(raw)
    if d.get('head')!=args.head or d.get('PR')!=args.pr: raise ValueError('Receipt PR/head mismatch')
    runs=d.get('runs',[])
    if len(runs)!=18 or len({r.get('id') for r in runs})!=18: raise ValueError('Exactly 18 distinct bound run IDs required')
    expected={'13','14','15','9-12','8','6-7','5','3-4','1-2'}
    for viewport in ['mobile','desktop']:
        rows=[r for r in runs if r.get('viewport')==viewport]
        if len(rows)!=9 or {r.get('stage') for r in rows}!=expected: raise ValueError('Nine exact groups per viewport required')
    for r in runs:
        if not isinstance(r.get('id'),int) or r['id']<=0 or not r.get('dispatch_accepted'): raise ValueError('Unaccepted or missing run binding')
        if r.get('observed_head')!=args.head: raise ValueError('Dispatch did not observe the exact expected head')
    out=pathlib.Path(args.out)
    if not out.is_absolute() or not str(out).startswith('/tmp/'): raise ValueError('Observer evidence must live in its own /tmp directory')
    out.mkdir(parents=True,exist_ok=True);once(out/'BOUND_DISPATCH.json',raw)
    return d,out

def poll(d,out):
    paths=[('PR','pulls/'+str(d['PR'])),('dev','git/ref/heads/dev'),('checks','commits/'+d['head']+'/check-runs?per_page=100')]
    paths += [(str(r['id']),'actions/runs/'+str(r['id'])) for r in d['runs']]
    def get(row):
        k,path=row
        try:return k,api(path)
        except Exception as e:return k,{'read_error':str(e)}
    response=dict(concurrent.futures.ThreadPoolExecutor(6).map(get,paths));pr=response['PR']
    result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_head':d['head'],'dispatch_sha256':hashlib.sha256((out/'BOUND_DISPATCH.json').read_bytes()).hexdigest(),'PR':{k:pr.get(k) for k in ['state','merged','draft','mergeable_state','merged_at','merge_commit_sha']},'PR_head':pr.get('head',{}).get('sha'),'PR_base':pr.get('base',{}).get('sha'),'dev':response['dev'].get('object',{}).get('sha'),'read_errors':{k:v['read_error'] for k,v in response.items() if 'read_error' in v},'smokes':[],'checks':[{k:c.get(k) for k in ['name','id','head_sha','status','conclusion','completed_at','details_url']} for c in response['checks'].get('check_runs',[])]}
    for requested in d['runs']:
        r=response[str(requested['id'])]
        row={k:requested[k] for k in ['id','viewport','stage']}
        row.update({k:r.get(k) for k in ['status','conclusion','head_sha','head_branch','event','path','run_attempt','created_at','updated_at','run_started_at','read_error']})
        row['head_matches']=r.get('head_sha')==d['head'];row['workflow_dispatch_matches']=r.get('event')=='workflow_dispatch';result['smokes'].append(row)
    result['counts']={}
    for r in result['smokes']:
        label=r['conclusion'] if r['status']=='completed' else r['status'] or 'UNKNOWN'
        result['counts'][label]=result['counts'].get(label,0)+1
    name='snapshot-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'.json'
    once(out/name,(json.dumps(result,indent=2)+'\n').encode());return result

def harvest(snapshot,out):
    rawdir=out/'job-logs';rawdir.mkdir(exist_ok=True);head=snapshot['expected_head']
    def one(run):
        jobs=api(f"actions/runs/{run['id']}/jobs?per_page=100")
        attempt=run.get('run_attempt') or 1
        once(rawdir/f"run{run['id']}-attempt{attempt}-jobs.json",(json.dumps(jobs,indent=2)+'\n').encode())
        records=[]
        for job in jobs.get('jobs',[]):
            if job.get('name')!='smoke' or job.get('status')!='completed':continue
            path=rawdir/f"run{run['id']}-attempt{attempt}-job{job['id']}.log"
            if not path.exists():once(path,api(f"actions/jobs/{job['id']}/logs",raw=True))
            data=path.read_bytes();text=re.sub(r'\x1b\[[0-9;]*m','',data.decode('utf-8','replace'));lines=text.splitlines();checkout=None
            for i,line in enumerate(lines[:-1]):
                if '[command]' in line and 'git log -1 --format=%H' in line:
                    m=re.search(r'Z ([0-9a-f]{40})$',lines[i+1]);checkout=m.group(1) if m else None
            viewport=re.findall(r'SMOKE_VIEWPORT: ([^\s]+)',text);stage=re.findall(r'SMOKE_STAGE: ([^\s]+)',text)
            counts=[{'passed':int(a),'failed':int(b)} for a,b in re.findall(r'(\d+) passed, (\d+) failed',text)]
            r={k:run[k] for k in ['id','viewport','stage','head_sha','conclusion','run_attempt']}
            r.update({'job':job['id'],'job_conclusion':job['conclusion'],'checkout':checkout,'head_matches':checkout==head,'viewport_matches':viewport==[run['viewport']],'stage_matches':stage==[run['stage']],'counts':counts,'smoke_pass':'SMOKE PASS' in text,'zero_page_errors':'zero page errors' in text,'suite_body_aborted':bool(re.search(r'FAIL[^\n]*the suite body ran to completion',text)),'log':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
            r['actual_result_verified']=r['head_matches'] and r['viewport_matches'] and r['stage_matches'] and r['smoke_pass'] and r['zero_page_errors'] and bool(counts) and all(c['failed']==0 for c in counts) and job['conclusion']=='success' and run['conclusion']=='success' and run['head_sha']==head and run.get('event')=='workflow_dispatch' and run.get('path')=='.github/workflows/chicago-4d-smoke.yml' and not r['suite_body_aborted']
            r['failure_lines']=[{'line':i+1,'text':line[:1200]} for i,line in enumerate(lines) if re.search(r'\bFAIL\b|FAILURES:|\bError:|TimeoutError',line) and 'self-test' not in line]
            r['evidence']=[{'line':i+1,'text':line[:700]} for i,line in enumerate(lines) if 'SMOKE_VIEWPORT:' in line or 'SMOKE_STAGE:' in line or 'zero page errors' in line or 'SMOKE PASS' in line or re.search(r'\d+ passed, \d+ failed',line) or checkout and line.endswith('Z '+checkout)]
            records.append(r)
        if not records:raise RuntimeError('Completed run has no completed native smoke job/log to verify')
        return records
    rows=[];errors=[]
    completed=[r for r in snapshot['smokes'] if r['status']=='completed']
    def safe(run):
        try:return one(run),None
        except Exception as e:return [],{'run':run['id'],'error':str(e)}
    for got,error in concurrent.futures.ThreadPoolExecutor(4).map(safe,completed):
        rows.extend(got)
        if error:errors.append(error)
    result={'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_head':head,'terminal_runs':len(completed),'verified_successes':sum(r['actual_result_verified'] for r in rows),'records':rows,'read_errors':errors,'all_18_success':len(rows)==18 and all(r['actual_result_verified'] for r in rows)}
    name='actual-results-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'.json';once(out/name,(json.dumps(result,indent=2)+'\n').encode());return result

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--dispatch',required=True);ap.add_argument('--head',required=True);ap.add_argument('--pr',type=int,required=True);ap.add_argument('--out',required=True);ap.add_argument('--harvest',action='store_true');args=ap.parse_args();d,out=bindings(args);s=poll(d,out)
    summary={k:s[k] for k in ['at','expected_head','PR_head','PR_base','dev','PR','counts','read_errors']};summary['all_18_metadata_heads_match']=all(r['head_matches'] for r in s['smokes']);summary['failed_runs']=[r for r in s['smokes'] if r['status']=='completed' and r['conclusion']!='success'];summary['required_checks']=[c for c in s['checks'] if c['name'] in ['gate','moving-frames','report','humans']]
    if args.harvest:
        r=harvest(s,out);summary['actual_terminal_log_count']=len(r['records']);summary['actual_verified_successes']=r['verified_successes'];summary['all_18_success']=r['all_18_success'];summary['log_read_errors']=r['read_errors'];summary['actual_failures']=[{k:x[k] for k in ['id','viewport','stage','checkout','counts','failure_lines','log']} for x in r['records'] if not x['actual_result_verified']]
    summary['all_check_runs']=s['checks'];summary['expected_head_is_current_PR_head']=s['PR_head']==s['expected_head'];print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
