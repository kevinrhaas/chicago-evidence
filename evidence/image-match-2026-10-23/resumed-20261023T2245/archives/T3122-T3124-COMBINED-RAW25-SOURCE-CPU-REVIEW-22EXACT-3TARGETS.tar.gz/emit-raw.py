"""CPU execution of actual build() and native mesh/material writers via tiny bpy adapter."""
from pathlib import Path
from types import ModuleType, SimpleNamespace as NS
import argparse, collections, copy, dataclasses, hashlib, importlib.util, json, math, os, sys
sys.dont_write_bytecode=True
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
HERE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--common-root',type=Path,required=True)
ap.add_argument('--source-root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
ap.add_argument('--records-file',type=Path);ap.add_argument('--dump-targets',action='store_true');ap.add_argument('--target-record',type=Path);ap.add_argument('--negative-controls',action='store_true')
args=ap.parse_args();sys.path.insert(0,str(args.common_root/'generators'))


class Socket:
    def __init__(self,value):self.default_value=value


class Material:
    def __init__(self,name):
        self.name=name;self.use_nodes=False;self.diffuse_color=(.8,.8,.8,1.)
        self.surface_render_method='UNSPECIFIED_BY_SOURCE'
        node=NS(inputs={'Base Color':Socket((.8,.8,.8,1.)),
                        'Roughness':Socket(.5),'Alpha':Socket(1.)})
        self.node_tree=NS(nodes={'Principled BSDF':node})


class Mesh:
    def __init__(self,name):
        self.name=name;self.materials=[];self._attrs={}
        self.attributes=NS(new=self.newattr)
    def from_pydata(self,verts,edges,faces):
        assert edges==[]
        self.verts=copy.deepcopy(verts);self.faces=copy.deepcopy(faces)
        self.polygons=[NS(material_index=0,use_smooth=False) for _ in faces]
    def update(self):pass
    def newattr(self,name,type,domain):
        assert type=='FLOAT' and domain=='POINT'
        attr=NS(data=[NS(value=None) for _ in self.verts]);self._attrs[name]=attr;return attr


bpy=ModuleType('bpy')
bpy.data=NS(materials=NS(new=Material),meshes=NS(new=Mesh),objects=NS(new=lambda name,mesh:NS(name=name,data=mesh)))
bpy.context=NS(scene=NS(collection=NS(objects=NS(link=lambda _:None))))
def unexpected(name):raise AssertionError('CPU adapter reached unsupported Blender API: '+name)
bpy.__getattr__=unexpected;sys.modules['bpy']=bpy


def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module


params=load(args.source_root/'generators/archetypes/fort_structure_params.py','archetypes.fort_structure_params')
builder=load(args.source_root/'generators/archetypes/fort_structure.py','actual_selected_fort')


def normal(points):
    n=[0.,0.,0.]
    for p,q in zip(points,points[1:]+points[:1]):
        n[0]+=(p[1]-q[1])*(p[2]+q[2]);n[1]+=(p[2]-q[2])*(p[0]+q[0]);n[2]+=(p[0]-q[0])*(p[1]+q[1])
    length=math.sqrt(sum(v*v for v in n))
    return tuple(v/length for v in n) if length else (0.,0.,0.)


def snapshot(obj):
    mesh=obj.data
    mats=[]
    for m in mesh.materials:
        inputs=m.node_tree.nodes['Principled BSDF'].inputs
        mats.append({'name':m.name,'use_nodes':m.use_nodes,'base_color':inputs['Base Color'].default_value,
                     'roughness':inputs['Roughness'].default_value,'alpha':inputs['Alpha'].default_value,
                     'diffuse_color':m.diffuse_color,'surface_render_method':m.surface_render_method})
    values={'vertices':mesh.verts,'faces':mesh.faces,
            'material_indices':[p.material_index for p in mesh.polygons],
            'materials':mats,'attributes':{k:[v.value for v in a.data] for k,a in mesh._attrs.items()},
            'smooth':[p.use_smooth for p in mesh.polygons],
            'polygon_unit_normals':[normal([mesh.verts[i] for i in f]) for f in mesh.faces]}
    assert all(all(math.isfinite(x) for x in v) for v in mesh.verts)
    return values


def digest(value):return hashlib.sha256(json.dumps(value,separators=(',',':'),sort_keys=True,allow_nan=False).encode()).hexdigest()


def summary(s):
    return {'parts_sha256':{k:digest(v) for k,v in s.items()},'snapshot_sha256':digest(s),
            'vertices':len(s['vertices']),'faces':len(s['faces']),
            'fan_triangles':sum(len(f)-2 for f in s['faces']),
            'materials':s['materials'],'attribute_names':list(s['attributes']),
            'bounds':[[min(v[k] for v in s['vertices']) for k in range(3)],
                      [max(v[k] for v in s['vertices']) for k in range(3)]]}


rows=[];negative=[]
if args.target_record:
    r=json.loads(args.target_record.read_bytes());records=[{'name':r['id']+'__'+r['phases'][0]['id'],'record':r,'phase_id':r['phases'][0]['id']}]
else:records=json.loads((args.records_file or HERE/'records25.json').read_bytes())
for row in records:
    record=row['record'];phase=next(p for p in record['phases'] if p['id']==row['phase_id'])
    p=params.from_phase(phase,record);obj=builder.build(p,row['name']);s=snapshot(obj)
    result={'name':row['name'],**summary(s)};rows.append(result)
    if args.dump_targets and record['id'] in {'chicago_lighthouse_1832','lake_house_construction','fort_dearborn_officers_quarters'}:
        target_dir=args.output.with_suffix('');target_dir.mkdir(exist_ok=True)
        (target_dir/(row['name']+'.raw.json')).write_text(json.dumps(s,separators=(',',':'))+'\n')
    if args.negative_controls and args.target_record:
        q=dataclasses.replace(p,tower_lantern_detail={**p.tower_lantern_detail,'pane_opacity':.19})
        changed=snapshot(builder.build(q,row['name']))
        assert digest(s['vertices'])==digest(changed['vertices']) and digest(s['faces'])==digest(changed['faces'])
        assert digest(s['materials'])!=digest(changed['materials'])
        negative.append({'fault':'pane_opacity_018_to019','geometry_exact':True,'material_guard_detects':True})
        reversed_mesh=copy.deepcopy(s);idx=next(i for i,n in enumerate(s['polygon_unit_normals']) if any(n))
        reversed_mesh['faces'][idx]=tuple(reversed(reversed_mesh['faces'][idx]))
        n=normal([reversed_mesh['vertices'][i] for i in reversed_mesh['faces'][idx]])
        assert n!=s['polygon_unit_normals'][idx]
        negative.append({'fault':'one_face_winding_reversed','vertex_positions_exact':True,'polygon_normal_guard_detects':True})
        confidence=copy.deepcopy(s['attributes']['_CONFIDENCE']);confidence[0]=.5 if confidence[0]!=.5 else 1.
        assert digest(confidence)!=digest(s['attributes']['_CONFIDENCE'])
        negative.append({'fault':'one_confidence_float_changed','confidence_guard_detects':True})
    if args.negative_controls and not args.target_record and p.gallery and p.gallery_storeys==2 and not negative:
        changed=snapshot(builder.build(dataclasses.replace(p,wall_height_m=p.wall_height_m+.1),row['name']))
        assert digest(s['vertices'])!=digest(changed['vertices'])
        negative.append({'fault':'one_gallery_wall_height_plus010m','geometry_guard_detects':True})
args.output.write_text(json.dumps({'scope':'ACTUAL_BUILD_AND_NATIVE_MESH_MATERIAL_SOURCE_CPU_ADAPTER_NOT_BLENDER_EXPORT',
                                  'rows':rows,'negative_controls':negative},indent=2)+'\n')
print('CPU captured',len(rows),'actual builds; output',args.output)
