import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import time

base = Path('/workspace/shared/relocated-closed-checkpoints-sixth-20261026')
base.mkdir(exist_ok=True)
libc = ctypes.CDLL(None, use_errno=True)
exchange = libc.renameat2
exchange.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
exchange.restype = ctypes.c_int

names = ['tremont-T2385-before-a575-complete-20261026', 'tremont-T2385-app-four-loads-closed-20261026', 'tremont-T2385-app-desktop-20261026', 'tremont-T2385-app-mobile-gifford-20261026', 'tremont-T2385-app-mobile-20261026']

def free(path):
    s = os.statvfs(path)
    return s.f_bavail * s.f_frsize

def snapshot(root):
    result = {}
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in sorted(dirs + files):
            p = Path(parent) / name
            s = p.lstat()
            entry = {'mode': stat.S_IMODE(s.st_mode)}
            if stat.S_ISLNK(s.st_mode):
                entry.update(kind='symlink', target=os.readlink(p))
            elif stat.S_ISREG(s.st_mode):
                h = hashlib.sha256()
                with p.open('rb') as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b''):
                        h.update(block)
                entry.update(kind='file', bytes=s.st_size, sha256=h.hexdigest())
            elif stat.S_ISDIR(s.st_mode):
                entry.update(kind='directory')
            else:
                raise RuntimeError(f'Unexpected special file: {p}')
            result[str(p.relative_to(root))] = entry
    return result

def swap(a, b):
    if exchange(-100, os.fsencode(a), -100, os.fsencode(b), 2):
        raise OSError(ctypes.get_errno(), 'atomic directory/symlink exchange failed')

copied_inodes = {}
def copy_preserving_links(source, destination):
    info = os.stat(source)
    key = (info.st_dev, info.st_ino)
    previous = copied_inodes.get(key)
    if previous is not None:
        os.link(previous, destination)
        shutil.copystat(source, destination)
    else:
        shutil.copy2(source, destination)
        copied_inodes[key] = destination
    return destination

receipt = {'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
           'scope': 'Only named CLOSED checkpoint directories, never worktrees or live logs',
           'initial_free_tmp': free('/tmp'), 'initial_free_workspace': free('/workspace'),
           'entries': []}
total = 0
for name in names:
    if free('/tmp') >= int(2.1 * 1024**3):
        break
    src, dst = Path('/tmp') / name, base / name
    if not src.is_dir() or src.is_symlink():
        continue
    assert not dst.exists(), f'Existing destination requires explicit inspection: {dst}'
    before = snapshot(src)
    amount = sum(x.get('bytes', 0) for x in before.values())
    if total + amount > 270 * 1024**2 or free('/workspace') - amount < 512 * 1024**2:
        continue
    shutil.copytree(src, dst, symlinks=True, copy_function=copy_preserving_links)
    assert snapshot(dst) == before, f'Destination mismatch: {src}'
    assert snapshot(src) == before, f'Source changed while copying: {src}'
    forwarding = src.with_name(src.name + f'.verified-relocation-{os.getpid()}')
    assert not forwarding.exists() and not forwarding.is_symlink()
    forwarding.symlink_to(dst, target_is_directory=True)
    swap(src, forwarding)
    if snapshot(forwarding) != before or snapshot(dst) != before:
        swap(src, forwarding)
        forwarding.unlink()
        raise RuntimeError(f'Post-exchange verification failed; rolled back: {src}')
    assert src.is_symlink() and src.resolve() == dst.resolve()
    assert forwarding.is_dir() and not forwarding.is_symlink()
    shutil.rmtree(forwarding)
    total += amount
    digest = hashlib.sha256(json.dumps(before, sort_keys=True).encode()).hexdigest()
    receipt['entries'].append({'original_path': str(src), 'backing_path': str(dst),
                               'payload_bytes': amount, 'members': len(before),
                               'all_member_sha_size_mode_snapshot_sha256': digest,
                               'atomic_exchange': True, 'forwarding_link_verified': True,
                               'snapshot': before})
    receipt['final_free_tmp'] = free('/tmp')
    receipt['final_free_workspace'] = free('/workspace')
    temp = base / 'RELOCATION.json.tmp'
    temp.write_text(json.dumps(receipt, indent=2) + '\n')
    os.replace(temp, base / 'RELOCATION.json')

print(json.dumps({'status': 'PASS', 'relocated_directories': len(receipt['entries']),
                  'payload_bytes': total, 'free_tmp': free('/tmp'),
                  'free_workspace': free('/workspace'), 'receipt': str(base / 'RELOCATION.json')}))
