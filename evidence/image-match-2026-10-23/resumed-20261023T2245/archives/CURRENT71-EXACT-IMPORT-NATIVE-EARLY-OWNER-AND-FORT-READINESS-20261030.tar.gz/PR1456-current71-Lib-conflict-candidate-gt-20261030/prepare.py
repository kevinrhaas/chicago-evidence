from pathlib import Path
import datetime,hashlib,heapq,json,os,re,subprocess
R=Path('/workspace/chicago');O=Path(__file__).parent;REL='chicago/4d/docs/LIBERTIES.md';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');g=lambda *a:subprocess.check_output(['git','-C',str(R),*a],env=E);sha=lambda b:hashlib.sha256(b).hexdigest()
def parse(b):
 matches=list(re.finditer(rb'(?m)^### (L[^ \t\r\n]+)(?:[ \t]|$)',b));assert len(matches)>850;pre=b[:matches[0].start()];order=[];blocks={}
 for i,m in enumerate(matches):
  key=m[1].decode();assert key not in blocks;order.append(key);blocks[key]=b[m.start():matches[i+1].start()if i+1<len(matches)else len(b)]
 return pre,order,blocks
B,Ours,Theirs=[g('show',':'+str(n)+':'+REL)for n in [1,2,3]];bp,bo,b=parse(B);op,oo,o=parse(Ours);tp,to,t=parse(Theirs);core=lambda x:x.rstrip(b'\n')if x is not None else None
assert bp==op==tp,'Preamble changed';chosen={};changes=[];conflicts=[]
for key in set(b)|set(o)|set(t):
 bv,ov,tv=b.get(key),o.get(key),t.get(key)
 if bv is not None:assert ov is not None and tv is not None,('Append-only deletion',key)
 oc,tc=core(ov)!=core(bv),core(tv)!=core(bv)
 if not oc:chosen[key]=tv
 elif not tc:chosen[key]=ov
 elif core(ov)==core(tv):chosen[key]=tv
 else:conflicts.append(key);continue
 changes.append({'id':key,'ours_changed':oc,'theirs_changed':tc,'base_sha256':sha(bv)if bv is not None else None,'ours_sha256':sha(ov)if ov is not None else None,'theirs_sha256':sha(tv)if tv is not None else None,'chosen_sha256':sha(chosen[key])})
assert not conflicts,('Genuine entry content conflicts',conflicts)
# Preserve BOTH branch sequences; choose dated older additions first only where
# concurrent tails impose no ordering. This never moves any incoming pair.
edges={k:set()for k in chosen};degree={k:0 for k in chosen}
for order in [oo,to]:
 for a,z in zip(order,order[1:]):
  if z not in edges[a]:edges[a].add(z);degree[z]+=1
rank={k:i for i,k in enumerate([*oo,*[k for k in to if k not in o]])}
def priority(k):
 date=re.search(rb'\*\*Recorded:\*\*\s*(\d{4}-\d{2}-\d{2})',chosen[k]);return(date[1].decode()if date else '9999-99-99',rank[k],k)
heap=[priority(k)for k in chosen if degree[k]==0];heapq.heapify(heap);order=[]
while heap:
 _,_,k=heapq.heappop(heap);order.append(k)
 for z in edges[k]:
  degree[z]-=1
  if degree[z]==0:heapq.heappush(heap,priority(z))
assert len(order)==len(chosen),'Entry-order conflict needs review'
output=tp+b''.join(chosen[k]for k in order);_,outorder,out=parse(output);assert outorder==order and out==chosen
own_changed={k for k in chosen if core(o.get(k))!=core(b.get(k))};foreign=[k for k in to if k not in own_changed];assert all(out[k]==t[k]for k in foreign);assert [k for k in order if k in t]==to;assert [k for k in order if k in o]==oo
(O/'LIBERTIES-CANDIDATE.md').write_bytes(output);d={'status':'EXTERNAL_ONLY_EXACT_ENTRYWISE_AUTHORED_LIB_CONFLICT_CANDIDATE_NO_PRIMARY_WRITE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'path':REL,'head':g('rev-parse','HEAD').decode().strip(),'merge_parent':g('rev-parse','MERGE_HEAD').decode().strip(),'base_sha256':sha(B),'ours_sha256':sha(Ours),'theirs_sha256':sha(Theirs),'candidate_sha256':sha(output),'candidate_bytes':len(output),'entry_counts':{'base':len(b),'ours':len(o),'theirs':len(t),'candidate':len(out)},'own_changed_ids':sorted(own_changed),'incoming_changed_ids':sorted(k for k in t if core(t[k])!=core(b.get(k))),'all_incoming_foreign_entry_blocks_byte_exact':len(foreign),'all_incoming_entry_order_exact':True,'all_ours_entry_order_exact':True,'preamble_all_three_exact':True,'genuine_entry_content_conflicts':conflicts,'rows':[r for r in changes if r['ours_changed']or r['theirs_changed']]};(O/'RESULT.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k!='rows'},indent=2))
