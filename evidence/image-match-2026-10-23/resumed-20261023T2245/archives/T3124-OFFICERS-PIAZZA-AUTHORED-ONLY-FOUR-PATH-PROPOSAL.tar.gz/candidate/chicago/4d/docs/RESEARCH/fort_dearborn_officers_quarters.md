# Fort Dearborn — officers' quarters

> Part of the Fort Dearborn complex. The plan source, the scale derivation, the garrison chronology, the wrong-fort guards and the three corrections to `docs/research/04-structures-south.md` are all in **`docs/RESEARCH/fort_dearborn.md`**, which this memo does not repeat.

## What is evidence

- **Logs, on the west, within the pickets** — Hubbard 1827, standing in the fort. The 1855 key
  says "wood", which is the same claim less precisely.
- **About 30 × 60 ft** — the 1855 key.
- Andreas p. 84: "The officers' quarters were on the west side."

## The one real dimensional disagreement in this complex

The 1855 key gives 30 × 60 ft. The 1830 plan draws the west range about 30 ft deep and about
80 ft long at this project's derived scale — agreement on the depth to 3 %, disagreement on the
length by nearly 40 %. **The stated figure wins**, because the scale that would overrule it was
itself calibrated on the other stated figure in the same caption. The cost is legible: the
modelled building is about 6 m shorter than the plan draws its range. That is why the footprint
is `inferred` and the commandant's is `documented`.

## A correction

`docs/research/04-structures-south.md` § 1.2 reads Andreas as giving brick officers' quarters
here and flags a conflict with the 1855 key. Andreas p. 84 gives no material and Andreas p. 264
gives logs. There is no conflict. See the main memo § 6.

## What is ours

The storey count (`conjectural`), the wall height, the roof, the stacks, and the decision to
build a plain front rather than a gallery — **L42**.


## T-3124 — bounded rereading and working upper-piazza reconstruction (2026-10-24)

`not_a_reading`: this reuses already admitted Hubbard claims and the existing fort plan/
Kinzie description for a modelling choice. It is not a new source-spend unit or a settled
identity/continuity ruling. Existing claims and prior refusals are preserved.

The positive pre-1835 form basis is `hubbard_autobiography_1911`, printed p. 36, scan leaf 74,
raw lines 2354–2364, `bk_hub_055`: the officers' quarters on Hubbard's first 1818 visit had
a piazza along the entire east front at second-floor level, with outside stairs. This is a
late recollection printed in 1888/1911, tier 2, not a contemporary 1818 record. Its two-storey
statement qualifies the old categorical 'not attested anywhere' note; the current value and
reconstructed grade remain.

For this model only, the range is conditionally associated with the **old** west log officers'
quarters in the same source's p. 167, leaf 205, raw lines 7609–7617, `bk_hub_090`, and the west
interior range drawn on `harrison_1830_river_mouth` (Andreas 1884 vol. 1 p. 113, leaf n242).
Function, material and east-facing parade front support that working interpretation. The
map is a memory-amended plan, not an elevation or a gallery drawing.

The conflict is retained: p. 36 says OUTSIDE the pickets, p. 167 says WITHIN. No dated
alteration/replacement record settles it. The fire account omits the west officers' range
from its list of losses, but absence from that list proves neither survival nor unchanged
fittings. The old spend ruling's refusal to re-elevate 1818 fabric remains in the record.
This new **model choice** does not rewrite it as a settled historical identification.

`kinzie_waubun_1856`, ch. XVII opening, recalls the 1831 group as the same buildings 'as at
present'. That is conditional building-group identity support only; no precise endpoint or
unchanged gallery is assumed. The nearby described piazza belongs to the Kinzie house.
`wentworth_1881_fort_dearborn`, printed pp. 92–93 after the 1855 Hesler view/key, is a later B
appearance bracket, not the source of 1835 fittings or a formal matched July 1835 view.

The model replaces the plain-front choice above with open lower space and one upper deck.
All exact metrics, sections, rails, canopy and closed ends remain reconstructed. The
18 front/back opening rectangles preserve the former generated positions exactly; they are
not newly measured historic bays. Outside stairs are unmodelled. Original T-2388 stays open;
all comparisons remain DIFFERS. See `L-second-fort-officers-upper-piazza-3124`.

Private source-bound geometry and 1855 diagnostic comparisons demonstrate the visible
increment, not canonical app acceptance. All 1,764 old physical triangles remain and only
gallery surfaces are added. New posts add ground-contact samples, so future app grounding
needs its own validation; common-plane review images do not establish terrain contact.
