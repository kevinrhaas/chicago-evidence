

### L-second-fort-officers-upper-piazza-3124 — a working officers' upper piazza

**Decision:** The second-fort officers' range has open lower space and one upper piazza in
the July 1835 model (T-3124). Occurrence on this specific range/date remains reconstructed.
The primary form source is Hubbard's late recollection of 1818, not a copied 1855 fitting:
`hubbard_autobiography_1911`, p. 36/scan leaf 74/`bk_hub_055`, describes an east-fronting
two-storey log officers' range with a full-front second-floor piazza and outside stairs.

The same-west-range association is a working reconstruction from function, log material,
east-facing parade front, the old west log range in the 1827 account (p. 167/leaf 205/
`bk_hub_090`) and the 1830 plan. OUTSIDE versus WITHIN the pickets remains unresolved; no
dated alteration record closes the gap. Kinzie's 1831 same-building-group recollection is
conditional identity support only. Prior claims and spend refusals remain; this is a
rereading/model admission, not a new reading or historical identity ruling. The 1855 B
engraving/key (`wentworth_1881_fort_dearborn`, pp. 92–93) is diagnostic context only.

Reach 2.1 m, deck thickness 0.14 m, post section 0.14 m, rail height 0.95 m, baluster
section 0.055 m/pitch about 0.18 m, canopy fall 0.45 m and closed rail ends are reconstructed
helper choices, not source measurements. The actual helper uses one upper deck, not two
independently attested piazza decks. Supports are projected onto clear piers beside both
storeys' openings; that set-out is ours. The 18 explicit front/back rectangles preserve the
old generated openings, not measured historic bays. Outside stairs remain unmodelled.

**Covers:** `fort_dearborn_officers_quarters.log_1816.form.gallery`,
`fort_dearborn_officers_quarters.log_1816.form.gallery_storeys`,
`fort_dearborn_officers_quarters.log_1816.form.face_openings`.

**Bounds:** Only this one phase opts in; footprint, bearing, wall height, building storey
grade, roof, stacks, occupants and other fort records do not move. The image gate is not
complete: all original T-2388 comparisons remain DIFFERS. The private 1855 camera is
unfitted diagnostic context, not a formal July 1835 matched view. Terrain/app acceptance
is separately owed; new post feet may change the ground samples.

**Sources:** `hubbard_autobiography_1911`; `harrison_1830_river_mouth`; `kinzie_waubun_1856`.
**Subjects:** `fort_dearborn_officers_quarters`.
**Recorded:** 2026-10-24.
