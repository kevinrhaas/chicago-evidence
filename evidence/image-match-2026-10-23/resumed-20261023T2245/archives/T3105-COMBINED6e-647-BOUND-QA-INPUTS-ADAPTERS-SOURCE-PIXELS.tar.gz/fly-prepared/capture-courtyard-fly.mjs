// Separate supplemental native Fly inspection only. Not on-foot/accessibility proof; the grounded FAIL stays unchanged. No source-matching camera changes.
import path from 'node:path';
export async function captureCourtyardFly(page, out) {
 const id='first_fort_dearborn_officers_barracks';
 const pose=await page.evaluate(id=>{
  const a=__chicago4d,parade=a.registry.get('first_fort_dearborn_parade')?.sidecar;
  if(String(a.scene.id)!=='1812'||!parade)throw Error('Courtyard inspection requires the actual1812parade');
  // Dataset-derived inspection station within the open parade, deliberately
  // southeast of the staff. These fractions choose a view, not historical metrics.
  // Use the original unchanged parade register box, checked against placement.
  const p=parade.placement;
  if(Math.abs(p.local_e-1144.11)>.011||Math.abs(p.local_n-213.04)>.011)throw Error('Parade placement drift: re-review inspection station');
  const e=p.local_e+15.51*.75,n=p.local_n+16.46*.20;
  const ground_point_blocked=a.router.blockedAt(e,n); // Preserved ground limitation, not waived.

  const b=a.buildings.instanceBounds()[id],m=a.buildings.matrixOf(id);
  if(!b||!m)throw Error('Missing actual officers GLB bounds/matrix');
  const x=(b.min[0]+b.max[0])/2,y=b.min[1]+(b.max[1]-b.min[1])*.47,z=(b.min[2]+b.max[2])/2;
  const v=m.elements,tx=v[0]*x+v[4]*y+v[8]*z+v[12],ty=v[1]*x+v[5]*y+v[9]*z+v[13],tz=v[2]*x+v[6]*y+v[10]*z+v[14];
  a.setFly(true);a.walker.teleport({local_e:e,local_n:n,altitude_m:3});a.step();
  const eye=a.player.y,de=tx-e,dn=-tz-n;
  const yaw=((Math.atan2(de,dn)*180/Math.PI)+360)%360,pitch=Math.atan2(ty-eye,Math.hypot(de,dn))*180/Math.PI;
  a.walker.teleport({local_e:e,local_n:n,altitude_m:3,yaw_deg:yaw,pitch_deg:pitch});a.step();
  if(!a.player.flying||Math.abs(a.player.altitude-3)>.01)throw Error('Supplemental view did not enter actual native Fly mode at declared altitude');
  const ground=a.terrain.surfaceHeight(a.player.e,a.player.n);
  if(!Number.isFinite(ground)||!a.stats().withinBudget)throw Error('Invalid courtyard ground/budget');
  return {kind:'supplemental_native_Fly_inspection_not_on_foot_or_accessibility_proof',id,station_fractions:{e:.75,n:.20},parade_position:p,player:{...a.player},ground,aim:{e:tx,n:-tz,y:ty},yaw_deg:yaw,pitch_deg:pitch,ground_point_blocked,accessibility_proven:false,stats:a.stats(),problems:[...a.problems]};
 },id);
 await page.evaluate(()=>{__chicago4d.setConfidenceView(false);__chicago4d.step();});
 await page.screenshot({path:path.join(out,'courtyard-officers-FLY-native.png')});
 await page.evaluate(()=>{__chicago4d.setConfidenceView(true);__chicago4d.step();});
 await page.screenshot({path:path.join(out,'courtyard-officers-FLY-by-grade.png')});
 await page.evaluate(()=>{__chicago4d.setConfidenceView(false);__chicago4d.step();});
 return pose;
}
