import {captureCourtyardFly} from './capture-courtyard-fly.mjs';
// T3082 V2 final5d9: separate current wording/native card QA; all older QA preserved.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {checkReviewNotices} from './review-notices.mjs';
import {readReviewSurfaceInPage,checkReviewSurface} from './review-surfaces.mjs';

const QA_DIR=path.dirname(fileURLToPath(import.meta.url));
const args=process.argv.slice(2), option=(k,d)=>{const i=args.indexOf(k);return i<0?d:args[i+1];};
const config=JSON.parse(fs.readFileSync(path.join(QA_DIR,'models.json'),'utf8'));
const app=path.resolve(option('--app',config.app)), site=path.resolve(app,'../../site/4d');
const bindings=JSON.parse(fs.readFileSync(path.join(QA_DIR,'input-bindings.json'),'utf8'));
for(const b of bindings.files){const base=b.root==='app'?app:site;const got=crypto.createHash('sha256').update(fs.readFileSync(path.join(base,b.path))).digest('hex');if(got!==b.sha256)throw Error('Frozen current source/published input drift: '+b.root+'/'+b.path);}
const viewportName=option('--viewport','mobile');
if(!['mobile','desktop'].includes(viewportName))throw Error('viewport must be mobile or desktop');
const chosen=option('--ids','').split(',').filter(Boolean);
const models=config.models.filter(x=>!chosen.length||chosen.includes(x.id));
if(!models.length||chosen.some(id=>!models.some(m=>m.id===id)))throw Error('Unknown or empty model selection');
const out=path.resolve(option('--out',path.join(QA_DIR,'runs',new Date().toISOString().replaceAll(':','-'))));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const m of models){
 const actual=sha(fs.readFileSync(path.join(app,'data/structures',m.id+'.json')));
 if(actual!==m.record_sha256)throw Error(m.id+': authored record drift; update/review expectation rather than overwrite it');
}
if(!args.includes('--execute')){
 console.log(JSON.stringify({status:'PREPARED_ONLY_NOT_EXECUTED',app,site,viewportName,ids:models.map(x=>x.id),out,
  limits:'No browser, publish, fetch, Blender, full gate, acceptance or canonical write. Pass --execute only after root assigns browser slot and native publish finishes.'},null,2));
 process.exit(0);
}
if(fs.existsSync(out))throw Error('Refusing to overwrite existing run: '+out);
fs.mkdirSync(out,{recursive:true});
const report={status:'RUNNING',started_at:new Date().toISOString(),app,site,viewport:viewportName,
 method:'Actual native published /walk/ app, visitor light/full tier, Inspect Photos/Sources, native framing and live feet through actual placement matrices. No source camera solving or automatic image-match acceptance.',
 limits:'Targeted seven-model first-fort application QA; not whole published smoke or an image-match verdict. Door/apron checks read declared access geometry; solid footprints still have no walk-through interiors. Burial is reported, not silently allowed as new evidence.',
 source_config_sha256:sha(fs.readFileSync(path.join(QA_DIR,'models.json'))),models:[],page_errors:[],http_errors:[],request_failures:[],web_asset_responses:[]};
const nativeRequestErrors=()=>report.request_failures.filter(r=>!/ERR_ABORTED/.test(typeof r.failure==='object'?(r.failure?.errorText||''):String(r.failure??'')));
const save=()=>fs.writeFileSync(path.join(out,'QA-RESULT.json'),JSON.stringify(report,null,2)+'\n');
save();
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.glb':'model/gltf-binary','.svg':'image/svg+xml','.wasm':'application/wasm','.ktx2':'image/ktx2'};
const server=http.createServer((req,res)=>{
 try{
  const url=new URL(req.url,'http://localhost');let p=path.resolve(site,'.'+decodeURIComponent(url.pathname));
  if(p!==site&&!p.startsWith(site+path.sep)){res.writeHead(403);res.end();return;}
  if(fs.statSync(p).isDirectory())p=path.join(p,'index.html');
  res.writeHead(200,{'Content-Type':types[path.extname(p)]||'application/octet-stream'});fs.createReadStream(p).pipe(res);
 }catch{res.writeHead(404);res.end('missing');}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let browser=null,context=null,failure=null;
const responseTasks=[],inflight=new Map();
try{
 for(const m of models){
  const web=fs.readFileSync(path.join(app,'assets/web',m.asset));
  const published=fs.readFileSync(path.join(site,'data/gltf',m.asset));
  if(sha(web)!==sha(published))throw Error(m.id+': published web GLB is stale');
  m.expected_web_sha256=sha(web);
 }
 let require=createRequire(path.join(app,'tools/qa.mjs'));
 try{require.resolve('playwright');}catch{require=createRequire('/workspace/__qa__.mjs');}
 const {chromium}=require('playwright');
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE||'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 const viewport=viewportName==='mobile'?{width:390,height:780}:{width:1280,height:800};
 context=await browser.newContext({viewport,deviceScaleFactor:viewportName==='mobile'?2:1,isMobile:false,hasTouch:viewportName==='mobile'});
 report.browser_context={viewport,deviceScaleFactor:viewportName==='mobile'?2:1,isMobile:false,hasTouch:viewportName==='mobile'};
 const page=await context.newPage();page.setDefaultTimeout(240000);
 page.on('pageerror',e=>report.page_errors.push(String(e)));
 page.on('request',r=>inflight.set(r,r.url()));
 page.on('requestfinished',r=>inflight.delete(r));
 page.on('requestfailed',r=>{inflight.delete(r);report.request_failures.push({url:r.url(),method:r.method(),resource_type:r.resourceType(),failure:r.failure()});});
 page.on('response',r=>{
  if(r.status()>=400)report.http_errors.push({url:r.url(),status:r.status()});
  const m=models.find(m=>r.url().split('?')[0].endsWith('/data/gltf/'+m.asset));
  if(m)responseTasks.push((async()=>{
   const b=await r.body();report.web_asset_responses.push({id:m.id,url:r.url(),status:r.status(),bytes:b.length,sha256:sha(b),expected_sha256:m.expected_web_sha256});
  })().catch(e=>{report.request_failures.push({id:m.id,url:r.url(),failure:String(e)});}));
 });
 const base='http://127.0.0.1:'+server.address().port;
 await page.goto(base+'/walk/?year='+encodeURIComponent(config.scene),{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:240000,polling:500});
 const boot=await page.evaluate(()=>({ready:__chicago4d.ready,error:__chicago4d.error,scene:__chicago4d.scene?.id}));
 if(!boot.ready||boot.error||String(boot.scene)!==String(config.scene))throw Error('Native app did not boot the configured scene: '+JSON.stringify(boot));
 await page.waitForFunction(()=>__chicago4d.welcome?.state==='welcome',null,{timeout:240000});
 await page.evaluate(async detail=>{
  const a=__chicago4d;await a.setDetail(detail);
  if(!a.welcome.enter('spawn'))throw Error('welcome entry failed');
  document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();
  a.renderer.setAnimationLoop(null);a.setAnimationHold(true);a.step();
 },viewportName==='mobile'?'light':'full');
 await page.waitForFunction(()=>document.getElementById('gate').hidden);
 report.boot=boot;
 report.scope='SUPPLEMENTAL_FLY_ONLY_NOT_STANDARD_QA_NOT_ON_FOOT_OR_ACCESSIBILITY';
 report.fly=await captureCourtyardFly(page,out);
 const declared=await page.evaluate(()=>[...__chicago4d.registry.values()].filter(r=>r.sidecar?.review_required).map(r=>r.sidecar.id).sort());
 report.fly.review_notices=checkReviewNotices(config.scene_review_notices,declared,report.fly.problems);
 if(report.fly.review_notices.failures.length)throw Error(report.fly.review_notices.failures.join('\n'));
 const networkDeadline=Date.now()+30000;
 while(inflight.size&&Date.now()<networkDeadline)await new Promise(r=>setTimeout(r,100));
 report.pending_requests=[...inflight.values()];
 if(inflight.size)throw Error('Native app requests did not finish: '+JSON.stringify(report.pending_requests));
 await Promise.all(responseTasks);
 for(const m of models){const got=report.web_asset_responses.filter(x=>x.id===m.id);if(!got.length||got.some(x=>x.status!==200||x.sha256!==m.expected_web_sha256))throw Error(m.id+': actual loaded published web asset binding failed');}
 const failures=report.models.flatMap(x=>x.failures.map(f=>x.id+': '+f));
 if(report.page_errors.length||report.http_errors.length||nativeRequestErrors().length)failures.push('Page/network errors: see unfiltered receipts');
 if(failures.length)throw Error(failures.join('\n'));
 report.status='PASS_SUPPLEMENTAL_FLY_NOT_ON_FOOT_NOT_STANDARD_QA';
}catch(e){failure=e;report.status='FAIL';report.error=String(e.stack||e);}
finally{
 try{await context?.close();}catch(e){report.cleanup_errors??=[];report.cleanup_errors.push(String(e));}
 try{await browser?.close();}catch(e){report.cleanup_errors??=[];report.cleanup_errors.push(String(e));}
 await new Promise(r=>server.close(r));
 if(report.page_errors.length||report.http_errors.length||nativeRequestErrors().length||report.cleanup_errors?.length){
  report.status='FAIL';failure??=Error('Page/network/cleanup errors: see unfiltered receipts');report.error??=String(failure);
 }
 report.native_network_classification={policy:'Exact native smoke_renderer.mjs ERR_ABORTED exclusion; all unfiltered events remain above',hard_errors:nativeRequestErrors(),aborted_requests:report.request_failures.filter(r=>!nativeRequestErrors().includes(r))};
 report.ended_at=new Date().toISOString();save();
}
console.log(JSON.stringify({status:report.status,out,error:report.error??null},null,2));
if(failure)process.exitCode=1;
