from pathlib import Path
import os,json,subprocess,hashlib,datetime,time,shutil,re,signal
os.sched_setaffinity(0,{2});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1',TMPDIR='/tmp/sm-n');repo=Path('/tmp/st-mary-picture-20261025');app=repo/'chicago/4d';r=Path('/tmp/st-mary-runtime-20261025');out=r/'combined-package-publish';assert not out.exists();out.mkdir();load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();floor=536870912;scope=load(r/'combined-all44-scope/RESULT.json');assert not scope['retained_real_semantic_binary_changes']and not scope['protected_population_paths_dirty'];assert load(r/'combined-all44-scope-status.json')['all_children_reaped'];prep=load(r/'combined-cf25-132e-v2/RESULT.json');family=load(r/'ff-20affa/PREPARED.json')['family542'];GT=load(r/'checked-GT23-snapshot.json');resources=[]
def space(label):
 free=shutil.disk_usage('/tmp').free;resources.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':label,'free_bytes':free});(out/'RESOURCE-OBSERVATIONS.json').write_text(json.dumps(resources,indent=2)+'\n');assert free>=floor,('ROOT_EXTERNAL512MIB_RESERVE_NO_NATIVE_ASSERTION_CHANGE',label,free);return free
def run(name,cmd):
 print(name,'START',datetime.datetime.now(datetime.timezone.utc).isoformat(),'FREE',space(name+' BEFORE'),flush=True);p=subprocess.Popen(cmd,cwd=app,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
 try:
  with(out/(name+'.log')).open('x')as log:
   for line in p.stdout:
    log.write(line);log.flush()
    if re.match(r'^\s*\[\d+/\d+\]',line):
     try:space(name+' '+line.strip())
     except AssertionError:os.killpg(p.pid,signal.SIGTERM);p.wait();raise
  code=p.wait()
 finally:
  if p.poll()is None:os.killpg(p.pid,signal.SIGTERM);p.wait()
 assert code==0,(name,code)
 if name=='native-package5':
  text=(out/(name+'.log')).read_text();assert 'derived layer rebuilt from step 198'in text and 'the last one moved nothing'in text,text[-1200:]
 print(name,'CLOSED_PASS',flush=True)
start=time.monotonic();run('native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']);run('native-final-publish',['bash','tools/publish.sh']);assert all(sha(app/p)==s for p,s in family.items());assert all(sha(repo/p)==v['sha256']for p,v in GT['files46'].items());assert all(sha(repo/p)==s for p,s in prep['authored_inputs_sha256'].items());assert all(sha(repo/z['path'])==z['base_sha256']for z in scope['rows']if z['semantics_equal'])
result={'status':'COMBINED_NATIVE_COMPOSITE_PLUS_ALL44_SCOPE_PACKAGE5_PUBLISH_COMPLETE','HEAD':prep['HEAD'],'MERGE_HEAD':prep['MERGE_HEAD'],'original_native_resolve_wrapper_exit':1,'original_resource_stop_retained':True,'successful_continuation':'actual202+7prefix then registered57tail1lapfixedpoint, nativefinalizer, ONEall44/outside4Daudit, nativepkg5fixedpoint/finalpublish','seconds_package_publish':round(time.monotonic()-start,3),'all542_Mary_assets_exact':True,'all46_GT_assets_exact':True,'all_authored_inputs_and_both_registries_exact':True,'all44_after_restore_exact132e':True,'protected_population_dirty':False,'no_geometry_bake_export_masterhash_gate_changes':True,'external_reserve_only_bytes':floor,'native_gate_assertions_unchanged':True,'tmp_free_after':shutil.disk_usage('/tmp').free,'wholecheck_manual_preflight_PR_and_fullpublishedsmoke_pending':True};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
