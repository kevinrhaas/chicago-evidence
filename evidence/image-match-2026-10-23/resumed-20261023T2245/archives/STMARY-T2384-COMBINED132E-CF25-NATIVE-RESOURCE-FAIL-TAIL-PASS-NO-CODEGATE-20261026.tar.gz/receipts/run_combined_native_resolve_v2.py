from pathlib import Path
import os,sys,json,subprocess,hashlib,datetime,time,shutil,re,signal
os.sched_setaffinity(0,{2});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1',TMPDIR='/tmp/sm-n')
repo=Path('/tmp/st-mary-picture-20261025');app=repo/'chicago/4d';r=Path('/tmp/st-mary-runtime-20261025');out=r/'combined-native-resolve-v2';assert not out.exists();out.mkdir();floor=int(1.5*1024**3);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());prep=load(r/'combined-cf25-132e-v2/RESULT.json');latest=prep['HEAD'];gt=prep['MERGE_HEAD'];assert prep['native_contract_FULL202_required']
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==latest and git('rev-parse','MERGE_HEAD').decode().strip()==gt
family=load(r/'ff-20affa/PREPARED.json')['family542'];GT=load(r/'checked-GT23-snapshot.json');assert all(sha(app/p)==s for p,s in family.items());assert all(sha(repo/p)==v['sha256']for p,v in GT['files46'].items());assert all(sha(repo/p)==s for p,s in prep['authored_inputs_sha256'].items())
tracked=[p.decode()for p in git('ls-tree','-r','--name-only','-z',latest).split(b'\0')if p];binary=[p for p in tracked if p.lower().endswith(('.xlsx','.gz'))];xlsx=[p for p in binary if p.lower().endswith('.xlsx')];assert len(xlsx)==23 and len(binary)==44,(len(xlsx),len(binary));proc=subprocess.Popen(['git','cat-file','--batch'],cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE);baseline={}
for p in binary:
 proc.stdin.write((latest+':'+p+'\n').encode());proc.stdin.flush();h=proc.stdout.readline().decode().split();assert len(h)==3;data=proc.stdout.read(int(h[2]));assert proc.stdout.read(1)==b'\n';q=out/'baseline132e'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);baseline[p]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob':h[0]}
proc.stdin.close();assert proc.wait()==0;(out/'BASELINE44-XLSX-ALL-GZIP.json').write_text(json.dumps({'base':latest,'xlsx_count':len(xlsx),'all_binary':baseline},indent=2)+'\n')
binding={'HEAD':latest,'HEAD_tree':prep['HEAD_tree'],'MERGE_HEAD':gt,'MERGE_HEAD_tree':prep['MERGE_HEAD_tree'],'native_contract':'existing--resolve ownsLib142; pass145below requiresFULL202+secondpass+settledtail','authored_inputs':prep['authored_inputs_sha256'],'cpu':[2],'BLAS_OMP':1,'local_orchestration_resource_floor_bytes':floor,'native_gate_resource_assertions_unchanged':True};(out/'INPUTS.json').write_text(json.dumps(binding,indent=2)+'\n')
resources=[]
def checkspace(label):
 free=shutil.disk_usage('/tmp').free;resources.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':label,'tmp_free':free});(out/'RESOURCE-OBSERVATIONS.json').write_text(json.dumps(resources,indent=2)+'\n');assert free>=floor,('LOCAL_RESOURCE_FLOOR_STOP_NO_FILES_DELETED',label,free,floor);return free
def run(name,cmd):
 free=checkspace(name+' BEFORE');print(name,'START',datetime.datetime.now(datetime.timezone.utc).isoformat(),'FREE',free,flush=True);p=subprocess.Popen(cmd,cwd=app,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
 try:
  with(out/(name+'.log')).open('x')as log:
   for line in p.stdout:
    log.write(line);log.flush()
    if re.match(r'^\s*\[\d+/\d+\]',line):
     try:checkspace(name+' '+line.strip())
     except AssertionError:os.killpg(p.pid,signal.SIGTERM);p.wait();raise
  code=p.wait()
 finally:
  if p.poll()is None:os.killpg(p.pid,signal.SIGTERM);p.wait()
 (out/(name+'-result.json')).write_text(json.dumps({'command':cmd,'exit':code,'tmp_free_after':shutil.disk_usage('/tmp').free},indent=2)+'\n');assert code==0,(name,code);print(name,'CLOSED_PASS',flush=True)
start=time.monotonic();run('official-glessner-package-check',['python3','tools/recover_glessner_v4.py','--check']);run('native-resolve-FULL202',['node','tools/rederive.mjs','--resolve'])
assert not git('diff','--name-only','--diff-filter=U').strip(),'UNMERGED_REMAIN';text=(out/'native-resolve-FULL202.log').read_text();assert 'the last one moved nothing'in text and 'WARNING: the tail'not in text,text[-1500:];assert all(sha(app/p)==s for p,s in family.items());assert all(sha(repo/p)==v['sha256']for p,v in GT['files46'].items());assert all(sha(repo/p)==s for p,s in prep['authored_inputs_sha256'].items()),'AUTHORED_INPUT_CHANGED_DURING_NATIVE'
result={'status':'COMBINED_NATIVE_RESOLVE_FULL202_CYCLE_SETTLEDTAIL_PASS','HEAD':latest,'MERGE_HEAD':gt,'cpu':[2],'seconds':round(time.monotonic()-start,3),'all542_Mary_assets_exact':True,'all46_GT_assets_exact':True,'all_authored_inputs_and_both_registries_exact':True,'all_generated_conflicts_cleared_by_native':True,'native_tail_last_lap_moved_nothing':True,'all44_workbook_gzip_outside4d_scope_audit_and_pkg5_publish_pending':True,'no_bakes_masterhashes_geometry_or_gate_changes':True,'tmp_free_after':shutil.disk_usage('/tmp').free};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
