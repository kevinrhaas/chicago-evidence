from pathlib import Path
import subprocess,json,datetime,os,time,hashlib
os.sched_setaffinity(0,{1});out=Path('/workspace/shared/T2380-e81-moving-frames-cancelled-20261026');head='e81e1d2d2352f152498564eff61d0fdf4c29c7c6';rid=40278868761;jid=121427461789
assert not(out/'ONE-RERUN-REQUEST.json').exists(),'Never duplicate an accepted rerun request'
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
annotations=api('check-runs/'+str(jid)+'/annotations');assert any('exceeded the maximum execution time of 30m0s'in x['message']for x in annotations);(out/'confirmed-timeout-annotations.json').write_text(json.dumps(annotations,indent=2)+'\n')
runs=api('actions/workflows/chicago-4d-moving-frames.yml/runs?head_sha='+head+'&per_page=100')['workflow_runs'];assert len(runs)==1 and runs[0]['id']==rid and runs[0]['head_sha']==head and runs[0]['status']=='completed'and runs[0]['conclusion']=='cancelled'and runs[0]['run_attempt']==1
pr=api('pulls/1333');assert pr['state']=='open'and pr['draft']and pr['head']['sha']==head
(out/'NO-REPLACEMENT-BEFORE-RERUN.json').write_text(json.dumps({'runs':runs,'pr_head':pr['head']['sha'],'draft':pr['draft']},indent=2)+'\n')
request={'status':'ONE_EXISTING_RUN_RERUN_REQUEST_STARTING','run':rid,'head':head,'expected_attempt':2,'requested':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authority':'Root authorizes exactly one existing-run retry after confirmed timeout and no active/valid replacement; unchanged source/workflow/caps/assertions. Attempt1 CANCELLED remains notPASS.'};(out/'ONE-RERUN-REQUEST.json').write_text(json.dumps(request,indent=2)+'\n')
p=subprocess.run(['gh','api','repos/kevinrhaas/chicago/actions/runs/'+str(rid)+'/rerun','--method','POST'],capture_output=True,text=True);(out/'rerun-POST-stdout.log').write_text(p.stdout);(out/'rerun-POST-stderr.log').write_text(p.stderr);request['POST_exit']=p.returncode;request['status']='RERUN_REQUEST_ACCEPTED_NOT_RESULT'if p.returncode==0 else'RERUN_REQUEST_FAILED_DO_NOT_REPEAT';(out/'ONE-RERUN-REQUEST.json').write_text(json.dumps(request,indent=2)+'\n');assert p.returncode==0,p.stderr
observed=None
for _ in range(10):
 run=api('actions/runs/'+str(rid));assert run['head_sha']==head
 if run['run_attempt']==2:observed=run;break
 assert run['run_attempt']==1;time.sleep(1)
if observed:(out/'OBSERVED-ATTEMPT2.json').write_text(json.dumps(observed,indent=2)+'\n')
result={**request,'observed_attempt':observed['run_attempt']if observed else None,'observed_status':observed['status']if observed else'READINESS_NOT_YET_OBSERVED','native_workflow_unchanged':True,'new_matrix_dispatched':False,'source_or_assertion_changes':False};(out/'RERUN-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
