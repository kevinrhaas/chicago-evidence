Wolf Point Tavern's roof looked pale in the published scene beside the dark roof in the credited NYPL print. This selects a darker reconstructed tone for this tavern through a keyword-only LogDwelling option. The 1867 print is a retrospective labelled 1833; the colour choice makes no claim about pigment, weathering or exact July 1835 fabric.

Genuine builds refreshed all 82 canonical masters and their real web derivatives. The other 81 pairs stayed byte-identical. Wolf changes only its roof base colour; positions, normals, UVs, confidence, counts, roughness and all other material values remain exact. Shared finishes and other archetypes retain their defaults.

This also carries four reviewed smoke/placement fixes for the existing lighthouse glass, offset footprint origins and retained 1904 ranges. They are the exact checked repairs from `6a61ab6e`; renderer behaviour and native tolerances remain unchanged by those repairs.

**Original T-2386 remains open.** The required acceptance of all eight picture files/nine compositions is unfinished. The retained NYPL comparison has a provisional camera and an external UNREVIEWED match record. The separate poster's rights limitation is unchanged. This PR ships the bounded roof improvement and creates no follow-up ticket.

Validation:

- Real Blender 4.5.3 LTS and glTF-Transform 4.5.0 production; all 81 default master/web pairs independently proved byte-identical. After integration with dev `a575ddde`, every pair stayed exact and all 82 freshly computed native recipe hashes matched.
- The owning 61-step native tail reached fixed point, the complete 44-file workbook/gzip audit proved equality before restoring serialization-only differences, and the package tail/final publish passed. All 2,920 asset/registry files and 3,875 authored/source/people/generator controls stayed exact.
- Targeted mobile passed. Desktop normal/By Grade/Photos components completed before an agent interrupted the first desktop run; a fresh desktop run passed the remaining Sources, new liberty, both native doorway approaches, HTTP asset/maps, caps and error checks on identical source bindings. The interrupted run keeps that status. All browser children were reaped; these are appearance/contact checks, with no performance claim.
- Full source preflight: **1070 steps / 384 self-tests**, all three questions passed on tree `b5069cd71967e5632acdb533533592edb7697254`. Committed-head changelog, IDs and history checks passed on `4fe7d4baf3af163e6156a4b003656713f3b7560d`.

All **18 published renderer groups passed** on exact head `4fe7d4baf3af163e6156a4b003656713f3b7560d` (desktop 1280×800 and mobile 390×780; native raw logs bind checkout, stage, successful publish, positive assertion counts, zero failures and zero page errors). The matrix completed at 2026-10-26 09:35 UTC.

The PR stays **draft** because newer `dev` changes conflict with this branch. The ordinary hosted PR check has no run for this head; it is **not passed**. Integration and fresh applicable checks are still required. This matrix validates the stated head and its `a575ddde` base, and makes no claim about a later merged tree or original image-match completion.

Recovery, exact source/artifact bindings and preserved failures: [immutable evidence index 365](https://github.com/kevinrhaas/chicago-evidence/blob/eb95cd5e64fae31c34419045fc89101ceae17418/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md), including native/source recovery at index 359, the interrupted run at 361, and completed component coverage at 365.
