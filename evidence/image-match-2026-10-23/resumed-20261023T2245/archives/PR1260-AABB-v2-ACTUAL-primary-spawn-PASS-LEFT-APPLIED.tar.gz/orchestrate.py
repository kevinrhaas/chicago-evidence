from pathlib import Path
import os,subprocess,json,datetime,hashlib,sys
R=Path('/workspace/PR1260-aabb-v2-actual-20261024');A=Path('/tmp/chicago-log-integration/chicago/4d');P=Path('/tmp/PR1260-aabb-narrowphase-proposal-v2-school-20261024');B=Path('/workspace/PR1260-cells-ab-20261024');S=R/'ORCHESTRATION.json';r={'status':'RUNNING','pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':[]};env=os.environ.copy();env.update(TMPDIR='/workspace/tmp-t3081',PW_EXECUTABLE='/usr/bin/chromium');env['PATH']='/workspace/shared/tools/usr/bin:'+env.get('PATH','');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if S.exists():raise SystemExit('Existing status refused')
def save():S.write_text(json.dumps(r,indent=2)+'\n')
def stage(name,cmd):
 row={'stage':name,'command':cmd,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};r['stages'].append(row);save()
 with (R/(name+'.log')).open('w') as log:
  p=subprocess.Popen(cmd,cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT);row['pid']=p.pid;save();rc=p.wait()
 row.update(exit_code=rc,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 if rc:raise RuntimeError(name+' exited '+str(rc))
try:
 assert sha(P/'MANIFEST.json')=='981e4e55285ca9c1963cf640a94a1e378a90bea472e198dd3d520760fed14a5a'
 for f in json.loads((P/'MANIFEST.json').read_text())['files']:assert sha(P/f['path'])==f['sha256']
 baseline=json.loads((B/'BASELINE-BINDINGS.json').read_text())
 for f in baseline['files']:assert sha(A/f['path'])==f['sha256'],f['path']
 stage('apply-reviewed-v2',['python3',str(P/'apply-guard.py'),'--apply-after-root-grant']);r['applied']=True;save()
 stage('normal-publish',['bash','tools/publish.sh']);stage('readonly-mirror',['node','tools/check_published.mjs'])
 bindings={'status':'EXACT_TWO_PATH_REVIEWED_AABB_V2','source':[],'published':[]};proposal=json.loads((P/'SOURCE-BINDINGS.json').read_text())
 for f in baseline['files']:
  expected=proposal['authored'][f['path']]['candidate_sha256'] if f['path'] in proposal['authored'] else f['sha256'];assert sha(A/f['path'])==expected,f['path'];bindings['source'].append({'path':f['path'],'sha256':expected})
 new='renderers/web/js/batch-frustum-box.js';assert sha(A/new)==proposal['authored'][new]['candidate_sha256'];bindings['source'].append({'path':new,'sha256':sha(A/new)})
 mirror=A.parent.parent/'site/4d'
 for f in baseline['published']:
  q=mirror/f['path'];h=sha(q)
  if f['path']!='build.json':assert h==(proposal['authored']['renderers/web/js/buildings.js']['candidate_sha256'] if f['path']=='walk/js/buildings.js' else f['sha256']),f['path']
  bindings['published'].append({'path':f['path'],'sha256':h})
 assert sha(mirror/'walk/js/batch-frustum-box.js')==sha(A/new);bindings['published'].append({'path':'walk/js/batch-frustum-box.js','sha256':sha(mirror/'walk/js/batch-frustum-box.js')});(R/'ACTUAL-BINDINGS.json').write_text(json.dumps(bindings,indent=2)+'\n')
 stage('actual',['node','/tmp/PR1260-aabb-v2-actual-20261024/probe.mjs','--out',str(R/'actual'),'--execute'])
 actual=json.loads((R/'actual/STATUS.json').read_text());r['actual_spawn']=actual['measurement']['stats'];r['box_proof']=actual['measurement']['boundsNarrowPhase'];save()
 if not r['actual_spawn']['withinBudget']:raise RuntimeError('Required unchanged normal spawn budget failed; reject reviewed AABBv2')
 r['status']='ACTUAL_CLOSED_PENDING_VISUAL_INVARIANTS_REVIEW';r['exit_code']=0
except BaseException as e:
 r['status']='FAIL_STOPPED';r['error']=str(e);r['exit_code']=1;save()
 if r.get('applied'):
  try:
   bindings=json.loads((P/'SOURCE-BINDINGS.json').read_text())['authored'];assert all(sha(A/name)==v['candidate_sha256'] for name,v in bindings.items()),'Unexpected canonical edits; refuse revert'
   old=R/'buildings.before.js';assert sha(old)==bindings['renderers/web/js/buildings.js']['before_sha256'];(A/'renderers/web/js/buildings.js').write_bytes(old.read_bytes());(A/'renderers/web/js/batch-frustum-box.js').unlink();r['reverted_exact_two_paths']=True;save();stage('restore-normal-publish',['bash','tools/publish.sh']);stage('restore-readonly-mirror',['node','tools/check_published.mjs']);assert sha(A/'renderers/web/js/buildings.js')==sha(mirror/'walk/js/buildings.js')==sha(old);assert not (mirror/'walk/js/batch-frustum-box.js').exists();r['status']='REJECTED_AABB_EXACT_BASELINE_RESTORED'
  except BaseException as restore:r['restore_error']=str(restore)
finally:r['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(r));sys.exit(r['exit_code'])
