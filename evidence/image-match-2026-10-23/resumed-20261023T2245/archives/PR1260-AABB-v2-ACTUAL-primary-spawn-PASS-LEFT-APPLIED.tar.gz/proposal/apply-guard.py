from pathlib import Path
import hashlib,json,sys
A=Path('/tmp/chicago-log-integration/chicago/4d');R=Path(__file__).resolve().parent;b=json.loads((R/'SOURCE-BINDINGS.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,r in b['read_only_dependencies'].items():assert sha(A/name)==r['sha256'],name
for name,r in b['authored'].items():
 p=A/name
 if r.get('before')=='ABSENT':assert not p.exists(),name
 else:assert sha(p)==r['before_sha256'],name
pairs=[('renderers/web/js/buildings.js','buildings.candidate.js'),('renderers/web/js/batch-frustum-box.js','batch-frustum-box.js')]
for name,file in pairs:assert sha(R/file)==b['authored'][name]['candidate_sha256'],file
if '--apply-after-root-grant' not in sys.argv:print('PASS read-only guard; exactly two authored paths prepared; no canonical writes');raise SystemExit(0)
for name,file in pairs:(A/name).write_bytes((R/file).read_bytes())
print('APPLIED exactly two reviewed paths; normal publish and actual unchanged-budget/visual proof still owed')
