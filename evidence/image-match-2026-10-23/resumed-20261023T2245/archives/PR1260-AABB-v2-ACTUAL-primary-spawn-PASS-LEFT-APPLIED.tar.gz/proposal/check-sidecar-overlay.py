from pathlib import Path
import sys,tempfile,hashlib,json
sys.dont_write_bytecode=True
A=Path('/tmp/chicago-log-integration/chicago/4d');R=Path(__file__).resolve().parent;sys.path.insert(0,str(A/'tools'));import validate as V
shape=V.sidecar_shape();rows=[];validator=hashlib.sha256((A/'tools/validate.py').read_bytes()).hexdigest()
with tempfile.TemporaryDirectory(prefix='aabb-sidecar-overlay-',dir='/workspace/tmp-t3081') as d:
 root=Path(d)
 for p in sorted((A/'renderers').rglob('*.js')):
  if 'vendor' in p.parts:continue
  rel=p.relative_to(A);q=root/rel;q.parent.mkdir(parents=True,exist_ok=True);data=(R/'buildings.candidate.js').read_bytes() if str(rel)=='renderers/web/js/buildings.js' else p.read_bytes();q.write_bytes(data);rows.append({'path':str(rel),'sha256':hashlib.sha256(data).hexdigest()})
 p=root/'renderers/web/js/batch-frustum-box.js';p.write_bytes((R/'batch-frustum-box.js').read_bytes());rows.append({'path':'renderers/web/js/batch-frustum-box.js','sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 V.ROOT=root;V.sidecar_shape=lambda:shape
 positive=V.Report();V.check_sidecar_contract(positive);assert not positive.errors,positive.errors
 p=root/'renderers/web/js/negative-aabb-contract.js';p.write_text('const side = record.sidecar; const placement = side.placement; placement.not_a_compiled_field;\n')
 negative=V.Report();V.check_sidecar_contract(negative);assert any('placement.not_a_compiled_field' in e for e in negative.errors),negative.errors
report={'status':'PASS_UNCHANGED_NATIVE_SIDECAR_CONTRACT','validator_sha256':validator,'shape_sha256':hashlib.sha256(json.dumps(shape,sort_keys=True).encode()).hexdigest(),'positive_errors':positive.errors,'positive_notes':positive.notes,'negative_errors':negative.errors,'renderers':rows,'limits':'Exact native scanner and actual source shape; complete nonvendor renderer temporary overlay +two candidate paths. No allowances, native writers, browser or fullgate. Temporary overlay removed.'};(R/'SIDECAR-OVERLAY.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS unchanged native sidecar scanner candidate overlay; invented placement negative still fails')
