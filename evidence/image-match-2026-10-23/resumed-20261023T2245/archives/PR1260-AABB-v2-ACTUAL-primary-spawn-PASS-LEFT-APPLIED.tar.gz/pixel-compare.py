from pathlib import Path
from PIL import Image
import numpy as np,json
R=Path('/workspace/PR1260-aabb-v2-actual-20261024');B=Path('/workspace/PR1260-cells-ab-20261024/baseline-controls-v4');rows=[]
for n in ['normal-spawn','north-service','courtyard','roofline','aloft']:
 a=np.asarray(Image.open(B/f'{n}.png').convert('RGB'));b=np.asarray(Image.open(R/'actual'/f'{n}.png').convert('RGB'));d=np.abs(a.astype(np.int16)-b.astype(np.int16));m=np.any(d,axis=2);x2=800 if n=='normal-spawn' else 1100;reg=d[260:780,70:x2]
 rows.append({'view':n,'dimensions':list(a.shape),'all_pixels_changed':int(m.sum()),'all_max_channel_delta':int(d.max()),'disclosed_geometry_region':[70,260,x2,780],'region_pixels_changed':int(np.any(reg,axis=2).sum()),'region_max_channel_delta':int(reg.max()),'limits':'Original raw PNGs unchanged. Disclosed region is not a crop replacement or automatic acceptance. Native foliage, HUD/font timing and occlusion remain; offscreen geometry cannot be visually certified.'})
(R/'PIXEL-COMPARISON.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
