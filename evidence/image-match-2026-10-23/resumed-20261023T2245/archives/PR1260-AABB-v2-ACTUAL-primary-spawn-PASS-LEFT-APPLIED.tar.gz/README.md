# Closed bounded actual AABBv2 proof: primary spawn passes; three prior supplemental overruns remain

The approved exact two-path981e AABBv2 candidate reduces the same real Full1904 normalspawn from4,601,782 to4,589,658 triangles (−12,124), now10,342 below the unchanged4,600,000 cap. Raw drawCalls5113→5097 and rendererCalls321→319 also decrease; cap7800 unchanged. Cumulative `boxRejected:106` after boot/native spawn sequence proves active safe guard(s), not106 rejections per frame or a per-batch eligibility count. Exact approved Full spatialCells=null integration/source bytes are bound. Per-batch private proof state is not exposed; no CDP attribution or new profiling was performed.

The exact approved two authored paths were left applied and root received CLEAR after all processes stopped. New source hashes: buildings.js9bbabfdcdf0ade6cd4edf161b9fe120afcc4332500b92f268461341495a9ec04, batch-frustum-box.js3baf84f8f26ce3410691b40bd18a22a302c74c38daae606d84a1800d62736217. Existing coalescer,4m×2m partition, assets/data, budgets, pose, tier and quality remain exact. This bounded experiment is not fullstage14, fullpreflight/mobile gate, production acceptance or an image match.

## Frozen inputs and execution

Root reviewed/approved proposal manifest981e4e55285ca9c1963cf640a94a1e378a90bea472e198dd3d520760fed14a5a, corrected from immutablef955. The complete reviewed proposal is copied verbatim under proposal/. Original2m rejection and source-bound4m baseline remain immutablec297a0fcff6e013f854160e6f7538374732a84d6cf0b5091ce699f26aceeda36 at `/workspace/PR1260-cells-ab-20261024` and private evidence commit5db495c0c79d5bb23a36c139f1d59b0162988b42. Proposal-only timepoints are privately saved at828b171eefa4f12d86e63a9b319fae32c93ce7b5. No baseline boot or observer redesign was repeated.

BASELINE-REUSE.json verifies every recorded c297 source/asset hash and exact original v4 stand helper. The native probe/observer sequence is unchanged; the sole external probe addition reads cumulative boxRejected, detail, coalescing and batch count into the saved initial measurement. The initial stats save precedes all four supplemental stands. Guarded apply, NORMAL tools/publish.sh and readonly check_published all exit0. ACTUAL-BINDINGS.json records candidate source/mirror/asset hashes. Root's integrated state is public H3460622123… plus its resolved latestdev60 Wheeler merge; HEAD alone does not describe the uncommitted integrated source/assets. Original baseline metadata and incoming files remain bound by c297.

ORCHESTRATION.json preserves commands/PIDs/timestamps/exits and exact two-path rollback guard. Actual probe/browser/server/orchestrator all completed exit0 and stopped before CLEAR. No rollback was needed. Root then regained exclusive heavy ownership for owed normal preflight/native gates. This packet never reads future root gate outputs.

## Authoritative raw native counts

Raw drawCalls is native driverDraws (Three calls plus retained multi-draw entries); rendererCalls is Three info.render.calls. Physical GL API invocations are not separately counted. All current raw drawCalls remain inside7800.

|View|Baseline drawCalls/rendererCalls/triangles|AABBv2 drawCalls/rendererCalls/triangles|Triangle delta|Native budget verdict|
|---|---:|---:|---:|---|
|Normal spawn|5113/321/4,601,782|5097/319/4,589,658|−12,124|FAIL→PASS|
|North/service|7179/318/3,864,020|7160/318/3,860,138|−3,882|PASS→PASS|
|Courtyard|4449/504/4,981,514|4426/500/4,946,601|−34,913|FAIL→FAIL|
|Roofline|5443/316/4,644,199|5441/315/4,609,762|−34,437|FAIL→FAIL|
|Aloft|4160/428/5,274,189|4144/426/5,264,822|−9,367|FAIL→FAIL|

The three original supplemental triangle overruns remain actual failed-budget observations, despite improving; no blanket stand-PASS claim. COMPARISON.json records43/43 focused checks pass: required initialspawn budget, no new/worsened supplemental cap failure, exact asset/stage/input/helper bindings, original spawn pose and picks, identical camera/projection/near/quality/DPR1/1280×800, complete bounds/confidence/body fields, Glessner feet/matrix, source geometry1,385,233triangles/3011instances and the same3transparent roof instances. No repartition, decimation or source attribute edit. All four new colour/shadow/pick-extra observer reconciliations are exact under the original v4 formula. Actual loaded Kimball HTTP-body hash matches its published source; other Glessner/Wheeler asset bytes are bound at source/mirror with native resource/census evidence, not a claim of copied full HTTP bodies.

Page/HTTP/unexpected-request/cleanup errors are0. One raw people.json net::ERR_ABORTED remains verbatim and is classified by the existing native smoke policy exactly as in the reused baseline. No new request allowlist/filter, counter or assertion change. The earlier strict abort failure and observer attempts remain in their original archived packets, not erased.

## Direct visual review and timing limitations

All five new original PNGs and the five frozen baseline views were directly inspected. No lost visible house/facade/opening/stair/courtyard tower/roof ridge/plane/chimney or shadow content was detected. Original roof blending census, source geometry and physical bounds are exact. Native foreground trees/foliage remain; the roofline view is substantially obscured and the aloft house is near the lower screen edge. Offscreen/occluded geometry is not visually certified. No extra views, hidden buildings, suppressed vegetation or camera/asset changes were introduced.

Raw pixels are NOT equal. PIXEL-COMPARISON.json retains all differing-pixel counts, including substantial foliage/roofline differences, plus explicitly disclosed central/lower region metrics. HUD/fonts/target timing and normal scene animation were not normalized away. No crop/replacement evidence or automatic pixel acceptance. The finding is bounded direct visual review plus exact geometry/physical/source proofs, not pixel identity.

Single end-to-spawn elapsed131.349s versus baseline146.578s includes software boot/welcome/navigation/picks and is not an isolated boot/hardware speedup. Single native step submitMs: service36.6 vs25.5; courtyard31.0 vs22.2; roofline24.9 vs33.8; aloft34.3 vs39.5. Two observations increase and two decrease. This is JS/software submission timing, not GPU frame time or a tested pacing threshold. Actual phone/performance/pacing acceptance remains owed under normal gates. This packet proves reduced submitted work and the unchanged initial budget outcome, not universal performance improvement.

Final focused verdict: initialspawn PASS with unchanged caps, exact focused invariants and no new/worsened submitted-work cap failure; three preexisting supplemental triangle failures retained. Approved two-path candidate remains applied for root's normal full preflight and published mobile/desktop gates. Original image tickets and source-camera acceptance remain unchanged/open; no rights/flag/data update or PR/merge completion is claimed here.
