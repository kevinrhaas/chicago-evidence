from pathlib import Path
import json,math,datetime
r=Path('/tmp/chicago-green-tree-integration/chicago/4d');h=Path('/workspace/T2376-annex-20261029')
j=json.loads((r/'data/structures/versions/green_tree_tavern/andreas-reading.json').read_text());ph=j['phases'][0];g=ph['form']['enclosed_left_annex']['value'];place=json.loads((r/'data/sidecars/1835/green_tree_tavern.json').read_text())['placement']
def world(u,v,p=place):
 th=math.radians(p.get('rotation_deg',0));cs,sn=math.cos(th),math.sin(th)
 return p['local_e']+u*cs+v*sn,p['local_n']-u*sn+v*cs
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def edges(p):return list(zip(p,p[1:]+p[:1]))
def inside(q,p):
 x,y=q;v=False
 for a,b in edges(p):
  if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:v=not v
 return v
def pointseg(p,a,b):
 dx,dy=b[0]-a[0],b[1]-a[1];t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy or 1)))
 return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)
def distance(a,b):
 if any(inside(p,b)for p in a)or any(inside(p,a)for p in b):return 0.
 for p,q in edges(a):
  for v,w in edges(b):
   if cross(p,q,v)*cross(p,q,w)<0 and cross(v,w,p)*cross(v,w,q)<0:return 0.
 return min([pointseg(p,v,w)for p in a for v,w in edges(b)]+[pointseg(p,v,w)for p in b for v,w in edges(a)])
parts=[];x=max(v[0]for v in ph['footprint']['polygon']);front=max(v[1]for v in ph['footprint']['polygon'])-g['front_setback_m']
for name in ['shoulder','connector','boarding_range']:
 v=g[name];x1=x+v['span_m'];f=front+v.get('front_set_out_m',0);a=f-v['depth_m'];parts.append({'part':name,'polygon':[world(x,a),world(x1,a),world(x1,f),world(x,f)]});x=x1
rows=[]
for p in (r/'data/sidecars/1835').glob('*.json'):
 sc=json.loads(p.read_text());pos=sc.get('placement',{});poly=sc.get('footprint',{}).get('polygon',[])
 if sc.get('id')=='green_tree_tavern' or pos.get('local_e')is None or pos.get('local_n')is None or len(poly)<3:continue
 pp=[world(u,v,pos)for u,v in poly]
 for part in parts:rows.append({'other':sc.get('id',p.stem),'part':part['part'],'distance_m':distance(part['polygon'],pp)})
rows.sort(key=lambda x:x['distance_m']);result={'status':'PRELIMINARY_EXACT_DECLARED_ANNEX_GROUND_POLYGONS_AGAINST_CURRENT_CANONICAL_NEIGHBOR_FOOTPRINTS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parts':parts,'closest':rows[:12],'intersections':[x for x in rows if x['distance_m']==0],'limits':'Canonical neighbor footprint polygons only; actual neighbor GLB appendages, streets/walks, doors, roof overhangs and published app still owed. No corridor line used or moved.'}
(h/'PRELIMINARY-NEIGHBOR-CLEARANCE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='parts'},indent=2))
