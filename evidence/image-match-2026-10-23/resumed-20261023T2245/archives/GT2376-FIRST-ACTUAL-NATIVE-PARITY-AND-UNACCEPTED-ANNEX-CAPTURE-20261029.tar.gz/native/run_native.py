from pathlib import Path
import sys,json,importlib.util,hashlib,time,datetime
P=Path('/workspace/T2376-annex-20261029/native');A=Path('/tmp/chicago-green-tree-integration/chicago/4d');sys.path.insert(0,str(A/'generators'));import emit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs=json.loads((P/'INPUTS.json').read_text());rows=[]
def use(label):
 for name in ['frame_tavern_params','frame_tavern']:
  full='archetypes.'+name;spec=importlib.util.spec_from_file_location(full,P/'inputs'/label/(name+'.py'));m=importlib.util.module_from_spec(spec);sys.modules[full]=m;spec.loader.exec_module(m)
 emit.ARCHETYPES['frame_tavern']=(sys.modules['archetypes.frame_tavern_params'].from_phase,sys.modules['archetypes.frame_tavern'].build)
for label in ['old']:
 use(label);target=P/(label+'25');target.mkdir(exist_ok=True)
 for e in inputs['family']:
  record=Path(e['record']);assert sha(record)==e['record_sha256'];r=json.loads(record.read_text());ph=next(x for x in r['phases']if x['id']==e['phase']);dest=target/e['asset'];t=time.monotonic();made=emit.emit_structure(r,ph,'frame_tavern',dest,bake=True,ao=False)
  row={'label':label,'asset':e['asset'],'seconds':time.monotonic()-t,'sha256':sha(dest),'bytes':dest.stat().st_size,'triangles':made.tris,'exact_current_master':sha(dest)==e['current_master_sha256']};rows.append(row);print(json.dumps(row),flush=True)
use('candidate')
# The real production writer refreshes every current family recipe and the new
# optional version, rather than hand-stamping a manifest after a diagnostic.
ids=sorted({json.loads(Path(e['record']).read_text())['id']for e in inputs['family']})
import build as production
saved_argv=sys.argv[:];sys.argv=['blender','--','--only',','.join(ids),'--wrote',str(P/'PRODUCTION-WROTE.txt')]
t=time.monotonic();code=production.main();sys.argv=saved_argv;assert code==0;production_seconds=time.monotonic()-t
for e in inputs['family']:
 assert (P/'old25'/e['asset']).read_bytes()==Path(e['current_master']).read_bytes(),e['asset']+' new default changed'
 assert sha(Path(e['record']))==e['record_sha256'] and sha(Path(e['current_master']))==e['current_master_sha256']
 rows.append({'label':'actual_official_production','asset':e['asset'],'sha256':sha(Path(e['current_master'])),'bytes':Path(e['current_master']).stat().st_size,'exact_current_master':True})
trials=[]
for name in ['prototype-initial']:
 r=json.loads((P/'inputs/candidate'/(name+'.json')).read_text());dest=P/'trials'/name/(r['id']+'__'+r['phases'][0]['id']+'.glb');t=time.monotonic();made=emit.emit_structure(r,r['phases'][0],'frame_tavern',dest,bake=True,ao=False);trials.append({'trial':name,'path':str(dest),'seconds':time.monotonic()-t,'sha256':sha(dest),'bytes':dest.stat().st_size,'triangles':made.tris})
dest=A/'assets/gltf/versions/green_tree_tavern/andreas-reading/green_tree_tavern__frame_1833.glb';trials.append({'trial':'andreas-reading','path':str(dest),'sha256':sha(dest),'bytes':dest.stat().st_size,'production_seconds':production_seconds})
result={'status':'ACTUAL_25_DEFAULT_NATIVE_BYTE_PARITY_OFFICIAL_FAMILY_AND_NEW_VERSION_PRODUCTION','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows,'all25_old_new_master_bytes_exact':True,'all25_current_committed_master_bytes_exact':all(x['exact_current_master']for x in rows),'actual_production_ids':ids,'trials':trials,'limits':'No WEB, camera, image match, footprint/neighbor/ground or published app acceptance. Preliminary native-feet relief for revised trial is0.292m; actual app placement and image review remain owed.'};(P/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='rows'}),flush=True)
