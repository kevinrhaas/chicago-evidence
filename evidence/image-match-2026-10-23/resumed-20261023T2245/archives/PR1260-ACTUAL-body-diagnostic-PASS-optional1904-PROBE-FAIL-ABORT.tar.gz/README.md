# Actual body-readback proofs PASS; optional1904 probe retains an abort failure

Independent review approved corrected proposal v2, frozen manifest `57cfda0dce707763ab67f091b7b5e4a99052c6f964c264a04da1f376963fdeba`. Its original18 and corrected38 positive/negative/static CPU controls were independently rerun on separate copies, leaving canonical/frozen inputs untouched. The initial caller omitted declared-sign records without numeric wall heights; v2 includes numeric wall OR declared appendage, and the helper requires a finite positive numeric wall. Missing/string/false/NaN/Infinity controls now fail. No global threshold or unrelated guard was removed.

The renderer reads only glTF original material roles/stored positions and the selected engine-neutral JSON declaration. Its narrow section envelopes are a bounded read-only measurement contract; they create no mesh, shader or placement. Roof/chimney/unknown geometry stays in the measured body unless it fits the explicit exterior-sign role/pose bounds. Complete bounds still feed existing size/clamp/absurd/placement/ground guards; the wall comparison retains its original0.9 floor and2.6*wall+3 ceiling. Future unsupported appendage/kit changes require a reviewed contract and new proof.

Root adopted v2 on the resolved, uncommitted dev8e working-tree integration. This proof binds exact file hashes, not a claim that uncommitted code already exists in the6bf HEAD commit. The normal publisher exited0. Post-native source/asset binding verified before browsers; published helper/buildings bytes match the bound source. Captured source modules and all test/orchestration code are included.

## Actual mobile and desktop body proof

Fresh actual published1835 boots used mobile390×780/light/DPR2 and desktop1280×800/full/DPR1. A read-only CDP breakpoint at the native helper entry captured its actual normalized stored-position samples/roles and quantization step, then resumed unmodified code. The live `instanceBounds().body` exactly equals replay through the actual served helper on those captured samples. Negative mutations ran on cloned data only, through the extracted bound live smoke predicates; no geometry was uploaded, hidden, moved or rewritten by a mutation.

Both viewports passed19 controls each and measured:

- Complete size `[7.440020230181192,11.022312130283224,10.342621762537085]`m, unchanged and still pole-inclusive.
- Occupied body height5.401596451102532m against unchanged9.76m cap for2.6m walls.
-3054 retained body samples,328 excluded bounded sign samples,782 occupied-log samples; quantization step0.0003236620798791139m.
- Only Wolf has optional body metadata. Exact14 retained review notices match their frozen IDs/messages. Owner ruling preserves flags/prose without a new consultation permission or release block.
- Zero page, HTTP, failed-request, CDP or cleanup errors. Actual HTTP-loaded Wolf compressed GLB SHA `340b5339aed7a0b1f75af7bade2bca25d16186133b6663a3823d509fdcc049cd` matches source and mirror.

Both scene screenshots were directly inspected. Their recorded normal native fly pose reuses the prior unoccluded Wolf inspection angle; it changes no canonical/reference camera or scene visibility. Stored-sample JSON, live bounds, all19 replay results and exact source/mirror/asset hashes are included. This focused proof is not the full native stage3–4 smoke gate or an image-match verdict.

## One optional normal1904 spawn probe

One fresh desktop1280×800/DPR1 `/1904/` boot followed the source's initial stage14 sequence: ordinary entry/two animation frames, street-readout excursions with exact home restore, then Glessner-front picks before `api.stats`. No tier, budget or arbitrary camera adjustment was made. Native Full normal spawn was exact at `(1410.12,-3218.01)`, bearing264.94deg.

It measured **5113 calls and4,599,770 triangles**, within the unchanged7,800-call/4,600,000-triangle ceiling by230 triangles. This is721 triangles below the parent's recorded old6bf result, matching the incoming Kimball geometry reduction. Actual Kimball HTTP SHA `804cd212d841d0be3acd7976f47a6a0cafb655775938666f69027f7ed9d74e92` was200 and matched source/mirror. Loader findings, page errors, HTTP errors and cleanup errors were zero. Its screenshot was directly inspected.

**The optional probe and enclosing orchestration retain FAIL/exit1** because one unfiltered request failed: `/data/sidecars/1904/people.json`, `net::ERR_ABORTED`. That is separate from the positively measured in-budget frame; it is not filtered or rerun to obtain a green result.

Read-only source analysis: main.js4523–4537 has a people-directory HEAD `ask()` and optional GET `load()`; `ask()` is scheduled immediately after ready at5490. No AbortController occurs in these paths or inspected popup/People/Inspect files. The recorded event lacks method/timestamp, so its exact HEAD/GET/cancellation timing is unproven. The normal smoke's requestfailed handler at1759–1761 already excludes all ERR_ABORTED; therefore its old errors0 does not prove this abort was absent. Both servers use the same static-file streaming pattern. No abort filter, source edit or further browser was added here.

Every browser/context/server stopped before root's preflight03 began; root is now the sole heavy owner. All original failed/successful receipts remain verbatim. No full stage3–4/14, model/source/flag mutation, reference-camera enrollment or image-match acceptance is claimed. Full stage3–4 remains owed on the new committed head.
