// Read-only source/data binder; call --with-inputs only after root's native writer finishes.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {execFileSync} from 'node:child_process';
const args=process.argv.slice(2),arg=(k,d)=>{const i=args.indexOf(k);return i<0?d:args[i+1];};const app=arg('--app','/tmp/chicago-log-integration/chicago/4d'),out=arg('--out',null);if(!out)throw Error('--out required');
if(fs.existsSync(out))throw Error('Refusing existing binder output');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const proposal='/tmp/PR1260-wall-body-diagnostic-proposal-v2',guards=JSON.parse(fs.readFileSync(path.join(proposal,'replacement-guards.json')));
if(sha(fs.readFileSync(path.join(proposal,'MANIFEST.json')))!=='57cfda0dce707763ab67f091b7b5e4a99052c6f964c264a04da1f376963fdeba')throw Error('Frozen proposal v2 drift');
const paths=['renderers/web/js/building-body-bounds.js','renderers/web/js/buildings.js','tools/smoke_renderer.mjs'];
const files=paths.map(p=>{const b=fs.readFileSync(path.join(app,p));return {path:p,bytes:b.length,sha256:sha(b)};});
for(const p of paths.slice(0,2))if(files.find(x=>x.path===p).sha256!==guards[p].after_sha256)throw Error('Adopted helper/buildings differs from reviewed v2: '+p);
const smoke=fs.readFileSync(path.join(app,'tools/smoke_renderer.mjs'),'utf8'),candidate=fs.readFileSync(path.join(proposal,'candidate/tools/smoke_renderer.mjs'),'utf8');
const extract=s=>({isClaimed:s.match(/const claimed = scale\.perStructure\.filter\((.*?)\);/s)?.[1],isOff:s.match(/const offClaim = claimed\.filter\(\(s\) => \{([\s\S]*?)\n    \}\);/)?.[1]});
const predicates=extract(smoke);if(!predicates.isClaimed||!predicates.isOff||JSON.stringify(predicates)!==JSON.stringify(extract(candidate)))throw Error('Live smoke height predicates differ from approved v2');
const git=(...a)=>execFileSync('git',['-C',app,...a],{encoding:'utf8'});
const result={status:args.includes('--with-inputs')?'FROZEN_POST_NATIVE_SOURCE_INPUT_BINDINGS':'FROZEN_CODE_BINDINGS_ONLY_NATIVE_INPUTS_PENDING',app,head:git('rev-parse','HEAD').trim(),git_status:git('status','--porcelain'),unmerged:git('diff','--name-only','--diff-filter=U').trim(),files,predicates,proposal_manifest_sha256:'57cfda0dce707763ab67f091b7b5e4a99052c6f964c264a04da1f376963fdeba',limits:'Read-only binder; no publish/browser/generator/fullgate. Dirty resolved merge may be intentional; exact adopted three code hashes are the proof identity.'};
if(result.unmerged)throw Error('Unresolved merge paths remain');
if(args.includes('--with-inputs')){const inputs=['assets/gltf/wolf_point_tavern__log_frame_1828.glb','assets/web/wolf_point_tavern__log_frame_1828.glb','data/sidecars/1835/wolf_point_tavern.json'];result.inputs=inputs.map(p=>{const b=fs.readFileSync(path.join(app,p));return {path:p,bytes:b.length,sha256:sha(b)};});const web=result.inputs.find(x=>x.path.startsWith('assets/web')).sha256;if(web!=='340b5339aed7a0b1f75af7bade2bca25d16186133b6663a3823d509fdcc049cd')throw Error('Wolf web asset changed from reviewed actual bytes');}
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,out,files:files.map(x=>({path:x.path,sha256:x.sha256}))},null,2));
