// Focused published proof. CDP reads arguments to unmodified native code; mutations use clones only.
import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import crypto from 'node:crypto';import {createRequire} from 'node:module';
import {checkReviewNotices} from '/tmp/T3081-published-qa-v4-20261024/review-notices.mjs';
const args=process.argv.slice(2),opt=(k,d)=>{const i=args.indexOf(k);return i<0?d:args[i+1];};
const bindingFile=opt('--bindings',null),out=opt('--out',null),viewport=opt('--viewport','mobile');if(!bindingFile||!out||!['mobile','desktop'].includes(viewport))throw Error('--bindings --out and mobile|desktop viewport required');
if(!args.includes('--execute')){console.log(JSON.stringify({status:'PREPARED_NOT_EXECUTED',bindingFile,out,viewport,limits:'After root native CLEAR and explicit grant: normal publish + input binder, then two sequential published boots. No render/data mutation; read-only CDP argument capture and cloned replay only.'},null,2));process.exit(0);}
const binding=JSON.parse(fs.readFileSync(bindingFile));if(binding.status!=='FROZEN_POST_NATIVE_SOURCE_INPUT_BINDINGS')throw Error('Post-native input binding required');
if(fs.existsSync(out))throw Error('Refusing existing output');fs.mkdirSync(out,{recursive:true});
const app=binding.app,site=path.resolve(app,'../../site/4d'),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),id='wolf_point_tavern',asset='wolf_point_tavern__log_frame_1828.glb';
const expectedNotices=JSON.parse(fs.readFileSync('/tmp/T3081-published-qa-v4-20261024/models.json')).scene_review_notices;
const report={status:'RUNNING',started_at:new Date().toISOString(),pid:process.pid,viewport,binding_sha256:sha(fs.readFileSync(bindingFile)),captures:[],page_errors:[],http_errors:[],request_failures:[],asset_responses:[],cdp_errors:[],limits:'Actual published full/body/stored-position readback; replay mutates cloned samples only. No geometry, data, asset, camera-reference or flag edits; not full stage3-4 or image-match acceptance.'};
const save=()=>{fs.writeFileSync(path.join(out,'STATUS.next.json'),JSON.stringify(report,null,2)+'\n');fs.renameSync(path.join(out,'STATUS.next.json'),path.join(out,'STATUS.json'));};save();
let browser,context,server,cdp,error;const tasks=[],inflight=new Map();
try{
 for(const f of [...binding.files,...binding.inputs])if(sha(fs.readFileSync(path.join(app,f.path)))!==f.sha256)throw Error('Bound source/input drift: '+f.path);
 for(const f of binding.files.filter(x=>x.path.startsWith('renderers/web/js/'))){const p=path.join(site,'walk/js',path.basename(f.path));if(sha(fs.readFileSync(p))!==f.sha256)throw Error('Stale published helper/buildings: '+p);}
 const expectedWeb=binding.inputs.find(x=>x.path.startsWith('assets/web/')).sha256;report.expected_web_sha256=expectedWeb;
 if(sha(fs.readFileSync(path.join(site,'data/gltf',asset)))!==expectedWeb)throw Error('Stale published Wolf web');
 report.mirror_build=JSON.parse(fs.readFileSync(path.join(site,'build.json')));
 const helperSource=fs.readFileSync(path.join(site,'walk/js/building-body-bounds.js'),'utf8'),entryLine=helperSource.split('\n').findIndex(s=>s.includes('const attrs = sidecar'));
 if(entryLine<0)throw Error('Exact native classifier entry line not found');
 const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.glb':'model/gltf-binary','.wasm':'application/wasm','.ktx2':'image/ktx2'};
 server=http.createServer((req,res)=>{try{const u=new URL(req.url,'http://localhost');let p=path.resolve(site,'.'+decodeURIComponent(u.pathname));if(p!==site&&!p.startsWith(site+path.sep)){res.writeHead(403);res.end();return;}if(fs.statSync(p).isDirectory())p=path.join(p,'index.html');res.writeHead(200,{'Content-Type':types[path.extname(p)]||'application/octet-stream'});fs.createReadStream(p).pipe(res);}catch{res.writeHead(404);res.end('missing');}});await new Promise(ok=>server.listen(0,'127.0.0.1',ok));
 const require=createRequire('/workspace/__qa__.mjs'),{chromium}=require('playwright');browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE||'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 const vp=viewport==='mobile'?{width:390,height:780}:{width:1280,height:800};context=await browser.newContext({viewport:vp,deviceScaleFactor:viewport==='mobile'?2:1,isMobile:false,hasTouch:viewport==='mobile'});const page=await context.newPage();page.setDefaultTimeout(240000);
 page.on('pageerror',e=>report.page_errors.push(String(e)));page.on('request',r=>inflight.set(r,r.url()));page.on('requestfinished',r=>inflight.delete(r));page.on('requestfailed',r=>{inflight.delete(r);report.request_failures.push({url:r.url(),failure:r.failure()});});
 page.on('response',r=>{if(r.status()>=400)report.http_errors.push({url:r.url(),status:r.status()});if(r.url().split('?')[0].endsWith('/data/gltf/'+asset))tasks.push((async()=>{const b=await r.body();report.asset_responses.push({url:r.url(),status:r.status(),bytes:b.length,sha256:sha(b)});})().catch(e=>report.request_failures.push({url:r.url(),failure:String(e)})));});
 cdp=await context.newCDPSession(page);await cdp.send('Debugger.enable');const {breakpointId}=await cdp.send('Debugger.setBreakpointByUrl',{urlRegex:'building-body-bounds\\.js(?:\\?.*)?$',lineNumber:entryLine});
 const captured=[];let pausedTasks=[];
 cdp.on('Debugger.paused',event=>{const t=(async()=>{try{
  if(!event.hitBreakpoints?.includes(breakpointId))throw Error('Unexpected debugger pause');
  const frame=event.callFrames[0];const value=await cdp.send('Debugger.evaluateOnCallFrame',{callFrameId:frame.callFrameId,expression:'JSON.stringify({sidecar,samples,quantStep})',returnByValue:true});
  if(value.exceptionDetails)throw Error(JSON.stringify(value.exceptionDetails));const fixture=JSON.parse(value.result.value);
  if(fixture.sidecar?.id!==id)throw Error('Unexpected declared body sample record: '+fixture.sidecar?.id);
  captured.push(fixture);report.captures.push({record:fixture.sidecar.id,samples:fixture.samples.length,quantStep:fixture.quantStep,source_url:frame.url,entry_line:frame.location.lineNumber});save();
 }catch(e){report.cdp_errors.push(String(e));save();}finally{await cdp.send('Debugger.resume').catch(e=>report.cdp_errors.push(String(e)));}})();pausedTasks.push(t);});
 await page.goto('http://127.0.0.1:'+server.address().port+'/walk/',{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:240000,polling:1000});
 const boot=await page.evaluate(()=>({ready:__chicago4d.ready,error:__chicago4d.error,scene:__chicago4d.scene?.id}));report.boot=boot;if(!boot.ready||boot.error||String(boot.scene)!=='1835')throw Error('Native boot failed');
 await page.waitForFunction(()=>__chicago4d.welcome?.state==='welcome',null,{timeout:240000});
 await page.evaluate(async detail=>{const a=__chicago4d;await a.setDetail(detail);if(!a.welcome.enter('spawn'))throw Error('Native entry failed');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.renderer.setAnimationLoop(null);a.setAnimationHold(true);a.step();},viewport==='mobile'?'light':'full');
 await Promise.all(pausedTasks);await cdp.send('Debugger.removeBreakpoint',{breakpointId});await cdp.send('Debugger.disable');
 if(report.cdp_errors.length||!captured.length)throw Error('Actual stored-position capture failed');const fixture=captured[captured.length-1];
 fs.writeFileSync(path.join(out,'STORED-SAMPLES.json'),JSON.stringify(fixture)+'\n');report.stored_samples_sha256=sha(fs.readFileSync(path.join(out,'STORED-SAMPLES.json')));
 report.actual=await page.evaluate(id=>{const a=__chicago4d,bounds=a.buildings.instanceBounds();return {full:bounds[id],sidecar:a.registry.get(id).sidecar,declared_body_ids:Object.keys(bounds).filter(id=>bounds[id].body!=null),registry_review_ids:[...a.registry.values()].filter(r=>r.sidecar?.review_required).map(r=>r.sidecar.id).sort(),raw_problems:a.problems};},id);
 const actual=report.actual;report.review_notices=checkReviewNotices(expectedNotices,actual.registry_review_ids,actual.raw_problems);if(report.review_notices.failures.length)throw Error(report.review_notices.failures.join('\n'));
 if(JSON.stringify(actual.declared_body_ids)!==JSON.stringify([id])||!actual.full.body?.valid)throw Error('Wrong/missing actual body diagnostics');
 report.replay=await page.evaluate(async({fixture,predicates,actual})=>{
  const {buildingBodyBounds:measure}=await import('/walk/js/building-body-bounds.js');const clone=x=>structuredClone(x),claimed=new Function('return ('+predicates.isClaimed+');')(),off=new Function('s',predicates.isOff),doc=fixture.sidecar,samples=fixture.samples,q=fixture.quantStep;
  const original=JSON.stringify(fixture),body=measure(doc,samples,q);if(JSON.stringify(body)!==JSON.stringify(actual.full.body))throw Error('CDP stored-sample replay differs from actual instanceBounds body');
  const pass=(s,points=samples,step=q,forceMissing=false)=>{const b=forceMissing?null:measure(s,points,step),row={declaredAppendage:s.attributes?.sign_pole_set_out?.value!=null,wallHeight:s.attributes?.wall_height_m?.value,body:b,size:actual.full.size};return {included:claimed(row),off:claimed(row)&&off(row),valid:b?.valid??false,body:b};};
  const controls=[];const require=(name,ok)=>{if(!ok)throw Error('Replay control failed: '+name);controls.push({name,pass:true});};
  require('actual live numeric body passes',!pass(doc).off&&body.valid);
  require('full pole-inclusive height still fails original unchanged wall cap',actual.full.size[1]>doc.attributes.wall_height_m.value*2.6+3);
  require('missing body readback fails declared smoke row',pass(doc,samples,q,true).off);
  for(const [name,value] of [['missing',undefined],['string','2.6'],['false',false],['NaN',NaN],['Infinity',Infinity]]){const s=clone(doc);if(value===undefined)delete s.attributes.wall_height_m;else s.attributes.wall_height_m.value=value;const got=pass(s);require(name+' wall retained and rejected',got.included&&got.off&&!got.valid);}
  const noDecl=clone(doc);delete noDecl.attributes.sign_pole_set_out;require('missing declaration keeps original full-bounds rejection',pass(noDecl).off);
  const malformed=clone(doc);malformed.attributes.sign_pole_set_out.value.board_wh=[1.6,NaN];require('malformed declaration rejected',pass(malformed).off);
  const tall=clone(doc);tall.attributes.sign_pole_set_out.value.head_xyz[2]=15;require('unsupported oversized declaration rejected',pass(tall).off);
  const isPole=s=>(s.role==='log'&&s.point[0]>5.2&&-s.point[2]>5.2)||['sign','paint'].includes(s.role)||(s.role==='dark'&&s.point[1]>7);
  const remap=fn=>samples.map(s=>({role:s.role,point:fn(s)}));
  require('missing occupied body rejected',pass(doc,samples.filter(isPole)).off);
  require('collapsed body with intact pole rejected',pass(doc,remap(s=>isPole(s)?s.point:s.point.map((v,i)=>i===1?v*.1:v))).off);
  require('2m clamped body with intact pole rejected',pass(doc,remap(s=>isPole(s)?s.point:s.point.map(v=>Math.max(-1,Math.min(1,v))))).off);
  require('inflated body with intact pole rejected',pass(doc,remap(s=>isPole(s)?s.point:s.point.map((v,i)=>i===1?v*4:v))).off);
  require('unknown roles do not exempt high geometry',pass(doc,samples.map(s=>({...s,role:'unknown'}))).off);
  require('undeclared high body extension rejected',pass(doc,[...samples,{role:'unknown',point:[0,20,0]}]).off);
  require('coarse stored-position precision rejected',pass(doc,samples,.1).off);
  require('original captured sidecar/samples immutable',JSON.stringify(fixture)===original);
  return {controls,body,full:actual.full,quantStep:q,full_height_still_pole_inclusive:actual.full.size[1],threshold:doc.attributes.wall_height_m.value*2.6+3};
 },{fixture,predicates:binding.predicates,actual});
 if(Math.abs(actual.full.size[1]-11.022312130283224)>fixture.quantStep*3||Math.abs(actual.full.body.size[1]-5.401596451102532)>fixture.quantStep*3||actual.full.body.samples!==3054||actual.full.body.excluded!==328||actual.full.body.wallSamples!==782)throw Error('Actual body/full/counts drift from independently decoded current web');
 report.scene_pose=await page.evaluate(()=>{const a=__chicago4d;a.setFly(true);const e=-52,n=-72,alt=8,b=a.buildings.instanceBounds().wolf_point_tavern,m=a.buildings.matrixOf('wolf_point_tavern').elements,x=(b.min[0]+b.max[0])/2,z=(b.min[2]+b.max[2])/2,y=b.min[1]+b.size[1]*.4;const te=m[0]*x+m[8]*z+m[12],tn=-(m[2]*x+m[10]*z+m[14]),ty=m[1]*x+m[5]*y+m[9]*z+m[13],eye=a.walker.surfaceAt(e,n)+alt;const yaw=(Math.atan2(te-e,tn-n)*180/Math.PI+360)%360,pitch=Math.atan2(ty-eye,Math.hypot(te-e,tn-n))*180/Math.PI;a.walker.teleport({local_e:e,local_n:n,altitude_m:alt,yaw_deg:yaw,pitch_deg:pitch});a.step();return {mode:'native free-fly',e,n,altitude_m:alt,yaw_deg:yaw,pitch_deg:pitch,camera_position:a.camera.position.toArray(),quaternion:a.camera.quaternion.toArray(),stats:a.stats()};});
 await page.screenshot({path:path.join(out,'actual-scene.png')});
 const deadline=Date.now()+30000;while(inflight.size&&Date.now()<deadline)await new Promise(ok=>setTimeout(ok,100));report.pending_requests=[...inflight.values()];if(inflight.size)throw Error('Pending native requests');await Promise.all(tasks);
 if(!report.asset_responses.length||report.asset_responses.some(x=>x.status!==200||x.sha256!==expectedWeb))throw Error('Actual loaded compressed Wolf binding failure');
 for(const f of [...binding.files,...binding.inputs])if(sha(fs.readFileSync(path.join(app,f.path)))!==f.sha256)throw Error('Source/input drift during proof: '+f.path);
 report.status='PASS_ACTUAL_BODY_READBACK_AND_CLONED_REPLAY_NOT_FULL_SMOKE';
}catch(e){error=e;report.status='FAIL';report.error=String(e.stack||e);}
finally{
 try{await context?.close();}catch(e){report.cleanup_errors??=[];report.cleanup_errors.push(String(e));}try{await browser?.close();}catch(e){report.cleanup_errors??=[];report.cleanup_errors.push(String(e));}if(server)await new Promise(ok=>server.close(ok));
 if(report.page_errors.length||report.http_errors.length||report.request_failures.length||report.cdp_errors.length||report.cleanup_errors?.length){error??=Error('Page/request/CDP/cleanup error');report.status='FAIL';report.error??=String(error);}
 report.ended_at=new Date().toISOString();report.exit_code=error?1:0;save();
}
console.log(JSON.stringify({status:report.status,out,error:report.error??null},null,2));if(error)process.exitCode=1;
