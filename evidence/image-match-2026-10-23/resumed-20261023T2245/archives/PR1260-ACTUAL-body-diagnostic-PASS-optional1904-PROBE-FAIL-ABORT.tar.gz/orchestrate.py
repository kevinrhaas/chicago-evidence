from pathlib import Path
import subprocess,os,json,datetime,sys,hashlib
R=Path('/workspace/PR1260-body-diagnostic-live-proof');A=Path('/tmp/chicago-log-integration/chicago/4d');H=Path('/tmp/PR1260-body-browser-proof-school-20261024');S=R/'ORCHESTRATION.json'
if S.exists():raise SystemExit('Refusing existing orchestration')
env=os.environ.copy();env['TMPDIR']='/workspace/tmp-t3081';env['PW_EXECUTABLE']='/usr/bin/chromium';env['PATH']='/workspace/shared/tools/usr/bin:'+env.get('PATH','')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
r={'status':'RUNNING','stage':'normal-publish','pid':os.getpid(),'started_at':now(),'scope':'Root approved normal publish then focused actual mobile/desktop body CDP readback and cloned replay. Optional one normal1904 spawn budget probe. No full smoke/native writer/geometry mutation.','stages':[],'proof_code_sha256':hashlib.sha256((H/'prove.mjs').read_bytes()).hexdigest()}
def save():
 t=S.with_suffix('.next.json');t.write_text(json.dumps(r,indent=2)+'\n');t.replace(S)
def stage(name,cmd):
 row={'name':name,'command':cmd,'started_at':now(),'log':str(R/(name+'.log'))};r['stage']=name;r['stages'].append(row);save()
 with Path(row['log']).open('w') as f:
  p=subprocess.Popen(cmd,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();code=p.wait()
 row['exit_code']=code;row['ended_at']=now();save()
 if code:raise RuntimeError(name+' exited '+str(code))
try:
 stage('normal-publish',['bash','tools/publish.sh'])
 stage('bind-post-native',['node',str(H/'bind.mjs'),'--with-inputs','--out',str(R/'SOURCE-INPUT-BINDINGS.json')])
 for vp in ['mobile','desktop']:stage('body-'+vp,['node',str(H/'prove.mjs'),'--bindings',str(R/'SOURCE-INPUT-BINDINGS.json'),'--viewport',vp,'--out',str(R/vp),'--execute'])
 extra=H/'spawn1904.mjs'
 if extra.exists():stage('spawn1904',['node',str(extra),'--out',str(R/'spawn1904'),'--execute'])
 else:r['spawn1904']='NOT_EXECUTED: supplemental helper unavailable; no full stage14 invoked'
 r['status']='PASS_FOCUSED_BODY_PROOFS_SEE_SPAWN_BUDGET';r['exit_code']=0
except BaseException as e:r['status']='FAIL_STOPPED';r['error']=str(e);r['exit_code']=1
finally:r['ended_at']=now();save()
print(json.dumps(r,indent=2));sys.exit(r['exit_code'])
