from pathlib import Path
import os,sys,json,hashlib,subprocess,time,datetime,shutil
os.sched_setaffinity(0,{3});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1')
app=Path('/tmp/st-mary-picture-20261025/chicago/4d');r=Path('/tmp/st-mary-runtime-20261025');out=r/'native-tail61';assert not out.exists();out.mkdir();tmp=Path('/tmp/sm-n');tmp.mkdir(exist_ok=True);os.environ['TMPDIR']=str(tmp)
assert json.loads((r/'ff-20affa/RESULT.json').read_text())['status'].endswith('NO_DERIVE_RENDER_OR_GATE')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=json.loads((r/'ff-20affa/PREPARED.json').read_text())['family542'];assert all(sha(app/p)==s for p,s in before.items())
manifest='docs/RESEARCH/glessner-v4-recovery/manifest.json';want='50d95d427046bd84d38ad6f204f22f0cea52fe991ab448d592a5ce9e914bac73';donor=Path('/tmp/chicago-green-tree-integration/chicago/4d');assert sha(app/manifest)==want==sha(donor/manifest)
links=[]
for name,info in json.loads((app/manifest).read_text())['files'].items():
 src=donor/name;dst=app/name;assert src.is_file()and not src.is_symlink()and src.stat().st_size==info['bytes']and sha(src)==info['sha256']
 if dst.exists():assert dst.is_file()and not dst.is_symlink()and sha(dst)==info['sha256']
 else:dst.parent.mkdir(parents=True,exist_ok=True);os.link(src,dst)
 assert dst.stat().st_ino==src.stat().st_ino and dst.stat().st_dev==src.stat().st_dev
 links.append({'path':name,'sha256':info['sha256'],'bytes':info['bytes'],'inode':dst.stat().st_ino,'real_hardlink':True})
(out/'EXACT-GLESSNER-HARDLINKS.json').write_text(json.dumps({'package_sha256':want,'donor':str(donor),'only_explicit_packaged_outputs':links},indent=2)+'\n')
start=time.monotonic()
def run(name,cmd):
 free=shutil.disk_usage('/tmp').free;print(name,'START',datetime.datetime.now(datetime.timezone.utc).isoformat(),'tmp_free',free,flush=True)
 if name in ['recover-check','bootstrap-native-publish']:assert free>=2*1024**3,('TMP_LOW',free)
 with(out/(name+'.log')).open('x')as log:z=subprocess.run(cmd,cwd=app,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'-result.json')).write_text(json.dumps({'command':cmd,'exit':z.returncode,'tmp_free_after':shutil.disk_usage('/tmp').free},indent=2)+'\n')
 assert z.returncode==0,(name,z.returncode);print(name,'CLOSED_PASS',flush=True)
run('recover-check',['python3','tools/recover_glessner_v4.py','--check'])
run('bootstrap-native-publish',['bash','tools/publish.sh'])
run('tail61',['node','tools/rederive.mjs','--tail','tools/compile_liberties.py'])
assert all(sha(app/p)==s for p,s in before.items()),'FROZEN_FRAME_ASSET_MOVED'
text=(out/'tail61.log').read_text();assert 'derived layer rebuilt from step 142' in text and 'the last one moved nothing' in text,('TAIL_NOT_FIXED',text[-1200:])
result={'status':'NATIVE_MIRROR_BOOTSTRAP_AND61TAIL_FIXEDPOINT_PASS','base':'20affa4da27b9d001f5c06a1a6f76df285817313','cpu':[3],'BLAS_OMP':1,'elapsed_seconds':round(time.monotonic()-start,3),'all542_frame_asset_bytes_exact':True,'glessner3_verified_real_hardlinks':True,'serialization_workbook_gzip_package_scope_audit_and_final_publish_pending':True,'scope':'Finite nativephase only. No actual app QA/source-photo/fullcheck/PR/image acceptance.'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
