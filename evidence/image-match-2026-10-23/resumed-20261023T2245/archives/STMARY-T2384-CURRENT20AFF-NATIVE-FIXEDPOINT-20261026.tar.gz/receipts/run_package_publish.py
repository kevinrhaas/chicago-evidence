from pathlib import Path
import os,json,subprocess,time,hashlib,shutil,datetime
os.sched_setaffinity(0,{3});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1',TMPDIR='/tmp/sm-n')
app=Path('/tmp/st-mary-picture-20261025/chicago/4d');r=Path('/tmp/st-mary-runtime-20261025');out=r/'native-package-publish';assert not out.exists();out.mkdir();assert json.loads((r/'serialization-scope-status.json').read_text())['all_children_reaped'];a=json.loads((r/'serialization-scope/RESULT.json').read_text());assert not a['kept_real_semantic_changes']and not a['protected_population_paths_dirty'];family=json.loads((r/'ff-20affa/PREPARED.json').read_text())['family542'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert all(sha(app/p)==s for p,s in family.items())
start=time.monotonic()
for name,cmd in [('package-tail5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']),('final-native-publish',['bash','tools/publish.sh'])]:
 print(name,'START',datetime.datetime.now(datetime.timezone.utc).isoformat(),'TMPFREE',shutil.disk_usage('/tmp').free,flush=True)
 with(out/(name+'.log')).open('x')as log:z=subprocess.run(cmd,cwd=app,stdout=log,stderr=subprocess.STDOUT)
 assert z.returncode==0,(name,z.returncode)
 if name=='package-tail5':
  text=(out/(name+'.log')).read_text();assert 'derived layer rebuilt from step 198'in text and 'the last one moved nothing'in text,text[-1000:]
 print(name,'CLOSED_PASS',flush=True)
assert all(sha(app/p)==s for p,s in family.items())
for row in a['rows']:
 if row['semantics_equal']:assert sha(app.parent.parent/row['path'])==row['base_sha256'],row['path']
result={'status':'ONE_NATIVE5STEP_PACKAGE_FIXEDPOINT_AND_FINAL_PUBLISH_PASS','base':'20affa4da27b9d001f5c06a1a6f76df285817313','cpu':[3],'elapsed_seconds':round(time.monotonic()-start,3),'all542_frame_asset_bytes_exact':True,'all_scope_restored_artifacts_still_exact20affa':True,'source_photo_actual_app_fullcheck_pending':True,'tmp_free_after':shutil.disk_usage('/tmp').free}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
