from pathlib import Path
import os,json,subprocess,hashlib,gzip,zipfile,io,xml.etree.ElementTree as ET,datetime
os.sched_setaffinity(0,{3});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1')
repo=Path('/tmp/st-mary-picture-20261025');r=Path('/tmp/st-mary-runtime-20261025');out=r/'serialization-scope';assert not out.exists();out.mkdir()
assert json.loads((r/'native-tail61-status.json').read_text())['all_children_reaped'];assert json.loads((r/'native-tail61/RESULT.json').read_text())['status']=='NATIVE_MIRROR_BOOTSTRAP_AND61TAIL_FIXEDPOINT_PASS'
base='20affa4da27b9d001f5c06a1a6f76df285817313';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==base
paths=[s.decode()for s in git('diff','HEAD','--name-only','-z').split(b'\0')if s];forced=['chicago/reference/resident-research/T-0509/T-0509_resident_research_working.xlsx','chicago/reference/resident-research/final/audit/resident_audit_master.xlsx'];targets=sorted(set(p for p in paths if p.lower().endswith(('.xlsx','.gz')))|set(forced));old={};proc=subprocess.Popen(['git','cat-file','--batch'],cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for p in targets:
 proc.stdin.write((base+':'+p+'\n').encode());proc.stdin.flush();head=proc.stdout.readline().decode().split();assert len(head)==3,head;old[p]=proc.stdout.read(int(head[2]));assert proc.stdout.read(1)==b'\n'
proc.stdin.close();assert proc.wait()==0
DCT='{http://purl.org/dc/terms/}'
def canonical(raw,name):
 root=ET.fromstring(raw)
 if name=='docProps/core.xml':
  for c in list(root):
   if c.tag in {DCT+'created',DCT+'modified'}:root.remove(c)
 return ET.canonicalize(ET.tostring(root,encoding='unicode'),rewrite_prefixes=True)
def xlsx_compare(a,b):
 with zipfile.ZipFile(io.BytesIO(a))as x,zipfile.ZipFile(io.BytesIO(b))as y:
  assert len(x.namelist())==len(set(x.namelist()))and len(y.namelist())==len(set(y.namelist()))
  if set(x.namelist())!=set(y.namelist()):return False,[{'difference':'member names'}]
  rows=[]
  for name in sorted(x.namelist()):
   p,q=x.read(name),y.read(name);same=p==q
   if not same and name.endswith(('.xml','.rels')):same=canonical(p,name)==canonical(q,name)
   rows.append({'member':name,'raw_bytes_exact':p==q,'semantics_equal':same})
  return all(z['semantics_equal']for z in rows),rows
rows=[];restore=[]
for p in targets:
 a,b=old[p],(repo/p).read_bytes();row={'path':p,'base_sha256':sha(a),'before_sha256':sha(b),'byte_exact':a==b,'forced_workbook_audit':p in forced}
 if a==b:row.update(semantics_equal=True,action='UNCHANGED_EXACT_BYTES_SKIP_PARSE_EVEN_IF_LEGACY_INVALID_ZIP')
 else:
  save=out/'before'/p;save.parent.mkdir(parents=True,exist_ok=True);save.write_bytes(b)
  if p.lower().endswith('.gz'):same=gzip.decompress(a)==gzip.decompress(b);row.update(semantics_equal=same,comparison='Exact decompressed bytes; no JSON semantic/whitespace tolerance')
  else:same,details=xlsx_compare(a,b);row.update(semantics_equal=same,members=details,comparison='Every ZIP member payload exact or canonical XML semantics exact; only created/modified core timestamps ignored. Member sets/duplicates checked. Cell/formula/style data remain in exact compared XML.')
  row['action']='RESTORE_BASE_BYTES_AND_INDEX'if same else'KEEP_REAL_SEMANTIC_CHANGE';restore.extend([p]if same else[])
 rows.append(row)
# All proofs are complete before the first restoration, and no non-identical semantic payload is restored.
for p in restore:
 (repo/p).write_bytes(old[p]);git('restore','--source='+base,'--staged','--',p);assert(repo/p).read_bytes()==old[p]and git('show',':'+p)==old[p]
protected=[p for p in paths if p.startswith('chicago/4d/data/residents/')];result={'status':'BATCHED_WORKBOOK_GZIP_SCOPE_AUDIT_COMPLETE','base':base,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_dirty_xlsx_gzip_audited_together':True,'both_required_workbooks_included':True,'rows':rows,'restored_semantic_only':restore,'kept_real_semantic_changes':[z['path']for z in rows if not z['semantics_equal']],'protected_population_paths_dirty':protected,'notes':'One batched pass. Original changed bytes saved before restoration; no writer, data, gate or scope assertion modified. Exact original20affa bytes restored ONLYafter full member/decompressed identity proof.'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2))
