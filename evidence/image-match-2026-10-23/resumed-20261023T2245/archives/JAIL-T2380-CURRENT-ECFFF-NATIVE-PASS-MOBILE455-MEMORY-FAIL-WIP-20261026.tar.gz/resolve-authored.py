from pathlib import Path
import subprocess,json,re,datetime,hashlib
r=Path('/workspace/chicago');a=r/'chicago/4d';o=Path('/tmp/jail-currentdev-ending-20261026');base='ecfff9f56ce359b70aa520e97d1923c12a6dafb2';private='23dddb8feb6698d6a601d200e49c79a56939935f';g=lambda *args:subprocess.check_output(['git',*args],cwd=r)
assert g('rev-parse','HEAD').decode().strip()=='6b72454ea24960a69c473be630580cdeff274802';assert g('rev-parse','MERGE_HEAD').decode().strip()==base
rel='chicago/4d/docs/LIBERTIES.md';mb=g('merge-base','HEAD',base).decode().strip();common=g('show',mb+':'+rel);ours=g('show','HEAD:'+rel);incoming=g('show',base+':'+rel);assert ours.startswith(common)
assert b'L-jail-palisade-2380' in ours[len(common):];p=r/rel;p.write_bytes(incoming+b'\n\n'+ours[len(common):]);assert p.read_bytes().startswith(incoming)
proof={'base':base,'merge_base':mb,'lib_incoming_exact_prefix':True,'lib_own_suffix_sha256':hashlib.sha256(ours[len(common):]).hexdigest(),'tool_conflicts_retained':'Independent DATA-centroid occupied footprint, vertex transforms, all ourscontrols plus incoming T3174 campWorst diagnostics and two inset-footprint assertions'}
for rel in ['chicago/4d/tools/drawn_placement_census.mjs','chicago/4d/tools/test_drawn_placement_census.mjs']:
 p=r/rel;s=p.read_text();n=0
 def choose(m):
  global n;n+=1;return m[1]
 s=re.sub(r'^<<<<<<< HEAD\n(.*?)^=======\n.*?^>>>>>>> '+base+r'\n',choose,s,flags=re.M|re.S);assert n>0 and not re.search(r'^(<<<<<<<|=======|>>>>>>>)',s,re.M);p.write_text(s)
subprocess.run(['git','add','--','chicago/4d/docs/LIBERTIES.md','chicago/4d/tools/drawn_placement_census.mjs','chicago/4d/tools/test_drawn_placement_census.mjs'],cwd=r,check=True)
# Repair only the four generic release-hash files, entrywise for native registrations.
for rel in ['chicago/4d/tools/dev-smoke-state.mjs','chicago/4d/tools/test_dev_smoke_state.mjs']:(r/rel).write_bytes(g('show',private+':'+rel))
p=a/'tools/check.sh';s=p.read_text();assert 'node tools/test_dev_smoke_state.mjs'not in s;privatecheck=g('show',private+':chicago/4d/tools/check.sh').decode();m=re.search(r'(selftest "Smoke input hashes[^\n]*\n  node tools/test_dev_smoke_state.mjs --self-test\n\n)',privatecheck);assert m;anchor='step "Spatial ground batches';assert s.count(anchor)==1;p.write_text(s.replace(anchor,m[1]+anchor))
p=a/'tools/step_isolation.json';isolation=json.loads(p.read_text());repair=json.loads(g('show',private+':chicago/4d/tools/step_isolation.json'));assert 'tools/test_dev_smoke_state.mjs'not in isolation['tools'];isolation['tools']['tools/test_dev_smoke_state.mjs']=repair['tools']['tools/test_dev_smoke_state.mjs'];isolation['tools']=dict(sorted(isolation['tools'].items()));isolation['measured']='2026-10-26';p.write_text(json.dumps(isolation,indent=2)+'\n')
subprocess.run(['git','add','--','chicago/4d/tools/dev-smoke-state.mjs','chicago/4d/tools/test_dev_smoke_state.mjs','chicago/4d/tools/check.sh','chicago/4d/tools/step_isolation.json'],cwd=r,check=True)
proof['remaining_derived_conflicts']=g('diff','--name-only','--diff-filter=U').decode().splitlines();proof['at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(o/'AUTHORED-RESOLVED.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
