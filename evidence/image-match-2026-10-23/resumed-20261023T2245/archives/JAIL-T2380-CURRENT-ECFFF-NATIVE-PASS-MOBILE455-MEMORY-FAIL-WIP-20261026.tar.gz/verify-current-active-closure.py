from pathlib import Path
import subprocess,json,hashlib,os,re,datetime
R=Path('/workspace/chicago');P=Path('/tmp/jail-currentdev-ending-20261026');E=P/'impact';OLD='8cd2db60777947a16399459fd2945eb804849a51';env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def g(*a):return subprocess.check_output(['git',*a],cwd=R,env=env)
idx={}
for x in g('ls-files','--stage','-z').decode().strip('\0').split('\0'):
 left,p=x.split('\t',1);mode,blob,stage=left.split();assert stage=='0',p;idx[p]={'mode':mode,'git_blob_sha1':blob}
cache={}
def check(p,want):
 assert idx.get(p)==want,('INDEX_MISMATCH',p,idx.get(p),want)
 if p not in cache:
  f=R/p;data=os.readlink(f).encode()if f.is_symlink()else f.read_bytes();mode='120000'if f.is_symlink()else'100755'if f.stat().st_mode&0o111 else'100644';blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();cache[p]={'mode':mode,'git_blob_sha1':blob}
 assert cache[p]==want,('WORKING_MISMATCH',p,cache[p],want)
counts={}
for name in ['EXPECTED-RUNTIME.json','EXPECTED-ACTIVE-SIDECARS.json','EXPECTED-PHYSICAL-DATA.json']:
 records=json.loads((E/name).read_text())
 for p,v in records.items():check(p,v)
 counts[name]=len(records)
master=json.loads((R/'chicago/4d/assets/manifest.json').read_text())['assets'];web=json.loads((R/'chicago/4d/assets/manifest.web.json').read_text())['masters'];rows=json.loads((E/'EXPECTED-ACTIVE-ASSETS.json').read_text())
for v in rows:
 for kind in ['master','web']:
  x=v[kind];check(x['path'],{k:x[k]for k in ['mode','git_blob_sha1']})
 name=Path(v['master']['path']).name;assert master[name]==v['master_registry_row'];assert web[name]==v['web_registry_row']
counts['active_master_WEB_pairs_and_registry_rows']=len(rows)
# Enumerate every changed smoke byte rather than claiming wholehelper equality.
smokep='chicago/4d/tools/smoke_renderer.mjs';old=g('show',OLD+':'+smokep).decode();now=(R/smokep).read_text();newdiag='''      + `${drawnTown.buildings.compounds} sparse camp plots (empty plot corners up to `
      + `${drawnTown.buildings.campWorst.toFixed(2)} m out, which gate nothing)`, true);''';olddiag='''      + `${drawnTown.buildings.compounds} sparse camp plots`, true);''';assert now.count(newdiag)==1;assert now.replace(newdiag,olddiag)==old,'UNCLASSIFIED_SMOKE_DELTA'
censusp='chicago/4d/tools/drawn_placement_census.mjs';census=(R/censusp).read_text();cold=g('show',OLD+':'+censusp).decode();newrow='misplaced: 0, worstTransform: 0, compounds: 0, campWorst: 0, campWorstId: null,';oldrow='misplaced: 0, worstTransform: 0, compounds: 0,';diag='''    // The worst is the worst GATED structure. T-3174 was filed against
    // land_sale_camp_shore because this line used to rank the exempt camps
    // too, so the message named a camp's empty plot corner (9.82 m) while the
    // one structure actually failing was the lighthouse at 1.81 m. Camps keep
    // their own figure, which gates nothing.
    if (box.compound) {
      if (out > B.campWorst) { B.campWorst = out; B.campWorstId = id; }
    } else if (out > B.worst) {''';assert census.count(diag)==1 and census.count(newrow)==1;assert census.replace(newrow,oldrow).replace(diag,'    if (out > B.worst) {')==cold,'UNCLASSIFIED_CENSUS_DELTA'
# The changed worst/campWorst values feed diagnostic strings only in the held smoke;
# all six actual held fields/thresholds and every vertex/centroid computation remain exact.
held='''      drawnTown.buildings.compared > 200 && drawnTown.buildings.unrecorded === 0
      && drawnTown.buildings.outside === 0 && drawnTown.buildings.mirrorCloser === 0
      && drawnTown.buildings.misplaced === 0,''';assert held in old and held in now
measure='chicago/4d/tools/measure_drawn_placement.mjs';assert(R/measure).read_bytes()==g('show',OLD+':'+measure)
# Save actual complete diffs for independent review; no test predicate weakened.
(P/'impact'/'EXACT-TOOL-DIAGNOSTIC-DELTA.patch').write_bytes(g('diff',OLD,'--',smokep,censusp,'chicago/4d/tools/test_drawn_placement_census.mjs',measure))
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_CURRENT_STAGED_AND_WORKING_ACTIVE1835_CLOSURE_PASS','head':g('rev-parse','HEAD').decode().strip(),'merge_head':g('rev-parse','MERGE_HEAD').decode().strip(),'staged_tree':g('write-tree').decode().strip(),'counts':counts,'unique_path_mode_and_blob_bytes_exact_old_actual8cd':len(cache),'old_actual_candidate':OLD,'smoke_delta':'EXACTONESTAGE10DIAGNOSTICSTRING; allheldpredicatesandsharedhelpersexactafterthatliteralnormalization','census_delta':'EXACTdiagnosticcampworstseparationonly; independentvertexplacement/DATAcentroid/1mm/occupiedbar/mirrortestsunchanged','not_current_whole18':True,'not_global_hash_equality':True,'fresh_selected_parts_both_still_required':True,'current_memory_not_excused':True};(P/'ACTIVE-CLOSURE-post-native.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
