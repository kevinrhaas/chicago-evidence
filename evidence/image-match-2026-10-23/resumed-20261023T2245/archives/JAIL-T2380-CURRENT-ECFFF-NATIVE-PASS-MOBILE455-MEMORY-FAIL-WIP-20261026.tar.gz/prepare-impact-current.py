from pathlib import Path
import subprocess,os,json,hashlib,re,datetime
R=Path('/workspace/chicago');P=Path('/tmp/jail-currentdev-ending-20261026');O=P/'impact';O.mkdir(exist_ok=True);OLD='8cd2db60777947a16399459fd2945eb804849a51';UP='a9c5bd4a9715e4d5634c536d0efcd516ea9c3f01';NEW='ecfff9f56ce359b70aa520e97d1923c12a6dafb2';E=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def g(*x):return subprocess.check_output(['git',*x],cwd=R,env=E)
def blob(ref,p):return g('show',ref+':'+p)
def j(ref,p):return json.loads(blob(ref,p))
def save(n,v):(O/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def tree(ref):
 d={}
 for line in g('ls-tree','-r','-z',ref).split(b'\0'):
  if line:
   x,p=line.split(b'\t',1);mode,kind,sha=x.decode().split();d[p.decode()]={'mode':mode,'git_blob_sha1':sha}
 return d
B,T,N=map(tree,[UP,OLD,NEW]);changed=[p for p in sorted(set(B)|set(N))if B.get(p)!=N.get(p)];save('UPSTREAM-DELTA.json',[{'path':p,'before':B.get(p),'incoming':N.get(p)}for p in changed]);canonical='chicago/4d/renderers/web/js/changelog.js';runtime={p:v for p,v in T.items()if p.startswith('chicago/4d/renderers/')and p!=canonical};assert all(B.get(p)==N.get(p)for p in runtime);assert{p for p in N if p.startswith('chicago/4d/renderers/')and p!=canonical}==set(runtime);save('EXPECTED-RUNTIME.json',runtime)
idxp='chicago/4d/data/sidecars/1835/index.json';idx=j(OLD,idxp);assert idx==j(NEW,idxp);active={f"chicago/4d/data/{v['sidecar']}":T[f"chicago/4d/data/{v['sidecar']}"]for v in idx['structures']};assert all(B.get(p)==N.get(p)for p in active);save('EXPECTED-ACTIVE-SIDECARS.json',active)
M=j(OLD,'chicago/4d/assets/manifest.json')['assets'];MN=j(NEW,'chicago/4d/assets/manifest.json')['assets'];W=j(OLD,'chicago/4d/assets/manifest.web.json')['masters'];WN=j(NEW,'chicago/4d/assets/manifest.web.json')['masters'];assets=[]
for v in idx['structures']:
 if not v.get('asset'):continue
 name=Path(v['asset']).name;master='chicago/4d/assets/gltf/'+name;web='chicago/4d/assets/web/'+name;assert T[master]==B[master]==N[master]and T[web]==B[web]==N[web];assert M[name]==MN[name]and W[name]==WN[name];assets.append({'id':v['id'],'master':{'path':master,**T[master]},'web':{'path':web,**T[web]},'master_registry_row':M[name],'web_registry_row':W[name]})
save('EXPECTED-ACTIVE-ASSETS.json',assets)
inactive_records=[p for p in changed if p.startswith('chicago/4d/data/structures/')];dates=[]
for p in inactive_records:
 record=j(NEW,p);assert all(v['documented_range']['from']>'1835-07-01'for v in record['phases']);assert all(v['id']!=record['id']for v in idx['structures']);dates.append({'path':p,'id':record['id'],'phase_ranges':[{'id':v['id'],'documented_range':v['documented_range']}for v in record['phases']]})
save('INACTIVE-STRUCTURE-DATE-PROOF.json',dates)
def global1904(p):
 s=p.removeprefix('chicago/4d/')
 return p in inactive_records or s=='data/liberties.json'or s.startswith(('data/sources/','data/research/','data/jaunts/','data/reference_views/','data/components/prairie_1904/','data/sidecars/1904/'))or bool(re.match(r'data/sidecars/[^/]+/sources/',s))
physical={p:v for p,v in T.items()if p.startswith('chicago/4d/data/')and not global1904(p)};unpriced=[p for p in changed if p.startswith('chicago/4d/data/')and not global1904(p)];assert not unpriced,unpriced;save('EXPECTED-PHYSICAL-DATA.json',physical)
rows=[]
for p in changed:
 if p.startswith('chicago/4d/assets/')or p.startswith('chicago/4d/data/sidecars/1904/')or p in inactive_records:parts=[14,15];why='Current1904models/registry/catalog; fresh1904sceneandarrival withcommonboot. Active1835assetsandregistryrowsremainexactoldactual8cd.'
 elif p==canonical:parts=[13];why='Releasefold/newnoteswithnormalizedreleasepartition; fresh13notesandcommonboot.'
 elif p.endswith('/data/liberties.json')or p.endswith('/docs/LIBERTIES.md'):parts=[3,4,12,14];why='GlobalLiberties/card/Inspect/Guide/Evidence newmetadata; freshbothviewportcoverage.'
 elif '/sources/'in p or p.startswith('chicago/4d/data/jaunts/'):parts=[3,4,12,14,15];why='Globalpictures/sources/catalog; freshcard/Inspect/Guide/Evidence/arrival; nozero-transitive-readclaim.'
 elif p.startswith('chicago/4d/tools/')and p.endswith(('drawn_placement_census.mjs','test_drawn_placement_census.mjs','smoke_renderer.mjs')):parts=[];why='Currentmergekeepsall8cdheldplacementpredicates/centroid/strictglass; onlynewincomingT3174campWorstdiagnosticsandassertionfixtures. Finalsourcecheckrequired; nooldwholesourceequalityclaim.'
 else:parts=[];why='Generator/schema/tool/prose/referenceinputvalidatedbycurrentnativewholecheck; generatedphysicaloutputscoveredbyexactclosure orfreshglobal/1904coverage. No generatorloadedbyrenderer.'
 rows.append({'path':p,'fresh_parts':parts,'why':why,'common_boot_both':True})
save('EVERY-UPSTREAM-PATH-COVERAGE.json',rows)
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'METADATA_IMPACT_PREPARED_FINAL_SOURCE_GUARDS_STILL_REQUIRED','old_actual_tested_candidate':OLD,'upstream_before':UP,'incoming':NEW,'upstream_changed_paths':len(changed),'runtime_paths':len(runtime),'active_sidecars':len(active),'active_master_WEB_pairs_and_rows':len(assets),'physical_paths':len(physical),'inactive_structure_records':len(inactive_records),'fresh_parts_both_viewports':[1,2,3,4,12,13,14,15],'reuse_old_actual_parts':[5,6,7,8,9,10,11],'not_current_whole18':True,'not_latest_global_hash_equality':True,'final_current_source_and_published_guards_pending':True};save('SUMMARY.json',summary);print(json.dumps(summary,indent=2))
