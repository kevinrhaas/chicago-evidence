from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,time
P=Path(__file__).resolve().parent;runtime=P/'runtime'
assert os.environ.get('SCHOOL_TRIAL_LEASE')=='explicit-root-GPU-after-school-native','Need later explicit GPU lease; CPU-only grant does not authorize photos'
assert json.loads((P/'CPU-ONLY-CLOSED.json').read_text())['status']=='ACTUAL_NATIVE_BASELINE_CANDIDATE_WEB_PASS_PHOTO_UNRUN'
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PW_EXECUTABLE='/usr/bin/chromium',TMPDIR=str(P/'scratch'),GIT_NO_LAZY_FETCH='1');cpus=os.environ.get('SCHOOL_TRIAL_CPUS','0,1');results=[]
def run(name,args):
 log=P/'logs'/(name+'.log');reap=P/'logs'/(name+'-REAPER.json');assert not log.exists(),'Preserve prior attempts, never overwrite logs'
 command=['python3','/workspace/shared/run-with-reaping.py',str(reap),'--','nice','-n','19','taskset','-c',cpus,*args];t=time.monotonic()
 with log.open('x') as f:r=subprocess.run(command,cwd=runtime,env=E,stdout=f,stderr=subprocess.STDOUT)
 rr=json.loads(reap.read_text());row={'name':name,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'cwd':str(runtime),'exit':r.returncode,'seconds':time.monotonic()-t,'all_children_reaped':rr.get('all_children_reaped'),'command_exit':rr.get('command_exit')};results.append(row);(P/'PHOTO-STAGE-RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0 and rr.get('command_exit')==0 and rr.get('all_children_reaped'),row
for label,asset in [('before','baseline-control.glb'),('after','chappel_infant_school__log_1833.glb')]:
 run(label.upper()+'-PHOTO',['node','tools/photo_match.mjs',str(P/'cameras'/(label+'.json')),'--glb','assets/gltf/'+asset,'--out',str(P/'outputs'/label)])
 raw=(P/'logs'/(label.upper()+'-PHOTO.log')).read_text();match=re.search(r'\n\s+(/[^\n]+-render\.png)\n',raw);assert match,'Native raw image path missing';src=Path(match.group(1));assert src.is_file();shutil.copyfile(src,P/'outputs'/label/'ACTUAL-NATIVE.png')
x={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_TWO_NATIVE_CAPTURES_PASS_UNREVIEWED','stages':results,'scope':'External before/after native picture captures only, on earlier actual candidate master. Canonical source/claim/scene/grade/metadata/app/policy/original acceptance remains separate.'};(P/'PHOTO-CLOSED.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x),flush=True)
