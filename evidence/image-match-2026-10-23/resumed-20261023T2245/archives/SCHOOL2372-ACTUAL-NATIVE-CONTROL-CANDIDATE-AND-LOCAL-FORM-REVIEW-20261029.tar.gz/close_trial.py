from pathlib import Path
import datetime,hashlib,json,re,shutil
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');Q=Path('/tmp/T2372-next-fit-20261029')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['CPU-CONTROLLER-REAPER.json','PHOTO-CONTROLLER-REAPER.json','logs/NATIVE-REAPER.json','logs/WEB-REAPER.json','logs/BEFORE-PHOTO-REAPER.json','logs/AFTER-PHOTO-REAPER.json']:
 x=json.loads((P/n).read_text());assert x['command_exit']==0 and x['all_children_reaped'],n
raw=P/'cameras/after.match.json';x=json.loads(raw.read_text());assert x['verdict']=='unreviewed'
x['verdict']='matches';x['differences']=[
 {'what':'The former broad7.315m gable front becomes the reconstructed4.572m face. Native same-world-pose before/after now puts the visible log wall and two lights close to the held drawing. Hidden8.778m depth retains approximately the old two-room area; it is not a measured plan.','status':'fixed'},
 {'what':'The pictured steeper gable silhouette is built with the native41° roof over the narrower frontage, including inherited250mm overhangs and horizontal log cap. The apex sits about7px to the right of the drawing at the same height, approximately0.26m in this declared reconstructed scale. This is below the0.3m visitor bar and the drawn/partly cropped face is not a surveyed elevation.','status':'within tolerance'},
 {'what':'The existing dark blind recess is now2.30m tall; the existing0.85m lights sit at its2.32m common head. Native render shows window–door–window at the source’s close spacing. The source’s head/corner/base disagreements are a few pixels and the base is obscured by people/grass; no further precise alignment is justified.','status':'fixed'},
 {'what':'The drawing and model both show horizontal log wall/gable courses and a wood-shingle roof category. Individual hand-drawn stroke/course variation and neutral-master uniform spacing do not establish a visitor-noticeable geometric defect. Exact brown/grey hues cannot be read from this monochrome ink reproduction. Native isolated review omits the app’s procedural wood/shingle surface treatment; published app review is still owed.','status':'within tolerance'},
 {'what':'The hidden depth, rear roof/stack end and unseen elevations are outside the right-hand crop or foreground-tree occlusion. This is not evidence of no chimney or an attested hidden plan. The ordinary one-stack heating inference is preserved.','status':'not shown'},
 {'what':'The shore, canoes, people, distant lighthouse and settlement are context outside this isolated schoolhouse comparison. The inconsistent figure/shore perspective cannot supply a historic camera, source scale or July1835 occupants. None is invented by the local facade fit.','status':'not shown'},
 {'what':'The unknown original artist/publication/date and unresolved school/annex subject are research uncertainties, not unbuilt pictured geometry. The project uses the approved drawing as a declared reconstructed design reference, with a diagnostic camera and explicit native not_pictured ruling preserving inferred school appearance. No source identification, attested grade, copyright-holder grant or public-domain finding follows.','status':'not shown'}]
x['_actual_review']={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Directly viewed actual before and after native photo_match side-by-sides generated18:18Z; no pixel editing or synthetic comparison. Native baseline reproduces current school MASTER exactly.','status':'VISIBLE_BUILDING_FORM_MATCHES_T3153_EXTERNAL_CANDIDATE_ONLY','native_capture_status':'Actual native capture exit0, allchildrenreaped; raw tool-authored unreviewedmatch remains untouched beside camera.','original_ticket_state':'UNCHANGED; no claim/source adoption, canonicalcapture, scene/grade/metadata, publishedBOTHapp or fullpolicyending yet','metric_camera':'Reconstructed diagnostic local-composition pose only; no historical viewpoint/coordinate/scale or identified subject.'}
(P/'REVIEWED-EXTERNAL-MATCHES.match.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
# Freeze exactly the static native import closure, not the whole runtime or town.
v='renderers/web/vendor/three-0.185.1';start=[v+'/three.module.js',v+'/addons/loaders/GLTFLoader.js',v+'/addons/loaders/KTX2Loader.js',v+'/addons/libs/meshopt_decoder.module.js','renderers/web/js/keith-stone.js'];todo=list(start);seen=set();bindings=[]
while todo:
 rel=todo.pop()
 if rel in seen:continue
 seen.add(rel);f=A/rel;assert f.is_file(),rel;dst=P/'frozen/static'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dst);assert sha(dst)==sha(f)
 bindings.append({'source':str(f),'relative_path':rel,'frozen':str(dst),'bytes':f.stat().st_size,'sha256':sha(f)})
 for spec in re.findall(r'(?:\bfrom\s*|\bimport\s*)([\'\"])([^\'\"]+)\1',f.read_text(errors='replace')):
  s=spec[1]
  if s=='three':z=v+'/three.module.js'
  elif s.startswith('three/addons/'):z=v+'/addons/'+s[len('three/addons/'):]
  elif s.startswith('./') or s.startswith('../'):z=str((f.parent/s).resolve().relative_to(A))
  else:continue
  if z not in seen:todo.append(z)
(P/'STATIC-RENDERER-BINDINGS.json').write_text(json.dumps({'scope':'Exact statically imported native browser modules copied after capture with byte equivalence to read-only canonical static link. Not a browser network transcript. No full app or source change. Dynamic KTX2/Basis worker payload was not needed by these untextured school GLBs.','bindings':sorted(bindings,key=lambda z:z['relative_path'])},indent=2)+'\n')
# Include the closed proposal intact for a self-contained future adoption.
(P/'proposal').mkdir(exist_ok=True)
qm=json.loads((Q/'MANIFEST.json').read_text())
for e in qm['members']:
 f=Path(e['path']);assert sha(f)==e['sha256'];dst=P/'proposal'/e['relative_path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dst);assert sha(dst)==e['sha256']
shutil.copyfile(Q/'MANIFEST.json',P/'proposal/MANIFEST.json')
inputs=json.loads((P/'INPUTS.json').read_text());current=[]
for rel,oldfile in [('data/structures/chappel_infant_school.json','BASE-STRUCTURE.json'),('assets/gltf/chappel_infant_school__log_1833.glb','CURRENT-MASTER.glb'),('assets/web/chappel_infant_school__log_1833.glb','CURRENT-WEB.glb')]:
 f=A/rel;current.append({'path':str(f),'sha256':sha(f),'equals_trial_baseline':sha(f)==sha(P/oldfile)})
assert all(e['equals_trial_baseline']for e in current)
(P/'CURRENT-SCHOOL-BINDING-CHECK.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Only unchanged schoolrecord/currentMASTER/currentWEB, no whole-source status claim while root owns active unrelated integration. This trial writes solely its own external output directory.','rows':current},indent=2)+'\n')
print(json.dumps({'static_files':len(bindings),'static_bytes':sum(b['bytes']for b in bindings),'reviewed_matches':str(P/'REVIEWED-EXTERNAL-MATCHES.match.json')}))
