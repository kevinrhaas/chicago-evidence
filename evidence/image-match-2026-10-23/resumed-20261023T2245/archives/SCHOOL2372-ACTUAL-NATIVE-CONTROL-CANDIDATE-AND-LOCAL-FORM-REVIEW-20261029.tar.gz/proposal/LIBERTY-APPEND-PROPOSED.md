
### L-T2372-narrow-school-front — a reconstructed reading of an unidentified school drawing

The owner approved attributed project reference use of the undated drawing reproduced
in the Digital Research Library of Illinois History Journal's 2018 Eliza Chappell article
(`eliza_chappel_school_shore_view`). Its original artist, publication, holding institution,
building identity and depicted date remain unresolved. We use the visible log gable front
as a declared design reference, without identifying it as the school or the Sauganash annex,
without placing the pictured people in July 1835, and without promoting its legal rights.

The old 7.315 × 5.486 m model was much broader than the pictured face at the doorway's
scale. The proposed front is 4.572 m (15 ft), with 8.778 m hidden depth to retain roughly
the previous 40.13 m² two-room school/lodging area. The depth is not drawn. The existing
250 mm overhang and a reconstructed 41° pitch put the ridge 2.2045 m above the unchanged
2.50 m eave. The existing 1.20 m wide recess becomes 2.30 m tall; the existing 0.85 m
lights hang from its 2.32 m common head. Their stations along the front are 0.95, 2.47
and 3.73 m, window–door–window. These are modelling choices, not measured dimensions.

An arithmetic origin compensation of (+1.1875, −3.292) m in the footprint frame keeps the
former doorway's world centre and east-facing front-wall line fixed; it supplies no new
survey precision. Hidden rear fabric, the partition, flue section and location remain
reconstructed. The proposed diagnostic local camera fits the facade composition only.
It cannot invert the inconsistent whole shore drawing to a historic station, and is not
offered as “From this spot.” The unresolved subject is explicitly ruled out of the native
whole-structure appearance grade, preserving `inferred` while the design itself is tested.

Status: **proposal only**. Pure parameter validation and perspective arithmetic passed;
actual native production, current model/WEB capture, picture acceptance, scene and grade
regeneration, exterior grounding and both published app reviews have not run for this fit.
