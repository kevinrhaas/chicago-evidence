# T-2372 next whole-front fit

This is a closed **unapplied proposal**, prepared from the actual held drawing and actual
PR1260 native side-by-side. It changes one structure record using existing controls. No
canonical file, claim, branch, model export, picture verdict or PR was changed.

The visible fix narrows the gable front from 7.315 to 4.572 m and steepens its roof from
35° to 41°; depth becomes 8.778 m to preserve approximately the old two-room floor area.
Window–door–window centres become 0.95, 2.47 and 3.73 m, and the door height becomes
2.30 m. Exact local origin compensation keeps the front-wall line and the former doorway
world centre fixed. The existing dark blind recess, horizontal gable courses, sash sizes,
shutters-off choice, one stack, dates and unknown 1835 use remain.

`PURE-PROJECTION.json` is only native parameter validation plus mathematical projections.
The predicted left corner, door, windows and gable are near the source points in the
640 × 368 image. It is **not a native render**, image acceptance or a calibrated metric
camera. The figure/shore/lighthouse perspective is inconsistent, as already measured in
T0649; this is a diagnostic local facade composition with reconstructed scale and pose.
The source's subject remains unresolved. A deliberate `not_pictured` ruling prevents the
native camera/library join from silently promoting the school to `attested`.

## Exact files to adopt after the current four-ticket unit

- Apply `FIELDWISE-STRUCTURE-ADOPTION.json` to the current structure only if every old leaf
  still matches; it preserves unrelated fields. The postimage is supplied for comparison.
- Add `PROPOSED-CAMERA.json` as `data/reference_views/chappel_infant_school/shore-drawing.json`.
  Its canonical photo path points to the existing exact reference, already in the project.
- Publish the exact `SOURCE-EXACT.jpg` through `IMAGE-HOST-REQUEST.json` to the image host.
  The immediate source and structured credit are supplied. A native ≤480px thumb may be
  generated separately, recording its own byte binding. No public-domain status is claimed.
- Add `PROPOSED-LIBRARY-STREAM.json` to the library after real hosting/STORE sync; fill the
  actual thumb fields if generated. Its camera joins the one held composition to the card.
  The catalog URL matches the existing source so the card deduplicates the link-only entry.
- Append the one explicit `PROPOSED-GRADE-RULING.json` row; preserve every other ruling.
  Compile the native grade, scene and pictures; do not type a sidecar grade by hand.
- Append the scoped liberty from `LIBERTY-APPEND-PROPOSED.md`, updating its final status only
  after the actual candidate has run.

## Required next actual work

Take the original ticket through the native claim protocol before adoption. Price the
remaining scratch/headroom and respect the current app lease. Run the native log-family
production once on the adopted current source, prove every unselected default MASTER/WEB
byte unchanged, generate only the changed school's WEB, compile all owning consumers and
capture the proposed native view. A before camera in the old footprint frame is supplied
for a same-world-pose before capture; the historical PR1260 camera/JPEG are retained as
historical evidence, with their original hashes.

Inspect the new real side-by-side under the 0.3 m stopping rule. The source's drawn head
and gable are not perfectly consistent; actual small residuals may be within tolerance,
but do not declare them passed from projection arithmetic. The cropped rear stack and
undrawn depth are not absence findings. The native flat review lacks the app's procedural
wood/shingle treatment, so review the published body, credited full picture, Sources,
Research/grade, exterior doorway, terrain and changed derived props at both required
viewports, with zero page errors. Complete the full policy check/preflight questions before
committing, PR to `dev`, expected-head standard merge, then official original closure only
if all actual views match. Otherwise preserve open discrepancies on this original; no new
photo tickets or invented certainty.

All existing rights/date/identity limits remain. The only held source identified by the
original ticket is `eliza_chappel_school_shore_view`; the existing origin search should not
be repeated without a new lead.
