from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
P=Path(__file__).resolve().parent;runtime=P/'runtime'
assert os.environ.get('SCHOOL_TRIAL_LEASE')=='explicit-root-CPU-only-after-GT','Need explicit root CPU-only lease after GT all-reaped handoff'
assert shutil.disk_usage(P).free>=512*1024*1024,'Native512MiB scratch guard unchanged'
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PW_EXECUTABLE='/usr/bin/chromium',TMPDIR=str(P/'scratch'),GIT_NO_LAZY_FETCH='1');cpus=os.environ.get('SCHOOL_TRIAL_CPUS','0,1');results=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,cwd):
 log=P/'logs'/(name+'.log');reap=P/'logs'/(name+'-REAPER.json');assert not log.exists(),'Preserve prior attempts, never overwrite logs'
 command=['python3','/workspace/shared/run-with-reaping.py',str(reap),'--','nice','-n','19','taskset','-c',cpus,*args];t=time.monotonic()
 with log.open('x') as f:r=subprocess.run(command,cwd=cwd,env=E,stdout=f,stderr=subprocess.STDOUT)
 rr=json.loads(reap.read_text());row={'name':name,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'cwd':str(cwd),'exit':r.returncode,'seconds':time.monotonic()-t,'all_children_reaped':rr.get('all_children_reaped'),'command_exit':rr.get('command_exit')};results.append(row);(P/'CPU-ONLY-STAGE-RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0 and rr.get('command_exit')==0 and rr.get('all_children_reaped'),row
run('NATIVE',['/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender','--background','--factory-startup','--threads','1','--python',str(P/'run_native.py')],P)
run('WEB',['bash','tools/web_derivatives.sh','--only','chappel_infant_school__log_1833.glb'],runtime)
web=runtime/'assets/web/chappel_infant_school__log_1833.glb';assert web.is_file()
x={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_NATIVE_BASELINE_CANDIDATE_WEB_PASS_PHOTO_UNRUN','stages':results,'web':{'path':str(web),'bytes':web.stat().st_size,'sha256':sha(web)},'scope':'External CPU-only frozen-source trial. No browser, photo_match, canonical source/claim write, family adoption/metadata/app/policy/original acceptance.'};(P/'CPU-ONLY-CLOSED.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x),flush=True)
