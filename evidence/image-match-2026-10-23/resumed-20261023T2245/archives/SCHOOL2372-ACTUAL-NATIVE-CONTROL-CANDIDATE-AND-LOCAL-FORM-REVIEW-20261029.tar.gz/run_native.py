from pathlib import Path
import datetime,hashlib,json,sys,time
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'frozen/generators'));import emit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((P/'INPUTS.json').read_text())
for row in inputs['source_bindings']:assert sha(Path(row['frozen']))==row['sha256'],row['frozen']
rows=[]
for label,record,dest in [('before','BASE-STRUCTURE.json',P/'runtime/assets/gltf/baseline-control.glb'),('after','PROPOSED-STRUCTURE.json',P/'runtime/assets/gltf/chappel_infant_school__log_1833.glb')]:
 assert not dest.exists();r=json.loads((P/record).read_text());t=time.monotonic();made=emit.emit_structure(r,r['phases'][0],'log_dwelling',dest,bake=True,ao=False)
 row={'label':label,'record_sha256':sha(P/record),'path':str(dest),'seconds':time.monotonic()-t,'bytes':dest.stat().st_size,'sha256':sha(dest),'triangles':made.tris,'baked_ao':False};rows.append(row);print(json.dumps(row),flush=True)
 if label=='before':assert row['sha256']==inputs['current_master_sha256'],'Native baseline did not reproduce existing exact MASTER; do not use candidate as qualified'
assert rows[1]['sha256']!=rows[0]['sha256'],'Candidate should change geometry'
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_NATIVE_TWO_EMITS_PASS','old_master_exact_current':True,'rows':rows,'source_adoption':'UNRUN','fullfamily_defaultproduction':'UNRUN; existing controls only; no producer modified','web_picture_app':'PENDING'};(P/'ACTUAL-NATIVE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
