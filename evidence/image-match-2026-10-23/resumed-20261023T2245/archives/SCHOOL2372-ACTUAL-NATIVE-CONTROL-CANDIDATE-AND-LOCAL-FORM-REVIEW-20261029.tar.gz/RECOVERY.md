# School trial recovery — actual native outputs, not an adopted change

The CPU-only trial finished at **2026-10-29 18:17:30 UTC**. The two isolated picture
captures finished at **18:18:07 UTC**. Every native stage and both outer controllers report
`command_exit: 0` and `all_children_reaped: true`. GPU and CPU were explicitly released;
there is no ongoing process to resume.

The first actual emit reproduces the existing 50,172-byte school MASTER exactly:
`fe73a03a135811179b47ac603bf4169b35d1b0cc8b8d595d144885053189a8d8`.
The proposed school MASTER is 49,864 bytes / 524 triangles:
`fb141fef3f348b494ffbf1bc2479427d0cec499001605cdcb34ce52c93c0787a`.
Its native WEB is 18,612 bytes:
`f120aa9abc970bb5b0b28f82c5fd176b268ba67923cea9b31de9967c8c9bf804`.

Actual picture comparisons are `outputs/before/before-side-by-side.jpg` and
`outputs/after/after-side-by-side.jpg`; their unchanged native screenshots and raw tool
match records are retained. `REVIEWED-EXTERNAL-MATCHES.match.json` is a separate direct
visual review. The new visible building form is good under T3153: the narrow steeper log
gable, doorway and two high lights now follow the drawing. The apex is approximately
7 pixels to the right, about 0.26 m in this reconstructed scale, below the 0.3 m bar.
The local drawing/fit and obscured base do not justify further millimetre alignment.

This is a **frozen external candidate**. It does not change the canonical record, model,
claim, grade, picture verdict or ticket. The native method used unmodified `emit_structure`
on exact frozen generator files, pinned Blender 4.5.3, the existing native WEB script/pins
and native `photo_match.mjs`. Static browser import dependencies were preserved by exact
byte copy, without making a full app/runtime copy. `runtime/renderers` is a read-only link
to the source static directory used during capture; an offline replay can explicitly link
it to `frozen/static/renderers` after verifying `STATIC-RENDERER-BINDINGS.json`.

The complete closed original record/camera/image/credit proposal is copied under
`proposal/`; its manifest remains unchanged. The exact original JPEG is 84,702 bytes,
SHA256 `1a63b75fea04e52cbdbbc5ffb2e85749cf648454970cb1bec0d8426a2cba61b9`.
Image-host publishing is assigned separately to the publisher; do not claim that its
proposed host path or thumbnail is already live. Rights are only the owner's approved
attributed project reference use. Artist, original publication/collection, depicted date
and school/annex identity remain unresolved; no public-domain or historic-camera claim.
The proposed native `not_pictured` ruling preserves the school's inferred appearance
while this explicitly reconstructed design is followed.

Next take the original claim through the native protocol, adopt the exact fieldwise
record/grade/library/camera changes on the current integration tree, run current native
owning production/metadata, then capture the canonical camera and inspect the actual
published body/credited whole image/Source/Research/doorway/ground at both viewports.
The isolated master lacks app procedural wood/shingle surface treatment. Complete the
full policy check and PR into `dev`; use expected-head standard merge and verify official
original closure only after all requirements pass. No new photo tickets are needed.

Do not rerun the finished external trial merely because an agent was interrupted.
`run_native_web_only.py` and `run_photo_only.py` refuse execution without their explicit
lease tokens, and preserve logs rather than overwriting attempts. The original combined
`run_trial.py` was prepared but never executed; split stage receipts are authoritative.
