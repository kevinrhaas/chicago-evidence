from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,time
P=Path(__file__).resolve().parent;runtime=P/'runtime';assert os.environ.get('SCHOOL_TRIAL_LEASE')=='explicit-root-after-GT','Wait for explicit root CPU/browser lease'
assert shutil.disk_usage(P).free>=512*1024*1024,'Native512MiB scratch guard unchanged'
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PW_EXECUTABLE='/usr/bin/chromium',TMPDIR=str(P/'scratch'),GIT_NO_LAZY_FETCH='1')
cpus=os.environ.get('SCHOOL_TRIAL_CPUS','0,1');results=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,cwd):
 log=P/'logs'/(name+'.log');reap=P/'logs'/(name+'-REAPER.json');assert not log.exists(),'Preserve prior attempts; do not overwrite logs'
 command=['python3','/workspace/shared/run-with-reaping.py',str(reap),'--','taskset','-c',cpus,*args];t=time.monotonic()
 with log.open('x') as f:r=subprocess.run(command,cwd=cwd,env=E,stdout=f,stderr=subprocess.STDOUT)
 rr=json.loads(reap.read_text());row={'name':name,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'cwd':str(cwd),'exit':r.returncode,'seconds':time.monotonic()-t,'all_children_reaped':rr.get('all_children_reaped'),'command_exit':rr.get('command_exit')};results.append(row);(P/'STAGE-RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0 and rr.get('command_exit')==0 and rr.get('all_children_reaped'),row
run('NATIVE',['/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender','--background','--factory-startup','--threads','1','--python',str(P/'run_native.py')],P)
run('WEB',['bash','tools/web_derivatives.sh','--only','chappel_infant_school__log_1833.glb'],runtime)
for label,asset in [('before','baseline-control.glb'),('after','chappel_infant_school__log_1833.glb')]:
 run(label.upper()+'-PHOTO',['node','tools/photo_match.mjs',str(P/'cameras'/(label+'.json')),'--glb','assets/gltf/'+asset,'--out',str(P/'outputs'/label)],runtime)
 raw=(P/'logs'/(label.upper()+'-PHOTO.log')).read_text();match=re.search(r'\n\s+(/[^\n]+-render\.png)\n',raw);assert match,'Native raw image path missing'
 src=Path(match.group(1));assert src.is_file();shutil.copyfile(src,P/'outputs'/label/'ACTUAL-NATIVE.png')
web=runtime/'assets/web/chappel_infant_school__log_1833.glb';assert web.is_file()
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_NATIVE_WEB_TWO_ISOLATED_CAPTURES_PASS_UNREVIEWED','stages':results,'web':{'path':str(web),'bytes':web.stat().st_size,'sha256':sha(web)},'scope':'External frozen-source school trial only. Native old MASTER exact; candidate and same-world-pose before/after captured. No source/claim writes, full-family production, source adoption, scene/grade/metadata/app/policy/PR/original acceptance.'};(P/'ACTUAL-TRIAL-CLOSED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
