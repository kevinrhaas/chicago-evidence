Fresh H5 moving-frames failed during runner setup, before any moving-frame measurement. No retry or waiver is included.

Job120806725950/run40071829019 checked out merge262bc859 of H5head6024f07363dac65668d90e55881824c067a172b1 into dev29ea317f. Raw logs show Ubuntu26.04.1/image26, followed by playwright@1.56.1 refusing Chromium dependencies on ubuntu26.04-x64. H5 changed the smoke workflow's runner, while this separate moving-frames workflow still used ubuntu-latest. Exact source locations are retained.

H4 and H5 have identical chicago/4d tree bc25fa8390d1cfc84f3c85fc9f281278da8ee009. That equivalence does not relabel this failed H5 setup as a successful measurement. H4's actual moving-frame PASS remains separate. Two H5 replacement1-2 groups and the automatic full smoke were still running in the captured snapshot; those are not PASS results.

The observer performed only GET reads and local evidence writes. It made no code/workflow/assertion change, extra dispatch, rerun, cancellation, claim, lap, label or merge action. The root received the concrete failure promptly and owns any remedy and final approval.
