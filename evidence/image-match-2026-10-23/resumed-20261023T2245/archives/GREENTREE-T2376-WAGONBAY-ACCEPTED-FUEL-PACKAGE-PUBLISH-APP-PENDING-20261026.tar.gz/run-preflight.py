from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import urllib.request

R=Path('/tmp/chicago-green-tree-integration')
A=R/'chicago/4d'
H=Path('/workspace/T2376-wagon-bay-followthrough-20261026')
BASE='a575dddeed356333423b20361a1f90f3b39a862f'
HEAD_BEFORE=BASE
INCOMING=None
O=H/('wagonbay-preflight-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
assert not O.exists()
O.mkdir()
env=dict(os.environ)
env.pop('CHICAGO_TICKETS_DIR',None)
env.pop('GIT_NO_LAZY_FETCH',None)
cores={int(x)for x in os.environ['GT_CHECK_CPUS'].split(',')};assert len(cores)==2;os.sched_setaffinity(0,cores)
env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
mem_limit=int(Path('/sys/fs/cgroup/memory.max').read_text());mem_current=int(Path('/sys/fs/cgroup/memory.current').read_text());assert mem_limit-mem_current>=512*1024**2,'Root-required512MiB caller reserve'
env.update(TMPDIR='/tmp/gt-check',CHECK_JOBS='2',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',PYTHONDONTWRITEBYTECODE='1',CHECK_TIMINGS=str(O/'timings.tsv'))
Path(env['TMPDIR']).mkdir(exist_ok=True)
temp_free_bytes=shutil.disk_usage(env['TMPDIR']).free
assert temp_free_bytes>=2040109465,'Root-approved whole-gate orchestration STARTUP floor1.9GiB on actual temporary filesystem; native assertions unchanged'
def git(*args):
    return subprocess.check_output(['git','-c','core.preloadIndex=false',*args],cwd=R,env={**env,'GIT_NO_LAZY_FETCH':'1'})
assert git('rev-parse','HEAD').decode().strip()==HEAD_BEFORE
assert not (R / git('rev-parse','--git-path','MERGE_HEAD').decode().strip()).exists(),'Freshbranch has no outstandingmerge'
assert git('merge-base','origin/dev','HEAD').decode().strip()==BASE
assert not git('diff','--name-only','--diff-filter=U').strip()
remote=json.loads(urllib.request.urlopen('https://api.github.com/repos/kevinrhaas/chicago/git/ref/heads/dev').read())
(O/'fresh-remote-base.json').write_text(json.dumps(remote,indent=2)+'\n')
remote_head=remote['object']['sha']
if remote_head!=BASE:
    comparison=json.loads(urllib.request.urlopen('https://api.github.com/repos/kevinrhaas/chicago/compare/'+BASE+'...'+remote_head).read())
    (O/'fresh-remote-merge-base.json').write_text(json.dumps(comparison,indent=2)+'\n')
    assert comparison['merge_base_commit']['sha']==BASE,'The actual fresh remote merge base changed'
paths=git('diff','HEAD','--name-only','-z').decode().split('\0')+git('ls-files','--others','--exclude-standard','-z').decode().split('\0')
paths += list(json.loads((H/'ACCEPTED-DOCS-ONLY-SOURCE-UPDATE.json').read_text())['source_after_documenting_natural_GT_fuel'])
paths=sorted(set(p for p in paths if p))
assert paths and all(p.startswith('chicago/4d/')for p in paths),paths
subprocess.run(['git','add','-A','--','chicago/4d'],cwd=R,env=env,check=True)
assert all(p.startswith('chicago/4d/')for p in git('diff','--cached','--name-only').decode().splitlines())
tree=git('write-tree').decode().strip()
bound={p:hashlib.sha256((R/p).read_bytes()).hexdigest()if(R/p).is_file()else None for p in paths}
(O/'SOURCE-BINDING.json').write_text(json.dumps({'base':BASE,'head':HEAD_BEFORE,'incoming_merge_parent':INCOMING,'fresh_remote_head':remote_head,'staged_tree':tree,'paths':bound,'temp_free_bytes':temp_free_bytes,'cgroup_memory_limit_start':mem_limit,'cgroup_memory_current_start':mem_current,'caller_reserve_start':mem_limit-mem_current,'orchestration_floor_bytes':2040109465,'orchestration_floor_authority':'Root2026-10-26 current instruction: whole-gate STARTUP floor1.9GiB;512MiB floor applies only remaining native tasks; do not kill a healthy running gate on transient dips. Native checks/assertions unchanged, no exports/bulk copies','all_required_readers':True,'all_required_base':True,'jobs':2,'cpu_affinity':sorted(os.sched_getaffinity(0)),'ticket_environment_override_absent':True,'scope':'Fresha575base with one boundedGTyardpolicy, citedmetadata and exactcheckedfourtoolrepairs. Actualnative202/7/57,all44audit,physicalsourcecontrols,pkg5andpublisherclosed beforewholegate. Sourceandstagedtreefrozen; noopaquefetch. Nativeprecommitmergebasea575 verifiedagainstfreshremote lineage. ActualcommittedHEADCL/IDquestions repeat after normalcodecommit.'},indent=2)+'\n')
(O/'source.binary.patch').write_bytes(git('diff','--cached','--binary'))
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
commands=[['bash','tools/check.sh'],['node','tools/check-changelog-entry.mjs',BASE,'HEAD'],['node','tools/resolve_id_collisions.mjs','--base','origin/dev','--check']]
results=[]
for i,command in enumerate(commands):
    assert int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text())>=512*1024**2,'Root-required512MiB caller reserve before command'
    log=O/['check.log','changelog-entry.log','ids.log'][i]
    with log.open('x')as stream:
        process=subprocess.run(command,cwd=A,env=env,stdout=stream,stderr=subprocess.STDOUT)
    results.append({'command':command,'exit_code':process.returncode,'log':str(log)})
    print('ACTUAL_REQUIRED_COMMAND',i,process.returncode,str(log),flush=True)
    if process.returncode:
        break
unchanged=all((hashlib.sha256((R/p).read_bytes()).hexdigest()if(R/p).is_file()else None)==value for p,value in bound.items())
same_tree=git('write-tree').decode().strip()==tree
work_index_clean=subprocess.run(['git','diff','--quiet'],cwd=R,env=env).returncode==0
text=re.sub(r'\x1b\[[0-9;]*m','',(O/'check.log').read_text(errors='replace'))
footer=text.splitlines()[-4:]
gate=re.search(r'CHECK PASS — (\d+) steps, none red\.', '\n'.join(footer))
selftests=re.search(r'(\d+) of them are self-tests','\n'.join(footer))
passed=len(results)==3 and all(r['exit_code']==0 for r in results)and unchanged and same_tree and work_index_clean and bool(gate)and bool(selftests)
result={'status':'PASS'if passed else'FAIL','started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'staged_tree':tree,'jobs':2,'cpu_affinity':sorted(os.sched_getaffinity(0)),'source_unchanged':unchanged,'index_tree_unchanged':same_tree,'working_index_clean':work_index_clean,'actual_gate_steps':int(gate[1])if gate else None,'actual_self_tests':int(selftests[1])if selftests else None,'footer':footer,'commands':results,'incoming_merge_parent':INCOMING,'head_before_codecommit':HEAD_BEFORE,'committed_HEAD_PR_event_checks':'OWED after normal checked codecommit'}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
raise SystemExit(0 if passed else 1)
