# Independent review: minimum Dearborn profile

Reviewed the immutable44member implementation packet, all twelve source changes, the native compiler/mesh ownership path, the shared numeric sampler, current walker/router/human callers, complete anchor measurement selection, native frontage floor consumers and the smoke's existing flat-bridge assertions. All44 member sizes and SHA256s matched their manifest. No canonical source edits, adoption, export or browser run occurred.

## Finding P2: compiler can emit an internally inconsistent legal profile

Candidate `chicago/4d/tools/compile_scene.py:266` rounds the old scalar `walk_surface_m` to four decimal places. The new profile reader at line284 preserves the native parameter's full float height. An explicit, otherwise legal `deck_height_m=2.22222` therefore emits scalar2.2222 with profile endpoint2.22222. `deck-surface.js:50` rejects that declaration because its strict endpoint/base agreement tolerance is1e-8.

This was reproduced by executing the **exact two candidate compiler functions**, isolated through their AST, on a legal profiled Dearborn record. Actual native bridge parameters accepted it; the exact candidate `deckFromSidecar` refused its emitted descriptor. `ROUNDING-COUNTEREXAMPLE.json` and `ROUNDING-RESULT.json` preserve the input and result. This is not a full-scene compile.

The selected current2.22m candidate is unaffected, but the new public profile contract must serialize one consistent base for every supported input. Preserve exact native mesh/profile height and old scalar-only rounding behavior; do not loosen the runtime validator or round only the profile endpoints to mask the mismatch. Finding sent directly to the author for a narrow correction.

## Finding P3: contradictory source note

Candidate `chicago/4d/data/structures/dearborn_street_drawbridge.json:173` says “The deck remains flat at its previous height” in the support note, while the same record now opts into the1.2m peaked profile. Preserve the support correction and its provenance, but update that stale sentence. This is source/card prose, not a geometry defect.

## Other review results and actual residual risks

No additional concrete current-candidate defect was identified. The profile uses the same local-x draw-rise function as physical mesh displacement. The ENU inversion and bearing convention in the shared sampler are consistent with the pinned GLB contract. Highest-covering-deck, water, ground and scalar-only behavior remain in the existing consumers. The human hook switches to the profiled floor only where a profiled deck covers the point; unrelated humans retain their old terrain placement. `main.js` constructs and extends the shared decks array before passing its closure to humans. The router's cached descriptors retain the profile frame while bbox fields remain separate. Existing North Branch smoke exact-scalar assertions are specifically about the unchanged North Branch bridge and do not need weakening.

The producer's split-and-fold operation runs before vertical gallows/tackle, leaves retained cribs horizontal, and uses the same rise at the central chain attachment. Default behavior is guarded by early flat branches, with meaningful author's six-default complete raw-mesh/material/confidence comparisons. I read those proof inputs/results; I did not rerun the author's full fixture suite or native exports. My independently executed test was the concrete compiler/consumer precision counterexample.

Omitting the old global yard/horse/vehicle changes is safe **only after** current whole emitted yard geometry and unchanged horse/vehicle asset extents are proved clear of the changed draw polygon. Source anchors alone do not bound long timber, bodies, wheels or support regions. That required proof must bind the actual batch's scene/yard/asset inputs and cover any existing relevant placements; it is not supplied by the1422-anchor scan or this code review. No placement on a slope is authorized by the new numeric floor contract. No new broad renderer architecture is requested.

Actual pinned six-family production and derivatives, adopted full-scene compiler output, complete native anchor reading, current-terrain approach/deck-edge contacts, published phone/desktop walker/human review and policy checks remain owed. The profile is expressly a nominal plank-top proxy across8mm gaps and below55mm proud timbers, not a topmost-mesh, wheel/hoof or shoe/IK certificate. Those documented bounds are retained. OriginalT2375 stays open/differs until its whole pictured geometry is reviewed; no new photo follow-up is requested.
