# Closed LIGHT fort-family composition checkpoint

Utilities T-3122 M, T-3123 S and T-3124 S were filed and claimed normally. This is an uncommitted source proposal, not release-ready code or fresh generated assets. Old PR1282 source308b stays independently frozen/root-owned.

The ZIP has14 after-images and12 before-images, all26 SHA256/CRC checked. The tracked patch excludes two new source files; recover them only from the ZIP. All incoming ledger prefix bytes are retained. The final source normalizes human prose, a dead docstring liberty ID and two duplicate NEW Covers claims, with the independent CPU/value/AST guards listed separately.

Independent actual source CPU builds show exactly three changes: lighthouse132→8021tri (exact full old prototype stream), Lake66→64tri (only360m²cap removed), officers1764→3382tri (all old physical faces/openings preserved). The other22 complete geometry/material/confidence/tone/normal streams are exact. This proves no Blender backend, exported bytes, web quantization, GPU material, terrain or app result.

Atomic adoption plan requires two genuine family refreshes plus one data-only target refresh, with each intermediate commit fresh and checked; no prototype GLBs/input hashes may be copied. Final native/app/fullgate/CI remain owed. Original2373/2379/2388 stay OPEN/DIFFERS with all picture/camera/date/rights obligations.

The first draft CPU positive-flat fixture used a nonexistent MeshBuilder.materials attribute; it was corrected to the actual mat_index with no assertion weakening or product change. The failed draft and latest PASS are explicitly distinguished.
