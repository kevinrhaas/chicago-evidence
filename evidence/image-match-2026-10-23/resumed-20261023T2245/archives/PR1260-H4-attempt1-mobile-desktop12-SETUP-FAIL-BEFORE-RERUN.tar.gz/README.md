Two actual attempt1 setup failures on exact head5d9d44646f49c69a4add36ece56bfbdab8caad70, preserved BEFORE any rerun request.

Desktop1-2 run40069326565/job120799148049 and mobile1-2 run40069331808/job120799164305 both checked out the exact head and then failed Playwright installation: 'Playwright does not support chromium on ubuntu26.04-x64'. The smoke body did not start; no staged assertion counts or zero-page-error claim exists for these attempts. Requests identify stages1-2, but those stages were not exercised.

Raw logs, job metadata, exact receipt and06:35 snapshot are retained unchanged. At that snapshot7 other groups passed,9 were running, and these2 attempts failed. The root authorized one normal rerun-failed-jobs request per failed run only after this proof was frozen. Any rerun is separate evidence and never overwrites these failures. This packet contains no rerun action or result, code/workflow/assertion change, approval or waiver.
