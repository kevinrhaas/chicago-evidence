# T-2376: restore the pictured middle sash on the south wall

**Ready as an unadopted, picture-led form correction. No source, geometry, camera or match record has been adopted or exported.** The existing wagon-bay work, its fourteen candidate files, and the exact compressed BEFORE archive remain intact. This is the same original T-2376 unit; it needs no new ticket, archetype API, structure version, licence finding or family rebake.

Both held illustrations show seven window stations on each floor of the long elevation. Andreas/Braunhold's reproduction shows a narrow sash at the middle lower station. Trowbridge's upright reproduction and the actual unmodified Gale 1902 plate also show a sash there. The frontmost lower Trowbridge sash is partly obscured by the sign/people; its middle lower sash is clear. These are manually read opening counts, not a camera solve or dimensions measured from a drawing. `PICTURE-READING.json` pins the actual images and counting qualifications.

The current model already has seven stations on the south wall. It substitutes a 1.20 m wide, floor-level door at the fourth lower station, leaving six lower sash. Setting the existing `side_entrance.value` from `"south"` to `null` retains the normal stock sash at that station: seven lower sash and seven upper sash. The existing parser accepts this value without changes, and the actual in-memory schema/parameter probe confirms that **only `side_entrance_face` changes, from `x_min` to `None`**. The current input hash matches the committed master, and the proposed hash differs honestly. `STATIC-PROBE.json` records the exact results.

This is a visible correction under T-3153: the stock sash is 0.35 m narrower than the substituted door and its sill is 0.75 m above the former door bottom. Its head stays at 2.10 m. The station remains local v = 6.095 m, with v bounds 5.670–6.520 m. Those are **existing model dimensions**, not archival measurements. The primary front entrance and every other resolved parameter remain exact.

## Evidence and counterevidence

- `andreas_1884_green_tree_hotel_plate` is a verified public-domain 1884 illustration. The held reproduction's caption “1838” does **not** date the original Andreas plate, whose caption is undated. “Braunhold” remains the reproduction/brief's attribution, not a newly verified signature.
- `trowbridge_green_tree_1902` is the verified public-domain illustration in Gale 1902, facing printed p. 35, original scan n55. I inspected that held original page: its caption retrospectively names 1835. It establishes neither a precise July-1835 fitting nor an independent contemporary witness. The upright reproduction and original have the same relevant opening pattern.
- The old `chicagology_prefire127` source records John Gray's recollection of an entrance “on the Lake street front about the middle of the long side.” Gray kept the inn in 1838–41, and the published recollection is from 1883. This is substantial counterevidence, not something to delete or pretend disproved. No source dates the door's construction or proves it was absent in July 1835. The proposal preserves the quotation and its meaning in the attribute note and Liberty amendment.

The proposed attribute remains **inferred**, on the pictured opening pattern. `null` selects no special side-door substitution; it is **not** an attested finding that a side door never existed. The two picture IDs alone appear in the proposed attribute's geometry sources. Gray's check-required website record is retained as textual counterevidence, not a source for new geometry or a new rights clearance. No c.1859 photograph is used. This is an explicit picture-priority choice for the 1835 reconstruction, with uncertainty retained.

## Exact change and adoption guard

`green_tree_tavern.record.preimage.json` is the exact current record, SHA256 `7ee5fc41e5c489a21a6044d082c6cd746fce538870020a0fac1067a125c10167`. The proposed record changes only `phases[0].form.side_entrance` (value, sources and explanatory note); reverting that one attribute restores the original object exactly. The inferred confidence label is retained.

Use `owned-attribute-only.jsonpatch` on the **incoming checked Tremont candidate**, after its `test` verifies the exact attribute preimage. Do not copy this proposal's whole record over incoming changes. The preimage/proposed attribute files and unified diff are review artifacts, not live source edits. Preserve Tremont's entire incoming smoke file, both new Tremont probes, its generic repairs and exact 283-ID set.

Append the draft `LIBERTY-AMENDMENT.draft.md` field to existing `L-green-tree-seven-bays-T-2376`; do not erase the historical side-door reading. Carry the same disagreement into the dossier and concise T-2376 release entry. Let the native Liberty/source-use owners regenerate their own JSON. The existing source cards must retain the two illustration credits and the later Gray counterevidence.

## Incremental build price and proof

The native manifest has **23 frame-tavern rows**. This proposal needs **one selected master and one WEB derivative**; the other 22 rows and all unrelated assets remain protected. There are no Green Tree structure versions. Current target sizes are 211,760 B master and 40,552 B WEB: **252,312 B** to preserve both exact preimages, before small registry/source backups. These are storage readings, not a promised size or measured duration for the new outputs. The pinned Blender 4.5.3 binary and glTF-Transform 4.5.0 toolchain are already installed; no download is needed. Native temporary memory/time must be measured under a later resource lease. No AO bake is proposed; normal UV/export remains on.

Under that later lease, use the normal production writer and derivative command, not a scratch mesh or fingerprint edit:

```bash
source /workspace/shared/resume-chicago-env.sh
GT_BAKE_EVIDENCE=/workspace/T2376-south-sash-native-20261026
test -d "$GT_BAKE_EVIDENCE" # prepare this separate evidence directory only at adoption
/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender \
  -b -noaudio --factory-startup --python generators/build.py -- \
  --only green_tree_tavern --scene 1835 --wrote "$GT_BAKE_EVIDENCE/masters-wrote.txt"
bash tools/web_derivatives.sh --only green_tree_tavern__frame_1833.glb
```

The build CLI's selected path writes only the selected phase; its `--wrote` receipt must name exactly that one master. Verify the official pin/binary and all four glTF packages before export. Snapshot all physical GLBs and registries first; prove all unrelated masters/WEBs and registry rows byte-exact afterward. Do not re-export the family. Verify the actual new master and compressed WEB contain the additional middle sash, no side-door leaf there, unchanged bounds/other openings/materials, and the honest new input fingerprint. The primary entrance/apron must remain exact: `generate_entrances.py` reads `resolved_front_ground_stations`, which this proposal does not change.

This fits **before GT's first checked candidate**, so its existing owed native rebuild, all-44 binary audit, protected people/yard checks, package/publish, whole preflight and full 18-group matrix are run once for the combined wagon-bay + sash unit. These are still owed, not passes supplied by this proposal. Native regeneration may update other source backlinks/reports; classify actual outputs instead of silently restoring semantic changes.

Retain the existing fixed Andreas comparison camera and perform a new actual `photo_match.mjs` review against the new GLB. Add/fit a Trowbridge reference view against the held upright picture if no formal view exists; keep footprint and geographic coordinates fixed and disclose drawing/camera residuals. Inspect the selected **published WEB** in ordinary mobile and desktop app loads, normal and ByGrade, with credited Images/Sources and the revised Liberty visible. Preserve the prior desktop native-capture timeouts; do not weaken their bounds or relabel the old runs.

Only after actual exported/rendered/app evidence verifies the sash should the long-wall discrepancy change from `open` to `fixed`. A changed GLB resets the previous match record to `unreviewed`; review it rather than carrying its old SHA or claiming `matches`. The enclosed-annex massing remains `open` unless separately adjudicated from the conflicting pictures. **This proposal does not close original T-2376 or assert the whole image case matches.**
