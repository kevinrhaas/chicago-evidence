from pathlib import Path
import subprocess,os,json,urllib.request,urllib.parse,hashlib,zlib,concurrent.futures,datetime,time,shutil,base64
B=Path('/tmp/current-dev-refresh-20261026-ce89');R=Path('/tmp/chicago-current-objects-20261025');C=Path('/workspace/chicago');G=C/'.git'
env=dict(os.environ);env['GIT_NO_LAZY_FETCH']='1'
if 4 in os.sched_getaffinity(0): os.sched_setaffinity(0,{4})
def git(repo,*args,input=None):
 return subprocess.check_output(['git','-C',str(repo),'-c','gc.auto=0','-c','maintenance.auto=false','-c','core.preloadIndex=false','-c','index.threads=1',*args],input=input,env=env)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
 paths=[G/'HEAD',G/'index',G/'config']
 return {'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata_hashes':{str(p):digest(p)for p in paths if p.is_file()}}
before=snapshot();(B/'SHARED-BEFORE.json').write_text(json.dumps(before,indent=2)+'\n')
price=json.loads((B/'PRICE.json').read_text());head=price['dev'];tree=git(R,'rev-parse',head+'^{tree}').decode().strip();assert tree=='09021f31575c50d4eaf835b220bbe0609889e1f4'
api=json.loads((B/'tip-recursive-tree.json').read_text());actual={}
for raw in git(R,'ls-tree','-r','-z',head).split(b'\0'):
 if raw:
  meta,name=raw.split(b'\t',1);mode,kind,sha=meta.decode().split();actual[name.decode()]={'mode':mode,'type':kind,'sha':sha}
assert len(actual)==len([x for x in api['tree']if x['type']=='blob'])
for row in api['tree']:
 if row['type']=='blob':assert actual[row['path']]=={k:row[k]for k in ['mode','type','sha']},row['path']
price['api_response_sha_alias']=api['sha'];price['tree']=tree;(B/'PRICE.json').write_text(json.dumps(price,indent=2)+'\n')
pack_rows=[];allocation=0
for pack in sorted((R/'objects/pack').glob('*.pack')):
 idx=pack.with_suffix('.idx');v=git(R,'verify-pack','-v',str(idx));(B/(pack.stem+'-verify.log')).write_bytes(v)
 data=pack.read_bytes();assert hashlib.sha1(data[:-20]).digest()==data[-20:]
 for file in [pack,idx,pack.with_suffix('.promisor')]:
  if not file.exists():continue
  dest=G/'objects/pack'/file.name
  if dest.exists():assert file.read_bytes()==dest.read_bytes();new=False
  else:
   tmp=dest.with_name('.'+dest.name+'.import-'+str(os.getpid()));shutil.copy2(file,tmp);assert digest(file)==digest(tmp);tmp.rename(dest);new=True;allocation+=dest.stat().st_blocks*512
  pack_rows.append({'file':str(dest),'bytes':file.stat().st_size,'sha256':digest(file),'new':new})
(B/'PACK-IMPORT.json').write_text(json.dumps({'packs':pack_rows,'allocated_bytes':allocation},indent=2)+'\n')
missing={r['sha']:r for r in price['missing_blob_paths']};assert len(missing)==36 and sum(x['size']for x in missing.values())==23131539
def download(row):
 sha=row['sha'];size=row['size'];dest=G/'objects'/sha[:2]/sha[2:]
 assert not dest.exists(),'Unexpected simultaneous writer for '+sha
 url='https://raw.githubusercontent.com/kevinrhaas/chicago/'+head+'/'+urllib.parse.quote(row['path'],safe='/')
 if row['mode']=='120000':url='https://api.github.com/repos/kevinrhaas/chicago/git/blobs/'+sha
 for attempt in range(3):
  try:
   with urllib.request.urlopen(url,timeout=90)as response:
    data=response.read(size*2+65536)
   if row['mode']=='120000':
    parsed=json.loads(data);assert parsed['encoding']=='base64';data=base64.b64decode(parsed['content'])
   assert len(data)==size,(row['path'],len(data),size)
   raw=b'blob '+str(len(data)).encode()+b'\0'+data
   assert hashlib.sha1(raw).hexdigest()==sha,row['path']
   encoded=zlib.compress(raw)
   dest.parent.mkdir(exist_ok=True)
   tmp=dest.with_name(dest.name+'.import-'+str(os.getpid()))
   with tmp.open('xb')as f:f.write(encoded)
   assert hashlib.sha1(zlib.decompress(tmp.read_bytes())).hexdigest()==sha
   tmp.rename(dest)
   return {'sha':sha,'path':row['path'],'bytes':size,'sha256':hashlib.sha256(data).hexdigest(),'compressed_bytes':len(encoded),'allocated_bytes':dest.stat().st_blocks*512}
  except Exception:
   if attempt==2:raise
   time.sleep(attempt+1)
rows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:
 for row in pool.map(download,missing.values()):
  rows.append(row);allocation+=row['allocated_bytes']
  assert allocation<=100*1024**2,allocation
  if len(rows)%50==0:
   (B/'DOWNLOAD-PROGRESS.json').write_text(json.dumps({'completed':len(rows),'total':len(missing),'allocated_bytes':allocation})+'\n');print('BLOBS',len(rows),'/',len(missing),'allocated',allocation,flush=True)
(B/'BLOB-IMPORT.json').write_text(json.dumps({'rows':rows,'allocated_total_bytes':allocation},indent=2)+'\n')
ids=sorted({r['sha']for r in api['tree']if r['type']=='blob'})
batch=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();assert not any(x.endswith(' missing')for x in batch)
sizes={x.split()[0]:int(x.split()[2])for x in batch}
assert all(sizes[r['sha']]==r['size']for r in api['tree']if r['type']=='blob')
assert git(C,'rev-parse',head+'^{tree}').decode().strip()==tree
assert git(C,'merge-base',head,'cb93ad9cd5ea38654737e05002b1f1904be14e54').decode().strip()=='cb93ad9cd5ea38654737e05002b1f1904be14e54'
after=snapshot();assert after['metadata_hashes']==before['metadata_hashes'],'Unexpected protected root metadata change before explicit remote-ref update'
with urllib.request.urlopen('https://api.github.com/repos/kevinrhaas/chicago/git/ref/heads/dev',timeout=40)as r:remote=json.load(r)
current=remote['object']['sha'];(B/'REMOTE-BEFORE-REF-UPDATE.json').write_text(json.dumps(remote,indent=2)+'\n')
updated=False
if current==head:
 old=git(C,'rev-parse','refs/remotes/origin/dev').decode().strip()
 git(C,'update-ref','refs/remotes/origin/dev',head,old);updated=True
final=snapshot()
assert final['metadata_hashes']==before['metadata_hashes']
other_before=[x for x in before['refs']if not x.startswith('refs/remotes/origin/dev ')];other_after=[x for x in final['refs']if not x.startswith('refs/remotes/origin/dev ')];other_changes={'removed':sorted(set(other_before)-set(other_after)),'added':sorted(set(other_after)-set(other_before))}
result={'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'READY'if updated else'OBJECTS_READY_REMOTE_ADVANCED','dev':head,'tree':tree,'fresh_remote_dev':current,'origin_dev_updated':updated,'tip_blob_unique_count':len(ids),'new_blob_count':len(rows),'new_blob_uncompressed_bytes':sum(x['bytes']for x in rows),'new_object_allocated_bytes':allocation,'all_tip_object_membership_and_sizes_verified':True,'all_new_blob_content_hashes_verified':True,'known_common_ancestor':'cb93ad9cd5ea38654737e05002b1f1904be14e54','root_index_HEAD_config_unchanged':True,'other_ref_observed_changes':other_changes,'active_child_indices_not_asserted':True,'workspace_free':shutil.disk_usage('/workspace').free}
(B/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');(B/'SHARED-AFTER.json').write_text(json.dumps(final,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
