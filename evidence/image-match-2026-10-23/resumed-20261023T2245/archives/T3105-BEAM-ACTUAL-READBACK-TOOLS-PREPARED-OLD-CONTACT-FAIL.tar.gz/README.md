# Five actual gallery joints — readback tool PREPARED

No corrected export is claimed. The old five master GLBs currently fail this contact oracle by approximately58mm; an actual old web decoded by the real GLTFLoader/MeshoptDecoder also fails by57.999mm. These negatives are preserved. Source-plane toy positive and coplanar-timber-top negative controls verify the local ruler, not a corrected asset. No Blender, browser, GPU rendering, native writer, or full gate was run.

After the owner finishes genuine25master/web regeneration, run outside the inspected root:

```bash
NODE_DISABLE_COMPILE_CACHE=1 PYTHONDONTWRITEBYTECODE=1 python3 /tmp/T3105-beam-actual-readback-prepared/readback.py --root /tmp/chicago-log-integration/chicago/4d --out /workspace/T3105-beam-corrected-actual-readback-001 --web-quant-bits 14
```

Use a new nonexistent output directory for every timepoint. The tool refuses an output inside the inspected canonical root. It writes only decoded web readbacks and a receipt in that new directory. A command failure remains a failure; it does not create/relabel corrected assets or mutate any source/asset. The caller must bind the actual native derivative command's14-bit POSITION setting; if that setting changes, review the bound and use the actual supported16-bit argument rather than copying a stale assumption.

The master path uses the verbatim native `tools/measure_glbs.py` GLB reader/world transforms, reads indexed actual FLOAT POSITION triangles, and checks structure/phase identity. Roof triangles and the actual low chinking/post/beam-bottom triangle streams must remain exact against public `9e757f0bd` masters. This comparison includes material role and winding, but not UVs/normals/tone; the owner's independent physical/material/default20 proof covers those separately. At this read-only preparation timepoint all baseline GLBs are exact Git objects from9e757, not reconstructed geometry.

The web path uses the copied actual Three0.185.1 GLTFLoader and MeshoptDecoder in Node, never a browser or imitation decoder. Its only import adapter rewrites bare-three and two relative addon imports to local native modules/dataURLs; vendor files remain verbatim. It applies the actual node world matrix, normalized integer POSITION accessors and all actual indices. This is CPU/dequantisation proof, not GPU/contact-pixel acceptance. Textured, skinned/morphed, non-diagonal dequantisation frames, unknown POSITION encodings and lossy POSITION compression filters are refused rather than guessed.

Both paths locate the four existing canopy corners and four beam upper corners from actual material-role vertices, using the source footprint solely to distinguish the intended surfaces. They calculate the plane through the actual roof vertices, measure all beam upper-corner residuals, and reject any coplanar timber triangle in the beam region. Master Float32 contact allowance is2µm; the independent raw source proof already required~1e-12m. This is a precision bound, not permission to leave a2µm designed gap.

For web, error is derived per axis from the actual normalizedSHORT dequantisation node scale and the known native POSITION quantisation bits: a full rung `E_axis = 2*abs(scale_axis)/(2^bits−1)`. The full rung conservatively covers nearest quantisation plus SHORT repacking; EXT_meshopt integer compression is lossless and an unexpected lossy POSITION filter is refused. Because a beam point lies between the roof's two depth endpoints, both it and the convex-interpolated endpoints contribute error. The vertical contact bound is `2*E_height + 2*abs(source_slope)*E_depth + 2µm`; source_slope is0.45/2.25=0.2. Each measured beam/canopy web corner must also match an actual current-master counterpart within its per-axis rung. It is not a free tolerance for a different shape.

For the actual old officers-barracks derivative the decoded scale gives0.00085149238m per-axis rung and derived contact bound0.00204558171m. That roughly2.05mm value is computed from that asset's true quantisation domain, not an invented2mm threshold; the old57.999mm separation fails clearly. Other ranges get their own bounds from their actual node scales. Float master passthroughs retain the2µm master bound.

`preparation-checks.json` distinguishes native old-web decode success from actual old contact failure, and explicitly labels source-plane controls as toys. The initial import-wrapper omission of SkeletonUtils is recorded there; it was corrected without changing native source or geometric assertions. The old actual master negative receipt is copied under `old-master-negative.json`. Corrected actual run, official asset freshness, web/GPU appearance, source comparisons (stillDIFFERS) and final gates remain owed.

`MANIFEST.json` freezes this preparation. Future receipts live outside the package. This is a small independent diagnostic for these five assets, not a new shared pipeline or canonical gate.
