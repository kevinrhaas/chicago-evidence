import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const vendor=path.join(here,'native/three-0.185.1');
const three=pathToFileURL(path.join(vendor,'three.module.js')).href;
const rewrite=s=>s.replaceAll("from 'three'",`from '${three}'`);
const data=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
const utils=data(rewrite(fs.readFileSync(path.join(vendor,'addons/utils/BufferGeometryUtils.js'),'utf8')));
const skeleton=data(rewrite(fs.readFileSync(path.join(vendor,'addons/utils/SkeletonUtils.js'),'utf8')));
const loaderSource=rewrite(fs.readFileSync(path.join(vendor,'addons/loaders/GLTFLoader.js'),'utf8'))
  .replaceAll("'../utils/BufferGeometryUtils.js'",JSON.stringify(utils))
  .replaceAll("'../utils/SkeletonUtils.js'",JSON.stringify(skeleton));
const {GLTFLoader}=await import(data(loaderSource));
const {MeshoptDecoder}=await import(pathToFileURL(path.join(vendor,'addons/libs/meshopt_decoder.module.js')));
const THREE=await import(three);
const [asset,output]=process.argv.slice(2);
const raw=fs.readFileSync(asset), len=raw.readUInt32LE(12), json=JSON.parse(raw.subarray(20,20+len));
const [sid,phase]=path.basename(asset,'.glb').split('__');
const identities=json.nodes.filter(n=>n.extras?.structure_id);
if(identities.length!==1||identities[0].extras.structure_id!==sid||identities[0].extras.phase_id!==phase)
 throw Error('web structure/phase identity differs from its selected path');
if(json.images?.length)throw Error('bounded readback refuses textured assets');
for(const mesh of json.meshes)for(const primitive of mesh.primitives){
 const a=json.accessors[primitive.attributes.POSITION],v=json.bufferViews[a.bufferView];
 const filter=v.extensions?.EXT_meshopt_compression?.filter;
 if(filter&&filter!=='NONE')throw Error('unknown lossy POSITION meshopt filter '+filter);
}
const loader=new GLTFLoader();loader.setMeshoptDecoder(MeshoptDecoder);
await MeshoptDecoder.ready;
const gltf=await loader.parseAsync(raw.buffer.slice(raw.byteOffset,raw.byteOffset+raw.byteLength),'');
gltf.scene.updateMatrixWorld(true);
const rows=[];
gltf.scene.traverse(o=>{
 if(!o.isMesh)return;
 if(o.isSkinnedMesh||o.morphTargetInfluences)throw Error('bounded readback refuses skinned/morph geometry');
 const p=o.geometry.getAttribute('position'),i=o.geometry.index,m=o.matrixWorld.elements;
 if(Array.isArray(o.material))throw Error('bounded readback expects one material per glTF primitive');
 if(!i||i.count%3)throw Error('indexed triangles required');
 if([1,2,4,6,8,9].some(k=>Math.abs(m[k])>1e-12)||m[0]<=0||m[5]<=0||m[10]<=0)
   throw Error('unknown non-diagonal dequantisation frame');
 const kind=p.array.constructor.name;
 if(!((kind==='Int16Array'&&p.normalized)||(kind==='Float32Array'&&!p.normalized)))
   throw Error('unknown POSITION encoding '+kind);
 const positions=[];
 for(let k=0;k<p.count;k++){
  const v=new THREE.Vector3(p.getX(k),p.getY(k),p.getZ(k)).applyMatrix4(o.matrixWorld);
  if(![v.x,v.y,v.z].every(Number.isFinite))throw Error('nonfinite decoded position');
  positions.push([v.x,-v.z,v.y]);
 }
 rows.push({material:o.material.name,positions,indices:Array.from(i.array),encoding:kind,
   normalized:p.normalized,node_scale_native_xyz:[m[0],m[10],m[5]],
   matrix_world:Array.from(m)});
});
if(!rows.length)throw Error('no meshes');
fs.writeFileSync(output,JSON.stringify({asset,rows}));
