#!/usr/bin/env python3
"""Bounded actual five-gallery master/web readback; no renderer or asset writer."""
from pathlib import Path
import argparse, collections, hashlib, importlib.util, json, math, struct, subprocess, sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('native_measure_glbs', HERE/'native/measure_glbs.py')
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def master(path):
    j, bins = native.read_glb(path)
    if j.get('images') or j.get('extensionsRequired'):
        raise ValueError('bounded master reader expects ordinary textureless exported glTF')
    found, world = native.find_structure_nodes(j)
    sid, phase = path.stem.split('__')
    if len(found)!=1 or found[0][0]!=sid or j['nodes'][found[0][1]]['extras'].get('phase_id')!=phase:
        raise ValueError('actual master structure/phase identity differs from its selected path')
    def acc(index):
        a=j['accessors'][index];v=j['bufferViews'][a['bufferView']]
        fmt={5126:'f',5123:'H',5125:'I'}[a['componentType']]
        n={'SCALAR':1,'VEC3':3}[a['type']]
        stride=v.get('byteStride',struct.calcsize(fmt)*n)
        offset=v.get('byteOffset',0)+a.get('byteOffset',0)
        return [struct.unpack_from('<'+fmt*n,bins[v.get('buffer',0)],offset+k*stride)
                for k in range(a['count'])]
    rows=[]
    for ni,node in enumerate(j['nodes']):
        if 'mesh' not in node:continue
        for p in j['meshes'][node['mesh']]['primitives']:
            points=[native.apply(world[ni],v) for v in acc(p['attributes']['POSITION'])]
            if any(not all(math.isfinite(x) for x in p) for p in points):
                raise ValueError('nonfinite actual master position')
            rows.append({'material':j['materials'][p['material']]['name'],
                         'positions':[(x,-z,y) for x,y,z in points],
                         'indices':[v[0] for v in acc(p['indices'])]})
    return rows


def points(rows,mat):
    return [tuple(p) for r in rows if r['material']==mat for p in r['positions']]


def triangles(rows,mat,predicate=lambda _:True):
    result=[]
    for r in rows:
        if r['material']!=mat:continue
        for k in range(0,len(r['indices']),3):
            t=tuple(tuple(r['positions'][i]) for i in r['indices'][k:k+3])
            if predicate(t):result.append(min(t,t[1:]+t[:1],t[2:]+t[:2]))
    return collections.Counter(result)


def contact(rows,rec,error):
    w,d,h=rec['width'],rec['depth'],rec['wall_height'];head=h-.45;bottom=head-.14
    expected=[(0,d,h),(w,d,h),(w,d+2.25,head),(0,d+2.25,head)]
    roofpoints=points(rows,'roof_shingle');trim=points(rows,'chinking')
    e=max(error)+2e-6
    roof=[min(roofpoints,key=lambda p:max(abs(a-b) for a,b in zip(p,q))) for q in expected]
    if any(any(abs(a-b)>err+2e-6 for a,b,err in zip(p,q,error)) for p,q in zip(roof,expected)):
        raise ValueError('actual canopy corners do not match unchanged nominal canopy')
    a,b,c=roof[:3];u=[y-x for x,y in zip(a,b)];v=[y-x for x,y in zip(a,c)]
    n=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
    if abs(n[2])<1e-9:raise ValueError('degenerate canopy')
    residual=lambda p:sum(z*(y-x) for z,x,y in zip(n,a,p))/n[2]
    in_beam=lambda p:-e<=p[0]<=w+e and d+1.96-e<=p[1]<=d+2.1+e and bottom-e<=p[2]<=h+e
    upper=set(p for p in trim if in_beam(p) and p[2]>bottom+2*e)
    if len(upper)!=4:raise ValueError('expected exactly four actual beam upper corners')
    maximum=max(abs(residual(p)) for p in upper)
    # Position quantisation is bounded per axis by a full native rung. Both the
    # point and convex-interpolated canopy endpoints contribute error. Master
    # Float32 source-plane error is bounded separately by 2um, not called exact.
    bound=2*error[2]+2*.2*error[1]+2e-6
    if maximum>bound:raise ValueError(f'beam/canopy separation {maximum:.9g}m exceeds derived {bound:.9g}m')
    topfaces=triangles(rows,'chinking',lambda t:all(in_beam(p) for p in t)
                       and all(abs(residual(p))<=bound for p in t))
    if topfaces:raise ValueError('coplanar timber top triangles under canopy')
    return {'upper_corners':sorted(upper),'actual_canopy_corners':roof,
            'max_vertical_contact_residual_m':maximum,'derived_vertical_bound_m':bound,
            'per_axis_position_error_bound_m':error,'coplanar_timber_top_triangles':0}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--web-quant-bits',type=int,choices=[14,16],required=True)
    args=ap.parse_args()
    if args.out.resolve().is_relative_to(args.root.resolve()):
        ap.error('read-only tool outputs must be outside the inspected canonical root')
    args.out.mkdir(parents=True,exist_ok=False)
    result={'status':'PASS_ACTUAL_READBACK','scope':'master+native CPU GLTFLoader/web; no browser/GPU proof',
            'native_quant_bits':args.web_quant_bits,'assets':[]}
    for rec in json.loads((HERE/'records.json').read_bytes()):
        name=rec['id']+'__'+rec['phase']+'.glb';m=args.root/'assets/gltf'/name;web=args.root/'assets/web'/name
        row={'structure':rec['id'],'master_sha256':sha(m),'web_sha256':sha(web)}
        try:
            current=master(m);old=master(HERE/'baseline/gltf'/name)
            if triangles(current,'roof_shingle')!=triangles(old,'roof_shingle'):
                raise ValueError('actual master roof triangle geometry changed')
            d=rec['depth'];bottom=rec['wall_height']-.45-.14
            low=lambda t:all(d+1.96-2e-6<=p[1]<=d+2.1+2e-6 and p[2]<=bottom+2e-6 for p in t)
            if triangles(current,'chinking',low)!=triangles(old,'chinking',low):
                raise ValueError('actual master posts/beam bottom/lower trim changed')
            row['master']=contact(current,rec,[0.,0.,0.])
            decoded=args.out/(rec['id']+'-web-decoded.json')
            proc=subprocess.run(['node',str(HERE/'decode-web.mjs'),str(web),str(decoded)],
                                stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            if proc.returncode:raise ValueError('native web decode failed: '+proc.stdout)
            payload=json.loads(decoded.read_bytes());errors=[0.,0.,0.]
            for r in payload['rows']:
                if r['encoding']=='Int16Array':
                    # SHORT normalized dequantisation domain [-1,1]. The selected
                    # native meshopt recipe uses 14(or explicitly16) POSITION bits.
                    # Use a FULL rung, covering quantiser + integer packing error;
                    # meshopt's integer compression is lossless (no POSITION filter).
                    for k,s in enumerate(r['node_scale_native_xyz']):
                        errors[k]=max(errors[k],2*abs(s)/(2**args.web_quant_bits-1))
            row['web']=contact(payload['rows'],rec,errors)
            # Bind the actual beam and canopy positions to the master, rather
            # than accepting an arbitrary decoded shape inside a tolerance.
            for category in ('upper_corners','actual_canopy_corners'):
                for p in row['web'][category]:
                    choices=row['master'][category]
                    if not any(all(abs(a-b)<=e+2e-6 for a,b,e in zip(p,q,errors)) for q in choices):
                        raise ValueError('decoded web beam/canopy point exceeds its actual master quantisation rung')
            row['unchanged_actual_master_roofs_posts_bottom']='PASS'
            row['status']='PASS'
        except Exception as error:
            row['status']='FAIL';row['error']=str(error);result['status']='FAIL_ACTUAL_READBACK'
        result['assets'].append(row)
    (args.out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result['status'],str(args.out/'receipt.json'))
    return 0 if result['status']=='PASS_ACTUAL_READBACK' else 1


if __name__=='__main__':sys.exit(main())
