# Whole T-3082 state before stacking onto PR1260

This checkpoint captures every owned dirty/untracked file, all46 genuine frame GLBs, the current native registries, full raw docs, both fixture fixes and incoming dev fold. The staged and unstaged patches preserve their separation; the missing-path list records the folded pending-entry deletion. HEAD is daaf with026ace MERGE_HEAD, still uncommitted. Other files are the unchanged base Git tree, whose commit and retained refs are recorded. No live ignored caches are included.

The actual exports are already independently archived at0cfce6af and passed semantic readback: only three roof RGB scalars change in the target, all22 other masters and derivatives are byte-identical. The later latest-parent migration, fixture and dev ancestry proofs are remote923d167. This whole checkpoint precedes any clearing of the old worktree. Do not clear it until this selected manifest itself has been remotely published and read back.

No native downstream/browser, gate, publish or new heavy job ran here. Stacking on6bf/PR1260 still requires exact source preimages and all23 current input hashes before transferring genuine exports. Preserve all82 incoming log assets/rows, unrelated rows and full target docs. Original T2385 stays open and differs, source-use rights are not upgraded, and broad-left flag pose stays unadopted.
