from pathlib import Path
import json,struct,hashlib,collections,copy,datetime,os
os.sched_setaffinity(0,{4});app=Path('/workspace/chicago/chicago/4d');out=Path('/tmp/WolfPoint-T2386-deep-brown82-20261026');g=json.loads((out/'AUTHORED-GUARDS.json').read_bytes())
def read(p):
 raw=p.read_bytes();o=12;j=None;b=None
 while o<len(raw):
  n,t=struct.unpack_from('<II',raw,o);v=raw[o+8:o+8+n];o+=n+8
  if t==0x4e4f534a:j=json.loads(v)
  if t==0x004e4942:b=v
 return raw,j,b
CT={5120:('b',1),5121:('B',1),5122:('h',2),5123:('H',2),5125:('I',4),5126:('f',4)};N={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def accessor(j,b,i):
 a=j['accessors'][i];assert 'sparse'not in a;v=j['bufferViews'][a['bufferView']];fmt,size=CT[a['componentType']];n=N[a['type']];start=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size*n);rows=[]
 for k in range(a['count']):
  vals=struct.unpack_from('<'+fmt*n,b,start+stride*k)
  if a.get('normalized'):
   denom={5120:127,5121:255,5122:32767,5123:65535,5125:4294967295}[a['componentType']];vals=tuple(max(-1,x/denom)if fmt.islower()else x/denom for x in vals)
  rows.append(vals)
 return rows

def primitive_streams(j,b,ignore_uv):
 result=[]
 for mi,m in enumerate(j['meshes']):
  for pi,p in enumerate(m['primitives']):
   attrs=sorted(k for k in p['attributes']if not(ignore_uv and k.startswith('TEXCOORD_')));arr={k:accessor(j,b,p['attributes'][k])for k in attrs};idx=accessor(j,b,p['indices']);assert len(idx)%3==0
   vertices=[tuple((key,arr[key][q])for key in attrs)for q in range(len(next(iter(arr.values()))))];tris=[]
   for z in range(0,len(idx),3):
    t=tuple(vertices[idx[z+k][0]]for k in range(3));tris.append(min(t,t[1:]+t[:1],t[2:]+t[:2]))
   result.append({'mesh':m.get('name'),'material':j['materials'][p['material']]['name'],'triangles':collections.Counter(tris),'count':len(tris),'vertex_count':len(vertices),'attributes':attrs})
 return result
rows=[]
for r in g['cohort82']:
 name=r['master'];a,ja,ba=read(out/'before/assets/gltf'/name);b,jb,bb=read(app/'assets/gltf'/name);target=r['structure_id']=='wolf_point_tavern';assert ja['nodes']==jb['nodes'];assert len(ja['materials'])==len(jb['materials']);material_changes=[]
 for i,(ma,mb)in enumerate(zip(ja['materials'],jb['materials'])):
  if ma!=mb:
   assert target and ma['name']==mb['name']=='roof_shingle';aa=copy.deepcopy(ma);ab=copy.deepcopy(mb);old=aa['pbrMetallicRoughness'].pop('baseColorFactor');new=ab['pbrMetallicRoughness'].pop('baseColorFactor');assert aa==ab;material_changes.append({'name':'roof_shingle','old':old,'new':new})
 assert len(material_changes)==(1 if target else 0)
 # Direct actual oriented POSITION/NORMAL/CONFIDENCE/etc tuples, with triangle winding preserved.
 sa=primitive_streams(ja,ba,True);sb=primitive_streams(jb,bb,True);assert len(sa)==len(sb)
 for x,y in zip(sa,sb):assert {k:v for k,v in x.items()if k!='vertex_count'}=={k:v for k,v in y.items()if k!='vertex_count'},(name,x['material'])
 untextured=not ja.get('textures')and not jb.get('textures');assert untextured,'A UV difference would need textured-semantic proof'
 uv_exact=primitive_streams(ja,ba,False)==primitive_streams(jb,bb,False)
 roofconf=[]
 if target:
  for p in jb['meshes'][0]['primitives']:
   if jb['materials'][p['material']]['name']=='roof_shingle':
    vals=accessor(jb,bb,p['attributes']['_CONFIDENCE']);roofconf.extend(v[0]for v in vals)
  assert roofconf and set(roofconf)=={1.0},set(roofconf)
 rows.append({'master':name,'target':target,'raw_byte_identical':a==b,'binary_chunk_identical':ba==bb,'before_sha256':hashlib.sha256(a).hexdigest(),'after_sha256':hashlib.sha256(b).hexdigest(),'before_bytes':len(a),'after_bytes':len(b),'oriented_positions_normals_confidence_and_other_nonUV_streams_exact':True,'triangles':sum(x['count']for x in sa),'nodes_and_transforms_exact':True,'all_UV_streams_exact':uv_exact,'UV_not_geometry_if_different':'No GLB textures in either actual file; native unchanged roof/wall relief uses metric world projection. All actual nonUV oriented streams/counts/materials exact.','actual_primitive_counts':[{'material':x['material'],'before_vertices':x['vertex_count'],'after_vertices':y['vertex_count'],'triangles':x['count']}for x,y in zip(sa,sb)],'material_changes':material_changes,'target_roof_confidence_values':sorted(set(roofconf))if target else None})
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ALL82_ACTUAL_MASTER_ORIENTED_GEOMETRY_NORMAL_CONFIDENCE_PROOF_PASS','count82':len(rows),'default81_raw_exact':sum(r['raw_byte_identical']for r in rows if not r['target']),'default81_semantic_exact':True,'target_only_expected_basecolour_change':True,'target_reconstructed_roof_confidence_actual1':True,'no_restoration_performed':True,'rows':rows};(out/'MASTER82-INDEPENDENT-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS82masters',result['default81_raw_exact'],'/81 default bytes exact; all oriented streams exact; target colour/roof confidence proven; no restore')
