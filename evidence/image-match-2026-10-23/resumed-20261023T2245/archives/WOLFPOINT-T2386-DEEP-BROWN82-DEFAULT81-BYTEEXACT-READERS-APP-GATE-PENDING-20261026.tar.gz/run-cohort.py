from pathlib import Path
import os,json,subprocess,hashlib,time,shutil,datetime
os.sched_setaffinity(0,{4});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/tmp/wolfpoint-native-tmp')
app=Path('/workspace/chicago/chicago/4d');out=Path('/tmp/WolfPoint-T2386-deep-brown82-20261026');g=json.loads((out/'AUTHORED-GUARDS.json').read_bytes());resources=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def guards():
 assert all(sha(app/r['path'])==r['sha256']for r in g['frozen_nonfamily_physical_assets'])
 assert all(sha(app/r['path'])==r['sha256']for r in g['frozen_other_record_source_people_population_generator_inputs'])
def run(name,cmd):
 resource={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':name,'workspace_free':shutil.disk_usage(app).free,'tmp_free':shutil.disk_usage('/tmp').free};resources.append(resource);(out/'RESOURCES.json').write_text(json.dumps(resources,indent=2)+'\n');assert min(resource['workspace_free'],resource['tmp_free'])>=g['native_floor_bytes'];guards();start=time.monotonic();print(name,'START',resource,flush=True)
 with(out/(name+'.log')).open('x')as log:r=subprocess.run(cmd,cwd=app,stdout=log,stderr=subprocess.STDOUT)
 record={'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-start,3)};(out/(name+'-RESULT.json')).write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,(name,r.returncode);guards();print(name,'PASS',record['seconds'],flush=True)
assert json.loads((out/'PARAMETER-API-PROOF.json').read_bytes())['all81_default_resolved_inputs_exact']
ids=','.join(sorted(r['structure_id']for r in g['cohort82']));names={r['master']for r in g['cohort82']};wrote=out/'WROTE82.txt';assert not wrote.exists();start=time.monotonic()
run('canonical82',['env','-u','PYTHONPATH','/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender','-b','-t','1','-noaudio','--factory-startup','--python-exit-code','1','--python','/workspace/chicago/chicago/4d/generators/build.py','--','--only',ids,'--wrote',str(wrote)])
actual=wrote.read_text().splitlines();assert len(actual)==82 and len(set(actual))==82 and set(actual)==names,('STRICT_EXPECTED82_WROTE_GUARD',actual)
(out/'STRICT-WROTE82-PASS.json').write_text(json.dumps({'exactly82':True,'no_versions_or_other_names':True,'actual_wrote':actual},indent=2)+'\n')
run('real-web82',['bash','tools/web_derivatives.sh','--only',','.join(actual)])
result={'status':'GENUINE_CANONICAL82_AND_REAL_PINNED_WEB82_COMPLETE_DEFAULT_SEMANTIC_PROOF_OWED','cpu':[4],'seconds':round(time.monotonic()-start,3),'strict_exact82_wrote_guard':True,'frozen_nonfamily_assets_exact':True,'frozen_other_records_source_people_population_generator_inputs_exact':True,'default81_geometry_material_confidence_comparison_and_registry_scope_still_required':True,'no_restore_or_handhash':True};(out/'COHORT-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
