from pathlib import Path
import os,json,hashlib,copy,struct,datetime
os.sched_setaffinity(0,{4});app=Path('/workspace/chicago/chicago/4d');out=Path('/tmp/WolfPoint-T2386-deep-brown82-20261026');g=json.loads((out/'AUTHORED-GUARDS.json').read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def parse(b):
 o=12;j=None;bin=None
 while o<len(b):
  n,t=struct.unpack_from('<II',b,o);v=b[o+8:o+8+n];o+=n+8
  if t==0x4e4f534a:j=json.loads(v)
  if t==0x004e4942:bin=v
 return j,bin
for r in g['cohort82']:
 n=r['master'];before=(out/'before/assets/web'/n).read_bytes();after=(app/'assets/web'/n).read_bytes();target=r['structure_id']=='wolf_point_tavern'
 if not target:assert before==after,n
 else:
  a,x=parse(before);b,y=parse(after);assert x==y and a['nodes']==b['nodes'];aa=copy.deepcopy(a);bb=copy.deepcopy(b);changes=[]
  for ma,mb in zip(aa['materials'],bb['materials']):
   if ma!=mb:
    assert ma['name']==mb['name']=='roof_shingle';old=ma['pbrMetallicRoughness'].pop('baseColorFactor');new=mb['pbrMetallicRoughness'].pop('baseColorFactor');assert ma==mb;changes.append({'old':old,'new':new})
  assert len(changes)==1 and aa==bb
 rows.append({'master':n,'target':target,'raw_byte_identical':before==after,'before_sha256':sha(before),'after_sha256':sha(after),'bytes':len(after),'target_binary_and_entire_JSON_except_roof_basecolour_identical':True if target else None})
names={r['master']for r in g['cohort82']};registry=[]
for name,key in [('assets/manifest.json','assets'),('assets/manifest.web.json','masters')]:
 a=json.loads((out/'before'/name).read_bytes());b=json.loads((app/name).read_bytes());assert set(a[key])==set(b[key]);outside=[n for n in a[key]if n not in names and a[key][n]!=b[key][n]];assert not outside;changed=[n for n in a[key]if a[key][n]!=b[key][n]]
 if key=='assets':
  assert set(changed)==names
  for n in names:
   x=copy.deepcopy(a[key][n]);y=copy.deepcopy(b[key][n]);old=x.pop('inputs_sha256');new=y.pop('inputs_sha256');assert x==y and old!=new,n
 else:assert changed==['wolf_point_tavern__log_frame_1828.glb']
 aa=copy.deepcopy(a);bb=copy.deepcopy(b);aa.pop(key);bb.pop(key);assert aa==bb
 registry.append({'path':name,'changed_rows':changed,'every_nonfamily_row_and_metadata_exact':True,'canonical_row_changes_inputs_sha_only':key=='assets','native_writer_recorded':True})
actual={str(p.relative_to(app))for p in(app/'assets').rglob('*')if p.is_file()};expected={r['path']for r in g['frozen_nonfamily_physical_assets']}|{'assets/'+kind+'/'+n for n in names for kind in['gltf','web']}|{'assets/manifest.json','assets/manifest.web.json'};assert actual==expected
assert all(sha((app/r['path']).read_bytes())==r['sha256']for r in g['frozen_nonfamily_physical_assets']);assert all(sha((app/r['path']).read_bytes())==r['sha256']for r in g['frozen_other_record_source_people_population_generator_inputs'])
wolfmaster=(app/'assets/gltf/wolf_point_tavern__log_frame_1828.glb').read_bytes();wolfweb=(app/'assets/web/wolf_point_tavern__log_frame_1828.glb').read_bytes()
result={'status':'REAL_WEB82_81_DEFAULT_BYTES_EXACT_TARGET_PBR_ONLY_NATIVE_REGISTRIES_SCOPE_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'count82':len(rows),'default81_WEB_raw_byte_exact':True,'default81_master_raw_byte_exact':True,'target_actual_master_sha256':sha(wolfmaster),'target_actual_WEB_sha256':sha(wolfweb),'target_master_bytes':len(wolfmaster),'target_web_bytes':len(wolfweb),'asset_path_set_exact':True,'nonfamily2754_assets_and3867_other_authored_inputs_exact':True,'registry':registry,'no_file_restore_or_hash_mint':True,'rows':rows};(out/'WEB82-REGISTRY-SCOPE-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in['rows','registry']},indent=2))
