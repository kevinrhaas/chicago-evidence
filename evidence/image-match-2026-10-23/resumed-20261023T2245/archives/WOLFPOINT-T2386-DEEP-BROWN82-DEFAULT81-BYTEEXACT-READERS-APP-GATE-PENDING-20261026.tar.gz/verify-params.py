from pathlib import Path
import os,sys,json,inspect,dataclasses,datetime
os.sched_setaffinity(0,{4});os.environ['PYTHONDONTWRITEBYTECODE']='1';app=Path('/workspace/chicago/chicago/4d');out=Path('/tmp/WolfPoint-T2386-deep-brown82-20261026');g=json.loads((out/'AUTHORED-GUARDS.json').read_bytes());sys.path.insert(0,str(app/'generators'))
from archetypes.log_dwelling_params import LogDwellingParams,from_phase,ParamError
sig=inspect.signature(LogDwellingParams);now=[{'name':n,'kind':str(v.kind),'default':repr(v.default)}for n,v in sig.parameters.items()if n!='roof_colour'];assert now==g['old_positional_API'];assert sig.parameters['roof_colour'].kind==inspect.Parameter.KEYWORD_ONLY and sig.parameters['roof_colour'].default is None
rows=[];wolf=None
for r in g['cohort82']:
 st=json.loads((app/'data/structures'/f"{r['structure_id']}.json").read_bytes());ph=next(p for p in st['phases']if p['id']==r['phase_id']);p=from_phase(ph,st);doc=json.loads(json.dumps(dataclasses.asdict(p)));colour=doc.pop('roof_colour');before=r['before_params']
 if st['id']!='wolf_point_tavern':assert colour is None and doc==before;kind='DEFAULT_RESOLVED_PARAMS_EXACT_PLUS_KEYWORD_NONE'
 else:
  wolf=p;old=json.loads(json.dumps(before));assert old['roof_condition']=='darkened';old['roof_condition']=None;assert old['confidence'].pop('roof_condition')=='reconstructed';old['confidence']['roof_colour']='reconstructed';assert doc==old and colour=='deep_brown';kind='ONLY_PROVISIONAL_CONDITION_REPLACED_BY_EXPLICIT_RECONSTRUCTED_COLOUR'
 rows.append({'id':st['id'],'proof':kind})
refusals=[]
for label,p in [('unknown_stock',dataclasses.replace(wolf,roof_colour='neon')),('false_attested_stock',dataclasses.replace(wolf,confidence={**wolf.confidence,'roof_colour':'attested'}))]:
 try:p.validate()
 except ParamError as e:refusals.append({'case':label,'actual_native_refusal':str(e)})
 else:raise AssertionError(label+' not refused')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_positional_signature_exact':True,'new_only_keyword_parameter':str(sig.parameters['roof_colour']),'all81_default_resolved_inputs_exact':True,'target_only_expected_metadata_change':True,'actual_native_validation_refusals':refusals,'rows':rows};(out/'PARAMETER-API-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS old positional API;81default params exact, keywordNone; native invalid-stock/false-attestation refusals; targetexplicitreconstructedonly')
