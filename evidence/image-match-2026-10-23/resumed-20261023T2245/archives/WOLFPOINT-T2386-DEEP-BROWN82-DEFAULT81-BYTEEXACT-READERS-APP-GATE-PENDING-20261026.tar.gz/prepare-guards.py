from pathlib import Path
import os,sys,json,hashlib,shutil,inspect,dataclasses,datetime
os.sched_setaffinity(0,{4});os.environ['PYTHONDONTWRITEBYTECODE']='1'
app=Path('/workspace/chicago/chicago/4d');out=Path('/tmp/WolfPoint-T2386-deep-brown82-20261026');sys.path.insert(0,str(app/'generators'))
from archetypes.log_dwelling_params import LogDwellingParams,from_phase
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((app/'assets/manifest.json').read_bytes());rows={k:v for k,v in m['assets'].items()if v.get('archetype')=='log_dwelling'};assert len(rows)==82 and len({r['structure_id']for r in rows.values()})==82
assert not [v for v in json.loads((app/'assets/manifest.versions.json').read_bytes()).get('assets',{}).values()if v.get('archetype')=='log_dwelling']
records={p.stem:json.loads(p.read_bytes())for p in (app/'data/structures').glob('*.json')};cohort=[]
for name,row in rows.items():
 st=records[row['structure_id']];ph=next(p for p in st['phases']if p['id']==row['phase_id']);par=from_phase(ph,st)
 item={'master':name,'structure_id':st['id'],'phase_id':ph['id'],'before_params':dataclasses.asdict(par),'before_master_row':row,'before_master_sha256':sha(app/'assets/gltf'/name),'before_web_sha256':sha(app/'assets/web'/name)}
 for kind in ['gltf','web']:
  name2='assets/'+kind+'/'+name;dest=out/'before'/name2;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(app/name2,dest)
 cohort.append(item)
for name in ['assets/manifest.json','assets/manifest.web.json','assets/manifest.versions.json','generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py','data/structures/wolf_point_tavern.json','data/reconstruction/name_pool_keys.json','docs/LIBERTIES.md','docs/RESEARCH/wolf_point_tavern.md','docs/STATUS.md','docs/ROADMAP.md','changelog.d/T-2386.json']:
 p=app/name;dest=out/'before'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
base=json.loads(Path('/tmp/WolfPoint-T2386-native-closure-20261026/PREPARED.json').read_bytes());family_paths={'assets/'+kind+'/'+name for name in rows for kind in ['gltf','web']};excluded=family_paths|{'assets/manifest.json','assets/manifest.web.json'}
nonfamily=[r for r in base['frozen_physical_assets_and_registry']if r['path']not in excluded];assert all(sha(app/r['path'])==r['sha256']for r in nonfamily)
modified={'generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py','data/structures/wolf_point_tavern.json'};inputs=[r for r in base['frozen_authored_people_population_source_generator_inputs']if r['path']not in modified];assert all(sha(app/r['path'])==r['sha256']for r in inputs)
sig=[{'name':n,'kind':str(v.kind),'default':repr(v.default)}for n,v in inspect.signature(LogDwellingParams).parameters.items()]
proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':'cb93ad9cd5ea38654737e05002b1f1904be14e54','cpu':[4],'cohort82':cohort,'no_versions':True,'old_positional_API':sig,'frozen_nonfamily_physical_assets':nonfamily,'frozen_other_record_source_people_population_generator_inputs':inputs,'expected_only_authored_core_paths':sorted(modified),'no_common_schema_emit_material_changes':True,'workspace_free':shutil.disk_usage(app).free,'tmp_free':shutil.disk_usage('/tmp').free,'native_floor_bytes':536870912};assert min(proof['workspace_free'],proof['tmp_free'])>=proof['native_floor_bytes'];(out/'AUTHORED-GUARDS.json').write_text(json.dumps(proof,indent=2)+'\n');print('GUARDS',len(cohort),'canonical pairs',len(nonfamily),'nonfamily assets',len(inputs),'other source inputs,0versions; old positional API captured')
