"""Read-only source/overlay/receipt guards. No production gate or asset load."""
from pathlib import Path
import hashlib,json,subprocess,ast
OUT=Path(__file__).resolve().parent;APP=Path('/workspace/chicago/chicago/4d');V2=Path('/tmp/chicago-next-model/T-2375-native-surface-profile-v2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((OUT/'preimages.json').read_text())
for rel,expected in meta['source_preimages'].items():assert sha(APP/rel)==expected,rel
assert sha(V2/'MANIFEST.json')==meta['v2_manifest_sha256']
for rel,entry in json.loads((V2/'MANIFEST.json').read_text())['files'].items():
 assert sha(V2/rel)==entry['sha256'] and (V2/rel).stat().st_size==entry['bytes'],rel
assert (OUT/'baseline/chicago/4d/renderers/web/js/main.js').read_bytes()==(V2/'candidate/chicago/4d/renderers/web/js/main.js').read_bytes()
assert (OUT/'standing-envelope.js').read_bytes()==(OUT/'candidate/chicago/4d/renderers/web/js/standing-envelope.js').read_bytes()
for p in (OUT/'candidate').rglob('*.js'):subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
for p in OUT.glob('*.py'):ast.parse(p.read_text(),str(p))
subprocess.run(['git','apply','--check',str(OUT/'standing-envelope-overlay.patch')],cwd=OUT/'baseline',check=True,capture_output=True)
receipt=json.loads((OUT/'receipt.json').read_text());assert receipt['status'].startswith('PASS')
assert receipt['current_horse']['all_pose_conservative_envelope_off_profile'] and receipt['body_only_control']['actual_rest_body_triangles_reach_profile']
assert receipt['unhandled_rejections']==[] and receipt['undersized_envelope_mutation_detected']
scanner=json.loads((OUT/'sidecar-contract-receipt.json').read_text());assert scanner['status']=='PASS' and not scanner['errors'] and scanner['missing_profile_negative_errors'] and scanner['nonexistent_field_negative_errors']
if (OUT/'MANIFEST.json').exists():
 entries=json.loads((OUT/'MANIFEST.json').read_text())['files'];actual={str(p.relative_to(OUT))for p in OUT.rglob('*')if p.is_file()and p.name!='MANIFEST.json'};assert actual==set(entries)
 for rel,entry in entries.items():assert sha(OUT/rel)==entry['sha256']and(OUT/rel).stat().st_size==entry['bytes'],rel
print('PASS read-only standing-envelope proposal guards; real asset/image load, browser/GPU and production gates remain unrun.')
