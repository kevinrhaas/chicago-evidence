import fs from 'node:fs';
const own=new URL('./',import.meta.url).href,v2='file:///tmp/chicago-next-model/T-2375-native-surface-profile-v2/',root='file:///workspace/chicago/chicago/4d/';
export function resolve(specifier,context,nextResolve){
 if(specifier==='three')return{url:root+'renderers/web/vendor/three-0.185.1/three.module.js',shortCircuit:true};
 if(specifier.startsWith('three/addons/'))return{url:root+'renderers/web/vendor/three-0.185.1/addons/'+specifier.slice(13),shortCircuit:true};
 if(specifier.startsWith('.')&&(context.parentURL?.startsWith(own)||context.parentURL?.startsWith(v2))){
  const url=new URL(specifier,context.parentURL);
  for(const prefix of[own+'candidate/chicago/4d/',v2+'candidate/chicago/4d/'])if(url.href.startsWith(prefix)&&!fs.existsSync(url))return{url:root+url.href.slice(prefix.length),shortCircuit:true};
 }
 return nextResolve(specifier,context);
}
