T-2375 separate standing-horse envelope follow-up — closed light proposal

This is an overlay after the frozen native profile v2 proposal at
`/tmp/chicago-next-model/T-2375-native-surface-profile-v2` (manifest 3bac59322a4444058475aba876f64df1ccc025167f12a85ad767ac5596fafc1d).
It changes only standing-horses.js, its main.js argument, and one new pure helper.
No current horse record, asset, placement, skin, clip, material, historical source,
scene date or image verdict changes. No canonical writes, claims, browser,
Blender or full gates occurred. Original T-2375 remains open/differs.

The existing metadata has only rest bounds and 65 keys/64 midpoints qualification,
not a continuous animated envelope. This proposal derives a conservative
unsupported-span envelope from the actual SHA/header-verified GLB once, before
GLTF parsing or cloning. The fixed 26 rig, identity mesh transforms, unit scales,
positive once-normalized skin weights and single allowed LINEAR clip are checked.
No generic physics, per-frame mesh scan, persisted asset cache, sampled-animation
acceptance or arbitrary geographic radius is introduced.

Bound derivation (all numerical terms are source-derived):

- A translation's norm over a LINEAR interval is no greater than the larger
  endpoint norm; include the rest translation too.
- For a permitted shortest-arc quaternion interpolation, coefficients a,b lie in
  [0,1]. Its squared norm is 1+a²(A−1)+b²(B−1), so maximum key norm excess bounds
  the interpolant excess. Matrix(q)=sR(q/|q|)+(1−s)I has operator norm at most
  1+4max_key_excess. This admits the source's small float key normalization error.
- Propagate translation-length and rotation-operator bounds along each actual
  joint path. For each actual inverse-bound vertex and nonnegative normalized
  weight, sum w*(joint_translation_bound + joint_rotation_bound*local_vertex_norm).
  This bounds all allowed clip times, including intervals not in the129samples.
- Add gamma_n=(n*u)/(1−n*u), u=2^-24, scaled by the radius plus its homogeneous
  coordinate. The scalar-operation allowance is rounded up from 256*(source max
  joint depth+4 influences): depth 7 gives 2816, rounded 4096. Real CPU world transforms
  use double precision. This conservative numeric model remains independently
  reviewable; it is not GPU/driver certification.

Actual verified source b479442cb03ac46eb13c19da15a79cdfaf28dbdf356b116f78de7ce7ecdc60be,
3,783,600 bytes /11,556 position entries produces raw bound 3.0553337881 m plus
0.0009903135 m numeric allowance =3.0563241016 m. Transform the corresponding
conservative 3D box by the exact support quaternion and bearing, then use v2's
shared projected-triangle eligibility. It can refuse safe close stands because
it is conservative; it is an unsupported-span exclusion envelope, never a fitted
anatomy/contact hull or a new accepted metric size.

`receipt.json` records actual tests:

- Decoded/rest-skinned real asset bounds agree with the existing independently
  decoded sidecar. All real rest vertices lie inside the analytic envelope.
  Both actual current Western Hotel geometry and its conservative all-pose
  envelope are off Dearborn; its position/rotation/support remain untouched.
- A real-body control places every actual hoof contact outside the profile while
  actual decoded neutral body triangles reach the span. The new envelope refuses
  it; a deliberately undersized bound misses it and is detected. Contact-on-span
  also refuses.
- Actual native createStandingHorses uses the actual verified GLB bytes and
  unchanged header/SHA validation. Both unsupported cases resolve with a recorded
  reason before GLTF parsing/cloning: zero active instances/children, no same-
  revision retry, and no unhandled rejection. Explicit light→full revisions remain
  clean refusals. No horse fallback exists to revive, and no source/clone/cache
  resource is created before the refusal.
- Current Western and flat-disabled controls reach the unchanged native parse
  boundary. The test intentionally stops there; complete real image/asset loading,
  happy placement, cloning, actual yard, page, mobile and photographic/GPU/world
  qualification remain UNRUN. The control is not a fake successful horse load.
- Changed scale, channel/interpolation contracts refuse. Runtime diagnostic mesh
  output is empty; raw triangle reconstruction is enabled only for the CPU proof.
- Unchanged native full-renderer sidecar contract passes with this follow-up over
  v2 and actual compiler profile shape. Missing-profile/nonexistent-field negatives
  remain red. No scanner/assertion relaxation or invented emitted field.

`standing-envelope-overlay.patch` applies to the exact v2 main.js plus current
native standing-horses.js preimages in baseline/. New helper is source only.
`preimages.json` guards the real source/spec/placement/GLB/vendor contracts.
`verify.py` is read-only: checks source and frozen-v2 integrity, syntax, patch,
receipts and manifest. Copy this closed directory before rerunning writer tests.
Root retains mathematical/code review, adoption and any native/browser/gate grant.
