import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {createStandingHorses} from './candidate/chicago/4d/renderers/web/js/standing-horses.js';
import {deriveStandingEnvelope,standingEnvelopeTriangles} from './standing-envelope.js';
import {validatePlantedStandingHeader} from '/workspace/chicago/chicago/4d/renderers/web/js/standing-horse-planted-idle.js';
import {decksFrom} from '/tmp/chicago-next-model/T-2375-native-surface-profile-v2/candidate/chicago/4d/renderers/web/js/walker.js';
import {createProfilePlacementEligibility} from '/tmp/chicago-next-model/T-2375-native-surface-profile-v2/candidate/chicago/4d/renderers/web/js/deck-surface.js';
const root='/workspace/chicago/chicago/4d/',read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const spec=read(root+'data/transport/parked/horse-sevket-sidecar.json'),manifest=read(root+'data/transport/parked/standing-horses.json'),originalRow=manifest.scenes['1835'][0];
const buf=fs.readFileSync(root+'renderers/web/'+spec.runtime_asset.file),bytes=buf.buffer.slice(buf.byteOffset,buf.byteOffset+buf.byteLength);
assert.equal(crypto.createHash('sha256').update(buf).digest('hex'),spec.runtime_asset.sha256);
const json=validatePlantedStandingHeader(bytes,spec),envelope=deriveStandingEnvelope(bytes,json,{includeRestTriangles:true}),runtime=deriveStandingEnvelope(bytes,json);
assert.deepEqual({...envelope,rest_triangles:[]},runtime);assert.equal(runtime.rest_triangles.length,0);
const xyz=[0,1,2].map(axis=>envelope.rest_triangles.filter((_,i)=>i%3===axis));
const bounds=[xyz.map(a=>Math.min(...a)),xyz.map(a=>Math.max(...a))];
for(let i=0;i<2;i++)for(let j=0;j<3;j++)assert(Math.abs(bounds[i][j]-spec.runtime_bounds_m[i][j])<1e-4);
for(let i=0;i<envelope.rest_triangles.length;i+=3)assert(Math.hypot(...envelope.rest_triangles.slice(i,i+3))<envelope.radius_m);
const f=read('/tmp/chicago-next-model/T-2375-native-surface-profile-v2/fixture.json');
const decks=decksFrom(new Map([['bridge',{id:'bridge',sidecar:f.profile_side}]])),eligibility=createProfilePlacementEligibility(decks),centre=f.samples[3],e=centre.world_e,n=centre.world_n;
assert.equal(eligibility.trianglesReason(standingEnvelopeTriangles(envelope,originalRow)),null);
// Exact support/bearing transform of actual decoded rest geometry, no fake mesh.
function worldTriangles(triangles,row){
 const q=new THREE.Quaternion().fromArray(row.support_quaternion_xyzw),yaw=Math.PI-row.bearing_deg*Math.PI/180,c=Math.cos(yaw),s=Math.sin(yaw),out=[],p=new THREE.Vector3();
 for(let i=0;i<triangles.length;i+=3){p.fromArray(triangles,i).applyQuaternion(q);out.push(row.at_local_enu_m[0]+c*p.x+s*p.z,p.y,-row.at_local_enu_m[1]-s*p.x+c*p.z);}
 return out;
}
assert.equal(eligibility.trianglesReason(worldTriangles(envelope.rest_triangles,originalRow)),null);
const bodyNear={...originalRow,at_local_enu_m:[e-2.4,n],bearing_deg:90};
const contacts=Object.values(spec.contacts).flatMap(p=>p.samples_m),contactWorld=worldTriangles(contacts.flat(),bodyNear);
const contactEN=[];for(let i=0;i<contactWorld.length;i+=3)contactEN.push([contactWorld[i],-contactWorld[i+2]]);
assert.equal(eligibility.pointsReason(contactEN),null,'Body-only control must have every hoof contact outside');
assert(eligibility.trianglesReason(worldTriangles(envelope.rest_triangles,bodyNear)),'Actual neutral body reaches the span');
assert(eligibility.trianglesReason(standingEnvelopeTriangles(envelope,bodyNear)));
assert.equal(eligibility.trianglesReason(standingEnvelopeTriangles({...envelope,radius_m:.1},bodyNear)),null,'Undersized-bound mutation misses actual body-only overlap');
const contactNear={...originalRow,at_local_enu_m:[e,n],bearing_deg:90};
assert(eligibility.trianglesReason(standingEnvelopeTriangles(envelope,contactNear)));
for(const mutate of [j=>j.nodes[1].scale=[1,2,1],j=>j.animations[0].channels[0].target.path='scale',j=>j.animations[0].samplers[0].interpolation='CUBICSPLINE']){
 const wrong=structuredClone(json);mutate(wrong);assert.throws(()=>deriveStandingEnvelope(bytes,wrong),/HorseEnvelope/);
}
const originalFetch=globalThis.fetch,originalParse=GLTFLoader.prototype.parseAsync,cases=[],unhandled=[];
const listener=error=>unhandled.push(String(error));process.on('unhandledRejection',listener);
try{
 for(const [name,row,enabled,shouldRefuse]of [['contact-on-span',contactNear,true,true],['body-only-overlap',bodyNear,true,true],['current-western',originalRow,true,false],['flat-default-bypass',bodyNear,false,false]]){
  let parses=0,glbFetches=0;
  GLTFLoader.prototype.parseAsync=async()=>{parses++;throw Error('CPU positive-control parse boundary reached; real asset/image load unrun');};
  globalThis.fetch=async url=>{
   if(String(url).endsWith('standing-horses.json'))return{ok:true,json:async()=>({...manifest,scenes:{1835:[row]}})};
   if(String(url).endsWith('horse-sevket-sidecar.json'))return{ok:true,json:async()=>structuredClone(spec)};
   assert(String(url).endsWith(spec.runtime_asset.file));glbFetches++;return{ok:true,arrayBuffer:async()=>bytes.slice(0)};
  };
  const problems=[],layer=await createStandingHorses({dataBase:new URL('file:///fixture/'),sceneId:'1835',groundHeight:()=>0,placementEligibility:enabled?eligibility:null,problems});
  const camera=new THREE.PerspectiveCamera();camera.position.set(row.at_local_enu_m[0],2,-row.at_local_enu_m[1]);layer.update(camera);await layer.ready;
  assert.equal(layer.instances.length,0);assert.equal(layer.group.children.length,0);assert.equal(glbFetches,1);
  if(shouldRefuse){assert.equal(parses,0);assert.match(problems[0],/unsupported whole placement intersects profiled span/);}
  else{assert.equal(parses,1);assert.match(problems[0],/positive-control parse boundary reached/);}
  for(let i=0;i<5;i++)layer.update(camera,.016);await layer.ready;assert.equal(glbFetches,1,'No same-revision retry loop');
  if(shouldRefuse){await layer.setTier('light');await layer.setTier('full');assert.equal(glbFetches,2);assert.equal(parses,0);}
  layer.dispose();layer.update(camera);assert.equal(layer.group.children.length,0);
  cases.push({name,refused_before_GLTF_parse_or_clone:shouldRefuse,GLTF_parse_calls:parses,group_children:0,recorded_problems:problems});
 }
 assert.equal(unhandled.length,0);
}finally{globalThis.fetch=originalFetch;GLTFLoader.prototype.parseAsync=originalParse;process.off('unhandledRejection',listener);}
const receipt={status:'PASS bounded source-envelope/native refusal proposal; actual asset load/render acceptance unrun',asset_sha256:spec.runtime_asset.sha256,asset_bytes:bytes.byteLength,
 envelope:{...runtime,rest_triangles:undefined},actual_rest_bounds:bounds,current_horse:{id:originalRow.id,at:originalRow.at_local_enu_m,actual_rest_geometry_off_profile:true,all_pose_conservative_envelope_off_profile:true},
 body_only_control:{at:bodyNear.at_local_enu_m,all_hoof_contacts_off_profile:true,actual_rest_body_triangles_reach_profile:true},native_API:cases,unhandled_rejections:unhandled,
 no_per_frame_mesh_scan:true,runtime_diagnostics_geometry_omitted:true,undersized_envelope_mutation_detected:true,no_external_asset_cache_added:true,
 limitations:['Conservative origin-centred source-derived skin envelope can reject safe nearby stands; it is not a fitted anatomy/contact or physics hull.','Analytic bound assumes this exact SHA/header-locked26 rig, single LINEAR clip, positive normalized skinning and unit scales. Numeric4096-operation binary32 allowance remains reviewable; GPU/driver behavior is not certified.','Current row reaches unchanged native parse boundary; complete real image/asset load, cloning/happy placement, actual yard/browser/mobile/photographic/world/GPU gates were not run.','No historical appearance/geometry/image verdict changed; T2375 remains open/differs.']};
fs.writeFileSync(new URL('receipt.json',import.meta.url),JSON.stringify(receipt,null,2)+'\n');console.log('PASS horse envelope radius',envelope.radius_m,'current horse unaffected; actual body-only/contact controls refused before parse/clone; no retry/unhandled errors.');
