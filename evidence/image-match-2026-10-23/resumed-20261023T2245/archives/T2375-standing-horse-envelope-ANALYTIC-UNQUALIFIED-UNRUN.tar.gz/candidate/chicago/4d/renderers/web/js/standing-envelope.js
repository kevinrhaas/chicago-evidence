/** Source-specific all-pose skin envelope, derived once from SHA-verified GLB.
 * This is a conservative unsupported-span refusal bound, never a physics hull. */
const check=(ok,msg)=>{if(!ok)throw Error('HorseEnvelope: '+msg);};
const norm=v=>Math.hypot(...v);
export function deriveStandingEnvelope(bytes,json,{includeRestTriangles=false} = {}) {
  const view=new DataView(bytes),jsonLength=view.getUint32(12,true),binHeader=20+jsonLength;
  check(view.getUint32(binHeader+4,true)===0x004e4942,'embedded BIN required');
  const binStart=binHeader+8,cache=new Map();
  const accessor=id=>{
    if(cache.has(id))return cache.get(id);
    const a=json.accessors[id],b=json.bufferViews[a?.bufferView];
    const sizes={SCALAR:1,VEC3:3,VEC4:4,MAT4:16},components={5121:[1,'getUint8'],5123:[2,'getUint16'],5125:[4,'getUint32'],5126:[4,'getFloat32']};
    check(a&&b&&!a.sparse&&!a.normalized&&b.buffer===0&&sizes[a.type]&&components[a.componentType],'unsupported accessor');
    const [width,read]=components[a.componentType],count=sizes[a.type],stride=b.byteStride??width*count;
    check(stride>=width*count,'invalid stride');
    const start=binStart+(b.byteOffset??0)+(a.byteOffset??0),rows=[];
    for(let i=0;i<a.count;i++){
      const row=[];for(let j=0;j<count;j++){const at=start+i*stride+j*width;check(at+width<=bytes.byteLength,'accessor exceeds bytes');row.push(view[read](at,true));}
      check(row.every(Number.isFinite),'nonfinite accessor');rows.push(row);
    }
    cache.set(id,rows);return rows;
  };
  check(json.skins.length===1&&json.skins[0].joints.length===26&&json.animations.length===1,'explicit26 single clip required');
  const skin=json.skins[0],nodes=json.nodes,parent=new Map(),motion=new Map();
  for(let i=0;i<nodes.length;i++)for(const child of nodes[i].children??[]){check(!parent.has(child),'multiple parents');parent.set(child,i);}
  for(let i=0;i<26;i++){
    const node=nodes[i];check(skin.joints[i]===i&&!node.matrix,'joint identity/matrix changed');
    check((node.scale??[1,1,1]).every(v=>v===1),'nonunit scale');
    check((node.rotation??[0,0,0,1]).every((v,k)=>v===[0,0,0,1][k]),'rest rotation changed');
    check((node.translation??[0,0,0]).every(Number.isFinite),'joint translation invalid');
    motion.set(i,{translation:norm(node.translation??[0,0,0]),rotation:1});
  }
  const clip=json.animations[0];
  for(const channel of clip.channels){
    const target=channel.target,sampler=clip.samplers[channel.sampler];
    check(sampler.interpolation==='LINEAR','nonlinear interpolation');
    const keys=accessor(sampler.output);
    if(target.path==='translation'){
      check(target.node===1,'unapproved moving root');
      motion.get(1).translation=Math.max(motion.get(1).translation,...keys.map(norm));
    }else{
      check(target.path==='rotation'&&[7,8,9,12,13,14,17,18,19,22,23,24].includes(target.node),'unsupported channel');
      const excess=Math.max(0,...keys.map(q=>q.reduce((s,v)=>s+v*v,0)-1));
      check(excess<1e-5&&keys.every(q=>Math.abs(norm(q)-1)<1e-5),'nonunit quaternion keys');
      // Shortest-arc SLERP coefficients a,b lie[0,1]. For cos(theta)=dot(q0,q1),
      // ||a*q0+b*q1||²=1+a²(A-1)+b²(B-1)<=1+2*max_key_excess.
      // Matrix(q)=s*R(unit)+(1-s)*I, so its operator norm<=1+4*excess.
      motion.get(target.node).rotation=1+4*excess;
    }
  }
  const joint=new Map(),visiting=new Set();
  const world=id=>{
    if(joint.has(id))return joint.get(id);check(!visiting.has(id),'joint cycle');visiting.add(id);
    const p=parent.has(id)?world(parent.get(id)):{translation:0,rotation:1,depth:0},m=motion.get(id);check(m,'joint outside reviewed skin');
    const result={translation:p.translation+p.rotation*m.translation,rotation:p.rotation*m.rotation,depth:p.depth+1};joint.set(id,result);visiting.delete(id);return result;
  };
  const inverse=accessor(skin.inverseBindMatrices);check(inverse.length===26,'inverse bind count');
  let rawRadius=0,vertices=0,maximumWeightSum=0;
  const restTriangles=[];
  for(const [nodeIndex,node] of nodes.entries()){
    if(node.mesh===undefined)continue;check(!parent.has(nodeIndex),'mesh parent changed');
    check(node.skin===0&&!node.matrix&&!node.translation&&!node.rotation&&!node.scale,'mesh transform changed');
    for(const primitive of json.meshes[node.mesh].primitives){
      check((primitive.mode??4)===4&&!primitive.targets,'rigid-target/morph contract changed');
      const pos=accessor(primitive.attributes.POSITION),ids=accessor(primitive.attributes.JOINTS_0),weights=accessor(primitive.attributes.WEIGHTS_0);
      check(pos.length===ids.length&&ids.length===weights.length,'skin streams disagree');
      const points=[];
      for(let i=0;i<pos.length;i++){
        const total=weights[i].reduce((s,w)=>s+Math.abs(w),0);check(total>0&&weights[i].every(w=>w>=0),'invalid skin weights');
        // Exactly GLTFLoader/SkinnedMesh.normalizeSkinWeights once into FLOAT32.
        const normalized=weights[i].map(w=>Math.fround(w/total));maximumWeightSum=Math.max(maximumWeightSum,normalized.reduce((s,w)=>s+w,0));
        let bound=0,rest=[0,0,0];
        for(let k=0;k<4;k++){
          const id=ids[i][k],m=inverse[id];check(Number.isInteger(id)&&m,'invalid joint');
          check(m[3]===0&&m[7]===0&&m[11]===0&&m[15]===1,'nonaffine inverse bind');
          const x=pos[i],local=[0,1,2].map(axis=>m[axis]*x[0]+m[4+axis]*x[1]+m[8+axis]*x[2]+m[12+axis]);
          const j=world(id);bound+=normalized[k]*(j.translation+j.rotation*norm(local));
          if (includeRestTriangles) {
            const t=[0,0,0];let ancestor=id;while(ancestor!==undefined){for(let a=0;a<3;a++)t[a]+=(nodes[ancestor].translation??[0,0,0])[a];ancestor=parent.get(ancestor);}
            for(let a=0;a<3;a++)rest[a]+=normalized[k]*(t[a]+local[a]);
          }
        }
        rawRadius=Math.max(rawRadius,bound);if(includeRestTriangles)points.push(rest);vertices++;
      }
      if(includeRestTriangles)for(const [index]of accessor(primitive.indices))restTriangles.push(...points[index]);
    }
  }
  // Conservative IEEE binary32 allowance:256 scalar operations per source
  // joint-depth (matrix/quaternion work) plus four influence budgets. Round up
  // to a power of two. Real CPU world matrices are double; this overbounds them.
  // The +1 is the affine homogeneous coordinate, not an extra map exclusion.
  const maximumDepth=Math.max(...[...joint.values()].map(j=>j.depth));
  const operationUpperBound=256*(maximumDepth+4),operationBudget=2**Math.ceil(Math.log2(operationUpperBound));
  const unit=2**-24,gamma=(operationBudget*unit)/(1-operationBudget*unit),roundingAllowance=(rawRadius+1)*gamma;
  const radius=rawRadius+roundingAllowance;check(Number.isFinite(radius)&&radius>0,'invalid envelope');
  return {radius_m:radius,raw_radius_m:rawRadius,rounding_allowance_m:roundingAllowance,vertices,maximum_weight_sum:maximumWeightSum,maximum_joint_translation_bound_m:Math.max(...[...joint.values()].map(j=>j.translation)),maximum_joint_rotation_norm:Math.max(...[...joint.values()].map(j=>j.rotation)),maximum_joint_depth:maximumDepth,arithmetic_operation_upper_bound:operationUpperBound,numeric_operation_budget:operationBudget,
    scope:'All permitted single-clip LINEAR translation/quaternion times, positive normalized LBS, unit scales, fixed26 rig; source-derived conservative bound, not sampled or anatomical clearance',rest_triangles:restTriangles};
}
export function standingEnvelopeTriangles(envelope,row) {
  const q=row.support_quaternion_xyzw;check(q?.length===4&&q.every(Number.isFinite)&&Math.abs(norm(q)-1)<1e-7,'invalid support quaternion');
  const yaw=Math.PI-row.bearing_deg*Math.PI/180,c=Math.cos(yaw),s=Math.sin(yaw),r=envelope.radius_m;
  const corners=[];
  for(const x of[-r,r])for(const y of[-r,r])for(const z of[-r,r]){
    // Unit quaternion vector rotation, same support then bearing transform as instantiate.
    const [qx,qy,qz,qw]=q,tx=2*(qy*z-qz*y),ty=2*(qz*x-qx*z),tz=2*(qx*y-qy*x);
    const a=x+qw*tx+qy*tz-qz*ty,b=y+qw*ty+qz*tx-qx*tz,d=z+qw*tz+qx*ty-qy*tx;
    corners.push([row.at_local_enu_m[0]+c*a+s*d,b,-row.at_local_enu_m[1]-s*a+c*d]);
  }
  const faces=[[0,1,3,2],[4,6,7,5],[0,4,5,1],[2,3,7,6],[0,2,6,4],[1,5,7,3]],triangles=[];
  for(const[a,b,c,d]of faces)for(const i of[a,b,c,a,c,d])triangles.push(...corners[i]);
  return triangles;
}
