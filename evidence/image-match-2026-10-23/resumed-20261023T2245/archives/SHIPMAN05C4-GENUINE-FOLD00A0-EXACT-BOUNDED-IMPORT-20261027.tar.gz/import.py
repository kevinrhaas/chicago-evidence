from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal,zlib,urllib.request,urllib.parse,struct
os.sched_setaffinity(0,{3});os.nice(19)
B=Path(__file__).parent;C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='403023c0369a99e0e9bbe9d8f488814a93cc89c2';TIP='00a058ec1a868f4d0a9b5f69c274d54849414cac';CAP=64*1024**2;ENVELOPE=CAP;FLOOR=128*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(r,*args,input=None):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:sha(G/n)for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
def indexed(ids):
 wanted=set(ids);found=set();obj=G/'objects'
 for s in wanted:
  if(obj/s[:2]/s[2:]).is_file():found.add(s)
 for idx in(obj/'pack').glob('*.idx'):
  remaining=wanted-found
  if not remaining:break
  with idx.open('rb')as f:
   head=f.read(8);v2=head[:4]==b'\xfftOc';off=8 if v2 else 0
   if v2:assert struct.unpack('>I',head[4:])[0]==2
   f.seek(off);fan=struct.unpack('>256I',f.read(1024));table=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
   for s in remaining:
    key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
    while a<z:
     m=(a+z)//2;f.seek(table+m*stride+delta);value=f.read(20)
     if value<key:a=m+1
     else:z=m
    f.seek(table+a*stride+delta)
    if a<fan[key[0]]and f.read(20)==key:found.add(s)
 return found
before=snap();save('SOURCE-BEFORE.json',before);assert git(C,'rev-parse','origin/dev').decode().strip()==OLD
remote=api('git/ref/heads/dev');save('REMOTE-AT-START.json',remote);assert remote['object']['sha']==TIP
tc=api('git/commits/'+TIP);save('TIP-COMMIT.json',tc);assert[p['sha']for p in tc['parents']]==['05c4b30a5f1376d59de13f0ebc35a820e3d99ae1']and tc['message'].startswith('changelog: fold entry files');fc=api('git/commits/05c4b30a5f1376d59de13f0ebc35a820e3d99ae1');save('FEATURE-COMMIT.json',fc);assert[p['sha']for p in fc['parents']]==['d3a1f4dbfcae2f7c106001c287e134acd2afdd9e'];lc=api('git/commits/d3a1f4dbfcae2f7c106001c287e134acd2afdd9e');save('CHECKED-C6-LANDING-COMMIT.json',lc);assert[p['sha']for p in lc['parents']]==[OLD,'b2920a32864bd2494237c0510c170ae42c8c25e3']and lc['tree']['sha']=='3ef34a2d7086e348350d65489345e2cb344d62e8'
TREE=tc['tree']['sha'];assert TREE=='e4aa27e2f30e442a4eb2083c610cf706120235fd'
compare=api('compare/'+OLD+'...'+TIP);save('BASE-TIP-COMPARE.json',compare)
priced=json.loads(Path('/tmp/current-dev-C6-d3a1-Shipman05c4-fold-price-20261027T0417/BASE-TIP-COMPARE.json').read_text());assert[(r['filename'],r['status'],r['sha'])for r in compare['files']]==[(r['filename'],r['status'],r['sha'])for r in priced['files']]
tree=api('git/trees/'+TREE+'?recursive=1');assert not tree.get('truncated');save('TIP-RECURSIVE-TREE.json',tree);leaves=[r for r in tree['tree']if r['type']!='tree'];by={r['path']:r for r in leaves};changes=[by[r['filename']]for r in compare['files']if r['status']!='removed'];present=indexed([r['sha']for r in changes]);missing=[r for r in changes if r['sha']not in present]
assert sum(r['size']for r in missing)==25435608 and len(missing)==23
assert shutil.disk_usage('/workspace').free>=FLOOR+sum(r['size']for r in missing)
with(B/'metadata-fetch.log').open('xb')as log:
 p=subprocess.Popen(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',TIP],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);abort=None;peak=0
 while p.poll()is None:
  size=sum(f.stat().st_size for f in(R/'objects').rglob('*')if f.is_file());peak=max(peak,size)
  if size>32*1024**2 or b'filtering not recognized'in(B/'metadata-fetch.log').read_bytes().lower():abort='filter/isolationbound';os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(.15)
 rc=p.wait()
save('METADATA-FETCH.json',{'exit':rc,'peak':peak,'abort':abort});assert rc==0 and not abort
actual={}
for row in git(R,'ls-tree','-r','-z',TIP).split(b'\0'):
 if row:
  a,n=row.split(b'\t',1);m,t,s=a.decode().split();actual[n.decode()]={'mode':m,'type':t,'sha':s}
assert actual=={r['path']:{k:r[k]for k in ['mode','type','sha']}for r in leaves}
metadata={};packs=[]
for pack in sorted((R/'objects/pack').glob('*.pack')):
 if(G/'objects/pack'/pack.name).exists():continue
 ids=[]
 for line in git(R,'verify-pack','-v',str(pack.with_suffix('.idx'))).decode().splitlines():
  c=line.split()
  if len(c)>4 and len(c[0])==40 and c[1]in ['commit','tree','tag','blob']:assert c[1]!='blob';ids.append(c[0])
 known=indexed(ids);canon=git(R,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines()
 for line in canon:
  obj,kind,size=line.split()
  if obj not in known:metadata[obj]={'kind':kind,'canonical_bytes':int(size)}
 packs.append(pack)
pending=None
if '630dac21b448ba97337c45fdc00de7ac039e1831'not in indexed(['630dac21b448ba97337c45fdc00de7ac039e1831']):
 import base64
 ob=api('git/blobs/630dac21b448ba97337c45fdc00de7ac039e1831');assert ob['encoding']=='base64';data=base64.b64decode(ob['content']);assert len(data)==ob['size']<4096 and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==ob['sha'];pending=({'path':'chicago/4d/changelog.d/T-3168.json@Shipman05c4','sha':ob['sha'],'size':len(data)},data)
raw=sum(r['size']for r in missing)+sum(r['canonical_bytes']for r in metadata.values())+(len(pending[1])if pending else 0);assert raw<=CAP;ENVELOPE=raw
assert shutil.disk_usage('/workspace').free>=FLOOR+raw+sum(x.stat().st_size for x in packs)
save('CANONICAL-RAW-OBJECT-PRICE.json',{'old':OLD,'tip':TIP,'tree':TREE,'missing_tip_blobs':missing,'new_metadata':metadata,'canonical_raw_total':raw,'intermediate_pending_bytes':len(pending[1])if pending else 0,'standing_authority_cap':CAP,'envelope':ENVELOPE,'workspace_free_before':shutil.disk_usage('/workspace').free,'minimum_postimport_reserve':FLOOR,'membership':'Read-only local pack-index binarysearch/loose exact path presence; no missing object cat-file probes or lazyfetch.'});assert snap()==before
allocation=0;packrows=[]
for pack in packs:
 data=pack.read_bytes();assert hashlib.sha1(data[:-20]).digest()==data[-20:]
 for src in [pack,pack.with_suffix('.idx'),pack.with_suffix('.promisor')]:
  if not src.exists():continue
  dest=G/'objects/pack'/src.name;assert not dest.exists();tmp=dest.with_name('.'+dest.name+'.pullman-'+str(os.getpid()));shutil.copy2(src,tmp);assert sha(src)==sha(tmp);tmp.rename(dest);allocation+=dest.stat().st_blocks*512;packrows.append({'name':src.name,'bytes':src.stat().st_size,'sha256':sha(src)})
save('PACK-IMPORT.json',packrows)
def store(row,data):
 global allocation
 raw=b'blob '+str(len(data)).encode()+b'\0'+data;assert len(data)==row['size']and hashlib.sha1(raw).hexdigest()==row['sha'];dest=G/'objects'/row['sha'][:2]/row['sha'][2:];assert not dest.exists();dest.parent.mkdir(exist_ok=True);tmp=dest.with_name(dest.name+'.pullman-'+str(os.getpid()));enc=zlib.compress(raw);tmp.write_bytes(enc);assert hashlib.sha1(zlib.decompress(tmp.read_bytes())).hexdigest()==row['sha'];tmp.rename(dest);allocation+=dest.stat().st_blocks*512;assert shutil.disk_usage('/workspace').free>=FLOOR;return {'path':row['path'],'sha':row['sha'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoded_bytes':len(enc)}
rows=[]
for row in missing:
 with urllib.request.urlopen('https://raw.githubusercontent.com/kevinrhaas/chicago/'+TIP+'/'+urllib.parse.quote(row['path'],safe='/'),timeout=90)as response:data=response.read(row['size']+65536)
 rows.append(store(row,data));save('DOWNLOAD-PROGRESS.json',{'complete':len(rows),'total':len(missing),'allocated':allocation})
if pending:rows.append(store(*pending))
save('BLOB-IMPORT.json',rows);ids=sorted({r['sha']for r in leaves if r['type']=='blob'});allchecks=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();assert not any(x.endswith(' missing')for x in allchecks);sizes={r.split()[0]:int(r.split()[2])for r in allchecks};assert all(sizes[r['sha']]==r['size']for r in leaves if r['type']=='blob');assert git(C,'rev-parse',TIP+'^{tree}').decode().strip()==TREE;assert git(C,'merge-base',OLD,TIP).decode().strip()==OLD;assert snap()==before
remote=api('git/ref/heads/dev');save('REMOTE-BEFORE-CAS.json',remote);cas=remote['object']['sha']==TIP
if cas:git(C,'update-ref','refs/remotes/origin/dev',TIP,OLD)
after=snap();save('SOURCE-AFTER.json',after);assert after['metadata']==before['metadata']and after['HEAD']==before['HEAD']and after['status_sha256']==before['status_sha256'];assert after['refs']==([x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+TIP)for x in before['refs']]if cas else before['refs'])
result={'status':'EXACT_CHECKED_C6_SINGLE_SHIPMAN05C4_GENUINE_FOLD00A0_IMPORT_EXPECTED_OLD_CAS_PASS'if cas else'PRICED_IMMUTABLE_FOLD_OBJECTS_READY_REMOTE_MOVED_NO_CAS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old':OLD,'tip':TIP,'tree':TREE,'new_tip_blobs':len(missing),'intermediate_pending_imported':bool(pending),'standing_authority_cap':CAP,'checked_C6_landing':'d3a1f4dbfcae2f7c106001c287e134acd2afdd9e','canonical_new_raw_bytes':raw,'envelope':ENVELOPE,'actual_source_allocated_bytes':allocation,'all_tip_unique_blobs_sizes_verified':len(ids),'cached_origin_dev':git(C,'rev-parse','origin/dev').decode().strip(),'fresh_remote_dev':remote['object']['sha'],'source_HEAD_index_config_merge_status_unchanged':True,'other_refs_unchanged':True,'source_HEAD':before['HEAD'],'workspace_free':shutil.disk_usage('/workspace').free,'workspace_reserve':FLOOR,'tmp_free':shutil.disk_usage('/tmp').free,'no_source_common_fetch_gc_repack_checkout':True,'authorization':'Standing authority for each separately inspected/priced single incoming1904 feature and genuine fold <=64MiB, workspace >=128MiB. Includes independently checked C6 d3a1 landing plus SINGLEShipman05c4 feature and genuine fold00a0 (only pending2382/3168 removals and changelog insert); no new code paths. Smallest exact measured canonical envelope, source standing permission and before/after invariance, fresh-tip/expected-old CAS. No repeated Root yes or all-idle-agent wait.','qualification':'C6 d3a1 is an independently checked actual merge; Shipman05c4 availability ONLY, not its native/app qualification. New1904 master/WEB/record/camera metadata, no generator/tool/runtime changes. Phone400MiB cap unchanged. OriginalT2382 staysOPEN/DIFFERS.'};save('RESULT.json',result);print(json.dumps(result,indent=2))
