// Only texture/base-URL dependencies substituted; no DOM, canvas or GPU is used.
export function resolveBases(){return {assetBase:new URL('file:///cpu-fixture/')};}
export const reliefStats={calls:0,releases:0};
export async function loadTimberRelief(){reliefStats.calls++;return {problem:'CPU fixture: no texture upload',dispose(){reliefStats.releases++;}};}
