V2 consumer disposition

The full v1 consumer map remains frozen in ../T-2375-native-surface-profile/CONSUMERS.md.
Walker/router grid/exactHeight, anchor reporting, compiler sidecar, human root,
flat-footway refusal and scalar defaults remain as there, with the corrected
sidecar placement alias. V2 closes only its rigid parked/yard whole-placement gap.

- Shared eligibility tests actual projected triangles and declared contacts.
- Parked near/support/final-tongue/mid geometry is checked before batching/addition.
  Profile refusal persists by legacy replacement identity. Visibility transitions
  and disposal cannot revive a refused identity; ordinary failures retain fallback.
- Yard frontage/lot items, wagons/carts (including gears, tongues, shafts, yokes and
  hogsheads), benches, sheds and outbuildings all pass through one transaction.
  Its complete native triangle stream is checked before streams/state/cache and
  picking/census/ownership bookkeeping commit. No arbitrary anchor buffer is used.
- Native tone-cache insertion rollback is necessary: its rounded cache key is
  first-writer-wins. Accepted and flat cache behavior remains unchanged.
- Current 1418 recursive yard anchors comprise 1417 actual emitted objects plus the
  water-place annotation. The actual native CPU inventory covers 239593 triangles;
  none intersects Dearborn's proposed profile. It is not actual terrain/canvas QA.
- Existing standing-horse hoof contacts retain v1's explicit profile refusal.
  Its whole skinned/posed/animated envelope is UNQUALIFIED and is a separate
  follow-up, not silently declared covered by the rigid mesh checks.

Tests invoke actual native APIs/builders with scoped local-data fetches and small
synthetic GLTF fixtures. Only texture/base-URL dependencies are substituted; a
read-only test-loader hook observes prepacking streams/cache. No production hook,
API shortcut, browser or full native acceptance is introduced.
