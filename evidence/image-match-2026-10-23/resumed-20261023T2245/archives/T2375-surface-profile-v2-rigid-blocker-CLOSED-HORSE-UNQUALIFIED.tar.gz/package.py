"""Generate guarded review patches; no canonical writes or generated asset claims."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/chicago')
APP = ROOT / 'chicago/4d'
PRIOR = Path('/tmp/chicago-next-model/T-2375-adoption-kwonly')
meta = json.loads((OUT / 'preimages.json').read_text())
meta.setdefault('surface_preimages', {k:v for k,v in meta['source_preimages'].items() if (OUT/'baseline/chicago/4d'/k).is_file()})

def sha(data):
    return hashlib.sha256(data).hexdigest()

def delta(path, before, after):
    return ''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),
        fromfile='a/chicago/4d/'+path if before else '/dev/null',tofile='b/chicago/4d/'+path))

for rel, expected in meta['source_preimages'].items():
    assert sha((APP / rel).read_bytes()) == expected, rel
assert sha((PRIOR/'MANIFEST.json').read_bytes()) == meta['prior_manifest_sha256']
prior=json.loads((PRIOR/'inputs.json').read_text())
shared={'chicago/4d/docs/LIBERTIES.md','chicago/4d/data/reconstruction/name_pool_keys.json'}
shared_drift={}
for path,expected in prior['preimage_sha256'].items():
    actual=sha((ROOT/path).read_bytes())
    if path in shared:
        if actual!=expected:shared_drift[path]={'prior_preimage':expected,'current_preimage':actual}
    else:
        assert actual==expected,('Prior geometry/source preimage changed',path)

combined={}
overlay={}
for rel in meta['surface_preimages']:
    after=(OUT/'candidate/chicago/4d'/rel).read_bytes()
    before=(APP/rel).read_bytes()
    combined[rel]=(before,after)
    overlay_before=((PRIOR/'candidate/chicago/4d'/rel).read_bytes()
                    if rel.startswith('generators/archetypes/bridge_timber') else before)
    overlay[rel]=(overlay_before,after)
new='renderers/web/js/deck-surface.js'
assert not(APP/new).exists()
combined[new]=overlay[new]=(b'',(OUT/'candidate/chicago/4d'/new).read_bytes())
for path in prior['patch_targets']:
    rel=path.removeprefix('chicago/4d/')
    if rel in combined:
        continue
    before=(ROOT/path).read_bytes()
    if rel=='docs/LIBERTIES.md':
        assert b'L-dearborn-board-parapet-2375'not in before and b'L-dearborn-draw-profile-2375'not in before
        after=before+(PRIOR/'LIBERTIES-APPEND.md').read_bytes()
    elif rel=='data/reconstruction/name_pool_keys.json':
        doc=json.loads(before);old=doc['read']['structures']
        required={'phases[].form.'+x+'.note'for x in ['railing_kind','draw_profile','draw_rise_m','draw_bearing_supports']}
        added=required-set(old);new=old+sorted(added)
        assert [x for x in new if x not in added]==old
        doc['read']['structures']=new
        after=(json.dumps(doc,indent=2,ensure_ascii=False)+'\n').encode()
    else:
        after=(PRIOR/'candidate'/path).read_bytes()
    combined[rel]=(before,after)
    meta['source_preimages'][rel]=sha(before)

(OUT/'combined-adoption.patch').write_text(''.join(delta(k,*v)for k,v in combined.items()))
(OUT/'native-surface-overlay.patch').write_text(''.join(delta(k,*v)for k,v in overlay.items()))
# Only copied files, no Git worktree, publisher or repository index.
overlay_root=OUT/'overlay-base'
for rel,(before,after) in overlay.items():
    if before:
        p=overlay_root/'chicago/4d'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(before)
subprocess.run(['git','apply','--check',str(OUT/'native-surface-overlay.patch')],cwd=overlay_root,check=True)
subprocess.run(['git','apply','--check',str(OUT/'combined-adoption.patch')],cwd=ROOT,check=True)

family=[]
current=json.loads((APP/'assets/manifest.json').read_text())['assets']
for row in prior['six_bridge_family']:
    assert current[row['asset']]==row['master_preimage_manifest']
    for kind,expected in [('gltf',row['master_sha256']),('web',row['web_sha256'])]:
        assert sha((APP/'assets'/kind/row['asset']).read_bytes())==expected
    family.append(row)
meta.update({'combined_patch_targets':list(combined),'overlay_patch_targets':list(overlay),
    'patches_are_alternatives':True,'combined_base':'Current canonical preimages; includes the prior geometry/source/liberty/reader payload',
    'overlay_base':'The prior frozen geometry/API candidate for the two generator modules, current snapshots for all other files',
    'six_bridge_family':family,'official_refresh':'All six real masters and web derivatives still required; zero versions',
    'acceptance':'CPU/Node proposal controls only; source image verdict differs; no canonical adoption, supported bake, browser/app or full gate',
    'Baker_Co_rights':'Unchanged check_required; Andreas1884p631 independently public_domain; no new rights claim',
    'frozen_original_sha256':prior['frozen_original_sha256'],
    'shared_metadata_recomposition':{'changed_preimages':shared_drift,'method':'Append exact normalized liberties to current full ledger; insert only four required readers into current JSON; preserve all independent edits'},
    'support_source_sha256':{rel:sha((APP/rel).read_bytes())for rel in ['renderers/web/js/parked-transport.js','renderers/web/js/yard.js','renderers/web/js/standing-horses.js','renderers/web/js/travel.js','renderers/web/js/controls/intent.js','renderers/web/js/terrain.js','renderers/web/vendor/three-0.185.1/three.module.js','renderers/web/vendor/three-0.185.1/addons/loaders/GLTFLoader.js','renderers/web/vendor/three-0.185.1/addons/utils/SkeletonUtils.js']}})
(OUT/'preimages.json').write_text(json.dumps(meta,indent=2)+'\n')
print('PASS: guarded combined and overlay patch checks; six unchanged master/recipe preimages; no asset or canonical writes.')
