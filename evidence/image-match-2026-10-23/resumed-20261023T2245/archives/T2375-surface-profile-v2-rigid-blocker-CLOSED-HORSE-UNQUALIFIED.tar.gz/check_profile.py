"""CPU: shared mesh/profile, exact flat defaults and real compiler placement dict."""
from pathlib import Path
import ast
import copy
import dataclasses
import hashlib
import importlib.util
import inspect
import json
import math
import sys
import types

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
APP = Path('/workspace/chicago/chicago/4d')
PRIOR = Path('/tmp/chicago-next-model/T-2375-adoption-kwonly')
NEW = OUT / 'candidate/chicago/4d'
BASE = OUT / 'baseline/chicago/4d'
sys.path.insert(0, str(APP / 'generators'))
sys.modules['bpy'] = types.ModuleType('bpy')
for name in ['mesh.py','logwork.py','materials.py']:
    assert (APP/'generators/common'/name).read_bytes() == (PRIOR/'baseline/chicago/4d/generators/common'/name).read_bytes()
from common import mesh

def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m

def pair(name, root):
    p = load(name+'_params', root/'generators/archetypes/bridge_timber_params.py')
    sys.modules['archetypes.bridge_timber_params'] = p
    b = load(name+'_builder', root/'generators/archetypes/bridge_timber.py')
    class Raw(mesh.MeshBuilder):
        def to_object(self, mats=None):
            self.captured_materials = mats
            return self
    b.MeshBuilder = Raw
    b.simple_material = lambda name, *a, **kw: dict(name=name, args=a, kwargs=kw)
    return p, b

def raw(builder, params, name):
    b = builder.build(params, name)
    return {k: getattr(b, k) for k in ['verts','faces','conf','mat_index','named','captured_materials']}

oldp, oldb = pair('old', BASE)
frozenp, frozenb = pair('frozen', PRIOR/'rendered-candidate')
newp, newb = pair('new', NEW)
assert [x for x in inspect.signature(newp.BridgeTimberParams).parameters.values()
        if x.kind != inspect.Parameter.KEYWORD_ONLY] == list(inspect.signature(oldp.BridgeTimberParams).parameters.values())
assert newp.BridgeTimberParams.__match_args__ == oldp.BridgeTimberParams.__match_args__
old_fields=dataclasses.fields(oldp.BridgeTimberParams)
new_fields={x.name:x for x in dataclasses.fields(newp.BridgeTimberParams)}
for field in old_fields:
    actual=new_fields[field.name]
    assert (actual.default,actual.default_factory,actual.kw_only)==(field.default,field.default_factory,field.kw_only)
assert all(new_fields[name].kw_only for name in ['railing_kind','draw_profile','draw_rise_m','draw_bearing_supports'])

def compiler(root, params):
    source = root/'tools/compile_scene.py'
    tree = ast.parse(source.read_text())
    wanted = ['vertical_anchor','walk_surface_m','walk_surface_profile']
    functions = [x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name in wanted]
    scope = {'ROOT': root, 'sys': sys}
    sys.modules['archetypes.bridge_timber_params'] = params
    exec(compile(ast.Module(body=functions,type_ignores=[]),str(source),'exec'),scope)
    placements = [x for x in ast.walk(tree) if isinstance(x,ast.Dict)
                  and any(isinstance(k,ast.Constant)and k.value=='walk_surface_m' for k in x.keys if k)]
    assert len(placements)==1
    return scope, compile(ast.Expression(placements[0]),str(source),'eval')

def placement(scope, expr, record, phase, side):
    pos = phase.get('position', {})
    loc = side['placement']
    return eval(expr, {**scope,'pos':pos,'st':record,'phase':phase,
                       'local_e':loc['local_e'],'local_n':loc['local_n'],
                       'provisional':loc['placement_provisional']})

manifest=json.loads((APP/'assets/manifest.json').read_text())['assets']
family=[dict(asset=k,**v)for k,v in manifest.items()if v.get('archetype')=='bridge_timber']
assert len(family)==6
baseline_sides=[]; default_checks=[]
for row in family:
    record=json.loads((APP/'data/structures'/f"{row['structure_id']}.json").read_text())
    phase=next(p for p in record['phases']if p['id']==row['phase_id'])
    side=json.loads((APP/'data/sidecars/1835'/f"{row['structure_id']}.json").read_text())
    op=oldp.from_phase(phase,record);np=newp.from_phase(phase,record)
    legacy_args=[getattr(op,name)for name in oldp.BridgeTimberParams.__match_args__]
    positional=newp.BridgeTimberParams(*legacy_args)
    assert all(getattr(positional,x.name)==getattr(op,x.name)for x in old_fields)
    try:newp.BridgeTimberParams(*legacy_args,'board')
    except TypeError:pass
    else:raise AssertionError('New field unexpectedly accepted positionally')
    assert raw(oldb,op,row['asset'])==raw(newb,np,row['asset'])
    assert newp.walk_surface_profile(np) is None
    a,expr=compiler(BASE,oldp);before=placement(a,expr,record,phase,side)
    b,expr=compiler(NEW,newp);after=placement(b,expr,record,phase,side)
    assert before==after==side['placement'] and 'walk_surface_profile'not in after
    baseline_sides.append({'id':row['structure_id'],'sidecar':side})
    default_checks.append({'asset':row['asset'],'raw_geometry_materials_confidence_exact':True,'compiler_placement_dict_exact':True})

record=json.loads((PRIOR/'candidate/chicago/4d/data/structures/dearborn_street_drawbridge.json').read_text())
phase=record['phases'][0];p=newp.from_phase(phase,record)
a=raw(frozenb,frozenp.from_phase(phase,record),'dearborn_street_drawbridge__draw_1834')
b=raw(newb,p,'dearborn_street_drawbridge__draw_1834')
assert a==b
raw_four={key:b[key]for key in ['verts','faces','conf','mat_index']}
raw_digest=hashlib.sha256(json.dumps(raw_four,separators=(',',':')).encode()).hexdigest()
assert raw_digest=='8db45fe611fb6b25d59b9c80808858905ab8a1b201834f216b1dd58668df10d3'
profile=newp.walk_surface_profile(p)
samples=json.loads((PRIOR/'height-samples.json').read_text())
side=copy.deepcopy(samples['sidecar'])
scope,expr=compiler(NEW,newp)
side['placement']=placement(scope,expr,record,phase,side)
assert side['placement']['walk_surface_profile']==profile
assert profile['stations_m'][2][1]==p.deck_height_m+1.2
for point in samples['samples']:
    # These expectations are positive ray intersections with actual proposed triangles.
    assert math.isclose(p.deck_height_m+newp.draw_rise_m_at(p,point['local_x_m']),point['actual_generated_board_top_m'],abs_tol=1e-9)
assert scope['walk_surface_profile']({'archetype':'not_a_real_type'}, {}) is None
for value in [float('nan'),float('inf'),True,-1,4]:
    try:newp.walk_surface_profile(dataclasses.replace(p,draw_rise_m=value))
    except newp.ParamError:pass
    else:raise AssertionError(value)

# Named flat footways must explicitly refuse a future non-flat host rather than
# drawing another flat layer over it. Everything after the guard is AST-identical.
def named_walk(root):
    return next(x for x in ast.parse((root/'tools/generate_frontage_works.py').read_text()).body
                if isinstance(x,ast.FunctionDef)and x.name=='build_lasalle_crossing_walk')
old_walk=named_walk(BASE);new_walk=named_walk(NEW)
guards=[(i,x)for i,x in enumerate(new_walk.body)if isinstance(x,ast.If)
        and 'walk_surface_profile' in ast.unparse(x.test)]
assert len(guards)==1
i,_=guards[0];without=copy.deepcopy(new_walk);without.body.pop(i)
assert ast.dump(without,include_attributes=False)==ast.dump(old_walk,include_attributes=False)
prefix=copy.deepcopy(new_walk);prefix.body=prefix.body[:i+1]
def footway_guard(host):
    env={'SIDECARS':Path('/not-used'),'LASALLE_BRIDGE':'fixture','_load':lambda _:host}
    exec(compile(ast.Module(body=[prefix],type_ignores=[]),'native-footway-guard','exec'),env)
    return env['build_lasalle_crossing_walk']()
assert footway_guard({'placement':{'walk_surface_m':2.22}}) is None
try:footway_guard(side)
except SystemExit as error:assert 'profile-aware footway' in str(error)
else:raise AssertionError('Non-flat host accepted by flat footway')
(OUT/'fixture.json').write_text(json.dumps({'flat_sides':baseline_sides,'profile_side':side,'samples':samples['samples']},indent=2)+'\n')
report={'status':'PASS CPU only','six_default_raw_and_native_compiler_placements':default_checks,
        'legacy20_positional_API_preserved':True,'full_rendered_candidate_raw_outputs_exact':True,
        'raw_mesh_sha256':raw_digest,'rendered_common_helpers_exact':True,
        'profile':profile,'positive_triangle_backed_samples':len(samples['samples']),
        'bad_rises_refused':True,'missing_archetype_default_stays_profile_absent':True,
        'flat_footway_AST_unchanged_and_nonflat_host_explicitly_refused':True,
        'no_Blender_browser_fullgate_or_canonical_write':True}
(OUT/'cpu-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: six raw/placement defaults exact; shared profile preserves rendered mesh; seven triangle-backed samples; invalid rises refused.')
