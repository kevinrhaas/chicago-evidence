T-2375 native surface profile v2 — closed proposal, production acceptance pending

This closes v1's concrete parked/legacy-yard blocker in isolated native CPU
controls. Immutable v1 is `/tmp/chicago-next-model/T-2375-native-surface-profile`,
manifest 20125984f22fd5b70cc98db09b516acb4e20de4d84aba127244e3b0808ec97cc.
No canonical changes, claims, Blender, browser or full gate occurred. The original
image ticket remains open/differs. Standing-horse whole-body/animated envelopes
remain explicitly unqualified; root requested a separate bounded follow-up.

The full already rendered candidate remains unchanged: horizontal-board parapets,
reconstructed 1.2 m closed central rise and aligned bearing cribs. All 20 legacy
positional constructor parameters/defaults/factories/match args remain exact;
four new fields stay keyword-only. Six default bridge raw geometry/material/
confidence outputs and compiler placement dictionaries remain exact. Seven actual
triangle-backed heights match the common sampler; the full candidate raw hash is
8db45fe611fb6b25d59b9c80808858905ab8a1b201834f216b1dd58668df10d3.

V2 adds one shared whole-placement eligibility for rigid parked vehicles and yard
objects. It tests the actual planned/emitted projected triangles and explicit
wheel/static-support/tongue contacts against the actual non-flat span polygon,
including crossing edges, contained polygons and vertical projected triangles.
The only tolerance is numerical 1e-8; there is no enlarged geographic radius.
Refined meshes include their authored transforms, added support mesh and final
tongue pose; optional mid-LOD mesh triangles are checked too. A profile refusal
persists by replacement identity, so neither an initial nor already-emitted
legacy fallback can remain visible or be revived by tier changes, setters,
updates or disposal. Ordinary load failures retain eligible fallbacks.

Every yard object emits transactionally into scratch streams. Refusal, false
returns and exceptions leave no positions, normals, colors, confidence, UV/UV1,
material/grain state, picking spans, ownership ranges or object counters committed.
New entries in the native first-writer-wins tone cache are also rolled back;
otherwise a refused object could influence a later accepted object's shade.
When all objects are refused, the layer releases its atlas/shared-relief hold.
The existing record-global mark atlas is predeclared, not per-object emission;
unused shared cells may exist beside accepted objects, as in the native original.
Its canvas/rendering path is not certified by these no-DOM fixtures.

Actual controls (`v2-receipt.json`):

- Native createParkedTransport API refuses wheel, support contact, tongue, body,
  support-mesh and late light→full cases without rejected instances/children or
  retained legacy geometry. Actual native createYardGoods API rejects v1's
  outside-anchor overlap; the unchanged original API emits it as a negative control.
- An already-emitted safe native fallback is hidden after a later refined refusal;
  native visibility/update/disposal cannot revive its banned identity. An ordinary
  non-profile asset failure still retains the eligible legacy wagon.
- Mixed chunks after refusal equal clean native output. Cache contents and all
  six raw streams after reject-before-accept equal the clean original from cold
  modules. Scratch refusal/false/exception controls retain stream/state/cache bytes.
- All current 8 yard records pass through the actual native API/builders:
  1,417 emitted objects /239,593 triangles, zero profile intersections. Their full
  raw streams/final material-grain state and packed geometry/material/confidence/
  census/picking spans remain exact. The older 1,418 point count includes one
  non-emitted `town_water_cart.the_place` geographic annotation. Bounds and hashes
  of every emitted object are recorded. This uses finite flat CPU terrain and
  native no-DOM unmarked/no-relief degradation, not actual heightfield/canvas/GPU.

Unchanged native validate.check_sidecar_contract passes on a temporary overlay of
all 265 current renderer JS files and 979 actual listed committed sidecars plus the
candidate sidecar's actual compiler-emitted placement/profile. Missing-profile
and nonexistent-field negatives remain red. The first scan reproduced the local
alias false positive (`placement.every`/`placement.length`); only that placement
alias became `deckPlacement`. The pre-rename red receipt remains. No scanner,
assertion or emitted-field invention was used.

`combined-adoption.patch` includes the complete geometry/source/liberty/reader and
native proposal against exact current preimages. `native-surface-overlay.patch`
is an alternative over the prior keyword-only geometry/API proposal. Never apply
both. `preimages.json` enumerates actual 6 family master/web/recipe/record hashes,
all code/data preimages, prior frozen artifacts and shared-metadata recomposition.
Read-only `verify.py` checks these guards, syntax, manifest and patch applicability.
Tests write only this proposal; copy the closed directory before reproducing them.
No official 6 family refresh, native full compiler/publisher derivation, app/browser
verification or full gate has run for this proposal. Root retains adoption/grants.

Historical and visual limits are unchanged: the 1.2 m rise is reconstruction, not a
measured mechanism. Actual prior v2 export/comparison is
`/tmp/chicago-next-model/T-2375-next/preview/comparisons/andreas-provisional-side-by-side.jpg`,
GLB SHA 107b76243e85ccf10a980cc96a2aa18487a2345a5a5e45f1db00a310be452648.
Its principal point reaches a bound; retrospective perspective and machinery stay
uncertain. The independently rendered smaller option is boards-only/flat/original
cribs under `/tmp/chicago-next-model/T-2375/preview/`; boards-plus-aligned-cribs
without rise is unrendered and has not silently replaced the full candidate.
Cleared Andreas 1884 vol.1 p.631/L. Braunhold artwork source correction and both liberty
fragments are retained. Baker-Co remains check_required. No borrowed image texture,
new phase/scene date, calibrated camera or accepted image match is asserted.
