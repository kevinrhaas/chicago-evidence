
## Optional span walk-surface profile

A water-anchored crossing may additionally declare
`placement.walk_surface_profile = {"version":1,"axis":"local_x","stations_m":[[x,z],...]}`.
Both coordinates are metres: `x` is the structure footprint's local polygon x;
`z` is height above the same water anchor as `walk_surface_m`. This is numeric
dataset geometry, not a camera, renderer object, mesh-material name or animation.
It is generated from the same pure archetype profile used by the deck builder.

The field is absent for flat defaults. Their existing scalar and placement output
stay unchanged. When present, the first station is at x=0, the last at the
footprint's maximum x; stations increase strictly and every coordinate is finite.
Both endpoint heights equal `walk_surface_m`, preserving this profile's approach
contact. Between stations height is linearly interpolated; there is no
extrapolation outside the declared span. This models the chosen closed-draw
display profile, not an operating lift or an attested historic mechanism.

Consumers transform ENU into the existing local footprint frame, sample the
profile, and retain the existing highest-deck, water and terrain policies. A
profile's scalar alone is not its interior floor. Walking, router grid/exact
checks and anchor reports share one sampler. Rigid parked vehicles and complete yard placements use shared eligibility
against the profile's actual polygon: declared wheel/support/tongue points and
actual projected triangles, including secondary pieces, must avoid the occupied
span unless a future profile-aware support model qualifies them. An unsupported
intersection refuses the whole placement and its legacy replacement fallback.
Yard emission commits all streams/material state/ownership/census only after its
complete geometry passes, and rolls back newly inserted tone-cache entries on
refusal. Scalar flat defaults bypass this optional machinery unchanged.
Standing-horse point contacts remain explicitly refused on the span; its full
skinned/animated envelope remains unqualified and requires a separate review.
Human root contacts use the sampled surface; this does not certify foot IK, body
clearance or historical placement. Invalid declared profiles are errors, never
silently flattened.
