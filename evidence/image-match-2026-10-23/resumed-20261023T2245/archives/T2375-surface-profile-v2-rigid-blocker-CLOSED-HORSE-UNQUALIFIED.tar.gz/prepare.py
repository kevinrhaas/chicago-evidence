"""Compose an isolated native-profile overlay; never write canonical trees."""
from pathlib import Path
import hashlib
import json
import re
import shutil

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/chicago')
APP = ROOT / 'chicago/4d'
PRIOR = Path('/tmp/chicago-next-model/T-2375-adoption-kwonly')
assert not (OUT / 'preimages.json').exists(), 'Preserve prepared snapshots'
paths = [
    'generators/archetypes/bridge_timber_params.py', 'generators/archetypes/bridge_timber.py',
    'tools/compile_scene.py', 'tools/measure_anchors.mjs',
    'renderers/web/js/walker.js', 'renderers/web/js/route.js',
    'renderers/web/js/main.js', 'renderers/web/js/humans.js',
    'tools/generate_frontage_works.py',
    'docs/GLB-CONTRACT.md',
]
hashes = {}
for rel in paths:
    raw = (APP / rel).read_bytes()
    hashes[rel] = hashlib.sha256(raw).hexdigest()
    for name in ['baseline', 'candidate']:
        p = OUT / name / 'chicago/4d' / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(raw)
candidate = OUT / 'candidate/chicago/4d'
for rel in paths[:2]:
    # Previously proved keyword-only geometry/API proposal, still immutable.
    (candidate / rel).write_bytes((PRIOR / 'candidate/chicago/4d' / rel).read_bytes())

def update(rel, old, new):
    p = candidate / rel
    s = p.read_text()
    assert s.count(old) == 1, (rel, old[:80], s.count(old))
    p.write_text(s.replace(old, new))

p = candidate / paths[0]
p.write_text(p.read_text() + '''

def draw_rise_m_at(params: BridgeTimberParams, x: float) -> float:
    """One pure closed-draw profile for the mesh and engine-neutral sidecar."""
    if params.draw_profile == "flat" or not params.draw_span_m:
        return 0.0
    mid = params.span_m / 2.0
    half = params.draw_span_m / 2.0
    if x <= mid - half or x >= mid + half:
        return 0.0
    return params.draw_rise_m * (1.0 - abs(x - mid) / half)


def walk_surface_profile(params: BridgeTimberParams):
    """Optional local polygon-x metres / height-above-anchor metres, no engine data."""
    params.validate()
    if params.draw_profile == "flat":
        return None
    mid = params.span_m / 2.0
    half = params.draw_span_m / 2.0
    stations = [0.0, mid-half, mid, mid+half, params.span_m]
    return {"version": 1, "axis": "local_x", "stations_m": [
        [x, params.deck_height_m + draw_rise_m_at(params, x)] for x in stations]}
''')
update(paths[1], 'from archetypes.bridge_timber_params import BridgeTimberParams',
       'from archetypes.bridge_timber_params import BridgeTimberParams, draw_rise_m_at')
builder = candidate / paths[1]
s = builder.read_text()
start = s.index('def _draw_rise(')
end = s.index('\n\ndef _clip_x', start)
s = s[:start] + '''def _draw_rise(p: BridgeTimberParams, x: float) -> float:
    """The same pure resolved profile serialized for native surface consumers."""
    return draw_rise_m_at(p, x)
''' + s[end:]
builder.write_text(s)

compiler_addition = '''def walk_surface_profile(structure: dict, phase: dict):
    """Optional archetype-owned local-span profile; omit for every flat default."""
    arch = structure.get("archetype")
    if not arch:
        return None
    gen = str(ROOT / "generators")
    if gen not in sys.path:
        sys.path.insert(0, gen)
    try:
        mod = __import__(f"archetypes.{arch}_params", fromlist=["from_phase"])
    except ImportError:
        return None
    reader = getattr(mod, "walk_surface_profile", None)
    if not callable(reader):
        return None
    return reader(mod.from_phase(phase, structure))


'''
update(paths[2], 'def walk_passages(structure: dict, phase: dict):',
       compiler_addition + 'def walk_passages(structure: dict, phase: dict):')
update(paths[2], '                "walk_surface_m": walk_surface_m(st, phase),',
       '''                "walk_surface_m": walk_surface_m(st, phase),
                **({"walk_surface_profile": profile}
                   if (profile := walk_surface_profile(st, phase)) is not None else {}),''')

walker = candidate / paths[4]
s = walker.read_text()
s = s.replace("import * as THREE from 'three';", "import * as THREE from 'three';\nimport { deckFromSidecar, deckHeightAt } from './deck-surface.js';", 1)
start = s.index('export function decksFrom(registry) {')
end = s.index('\n/**', start)
s = s[:start] + '''export function decksFrom(registry) {
  const out = [];
  for (const record of registry.values()) {
    const deck = deckFromSidecar(record.id, record.sidecar);
    if (deck) out.push(deck);
  }
  return out;
}
''' + s[end:]
old = """      if ((deckY !== null && d.y <= deckY) || !inside(e, n, d.pts)) continue;
      deckY = d.y;"""
assert s.count(old) == 1
s = s.replace(old, """      if (!inside(e, n, d.pts)) continue;
      const y = deckHeightAt(d, e, n);
      if (typeof y === 'number' && (deckY === null || y > deckY)) deckY = y;""")
walker.write_text(s)

route = candidate / paths[5]
route.write_text("import { deckHeightAt } from './deck-surface.js';\n" + route.read_text())
update(paths[5], 'deckBoxes.push({ pts: d.pts, y: d.y, ...bb });', 'deckBoxes.push({ ...d, ...bb });')
update(paths[5], '''          } else if (cls[k] === CLS_BLOCKED) {
            hgt[k] = d.y;               // over water: the deck wins outright
          } else {
            hgt[k] = Math.max(hgt[k], d.y);
          }''', '''          } else if (cls[k] === CLS_BLOCKED) {
            hgt[k] = deckHeightAt(d, e, n); // over water: the sampled deck wins
          } else {
            hgt[k] = Math.max(hgt[k], deckHeightAt(d, e, n));
          }''')
update(paths[5], """      if ((deckY !== null && d.y <= deckY) || !inside(e, n, d.pts)) continue;
      deckY = d.y;""", """      if (!inside(e, n, d.pts)) continue;
      const y = deckHeightAt(d, e, n);
      if (typeof y === 'number' && (deckY === null || y > deckY)) deckY = y;""")

update(paths[3], "import path from 'node:path';", "import path from 'node:path';\nimport { deckFromSidecar, deckHeightAt } from '../renderers/web/js/deck-surface.js';")
update(paths[3], 'async function sceneOutlines(scene) {', '''export function anchorDeckHeight(row, e, n) {
  return row.deck_surface ? deckHeightAt(row.deck_surface, e, n) : row.walk_surface_m;
}

async function sceneOutlines(scene) {''')
update(paths[3], '        walk_surface_m: sidecar.placement?.walk_surface_m ?? null,',
       '''        walk_surface_m: sidecar.placement?.walk_surface_m ?? null,
        ...(sidecar.placement?.walk_surface_profile != null
          ? { deck_surface: deckFromSidecar(name.replace(/\\.json$/, ''), sidecar) } : {}),''')
update(paths[3], '      deck_m: deck ? deck.walk_surface_m : null,',
       '      deck_m: deck ? anchorDeckHeight(deck, e, n) : null,')

update(paths[6], "import { createWalker, footprintsFrom, decksFrom, WALK } from './walker.js';",
       "import { createWalker, footprintsFrom, decksFrom, WALK } from './walker.js';\nimport { profiledGroundHeight, refuseProfiledSupportTerrain, refuseProfiledSupportHeight } from './deck-surface.js';")
update(paths[6], '  const decks = decksFrom(loaded.registry);',
       '''  const decks = decksFrom(loaded.registry);
  // Rigid props/supports cannot span a sloped bridge without an authored contact model.
  // Their existing finite-ground guards refuse these points; flat defaults are exact.
  const rigidSupportTerrain = refuseProfiledSupportTerrain(terrain, decks);''')
update(paths[6], "dataBase: layerBase('parked_transport'), sceneId: YEAR, terrain, confidence,",
       "dataBase: layerBase('parked_transport'), sceneId: YEAR, terrain: rigidSupportTerrain, confidence,")
update(paths[6], "groundHeight: String(YEAR) === '1904' ? (e, n) => streetGrid.carriagewayHeight(e, n) : null,",
       "groundHeight: String(YEAR) === '1904' ? refuseProfiledSupportHeight(decks, (e, n) => streetGrid.carriagewayHeight(e, n)) : null,")
update(paths[6], 'groundHeight: (e, n, recordId, regionId) => yards.drawnBaseHeightAt(e, n, recordId, regionId),',
       'groundHeight: refuseProfiledSupportHeight(decks, (e, n, recordId, regionId) => yards.drawnBaseHeightAt(e, n, recordId, regionId)),')
update(paths[6], "dataBase: layerBase('yard_goods'), terrain, confidence, problems: layerProblems('yard_goods'), hostMissing,",
       "dataBase: layerBase('yard_goods'), terrain: rigidSupportTerrain, confidence, problems: layerProblems('yard_goods'), hostMissing,")
update(paths[6], '    people, terrain, tier: detailLevel, problems: layerProblems(\'humans\'),',
       '''    people, terrain, tier: detailLevel, problems: layerProblems('humans'),
    groundHeight: (e, n) => profiledGroundHeight(terrain, decks, e, n),''')
update(paths[7], '  problems = [], fetchImpl = fetch, contract = null,',
       '  problems = [], fetchImpl = fetch, contract = null, groundHeight = null,')
update(paths[7], '  const heightAt = terrain ? (e, n) => terrain.surfaceHeight(e, n) : () => 0;',
       '  const heightAt = groundHeight ?? (terrain ? (e, n) => terrain.surfaceHeight(e, n) : () => 0);')

update(paths[8], '    place = bridge.get("placement") or {}\n',
       '    place = bridge.get("placement") or {}\n    if place.get("walk_surface_profile") is not None:\n        raise SystemExit("generate_frontage_works: a non-flat host needs a profile-aware footway; flat boards refused")\n')

target = candidate / 'renderers/web/js/deck-surface.js'
target.write_bytes((OUT / 'deck-surface.js').read_bytes())
contract = candidate / 'docs/GLB-CONTRACT.md'
contract.write_bytes(contract.read_bytes() + (OUT / 'CONTRACT-APPEND.md').read_bytes())
report = {'source_repo': str(ROOT), 'source_preimages': hashes, 'surface_preimages': hashes.copy(),
          'prior_geometry_API_package': str(PRIOR),
          'prior_manifest_sha256': hashlib.sha256((PRIOR / 'MANIFEST.json').read_bytes()).hexdigest(),
          'new_file': 'renderers/web/js/deck-surface.js',
          'canonical_writes': False, 'official_gate_bake_browser': False}
(OUT / 'preimages.json').write_text(json.dumps(report, indent=2)+'\n')
print('Prepared optional numeric profile, coherent native samplers and point-contact refusal wiring; whole-placement unqualified; isolated proposal only.')
