
/** Whole placements are refused only where their actual projected triangles or
 * declared contact points touch a non-flat span. No expanded exclusion radius. */
export function createProfilePlacementEligibility(decks) {
  const spans = decks.filter(d => d.profile).map(d => ({ ...d,
    e0: Math.min(...d.pts.map(p => p[0])), e1: Math.max(...d.pts.map(p => p[0])),
    n0: Math.min(...d.pts.map(p => p[1])), n1: Math.max(...d.pts.map(p => p[1])),
  }));
  if (!spans.length) return null;
  const orient = (a, b, c) => (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
  const on = (p, a, b) => Math.abs(orient(a,b,p)) <= EPS
    && p[0] >= Math.min(a[0],b[0])-EPS && p[0] <= Math.max(a[0],b[0])+EPS
    && p[1] >= Math.min(a[1],b[1])-EPS && p[1] <= Math.max(a[1],b[1])+EPS;
  const segments = (a,b,c,d) => {
    const abC=orient(a,b,c), abD=orient(a,b,d), cdA=orient(c,d,a), cdB=orient(c,d,b);
    return (abC*abD < 0 && cdA*cdB < 0) || on(c,a,b) || on(d,a,b) || on(a,c,d) || on(b,c,d);
  };
  const covered = (p, poly) => insideDeck(...p,poly) || poly.some((a,i) => on(p,a,poly[(i+1)%poly.length]));
  const inTriangle = (p,a,b,c) => {
    if (Math.abs(orient(a,b,c)) <= EPS) return false;
    const s=[orient(a,b,p),orient(b,c,p),orient(c,a,p)];
    return s.every(x=>x>=-EPS) || s.every(x=>x<=EPS);
  };
  const refusal = d => `unsupported whole placement intersects profiled span ${d.id}`;
  const pointsReason = points => {
    for (const p of points) {
      if (!Array.isArray(p) || p.length!==2 || !p.every(finite)) throw Error('Invalid placement contact point');
      for (const d of spans) if (covered(p,d.pts)) return refusal(d);
    }
    return null;
  };
  const trianglesReason = positions => {
    if (positions.length % 9) throw Error('Invalid placement triangle stream');
    for (let i=0;i<positions.length;i+=9) {
      for(let j=0;j<9;j++) if (!finite(positions[i+j])) throw Error('Non-finite placement triangle');
      const t=[[positions[i],-positions[i+2]],[positions[i+3],-positions[i+5]],[positions[i+6],-positions[i+8]]];
      if (!t.every(p=>p.every(finite))) throw Error('Non-finite placement triangle');
      const e0=Math.min(...t.map(p=>p[0])),e1=Math.max(...t.map(p=>p[0]));
      const n0=Math.min(...t.map(p=>p[1])),n1=Math.max(...t.map(p=>p[1]));
      for (const d of spans) {
        if (e1<d.e0-EPS || e0>d.e1+EPS || n1<d.n0-EPS || n0>d.n1+EPS) continue;
        if (t.some(p=>covered(p,d.pts)) || d.pts.some(p=>inTriangle(p,...t))
          || t.some((a,j)=>d.pts.some((c,k)=>segments(a,t[(j+1)%3],c,d.pts[(k+1)%d.pts.length])))) return refusal(d);
      }
    }
    return null;
  };
  const assertReason = reason => {
    if (!reason) return;
    const error=Error(reason);error.profilePlacementRefusal=true;throw error;
  };
  const refusedReplacements=new Map();
  return { refusedReplacements, pointsReason, trianglesReason,
    assertPoints(points) { assertReason(pointsReason(points)); },
    assertTriangles(positions) { assertReason(trianglesReason(positions)); },
    refuseReplacement(id,reason) { if (id) refusedReplacements.set(id,reason); },
  };
}

/** Per-object scratch emission: no stream, material/grain state or span/census
 * commit until the complete object passes. Existing flat path calls draw directly. */
export function emitEligiblePlacement(buf, draw, eligibility, id, problems, sharedCaches = []) {
  if (!eligibility) return draw(buf,problems);
  const banned=eligibility.refusedReplacements.get(id);
  if (banned) { problems.push(`yard: ${id}: ${banned}; legacy fallback not drawn`);return false; }
  const lanes=['pos','nrm','conf','col','uv','uv1'];
  const scratch={...buf};
  for (const lane of lanes) scratch[lane]=[];
  // Native toneOf is first-writer-wins at a rounded shade key. A refused
  // object must not seed a later accepted object's material through that cache.
  const cacheKeys=sharedCaches.map(cache=>new Set(cache.keys()));
  const rollbackCaches=()=>sharedCaches.forEach((cache,i)=>{
    for (const key of cache.keys()) if (!cacheKeys[i].has(key)) cache.delete(key);
  });
  const pendingProblems=[];
  let drew,reason;
  try {
    drew=draw(scratch,pendingProblems);
    if (drew) reason=eligibility.trianglesReason(scratch.pos,id);
  } catch (error) { rollbackCaches();throw error; }
  if (!drew) { rollbackCaches();problems.push(...pendingProblems);return false; }
  if (reason) { rollbackCaches();problems.push(`yard: ${id}: ${reason}; whole object not drawn`);return false; }
  // These lanes are append-only in the native yard builders. Other fields are
  // immutable tone/atlas references or assigned scalar/grain state.
  for (const [key,value] of Object.entries(scratch)) {
    if (lanes.includes(key)) { for (const x of value) buf[key].push(x); }
    else buf[key]=value;
  }
  problems.push(...pendingProblems);
  return true;
}
