"""Bounded current contact inventory. Points are not whole-object clearances."""
from pathlib import Path
import hashlib
import json

OUT=Path(__file__).resolve().parent
APP=Path('/workspace/chicago/chicago/4d')
report=json.loads((OUT/'current-path-inventory.json').read_text())
poly=report['profile_polygon_world_EN_m']
def inside(e,n):
    hit=False
    for (x,y),(a,b) in zip(poly,poly[1:]+poly[:1]):
        if (y>n)!=(b>n) and e < (a-x)*(n-y)/(b-y)+x:hit=not hit
    return hit
sources={}
def read(rel):
    data=(APP/rel).read_bytes();sources[rel]=hashlib.sha256(data).hexdigest()
    return json.loads(data)
parked=read('data/transport/parked/placements.json')['scenes']['1835']
horses=read('data/transport/parked/standing-horses.json')['scenes']['1835']
yard=[]
def collect(value,rel):
    if isinstance(value,dict):
        p=value.get('at_local_enu_m')
        if isinstance(p,list) and len(p)==2 and all(type(x)in[int,float]for x in p):
            yard.append({'file':rel,'id':value.get('id'),'point':p})
        for x in value.values():collect(x,rel)
    elif isinstance(value,list):
        for x in value:collect(x,rel)
for p in sorted((APP/'data/yard').glob('*.json')):
    rel=str(p.relative_to(APP));collect(read(rel),rel)
report['parked_1835']={'count':len(parked),'centres_on_profile':[x['id']for x in parked if inside(*x['at_local_enu_m'])]}
report['yard_point_anchors_all_records']={'count':len(yard),'on_profile':[x for x in yard if inside(*x['point'])]}
report['standing_horses_1835']=[{'id':r['id'],'point':r['at_local_enu_m'],'on_profile':inside(*r['at_local_enu_m']),
    'riding':r.get('capabilities',{}).get('riding'),'hitching':r.get('capabilities',{}).get('hitching'),
    'walk_trot_gallop_approved':r.get('capabilities',{}).get('walk_trot_gallop_approved')}for r in horses]
scene=read('data/scenes/1835.json')
report['scene_spawn']=scene['spawn']
report['scene_anchors']=[{'id':r['id'],'point':[r['local_e'],r['local_n']],
    'on_profile':inside(r['local_e'],r['local_n']),'aerial':r.get('aerial',False)}for r in scene['anchors']]
humans=[]
for ident in read('data/humans/instances/1835/index.json')['instances']:
    r=read('data/humans/instances/1835/'+ident+'.json');p=r['placement'];behaviour=r.get('behaviour',{})
    points=[[p['local_e'],p['local_n']]]+[[x['local_e'],x['local_n']]for x in behaviour.get('route',[])]
    intersects=any(inside(*p)for p in points)
    for a,b in zip(points,points[1:]):
        intersects|=any(inside(a[0]+(b[0]-a[0])*i/100,a[1]+(b[1]-a[1])*i/100)for i in range(101))
    humans.append({'id':ident,'state':behaviour.get('state'),'shown':r.get('display'),
        'route_points':points,'spawn_on_profile':inside(*points[0]),'sampled_route_intersects_profile':intersects})
report['current_human_instances']=humans
assert not any(r['on_profile']for r in report['scene_anchors'])
assert not any(r['sampled_route_intersects_profile']for r in humans)
report['source_sha256']=sources
report['full_placement_or_motion_acceptance']=False
report['limitations']='Current point anchors only. Absence of centre hits is not a footprint or wheel/tongue clearance certificate; legacy fallback refusal is concretely incomplete. User camera travel can cross the profile; no moving physical carriage/rider implementation found. No claim about future records.'
(OUT/'current-path-inventory.json').write_text(json.dumps(report,indent=2)+'\n')
print('Inventory:',len(parked),'parked centres,',len(yard),'yard anchors,',len(horses),'standing horses; no point hits. Extent/fallback blocker retained.')
assert not report['parked_1835']['centres_on_profile']
assert not report['yard_point_anchors_all_records']['on_profile']
assert not any(r['on_profile']for r in report['standing_horses_1835'])
