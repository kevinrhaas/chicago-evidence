/** Actual native APIs, actual yard records; pure CPU/Three, no canvas/GL/network. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {createParkedTransport} from './candidate/chicago/4d/renderers/web/js/parked-transport.js';
import {createParkedTransport as oldParked} from './baseline/chicago/4d/renderers/web/js/parked-transport.js';
import {createYardGoods} from './candidate/chicago/4d/renderers/web/js/yard.js';
import {reliefStats} from './cpu-yard-deps.mjs';
import {createYardGoods as oldYard} from './baseline/chicago/4d/renderers/web/js/yard.js';
import {decksFrom} from './candidate/chicago/4d/renderers/web/js/walker.js';
import {createProfilePlacementEligibility,emitEligiblePlacement,insideDeck} from './candidate/chicago/4d/renderers/web/js/deck-surface.js';
const read=rel=>JSON.parse(fs.readFileSync(new URL(rel,import.meta.url),'utf8'));
const f=read('fixture.json'),decks=decksFrom(new Map([['bridge',{id:'bridge',sidecar:f.profile_side}]]));
const e=f.samples[3].world_e,n=f.samples[3].world_n;
const terrain={surfaceHeight:()=>0},elig=()=>createProfilePlacementEligibility(decks);
const lanes=['pos','nrm','conf','col','uv','uv1'];
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
function signature(layer){
 const meshes=[];layer.group.updateMatrixWorld(true);layer.group.traverse(o=>{if(o.isMesh)meshes.push({name:o.name,
  attributes:Object.fromEntries(Object.entries(o.geometry.attributes).map(([k,v])=>[k,{array:Array.from(v.array),itemSize:v.itemSize,normalized:v.normalized}])),
  matrix:o.matrix.elements,material:{name:o.material.name,color:o.material.color?.toArray(),roughness:o.material.roughness,metalness:o.material.metalness},
  userData:o.userData});});
 return hash({meshes,census:layer.census,frontages:layer.frontages,lots:layer.lots,wagons:layer.wagons,benches:layer.benches,sheds:layer.sheds,outbuildings:layer.outbuildings});
}
function assetAt(x=0,z=0,tongue=false){const g=new THREE.Group();const m=new THREE.Mesh(new THREE.BoxGeometry(.1,.1,.1),new THREE.MeshStandardMaterial());m.position.set(x,.1,z);if(tongue)m.name='vehicle_tongue';g.add(m);return {scene:g};}
let responses;
const originalFetch=globalThis.fetch,originalLoad=GLTFLoader.prototype.loadAsync;
globalThis.fetch=async url=>{const key=String(url).replace('file:///fixture/','');assert(key in responses,key);return {ok:true,json:async()=>structuredClone(responses[key])};};
const makeYard=wagons=>({existence:{confidence:'reconstructed'},wagons});
const wagon=(at,id='legacy')=>({id,at_local_enu_m:at,bearing_deg:0,kind:'farm_box',belongs_to:'host'});
const dataBase=new URL('file:///fixture/');
const receipt={status:'PENDING',tests:[]};
try{
 // Crossing / containing / degenerate projected triangles, exact gap negative.
 const p=elig();
 assert(p.trianglesReason([e-100,0,-n-100,e+100,0,-n-100,e,0,-n+100]));
 assert(p.trianglesReason([e-5,0,-n,e+5,0,-n,e+5,3,-n]));
 assert.equal(p.trianglesReason([e+10,0,-n,e+11,0,-n,e+10,0,-n+1]),null);
 // Scratch state rollback, including late rejection and false/throwing builders.
 const cache=new Map([['existing',[1,2,3]]]),cacheBefore=[...cache];
 const original={...Object.fromEntries(lanes.map(k=>[k,[.25]])),tint:[1,2,3],grainOn:false,k:7,ground:99};
 const initial=structuredClone(original),problems=[];
 const draw=b=>{cache.set('rejected shade',[9,9,9]);for(const k of lanes)b[k].push(99);b.pos=[e,0,-n,e+.1,0,-n,e,0,-n+.1];b.tint=[9,9,9];b.ground=-10;b.newProperty='partial';return true;};
 assert.equal(emitEligiblePlacement(original,draw,p,'late-crossing',problems,[cache]),false);assert.deepEqual(original,initial);assert.equal(problems.length,1);assert.deepEqual([...cache],cacheBefore);
 assert.equal(emitEligiblePlacement(original,b=>{b.pos.push(9);b.k=2;cache.set('false shade',1);return false;},p,'false',[],[cache]),false);assert.deepEqual(original,initial);
 assert.throws(()=>emitEligiblePlacement(original,b=>{b.pos.push(9);b.k=2;cache.set('exception shade',1);throw Error('builder failure');},p,'throws',[],[cache]),/builder failure/);assert.deepEqual(original,initial);
 assert.deepEqual([...cache],cacheBefore);
 receipt.tests.push('Triangle edge/containment/vertical controls; no arbitrary exclusion radius; scratch rejection/false/exception leaves streams/state byte exact.');
 // Actual native parked API: refusal persists through initial setFallback,
 // late light->full loading, updates and disposal; fallback must never revive.
 for(const mode of ['wheel','support','tongue','body','support-mesh','light-to-full']){
  const eligibility=elig(),at=[e+1.7,n],row={id:'refined-'+mode,model:'test',name:'fixture',replaces:'legacy',at_local_enu_m:at,bearing_deg:0,source_ids:[]};
  const spec={file:'body.glb',type:'fixture',basis:'CPU fixture',wheel_contacts_m:mode==='wheel'||mode==='light-to-full'?[[1.7,0]]:[[0,0]]};
  if(mode==='support')spec.static_support_contacts_m=[[1.7,0,0]];
  if(mode==='support-mesh')spec.support_file='support.glb';
  responses={'transport/parked/placements.json':{models:{test:spec},scenes:{1835:[row]}},'yard/index.json':{yard:[{id:'fixture',file:'fixture.json'}]},'yard/fixture.json':makeYard([wagon(at)])};
  GLTFLoader.prototype.loadAsync=async url=>mode==='tongue'?assetAt(1.7,0,true):mode==='body'||String(url).endsWith('/support.glb')?assetAt(1.7):assetAt();
  const errors=[],layer=await createParkedTransport({dataBase,sceneId:'1835',terrain,placementEligibility:eligibility,detail:mode==='light-to-full'?'light':'full',problems:errors});
  const fallback=[];layer.setFallback((id,visible)=>fallback.push({id,visible}));
  if(mode==='light-to-full')await layer.setTier('full');
  assert.equal(layer.instances.length,0,mode);assert.equal(layer.group.children.length,0);assert(eligibility.refusedReplacements.has('legacy'),mode);
  assert.match(errors[0],/whole placement and legacy fallback refused/);assert(fallback.length&&fallback.every(x=>!x.visible));
  const yardErrors=[],yard=await createYardGoods({dataBase,terrain,placementEligibility:eligibility,replacementIds:layer.replacementIds,problems:yardErrors});
  assert.equal(yard.wagons.length,0);assert.equal(yard.census.wagons,0);assert.equal(yard.census.objects,0);assert.equal(yard.group.children.length,0);
  assert(yardErrors.some(x=>x.includes('legacy fallback not drawn')));
  layer.update(new THREE.PerspectiveCamera());layer.dispose();assert(fallback.every(x=>!x.visible));yard.dispose();
  receipt.tests.push({native_parked_refusal:mode,instances:0,legacy_wagons:0,legacy_vertices:0,no_uncaught_API_rejection:true,fallback_visibility_calls:fallback});
 }
 // Actual already-emitted safe fallback is hidden on a later light->full
 // refined profile refusal, and the native yard setter cannot revive it.
 {
  const eligibility=elig(),row={id:'late',model:'test',name:'fixture',replaces:'legacy',at_local_enu_m:[e+10,n],bearing_deg:0,source_ids:[]};
  responses={'transport/parked/placements.json':{models:{test:{file:'body.glb',type:'fixture',basis:'CPU fixture',wheel_contacts_m:[[10,0]]}},scenes:{1835:[row]}},'yard/index.json':{yard:[{id:'fixture',file:'fixture.json'}]},'yard/fixture.json':makeYard([wagon([e+10,n])])};
  GLTFLoader.prototype.loadAsync=async()=>assetAt();
  const parked=await createParkedTransport({dataBase,sceneId:'1835',terrain,placementEligibility:eligibility,detail:'light',problems:[]});
  const yard=await createYardGoods({dataBase,terrain,placementEligibility:eligibility,replacementIds:parked.replacementIds,problems:[]});
  assert.equal(yard.wagons.length,1);assert.equal(yard.group.children.length,1);const mesh=yard.group.children[0];assert.equal(mesh.visible,true);
  parked.setFallback((id,visible)=>yard.setReplacementVisible(id,visible));await parked.setTier('full');assert.equal(mesh.visible,false);
  yard.setReplacementVisible('legacy',true);assert.equal(mesh.visible,false);parked.update(new THREE.PerspectiveCamera());parked.dispose();assert.equal(mesh.visible,false);yard.dispose();
  receipt.tests.push('Actual emitted native legacy fallback becomes hidden on late profile rejection; native setter/update/dispose cannot revive it.');
 }
 // Ordinary unrelated asset failure retains its eligible legacy fallback.
 {
  const eligibility=elig(),row={id:'ordinary-failure',model:'test',name:'fixture',replaces:'legacy',at_local_enu_m:[e+10,n],bearing_deg:0,source_ids:[]};
  responses={'transport/parked/placements.json':{models:{test:{file:'missing.glb',type:'fixture',basis:'CPU fixture',wheel_contacts_m:[[0,0]]}},scenes:{1835:[row]}},'yard/index.json':{yard:[{id:'fixture',file:'fixture.json'}]},'yard/fixture.json':makeYard([wagon([e+10,n])])};
  GLTFLoader.prototype.loadAsync=async()=>{throw Error('synthetic ordinary load failure');};const errors=[];
  const parked=await createParkedTransport({dataBase,sceneId:'1835',terrain,placementEligibility:eligibility,problems:errors});
  assert.equal(eligibility.refusedReplacements.size,0);assert.match(errors[0],/existing yard vehicle retained/);
  const yard=await createYardGoods({dataBase,terrain,placementEligibility:eligibility,replacementIds:parked.replacementIds,problems:[]});assert.equal(yard.wagons.length,1);assert.equal(yard.group.children[0].visible,true);parked.dispose();yard.dispose();
  receipt.tests.push('Ordinary non-profile asset failure preserves eligible legacy fallback and records original reason.');
 }
 // Actual yard API independently refuses outside-anchor geometry (no refined model).
 responses={'yard/index.json':{yard:[{id:'fixture',file:'fixture.json'}]},'yard/fixture.json':makeYard([wagon([e+1.7,n])])};
 const reliefBefore={...reliefStats};
 const errors=[],blocked=await createYardGoods({dataBase,terrain,placementEligibility:elig(),problems:errors});
 assert.equal(blocked.wagons.length,0);assert.equal(blocked.census.objects,0);assert.equal(blocked.census.chunks,0);assert.equal(blocked.group.children.length,0);assert(errors.some(x=>x.includes('whole object not drawn')));assert.equal(reliefStats.calls-reliefBefore.calls,1);assert.equal(reliefStats.releases-reliefBefore.releases,1);assert.equal(blocked.census.markCells,0);blocked.dispose();
 receipt.tests.push('Actual yard API refuses outside-anchor overlapping whole wagon, with zero chunks/objects/spans/vertices.');
 // Negative control: native original actually emits that exact counterexample.
 const old=await oldYard({dataBase,terrain,problems:[]});assert.equal(old.wagons.length,1);assert(old.group.children.length);old.dispose();
 // Outside/profile-disabled parity for actual parked API and actual yard API.
 responses={'yard/index.json':{yard:[{id:'fixture',file:'fixture.json'}]},'yard/fixture.json':makeYard([wagon([e+10,n])])};
 const a=await oldYard({dataBase,terrain,problems:[]}),b=await createYardGoods({dataBase,terrain,placementEligibility:elig(),problems:[]});assert.equal(signature(a),signature(b));a.dispose();b.dispose();
 receipt.tests.push('Native original counterexample emits; corrected API refuses; unrelated outside wagon geometry/material/confidence/census/span signature exact.');
 // Rejection before a good object in the same native chunk leaves no stale
 // stream/material/grain state, picking ranges, census or ownership records.
 responses['yard/fixture.json']=makeYard([wagon([e+1.7,n],'bad'),wagon([e+10,n],'safe')]);
 const mixed=await createYardGoods({dataBase,terrain,placementEligibility:elig(),problems:[]});
 responses['yard/fixture.json']=makeYard([wagon([e+10,n],'safe')]);
 const clean=await oldYard({dataBase,terrain,problems:[]});assert.equal(signature(mixed),signature(clean));assert.equal(mixed.census.objects,1);mixed.dispose();clean.dispose();
 for(const enabled of [false,true]){
  responses={'transport/parked/placements.json':{models:{test:{file:'body.glb',type:'fixture',basis:'CPU fixture',wheel_contacts_m:[[0,0]]}},scenes:{1835:[{id:'outside',model:'test',name:'fixture',replaces:'legacy',at_local_enu_m:[e+10,n],bearing_deg:0,source_ids:[]}]}}};
  GLTFLoader.prototype.loadAsync=async()=>assetAt();
  const old=await oldParked({dataBase,sceneId:'1835',terrain,problems:[]});
  const next=await createParkedTransport({dataBase,sceneId:'1835',terrain,placementEligibility:enabled?elig():null,problems:[]});
  assert.equal(old.instances.length,1);assert.equal(signature(next),signature(old));
  assert.deepEqual(next.instances.map(x=>({card:x.card,parking:x.parking,wheel:x.wheel_clearance_m})),old.instances.map(x=>({card:x.card,parking:x.parking,wheel:x.wheel_clearance_m})));
  old.dispose();next.dispose();
 }
 receipt.tests.push('Mixed native chunk after rejected object equals clean original; parked flat-disabled and outside-enabled native API geometry/card/contact parity exact.');
 // Actual native cache and raw-state rollback with separate cold page modules.
 const cacheSnapshots=[];globalThis.__observeYardEmission=({toneCache,chunks})=>cacheSnapshots.push({cache:[...toneCache],raw:hash([...chunks].map(([key,c])=>({key,streams:Object.fromEntries(lanes.map(k=>[k,c.buf[k]])),spans:c.spans})))});
 const cleanModule=await import('./baseline/chicago/4d/renderers/web/js/yard.js?cold-rejection-parity');
 const mixedModule=await import('./candidate/chicago/4d/renderers/web/js/yard.js?cold-rejection-parity');
 responses={'yard/index.json':{yard:[{id:'fixture',file:'fixture.json'}]},'yard/fixture.json':makeYard([wagon([e+10,n],'safe')])};
 const baselineClean=await cleanModule.createYardGoods({dataBase,terrain,problems:[]});
 responses['yard/fixture.json']=makeYard([wagon([e+1.7,n],'bad'),wagon([e+10,n],'safe')]);
 const correctedMixed=await mixedModule.createYardGoods({dataBase,terrain,placementEligibility:elig(),problems:[]});
 assert.deepEqual(cacheSnapshots[0],cacheSnapshots[1]);assert.equal(signature(baselineClean),signature(correctedMixed));baselineClean.dispose();correctedMixed.dispose();delete globalThis.__observeYardEmission;
 receipt.tests.push('Actual cold native tone-cache contents and all six raw streams after refused-before-accepted placement equal clean original; generic refusal/false/exception cache rollback controls pass.');
 // Every actual current yard record through native full CPU API; capture each
 // whole-object raw projected triangle stream before packing. Canvas/relief
 // deliberately unavailable in this Node fixture, identically in both paths.
 const root='/workspace/chicago/chicago/4d/data/';const index=JSON.parse(fs.readFileSync(root+'yard/index.json','utf8'));
 responses={'yard/index.json':index};for(const entry of index.yard)responses['yard/'+entry.file]=JSON.parse(fs.readFileSync(root+'yard/'+entry.file,'utf8'));
 const inventory=[],current=elig(),real=current.trianglesReason;
 current.trianglesReason=(pos,id)=>{const reason=real(pos),xs=[],ns=[];for(let i=0;i<pos.length;i+=3){xs.push(pos[i]);ns.push(-pos[i+2]);}
  inventory.push({id,triangles:pos.length/9,bounds_EN_m:[Math.min(...xs),Math.min(...ns),Math.max(...xs),Math.max(...ns)],intersects_profile:!!reason,raw_positions_sha256:hash(pos)});return reason;};
 const inputHashes=Object.fromEntries(index.yard.map(row=>['yard/'+row.file,crypto.createHash('sha256').update(fs.readFileSync(root+'yard/'+row.file)).digest('hex')]));
 const raw=[],rawSummary=[],diagnostic=[];globalThis.__observeYardEmission=({chunks,woodChunks,out,toneCache})=>{
  const focus=chunks.get('-2,-1');diagnostic.push(focus?{col:[...focus.buf.col],spans:focus.spans,pos:[...focus.buf.pos]}:null);
  rawSummary.push([...chunks,...woodChunks].map(([key,c])=>({key,streams:Object.fromEntries(lanes.map(k=>[k,hash(c.buf[k])])),state:Object.fromEntries(['tint','grainAxis','grainOn','grainOff','ground','pieceOff','k'].filter(k=>Object.hasOwn(c.buf,k)).map(k=>[k,c.buf[k]]))})));
  raw.push(hash([...chunks,...woodChunks].map(([key,c])=>({key,spans:c.spans,lotItemSpans:c.lotItemSpans,
   streams:Object.fromEntries(lanes.map(k=>[k,c.buf[k]])),state:Object.fromEntries(['tint','grainAxis','grainOn','grainOff','ground','pieceOff','k'].filter(k=>Object.hasOwn(c.buf,k)).map(k=>[k,c.buf[k]]))}))));
 };
 const beforeErrors=[],afterErrors=[];
 const coldOld=await import('./baseline/chicago/4d/renderers/web/js/yard.js?cold-current-records');
 const coldNew=await import('./candidate/chicago/4d/renderers/web/js/yard.js?cold-current-records');
 const before=await coldOld.createYardGoods({dataBase,terrain,problems:beforeErrors});
 const after=await coldNew.createYardGoods({dataBase,terrain,placementEligibility:current,problems:afterErrors});
 delete globalThis.__observeYardEmission;assert.equal(raw.length,2);if(raw[0]!==raw[1]){const j=diagnostic[0].col.findIndex((v,i)=>!Object.is(v,diagnostic[1].col[i]));console.log('FIRST RAW COLOUR',JSON.stringify({index:j,before:diagnostic[0].col.slice(j,j+3),after:diagnostic[1].col.slice(j,j+3),pos:diagnostic[0].pos.slice(j,j+3),span:diagnostic[0].spans.filter(s=>j/9>=s.from&&j/9<s.to)}));for(let i=0;i<rawSummary[0].length;i++){if(hash(rawSummary[0][i])!==hash(rawSummary[1][i])){console.log('RAW DIFFERENCE',JSON.stringify({before:rawSummary[0][i],after:rawSummary[1][i]}));break;}}}assert.equal(raw[0],raw[1]);
 assert.deepEqual(afterErrors,beforeErrors);assert.equal(signature(after),signature(before));assert(!inventory.some(x=>x.intersects_profile));
 receipt.current_yard={loaded_record_count:index.yard.length,planned_whole_objects_with_geometry:inventory.length,total_triangles:inventory.reduce((n,x)=>n+x.triangles,0),
  profile_intersections:0,geometry_material_confidence_census_spans_signature_exact:true,all_six_raw_streams_and_final_material_grain_state_exact:true,raw_stream_state_signature:raw[0],
  source_file_sha256:inputHashes,recursive_anchor_count:1418,extra_anchor:'town_water_cart.the_place is a non-emitted geographic annotation;1417 actual native emission objects exhaust the placement loops',signature:signature(after),per_object_streams:inventory,
  scope:'Actual current records and actual native API/builders. Finite flat CPU terrain; native no-DOM unmarked/no-relief fallback; full emitted horizontal triangle extents, not just point anchors. Actual heightfield/canvas/browser/GPU not tested.'};
 for(const [file,expected]of Object.entries(inputHashes))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(root+file)).digest('hex'),expected);
 before.dispose();after.dispose();
 receipt.status='PASS bounded whole-placement controls; production gates and real assets pending';
 receipt.limits=['No real authored GLB loads, actual heightfield, canvas marks/relief, browser/GPU or full native gate.',
 'Only existing rigid parked assets, support meshes, final tongue pose and declared wheel/static contacts qualified by projected triangles/points. Standing horses retain prior point-contact refusal; whole skinned-body envelope remains a separate question.',
 'Shared mark atlas is record-declared before emission, as in native original; unused predeclared cells are not emitted placement bookkeeping. Accepted flat/current geometry and census remain exact.'];
 fs.writeFileSync(new URL('v2-receipt.json',import.meta.url),JSON.stringify(receipt,null,2)+'\n');
 console.log('PASS V2 native whole-placement API; current yard objects',inventory.length,'triangles',receipt.current_yard.total_triangles,'default/output parity exact.');
}finally{delete globalThis.__observeYardEmission;globalThis.fetch=originalFetch;GLTFLoader.prototype.loadAsync=originalLoad;}
