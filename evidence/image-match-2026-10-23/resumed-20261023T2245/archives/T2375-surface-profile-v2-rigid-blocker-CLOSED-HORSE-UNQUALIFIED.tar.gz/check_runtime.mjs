/** Actual copied native modules, pure Node/math fixtures; no browser/GL/network. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from 'three';
import { decksFrom as oldDecks, createWalker as oldWalker } from './baseline/chicago/4d/renderers/web/js/walker.js';
import { decksFrom, createWalker } from './candidate/chicago/4d/renderers/web/js/walker.js';
import { createRouter } from './candidate/chicago/4d/renderers/web/js/route.js';
import { createRouter as oldRouter } from './baseline/chicago/4d/renderers/web/js/route.js';
import { HumanActor } from './candidate/chicago/4d/renderers/web/js/humans.js';
import * as surface from './candidate/chicago/4d/renderers/web/js/deck-surface.js';

const here = new URL('./', import.meta.url);
const read = rel => fs.readFileSync(new URL(rel, here), 'utf8');
const fixture = JSON.parse(read('fixture.json'));
const registry = sides => new Map(sides.map(x => [x.id, x]));
const before = oldDecks(registry(fixture.flat_sides));
const after = decksFrom(registry(fixture.flat_sides));
assert.deepEqual(after, before); // Entire old deck objects, point floats and keys exact.
const terrain = { isWater: () => true, walkHeight: () => 4, surfaceHeight: () => -2 };
assert.equal(surface.refuseProfiledSupportTerrain(terrain, after), terrain);
const constant = () => -2;
assert.equal(surface.refuseProfiledSupportHeight(after, constant), constant);
for (const d of before) {
  const e = d.pts.reduce((s,p) => s+p[0],0)/d.pts.length;
  const n = d.pts.reduce((s,p) => s+p[1],0)/d.pts.length;
  assert.equal(createWalker({ camera:null, terrain, decks:after }).surfaceAt(e,n),
               oldWalker({ camera:null, terrain, decks:before }).surfaceAt(e,n));
  assert.equal(surface.profiledGroundHeight(terrain, after, e,n), -2);
  const xs=d.pts.map(p=>p[0]),ys=d.pts.map(p=>p[1]);
  const t={...terrain,heightfield:{loaded:true,originE:Math.min(...xs)-30,originN:Math.min(...ys)-30,
    widthM:Math.max(...xs)-Math.min(...xs)+60,depthM:Math.max(...ys)-Math.min(...ys)+60}};
  const a=oldRouter({terrain:t,decks:[d],cell:2}), b=createRouter({terrain:t,decks:[d],cell:2});
  assert.equal(a.heightAt(e,n),b.heightAt(e,n));
  const start={e:(d.pts[0][0]+e)/2,n:(d.pts[0][1]+n)/2};
  const end={e:(d.pts[2][0]+e)/2,n:(d.pts[2][1]+n)/2};
  assert.deepEqual(a.plan(start,end),b.plan(start,end));
}
const side = fixture.profile_side;
const profiled = decksFrom(registry([{ id:'dearborn_street_drawbridge', sidecar:side }]));
const deck = profiled[0];
const walker = createWalker({ camera:null, terrain, decks:profiled });
for (const s of fixture.samples) {
  const z = surface.deckHeightAt(deck,s.world_e,s.world_n);
  assert(Math.abs(z-s.actual_generated_board_top_m)<1e-9);
  assert(Math.abs(walker.surfaceAt(s.world_e,s.world_n)-s.actual_generated_board_top_m)<1e-9);
}
const centre = fixture.samples[3];
const e = centre.world_e, n = centre.world_n;
const lowFlat = { ...before.find(x=>x.id===deck.id), y:3.0 };
assert(Math.abs(createWalker({camera:null,terrain,decks:[lowFlat,deck]}).surfaceAt(e,n)-3.42)<1e-9);
assert.equal(createWalker({camera:null,terrain,decks:[deck,{...lowFlat,y:4}]}).surfaceAt(e,n),4);
assert.equal(surface.profiledGroundHeight(terrain,[deck,{...lowFlat,y:4}],e,n),4);
const highLand = { ...terrain,isWater:()=>false,surfaceHeight:()=>5 };
assert.equal(createWalker({camera:null,terrain:highLand,decks:profiled}).surfaceAt(e,n),5);
assert.equal(surface.profiledGroundHeight(terrain,profiled,e+1000,n+1000),-2);

// Real router grid fallback and actual private exact/string-pull function source.
const pts=deck.pts, xs=pts.map(p=>p[0]), ys=pts.map(p=>p[1]);
terrain.heightfield={loaded:true,originE:Math.min(...xs)-30,originN:Math.min(...ys)-30,
  widthM:Math.max(...xs)-Math.min(...xs)+60,depthM:Math.max(...ys)-Math.min(...ys)+60};
const router=createRouter({terrain,decks:profiled,cell:1});
router.warm();
const bounds=router.bounds;
const ce=bounds.e0+(Math.floor((e-bounds.e0))+0.5);
const cn=bounds.n0+(Math.floor((n-bounds.n0))+0.5);
assert(Math.abs(router.heightAt(e,n)-surface.deckHeightAt(deck,ce,cn))<1e-6);
const text=read('candidate/chicago/4d/renderers/web/js/route.js');
const start=text.indexOf('  function exactHeight(e, n) {');
const stop=text.indexOf('\n  // ---------------------------------------------------------------- A*',start);
assert(start>=0&&stop>start);
const exactSource=text.slice(start,stop);
const box={...deck,e0:Math.min(...xs),e1:Math.max(...xs),n0:Math.min(...ys),n1:Math.max(...ys)};
const exact = boxes => Function('grid','inside','deckHeightAt',exactSource+'\nreturn exactHeight;')(
  {deckBoxes:boxes,surf:()=>-2,waterOf:()=>true},surface.insideDeck,surface.deckHeightAt);
for(const s of fixture.samples)assert(Math.abs(exact([box])(s.world_e,s.world_n)-s.actual_generated_board_top_m)<1e-9);
// Mutation control: copying only old scalar/points loses the 1.2m rise.
assert(Math.abs(exact([{...box,profile:undefined}])(e,n)-3.42)>1);
const from=fixture.samples[2],to=fixture.samples[4];
const plan=router.plan({e:from.world_e,n:from.world_n},{e:to.world_e,n:to.world_n});
assert(plan&&plan.points.length>1,'Actual native route must cross the peaked span');
const withWalker=createRouter({terrain,decks:profiled,surfaceAt:(x,y)=>walker.surfaceAt(x,y),cell:1});
assert(withWalker.plan({e:from.world_e,n:from.world_n},{e:to.world_e,n:to.world_n}));

// Exact anchor-report helper, extracted to avoid invoking its whole-scene CLI.
const anchors=read('candidate/chicago/4d/tools/measure_anchors.mjs');
const af=anchors.slice(anchors.indexOf('export function anchorDeckHeight'),anchors.indexOf('\nasync function sceneOutlines'));
const anchorHeight=Function('deckHeightAt',af.replace('export ','')+'\nreturn anchorDeckHeight;')(surface.deckHeightAt);
assert(Math.abs(anchorHeight({deck_surface:deck},e,n)-3.42)<1e-9);
assert.equal(anchorHeight({walk_surface_m:2.22},e,n),2.22);

// Unsupported rigid contacts are refused at the existing actual finite-ground checks.
const unsupported=surface.refuseProfiledSupportTerrain(terrain,profiled);
assert(Number.isNaN(unsupported.surfaceHeight(e,n)));
assert.equal(unsupported.surfaceHeight(e+1000,n+1000),-2);
const yard=fs.readFileSync('/workspace/chicago/chicago/4d/renderers/web/js/yard.js','utf8');
const gf=yard.slice(yard.indexOf('function groundAt('),yard.indexOf('\nfunction buildItem('));
const groundAt=Function(gf+'\nreturn groundAt;')();
assert.equal(groundAt(unsupported,e,n),null); // Actual yard guard: object not drawn.
const parked=fs.readFileSync('/workspace/chicago/chicago/4d/renderers/web/js/parked-transport.js','utf8');
const pf=parked.slice(parked.indexOf('function parkTongue('),parked.indexOf('\nexport async function createParkedTransport'));
const tongue=Function('THREE','yawOf',pf+'\nreturn parkTongue;')(THREE,b=>Math.PI-b*Math.PI/180);
function tinyTongue(){const r=new THREE.Group(),m=new THREE.Mesh(new THREE.BufferGeometry().setAttribute('position',new THREE.Float32BufferAttribute([0,0,0,.1,0,0,0,0,.1],3)));m.name='vehicle_tongue';r.add(m);return r;}
assert.throws(()=>tongue(tinyTongue(),{at_local_enu_m:[e,n],bearing_deg:0},unsupported,3.42),/No terrain under parked tongue/);
assert(tongue(tinyTongue(),{at_local_enu_m:[e+1000,n+1000],bearing_deg:0},unsupported,-2));
const guarded=surface.refuseProfiledSupportHeight(profiled,()=>7);
assert(Number.isNaN(guarded(e,n))); assert.equal(guarded(e+1000,n+1000),7);
assert(parked.includes('heights.every(Number.isFinite)')&&parked.includes('supportGrounds.every(Number.isFinite)'));

// Actual native human root-contact method follows the shared profile provider.
const actor=new HumanActor({instance:{id:'proof',placement:{local_e:e,local_n:n,heading_deg:0},appearance:{asset_id:'unused'}},assets:{},
  heightAt:(x,y)=>surface.profiledGroundHeight(terrain,profiled,x,y)});
assert(Math.abs(actor.root.position.y-3.42)<1e-9);
actor.e=e+1000;actor.n=n+1000;actor.place();assert.equal(actor.root.position.y,-2);

for(const mutate of [p=>p.version=2,p=>p.axis='world_x',p=>p.stations_m[1][0]=0,
  p=>p.stations_m[1][1]=NaN,p=>p.stations_m[0][1]=3,p=>p.stations_m.at(-1)[0]-=1]){
  const s=structuredClone(side);mutate(s.placement.walk_surface_profile);
  assert.throws(()=>surface.deckFromSidecar('bad',s),/Invalid declared/);
}
assert.equal(surface.deckHeightAt(deck,e+1000,n+1000),null);
for (const change of [s=>s.placement.vertical_anchor='terrain',s=>delete s.placement.walk_surface_m,
  s=>s.footprint=null,s=>s.footprint.polygon[0][0]='0']) {
  const s=structuredClone(side);change(s);assert.throws(()=>surface.deckFromSidecar('bad',s),/Invalid declared/);
}
const main=read('candidate/chicago/4d/renderers/web/js/main.js');
for(const code of ['terrain: rigidSupportTerrain','groundHeight: refuseProfiledSupportHeight(decks',
  'groundHeight: (e, n) => profiledGroundHeight(terrain, decks, e, n)'])assert(main.includes(code));
const receipt={status:'PASS pure Node native fixtures',all_six_flat_deck_objects_and_walker_floors_exact:true,
  all_six_flat_router_heights_and_plans_exact:true,
  triangle_backed_profile_samples:fixture.samples.length,router_grid_and_exact_string_pull:true,
  dropped_profile_mutation_detected:true,rotated_frame_and_overlapping_highest_deck:true,land_policy_preserved:true,
  anchor_report_helper_uses_shared_sampler:true,actual_yard_and_tongue_refusals:true,
  actual_human_root_contact_samples_profile:true,invalid_profiles_refused:true,
  no_browser_GL_network_fullgate_or_canonical_write:true,
  limits:'Synthetic contacts/terrain and actual native functions only; no rendered full-body feet, rigid mesh clearance, published app or production bake validation.'};
fs.writeFileSync(new URL('runtime-receipt.json',here),JSON.stringify(receipt,null,2)+'\n');
console.log('PASS: exact flat defaults, seven triangle-backed heights, native walker/router/anchor, support refusals, human root and negative controls.');
