"""V2 additive proposal only. V1 originals remain unchanged."""
from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent
APP=OUT/'candidate/chicago/4d'
assert 'function placementTriangles(' not in (APP/'renderers/web/js/parked-transport.js').read_text(), 'Preserve prepared V2 snapshots'
def edit(rel,old,new):
 p=APP/rel;s=p.read_text();assert s.count(old)==1,(rel,old[:90],s.count(old));p.write_text(s.replace(old,new))
helper=(OUT/'deck-surface.js').read_text()+(OUT/'placement-helper.js').read_text()
for old,new in {'const p = sidecar?.placement ?? {}, h = p.walk_surface_m;': 'const deckPlacement = sidecar?.placement ?? {}, h = deckPlacement.walk_surface_m;', 'p.walk_surface_profile': 'deckPlacement.walk_surface_profile', 'p.vertical_anchor': 'deckPlacement.vertical_anchor', 'p.rotation_deg': 'deckPlacement.rotation_deg', 'p.local_e': 'deckPlacement.local_e', 'p.local_n': 'deckPlacement.local_n'}.items():helper=helper.replace(old,new)
(OUT/'deck-surface.js').write_text(helper)
(APP/'renderers/web/js/deck-surface.js').write_text(helper)
main='renderers/web/js/main.js'
edit(main,'profiledGroundHeight, refuseProfiledSupportTerrain, refuseProfiledSupportHeight }','profiledGroundHeight, refuseProfiledSupportTerrain, refuseProfiledSupportHeight, createProfilePlacementEligibility }')
edit(main,'  const rigidSupportTerrain = refuseProfiledSupportTerrain(terrain, decks);','  const rigidSupportTerrain = refuseProfiledSupportTerrain(terrain, decks);\n  const placementEligibility = createProfilePlacementEligibility(decks);')
edit(main,"sceneId: YEAR, terrain: rigidSupportTerrain, confidence,", "sceneId: YEAR, terrain: rigidSupportTerrain, confidence, placementEligibility,")
edit(main,"dataBase: layerBase('yard_goods'), terrain: rigidSupportTerrain, confidence,", "dataBase: layerBase('yard_goods'), terrain, placementEligibility, confidence,")
park='renderers/web/js/parked-transport.js'
# Native object transforms match staticBatches and final model placement exactly.
p=APP/park;s=p.read_text();i=s.index('/** Solve the lowest actual tongue')
s=s[:i]+'''/** Project every actual rigid mesh triangle after authored transforms and pose.
 * The same indices used by staticBatches are included, including support meshes. */
function placementTriangles(root, row) {
  root.updateMatrixWorld(true);
  const out=[], p=new THREE.Vector3();
  const yaw=yawOf(row.bearing_deg),c=Math.cos(yaw),s=Math.sin(yaw);
  root.traverse(node=>{
    if (!node.isMesh) return;
    const pos=node.geometry.getAttribute('position'),index=node.geometry.index;
    const count=index?index.count:pos.count;
    for(let i=0;i<count;i++) {
      p.fromBufferAttribute(pos,index?index.getX(i):i).applyMatrix4(node.matrixWorld);
      out.push(row.at_local_enu_m[0]+c*p.x+s*p.z,p.y,
        -row.at_local_enu_m[1]-s*p.x+c*p.z);
    }
  });
  return out;
}

'''+s[i:];p.write_text(s)
edit(park,'function parkTongue(root, row, terrain, base) {','function parkTongue(root, row, terrain, base, placementEligibility = null) {')
edit(park,'        const ground = terrain.surfaceHeight(e, n);','        placementEligibility?.assertPoints([[e,n]]);\n        const ground = terrain.surfaceHeight(e, n);')
edit(park,"  getDrawingBufferHeight = () => null } = {}) {", "  getDrawingBufferHeight = () => null, placementEligibility = null } = {}) {")
edit(park,'    setFallback(callback) { fallback = callback; },','''    setFallback(callback) {
      fallback = placementEligibility ? (id,visible) => callback(id,
        visible && !placementEligibility.refusedReplacements.has(id)) : callback;
      for (const id of placementEligibility?.refusedReplacements.keys() ?? []) fallback(id,false);
    },''')
edit(park,"        try {\n          let pending = assets.get(row.model);", """        try {
          if (placementEligibility) {
            const yaw0=yawOf(row.bearing_deg),c0=Math.cos(yaw0),s0=Math.sin(yaw0);
            const point=([x,,z])=>[row.at_local_enu_m[0]+c0*x+s0*z,row.at_local_enu_m[1]+s0*x-c0*z];
            placementEligibility.assertPoints([
              ...spec.wheel_contacts_m.map(([x,z])=>point([x,0,z])),
              ...(spec.static_support_contacts_m ?? []).map(point),
            ]);
          }
          let pending = assets.get(row.model);""")
edit(park,'          const parking = parkTongue(root, row, terrain, base);','''          const parking = parkTongue(root, row, terrain, base, placementEligibility);
          if (placementEligibility) placementEligibility.assertTriangles(placementTriangles(root,row));''')
edit(park,'          const near = staticBatches(root, confidence);','''          if (placementEligibility && midAsset) placementEligibility.assertTriangles(placementTriangles(midAsset.scene,row));
          const near = staticBatches(root, confidence);''')
edit(park,"        } catch (error) { problems.push(`parked transport ${row.id}: ${error.message}; ${row.replaces ? 'existing yard vehicle retained' : 'vehicle not shown'}`); }", """        } catch (error) {
          if (error.profilePlacementRefusal && placementEligibility) {
            placementEligibility.refuseReplacement(row.replaces,error.message);
            if (row.replaces) fallback(row.replaces,false);
            problems.push(`parked transport ${row.id}: ${error.message}; whole placement and legacy fallback refused`);
          } else problems.push(`parked transport ${row.id}: ${error.message}; ${row.replaces ? 'existing yard vehicle retained' : 'vehicle not shown'}`);
        }""")
yard='renderers/web/js/yard.js'
edit(yard,"import * as THREE from 'three';", "import * as THREE from 'three';\nimport { emitEligiblePlacement } from './deck-surface.js';")
edit(yard,'  replacementIds = new Set(),','  replacementIds = new Set(),\n  placementEligibility = null,')
edit(yard,'  const emit = (chunk, id, draw) => {\n    const from = chunk.buf.pos.length / 9;\n    const drew = draw(chunk.buf);','''  const emit = (chunk, id, draw, placementId = id) => {
    const from = chunk.buf.pos.length / 9;
    const drew = emitEligiblePlacement(chunk.buf,draw,placementEligibility,placementId,problems,[toneCache]);''')
edit(yard,'''        if (!buildItem(chunk.buf, item, form, terrain,
          LEVEL[frontage.confidence] ?? level, problems, frontage.structure_id,
          markRect)) continue;''','''        if (!emitEligiblePlacement(chunk.buf,(b,p)=>buildItem(b,item,form,terrain,
          LEVEL[frontage.confidence] ?? level,p,frontage.structure_id,markRect),
          placementEligibility,item.id ?? `${frontage.structure_id} ${item.kind}`,problems,[toneCache])) continue;''')
edit(yard,'''        if (!draw(chunk.buf, item, form, terrain,
          LEVEL[lot.confidence] ?? level, problems, lot.structure_id)) continue;''','''        if (!emitEligiblePlacement(chunk.buf,(b,p)=>draw(b,item,form,terrain,
          LEVEL[lot.confidence] ?? level,p,lot.structure_id),
          placementEligibility,item.id ?? `${lot.structure_id} ${item.kind}`,problems,[toneCache])) continue;''')
edit(yard,'''        (b) => build(b, wagon, form, terrain, LEVEL[wagon.confidence] ?? level,
          problems))) continue;''','''        (b,p) => build(b,wagon,form,terrain,LEVEL[wagon.confidence] ?? level,p),wagon.id)) continue;''')
edit(yard,'''        (b) => buildItem(b, bench, form, terrain, LEVEL[bench.confidence] ?? level,
          problems, bench.belongs_to ?? bench.id))) continue;''','''        (b,p) => buildItem(b,bench,form,terrain,LEVEL[bench.confidence] ?? level,
          p,bench.belongs_to ?? bench.id),bench.id)) continue;''')
edit(yard,'''        (b) => buildShed(b, shed, form, terrain, LEVEL[shed.confidence] ?? level,
          problems))) continue;''','''        (b,p) => buildShed(b,shed,form,terrain,LEVEL[shed.confidence] ?? level,p),shed.id)) continue;''')
edit(yard,'''        (b) => buildOutbuilding(b, ob, terrain, LEVEL[ob.confidence] ?? level,
          problems))) continue;''','''        (b,p) => buildOutbuilding(b,ob,terrain,LEVEL[ob.confidence] ?? level,p),ob.id)) continue;''')
print('Prepared V2 whole-placement eligibility, scratch yard emission and persistent profiled fallback refusal; no canonical writes.')

edit(yard,'    if (mesh) mesh.visible = visible;','    if (mesh) mesh.visible = placementEligibility?.refusedReplacements.has(id) ? false : visible;')

edit(yard,'  if (!built.length && !woodBuilt.length) {\n    if (out.census.records) {','  if (!built.length && !woodBuilt.length) {\n    if (placementEligibility) {\n      // Whole-placement refusal may leave no object using the predeclared atlas\n      // or the shared relief hold. Release these layer resources as well.\n      atlas?.texture?.dispose();\n      (await reliefP).dispose?.();\n      out.census.markCells = 0;\n    }\n    if (out.census.records) {')

(APP/'docs/GLB-CONTRACT.md').write_bytes((OUT/'baseline/chicago/4d/docs/GLB-CONTRACT.md').read_bytes()+(OUT/'CONTRACT-APPEND.md').read_bytes())
