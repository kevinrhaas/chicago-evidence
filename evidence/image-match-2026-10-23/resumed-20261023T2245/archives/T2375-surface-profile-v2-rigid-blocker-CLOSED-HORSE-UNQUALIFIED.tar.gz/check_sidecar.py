"""Unchanged native sidecar gate over every actual renderer with candidate overlay."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,sys,tempfile
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;APP=Path('/workspace/chicago/chicago/4d')
sys.path[:0]=[str(APP/'tools'),str(APP/'generators')]
spec=importlib.util.spec_from_file_location('native_validate_bridge',APP/'tools/validate.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_hash=sha(APP/'tools/validate.py')
with tempfile.TemporaryDirectory(prefix='t2375-sidecar-',dir='/tmp') as tmp:
 root=Path(tmp)
 js=[p for p in (APP/'renderers').rglob('*.js')if'vendor'not in p.parts]
 source_paths=set(js)
 digest=lambda paths:hashlib.sha256(json.dumps(sorted((str(p.relative_to(APP)),sha(p))for p in paths),separators=(',',':')).encode()).hexdigest()
 renderer_before=digest(source_paths)
 for p in js:
  rel=p.relative_to(APP);candidate=OUT/'candidate/chicago/4d'/rel;dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True)
  if candidate.is_file():shutil.copy2(candidate,dest)
  else:dest.symlink_to(p)
 helper=root/'renderers/web/js/deck-surface.js';helper.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(OUT/'candidate/chicago/4d/renderers/web/js/deck-surface.js',helper)
 listed=[]
 for index in sorted((APP/'data/sidecars').glob('*/index.json')):
  source_paths.add(index)
  rows=list(json.loads(index.read_text()).get('structures',[]))
  versions=index.parent/'versions/index.json'
  if versions.is_file():source_paths.add(versions)
  if versions.is_file():rows += [entry for entries in json.loads(versions.read_text()).get('structures',{}).values()for entry in entries]
  for row in rows:
   path=APP/'data'/row.get('sidecar','')
   if path.is_file():listed.append({'sidecar':str(path)});source_paths.add(path)
 candidate_sidecar=json.loads((OUT/'fixture.json').read_text())['profile_side']
 target=root/'data/candidate-sidecar.json';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(candidate_sidecar))
 listed.append({'sidecar':str(target)})
 index=root/'data/sidecars/cpu/index.json';index.parent.mkdir(parents=True);index.write_text(json.dumps({'structures':listed}))
 all_inputs_before=digest(source_paths)
 v.ROOT=root;v.DATA=root/'data'
 rep=v.Report();v.check_sidecar_contract(rep)
 result={'status':'PASS'if not rep.errors else'FAIL','validator_sha256':source_hash,'renderer_source_aggregate_sha256':renderer_before,'renderer_and_actual_sidecar_input_aggregate_sha256':all_inputs_before,'renderer_files':len(js)+1,'listed_actual_sidecar_entries':len(listed)-1,
  'candidate_profile_from_actual_compiler_placement':candidate_sidecar['placement']['walk_surface_profile'],'errors':rep.errors,'notes':rep.notes,
  'method':'Every current non-vendor renderer, candidate overrides, original actual listed committed sidecars plus candidate sidecar whose placement is emitted by real candidate compiler AST. No invented fields and no scanner changes.'}
 # Missing actual emitted profile must stay red when its nested fields are read.
 missing=json.loads(json.dumps(candidate_sidecar));del missing['placement']['walk_surface_profile'];target.write_text(json.dumps(missing))
 negative=v.Report();v.check_sidecar_contract(negative)
 result['missing_profile_negative_errors']=negative.errors
 # Scanner's native malformed binding must also remain visibly rejected.
 typo=root/'renderers/web/js/negative-probe.js';typo.write_text('export const unsupported = sidecar.placement.bridge_field_never_emitted;\n')
 malformed=v.Report();v.check_sidecar_contract(malformed);result['nonexistent_field_negative_errors']=malformed.errors
 assert negative.errors,'Missing profile was silently accepted'
 assert any('bridge_field_never_emitted'in e for e in malformed.errors)
 assert sha(APP/'tools/validate.py')==source_hash
 assert digest(source_paths)==all_inputs_before,'Native scanner inputs moved during proof'
 (OUT/'sidecar-contract-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
 if rep.errors:
  print('\n'.join(rep.errors));raise SystemExit(1)
 print('PASS unchanged native full-renderer sidecar contract; missing-profile/nonexistent-field negatives remain red.')
