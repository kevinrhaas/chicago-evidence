import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
const root = 'file:///workspace/chicago/chicago/4d/';
const own = new URL('./', import.meta.url).href;
export function resolve(specifier, context, nextResolve) {
  if (context.parentURL && new URL(context.parentURL).pathname.endsWith('/renderers/web/js/yard.js') && ['./frontage.js','./scene-loader.js'].includes(specifier)) return {url:own+'cpu-yard-deps.mjs',shortCircuit:true};
  if (specifier === 'three') return { url: root + 'renderers/web/vendor/three-0.185.1/three.module.js', shortCircuit: true };
  if (specifier.startsWith('three/addons/')) return { url: root + 'renderers/web/vendor/three-0.185.1/addons/' + specifier.slice(13), shortCircuit: true };
  if (specifier.startsWith('.') && context.parentURL?.startsWith(own)) {
    const url = new URL(specifier, context.parentURL);
    if (url.protocol === 'file:' && !fs.existsSync(fileURLToPath(url))) {
      for (const area of ['candidate/chicago/4d/', 'baseline/chicago/4d/']) {
        const prefix = own + area;
        if (url.href.startsWith(prefix)) return { url: root + url.href.slice(prefix.length), shortCircuit: true };
      }
    }
  }
  return nextResolve(specifier, context);
}

// Test-only observational hook before native packing: reads raw streams/state;
// it changes no builder, loop, return value or public API.
export async function load(url,context,nextLoad) {
  const result=await nextLoad(url,context);
  if (url.startsWith(own)&&new URL(url).pathname.endsWith('/renderers/web/js/yard.js')) {
    const text=typeof result.source==='string'?result.source:new TextDecoder().decode(result.source);
    const marker='  const built = [...chunks.values()].filter((c) => c.buf.pos.length);';
    if (!text.includes(marker)) throw Error('Native yard observation preimage changed');
    return {...result,source:text.replace(marker,'  globalThis.__observeYardEmission?.({chunks,woodChunks,out,toneCache});\n'+marker)};
  }
  return result;
}
