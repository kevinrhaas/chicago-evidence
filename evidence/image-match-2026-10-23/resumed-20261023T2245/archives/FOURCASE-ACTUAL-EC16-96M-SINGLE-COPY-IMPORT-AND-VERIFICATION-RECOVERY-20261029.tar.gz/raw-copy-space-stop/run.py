from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,signal,zlib,importlib.util,datetime,base64
from urllib.request import Request,urlopen
os.sched_setaffinity(0,{1});os.nice(10)
O=Path(__file__).parent;P=Path('/workspace/early-four-current-dev-ec16-price-publisher-v4-20261029');PAY=O/'encoded-payload';PAY.mkdir(exist_ok=False)
C=Path('/workspace/chicago');R=Path('/tmp/chicago-current-objects-20261025');OLD='be501b034cd24410843eedced9e1bf1b52a4ff4f';TIP='ec16b8dd726fa7852ede885ef2d754d55b9b4c59';HEAD='24e4c333ab94864208141bb85234e33dadde841a';CAP=96*1024**2;FLOOR=512*1024**2;HEADROOM=16*1024**2
assert os.environ.get('APPROVED_EC16_EXACT_96M_IMPORT')=='root-85174449-60blobs-plus-boundedmetadata'
sp=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(root,*a,input=None):return subprocess.check_output(['git','-C',str(root),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*a],env=env,input=input)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
price=json.loads((P/'RESULT.json').read_text());tree=json.loads((P/'REMOTE-TREE.json').read_text());missing=json.loads((P/'MISSING-BLOBS.json').read_text());compare=json.loads((P/'COMPARE.json').read_text());assert price['tip']==TIP and price['missing_blob_count']==60 and price['missing_raw_bytes']==85174449 and tree['sha']==price['tree']=='247ea33b100431aa35c72acb07a43e6db164ba89'
before=m.snapshot();save('SOURCE-BEFORE.json',before);assert before['HEAD']==HEAD and not before['status']and not(m.G/'MERGE_HEAD').exists();assert m.git('rev-parse','origin/dev').decode().strip()==OLD;assert m.api('git/ref/heads/dev')['object']['sha']==TIP
# Conservative futurecheckoutprice, using only cleanleased workingfile sizes and immutable incomingtip sizes.
by_path={r['path']:r for r in tree['tree']if r['type']!='tree'};workrows=[]
for r in compare['files']:
 p=r['filename'];new=by_path.get(p);old=C/p;oldsize=old.stat().st_size if old.is_file()else 0;newsize=0 if new is None else new['size'];workrows.append({'path':p,'old_working_bytes':oldsize,'new_tip_bytes':newsize,'net':newsize-oldsize})
save('CHECKOUT-PRICE.json',{'net_bytes':sum(r['net']for r in workrows),'positive_delta_upper':sum(max(0,r['net'])for r in workrows),'largest_atomic_new_file':max(r['new_tip_bytes']for r in workrows),'rows':workrows,'qualification':'Conservativeincomingbase→tippaths only; mergepreservesownfourpaths andmayderiveadditionalmetadata. No checkoutperformedhere.'})
old_isolated=sum(p.stat().st_size for p in(R/'objects').rglob('*')if p.is_file())
with(O/'ISOLATED-METADATA-FETCH.log').open('xb')as f:
 proc=subprocess.Popen(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',TIP],env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);peak=old_isolated;abort=None
 while proc.poll()is None:
  total=sum(p.stat().st_size for p in(R/'objects').rglob('*')if p.is_file());peak=max(peak,total)
  if total-old_isolated>8*1024**2 or b'filtering not recognized'in(O/'ISOLATED-METADATA-FETCH.log').read_bytes().lower():abort='Isolatedmetadata8MiBdelta/filterguard';os.killpg(proc.pid,signal.SIGTERM);proc.wait();break
  time.sleep(.15)
 rc=proc.wait()
save('ISOLATED-METADATA-FETCH.json',{'exit':rc,'before':old_isolated,'peak':peak,'new_delta_cap':8*1024**2,'abort':abort});assert rc==0 and abort is None
actual={}
for row in git(R,'ls-tree','-r','-z',TIP).split(b'\0'):
 if row:
  a,n=row.split(b'\t');mode,kind,s=a.decode().split();actual[n.decode()]=(mode,kind,s)
assert actual=={r['path']:(r['mode'],r['type'],r['sha'])for r in tree['tree']if r['type']!='tree'}
allmeta=set()
for idx in(R/'objects/pack').glob('*.idx'):
 for l in git(R,'show-index',input=idx.read_bytes()).decode().splitlines():allmeta.add(l.split()[1])
for folder in(R/'objects').iterdir():
 if folder.is_dir()and len(folder.name)==2:
  for p in folder.iterdir():
   if p.is_file()and len(p.name)==38:allmeta.add(folder.name+p.name)
unknown=allmeta-m.indexed(allmeta);meta=[]
if unknown:
 for line in git(R,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(sorted(unknown))+'\n').encode()).decode().splitlines():
  s,kind,size=line.split();assert kind in {'commit','tree','tag'};meta.append({'sha':s,'kind':kind,'bytes':int(size)})
rows=[];allocated=0;raw_total=0

def store(s,kind,data,path):
 global allocated,raw_total
 raw=kind.encode()+b' '+str(len(data)).encode()+b'\0'+data;assert hashlib.sha1(raw).hexdigest()==s;raw_total+=len(data);assert raw_total<=CAP
 enc=zlib.compress(raw);n=((len(enc)+4095)//4096)*4096;assert shutil.disk_usage('/workspace').free>=FLOOR+HEADROOM+allocated+2*n
 p=PAY/s;assert not p.exists();p.write_bytes(enc);a=p.stat().st_blocks*512;allocated+=a;assert shutil.disk_usage('/workspace').free>=FLOOR+HEADROOM+allocated
 rows.append({'sha':s,'kind':kind,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoded_bytes':len(enc),'allocated':a,'payload':str(p),'path':path})
for r in meta:
 data=git(R,'cat-file',r['kind'],r['sha']);assert len(data)==r['bytes'];store(r['sha'],r['kind'],data,'isolatedcanonicalmetadata')
for r in missing:
 with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+TIP+'/'+r['path'],headers={'User-Agent':'Chicago-root-exact96MiB-upstream-import'}),timeout=120)as response:assert response.status==200;data=response.read(r['size']+1)
 assert len(data)==r['size'];store(r['sha'],'blob',data,r['path'])
# Tiny genuinefeaturechangelogblobs are absentfromfoldedtip butnativehistorychecks mayreadthem.
for s in ['de3a91236e8ec3c66eca092cb11088db1de46b3d','e413137835c9bdc2d833979bcc5609f79ebcc90b']:
 feature=m.api('commits/'+s);save('FEATURE-'+s+'.json',feature)
 for r in feature['files']:
  if r['filename'].startswith('chicago/4d/changelog.d/')and r['status']=='added'and r['sha']not in m.indexed([r['sha']])and r['sha']not in{x['sha']for x in rows}:
   ob=m.api('git/blobs/'+r['sha']);data=base64.b64decode(ob['content']);assert len(data)==ob['size']<4096;store(r['sha'],'blob',data,r['filename'])
save('ENCODED-IMPORT-PLAN.json',{'status':'EXACT_ALL_CANONICAL_OBJECTS_COMPRESSED_VERIFIED_PRICED_BEFORE_PRIMARY_IMPORT','old':OLD,'tip':TIP,'tree':price['tree'],'raw_total':raw_total,'raw_cap':CAP,'objects':len(rows),'encoded_allocated_payload':allocated,'predicted_primary_copy_allocated':allocated,'workspace_free_after_payload':shutil.disk_usage('/workspace').free,'workspace_floor':FLOOR,'extra_working_headroom':HEADROOM,'rows':rows});assert m.snapshot()==before
assert shutil.disk_usage('/workspace').free>=FLOOR+HEADROOM+allocated;assert m.api('git/ref/heads/dev')['object']['sha']==TIP
imported=[]
for r in rows:
 assert r['sha']not in m.indexed([r['sha']]);enc=Path(r['payload']).read_bytes();raw=zlib.decompress(enc);header,data=raw.split(b'\0',1);assert header==r['kind'].encode()+b' '+str(len(data)).encode()and len(data)==r['bytes']and hashlib.sha1(raw).hexdigest()==r['sha']and hashlib.sha256(data).hexdigest()==r['sha256'];d=m.G/'objects'/r['sha'][:2]/r['sha'][2:];assert not d.exists();d.parent.mkdir(exist_ok=True);tmp=d.with_name(d.name+'.exact-ec16-'+str(os.getpid()));tmp.write_bytes(enc);assert tmp.read_bytes()==enc;tmp.rename(d);assert shutil.disk_usage('/workspace').free>=FLOOR+HEADROOM;imported.append({'sha':r['sha'],'allocated':d.stat().st_blocks*512})
save('IMPORTED-OBJECTS.json',imported)
leaves=[r for r in tree['tree']if r['type']!='tree'];ids={r['sha']for r in leaves};assert ids<=m.indexed(ids);blobids=sorted({r['sha']for r in leaves if r['type']=='blob'});lines=m.git('cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(blobids)+'\n').encode()).decode().splitlines();assert not any(x.endswith(' missing')for x in lines);sizes={x.split()[0]:int(x.split()[2])for x in lines};assert all(sizes[r['sha']]==r['size']for r in leaves if r['type']=='blob');assert m.git('rev-parse',TIP+'^{tree}').decode().strip()==price['tree']and m.git('merge-base',OLD,TIP).decode().strip()==OLD
assert m.snapshot()==before;fresh=m.api('git/ref/heads/dev')['object']['sha'];assert fresh==TIP;m.git('update-ref','refs/remotes/origin/dev',TIP,OLD);after=m.snapshot();save('SOURCE-AFTER.json',after)
assert after['HEAD']==before['HEAD']and after['metadata']==before['metadata']and after['status']==before['status']and after['refs']==[x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+TIP)for x in before['refs']]
# RootallowsretiringONLYtheseverifiedduplicatedownloadpayloads torestoreownerworkingheadroom.
retired=[]
for r in rows:
 p=Path(r['payload']);d=m.G/'objects'/r['sha'][:2]/r['sha'][2:];assert p.read_bytes()==d.read_bytes();retired.append({'sha':r['sha'],'payload':str(p),'allocated':p.stat().st_blocks*512,'preserved_primary_object':str(d),'bytes_verified_equal':True});p.unlink()
save('VERIFIED-DUPLICATE-PAYLOAD-RETIREMENT.json',retired)
save('RESULT.json',{'status':'EXACT_EC16_ROOT96MiB_PRICED_IMPORT_ALL_TIP_IDS_SIZES_SOURCE_GUARDS_AND_FRESH_BE501_CAS_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old':OLD,'tip':TIP,'tree':price['tree'],'source_head':HEAD,'objects':len(rows),'canonical_new_raw_bytes':raw_total,'cap':CAP,'actual_primary_allocated_bytes':sum(r['allocated']for r in imported),'all_tip_leaves':len(leaves),'all_tip_unique_blob_IDs_and_sizes_verified':len(blobids),'all60newtip_blobs_fullSHA1_SHA256_and_modes_verified':True,'HEAD_index_config_working_status_unchanged':True,'all_other_refs_unchanged':True,'cached_origin_dev_exact_fresh_cas':TIP,'workspace_free':shutil.disk_usage('/workspace').free,'workspace_floor':FLOOR,'tmp_free':shutil.disk_usage('/tmp').free,'verified_download_duplicate_retired_count':len(retired),'qualification':'Availabilityonly; nativeSOURCEmerge/chronologicaldocunion/204+tail/fullcheck/currentphone/commit/PRheadCI stillfinisherresponsibility. No stagedsource/headcheck qualification relabeled.'});print((O/'RESULT.json').read_text())
