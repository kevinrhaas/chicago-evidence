from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,stat,subprocess,zlib
R=Path('/workspace/chicago-private-publisher-20261024');G=R/'.git';D=G/'objects/pack';W=Path('/tmp/chicago-resumed-evidence-20261023T2245');OUT=Path('/workspace/chicago-publisher-object-preserving-maintenance-20261024');OUT.mkdir(exist_ok=False)
ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_NO_LAZY_FETCH':'1'};KEEP='pack-9b63f1d6c94fa84fabfcecfc03ec14623c69e817'
def run(*args,input=None):return subprocess.check_output(['git',*args],cwd=R,env=ENV,input=input)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def write(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
def snapshot():
 return {'HEAD':run('rev-parse','HEAD').decode().strip(),'refs':run('show-ref').decode(),'index_sha256':sha(G/'index'),'stage_entries_sha256':hashlib.sha256(run('ls-files','--stage')).hexdigest(),'status':run('status','--porcelain').decode(),'sparse_sha256':sha(G/'info/sparse-checkout'),'config_sha256':sha(G/'config'),'free_workspace':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize}
def indexed():
 ret={}
 for idx in sorted(D.glob('*.idx')):
  with idx.open('rb') as f:text=subprocess.check_output(['git','show-index'],stdin=f,env=ENV).decode()
  ret[idx.stem]={line.split()[1] for line in text.splitlines()}
 return ret
def loose():
 ret={}
 for p in (G/'objects').iterdir():
  if p.is_dir() and len(p.name)==2 and all(c in '0123456789abcdef' for c in p.name):
   for q in p.iterdir():
    if q.is_file() and len(q.name)==38 and all(c in '0123456789abcdef' for c in q.name):ret[p.name+q.name]=q
 return ret
def read_all(oids):
 proc=subprocess.Popen(['git','cat-file','--batch'],cwd=R,env=ENV,stdin=subprocess.PIPE,stdout=subprocess.PIPE);ret=[]
 try:
  for oid in sorted(oids):
   proc.stdin.write((oid+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().strip().split();assert len(header)==3 and header[0]==oid
   typ=header[1];size=int(header[2]);data=proc.stdout.read(size);assert len(data)==size and proc.stdout.read(1)==b'\n';encoded=(typ+' '+str(size)+'\0').encode()+data;assert hashlib.sha1(encoded).hexdigest()==oid
   ret.append({'oid':oid,'type':typ,'bytes':size,'content_sha256':hashlib.sha256(data).hexdigest()})
 finally:
  proc.stdin.close();assert proc.wait()==0
 return ret
before=snapshot();assert before['status']=='';packs=indexed();lp=loose();union=set().union(*packs.values())|set(lp);assert len(union)==2706 and len(packs)==29 and len(lp)==1812;assert len(packs[KEEP])==937;other=union-packs[KEEP];assert len(other)==1769
oldpackfiles=[p for p in D.iterdir() if p.name.startswith('pack-') and p.stem in packs and p.stem!=KEEP];assert len(oldpackfiles)==112 and all(p.suffix in ['.pack','.idx','.rev','.promisor'] for p in oldpackfiles)
keepfiles=[p for p in D.iterdir() if p.stem==KEEP];keepmeta=[{'path':str(p),'bytes':p.stat().st_size,'mode':oct(stat.S_IMODE(p.stat().st_mode)),'sha256':sha(p)} for p in keepfiles]
oldmeta=[{'path':str(p),'bytes':p.stat().st_size,'mode':oct(stat.S_IMODE(p.stat().st_mode)),'sha256':sha(p)} for p in oldpackfiles]
loosemeta=[]
for oid,p in sorted(lp.items()):
 raw=p.read_bytes();decoded=zlib.decompress(raw);assert hashlib.sha1(decoded).hexdigest()==oid;loosemeta.append({'oid':oid,'path':str(p),'bytes':len(raw),'mode':oct(stat.S_IMODE(p.stat().st_mode)),'sha256':hashlib.sha256(raw).hexdigest()})
# Materialized current archive cache bytes are preserved exactly; omitted blobs are represented in full object inventory.
archives=[]
for p in sorted((R/'evidence/image-match-2026-10-23/resumed-20261023T2245/archives').glob('*.tar.gz')):archives.append({'path':str(p),'bytes':p.stat().st_size,'mode':oct(stat.S_IMODE(p.stat().st_mode)),'sha256':sha(p)})
write('BEFORE.json',before);write('KEEPER-PACKS.json',keepmeta);write('OLD-PACK-FILES.json',oldmeta);write('LOOSE-FILES.json',loosemeta);write('MATERIALIZED-ARCHIVES.json',archives);write('ALL-OBJECTS-BEFORE.json',read_all(union));write('OBJECT-SETS.json',{'all':sorted(union),'keeper':sorted(packs[KEEP]),'standalone':sorted(other)})
with (OUT/'keeper-verify-before.log').open('wb') as f:subprocess.run(['git','verify-pack','-v',str(D/(KEEP+'.idx'))],cwd=R,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
print(json.dumps({'phase':'BEFORE_ALL_TYPED_HASHES_AND_KEEPER_VERIFY_PASS','objects':len(union),'other_unique':len(other),'other_uncompressed_bytes':29046117}),flush=True)
# New pack uses no object deltas and preserves every unique historical object, without reachability selection.
prefix=D/'object-preserving-20261024';out=run('pack-objects','--window=0','--depth=0','--compression=1',str(prefix),input=('\n'.join(sorted(other))+'\n').encode());packhash=out.decode().strip();assert len(packhash)==40
created_pack=D/(prefix.name+'-'+packhash+'.pack');created_idx=created_pack.with_suffix('.idx');assert created_pack.is_file() and created_idx.is_file()
# Install through normal pack-* filenames without altering refs/index/config.
newpack=D/('pack-'+packhash+'.pack');newidx=newpack.with_suffix('.idx');assert not newpack.exists() and not newidx.exists();os.rename(created_pack,newpack);os.rename(created_idx,newidx)
# It contains objects from promisor and local histories; keep partial-clone provenance metadata.
newprom=newpack.with_suffix('.promisor');newprom.write_bytes(b'')
with (OUT/'standalone-verify.log').open('wb') as f:subprocess.run(['git','verify-pack','-v',str(newidx)],cwd=R,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
with newidx.open('rb') as f:rows=subprocess.check_output(['git','show-index'],stdin=f,env=ENV).decode().splitlines()
assert {row.split()[1] for row in rows}==other
# Every object is fully re-read before any old representation is removed.
assert read_all(union)==json.loads((OUT/'ALL-OBJECTS-BEFORE.json').read_text())
mid=snapshot();assert all(mid[k]==before[k] for k in before if k!='free_workspace')
write('PRE-REMOVAL-PROOF.json',{'status':'ALL2706_TYPED_CONTENT_HASHES_EXACT_NEW1769_NO_DELTA_PACK_VERIFIED_BEFORE_ANY_REMOVAL','new_pack_sha':packhash,'new_pack_bytes':newpack.stat().st_size,'new_pack_sha256':sha(newpack),'new_idx_sha256':sha(newidx),'union_count':len(union),'unique_new_count':len(other),'snapshot':mid})
for x in keepmeta:assert sha(Path(x['path']))==x['sha256']
# Only now remove exact old redundant representations; all objects remain in keeper+verified standalone pack.
for x in oldmeta:
 p=Path(x['path']);assert sha(p)==x['sha256'];p.unlink()
for x in loosemeta:
 p=Path(x['path']);assert sha(p)==x['sha256'];p.unlink()
postsets=indexed();assert set(postsets)=={KEEP,'pack-'+packhash} and set().union(*postsets.values())==union;assert not loose()
afterobjects=read_all(union);assert afterobjects==json.loads((OUT/'ALL-OBJECTS-BEFORE.json').read_text());write('ALL-OBJECTS-AFTER.json',afterobjects)
for x in keepmeta+archives:
 p=Path(x['path']);assert sha(p)==x['sha256'] and p.stat().st_size==x['bytes'] and oct(stat.S_IMODE(p.stat().st_mode))==x['mode']
with (OUT/'keeper-verify-after.log').open('wb') as f:subprocess.run(['git','verify-pack','-v',str(D/(KEEP+'.idx'))],cwd=R,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
after=snapshot();assert all(after[k]==before[k] for k in before if k!='free_workspace');write('AFTER.json',after)
receipt={'status':'OBJECT_PRESERVING_STORAGE_DEDUPLICATION_PASS','at_utc':datetime.now(timezone.utc).isoformat(),'objects_before_after':len(union),'keeper_objects':937,'standalone_objects':1769,'standalone_pack_bytes':newpack.stat().st_size,'all_object_typed_SHA1_and_content_SHA256_before_after_exact':True,'keeper_files_byte_mode_hash_exact':True,'HEAD_refs_index_stage_status_config_sparse_exact':True,'current_materialized_archive_bytes_modes_hashes_exact':True,'removed_only_verified_redundant_pack_files':len(oldmeta),'removed_only_verified_redundant_loose_copies':len(loosemeta),'no_reachability_pruning_or_gc':True,'no_source_archive_worktree_or_ref_mutation':True,'no_fetch_reset_or_remote_mutation':True,'remote_main_prior_readonly_context':'aec47937cf348c35cdfcbfa02afc00e92b9bb6e0','remote_context_not_fetched_reset_or_adopted':True,'free_workspace_before':before['free_workspace'],'free_workspace_after':after['free_workspace'],'freed_workspace_bytes':after['free_workspace']-before['free_workspace']}
write('RECEIPT.json',receipt);manifest={'status':'CLOSED_OBJECT_PRESERVING_MAINTENANCE_PROOF','files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.iterdir()) if p.is_file()]};write('MANIFEST.json',manifest)
print(json.dumps(receipt,indent=2),flush=True);print('MANIFEST_SHA256',sha(OUT/'MANIFEST.json'),flush=True)
