from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json
w=Path('/tmp/chicago-resumed-evidence-20261023T2245');p=w/'publish_checkpoint.py';tree=ast.parse(p.read_text());body=[]
for node in tree.body:
 if isinstance(node,ast.Assert):break
 body.append(node)
ns={ '__file__':str(p)};exec(compile(ast.Module(body=body,type_ignores=[]),str(p),'exec'),ns)
receipt=json.loads((w/'LATEST-PUBLICATION.json').read_text());row=next(x for x in receipt['remote_readback'] if x['path'].endswith('/RECOVERY.md'));actual=ns['verify_remote_row'](receipt['commit'],row,row['git_blob']);assert actual['status']=='PASS';negative=[]
for kind in ['sha256','git_blob']:
 try:
  wrong=dict(row)
  if kind=='sha256':wrong['sha256']='0'*64
  ns['verify_remote_row'](receipt['commit'],wrong,'0'*40 if kind=='git_blob' else row['git_blob'])
 except AssertionError:negative.append(kind)
 else:raise AssertionError('Mismatch accepted: '+kind)
original=ns['run'];calls=[]
def fake(args,check=True):
 from types import SimpleNamespace
 calls.append(args)
 if args==['git','rev-parse','HEAD']:return SimpleNamespace(stdout='a'*40+'\n')
 if args==['git','ls-remote','origin','refs/heads/main']:return SimpleNamespace(stdout='a'*40+'\trefs/heads/main\n')
 raise AssertionError('Unexpected Git operation in equal-head control: '+str(args))
ns['run']=fake;same=ns['synchronize_remote']();ns['run']=original;assert same['fetched'] is False and len(calls)==3
out={'status':'TRANSPORT_AND_NO_FETCH_GUARDS_PASS','at_utc':datetime.now(timezone.utc).isoformat(),'publisher_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'strict_immutable_readback':actual,'wrong_author_sha256_refused':'sha256' in negative,'wrong_git_blob_sha1_refused':'git_blob' in negative,'equal_heads_no_fetch_merge_or_mutation':True,'equal_head_control_git_calls':calls,'no_remote_ref_or_settings_mutation':True};dest=Path('/workspace/chicago-evidence-publisher-transport-guards-20261024.json');dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
