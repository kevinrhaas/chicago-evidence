"""Run only the finite two-pose native external diagnostic after root grants CPU/GPU.
No source/claim/export/grade/scene/app/gate/PR mutation. Frozen preparation is read-only.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,shutil,subprocess,time
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',required=True,type=Path);ap.add_argument('--cpus',default='0,1');args=ap.parse_args()
assert os.environ.get('COBWEB_CAMERA_LEASE')=='explicit-root-after-fourcase-gate','Wait for actual root CPU/GPU release'
P=Path(__file__).resolve().parent;O=args.out;assert not O.exists();assert shutil.disk_usage(O.parent).free>=512*1024*1024,'Keep unchanged native512MiB scratch margin'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs=json.loads((P/'INPUTS.json').read_text());manifest=json.loads((P/'MANIFEST.json').read_text())
for row in manifest['members']:
 f=P/row['relative_path'];assert f.is_file()and f.stat().st_size==row['bytes']and sha(f)==row['sha256'],('Frozenprepchanged',row['relative_path'])
for row in inputs['bindings']:
 src=Path(row['source']);assert src.is_file()and src.stat().st_size==row['bytes']and sha(src)==row['sha256'],('Currentconsumer/sourcechanged; reviewandfreshlybindbeforetrial',str(src))
O.mkdir();shutil.copytree(P/'runtime',O/'runtime');shutil.copytree(P/'cameras',O/'cameras');shutil.copyfile(P/'source.jpg',O/'source.jpg');(O/'logs').mkdir();(O/'scratch').mkdir();runtime=O/'runtime'
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PW_EXECUTABLE='/usr/bin/chromium',TMPDIR=str(O/'scratch'),GIT_NO_LAZY_FETCH='1');results=[]
for name in ['end-rear-70','end-front-110']:
 log=O/'logs'/(name+'.log');reap=O/'logs'/(name+'-REAPER.json');command=['python3','/workspace/shared/run-with-reaping.py',str(reap),'--','nice','-n','19','taskset','-c',args.cpus,'node','tools/photo_match.mjs',str(O/'cameras'/(name+'.json')),'--glb','assets/gltf/cobweb_castle__log_1820.glb','--out',str(O/'outputs'/name)];start=time.monotonic()
 with log.open('x')as f:q=subprocess.run(command,cwd=runtime,env=E,stdout=f,stderr=subprocess.STDOUT)
 r=json.loads(reap.read_text());row={'view':name,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'cwd':str(runtime),'exit':q.returncode,'seconds':round(time.monotonic()-start,3),'command_exit':r.get('command_exit'),'all_children_reaped':r.get('all_children_reaped'),'leftover_cleanup':r.get('leftover_cleanup')};results.append(row);(O/'STAGES.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert q.returncode==0 and r['command_exit']==0 and r['all_children_reaped']and not r['leftover_cleanup'],row
 m=re.search(r'\n\s+(/[^\n]+-render\.png)\n',log.read_text());assert m;raw=Path(m.group(1));assert raw.is_file();shutil.copyfile(raw,O/'outputs'/name/'ACTUAL-NATIVE.png')
for row in inputs['bindings']:assert sha(Path(row['source']))==row['sha256'],('Currentprotectedinputmoved',row['source'])
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_FINITE_TWO_POSE_NATIVE_CAMERA_DIAGNOSTICS_PASS_UNREVIEWED','stages':results,'unchanged_actualcurrentMASTER':'af1f33c0f5d75fc8c40e6cbb589adfd7d29d551572c2775e236bb260f6ee561f','no_canonical_source_claim_grade_picture_verdict_PR_or_originalclosure':True,'next':'DirectlyinspectactualnativebothposesagainstreferencesheetunderT3153; chooseonlydefensibleconditionalformandrealvisibledefects. Do notinferamatchfromprojectedboundsorfalselyattesthistoricalsubject.'};(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
