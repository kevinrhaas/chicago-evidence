import fs from 'node:fs';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
const root='/tmp/chicago-log-integration/';
const expected=JSON.parse(fs.readFileSync(new URL('PROJECTION-DEPENDENCIES.json',import.meta.url)));
for(const [path,sha] of Object.entries(expected.three)){
 const actual=crypto.createHash('sha256').update(fs.readFileSync(root+path)).digest('hex');
 if(actual!==sha)throw Error('Three source drift '+path);
}
const THREE=await import(pathToFileURL(root+'chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js'));
const c=JSON.parse(fs.readFileSync(new URL('existing-provisional-camera.json',import.meta.url)));
const [W,H]=c.image_px,[cx,cy]=c.principal_px,f=c.focal_px;
const FW=2*Math.max(cx,W-cx),FH=2*Math.max(cy,H-cy);
const cam=new THREE.PerspectiveCamera(2*Math.atan(FH/2/f)*180/Math.PI,FW/FH,.1,500);
cam.setViewOffset(FW,FH,FW/2-cx,FH/2-cy,W,H);
const [u,v,y]=c.eye,t=c.yaw_deg*Math.PI/180;
cam.position.set(u,y,-v);cam.lookAt(u+Math.sin(t),y,-v-Math.cos(t));cam.updateMatrixWorld(true);
const record=JSON.parse(fs.readFileSync(new URL('candidate/data/structures/green_tree_tavern.json',import.meta.url)));
const fractions=record.phases[0].form.front_ground_layout.value;
if(JSON.stringify(fractions)!==JSON.stringify([.20,.50,.78]))throw Error('Candidate projection input drift');
const project=stations=>stations.map(([role,at])=>{
 const pos=new THREE.Vector3(7.62*at,role==='door'?1.05:1.425,-12.19);
 const depth=-(pos.clone().applyMatrix4(cam.matrixWorldInverse).z);
 if(!(depth>0))throw Error('Projected point behind the unchanged camera');
 const q=pos.project(cam);
 return {role,local_u_fraction:at,screen_x:(q.x+1)*W/2,screen_y:(1-q.y)*H/2,positive_camera_depth:depth};
});
const ordered=points=>[...points].sort((a,b)=>a.screen_x-b.screen_x).map(p=>p.role);
const old=project([['sash',.22],['sash',.50],['door',.80]]);
const now=project([['door',fractions[0]],['sash',fractions[1]],['sash',fractions[2]]]);
if(ordered(old).join(',')!=='door,sash,sash')throw Error('Failed to reproduce preserved v1 mirror counterexample');
if(ordered(now).join(',')!=='sash,sash,door')throw Error('V2 contradicts source screen order');
if(!(v>12.19&&f>0)||c.basis_right_up_forward)throw Error('General derivative proof assumptions not satisfied');
const derivatives=fractions.map(at=>{
 const du=7.62*at-u,dv=12.19-v;
 const right=Math.cos(t)*du-Math.sin(t)*dv,depth=Math.sin(t)*du+Math.cos(t)*dv;
 const derivative=f*dv/(depth*depth);
 if(!(derivative<0))throw Error('Exterior+y local-u ordering proof failed');
 return {local_u:7.62*at,screen_x_closed_form:cx+f*right/depth,dx_screen_du:derivative};
});
const result={scope:'CPU_NATIVE_THREE_AND_ANALYTIC_HANDEDNESS_ONLY_NO_RENDER_BROWSER_MATCH',camera_sha256:expected.camera_sha256,
 old_v1:old,old_v1_screen_order:ordered(old),old_v1_negative_detected:true,
 corrected_v2:now,corrected_v2_screen_order:ordered(now),source_relative_order_agrees:true,
 general_front_view_proof:'For this unrolled yaw camera, screenX=cx+f*(cos(t)*(u-eu)-sin(t)*(v-ev))/(sin(t)*(u-eu)+cos(t)*(v-ev)). On constant front v=d, derivative=f*(d-ev)/positiveDepth^2 <0 whenever exterior eye_v>d. Thus local-u increases screen LEFT independently of principal point, yaw and metric station spacing, provided the front is visible/in front of camera. Roll/custom basis are not assumed.',
 derivatives,source_camera:'PROVISIONAL/UNSOLVED unchanged; no geographic relocation',original_T2376:'OPEN/DIFFERS',new_capture:false};
fs.writeFileSync(new URL('HANDEDNESS-CPU-PROOF.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log('PASS exact native Three v1 MIRROR negative; corrected v2 screen sash,sash,door; exterior+y derivative negative; no camera change/render');
