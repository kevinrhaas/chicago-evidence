import pathlib,subprocess,json,hashlib,difflib
P=pathlib.Path(__file__).parent;R=pathlib.Path('/tmp/chicago-log-integration');REF='7a58448ab207e67de14fb7d792ca01258ce8f748';A='chicago/4d/'
sha=lambda b:hashlib.sha256(b).hexdigest()
def frozen(path):return subprocess.check_output(['git','-C',str(R),'show',REF+':'+A+path])
paths=['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','data/structures/green_tree_tavern.json','docs/RESEARCH/green_tree_tavern.md','tools/test_frame_tavern_picture_features.py']
baseline={p:frozen(p) for p in paths};cand={p:b.decode() for p,b in baseline.items()}
def replace(path,old,new):
 assert cand[path].count(old)==1,(path,old);cand[path]=cand[path].replace(old,new,1)
pp=paths[1];bp=paths[0]
replace(pp,'"first_story_height_m", "entry_raise_m", "gable_lunette",','"first_story_height_m", "entry_raise_m", "gable_lunette", "front_ground_layout",')
replace(pp,'    # Explicit sash on the MAIN gable ends of a frontage-scheme block (T-2383).','    # Ground floor of the +y gable only: two sash then one door, at fractions\n    # across its width. None preserves the legacy centred-door layout exactly.\n    # Stations and stock sections remain reconstructed; this is not a survey.\n    front_ground_layout: list[float] | None = field(default=None, kw_only=True)\n\n    # Explicit sash on the MAIN gable ends of a frontage-scheme block (T-2383).')
replace(pp,'        if self.end_windows:\n','''        if self.front_ground_layout is not None:
            stations = self.front_ground_layout
            if self.conf("front_ground_layout") != 1.0:
                raise ParamError("front_ground_layout metrics must remain reconstructed")
            if self.elevation_scheme != "gable_front":
                raise ParamError("front_ground_layout needs the gable_front scheme")
            if not isinstance(stations, list) or len(stations) != 3:
                raise ParamError("front_ground_layout needs three fractions: sash, sash, door")
            if any(isinstance(v, bool) or not isinstance(v, (int, float))
                   or not math.isfinite(v) for v in stations):
                raise ParamError("front_ground_layout stations must be finite numbers")
            if not stations[0] < stations[1] < stations[2]:
                raise ParamError("front_ground_layout must order two left sash before the door")
            # Existing opening widths, plus at least .15 m to a corner and
            # .30 m between openings. Never shrink a kit to fit a bad layout.
            spans = [(at * self.width_m - width / 2,
                      at * self.width_m + width / 2)
                     for at, width in zip(stations, (.85, .85, 1.20))]
            if spans[0][0] < .15 or spans[-1][1] > self.width_m - .15:
                raise ParamError("front_ground_layout reaches a wall corner")
            if any(right[0] - left[1] < .30 for left, right in zip(spans, spans[1:])):
                raise ParamError("front_ground_layout overlaps openings or leaves too little pier")
            if self.wall_height_m / self.stories < 2.25:
                raise ParamError("front_ground_layout needs the stock 2.1 m door below its storey")
        if self.end_windows:
''')
replace(pp,'        eaves_bays=val("eaves_bays", {}),','        eaves_bays=val("eaves_bays", {}),\n        front_ground_layout=val("front_ground_layout"),')
replace(bp, '    # ---- the front gable: centred door, flanking bays ---------------------- #', '    # ---- front gable: legacy centre door, optional ground-only layout ----- #')
replace(bp,'''    _door(b, params, "y", d, 1, w / 2 - 0.6, w / 2 + 0.6, 0.0, 2.1, conf)
    for story in range(params.stories):
        z0 = story * story_h + story_h * 0.30
        for cx in (w * 0.22, w * 0.78):
''','''    layout = params.front_ground_layout
    door_cx = w / 2 if layout is None else w * layout[2]
    ground_conf = conf if layout is None else max(conf, params.conf("front_ground_layout"))
    _door(b, params, "y", d, 1, door_cx - 0.6, door_cx + 0.6, 0.0, 2.1, ground_conf)
    for story in range(params.stories):
        z0 = story * story_h + story_h * 0.30
        stations = (0.22, 0.78) if layout is None or story else layout[:2]
        window_conf = ground_conf if story == 0 else conf
        for at in stations:
            cx = w * at
''')
# The replacement above preserves operation order for legacy centres; .22*w
# vs w*.22 is IEEE-identical for finite floats. No other faces read this field.
old='''            _win(b, params, "y", d, 1, cx - win_w / 2, cx + win_w / 2, z0, z0 + win_h,
                 conf)
''';new=old.replace('                 conf)','                 window_conf)');replace(bp,old,new)
record=json.loads(cand[paths[2]]);record['phases'][0]['form']['front_ground_layout']={
 'value':[.22,.50,.80], 'confidence':'reconstructed',
 'sources':['andreas_1884_green_tree_hotel_plate','trowbridge_green_tree_1902','kurz_allison_1893'],
 'note':'Two sash left of a rightmost front-gable entrance agree in the actually viewed Andreas 1884 p634/n1301 plate, Trowbridge/Gale 1902 plate facing p35/n55, and Kurz & Allison 1893 panel11. This is retrospective form agreement, not independent contemporaneous proof of 1 July 1835; Kurz may derive from Andreas and Trowbridge may rely on later material. Exact centre fractions .22/.50/.80 across the existing 7.62 m wall, equal existing .85x1.35 m sash and 1.20x2.10 m door stock, sill bands, sections and hidden joinery are RECONSTRUCTED, not measured or attested by those pictures. Only the +y front ground floor opts in. The current two upper sash versus Trowbridge\'s three, attic light, text-attested south-side door, disputed additions, roof, geographic placement and all existing source/camera uncertainties stay unresolved. The held-rights/unverified 1859 source is excluded as a geometry witness. Original T-2376 remains open/differs; this is not a solved camera or picture match.'}
cand[paths[2]]=json.dumps(record,indent=2,ensure_ascii=False)+'\n'
append='''\n\n## Front-ground entrance layout — bounded retrospective reconstruction\n\n`not_a_reading`: rereading the already admitted three plates to adjudicate one\nvisible layout discrepancy; no new formal source unit or research spend.\n\nThe actual whole Andreas1884 p634/n1301 and Trowbridge/Gale1902 plate facingp35/n55,\nand Kurz1893 panel11, agree on two lower front-gable sash to the left of a\nrightmost door. The old centre-door/flanking-sash layout is revised only on this\nfront ground floor. Their agreement is not three independent period witnesses:\nKurz may derive from Andreas and Trowbridge may depend on later material.\nNeither the local1838 label nor the retrospective1835 title proves the precise\nJuly1835 form. This is a declared working reconstruction of the early inn.\n\nThe chosen fractions .22/.50/.80, existing stock opening dimensions and sections\nare reconstructed, NOT picture measurements. Keep the upper two-versus-three\nsash conflict, attic, text-attested side entrance, additions, roof and geographic\nplacement unchanged. Keep all comparisons DIFFERS pending actual current exports,\nsource-specific cameras and side-by-sides. Andreas1884, Trowbridge1902 and\nKurz1893 underlying artwork have their existing public-domain source credits; no\nnew rights upgrade is made. Exclude `chm_green_tree_1859` (check_required/unverified)\nand the site filename1859.jpg as governing geometry: the viewed site file is an\nengraving, not thereby a verified CHM photograph. No later commercial shopfront,\nawning, sign or gaslamp is backdated.\n'''
cand[paths[3]]=cand[paths[3]].rstrip()+append
tests = """    def test_green_tree_front_ground_layout_is_sparse_and_reconstructed(self):
        record, phase, p = record_params("green_tree_tavern", "frame_1833")
        self.assertEqual(p.front_ground_layout, [.22, .50, .80])
        self.assertIn("front_ground_layout", CONSUMED)
        signature = inspect.signature(FrameTavernParams)
        self.assertEqual(signature.parameters["front_ground_layout"].kind,
                         inspect.Parameter.KEYWORD_ONLY)
        calls = []
        with patch.object(builder, "_win", lambda *a, **k: calls.append(("win", a[2:]))), \
             patch.object(builder, "_door", lambda *a, **k: calls.append(("door", a[2:]))):
            builder._fenestration_gable_front(MeshBuilder("layout"), p, p.width_m,
                                              p.depth_m, p.wall_height_m, 8., .5)
        front_ground = [(kind, a) for kind, a in calls
                        if a[0] == "y" and a[1] == p.depth_m and a[2] == 1
                        and a[5] < p.wall_height_m / p.stories]
        self.assertEqual([kind for kind, _ in front_ground], ["door", "win", "win"])
        for (_, a), at, width in zip(front_ground, (.80, .22, .50), (1.20, .85, .85)):
            self.assertEqual(a[3:5], (p.width_m*at-width/2, p.width_m*at+width/2))
            self.assertEqual(a[-1], 1.)
        legacy = copy.deepcopy(record)
        del legacy["phases"][0]["form"]["front_ground_layout"]
        self.assertIsNone(from_phase(legacy["phases"][0], legacy).front_ground_layout)

    def test_front_ground_layout_refuses_bad_shape_spacing_or_grade(self):
        _, _, p = record_params("green_tree_tavern", "frame_1833")
        for bad in (False, (), [], [.2, .8], [True, .5, .8], [math.nan, .5, .8],
                    [.2, math.inf, .8], [".2", .5, .8], [.5, .2, .8],
                    [-.1, .5, .8], [.2, .5, 1.], [.2, .22, .8]):
            with self.subTest(bad=bad), self.assertRaises(ParamError):
                dataclasses.replace(p, front_ground_layout=bad).validate()
        for grade in ("attested", "inferred"):
            with self.subTest(grade=grade), self.assertRaises(ParamError):
                dataclasses.replace(p, confidence={**p.confidence,
                                      "front_ground_layout": grade}).validate()
        with self.assertRaises(ParamError):
            dataclasses.replace(p, elevation_scheme="frontage").validate()

"""
replace(paths[4], '    def test_green_tree_override_changes_only_named_eaves_face(self):', tests+'    def test_green_tree_override_changes_only_named_eaves_face(self):')
for p,b in baseline.items():
 q=P/'baseline'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
for p,s in cand.items():
 q=P/'candidate'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
# Freeze only CPU dependency modules; no large checkout or asset copies.
ls=subprocess.check_output(['git','-C',str(R),'ls-tree','-r','--name-only',REF,'--',A+'generators/common'],text=True).splitlines()
deps={}
for fullname in ls:
 if not fullname.endswith('.py'):continue
 p=fullname[len(A):];b=frozen(p);q=P/'cpu-deps'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);deps[p]=sha(b)
assets=json.loads(frozen('assets/manifest.json'))['assets'];family={k:v for k,v in assets.items() if v.get('archetype')=='frame_tavern'};assert len(family)==23
for name,row in family.items():
 p='data/structures/'+row['structure_id']+'.json';q=P/'cpu-deps'/p
 if not q.exists():q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(frozen(p))
q=P/'cpu-deps/data/structures.schema.json';q.write_bytes(frozen('data/structures.schema.json'))
(P/'family23.json').write_text(json.dumps(family,indent=2)+'\n')
guard_paths=paths+['docs/LIBERTIES.md','generators/emit.py','generators/mesh_inputs.py','generators/code_inputs.py','tools/validate.py','tools/compile_liberties.py','tools/test_frame_tavern_picture_features.py','data/structures.schema.json','assets/manifest.json','assets/manifest.web.json']+[f'data/sources/{s}.json' for s in record['phases'][0]['form']['front_ground_layout']['sources']]+['data/sources/chm_green_tree_1859.json']
guards={p:{'committed7a_sha256':sha(frozen(p)), 'observed_live_sha256':sha((R/A/p).read_bytes())} for p in guard_paths};guards.update({p:{'committed7a_sha256':v,'observed_live_sha256':sha((R/A/p).read_bytes())} for p,v in deps.items()})
reader_paths=[]
for q in sorted((R/A/'tools').glob('*.py')):
 text=q.read_text()
 if 'frame_tavern' not in text and 'FrameTavernParams' not in text:continue
 name=q.relative_to(R/A).as_posix();guards[name]={'committed7a_sha256':sha(frozen(name)),'observed_live_sha256':sha(q.read_bytes())};reader_paths.append(name)
(P/'GUARDS.json').write_text(json.dumps({'ref':REF,'paths':guards,'frame_reader_paths':reader_paths,'family23':list(family),'latest_liberties_prefix_policy':'Observed whole-prefix hash is a refusal guard, never a replacement document; later drift requires selective union preserving incoming bytes.','policy':'Core authored preimages must match exactly; latest full LIBERTIES prefix and all named readers must be reread/verified at later selective union. Never overwrite an incoming ledger/name-reader update with this snapshot. Noncore live deltas are not owned by this proposal.'},indent=2)+'\n')
(P/'proposal.patch').write_text(''.join(''.join(difflib.unified_diff(baseline[p].decode().splitlines(True),cand[p].splitlines(True),fromfile='a/'+A+p,tofile='b/'+A+p)) for p in paths))
print('PREPARED',len(paths),'authored paths',len(deps),'CPU modules',len(family),'recipes')
