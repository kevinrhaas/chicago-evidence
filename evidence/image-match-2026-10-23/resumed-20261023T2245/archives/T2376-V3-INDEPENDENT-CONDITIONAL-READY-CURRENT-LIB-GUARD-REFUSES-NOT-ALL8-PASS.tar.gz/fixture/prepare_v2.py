import pathlib,json,subprocess,hashlib,difflib
P=pathlib.Path(__file__).parent;V1=pathlib.Path('/workspace/T2376-front-ground-proposal-7a-20261024');R=pathlib.Path('/tmp/chicago-log-integration');REF='7a58448ab207e67de14fb7d792ca01258ce8f748';A='chicago/4d/'
sha=lambda b:hashlib.sha256(b).hexdigest();paths=[str(p.relative_to(V1/'candidate')) for p in sorted((V1/'candidate').rglob('*')) if p.is_file()];cand={p:(V1/'candidate'/p).read_text() for p in paths}
def replace(p,a,b):
 assert cand[p].count(a)==1,(p,a);cand[p]=cand[p].replace(a,b,1)
pp='generators/archetypes/frame_tavern_params.py';bp='generators/archetypes/frame_tavern.py';rp='data/structures/green_tree_tavern.json';tp='tools/test_frame_tavern_picture_features.py';dp='docs/RESEARCH/green_tree_tavern.md';ep='tools/generate_entrances.py'
replace(pp,'# Ground floor of the +y gable only: two sash then one door, at fractions','# Ground floor of the +y gable only: door then two sash in local +u, at fractions')
replace(pp,'front_ground_layout needs three fractions: sash, sash, door','front_ground_layout needs three local fractions: door, sash, sash')
replace(pp,'front_ground_layout must order two left sash before the door','front_ground_layout must order low-u door before the two local-u sash')
replace(pp,'zip(stations, (.85, .85, 1.20))','zip(stations, (1.20, .85, .85))')
helper='''def front_ground_stations(params: FrameTavernParams) -> tuple[float, tuple[float, float]]:
    """Pure footprint-u centres shared by mesh and exact-phase access reader.

    The +y front is viewed from outside at v > depth, so LOW u is SCREEN RIGHT:
    a low-u door and two higher-u sash give the pictured sash/sash/door order.
    Door defaults apply to every tavern scheme; the two sash centres are used
    only by gable_front. Sections/metric stations remain reconstructed.
    """
    if params.front_ground_layout is None:
        return params.width_m / 2, (params.width_m * .22, params.width_m * .78)
    door, sash_a, sash_b = params.front_ground_layout
    return params.width_m * door, (params.width_m * sash_a, params.width_m * sash_b)


'''
replace(pp,'def from_phase(phase: dict, record: dict | None = None) -> FrameTavernParams:',helper+'def from_phase(phase: dict, record: dict | None = None) -> FrameTavernParams:')
replace(bp,'from archetypes.frame_tavern_params import FrameTavernParams  # noqa: E402','from archetypes.frame_tavern_params import FrameTavernParams, front_ground_stations  # noqa: E402')
replace(bp,'    door_cx = w / 2 if layout is None else w * layout[2]','    door_cx, ground_sash_centres = front_ground_stations(params)')
replace(bp,'''        stations = (0.22, 0.78) if layout is None or story else layout[:2]
        window_conf = ground_conf if story == 0 else conf
        for at in stations:
            cx = w * at
''','''        centres = (w * .22, w * .78) if story else ground_sash_centres
        window_conf = ground_conf if story == 0 else conf
        for cx in centres:
''')
rec=json.loads(cand[rp]);field=rec['phases'][0]['form']['front_ground_layout'];field['value']=[.20,.50,.78];field['note']=field['note'].replace('Exact centre fractions .22/.50/.80 across','The ascending LOCAL-u fractions are door .20, sash .50, sash .78: exterior +y viewers see higher u toward screen left, so this yields two screen-left sash and a screen-right entrance. Exact centre fractions .20/.50/.78 across');field['note']+=' The same pure door-centre helper is consumed by the mesh and the native entrance/apron/clearance reader after resolving exactly the sidecar-selected source phase; no renderer facade API or bearing is changed.';cand[rp]=json.dumps(rec,indent=2,ensure_ascii=False)+'\n'
# Amend only the newly appended dossier text; preserve the entire baseline prefix.
base=(P/'baseline'/dp).read_text();suffix=cand[dp][len(base.rstrip()):];suffix=suffix.replace('The chosen fractions .22/.50/.80','The chosen ascending LOCAL-u fractions .20/.50/.78 (door, sash, sash)');suffix+='\nThe exterior +y face reverses local-u screen order: low-u is screen right.\nThe shared pure `front_ground_stations` helper feeds the mesh and exact-phase\nnative entrance/apron/doorway-clearance reader; no camera or geographic bearing\nis changed to obtain the order. Full native derivation remains owed.\n';cand[dp]=base.rstrip()+suffix
replace(tp,'from pathlib import Path\n','from pathlib import Path\nimport ast\n')
replace(tp,'self.assertEqual(p.front_ground_layout, [.22, .50, .80])','self.assertEqual(p.front_ground_layout, [.20, .50, .78])')
replace(tp,'zip(front_ground, (.80, .22, .50), (1.20, .85, .85))','zip(front_ground, (.20, .50, .78), (1.20, .85, .85))')
replace(tp, '        legacy = copy.deepcopy(record)\n', '''        # Exterior +y view, yaw180: camera-right is -u. Physical screen order
        # must be two sash then the door, not merely ascending local stations.
        screen_order = [kind for kind, a in sorted(front_ground,
                        key=lambda call: -(call[1][3]+call[1][4])/2)]
        self.assertEqual(screen_order, ["win", "win", "door"])
        legacy = copy.deepcopy(record)
''')

# Native source uses source phase, never an invented sc.form fallback.
raw=subprocess.check_output(['git','-C',str(R),'show',REF+':'+A+ep]);q=P/'baseline'/ep;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw);cand[ep]=raw.decode();paths.append(ep)
replace(ep,'from archetypes.log_dwelling_params import side_access_faces as _log_side_access_faces  # noqa: E402','''from archetypes.log_dwelling_params import side_access_faces as _log_side_access_faces  # noqa: E402
from archetypes.frame_tavern_params import (  # noqa: E402
    from_phase as _frame_tavern_params, front_ground_stations as _frame_front_ground_stations,
)''')
replace(ep,'''`frame_tavern` has no reader; both its schemes centre the
front door on the front wall, 1.2 m wide (`frame_tavern.py`, "the front gable: centred
door" and "four plus a centred door below"), and that is what is read here, by name.''','''`frame_tavern` remains UNREAD by the generic facade API. Its primary door is
read separately from the pure shared front_ground_stations helper after resolving
the exact sidecar-selected source phase. Absent opt-in keeps the centred 1.2 m
door and old read_by metadata; a declared gable-front layout moves only that door's
native approach/clearance along the same front wall.''')
replace(ep,'        c = (u0 + u1) / 2.0\n', '''        record = gbs._load(gbs.STRUCTURES / f"{sc['id']}.json")
        phases = [ph for ph in record.get("phases", []) if ph.get("id") == sc.get("phase")]
        if len(phases) != 1:
            raise ValueError(f"{sc['id']}: front entrance needs exactly one selected phase")
        params = _frame_tavern_params(phases[0], record)
        c, _sash = _frame_front_ground_stations(params)
        reader = "frame_tavern centred front door"
        if params.front_ground_layout is not None:
            if poly != phases[0].get("footprint", {}).get("polygon"):
                raise ValueError(f"{sc['id']}: front entrance sidecar footprint is stale")
            reader = "frame_tavern.front_ground_stations (selected phase)"
''')
replace(ep,'"frame_tavern centred front door")\n    wall', 'reader)\n    wall')
replace(ep,'TAVERN_DOOR_W_M = 1.2      # frame_tavern.py\'s front door, w/2 +- 0.6, both schemes','TAVERN_DOOR_W_M = 1.2      # shared stock front-door width; only the declared centre moves')
replace(ep,'"generated_from": ["data/sidecars/1835/", "generators/archetypes/facade_openings.py"],','''"generated_from": ["data/sidecars/1835/", "generators/archetypes/facade_openings.py"] + (
            ["data/structures/", "generators/archetypes/frame_tavern_params.py"]
            if any(x["read_by"] == "frame_tavern.front_ground_stations (selected phase)"
                   for x in entrances) else []),''')
# Add one narrow canonical regression for exact-phase consumption; no full fixture.
native_test='''    def test_front_ground_access_reads_exact_phase_not_sidecar_form(self):
        record, phase, p = record_params("green_tree_tavern", "frame_1833")
        from archetypes.frame_tavern_params import front_ground_stations
        decoy = copy.deepcopy(phase)
        decoy["id"] = "other_phase_first"
        del decoy["form"]["front_ground_layout"]
        record = {**record, "phases": [decoy, phase]}
        tree = ast.parse((ROOT / "tools/generate_entrances.py").read_text())
        node = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                    and n.name == "front_doors")
        fake = types.SimpleNamespace(STRUCTURES=ROOT / "data/structures",
            _load=lambda path: record,
            _front_edge=lambda poly: (0., p.width_m, p.depth_m))
        ns = {"gbs": fake, "_frame_tavern_params": from_phase,
              "_frame_front_ground_stations": front_ground_stations,
              "TAVERN_DOOR_W_M": 1.2}
        exec(compile(ast.Module(body=[node], type_ignores=[]), "actual_front_doors", "exec"), ns)
        sc = {"id": record["id"], "archetype": "frame_tavern", "phase": phase["id"],
              "footprint": phase["footprint"], "form": {"front_ground_layout": {"value": [.8,.9,.95]}}}
        doors, reader = ns["front_doors"](sc)
        c, _ = front_ground_stations(p)
        self.assertEqual(doors, [{"kind": "door", "u0": c-.6, "u1": c+.6}])
        self.assertIn("selected phase", reader)
        with self.assertRaises(ValueError):
            ns["front_doors"]({**sc, "phase": "nonexistent"})

'''
replace(tp,'    def test_green_tree_override_changes_only_named_eaves_face(self):',native_test+'    def test_green_tree_override_changes_only_named_eaves_face(self):')
for p,s in cand.items():
 q=P/'candidate'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
(P/'proposal.patch').write_text(''.join(''.join(difflib.unified_diff((P/'baseline'/p).read_text().splitlines(True),cand[p].splitlines(True),fromfile='a/'+A+p,tofile='b/'+A+p)) for p in paths))
g=json.load(open(V1/'GUARDS.json'));g['paths'][ep]={'committed7a_sha256':sha(raw),'observed_live_sha256':sha((R/A/ep).read_bytes())};g['paths']['tools/generate_business_signboards.py']={'committed7a_sha256':sha(subprocess.check_output(['git','-C',str(R),'show',REF+':'+A+'tools/generate_business_signboards.py'])),'observed_live_sha256':sha((R/A/'tools/generate_business_signboards.py').read_bytes())};(P/'GUARDS.json').write_text(json.dumps(g,indent=2)+'\n')
q=P/'cpu-deps/tools/generate_business_signboards.py';q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(subprocess.check_output(['git','-C',str(R),'show',REF+':'+A+'tools/generate_business_signboards.py']))
for path in ['data/reconstruction/name_pool_keys.json','tools/replace_invented_residents.py','tools/town_year.py']:
 b=subprocess.check_output(['git','-C',str(R),'show',REF+':'+A+path]);g['paths'][path]={'committed7a_sha256':sha(b),'observed_live_sha256':sha((R/A/path).read_bytes())}
g['latest_name_pool_registry_policy']='Only own new read.structures key may be selectively added; drift requires reviewed union, never stale full-file overwrite.'
(P/'GUARDS.json').write_text(json.dumps(g,indent=2)+'\n')
print('V2 PREPARED',len(paths),'authored paths; V1 untouched')
