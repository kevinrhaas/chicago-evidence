"""Existing Wolf AST adapter reused for bounded native physical/world access proof.
No generated source/sidecar files, native pipeline, browser or scene publication.
"""
from pathlib import Path
from types import SimpleNamespace
import ast,sys,json,math,re,copy,importlib.util,os,collections
sys.dont_write_bytecode=True
P=Path(__file__).parent;os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});sys.path[:0]=[str(P/'cpu-deps/generators'),str(P/'candidate/generators')]
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
params=load('native_access_params',P/'candidate/generators/archetypes/frame_tavern_params.py')
records={}
for f in (P/'cpu-deps/data/structures').glob('*.json'):records[f.stem]=json.load(open(f))
helperns={'math':math};tree=ast.parse((P/'cpu-deps/tools/generate_business_signboards.py').read_text());names={'_front_edge','_to_enu','_nearest_on_path'}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'actual_gbs_helpers','exec'),helperns)
other_wall={'openings':[{'kind':'door','u0':1.,'u1':2.,'z0':0.,'z1':2.},{'kind':'show_window','u0':3.,'u1':4.,'z0':.5,'z1':2.},{'kind':'door','u0':5.,'u1':6.,'z0':3.,'z1':5.}]}
gbs=SimpleNamespace(**{k:helperns[k] for k in names},STRUCTURES=Path('/READ_ONLY_SOURCE_MAP'),_load=lambda path:records[path.stem],_front_wall=lambda sid:None if sid=='unread_bridge' else other_wall,facade_openings=SimpleNamespace(HOLE_KINDS={'door','show_window'}))
gfw=SimpleNamespace(_nearest_on_path=helperns['_nearest_on_path'])
consts={'ENTRANCE_KINDS','GROUND_Z_M','TAVERN_DOOR_W_M','STRIP_DEPTH_M','STRIP_PAST_CORNER_M','PATH_SIDE_AT_STRIP_M','PATH_SIDE_OUT_M','PATH_DEPTH_M','PATH_TO_STREET_M','PATH_INTO_TRACK_M','PATH_ROUND_M','OPENING_GAP_M','SHOPFRONT','DOORWAY_SIDE_M','DOORWAY_OUT_M'}
def native(path):
 tree=ast.parse(path.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in consts for t in n.targets)]
 ns={'math':math,'json':json,'re':re,'Path':Path,'gbs':gbs,'gfw':gfw,'_log_side_access_faces':lambda p:[], '_frame_tavern_params':params.from_phase,'_frame_front_ground_stations':lambda p: p.resolved_front_ground_stations}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ns);ns['_streets']=lambda:[];return ns
old=native(P/'baseline/tools/generate_entrances.py');new=native(P/'candidate/tools/generate_entrances.py')
family=json.load(open(P/'family23.json'));sidecars=[]
for name,row in family.items():
 rec=records[row['structure_id']];ph=next(x for x in rec['phases'] if x['id']==row['phase_id']);sc={'id':rec['id'],'archetype':'frame_tavern','phase':ph['id'],'footprint':copy.deepcopy(ph['footprint']),'attributes':copy.deepcopy(ph['form']),'placement':{'local_e':17.125,'local_n':-23.5,'rotation_deg':ph.get('position',{}).get('rotation_deg',0)}};sidecars.append(sc)
assert all('form' not in x for x in sidecars)
old['_sidecars']=new['_sidecars']=lambda:sidecars
legacyold=old['build']();legacynew=new['build']();assert legacyold==legacynew,'default native output changed'
assert old['doorway_zones']()==new['doorway_zones']()
other=[]
for arch in ['frame_dwelling','frame_storefront','outbuilding','log_dwelling','bridge_timber']:
 sc={'id':'unread_bridge' if arch=='bridge_timber' else 'other','archetype':arch};a=old['front_doors'](sc);b=new['front_doors'](sc);assert a==b;other.append({'archetype':arch,'front_reader_exact':True,'result':b})
# Reorder source phases: the first phase is an intentionally centred decoy.
rec=json.load(open(P/'candidate/data/structures/green_tree_tavern.json'));ph=rec['phases'][0];decoy=copy.deepcopy(ph);decoy['id']='decoy_other_phase';del decoy['form']['front_ground_layout'];rec['phases']=[decoy,ph];records[rec['id']]=rec
sc=copy.deepcopy(next(x for x in sidecars if x['id']==rec['id']));sc['attributes']=copy.deepcopy(ph['form']);assert 'form' not in sc
new['_sidecars']=old['_sidecars']=lambda:[sc]
p=params.from_phase(ph,rec);door_cx,_=p.resolved_front_ground_stations;expected_interval=(door_cx-.6,door_cx+.6);actual=new['front_doors'](sc);assert (actual[0][0]['u0'],actual[0][0]['u1'])==expected_interval
# Old-centred-reader negative control MUST remain false after mirror fix.
legacy_interval=old['front_doors'](sc)[0][0];assert (legacy_interval['u0'],legacy_interval['u1'])!=expected_interval
# A fabricated sc.form value cannot override the exact selected source phase.
trap={**sc,'form':{'front_ground_layout':{'value':[.80,.90,.95]}}};assert new['front_doors'](trap)==actual
rotations=[]
for rotation in [0.,37.,90.,180.,270.,359.]:
 sc['placement']['rotation_deg']=rotation;result=new['build']();d=result['entrances'][0];t=math.radians(rotation);e=17.125+door_cx*math.cos(t)+p.depth_m*math.sin(t);n=-23.5-door_cx*math.sin(t)+p.depth_m*math.cos(t);assert d['at_local_enu_m']==[round(e,2),round(n,2)]
 assert d['width_m']==1.2 and d['bearing_deg']==rotation
 # Doorway zone front edge is centred on the rounded actual native threshold.
 zone=dict(new['doorway_zones']())[d['id']];mid=[(zone[0][j]+zone[1][j])/2 for j in [0,1]];assert all(abs(mid[j]-d['at_local_enu_m'][j])<1e-12 for j in [0,1])
 outward=(math.sin(t),math.cos(t));assert all(abs((zone[j][0]-zone[j-2][0])*outward[0]+(zone[j][1]-zone[j-2][1])*outward[1]-1.8)<1e-12 for j in [2,3])
 # Real _front_ring input stores the exact door centre; invert actual ENU ring
 # to prove its maximum outward path centres on the moved door, not old sash.
 ring=result['ground']['interior_local_enu_m'][0];inv=[((x-17.125)*math.cos(t)-(y+23.5)*math.sin(t),(x-17.125)*math.sin(t)+(y+23.5)*math.cos(t)-p.depth_m) for x,y in ring];deep=max(q[1] for q in inv);tips=[q[0] for q in inv if abs(q[1]-deep)<.03];assert tips and abs((min(tips)+max(tips))/2-door_cx)<.02
 olddoor=old['build']()['entrances'][0];assert olddoor['at_local_enu_m']!=d['at_local_enu_m']
 rotations.append({'rotation_deg':rotation,'native_door':d,'world_from_actual_builder_local_threshold':[e,n],'apron_path_midpoint_local_u':(min(tips)+max(tips))/2,'doorway_zone':zone,'old_centred_negative_detected':True})
# Missing/unknown/duplicate phase, stale geometry and malformed explicit control
# must fail closed, never fall back to a centred door or sc.form.
faults=[]
for phase in [None,'unknown']:
 bad={**sc,'phase':phase}
 try:new['front_doors'](bad)
 except ValueError:faults.append('selected phase '+str(phase))
 else:raise AssertionError('invalid selected phase accepted')
records[rec['id']]=copy.deepcopy(rec);records[rec['id']]['phases'].append(copy.deepcopy(ph))
try:new['front_doors'](sc)
except ValueError:faults.append('duplicate selected phase')
else:raise AssertionError('duplicate phase accepted')
records[rec['id']]=rec
bad=copy.deepcopy(sc);bad['footprint']['polygon'][1][0]+=.2
try:new['front_doors'](bad)
except ValueError:faults.append('stale selected footprint')
else:raise AssertionError('stale footprint accepted')
records[rec['id']]=copy.deepcopy(rec);records[rec['id']]['phases'][1]['form']['front_ground_layout']['value']=[True,.5,.78]
try:new['front_doors'](sc)
except params.ParamError:faults.append('invalid explicit control')
else:raise AssertionError('bad source control silently centred')
records[rec['id']]=rec
report={'scope':'CPU_REAL_FUNCTION_AST_NO_NATIVE_WRITES_NO_SCENE_TERRAIN_CLAIM','adapter_lineage':'existing T-2386-entry-site/check_consumer.py small AST extraction','legacy23_native_whole_document_and_doorway_zones_exact':True,'legacy23_fronts':len(legacyold['entrances']),'other_archetype_primary_branch_equal':other,'selected_source_phase_not_first_or_sc_form':True,'actual_flat_attributes_sidecar_no_form':True,'shared_builder_door_local_centre':door_cx,'actual_native_interval':actual,'old_centred_negative_interval':legacy_interval,'old_centred_negative_refused':True,'six_world_rotations_native_door_apron_zone':rotations,'fail_closed_cases':faults,'metadata':'generated_from adds source structures/params only when new declared layout is actually read; centred legacy whole-document exact','public_adoption_export_native_pipeline_browser_gate':'UNRUN','original_T2376':'OPEN/DIFFERS'}
actual_mesh=json.load(open(P/'CPU-PROOF.json'));mesh_door=next(row[1] for row in actual_mesh['ground_calls_after'] if row[0]=='_door');nd=report['actual_native_interval'][0][0];assert mesh_door[3:5]==[nd['u0'],nd['u1']];report['actual_accumulated_builder_door_interval_exact_native']={'u0':mesh_door[3],'u1':mesh_door[4],'plane_v':mesh_door[1]}
(P/'NATIVE-ACCESS-CPU-PROOF.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS native default23 whole-doc/clearance; other5primary branches; exact-phase selection;6rotation threshold/apron/zone; old-centre negative and5faults')
