"""Execute actual native recipe and real accumulator in one isolated small CPU context."""
import pathlib,sys,types,json,hashlib,pickle,ast
sys.dont_write_bytecode=True
R=pathlib.Path(sys.argv[1]);sys.path.insert(0,str(R/'generators'));sys.modules['bpy']=types.ModuleType('bpy')
import mesh_inputs
from archetypes import frame_tavern_params as par,frame_tavern as builder
from common.mesh import MeshBuilder
MeshBuilder.to_object=lambda self,mats=None:(self,list(mats or []));builder.simple_material=lambda n,*a,**kw:(n,a,kw)
rec=json.load(open(R/'record.json'));ph=rec['phases'][0];p=par.from_phase(ph,rec);mesh,mats=builder.build(p,'green_tree_tavern__frame_1833.glb');raw=(mesh.verts,mesh.faces,mesh.conf,mesh.mat_index,mesh.named,mats);doc=mesh_inputs.structure_inputs_doc(rec,ph)
assert isinstance(par.FrameTavernParams.resolved_front_ground_stations,property);assert not hasattr(par,'front_ground_stations');assert doc['params']['inferred']['resolved_front_ground_stations']==p.resolved_front_ground_stations
# The native entrance function consumes the same actual property value.
ns={'gbs':types.SimpleNamespace(STRUCTURES=R,_load=lambda path:rec,_front_edge=lambda poly:(0.,p.width_m,p.depth_m)),'_frame_tavern_params':par.from_phase,'TAVERN_DOOR_W_M':1.2};tree=ast.parse((R/'native_entrances.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='front_doors');exec(compile(ast.Module(body=[node],type_ignores=[]),'actual_native_front_doors','exec'),ns);native=ns['front_doors']({'id':rec['id'],'archetype':rec['archetype'],'phase':ph['id'],'footprint':ph['footprint'],'attributes':ph['form']})
result={'native_inputs_sha':mesh_inputs.structure_inputs_sha(rec,ph),'native_document':doc,'raw_sha':hashlib.sha256(pickle.dumps(raw,protocol=4)).hexdigest(),'actual_consumed_property_value':p.resolved_front_ground_stations,'native_front':native,'params_module_sha256':hashlib.sha256((R/'generators/archetypes/frame_tavern_params.py').read_bytes()).hexdigest(),'builder_sha256':hashlib.sha256((R/'generators/archetypes/frame_tavern.py').read_bytes()).hexdigest(),'vertices':len(mesh.verts),'faces':len(mesh.faces)}
(R/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
