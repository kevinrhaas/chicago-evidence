"""Exercise refusal using in-memory byte drift only; no canonical files modified."""
import pathlib,unittest.mock,runpy,sys,contextlib,io,json
P=pathlib.Path(__file__).parent;root=pathlib.Path('/tmp/chicago-log-integration/chicago/4d');original=pathlib.Path.read_bytes;cases=[]
for relative in ['generators/archetypes/frame_tavern_params.py','tools/generate_entrances.py','docs/LIBERTIES.md','data/reconstruction/name_pool_keys.json']:
 target=root/relative
 def drift(path,_target=target):
  data=original(path);return data+b'\n# controlled in-memory drift\n' if path==_target else data
 stream=io.StringIO();sys.argv=[str(P/'verify_preimages.py'),'--repo',str(root.parent.parent)];code=0
 with unittest.mock.patch.object(pathlib.Path,'read_bytes',drift),contextlib.redirect_stdout(stream):
  try:runpy.run_path(str(P/'verify_preimages.py'),run_name='__main__')
  except SystemExit as e:code=e.code
 assert code==1,(relative,code,stream.getvalue())
 result=json.loads(stream.getvalue());assert any(x.get('path')==relative for x in result['drift']);cases.append({'in_memory_drift':relative,'refused_code':code,'result':result})
(P/'GUARD-FAULT-PROOF.json').write_text(json.dumps({'canonical_writes':False,'cases':cases},indent=2)+'\n');print('PASS core/entrance-reader/latest-LIB/latest-name-key drift each refuses; no source writes')
