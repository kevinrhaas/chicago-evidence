import pathlib,json,hashlib,difflib,subprocess
P=pathlib.Path(__file__).parent;V2=pathlib.Path('/workspace/T2376-front-ground-proposal-v2-handed-access-7a-20261024');R=pathlib.Path('/tmp/chicago-log-integration');REF='7a58448ab207e67de14fb7d792ca01258ce8f748';A='chicago/4d/'
paths=[q.relative_to(V2/'candidate').as_posix() for q in sorted((V2/'candidate').rglob('*')) if q.is_file()];cand={p:(V2/'candidate'/p).read_text() for p in paths}
def replace(p,a,b):
 assert cand[p].count(a)==1,(p,a);cand[p]=cand[p].replace(a,b,1)
pp='generators/archetypes/frame_tavern_params.py';bp='generators/archetypes/frame_tavern.py';ep='tools/generate_entrances.py';tp='tools/test_frame_tavern_picture_features.py';rp='data/structures/green_tree_tavern.json';dp='docs/RESEARCH/green_tree_tavern.md'
start=cand[pp].index('def front_ground_stations(');end=cand[pp].index('def from_phase(',start);cand[pp]=cand[pp][:start]+cand[pp][end:]
prop='''    @property
    def resolved_front_ground_stations(self) -> tuple[float, tuple[float, float]]:
        """Actual local-u centres consumed by mesh and native primary access.

        Existing mesh_inputs hashes all dataclass property VALUES. Keeping the
        geometry arithmetic here makes a station change a real recipe change;
        this is not a hash-only proxy. No plain params helper can move the mesh.
        Exterior +y reverses screen order, so low-u door precedes the local sash.
        Default door applies to all tavern schemes; sash only to gable_front.
        """
        if self.front_ground_layout is None:
            return self.width_m / 2, (self.width_m * .22, self.width_m * .78)
        door, sash_a, sash_b = self.front_ground_layout
        return self.width_m * door, (self.width_m * sash_a, self.width_m * sash_b)


'''
replace(pp,'def _board_lay(recon: dict) -> float:',prop+'def _board_lay(recon: dict) -> float:')
replace(bp,'from archetypes.frame_tavern_params import FrameTavernParams, front_ground_stations  # noqa: E402','from archetypes.frame_tavern_params import FrameTavernParams  # noqa: E402')
replace(bp,'door_cx, ground_sash_centres = front_ground_stations(params)','door_cx, ground_sash_centres = params.resolved_front_ground_stations')
replace(ep,'''from archetypes.frame_tavern_params import (  # noqa: E402
    from_phase as _frame_tavern_params, front_ground_stations as _frame_front_ground_stations,
)''','from archetypes.frame_tavern_params import from_phase as _frame_tavern_params  # noqa: E402')
replace(ep,'c, _sash = _frame_front_ground_stations(params)','c, _sash = params.resolved_front_ground_stations')
cand[ep]=cand[ep].replace('shared front_ground_stations helper','shared resolved_front_ground_stations property').replace('frame_tavern.front_ground_stations (selected phase)','frame_tavern.resolved_front_ground_stations (selected phase)')
cand[tp]=cand[tp].replace('        from archetypes.frame_tavern_params import front_ground_stations\n','');replace(tp,'              "_frame_front_ground_stations": front_ground_stations,\n','');replace(tp,'c, _ = front_ground_stations(p)','c, _ = p.resolved_front_ground_stations')
# Protect the existing native recipe property enumeration without changing it.
needle='    def test_front_ground_access_reads_exact_phase_not_sidecar_form(self):'
addition='''    def test_front_ground_actual_geometry_stations_are_native_hashed_property(self):
        from mesh_inputs import _params_doc
        _, _, p = record_params("green_tree_tavern", "frame_1833")
        self.assertIsInstance(FrameTavernParams.resolved_front_ground_stations, property)
        self.assertEqual(_params_doc(p)["inferred"]["resolved_front_ground_stations"],
                         p.resolved_front_ground_stations)
        self.assertEqual(p.resolved_front_ground_stations,
                         (p.width_m*.20, (p.width_m*.50, p.width_m*.78)))

'''
replace(tp,needle,addition+needle)
rec=json.loads(cand[rp]);note=rec['phases'][0]['form']['front_ground_layout']['note'];note=note.replace('same pure door-centre helper','same pure resolved_front_ground_stations dataclass property (whose actual values are covered by the existing native mesh recipe)');rec['phases'][0]['form']['front_ground_layout']['note']=note;cand[rp]=json.dumps(rec,indent=2,ensure_ascii=False)+'\n'
cand[dp]=cand[dp].replace('shared pure `front_ground_stations` helper','shared pure `resolved_front_ground_stations` dataclass property')
cand[dp]+='\nThe mesh directly consumes the resolved dataclass property value, already hashed\nby the native recipe. There is no separate plain helper arithmetic or phantom\nchecksum field; source calculations, actual geometry and native access share it.\n'
for p,s in cand.items():(P/'candidate'/p).write_text(s)
(P/'proposal.patch').write_text(''.join(''.join(difflib.unified_diff((P/'baseline'/p).read_text().splitlines(True),cand[p].splitlines(True),fromfile='a/'+A+p,tofile='b/'+A+p)) for p in paths))
# Exact existing native recipe/pin copied into SMALL CPU dependency context.
g=json.load(open(V2/'GUARDS.json'))
for name in ['mesh_inputs.py','code_inputs.py','emit.py','blender.pin']:
 path='generators/'+name;b=subprocess.check_output(['git','-C',str(R),'show',REF+':'+A+path]);q=P/'cpu-deps'/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);g['paths'][path]={'committed7a_sha256':hashlib.sha256(b).hexdigest(),'observed_live_sha256':hashlib.sha256((R/A/path).read_bytes()).hexdigest()}
(P/'GUARDS.json').write_text(json.dumps(g,indent=2)+'\n');print('V3 PREPARED consumed hashed property; existing mesh_inputs unchanged; six paths')
