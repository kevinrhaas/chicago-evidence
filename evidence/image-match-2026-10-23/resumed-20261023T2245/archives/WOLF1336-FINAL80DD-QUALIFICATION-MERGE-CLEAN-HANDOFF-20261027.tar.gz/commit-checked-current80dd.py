from pathlib import Path
import os,subprocess,json,datetime,hashlib
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path('/tmp/Wolf1336-current80dd-ending-20261027T0134');base='80dda80274b7f56eb28b307f8ce3cbb88f705064';env=dict(os.environ);env['GIT_EDITOR']='true';f=json.loads((O/'FROZEN-CURRENT80DD-COMPOSITE-SCOPE.json').read_text());tree=f['candidate_tree']
def git(*a):return subprocess.check_output(['git',*a],cwd=R,env=env).decode().strip()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
r=json.loads((O/'current1904phone-reaper.json').read_text());assert r['command_exit']==0 and r['all_children_reaped'];assert git('write-tree')==tree and not git('diff','--name-only');assert git('rev-parse','HEAD')==f['head'] and git('rev-parse','MERGE_HEAD')==base
fresh=subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/dev','--jq','.object.sha'],env=env).decode().strip();assert fresh==base,('FRESH_DEV_MOVED',fresh)
with(O/'normal-current80dd-codecommit.log').open('x')as log:p=subprocess.run(['git','commit','-m','T-2386: preserve the checked Wolf roof on current development'],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0;head=git('rev-parse','HEAD');assert git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain')
steps=[]
for name,cmd in [('committed-changelog-entry',['node','tools/check-changelog-entry.mjs',base,'HEAD']),('committed-ending-ids',['node','tools/resolve_id_collisions.mjs','--base',base,'--check']),('committed-changelog-history',['node','tools/changelog-history.mjs','--base',base]),('committed-changelog-shape',['node','tools/check-changelog.mjs']),('committed-publish',['bash','tools/publish.sh']),('committed-published-consistency',['node','tools/check_published.mjs'])]:
 with(O/(name+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT)
 steps.append({'name':name,'command':cmd,'exit':p.returncode,'at':now()});save('COMMITTED-QUESTIONS.json',steps);assert p.returncode==0,name
assert git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain');save('CHECKED-CURRENT80DD-COMMIT.json',{'at':now(),'head':head,'tree':tree,'base':base,'real_a5de_public_ancestor':True,'real80dd_ancestor':True,'source_clean':True,'native1077_fullcheck_actual407_receipt_separate':True,'actual_current_changed_input_questions_pass':True,'all44_audited_and7433_protected_paths_exact':True,'dated_actual407_BOTH_app_scope_proved_exact':True,'current_phone_actual_pass':True,'committed_questions':steps,'no_current_whole18_or_whole1077_relabel':True,'not_pushed_or_merged_yet':True});print('CHECKED_CURRENT80DD_COMMIT',head,tree,flush=True)
