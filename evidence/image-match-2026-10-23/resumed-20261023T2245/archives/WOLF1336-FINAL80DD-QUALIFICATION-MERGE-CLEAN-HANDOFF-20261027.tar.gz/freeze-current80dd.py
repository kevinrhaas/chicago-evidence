from pathlib import Path
import os,subprocess,json,hashlib,datetime
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path('/tmp/Wolf1336-current80dd-ending-20261027T0134');old=Path('/tmp/Wolf1336-currentMary-ending-20261027T0045');base='80dda80274b7f56eb28b307f8ce3cbb88f705064';dated='a5de30c2005e778bad1d8f5e6d1996b539808534';env=dict(os.environ)
def git(*a):return subprocess.check_output(['git',*a],cwd=R,env=env)
def sha(b):return hashlib.sha256(b).hexdigest()
assert json.loads((O/'NATIVE-RESULT.json').read_text())['all44_audited'];assert all(r['exit']==0 for r in json.loads((O/'CURRENT-NATIVE-QUESTIONS.json').read_text()))
assert git('rev-parse','HEAD').decode().strip()==dated;assert git('rev-parse','MERGE_HEAD').decode().strip()==base;assert not git('diff','--name-only','--diff-filter=U').strip()
subprocess.check_call(['git','add','-u'],cwd=R,env=env);assert not git('diff','--name-only').strip();tree=git('write-tree').decode().strip()
want=set(git('diff','--name-only','407e4c730c818c817cf0e38b24550d8d4bee0394',dated).decode().splitlines());actual=set(git('diff','--name-only',base,tree).decode().splitlines());assert want==actual,{'missing':list(want-actual),'extra':list(actual-want)}
rows=[]
for row in json.loads((old/'current-app/SOURCE-BINDINGS.json').read_text())['paths']:
 p=Path(row['path'])
 if str(p).endswith('/data/liberties.json'):continue
 digest=sha(p.read_bytes());assert digest==row['sha256'],str(p);rows.append({'path':str(p.relative_to(R)),'sha256':digest,'byte_exact_dated407_app_input':True})
oldlib=json.loads(git('show',dated+':chicago/4d/data/liberties.json'));cur=json.loads((A/'data/liberties.json').read_text());librows={}
for key in ['names','liberties']:
 relevant=lambda x:isinstance(x,dict)and('wolf_point_tavern' in json.dumps(x)or'L-wolf-point-roof-tone-2386' in json.dumps(x))
 a=[x for x in oldlib[key]if relevant(x)];b=[x for x in cur[key]if relevant(x)];assert a==b,key;librows[key]={'rows':len(a),'canonical_sha256':sha(json.dumps(a,sort_keys=True,separators=(',',':')).encode()),'all_relevant_values_equal':True}
for path in ['chicago/4d/data/sources/blanchard_shober_1867_wolf_point.json','chicago/4d/data/sidecars/1835/sources/blanchard_shober_1867_wolf_point.json']:
 b=(R/path).read_bytes();assert b==git('show',dated+':'+path);rows.append({'path':path,'sha256':sha(b),'byte_exact_dated407_source_credit_input':True})
changed=git('diff','--name-only',dated,tree).decode().splitlines();render=[p for p in changed if p.startswith('chicago/4d/renderers/web/')];assert render==['chicago/4d/renderers/web/js/changelog.js'],render
oldphysical=[p for p in changed if p.startswith('chicago/4d/data/structures/')or(p.startswith('chicago/4d/data/sidecars/1835/')and'/sources/'not in p)];assert oldphysical==['chicago/4d/data/structures/dent_house_1823_prairie.json'],oldphysical
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CURRENT80DD_FROZEN_NATIVE_CHANGED_INPUTS_PASS_WITH_EXACT_DATED407_WOLF_APP_SCOPE','base':base,'head':dated,'merge_head':base,'candidate_tree':tree,'own_diff_paths':sorted(actual),'own_diff_matches_checked407_exact_pathset':True,'dated407_app_tree':'2a3d06495d73fc36b40458b093db7d67f6784fd3','dated407_app_actual_BOTH_PASS':True,'current_app_input_byte_guards':rows,'relevant_compiled_liberty_rows':librows,'all_renderer_code_styles_except_folded_changelog_exact':True,'no1835_physical_change_vs_dated407':True,'all44_actual_native_audit_pass':True,'incoming1351_exact_native_CI_gate_success_recorded':True,'current_phone_pending':True,'no_current_whole18_or_relabelled407_fullcheck_claim':True};(O/'FROZEN-CURRENT80DD-COMPOSITE-SCOPE.json').write_text(json.dumps(result,indent=2)+'\n');(O/'current80dd-Wolf-full.binary.patch').write_bytes(git('diff','--binary',base,tree));print('FROZEN_CURRENT80DD',tree,len(actual),flush=True)
