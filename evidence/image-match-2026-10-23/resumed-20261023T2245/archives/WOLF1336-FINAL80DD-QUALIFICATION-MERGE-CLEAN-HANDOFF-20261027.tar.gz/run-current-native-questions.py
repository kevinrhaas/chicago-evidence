from pathlib import Path
import os,subprocess,json,datetime,concurrent.futures,time
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path('/tmp/Wolf1336-current80dd-ending-20261027T0134');base='80dda80274b7f56eb28b307f8ce3cbb88f705064';env=dict(os.environ);env.update(C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',C4D_RULINGS_BASE=base,CHECK_JOBS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PW_EXECUTABLE='/usr/bin/chromium');os.sched_setaffinity(0,{0,1,3,4})
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert json.loads((O/'NATIVE-RESULT.json').read_text())['all44_audited']
commands=[('current-K01-all-emissions',['python3','generators/k01_emit.py','--check']),('current-all-record-validation',['python3','tools/validate.py','--all']),('current-entrance-kit',['python3','tools/check_entrance_kit.py','--check']),('current-entrance-refusals',['python3','tools/check_entrance_kit.py','--self-test']),('current-image-gate',['node','tools/image_gate.mjs','--check']),('current-liberties',['python3','tools/compile_liberties.py','--check']),('current-source-use',['python3','tools/compile_source_use.py','--check']),('current-derived-manifest',['node','tools/rederive.mjs','--check']),('current-published-consistency',['node','tools/check_published.mjs']),('current-rulings-history',['python3','tools/check_rulings_not_lost.py']),('current-changelog-history',['node','tools/changelog-history.mjs','--base',base]),('current-changelog-shape',['node','tools/check-changelog.mjs']),('current-ending-ids',['node','tools/resolve_id_collisions.mjs','--base',base,'--check'])]
def run(item):
 name,cmd=item;t=time.monotonic();print('START',name,now(),flush=True)
 with(O/(name+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit':p.returncode,'seconds':round(time.monotonic()-t,3),'at':now()};print('CLOSED',name,p.returncode,flush=True);return row
# All readers; only the owning native sequence writes and it has already reaped.
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:rows=list(pool.map(run,commands))
(O/'CURRENT-NATIVE-QUESTIONS.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(r['exit']==0 for r in rows),[r for r in rows if r['exit']]
print('CURRENT80DD_CHANGED_INPUT_NATIVE_QUESTIONS_PASS',flush=True)
