from pathlib import Path
import os,subprocess,json,datetime,time,hashlib,zipfile,gzip,io,xml.etree.ElementTree as ET,shutil
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path('/tmp/Wolf1336-current80dd-ending-20261027T0134');incoming='80dda80274b7f56eb28b307f8ce3cbb88f705064';head='a5de30c2005e778bad1d8f5e6d1996b539808534';merge='80dda80274b7f56eb28b307f8ce3cbb88f705064';os.sched_setaffinity(0,{0,1,3,4});env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(PYTHONPATH='/workspace/shared/python',NODE_PATH='/workspace/shared/node/node_modules',PW_EXECUTABLE='/usr/bin/chromium',TMPDIR='/tmp/Wolf1336-current80dd-native-tmp-20261027',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',CHECK_JOBS='4',C4D_RULINGS_BASE=incoming);Path(env['TMPDIR']).mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=R,env=env)
def save(name,value):(O/name).write_text(json.dumps(value,indent=2)+'\n')
def sha(data):return hashlib.sha256(data).hexdigest()
print('START sole copy-heavy Wolf currentMary/currented250 native resolver after dated407appfullyreaped; sole nativecopy.',flush=True)
assert git('rev-parse','HEAD').decode().strip()==head;assert git('rev-parse','MERGE_HEAD').decode().strip()==merge
assert shutil.disk_usage(env['TMPDIR']).free>=1800000000
protected=json.loads((O/'PROTECTED-AUTHORED-MODELS-BEFORE-NATIVE.json').read_text())
def check_protected():
 bad=[]
 for path,digest in protected.items():
  f=R/path;data=os.readlink(f).encode() if f.is_symlink() else f.read_bytes()
  if sha(data)!=digest:bad.append(path)
 assert not bad,bad
check_protected();steps=[]
def command(name,cmd):
 print('START',name,now(),flush=True)
 with(O/(name+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit':p.returncode,'closed_at':now()};steps.append(row);save('NATIVE-STEPS.json',steps);print('CLOSED',name,p.returncode,now(),flush=True);assert p.returncode==0,(name,p.returncode)
command('native-resolve',['node','tools/rederive.mjs','--resolve']);assert not git('diff','--name-only','--diff-filter=U').strip();check_protected()
def xlsx(data):
 with zipfile.ZipFile(io.BytesIO(data))as archive:
  result={}
  for name in archive.namelist():
   value=archive.read(name)
   if name.endswith(('.xml','.rels')):
    root=ET.fromstring(value)
    if name=='docProps/core.xml':
     for element in list(root):
      if element.tag=='{http://purl.org/dc/terms/}modified':root.remove(element)
    result[name]=ET.canonicalize(ET.tostring(root,encoding='unicode'))
   else:result[name]=value.hex()
  return result
def audit44(phase):
 rows=[];artifacts=json.loads((O/'ALL44-INCOMING-METADATA.json').read_text());known={row['path']for row in artifacts}
 for row in artifacts:
  path=row['path'];f=R/path;actual=f.read_bytes();before=git('show',incoming+':'+path);equal=actual==before;kind='BYTE_EXACT'
  if not equal:
   raw=O/('raw-regenerated-artifacts-'+phase)/path;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_bytes(actual)
   if path.endswith('.xlsx'):equal=xlsx(actual)==xlsx(before);kind='ALL_ZIP_MEMBERS_C14N_EXCEPT_CORE_MODIFIED'
   elif path.endswith('.gz'):
    equal=gzip.decompress(actual)==gzip.decompress(before);kind='GZIP_DECOMPRESSED_BYTES'
    if not equal:
     try:equal=json.loads(gzip.decompress(actual))==json.loads(gzip.decompress(before));kind='GZIP_JSON_ALL_FIELDS'
     except(ValueError,UnicodeError):pass
   if equal:f.write_bytes(before)
  rows.append({'path':path,'regenerated_sha256':sha(actual),'incoming_sha256':sha(before),'comparison':kind,'equal':equal,'restored_serialization_only':actual!=before and equal})
 save('ALL44-NATIVE-AUDIT-'+phase+'.json',rows);assert len(rows)==44 and all(row['equal']for row in rows)
 return rows
rows=audit44('after-resolve');known={row['path']for row in rows}
changed=git('diff','--name-only',incoming).decode().splitlines();unexpected=[p for p in changed if (p.endswith(('.xlsx','.gz'))or not p.startswith('chicago/4d/'))and p not in known];assert not unexpected,unexpected
command('native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']);audit44('after-package');command('native-publish',['bash','tools/publish.sh']);check_protected();assert not git('diff','--name-only','--diff-filter=U').strip()
result={'at':now(),'status':'WOLF_CURRENTDEV_OWNING_RESOLUTION_ALL44_PACKAGE_PUBLISH_PASS','head':head,'incoming':incoming,'cpu_affinity':[0,1,3,4],'protected_paths_exact':len(protected),'all44_audited':True,'steps':steps,'no_new_Wolf_geometry_API_or_camera':True,'genuine_public0d17_ancestry_preserved':True,'startup_tmp_floor_bytes':1800000000,'dated407full3_and_app_kept_separate':True,'current80dd_remaining_native_questions_and_phone_pending':True};save('NATIVE-RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
