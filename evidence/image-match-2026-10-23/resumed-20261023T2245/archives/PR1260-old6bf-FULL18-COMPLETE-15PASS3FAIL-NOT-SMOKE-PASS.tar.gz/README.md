COMPLETE18-RUN old6bf PR1260 SMOKE EXECUTION:15SUCCESS,3FAILURES. THIS IS NOT A FULL SMOKE PASS.

Bothmobile/desktop ninegroups coverall15parts. All18actualcheckout6bf,requestedviewport/stage,terminaljobconclusions andsummarycounts verified fromrawlogs. All18reportzero pageerrors.1662passedchecks+3failedchecks acrossgroups (boot/sharedchecks repeated;notuniquetestcount).

Desktop/mobile3-4 eachfailonlyWolfwholebbox11m vsdocumentedwall2.6m (134/1desktop,137/1mobile). Desktop14failsonly1904spawn4,600,491triangles vsunchanged4,600,000budget (139/1). Remaining15groupsPASS includingdesktop13(160/0). TheseoldFAILS remainunaltered. No baselinemismatch,signhypothesis orincoming721triangleKimballreduction waives them. Actualnewheadproofrequiredafterrootremediation/reconciliation.

Hostedgate120744672009 actual1060/383PASS atca5a27aa2=6bf+026ace rawlogincluded. PR1260stillold6bf/dirtyagainstnewdev8e5aat03:00snapshot. No movingframesdispatch/checkimplied; PRdiffdidnottouchitsfilter.

OriginalrequestJSONsareprovenancenotresults;COMPLETE_RESULTS andrawjoblogsareactualexecutionproof. No sourcewriters/fetch/lap/merge/cancel/redispatch/browser/heavyjobs bymonitor. Rootownsfinalapproval andnewheadvalidation.
