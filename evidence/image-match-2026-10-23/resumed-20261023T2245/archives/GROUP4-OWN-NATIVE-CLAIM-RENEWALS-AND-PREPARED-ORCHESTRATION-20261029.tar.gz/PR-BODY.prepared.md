Miller now has the pictured low wing beside its taller range, a lower cabin roof, three upper lights and the short ridge flue. Hogan’s store has horizontal courses on the pictured end gable and its projecting chimney cap. St Mary’s five front sash windows sit higher beneath the frieze. The lighthouse retains its physical model and gains the credited Castelnau reference on its card.

The four canonical comparisons pass the visitor-visible stopping rule. The dossiers distinguish genuinely pictured features from reconstructed dimensions, conflicting drawings, cropped details and unresolved publication credits. Existing image-host and source rows are preserved entry by entry.

Validation pending final execution: current accepted-parent integration; owning capacity, entrance, parcel and metadata rebuild; all 44 binary-output audits; native package and published mirror; phone and desktop published checks; complete three-question preflight. The PR will record only the actual results before it is opened.

This is one checked final four-ticket unit, partitioned into one commit per original ticket. Shared producer and generated dependencies are verified on the complete final working tree; the intermediate commit trees are not separately represented as passed.

Original tickets: T-2381, T-2377, T-2384, T-2373.
