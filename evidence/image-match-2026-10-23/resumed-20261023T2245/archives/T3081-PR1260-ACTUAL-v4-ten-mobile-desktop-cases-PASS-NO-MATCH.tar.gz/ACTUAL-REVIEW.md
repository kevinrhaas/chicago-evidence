# Ten actual published app cases — PASS, not an image-match verdict

All five targets passed actual mobile390×780/light and desktop1280×800/full checks at PR1260 head `6bf9d0e91fef27dedb9d364132e290706dd27609`. Durable orchestration exit0 ended2026-10-24T02:11:43UTC. The normal publisher had already completed at that head with source clean; this retry verified `site/4d/build.json`6bf and normal read-only `check_published.mjs` exit0 before reusing it. The source working tree remained clean at completion. Each of the ten native browser/context/server instances closed.

Every case bound the actual HTTP-loaded compressed GLB response to the current source web derivative and published copy, selected the expected phase, read positive live instance bounds/placement/feet, and passed native stand collision and detail budget. All page/HTTP/failed-request/cleanup errors are zero, with no categorization exemptions. Declared entries equal authored expected stations, widths and outward bearings: school1.20m primary; Cobweb1.04m; Miller1.10m; Carpenter1.04m; Wolf two0.90m primary/+X entries at distinct east/south bearings90/180deg.

All ten native-model/Photos/Sources screenshot triples were directly inspected (30 actual PNGs). Four targets carry one credited link-only picture each, joined to their published picture rows; Cobweb shows the exact honest empty-Photos state because no accepted panorama-subject join exists. Sources retain each primary bibliographic citation/URL, including the school blog and archived link, Wau-Bun, the Blanchard/Shober lithograph and the Andreas plate. Link-only files were not invented as image tiles or fetched from their holders. The browser interaction verified the actual selected tabs, no horizontal overflow and explicit displayed credits.

Both viewports measured identical contact samples per target:

| Target | Maximum foot gap m | Minimum foot gap m | Actual local maxY m |
| --- | ---: | ---: | ---: |
| School | 0 | -0.10643 | 5.95628 |
| Cobweb | 0 | -0.04981 | 5.04980 |
| Miller | 0 | -0.01352 | 8.45904 |
| Carpenter | 0 | -0.00247 | 5.03233 |
| Wolf | 0 | -0.19703 | 10.60544 |

The maximum-gap check retains the native0.15m hover ceiling; burial is reported, not redefined as an allowance. These are live wall-foot samples and exterior entry consumers, not every prop's full volume or walk-through interiors. Cobweb's compressed maxY5.04980m is consistent with its newly authored reconstructed5.05m head.

The exact14 retained review IDs/messages agree with live registry flags in all cases. All raw legacy messages are kept. AGENTS.md's owner ruling2026-10-16 says these flags and explanatory prose remain but **do not block a scene from being marked released**. The legacy loader wording is evidence, not a new consultation permission or release-denial requirement. Direct desktop Cobweb review also shows an existing floating-popup sentence “Held pending consultation… stops there until… consulted”; that stale UI wording is recorded for root follow-up and was not changed here.

Native framing limits are preserved: foreground grass partially crosses Cobweb, and Wolf's route-safe stand across the river makes the view's ahead label resolve Green Tree Tavern; nearby building/wagon/grass limit the visible target. Passing asset/bounds/entry/contact checks do not certify that original Wolf screenshot as an unobstructed view. Root separately authorized a bounded normal-native fly supplement outside this packet, with no hidden scene elements; those future results are not claimed here.

No data/asset/flag/source/reference-camera change, Blender export, source-photo comparison, accepted camera, image-match verdict or original ticket closure occurred in this batch. Image gates remain open; this targeted application PASS is separate from the full smoke gate. Frozen QA v4 manifest is `8ba6e0f8966e5b2273798708caea9d28477eb3ba6cb8357fadb111703bb7180c`; failed-v3 evidence remains separately preserved.
