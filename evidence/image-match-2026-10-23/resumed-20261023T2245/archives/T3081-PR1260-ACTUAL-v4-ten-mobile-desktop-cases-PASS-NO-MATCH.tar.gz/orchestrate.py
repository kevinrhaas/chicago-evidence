from pathlib import Path
import os,subprocess,json,datetime,sys,hashlib
ROOT=Path('/workspace/T3081-PR1260-published-qa-v4')
APP=Path('/tmp/chicago-log-integration/chicago/4d')
EXPECTED='6bf9d0e91fef27dedb9d364132e290706dd27609'
STATUS=ROOT/'ORCHESTRATION.json'
if STATUS.exists():raise SystemExit('Refusing existing durable orchestration status')
env=os.environ.copy();env['TMPDIR']='/workspace/tmp-t3081';env['PW_EXECUTABLE']='/usr/bin/chromium';env['PATH']='/workspace/shared/tools/usr/bin:'+env.get('PATH','')
Path(env['TMPDIR']).mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
r={'status':'RUNNING','stage':'prechecks','pid':os.getpid(),'started_at':now(),'expected_head':EXPECTED,'app':str(APP),'output':str(ROOT),'authorized_scope':'Root renewed exclusive heavy grant: exact14 native review-notice correction, read-only mirror verification, then ten sequential published cases only. Reuse already published6bf mirror; no publisher, Blender, full gate, source/native writers or photo comparisons.','helper_manifest_sha256':'8ba6e0f8966e5b2273798708caea9d28477eb3ba6cb8357fadb111703bb7180c','stages':[]}
def save():
 tmp=STATUS.with_suffix('.next.json');tmp.write_text(json.dumps(r,indent=2)+'\n');tmp.replace(STATUS)
def readgit(*args):return subprocess.check_output(['git','-C',str(APP),*args],text=True,env=env)
def stage(name,cmd,log):
 r['stage']=name;row={'name':name,'command':cmd,'started_at':now(),'log':str(ROOT/log)};r['stages'].append(row);save()
 with (ROOT/log).open('w') as f:
  p=subprocess.Popen(cmd,cwd=APP,env=env,stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();code=p.wait()
 row['exit_code']=code;row['ended_at']=now();save()
 if code:raise RuntimeError(name+' exited '+str(code))
try:
 head=readgit('rev-parse','HEAD').strip();before=readgit('status','--porcelain');r['actual_head']=head;r['source_status_before']=before;save()
 if head!=EXPECTED or before:raise RuntimeError('Expected exact clean PR1260 source before publish')
 mirror=APP/'../../site/4d/build.json';build=json.loads(mirror.read_text());r['mirror_build']=build;r['mirror_build_sha256']=hashlib.sha256(mirror.read_bytes()).hexdigest();save()
 if build['version']!=EXPECTED[:9]:raise RuntimeError('Mirror build metadata differs from exact6bf head')
 stage('verify-published-mirror',['node','tools/check_published.mjs'],'mirror-verification.log')
 after=readgit('status','--porcelain');r['source_status_after_mirror_verification']=after;save()
 if after:raise RuntimeError('Source changed during mirror verification; stop before browser')
 if readgit('rev-parse','HEAD').strip()!=EXPECTED:raise RuntimeError('HEAD changed during mirror verification')
 stage('ten-published-cases',['bash','/tmp/T3081-published-qa-v4-20261024/run-sequential.sh','published','--execute-after-root-grant',str(ROOT)],'published-batch.log')
 rows=[]
 for vp in ['mobile','desktop']:
  for id in ['chappel_infant_school','cobweb_castle','miller_house','philo_carpenter_log_shop','wolf_point_tavern']:
   f=ROOT/'published'/f'{vp}-{id}'/'QA-RESULT.json';j=json.loads(f.read_text());rows.append({'viewport':vp,'id':id,'status':j['status'],'receipt':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 r['case_receipts']=rows
 if len(rows)!=10 or any(j['status']!='PASS_TARGETED_APP_QA_NOT_IMAGE_MATCH' for j in rows):raise RuntimeError('Not all ten actual receipts pass')
 r['source_status_final']=readgit('status','--porcelain')
 if r['source_status_final']:raise RuntimeError('Source changed during browser QA')
 r['status']='PASS_TEN_TARGETED_PUBLISHED_CASES_NOT_IMAGE_MATCH';r['stage']='finished';r['exit_code']=0
except BaseException as e:
 r['status']='FAIL_STOPPED';r['error']=str(e);r['exit_code']=1
finally:
 r['ended_at']=now();save()
print(json.dumps(r,indent=2));sys.exit(r['exit_code'])
