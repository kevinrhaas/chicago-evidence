# T-3081 five-model application and picture review — prepared only

This package prepares reproducible QA of the upcoming official82 refresh. No Blender, browser, native publisher, full gate, fetch, new camera fit or canonical edit was run to prepare it. `PREPARE-ONLY.json` is the dry receipt; JavaScript syntax is checked only. The actual application runner remains unexecuted and may reveal integration or harness failures. Never describe this as passing application QA until its actual receipts and images have been inspected.

Targets are the infant school, Cobweb Castle, Miller House, Carpenter’s log shop and Wolf Point Tavern. `models.json` binds the five authored record hashes, native selected phase/master names, reconstructed source limits, primary bibliographic source and exact expected ground-entry stations/widths/bearings resolved from the authored phase with the native helper. These expectations do not come from old generated sidecars/aprons. The expected entry counts are1/1/1/1/2; Wolf’s second entry is a distinct +X side face and90degrees from its primary face. The metadata records architectural/source limits, not new historical claims.

## Actual native application QA, after root finishes all82 masters/web and the ordered native tail

The parent first finishes native re-derivation and its single-writer publish. Do not run another publisher from this child or race the build. Only execute after root assigns the shared browser slot. From any directory:

```sh
PW_EXECUTABLE=/usr/bin/chromium node /tmp/T3081-published-qa-20261023/qa-published.mjs \
  --app /tmp/chicago-log-integration/chicago/4d \
  --viewport mobile --ids chappel_infant_school,cobweb_castle \
  --out /tmp/log82-integration-evidence/qa-mobile-school-cobweb --execute

PW_EXECUTABLE=/usr/bin/chromium node /tmp/T3081-published-qa-20261023/qa-published.mjs \
  --viewport mobile --ids miller_house,philo_carpenter_log_shop \
  --out /tmp/log82-integration-evidence/qa-mobile-miller-carpenter --execute

PW_EXECUTABLE=/usr/bin/chromium node /tmp/T3081-published-qa-20261023/qa-published.mjs \
  --viewport mobile --ids wolf_point_tavern \
  --out /tmp/log82-integration-evidence/qa-mobile-wolf --execute
```

Repeat those three commands with `--viewport desktop` and distinct `qa-desktop-*` output paths for1280×800/full. Mobile is390×780/light. The split keeps individual foreground calls bounded and makes each case resumable; it does not weaken coverage. Do not run the parts concurrently on this machine. Without `--execute`, the same helper checks the authored-record hashes and prints planned paths/IDs without launching a browser.

The runner serves the real published `/walk/` app, enters through its ordinary welcome, uses native detail selection and native safe building framing, and records:

- Each expected web derivative’s hash equal to the published copy, plus the actual HTTP-loaded GLB response/hash and successful status. A sidecar or master alone is not counted as drawn evidence.
- Positive native registry/phase/asset, live rendered bounds, actual placement matrix and actual wall-foot samples. Wall feet are transformed through that live matrix and compared to the native terrain. The existing full-smoke0.15m hover threshold is retained; minimum burial is reported without inventing a new allowance. Full source/contact investigation remains a separate review.
- Actual native stand’s detail budget and whether the walker stands on blocked ground. This is outside framing, not a claim that solid-footprint cabins have walk-through interiors.
- Published native entrance list equal to authored expected primary/+X stations, widths and outward bearings. The prepared fixture cannot silently pass on old one-door Wolf output or old school1.04m width.
- Actual Inspect Photos and Sources tabs, every picture/link’s explicit credit, primary-source citation/link, no horizontal overflow, and screenshots of normal model/Photos/Sources. Link-only source records are allowed; unheld images are not invented as tiles. All page, failed-request and HTTP errors are preserved unfiltered and fail the targeted QA.

`QA-RESULT.json` is written even on failure, with exact failures, live data and screenshot paths. A passing targeted app receipt is not the whole published smoke gate and is never an image-match verdict. If the authored records changed before execution, the helper refuses its hash guard: review/update expectations deliberately rather than restoring an old record or bypassing the check. Changes to new meshes do not require changing these authored guards.

The parent’s normal gate already covers these native consumers. If a failure needs focused reproduction, these existing commands are available after the native tail; they write no new model:

```sh
cd /tmp/chicago-log-integration/chicago/4d
python3 tools/generate_entrances.py --check
python3 tools/measure_doorways.py --gate
python3 tools/check_structure_clearance.py
```

The last check also asks current yard goods/fences against occupied footprints. Keep Wolf’s concave-body/river/doorway clearance and its old four misplaced goods diagnostic explicit; regenerate through native writers, never hand-move or whitelist them. Foot samples and these point/plan consumers do not certify every prop’s three-dimensional mesh extent or every human motion.

## Actual same-camera source comparisons, separately assigned browser slot

`cameras/original/` holds verbatim existing research camera bytes with their original hashes. `cameras/portable/` changes only the source-image path to a package-local copy. Every numeric pose/lens/light/clip/group field is unchanged. Original source-image bytes are copied and hashed; no drawing pixels are used as model textures.

From the actual integration app, one case at a time:

```sh
cd /tmp/chicago-log-integration/chicago/4d
node tools/photo_match.mjs /tmp/T3081-published-qa-20261023/cameras/portable/chappel_infant_school.json --out /tmp/log82-integration-evidence/pictures/school
node tools/photo_match.mjs /tmp/T3081-published-qa-20261023/cameras/portable/cobweb_castle.json --out /tmp/log82-integration-evidence/pictures/cobweb
node tools/photo_match.mjs /tmp/T3081-published-qa-20261023/cameras/portable/miller_house.json --out /tmp/log82-integration-evidence/pictures/miller
node tools/photo_match.mjs /tmp/T3081-published-qa-20261023/cameras/portable/philo_carpenter_log_shop.json --out /tmp/log82-integration-evidence/pictures/carpenter
node tools/photo_match.mjs /tmp/T3081-published-qa-20261023/cameras/portable/wolf_point_tavern.json --out /tmp/log82-integration-evidence/pictures/wolf
```

These commands consume the official current masters at their native names; no preview substitution or old recipe hash is supplied. They write their research `.match.json` beside the package camera, and screenshots to the given external output. They do not enroll an accepted view. Carpenter’s camera deliberately anchors on the main Sauganash and includes the separately modeled shop as context: inspect both and preserve that camera/relative-placement uncertainty; the hotel is not a sixth changed target in this unit.

All five cameras remain provisional. Cobweb’s tiny panorama subject identity is unresolved. School’s artist/publication, subject identity, depicted date and metric framing remain unresolved; it is owner-approved attributed project use, not a public-domain finding or1835 occupant record. Miller/Wolf’s1867sheet depicts1833 and does not prove every1835 feature unchanged. Carpenter’s poorly constrained principal-point fit does not calibrate the annex independently. Historical “unrendered” wording inside some frozen camera notes predates later research trials; it does not certify the upcoming official master comparison.

Inspect every resulting full source/actual pair before recording `differs` and its remaining differences. No script in this package writes `matches`, closes an original ticket, upgrades a source’s rights or solves a camera. The original picture gates remain unfinished.
