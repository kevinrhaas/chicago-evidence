from pathlib import Path
import json,hashlib,subprocess,datetime,shutil
root=Path('/workspace/T3081-PR1260-five-photo-comparisons');bindings=json.loads((root/'INPUT-BINDINGS.json').read_text());status=json.loads((root/'RESUME-ORCHESTRATION.json').read_text());assert status['exit_code']==0 and len(status['closed_capture_ids'])==5
reviews={
'chappel_infant_school':{
 'visible_features':['The adopted dark recessed opening and horizontal front-gable courses are visible; the cap no longer reads as an unbroken roof-colour triangle.','The current master SHA is exactly the earlier closed front-gable trial fe73a03a…, so this official rerun retains that improvement rather than claiming a new geometry improvement.'],
 'differences':['The frontage is too broad in the provisional framing, and the left corner/window spread, roof/apex silhouette and crop do not align with the drawing.','Uniform regular logs/chink stripes, roof covering, window/door-case details, tone and chimney appearance differ from the ink drawing.','Source artist/publication, school/annex identity, depicted date and metric camera remain unresolved; absence of the drawing’s people/shore/canoes belongs to the isolated-render/context limit, not proof of scene-date occupants.']},
'cobweb_castle':{
 'visible_features':['The distant official model has a composed front/compound-roof silhouette and two raised outer heads, preserving the adopted connected-room reconstruction.','The heads are the new reconstructed5.05m choice; normal published app QA separately measured maxY5.04980m. This does not validate a source-picture height.'],
 'differences':['The panorama’s agency-house subject join is unresolved; its label does not independently calibrate this model, and no accepted source/camera relationship exists.','The unchanged provisional panorama camera leaves the model extremely small; detailed roof valleys, openings, log/cladding finish and silhouette cannot be certified from it.','Five-room arrangement, exact dimensions and1835 continuity remain reconstructed/inferred choices; no image-match acceptance is supported.']},
'miller_house':{
 'visible_features':['The frame upper storey over a log lower front is now clearly expressed, with vertical upper boarding, front openings and a differentiated lower log body.'],
 'differences':['The roof pitch/outline, front/side proportion and camera angle differ from the lithograph’s right-hand building.','The actual tall left chimney shaft/head is much more prominent than the lithograph; source chimney station/height/details remain different.','The side/rear log-wing silhouette and direction, opening proportions, roof covering, tones and source surface irregularity remain different; the1867 sheet depicts1833 and does not establish every1835 feature unchanged.']},
'philo_carpenter_log_shop':{
 'visible_features':['The grouped actual view includes the official log-shop master beside the separately selected Sauganash master in their current native scene relation.','A single continuous roof-piercing stack is visible on the log wing, rather than treating its shaft as disconnected from the roof.'],
 'differences':['The log wing is too large/high and differently positioned within the provisional principal-point/group fit compared with the engraving.','Log-wing roof/eave form, roof surface, masonry-stack shape, windows, door treatment and log joints differ from the drawing.','The unchanged hotel context also differs in roof/chimneys, window count/proportions, shutters, door and overall massing; it is a second bound group member, not a sixth changed target or an accepted hotel match.']},
'wolf_point_tavern':{
 'visible_features':['The physical L/two-gable body, recessed junction and separate door openings are readable, replacing the former rectangular-profile limitation.','Rounded log-course faces and the sign/staff structure remain in the official master; normal native supplemental views separately identify the L and both entry faces in context.'],
 'differences':['The provisional viewpoint, mass/roof proportions and projecting-wing silhouette do not align with the lithograph’s left-hand tavern.','Door/window sizes and treatment, roof covering/linework, chimney and sign details, colour/contrast and source irregular log appearance still differ.','Fine roof-surface relief is not established as matching by this small neutral distant capture; the1867 depiction of1833 does not prove1835 fabric unchanged.']}}
common='Native photo_match uses uncompressed master materials in an isolated neutral review scene/common grade plane. It does not load the shipped app’s full terrain/context/procedural wall/roof surface treatment. Colour, texture and lighting differences are not silently treated as fixed geometry, and this contract does not make a camera solved.'
ledger=[]
for c in bindings['cases']:
 id=c['id'];folder=root/'pictures'/id;native=folder/'MATCH-UNREVIEWED.json';rec=json.loads(native.read_text());assert rec['verdict']=='unreviewed'
 assert rec['camera_sha256']==c['camera_sha256'] and rec['photo_sha256']==c['source_sha256']
 body=reviews[id];rec['verdict']='differs';rec['differences']=[{'what':x,'status':'open'} for x in body['differences']]+[{'what':common,'status':'open'}]
 rec['_actual_review']={'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Directly inspected full source/actual side-by-side and byte-original actual PNG; no image pixels edited, no new capture/camera fit.','visible_adopted_features':body['visible_features'],'camera_unaccepted':True,'original_ticket_open':True,'scope':'Research-only staged comparison outside canonical reference_views; no accepted view, rights upgrade or image-match claim.'}
 text=json.dumps(rec,ensure_ascii=False,indent=2)+'\n';(folder/'REVIEWED-MATCH-DIFFERS.json').write_text(text)
 staged=root/'picture-inputs/cameras/portable'/f'{id}.match.json';staged.write_text(text)
 images={}
 for name in ['actual-native.png','source.jpg',id+'-side-by-side.jpg']:
  p=folder/name;images[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 ledger.append({'target':id,'verdict':'differs','camera_unaccepted':True,'original_ticket_open':True,'visible_adopted_features':body['visible_features'],'remaining_differences':body['differences'],'renderer_limits':common,'native_match_anchor':rec['structure_id'],'native_anchor_master_sha256':rec['glb_sha256'],'native_group_sha256':rec.get('group_sha256'),'camera_sha256':rec['camera_sha256'],'source_sha256':rec['photo_sha256'],'images':images,'native_unreviewed_match_sha256':hashlib.sha256(native.read_bytes()).hexdigest()})
clean=subprocess.check_output(['git','-C','/tmp/chicago-log-integration','status','--porcelain'],text=True);assert clean==''
result={'status':'CLOSED_FIVE_ACTUAL_COMPARISONS_ALL_DIFFERS','head':bindings['source_head'],'actual_native_capture_count':5,'native_capture_exit_codes':[0]*5,'first_preservation_exit':1,'preservation_correction':'External-only actual os.tmpdir path validation; no school recapture. Original failed status/log and all producer unreviewed records retained.','reviewed_case_count':5,'source_git_status_at_close':clean,'renderer_limits':common,'cases':ledger,'scope':'Only staged research match records changed to differs; canonical/source cameras/images/data/assets untouched, no accepted views, rights upgrades or original ticket closures.'}
(root/'ACTUAL-REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
# Keep the exact orchestration and path-only preservation correction with the actual packet.
copy=root/'orchestration-code';copy.mkdir(exist_ok=True)
for p in Path('/tmp/T3081-five-photo-orchestration-20261024').iterdir():
 if p.is_file():shutil.copyfile(p,copy/p.name)
print('Reviewed five pairs and actual PNGs: all differs, staged cameras unaccepted, canonical untouched, source clean.')
