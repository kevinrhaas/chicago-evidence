// LIGHT: retain native photo_match's byte-original bare PNG after a granted actual run.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import os from 'node:os';
const [cameraFile,output,logFile]=process.argv.slice(2);if(!cameraFile||!output||!logFile)throw Error('usage: preserve-picture.mjs camera output log');
const log=fs.readFileSync(logFile,'utf8'),tmpRoot=fs.realpathSync(os.tmpdir());
const candidates=log.split('\n').filter(l=>l.startsWith('  ')&&l.trim().endsWith('-render.png')).filter(l=>{const p=l.trim();return path.isAbsolute(p)&&path.dirname(p).startsWith(tmpRoot+path.sep+'photo-match-')&&path.basename(p)===path.basename(cameraFile,'.json')+'-render.png';});
if(candidates.length!==1)throw Error('Expected exactly one native bare PNG under actual TMPDIR');
const line=candidates[0];
if(!line)throw Error('Native byte-original bare PNG path missing from actual log');
const camera=JSON.parse(fs.readFileSync(cameraFile)),matchFile=cameraFile.replace(/\.json$/,'.match.json'),match=JSON.parse(fs.readFileSync(matchFile));
if(match.verdict!=='unreviewed')throw Error('Expected fresh unreviewed native match; inspect prior state');
const actual=path.join(output,'actual-native.png'),source=path.join(output,'source'+path.extname(camera.photo)),cameraCopy=path.join(output,'camera.json'),matchCopy=path.join(output,'MATCH-UNREVIEWED.json');
for(const f of [actual,source,cameraCopy,matchCopy])if(fs.existsSync(f))throw Error('Refusing overwrite: '+f);
fs.copyFileSync(line.trim(),actual);fs.copyFileSync(path.resolve(path.dirname(cameraFile),camera.photo),source);fs.copyFileSync(cameraFile,cameraCopy);fs.copyFileSync(matchFile,matchCopy);
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
if(sha(cameraCopy)!==match.camera_sha256||sha(source)!==match.photo_sha256)throw Error('Native camera/source binding mismatch');
fs.writeFileSync(path.join(output,'CAPTURE-RECEIPT.json'),JSON.stringify({status:'ACTUAL_CAPTURE_UNREVIEWED_NOT_MATCH',native_bare_png_path:line.trim(),actual_png_sha256:sha(actual),source_sha256:sha(source),camera_sha256:sha(cameraCopy),match_sha256:sha(matchCopy),native_match:match,limits:'Fresh native master capture with unchanged provisional framing. Requires full source/actual review; no accepted camera or matches claim. Original drawing credits and rights are unchanged.'},null,2)+'\n');
console.log('Preserved byte-original native bare PNG and source/camera/match bindings; unreviewed.');
