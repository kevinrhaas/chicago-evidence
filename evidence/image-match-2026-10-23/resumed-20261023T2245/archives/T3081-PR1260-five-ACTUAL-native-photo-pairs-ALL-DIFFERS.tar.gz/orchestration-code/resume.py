from pathlib import Path
import subprocess,os,json,datetime,sys,hashlib
ROOT=Path('/workspace/T3081-PR1260-five-photo-comparisons');APP=Path('/tmp/chicago-log-integration/chicago/4d');PRESERVE='/tmp/T3081-five-photo-orchestration-20261024/preserve-picture-tmpdir.mjs';STATUS=ROOT/'RESUME-ORCHESTRATION.json';EXPECTED='6bf9d0e91fef27dedb9d364132e290706dd27609'
if STATUS.exists():raise SystemExit('Refusing existing resume status')
env=os.environ.copy();env['TMPDIR']='/workspace/tmp-t3081';env['PW_EXECUTABLE']='/usr/bin/chromium';env['PATH']='/workspace/shared/tools/usr/bin:'+env.get('PATH','')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
r={'status':'RUNNING','pid':os.getpid(),'started_at':now(),'stage':'source-precheck','reason':'Frozen v3 preservation path regex expected /tmp but root requires TMPDIR=/workspace/tmp-t3081. Native school capture exit0 is reused; no recapture. External-only preservation path fix validates actual os.tmpdir and exact native basename. Original failed stage retained.','stages':[],'closed_capture_ids':[]}
def save():
 tmp=STATUS.with_suffix('.next.json');tmp.write_text(json.dumps(r,indent=2)+'\n');tmp.replace(STATUS)
def git(*a):return subprocess.check_output(['git','-C',str(APP),*a],text=True,env=env)
def stage(name,cmd):
 row={'name':name,'command':cmd,'started_at':now(),'log':str(ROOT/'logs'/f'{name}.log')};r['stage']=name;r['stages'].append(row);save()
 with Path(row['log']).open('w') as f:
  p=subprocess.Popen(cmd,cwd=APP,env=env,stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();code=p.wait()
 row['exit_code']=code;row['ended_at']=now();save()
 if code:raise RuntimeError(name+' exited '+str(code))
try:
 if git('rev-parse','HEAD').strip()!=EXPECTED or git('status','--porcelain'):raise RuntimeError('Exact clean6bf source required')
 first=json.loads((ROOT/'ORCHESTRATION-INITIAL-FAILED.json').read_text());cap=next(x for x in first['stages'] if x['name']=='capture-chappel_infant_school');assert cap['exit_code']==0
 bindings=json.loads((ROOT/'INPUT-BINDINGS.json').read_text())
 for c in bindings['cases']:
  id=c['id'];cam=ROOT/'picture-inputs/cameras/portable'/f'{id}.json';out=ROOT/'pictures'/id
  if id!='chappel_infant_school':stage('capture-'+id,['node','tools/photo_match.mjs',str(cam),'--out',str(out)])
  stage('preserve-tmpdir-'+id,['node',PRESERVE,str(cam),str(out),str(ROOT/'logs'/f'capture-{id}.log')])
  match=json.loads((out/'MATCH-UNREVIEWED.json').read_text());expected=c['native_group']['rendered_members']
  if len(expected)>1:
   if match.get('group_sha256')!=c['native_group']['group_sha256'] or match.get('rendered_members')!=expected:raise RuntimeError(id+': group binding drift')
  elif match['glb_sha256']!=expected[0]['glb_sha256']:raise RuntimeError(id+': master binding drift')
  if match['camera_sha256']!=c['camera_sha256'] or match['photo_sha256']!=c['source_sha256'] or match['verdict']!='unreviewed':raise RuntimeError(id+': native source/camera/verdict binding failure')
  r['closed_capture_ids'].append(id);save()
 r['source_status_after']=git('status','--porcelain')
 if r['source_status_after'] or git('rev-parse','HEAD').strip()!=EXPECTED:raise RuntimeError('Source drift during captures')
 r['status']='PASS_FIVE_ACTUAL_CAPTURES_UNREVIEWED_NOT_MATCHES';r['stage']='captures-finished';r['exit_code']=0
except BaseException as e:r['status']='FAIL_STOPPED';r['error']=str(e);r['exit_code']=1
finally:r['ended_at']=now();save()
print(json.dumps(r,indent=2));sys.exit(r['exit_code'])
