from pathlib import Path
import subprocess,os,json,datetime,hashlib,sys
ROOT=Path('/workspace/T3081-PR1260-five-photo-comparisons');APP=Path('/tmp/chicago-log-integration/chicago/4d');HELP=Path('/tmp/T3081-published-qa-v3-20261024');STATUS=ROOT/'ORCHESTRATION.json';EXPECTED='6bf9d0e91fef27dedb9d364132e290706dd27609'
if STATUS.exists():raise SystemExit('Refusing existing orchestration')
env=os.environ.copy();env['TMPDIR']='/workspace/tmp-t3081';env['PW_EXECUTABLE']='/usr/bin/chromium';env['PATH']='/workspace/shared/tools/usr/bin:'+env.get('PATH','')
ROOT.mkdir(exist_ok=True);(ROOT/'logs').mkdir(exist_ok=True);(ROOT/'pictures').mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
r={'status':'RUNNING','stage':'source-precheck','pid':os.getpid(),'started_at':now(),'expected_head':EXPECTED,'authorized_scope':'Root exclusive heavy grant: stage unchanged cameras/sources with v3 helper, verify bindings, five sequential normal native photo_match commands plus v3 preservation helper. No other browser/native/fullgate job, canonical edit or accepted view.','stages':[]}
def save():
 tmp=STATUS.with_suffix('.next.json');tmp.write_text(json.dumps(r,indent=2)+'\n');tmp.replace(STATUS)
def git(*args):return subprocess.check_output(['git','-C',str(APP),*args],text=True,env=env)
def stage(name,cmd):
 row={'name':name,'command':cmd,'started_at':now(),'log':str(ROOT/'logs'/f'{name}.log')};r['stage']=name;r['stages'].append(row);save()
 with Path(row['log']).open('w') as f:
  p=subprocess.Popen(cmd,cwd=APP,env=env,stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();code=p.wait()
 row['exit_code']=code;row['ended_at']=now();save()
 if code:raise RuntimeError(name+' exited '+str(code))
try:
 r['actual_head']=git('rev-parse','HEAD').strip();r['source_status_before']=git('status','--porcelain');save()
 if r['actual_head']!=EXPECTED or r['source_status_before']:raise RuntimeError('Expected exact clean6bf source')
 stage('stage-inputs',['node',str(HELP/'stage-pictures.mjs'),'--out',str(ROOT/'picture-inputs')])
 stage('verify-input-bindings',['node','/tmp/T3081-five-photo-orchestration-20261024/snapshot.mjs',str(ROOT)])
 bindings=json.loads((ROOT/'INPUT-BINDINGS.json').read_text())
 for c in bindings['cases']:
  id=c['id'];cam=ROOT/'picture-inputs'/'cameras/portable'/f'{id}.json';out=ROOT/'pictures'/id
  stage('capture-'+id,['node','tools/photo_match.mjs',str(cam),'--out',str(out)])
  stage('preserve-'+id,['node',str(HELP/'preserve-picture.mjs'),str(cam),str(out),str(ROOT/'logs'/f'capture-{id}.log')])
  match=json.loads((out/'MATCH-UNREVIEWED.json').read_text());expected=c['native_group']['rendered_members']
  # The native producer records all members only for its multi-structure camera.
  if len(expected)>1:
   if match.get('group_sha256')!=c['native_group']['group_sha256'] or match.get('rendered_members')!=expected:raise RuntimeError(id+': group binding drift')
  elif match['glb_sha256']!=expected[0]['glb_sha256']:raise RuntimeError(id+': selected master binding drift')
  if match['camera_sha256']!=c['camera_sha256'] or match['photo_sha256']!=c['source_sha256'] or match['verdict']!='unreviewed':raise RuntimeError(id+': native source/camera/verdict binding failure')
  r.setdefault('closed_capture_ids',[]).append(id);save()
 r['source_status_after']=git('status','--porcelain')
 if r['source_status_after'] or git('rev-parse','HEAD').strip()!=EXPECTED:raise RuntimeError('Source drift during captures')
 r['status']='PASS_FIVE_ACTUAL_CAPTURES_UNREVIEWED_NOT_MATCHES';r['stage']='captures-finished';r['exit_code']=0
except BaseException as e:r['status']='FAIL_STOPPED';r['error']=str(e);r['exit_code']=1
finally:r['ended_at']=now();save()
print(json.dumps(r,indent=2));sys.exit(r['exit_code'])
