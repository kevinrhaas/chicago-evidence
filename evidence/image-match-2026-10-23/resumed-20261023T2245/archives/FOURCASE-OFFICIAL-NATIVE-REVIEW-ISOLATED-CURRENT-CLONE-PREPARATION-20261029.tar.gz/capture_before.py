from pathlib import Path
import argparse,importlib.util,json,datetime,hashlib
P=argparse.ArgumentParser();P.add_argument('--output',required=True);a=P.parse_args();O=Path(a.output);O.mkdir(exist_ok=False)
sp=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
app=m.snapshot();m.SOURCE=Path('/workspace/isolated-gt-ticket-renewal-native-v4-20261029/repo');m.G=m.SOURCE/'.git';m.REPO='kevinrhaas/chicago-tickets';snapshot=m.snapshot();assert not snapshot['status']
ids=['T-2381','T-2373','T-2384','T-2377'];own={}
for n in ids:
 paths=list(m.SOURCE.glob('T-2250-2499/'+n+'-*'));assert len(paths)==1;b=paths[0].read_bytes();assert b'state: claimed\n'in b and b'pr: null\n'in b;own[str(paths[0].relative_to(m.SOURCE))]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
remote=m.api('git/ref/heads/main')['object']['sha'];compare=m.api('compare/'+snapshot['HEAD']+'...'+remote);assert compare['status']in {'ahead','identical'}
assert not set(own)&{r['filename']for r in compare.get('files',[])},'Ownrecords changed remotely; reread before closing'
(O/'BEFORE.json').write_text(json.dumps({'status':'READONLY_OFFICIAL_FOUR_REVIEW_PRECONDITION_PASS_NOT_RUN','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'app_snapshot':app,'isolated_snapshot':snapshot,'remote_main':remote,'remote_ahead_by':compare['ahead_by'],'own_paths':own,'ids':ids,'PR':1456,'command':['node','tools/ticket.mjs','done',*ids,'--pr','1456'],'env':{'CHICAGO_TICKETS_DIR':str(m.SOURCE)},'requires':'Rootexplicitpostgate/postphone grant; currentprimaryROOT ensuresactualfourimagegates; nativegenerateBoard mayrefreshprimaryignoredmirror AFTERphone closes. Remoteadvancesmayrequirefinitecurrenttipblobhydration intoisolated only; no bypass.'},indent=2)+'\n');print((O/'BEFORE.json').read_text())
