"""Read-only pure-function checks of committed objects; no native writers invoked."""
from pathlib import Path
from types import SimpleNamespace
import ast,copy,datetime as dt,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=H/'published6bf/chicago/4d';P=Path('/tmp/chicago-next-model/T3041-gallery-front-adoption-20261024');C=P/'candidate/chicago/4d';sys.path[:0]=[str(R/'tools'),str(R/'generators')]
def load(p,name):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def funcs(p):return {n.name:n for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
def native(p,names,env):
 ns=env.copy();nodes=funcs(p)
 for n in names:exec(compile('from __future__ import annotations\n'+ast.unparse(nodes[n]),str(p)+':'+n,'exec'),ns)
 return ns
params=load(C/'generators/archetypes/fort_structure_params.py','archetypes.fort_structure_params');facade=load(C/'generators/archetypes/facade_openings.py','audit_fort_facade')
source=load(R/'tools/compile_pictures.py','audit_picture_compiler');grader=load(R/'tools/grade_structures.py','audit_grader');rulings=json.loads((R/'data/structure_grades.json').read_text())
gbs=native(C/'tools/generate_business_signboards.py',['_front_wall'],{'STRUCTURES':C/'data/structures','_RESOLVERS':{'fort_structure':params.from_phase},'_load':lambda p:json.loads(p.read_text()),'facade_openings':facade,'TARGET_DATE':'1835-07-01'})
# For the isolated face diagnostic only, change the existing date variable to the real1812 target.
frontgbs=SimpleNamespace(_front_wall=gbs['_front_wall'],facade_openings=facade)
ens=native(R/'tools/generate_entrances.py',['front_doors','side_access_faces','merged_openings'],{'gbs':frontgbs,'_log_side_access_faces':lambda p:[], 'ENTRANCE_KINDS':('door','shop_door','open_bay'),'GROUND_Z_M':.30,'OPENING_GAP_M':.15,'SHOPFRONT':frozenset({'shop_door','show_window'})})
phase=native(R/'tools/compile_scene.py',['resolve_phase'],{'dt':dt})['resolve_phase']
floor=native(R/'tools/build_lodging_model_1835.py',['enclosed_area_m2'],{'Fault':ValueError})['enclosed_area_m2']
housing=native(R/'tools/house_the_present_1835.py',['floor_area'],{})['floor_area']
lodging=load(R/'tools/build_lodging_model_1835.py','audit_lodging')
source_index={p.stem:json.loads(p.read_text()) for p in(R/'data/sources').glob('*.json')};source_index['currey_1912_first_fort_birdseye']=json.loads((C/'data/sources/currey_1912_first_fort_birdseye.json').read_text())
rows=[];ids=[];records={}
for delta in json.loads((P/'review-manifest.json').read_text())['record_deltas']:
 sid=delta['structure_id'];ids.append(sid);old=json.loads((R/'data/structures'/f'{sid}.json').read_text());new=json.loads((C/'data/structures'/f'{sid}.json').read_text());records[sid]=new
 assert len(old['phases'])==len(new['phases'])==1
 op,np=old['phases'][0],new['phases'][0]
 for key in ['documented_range','position','footprint']:assert op[key]==np[key]
 assert {k:v for k,v in old.items() if k!='phases'}=={k:v for k,v in new.items() if k!='phases'}
 expected={'gallery_storeys','face_openings'} if 'blockhouse' not in sid else {'chimneys'}
 assert {k for k in set(op['form'])|set(np['form']) if op['form'].get(k)!=np['form'].get(k)}==expected
 assert floor(op)==floor(np);assert housing(op['footprint']['polygon'],op['form']['stories']['value'])==housing(np['footprint']['polygon'],np['form']['stories']['value'])
 assert phase(old,dt.date(1812,8,14))==op and phase(new,dt.date(1812,8,14))==np
 assert phase(old,dt.date(1835,7,1)) is phase(new,dt.date(1835,7,1)) is None
 fn=old['function']['value'];assert fn not in set(lodging.LODGING_FUNCTIONS)|lodging.OUTSIDE_THE_PROGRAMME|lodging.NOT_YET_OPEN
 # Native1835 entrance path has no eligible phase, and side-door reader returns empty before phase access for fort.
 assert ens['front_doors']({'id':sid,'archetype':'fort_structure'})==([],None)
 assert ens['side_access_faces']({'id':sid,'archetype':'fort_structure','phase':'first_fort_1803'})==[]
 np_p=params.from_phase(np,new);assert not hasattr(np_p,'deck_height_m') and not hasattr(np_p,'detail')
 entry={'id':sid,'function':fn,'phase':np['id'],'range':np['documented_range'],'footprint_area_m2':floor(np)[0],'stories':floor(np)[1],'enclosed_floor_proxy_m2':floor(np)[2],'housing_area_unchanged':True,'lodging_model_eligible':False,'standing_1835':False,'1835_front_doors':0,'1835_side_doors':0,'new_walk_surface_or_passages':False,'1812_residents_current':len(json.loads((R/'data/sidecars/1812'/f'{sid}.json').read_text()).get('residents',[]))}
 if 'blockhouse' not in sid:
  gbs['TARGET_DATE']='1812-08-14';doors,read=ens['front_doors']({'id':sid,'archetype':'fort_structure'});assert len(doors)==1 and read=='facade_openings.fort_structure';assert not ens['merged_openings']({'id':sid,'archetype':'fort_structure'})
  gbs['TARGET_DATE']='1835-07-01';entry['1812_diagnostic_ground_door']=doors[0];entry['front_rectangles_per_storey']=len(params.front_wall(np_p)['openings'])//2
 rows.append(entry)
cards=source.derive(None,'',source_index,{sid:json.dumps(rec) for sid,rec in records.items()},{'1812':ids},{})['1812']['by_structure']
for row in rows:
 sid=row['id'];grade=grader.grade_structure(sid,'inferred',cards.get(sid,[]),[],rulings,'1812');current=json.loads((R/'data/sidecars/1812'/f'{sid}.json').read_text())['grade'];assert grade==current;row['native_grade_after_new_source']=grade
 if 'blockhouse' not in sid:
  cur=next(x for x in cards[sid] if x['id']=='currey_1912_first_fort_birdseye');assert cur['years']==[1912,1912] and not cur.get('library') and cur['creator'];row['new_Currey_picture_entry']=cur
# Exercise the exact native selected-phase log reader with two source phases and a spy; no invented production data.
seen=[];old_phase={'id':'earlier'};selected={'id':'selected'}
def read_log(ph,rec):seen.append(ph['id']);return ph
ens['gbs']=SimpleNamespace(STRUCTURES=Path('/never-written'),_load=lambda p:{'phases':[old_phase,selected]},_log_dwelling_params=read_log)
ens['_log_side_access_faces']=lambda p:[{'selected_phase':p['id']}]
assert ens['side_access_faces']({'id':'fixture','archetype':'log_dwelling','phase':'selected'})==[{'selected_phase':'selected'}] and seen==['selected']
try:ens['side_access_faces']({'id':'fixture','archetype':'log_dwelling','phase':'missing'})
except ValueError:pass
else:raise AssertionError('missing phase did not refuse')
report={'status':'PASS','base':(H/'base-heads.txt').read_text().splitlines(),'tests':'actual native pure functions evaluated in memory; no CLI writers/producers, no Blender/browser/full gate','seven_targets':rows,'exact_phase_log_fix':'actual function chooses selected phase, missing phase refuses; fort early return untouched','source_grade_caveat':'Current inferred/no-picture grades are unchanged by source illustration links alone. Explicit per-building pictured rulings or genuine native cameras are required where a reasonable whole-building view is independently identified; no blanket attestation from ambiguous compound image.','1812_entrance_limit':'No native1812 apron/entrance producer: five rectangles/door diagnostics use real1812 target in isolated native date reader; normal producer remains1835 only.','counts':{'targets':7,'ranges':5,'chimney_only':2,'new_1835_doors':0,'new_1835_aprons':0,'new_people_or_beds':0}}
(H/'native-impacts.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='seven_targets'},indent=2))
