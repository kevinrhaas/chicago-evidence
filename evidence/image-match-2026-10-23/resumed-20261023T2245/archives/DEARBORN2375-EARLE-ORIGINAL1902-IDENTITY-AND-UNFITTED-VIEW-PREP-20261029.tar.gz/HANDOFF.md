# T-2375: verified Earle bridge identity and finite next-view plan

The actual original book contains the held colour lunette. Internet Archive
`chicagohistorica00chic`, catalogued **c1902**, supplies exact plate n24, facing
narrative n23/printed p18 explicitly headed *The First Bridge Across the Chicago
River,1834*. Its n5 Chicago RandMcNally imprint, n6 title, and n10/printed p6
attribution to Lawrence C.Earle were downloaded and directly viewed. The underlying
pre1930 US artwork is public domain by age on that identified publication. No
explicit dated copyright page or modern stock-reproduction licence is claimed.

The previous inventory's1849 swing-bridge exclusion is wrong for this exact image.
The historical filename is retained for byte and link continuity. Two inventory
entries/summary rows are corrected while recording the superseded reading; a new
source record gives the actual book, artist, original plate and careful date/rights
scope. The separate Baker-Co work's explicit hold remains unchanged.

PROPOSED.patch passes actual `git apply --check` against the current primary
working source without applying it. This external four-path proposal is independent
of the existing thirteen-path bridge producer/runtime proposal. Neither is adopted
or claimed by this packet. Recheck all preimages before later adoption, and merge
any incoming inventory edits entry by entry rather than overwriting the file.

The fourth proposed path is deliberately an **UNFITTED diagnostic camera seed**.
It retains the old provisional Andreas pose/focal only as a starting frame, resets
principal point to the held1800×1238 lunette, and must be fitted before it is a useful
actual comparison. It is not a canonical matches record and must not become a
historical From-this-spot affordance. No new image matches are asserted here.

Finite actual-view work after the root grants the source/CPU/GPU lease:

1. Claim the original ticket and adopt the guarded thirteen-path source proposal
   plus these independent identity/source fixes. Source rights no longer block the
   Earle comparison. Keep Baker's check_required source and explicit disposition.
2. Fit one diagnostic Earle camera to the two gallows heads/feet and rising
   parapet, using the final current native v5MASTER and fixed mapped placement.
   Record approximate picks/residuals and drawing projection disagreement. Do not
   derive new historical dimensions from those picks or tune geometry to conflict
   with the independently cleared Andreas form within T-3153 tolerance.
3. Run the native `node tools/photo_match.mjs
   data/reference_views/dearborn_street_drawbridge/earle_1902_lunette.json` on the
   actual adopted/compiled source, or a fully bound isolated photo root with
   `--glb` pointing to the exact current genuine native v5MASTER. Preserve its raw
   unreviewed record and directly inspect the actual side-by-side before deciding
   matches. The original volume's colour can corroborate a warm-brown
   representation; it does not establish exact historical finish. Ships,
   dockworkers, water/wharf context are not additional bridge-body geometry.
4. The two-gallows form/profile is qualitatively consistent in directly read
   Earle and Andreas. Only a new concrete visitor-noticeable gap may reopen model
   form. Different painterly projections are honestly within tolerance when that
   is what was read, with no new photo follow-up ticket.
5. Original closure still needs current producer/WEB/metadata/rights-consumer
   checks, canonical views, source-gallery and app/ground evidence on both
   viewports, actual full check, policy PR/CI/merge to dev and official settlement.

The existing actual v5 native proof already preserves six legacy default masters;
new source/citation records alone are not a new actual model export. Canonical
recipes must be recomputed through their actual native owners after adoption.
The p18 retrospective200ft length conflicts with Norton/Moses300ft and the mapped
water gap; this packet records the conflict and does not move independent banks.
