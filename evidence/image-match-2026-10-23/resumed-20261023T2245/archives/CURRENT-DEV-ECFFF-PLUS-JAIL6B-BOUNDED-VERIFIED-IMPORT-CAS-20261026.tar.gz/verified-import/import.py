from pathlib import Path
import subprocess,os,json,urllib.request,urllib.parse,hashlib,zlib,concurrent.futures,datetime,time,shutil,base64,signal
B=Path('/tmp/root-first-dev-landing-import-20261026T1735');P=Path('/tmp/root-first-dev-landing-current-plus6b-readonly-price-20261026T1718');R=Path('/tmp/chicago-current-objects-20261025');C=Path('/workspace/chicago');G=C/'.git'
OLD='8f70801833aa36dd304f80d92cb8981ce5723f27';DEV='ecfff9f56ce359b70aa520e97d1923c12a6dafb2';FOREIGN='6b72454ea24960a69c473be630580cdeff274802';PRIMARY='562a4a9adaee706a97ea3b83b06b6cda89a69fc4'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1');os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
def git(repo,*args,input=None):return subprocess.check_output(['git','-C',str(repo),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','-c','index.threads=1',*args],input=input,env=env)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():return {'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{str(p):{'sha256':digest(p),'mode':p.stat().st_mode}for p in [G/'HEAD',G/'index',G/'config']},'HEAD':git(C,'rev-parse','HEAD').decode().strip()}
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path]))
before=snapshot();save('SOURCE-BEFORE.json',before)
assert before['HEAD']==PRIMARY and git(C,'rev-parse','refs/remotes/origin/dev').decode().strip()==OLD
assert not git(C,'status','--porcelain','--untracked-files=no').strip(),'Primary tracked dirt'
assert shutil.disk_usage('/workspace').free>230*1024**2 and shutil.disk_usage('/tmp').free>1024**3
price=json.loads((P/'PRICE.json').read_text());tips=price['tip_prices'];assert [x['commit']for x in tips]==[DEV,FOREIGN]
# Fetch immutable commit/tree metadata ONLY into the established tiny isolated promisor repo.
fetches=[]
for head in [DEV,FOREIGN]:
 cmd=['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',head]
 log=B/(head+'-metadata.log')
 with log.open('xb')as out:
  p=subprocess.Popen(cmd,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,env=env);reason=None;peak=0
  while p.poll()is None:
   size=sum(f.stat().st_size for f in (R/'objects').rglob('*')if f.is_file());peak=max(peak,size)
   if size>24*1024**2:reason='Isolated metadata exceeds24MiB'
   if b'filtering not recognized'in log.read_bytes().lower():reason='Server ignored blob:none'
   if reason:os.killpg(p.pid,signal.SIGTERM);p.wait();break
   time.sleep(.15)
  rc=p.wait()
 fetches.append({'head':head,'exit':rc,'peak_bytes':peak,'abort':reason});save('METADATA-FETCH.json',fetches);assert rc==0 and not reason
apis=[]
for tip,filename in zip(tips,['current-dev-tip-recursive-tree.json','foreign6b-tip-recursive-tree.json']):
 head=tip['commit'];assert git(R,'rev-parse',head+'^{tree}').decode().strip()==tip['tree'];a=json.loads((P/filename).read_text());assert not a.get('truncated');actual={}
 for raw in git(R,'ls-tree','-r','-z',head).split(b'\0'):
  if raw:
   meta,name=raw.split(b'\t',1);mode,kind,sha=meta.decode().split();actual[name.decode()]={'mode':mode,'type':kind,'sha':sha}
 leaves=[r for r in a['tree']if r['type']!='tree'];assert len(actual)==len(leaves)
 for row in leaves:assert actual[row['path']]=={k:row[k]for k in ['mode','type','sha']},row['path']
 apis.append(a)
allocation=0;packs=[]
for pack in sorted((R/'objects/pack').glob('*.pack')):
 git(R,'verify-pack',str(pack.with_suffix('.idx')));d=pack.read_bytes();assert hashlib.sha1(d[:-20]).digest()==d[-20:]
 for file in [pack,pack.with_suffix('.idx'),pack.with_suffix('.promisor')]:
  if not file.exists():continue
  dest=G/'objects/pack'/file.name;new=not dest.exists()
  if not new:assert digest(file)==digest(dest)
  else:
   tmp=dest.with_name('.'+dest.name+'.bounded-'+str(os.getpid()));shutil.copy2(file,tmp);assert digest(file)==digest(tmp);tmp.rename(dest);allocation+=dest.stat().st_blocks*512
  packs.append({'file':file.name,'bytes':file.stat().st_size,'sha256':digest(file),'new':new})
save('PACK-IMPORT.json',packs)
missing={}
for tip in tips:
 for r in tip['missing_blob_paths']:missing.setdefault(r['sha'],dict(r,head=tip['commit']))
assert len(missing)==75 and sum(r['size']for r in missing.values())==75138673
# Missing set was priced readonly before mutation; verify no surprise concurrent writer.
for sha in missing:
 r=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=(sha+'\n').encode());assert r.decode().strip().endswith(' missing'),r

def download(row):
 sha=row['sha'];dest=G/'objects'/sha[:2]/sha[2:];url='https://raw.githubusercontent.com/kevinrhaas/chicago/'+row['head']+'/'+urllib.parse.quote(row['path'],safe='/')
 for attempt in range(3):
  try:
   with urllib.request.urlopen(url,timeout=90)as response:data=response.read(row['size']+65536)
   assert len(data)==row['size'];raw=b'blob '+str(len(data)).encode()+b'\0'+data;assert hashlib.sha1(raw).hexdigest()==sha
   encoded=zlib.compress(raw);dest.parent.mkdir(exist_ok=True);tmp=dest.with_name(dest.name+'.bounded-'+str(os.getpid()))
   with tmp.open('xb')as f:f.write(encoded)
   assert hashlib.sha1(zlib.decompress(tmp.read_bytes())).hexdigest()==sha;assert not dest.exists();tmp.rename(dest)
   return {'sha':sha,'path':row['path'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'allocated_bytes':dest.stat().st_blocks*512}
  except Exception:
   if attempt==2:raise
   time.sleep(attempt+1)
rows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=5)as pool:
 for row in pool.map(download,missing.values()):
  rows.append(row);allocation+=row['allocated_bytes'];assert allocation<=120*1024**2;save('BLOB-PROGRESS.json',{'completed':len(rows),'total':75,'allocated_bytes':allocation})
save('BLOB-IMPORT.json',rows)
checks=[]
for tip,a in zip(tips,apis):
 ids=sorted({r['sha']for r in a['tree']if r['type']=='blob'});batch=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();assert not any(x.endswith(' missing')for x in batch);sizes={x.split()[0]:int(x.split()[2])for x in batch};assert all(sizes[r['sha']]==r['size']for r in a['tree']if r['type']=='blob');assert git(C,'rev-parse',tip['commit']+'^{tree}').decode().strip()==tip['tree'];checks.append({'commit':tip['commit'],'tree':tip['tree'],'unique_tip_blobs_verified':len(ids)})
assert snapshot()==before,'Source changed during objects import'
fresh=api('git/ref/heads/dev');pr=api('pulls/1333');save('FRESH-BEFORE-CAS.json',{'dev':fresh,'pr_head':pr['head']['sha'],'draft':pr['draft']})
ready=fresh['object']['sha']==DEV and pr['head']['sha']==FOREIGN
if ready:
 assert not git(C,'status','--porcelain','--untracked-files=no').strip();assert snapshot()==before
 git(C,'update-ref','refs/remotes/origin/dev',DEV,OLD)
after=snapshot();save('SOURCE-AFTER.json',after);assert after['metadata']==before['metadata']and after['HEAD']==PRIMARY
expected=[line.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+DEV)for line in before['refs']]if ready else before['refs'];assert after['refs']==expected
result={'status':'IMPORTED_VERIFIED_AND_EXACT_CAS_COMPLETE'if ready else'OBJECTS_READY_REMOTE_MOVED_NO_CAS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tip_checks':checks,'imported_blob_count':len(rows),'blob_uncompressed_bytes':sum(x['bytes']for x in rows),'new_object_allocated_bytes':allocation,'cached_origin_dev':git(C,'rev-parse','refs/remotes/origin/dev').decode().strip(),'fresh_remote_dev':fresh['object']['sha'],'fresh_PR1333_head':pr['head']['sha'],'primary_HEAD':PRIMARY,'HEAD_index_config_unchanged':True,'all_other_refs_unchanged':True,'primary_clean':True,'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free}
save('RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
