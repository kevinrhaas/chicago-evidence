from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal,zlib,urllib.request,urllib.parse,struct
os.sched_setaffinity(0,{1,3});os.nice(19)
B=Path(__file__).parent;C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='00a058ec1a868f4d0a9b5f69c274d54849414cac';TIP='03b027ba6bed8d8ebf1a20e716462ea2b8b54739';CAP=620*1024**2;ENVELOPE=CAP;FLOOR=512*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(r,*args,input=None):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:sha(G/n)for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
def indexed(ids):
 wanted=set(ids);found=set();obj=G/'objects'
 for s in wanted:
  if(obj/s[:2]/s[2:]).is_file():found.add(s)
 for idx in(obj/'pack').glob('*.idx'):
  remaining=wanted-found
  if not remaining:break
  with idx.open('rb')as f:
   head=f.read(8);v2=head[:4]==b'\xfftOc';off=8 if v2 else 0
   if v2:assert struct.unpack('>I',head[4:])[0]==2
   f.seek(off);fan=struct.unpack('>256I',f.read(1024));table=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
   for s in remaining:
    key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
    while a<z:
     m=(a+z)//2;f.seek(table+m*stride+delta);value=f.read(20)
     if value<key:a=m+1
     else:z=m
    f.seek(table+a*stride+delta)
    if a<fan[key[0]]and f.read(20)==key:found.add(s)
 return found

from concurrent.futures import ThreadPoolExecutor,as_completed
import threading
P=Path('/tmp/current-dev-03b0-readonly-price-20261029');priced=json.loads((P/'PRICE.json').read_text());tree=json.loads((P/'TREE.json').read_text());tc=json.loads((P/'TIP-COMMIT.json').read_text());TREE=tc['tree']['sha'];assert tree['sha']==TREE and not tree.get('truncated')
before=snap();save('SOURCE-BEFORE.json',before);assert git(C,'rev-parse','origin/dev').decode().strip()==OLD
remote=api('git/ref/heads/dev');save('REMOTE-AT-START.json',remote);assert remote['object']['sha']==TIP
leaves=[r for r in tree['tree']if r['type']!='tree'];allids={r['sha']for r in leaves};present=indexed(allids);missing={r['sha']:r for r in leaves if r['sha']not in present};assert sum(r['size']for r in missing.values())==598002025 and len(missing)==946
with(B/'metadata-fetch.log').open('xb')as log:
 p=subprocess.Popen(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',TIP],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);abort=None;peak=0
 while p.poll()is None:
  size=sum(f.stat().st_size for f in(R/'objects').rglob('*')if f.is_file());peak=max(peak,size)
  if size>32*1024**2 or b'filtering not recognized'in(B/'metadata-fetch.log').read_bytes().lower():abort='filter/isolationbound';os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(.15)
 rc=p.wait()
save('METADATA-FETCH.json',{'exit':rc,'peak':peak,'abort':abort,'total_isolation_cap':32*1024**2});assert rc==0 and not abort
actual={}
for row in git(R,'ls-tree','-r','-z',TIP).split(b'\0'):
 if row:
  a,n=row.split(b'\t',1);m,t,s=a.decode().split();actual[n.decode()]={'mode':m,'type':t,'sha':s}
assert actual=={r['path']:{k:r[k]for k in ['mode','type','sha']}for r in leaves}
metadata={};packs=[]
for pack in sorted((R/'objects/pack').glob('*.pack')):
 if(G/'objects/pack'/pack.name).exists():continue
 ids=[]
 for line in git(R,'verify-pack','-v',str(pack.with_suffix('.idx'))).decode().splitlines():
  c=line.split()
  if len(c)>4 and len(c[0])==40 and c[1]in['commit','tree','tag','blob']:assert c[1]!='blob';ids.append(c[0])
 known=indexed(ids)
 for line in git(R,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines():
  obj,kind,size=line.split()
  if obj not in known:metadata[obj]={'kind':kind,'canonical_bytes':int(size)}
 packs.append(pack)
raw=sum(r['size']for r in missing.values())+sum(r['canonical_bytes']for r in metadata.values());allocation=0;lock=threading.Lock();rows=[]
assert shutil.disk_usage('/workspace').free>=FLOOR+CAP
save('EXACT-PRICE-AND-AUTHORITY.json',{'canonical_new_tip_blob_bytes':598002025,'new_metadata':metadata,'canonical_total':raw,'actual_common_allocation_cap':CAP,'workspace_floor':FLOOR,'isolated_metadata_cap':32*1024**2,'Root_authorization':'EXACT946missing03btipblobs598002025canonicalbytes plusisolatedmetadata<=32MiB,actualCOMMONallocation<=620MiB,WS>=512MiB. This175commitpricedbatchonly. Freshremote03b/expectedold00aCASafteralltipverification,allsourceguardsunchanged. Nobroadfetch/GC/repack.','scope':'175commits1020paths includingruntime/transport/humans/1904 andoldTremontmerge;availabilityONLY.'});assert snap()==before
packrows=[]
for pack in packs:
 data=pack.read_bytes();assert hashlib.sha1(data[:-20]).digest()==data[-20:]
 for src in[pack,pack.with_suffix('.idx'),pack.with_suffix('.promisor')]:
  if not src.exists():continue
  dest=G/'objects/pack'/src.name;assert not dest.exists();tmp=dest.with_name('.'+dest.name+'.03b0-'+str(os.getpid()));shutil.copy2(src,tmp);assert sha(src)==sha(tmp);tmp.rename(dest);allocation+=dest.stat().st_blocks*512;assert allocation<=CAP and shutil.disk_usage('/workspace').free>=FLOOR;packrows.append({'name':src.name,'bytes':src.stat().st_size,'sha256':sha(src)})
save('PACK-IMPORT.json',packrows)
def work(row):
 global allocation
 error=None
 for attempt in range(3):
  try:
   with urllib.request.urlopen('https://raw.githubusercontent.com/kevinrhaas/chicago/'+TIP+'/'+urllib.parse.quote(row['path'],safe='/'),timeout=90)as response:data=response.read(row['size']+65536)
   break
  except Exception as e:
   error=str(e)
   if attempt==2:raise
   time.sleep(1+attempt)
 rawblob=b'blob '+str(len(data)).encode()+b'\0'+data;assert len(data)==row['size']and hashlib.sha1(rawblob).hexdigest()==row['sha'];dest=G/'objects'/row['sha'][:2]/row['sha'][2:];assert not dest.exists();dest.parent.mkdir(exist_ok=True);tmp=dest.with_name(dest.name+'.03b0-'+str(os.getpid()));enc=zlib.compress(rawblob);tmp.write_bytes(enc);assert hashlib.sha1(zlib.decompress(tmp.read_bytes())).hexdigest()==row['sha']
 with lock:
  assert allocation+tmp.stat().st_blocks*512<=CAP and shutil.disk_usage('/workspace').free>=FLOOR
  tmp.rename(dest);allocation+=dest.stat().st_blocks*512
 return {'path':row['path'],'sha':row['sha'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoded_bytes':len(enc),'retry_error_retained':error}
with ThreadPoolExecutor(max_workers=4)as ex:
 for future in as_completed([ex.submit(work,row)for row in missing.values()]):
  rows.append(future.result());save('DOWNLOAD-PROGRESS.json',{'complete':len(rows),'total':len(missing),'allocated':allocation,'workspace_free':shutil.disk_usage('/workspace').free})
  if len(rows)%100==0:print('IMPORTED',len(rows),'/',len(missing),'allocated',allocation,flush=True)
save('BLOB-IMPORT.json',rows)
assert allids<=indexed(allids),'Refusemissingtipobjectprobe'
ids=sorted({r['sha']for r in leaves if r['type']=='blob'});checks=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();assert not any(x.endswith(' missing')for x in checks);sizes={r.split()[0]:int(r.split()[2])for r in checks};assert all(sizes[r['sha']]==r['size']for r in leaves if r['type']=='blob');save('ALL-TIP-OBJECT-IDS-AND-SIZES-VERIFIED.json',{'tip_entries':len(leaves),'unique_blob_ids':len(ids),'all_sizes_match':True,'all_new_downloads_canonical_sha1_verified':len(rows),'existing_ids':'Exactloosepath/packindexmembership plusnativecat-file objectID/size; notarehashallhistoricbytesclaim.'})
assert git(C,'rev-parse',TIP+'^{tree}').decode().strip()==TREE and git(C,'merge-base',OLD,TIP).decode().strip()==OLD;assert snap()==before
remote=api('git/ref/heads/dev');save('REMOTE-BEFORE-CAS.json',remote);cas=remote['object']['sha']==TIP
if cas:git(C,'update-ref','refs/remotes/origin/dev',TIP,OLD)
after=snap();save('SOURCE-AFTER.json',after);assert after['metadata']==before['metadata']and after['HEAD']==before['HEAD']and after['status_sha256']==before['status_sha256'];assert after['refs']==([x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+TIP)for x in before['refs']]if cas else before['refs'])
result={'status':'EXACT_03B0_BOUNDED_IMPORT_ALL_TIP_VERIFIED_EXPECTED_OLD_CAS_PASS'if cas else'PRICED_IMMUTABLE_03B0_READY_REMOTE_MOVED_NO_CAS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old':OLD,'tip':TIP,'tree':TREE,'new_tip_blobs':len(missing),'canonical_new_raw_bytes':raw,'actual_source_allocated_bytes':allocation,'allocation_cap':CAP,'all_tip_entries':len(leaves),'all_tip_unique_blobs_sizes_verified':len(ids),'cached_origin_dev':git(C,'rev-parse','origin/dev').decode().strip(),'fresh_remote_dev':remote['object']['sha'],'source_HEAD_index_config_merge_status_unchanged':True,'other_refs_unchanged':True,'source_HEAD':before['HEAD'],'workspace_free':shutil.disk_usage('/workspace').free,'workspace_floor':FLOOR,'tmp_free':shutil.disk_usage('/tmp').free,'no_source_common_fetch_gc_repack_checkout':True,'qualification':'AvailabilityONLY;175incomingcommitsscopeunqualifiedbythisimport. Currentruntime/phonecaps/AGENTS mustbeinspectedbyauthors; olderdatedpassesNOTcurrentwholequalification.'};save('RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
