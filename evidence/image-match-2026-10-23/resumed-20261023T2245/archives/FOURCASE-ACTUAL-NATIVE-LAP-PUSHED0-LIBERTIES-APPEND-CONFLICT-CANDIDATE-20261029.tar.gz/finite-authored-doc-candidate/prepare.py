from pathlib import Path
from urllib.request import Request,urlopen
import json,hashlib,subprocess,difflib,datetime
O=Path(__file__).parent;p='chicago/4d/docs/LIBERTIES.md';bodies={}
for label,head in [('BASE','be501b034cd24410843eedced9e1bf1b52a4ff4f'),('OURS','24e4c333ab94864208141bb85234e33dadde841a'),('THEIRS','ec16b8dd726fa7852ede885ef2d754d55b9b4c59')]:
 with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+head+'/'+p,headers={'User-Agent':'Chicago-finite-hand-authored-conflict-review'}),timeout=60)as r:assert r.status==200;data=r.read(4*1024**2+1)
 assert len(data)<=4*1024**2;bodies[label]=data;(O/(label+'.md')).write_bytes(data)
for label in ['OURS','THEIRS']:
 diff=''.join(difflib.unified_diff(bodies['BASE'].decode().splitlines(True),bodies[label].decode().splitlines(True),fromfile='BASE',tofile=label));(O/('BASE-TO-'+label+'.patch')).write_text(diff)
r=subprocess.run(['git','merge-file','--diff3','--stdout',str(O/'OURS.md'),str(O/'BASE.md'),str(O/'THEIRS.md')],stdout=subprocess.PIPE,stderr=subprocess.PIPE);(O/'NATIVE-DIFF3-UNRESOLVED.md').write_bytes(r.stdout);(O/'NATIVE-DIFF3.stderr').write_bytes(r.stderr)
text=r.stdout.decode();lines=text.splitlines();blocks=[];start=None
for i,l in enumerate(lines):
 if l.startswith('<<<<<<<'):start=i
 if l.startswith('>>>>>>>'):
  assert start is not None;blocks.append({'line':start+1,'lines':lines[max(0,start-3):i+4]});start=None
assert start is None
result={'status':'READONLY_REMOTE_IMMUTABLE_THREE_WAY_AUTHORED_LIBERTIES_CONFLICT_PREP_NOT_ADOPTED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'path':p,'base':'be501b034cd24410843eedced9e1bf1b52a4ff4f','ours':'24e4c333ab94864208141bb85234e33dadde841a','theirs':'ec16b8dd726fa7852ede885ef2d754d55b9b4c59','native_merge_file_exit':r.returncode,'raw_file_bindings':{k:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}for k,v in bodies.items()},'conflicts':blocks,'primary_reads_imports_source_ref_index_changes':False};(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'exit':r.returncode,'conflict_count':len(blocks),'conflicts':blocks},indent=2))
