ACTUAL PR1260 mobile3-4 failure, not a PASS.

Run40051671920/job120745491483 exact6bf checkout, correctmobile3-4,137passed1failed,zero pageerrors. Failure namesWolf Point renderedbbox11m vswall2.6m. Rawlog/jobs/receipt retain proof. Boundedread-only source diagnosis identifies potential whole-instance sign-pole envelope mismatch; norepair/assertionchange or tolerance recommendation. Rootowns diagnosis and remediation. Snapshot11success1failure6running; fullcoverage notcomplete. No sourcewrites, redispatch/cancel/merge/lap/browser/heavywork.
