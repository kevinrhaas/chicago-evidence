from pathlib import Path
import json,os,subprocess,importlib.util,hashlib,zlib,shutil,datetime
os.sched_setaffinity(0,{1});os.nice(10)
B=Path(__file__).parent;R=Path('/workspace/chicago/chicago/4d/tickets');I=Path('/workspace/isolated-gt-ticket-renewal-native-v4-20261029/repo');C=Path('/workspace/chicago');CAP=8*1024**2;FLOOR=512*1024**2
sp=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
m.SOURCE=R;m.G=R/'.git';m.REPO='kevinrhaas/chicago-tickets';before=m.snapshot();save('TICKET-CACHE-BEFORE.json',before);assert before['HEAD']=='b92d033c528e40d0896d7304027443dcf24ed8c2'and not before['status']and not(m.G/'MERGE_HEAD').exists()
mirror=C/'site/4d/tickets.json';mirror_before=hashlib.sha256(mirror.read_bytes()).hexdigest();sourceboard={p:hashlib.sha256((R/p).read_bytes()).hexdigest()for p in ['BOARD.md','tickets.json']if(R/p).is_file()}
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(root,*a,input=None):return subprocess.check_output(['git','-C',str(root),'-c','gc.auto=0','-c','maintenance.auto=false',*a],env=env,input=input)
isolated_head=git(I,'rev-parse','HEAD').decode().strip();assert isolated_head=='2929e1612e4688ed1080e9e1522a49ae5ec2b911';tip=m.api('git/ref/heads/main')['object']['sha']
remote=m.api('git/commits/'+tip);tree=m.api('git/trees/'+remote['tree']['sha']+'?recursive=1');assert not tree.get('truncated');save('REMOTE-COMMIT.json',remote);save('REMOTE-TREE.json',tree);compare=m.api('compare/'+before['HEAD']+'...'+tip);assert compare['status']=='ahead';save('REMOTE-COMPARE.json',compare)
# Bring only canonical immutablemetadata and missingtipblobs into isolatedobjectstore.
assert m.api('compare/'+isolated_head+'...'+tip)['status']in {'ahead','identical'}
with(B/'ISOLATED-EXACT-METADATA-FETCH.log').open('xb')as f:q=subprocess.run(['git','-C',str(I),'-c','gc.auto=0','-c','maintenance.auto=false','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','origin',tip],env=env,stdout=f,stderr=subprocess.STDOUT)
assert q.returncode==0;originalG=m.G;m.G=I/'.git';isolated_known=m.indexed([r['sha']for r in tree['tree']if r['type']!='tree']);m.G=originalG;primary_known=m.indexed([r['sha']for r in tree['tree']if r['type']!='tree']);missing=[r for r in tree['tree']if r['type']!='tree'and r['sha']not in isolated_known|primary_known];assert sum(r['size']for r in missing)<1024**2 and len(missing)<128
from urllib.request import Request,urlopen
hydrated=[]
for r in missing:
 with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+tip+'/'+r['path'],headers={'User-Agent':'Chicago-current-nativeclaim-cache-FF'}),timeout=60)as response:assert response.status==200;data=response.read(r['size']+1)
 assert len(data)==r['size']and m.gitsha('blob',data)==r['sha'];raw=b'blob '+str(len(data)).encode()+b'\0'+data;d=I/'.git/objects'/r['sha'][:2]/r['sha'][2:];assert not d.exists();d.parent.mkdir(exist_ok=True);d.write_bytes(zlib.compress(raw));hydrated.append({'path':r['path'],'sha':r['sha'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
save('ISOLATED-TIP-HYDRATION.json',hydrated);assert git(I,'rev-parse','HEAD').decode().strip()==isolated_head
ids=set()
for idx in(I/'.git/objects/pack').glob('*.idx'):
 for line in git(I,'show-index',input=idx.read_bytes()).decode().splitlines():ids.add(line.split()[1])
for folder in(I/'.git/objects').iterdir():
 if folder.is_dir()and len(folder.name)==2:
  for p in folder.iterdir():
   if p.is_file()and len(p.name)==38:ids.add(folder.name+p.name)
unknown=ids-m.indexed(ids);assert len(unknown)<512
rows=[]
for s in sorted(unknown):
 kind=git(I,'cat-file','-t',s).decode().strip();assert kind in {'commit','tree','blob'};data=git(I,'cat-file',kind,s);raw=kind.encode()+b' '+str(len(data)).encode()+b'\0'+data;assert hashlib.sha1(raw).hexdigest()==s;enc=zlib.compress(raw);rows.append({'sha':s,'kind':kind,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoded_bytes':len(enc),'enc':enc})
raw_total=sum(r['bytes']for r in rows);allocated=sum(((len(r['enc'])+4095)//4096)*4096 for r in rows);assert raw_total<CAP and allocated<CAP and shutil.disk_usage('/workspace').free>=FLOOR+allocated+65536
save('PLAN.json',{'status':'EXACT_ISOLATED_NATIVE_REVIEW_AND_FOREIGN_TIP_OBJECTS_PRICED','old':before['HEAD'],'tip':tip,'tree':remote['tree']['sha'],'new_objects':len(rows),'raw_total':raw_total,'encoded_allocated_upper':allocated,'cap':CAP,'workspace_floor':FLOOR,'rows':[{k:v for k,v in r.items()if k!='enc'}for r in rows],'app_source_ref_config_mutations':False,'mirror_board_publish_writes':False});assert m.snapshot()==before
for r in rows:
 d=m.G/'objects'/r['sha'][:2]/r['sha'][2:];assert not d.exists();d.parent.mkdir(exist_ok=True);tmp=d.with_name(d.name+'.known-ticket-sync-'+str(os.getpid()));tmp.write_bytes(r['enc']);assert tmp.read_bytes()==r['enc'];tmp.rename(d);assert shutil.disk_usage('/workspace').free>=FLOOR
assert {r['sha']for r in tree['tree']if r['type']!='tree'}<=m.indexed([r['sha']for r in tree['tree']if r['type']!='tree']);assert tip in m.indexed([tip])
assert m.api('git/ref/heads/main')['object']['sha']==tip,'Remoteadvanced: knownobjectsretained, do notpullunpricedtip'
with(B/'NATIVE-FF-PULL.log').open('xb')as f:p=subprocess.run(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','pull','--ff-only','origin','main'],env=env,stdout=f,stderr=subprocess.STDOUT)
save('NATIVE-FF-PULL.json',{'exit':p.returncode});assert p.returncode==0
assert git(R,'rev-parse','HEAD').decode().strip()==tip and not git(R,'status','--porcelain').strip();assert git(R,'rev-parse','HEAD^{tree}').decode().strip()==remote['tree']['sha'];assert git(R,'rev-parse','origin/main').decode().strip()==tip
readback=[]
for r in tree['tree']:
 if r['type']=='tree':continue
 assert r['type']=='blob'and r['mode']=='100644';p=R/r['path'];data=p.read_bytes();assert len(data)==r['size']and m.gitsha('blob',data)==r['sha'];readback.append({'path':r['path'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob':r['sha']})
save('ALL-CURRENT-TIP-WORKING-FILES.json',readback)
assert hashlib.sha256(mirror.read_bytes()).hexdigest()==mirror_before and all(hashlib.sha256((R/p).read_bytes()).hexdigest()==s for p,s in sourceboard.items())
after=m.snapshot();save('TICKET-CACHE-AFTER.json',after)
save('RESULT.json',{'status':'EXACT_OFFICIAL_CARPENTER_CLAIM_AND_CURRENT_FOREIGN_MAIN_PRIMARY_CACHE_NORMAL_FF_SYNC_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old':before['HEAD'],'tip':tip,'tree':remote['tree']['sha'],'new_objects':len(rows),'canonical_new_raw_bytes':raw_total,'actual_all_tip_files_bytes_SHA256_Gitblob_verified':len(readback),'all_foreign_and_own_native_states_exact_tip':True,'no_app_source_HEAD_index_config_ref_operations_or_snapshots_issued':True,'primary_ignored_published_ticketmirror_unchanged':True,'primary_source_ignored_BOARD_and_ticketsJSON_unchanged':True,'note':'Nativeboard/publish notrun undercache-onlylease. Sourceignoredboardmaybedated; nextnativepublish/board refreshes fromnowactualcurrentcache. No models/appsource/devmerge/mainpromotion.','workspace_free':shutil.disk_usage('/workspace').free});print((B/'RESULT.json').read_text())
