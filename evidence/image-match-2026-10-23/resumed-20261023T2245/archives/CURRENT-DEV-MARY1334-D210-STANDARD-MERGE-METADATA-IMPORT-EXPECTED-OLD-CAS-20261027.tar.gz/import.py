from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal
os.sched_setaffinity(0,{3});os.nice(19)
B=Path(__file__).parent;C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025')
OLD='6c103072dae94ed58cc8fc06462aef2638be736f';TIP='d21076643a97b5c8695139ed7d8ab94150154b8b';TREE='a38e6d3e4dda32be845cd0e6e05cda278ca13b0f';AUTHOR='3f853f35c01f8b1a429fd75292a53be25102a736';ENVELOPE=5*1024**2;FLOOR=128*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(r,*args,input=None):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:sha(G/n)for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
def checks(repo,ids):return dict(zip(ids,git(repo,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines()))
before=snapshot();save('SOURCE-BEFORE.json',before);assert git(C,'rev-parse','origin/dev').decode().strip()==OLD
fresh=api('git/ref/heads/dev');save('REMOTE-AT-START.json',fresh);assert fresh['object']['sha']==TIP
commit=api('git/commits/'+TIP);save('LANDING-COMMIT.json',commit);assert[p['sha']for p in commit['parents']]==[OLD,AUTHOR]and commit['tree']['sha']==TREE
assert git(C,'rev-parse',AUTHOR+'^{tree}').decode().strip()==TREE
apijson=api('git/trees/'+TREE+'?recursive=1');assert not apijson.get('truncated');save('TIP-RECURSIVE-TREE.json',apijson);leaves=[r for r in apijson['tree']if r['type']!='tree'];ids=sorted({r['sha']for r in leaves if r['type']=='blob'});beforeblobs=checks(C,ids);assert not any(x.endswith(' missing')for x in beforeblobs.values()),'Unexpectedmissingsourceblob';assert all(int(beforeblobs[r['sha']].split()[2])==r['size']for r in leaves if r['type']=='blob')
assert shutil.disk_usage('/workspace').free>=FLOOR+ENVELOPE and shutil.disk_usage('/tmp').free>=1024**3
with(B/'metadata-fetch.log').open('xb')as log:
 p=subprocess.Popen(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',TIP],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);abort=None;peak=0
 while p.poll()is None:
  size=sum(f.stat().st_size for f in(R/'objects').rglob('*')if f.is_file());peak=max(peak,size)
  if size>32*1024**2 or b'filtering not recognized'in(B/'metadata-fetch.log').read_bytes().lower():abort='isolation/filterbound';os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(.15)
 rc=p.wait()
save('METADATA-FETCH.json',{'exit':rc,'peak':peak,'abort':abort});assert rc==0 and not abort
actual={}
for line in git(R,'ls-tree','-r','-z',TIP).split(b'\0'):
 if line:
  a,n=line.split(b'\t',1);m,t,s=a.decode().split();actual[n.decode()]={'mode':m,'type':t,'sha':s}
assert actual=={r['path']:{k:r[k]for k in ['mode','type','sha']}for r in leaves}
meta={};packs=[]
for pack in sorted((R/'objects/pack').glob('*.pack')):
 if(G/'objects/pack'/pack.name).exists():continue
 objects=[]
 for line in git(R,'verify-pack','-v',str(pack.with_suffix('.idx'))).decode().splitlines():
  c=line.split()
  if len(c)>4 and len(c[0])==40 and c[1]in ['commit','tree','tag','blob']:assert c[1]!='blob';objects.append(c[0])
 local=checks(C,objects);canon=checks(R,objects)
 for obj in objects:
  if local[obj].endswith(' missing'):
   _,kind,size=canon[obj].split();meta[obj]={'kind':kind,'canonical_bytes':int(size)}
 packs.append(pack)
raw=sum(x['canonical_bytes']for x in meta.values());assert raw<=ENVELOPE;save('CANONICAL-RAW-OBJECT-PRICE.json',{'new_metadata':meta,'canonical_raw_total':raw,'envelope':ENVELOPE,'new_source_blobs':0,'all_existing_tip_unique_blobs_verified':len(ids),'workspace_free':shutil.disk_usage('/workspace').free});assert snapshot()==before
allocation=0;rows=[]
for pack in packs:
 data=pack.read_bytes();assert hashlib.sha1(data[:-20]).digest()==data[-20:]
 for src in [pack,pack.with_suffix('.idx'),pack.with_suffix('.promisor')]:
  if not src.exists():continue
  dest=G/'objects/pack'/src.name;assert not dest.exists();temp=dest.with_name('.'+dest.name+'.marylanding-'+str(os.getpid()));shutil.copy2(src,temp);assert sha(src)==sha(temp);temp.rename(dest);allocation+=dest.stat().st_blocks*512;rows.append({'name':src.name,'bytes':src.stat().st_size,'sha256':sha(src)})
save('PACK-IMPORT.json',rows);assert git(C,'rev-parse',TIP+'^{tree}').decode().strip()==TREE;assert git(C,'merge-base',OLD,TIP).decode().strip()==OLD;assert snapshot()==before
remote=api('git/ref/heads/dev');save('REMOTE-BEFORE-CAS.json',remote);cas=remote['object']['sha']==TIP
if cas:git(C,'update-ref','refs/remotes/origin/dev',TIP,OLD)
after=snapshot();save('SOURCE-AFTER.json',after);assert after['metadata']==before['metadata']and after['HEAD']==before['HEAD']and after['status_sha256']==before['status_sha256'];assert after['refs']==([x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+TIP)for x in before['refs']]if cas else before['refs']);assert shutil.disk_usage('/workspace').free>=FLOOR
result={'status':'MARY1334_EXACT_STANDARD_MERGE_METADATA_IMPORT_EXPECTED_OLD_CAS_PASS'if cas else'EXACT_D210_OBJECTS_READY_REMOTE_MOVED_NO_CAS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old':OLD,'tip':TIP,'tree':TREE,'parents':[OLD,AUTHOR],'new_blob_count':0,'canonical_new_metadata_bytes':raw,'envelope':ENVELOPE,'actual_source_allocated_bytes':allocation,'all_tip_unique_blobs_sizes_verified':len(ids),'cached_origin_dev':git(C,'rev-parse','origin/dev').decode().strip(),'fresh_remote_dev':remote['object']['sha'],'source_HEAD_index_config_merge_status_unchanged':True,'all_other_refs_unchanged':True,'source_HEAD':before['HEAD'],'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free,'no_source_common_fetch_gc_repack_checkout':True};save('RESULT.json',result);print(json.dumps(result,indent=2))
