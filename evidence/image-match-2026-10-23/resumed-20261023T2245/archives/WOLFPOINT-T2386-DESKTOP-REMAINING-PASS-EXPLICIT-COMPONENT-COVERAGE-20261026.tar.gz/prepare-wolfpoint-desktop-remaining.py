from pathlib import Path
import shutil,subprocess,json
H=Path('/tmp/WolfPoint-T2386-desktop-remaining-20261026');H.mkdir(exist_ok=False)
old=Path('/tmp/WolfPoint-T2386-a575-final-app-20261026')
for p in ['APP-EXPECTED.json','SOURCE-BINDINGS.json']:shutil.copy2(old/p,H/p)
shutil.copy2(old/'app-qa/desktop-full-pose.json',H/'REUSED-EXACT-SOURCE-DESKTOP-POSE.json')
(H/'COMPONENT-REUSE.json').write_text(json.dumps({'prior_closed_manifest':str(old/'MANIFEST.json'),'prior_manifest_sha256':'047e07f55548d217eebc480a57c6cde85249e6a779b57ee48a00c3f85d490ab5','public_evidence_index':361,'reuse_only':['mobile full targetedPASS','desktop normal/ByGrade/Photos components'],'old_desktop_terminal_status':'INTERRUPTED143, remains partial; never relabeled fullPASS','new_scope':'One fresh ordinary desktop load on2,4, finish Sources/Lib/two native doors+freshHTTPWEB/maps/errors/caps. No new source/bake/variant/mobile/normalPNGloop.'},indent=2)+'\n')
print(H)
