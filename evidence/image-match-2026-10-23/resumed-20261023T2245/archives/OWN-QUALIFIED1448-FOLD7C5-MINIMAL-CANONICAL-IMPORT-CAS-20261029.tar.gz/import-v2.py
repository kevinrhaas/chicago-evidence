from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal,zlib,urllib.request,urllib.parse,struct
os.sched_setaffinity(0,{1});os.nice(19)
B=Path(__file__).parent;C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='ec9f5c932763e3a40df8cb15496d888df50f6a37';TIP='7c5f2109cc1db6a86e23d76b4127385b587adcee';CAP=64*1024**2;ENVELOPE=CAP;FLOOR=512*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(r,*args,input=None):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:sha(G/n)for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
def indexed(ids):
 wanted=set(ids);found=set();obj=G/'objects'
 for s in wanted:
  if(obj/s[:2]/s[2:]).is_file():found.add(s)
 for idx in(obj/'pack').glob('*.idx'):
  remaining=wanted-found
  if not remaining:break
  with idx.open('rb')as f:
   head=f.read(8);v2=head[:4]==b'\xfftOc';off=8 if v2 else 0
   if v2:assert struct.unpack('>I',head[4:])[0]==2
   f.seek(off);fan=struct.unpack('>256I',f.read(1024));table=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
   for s in remaining:
    key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
    while a<z:
     m=(a+z)//2;f.seek(table+m*stride+delta);value=f.read(20)
     if value<key:a=m+1
     else:z=m
    f.seek(table+a*stride+delta)
    if a<fan[key[0]]and f.read(20)==key:found.add(s)
 return found



P=Path('/tmp/current-dev-a7d7-readonly-price-20261029');tree=json.loads((P/'TREE.json').read_text());leaves=[r for r in tree['tree']if r['type']!='tree'];before=snap();save('SOURCE-BEFORE.json',before);assert git(C,'rev-parse','origin/dev').decode().strip()==OLD
remote=api('git/ref/heads/dev');save('REMOTE-BEFORE.json',remote);assert remote['object']['sha']==TIP
assert json.loads((B/'METADATA-FETCH.json').read_text())['exit']==0
actual={}
for row in git(R,'ls-tree','-r','-z',TIP).split(b'\0'):
 if row:
  a,n=row.split(b'\t',1);m,t,s=a.decode().split();actual[n.decode()]={'mode':m,'type':t,'sha':s}
assert actual=={r['path']:{k:r[k]for k in ['mode','type','sha']}for r in leaves}
allmeta={}
for idx in(R/'objects/pack').glob('*.idx'):
 for line in git(R,'show-index',input=idx.read_bytes()).decode().splitlines():allmeta[line.split()[1]]=None
for folder in(R/'objects').iterdir():
 if len(folder.name)==2 and folder.is_dir():
  for obj in folder.iterdir():
   if len(obj.name)==38:allmeta[folder.name+obj.name]=None
present=indexed(allmeta);newmeta=[]
if set(allmeta)-present:
 for line in git(R,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(sorted(set(allmeta)-present))+'\n').encode()).decode().splitlines():
  obj,kind,size=line.split();assert kind in ['commit','tree','tag'];newmeta.append({'sha':obj,'kind':kind,'bytes':int(size)})
known=indexed([r['sha']for r in leaves]);missing={r['sha']:r for r in leaves if r['sha']not in known};assert sum(r['size']for r in missing.values())<=3975984
raw=sum(r['size']for r in missing.values())+sum(r['bytes']for r in newmeta);assert raw<=CAP
save('EXACT-PRICE.json',{'canonical_new_raw_bytes':raw,'cap':CAP,'missing_tip_blobs':list(missing.values()),'new_metadata':newmeta,'isolated_metadata_ids':len(allmeta),'method':'ImportONLYunknowncanonicalmetadataaslooseobjects,avoidingduplicateknownpackcopy; qualifiedfeatureobjects alreadycommonindexed.','authorization':'RootOWNqualifieda7d744dmerge + genuine7c5ffold <=64MiB measured,floor512MiB,freshsourceguards/CAS.'})
assert snap()==before;allocated=0;rows=[]
def store(obj,kind,data,path):
 global allocated
 rawobj=kind.encode()+b' '+str(len(data)).encode()+b'\0'+data;assert hashlib.sha1(rawobj).hexdigest()==obj;dest=G/'objects'/obj[:2]/obj[2:];assert not dest.exists();dest.parent.mkdir(exist_ok=True);enc=zlib.compress(rawobj);assert shutil.disk_usage('/workspace').free>=FLOOR+len(enc)+4096;tmp=dest.with_name(dest.name+'.qualified-'+str(os.getpid()));tmp.write_bytes(enc);assert hashlib.sha1(zlib.decompress(tmp.read_bytes())).hexdigest()==obj;tmp.rename(dest);allocated+=dest.stat().st_blocks*512;rows.append({'sha':obj,'kind':kind,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoded_bytes':len(enc),'path':path})
for r in newmeta:
 data=git(R,'cat-file',r['kind'],r['sha']);assert len(data)==r['bytes'];store(r['sha'],r['kind'],data,'isolatedcanonicalmetadata')
for r in missing.values():
 with urllib.request.urlopen('https://raw.githubusercontent.com/kevinrhaas/chicago/'+TIP+'/'+urllib.parse.quote(r['path'],safe='/'),timeout=90)as response:data=response.read(r['size']+65536)
 assert len(data)==r['size'];store(r['sha'],'blob',data,r['path'])
save('CANONICAL-OBJECTS-IMPORTED.json',rows);allids={r['sha']for r in leaves};assert allids<=indexed(allids);ids=sorted({r['sha']for r in leaves if r['type']=='blob'});checks=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();sizes={x.split()[0]:int(x.split()[2])for x in checks};assert all(sizes[r['sha']]==r['size']for r in leaves if r['type']=='blob');assert git(C,'rev-parse',TIP+'^{tree}').decode().strip()==tree['sha']and git(C,'merge-base',OLD,TIP).decode().strip()==OLD;assert snap()==before
remote=api('git/ref/heads/dev');save('REMOTE-BEFORE-CAS.json',remote);cas=remote['object']['sha']==TIP
if cas:git(C,'update-ref','refs/remotes/origin/dev',TIP,OLD)
after=snap();save('SOURCE-AFTER.json',after);assert after['metadata']==before['metadata']and after['HEAD']==before['HEAD']and after['status_sha256']==before['status_sha256'];assert after['refs']==([x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+TIP)for x in before['refs']]if cas else before['refs'])
result={'status':'OWN_QUALIFIED_1448_AND_GENUINE_FOLD_IMPORT_EXPECTED_OLD_CAS_PASS'if cas else'OWN_QUALIFIED_IMMUTABLE_TIP_READY_REMOTE_MOVED_NO_CAS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old':OLD,'tip':TIP,'tree':tree['sha'],'qualified_merge':'a7d744d770d765c58d66a91e98b771ec6e85ddc5','canonical_new_raw_bytes':raw,'exact_canonical_envelope':raw,'actual_source_allocated_bytes':allocated,'new_metadata_objects':len(newmeta),'new_tip_blobs':len(missing),'all_tip_entries':len(leaves),'all_tip_unique_blob_ids_sizes_verified':len(ids),'sourceHEAD_index_MERGE_config_status_unchanged':True,'all_other_refs_unchanged':True,'cached_origin_dev':git(C,'rev-parse','origin/dev').decode().strip(),'fresh_remote_dev':remote['object']['sha'],'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free,'scope':'OWNactuallyqualified/mergedTGT1448 plus genuinechildfold; no extra globalgate neededforavailability. No nonqualifiedfeatureadded.'};save('RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
