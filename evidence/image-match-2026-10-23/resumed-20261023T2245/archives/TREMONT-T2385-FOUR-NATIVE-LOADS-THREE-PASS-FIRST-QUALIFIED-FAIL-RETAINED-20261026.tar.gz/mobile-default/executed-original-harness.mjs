// External finite review harness: native published URLs and native harness API only.
import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import crypto from 'node:crypto';import {createRequire} from 'node:module';
const args=process.argv.slice(2),opt=(k,d)=>{const i=args.indexOf(k);return i<0?d:args[i+1];};
const app=path.resolve(opt('--app','/tmp/tremont-picture-20261026/chicago/4d')),site=path.resolve(app,'../../site/4d');
const viewport=opt('--viewport','mobile');if(!['mobile','desktop'].includes(viewport))throw Error('Unknown viewport');
const out=path.resolve(opt('--out','/tmp/tremont-T2385-app-'+viewport+'-20261026'));
const ID='tremont_house_1',KEY=ID+'__frame_1833.glb',VKEY='versions/'+ID+'/gifford-reading/'+KEY;
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const expected=JSON.parse(fs.readFileSync(new URL('./expected.json',import.meta.url)));
for(const e of expected.records){if(sha(fs.readFileSync(path.join(app,e.path)))!==e.sha256)throw Error('Authored source drift: '+e.path);}
for(const e of expected.outputs){if(sha(fs.readFileSync(path.join(app,e.path)))!==e.sha256)throw Error('Native output drift: '+e.path);}
if(!args.includes('--execute')){console.log(JSON.stringify({status:'PREPARED_ONLY_NOT_EXECUTED',app,site,viewport,out,world_loads:2,limits:'No browser/publish/derive/gate. Root must lease actual app work; ordinary URL version selection reloads the same tab.'},null,2));process.exit(0);}
if(fs.existsSync(out))throw Error('Refuse to overwrite run');fs.mkdirSync(out,{recursive:true});
const report={status:'RUNNING',app,site,viewport,started:new Date().toISOString(),method:'Two ordinary published world loads in one tab: documented default and gifford-reading URL, visible native badge, native normal/ByGrade/card/flag/feet reads. Static held frames, no performance or photographic-match claim.',harness_sha256:sha(fs.readFileSync(new URL(import.meta.url))),source_config_sha256:sha(fs.readFileSync(new URL('./expected.json',import.meta.url))),cases:[],page_errors:[],http_errors:[],request_failures:[],loaded_meshes:[]};
const save=()=>fs.writeFileSync(path.join(out,'RESULT.json'),JSON.stringify(report,null,2)+'\n');save();
for(const e of expected.outputs.filter(e=>e.path.startsWith('assets/web/'))){const p='data/gltf/'+e.path.slice('assets/web/'.length);if(sha(fs.readFileSync(path.join(site,p)))!==e.sha256)throw Error('Published WEB binding drift: '+p);}
for(const p of ['main.js','structure-versions.js','scene-loader.js','hud.js','flags.js','flag-anchors.js','popup.js'])if(!fs.readFileSync(path.join(app,'renderers/web/js',p)).equals(fs.readFileSync(path.join(site,'walk/js',p))))throw Error('Published source drift: '+p);
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.glb':'model/gltf-binary','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.wasm':'application/wasm','.ktx2':'image/ktx2'};
const server=http.createServer((req,res)=>{try{const u=new URL(req.url,'http://local');let p=path.resolve(site,'.'+decodeURIComponent(u.pathname));if(p!==site&&!p.startsWith(site+path.sep)){res.writeHead(403);res.end();return;}if(fs.statSync(p).isDirectory())p=path.join(p,'index.html');res.writeHead(200,{'Content-Type':types[path.extname(p)]||'application/octet-stream'});fs.createReadStream(p).pipe(res);}catch{res.writeHead(404);res.end('missing');}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser,context,failure;const responseTasks=[],inflight=new Map();
try{
 const require=createRequire(path.join(app,'tools/qa.mjs'));const {chromium}=require('playwright');
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE||'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 context=await browser.newContext({viewport:viewport==='mobile'?{width:390,height:780}:{width:1280,height:800},deviceScaleFactor:viewport==='mobile'?2:1,isMobile:false,hasTouch:viewport==='mobile'});
 const page=await context.newPage();page.setDefaultTimeout(600000);let activeLabel='none';
 page.on('pageerror',e=>report.page_errors.push({version:activeLabel,error:String(e)}));page.on('request',r=>inflight.set(r,r.url()));page.on('requestfinished',r=>inflight.delete(r));page.on('requestfailed',r=>{inflight.delete(r);report.request_failures.push({version:activeLabel,url:r.url(),failure:r.failure()});});
 page.on('response',r=>{if(r.status()>=400)report.http_errors.push({version:activeLabel,url:r.url(),status:r.status()});if(r.url().split('?')[0].endsWith('/'+KEY)){const label=activeLabel;responseTasks.push((async()=>{const b=await r.body();report.loaded_meshes.push({version:label,url:r.url(),bytes:b.length,sha256:sha(b),status:r.status()});})().catch(e=>report.request_failures.push({version:label,url:r.url(),failure:String(e)})));}});
 let defaultCensus=null;
 for(const label of ['default','gifford-reading']){
  activeLabel=label;const row={version:label,started:new Date().toISOString(),load_started_ms:Date.now(),failures:[],url:`http://127.0.0.1:${server.address().port}/walk/?year=1835&structure=${ID}&version=${label}`};report.cases.push(row);save();
  await page.goto(row.url,{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:600000,polling:1000});
  row.boot_ms=Date.now()-row.load_started_ms;row.boot=await page.evaluate(()=>({ready:__chicago4d.ready,error:__chicago4d.error,scene:__chicago4d.scene?.id}));if(!row.boot.ready||row.boot.error||String(row.boot.scene)!=='1835')throw Error('Native boot failed: '+JSON.stringify(row.boot));
  row.entry=await page.evaluate(async detail=>{const a=__chicago4d;await a.setDetail(detail);const until=Date.now()+180000;let clicked=false;while(a.welcome?.state!=='world'&&Date.now()<until){const button=document.getElementById('home-roam');if(a.welcome?.state==='welcome'&&button?.checkVisibility()){button.click();clicked=true;}await new Promise(r=>setTimeout(r,100));}if(a.welcome?.state!=='world')throw Error('Native Free roam UI did not enter world');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();document.getElementById('roam-tip-dismiss')?.click();a.renderer.setAnimationLoop(null);a.setAnimationHold(true);a.setConfidenceView(false);a.step();return {nativeFreeRoamClicked:clicked,welcome:a.welcome.state,gateHidden:document.getElementById('gate').hidden};},viewport==='mobile'?'light':'full');if(!row.entry.nativeFreeRoamClicked||!row.entry.gateHidden)row.failures.push('Native Free roam entry UI not exercised');
  await page.waitForFunction(()=>document.getElementById('gate').hidden);
  row.actual=await page.evaluate(id=>{
   const a=__chicago4d,r=a.registry.get(id),m=a.buildings.matrixOf(id),b=a.buildings.instanceBounds()[id],feet=a.buildings.feetOf(id);if(!r||!m||!b||!feet?.length)throw Error('Missing native record/geometry');
   if(!a.frame(id,{card:false}))throw Error('Native frame failed');a.step();const v=m.elements;
   const xyz=(x,y,z)=>[v[0]*x+v[4]*y+v[8]*z+v[12],v[1]*x+v[5]*y+v[9]*z+v[13],v[2]*x+v[6]*y+v[10]*z+v[14]];
   const samples=feet.map(([x,z])=>{const [e,y,wz]=xyz(x,0,z),n=-wz;return {e,n,y,terrain:a.terrain.surfaceHeight(e,n),gap:y-a.terrain.surfaceHeight(e,n)};});
   const corners=r.sidecar.footprint.polygon.map(([u,n])=>{const p=xyz(u,0,-n);return [p[0]+a.datum.origin_utm_e,-p[2]+a.datum.origin_utm_n];});
   const flag=a.flags.drawn.find(f=>f.id===id),mesh=a.flags.group.getObjectByName('flag:'+id),an=r.sidecar.attributes.flag_anchor.value,head=xyz(an.head[0],an.head[2],-an.head[1]);
   const badge=document.getElementById('badge-version');const other={};for(const [k,v]of a.registry)if(k!==id)other[k]={asset:v.assetUrl,sidecar:v.sidecarUrl,attributes:JSON.stringify(v.sidecar),at:a.buildings.positionOf(k)?.toArray?.()??null};
   a.pick(id);const vf=document.querySelector('#popup .pop-flag-version');const versionFlag=vf?{text:vf.textContent,label:vf.dataset.version}:null;a.popup.close();a.step();
   return {sidecar:r.sidecar,assetUrl:r.assetUrl,sidecarUrl:r.sidecarUrl,versionState:a.structureVersion,badge:{hidden:badge.hidden,text:badge.textContent,tone:badge.dataset.tone,title:badge.title},versionFlag,bounds:b,frontages:{east:Math.max(...corners.map(p=>p[0])),south:Math.min(...corners.map(p=>p[1]))},samples,maxGap:Math.max(...samples.map(p=>p.gap)),minGap:Math.min(...samples.map(p=>p.gap)),flag:{drawn:flag??null,mesh:!!mesh,visible:mesh?.visible??false,holder:mesh?.parent.position.toArray()??null,expectedHolder:[head[0],head[1]-.18,head[2]]},stats:a.stats(),problems:a.problems,targetProblems:a.problems.filter(p=>p.includes(id)),other,player:{e:a.player.e,n:a.player.n,blocked:a.router.blockedAt(a.player.e,a.player.n)}};
  },ID);
  const act=row.actual;const want=label==='default'?expected.default:expected.version;
  if(act.sidecar.attributes.stories.value!==want.stories||act.sidecar.attributes.wall_height_m.value!==want.wallHeight||act.sidecar.attributes.paint.value!==want.paint||act.sidecar.attributes.shutters.value!==want.shutters)row.failures.push('Loaded attributes disagree with source');
  if(act.badge.hidden||act.badge.text!==`version ${label}`||act.versionState.notice)row.failures.push('Native version badge/state incorrect');
  if(label==='gifford-reading'&&(act.versionFlag?.label!==label||!act.assetUrl.includes('/versions/tremont_house_1/gifford-reading/')))row.failures.push('Version sidecar/mesh/card not selected');
  if(label==='default'&&act.versionState.explicitDefault!==true)row.failures.push('Canonical state is not explicit default');
  if(Math.abs(act.frontages.east-447760.52)>.03||Math.abs(act.frontages.south-4637295.24)>.03)row.failures.push('Actual native frontage plane moved');
  if(act.maxGap>.15||act.minGap<-.35)row.failures.push('Actual native wall feet hover/bury beyond review limits');
  if(!act.flag.drawn||!act.flag.mesh||!act.flag.visible||act.flag.holder.some((x,i)=>Math.abs(x-act.flag.expectedHolder[i])>.03))row.failures.push('Dynamic flag missing or detached from explicit staff anchor');
  if(!act.stats.withinBudget||act.player.blocked||act.targetProblems.length)row.failures.push('Native budget/placement/target problem');
  if(defaultCensus){const before=Object.keys(defaultCensus).sort(),after=Object.keys(act.other).sort();const moved=before.filter(k=>JSON.stringify(defaultCensus[k])!==JSON.stringify(act.other[k]));if(JSON.stringify(before)!==JSON.stringify(after)||moved.length)row.failures.push('Other structure registry/placement changed between native versions: '+moved.slice(0,5).join(','));}else defaultCensus=act.other;
  delete act.other;
  await page.screenshot({timeout:180000,path:path.join(out,label+'-normal.png')});
  await page.keyboard.press('c');await page.evaluate(()=>{if(!__chicago4d.confidenceView)throw Error('Native C key did not select By grade');__chicago4d.step();});await page.screenshot({timeout:180000,path:path.join(out,label+'-by-grade.png')});
  await page.keyboard.press('c');await page.evaluate(()=>{if(__chicago4d.confidenceView)throw Error('Native C key did not restore Normal');__chicago4d.step();});
  row.fly=await page.evaluate(id=>{const a=__chicago4d;const f=a.framing(id,{card:false,mode:'fly'});if(!f)throw Error('Native fly framing absent');a.setFly(true);a.walker.teleport({local_e:f.e,local_n:f.n,altitude_m:5,yaw_deg:0,pitch_deg:0});const st=a.walker.state,de=f.aim.x-st.e,dn=-f.aim.z-st.n;const yaw=((Math.atan2(de,dn)*180/Math.PI)+360)%360+f.yawOffsetDeg,pitch=Math.atan2(f.aim.y-st.eyeY,Math.max(Math.hypot(de,dn),.1))*180/Math.PI+f.pitchOffsetDeg;a.walker.teleport({local_e:st.e,local_n:st.n,altitude_m:5,yaw_deg:yaw,pitch_deg:pitch});a.step();return {api:a.flying,walker:a.walker.state.flying,player:a.player.flying,intent:a.intent.flying,hud:a.hud.flying,button:document.getElementById('btn-fly')?.getAttribute('aria-pressed'),altitude:a.player.altitude,stats:a.stats()};},ID);
  if(!['api','walker','player','intent','hud'].every(k=>row.fly[k]===true)||row.fly.button!=='true'||Math.abs(row.fly.altitude-5)>.03||!row.fly.stats.withinBudget)row.failures.push('Native fly pose lost walker/HUD/intent state or budget');
  await page.screenshot({timeout:180000,path:path.join(out,label+'-native-fly.png')});
  await page.evaluate(id=>{const a=__chicago4d;a.setFly(false);a.frame(id,{card:false,mode:'walk'});a.step();},ID);
  row.cards=await page.evaluate(async id=>{
   const a=__chicago4d;const wait=async f=>{const end=Date.now()+30000;while(!f()&&Date.now()<end)await new Promise(r=>setTimeout(r,100));if(!f())throw Error('Native card timed out');};
   a.openBuilding(id);const root=()=>document.getElementById('nav-app-inspect');await wait(()=>root()?.dataset.structure===id&&root().querySelector('.insp-tabs'));const out={};
   for(const key of ['photos','sources']){root().querySelector(`[data-insp-tab="${key}"]`)?.click();const pane=()=>root()?.querySelector(`[data-insp-pane="${key}"]`);await wait(()=>['yes','failed'].includes(pane()?.dataset.filled));pane().querySelectorAll('details').forEach(d=>d.open=true);out[key]={filled:pane().dataset.filled,text:pane().innerText,links:[...pane().querySelectorAll('a[href]')].map(n=>({href:n.href,text:n.textContent.trim()})),credits:[...pane().querySelectorAll('.ph-credit,.ph-link-list .nav-sub')].map(n=>n.textContent.trim()),overflow:document.documentElement.scrollWidth>innerWidth};}
   return out;
  },ID);
  if(!row.cards.photos.credits.some(x=>/Gifford/i.test(x))||!row.cards.photos.links.some(x=>x.href==='https://chicagology.com/prefire/prefire021/'))row.failures.push('Attributed Gifford picture/link absent');
  if(!/Gale/.test(row.cards.sources.text)||!row.cards.sources.links.some(x=>x.href.includes('reminiscencesofe00ingale')))row.failures.push('Actual Sources lacks Gale citation/link');
  if(row.cards.photos.filled!=='yes'||row.cards.sources.filled!=='yes'||row.cards.photos.overflow||row.cards.sources.overflow)row.failures.push('Native Inspect card failed or overflows viewport');
  for(const key of ['photos','sources']){await page.evaluate(key=>document.querySelector(`#nav-app-inspect [data-insp-tab="${key}"]`)?.click(),key);await page.screenshot({timeout:180000,path:path.join(out,label+'-'+key+'.png')});}
  await page.evaluate(async()=>{const a=__chicago4d;a.closeBuilding();a.navigator.select('home');a.navigator.dock();await a.loadLiberties();a.pick('tremont_house_1');const r=document.getElementById('popup');r.querySelector('[data-pop-tab="liberties"]')?.click();r.querySelectorAll('[data-pop-pane="liberties"] details').forEach(d=>d.open=true);});
  row.liberties=await page.evaluate(()=>({text:document.getElementById('popup').innerText,libertyLinks:[...document.querySelectorAll('#popup a[href]')].map(n=>({href:n.href,text:n.textContent.trim()})),version:document.querySelector('#popup .pop-flag-version')?.textContent??null}));
  await page.screenshot({timeout:180000,path:path.join(out,label+'-popup.png')});await page.evaluate(()=>__chicago4d.popup.close());
  if(!/liberties/i.test(row.liberties.text)||!/two-storey default and picture alternative/i.test(row.liberties.text))row.failures.push('Native card does not expose the current Tremont evidence/reconstruction liberty');
  const end=Date.now()+30000;while(inflight.size&&Date.now()<end)await new Promise(r=>setTimeout(r,100));if(inflight.size)row.failures.push('Native requests still pending before next world load');
  await Promise.all(responseTasks);const selected=report.loaded_meshes.filter(x=>x.version===label);const wanted=expected.outputs.find(e=>e.path==='assets/web/'+(label==='default'?KEY:VKEY));
  if(!selected.length||selected.some(x=>x.status!==200||x.sha256!==wanted.sha256))row.failures.push('Actual fetched WEB bytes do not match selected native artifact');
  row.finished=new Date().toISOString();row.elapsed_ms=Date.now()-row.load_started_ms;save();if(row.failures.length)throw Error(label+': '+row.failures.join('; '));
 }
 if(report.page_errors.length||report.http_errors.length||report.request_failures.length)throw Error('Unfiltered page/network errors');report.status='PASS_TARGETED_NATIVE_VERSIONS_NOT_IMAGE_MATCH';
}catch(e){failure=e;report.status='FAIL';report.error=String(e.stack||e);}finally{try{await context?.close();}catch(e){report.cleanup_error=String(e);failure??=e;}try{await browser?.close();}catch(e){report.cleanup_error=String(e);failure??=e;}await new Promise(r=>server.close(r));report.finished=new Date().toISOString();save();}
console.log(JSON.stringify({status:report.status,out,error:report.error??null},null,2));if(failure)process.exitCode=1;
