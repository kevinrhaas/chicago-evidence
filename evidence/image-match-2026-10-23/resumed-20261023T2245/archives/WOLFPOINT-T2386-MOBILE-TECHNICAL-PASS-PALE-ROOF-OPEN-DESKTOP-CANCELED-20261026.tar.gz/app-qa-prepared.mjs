import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire('/workspace/shared/node/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const root='/workspace/chicago/site',sid='wolf_point_tavern';
const home='/tmp/WolfPoint-T2386-native-candidate-app-20261026',out=process.env.WOLF_APP_OUT||path.join(home,'app-qa');fs.mkdirSync(out);
const expected=JSON.parse(fs.readFileSync(path.join(home,'APP-EXPECTED.json')));
const expectedWEB='34124fabeea096bd1e977f82596ba9df21533320ad57ae2b173ad40102a8bb6d';
for(const b of JSON.parse(fs.readFileSync(path.join(home,'SOURCE-BINDINGS.json'))).paths){assert.equal(crypto.createHash('sha256').update(fs.readFileSync(b.path)).digest('hex'),b.sha256,b.path);}
assert.equal(crypto.createHash('sha256').update(fs.readFileSync(root+'/4d/data/gltf/wolf_point_tavern__log_frame_1828.glb')).digest('hex'),expectedWEB);
const write=(name,x)=>fs.writeFileSync(path.join(out,name),JSON.stringify(x,null,2)+'\n');
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon'};
const serverErrors=[];
const server=http.createServer((req,res)=>{try{
 let file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
 if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
 if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
 if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
 res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');
 const stream=fs.createReadStream(file);stream.on('error',e=>{serverErrors.push(e.message);res.destroy(e);});stream.pipe(res);
}catch(e){serverErrors.push(e.message);res.writeHead(500).end();}});
async function settle(page){await page.locator('.navigator').evaluate(async n=>{
 for(let k=0;k<4;k++){const active=n.getAnimations().filter(a=>Number.isFinite(a.effect.getComputedTiming().endTime));if(!active.length)return;await Promise.all(active.map(a=>a.finished.catch(e=>{if(e.name!=='AbortError')throw e;})));}
});}
async function pane(page,key){await page.locator(`#nav-app-inspect [data-insp-tab="${key}"]`).click();await page.waitForFunction(k=>document.querySelector(`#nav-app-inspect [data-insp-pane="${k}"]`)?.dataset.filled==='yes',key,{timeout:45000});await settle(page);return page.locator(`#nav-app-inspect [data-insp-pane="${key}"]`);}
async function observe(page,target,label,key){
 const x=await target.evaluate(p=>({text:p.innerText,links:[...p.querySelectorAll('a')].filter(a=>a.checkVisibility()).map(a=>a.href),visible:p.checkVisibility(),pageOverflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1}));
 write(`${label}-${key}.json`,x);assert(x.visible);assert(!x.pageOverflow);assert(!x.paneOverflow);await page.screenshot({path:path.join(out,`${label}-${key}.png`)});return x;
}
let browser;const results=[];
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE||'/usr/bin/chromium',args:['--enable-unsafe-swiftshader']});
 for(const [label,width,height,touch] of [['mobile',390,780,true],['desktop',1280,800,false]].filter(x=>!process.env.WOLF_VIEWPORT||x[0]===process.env.WOLF_VIEWPORT)){
  if(fs.existsSync(path.join(home,'STOP_AFTER_CURRENT_CASE'))){write('deferred-viewport.json',{viewport:label,reason:'Root resource handoff; no new context started'});break;}
  write('PHASE.json',{phase:'starting',viewport:label,at:new Date().toISOString(),cpu_affinity:fs.readFileSync('/proc/self/status','utf8').match(/^Cpus_allowed_list:\s*(.+)$/m)?.[1]});
  const context=await browser.newContext({viewport:{width,height},hasTouch:touch,deviceScaleFactor:touch?2:1});const errors=[],network=[],cancelled=[],responses=[],responseWork=[];let page;
  try{
   await context.addInitScript(()=>localStorage.setItem('chicago4d.researcher','on'));
   page=await context.newPage();page.setDefaultTimeout(180000);page.on('pageerror',e=>errors.push(e.message));
   page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});if(r.url().endsWith('wolf_point_tavern__log_frame_1828.glb'))responseWork.push(r.body().then(b=>responses.push({url:r.url(),status:r.status(),bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')})));});
   page.on('requestfailed',r=>{const v={url:r.url(),failure:r.failure()};if(r.failure()?.errorText==='net::ERR_ABORTED')cancelled.push(v);else network.push(v);});
   const navStart=Date.now();const response=await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835&keep-geometry=1`);assert.equal(response.status(),200);
   await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:600000,polling:1000});const readyAt=Date.now();console.log(`${label}: actual APIready after ${readyAt-navStart}ms`);
   await page.evaluate(async sid=>{const a=window.__chicago4d,end=Date.now()+90000;while(a.welcome?.state!=='world'&&Date.now()<end){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}if(a.welcome&&a.welcome.state!=='world')throw Error('welcome did not enter world');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.setAnimationHold(true);a.navigator.dock();a.popup.close();await a.capture(1);if(a.welcome.state!=='world'||!document.getElementById('gate').hidden)throw Error('Home still shown');},sid);const worldAt=Date.now();console.log(`${label}: actual welcome/world/firsttargetcapture after ${worldAt-navStart}ms`);
   const data=await page.evaluate(sid=>{const a=window.__chicago4d,s=a.registry.get(sid)?.sidecar;return{grade:s?.grade,attributes:s?.attributes,phase:s?.phase,placement:s?.placement,bounds:a.buildings.instanceBounds()[sid],matrix:a.buildings.matrixOf(sid)?.elements,feet:a.buildings.feetOf(sid),problems:a.problems??[],expectedReviews:[...a.registry.values()].filter(r=>r.sidecar?.review_required).map(r=>r.sidecar.id).sort(),scene:a.scene?.id};},sid);
   write(`${label}-diagnostic.json`,{data,errors,network});assert.equal(data.scene,'1835');assert.equal(data.phase,'log_frame_1828');assert.deepEqual(data.grade,expected.grade);
   for(const[k,v]of Object.entries(expected.attributes)){assert.deepEqual(data.attributes[k]?.value,v.value,k+' value');assert.equal(data.attributes[k]?.confidence,v.confidence,k+' confidence');}
   for(const[k,v]of Object.entries(expected.placement))assert.deepEqual(data.placement[k],v,'placement '+k);
   assert(data.bounds.size.every(x=>Number.isFinite(x)&&x>0));assert.deepEqual(data.problems.filter(p=>/review_required is set/.test(p)).map(p=>p.split(':',1)[0]).sort(),data.expectedReviews);
   const unexpected=data.problems.filter(p=>!/provisional|PLACEHOLDER|placeholder|review_required is set/i.test(p));assert.deepEqual(unexpected,[]);
   const roof=await page.evaluate(()=>{const a=window.__chicago4d,rows=[];a.buildings.group.traverse(o=>{if(!o.isMesh||!o.userData?.batchIndex?.includes('wolf_point_tavern'))return;for(const m of[o.material].flat()){if(m?.userData?.chiRoofRelief==='roof_shingle')rows.push({name:m.name,normal:!!m.normalMap,normalSize:[m.normalMap?.image?.width,m.normalMap?.image?.height],sharedORM:!!m.roughnessMap&&m.roughnessMap===m.aoMap,basecolourMap:!!m.map,patch:m.customProgramCacheKey?.()});}});return rows;});write(`${label}-native-roof-bindings.json`,roof);assert(roof.length&&roof.every(x=>x.normal&&x.sharedORM&&!x.basecolourMap));
   const poses=[];
   for(const kind of ['full']){
    const pose=await page.evaluate(async({sid,kind,mobile})=>{
     const a=window.__chicago4d,s=a.registry.get(sid).sidecar,b=a.buildings.instanceBounds()[sid],m=a.buildings.matrixOf(sid).elements,poly=s.footprint.polygon;
     const loU=Math.min(...poly.map(x=>x[0])),hiU=Math.max(...poly.map(x=>x[0])),hiV=Math.max(...poly.map(x=>x[1]));
     const world=(u,v,y)=>({e:m[0]*u+m[4]*y-m[8]*v+m[12],n:-(m[2]*u+m[6]*y-m[10]*v+m[14]),y:m[1]*u+m[5]*y-m[9]*v+m[13]});
     const midU=(b.min[0]+b.max[0])/2,midV=-(b.min[2]+b.max[2])/2;
     const aim=world(midU,midV,b.min[1]+.4*(b.max[1]-b.min[1]));a.setFly(true);let result;
     for(let scale=1;scale<=3;scale+=.25){
      const eye={e:aim.e+(-52-aim.e)*scale,n:aim.n+(-72-aim.n)*scale,y:a.walker.surfaceAt(-52,-72)+8*scale};
      const yaw=Math.atan2(aim.e-eye.e,aim.n-eye.n)*180/Math.PI,pitch=Math.atan2(aim.y-eye.y,Math.hypot(aim.e-eye.e,aim.n-eye.n))*180/Math.PI;
      a.walker.teleport({local_e:eye.e,local_n:eye.n,yaw_deg:yaw,pitch_deg:pitch,altitude_m:eye.y-a.walker.surfaceAt(eye.e,eye.n)});await a.capture(1);
      const corners=[];for(const u of [b.min[0],b.max[0]])for(const v of [-b.max[2],-b.min[2]])for(const y of [b.min[1],b.max[1]]){const w=world(u,v,y);corners.push({...w,...a.project(w.e,w.n,w.y)});}
      result={kind,eye,aim,yaw,pitch,scale,corners,state:{...a.walker.state},liveFly:{walker:a.walker.state.flying,hud:a.hud.flying,intent:a.intent.flying}};
      if(kind==='front'||corners.every(c=>Math.abs(c.x)<.88&&Math.abs(c.y)<.88&&c.z>-1&&c.z<1))break;
     }
     if(kind==='full'&&!result.corners.every(c=>Math.abs(c.x)<.88&&Math.abs(c.y)<.88&&c.z>-1&&c.z<1))throw Error('full model does not fit view');return result;
    },{sid,kind,mobile:touch});poses.push(pose);write(`${label}-${kind}-pose.json`,pose);
    write('PHASE.json',{phase:'normal-and-ByGrade',viewport:label,at:new Date().toISOString()});
    for(const[view,on]of[['normal',false],['confidence',true]]){await page.evaluate(async on=>{const a=window.__chicago4d;a.setConfidenceView(on);await a.capture(1);},on);const ui=await page.evaluate(()=>({world:window.__chicago4d.welcome.state==='world',homeHidden:document.getElementById('gate').hidden,cardClosed:window.__chicago4d.popup.openId===null&&document.getElementById('popup').hidden}));assert(ui.world&&ui.homeHidden&&ui.cardClosed);write(`${label}-${kind}-${view}-ui.json`,ui);await page.screenshot({path:path.join(out,`${label}-${kind}-${view}.png`),timeout:180000});const x=await page.evaluate(()=>{const a=window.__chicago4d;return{...a.stats(),confidenceView:a.confidenceView,flying:a.walker.state.flying,hudFlying:a.hud.flying,intentFlying:a.intent.flying};});write(`${label}-${kind}-${view}-stats.json`,x);assert.equal(x.confidenceView,on);assert(x.flying&&x.hudFlying&&x.intentFlying);assert(x.withinBudget,`${label}/${kind}/${view} budget`);}
   }
   await page.evaluate(async sid=>{const a=window.__chicago4d;a.setConfidenceView(false);a.pick(sid);await a.navigator.select('inspect');a.navigator.open(2);},sid);await page.waitForFunction(sid=>document.querySelector('#nav-app-inspect')?.dataset.structure===sid,sid);
   const photosPane=await pane(page,'photos');await photosPane.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});const photos=await observe(page,photosPane,label,'photos');assert.match(photos.text,/Blanchard|Shober|NYPL|New York Public Library/i);
   const sourcesPane=await pane(page,'sources');await sourcesPane.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});const sources=await observe(page,sourcesPane,label,'sources');assert.match(sources.text,/Blanchard/i);assert.match(sources.text,/Shober/i);assert.match(sources.text,/1867/i);assert.match(sources.text,/A picture-bounded roof tone/i);
   const liberty=sourcesPane.locator('.src-lib').filter({hasText:'A picture-bounded roof tone'});assert.equal(await liberty.count(),1);await liberty.locator(':scope > summary').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(out,`${label}-building-liberty.png`)});write(`${label}-building-liberty.json`,{visible:await liberty.isVisible(),text:await liberty.innerText()});
   write('PHASE.json',{phase:'actual-native-ground',viewport:label,at:new Date().toISOString()});
   const contacts=await page.evaluate(async({sid,expectedDoors})=>{
    const a=window.__chicago4d,doc=await fetch('../data/enclosures/town_entrance_aprons.json').then(r=>{if(!r.ok)throw Error('native entrances unavailable');return r.json();});const doors=doc.entrances.filter(x=>x.structure_id===sid);
    if(JSON.stringify(doors)!==JSON.stringify(expectedDoors))throw Error('Native doors differ from frozen source');a.setConfidenceView(false);a.setFly(false);a.popup.close();a.navigator.dock();const samples=[];
    for(const door of doors){const angle=door.bearing_deg*Math.PI/180,outward={e:Math.sin(angle),n:Math.cos(angle)};
     for(const distance of [3,2]){const e=door.at_local_enu_m[0]+outward.e*distance,n=door.at_local_enu_m[1]+outward.n*distance;a.walker.teleport({local_e:e,local_n:n,yaw_deg:(door.bearing_deg+180)%360});await a.capture(1);samples.push({door:door.id,distance,e,n,water:a.terrain.isWater(e,n),surface:a.walker.surfaceAt(e,n),routed:a.router.heightAt(e,n),blocked:a.router.blockedAt(e,n),ground:a.walker.state.groundY,eye:a.walker.state.eyeY,actualE:a.walker.state.e,actualN:a.walker.state.n,flying:a.walker.state.flying,hudFlying:a.hud.flying,intentFlying:a.intent.flying});}
    }return{doors,samples,scope:'Existing two native door approaches only; no interior/passable aperture claim.'};
   },{sid,expectedDoors:expected.entrances});write(`${label}-ground-contacts.json`,contacts);assert.equal(contacts.doors.length,2);
   for(const c of contacts.samples){assert(!c.water);assert.equal(c.blocked,false);assert(!c.flying&&!c.hudFlying&&!c.intentFlying);assert(Math.abs(c.ground-c.surface)<1e-6);assert(c.eye>c.ground&&Number.isFinite(c.routed));assert(Math.hypot(c.actualE-c.e,c.actualN-c.n)<.01);}
   await page.screenshot({path:path.join(out,`${label}-ground-contact.png`)});await Promise.all(responseWork);assert(responses.length);assert(responses.every(r=>r.status===200&&r.sha256===expectedWEB));assert.deepEqual(errors,[]);assert.deepEqual(network,[]);assert.deepEqual(serverErrors,[]);
   const result={status:'PASS',timings:{navigation_to_api_ready_ms:readyAt-navStart,navigation_to_world_first_target_capture_ms:worldAt-navStart,viewport_total_ms:Date.now()-navStart},viewport:label,width,height,errors,network,cancelled,servedTargetWEB:responses,loaderUnexpected:unexpected,poses,contacts,photos,sources,limit:'Actual targeted published app review, not full renderer smoke or source-picture acceptance.'};results.push(result);write(`${label}-result.json`,result);console.log(`${label}: actual app/grade/Images/Sources/liberty/grounded entry PASS`);
  }catch(e){write(`${label}-failure.json`,{message:e.message,stack:e.stack,errors,network,cancelled,responses});if(page)await page.screenshot({path:path.join(out,`${label}-failure.png`)}).catch(()=>{});throw e;}
  finally{await context.close();}
 }
 write('results.json',{status:results.length===2?'BOTH_VIEWPORTS_TARGETED_APP_PASS':'STARTED_VIEWPORT_PASS_REMAINING_DEFERRED',results,serverErrors,sourceBase:'cb93ad9cd5ea38654737e05002b1f1904be14e54',candidateWEB:expectedWEB,noFpsClaim:true});
}finally{if(browser)await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));}
