from pathlib import Path
import json,hashlib
home=Path('/tmp/WolfPoint-T2386-native-candidate-app-20261026');app=Path('/workspace/chicago/chicago/4d');s=Path('/tmp/st-mary-runtime-20261025/app-qa-proposal.mjs').read_text()
s=s.replace("root='/tmp/st-mary-picture-20261025/site',sid='st_marys_church'","root='/workspace/chicago/site',sid='wolf_point_tavern'")
s=s.replace("home='/tmp/st-mary-runtime-20261025'","home='/tmp/WolfPoint-T2386-native-candidate-app-20261026'").replace('process.env.ST_MARY_APP_OUT','process.env.WOLF_APP_OUT')
s=s.replace('9058e91e464a1fbbf773eddfaffddf73304e67f3712cc9ca8e47ae7820465207','34124fabeea096bd1e977f82596ba9df21533320ad57ae2b173ad40102a8bb6d')
s=s.replace("['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']","['--enable-unsafe-swiftshader']")
s=s.replace("const context=await browser.newContext", "if(fs.existsSync(path.join(home,'STOP_AFTER_CURRENT_CASE'))){write('deferred-viewport.json',{viewport:label,reason:'Root resource handoff; no new context started'});break;}\n  write('PHASE.json',{phase:'starting',viewport:label,at:new Date().toISOString(),cpu_affinity:fs.readFileSync('/proc/self/status','utf8').match(/^Cpus_allowed_list:\\s*(.+)$/m)?.[1]});\n  const context=await browser.newContext")
s=s.replace('page.setDefaultTimeout(90000)','page.setDefaultTimeout(180000)')
s=s.replace('timeout:240000','timeout:600000')
s=s.replace("endsWith('st_marys_church__frame_1833.glb')","endsWith('wolf_point_tavern__log_frame_1828.glb')")
s=s.replace("assert.equal(data.phase,'frame_1833')","assert.equal(data.phase,'log_frame_1828')")
s=s.replace("if(!a.frame(sid))throw Error('St Mary cannot frame');await a.capture(1);", "a.popup.close();await a.capture(1);if(a.welcome.state!=='world'||!document.getElementById('gate').hidden)throw Error('Home still shown');")
s=s.replace("const aim=kind==='full'?world(midU,midV,(b.min[1]+b.max[1])/2):world((loU+hiU)/2,hiV,2.4);a.setFly(true);let result;", "const aim=world(midU,midV,b.min[1]+.4*(b.max[1]-b.min[1]));a.setFly(true);let result;")
s=s.replace("const eye=kind==='full'?world(midU-18*scale,hiV+20*scale,9*scale):world((loU+hiU)/2,hiV+(mobile?18:10),2.4);", "const eye={e:aim.e+(-52-aim.e)*scale,n:aim.n+(-72-aim.n)*scale,y:a.walker.surfaceAt(-52,-72)+8*scale};")
s=s.replace("for(const[view,on]of[['normal',false],['confidence',true]])", "write('PHASE.json',{phase:'normal-and-ByGrade',viewport:label,at:new Date().toISOString()});\n    for(const[view,on]of[['normal',false],['confidence',true]])")
s=s.replace("await page.screenshot({path:path.join(out,`${label}-${kind}-${view}.png`)});", "const ui=await page.evaluate(()=>({world:window.__chicago4d.welcome.state==='world',homeHidden:document.getElementById('gate').hidden,cardClosed:window.__chicago4d.popup.openId===null&&document.getElementById('popup').hidden}));assert(ui.world&&ui.homeHidden&&ui.cardClosed);write(`${label}-${kind}-${view}-ui.json`,ui);await page.screenshot({path:path.join(out,`${label}-${kind}-${view}.png`),timeout:180000});")
s=s.replace("assert.match(photos.text,/Andreas/i);assert(photos.text.includes(\"Saint Mary's Church\"));assert.match(photos.text,/Moss Engraving Co/i);", "assert.match(photos.text,/Blanchard|Shober|NYPL|New York Public Library/i);")
s=s.replace("assert.match(sources.text,/Andreas/i);assert.match(sources.text,/A pictured chapel form for St Mary/i);", "assert.match(sources.text,/Blanchard/i);assert.match(sources.text,/Shober/i);assert.match(sources.text,/1867/i);assert.match(sources.text,/A picture-bounded roof tone/i);")
s=s.replace("hasText:'A pictured chapel form for St Mary'","hasText:'A picture-bounded roof tone'")
a=s.index('   const contacts=await page.evaluate(async sid=>{');b=s.index('   await page.screenshot({path:path.join(out,`${label}-ground-contact.png`)});',a)
s=s[:a]+'''   write('PHASE.json',{phase:'actual-native-ground',viewport:label,at:new Date().toISOString()});
   const contacts=await page.evaluate(async({sid,expectedDoors})=>{
    const a=window.__chicago4d,doc=await fetch('../data/enclosures/town_entrance_aprons.json').then(r=>{if(!r.ok)throw Error('native entrances unavailable');return r.json();});const doors=doc.entrances.filter(x=>x.structure_id===sid);
    if(JSON.stringify(doors)!==JSON.stringify(expectedDoors))throw Error('Native doors differ from frozen source');a.setConfidenceView(false);a.setFly(false);a.popup.close();a.navigator.dock();const samples=[];
    for(const door of doors){const angle=door.bearing_deg*Math.PI/180,outward={e:Math.sin(angle),n:Math.cos(angle)};
     for(const distance of [3,2]){const e=door.at_local_enu_m[0]+outward.e*distance,n=door.at_local_enu_m[1]+outward.n*distance;a.walker.teleport({local_e:e,local_n:n,yaw_deg:(door.bearing_deg+180)%360});await a.capture(1);samples.push({door:door.id,distance,e,n,water:a.terrain.isWater(e,n),surface:a.walker.surfaceAt(e,n),routed:a.router.heightAt(e,n),blocked:a.router.blockedAt(e,n),ground:a.walker.state.groundY,eye:a.walker.state.eyeY,actualE:a.walker.state.e,actualN:a.walker.state.n,flying:a.walker.state.flying,hudFlying:a.hud.flying,intentFlying:a.intent.flying});}
    }return{doors,samples,scope:'Existing two native door approaches only; no interior/passable aperture claim.'};
   },{sid,expectedDoors:expected.entrances});write(`${label}-ground-contacts.json`,contacts);assert.equal(contacts.doors.length,2);
   for(const c of contacts.samples){assert(!c.water);assert.equal(c.blocked,false);assert(!c.flying&&!c.hudFlying&&!c.intentFlying);assert(Math.abs(c.ground-c.surface)<1e-6);assert(c.eye>c.ground&&Number.isFinite(c.routed));assert(Math.hypot(c.actualE-c.e,c.actualN-c.n)<.01);}
''' +s[b:]
s=s.replace("write('results.json',{status:'PASS',results,serverErrors});", "write('results.json',{status:results.length===2?'BOTH_VIEWPORTS_TARGETED_APP_PASS':'STARTED_VIEWPORT_PASS_REMAINING_DEFERRED',results,serverErrors,sourceBase:'cb93ad9cd5ea38654737e05002b1f1904be14e54',candidateWEB:expectedWEB,noFpsClaim:true});")
# Actual roof maps on Wolf batch, read without changing materials/scene.
anchor="   const poses=[];"
insert="""   const roof=await page.evaluate(()=>{const a=window.__chicago4d,rows=[];a.buildings.group.traverse(o=>{if(!o.isMesh||!o.userData?.batchIndex?.includes('wolf_point_tavern'))return;for(const m of[o.material].flat()){if(m?.userData?.chiRoofRelief==='roof_shingle')rows.push({name:m.name,normal:!!m.normalMap,normalSize:[m.normalMap?.image?.width,m.normalMap?.image?.height],sharedORM:!!m.roughnessMap&&m.roughnessMap===m.aoMap,basecolourMap:!!m.map,patch:m.customProgramCacheKey?.()});}});return rows;});write(`${label}-native-roof-bindings.json`,roof);assert(roof.length&&roof.every(x=>x.normal&&x.sharedORM&&!x.basecolourMap));
   const poses=[];"""
s=s.replace(anchor,insert)
(home/'app-qa-prepared.mjs').write_text(s)
side=json.loads((app/'data/sidecars/1835/wolf_point_tavern.json').read_bytes());side['entrances']=[r for r in json.loads((app/'data/enclosures/town_entrance_aprons.json').read_bytes())['entrances']if r['structure_id']=='wolf_point_tavern'];(home/'APP-EXPECTED.json').write_text(json.dumps(side,indent=2)+'\n')
files=['data/sidecars/1835/wolf_point_tavern.json','data/structures/wolf_point_tavern.json','assets/gltf/wolf_point_tavern__log_frame_1828.glb','assets/web/wolf_point_tavern__log_frame_1828.glb','data/enclosures/town_entrance_aprons.json','data/pictures/1835.json','data/liberties.json','renderers/web/js/main.js','renderers/web/js/roof-relief.js']
(home/'SOURCE-BINDINGS.json').write_text(json.dumps({'base':'cb93ad9cd5ea38654737e05002b1f1904be14e54','ownedWIP':True,'paths':[{'path':str(app/p),'bytes':(app/p).stat().st_size,'sha256':hashlib.sha256((app/p).read_bytes()).hexdigest()}for p in files],'scope':'Two ordinary loads mobile390x780/desktop1280x800, serial contexts max1, normal/ByGrade/publicFly/credits/newLib/existing2door-ground/native caps/errors. All8 source acceptance not implied; no FPS claim.'},indent=2)+'\n')
print('Prepared exact Wolf native candidate app helper; source unchanged.')
