Give the Miller House its pictured low log wing beside the tall range, add Hogan’s horizontal gable courses and chimney cap, raise St Mary’s front sash, and put the credited Castelnau harbour view on the lighthouse card. Source records retain disputed dates, unresolved details and picture conflicts; the comparison cameras remain diagnostic.

Validation:

- Actual foreground `tools/check.sh`: all 1,104 steps passed, including 395 self-tests; complete source/index/asset bindings unchanged. Committed changelog-entry, ticket-ID and fold-history checks also passed.
- Genuine native models and WEB derivatives, all 353 log/frame recipes fresh, native metadata and five package checks passed. The 1904 phone measurement is 395.8 MiB against the unchanged 400 MiB limit.
- Published app checks covered all four buildings at mobile and desktop sizes. Miller was checked again in fresh Full-detail browsers after its 10 mm stack-top correction: both passed with zero page errors, exact compressed assets/full-image credits, and dry unblocked approaches to both doors. Other dated app proofs remain dated and are bound to unchanged relevant inputs.

Four native ticket commits form one qualified unit with shared producer/generated dependencies; intermediate commit trees are not independently qualified. Image comparisons follow T-3153 and retain conflicts and unshown details without inventing historical camera positions. This validation does not claim a new whole-app renderer matrix or frame-rate measurement.

Recovery and exact source/app evidence: [checkpoint649](https://github.com/kevinrhaas/chicago-evidence/blob/faa79fc0bd9a0e51030f5de6d5ec7c60a6d0ae7f/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md). Final source-gate and commit receipts are preserved for the next checkpoint.
