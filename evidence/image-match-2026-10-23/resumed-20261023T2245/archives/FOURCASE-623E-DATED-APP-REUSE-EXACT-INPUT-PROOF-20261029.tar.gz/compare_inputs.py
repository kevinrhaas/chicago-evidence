"""Read only selected current published inputs against the dated actual app bindings."""
from pathlib import Path
import copy, datetime, hashlib, json, subprocess

O=Path(__file__).resolve().parent
R=Path('/workspace/chicago'); A=R/'chicago/4d'; S=R/'site/4d'
F=Path('/workspace/early-four-final-app-20261029')
C=Path('/workspace/early-four-final-candidate-ccbb-closed-20261029/postimages')
P=Path('/workspace/early-four-2cb3-current-native-root-20261029/CURRENT-DATED-APP-REUSE.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
old=load(F/'SOURCE-BINDINGS.json'); binding={x['path']:x for x in old['paths']}
prior=load(P)
assert prior['relevant_target_liberty_records_equal_to_actual_old_app_input'] is True
seen={}
def current(path):
    digest=sha(path);seen[str(path)]=digest;return digest
def exact_published(path):
    oldrow=binding[str(path)];digest=current(path)
    row={'path':str(path),'dated_sha256':oldrow['sha256'],'current_sha256':digest,'exact':digest==oldrow['sha256']}
    assert row['exact'],row
    return row

js=[x for x in binding if x.startswith(str(S/'walk/js')+'/') and x.endswith('.js') and not x.endswith('/changelog.js')]
now_js={str(p)for p in (S/'walk/js').rglob('*.js')if p.name!='changelog.js'}
assert set(js)==now_js
renderer=[exact_published(Path(p))for p in sorted(js)]
picture_binding=exact_published(S/'data/pictures/1835.json')
expected={label:load(F/label/'APP-EXPECTED.json')for label in ['miller','hogan','mary','lighthouse']}
camera_names={'miller':'wolf-point-1833','hogan':'cameron_1833','mary':'moss-engraving','lighthouse':'castelnau-1842'}
images=load(A.parent/'prairie_1904_v1/data/images.json')['images']
store=load(A.parent/'prairie_1904_v1/research/images/STORE.json')
old_grades=load(C/'chicago/4d/data/structure_grades.json')
new_grades=load(A/'data/structure_grades.json')
old_library=load(C/'chicago/prairie_1904_v1/data/images.json')['images']
entrances=load(A/'data/enclosures/town_entrance_aprons.json')['entrances']
cases=[]
for label,e in expected.items():
    sid=e['sidecar']['id'];native=A/'data/sidecars/1835'/(sid+'.json');pub=S/'data/sidecars/1835'/(sid+'.json')
    n=load(native);published_side=load(pub)
    # publish's native resident pruning removes long note/why fields; the dated
    # published-byte check below binds that real consumer independently.
    adjusted_published=copy.deepcopy(published_side);adjusted_published['residents']=n['residents']
    assert adjusted_published==n
    current(native);current(pub)
    web=S/'data'/e['sidecar']['asset'];web_sha=current(web)
    assert web_sha==current(A/'assets/web'/Path(web).name)
    camera=A/'data/reference_views'/sid/(camera_names[label]+'.json')
    camera_sha=current(camera);assert camera_sha==e['source_binding']['canonical_camera_sha256']
    assert n['grade']==e['grade'] and n['placement']==e['placement']
    assert [x for x in entrances if x['structure_id']==sid]==e['entrances']
    grade_rows={}
    for array in ['pictured','not_pictured']:
        before=[x for x in old_grades[array]if x.get('scene')=='1835'and x.get('structure')==sid]
        after=[x for x in new_grades[array]if x.get('scene')=='1835'and x.get('structure')==sid]
        assert before==after
        grade_rows[array]=after
    photo=e['photo']; image=[x for x in images if x['id']==photo['id']];old_image=[x for x in old_library if x['id']==photo['id']]
    assert len(image)==1 and image==old_image
    assert store['base_url']==photo['base_url']
    assert store['files'][photo['display']]==photo['display_binding'] and store['files'][photo['thumb']]==photo['thumb_binding']
    row={'case':label,'structure':sid,'full_sidecar_object_exact':n==e['sidecar'],'native_sidecar_sha256':sha(native),
         'published_sidecar_sha256':sha(pub),'current_WEB_sha256':web_sha,'dated_WEB_sha256':e['WEB_sha256'],
         'WEB_exact':web_sha==e['WEB_sha256'],'canonical_camera_sha256_exact':True,'grade':n['grade'],
         'grade_rows_exact':grade_rows,'placement_and_native_entrances_exact':True,'picture_library_row_and_STORE_bindings_exact':True}
    if label!='miller':
        assert row['full_sidecar_object_exact']and row['WEB_exact']
        row['published_sidecar_bytes']=exact_published(pub)
        row['published_WEB_bytes']=exact_published(web)
    else:
        assert not row['full_sidecar_object_exact']and not row['WEB_exact']
        adjusted=copy.deepcopy(e['sidecar']);adjusted['attributes']['frame_addition_ridge_stack']=n['attributes']['frame_addition_ridge_stack']
        assert adjusted==n
        assert e['attributes']['frame_addition_ridge_stack']['value']==[.4,.45,.45]
        assert n['attributes']['frame_addition_ridge_stack']['value']==[.4,.45,.46]
        row['intentional_exception']={'only_sidecar_attribute_changed':'frame_addition_ridge_stack value and explanatory note',
          'old_value':[.4,.45,.45],'new_value':[.4,.45,.46],
          'fresh_Miller_BODY_BOTH_result':'Separate root proof; not inferred or read from an unfinished browser run here.',
          'actual_mesh_delta_proof':'/workspace/early-four-miller-10mm-mesh-delta-proof-20261029/MANIFEST.json',
          'dated_WEB_identity_claim':False}
    cases.append(row)

props=[]
for key,rel,field in [('signs','data/signage/town_business_signboards.json','signs'),('frontages','data/yard/town_trade_goods.json','frontages'),('woodpiles','data/yard/town_woodpiles.json','lots')]:
    native=load(A/rel);published=load(S/rel)
    before=expected['miller']['changed_props'][key]
    assert [x for x in native[field]if x['structure_id']=='miller_house']==before
    assert [x for x in published[field]if x['structure_id']=='miller_house']==before
    props.append({'kind':key,'whole_published_file':exact_published(S/rel),'Miller_rows_exact':True})
entrance_binding=exact_published(S/'data/enclosures/town_entrance_aprons.json')
terrain=[]
for row in prior['native_ground_inputs']:
    path=Path(row['path']);assert binding[str(path)]['sha256']==row['sha256']
    terrain.append(exact_published(path))

old_lib=load(C/'chicago/4d/data/liberties.json')
new_lib=load(S/'data/liberties.json');assert new_lib==load(A/'data/liberties.json')
target_ids={e['sidecar']['id']for e in expected.values()}
relevant=lambda row:bool(target_ids.intersection(row.get('subjects',[])))or any(c.get('structure')in target_ids for c in row.get('covers',[]))
old_rows={x['id']:x for x in old_lib['liberties']if relevant(x)}
new_rows={x['id']:x for x in new_lib['liberties']if relevant(x)}
assert old_rows.keys()==new_rows.keys()
liberty=[]
allowed={'L-hogan-gable-courses-cap-2377':{'form.end_gable_courses'},'L-miller-adjacent-wing-2381':{'form.frame_addition_side','position'}}
for identity,before in old_rows.items():
    after=new_rows[identity]
    if before==after:
        liberty.append({'id':identity,'full_relevant_row_exact':True});continue
    assert identity in allowed
    removed=[x for x in before['covers']if x not in after['covers']]
    assert not[x for x in after['covers']if x not in before['covers']]
    assert {x['aspect']for x in removed}==allowed[identity]
    adjusted=copy.deepcopy(before);adjusted['covers']=after['covers']
    fields=[i for i,x in enumerate(before['fields'])if x['label']=='Covers'];assert len(fields)==1
    adjusted['fields'][fields[0]]=after['fields'][fields[0]]
    assert adjusted==after
    liberty.append({'id':identity,'full_relevant_row_exact':False,'intentional_only_exception':'Covers pointers and corresponding displayed Covers text',
                    'removed_false_pointers':removed,'decision_source_title_subjects_dates_and_all_other_fields_exact':True,
                    'dated_display_exact_claim':False})
assert sum(not x['full_relevant_row_exact']for x in liberty)==2

assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
assert all(sha(Path(path))==digest for path,digest in seen.items()),'Selected current inputs moved while reading'
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CURRENT_623E_SELECTED_DATED_APP_REUSE_PASS_WITH_MILLER_AND_COVERS_EXCEPTIONS',
 'actual_current_base':head,'source_working_snapshot_uncommitted':True,
 'dated_actual_mobile_result':'/workspace/early-four-final-app-both-v4-20261029/mobile-RESULT.json',
 'dated_actual_desktop_result':'/workspace/early-four-desktop-fresh-v5-root-20261029/RESULT.json',
 'dated_app_input_file':str(F/'SOURCE-BINDINGS.json'),'dated_app_input_sha256':sha(F/'SOURCE-BINDINGS.json'),
 'prior_verified_selected_liberty_equivalence':{'path':str(P),'sha256':sha(P),'method':'Current selected rows compared to frozen ccbb source postimages. Prior native receipt explicitly verifies those relevant target rows equal the actual older app inputs; no old whole-liberties file identity is asserted.'},
 'cases':cases,'published_JS_except_changelog':renderer,'published_1835_pictures':picture_binding,
 'published_JS_set_exact':True,'renderer_and_picture_bindings_count':len(renderer)+1,
 'terrain_and_heightfield_bindings':terrain,'published_entrance_file':entrance_binding,'Miller_props':props,
 'selected_liberty_rows':liberty,'selected_current_input_hashes':seen,
 'scope':'Dated actual BOTH proofs reused for unchanged Hogan/Mary/Lighthouse selected consumers. Miller body uses separate fresh BOTH proof. No whole renderer matrix, whole-source gate, whole-year smoke, GPU timing or FPS claim.',
 'limits':['changelog.js and build/pack metadata intentionally outside selected renderer equality.',
           'Two liberty Covers displays intentionally differ after deleting three false pointers; their prose and all other fields remain exact.',
           'This process performs no browser invocation, source/publish write, native rebuild, image network fetch, or full asset-tree walk.',
           'The full-source gate and incoming1904 qualifications are separate actual receipts.']}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'base':head,'renderer_picture_bindings':len(renderer)+1,'terrain':len(terrain),'cases':[(x['case'],x['full_sidecar_object_exact'],x['WEB_exact'])for x in cases],'relevant_liberties':len(liberty),'intentional_Covers_exceptions':2},indent=2))
