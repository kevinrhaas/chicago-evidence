# Selected current app input reuse

Actual read-only comparison passed on current623e plus the final four-ticket working source. The dated mobilev4 and desktopv5 runs remain dated results. Hogan, StMary and Lighthouse full native sidecar objects, actual published sidecar bytes, WEBbytes, cameras, grade and picture bindings remain exact. All255 selected publishedJS/picture bindings and26 terrain/heightfield bindings are exact.

Miller intentionally has the10mm reconstructed stack correction and newWEB; its fresh BOTH body proof is separate and is not inferred here. Two liberty rows intentionally lose three false Covers pointers; their Decision/Source prose and all other fields stay exact. Relevant old liberties use the prior verified selected-row equivalence receipt and frozenccbb postimages, not an invented old whole-file hash identity.

The initial native=published sidecar guard failed because publish prunes long resident notes. Its raw log is preserved. The completed comparison binds each representation independently to its actual dated counterpart, and reports that fact explicitly.

No browser, native export, source/publish write, whole asset walk, renderer matrix, whole-year smoke, FPS, GPU performance or full-source gate verdict is claimed by this packet.
