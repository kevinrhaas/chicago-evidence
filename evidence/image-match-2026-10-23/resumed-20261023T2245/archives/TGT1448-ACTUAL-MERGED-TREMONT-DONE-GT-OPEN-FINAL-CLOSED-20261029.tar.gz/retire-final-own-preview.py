from pathlib import Path
import subprocess,json,os,hashlib,shutil,datetime
r=Path('/tmp/chicago-green-tree-integration');p=r/'site/4d';h=Path('/workspace/T2385-resume-20261029');sha=lambda b:hashlib.sha256(b).hexdigest()
def raw(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=r)
def snapshot():
 common=Path(raw('rev-parse','--git-common-dir').decode().strip());common=common if common.is_absolute()else r/common
 idx=Path(raw('rev-parse','--git-path','index').decode().strip());idx=idx if idx.is_absolute()else r/idx
 q=subprocess.run(['git','rev-parse','--verify','MERGE_HEAD'],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 return {'head':raw('rev-parse','HEAD').decode().strip(),'merge_head':q.stdout.decode().strip()if q.returncode==0 else None,'status_sha256':sha(raw('status','--porcelain=v1','-z')),'index_sha256':sha(idx.read_bytes()),'config_sha256':sha((common/'config').read_bytes())}
assert p.is_dir()and not p.is_symlink()and not raw('ls-files','-z','--','site/4d');assert subprocess.run(['git','check-ignore','-q','site/4d/index.html'],cwd=r).returncode==0
readers=[];servers=[]
for z in Path('/proc').iterdir():
 if not z.name.isdigit()or int(z.name)==os.getpid():continue
 try:args=[a.decode(errors='replace')for a in(z/'cmdline').read_bytes().split(b'\0')if a];cwd=os.readlink(z/'cwd')
 except (OSError,PermissionError):continue
 server=any(a=='http.server'or Path(a).name in {'http-server','serve-handler'}for a in args)
 if server and(any(str(p)in a for a in args)or cwd.startswith(str(r))):servers.append({'pid':z.name,'cwd':cwd,'args':args})
 for f in [z/'cwd',*(z/'fd').glob('*')]:
  try:t=os.readlink(f)
  except OSError:continue
  if t==str(p)or t.startswith(str(p)+'/'):readers.append({'pid':z.name,'fd':str(f),'target':t})
assert not readers and not servers,(readers,servers)
files=[f for f in p.rglob('*')if f.is_file()];before=snapshot();assert before['head']=='91c3f4abdaf3c1a20806f589881de20961b83319'and before['merge_head']is None and not raw('status','--porcelain=v1');free=shutil.disk_usage('/tmp').free
j={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':before,'preview':str(p),'files':len(files),'logical_bytes':sum(f.stat().st_size for f in files),'readers':readers,'servers':servers,'restore':'Native bash tools/publish.sh from exact committed source regenerates this ignored preview. All source/caches/materialization backups remain protected.'};(h/'FINAL-GT-PREVIEW-RETIREMENT-BEFORE.json').write_text(json.dumps(j,indent=2)+'\n');shutil.rmtree(p);after=snapshot();assert before==after;j.update(status='ACTUAL_OWN_INACTIVE_IGNORED_PREVIEW_ONLY_RETIRED_SOURCE_UNCHANGED',finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_tmp_free_gain=shutil.disk_usage('/tmp').free-free,tmp_free_after=shutil.disk_usage('/tmp').free,source_after=after);(h/'FINAL-GT-PREVIEW-RETIREMENT-RESULT.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j,indent=2))
