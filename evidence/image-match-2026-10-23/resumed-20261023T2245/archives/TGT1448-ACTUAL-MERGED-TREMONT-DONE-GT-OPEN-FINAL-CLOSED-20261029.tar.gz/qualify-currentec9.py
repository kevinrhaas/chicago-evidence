from pathlib import Path
import os,json,subprocess,hashlib,datetime,difflib
r=Path('/tmp/chicago-green-tree-integration');app=r/'chicago/4d';h=Path('/workspace/T2385-resume-20261029');out=h/'CURRENTEC9-COMPAT-METADATA';out.mkdir(exist_ok=False);env=dict(os.environ,TMPDIR=str(h/'native-scratch'),NPM_CONFIG_PREFIX='/tmp/T2385-runtime-prefix',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);incoming='ec9f5c932763e3a40df8cb15496d888df50f6a37';own='f2635549179a61fd684336248418ba1e48aaeea9';base='2d2f258ec73a90c9946f1b6694a839dff3ee20fc';sha=lambda b:hashlib.sha256(b).hexdigest()
def g(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=r,env=env)
def save(n,j):(out/n).write_text(json.dumps(j,indent=2)+'\n')
assert g('rev-parse','HEAD').decode().strip()==own and g('rev-parse','MERGE_HEAD').decode().strip()==incoming
conflicts=g('diff','--name-only','--diff-filter=U').decode().splitlines();assert conflicts==['chicago/4d/data/sidecars/1835/sources/index.json'];p=conflicts[0]
for k in [1,2,3]:(out/('RAW-NATIVE-INDEX-STAGE'+str(k)+'.json')).write_bytes(g('show',':'+str(k)+':'+p))
(out/'RAW-NATIVE-INDEX-MARKERS.json').write_bytes((r/p).read_bytes())
scope=json.loads(Path('/tmp/current-dev-ec9f-readonly-price-20261029/CONSUMER-SCOPE.json').read_bytes());assert scope['tip']==incoming
protected=[]
for p,row in scope['exact_unchanged_bindings'].items():
 if p.startswith('chicago/4d/renderers/')or '/generators/archetypes/'in p or '/data/structures/'in p or '/data/reference_views/'in p or '/assets/'in p:
  assert(r/p).read_bytes()==g('show',own+':'+p),p;protected.append(p)
shared=set(g('diff','--name-only',base,own).decode().splitlines());exact=[]
for x in scope['exact_changed_paths']:
 p=x['path']
 if p in shared:continue
 if x['new']is None:assert not(r/p).exists(),p
 else:assert(r/p).read_bytes()==g('show',incoming+':'+p),p
 exact.append(p)
for p in ['chicago/4d/docs/LIBERTIES.md']:
 a=g('show',base+':'+p).splitlines(keepends=True);b=g('show',incoming+':'+p).splitlines(keepends=True);now=(r/p).read_bytes()
 for op,i,j,k,l in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes():
  if op in ['insert','replace']:assert b''.join(b[k:l])in now,('incoming authored delta lost',p)
save('CURRENT-INCOMING-AND-DATED-APP-REUSE-PROOF.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'incoming':incoming,'feature':own,'tested_feature_tree':'1c26d94c0fdc64469a06f650c2bf1f13ff0a2c2f','early_app_protected_paths_exact':protected,'incoming_nonshared_paths_exact':exact,'source_scope':scope['tip'],'proofscope':'Full1104/395 remains actualdated1c26; c093 BOTHbody/card/GT proof remains dated inputbound. Nativechangedconsumers/metadata and currentphone below qualify newec9 composite.'})
steps=[]
def run(n,args):
 print('START',n,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
 with(out/(n+'.log')).open('x')as f:q=subprocess.run(args,cwd=app,env=env,stdout=f,stderr=subprocess.STDOUT)
 steps.append({'name':n,'command':args,'exit':q.returncode,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat()});save('STEPS.json',steps);print(n,q.returncode,flush=True);assert q.returncode==0,(n,q.returncode)
run('01-native-current-liberties',['python3','tools/compile_liberties.py']);run('02-native-current-scene-conflict-owner',['python3','tools/compile_scene.py','--all']);g('add','--','chicago/4d/data/sidecars/1835/sources/index.json');assert not g('ls-files','-u');run('03-native-current-source-use',['python3','tools/compile_source_use.py'])
for n,args in [('04-K01-all-current-build-check',['python3','generators/k01_emit.py','--check']),('05-draft-all-current-build-check',['python3','generators/draft_emit.py','--check']),('06-native-ironwork-kit',['python3','tools/check_ironwork_kit.py','--check']),('07-native-ironwork-faults',['python3','tools/check_ironwork_kit.py','--self-test']),('08-current-front-yards',['python3','tools/plant_prairie_1904_front_yards.py','--check']),('09-current-front-yard-faults',['python3','tools/plant_prairie_1904_front_yards.py','--self-test']),('10-current-walks',['python3','tools/check_house_walks.py','--check']),('11-current-image-gate',['node','tools/image_gate.mjs','--structure','tremont_house_1'])]:run(n,args)
rows=[]
for p in g('ls-tree','-r','--name-only',incoming).decode().splitlines():
 if p.lower().endswith(('.xlsx','.gz')):
  old=g('show',incoming+':'+p);now=(r/p).read_bytes();rows.append({'path':p,'bytes':len(old),'expected_current_sha256':sha(old),'actual_sha256':sha(now),'exact':old==now})
save('ONE-ALL44-ACTUALEC9-AUDIT.json',rows);assert len(rows)==44 and all(x['exact']for x in rows)
run('12-native-current-publish',['bash','tools/publish.sh']);save('RESULT.json',{'status':'ACTUAL_CURRENTEC9_CHANGED_CONSUMERS_METADATA_ALL44_PUBLISH_PASS_APP_PROOF_SCOPED_REUSE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'incoming':incoming,'head':own,'real_merge_head':g('rev-parse','MERGE_HEAD').decode().strip(),'source_app':str(app),'native_conflict_resolved_only_by_owner':True,'actual_all44_current_bytes_exact':True,'native_steps':steps,'pending':'Actualcurrentphone400, finalnativePRquestions/compositecommit/qualifiedDEVmerge. Full1104/395 remains honestdated1c26; earlierc093app exactconsumerbound.'});print((out/'RESULT.json').read_text(),flush=True)
