from pathlib import Path
import subprocess,json,hashlib,datetime,shutil,os
repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';out=Path(__file__).parent;tip='4220f39bc160816f2fc716606d854c0c9ad7bc05'
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo).decode().strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
frozen=json.loads((out/'PROTECTED-INPUTS-BEFORE-NATIVE.json').read_text());assert git('rev-parse','HEAD')==frozen['head'] and git('rev-parse','MERGE_HEAD')==tip
remote=subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/dev','--jq','.object.sha'],text=True).strip();assert remote==tip and git('rev-parse','origin/dev')==tip
for p,v in frozen['authored'].items():assert hashlib.sha256((repo/p).read_bytes()).hexdigest()==v['sha256'],p
for p,v in frozen['models'].items():assert hashlib.sha256((repo/p).read_bytes()).hexdigest()==v['sha256'],p
assert set(git('diff','--name-only','--diff-filter=U').splitlines())==set(frozen['unmerged_native_paths'])
free=shutil.disk_usage('/tmp').free;assert free>=1800000000
assert int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text())>=512*1024**2
binding=dict(status='NATIVE_ACTIVE',at=now(),head=frozen['head'],incoming=tip,remote=remote,affinity=sorted(os.sched_getaffinity(0)),tmp_free=free,caller_startup_floor=1800000000,native_guards_unchanged=True,command=['node','tools/rederive.mjs','--resolve'],owner_Mary=frozen['author_qualified_Mary'],scope='One real native ownership resolution of current4220 plus checkedMary metadata and Philo alias choice. Existing202/feedback/settled graph unchanged; single copy-heavy lease required.')
(out/'NATIVE-BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
with (out/'native-resolve.log').open('w') as f:code=subprocess.call(binding['command'],cwd=app,stdout=f,stderr=subprocess.STDOUT)
checks=dict(head=git('rev-parse','HEAD')==frozen['head'],incoming=git('rev-parse','MERGE_HEAD')==tip,authored=all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==v['sha256'] for p,v in frozen['authored'].items()),models=all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==v['sha256'] for p,v in frozen['models'].items()),no_conflicts=not git('ls-files','-u'))
for sid,pic in [('philo_carpenter_log_shop','early-andreas-1884-sauganash'),('st_marys_church','early-moss-1884-st-marys')]:
 grade=json.loads((app/f'data/sidecars/1835/{sid}.json').read_text())['grade'];checks[sid+'_one_picture']=grade==dict(value='attested',why='Pictured: a picture on the Images tab shows it.',pictures=[pic])
r=dict(status='NATIVE_RESOLVE_AND_PROTECTED_INPUTS_PASS' if code==0 and all(checks.values()) else 'ACTUAL_NATIVE_FAILURE_RETAINED',at=now(),binding=binding,exit=code,checks=checks,changed_paths=git('diff','HEAD','--name-only').splitlines(),pending='Actualall44serializationaudit/package/publish/full3/currentupstream endings/normalcheckedcodecommit and standardexpectedheadDEVmerge. No wholeimagecompletion.')
(out/'NATIVE-RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(0 if code==0 and all(checks.values()) else 1)
