from pathlib import Path
import subprocess,sys,importlib.util,json,hashlib,datetime,tempfile,struct,os
import datetime as dt
repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';out=Path(__file__).parent;tip='4220f39bc160816f2fc716606d854c0c9ad7bc05';base='373851d158a7b6fc701b9cae1a651aa4b3823f97'
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo)
def at(ref,p):return git('show',ref+':chicago/4d/'+p)
def loadmod(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def digest(b):return hashlib.sha256(b).hexdigest()
def glbinfo(b):
 assert struct.unpack('<I',b[:4])[0]==0x46546c67
 n=struct.unpack('<I',b[12:16])[0];g=json.loads(b[20:20+n]);ps=[p for m in g.get('meshes',[]) for p in m['primitives']];acc=g['accessors'];pos=[acc[p['attributes']['POSITION']] for p in ps]
 return dict(bytes=len(b),sha256=digest(b),bin_bytes=sum(x['byteLength'] for x in g.get('buffers',[])),vertices=sum(x['count'] for x in pos),triangles=sum(acc[p['indices']]['count']//3 for p in ps),primitives=len(ps),materials=[dict(name=m.get('name'),alphaMode=m.get('alphaMode','OPAQUE'),alpha=m.get('pbrMetallicRoughness',{}).get('baseColorFactor',[1,1,1,1])[3]) for m in g.get('materials',[])],bounds=dict(min=[min(a['min'][i] for a in pos) for i in range(3)],max=[max(a['max'][i] for a in pos) for i in range(3)]),nodes=[dict(name=n.get('name'),extras=n.get('extras')) for n in g.get('nodes',[])])
original=dict(tree=git('write-tree').decode().strip(),status=git('status','--porcelain').decode(),head=git('rev-parse','HEAD').decode().strip(),merge=git('rev-parse','MERGE_HEAD').decode().strip())
assert original['tree']=='a091a9d69f816e374e2c6503670b3e1602b8e09d'
assert git('rev-parse','origin/dev').decode().strip()==tip
sys.path.insert(0,str(app/'generators'));sys.path.insert(0,str(app/'tools'))
deps=['generators/k13_emit.py','generators/archetypes/k13_conservatories_params.py','generators/archetypes/k01_frontage.py','generators/archetypes/k01_frontage_params.py','generators/archetypes/k06_windows.py','data/components/prairie_1904/k13_conservatories.json','data/components/prairie_1904/k04_roofs.json','tools/check_conservatory_kit.py']
for p in deps:assert (app/p).read_bytes()==at(tip,p),p
manifest=json.loads(at(tip,'assets/manifest.json'));assets=[(n,v) for n,v in manifest['assets'].items() if v.get('archetype')=='k13_conservatories'];assert len(assets)==5
scene_paths=git('ls-tree','-r','--name-only',tip,'--','chicago/4d/data/scenes').decode().splitlines();scenes=[]
for p in scene_paths:
 if p.endswith('.json'):
  d=json.loads(git('show',tip+':'+p))
  if d.get('target_date'):scenes.append((d['id'],dt.date.fromisoformat(d['target_date'])))
rows=[];target=None
with tempfile.TemporaryDirectory(prefix='T3177-k13-default-controls-',dir='/tmp') as tmp:
 t=Path(tmp);module=t/'incoming_k13.py';module.write_bytes(at(tip,'generators/archetypes/k13_conservatories.py'))
 K=loadmod('incoming_k13',module);K.ROOT=app;K.DATA=app/'data/components/prairie_1904/k13_conservatories.json';data=K.load()
 E=loadmod('incoming_control_emitter',app/'generators/k13_emit.py');E.k13_conservatories=K
 checker=loadmod('incoming_control_checker',app/'tools/check_conservatory_kit.py');checker.K=K
 overlay=t/'overlay';(overlay/'data/structures').mkdir(parents=True);(overlay/'data/sources').symlink_to(app/'data/sources',target_is_directory=True)
 specpath=overlay/data['specimen'];specpath.parent.mkdir(parents=True,exist_ok=True);specpath.symlink_to(app/data['specimen']);checker.ROOT=overlay
 for name,v in sorted(assets):
  sid,pid=v['structure_id'],v['phase_id'];st=json.loads(at(tip,'data/structures/'+sid+'.json'));(overlay/'data/structures'/f'{sid}.json').write_text(json.dumps(st))
  phase=next(p for p in st['phases'] if p['id']==pid);active=[s for s,day in scenes if E._covers(phase,day)];assert active==['1904'],(sid,active)
  blob=E.glb_for(st,phase,active);incoming=at(tip,'assets/gltf/'+name);old=at(base,'assets/gltf/'+name)
  row=dict(id=sid,phase=pid,active_scenes=active,generated=glbinfo(blob),incoming_byte_exact=blob==incoming,default_control=sid!='pullman_house_1729_prairie_conservatory',base_byte_exact=blob==old,base=glbinfo(old))
  if row['default_control']:assert blob==old,sid
  else:assert blob!=old;target=row
  assert blob==incoming,sid;rows.append(row)
 failures=checker.check(data,glb_check=True)
 assert failures==[],failures
assert target is not None
assert git('write-tree').decode().strip()==original['tree'] and git('status','--porcelain').decode()==original['status'] and git('rev-parse','HEAD').decode().strip()==original['head'] and git('rev-parse','MERGE_HEAD').decode().strip()==original['merge']
r=dict(status='PASS_ALL_FIVE_INCOMING_MASTERS_FOUR_DEFAULTS_AND_EXISTING_KIT_SPECIMEN',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),incoming=tip,base=base,affinity=sorted(os.sched_getaffinity(0)),dependency_files_exact_to_incoming=deps,kit_checker_failures=failures,records=rows,target_delta={k:target['generated'][k]-target['base'][k] for k in ['bytes','bin_bytes','vertices','triangles','primitives']},source_index_head_merge_unchanged=original,scope='Actual purePython native emitter/control/checker; temporary overlay contains ALL5 incoming K13 records, every kitvariant and originalspecimen. Fourdefaults byteexact to373; allfive byteexact to4220. Only1904 active. No source/index/ref/guard/assertion changes, Blender, fullrepo scratch or app-performance claim.')
(out/'K13-DEFAULT-CONTROLS-RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['records','dependency_files_exact_to_incoming']},indent=2));print('target old/new',target['base']['bytes'],target['generated']['bytes']);print('all model IDs',[r['id'] for r in rows])
