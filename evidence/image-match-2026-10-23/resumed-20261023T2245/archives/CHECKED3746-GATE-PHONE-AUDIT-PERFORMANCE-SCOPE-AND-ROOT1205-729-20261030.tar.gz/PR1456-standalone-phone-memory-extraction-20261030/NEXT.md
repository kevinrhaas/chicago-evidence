# Standalone performance support extraction — ready, not applied

The concrete source extraction is **four files**, exactly copied from checked commit `3746b23bf1298c34a29946b4cdb6ee2d98abff8f`:

- `renderers/web/js/railway.js`
- `renderers/web/js/spatial-batch.js`
- `tools/check_confidence_lane.mjs`
- `tools/test_rail_geometry_lifecycle.mjs`

All are under `chicago/4d/`. The exact preimages/postimages, complete unified patch, per-file Git blobs/SHA256s and semantic/test mapping are included. The immutable bc→039 comparison returned all17changed paths; none is one of these four files. Therefore the039preimages are exactly the known canonical bc bytes. This is proof for pinned `039c846c110adf36d07db153c2a53aaa5f9000e7`, not a claim that a future moving dev remains unchanged.

The patch carries the already checked railway normal/grade storage and the exact spatial initial-range cleanup. It contains no target models, structure/source records, Liberty/source-index output, asset registry, image metadata, rights baseline or PR-lap repair. The two existing tests already run in the native check.sh, so no new harness or check dispatcher edit is needed.

## Semantics

Rail and ground normals use the existing normalized8-bit compact helper; component/angle error bounds and a wrong-normal control remain in the existing lifecycle test. This is a bounded encoding change, not a claim of lossless normal bytes. Positions, indices, UVs, colours, grades and material/visibility/lifecycle behavior stay exact under those contracts.

Only a fine/far ground pair with the same exact uniform0,0.5or1 grade may omit the Float32 per-vertex grade stream. Mixed, invalid, fractional or mismatched grades retain it. Explicit whole/per-piece grade metadata and distinct shader cache keys preserve ByGrade/readback after upload release. This exact uniform-grade behavior is covered by the actual factory assertions in check_confidence_lane.

The spatial cleanup drops initial dead updateRange objects after all geometry is assembled. It changes no GPU/ArrayBuffer contents or picks/culls. Its prior source-only geometry/picking/coalescing tests passed. An old-mirror upload-release smoke was cancelled as irrelevant; that negative receipt is preserved and is not called a pass. Current source/fullgate and final runtime checks still apply to the new branch.

## Next ordinary branch/PR

After the root finishes its owned039import and releases the primary source, create a separate steward performance-support branch from actual canonical dev. Root files the one native performance-support ticket under the standing owner phone/OOM report and the permitted performance exception. No photo-follow-up ticket is needed or authorized by this packet. Replace the future changelog path anchor with that actual ticket ID; `changelog-entry.PROPOSED.json` has the normal title/kind/items schema and no invented ticket number/stamp.

Re-read actual HEAD and all four preimage hashes. If dev has moved, compare these four code/test paths; preserve any incoming code edits with a reviewed native merge rather than replaying whole old files. Data-only changes do not alter these four postimages, but the app's complete memory reading must still include the actual data at the branch head. Apply only these four source files plus the future own changelog entry. Respect the repository's same-PR STATUS/ROADMAP requirement with short current entrywise performance notes; do not replay historical whole documents or touch generated minified case metadata.

Run the existing relevant tests, current native owners/publish as required, full source/preflight and the official unchanged complete1904mobile phone gate on the actual new branch. Source gate1105/852.810s and phone398.9841709MiB from3746 demonstrate the extracted implementation on that composed tree; **they do not qualify a different039 standalone branch**, which also lacks the four picture/model changes. Preserve those exact limits in the actual PR body. Only a current passing required CI permits the normal dev merge; no admin bypass, forced code ref or main promotion.

After the support PR merges and its normal changelog fold settles, return to PR1456 and the original picture work. Reuse its validated target-specific evidence under exact bindings, merge the performance support normally, regenerate the necessary metadata and complete its own current checks/normal merge/official ticket settlement. Do not retarget or close the four original picture tickets through the performance PR.

No source/branch/ticket/API writes, tests, browser, native build or actual PR occurred in this extraction task. The earlier Bridge80 packet remains frozen and unchanged.
