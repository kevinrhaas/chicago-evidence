Prepared only: current-bc primary runtime qualification

After the actual complete bc source gate and native checkpoint create the new HEAD/tree, root runs either order (audit is read-only and launches no browser/meter):

python3 /workspace/PR1456-currentbc7-runtime-prep-first-fort-20261030/audit.py --checked-head ACTUAL_NATIVE_HEAD --checked-tree ACTUAL_CHECKED_TREE --execute
python3 /workspace/PR1456-currentbc7-runtime-prep-first-fort-20261030/phone.py --checked-head ACTUAL_NATIVE_HEAD --checked-tree ACTUAL_CHECKED_TREE --execute

The phone is ONE actual official complete1904mobile run at the unchanged400MiB ceiling/config, using actual PRIMARY publication from the bound fullgate. No runtime fixture, copied scene, fakecommit metadata or old399.2729 relabeling. Short owned /workspace/p1456-bc-final TMP is removed only after actual reaper closure plus source guard. The24MiB workspace reserve and caller1.8GB /tmp floors remain. Independent artifacts use PHONE-* names.

The audit binds the same actual gate/checkpoint/head/tree and verifies302/305 consumers exact to qualified9d,297/305 exact to original305, with8 precise original exceptions. Three changed since9d are pinned: inactive1835palm selector, additivephoenix descriptor, and active1835spatial clearUpdateRanges metadata cleanup. The root-reviewed firsttwo and actual two direct-source spatial geometry/picking/coalesce tests are hashed authorities. Canceled143 oldmirror upload smoke is explicitly excluded. No new wholeBODY/BOTH/environment or current8capture assertion is made. Prior9dPeople8/rootdirectreview stay dated; source inputs/app modules must remain exact, original mobile scrolled-frame/DOM limits retained.

Current native/published target picture tiles are compared to a pure native9d parent projection from tracked inputs in RAM; ignored generated parent pictures.json is never requested from Git. All target library/STORE/source context/structure/camera inputs must match9d. Original29 liberty rows and target source descriptions, claimjoins/names are exact; foreign globalcounts may move. The inherited Census authored/public citation sanitization discrepancy remains explicitly qualified, no clean-credit claim.

Source/index-stage semantics/indexflags/config/allrefs/all actual checked paths/6 critical published hashes are guarded before/after. No source writes, Git mutation, API mutation, full nativepublish/scene fixture or browser has been performed during preparation. Fresh phone and actual audit PASS remain pending.
