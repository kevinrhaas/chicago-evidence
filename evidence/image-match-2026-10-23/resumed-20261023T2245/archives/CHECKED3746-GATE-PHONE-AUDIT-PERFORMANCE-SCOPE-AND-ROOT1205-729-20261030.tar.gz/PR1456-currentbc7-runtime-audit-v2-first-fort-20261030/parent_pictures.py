"""Pure native parent projection from tracked inputs; ignored output is never git-shown."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys
sha=lambda b:hashlib.sha256(b).hexdigest()
def prove(repo,parent,subjects):
 A=repo/'chicago/4d';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a],env=E)
 top='chicago/4d/data/sources/';sourcepaths=[p for p in git('ls-tree','-r','--name-only',parent,'--',top).decode().splitlines()if p.startswith(top)and'/'not in p[len(top):]and p.endswith('.json')]
 camera_paths=[]
 for sid in sorted(subjects):camera_paths += [p for p in git('ls-tree','-r','--name-only',parent,'--',f'chicago/4d/data/reference_views/{sid}').decode().splitlines()if p.endswith('.json')and not p.endswith('.match.json')]
 compiler='chicago/4d/tools/compile_pictures.py';library='chicago/prairie_1904_v1/data/images.json';store='chicago/prairie_1904_v1/research/images/STORE.json';tsv='chicago/prairie_1904_v1/research/images/buildings-index.tsv';structures=[f'chicago/4d/data/structures/{sid}.json'for sid in sorted(subjects)];paths=[compiler,library,store,tsv,*sourcepaths,*structures,*camera_paths];assert len(paths)==len(set(paths))
 raw=subprocess.check_output(['git','-C',str(repo),'cat-file','--batch'],input=('\n'.join(parent+':'+p for p in paths)+'\n').encode(),env=E);offset=0;blobs={};oids={}
 for p in paths:
  end=raw.index(b'\n',offset);h=raw[offset:end].decode().split();assert len(h)==3 and h[1]=='blob',(p,h);size=int(h[2]);b=raw[end+1:end+1+size];assert len(b)==size and raw[end+1+size:end+2+size]==b'\n';assert hashlib.sha1(b'blob '+str(size).encode()+b'\0'+b).hexdigest()==h[0];blobs[p]=b;oids[p]=h[0];offset=end+2+size
 assert offset==len(raw)
 assert all((repo/p).read_bytes()==blobs[p]for p in paths),'A tracked parent target/source/context input changed; cannot reuse projection'
 current_sourcepaths=[str(p.relative_to(repo))for p in (A/'data/sources').glob('*.json')];added=set(current_sourcepaths)-set(sourcepaths);assert not added and set(sourcepaths)==set(current_sourcepaths)
 parent_sources={};current_sources={}
 for p in sourcepaths:
  d=json.loads(blobs[p]);
  if isinstance(d,dict)and d.get('id'):parent_sources[d['id']]=d
 for p in current_sourcepaths:
  d=json.loads((repo/p).read_bytes());
  if isinstance(d,dict)and d.get('id'):current_sources[d['id']]=d
 census=current_sources['census_1900_chicago_t623_roll245'];assert census['type']=='manuscript'and census['asset_use']=='text_only'
 spec=importlib.util.spec_from_file_location('pr1456_parent_native_compile_pictures',repo/compiler);cp=importlib.util.module_from_spec(spec);spec.loader.exec_module(cp)
 pictured=lambda sources:{k for k,v in sources.items()if v.get('type')in cp.SOURCE_PICTURE_TYPES};assert pictured(parent_sources)==pictured(current_sources)
 views={}
 for p in camera_paths:views.setdefault(Path(p).parent.name,[]).append(json.loads(blobs[p]))
 for sid in sorted(subjects):assert {str(p.relative_to(repo))for p in (A/'data/reference_views'/sid).glob('*.json')if not p.name.endswith('.match.json')}=={p for p in camera_paths if Path(p).parent.name==sid}
 texts={Path(p).stem:blobs[p].decode()for p in structures};scene={'1835':sorted(subjects)};images=json.loads(blobs[library]);parent_doc=cp.derive(images,blobs[tsv].decode(),parent_sources,texts,scene,views)['1835'];current_projection=cp.derive(images,blobs[tsv].decode(),current_sources,texts,scene,views)['1835'];native=json.loads((A/'data/pictures/1835.json').read_bytes());published=json.loads((repo/'site/4d/data/pictures/1835.json').read_bytes());rows=[]
 for sid in sorted(subjects):
  tiles=parent_doc['by_structure'][sid];assert tiles==current_projection['by_structure'][sid]==native['by_structure'][sid]==published['by_structure'][sid];rows.append({'structure_id':sid,'tiles':tiles,'parent_native_projection_equals_current_native_projection_native_output_and_published_target':True})
 return {'status':'ACTUAL_PURE_NATIVE_PARENT9D_FOUR_PICTURE_PROJECTION_FROM_TRACKED_INPUTS_NOT_PARENT_ARTIFACT','parent':parent,'compiler_git_blob':oids[compiler],'compiler_sha256':sha(blobs[compiler]),'compiler_byte_exact_to_parent':True,'entire_tracked_library_and_STORE_byte_exact_to_parent':{p:{'git_blob':oids[p],'sha256':sha(blobs[p]),'bytes':len(blobs[p])}for p in [library,store]},'buildings_index_byte_exact_to_parent':sha(blobs[tsv]),'parent_top_level_source_count':len(parent_sources),'all_parent_source_context_bytes_exact':True,'parent_and_current_picture_source_ID_sets_exact':sorted(pictured(parent_sources)),'new_sources_since_parent9d':[],'inherited_Census_is_manuscript_text_only_not_native_picture_type':True,'four_target_structure_texts_and_all_nonmatch_cameras_byte_exact':{p:sha(blobs[p])for p in structures+camera_paths},'parent_source_inputs_aggregate_sha256':sha(json.dumps({p:sha(blobs[p])for p in sourcepaths},sort_keys=True,separators=(',',':')).encode()),'scene_projection_scope':scene,'rows':rows,'ignored_parent_generated_file_not_read':True,'original_native_derive_function_unmodified':True,'native_main_or_emit_or_browser_or_meter_run':False,'payloads_in_RAM_only_no_scene_fixture':True}
