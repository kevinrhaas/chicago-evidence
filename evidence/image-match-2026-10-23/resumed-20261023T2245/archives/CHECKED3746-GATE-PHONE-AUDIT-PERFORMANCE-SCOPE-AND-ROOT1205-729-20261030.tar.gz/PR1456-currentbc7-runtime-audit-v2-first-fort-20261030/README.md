External V2 read-only original-four runtime auditor. No phone helper copied, altered or rerun. V1 all8 frozen helpers and read-only failure remain unchanged.

The only classification change is explicit L264: same29 targetLiberty IDs,28 whole rows exact9d, and L264 entirely exactincomingbc. L264 can differ only by globalbrick population192→191, the exact Hibbard1701 explanatory scope sentence, and T3254 work-reference insertion. Subjects/covers, dates, Decision (including lighthouse finish/unsizedstone and brick dimensions), discharge/recording fields stay exact. No target entry excluded; full29whole-row equality is not claimed. Other305/People/Images/source/credit checks unchanged.

Root command after same checkednativeHEAD/tree (read-only, no browser/meter):

python3 /workspace/PR1456-currentbc7-runtime-audit-v2-first-fort-20261030/audit.py --checked-head 3746b23bf1298c34a29946b4cdb6ee2d98abff8f --checked-tree ACTUAL_CHECKED_TREE --execute
