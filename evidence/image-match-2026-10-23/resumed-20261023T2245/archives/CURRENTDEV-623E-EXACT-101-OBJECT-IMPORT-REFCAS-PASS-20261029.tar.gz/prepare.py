from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal,zlib,urllib.request,urllib.parse,struct
os.sched_setaffinity(0,{1});os.nice(19)
B=Path(__file__).parent;C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='2cb3f591104a2e770ecf5dc42db90d4090cbbe34';TIP='623eccd80f5d5fee2dbbc6d33b8262fd50b7fe2e';CAP=64*1024**2;ENVELOPE=CAP;FLOOR=512*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(r,*args,input=None):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:sha(G/n)for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
def indexed(ids):
 wanted=set(ids);found=set();obj=G/'objects'
 for s in wanted:
  if(obj/s[:2]/s[2:]).is_file():found.add(s)
 for idx in(obj/'pack').glob('*.idx'):
  remaining=wanted-found
  if not remaining:break
  with idx.open('rb')as f:
   head=f.read(8);v2=head[:4]==b'\xfftOc';off=8 if v2 else 0
   if v2:assert struct.unpack('>I',head[4:])[0]==2
   f.seek(off);fan=struct.unpack('>256I',f.read(1024));table=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
   for s in remaining:
    key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
    while a<z:
     m=(a+z)//2;f.seek(table+m*stride+delta);value=f.read(20)
     if value<key:a=m+1
     else:z=m
    f.seek(table+a*stride+delta)
    if a<fan[key[0]]and f.read(20)==key:found.add(s)
 return found





P=Path('/tmp/current-dev-freshness-readonly-20261029T1915');payload=Path('/workspace/shared/DEV-623e-encoded-payload-20261029');payload.mkdir(exist_ok=False)
price=json.loads((P/'PRICE.json').read_text());tree=json.loads((P/'TREE.json').read_text());leaves=[r for r in tree['tree']if r['type']!='tree'];missing=price['missing'];assert len(missing)==39 and sum(r['size']for r in missing)==28392657
commit=json.loads((P/'COMMIT.json').read_text());assert commit['tree']['sha']=='2abbb5a540363a54a100dbf51e44dc8c972baf89'
before=snap();save('PREPARE-SOURCE-BEFORE.json',before);assert git(C,'rev-parse','origin/dev').decode().strip()==OLD
remote=api('git/ref/heads/dev');save('PREPARE-REMOTE.json',remote);assert remote['object']['sha']==TIP
with(B/'metadata-fetch.log').open('xb')as log:
 p=subprocess.Popen(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',TIP],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);abort=None;peak=0
 while p.poll()is None:
  size=sum(f.stat().st_size for f in(R/'objects').rglob('*')if f.is_file());peak=max(peak,size)
  if size>32*1024**2 or b'filtering not recognized'in(B/'metadata-fetch.log').read_bytes().lower():abort='filter/isolationbound';os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(.15)
 rc=p.wait()
save('METADATA-FETCH.json',{'exit':rc,'peak':peak,'abort':abort,'cap':32*1024**2});assert rc==0 and not abort
actual={}
for row in git(R,'ls-tree','-r','-z',TIP).split(b'\0'):
 if row:
  a,n=row.split(b'\t',1);m,t,s=a.decode().split();actual[n.decode()]={'mode':m,'type':t,'sha':s}
assert actual=={r['path']:{k:r[k]for k in ['mode','type','sha']}for r in leaves}
allmeta=set()
for idx in(R/'objects/pack').glob('*.idx'):
 for line in git(R,'show-index',input=idx.read_bytes()).decode().splitlines():allmeta.add(line.split()[1])
for folder in(R/'objects').iterdir():
 if len(folder.name)==2 and folder.is_dir():
  for obj in folder.iterdir():
   if len(obj.name)==38:allmeta.add(folder.name+obj.name)
unknown=allmeta-indexed(allmeta);newmeta=[]
if unknown:
 for line in git(R,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(sorted(unknown))+'\n').encode()).decode().splitlines():
  obj,kind,size=line.split();assert kind in ['commit','tree','tag'];newmeta.append({'sha':obj,'kind':kind,'bytes':int(size)})
rows=[]
def store(obj,kind,data,path):
 raw=kind.encode()+b' '+str(len(data)).encode()+b'\0'+data;assert hashlib.sha1(raw).hexdigest()==obj;enc=zlib.compress(raw);f=payload/obj;assert not f.exists();assert shutil.disk_usage('/workspace').free>=FLOOR+len(enc)+4096;f.write_bytes(enc);rows.append({'sha':obj,'kind':kind,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoded_bytes':len(enc),'payload':str(f),'path':path})
for r in newmeta:
 data=git(R,'cat-file',r['kind'],r['sha']);assert len(data)==r['bytes'];store(r['sha'],r['kind'],data,'isolatedcanonicalmetadata')
for r in missing:
 with urllib.request.urlopen('https://raw.githubusercontent.com/kevinrhaas/chicago/'+TIP+'/'+urllib.parse.quote(r['path'],safe='/'),timeout=90)as response:assert response.status==200;data=response.read(r['size']+65536)
 assert len(data)==r['size'];store(r['sha'],'blob',data,r['path'])
import base64
for label,sha in [('WALKER-FEATURE','2f9ce034288882c1752d7ae9ebca5e4cf4990595'),('WALKER-FOLD','85faffc221f90f13130adfbb4041fe55e781a092'),('KEITH-FEATURE','3f63185cb4d804dbe5f28e6933ad3ad58868a2c8'),('KEITH-FOLD',TIP)]:
 feature=api('commits/'+sha);save(label+'.json',feature)
 for r in feature['files']:
  if r['filename'].startswith('chicago/4d/changelog.d/')and r['status']=='added'and r['sha']not in indexed([r['sha']])and r['sha']not in{q['sha']for q in rows}:
   ob=api('git/blobs/'+r['sha']);data=base64.b64decode(ob['content']);assert len(data)==ob['size']<4096;store(r['sha'],'blob',data,r['filename'])
raw=sum(r['bytes']for r in rows);assert raw<=CAP
save('PREPARED-PAYLOAD.json',{'old':OLD,'tip':TIP,'tree':commit['tree']['sha'],'rows':rows,'canonical_raw_total':raw,'standing_cap':CAP,'allocation_envelope':sum(Path(r['payload']).stat().st_blocks*512 for r in rows),'source_scope':'PR1449 Walker1720 +fold and PR1447 EdsonKeith1906 +fold. No earlyfamily producer or renderer exceptchangelog change. Availability only.'})
after=snap();save('PREPARE-SOURCE-AFTER.json',after);save('PREPARE-RESULT.json',{'status':'BOUNDED_EXACT_PAYLOAD_PREPARED_NO_SHARED_MUTATION','tip':TIP,'canonical_raw_total':raw,'new_objects':len(rows),'refs_HEAD_index_config_merge_unchanged':all(after[k]==before[k]for k in ['refs','HEAD','metadata']),'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free});print((B/'PREPARE-RESULT.json').read_text())
