from pathlib import Path
import subprocess,json,datetime,os,hashlib,sys
r=Path('/tmp/chicago-log-integration/chicago/4d');o=Path(__file__).resolve().parent;now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();get=lambda rel:subprocess.check_output(['git','show','HEAD:chicago/4d/'+rel],cwd=r)
files=['data/reconstruction/1835_lodgers_seated.json','data/reconstruction/1835_reconstruction_order_book.json','data/reconstruction/1835_lodging_model.json','data/reconstruction/1835_placement_policy.json',*[str(p.relative_to(r))for p in sorted((r/'data/residents/lodgers').glob('*.json'))]];assert len(files)==26;guards={p:hashlib.sha256(get(p)).hexdigest()for p in files};(o/'protected-before.json').write_text(json.dumps(guards,indent=2)+'\n')
def guard():
 for p,h in guards.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,('Protected drift',p)
state={'status':'RUNNING','started':now(),'controller_pid':os.getpid(),'bounded_scope':'only incoming1904Kimball form/native metadata; own sixbuilding composition already derived; same population/layout inputs; writers142,146,150','phases':[]};save=lambda:(o/'receipt.json').write_text(json.dumps(state,indent=2)+'\n');save();env={**os.environ,'TMPDIR':'/workspace/tmp-t3081','PATH':'/workspace/shared/tools/usr/bin:'+os.environ['PATH'],'PYTHONDONTWRITEBYTECODE':'1'}
cmds=[('liberties',['python3','tools/compile_liberties.py']),('scenes',['python3','tools/compile_scene.py','--all']),('entrances-check',['python3','tools/generate_entrances.py','--check']),('source-use',['python3','tools/compile_source_use.py']),('scenes-check',['python3','tools/compile_scene.py','--all','--check']),('closing-check',['python3','tools/rebuild_closing_set.py','--check']),('publish',['bash','tools/publish.sh']),('dataset-all-stale',['python3','tools/validate.py','--all','--stale']),('published-check',['node','tools/check_published.mjs'])]
try:
 for name,args in cmds:
  guard();row={'name':name,'command':args,'started':now()};state['phases'].append(row);save()
  with(o/(name+'.log')).open('x')as f:q=subprocess.Popen(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT);row['pid']=q.pid;save();code=q.wait()
  row.update(exit_code=code,finished=now());save();assert code==0,name;guard()
 state.update(status='PASS',finished=now(),all26_population_model_files_exact=True);save();print(json.dumps(state,indent=2))
except BaseException as e:state.update(status='FAILED',error=str(e),finished=now());save();raise
