from pathlib import Path
import subprocess,time,json,datetime,sys
r=Path('/tmp/chicago-log-integration');o=Path(__file__).resolve().parent;n=Path('/workspace/T3081-T3082-dev85-native07');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
s={'status':'WAITING_NATIVE','started':now()};p=o/'coordination.json';save=lambda:p.write_text(json.dumps(s,indent=2)+'\n');save()
for i in range(120):
 v=json.loads((n/'receipt.json').read_text())
 if v['status']!='RUNNING':break
 time.sleep(15)
assert v['status']=='PASS',v
q=subprocess.run(['python3',str(n/'check_asset_guards.py')],cwd=r);assert q.returncode==0
subprocess.run(['git','add','--','chicago/4d'],cwd=r,check=True)
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=r).strip()
s.update(status='RUNNING_PREFLIGHT',native_finished=v['finished'],preflight_started=now());save()
q=subprocess.run(['python3',str(o/'run_preflight.py')],cwd=r)
s.update(status='PASS'if q.returncode==0 else'FAILED',exit_code=q.returncode,finished=now());save();sys.exit(q.returncode)
