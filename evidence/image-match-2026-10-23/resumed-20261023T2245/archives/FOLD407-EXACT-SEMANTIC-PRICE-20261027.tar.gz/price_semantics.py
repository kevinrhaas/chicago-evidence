from pathlib import Path
import os,json,subprocess,urllib.request,hashlib,struct
os.sched_setaffinity(0,{1});os.nice(19)
B=Path(__file__).parent;G=Path('/workspace/chicago/.git');OLD='ed250192e95420f20d810b5a012fe351c553815c';TIP='407e4c730c818c817cf0e38b24550d8d4bee0394';env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def sha(b):return hashlib.sha256(b).hexdigest()
def gitsha(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C','/workspace/chicago',*args],env=env)
def indexed(ids):
 wanted=set(ids);found=set();obj=G/'objects'
 for s in wanted:
  if(obj/s[:2]/s[2:]).is_file():found.add(s)
 for idx in(obj/'pack').glob('*.idx'):
  if not wanted-found:break
  with idx.open('rb')as f:
   head=f.read(8);v2=head[:4]==b'\xfftOc';off=8 if v2 else 0
   if v2:assert struct.unpack('>I',head[4:])[0]==2
   f.seek(off);fan=struct.unpack('>256I',f.read(1024));table=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
   for s in wanted-found:
    key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
    while a<z:
     m=(a+z)//2;f.seek(table+m*stride+delta);value=f.read(20)
     if value<key:a=m+1
     else:z=m
    f.seek(table+a*stride+delta)
    if a<fan[key[0]]and f.read(20)==key:found.add(s)
 return found
compare=json.loads((B/'COMPARE.json').read_text());commit=json.loads((B/'COMMIT.json').read_text());assert[p['sha']for p in commit['parents']]==[OLD]and commit['message'].startswith('changelog: fold entry files');assert{(r['filename'],r['status'])for r in compare['files']}=={('chicago/4d/changelog.d/T-3161.json','removed'),('chicago/4d/data/liberties.json','modified'),('chicago/4d/docs/measurements/source_use_coverage.md','modified'),('chicago/4d/renderers/web/js/changelog.js','modified')}
rows=[];proof={}
for row in compare['files']:
 if row['status']=='removed':continue
 path=row['filename'];meta=json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/contents/'+path+'?ref='+TIP]));assert meta['sha']==row['sha'];rows.append({'path':path,'sha':row['sha'],'size':meta['size']})
 with urllib.request.urlopen('https://raw.githubusercontent.com/kevinrhaas/chicago/'+TIP+'/'+path,timeout=90)as response:new=response.read(meta['size']+65536)
 assert len(new)==meta['size']and gitsha(new)==row['sha'];old=git('cat-file','blob',OLD+':'+path);entry={'old_bytes':len(old),'new_bytes':len(new),'old_sha256':sha(old),'new_sha256':sha(new)}
 if path.endswith('data/liberties.json'):
  a=json.loads(old);b=json.loads(new);ca=a.pop('count');cb=b.pop('count');assert(ca,cb)==(796,797)and a==b;entry.update({'only_root_count_changes':True,'old_count':ca,'new_count':cb,'all_other_JSON_values_exact':True,'identical_without_count_sha256':sha(json.dumps(a,sort_keys=True,separators=(',',':')).encode()),'unchanged_names_rows':len(a['names'])})
 elif path.endswith('source_use_coverage.md'):
  before=b'| liberties (structured citations) | 796 | 0 | 0 |';after=b'| liberties (structured citations) | 797 | 0 | 0 |';assert old.count(before)==1 and old.replace(before,after)==new;entry['only_one_796_to797_count_table_row_changes']=True
 else:
  aa=old.splitlines(keepends=True);bb=new.splitlines(keepends=True);assert len(bb)==len(aa)+6 and bb[0]==aa[0]and bb[7:]==aa[1:];entry.update({'only_six_changelog_lines_inserted_after_first':True,'existing_changelog_tail_byte_exact':True,'inserted_text':b''.join(bb[1:7]).decode()})
 proof[path]=entry
found=indexed([r['sha']for r in rows])
for row in rows:row['present_pack_index_or_loose_only']=row['sha']in found
result={'status':'READONLY_GENUINE_T3161_FOLD407E_EXACT_SEMANTIC_AND_BLOB_PRICE_PASS','old':OLD,'tip':TIP,'tree':commit['tree']['sha'],'changed_paths':4,'new_source_blobs':rows,'new_blob_raw_total':sum(r['size']for r in rows if not r['present_pack_index_or_loose_only']),'routine_5MiB_envelope_fits':sum(r['size']for r in rows if not r['present_pack_index_or_loose_only'])<=5*1024**2,'proposed_canonical_envelope_including_metadata':10*1024**2,'semantics':proof,'no_source_objects_refs_index_config_or_worktree_writes':True,'no_missing_object_probes_or_lazyfetch':True,'native_active_so_NOIMPORT_NO_CAS':True,'workspace_free':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize,'tmp_free':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize}
(B/'EXACT-SEMANTIC-PRICE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='semantics'},indent=2))
