"""Prepared only. Actual checkpoint phone after truthful restart recovery; native household-note projection preserved."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess,sys,time,datetime
V2=Path('/workspace/PR1456-genuine54-lean-gate-v2-secondfort-20261030');assert hashlib.sha256((V2/'CLOSED-MANIFEST.json').read_bytes()).hexdigest()=='ac077de026442ffa0a8301baad19c5dc020fe6544e8a415bca61ea03eaa5c9b0'
for n,v in json.loads((V2/'CLOSED-MANIFEST.json').read_bytes())['members'].items():assert hashlib.sha256((V2/n).read_bytes()).hexdigest()==v['sha256']
sys.path.insert(0,str(V2));import gate as G
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--gate-dir',required=True,type=Path);ap.add_argument('--expect-head',required=True);ap.add_argument('--output',required=True,type=Path);ap.add_argument('--execute',action='store_true');a=ap.parse_args();assert a.execute and re.fullmatch('[0-9a-f]{40}',a.expect_head)
D=a.gate_dir.resolve();gate=json.loads((D/'GATE-RESULT.json').read_bytes());cp=json.loads((D/'CHECKPOINT-RESULT.json').read_bytes());b=gate['binding'];assert gate['status']=='ACTUAL_PR1456_GENUINE54_FULL1105_SOURCE_PASS_RESTART_RECOVERED'and all(gate['guards'].values())
assert gate['exit']==0 and gate['original_all_children_reaped']is False and gate['original_wrapper_exit_unknown']is True and gate['native_source_test_assertions_commands_and_output_unchanged']is True
closure=gate['restart_process_closure'];actual=closure['actual_root_exit'];assert closure['zero_live_owned_processes']is True and not closure['live_owned_pids']and closure['all_children_reaped']is False
assert actual['pid']==2654041 and actual['birth_ticks']=='46026680'and actual['state']=='Z'and actual['exit_wait_status']==0 and actual['exit_code']==0 and actual['actual_kernel_exit_status_not_inferred_from_footer']is True
assert G.pf(gate['restart_observation'])==gate['restart_observation_sha256']
observation=json.loads(Path(gate['restart_observation']).read_bytes());assert observation['status']=='ACTUAL_NATIVE_BODY_KERNEL_EXIT_AND_ZERO_LIVE_OWNED_PROCESSES_AFTER_CONTROLLER_RESTART'and observation['qualified_owner']=='gate'and observation['body']==closure
original=Path(gate['original_native_gate_dir']);assert original==Path('/workspace/PR1456-genuine54-root-actual-gate-20261030')
for name,key in [('GATE-BINDING.json','original_gate_binding_sha256'),('check.log','original_native_check_log_sha256'),('TIMINGS.tsv','original_timings_sha256'),('check-REAPER.json','original_reaper_sha256')]:assert G.pf(original/name)==gate[key]
assert json.loads((original/'GATE-BINDING.json').read_bytes())==b
old_reaper=json.loads((original/'check-REAPER.json').read_bytes());assert old_reaper['command_pid']==2654041 and old_reaper['command_exit']is None and old_reaper['all_children_reaped']is False
assert cp['status']=='ACTUAL_PR1456_GENUINE54_NATIVE_TWO_PARENT_CHECKPOINT_PASS'and cp['head']==a.expect_head and cp['parents']==[G.SOURCE,G.DEV]and cp['tree']==b['tree']and cp['pr_base']==G.DEV and cp['source_gate_sha256']==G.pf(D/'GATE-RESULT.json')and cp['staged_paths']==b['staged_paths']
m,msha=G.load(b['reviewed_manifest']);assert msha==b['reviewed_manifest_sha256']and m['tree']==cp['tree'];assert G.pf(V2/'gate.py')==b['helper_sha256']
assert cp['source_gate_controller_restart_recovered']is True and cp['source_gate_actual_native_body_exit0']is True and cp['source_gate_original_wrapper_exit_unknown']is True and cp['source_gate_orphan_zombies_not_falsely_reaped']is True
for n in ['changelog-entry','ticket-ids','fold-history']:
 r=json.loads((D/(n+'-REAPER.json')).read_bytes());assert r['command_exit']==0 and r['all_children_reaped']and not r['leftover_cleanup']
R,A=G.R,G.A;SITE=R/'site/4d';O=a.output.resolve();assert str(O).startswith('/workspace/')and not O.exists()and not O.is_relative_to(R)and not O.is_relative_to(Path('/workspace/chicago'));O.mkdir()
save=lambda n,d:(O/n).write_text(json.dumps(d,indent=2)+'\n');E=dict(G.E);TMP=Path('/workspace/p1456-ph54');assert not TMP.exists();assert shutil.disk_usage('/workspace').free>=536870912+128*1048576 and shutil.disk_usage('/tmp').free>=1800000000
TMP.mkdir(mode=0o700);(TMP/'OWNER').write_text(a.expect_head+'\n');E.update(TMPDIR=str(TMP),TMP=str(TMP),TEMP=str(TMP),NODE_COMPILE_CACHE=str(TMP/'node-compile-cache'))
config=G.pf(R/'.git/config');ix=G.index();rf=G.refs();ceil=(A/'tools/memory_ceilings.json').read_bytes();assert ceil==G.g('show',G.DEV+':chicago/4d/tools/memory_ceilings.json')and json.loads(ceil)['ceilings']['1904']['mobile']['total_bytes']==400*1048576
assert(SITE/'1904/index.html').is_file()and(SITE/'build.json').is_file();pub={str(f.relative_to(SITE)):dict(sha256=G.pf(f),bytes=f.stat().st_size)for f in sorted(SITE.rglob('*'))if f.is_file()};assert len(pub)>100
models={};reg=json.loads((A/'assets/manifest.json').read_bytes())['assets'];web=json.loads((A/'assets/manifest.web.json').read_bytes())['masters'];targets={'miller_house','chicago_lighthouse_1832','st_marys_church','hogan_store'};found=set()
for name,row in reg.items():
 if row.get('structure_id')not in targets:continue
 found.add(row['structure_id']);master=A/'assets/gltf'/name;derivative=A/'assets/web'/name;delivered=SITE/'data/gltf'/name;assert G.pf(master)==web[name]and G.pf(derivative)==G.pf(delivered);models[name]=dict(structure_id=row['structure_id'],MASTER=G.pf(master),WEB=G.pf(derivative),published=G.pf(delivered))
assert found==targets
joins={};source_files={};sidecar_projections={}
for name in models:
 for folder in ['assets/gltf','assets/web']:
  rel=folder+'/'+name;source_files[rel]=G.pf(A/rel)
for rel in ['data/scenes/1835.json','data/scenes/1904.json']:
 assert(A/rel).read_bytes()==(SITE/rel).read_bytes();joins[rel]=G.pf(A/rel);source_files[rel]=G.pf(A/rel)
projector='tools/defer_household_notes.mjs';projector_bytes=(A/projector).read_bytes()
assert projector_bytes==G.g('show',G.DEV+':chicago/4d/'+projector)==G.g('show',G.SOURCE+':chicago/4d/'+projector)
source_files[projector]=G.sha(projector_bytes)
prior_path=Path('/workspace/PR1456-currentbc7-runtime-audit-v2-first-fort-20261030/BODY-PEOPLE-REUSE.json')
prior_sha='164299a5d7344873139583564ddc45af8567033b737e48fb10977046b260ff1d';assert G.pf(prior_path)==prior_sha;prior_rows={r['path']:r['current_sha256']for r in json.loads(prior_path.read_bytes())['rows']}
for sid in sorted(targets):
 rel='data/sidecars/1835/'+sid+'.json';native=(A/rel).read_bytes();published=(SITE/rel).read_bytes();record=json.loads(native)
 assert G.sha(native)==prior_rows['/workspace/chicago/chicago/4d/'+rel]and G.sha(published)==prior_rows['/workspace/chicago/site/4d/'+rel]
 full=record.get('residents');deferred=isinstance(full,list)and len(full)>0
 if deferred:
  slim=[]
  for household in full:
   row={k:v for k,v in household.items()if k not in ['why','research_note']}
   if isinstance(household.get('persons'),list):row['persons']=[{k:v for k,v in person.items()if k!='note'}for person in household['persons']]
   slim.append(row)
  assert json.loads(published)=={**record,'residents':slim}
  hrel='data/sidecars/1835/households/'+sid+'.json';assert json.loads((SITE/hrel).read_bytes())=={'id':record['id'],'residents':full};joins[hrel]=G.pf(SITE/hrel)
 else:assert published==native
 source_files[rel]=G.sha(native);joins[rel]=G.sha(published);sidecar_projections[sid]=dict(source_sha256=G.sha(native),published_sha256=G.sha(published),native_household_notes_deferred=deferred,source_and_published_byte_equality_claimed=not deferred,projection='Exact native household notes split; residents only remove household why/research_note and person note; full residents ship in households sidecar'if deferred else'Native publication copy byteexact',accepted3746_published_bytes_exact=True)
for name in ['railway.js','spatial-batch.js']:
 assert(A/'renderers/web/js'/name).read_bytes()==(SITE/'walk/js'/name).read_bytes();joins['walk/js/'+name]=G.pf(SITE/'walk/js'/name);source_files['renderers/web/js/'+name]=G.pf(A/'renderers/web/js'/name)
version=json.loads((SITE/'build.json').read_bytes()).get('version','');assert version and(a.expect_head.startswith(version)or G.SOURCE.startswith(version))
publication_kind='native_publication_at_actual_checkpoint'if a.expect_head.startswith(version)else'unchanged_gate_publication_from_exact_checked_staged_tree_before_commit'
tickets=G.ticket_context(m,cp['tickets_after']['head']);gate_sha=G.pf(D/'GATE-RESULT.json');cp_sha=G.pf(D/'CHECKPOINT-RESULT.json')
def guard():
 assert G.g('rev-parse','HEAD').decode().strip()==a.expect_head and G.g('rev-parse','HEAD^{tree}').decode().strip()==cp['tree']and G.g('show','-s','--format=%P',a.expect_head).decode().strip().split()==cp['parents']
 assert G.g('branch','--show-current').decode().strip()==G.BRANCH and G.g('rev-parse','origin/dev').decode().strip()==G.DEV and not(R/'.git/MERGE_HEAD').exists()and not G.g('status','--porcelain=v1','--untracked-files=all')
 assert G.index()==ix and G.refs()==rf and G.pf(R/'.git/config')==config and all(G.pathsha(p)==h for p,h in cp['staged_paths'].items())
 assert all(G.pathsha(p)==h for p,h in{**m['required404_dependency_paths'],**m['protected404_performance_paths'],**m['ignored_dependencies']['source_sha256']}.items())
 assert all(G.pf(A/p)==h for p,h in source_files.items())
 assert{str(f.relative_to(SITE)):dict(sha256=G.pf(f),bytes=f.stat().st_size)for f in sorted(SITE.rglob('*'))if f.is_file()}==pub
 assert(A/'tools/memory_ceilings.json').read_bytes()==ceil and G.pf(D/'GATE-RESULT.json')==gate_sha and G.pf(D/'CHECKPOINT-RESULT.json')==cp_sha and G.pf(b['reviewed_manifest'])==msha
 G.ticket_context(m,tickets['head']);r=G.resource(m);assert r['workspace_pass']and r['shared_TMP_pass']and r['clone_cap_pass']
guard();cmd=['node','tools/measure_memory.mjs','--year','1904','--only','mobile','--gate','--no-snapshot','--json',str(O/'PHONE.json')]
binding=dict(revision='PR1456_GENUINE_54',head=a.expect_head,tree=cp['tree'],parents=cp['parents'],pr_base=G.DEV,branch=G.BRANCH,source_gate=str(D/'GATE-RESULT.json'),source_gate_sha256=gate_sha,native_checkpoint=str(D/'CHECKPOINT-RESULT.json'),native_checkpoint_sha256=cp_sha,staged_paths=cp['staged_paths'],required404_dependency_paths=m['required404_dependency_paths'],protected404_performance_paths=m['protected404_performance_paths'],source_config_sha256=config,index_semantics=ix,all_refs=rf,models=models,source_published_joins=joins,published_files=pub,published_build_version=version,source_runtime_files=source_files,native_sidecar_projection=sidecar_projections,accepted3746_sidecar_proof_sha256=prior_sha,source_gate_controller_restart_recovered=True,source_gate_original_all_children_reaped=False,source_gate_original_wrapper_exit_unknown=True,source_gate_actual_kernel_exit0_and_no_live_owned_processes=True,publication_kind=publication_kind,memory_config_sha256=G.sha(ceil),memory_limit_bytes=400*1048576,command=cmd,CPU_affinity=[2],nice=19,TMPDIR=str(TMP),ordinary_native_clone_no_root_override_or_alias=True,helper_sha256=G.pf(Path(__file__)),prior_phone_results_not_reused=True)
save('PHONE-BINDING.json',binding);rp=O/'PHONE-REAPER.json';argv=['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','nice','-n','19','taskset','-c','2',*cmd];start=time.monotonic()
with(O/'PHONE.log').open('xb')as log:q=subprocess.run(argv,cwd=A,env=E,stdout=log,stderr=subprocess.STDOUT)
r=json.loads(rp.read_bytes());raw=json.loads((O/'PHONE.json').read_bytes())if(O/'PHONE.json').exists()else{};rows=raw.get('rows',[]);peak=rows[0]['totals']['total']/1048576 if len(rows)==1 else None;guard_error=None
try:guard();assert G.pf(Path(__file__))==binding['helper_sha256']
except Exception as e:guard_error=repr(e)
passed=q.returncode==0 and r['command_exit']==0 and r['all_children_reaped']and not r['leftover_cleanup']and guard_error is None and len(rows)==1 and rows[0]['year']=='1904'and rows[0]['viewport']=='mobile'and not rows[0]['errors']and peak is not None and 0<peak<=400
save('PHONE-RESULT.json',dict(status='ACTUAL_PR1456_GENUINE54_CURRENT_CHECKPOINT_PHONE400_PASS'if passed else'ACTUAL_PR1456_GENUINE54_CURRENT_CHECKPOINT_PHONE_NOT_QUALIFIED',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=a.expect_head,tree=cp['tree'],parents=cp['parents'],source_gate_sha256=gate_sha,native_checkpoint_sha256=cp_sha,source_gate_controller_restart_recovered=True,source_gate_original_all_children_reaped=False,source_gate_original_wrapper_exit_unknown=True,source_gate_actual_kernel_exit0_and_no_live_owned_processes=True,actual_complete_1904_mobile_peak_MiB=peak,unchanged_limit_MiB=400,exit=q.returncode,seconds=time.monotonic()-start,command=cmd,actual_measurement_sha256=G.pf(O/'PHONE.json')if(O/'PHONE.json').exists()else None,reaper_sha256=G.pf(rp),all_children_reaped=r['all_children_reaped'],source_published_guards_exact=guard_error is None,guard_error=guard_error,errors=rows[0]['errors']if len(rows)==1 else['no complete actual row'],published_browser_coverage_separate_not_claimed=True,owned_TMP_retained_for_exact_root_cleanup=str(TMP)))
print((O/'PHONE-RESULT.json').read_text());raise SystemExit(0 if passed else 1)
