# PR1456 genuine54 phone V2 — prepared only

No helper/native browser/meter/source action executed. Original frozen V1 remains unchanged at /workspace/PR1456-genuine54-phone-prep-secondfort-20261030. Root must review this new adapter before execution.

The official command, 1904/mobile/400MiB native ceiling, ordinary checkout publication, waits/instrumentation/assertions, CPU2/nice19, exact current checkpoint[3746,54], full publication/index/refs/config/source/resource guards and owned short TMP are unchanged.

## Focused corrections

1. Native1105 check survived the controller restart. V2 requires the separate ACTUAL_PR1456_GENUINE54_FULL1105_SOURCE_PASS_RESTART_RECOVERED receipt, all original source/native guards, actual kernel root exit0 from PID2654041/birth46026680, zero live owned native processes, exact closed-observation hash/body, unchanged original gate binding/check log/timings/reaper hashes and the original reaper's command_exit=null/all_children_reaped=false. It does not manufacture an old wrapper exit or claim zombies reaped. The native two-parent checkpoint must explicitly carry recovered source-gate flags, match the real source-gateSHA, and all three NEW native PR-question reapers must actually close successfully.

2. Native publish deliberately splits household notes (tools/defer_household_notes.mjs). V1's blanket source=published sidecar assertion was false for Hogan and Mary. V2 pins the exact unchanged canonical3746/54 native projector source, verifies the exact native split semantically (only household why/research_note and person note leave the boot record; full source residents survive in the separate households sidecar), and ALSO requires exact accepted3746 full source and actual published hashes from its closed BODY/People artifact. Miller/lighthouse still require byteexact source/publication. The stronger exact accepted published-byte bound is retained.

3. Actual source MASTER+WEB files, scenes, four sidecars, railway/spatial modules and native projector are additionally rehashed before/after the phone. No source alias, root override, fixture model or assertion weakening is introduced.

## Root execution after actual recovered gate and genuine checkpoint PASS

    source /workspace/shared/resume-chicago-env.sh
    nice -n 19 taskset -c 2 python -B /workspace/PR1456-genuine54-phone-v2-restart-and-native-sidecar-prep-20261030/phone.py --gate-dir ACTUAL_RECOVERED_GATE_AND_CHECKPOINT_DIRECTORY --expect-head ACTUAL_NATIVE_CHECKPOINT_HEAD --output NEW_OWN_PHONE_OUTPUT --execute

The publication version may truthfully name parent3746 because check.sh publishes the exact stagedtree before commit; this is explicitly bound as such, never restamped. Actual current phone PASS requires its own native exit0, all children reaped, no cleanup, one complete1904mobile row, zero page errors, <=400MiB, unchanged source/publication and floors. It does not qualify ALL15 browser parts, current CI, original ticket completion or finaldev merge.

Prepared by AST/static read-only analysis only. Frozen files immutable after handoff; later adjustments need another folder.
