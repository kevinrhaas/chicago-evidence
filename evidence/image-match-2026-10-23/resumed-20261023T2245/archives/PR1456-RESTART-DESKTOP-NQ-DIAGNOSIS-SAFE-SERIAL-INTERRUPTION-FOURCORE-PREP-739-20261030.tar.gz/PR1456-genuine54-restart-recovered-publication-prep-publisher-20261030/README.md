# PR1456 ordinary source checkpoint publication — preparation only

This recovered frozen helper is byte-exact the pre-restart firstfort publication helper. It has not executed. Root retains all source mutation and API-write authority; this packet performs none.

After an actual native1105 source PASS and genuine ordinary checkpoint exist, run READONLY first:

    source /workspace/shared/resume-chicago-env.sh
    nice -n19 taskset -c2 python -B CAPSULE/publish_native.py --checkpoint ACTUAL_CHECKPOINT_RESULT_JSON --expect-head ACTUAL_NATIVE_HEAD --expected-lap ddebfe1b81995850bca82bc4eea1957e459bb1b9 --output NEW_EXTERNAL_READONLY_OUTPUT

Review PLAN then issue the same command with a new external output and `--publish`. The default16MiB/new-blob bound may be raised only to32MiB by explicit argument, never without reviewing the measured plan. The helper will not work while the actual merge is still staged, while a source gate is pending, or on a different native parent pair.

Bindings: repositorykevinrhaas/chicago; source ordinary clone/worktree /workspace/t2372-parallel-native-20261030; branchsteward/t2381-t2373-t2384-t2377-early-pictures-20261029; oldremote3746b23bf1298c34a29946b4cdb6ee2d98abff8f; nativeparents exactly[3746,54e4004add7ab5208d71a51282c008cda6e7edad]. Future actualnativehead remains unknown; source tree expected444505c7ca5a22c7e90c653a10f579630be6978c through the approved manifest/gate/checkpoint chain. This is not a40453ancestry claim. Source config/index semantics/status/allrefs/working blobs must remain exact.

Only source-qualified normal-FF publication is authorized by the helper: actual sourcegate, actualnativecheckpoint+threePRquestions, fullstagedmap and own/foreign proof bindings, exact nativecommit/tree/parent preservation, remote existingparent/blobreuse, exactown live lap, sourcebefore/after guards, then `force:false` remote branch update and immutable allchangedpath readback. No rewrite, forcedrefs, workflowdispatch, forgedCI, admin, PRbody/label, dev/main/production write or runtime result manufacture exists. Phone/BOTH/PR1486/actualrequiredCI/finalnormaldevmerge remain visibly pending; these are final-merge prerequisites, not prerequisites to this reversible source checkpoint push.

The cloud restart stopped the original native gate controller/reaper while check.sh continued. An interrupted controller is not a sourcePASS; do not invent the old wrapper exit or cleanup result to satisfy this helper. Root recovery must first produce truthful qualified native receipts, or rerun as required.

At17:28UTC the live PR1456 remains3746/non-draft/open/dirty and currentdev8b4e98207c1afcff4878239cd700379447218cfb. Pre-restart external native merge-file inspection for the actual4445tree vs named8b predicts exactlythree generated content conflicts: data/liberties.json; data/sidecars/1835/sources/index.json; docs/measurements/source_use_coverage.md. The otherfour overlapping registries/LIBERTIES.md/rightsbaseline merge cleanly. A54checkpoint push saves work but does not resolve those newer8b conflicts, and cannot by itself start requiredCI if GitHub cannot form a merge ref. No promise of clean server state is made.

The current PRbody includes earlier3746 actual1105source852.810s and398.984MiB/400mobile PASS; reused geometry/Images/eight Peoplecaptures with eight consumer qualifications; it explicitly does not claim freshfullBOTH. These dated claims must remain dated. The body template has placeholders and is NOT ready for external publication. Populate only actual sourcecheckpoint facts, retain exact inherited runtime limits and pendingcurrent8b repair.

## Explicit controller-restart variant

This new frozen helper intentionally accepts only `ACTUAL_PR1456_GENUINE54_FULL1105_SOURCE_PASS_RESTART_RECOVERED` from the reviewed recovery finalizer. The original normal gate/controller/reaper receipts remain unchanged and unqualified. All native1105/footer/source/provenance/resource guards must still be true; the original kernel-observed Bash PID2654041/birth46026680 must have actualLinuxzombie exit0, zero live owned processes, and an explicit false all_children_reaped. The observation and unchanged original binding/log/timings/interrupted-reaper hashes are verified. CP retains its genuine native checkpoint status but must explicitly report source_gate_controller_restart_recovered/actual_native_body_exit0/original_wrapper_exit_unknown/orphan_zombies_not_falsely_reaped. Three fresh ordinary PR-question reapers still need actualexit0/allreaped/no cleanup. Source/publication/nativeparent/normalFF/remote guards are unchanged. No old wrapper completion or old allreapedPASS is invented. Exact source patch documents this sole schema adaptation.
