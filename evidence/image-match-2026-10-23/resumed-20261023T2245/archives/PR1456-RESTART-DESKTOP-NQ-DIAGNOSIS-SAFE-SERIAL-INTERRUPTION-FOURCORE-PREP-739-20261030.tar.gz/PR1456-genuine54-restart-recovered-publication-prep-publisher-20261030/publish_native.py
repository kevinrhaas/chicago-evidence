"""Bounded native-commit transport. Default is read-only planning; no git push/fetch.

Run only after the actual checked final native commits exist. --publish additionally
requires the exact checked final tree, a passing gate receipt, and explicit expected
remote branch state. Native Git SHAs, trees, messages, author dates and parents stay exact.
"""
from pathlib import Path
import argparse,base64,datetime,hashlib,json,os,re,struct,subprocess
from urllib.request import Request,urlopen
from urllib.error import HTTPError

REPO='kevinrhaas/chicago';SOURCE=Path('/workspace/t2372-parallel-native-20261030');G=SOURCE/'.git'
BRANCH='steward/t2381-t2373-t2384-t2377-early-pictures-20261029'
LIBRARY_OUTPUTS=set(['chicago/prairie_1904_v1/data/images.json', 'chicago/prairie_1904_v1/research/images/STORE.json', 'chicago/prairie_1904_v1/research/images/stream-early-chicago-lighthouse-reference.json', 'chicago/prairie_1904_v1/research/images/stream-early-chicago-miller-hogan-references.json', 'chicago/prairie_1904_v1/research/images/stream-st-mary-reference.json'])
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*args):
    return subprocess.check_output(['git','-C',str(SOURCE),'-c','gc.auto=0','-c','maintenance.auto=false',*args],env=ENV)
def shab(b):return hashlib.sha256(b).hexdigest()
def gitsha(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def api(path,data=None,method=None,missing=False):
    req=Request('https://api.github.com/repos/'+REPO+'/'+path,data=None if data is None else json.dumps(data).encode(),headers={'User-Agent':'Chicago-four-case-exact-native-transport','Accept':'application/vnd.github+json','Content-Type':'application/json'},method=method or('GET'if data is None else'POST'))
    try:
        with urlopen(req,timeout=120)as r:return json.load(r)
    except HTTPError as e:
        if missing and e.code==404:return None
        raise
def indexed(wanted):
    wanted=set(wanted);found={s for s in wanted if(G/'objects'/s[:2]/s[2:]).is_file()}
    for p in(G/'objects/pack').glob('*.idx'):
        if wanted<=found:break
        with p.open('rb')as f:
            h=f.read(8);v2=h[:4]==b'\xfftOc';off=8 if v2 else 0
            if v2:assert struct.unpack('>I',h[4:])[0]==2
            f.seek(off);fan=struct.unpack('>256I',f.read(1024));tab=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
            for s in wanted-found:
                key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
                while a<z:
                    m=(a+z)//2;f.seek(tab+m*stride+delta)
                    if f.read(20)<key:a=m+1
                    else:z=m
                f.seek(tab+a*stride+delta)
                if a<fan[key[0]]and f.read(20)==key:found.add(s)
    return found
def obj(kind,s):
    b=git('cat-file',kind,s);assert gitsha(kind,b)==s;return b
TREES={}
def leaves(s):
    if s in TREES:return TREES[s]
    b=obj('tree',s);i=0;out={}
    while i<len(b):
        n=b.index(b' ',i);mode=b[i:n].decode();z=b.index(b'\0',n+1);name=b[n+1:z].decode();child=b[z+1:z+21].hex();i=z+21
        assert name not in ('.','..')and'/'not in name
        if mode=='40000':out.update({name+'/'+p:v for p,v in leaves(child).items()})
        else:
            assert mode in('100644','100755','120000','160000')
            out[name]=(mode,'commit'if mode=='160000'else'blob',child)
    TREES[s]=out;return out
def commit(s):
    raw=obj('commit',s);header,msg=raw.split(b'\n\n',1);lines=header.decode().splitlines()
    return {'sha':s,'raw_sha256':shab(raw),'raw':raw,'lines':lines,'message':msg.decode(),'tree':next(x[5:]for x in lines if x.startswith('tree ')),'parents':[x[7:]for x in lines if x.startswith('parent ')]}
def native_payload(c):
    assert all(x.startswith(('tree ','parent ','author ','committer '))for x in c['lines']),'Unsupported signed/extra native header; do not rewrite native commit'
    p={'tree':c['tree'],'parents':c['parents'],'message':c['message']}
    for k in['author','committer']:
        line=next(x for x in c['lines']if x.startswith(k+' '));m=re.fullmatch(k+r' (.*) <([^>]+)> (\d+) ([+-]\d{4})',line);assert m
        zone=m[4];offset=(int(zone[1:3])*60+int(zone[3:]))*60*(1 if zone[0]=='+'else-1)
        dt=datetime.datetime.fromtimestamp(int(m[3]),datetime.timezone(datetime.timedelta(seconds=offset)))
        p[k]={'name':m[1],'email':m[2],'date':dt.isoformat()}
    return p
def snapshot():
    return {'HEAD':git('rev-parse','HEAD').decode().strip(),'refs':git('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{'config':shab((G/'config').read_bytes()),'index_stage':shab(git('ls-files','--stage','-z')),'index_flags':shab(git('ls-files','-v','-z'))},'status':git('status','--porcelain','--untracked-files=all').decode()}

OLD='3746b23bf1298c34a29946b4cdb6ee2d98abff8f';DEV='54e4004add7ab5208d71a51282c008cda6e7edad';DEP='40453bde8ba1812925d61fef118782a30323f98e'
def proof(p):
    raw=Path(p).read_bytes();return json.loads(raw),shab(raw)
def main():
    p=argparse.ArgumentParser(description='Source-qualified native one-commit FF checkpoint only; runtime/CI/dev merge remain pending.')
    p.add_argument('--checkpoint',required=True);p.add_argument('--expect-head',required=True);p.add_argument('--expected-old',default=OLD);p.add_argument('--expected-lap',required=True);p.add_argument('--output',required=True);p.add_argument('--max-total-bytes',type=int,default=16*1024**2);p.add_argument('--publish',action='store_true');a=p.parse_args()
    os.sched_setaffinity(0,{2});os.nice(19);assert a.expected_old==OLD and re.fullmatch('[0-9a-f]{40}',a.expect_head)and re.fullmatch('[0-9a-f]{40}',a.expected_lap);assert 0<a.max_total_bytes<=32*1024**2
    out=Path(a.output).resolve();assert str(out).startswith('/workspace/')and not out.is_relative_to(SOURCE)and not out.exists();out.mkdir();save=lambda n,x:(out/n).write_text(json.dumps(x,indent=2)+'\n')
    cp,cpsha=proof(a.checkpoint);assert cp['status']=='ACTUAL_PR1456_GENUINE54_NATIVE_TWO_PARENT_CHECKPOINT_PASS'and cp['revision']=='PR1456_GENUINE_54'and cp['head']==a.expect_head and cp['parents']==[OLD,DEV]and cp['branch']==BRANCH and cp['clean']is True and cp['only_own_branch_ref_changed']is True
    gate,gs=proof(cp['source_gate']);assert gs==cp['source_gate_sha256']and gate['status']=='ACTUAL_PR1456_GENUINE54_FULL1105_SOURCE_PASS_RESTART_RECOVERED'and gate['guards']and all(v is True for v in gate['guards'].values())
    assert gate['exit']==0 and gate['original_all_children_reaped']is False and gate['original_wrapper_exit_unknown']is True and gate['native_source_test_assertions_commands_and_output_unchanged']is True
    assert all(gate['guards'][k]is True for k in ['actual_uninterrupted_native_body_kernel_exit0','zero_live_owned_native_processes','orphan_zombies_explicit_not_falsely_reaped','original_reaper_receipts_unchanged','full1105_footer','native_publish_ran'])
    closure=gate['restart_process_closure'];actual=closure['actual_root_exit']
    assert closure['zero_live_owned_processes']is True and not closure['live_owned_pids']and closure['all_children_reaped']is False
    assert actual['pid']==2654041 and actual['birth_ticks']=='46026680'and actual['state']=='Z'and actual['exit_wait_status']==0 and actual['exit_code']==0 and actual['actual_kernel_exit_status_not_inferred_from_footer']is True
    observation,obsha=proof(gate['restart_observation']);assert obsha==gate['restart_observation_sha256']and observation['status']=='ACTUAL_NATIVE_BODY_KERNEL_EXIT_AND_ZERO_LIVE_OWNED_PROCESSES_AFTER_CONTROLLER_RESTART'and observation['qualified_owner']=='gate'and observation['body']==closure
    original=Path(gate['original_native_gate_dir']);assert original==Path('/workspace/PR1456-genuine54-root-actual-gate-20261030')
    for rel,key in [('GATE-BINDING.json','original_gate_binding_sha256'),('check.log','original_native_check_log_sha256'),('TIMINGS.tsv','original_timings_sha256'),('check-REAPER.json','original_reaper_sha256')]:assert shab((original/rel).read_bytes())==gate[key]
    interrupted=json.loads((original/'check-REAPER.json').read_bytes());assert interrupted['command_pid']==2654041 and interrupted['command_exit']is None and interrupted['all_children_reaped']is False
    assert interrupted['command']==['nice','-n','19','taskset','-c','2','bash','tools/check.sh']
    assert cp['source_gate_controller_restart_recovered']is True and cp['source_gate_actual_native_body_exit0']is True and cp['source_gate_original_wrapper_exit_unknown']is True and cp['source_gate_orphan_zombies_not_falsely_reaped']is True
    b=gate['binding'];assert b['head']==OLD and b['merge_parent']==DEV and b['parents']==[OLD,DEV]and b['tree']==cp['tree']and b['staged_paths']==cp['staged_paths']
    m,msha=proof(b['reviewed_manifest']);assert msha==b['reviewed_manifest_sha256']==cp['reviewed_manifest_sha256']and m['root_reviewed']is True and m['status']=='ROOT_REVIEWED_PR1456_GENUINE_54_INTEGRATION_STAGED'and m['tree']==cp['tree']
    expected={'changelog-entry','ticket-ids','fold-history'};assert {s['name']for s in cp['steps']}==expected
    for s in cp['steps']:
        rp=Path(cp['source_gate']).parent/(s['name']+'-REAPER.json');r,rs=proof(rp);assert s['exit']==0 and s['reaper_sha256']==rs and r['command_exit']==0 and r['all_children_reaped']is True and not r['leftover_cleanup']
    for q in m['owned_original']['proof_files']+m['canonical_foreign_entrywise']['proof_files']+m['resource_price']['proof_files']:assert shab(Path(q['path']).read_bytes())==q['sha256']
    before=snapshot();save('SOURCE-BEFORE.json',before);assert before['HEAD']==a.expect_head and not before['status']and git('branch','--show-current').decode().strip()==BRANCH and not(G/'MERGE_HEAD').exists()
    assert before['metadata']['config']==m['source_config_sha256']and git('write-tree').decode().strip()==cp['tree']
    head=commit(a.expect_head);old=commit(OLD);dev=commit(DEV);dep=commit(DEP);assert head['parents']==[OLD,DEV]and head['tree']==cp['tree'];native_payload(head)
    current=leaves(head['tree']);prior=leaves(old['tree']);canonical=leaves(dev['tree']);changes={p:current.get(p)for p in sorted(set(current)|set(prior))if current.get(p)!=prior.get(p)}
    assert set(changes)==set(cp['staged_paths'])and 0<len(changes)<=192
    allowed={**m['owned_original']['reviewed_paths'],**m['canonical_foreign_entrywise']['mixed_paths'],**m['required404_dependency_paths']}
    for path in set(current)|set(canonical):
        if path not in allowed:assert current.get(path)==canonical.get(path),('Foreign canonical path drift',path)
    for path,h in {**allowed,**m['protected404_performance_paths'],**cp['staged_paths']}.items():
        if h is None:assert path not in current;continue
        raw=obj('blob',current[path][2]);assert shab(raw)==h and(SOURCE/path).read_bytes()==raw
    for c in [old,dev,dep]:
        remote=api('git/commits/'+c['sha']);assert remote['sha']==c['sha']and remote['tree']['sha']==c['tree']and[x['sha']for x in remote['parents']]==c['parents']
    pr=api('pulls/1456');ref=api('git/ref/heads/'+BRANCH);assert pr['state']=='open'and not pr['merged']and pr['head']['ref']==BRANCH and pr['head']['sha']==ref['object']['sha']==OLD and pr['base']['ref']=='dev'
    marker=api('git/ref/heads/lap/pr-1456');assert marker['object']['sha']==a.expected_lap;mc=api('git/commits/'+a.expected_lap);dt=datetime.datetime.fromisoformat(mc['committer']['date'].replace('Z','+00:00'));age=(datetime.datetime.now(datetime.timezone.utc)-dt).total_seconds()/3600;assert 0<=age<=3,'Native ticket.mjs markerDead policy: ageHours>3 is stale'
    known={v[2]for c in [old,dev,dep]for v in leaves(c['tree']).values()if v[1]=='blob'};needed={}
    for path,v in changes.items():
        if v is None:continue
        assert v[1]=='blob'and v[0]in('100644','100755')
        if v[2]not in known:
            raw=obj('blob',v[2]);needed[v[2]]={'bytes':len(raw),'sha256':shab(raw)}
    total=sum(x['bytes']for x in needed.values());assert total<=a.max_total_bytes
    plan={'status':'SOURCE_QUALIFIED_PR1456_NATIVE_FF_CHECKPOINT_PREPARED_NO_REMOTE_WRITE','head':head['sha'],'tree':head['tree'],'parents':head['parents'],'expected_old':OLD,'branch':BRANCH,'changed_paths':changes,'new_blob_bytes':total,'new_blobs':needed,'native_commit_raw_sha256':head['raw_sha256'],'gate':{'path':cp['source_gate'],'sha256':gs},'checkpoint':{'path':a.checkpoint,'sha256':cpsha},'reviewed_manifest_sha256':msha,'live_lap':{'sha':a.expected_lap,'age_hours':age,'message':mc['message']},'force':False,'runtime_phone_BOTH_1486_required_CI_and_dev_merge_pending':True,'404_remote_blob_reuse_is_not_404_ancestry':True};save('PLAN.json',plan);assert snapshot()==before
    if not a.publish:print(json.dumps({'status':plan['status'],'head':head['sha'],'new_blob_bytes':total}));return
    for oid,row in needed.items():
        raw=obj('blob',oid);assert len(raw)==row['bytes']and shab(raw)==row['sha256'];answer=api('git/blobs',{'encoding':'base64','content':base64.b64encode(raw).decode()});assert answer['sha']==oid
    entries=[]
    for path,v in changes.items():entries.append({'path':path,'mode':'100644','type':'blob','sha':None}if v is None else{'path':path,'mode':v[0],'type':v[1],'sha':v[2]})
    tree=api('git/trees',{'base_tree':old['tree'],'tree':entries});assert tree['sha']==head['tree'];answer=api('git/commits',native_payload(head));save('NATIVE-COMMIT.json',answer);assert answer['sha']==head['sha'],'Never rewrite native commit SHA'
    assert snapshot()==before and proof(a.checkpoint)[1]==cpsha and proof(cp['source_gate'])[1]==gs and proof(b['reviewed_manifest'])[1]==msha
    assert api('git/ref/heads/'+BRANCH)['object']['sha']==OLD and api('pulls/1456')['head']['sha']==OLD and api('git/ref/heads/lap/pr-1456')['object']['sha']==a.expected_lap
    answer=api('git/refs/heads/'+BRANCH,{'sha':head['sha'],'force':False},'PATCH');assert answer['object']['sha']==head['sha']and api('git/ref/heads/'+BRANCH)['object']['sha']==head['sha']
    published=api('git/commits/'+head['sha']);assert published['tree']['sha']==head['tree']and[x['sha']for x in published['parents']]==head['parents']
    from urllib.parse import quote
    rows=[]
    for path,v in changes.items():
        if v is None:continue
        with urlopen(Request('https://raw.githubusercontent.com/'+REPO+'/'+head['sha']+'/'+quote(path,safe='/'),headers={'User-Agent':'Chicago-source-qualified-PR1456-immutable-readback'}),timeout=120)as response:assert response.status==200;raw=response.read()
        assert gitsha('blob',raw)==v[2]and raw==obj('blob',v[2]);rows.append({'path':path,'mode':v[0],'blob':v[2],'bytes':len(raw),'sha256':shab(raw)})
    assert snapshot()==before;save('RESULT.json',{'status':'ACTUAL_SOURCE_QUALIFIED_PR1456_NATIVE_NORMAL_FF_CHECKPOINT_AND_ALL_CHANGED_PATH_READBACK_PASS','head':head['sha'],'tree':head['tree'],'parents':head['parents'],'expected_old':OLD,'branch':BRANCH,'force':False,'gate_sha256':gs,'checkpoint_sha256':cpsha,'readback':rows,'new_blob_bytes':total,'source_HEAD_index_semantics_config_status_allrefs_unchanged':True,'runtime_phone_BOTH_1486_required_CI_and_dev_merge_pending':True,'no_PR_body_label_merge_or_deployment_write':True});print((out/'RESULT.json').read_text())
if __name__=='__main__':main()
