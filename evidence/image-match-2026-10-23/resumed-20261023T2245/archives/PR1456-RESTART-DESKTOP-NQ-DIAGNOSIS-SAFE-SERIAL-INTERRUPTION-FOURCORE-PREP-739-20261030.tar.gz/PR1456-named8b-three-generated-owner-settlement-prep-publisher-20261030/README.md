# Actual named8b three-generated-conflict settlement — prepared only

No helper/native owner/source mutation ran during preparation. Root first finishes/saves the actual54CP, applies the closed missing8bobject import, and executes a genuine native8b merge into that actual54CP. Initial conflicts must exactly equal liberties.json,1835sources/index.json,and source_use_coverage.md. The helper refuses another shape; it never substitutes old whole blobs or rolls back foreign data.

Root command on that actual merge:

    source /workspace/shared/resume-chicago-env.sh
    nice -n 19 taskset -c 2 python -B CAPSULE/native_owners8b.py --expect-head ACTUAL54CP --checkpoint54 ACTUAL54CP_RESULT --import-result ACTUAL8B_IMPORT_RESULT --output NEW_EXTERNAL_OUTPUT --execute

Commands are unchanged native compile_liberties.py and compile_source_use.py, exactly two laps; lap2 must move nothing. Their output allowlist is derived from the actual incoming tools/derived_manifest.json. Every tracked byte outside those native outputs stays exact, source HEAD/MERGE_HEAD/index/flags/refs/config and primary context stay exact, all glTF/binaries stay exact. Six fresh actual reapers mustexit0/allreaped/no cleanup. Native1904 scene and front-yard checks follow. At most the exact3known generated files may actually change. Final sourcegate, staging, commit, phone, publication, CI and merge are NOT run or claimed. Source cap4.6GB, workspace floor512MiB, sharedTMP1.8GB and owned externalTMP maintained.

Root must independently review resulting own/foreign entrywise provenance before staging: own four liberty IDs remain exact actual54CP; all foreign liberties exact8b, including any changed global Hibbard brick population; five own source-index rows exactactual54CP/all509foreign exact8b; MASTER own353/native fingerprints unchanged and foreign677exact8b; WEB own3/foreign1027exact8b; original library5exactactual54CP; own authored doc notes remain; fourperformance filesexact40453; allother indexed modes/blobs/deletionsexact8b. Do not assert all29target-relevant liberties exactold if a shared global foreign population legitimately moved.

The new k01_dressings dependency is added only to K01 in mesh_inputs.py, so this does not on its own demand rebaking own log/frame353. Actual sourcefreshness/native1108gate still decides; no recipe retagging or metadata restamping is authorized. Root adds its separately reviewed smoke validation repair, then builds the actual staged tree/path map and root-reviewed8b manifest. Finalhead/tree are unknown until those actual operations.
