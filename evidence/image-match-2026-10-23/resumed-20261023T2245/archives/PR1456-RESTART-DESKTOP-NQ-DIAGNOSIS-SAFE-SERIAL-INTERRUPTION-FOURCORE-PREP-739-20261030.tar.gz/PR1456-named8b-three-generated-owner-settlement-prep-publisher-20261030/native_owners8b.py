"""Prepared only. Two unchanged native owners settle the three actual8b generated conflicts; no stage/commit."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess,time
R=Path('/workspace/t2372-parallel-native-20261030');A=R/'chicago/4d';P=Path('/workspace/chicago');TIP='8b4e98207c1afcff4878239cd700379447218cfb';OLD='3746b23bf1298c34a29946b4cdb6ee2d98abff8f';BASE='54e4004add7ab5208d71a51282c008cda6e7edad';BRANCH='steward/t2381-t2373-t2384-t2377-early-pictures-20261029'
EXPECTED={'chicago/4d/data/liberties.json','chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/docs/measurements/source_use_coverage.md'}
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');sha=lambda b:hashlib.sha256(b).hexdigest()
def g(r,*a):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false',*a],env=E)
def state(r):return dict(head=g(r,'rev-parse','HEAD').decode().strip(),branch=g(r,'branch','--show-current').decode().strip(),merge=(r/'.git/MERGE_HEAD').read_text()if(r/'.git/MERGE_HEAD').exists()else None,config=sha((r/'.git/config').read_bytes()),refs=sha(g(r,'for-each-ref','--format=%(refname) %(objectname)')),index=sha(g(r,'ls-files','--stage','-z')),flags=sha(g(r,'ls-files','-v','-z')))
def snap(paths):return {p:sha((R/p).read_bytes())if(R/p).is_file()else None for p in sorted(paths)}
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--expect-head',required=True);a.add_argument('--checkpoint54',required=True,type=Path);a.add_argument('--import-result',required=True,type=Path);a.add_argument('--output',required=True,type=Path);a.add_argument('--execute',action='store_true');a=a.parse_args();assert a.execute;os.sched_setaffinity(0,{2});os.nice(19)
 cpraw=a.checkpoint54.read_bytes();cp=json.loads(cpraw);iraw=a.import_result.read_bytes();im=json.loads(iraw)
 assert cp['head']==a.expect_head and cp['tree']=='444505c7ca5a22c7e90c653a10f579630be6978c'and cp['parents']==[OLD,BASE]and cp['status']=='ACTUAL_PR1456_GENUINE54_NATIVE_TWO_PARENT_CHECKPOINT_PASS'
 assert im['status']=='ACTUAL_NAMED8B_MISSING_ONLY_NATIVE_OBJECT_IMPORT_PASS_SOURCE_PRIMARY_INDEX_CONFIG_REFS_WORKING_BYTES_UNCHANGED'and im['tip']==TIP and im['source_checkpoint_head']==a.expect_head
 assert g(R,'rev-parse','HEAD').decode().strip()==a.expect_head and g(R,'branch','--show-current').decode().strip()==BRANCH and g(R,'rev-parse','MERGE_HEAD').decode().strip()==TIP
 assert g(R,'show','-s','--format=%P','HEAD').decode().strip().split()==[OLD,BASE]
 commands=[['python3','tools/compile_liberties.py'],['python3','tools/compile_source_use.py']];manifest=json.loads((A/'tools/derived_manifest.json').read_bytes());owned={p for s in manifest['steps']if s['command']in commands for p in s['resolves']}
 conflicts=set(g(R,'diff','--name-only','--diff-filter=U').decode().splitlines());assert conflicts==EXPECTED and conflicts<=owned,conflicts
 assert not g(R,'ls-files','--others','--exclude-standard')
 O=a.output.resolve();assert not O.exists()and O.is_relative_to('/workspace')and not O.is_relative_to(R)and not O.is_relative_to(P);O.mkdir();save=lambda n,d:(O/n).write_text(json.dumps(d,indent=2)+'\n')
 T=O/'tmp';T.mkdir();owner=dict(owner='PR1456_NAMED8B_NATIVE_GENERATED_OWNERS',source=a.expect_head,merge_parent=TIP);marker=T/'OWNER.json';marker.write_text(json.dumps(owner)+'\n');marker_sha=sha(marker.read_bytes());E.update(TMPDIR=str(T),TMP=str(T),TEMP=str(T))
 tracked={p.decode()for p in g(R,'ls-files','-z').split(b'\0')if p};before=snap(tracked);immutable={p:v for p,v in before.items()if p not in owned};models={p:v for p,v in before.items()if p.endswith('.glb')};binary={p:v for p,v in before.items()if p.endswith(('.gz','.xlsx'))};source=state(R);primary=state(P);steps=[];laps=[];start=time.monotonic()
 save('BEFORE-ALL-TRACKED.json',before);save('BEFORE-MODELS.json',models);save('BEFORE-BINARIES.json',binary);save('BINDING.json',dict(source=source,primary=primary,commands=commands,actual_owned_paths=sorted(owned),actual_conflicts=sorted(conflicts),all_tracked_count=len(before),checkpoint54=str(a.checkpoint54),checkpoint54_sha256=sha(cpraw),import_result=str(a.import_result),import_result_sha256=sha(iraw),models=len(models),binary=len(binary),no_primary_write=True))
 def guard():
  assert state(R)==source and state(P)==primary and snap(immutable)==immutable
  assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
  assert int(subprocess.check_output(['du','-s','-B1',str(R)]).split()[0])<=4600000000
 def native(name,cmd):
  guard();t=time.monotonic();rp=O/(name+'-REAPER.json')
  with(O/(name+'.log')).open('x')as f:q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','taskset','-c','2','nice','-n','19',*cmd],cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
  rr=json.loads(rp.read_bytes());row=dict(name=name,argv=cmd,exit=q.returncode,seconds=time.monotonic()-t,reaper=str(rp),reaper_sha256=sha(rp.read_bytes()),all_children_reaped=rr['all_children_reaped']);steps.append(row);save('STEPS.json',steps)
  assert q.returncode==rr['command_exit']==0 and rr['all_children_reaped']and not rr['leftover_cleanup'];guard()
 for lap in [1,2]:
  previous=snap(owned)
  for i,c in enumerate(commands):native('lap'+str(lap)+'-owner'+str(i+1),c)
  after=snap(owned);laps.append(dict(lap=lap,moved_paths=[p for p in previous if previous[p]!=after[p]],after_sha256=after));save('LAPS.json',laps)
 assert not laps[-1]['moved_paths'],'No settled owner fixed point'
 native('scene1904-check',['python3','tools/compile_scene.py','--scene','1904','--check']);native('frontyards-check',['python3','tools/plant_prairie_1904_front_yards.py','--check'])
 guard();after=snap(tracked);changed={p for p in before if before[p]!=after[p]};assert changed==EXPECTED,changed;assert snap(models)==models and snap(binary)==binary
 assert sha(a.checkpoint54.read_bytes())==sha(cpraw)and sha(a.import_result.read_bytes())==sha(iraw)and sha(marker.read_bytes())==marker_sha
 marker.unlink();T.rmdir()
 save('RESULT.json',dict(status='ACTUAL_PR1456_NAMED8B_TWO_NATIVE_OWNERS_TWO_LAPS_FIXED_POINT_AND1904_CHECKS_PASS',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_head=a.expect_head,merge_parent=TIP,seconds=time.monotonic()-start,steps=steps,changed_paths=sorted(changed),changed_path_sha256={p:after[p]for p in sorted(changed)},second_lap_moved_nothing=True,all_models_and_binaries_exact=True,all_nonowned_tracked_bytes_exact=True,primary_and_clone_HEAD_config_index_refs_exact=True,stage_or_commit=False,final_staged_tree='UNKNOWN_PENDING_ROOT_STAGE_AND_REVIEW',source_gate_phone_publication_CI_merge_not_run=True,workspace_free=shutil.disk_usage('/workspace').free,tmp_free=shutil.disk_usage('/tmp').free));print((O/'RESULT.json').read_text())
if __name__=='__main__':main()
