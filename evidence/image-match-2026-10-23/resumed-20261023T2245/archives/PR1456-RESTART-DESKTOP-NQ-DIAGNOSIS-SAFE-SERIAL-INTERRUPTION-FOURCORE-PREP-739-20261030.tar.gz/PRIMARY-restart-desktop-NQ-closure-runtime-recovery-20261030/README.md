# Actual restarted-controller desktop failure — closed

The original native desktop body completed naturally with real Linux zombie waitstatus256/exit1 at17:30:33. The original desktop log says503passed/3failed; all3 failures are preserved verbatim in RESULT.json. It also records completed suite body and zero page errors. No mobile started or qualified, no BOTH PASS.

Original Python controller/reaper died during environment reconnect. Original desktop reaper remains byte-exact with command_exitnull/all_children_reapedfalse. Detached read-only observer captured original native PID2613607 birth45427107 in zombie state and all owned descendant/session processes closed; orphan zombies are explicitly not reaped. No root exit was guessed from a footer.

Authorized read-only close.py executed once successfully using unchanged pinned common.committed binder: exact40453 source/tree/parents/branch/index/config/allrefs/model/data/memoryconfig/published maps before/after match the original BINDING. RESULT references actual original log/reaper/binding/observerSHA and full closure. No source/index/ref/config/site/process signal/ptrace/mobile/API action occurred. A first malformed shell taskset -c2 command refused before Python execution; successful actual call used taskset -c 2.

The unfinished /workspace/PRIMARY-grouped-restart-recovered-mobile-prep-runtime-recovery-20261030 is PREPARATION_CANCELLED_AFTER_ACTUAL_DESKTOP_FAILURE, not a ready frozen capsule and never executed. Its draft requires desktopkernel0, so actualdesktop1 refuses before any mobile. No helper launches or mobile runtime should occur on that failed prerequisite.

Root owns diagnosis and any later source/profile action. Original logs, screenshots, stale reapers and /workspace/v3-grp remain untouched. This closed receipt is NOT a smoke qualification or merge permission.
