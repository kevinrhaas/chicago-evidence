"""Read-only closure of actual desktop failure after original controller restart; never a PASS."""
from pathlib import Path
import argparse,hashlib,json,re,sys,os
sha=lambda b:hashlib.sha256(b).hexdigest()
P=Path('/workspace/T3262-v3-237-controllers-secondfort-20261030');O=Path(__file__).resolve().parent
assert sha((P/'common.py').read_bytes())=='6532d4cf179979b97684938a0512b6bf1ce8b9115834212b09b7cced8532b9d7'
sys.dont_write_bytecode=True;sys.path.insert(0,str(P));import common as C
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');a=p.parse_args();assert a.execute
old=Path('/workspace/T3262-40453-grouped-published-BOTH-root-20261030');op=Path('/workspace/RESTART-native-orphan-observation-runtime-recovery-20261030/smoke-CLOSED-OBSERVATION.json');initialp=op.parent/'INITIAL-OBSERVATION.json'
original=json.loads((old/'BINDING.json').read_bytes());expect=argparse.Namespace(expect_head=original['head'],expect_tree=original['tree'],expect_merge_parent=original['merge_parent'],expect_branch=original['branch'],ticket=original['ticket'])
assert expect.expect_head=='40453bde8ba1812925d61fef118782a30323f98e'and expect.expect_tree=='2b609b8461f000730de75dd4672275ca5115fa8d'
guard,fresh=C.committed(expect);assert all(original[k]==v for k,v in fresh.items());guard()
obs=json.loads(op.read_bytes());body=obs['body'];actual=body['actual_root_exit'];initial=json.loads(initialp.read_bytes())
assert obs['status']=='ACTUAL_NATIVE_BODY_KERNEL_EXIT_AND_ZERO_LIVE_OWNED_PROCESSES_AFTER_CONTROLLER_RESTART'and obs['qualified_owner']=='smoke'
assert obs['initial_observation_sha256']==sha(initialp.read_bytes())and obs['monitor_helper_sha256']==sha((op.parent/'monitor.py').read_bytes())and obs['no_source_process_signal_ptrace_or_old_receipt_mutation']is True
assert body['root']['pid']==2613607 and body['root']['birth_ticks']=='45427107'and body['zero_live_owned_processes']is True and not body['live_owned_pids']and body['all_children_reaped']is False
assert actual['pid']==2613607 and actual['birth_ticks']=='45427107'and actual['state']=='Z'and actual['exit_wait_status']==256 and actual['exit_code']==1 and actual['actual_kernel_exit_status_not_inferred_from_footer']is True
rawstat=Path('/proc/2613607/stat').read_text();f=rawstat[rawstat.rfind(')')+2:].split();assert f[0]=='Z'and f[19]=='45427107'and int(f[49])==256
for row in obs['known_processes']:
 if 'smoke'not in row['owners']:continue
 assert row['live']is False and row['state']in ['Z','GONE_OR_PID_REUSED']
 proc=Path('/proc')/str(row['pid'])/'stat'
 if proc.exists():
  raw=proc.read_text();a=raw[raw.rfind(')')+2:].split();assert a[19]!=row['birth_ticks']or a[0]=='Z'
assert all(r['unchanged']is True and sha(Path(r['path']).read_bytes())==r['expected_sha256']for r in obs['original_reaper_receipts_unchanged'])
rp=old/'desktop-REAPER.json';reap=json.loads(rp.read_bytes());assert reap['command_pid']==2613607 and reap['command_exit']is None and reap['all_children_reaped']is False
assert reap['command']==['taskset','-c','0,1,3,4','node','tools/smoke_renderer.mjs','--published']
raw=(old/'desktop.log').read_text();clean=re.sub(r'\x1b\[[0-9;]*m','',raw);summary=re.findall(r'^(\d+) passed, (\d+) failed$',clean,re.M);assert summary[-1]==('503','3')and not re.search(r'^SMOKE PASS$',clean,re.M)
audit=re.findall(r'^(\d+) staged-section check\(s\) \(stage 1-3,7-12,14 of 15\), (\d+) always-on check\(s\)$',clean,re.M);assert len(audit)==1
failed=[line for line in clean.splitlines()if re.match(r'^\s*FAIL\s',line)];assert len(failed)==3,failed
assert any('the bench stands against the Green Tree' in line for line in failed)and any('nothing in the shed' in line for line in failed)and any('the distant walk draw is one exact derived top-face batch'in line for line in failed)
passes=[line for line in clean.splitlines()if re.match(r'^  pass  ',line)];zero_page=any('desktop 1280x800: zero page errors'in line for line in passes);suite=any('desktop 1280x800: the suite body ran to completion'in line for line in passes);assert zero_page and suite
guard();assert all(original[k]==v for k,v in fresh.items())
result=dict(status='ACTUAL_40453_NATIVE_GROUPED_DESKTOP_FAILED_RESTART_RECOVERED',at=C.now(),head=expect.expect_head,tree=expect.expect_tree,parents=fresh['parents'],branch=expect.expect_branch,ticket=expect.ticket,stage_selector='1-3,7-12,14',actual_real_native_calls=1,mobile_started=False,mobile_qualified=False,full_changed_source_map_BOTH_ACTUALLY_passed=False,native_body_exit=1,native_exit_source='Actual original Linuxstat zombie waitstatus256 decoded1; not inferred from footer',passed_checks=503,failed_checks=3,failed_lines=failed,native_audit_staged_checks=int(audit[0][0]),native_audit_always_on_checks=int(audit[0][1]),native_suite_completed=suite,native_zero_page_errors=zero_page,native_footer=clean.splitlines()[-24:],controller_restart_recovered=True,original_wrapper_exit_unknown=True,original_all_children_reaped=False,original_orphan_zombies_not_falsely_reaped=True,zero_live_owned_processes=True,restart_process_closure=body,observation=str(op),observation_sha256=sha(op.read_bytes()),original_log=str(old/'desktop.log'),original_log_sha256=sha((old/'desktop.log').read_bytes()),original_reaper=str(rp),original_reaper_sha256=sha(rp.read_bytes()),original_binding=str(old/'BINDING.json'),original_binding_sha256=sha((old/'BINDING.json').read_bytes()),source_binding=fresh,source_index_config_allrefs_publication_guards_exact_before_after=True,no_original_receipt_source_process_signal_ptrace_mobile_or_API_mutation=True,old_TMP_untouched=True)
assert not(O/'RESULT.json').exists();(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['status','native_body_exit','passed_checks','failed_checks','zero_live_owned_processes','source_index_config_allrefs_publication_guards_exact_before_after']},indent=2))
