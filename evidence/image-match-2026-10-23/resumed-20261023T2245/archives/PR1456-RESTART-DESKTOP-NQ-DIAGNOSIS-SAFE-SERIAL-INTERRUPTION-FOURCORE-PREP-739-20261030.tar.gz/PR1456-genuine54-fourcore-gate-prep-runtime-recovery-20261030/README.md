# Genuine54 four-core native gate restart — preparation only

Old serial native body is intentionally interruptedNQ at a completed-child boundary; /workspace/PR1456-serial-to-native-pool-root-20261030/SAFE-BOUNDARY-INTERRUPTION.json preserves actual sourceguards and root-onlyTERM+CONT proof. Kernel waitstatus15 means signal15/decoded-15; conventional shellstatus143 is stated separately. No PASS from partial execution. The previously interrupted controller is not repaired or forged.

This is a NEW frozen normal V2 gate/CP adapter. ONLY differences from frozen V2 gate.py: native subprocess CPU affinity0,1,3,4; CHECK_JOBS4; corresponding actual binding fields. checkpoint.py and exact fixture bin/node are byte-identical to V2. SOURCE-DELTA.patch is the complete code diff. No native test/assertion/command/timeouts/IDs/model/source/proof/foreign/ticket/config/index/ref/resource/gate-reader rule changed.

The normal gate will execute unchanged bash tools/check.sh from the beginning with native supported four-worker pool. Existing check_flush publication barriers and native isolated reruns remain. Only one DRIFT_ROOTS scratch copy1.557GB occurs, with separately funded96MiB log/pool/TMP and32MiB guard. Original reviewed3545 source manifest and all numeric funded resource prices remain unchanged; current observed entryresource/clonecap checks pass. Old serial TMP is left intact and still priced in actual free space. New own external output/TMP is required. No old successful steps/logs/exit statuses are reused.

Root review then explicitly detached topcontroller launch (separate ownsession/stdout receipt), substitute an unused external output path:

    source /workspace/shared/resume-chicago-env.sh
    nice -n 19 taskset -c 0,1,3,4 python -B /workspace/PR1456-genuine54-fourcore-gate-prep-runtime-recovery-20261030/gate.py --reviewed-manifest /workspace/PR1456-root-approved-54-integration-20261030.json --output NEW_EXTERNAL_NORMAL_FOURCORE_GATE_OUTPUT --execute

Normal result ACTUAL_PR1456_GENUINE54_FULL1105_SOURCE_PASS requires full actual1105footer, newwrapperexit0, newactualreaperallchildrenreaped/no cleanup and every originalsource/ticket/resource guard. It is not a restart-recovered source qualification: this is a wholly new native gate. Do not launch until root reviews this frozen capsule and confirms old serial processclosure.

After actual normal gatePASS, same unchanged ordinary native checkpoint/threequestions:

    nice -n 19 taskset -c 0,1,3,4 python -B /workspace/PR1456-genuine54-fourcore-gate-prep-runtime-recovery-20261030/checkpoint.py --gate-dir ACTUAL_NEW_NORMAL_GATE_OUTPUT --message-file /workspace/PR1456-current37-school-clone-integration-first-fort-20261030/PROPOSED-CHECKPOINT-MESSAGE.txt --execute

Actual future commit unknown; parents remain exactly[3746,54]. Phone/publishedruntime/PRCI/normalmerge remain separate prerequisites. No gate/checkpoint/browser/API/PR/ref/source mutation executed by this preparation. Only read-only load/check/resource validators and AST parsing ran. Frozen after handoff; adapt only in a new directory.
