"""Prepared only. Ordinary genuine two-parent checkpoint after unchanged full1105 source PASS."""
from gate import *
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--gate-dir',required=True,type=Path);ap.add_argument('--message-file',required=True,type=Path);ap.add_argument('--execute',action='store_true');a=ap.parse_args();assert a.execute
o=a.gate_dir.resolve();gate=json.loads((o/'GATE-RESULT.json').read_bytes());b=gate['binding'];assert gate['status']=='ACTUAL_PR1456_GENUINE54_FULL1105_SOURCE_PASS'and all(gate['guards'].values())and b['revision']==REV
checkpoint_helper_sha256=pf(Path(__file__));tickets_before=ticket_context(json.loads(Path(b['reviewed_manifest']).read_bytes()),gate['tickets_after']['head'])
m,msha=load(b['reviewed_manifest']);assert msha==b['reviewed_manifest_sha256']and m['tree']==b['tree']and b['parents']==[SOURCE,DEV]
assert pf(P/'gate.py')==b['helper_sha256'];before=check(m);assert before==b['before'];r=resource(m);assert r['workspace_pass']and r['shared_TMP_pass']and r['clone_cap_pass']
assert pf(a.message_file)==m['checkpoint_message_sha256'];assert not(o/'CHECKPOINT-RESULT.json').exists();env(o)
q=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','--file',str(a.message_file.resolve())],cwd=R,env=E,capture_output=True);(o/'NATIVE-COMMIT.log').write_bytes(q.stdout+q.stderr);assert q.returncode==0
head=g('rev-parse','HEAD').decode().strip();tree=g('rev-parse','HEAD^{tree}').decode().strip();parents=g('show','-s','--format=%P',head).decode().strip().split();assert parents==[SOURCE,DEV]and tree==m['tree']and not(R/'.git/MERGE_HEAD').exists()
expectedrefs={**before['refs'],'refs/heads/'+BRANCH:head};assert refs()==expectedrefs and not g('status','--porcelain=v1','--untracked-files=all');steps=[]
for name,cmd in [('changelog-entry',['node','tools/check-changelog-entry.mjs',DEV,'HEAD']),('ticket-ids',['node','tools/resolve_id_collisions.mjs','--base',DEV,'--check']),('fold-history',['node','tools/check-changelog.mjs'])]:
 row,reap=native(o,name,cmd);steps.append(row);save(o,'CHECKPOINT-STEPS.json',steps);assert row['exit']==0 and reap['command_exit']==0 and reap['all_children_reaped']and not reap['leftover_cleanup']
assert not g('status','--porcelain=v1','--untracked-files=all')and refs()==expectedrefs and index()==before['index']and pf(R/'.git/config')==before['config']
assert all(pathsha(p)==h for p,h in m['staged_paths'].items());r=resource(m);assert r['workspace_pass']and r['shared_TMP_pass']and r['clone_cap_pass']
assert pf(b['reviewed_manifest'])==msha and pf(Path(__file__))==checkpoint_helper_sha256 and pf(P/'gate.py')==b['helper_sha256']and pf(P/'bin/node')==b['fixture_shim_sha256']
tickets_after=ticket_context(m,tickets_before['head'])
save(o,'CHECKPOINT-RESULT.json',dict(status='ACTUAL_PR1456_GENUINE54_NATIVE_TWO_PARENT_CHECKPOINT_PASS',revision=REV,at=now(),head=head,tree=tree,parents=parents,branch=BRANCH,pr_base=DEV,reviewed_manifest_sha256=msha,source_gate=str(o/'GATE-RESULT.json'),source_gate_sha256=pf(o/'GATE-RESULT.json'),checkpoint_helper_sha256=checkpoint_helper_sha256,staged_paths=m['staged_paths'],required404_dependency_paths=m['required404_dependency_paths'],protected404_performance_paths=m['protected404_performance_paths'],clean=True,only_own_branch_ref_changed=True,tickets_before=tickets_before,tickets_after=tickets_after,steps=steps,resource_after=r,phone_published_probes_PR_CI_merge_pending=True));print((o/'CHECKPOINT-RESULT.json').read_text())
