"""Read-only Linux process observer after original controllers were lost; never reaps/signals."""
from pathlib import Path
import datetime,hashlib,json,os,time
P=Path(__file__).resolve().parent
I=json.loads((P/'INITIAL-OBSERVATION.json').read_bytes())
ROOTS={k:dict(v,birth_ticks=next(r['birth_ticks'] for r in I['processes'] if r['pid']==v['pid'])) for k,v in I['owners'].items()}
known={(r['pid'],r['birth_ticks']):dict(r,first_observed=I['at']) for r in I['processes']}
exit_seen={};started=datetime.datetime.now(datetime.timezone.utc).isoformat()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,d):
 f=P/n;t=P/(n+'.next');t.write_text(json.dumps(d,indent=2)+'\n');os.replace(t,f)
def scan():
 rows={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   raw=(p/'stat').read_text();a=raw[raw.rfind(')')+2:].split();rows[int(p.name)]=dict(pid=int(p.name),birth_ticks=a[19],state=a[0],ppid=int(a[1]),pgid=int(a[2]),sid=int(a[3]),exit_wait_status=int(a[49]),raw_stat=raw)
  except (OSError,ValueError,IndexError):pass
 return rows
while True:
 rows=scan();session_owners={}
 for (pid,birth),r in known.items():
  current=rows.get(pid)
  if current and current['birth_ticks']==birth:
   for owner in r['owners']:session_owners.setdefault(current['sid'],set()).add(owner)
 changed=True
 while changed:
  changed=False
  bypid={pid:r for (pid,birth),r in known.items() if rows.get(pid,{}).get('birth_ticks')==birth}
  for pid,r in rows.items():
   key=(pid,r['birth_ticks'])
   if key in known:continue
   owners=set(bypid.get(r['ppid'],{}).get('owners',[]))|session_owners.get(r['sid'],set())
   if owners:
    known[key]=dict(r,owners=sorted(owners),first_observed=now());changed=True
 for owner,root in ROOTS.items():
  r=rows.get(root['pid'])
  if r and r['birth_ticks']==root['birth_ticks'] and r['state']=='Z' and owner not in exit_seen:
   exit_seen[owner]=dict(observed_at=now(),pid=root['pid'],birth_ticks=root['birth_ticks'],raw_proc_stat=r['raw_stat'],state='Z',exit_wait_status=r['exit_wait_status'],exit_code=os.waitstatus_to_exitcode(r['exit_wait_status']),actual_kernel_exit_status_not_inferred_from_footer=True)
 current=[]
 for (pid,birth),r in sorted(known.items()):
  v=rows.get(pid);same=v is not None and v['birth_ticks']==birth
  current.append(dict(pid=pid,birth_ticks=birth,owners=r['owners'],first_observed=r['first_observed'],current=v if same else None,state=v['state']if same else'GONE_OR_PID_REUSED',live=same and v['state']!='Z'))
 bodies={}
 for owner,root in ROOTS.items():
  members=[r for r in current if owner in r['owners']];live=[r['pid']for r in members if r['live']];zombies=[r['pid']for r in members if r['state']=='Z']
  bodies[owner]=dict(root=root,actual_root_exit=exit_seen.get(owner),live_owned_pids=live,orphan_zombie_pids=zombies,zero_live_owned_processes=not live,all_children_reaped=False,original_reaper_completion_unknown=True,observer_does_not_reap_or_signal=True)
 receipt=dict(status='READONLY_RESTART_ORPHAN_MONITOR',started=started,observed=now(),monitor_pid=os.getpid(),monitor_helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),initial_observation_sha256=hashlib.sha256((P/'INITIAL-OBSERVATION.json').read_bytes()).hexdigest(),bodies=bodies,known_processes=current,exit_status_source='Linux /proc/<pid>/stat field52 observed only in zombie state with original birth_ticks; decoded with os.waitstatus_to_exitcode',original_reaper_receipts_unchanged=[dict(path=r['path'],expected_sha256=r['sha256'],unchanged=hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256'])for r in I['stale_original_reapers']],no_source_process_signal_ptrace_or_old_receipt_mutation=True)
 save('CURRENT-OBSERVATION.json',receipt)
 for owner,b in bodies.items():
  if b['actual_root_exit']is not None and b['zero_live_owned_processes']and not(P/(owner+'-CLOSED-OBSERVATION.json')).exists():
   save(owner+'-CLOSED-OBSERVATION.json',dict(receipt,qualified_owner=owner,body=b,status='ACTUAL_NATIVE_BODY_KERNEL_EXIT_AND_ZERO_LIVE_OWNED_PROCESSES_AFTER_CONTROLLER_RESTART'))
 if all(b['actual_root_exit']is not None and b['zero_live_owned_processes']for b in bodies.values()):break
 time.sleep(0.4)
