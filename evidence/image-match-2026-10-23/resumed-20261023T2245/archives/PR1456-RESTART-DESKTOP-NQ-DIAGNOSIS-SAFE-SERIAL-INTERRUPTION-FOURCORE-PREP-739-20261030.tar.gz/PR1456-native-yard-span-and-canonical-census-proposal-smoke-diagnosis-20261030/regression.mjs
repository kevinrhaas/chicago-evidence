import { readFileSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const folder=new URL('.',import.meta.url);const app='/workspace/chicago/chicago/4d';
const three=pathToFileURL(`${app}/renderers/web/vendor/three-0.185.1/three.module.js`).href;
const data=JSON.parse(readFileSync(`${app}/data/yard/town_trade_goods.json`));
const wagon=data.wagons.find(w=>w.under_shed),bench=data.benches[0],shed=data.sheds[0];
const sha=x=>createHash('sha256').update(x).digest('hex');
async function native(file){
 const source=readFileSync(file,'utf8');
 let text=source.replace("from 'three'",`from '${three}'`)
 .replace("import { resolveBases } from './scene-loader.js';","const resolveBases = () => ({assetBase:new URL('file:///unneeded-selected-primitive-assets/')});")
 .replace("import { loadTimberRelief } from './frontage.js';","const loadTimberRelief = () => null;")
 .replace("import { layerPick } from './gpu-pick.js';","const layerPick = () => null;")
 .replace("from './compact-streams.js'",`from '${pathToFileURL(`${app}/renderers/web/js/compact-streams.js`).href}'`);
 const a=source.indexOf('  const emit = (chunk, id, draw');const z=source.indexOf('\n\n  for (const [id, record, why] of loaded)',a);
 assert(a>0&&z>a);const emit=source.slice(a,z).trim().replace(/^const emit = /,'export const nativeEmit = ');
 text+='\nexport { buildItem, buildWagon, buildShed, readForm };\n'+emit;
 const m=await import(`data:text/javascript;base64,${Buffer.from(text).toString('base64')}`);
 const timber=[.3,.2,.1],canvas=[.7,.6,.5],iron=[.1,.1,.1];
 const buf={pos:[],nrm:[],conf:[],col:[],uv:[],uv1:[],timber,canvas,iron,tint:timber,blank:[0,0],bare:new Set([canvas,iron])};
 const chunk={buf,spans:[],objectSpans:[]},form=m.readForm(data),terrain={surfaceHeight:()=>0,isWater:()=>false},problems=[];
 m.nativeEmit(chunk,wagon.belongs_to,b=>m.buildWagon(b,wagon,form,terrain,1,problems),wagon);
 m.nativeEmit(chunk,bench.belongs_to,b=>m.buildItem(b,bench,form,terrain,1,problems,bench.belongs_to),bench);
 m.nativeEmit(chunk,shed.belongs_to,b=>m.buildShed(b,shed,form,terrain,1,problems),shed);
 assert.deepEqual(problems,[]);return{source,chunk};
}
const before=await native(`${app}/renderers/web/js/yard.js`);
const after=await native(new URL('postimages/renderers/web/js/yard.js',folder));
for(const stream of ['pos','nrm','conf','col','uv','uv1'])assert.deepEqual(after.chunk.buf[stream],before.chunk.buf[stream],stream);
const p=after.chunk.buf.pos;const spans=after.chunk.objectSpans;
assert.equal(spans.length,3);assert.deepEqual(spans.map(s=>s.id),[wagon.id,bench.id,shed.id]);
assert.equal(spans[0].from,0);assert.equal(spans[0].to,spans[1].from);assert.equal(spans[1].to,spans[2].from);assert.equal(spans[2].to,p.length/9);
let oldBench=0,oldShedMin=Infinity,oldShedMax=-Infinity,benchToShed=0,benchToWagon=0;
for(let i=0;i<p.length/3;i++){
 const e=p[i*3],n=-p[i*3+2],along=e-shed.at_local_enu_m[0],out=n-shed.at_local_enu_m[1];
 const ownedBench=i>=spans[1].from*3&&i<spans[1].to*3;
 if(Math.abs(along)<=shed.length_m/2+.4&&Math.abs(out)<=shed.depth_m/2+.5){oldShedMin=Math.min(oldShedMin,out);oldShedMax=Math.max(oldShedMax,out);if(ownedBench)benchToShed++;continue;}
 if(Math.hypot(e-wagon.at_local_enu_m[0],n-wagon.at_local_enu_m[1])<=4.6){if(ownedBench)benchToWagon++;continue;}
 if(Math.hypot(e-bench.at_local_enu_m[0],n-bench.at_local_enu_m[1])<=1.1)oldBench++;
}
assert.equal(oldBench,0);assert(benchToShed>0&&benchToWagon>0);assert(Math.abs(oldShedMin-(-2.095))<1e-10);
let benchCount=0,stray=0,inside=0,shedCount=0,minOut=Infinity,maxOut=-Infinity,minY=Infinity,maxY=-Infinity;
for(const span of spans)for(let i=span.from*3;i<span.to*3;i++){
 const e=p[i*3],n=-p[i*3+2],y=p[i*3+1];
 if(span.id===bench.id){benchCount++;stray=Math.max(stray,Math.hypot(e-bench.at_local_enu_m[0],n-bench.at_local_enu_m[1]));const b=bench.bearing_deg*Math.PI/180;inside=Math.min(inside,(e-bench.at_local_enu_m[0])*Math.sin(b)+(n-bench.at_local_enu_m[1])*Math.cos(b));continue;}
 const along=e-shed.at_local_enu_m[0],out=n-shed.at_local_enu_m[1];
 if(span.id===shed.id||(span.id===wagon.id&&Math.abs(along)<=shed.length_m/2+.4)){shedCount++;minOut=Math.min(minOut,out);maxOut=Math.max(maxOut,out);minY=Math.min(minY,y);maxY=Math.max(maxY,y);}
}
assert(benchCount>0&&stray>0&&stray<=1&&inside>=-.20);
assert(shedCount>0&&minOut>=-(shed.depth_m/2+.05)&&maxOut<=shed.depth_m/2+.35&&(maxY-minY)>2.8&&(maxY-minY)<=shed.head_m+.25);
const validOwnership=rows=>rows.length===3&&new Set(rows.map(s=>s.id)).size===3&&rows.every(s=>[wagon.id,bench.id,shed.id].includes(s.id)&&s.to>s.from);
assert(validOwnership(spans));assert(!validOwnership(spans.filter(s=>s.id!==bench.id)));assert(!validOwnership([spans[0],spans[0],spans[2]]));
const benchFirst=spans[1].from*9;
assert(Math.hypot(p[benchFirst]+2-bench.at_local_enu_m[0],-p[benchFirst+2]-bench.at_local_enu_m[1])>1);
assert(minOut-.2<-(shed.depth_m/2+.05));assert((maxY+.5-minY)>shed.head_m+.25);
const faultControls=['missing bench range refused','duplicate/wrong object ownership refused','displaced native bench vertex exceeds unchanged1m bound','native shed wall crossing exceeds unchanged depth+0.05m bound','native shed roof crossing exceeds unchanged head+0.25m bound'];
const result={fault_controls: faultControls,status:'ACTUAL_NATIVE_PRIMITIVES_COLLISION_REGRESSION_PASS',scope:'Original and proposed actual buildWagon/buildItem/buildShed and actual extracted emit closure; committed overlapping GreenTree objects; flat diagnostic terrain; no browser or published fullstage PASS.',unchanged_streams:['pos','nrm','conf','col','uv','uv1'],before_source_sha256:sha(before.source),after_source_sha256:sha(after.source),committed_record_sha256:sha(readFileSync(`${app}/data/yard/town_trade_goods.json`)),old_classification:{bench_vertices:oldBench,bench_vertices_swallowed_by_shed:benchToShed,bench_vertices_swallowed_by_wagon:benchToWagon,shed_min_out:oldShedMin,shed_max_out:oldShedMax},exact_owned_classification:{bench_vertices:benchCount,bench_stray:stray,bench_inside:inside,shed_vertices:shedCount,shed_min_out:minOut,shed_max_out:maxOut,shed_height:maxY-minY},spans};
writeFileSync(new URL('NATIVE-REGRESSION-RESULT.json',folder),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
