from pathlib import Path
import difflib,hashlib,json,math,subprocess,os
out=Path(__file__).resolve().parent;root=Path('/workspace/chicago');base='chicago/4d/'
yard=(root/(base+'renderers/web/js/yard.js')).read_text();smoke=(root/(base+'tools/smoke_renderer.mjs')).read_text()
y=yard.replace('        lotItemSpans: [],','        lotItemSpans: [],\n        objectSpans: [],')
assert y.count('        objectSpans: [],')==2
y=y.replace('  const emit = (chunk, id, draw) => {','  const emit = (chunk, id, draw, object = null) => {')
y=y.replace('    if (id) chunk.spans.push({ id, from, to: chunk.buf.pos.length / 9 });\n    return true;', '''    const to = chunk.buf.pos.length / 9;
    if (id) chunk.spans.push({ id, from, to });
    // Primitive ownership is separate from the building pick target. Nearby
    // furniture can overlap a diagnostic search radius without sharing vertices.
    if (object) chunk.objectSpans.push({ id: object.id, from, to });
    return true;''')
y=y.replace('          problems))) continue;\n      out.wagons.push(wagon);','          problems), wagon)) continue;\n      out.wagons.push(wagon);')
y=y.replace('          problems, bench.belongs_to ?? bench.id))) continue;','          problems, bench.belongs_to ?? bench.id), bench)) continue;')
y=y.replace('          problems))) continue;\n      out.sheds.push(shed);','          problems), shed)) continue;\n      out.sheds.push(shed);')
y=y.replace('    mesh.userData.lotItemSpans = chunk.lotItemSpans;','    mesh.userData.lotItemSpans = chunk.lotItemSpans;\n    mesh.userData.yardObjectSpans = chunk.objectSpans;')
assert y!=yard and y.count(', wagon)) continue;')==1 and y.count(', bench)) continue;')==1 and y.count(', shed)) continue;')==1
s=smoke
start=s.index('      // T-0064. Sixty-eight wagons against a hundred thousand vertices')
end=s.index('      // Measure the exact vertices emitted for each lot item.',start)
s=s[:start]+'''      // A bench beside the moved Green Tree shed is within the wagon's old
      // search radius, and one end enters the shed's diagnostic rectangle. Read
      // the ranges actually emitted for each object, never a proximity guess.
      const objects = new Map([
        ...wagons.map((object) => [object.id, { wagon: object }]),
        ...benches.map((object) => [object.id, { bench: object }]),
        ...sheds.map((object) => [object.id, { shed: object }]),
      ]);
      const objectOwners = new Map(meshes.map((m) => [m.geometry,
        (m.userData.yardObjectSpans ?? []).map((span) => ({
          ...span, object: objects.get(span.id),
        }))]));
      const objectSpans = [...objectOwners.values()].flat();
      const objectOwnershipExact = objectSpans.length === objects.size
        && new Set(objectSpans.map((span) => span.id)).size === objects.size
        && objectSpans.every((span) => span.object && span.to > span.from);
''' +s[end:]
s=s.replace('        let ownerIndex = 0;\n        for (let i = 0; i < pos.count; i++) {','        let ownerIndex = 0;\n        const objectRanges = objectOwners.get(geo) ?? [];\n        let objectIndex = 0;\n        for (let i = 0; i < pos.count; i++) {')
start=s.index("          // The shed's bay first: along the wall and out of it, in the shed's own")
end=s.index('          let best = null;',start)
s=s[:start]+'''          while (objectIndex < objectRanges.length && i >= objectRanges[objectIndex].to * 3) objectIndex++;
          const objectRange = objectRanges[objectIndex];
          const object = objectRange && i >= objectRange.from * 3
            && i < objectRange.to * 3 ? objectRange.object : null;
          if (object?.bench) {
            const bench = object.bench;
            benchVerts++;
            benchStray = Math.max(benchStray, Math.hypot(e - bench.at_local_enu_m[0],
              n - bench.at_local_enu_m[1]));
            const bearing = (bench.bearing_deg ?? 0) * Math.PI / 180;
            benchInside = Math.min(benchInside,
              (e - bench.at_local_enu_m[0]) * Math.sin(bearing)
              + (n - bench.at_local_enu_m[1]) * Math.cos(bearing));
            continue;
          }
          const ownShed = object?.shed;
          const wagonShed = object?.wagon?.under_shed
            ? sheds.find((shed) => shed.id === object.wagon.under_shed) : null;
          const shed = ownShed ?? wagonShed;
          if (shed) {
            const bearing = (shed.bearing_deg ?? 0) * Math.PI / 180;
            const de = e - shed.at_local_enu_m[0];
            const dn = n - shed.at_local_enu_m[1];
            const along = de * Math.cos(bearing) - dn * Math.sin(bearing);
            const out = de * Math.sin(bearing) + dn * Math.cos(bearing);
            // The wagon tongue deliberately projects beyond the bay's open end.
            // Every shed vertex is checked; only that wagon's beyond-end vertices
            // belong to its wagon bound. Never filter a wall/roof violation by out.
            if (ownShed || Math.abs(along) <= (shed.length_m ?? 0) / 2 + 0.4) {
              shedVerts++;
              shedOut = Math.max(shedOut, out);
              shedIn = Math.min(shedIn, out);
              shedHigh = Math.max(shedHigh, pos.getY(i));
              shedLow = Math.min(shedLow, pos.getY(i));
            } else wagonVerts++;
            continue;
          }
          if (object?.wagon) { wagonVerts++; continue; }
          const ob = obAt(e, n);
          if (ob) {
            obVerts++;
            const c = geo.getAttribute('color');
            if (c) obTones.add(`${c.getX(i).toFixed(4)},${c.getY(i).toFixed(4)},${c.getZ(i).toFixed(4)}`);
            ob.minY = Math.min(ob.minY ?? Infinity, pos.getY(i));
            ob.maxY = Math.max(ob.maxY ?? -Infinity, pos.getY(i));
            obHigh = Math.max(obHigh, ob.maxY - ob.minY);
            continue;
          }
''' +s[end:]
s=s.replace('        benchVerts,\n        benchStray,','        objectOwnershipExact,\n        objectSpans: objectSpans.length,\n        benchVerts,\n        benchStray,')
needle='    // T-0080. The Green Tree\'s two, from the Trowbridge view:'
s=s.replace(needle,'''    check(`${label}: every wagon, bench and shed owns its exact emitted triangle range`,
      goods.objectOwnershipExact,
      `${goods.objectSpans} primitive ownership range(s)`);
''' +needle)
old='''          // T-2385 — the native Dearborn street-edge closure lengthens
          // blk_south_water_clark_east_walk_1 from 30.97058 to 36.13067 m:
          // 97 to 113 board tops (+32 triangles), 15 to 17 stringer bays
          // (+8 triangles). check_far_plank_tops independently reads 111510.
          && m.candidates === 111510'''
new='''          // T-2385 retains the pictured 15.24 x 9.14 m canonical Tremont.
          // Its committed Dearborn walk remains 30.97058 m. The 36.13067 m
          // walk / 111510 census belonged to the superseded smaller Gale default;
          // Gale is now optional. Native check_far_plank_tops derives 111470.
          && m.candidates === 111470'''
assert old in s;s=s.replace(old,new)
assert s!=smoke and 'wagonNear'not in s
for rel,b,a in [('renderers/web/js/yard.js',yard,y),('tools/smoke_renderer.mjs',smoke,s)]:
 p=out/'postimages'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(a)
 (out/(Path(rel).name+'.patch')).write_text(''.join(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel)))
print('proposal written')
