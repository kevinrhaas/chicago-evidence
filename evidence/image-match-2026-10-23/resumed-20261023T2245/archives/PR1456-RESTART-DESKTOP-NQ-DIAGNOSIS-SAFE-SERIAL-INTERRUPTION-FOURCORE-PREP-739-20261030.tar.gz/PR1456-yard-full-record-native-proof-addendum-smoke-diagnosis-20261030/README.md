# Full-record native ownership addendum

New proof only; original14-member capsule SHA8654d434 unchanged. Actual unchanged/proposed createYardGoods runs load committedindex plusall8records and actuale1834heightfield. Native Three,compactStreams andgpuPick are real; texture-only atlascontext is null and timberrelief is explicitly notuploaded. No browser/visual/sourcegate/phone/PRmerge claim.

Both ordinary-chunk and actual5parkedGLBreplacement-ID paths produce89primitiveobjects/89exactunique spans on83direct meshes. Allranges are sorted, nonoverlapping and inside their actual attribute vertexcounts. Nestedwoodgroup hasone mesh withzero wagon/bench/shedranges; allthree objecttypes alwaysuse direct chunks. Everyrecord in out.wagons/out.benches/out.sheds appears exactlyonce. The5replacementfallbackmeshes canbehidden by the production setReplacementVisible path withoutlosing their ownedranges from the smoke’s direct-childmeshcollection (smoke doesnotfiltervisible). Farmergedartifactsareexplicitly excluded by smoke’s existingfarMergedfilter; no duplicate objectmetadata is asserted for those clones.

Original/proposed fullgeometry attributes, indices, quantization metadata, mesh transforms, unchanged buildingpickspans/lotitemspans andallcensus values match exactly. No added triangle, movedfurniture or alteredmaterial is needed. Texture absence is a named CPUfixture limitation and no marks/pixels are qualified here. Fresh normalreaper confirms exit0/allchildrenreaped/no cleanup.

Source remains untouched. Publishedstage2–3BOTH on the appliedintegration remains the finalnativebrowsercheck.
