import {readFileSync,writeFileSync} from 'node:fs';
import {readFile} from 'node:fs/promises';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const app='/workspace/chicago/chicago/4d';
const candidate='/workspace/PR1456-native-yard-span-and-canonical-census-proposal-smoke-diagnosis-20261030/postimages/renderers/web/js/yard.js';
const out=new URL('.',import.meta.url),threeURL=pathToFileURL(`${app}/renderers/web/vendor/three-0.185.1/three.module.js`).href;
const THREE=await import(threeURL),compactURL=pathToFileURL(`${app}/renderers/web/js/compact-streams.js`).href;
const uri=text=>`data:text/javascript;base64,${Buffer.from(text).toString('base64')}`;
const gpu=readFileSync(`${app}/renderers/web/js/gpu-pick.js`,'utf8').replace("from 'three'",`from '${threeURL}'`).replace("from './compact-streams.js'",`from '${compactURL}'`);
const sha=b=>createHash('sha256').update(b).digest('hex');
const inputs=new Map();
globalThis.fetch=async url=>{const file=fileURLToPath(url);assert(file.startsWith(`${app}/data/`));const b=await readFile(file);inputs.set(file,sha(b));return{ok:true,json:async()=>JSON.parse(b)}};
globalThis.document={createElement:()=>({getContext:()=>null})};
const terrainSource=readFileSync(`${app}/renderers/web/js/terrain.js`,'utf8');const start=terrainSource.indexOf('export class Heightfield'),end=terrainSource.indexOf('\n/**\n * Load the terrain',start);
const Heightfield=new Function('THREE',terrainSource.slice(start,end).replace('export class','class')+'\nreturn Heightfield;')(THREE);
const td=`${app}/data/terrain/epochs/e1834_harbor_cut`,metaBytes=readFileSync(`${td}/heightfield.json`),meta=JSON.parse(metaBytes),bin=readFileSync(`${td}/${meta.bin}`);
const hf=new Heightfield().adopt(meta,bin.buffer.slice(bin.byteOffset,bin.byteOffset+bin.byteLength));
const terrain={surfaceHeight:(e,n)=>hf.sample(e,n),isWater:(e,n)=>hf.sample(e,n)<.015};
const placementBytes=readFileSync(`${app}/data/transport/parked/placements.json`),placements=JSON.parse(placementBytes);
const actualReplacements=placements.scenes['1835'].filter(x=>x.replaces).map(x=>x.replaces);
async function mod(file){let s=readFileSync(file,'utf8');return import(uri(s.replace("from 'three'",`from '${threeURL}'`)
.replace("import { resolveBases } from './scene-loader.js';","const resolveBases=()=>({assetBase:new URL('file:///unused-CPU-texture-assets/')});")
.replace("import { loadTimberRelief } from './frontage.js';","const loadTimberRelief=async()=>({problem:'CPU fixture: no texture upload'});")
.replace("from './gpu-pick.js'",`from '${uri(gpu)}'`).replace("from './compact-streams.js'",`from '${compactURL}'`)))}
const before=await mod(`${app}/renderers/web/js/yard.js`),after=await mod(candidate);
function meshes(layer){const all=[];layer.group.traverse(x=>{if(x.isMesh)all.push(x)});return all}
function attributeSnapshot(attr){return{type:attr.array.constructor.name,size:attr.itemSize,normalized:attr.normalized,count:attr.count,sha256:sha(Buffer.from(attr.array.buffer,attr.array.byteOffset,attr.array.byteLength))}}
function geometrySnapshot(layer){return meshes(layer).map(m=>({name:m.name,matrix:m.matrix.elements,geometry_index:m.geometry.index?attributeSnapshot(m.geometry.index):null,attributes:Object.fromEntries(Object.entries(m.geometry.attributes).map(([k,a])=>[k,attributeSnapshot(a)])),pickSpans:m.userData.spans,lotItemSpans:m.userData.lotItemSpans,positionQuantized:m.geometry.userData.positionQuantized,positionBoxes:m.geometry.userData.positionBoxes}))}
function checkOwners(layer){
 const objects=new Map([...layer.wagons,...layer.benches,...layer.sheds].map(o=>[o.id,o]));
 const direct=layer.group.children.filter(m=>m.isMesh),all=meshes(layer),seen=new Map();let spans=0;
 for(const m of direct){let end=0;const rows=m.userData.yardObjectSpans??[];
  for(const s of rows){assert(objects.has(s.id),`unrecognized owner ${s.id}`);assert(Number.isInteger(s.from)&&Number.isInteger(s.to)&&s.to>s.from);assert(s.from>=end,`out-of-order/overlap${s.id}`);assert(s.to*3<=m.geometry.attributes.position.count,`outofbounds${s.id}`);end=s.to;assert(!seen.has(s.id),`duplicate${s.id}`);seen.set(s.id,{mesh:m.name,from:s.from,to:s.to});spans++}
 }
 assert.equal(spans,objects.size);assert.deepEqual([...seen.keys()].sort(),[...objects.keys()].sort());
 const nested=all.filter(m=>!direct.includes(m));assert(nested.every(m=>(m.userData.yardObjectSpans??[]).length===0),'object hidden in nested wood mesh');
 const primitiveRows=[...objects.values()].map(o=>({id:o.id,kind:o.kind??'farm_box',...seen.get(o.id)}));
 return{expected_objects:objects.size,spans,direct_meshes:direct.length,nested_wood_meshes:nested.length,all_owners_unique:true,all_spans_sorted_nonoverlapping_inbounds:true,nested_wood_meshes_have_no_owned_wagons_benches_sheds:true,primitiveRows};
}
const scenarios=[];
for(const replacementIds of [new Set(),new Set(actualReplacements)]){
 const opts={dataBase:pathToFileURL(`${app}/data/`),terrain,replacementIds};let problems=[];let a=await before.createYardGoods({...opts,problems});const original=geometrySnapshot(a),census=a.census,originalProblems=problems;a.dispose();a=null;globalThis.gc?.();
 problems=[];let b=await after.createYardGoods({...opts,problems});assert.deepEqual(geometrySnapshot(b),original,'all complete geometry/pickspan/lotspan streams unchanged');assert.deepEqual(b.census,census);assert.deepEqual(problems,originalProblems);
 const owners=checkOwners(b),visibleBefore=meshes(b).filter(m=>m.visible).length;
 for(const id of replacementIds)b.setReplacementVisible(id,false);
 const hiddenAfter=meshes(b).filter(m=>!m.visible).length;assert.deepEqual(checkOwners(b),owners,'replacement visibility leaves every owned object exactly once in smoke direct-child census');
 scenarios.push({replacement_ids:[...replacementIds],census,owners,visible_before:visibleBefore,hidden_after_replacements:hiddenAfter,geometry_attributes_indices_quantization_pickspans_and_lotspans_exact_before_after:true,problems});
 b.dispose();b=null;globalThis.gc?.();
}
const result={status:'ACTUAL_FULL_RECORD_CREATE_YARD_GOODS_OWNERSHIP_AND_GEOMETRY_PASS',scope:'Actual original/proposed createYardGoods with all8 committed yard records and actual e1834 heightfield, native Three/compactStreams/gpuPick. CPU-only texture atlas context null and timber relief explicitly unuploaded; no browser or visual PASS.',source_sha256:sha(readFileSync(`${app}/renderers/web/js/yard.js`)),proposal_sha256:sha(readFileSync(candidate)),terrain_metadata_sha256:sha(metaBytes),terrain_bin_sha256:sha(bin),parked_placements_sha256:sha(placementBytes),actual_replacement_ids:actualReplacements,input_json_sha256:Object.fromEntries(inputs),scenarios};
writeFileSync(new URL('FULL-RECORD-RESULT.json',out),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,scenarios:scenarios.map(s=>({objects:s.owners.expected_objects,spans:s.owners.spans,direct_meshes:s.owners.direct_meshes,nested:s.owners.nested_wood_meshes,replacements:s.replacement_ids.length,hidden:s.hidden_after_replacements})),input_count:inputs.size},null,2));
