# Restart recovery preparation — original native bodies keep running

Prepared, unexecuted. The tool/environment reconnect killed Python controllers/reapers while two already-started native command groups continued. This capsule never pretends those wrappers completed or reaped their children. It accepts only actual Linux `/proc/PID/stat` field52 status observed in zombie state at the original PID birth, plus zero live owned roots/descendants/session processes. PID1 is plain tail and currently leaves orphan zombies visible; zombies are explicitly NOT reaped.

Detached read-only observer: /workspace/RESTART-native-orphan-observation-runtime-recovery-20261030/monitor.py PID2661232, own session/devnull stdin/own monitor.log stdout+stderr. Initial ownership and stale original reaper hashes are immutable INITIAL-OBSERVATION.json. It captures descendant/session ownership across Chromium's sanitized environment and records real native root exit only after stateZ. CURRENT-OBSERVATION is live; gate-CLOSED-OBSERVATION is created once real root exit and zero live owned processes hold. The monitor never signals, ptraces, adopts, reaps or writes source/original receipts.

After root reviews the frozen helper and the actual closed observation, use a NEW external result directory:

    source /workspace/shared/resume-chicago-env.sh
    nice -n19 taskset -c2 python -B /workspace/PR1456-and-primary-restart-recovery-prep-runtime-recovery-20261030/finalize_gate_recovered.py --gate-dir /workspace/PR1456-genuine54-root-actual-gate-20261030 --observation /workspace/RESTART-native-orphan-observation-runtime-recovery-20261030/gate-CLOSED-OBSERVATION.json --output NEW_RECOVERED_GATE_DIRECTORY --execute

This rechecks unchanged original V2 helper/fixture, reviewed3545 manifest, exact genuine3746/54 merge/tree444505, all own/foreign source/index/ref/config/proof/resource invariants, canonical clean FF public tickets/four exact review files, native1105 footer and native publish execution. The original native log/binding/timings/reaper SHA and separately observed actual kernel exit/no-live-process closure are retained. Result status is ACTUAL_PR1456_GENUINE54_FULL1105_SOURCE_PASS_RESTART_RECOVERED, never the old controller PASS. original_all_children_reaped=false and original_wrapper_exit_unknown=true remain explicit, outside the qualifying guard set; nativebodyexit0 and no live sourcewriters are the actual qualifying recovery observations.

Then root may run ordinary native checkpoint, same genuine parents[3746,54], unchanged message SHA, exact refs/index/config and actual three PR questions with fresh original run-with-reaping wrappers:

    nice -n19 taskset -c2 python -B /workspace/PR1456-and-primary-restart-recovery-prep-runtime-recovery-20261030/checkpoint_recovered.py --gate-dir ACTUAL_RECOVERED_GATE_DIRECTORY --message-file /workspace/PR1456-current37-school-clone-integration-first-fort-20261030/PROPOSED-CHECKPOINT-MESSAGE.txt --execute

Future checkpoint SHA is unknown. Only an actual normal commit and all three successful fresh reaped questions produce native checkpoint PASS. Phone/published runtime/PR CI/merge remain separately pending.

Primary grouped plan: let original desktop native Node2613607 finish; capture its true kernel exit0 and zero live-owned-process closure. Preserve original desktop log/reaper unchanged and qualify it only as RESTART_RECOVERED_NATIVE_DESKTOP if native stage audit1-3,7-12,14/zero-failed/SMOKEPASS/suitecompleted/pageerrors0/vendor predicates pass with original40453 source/publication/allrefs context. Then launch ONE genuine freshmobile grouped native command with unchanged selector/assertions/viewports and a fresh real reaper, own external output/TMP. That yields two actual native grouped calls total,20logical coverage cells, not20individual runs or full15. Combined result must remain explicitly restart-recovered; old grouped controller PASS cannot be fabricated. Separate mobile continuation helper is not included here.

The helpers were AST-parsed only. No finalizer, source commit, nativecheck restart, phone, browser/mobile continuation, GitHub operation, source/profile cleanup, signal or ptrace was executed by this preparation. Frozen after handoff; adapt in a new directory.
