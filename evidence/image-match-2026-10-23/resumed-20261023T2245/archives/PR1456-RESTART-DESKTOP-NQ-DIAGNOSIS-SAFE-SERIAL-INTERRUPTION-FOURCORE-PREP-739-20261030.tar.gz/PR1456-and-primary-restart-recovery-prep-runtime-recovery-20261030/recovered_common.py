"""Frozen recovery import of the unchanged reviewed source gate helpers."""
from pathlib import Path
import importlib.util,hashlib
V2=Path('/workspace/PR1456-genuine54-lean-gate-v2-secondfort-20261030')
assert hashlib.sha256((V2/'gate.py').read_bytes()).hexdigest()=='b8e0b81586455a1c3b69a917e8c454e0fab8fc3fe548e5029c940043e06b8ade'
spec=importlib.util.spec_from_file_location('unchanged_reviewed_v2',V2/'gate.py');v2=importlib.util.module_from_spec(spec);spec.loader.exec_module(v2)
for name in dir(v2):
 if not name.startswith('_'):globals()[name]=getattr(v2,name)
RECOVERY_PREP=Path(__file__).resolve().parent
