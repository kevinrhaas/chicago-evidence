Read-only evidence index and CURRENT ACTIVE-GATE preflight, not final current-head browser qualification. RESULT.json compares actual305 selected published consumers to the accepted3746 audit:304exact, sole changed railway.js exact40453. Full native publication is still being checked, so root must rehash these same305 rows after actual gate/process closure and actual checkpoint before reuse.

The index names exact actual old BOTH evidence and limits, including updatedMiller and fresh9dPeople, so no all15wholematrix claim is manufactured. Current400MiB phone, requiredCI and ordinary merge stay separate.

The native publication intentionally removes household notes from Hogan/Mary boot sidecars and ships full residents separately; blanket native=published assertions are false. All four native/published bytes remain exactaccepted3746.
