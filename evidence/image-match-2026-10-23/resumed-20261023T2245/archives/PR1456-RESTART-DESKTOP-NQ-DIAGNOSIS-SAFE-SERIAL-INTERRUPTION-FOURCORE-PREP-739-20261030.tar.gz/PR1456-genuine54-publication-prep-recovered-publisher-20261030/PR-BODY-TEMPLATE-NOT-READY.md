Give the Miller House its pictured low log wing, add Hogan’s gable courses and chimney cap, raise St Mary’s front sash, and show the credited Castelnau harbour view on the lighthouse’s Images card. Records retain disputed dates and uncertain reconstruction details.

The source integration preserves canonical foreign data and the four original picture decisions. Rendering changes retain compact railway normals, exact uniform confidence storage and removal of unused initial upload-range metadata, and adopt the exact approved railway/lifecycle revision from performance PR #1486. Mixed confidence values keep their existing representation.

Current source checkpoint: [`{{ACTUAL_NATIVE_HEAD_SHORT}}`](https://github.com/kevinrhaas/chicago/commit/{{ACTUAL_NATIVE_HEAD}}), genuine parents `3746b23b` and named dev `54e4004a`, tree `444505c7`.

- {{ACTUAL_1105_SOURCE_GATE_RESULT_AND_SECONDS}}
- {{ACTUAL_NATIVE_CHECKPOINT_AND_THREE_PR_QUESTIONS_RESULT}}
- {{ACTUAL_NORMAL_FF_PUBLICATION_AND_IMMUTABLE_READBACK_RESULT}}

Runtime evidence remains dated. Earlier head `3746b23b` passed the unchanged official 1904 mobile memory gate at398.984MiB/400MiB with no page errors. Its earlier geometry, Images and eight desktop/mobile People captures carry eight documented consumer qualifications. Mobile Hogan/Mary captures are scrolled, with complete names/order/links established by DOM assertions. Earlier AIR/SOUTH confidence comparisons had zero pixel differences in nine modes; NORTH was not run. This does not claim a fresh current-head full desktop/mobile matrix or1904 staff-directory review. Inherited visual-budget failures and the incoming Census citation-sanitizer discrepancy remain documented.

**Merge pending:** actual current-head phone/runtime qualification, PR #1486 landing, the latest concurrent-dev generated metadata settlement and GitHub’s required check remain pending. Named dev `8b4e9820` adds three generated-file conflicts beyond this54checkpoint: liberties, source index and source-use report. The checked54source and earlier3746 runtime facts are not presented as checks of a later base. The four original picture tickets remain in review until this qualified PR merges normally to `dev` and settles. No app-main or production promotion is included.

[Verified recovery checkpoint738](https://github.com/kevinrhaas/chicago-evidence/blob/11317d6513f0410e20d392a863a1a7eb3165421a/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md) preserves exact staged source, WIP restoration and qualified evidence.
