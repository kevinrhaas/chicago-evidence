# Named8b missing-native-object import — prepared, no source mutation

Actual read-only preparation downloaded only76 missing canonical public objects into this external payload capsule. Native object SHA/signature/parent/tree reconstruction and before/after source/primary guards passed. Eventual own-clone object upper price13,164,544B<32MiB; frozen external payload allocation14,884,864B<32MiB. Source `.git/objects` has NOT received any of them. No fetch/ref/index/config/working/source/site/API write occurred.

Frozen payload manifest payload/CLOSED-MANIFEST.json SHA62e234d59c76e88d556996cd24b7d75d160595fc35d6e522d47d8d5cacbe966e. `apply_import8b.py` is Python-AST checked only, never executed. Root commands, after actual54 nativeCP is saved through normalFFpublication:

    source /workspace/shared/resume-chicago-env.sh
    nice -n 19 taskset -c 2 python -B CAPSULE/apply_import8b.py --expect-head ACTUAL54CP --checkpoint ACTUAL54CP_RESULT --publication ACTUAL54_FF_PUBLICATION_RESULT --payload-manifest CAPSULE/payload/CLOSED-MANIFEST.json --payload-manifest-sha256 62e234d59c76e88d556996cd24b7d75d160595fc35d6e522d47d8d5cacbe966e --output NEW_READONLY_OUTPUT

Review PLAN, then same command with NEW output and --execute. It requires real nativeparents[3746,54]/tree4445 and the actual normalFFpublication receipt and fresh PRhead equality. It verifies every encoded payload/member SHA, object header/type/rawSHA/nativeGitSHA, writes missing objects only in the ordinary own clone objects directory (atomic readonly loose objects), verifies all18K native8b leaf modes/types/blobs, and keeps source HEAD/branch/index/flags/config/status/allrefs and primary context exact. No local origin/dev tracking ref change is included. Missing8bobjects are read from frozen external verified bytes; no second API blob download is needed. Currentdev is reported, never chased; only named8b is imported.

After actual importPASS root may prove ancestry54→8b and CAS local origin/dev from exact54 to named8b, then make a genuine native merge into the actual54CP branch. `git merge --no-commit --no-ff 8b4e98207c1afcff4878239cd700379447218cfb` is expected to stop on the three known generated conflicts. That source mutation is root-owned and not executed here. Do not install old whole-file generated postimages. Use the separate native-owner settlement helper on the actual merge, then review actual foreign/own entrywise composition, stage, sourcegate and nativeCP.

Public incoming payload is replaceable from immutable GitHub8b; preserve manifest/helper/proofs in recovery. Do not confuse this external payload allocation with an import already applied.
