"""PREPARATION ONLY: bounded missing-only named8b payload outside clone, no source or API write."""
from pathlib import Path
from urllib.request import Request,urlopen
import os,json,hashlib,subprocess,datetime,zlib,base64,concurrent.futures,stat,argparse,time
F=Path('/workspace/t2372-parallel-native-20261030');R=Path('/workspace/chicago');O=Path(__file__).parent/'payload';assert not O.exists();O.mkdir();TIP='8b4e98207c1afcff4878239cd700379447218cfb';HEAD='3746b23bf1298c34a29946b4cdb6ee2d98abff8f';BRANCH='steward/t2381-t2373-t2384-t2377-early-pictures-20261029';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');sha=lambda b:hashlib.sha256(b).hexdigest();oid=lambda k,b:hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();g=lambda r,*a:subprocess.check_output(['git','-C',str(r),*a],env=E);save=lambda n,d:(O/n).write_text(json.dumps(d,indent=2)+'\n');a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');args=a.parse_args();os.sched_setaffinity(0,{2});os.nice(19)
def api(path):
 with urlopen(Request('https://api.github.com/repos/kevinrhaas/chicago/'+path,headers={'User-Agent':'Chicago-isolated-canonical-missing8b-preparation','Accept':'application/vnd.github+json'}),timeout=60)as r:return json.load(r)
def snapshot(repo):return{'head':g(repo,'rev-parse','HEAD').decode().strip(),'branch':g(repo,'branch','--show-current').decode().strip(),'index':sha(g(repo,'ls-files','--stage','-z')),'flags':sha(g(repo,'ls-files','-v','-z')),'config':sha((repo/'.git/config').read_bytes()),'refs':sha(g(repo,'for-each-ref','--format=%(refname) %(objectname)')),'status':g(repo,'status','--porcelain=v1').decode()}
def have(ids):
 ids=sorted(set(ids))
 if not ids:return set()
 raw=subprocess.check_output(['git','-C',str(F),'cat-file','--batch-check=%(objectname) %(objecttype)'],input=('\n'.join(ids)+'\n').encode(),env=E);return{p[0]for line in raw.decode().splitlines()if len(p:=line.split())==2 and p[1]!='missing'}
def canonical(c):
 v=c.get('verification',{});payload=v.get('payload');sig=v.get('signature')
 if payload and sig:
  h,msg=payload.encode().split(b'\n\n',1)
  for s in [sig.encode(),sig.encode().rstrip(b'\n')]:
   raw=h+b'\ngpgsig '+b'\n '.join(s.split(b'\n'))+b'\n\n'+msg
   if oid('commit',raw)==c['sha']:return raw
 if not sig:
  def actor(k):
   x=c[k];dt=datetime.datetime.fromisoformat(x['date'].replace('Z','+00:00'));return k+' '+x['name']+' <'+x['email']+'> '+str(int(dt.timestamp()))+' +0000'
  h=['tree '+c['tree']['sha'],*['parent '+p['sha']for p in c['parents']],actor('author'),actor('committer')]
  for ending in ['', '\n']:
   raw=('\n'.join(h)+'\n\n'+c['message']+ending).encode()
   if oid('commit',raw)==c['sha']:return raw
 raise AssertionError('Canonical commit byte reconstruction refused: '+c['sha'])
def tree_bytes(j):
 rows=sorted(j,key=lambda r:r['path'].encode()+(b'/'if r['type']=='tree'else b''));return b''.join(('40000'if r['type']=='tree'else r['mode']).encode()+b' '+r['path'].encode()+b'\0'+bytes.fromhex(r['sha'])for r in rows)
before=snapshot(F);primary=snapshot(R);assert not args.execute,'Preparation never writes source objects';assert before['head']==HEAD and before['branch']==BRANCH;assert primary['head']=='40453bde8ba1812925d61fef118782a30323f98e'and not primary['status'];assert (F/'.git/MERGE_HEAD').read_text().strip()=='54e4004add7ab5208d71a51282c008cda6e7edad';assert g(F,'write-tree').decode().strip()=='444505c7ca5a22c7e90c653a10f579630be6978c';assert(F/'.git/objects').is_dir()and not(F/'.git/objects').is_symlink();assert api('pulls/1456')['head']['sha']==HEAD
commits={};meta={};pending=[TIP]
while pending:
 cid=pending.pop()
 if cid in commits or have([cid]):continue
 assert len(commits)<32,'No broadhistory allowed';c=api('git/commits/'+cid);raw=canonical(c);assert oid('commit',raw)==cid;commits[cid]=c;meta[cid]=('commit',raw);pending.extend(p['sha']for p in c['parents'])
tip=commits.get(TIP)or api('git/commits/'+TIP);flat=api('git/trees/'+tip['tree']['sha']+'?recursive=1');assert not flat['truncated']and flat['sha']==tip['tree']['sha'];groups={};roots={'':flat['sha']}
for r in flat['tree']:
 parent,_,name=r['path'].rpartition('/');groups.setdefault(parent,[]).append({**r,'path':name})
 if r['type']=='tree':roots[r['path']]=r['sha']
for path,tid in roots.items():
 raw=tree_bytes(groups.get(path,[]));assert oid('tree',raw)==tid;meta[tid]=('tree',raw)
# Preserve all pending native commit/tree metadata, without fetching historical blobs.
queue=[c['tree']['sha']for c in commits.values()];seen=set()
while queue:
 tid=queue.pop()
 if tid in seen or have([tid]):continue
 seen.add(tid)
 if tid in meta:
  kind,raw=meta[tid];assert kind=='tree'
  # Its tip subtree graph is already entirely reconstructed from the flat tree.
  continue
 j=api('git/trees/'+tid);assert not j.get('truncated',False);raw=tree_bytes(j['tree']);assert oid('tree',raw)==tid;meta[tid]=('tree',raw);queue.extend(r['sha']for r in j['tree']if r['type']=='tree')
all_ids=set(meta)|{r['sha']for r in flat['tree']if r['type']!='tree'};existing=have(all_ids);payloads={};rows=[]
for sid,(kind,raw)in meta.items():
 if sid in existing:continue
 enc=zlib.compress(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw);payloads[sid]=enc;rows.append({'sha':sid,'kind':kind,'raw_bytes':len(raw),'sha256':sha(raw),'encoded_bytes':len(enc)})
missing_blobs={r['sha']:r for r in flat['tree']if r['type']=='blob'and r['sha']not in existing}
def download(item):
 sid,row=item;j=api('git/blobs/'+sid);assert j['encoding']=='base64';raw=base64.b64decode(j['content']);assert len(raw)==row['size']==j['size']and oid('blob',raw)==sid;enc=zlib.compress(b'blob '+str(len(raw)).encode()+b'\0'+raw);return sid,enc,{'sha':sid,'kind':'blob','path':row['path'],'raw_bytes':len(raw),'sha256':sha(raw),'encoded_bytes':len(enc)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for sid,enc,row in pool.map(download,missing_blobs.items()):payloads[sid]=enc;rows.append(row)
newdirs={sid[:2]for sid in payloads if not(F/'.git/objects'/sid[:2]).exists()};price=sum((len(x)+4095)//4096*4096 for x in payloads.values())+4096*len(newdirs)+1024*1024;assert price<=32*1048576,'32MiB object-allocation cap';assert snapshot(F)==before and snapshot(R)==primary
plan={'status':'MISSING_ONLY_NAMED8B_PUBLIC_NATIVE_OBJECTS_EXTERNAL_PREPARATION_NO_SOURCE_WRITE','tip':TIP,'tree':flat['sha'],'new_commit_metadata':len(commits),'new_objects':len(payloads),'tip_missing_blobs':len(missing_blobs),'raw_bytes':sum(r['raw_bytes']for r in rows),'encoded_bytes':sum(len(v)for v in payloads.values()),'allocation_upper_plus_receipt_reserve':price,'cap_bytes':32*1048576,'global_free':__import__('shutil').disk_usage('/workspace').free,'rows':rows,'all_native_SHA_signatures_parents_verified':True,'no_primary_write_fetch_lazyfetch_or_ref_change':True};save('PRICE.json',plan);save('NEW-COMMIT-GITDATA.json',commits)
assert __import__('shutil').disk_usage('/workspace').free>=1073741824+price
payload_dir=O/'encoded';payload_dir.mkdir();payload_rows=[]
for sid,encoded in sorted(payloads.items()):
 dest=payload_dir/sid;dest.write_bytes(encoded)
 payload_rows.append({'oid':sid,'relative':'encoded/'+sid,'bytes':len(encoded),'sha256':sha(encoded)})
wanted={r['path']:[r['mode'],r['type'],r['sha']]for r in flat['tree']if r['type']!='tree'}
save('TIP-LEAVES.json',wanted);save('SOURCE-BEFORE.json',before);save('PRIMARY-BEFORE.json',primary)
assert snapshot(F)==before and snapshot(R)==primary and g(F,'write-tree').decode().strip()=='444505c7ca5a22c7e90c653a10f579630be6978c'
plan.update(payloads=payload_rows,tip_leaves_path='TIP-LEAVES.json',tip_leaves_sha256=sha((O/'TIP-LEAVES.json').read_bytes()),metadata_commit_path='NEW-COMMIT-GITDATA.json',metadata_commit_sha256=sha((O/'NEW-COMMIT-GITDATA.json').read_bytes()),prepared_source=before,prepared_primary=primary,source_writes=False)
save('PLAN.json',plan)
files=[{'path':str(p),'relative':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(O.rglob('*'))if p.is_file()]
allocation=int(subprocess.check_output(['du','-s','-B1',str(O)]).split()[0]);assert allocation<=32*1048576
save('CLOSED-MANIFEST.json',{'status':'CLOSED_NAMED8B_PUBLIC_MISSING_OBJECT_PAYLOAD_PREPARATION_ONLY','files':files,'count':len(files),'allocation_bytes':allocation,'source_HEAD_index_config_allrefs_working_status_and_primary_unchanged':True,'no_fetch_ref_or_API_write':True})
print(json.dumps({'status':plan['status'],'tip':TIP,'new_objects':len(payloads),'source_object_allocation_upper':price,'external_capsule_allocation':allocation,'closed_manifest':str(O/'CLOSED-MANIFEST.json'),'closed_manifest_sha256':sha((O/'CLOSED-MANIFEST.json').read_bytes())},indent=2))
