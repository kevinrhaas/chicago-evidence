"""Prepared only. Missing-only public8b objects into own ordinary clone after actual54 checkpoint publication; no refs/fetch."""
from pathlib import Path
from urllib.request import Request,urlopen
import argparse,datetime,hashlib,json,os,re,shutil,subprocess,zlib
F=Path('/workspace/t2372-parallel-native-20261030');G=F/'.git';P=Path('/workspace/chicago')
OLD='3746b23bf1298c34a29946b4cdb6ee2d98abff8f';BASE='54e4004add7ab5208d71a51282c008cda6e7edad';TIP='8b4e98207c1afcff4878239cd700379447218cfb';TREE='444505c7ca5a22c7e90c653a10f579630be6978c';BRANCH='steward/t2381-t2373-t2384-t2377-early-pictures-20261029'
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');sha=lambda b:hashlib.sha256(b).hexdigest()
def g(r,*a):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false',*a],env=E)
def state(r):return dict(head=g(r,'rev-parse','HEAD').decode().strip(),branch=g(r,'branch','--show-current').decode().strip(),index=sha(g(r,'ls-files','--stage','-z')),flags=sha(g(r,'ls-files','-v','-z')),config=sha((r/'.git/config').read_bytes()),refs=sha(g(r,'for-each-ref','--format=%(refname) %(objectname)')),status=g(r,'status','--porcelain=v1','--untracked-files=all').decode())
def api(path):
 with urlopen(Request('https://api.github.com/repos/kevinrhaas/chicago/'+path,headers={'User-Agent':'Chicago-named8b-bounded-native-object-import','Accept':'application/vnd.github+json'}),timeout=90)as r:return json.load(r)
def have(ids):
 ids=sorted(set(ids));raw=subprocess.check_output(['git','-C',str(F),'cat-file','--batch-check=%(objectname) %(objecttype)'],input=('\n'.join(ids)+'\n').encode(),env=E)
 return {p[0]for row in raw.decode().splitlines()if len(p:=row.split())==2 and p[1]!='missing'}
def resource(extra=0):
 ws=shutil.disk_usage('/workspace').free;tmp=shutil.disk_usage('/tmp').free;alloc=int(subprocess.check_output(['du','-s','-B1',str(F)]).split()[0])
 assert ws>=536870912+extra and tmp>=1800000000 and alloc+extra<=4600000000,(ws,tmp,alloc,extra)
 return dict(workspace_free=ws,shared_TMP_free=tmp,source_allocation=alloc,extra_allocation_reserved=extra,workspace_floor=536870912,shared_TMP_floor=1800000000,clone_cap=4600000000)
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--expect-head',required=True);a.add_argument('--checkpoint',required=True,type=Path);a.add_argument('--publication',required=True,type=Path);a.add_argument('--payload-manifest',required=True,type=Path);a.add_argument('--payload-manifest-sha256',required=True);a.add_argument('--output',required=True,type=Path);a.add_argument('--execute',action='store_true');a=a.parse_args();os.sched_setaffinity(0,{2});os.nice(19)
 assert re.fullmatch('[0-9a-f]{40}',a.expect_head)and a.expect_head not in [OLD,BASE,TIP]
 out=a.output.resolve();assert not out.exists()and out.is_relative_to('/workspace')and not out.is_relative_to(F)and not out.is_relative_to(P);out.mkdir();save=lambda n,d:(out/n).write_text(json.dumps(d,indent=2)+'\n')
 mb=a.payload_manifest.read_bytes();assert sha(mb)==a.payload_manifest_sha256;manifest=json.loads(mb);root=a.payload_manifest.resolve().parent;assert manifest['status']=='CLOSED_NAMED8B_PUBLIC_MISSING_OBJECT_PAYLOAD_PREPARATION_ONLY'
 for row in manifest['files']:
  rel=Path(row['relative']);p=root/rel;assert not rel.is_absolute()and'..'not in rel.parts and p.is_file()and not p.is_symlink();b=p.read_bytes();assert len(b)==row['bytes']and sha(b)==row['sha256']
 plan=json.loads((root/'PLAN.json').read_bytes());assert plan['tip']==TIP and plan['source_writes']is False and plan['allocation_upper_plus_receipt_reserve']<=32*1048576 and plan['cap_bytes']==32*1048576
 leaves_path=root/plan['tip_leaves_path'];assert sha(leaves_path.read_bytes())==plan['tip_leaves_sha256'];wanted=json.loads(leaves_path.read_bytes())
 cp_raw=a.checkpoint.read_bytes();cp=json.loads(cp_raw);pub_raw=a.publication.read_bytes();pub=json.loads(pub_raw)
 assert cp['status']=='ACTUAL_PR1456_GENUINE54_NATIVE_TWO_PARENT_CHECKPOINT_PASS'and cp['head']==a.expect_head and cp['tree']==TREE and cp['parents']==[OLD,BASE]and cp['clean']is True
 assert pub['status']=='ACTUAL_SOURCE_QUALIFIED_PR1456_NATIVE_NORMAL_FF_CHECKPOINT_AND_ALL_CHANGED_PATH_READBACK_PASS'and pub['head']==a.expect_head and pub['tree']==TREE and pub['parents']==[OLD,BASE]and pub['force']is False and pub['checkpoint_sha256']==sha(cp_raw)and pub['gate_sha256']==cp['source_gate_sha256']
 before=state(F);primary=state(P);assert before['head']==a.expect_head and before['branch']==BRANCH and not before['status']and not(G/'MERGE_HEAD').exists()and before['config']==plan['prepared_source']['config']
 assert g(F,'show','-s','--format=%P','HEAD').decode().strip().split()==[OLD,BASE]and g(F,'rev-parse','HEAD^{tree}').decode().strip()==TREE
 assert (G/'objects').is_dir()and not(G/'objects').is_symlink();pr=api('pulls/1456');assert pr['state']=='open'and not pr['merged']and pr['head']['ref']==BRANCH and pr['head']['sha']==a.expect_head and pr['base']['ref']=='dev'
 remote=api('git/commits/'+TIP);assert remote['sha']==TIP and remote['tree']['sha']==plan['tree'];actual_dev=api('git/ref/heads/dev')['object']['sha']
 all_ids={r['oid']for r in plan['payloads']}|{r[2]for r in wanted.values()};existing=have(all_ids);payload_rows={r['oid']:r for r in plan['rows']};price=plan['allocation_upper_plus_receipt_reserve'];r=resource(price)
 save('PLAN.json',dict(status='NAMED8B_MISSING_ONLY_NATIVE_OBJECT_IMPORT_QUALIFIED_READONLY_NO_SOURCE_WRITE',tip=TIP,tip_tree=plan['tree'],actual_current_dev_reported_not_chased=actual_dev,source=before,primary=primary,source_gate_publication_head=a.expect_head,payload_manifest_sha256=sha(mb),payload_objects=len(plan['payloads']),currently_missing=len(all_ids-existing),allocation_upper=price,resource=r,no_fetch_ref_API_or_working_source_write=True))
 assert state(F)==before and state(P)==primary
 if not a.execute:print((out/'PLAN.json').read_text());return
 written=[]
 for row in plan['payloads']:
  sid=row['oid'];assert re.fullmatch('[0-9a-f]{40}',sid)
  if sid in have([sid]):continue
  encoded=(root/row['relative']).read_bytes();assert len(encoded)==row['bytes']and sha(encoded)==row['sha256'];decoded=zlib.decompress(encoded);assert hashlib.sha1(decoded).hexdigest()==sid;header,raw=decoded.split(b'\0',1);kind,n=header.decode().split();assert kind==payload_rows[sid]['kind']and int(n)==len(raw)==payload_rows[sid]['raw_bytes']and sha(raw)==payload_rows[sid]['sha256']
  dest=G/'objects'/sid[:2]/sid[2:];assert not dest.exists();dest.parent.mkdir(exist_ok=True);tmp=dest.with_name(dest.name+'.named8b-'+str(os.getpid()))
  with tmp.open('xb')as f:f.write(encoded);f.flush();os.fsync(f.fileno())
  os.link(tmp,dest);tmp.unlink();os.chmod(dest,0o444);assert hashlib.sha1(zlib.decompress(dest.read_bytes())).hexdigest()==sid;written.append(sid);resource()
 assert all_ids<=have(all_ids);actual={}
 for row in g(F,'ls-tree','-rz',TIP).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);actual[path.decode()]=meta.decode().split()
 assert actual==wanted and state(F)==before and state(P)==primary and sha(a.checkpoint.read_bytes())==sha(cp_raw)and sha(a.publication.read_bytes())==sha(pub_raw)and sha(a.payload_manifest.read_bytes())==sha(mb)
 save('RESULT.json',dict(status='ACTUAL_NAMED8B_MISSING_ONLY_NATIVE_OBJECT_IMPORT_PASS_SOURCE_PRIMARY_INDEX_CONFIG_REFS_WORKING_BYTES_UNCHANGED',tip=TIP,tip_tree=plan['tree'],source_checkpoint_head=a.expect_head,all_tip_leaf_modes_types_blobs_exact=len(actual),written_objects=written,allocation_upper=price,resource_after=resource(),no_fetch_API_ref_or_working_source_write=True,origin_dev_tracking_ref_NOT_updated=True,current_dev_reported_not_chased=actual_dev));print((out/'RESULT.json').read_text())
if __name__=='__main__':main()
