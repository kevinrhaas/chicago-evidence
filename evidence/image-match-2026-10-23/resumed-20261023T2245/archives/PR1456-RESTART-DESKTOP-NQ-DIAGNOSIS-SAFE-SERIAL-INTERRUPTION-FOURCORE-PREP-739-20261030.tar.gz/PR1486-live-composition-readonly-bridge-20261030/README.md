# PR1486 named8b composition audit — read-only

At17:16:32UTC PR1486 remained open/non-draft/head40453, servermergeable and clean, with allfour actual head checkssuccessful. Native logs previously prove that substantive CI checked synthetic584328[a248,40453]. Official40453 phone398.969MiB belongs to its237 data binding. Neither qualification is restamped8b.

Named8b is ten commits/66paths beyond237, covering foreign stable, Kimball, Pullman and Hibbard model work plus jaunt viewpoint avoidance. Allseven performance-base path modes/types/blobOIDs remain unchanged. Complete immutable recursive trees for237/40453/8b were read and reconstructed to their original Git treeOIDs without imports or source writes. Exact composition8b nonown+40453own7 yields tree19d3dfe41b431b5a1c0128ea96acc678bcc479b0.

Jaunt occluder records are lazy: official fresh-context spawn entry maps zero tree/post/trunk records. Empty arrays/constants/function/closure/code metadata still have unmeasured V8 bytes. Allfour WEB payloads grow38,676B physically/153,008B declaredbuffers together; this is not a CPU+GPU+V8 resident bound. No unmeasured8b phonePASS is claimed.

Root approval of this exact dated-scope composition and an actual closed grouped BOTH PASS remain required. Any later unclassified dev must stop without automatic sourcebranch chasing. No merge, native gate/browser/runtime, source/site/index/config/ref/import/checkout/CI/API mutation occurred. Only external audit files were written.
