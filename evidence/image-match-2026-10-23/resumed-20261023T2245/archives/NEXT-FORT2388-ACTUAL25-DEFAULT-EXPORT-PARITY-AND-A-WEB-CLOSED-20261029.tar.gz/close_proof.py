from pathlib import Path
import json,hashlib,struct,datetime
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((P/'ACTUAL-NATIVE-EXPORT-RESULT.json').read_text());assert r['all25_old_new_master_bytes_exact']and r['all25_existing_source_master_bytes_exact']
master=Path(r['candidate_A']['path']);web=P/'candidate/assets/web'/master.name;raw=web.read_bytes();jlen=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+jlen]);assert g['asset']['generator']=='glTF-Transform v4.5.0';assert 'EXT_meshopt_compression'in g.get('extensionsUsed',[])
record=json.loads((P/'candidate/assets/manifest.web.json').read_text());assert record['masters'][master.name]==sha(master);assert web.stat().st_size<master.stat().st_size
nr=json.loads((P/'NATIVE-REAPER.json').read_text());wr=json.loads((P/'WEB-REAPER.json').read_text());assert all(x['command_exit']==0 and x['all_children_reaped']for x in[nr,wr])
inputs=json.loads((P/'INPUTS.json').read_text());assert sha(Path(inputs['source_emit']['path']))==inputs['source_emit']['sha256'];assert sha(A/'tools/web_derivatives.sh')==inputs['source_web_script_sha256']
for e in inputs['family']:
 assert sha(Path(e['current_master']))==e['current_master_sha256'];assert sha(A/'data/structures'/(e['id']+'.json'))==e['record_sha256']
r['web']={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'path':str(web),'bytes':web.stat().st_size,'sha256':sha(web),'master_sha256':sha(master),'generator':g['asset']['generator'],'actual_EXT_meshopt_compression':True,'native_master_binding_exact':True,'fallback':False}
r['execution']={'native_seconds':nr['observed_unix']-nr['started_unix'],'web_seconds':wr['observed_unix']-wr['started_unix'],'all_children_reaped':True,'cpu_affinity':'0,1','blender_version':'4.5.3 LTS','new_native_exports':51,'default_baseline_current_matches':25,'source_records_and_masters_unchanged_after_WEB':True}
r['candidate_source_sha256']={p.name:sha(p)for p in sorted((P/'inputs/candidate').iterdir())if p.is_file()};r['limits']={'no_source_adoption':True,'clearance_footprint_palisade_neighbours':'UNRUN','actual_stair_ground_walking':'UNRUN','source_picture_comparison':'UNRUN','full_fort_acceptance':'NOT_CLAIMED','global_app_policy_gate':'UNRUN','historical1835_continuity':'NOT_ASSERTED'}
(P/'CLOSED-RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'default_current_exact':25,'native_seconds':r['execution']['native_seconds'],'web_seconds':r['execution']['web_seconds'],'web':r['web']}))
