from pathlib import Path
import sys,json,importlib.util,hashlib,time,datetime,shutil
P=Path('/workspace/T2388-native-access-proof-20261029');A=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(A/'generators'));import emit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs=json.loads((P/'INPUTS.json').read_text());outcomes=[]
def use(label):
 for name in ['fort_structure_params','fort_structure']:
  fullname='archetypes.'+name;spec=importlib.util.spec_from_file_location(fullname,P/'inputs'/label/(name+'.py'));mod=importlib.util.module_from_spec(spec);sys.modules[fullname]=mod;spec.loader.exec_module(mod)
 params=sys.modules['archetypes.fort_structure_params'];arch=sys.modules['archetypes.fort_structure'];emit.ARCHETYPES['fort_structure']=(params.from_phase,arch.build)
for label in ['old','candidate']:
 use(label);target=P/('old25'if label=='old'else'candidate25');target.mkdir(exist_ok=True)
 for e in inputs['family']:
  r=json.loads(Path(e['record']).read_text());phase=next(x for x in r['phases']if x['id']==e['phase']);t=time.monotonic();dest=target/e['asset'];made=emit.emit_structure(r,phase,'fort_structure',dest,bake=True,ao=False);assert dest.exists();outcomes.append({'label':label,'asset':e['asset'],'seconds':time.monotonic()-t,'sha256':sha(dest),'bytes':dest.stat().st_size,'triangles':made.tris,'exact_current_master':sha(dest)==e['current_master_sha256']});print(json.dumps(outcomes[-1]),flush=True)
# Keep a binary control copy only where current source output actually differs.
for e in inputs['family']:
 old=P/'old25'/e['asset'];new=P/'candidate25'/e['asset'];assert old.read_bytes()==new.read_bytes(),e['asset']+' newdefault changed'
 if sha(old)!=e['current_master_sha256']:
  d=P/'current25-differences'/e['asset'];d.parent.mkdir(exist_ok=True);shutil.copyfile(e['current_master'],d)
 rsrc=A/'data/structures'/(e['id']+'.json');assert sha(rsrc)==e['record_sha256'];assert sha(Path(e['current_master']))==e['current_master_sha256']
use('candidate');r=json.loads((P/'inputs/candidate/fort_dearborn_commandants_quarters.json').read_text());dest=P/'candidate/assets/gltf'/(r['id']+'__'+r['phases'][0]['id']+'.glb');t=time.monotonic();made=emit.emit_structure(r,r['phases'][0],'fort_structure',dest,bake=True,ao=False)
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'default_rows':outcomes,'all25_old_new_master_bytes_exact':True,'all25_existing_source_master_bytes_exact':all(x['exact_current_master']for x in outcomes),'candidate_A':{'path':str(dest),'seconds':time.monotonic()-t,'sha256':sha(dest),'bytes':dest.stat().st_size,'triangles':made.tris},'source_records_and_current_masters_unchanged':True,'web':'PENDING','clearance_walking_photo_app_adoption':'UNRUN'};(P/'ACTUAL-NATIVE-EXPORT-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'actual_defaults':50,'old_new_exact':True,'all_current_exact':result['all25_existing_source_master_bytes_exact'],'candidate':result['candidate_A']}),flush=True)
