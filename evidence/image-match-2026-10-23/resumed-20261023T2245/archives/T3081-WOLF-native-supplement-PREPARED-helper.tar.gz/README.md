# Bounded normal-native Wolf views, supplemental to the ten fixed cases

Root extended the published-QA grant for at most two normal native views after the ten cases finish. This external helper makes one fresh1280×800/full native app boot at exact clean6bf head and same published build, then uses native free-fly/teleport controls for two southeast Wolf views. It changes no building/vegetation visibility, asset/data, canonical camera or reference-view file. The first overlooks the L/body from(-52E,-72N), native altitude8m; the second approaches the primary east/+X south entries from(-56E,-60N), native altitude3.2m. Aim is computed from the actual live bounds/placement, not a source camera solve. Requested and actual mode/position/quaternion/matrices and native centre-building GPU pick are recorded. All raw review notices and all unknown/page/network/cleanup errors are preserved, and the exact current14 review flags use the authorized v4 semantics.

The helper checks actual HTTP-loaded compressed Wolf GLB bytes against the published and authored web derivative, and retains original framing/occlusion evidence separately. No image-match verdict is written. Result images require direct inspection; if either remains obscured, record that limitation. It takes exactly two PNGs, with no hidden-scene alternative.

Only after the ten-case batch completes, under the extended root grant:

```sh
TMPDIR=/workspace/tmp-t3081 PW_EXECUTABLE=/usr/bin/chromium node /tmp/T3081-native-supplement-20261024/supplement.mjs --out /workspace/T3081-PR1260-native-supplement --execute
```

Syntax and dry mode only were checked when this preparation was frozen. `STATUS.json` in the separate actual output records PID, requested poses, partial view receipts and final exit durably. Original frozen v1–v4 and failed-v3 actual evidence stay untouched. No photo_match is included.
