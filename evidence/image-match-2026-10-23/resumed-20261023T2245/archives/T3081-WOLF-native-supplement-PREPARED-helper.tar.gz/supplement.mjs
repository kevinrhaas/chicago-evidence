// Root-authorized bounded native fly inspection; no scene/data/asset visibility changes.
import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import crypto from 'node:crypto';import {createRequire} from 'node:module';import {execFileSync} from 'node:child_process';
import {checkReviewNotices} from '/tmp/T3081-published-qa-v4-20261024/review-notices.mjs';
const app='/tmp/chicago-log-integration/chicago/4d',site=path.resolve(app,'../../site/4d');
const args=process.argv.slice(2),index=args.indexOf('--out'),out=index<0?null:args[index+1];if(!out)throw Error('--out <NEW absolute output> required');
const config=JSON.parse(fs.readFileSync('/tmp/T3081-published-qa-v4-20261024/models.json')),m=config.models.find(m=>m.id==='wolf_point_tavern'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const poses=[{id:'wolf-se-body',e:-52,n:-72,altitude_m:8,aim_fraction_y:.40},{id:'wolf-se-entries',e:-56,n:-60,altitude_m:3.2,aim_fraction_y:.23}];
if(!args.includes('--execute')){console.log(JSON.stringify({status:'PREPARED_NOT_EXECUTED',app,site,out,poses,limits:'At most two normal native fly views, after ten published cases. No image-match verdict, scene hiding, vegetation suppression, data or reference-camera changes.'},null,2));process.exit(0);}
if(fs.existsSync(out))throw Error('Refusing existing output');fs.mkdirSync(out,{recursive:true});
const r={status:'RUNNING',started_at:new Date().toISOString(),pid:process.pid,app,site,poses,views:[],page_errors:[],http_errors:[],request_failures:[],asset_responses:[],limits:'Supplemental normal native fly inspection only. Original native framing preserved separately. No scene hiding, vegetation suppression, asset/data/reference-camera changes or image-match verdict.'};
const save=()=>{const tmp=path.join(out,'STATUS.next.json');fs.writeFileSync(tmp,JSON.stringify(r,null,2)+'\n');fs.renameSync(tmp,path.join(out,'STATUS.json'));};save();
let browser,context,server,error;const inflight=new Map(),tasks=[];
const git=(...a)=>execFileSync('git',['-C',app,...a],{encoding:'utf8'});
try{
 r.head=git('rev-parse','HEAD').trim();r.source_status_before=git('status','--porcelain');if(r.head!=='6bf9d0e91fef27dedb9d364132e290706dd27609'||r.source_status_before)throw Error('Exact clean6bf source required');
 const build=JSON.parse(fs.readFileSync(path.join(site,'build.json')));r.build=build;if(build.version!==r.head.slice(0,9))throw Error('Wrong mirror build');
 if(sha(fs.readFileSync(path.join(app,'data/structures',m.id+'.json')))!==m.record_sha256)throw Error('Authored Wolf record drift');
 const web=fs.readFileSync(path.join(app,'assets/web',m.asset));r.expected_web_sha256=sha(web);if(sha(fs.readFileSync(path.join(site,'data/gltf',m.asset)))!==r.expected_web_sha256)throw Error('Published Wolf asset drift');
 const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.glb':'model/gltf-binary','.ktx2':'image/ktx2','.wasm':'application/wasm'};
 server=http.createServer((req,res)=>{try{const url=new URL(req.url,'http://localhost');let p=path.resolve(site,'.'+decodeURIComponent(url.pathname));if(p!==site&&!p.startsWith(site+path.sep)){res.writeHead(403);res.end();return;}if(fs.statSync(p).isDirectory())p=path.join(p,'index.html');res.writeHead(200,{'Content-Type':types[path.extname(p)]||'application/octet-stream'});fs.createReadStream(p).pipe(res);}catch{res.writeHead(404);res.end('missing');}});await new Promise(ok=>server.listen(0,'127.0.0.1',ok));
 const require=createRequire('/workspace/__qa__.mjs'),{chromium}=require('playwright');browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE||'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 context=await browser.newContext({viewport:{width:1280,height:800},deviceScaleFactor:1,isMobile:false,hasTouch:false});const page=await context.newPage();page.setDefaultTimeout(240000);
 page.on('pageerror',e=>r.page_errors.push(String(e)));page.on('request',q=>inflight.set(q,q.url()));page.on('requestfinished',q=>inflight.delete(q));page.on('requestfailed',q=>{inflight.delete(q);r.request_failures.push({url:q.url(),failure:q.failure()});});
 page.on('response',q=>{if(q.status()>=400)r.http_errors.push({url:q.url(),status:q.status()});if(q.url().split('?')[0].endsWith('/data/gltf/'+m.asset))tasks.push((async()=>{const b=await q.body();r.asset_responses.push({url:q.url(),status:q.status(),bytes:b.length,sha256:sha(b)});})().catch(e=>r.request_failures.push({url:q.url(),failure:String(e)})));});
 await page.goto('http://127.0.0.1:'+server.address().port+'/walk/',{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:240000,polling:1000});
 const boot=await page.evaluate(()=>({ready:__chicago4d.ready,error:__chicago4d.error,scene:__chicago4d.scene?.id}));r.boot=boot;if(!boot.ready||boot.error||String(boot.scene)!=='1835')throw Error('Native boot failed: '+JSON.stringify(boot));
 await page.waitForFunction(()=>__chicago4d.welcome?.state==='welcome',null,{timeout:240000});
 await page.evaluate(async()=>{const a=__chicago4d;if(!a.ready||a.error||String(a.scene.id)!=='1835')throw Error('Wrong or failed native scene');await a.setDetail('full');if(!a.welcome.enter('spawn'))throw Error('Native entry failed');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.renderer.setAnimationLoop(null);a.setAnimationHold(true);a.setFly(true);a.popup.close();a.navigator.dock();});
 for(const pose of poses){
  const view=await page.evaluate(({pose,id})=>{
   const a=__chicago4d,b=a.buildings.instanceBounds()[id],matrix=a.buildings.matrixOf(id);if(!b||!matrix)throw Error('Actual Wolf bounds/matrix absent');
   const e=matrix.elements,x=(b.min[0]+b.max[0])/2,z=(b.min[2]+b.max[2])/2,y=b.min[1]+b.size[1]*pose.aim_fraction_y;
   const target={e:e[0]*x+e[8]*z+e[12],n:-(e[2]*x+e[10]*z+e[14]),y:e[1]*x+e[5]*y+e[9]*z+e[13]};
   const ground=a.walker.surfaceAt(pose.e,pose.n),eye=ground+pose.altitude_m,de=target.e-pose.e,dn=target.n-pose.n;
   const yaw=(Math.atan2(de,dn)*180/Math.PI+360)%360,pitch=Math.atan2(target.y-eye,Math.hypot(de,dn))*180/Math.PI;
   a.walker.teleport({local_e:pose.e,local_n:pose.n,altitude_m:pose.altitude_m,yaw_deg:yaw,pitch_deg:pitch});a.step();
   const stats=a.stats(),hit=a.buildings.pickAt({x:0,y:0},a.camera);a.camera.updateMatrixWorld();
   return {id:pose.id,requested_pose:pose,mode:'native free-fly',target,yaw_deg:yaw,pitch_deg:pitch,walker:{...a.walker.enu,flying:a.walker.state.flying,altitude_m:a.walker.state.altitude},camera:{position:a.camera.position.toArray(),quaternion:a.camera.quaternion.toArray(),matrix_world:a.camera.matrixWorld.toArray(),projection_matrix:a.camera.projectionMatrix.toArray(),fov:a.camera.fov,aspect:a.camera.aspect,near:a.camera.near,far:a.camera.far},centre_building_pick:hit?.id??null,phase:a.registry.get(id)?.sidecar?.phase,asset:a.registry.get(id)?.sidecar?.asset,bounds:b,placement_matrix:matrix.toArray(),stats,raw_problems:a.problems,registry_review_ids:[...a.registry.values()].filter(q=>q.sidecar?.review_required).map(q=>q.sidecar.id).sort(),scene_visibility_unchanged:true};
  },{pose,id:m.id});
  view.review_notices=checkReviewNotices(config.scene_review_notices,view.registry_review_ids,view.raw_problems);
  if(view.review_notices.failures.length)throw Error(view.review_notices.failures.join('\n'));if(!view.walker.flying||view.phase!==m.phase||view.asset!=='gltf/'+m.asset)throw Error('Wrong native fly state or selected Wolf asset');
  view.screenshot=pose.id+'.png';await page.screenshot({path:path.join(out,view.screenshot)});r.views.push(view);save();
 }
 const deadline=Date.now()+30000;while(inflight.size&&Date.now()<deadline)await new Promise(ok=>setTimeout(ok,100));r.pending_requests=[...inflight.values()];if(inflight.size)throw Error('Pending native requests');await Promise.all(tasks);
 if(!r.asset_responses.length||r.asset_responses.some(x=>x.status!==200||x.sha256!==r.expected_web_sha256))throw Error('Actual HTTP Wolf asset binding mismatch');
 r.status='ACTUAL_TWO_NATIVE_VIEWS_REQUIRES_VISUAL_REVIEW';
}catch(e){error=e;r.status='FAIL';r.error=String(e.stack||e);}
finally{
 try{await context?.close();}catch(e){r.cleanup_errors??=[];r.cleanup_errors.push(String(e));}try{await browser?.close();}catch(e){r.cleanup_errors??=[];r.cleanup_errors.push(String(e));}if(server)await new Promise(ok=>server.close(ok));
 r.source_status_after=git('status','--porcelain');if(r.page_errors.length||r.http_errors.length||r.request_failures.length||r.cleanup_errors?.length||r.source_status_after){error??=Error('Page/network/cleanup/source status failure');r.status='FAIL';r.error??=String(error);}
 r.ended_at=new Date().toISOString();r.exit_code=error?1:0;save();
}
console.log(JSON.stringify({status:r.status,out,error:r.error??null},null,2));if(error)process.exitCode=1;
