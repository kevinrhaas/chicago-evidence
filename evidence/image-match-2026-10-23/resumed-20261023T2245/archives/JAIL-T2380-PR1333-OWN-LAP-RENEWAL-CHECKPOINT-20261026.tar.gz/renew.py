from pathlib import Path
import subprocess,json,hashlib,os,datetime
out=Path('/workspace/shared/T2380-lap1333-renewal-20261026T0505');repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);actor='Codex jail picture 2026-10-25';head='4176cc2e410e70604f40af1b1101f71ddd242e29'
def run(c,cwd=repo):return subprocess.check_output(c,cwd=cwd,env=env,text=True)
def api(p):return json.loads(run(['gh','api',p]))
def snapshot():
 ip=Path(run(['git','rev-parse','--git-path','index']).strip());ip=ip if ip.is_absolute()else repo/ip
 return {'head':run(['git','rev-parse','HEAD']).strip(),'index_sha256':hashlib.sha256(ip.read_bytes()).hexdigest(),'tracked_status':run(['git','status','--porcelain=v1','-uno']),'worktree_diff_sha256':hashlib.sha256(run(['git','diff','--binary']).encode()).hexdigest(),'index_diff_sha256':hashlib.sha256(run(['git','diff','--cached','--binary']).encode()).hexdigest()}
def save(n,d):(out/n).write_text(json.dumps(d,indent=2)+'\n')
old=snapshot();assert old['head']==head and old['tracked_status']==''
pr=api('repos/kevinrhaas/chicago/pulls/1333');assert pr['state']=='open' and pr['head']['sha']==head and pr['head']['ref']=='steward/t2380-jail-palisade' and pr['base']['ref']=='dev'
ref=api('repos/kevinrhaas/chicago/git/ref/heads/lap/pr-1333');before=api('repos/kevinrhaas/chicago/git/commits/'+ref['object']['sha']);assert before['message'].splitlines()[0].startswith('lap PR #1333 — '+actor+' '),before['message']
save('BEFORE.json',{'source':old,'public_pr':{'number':pr['number'],'head':pr['head']['sha'],'base':pr['base']['ref'],'state':pr['state']},'marker':before,'marker_ref':ref})
with(out/'native-renew.log').open('w')as log:p=subprocess.run(['node','tools/ticket.mjs','lap','1333','--force','--by',actor],cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,p.returncode
ref2=api('repos/kevinrhaas/chicago/git/ref/heads/lap/pr-1333');after=api('repos/kevinrhaas/chicago/git/commits/'+ref2['object']['sha']);assert ref2['object']['sha']!=ref['object']['sha'];assert after['message'].splitlines()[0].startswith('lap PR #1333 — '+actor+' ')
with(out/'native-status.log').open('w')as log:p=subprocess.run(['node','tools/ticket.mjs','lap','1333','--status'],cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==3 and actor in(out/'native-status.log').read_text()
new=snapshot();assert new==old,(old,new)
pr2=api('repos/kevinrhaas/chicago/pulls/1333');assert pr2['head']['sha']==head and pr2['state']=='open'
t=datetime.datetime.fromisoformat(after['committer']['date'].replace('Z','+00:00'));expiry=t+datetime.timedelta(hours=3)
save('AFTER.json',{'marker_ref':ref2,'marker':after,'source':new})
result={'status':'NATIVE_EXACT_OWN_LAP_RENEWED_SOURCE_INDEX_UNCHANGED','actor':actor,'pr':1333,'public_head':head,'old_marker':ref['object']['sha'],'new_marker':ref2['object']['sha'],'taken_at':after['committer']['date'],'native_run_hours':3,'expires_after':expiry.isoformat().replace('+00:00','Z'),'source_index_worktree_guards':new==old,'native_status_exit':p.returncode,'dependency_1328_still_required':True,'no_merge_or_code_change':True};save('RESULT.json',result);print(json.dumps(result,indent=2))
