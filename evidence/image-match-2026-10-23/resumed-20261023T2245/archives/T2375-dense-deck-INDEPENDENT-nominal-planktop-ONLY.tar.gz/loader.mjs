import fs from 'node:fs';
const fixture=new URL('./fixture/',import.meta.url).href,root='file:///workspace/chicago/chicago/4d/renderers/web/';
export function resolve(specifier,context,nextResolve){
 if(specifier==='three')return{url:root+'vendor/three-0.185.1/three.module.js',shortCircuit:true};
 if(specifier.startsWith('three/addons/'))return{url:root+'vendor/three-0.185.1/addons/'+specifier.slice(13),shortCircuit:true};
 if(specifier.startsWith('.')&&context.parentURL?.startsWith(fixture)){const u=new URL(specifier,context.parentURL);if(!fs.existsSync(u))return{url:root+'js/'+u.href.slice(fixture.length),shortCircuit:true};}
 return nextResolve(specifier,context);
}
