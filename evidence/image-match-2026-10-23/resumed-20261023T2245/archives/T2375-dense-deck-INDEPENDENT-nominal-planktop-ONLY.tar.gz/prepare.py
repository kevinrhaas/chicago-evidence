from pathlib import Path
import hashlib,json,shutil
out=Path(__file__).resolve().parent;app=Path('/workspace/chicago/chicago/4d');v2=Path('/tmp/chicago-next-model/T-2375-native-surface-profile-v2');prior=Path('/tmp/chicago-next-model/T-2375-adoption-kwonly');bind={}
for rel in ['generators/archetypes/bridge_timber.py','generators/archetypes/bridge_timber_params.py']:
 source=v2/'candidate/chicago/4d'/rel;target=out/'fixture'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);bind[str(source)]=hashlib.sha256(source.read_bytes()).hexdigest()
for rel in ['generators/common/mesh.py','generators/common/logwork.py','generators/common/materials.py','generators/common/__init__.py','generators/archetypes/__init__.py']:
 source=app/rel
 if (prior/'baseline/chicago/4d'/rel).exists():assert source.read_bytes()==(prior/'baseline/chicago/4d'/rel).read_bytes()
 target=out/'fixture'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);bind[str(source)]=hashlib.sha256(source.read_bytes()).hexdigest()
for source,name in [(prior/'candidate/chicago/4d/data/structures/dearborn_street_drawbridge.json','record.json'),(v2/'fixture.json','native-fixture.json'),(v2/'candidate/chicago/4d/renderers/web/js/deck-surface.js','deck-surface.js'),(v2/'candidate/chicago/4d/renderers/web/js/walker.js','walker.js'),(v2/'candidate/chicago/4d/renderers/web/js/route.js','route.js')]:
 shutil.copyfile(source,out/'fixture'/name);bind[str(source)]=hashlib.sha256(source.read_bytes()).hexdigest()
bind[str(v2/'MANIFEST.json')]=hashlib.sha256((v2/'MANIFEST.json').read_bytes()).hexdigest();(out/'source-bindings.json').write_text(json.dumps(bind,indent=2)+'\n')
