from pathlib import Path
import sys,types,json,math,hashlib,bisect,collections
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT/'fixture';sys.path.insert(0,str(ROOT/'generators'));sys.modules['bpy']=types.ModuleType('bpy')
from common.mesh import MeshBuilder
from archetypes import bridge_timber as B,bridge_timber_params as P
class Raw(MeshBuilder):
 def to_object(self,mats=None):return self
B.MeshBuilder=Raw;B.simple_material=lambda *a,**k:None
record=json.loads((ROOT/'record.json').read_text());p=P.from_phase(record['phases'][0],record)
raw=B.build(p,'dearborn_street_drawbridge__draw_1834')
digest=hashlib.sha256(json.dumps({k:getattr(raw,k)for k in ['verts','faces','conf','mat_index']},separators=(',',':')).encode()).hexdigest();assert digest=='8db45fe611fb6b25d59b9c80808858905ab8a1b201834f216b1dd58668df10d3',digest
profile=P.walk_surface_profile(p);assert profile==json.loads((ROOT/'native-fixture.json').read_text())['profile_side']['placement']['walk_surface_profile']
key=lambda b,f,m:(m,tuple(tuple(b.verts[i])for i in f))
full=collections.Counter(key(raw,f,m)for f,m in zip(raw.faces,raw.mat_index))
roles={}
for name,emit in [('planks',lambda b:B._deck(b,p,p.deck_height_m,p.worst_conf('construction','width_m','clearance_m','deck_kind'))),('leaf_beams',lambda b:B._draw_leaves(b,p,p.deck_height_m,p.worst_conf('draw_leaves','draw_span_m'))),('rails',lambda b:B._railing(b,p,p.deck_height_m,p.conf('railing')))]:
 b=Raw(name);emit(b);B._apply_draw_profile(b,p);c=collections.Counter(key(b,f,m)for f,m in zip(b.faces,b.mat_index));assert all(full[k]>=n for k,n in c.items()),name;roles[name]=b
# Triangulate actual clipped convex polygons; never replace deck faces by a box.
def triangles(b):
 rows=[]
 for fi,(f,m)in enumerate(zip(b.faces,b.mat_index)):
  for j in range(1,len(f)-1):
   a,c,d=[b.verts[i]for i in [f[0],f[j],f[j+1]]];den=(c[1]-d[1])*(a[0]-d[0])+(d[0]-c[0])*(a[1]-d[1])
   if abs(den)<1e-12:continue # vertical faces have no positive-area floor projection
   rows.append((min(a[0],c[0],d[0]),max(a[0],c[0],d[0]),min(a[1],c[1],d[1]),max(a[1],c[1],d[1]),a,c,d,den,fi,m))
 return rows
tri={name:triangles(b)for name,b in roles.items()};tri['all']=triangles(raw)
# Analytic complete-face certificate for every actual plank top triangle.
tops=[];bad=[];stations=[x for x,_ in profile['stations_m']]
for fi,(f,m)in enumerate(zip(roles['planks'].faces,roles['planks'].mat_index)):
 pts=[roles['planks'].verts[i]for i in f]
 if all(abs(v[2]-(p.deck_height_m+P.draw_rise_m_at(p,v[0])))<1e-11 for v in pts):
  xs=[v[0]for v in pts];cross=[x for x in stations[1:-1]if min(xs)+1e-9<x<max(xs)-1e-9]
  if cross:bad.append({'face':fi,'xs':xs,'missed_stations':cross})
  tops.append((min(xs),max(xs)))
assert not bad
# Dense deterministic grid, plus every visible gap midpoint and all geometry/station
# breakpoints and near-boundary sides. The regular grid alone cannot resolve the actual8mm sawn-board gaps.
xset={round(i*p.span_m/1600,12)for i in range(1,1600)};riven=p.deck_kind=='puncheon';gap=.022 if riven else .008;n=max(int(p.span_m/(B.PLANK_PITCH_M if riven else B.SAWN_PITCH_M)),2);pitch=p.span_m/n
for i in range(n+1):xset.add(i*pitch)
for a,c in tops:
 for x in (a,c):
  for eps in (-1e-6,0,1e-6):
   if 0<x+eps<p.span_m:xset.add(x+eps)
for x in stations:
 for eps in (-1e-6,0,1e-6):
  if 0<x+eps<p.span_m:xset.add(x+eps)
xs=sorted(xset);ys=sorted({p.width_m*i/80 for i in range(1,80)}|{.001,.01,.029,.031,.06,.12,p.width_m-.001,p.width_m-.01,p.width_m-.029,p.width_m-.031,p.width_m-.06,p.width_m-.12})
# Binning by actual x coverage keeps this bounded scan light.
bins={}
for role,rows in tri.items():
 byx=[[]for _ in xs]
 for row in rows:
  for i in range(bisect.bisect_left(xs,row[0]-1e-10),bisect.bisect_right(xs,row[1]+1e-10)):byx[i].append(row)
 bins[role]=byx

def hit(rows,x,y):
 z=None;which=None
 for row in rows:
  _,_,y0,y1,a,b,c,den,fi,mat=row
  if not y0-1e-10<=y<=y1+1e-10:continue
  u=((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(y-c[1]))/den
  v=((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(y-c[1]))/den
  if min(u,v,1-u-v)<-1e-9:continue
  height=u*a[2]+v*b[2]+(1-u-v)*c[2]
  if z is None or height>z:z=height;which={'face':fi,'material':mat}
 return z,which

counts=collections.Counter();maxerr=0.;beammax=0.;othermax=0.;examples={};rows_out=[]
for xi,x in enumerate(xs):
 expected=p.deck_height_m+P.draw_rise_m_at(p,x)
 for y in ys:
  heights={role:hit(bins[role][xi],x,y)for role in bins}
  z,face=heights['planks'];counts['samples']+=1
  if z is None:
   counts['no_plank_hit']+=1
   if 'no_plank_hit'not in examples:examples['no_plank_hit']={'x':x,'y':y,'profile':expected,'actual_triangle_hit':None,'all_mesh_hit':heights['all'][0]}
  else:
   counts['plank_hit']+=1;error=abs(z-expected);maxerr=max(maxerr,error)
   if error>1e-9 and 'plank_mismatch'not in examples:examples['plank_mismatch']={'x':x,'y':y,'triangle_height':z,'profile':expected,'error':error,'triangle':face}
  beam=heights['leaf_beams'][0]
  if beam is not None:
   counts['leaf_beam_hit']+=1;beammax=max(beammax,beam-expected)
   if beam>expected+.054 and 'proud_leaf_threshold'not in examples:examples['proud_leaf_threshold']={'x':x,'y':y,'beam_top':beam,'profile':expected,'delta':beam-expected,'plank_height':z}
  allz,allface=heights['all'];rail=heights['rails'][0]
  if rail is not None and rail>expected+.2:
   counts['rail_above_floor']+=1
   if 'rail_is_not_floor'not in examples:examples['rail_is_not_floor']={'x':x,'y':y,'rail_top':rail,'profile':expected,'plank_height':z}
  if allz is not None and allz>expected+.056:
   counts['highest_other_above_floor']+=1;othermax=max(othermax,allz-expected)
   if 'highest_mesh_is_not_floor'not in examples:examples['highest_mesh_is_not_floor']={'x':x,'y':y,'highest_mesh':allz,'profile':expected,'plank_height':z,'triangle':allface}
  rows_out.append([x,y,expected,z,beam,rail,allz])
assert maxerr<1e-9,maxerr
assert abs(beammax-.055)<1e-9,beammax
report={'status':'PASS nominal plank-profile coherence; gaps and55mm thresholds explicitly retained as proxy limits','raw_digest':digest,'raw_vertices':len(raw.verts),'raw_faces':len(raw.faces),'profile':profile,'grid_x_count':len(xs),'grid_y_count':len(ys),'counts':dict(counts),'maximum_plank_profile_error_m':maxerr,'maximum_proud_leaf_beam_offset_m':beammax,'maximum_highest_other_offset_m':othermax,'examples':examples,'analytic_all_faces':{'top_polygons':len(tops),'every_top_vertex_lies_on_profile':True,'every_top_face_interval_contains_no_unrepresented_profile_breakpoint':True,'missed_breakpoints':bad,'reason':'All top faces are clipped to one affine profile segment; barycentric triangle interpolation therefore agrees throughout each actual top face.'},'role_subset_proof':{name:{'faces':len(b.faces),'all_exact_polygon_material_keys_occur_in_full_raw':True}for name,b in roles.items()},'regular_x_step_m':p.span_m/1600,'plank_count':n,'deck_kind':p.deck_kind,'gap_width_m':gap,'limits':['No plank-hit samples remain no hit; profile is a continuous nominal walk proxy over the resolved8mm sawn-board gaps.','Leaf/hinge/edge thresholds are55mm proud and not included in the plank profile; physical topmost surface is not everywhere equal to the proxy.','Rails/gallows/hoists are not floor; highest-any-material ray is explicitly not a walk-floor oracle.','CPU raw triangle/model coherence only; no Blender/browser/GPU/image/contact acceptance.']}
(OUT/'dense-mesh-review.json').write_text(json.dumps(report,indent=2)+'\n')
# Compact full grid numeric evidence, preserving null no-hit entries; compressed artifact.
import gzip
with gzip.open(OUT/'dense-grid.json.gz','wt')as f:json.dump({'columns':['local_x','local_y','profile_z','plank_hit_z','leaf_beam_hit_z','rail_hit_z','all_mesh_highest_z'],'rows':rows_out},f,separators=(',',':'))
print(json.dumps({k:report[k]for k in ['status','raw_digest','grid_x_count','grid_y_count','counts','maximum_plank_profile_error_m','maximum_proud_leaf_beam_offset_m','examples']},indent=2))
