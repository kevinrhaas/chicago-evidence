# Independent dense raw-deck/profile coherence review

**PASS for the exact proposed nominal plank-top profile. No missing camber station or hidden triangulation chord was found.** This does not assert equality to every topmost bridge surface, continuous material coverage, collision/foot contact or browser/image acceptance. No canonical or frozen author files were changed.

The full proposed raw mesh retains exact four-list SHA256 **8db45fe611fb6b25d59b9c80808858905ab8a1b201834f216b1dd58668df10d3**,27,640 vertices/6,846 polygons. Copied native modules/common helpers and proposed record reconstruct that same mesh. No default-family result was relabeled or rerun; the six existing parity results remain the author's separate evidence.

## Complete-face certificate and dense measurement

The profile stations are local x0,29.021,38.165,47.309,76.33m, at heights2.22,2.22,3.42,2.22,2.22m. `_apply_draw_profile` clips every affected face at the two draw ends and apex before displacing vertices. Independent inspection of **all296 actual plank-top polygons** finds every vertex on the profile and no face spanning an unrepresented affine-segment breakpoint. Every resulting top triangle therefore interpolates the same affine height throughout its area. Plank ends are coverage boundaries, not omitted changes of floor slope.

A **3661×91 =333,151-point** bounded grid covers span and interior width, with regular longitudinal step47.70625mm, all actual plank-top boundaries and ±1µm sides, every actual gap midpoint, every profile station and ±1µm sides, and near-edge lateral controls. Rays use the actual clipped raw polygons triangulated as convex fans; vertical faces have zero floor-projection area and are excluded. This is a two-sided geometric height test, not GPU winding/visibility qualification.

-248,521 positive plank hits; maximum triangle/profile error **8.881784197e-16m**.
-84,630 no-plank-hit grid points remain JSON null; no surface was invented for the mesh proof. Counts include extra boundary/gap probes and are not area-weighted coverage percentages.
-The actual resolved target is **`deck_kind=plank`,293 sawn boards,8mm gaps**. The22mm puncheon branch is not this target.

Plank, leaf-beam and railing categories were obtained from their isolated **unchanged native emitters**, folded by the same candidate function, then verified as exact polygon/material multisets contained in the full raw mesh. No arbitrary material-height rule selected the floor. The full-mesh ray was retained as a diagnostic to expose rails/overhead members, never used as the floor oracle.

## Actual copied consumer coherence

`check_consumers.mjs` imports copied native sidecar/deck/walker/router code. It maps local XY through the actual placement and exercises shared `deckHeightAt`, actual walker `surfaceAt` and the unchanged exact-point router function extracted directly from the copied native closure. It checks **332,969 interior points** (excluding exact span endpoint controls):

-Shared/walker/exact-router vs profile maximum error **3.996802889e-15m**.
-Walker vs positive actual plank hits maximum error **4.440892099e-15m**.
-All233 covering centres of an actual native1m router grid agree with the exact sampler within **1.125057008e-7m**, its Float32 height storage. The native router produces a route across the profile.
-The84,448 interior no-plank-hit points are still no-hit mesh samples, even though the nominal locomotion proxy supplies a walking height there.

This uses finite all-water CPU terrain to isolate the deck rule; it is not real heightfield, land-approach, yard, walker-body, mobile or application validation. Public grid `heightAt` is a cell-centre readback, so it is compared at its actual cell centres; it is not incorrectly asserted equal to every arbitrary point in a sloped cell. The exact-point path is tested separately at all interior points.

## Explicit proxy limits and exact counterexamples

`interior-counterexamples.json` preserves:

1. Local **x2.6051194539249147,y1.524m**: plank ray has **no hit**, and no other full-mesh triangle lies under that ray, while the nominal profile answers2.22m. This is the actual8mm board gap. A coherent walking proxy may bridge it, but must not be described as a positive triangle contact there.
2. Local **x29.021,y1.524m**: actual plank/profile2.22m, draw-leaf bearing timber **2.275m**, a **55mm proud threshold**. The full-mesh highest ray is8.62m because of the gallows; treating it as the walking floor would be wrong. The55mm threshold is an existing explicit kit detail (`LEAF_PROUD_M`), not a camber interpolation error.

The geometry concern is disproved for nominal plank tops. A literal claim that the profile equals the continuous/topmost material surface is false at these exact points. Keep the distinction explicit in the next version's contract/readiness prose; no geometry normalization is proposed. Suggested bounded wording:

> The profile follows the nominal plank tops. The walking proxy bridges the8mm sawn-board gaps and omits55mm proud draw-leaf threshold/edge timbers. It is not a maximum-height raycast over rails, gallows, chains or all mesh faces, and does not certify foot or rigid-body contact.

This carries the legacy continuous scalar-deck abstraction into the optional camber profile; it does not silently qualify an IK, wheel or whole-body support model. Existing rigid-profile refusals, image gate, reconstructed rise/source uncertainty and all actual application/GPU acceptance remain separate.

## Artifacts and reproduction

`dense-grid.json.gz` retains all333,151 rows and explicit null hits. `dense-mesh-review.json` retains the exact digest, complete-face certificate, role-subset proof and metrics. `consumer-review.json` and `interior-counterexamples.json` retain actual native consumer results and limits. `source-bindings.json` pins author/native inputs; copied fixture files are regular files.

`PYTHONDONTWRITEBYTECODE=1 python check_mesh.py`

`node --experimental-loader ./loader.mjs ./check_consumers.mjs`

Run only in a copied review directory because those proof scripts write their own receipts. No Blender/browser/native writer/full gate or source/asset/data change occurred.
