/** Numeric, engine-neutral deck profiles. Flat decks retain their original shape. */
const EPS = 1e-8;
const finite = Number.isFinite;

export function insideDeck(e, n, pts) {
  let hit = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const [x, y] = pts[i], [a, b] = pts[j];
    if ((y > n) !== (b > n) && e < (a - x) * (n - y) / (b - y) + x) hit = !hit;
  }
  return hit;
}

export function validateSpanProfile(profile, base, poly) {
  const fail = () => { throw new Error('Invalid declared walk-surface span profile'); };
  if (!profile || profile.version !== 1 || profile.axis !== 'local_x'
      || !finite(base) || !Array.isArray(profile.stations_m) || profile.stations_m.length < 2) fail();
  const stations = profile.stations_m;
  let last = -Infinity;
  for (const p of stations) {
    if (!Array.isArray(p) || p.length !== 2 || !p.every(finite) || p[0] <= last) fail();
    last = p[0];
  }
  if (Math.abs(stations[0][0]) > EPS || !(last > 0)
      || Math.abs(stations[0][1] - base) > EPS || Math.abs(stations.at(-1)[1] - base) > EPS) fail();
  if (poly && (Math.abs(Math.min(...poly.map(p => p[0]))) > EPS
      || Math.abs(Math.max(...poly.map(p => p[0])) - last) > EPS)) fail();
  return profile;
}

export function deckFromSidecar(id, sidecar) {
  const deckPlacement = sidecar?.placement ?? {}, h = deckPlacement.walk_surface_m;
  if (deckPlacement.walk_surface_profile != null && (typeof h !== 'number' || deckPlacement.vertical_anchor !== 'water')) {
    throw new Error('Invalid declared profile: a numeric water-anchored surface is required');
  }
  if (typeof h !== 'number' || deckPlacement.vertical_anchor !== 'water') return null;
  const raw = sidecar.footprint;
  const poly = Array.isArray(raw) ? raw : raw?.polygon;
  if (!Array.isArray(poly) || poly.length < 3) {
    if (deckPlacement.walk_surface_profile != null) throw new Error('Invalid declared profile footprint');
    return null;
  }
  if (deckPlacement.walk_surface_profile != null && poly.some(p => !Array.isArray(p) || p.length !== 2 || !p.every(finite))) {
    throw new Error('Invalid declared profile footprint');
  }
  const th = (deckPlacement.rotation_deg ?? 0) * (Math.PI / 180);
  const cos = Math.cos(th), sin = Math.sin(th);
  const e0 = deckPlacement.local_e ?? 0, n0 = deckPlacement.local_n ?? 0;
  const deck = { id, y: h, pts: poly.map(([u, v]) => [e0 + u * cos + v * sin, n0 - u * sin + v * cos]) };
  if (deckPlacement.walk_surface_profile != null) {
    deck.profile = validateSpanProfile(deckPlacement.walk_surface_profile, h, poly);
    if (![e0, n0, th].every(finite)) throw new Error('Invalid profile coordinate frame');
    deck.profileFrame = { e0, n0, cos, sin };
  }
  return deck;
}

/** Point height above the water anchor. Callers retain their own covering/ground policy. */
export function deckHeightAt(deck, e, n) {
  if (!deck.profile) return deck.y;
  validateSpanProfile(deck.profile, deck.y);
  const f = deck.profileFrame;
  if (!f || ![e, n, f.e0, f.n0, f.cos, f.sin].every(finite)) throw new Error('Invalid profile sample frame');
  const x = (e - f.e0) * f.cos - (n - f.n0) * f.sin;
  const s = deck.profile.stations_m;
  if (x < -EPS || x > s.at(-1)[0] + EPS) return null;
  const u = Math.max(0, Math.min(s.at(-1)[0], x));
  for (let i = 1; i < s.length; i++) {
    if (u <= s[i][0]) {
      const [a, z] = s[i - 1], [b, w] = s[i];
      return z + (w - z) * ((u - a) / (b - a));
    }
  }
  return s.at(-1)[1];
}

export function profileDeckAt(decks, e, n) {
  return decks.find(d => d.profile && insideDeck(e, n, d.pts)) ?? null;
}

/** Humans use their existing root-contact sampler; outside a profile preserve terrain exactly. */
export function profiledGroundHeight(terrain, decks, e, n) {
  if (!profileDeckAt(decks, e, n)) return terrain.surfaceHeight(e, n);
  let height = null;
  for (const d of decks) {
    if (!insideDeck(e, n, d.pts)) continue;
    const y = deckHeightAt(d, e, n);
    if (typeof y === 'number' && (height === null || y > height)) height = y;
  }
  if (height === null) return terrain.surfaceHeight(e, n);
  return terrain.isWater(e, n) ? height : Math.max(height, terrain.surfaceHeight(e, n));
}

/** Unsupported rigid contacts are explicitly refused by existing finite-height guards.
 * Covers wheel/support/tongue and yard groundAt; never raises the terrain itself.
 */
export function refuseProfiledSupportHeight(decks, fallback) {
  if (!decks.some(d => d.profile)) return fallback;
  return (e, n, ...rest) => profileDeckAt(decks, e, n) ? NaN : fallback(e, n, ...rest);
}

export function refuseProfiledSupportTerrain(terrain, decks) {
  if (!decks.some(d => d.profile)) return terrain;
  return Object.create(terrain, { surfaceHeight: {
    value: refuseProfiledSupportHeight(decks, (e, n) => terrain.surfaceHeight(e, n)),
  } });
}

/** Whole placements are refused only where their actual projected triangles or
 * declared contact points touch a non-flat span. No expanded exclusion radius. */
export function createProfilePlacementEligibility(decks) {
  const spans = decks.filter(d => d.profile).map(d => ({ ...d,
    e0: Math.min(...d.pts.map(p => p[0])), e1: Math.max(...d.pts.map(p => p[0])),
    n0: Math.min(...d.pts.map(p => p[1])), n1: Math.max(...d.pts.map(p => p[1])),
  }));
  if (!spans.length) return null;
  const orient = (a, b, c) => (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
  const on = (p, a, b) => Math.abs(orient(a,b,p)) <= EPS
    && p[0] >= Math.min(a[0],b[0])-EPS && p[0] <= Math.max(a[0],b[0])+EPS
    && p[1] >= Math.min(a[1],b[1])-EPS && p[1] <= Math.max(a[1],b[1])+EPS;
  const segments = (a,b,c,d) => {
    const abC=orient(a,b,c), abD=orient(a,b,d), cdA=orient(c,d,a), cdB=orient(c,d,b);
    return (abC*abD < 0 && cdA*cdB < 0) || on(c,a,b) || on(d,a,b) || on(a,c,d) || on(b,c,d);
  };
  const covered = (p, poly) => insideDeck(...p,poly) || poly.some((a,i) => on(p,a,poly[(i+1)%poly.length]));
  const inTriangle = (p,a,b,c) => {
    if (Math.abs(orient(a,b,c)) <= EPS) return false;
    const s=[orient(a,b,p),orient(b,c,p),orient(c,a,p)];
    return s.every(x=>x>=-EPS) || s.every(x=>x<=EPS);
  };
  const refusal = d => `unsupported whole placement intersects profiled span ${d.id}`;
  const pointsReason = points => {
    for (const p of points) {
      if (!Array.isArray(p) || p.length!==2 || !p.every(finite)) throw Error('Invalid placement contact point');
      for (const d of spans) if (covered(p,d.pts)) return refusal(d);
    }
    return null;
  };
  const trianglesReason = positions => {
    if (positions.length % 9) throw Error('Invalid placement triangle stream');
    for (let i=0;i<positions.length;i+=9) {
      for(let j=0;j<9;j++) if (!finite(positions[i+j])) throw Error('Non-finite placement triangle');
      const t=[[positions[i],-positions[i+2]],[positions[i+3],-positions[i+5]],[positions[i+6],-positions[i+8]]];
      if (!t.every(p=>p.every(finite))) throw Error('Non-finite placement triangle');
      const e0=Math.min(...t.map(p=>p[0])),e1=Math.max(...t.map(p=>p[0]));
      const n0=Math.min(...t.map(p=>p[1])),n1=Math.max(...t.map(p=>p[1]));
      for (const d of spans) {
        if (e1<d.e0-EPS || e0>d.e1+EPS || n1<d.n0-EPS || n0>d.n1+EPS) continue;
        if (t.some(p=>covered(p,d.pts)) || d.pts.some(p=>inTriangle(p,...t))
          || t.some((a,j)=>d.pts.some((c,k)=>segments(a,t[(j+1)%3],c,d.pts[(k+1)%d.pts.length])))) return refusal(d);
      }
    }
    return null;
  };
  const assertReason = reason => {
    if (!reason) return;
    const error=Error(reason);error.profilePlacementRefusal=true;throw error;
  };
  const refusedReplacements=new Map();
  return { refusedReplacements, pointsReason, trianglesReason,
    assertPoints(points) { assertReason(pointsReason(points)); },
    assertTriangles(positions) { assertReason(trianglesReason(positions)); },
    refuseReplacement(id,reason) { if (id) refusedReplacements.set(id,reason); },
  };
}

/** Per-object scratch emission: no stream, material/grain state or span/census
 * commit until the complete object passes. Existing flat path calls draw directly. */
export function emitEligiblePlacement(buf, draw, eligibility, id, problems, sharedCaches = []) {
  if (!eligibility) return draw(buf,problems);
  const banned=eligibility.refusedReplacements.get(id);
  if (banned) { problems.push(`yard: ${id}: ${banned}; legacy fallback not drawn`);return false; }
  const lanes=['pos','nrm','conf','col','uv','uv1'];
  const scratch={...buf};
  for (const lane of lanes) scratch[lane]=[];
  // Native toneOf is first-writer-wins at a rounded shade key. A refused
  // object must not seed a later accepted object's material through that cache.
  const cacheKeys=sharedCaches.map(cache=>new Set(cache.keys()));
  const rollbackCaches=()=>sharedCaches.forEach((cache,i)=>{
    for (const key of cache.keys()) if (!cacheKeys[i].has(key)) cache.delete(key);
  });
  const pendingProblems=[];
  let drew,reason;
  try {
    drew=draw(scratch,pendingProblems);
    if (drew) reason=eligibility.trianglesReason(scratch.pos,id);
  } catch (error) { rollbackCaches();throw error; }
  if (!drew) { rollbackCaches();problems.push(...pendingProblems);return false; }
  if (reason) { rollbackCaches();problems.push(`yard: ${id}: ${reason}; whole object not drawn`);return false; }
  // These lanes are append-only in the native yard builders. Other fields are
  // immutable tone/atlas references or assigned scalar/grain state.
  for (const [key,value] of Object.entries(scratch)) {
    if (lanes.includes(key)) { for (const x of value) buf[key].push(x); }
    else buf[key]=value;
  }
  problems.push(...pendingProblems);
  return true;
}
