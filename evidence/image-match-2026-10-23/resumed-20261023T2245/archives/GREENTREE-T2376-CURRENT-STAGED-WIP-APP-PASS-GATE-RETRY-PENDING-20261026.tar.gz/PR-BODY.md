Green Tree Tavern now has the two viewer-left ground-floor sash and rightmost entrance shown in the Andreas 1838 engraving, corroborated by the retrospective Trowbridge and Kurz views. The doorway moves 2.286 m within the unchanged footprint; the native entrance, approach apron and nearby goods follow it. Exact spacing remains a declared reconstruction in the building card's liberties.

The sparse frame parameter is consumed through one recipe-hashed property by both the mesh builder and the entrance producer. All 23 frame masters and their actual web derivatives were regenerated: the other 22 masters and 22 web derivatives remain byte-identical. The legacy parameters, grades, materials, population and protected research outputs remain unchanged.

T-2376 remains open. The current image comparison records two visitor-visible differences: annex massing and the long-wall opening pattern. Conflicting upper/attic details and drawing-camera residuals are within tolerance under T-3153. The known 1859 catalogue photograph remains an unverified cross-check; it supplies no newly derived geometry.

Validation: REQUIRED_GATE_RESULT_PENDING. Actual published app checks passed at 390×780 and 1280×800 with zero page/network/loader errors, including normal and confidence views, source credits, the new liberty, served web-asset bytes, and clear grounded approaches at 2 m and 3 m. The prior 1 m diagnostic remains blocked by the existing conservative router inflation and is documented. The existing Sources & Images tab remains link-only.

The initial app proof uses the c6 scene; incoming 9f operative 1835 geometry, terrain and entrances were verified identical. This checked checkpoint is based on 9f; integration of the newer dev head and the final combined published smoke matrix remain required before merge. This PR targets dev only.

Source comparison: [Andreas 1838 side by side](chicago/4d/docs/RESEARCH/photo-match/green_tree_tavern/andreas_1838-side-by-side.jpg). Research and source/date coverage: [Green Tree dossier](chicago/4d/docs/RESEARCH/green_tree_tavern.md).
