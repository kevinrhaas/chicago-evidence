

### L-green-tree-right-front-entry — Green Tree front-ground opening order

**Covers:** `green_tree_tavern.frame_1833.form.front_ground_layout`.

**Decision:** Use two lower sash to the left of a rightmost entrance on the main +y front gable only. This corrects the archetype's centre-door/flanking-sash assumption. The actual whole Andreas1884 p634/n1301 plate, Trowbridge/Gale1902 plate facing printedp35/n55 and Kurz1893 panel11 agree about that relative order. Their retrospective agreement is form evidence, not independent contemporary proof of the July1835 state: Kurz may derive from Andreas and Trowbridge may rely on later material. The selected .22/.50/.80 width fractions, retained .85×1.35m sash and1.20×2.10m door stock, vertical bands, casing, joinery and hidden treatment are explicitly **reconstructed**, not measurements read from those plates. The whole new attribute remains reconstructed and the control refuses a stronger grade.

**Source:** `andreas_1884_green_tree_hotel_plate`, `trowbridge_green_tree_1902`, `kurz_allison_1893`; retain their existing publication credits and qualified source-period/dependence notes. Existing public-domain underlying artwork status is unchanged. `chm_green_tree_1859` remains check_required/unverified and is excluded as a governing geometry source. The site1859.jpg engraving is not thereby a verified photograph or permission to reproduce later shopfronts in1835.

**Limits:** Upper two-versus-three sash, attic, text-attested south-side entrance, ell/other additions, roof, finish, geographic placement and camera remain unchanged and unresolved. No new historical date, dimension, hidden feature, source rights or structure/per-attribute grade is promoted. Existing ledger history remains intact. This paragraph revises only the old front-ground opening assumption, not the wider Green Tree reconstruction.

**How to resolve:** Actual official family export/default parity, source-specific cameras and inspected side-by-sides with all ticket pictures; retain DIFFERS until visible differences are resolved. This proposal's CPU checks are not new GLBs or picture matches.

**Ticket:** Original T-2376 remains OPEN; no utility ticket or claim created by this external proposal.

**Recorded:** 2026-10-24 (external UNAPPLIED proposal; not yet a canonical ledger entry).
