"""Read-only compatibility gate. No source update, union, stamp or asset writes."""
import argparse,pathlib,json,hashlib,sys
P=pathlib.Path(__file__).parent
parser=argparse.ArgumentParser();parser.add_argument('--repo',required=True);args=parser.parse_args();root=pathlib.Path(args.repo)/'chicago/4d';g=json.load(open(P/'GUARDS.json'));drift=[]
for path,row in g['paths'].items():
 if path in ('assets/manifest.json','assets/manifest.web.json'):continue
 f=root/path;actual=hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
 expected=row['observed_live_sha256'] if path=='docs/LIBERTIES.md' else row['committed7a_sha256']
 if actual!=expected:drift.append({'path':path,'expected_sha256':expected,'actual_sha256':actual})
# A new tool mentioning this archetype is a newly named reader: refuse until
# reviewed and explicitly added, rather than trusting an old fixed name pool.
known=set(g['frame_reader_paths']);actual=set()
for f in (root/'tools').glob('*.py'):
 text=f.read_text()
 if 'frame_tavern' in text or 'FrameTavernParams' in text:actual.add(f.relative_to(root).as_posix())
if actual!=known:drift.append({'frame_reader_membership_added':sorted(actual-known),'removed':sorted(known-actual)})
if drift:
 print(json.dumps({'status':'REFUSE_DRIFT_REQUIRES_SELECTIVE_UNION_REVIEW','drift':drift},indent=2));raise SystemExit(1)
print('PASS exact owned source/data preimages, current named readers, source credits, CPU dependencies and observed latest LIBERTIES prefix; no files changed')
