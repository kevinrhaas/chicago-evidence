from pathlib import Path
import subprocess, json, hashlib, gzip, zipfile, io, shutil, datetime
import xml.etree.ElementTree as ET

root = Path('/tmp/jail-picture-c6')
out = Path('/workspace/T2382-Carpenter-adoption-20261026')
base = '1290a23271b2771c77201fd17fed7cfa857ade14'
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])
assert git('rev-parse', 'HEAD').decode().strip() == base
paths = git('ls-files', '*.xlsx', '*.gz').decode().splitlines()
assert len(paths) == 44
def node(n):
    text = n.text
    if text is not None and not text.strip() and len(n):
        text = None
    return n.tag, tuple(sorted(n.attrib.items())), text, n.tail if n.tail and n.tail.strip() else None, tuple(node(c) for c in n)
def equivalent(a, b, name):
    if name.endswith('.gz'):
        return gzip.decompress(a) == gzip.decompress(b), 'exact decompressed bytes'
    za, zb = zipfile.ZipFile(io.BytesIO(a)), zipfile.ZipFile(io.BytesIO(b))
    names = sorted(za.namelist())
    if names != sorted(zb.namelist()):
        return False, 'different ZIP members'
    for part in names:
        aa, bb = za.read(part), zb.read(part)
        same = node(ET.fromstring(aa)) == node(ET.fromstring(bb)) if part.endswith(('.xml', '.rels')) else aa == bb
        if not same:
            return False, 'changed full member: '+part
    return True, 'all XML tree values/attributes and non-XML members equal'
rows, restore = [], {}
for rel in paths:
    old, actual = git('show', base+':'+rel), (root/rel).read_bytes()
    row = {'path':rel, 'before_sha256':hashlib.sha256(old).hexdigest(), 'actual_sha256':hashlib.sha256(actual).hexdigest(), 'byte_equal':actual == old}
    if actual != old:
        saved = out/'preview-generated-binaries'/rel
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root/rel, saved)
        row['semantic_equal'], row['comparison'] = equivalent(actual, old, rel)
        row['raw_generated_preserved'] = str(saved)
        restore[rel] = old
    rows.append(row)
outside = [p for p in git('diff', 'HEAD', '--name-only').decode().splitlines() if not p.startswith('chicago/4d/')]
unknown = sorted(set(outside)-set(restore))
passed = not unknown and all(r.get('semantic_equal', True) for r in rows)
proof = {'at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'base':base, 'scope':'Preview on its actual checked1290 base, before any current-dev ending integration. This does not prescribe the baseline for a future merge.', 'status':'PASS' if passed else 'FAIL', 'scanned':len(rows), 'unknown_outside_scope':unknown, 'records':rows, 'restored_after_complete_audit':[]}
(out/'PREVIEW-ALL44-AUDIT.json').write_text(json.dumps(proof, indent=2)+'\n')
assert passed, 'Actual semantic changes preserved; no restore performed'
for rel, data in restore.items():
    (root/rel).write_bytes(data)
proof['restored_after_complete_audit'] = list(restore)
(out/'PREVIEW-ALL44-AUDIT.json').write_text(json.dumps(proof, indent=2)+'\n')
print(json.dumps({'status':'PASS', 'scanned':len(rows), 'serialization_only_restored':len(restore)}))
