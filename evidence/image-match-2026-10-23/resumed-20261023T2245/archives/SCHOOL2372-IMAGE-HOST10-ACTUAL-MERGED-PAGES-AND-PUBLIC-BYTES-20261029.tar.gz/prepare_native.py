import os
os.sched_setaffinity(0, {1})
os.nice(19)
from pathlib import Path
import json, hashlib, shutil, subprocess, datetime
from urllib.request import Request, urlopen
from PIL import Image

out=Path('/tmp/school-reference-image-host-20261029')
src=Path('/tmp/T2372-next-fit-20261029')
app=Path('/workspace/chicago')
rid='early-eliza-chappel-school-shore-reference'
scope=out/'native-store-scope'
files=scope/'store/files'
lib=scope/'library'
(lib/'tools').mkdir(parents=True,exist_ok=True)
(lib/'research/images').mkdir(parents=True,exist_ok=True)
files.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
request=json.loads((src/'IMAGE-HOST-REQUEST.json').read_text())
original=(src/'SOURCE-EXACT.jpg').read_bytes()
assert len(original)==84702 and sha(original)==request['sha256']
url='https://raw.githubusercontent.com/kevinrhaas/chicago/7c5f2109cc1db6a86e23d76b4127385b587adcee/chicago/reference/images/chicago/eliza-chappel-school/21617595_10203558686525015_5452300313452439832_n.jpg'
tool_bindings=[]
for name in ['fetch_image.py','sync_image_store.py']:
    p=app/'chicago/prairie_1904_v1/tools'/name
    b=p.read_bytes(); (lib/'tools'/name).write_bytes(b)
    tool_bindings.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'exact_scoped_copy':True})
env=os.environ.copy();env['PRAIRIE_IMAGE_STORE']=str(files)
r=subprocess.run(['python3',str(lib/'tools/fetch_image.py'),rid,url,'--thumb-only'],env=env,capture_output=True,text=True)
(out/'native-thumb.stdout').write_text(r.stdout);(out/'native-thumb.stderr').write_text(r.stderr)
assert r.returncode==0, r.stderr
local=json.loads(r.stdout)
assert local['original_sha256']==sha(original) and local['original_bytes']==len(original)
assert local['original_px']==[640,368]
# This exact-copy tool writes the permitted reference display without reencoding it.
display=files/(rid+'.jpg');display.write_bytes(original)
local.update(display='research/images/files/'+display.name,display_bytes=len(original))
records=json.loads((src/'PROPOSED-LIBRARY-STREAM.json').read_text());assert len(records)==1
record=records[0];record['local']=local
record['date']='Undated drawing; republished 2018-01-19'
record['reference_copy']['credit']['date']='Undated drawing; republished 2018'
record['reference_copy']['credit_statement']=record['reference_copy']['credit_statement'].replace('its2018','its 2018')
stream='stream-eliza-chappel-school-reference.json'
dump(lib/'research/images'/stream,records);dump(out/stream,records)
for args,name in [([], 'native-sync'),(['--check'],'native-sync-check')]:
    r=subprocess.run(['python3',str(lib/'tools/sync_image_store.py'),*args],env=env,capture_output=True,text=True)
    (out/(name+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==0
native=json.loads((scope/'store/MANIFEST.json').read_text())
native_store=json.loads((lib/'research/images/STORE.json').read_text())
assert set(native['files'])=={rid+'.jpg',rid+'-thumb.jpg'}
base_ref=json.loads((out/'BASE-REF.json').read_text())['object']['sha']
raw='https://raw.githubusercontent.com/kevinrhaas/chicago-images/'+base_ref+'/prairie-1904/MANIFEST.json'
with urlopen(Request(raw,headers={'User-Agent':'Chicago-school-image-host'}),timeout=120) as r:
    assert r.status==200; base_bytes=r.read()
(out/'BASE-MANIFEST.json').write_bytes(base_bytes);base=json.loads(base_bytes)
assert len(base['files'])==1302
assert not set(base['files'])&set(native['files'])
final={**base,'generated':'2026-10-29','files':{**base['files'],**native['files']}}
final['_doc']=final['_doc'].replace('Only public-domain / no-known-restrictions items are stored.','Public-domain / no-known-restrictions items and owner-approved attributed reference copies are stored under the repository README policy; rights remain recorded per item.')
assert all(final['files'][k]==v for k,v in base['files'].items())
dump(out/'MANIFEST-POSTIMAGE.json',final);dump(out/'APP-STORE-TWO-ROWS.json',native_store)
validation=[]
for p in sorted(files.glob('*.jpg')):
    b=p.read_bytes()
    with Image.open(p) as im:
        im.verify()
    with Image.open(p) as im:
        size=list(im.size);assert max(size)<=640
        if p.name.endswith('-thumb.jpg'):assert max(size)==400
    validation.append({'file':p.name,'bytes':len(b),'sha256':sha(b),'dimensions':size,'JPEG_decode':'PASS'})
assert display.read_bytes()==original
dump(out/'NATIVE-ENTRYWISE-PROOF.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','base':base_ref,'all_existing_rows_exact':1302,'new_rows':native['files'],'new_files':validation,'tools':tool_bindings,'display_exact_original':True,'native_thumb_and_scoped_sync':True,'rights':'unknown; owner-approved attributed project reference, no PD finding','app_source_written':False,'images_checkout_written':False})
print(json.dumps({'status':'PASS','files':validation,'base_rows_preserved':1302,'base':base_ref}),flush=True)
