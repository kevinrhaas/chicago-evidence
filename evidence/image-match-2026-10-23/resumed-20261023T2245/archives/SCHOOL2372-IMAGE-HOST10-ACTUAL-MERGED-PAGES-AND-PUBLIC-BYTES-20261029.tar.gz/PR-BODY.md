Add the full credited schoolhouse drawing and a thumbnail for the Images tab. The display preserves the exact held 640 × 368 JPEG; the existing native image tool produces the 400 × 230 thumbnail.

Original artist, publication, holding institution and copyright status remain unknown. The record retains the owner-approved attributed project-reference scope and credits the Digital Research Library of Illinois History Journal’s 2018 reproduction. This is not a public-domain finding or copyright-holder licence. The drawing does not establish the school’s identity or date.

Validation: native thumbnail generation and scoped manifest sync/check passed; both JPEGs decode; the display SHA matches the held original. All 1,302 existing manifest rows and every unrelated repository path remain exact. Immutable branch readback verified all three changed files. App/model adoption and picture acceptance remain separate T-2372 work.
