# School reference hosting — actual qualified image-store delivery

Image PR [#10](https://github.com/kevinrhaas/chicago-images/pull/10) merged normally into the image store’s main at `01fb9631dd4b3a1a83c1db68f1c0f7225eb4f1dd`. Pages run `40930492832` succeeded; both normal public HTTPS URLs returned 200 with the native sizes and SHA256 values.

Adopt `stream-eliza-chappel-school-reference.json` into the app library stream path, and merge only the two rows from `APP-STORE-TWO-ROWS.json` through the native source/image build flow. All existing app STORE rows must remain. The display is the exact 640×368/84,702-byte held JPEG (SHA256 `1a63b75fea04e52cbdbbc5ffb2e85749cf648454970cb1bec0d8426a2cba61b9`); the native 400×230 thumbnail is 18,017 bytes (SHA256 `dc7f62ba142f97337c26dc9f5ea38293fe277f3140a31926a5f3c31a8d91880d`).

The structured reproduction credit retains the unknown artist, original publication, original institution and original rights. Project-owner approval covers attributed project reference/comparison/source display; no public-domain finding, copyright-holder licence or historical subject/date proof follows. The school fit packet’s explicit not_pictured ruling and diagnostic camera limits remain necessary; do not auto-attest the school from this uncertain drawing.

The native fetch tool generated the thumb; a hash-guarded tool copied the exact permitted display without reencoding. Scoped native sync/check passed. The final host manifest preserves all 1,302 older rows exactly and every unrelated repository tree entry is unchanged. Its general documentation now states the README’s existing permission for attributed owner-approved reference copies.

This agent wrote no app source or models. No app adoption, full scene build, mobile/desktop review, original ticket closure or whole-image-match acceptance is claimed. The images checkout remains clean at its preexisting local HEAD; transport was bounded Git Data REST, not a fetch or direct main push. Parent/child/qualified-tree verification proves the standard expected-head merge.
