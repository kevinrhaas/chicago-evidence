// External T2386-only native app probe. Prepared, UNRUN. No browser or server launch.
// Call with page.evaluate(nativeRoofProbe, fixture.poses[i]) only under the root's
// exclusive native appearance lease and on a freshly published exact-head tree.
export function nativeRoofProbe(pose) {
  const a = window.__chicago4d;
  if (!a?.ready || a.error || a.scene?.id !== '1835') throw Error('1835 native app is not ready');
  if (!a.registry.has('wolf_point_tavern')) throw Error('Wolf missing from actual registry');
  a.walker.teleport({local_e: pose.e, local_n: pose.n, altitude_m: pose.altitude_m,
    yaw_deg: pose.yaw_deg, pitch_deg: pose.pitch_deg});
  a.setAnimationHold(true);
  a.step(); a.step();
  const roofs = [];
  a.buildings.group.traverse(o => {
    if (!o.isMesh) return;
    const ids = o.userData?.batchIndex || [];
    const wolfInstances = ids.flatMap((id, i) => id === 'wolf_point_tavern' ? [i] : []);
    if (!wolfInstances.length) return;
    for (const m of [o.material].flat()) {
      if (m?.userData?.chiRoofRelief !== 'roof_shingle') continue;
      const image = t => ({uuid:t?.uuid || null,source:t?.source?.data?.src || t?.image?.src || null,
        width:t?.image?.width || null,height:t?.image?.height || null});
      roofs.push({name:m.name,wolf_instances:wolfInstances,
        chiRoofRelief:m.userData.chiRoofRelief,normal_map:image(m.normalMap),
        roughness_map:image(m.roughnessMap),ao_map:image(m.aoMap),
        shared_orm:!!m.roughnessMap && m.roughnessMap === m.aoMap,
        basecolour_map:!!m.map,vertex_colors:m.vertexColors,
        normal_scale:m.normalScale?.toArray(),shader_key:m.customProgramCacheKey?.(),
        visible:o.visible,geometry_attributes:Object.keys(o.geometry?.attributes || {})});
    }
  });
  if (!roofs.length || roofs.some(x => !x.normal_map.uuid || !x.shared_orm))
    throw Error('Wolf shingle normal/ORM bindings not proven');
  const c=a.camera, st=a.walker.state;
  return {status:'ACTUAL_NATIVE_PROBE_REQUIRES_SCREENSHOT_VISUAL_REVIEW',pose,
    walker:{e:st.e,n:st.n,y:st.eyeY,flying:st.flying,altitude_m:a.walker.altitudeM},
    scene:a.scene.id,record:a.registry.get('wolf_point_tavern').sidecar,
    camera:{position:c.position.toArray(),quaternion:c.quaternion.toArray(),
      world:c.matrixWorld.toArray(),projection:c.projectionMatrix.toArray(),fov:c.fov,aspect:c.aspect,near:c.near,far:c.far},
    centre_pick:a.pick?.({x:0,y:0})?.id || null,roofs,stats:a.stats?.(),problems:[...a.problems]};
}
