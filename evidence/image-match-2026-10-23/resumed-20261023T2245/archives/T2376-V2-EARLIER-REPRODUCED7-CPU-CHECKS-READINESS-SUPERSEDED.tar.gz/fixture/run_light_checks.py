"""External-only serial CPU verification; does not call native/export/browser writers."""
import pathlib,subprocess,os,json,hashlib,datetime,sys
P=pathlib.Path(__file__).parent;os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();inputs={str(f.relative_to(P)):sha(f) for folder in ['candidate','baseline','cpu-deps'] for f in sorted((P/folder).rglob('*')) if f.is_file()};inputs.update({n:sha(P/n) for n in ['GUARDS.json','family23.json','existing-provisional-camera.json','PROJECTION-DEPENDENCIES.json']})
runs=[]
commands=[('cpu-check.log',[sys.executable,str(P/'check_cpu.py')]),('focused-check.log',[sys.executable,str(P/'check_focused.py')]),('native-access-check.log',[sys.executable,str(P/'check_native_access.py')]),('projection-check.log',['node',str(P/'check_projection.mjs')]),('name-reader-check.log',[sys.executable,str(P/'check_name_reader.py')]),('preimage-check.log',[sys.executable,str(P/'verify_preimages.py'),'--repo','/tmp/chicago-log-integration']),('guard-faults.log',[sys.executable,str(P/'check_guard_faults.py')])]
for log,cmd in commands:
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();proc=subprocess.run(cmd,cwd=P,env=env,capture_output=True,text=True);(P/log).write_text(proc.stdout+proc.stderr);runs.append({'command':cmd,'log':log,'started':started,'exit':proc.returncode,'log_sha256':sha(P/log)})
 if proc.returncode:
  (P/'LIGHT-CHECKS-RECEIPT.json').write_text(json.dumps({'status':'FAILED','inputs':inputs,'runs':runs},indent=2)+'\n');raise SystemExit(proc.returncode)
assert all(sha(P/name)==digest for name,digest in inputs.items()),'frozen candidate/dependencies drift during checks'
(P/'LIGHT-CHECKS-RECEIPT.json').write_text(json.dumps({'status':'ALL7CPU_CHECKS_PASS_NO_HEAVY','affinity':list(os.sched_getaffinity(0)),'frozen_inputs_sha256':inputs,'all_frozen_inputs_before_after_exact':True,'runs':runs,'no_native_export_browser_or_fullgate':True},indent=2)+'\n');print('PASS all7serialCPU checks; exact before/after frozen inputs; no native/export/browser/fullgate')
