# Green Tree v2 — fresh independent readiness review

READY as an external bounded proposal; no substantive blocker remains in reviewed scope. Root has not authorized canonical adoption. OriginalT2376 remainsOPEN/DIFFERS, and originala952v1 stays immutable/BLOCKED.

Both prior defects are actually fixed. NativeThree projects the unchanged-camera v2stations as two left sash then right door; the preservedv1 projects door/sash/sash and remains a detecting negative. The actual mesh threshold interval .924…2.124m equals the exact-source-phase native reader. Native whole entrance/apron/doorway functions follow it at0/37/90/180/270/359degrees, while the old centred-reader negative still fails. Missing/unknown/duplicatephase, staleoptinfootprint and malformedcontrol refuse; no first-phase/sc.form fallback or broadfacade/renderer change is introduced. Real native callers in frontage/yard generators load compiled sidecars with phase, so the exact-phase requirement is compatible with those reviewed call sites.

AllSEVENserialoneCPUchecks were rerun in an ownedcopy and exited0:40API/23rawdefaults/22unchanged/84face-only/schema/refusals;3focusedtests; actualnativeASTworld/default/phase controls; nativeThreeprojection; realnameharvest; preimageguards;4driftfaults. This is freshv2evidence, not inheritedv1greenchecks. Original85v2and62v1payloads remained hash-exact.

The name reader actually inspected2141current source files, preserving the corpus/registry bytes; pool3470→3470, no added/removedwords, prior/candidate undeclaredcount0. A missing-keynegative detects the new authorednote. The READ fragment appends justfront_ground_layout.note; no ignored exemption, population deal, workbook/index update or fabricated reading count. This proves bounded vocabulary stability, not future population publication.

Source/order interpretation remains qualified: the three retrospective prints may share material and do not independently attestJuly1835. Exactfractions/sections are reconstructed and stronger metricgrades refused. The1859engraving doesnot verifytheheldCHMphoto/source; rights/wholegrade remainunchanged. Upper/windows/attic/wings/sideentry and camera differences stayopen.

Later adoption must preserve latestrawLIB and name-reader history through own-fragment union plus preimage refusal, then genuine23masters+23web derivatives,22defaultactualparity, ordered native sidecar/entrance/frontage/yard/publisher run, terrain/app/Bygrade/source-card/source-camera reviews and all policy gates/hosted exact-head checks. No canonical write, ticket/claim, Blender, browser, nativeproducer or fullgate was performed here. CPUchildren areclosed/CLEAR.

fixture/ is an OWNEDWORKINGCOPY: UPSTREAM-ORIGINAL-MANIFEST.json describes the immutable upstream package at its originalpath; fresh rerun receipts/logs in this copy differ intentionally. This packet's rootMANIFEST freezes the actual independent outputs.
