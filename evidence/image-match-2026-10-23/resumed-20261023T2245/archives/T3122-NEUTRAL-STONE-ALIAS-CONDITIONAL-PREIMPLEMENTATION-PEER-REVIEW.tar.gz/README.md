# Lighthouse neutral material alias peer review

Read-only source and actual pure parameter/material-descriptor review. The current bare-stone target's base wall and tone1 duplicate are exactly equivalent. Approve aliasing those face assignments to M_WALL only when resolved base color and roughness equal the stone/.93 descriptor. Existing valid whitewash and white controls have different wall descriptors; an unconditional alias changes their physical material semantics and should not ship. Preserve fallback named neutral tone for these cases.

No generator edits, raw geometry, Blender, export, browser or native pipeline ran here. This approves the bounded descriptor-equivalence approach before implementation, not an unviewed final patch or new actual web result. Owner retains exclusive writer/heavy lane and plans genuine family refresh.
