from pathlib import Path
import os,json,subprocess,hashlib,datetime,shutil,zipfile,xml.etree.ElementTree as ET
repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';out=Path('/tmp/T2380-native61-20261025-finish');out.mkdir();os.sched_setaffinity(0,{4});env=dict(os.environ);env.pop('CHICAGO_TICKETS_DIR',None);env.update(PYTHONPATH='/workspace/shared/python',NODE_PATH='/workspace/shared/node/node_modules',PATH='/workspace/shared/tools/usr/bin:/workspace/shared/gltf-transform/node_modules/.bin:'+env['PATH'],PW_EXECUTABLE='/usr/bin/chromium',TMPDIR='/tmp/jail-native-tmp',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',npm_config_cache='/workspace/shared/npm-cache');assert shutil.disk_usage('/tmp').free>=2*1024**3
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();baseline=Path('/tmp/T2380-native61-20261025');protected=json.loads((baseline/'PROTECTED-BEFORE.json').read_text());bookmap=json.loads((baseline/'BOOKS-BEFORE.json').read_text());assert all(sha(repo/k)==v for k,v in protected.items())
def members(p):
 with zipfile.ZipFile(p)as z:
  result={}
  for n in z.namelist():
   b=z.read(n)
   if n.endswith(('.xml','.rels')):
    root=ET.fromstring(b)
    if n=='docProps/core.xml':
     for e in list(root):
      if e.tag=='{http://purl.org/dc/terms/}modified':root.remove(e)
    result[n]=ET.canonicalize(ET.tostring(root,encoding='unicode'))
   else:result[n]=b.hex()
  return result
bookproof=[]
for rel,s in bookmap.items():
 now=repo/rel;original=Path(s['snapshot']);actual=sha(now);exact=actual==s['sha256'];same=exact or members(now)==members(original);proof={'path':rel,'original_sha256':s['sha256'],'regenerated_sha256':actual,'proof':'EXACT_BYTES' if exact else 'CANONICAL_ALL_ZIP_MEMBERS_EXCEPT_MODIFIED_TIMESTAMP','equal':same};bookproof.append(proof);(out/'BOOKS-PROOF.json').write_text(json.dumps(bookproof,indent=2)+'\n');assert same,proof
 if not exact:shutil.copy2(now,out/('regenerated-'+now.name));shutil.copy2(original,now)
for name,cmd in [('package-tail',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']),('publish',['bash','tools/publish.sh'])]:
 with(out/(name+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert p.returncode==0,(name,p.returncode)
assert all(sha(repo/k)==v for k,v in protected.items());assert all(sha(repo/k)==v['sha256']for k,v in bookmap.items())
result={'status':'PASS_NATIVE_TAIL_PUBLISH_PROTECTED','finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native61_log':'/tmp/T2380-native61-20261025-retry/native-tail.log','protected_files':len(protected),'workbooks_exact_final':len(bookmap),'books':bookproof,'affinity':sorted(os.sched_getaffinity(0)),'scope':'Native serial reader/package fixedpoint and publish only. Formal renders/app/wholecheck/imageacceptance NOT RUN. Prior harness BadZipFile preserved; exact unchanged source bytes need no ZIP parsing.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
