from pathlib import Path
import os,json,subprocess,hashlib,datetime,shutil,zipfile,xml.etree.ElementTree as ET
repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';out=Path('/tmp/T2380-native61-20261025-retry');assert not out.exists();out.mkdir();os.sched_setaffinity(0,{4});env=dict(os.environ);env.pop('CHICAGO_TICKETS_DIR',None);env.update(PYTHONPATH='/workspace/shared/python',NODE_PATH='/workspace/shared/node/node_modules',PATH='/workspace/shared/tools/usr/bin:/workspace/shared/gltf-transform/node_modules/.bin:'+env['PATH'],PW_EXECUTABLE='/usr/bin/chromium',TMPDIR='/tmp/jail-native-tmp',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',npm_config_cache='/workspace/shared/npm-cache');Path(env['TMPDIR']).mkdir(exist_ok=True);assert shutil.disk_usage('/tmp').free>=2*1024**3
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=Path('/tmp/T2380-native61-20261025')
protected=json.loads((baseline/'PROTECTED-BEFORE.json').read_text())
bookmap=json.loads((baseline/'BOOKS-BEFORE.json').read_text())
assert all(sha(repo/k)==v for k,v in protected.items()),'Original protected inputs changed before retry'
(out/'PROTECTED-BEFORE.json').write_text(json.dumps(protected,indent=2)+'\n')
(out/'BOOKS-BEFORE.json').write_text(json.dumps(bookmap,indent=2)+'\n')
started=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'RUNNING.json').write_text(json.dumps({'started':started,'pid':os.getpid(),'affinity':sorted(os.sched_getaffinity(0)),'tmp_free':shutil.disk_usage('/tmp').free,'scope':'Finite native tail only, no browser/wholegate','command':['node','tools/rederive.mjs','--tail','tools/compile_liberties.py']},indent=2)+'\n')
with(out/'native-tail.log').open('x')as log:p=subprocess.run(['node','tools/rederive.mjs','--tail','tools/compile_liberties.py'],cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
if p.returncode:
 (out/'RESULT.json').write_text(json.dumps({'status':'NATIVE_TAIL_FAIL','exit_code':p.returncode,'source_state':'Inspect actual log; no restore/commit performed'},indent=2)+'\n');raise SystemExit(p.returncode)
changed={k:{'before':v,'after':sha(repo/k)}for k,v in protected.items()if sha(repo/k)!=v};(out/'PROTECTED-AFTER.json').write_text(json.dumps({'changed':changed,'count':len(protected)},indent=2)+'\n');assert not changed,changed
# Package writers serialize workbooks. Compare all canonical XML members (apart
# from the writer timestamp), then retain exact incoming bytes if semantics agree.
def members(p):
 with zipfile.ZipFile(p)as z:
  result={}
  for n in z.namelist():
   b=z.read(n)
   if n.endswith(('.xml','.rels')):
    root=ET.fromstring(b)
    if n=='docProps/core.xml':
     for e in list(root):
      if e.tag=='{http://purl.org/dc/terms/}modified':root.remove(e)
    result[n]=ET.canonicalize(ET.tostring(root,encoding='unicode'))
   else:result[n]=b.hex()
  return result
bookproof=[]
for rel,s in bookmap.items():
 now=repo/rel;original=Path(s['snapshot']);same=members(now)==members(original);proof={'path':rel,'original_sha256':s['sha256'],'regenerated_sha256':sha(now),'all_nonvolatile_XML_members_equal':same};bookproof.append(proof)
 (out/'BOOKS-PROOF.json').write_text(json.dumps(bookproof,indent=2)+'\n');assert same,proof
 if sha(now)!=s['sha256']:shutil.copy2(now,out/('regenerated-'+now.name));shutil.copy2(original,now)
# If restoring serialization affected a package hash, use the owning native tail.
with(out/'package-tail.log').open('x')as log:p=subprocess.run(['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'],cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,p.returncode
with(out/'publish.log').open('x')as log:p=subprocess.run(['bash','tools/publish.sh'],cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,p.returncode
assert all(sha(repo/k)==v for k,v in protected.items())
assert all(sha(repo/k)==v['sha256']for k,v in bookmap.items())
result={'status':'PASS_NATIVE_TAIL_PUBLISH_PROTECTED','started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protected_files':len(protected),'books':bookproof,'affinity':sorted(os.sched_getaffinity(0)),'scope':'Native serial reader/package fixedpoint and publish only. Formal renders/app/wholecheck/imageacceptance NOT RUN.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
