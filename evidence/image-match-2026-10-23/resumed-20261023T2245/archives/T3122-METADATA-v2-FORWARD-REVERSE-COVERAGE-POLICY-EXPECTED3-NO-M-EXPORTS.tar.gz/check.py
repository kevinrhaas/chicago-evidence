from pathlib import Path
import sys,os,json,zipfile,copy,hashlib
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});sys.dont_write_bytecode=True
A=Path('/tmp/chicago-log-integration/chicago/4d');H=Path('/workspace/T3122-T3123-T3124-integration-20261024');O=Path(__file__).resolve().parent;sys.path.insert(0,str(A/'tools'));import validate as v;import compile_liberties as c
with zipfile.ZipFile(H/'closed-light-composed-proposal/OWNED-SOURCE.zip')as z:
 lib=z.read('after/chicago/4d/docs/LIBERTIES.md').decode();records={}
 for sid in ['chicago_lighthouse_1832','lake_house_construction','fort_dearborn_officers_quarters']:records[sid]=json.loads(z.read('after/chicago/4d/data/structures/'+sid+'.json'))
 def fragment(start,end=None):
  i=lib.index('### '+start);j=lib.index('### '+end,i)if end else len(lib);return lib[i:j]
 bad=fragment('L-lighthouse-visible-prototype-2373','L-lake-house-open-shell-2379');token='`chicago_lighthouse_1832.tower_1832.form.lantern_profile`, ';assert bad.count(token)==1;good=bad.replace(token,'',1);assert '**Subjects:** `chicago_lighthouse_1832`.'in good
 other=fragment('L-lake-house-open-shell-2379','L-second-fort-officers-upper-piazza-3124')+fragment('L-second-fort-officers-upper-piazza-3124');known={sid:x['name']for sid,x in records.items()};entries,problems=c.parse('## Per-subject liberties\n\n'+good+other,known);assert not problems,problems
 fields={'chicago_lighthouse_1832':['lantern_profile','tower_diameter_m','tower_openings','tower_profile','tower_lantern_detail','tower_masonry'],'lake_house_construction':['roof_type'],'fort_dearborn_officers_quarters':['gallery_storeys','face_openings']}
 projected={}
 for sid,names in fields.items():
  r=records[sid];phase=r['phases'][0];projected[sid]={'id':sid,'name':r['name'],'archetype':r.get('archetype','fort_structure'),'phases':[{'id':phase['id'],'archetype':phase.get('archetype','fort_structure'),'form':{n:copy.deepcopy(phase['form'][n])for n in names}}]}
 consumed={'fort_structure':frozenset(n for names in fields.values()for n in names)};rep=v.Report();v.check_liberties_coverage(projected,{'liberties':entries},rep,consumed);assert not rep.errors,rep.errors
 owed=v.inferred_values(projected);assert len(owed)==8 and not any(x[2]=='form.lantern_profile'for x in owed)
 badentries,badproblems=c.parse('## Per-subject liberties\n\n'+bad+other,known);assert not badproblems;badrep=v.Report();v.check_liberties_coverage(projected,{'liberties':badentries},badrep,consumed);assert any('lantern_profile'in x and'neither'in x for x in badrep.errors),badrep.errors
 # A subject link must not launder the same false Covers claim.
 own=next(e for e in entries if e['id']=='L-lighthouse-visible-prototype-2373');assert 'chicago_lighthouse_1832'in own['subjects'];assert len(own['covers'])==5
 (O/'LIBERTY-M.fragment.md').write_text('\n\n'+good.rstrip()+'\n');(O/'native-entries.json').write_text(json.dumps(entries,indent=2,ensure_ascii=False)+'\n');(O/'actual-field-projection.json').write_text(json.dumps(projected,indent=2,ensure_ascii=False)+'\n');out={'status':'PASS_UNCHANGED_NATIVE_FORWARD_AND_REVERSE_COVERAGE_ON_ACTUAL_NEW_FIELD_PROJECTION','scope':'Only9actualnew field blocks, retaining their exact values/grades/notes/sources; 8reconstructed owed, inferred category notowed. Legacyfootprint/gallery coverage deliberately outside this unitprojection, stillL44/L42 in unchanged realledger. Not fullschema/geometry/mainvalidator acceptance.','native_code_sha256':hashlib.sha256((A/'tools/validate.py').read_bytes()).hexdigest(),'native_parse_problems':problems,'positive_errors':rep.errors,'old_bad_cover_negative_errors':badrep.errors,'inferred_category_grade_unchanged':projected['chicago_lighthouse_1832']['phases'][0]['form']['lantern_profile']['confidence'],'new_M_reconstructed_covers':len(own['covers']),'M_subject_reachable':True,'canonical_writes':False};(O/'PROOF.json').write_text(json.dumps(out,indent=2)+'\n');print(out['status'])
