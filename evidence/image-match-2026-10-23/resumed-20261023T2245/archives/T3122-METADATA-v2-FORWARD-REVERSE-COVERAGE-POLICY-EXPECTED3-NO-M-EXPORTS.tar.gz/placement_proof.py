from pathlib import Path
import sys,os,json,zipfile,copy,hashlib,subprocess
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});sys.dont_write_bytecode=True
A=Path('/tmp/chicago-log-integration/chicago/4d');O=Path(__file__).resolve().parent;sys.path.insert(0,str(A/'tools'));import measure_frontage_fabric as f;import placement_policy_1835 as p
base='bd316f7f45668e906a49beeefa01a1b72ee2e5d8'
get=lambda rel:subprocess.check_output(['git','show',base+':chicago/4d/'+rel],cwd=A)
families=f.documented_families();records=[r for r in f.buildings()if r['id']in families and r['layer']=='research'];traffic=f.street_traffic();datum=json.loads((A/'data/datum.json').read_bytes());origin=datum['origin_utm_e'],datum['origin_utm_n'];old_record=json.loads(get('data/structures/chicago_lighthouse_1832.json'));next(r for r in records if r['id']=='chicago_lighthouse_1832')['world']=f.world_polygon(old_record['phases'][0],origin)
before_census=f.census(records=records);p._tree=lambda:(before_census,families,traffic);before=p.build();committed=json.loads(get('data/reconstruction/1835_placement_policy.json'));assert before==committed,'Filtered actualcohort with explicit sourcebase polygon must reproduce entire committed baseline first'
with zipfile.ZipFile('/workspace/T3122-T3123-T3124-integration-20261024/closed-light-composed-proposal/OWNED-SOURCE.zip')as z:source=json.loads(z.read('after/chicago/4d/data/structures/chicago_lighthouse_1832.json'))
datum=json.loads((A/'data/datum.json').read_bytes());origin=datum['origin_utm_e'],datum['origin_utm_n'];new=copy.deepcopy(records);row=next(r for r in new if r['id']=='chicago_lighthouse_1832');old_world=copy.deepcopy(row['world']);row['world']=f.world_polygon(source['phases'][0],origin);assert [sum(q[i]for q in old_world)/4 for i in(0,1)]==[sum(q[i]for q in row['world'])/4 for i in(0,1)]
after_census=f.census(records=new);p._tree=lambda:(after_census,families,traffic);after=p.build();diff=[]
def compare(a,b,ptr=''):
 if isinstance(a,dict)and isinstance(b,dict):
  assert set(a)==set(b)
  for key in sorted(a):compare(a[key],b[key],ptr+'/'+key.replace('~','~0').replace('/','~1'))
 elif isinstance(a,list)and isinstance(b,list):
  assert len(a)==len(b)
  for i,(x,y)in enumerate(zip(a,b)):compare(x,y,ptr+'/'+str(i))
 elif a!=b:diff.append({'pointer':ptr,'before':a,'after':b})
compare(before,after);assert before['constants']==after['constants']and len(before['constants'])==6;assert len(before['clauses'])==len(after['clauses'])==15
for a,b in zip(before['clauses'],after['clauses']):assert {k:v for k,v in a.items()if k!='witness'}=={k:v for k,v in b.items()if k!='witness'}
assert [(r['id'],r['reason'])for r in before['outliers']]==[(r['id'],r['reason'])for r in after['outliers']]and len(after['outliers'])==19
outlier=next(i for i,r in enumerate(before['outliers'])if r['id']=='chicago_lighthouse_1832');assert before['outliers'][outlier]['street']is after['outliers'][outlier]['street']is None;assert before['outliers'][outlier]['setback_m']==317.96 and after['outliers'][outlier]['setback_m']==319.7
allowed={f'/outliers/{outlier}/setback_m',f'/outliers/{outlier}/measured/0'}|{f'/clauses/{i}/witness/setback_m_max'for i,c in enumerate(before['clauses'])if 'chicago_lighthouse_1832'in c['evidence']};assert diff and all(r['pointer']in allowed for r in diff),diff
(O/'PLACEMENT-BEFORE.json').write_text(json.dumps(before,indent=2,ensure_ascii=False)+'\n');(O/'PLACEMENT-EXPECTED.json').write_text(json.dumps(after,indent=2,ensure_ascii=False)+'\n');proof={'status':'PASS_ACTUAL_UNCHANGED_NATIVE_POLICY_EXACT_BASELINE_AND_NARROW_OUTLINE_PREDICTION','source_code_sha256':hashlib.sha256((A/'tools/placement_policy_1835.py').read_bytes()).hexdigest(),'cohort_records':len(records),'full_baseline_JSON_reproduced_exact':True,'only_one_input_polygon_changed':True,'world_center_position_bearing_dates_unchanged':True,'constants6_exact':True,'clauses15_authored_exact':True,'outlier19_ids_reasons_exact':True,'nearest_street_stays_null':True,'exact_JSON_pointer_deltas':diff,'population_guard':'Other25protectedfiles must remain byteexact in actual future native run. Policy file allowed ONLY this exact complete native predicted JSON, never a blanket exemption.','scope':'Read-only prediction; not canonical writer/app/asset acceptance.'};(O/'PLACEMENT-PROOF.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
