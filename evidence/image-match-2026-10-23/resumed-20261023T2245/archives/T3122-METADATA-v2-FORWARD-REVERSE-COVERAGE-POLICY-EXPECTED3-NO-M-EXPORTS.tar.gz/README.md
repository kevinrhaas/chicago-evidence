# Corrected lighthouse admission and exact placement measurement prediction

This new packet preserves the earlier frozen proposal as history. The categorical
lantern_profile field remains inferred. Its invalid new Covers token is removed;
the five reconstructed metric controls retain their Covers and the lighthouse
subject association remains reachable. Actual unchanged native parsing plus
forward AND reverse coverage pass on the nine actual new field blocks: eight
reconstructed values are owed admissions, while the inferred category is not.
The old erroneous Covers claim is a negative control that the native reverse
validator rejects. This is a bounded field-projection proof, not a full dataset
schema, geometry, app or native-writer acceptance. The initial fixture header
Active was rejected; the reproduction uses the actual Per-subject liberties
section without relaxing the parser.

The unchanged native placement-policy builder exactly reproduces the entire
source-base policy from its 100 documented cohort records. Changing only the
lighthouse outline preserves its world centre and position but moves measured
nearest-corridor distance from 317.96 to 319.70 metres. Exactly three JSON
pointers change: the institutional witness maximum, the lighthouse outlier's
numeric setback, and the same figure in its diagnostic text. All six constants,
15 authored clauses, 19 outlier IDs/reasons and nearest-street absence remain
exact. The future native policy output must equal PLACEMENT-EXPECTED.json in
full; do not exempt the policy file. The other 25 protected population files
must stay byte exact against the actual incoming-source baseline.

Normal incoming Abb/Ames integration preserves its K01 code, data, assets and
audit workbook. Incoming fort producer/params/entrances and 25 rows were proven
identical to 7a; the registry union retains all incoming other rows and the
previously genuine Sroof rows. Three registered generated conflicts remain
unaccepted placeholders pending actual writers after the bridge lease.

The corrected selective M overlay is authored on the owner's branch, with the
old repaired gallery, beam, facade and positional API preserved. Focused CPU
API/outline/none-flat/canopy checks pass. All 25 current fort recipes are now
intentionally stale and require genuine exports. No M export, publisher, app,
full gate, image match, PR readiness or dev delivery follows from this packet.
Public checked Sroof checkpoint remains bd316f7f4. The older full proposal/CPU
evidence and all original picture obligations remain unchanged.
