"""Owner-only M overlay after committed roof S. Read-only by default; no asset writes."""
from pathlib import Path
import argparse,ast,difflib,hashlib,json,subprocess,zipfile
O=Path(__file__).resolve().parent;C=O/'closed-light-composed-proposal';R=Path('/tmp/chicago-log-integration');A=R/'chicago/4d';sha=lambda b:hashlib.sha256(b).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--apply',action='store_true');args=ap.parse_args()
assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()=='steward/t3122-t3123-t3124-fort-family-profile-piazza'
status=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
if status.strip():
    proof=json.loads((O/'ABB-LIGHT-INTEGRATION.json').read_bytes())
    assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=R,text=True).strip()==proof['incoming']
    assert set(subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=R,text=True).splitlines())==set(proof['remaining_unmerged'])
    assert len(proof['remaining_unmerged'])==3,'Only registered derived placeholders may remain'
else:
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()

with zipfile.ZipFile(C/'OWNED-SOURCE.zip')as z:
 def held(phase,path):return z.read(phase+'/chicago/4d/'+path)
 expected=json.loads((C/'SOURCE-BINDING.json').read_bytes())
 for row in expected['files']:
  assert sha(z.read('after/'+row['path']))==row['after_sha256']
 source_path='generators/archetypes/fort_structure.py';current=(A/source_path).read_bytes();assert sha(current)=='6c2b7d53ea6e62dbdb61ef331b0ff2ec646e7627b23ef81d16a3d6ea886b5027'
 proposed=held('after',source_path);patch=''.join(difflib.unified_diff(current.decode().splitlines(True),proposed.decode().splitlines(True),fromfile='a/chicago/4d/'+source_path,tofile='b/chicago/4d/'+source_path))
 # Every existing helper except the two reviewed dispatch/tower changes is exact.
 def functions(b):return {n.name:ast.dump(n,include_attributes=False)for n in ast.parse(b).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 old,new=functions(current),functions(proposed)
 for name,value in old.items():
  if name not in('build','_tower'):assert new[name]==value,name
 pending={}
 for path in('generators/archetypes/fort_structure_params.py','data/structures/chicago_lighthouse_1832.json','tools/test_fort_picture_fronts.py'):
  data=(A/path).read_bytes()
  if path=='tools/test_fort_picture_fronts.py':assert sha(data)=='a7510900d0a19a1ba42204d5ee003b41486848c205b9444f73fee2c6cb682e32'
  else:assert data==held('before',path),path
  pending[path]=held('after',path)
 for path in('data/sources/castelnau_1842_chicago_harbor.json','data/sources/assets/chicago_harbor_lighthouse_1838.jpg'):
  assert not(A/path).exists(),path;pending[path]=held('after',path)
 # Append only the reviewed appearance ruling to the actual current register.
 path='data/structure_grades.json';d=json.loads((A/path).read_bytes());b=json.loads(held('before',path));a=json.loads(held('after',path));added=[x for x in a['pictured']if x not in b['pictured']];assert len(added)==1 and added[0]['picture']=='castelnau_1842_chicago_harbor';assert added[0]not in d['pictured'];d['pictured'].extend(added);pending[path]=(json.dumps(d,indent=2,ensure_ascii=False)+'\n').encode()
 # Preserve actual current note-key additions; add only our six admitted keys.
 path='data/reconstruction/name_pool_keys.json';d=json.loads((A/path).read_bytes());before=json.loads(held('before',path));after=json.loads(held('after',path));changes=[]
 def union(cur,b,a,p=()):
  if b==a:return
  if isinstance(b,dict):
   assert set(b)==set(a)
   for k in b:union(cur[k],b[k],a[k],p+(k,))
  elif isinstance(b,list):
   new=[v for v in a if v not in b];assert all(v in a for v in b)and len(new)==6
   assert not any(v in cur for v in new);cur.extend(new);changes.extend(new)
  else:raise AssertionError(('unexpected scalar namepool delta',p))
 union(d,before,after);assert len(changes)==6;pending[path]=(json.dumps(d,indent=2,ensure_ascii=False)+'\n').encode()
 # A newer root/S library tail is kept verbatim. Never restore the old whole file.
 path='docs/LIBERTIES.md';live=(A/path).read_bytes();assert live.startswith(held('before',path));fragment=(O/'M-metadata-correction-v2/LIBERTY-M.fragment.md').read_bytes();assert b'**Subjects:** `chicago_lighthouse_1832`.' in fragment;assert b'**Covers:** `chicago_lighthouse_1832.tower_1832.form.tower_diameter_m`'in fragment;assert b'`chicago_lighthouse_1832.tower_1832.form.lantern_profile`'not in fragment;assert b'L-lighthouse-visible-prototype-2373'not in live;pending[path]=live+fragment
 p=subprocess.run(['git','apply','--check','-'],input=patch.encode(),cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode==0,p.stderr.decode()
 report={'status':'APPLIED_SOURCE_ONLY'if args.apply else'DRY_RUN_GUARDS_PASS','utility':'T-3122','module_before':sha(current),'module_after':sha(proposed),'existing_helpers_except_build_tower_exact':True,'native_assets_written':False,'new_family_bake_required':True,'paths':{k:sha(v)for k,v in pending.items()}}
 if args.apply:
  subprocess.run(['git','apply','-'],input=patch.encode(),cwd=R,check=True)
  assert(A/source_path).read_bytes()==proposed
  for path,data in pending.items():(A/path).parent.mkdir(parents=True,exist_ok=True);(A/path).write_bytes(data)
  (O/'T3122-materialization-v2.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
