from pathlib import Path
import sys,json,hashlib,types,inspect
from unittest.mock import patch
root=Path(sys.argv[1]);out=Path(sys.argv[2]);sys.path.insert(0,str(root/'generators'));sys.modules['bpy']=types.ModuleType('bpy')
from archetypes import frame_tavern as builder
from archetypes.frame_tavern_params import from_phase,FrameTavernParams,ParamError
from common.mesh import MeshBuilder
hashit=lambda v:hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
rows=[]
with patch.object(MeshBuilder,'to_object',lambda b,mats=None:(b,mats)),patch.object(builder,'simple_material',lambda n,*a,**kw:(n,a,kw)):
 for file in sorted((root/'data/structures').glob('*.json')):
  r=json.loads(file.read_text())
  if r.get('archetype')!='frame_tavern':continue
  for ph in r['phases']:
   try:p=from_phase(ph,r);p.validate()
   except (KeyError,ValueError):continue
   mesh,mats=builder.build(p,r['id']+'__'+ph['id']);geometry=(mesh.verts,mesh.faces,mesh.mat_index,mesh.named)
   rows.append({'id':r['id'],'phase':ph['id'],'geometry_sha256':hashit(geometry),'confidence_sha256':hashit(mesh.conf),'all_materials_sha256':hashit(mats),'nonroof_materials_sha256':hashit(mats[:1]+mats[2:]),'roof_material':mats[1],'vertices':len(mesh.verts),'faces':len(mesh.faces)})
 api=[{'name':n,'kind':str(p.kind),'default':str(p.default)} for n,p in inspect.signature(FrameTavernParams).parameters.items()]
out.write_text(json.dumps({'root':str(root),'API':api,'records':rows},indent=2)+'\n');print(len(rows),'frame record-phase streams captured')
