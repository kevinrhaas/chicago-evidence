"""Bounded native producers only. Default/readiness work imports no Blender.

dry: inspect canonical input bindings, without writes or Blender.
bind: freeze the actual settled checkout and before manifests in a new run dir.
masters/web: require the parent's exclusive heavy grant and preserve receipts.
No population/sidecar writer, publisher, gate, browser, commit or PR is run here.
"""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import os
import shutil
import subprocess
import sys

APP = Path('/workspace/chicago/chicago/4d')
REPO = APP.parents[1]
PREP = Path(__file__).resolve().parent
RUNS = Path('/workspace/T3082-official23-runs')
SCRATCH = Path('/workspace/T3082-official23-tmp')
BLENDER = Path('/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender')
TARBALL = Path('/workspace/shared/blender-dl/blender-4.5.3-linux-x64.tar.xz')
PIN_SHA = '975c58fcb244273838534bba771e64ad87739216b0f9b39a888531a49a72d845'
PARENT = '3fa6e0e84f84a33ccb8ac82c4778f6468af3b029'
FOLD = 'ff808a22d50fedf5474d33535748286b71794c8e'
sys.path.insert(0, str(APP / 'generators'))
import mesh_inputs


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def inspect():
    assert git('branch', '--show-current') == 'steward/t3082-tremont-quarter-roof-v2'
    assert git('rev-parse', 'HEAD') == PARENT
    assert git('rev-parse', 'MERGE_HEAD') == FOLD
    proposal = read(Path('/tmp/chicago-next-model/T-2385-deep-roof-proposal-20261023T2250/SOURCE-GUARDS.json'))
    for rel, guard in proposal.items():
        assert sha(REPO / rel) == guard['after_sha256'], ('Authored input drift', rel)
    manifest = read(APP / 'assets/manifest.json')
    rows = {name: row for name, row in manifest['assets'].items()
            if row.get('archetype') == 'frame_tavern'}
    assert len(rows) == 23
    assert sorted(rows) == [r['master'] for r in read(PREP / 'latest23-inventory.json')]
    ids = sorted({row['structure_id'] for row in rows.values()})
    assert len(ids) == 23
    target_date = dt.date.fromisoformat(read(APP / 'data/scenes/1835.json')['target_date'])
    docs = {}
    expected = {}
    for name, row in sorted(rows.items()):
        record = read(APP / 'data/structures' / (row['structure_id'] + '.json'))
        phases = [p for p in record['phases'] if
                  dt.date.fromisoformat(p['documented_range']['from']) <= target_date <=
                  dt.date.fromisoformat(p['documented_range']['to'])]
        assert len(phases) == 1 and phases[0]['id'] == row['phase_id'], name
        docs[name] = mesh_inputs.structure_inputs_doc(record, phases[0], 'frame_tavern')
        expected[name] = mesh_inputs.structure_inputs_sha(record, phases[0], 'frame_tavern')
        assert expected[name] != row['inputs_sha256'], ('Expected old recipe to be stale', name)
        assert not (APP / 'data/structures/versions' / record['id']).exists(), ('Selected version scope', name)
    vm = read(APP / 'assets/manifest.versions.json')
    assert not [r for r in vm['assets'].values() if r.get('structure_id') in ids]
    # Freeze producer code, all structure/version inputs, selected native scene,
    # and actual web producer/helpers. These files must stay exact through both phases.
    inputs = list((APP / 'generators').rglob('*.py'))
    inputs += list((APP / 'data/structures').rglob('*.json'))
    inputs += [APP / rel for rel in ['generators/blender.pin', 'data/datum.json',
               'data/scenes/1835.json', 'tools/web_derivatives.sh', 'tools/ktx2_glb.py',
               'tools/ktx2_sheets.py', 'tools/recover_glessner_v4.py', 'tools/structure_versions.py',
               'renderers/web/js/flags.js', 'renderers/web/js/flag-anchors.js',
               'data/reconstruction/name_pool_keys.json', 'assets/LICENSES.md',
               'data/sources/gifford_tremont_house_no_1.json']]
    protected = ['assets/manifest.versions.json',
                 'assets/gltf/hogan_store__frame_1832.glb',
                 'assets/web/hogan_store__frame_1832.glb']
    protected += [p.relative_to(APP).as_posix() for p in
                  (APP / 'docs/RESEARCH/glessner-v4-recovery').iterdir() if p.is_file()]
    # Resolve Hogan names from the real manifest instead of assuming a phase label.
    protected = [p for p in protected if (APP / p).exists()]
    for name, row in manifest['assets'].items():
        if row.get('structure_id') == 'hogan_store':
            protected += ['assets/gltf/' + name, 'assets/web/' + name]
    before_files = {p: sha(APP / p) for p in sorted(set(protected))}
    assert 'bpy' not in sys.modules
    return {'head': PARENT, 'merge_head': FOLD, 'ids': ids, 'names': sorted(rows),
            'expected_inputs': expected, 'input_docs': docs,
            'frozen_inputs': {p.relative_to(APP).as_posix(): sha(p) for p in sorted(set(inputs))},
            'protected_files': before_files, 'blender_binary_sha256': sha(BLENDER),
            'blender_pin_tarball_sha256': PIN_SHA,
            'workspace_free_bytes': shutil.disk_usage('/workspace').free,
            'policy': 'Normal official UV/export; no --no-bake or --ao. No sidecar/population writer. No publish/gate/browser/commit.'}


def guards(binding):
    assert git('rev-parse', 'HEAD') == binding['head']
    assert git('rev-parse', 'MERGE_HEAD') == binding['merge_head']
    for section in ('frozen_inputs', 'protected_files'):
        for rel, expected in binding[section].items():
            assert sha(APP / rel) == expected, ('Frozen input/protected drift', rel)
    assert sha(BLENDER) == binding['blender_binary_sha256']


ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('phase', choices=['dry', 'bind', 'masters', 'web'])
ap.add_argument('--run-id')
ap.add_argument('--root-heavy-granted', action='store_true')
args = ap.parse_args()
if args.phase == 'dry':
    binding = inspect()
    print(json.dumps({'status': 'PASS LIGHT dry; no Blender/subprocess producer',
                      'head': binding['head'], 'merge_head': binding['merge_head'],
                      'actual_count': len(binding['names']), 'ids': binding['ids'],
                      'frozen_file_count': len(binding['frozen_inputs']),
                      'protected_file_count': len(binding['protected_files']),
                      'workspace_free_bytes': binding['workspace_free_bytes'],
                      'tmpdir': str(SCRATCH), 'policy': binding['policy']}, indent=2))
    sys.exit(0)
assert args.run_id and Path(args.run_id).name == args.run_id, 'A plain explicit run ID is required'
run = RUNS / args.run_id
if args.phase == 'bind':
    assert not run.exists(), 'Never overwrite an earlier binding or failure'
    binding = inspect()
    assert binding['workspace_free_bytes'] >= 2 * 1024**3, 'Need 2 GiB free workspace before binding'
    run.mkdir(parents=True)
    for name in ['manifest.json', 'manifest.web.json', 'manifest.versions.json']:
        (run / ('before-' + name)).write_bytes((APP / 'assets' / name).read_bytes())
    write(run / 'binding.json', binding)
    print('Bound actual inputs only:', run)
    sys.exit(0)

assert args.root_heavy_granted, 'Parent exclusive heavy grant is required before producers'
binding = read(run / 'binding.json')
guards(binding)
receipt_path = run / ('official-' + args.phase + '-receipt.json')
assert not receipt_path.exists(), 'Preserve every earlier attempt; do not overwrite'
assert shutil.disk_usage('/workspace').free >= 2 * 1024**3
before_master = read(run / 'before-manifest.json')
before_web = read(run / 'before-manifest.web.json')
names = set(binding['names'])
wrote = run / 'written-masters.txt'
receipt = {'phase': args.phase, 'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
           'status': 'RUNNING', 'head': binding['head'], 'merge_head': binding['merge_head'],
           'expected_names': binding['names'], 'no_sidecar_population_publish_gate_browser_commit': True}
write(receipt_path, receipt)
try:
    SCRATCH.mkdir(parents=True, exist_ok=True)
    env = {**os.environ, 'TMPDIR': str(SCRATCH), 'TMP': str(SCRATCH), 'TEMP': str(SCRATCH),
           'PYTHONDONTWRITEBYTECODE': '1', 'npm_config_cache': '/workspace/shared/npm-cache',
           'PATH': '/workspace/shared/tools/usr/bin:' + os.environ.get('PATH', '')}
    if args.phase == 'masters':
        assert sha(TARBALL) == PIN_SHA, 'Pinned cached archive must verify'
        assert subprocess.check_output([str(BLENDER), '--version'], text=True).splitlines()[0] == 'Blender 4.5.3 LTS'
        argv = [str(BLENDER), '-b', '-noaudio', '--factory-startup', '--python',
                str(APP / 'generators/build.py'), '--', '--only', ','.join(binding['ids']),
                '--scene', '1835', '--wrote', str(wrote)]
    else:
        prior = read(run / 'official-masters-receipt.json')
        assert prior['status'] == 'PASS'
        assert sha(APP / 'assets/manifest.json') == prior['after_master_manifest_sha256']
        assert read(APP / 'assets/manifest.web.json') == before_web
        argv = ['bash', str(APP / 'tools/web_derivatives.sh'), '--only', ','.join(binding['names'])]
    receipt['command'] = argv
    receipt['tmpdir'] = str(SCRATCH)
    write(receipt_path, receipt)
    with (run / ('official-' + args.phase + '.log')).open('w') as log:
        completed = subprocess.run(argv, cwd=APP, env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt['exit_code'] = completed.returncode
    assert completed.returncode == 0, 'Official producer failed; preserved log, stop and investigate'
    written = wrote.read_text().splitlines()
    assert len(written) == 23 and len(set(written)) == 23 and set(written) == names
    guards(binding)
    after_master = read(APP / 'assets/manifest.json')
    assert set(after_master['assets']) == set(before_master['assets'])
    assert {k: v for k, v in after_master['assets'].items() if k not in names} == {
        k: v for k, v in before_master['assets'].items() if k not in names}
    for name in names:
        entry = after_master['assets'][name]
        assert entry['inputs_sha256'] == binding['expected_inputs'][name]
        assert entry['bytes'] == (APP / 'assets/gltf' / name).stat().st_size
        assert entry['baked_ao'] is False
    if args.phase == 'masters':
        assert read(APP / 'assets/manifest.web.json') == before_web
    else:
        after_web = read(APP / 'assets/manifest.web.json')
        assert set(after_web['masters']) == set(before_web['masters'])
        assert {k: v for k, v in after_web['masters'].items() if k not in names} == {
            k: v for k, v in before_web['masters'].items() if k not in names}
        for name in names:
            assert after_web['masters'][name] == sha(APP / 'assets/gltf' / name)
    receipt.update(status='PASS', finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                   after_master_manifest_sha256=sha(APP / 'assets/manifest.json'),
                   output_hashes={name: sha(APP / 'assets' / ('gltf' if args.phase == 'masters' else 'web') / name)
                                  for name in binding['names']},
                   unrelated_manifest_entries_and_protected_inputs_exact=True,
                   limitations='Producer/freshness receipts only. Export stream parity, native picture review and full gates remain separate.')
    write(receipt_path, receipt)
    print(json.dumps(receipt, indent=2))
except BaseException as exc:
    receipt.update(status='FAILED', error=str(exc), finished_utc=dt.datetime.now(dt.timezone.utc).isoformat())
    write(receipt_path, receipt)
    raise
