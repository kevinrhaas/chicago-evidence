# T-3082 latest-base migration and official producer preparation

LIGHT migration and input preparation are complete. No Blender, web producer,
native browser, downstream writer, full gate or code commit ran in this packet.

Canonical owner worktree is `/workspace/chicago`, branch
`steward/t3082-tremont-quarter-roof-v2`. HEAD is
`3fa6e0e84f84a33ccb8ac82c4778f6468af3b029`; the normal uncommitted merge has
MERGE_HEAD `ff808a22d50fedf5474d33535748286b71794c8e`. The previous v1 topic
remains at96ca, and the original parent topic remains at792. No parent PR branch
or lease was touched. The parent's separate log worktree remains outside scope.

Before migration, every old authored byte, the exact staged fold, the sole
untracked entry and all current branch/merge/status information were verified
against the remotely archived f499 packet. Standard `git merge --quit` ended
that merge. Only the nine owned, hashed tracked paths were restored to old HEAD;
the one untracked T-3082 entry was atomically preserved at
`/workspace/T3082-latestbase-migration-held/T-3082.json`. A new v2 topic was then
created from3fa and ff808 merged normally with --no-commit --no-ff. Exactly the
four guarded edits and the original own doc suffixes were applied. The latest
LIBERTIES prefix contains another2,331 bytes and is preserved verbatim.
`MIGRATION-RECEIPT.json` records the whole bounded operation and raw prefix proofs.

T-3082 remains normally claimed, and original T-2385 remains open/claimed and
DIFFERS. The original source attribution, owner-approved project-use rights
limits and all native flag/global wind inputs remain unchanged. The separate
TO105.6 flag pose remains unadopted research.

`CURRENT23-DEFAULT-PARITY.json` compares actual current CPU streams to the old
before proof: all23 current geometry/confidence/nonroof streams, all22 current
non-target full material streams, and constructor names/kinds/defaults remain
exact. Only Tremont roof material changes. The raw test also includes the extra
Sauganash log_1829 case, which is not a24th current master. This is CPU evidence;
actual official export/UV parity remains to be inspected after the real build.

`run_official23.py dry` passed without importing bpy or starting Blender. The
actual binding is at
`/workspace/T3082-official23-runs/T3082-3fa-ff808-official23-001` and is copied
under `bound-inputs/` here for checkpointing. It freezes1,106 producer/input files,
25 protected paths (including Hogan assets, Glessner package and versions
manifest), native recipe docs, exact23IDs/names, old manifests and cached Blender
binary hash. No selected structure version exists; every selected phase resolves
at1835-07-01. All23 recipe stamps are correctly stale before the official refresh.

The runner's masters phase verifies the pinned archive hash and Blender4.5.3LTS,
uses an absolute official build.py path, normal UV/export, scene1835 and exact
23IDs. Its web phase requires a successful masters receipt and calls only the
native selected derivative path. Each phase refuses frozen input/protected-file
drift, unexpected wrote-list scope, unrelated registry changes, stale recipe
stamps or overwritten earlier receipts. Export-stream/picture acceptance is not
inferred from successful producer receipts.

After the parent explicitly grants the exclusive heavy slot, run sequentially:

```bash
python3 /tmp/chicago-next-model/T-3082-official23-prep-3fa-20261024/run_official23.py masters --run-id T3082-3fa-ff808-official23-001 --root-heavy-granted
python3 /tmp/chicago-next-model/T-3082-official23-prep-3fa-20261024/run_official23.py web --run-id T3082-3fa-ff808-official23-001 --root-heavy-granted
```

The second command depends on the first passing. Stop on any failure and preserve
its receipt/log; no assertion relaxation or substitution of old exports follows.
The runner does not publish, materialize Glessner, run population/sidecar writers,
launch browser QA, run gates, commit, open a PR or merge. Those are separately
scheduled after the actual output is reviewed and checkpoints are closed.

Both producer phases place scratch data at `/workspace/T3082-official23-tmp` and
receipts under `/workspace/T3082-official23-runs/`, use the shared npm cache and
include `/workspace/shared/tools/usr/bin` in PATH. At preparation time workspace
had4.83GB free and /tmp only1.01GB; the runner requires at least2GiB workspace
free before binding/execution. No existing scratch contents are deleted.

The three old Glessner outputs are still safely held at
`/workspace/T3082-glessner-old-cache-held`, all258,999,416 bytes exact to the792
package. Current17ac package parts are verified; its canonical ignored outputs
remain absent until separately authorized materialization. The selected23 web
command does not select Glessner and does not recover/repack its assets. Future
native publication will use the new package after verification, retaining the
old held bytes.

Preceding authored checkpoint and exact claim are durable in private evidence:
https://github.com/kevinrhaas/chicago-evidence/blob/f917d665e3077ebc4bf992e758b5cf11047c2832/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md
