from pathlib import Path
import json,hashlib,shutil,datetime
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');prior=Path('/workspace/T2375-native-v3-rakers-platforms-20261029');V=Path('/tmp/dearborn-piled-platform-v4-20261029/candidate/chicago/4d');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for d in ['inputs/candidate','inputs/records','candidate/tools','candidate/assets/gltf','scratch','photo']:(P/d).mkdir(parents=True,exist_ok=True)
old=json.loads((prior/'INPUTS.json').read_text());family=[]
for name in ['bridge_timber.py','bridge_timber_params.py']:shutil.copyfile(V/'generators/archetypes'/name,P/'inputs/candidate'/name)
shutil.copyfile(V/'data/structures/dearborn_street_drawbridge.json',P/'inputs/candidate/dearborn_street_drawbridge.json')
for e in old['family']:
 e=e.copy();f=A/'data/structures'/(e['id']+'.json');assert sha(f)==e['record_sha256'];dest=P/'inputs/records'/f.name;shutil.copyfile(f,dest);e['record']=str(dest);assert sha(Path(e['old_actual_export_control']))==e['current_master_sha256'];assert sha(Path(e['current_master']))==e['current_master_sha256'];family.append(e)
for rel in ['tools/web_derivatives.sh','tools/web_derivative_baseline.json','tools/structure_versions.py']:shutil.copyfile(A/rel,P/'candidate'/rel)
bindings={p:sha(Path(p)) for p in old['producer_current_bindings']}
(P/'INPUTS.json').write_text(json.dumps({'prepared_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PREPARED_ROOT_GRANTED','family':family,'producer_current_bindings':bindings,'packet_input_bindings':{str(f.relative_to(P)):sha(f) for f in (P/'inputs').rglob('*') if f.is_file()},'old_native_control_proof':old['old_native_control_proof'],'old_native_control_proof_sha256':old['old_native_control_proof_sha256'],'scope':'7newexports6defaultcontrols+v4selected, nativeWEB/samecamera, no canonical adoption'},indent=2)+'\n')
s=(prior/'run_native.py').read_text().replace('NATIVE_V3_EXPORT','NATIVE_V4_EXPORT');(P/'run_native.py').write_text(s)
(P/'ROOT-CPU-GRANT.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'by':'root message','scope':'finite v4native/Web/photoNOW max2CPU affinity3,4; rootfullgatev2notstarted; allresourcesback~2min; no canonicaladoptionclaim'})+'\n')
root=P/'photo-root/chicago/4d';root.mkdir(parents=True)
for name,target in [('tools',A/'tools'),('renderers',A/'renderers'),('node_modules',Path('/workspace/chicago/node_modules'))]:(root/name).symlink_to(target)
(root/'assets/gltf').mkdir(parents=True);(root/'assets/gltf/trial.glb').symlink_to(P/'candidate/assets/gltf/dearborn_street_drawbridge__draw_1834.glb')
d=root/'docs/RESEARCH/photo-match/dearborn_street_drawbridge/trial';d.mkdir(parents=True)
camera=A/'docs/RESEARCH/photo-match/dearborn_street_drawbridge/T3126-board-parapets/andreas-provisional-official.json';shutil.copyfile(camera,d/camera.name)
(P/'photo-root/chicago/reference').symlink_to(Path('/workspace/chicago/chicago/reference'))
(P/'PHOTO-INPUTS.json').write_bytes((prior/'PHOTO-INPUTS.json').read_bytes())
print('prepared v4, actual run pending')
