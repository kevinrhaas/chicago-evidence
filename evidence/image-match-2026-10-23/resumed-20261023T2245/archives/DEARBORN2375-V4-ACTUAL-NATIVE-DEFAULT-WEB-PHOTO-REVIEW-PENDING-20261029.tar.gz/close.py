from pathlib import Path
import json,hashlib,struct,math,datetime,shutil,stat
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((P/'INPUTS.json').read_text());native=json.loads((P/'ACTUAL-NATIVE-RESULT.json').read_text())
reapers={}
for name in ['NATIVE','WEB','PHOTO']:
 r=json.loads((P/(name+'-REAPER.json')).read_text());assert r['command_exit']==0 and r['all_children_reaped'];reapers[name]={'seconds':r['observed_unix']-r['started_unix'],'children_reaped':r['reaped_children'],'all_children_reaped':True}
for path,h in inputs['producer_current_bindings'].items():
 f=Path(path);assert sha(f)==h,path;rel=f.relative_to(A);dest=P/'frozen-native-source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
photo=json.loads((P/'PHOTO-INPUTS.json').read_text())
for key in ['camera','photo']:
 f=Path(photo[key]);assert sha(f)==photo[key+'_sha256'];shutil.copyfile(f,P/('source-camera.json'if key=='camera'else'source-photo.png'))
render=next((P/'scratch').rglob('*-render.png'));shutil.copyfile(render,P/'actual-render.png')
master=Path(native['candidate']['path']);assert sha(master)==native['candidate']['sha256'];d=master.read_bytes();jl=struct.unpack_from('<I',d,12)[0];j=json.loads(d[20:20+jl]);bn=d[28+jl:]
points=[]
for mesh in j['meshes']:
 for prim in mesh['primitives']:
  a=j['accessors'][prim['attributes']['POSITION']];v=j['bufferViews'][a['bufferView']];o=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',12)
  pts=[struct.unpack_from('<fff',bn,o+k*stride)for k in range(a['count'])]
  above=[q for q in pts if 20<q[0]<24 and 3<q[1]<3.3]
  points.append({'material':j['materials'][prim['material']]['name'],'all_primitive_positions':len(pts),'actual_rail_region_x20to24_h3to3_3_vertices':len(above),'sample':above[:4]})
assert points[0]['actual_rail_region_x20to24_h3to3_3_vertices']>=36 and points[1]['actual_rail_region_x20to24_h3to3_3_vertices']>=144
record=json.loads((P/'inputs/candidate/dearborn_street_drawbridge.json').read_text());form=record['phases'][0]['form'];assert form['railing']['value']is True and form['railing_kind']['value']=='board'
camera=json.loads((P/'source-camera.json').read_text());u,v,h=camera['eye'];t=math.radians(camera['yaw_deg']);cx,cy=camera['principal_px'];f=camera['focal_px']
def project(x,y,z):
 a,b=x-u,y-v;depth=a*math.sin(t)+b*math.cos(t);assert depth>0
 return [cx+f*(a*math.cos(t)-b*math.sin(t))/depth,cy-f*(z-h)/depth]
railproof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_NATIVE_GLB_CONTAINS_EXISTING_BOARDED_PARAPETS','master_sha256':sha(master),'railing':True,'railing_kind':'board','binary_decoded_primitive_position_counts':points,'projection_scope':'Exact inherited no-pitch diagnostic camera algebra; numerical projection, not a new capture.','front_approach_station53_88':{'deck_height_m':2.22,'front_board_top_m':3.11,'front_cap_top_m':3.17,'deck_point_px':project(53.88,-.15,2.22),'board_top_point_px':project(53.88,-.15,3.11),'cap_top_point_px':project(53.88,-.15,3.17)},'limits':'Existing 0.95m boarded railing is physically present; same material/low viewpoint can make broad panel read like a deck in isolated image. No texture or height changed to address subjective appearance. Actual wholepicture verdict left to direct review.'}
(P/'ACTUAL-RAIL-PRESERVATION.json').write_text(json.dumps(railproof,indent=2)+'\n')
web=P/'candidate/assets/web/dearborn_street_drawbridge__draw_1834.glb';data=web.read_bytes();n=struct.unpack_from('<I',data,12)[0];wj=json.loads(data[20:20+n]);assert 'EXT_meshopt_compression'in wj['extensionsUsed']
unreviewed=P/'photo-root/chicago/4d/docs/RESEARCH/photo-match/dearborn_street_drawbridge/trial/andreas-provisional-official.match.json';shutil.copyfile(unreviewed,P/'NATIVE-UNREVIEWED.match.json')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_V4_NATIVE_WEB_SAMECAMERA_PHOTO_PASS_ROOT_REVIEW_PENDING','six_new_defaults_byte_exact_prior_actual_old_and_current':True,'candidate_master':native['candidate'],'candidate_web':{'path':str(web),'bytes':web.stat().st_size,'sha256':sha(web),'EXT_meshopt_compression':True},'all_reapers':reapers,'all_producer_record_camera_photo_bindings_exact_after_runs':True,'native_board_parapets_physically_present':True,'scope':'UNADOPTED. V4 piledcap correction captured. Native unreviewed match preserved; root directly reviewing. No canonicalclaim/adoption/app/fullgate/originalclosure. CPU/GPU released.'}
(P/'CLOSED-RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
files=[]
for item in sorted(P.rglob('*')):
 if not item.is_file()or item.is_symlink()or item.name=='MANIFEST.json'or 'scratch'in item.relative_to(P).parts:continue
 # Do not traverse or archive linked primary tools/renderers/node_modules.
 if any(p.is_symlink()for p in item.parents if p!=P and P in p.parents):continue
 files.append({'path':str(item.relative_to(P)),'bytes':item.stat().st_size,'sha256':sha(item),'mode':oct(stat.S_IMODE(item.stat().st_mode))})
(P/'MANIFEST.json').write_text(json.dumps({'closed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':result['scope'],'files':files},indent=2)+'\n')
print(json.dumps({'manifest':str(P/'MANIFEST.json'),'sha256':sha(P/'MANIFEST.json'),'files':len(files),'result':result},indent=2))
