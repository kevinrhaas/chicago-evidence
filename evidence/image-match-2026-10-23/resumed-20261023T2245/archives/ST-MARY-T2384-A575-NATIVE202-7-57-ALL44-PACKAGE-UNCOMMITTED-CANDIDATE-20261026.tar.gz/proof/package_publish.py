from pathlib import Path
import os,json,subprocess,hashlib,datetime,time,shutil,re,signal
os.sched_setaffinity(0,{0});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1',TMPDIR='/tmp/sm-n');repo=Path('/tmp/st-mary-picture-20261025');app=repo/'chicago/4d';r=Path('/tmp/st-mary-runtime-20261025');root=Path('/workspace/shared/st-mary-a575-integration-runtime');out=root/'package-publish';assert not out.exists();out.mkdir();load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();floor=536870912;scope=load(root/'all44-scope/RESULT.json');assert not scope['retained_real_semantic_binary_changes']and not scope['protected_population_paths_dirty'];assert load(r/'integrate-a575-all44-scope-status.json')['all_children_reaped'];prep=load(root/'native-resolve-v2/INPUTS.json');family=load(r/'ff-20affa/PREPARED.json')['family542'];GT=load(r/'checked-GT23-snapshot.json');resources=[]
def space(label):
 free=shutil.disk_usage('/tmp').free;resources.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':label,'free_bytes':free});(out/'RESOURCE-OBSERVATIONS.json').write_text(json.dumps(resources,indent=2)+'\n');assert free>=floor,('ROOT_EXTERNAL512MIB_RESERVE_NO_NATIVE_ASSERTION_CHANGE',label,free);return free
def run(name,cmd):
 print(name,'START',datetime.datetime.now(datetime.timezone.utc).isoformat(),'FREE',space(name+' BEFORE'),flush=True);p=subprocess.Popen(cmd,cwd=app,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
 try:
  with(out/(name+'.log')).open('x')as log:
   for line in p.stdout:
    log.write(line);log.flush()
    if re.match(r'^\s*\[\d+/\d+\]',line):
     try:space(name+' '+line.strip())
     except AssertionError:os.killpg(p.pid,signal.SIGTERM);p.wait();raise
  code=p.wait()
 finally:
  if p.poll()is None:os.killpg(p.pid,signal.SIGTERM);p.wait()
 assert code==0,(name,code)
 if name=='native-package5':
  text=(out/(name+'.log')).read_text();assert 'derived layer rebuilt from step 198'in text and 'the last one moved nothing'in text,text[-1200:]
 print(name,'CLOSED_PASS',flush=True)
start=time.monotonic();run('native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']);run('native-final-publish',['bash','tools/publish.sh']);assert all(sha(app/p)==s for p,s in family.items());assert all(sha(repo/p)==v['sha256']for p,v in GT['files46'].items());assert all(sha(repo/p)==s for p,s in prep['authored_inputs_sha256'].items());assert all(sha(repo/z['path'])==z['base_sha256']for z in scope['rows']if z['semantics_equal'])
result={'status':'A575_FULL_NATIVE_RESOLVE_ALL44_PACKAGE5_PUBLISH_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'HEAD':prep['HEAD'],'MERGE_HEAD':prep['MERGE_HEAD'],'seconds_package_publish':round(time.monotonic()-start,3),'actual_full202_plus7_and_tail_fixedpoint_exit0':True,'prior_external_bootstrap_failed_receipt_retained':True,'all542_Mary_assets_exact':True,'all46_GT_assets_exact':True,'all_authored_inputs_and_both_registries_exact':True,'all44_after_restore_exact_actual_a575':True,'canonical_incoming_changelog_exact':sha(app/'renderers/web/js/changelog.js')=='e5eb3d494e369b4db76b1e99f95bdb2d7775b9c3145e96d1eb2edb1390141339','protected_population_dirty':False,'no_new_geometry_bake_export_or_masterhash_changes':True,'tmp_free_after':shutil.disk_usage('/tmp').free,'fresh3questions_and_final_actual_full18_still_pending':True};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
