# Closed first M wholecheck failure and concrete corrections

The first full required-reader check genuinely FAILS2/1065 with384selftests and47sourcepathsunchanged. No commit. Both errors are preserved: newlantern_profile incorrectly retained a rights-unresolved modern corroborating source; squash ancestry retained oldpendingT3105 while incomingAbb alreadyfolded exactv2256. Onlynewprofile source/note corrected to public-domainCastelnau; alloldbankedcitations and rightsbaselineunchanged. OnlyexactfoldedpendingT3105 removed, ownT3122entrypreserved. Neitherassertionchanged.

No producerbyte change (a0bcd0e): one genuine pinnedlighthouse export+nativeweb refreshed its provenance inputs, all50master/web bytesexact toclosedM25. Native61-step affectedtailran2laps tostable, auditall12XML/nonXMLmemberssameactualAbb thenactualincomingbytesrestored; package5stable.341rawguards+955incomingnonfortrows+bothincomingbooks andfullpredictedpolicyJSONPASS. FocusedUNCHANGEDrights/changelogtoolsPASS.

Secondgate SOURCE-BINDING is immutable startupmetadata only. The second fullcheck itself is LIVE/PENDING and is NOT included or accepted here. No app/PR/merge/originalimageacceptance. T3124notadopted. Originals2373/2379/2388 remainOPEN/DIFFERS. Source recovery starts with980703ee checkpoint plus these corrective source/metadata deltas and exactnativeinputs; do not copy researchGLBs or mintstamps.
