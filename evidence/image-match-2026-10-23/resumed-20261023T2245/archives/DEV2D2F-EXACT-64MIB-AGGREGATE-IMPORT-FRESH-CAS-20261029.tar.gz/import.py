from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal,zlib,urllib.request,urllib.parse,struct
os.sched_setaffinity(0,{1});os.nice(19)
B=Path(__file__).parent;C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='c0936cb192873b8c09a747e4ed3d64b3c6f5115c';TIP='2d2f258ec73a90c9946f1b6694a839dff3ee20fc';CAP=64*1024**2;ENVELOPE=CAP;FLOOR=512*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(r,*args,input=None):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:sha(G/n)for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
def indexed(ids):
 wanted=set(ids);found=set();obj=G/'objects'
 for s in wanted:
  if(obj/s[:2]/s[2:]).is_file():found.add(s)
 for idx in(obj/'pack').glob('*.idx'):
  remaining=wanted-found
  if not remaining:break
  with idx.open('rb')as f:
   head=f.read(8);v2=head[:4]==b'\xfftOc';off=8 if v2 else 0
   if v2:assert struct.unpack('>I',head[4:])[0]==2
   f.seek(off);fan=struct.unpack('>256I',f.read(1024));table=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
   for s in remaining:
    key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
    while a<z:
     m=(a+z)//2;f.seek(table+m*stride+delta);value=f.read(20)
     if value<key:a=m+1
     else:z=m
    f.seek(table+a*stride+delta)
    if a<fan[key[0]]and f.read(20)==key:found.add(s)
 return found



TGT=Path('/tmp/chicago-green-tree-integration')
def tgt_snapshot():
 if not TGT.exists():return None
 gd=Path(git(TGT,'rev-parse','--absolute-git-dir').decode().strip())
 return {'HEAD':git(TGT,'rev-parse','HEAD').decode().strip(),'gitdir':str(gd),'metadata':{n:sha(gd/n)for n in ['HEAD','index','MERGE_HEAD','MERGE_MSG']if(gd/n).is_file()},'status_sha256':hashlib.sha256(git(TGT,'status','--porcelain','-z')).hexdigest()}
tgt_before=tgt_snapshot();save('TGT-SOURCE-BEFORE.json',tgt_before)
p=json.loads((B/'PREPARED-PAYLOAD.json').read_text());assert p['old']==OLD and p['tip']==TIP and p['canonical_raw_total']<=CAP
before=snap();save('SOURCE-BEFORE.json',before);assert git(C,'rev-parse','origin/dev').decode().strip()==OLD
remote=api('git/ref/heads/dev');save('REMOTE-BEFORE-IMPORT.json',remote);assert remote['object']['sha']==TIP
packfiles=[]
for name in p['pack_paths']:
 pack=Path(name);assert hashlib.sha1(pack.read_bytes()[:-20]).digest()==pack.read_bytes()[-20:]
 for f in[pack,pack.with_suffix('.idx'),pack.with_suffix('.promisor')]:
  if f.exists()and not(G/'objects/pack'/f.name).exists():packfiles.append(f)
blobrows=list(p['tip_blob_rows'])+[{'sha':obj,'path':r['intermediate_path'],'bytes':r['canonical_bytes'],'payload':r['payload']}for obj,r in p['metadata'].items()if r.get('payload')]
known=indexed([r['sha']for r in blobrows]);newrows=[r for r in blobrows if r['sha']not in known];planned=sum(f.stat().st_blocks*512 for f in packfiles)+sum(Path(r['payload']).stat().st_blocks*512 for r in newrows)
assert planned<=CAP and shutil.disk_usage('/workspace').free>=FLOOR+planned+65536
save('MEASURED-EXACT-ENVELOPE.json',{'canonical_raw_total':p['canonical_raw_total'],'standing_cap':CAP,'encoded_allocation_envelope':planned,'workspace_floor':FLOOR,'source_guard':'FreshHEAD/index/MERGE/config/status/allrefs before/after; expectedoldc093 and freshremotetip2d2f beforewrite/CAS.','scope':'Two separately inspected1904feature+genuinefoldpairs in one aggregateunder64MiBenvelope, authorizedRoot15:39.'})
assert snap()==before
allocated=0;packrows=[]
for f in packfiles:
 dest=G/'objects/pack'/f.name;assert not dest.exists();tmp=dest.with_name('.'+dest.name+'.2d2f-'+str(os.getpid()));shutil.copy2(f,tmp);assert sha(f)==sha(tmp);tmp.rename(dest);allocated+=dest.stat().st_blocks*512;packrows.append({'name':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest)})
save('PACK-IMPORT.json',packrows)
rows=[]
for row in newrows:
 f=Path(row['payload']);enc=f.read_bytes();raw=zlib.decompress(enc);header,data=raw.split(b'\0',1);assert header==b'blob '+str(len(data)).encode()and len(data)==row['bytes']and hashlib.sha1(raw).hexdigest()==row['sha'];dest=G/'objects'/row['sha'][:2]/row['sha'][2:];assert not dest.exists();dest.parent.mkdir(exist_ok=True);tmp=dest.with_name(dest.name+'.2d2f-'+str(os.getpid()));tmp.write_bytes(enc);assert tmp.read_bytes()==enc;tmp.rename(dest);allocated+=dest.stat().st_blocks*512;assert allocated<=planned and shutil.disk_usage('/workspace').free>=FLOOR;rows.append({'path':row['path'],'sha':row['sha'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoded_bytes':len(enc)})
save('BLOB-IMPORT.json',rows)
t=json.loads(Path('/tmp/current-dev-2d2f-readonly-price-20261029/TREE.json').read_text());leaves=[r for r in t['tree']if r['type']!='tree'];allids={r['sha']for r in leaves};assert allids<=indexed(allids),'Neverpromisormissingprobe'
ids=sorted({r['sha']for r in leaves if r['type']=='blob'});checks=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();assert not any(x.endswith(' missing')for x in checks);sizes={r.split()[0]:int(r.split()[2])for r in checks};assert all(sizes[r['sha']]==r['size']for r in leaves if r['type']=='blob');assert git(C,'rev-parse',TIP+'^{tree}').decode().strip()==p['tree']and git(C,'merge-base',OLD,TIP).decode().strip()==OLD
save('ALL-TIP-IDS-AND-SIZES.json',{'entries':len(leaves),'unique_blob_ids':len(ids),'all_sizes_match':True,'new_canonical_blobs_fully_sha1_verified':len(rows),'existing':'ExactindexedobjectIDs+sizes+trustedpriorverification; notfullhistoricalrehash.'});assert snap()==before
assert tgt_snapshot()==tgt_before,'StopbeforeCAS: TGTauthorstatechanged'
remote=api('git/ref/heads/dev');save('REMOTE-BEFORE-CAS.json',remote);cas=remote['object']['sha']==TIP
if cas:git(C,'update-ref','refs/remotes/origin/dev',TIP,OLD)
tgt_after=tgt_snapshot();save('TGT-SOURCE-AFTER.json',tgt_after);assert tgt_after==tgt_before,'TGTauthorstatechanged;doNOTassertqualification'
after=snap();save('SOURCE-AFTER.json',after);assert after['metadata']==before['metadata']and after['HEAD']==before['HEAD']and after['status_sha256']==before['status_sha256'];assert after['refs']==([x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+TIP)for x in before['refs']]if cas else before['refs'])
result={'status':'EXACT_2D2F_TWO_PRICED_PAIRS_IMPORT_FRESH_EXPECTED_OLD_CAS_PASS'if cas else'EXACT_IMMUTABLE_2D2F_AVAILABLE_REMOTE_MOVED_NO_CAS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old':OLD,'tip':TIP,'tree':p['tree'],'new_tip_blobs':len(p['tip_blob_rows']),'intermediate_pending_blobs':len(rows)-len(p['tip_blob_rows']),'canonical_new_raw_bytes':p['canonical_raw_total'],'actual_source_allocated_bytes':allocated,'exact_encoded_allocation_envelope':planned,'standing_cap':CAP,'all_tip_entries':len(leaves),'all_tip_unique_blob_ids_sizes_verified':len(ids),'cached_origin_dev':git(C,'rev-parse','origin/dev').decode().strip(),'fresh_remote_dev':remote['object']['sha'],'source_HEAD_index_config_MERGE_status_unchanged':True,'all_other_refs_unchanged':True,'workspace_free':shutil.disk_usage('/workspace').free,'workspace_floor':FLOOR,'tmp_free':shutil.disk_usage('/tmp').free,'qualification':'AvailabilityONLY. Separatechangedconsumer/defaultaudit suppliedauthors; all454rendererconsumers exceptchangelog/6earlyfamilyproducers/31targetinputs exact. New1904assets/producers/metadata/currentphone requireactualboundedqualification; no datedproof relabeledcurrent.'};save('RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
