# RESTORE BEFORE REUSING THIS WORKTREE — NEVER COMMIT THE ASSET DELETION

ONLY the inactive exact canonical working-copy terrain payload was temporarily retired for storage, under root approval. This is not a historical-model edit. Restore this file before any reuse/build/publication of this old worktree:

/workspace/worktrees/t2373-lighthouse/chicago/4d/assets/gltf/terrain__e1834_harbor_cut.glb

Old HEAD: e5b9a0fbb145545c95079ccc7e7a3e08ffa050a5. Existing index/flags were preserved; one unstaged deletion is intentional. Ten pre-existing WIP files are immutable in checkpoint732 publication0946b2f11851e7ee0a54cdcd61caa8c0e696049c. Do not stage or commit the terrain deletion.

Exact local native blob restore command (stream to ONE owned sibling temporary file, verify, chmod/fsync, then atomically restore ONLY the missing path; no checkout/index update):
GIT_NO_LAZY_FETCH=1 GIT_OPTIONAL_LOCKS=0 git --no-optional-locks -c protocol.allow=never --git-dir=/workspace/chicago/.git cat-file blob 9e56099d72a013ae8a6cac22deab5aabb92d84ef

Immutable public fallback (same blob in current primary3e):
https://raw.githubusercontent.com/kevinrhaas/chicago/3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa/chicago/4d/assets/gltf/terrain__e1834_harbor_cut.glb

Required bytes:30621836; SHA256:6e0ac8f7a527e6ab1a3e4ad0920294b75d0a191c08523200b78603be82b22611; Git blob SHA1:9e56099d72a013ae8a6cac22deab5aabb92d84ef; full Unix mode0600 (Git100644). Originalmtime_ns:1792756793417933361. Shared local object is already materialized; no geometry regeneration or source hardlink coupling. Preserve all existing WIP/configs/ticket link. Confirm caller storage/CPU lease before restoration. Full audit and restore mapping: /workspace/t2373-terrain-master-retirement-proposal-20261030/PROPOSAL.md and /workspace/t2373-terrain-canonical-copy-retirement-20261030/RESTORE-MAP.json.
