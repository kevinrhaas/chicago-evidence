from pathlib import Path
import os,stat,json,hashlib,subprocess,datetime,shutil
P=Path(__file__).resolve().parent;Q=Path('/workspace/t2373-terrain-master-retirement-proposal-20261030');W=Path('/workspace/worktrees/t2373-lighthouse');R=Path('/workspace/chicago');C=R/'.git';G=C/'worktrees/t2373-lighthouse'
F=W/'chicago/4d/assets/gltf/terrain__e1834_harbor_cut.glb';NOTE=W/'RESTORE-RETIRED-TERRAIN.md';OID='9e56099d72a013ae8a6cac22deab5aabb92d84ef';H='6e0ac8f7a527e6ab1a3e4ad0920294b75d0a191c08523200b78603be82b22611'
os.sched_setaffinity(0,{2});os.nice(19);E=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1')
PF=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(root,*a):return subprocess.check_output(['git','--no-optional-locks','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','protocol.allow=never','-C',str(root),*a],env=E)
def ident(p):
 s=p.lstat();return(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
source7=json.loads(Path('/workspace/standalone-phone-memory-v2-controllers-second-fort-20261030/CHECKPOINT-RESULT.json').read_text())['all7_source_sha256'];assert len(source7)==7
def primary():
 out={'HEAD':git(R,'rev-parse','HEAD').decode().strip(),'HEAD_file':PF(C/'HEAD'),'index':PF(C/'index'),'index_semantic':hashlib.sha256(git(R,'ls-files','--stage','-z')).hexdigest(),'index_flags':hashlib.sha256(git(R,'ls-files','-v','-z')).hexdigest(),'config':PF(C/'config'),'refs':hashlib.sha256(git(R,'for-each-ref','--format=%(refname) %(objectname)')).hexdigest(),'status':hashlib.sha256(git(R,'status','--porcelain=v1','-z','--untracked-files=all')).hexdigest(),'source7':{p:PF(R/p)for p in source7}}
 assert out['source7']==source7;return out
before=primary();assert before['HEAD']=='3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa'
a=json.loads((Q/'AUDIT.json').read_text());assert PF(Q/'CLOSED-MANIFEST.json')=='99daf7a4a08ca6fd08df8927491950413065cbb8f49c223bb836034037394fda'
old_index=PF(G/'index');old_HEAD_file=PF(G/'HEAD');assert old_index==a['worktree_index_sha256_unchanged']and old_HEAD_file==a['worktree_HEAD_file_sha256_unchanged']
assert git(W,'rev-parse','HEAD').decode().strip()==a['old_HEAD'];rel=str(F.relative_to(W));assert git(W,'ls-files','--stage','--',rel).decode().strip()==a['old_index_entry'];assert git(W,'ls-tree',a['old_HEAD'],'--',rel).decode().strip()==a['old_HEAD_tree_entry'];assert git(W,'ls-files','-v','--',rel).decode().strip()=='H '+rel
s=F.lstat();assert stat.S_ISREG(s.st_mode)and s.st_nlink==1 and stat.S_IMODE(s.st_mode)==0o600 and s.st_size==30621836 and PF(F)==H
assert git(W,'cat-file','-t',OID).strip()==b'blob'and git(W,'cat-file','-s',OID).strip()==b'30621836'
pack=Path(a['canonical_local_blob']['locations'][0]['pack']);pack_id=ident(pack)
primary_file=R/rel;primary_id=ident(primary_file);assert not primary_file.is_symlink()and primary_id[:2]!=ident(F)[:2]and PF(primary_file)==H
wip=json.loads(Path('/workspace/t2373-single-glb-funding-readonly-20261030/WIP-SOURCE-MANIFEST.json').read_text())['files'];assert len(wip)==10
def verify_wip():
 for r in wip:
  p=Path(r['path']);assert p.stat().st_size==r['bytes']and stat.S_IMODE(p.stat().st_mode)==r['mode']and PF(p)==r['sha256']
verify_wip();old_status=git(W,'status','--porcelain=v1','-z','--untracked-files=all','--ignored=matching');assert not NOTE.exists()and not NOTE.is_symlink()
protected={p:ident(p)for p in [W/'.claude',W/'node_modules',W/'chicago/4d/tickets']}
# Recheck actual exact/ancestor symlink aliases. No private/config/dependency reads.
skip={'.git','node_modules','.claude','.codex','.agents','.aws','.cache','Cache','Caches','Default','GPUCache','ShaderCache','Code Cache','Crashpad','BrowserMetrics'};skiproots={Path('/workspace/shared'),Path('/workspace/b2378p30'),Path('/workspace/b2378l30'),Path('/workspace/b2378a30')};stack=[Path('/workspace')];aliases=[];links=0
while stack:
 d=stack.pop()
 for e in os.scandir(d):
  q=Path(e.path)
  if e.is_symlink():
   links+=1;t=Path(os.path.realpath(q))
   if t==F or(F.is_relative_to(t)and t.is_dir()):aliases.append(str(q))
  elif e.is_dir(follow_symlinks=False)and q not in skiproots and e.name not in skip and not any(x in e.name.lower()for x in ['playwright_chromiumdev_profile','browser-profile','chromium-profile','private-profile']):stack.append(q)
assert not aliases
live=[];unreadable=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 pid=int(p.name)
 for key in ['cwd','exe']:
  try:t=os.readlink(p/key)
  except OSError:continue
  if t==str(W)or t.startswith(str(W)+'/'):live.append((pid,key))
 try:
  if str(W)in(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace'):live.append((pid,'argv'))
 except OSError:pass
 try:fds=list((p/'fd').iterdir())
 except OSError:unreadable.append(pid);continue
 for fd in fds:
  try:t=os.readlink(fd);fs=fd.stat()
  except OSError:continue
  if t==str(F)or t.startswith(str(W)+'/')or(fs.st_dev,fs.st_ino)==(s.st_dev,s.st_ino):live.append((pid,'fd'))
 try:
  if str(W)in(p/'maps').read_text(errors='replace'):live.append((pid,'maps'))
 except OSError:pass
assert not live;assert primary()==before;verify_wip();assert F.lstat().st_ino==s.st_ino and PF(F)==H
note=f'''# RESTORE BEFORE REUSING THIS WORKTREE — NEVER COMMIT THE ASSET DELETION

ONLY the inactive exact canonical working-copy terrain payload was temporarily retired for storage, under root approval. This is not a historical-model edit. Restore this file before any reuse/build/publication of this old worktree:

{F}

Old HEAD: {a['old_HEAD']}. Existing index/flags were preserved; one unstaged deletion is intentional. Ten pre-existing WIP files are immutable in checkpoint732 publication0946b2f11851e7ee0a54cdcd61caa8c0e696049c. Do not stage or commit the terrain deletion.

Exact local native blob restore command (stream to ONE owned sibling temporary file, verify, chmod/fsync, then atomically restore ONLY the missing path; no checkout/index update):
GIT_NO_LAZY_FETCH=1 GIT_OPTIONAL_LOCKS=0 git --no-optional-locks -c protocol.allow=never --git-dir=/workspace/chicago/.git cat-file blob {OID}

Immutable public fallback (same blob in current primary3e):
{a['primary_comparison']['immutable_raw_url']}

Required bytes:30621836; SHA256:{H}; Git blob SHA1:{OID}; full Unix mode0600 (Git100644). Originalmtime_ns:{s.st_mtime_ns}. Shared local object is already materialized; no geometry regeneration or source hardlink coupling. Preserve all existing WIP/configs/ticket link. Confirm caller storage/CPU lease before restoration. Full audit and restore mapping: {Q}/PROPOSAL.md and {P}/RESTORE-MAP.json.
'''
restore={'path':str(F),'old_HEAD':a['old_HEAD'],'old_index_sha256':old_index,'old_HEAD_file_sha256':old_HEAD_file,'blob':OID,'bytes':s.st_size,'sha256':H,'mode':'0o600','Git_mode':'100644','mtime_ns':s.st_mtime_ns,'public_url':a['primary_comparison']['immutable_raw_url'],'local_common_gitdir':str(C),'pack':str(pack),'source7_primary_before':before,'ten_WIP_preserved':wip,'no_aliases':True,'no_live_affected_references':True,'scanned_symlinks':links,'warning_note':str(NOTE)}
(P/'RESTORE-MAP.json').write_text(json.dumps(restore,indent=2)+'\n')
assert primary()==before and PF(G/'index')==old_index and PF(G/'HEAD')==old_HEAD_file
space_before={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']};F.unlink();assert not F.exists()
fd=os.open(NOTE,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w')as out:out.write(note);out.flush();os.fsync(out.fileno())
assert primary()==before and PF(G/'index')==old_index and PF(G/'HEAD')==old_HEAD_file;verify_wip();assert ident(primary_file)==primary_id and PF(primary_file)==H and ident(pack)==pack_id
for p,i in protected.items():assert ident(p)==i
new_status=git(W,'status','--porcelain=v1','-z','--untracked-files=all','--ignored=matching');oldrows=set(old_status.split(b'\0'))-{b''};newrows=set(new_status.split(b'\0'))-{b''};assert newrows-oldrows=={b' D '+rel.encode(),b'?? RESTORE-RETIRED-TERRAIN.md'}and not oldrows-newrows
space_after={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']}
result={'status':'AUTHORIZED_ONLY_OLD_CANONICAL_TERRAIN_COPY_UNLINKED_RESTORE_NOTE_CREATED_ALL_WIP_AND_PRIMARY_GUARDS_EXACT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'removed':str(F),'bytes':s.st_size,'allocated_reclaimed_B':s.st_blocks*512,'workspace_before_B':space_before['/workspace'],'workspace_after_B':space_after['/workspace'],'observed_net_workspace_delta_B':space_after['/workspace']-space_before['/workspace'],'TMP_before_B':space_before['/tmp'],'TMP_after_B':space_after['/tmp'],'warning_note':str(NOTE),'warning_note_sha256':PF(NOTE),'old_index_HEAD_flags_unchanged':True,'all10_WIP_bytes_modes_hashes_exact':True,'old_worktree_status':'existing4modified+6untracked WIP, plus1unstaged canonicalasset deletion and1untracked restore note; ignoredtickets link intact','primary_source7_HEAD_index_semantics_flags_config_refs_status_exact':True,'primary_independent_terrain_and_shared_Gitpack_exact':True,'actual_symlink_aliases':0,'live_affected_FD_cwd_argv_maps':0,'no_other_deletions_source_changes_hardlinks_or_Gitobject_mutations':True,'import_authorized':False,'root_explicit_phase_handshake_required':True}
(P/'RETIRED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
