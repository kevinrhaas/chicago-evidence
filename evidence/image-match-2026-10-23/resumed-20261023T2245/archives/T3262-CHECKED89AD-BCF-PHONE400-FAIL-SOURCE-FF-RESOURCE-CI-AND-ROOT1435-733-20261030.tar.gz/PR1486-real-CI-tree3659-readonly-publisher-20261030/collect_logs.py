from pathlib import Path
from urllib.request import Request,urlopen
import os,json,hashlib,re,io,zipfile,concurrent.futures,importlib.util,datetime
os.sched_setaffinity(0,{2});os.nice(19)
p=Path(__file__).parent;s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);state=json.loads((p/'FRESH-PR-CHECKS-RUNS.json').read_text());checks=state['check_runs']
sha=lambda b:hashlib.sha256(b).hexdigest()
def job(r):
 jid=r['id'];req=Request('https://api.github.com/repos/kevinrhaas/chicago/actions/jobs/'+str(jid)+'/logs',headers={'User-Agent':'Chicago-actual-CI-checkout-tree-readonly','Accept':'application/vnd.github+json','Cache-Control':'no-cache','Pragma':'no-cache'})
 try:
  with urlopen(req,timeout=90)as f:raw=f.read(32*1024*1024+1);assert len(raw)<=32*1024*1024;ctype=f.headers.get('Content-Type');status=f.status
  if raw.startswith(b'PK'):
   with zipfile.ZipFile(io.BytesIO(raw))as z:text='\n'.join(z.read(n).decode(errors='replace')for n in z.namelist()if n.endswith('.txt'))
  else:text=raw.decode(errors='replace')
  lines=text.splitlines();windows=set();checkout=[]
  for i,line in enumerate(lines):
   if any(term in line for term in['git log -1','git checkout','Checking out the ref','HEAD is now at','refs/pull/1486','refs/remotes/pull/1486','--format=%H','git rev-parse','GITHUB_SHA','BASE_SHA']):
    windows.update(range(max(0,i-1),min(len(lines),i+4)))
   if 'git log -1 --format=%H' in line or 'git log -1 --format=%H' in line.replace('"',''):
    for j in range(i+1,min(len(lines),i+5)):
     value=re.sub(r'^\S+Z\s+','',lines[j]).strip()
     if re.fullmatch('[0-9a-f]{40}',value):checkout.append({'sha':value,'command_line_number':i+1,'command_line':line,'value_line_number':j+1,'value_line':lines[j]});break
  excerpts=[{'line':i+1,'text':lines[i]}for i in sorted(windows)]
  return {'job_id':jid,'check_name':r['name'],'check_conclusion':r['conclusion'],'check_head_sha':r['head_sha'],'job_url':r['details_url'],'HTTP_status':status,'content_type':ctype,'raw_log_bytes':len(raw),'raw_log_sha256':sha(raw),'raw_log_line_count':len(lines),'actual_full_checkout_SHA_from_git_log_command':checkout,'excerpts':excerpts}
 except Exception as e:return {'job_id':jid,'check_name':r['name'],'read_error':str(e),'not_a_product_failure':True}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:logs=list(ex.map(job,checks))
(p/'ACTUAL-JOB-CHECKOUT-LOG-PROOF.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'jobs':logs,'logs_streamed_RAM_only_no_largeexports':True},indent=2)+'\n')
ids={x['sha']for r in logs for x in r.get('actual_full_checkout_SHA_from_git_log_command',[])}|{state['PR']['merge_commit_sha'],state['fresh_dev']['sha']}
def commit(s):return s,m.api('git/commits/'+s)
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:commits=dict(ex.map(commit,ids))
small={s:{'sha':j['sha'],'tree':j['tree']['sha'],'parents':[r['sha']for r in j['parents']],'message':j['message'].splitlines()[0],'url':j['url'],'tree_matches_local3659':j['tree']['sha']=='36590ee4e51d8970ebcb25608f36e7a7bf217912'}for s,j in commits.items()}
(p/'ACTUAL-CHECKOUT-GITDATA-TREES.json').write_text(json.dumps(small,indent=2)+'\n');print('JOBS',[(r['check_name'],r.get('actual_full_checkout_SHA_from_git_log_command'),r.get('read_error'))for r in logs]);print('TREES',json.dumps(small,indent=2))
