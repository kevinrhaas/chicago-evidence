from pathlib import Path
from urllib.request import Request,urlopen
import os,json,hashlib,re,concurrent.futures,importlib.util,time,datetime
os.sched_setaffinity(0,{2});os.nice(19)
p=Path(__file__).parent;s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def compare():
 j=m.api('compare/bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9...2378484c31b91a1b8d28fd8430d2b4d1a783bdaa');out={'base':'bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9','tip':'2378484c31b91a1b8d28fd8430d2b4d1a783bdaa','merge_base':j['merge_base_commit']['sha'],'ahead':j['ahead_by'],'behind':j['behind_by'],'total_commits':j['total_commits'],'commits':[{'sha':c['sha'],'parents':[r['sha']for r in c['parents']],'subject':c['commit']['message'].splitlines()[0]}for c in j['commits']],'files':[{'path':r['filename'],'status':r['status'],'blob':r['sha'],'additions':r['additions'],'deletions':r['deletions']}for r in j['files']],'runtime_patches':{r['filename']:r.get('patch')for r in j['files']if r['filename'].endswith(('assets/manifest.json','assets/manifest.web.json'))}}
 (p/'TINY-BCF-TO2378484-DELTA.json').write_text(json.dumps(out,indent=2)+'\n');return out

def gate():
 url='https://api.github.com/repos/kevinrhaas/chicago/actions/jobs/124084329914/logs?codex_read='+str(time.time_ns())
 try:
  with urlopen(Request(url,headers={'User-Agent':'Chicago-real-CI-tree-gate-one-readretry','Cache-Control':'no-cache','Pragma':'no-cache','Accept':'application/vnd.github+json'}),timeout=90)as f:raw=f.read(32*1024**2+1);assert len(raw)<=32*1024**2
  lines=raw.decode(errors='replace').splitlines();proof=[];excerpts=[]
  for i,line in enumerate(lines):
   if 'git log -1 --format=%H'in line:
    for k in range(i+1,min(len(lines),i+5)):
     val=re.sub(r'^\S+Z\s+','',lines[k]).strip()
     if re.fullmatch('[0-9a-f]{40}',val):proof.append({'sha':val,'command_line':line,'command_line_number':i+1,'value_line':lines[k],'value_line_number':k+1});excerpts+=lines[max(0,i-2):min(len(lines),k+3)];break
  out={'status':'ONE_READONLY_GATE_LOG_RETRY_SUCCESS_NOT_A_CI_RERUN','job_id':124084329914,'job_url':'https://github.com/kevinrhaas/chicago/actions/runs/41062157728/job/124084329914','raw_log_bytes':len(raw),'raw_log_sha256':hashlib.sha256(raw).hexdigest(),'checkout_git_log_proof':proof,'excerpts':excerpts,'first_HTTP503_read_error_retained':'ACTUAL-JOB-CHECKOUT-LOG-PROOF.json','no_dispatch_or_retry_job':True}
 except Exception as e:out={'status':'ONE_READONLY_GATE_LOG_RETRY_UNREAD','error':str(e),'not_product_fail':True}
 (p/'GATE-LOG-ONE-READRETRY-PROOF.json').write_text(json.dumps(out,indent=2)+'\n');return out
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:
 a=ex.submit(compare);b=ex.submit(gate);print('COMPARE',json.dumps(a.result(),indent=2));print('GATE',json.dumps(b.result(),indent=2))
