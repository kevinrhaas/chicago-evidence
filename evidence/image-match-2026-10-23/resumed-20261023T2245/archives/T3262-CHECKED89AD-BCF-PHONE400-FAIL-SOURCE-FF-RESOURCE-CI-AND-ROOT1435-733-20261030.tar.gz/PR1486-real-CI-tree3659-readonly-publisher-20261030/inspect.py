from pathlib import Path
import os,json,importlib.util,concurrent.futures,time,datetime
os.sched_setaffinity(0,{2});os.nice(19)
p=Path(__file__).parent;s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
head='3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa';qs={'pr':'pulls/1486?codex_read='+str(time.time_ns()),'merge_ref':'git/ref/pull/1486/merge?codex_read='+str(time.time_ns()),'checks':'commits/'+head+'/check-runs?per_page=100','runs':'actions/runs?head_sha='+head+'&per_page=100','dev':'git/ref/heads/dev?codex_read='+str(time.time_ns())}
def f(z):
 n,q=z;return n,m.api(q,missing=n=='merge_ref')
with concurrent.futures.ThreadPoolExecutor(max_workers=5)as ex:j=dict(ex.map(f,qs.items()))
pr=j['pr'];out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'PR':{k:pr[k]for k in ['number','html_url','draft','mergeable','mergeable_state','merge_commit_sha']},'head':{'sha':pr['head']['sha'],'ref':pr['head']['ref']},'base':{'sha':pr['base']['sha'],'ref':pr['base']['ref']},'fresh_dev':j['dev']['object'],'test_merge_ref':j['merge_ref'],'check_runs':[{k:r.get(k)for k in['id','name','status','conclusion','head_sha','details_url','html_url','started_at','completed_at','check_suite']}for r in j['checks']['check_runs']],'workflow_runs':[{k:r.get(k)for k in ['id','name','path','event','status','conclusion','head_sha','head_branch','run_attempt','created_at','updated_at','html_url','check_suite_id','pull_requests']}for r in j['runs']['workflow_runs']]}
(p/'FRESH-PR-CHECKS-RUNS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
