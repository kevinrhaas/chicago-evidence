from pathlib import Path
import sys,json,re,hashlib,datetime,os,stat,shutil
S=Path('/workspace/T3262-currentdev-bcf-integration-controllers-secondfort-20261030');sys.path.insert(0,str(S));import common as C
O=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();assert not(S/'GATE-RESULT.json').exists()
b=json.loads((S/'GATE-BINDING.json').read_bytes());rawresult=json.loads((S/'NATIVE-SOURCE-RESULT-BEFORE-RESOURCE-RECHECK.json').read_bytes());rp=json.loads((S/'check-REAPER.json').read_bytes())
assert rawresult['native_source_pass']and rawresult['exit']==0 and all(rawresult['guards'].values())and rp['command_exit']==0 and rp['all_children_reaped']and not rp['leftover_cleanup']
assert b['head']=='3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa'and b['merge_parent']=='bcf92524e404dbb4f441d1d8d5c4ab9e3303d4b9'and b['checked_final_staged_tree']=='36590ee4e51d8970ebcb25608f36e7a7bf217912'
cli=(C.A/'tools/ticket.mjs').read_bytes();variant=cli.replace(b'#!/usr/bin/env node\n',b"#!/usr/bin/env node\nif (!process.argv.includes('--status')) process.exit(0);\n",1);expected={'merge-smoke-state.mjs','merge-generated.mjs','merge-changelog.mjs','merge-queue.mjs','lock/tools/ticket.mjs'};rows=[]
for p in Path('/tmp').iterdir():
 if not re.fullmatch(r'tmp\.[A-Za-z0-9]{10}',p.name)or not p.is_dir()or not(rp['started_unix']<=p.stat().st_mtime<=rp['observed_unix']):continue
 allpaths=list(p.rglob('*'));files=[f for f in allpaths if f.is_file()]
 if {str(f.relative_to(p))for f in files}!=expected or any(f.is_symlink()for f in allpaths):continue
 if(p/'lock/tools/ticket.mjs').read_bytes()!=variant or any((p/n).stat().st_size for n in expected-{'lock/tools/ticket.mjs'}):continue
 assert all(f.stat().st_uid==os.geteuid()and f.stat().st_nlink==1 for f in files)
 rows.append({'root':str(p),'root_mode':stat.S_IMODE(p.stat().st_mode),'files':[{'relative':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes()),'mode':stat.S_IMODE(f.stat().st_mode),'allocated':f.stat().st_blocks*512}for f in files],'dirs':[{'relative':str(f.relative_to(p)),'mode':stat.S_IMODE(f.stat().st_mode)}for f in allpaths if f.is_dir()]})
assert len(rows)==5,len(rows);roots=[Path(r['root'])for r in rows];fds=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  for fd in(proc/'fd').iterdir():
   try:
    p=Path(os.readlink(fd))
    if any(p==r or p.is_relative_to(r)for r in roots):fds.append(str(fd))
   except OSError:pass
 except OSError:pass
assert not fds
C.exact(b['all_staged_paths']);C.exact(b['all7_source_sha256']);assert C.refs()==b['all_refs_before']and C.index()==b['index_semantics'];tmp_before=shutil.disk_usage('/tmp').free
restore={'status':'FIVE_EXACT_OWN_CLOSED_NATIVE_GATE_SYNTHETIC_DRIVER_FIXTURES','native_reaper':str(S/'check-REAPER.json'),'rows':rows,'zero_candidate_FDs':True,'native_cli_sha256':sha(cli),'public_cli':'https://raw.githubusercontent.com/kevinrhaas/chicago/3e0001b9ef061b9fb2a0ee293b734b2c7a99c6fa/chicago/4d/tools/ticket.mjs','variant_rule':"Add documented status-only test shim after shebang (test_pr_lap_lock.mjs:267); other four files empty; restore directories/modes from rows.",'no_privatecache_source_model_or_other_tmp_deletion':True};(O/'BCF-OWN-TMP-FIXTURE-RESTORE.json').write_text(json.dumps(restore,indent=2)+'\n')
for p in roots:shutil.rmtree(p)
C.floors();guards=dict(HEAD=C.g('rev-parse','HEAD').decode().strip()==b['head'],MERGE_HEAD=C.g('rev-parse','MERGE_HEAD').decode().strip()==b['merge_parent'],cached_origin_dev=C.g('rev-parse','origin/dev').decode().strip()==b['merge_parent'],staged_tree=C.g('write-tree').decode().strip()==b['checked_final_staged_tree'],tracked_working_bytes=not C.g('diff','--name-only'),no_untracked=not C.g('ls-files','--others','--exclude-standard'),no_conflicts=not C.g('ls-files','-u'),staged_path_sha256=all(C.path_sha(p)==v for p,v in b['all_staged_paths'].items()),source_hashes=all(C.path_sha(p)==v for p,v in b['all7_source_sha256'].items()),all_refs_exact=C.refs()==b['all_refs_before'],index_semantics_exact=C.index()==b['index_semantics'],config_exact=sha((C.R/'.git/config').read_bytes())==b['source_config_sha256'],protected_own5_exact=all(C.path_sha(p)==C.BASE['own3e_sha256'][p]for p in C.BASE['own_exact5']),own_docs_composed=C.docs_compose()==b['own_document_composition'],incoming_authoritative=set(C.g('diff','--name-only',b['merge_parent']).decode().splitlines())==set(C.BASE['own7_paths']),all_children_reaped=rp['all_children_reaped']);assert all(guards.values())
log=(S/'check.log').read_text();clean=re.sub(r'\x1b\[[0-9;]*m','',log);assert re.search(r'^CHECK PASS — 1105 steps, none red\.$',clean,re.M)
incident={'initial_controller_exit':1,'reason':'Native source1105 passed/all16guards true; final caller TMPfloor only asserted. Exact five owned closed unit-test driver fixtures retired with0FDs/public reconstruction map; same source/merge/index/config/refs/tree reverified, no test rerun/floor change.','TMP_at_halt':tmp_before,'TMP_after_cleanup':shutil.disk_usage('/tmp').free,'caller_floor':1800000000,'retired_only_roots':[str(p)for p in roots],'restore':str(O/'BCF-OWN-TMP-FIXTURE-RESTORE.json'),'no_source_or_Git_mutation':True};(O/'BCF-CONTROLLER-RESOURCE-HALT-AND-RECOVERY.json').write_text(json.dumps(incident,indent=2)+'\n')
result=dict(status='ACTUAL_T3262_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_PASS',revision='CURRENTDEV_BCF',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=0,seconds=rp['observed_unix']-rp['started_unix'],binding=b,guards=guards,config_unchanged=guards['config_exact'],footer=log.splitlines()[-15:],step=dict(name='check',command=['bash','tools/check.sh'],exit=0,seconds=rp['observed_unix']-rp['started_unix'],all_children_reaped=True),original_controller_resource_halt_recovered=incident,native_check_was_not_rerun=True,phone_commit_PR_CI_merge_pending=True)
(S/'GATE-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'native_seconds':result['seconds'],'all16guards':all(guards.values()),'TMPrestored':incident['TMP_after_cleanup'],'source_unchanged_no_test_rerun':True},indent=2))
