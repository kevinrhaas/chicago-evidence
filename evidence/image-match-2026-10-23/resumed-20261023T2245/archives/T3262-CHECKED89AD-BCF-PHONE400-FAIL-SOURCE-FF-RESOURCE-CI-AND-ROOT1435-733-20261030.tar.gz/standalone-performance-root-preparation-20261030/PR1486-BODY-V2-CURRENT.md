Reduce memory used by the 1904 railway yard within the existing 400 MiB phone limit. The renderer uses the existing compact-normal encoding, omits only exact shared uniform ground grades, releases unused initial upload bookkeeping, and keeps unreached tie transforms in a smaller lossless CPU cache. Reaching those ties installs identical Float32 matrix/colour buffers; unusual transforms retain the full layout.

Positions, materials, evidence grades, picking and draw reaches are preserved. Normal encoding retains its existing precision bounds. This addresses the owner-reported phone memory problem and supports the picture changes in PR1456; only T-3262 closes here. T-2373, T-2377, T-2381 and T-2384 remain on PR1456.

Validation on published native head `3e0001b9` (tree `a3bc0f12`, scene data from dev `9117b226`):

- All 1,105 source checks and PR-event questions passed; 434 focused geometry/lifecycle/cache checks passed. Source, index, config, ref and reaper guards passed.
- Official complete 1904 mobile measurement passed at **396.592 MiB / 400**, with zero page errors. The earlier head measured **400.199 MiB, FAIL**. The revision removes 3.61 MiB total; GPU buffer/texture/renderbuffer allocations are unchanged.
- A genuine merge with current dev `bcf92524`, including the newly detailed Field house, is undergoing a fresh source check. Its phone reading, published desktop/mobile qualification and required exact-head CI remain pending. The 396.592 MiB result does not qualify that enlarged scene.

This is the visible-progress exception for the owner-reported memory issue and a gate blocking the original picture parcel. No historical models, sources, image-match decisions, memory limit or measurement assertion change through this PR.

Checked source, raw pass/failure evidence, resource recovery, renewals and all older lighthouse WIP files are preserved in [checkpoint732](https://github.com/kevinrhaas/chicago-evidence/blob/cadbae3bb8780ae24e8438393cdd0697fa0b9f61/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md). Normal PR into dev; not cleared to merge until current integration qualification finishes.
