"""Two normal stage14 dispatches. Never run without the parent's exact-head authorization."""
import argparse, pathlib, subprocess, json, datetime, time, re
P=pathlib.Path(__file__).resolve().parent
BRANCH='steward/t3081-log-picture-controls-v4'
BASE='repos/kevinrhaas/chicago/'
ENDPOINT=BASE+'actions/workflows/chicago-4d-smoke.yml'
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--head',required=True)
ap.add_argument('--authorized-head',required=True,help='Only pass after the parent explicitly authorizes this exact public head')
a=ap.parse_args()
assert re.fullmatch('[0-9a-f]{40}',a.head) and a.authorized_head==a.head
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def get(path):
    q=subprocess.run(['gh','api','--method','GET',path],capture_output=True,text=True)
    if q.returncode:raise RuntimeError(q.stderr[-800:])
    return json.loads(q.stdout)
def refs():
    pr=get(BASE+'pulls/1260');ref=get(BASE+'git/ref/heads/'+BRANCH)
    assert pr['state']=='open' and not pr['merged'] and pr['head']['sha']==a.head and pr['head']['ref']==BRANCH and ref['object']['sha']==a.head, 'Public PR/ref changed; no dispatch allowed'
    return {'at':now(),'PR':pr,'ref':ref}
def runs():return [r for r in get(ENDPOINT+'/runs?branch='+BRANCH+'&event=workflow_dispatch&per_page=100')['workflow_runs'] if r['head_sha']==a.head]
with (P/'DISPATCH_OPERATION_STARTED.json').open('x') as f:json.dump({'at':now(),'head':a.head,'authorization':'Parent supplied exact public head and explicit dispatch authorization'},f)
state={'status':'PREPARING','PR':1260,'head':a.head,'branch':BRANCH,'started':now(),'coverage':'Only full stage14 body at desktop and mobile; prior DA18 stays separate','runs':[]}
def save():
    tmp=P/'DISPATCH.tmp';tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(P/'DISPATCH.json')
save()
try:
    state['initial_readback']=refs();seen={r['id'] for r in runs()};assert not seen,'Existing exact-head smoke dispatches; stop instead of duplicating'
    for viewport in ['desktop','mobile']:
        readback=refs();(P/(viewport+'-READBACK_BEFORE.json')).write_text(json.dumps(readback,indent=2)+'\n')
        payload=P/(viewport+'-14.json');assert json.loads(payload.read_text())=={'ref':BRANCH,'inputs':{'viewport':viewport,'stage':'14'}}
        row={'viewport':viewport,'stage':'14','requested':now(),'payload_file':payload.name};state['runs'].append(row);save()
        with (P/(viewport+'-POST_STARTED.json')).open('x') as f:json.dump({'at':now(),'head':a.head,'payload_file':payload.name},f)
        q=subprocess.run(['gh','api','--include','--method','POST',ENDPOINT+'/dispatches','--input',str(payload)],capture_output=True,text=True)
        row['POST_result']={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};save()
        status=re.search(r'^HTTP/\S+\s+(\d+)',q.stdout)
        assert q.returncode==0 and status and status[1]=='204','POST rejected or unknown; never repeat automatically'
        row['dispatch_accepted']=True;save()
        found=[]
        for _ in range(30):
            found=[r for r in runs() if r['id'] not in seen]
            if found:break
            time.sleep(2)
        assert len(found)==1, 'Dispatch cannot be bound uniquely; stop without retry or cancellation'
        run=found[0];assert run['event']=='workflow_dispatch' and run['path']=='.github/workflows/chicago-4d-smoke.yml'
        row.update({'id':run['id'],'url':run['html_url'],'run_number':run['run_number'],'created_at':run['created_at'],'observed_head':run['head_sha']});seen.add(run['id']);save();print(json.dumps(row),flush=True)
    state.update(status='DISPATCHED_NOT_RESULTS',finished=now(),expected_run_count=2);save()
except BaseException as e:
    state.update(status='STOPPED_NO_AUTOMATIC_RETRY',error=str(e),finished=now());save();raise
