Prepared two full stage14 workflow dispatches, one desktop and one mobile, using the unchanged native inputs. No POST or run binding exists at preparation time.

The parent must supply and explicitly authorize the new public H8 head after the full preflight and bounded probe. Only then may dispatch_two.py receive matching --head and --authorized-head values. It verifies PR and branch head before each single POST, preserves acceptance/sentinels, binds one unique exact-head run, and stops on any uncertainty without automatic retry or cancellation.

After its DISPATCH.json reaches DISPATCHED_NOT_RESULTS, periodic_observer.py can start a separate five-minute GET-only watcher. It retains raw source/stage/viewport-bound job transcripts and all head check statuses, including humans. The prior DA full18 and H7 strict humans proofs remain separate; these two runs supply new stage14 validation only.

The lease helper is GET-only. Reclaim is NOT armed. The current root marker f83 expires10:48:34UTC; an explicit parent follow-up after expiry and fresh positive nativeSTALE/exact-own/open-PR checks are prerequisites for any normal CAS. No force, release, timestamp override, labels, claims, merges, source edits or heavy work are performed by preparation.
