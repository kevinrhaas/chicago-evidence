from pathlib import Path
import sys,json,importlib.util,hashlib,time,datetime
import bpy
assert bpy.app.version[:3]==(4,5,3)
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(A/'generators'));import emit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs=json.loads((P/'INPUTS.json').read_text());assert (P/'ROOT-CPU-GRANT.json').is_file(),'No root CPU grant'
for path,h in inputs['producer_current_bindings'].items():assert sha(Path(path))==h,path
for rel,h in inputs['packet_input_bindings'].items():assert sha(P/rel)==h,rel
assert sha(Path(inputs['old_native_control_proof']))==inputs['old_native_control_proof_sha256']
for name in ['bridge_timber_params','bridge_timber']:
 full='archetypes.'+name;spec=importlib.util.spec_from_file_location(full,P/'inputs/candidate'/(name+'.py'));mod=importlib.util.module_from_spec(spec);sys.modules[full]=mod;spec.loader.exec_module(mod)
params=sys.modules['archetypes.bridge_timber_params'];arch=sys.modules['archetypes.bridge_timber'];emit.ARCHETYPES['bridge_timber']=(params.from_phase,arch.build)
rows=[];destdir=P/'newdefault6';destdir.mkdir(exist_ok=True)
for e in inputs['family']:
 assert sha(Path(e['canonical_record']))==e['record_sha256'];assert sha(Path(e['current_master']))==e['current_master_sha256'];assert sha(Path(e['old_actual_export_control']))==e['current_master_sha256']
 r=json.loads(Path(e['record']).read_text());phase=next(p for p in r['phases'] if p['id']==e['phase']);dest=destdir/e['asset'];t=time.monotonic();made=emit.emit_structure(r,phase,'bridge_timber',dest,bake=True,ao=False);assert sha(dest)==e['current_master_sha256'],e['asset'];row={'asset':e['asset'],'sha256':sha(dest),'bytes':dest.stat().st_size,'triangles':made.tris,'seconds':time.monotonic()-t,'exact_prior_actual_old_and_current_master':True};rows.append(row);print(json.dumps(row),flush=True)
r=json.loads((P/'inputs/candidate/dearborn_street_drawbridge.json').read_text());dest=P/'candidate/assets/gltf'/(r['id']+'__'+r['phases'][0]['id']+'.glb');t=time.monotonic();made=emit.emit_structure(r,r['phases'][0],'bridge_timber',dest,bake=True,ao=False)
for path,h in inputs['producer_current_bindings'].items():assert sha(Path(path))==h,path
for e in inputs['family']:assert sha(Path(e['canonical_record']))==e['record_sha256'] and sha(Path(e['current_master']))==e['current_master_sha256']
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'NATIVE_V5_EXPORT_PASS_UNADOPTED','six_new_defaults_exact_old_actual_and_current':rows,'candidate':{'path':str(dest),'sha256':sha(dest),'bytes':dest.stat().st_size,'triangles':made.tris,'seconds':time.monotonic()-t},'current_producer_record_master_bindings_unchanged':True,'WEB':'PENDING','actual_new_photo_app_gate_adoption':'UNRUN'};(P/'ACTUAL-NATIVE-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['candidate']),flush=True)
