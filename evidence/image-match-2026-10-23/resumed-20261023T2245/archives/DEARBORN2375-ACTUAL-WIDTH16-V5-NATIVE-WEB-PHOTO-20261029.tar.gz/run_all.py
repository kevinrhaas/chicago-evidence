from pathlib import Path
import os,json,subprocess,datetime,sys
P=Path(__file__).resolve().parent
grant=P/'ROOT-CPU-GRANT.json';assert grant.is_file(),'Actual root post-gate CPU/GPU grant required'
g=json.loads(grant.read_text());cpus=g.get('cpus',[3,4]);assert len(cpus)==2 and set(cpus)<=set([0,1,3,4])
assert not(P/'ACTUAL-NATIVE-RESULT.json').exists(),'Do not duplicate an actual native run'
E=dict(os.environ,TMPDIR=str(P/'scratch'),GIT_NO_LAZY_FETCH='1')
wrapper=['python3','/workspace/shared/run-with-reaping.py'];lease=['taskset','-c',','.join(map(str,cpus)),'nice','-n','19']
rows=[]
jobs=[('NATIVE',['/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender','-b','-noaudio','--factory-startup','--threads','2','--python-exit-code','1','--python',str(P/'run_native.py')],P),('WEB',['bash',str(P/'candidate/tools/web_derivatives.sh'),'--only','dearborn_street_drawbridge__draw_1834.glb'],P),('PHOTO',['node','tools/photo_match.mjs','docs/RESEARCH/photo-match/dearborn_street_drawbridge/trial/andreas-provisional-official.json','--glb','assets/gltf/trial.glb','--out',str(P/'photo')],P/'photo-root/chicago/4d')]
for label,cmd,cwd in jobs:
 with(P/(label+'.log')).open('x')as f:q=subprocess.run(wrapper+[str(P/(label+'-REAPER.json')),'--']+lease+cmd,cwd=cwd,env=E,stdout=f,stderr=subprocess.STDOUT)
 assert q.returncode==0,(label,q.returncode)
 r=json.loads((P/(label+'-REAPER.json')).read_text());assert r['command_exit']==0 and r['all_children_reaped'];rows.append({'label':label,'seconds':r['observed_unix']-r['started_unix'],'all_children_reaped':True})
 print(json.dumps(rows[-1]),flush=True)
q=subprocess.run(['python3',str(P/'close.py')],cwd=P,env=E,capture_output=True);assert q.returncode==0,q.stderr.decode()
print(q.stdout.decode(),flush=True)
