from pathlib import Path
import os,json,subprocess,hashlib,datetime,shutil,zipfile,xml.etree.ElementTree as ET,gzip
os.sched_setaffinity(0,{2});repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';out=Path('/tmp/T2380-combined-native61-20261026');out.mkdir();env=dict(os.environ);env.pop('CHICAGO_TICKETS_DIR',None);env.update(PYTHONPATH='/workspace/shared/python',NODE_PATH='/workspace/shared/node/node_modules',PATH='/workspace/shared/tools/usr/bin:/workspace/shared/gltf-transform/node_modules/.bin:'+env['PATH'],PW_EXECUTABLE='/usr/bin/chromium',TMPDIR='/tmp/jail-native-tmp',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1');Path(env['TMPDIR']).mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();file_sha=lambda p:sha(p.read_bytes());git=lambda a:subprocess.check_output(['git',*a],cwd=repo,env=env);latest='88c983a2fc8ba107ca36d9346dcbc5c99b488bdf';assert git(['rev-parse','HEAD']).decode().strip()=='cf25a3f2bb653648d25502fe5fab914b8cb29453';assert git(['rev-parse','MERGE_HEAD']).decode().strip()==latest;assert not git(['diff','--name-only','--diff-filter=U']);assert shutil.disk_usage(env['TMPDIR']).free>=2*1024**3
protected={}
for folder in ['data/reconstruction','data/residents','data/structures']:
 for p in(app/folder).rglob('*'):
  if p.is_file():protected[str(p.relative_to(repo))]=file_sha(p)
asset_paths=set()
for folder in ['gltf','web','web_light','web-light','light']:
 d=app/'assets'/folder
 if d.exists():asset_paths.update(p for p in d.rglob('*.glb')if p.is_file())
for p in(app/'assets').glob('manifest*.json'):asset_paths.add(p)
for p in asset_paths:protected[str(p.relative_to(repo))]=file_sha(p)
(out/'PROTECTED-INTEGRATED-BEFORE.json').write_text(json.dumps(protected,indent=2)+'\n');(out/'RUNNING.json').write_text(json.dumps({'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'affinity':sorted(os.sched_getaffinity(0)),'protected_files':len(protected),'asset_files':len(asset_paths),'actual_tmp_free':shutil.disk_usage(env['TMPDIR']).free,'head':'cf25','merge_head':latest,'native_scope':'One owning61 tail+one package5 tail/publish; no bake/GPU/fullgate.'},indent=2)+'\n')
def command(name,cmd):
 assert shutil.disk_usage(env['TMPDIR']).free>=2*1024**3,('TMP_BELOW_2G',name,shutil.disk_usage(env['TMPDIR']).free)
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(out/(name+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'-STATUS.json')).write_text(json.dumps({'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exit_code':p.returncode},indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0,(name,p.returncode)
command('official-glessner-check',['python3','tools/recover_glessner_v4.py','--check'])
command('bootstrap-publish',['bash','tools/publish.sh'])
command('native61',['node','tools/rederive.mjs','--tail','tools/compile_liberties.py'])
changed={k:{'before':v,'after':file_sha(repo/k)}for k,v in protected.items()if file_sha(repo/k)!=v};(out/'PROTECTED-INTEGRATED-AFTER.json').write_text(json.dumps({'count':len(protected),'changed':changed},indent=2)+'\n');assert not changed,changed
# ONE audit of every dirty XLSX/gzip plus every dirty outside4d path versus incoming88.
tracked=git(['ls-files','-z']).decode().strip('\0').split('\0');dirty=set(git(['diff',latest,'--name-only','-z']).decode().strip('\0').split('\0'));targets=sorted(p for p in dirty if p and(p.endswith(('.xlsx','.gz'))or not p.startswith('chicago/4d/')))
def xlsx_members(b):
 import io
 with zipfile.ZipFile(io.BytesIO(b))as z:
  result={}
  for name in z.namelist():
   data=z.read(name)
   if name.endswith(('.xml','.rels')):
    root=ET.fromstring(data)
    if name=='docProps/core.xml':
     for node in list(root):
      if node.tag=='{http://purl.org/dc/terms/}modified':root.remove(node)
    result[name]=ET.canonicalize(ET.tostring(root,encoding='unicode'))
   else:result[name]=data.hex()
  return result
proof=[]
for rel in targets:
 p=repo/rel;now=p.read_bytes();old=git(['show',f'{latest}:{rel}']);exact=now==old;kind='EXACT_BYTES';equal=exact
 if not exact and rel.endswith('.xlsx'):kind='ALL_CANONICAL_ZIP_MEMBERS_EXCEPT_MODIFIED_TIMESTAMP';equal=xlsx_members(now)==xlsx_members(old)
 elif not exact and rel.endswith('.gz'):
  kind='GZIP_DECOMPRESSED_BYTES';equal=gzip.decompress(now)==gzip.decompress(old)
  if not equal:
   try:equal=json.loads(gzip.decompress(now))==json.loads(gzip.decompress(old));kind='GZIP_DECOMPRESSED_JSON_SEMANTICS'
   except(ValueError,UnicodeError):pass
 elif not exact:
  try:equal=json.loads(now)==json.loads(old);kind='JSON_SEMANTICS'
  except(ValueError,UnicodeError):equal=False;kind='REAL_OR_UNCLASSIFIED_OUTSIDE4D_CHANGE'
 rec={'path':rel,'proof':kind,'equal':equal,'current_sha256':sha(now),'incoming88_sha256':sha(old),'action':'UNCHANGED'if exact else'RESTORE_EXACT_INCOMING88'if equal else'PRESERVE_REAL_DIFFERENCE'};proof.append(rec)
 if not exact:
  dst=out/'regenerated-before-normalization'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(now)
  if equal:p.write_bytes(old)
(out/'ALL-DIRTY-SEMANTIC-AUDIT.json').write_text(json.dumps(proof,indent=2)+'\n');print('audit',json.dumps(proof),flush=True)
command('package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'])
command('final-publish',['bash','tools/publish.sh'])
assert all(file_sha(repo/k)==v for k,v in protected.items());result={'status':'PASS_COMBINED_NATIVE61_PACKAGE5_PUBLISH','finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'affinity':sorted(os.sched_getaffinity(0)),'protected_count':len(protected),'assets_protected':len(asset_paths),'all_dirty_semantic_audit':proof,'source_baseline':'Normal integrated GTcf25+incoming88+ownjail authored inputs. No model or WEB bakes.','pending':'Wholecheck/preflight/codecommit/PR. Both original views remain DIFFERS.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
