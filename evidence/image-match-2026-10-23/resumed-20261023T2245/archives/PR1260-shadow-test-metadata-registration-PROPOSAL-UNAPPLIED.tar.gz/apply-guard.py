#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,os
p=argparse.ArgumentParser();p.add_argument('project_root',type=Path);p.add_argument('--apply',action='store_true');a=p.parse_args();packet=Path(__file__).resolve().parent;guards=json.loads((packet/'guards.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();pending=[]
rel='tools/test_check_harness.sh';target=a.project_root/rel;old=target.read_bytes();g=guards[rel];candidate=(packet/'candidate'/rel).read_bytes();assert sha(candidate)==g['after_sha256']
if sha(old)==g['before_sha256']:pending.append((target,candidate))
elif sha(old)!=g['after_sha256']:raise SystemExit('REFUSED unknown harness preimage')
rel='tools/step_isolation.json';target=a.project_root/rel;current=target.read_bytes();doc=json.loads(current);baseline=json.loads((packet/'before'/rel).read_bytes());measured=json.loads((packet/'candidate'/rel).read_bytes());key='tools/test_batch_shadow_cull.mjs';row=measured['tools'][key];receipt=json.loads((packet/'measurement-receipt.json').read_text());assert row==receipt['measured_row']
for k,v in baseline['tools'].items():
 if doc['tools'].get(k)!=v:raise SystemExit('REFUSED changed prior measured row: '+k)
if key in doc['tools']:
 if doc['tools'][key]!=row:raise SystemExit('REFUSED differing existing target measurement')
else:
 raw=(packet/'candidate'/rel).read_text();start=raw.index('    "'+key+'": {');stop=raw.index('    "tools/test_blackbox.mjs": {',start);entry=raw[start:stop];text=current.decode();anchor='    "tools/test_blackbox.mjs": {'
 if text.count(anchor)!=1:raise SystemExit('REFUSED unknown measurement insertion point')
 after=text.replace(anchor,entry+anchor,1).encode();check=json.loads(after);assert check['tools'][key]==row;del check['tools'][key];assert check==doc;pending.append((target,after))
if a.apply:
 for target,data in pending:
  temp=target.with_name(target.name+'.shadow-registration.tmp')
  with temp.open('xb')as f:f.write(data)
  os.chmod(temp,target.stat().st_mode);os.replace(temp,target)
print(json.dumps({'status':'APPLIED'if a.apply else'PASS_READONLY_GUARDS','paths_to_write':[str(t.relative_to(a.project_root))for t,_ in pending],'prior_rows_preserved':True},indent=2))
