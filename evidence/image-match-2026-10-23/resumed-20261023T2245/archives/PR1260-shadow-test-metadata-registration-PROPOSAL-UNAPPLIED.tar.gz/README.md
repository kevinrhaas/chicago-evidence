# Native shadow selftest registration and measured isolation — UNAPPLIED metadata repair

Exactly2 tracked paths. Source helper, permanent28 assertions and check.sh command remain unchanged.

`tools/test_check_harness.sh` adds the exact existing continuation command `  node tools/test_batch_shadow_cull.mjs` to an associative selftest command inventory and checks exact membership alongside the unchanged legacy `/self-?test/` rule. No regex loosening, renamed command or fake `--self-test` argument is used. The scanner still rejects a plain gate dressed as a selftest and selftests left untagged.

`tools/step_isolation.json` gains only the real measured row for that target tool. Native targeted measurement is supported through `--tool`; unlike `--build`, it runs exactly the commands check.sh declares for this one tool under the original probes and merges its actual classified writes. The unchanged native command was run in an owned minimal Git project fixture:

`node tools/measure_step_isolation.mjs --tool tools/test_batch_shadow_cull.mjs`

`actual-probe.jsonl` records the actual target argv and `wrote:[]`; the native classifier emits `wrote:[],wrote_ignored:[]`. Every prior row and every top-level metadata value are exact. No row, timing, hash or verdict was hand-minted. `measurement-receipt.json` binds that raw probe and the exact native output.

Three focused checks PASS on the fixture: original harness32passed/0failed, original harness--self-test36passed/0failed, native isolation audit792tools/1037keyedsteps covered. The actual unchanged target test separately passes all28 controls. No1064-step fullgate ran.

While root cleaned/remerged its source, the first fixture setup found the temporarily absent new test; the final fixture explicitly copies the frozen reviewed1508 helper and frozen permanent test/check.sh where needed. `source-bindings.json` records exact source paths and hashes. Original setup errors remain in the two setup-failure logs. This was not a production gate verdict and no source assertion was changed to resolve it.

`proposal.patch` is1100bytes: one exact command registration and four measured-row lines. `apply-guard.py <4d-root>` is read-only; `--apply` writes only these2 paths. Harness preimages must be exact. Measurement application transplants the exact native entry into current raw bytes, preserving all incoming new rows and metadata; any changed prior row or conflicting target row refuses. It does not replace a whole incoming manifest. Already-applied exact changes are accepted idempotently. Parent owns canonical application and fullgate.

No canonical file, source helper,28 assertions, image/TLS behavior, workflow, cap or actual browser verdict changed here. Root's original preflight08 metadata failure remains separate and preserved at `/workspace/PR1260-shadow-final-preflight08/check.log`. Empty measured writes prove this tested tool run, not every hypothetical future branch; native isolation policy remains unchanged.
