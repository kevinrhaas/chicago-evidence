from pathlib import Path
import json,hashlib,shutil,subprocess
p=Path(__file__).resolve().parent;root=Path('/workspace/primary-human-runner-compat/chicago/4d');fixture=p/'fixture';app=fixture/'chicago/4d';bindings={}
rels=['tools/check.sh','tools/check_harness.sh','tools/test_check_harness.sh','tools/step_isolation.json','tools/measure_step_isolation.mjs','tools/audit_step_isolation.mjs','tools/isolation_probe/node_probe.js','tools/isolation_probe/sitecustomize.py','tools/test_batch_shadow_cull.mjs','renderers/web/js/batch-frustum-box.js','renderers/web/vendor/three-0.185.1/three.core.js','renderers/web/vendor/three-0.185.1/three.module.js']
for rel in rels:
 source=root/rel
 if rel=='tools/test_batch_shadow_cull.mjs':source=Path('/tmp/PR1260-shadow-regression-test/candidate')/rel
 if rel=='renderers/web/js/batch-frustum-box.js':source=Path('/tmp/PR1260-shadow-ray-contingency/candidate')/rel
 if rel=='tools/check.sh' and 'node tools/test_batch_shadow_cull.mjs' not in source.read_text():source=Path('/tmp/PR1260-shadow-regression-test/candidate')/rel
 b=source.read_bytes();target=app/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);target.chmod(source.stat().st_mode);bindings[rel]={'copied_from':str(source),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
subprocess.run(['git','init','-q',str(fixture)],check=True)
rel='tools/test_check_harness.sh';b=(app/rel).read_text();needle="  awk '\n    /^step";replacement="  awk '\n    BEGIN { selftest_commands[\"  node tools/test_batch_shadow_cull.mjs\"] = 1 }\n    /^step";assert b.count(needle)==2;a=b.replace(needle,replacement,1).replace('looks = (cmd ~ /self-?test/)','looks = (cmd ~ /self-?test/ || cmd in selftest_commands)');assert a!=b;(app/rel).write_text(a)
for rel in ['tools/test_check_harness.sh','tools/step_isolation.json']:
 f=p/'before'/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((root/rel).read_bytes())
(p/'source-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
print(app)
