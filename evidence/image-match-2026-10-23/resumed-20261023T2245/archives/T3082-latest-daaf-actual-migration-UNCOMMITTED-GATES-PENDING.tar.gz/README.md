# T-3082 genuine exports migrated onto the latest parent

LIGHT migration completed on new branch
`steward/t3082-tremont-quarter-roof-v3`, HEAD
`daaf276c4d3310f050dc96bbb67e8cfe80078388`. ff808 is already an ancestor; no
merge is in progress. All earlier topic refs, held original entry files and
old Glessner cache remain preserved. No native downstream writer, browser,
gate, publisher, Glessner materializer/repacker or heavy build ran here.

Before clearing the previous v2 state, the actual b27972-file output checkpoint
was durably published and independently read back at private evidence commit
0cfce6afab2e9e0df5e97bb253da68bad80079e7. REMOTE-RECOVERY.json carries the
immutable recovery link. The old full diff/status and every selected actual
output, registry and authored file were compared exactly to that closed snapshot.

The four latest-parent authored preimages match the original guarded proposal.
A LIGHT fixture prepared the exact latest parent plus those four changes and
recomputed every one of the23 native recipe hashes and full serialized input
documents. Every recipe matched the genuine official producer binding exactly.
An exploratory Python comparison initially compared an in-memory tuple with a
persisted JSON array; both native hashes already matched. The final proof compares
exact finite canonical JSON, without float tolerances or production changes.

The migration used standard `git merge --quit`, restored only13 verified owned
tracked paths to the old HEAD, and atomically held the sole untracked original
T-3082 entry. It then created a fresh v3 topic from the full latest parent,
rechecked each authored preimage and reapplied only the four guarded files.
The entire incoming LIBERTIES document, including the reviewed Glessner
historical revision and Coleman append, was retained as raw bytes. Only this
unit's exact original suffix was appended once. STATUS/ROADMAP prefixes and the
one actual T-3082 entry were preserved the same way.

After actual canonical migration, all23 input hashes and full finite serialized
input documents were recomputed again, before copying any asset or recipe row.
Only after that proof passed were the46 genuine produced GLBs and the23 exact
native producer rows transferred from the immutable actual snapshot. No recipe
hash was invented or manually restamped. All unrelated incoming master/web rows
and physical assets, including Coleman/Glessner/Hogan, remain exact; the versions
manifest remains exact. Native web registry field order is retained, so its diff
contains only the Tremont master-hash change. Under assets, only the two target
GLBs and the two native registry files differ from the new parent.

MIGRATION-RECEIPT.json records actual canonical hashes, all46 transfers, raw doc
prefix guards, old/new branches and final status. LATEST23-INPUT-PROOF.json and
LATEST23-INPUT-DOCS.json retain the independent latest-parent fixture proof.
TRANSFER-PLAN.json records protected incoming rows and intended scope. The
proposed registry files are exact actual-row transfer results, not substitutes
for a producer. Current diff and entry capture the final uncommitted unit.

Only top-level selected files in CLOSED-MANIFEST.json belong to this closed
checkpoint. candidate/ is an unfrozen disposable source fixture and must not be
read or archived as part of this selection. The actual GLBs and producer receipts
are already in the independently verified b279 checkpoint; no live tree, run
directory or held Glessner bytes are needed to recover them.

Original T-2385 remains open/claimed and DIFFERS. T-3082 is bounded roof progress.
Source attribution and owner-approved project-use limits stand without a rights
upgrade. The broad-left flag pose remains unadopted research; canonical flag and
global wind are unchanged. The quarter-linear roof is a reconstructed contrast
choice. Native source/render review, the actual name-pool/seating check, ordered
downstream fixed point, preflight/full gate, published mobile/desktop smoke and
PR/merge remain pending. Those require the parent's next execution grant.
