from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal,zlib,urllib.request,urllib.parse,struct
os.sched_setaffinity(0,{1});os.nice(19)
B=Path(__file__).parent;C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='ec9f5c932763e3a40df8cb15496d888df50f6a37';TIP='7c5f2109cc1db6a86e23d76b4127385b587adcee';CAP=64*1024**2;ENVELOPE=CAP;FLOOR=512*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(r,*args,input=None):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:sha(G/n)for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
def indexed(ids):
 wanted=set(ids);found=set();obj=G/'objects'
 for s in wanted:
  if(obj/s[:2]/s[2:]).is_file():found.add(s)
 for idx in(obj/'pack').glob('*.idx'):
  remaining=wanted-found
  if not remaining:break
  with idx.open('rb')as f:
   head=f.read(8);v2=head[:4]==b'\xfftOc';off=8 if v2 else 0
   if v2:assert struct.unpack('>I',head[4:])[0]==2
   f.seek(off);fan=struct.unpack('>256I',f.read(1024));table=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
   for s in remaining:
    key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
    while a<z:
     m=(a+z)//2;f.seek(table+m*stride+delta);value=f.read(20)
     if value<key:a=m+1
     else:z=m
    f.seek(table+a*stride+delta)
    if a<fan[key[0]]and f.read(20)==key:found.add(s)
 return found




objdir=R/'objects';allids=set();inventory=[]
for f in sorted(objdir.rglob('*')):
 if not f.is_file():continue
 st=f.stat();inventory.append({'path':str(f.relative_to(objdir)),'bytes':st.st_size,'allocated':st.st_blocks*512,'inode':st.st_ino,'mtime_ns':st.st_mtime_ns,'sha256':sha(f)})
 if f.suffix=='.pack':
  data=f.read_bytes();assert hashlib.sha1(data[:-20]).digest()==data[-20:]
for idx in(objdir/'pack').glob('*.idx'):
 for line in git(R,'show-index',input=idx.read_bytes()).decode().splitlines():allids.add(line.split()[1])
for folder in objdir.iterdir():
 if len(folder.name)==2 and folder.is_dir():
  for f in folder.iterdir():
   if len(f.name)==38:allids.add(folder.name+f.name)
assert allids<=indexed(allids),'Neverprobecommonmissingobject'
ids=sorted(allids);(B/'EXACT-OBJECT-IDS.txt').write_text('\n'.join(ids)+'\n')
def canonical(r):
 checks={}
 with(B/'EXACT-OBJECT-IDS.txt').open('rb')as incoming:
  proc=subprocess.Popen(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','cat-file','--batch'],stdin=incoming,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
  for obj in ids:
   line=proc.stdout.readline();fields=line.decode().split();assert len(fields)==3 and fields[0]==obj;kind=fields[1];size=int(fields[2]);assert kind in ['commit','tree','tag']
   h1=hashlib.sha1(kind.encode()+b' '+str(size).encode()+b'\0');h2=hashlib.sha256();left=size
   while left:
    data=proc.stdout.read(min(left,1024**2));assert data;h1.update(data);h2.update(data);left-=len(data)
   assert proc.stdout.read(1)==b'\n'and h1.hexdigest()==obj
   checks[obj]={'kind':kind,'bytes':size,'canonical_data_sha256':h2.hexdigest()}
  assert proc.stdout.read()==b'';error=proc.stderr.read().decode();rc=proc.wait();assert rc==0,(rc,error)
 return checks
isolated=canonical(R);common=canonical(C);assert isolated==common
save('ALL-CANONICAL-METADATA-OBJECTS-BYTE-DUPLICATED.json',isolated);save('EXACT-OBJECT-FILE-INVENTORY.json',inventory)
def readers():
 hits=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   for fd in(proc/'fd').iterdir():
    try:
     target=os.readlink(fd)
     if target.startswith(str(objdir)+'/'):hits.append({'pid':int(proc.name),'fd':fd.name,'target':target})
    except(OSError,PermissionError):pass
  except(OSError,PermissionError):pass
 return hits
assert not readers()
for row in inventory:
 f=objdir/row['path'];st=f.stat();assert(st.st_ino,st.st_size,st.st_mtime_ns)==(row['inode'],row['bytes'],row['mtime_ns'])and sha(f)==row['sha256']
for f in R.rglob('*'):
 if f.is_file()and objdir not in f.parents:
  dest=B/'bare-nonobject-metadata'/f.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
before=snap();save('SOURCE-BEFORE.json',before);free=shutil.disk_usage('/tmp').free;assert not readers()
shutil.rmtree(objdir);(objdir/'info').mkdir(parents=True);(objdir/'pack').mkdir();(objdir/'info/alternates').write_text(str(G/'objects')+'\n')
# The isolated repository remains usable through a READONLY object selector; future fetches write only new isolated objects.
after=snap();save('SOURCE-AFTER.json',after);assert after==before
free_after=shutil.disk_usage('/tmp').free
result={'status':'ONLY_ISOLATED_CANONICAL_METADATA_DUPLICATES_RETIRED_COMMON_SOURCE_UNCHANGED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'object_directory':str(objdir),'verified_unique_objects':len(ids),'canonical_bytes_verified_per_repo':sum(r['bytes']for r in isolated.values()),'exact_canonical_SHA1_and_SHA256_kind_size_pairwise_equal':True,'removed_duplicate_files':len(inventory),'removed_allocated_bytes':sum(r['allocated']for r in inventory),'TMP_free_before':free,'TMP_free_after':free_after,'actual_TMP_df_gain':free_after-free,'workspace_free':shutil.disk_usage('/workspace').free,'live_readers_writers_before':[],'sourceHEAD_index_MERGE_config_status_allrefs_unchanged':True,'preserved':'Allreceipts/manifests/scripts/source/caches/recoveryarchives untouched; isolatednonobjectmetadata copiedtoproof andleftinplace.','isolated_reuse':'objects/info/alternates now READONLYselector of verifiedcommonobjects. Future isolatedfetch writes only new isolatedobjectfiles. Commonconfig/objects unchanged bycleanup.'};save('RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
