#!/usr/bin/python3
"""Preserve node unchanged except the reviewed tiny local Git promisor fixture."""
import os,sys,pathlib,hashlib,json,time
REAL_NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
APP=pathlib.Path('/workspace/chicago/chicago/4d')
FIXTURE=APP/'tools/test_repo_file.mjs'
EXPECTED_SHA='3a481450fb9324d285a08492a526e657a39f51d64aa918ee3f39cb6418bc4289'
LOG='/workspace/early-four-node-fixture-scope-20261029/NODE-INVOCATIONS.jsonl'
argv=sys.argv[1:]
fixture=bool(argv and pathlib.Path(argv[0]).resolve()==FIXTURE and pathlib.Path.cwd().resolve()==APP)
env=dict(os.environ)
row={'unix':time.time(),'pid':os.getpid(),'cwd':os.getcwd(),'argv':argv,'fixture_exception':fixture,'GIT_NO_LAZY_FETCH_before':env.get('GIT_NO_LAZY_FETCH')}
if fixture:
    assert len(argv)==1, 'No unreviewed fixture arguments'
    assert hashlib.sha256(FIXTURE.read_bytes()).hexdigest()==EXPECTED_SHA, 'Fixture changed; review scope again'
    env.pop('GIT_NO_LAZY_FETCH',None)
row['GIT_NO_LAZY_FETCH_after']=env.get('GIT_NO_LAZY_FETCH')
fd=os.open(LOG,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
os.write(fd,(json.dumps(row,separators=(',',':'))+'\n').encode());os.close(fd)
os.execve(REAL_NODE,[REAL_NODE,*argv],env)
