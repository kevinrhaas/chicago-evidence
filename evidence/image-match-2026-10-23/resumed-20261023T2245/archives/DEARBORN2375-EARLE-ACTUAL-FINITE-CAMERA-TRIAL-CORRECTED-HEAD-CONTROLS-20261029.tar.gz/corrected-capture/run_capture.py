from pathlib import Path
import os,json,subprocess,time,shutil,hashlib,signal,datetime
O=Path(__file__).resolve().parent;P=O/'photo-root';R=Path('/workspace/chicago/chicago/4d');B=json.loads((O/'BINDING.json').read_text());CAP=3*1048576
assert os.environ.get('EARLE_ONE_CPU3_CAPTURE_LEASE')=='finisher_v4-coordinated-one-native-capture'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ownbytes():
 return sum(p.stat().st_size for p in O.rglob('*')if p.is_file()and not p.is_symlink())
def floors():return {'workspace':shutil.disk_usage('/workspace').free,'tmp':shutil.disk_usage('/tmp').free}
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
assert all(sha(R/p)==v for p,v in B['runtime'].items());assert sha(Path(B['native_master']))==B['native_master_sha256']and sha(P/'camera.json')==B['camera_sha256']
space=floors();n_preflight=ownbytes();save('PREFLIGHT-v2.json', {'free':space,'owned_bytes':n_preflight,'WS_floor_bytes':512*1048576,'TMP_floor_bytes':1800000000,'cap_bytes':CAP});assert space['workspace']>=512*1048576 and space['tmp']>=1800000000 and n_preflight<CAP, (space,n_preflight)
scratch=O/'scratch';scratch.mkdir();E=dict(os.environ,TMPDIR=str(scratch),GIT_NO_LAZY_FETCH='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
cmd=['python3','/workspace/shared/run-with-reaping.py',str(O/'REAPER.json'),'--','taskset','-c','3','nice','-n','19','node','tools/photo_match.mjs','camera.json','--glb','assets/gltf/trial.glb','--out',str(O/'photo')]
t=time.monotonic();minimum=dict(space);peak=ownbytes();violations=[]
with(O/'CAPTURE.log').open('x')as log:
 q=subprocess.Popen(cmd,cwd=P,env=E,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while q.poll()is None:
  s=floors();n=ownbytes();peak=max(peak,n);minimum={k:min(minimum[k],s[k])for k in minimum}
  bad=s['workspace']<512*1048576 or s['tmp']<1800000000 or n>CAP
  if bad or time.monotonic()-t>180:
   violations.append({'space':s,'owned_bytes':n,'elapsed':time.monotonic()-t,'reason':'diskfloor_or3MiBcap'if bad else'180sbound'});os.killpg(q.pid,signal.SIGTERM);break
  time.sleep(.1)
 try:exit=q.wait(timeout=20)
 except subprocess.TimeoutExpired:os.killpg(q.pid,signal.SIGKILL);exit=q.wait()
reaper=json.loads((O/'REAPER.json').read_text())if(O/'REAPER.json').exists()else{}
match=P/'camera.match.json';done=exit==0 and not violations and reaper.get('command_exit')==0 and reaper.get('all_children_reaped')is True and match.exists()
if done:
 m=json.loads(match.read_text());assert m['glb_sha256']==B['native_master_sha256']and m['camera_sha256']==B['camera_sha256']and m['photo_sha256']==B['photo_sha256']and m['verdict']=='unreviewed'
assert all(sha(R/p)==v for p,v in B['runtime'].items());assert sha(Path(B['native_master']))==B['native_master_sha256']
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_NATIVE_EARLE_CORRECTED_DIAGNOSTIC_CAPTURE_UNREVIEWED'if done else'CAPTURE_STOPPED_NOT_A_PASS','exit':exit,'seconds':round(time.monotonic()-t,3),'minimum_free_bytes':minimum,'peak_own_regular_bytes':peak,'cap_new_bytes':CAP,'final_own_regular_bytes':ownbytes(),'violations':violations,'reaper':reaper,'frozen_master_and_native_runtime_unchanged':True,'no_primary_or_closed_bibliography_packet_writes':True,'no_canonical_match_or_DONE':True};save('RESULT.json',r);print(json.dumps(r,indent=2));assert done,r
