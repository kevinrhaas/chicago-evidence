# T-2375: finite Earle diagnostic camera trial

Two actual native captures use the exact existing V5 sixteen-foot-width MASTER
`c7408d424c67488f56650e190fdd7af6a23a667c67f005dff1849ef20c3b2f84`.
No geometry was exported or changed. The verified original Earle1902-volume
source and qualified1880Tribune/Baker addenda remain immutable.

The first camera used four approximate drawing controls. Direct inspection of
its actual side-by-side exposed a plainly incorrect manual head pick: near head
360px rather than about200px, far head480px rather than about405px. Its exact
camera, native result and raw unreviewed record are preserved. This was a camera
control error, not evidence for changing the bridge geometry.

The root authorized one finite correction. Corrected controls are documented
alongside the old controls: far visible post deck/head(300,620)/(300,405), near
post deck/head(1020,635)/(1020,200), approximately20px picking uncertainty. The
algebraic four-point fit can hit those approximate points exactly because its
pose/principal variables are weakly constrained; the residual is not evidence
of a surveyed camera or attested model dimensions. All positions, model heights,
width, profile, piles, caps, rakers and native source inputs remain unchanged.

One corrected attempt failed before rendering because the deeper scratch path
exceeded Chromium's Unix-socket pathname limit. Its actual error/reaper is kept.
A separate preflight refusal is also retained. The same corrected camera was
then rendered successfully using the short own TMPDIR spelling
`/workspace/e2375v2`, an alias to the owned workspace scratch. That successful
render finished before root's subsequent preference for a genuinely short
private directory arrived. No data moved to /tmp, no floor was lowered, and no
additional camera fitting variant or geometry pass was run.

Actual corrected native result: **4.624seconds**, CPU3/nice19, exit0 and all four
children reaped. Peak owned regular-file bytes1,480,629 <3MiB cap. Minimum free
workspace569,077,760B >512MiB; /tmp1,812,631,552B >1.8GB. First actual capture also
passed its5MiB cap, both floors and reaping. No live browser/profile remains.

The corrected side-by-side was directly inspected. The near/far heads are now
framed at their approximate pictured heights. Two gallows, high outer rakers,
chains, rising closed deck, horizontal-board parapets and pile-supported caps
are present in the native model. The Earle painting and Andreas engraving do
not supply a single consistent metric projection of deck and support shapes.
Those genuine drawing/camera differences do not justify another geometry or
pixel-offset loop under T-3153. The painting's dark/warm finish, figures, vessels,
water and wharf are not an exact material specification or additional bridge-
body geometry. There is no claimed new historically measured camera.

Both raw native match records remain **unreviewed**. The corrected review is
provided for root review, without a canonical MATCHES or original DONE claim.
The current native model, reader/tool bindings, camera/photo hashes and both
closed bibliography manifests are checked explicitly. Root should adopt the
original ticket/source/runtime work normally, including new Earle source,
current canonical view/publication/metadata, app and ground proof, full gate,
policy PR/CI/merge to dev and official ticket settlement. The standalone Baker
publication remains qualified rather than falsely identified in1880.
