from pathlib import Path
import subprocess,os,json,hashlib,importlib.util,sys,re,datetime
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path('/workspace/shared/WolfPoint-T2386-a9c5-integration-20261026');env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
H='4fe7d4baf3af163e6156a4b003656713f3b7560d';N='a9c5bd4a9715e4d5634c536d0efcd516ea9c3f01';B='a575dddeed356333423b20361a1f90f3b39a862f'
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=env)
def show(c,p):return git('show',c+':'+p)
sha=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==H and git('rev-parse','MERGE_HEAD').decode().strip()==N
p='chicago/4d/docs/LIBERTIES.md';base=show(B,p);ours=show(H,p);theirs=show(N,p);assert ours.startswith(base);suffix=ours[len(base):];assert suffix.count(b'### L-wolf-point-roof-tone-2386')==1 and b'### L-wolf-point-roof-tone-2386'not in theirs
(R/p).write_bytes(theirs+suffix);git('add',p)
# Preserve precisely incoming strict1904 expected IDs, eliminating only duplicate ranges.
p='chicago/4d/tools/smoke_renderer.mjs';current=(R/p).read_text();incoming=show(N,p).decode();pat=r'const PLACED_1904 = \[.*?\]\.sort\(\);';oursmatches=list(re.finditer(pat,current,re.S));newmatches=list(re.finditer(pat,incoming,re.S));assert len(oursmatches)==len(newmatches)==1
ids=re.findall(r"'([a-z][a-z0-9_]+)'",newmatches[0].group());assert len(ids)==len(set(ids))==283
oldids=re.findall(r"'([a-z][a-z0-9_]+)'",oursmatches[0].group());assert len(oldids)==284 and set(oldids)==set(ids) and oldids.count('pullman_house_1729_prairie_ranges')==2
current=current[:oursmatches[0].start()]+newmatches[0].group()+current[oursmatches[0].end():];(R/p).write_text(current);git('add',p)
# Verify custom registry merge agrees exactly at parsed entry level with native merge policy.
spec=importlib.util.spec_from_file_location('native_registry',A/'tools/merge_asset_registry.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
regs=[]
for p in ['chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json']:
 expected=mod.merge_texts(p,show(B,p).decode(),show(H,p).decode(),show(N,p).decode());actual=(R/p).read_text();assert json.loads(expected)==json.loads(actual),p;regs.append({'path':p,'native_entrywise_semantics_exact':True,'sha256':sha(actual.encode())})
prep=json.loads((O/'PREMERGE.json').read_text())
for row in prep['all82_pairs']:
 b=(R/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
sys.path.insert(0,str(A/'generators'));import mesh_inputs
rows=[]
for key,row in json.loads((A/'assets/manifest.json').read_text())['assets'].items():
 if row.get('archetype')!='log_dwelling':continue
 st=json.loads((A/'data/structures'/(row['structure_id']+'.json')).read_text());phase=next(p for p in st['phases']if p['id']==row['phase_id']);actual=mesh_inputs.structure_inputs_sha(st,phase,'log_dwelling');assert actual==row['inputs_sha256'],key;rows.append({'asset':key,'fresh_native_inputs_sha256':actual})
assert len(rows)==82
u=git('diff','--name-only','--diff-filter=U').decode().splitlines();assert set(u)==set('chicago/4d/'+p for p in ['data/liberties.json','data/sidecars/1835/sources/index.json','docs/measurements/source_use_coverage.md'])
for p in ['generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py','data/structures/wolf_point_tavern.json']:
 assert (A/p).read_bytes()==show(H,'chicago/4d/'+p),p
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':H,'incoming':N,'actual_mergebase':B,'authored_resolutions':['docs/LIBERTIES.md incomingexact plusownexactappend','tools/smoke_renderer.mjs exactincoming283strictIDs; allotherdonorrepairshunksretained'],'asset_registries':regs,'all82_master_and_web_pairs_exact':True,'all82_fresh_native_input_hashes':rows,'remaining_derived_U_for_native_resolve_only':u,'source_gate_not_yet_run':True,'codecommit_not_made':True,'whole_native_derive_CPU_lease_pending':True}
(O/'AUTHORED-RESOLUTIONS.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='all82_fresh_native_input_hashes'}))
