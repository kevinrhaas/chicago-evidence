# Permanent shadow regression test — two-path UNAPPLIED proposal

Adds only `tools/test_batch_shadow_cull.mjs` and one `selftest` step in `tools/check.sh`, immediately after the existing batch-coalescing renderer check. No runtime source, assertions, fixtures or frozen1508 proposal changed.

The test adapts all28 focused shadow controls to repository-relative native Three/helper paths. It reads the real helper, resolves its browser `three` import to the same vendored module through a dataURL, and exposes its two private pure kernels only in that test instance. Production exports/source files remain exact. Native callback comparisons use this same helper with a null descriptor as the old AABB-only baseline; no saved old helper or absolute external fixture is needed. The renderer descriptor is explicitly a CPU-only prototype, not an initialized WebGL renderer.

Controls cover the exact native light/map/inverse/filter/bias contract; unknown states fail open; source/receiver chunk changes; toward/tangent/filter-near preservation; real BatchedMesh shadow callback and stable retained-order/colour-list behavior; and1000 deterministic separating-plane ray/offset fixtures. A no-margin mutation control demonstrates why the physical padding matters. No47-test copy or committed artifacts are added. The test prints to stdout and writes no files.

All28 controls PASS in a minimal project-equivalent fixture containing only the test, exact1508 helper and two native vendor JS files. JS and shell syntax pass. The new selftest takes about0.1s locally; no fullgate or browser ran. Source1508 and its parent actual runtime proof remain separate. Root's hosted normal-TLS browser proof remains owed; the local remote-picture TLS failure was not suppressed or recast.

`proposal.patch` is the exact two-path patch against NEWroot H8check.sh. `apply-guard.py <4d-root>` checks both preimages read-only and recognizes only the exact H8old or1508new helper. `--apply` additionally requires the reviewed3path source helper already installed. Parent owns application and fullgate/commit. No canonical file was written here.
