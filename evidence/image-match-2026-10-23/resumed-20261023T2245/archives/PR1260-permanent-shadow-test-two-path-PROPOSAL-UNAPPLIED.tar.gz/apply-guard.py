#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,os
p=argparse.ArgumentParser();p.add_argument('project_root',type=Path);p.add_argument('--apply',action='store_true');a=p.parse_args();packet=Path(__file__).resolve().parent;g=json.loads((packet/'guards.json').read_text());binding=json.loads((packet/'helper-binding.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();helper=sha(a.project_root/'renderers/web/js/batch-frustum-box.js');ready=helper==binding['after_sha256']
if helper not in binding.values():raise SystemExit('REFUSED unknown helper source')
if a.apply and not ready:raise SystemExit('REFUSED apply reviewed3path source candidate first')
pending=[]
for rel,row in g.items():
 target=a.project_root/rel;candidate=packet/'candidate'/rel
 if row['before_sha256']is None:
  if target.exists():raise SystemExit('REFUSED new test already exists')
 elif sha(target)!=row['before_sha256']:raise SystemExit('REFUSED changed check.sh preimage')
 if sha(candidate)!=row['after_sha256']:raise SystemExit('REFUSED changed candidate')
 pending.append((target,candidate.read_bytes()))
if a.apply:
 for target,data in pending:
  temp=target.with_name(target.name+'.shadow-test.tmp')
  with temp.open('xb')as f:f.write(data)
  if target.exists():os.chmod(temp,target.stat().st_mode)
  os.replace(temp,target)
print(json.dumps({'status':'APPLIED'if a.apply else'PASS_READONLY_TWO_PATH_GUARDS','reviewed_source_helper_already_applied':ready,'files':list(g)},indent=2))
