from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal,zlib,urllib.request,urllib.parse,struct
os.sched_setaffinity(0,{1});os.nice(19)
B=Path(__file__).parent;C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='ec9f5c932763e3a40df8cb15496d888df50f6a37';TIP='7c5f2109cc1db6a86e23d76b4127385b587adcee';CAP=64*1024**2;ENVELOPE=CAP;FLOOR=512*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(r,*args,input=None):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:sha(G/n)for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
def indexed(ids):
 wanted=set(ids);found=set();obj=G/'objects'
 for s in wanted:
  if(obj/s[:2]/s[2:]).is_file():found.add(s)
 for idx in(obj/'pack').glob('*.idx'):
  remaining=wanted-found
  if not remaining:break
  with idx.open('rb')as f:
   head=f.read(8);v2=head[:4]==b'\xfftOc';off=8 if v2 else 0
   if v2:assert struct.unpack('>I',head[4:])[0]==2
   f.seek(off);fan=struct.unpack('>256I',f.read(1024));table=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
   for s in remaining:
    key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
    while a<z:
     m=(a+z)//2;f.seek(table+m*stride+delta);value=f.read(20)
     if value<key:a=m+1
     else:z=m
    f.seek(table+a*stride+delta)
    if a<fan[key[0]]and f.read(20)==key:found.add(s)
 return found




F=Path('/workspace/chicago/.git/objects/pack/tmp_pack_6WEr65')
def statrow():
 st=F.stat();return {'inode':st.st_ino,'device':st.st_dev,'bytes':st.st_size,'allocated_bytes':st.st_blocks*512,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'mode':st.st_mode}
def readers():
 hits=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   for fd in(proc/'fd').iterdir():
    try:
     target=os.readlink(fd)
     if target==str(F)or target==str(F)+' (deleted)':hits.append({'pid':int(proc.name),'fd':fd.name,'target':target})
    except(OSError,PermissionError):pass
  except(OSError,PermissionError):pass
 return hits
s0=statrow();assert F.name=='tmp_pack_6WEr65'and F.is_file()and not F.is_symlink();assert not readers();siblings=[str(p)for p in F.parent.glob(F.name+'*')];assert siblings==[str(F)],siblings
h=hashlib.sha1();full=hashlib.sha256();remaining=s0['bytes']-20
with F.open('rb')as f:
 head=f.read(12);f.seek(0)
 while remaining:
  data=f.read(min(4*1024**2,remaining));assert data;h.update(data);full.update(data);remaining-=len(data)
 tail=f.read(20);assert len(tail)==20;full.update(tail);assert f.read()==b''
assert head[:4]==b'PACK';valid=h.digest()==tail;s1=statrow();assert s1==s0 and not readers();assert not valid,'Neverdeletevalidcanonicalpackwithoutseparateduplicationproof'
proof={'status':'EXACT_INACTIVE_UNINDEXED_ORPHAN_FULL_STREAM_CHECKSUM_INVALID','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'path':str(F),'before_stat':s0,'after_full_checksum_stat':s1,'pack_header_hex':head.hex(),'full_stream_sha1_excluding_last20':h.hexdigest(),'actual_last20_hex':tail.hex(),'valid_pack_stream_checksum':valid,'full_file_sha256':full.hexdigest(),'same_prefix_files':siblings,'live_readers_writers':readers(),'authorization':'RootexactYjp-styleinvalidorphanrepair; no validindexedpacks/locks/source/assets/caches touched.'};save('PROOF-BEFORE.json',proof)
before=snap();save('SOURCE-BEFORE.json',before);free_before=shutil.disk_usage('/workspace').free
assert statrow()==s0 and not readers()and snap()==before
F.unlink()
after=snap();save('SOURCE-AFTER.json',after);assert after==before
free_after=shutil.disk_usage('/workspace').free
result={'status':'EXACT_INACTIVE_INVALID_UNINDEXED_ORPHAN_RETIRED_SOURCE_STATE_UNCHANGED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'removed_exact_path':str(F),'file_bytes':s0['bytes'],'allocated_bytes':s0['allocated_bytes'],'workspace_free_before':free_before,'workspace_free_after':free_after,'actual_df_gain':free_after-free_before,'TMP_free':shutil.disk_usage('/tmp').free,'sourceHEAD_index_MERGE_config_status_allrefs_unchanged':True,'all_other_files':'Nootherfiledeleted,noindex/lock/packrewrites. Invalidorphanpayloadnotcanonicalsource.'};save('RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
