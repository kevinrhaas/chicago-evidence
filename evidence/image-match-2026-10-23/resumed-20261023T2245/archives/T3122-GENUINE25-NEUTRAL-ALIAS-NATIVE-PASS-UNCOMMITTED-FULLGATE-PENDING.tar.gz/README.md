# T3122 genuine exports and closed native checkpoint

This is an uncommitted source checkpoint on checked T3123 bd316 plus actual incoming Abb/Ames. It is NOT a check.sh, app, PR or original-image acceptance.

Final producer a0bcd0e genuinely exported all25 masters with pinned Blender4.5.3 and real native web derivatives. Lighthouse8021 preserves all prototype physical/PBR/confidence/tone/normal faces, with an explicit neutral-stone material alias;24 default master/web files byte exact. Native strict material gate now passes. First relative-script launch and first duplicate-material bootstrap failure are retained. A superseded unconditional alias was caught by peer API review; the final helper compares resolved RGBA and roughness, retaining painted variants. Four source tests pass; all25 final assets were freshly baked afterward.

Native resolve202+7population+57stable-tail passes and clears all3 registered conflicts. The separate native policy builder exactly matches the approved full predicted JSON with only3 lighthouse measurements changed;341 protected rawfiles/955 incoming nonfort rows and both exact actualAbb workbooks preserved. Workbook serialization was restored only after every XML/nonXML member proved semantically identical to actual incoming Abb. No old7a workbook restoration.

All25 recipes genuinely fresh. Officers' T3124 piazza is NOT adopted here. Full required-reader check, subsequent S/native export, incoming frozen bridge/latestdev integration, final app/source comparisons/preflight/CI remain owed. Original2373/2379/2388 stay open/DIFFERS with all cameras/date/rights obligations. No prototype GLB copying or input-hash minting.
