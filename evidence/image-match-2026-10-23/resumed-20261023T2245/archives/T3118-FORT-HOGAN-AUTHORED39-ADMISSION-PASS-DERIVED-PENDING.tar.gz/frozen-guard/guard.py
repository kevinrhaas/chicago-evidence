"""Read-only exact-6e Hogan admission checks. Standard-library bytes/JSON only."""
from pathlib import Path
import argparse,hashlib,json
HERE=Path(__file__).resolve().parent
E=json.loads((HERE/'expected.json').read_text());A='chicago/4d/'
HOGAN='hogan_store';ASSET=HOGAN+'__log_1831.glb';SOURCE='cameron_c1900_first_post_office'
def digest(b):return hashlib.sha256(b).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'))
def sorted_rows(rows):return sorted(canonical(x) for x in rows)
def inspect(read,common_members,phase='derived'):
 checks=[];problems=[];seen={}
 def record(label,ok,detail=None):
  checks.append({'check':label,'pass':bool(ok)})
  if not ok:problems.append({'check':label,'detail':detail})
 def raw(p):
  try:
   b=read(p);seen[p]=digest(b);return b
  except (OSError,KeyError) as ex:
   record('read:'+p,False,type(ex).__name__);return b''
 def doc(p):
  try:return json.loads(raw(A+p))
  except (ValueError,TypeError):record('JSON:'+p,False,'missing or malformed');return {}
 for p,wanted in E['strict_files'].items():record('bytes:'+p,digest(raw(p))==wanted['sha256'],'exact6e preimage required')
 record('log-common-module-members',sorted(common_members)==sorted(E['common_python_members']),'new shared common input requires separate recipe/default review')
 for p,wanted in E['raw_fragments'].items():
  b=raw(p);fragment=bytes.fromhex(wanted['raw_utf8_hex']);record('own-raw-fragment:'+p,b.count(wanted['marker'].encode())==1 and fragment in b,'own6e fragment must remain byte-exact once; later fort append allowed')
 lib=raw(A+'docs/LIBERTIES.md');length=E['liberties_authoritative_prefix_bytes'];record('raw-LIBERTIES-complete-incoming6e-prefix',digest(lib[:length])==E['liberties_authoritative_prefix_sha256'],'fort owner declared incoming6e prefix plus own-only append tail')
 registry=doc('assets/manifest.json');record('master-registry-own-row',registry.get('assets',{}).get(ASSET)==E['master_row'])
 web=doc('assets/manifest.web.json');record('web-registry-own-master-row',web.get('masters',{}).get(ASSET)==E['web_master_row'])
 rules=doc('data/structure_grades.json');rows=[x for x in rules.get('pictured',[]) if x.get('structure')==HOGAN];record('authored-own-picture-grade-rule',sorted_rows(rows)==sorted_rows(E['pictured_rule']))
 notes=doc('data/reconstruction/name_pool_keys.json').get('read',{}).get('structures',[])
 record('own-note-readers',all(x in notes for x in E['required_note_readers']))
 if phase=='derived':
  libs=doc('data/liberties.json')
  for lid,wanted in E['liberty_rows'].items():record('compiled-own-liberty:'+lid,[x for x in libs.get('liberties',[]) if x.get('id')==lid]==[wanted],'exact own row once; other fort rows may grow')
  record('compiled-own-liberty-name',[x for x in libs.get('names',[]) if x.get('id')==HOGAN]==[E['liberty_name_row']])
  sidecar=doc('data/sidecars/1835/hogan_store.json');record('compiled-own-sidecar-row',sidecar==E['sidecar'],'entire Hogan own row, including attr grades/source/date/card grade; no global file identity assumption')
  source=doc('data/sidecars/1835/sources/'+SOURCE+'.json')
  record('compiled-own-source-metadata',source.get('source')==E['source_own_metadata'])
  record('compiled-own-source-name',source.get('names',{}).get(HOGAN)==E['source_name'])
  rows=[x for x in source.get('edges',[]) if x.get('entity_id')==HOGAN]
  record('compiled-own-source-edges',sorted_rows(rows)==sorted_rows(E['source_own_edges']),'all9own edges exact; unrelated entity edges allowed')
  idx=doc('data/sidecars/1835/sources/index.json');rows=[x for x in idx.get('sources',[]) if x.get('source_id')==SOURCE]
  wanted=E['source_index_row'][0]
  record('compiled-own-source-index-metadata',len(rows)==1 and {k:v for k,v in rows[0].items() if k!='counts'}=={k:v for k,v in wanted.items() if k!='counts'},'own source identity/citation/date/tier/use exact once; aggregate counts may grow with other entities')
  counts=rows[0].get('counts',{}) if len(rows)==1 else {}
  record('compiled-source-index-covers-own-claim-minimum',counts.get('claims',0)>=len(E['source_own_edges']) and counts.get('entities',0)>=1,'all9own edges separately checked exact; global aggregate correctness remains native owner gate')
 return {'authority':E['authority'],'phase':phase,'status':'PASS preservation only' if not problems else 'FAIL preservation','checks':checks,'problems':problems,'observed_sha256':seen,'limits':'Read-only bytes/JSON admission, no native recipe recomputation, generators, re-derivation, Blender/browser/export/fullgate/CI or source-image acceptance. OriginalT2377 remains open/differs.'}

def main():
 p=argparse.ArgumentParser();p.add_argument('repository');p.add_argument('--phase',choices=['authored','derived'],default='derived');args=p.parse_args();root=Path(args.repository).resolve()
 members=[str(p.relative_to(root)) for p in (root/A/'generators/common').glob('*.py')]
 report=inspect(lambda path:(root/path).read_bytes(),members,args.phase)
 # Refuse a mixed snapshot if any sampled file changed during the read.
 for path,old in report['observed_sha256'].items():
  try:unchanged=digest((root/path).read_bytes())==old
  except OSError:unchanged=False
  if not unchanged:report['problems'].append({'check':'stable-read:'+path,'detail':'writer changed a sampled input during read; rerun after owner closes native writers'})
 if report['problems']:report['status']='FAIL preservation'
 report['repository']=str(root);print(json.dumps(report,indent=2));return int(bool(report['problems']))
if __name__=='__main__':raise SystemExit(main())
