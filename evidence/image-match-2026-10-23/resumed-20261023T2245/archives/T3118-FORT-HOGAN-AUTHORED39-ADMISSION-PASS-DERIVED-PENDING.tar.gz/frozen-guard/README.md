# Read-only Hogan admission from exact public 6e66191

Authority is commit6e66191ebaea1f9d4d15c7a1ac9042a341d3714b, read with Git show by freeze.py. No baseline value was borrowed from the mutable fort checkout. This guard never imports a generator, validator, renderer, native writer or browser; it reads bytes and JSON using the standard library and prints a report.

Run from any directory, redirecting stdout to a NEW receipt outside the target checkout:

    python3 /tmp/chicago-next-model/T-3118-fort-admission-6e66191-v1/guard.py /tmp/chicago-log-integration --phase authored
    python3 /tmp/chicago-next-model/T-3118-fort-admission-6e66191-v1/guard.py /tmp/chicago-log-integration --phase derived

The authored phase covers30 exact source/artifact/log-input files, including Hogan record, master6876/web e7c0, source/actual painting, old provisional camera/match, all new source comparisons, R1 research README and pending T3118 changelog. It checks exact own raw LIB/STATUS/ROADMAP fragments, complete incoming6e LIB prefix, own registry rows, pictured ruling and consumed note readers. Shared common-module membership is pinned: a new or modified log input requires separate recipe/default review, not a checksum restamp.

Derived phase additionally compares the Hogan sidecar row (including reconstructed attribute grades and pictured/attested card basis), both own compiled liberty entries and name, the Cameron source metadata/name and all9 Hogan edges, and the Cameron index metadata once. The global index's aggregate counts may legitimately grow for other entities; own9 edges are compared exactly and must still be covered. Other fort registry/liberty/grade/index rows and appended documents are allowed to grow. No whole-file hash is imposed on those shared generated files. A second read rejects a snapshot modified by an active writer.

The existing pending T3118 entry is exact in this pre-merge composition. If a later legitimate public changelog fold removes it, do NOT restore that old pending file: stop this version and review the actual folded own entry, then issue a separately frozen revision. This guard does not evaluate JavaScript or replace the native changelog contract.

Public6e positive baseline passes. Memory-only controls allow unrelated fort global rows/raw appends and shared-source aggregate growth, and reject duplicate Hogan liberty, changed card grade, lost source edge, missing master row and changed raw admission. Control placeholder rows are not actual source records/assets or a native schema test.

This packet is immutable after MANIFEST. Do not rerun freeze.py or controls.py here; guard.py only reads and prints. Future actual-combined authored/derived verdicts belong in separate NEW receipt folders. The native owner still owes actual202 writers, fixed-point/native freshness, app/source/contact review, full gates and CI. A preservation pass is not an image match, a native acceptance or a public readiness claim. OriginalT2377 stays OPEN/DIFFERS, public1283 head6e and own live lap are untouched.
