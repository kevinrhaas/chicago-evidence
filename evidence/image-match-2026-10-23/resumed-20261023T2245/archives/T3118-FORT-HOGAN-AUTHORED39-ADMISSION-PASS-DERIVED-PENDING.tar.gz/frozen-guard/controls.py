"""Memory-only counterfactual selector controls, not actual fort data or native tests."""
import importlib.util,json,subprocess,copy,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('hogan_admission',O/'guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
R=Path('/workspace/chicago');H=g.E['authority'];cache={}
def read(p):
 if p not in cache:cache[p]=subprocess.check_output(['git','show',H+':'+p],cwd=R)
 return cache[p]
def run(overlay):return g.inspect(lambda p:overlay.get(p,read(p)),g.E['common_python_members'])
def data(p):return json.loads(read(g.A+p))
def encoded(d):return (json.dumps(d,indent=2)+'\n').encode()
base=run({});assert not base['problems']
# Positive: shared files can change for an unrelated fort; Hogan-own rows remain exact.
positive={}
p='data/liberties.json';d=data(p);extra=copy.deepcopy(d['liberties'][0]);extra['id']='L-fort-admission-memory-control';extra['subjects']=['fort_guard_control'];d['liberties'].append(extra);d['count']+=1;d['names'].append({'id':'fort_guard_control','name':'Memory-only unrelated fort control'});positive[g.A+p]=encoded(d)
p='assets/manifest.json';d=data(p);d['assets']['fort_guard_control.glb']={'structure_id':'fort_guard_control','memory_control_only':True};positive[g.A+p]=encoded(d)
p='assets/manifest.web.json';d=data(p);d['masters']['fort_guard_control.glb']='memory-only-not-an-asset';positive[g.A+p]=encoded(d)
p='data/structure_grades.json';d=data(p);extra=copy.deepcopy(d['pictured'][0]);extra['structure']='fort_guard_control';d['pictured'].append(extra);positive[g.A+p]=encoded(d)
p='data/sidecars/1835/sources/'+g.SOURCE+'.json';d=data(p);extra=copy.deepcopy(d['edges'][0]);extra['entity_id']='fort_guard_control';d['edges'].append(extra);d['names']['fort_guard_control']='Memory-only unrelated fort control';positive[g.A+p]=encoded(d)
p='data/sidecars/1835/sources/index.json';d=data(p)
for row in d['sources']:
 if row['source_id']==g.SOURCE:row['counts']['claims']+=1;row['counts']['entities']+=1
positive[g.A+p]=encoded(d)
for p in g.E['raw_fragments']:positive[p]=read(p)+b'\n\n### Fort memory control\n\nIndependent appended material only.\n'
passed=run(positive);assert not passed['problems'],passed['problems']
negatives=[]
# These preserve surrounding global rows, so matching only the first row must not mask loss/duplication.
p='data/liberties.json';d=data(p);d['liberties'].append(copy.deepcopy(next(x for x in d['liberties'] if x['id']=='L-hogan-dark-door-hatch-3118')));negatives.append(('duplicate-own-liberty',{g.A+p:encoded(d)}))
p='data/sidecars/1835/hogan_store.json';d=data(p);d['grade']['value']='reconstructed';negatives.append(('downgraded-own-card-grade',{g.A+p:encoded(d)}))
p='data/sidecars/1835/sources/'+g.SOURCE+'.json';d=data(p);d['edges']=[x for x in d['edges'] if not(x.get('entity_id')==g.HOGAN and x.get('claim','').endswith('.front_door_state'))];negatives.append(('lost-own-source-edge',{g.A+p:encoded(d)}))
p='assets/manifest.json';d=data(p);d['assets'].pop(g.ASSET);negatives.append(('missing-own-master-row',{g.A+p:encoded(d)}))
p='docs/LIBERTIES.md';b=read(g.A+p);negatives.append(('edited-own-raw-admission',{g.A+p:b.replace(b'0.30 m inside',b'0.45 m inside')}))
results=[]
for name,overlay in negatives:
 report=run(overlay);assert report['problems'],name;results.append({'control':name,'rejected_checks':[x['check'] for x in report['problems']]})
report={'authority':H,'baseline':'PASS','unrelated-fort-global-and-raw-append-control':'PASS','negative_controls':results,'actual_combined_fort_checked':False,'limits':'Memory-only selection/refusal controls using Git6e blobs. No native/generator/Blender/browser/fullgate, canonical writes or accepted image match.'}
(O/'controls-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
