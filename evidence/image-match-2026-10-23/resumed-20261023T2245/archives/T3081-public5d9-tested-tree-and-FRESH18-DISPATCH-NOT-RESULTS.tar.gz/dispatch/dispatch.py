from pathlib import Path
import subprocess,json,time,datetime,sys
out=Path(__file__).resolve().parent;branch='steward/t3081-log-picture-controls-v4';head=sys.argv[1];assert len(head)==40 and all(c in '0123456789abcdef' for c in head);endpoint='repos/kevinrhaas/chicago/actions/workflows/chicago-4d-smoke.yml';now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def api(args):
 q=subprocess.run(['gh','api',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);assert q.returncode==0,q.stderr;return q.stdout
pr=json.loads(api(['repos/kevinrhaas/chicago/pulls/1260']));assert pr['head']['sha']==head and pr['state']=='open'
def runs():return [x for x in json.loads(api([endpoint+'/runs?branch='+branch+'&event=workflow_dispatch&per_page=100']))['workflow_runs']if x['head_sha']==head]
seen={x['id']for x in runs()};assert not seen,'Prior dispatches exist; refuse duplicate batch'
groups=['13','14','15','9-12','8','6-7','5','3-4','1-2'];covered=[]
for g in groups:
 if '-'in g:
  a,b=map(int,g.split('-'));covered.extend(range(a,b+1))
 else:covered.append(int(g))
assert sorted(covered)==list(range(1,16))
state={'status':'RUNNING','started':now(),'PR':1260,'head':head,'branch':branch,'coverage':'all15parts per mobile and desktop, standard nine group split','runs':[]};receipt=out/'DISPATCH.json'
def save():receipt.write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for stage in groups:
  for viewport in ['desktop','mobile']:
   payload={'ref':branch,'inputs':{'viewport':viewport,'stage':stage}};p=out/(viewport+'-'+stage+'.json');p.write_text(json.dumps(payload)+'\n');item={'viewport':viewport,'stage':stage,'requested':now(),'payload_file':p.name};state['runs'].append(item);save();api(['-X','POST',endpoint+'/dispatches','--input',str(p)]);item['dispatch_accepted']=True;save()
   found=[]
   for _ in range(30):
    found=[x for x in runs()if x['id']not in seen]
    if found:break
    time.sleep(1)
   assert len(found)==1,('Cannot bind dispatch uniquely',viewport,stage,len(found))
   x=found[0];seen.add(x['id']);item.update(id=x['id'],url=x['html_url'],run_number=x['run_number'],created_at=x['created_at'],observed_head=x['head_sha']);save();print(viewport,stage,x['id'],flush=True)
 state.update(status='DISPATCHED_NOT_RESULTS',finished=now(),expected_run_count=18);save()
except BaseException as e:state.update(status='STOPPED',error=str(e),finished=now());save();raise
