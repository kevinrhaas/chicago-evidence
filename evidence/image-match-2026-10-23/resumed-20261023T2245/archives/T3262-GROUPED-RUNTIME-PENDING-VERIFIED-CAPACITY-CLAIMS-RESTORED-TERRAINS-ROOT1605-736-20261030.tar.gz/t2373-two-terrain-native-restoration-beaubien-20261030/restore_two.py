#!/usr/bin/env python3
"""One explicit root-approved restoration of exactly two missing canonical old-worktree copies."""
from pathlib import Path
import os,json,hashlib,importlib.util,time,subprocess,signal,stat,datetime,shutil,ctypes
assert os.environ.get('ROOT_TWO_TERRAIN_RESTORE_GRANT')=='only-old-harbor-and-natural'
os.sched_setaffinity(0,{2});os.nice(19)
OUT=Path(__file__).resolve().parent;V=Path('/workspace/shared-git-B-survivor-verifier-v2-beaubien-20261030/verify_b.py');assert hashlib.sha256(V.read_bytes()).hexdigest()=='4812123fa8127d199fc776c5d6320a68ddd09cae04576a1b59fb65c40cd9eb3f'
spec=importlib.util.spec_from_file_location('readguard',V);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.DEADLINE=180
W=Path('/workspace/worktrees/t2373-lighthouse');AD=m.C/'worktrees/t2373-lighthouse';NOTE=W/'RESTORE-RETIRED-TERRAIN.md';CHILD=None;TEMPS=[];START=time.monotonic()
MAPS=[Path('/workspace/t2373-terrain-canonical-copy-retirement-20261030/RESTORE-MAP.json'),Path('/workspace/t2373-natural-terrain-canonical-copy-retirement-20261030/RESTORE-MAP.json')];records=[json.loads(p.read_text())for p in MAPS];rels=[str(Path(r['path']).relative_to(W))for r in records]
assert set(rels)=={'chicago/4d/assets/gltf/terrain__e1834_harbor_cut.glb','chicago/4d/assets/gltf/terrain__e1830_natural.glb'}
wip=json.loads(Path('/workspace/t2373-single-glb-funding-readonly-20261030/WIP-SOURCE-MANIFEST.json').read_text())['files']

def verify_wip():
 assert len(wip)==10
 for r in wip:
  p=Path(r['path']);assert p.stat().st_size==r['bytes']and stat.S_IMODE(p.stat().st_mode)==r['mode']and m.sha(p)==r['sha256']
def oldres():
 d={}
 for raw in m.git(W,'ls-files','-z').split(b'\0'):
  if not raw:continue
  rel=os.fsdecode(raw)
  if rel in rels:continue
  p=W/rel
  try:d[rel]=m.info(p)
  except FileNotFoundError:d[rel]={'absent':True}
 return hashlib.sha256(json.dumps(d,sort_keys=True).encode()).hexdigest()
def status():return set(m.git(W,'status','--porcelain=v1','-z','--untracked-files=all').split(b'\0'))-{b''}
def reap():
 global CHILD
 if CHILD:
  try:os.killpg(CHILD.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:CHILD.wait(timeout=3)
  except subprocess.TimeoutExpired:
   try:os.killpg(CHILD.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   CHILD.wait(timeout=5)
  CHILD=None

def interrupted(sig,frame):raise InterruptedError(str(sig))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
libc=ctypes.CDLL(None,use_errno=True);rename_noreplace=libc.renameat2;rename_noreplace.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint];rename_noreplace.restype=ctypes.c_int
try:
 previous=json.loads(Path('/workspace/shared-git-A-redundant-retirement-v2-beaubien-20261030/PREFLIGHT.json').read_text());before=m.authority();historical=json.loads(json.dumps(previous['authority']))
 # Only prior root-approved historical index timestamp refresh is accepted.
 oi=historical['admin'][0]['files']['index'];ni=before['admin'][0]['files']['index'];assert oi['sha256']==ni['sha256'];refresh={k:{'prior':oi['stat'][k],'fresh':ni['stat'][k]}for k in ['mtime_ns','ctime_ns']}
 for k in ['mtime_ns','ctime_ns']:oi['stat'][k]=ni['stat'][k]
 assert before==historical,'unexpected authority drift'
 expecteddeps={**previous['deps'],'target_sidecars':[x for x in previous['deps']['target_sidecars']if not Path(x['path']).name.startswith(m.A)]};assert m.deps()==expecteddeps
 b,oids=m.idx(m.B);assert b==previous['B_index']and len(oids)==96935
 verify_wip();assert m.git(W,'rev-parse','HEAD').decode().strip()==records[0]['old_HEAD'];assert m.sha(AD/'index')==records[0]['old_index_sha256'];assert m.sha(AD/'HEAD')==records[0]['old_HEAD_file_sha256']
 for r,rel in zip(records,rels):
  p=Path(r['path']);assert not p.exists()and not p.is_symlink();entry=m.git(W,'ls-files','--stage','--',rel).decode().strip();assert entry.startswith('100644 '+r['blob']+' 0\t');assert m.git(W,'ls-files','-v','--',rel).decode().strip()=='H '+rel
 assert NOTE.is_file()and not NOTE.is_symlink();note_before=NOTE.read_bytes();other_res_before=oldres();status_before=status();assert all(b' D '+x.encode()in status_before for x in rels)
 owned_private={str(p):m.info(p)for p in [W/'.claude',W/'node_modules',W/'chicago/4d/tickets']};free_before=shutil.disk_usage('/workspace').free;tmp_before=shutil.disk_usage('/tmp').free;results=[]
 assert free_before>=536870912+sum(r['bytes']for r in records)+1048576
 (OUT/'PREFLIGHT.json').write_text(json.dumps({'authority':before,'restore_maps':[{**r,'map_path':str(p),'map_sha256':m.sha(p)}for r,p in zip(records,MAPS)],'B_index':b,'B_96935_OIDs':True,'old_other_resident_statmap_sha256':other_res_before,'note_prior_sha256':hashlib.sha256(note_before).hexdigest(),'note_prior_bytes':len(note_before),'root_historical_index_time_refresh_only':refresh},indent=2)+'\n')
 for r in records:
  target=Path(r['path']);tmp=target.with_name('.'+target.name+'.root-owned-restore-20261030');assert not target.exists();fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);TEMPS.append(tmp)
  cmd=[m.GIT,'--no-optional-locks','-c','protocol.allow=never','-c','core.packedGitWindowSize=16m','-c','core.packedGitLimit=64m','-C',str(m.ROOT),'cat-file','blob',r['blob']]
  try:
   CHILD=subprocess.Popen(cmd,stdout=fd,stderr=subprocess.PIPE,env=m.E,start_new_session=True);pid=CHILD.pid;_,err=CHILD.communicate(timeout=60);rc=CHILD.returncode;CHILD=None;assert rc==0,(rc,err[:2048]);os.fsync(fd)
  finally:os.close(fd)
  assert tmp.stat().st_size==r['bytes']and m.sha(tmp)==r['sha256']and stat.S_IMODE(tmp.stat().st_mode)==0o600;os.utime(tmp,ns=(r['mtime_ns'],r['mtime_ns']));assert not target.exists()and not target.is_symlink()
  ret=rename_noreplace(-100,os.fsencode(tmp),-100,os.fsencode(target),1);assert ret==0,('renameat2_noreplace',ctypes.get_errno());TEMPS.remove(tmp)
  dirfd=os.open(target.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(dirfd);os.close(dirfd)
  s=target.stat();assert s.st_size==r['bytes']and s.st_nlink==1 and stat.S_IMODE(s.st_mode)==0o600 and s.st_mtime_ns==r['mtime_ns']and m.sha(target)==r['sha256']
  primary=m.ROOT/target.relative_to(W);assert (s.st_dev,s.st_ino)!=(primary.stat().st_dev,primary.stat().st_ino)
  results.append({'path':str(target),'blob':r['blob'],'bytes':s.st_size,'allocated_B':s.st_blocks*512,'sha256':r['sha256'],'mode':'0o600','mtime_ns':s.st_mtime_ns,'nlink':s.st_nlink,'native_pid':pid,'native_exit':rc,'native_reaped':True,'atomic_rename_noreplace':True,'primary_independent_inode':True})
 assert NOTE.read_bytes()==note_before
 now=datetime.datetime.now(datetime.timezone.utc).isoformat();append='\n\n## BOTH TERRAIN COPIES RESTORED — NO PENDING ASSET DELETIONS\n\nRestored '+now+' by separately root-authorized native local Git streams from the verified surviving object store. Both prior retirement entries above remain unchanged history. Both missing terrain paths are now present with their exact canonical bytes, full Unix0600 mode and original mtime; no pending asset deletions from these temporary retirements. NEVER commit a terrain deletion based on the historical retirement entries.\n\n'+''.join(x['path']+'\nSHA256 '+x['sha256']+'; blob '+x['blob']+'; bytes '+str(x['bytes'])+'\n\n'for x in results)
 fd=os.open(NOTE,os.O_WRONLY|os.O_APPEND)
 with os.fdopen(fd,'a')as f:f.write(append);f.flush();os.fsync(f.fileno())
 assert NOTE.read_bytes()==note_before+append.encode();verify_wip();assert oldres()==other_res_before
 status_after=status();assert status_before-status_after=={b' D '+r.encode()for r in rels}and not status_after-status_before
 after=m.authority();adjusted=json.loads(json.dumps(after))
 for old,new in zip(before['worktrees'],adjusted['worktrees']):
  if old['root']==str(W):new['resident_stat_map_sha256']=old['resident_stat_map_sha256'];new['status_sha256']=old['status_sha256']
 assert adjusted==before,'unexpected source/admin/index/config/private authority change';assert m.deps()==expecteddeps;assert m.idx(m.B)==(b,oids)
 for path,s in owned_private.items():assert m.info(Path(path))==s
 result={'status':'ONLY_TWO_CANONICAL_TERRAIN_COPIES_NATIVE_RESTORED_EXACT','at':now,'restored':results,'all10_WIP_exact':True,'old_HEAD_index_flags_unchanged':True,'all_primary_source7_index_config_allrefs_and_private_authority_unchanged':True,'all_other_resident_statmaps_unchanged':True,'old_status_delta_only_two_asset_D_disappear':True,'full_prior_restore_note_history_preserved':True,'restore_note_sha256':m.sha(NOTE),'note_now_clearly_both_restored_no_pending_asset_deletions':True,'B_verified_pack_idx_rev_96935objects_preserved':True,'workspace_before_B':free_before,'workspace_after_B':shutil.disk_usage('/workspace').free,'TMP_before_B':tmp_before,'TMP_after_B':shutil.disk_usage('/tmp').free,'wall_seconds':time.monotonic()-START,'all_native_children_reaped':CHILD is None,'own_temporary_files_absent':not TEMPS,'no_thirdasset_source_Git_ref_index_config_mutation':True}
 (OUT/'RESTORED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
finally:
 reap()
 # Never delete a canonical destination on failure. Retain any owned temp for diagnosis.
