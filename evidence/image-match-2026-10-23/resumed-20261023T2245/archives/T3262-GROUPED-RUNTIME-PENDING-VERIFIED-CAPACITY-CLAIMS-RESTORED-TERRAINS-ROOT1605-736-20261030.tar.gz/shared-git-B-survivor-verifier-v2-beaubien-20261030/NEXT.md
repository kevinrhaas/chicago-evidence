V2 only classifies absent registered root directories and queries their surviving index/flags/HEAD directly through --git-dir/--work-tree. Their admin bytes/reflogs/config remain covered by the original authority guards; before/after record equality requires each directory remain absent. Existing roots retain identical full resident/index/status/source guards. No metadata prune, directory creation, Git mutation or removal capability was added. V1 remains immutable; refusal is root-reported with absent output dir independently rechecked, not falsely presented as a raw traceback.

After root review and an explicit NEW grant only:
ROOT_PACK_VERIFY_GRANT=after-phone-B-survivor-only python -B /workspace/shared-git-B-survivor-verifier-v2-beaubien-20261030/verify_b.py --execute --expected-head 40453bde8ba1812925d61fef118782a30323f98e --output /workspace/shared-git-B-survivor-actual-v2-root-20261030

No V2 native or large-body execution has occurred. All V1 CPU/deadline/floors/reaper/resource bounds remain identical.
