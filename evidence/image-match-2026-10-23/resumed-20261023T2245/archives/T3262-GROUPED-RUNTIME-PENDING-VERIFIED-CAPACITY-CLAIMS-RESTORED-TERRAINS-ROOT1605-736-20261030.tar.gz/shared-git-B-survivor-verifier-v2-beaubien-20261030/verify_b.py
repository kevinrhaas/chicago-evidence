#!/usr/bin/env python3
"""One read-only pack verification. No retirement capability; execute requires root lease."""
import argparse,datetime,hashlib,json,os,pathlib,resource,selectors,signal,stat,struct,subprocess,time,shutil
P=pathlib.Path;ROOT=P('/workspace/chicago');C=ROOT/'.git';PACK=C/'objects/pack'
A='pack-af7f4707b5c1dfa2fc9470dff818f74c796080e4';B='pack-d9f146b2a772477817d63ff619703c55bc5124d0'
HERE=P(__file__).resolve().parent;EXPECTED='40453bde8ba1812925d61fef118782a30323f98e';FLOOR=536870912;TMPFLOOR=1800000000;RESERVE=1048576
E=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C')
GIT=shutil.which('git');CHILD=None;START=time.monotonic();DEADLINE=900

def checktime():
 if time.monotonic()-START>DEADLINE:raise TimeoutError('900s total verification deadline')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):checktime();h.update(b)
 return h.hexdigest()
def info(p):
 s=p.lstat();d={'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'nlink':s.st_nlink,'bytes':s.st_size,'allocated_B':s.st_blocks*512,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
 if stat.S_ISLNK(s.st_mode):d['link']=os.readlink(p)
 return d
def git(root,*args):
 checktime();return subprocess.check_output([GIT,'--no-optional-locks','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','protocol.allow=never','-c','maintenance.auto=false','-c','gc.auto=0','-C',str(root),*args],env=E,timeout=min(60,max(1,DEADLINE-(time.monotonic()-START))))
def idx(name):
 p=PACK/(name+'.idx');before=info(p);raw=p.read_bytes();assert raw[:4]==b'\xfftOc'and struct.unpack_from('>I',raw,4)[0]==2
 fan=struct.unpack_from('>256I',raw,8);n=fan[-1];oids=[raw[1032+i*20:1052+i*20]for i in range(n)];assert n==96935 and all(len(o)==20 for o in oids)and all(x<y for x,y in zip(oids,oids[1:]))
 counts=[0]*256
 for o in oids:counts[o[0]]+=1
 acc=0
 for i,count in enumerate(counts):acc+=count;assert fan[i]==acc
 assert hashlib.sha1(raw[:-20]).digest()==raw[-20:];assert raw[-40:-20].hex()==name[5:];assert info(p)==before
 return {'name':name,'count':n,'sha256':hashlib.sha256(raw).hexdigest(),'idx_sha1':raw[-20:].hex(),'pack_sha1_from_idx':raw[-40:-20].hex(),'OID_sha256':hashlib.sha256(raw[1032:1032+20*n]).hexdigest(),'stat':before},oids

def deps():
 side=[];forbidden=[]
 for p in sorted(PACK.iterdir()):
  if p.name.startswith((A,B)):
   r={'path':str(p),'stat':info(p)}
   if p.suffix!='.pack':r['sha256']=sha(p)
   side.append(r)
   if p.suffix not in ('.pack','.idx','.rev'):forbidden.append(p.name)
  if p.name.startswith('multi-pack-index')or p.suffix in ('.midx','.bitmap'):forbidden.append(p.name)
 assert not forbidden,('MIDX/bitmap/target protection dependencies require separate analysis',forbidden)
 alternatives=[]
 for f in ['alternates','http-alternates']:
  q=C/'objects/info'/f
  if q.exists():alternatives.append({'path':str(q),'sha256':sha(q),'bytes':q.stat().st_size})
 assert not alternatives,'external alternates require separate analysis'
 prom=[{'name':p.name,'stat':info(p),'sha256':sha(p)}for p in sorted(PACK.glob('*.promisor'))]
 return {'target_sidecars':side,'MIDX_bitmap_target_keep_promisor_absent':True,'other_promisor_markers':prom,'alternates_absent':True}

def authority():
 assert git(ROOT,'rev-parse','HEAD').decode().strip()==EXPECTED
 assert not (C/'MERGE_HEAD').exists(),'primary merge active'
 source_keys=json.loads(P('/workspace/standalone-phone-memory-v2-controllers-second-fort-20261030/CHECKPOINT-RESULT.json').read_text())['all7_source_sha256'].keys()
 source7={s:sha(ROOT/s)for s in source_keys};assert len(source7)==7
 admin=[C]+sorted((C/'worktrees').iterdir());admin_records=[];roots=[(ROOT,C)]
 for ad in admin:
  files={}
  for name in ['HEAD','index','config','config.worktree','commondir','gitdir','locked','ORIG_HEAD','MERGE_HEAD','FETCH_HEAD','packed-refs']:
   p=ad/name
   if p.is_file():files[name]={'stat':info(p),'sha256':sha(p)}
  if ad!=C:
   gd=(ad/'gitdir').read_text().strip();roots.append((P(gd).parent,ad))
  admin_records.append({'admin':str(ad),'files':files})
 refs={str(p.relative_to(C)):sha(p)for p in sorted((C/'refs').rglob('*'))if p.is_file()}
 refs_sem=git(ROOT,'for-each-ref','--format=%(refname) %(objectname)')
 work=[]
 for root,ad in roots:
  if not root.exists():
   assert not root.is_symlink(),('dangling worktree path requires separate classification',str(root))
   opts=('--git-dir='+str(ad),'--work-tree='+str(root))
   work.append({'root':str(root),'root_absent':True,'admin':str(ad),'HEAD':git(ROOT,*opts,'rev-parse','HEAD').decode().strip(),'stage_sha256':hashlib.sha256(git(ROOT,*opts,'ls-files','--stage','-z')).hexdigest(),'flags_sha256':hashlib.sha256(git(ROOT,*opts,'ls-files','-v','-z')).hexdigest(),'resident_scope':'no existing directory; absence must remain exact before/after; admin/index/config/reflogs preserved above'})
   continue
  assert root.is_dir(),('registered worktree path not directory',str(root))
  tracked=git(root,'ls-files','-z').split(b'\0');res={}
  for raw in tracked:
   if not raw:continue
   path=os.fsdecode(raw);p=root/path
   try:res[path]=info(p)
   except FileNotFoundError:res[path]={'absent':True}
  stages=git(root,'ls-files','--stage','-z');flags=git(root,'ls-files','-v','-z');status=git(root,'status','--porcelain=v1','-z','--untracked-files=all')
  work.append({'root':str(root),'HEAD':git(root,'rev-parse','HEAD').decode().strip(),'stage_sha256':hashlib.sha256(stages).hexdigest(),'flags_sha256':hashlib.sha256(flags).hexdigest(),'status_sha256':hashlib.sha256(status).hexdigest(),'tracked_entries':len(res),'resident_stat_map_sha256':hashlib.sha256(json.dumps(res,sort_keys=True).encode()).hexdigest()})
 # All administrative reflog bytes remain authority, including private/worktree commits.
 logs={}
 for ad in admin:
  lp=ad/'logs'
  if lp.exists():
   for p in sorted(lp.rglob('*')):
    if p.is_file():logs[str(p)]=sha(p)
 return {'HEAD':EXPECTED,'source7_sha256':source7,'admin':admin_records,'refs_physical':refs,'all_refs_semantic_sha256':hashlib.sha256(refs_sem).hexdigest(),'all_refs_count':len(refs_sem.splitlines()),'reflog_sha256':logs,'worktrees':work,'git_executable':{'path':GIT,'stat':info(P(GIT)),'sha256':sha(P(GIT))}}

def verify_native(out):
 global CHILD
 argv=[GIT,'--no-optional-locks','-c','protocol.allow=never','-c','pack.threads=1','-c','core.packedGitWindowSize=16m','-c','core.packedGitLimit=64m','-c','core.deltaBaseCacheLimit=32m','-c','maintenance.auto=false','-c','gc.auto=0','verify-pack',str(PACK/(B+'.idx'))]
 t=time.monotonic();CHILD=subprocess.Popen(argv,env=E,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);pid=CHILD.pid
 sel=selectors.DefaultSelector();sel.register(CHILD.stdout,selectors.EVENT_READ);log=bytearray()
 while sel.get_map():
  checktime()
  for key,_ in sel.select(0.5):
   data=os.read(key.fd,8192)
   if not data:sel.unregister(key.fileobj);continue
   assert len(log)+len(data)<=65536,'native output exceeded finite64KiB log'
   log.extend(data)
 rc=CHILD.wait(timeout=5);CHILD=None;(out/'NATIVE-VERIFY.log').write_bytes(log);assert rc==0,('native verify-pack failed',rc)
 return {'argv':argv,'pid':pid,'exit_code':rc,'wall_seconds':time.monotonic()-t,'output_bytes':len(log),'reaped':True,'max_child_rss_KiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}

def reap():
 global CHILD
 if CHILD is not None:
  pid=CHILD.pid
  try:os.killpg(pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:CHILD.wait(timeout=3)
  except subprocess.TimeoutExpired:
   try:os.killpg(pid,signal.SIGKILL)
   except ProcessLookupError:pass
   CHILD.wait(timeout=5)
  CHILD=None

def stopped(signum,frame):raise InterruptedError('signal '+str(signum))

def main():
 global START
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--expected-head',default=EXPECTED);ap.add_argument('--output',type=P);args=ap.parse_args()
 assert args.expected_head==EXPECTED;os.sched_setaffinity(0,{2});os.nice(19)
 a,oa=idx(A);b,ob=idx(B);assert oa==ob;dependency=deps()
 prep={'status':'READONLY_REHEARSAL_NO_PACK_BODY_READ','expected_HEAD':EXPECTED,'survivor':B,'redundant_candidate':A,'indexes':[a,b],'exact_equal96935OID':True,'dependencies':dependency,'deadline_seconds':900,'CPU':[2],'workspace_floor_B':FLOOR,'workspace_reserve_B':RESERVE,'shared_TMP_floor_B':TMPFLOOR,'shared_TMP_allocations':False,'native_execute_requires_root_after_phone_grant':True,'no_retirement_capability':True}
 if not args.execute:print(json.dumps(prep));return
 assert os.environ.get('ROOT_PACK_VERIFY_GRANT')=='after-phone-B-survivor-only','requires explicit root after-phone grant'
 assert args.output and args.output.is_absolute() and args.output.parent==P('/workspace') and args.output.name.startswith('shared-git-B-survivor-actual-')
 assert not args.output.exists();assert shutil.disk_usage('/workspace').free>=FLOOR+RESERVE;assert shutil.disk_usage('/tmp').free>=TMPFLOOR
 START=time.monotonic();before=authority();args.output.mkdir(mode=0o700);(args.output/'BEFORE.json').write_text(json.dumps({'authority':before,'bindings':prep},indent=2)+'\n')
 signal.signal(signal.SIGTERM,stopped);signal.signal(signal.SIGINT,stopped);survivor=PACK/(B+'.pack');packstat=info(survivor);t=time.monotonic();h=hashlib.sha1();count=0
 with survivor.open('rb')as f:
  header=f.read(12);assert header[:4]==b'PACK';version,n=struct.unpack('>II',header[4:]);assert version in (2,3)and n==96935;h.update(header);remain=packstat['bytes']-12-20
  while remain:
   checktime();chunk=f.read(min(1048576,remain));assert chunk;h.update(chunk);remain-=len(chunk);count+=len(chunk)
  footer=f.read(20);assert len(footer)==20 and not f.read(1)
 assert h.hexdigest()==footer.hex()==b['pack_sha1_from_idx'];assert info(survivor)==packstat
 checksum={'bytes_streamed':count+32,'pack_header_version':version,'pack_header_objects':n,'computed_sha1':h.hexdigest(),'actual_footer_sha1':footer.hex(),'index_pack_checksum':b['pack_sha1_from_idx'],'wall_seconds':time.monotonic()-t}
 (args.output/'SURVIVOR-CHECKSUM.json').write_text(json.dumps(checksum,indent=2)+'\n')
 native=verify_native(args.output);a2,oa2=idx(A);b2,ob2=idx(B);assert a2==a and b2==b and oa2==ob2==oa;assert deps()==dependency;after=authority();assert after==before
 result={'status':'SURVIVOR_B_FULL_PACK_CHECKSUM_AND_NATIVE_VERIFY_PASS_NO_RETIREMENT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checksum':checksum,'native':native,'both_indexes_exact_equal96935OID':True,'all_refs_worktree_HEAD_index_flags_status_config_reflogs_source7_resident_stats_preserved':True,'tracked_resident_bytes_not_rehashed':True,'resident_preservation_scope':'full tracked path inode,size,mode,nlink,mtime,ctime and symlink target snapshot every registered worktree; critical7source/admin/config/reflog bytes hashed; read-only verifier writes only own external outputs','all_source_Git_and_sidecars_unchanged':True,'total_wall_seconds':time.monotonic()-START,'CPU_affinity':list(os.sched_getaffinity(0)),'reaper_complete':CHILD is None,'removal_authorized':False,'separate_root_review_and_grant_required':True,'workspace_free_B':shutil.disk_usage('/workspace').free,'TMP_free_B':shutil.disk_usage('/tmp').free}
 (args.output/'AFTER.json').write_text(json.dumps(after,indent=2)+'\n');(args.output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

if __name__=='__main__':
 try:main()
 except BaseException:
  reap();raise
 finally:reap()
