# Prepared only: older B survivor verification

No pack-body or native verify-pack run has occurred. The successful default rehearsal read the two small .idx files, .rev sidecars, marker hashes and filesystem metadata only. Root must close the phone phase, freeze shared Git/source mutation and explicitly grant this separate read-only verification phase. No removal is authorized or implemented.

Exact future command, AFTER that root grant only:

```sh
source /workspace/shared/resume-chicago-env.sh
ROOT_PACK_VERIFY_GRANT=after-phone-B-survivor-only python -B /workspace/shared-git-B-survivor-verifier-prep-beaubien-20261030/verify_b.py --execute --expected-head 40453bde8ba1812925d61fef118782a30323f98e --output /workspace/shared-git-B-survivor-actual-beaubien-20261030
```

One selected older survivor d9f146b2a772477817d63ff619703c55bc5124d0 is fully streamed SHA1 (8,753,349,340 bytes) with actual header count96,935, actual footer and index pack checksum equality. Then real native Git verify-pack validates that survivor's payload/delta objects. Newer af7f is not assumed valid. Both sorted complete index OID inventories must still be equal before/after. No pack-body verification has yet passed.

CPU2 only/nice19;900s total monotonic deadline covering setup/hash/native/afterguards; native process has a new processgroup, bounded64KiB output, SIGTERM/SIGKILL+wait reaper and measured duration/maxRSS. PackedGit window16MiB/limit64MiB/deltaCache32MiB; these are Git cache settings, not an assertion that RSS is capped. SHA1 buffer1MiB. Shared TMP has no owned allocations and retains1.8GB floor. Workspace retains536,870,912B floor plus1MiB metadata reserve; command refuses nonunique output paths or wrong404HEAD. No browser, fixture, model duplication or Git mutation.

Every registered worktree HEAD/index/config/flags/status plus common raw/semantic refs and all administrative reflog bytes are guarded before/after. All tracked paths in every registered worktree receive full inode/size/mode/nlink/mtime/ctime/symlink snapshots; the seven established critical source files receive byteSHA256, as do administrative/config/ref/reflog files. Resident model/source bytes are NOT all rehashed; this read-only operation preserves complete resident stat maps and reports that limit explicitly. Missing registered worktrees stop the phase. No primary source adoption follows verification.

Observed dependencies: exactly .idx/.pack/.rev for both targets; no target.keep/.promisor, MIDX, bitmap or alternates.69 other pack.promisor markers are hashed/preserved, not interpreted as target payload proof. Any new dependent sidecar/MIDX/bitmap or source/Git drift stops. A later separate root review/grant must evaluate any redundant A pack/index/reverse-index retirement and preserve all private commits/worktree authority. This helper contains no unlink, repack, prune, GC, config/ref/index write or retirement code.
