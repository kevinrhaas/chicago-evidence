"""Two real native grouped smoke calls; twenty logical part/viewport coverage cells."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess,sys,time
P=Path('/workspace/T3262-v3-237-controllers-secondfort-20261030');F=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((P/'common.py').read_bytes())=='6532d4cf179979b97684938a0512b6bf1ce8b9115834212b09b7cced8532b9d7'
assert sha((P/'BASE.json').read_bytes())=='ea55abc546227a75c7b1e7834545769e86f6689cef88455eec5795a40955c5f2'
sys.dont_write_bytecode=True;sys.path.insert(0,str(P));import common as C
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--expect-head',required=True);p.add_argument('--expect-tree',required=True);p.add_argument('--expect-merge-parent',default=C.BASE['merge_parent']);p.add_argument('--expect-branch',required=True);p.add_argument('--ticket',required=True);p.add_argument('--outdir',required=True);p.add_argument('--execute',action='store_true');a=p.parse_args();assert a.execute
assert a.expect_head=='40453bde8ba1812925d61fef118782a30323f98e'and a.expect_tree=='2b609b8461f000730de75dd4672275ca5115fa8d'
assert a.ticket=='T-3262'and a.expect_merge_parent==C.BASE['merge_parent']
guard,binding=C.committed(a);stage='1-3,7-12,14';parts=[1,2,3,7,8,9,10,11,12,14];views=['desktop','mobile'];cmd=['node','tools/smoke_renderer.mjs','--published']
# Root owns cancellation of the old first incomplete call. Preserve it as NQ.
prior_rp=P/'smoke-v3-14-desktop-REAPER.json';prior_log=P/'smoke-v3-14-desktop.log';prior=json.loads(prior_rp.read_bytes());assert prior['all_children_reaped']and prior['command_exit']!=0;assert not re.search(r'^SMOKE PASS$',prior_log.read_text(),re.M)
if(P/'SMOKE-V3-STEPS.json').exists():assert not any(r.get('passed')for r in json.loads((P/'SMOKE-V3-STEPS.json').read_bytes()))
out=Path(a.outdir).resolve();assert out.is_relative_to('/workspace')and not out.is_relative_to(C.R)and not out.exists();C.floors(24*1048576);tmp=Path('/workspace/v3-grp');assert not tmp.exists();out.mkdir(mode=0o700);tmp.mkdir(mode=0o700);marker=tmp/'OWNED-40453-GROUPED-SMOKE';marker.write_text(a.expect_head+'\n')
E=dict(C.E,TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),SMOKE_STAGE=stage,SMOKE_TIMING='1');save=lambda n,d:(out/n).write_text(json.dumps(d,indent=2)+'\n')
binding.update(grouped_native_stage_selector=stage,logical_parts=parts,viewports=views,planned_real_native_calls=2,planned_logical_coverage_cells=20,command=cmd,outdir=str(out),TMPDIR=str(tmp),controller=str(F/'run.py'),controller_sha256=sha((F/'run.py').read_bytes()),native_smoke_source_sha256=sha((C.A/'tools/smoke_renderer.mjs').read_bytes()),frozen_common_sha256=sha((P/'common.py').read_bytes()),old_first_incomplete_call=dict(reaper=str(prior_rp),reaper_sha256=sha(prior_rp.read_bytes()),log=str(prior_log),log_sha256=sha(prior_log.read_bytes()),command_exit=prior['command_exit'],all_children_reaped=True,qualified=False),scope='Exactly one unmodified native grouped call per viewport, not20individual runs. Same native assertions/waits/timeouts; all15parts/10minfit never claimed.');save('BINDING.json',binding)
steps=[];started_calls=[];pending=None;failure=None;start=time.monotonic()
def native(view):
 global pending
 guard();C.floors();shots=out/view;shots.mkdir();env=dict(E,SMOKE_VIEWPORT=view,SMOKE_SHOTS=str(shots));rp=out/(view+'-REAPER.json');pending=view;started_calls.append(view);save('CURRENT-CALL.json',dict(viewport=view,stage_selector=stage,started=C.now(),command=cmd,log=str(out/(view+'.log')),reaper=str(rp)));t=time.monotonic()
 with(out/(view+'.log')).open('x')as log:q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','taskset','-c','0,1,3,4',*cmd],cwd=C.A,env=env,stdout=log,stderr=subprocess.STDOUT)
 r=json.loads(rp.read_bytes());pending=None if r['all_children_reaped']else view;text=(out/(view+'.log')).read_text();clean=re.sub(r'\x1b\[[0-9;]*m','',text);audit=re.findall(r'^(\d+) staged-section check\(s\) \(stage '+re.escape(stage)+r' of 15\), (\d+) always-on check\(s\)$',clean,re.M);summary=re.findall(r'^(\d+) passed, (\d+) failed$',clean,re.M);label='desktop 1280x800'if view=='desktop'else'mobile 390x780';passed_lines=[line for line in clean.splitlines()if re.match(r'^  pass  ',line)];has=lambda s:any(s in line for line in passed_lines)
 predicates=dict(native_exit=q.returncode==0 and r['command_exit']==0,all_children_reaped=r['all_children_reaped'],exact_native_stage_audit=len(audit)==1 and int(audit[0][0])>0 and int(audit[0][1])>0,native_summary_zero_failed=bool(summary)and int(summary[-1][1])==0,no_FAIL_lines=not bool(re.search(r'^\s*FAIL\s',clean,re.M)),native_footer_PASS=bool(re.search(r'^SMOKE PASS$',clean,re.M)),native_suite_completed=has(label+': the suite body ran to completion'),native_zero_page_errors=has(label+': zero page errors'),native_vendor_no_page_error=has('vendor: meshopt import raises no page error'))
 row=dict(viewport=view,stage_selector=stage,logical_parts=parts,real_native_calls=1,command=cmd,exit=q.returncode,native_command_exit=r['command_exit'],seconds=time.monotonic()-t,all_children_reaped=r['all_children_reaped'],native_audit_staged_checks=int(audit[0][0])if len(audit)==1 else None,native_audit_always_on_checks=int(audit[0][1])if len(audit)==1 else None,native_summary=summary[-1]if summary else None,predicates=predicates,passed=all(predicates.values()),native_footer=clean.splitlines()[-20:],log_sha256=sha((out/(view+'.log')).read_bytes()),reaper_sha256=sha(rp.read_bytes()),screenshots=[dict(path=str(q),sha256=sha(q.read_bytes()),bytes=q.stat().st_size)for q in sorted(shots.glob('*.png'))]);steps.append(row);save('STEPS.json',steps);guard();return row
try:
 for view in views:
  row=native(view)
  if not row['passed']:raise RuntimeError('Actual grouped native '+view+' failed; remaining coverage is not qualified')
except BaseException as error:failure=type(error).__name__+': '+str(error)
finally:
 reaped=pending is None and all(r['all_children_reaped']for r in steps);guards_exact=True;guard_error=None
 try:guard()
 except BaseException as error:guards_exact=False;guard_error=type(error).__name__+': '+str(error)
 retired=False
 if reaped:
  assert marker.read_text()==a.expect_head+'\n';shutil.rmtree(tmp);retired=True
 capacity=dict(workspace_free=shutil.disk_usage('/workspace').free,tmp_free=shutil.disk_usage('/tmp').free);floors=capacity['workspace_free']>=536870912 and capacity['tmp_free']>=1800000000;full=failure is None and reaped and retired and floors and guards_exact and len(started_calls)==len(steps)==2 and all(r['passed']for r in steps)
 save('RESULT.json',dict(status='ACTUAL_40453_NATIVE_GROUPED_CHANGED_SOURCE_MAP_BOTH_PASS'if full else'ACTUAL_40453_NATIVE_GROUPED_CHANGED_SOURCE_MAP_NOT_QUALIFIED',at=C.now(),head=a.expect_head,tree=a.expect_tree,parents=binding['parents'],branch=a.expect_branch,ticket=a.ticket,stage_selector=stage,logical_required_parts=parts,planned_real_native_calls=2,actual_real_native_calls=len(started_calls),completed_native_call_records=len(steps),started_viewports=started_calls,planned_logical_coverage_cells=20,qualified_logical_coverage_cells=[dict(part=part,viewport=r['viewport'],via_one_native_grouped_call=True)for r in steps if r['passed']for part in parts]if guards_exact else[],twenty_individual_native_runs_NOT_claimed=True,full_changed_source_map_BOTH_ACTUALLY_passed=full,all_children_reaped=reaped,pending_or_unclosed_call=pending,guards_before_after_exact=guards_exact,guard_error=guard_error,failure=failure,own_TMP_retired=retired,capacity_after=capacity,caller_floors_passed=floors,total_actual_seconds=time.monotonic()-start,steps=steps,native_assertions_waits_timeouts_and_viewports_unchanged=True,whole15part_renderer_gate_NOT_claimed=True,fits_10min_foreground_NOT_claimed=True,prior_incomplete_call_qualified=False,no_new_source_Git_API_meter_mutation=True))
print((out/'RESULT.json').read_text(),flush=True);raise SystemExit(0 if full else 1)
