40453 grouped native published smoke adapter — preparation only

Root first owns/reaps/closes the interrupted oldstage14desktop call and archives it asNQ; it has noSMOKEPASS and cannotcreditanycell. The adapter reads its closedreaper/log hashes and rejects anyoldsuccessfulleg reuse. No oldfolder/proof/common file is written or copied. Pythonbytecode is disabled beforeimporting pinnedfrozenV3common; its committed binder guards exact40453/tree2b60/twoparents, gate/CP/all7/stagedsource/currentdata/publication/config/index/refs. Ownrunner/save neverchanges C.O.

Rootcommand afteroldCPU/TMP lease isreleased:

python3 /workspace/T3262-v3-grouped-smoke-prep-first-fort-20261030/run.py --expect-head 40453bde8ba1812925d61fef118782a30323f98e --expect-tree 2b609b8461f000730de75dd4672275ca5115fa8d --expect-merge-parent 2378484c31b91a1b8d28fd8430d2b4d1a783bdaa --expect-branch steward/t3262-phone-renderer-memory --ticket T-3262 --outdir /workspace/T3262-40453-grouped-published-BOTH-root-20261030 --execute

There are exactly2 planned realnativecalls: desktop thenmobile. Both use unchanged `node tools/smoke_renderer.mjs --published` and nativeSMOKE_STAGE=1-3,7-12,14; existingnativeparser itselfselects all10requiredparts inonebody, preservingallchecks/sharedchecks/always-on/vendor/pageerror work. Nativeassertions/waits/timeouts/viewports areunchanged; actualelapsed isreportedhonestly andno10minfit isclaimed. This removes18duplicated startups, notassertions.

A realcall qualifies only with exit0/reaperallclosed, the exactnative groupedstageauditline withpositive stagedand always-oncounts, nativezero-failedsummary/noFAILlines, suitebodycompletion/zero-page-errors/vendor-no-pageerror checks andSMOKEPASS. Bothsourceguards musthold. The receipt says2actualrealcalls/20logicalcells, NEVER20individualruns; no perpartindividualPASS/timings areinvented. All15rendererparts arenotclaimed. A failedcall stopsremainingcoverage andsaveshonestNQ.

Newownoutdir contains everylog/reaper/binding/steps/rawscreenshot/currentcall/result; ownshort/workspace/v3-grp TMP isretiredonlyafterownmarker andallstartedchildrenreaped. BeforestartWS512MiB+24MiBreserve/TMPcaller1.8GB unchanged; aftercleanupcallerfloorschecked. Adapterwritesno primary/source/index/ref/API/oldproof/nativecode and launchesnometer. No runtime executed duringpreparation.
