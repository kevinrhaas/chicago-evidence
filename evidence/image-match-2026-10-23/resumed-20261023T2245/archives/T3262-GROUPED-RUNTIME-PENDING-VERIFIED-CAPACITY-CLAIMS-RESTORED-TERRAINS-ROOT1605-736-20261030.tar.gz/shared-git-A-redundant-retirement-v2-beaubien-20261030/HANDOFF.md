Actual terminal exit0 and all native readbacks reaped. Only separately root-approved redundant A .pack/.idx/.rev were unlinked after full fresh equality, native object/FD/mmap/dependency/source guards. Older B remains fully verified by actual SHA1/footer/header/count and real native verify-pack, and contains every one of the96,935 A OIDs. No private commits or model/source objects were discarded; only duplicate pack encoding was removed.

Physical workspace increased8,756,207,616B to9,330,860,032B at receipt; summed original allocated statistics were8,759,713,792B, so report actual free delta rather than promise index/reverse-index allocation reclaim. Shared TMP unchanged.

The initial preunlink refusal remains immutable in the sibling V1 packet. Separate root direction allowed only historical primary-index mtime/ctime refresh with byteSHA/inode/size/mode/nlink/indexstage/flags/status identical; this did not alter index timestamps or relax fresh before/after authority equality.

The two old lighthouse terrain working-copy files remain retired, with original untracked restore note and immutable canonical Git blobs intact. Do not restore them until separate root grant; no other model or cleanup operation is part of this closure.
