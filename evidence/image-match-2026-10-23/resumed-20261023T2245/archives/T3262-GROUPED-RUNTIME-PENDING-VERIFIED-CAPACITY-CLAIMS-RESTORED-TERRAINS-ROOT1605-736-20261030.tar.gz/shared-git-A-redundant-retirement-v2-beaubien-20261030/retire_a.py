#!/usr/bin/env python3
"""Explicit root-granted deletion of exactly three redundant A files; no Git mutation commands."""
from pathlib import Path
import os,json,hashlib,importlib.util,time,subprocess,selectors,signal,stat,datetime,shutil
os.sched_setaffinity(0,{2});os.nice(19)
OUT=Path(__file__).resolve().parent;V=Path('/workspace/shared-git-B-survivor-verifier-v2-beaubien-20261030/verify_b.py');PROOF=Path('/workspace/shared-git-B-survivor-actual-v2-root-20261030')
assert os.environ.get('ROOT_REDUNDANT_A_RETIRE_GRANT')=='only-verified-redundant-A-pack-idx-rev'
assert hashlib.sha256(V.read_bytes()).hexdigest()=='4812123fa8127d199fc776c5d6320a68ddd09cae04576a1b59fb65c40cd9eb3f'
spec=importlib.util.spec_from_file_location('verified_B_helper',V);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.DEADLINE=300
START=time.monotonic();CHILD=None

def reap():
 global CHILD
 if CHILD:
  try:os.killpg(CHILD.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:CHILD.wait(timeout=3)
  except subprocess.TimeoutExpired:
   try:os.killpg(CHILD.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   CHILD.wait(timeout=5)
  CHILD=None

def stop(sig,frame):raise InterruptedError(str(sig))
signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)

def readobject(oid,expected_bytes=None,expected_sha=None):
 global CHILD
 cmd=[m.GIT,'--no-optional-locks','-c','protocol.allow=never','-c','core.packedGitWindowSize=16m','-c','core.packedGitLimit=64m','-c','core.deltaBaseCacheLimit=32m','-C',str(m.ROOT),'cat-file','blob',oid]
 CHILD=subprocess.Popen(cmd,env=m.E,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);pid=CHILD.pid;sel=selectors.DefaultSelector();sel.register(CHILD.stdout,selectors.EVENT_READ,'out');sel.register(CHILD.stderr,selectors.EVENT_READ,'err');h=hashlib.sha256();count=0;errors=bytearray();begin=time.monotonic()
 while sel.get_map():
  m.checktime();assert time.monotonic()-begin<60,'native object readback60s deadline'
  for key,_ in sel.select(.2):
   b=os.read(key.fd,1048576)
   if not b:sel.unregister(key.fileobj);continue
   if key.data=='out':h.update(b);count+=len(b)
   else:errors.extend(b);assert len(errors)<8192
 rc=CHILD.wait(timeout=3);CHILD=None;assert rc==0,(oid,rc,errors.decode(errors='replace'))
 if expected_bytes is not None:assert count==expected_bytes
 if expected_sha is not None:assert h.hexdigest()==expected_sha
 return {'OID':oid,'bytes':count,'sha256':h.hexdigest(),'native_exit':rc,'pid':pid,'reaped':True}

def readbacks():
 objects=[('9e56099d72a013ae8a6cac22deab5aabb92d84ef',30621836,'6e0ac8f7a527e6ab1a3e4ad0920294b75d0a191c08523200b78603be82b22611'),('7f2e52f2872a09f10dad03e44ab411117d3a9ad3',30004072,'7355878e618d7ed37dcbd65fab5c99fe64c9599b6c83ba2066e683d1465e48cf')]
 for p in sorted(before['source7_sha256']):
  oid=m.git(m.ROOT,'rev-parse','HEAD:'+p).decode().strip();objects.append((oid,(m.ROOT/p).stat().st_size,before['source7_sha256'][p]))
 return [readobject(*obj)for obj in objects]

def active_references():
 paths={str(p)for p in targets+survivors};inodes={(s['stat']['dev'],s['stat']['ino'])for s in deps['target_sidecars']};hits=[];protected=[];zombies=0
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  pid=int(proc.name)
  for key in ['cwd','exe']:
   try:v=os.readlink(proc/key)
   except OSError:continue
   if v in paths:hits.append([pid,key,v])
  try:
   cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
   if any(v in cmd for v in paths):hits.append([pid,'argv','target path'])
  except OSError:pass
  try:fds=list((proc/'fd').iterdir())
  except (PermissionError,FileNotFoundError):
   try:d=dict(x.split(':',1)for x in(proc/'status').read_text().splitlines()if ':'in x)
   except FileNotFoundError:continue
   if d['State'].strip().startswith('Z'):zombies+=1
   else:
    name=d['Name'].strip();assert (pid,name)in {(125,'dockerd'),(176,'containerd')}and set(d['Uid'].split())=={'65534'},('unclassified inaccessible process',pid,name)
    protected.append({'pid':pid,'name':name,'classification':'same unrelated protected65534daemon; no visible target metadata'})
   continue
  for fd in fds:
   try:s=fd.stat();v=os.readlink(fd)
   except OSError:continue
   if (s.st_dev,s.st_ino)in inodes or v in paths:hits.append([pid,'fd',v])
  try:maps=(proc/'maps').read_text(errors='replace')
  except OSError:continue
  if any(v in maps for v in paths):hits.append([pid,'mmap','target path'])
 assert not hits,('live target consumers',hits)
 return {'visible_affected_FD_argv_mmap':0,'inaccessible_zombies':zombies,'classified_unrelated_protected_daemons':protected}

try:
 proof=json.loads((PROOF/'RESULT.json').read_text());baseline=json.loads((PROOF/'BEFORE.json').read_text());assert proof['status']=='SURVIVOR_B_FULL_PACK_CHECKSUM_AND_NATIVE_VERIFY_PASS_NO_RETIREMENT'and proof['native']['exit_code']==0 and proof['reaper_complete']
 before=m.authority()
 # Root explicitly accepts ONLY historical byte-identical primary-index time refresh.
 historical=json.loads(json.dumps(baseline['authority']));oldidx=historical['admin'][0]['files']['index'];nowidx=before['admin'][0]['files']['index'];assert oldidx['sha256']==nowidx['sha256']
 historical_index_time_refresh={key:{'verified_receipt':oldidx['stat'][key],'fresh':nowidx['stat'][key]}for key in ['mtime_ns','ctime_ns']}
 for key in ['mtime_ns','ctime_ns']:oldidx['stat'][key]=nowidx['stat'][key]
 assert before==historical,'nonpermitted authority drift since verifiedB receipt'
 a,oa=m.idx(m.A);b,ob=m.idx(m.B);assert oa==ob and a==baseline['bindings']['indexes'][0]and b==baseline['bindings']['indexes'][1];deps=m.deps();assert deps==baseline['bindings']['dependencies'],'pack/sidecar/dependency drift since verified B'
 targets=[m.PACK/(m.A+ext)for ext in ['.pack','.idx','.rev']];survivors=[m.PACK/(m.B+ext)for ext in ['.pack','.idx','.rev']]
 assert all(p.is_file()and not p.is_symlink()and p.stat().st_nlink==1 for p in targets)
 native_before=readbacks();fd=active_references();assert m.authority()==before and m.deps()==deps
 pre={'status':'ALL_PRECONDITIONS_PASS_EXPLICIT_ROOT_ONE_FAMILY_GRANT','verified_B_receipt':str(PROOF/'RESULT.json'),'verified_B_result_sha256':m.sha(PROOF/'RESULT.json'),'authority':before,'historical_primary_index_only_timestamp_refresh':historical_index_time_refresh,'original_refusal_manifest_sha256':'04e63d4a3ce681088454966b43f4b8ff13c7427aedbd1033c6d1230324afb951','deps':deps,'A_index':a,'B_index':b,'exact_96935_OID_coverage':True,'native_before':native_before,'fresh_consumers':fd}
 (OUT/'PREFLIGHT.json').write_text(json.dumps(pre,indent=2)+'\n')
 # Final identity/coverage/dependency/consumer checks precede the only mutation.
 assert m.deps()==deps;assert m.idx(m.A)==(a,oa)and m.idx(m.B)==(b,ob);fd=active_references();assert m.authority()==before
 space_before=shutil.disk_usage('/workspace').free;tmp_before=shutil.disk_usage('/tmp').free;allocated=sum(p.stat().st_blocks*512 for p in targets)
 for p in targets:p.unlink()
 assert all(not p.exists()for p in targets)
 native_after=readbacks();assert [{k:v for k,v in x.items()if k not in ['pid']}for x in native_after]==[{k:v for k,v in x.items()if k not in ['pid']}for x in native_before]
 b2,ob2=m.idx(m.B);assert b2==b and ob2==oa
 after=m.authority();assert after==before
 finaldeps=m.deps();assert finaldeps=={**deps,'target_sidecars':[x for x in deps['target_sidecars']if not Path(x['path']).name.startswith(m.A)]}
 result={'status':'ONLY_EXPLICIT_REDUNDANT_A_PACK_IDX_REV_RETIRED_B_96935_OBJECTS_PRESERVED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'removed':[str(p)for p in targets],'allocated_removed_B':allocated,'workspace_before_B':space_before,'workspace_after_B':shutil.disk_usage('/workspace').free,'TMP_before_B':tmp_before,'TMP_after_B':shutil.disk_usage('/tmp').free,'actual_net_workspace_delta_B':shutil.disk_usage('/workspace').free-space_before,'B_survivor_index_exact_96935_OID_coverage_before_after':True,'B_verified_pack_and_owned_sidecars_identity_unchanged':True,'critical_native_terrain2_and_source7_readbacks_before':native_before,'critical_native_terrain2_and_source7_readbacks_after':native_after,'all_private_refs_registered_worktree_admin_index_flags_config_source7_and_resident_statmaps_preserved':True,'all_source_bytes_preservation_scope':'critical7 exactbyteSHA plus alltracked resident statmaps, no producer/source writes; everyAobject retained in verified B','fresh_FD_mmap':fd,'historical_primary_index_only_timestamp_refresh':historical_index_time_refresh,'fresh_authority_including_index_timestamps_exact_before_after':True,'wall_seconds':time.monotonic()-START,'all_native_children_reaped':CHILD is None,'old_terrain_file_restoration_authorized':False,'no_other_deletions_or_Git_mutating_commands':True}
 (OUT/'RETIRED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if not k.startswith('critical_native')},indent=2))
finally:reap()
