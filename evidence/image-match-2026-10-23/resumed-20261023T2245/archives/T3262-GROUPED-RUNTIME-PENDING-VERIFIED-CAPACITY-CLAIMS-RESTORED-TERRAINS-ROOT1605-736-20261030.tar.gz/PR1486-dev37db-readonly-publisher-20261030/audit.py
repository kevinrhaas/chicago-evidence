from pathlib import Path
import os,json,importlib.util,time,concurrent.futures,datetime
os.sched_setaffinity(0,{2});os.nice(19)
p=Path(__file__).parent;s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);base='a24805f821224e423d114e89d91326a75a44b837';tip='37db624c3983b17db2b64354c5036455fc79c2de'
qs={'compare':'compare/'+base+'...'+tip,'tip':'git/commits/'+tip,'fresh':'git/ref/heads/dev?codex_read='+str(time.time_ns())}
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:r=dict(ex.map(lambda z:(z[0],m.api(z[1])),qs.items()))
j=r['compare'];assert j['merge_base_commit']['sha']==base and len(j['files'])<100
out={'status':'EXACT_IMMUTABLE_A248_TO37DB_SCOPE_READONLY','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'tip':tip,'tree':r['tip']['tree']['sha'],'fresh_actualdev':r['fresh']['object']['sha'],'no_chase_newtips':True,'total_commits':j['total_commits'],'commits':[{'sha':c['sha'],'parents':[a['sha']for a in c['parents']],'subject':c['commit']['message'].splitlines()[0]}for c in j['commits']],'files':[{'path':f['filename'],'status':f['status'],'blob':f['sha'],'additions':f['additions'],'deletions':f['deletions']}for f in j['files']]}
(p/'COMPARE-SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n');patch={f['filename']:f.get('patch')for f in j['files']if f['filename'].endswith(('.py','.js','.mjs'))or f['filename'].endswith(('assets/manifest.json','assets/manifest.web.json'))};(p/'PRODUCER-AND-MANIFEST-PATCHES.json').write_text(json.dumps(patch,indent=2)+'\n');print(json.dumps(out,indent=2));print('PATCHES',json.dumps(patch,indent=2))
