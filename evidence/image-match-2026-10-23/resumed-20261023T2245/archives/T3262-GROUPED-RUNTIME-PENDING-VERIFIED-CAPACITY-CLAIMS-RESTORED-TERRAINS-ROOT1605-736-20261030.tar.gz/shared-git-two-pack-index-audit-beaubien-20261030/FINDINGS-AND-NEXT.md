# Exact two-pack index coverage, read-only

Both v2 indexes contain exactly 96,935 objects. Their complete sorted OID tables are equal (SHA256 34dc6b45cc5c2fde6f0b9a06f10f4f31c0978c160040c675d16d2c3f6497f2e6); both directional differences are zero. Both indexes have valid stored/computed SHA1 checksums, strict sorted unique OIDs, and fanout tables that reproduce the OID table. Their stored pack checksums agree with their filenames. This proves exact advertised OID coverage; it does not establish valid surviving object payloads or authorize retirement.

A: pack-af7f4707b5c1dfa2fc9470dff818f74c796080e4
- Pack 8,756,202,282 bytes / 8,756,207,616 allocated; mtime 2026-10-30T08:44:05.307321+00:00.
- Index 3,114,252 bytes; mtime 2026-10-22T20:59:53.106045+00:00.
B: pack-d9f146b2a772477817d63ff619703c55bc5124d0
- Pack 8,753,349,340 bytes / 8,753,352,704 allocated; mtime 2026-10-22T20:58:19.297814+00:00.
- Index 3,104,532 bytes; mtime 2026-10-22T20:58:19.333814+00:00.

Only the two small indexes and filesystem metadata were read. No pack body/footer, Git command, source/index/ref/config mutation, removal, repack, prune or GC occurred. Complete before/after file metadata is in INDEX-COMPARISON.json. No evidence of actual reclaimability is asserted.

## Separate proposed verification after the current source gate

1. Root must schedule an exclusive shared-object-store inspection phase and authorize its bounded resource/time envelope. Capture current shared Git configuration, alternates/promisor state, all refs including private/worktree branches, every registered worktree HEAD/index/flags/status and current required source hashes. Preserve this as a before/after guard. Account for all registered worktree/reflog/private commit authority; do not use only origin/dev reachability as the authority boundary.
2. Provisionally consider A the survivor because its pack mtime is newer, not because the indexes prove it healthy. Recheck both paths' inode/size/mode/link/mtime/ctime, exact index checksums and complete OID equality against this report; any drift stops this proposal. Check .keep/.promisor/reverse-index/MIDX/bitmap sidecars, actual active Git processes/open FDs, and all shared worktree consumers. No sidecar may be removed under this proposal.
3. In that later approved phase only, stream the survivor pack SHA1 over bytes excluding its final20-byte footer, then compare computed SHA1 with the actual footer AND the stored pack checksum from its verified index. This requires reading the 8.76GB survivor and has NOT been done. Revalidate full index SHA1/fanout/OIDs. Run genuine read-only Git verify-pack against the survivor .idx to validate compressed object payloads and delta/base closure; a valid name/OID list alone is insufficient. Avoid Git commands that write a new index or pack. Any error stops with both packs retained.
4. Compare the complete verified OID inventory again and demonstrate that every object advertised in the proposed retired pack remains in the verified survivor. Check all current local refs, worktree/private heads and required source/recipe/blob authority against the complete preserved local object inventory. If any referenced authority depends on an unverified payload or an external unresolved delta, stop; do not infer safety from a sample of model blobs.
5. Reverify the full source/ref/worktree/config guard map. Return the actual verification receipt, exact candidate pack+index+sidecar mapping, filesystem allocation/nlink/FD facts and explicit restore/retention plan to root for a SEPARATE retirement decision. Neither this report nor a successful future verify-pack authorizes unlink/repack/gc/prune. No amount of reclaimable space is promised here.
