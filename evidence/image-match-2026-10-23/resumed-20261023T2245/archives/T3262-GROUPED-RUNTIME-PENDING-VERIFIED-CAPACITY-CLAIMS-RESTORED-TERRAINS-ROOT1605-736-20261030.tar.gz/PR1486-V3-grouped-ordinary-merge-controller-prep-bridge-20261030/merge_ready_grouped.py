"""Read-only grouped-proof qualification; --merge permits one ordinary expected-SHA PR1486 merge."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,re,sys,time
from urllib.request import Request,urlopen
sys.dont_write_bytecode=True
HELPER=Path('/workspace/T3262-v3-237-merge-publication-prep-bridge-20261030/publish_merge_v3.py')
assert hashlib.sha256(HELPER.read_bytes()).hexdigest()=='cde0754553ff3ebba704404f9cee6930c89d95e0f8d55363aa4b78b4e33d078d'
s=importlib.util.spec_from_file_location('reviewed_native_transport',HELPER);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
R=m.SOURCE;A=R/'chicago/4d';DEV='2378484c31b91a1b8d28fd8430d2b4d1a783bdaa';PARENTS=['89ad07fd2b43679c028715dbf30830b7dacf2a54',DEV];BRANCH=m.BRANCH;OWN=m.OWN;STAGES={14,1,2,3,7,8,9,10,11,12}
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(path):
 p=Path(path);raw=p.read_bytes();return json.loads(raw),sha(raw)
def reaped(path):
 d,_=read(path);assert d['command_exit']==0 and d['all_children_reaped']is True;return d
def exact_map(values):
 for p,h in values.items():
  q=R/p
  if h is None:assert not q.exists()and not q.is_symlink()
  else:assert re.fullmatch('[0-9a-f]{64}',h)and sha(q.read_bytes())==h,p

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for k in ['head','tree','gate','checkpoint','phone','smoke','publication','output']:ap.add_argument('--'+k,required=True)
 ap.add_argument('--merge',action='store_true');ap.add_argument('--merge-method',choices=['auto','merge','squash'],default='auto');a=ap.parse_args();os.sched_setaffinity(0,{2});os.nice(19)
 assert re.fullmatch('[0-9a-f]{40}',a.head)and re.fullmatch('[0-9a-f]{40}',a.tree)
 out=Path(a.output).resolve();assert out!=R and R not in out.parents and not out.exists();out.mkdir()
 save=lambda n,d:(out/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
 before=m.snapshot();save('SOURCE-BEFORE.json',before);assert before['HEAD']==a.head and not before['status']and not(R/'.git/MERGE_HEAD').exists()and m.git('branch','--show-current').decode().strip()==BRANCH
 native=m.commit(a.head);assert native['tree']==a.tree and native['parents']==PARENTS
 gate,gh=read(a.gate);cp,ch=read(a.checkpoint);phone,ph=read(a.phone);smoke,sh=read(a.smoke);pub,puh=read(a.publication);gb=gate['binding'];seven=gb['all7_source_sha256']
 assert gate['status']=='ACTUAL_T3262_V3_CURRENTDEV_INTEGRATION_FULL_SOURCE_CHECK_PASS'and gate['exit']==0 and all(v is True for v in gate['guards'].values())and gate['config_unchanged']is True
 assert {'HEAD','staged_tree','tracked_working_bytes','no_untracked','no_conflicts','staged_path_sha256','all_children_reaped'}<=set(gate['guards'])
 assert any('CHECK PASS'in line for line in gate['footer'])and gb['revision']=='V3_CURRENTDEV_237'and gb['head']==gb['source_head']==PARENTS[0]and gb['merge_parent']==gb['pr_base']==DEV and gb['checked_final_staged_tree']==a.tree and gb['branch']==BRANCH and gb['ticket']=='T-3262'
 assert set(seven)==OWN and gb['source_config_sha256']==sha((R/'.git/config').read_bytes());exact_map(seven);exact_map(gb['all_staged_paths']);reaped(Path(a.gate).parent/'check-REAPER.json')
 assert cp['status']=='ACTUAL_T3262_V3_CURRENTDEV_INTEGRATION_NATIVE_MERGE_CHECKPOINT_PASS'and cp['revision']=='V3_CURRENTDEV_237'and cp['head']==a.head and cp['tree']==a.tree and cp['parents']==PARENTS and cp['source_gate_sha256']==gh and cp['source_gate_exact_tree']is True and cp['source_clean']is True and cp['only_own_branch_ref_changed']is True and cp['all7_source_sha256']==seven and cp['branch']==BRANCH and cp['ticket']=='T-3262'
 assert cp['pr_base']==DEV and cp['own4_postimages']==gb['own4_postimages']and len(cp['steps'])==3 and{r['name']for r in cp['steps']}=={'changelog-entry','ticket-ids','fold-history'}
 for row in cp['steps']:assert row['exit']==0 and row['all_children_reaped']is True;reaped(Path(a.checkpoint).parent/(row['name']+'-REAPER.json'))
 def same_runtime(d):
  assert d['revision']=='V3_CURRENTDEV_237'and d['head']==a.head and d['tree']==a.tree and d['parents']==PARENTS and d['source_parent']==PARENTS[0]and d['merge_parent']==DEV and d['all7_source_sha256']==seven and d['source_gate_sha256']==gh and d['native_checkpoint_sha256']==ch and d['branch']==BRANCH and d['ticket']=='T-3262'
 same_runtime(phone)
 assert phone['status']=='ACTUAL_T3262_V3_CURRENTDEV_237_NATIVE_PHONE_PASS'and phone['exit']==0 and phone['errors']==[]and phone['all_children_reaped']is True and phone['own_short_TMP_retired']is True and phone['phone_unchanged_limit_MiB']==400 and phone['source_index_semantics_config_refs_all7paths_and_critical_publication_guards_before_after_exact']is True
 pp=Path(a.phone).parent;measurement,mh=read(pp/'PHONE-V3.json');pb,pbh=read(pp/'PHONE-V3-BINDING.json');assert phone['actual_measurement_json']==str(pp/'PHONE-V3.json')and phone['actual_measurement_sha256']==mh
 assert len(measurement['rows'])==1;mr=measurement['rows'][0];assert mr['year']=='1904'and mr['viewport']=='mobile'and mr['errors']==[]and 0<mr['totals']['total']<=400*1048576 and phone['actual_complete_1904_mobile_peak_MiB']==mr['totals']['total']/1048576
 expected_phone=['node','tools/measure_memory.mjs','--year','1904','--only','mobile','--gate','--no-snapshot','--json',str(pp/'PHONE-V3.json')];assert phone['command']==pb['command']==expected_phone
 prp=reaped(pp/'phone-v3-REAPER.json');assert prp['command']==['taskset','-c','0,1,3,4',*expected_phone]
 same_runtime(pb);assert pb['memory_limit_bytes']==400*1048576 and pb['memory_config_sha256']==sha((A/'tools/memory_ceilings.json').read_bytes())and json.loads((A/'tools/memory_ceilings.json').read_bytes())['ceilings']['1904']['mobile']['total_bytes']==400*1048576
 # Grouped native adapter has two real calls and twenty logical coverage pairs.
 # The complete common binding carries the same source/gate/checkpoint identities.
 grouped=Path('/workspace/T3262-v3-grouped-smoke-prep-first-fort-20261030/run.py')
 assert sha(grouped.read_bytes())=='cc6658c00e0dca032eacea32c4abe363afed9609ba3a31ff838a793a1bc63db1'
 assert a.head=='40453bde8ba1812925d61fef118782a30323f98e'and a.tree=='2b609b8461f000730de75dd4672275ca5115fa8d'
 selector='1-3,7-12,14';parts=[1,2,3,7,8,9,10,11,12,14];views=['desktop','mobile'];native_cmd=['node','tools/smoke_renderer.mjs','--published']
 assert smoke['status']=='ACTUAL_40453_NATIVE_GROUPED_CHANGED_SOURCE_MAP_BOTH_PASS'and smoke['head']==a.head and smoke['tree']==a.tree and smoke['parents']==PARENTS and smoke['branch']==BRANCH and smoke['ticket']=='T-3262'
 assert smoke['stage_selector']==selector and smoke['logical_required_parts']==parts and smoke['started_viewports']==views
 assert smoke['planned_real_native_calls']==smoke['actual_real_native_calls']==smoke['completed_native_call_records']==2 and smoke['planned_logical_coverage_cells']==20
 for key in ['full_changed_source_map_BOTH_ACTUALLY_passed','all_children_reaped','guards_before_after_exact','own_TMP_retired','caller_floors_passed','native_assertions_waits_timeouts_and_viewports_unchanged','twenty_individual_native_runs_NOT_claimed','whole15part_renderer_gate_NOT_claimed','no_new_source_Git_API_meter_mutation']:assert smoke[key]is True,key
 assert smoke['pending_or_unclosed_call']is None and smoke['guard_error']is None and smoke['failure']is None and smoke['prior_incomplete_call_qualified']is False
 cells=smoke['qualified_logical_coverage_cells'];assert len(cells)==20 and{(r['part'],r['viewport'])for r in cells}=={(s,v)for s in STAGES for v in views}and all(r['via_one_native_grouped_call']is True for r in cells)
 sp=Path(a.smoke).parent;sb,sbh=read(sp/'BINDING.json');same_runtime(sb)
 assert sb['grouped_native_stage_selector']==selector and sb['logical_parts']==parts and sb['viewports']==views and sb['planned_real_native_calls']==2 and sb['planned_logical_coverage_cells']==20 and sb['command']==native_cmd
 assert Path(sb['outdir']).resolve()==sp.resolve()and sb['controller']==str(grouped)and sb['controller_sha256']==sha(grouped.read_bytes())
 assert sb['native_smoke_source_sha256']==sha((A/'tools/smoke_renderer.mjs').read_bytes())and sb['frozen_common_sha256']=='6532d4cf179979b97684938a0512b6bf1ce8b9115834212b09b7cced8532b9d7'
 assert phone['current_data_source_sha256']==pb['current_data_source_sha256']==sb['current_data_source_sha256']and phone['critical_current_published_sha256']==pb['critical_current_published_sha256']==sb['critical_current_published_sha256'];exact_map(pb['current_data_source_sha256']);exact_map(pb['critical_current_published_sha256']);assert sb['source_config_sha256']==pb['source_config_sha256']==gb['source_config_sha256']
 assert sb['incoming_staged_paths']==gb['all_staged_paths']and sb['memory_limit_bytes']==400*1048576 and sb['memory_config_sha256']==pb['memory_config_sha256']and sb['ordinary_PRIMARY_native_publication_no_fixture']is True
 # The interrupted earlier first call remains negative evidence, never a pass.
 prior=sb['old_first_incomplete_call'];prior_reaper,prior_rh=read(prior['reaper']);prior_log=Path(prior['log']).read_bytes()
 assert prior_rh==prior['reaper_sha256']and sha(prior_log)==prior['log_sha256']and prior_reaper['all_children_reaped']is True and prior_reaper['command_exit']!=0 and prior['command_exit']==prior_reaper['command_exit']and prior['qualified']is False and not re.search(r'^SMOKE PASS$',prior_log.decode(),re.M)
 steps,_=read(sp/'STEPS.json');assert steps==smoke['steps']and len(steps)==2 and[r['viewport']for r in steps]==views
 screenshots=0
 for row in steps:
  view=row['viewport'];assert row['stage_selector']==selector and row['logical_parts']==parts and row['real_native_calls']==1 and row['command']==native_cmd
  assert row['passed']is True and row['exit']==row['native_command_exit']==0 and row['all_children_reaped']is True and row['predicates']and all(v is True for v in row['predicates'].values())
  rp_path=sp/(view+'-REAPER.json');rp=reaped(rp_path);assert sha(rp_path.read_bytes())==row['reaper_sha256']and rp['command']==['taskset','-c','0,1,3,4',*native_cmd]
  log=(sp/(view+'.log')).read_bytes();assert sha(log)==row['log_sha256'];clean=re.sub(r'\x1b\[[0-9;]*m','',log.decode())
  audit=re.findall(r'^(\d+) staged-section check\(s\) \(stage '+re.escape(selector)+r' of 15\), (\d+) always-on check\(s\)$',clean,re.M);summary=re.findall(r'^(\d+) passed, (\d+) failed$',clean,re.M)
  assert len(audit)==1 and int(audit[0][0])==row['native_audit_staged_checks']>0 and int(audit[0][1])==row['native_audit_always_on_checks']>0
  assert summary and list(summary[-1])==row['native_summary']and int(summary[-1][1])==0 and int(summary[-1][0])>0 and not re.search(r'^\s*FAIL\s',clean,re.M)and re.search(r'^SMOKE PASS$',clean,re.M)
  label='desktop 1280x800'if view=='desktop'else'mobile 390x780';passed_lines=[line for line in clean.splitlines()if re.match(r'^  pass  ',line)]
  assert all(any(required in line for line in passed_lines)for required in [label+': the suite body ran to completion',label+': zero page errors','vendor: meshopt import raises no page error'])
  assert row['native_footer']==clean.splitlines()[-20:];expected_dir=sp.resolve()/view
  for image in row['screenshots']:
   q=Path(image['path']);assert q.resolve().parent==expected_dir and q.is_file()and not q.is_symlink()and q.stat().st_size==image['bytes']and sha(q.read_bytes())==image['sha256'];screenshots+=1
 assert pub['status']=='EXACT_NATIVE_V3_GENUINE_237_MERGE_FF_PR1486_OWN7_AND_CANONICAL_INCOMING_READBACK_PASS'and pub['head']==a.head and pub['tree']==a.tree and pub['parents']==PARENTS and pub['all7_source_sha256']==seven and pub['force']is False and pub['branch_or_PR_created']is False and pub['source_HEAD_index_config_allrefs_status_unchanged']is True and pub['branch']==BRANCH and pub['PR']==1486 and pub['expected_old']==PARENTS[0]
 publication_plan,_=read(Path(a.publication).parent/'PLAN.json');assert publication_plan['gate']['sha256']==gh
 readback=pub['own7_immutable_raw_readback'];assert len(readback)==7 and{r['path']for r in readback}==OWN and all(r['sha256']==seven[r['path']]for r in readback)
 leaves=m.leaves(a.tree);incoming=m.leaves(m.commit(DEV)['tree']);assert set(m.diff(incoming,leaves))==OWN
 ownbytes={p:m.obj('blob',leaves[p][2])for p in OWN};assert all(sha(ownbytes[p])==seven[p]for p in OWN)and sum(map(len,ownbytes.values()))<=4*1024**2
 save('QUALIFIED-LOCAL-PROOFS.json',{'status':'ACTUAL_SAME_V3_SOURCE_PHONE_TWO_GROUPED_CALLS_TWENTY_LOGICAL_PAIRS_AND_PUBLICATION_VALIDATED','head':a.head,'tree':a.tree,'parents':PARENTS,'all7_source_sha256':seven,'receipt_sha256':{'gate':gh,'checkpoint':ch,'phone':ph,'smoke':sh,'publication':puh,'phone_binding':pbh,'smoke_binding':sbh},'phone_peak_MiB':phone['actual_complete_1904_mobile_peak_MiB'],'smoke_logical_coverage_pairs':20,'real_native_smoke_calls':2,'twenty_separate_native_runs_claimed':False,'screenshots_rehashed':screenshots,'no_checks_or_runtime_launched':True})
 def dev_guard():
  actual=m.api('git/ref/heads/dev')['object']['sha']
  if actual!=DEV:
   comparison=m.api('compare/'+DEV+'...'+actual);files=comparison.get('files',[]);save('REFUSED-DEV-ADVANCED.json',{'status':'REFUSED_DEV_ADVANCED_ROOT_CLASSIFICATION_REQUIRED','expected':DEV,'actual':actual,'comparison_status':comparison['status'],'file_list_may_be_truncated':len(files)>=300,'files':[{k:r.get(k)for k in ['filename','sha','status']}for r in files],'own7_path_overlap':[r['filename']for r in files if r['filename']in OWN],'no_mutation':True});raise RuntimeError('Current dev advanced; root classification required, no merge attempted')
  return actual
 def github_guard(label):
  dev_guard();pr=m.api('pulls/1486');checks=m.api('commits/'+a.head+'/check-runs?per_page=100');statuses=m.api('commits/'+a.head+'/status?per_page=100');files=m.api('pulls/1486/files?per_page=100');public=m.api('git/commits/'+a.head)
  save('GITHUB-'+label+'.json',{'PR':pr,'checks':checks,'statuses':statuses,'files':files,'head_commit':public})
  assert pr['state']=='open'and pr['draft']is False and pr['merged']is False and pr['head']['sha']==a.head and pr['head']['ref']==BRANCH and pr['base']['ref']=='dev'and pr['mergeable']is True and pr['mergeable_state']=='clean'and 'hold' not in {r['name']for r in pr['labels']}
  assert public['tree']['sha']==a.tree and[p['sha']for p in public['parents']]==PARENTS
  assert len(files)==7 and{r['filename']for r in files}==OWN and all(r['sha']==leaves[r['filename']][2]for r in files)
  runs=checks['check_runs'];assert checks['total_count']==len(runs)<=100 and runs
  assert all(r['head_sha']==a.head and r['status']=='completed'and r['conclusion']in ['success','skipped','neutral']for r in runs),'Pending/failing/cancelled actual checks refuse'
  assert any(r['name']=='gate'and r['conclusion']=='success'for r in runs),'Actual successful head gate required'
  legacy=statuses['statuses'];assert statuses['total_count']==len(legacy)<=100 and all(r['state']=='success'for r in legacy),'Actual pending/failing legacy status refuses'
  # GitHub returns aggregate statepending for an empty legacy list: no status
  # context is manufactured or backfilled. Real check runs and serverclean rule bind.
  return pr
 pr=github_guard('BEFORE')
 req=Request('https://api.github.com/repos/kevinrhaas/chicago?codex_read='+str(time.time_ns()),headers={'User-Agent':'Chicago-actual-proof-normal-merge','Accept':'application/vnd.github+json'})
 with urlopen(req,timeout=120)as response:repo=json.load(response)
 assert repo['full_name']=='kevinrhaas/chicago';method=a.merge_method
 if method=='auto':method='merge'if repo.get('allow_merge_commit')else'squash'if repo.get('allow_squash_merge')else None
 assert method in ['merge','squash']and repo.get('allow_merge_commit'if method=='merge'else'allow_squash_merge')is True
 plan={'status':'ACTUAL_ALL_V3_PREREQUISITES_AND_FRESH_GITHUB_REQUIRED_CHECKS_QUALIFIED_READONLY_NO_MERGE','head':a.head,'tree':a.tree,'expected_dev':DEV,'PR':1486,'merge_method':method,'method_selection':'Explicitcallerchoice or repository-enabled merge preferred; squash fallback. Native merge-ready script uses squash.','sole_possible_mutation':{'method':'PUT','path':'pulls/1486/merge','body':{'sha':a.head,'merge_method':method}},'no_admin_force_dispatch_status_fabrication_body_ticket_lap_or_source_action':True};save('PLAN.json',plan);assert m.snapshot()==before
 if not a.merge:print(json.dumps({'status':plan['status'],'merge_method':method}));return
 github_guard('FINAL');exact_map(seven);exact_map(pb['current_data_source_sha256']);exact_map(pb['critical_current_published_sha256']);assert m.snapshot()==before;dev_guard()
 # Sole write: GitHub's ordinary expected-head-SHA merge, subject to serverrules.
 merged=m.api('pulls/1486/merge',{'sha':a.head,'merge_method':method},method='PUT');save('MERGE-API-RESULT.json',merged);assert merged.get('merged')is True
 merge_sha=merged['sha'];assert re.fullmatch('[0-9a-f]{40}',merge_sha);actual=m.api('git/commits/'+merge_sha);assert actual['tree']['sha']==a.tree
 expected_parents=[DEV,a.head]if method=='merge'else[DEV];assert[p['sha']for p in actual['parents']]==expected_parents
 immutable=[]
 from urllib.parse import quote
 for p in sorted(OWN):
  req=Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+merge_sha+'/'+quote(p,safe='/')+'?codex_read='+str(time.time_ns()),headers={'User-Agent':'Chicago-actual-proof-normal-merge'})
  with urlopen(req,timeout=120)as response:assert response.status==200;b=response.read()
  assert b==ownbytes[p]and m.gitsha('blob',b)==leaves[p][2];immutable.append({'path':p,'bytes':len(b),'sha256':sha(b),'git_blob':leaves[p][2]})
 after_pr=m.api('pulls/1486');assert after_pr['merged']is True and after_pr['state']=='closed'and after_pr['merge_commit_sha']==merge_sha and after_pr['head']['sha']==a.head and after_pr['base']['ref']=='dev'
 current_dev=m.api('git/ref/heads/dev')['object']['sha'];later=None
 if current_dev!=merge_sha:
  comparison=m.api('compare/'+merge_sha+'...'+current_dev);assert comparison['status']=='ahead'and comparison['merge_base_commit']['sha']==merge_sha;later=m.api('git/commits/'+current_dev)
 after=m.snapshot();save('SOURCE-AFTER.json',after);assert after==before
 result={'status':'ACTUAL_ORDINARY_PR1486_MERGE_VERIFIED_WITH_IMMUTABLE_OWN7_READBACK','PR':1486,'PR_url':after_pr['html_url'],'qualified_head':a.head,'qualified_tree':a.tree,'merge_method':method,'merge_commit':merge_sha,'merge_tree':actual['tree']['sha'],'merge_parents':[p['sha']for p in actual['parents']],'merged_true_fresh':True,'immutable_pre_fold_own7':immutable,'current_dev_after':current_dev,'later_dev_commit':None if later is None else{'sha':later['sha'],'tree':later['tree']['sha'],'message':later['message'],'parents':[p['sha']for p in later['parents']]},'later_fold_or_other_dev_advance_reported_not_forced':current_dev!=merge_sha,'local_HEAD_index_config_allrefs_status_unchanged':True,'ticket_settlement_lap_release_and_original_picture_work_separate':True};save('RESULT.json',result);print(json.dumps({'status':result['status'],'merge_commit':merge_sha,'current_dev':current_dev}))
if __name__=='__main__':main()
