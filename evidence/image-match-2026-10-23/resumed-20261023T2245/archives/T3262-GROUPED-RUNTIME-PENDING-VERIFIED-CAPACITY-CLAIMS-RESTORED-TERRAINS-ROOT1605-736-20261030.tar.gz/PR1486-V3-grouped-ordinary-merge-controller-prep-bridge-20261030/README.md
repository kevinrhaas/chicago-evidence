# PR1486 grouped smoke merge guard — prepared, unrun

This separate controller preserves the original V3 ordinary merge guard and changes smoke-proof consumption to the frozen first-fort grouped adapter. The original capsule is untouched. Preparation only syntax-parsed the source; no controller, runtime, source mutation or API write was executed.

`merge_ready_grouped.py` requires actual 40453/tree2b609b84 V3 full-source and native two-parent checkpoint PASS, official unchanged400MiB phone PASS with zero errors/reaper/raw measurement, verified normal-FF publication and all seven immutable source hashes. It launches no checks or renderer.

The grouped smoke proof must be the actual adapter RESULT.json and sibling BINDING.json/STEPS.json. Exactly two genuine native calls, one desktop and one mobile, must each run selector `1-3,7-12,14`. Exact twenty unique logical stage/viewport pairs are required. The controller rehashes each real log/reaper/screenshot, parses aggregate native stage audit and positive staged/always-on counts, zero failed assertions, suite completion, zero page errors and SMOKE PASS. It binds unchanged native smoke source, the frozen controller and common helper, actual source/data/publication/gate/checkpoint identities. This is two native runs covering twenty logical pairs; it does not claim twenty separate native runs or per-part native audit counters. The earlier interrupted first call remains hashed negative evidence.

All existing source/Git/phone/publication checks, fresh GitHub checks and ordinary expected-SHA merge rules remain. The default is read-only; `--merge` permits only the original sole PUT pulls/1486/merge with the exact qualified head, ordinary merge or allowed squash, no admin/force/retry/dispatch/status/backfill/body/ticket/lap mutation. Immutable own-seven postmerge readback includes changelog at the prefold merge SHA. Local HEAD/index/config/refs/status must remain unchanged.

IMPORTANT: expected dev remains2378484c31b91a1b8d28fd8430d2b4d1a783bdaa. Current37db drift intentionally refuses and writes a bounded read-only comparison. This grouped-proof adaptation does not qualify a248/37db or silently widen the merge base. Root must separately classify actual currentdev and authorize a concrete binding before a future compatible controller can merge. REST atomically checks expected head, not expected base; fresh dev checks plus exact postmerge parents/tree remain required and are not a base CAS.

Invocation uses the original CLI with --smoke ACTUAL_GROUPED_OUTPUT/RESULT.json:

    python merge_ready_grouped.py --head 40453bde8ba1812925d61fef118782a30323f98e --tree 2b609b8461f000730de75dd4672275ca5115fa8d --gate ACTUAL/GATE-RESULT.json --checkpoint ACTUAL/CHECKPOINT-RESULT.json --phone ACTUAL/PHONE-V3-RESULT.json --smoke ACTUAL_GROUPED_OUTPUT/RESULT.json --publication ACTUAL_PUBLICATION/RESULT.json --output NEW_EXTERNAL_OUTPUT

Only an actual closed grouped PASS can qualify; partial/running/negative receipts refuse. No actual grouped PASS or merge is claimed by this preparation.
