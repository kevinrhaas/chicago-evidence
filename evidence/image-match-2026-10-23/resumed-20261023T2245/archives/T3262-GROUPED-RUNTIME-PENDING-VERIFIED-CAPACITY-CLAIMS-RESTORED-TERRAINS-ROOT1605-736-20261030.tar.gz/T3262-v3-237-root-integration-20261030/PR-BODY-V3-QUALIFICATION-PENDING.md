Reduce memory used by the 1904 railway yard within the existing 400 MiB phone limit. Compact normals and exact uniform evidence grades reduce geometry streams; spatial batches release unused initial upload records. Unreached ties and verge tufts retain smaller lossless Float32 caches, installing byte-identical matrix/colour buffers at the existing draw reach. Unusual transforms or colours retain exact fallbacks.

This addresses the owner-reported phone memory problem and the gate blocking the four picture tickets in PR1456. Only T-3262 closes here; T-2373, T-2377, T-2381 and T-2384 remain on PR1456. This is the visible-progress exception for that blocked picture parcel.

Validation on native head `40453bde` (tree `2b609b84`, genuinely integrated with dev `2378484`, including the detailed Field house and balconies):

- All 1,105 source checks and the three PR-event questions passed; 736 focused geometry, cache and lifecycle checks passed.
- The official complete 1904 mobile measurement passed at **398.969 MiB / 400**, with zero page errors. The prior integrated head measured **400.997 MiB, FAIL**; that result is preserved. The limit and measurement assertions are unchanged.
- Source, index, configuration, ref, current published-data and child-process preservation checks passed. The source wrapper's temporary-space halt was recovered by retiring only its five closed test fixtures; the original halt and unchanged native passing result are retained.
- Published desktop/mobile smoke coverage and required current-head GitHub CI are running. This PR is not yet cleared to merge.

The exact source and restart state are saved in [checkpoint734](https://github.com/kevinrhaas/chicago-evidence/blob/282be4972fbb0556920efe40d396ba3c8e995704/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md); the subsequent passing source, phone and native publication receipts are being checkpointed separately. Normal PR into dev; production remains controlled by the owner's promotion workflow.
