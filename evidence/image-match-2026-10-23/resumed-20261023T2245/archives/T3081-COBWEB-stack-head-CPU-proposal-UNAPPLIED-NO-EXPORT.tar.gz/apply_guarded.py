"""Explicit root-owned adoption only, after review; never invoked by preparation."""
import argparse,hashlib,json
from pathlib import Path

ap=argparse.ArgumentParser()
ap.add_argument('--project-root',type=Path,required=True)
args=ap.parse_args()
packet=Path(__file__).resolve().parent
root=args.project_root.resolve()
entries=json.loads((packet/'input-guards.json').read_bytes())['files']
expected={'generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py',
          'data/structures/cobweb_castle.json','docs/LIBERTIES.md','data/reconstruction/name_pool_keys.json'}
assert len(entries)==5 and {e['path'] for e in entries}==expected
writes=[]
for e in entries:
 path=root/e['path'];candidate=packet/'candidate'/e['path']
 assert not path.is_symlink() and not candidate.is_symlink()
 before=path.read_bytes();after=candidate.read_bytes()
 assert hashlib.sha256(before).hexdigest()==e['before_sha256'],e['path']+' preimage changed; rebase exact proposal'
 assert hashlib.sha256(after).hexdigest()==e['after_sha256'],e['path']+' candidate changed'
 writes.append((path,before,after))
done=[]
try:
 for path,before,after in writes:
  assert path.read_bytes()==before,path
  path.write_bytes(after);done.append((path,before))
except Exception:
 for path,before in reversed(done):path.write_bytes(before)
 raise
print('Applied5 reviewed authored files, uncommitted; official82 refresh and gates still owed.')
