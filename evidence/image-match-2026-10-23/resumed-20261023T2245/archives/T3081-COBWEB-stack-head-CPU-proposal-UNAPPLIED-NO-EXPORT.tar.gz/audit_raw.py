"""CPU-only raw-mesh parity and stack-head arithmetic. No Blender/writers/gate."""
from pathlib import Path
from types import ModuleType
from dataclasses import asdict
import hashlib,inspect,json,math,sys

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
LIVE=Path('/tmp/chicago-log-integration/chicago/4d')
BEFORE=OUT/'before';AFTER=OUT/'candidate'
sys.path[:0]=[str(LIVE/'generators'),str(LIVE/'tools')]
sys.modules['bpy']=ModuleType('bpy')
def load(name,path):
 m=ModuleType(name);m.__file__=str(path);sys.modules[name]=m
 exec(compile(path.read_text(),str(path),'exec'),m.__dict__)
 return m
oldparams=load('old_head_params',BEFORE/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=oldparams
before=load('old_head_builder',BEFORE/'generators/archetypes/log_dwelling.py')
newparams=load('new_head_params',AFTER/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=newparams
after=load('new_head_builder',AFTER/'generators/archetypes/log_dwelling.py')
from common.mesh import MeshBuilder
class Raw(MeshBuilder):
 def to_object(self,mats=None):self.materials=mats;return self
for module in [before,after]:
 module.MeshBuilder=Raw
 module.simple_material=lambda *a,**kw:(a,kw)
def raw(obj):return obj.verts,obj.faces,obj.conf,obj.mat_index,obj.named,obj.materials
def digest(obj):return hashlib.sha256(json.dumps(raw(obj),sort_keys=True).encode()).hexdigest()

assert inspect.signature(oldparams.LogDwellingParams)==inspect.signature(newparams.LogDwellingParams)
scope=[]
manifest=json.loads((LIVE/'assets/manifest.json').read_bytes())['assets']
for path in sorted((LIVE/'data/structures').glob('*.json')):
 source_bytes=path.read_bytes();record=json.loads(source_bytes)
 if record.get('archetype')!='log_dwelling':continue
 for phase in record.get('phases',[]):
  key=record['id']+'__'+phase['id']+'.glb'
  if key in manifest:scope.append((key,record,phase,source_bytes))
assert len(scope)==82,len(scope)
rows=[];old_cobweb=None
for key,record,phase,source_bytes in scope:
 a=oldparams.from_phase(phase,record);b=newparams.from_phase(phase,record)
 assert asdict(a)==asdict(b),key
 x=before.build(a,key[:-4]);y=after.build(b,key[:-4])
 assert raw(x)==raw(y),key
 rows.append({'asset':key,'current_record_raw_exact':True,'raw_sha256':digest(y),
              'source_record_sha256':hashlib.sha256(source_bytes).hexdigest()})
 if record['id']=='cobweb_castle':old_cobweb=x
 snapshot=OUT/'current-records'/('data/structures/'+record['id']+'.json')
 snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(source_bytes)

record=json.loads((AFTER/'data/structures/cobweb_castle.json').read_bytes())
phase=next(p for p in record['phases'] if p['id']=='log_1820')
params=newparams.from_phase(phase,record)
candidate=after.build(params,'cobweb_castle__log_1820')
assert candidate.faces==old_cobweb.faces
assert candidate.mat_index==old_cobweb.mat_index
assert candidate.conf==old_cobweb.conf
assert candidate.named==old_cobweb.named and candidate.materials==old_cobweb.materials
chimney_index=next(i for i,m in enumerate(candidate.materials) if m[0][0]=='chimney')
roof_index=next(i for i,m in enumerate(candidate.materials) if m[0][0].startswith('roof'))
vertex_material={}
for face,material in zip(candidate.faces,candidate.mat_index):
 for i in face:vertex_material.setdefault(i,set()).add(material)
changed=[]
for i,(a,b) in enumerate(zip(old_cobweb.verts,candidate.verts)):
 if a!=b:
  assert a[:2]==b[:2] and vertex_material[i]=={chimney_index},(i,a,b,vertex_material[i])
  changed.append(i)
assert changed
roof_top=max(p[2] for i,p in enumerate(candidate.verts) if roof_index in vertex_material.get(i,set()))
chimney_points=[p for i,p in enumerate(candidate.verts) if chimney_index in vertex_material.get(i,set())]
left=[p for p in chimney_points if p[0]<1];right=[p for p in chimney_points if p[0]>12]
assert left and right and max(p[2] for p in left)==max(p[2] for p in right)==5.05
minimum=18*.0254
projection=5.05-roof_top
assert projection>minimum+.05
assert all(a==b for i,(a,b) in enumerate(zip(old_cobweb.verts,candidate.verts))
           if roof_index in vertex_material.get(i,set()))

from measure_glbs import read_glb
from measure_stack_fabric import material_tops,roof_top as native_roof_top
master_path=LIVE/'assets/gltf/cobweb_castle__log_1820.glb'
js,_=read_glb(master_path)
old_master=master_path.read_bytes()
snapshot=BEFORE/'assets/gltf/cobweb_castle__log_1820.glb'
snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(old_master)
tops=material_tops(js);native_roof=native_roof_top(tops)[1]
native_chimney=tops['chimney'];old_native_projection=native_chimney-native_roof
assert abs(old_native_projection-(.72-.5*math.tan(math.radians(35))))<1e-6
for p in ['generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py',
          'data/structures/cobweb_castle.json','docs/LIBERTIES.md','data/reconstruction/name_pool_keys.json']:
 assert (LIVE/p).read_bytes()==(BEFORE/p).read_bytes(),p+' changed during audit'
for _,record,_,source_bytes in scope:
 assert (LIVE/'data/structures'/(record['id']+'.json')).read_bytes()==source_bytes,record['id']+' changed during audit'
notes=json.loads((AFTER/'data/reconstruction/name_pool_keys.json').read_bytes())
assert 'phases[].form.chimney_head_m.note' in notes['read']['structures']
source=json.loads((LIVE/'data/sources/chicago_democrat_1833_1835.json').read_bytes())
shared=[]
for module in list(sys.modules.values()):
 filename=getattr(module,'__file__',None)
 if filename:
  path=Path(filename).resolve()
  if LIVE in path.parents and path.suffix=='.py':
   data=path.read_bytes();rel=path.relative_to(LIVE)
   dest=OUT/'shared-source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
   shared.append({'path':str(rel),'sha256':hashlib.sha256(data).hexdigest()})
report={'status':'PASS_CPU_ONLY_PROPOSAL_UNAPPLIED','current_family':82,
        'all82_current_record_outputs_exact_before_Cobweb_head_optin':True,
        'all81_other_actual_optin_outputs_exact':True,'parameter_signature_exact':True,
        'new_cobweb_head_m':5.05,'native_current_master_sha256':hashlib.sha256(old_master).hexdigest(),
        'native_current_roof_top_m':native_roof,
        'native_current_chimney_top_m':native_chimney,'native_current_global_projection_m':old_native_projection,
        'candidate_raw_roof_top_m':roof_top,'candidate_raw_chimney_top_m':5.05,
        'candidate_global_projection_m':projection,'eighteen_inch_minimum_m':minimum,
        'candidate_margin_m':projection-minimum,'wing_ridge_m':2.6+2.25*math.tan(math.radians(35)),
        'candidate_own_wing_projection_m':5.05-(2.6+2.25*math.tan(math.radians(35))),
        'changed_vertex_count':len(changed),'changed_vertices_only_chimney_z':True,
        'faces_material_confidence_named_palette_exact':True,'roof_geometry_all_exact':True,
        'raw_triangles_before':sum(len(f)-2 for f in old_cobweb.faces),
        'raw_triangles_after':sum(len(f)-2 for f in candidate.faces),
        'source_id_resolves':source['id'],'native_note_reader_declared':True,'shared_source_bindings':shared,'assets':rows,
        'limits':'Pure Python raw builder/read-only existing GLB bounds. No bpy execution, Blender, web export, native writer/full gate, or canonical mutation. Candidate5.05m still needs actual official82 refresh and native byte-level ordinance check; no image-match acceptance.'}
(OUT/'raw-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='assets'},indent=2))
