"""Bounded authored proposal only; no canonical edits or gates."""
from pathlib import Path
import hashlib,json,difflib,datetime,subprocess

root=Path('/tmp/chicago-log-integration/chicago/4d')
out=Path(__file__).resolve().parent
paths=['generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py',
       'data/structures/cobweb_castle.json','docs/LIBERTIES.md','data/reconstruction/name_pool_keys.json']
before={p:(root/p).read_bytes() for p in paths};after=dict(before)
p=paths[1]
old=b'            p.chimney_cross_m != 0 or p.chimney_head_m is not None or\n'
new=b'            p.chimney_cross_m != 0 or\n'
assert after[p].count(old)==1
after[p]=after[p].replace(old,new)
p=paths[0]
old=b'            _stack(b,*r,roofs[i],1.0,M_CHIMNEY_AFTER_SIGN,gable_axis=axis,at_min=n == 0)'
new=b'            _stack(b,*r,roofs[i],1.0,M_CHIMNEY_AFTER_SIGN,gable_axis=axis,at_min=n == 0,\n                   head_z=p.chimney_head_m)'
assert after[p].count(old)==1
after[p]=after[p].replace(old,new)
p=paths[2]
d=json.loads(after[p]);phase=next(ph for ph in d['phases'] if ph['id']=='log_1820')
assert 'chimney_head_m' not in phase['form']
phase['form']['chimney_head_m']={
 'value':5.05,'confidence':'reconstructed','sources':['chicago_democrat_1833_1835'],
 'note':"T-3081: both outer-wing chimney heads are reconstructed at 5.05 m above grade. The unchanged 2.6 m eaves, 35-degree pitch and stated roof rectangles put the central ridge at about 4.526 m and each wing ridge at about 4.175 m. The heads therefore stand about 0.524 m above the highest roof and 0.875 m above their own wing roofs. This leaves a margin above the project's eighteen-inch (0.4572 m) clearance floor, drawn from section 18 of the 5 August 1835 by-law printed on 19 August (chicago_democrat_1835_08_19#c005 within the cited newspaper corpus). It is a declared construction choice, not a measured or pictured height or proof that this agency building complied in July 1835. Stack count, outer-wing positions, sections, roofs, occupied footprint and placement remain unchanged; T-2374's image gate remains open."}
after[p]=(json.dumps(d,ensure_ascii=True,indent=2)+'\n').encode()
assert(root/'data/sources/chicago_democrat_1833_1835.json').exists()
p=paths[4]
d=json.loads(after[p]);reader='phases[].form.chimney_head_m.note'
assert reader not in d['read']['structures']
d['read']['structures'].append(reader)
after[p]=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
p=paths[3]
raw=after[p]
incoming=subprocess.check_output(['git','-C',str(root),'show','3fa6e0e84f84a33ccb8ac82c4778f6468af3b029:chicago/4d/docs/LIBERTIES.md'])
assert raw.startswith(incoming)
start=raw.index(b'### L-cobweb-compound-2374');assert start>=len(incoming)
end=raw.find(b'\n### ',start+1);assert end>start
block=raw[start:end];anchor=b'**Recorded:** 2026-10-23.\n';assert block.count(anchor)==1
extra=("**Head clearance (T-3081, 2026-10-24):** both outer-wing chimney heads are chosen at 5.05 m\n"
       "above grade. The unchanged roofs have a highest ridge of about 4.526 m and\n"
       "wing ridges of about 4.175 m: the heads stand 0.524 m above the highest roof\n"
       "and 0.875 m above their own wings. The project measures its eighteen-inch\n"
       "(0.4572 m) floor conservatively from the highest roof; this head leaves a\n"
       "margin without changing any roof, stack count, position or section. The\n"
       "newspaper corpus records the 5 August by-law printed on 19 August 1835, not\n"
       "Cobweb's actual height or July compliance. Both heads remain reconstructed;\n"
       "no image match or historical measurement is claimed.\n").encode()
block=block.replace(anchor,extra+anchor)
needle=b'`cobweb_castle.log_1820.footprint`.\n';assert block.count(needle)==1
block=block.replace(needle,b'`cobweb_castle.log_1820.footprint`, `cobweb_castle.log_1820.form.chimney_head_m`.\n')
after[p]=raw[:start]+block+raw[end:]
assert after[p].startswith(incoming)
assert after[p][:start]==raw[:start] and after[p][start+len(block):]==raw[end:]
files=[];patch=[]
for path in paths:
 assert(root/path).read_bytes()==before[path],path
 for label,items in [('before',before),('candidate',after)]:
  dest=out/label/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(items[path])
 files.append({'path':path,'before_sha256':hashlib.sha256(before[path]).hexdigest(),
               'after_sha256':hashlib.sha256(after[path]).hexdigest()})
 patch.extend(difflib.diff_bytes(difflib.unified_diff,before[path].splitlines(keepends=True),
                               after[path].splitlines(keepends=True),
                               fromfile=('a/chicago/4d/'+path).encode(),tofile=('b/chicago/4d/'+path).encode()))
(out/'proposal.patch').write_bytes(b''.join(patch))
(out/'input-guards.json').write_text(json.dumps({
 'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'canonical_writes':False,
 'old_incoming_liberty_prefix_exact':True,'only_own_L_cobweb_block_changed':True,
 'added_native_note_reader':reader,'head_m':5.05},indent=2)+'\n')
print(json.dumps({'prepared':str(out),'files':len(files),'patch_bytes':sum(map(len,patch))}))
