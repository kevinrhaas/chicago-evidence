from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,time
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');runtime=P/'runtime';assert os.environ.get('CARPENTER_TRIAL_LEASE')=='root-actual-two-control-prototype-cpu3-4'
assert shutil.disk_usage(P).free>=512*1024**2 and shutil.disk_usage('/tmp').free>=1800000000
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PW_EXECUTABLE='/usr/bin/chromium',TMPDIR=str(P/'scratch'),GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');results=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs=json.loads((P/'INPUTS.json').read_text());assert json.loads(Path('/workspace/T2382-official-claim-reviewed-force-school-agent-v3-20261029/RESULT.json').read_text())['native_commit']==inputs['original_claim_native_commit']
for row in inputs['source_bindings']:
 assert sha(Path(row['frozen']))==row['sha256']
 if row['category']not in {'proposed_record'}:assert sha(Path(row['source']))==row['sha256'],row['source']
def run(name,args,cwd):
 assert shutil.disk_usage(P).free>=512*1024**2;log=P/'logs'/(name+'.log');reap=P/'logs'/(name+'-REAPER.json');assert not log.exists()
 cmd=['python3','/workspace/shared/run-with-reaping.py',str(reap),'--','nice','-n','19','taskset','-c','3,4',*args];t=time.monotonic()
 with log.open('x')as f:r=subprocess.run(cmd,cwd=cwd,env=E,stdout=f,stderr=subprocess.STDOUT)
 rp=json.loads(reap.read_text());row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'name':name,'command':cmd,'cwd':str(cwd),'exit':r.returncode,'seconds':round(time.monotonic()-t,3),'command_exit':rp.get('command_exit'),'all_children_reaped':rp.get('all_children_reaped'),'leftover_cleanup':rp.get('leftover_cleanup')};results.append(row);(P/'STAGES.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0 and rp['command_exit']==0 and rp['all_children_reaped'],row
run('NATIVE',['/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender','--background','--factory-startup','--threads','2','--python',str(P/'run_native.py')],P)
run('WEB',['bash','tools/web_derivatives.sh','--only','philo_carpenter_log_shop__log_1832.glb'],runtime)
for kind in ['existing','annex']:
 for label,name in [('before','baseline-control.glb'),('after','philo_carpenter_log_shop__log_1832.glb')]:
  view=kind+'-'+label;run(view,['node','tools/photo_match.mjs',str(P/'cameras'/(view+'.json')),'--glb','assets/gltf/'+name,'--out',str(P/'outputs'/view)],runtime)
  raw=(P/'logs'/(view+'.log')).read_text();match=re.search(r'\n\s+(/[^\n]+-render\.png)\n',raw);assert match,'actualnativePNGpathmissing';src=Path(match.group(1));assert src.is_file();shutil.copyfile(src,P/'outputs'/view/'ACTUAL-NATIVE.png')
models=json.loads((P/'ALL706-PRIMARY-MODELS-BEFORE.json').read_text());assert len(models)==706 and all(sha(A/rel)==h for rel,h in models.items()),'Allprimaryfamilymodels must remainexact'
family=json.loads((P/'ALL353-PRIMARY-FAMILY-ROWS-BEFORE.json').read_text());mf=json.loads((A/'assets/manifest.json').read_text());assets=mf.get('assets',mf);assert all(assets[n]==row for n,row in family.items())
for row in inputs['source_bindings']:assert sha(Path(row['frozen']))==row['sha256']
web=runtime/'assets/web/philo_carpenter_log_shop__log_1832.glb';size=sum(x.stat().st_size for x in P.rglob('*')if x.is_file());assert size<20*1024**2,('Closed outputcap20MiB',size)
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_NATIVE_CURRENT_BASELINE_EXACT_CANDIDATE_WEB_AND4_GROUP_CAPTURES_PASS_UNREVIEWED','stages':results,'actual_candidate_WEB':{'bytes':web.stat().st_size,'sha256':sha(web)},'all706_primary_models_unchanged':True,'all353_primary_family_rows_unchanged':True,'frozen_sources_unchanged':True,'persistent_output_bytes':size,'output_cap_bytes':20*1024**2,'actual_hotel_holdout_in_every_render':True,'scope':'Externalfinite21.49roof/.94stacktrialonly. Currentbaselineactualnativeequal; unchangedproducer/defaults preserved, nofull82exportclaimed. No primarycanonicalrecord/recipe/camera/MATCHES/app/fullgate/PR/DONE claimed. Diagnosticcamera0.472m eye nothistorical/visitorpose.'};(P/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
