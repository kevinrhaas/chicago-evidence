from pathlib import Path
import json,hashlib,copy,os,shutil,datetime
A=Path('/workspace/chicago/chicago/4d');R=A.parent.parent;Q=Path('/workspace/next-original-Carpenter-Wolf-readonly-v3-20261029');P=Path('/workspace/T2382-native-two-control-school-agent-v3-20261029');assert not P.exists();P.mkdir()
assert shutil.disk_usage(P).free>=512*1024**2 and shutil.disk_usage('/tmp').free>=1800000000
claim=json.loads(Path('/workspace/T2382-official-claim-reviewed-force-school-agent-v3-20261029/RESULT.json').read_text());assert claim['status']=='ACTUAL_OFFICIAL_NATIVE_CARPENTER_CLAIM_REMOTE_IMMUTABLE_READBACK_PASS'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();bindings=[]
def cp(source,dest,category):
 source=Path(source);dest=Path(dest);assert source.is_file()and not source.is_symlink();raw=source.read_bytes();dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);dest.chmod(source.stat().st_mode&0o777);h=hashlib.sha256(raw).hexdigest();assert sha(source)==h;bindings.append({'source':str(source),'frozen':str(dest),'bytes':len(raw),'sha256':h,'category':category})
plan=json.loads((Q/'CARPENTER-FINITE-TWO-CONTROL-PLAN.json').read_text())
for row in plan['current_inputs']:assert sha(R/row['path'])==row['sha256'],('Currentboundinputchanged',row['path'])
old=json.loads((A/'data/structures/philo_carpenter_log_shop.json').read_text());new=json.loads((Q/'Carpenter-PROPOSED-STRUCTURE-UNEXPORTED.json').read_text())
assert old['phases'][0]['position']==new['phases'][0]['position']and old['phases'][0]['footprint']==new['phases'][0]['footprint']
cp(A/'data/structures/philo_carpenter_log_shop.json',P/'BASE-STRUCTURE.json','current_record');cp(Q/'Carpenter-PROPOSED-STRUCTURE-UNEXPORTED.json',P/'PROPOSED-STRUCTURE.json','proposed_record')
# Reuse the proven narrow prototype's exact source-membership list, read CURRENT bytes for every member.
oldinputs=json.loads(Path('/workspace/T2372-native-fit-trial-20261029/INPUTS.json').read_text())
for row in oldinputs['source_bindings']:
 source=Path(row['source']);rel=source.relative_to(A);cp(source,P/'frozen'/rel,'current_native_producer_or_tool')
for name in ['photo_match.mjs','photo_match_group.mjs','photo_match_enclosures.mjs','photo_match_flora.mjs','web_derivatives.sh','structure_versions.py','web_derivative_baseline.json']:
 cp(A/'tools'/name,P/'runtime/tools'/name,'current_native_runtime_tool')
static=json.loads(Path('/workspace/T2372-native-fit-trial-20261029/STATIC-RENDERER-BINDINGS.json').read_text())
for row in static['bindings']:cp(A/row['relative_path'],P/'runtime'/row['relative_path'],'current_static_renderer')
for rel in ['data/scenes/1835.json','data/sidecars/1835/philo_carpenter_log_shop.json','data/sidecars/1835/sauganash_hotel.json','assets/gltf/sauganash_hotel__frame_1831.glb']:
 cp(A/rel,P/'runtime'/rel,'actual_hotel_group_holdout_and_placements')
cp(R/'chicago/reference/images/chicago/chicago_sauganash_hotel_1831.jpg',P/'SOURCE-EXACT.jpg','source_picture')
cp(A/'assets/gltf/philo_carpenter_log_shop__log_1832.glb',P/'CURRENT-MASTER.glb','current_master_control');cp(A/'assets/web/philo_carpenter_log_shop__log_1832.glb',P/'CURRENT-WEB.glb','current_web_control')
for rel in ['data/sources/andreas_1884_sauganash_hotel_plate.json','data/sources/trowbridge_sauganash_hotel.json','data/reference_views/philo_carpenter_log_shop/andreas-1884.json','data/reference_views/philo_carpenter_log_shop/andreas-1884.match.json']:
 cp(A/rel,P/'frozen'/rel,'current_source_camera_provenance')
(P/'runtime/assets/gltf').mkdir(exist_ok=True,parents=True);(P/'runtime/assets/web').mkdir(exist_ok=True,parents=True);(P/'logs').mkdir();(P/'outputs').mkdir();(P/'scratch').mkdir();(P/'cameras').mkdir()
for kind,src in [('existing',A/'data/reference_views/philo_carpenter_log_shop/andreas-1884.json'),('annex',Q/'Carpenter-ANNEX-WALL-camera-PROPOSED-UNRENDERED.json')]:
 cam=json.loads(src.read_text());cam['photo']=str(P/'SOURCE-EXACT.jpg')
 if isinstance(cam['solve'],str):cam['solve']+=' Externalfrozenactualbefore/aftertrial2026-10-29; selectedsourcepixelsandnumericraysremainexact; allhotelinputsareindependentunchangedholdout.'
 else:cam['solve']['external_trial']='Frozenexternalbefore/aftercandidate trial; numericrays exactpurefit; diagnostic0.472m eye is not historical/visitorcamera; hotelholdout unchanged.'
 for phase in ['before','after']:(P/'cameras'/(kind+'-'+phase+'.json')).write_text(json.dumps(cam,indent=2)+'\n')
# Record the actual current family inputs/models without copying or re-exporting unrelated assets.
manifest=json.loads((A/'assets/manifest.json').read_text());assets=manifest.get('assets',manifest);family={k:v for k,v in assets.items()if v.get('archetype')in {'log_dwelling','frame_dwelling'}};assert len(family)==353
models={}
for n,row in family.items():
 for fold in ['gltf','web']:
  rel='assets/'+fold+'/'+n;models[rel]=sha(A/rel)
(P/'ALL706-PRIMARY-MODELS-BEFORE.json').write_text(json.dumps(models,indent=2)+'\n')
(P/'ALL353-PRIMARY-FAMILY-ROWS-BEFORE.json').write_text(json.dumps(family,indent=2)+'\n')
(P/'INPUTS.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FROZEN_CURRENT_PRODUCER_SOURCE_AND_GROUP_INPUTS_PREPARED_UNRUN','source_bindings':bindings,'original_claim_native_commit':claim['native_commit'],'current_master_sha256':sha(P/'CURRENT-MASTER.glb'),'current_web_sha256':sha(P/'CURRENT-WEB.glb'),'no_producer_changes':True,'only2physicalcontrols':[21.49,.94],'source_date':'Andreas1884 retrospectivepre1834; no July1835/metric/identity upgrade','floor_TMP':1800000000,'floor_workspace':512*1024**2,'output_cap':20*1024**2,'cap_scope':'Closedpersistenttrialfiles; native transient browser scratch stillguarded512MiBfree','source_and_target_records':'Exactoldsourcepreimage and authored2controlpostimage; no primarycanonicalwrites'},indent=2)+'\n')
size=sum(p.stat().st_sizefor p in [])if False else sum(p.stat().st_size for p in P.rglob('*')if p.is_file());assert size<20*1024**2;print(json.dumps({'prepared':str(P),'bytes':size,'bindings':len(bindings)},indent=2))
