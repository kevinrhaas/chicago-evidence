from pathlib import Path
import json,hashlib,sys,time,datetime
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'frozen/generators'));import emit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs=json.loads((P/'INPUTS.json').read_text())
for row in inputs['source_bindings']:assert sha(Path(row['frozen']))==row['sha256'],row['frozen']
rows=[]
for label,record,name in [('before','BASE-STRUCTURE.json','baseline-control.glb'),('after','PROPOSED-STRUCTURE.json','philo_carpenter_log_shop__log_1832.glb')]:
 r=json.loads((P/record).read_text());dest=P/'runtime/assets/gltf'/name;assert not dest.exists();t=time.monotonic();made=emit.emit_structure(r,r['phases'][0],'log_dwelling',dest,bake=True,ao=False)
 row={'label':label,'record_sha256':sha(P/record),'path':str(dest),'seconds':round(time.monotonic()-t,3),'bytes':dest.stat().st_size,'sha256':sha(dest),'triangles':made.tris,'baked_AO':False};rows.append(row);print(json.dumps(row),flush=True)
 if label=='before':assert row['sha256']==inputs['current_master_sha256'],'ActualnativebaselinefailedtoreproducecurrentMASTER'
assert rows[1]['sha256']!=rows[0]['sha256']
(P/'ACTUAL-NATIVE.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_NATIVE_BASELINE_EXACT_AND_TWO_CONTROL_CANDIDATE_EMITTED','rows':rows,'all_other_defaults':'Producerunchanged; no otherrecordaltered. No full82export claimed.','candidate_model_acceptance':'UNREVIEWED'},indent=2)+'\n')
