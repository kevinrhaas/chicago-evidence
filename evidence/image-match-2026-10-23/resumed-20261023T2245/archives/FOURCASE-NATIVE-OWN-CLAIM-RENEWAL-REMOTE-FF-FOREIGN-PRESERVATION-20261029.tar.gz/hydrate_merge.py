from pathlib import Path
import json,importlib.util,hashlib,zlib,os,subprocess,datetime
from urllib.request import Request,urlopen
O=Path(__file__).parent;R=Path('/workspace/chicago/chicago/4d/tickets');G=R/'.git';env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*a):return subprocess.check_output(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false',*a],env=env)
def api(p):
 with urlopen(Request('https://api.github.com/repos/kevinrhaas/chicago-tickets/'+p,headers={'User-Agent':'Chicago-own-claim-renewal','Accept':'application/vnd.github+json'}),timeout=60)as r:return json.load(r)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
remote=json.loads((O/'REMOTE-BEFORE.json').read_text())['object']['sha'];old='6d0b3e645f3fbe352f18cfed1f9ebfb79afca59a';base='c9c8cf714dba71ee503a84ca19d043dc08ecc0ef'
assert git('rev-parse','HEAD').decode().strip()==old and not git('status','--porcelain').strip()and not(G/'MERGE_HEAD').exists();assert api('git/ref/heads/main')['object']['sha']==remote
own=git('diff','--name-only',base,old).decode().splitlines();assert len(own)==4 and all(any('/'+t+'-'in p for t in ['T-2381','T-2373','T-2384','T-2377'])for p in own)
comp=json.loads((O/'REMOTE-COMPARE.json').read_text());assert not(set(own)&{x['filename']for x in comp['files']});tree=json.loads((O/'REMOTE-TREE.json').read_text());remoteleaves={x['path']:(x['mode'],x['type'],x['sha'])for x in tree['tree']if x['type']!='tree'}
spec=importlib.util.spec_from_file_location('t','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.SOURCE=R;m.G=G
price=json.loads((O/'REMOTE-PRICE.json').read_text());assert price['new_blob_bytes']==191745 and price['new_blob_bytes']<1024**2;rows=[]
for r in price['missing']:
 assert r['sha']not in m.indexed([r['sha']]);url='https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+remote+'/'+r['path']
 with urlopen(Request(url,headers={'User-Agent':'Chicago-own-claim-renewal'}),timeout=60)as response:assert response.status==200;b=response.read(r['size']+1)
 raw=b'blob '+str(len(b)).encode()+b'\0'+b;assert len(b)==r['size']and hashlib.sha1(raw).hexdigest()==r['sha'];enc=zlib.compress(raw);p=G/'objects'/r['sha'][:2]/r['sha'][2:];p.parent.mkdir(exist_ok=True);assert not p.exists();p.write_bytes(enc);rows.append({'path':r['path'],'sha':r['sha'],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'allocated':p.stat().st_blocks*512})
save('EXACT-16-BLOB-HYDRATION.json',rows);assert all(s[2]in m.indexed([s[2]])for s in remoteleaves.values());assert api('git/ref/heads/main')['object']['sha']==remote
with(O/'NATIVE-NORMAL-MERGE.log').open('x')as f:q=subprocess.run(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','merge','--no-ff','-m','Merge current ticket work while preserving the four native claim renewals',remote],env=env,stdout=f,stderr=subprocess.STDOUT)
assert q.returncode==0
head=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',head).decode().strip().split()==[old,remote]and not git('status','--porcelain').strip()
actual={}
for r in git('ls-tree','-r','-z',head).split(b'\0'):
 if r:a,n=r.split(b'\t');mode,kind,sha=a.decode().split();actual[n.decode()]=(mode,kind,sha)
assert set(actual)==set(remoteleaves)and all(actual[p]==v for p,v in remoteleaves.items()if p not in own)
assert set(git('diff','--name-only',remote,head).decode().splitlines())==set(own)
for p in own:
 before=git('show',remote+':'+p).decode();after=(R/p).read_text();strip=lambda s:'\n'.join(l for l in s.splitlines()if not l.startswith(('claimed_by:','claimed_at:')))
 assert strip(before)==strip(after)and 'claimed_at: 2026-10-29T19:27:38.302Z'in after
save('NATIVE-MERGE-RESULT.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FOUR_NATIVE_RENEWALS_AND_ALL_FOREIGN_PATHS_COMPOSED_EXACTLY','head':head,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'remote_base':remote,'native_renewals_preserved':['2911f2a56a61be8afeb0ca0e425370d61a7ff9fa','ad69e2060325fbfd5add24ae97a005f92acf7f98',old],'own_paths':own,'remote_paths_preserved':len(remoteleaves)-4,'only_own_changed_fields':['claimed_by','claimed_at'],'claim_expiry_utc':'2026-10-29T22:27:38.302Z','publication':'PENDING'})
print((O/'NATIVE-MERGE-RESULT.json').read_text())
