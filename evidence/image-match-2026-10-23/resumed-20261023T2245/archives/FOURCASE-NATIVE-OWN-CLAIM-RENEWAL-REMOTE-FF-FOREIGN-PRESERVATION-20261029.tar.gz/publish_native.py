from pathlib import Path
import json,importlib.util,hashlib,base64,datetime
O=Path(__file__).parent;proof=json.loads((O/'NATIVE-MERGE-RESULT.json').read_text());remote=proof['remote_base'];head=proof['head'];own=set(proof['own_paths']);base='c9c8cf714dba71ee503a84ca19d043dc08ecc0ef'
spec=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.SOURCE=Path('/workspace/chicago/chicago/4d/tickets');m.G=m.SOURCE/'.git';m.REPO='kevinrhaas/chicago-tickets'
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
before=m.snapshot();save('TRANSPORT-SOURCE-BEFORE.json',before);assert before['HEAD']==head and not before['status'];assert m.api('git/ref/heads/main')['object']['sha']==remote
ids=proof['native_renewals_preserved']+[head];cs=[m.commit(s)for s in ids];available={c['sha']:c for c in cs};known=set()
for s in [base,remote]:
 c=m.commit(s);r=m.api('git/commits/'+s);assert r['tree']['sha']==c['tree']and[p['sha']for p in r['parents']]==c['parents'];available[s]=c;known|={v[2]for v in m.leaves(c['tree']).values()if v[1]=='blob'}
assert cs[-1]['tree']==proof['tree'];diffs={};blobs={}
foreign={x['filename']for x in json.loads((O/'REMOTE-COMPARE.json').read_text())['files']}
for i,c in enumerate(cs):
 assert c['parents']==([base if i==0 else cs[i-1]['sha']]if i<3 else[cs[i-1]['sha'],remote]);m.native_payload(c)
 a=m.leaves(available[c['parents'][0]]['tree']);b=m.leaves(c['tree']);diff={p:b.get(p)for p in set(a)|set(b)if a.get(p)!=b.get(p)}
 assert set(diff)==(own if i<3 else foreign);diffs[c['sha']]=diff
 for p,v in diff.items():
  assert v and v[0]=='100644'and v[1]=='blob'
  if v[2]not in known:blobs[v[2]]=m.obj('blob',v[2])
assert sum(len(b)for b in blobs.values())<1024**2
save('EXACT-NATIVE-TRANSPORT-PLAN.json',{'remote_expected_old':remote,'native_commits':[{'sha':c['sha'],'tree':c['tree'],'parents':c['parents']}for c in cs],'new_blob_bytes':sum(len(b)for b in blobs.values()),'only_final_changed_paths':sorted(own),'all3217foreignpaths_exact':True,'force':False})
for s,b in blobs.items():assert m.api('git/blobs',{'encoding':'base64','content':base64.b64encode(b).decode()})['sha']==s
for c in cs:
 d=diffs[c['sha']];tr=m.api('git/trees',{'base_tree':available[c['parents'][0]]['tree'],'tree':[{'path':p,'mode':v[0],'type':v[1],'sha':v[2]}for p,v in sorted(d.items())]});assert tr['sha']==c['tree'];r=m.api('git/commits',m.native_payload(c));save('CREATED-COMMIT-'+c['sha']+'.json',r);assert r['sha']==c['sha']
assert m.api('git/ref/heads/main')['object']['sha']==remote,'Remoteadvanced: exactnativeobjects preserved, DO NOT overwrite'
assert m.snapshot()==before
r=m.api('git/refs/heads/main',{'sha':head,'force':False},'PATCH');assert r['object']['sha']==head;assert m.api('git/ref/heads/main')['object']['sha']==head
from urllib.request import Request,urlopen
readback=[]
for p in sorted(own):
 b=(m.SOURCE/p).read_bytes()
 with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+head+'/'+p,headers={'User-Agent':'Chicago-native-ownclaim-verifier'}),timeout=60)as r:assert r.status==200;actual=r.read()
 assert actual==b;readback.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
after=m.snapshot();save('TRANSPORT-SOURCE-AFTER.json',after);assert after==before
# Cached remote ref follows only the exact actually verified normal-FF result.
assert m.git('rev-parse','origin/main').decode().strip()==remote;m.git('update-ref','refs/remotes/origin/main',head,remote)
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EXACT_NATIVE_OWN_FOUR_CLAIM_RENEWALS_REMOTE_NORMAL_FF_PASS','remote_old':remote,'head':head,'tree':proof['tree'],'native_commit_SHAs_preserved':ids,'all3217foreignpaths_and_all_other_own_fields_exact':True,'readback':readback,'force':False,'claim_timestamp':'2026-10-29T19:27:38.302Z','claim_expiry':'2026-10-29T22:27:38.302Z','sourceworkingHEADindexconfigunchanged':True,'cachedoriginmain_exactverifiedhead':head,'ignored_board_and_site_mirror':'Not refreshed by transport; nativeboard next.'};save('RESULT.json',result);print(json.dumps(result,indent=2))
