from pathlib import Path
import copy,datetime,hashlib,json,os,subprocess,time
R=Path('/workspace/chicago');A=R/'chicago/4d';T=(A/'tickets').resolve();O=Path('/tmp/original-remaining-audit-school-20261029');E=dict(os.environ,GIT_NO_LAZY_FETCH='1')
ids={2374:'cobweb_castle',2378:'jb_beaubien_homestead',2379:'lake_house_construction',2380:'log_jail',2382:'philo_carpenter_log_shop',2383:'sauganash_hotel',2386:'wolf_point_tavern',2387:'first_fort_dearborn_blockhouse_nw',2388:'fort_dearborn_blockhouse'}
def git(root,*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=root,env=E,text=True).strip()
def bind(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def freeze(p,rel):dst=O/'inputs'/rel;dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();dst.write_bytes(p.read_bytes());return bind(p)
def fm(s):
 block=s.split('---',2)[1];return {line.partition(':')[0]:line.partition(':')[2].strip()for line in block.splitlines()if ':'in line}
start={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'app_HEAD':git(R,'rev-parse','HEAD'),'app_branch':git(R,'branch','--show-current'),'ticket_HEAD':git(T,'rev-parse','HEAD'),'ticket_root':str(T)};rows=[];bindings=[]
book=json.loads((A/'assets/manifest.json').read_text())['assets'];web=json.loads((A/'assets/manifest.web.json').read_text())['masters']
for tid,sid in ids.items():
 ticket=next(T.glob(f'*/T-{tid}-*.md'));bindings.append(freeze(ticket,Path('tickets')/ticket.name));record=A/'data/structures'/f'{sid}.json';bindings.append(freeze(record,Path('structures')/record.name));r=json.loads(record.read_text());assets={k:v for k,v in book.items()if v.get('structure_id')==sid};views=[]
 for f in sorted((A/'data/reference_views'/sid).glob('*.json')):
  bindings.append(freeze(f,Path('reference_views')/sid/f.name));d=json.loads(f.read_text());views.append({'name':f.name,'verdict':d.get('verdict'),'open_differences':[x['what']for x in d.get('differences',[])if x.get('status')=='open']})
 assetrows=[]
 for name,v in assets.items():
  paths={kind:bind(A/'assets'/kind/name)for kind in ['gltf','web']};assetrows.append({'name':name,'native_manifest_entry':v,'WEB_master_binding':web.get(name),'current_MASTER_WEB':paths,'current_master_matches_WEBbinding':paths['gltf']['sha256']==web.get(name)})
 rows.append({'ticket':f'T-{tid}','frontmatter':fm(ticket.read_text()),'structure':sid,'current_form_keys_by_phase':{p['id']:list(p.get('form',{}))for p in r['phases']},'canonical_views':views,'assets':assetrows})
# Actual selected native gate; deliberately expects refusal, not a passing signoff.
command=['node','tools/image_gate.mjs','--structure',*ids.values()];beg=time.monotonic();q=subprocess.run(command,cwd=A,env=E,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(O/'native-selected-image-gate.log').write_text(q.stdout)
gate={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'exit':q.returncode,'seconds':round(time.monotonic()-beg,4),'expected_negative_audit_result':True,'source_or_ticket_mutation':False};(O/'NATIVE-GATE-RESULT.json').write_text(json.dumps(gate,indent=2)+'\n')
old=json.loads(Path('/tmp/remaining-work-audit-20261029-resume/LIVE-RESULT.json').read_text());prs=[x for x in old['prs']if x['number']in [1260,1282,1298,1300,1333,1336,1348]]
end={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'app_HEAD':git(R,'rev-parse','HEAD'),'ticket_HEAD':git(T,'rev-parse','HEAD'),'audited_ticket_and_record_bytes_unchanged':all(bind(Path(x['path']))==x for x in bindings)};assert end['audited_ticket_and_record_bytes_unchanged']
result={'status':'READ_ONLY_NINE_ORIGINALS_AUDITED_NO_CLOSURE_READY','start':start,'end':end,'scope':'Current local accepted-source target files and nativeclosinggate, not freshremotePRlist or newlyrenderedreviews. All nine selected originalrecords read currentcachedtickets; no claims/edits/nativeexports/browser/newtickets/PRmutations.','tickets':rows,'input_bindings':bindings,'selected_native_gate':gate,'dated_actual_merged_PR_receipts':{'audit_at':old['at'],'source':str(Path('/tmp/remaining-work-audit-20261029-resume/LIVE-RESULT.json')),'PRS':prs},'none_with_accepted_current_canonical_all_picture_gate':True,'potential_without_geometry':'Cobweb has realcompoundbuilt, but provisionalsmallpanoramacamera prevents a meaningfulformcomparison. Finitecamera-onlyassessment may reveal acceptance or realdefects; no acceptanceisproved. Others show actualmaterialgeometrygaps or unresolveddatedsubjects.'}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'ticket_HEAD':start['ticket_HEAD'],'source_HEAD':start['app_HEAD'],'gate_exit':q.returncode,'records':len(rows),'all_SELECTED_WEBbindings_current':all(x['current_master_matches_WEBbinding']for r in rows for x in r['assets'])},indent=2))
