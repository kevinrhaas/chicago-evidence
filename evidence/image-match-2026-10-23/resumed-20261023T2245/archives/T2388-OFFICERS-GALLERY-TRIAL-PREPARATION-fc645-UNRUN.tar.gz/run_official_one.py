"""Prepared, UNRUN controller for normal one-master then web production, in an isolated trial."""
from pathlib import Path
import argparse,json,hashlib,sys,subprocess,datetime,traceback
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--stage',choices=['masters','web'],required=True);ap.add_argument('--blender',type=Path);ap.add_argument('--masters-result',type=Path);ap.add_argument('--root-heavy-granted',action='store_true');a=ap.parse_args()
if not a.root_heavy_granted:ap.error('Prepared only. An explicit later root heavy grant is required.')
repo=a.repo.resolve();assert repo not in [Path('/workspace/chicago'),Path('/tmp/chicago-log-integration')],'canonical writer checkouts are off limits'
root=repo/'chicago/4d';out=a.out.resolve();assert not out.exists(),'preserve every prior attempt';out.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest();key='fort_dearborn_officers_quarters__log_1816.glb';sid='fort_dearborn_officers_quarters';checks=json.loads((P/'LIGHT-CHECKS.json').read_text());state={'status':'RUNNING','stage':a.stage,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'isolated_repo':str(repo),'scope':'Normal current production producer only; no native/gate/browser/adoption or match implied'}
save=lambda:(out/'RESULT.json').write_text(json.dumps(state,indent=2)+'\n');save()
try:
 assert sha((root/'generators/archetypes/fort_structure.py').read_bytes())==checks['repaired_producer_sha256'],'rebind if the actual landed producer differs; never copy an old module over current source'
 assert (root/'data/structures'/f'{sid}.json').read_bytes()==(P/'candidate/fort_dearborn_officers_quarters.json').read_bytes(),'exact prepared candidate must already be applied in the isolated trial'
 sys.path.insert(0,str(root/'generators'));import mesh_inputs
 manifests={name:json.loads((root/'assets'/name).read_text())for name in ['manifest.json','manifest.web.json']};before=manifests['manifest.json'];selected_before={directory:sha((root/'assets'/directory/key).read_bytes())for directory in ['gltf','web']};rows=before['assets'];fort={k:v for k,v in rows.items()if v.get('archetype')=='fort_structure'};assert len(fort)==25
 current_st=json.loads((root/'data/structures'/f'{sid}.json').read_text());phase=next(p for p in current_st['phases']if p['id']=='log_1816');candidate_input=mesh_inputs.structure_inputs_sha(current_st,phase,'fort_structure')
 original_st=json.loads((P/'frozen/officers.before.json').read_text());baseline_input=mesh_inputs.structure_inputs_sha(original_st,original_st['phases'][0],'fort_structure');assert candidate_input!=baseline_input
 for k,row in fort.items():
  st=json.loads((root/'data/structures'/f'{row["structure_id"]}.json').read_text());ph=next(p for p in st['phases']if p['id']==row['phase_id']);actual=mesh_inputs.structure_inputs_sha(st,ph,'fort_structure')
  if k!=key:assert row['inputs_sha256']==actual,('another fort recipe is stale; prerequisite bake not ready',k)
 assert rows[key]['inputs_sha256']==(baseline_input if a.stage=='masters'else candidate_input)
 # Protect every unrelated normal recipe row and both master/web byte sets, not only the fort family.
 protected={}
 for directory in ['gltf','web']:
  for pth in (root/'assets'/directory).rglob('*.glb'):
   if pth!=root/'assets'/directory/key:protected[str(pth.relative_to(root))]=sha(pth.read_bytes())
 state.update({'before_25recipes_fresh_except_selected_candidate':True,'baseline_inputs_sha256':baseline_input,'candidate_inputs_sha256':candidate_input,'protected_glbs':len(protected)});save()
 if a.stage=='masters':
  assert rows[key]['bytes']==(root/'assets/gltf'/key).stat().st_size
  assert manifests['manifest.web.json']['masters'][key]==selected_before['gltf'],'baseline master must equal its actual derived binding'
  assert a.blender and a.blender.is_file(),'pass the normal pinned Blender binary, never install one here'
  cmd=[str(a.blender),'-b','-noaudio','--factory-startup','--python','generators/build.py','--','--only',sid,'--scene','1835','--wrote',str(out/'wrote.txt')]
 else:
  assert a.masters_result and a.masters_result.is_file(),'web requires the actual completed masters receipt'
  prior=json.loads(a.masters_result.read_text());assert prior['status']=='PASS_OFFICIAL_ONE_MASTERS_NOT_NATIVE_QA_OR_IMAGE_ACCEPTANCE' and prior['isolated_repo']==str(repo) and prior['candidate_inputs_sha256']==candidate_input and prior['master_sha256']==selected_before['gltf']
  state['masters_receipt_sha256']=sha(a.masters_result.read_bytes())
  cmd=['bash','tools/web_derivatives.sh','--only',key]
 state['command']=cmd;save()
 with (out/'producer.log').open('wb')as log:rc=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
 state['exit_code']=rc;assert rc==0,'normal producer failed'
 now={name:json.loads((root/'assets'/name).read_text())for name in manifests}
 assert {k:v for k,v in now['manifest.json'].items()if k!='assets'}=={k:v for k,v in before.items()if k!='assets'}
 assert {k:v for k,v in now['manifest.web.json'].items()if k!='masters'}=={k:v for k,v in manifests['manifest.web.json'].items()if k!='masters'}
 if a.stage=='masters':
  assert sha((root/'assets/web'/key).read_bytes())==selected_before['web']
  assert (out/'wrote.txt').read_text().splitlines()==[key]
  assert {k:v for k,v in now['manifest.json']['assets'].items()if k!=key}=={k:v for k,v in rows.items()if k!=key}
  assert now['manifest.json']['assets'][key]['inputs_sha256']==candidate_input
  assert now['manifest.web.json']==manifests['manifest.web.json']
 else:
  assert sha((root/'assets/gltf'/key).read_bytes())==selected_before['gltf']
  assert now['manifest.json']==before
  assert {k:v for k,v in now['manifest.web.json']['masters'].items()if k!=key}=={k:v for k,v in manifests['manifest.web.json']['masters'].items()if k!=key}
  assert now['manifest.web.json']['masters'][key]==sha((root/'assets/gltf'/key).read_bytes())
 for rel,h in protected.items():assert sha((root/rel).read_bytes())==h,('unrelated output changed',rel)
 state.update({'status':'PASS_OFFICIAL_ONE_'+a.stage.upper()+'_NOT_NATIVE_QA_OR_IMAGE_ACCEPTANCE','master_sha256':sha((root/'assets/gltf'/key).read_bytes()),'web_sha256':sha((root/'assets/web'/key).read_bytes()),'all_unrelated_protected_glbs_exact':True})
except BaseException as e:
 state.update({'status':'FAIL_PRESERVED','error':str(e),'traceback':traceback.format_exc()});raise
finally:state['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
