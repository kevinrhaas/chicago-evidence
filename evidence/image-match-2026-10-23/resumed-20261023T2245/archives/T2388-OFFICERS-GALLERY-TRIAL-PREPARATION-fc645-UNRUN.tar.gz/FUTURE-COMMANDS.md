# Prepared commands; actual export, browser and native stages remain UNRUN

The root must assign a later heavy slot and isolated trial after the repaired T-3105 source/output is ready. There is no new claim, ticket or permission request in this packet. Before implementation, normal task ownership must be resolved by the root. Never use these commands against either active canonical writer checkout.

The original source is appropriate for a bounded gallery occurrence trial: the original 1881 p. 92 print and p. 93 key identify B. B's left endpoint is clipped, so this is not a whole-building or full-fort match camera. All 1835 backdating and copied metric openings are reconstructed. The camera is an initial manual seed with no fitted correspondence or residual, not an accepted historical camera. Crop JSON is an unexecuted ROI proposal; all included image bytes are copied unchanged. The source image is the upright modern-hosted reproduction of the inspected 1881 engraving, with both original JP2 pages retained for attribution; it is not an independent witness or modern-page rights upgrade.

1. Check the closed preparation without running a producer:

```bash
python -B /workspace/T2388-officers-gallery-trial-prep-fc645-20261024/VERIFY.py
```

2. Prepare a NEW isolated trial from the actual landed current source using the repository's normal setup. Do not copy an old complete generator overlay. The controller requires the exact repaired producer SHA256 `fc645a66b889e8ca837520e73d2bdee4806b0892e33591099714bff10178d64e`. If the actual parent lands another version, stop and rebind this preparation; do not overwrite it with the frozen file. The frozen producer is evidence and an optional expressly authorized isolated-trial input, not an adoption instruction.

Use these paths as explicit future parameters; they do not exist as an actual execution result:

```bash
TRIAL_REPO=/workspace/T2388-actual-trial-fc645
TRIAL_RUN=/workspace/T2388-actual-run-fc645-001
PREP=/workspace/T2388-officers-gallery-trial-prep-fc645-20261024
```

Before patching the record, prove all 25 fort recipes current and preserve the baseline officers' master/web plus manifest rows; archive full current inputs and branch identity. Preserve the 24 unrelated fort inputs, all other assets and incoming liberty/population history. The root coordinates native materialization if required; this preparation does not run it.

3. Create before/after camera work copies so photo_match's generated match records cannot mutate this CLOSED packet. Keep identical camera/source bytes and intrinsics in the two trials. Both source and camera copies are required because the camera's photo path is relative.

```bash
mkdir -p "$TRIAL_RUN/before" "$TRIAL_RUN/after"
cp -a "$PREP/cameras" "$PREP/source" "$TRIAL_RUN/before/"
cp -a "$PREP/cameras" "$PREP/source" "$TRIAL_RUN/after/"
cd "$TRIAL_REPO/chicago/4d"
PW_EXECUTABLE=/usr/bin/chromium node tools/photo_match.mjs "$TRIAL_RUN/before/cameras/wentworth_1855_gallery_seed.json" --out "$TRIAL_RUN/before/comparisons"
```

Inspect the ACTUAL baseline image before moving forward. Stop and revise the camera separately if source B/A assignment, facade bearing, partial clipping or framing is not defensible. Preserve the failed seed and any outcome. The manual seed does not authorize moving the surveyed structures. No 1855 city/hospital/fence is inserted into the 1835 scene to imitate context.

4. Only in the assigned isolated trial, check exact record preimage and apply the single-record patch through normal Git. Preserve the old record and baseline outputs first. The postimage SHA256 is in LIGHT-CHECKS.json. Syntax/parameter checks have passed only in the external packet so far.

```bash
cd "$TRIAL_REPO"
git apply --check "$PREP/officers-gallery-data-only.patch"
git apply "$PREP/officers-gallery-data-only.patch"
```

5. Produce the one current master using the existing official pinned Blender build, then its normal compressed derivative. Run the web command only after the masters RESULT is PASS. Supply the actual installed pinned binary from this trial's generators/blender.pin; the example follows the normal cache path and does not download/install Blender. Both controller output directories must be NEW; failed attempts are never reused.

```bash
cd "$TRIAL_REPO/chicago/4d"
source generators/blender.pin
python -B "$PREP/run_official_one.py" --repo "$TRIAL_REPO" --out "$TRIAL_RUN/official-masters-001" --stage masters --blender "/opt/blender-dl/$BLENDER_DIR/blender" --root-heavy-granted
python -B "$PREP/run_official_one.py" --repo "$TRIAL_REPO" --out "$TRIAL_RUN/official-web-001" --stage web --masters-result "$TRIAL_RUN/official-masters-001/RESULT.json" --root-heavy-granted
```

The controller invokes exactly the existing `generators/build.py --only fort_dearborn_officers_quarters --scene 1835 --wrote <new receipt>` under factory-startup Blender, then `tools/web_derivatives.sh --only fort_dearborn_officers_quarters__log_1816.glb`. It refuses either active canonical checkout, requires the exact candidate/producer, recomputes all 25 fort recipes, requires the 24 others fresh, checks the official producer's one-key write receipt, preserves all unrelated manifest rows/GLB hashes, checks the selected derivative's master SHA binding, and saves exit/log/exception receipts even on failure. It does not restamp hashes, copy old outputs, run native writers, run gates or infer adoption.

6. Compare the genuine produced master from the identical camera/source, then inspect the complete image and gallery detail. The sidecar-selected anchor filename and placement stay the same; the context commandant asset/placement must remain exact. If scene inputs require refresh, root must explicitly coordinate the normal native derivation before this group capture.

```bash
cd "$TRIAL_REPO/chicago/4d"
PW_EXECUTABLE=/usr/bin/chromium node tools/photo_match.mjs "$TRIAL_RUN/after/cameras/wentworth_1855_gallery_seed.json" --out "$TRIAL_RUN/after/comparisons"
```

Before any adoption, inspect actual support/canopy/beam contacts, both-storey opening clearance, rear windows, feet/material/confidence contracts and native mobile/desktop published rendering. The first-fort beam repair's 25-family parity does not establish this newly enabled second-fort gallery's actual joint/rail/ground behavior. Rails may still occlude upper windows, the source endpoint is clipped, and this straight-front helper omits source stairs and A's corner return. Record these differences honestly.

Only after a successful bounded trial should root prepare the normal utility ticket/Liberty Covers, sources/access-note erratum, raw STATUS/ROADMAP/changelog and native ordered rederive tail; then required gates/readers and source/card/Photos checks. Do not call standalone compile_scene to evade its native orchestration. No original T-2388 match or closure is proposed; all its 16 existing DIFFERS comparisons and 21-member scope remain intact.
