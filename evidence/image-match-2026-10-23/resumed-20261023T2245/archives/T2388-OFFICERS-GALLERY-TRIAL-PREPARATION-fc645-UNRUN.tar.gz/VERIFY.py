from pathlib import Path
import json,hashlib,ast,types,sys,dataclasses,collections,math
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=json.loads((R/'LIGHT-CHECKS.json').read_text())
assert sha(R/'frozen/officers.before.json')==c['record_preimage_sha256']
assert sha(R/'candidate/fort_dearborn_officers_quarters.json')==c['record_postimage_sha256']
assert sha(R/'frozen/fort_structure.fc645.py')==c['repaired_producer_sha256']
a=json.loads((R/'frozen/officers.before.json').read_text());b=json.loads((R/'candidate/fort_dearborn_officers_quarters.json').read_text())
f=b['phases'][0]['form'];assert f['gallery']['confidence']==f['gallery_storeys']['confidence']==f['face_openings']['confidence']=='reconstructed'
restored=json.loads(json.dumps(b));g=restored['phases'][0]['form'];g['gallery']=a['phases'][0]['form']['gallery'];g.pop('gallery_storeys');g.pop('face_openings');assert restored==a
m=types.ModuleType('verify_fort_params');sys.modules[m.__name__]=m;exec(compile((R/'frozen/fort_structure_params.9e757.py').read_text(),'params','exec'),m.__dict__)
p=m.from_phase(a['phases'][0],a);q=m.from_phase(b['phases'][0],b)
s=(R/'frozen/fort_structure.fc645.py').read_text();t=ast.parse(s);names={'_openings','_explicit_openings','_gallery_post_centres'};code='from __future__ import annotations\n'+'\n\n'.join(ast.get_source_segment(s,n)for n in t.body if isinstance(n,ast.FunctionDef)and n.name in names)
calls=[]
def opening(_b,axis,plane,u0,u1,z0,z1,outward,conf,kind='window'):calls.append((axis,plane,u0,u1,z0,z1,outward,conf,kind))
env={'math':math,'wall_openings':m.wall_openings,'openings':types.SimpleNamespace(CASING_W_M=.09,SILL_HORN_M=.03),'_opening':opening};exec(compile(code,'functions','exec'),env)
env['_openings'](None,p,0,0);old=collections.Counter(calls);calls.clear();env['_openings'](None,q,0,0);assert old==collections.Counter(calls);assert len(calls)==18
centres=env['_gallery_post_centres'](q,.14);assert centres==c['explicit_post_centres'];assert len(centres)==7
for x in centres[1:-1]:assert all(x<=o['u0']-.19+1e-9 or x>=o['u1']+.19-1e-9 for o in m.wall_openings(q,'front'))
cam=json.loads((R/'cameras/wentworth_1855_gallery_seed.json').read_text());right,up,forward=cam['basis_right_up_forward'];assert all(abs(sum(v*v for v in row)-1)<1e-12 for row in [right,up,forward]);assert all(abs(sum(x*y for x,y in zip(a,b)))<1e-12 for a,b in [(right,up),(right,forward),(up,forward)])
from PIL import Image
with Image.open(R/'source/fortdearborn1855.jpg')as im:assert list(im.size)==cam['image_px'];im.verify()
for pth in [R/'frozen/fort_structure.fc645.py',R/'frozen/fort_structure_params.9e757.py',R/'run_official_one.py']:ast.parse(pth.read_text())
print(json.dumps({'status':'PASS_LIGHT_ONLY','same18opening_call_multiset':True,'post_count':7,'actual_mesh_export':'UNRUN','camera_fit_and_render':'UNRUN','canonical_adoption':'UNAPPLIED'}))
