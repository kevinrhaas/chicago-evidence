"""One bounded comparison of the actual before/after native Miller masters.

This is a dated evidence instrument, not an application change or new test suite.
"""
from pathlib import Path
import copy
import datetime
import hashlib
import json
import math
import shutil
import struct

OUT = Path(__file__).resolve().parent
APP = Path('/workspace/chicago/chicago/4d')
BEFORE = Path('/workspace/early-four-miller-10mm-native-20261029/before-Miller/gltf/miller_house__log_frame_1827.glb')
AFTER = APP / 'assets/gltf/miller_house__log_frame_1827.glb'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def parse(path):
    data = path.read_bytes()
    assert len(data) < 1024 * 1024
    magic, version, size = struct.unpack_from('<4sII', data)
    assert magic == b'glTF' and version == 2 and size == len(data)
    chunks = []
    offset = 12
    while offset < len(data):
        count, kind = struct.unpack_from('<II', data, offset)
        offset += 8
        assert count % 4 == 0 and offset + count <= len(data)
        chunks.append((kind, data[offset:offset + count]))
        offset += count
    assert offset == len(data) and [c[0] for c in chunks] == [0x4E4F534A, 0x004E4942]
    document = json.loads(chunks[0][1])
    assert len(document['buffers']) == 1
    assert 'uri' not in document['buffers'][0]
    assert document['buffers'][0]['byteLength'] <= len(chunks[1][1])
    assert not document.get('extensionsUsed')
    return data, document, chunks[1][1]


def accessor_raw(document, binary, index):
    accessor = document['accessors'][index]
    assert 'sparse' not in accessor
    view = document['bufferViews'][accessor['bufferView']]
    assert view.get('buffer', 0) == 0
    components = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[accessor['type']]
    component = {5121: 'B', 5123: 'H', 5125: 'I', 5126: 'f'}[accessor['componentType']]
    fmt = '<' + component * components
    width = struct.calcsize(fmt)
    start = view.get('byteOffset', 0) + accessor.get('byteOffset', 0)
    stride = view.get('byteStride', width)
    assert stride >= width
    assert start + (accessor['count'] - 1) * stride + width <= view.get('byteOffset', 0) + view['byteLength']
    raw = [binary[start + row * stride:start + row * stride + width] for row in range(accessor['count'])]
    return b''.join(raw), [struct.unpack(fmt, value) for value in raw]


before_bytes, before, before_bin = parse(BEFORE)
after_bytes, after, after_bin = parse(AFTER)
assert len(before_bytes) == len(after_bytes) and len(before_bin) == len(after_bin)
assert len(before['meshes']) == len(after['meshes']) == 1
assert len(before['meshes'][0]['primitives']) == 10

rows = []
changed_positions = []
uv_rows = []
changed_accessors = set()
for primitive_index, primitive in enumerate(before['meshes'][0]['primitives']):
    assert primitive == after['meshes'][0]['primitives'][primitive_index]
    material = before['materials'][primitive['material']]['name']
    index = primitive['indices']
    old_indices, old_index_values = accessor_raw(before, before_bin, index)
    new_indices, new_index_values = accessor_raw(after, after_bin, index)
    assert old_indices == new_indices
    row = {'primitive': primitive_index, 'material': material,
           'index_accessor': index, 'indices_byteexact': True,
           'triangles': len(old_index_values) // 3, 'attributes': {}}
    assert len(old_index_values) % 3 == 0
    for semantic, index in primitive['attributes'].items():
        old_raw, old_values = accessor_raw(before, before_bin, index)
        new_raw, new_values = accessor_raw(after, after_bin, index)
        different = [(number, old, new) for number, (old, new) in enumerate(zip(old_values, new_values)) if old != new]
        assert len(old_values) == len(new_values)
        info = {'accessor': index, 'vertices': len(old_values), 'byteexact': old_raw == new_raw,
                'changed_vertices': len(different)}
        if different:
            changed_accessors.add(index)
            info['max_abs_axis_delta'] = [max(abs(old[axis] - new[axis]) for _, old, new in different) for axis in range(len(old_values[0]))]
            if semantic == 'POSITION':
                assert material == 'chimney' and index == 26
                for number, old, new in different:
                    assert old[0] == new[0] and old[2] == new[2]
                    assert 0 < new[1] - old[1] <= 0.010001
                    assert old[1] == before['accessors'][index]['max'][1]
                    assert new[1] == after['accessors'][index]['max'][1]
                    changed_positions.append({'primitive': primitive_index, 'material': material,
                                              'vertex': number, 'before': old, 'after': new,
                                              'distance_m': math.dist(old, new)})
            else:
                assert semantic == 'TEXCOORD_0'
                uv_rows.append({'primitive': primitive_index, 'material': material, **info})
        row['attributes'][semantic] = info
    rows.append(row)

assert len(changed_positions) == 12 and len(uv_rows) == 10
expected_json = copy.deepcopy(before)
expected_json['accessors'][26]['max'][1] = after['accessors'][26]['max'][1]
assert expected_json == after
assert set(before.keys()) == {'asset', 'scene', 'scenes', 'nodes', 'materials', 'meshes', 'accessors', 'bufferViews', 'buffers'}
assert not any('Texture' in json.dumps(material) for material in before['materials'])
assert before['materials'] == after['materials']

permitted_offsets = set()
for index in changed_accessors:
    view = before['bufferViews'][before['accessors'][index]['bufferView']]
    start = view.get('byteOffset', 0)
    permitted_offsets.update(range(start, start + view['byteLength']))
changed_byte_offsets = [index for index, (old, new) in enumerate(zip(before_bin, after_bin)) if old != new]
assert all(offset in permitted_offsets for offset in changed_byte_offsets)

shutil.copyfile(BEFORE, OUT / 'before.glb')
shutil.copyfile(AFTER, OUT / 'after.glb')
runtime = []
for name in ['buildings.js', 'wall-relief.js', 'roof-relief.js']:
    source = APP / 'renderers/web/js' / name
    target = OUT / ('runtime-' + name)
    shutil.copyfile(source, target)
    runtime.append({'source': str(source), 'snapshot': target.name, 'sha256': sha(target.read_bytes())})

result = {
    'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'ACTUAL_NATIVE_MASTER_GEOMETRY_DELTA_10MM_STACK_TOP_ONLY_WITH_UV_REPACK_DISCLOSED',
    'before': {'path': str(BEFORE), 'bytes': len(before_bytes), 'sha256': sha(before_bytes)},
    'after': {'path': str(AFTER), 'bytes': len(after_bytes), 'sha256': sha(after_bytes)},
    'actual_position_vertices_changed': len(changed_positions),
    'max_position_displacement_m': max(row['distance_m'] for row in changed_positions),
    'position_changes': changed_positions,
    'unchanged': {
        'nodes_scenes_materials_mesh_descriptors_buffer_layout': True,
        'all_indices_normals_confidence_attributes_byteexact': True,
        'all_other_position_vertices_byteexact': True,
        'door_and_door_panel_positions_byteexact': True,
        'all_horizontal_position_components_byteexact': True,
        'all_binary_bytes_outside_changed_position_and_uv_views_byteexact': True,
    },
    'json_difference_only': 'accessors[26].max[1], the same chimney top rise',
    'uv_repack': {
        'all_10_uv0_arrays_changed': True,
        'byteexact_nonposition_attributes_claim': False,
        'native_material_texture_references': 0,
        'asset_images_textures_samplers': 'absent',
        'cause': 'Native smart_project atlas repack; not a geometry, normals, material or index change.',
        'runtime_static_evidence': 'buildings.js applies wall-/roof-relief. The frozen wall- and roof-relief vertex shaders derive metric UV from position/normal and overwrite the stock map UV varyings. These are static source observations; this comparison does not execute a browser or GPU shader.',
        'details': uv_rows,
    },
    'primitives': rows,
    'runtime_sources': runtime,
    'scope_limits': [
        'This is an actual bounded native MASTER comparison; it is not a new browser, WEB decoding, screenshot, ground or GPU result.',
        'The dated BOTH browser pass used the before WEB. Current WEB bytes differ and must be named separately; no exact-WEB-byte reuse claim.',
        'All ground/door/footprint geometry is unchanged within the MASTER. Source-side positions, sidecars, entrance records and terrain bindings require their separate existing input proofs.',
        'The 10mm bound is geometric. UVs are not byteexact; no full-attribute exactness assertion is made.',
    ],
}
(OUT / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['status', 'actual_position_vertices_changed', 'max_position_displacement_m', 'unchanged']}, indent=2))
