from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys

APP=Path('/workspace/chicago/chicago/4d')
OUT=Path(__file__).resolve().parent
phase=sys.argv[1]
commands={
 'publish-before':['bash','tools/publish.sh'],
 'check-lodging':['python3','tools/build_lodging_model_1835.py','--check'],
 'check-placement':['python3','tools/placement_policy_1835.py','--check','--quiet'],
 'check-lodgers':['python3','tools/seat_lodgers_1835.py','--check'],
 'check-staffing':['python3','tools/staffing_mint_order_1835.py','--check'],
 'check-orderbook':['python3','tools/build_order_book_1835.py','--check'],
 'check-namepool':['python3','tools/replace_invented_residents.py','--check'],
 'derive-1':['node','tools/rederive.mjs','--tail','tools/compile_liberties.py'],
 'publish-after-1':['bash','tools/publish.sh'],
 'focus-liberties':['python3','tools/compile_liberties.py','--check'],
 'focus-sourceuse':['python3','tools/compile_source_use.py','--check'],
 'focus-closing':['python3','tools/rebuild_closing_set.py','--check'],
 'focus-published':['node','tools/check_published.mjs'],
}
assert phase in commands
receipt_path=OUT/(phase+'-receipt.json')
assert not receipt_path.exists(),'Never overwrite an earlier attempt'
guards=json.loads((OUT/'PROTECTED-GUARDS.json').read_text())
def verify():
 for rel,g in guards.items():
  raw=(APP/rel).read_bytes()
  assert len(raw)==g['bytes'] and hashlib.sha256(raw).hexdigest()==g['sha256'],('Protected byte drift',rel)
 policy=json.loads((APP/'data/reconstruction/1835_placement_policy.json').read_text())
 semantic=json.loads((OUT/'SEMANTIC-GUARDS.json').read_text())
 for name in ('constants','clauses','outliers'):
  assert policy[name]==semantic['placement_'+name],('Policy semantic drift',name)
 assert json.loads((APP/'data/reconstruction/1835_lodging_model.json').read_text())['the_figures_this_model_does_not_move']==semantic['lodging_figures_not_moved']
verify()
receipt={'phase':phase,'status':'RUNNING','command':commands[phase],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controller_pid':os.getpid(),'native_only_grant':True}
def save():receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
save()
try:
 env={**os.environ,'TMPDIR':'/workspace/T3082-official23-tmp','TMP':'/workspace/T3082-official23-tmp','TEMP':'/workspace/T3082-official23-tmp','PYTHONDONTWRITEBYTECODE':'1','PATH':'/workspace/shared/tools/usr/bin:'+os.environ.get('PATH',''),'npm_config_cache':'/workspace/shared/npm-cache'}
 with (OUT/(phase+'.log')).open('x')as log:
  child=subprocess.Popen(commands[phase],cwd=APP,env=env,stdout=log,stderr=subprocess.STDOUT)
  receipt['child_pid']=child.pid;save();code=child.wait()
 receipt['exit_code']=code;save()
 verify()
 assert code==0,'Native command failed; preserve log and inspect before any retry/refresh'
 receipt.update(status='PASS',protected_bytes_constants_clauses_outliers_exact=True,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as exc:
 receipt.update(status='FAILED',error=str(exc),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
print(json.dumps(receipt,indent=2))
