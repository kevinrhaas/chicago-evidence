from pathlib import Path
import datetime,json,os,subprocess,sys
out=Path(__file__).resolve().parent
state={'status':'RUNNING','pid':os.getpid(),'head':'5d9d44646f49c69a4add36ece56bfbdab8caad70','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phases':[]}
def save():(out/'ORCHESTRATION.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for phase in ['publish-before','check-lodging','check-placement','check-lodgers','check-staffing','check-orderbook','check-namepool','derive-1','publish-after-1','focus-liberties','focus-sourceuse','focus-closing','focus-published']:
  row={'phase':phase,'status':'RUNNING'};state['phases'].append(row);save()
  with(out/(phase+'-runner.log')).open('x')as log:
   child=subprocess.Popen([sys.executable,str(out/'run_phase.py'),phase],stdout=log,stderr=subprocess.STDOUT)
   row['pid']=child.pid;save();code=child.wait()
  row.update(exit_code=code,status='PASS'if code==0 else'FAILED');save();assert code==0,phase+' failed; preserve all logs; no automatic relaxation/retry'
 state['status']='PASS'
except BaseException as exc:state.update(status='FAILED',error=str(exc));save();raise
finally:state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(state,indent=2))
