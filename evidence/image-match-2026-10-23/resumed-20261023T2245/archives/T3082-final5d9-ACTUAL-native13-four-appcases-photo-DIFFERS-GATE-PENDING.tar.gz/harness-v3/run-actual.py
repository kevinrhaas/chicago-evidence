from pathlib import Path
import datetime,json,os,subprocess,sys
QA=Path(__file__).resolve().parent
OUT=Path('/workspace/T3082-QA-v3-final5d9-20261024')
assert not OUT.exists(),'Preserve every earlier actual run'
assert json.loads(Path('/workspace/T3082-native-final5d9-20261024/ORCHESTRATION.json').read_text())['status']=='PASS'
OUT.mkdir()
state={'status':'RUNNING','head':'5d9d44646f49c69a4add36ece56bfbdab8caad70','pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':[]}
def save():(OUT/'ORCHESTRATION.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 commands=[]
 for viewport in['mobile','desktop']:
  for model in['tremont_house_1','cobweb_castle']:
   label=viewport+'-'+model
   commands.append((label,['node',str(QA/'qa-published.mjs'),'--viewport',viewport,'--ids',model,'--out',str(OUT/label),'--execute']))
 commands.append(('tremont-photo',[sys.executable,str(QA/'run-photo.py'),'--out',str(OUT/'tremont-photo'),'--execute-after-root-grant']))
 env={**os.environ,'TMPDIR':'/workspace/T3082-browser-qa-tmp','TMP':'/workspace/T3082-browser-qa-tmp','TEMP':'/workspace/T3082-browser-qa-tmp','PW_EXECUTABLE':'/usr/bin/chromium','PATH':'/workspace/shared/tools/usr/bin:'+os.environ.get('PATH','')}
 Path(env['TMPDIR']).mkdir(parents=True,exist_ok=True)
 for label,argv in commands:
  row={'case':label,'command':argv,'status':'RUNNING','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['cases'].append(row);save()
  with(OUT/(label+'.log')).open('x')as log:
   child=subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
   row['pid']=child.pid;save();code=child.wait()
  row.update(status='PASS'if code==0 else'FAILED',exit_code=code,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();assert code==0,label+' failed; stop and preserve all results'
 state['status']='PASS_ACTUAL_CASES_MANUAL_IMAGE_REVIEW_OWED'
except BaseException as exc:state.update(status='FAILED',error=str(exc));save();raise
finally:state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(state,indent=2))
