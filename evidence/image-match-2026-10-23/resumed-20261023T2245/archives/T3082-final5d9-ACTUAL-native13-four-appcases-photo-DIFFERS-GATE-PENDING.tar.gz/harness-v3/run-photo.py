from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys

QA=Path(__file__).resolve().parent
APP=Path('/workspace/chicago/chicago/4d')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--out',type=Path);p.add_argument('--execute-after-root-grant',action='store_true');a=p.parse_args()
b=json.loads((QA/'input-bindings.json').read_text());cam=QA/'photo-inputs/camera.json';c=json.loads(cam.read_text());photo=Path(c['photo'])
assert sha(cam)==b['camera_sha256'];assert sha(photo)==b['photo_source_sha256'];assert sha(QA/'photo-inputs/source.jpg')==sha(photo)
for item in b['files']:
 if item['root']=='app':assert sha(APP/item['path'])==item['sha256'],item['path']
config=json.loads((QA/'models.json').read_text());m=next(x for x in config['models']if x['id']=='tremont_house_1');glb=APP/'assets/gltf'/m['asset'];assert sha(glb)==m['master_sha256']
if not a.execute_after_root_grant:
 print(json.dumps({'status':'PREPARED_UNRUN','camera_sha256':sha(cam),'photo_sha256':sha(photo),'master_sha256':sha(glb),'same_provisional_camera':True,'canonical_camera_or_acceptance_write':False},indent=2));sys.exit(0)
assert a.out and a.out.is_absolute() and not a.out.exists(),'Use a fresh absolute external output directory'
a.out.mkdir(parents=True);mutable=a.out/'camera.json';shutil.copyfile(cam,mutable)
argv=['node','tools/photo_match.mjs',str(mutable),'--glb','assets/gltf/'+m['asset'],'--out',str(a.out/'comparison')]
r={'status':'RUNNING','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':argv,'camera_sha256':sha(mutable),'photo_sha256':sha(photo),'glb_sha256':sha(glb),'method':'Actual native photo_match neutral GLB comparison, same provisional camera/source; not the app, terrain, dynamic flag or image-match acceptance.','original_ticket':'T-2385 remains open/DIFFERS'}
receipt=a.out/'PHOTO-RECEIPT.json';save=lambda:receipt.write_text(json.dumps(r,indent=2)+'\n');save()
try:
 env={**os.environ,'TMPDIR':'/workspace/T3082-browser-qa-tmp','PW_EXECUTABLE':'/usr/bin/chromium'};Path(env['TMPDIR']).mkdir(parents=True,exist_ok=True)
 with(a.out/'photo-match.log').open('x')as log:
  child=subprocess.Popen(argv,cwd=APP,env=env,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=child.pid;save();code=child.wait()
 r['exit_code']=code;save();assert code==0,'Photo renderer failed; preserve this run'
 match=json.loads((a.out/'camera.match.json').read_text());assert match['glb_sha256']==sha(glb)and match['camera_sha256']==sha(cam)and match['photo_sha256']==sha(photo);assert match['verdict']=='unreviewed','No accepted match is created automatically'
 r.update(status='PASS_RENDER_UNREVIEWED_NOT_IMAGE_MATCH',manual_side_by_side_review_owed=True,match=match)
except BaseException as exc:r.update(status='FAILED',error=str(exc));save();raise
finally:r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(r,indent=2))
