from pathlib import Path,PurePosixPath
import os,json,hashlib,stat,time,datetime,urllib.request,tarfile,io,shutil,collections
os.sched_setaffinity(0,{3});os.nice(19)
B=Path('/tmp/workspace-verified-duplicate-capacity-plan-20261026T2158');COMMIT='3573b861adb4f0e9e59b85cad647a96ccdfc821b';REPO='kevinrhaas/chicago-evidence';REL='evidence/image-match-2026-10-23/resumed-20261023T2245/';IDX=json.loads((B/'REMOTE-ARCHIVES-472.json').read_text());FLOOR=512*1024**2;GOAL=600*1024**2
sha=lambda d:hashlib.sha256(d).hexdigest()
gitsha=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,x):
 p=B/n;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2)+'\n');t.replace(p)
def raw(path):
 url='https://raw.githubusercontent.com/'+REPO+'/'+COMMIT+'/'+urllib.parse.quote(path,safe='/')
 with urllib.request.urlopen(url,timeout=120)as r:assert r.status==200;return r.read()
import urllib.parse
bycount=collections.defaultdict(list);bysha={}
for rec in IDX:
 bycount[(rec.get('source_file_count'),rec.get('source_bytes'))].append(rec)
 if rec.get('source_manifest_sha256'):bysha[rec['source_manifest_sha256']]=rec
candidates=[];seen=set();excluded=[]
SKIP_TOP={'blender-dl','playwright-browsers','apt','python','downloads','evidence-native-fallback-20261026T1352'}
for cur,dirs,files in os.walk('/workspace/shared',followlinks=False):
 p=Path(cur)
 if p==Path('/workspace/shared'):dirs[:]=[x for x in dirs if x not in SKIP_TOP and not(p/x).is_symlink()]
 if (p/'.git').exists()or((p/'HEAD').is_file()and(p/'objects').is_dir()):dirs[:]=[];continue
 dirs[:]=[x for x in dirs if x not in {'.git','objects','node_modules','profile','profiles','Default','__pycache__'}and not(p/x).is_symlink()and'glessner'not in x.lower()]
 if 'MANIFEST.json'not in files:continue
 mf=p/'MANIFEST.json'
 try:
  data=mf.read_bytes();m=json.loads(data);rows=m.get('files',m.get('members'));rows=[dict(path=k,**v)for k,v in rows.items()]if isinstance(rows,dict)else rows
  if not isinstance(rows,list)or not all(isinstance(r,dict)and'path'in r and'bytes'in r for r in rows):continue
 except Exception:continue
 if 'glessner'in str(p).lower():continue
 rec=bysha.get(sha(data));rs=[rec]if rec else bycount.get((len(rows)+1,sum(r['bytes']for r in rows)+len(data)),[])
 for rec in rs:
  if (str(p),rec['name'])in seen:continue
  seen.add((str(p),rec['name']));potential=0
  for row in rows:
   q=p/row['path']
   try:
    s=q.lstat()
    if stat.S_ISREG(s.st_mode)and s.st_nlink==1 and'glessner'not in str(q).lower():potential+=s.st_blocks*512
   except OSError:pass
  candidates.append({'root':str(p),'manifest_sha256':sha(data),'record':rec,'potential':potential})
candidates.sort(key=lambda x:x['potential'],reverse=True);save('ALL-PUBLISHED-CLOSED-WS-CANDIDATES.json',candidates);print('CANDIDATES',len(candidates),'potential',sum(x['potential']for x in candidates),flush=True)
# These are closed packet roots, never worktrees: each packet must match the immutable published original MANIFEST.
def reader_guard(root,targets):
 aliases=[root]
 for relocation in Path('/workspace/shared').glob('relocated-closed-checkpoints*/RELOCATION.json'):
  try:
   entries=json.loads(relocation.read_text()).get('entries',[])
   for entry in entries:
    backing=entry.get('backing_path',entry.get('destination',''));original=entry.get('original_path',entry.get('source',''))
    if backing and original and(root==backing or root.startswith(backing+'/')):aliases.append(original+root[len(backing):])
  except Exception:pass
 hits=[];fd_denied=[];maps_denied=[];cmd_denied=[];fd_readable=0;live_checked=0;zombies_skipped=0
 ancestors={os.getpid()};pid=os.getppid()
 for _ in range(5):
  if pid<=1:break
  ancestors.add(pid)
  try:pid=int((Path('/proc')/str(pid)/'stat').read_text().split(') ',1)[1].split()[1])
  except Exception:break
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit()or int(proc.name)in ancestors:continue
  try:
   if proc.stat().st_uid!=os.getuid():continue
   fields=(proc/'stat').read_text().split(') ',1)[1].split()
   if fields[0]=='Z':zombies_skipped+=1;continue
   live_checked+=1
   try:cmd=(proc/'cmdline').read_bytes().decode(errors='replace')
   except PermissionError:cmd_denied.append(proc.name);continue
   if any(prefix in cmd for prefix in aliases):hits.append({'pid':proc.name,'kind':'COMMAND_PREFIX'})
   try:
    cwd=os.readlink(proc/'cwd')
    if any(cwd==prefix or cwd.startswith(prefix+'/')for prefix in aliases):hits.append({'pid':proc.name,'kind':'CWD_PREFIX'})
   except(FileNotFoundError,ProcessLookupError,PermissionError):pass
   try:
    for fd in(proc/'fd').iterdir():
     try:
      target=os.readlink(fd);fd_readable+=1
      if any(target==prefix or target.startswith(prefix+'/')for prefix in aliases):hits.append({'pid':proc.name,'kind':'OPEN_FD_PREFIX','fd':fd.name})
     except PermissionError:
      if proc.name not in fd_denied:fd_denied.append(proc.name)
     except(FileNotFoundError,ProcessLookupError):pass
   except PermissionError:fd_denied.append(proc.name)
   try:
    maps=(proc/'maps').read_text(errors='replace')
    if any(prefix in maps for prefix in aliases):hits.append({'pid':proc.name,'kind':'MMAP_PREFIX'})
   except PermissionError:maps_denied.append(proc.name)
  except(FileNotFoundError,ProcessLookupError):pass
  except PermissionError:cmd_denied.append(proc.name)
 return {'at':now(),'hits':hits,'original_and_backing_aliases_checked':aliases,'same_uid_live_process_cmdlines_checked':live_checked,'unreadable_live_cmdlines':cmd_denied,'fd_links_readable':fd_readable,'fd_visibility_restricted_pids':sorted(set(fd_denied)),'maps_visibility_restricted_pids':maps_denied,'zombies_skipped_not_live_readers':zombies_skipped,'full_FD_visibility_NOT_claimed':True,'safety_basis':'Explicit Root authorization for CLOSED duplicate staging; immutable original manifest binding; fresh every-member archive/local SHA/size/mode; stable inode/mtime/ctime CAS; zero observed current command/cwd/FD/map references; owner confirms packet closed. Restricted sibling FD visibility is disclosed, not called globallyzero readers.'}
initial=shutil.disk_usage('/workspace').free;results=[];failures=[];allocated=0;payloadbytes=0;save('RETIREMENT-STATUS.json',{'status':'VERIFYING_NO_SOURCE_GIT_OR_MIRROR_CHANGES','at':now(),'initial_free_workspace':initial})
for candidate in candidates:
 if allocated>=GOAL and shutil.disk_usage('/workspace').free>=FLOOR:break
 root=Path(candidate['root']);rec=candidate['record'];archive_path=REL+'archives/'+rec['name']+'.tar.gz';manifest_path=archive_path+'.manifest.json'
 try:
  assert 'PASS'in rec['readback']and str(root).startswith('/workspace/shared/')and not root.is_symlink()
  assert not(root/'.git').exists()and not(root/'objects').exists()
  sidebytes=raw(manifest_path);side=json.loads(sidebytes);pubrows=side['files'];assert side['name']==rec['name']and len(pubrows)==rec['source_file_count']
  bypath={row['path']:row for row in pubrows};assert len(bypath)==len(pubrows);assert bypath['MANIFEST.json']['sha256']==candidate['manifest_sha256'];assert sha((root/'MANIFEST.json').read_bytes())==candidate['manifest_sha256']
  # Fresh complete immutable archive readback, including exact part reconstruction where needed.
  if rec.get('remote_transport'):
   transport=json.loads(raw(rec['remote_transport']['manifest_path']));parts=[]
   for row in sorted(transport['parts'],key=lambda r:r['index']):
    data=raw(row['path']);assert len(data)==row['bytes']and sha(data)==row['sha256']and gitsha(data)==row['git_blob'];parts.append(data)
   archive=b''.join(parts);assert len(archive)==transport['archive_bytes']and sha(archive)==transport['archive_sha256']
  else:archive=raw(archive_path)
  assert len(archive)==rec['bytes']and sha(archive)==rec['sha256']
  local=[];remote_verified=0
  with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz')as tf:
   members=tf.getmembers();assert len(members)==len(pubrows)and {x.name for x in members}==set(bypath)
   for member in members:
    row=bypath[member.name];assert member.isfile()and member.size==row['bytes'];data=tf.extractfile(member).read();assert sha(data)==row['sha256'];remote_verified+=1
    if 'mode'in row:
     mode=int(row['mode'],0)if isinstance(row['mode'],str)else row['mode'];assert member.mode==mode
    rel=PurePosixPath(member.name);assert not rel.is_absolute()and'..'not in rel.parts
    if member.name in {'MANIFEST.json','ARCHIVE-MANIFEST.json','STATE.json','PAYLOADS-RESTORE.json'}:continue
    q=root/member.name
    if 'glessner'in str(q).lower()or'.git'in q.parts:continue
    if any(parent.is_symlink()for parent in[q,*q.parents]if parent!=root.parent and str(parent).startswith(str(root))):continue
    try:s=q.lstat()
    except FileNotFoundError:continue
    if not stat.S_ISREG(s.st_mode)or s.st_nlink!=1:continue
    assert s.st_size==member.size and stat.S_IMODE(s.st_mode)==member.mode,(q,'size/mode')
    assert sha(q.read_bytes())==row['sha256'],(q,'local hash')
    local.append({'path':str(q),'relative_path':member.name,'sha256':row['sha256'],'bytes':s.st_size,'mode':member.mode,'allocated':s.st_blocks*512,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns})
  del archive
  guard=reader_guard(str(root),local)
  if guard['hits']or guard['unreadable_live_cmdlines']:
   failures.append({'root':str(root),'status':'SKIP_READER_GUARD','guard':guard});continue
  if not local:continue
  locator={'status':'CLOSED_DUPLICATE_PAYLOADS_RETIRED_AFTER_FRESH_IMMUTABLE_EVERY_MEMBER_VERIFICATION','at':now(),'publication_commit':COMMIT,'repository':REPO,'archive_path':archive_path,'archive_bytes':rec['bytes'],'archive_sha256':rec['sha256'],'remote_transport':rec.get('remote_transport'),'immutable_archive_url':'https://raw.githubusercontent.com/'+REPO+'/'+COMMIT+'/'+archive_path,'immutable_sidecar_manifest_url':'https://raw.githubusercontent.com/'+REPO+'/'+COMMIT+'/'+manifest_path,'sidecar_sha256':sha(sidebytes),'original_manifest_sha256':candidate['manifest_sha256'],'all_remote_members_freshly_verified':remote_verified,'retired_paths':[r['relative_path']for r in local],'local_source_manifest_retained':True,'restore':'Fetch immutable archive (or ordered transport parts), verify recorded SHA/bytes; extract only desired members into this CLOSED staging directory, preserving tar modes. This is not a source worktree. Restore metadata original MANIFEST is unchanged. Never extract blindly over active source worktrees.','source_Git_assets_originals_or_live_receipts_touched':False}
  if rec.get('remote_transport'):locator['immutable_transport_url']='https://raw.githubusercontent.com/'+REPO+'/'+COMMIT+'/'+rec['remote_transport']['manifest_path']
  marker=root/'PAYLOADS-RESTORE.json';marker.write_text(json.dumps(locator,indent=2)+'\n');marker.chmod(0o600)
  removed=[];freebefore=shutil.disk_usage('/workspace').free
  for row in local:
   q=Path(row['path']);s=q.lstat();assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size,stat.S_IMODE(s.st_mode),s.st_mtime_ns,s.st_ctime_ns)==(row['device'],row['inode'],row['nlink'],row['bytes'],row['mode'],row['mtime_ns'],row['ctime_ns']),q
   q.unlink();removed.append(row);allocated+=row['allocated'];payloadbytes+=row['bytes']
  # Remove only now-empty payload subdirectories; packet manifest/restore locator remain.
  for d in sorted([p for p in root.rglob('*')if p.is_dir()and not p.is_symlink()],key=lambda p:len(p.parts),reverse=True):
   try:d.rmdir()
   except OSError:pass
  row={'root':str(root),'archive_name':rec['name'],'archive_sha256':rec['sha256'],'manifest_sha256':candidate['manifest_sha256'],'fresh_remote_members_verified':remote_verified,'reader_guard':guard,'retired':removed,'allocated_bytes_reclaimed':sum(x['allocated']for x in removed),'logical_bytes_reclaimed':sum(x['bytes']for x in removed),'free_workspace_before':freebefore,'free_workspace_after':shutil.disk_usage('/workspace').free,'local_restore_locator':str(marker)};results.append(row);save('RETIRED-PACKETS.json',results);save('VERIFICATION-SKIPS.json',failures);save('RETIREMENT-STATUS.json',{'status':'RETIRING_ONLY_FRESHLY_VERIFIED_CLOSED_DUPLICATES','at':now(),'packets':len(results),'allocated_bytes_reclaimed':allocated,'payload_bytes_reclaimed':payloadbytes,'initial_free_workspace':initial,'current_free_workspace':shutil.disk_usage('/workspace').free});print('RETIRED',root.name,len(removed),'allocated',allocated,'freeWS',shutil.disk_usage('/workspace').free,flush=True)
 except Exception as e:
  failures.append({'root':str(root),'status':'VERIFICATION_STOP_NO_UNVERIFIED_DELETION','error':repr(e)});save('VERIFICATION-SKIPS.json',failures);print('SKIP',root.name,repr(e),flush=True)
result={'status':'VERIFIED_CLOSED_WS_PAYLOAD_RETIREMENT_COMPLETE','at':now(),'initial_free_workspace':initial,'final_free_workspace':shutil.disk_usage('/workspace').free,'measured_net_workspace_increase':shutil.disk_usage('/workspace').free-initial,'allocated_bytes_reclaimed':allocated,'logical_bytes_reclaimed':payloadbytes,'retired_packets':len(results),'skipped_candidates':len(failures),'native512MiB_guard_met':shutil.disk_usage('/workspace').free>=FLOOR,'goal_allocated600MiB_met':allocated>=GOAL,'original_manifests_and_public_restore_locators_retained':True,'source_git_objects_refs_config_assets_live_receipts_protectedGlessner_runtime_caches_untouched':True,'no_rehome_or_mirror_topology_changes':True};save('RESULT.json',result);save('RETIREMENT-STATUS.json',result);print(json.dumps(result,indent=2),flush=True)
