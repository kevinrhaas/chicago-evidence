# Current M over checked S and incoming Abb — closed CPU checkpoint

One bounded serial CPU pass calls actual current fort build() and native
MeshBuilder/TonedBuilder through the previously used tiny bpy-data adapter.
All 24 non-lighthouse complete snapshots match checked S source bd316f7f4,
including the corrected Lake House 64-triangle shell and five first-fort
gallery/beam/front controls. The lighthouse changes from 132 to 8,021 triangles
and its complete snapshot matches the original reviewed prototype.

Current canonical M modules, baseline modules and all 25 before/after records
are captured. Common source hashes are named; the existing source/evidence
checkpoints retain those dependencies. Summary hashes include vertices, polygon
indices, materials, confidence, tone, smooth flags and winding normals. This is
not Blender export, web quantization, shader, native-writer, app, full-gate or
image-match acceptance. All 25 current fort recipes remain stale until actual
exports. Source base includes the reviewed Abb/Ames merge inputs; its three
registered generated conflicts remain unaccepted pending normal writers.

The separate corrected-admission/policy packet is a40b8122. Public checked S
checkpoint is bd316f7f4. Original picture obligations remain open/DIFFERS.
