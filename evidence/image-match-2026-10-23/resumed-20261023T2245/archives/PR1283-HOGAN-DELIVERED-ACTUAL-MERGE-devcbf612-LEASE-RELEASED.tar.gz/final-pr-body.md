Hogan’s store now has a dark recessed doorway, a boarded gable opening and a shorter chimney, using existing record controls. Credited before/after comparisons record the improvement toward Cameron’s drawing.

The dimensions and construction choices remain reconstructed. The retrospective drawing supplies neither a survey scale nor proof of the store’s exact state on 1 July 1835. Original image ticket T-2377 remains open, with both comparisons marked **differs**.

Validation:

- Official pinned Blender master and genuine web export completed for Hogan. All 82 log recipes are fresh; the other 81 record/master/web sets remain byte-identical.
- Native regeneration settled in two laps. Existing lodger cards, seated ledger and order book remain exact.
- Local and hosted gates pass **1,064 checks / 384 self-tests**. The hosted merge checkout has the same full source tree as public head `6e66191`.
- All **18 published smoke jobs pass**, covering stages 1–15 in both viewports: 829 desktop and 836 mobile assertions, zero failures or page errors. Independent Hogan app/card checks and front-view inspection also pass in both layouts.

[Verified source, comparisons, validation and recovery evidence](https://github.com/kevinrhaas/chicago-evidence/blob/f7b9dccfaf8f5b05dbc5c1cc12a14cc67f55f8a0/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md). Merge target: `dev`.

[Before comparison](https://github.com/kevinrhaas/chicago/blob/6e66191ebaea1f9d4d15c7a1ac9042a341d3714b/chicago/4d/docs/RESEARCH/hogan-picture-match-T-3118/before/cameron-1833-before-side-by-side.jpg) · [After comparison](https://github.com/kevinrhaas/chicago/blob/6e66191ebaea1f9d4d15c7a1ac9042a341d3714b/chicago/4d/docs/RESEARCH/hogan-picture-match-T-3118/after/cameron-1833-after-side-by-side.jpg)
