from pathlib import Path
import json,copy,hashlib,importlib.util,sys,ast,math,types,dataclasses,collections,datetime
P=Path(__file__).resolve().parent;C=P/'current-api'
spec=importlib.util.spec_from_file_location('frozen_fort_params',C/'fort_structure_params.py');mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
record=json.loads((C/'fort_dearborn_commandants_quarters.json').read_text());phase=record['phases'][0];old=mod.from_phase(phase,record)
tree=ast.parse((C/'fort_structure.py').read_text());funcs={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
ns={'FortStructureParams':mod.FortStructureParams,'MeshBuilder':object,'wall_openings':mod.wall_openings,'math':math,'openings':types.SimpleNamespace(CASING_W_M=.09,SILL_HORN_M=.03)}
call=[]
def spy(b,axis,plane,u0,u1,z0,z1,out,conf,kind='window'):
 call.append({'face':('front'if out==1 else'back')if axis=='y'else('right'if out==1 else'left'),'kind':kind,'u0':u0,'u1':u1,'z0':z0,'z1':z1})
ns['_opening']=spy
for n in ['_openings','_explicit_openings','_gallery_post_centres']:exec(compile(ast.Module(body=[funcs[n]],type_ignores=[]),str(C/'fort_structure.py'),'exec'),ns)
ns['_openings'](None,old,0.,0.);legacy=copy.deepcopy(call)
new=copy.deepcopy(record);form=new['phases'][0]['form']
form['gallery']={'value':True,'confidence':'reconstructed','sources':['wentworth_1881_fort_dearborn'],'note':"PROPOSED T-2388 PARTIAL FRONT-GALLERY HYPOTHESIS, NOT ADOPTED. The directly inspected 1881 Wentworth p.92 engraving after Hesler's 1855 photograph, with the p.93 key identifying A as the brick commandant's quarters, visibly shows an upper gallery front with rail, canopy and ground-reaching posts on A beside B. Pictured presence in 1855 is inferred from those pixels; applying it twenty years earlier to 1 July 1835 is reconstructed because no source dates the gallery's construction or proves continuity. The existing two-storey front helper supplies one straight gallery only. The visible corner return, outside stairs and source-specific group-camera fit remain unresolved; no whole-fort match or original-ticket completion follows. The 2.1 m reach, post section/rhythm, rail/deck/baluster sections and canopy fall are reconstructed helper choices, not image measurements. Preserve original dates, footprint, placement, height and other form. Record these choices as liberties before actual adoption."}
form['gallery_storeys']={'value':2,'confidence':'reconstructed','sources':['wentworth_1881_fort_dearborn'],'note':"The 1855 pictured upper walk and open ground gallery motivate the two-level form. July1835 transfer and all heights are reconstructed. Existing 5.4 m wall and 2.7 m storey line remain unchanged; no 1855 date is backdated as attestation."}
form['face_openings']={'value':legacy,'confidence':'reconstructed','note':"Exact procedural rectangles copied from the current 03b027ba commandant's build, not a new pictured fenestration reading. Explicit declaration enables existing gallery-pier clearance without changing any aperture. All front and back rectangles are retained; both gable faces remain empty as before. No source attests these opening dimensions or stations."}
resolved=mod.from_phase(new['phases'][0],new);call.clear();ns['_openings'](None,resolved,0.,0.)
canon=lambda x:json.dumps(x,sort_keys=True)
assert collections.Counter(map(canon,legacy))==collections.Counter(map(canon,call))
oldp=dataclasses.asdict(old);newp=dataclasses.asdict(resolved);delta=[k for k in oldp if oldp[k]!=newp[k]];assert set(delta)=={'gallery','gallery_storeys','face_openings','confidence'}
posts=ns['_gallery_post_centres'](resolved,.14);margin=.14/2+.09+.03
for x in posts:
 for o in legacy:
  if o['face']=='front':assert x<=o['u0']-margin+1e-9 or x>=o['u1']+margin-1e-9
(P/'COMMANDANT-RECORD-CANDIDATE.json').write_text(json.dumps(new,indent=2)+'\n')
(P/'PURE-PARAMETER-AND-OPENING-PROOF.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'READONLY PREPARATION: no canonical edit, mesh, recipe, app or gate run','base_dev':'03b027ba6bed8d8ebf1a20e716462ea2b8b54739','status':'PASS_PURE_ONLY','gallery_before':old.gallery,'gallery_after':resolved.gallery,'gallery_storeys_before':old.gallery_storeys,'gallery_storeys_after':resolved.gallery_storeys,'resolved_delta_only':delta,'opening_count':len(legacy),'opening_multiset_byte_numbers_exact':True,'all_front_back_retained':True,'explicit_post_centres':posts,'both_storey_aperture_clearance_margin_m':margin,'all_posts_clear':True,'new_generator_api':False,'mesh_bake':'UNRUN','image_match':'UNRUN','claim_or_original_done':'NOT_REQUESTED'},indent=2)+'\n')
print(json.dumps({'resolved_delta':delta,'opening_count':len(legacy),'posts':posts,'status':'PASS_PURE_ONLY'}))
