### L-miller-frame-ridge-stack-2381 — the Miller range's short roof flue

**Covers:** `miller_house.log_frame_1827.form.frame_addition_ridge_stack`.

**Decision:** Replace only the tall range's previous full-height exterior end stack with a short flue penetrating that range's own ridge. The numeric tuple is reconstructed: fraction 0.40 along the addition's x ridge, 0.45 m square shaft and 0.45 m head above ridge are first-fit choices, not measurements. The new stack renders R; the separate count/form inference and unchanged low log core's existing I stack retain their earlier inference. Total count, main and cabin massing, footprint, placement, other openings and roof dimensions remain unchanged.

**Source and limits:** `blanchard_shober_1867_wolf_point`, Rufus Blanchard/Chas. Shober & Co., Chicago, 1867, labelled Wolf's Point in 1833; existing cleared NYPL/Commons surrogate. The inspected sheet shows a short roof head over the tall log-and-board range. Roof penetration is inferred pictured form; the retrospective depiction does not establish exact dimensions or unchanged appearance on 1 July 1835. Other held pictures do not independently establish absence of the low core's inferred stack. No source date, rights status or authentic material/pigment is newly asserted.

**Verification owed:** Genuine pinned selected pilot and unchanged-camera review, then the complete 82-member native family rebuild and verification of 81 unchanged master/WEB control pairs. All original picture/massing/opening/camera differences remain subject to the T-3153 stopping rule. This bounded correction is not an original-ticket matches or completion claim.

**Ticket:** T-2381.

**Recorded:** 2026-10-27.
