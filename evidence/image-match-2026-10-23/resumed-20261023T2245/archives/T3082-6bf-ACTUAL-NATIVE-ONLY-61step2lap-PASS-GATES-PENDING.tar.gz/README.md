# T-3082 native-only preparation passed on the 6bf stack

The parent granted exclusive local publish/materialization and ordered native
derivation, without browser/fullgate/extra Blender work. All13 actual phase
receipts exited0. The heavy slot was returned at02:50:25Z, before this LIGHT
checkpoint review. Source remains exact6bf plus the bounded roof/review-wording
unit; no newer root working tree was integrated.

Freshness was verified first for all23 frame and82 log records, their105 native
recipe hashes and210 actual master/web files. The normal publisher then
materialized the correct three committed Glessner package outputs, with exact
member hashes verified, and published the source. Older incompatible outputs
remain held outside the checkout and were not overwritten or repacked.

Native lodging, placement, lodger seating, staffing, orderbook and name-pool
checks all passed before derivation. No refresh writer was needed. All22 lodger
cards, the complete seated ledger/orderbook/lodging model/placement policy,
constants, clauses and outliers stayed exact, as did authored sources and all
105 records/210 assets. No population identities or policy constants were tuned.

The inherited202-step native manifest's affected tail began normally at
compile_liberties (step142 as printed), ran61 steps in order, and settled after
two laps; its final lap changed nothing. compile_scene was invoked only by that
ordered tail. The normal publisher then refreshed the generated mirror again.
Focused liberties, source-use, closing-set and published-mirror checks all
passed. The compiled ledger contains734 liberties; all422 source IDs resolve.

Exactly five new native tracked paths differ from the pre-native authored state:
the compiled liberties, Tremont sidecar, Gifford source sidecar/index and source
use coverage. Their exact snapshots, native-only patch and complete current diff
are selected here. Every other previously owned delta is unchanged, and no
unrelated native source delta appeared. site/4d remains ignored generated output;
only small published source/build proof files are retained, not the whole mirror.

The claim was rechecked against isolated remote main after its ordinary3h expiry.
It was still this agent's actor. Normal CAS claim refresh succeeded without
force or manual timestamp edits at02:45:25.144Z, ticket commit5a8a93595e629e93119a76329c3571b5bd069885.
The previous claim/timepoint and exact command/results are preserved.

This is NATIVE-ONLY evidence on6bf. Current combined browser picture/card review,
full preflight/check, published mobile/desktop smoke, latest-parent composition,
code commit/PR/merge remain pending. Root's separately reviewed bbox diagnostic
and future source changes are not tested or adopted by this packet. Original
T-2385 stays open/claimed and DIFFERS. Source-use rights/attribution remain within
standing owner-approved limits without upgrade. The separate broad-left flag
pose remains unadopted research; global native wind/flag state stayed unchanged.

All logs, command arrays, durable controller/child PIDs, exit statuses, protected
byte/semantic guards and actual changed native outputs are selected by the
manifest. No live worktree, live browser, held old GLBs or full ignored mirror is
needed to verify this checkpoint. Do not relabel these receipts onto a newer tree.
