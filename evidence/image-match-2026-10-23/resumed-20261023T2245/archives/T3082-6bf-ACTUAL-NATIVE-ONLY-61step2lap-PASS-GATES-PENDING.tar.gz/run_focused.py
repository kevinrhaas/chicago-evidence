from pathlib import Path
import datetime,json,os,subprocess,sys
out=Path(__file__).resolve().parent
assert json.loads((out/'derive-1-receipt.json').read_text())['status']=='PASS'
assert json.loads((out/'publish-after-1-receipt.json').read_text())['status']=='PASS'
state={'status':'RUNNING','controller_pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phases':[]}
def save():(out/'FOCUSED-ORCHESTRATION.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for phase in ['focus-liberties','focus-sourceuse','focus-closing','focus-published']:
  row={'phase':phase,'status':'RUNNING'};state['phases'].append(row);save()
  with(out/(phase+'-runner.log')).open('x')as log:
   child=subprocess.Popen([sys.executable,str(out/'run_phase.py'),phase],stdout=log,stderr=subprocess.STDOUT)
   row['pid']=child.pid;save();code=child.wait()
  row.update(exit_code=code,status='PASS'if code==0 else'FAILED');save();assert code==0,phase+' failed; no relaxation/retry'
 state['status']='PASS'
except BaseException as exc:state.update(status='FAILED',error=str(exc));save();raise
finally:state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(state,indent=2))
