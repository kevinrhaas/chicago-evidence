from pathlib import Path
import struct,json,hashlib,collections
P=Path(__file__).resolve().parent;original=P/'shadow/chicago/4d/assets/humans';r1=P/'run1/retained-scratch/out';r2=P/'run2/retained-scratch/out';sha=lambda b:hashlib.sha256(b).hexdigest()
def parse(path):
 data=path.read_bytes();assert struct.unpack_from('<III',data)==(0x46546c67,2,len(data));at=12;chunks=[]
 while at<len(data):
  n,t=struct.unpack_from('<II',data,at);chunks.append((t,data[at+8:at+8+n]));at+=8+n
 assert at==len(data)and chunks[0][0]==0x4e4f534a
 return data,json.loads(chunks[0][1]),chunks

def differences(a,b,path='$'):
 if type(a)!=type(b):yield{'path':path,'committed':a,'rebuilt':b}
 elif isinstance(a,dict):
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:yield{'path':path+'.'+k,'committed':a.get(k),'rebuilt':b.get(k)}
   else:yield from differences(a[k],b[k],path+'.'+k)
 elif isinstance(a,list):
  if len(a)!=len(b):yield{'path':path+'.length','committed':len(a),'rebuilt':len(b)}
  for i,(x,y)in enumerate(zip(a,b)):yield from differences(x,y,path+'['+str(i)+']')
 elif a!=b:yield{'path':path,'committed':a,'rebuilt':b}

def matrix(q):
 x,y,z,w=q
 return[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w),2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w),2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]
rows=[]
for f in sorted(original.rglob('c4d_fixture.lod*.glb')):
 rel=f.relative_to(original);a,ja,ca=parse(f);b,jb,cb=parse(r1/rel);c,jc,cc=parse(r2/rel);diff=list(differences(ja,jb));changed=sorted({int(d['path'].split('[')[1].split(']')[0])for d in diff if d['path'].startswith('$.nodes[')})
 nodes=[]
 for n in changed:
  q0=ja['nodes'][n]['rotation'];q1=jb['nodes'][n]['rotation'];nodes.append({'index':n,'name':ja['nodes'][n].get('name'),'committed_rotation':q0,'rebuilt_rotation':q1,'maximum_rotation_matrix_component_delta':max(abs(x-y)for x,y in zip(matrix(q0),matrix(q1)))})
 bins_a=[v for t,v in ca if t==0x004e4942];bins_b=[v for t,v in cb if t==0x004e4942]
 rows.append({'path':'assets/humans/'+str(rel),'committed_bytes':len(a),'run1_bytes':len(b),'run2_bytes':len(c),'committed_sha256':sha(a),'run1_sha256':sha(b),'run2_sha256':sha(c),'run1_run2_byte_exact':b==c,'committed_rebuilt_byte_exact':a==b,'json_raw_byte_exact':ca[0][1]==cb[0][1],'bin_raw_byte_exact':bins_a==bins_b,'committed_BIN_sha256':[sha(v)for v in bins_a],'run1_BIN_sha256':[sha(v)for v in bins_b],'json_differences':diff,'changed_nodes':nodes,'unchanged_JSON_top_level_blocks':[k for k in ja if k!='nodes'and ja.get(k)==jb.get(k)],'changed_nodes_are_not_skin_joints':all(n not in set(k for skin in ja.get('skins',[])for k in skin['joints'])for n in changed),'node_arrays_except_two_rotations_equal':all(d['path'].startswith('$.nodes[')and'.rotation['in d['path']for d in diff),'asset_generators':[ja.get('asset'),jb.get('asset')],'note':'No bytes or quaternions were normalized/modified; raw SHA/JSON/BIN compared directly. Matrix deltas describe semantic effect only.'})
report={'status':'ACTUAL_REPRODUCTION_FAILS_8_OF_8__TWO_LOCAL_RUNS_COMPARED','runs_exit_codes':[int((P/f'run{i}/exit-code.txt').read_text())for i in [1,2]],'all8_local_rebuilds_deterministic':all(r['run1_run2_byte_exact']for r in rows),'all8_committed_BIN_payloads_exact_to_rebuild':all(r['bin_raw_byte_exact']for r in rows),'all8_only_two_rest_node_quaternion_JSON_differences':all(len(r['json_differences'])==8 and len(r['changed_nodes'])==2 and r['node_arrays_except_two_rotations_equal']for r in rows),'files':rows}
(P/'glb-byte-analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='files'},indent=2));print(json.dumps([{'path':r['path'],'sizes':[r['committed_bytes'],r['run1_bytes'],r['run2_bytes']],'nodes':r['changed_nodes']}for r in rows[:2]],indent=2))
