#!/usr/bin/env python3
"""Preserve ONLY this diagnostic's unchanged exporter scratch on exit."""
import os,sys,shutil,subprocess
from pathlib import Path
capture=os.environ.get('HUMAN_DIAGNOSTIC_CAPTURE')
if capture:
 for arg in sys.argv[1:]:
  source=Path(arg)
  if source.is_dir() and source.name.startswith('humanexport.') and source.parent.resolve()==Path(os.environ['TMPDIR']).resolve():
   target=Path(capture)/'retained-scratch'
   if target.exists():raise SystemExit('REFUSED overwrite retained scratch')
   shutil.copytree(source,target)
subprocess.run(['/usr/bin/rm',*sys.argv[1:]],check=True)
