from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path('/tmp/chicago-log-integration');out=Path(__file__).resolve().parent;head='da65119e52d6bb615bcdd72ef6dd14230e30414e';shadow=out/'shadow';files=subprocess.check_output(['git','ls-tree','-r','--name-only',head],cwd=repo,text=True).splitlines()
selected=[f for f in files if f.startswith(('chicago/4d/tools/human_','chicago/4d/data/humans/')) or f.startswith('chicago/4d/assets/humans/c4d_fixture.') or f.startswith('chicago/4d/assets/humans/web/c4d_fixture.') or f in ['.github/workflows/chicago-4d-humans.yml','chicago/4d/tools/web_derivatives.sh','chicago/4d/generators/blender.pin','chicago/4d/docs/LIBERTIES.md','chicago/4d/docs/HUMAN-ASSET-CONTRACT.md','chicago/4d/AGENTS.md','chicago/4d/assets/LICENSES.md']]
rows=[]
for rel in selected:
 b=subprocess.check_output(['git','show',head+':'+rel],cwd=repo);p=shadow/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 if p.suffix=='.sh':p.chmod(0o755)
 rows.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':subprocess.check_output(['git','rev-parse',head+':'+rel],cwd=repo,text=True).strip()})
(out/'shadow-inputs.json').write_text(json.dumps({'source_public_commit':head,'git_repo_used_readonly':str(repo),'file_count':len(rows),'total_bytes':sum(r['bytes']for r in rows),'files':rows},indent=2)+'\n')
# Preserve the closed original CI evidence as immutable dependency and copy its small raw log.
failure=Path('/tmp/PR1260-head-da65119-watch/non-summary-checks/closed-humans-reproduction-failure');m=json.loads((failure/'MANIFEST.json').read_text())
for r in m['files']:assert hashlib.sha256((failure/r['path']).read_bytes()).hexdigest()==r['sha256']
(out/'original-CI-manifest-reference.json').write_text(json.dumps({'path':str(failure/'MANIFEST.json'),'sha256':hashlib.sha256((failure/'MANIFEST.json').read_bytes()).hexdigest(),'verified_all_files':True},indent=2)+'\n');shutil.copyfile(failure/'humans.log',out/'original-CI-humans.log')
print(len(rows),sum(r['bytes']for r in rows))
