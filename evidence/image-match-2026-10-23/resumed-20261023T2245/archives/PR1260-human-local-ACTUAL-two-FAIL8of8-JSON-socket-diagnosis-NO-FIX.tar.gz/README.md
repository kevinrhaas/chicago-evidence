# Exact da65119 human-fixture reproduction diagnosis

**Actual result: reproduction FAIL8/8, twice. Contract8/8 PASS is a separate result.** Both independent local rebuilt sets are byte-for-byte equal to each other. Each differs from its committed fixture only in eight JSON quaternion scalars on `socket_hand_l`/`socket_hand_r`; every master and web BIN payload is byte-for-byte identical to committed. No byte/hash/quaternion normalization or source/fixture edits were used.

Source is explicit public commit `da65119e52d6bb615bcdd72ef6dd14230e30414e`, extracted read-only from existing Git objects into a68-file/4.88MB owned shadow. All68 original source/fixture paths remain exact after both runs. The original CI failure is preserved and its closed manifest/all files were verified. The72-path85→da equality guard and lack of a base85 humans CI result do not establish when or why the mismatch arose; no baseline/environment cause is asserted.

## Actual runs and exact bytes

`run1/export.log`, `run2/export.log` are the unchanged `tools/human_export.sh --verify` transcripts. Both exit1, name all8 differences, and first report8 contract-valid GLBs. `run*/retained-scratch` retains each actual generated blend,4 masters and4 web derivatives. The export script itself was not edited. A disclosed diagnostic `rm` shim copies only its own `TMPDIR/humanexport.*` directory before delegating the original cleanup; it does not alter bytes or exit verdicts. No cache/preexisting master output was substituted.

`glb-byte-analysis.json` records all8 committed/run1/run2 hashes and JSON/BIN comparisons. For every file:

-Run1 equals run2 exactly; committed differs. Each new file is4bytes larger.
-BIN chunks are exact, including vertex/index/normal/UV/skin/inverse-bind/morph/animation/image payloads. JSON meshes, materials, accessors, bufferViews, skins, animations, textures/images, provenance and every other block are exact.
-Only node21 `socket_hand_l` and node41 `socket_hand_r` rotations differ. Each has4 changed raw scalar values; neither node is a skin joint. Remaining joint/hierarchy/mesh data are exact.
-The old and new raw quaternion values are retained. The maximum component difference of the corresponding unnormalized-quaternion rotation matrices is1.685873937e-7; this is a semantic size description, not byte equivalence or a license to ignore the difference. No regenerated skin/body/morph/animation/image bytes changed.

CommittedLOD0 is238,764B; newLOD0 is238,768B. Both identify `Khronos glTF Blender I/O v4.5.48`. Web assets identify glTF-Transform4.5.0. CI's rounded size reports are consistent with the local rebuilt sizes, but its temporary generated outputs were not uploaded, so exact CI-output/local equality is not claimed.

## Environment and limits

The actual shared Blender archive SHA256 equals the committed pin `975c58fcb244273838534bba771e64ad87739216b0f9b39a888531a49a72d845`; executable reports4.5.3LTS, official build67807e1800cc. All4 resolved glTF-Transform packages are exactly4.5.0, using the authorized shared npm cache. `environment.json` retains versions/package hashes. Local Node24.19/npm11.9 differs from CI22.23.3/npm10.9.9; that difference is disclosed. The master quaternion difference already exists before Node derivatives, and all web BIN bytes remain exact.

Fixture GLBs last changed in60f7482 (#644,T1787). Builder and Blender pin are unchanged from that point; exporter gained only separately opted-in rigid-study handling, which this fixture's provenance does not enable. The machine contract's historical L1 prose/flag changed but skeleton/layout did not. The source-history diff is retained as context, not proof of the original generation environment or root cause. Two repetitions establish deterministic local mismatch under the current pinned path, not universal determinism across untested hosts.

## Evidence-based minimal remedy — not applied

Regenerate the8 `assets/humans[/web]/c4d_fixture.lod0..3.glb` files with the existing pinned source path, then require actual `--verify` to pass byte-for-byte. No production/exporter/validator/threshold/source-confidence change is supported by this diagnosis. Do not normalize hashes or suppress the reproduction gate.

Those8 refreshed files also require **genuine browser remeasurement**: `human_fixture.mjs --check` pins each measure row to its GLB SHA; normal browser mode checks structural byte counts too. Therefore the minimum coherent authored update is the8 GLBs plus their8 actually remeasured rows in `data/humans/fixture.measure.json`, preserving every unrelated human row. A small fixture-only shadow can run the unchanged native `human_fixture.mjs --write`; only freshly measured fixture rows should then be merged through explicit guards. Do not merely copy new hashes into old verdicts.

Actual native `human_fixture`/`human_actor` browser runs, resulting measure, full required checks and dedicated CI success remain owed before acceptance. This task stops before any canonical source/fixture/measure edit or PR/CI mutation. Original CI did not reach its later Playwright/browser steps; its host wasUbuntu26.04.1 and workflow remains `ubuntu-latest`, so this report supplies no later-step success verdict.

## State

**HEAVY CLEAR.** Both authorized Blender/meshopt runs finished; baseline agent was notified before its next browser. No further local heavy work is planned. No canonical Git refs/paths, assets, fixtures, assertions, measures, workflows or PRs were modified. The owned shadow retains committed originals; rebuilt outputs remain evidence only. ContractPASS has not been recast as reproductionPASS.
