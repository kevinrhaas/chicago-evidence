from pathlib import Path
import importlib.util,sys,json,dataclasses,hashlib,math
sys.dont_write_bytecode=True
A=Path('/workspace/chicago/chicago/4d');O=Path(__file__).resolve().parent

def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=load('miller_windows_old',A/'generators/archetypes/log_dwelling_params.py');new=load('miller_windows_new',O/'candidate/generators/archetypes/log_dwelling_params.py')
manifest=json.loads((A/'assets/manifest.json').read_text())['assets'];rows=[]
for filename,e in manifest.items():
 if e.get('archetype')!='log_dwelling':continue
 r=json.loads((A/'data/structures'/f"{e['structure_id']}.json").read_text());ph=next(x for x in r['phases']if x['id']==e['phase_id']);p=old.from_phase(ph,r);q=new.from_phase(ph,r)
 assert q.frame_addition_upper_windows is None
 assert old.addition_front_rects(p)==new.addition_front_rects(q),filename+' default addition openings changed'
 rows.append(filename)
r=json.loads((O/'candidate/data/structures/miller_house.json').read_text());p=new.from_phase(r['phases'][0],r);before=new.addition_front_rects(dataclasses.replace(p,frame_addition_upper_windows=None));after=new.addition_front_rects(p)
assert len(before)==5 and len(after)==6
assert after[:3]==before[:3], 'ground-floor window-door-window changed'
assert after[3]==before[3] and after[5]==before[4], 'existing outer upper windows moved or resized'
assert after[4][0]=='window';assert(after[4][1]+after[4][2])/2==p.width_m/2
assert after[4][3:]==before[3][3:], 'added light changed existing row band'
assert math.isclose(after[4][2]-after[4][1],after[3][2]-after[3][1],rel_tol=0,abs_tol=1e-12)
assert p.frame_addition_ridge_stack==(.4,.45,.45)and p.conf('frame_addition_ridge_stack')==1.0
assert p.conf('frame_addition_upper_windows')==.5
assert {'frame_addition_ridge_stack','frame_addition_upper_windows'}<=new.CONSUMED
for bad in [False,True,0,-1,4,2.5,'3']:
 try:dataclasses.replace(p,frame_addition_upper_windows=bad).validate()
 except new.ParamError:pass
 else:raise AssertionError(('invalid count',bad))
for change in [{'frame_addition':False},{'frame_addition_side':'end'},{'frame_addition_stories':1},{'frame_addition_width_m':2}]:
 try:dataclasses.replace(p,**change).validate()
 except new.ParamError:pass
 else:raise AssertionError(('incompatible row geometry',change))
base=json.loads((O/'BASE.json').read_text())['paths'];assert all(hashlib.sha256((A/rel).read_bytes()).hexdigest()==h for rel,h in base.items()),'Source changed during external proof'
result={'status':'PASS','scope':'Actual pure native parameter/opening-helper outputs; not GLB/mesh/photo/project qualification.','all82_default_addition_opening_sequences_exact':len(rows),'Miller_existing_three_ground_openings_exact':True,'Miller_outer_two_upper_openings_exact':True,'Miller_one_center_upper_light_added_in_same_band_and_section':True,'new_count_I_preserved_numeric_ridge_tuple_R':True,'both_consumed_form_fields_declared':True,'invalid_counts_rejected':7,'incompatible_geometry_rejected':4,'before':before,'after':after,'source_unchanged':True}
(O/'PURE-OPENING-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['before','after']},indent=2))
