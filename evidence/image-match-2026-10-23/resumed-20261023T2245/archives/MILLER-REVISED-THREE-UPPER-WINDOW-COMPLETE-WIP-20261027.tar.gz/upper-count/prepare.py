from pathlib import Path
import hashlib,json,difflib,datetime
A=Path('/workspace/chicago/chicago/4d');O=Path('/tmp/miller-upper-window-20261027');base={};patch=[]
def once(s,a,b):assert s.count(a)==1,(a[:55],s.count(a));return s.replace(a,b)
def params(s):
 s=once(s,'    "frame_addition_cladding",\n','    "frame_addition_cladding", "frame_addition_ridge_stack", "frame_addition_upper_windows",\n')
 s=once(s,'    frame_addition_ridge_stack: tuple | None = field(default=None, kw_only=True)\n','''    frame_addition_ridge_stack: tuple | None = field(default=None, kw_only=True)
    # A pictured upper front row on a two-storey front addition. None preserves
    # the existing pair; ground-floor windows/door and end additions never change.
    frame_addition_upper_windows: int | None = field(default=None, kw_only=True)
''')
 s=once(s,'        if self.frame_addition_ridge_stack is not None:\n','''        if self.frame_addition_upper_windows is not None:
            n = self.frame_addition_upper_windows
            if isinstance(n, bool) or not isinstance(n, int) or not 1 <= n <= 3:
                raise ParamError("frame_addition_upper_windows is a whole count in 1..3")
            if not self.frame_addition or self.frame_addition_side != "front" or self.frame_addition_stories != 2:
                raise ParamError("frame_addition_upper_windows needs a two-storey front addition")
            span = self.frame_addition_width_m
            if span * 0.22 < ADDITION_WIN_HALF_M or (n > 1 and span * 0.56 / (n - 1) <= 2 * ADDITION_WIN_HALF_M):
                raise ParamError("frame_addition_upper_windows overlaps its neighbour or wall edge")
        if self.frame_addition_ridge_stack is not None:
''')
 s=once(s,'        frame_addition_ridge_stack=(None if val("frame_addition_ridge_stack") is None\n                                    else tuple(val("frame_addition_ridge_stack"))),\n','''        frame_addition_ridge_stack=(None if val("frame_addition_ridge_stack") is None
                                    else tuple(val("frame_addition_ridge_stack"))),
        frame_addition_upper_windows=val("frame_addition_upper_windows"),
''')
 s=once(s,'        for fx in (0.22, 0.78):\n','''        fractions = (0.22, 0.78)
        if story > 0 and p.frame_addition_upper_windows is not None:
            n = p.frame_addition_upper_windows
            fractions = ((0.5,) if n == 1 else
                         tuple(0.22 + (0.78 - 0.22) * k / (n - 1) for k in range(n)))
        for fx in fractions:
''')
 return s
raw=(A/'generators/archetypes/log_dwelling_params.py').read_text();new=params(raw);p=O/'candidate/generators/archetypes/log_dwelling_params.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new);base['generators/archetypes/log_dwelling_params.py']=hashlib.sha256(raw.encode()).hexdigest();patch.extend(difflib.unified_diff(raw.splitlines(True),new.splitlines(True),fromfile='a/chicago/4d/generators/archetypes/log_dwelling_params.py',tofile='b/chicago/4d/generators/archetypes/log_dwelling_params.py'))
raw=(A/'data/structures/miller_house.json').read_text();r=json.loads(raw);f=r['phases'][0]['form'];a={'value':3,'confidence':'inferred','sources':['blanchard_shober_1867_wolf_point'],'note':'Three upper front windows are directly visible on Miller\'s tall block in the cleared 1867 Blanchard/Shober lithograph labelled Wolf\'s Point in 1833. This replaces the generic two-window row only on this two-storey front addition. The outer two upper windows retain their previous stations, section and band; one middle light is added. Lower window-door-window, gables, all low-core openings, massing and footprint remain unchanged. Count is inferred pictured form transferred cautiously into July 1835, not proof of an unchanged scene-date state. Existing 0.72 m width, 1.05 m height, row band and 0.22/0.50/0.78 fractions remain reconstructed window proxies rather than measured sash dimensions. The actual all-picture match still differs in composition, camera and other form/material details.'}
lines=json.dumps(a,indent=2,ensure_ascii=True).splitlines();member='        "frame_addition_upper_windows": '+lines[0]+'\n'+'\n'.join('        '+line for line in lines[1:])
needle='        "frame_addition_height_m": {';assert raw.count(needle)==1;new=raw.replace(needle,member+',\n'+needle);p=O/'candidate/data/structures/miller_house.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new);base['data/structures/miller_house.json']=hashlib.sha256(raw.encode()).hexdigest();patch.extend(difflib.unified_diff(raw.splitlines(True),new.splitlines(True),fromfile='a/chicago/4d/data/structures/miller_house.json',tofile='b/chicago/4d/data/structures/miller_house.json'))
(O/'UPPER-WINDOW.patch').write_text(''.join(patch));(O/'BASE.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_root':str(A),'paths':base,'extends':'chimney-only actual source/native checkpoint521','no_primary_mutation_yet':True},indent=2)+'\n');print('Prepared two-file upper-count delta externally; primary source unchanged.')
