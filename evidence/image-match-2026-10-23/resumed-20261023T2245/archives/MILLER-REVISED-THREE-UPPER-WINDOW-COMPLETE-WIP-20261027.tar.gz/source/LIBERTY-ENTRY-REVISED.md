### L-miller-frame-ridge-stack-2381 — the Miller range's roof flue and upper windows

**Covers:** `miller_house.log_frame_1827.form.frame_addition_ridge_stack`, `miller_house.log_frame_1827.form.frame_addition_upper_windows`.

**Decision:** Replace only the tall range's previous full-height exterior end stack with a short flue penetrating that range's own ridge. The numeric tuple is reconstructed: fraction 0.40 along the addition's x ridge, 0.45 m square shaft and 0.45 m head above ridge are first-fit choices, not measurements. The new stack renders R; the separate count/form inference and unchanged low log core's existing I stack retain their earlier inference. Chimney count, main and cabin massing, footprint, placement and roof dimensions remain unchanged. The pictured upper front count is now three rather than the generic pair: one middle upper light is added, while both outer upper lights and all lower windows/door retain their existing stations, bands and section. This count is inferred from the retrospective picture. The retained 0.72 m width, 1.05 m height and 0.22/0.50/0.78 stations are reconstructed proxies, not measured sash dimensions; existing opening-face confidence remains reconstructed.

**Source and limits:** `blanchard_shober_1867_wolf_point`, Rufus Blanchard/Chas. Shober & Co., Chicago, 1867, labelled Wolf's Point in 1833; existing cleared NYPL/Commons surrogate. The inspected sheet shows a short roof head over the tall log-and-board range and three upper front lights above window-door-window. Roof penetration is inferred pictured form; the retrospective depiction does not establish exact dimensions or unchanged appearance on 1 July 1835. Other held pictures do not independently establish absence of the low core's inferred stack. No source date, rights status or authentic material/pigment is newly asserted.

**Verification owed:** The chimney-only actual pilot/same-camera review and genuine 82-master/82-WEB production are preserved in checkpoint 521. The added middle upper light still requires its own revised pinned pilot, unchanged-camera review and complete 82-member native rebuild with 81 unchanged master/WEB control pairs; the older receipts do not certify the revised windows. All original picture/massing/opening/camera differences remain subject to the T-3153 stopping rule. This bounded correction is not an original-ticket matches or completion claim.

**Ticket:** T-2381.

**Recorded:** 2026-10-27.
