"""After actual native closure/publish, freeze the selected model and all app consumers."""
from pathlib import Path
import json,hashlib,subprocess,datetime,os
A=Path('/workspace/chicago/chicago/4d');R=A.parent.parent;O=Path(os.environ['MILLER_APP_HOME']);O.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((A/'data/structures/miller_house.json').read_text());ph=next(x for x in r['phases']if x['id']=='log_frame_1827');side=json.loads((A/'data/sidecars/1835/miller_house.json').read_text());d=json.loads((A/'data/enclosures/town_entrance_aprons.json').read_text());doors=[x for x in d['entrances']if x['structure_id']=='miller_house'];assert doors
keys=['stories','construction','frame_addition','frame_addition_stories','frame_addition_cladding','frame_addition_height_m','wall_height_m','chimneys','frame_addition_ridge_stack','frame_addition_upper_windows'];attrs={k:ph['form'][k]for k in keys};assert attrs['frame_addition_ridge_stack']['confidence']=='reconstructed'and attrs['frame_addition_upper_windows']['value']==3 and attrs['frame_addition_upper_windows']['confidence']=='inferred'
for k,v in attrs.items():assert side['attributes'][k]['value']==v['value']and side['attributes'][k]['confidence']==v['confidence'],k
web=A/'assets/web/miller_house__log_frame_1827.glb';published=R/'site/4d/data/gltf/miller_house__log_frame_1827.glb';assert sha(web)==sha(published)
expected={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_binding':{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'working_snapshot_uncommitted':True,'record_sha256':sha(A/'data/structures/miller_house.json'),'master_sha256':sha(A/'assets/gltf/miller_house__log_frame_1827.glb'),'WEB_sha256':sha(web),'native_sidecar_sha256':sha(A/'data/sidecars/1835/miller_house.json')},'grade':side['grade'],'attributes':attrs,'placement':side['placement'],'entrances':doors,'WEB_sha256':sha(web)}
(O/'APP-EXPECTED.json').write_text(json.dumps(expected,indent=2)+'\n')
# Protect the actual entire generated site payload: per-file byte binding, no claim
# that an old app run covered a changed graph. This is metadata only, not a copy.
paths=[]
for f in sorted((R/'site/4d').rglob('*')):
 if f.is_file():paths.append({'path':str(f),'sha256':sha(f),'bytes':f.stat().st_size})
(O/'SOURCE-BINDINGS.json').write_text(json.dumps({'at':expected['at'],'paths':paths,'scope':'Current published mirror payload hashes; no source/runtime modification or performance acceptance.'},indent=2)+'\n')
print(json.dumps({'frozen_site_members':len(paths),'selected_native_WEB':expected['WEB_sha256'],'app_review_not_run':True}))
