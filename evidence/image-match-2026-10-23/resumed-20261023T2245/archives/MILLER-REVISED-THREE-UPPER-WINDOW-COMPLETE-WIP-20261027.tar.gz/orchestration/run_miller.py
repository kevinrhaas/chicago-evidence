"""Guarded native stages; invoke ONLY after explicit Wolf source handoff/CPU coordination.

No worktree/fetch/GC/repack. Each stage preserves its raw native log and reaper.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys,time
P=Path(__file__).resolve().parent; R=Path('/workspace/chicago'); A=R/'chicago/4d'; Q=Path('/tmp/miller-next-20261027'); BLENDER=Path('/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender'); M='miller_house__log_frame_1827.glb'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def environment():
 e=dict(os.environ)
 for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR']:e.pop(k,None)
 for k,v in [('gc.auto','0'),('maintenance.auto','false'),('remote.origin.tagOpt','--no-tags')]:
  n=int(e.get('GIT_CONFIG_COUNT','0'));e[f'GIT_CONFIG_KEY_{n}']=k;e[f'GIT_CONFIG_VALUE_{n}']=v;e['GIT_CONFIG_COUNT']=str(n+1)
 e.update(PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PW_EXECUTABLE='/usr/bin/chromium')
 return e
E=environment()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,env=E).decode().strip()
def run(out,name,args,cpu):
 assert not (out/(name+'.log')).exists(),name+' already ran: preserve prior attempt, use a consciously new execution directory'
 assert cpu in os.sched_getaffinity(0),cpu
 cmd=['python3','/workspace/shared/run-with-reaping.py',str(out/(name+'-reaper.json')),'--','taskset','-c',str(cpu),*args]
 t=time.monotonic()
 with (out/(name+'.log')).open('x') as log:p=subprocess.run(cmd,cwd=A,env=dict(E,PWD=str(A)),stdout=log,stderr=subprocess.STDOUT)
 reaper=json.loads((out/(name+'-reaper.json')).read_text());row={'at':now(),'command':cmd,'exit':p.returncode,'seconds':round(time.monotonic()-t,3),'all_children_reaped':reaper.get('all_children_reaped')};save(out/(name+'-result.json'),row);print(json.dumps(row),flush=True)
 assert p.returncode==0 and reaper.get('command_exit')==0 and reaper.get('all_children_reaped'),row

def snapshot(out,expected):
 assert expected and git('rev-parse','HEAD')==expected,'Need the exact handed-off source HEAD'
 assert not git('status','--porcelain=v1'),'Handoff must be clean; checkpoint/coordinate existing work, never reset it'
 assert not (R/'.git/MERGE_HEAD').exists(),'No inherited unresolved merge'
 assert not out.exists(),'Snapshot/execution directory already exists; do not overwrite'
 out.mkdir(parents=True)
 inv=json.loads((A/'assets/manifest.json').read_text())['assets'];family={k:v for k,v in inv.items() if v.get('archetype')=='log_dwelling'};assert len(family)==82
 assert len({v['structure_id']for v in family.values()})==82
 versions=json.loads((A/'assets/manifest.versions.json').read_text()).get('assets',{});assert not [k for k,v in versions.items()if v.get('archetype')=='log_dwelling'],'New log versions require an inspected expanded rebuild scope'
 paths=['chicago/4d/'+x for x in ['generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py','data/structures/miller_house.json','docs/LIBERTIES.md','assets/manifest.json','assets/manifest.web.json','assets/manifest.versions.json']]
 paths += ['chicago/4d/assets/'+kind+'/'+k for k in family for kind in ['gltf','web']]
 inventory=json.loads(Path('/tmp/Wolf1336-currentMary-ending-20261027T0045/ALL44-INCOMING-METADATA.json').read_text());assert len(inventory)==44
 paths+= [x['path']for x in inventory];rows={}
 for rel in sorted(set(paths)):
  src=R/rel;dest=out/'before'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);rows[rel]={'bytes':src.stat().st_size,'sha256':sha(src)};assert sha(dest)==rows[rel]['sha256']
 basephoto=Path('/workspace/T3081-PR1260-five-photo-comparisons/picture-inputs/cameras/portable/miller_house.match.json');oldmatch=json.loads(basephoto.read_text());assert sha(A/'assets/gltf'/M)==oldmatch['glb_sha256']
 oldcam=basephoto.with_name('miller_house.json');assert sha(oldcam)==oldmatch['camera_sha256'];photo=R/'chicago/reference/images/chicago/chicago_wolf_point_1833_nypl.jpg';assert sha(photo)==oldmatch['photo_sha256']
 cam=out/'pilot/cameras/portable/miller_house.json';cam.parent.mkdir(parents=True);shutil.copyfile(oldcam,cam);img=out/'pilot/sources/chicago_wolf_point_1833_nypl.jpg';img.parent.mkdir(parents=True);shutil.copyfile(photo,img);assert sha((cam.parent/json.loads(cam.read_text())['photo']).resolve())==oldmatch['photo_sha256']
 oldside=Path('/workspace/T3081-PR1260-five-photo-comparisons/pictures/miller_house/miller_house-side-by-side.jpg');shutil.copyfile(oldside,out/'pilot/before-side-by-side.jpg');shutil.copyfile(basephoto,out/'pilot/before-native.match.json')
 save(out/'BASELINE.json',{'at':now(),'head':expected,'dev_tip':git('rev-parse','refs/remotes/origin/dev'),'branch':git('branch','--show-current'),'clean_source_handoff_received':True,'paths':rows,'family':family,'all44_paths':[x['path']for x in inventory],'master_web_before_bytes':sum(x['bytes']for k,x in rows.items()if '/assets/gltf/'in k or '/assets/web/'in k),'native_before_binding':oldmatch,'camera_sha256':sha(cam),'photo_sha256':sha(img),'before_side_by_side_sha256':sha(oldside),'actual_whole_picture_acceptance':False})
 print('Snapshot complete: only external copies; source unchanged',flush=True)

def adopt(out):
 b=json.loads((out/'BASELINE.json').read_text());assert git('rev-parse','HEAD')==b['head'] and not git('status','--porcelain=v1')
 base=json.loads((Q/'BASE-INPUTS.json').read_text())['paths']
 for rel,entry in base.items():assert sha(A/rel)==entry['sha256'],rel+' changed since reviewed proposal'
 run(out,'normal-original-claim',['node','tools/ticket.mjs','claim','T-2381','--by','Codex Miller picture correction'],0)
 assert git('rev-parse','refs/remotes/origin/dev')==b['dev_tip'],'Cached actual dev moved since source snapshot; consciously rebind before adopting'
 subprocess.run(['git','merge-base','--is-ancestor',b['head'],b['dev_tip']],cwd=R,env=E,check=True)
 branch='steward/t2381-miller-frame-ridge-stack-20261027';subprocess.run(['git','switch','-c',branch,b['dev_tip']],cwd=R,env=E,check=True)
 for rel,entry in base.items():assert sha(A/rel)==entry['sha256'],rel+' differs on actual dev base'
 for rel,entry in b['paths'].items():
  if '/assets/gltf/'in rel or '/assets/web/'in rel:assert sha(R/rel)==entry['sha256'],rel+' changed between checked handoff and actual dev base'
 subprocess.run(['git','apply','--check',str(Q/'PROPOSED.patch')],cwd=R,env=E,check=True);subprocess.run(['git','apply',str(Q/'PROPOSED.patch')],cwd=R,env=E,check=True)
 doc=A/'docs/LIBERTIES.md';raw=doc.read_bytes();entry=(P/'LIBERTY-ENTRY.md').read_bytes();assert b'L-miller-frame-ridge-stack-2381'not in raw;doc.write_bytes(raw.rstrip(b'\n')+b'\n\n'+entry)
 actual=json.loads((A/'data/structures/miller_house.json').read_text())['phases'][0]['form']['frame_addition_ridge_stack'];assert actual['confidence']=='reconstructed' and actual['value']==[.4,.45,.45]
 entryfile=A/'changelog.d/T-2381.json';assert not entryfile.exists(),'Existing original entry needs owner-aware reconciliation';save(entryfile,{'title':"The Miller House's roof chimney",'kind':'feature','items':["The main range now has a short chimney rising through its ridge, following the old drawing. Its low log cabin keeps its existing chimney."]})
 save(out/'ADOPTED.json',{'at':now(),'head':b['head'],'branch':branch,'tuple':actual,'source_paths':['chicago/4d/'+x for x in base]+['chicago/4d/docs/LIBERTIES.md','chicago/4d/changelog.d/T-2381.json'],'source_patch_sha256':sha(Q/'PROPOSED.patch'),'liberty_entry_sha256':sha(P/'LIBERTY-ENTRY.md'),'original_ticket_not_done':True})

def pilot(out,cpu,attempt):
 assert (out/'ADOPTED.json').exists();assert shutil.disk_usage('/tmp').free>=512*1024**2
 original=json.loads((out/'BASELINE.json').read_text());starting={rel:sha(R/rel)for rel in original['paths']if '/assets/gltf/'in rel or '/assets/web/'in rel};save(out/'PILOT-STARTING-FAMILY.json',{'at':now(),'sha256':starting})
 run(out,'selected-Miller-native-build-'+attempt,[str(BLENDER),'-b','-noaudio','--factory-startup','--threads','1','--python-exit-code','1','--python',str(A/'generators/build.py'),'--','--only','miller_house','--wrote',str(out/'pilot-wrote.txt')],cpu)
 wrote=(out/'pilot-wrote.txt').read_text().splitlines();assert wrote==[M],wrote
 b=json.loads((out/'BASELINE.json').read_text());bad=[rel for rel,h in starting.items()if rel!='chicago/4d/assets/gltf/'+M and sha(R/rel)!=h];assert not bad,bad
 assert sha(A/'assets/gltf'/M)!=b['native_before_binding']['glb_sha256'],'Pilot did not change selected master'
 save(out/'PILOT-BUILD.json',{'at':now(),'master_sha256':sha(A/'assets/gltf'/M),'unchanged_other_163_model_files':True,'photo_review_pending':True,'other81_recipes_stale_until_full_native_family_bake':True})

def photo(out,cpu):
 b=json.loads((out/'BASELINE.json').read_text());p=json.loads((out/'PILOT-BUILD.json').read_text());assert sha(A/'assets/gltf'/M)==p['master_sha256'];cam=out/'pilot/cameras/portable/miller_house.json';assert sha(cam)==b['camera_sha256']and not cam.with_suffix('.match.json').exists()
 run(out,'selected-Miller-native-photo',['node','tools/photo_match.mjs',str(cam),'--glb','assets/gltf/'+M,'--out',str(out/'pilot/after')],cpu)
 m=json.loads(cam.with_suffix('.match.json').read_text());assert m['glb_sha256']==p['master_sha256']and m['camera_sha256']==b['camera_sha256']and m['photo_sha256']==b['photo_sha256'];assert m['verdict']=='unreviewed'
 save(out/'PILOT-PHOTO.json',{'at':now(),'native_match':m,'same_camera_and_photo_as_actual_before':True,'actual_visual_review_pending':True})

def family(out,cpu,mode):
 review=json.loads((out/'PILOT-REVIEW.json').read_text());assert review.get('ready_for_family_bake')is True,'First directly inspect fresh actual source/render and write honest pilot readiness'
 b=json.loads((out/'BASELINE.json').read_text());selected=','.join(sorted({v['structure_id']for v in b['family'].values()}));assert len(selected.split(','))==82
 if mode not in {'web','web-moved'}:
  run(out,'full82-native-build',[str(BLENDER),'-b','-noaudio','--factory-startup','--threads','1','--python-exit-code','1','--python',str(A/'generators/build.py'),'--','--only',selected,'--wrote',str(out/'family-wrote.txt')],cpu)
  wrote=(out/'family-wrote.txt').read_text().splitlines();assert len(wrote)==82 and set(wrote)==set(b['family'])
  sys.path.insert(0,str(A/'generators'));import mesh_inputs
  current=json.loads((A/'assets/manifest.json').read_text())['assets'];masters={}
  for name,entry in b['family'].items():
   st=json.loads((A/'data/structures'/f"{entry['structure_id']}.json").read_text());ph=next(x for x in st['phases']if x['id']==entry['phase_id']);assert current[name]['inputs_sha256']==mesh_inputs.structure_inputs_sha(st,ph,'log_dwelling'),name
   rel='chicago/4d/assets/gltf/'+name;h=sha(R/rel);assert name==M or h==b['paths'][rel]['sha256'],name+' master control changed';masters[name]=h
  assert masters[M]==json.loads((out/'PILOT-BUILD.json').read_text())['master_sha256'],'Full family changed selected pilot bytes: recapture before any picture reuse'
  save(out/'FULL82-MASTERS-PROOF.json',{'at':now(),'status':'PASS','actual82_masters_built':True,'all82_recipes_fresh':True,'all81_other_master_bytes_exact':True,'selected_master_exact_actual_pilot':True,'masters':masters,'WEB_generation_still_owed':True})
  if mode=='masters':return
 else:
  proof=json.loads((out/'FULL82-MASTERS-PROOF.json').read_text());assert proof['status']=='PASS'
  for name,h in proof['masters'].items():assert sha(A/'assets/gltf'/name)==h,name+' changed before WEB production'
  wrote=(out/'family-wrote.txt').read_text().splitlines();assert len(wrote)==82 and set(wrote)==set(b['family'])
 if mode=='web-moved':
  prior=json.loads(Path('/tmp/miller-execution-20261027T0205/FULL82-NATIVE-PROOF.json').read_text());assert prior['status']=='PASS'
  subprocess.run(['git','diff','--quiet','HEAD','--','chicago/4d/tools/web_derivatives.sh'],cwd=R,env=E,check=True)
  prior_rows={(row['name'],row['kind']):row for row in prior['rows']}
  for name in b['family']:
   if name==M:continue
   assert sha(A/'assets/gltf'/name)==prior_rows[(name,'gltf')]['sha256'],name+' actual prior master differs'
   assert sha(A/'assets/web'/name)==prior_rows[(name,'web')]['sha256'],name+' actual prior WEB differs'
  run(out,'selected-Miller-native-WEB',['bash','tools/web_derivatives.sh','--only',M],cpu)
 else:
  run(out,'full82-native-WEB',['bash','tools/web_derivatives.sh','--only',','.join(wrote)],cpu)
 sys.path.insert(0,str(A/'generators'));import mesh_inputs
 manifest=json.loads((A/'assets/manifest.json').read_text())['assets'];web=json.loads((A/'assets/manifest.web.json').read_text())['masters'];rows=[]
 for name,entry in b['family'].items():
  st=json.loads((A/'data/structures'/f"{entry['structure_id']}.json").read_text());ph=next(x for x in st['phases']if x['id']==entry['phase_id']);expected=mesh_inputs.structure_inputs_sha(st,ph,'log_dwelling');assert manifest[name]['inputs_sha256']==expected,name
  assert web[name]==sha(A/'assets/gltf'/name),name+' WEB native master binding stale'
  for kind in ['gltf','web']:
   rel='chicago/4d/assets/'+kind+'/'+name;unchanged=sha(R/rel)==b['paths'][rel]['sha256'];assert unchanged or name==M,(name,kind,'unselected control changed')
   rows.append({'name':name,'kind':kind,'sha256':sha(R/rel),'before_exact':unchanged,'recipe_fresh':True})
 save(out/'FULL82-NATIVE-PROOF.json',{'at':now(),'status':'PASS','actual82_masters_current':True,'native_WEB_scope':'ONLY_CHANGED_MILLER_REBUILT_PRIOR_ACTUAL_81_REPRODUCTIONS_REUSED_ON_EXACT_MASTER_PIPELINE_AND_DERIVATIVE_BYTES'if mode=='web-moved'else'ALL82_CURRENT_ACTUALLY_REPRODUCED','prior_81_actual_WEB_proof_index':521 if mode=='web-moved'else None,'all82_native_recipe_andWEB_bindings_fresh':True,'all81_unselected_master_andWEB_pairs_byte_exact':True,'rows':rows,'selected_Miller_original_acceptance':'OPEN; native closure/all44/app/finalfull3/PR still owed'})

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('stage',choices=['snapshot','adopt','pilot','photo','family','family-masters','family-web','family-web-moved']);ap.add_argument('--execution',required=True,type=Path);ap.add_argument('--handed-off-head');ap.add_argument('--cpu',type=int,default=3);ap.add_argument('--attempt',default='initial');args=ap.parse_args()
 assert os.environ.get('MILLER_SOURCE_OWNER')=='explicit-Wolf-handoff','Source must remain read-only until Wolf explicitly hands it over'
 assert str(args.execution).startswith('/tmp/miller-'),'Keep execution evidence external and bounded'
 if args.stage=='snapshot':snapshot(args.execution,args.handed_off_head)
 elif args.stage=='adopt':adopt(args.execution)
 elif args.stage=='pilot':pilot(args.execution,args.cpu,args.attempt)
 elif args.stage=='photo':photo(args.execution,args.cpu)
 else:family(args.execution,args.cpu,'masters'if args.stage=='family-masters'else'web'if args.stage=='family-web'else'web-moved'if args.stage=='family-web-moved'else'both')
if __name__=='__main__':main()
