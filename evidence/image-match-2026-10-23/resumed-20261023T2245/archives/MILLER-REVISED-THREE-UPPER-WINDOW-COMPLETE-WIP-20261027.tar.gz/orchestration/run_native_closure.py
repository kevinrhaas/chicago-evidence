"""One coordinated copy-heavy native closure; never run alongside another scratch-copy job."""
from pathlib import Path
import argparse,datetime,gzip,hashlib,io,json,os,shutil,sys,xml.etree.ElementTree as ET,zipfile
sys.path.insert(0,str(Path(__file__).resolve().parent));import run_miller as task
P=Path(__file__).resolve().parent;R=task.R;A=task.A;sha=task.sha

def xml(raw,name):
 root=ET.fromstring(raw)
 if name=='docProps/core.xml':
  for child in list(root):
   if child.tag=='{http://purl.org/dc/terms/}modified':root.remove(child)
 return ET.canonicalize(ET.tostring(root,encoding='unicode'),rewrite_prefixes=True)
def workbook(raw):
 with zipfile.ZipFile(io.BytesIO(raw))as z:
  names=z.namelist();assert len(names)==len(set(names)),'Duplicate ZIP members'
  return {name:xml(z.read(name),name)if name.endswith(('.xml','.rels'))else z.read(name)for name in names}
def no_dupes(pairs):
 result={}
 for k,v in pairs:
  assert k not in result,'Duplicate JSON key'
  result[k]=v
 return result
def json_canon(raw):return json.dumps(json.loads(raw,object_pairs_hook=no_dupes),sort_keys=True,separators=(',',':'),ensure_ascii=True)
def audit(out,phase):
 b=json.loads((out/'BASELINE.json').read_text());rows=[]
 for path in b['all44_paths']:
  f=R/path;before=(out/'before'/path).read_bytes();actual=f.read_bytes();same=actual==before;method='EXACT_BYTES';equal=same
  if not same:
   raw=out/('raw-native-binaries-'+phase)/path;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_bytes(actual)
   if path.endswith('.gz'):
    x,y=gzip.decompress(actual),gzip.decompress(before);equal=x==y;method='GZIP_DECOMPRESSED_EXACT_BYTES'
    if not equal:
     try:equal=json_canon(x)==json_canon(y);method='DUPLICATE_FREE_JSON_CANONICAL_VALUES_ALL_FIELDS_ARRAY_ORDER_TYPES_PRESERVED'
     except (ValueError,UnicodeError,AssertionError):pass
   elif path.endswith('.xlsx'):equal=workbook(actual)==workbook(before);method='EVERY_ZIP_MEMBER_EXACT_OR_CANONICAL_XML_EXCEPT_CORE_MODIFIED_ONLY'
   if equal:f.write_bytes(before)
  rows.append({'path':path,'before_sha256':hashlib.sha256(before).hexdigest(),'native_generated_sha256':hashlib.sha256(actual).hexdigest(),'before_exact':same,'comparison':method,'equal':equal,'restored_serialization_only':not same and equal})
 task.save(out/('ALL44-'+phase+'.json'),{'at':task.now(),'rows':rows,'all44_compared':len(rows)==44,'all_equal':all(x['equal']for x in rows),'scope':'An actual content difference remains preserved and fails; exact legacy invalid ZIPs are not parsed.'});assert len(rows)==44 and all(x['equal']for x in rows),'Unexpected real native binary content; diagnose retained raw bytes, do not discard'

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execution',required=True,type=Path);ap.add_argument('--cpu',type=int,default=3);args=ap.parse_args();out=args.execution
 assert os.environ.get('MILLER_SOURCE_OWNER')=='explicit-Wolf-handoff'
 assert os.environ.get('MILLER_COPY_LEASE')=='sole-coordinated-native-copy','Wait for sole copy-heavy lease; caller floor is priced1.8GB'
 assert json.loads((out/'FULL82-NATIVE-PROOF.json').read_text())['status']=='PASS'
 assert shutil.disk_usage('/tmp').free>=1800000000,'Current native copy needs1.534GB plus other consumers; do not lower the guard'
 b=json.loads((out/'BASELINE.json').read_text())
 expected={rel:sha(R/rel)for rel in b['paths']if '/assets/gltf/'in rel or '/assets/web/'in rel or rel.endswith(('generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py','data/structures/miller_house.json','docs/LIBERTIES.md'))}
 task.save(out/'BEFORE-NATIVE-CLOSURE.json',{'at':task.now(),'protected':expected,'tmp_free':shutil.disk_usage('/tmp').free,'sole_copy_heavy_lease':True,'old_native_guard_unchanged':True})
 def guarded():
  bad=[rel for rel,h in expected.items()if sha(R/rel)!=h];assert not bad,bad
 task.run(out,'native-liberties-through-owning-tail',['node','tools/rederive.mjs','--tail','tools/compile_liberties.py'],args.cpu);guarded();audit(out,'after-owning-tail')
 task.run(out,'native-package5-after-serialization-audit',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'],args.cpu);audit(out,'after-package5');guarded()
 task.run(out,'native-published-mirror',['bash','tools/publish.sh'],args.cpu);guarded()
 changed=task.git('diff','--name-only').splitlines();known=set(b['all44_paths']);unexpected=[p for p in changed if(p.endswith(('.xlsx','.gz'))or not p.startswith('chicago/4d/'))and p not in known];assert not unexpected,unexpected
 task.save(out/'NATIVE-CLOSURE-RESULT.json',{'at':task.now(),'status':'PASS','owning_tail_from_compile_liberties':True,'all44_twice_audited':True,'package5_and_publish_pass':True,'protected_inputs_and164_models_exact':True,'current_full3_and_actual_app_review_still_owed':True,'original_T2381_open':True})
if __name__=='__main__':main()
