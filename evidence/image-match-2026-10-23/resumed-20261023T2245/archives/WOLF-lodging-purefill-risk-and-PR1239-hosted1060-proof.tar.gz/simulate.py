from pathlib import Path
from collections import Counter
import sys,os,json,copy,types,subprocess,importlib.util,hashlib,datetime
sys.dont_write_bytecode=True
OUT=Path('/tmp/T3081-Wolf-lodging-readonly-risk'); APP=Path('/tmp/chicago-log-integration/chicago/4d'); REPO=APP.parents[1]; PR='a2192528415d04f3b83424447a0b08a766d73825'
sys.path.insert(0,str(APP/'tools'))
# Every simulation path is read-only except this newly-owned output folder.
write_events=[]
def guard(event,args):
 if event=='open':
  path,mode,flags=args
  writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_APPEND|os.O_CREAT|os.O_TRUNC)))
  if writing and isinstance(path,(str,bytes,os.PathLike)):
   path=Path(os.fsdecode(path)).resolve();write_events.append(str(path))
   if not path.is_relative_to(OUT):raise RuntimeError('WRITE DENIED outside own review: '+str(path))
 elif event in ['os.remove','os.rename','os.rmdir','os.mkdir']:
  path=Path(os.fsdecode(args[0])).resolve()
  if not path.is_relative_to(OUT):raise RuntimeError('MUTATION DENIED '+event+' '+str(path))
sys.addaudithook(guard)
def git(ref,path):return subprocess.check_output(['git','-C',str(REPO),'show',ref+':chicago/4d/'+path])
def module(name,source,path):
 m=types.ModuleType(name);m.__file__=str(path);sys.modules[name]=m;exec(compile(source,str(path),'exec'),m.__dict__);return m
oldseat=module('oldseat',(APP/'tools/seat_lodgers_1835.py').read_bytes(),APP/'tools/seat_lodgers_1835.py')
v2seat=module('v2seat',git(PR,'tools/seat_lodgers_1835.py'),APP/'tools/seat_lodgers_1835.py')
build=module('lodgingbuild',(APP/'tools/build_lodging_model_1835.py').read_bytes(),APP/'tools/build_lodging_model_1835.py')
newdata=build.load(APP);olddata=copy.deepcopy(newdata)
changed=['wolf_point_tavern','miller_house','chappel_infant_school','cobweb_castle','philo_carpenter_log_shop']
oldrecords={sid:json.loads(git('HEAD','data/structures/'+sid+'.json')) for sid in changed}
olddata['structures']=[copy.deepcopy(oldrecords.get(r['id'],r)) for r in olddata['structures']]
prdata=copy.deepcopy(olddata)
prpaths=subprocess.check_output(['git','-C',str(REPO),'diff','--name-only','HEAD',PR,'--','chicago/4d/data/structures'],text=True).splitlines()
prrecords={Path(p).stem:json.loads(git(PR,'data/structures/'+Path(p).name)) for p in prpaths}
prdata['structures']=[copy.deepcopy(prrecords.get(r['id'],r)) for r in prdata['structures']]
for key,path in [('model','data/reconstruction/1835_town_model.json'),('inventory','data/reconstruction/1835_building_inventory.json'),('composition','data/research/census_1840/composition_1840.json')]:prdata[key]=json.loads(git(PR,path))
prnewdata=copy.deepcopy(prdata)
newrecords={r['id']:r for r in newdata['structures'] if r['id'] in changed}
prnewdata['structures']=[copy.deepcopy(newrecords.get(r['id'],r)) for r in prnewdata['structures']]
models={name:build.build(data) for name,data in [('dev_old',olddata),('dev_new',newdata),('pr_old',prdata),('pr_new',prnewdata)]}
tracked=[APP/'data/reconstruction/1835_lodgers_seated.json',APP/'data/reconstruction/1835_reconstruction_order_book.json']+sorted((APP/'data/residents/lodgers').glob('*.json'))
beforehash={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in tracked}
results={}
def run(name,mod,model,prior=None):
 savedmodel=mod.lodging_model;savedload=mod.load
 mod.lodging_model=lambda:copy.deepcopy(model)
 if prior is not None:mod.load=lambda path:copy.deepcopy(prior) if Path(path)==mod.LEDGER else savedload(path)
 try:
  cards,ledger=mod.fill();mod.refuse(cards,ledger)
  results[name]={'cards':cards,'ledger':ledger,'measurement':mod.measurement(cards,ledger),'refuse':'PASS'}
 finally:mod.lodging_model=savedmodel;mod.load=savedload
 print(name,'cards',len(cards),'persons',sum(len(c['persons']) for c in cards.values()),'seats',len(ledger['seats']),flush=True)
 return ledger
devold=run('old_policy_dev_old',oldseat,models['dev_old'])
devnew=run('old_policy_dev_new',oldseat,models['dev_new'])
v2old=run('V2_policy_dev_old',v2seat,models['dev_old'])
v2new=run('V2_policy_dev_new',v2seat,models['dev_new'],v2old)
prprior=json.loads(git(PR,'data/reconstruction/1835_lodgers_seated.json'))
prold=run('V2_policy_PR_old',v2seat,models['pr_old'],prprior)
prnew=run('V2_policy_PR_new',v2seat,models['pr_new'],prold)
for name,data in models.items():(OUT/(name+'-model.json')).write_text(json.dumps(data,indent=2)+'\n')
for name,data in results.items():(OUT/(name+'-result.json')).write_text(json.dumps(data,indent=2)+'\n')
def identity(cards):
 return {p['id']:{'household':hid,'name':p.get('name'),'place':card['lodging_household']['place'],'head':card['head'],'division':card['division'],'person':{k:p.get(k) for k in ['id','name','relationship','sex','age_band','seed','employment']}} for hid,card in cards.items() for p in card['persons']}
def delta(a,b):
 before,after=results[a],results[b];aid,bid=identity(before['cards']),identity(after['cards']);aseat={s['person']:s for s in before['ledger']['seats']};bseat={s['person']:s for s in after['ledger']['seats']}
 return {'before':a,'after':b,'retired_person_ids':sorted(set(aid)-set(bid)),'new_person_ids':sorted(set(bid)-set(aid)),'changed_existing_person_ids':{pid:{'before':aid[pid],'after':bid[pid]} for pid in set(aid)&set(bid) if aid[pid]!=bid[pid]},'retired_household_ids':sorted(set(before['cards'])-set(after['cards'])),'new_household_ids':sorted(set(after['cards'])-set(before['cards'])),'retired_seat_ids':sorted(set(aseat)-set(bseat)),'new_seat_ids':sorted(set(bseat)-set(aseat)),'changed_seats':{pid:{'before':aseat[pid],'after':bseat[pid]} for pid in set(aseat)&set(bseat) if aseat[pid]!=bseat[pid]},'quota_basis_equal':before['ledger']['quota_basis']==after['ledger']['quota_basis'],'fill_counters_equal':all(before['ledger'].get(k)==after['ledger'].get(k) for k in ['fills','child_fills','top_up_fills','youth_top_up_fills','working_fills','household_fills']),'before_measurement':before['measurement'],'after_measurement':after['measurement']}
deltas=[delta('old_policy_dev_old','old_policy_dev_new'),delta('V2_policy_dev_old','V2_policy_dev_new'),delta('V2_policy_PR_old','V2_policy_PR_new')]
capacity=[]
for a,b in [('dev_old','dev_new'),('pr_old','pr_new')]:
 old={p['id']:p for p in models[a]['places']};new={p['id']:p for p in models[b]['places']}
 capacity.append({'before':a,'after':b,'rows':[{'id':sid,'old_floor_m2':old[sid]['enclosed_floor_m2'],'new_floor_m2':new[sid]['enclosed_floor_m2'],'old_ordinary':old[sid]['beds_ordinary'],'new_ordinary':new[sid]['beds_ordinary'],'old_crowded':old[sid]['beds_crowded'],'new_crowded':new[sid]['beds_crowded']} for sid in old if old[sid]!=new[sid]]})
afterhash={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in tracked};assert beforehash==afterhash
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':'Actual native pure build/fill/refuse/measurement functions only; writers never called; process audit hook denies writes outside review directory','root_integration_HEAD':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(),'V2_source_ref':PR,'capacity':capacity,'deltas':deltas,'canonical_file_double_read_hashes_unchanged':beforehash,'writes_under_own_directory_only':write_events}
(OUT/'REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
for c in capacity:print('CAPACITY',json.dumps(c),flush=True)
for d in deltas:print('DELTA',d['before'],d['after'],'retired',len(d['retired_person_ids']),'new',len(d['new_person_ids']),'changed',len(d['changed_existing_person_ids']),'seat changes',len(d['changed_seats']),flush=True)
