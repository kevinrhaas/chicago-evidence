# T-2385: closed native two-output delta and canonical comparison

This is a CLOSED snapshot, not a live folder. It depends on the durable authored
checkpoint 003, public Green Tree commit cf25a3f2bb653648d25502fe5fab914b8cb29453,
and incoming dev 88c983a2fc8ba107ca36d9346dcbc5c99b488bdf.

The own worktree fast-forwarded normally to public cf25, then merged dev 88 with
--no-commit. It retains MERGE_HEAD 88 and private author stash
4c6b9497539bd490be995c0a864fb02421442fac. There is NO code commit, final gate,
PR or merge claim. Do not copy unrelated manifest rows over a newer base: the full
native books here document exact output metadata from that normal merged state.
The owned-source patch is relative to public cf25 for the selected owned paths;
it therefore also carries incoming 88's legitimate changes to those shared files.
Use ordinary three-way integration rather than blindly applying it to a newer tree.
Full current Tremont records, source, changelog and test file are supplied separately.

## Evidence and visible interpretation

The default adopts Gale's retrospective 1835-framed description on printed p51
(context p25/p43): inferred 30 x 20 ft natural axes, two storeys and yellow paint.
Working wall height is 5.45 m. Both existing street-facing planes remain fixed;
the northeast origin and explicit roof-staff flag anchor follow the smaller geometry.
Canonical shutters are explicitly FALSE/RECONSTRUCTED, a simplifying choice under
the unchanged native stock clearance, not an attested historical absence.
Native gifford-reading preserves the earlier three-storey picture-led model, its
reconstructed larger scale/colour and all pictured shutters. No enlargement date,
original Gifford publication or public-domain finding is invented.

## Closed native work

One Blender 4.5.3 process, pinned to hard CPU 2 with one worker, wrote EXACTLY two
selected master paths. The unchanged native pinned WEB 4.5.0 pipeline wrote EXACTLY
their two derivatives. Actual native wrote list, logs, reaper reports and freshness
hashes are included. Only two master and two WEB files are packaged.

Default: 276104 B / 3400 triangles; WEB 46072 B.
Gifford reading: 445040 B / 5552 triangles; WEB 66692 B.
Both alternative outputs are BYTE EXACT to the incoming old default. Twenty-two
other frame-tavern masters, WEB files and rows are exact; every non-target default
master-manifest and WEB-book row is exact to the staged incoming normal union.
The shared generator, params and native entrances consumer match checked cf25
exactly. Actual GLB staff-top bounds agree with each explicit flag anchor.
The existing CPU picture suite passed 20 tests; flag contract passed five.

## Closed image review and limits

ONE actual native photo_match run rendered the current canonical master directly
from source assets, on hard CPU 2, without full publish or scene compilation.
The complete Gifford source and byte-exact historical provisional camera are used.
I viewed its actual whole side-by-side. Verdict: DIFFERS. The real third storey
and pictured shutters are missing from the chosen default; this is not a pixel
or tolerance signoff. The camera's old 50 x 30 ft / 7.8 m trial remains historical
provisional framing, NOT an independently solved metric camera for the new default.
The neutral GLB review contains no dynamic flag cloth or full town context.

The retained Gifford comparison is included and bound to the current alternative
by exact master, camera and source hashes. It was NOT re-rendered. The historical
match records no renderer-code hash; no current application review is asserted.

PENDING: native scene compilation / 202 tail, entrance/apron/clearance and protected
population checks, fixed-point, current published desktop/mobile/default/version
and Images-tab review, fullcheck/preflight and PR/dev merge. Temporary selected
incoming generated source-use outputs are explicitly listed in pending-generated-tail.
Original T-2385 remains OPEN for the source disagreement and declared differences.
