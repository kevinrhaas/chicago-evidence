"""Two native published2-3 calls on the checked staged8b tree; no actual8b commit is claimed."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,re,shutil,subprocess,sys,time
P=Path(__file__).resolve().parent;F=Path('/workspace/PR1456-genuine8b-native-gate-checkpoint-prep-publisher-20261030')
sha=lambda b:hashlib.sha256(b).hexdigest();pf=lambda p:sha(Path(p).read_bytes())
assert pf(F/'CLOSED-MANIFEST.json')=='17db0a325732bd88e7d8e2f193424f16cd440864cce329125e660748ca3f784d'
for row in json.loads((F/'CLOSED-MANIFEST.json').read_bytes())['files']:
 q=Path(row['path']);assert q.parent==F and q.name==row['relative']and q.is_file()and not q.is_symlink()and q.stat().st_size==row['bytes']and pf(q)==row['sha256']
sys.dont_write_bytecode=True;sys.path.insert(0,str(F));import common as C
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',required=True,type=Path);ap.add_argument('--execute',action='store_true');a=ap.parse_args();assert a.execute
os.sched_setaffinity(0,{0,1,3,4});os.nice(19)
SOURCE='3e63ad191b0c264fa3d6a0707db9ffeed7e4de79';DEV='8b4e98207c1afcff4878239cd700379447218cfb';TREE='e7df4262112da841da674ded1b1359247946c9fa'
G=Path('/workspace/PR1456-genuine8b-root-actual-gate-20261030/GATE-RESULT.json');GH='9c6e9dc392aa7c60fc5c90647a0dd22d508c5d6fcf94d266ba45533b2eb3c9a9';assert pf(G)==GH
gate=json.loads(G.read_bytes());b=gate['binding'];assert gate['status']=='ACTUAL_PR1456_GENUINE8B_FULL_SOURCE_PASS'and gate['exit']==0 and all(v is True for v in gate['guards'].values())and gate['guards']
assert b['head']==b['source_head']==SOURCE and b['merge_parent']==DEV and b['tree']==TREE and b['parents']==[SOURCE,DEV]
assert b['reviewed_manifest_sha256']=='37d940aa6f4e42b4c9c6f993bae17fb38b0927d1f1af4c97709b295f6aad9b8b'and b['prior_checkpoint_sha256']=='6d1e34851ef788b6b519692ea745274e3aea89f4b1c90146de34bede4030fcbf'
C.configure(b['prior_checkpoint'],b['prior_checkpoint_sha256']);assert C.SOURCE==SOURCE and C.DEV==DEV
m,mh=C.load(b['reviewed_manifest']);assert mh==b['reviewed_manifest_sha256']and m['tree']==TREE
before=C.check(m);assert before==b['before'];r=C.resource(m);assert r['workspace_pass']and r['shared_TMP_pass']and r['clone_cap_pass']
for path,key in [(gate['native_check_log'],'native_check_log_sha256'),(gate['native_reaper'],'native_reaper_sha256'),(gate['native_timings'],'native_timings_sha256')]:assert pf(path)==gate[key]
rp=json.loads(Path(gate['native_reaper']).read_bytes());assert rp['command_exit']==0 and rp['all_children_reaped']is True and not rp['leftover_cleanup']
clean=re.sub(r'\x1b\[[0-9;]*m','',Path(gate['native_check_log']).read_text(errors='replace'));assert re.search(r'^CHECK PASS — 1108 steps, none red\.$',clean,re.M)
R,A=C.R,C.A;SITE=R/'site/4d';out=a.output.resolve();assert out.is_relative_to('/workspace')and not out.is_relative_to(R)and not out.is_relative_to('/workspace/chicago')and not out.exists()
assert shutil.disk_usage('/workspace').free>=536870912+128*1048576 and shutil.disk_usage('/tmp').free>=1800000000
pub=lambda:{str(p.relative_to(SITE)):dict(sha256=pf(p),bytes=p.stat().st_size)for p in sorted(SITE.rglob('*'))if p.is_file()}
published=pub();assert len(published)>100
js={str(p.relative_to(A)):pf(p)for p in sorted((A/'renderers/web/js').rglob('*'))if p.is_file()}
for rel,h in js.items():
 if rel!='renderers/web/js/changelog.js':assert pf(SITE/'walk/js'/rel.removeprefix('renderers/web/js/'))==h
assert(A/'renderers/web/js/changelog.js').read_bytes()==(SITE/'js/changelog.js').read_bytes()
shim_source=(A/'tools/changelog_shim.mjs').read_text();shim=re.search(r'^export const WALK_SHIM = `(.*)`;\s*$',shim_source,re.M|re.S);assert shim and'\\'not in shim.group(1)and'${'not in shim.group(1)and(SITE/'walk/js/changelog.js').read_bytes()==shim.group(1).encode()
prior=Path('/workspace/PR1456-currentbc7-runtime-audit-v2-first-fort-20261030/BODY-PEOPLE-REUSE.json');PH='164299a5d7344873139583564ddc45af8567033b737e48fb10977046b260ff1d';assert pf(prior)==PH;prior_rows={r['path']:r['current_sha256']for r in json.loads(prior.read_bytes())['rows']}
targets={'miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832'};reg=json.loads((A/'assets/manifest.json').read_bytes())['assets'];web=json.loads((A/'assets/manifest.web.json').read_bytes())['masters'];models={};found=set()
for name,row in reg.items():
 if row.get('structure_id')not in targets:continue
 found.add(row['structure_id']);master=A/'assets/gltf'/name;derivative=A/'assets/web'/name;delivered=SITE/'data/gltf'/name;assert pf(master)==web[name]and pf(derivative)==pf(delivered)==prior_rows['/workspace/chicago/site/4d/data/gltf/'+name];models[name]=dict(structure_id=row['structure_id'],MASTER=pf(master),WEB=pf(derivative),published=pf(delivered))
assert found==targets
sidecars={};critical={}
for sid in sorted(targets):
 rel='data/sidecars/1835/'+sid+'.json';native=(A/rel).read_bytes();shipped=(SITE/rel).read_bytes();assert sha(native)==prior_rows['/workspace/chicago/chicago/4d/'+rel]and sha(shipped)==prior_rows['/workspace/chicago/site/4d/'+rel]
 rec=json.loads(native);full=rec.get('residents');deferred=isinstance(full,list)and len(full)>0
 if deferred:
  slim=[]
  for household in full:
   h={k:v for k,v in household.items()if k not in ['why','research_note']}
   if isinstance(household.get('persons'),list):h['persons']=[{k:v for k,v in person.items()if k!='note'}for person in household['persons']]
   slim.append(h)
  assert json.loads(shipped)=={**rec,'residents':slim};assert json.loads((SITE/('data/sidecars/1835/households/'+sid+'.json')).read_bytes())=={'id':rec['id'],'residents':full}
 else:assert native==shipped
 sidecars[sid]=dict(source_sha256=sha(native),published_sha256=sha(shipped),native_household_notes_deferred=deferred,accepted3746_source_and_published_bytes_exact=True)
for rel in ['data/scenes/1835.json','data/scenes/1904.json']:
 assert(A/rel).read_bytes()==(SITE/rel).read_bytes();critical[rel]=pf(SITE/rel)
source_runtime=dict(js);source_1835={}
for rel in ['tools/smoke_renderer.mjs','tools/measure_memory.mjs','tools/memory_ceilings.json','tools/defer_household_notes.mjs','tools/changelog_shim.mjs','tools/stamp-changelog.mjs','assets/manifest.json','assets/manifest.web.json','data/scenes/1835.json','data/scenes/1904.json']:
 source_runtime[rel]=pf(A/rel)
for name in models:
 for prefix in ['assets/gltf','assets/web']:source_runtime[prefix+'/'+name]=pf(A/prefix/name)
for sid,row in sidecars.items():source_runtime['data/sidecars/1835/'+sid+'.json']=row['source_sha256']
for rel in ['data/scenes/1835.json','data/pictures/1835.json','data/sidecars/1835/people.json','data/inspect/1835.json','data/signage/town_business_signboards.json','data/yard/town_trade_goods.json','data/yard/town_woodpiles.json','data/enclosures/town_entrance_aprons.json']:
 assert(A/rel).is_file();source_1835[rel]=pf(A/rel)
for sid in targets:
 rel='data/sidecars/1835/'+sid+'.json';source_1835[rel]=pf(A/rel)
 for camera in (A/'data/reference_views'/sid).glob('*.json'):
  if not camera.name.endswith('.match.json'):source_1835[str(camera.relative_to(A))]=pf(camera)
version=json.loads((SITE/'build.json').read_bytes()).get('version');assert isinstance(version,str)and version and SOURCE.startswith(version)
helper=pf(Path(__file__));native_smoke=pf(A/'tools/smoke_renderer.mjs');cap_manifest=Path(__file__).with_name('CLOSED-MANIFEST.json');cap_sha=pf(cap_manifest);capsule=json.loads(cap_manifest.read_bytes());assert capsule['status']=='FROZEN_STAGED8B_NATIVE_SMOKE23_PREPARATION_ONLY'
for n,row in capsule['members'].items():assert pf(P/n)==row['sha256']
def guard():
 assert pf(G)==GH and pf(b['reviewed_manifest'])==mh and pf(b['prior_checkpoint'])==b['prior_checkpoint_sha256']and pf(prior)==PH
 assert C.check(m)==before and C.ticket_context(m,gate['tickets_after']['head'])
 assert pub()==published and pf(Path(__file__))==helper and pf(cap_manifest)==cap_sha
 assert all(pf(A/rel)==h for rel,h in{**source_runtime,**source_1835}.items())
 assert pf(A/'tools/smoke_renderer.mjs')==native_smoke
 for n,row in capsule['members'].items():assert pf(P/n)==row['sha256']
 r=C.resource(m);assert r['workspace_pass']and r['shared_TMP_pass']and r['clone_cap_pass']
guard();out.mkdir(mode=0o700);tmp=Path('/workspace/p1456-st8');assert not tmp.exists();tmp.mkdir(mode=0o700);(tmp/'OWNER.json').write_text(json.dumps(dict(owner='PR1456_STAGED8B_SMOKE23',source_head=SOURCE,staged_tree=TREE,output=str(out)))+'\n')
E=dict(C.E,TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),NODE_COMPILE_CACHE=str(tmp/'node-compile-cache'))
for key in ['SMOKE_ROOT','SMOKE_ENTRY','SMOKE_TARGET','SMOKE_YEAR','SMOKE_PORT','SMOKE_STAGE','SMOKE_VIEWPORT','SMOKE_SHOTS']:E.pop(key,None)
save=lambda n,d:(out/n).write_text(json.dumps(d,indent=2)+'\n')
binding=dict(revision='PR1456_STAGED8B',source_head=SOURCE,actual_HEAD=SOURCE,merge_parent=DEV,staged_tree=TREE,branch=C.BRANCH,prospective_merge_parents=[SOURCE,DEV],actual8b_commit=None,checked_staged_tree_not_committed=True,source_gate=str(G),source_gate_sha256=GH,reviewed_manifest=b['reviewed_manifest'],reviewed_manifest_sha256=mh,prior_checkpoint=b['prior_checkpoint'],prior_checkpoint_sha256=b['prior_checkpoint_sha256'],source_before=before,staged_paths=m['staged_paths'],required404_dependency_paths=m['required404_dependency_paths'],protected404_performance_paths=m['protected404_performance_paths'],new_owned_path_sha256=m['new_owned_path_sha256'],published_files=published,source_runtime_files=source_runtime,source_1835_files=source_1835,current_renderer_source_sha256=js,models=models,native_sidecar_projection=sidecars,original4_models=models,original4_sidecars=sidecars,critical_current_published_sha256=critical,published_build_version=version,publication_kind='native_publication_of_checked_staged8b_tree_at_source_parent_HEAD',native_smoke_source_sha256=native_smoke,stage_selector='2-3',logical_parts=[2,3],viewports=['desktop','mobile'],planned_real_native_calls=2,planned_logical_coverage_pairs=4,CPU_affinity=[0,1,3,4],nice=19,TMPDIR=str(tmp),helper_sha256=helper,capsule_manifest_sha256=cap_sha,source_gate_common_capsule_sha256='17db0a325732bd88e7d8e2f193424f16cd440864cce329125e660748ca3f784d',ordinary_published_root_no_alias=True,full_all15_renderer_matrix_NOT_claimed=True)
save('BINDING.json',binding);steps=[];started=[];pending=None;failure=None;start=time.monotonic();cmd=['node','tools/smoke_renderer.mjs','--published']
try:
 for view in ['desktop','mobile']:
  guard();shots=out/view;shots.mkdir();env=dict(E,SMOKE_VIEWPORT=view,SMOKE_YEAR='1835',SMOKE_STAGE='2-3',SMOKE_TIMING='1',SMOKE_SHOTS=str(shots));rp=out/(view+'-REAPER.json');pending=view;started.append(view);save('CURRENT-CALL.json',dict(viewport=view,stage_selector='2-3',started=C.now(),command=cmd,log=str(out/(view+'.log')),reaper=str(rp)));t=time.monotonic()
  with(out/(view+'.log')).open('xb')as log:q=subprocess.run(['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','nice','-n','19','taskset','-c','0,1,3,4',*cmd],cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT)
  r=json.loads(rp.read_bytes());pending=None if r['all_children_reaped']else view;clean=re.sub(r'\x1b\[[0-9;]*m','',(out/(view+'.log')).read_text(errors='replace'));audit=re.findall(r'^(\d+) staged-section check\(s\) \(stage 2-3 of 15\), (\d+) always-on check\(s\)$',clean,re.M);summary=re.findall(r'^(\d+) passed, (\d+) failed$',clean,re.M);label='desktop 1280x800'if view=='desktop'else'mobile 390x780';lines=[line for line in clean.splitlines()if re.match(r'^  pass  ',line)];has=lambda text:any(text in line for line in lines)
  predicates=dict(native_exit=q.returncode==0 and r['command_exit']==0,all_children_reaped=r['all_children_reaped']is True,no_reaper_cleanup=not r['leftover_cleanup'],exact_native_stage_audit=len(audit)==1 and int(audit[0][0])>0 and int(audit[0][1])>0,native_summary_zero_failed=bool(summary)and int(summary[-1][1])==0,no_FAIL_lines=not bool(re.search(r'^\s*FAIL\s',clean,re.M)),native_footer_PASS=bool(re.search(r'^SMOKE PASS$',clean,re.M)),native_suite_completed=has(label+': the suite body ran to completion'),native_zero_page_errors=has(label+': zero page errors'),native_vendor_no_page_error=has('vendor: meshopt import raises no page error'))
  row=dict(viewport=view,stage_selector='2-3',logical_parts=[2,3],command=cmd,exit=q.returncode,native_command_exit=r['command_exit'],seconds=time.monotonic()-t,all_children_reaped=r['all_children_reaped'],predicates=predicates,passed=all(predicates.values()),native_audit_staged_checks=int(audit[0][0])if len(audit)==1 else None,native_audit_always_on_checks=int(audit[0][1])if len(audit)==1 else None,native_summary=summary[-1]if summary else None,log_sha256=pf(out/(view+'.log')),reaper_sha256=pf(rp),screenshots=[dict(path=str(p),sha256=pf(p),bytes=p.stat().st_size)for p in sorted(shots.glob('*.png'))],native_footer=clean.splitlines()[-20:]);steps.append(row);save('STEPS.json',steps);guard()
  if not row['passed']:raise RuntimeError('Actual native staged8b '+view+' failed; remaining coverage not qualified')
except BaseException as error:failure=type(error).__name__+': '+str(error)
guards_exact=True;guard_error=None
try:guard()
except BaseException as error:guards_exact=False;guard_error=type(error).__name__+': '+str(error)
reaped=pending is None and all(s['all_children_reaped']for s in steps);passed=failure is None and guards_exact and reaped and len(started)==len(steps)==2 and all(s['passed']for s in steps)
save('RESULT.json',dict(status='ACTUAL_STAGED8B_PUBLISHED_STAGES23_BOTH_PASS'if passed else'ACTUAL_STAGED8B_PUBLISHED_STAGES23_BOTH_NOT_QUALIFIED',at=C.now(),source_head=SOURCE,actual_HEAD=SOURCE,merge_parent=DEV,staged_tree=TREE,branch=C.BRANCH,actual8b_commit=None,checked_staged_tree_not_committed=True,binding_sha256=pf(out/'BINDING.json'),source_gate_sha256=GH,reviewed_manifest_sha256=mh,prior_checkpoint_sha256=b['prior_checkpoint_sha256'],stage_selector='2-3',logical_required_parts=[2,3],actual_real_native_calls=len(started),completed_native_call_records=len(steps),started_viewports=started,qualified_logical_pairs=[dict(viewport=s['viewport'],part=p,via_one_native_grouped_call=True)for s in steps if s['passed']for p in [2,3]]if guards_exact else[],four_individual_runs_NOT_claimed=True,all15_renderer_parts_NOT_claimed=True,old503_or_failed_body_NOT_relabelled=True,all_children_reaped=reaped,pending_or_unclosed_call=pending,guards_before_after_exact=guards_exact,guard_error=guard_error,failure=failure,total_actual_seconds=time.monotonic()-start,steps=steps,native_assertions_waits_timeouts_and_viewports_unchanged=True,owned_TMP_retained_for_exact_root_cleanup=str(tmp),final_latestdev_fullsource_CP_phone_CI_and_normal_merge_separate=True))
print((out/'RESULT.json').read_text());raise SystemExit(0 if passed else 1)
