# Checked STAGED8b native2-3 BOTH — prepared, not run

Root may launch after review:

    source /workspace/shared/resume-chicago-env.sh
    nice -n 19 taskset -c 0,1,3,4 python -B /workspace/PR1456-staged8b-smoke23-prep-runtime-v2-20261030/run.py --output NEW_EXTERNAL_OWN_OUTPUT --execute

Exact sourceHEAD3e63ad191b0c264fa3d6a0707db9ffeed7e4de79, genuineMERGE_HEAD8b4e98207c1afcff4878239cd700379447218cfb, stagedtreee7df4262112da841da674ded1b1359247946c9fa. NO8bCP is required or claimed. Source parent is actual prior54CP6d1e3485…, approvedmanifest37d940aa…, and ACTUAL full8bgate9c6e9dc3… has native1108footer/exit0/allguards/reaperclosed. These actual receipts and frozen source-check common17db0… are pinned exactly; their complete all-workingmode/blob/source/index/ref/config/foreign/ticket guards run before and after both calls. Every published file is SHA-bound; currentJS/native source consumers, original4 models/source+publishedsidecars,1835sourcefiles and nativechangelog/household projections are explicitly recorded.

Two real native node tools/smoke_renderer.mjs --published calls, desktop thenmobile, nativeSMOKE_STAGE2-3/SMOKE_YEAR1835, CPU0,1,3,4/nice19, unchangedassertions/waits/timeouts/viewports. Each needs nativeauditpositive staged+alwaysoncounts, zerosummaryfailures/noFAILlines/SMOKEPASS/suitecompletion/zeropageerrors/vendorcheck and actualexit0/reaperallclosed/nocleanup. Failure stops remainingcoverage and writes honestNQ. Fourlogicalpairs are not fourindividualruns orALL15rendererparts; old503passes/failedbody are never relabelled.

PASS status ACTUAL_STAGED8B_PUBLISHED_STAGES23_BOTH_PASS is only this checked stagedtree, not a finalcommit/currentlatestdevPASS. BINDING has source_head/actual_HEAD, merge_parent, staged_tree, prospective_merge_parents explicitlynotreal, actual8b_commitnull, source_gate/manifest/priorCPpaths+SHAs, source_before fullnativecontext, published_files, source_runtime_files,source_1835_files,models,native_sidecar_projection,4performance/twofixmaps and helper/scope/processfacts. RESULT carries same stagedidentity/bindingSHA/2actualcalls/4logicalpairs, actualsteps/reapers/log/screenshot hashes and beforeafterguard outcome.

OwnedshortTMP /workspace/p1456-st8 mustinitiallynotexist and is retained for root's laterexact0FDcleanup. Workspace512MiB +128MiBentryreserve/sharedTMP1.8GB/clone4.6GBcap maintained. No source/ref/index/config/site mutation, meter, alias or forcedoperation. Subsequentlatestdev sourcegate/CP/freshphone/CI/normalmerge are separate. Datedreuse aftersourcechanges requires root's explicit actual1835/renderer consumer-preservationproof.

Validation: AST and read-only inspection only, no controller/native execution. Frozen after handoff; adjustments require newversion.

V2 changes only the imported frozen17db capsule reader to its actual files-list/absolute-path schema. Original9be V1 remains unchanged and was not launched. Root requested full read-only prefix execution through guard() before handoff; its external receipt is separate and no output/TMP/browser is created.
