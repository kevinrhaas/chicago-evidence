from pathlib import Path
import subprocess,os,json,hashlib,datetime,re,collections
out=Path(__file__).resolve().parent;repo='/workspace/t2372-parallel-native-20261030';tickets=repo+'/chicago/4d/tickets';dev='8b4e98207c1afcff4878239cd700379447218cfb';tref='7398315488d291f8c1417119c44ad842c03cd744';env=os.environ|{'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0'};sha=lambda b:hashlib.sha256(b).hexdigest()
def g(r,*a):return subprocess.check_output(['git','-C',r,*a],env=env)
paths=g(tickets,'ls-tree','-rz','--name-only',tref,'T-2250-2499').decode().split('\0');rows=[]
for n in range(2372,2389):
 p=next(p for p in paths if Path(p).name.startswith(f'T-{n}-'));b=g(tickets,'show',tref+':'+p);text=b.decode();front=text.split('---',2)[1];fields={}
 for l in front.splitlines():
  if ': ' in l:
   k,v=l.split(': ',1)
   if k in ['id','title','state','pr','closed_at','claimed_by','claimed_at','group']:fields[k]=None if v=='null' else v
 rows.append(dict(**fields,ticket_path=p,ticket_sha256=sha(b),immutable_url=f'https://github.com/kevinrhaas/chicago-tickets/blob/{tref}/{p}'))
counts=dict(collections.Counter(r['state']for r in rows));assert counts=={'claimed':7,'review':4,'open':4,'done':1,'split':1}
(out/'TICKET-SNAPSHOT-17.json').write_text(json.dumps(dict(status='IMMUTABLE_TICKET_METADATA_SNAPSHOT_ONLY_NOT_A_LIVE_LEASE_READING',ticket_main=tref,rows=rows,counts=counts,original_done=1,original_review_PR1456=4,unfinished_after_1456_if_merged_and_settled=12),indent=2)+'\n')
base=Path('/workspace');sources=[
'T2372-parallel-native-40453-closure-20261030/CLOSED-MANIFEST.json',
'T2378-parallel-native-reviewed-addendum-20261030/CLOSED-PUBLIC-MANIFEST.json',
'T2375-selected-native-source-app-WIP-closed-20261030/MANIFEST.json',
'T2376-exact67-snapshot-and-rebind-20261030/SNAPSHOT.json',
'T2376-dd1-current-consumer-audit-20261030/RESULT.json',
'T2382-current-entrywise-adoption-prep-first-fort-20261030/CLOSED-MANIFEST.json',
'T2382-published-BOTH-current2b01-20261030/CLOSED-V3-APP-MANIFEST.json',
'T2386-current-picture-closure-prep-20261030/CLOSED-MANIFEST.json',
'T2386-current9d97-sixcase-execution-prep-publisher-20261030/CLOSED-MANIFEST.json',
'T2383-current-canonical-controller-prep-20261030/CLOSED-MANIFEST.json',
'T2383-front-entrance-proposal-20261030/CLOSED-MANIFEST.json',
'T2387-first-fort-readiness-20261030/MANIFEST.json',
'T2387-native25-controller-20261030/CONTROLLER-CLOSED-MANIFEST.json',
'T2388-canonical21-fixedview-ready-9d97-20261030/MANIFEST.json',
'T2380-corrected-v3-actual-closure-20261030/CLOSED-MANIFEST.json',
'T2380-v3-actual-projection-diagnostic-20261030/HANDOFF.md',
'T2374-agency-key-identity-review-20261030/CLOSED-MANIFEST.json',
'T2379-LakeHouse-H9-T3105-plan-20261024/CLOSED-MANIFEST.json']
refs=[dict(path=str(base/p),sha256=sha((base/p).read_bytes()))for p in sources]
current=[]
for folder in ['green_tree_tavern','log_jail','philo_carpenter_log_shop']:
 names=g(repo,'ls-tree','-rz','--name-only',dev,'chicago/4d/data/reference_views/'+folder).decode().split('\0')
 for p in names:
  if p.endswith('.match.json'):
   b=g(repo,'show',dev+':'+p);d=json.loads(b);current.append(dict(path=p,sha256=sha(b),verdict=d.get('verdict'),open_differences=[x['what']for x in d.get('differences',[])if x.get('status')=='open']))
(out/'AUTHORITIES.json').write_text(json.dumps(dict(status='READONLY_EXISTING_CLOSED_WORK_AND_NAMED_DEV_REFERENCE_AUDIT',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),named_dev=dev,named_dev_tree=g(repo,'rev-parse',dev+'^{tree}').decode().strip(),ticket_snapshot=tref,capsule_manifest_hashes=refs,current_canonical_open_matches=current,limits='Manifest references and selected immutable files were read; no fresh blanket rehash of every large capsule member, source edit, claim, capture, gate, PR or merge action. Historical matches/browser scopes remain dated; all post1456 application plans must rebind actual dev/fold and native recipe/state.'),indent=2)+'\n')
