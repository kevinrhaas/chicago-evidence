from pathlib import Path
import json,subprocess,hashlib,datetime,os,sys
r=Path('/tmp/chicago-log-integration/chicago/4d');out=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pop=[r/'data/reconstruction/1835_lodgers_seated.json',r/'data/reconstruction/1835_reconstruction_order_book.json',*sorted((r/'data/residents/lodgers').glob('*.json'))];assert len(pop)==24
baseline={str(p.relative_to(r)):sha(p)for p in pop};(out/'population-before-hashes.json').write_text(json.dumps(baseline,indent=2)+'\n')
state={'status':'RUNNING','started':now(),'HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'population_guard':24,'steps':[]};receipt=out/'receipt.json'
def save():receipt.write_text(json.dumps(state,indent=2)+'\n')
save();env={**os.environ,'TMPDIR':'/workspace/tmp-t3081','PATH':'/workspace/shared/tools/usr/bin:'+os.environ['PATH'],'PYTHONDONTWRITEBYTECODE':'1'}
commands=[('placement-build',['python3','tools/placement_policy_1835.py','--build']),('placement-check',['python3','tools/placement_policy_1835.py','--check']),('lodging-build',['python3','tools/build_lodging_model_1835.py','--build']),('lodging-check',['python3','tools/build_lodging_model_1835.py','--check']),('native-tail',['node','tools/rederive.mjs','--tail','tools/compile_liberties.py'])]
try:
 for name,args in commands:
  item={'name':name,'command':args,'started':now()};state['steps'].append(item);save()
  with(out/(name+'.log')).open('w')as log:q=subprocess.run(args,cwd=r,stdout=log,stderr=subprocess.STDOUT,env=env)
  item.update(exit_code=q.returncode,finished=now());save();assert q.returncode==0,name
 for p,h in baseline.items():assert sha(r/p)==h,('population identities changed',p)
 state.update(status='PASS',finished=now(),all22_lodger_cards_ledger_orderbook_exact=True);save();print(json.dumps(state,indent=2))
except BaseException as e:state.update(status='FAILED',error=str(e),finished=now());save();raise
