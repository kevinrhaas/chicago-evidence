"""Freeze the final published group only after native closure; no browser run."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys

R = Path('/workspace/chicago')
A = R / 'chicago/4d'
O = Path(os.environ['EARLY_GROUP_APP_HOME'])
assert os.environ.get('EARLY_GROUP_APP_READY') == 'current-native-and-publish-closed'
assert not O.exists()
O.mkdir(parents=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

# Miller's existing freezer binds the entire site once. Every peer uses that
# exact binding, rather than making separate potentially different snapshots.
env = dict(os.environ, MILLER_APP_HOME=str(O / 'miller'))
subprocess.run([sys.executable, '/tmp/miller-execution-prep-20261027/app/freeze_app_inputs.py'], env=env, check=True)
site_binding = O / 'miller/SOURCE-BINDINGS.json'
binding = json.loads((O / 'miller/APP-EXPECTED.json').read_text())['source_binding']
results = []
for sid, phase_id, label in [
    ('st_marys_church', 'frame_1833', 'mary'),
    ('chicago_lighthouse_1832', 'tower_1832', 'lighthouse'),
]:
    record_path = A / 'data/structures' / (sid + '.json')
    record = json.loads(record_path.read_text())
    phase = next(p for p in record['phases'] if p['id'] == phase_id)
    side_path = A / 'data/sidecars/1835' / (sid + '.json')
    side = json.loads(side_path.read_text())
    attrs = phase['form']
    for key, value in attrs.items():
        assert side['attributes'][key]['value'] == value['value'], (sid, key)
        assert side['attributes'][key]['confidence'] == value['confidence'], (sid, key)
    model_name = sid + '__' + phase_id + '.glb'
    master = A / 'assets/gltf' / model_name
    web = A / 'assets/web' / model_name
    published = R / 'site/4d/data/gltf' / model_name
    assert sha(web) == sha(published)
    expected = {
        'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_binding': dict(binding, record_sha256=sha(record_path),
                               master_sha256=sha(master), WEB_sha256=sha(web),
                               native_sidecar_sha256=sha(side_path)),
        'site_binding_file': str(site_binding), 'sidecar': side,
        'grade': side['grade'], 'attributes': attrs,
        'placement': side['placement'], 'WEB_sha256': sha(web),
    }
    if label == 'mary':
        assert attrs['front_window_sill_m']['value'] == 1.4
        assert attrs['front_window_sill_m']['confidence'] == 'reconstructed'
        assert sha(master) == '1443ab7dc50739a211a41ba87eb3ab31c85644c344469fdd578ad80101b6bbaf'
    else:
        assert sha(master) == 'ae855793a983ff884b2653479c74fe517d3f8f2f14b6eae606f972a68373224d'
        assert side['grade']['pictures'] == ['early-castelnau-1842-chicago-harbor']
        assert side['grade']['why'] == 'Pictured: a picture on the Images tab shows it.'
    target = O / label
    target.mkdir()
    (target / 'APP-EXPECTED.json').write_text(json.dumps(expected, indent=2) + '\n')
    results.append({'case': label, 'expected': str(target / 'APP-EXPECTED.json'),
                    'WEB_sha256': sha(web), 'native_sidecar_sha256': sha(side_path)})

assert json.loads((O / 'miller/SOURCE-BINDINGS.json').read_text())['paths']
(O / 'PREPARED.json').write_text(json.dumps({
    'status': 'CURRENT_FINAL_GROUP_APP_INPUTS_FROZEN_NOT_RUN',
    'site_binding_file': str(site_binding), 'cases': results,
    'scope': 'Metadata binding only; actual both-viewport app and native full3 remain separate.'
}, indent=2) + '\n')
print(json.dumps(results, indent=2))
