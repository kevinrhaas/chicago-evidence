from pathlib import Path
import json,os,subprocess,hashlib,datetime,importlib.util
R=Path('/workspace/chicago');A=R/'chicago/4d';T=Path('/workspace/isolated-gt-ticket-renewal-native-v4-20261029/repo');O=Path('/workspace/T2382-official-claim-reviewed-force-school-agent-v3-20261029');O.mkdir()
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',CHICAGO_TICKETS_DIR=str(T))
g=lambda root,*a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=root,env=E,text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':g(R,'rev-parse','HEAD'),'staged_entries':g(R,'ls-files','--stage'),'index_bytes':sha(R/'.git/index'),'status':g(R,'status','--porcelain=v1'),'refs':g(R,'show-ref')}
review=Path('/workspace/T2382-official-claim-school-agent-v3-20261029/STALE-OWN-BRANCH-GUARD-READONLY-REVIEW.json');assert json.loads(review.read_text())['status']=='ACTUAL_READONLY_BOTH_OLD_BRANCHES_NO_OPEN_PR_AND_PRIOR_1348_MERGED'
before=snap();theadt=g(T,'rev-parse','HEAD');assert theadt=='b92d033c528e40d0896d7304027443dcf24ed8c2';assert not g(T,'status','--porcelain=v1')
files={str(p.relative_to(T)):sha(p)for p in T.glob('T-*/T-*.md')};assert len(files)>3000
(O/'BEFORE.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':before,'tickets_head':theadt,'all_ticket_files':files,'root_authorization':'Explicitreviewedoldownbranchguardonly; bothbranchPRsactualZEROopen/pr1348actualmerged; noforcefreshholder','review_receipt_sha256':sha(review)},indent=2)+'\n')
cmd=['python3','/workspace/shared/run-with-reaping.py',str(O/'NATIVE-CLAIM-REAPER.json'),'--','node','tools/ticket.mjs','claim','T-2382','--force','--by','Codex Carpenter picture match 2026-10-29']
with(O/'NATIVE-CLAIM.log').open('x')as f:q=subprocess.run(cmd,cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
(O/'EXIT.json').write_text(json.dumps({'exit':q.returncode,'command':cmd},indent=2)+'\n');print('nativeclaimexit',q.returncode,flush=True);assert q.returncode==0
reaper=json.loads((O/'NATIVE-CLAIM-REAPER.json').read_text());assert reaper['all_children_reaped'];after=snap();guards={k:before[k]==after[k]for k in before};assert all(guards[k]for k in ['HEAD','staged_entries','refs']),'No primarysource/index-staging/refs mutations allowed'
changed=[p for p,h in files.items()if sha(T/p)!=h];assert len(changed)==1 and '/T-2382-'in changed[0],changed
head=g(T,'rev-parse','HEAD');sp=importlib.util.spec_from_file_location('transport','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);m.REPO='kevinrhaas/chicago-tickets';remote=m.api('git/ref/heads/main')['object']['sha'];assert remote==head,'Native claim may remain local; remote readback must match';commit=m.api('git/commits/'+head);assert commit['sha']==head and len(commit['parents'])==1 and commit['parents'][0]['sha']==theadt
from urllib.request import urlopen,Request
from urllib.parse import quote
with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+head+'/'+quote(changed[0]),headers={'User-Agent':'Chicago-native-original-claim-readback'}),timeout=90)as response:assert response.status==200;raw=response.read()
assert raw==(T/changed[0]).read_bytes() and b'Codex Carpenter picture match 2026-10-29'in raw
(O/'IMMUTABLE-CLAIM-READBACK.md').write_bytes(raw)
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_OFFICIAL_NATIVE_CARPENTER_CLAIM_REMOTE_IMMUTABLE_READBACK_PASS','native_commit':head,'native_parent':theadt,'remote_head':remote,'changed_ticket':changed[0],'all_other_original_ticket_files_exact':True,'source_guards':guards,'allchildrenreaped':True,'native_force_limited_to_reviewed_stale_own_branches':True,'ignored_primary_ticket_mirror_may_refresh':True,'primary_default_cache_still_b92d_requires_FF_before_publish':True}
(O/'AFTER.json').write_text(json.dumps({'source':after},indent=2)+'\n');(O/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2),flush=True)
