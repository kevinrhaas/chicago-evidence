# Exact two-leaf correction before the required full gate

Public363 reconstructs14dd. Apply this exactpatch (only2leafreports+honestSTATUS) to recover9092fd814e577c9b7b7c55221f1f4b90b013fb48; nativealternate-index proofis exact. No assetbytes are copied.

The priorfull1070-step run failed2stale leafreports; CL+IDs andallsource/indexguards passed. Nativebusiness --group lodging_river_and_transport --build andstaffing_mint_order --build refreshONLYnineordinarybedledgercells and4bedaccountingfields/sentence. All48firms/everyperson/home/seat/quota/otherfile remains exact; mintauthorization32 andmintable0unchanged. Bothnativechecks+selftestsPASS. No115/202/app/bakecycle. Originalfailure/dryproof/before-afteroutputs preserved.

An external2GBstartupguard firststopped BEFOREanynativecheck; itsreceiptis preserved. Verifiedrelocation/forwardingofCLOSEDownedpublicbaseline/duplicate metadata restoredheadroom withoutchangingnativeassertions. ExactlyONE actualrequired2-jobFULL3 is nowrunning1,4 on9092; no PASS/codecommit/publicPR/FULL18certificate is claimed. UponactualPASS/reaping: normalcommit, actualcommittedCL/IDs, normalpushDEV DRAFTPR, nativeDIRECTlap, exactlyONE9groups×both18smokeworkflows againstexactpublichead. Rootready/mergeonlyafteractualFULL18. OriginalT2385remainsOPEN/DIF.
