from pathlib import Path
import os,json,subprocess,hashlib,datetime,shutil
os.sched_setaffinity(0,{2})
repo=Path('/tmp/tremont-picture-20261026');app=repo/'chicago/4d';rt=Path('/tmp/tremont-T2385-runtime-20261026');out=Path('/tmp/T2385-two-native-leaf-refresh-20261026');assert not out.exists();out.mkdir()
env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def g(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=repo,env=env).decode().strip()
assert g('write-tree')=='14dd258dcf7f58cfeeb42b3eea2654bda222a50d' and not g('diff','--name-only')
fail=json.load(open('/tmp/T2385-a575-full3-20261026/RESULT.json'));assert fail['status']=='FAIL_CURRENT_A575_PREFLIGHT_RETAINED'
receipt=json.load(open(rt/'a575-full3-reaper.json'));assert receipt['command_exit']==1 and receipt['all_children_reaped'] and not receipt['leftover_cleanup']
leafs=['data/reconstruction/1835_business_reconstruction.json','data/reconstruction/1835_staffing_mint_order.json'];expected=['expected-native-business-ledger.json','expected-native-staffing-order.json']
for rel in leafs:
 p=app/rel;q=out/'before'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
steps=[]
def command(name,args):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(out/(name+'.log')).open('x')as log:p=subprocess.run(args,cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':args,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode};steps.append(row);(out/'STEPS.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True);assert p.returncode==0
command('01-native-business-owner',['python3','tools/reconstruct_businesses_1835.py','--group','lodging_river_and_transport','--build'])
command('02-native-staffing-leaf',['python3','tools/staffing_mint_order_1835.py','--build'])
changed=set(g('diff','--name-only').splitlines());assert changed=={'chicago/4d/'+p for p in leafs},changed
for rel,e in zip(leafs,expected):assert json.loads((app/rel).read_text())==json.loads((Path('/tmp/T2385-two-leaf-owner-diagnosis-20261026')/e).read_text()),rel
assert not g('ls-files','--others','--exclude-standard')
# All48 business records and every person/home/seat/quota/ruling input are unchanged:
# nativeGit sees ONLY the exact2 leaf reports above, matching the reviewed dry proof.
for name,args in [('03-business-check',['python3','tools/reconstruct_businesses_1835.py','--check']),('04-business-selftest',['python3','tools/reconstruct_businesses_1835.py','--self-test']),('05-staffing-check',['python3','tools/staffing_mint_order_1835.py','--check']),('06-staffing-selftest',['python3','tools/staffing_mint_order_1835.py','--self-test'])]:command(name,args)
assert set(g('diff','--name-only').splitlines())==changed and not g('ls-files','--others','--exclude-standard')
for rel in leafs:
 q=out/'after'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(app/rel,q)
note='''\n\nT-2385 leaf-report closure, 2026-10-26: the fresh14dd full gate retained two\nfailures, both unregistered leaf reports of the already-updated lodging model.\nNative business reconstruction refreshes exactly nine ordinary-capacity ledger\ncells; all48 reconstructed firms re-derive unchanged. Native staffing-order\nrefreshes only ordinary beds slept in215→212, physical empty beds37→40,\noccupants above the ordinary figure5→8 and its matching sentence. Remaining\ncarried mint authorization32 and mintable_today0 stay unchanged. No person, firm,\nidentity, home, seat, quota, allocation or staffing ruling is re-dealt. Both\nnative checks and self-tests pass. No scene/native115/202/app/bake cycle is used\nfor these reports, whose literal readers are their own tools. The original full\ntwo-failure verdict is preserved; another full preflight on this exact corrected\nsource remains pending before any code commit or draft dev PR.\n'''
p=app/'docs/STATUS.md';p.write_text(p.read_text()+note)
assert set(g('diff','--name-only').splitlines())==changed|{'chicago/4d/docs/STATUS.md'}
g('add','--',*['chicago/4d/'+p for p in leafs],'chicago/4d/docs/STATUS.md');g('diff','--cached','--check');assert not g('diff','--name-only');tree=g('write-tree')
old=json.load(open(rt/'A575-CODEGATE-CANDIDATE.json'));shutil.copy2(rt/'A575-CODEGATE-CANDIDATE.json',out/'prior-14dd-candidate.json');old.update(status='FROZEN_TWO_LEAF_CORRECTED_FOR_FULL3_NO_CODECOMMIT',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate_index_tree=tree,leaf_refresh_receipt=str(out/'RESULT.json'));(rt/'A575-LEAF-CODEGATE-CANDIDATE.json').write_text(json.dumps(old,indent=2)+'\n')
r={'status':'PASS_EXACT_TWO_NATIVE_LEAF_REFRESH_NO_IDENTITY_OR_ALLOCATION_CHANGE','finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':steps,'only_changed_files_before_STATUS':sorted(changed),'exact_reviewed_business_ledger_cells':9,'exact_reviewed_staffing_accounting_fields':4,'all48_business_records_and_every_other_tracked_file_exact_before_STATUS':True,'all_people_homes_seats_quotas_allocations_mintauthorization32_mintable0_unchanged':True,'prior_full2FAIL_preserved':True,'new_candidate_tree':tree,'base':g('rev-parse','HEAD'),'branch':g('branch','--show-current'),'next':'Required FULL3 rootauthorized1,4 CHECK_JOBS2, no furthernative/source/bake/appcycle; normalcommit/draftPR onlyafterPASS; originalT2385OPEN/DIF.'};(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2),flush=True)
