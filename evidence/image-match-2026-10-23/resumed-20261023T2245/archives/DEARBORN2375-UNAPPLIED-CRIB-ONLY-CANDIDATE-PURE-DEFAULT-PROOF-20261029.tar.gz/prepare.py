from pathlib import Path
import hashlib,json,difflib,datetime
root=Path('/workspace/chicago/chicago/4d');out=Path(__file__).resolve().parent
rels=['generators/archetypes/bridge_timber_params.py','data/structures/dearborn_street_drawbridge.json']
old={rel:(root/rel).read_bytes() for rel in rels};s=old[rels[0]].decode()
def replace(a,b):
 global s
 assert s.count(a)==1,(a[:80],s.count(a));s=s.replace(a,b)
replace('    "draw_span_m", "gallows_frames", "gallows_height_m",','    "draw_span_m", "gallows_frames", "gallows_height_m",\n    "draw_bearing_supports",')
replace('    draw_span_m: float | None = None\n','    draw_span_m: float | None = None\n\n    # Optional pictured bearing relationship; retain every default station.\n    # Move the nearest surviving approach crib onto each existing draw end.\n    draw_bearing_supports: bool = field(default=False, kw_only=True)\n')
replace('        return [x for x in xs if not lo < x < hi]\n','''        outside = [x for x in xs if not lo < x < hi]
        if not self.draw_bearing_supports:
            return outside
        # The default stations can leave a frame between approach cribs. Only
        # relocate existing survivors: this option never invents another pier.
        left = [x for x in outside if x <= lo]
        right = [x for x in outside if x >= hi]
        if not left or not right:
            raise ParamError("draw_bearing_supports needs a surviving support on each approach")
        left[-1] = lo
        right[0] = hi
        return left + right
''')
replace('        if self.draw_lifting_gear not in DRAW_GEAR:\n','''        if not isinstance(self.draw_bearing_supports, bool):
            raise ParamError("draw_bearing_supports must be boolean")
        if self.draw_bearing_supports:
            if not self.draw_span_m or self.gallows_frames != 2 or self.bays < 3:
                raise ParamError("draw_bearing_supports needs a draw, two gallows and two approach supports")
            # Evaluate the selected stations here so an option with no surviving
            # support on one approach refuses before a geometry build begins.
            _ = self.pier_x
        if self.draw_lifting_gear not in DRAW_GEAR:
''')
replace('        gallows_frames=int(val("gallows_frames", 0)),','        draw_bearing_supports=val("draw_bearing_supports", False),\n        gallows_frames=int(val("gallows_frames", 0)),')
s=s.replace('"""Centre-lines of the interior supports, evenly spaced along the span.','"""Interior supports, regular by default or aligned at draw bearings.').replace("EVEN SPACING IS THE ARCHETYPE'S, always.","EVEN SPACING IS THE ARCHETYPE'S default.")
r=json.loads(old[rels[1]]);ph=r['phases'][0];assert ph['id']=='draw_1834';block={'value':True,'confidence':'inferred','sources':['andreas_1884_dearborn_drawbridge_plate'],'note':"THE DRAW BEARS ON THE CRIBS. The retrospective Andreas 1884 p. 631 plate shows a crib beneath each frame/draw-end assembly. Align the nearest existing surviving approach support on each side with the existing text-derived draw end. The current stations move inward 2.081 m, from 26.94/49.39 m to 29.021/47.309 m along the unchanged 76.33 m local span; these numbers are model arithmetic, not dimensions measured from the engraving or a geographic placement. The 12 surviving supports, invented crib construction and remaining approach stations stay reconstructed. The deck remains flat at its previous height. This finite correction does not settle the central rise, gallows proportions/mechanism, approach trestle or provisional camera, and original T-2375 remains open/differs."}
r['phases'][0]['form']['draw_bearing_supports']=block
text=old[rels[1]].decode();anchor='\n      },\n      "change_note"';assert text.count(anchor)==1
encoded=json.dumps({'draw_bearing_supports':block},indent=2,ensure_ascii=False).splitlines()[1:-1];encoded='\n'.join('      '+line for line in encoded)
text=text.replace(anchor,',\n'+encoded+anchor)
assert json.loads(text)==r
new={rels[0]:s.encode(),rels[1]:text.encode()}
for rel in rels:
 for which,data in [('before',old[rel]),('candidate',new[rel])]:
  p=out/which/'chicago/4d'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
lib='''\n\n### L-dearborn-draw-bearing-cribs-2375 — The draw's bearings\n\n**Covers:** `dearborn_street_drawbridge.draw_1834.form.draw_bearing_supports`.\n**Decision:** Align the nearest existing surviving approach crib on each side\nwith the already modeled draw/gallows endpoint. The Andreas 1884 p. 631\nretrospective plate (`andreas_1884_dearborn_drawbridge_plate`) supports the relative\nbearing relationship as inferred form, never a geographic coordinate.\n**What is invented:** The twelve surviving cribs, their sections and remaining\napproach layout remain reconstructed. The selected two stations move inward\n2.081 m within the unchanged local span. This is arithmetic on the existing\n76.33 m span/18.288 m draw, not a metric measurement from a provisional camera.\n**Limits:** The flat floor, geography, draw length and support count/type stay\nunchanged. Central rise, mechanism, trestle and whole-picture fit remain open;\nwhole-picture acceptance remains unfinished.\n**Ticket:** T-2375.\n**Recorded:** 2026-10-29.\n'''
(out/'LIBERTY-APPEND.md').write_text(lib)
patch=''.join(''.join(difflib.unified_diff(old[rel].decode().splitlines(True),new[rel].decode().splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel)) for rel in rels)
(out/'SOURCE-2PATH.patch').write_text(patch)
proof={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'UNAPPLIED_SOURCE_CANDIDATE','source_root':str(root),'preimages':{r:hashlib.sha256(b).hexdigest() for r,b in old.items()},'postimages':{r:hashlib.sha256(b).hexdigest() for r,b in new.items()},'other_canonical_outputs_untouched':True,'canonical_claim_not_taken':'No safe existing author checkout; root explicitly authorized external adoptionpacket fallback only.','control':'one keyword-only defaultFalse draw_bearing_supports; no rise/profile/runtime overlay/horse machinery','difference_from_historical_H4':'Refuse missing-survivor cases instead of creating new supports; preserve selected record count.','adoption':'Verify exact two source preimages, apply SOURCE-2PATH.patch, append LIBERTY-APPEND to current LIBERTIES preserving all existing bytes. Claim T2375 first in actualauthorcheckout. Wholepicture DIFFERS.'}
assert all((root/rel).read_bytes()==b for rel,b in old.items());(out/'SOURCE-BINDINGS.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
