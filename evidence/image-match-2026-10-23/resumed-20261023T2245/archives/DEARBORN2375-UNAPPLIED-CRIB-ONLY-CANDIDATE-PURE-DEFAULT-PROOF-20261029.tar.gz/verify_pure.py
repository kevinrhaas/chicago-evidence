from pathlib import Path
import sys,types,importlib.util,json,dataclasses,hashlib,math,time,copy,inspect
sys.dont_write_bytecode=True
out=Path(__file__).resolve().parent;root=Path('/workspace/chicago/chicago/4d');base=out/'before/chicago/4d';cand=out/'candidate/chicago/4d';start=time.monotonic()
sys.path.insert(0,str(root/'generators'));sys.modules['bpy']=types.ModuleType('bpy')
from common import mesh
mesh.MeshBuilder.to_object=lambda self,mats=None:{'verts':self.verts,'faces':self.faces,'confidence':self.conf,'materials':mats,'mat_index':self.mat_index,'named':self.named}
mesh.simple_material=lambda name,rgba,roughness=.75:{'name':name,'rgba':rgba,'roughness':roughness}
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=load('crib_old_params',base/'generators/archetypes/bridge_timber_params.py');new=load('crib_new_params',cand/'generators/archetypes/bridge_timber_params.py')
def producer(name,params):
 sys.modules['archetypes.bridge_timber_params']=params;return load(name,root/'generators/archetypes/bridge_timber.py')
of=producer('crib_old_build',old);nf=producer('crib_new_build',new)
entries=json.loads((root/'assets/manifest.json').read_text())['assets'];rows=[];inputs={root/'assets/manifest.json',root/'generators/archetypes/bridge_timber.py',root/'generators/archetypes/bridge_timber_params.py',root/'generators/common/mesh.py',root/'generators/common/materials.py',root/'generators/common/logwork.py'}
records=[]
for asset,e in entries.items():
 if e.get('archetype')!='bridge_timber':continue
 rp=root/'data/structures'/f"{e['structure_id']}.json";inputs.add(rp);records.append((asset,e,rp))
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
for asset,e,rp in records:
 r=json.loads(rp.read_text());ph=next(p for p in r['phases'] if p['id']==e['phase_id']);a=old.from_phase(ph,r);b=new.from_phase(ph,r)
 d=dataclasses.asdict(b);assert d.pop('draw_bearing_supports') is False;assert d==dataclasses.asdict(a)
 ga=of.build(a,asset);gb=nf.build(b,asset);assert ga==gb,asset
 rows.append({'asset':asset,'verts':len(gb['verts']),'polygons':len(gb['faces']),'whole_raw_geometry_material_confidence_named_exact':True})
assert len(rows)==6
old_fields=dataclasses.fields(old.BridgeTimberParams);new_fields=dataclasses.fields(new.BridgeTimberParams);legacy=[f for f in new_fields if f.name!='draw_bearing_supports']
assert [(f.name,f.default,f.default_factory,f.kw_only) for f in old_fields]==[(f.name,f.default,f.default_factory,f.kw_only) for f in legacy]
assert inspect.signature(new.BridgeTimberParams).parameters['draw_bearing_supports'].kind==inspect.Parameter.KEYWORD_ONLY
assert old.BridgeTimberParams.__match_args__==new.BridgeTimberParams.__match_args__
r=json.loads((cand/'data/structures/dearborn_street_drawbridge.json').read_text());p=new.from_phase(r['phases'][0],r);before_record=copy.deepcopy(r);before_record['phases'][0]['form'].pop('draw_bearing_supports');a=old.from_phase(before_record['phases'][0],before_record)
ga=of.build(a,'same');gb=nf.build(p,'same')
assert len(a.pier_x)==len(p.pier_x)==12
assert p.pier_x==[x if i not in [5,6] else p.gallows_x[i-5] for i,x in enumerate(a.pier_x)]
assert len(ga['verts'])==len(gb['verts']);assert all(ga[k]==gb[k] for k in ['faces','confidence','materials','mat_index','named'])
assert all(math.isfinite(k) for v in gb['verts'] for k in v)
assert all(abs(x[1]-y[1])<1e-13 and abs(x[2]-y[2])<1e-13 for x,y in zip(ga['verts'],gb['verts']))
maxdx=max(abs(x[0]-y[0]) for x,y in zip(ga['verts'],gb['verts']));assert abs(maxdx-2.081)<1e-12
assert a.deck_height_m==p.deck_height_m and a.gallows_x==p.gallows_x
invalid=[]
for name,change in [('numeric1',{'draw_bearing_supports':1}),('string',{'draw_bearing_supports':'yes'}),('None',{'draw_bearing_supports':None}),('no_draw',{'draw_span_m':None}),('one_gallows',{'gallows_frames':1}),('no_survivors',{'draw_span_m':75.0}),('one_bay',{'pier_count':0})]:
 try:dataclasses.replace(p,**change).validate()
 except new.ParamError:invalid.append(name)
 else:raise AssertionError(name)
assert hashes=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
assert all((base/rel).read_bytes()==(root/rel).read_bytes() for rel in ['generators/archetypes/bridge_timber_params.py','data/structures/dearborn_street_drawbridge.json'])
result={'status':'PASS_PURE_ONLY_UNAPPLIED','elapsed_s':time.monotonic()-start,'current_six_default_raw_controls':rows,'legacy_positional_count':len([f for f in old_fields if not f.kw_only]),'legacy_defaults_factories_and_match_args_exact':True,'new_keyword_only_CONSUMED': 'draw_bearing_supports' in new.CONSUMED,'candidate':{'vertices':len(gb['verts']),'polygons':len(gb['faces']),'nominal_fan_triangle_count':sum(len(f)-2 for f in gb['faces']),'old_stations':a.pier_x,'new_stations':p.pier_x,'old_and_new_count':12,'only_changed_coordinate_axis':'localX;Y/Z within1e-13m','max_local_x_delta_m':maxdx,'face_indices_materials_confidences_named_exact':True,'deck_height_unchanged':True,'gallows_stations_unchanged':True},'invalid_controls_refused':invalid,'canonical_input_hashes_before_after_exact':hashes,'limits':'No claim/canonical adoption/Blender/nativeexport/GLB/WEB/camera/browser/gate/newimageacceptance. Full nativefamilyexports and actualpublishedBOTH/app/sourcecomparisons stillowed. OriginalT2375 remainsOPEN/DIFFERS.'}
(out/'PURE-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='canonical_input_hashes_before_after_exact'},indent=2))
