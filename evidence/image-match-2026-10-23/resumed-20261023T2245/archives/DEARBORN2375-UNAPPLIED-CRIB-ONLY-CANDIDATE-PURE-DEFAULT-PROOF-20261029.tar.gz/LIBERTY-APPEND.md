

### L-dearborn-draw-bearing-cribs-2375 — The draw's bearings

**Covers:** `dearborn_street_drawbridge.draw_1834.form.draw_bearing_supports`.
**Decision:** Align the nearest existing surviving approach crib on each side
with the already modeled draw/gallows endpoint. The Andreas 1884 p. 631
retrospective plate (`andreas_1884_dearborn_drawbridge_plate`) supports the relative
bearing relationship as inferred form, never a geographic coordinate.
**What is invented:** The twelve surviving cribs, their sections and remaining
approach layout remain reconstructed. The selected two stations move inward
2.081 m within the unchanged local span. This is arithmetic on the existing
76.33 m span/18.288 m draw, not a metric measurement from a provisional camera.
**Limits:** The flat floor, geography, draw length and support count/type stay
unchanged. Central rise, mechanism, trestle and whole-picture fit remain open;
whole-picture acceptance remains unfinished.
**Ticket:** T-2375.
**Recorded:** 2026-10-29.
