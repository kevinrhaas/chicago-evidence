

### L-dearborn-draw-bearing-cribs-2375 — The draw's bearings

**Covers:** `dearborn_street_drawbridge.draw_1834.form.draw_bearing_supports`.
**Decision:** Align the nearest existing surviving approach crib on each side
with the already modeled draw/gallows endpoint. The Andreas 1884 p. 631
retrospective plate (`andreas_1884_dearborn_drawbridge_plate`) supports the relative
bearing relationship as inferred form, never a geographic coordinate.
**What is invented:** The twelve surviving cribs, their sections and remaining
approach layout remain reconstructed. The selected two stations move inward
2.081 m within the unchanged local span. This is arithmetic on the existing
76.33 m span/18.288 m draw, not a metric measurement from a provisional camera.
**Limits:** The flat floor, geography, draw length and support count/type stay
unchanged. Central rise, mechanism, trestle and whole-picture fit remain open;
whole-picture acceptance remains unfinished.
**Ticket:** T-2375.
**Recorded:** 2026-10-29.


### L-dearborn-closed-rise-2375 — The closed draw's central rise

**Covers:** `dearborn_street_drawbridge.draw_1834.form.draw_rise_m`.
**Decision:** A visible central rise follows the retrospective Andreas 1884
p.631 plate as inferred form. An exact 1.2m peak, the two linear slopes and
folded/split timber joints are reconstructed; they are not measured from the
provisional camera or established by a contemporary specification.
**Limits:** The text-derived draw span, footprint, geographical placement and
approach heights remain. Cribs stay horizontal; gallows remain vertical with
level heads. This is a closed display, not a hoisted or animated mechanism.
The nominal floor bridges board gaps and omits proud thresholds; no foot,
wheel or whole-body contact precision follows. Whole-picture acceptance,
mechanism attribution, gallows/trestle fit and camera calibration remain open.
**Ticket:** T-2375.
**Recorded:** 2026-10-29.
