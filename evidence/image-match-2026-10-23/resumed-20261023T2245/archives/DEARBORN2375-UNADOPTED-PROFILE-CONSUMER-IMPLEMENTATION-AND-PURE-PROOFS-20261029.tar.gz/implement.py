from pathlib import Path
import re,json,hashlib,difflib,datetime
out=Path(__file__).resolve().parent;root=Path('/workspace/chicago/chicago/4d');crib=Path('/tmp/dearborn-crib-only-candidate-20261029');hist=Path('/tmp/remaining-work-audit-20261029-resume/bridge-H4-adoption.patch').read_text()
rels=['generators/archetypes/bridge_timber_params.py','generators/archetypes/bridge_timber.py','tools/compile_scene.py','tools/measure_anchors.mjs','renderers/web/js/walker.js','renderers/web/js/route.js','renderers/web/js/main.js','renderers/web/js/humans.js','data/structures/dearborn_street_drawbridge.json','docs/GLB-CONTRACT.md']
old={rel:(root/rel).read_bytes() for rel in rels};new={rel:v.decode() for rel,v in old.items()};param=rels[0]
for rel in [param,'data/structures/dearborn_street_drawbridge.json']:
 assert old[rel]==(crib/'before/chicago/4d'/rel).read_bytes();new[rel]=(crib/'candidate/chicago/4d'/rel).read_text()
def rep(rel,a,b):
 assert new[rel].count(a)==1,(rel,a[:90],new[rel].count(a));new[rel]=new[rel].replace(a,b)
rep(param,'from dataclasses import dataclass, field\n','from dataclasses import dataclass, field\nimport math\n')
rep(param,'RAILING_KINDS = ("pole", "board")','RAILING_KINDS = ("pole", "board")\nDRAW_PROFILES = ("flat", "peaked")')
rep(param,'    "draw_bearing_supports",','    "draw_bearing_supports", "draw_profile", "draw_rise_m",')
rep(param,'    draw_bearing_supports: bool = field(default=False, kw_only=True)\n','    draw_bearing_supports: bool = field(default=False, kw_only=True)\n    # Optional closed-display rise. Exact height and joints are reconstructed.\n    draw_profile: str = field(default="flat", kw_only=True)\n    draw_rise_m: float = field(default=0.0, kw_only=True)\n')
rep(param,'        if not isinstance(self.draw_bearing_supports, bool):\n','''        if self.draw_profile not in DRAW_PROFILES:
            raise ParamError(f"draw_profile {self.draw_profile!r} not in {DRAW_PROFILES}")
        if (isinstance(self.draw_rise_m, bool)
                or not isinstance(self.draw_rise_m, (int, float))
                or not math.isfinite(self.draw_rise_m)):
            raise ParamError("draw_rise_m must be finite and numeric, not boolean")
        if self.draw_profile == "flat" and self.draw_rise_m != 0:
            raise ParamError("flat draw_profile requires zero draw_rise_m")
        if self.draw_profile == "peaked":
            if not self.draw_span_m:
                raise ParamError("peaked draw_profile requires a draw")
            if not 0 < self.draw_rise_m <= min(3.0, self.draw_span_m / 4.0):
                raise ParamError("draw_rise_m must be positive, <=3m and <=quarter draw span")
        if not isinstance(self.draw_bearing_supports, bool):
''')
rep(param,'        draw_bearing_supports=val("draw_bearing_supports", False),','        draw_bearing_supports=val("draw_bearing_supports", False),\n        draw_profile=val("draw_profile", "flat"),\n        draw_rise_m=val("draw_rise_m", 0.0),')
lo=hist.index('+def draw_rise_m_at(');hi=hist.index('--- a/chicago/4d/generators/archetypes/bridge_timber.py',lo)
funcs='\n'.join(line[1:] for line in hist[lo:hi].splitlines() if line.startswith('+'))+'\n';new[param]+='\n\n'+funcs
mesh=rels[1];rep(mesh,'from archetypes.bridge_timber_params import BridgeTimberParams  # noqa: E402','from archetypes.bridge_timber_params import BridgeTimberParams, draw_rise_m_at  # noqa: E402')
lo=hist.index('+def _draw_rise(');hi=hist.index(' def build(',lo)
helpers='\n'.join(line[1:] for line in hist[lo:hi].splitlines() if line.startswith('+'))+'\n'
rep(mesh,'\ndef build(params: BridgeTimberParams, name: str):','\n'+helpers+'\ndef build(params: BridgeTimberParams, name: str):')
rep(mesh,'    for xp in params.pier_x:\n        _pier(b, params, xp, bearing_z, c_pier)\n','    # Preserve the old default emission order; raised cribs stay horizontal.\n    if params.draw_profile == "flat":\n        for xp in params.pier_x:\n            _pier(b, params, xp, bearing_z, c_pier)\n')
rep(mesh,'    # The gallows frames over a draw. Their POSITIONS are documented','    _apply_draw_profile(b, params)\n    if params.draw_profile != "flat":\n        for xp in params.pier_x:\n            _pier(b, params, xp, bearing_z, c_pier)\n\n    # The gallows frames over a draw. Their POSITIONS are documented')
rep(mesh,'(mid, y, deck_z + LEAF_PROUD_M * 0.5),','(mid, y, deck_z + LEAF_PROUD_M * 0.5 + _draw_rise(p, mid)),')
rep(mesh,'    The deck boards are untouched and run straight through, so the crossing stays as\n    walkable as it was — `_deck` never learns there is a draw. What is added is the','    The boards run through the draw. The optional display profile folds these\n    faces afterward; the same pure function supplies the nominal floor sidecar.\n    What is added here is the')
compile=rels[2];lo=hist.index('+def walk_surface_profile(structure:');hi=hist.index(' def walk_passages(',lo);func='\n'.join(line[1:] for line in hist[lo:hi].splitlines() if line.startswith('+'))+'\n'
rep(compile,'\ndef walk_passages(structure: dict, phase: dict):','\n'+func+'\ndef walk_passages(structure: dict, phase: dict):')
rep(compile,'                "walk_surface_m": walk_surface_m(st, phase),','                "walk_surface_m": walk_surface_m(st, phase),\n                **({"walk_surface_profile": profile}\n                   if (profile := walk_surface_profile(st, phase)) is not None else {}),')
# Apply exact historical consumer hunks, preserving all current surrounding bytes.
def apply_historical(rel):
 marker='--- a/chicago/4d/'+rel+'\n';start=hist.index(marker);end=hist.find('\n--- ',start+1);section=hist[start:] if end<0 else hist[start:end]
 for block in re.split(r'^@@[^\n]*\n',section,flags=re.M)[1:]:
  lines=block.splitlines(True);before=''.join(l[1:] for l in lines if l.startswith((' ','-')));after=''.join(l[1:] for l in lines if l.startswith((' ','+')))
  if before and new[rel].count(before)==1:new[rel]=new[rel].replace(before,after)
  elif after and new[rel].count(after)==1:pass
  else:raise AssertionError(('historical hunk context drift',rel,before[:100]))
for rel in ['tools/measure_anchors.mjs','renderers/web/js/walker.js','renderers/web/js/route.js','renderers/web/js/humans.js']:apply_historical(rel)
main='renderers/web/js/main.js';rep(main,"import { createWalker, footprintsFrom, decksFrom, WALK } from './walker.js';","import { createWalker, footprintsFrom, decksFrom, WALK } from './walker.js';\nimport { profiledGroundHeight } from './deck-surface.js';")
rep(main,"    people, terrain, tier: detailLevel, problems: layerProblems('humans'),","    people, terrain, tier: detailLevel, problems: layerProblems('humans'),\n    groundHeight: (e, n) => profiledGroundHeight(terrain, decks, e, n),")
record='data/structures/dearborn_street_drawbridge.json';r=json.loads(new[record]);form=r['phases'][0]['form'];form['draw_profile']={'value':'peaked','confidence':'inferred','sources':['andreas_1884_dearborn_drawbridge_plate'],'note':'The retrospective Andreas 1884 p. 631 plate shows a central rise in the closed draw and boarded parapet. This supports qualitative form, not a surveyed profile, a geographic coordinate or an attested operating mechanism. The exact rise and folded timber joints are separately reconstructed. The same native pure profile drives the mesh and nominal walk surface.'};form['draw_rise_m']={'value':1.2,'confidence':'reconstructed','note':'A reconstructed 1.2 m rise at the closed-draw centre, tapering to zero at the existing draw endpoints. It is a visual trial bounded by the pictured rise, not a metric camera measurement: the existing provisional camera reaches a principal-point bound. Original whole-picture acceptance remains open. Preserve the 18.288 m draw, geographic placement, flat approaches and vertical gallows.'}
anchor='\n      },\n      "change_note"';extra={k:form[k] for k in ['draw_profile','draw_rise_m']};lines=json.dumps(extra,indent=2,ensure_ascii=False).splitlines()[1:-1];encoded='\n'.join('      '+line for line in lines);rep(record,anchor,',\n'+encoded+anchor);assert json.loads(new[record])==r
contract='''\n\n## Optional span walk-surface profile (T-2375)\n\nA water-anchored bridge may carry `placement.walk_surface_profile =\n{"version":1,"axis":"local_x","stations_m":[[x,z],...]}`. The pure archetype\nfunction that displaces the closed-draw mesh writes the same local-span stations\nand heights above its water anchor. Existing scalar-only sidecars and flat\ndefaults omit this field and retain their old behavior.\n\nVersion1 stations increase strictly from x=0 to the footprint's maximum x.\nTheir first/last heights equal `walk_surface_m`; all values/transforms are finite.\nThis bounded closed-rise profile permits heights from the base through base+3m.\nMalformed declarations refuse instead of silently flattening. The sampler\nreturns null outside the local span; callers retain polygon-covering, highest\ndeck, water and land rules. Walker, router grid/exact queries, offered-anchor\nreadings and human root placement consume this same numeric sampler.\n\nThe Dearborn profile is a nominal plank-top proxy: it bridges 8mm board gaps and\nomits 55mm proud thresholds. It is not a topmost-any-mesh raycast, continuous\nwood coverage, shoe/IK/wheel or whole-body contact certificate. Geometry and\nprofile choices are reconstructed display form, not an operating historic draw.\n\nThis contract alone grants no static prop, vehicle or horse placement on a\nsloped span. Before adoption, verify current whole emitted yard/asset extents\nclear the changed polygon and bind those finite scene inputs. Future overlapping\nplacements require a qualified contact model. No horse, parked-transport or\nyard runtime architecture changes are included by this profile feature.\n'''
new['docs/GLB-CONTRACT.md']+=contract
for rel in rels:
 for part,data in [('before',old[rel]),('candidate',new[rel].encode())]:
  p=out/part/'chicago/4d'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
(out/'LIBERTY-APPEND.md').write_text((crib/'LIBERTY-APPEND.md').read_text()+'''\n\n### L-dearborn-closed-rise-2375 — The closed draw's central rise\n\n**Covers:** `dearborn_street_drawbridge.draw_1834.form.draw_rise_m`.\n**Decision:** A visible central rise follows the retrospective Andreas 1884\np.631 plate as inferred form. An exact 1.2m peak, the two linear slopes and\nfolded/split timber joints are reconstructed; they are not measured from the\nprovisional camera or established by a contemporary specification.\n**Limits:** The text-derived draw span, footprint, geographical placement and\napproach heights remain. Cribs stay horizontal; gallows remain vertical with\nlevel heads. This is a closed display, not a hoisted or animated mechanism.\nThe nominal floor bridges board gaps and omits proud thresholds; no foot,\nwheel or whole-body contact precision follows. Whole-picture acceptance,\nmechanism attribution, gallows/trestle fit and camera calibration remain open.\n**Ticket:** T-2375.\n**Recorded:** 2026-10-29.\n''')
(out/'CONTRACT-APPEND.md').write_text(contract)
assert all((root/rel).read_bytes()==b for rel,b in old.items())
bind={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'UNADOPTED_EXTERNAL_SOURCE_IMPLEMENTATION','preimages':{k:hashlib.sha256(v).hexdigest() for k,v in old.items()},'postimages':{k:hashlib.sha256(v.encode()).hexdigest() for k,v in new.items()},'liberty_append_only':True,'no_canonical_source_edits_claim_exports_browser':True,'historical_geometry':'H4 split-and-fold mesh helper plus horizontal crib order, shared pure profile and chain attachment. No global horse/yard/parked/refusal architecture.'};(out/'SOURCE-BINDINGS.json').write_text(json.dumps(bind,indent=2)+'\n')
print('prepared',len(rels),'existing paths; numeric helper added separately')
