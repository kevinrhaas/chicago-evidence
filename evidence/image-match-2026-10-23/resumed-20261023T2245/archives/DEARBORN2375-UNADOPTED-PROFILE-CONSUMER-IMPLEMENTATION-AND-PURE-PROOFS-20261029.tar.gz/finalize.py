from pathlib import Path
import json,hashlib,difflib,subprocess,shutil,datetime,ast
out=Path(__file__).resolve().parent;root=Path('/workspace/chicago/chicago/4d');rel='data/reconstruction/name_pool_keys.json';before=(root/rel).read_bytes();r=json.loads(before);keys=['phases[].form.draw_bearing_supports.note','phases[].form.draw_profile.note','phases[].form.draw_rise_m.note'];assert not any(k in r['read']['structures'] for k in keys)
anchor='\n    ],\n    "households"';s=before.decode();assert s.count(anchor)==1;extra=',\n'+',\n'.join('      '+json.dumps(k) for k in keys);s=s.replace(anchor,extra+anchor)
r['read']['structures']+=keys;assert json.loads(s)==r
for part,b in [('before',before),('candidate',s.encode())]:
 p=out/part/'chicago/4d'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
source={};diff=[];syntax=[]
for p in sorted((out/'candidate').rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(out/'candidate'));b=out/'before'/rel;old=b.read_bytes() if b.exists() else b'';new=p.read_bytes()
 source[rel]={'pre_sha256':hashlib.sha256(old).hexdigest() if b.exists() else None,'post_sha256':hashlib.sha256(new).hexdigest(),'before_bytes':len(old),'after_bytes':len(new)}
 if p.suffix=='.py':ast.parse(new);syntax.append({'path':rel,'python_AST':'PASS'})
 if p.suffix=='.js':
  run=subprocess.run(['node','--check',str(p)],capture_output=True,text=True);assert run.returncode==0,run.stderr;syntax.append({'path':rel,'node_syntax':'PASS'})
 diff.append(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel if b.exists() else '/dev/null',tofile='b/'+rel)))
patch=out/'MINIMAL-PROFILE.patch';patch.write_text(''.join(diff))
# Bounded disposable file fixture only; no Git repo/worktree or canonical writes.
replay=out/'replay-fixture';assert not replay.exists();shutil.copytree(out/'before',replay)
check=subprocess.run(['git','apply','--check',str(patch)],cwd=replay,capture_output=True,text=True);assert check.returncode==0,check.stderr
apply=subprocess.run(['git','apply',str(patch)],cwd=replay,capture_output=True,text=True);assert apply.returncode==0,apply.stderr
for rel,row in source.items():assert hashlib.sha256((replay/rel).read_bytes()).hexdigest()==row['post_sha256'],rel
shutil.rmtree(replay)
assert (root/'data/reconstruction/name_pool_keys.json').read_bytes()==before
(out/'POSTIMAGES-AND-REPLAY.json').write_text(json.dumps({'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SOURCE_PATCH_REPLAY_PASS_UNADOPTED','paths':source,'syntax':syntax,'patch_check_and_exact_replay':True,'no_Git_repository_or_canonical_write':True,'liberty_append_separate_preserve_current_prefix':True,'name_pool_three_reader_paths_entrywise_added':keys},indent=2)+'\n');print(len(source),'sourcepaths exactreplay/syntaxPASS')
