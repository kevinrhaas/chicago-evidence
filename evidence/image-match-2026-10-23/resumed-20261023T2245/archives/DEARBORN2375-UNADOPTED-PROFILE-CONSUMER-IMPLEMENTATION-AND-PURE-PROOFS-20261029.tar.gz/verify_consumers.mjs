import assert from 'node:assert/strict';
import fs from 'node:fs';
import { register } from 'node:module';
import { pathToFileURL, fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
const out=fileURLToPath(new URL('.',import.meta.url));
const root='/workspace/chicago/chicago/4d/';
const candidate=out+'candidate/chicago/4d/';
const before=out+'before/chicago/4d/';
const vendor=pathToFileURL(root+'renderers/web/vendor/three-0.185.1/').href;
fs.writeFileSync(out+'resolved-dependencies.jsonl','');
register(`data:text/javascript,${encodeURIComponent(`import fs from 'node:fs';import crypto from 'node:crypto';import {fileURLToPath,pathToFileURL} from 'node:url';
function track(r){if(r.url.startsWith('file:')){const p=fileURLToPath(r.url);if(fs.existsSync(p)&&fs.statSync(p).isFile())fs.appendFileSync(${JSON.stringify(out+'resolved-dependencies.jsonl')},JSON.stringify({path:p,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')})+'\\n');}return r;}
export async function resolve(s,c,next){
 if(s==='three')return track({url:'${vendor}three.module.js',shortCircuit:true});
 if(s.startsWith('three/addons/'))return track({url:'${vendor}addons/'+s.slice(13),shortCircuit:true});
 if((s.startsWith('./')||s.startsWith('../'))&&c.parentURL?.startsWith('file:')){
  const u=new URL(s,c.parentURL),p=fileURLToPath(u);
  for(const prefix of [${JSON.stringify(candidate)},${JSON.stringify(before)}])if(p.startsWith(prefix)&&!fs.existsSync(p))return track({url:pathToFileURL(${JSON.stringify(root)}+p.slice(prefix.length)).href,shortCircuit:true});
 }
 return track(await next(s,c));
}`)}`,import.meta.url);
const imp=path=>import(pathToFileURL(path));
const THREE=await import('three');
const newer=await imp(candidate+'renderers/web/js/walker.js');
const older=await imp(before+'renderers/web/js/walker.js');
const route=await imp(candidate+'renderers/web/js/route.js');
const oldRoute=await imp(before+'renderers/web/js/route.js');
const human=await imp(candidate+'renderers/web/js/humans.js');
const helper=await imp(candidate+'renderers/web/js/deck-surface.js');
const {createIntent}=await imp(root+'renderers/web/js/controls/intent.js');
const {deckFromSidecar,deckHeightAt,profiledGroundHeight}=helper;
const fixture=JSON.parse(fs.readFileSync(out+'NATIVE-PROFILE-FIXTURE.json'));
const profiled=structuredClone(fixture.sidecar);profiled.placement.walk_surface_profile=fixture.profile;
const profileside=structuredClone(profiled);profileside.placement.local_e=0;profileside.placement.local_n=0;profileside.placement.rotation_deg=0;
const reg=side=>new Map([[side.id,{id:side.id,sidecar:side}]]);
const oldside=fixture.sidecar;
const flatDeck=newer.decksFrom(reg(oldside));assert.deepEqual(flatDeck,older.decksFrom(reg(oldside)));
const deck=deckFromSidecar('fixture',profileside), nativeRotated=deckFromSidecar('actual',profiled);
const base=2.22, span=76.33, centre=38.165, lo=29.021, hi=47.309;
const expected=x=> x<=lo||x>=hi ? base : base+1.2*(1-Math.abs(x-centre)/9.144);
const world=(deck,x,y=1.524)=>{const f=deck.profileFrame;return [f.e0+x*f.cos+y*f.sin,f.n0-x*f.sin+y*f.cos];};
let meshSamples=0;
for(const sample of fixture.physical_samples){
 const point=world(nativeRotated,sample.x);
 assert(Math.abs(deckHeightAt(nativeRotated,...point)-sample.mesh_deck_top)<1e-11);
 meshSamples++;
}
assert.equal(deckHeightAt(deck,-1,1.524),null);assert.equal(deckHeightAt(deck,span+1,1.524),null);
const terrain={heightfield:{loaded:true,widthM:100,depthM:20,originE:-10,originN:-10},
 surfaceHeight:(e,n)=>e>0&&e<span ? -2 : base,
 walkHeight:(e,n)=>e>0&&e<span ? 4 : base,
 isWater:(e,n)=>e>0&&e<span};
const w=newer.createWalker({camera:new THREE.PerspectiveCamera(),terrain,decks:[deck]});
for(const x of [.001,lo,centre,hi,span-.001])assert(Math.abs(w.surfaceAt(x,1.524)-expected(x))<1e-12);
const upper={id:'upper',y:4,pts:deck.pts};
const over=newer.createWalker({camera:new THREE.PerspectiveCamera(),terrain,decks:[deck,upper]});assert.equal(over.surfaceAt(centre,1.524),4);
const land={...terrain,surfaceHeight:()=>4,isWater:()=>false,walkHeight:()=>4};
const landWalk=newer.createWalker({camera:new THREE.PerspectiveCamera(),terrain:land,decks:[deck]});assert.equal(landWalk.surfaceAt(centre,1.524),4);
// Native update/step logic walks both slopes and approaches, not just helper queries.
const traverse=newer.createWalker({camera:new THREE.PerspectiveCamera(),terrain,decks:[deck],spawn:{local_e:-.1,local_n:1.524,yaw_deg:90}});
const intent=createIntent();let walking=0,maxWalkResidual=0,maxWalkHeight=-Infinity;
for(let i=0;i<2200;i++){
 intent.forward=1;traverse.update(1/60,intent);
 const {e,n,groundY}=traverse.state;
 if(e>0&&e<span){maxWalkResidual=Math.max(maxWalkResidual,Math.abs(groundY-expected(e)));maxWalkHeight=Math.max(maxWalkHeight,groundY);walking++;assert.equal(traverse.state.blocked,false);}
 if(e>span+.1)break;
}
assert(traverse.state.e>span+.1,'native walker reaches opposite bank');assert(maxWalkHeight>3.41);assert(maxWalkResidual<1e-10);
// Native route fallback grid and exact/string-pull each must use profile height.
const r=route.createRouter({terrain,decks:[deck],cell:1});r.warm();
const through=r.plan({e:.5,n:1.524},{e:span-.5,n:1.524});assert(through,'route crosses span');
assert(r.clearSegment(lo+.1,1.524,hi-.1,1.524),'exact string-pull crosses both slopes');
assert(!r.clearSegment(lo+.1,5,hi-.1,5),'water beside deck remains impassable');
let gridResidual=0;
const bounds=r.bounds;for(let x=lo+1;x<hi-1;x+=1){
 const cx=bounds.e0+(Math.floor((x-bounds.e0)/r.cell)+.5)*r.cell;
 gridResidual=Math.max(gridResidual,Math.abs(r.heightAt(x,1.524)-expected(cx)));
}
assert(gridResidual<3e-7,'fallback grid samples profile, not scalarbase');
// Counterexample: exact queries must reject an impossible step even when scalar base is unchanged.
const spikeSide=structuredClone(profileside);
spikeSide.placement.walk_surface_profile.stations_m=[[0,base],[29,base],[29.1,base+2.9],[29.2,base],[span,base]];
const spikeDeck=deckFromSidecar('spike',spikeSide);
const spikeRoute=route.createRouter({terrain,decks:[spikeDeck],cell:1});
const oldSpike=oldRoute.createRouter({terrain,decks:[spikeDeck],cell:1});
assert.equal(spikeRoute.clearSegment(29,1.524,29.1,1.524),false);
assert.equal(oldSpike.clearSegment(29,1.524,29.1,1.524),true,'old scalar-only exact query misses an unwalkable rise');
const callbackRoute=route.createRouter({terrain,decks:[deck],surfaceAt:w.surfaceAt,cell:1});
for(const x of [30,34,38,42,46])assert.equal(callbackRoute.heightAt(x,1.524),r.heightAt(x,1.524));
// Scalar-deck route fixtures retain exact native old/new results.
const flatSide=structuredClone(profileside);delete flatSide.placement.walk_surface_profile;
const scalar=newer.decksFrom(reg(flatSide));
const rf=route.createRouter({terrain,decks:scalar,cell:1}),ro=oldRoute.createRouter({terrain,decks:scalar,cell:1});
assert.deepEqual(rf.plan({e:.5,n:1.524},{e:span-.5,n:1.524}),ro.plan({e:.5,n:1.524},{e:span-.5,n:1.524}));
for(const x of [1,lo,centre,hi,75])assert.equal(rf.heightAt(x,1.524),ro.heightAt(x,1.524));
// The actual mount's groundHeight option reaches native HumanActor.place/walk.
const layer=await human.mountHumans({terrain,groundHeight:(e,n)=>profiledGroundHeight(terrain,[deck],e,n),assets:{},dataBase:null});
const actor=layer.add({id:'fixture_bridge_root',person_id:'fixture_person',placement:{local_e:lo,local_n:1.524,heading_deg:90},behaviour:{state:'walking',route:[{local_e:hi,local_n:1.524}]}});
let humanResidual=0;
for(let i=0;i<200;i++){actor.walk(.05);humanResidual=Math.max(humanResidual,Math.abs(actor.position.y-expected(actor.e)));}
assert(humanResidual<1e-11);assert(actor.e>centre);
assert.equal(profiledGroundHeight(terrain,[deck],-5,1.524),terrain.surfaceHeight(-5,1.524));
assert.equal(profiledGroundHeight(land,[deck],centre,1.524),4);
const defaultLayer=await human.mountHumans({terrain,assets:{},dataBase:null});
const defaultActor=defaultLayer.add({id:'fixture_legacy_root',person_id:'fixture_legacy_person',placement:{local_e:centre,local_n:1.524,heading_deg:90}});assert.equal(defaultActor.position.y,terrain.surfaceHeight(centre,1.524));
layer.dispose();defaultLayer.dispose();
// Isolate the exact anchor helper to avoid invoking the tool's top-level full-scene writer/reader.
const anchorSource=fs.readFileSync(candidate+'tools/measure_anchors.mjs','utf8');
const anchorText=anchorSource.match(/export function anchorDeckHeight\(row, e, n\) \{[\s\S]*?\n\}/)[0].replace('export ','');
const anchor=new Function('deckHeightAt',`return (${anchorText})`)(deckHeightAt);
assert.equal(anchor({walk_surface_m:base},centre,1.524),base);assert.equal(anchor({deck_surface:deck},centre,1.524),3.42);
const refusals=[];
function bad(name,change){const side=structuredClone(profileside);change(side);assert.throws(()=>deckFromSidecar('invalid',side));refusals.push(name);}
bad('wrong axis',s=>s.placement.walk_surface_profile.axis='local_y');
bad('unsorted',s=>s.placement.walk_surface_profile.stations_m.reverse());
bad('duplicate station',s=>s.placement.walk_surface_profile.stations_m[2]=s.placement.walk_surface_profile.stations_m[1]);
bad('NaNheight',s=>s.placement.walk_surface_profile.stations_m[2][1]=NaN);
bad('booleanheight',s=>s.placement.walk_surface_profile.stations_m[2][1]=true);
bad('endpointdifferent',s=>s.placement.walk_surface_profile.stations_m[0][1]=3);
bad('wrongspan',s=>s.placement.walk_surface_profile.stations_m.at(-1)[0]=77);
bad('excessrise',s=>s.placement.walk_surface_profile.stations_m[2][1]=6);
bad('belowbase',s=>s.placement.walk_surface_profile.stations_m[2][1]=2);
bad('nonwater',s=>s.placement.vertical_anchor='terrain');
bad('badframe',s=>s.placement.local_e=Infinity);
bad('badfootprint',s=>s.footprint.polygon[2][0]=Infinity);
bad('extraneousfield',s=>s.placement.walk_surface_profile.horse='override');
const result={status:'PASS_BOUND_NODE_CONSUMERS_ONLY',mesh_deck_samples_shared_by_native_producer_and_JS:meshSamples,actual_native_walker_steps_on_span:walking,max_native_walker_floor_residual_m:maxWalkResidual,max_native_walker_floor_m:maxWalkHeight,actual_native_route_crossing:true,actual_native_route_grid_residual_m:gridResidual,actual_native_route_exact_and_offdeck_water_controls:true,actual_native_route_steep_step_regression_old_scalar_misses:true,actual_native_route_walker_callback_grid_equal:true,actual_native_human_mount_and_root_route_residual_m:humanResidual,legacy_scalar_deck_descriptors_and_native_route_results_exact:true,legacy_human_default_unchanged:true,isolated_exact_anchor_helper:true,malformed_declarations_refused:refusals,scope:'Bounded Node fixture uses real native walker/router/human classes and actual vendorThree with module resolution only; no browser/GLB/export/nativewholetool/actualterrain/wholeyardclearance/wholepicture or fullgate acceptance.'};
const dependencies=new Map();
for(const line of fs.readFileSync(out+'resolved-dependencies.jsonl','utf8').trim().split('\n')){
 const row=JSON.parse(line);if(dependencies.has(row.path))assert.equal(dependencies.get(row.path),row.sha256);
 dependencies.set(row.path,row.sha256);assert.equal(crypto.createHash('sha256').update(fs.readFileSync(row.path)).digest('hex'),row.sha256);
}
fs.writeFileSync(out+'CONSUMER-DEPENDENCY-INPUTS.json',JSON.stringify({status:'ALL_EXECUTED_FILE_MODULES_HASH_EXACT_BEFORE_AFTER',files:[...dependencies].map(([path,sha256])=>({path,sha256}))},null,2)+'\n');
result.executed_file_module_bindings=dependencies.size;
fs.writeFileSync(out+'CONSUMER-PROOF.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
