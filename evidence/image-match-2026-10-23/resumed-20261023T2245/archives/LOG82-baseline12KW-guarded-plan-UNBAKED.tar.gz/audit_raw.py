"""Light copied-module/raw audit only. No Blender/browser/canonical writes."""
from pathlib import Path
from types import ModuleType
from dataclasses import asdict
import argparse,hashlib,inspect,json,subprocess,sys,shutil

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
CURRENT=ROOT/'current'
FROZEN=Path('/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final')
parser=argparse.ArgumentParser()
parser.add_argument('--producer-root',default='/tmp/chicago-next-model/T-2386-door-log-relief-next/runs/20261023-141756-738729/after')
parser.add_argument('--school-root',default='/tmp/chicago-next-model/T-2372-door-recess-next/runs/20261023-224621-281228/after')
parser.add_argument('--report',default='raw-audit.json')
args=parser.parse_args()
LATEST=Path(args.producer_root)
SCHOOL=Path(args.school_root)
DEV='5f15de2ba89a9aeef602b01462c0c688fe27280e'
for label,p in [('tested-producer',LATEST),('tested-school-producer',SCHOOL)]:
 for f in ['log_dwelling.py','log_dwelling_params.py']:
  dest=ROOT/label/f
  dest.parent.mkdir(parents=True,exist_ok=True)
  shutil.copy2(p/'generators/archetypes'/f,dest)
sys.path.insert(0,str(CURRENT/'generators'))
sys.modules['bpy']=ModuleType('bpy')
def load(name,path):
 m=ModuleType(name);m.__file__=str(path);sys.modules[name]=m
 exec(compile(path.read_text(),str(path),'exec'),m.__dict__)
 return m
oldparams=load('current_log_params',CURRENT/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=oldparams
before=load('current_log',CURRENT/'generators/archetypes/log_dwelling.py')
newparams=load('proposed_log_params',LATEST/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=newparams
after=load('proposed_log',LATEST/'generators/archetypes/log_dwelling.py')
schoolparams=load('school_log_params',SCHOOL/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=schoolparams
schoolmodule=load('school_log',SCHOOL/'generators/archetypes/log_dwelling.py')
sys.modules['archetypes.log_dwelling_params']=newparams
from common.mesh import MeshBuilder
class Raw(MeshBuilder):
 def to_object(self,mats=None):self.materials=mats;return self
for m in [before,after,schoolmodule]:
 m.MeshBuilder=Raw;m.simple_material=lambda *a,**kw:(a,kw)
def raw(obj):return obj.verts,obj.faces,obj.conf,obj.mat_index,obj.named,obj.materials
def digest(obj):return hashlib.sha256(json.dumps(raw(obj),sort_keys=True).encode()).hexdigest()
old_sig=inspect.signature(oldparams.LogDwellingParams)
new_sig=inspect.signature(newparams.LogDwellingParams)
extra={k:v.default for k,v in new_sig.parameters.items() if k not in old_sig.parameters}
assert [v for k,v in new_sig.parameters.items() if k not in extra]==list(old_sig.parameters.values())
assert all(new_sig.parameters[k].kind==inspect.Parameter.KEYWORD_ONLY for k in extra)
manifest=json.loads((CURRENT/'assets/manifest.json').read_text())['assets']
oldscope=json.loads((FROZEN/'freshness-scope.json').read_text())['assets']
scope=json.loads((ROOT/'full-family-enumeration.json').read_text())[DEV]['assets']
scope_ids={r['structure_id'] for r in scope}
current_assets={k:v for k,v in manifest.items() if v.get('structure_id') in scope_ids}
assert set(current_assets)=={r['asset'] for r in scope},'full-family scope changed'
assert {r['asset'] for r in oldscope}<set(current_assets),'old81 are not a strict subset of current82'
defaults=[]
for row in scope:
 sid=row['structure_id'];record=json.loads((CURRENT/f'data/structures/{sid}.json').read_text())
 phase=next(p for p in record['phases'] if p['id']==row['phase_id'])
 a=oldparams.from_phase(phase,record);b=newparams.from_phase(phase,record)
 fields=asdict(b)
 for k,v in extra.items():assert fields.pop(k)==v,(sid,k)
 assert fields==asdict(a),sid+' old resolved fields changed'
 name=Path(row['asset']).stem
 x,y=before.build(a,name),after.build(b,name)
 assert raw(x)==raw(y),sid+' default raw geometry/material/confidence changed'
 asset_bytes=subprocess.check_output(['git','-C','/workspace/chicago','show',DEV+':chicago/4d/assets/gltf/'+row['asset']])
 defaults.append({'asset':row['asset'],'structure_id':sid,'phase_id':row['phase_id'],'canonical_master_sha256':hashlib.sha256(asset_bytes).hexdigest(),'raw_sha256':digest(y)})

schoolrecord=json.loads((SCHOOL/'data/structures/chappel_infant_school.json').read_text())
phase=next(p for p in schoolrecord['phases'] if p['id']=='log_1833')
x=schoolmodule.build(schoolparams.from_phase(phase,schoolrecord),'chappel_infant_school__log_1833')
y=after.build(newparams.from_phase(phase,schoolrecord),'chappel_infant_school__log_1833')
assert raw(x)==raw(y),'Wolf latest module altered school recess trial'

report={'dev':DEV,'status':'PASS','current_family_assets':len(defaults),'default_raw_geometry_material_confidence_parity':len(defaults),'legacy_parameter_signature_exact':True,'new_keyword_only_defaults':extra,'current_merged_hogan_unchanged_by_new_module_defaults':True,'school_actual_selected_output_raw_exact':True,'school_selected_raw_triangles':sum(len(f)-2 for f in y.faces),'tested_producer_root':str(LATEST),'school_tested_producer_root':str(SCHOOL),'limits':'Pure Python raw audit only, using actual official asset keys. No Blender/export/web derivatives, canonical changes, fullgate or accepted matches. Any later code/opt-in modification requires this audit rerun.','defaults':defaults}
(ROOT/args.report).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='defaults'},indent=2))
