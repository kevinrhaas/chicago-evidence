

## Future log picture-controls increment

Compound parts build the already reconstructed centre/wings/tails polygon rather
than its bounding box. Wau-Bun supports composition, not the exact plan/roof.
Dimensions, openings, intersections and stack positions remain reconstructed;
partial siding, 1835 survival and the tiny panorama subject remain unresolved.
The original T-2374 image match remains open.
