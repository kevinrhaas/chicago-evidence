"""Prepare guarded authored-data candidates; never touches a checkout."""
from pathlib import Path
import copy,difflib,hashlib,json,re
import jsonschema
from visitor_text import fields as plain_fields

ROOT=Path(__file__).resolve().parent
CURRENT=ROOT/'current'
OUT=ROOT/'candidate-authored'
FROZEN=Path('/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final/review-tree/chicago/4d')
SCHOOL=Path('/tmp/chicago-next-model/T-2372-front-gable-next-20261023/runs/20261023-225301-130616/after')
WOLF=Path('/tmp/chicago-next-model/T-2386-door-log-relief-next/runs/20261023-141756-738729/after')
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
changes=[]
def diffs(a,b,path=''):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict):
  out=[]
  for key in sorted(set(a)|set(b)):
   ptr=path+'/'+key.replace('~','~0').replace('/','~1')
   if key not in a:out.append({'op':'add','path':ptr,'value':b[key]})
   elif key not in b:out.append({'op':'remove','path':ptr,'old_value':a[key]})
   else:out+=diffs(a[key],b[key],ptr)
  return out
 if isinstance(a,list) and isinstance(b,list) and path=='/phases':
  assert [v['id'] for v in a]==[v['id'] for v in b]
  return [item for i,(x,y) in enumerate(zip(a,b)) for item in diffs(x,y,path+'/'+str(i))]
 return [{'op':'replace','path':path,'old_value':a,'value':b}]
def put(rel,new):
 oldpath=CURRENT/rel;old=oldpath.read_bytes() if oldpath.exists() else None
 new=plain_fields(new,json.loads(old) if old is not None else None)
 b=json.dumps(new,indent=2,ensure_ascii=True).encode()+b'\n'
 target=OUT/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 changes.append({'path':rel,'expected_current_sha256':sha(old) if old is not None else None,'candidate_sha256':sha(b),'field_changes':diffs(json.loads(old),new) if old is not None else [{'op':'add','path':'','value':new}]})

records={}
for sid,root in [('chappel_infant_school',SCHOOL),('cobweb_castle',FROZEN),('miller_house',FROZEN),('philo_carpenter_log_shop',FROZEN),('wolf_point_tavern',WOLF)]:
 rel=f'data/structures/{sid}.json';record=load(root/rel)
 jsonschema.validate(record,load(CURRENT/'data/structures.schema.json'))
 records[sid]=record;put(rel,record)
assert 'hogan_store' not in records

old=load(CURRENT/'data/sources/eliza_chappel_school_shore_view.json')
schoolsource=load(SCHOOL/'data/sources/eliza_chappel_school_shore_view.json')
assert all(old[k]==schoolsource[k] for k in set(old)-{'note','what_it_supplies'})
for sid,root in [('eliza_chappel_school_shore_view',SCHOOL),('blanchard_shober_1867_wolf_point',WOLF)]:
 rel=f'data/sources/{sid}.json';source=load(root/rel);jsonschema.validate(source,load(CURRENT/'data/source.schema.json'));put(rel,source)

grades=load(CURRENT/'data/structure_grades.json');beforegrades=copy.deepcopy(grades)
old=load(Path('/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final/baseline/chicago/4d/data/structure_grades.json'))
new=load(FROZEN/'data/structure_grades.json')
for row in new['pictured']:
 if row in old['pictured']:continue
 if row not in grades['pictured']:
  assert not any(r['scene']==row['scene'] and r['structure']==row['structure'] for r in grades['pictured']),row
  grades['pictured'].append(row)
assert all(row in grades['pictured'] for row in beforegrades['pictured'])
put('data/structure_grades.json',grades)

def leaves(obj,path=''):
 if isinstance(obj,dict):
  for key,value in obj.items():yield from leaves(value,path+'.'+key if path else key)
 elif isinstance(obj,list):
  for value in obj:yield from leaves(value,path+'[]')
 elif isinstance(obj,str):yield path,obj
pool=load(CURRENT/'data/reconstruction/name_pool_keys.json')
declared=set(pool['read']['structures'])|set(pool['ignored']['structures'])
added=sorted({path for r in records.values() for path,value in leaves(r) if re.search(r'\b[A-Z][a-z]{2,}\b',value) and path not in declared})
assert all(path.endswith('.note') for path in added),added
pool['read']['structures']+=added
put('data/reconstruction/name_pool_keys.json',pool)

ledger={'base_dev':'5f15de2ba89a9aeef602b01462c0c688fe27280e','scope':'Five visible model record opt-ins only; current Hogan and every other record excluded. Exact current hash guard required before applying; on drift rebase field-by-field and retain independent work.','changed_files':changes,'added_structure_note_reader_paths':added,'current_source_rights_and_attribution_exact':True,'new_grade_rows':[r for r in grades['pictured'] if r not in beforegrades['pictured']],'new_gable_actual':'fe73a03a135811179b47ac603bf4169b35d1b0cc8b8d595d144885053189a8d8','pending':'Wolf roof relief not yet composed; parent owns liberty parser/Covers/native regeneration/82 official bake/consumer/app/gates. No acceptance enrolled.'}
(ROOT/'minimal-field-deltas.json').write_text(json.dumps(ledger,indent=2)+'\n')
patch=''
for row in changes:
 p=CURRENT/row['path'];a=p.read_text() if p.exists() else '';b=(OUT/row['path']).read_text()
 patch+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/chicago/4d/'+row['path'] if p.exists() else '/dev/null',tofile='b/chicago/4d/'+row['path']))
(ROOT/'authored-data.patch').write_text(patch)
print(json.dumps({'authored_data_files':len(changes),'five_records':list(records),'new_note_reader_paths':added,'grade_rows_added':len(ledger['new_grade_rows']),'source_rights_and_credits_preserved':True,'canonical_writes':False},indent=2))
