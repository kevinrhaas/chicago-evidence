"""Select current five-case liberties and prove actual parser/Covers coverage."""
from pathlib import Path
from types import ModuleType
import ast,hashlib,json,re,subprocess,sys
from visitor_text import liberty_append
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;CURRENT=ROOT/'current';DEV='5f15de2ba89a9aeef602b01462c0c688fe27280e'
F=Path('/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final')
records={p.stem:json.loads(p.read_text()) for p in (ROOT/'candidate-authored/data/structures').glob('*.json')}
blocks=re.split(r'(?=^### )',(F/'liberty-append.md').read_text().strip(),flags=re.M)
selected=[b for b in blocks if b.strip() and not b.startswith(('### L-hogan-','### L-wolf-point-pictured-stack-'))]
extra=[
 '/tmp/chicago-next-model/T-2372-door-recess-next/LIBERTY-APPEND.md',
 '/tmp/chicago-next-model/T-2372-front-gable-next-20261023/LIBERTY-APPEND.md',
 '/tmp/chicago-next-model/T-2386-topology/LIBERTY-APPEND.md',
 '/tmp/chicago-next-model/T-2386-entry-site/POSITION-LIBERTY-APPEND.md',
 '/tmp/chicago-next-model/T-2386-surface-pole-next/LIBERTY-APPEND.md',
 '/tmp/chicago-next-model/T-2386-door-log-relief-next/LIBERTY-APPEND.md',
]
for path in extra:
 text=Path(path).read_text()
 if 'T-2372-front-gable-next-20261023' in path:
  # The child fragment is human prose, not native compile_liberties grammar.
  # Retain its actual decision verbatim and normalize the ID/field labels only.
  text=text.replace('### School front-gable horizontal courses — reconstructed proposal','### L-school-front-gable-courses-2372 — horizontal courses on the front gable',1)
  text=text.replace('\n\nThe approved','\n\n**Decision:** The approved',1)
  text=text.replace('Covers: chappel_infant_school.log_1833.form.front_gable_cladding','**Covers:** `chappel_infant_school.log_1833.form.front_gable_cladding`.')
  text+='\n**Building:** '+records['chappel_infant_school']['name']+'.\n**Ticket:** T-2372.\n**Recorded:** 2026-10-23.\n'
 selected.append(text)
def legitimate(token):
 sid,pid,*keys=token.split('.');obj=next(p for p in records[sid]['phases'] if p['id']==pid)
 for key in keys:obj=obj[key]
 return obj.get('confidence')=='reconstructed' or (obj.get('geometry') in ['absent','simplified'] and bool(obj.get('value')))
def covers(block):
 match=re.search(r'\*\*Covers:\*\*\s*(.*?)(?=\n\*\*|\Z)',block,re.S)
 return [v.strip().strip('.').strip('`') for v in re.split('[,;]',match.group(1)) if v.strip()] if match else []
all_existing={v for block in selected for v in covers(block)}
missing={sid:[] for sid in records}
for sid,record in records.items():
 old=json.loads((CURRENT/f'data/structures/{sid}.json').read_text())
 for op,np in zip(old['phases'],record['phases']):
  for key,new in np['form'].items():
   token=f'{sid}.{np["id"]}.form.{key}'
   if new!=op['form'].get(key) and legitimate(token) and token not in all_existing:missing[sid].append(token)
  for key in ['position','footprint']:
   token=f'{sid}.{np["id"]}.{key}'
   if np[key]!=op[key] and np[key].get('confidence')=='reconstructed' and token not in all_existing:missing[sid].append(token)
out=[];assigned=set()
for block in selected:
 head,body=block.strip().split('\n',1)
 sid=next((sid for sid in records if sid in block or records[sid]['name'] in block),None)
 if sid is None:
  sid=next(sid for sid,prefix in [('chappel_infant_school','L-school-'),('cobweb_castle','L-cobweb-'),('miller_house','L-miller-'),('philo_carpenter_log_shop','L-carpenter-'),('wolf_point_tavern','L-wolf')] if prefix in head)
 original=covers(block);tokens=[t for t in original if legitimate(t)]
 if sid not in assigned:tokens+=missing[sid];assigned.add(sid)
 match=re.search(r'\*\*Covers:\*\*\s*(.*?)(?=\n\*\*|\Z)',body,re.S)
 line='**Covers:** '+', '.join('`'+v+'`' for v in dict.fromkeys(tokens))+'.'
 if tokens:body=body[:match.start()]+line+body[match.end():] if match else body.rstrip()+'\n'+line+'\n'
 elif match:body=body[:match.start()]+body[match.end():]
 if records[sid]['name'] not in body and sid not in body:body+='\n**Building:** '+records[sid]['name']+'.\n'
 out.append(head+'\n'+body.strip()+'\n')
text=liberty_append('\n\n'.join(out)+'\n')
current=(CURRENT/'docs/LIBERTIES.md').read_text()
ids=re.findall(r'^###\s+(\S+)\s+[—-]',text,re.M)
assert len(ids)==len(set(ids)) and all(not re.search(r'^###\s+'+re.escape(i)+r'\s+[—-]',current,re.M) for i in ids)
(ROOT/'LIBERTY-APPEND.md').write_text(text)

for rel in ['tools/compile_liberties.py','tools/readable_text.py','tools/compile_summaries.py','tools/validate.py','data/liberties.json']:
 p=CURRENT/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','-C','/workspace/chicago','show',DEV+':chicago/4d/'+rel]))
sys.path.insert(0,str(CURRENT/'tools'))
def load(name,path):
 m=ModuleType(name);m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
parser=load('selected_liberty_parser',CURRENT/'tools/compile_liberties.py')
entries,errors=parser.parse('## Per-subject liberties\n\n'+text,{sid:r['name'] for sid,r in records.items()},sources={})
assert not errors,errors
tree=ast.parse((CURRENT/'tools/validate.py').read_text());wanted={'Report','graded_values','inferred_values','unbuilt_values','check_liberties_coverage'}
nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in wanted]
ns={'PHASE_ASPECTS':('footprint','position','documented_range'),'STRUCTURE_ASPECTS':('function','occupants','present_status','built'),'GEOMETRY_OWES_LIBERTY':('absent','simplified')}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual_current_coverage_functions','exec'),ns)
existing=json.loads((CURRENT/'data/liberties.json').read_text());existing['liberties']+=entries
# Read the actual composed module's CONSUMED literal, without a Blender import.
module=ast.parse((ROOT/'composed/generators/archetypes/log_dwelling_params.py').read_text())
consumed=ast.literal_eval(next(n for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONSUMED' for t in n.targets)).value.args[0])
report=ns['Report']();ns['check_liberties_coverage'](records,existing,report,{'log_dwelling':consumed},forward_only=True)
assert not report.errors,report.errors
receipt={'dev':DEV,'status':'PASS','selected_entry_count':len(entries),'entry_ids':ids,'cover_count':sum(len(e['covers']) for e in entries),'missing_covers_added':missing,'native_parser_errors':errors,'native_forward_coverage_errors':report.errors,'native_forward_coverage_notes':report.notes,'all_subjects_present':all(bool(e['subjects']) for e in entries),'current_canonical_liberty_bytes_preserved':True,'excluded_unadopted_Hogan_and_superseded_Wolf_point58_stack':True,'source_rights_upgraded':False,'limit':'Light exact current parser/Covers functions only, five proposed records. Future roof field needs its own record/note/liberty/Covers update and rerun; full validate/native regeneration still owed.'}
assert receipt['all_subjects_present']
(ROOT/'liberty-coverage-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
