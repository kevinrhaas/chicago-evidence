"""Plain wording for new visitor prose only; preserve pre-existing source history."""
import copy

REPLACEMENTS={
 'front_door_state: recess':'a recessed front doorway',
 'compound_parts':'the connected room layout',
 'compound_joint':'the joined corner',
 'compound_wall_cladding':'the exterior wall covering',
 'compound_door_state':'the doorway treatment',
 'compound_log_profile':'the log-face relief',
 'compound_roof_overhang_m':'the roof overhang',
 'sign_pole_set_out':'the sign-pole placement',
 'roof_pipe':'the narrow roof projection',
 'roof_ridge_axis':'the roof direction',
 'frame_addition_cladding':"the addition's exterior covering",
 'front_door_state':'the front doorway',
 'front_gable_cladding':'the front-gable covering',
 'front_set_out':'the front opening arrangement',
 'front_shutters':'the front shutters',
 'ridge_stack_head_m':'the chimney height above the ridge',
 'ridge_stack_w_m':'the chimney section',
 'chimney_ridge_at':'the chimney position',
 'RELIEF_M':'shallow relief',
 'chappel_infant_school':'the former schoolhouse',
 'philo_carpenter_log_shop':"Carpenter's log shop",
 'wolf_point_tavern':'Wolf Point Tavern',
 'miller_house':'Miller House',
 'cobweb_castle':'Cobweb Castle',
 'drloih_beaubien':"the Illinois History Journal's Beaubien caption",
 'e1834_harbor_cut':'the committed 1834 harbor-cut river outline',
 'eliza_chappel_school_shore_view':'the attributed school-shore drawing',
 'blanchard_shober_1867_wolf_point':'the 1867 Wolf Point lithograph',
 'andreas_1884_sauganash_hotel_plate':'the Sauganash engraving published by Andreas in 1884',
 'kinzie_waubun_1856':'the 1856 Wau-Bun account',
 'chicago_wolf_point_1833_nypl':'the NYPL Wolf Point in 1833 image',
 'chicago_sauganash_hotel_1831':'the Sauganash Hotel in 1831 image',
}

def plain(text):
 for old,new in sorted(REPLACEMENTS.items(),key=lambda pair:-len(pair[0])):
  text=text.replace(old,new)
 return text

VISIBLE_KEYS={'note','research_note','what_it_supplies','what_it_does_not_supply','why'}
def fields(new,old=None,key=''):
 if isinstance(new,dict):
  return {k:fields(v,old.get(k) if isinstance(old,dict) else None,k) for k,v in new.items()}
 if isinstance(new,list):
  return [fields(v,old[i] if isinstance(old,list) and i<len(old) else None,key) for i,v in enumerate(new)]
 if isinstance(new,str) and key in VISIBLE_KEYS and new!=old:
  # An independently authored source-history span is never normalized.
  if isinstance(old,str) and old and old in new:
   prefix,suffix=new.split(old,1)
   return plain(prefix)+old+plain(suffix)
  return plain(new)
 return copy.deepcopy(new)

def liberty_append(text):
 lines=[]
 for line in text.splitlines(True):
  if line.startswith(('**Covers:**','**Source:**','**Sources:**','**Ticket:**','**Recorded:**')):
   lines.append(line)
  else:lines.append(plain(line))
 return ''.join(lines)
