from pathlib import Path
import datetime,hashlib,json,subprocess,os
r=Path('/tmp/chicago-green-tree-integration');h=Path('/workspace/T2376-wagon-bay-followthrough-20261026');c=Path('/workspace/shared/T2376-wagonbay-resume-closed-20261026');base='a575dddeed356333423b20361a1f90f3b39a862f';incoming='a9c5bd4a9715e4d5634c536d0efcd516ea9c3f01'
env=dict(os.environ);env['GIT_NO_LAZY_FETCH']='1'
def git(*args,check=True):
 p=subprocess.run(['git',*args],cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if check and p.returncode:raise RuntimeError((args,p.returncode,p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace')))
 return p
state=json.loads((h/'app-desktop-after-only-20261026T1236-status.json').read_text());assert state['all_children_reaped'] and state['command_exit'] is not None
assert git('rev-parse','HEAD').stdout.decode().strip()==base
assert git('rev-parse','origin/dev').stdout.decode().strip()==incoming
assert not git('diff','--name-only','--diff-filter=U').stdout.strip()
paths=json.loads((c/'STATE.json').read_text())['source_paths'];before={}
for p in paths:
 b=(r/p).read_bytes();assert b==(c/'source'/p).read_bytes(),p;before[p]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
oldbranch=git('branch','--show-current').stdout.decode().strip();assert oldbranch=='steward/t2376-green-tree-wagon-bay-front'
result=git('stash','push','-u','-m','checkpoint: T2376 wagonbay exact a575 source before current dev a9c5; not gated candidate codecommit')
(h/'private-a575-stash.log').write_bytes(result.stdout+result.stderr)
stash=git('rev-parse','refs/stash').stdout.decode().strip();assert git('rev-parse',stash+'^1').stdout.decode().strip()==base
preserved={}
for p in paths:
 q=git('cat-file','blob',stash+':'+p,check=False)
 if q.returncode:q=git('cat-file','blob',stash+'^3:'+p)
 assert len(q.stdout)==before[p]['bytes'] and hashlib.sha256(q.stdout).hexdigest()==before[p]['sha256'],p
 preserved[p]=before[p]
ref='refs/checkpoints/t2376-wagonbay-a575-before-a9c5-20261026';git('update-ref',ref,stash)
assert not git('status','--porcelain').stdout.strip()
git('switch','--no-track','-c','steward/t2376-green-tree-wagon-bay-a9c5',incoming)
assert git('rev-parse',oldbranch).stdout.decode().strip()==base
apply=git('stash','apply',stash,check=False);(h/'private-a575-stash-apply-to-a9c5.log').write_bytes(apply.stdout+apply.stderr)
conflicts=git('diff','--name-only','--diff-filter=U').stdout.decode().splitlines()
proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PRIVATE_ALL14_SOURCE_RECOVERY_VERIFIED_FRESH_A9C5_BRANCH_TRANSPLANT_STARTED_NOT_CODE_COMMIT','old_branch':oldbranch,'old_branch_head':base,'new_branch':'steward/t2376-green-tree-wagon-bay-a9c5','new_head':incoming,'private_stash':stash,'private_ref':ref,'all14_authored_and_native_candidate_files_exact_in_private_git':preserved,'immutable_closed_checkpoint_manifest':'568868470969f5675bebf88a570c1c597608117223a9487be90391ce262b98cf','stash_apply_exit':apply.returncode,'conflicts':conflicts,'native_owning_rebuild_check_and_fullgate':'OWED','app_worker_closed':state}
(h/'PRIVATE-A575-TO-A9C5-RECOVERY.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items()if k!='all14_authored_and_native_candidate_files_exact_in_private_git'},indent=2));assert apply.returncode in(0,1)
