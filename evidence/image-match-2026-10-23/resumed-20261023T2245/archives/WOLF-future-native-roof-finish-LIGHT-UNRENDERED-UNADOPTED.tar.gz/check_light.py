"""Pure current82 replay and image diagnostics; no Blender/browser/network."""
from pathlib import Path
from types import ModuleType
from dataclasses import asdict
import sys,json,hashlib,math
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'baseline/generators'));sys.modules['bpy']=ModuleType('bpy')
from archetypes import log_dwelling as build
from archetypes.log_dwelling_params import from_phase
from common.mesh import MeshBuilder
from common import materials
class Raw(MeshBuilder):
    def to_object(self,materials=None):self.materials=materials;return self
build.MeshBuilder=Raw;build.simple_material=lambda *a,**kw:(a,kw)
def raw(b):return b.verts,b.faces,b.conf,b.mat_index,b.named,b.materials
def mesh(b):return b.verts,b.faces,b.conf,b.mat_index,b.named
scope=json.loads((H/'scope82.json').read_text())
assert scope['log_assets']==scope['log_records']==82 and len(scope['assets'])==82
receipts=[]
for row in scope['assets']:
    rel=Path('data/structures')/(row['structure_id']+'.json')
    old=json.loads((H/'baseline'/rel).read_text())
    path=H/'candidate'/rel;new=json.loads(path.read_text()) if path.exists() else old
    p=next(p for p in old['phases'] if p['id']==row['phase_id'])
    q=next(p for p in new['phases'] if p['id']==row['phase_id'])
    a,b=from_phase(p,old),from_phase(q,new)
    before,after=build.build(a,Path(row['asset']).stem),build.build(b,Path(row['asset']).stem)
    assert mesh(before)==mesh(after),row
    if row['structure_id']=='wolf_point_tavern':
        assert a.roof_condition is None and b.roof_condition=='darkened'
        b.roof_condition=None
        assert b.confidence.pop('roof_condition')=='reconstructed'
        assert asdict(a)==asdict(b)
        assert raw(before)==raw(build.build(b,Path(row['asset']).stem))
        changed=[i for i,(x,y) in enumerate(zip(before.materials,after.materials)) if x!=y]
        assert changed==[build.M_ROOF]
        oldroof,newroof=before.materials[build.M_ROOF],after.materials[build.M_ROOF]
        assert oldroof[0][0]==newroof[0][0]=='roof_shingle'
        assert oldroof[1]==newroof[1]=={'roughness':0.9}
        assert oldroof[0][1]==materials.ROOF_DEFAULT.rgba
        assert newroof[0][1]==materials.ROOF_CONDITIONS['darkened'].rgba
        roof={'before':oldroof,'candidate':newroof,'triangles':sum(len(f)-2 for f in before.faces),'vertices':len(before.verts),'confidence':sorted(set(before.conf))}
        assert roof['triangles']==1730
        stripped=json.loads(json.dumps(new));del stripped['phases'][0]['form']['roof_condition'];assert stripped==old
    else:assert raw(before)==raw(after) and asdict(a)==asdict(b),row
    receipts.append({'asset':row['asset'],'raw_geometry_confidence_matindices_named_exact':True,'all_materials_exact':row['structure_id']!='wolf_point_tavern'})
import jsonschema
for kind,rel,schema in [('record','data/structures/wolf_point_tavern.json','structures.schema.json'),('source','data/sources/blanchard_shober_1867_wolf_point.json','source.schema.json')]:
    jsonschema.validate(json.loads((H/'candidate'/rel).read_text()),json.loads((H/'contracts'/schema).read_text()))
source=json.loads((H/'candidate/data/sources/blanchard_shober_1867_wolf_point.json').read_text())
oldsource=json.loads((H/'baseline/data/sources/blanchard_shober_1867_wolf_point.json').read_text())
assert source['rights_status']=='public_domain' and source['verified'] is True
assert source.pop('note').startswith(oldsource.pop('note')) and source==oldsource
from PIL import Image,ImageStat
regions=[(370,790,420,825)]
stats=[]
for box in regions:
    row={'box_xyxy_source_pixels':box}
    for name,path in [('source',H/'actual-before/nypl-full.jpg'),('actual_isolated_be265',H/'actual-before/render.png')]:
        image=Image.open(path).convert('RGB');assert image.size==(1920,1697)
        s=ImageStat.Stat(image.crop(box));row[name]={'mean_sRGB_8bit':s.mean,'stddev_sRGB_8bit':s.stddev,'sample_pixels':(box[2]-box[0])*(box[3]-box[1])}
    stats.append(row)
light=lambda c:sum(a*b for a,b in zip(c,[.2126,.7152,.0722]))
out={'status':'PASS_LIGHT_ONLY_UNRENDERED_UNADOPTED','scope':'closed T3081 current82 source packet; no new geometry or fields','assets':receipts,'default82_raw_material_confidence_exact_when_candidate_absent':True,'candidate82_raw_geometry_confidence_matindices_named_exact':True,'candidate_other81_all_materials_exact':True,'candidate_Wolf_only_roof_basecolour_changes':roof,'candidate_triangles_added':0,'candidate_material_slots_added':0,'stock_darkened_linear_luminance_ratio_to_default':light(materials.ROOF_CONDITIONS['darkened'].rgba)/light(materials.ROOF_DEFAULT.rgba),'image_diagnostics':stats,'diagnostic_limits':'Manually selected roof-interior rectangles shared by source and earlier actual isolated render; appearance diagnostics only. No calibrated illumination/reflectance inference or production texture sampling. Native relief not present in that earlier isolated render; stock-preset candidate has never been exported/rendered.','source_note_append_only_schema_rights':'PASS','generator_shared_material_renderer_edits':0,'rejected_40622_triangle_roof':'ABSENT; not recommended and not adopted'}
(H/'LIGHT-RECEIPT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('assets','image_diagnostics')},indent=2))
