# Wolf Point native roof finish — LIGHT future trial only

Status: **UNRENDERED, UNADOPTED.** This packet is outside canonical trees and
does not extend T3081. No Blender, browser, full gate, fetch, ticket write or
GitHub write ran for this parcel. The earlier40,622-triangle geometric roof is
**rejected, not recommended and absent here**. Original T2386 remains open.

## Concrete proposal

First inspect the existing be265 rounded-log/recess Wolf roof in the native app,
with its native normal/ORM maps proven bound. The earlier source-camera render
was an isolated `photo_match.mjs` scene, which does not import `roof-relief.js`.
It therefore did not demonstrate the roof finish visitors already receive.

If native baseline still needs a darker field, the two-file
`DATA-ONLY-UNRUN.patch` selects the existing per-phase `roof_condition=darkened`
stock preset for Wolf only and appends an honest source note. No new parameter,
generator/shared material/renderer edit, texture, UV or geometry is proposed.
The unnumbered liberty in `LIBERTY-DRAFT.md` is a future integration draft, not
a current canonical liberty. Its Covers path names Wolf only.

The stock name does not establish historical weather-blackening, pigment, age
or mending. It is explicitly a reconstructed appearance proxy for a dark field
in a retrospective print. Alternative `patched`/`fresh` stock names would add
unsupported histories and are not proposed. No source image is used as a
production texture. Stock linear basecolour changes from(.34,.30,.27) to
(75,64,55)/255; stock linear luminance is0.8409 of default. This modest change
may prove inadequate. Do not claim a match or read its multiplier from pixels.

## Existing native treatment

`native-inspection/roof-relief.js` binds `roof_shingle` to the existing procedural
`wood_shingles_weathered` normal_gl and packedORM maps. It binds no basecolour
map. It sets repeat wrapping, linear colour space and8x anisotropy. The shader
derives metric slope-aligned UVs from structure/world position and face normal,
using the library's4.48m span (32 reconstructed courses at0.14m exposure, L263).
L266's shingle substrate inference and L157's stock finish programme remain.
The existing library license and metadata are preserved; maps are original
procedural output, with confidence/provenance labels retained. Map hashes are
recorded in `native-map-inputs.json`; this packet does not vendor a whole app.

`buildings.js` applies relief before material grouping and carries colour per
instance. Keep `roof_shingle`,0.90 uniform roughness and map identity unchanged;
the existing roof batch then receives the colour without a new material bucket.
That is a code-path argument, not a measured future GPU receipt.

## LIGHT checks and input binding

`baseline/` copies the closed current82 producer and records from
`/tmp/log82-official-checkpoint-20261023T2335/tree/chicago/4d`, based on5f15de2.
It includes Ouilmette1812, school front-gable/dark-door refinement and the earlier
be265 Wolf surface controls. It does not restore the old81 fork or rejected roof.
`SOURCE-BINDING.json` binds copied generator/record bytes to that closed packet's
195-file official input manifest. Renderer inspection copies are separately
fingerprinted and are read-only evidence of the native code examined.

Run only the pure audit without a heavy slot:

```
python /tmp/chicago-next-model/T-2386-native-roof-finish-next-20261023/check_light.py
```

`LIGHT-RECEIPT.json` records all82 raw mesh/confidence/material-index/named-slot
streams exact under the data-only trial; the other81 material lists remain
exact. Removing Wolf's candidate condition reproduces all82 defaults/materials.
Wolf remains3382 raw vertices/1730 triangles, all confidence1; only its roof
basecolour changes, with zero added slots. Candidate record/source schemas and
append-only source metadata/cleared rights pass. No actual export is implied.

The actual earlier be265 master, source image, camera and rendered PNG are in
`actual-before/`. A manually selected roof-interior rectangle(370,790)-(420,825)
has source mean sRGB approximately(98,91,72) versus earlier isolated actual
(154,150,146). This diagnoses the displayed difference only; ink, paper,
lighting, tone mapping and camera prevent treating it as historical reflectance.
The native relief baseline and proposed stock finish have not been captured.

## Bounded next actual slot — requires parent grant

1. Bind the latest merged/current producer and canonical Wolf record to this
   closed packet with explicit differences reviewed; never apply an old tree.
   Keep the rejected geometry absent. Check current source/camera hashes and
   rights, current ticket ownership and any new family enumeration.
2. Capture baseline through the **native building loader**, using the governing
   source camera and identical lighting for the later candidate. Preserve the
   actual master/phase/recipe/texture hashes. Prove map loads succeeded, material
   is `roof_shingle`, chiRoofRelief metadata is present, metric-roof-uv-v2 is
   registered, chiRoofTileM=4.48 and normal/ORM samplers are bound. A stand-alone
   photo_match frame cannot substitute for this proof.
3. If still warranted, apply only the two-record-file patch in an isolated
   trial and perform **one official Wolf export plus web transform**, then one
   same-camera native candidate capture. No archetype changes/full82 bake are
   required by this data-only proposal; freshness checks still decide that.
4. Inspect full source/baseline/candidate and identical roof detail, then measure
   app/detail cost and inspect error logs. Report differs unless every visible
   requirement is met; all other pictures and contexts remain obligatory. Close
   browser/server processes and return the heavy slot. No second speculative
   preset, arbitrary global retune or geometric skin in that bounded slot.

No runnable capture harness is asserted here: the earlier harness intentionally
omits native treatment, and current native app assets/camera access must be bound
under a new explicit slot. This packet is ready for that bounded preparation,
not ready for canonical adoption or original-ticket completion.
