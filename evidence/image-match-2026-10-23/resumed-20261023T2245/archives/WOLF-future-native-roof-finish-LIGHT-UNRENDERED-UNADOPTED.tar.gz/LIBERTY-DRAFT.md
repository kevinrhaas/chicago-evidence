# Unnumbered future liberty draft — NOT CANONICAL, NOT RENDERED

**Decision:** Test only Wolf Point's existing `roof_condition=darkened` stock finish
as a reconstructed darker appearance proxy with the native app's existing metric
shingle relief. This selects a stock linear basecolour, not a weathering history.
It does not establish weather-blackening, age, pigment, mending, original timber
colour, individual shingle dimensions or an unchanged July1835 state. The source
is a retrospective coloured print. No source pixels enter a production texture.

**Covers:** `data/structures/wolf_point_tavern.json`.

**Evidence and limits:** `blanchard_shober_1867_wolf_point`, the independently
cleared1867 NYPL sheet depicting1833. Source roof reads a soft dark field. The
stock preset remains a renderer choice and is too small a change to promise a
match before actual review. L157's stock finish programme, L263's reconstructed
0.14m exposure/4.48m tile, and L266's inferred shingle substrate remain intact.
All source/date/rights limitations, camera, shape and other finishes stay exact.

**Cost:** No new triangles, vertices, UVs, materials, texture sheets or shader
variants. Existing `roof_shingle` name and0.90 uniform roughness stay exact. The
app already batches basecolour per instance. Actual app binding/performance
verification is still required; zero incremental source geometry is not proof
of GPU visual acceptance. The40,622-triangle geometry trial remains rejected.

**Resolve:** First capture native baseline with maps proven loaded/bound, then
compare this stock candidate at the same camera/lighting. Require full source
and roof detail review, identity/phase/recipe bindings, native actual map/frame
proof and all-picture acceptance before any completion claim. Do not append
this draft or its data patch to the current T3081 integration.
