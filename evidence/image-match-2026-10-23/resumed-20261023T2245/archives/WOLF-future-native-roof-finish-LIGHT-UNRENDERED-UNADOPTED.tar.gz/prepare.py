"""Make an isolated LIGHT future-trial packet; never touches a canonical tree."""
from pathlib import Path
import hashlib,json,shutil,difflib
H=Path(__file__).resolve().parent
S=Path('/tmp/log82-official-checkpoint-20261023T2335/tree/chicago/4d')
W=Path('/workspace/chicago/chicago/4d')
A=Path('/tmp/chicago-next-model/T-2386-door-log-relief-next/runs/20261023-141756-738729/after')
scope=json.loads(Path('/tmp/log82-root-inputs-20261023/full-family-enumeration.json').read_text())['5f15de2ba89a9aeef602b01462c0c688fe27280e']
def cp(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for p in (S/'generators').rglob('*.py'):cp(p,H/'baseline'/p.relative_to(S))
for row in scope['assets']:
    rel=Path('data/structures')/(row['structure_id']+'.json');cp(S/rel,H/'baseline'/rel)
rel=Path('data/sources/blanchard_shober_1867_wolf_point.json');cp(S/rel,H/'baseline'/rel)
(H/'scope82.json').write_text(json.dumps(scope,indent=2)+'\n')
for name in ('structures.schema.json','source.schema.json'):cp(W/'data'/name,H/'contracts'/name)
for name in ('roof-relief.js','buildings.js','batch-material.js','compact-attributes.js','facades.js'):
    cp(W/'renderers/web/js'/name,H/'native-inspection'/name)
T=W/'assets/textures/chicago_1835_pbr'
cp(T/'roofs/wood_shingles_weathered/material.json',H/'native-inspection/shingle-material.json')
cp(T/'LICENSE.txt',H/'native-inspection/texture-LICENSE.txt')
cp(W/'assets/LICENSES.md',H/'native-inspection/assets-LICENSES.md')
cp(A/'data/sources/assets/nypl-full.jpg',H/'actual-before/nypl-full.jpg')
cp(A/'assets/gltf/wolf_point_tavern__log_frame_1828.glb',H/'actual-before/be265-master.glb')
cp(A.parent/'reviews/after/render.png',H/'actual-before/render.png')
cp(A/'docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json',H/'actual-before/camera.json')
r=json.loads((H/'baseline/data/structures/wolf_point_tavern.json').read_text())
assert 'roof_condition' not in r['phases'][0]['form']
r['phases'][0]['form']['roof_condition']={
 'value':'darkened','confidence':'reconstructed','sources':['blanchard_shober_1867_wolf_point'],
 'note':"T-2386 LIGHT native-roof future trial: select the existing darkened stock finish solely as a bounded darker appearance proxy for the 1867 NYPL sheet's soft dark roof field. The stock preset's name is not evidence of weather-blackening, age, pigment, paint, original timber colour or mending. This retrospective printed colour is not a calibrated reflectance sample and does not attest an unchanged July 1835 finish. Keep roof_shingle substrate/name, uniform0.90 roughness, existing native metric shingle normal/ORM maps, 0.14m reconstructed library exposure (L263/L266), and all geometry/camera/other materials unchanged. No photograph is embedded or sampled into a production texture. This option is unrendered and may prove too slight; actual native baseline/preset comparison and all-picture acceptance remain owed. The rejected40,622-triangle roof skin stays absent."}
q=H/'candidate/data/structures/wolf_point_tavern.json';q.parent.mkdir(parents=True,exist_ok=True);q.write_text(json.dumps(r,indent=2)+'\n')
source=json.loads((H/'baseline'/rel).read_text())
source['note']+=" T-2386 native-roof finish study re-reads only the pictured soft dark roof field. It supports an appearance target, not measured pigment/reflectance, proven weathering, individual shingle dimensions or a historical mending claim. The proposed existing darkened stock preset and procedural roof relief remain reconstructed choices, pending an actual native-app comparison; no new geometry or source-derived texture is proposed."
q=H/'candidate'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(json.dumps(source,indent=2)+'\n')
patch=''
for rel in (Path('data/structures/wolf_point_tavern.json'),Path('data/sources/blanchard_shober_1867_wolf_point.json')):
    patch+=''.join(difflib.unified_diff((H/'baseline'/rel).read_text().splitlines(True),(H/'candidate'/rel).read_text().splitlines(True),fromfile='a/chicago/4d/'+str(rel),tofile='b/chicago/4d/'+str(rel)))
(H/'DATA-ONLY-UNRUN.patch').write_text(patch)
maps={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (T/'roofs/wood_shingles_weathered').iterdir() if p.is_file()}
(H/'native-map-inputs.json').write_text(json.dumps(maps,indent=2)+'\n')
print('Prepared isolated current82 producer/records and data-only future candidate; no canonical writes.')
