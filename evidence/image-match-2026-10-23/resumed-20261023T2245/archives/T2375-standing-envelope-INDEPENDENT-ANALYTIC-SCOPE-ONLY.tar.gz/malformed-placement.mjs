import fs from 'node:fs';
import * as THREE from 'three';
import {createStandingHorses as followup} from '/tmp/chicago-next-model/T-2375-standing-envelope-followup/candidate/chicago/4d/renderers/web/js/standing-horses.js';
import {createStandingHorses as originalNative} from '/workspace/chicago/chicago/4d/renderers/web/js/standing-horses.js';
const root='/workspace/chicago/chicago/4d/';
const original=JSON.parse(fs.readFileSync(root+'data/transport/parked/standing-horses.json'));
const saved=globalThis.fetch,rows=[];
try {
 for(const [version,createStandingHorses] of [['original-native-and-v2',originalNative],['envelope-followup',followup]])for(const [name,coordinates] of [['missing',undefined],['nonnumeric-string',['bad',0]]]){
  const manifest=structuredClone(original),row=manifest.scenes['1835'][0];
  if(coordinates===undefined)delete row.at_local_enu_m;else row.at_local_enu_m=coordinates;
  let requests=0;globalThis.fetch=async()=>{requests++;return{ok:true,json:async()=>manifest};};
  const problems=[],layer=await createStandingHorses({dataBase:new URL('file:///fixture/'),sceneId:'1835',groundHeight:()=>0,problems,placementEligibility:{assertTriangles(){throw Error('should not reach');}}});
  const camera=new THREE.PerspectiveCamera();camera.position.set(0,2,0);
  let thrown=null;try{layer.update(camera);await layer.ready;}catch(e){thrown={name:e.name,message:e.message};}
  rows.push({version,case:name,update_threw:thrown,recorded_problems:problems,requests,active:layer.instances.length});layer.dispose();
 }
}finally{globalThis.fetch=saved;}
console.log(JSON.stringify(rows,null,2));fs.writeFileSync(new URL('malformed-placement.json',import.meta.url),JSON.stringify(rows,null,2)+'\n');
