T-2375 optional native bridge-surface profile — CLOSED PROPOSAL, ADOPTION BLOCKED

The full previously rendered Dearborn candidate is preserved: boarded parapets,
reconstructed 1.2 m central rise and aligned bearing cribs. This package adds a
numeric optional sidecar profile and a shared native height sampler. It does not
adopt code/assets, claim tickets or accept an image match. Original T-2375 stays
open; every image verdict remains differs.

`combined-adoption.patch` is the complete proposal against the exact canonical
preimages enumerated in `preimages.json` (15 targets). It includes the earlier
keyword-only API fix, cleared Andreas 1884 p.631 source-prose correction, both
historical liberty fragments and four name-pool note readers. Alternatively apply
`/tmp/chicago-next-model/T-2375-adoption-kwonly/bridge-adoption.patch` followed by
`native-surface-overlay.patch`, after reviewing/recomposing the two shared
metadata preimages. Do not apply combined and overlay together. No patch is an
approved integration command while the blockers below remain.

The new `placement.walk_surface_profile` is absent for flat defaults. Version 1
uses local footprint x/metres and height/metres above the existing water anchor.
Dearborn's stations are 0:2.22, 29.021:2.22, 38.165:3.42, 47.309:2.22, 76.33:2.22.
The original scalar 2.22 is retained. Python mesh and sidecar share the same pure
profile function; walker, router grid/exactHeight, human root contact and anchor
report share the same JS sampler. Invalid declared profiles refuse explicitly.

Actual light verification:

- Six current default bridge raw geometry/material/confidence outputs and native
  compiler placement dicts remain exact. All 20 old positional parameter names,
  order, kinds, defaults/factories and match args remain exact; only the four new
  fields are keyword-only. All six master/web/recipe hashes are enumerated and
  unchanged, not regenerated.
- The corrected candidate's raw outputs equal the previously rendered v2 mesh:
  SHA256 8db45fe611fb6b25d59b9c80808858905ab8a1b201834f216b1dd58668df10d3.
  Seven actual generated board-triangle intersections at approaches, bearings,
  quarters and centre match the sampler within 1e-9 m. The centre is 3.42 m.
- Actual copied native walker/router and extracted exactHeight/anchor functions
  pass positive, flat-default, rotation, overlap/land-policy and invalid-profile
  controls. A dropped-profile mutation produces the old 1.2 m centre error.
- Actual native parked wheel, static support and tongue guards catch refused
  point contacts; a synthetic horse instance cleans up and its native outer catch
  records the refusal; yard buildItem/buildWagon refuse unsupported anchors before
  emitting. Finite outside-span controls succeed. See qualification limits below.
- Actual travel/router/walker/intent modules drive walk/run/horse/wagon CAMERA
  paces across the rise and arrive with finite sampled floors. These are not
  physical moving carriage, rider or animal models.
- Object.create wrapper retains inherited group/getter reads on frozen terrain.
  Its actual parked/yard consumers read surfaceHeight directly and no own-key,
  spread or has-own expectation was found. Flat inputs return the original
  terrain object/provider by identity.

FULL ADOPTION IS BLOCKED. `contact-receipt.json` reproduces an outside-anchor
counterexample: at E698.959078, N58.867584 a refined vehicle's wheel on the bridge
is refused and its native catch retains the legacy yard wagon. The native legacy
anchor guard accepts its outside anchor at -2 m. Executing its actual default body
builder up to the first primitive sink requests a floor box at -1.05 m whose
footprint overlaps a 3.418450 m bridge point. The sink is intercepted; no full mesh
or browser fallback render is claimed. Point NaN rejection is therefore NOT a
whole-placement refusal. Before adoption, legacy fallback/replacement ownership
and full multi-piece yard extents must be qualified or refused coherently while
preserving flat behavior. This package deliberately leaves that dependency open.
Real authored vehicle/horse assets, full async page handling, foot/body clearance,
all six official bakes/web derivatives, native derivation, supported full-scene
photo_match, app checks and full gates are also unrun here.

Current 1835 point inventory:5 parked centres,1418 yard anchors across all records,
1 static standing horse,1 shown standing human, and all scene anchors are off this
span. This is NOT an object-extent certificate or a reason to dismiss the blocker.
The horse is in the Western Hotel yard at [-127.5,-296], with riding, hitching and
walk/trot/gallop approval false. Current native travel modes are visitor-camera
paces; no moving physical carriage/rider implementation was found. Arbitrary
visitor destination routes may cross the span, so actual camera travel was tested.
See `current-path-inventory.json` for source hashes and scope.

Preserved visual evidence (not newly rendered):

- Full v2 actual isolated export/side-by-side:
  `/tmp/chicago-next-model/T-2375-next/preview/comparisons/andreas-provisional-side-by-side.jpg`.
  GLB path under that fixture is in preimages.json; SHA256 107b76243e85ccf10a980cc96a2aa18487a2345a5a5e45f1db00a310be452648.
  This is proposal-only pinned Blender 4.5.3 export and isolated comparison, not a
  supported official bake or accepted image gate. Its camera principal point
  reaches a bound (principal_x≈-2500, RMS≈10.75px, max≈20.58px), and the engraving's
  perspective/mechanism remain uncertain.
- Committed-before comparison:
  `/tmp/chicago-next-model/T-2375-next/preview/committed-before/andreas-committed-before-side-by-side.jpg`.
- Independently rendered smaller option is BOARDS ONLY, flat deck, original crib
  stations: `/tmp/chicago-next-model/T-2375/preview/comparisons/andreas-provisional-side-by-side.jpg`.
  Its GLB SHA256 8552ab10ecb1c201631a09ce1f512382000a22dea0982b076a1b73f6225bdc42.
  Board-plus-aligned-cribs without rise has never been rendered. The full rise has
  not been silently replaced by this option.

The source is retrospective Andreas 1884 vol.1 p.631, L. Braunhold del., independently
verified public-domain artwork. Baker-Co `dearborn_street_bridge_1834_engraving`
remains check_required and is not licensed as geometry by this proposal. No
borrowed image texture, new scene date, operating-lift mechanism or measured
metric rise is asserted. The source correction and liberties preserve these
limits; 1834 phase / 1 July 1835 scene dates remain unchanged.

Reproduce light controls only (do not rerun writers inside this closed package;
copy the directory to a new isolated path first):

    PYTHONPATH=/workspace/shared/python PYTHONDONTWRITEBYTECODE=1 python3 check_profile.py
    node --no-warnings --experimental-loader ./loader.mjs check_runtime.mjs
    node --no-warnings --experimental-loader ./loader.mjs check_contacts.mjs

`verify.py` is read-only and verifies the manifest, canonical/source/family guards
and patch application checks. `prepare.py` refuses to overwrite prepared snapshots.
The prior keyword-only package and all rendered/source-audit originals remain
immutable and are referenced by exact hashes. No external checkpoint/archive is
created here; parent owns adoption, follow-up scope and GitHub archival routing.
