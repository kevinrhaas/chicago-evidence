
## Optional span walk-surface profile

A water-anchored crossing may additionally declare
`placement.walk_surface_profile = {"version":1,"axis":"local_x","stations_m":[[x,z],...]}`.
Both coordinates are metres: `x` is the structure footprint's local polygon x;
`z` is height above the same water anchor as `walk_surface_m`. This is numeric
dataset geometry, not a camera, renderer object, mesh-material name or animation.
It is generated from the same pure archetype profile used by the deck builder.

The field is absent for flat defaults. Their existing scalar and placement output
stay unchanged. When present, the first station is at x=0, the last at the
footprint's maximum x; stations increase strictly and every coordinate is finite.
Both endpoint heights equal `walk_surface_m`, preserving this profile's approach
contact. Between stations height is linearly interpolated; there is no
extrapolation outside the declared span. This models the chosen closed-draw
display profile, not an operating lift or an attested historic mechanism.

Consumers transform ENU into the existing local footprint frame, sample the
profile, and retain the existing highest-deck, water and terrain policies. A
profile's scalar alone is not its interior floor. Walking, router grid/exact
checks and anchor reports share one sampler. Individual rigid vehicle, tongue, horse and
yard contacts lacking a profile-aware contact model return a non-finite height
on the occupied span, and their existing finite-height guards reject those
contacts. This proposal is NOT yet a whole-placement refusal contract: a rejected
refined vehicle can retain its legacy yard fallback, and an outside anchor can
allow that fallback or another multi-piece prop to extend onto the span. Full
adoption remains blocked until those extents/fallbacks are explicitly qualified
or refused. Human root contacts use the sampled surface; this does not certify
foot IK, body clearance or historical placement. Invalid declared profiles are
errors, never silently flattened.
