"""Read-only integrity, source/asset freshness and syntax checks; no native full gate."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=Path('/workspace/chicago');APP=ROOT/'chicago/4d'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
meta=json.loads((OUT/'preimages.json').read_text())
prior=Path(meta['prior_geometry_API_package'])
assert sha(prior/'MANIFEST.json')==meta['prior_manifest_sha256']
old=json.loads((prior/'inputs.json').read_text())
for path,expected in old['preimage_sha256'].items():
    rel=path.removeprefix('chicago/4d/')
    assert sha(ROOT/path)==meta['source_preimages'].get(rel,expected),path
for key in ['source_preimages','support_source_sha256']:
    for rel,expected in meta[key].items():assert sha(APP/rel)==expected,rel
for path,expected in meta['frozen_original_sha256'].items():assert sha(Path(path))==expected,path
for rel,expected in json.loads((OUT/'current-path-inventory.json').read_text())['source_sha256'].items():
    assert sha(APP/rel)==expected,rel
manifest=json.loads((APP/'assets/manifest.json').read_text())['assets']
for row in meta['six_bridge_family']:
    assert manifest[row['asset']]==row['master_preimage_manifest']
    assert sha(APP/'assets/gltf'/row['asset'])==row['master_sha256']
    assert sha(APP/'assets/web'/row['asset'])==row['web_sha256']
    assert sha(APP/'data/structures'/(row['structure_id']+'.json'))==row['record_sha256']
assert not(APP/meta['new_file']).exists()
assert (OUT/'deck-surface.js').read_bytes()==(OUT/'candidate/chicago/4d'/meta['new_file']).read_bytes()
assert (OUT/'candidate/chicago/4d/docs/GLB-CONTRACT.md').read_bytes()==(OUT/'baseline/chicago/4d/docs/GLB-CONTRACT.md').read_bytes()+(OUT/'CONTRACT-APPEND.md').read_bytes()
for p in (OUT/'candidate').rglob('*.py'):ast.parse(p.read_text(),str(p))
for suffix in ['*.js','*.mjs']:
    for p in (OUT/'candidate').rglob(suffix):subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
for name,cwd in [('combined-adoption.patch',ROOT),('native-surface-overlay.patch',OUT/'overlay-base')]:
    subprocess.run(['git','apply','--check',str(OUT/name)],cwd=cwd,check=True,capture_output=True)
for rel in ['cpu-receipt.json','runtime-receipt.json','contact-receipt.json']:
    receipt=json.loads((OUT/rel).read_text());assert receipt['status'].startswith('PASS')
contact=json.loads((OUT/'contact-receipt.json').read_text())
assert contact['full_adoption_blocked'] and contact['legacy_fallback_counterexample']['status']=='BLOCKED'
if (OUT/'MANIFEST.json').exists():
    entries=json.loads((OUT/'MANIFEST.json').read_text())['files']
    actual={str(p.relative_to(OUT))for p in OUT.rglob('*')if p.is_file() and p.name!='MANIFEST.json'}
    assert actual==set(entries),'Unexpected/missing package files'
    for rel,expected in entries.items():
        p=OUT/rel;assert p.stat().st_size==expected['bytes'] and sha(p)==expected['sha256'],rel
print('PASS read-only: source/helper/inventory/6-family/frozen-artifact guards; syntax; alternative patch checks. FULL ADOPTION BLOCKED by legacy fallback/prop extents; native/app/full gates remain unrun.')
