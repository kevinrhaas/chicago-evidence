/** Native refusal branches and active camera travel; synthetic CPU fixtures only. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { clone as cloneSkinned } from 'three/addons/utils/SkeletonUtils.js';
import { createParkedTransport } from '/workspace/chicago/chicago/4d/renderers/web/js/parked-transport.js';
import { createTravel } from '/workspace/chicago/chicago/4d/renderers/web/js/travel.js';
import { createIntent } from '/workspace/chicago/chicago/4d/renderers/web/js/controls/intent.js';
import { decksFrom, createWalker } from './candidate/chicago/4d/renderers/web/js/walker.js';
import { createRouter } from './candidate/chicago/4d/renderers/web/js/route.js';
import { refuseProfiledSupportTerrain, refuseProfiledSupportHeight, deckHeightAt, insideDeck } from './candidate/chicago/4d/renderers/web/js/deck-surface.js';
const root='/workspace/chicago/chicago/4d/';
const read=rel=>fs.readFileSync(new URL(rel,import.meta.url),'utf8');
const f=JSON.parse(read('fixture.json'));
const decks=decksFrom(new Map([['bridge',{id:'bridge',sidecar:f.profile_side}]]));
const centre=f.samples[3],e=centre.world_e,n=centre.world_n;
const marker={}, base=Object.freeze({group:marker,get heightfield(){return marker;},
  isWater:()=>true,surfaceHeight:()=>-2,walkHeight:()=>4});
const denied=refuseProfiledSupportTerrain(base,decks);
assert.equal(Object.getPrototypeOf(denied),base);
assert.equal(denied.group,marker);assert.equal(denied.heightfield,marker);
assert(Number.isNaN(denied.surfaceHeight(e,n)));
assert.equal(denied.surfaceHeight(e+1000,n+1000),-2);
for(const file of ['parked-transport.js','yard.js']){
  const source=fs.readFileSync(root+'renderers/web/js/'+file,'utf8');
  assert(!/Object\.(keys|values|entries)\(terrain|hasOwnProperty\([^)]*terrain|\.\.\.terrain/.test(source));
}
function tinyAsset(tongue=false){
  const group=new THREE.Group(),m=new THREE.Mesh(new THREE.BoxGeometry(.1,.1,.1),new THREE.MeshStandardMaterial());
  if(tongue)m.name='vehicle_tongue';group.add(m);return {scene:group};
}
const oldFetch=globalThis.fetch,oldLoad=GLTFLoader.prototype.loadAsync;
const cases=[];
try{
  for(const kind of ['wheel','support','tongue','anchor-outside-wheel-inside','flat-positive']){
    const outside=kind==='flat-positive';
    const row={id:kind,model:'test',name:'fixture',replaces:'legacy',at_local_enu_m:outside?[e+1000,n+1000]:kind==='anchor-outside-wheel-inside'?[e+1.7,n]:[e,n],bearing_deg:0,source_ids:[]};
    const spec={file:'fixture.glb',type:'fixture',basis:'CPU test asset',wheel_contacts_m:kind==='anchor-outside-wheel-inside'?[[1.7,0]]:kind==='wheel'||outside?[[0,0]]:[[100,100]]};
    if(kind==='support')spec.static_support_contacts_m=[[0,0,0]];
    globalThis.fetch=async url=>{assert(String(url).endsWith('transport/parked/placements.json'));return{ok:true,json:async()=>({models:{test:spec},scenes:{'1835':[row]}})};};
    GLTFLoader.prototype.loadAsync=async()=>tinyAsset(kind==='tongue');
    const problems=[];
    const layer=await createParkedTransport({dataBase:new URL('file:///synthetic/'),sceneId:'1835',terrain:denied,problems});
    if(outside){assert.equal(layer.instances.length,1);assert.equal(problems.length,0);}
    else{
      assert.equal(layer.instances.length,0);assert.equal(layer.group.children.length,0);
      assert.equal(problems.length,1);assert(problems[0].includes('existing yard vehicle retained'));
      assert(problems[0].includes(kind==='wheel'||kind==='anchor-outside-wheel-inside'?'No ground under all four wheels':kind==='support'?'No rendered ground under all static support contacts':'No terrain under parked tongue'));
    }
    cases.push({consumer:kind,instances:layer.instances.length,anchor:row.at_local_enu_m,problems});layer.dispose();
  }
}finally{globalThis.fetch=oldFetch;GLTFLoader.prototype.loadAsync=oldLoad;}

function nativeFunction(text,name){const a=text.indexOf('function '+name+'('),b=text.indexOf('\n}',a);assert(a>=0&&b>a);return text.slice(a,b+2);}
const yard=fs.readFileSync(root+'renderers/web/js/yard.js','utf8');
const groundAt=Function(nativeFunction(yard,'groundAt')+';return groundAt;')();
for(const name of ['buildItem','buildWagon']){
  const native=Function('groundAt',nativeFunction(yard,name)+';return '+name+';')(groundAt);
  const buf={pos:[]},problems=[],item={id:'unsupported',kind:'barrel',at_local_enu_m:[e,n]};
  assert.equal(native(buf,item,{},denied,1,problems,'fixture'),false);
  assert.equal(buf.pos.length,0);assert.equal(problems.length,1);
  cases.push({consumer:'yard '+name,returned:false,emitted_vertices:0,problems});
}
// A rejected replacement leaves its legacy wagon in place. The unchanged legacy
// guard tests only the anchor: this outside anchor passes even though the parked
// model's wheel at local[1.7,0] was just refused on the bridge. This is an adoption
// blocker, not proof of a safe whole-object refusal. Execute that exact guard.
const wagonText=nativeFunction(yard,'buildWagon');
const prefix=wagonText.slice(0,wagonText.indexOf('  const b ='));
assert(prefix.includes('const base = groundAt(terrain, at[0], at[1])'));
const wagonAnchorGuard=Function('groundAt',prefix+'return {base,continued:true};};return buildWagon;')(groundAt);
const fallbackAnchor=[e+1.7,n];
assert.equal(groundAt(denied,...fallbackAnchor),-2);
assert(Number.isNaN(denied.surfaceHeight(e,n)));
const legacyGuard=wagonAnchorGuard({}, {id:'legacy',at_local_enu_m:fallbackAnchor},{},denied,1,[]);
assert.deepEqual(legacyGuard,{base:-2,continued:true});
// Trace the actual next native body-emission request using native default form
// and native pushWagonBox. Stop at its first primitive sink: no complete mesh or
// real asset is invented. This proves a below-deck floor box is requested where
// the outside anchor permits overlap, rather than claiming hypothetical refusal.
const defaultForm=Function(nativeFunction(yard,'readForm')+';return readForm({});')();
const stopEmission={};let firstBox;
const box=Function('pushBox',nativeFunction(yard,'pushWagonBox')+';return pushWagonBox;')((...args)=>{firstBox=args;throw stopEmission;});
const legacyWagon=Function('groundAt','wagonCoat','pushWagonBox',wagonText+';return buildWagon;')(
  groundAt,()=>({body:[1,1,1],rng:()=>.5}),box);
try{legacyWagon({}, {id:'legacy',at_local_enu_m:fallbackAnchor,bearing_deg:0},defaultForm,denied,1,[]);assert.fail('Expected first-box interception');}
catch(error){assert.equal(error,stopEmission);}
const [,boxE,boxY,boxZ,fx,fz,halfL,halfW]=firstBox;
const crossingPoint=[boxE-halfW,-boxZ];
assert(insideDeck(...crossingPoint,decks[0].pts));
assert.equal(boxY,-2+defaultForm.wagonBedY);
assert(boxY<deckHeightAt(decks[0],...crossingPoint));
const bodyEmission={native_default_body_m:defaultForm.wagonBody,
  first_native_floor_box:{centre_EN_m:[boxE,-boxZ],y_m:boxY,half_length_m:halfL,half_width_m:halfW},
  overlapping_body_point_EN_m:crossingPoint,profile_height_at_point_m:deckHeightAt(decks[0],...crossingPoint),
  primitive_sink_intercepted:true,complete_mesh_built:false};
const fallbackBlocker={
  status:'BLOCKED',anchor_EN_m:fallbackAnchor,refused_wheel_EN_m:[e,n],
  native_parked_result:'0 refined instances; caught error explicitly retains existing yard vehicle',
  native_legacy_anchor_guard:legacyGuard,
  native_legacy_whole_geometry_executed:false,native_body_emission_request:bodyEmission,
  explanation:'Legacy buildWagon permits the outside anchor and the actual native default body builder requests its first floor box below the bridge at an overlapping point. Its primitive sink is intercepted; no full mesh or rendered fallback is claimed. Wheels/tongue also use that scalar base. Whole-object refusal is not established.',
  required_before_adoption:'Qualify/refuse every legacy fallback and multi-piece yard footprint crossing the profiled span, with actual emitted-geometry or whole-placement tests; preserve flat defaults.'
};
const horse=fs.readFileSync(root+'renderers/web/js/standing-horses.js','utf8');
const horseAssert=(value,message)=>{if(!value)throw Error(message);};
let cleaned=0;
const instantiate=Function('THREE','cloneSkinned','disposeSkeletons','assert','yawOf','card','createPlantedStandingHorseIdle',
  nativeFunction(horse,'instantiate')+';return instantiate;')(THREE,cloneSkinned,()=>cleaned++,horseAssert,b=>Math.PI-b*Math.PI/180,()=>({}),()=>{throw Error('Unexpected animation');});
const spec={material_variants:{source_native:{}},proposed_static_support_pose:{local_quaternion_xyzw:[0,0,0,1]},
  runtime_scale_m_per_unit:1,runtime_origin_m:[0,0,0],contacts:{hoof:{samples_m:[[0,0,0]],equal_10mm_slab_samples_m:[[0,0,0]]}}};
const row={id:'horse-fixture',material_variant:'source_native',bearing_deg:0,at_local_enu_m:[e,n],
  support_quaternion_xyzw:[0,0,0,1],support_limits:{maximum_per_hoof_minimum_gap_m:.03,minimum_sample_clearance_m:-.001}};
let horseError;
try{instantiate({scene:new THREE.Group()},spec,row,null,refuseProfiledSupportHeight(decks,()=>-2));}
catch(error){horseError=error;}
assert.match(horseError?.message,/No actual drawn yard base/);assert.equal(cleaned,1);
// The exact native outer catch records this error rather than letting load reject.
const catchText=horse.slice(horse.indexOf('        if (!disposed && mine === revision && error.name'),horse.indexOf('\n      } finally',horse.indexOf('        if (!disposed && mine === revision && error.name')));
const horseProblems=[];Function('error','disposed','mine','revision','problems',catchText)(horseError,false,1,1,horseProblems);
assert.equal(horseProblems.length,1);
const good=instantiate({scene:new THREE.Group()},spec,{...row,at_local_enu_m:[e+1000,n+1000]},null,refuseProfiledSupportHeight(decks,()=>-2));
assert.equal(good.group.position.y,-2);good.dispose();
cases.push({consumer:'horse contact',cleaned_invalid_clone:true,recorded_outer_catch:horseProblems,finite_control_root_y:-2});

// Active modes are visitor camera paces using this same walker, not moving rigid meshes.
const xs=decks[0].pts.map(p=>p[0]),ys=decks[0].pts.map(p=>p[1]);
const terrain={...base,heightfield:{loaded:true,originE:Math.min(...xs)-30,originN:Math.min(...ys)-30,
  widthM:Math.max(...xs)-Math.min(...xs)+60,depthM:Math.max(...ys)-Math.min(...ys)+60}};
const dynamic=[];
for(const mode of ['walk','run','horse','wagon']){
  const from=f.samples[2],to=f.samples[4],intent=createIntent(),camera=new THREE.PerspectiveCamera();
  const walker=createWalker({camera,terrain,decks,spawn:{local_e:from.world_e,local_n:from.world_n,yaw_deg:0}});
  const router=createRouter({terrain,decks,surfaceAt:(x,y)=>walker.surfaceAt(x,y),cell:1});
  const travel=createTravel({walker,intent,router,terrain,settings:{headBob:false,eyeHeight:1.68}});
  travel.setMode(mode);assert(travel.go({kind:'point',id:'end',e:to.world_e,n:to.world_n}));
  let steps=0,maxError=0,maxGround=-Infinity;
  for(;steps<4000&&travel.state.phase!=='idle';steps++){
    travel.update(1/30,intent);walker.update(1/30,intent);travel.afterWalk(intent,1/30);
    assert(Number.isFinite(walker.state.groundY));
    maxError=Math.max(maxError,Math.abs(walker.state.groundY-deckHeightAt(decks[0],walker.state.e,walker.state.n)));
    maxGround=Math.max(maxGround,walker.state.groundY);
  }
  assert.equal(travel.state.phase,'idle');assert(steps<4000);assert(maxError<1e-9);assert(maxGround>3.3);
  dynamic.push({mode,steps,max_floor_error_m:maxError,max_floor_m:maxGround,physical_vehicle_or_rider_mesh_tested:false});
}
const receipt={status:'PASS bounded controls; FULL ADOPTION BLOCKED',full_adoption_blocked:true,legacy_fallback_counterexample:fallbackBlocker,rigid_consumers:cases,dynamic_camera_travel:dynamic,
  terrain_wrapper:{frozen_input_and_inherited_getter_and_group_reads_pass:true,no_consumer_own_key_expectation_found:true},
  unresolved:['No browser/page or real authored vehicle/horse asset-load verification.','Concrete legacy fallback counterexample: rejected refined contact leaves legacy wagon eligible via outside anchor. Complex yard footprints/secondary pieces can also extend onto the span; whole-placement refusal unresolved.','No physical moving carriage/rider mesh implementation found in current renderer; future such models require independent contact qualification.'],
  limitations:'Actual placement/contact functions with synthetic assets/terrain and scoped fetch/loader stubs. Source outer horse catch exercised as a native code fragment, not a full real-asset async load.'};
fs.writeFileSync(new URL('contact-receipt.json',import.meta.url),JSON.stringify(receipt,null,2)+'\n');
console.log('PASS: actual parked wheel/support/tongue catches, yard early refusals, native horse contact/catch, wrapper properties and four dynamic camera paces; legacy fallback BLOCKER reproduced.');
