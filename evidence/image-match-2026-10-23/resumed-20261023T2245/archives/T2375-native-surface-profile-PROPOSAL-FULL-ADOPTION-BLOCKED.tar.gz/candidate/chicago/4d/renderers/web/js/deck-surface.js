/** Numeric, engine-neutral deck profiles. Flat decks retain their original shape. */
const EPS = 1e-8;
const finite = Number.isFinite;

export function insideDeck(e, n, pts) {
  let hit = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const [x, y] = pts[i], [a, b] = pts[j];
    if ((y > n) !== (b > n) && e < (a - x) * (n - y) / (b - y) + x) hit = !hit;
  }
  return hit;
}

export function validateSpanProfile(profile, base, poly) {
  const fail = () => { throw new Error('Invalid declared walk-surface span profile'); };
  if (!profile || profile.version !== 1 || profile.axis !== 'local_x'
      || !finite(base) || !Array.isArray(profile.stations_m) || profile.stations_m.length < 2) fail();
  const stations = profile.stations_m;
  let last = -Infinity;
  for (const p of stations) {
    if (!Array.isArray(p) || p.length !== 2 || !p.every(finite) || p[0] <= last) fail();
    last = p[0];
  }
  if (Math.abs(stations[0][0]) > EPS || !(last > 0)
      || Math.abs(stations[0][1] - base) > EPS || Math.abs(stations.at(-1)[1] - base) > EPS) fail();
  if (poly && (Math.abs(Math.min(...poly.map(p => p[0]))) > EPS
      || Math.abs(Math.max(...poly.map(p => p[0])) - last) > EPS)) fail();
  return profile;
}

export function deckFromSidecar(id, sidecar) {
  const p = sidecar?.placement ?? {}, h = p.walk_surface_m;
  if (p.walk_surface_profile != null && (typeof h !== 'number' || p.vertical_anchor !== 'water')) {
    throw new Error('Invalid declared profile: a numeric water-anchored surface is required');
  }
  if (typeof h !== 'number' || p.vertical_anchor !== 'water') return null;
  const raw = sidecar.footprint;
  const poly = Array.isArray(raw) ? raw : raw?.polygon;
  if (!Array.isArray(poly) || poly.length < 3) {
    if (p.walk_surface_profile != null) throw new Error('Invalid declared profile footprint');
    return null;
  }
  if (p.walk_surface_profile != null && poly.some(p => !Array.isArray(p) || p.length !== 2 || !p.every(finite))) {
    throw new Error('Invalid declared profile footprint');
  }
  const th = (p.rotation_deg ?? 0) * (Math.PI / 180);
  const cos = Math.cos(th), sin = Math.sin(th);
  const e0 = p.local_e ?? 0, n0 = p.local_n ?? 0;
  const deck = { id, y: h, pts: poly.map(([u, v]) => [e0 + u * cos + v * sin, n0 - u * sin + v * cos]) };
  if (p.walk_surface_profile != null) {
    deck.profile = validateSpanProfile(p.walk_surface_profile, h, poly);
    if (![e0, n0, th].every(finite)) throw new Error('Invalid profile coordinate frame');
    deck.profileFrame = { e0, n0, cos, sin };
  }
  return deck;
}

/** Point height above the water anchor. Callers retain their own covering/ground policy. */
export function deckHeightAt(deck, e, n) {
  if (!deck.profile) return deck.y;
  validateSpanProfile(deck.profile, deck.y);
  const f = deck.profileFrame;
  if (!f || ![e, n, f.e0, f.n0, f.cos, f.sin].every(finite)) throw new Error('Invalid profile sample frame');
  const x = (e - f.e0) * f.cos - (n - f.n0) * f.sin;
  const s = deck.profile.stations_m;
  if (x < -EPS || x > s.at(-1)[0] + EPS) return null;
  const u = Math.max(0, Math.min(s.at(-1)[0], x));
  for (let i = 1; i < s.length; i++) {
    if (u <= s[i][0]) {
      const [a, z] = s[i - 1], [b, w] = s[i];
      return z + (w - z) * ((u - a) / (b - a));
    }
  }
  return s.at(-1)[1];
}

export function profileDeckAt(decks, e, n) {
  return decks.find(d => d.profile && insideDeck(e, n, d.pts)) ?? null;
}

/** Humans use their existing root-contact sampler; outside a profile preserve terrain exactly. */
export function profiledGroundHeight(terrain, decks, e, n) {
  if (!profileDeckAt(decks, e, n)) return terrain.surfaceHeight(e, n);
  let height = null;
  for (const d of decks) {
    if (!insideDeck(e, n, d.pts)) continue;
    const y = deckHeightAt(d, e, n);
    if (typeof y === 'number' && (height === null || y > height)) height = y;
  }
  if (height === null) return terrain.surfaceHeight(e, n);
  return terrain.isWater(e, n) ? height : Math.max(height, terrain.surfaceHeight(e, n));
}

/** Unsupported rigid contacts are explicitly refused by existing finite-height guards.
 * Covers wheel/support/tongue and yard groundAt; never raises the terrain itself.
 */
export function refuseProfiledSupportHeight(decks, fallback) {
  if (!decks.some(d => d.profile)) return fallback;
  return (e, n, ...rest) => profileDeckAt(decks, e, n) ? NaN : fallback(e, n, ...rest);
}

export function refuseProfiledSupportTerrain(terrain, decks) {
  if (!decks.some(d => d.profile)) return terrain;
  return Object.create(terrain, { surfaceHeight: {
    value: refuseProfiledSupportHeight(decks, (e, n) => terrain.surfaceHeight(e, n)),
  } });
}
