Native consumer disposition (proposal paths under candidate/chicago/4d)

| Consumer | Proposed response | Actual light evidence / remaining limit |
|---|---|---|
| bridge_timber params/builder | One pure local-x rise owns generated boards and optional profile | Seven actual raw board-triangle hits; prior rendered full raw output exact |
| tools/compile_scene.py walk_surface_profile | Conditional engine-neutral metadata; scalar stays | Actual placement AST evaluation exact for all six flat sidecars; candidate station list positive |
| walker.js decksFrom/surfaceAt | Preserve frame/profile; shared point heights before existing highest deck/land policy | Actual native module floors and six flat object/floor controls |
| route.js grid / deckBoxes / exactHeight | Preserve profile in deckBoxes; sample grid and exact string-pull | Native planner crosses; private exactHeight executed; dropped metadata mutation detected |
| tools/measure_anchors.mjs | Optional descriptor and shared point sampler | Exact helper/native outline code extracted; full CLI not run |
| humans.js / main.js | Optional shared root-height provider; original terrain default | Actual HumanActor root samples 3.42; no foot IK/body or published asset acceptance |
| parked-transport.js wheels | NaN profile contacts caught before addition | Actual createParkedTransport API, synthetic asset: 0 instances, 1 caught problem; outside positive 1 instance |
| parked-transport.js static support | NaN sampled contacts caught | Same native API with wheels outside/support inside:0 instances, 1 caught problem |
| parked-transport.js lowered tongue | NaN terrain contact throws into parked catch | Actual native tongue branch and API:0 instances, 1 caught problem |
| standing-horses.js contact/outercatch | Refused hoof contact cleans clone; outer catch records error | Native instantiate with synthetic object/spec; exact native outercatch fragment executed, not real async asset load |
| yard.js groundAt/buildItem/buildWagon | Profile anchor ->null/false before geometry | Actual native functions: 0 vertices / 1 problem; outside anchor can still overlap span:BLOCKER |
| parked replacement + legacy yard fallback | Refined model refused; old wagon may be retained | Concrete native counterexample in contact-receipt.json; first native body primitive request crosses profile below boards; whole-placement refusal NOT satisfied |
| multi-piece yard goods/props | Point anchors refused; full secondary extents unqualified | Current point centres off span; not whole-object clearance:BLOCKER |
| travel.js walk/run/horse/wagon | All use visitor walker/router; profile floors | Actual createTravel simulation arrives all 4 modes, finite sampled floors; camera paces only, no physical moving meshes |
| generate_frontage_works.py LaSalle footway | Flat current AST/output unchanged; future profiled host explicitly refuses | Actual guardprefix positive/negative, prior rest of function AST exact; not an automatic curved footway rewrite |

Terrain wrapper: only parked and yard receive Object.create(terrain) with an own
surfaceHeight provider. Their current source references only direct calls to that
method; no own-key enumeration/spread assumptions were found. Current terrain
surfaceHeight closes over heightfield, not this. Frozen inherited descriptor and
getter/group reads pass. No profile => original object/provider identity. This
wrapper is not presented as a generic substitute for arbitrary future consumers.

Minimum unresolved dependency: placement-level support/overlap decision must also
control legacy replacement retention and every secondary yard piece. Either
sample/qualify real contact geometry over the profile or refuse the entire occupied
placement, including fallback. A NaN at one refined contact is insufficient. The
package does not broaden into a transport/prop rewrite without root review.
