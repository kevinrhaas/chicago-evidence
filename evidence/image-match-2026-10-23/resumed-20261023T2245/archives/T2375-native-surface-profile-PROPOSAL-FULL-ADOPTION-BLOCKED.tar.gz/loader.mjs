import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
const root = 'file:///workspace/chicago/chicago/4d/';
const own = new URL('./', import.meta.url).href;
export function resolve(specifier, context, nextResolve) {
  if (specifier === 'three') return { url: root + 'renderers/web/vendor/three-0.185.1/three.module.js', shortCircuit: true };
  if (specifier.startsWith('three/addons/')) return { url: root + 'renderers/web/vendor/three-0.185.1/addons/' + specifier.slice(13), shortCircuit: true };
  if (specifier.startsWith('.') && context.parentURL?.startsWith(own)) {
    const url = new URL(specifier, context.parentURL);
    if (url.protocol === 'file:' && !fs.existsSync(fileURLToPath(url))) {
      for (const area of ['candidate/chicago/4d/', 'baseline/chicago/4d/']) {
        const prefix = own + area;
        if (url.href.startsWith(prefix)) return { url: root + url.href.slice(prefix.length), shortCircuit: true };
      }
    }
  }
  return nextResolve(specifier, context);
}
