import os
os.sched_setaffinity(0,{1});os.nice(19)
import json,base64,hashlib,time,datetime
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError

out=Path('/tmp/green-tree-reference-image-host-publication-20261029')
src=Path('/tmp/green-tree-reference-image-host-20261029')
repo='kevinrhaas/chicago-images';apiroot='https://api.github.com/repos/'+repo+'/'
branch='steward/t2376-green-tree-picture-references-20261029'
sha=lambda b:hashlib.sha256(b).hexdigest()
gitsha=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def save(name,d):
    (out/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');return d
def api(path,data=None,method=None):
    req=Request(apiroot+path,data=None if data is None else json.dumps(data).encode(),headers={'User-Agent':'Chicago-Green-Tree-image-publisher','Accept':'application/vnd.github+json','Content-Type':'application/json'},method=method or('GET' if data is None else 'POST'))
    try:
        with urlopen(req,timeout=120) as r:return json.load(r)
    except HTTPError as e:
        print('API_ERROR',path,e.code,e.read(8192).decode(errors='replace'),flush=True);raise
def raw(head,path):
    with urlopen(Request('https://raw.githubusercontent.com/'+repo+'/'+head+'/'+path,headers={'User-Agent':'Chicago-Green-Tree-image-publisher'}),timeout=120) as r:
        assert r.status==200;return r.read()
author_manifest=json.loads((src/'MANIFEST.json').read_text())
for row in author_manifest.get('members',author_manifest.get('files',[])):
    p=Path(row['path']) if Path(row['path']).is_absolute() else src/row['path']
    b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
base=json.loads((src/'BASE-REF.json').read_text())['object']['sha']
assert api('git/ref/heads/main')['object']['sha']==base,'Main advanced; reprice and preserve before publishing'
basecommit=api('git/commits/'+base);baseentries=json.loads((src/'BASE-TREE.json').read_text())
assert not baseentries.get('truncated')
old={x['path']:(x['mode'],x['type'],x['sha']) for x in baseentries['tree'] if x['type']!='tree'}
changed={'prairie-1904/MANIFEST.json':(src/'MANIFEST-POSTIMAGE.json').read_bytes()}
for p in sorted((src/'native-store-scope/store/files').glob('*.jpg')):changed['prairie-1904/files/'+p.name]=p.read_bytes()
assert len(changed)==5 and all(p not in old for p in changed if p.endswith('.jpg'))
blobs={}
for path,b in changed.items():
    d=api('git/blobs',{'encoding':'base64','content':base64.b64encode(b).decode()});assert d['sha']==gitsha(b);blobs[path]=d['sha']
save('CREATED-BLOBS.json',blobs)
tree=save('CREATED-TREE.json',api('git/trees',{'base_tree':basecommit['tree']['sha'],'tree':[{'path':p,'mode':'100644','type':'blob','sha':blobs[p]} for p in changed]}))
entries=api('git/trees/'+tree['sha']+'?recursive=1');assert not entries.get('truncated')
new={x['path']:(x['mode'],x['type'],x['sha']) for x in entries['tree'] if x['type']!='tree'}
assert set(new)==set(old)|set(changed)
assert all(new[p]==v for p,v in old.items() if p not in changed)
assert all(new[p]==('100644','blob',blobs[p]) for p in changed)
save('ALL-PRIOR-PATHS-EXACT.json',{'status':'PASS','prior_paths':len(old),'changed':list(changed),'all_unrelated_entries_exact':True})
commit=save('CREATED-COMMIT.json',api('git/commits',{'message':'T-2376: Store the credited Green Tree picture references\n\nPreserve held Andreas1884 and Trowbridge1902 display JPEGs with native thumbnails and explicit source credits.\n\nCovers: T-2376','tree':tree['sha'],'parents':[base]}))
assert commit['tree']['sha']==tree['sha'] and [p['sha'] for p in commit['parents']]==[base]
assert api('git/ref/heads/main')['object']['sha']==base
ref=save('CREATED-BRANCH.json',api('git/refs',{'ref':'refs/heads/'+branch,'sha':commit['sha']}));assert ref['object']['sha']==commit['sha']
rows=[]
for path,b in changed.items():
    actual=raw(commit['sha'],path);assert actual==b
    rows.append({'path':path,'bytes':len(b),'sha256':sha(b),'git_blob':gitsha(b),'status':'PASS'})
save('HEAD-STRICT-READBACK.json',rows)
body='''Add display copies and native thumbnails for the Green Tree illustrations published in Andreas’s 1884 History of Chicago and Gale’s 1902 Reminiscences of Early Chicago and Vicinity. Both displays preserve the exact held JPEGs; source records retain publication credits, public-domain publication-age basis, and the drawings’ retrospective date and form limits.

Validation: native thumbnail generation and scoped manifest sync/check passed; all four JPEGs decode and display hashes equal the held originals. All 1,304 existing manifest rows and every unrelated repository path remain exact. Immutable branch readback verifies all five changed files. App/model adoption, camera interpretation and original T-2376 completion remain separate work.'''
(out/'PR-BODY.md').write_text(body+'\n')
pr=save('PR-CREATED.json',api('pulls',{'title':'T-2376: Add the credited Green Tree picture references','head':branch,'base':'main','body':body,'draft':False}))
assert pr['head']['sha']==commit['sha'] and pr['base']['ref']=='main'
for _ in range(15):
    current=api('pulls/'+str(pr['number']))
    save('PR-BEFORE-MERGE.json',current)
    assert current['head']['sha']==commit['sha'] and current['base']['sha']==base
    if current.get('mergeable') is True and current.get('mergeable_state')=='clean':break
    time.sleep(2)
else:raise RuntimeError('PR did not become clean; retained ready PR')
checks=save('HEAD-CHECKS.json',api('commits/'+commit['sha']+'/check-runs'))
assert all(x['status']=='completed' and x['conclusion'] in ('success','neutral','skipped') for x in checks.get('check_runs',[])), 'Checks not green yet'
status=save('HEAD-STATUS.json',api('commits/'+commit['sha']+'/status'))
assert status['total_count']==0 or status['state']=='success'
request={'sha':commit['sha'],'merge_method':'merge','commit_title':'T-2376: Add the credited Green Tree picture references (#'+str(pr['number'])+')'}
save('MERGE-REQUEST.json',request)
merged=save('MERGE-RESPONSE.json',api('pulls/'+str(pr['number'])+'/merge',request,'PUT'));assert merged.get('merged') is True
actual=save('PR-ACTUAL-MERGED.json',api('pulls/'+str(pr['number'])));assert actual['merged_at'] and actual['merge_commit_sha']==merged['sha']
mc=save('ACTUAL-MERGE-COMMIT.json',api('git/commits/'+merged['sha']));assert mc['tree']['sha']==tree['sha'] and [p['sha'] for p in mc['parents']]==[base,commit['sha']]
save('MERGE-VERIFIED.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','pr':actual['html_url'],'head':commit['sha'],'base':base,'merge':merged['sha'],'tree':tree['sha'],'actual_merged_at':actual['merged_at'],'all_prior_rows_exact':1304,'all_prior_unrelated_paths_exact':True,'standard_expected_head_merge':True,'app_source_written':False,'images_checkout_written':False})
print(json.dumps({'status':'MERGED','pr':actual['html_url'],'merge':merged['sha'],'head':commit['sha'],'tree':tree['sha']}),flush=True)
