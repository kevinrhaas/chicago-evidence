#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,os
p=argparse.ArgumentParser();p.add_argument('project_root',type=Path);p.add_argument('--apply',action='store_true');a=p.parse_args();packet=Path(__file__).resolve().parent;guards=json.loads((packet/'source-guards.json').read_text());dependencies=json.loads((packet/'dependency-guards.json').read_text());pending=[];receipt=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for rel,expected in dependencies.items():
 if sha(a.project_root/rel)!=expected:raise SystemExit('REFUSED changed dependency: '+rel)
for rel,g in guards.items():
 target=a.project_root/rel;candidate=packet/'candidate'/rel
 if sha(target)!=g['before_sha256']:raise SystemExit('REFUSED unknown source preimage: '+rel)
 if sha(candidate)!=g['after_sha256']:raise SystemExit('REFUSED changed candidate: '+rel)
 pending.append((target,candidate.read_bytes()));receipt.append({'path':rel,**g})
if a.apply:
 for target,data in pending:
  temp=target.with_name(target.name+'.shadow-ray.tmp')
  with temp.open('xb')as f:f.write(data)
  os.chmod(temp,target.stat().st_mode);os.replace(temp,target)
print(json.dumps({'status':'APPLIED'if a.apply else'PASS_READONLY_PREFLIGHT','files':receipt,'dependency_count':len(dependencies)},indent=2))
