from pathlib import Path
import hashlib,json,difflib
root=Path('/workspace/primary-human-runner-compat/chicago/4d');out=Path(__file__).resolve().parent
helper=r'''const DIRECTIONAL_SHADOW_CLASS = new THREE.DirectionalLight().shadow.constructor;
const STOCK_SHADOW = [THREE.ShaderChunk.shadowmap_vertex, THREE.ShaderChunk.shadowmap_pars_fragment];
/** Exact native directional PCF frame only; any unsupported state skips this phase. */
function shadowViewFrame(out, renderer, camera, shadowCamera, descriptor, batch) {
  try {
    const light = descriptor?.light?.(), map = light?.shadow?.map, depth = map?.depthTexture;
    if (descriptor?.fresh?.() !== true || renderer?.constructor !== THREE.WebGLRenderer
        || renderer.shadowMap?.enabled !== true || renderer.shadowMap.autoUpdate !== true
        || renderer.shadowMap.type !== THREE.PCFShadowMap || light?.constructor !== THREE.DirectionalLight
        || light.castShadow !== true || light.shadow?.constructor !== DIRECTIONAL_SHADOW_CLASS
        || light.shadow.autoUpdate !== true || light.shadow.camera !== shadowCamera
        || camera?.constructor !== THREE.PerspectiveCamera || camera.isArrayCamera
        || camera.coordinateSystem !== THREE.WebGLCoordinateSystem || camera.reversedDepth !== false
        || shadowCamera?.constructor !== THREE.OrthographicCamera || shadowCamera.view !== null
        || shadowCamera.zoom !== 1 || shadowCamera.coordinateSystem !== THREE.WebGLCoordinateSystem
        || shadowCamera.reversedDepth !== false || !finiteMatrix(camera.projectionMatrix)
        || !finiteMatrix(camera.matrixWorldInverse) || !affine(shadowCamera.matrixWorld)
        || !finiteMatrix(shadowCamera.matrixWorldInverse) || !batch.matrixWorld.equals(out.identity)
        || map?.samples !== 0 || !depth?.isDepthTexture || depth.type !== THREE.UnsignedIntType
        || depth.format !== THREE.DepthFormat || depth.minFilter !== THREE.LinearFilter
        || depth.magFilter !== THREE.LinearFilter || depth.compareFunction !== THREE.LessEqualCompare
        || depth.wrapS !== THREE.ClampToEdgeWrapping || depth.wrapT !== THREE.ClampToEdgeWrapping
        || STOCK_SHADOW[0] !== THREE.ShaderChunk.shadowmap_vertex
        || STOCK_SHADOW[1] !== THREE.ShaderChunk.shadowmap_pars_fragment) return null;
    const shadow = light.shadow, c = shadowCamera, w = shadow.mapSize.x, h = shadow.mapSize.y;
    const width = c.right - c.left, height = c.top - c.bottom, span = c.far - c.near;
    if (![w,h,width,height,span,c.near,shadow.bias,shadow.normalBias].every(Number.isFinite)
        || !Number.isInteger(w) || w < 1 || w !== h || map.width !== w || map.height !== h
        || depth.image?.width !== w || depth.image?.height !== h
        || width <= 0 || width !== height || span <= 0 || c.near <= 0 || shadow.radius !== 1
        || shadow.getFrameExtents().x !== 1 || shadow.getFrameExtents().y !== 1) return null;
    out.expected.copy(c.matrixWorld).invert();
    if (!out.expected.equals(c.matrixWorldInverse)) return null;
    out.expected.makeOrthographic(c.left,c.right,c.top,c.bottom,c.near,c.far,c.coordinateSystem,false);
    if (!out.expected.equals(c.projectionMatrix)) return null;
    out.clip.multiplyMatrices(c.projectionMatrix,c.matrixWorldInverse);
    out.expected.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1).multiply(out.clip);
    if (!out.expected.equals(shadow.matrix)) return null;
    const e = c.matrixWorld.elements;
    const xx=e[0]*e[0]+e[1]*e[1]+e[2]*e[2], yy=e[4]*e[4]+e[5]*e[5]+e[6]*e[6], zz=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];
    if (Math.max(Math.abs(xx-1),Math.abs(yy-1),Math.abs(zz-1),
        Math.abs(e[0]*e[4]+e[1]*e[5]+e[2]*e[6]),Math.abs(e[0]*e[8]+e[1]*e[9]+e[2]*e[10]),
        Math.abs(e[4]*e[8]+e[5]*e[9]+e[6]*e[10])) > 1e-12) return null;
    out.ray.set(-e[8],-e[9],-e[10]).normalize();
    // Native5-tap unit-radius PCF + linear compare footprint, normal bias,
    // normalized depth bias and a depth/numeric allowance; never reduce this.
    out.margin = 2*Math.SQRT2*(width/w) + Math.abs(shadow.normalBias)
      + Math.abs(shadow.bias)*span + 2**-23*span;
    out.clip.multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse);
    out.frustum.setFromProjectionMatrix(out.clip,camera.coordinateSystem,false);
    if (!Number.isFinite(out.margin) || out.frustum.planes.some(p=>![...p.normal.toArray(),p.constant].every(Number.isFinite))) return null;
    out.camera = shadowCamera; return out;
  } catch { return null; }
}
function shadowCannotReachView(frame, box) {
  for (const {normal:n,constant:d} of frame.frustum.planes) {
    // Strict angular fringe: an uncertain/parallel direction always keeps caster.
    if (n.dot(frame.ray) >= -1e-10) continue;
    const support=d+n.x*(n.x>=0?box.max.x:box.min.x)+n.y*(n.y>=0?box.max.y:box.min.y)+n.z*(n.z>=0?box.max.z:box.min.z);
    if (Number.isFinite(support) && support < -frame.margin*(Math.abs(n.x)+Math.abs(n.y)+Math.abs(n.z))) return true;
  }
  return false;
}

'''
changes={}
rel='renderers/web/js/batch-frustum-box.js';before=(root/rel).read_text();s=before.replace('/** No renderer/visibility/geometry mutation: only compact a freshly prepared list. */',helper+'/** No renderer/visibility/geometry mutation: only compact a freshly prepared list. */');s=s.replace('acceptsSeason, stats = null)', 'acceptsSeason, stats = null, shadowDescriptor = null)');s=s.replace('  let renderHook = null, shadowHook = null;', '  let renderHook = null, shadowHook = null, shadowFrame = null;\n  const shadowScratch = { identity: new THREE.Matrix4(), clip: new THREE.Matrix4(), expected: new THREE.Matrix4(),\n    frustum: new THREE.Frustum(), ray: new THREE.Vector3(), margin: 0, camera: null };');s=s.replace('    let rejected = 0;', '    let rejected = 0, shadowRejected = 0;');s=s.replace('        if (!frustum.intersectsBox(box)) { keep[k] = false; rejected++; }', '        if (!frustum.intersectsBox(box)) { keep[k] = false; rejected++; }\n        else if (shadowFrame?.camera === camera && material === depthMaterial && shadowCannotReachView(shadowFrame, box)) {\n          keep[k] = false; rejected++; shadowRejected++;\n        }');s=s.replace('    if (stats) stats.boxRejected = (stats.boxRejected ?? 0) + rejected;', '    if (stats) {\n      stats.boxRejected = (stats.boxRejected ?? 0) + rejected;\n      stats.shadowViewRejected = (stats.shadowViewRejected ?? 0) + shadowRejected;\n    }');needle='  cullPrepared.seal = () =>';idx=s.index(needle);s=s[:idx]+'''  const prepareShadow = batch.onBeforeShadow;
  batch.onBeforeShadow = function(renderer, object, camera, shadowCamera, geometry, material, group) {
    const previous = shadowFrame;
    shadowFrame = object === batch ? shadowViewFrame(shadowScratch,renderer,camera,shadowCamera,shadowDescriptor,batch) : null;
    try { return prepareShadow.call(this,renderer,object,camera,shadowCamera,geometry,material,group); }
    finally { shadowFrame = previous; }
  };
'''+s[idx:];changes[rel]=(before,s)
rel='renderers/web/js/buildings.js';before=(root/rel).read_text();old='installFrustumBoxCull(batch, bucket.boundsRigid, depthMaterial, seasonPreservesSurface, coalesce)';new='installFrustumBoxCull(batch, bucket.boundsRigid, depthMaterial, seasonPreservesSurface, coalesce, shadowCasters)';assert before.count(old)==1;changes[rel]=(before,before.replace(old,new))
rel='renderers/web/js/main.js';before=(root/rel).read_text();old='const shadowCasters = { on: false, culled: 0, sun: () => world.direction };';new="const shadowCasters = { on: false, culled: 0, sun: () => world.direction,\n    light: () => world.light, fresh: () => detailLevel === 'full' && governor.shadowFresh };";assert before.count(old)==1;changes[rel]=(before,before.replace(old,new))
guards={};patch=[]
for rel,(b,a)in changes.items():
 for folder,data in [('before',b),('candidate',a)]:
  p=out/folder/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 guards[rel]={'before_sha256':hashlib.sha256(b.encode()).hexdigest(),'after_sha256':hashlib.sha256(a.encode()).hexdigest()};patch.extend(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel))
(out/'source-guards.json').write_text(json.dumps(guards,indent=2)+'\n');(out/'proposal.patch').write_text(''.join(patch));(out/'batch-frustum-box.js').write_text(changes['renderers/web/js/batch-frustum-box.js'][1]);(out/'buildings.candidate.js').write_text(changes['renderers/web/js/buildings.js'][1])
