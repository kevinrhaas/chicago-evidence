# Full directional-shadow away-ray candidate — UNAPPLIED / actual saving UNKNOWN

This is a three-path candidate against root H8commit35f0c564cc25303d3f5641812d532dd9d2166b64. It has not been adopted, published or browser-tested here. Root's original new-base4,666,158-triangle/5,097-call failure remains. The previous affine-box candidate saved zero and was rejected; no result from it is borrowed. Caps, source geometry, camera/tier, transparent roofs and existing Light-only caster policy remain unchanged.

## Exact mathematical scope

For a main-camera inward plane `P(x)=n·x+d`, let a containing caster box have maximum support `s`. The actual directional shadow-camera forward ray is `r`. For `t>=0`, `P(c+t*r)=P(c)+t*(n·r)`. If `n·r<0` and `s+offsetAllowance<0`, every forward ray remains outside that visible halfspace. A caster satisfying this condition cannot shadow a receiver inside the main-camera frustum, subject to the explicitly bounded native filter/bias offsets below. Tangent or uncertain directions are retained with a strict1e-10 dimensionless angular fringe; there is no assumed terrain floor or finite30m sweep.

The caster bound is the same actual stored-geometry AABB/current instance transform already used by the existing culler. Its existing world-coordinate numeric fringe remains. The supplemental phase requires identity batch matrixWorld, so all new planes/rays/margins are in actual world metres. It rejects only after the original native-sphere/AABB stages and only in a recorded actual `onBeforeShadow` depth preparation, never a colour/pick preparation.

The source stock PCF shader uses five unit-radius Vogel taps and hardware linear depth comparison. Tap displacement is below one texel-radius; linear texel support is bounded by another diagonal texel. The square orthographic native map therefore admits a conservative **2*sqrt(2)*worldTexel** offset. Add the unit world-normal displacement **abs(normalBias)**, possible backward normalized-depth comparison displacement **abs(bias)*(far-near)** and **2^-23*(far-near)** depth/numeric allowance. Expand by that total through plane L1 norm, in addition to the old positional fringe. No filter/bias/numeric allowance is reduced to seek a saving.

At default Full480m/4096 map, bias−0.0004, normalBias0.045 and depth span899m, this is about0.736m world padding. This is a conservative unsupported-contribution test, not occlusion or a visible-face deletion.

## Three tracked paths and actual native plumbing

1. `main.js`: extend existing shadowCasters descriptor with live `light:()=>world.light` and `fresh:()=>detailLevel==='full' && governor.shadowFresh`. The world already exposes the real light. Existing Light `on/sun` policy stays intact.
2. `buildings.js`: pass that descriptor to the existing eligible Full opaque culler. No geometry/material/bounds source change.
3. `batch-frustum-box.js`: wrap actual `onBeforeShadow(renderer,object,mainCamera,shadowCamera,geometry,depthMaterial)` before the old shadow preparation. Its scoped context reaches the existing `onBeforeRender` depth-list preparation, then clears in finally. Only the known current depth list gets a supplemental stable compaction. Existing callback seals, range identity, material/hook/format/epoch/morph/unknown fail-open checks remain in force. Diagnostic `shadowViewRejected` counts only new rejections; `boxRejected` remains total.

The new phase requires the actual stock DirectionalLight and DirectionalLightShadow class, the exact associated shadow camera, native Perspective main/Orthographic shadow cameras, WebGL/non-reversed projection, rigid unit orthographic frame, exact inverse consistency and exact native projection/shadow matrix agreement. It also requires fresh Full cadence plus renderer/light autoUpdate, actual square map/mapSize/depth-image agreement, noMSAA, stock unsigned-integer depth/linear compare/clamp sampler, radius1 and the unmodified native shadow-coordinate/filter chunks. Unknown/missing/light/filter/camera/map/cadence states skip this phase. Three does not publicly export DirectionalLightShadow; its exact class is captured from a stock DirectionalLight instead of relying on an undefined export or a name string.

This guarantee is bounded to the current native stock receiver shadow-coordinate/filter contract. It does not qualify arbitrary receiver shader code rewriting shadow UVs, normals or filtering. Global stock chunk mutations skip the phase; new receiver shader behavior requires a new contract review. Full's existing governor regenerates the map on every drawn frame. Reusing a view-culled map for a different camera without regeneration is outside that premise; the Full/fresh descriptor and runtime cadence checks must remain. This is not a general cached-shadow optimizer.

## CPU proof and limits

**47 existing controls PASS**, unchanged, including geometry/index/instance bytes, transparent source colour/shadow ordering, picking replacement material, season hooks, unknown hook/define/format/epoch/morph/range/camera states, coalescing and native Full-vs-Light/Balanced integration.

**28 new controls PASS** with actual vendored Three lights, shadow matrices, depth textures and BatchedMesh callbacks. The renderer metadata descriptor is a CPU-only prototype fixture, not an initialized WebGL renderer or a claimed actual browser pass. A native shadow-list control removes only a known away-casting offscreen primitive, preserves the exact old filtered ordering and colour list, and retains the same caster for a toward-view sun.1000 separating-plane fixtures check forward rays/corner-offset bounds; algebra supplies the unbounded-time argument. Filter-nearby controls retain a caster and prove that removing the offset allowance would incorrectly reject it. Unsupported cadence, light, filter, matrix/inverse, map/depth image, radius, camera, batch frame and stock chunk states all skip the phase.

All3 authored JS syntax checks, exact preimage/dependency guards and isolated three-file patch checks pass. The initial undefined non-exported class assumption and two guessed native-order draft errors remain in logs. The class guard was corrected and tests now compare old native retained order instead of assuming IDs sort numerically. No project assertion or contract validator was relaxed.

No Blender/browser/native writer/fullgate or canonical change occurred. No actual saving, shadow-pixel equivalence, device CPU overhead or performance acceptance is established. Actual default map/filter source was read; GPU/driver behavior and arbitrary postprocessing/receiver programs are not certified by these CPU fixtures.

## Parent-only next action

`python apply-guard.py <4d-root>` is read-only. `--apply` writes only these3 reviewed paths after all hashes/dependencies pass. Original root paths are unknown to this proposal if anything moves; guard failure requires review, not an automatic broad merge.

If adopted, root should run the same bounded actual1904Full arrival/spawn and relevant shadow/content/pick/default controls, requiring the real4.6M/7800 caps without changed pose/quality/geometry. Capture live `shadowViewRejected` and raw renderer counters but do not turn the counter into a saving claim without the actual run. Reject/revert on inadequate saving, lost visible/shadow content, unexpected errors or unacceptable CPU cost. Existing whole-stage/phone/browser/fullgate requirements remain owed before merge.
