

### L-lake-house-open-shell-2379 — distinguish an omitted roof from a flat cap

**Covers:** `lake_house_construction.shell_1835.form.roof_type`.

**Decision:** Keep the existing reconstructed one-storey/four-metre,24×15m worksite and `roof_type: none`, and make that selector omit the generic roof cap. `flat` retains its exact existing cap; all pitched roofs and other role dispatch remain unchanged. This removes a360m² cap/four raw vertices/two triangles; it introduces no excavation, floor, scaffold, interior passage, construction stock or new phase.

**Evidence and bounds:** The held Chicago Democrat notice of10June1835,p.2col.5, reports an active house-building project in Kinzie's Addition, understood to be named Lake House. The bracketed/transcription-mediated reading does not show roof or progress. June1836 unfinished work and autumn1836 opening do not establish July1835 roof absence. The roof field therefore becomes reconstructed; all phase dates, footprint, coordinates, dimensions, whole-building grade and the zero-to-two-storey uncertainty stay unchanged. Bonnell's conflicting retrospective dates remain unresolved. No later completed-hotel picture supplies the July construction stage. OriginalT-2379 remains open/differs; actual native family refresh, above-wall comparison and app/gates are owed.

**Status:** Prepared isolated S proposal; utility/date/admission are the canonical writer's responsibility.
