"""Bounded actual-source CPU controls. No Blender, exporter or native pipeline."""
from pathlib import Path
import ast, copy, dataclasses, hashlib, json, sys

HERE=Path(__file__).resolve().parent
ROOT=Path('/tmp/chicago-log-integration/chicago/4d')
EMITTER=Path('/tmp/T2373-8021-raw25-proof/emit-raw.py')
sys.argv=[str(EMITTER),'--common-root',str(ROOT),'--source-root',str(HERE/'before'),'--output',str(HERE/'unused-adapter-output.json')]
source=EMITTER.read_text();prefix=source.split('rows=[];negative=[]')[0]
env={'__file__':str(EMITTER),'__name__':'bounded_cpu_adapter'}
exec(compile(prefix,str(EMITTER),'exec'),env)
params=env['params'];old=env['builder'];load=env['load'];snapshot=env['snapshot'];summary=env['summary'];digest=env['digest']
new=load(HERE/'candidate/generators/archetypes/fort_structure.py','none_roof_selected_candidate')
before=json.loads((HERE/'before/data/structures/lake_house_construction.json').read_text())
after=json.loads((HERE/'candidate/data/structures/lake_house_construction.json').read_text())
oldp=params.from_phase(before['phases'][0],before);newp=params.from_phase(after['phases'][0],after)
name='lake_house_construction__shell_1835'
a=snapshot(old.build(oldp,name));b=snapshot(new.build(newp,name))
cap=[(0.,0.,4.),(0.,15.,4.),(24.,15.,4.),(24.,0.,4.)]
indices=[i for i,f in enumerate(a['faces']) if [a['vertices'][j] for j in f]==cap]
assert len(indices)==1
ci=indices[0];vertex_indices=list(a['faces'][ci]);assert vertex_indices==list(range(vertex_indices[0],vertex_indices[0]+4))
reduced=copy.deepcopy(a);reduced['vertices']=[v for i,v in enumerate(a['vertices']) if i not in vertex_indices]
reduced['faces']=[tuple(j-4 if j>vertex_indices[-1] else j for j in f) for i,f in enumerate(a['faces']) if i!=ci]
for k in ['material_indices','smooth','polygon_unit_normals']:
 reduced[k]=[v for i,v in enumerate(a[k]) if i!=ci]
for k,vals in a['attributes'].items():reduced['attributes'][k]=[v for i,v in enumerate(vals) if i not in vertex_indices]
assert digest(reduced)==digest(b),'Unexpected non-cap geometry/material/confidence/tone change'
assert summary(a)['fan_triangles']==66 and summary(b)['fan_triangles']==64
assert summary(a)['bounds']==summary(b)['bounds']

flat=dataclasses.replace(oldp,roof_type='flat')
flat_old=old.TonedBuilder('synthetic-flat');flat_new=new.TonedBuilder('synthetic-flat')
old_return=old._roof(flat_old,flat,0.,0.,24.,15.,4.,.5)
new_return=new._roof(flat_new,flat,0.,0.,24.,15.,4.,.5)
def raw(m):return {'verts':m.verts,'faces':m.faces,'confidence':m.conf,'materials':m.mat_index,'named':m.named,'tone':m.tone}
assert old_return==new_return==4. and raw(flat_old)==raw(flat_new)
assert flat_new.verts==cap and len(flat_new.faces)==1 and flat_new.mat_index==[new.M_ROOF]
none=params.from_phase(after['phases'][0],after)
empty=new.TonedBuilder('synthetic-none');assert new._roof(empty,none,0.,0.,24.,15.,4.,.5)==4.
assert not empty.verts and not empty.faces and not empty.conf and not empty.mat_index and not empty.named and not empty.tone

# Negative control: the old buggy none selector emits the cap and fails omission.
bug=old.TonedBuilder('old-none-negative');old._roof(bug,oldp,0.,0.,24.,15.,4.,.5)
assert bug.verts and bug.faces
# Negative control: a dropped flat cap is not equivalent to the flat positive.
assert raw(empty)!=raw(flat_new)
proof={'scope':'ACTUAL_BUILD_AND_NATIVE_MESH_MATERIAL_SOURCE_CPU_ADAPTER; NO_BLENDER_OR_EXPORT',
       'adapter_preimage_sha256':hashlib.sha256(EMITTER.read_bytes()).hexdigest(),
       'baseline':summary(a),'candidate':summary(b),
       'removed_exactly_one_cap':{'quad':cap,'vertices':4,'fan_triangles':2,'area_m2':360,'old_face_index':ci},
       'remaining_vertices_faces_materials_confidence_tone_normals_exact':True,
       'bounds_exact':True,'generic_flat_positive_exact':True,'generic_none_empty_positive':True,
       'old_bug_negative_detected':True,'dropped_flat_negative_detected':True,
       'default24_scope':'STATIC unchanged functions/branches plus actual25 dispatch; not24 new exported or CPU-built streams',
       'full_native_family_refresh_app_image_and_policy_gates':'NOT_RUN'}
(HERE/'cpu-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print('PASS actual LakeHouse66->64; remaining streams exact; flat positive/none positive/old-bug and lost-flat negatives')
