from pathlib import Path
import ast, copy, difflib, hashlib, json

ROOT=Path('/tmp/chicago-log-integration/chicago/4d')
OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['generators/archetypes/fort_structure.py','generators/archetypes/fort_structure_params.py',
       'data/structures/lake_house_construction.json','docs/RESEARCH/lake_house_construction.md','docs/LIBERTIES.md']
before={p:(ROOT/p).read_bytes() for p in paths}
assert sha(before[paths[0]])=='fc645a66b889e8ca837520e73d2bdee4806b0892e33591099714bff10178d64e'
assert sha(before[paths[1]])=='81d6a7fbb345082d60272429f0cb92dee751d3c1cbe40624017f572d6e523a5d'
builder=before[paths[0]].decode()
old='    if p.roof_type in ("flat", "none"):\n'
assert builder.count(old)==1
builder=builder.replace(old,'    if p.roof_type == "none":\n        return eave_z\n    if p.roof_type == "flat":\n')
record=json.loads(before[paths[2]])
original=copy.deepcopy(record)
phase=record['phases'][0]
roof=phase['form']['roof_type']
assert roof['value']=='none' and roof['confidence']=='inferred'
roof.update(confidence='reconstructed', sources=['andreas_1884_v1','chicago_democrat_1833_1835'],
 note='A RECONSTRUCTED OPEN-SHELL CHOICE, NOT A DATED ROOF OBSERVATION. The Chicago Democrat of 10 June 1835, page 2 column 5, reports a new house building in Kinzie\'s Addition, understood to be named Lake House. The held reading is transcription-mediated with bracketed supplies; no newspaper scan was newly inspected. It establishes an active project, not its roof, storeys reached or dimensions on 1 July. Andreas\'s autumn 1836 opening and Martineau\'s June 1836 unfinished interior do not prove that a roof was absent in July 1835. The existing one-storey, four-metre roofless shell is a chosen worksite representation within the stated zero-to-two-storey uncertainty. The none selector omits the roof cap; no scaffold, excavation or walkthrough is implied.')
note=record['research_note']
replacements={
 'and nothing at all is documented about what stood on the ground on 1 July 1835.':'and the scene-year press records an active project, but not its height, roof or detailed progress on 1 July 1835.',
 'So the fact that puts this structure in the 1835 scene at all rests on two modern compilations agreeing, which is not two witnesses,':'That editorial groundbreaking date is not two independent witnesses, but the separate Chicago Democrat notice of 10 June 1835, page 2 column 5, already cited under function, does report a new house building in Kinzie\'s Addition, understood to be named Lake House. Its held transcription has bracketed supplies; no newspaper scan was newly inspected. The notice supports the project before the scene, not an exact groundbreaking date or progress,',
 'and this record models one storey of roofless brickwork on that reasoning with the honest range stated as zero to two storeys.':'and this record retains one storey of roofless brickwork as a reconstructed worksite choice, with the honest range stated as zero to two storeys. Being unfinished in 1836 does not prove roof absence in July 1835.'}
for old,new in replacements.items():
 assert note.count(old)==1,old
 note=note.replace(old,new)
record['research_note']=note
rng=phase['documented_range']
rng['note']+=' CURRENT EVIDENCE CORRECTION: the earlier ONLY THING wording is superseded by the separate Chicago Democrat notice of 10 June 1835, page 2 column 5, already cited under function. Its transcription-mediated reading supports an active named project before the scene but no precise groundbreaking day, roof or construction stage. The existing January 1 bound remains inferred, not an observed start date.'
rng['sources'].append('chicago_democrat_1833_1835')
dossier_fragment='''\n\n## Current evidence correction — roof absence is reconstructed\n\nThe earlier statements that modern compilations alone establish the 1835 site, and that rooflessness is a documented fact, are superseded here. The already-held *Chicago Democrat*, 10 June 1835, p.2 col.5, claim `chicago_democrat_1835_06_10#c001`, reports a new house building in Kinzie's Addition, understood to be named Lake House. Its reading is transcription-mediated, with bracketed supplies; no newspaper scan was newly inspected for this correction. It establishes an active project before1July, not the groundbreaking day, height, storeys, plan or roof. The existing January1 bound remains inferred.\n\nMartineau's unfinished hotel interior in June1836 and Andreas's autumn1836 opening do not prove roof absence in July1835. The current one-storey/four-metre open shell,24×15m plan and zero-to-two-storey progress range remain reconstructed choices. No scaffolding, excavation, materials stock, later completed-hotel appearance, new phase or exact construction schedule is inferred. Bonnell's explicit1835/date-arithmetic1836/introductory1837 conflict remains unresolved. The exclusion of the finished hotel does not establish the site's July progress.\n\n`roof_type: none` must omit the generic cap; `flat` retains its existing cap. Actual dispatch isolates the visible change to this magazine-role worksite among the25 current fort-family phases; parades, flagstaffs, tower and earth-covered root houses use other builders. The full shared-family official refresh, actual above-wall comparison, app and policy gates remain owed. OriginalT-2379 stays open/differs; this correction is not an accepted picture match.\n'''
lib_fragment='''\n\n### L-lake-house-open-shell-2379 — distinguish an omitted roof from a flat cap\n\n**Covers:** `lake_house_construction.shell_1835.form.roof_type`.\n\n**Decision:** Keep the existing reconstructed one-storey/four-metre,24×15m worksite and `roof_type: none`, and make that selector omit the generic roof cap. `flat` retains its exact existing cap; all pitched roofs and other role dispatch remain unchanged. This removes a360m² cap/four raw vertices/two triangles; it introduces no excavation, floor, scaffold, interior passage, construction stock or new phase.\n\n**Evidence and bounds:** The held Chicago Democrat notice of10June1835,p.2col.5, reports an active house-building project in Kinzie's Addition, understood to be named Lake House. The bracketed/transcription-mediated reading does not show roof or progress. June1836 unfinished work and autumn1836 opening do not establish July1835 roof absence. The roof field therefore becomes reconstructed; all phase dates, footprint, coordinates, dimensions, whole-building grade and the zero-to-two-storey uncertainty stay unchanged. Bonnell's conflicting retrospective dates remain unresolved. No later completed-hotel picture supplies the July construction stage. OriginalT-2379 remains open/differs; actual native family refresh, above-wall comparison and app/gates are owed.\n\n**Status:** Prepared isolated S proposal; utility/date/admission are the canonical writer's responsibility.\n'''
after={paths[0]:builder.encode(),paths[1]:before[paths[1]],paths[2]:(json.dumps(record,ensure_ascii=False,indent=2)+'\n').encode(),paths[3]:before[paths[3]]+dossier_fragment.encode(),paths[4]:before[paths[4]]+lib_fragment.encode()}
for p in paths[:4]:
 for prefix,data in [('before',before[p]),('candidate',after[p])]:
  dest=OUT/prefix/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
(OUT/'LIBERTIES.fragment.md').write_text(lib_fragment)
(OUT/'dossier-correction.fragment.md').write_text(dossier_fragment)
patch=''.join(''.join(difflib.unified_diff(before[p].decode().splitlines(True),after[p].decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p,n=3)) for p in paths if after[p]!=before[p])
(OUT/'selective.patch').write_text(patch)
guards=[{'path':p,'before_sha256':sha(before[p]),'after_sha256':sha(after[p]),'changed':after[p]!=before[p]} for p in paths]
(OUT/'file-guards.json').write_text(json.dumps(guards,indent=2)+'\n')
ast_before=ast.parse(before[paths[0]]);ast_after=ast.parse(after[paths[0]])
for tree in (ast_before,ast_after):
 tree.body=[n for n in tree.body if not isinstance(n,ast.FunctionDef) or n.name!='_roof']
assert ast.dump(ast_before)==ast.dump(ast_after)
check=copy.deepcopy(record);check['research_note']=original['research_note'];check['phases'][0]['documented_range']=original['phases'][0]['documented_range'];check['phases'][0]['form']['roof_type']=original['phases'][0]['form']['roof_type'];assert check==original
rows=[]
for p in sorted((ROOT/'data/structures').glob('*.json')):
 d=json.loads(p.read_bytes())
 if d.get('archetype')!='fort_structure':continue
 for ph in d['phases']:
  k=ph['form'].get('kind',{}).get('value','quarters');rf=ph['form'].get('roof_type',{}).get('value','gable');dispatch={'parade':'_parade','root_house':'_root_house','tower':'_tower','flagstaff':'_flagstaff'}.get(k,'_building')
  rows.append({'record_path':str(p.relative_to(ROOT)),'record_sha256':sha(p.read_bytes()),'structure':d['id'],'phase':ph['id'],'kind':k,'roof':rf,'dispatch':dispatch,'affected':dispatch=='_building' and rf=='none'})
assert len(rows)==25 and [r['structure'] for r in rows if r['affected']]==['lake_house_construction']
(OUT/'current25-dispatch.json').write_text(json.dumps(rows,indent=2)+'\n')
(OUT/'source-proof.json').write_text(json.dumps({'all_non_roof_module_AST_exact':True,'params_exact':True,'only_record_deltas':['roof_type.confidence/note/sources','research_note','documented_range.note/sources'],'all_dates_footprint_dimensions_placement_whole_grade_unchanged':True,'dossier_entire_raw_prefix_preserved':True,'liberties_entire_raw_prefix_preserved':True,'actual25_static_only_LakeHouse_generic_none':True,'native_official_bake_browser_app_gates':'NOT_RUN'},indent=2)+'\n')
print('Prepared guarded four-change-path proposal; fifth params path unchanged dependency.')
