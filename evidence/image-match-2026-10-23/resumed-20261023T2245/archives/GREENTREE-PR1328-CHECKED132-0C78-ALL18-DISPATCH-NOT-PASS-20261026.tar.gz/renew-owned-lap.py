from pathlib import Path
import subprocess,json,datetime
H=Path('/tmp/green-tree-T2376-20261025')
source=H/'OWN-LAP-LATEST.json'
if not source.exists():
    source=H/'OWN-LAP-RENEWAL.json'
previous=json.loads(source.read_text());expected=previous['new_sha']
out=H/'lap-renewals'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%f')
out.mkdir(parents=True)
def api(path):
    return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path]))
ref=api('git/ref/heads/lap/pr-1328')
assert ref['object']['sha']==expected,'A different holder must never be overridden'
owner=api('git/commits/'+expected)
assert owner['message']==previous['owner']['message']
assert owner['author']==previous['owner']['author']
assert owner['author']['name']=='polecat-steward' and owner['parents']==[]
assert owner['message'].startswith('lap PR #1328 — Codex Green Tree PR1328 continuation ')
(out/'before.json').write_text(json.dumps({'ref':ref,'owner':owner,'source_receipt':str(source)},indent=2)+'\n')
command=['node','tools/ticket.mjs','lap','1328','--force','--by','Codex Green Tree PR1328 continuation']
with (out/'native.log').open('x') as log:
    process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
assert process.returncode==0
updated=api('git/ref/heads/lap/pr-1328');newsha=updated['object']['sha'];assert newsha!=expected
record=api('git/commits/'+newsha)
assert record['message'].startswith('lap PR #1328 — Codex Green Tree PR1328 continuation ')
assert record['author']['name']=='polecat-steward' and record['parents']==[]
created=datetime.datetime.fromisoformat(record['author']['date'].replace('Z','+00:00'))
result={'old_sha':expected,'new_sha':newsha,'created':created.isoformat(),'expires':(created+datetime.timedelta(hours=3)).isoformat(),'verified_only_our_old_marker':True,'native_command':command,'native_exit':process.returncode,'ref':updated,'owner':record,'directory':str(out)}
(out/'RENEWAL.json').write_text(json.dumps(result,indent=2)+'\n')
(H/'OWN-LAP-LATEST.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['old_sha','new_sha','created','expires','directory']},indent=2))
