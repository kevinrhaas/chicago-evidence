from pathlib import Path
import datetime, hashlib, json, time, urllib.request, urllib.error, urllib.parse, subprocess, os, sys

BASE = 'https://api.github.com/repos/kevinrhaas/chicago/'
HOLDER=Path('/tmp/green-tree-T2376-20261025')
CFILE=Path(sys.argv[1]) if len(sys.argv)>1 else HOLDER/'FINAL-CANDIDATE.json'
C=json.loads(CFILE.read_text())
HEAD=C['head']
TREE=C['tree']
EXPECTED_BASE=C['base']
BRANCH='verification/t2376-pr1328-'+HEAD[:12]+'-20261026'
OUT=HOLDER/('native-final-matrix-'+HEAD[:12])
OUT.mkdir(exist_ok=True)
PLAN = [(v, s) for v in ('desktop', 'mobile') for s in ('1-2','3-4','5','6-7','8','9-12','13','14','15')]

def api(path, data=None):
    req = urllib.request.Request(BASE + path, data=None if data is None else json.dumps(data).encode(),
        headers={'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json'},
        method='GET' if data is None else 'POST')
    with urllib.request.urlopen(req, timeout=90) as r:
        body = r.read()
        return r.status, json.loads(body) if body else None

def save(name, value):
    p = OUT / name
    assert not p.exists(), 'Never overwrite an earlier dispatch receipt'
    p.write_text(json.dumps(value, indent=2) + '\n')

if (OUT / 'COMPLETE_DISPATCH.json').exists():
    raise SystemExit('Already dispatched; refusing duplicate run')
for viewport in ('mobile','desktop'):
    actual=[]
    for v,group in PLAN:
        if v!=viewport: continue
        bounds=[int(x) for x in group.split('-')]
        actual.extend(range(bounds[0],bounds[-1]+1))
    assert sorted(actual)==list(range(1,16)) and len(actual)==15
pre=json.loads(Path(C['preflight_result']).read_text())
post=json.loads(Path(C['committed_questions']).read_text())
assert pre['status']=='PASS' and pre['staged_tree']==TREE
assert pre['source_unchanged'] and pre['index_tree_unchanged'] and pre['working_index_clean']
assert post['status']=='PASS' and post['head']==HEAD and post['tree']==TREE and post['base']==EXPECTED_BASE
source_env={**os.environ,'GIT_NO_LAZY_FETCH':'1'}
assert subprocess.check_output(['git','rev-parse','HEAD'],env=source_env).decode().strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],env=source_env).strip()
workflow=subprocess.check_output(['git','show',HEAD+':.github/workflows/chicago-4d-smoke.yml'],env=source_env)
assert hashlib.sha256(workflow).hexdigest()=='f0f6c6f5cf942af4e49609b7854bdd1472bd98e06159e687ed76893138e7a73c'
assert b'timeout-minutes: 150' in workflow
_,dev=api('git/ref/heads/dev')
_,pr=api('pulls/1328')
_,commit=api('git/commits/'+HEAD)
_,comparison=api('compare/'+EXPECTED_BASE+'...'+HEAD)
_,lap=api('git/ref/heads/lap/pr-1328')
_,owner=api('git/commits/'+lap['object']['sha'])
save('PRE-DISPATCH-REMOTE.json',{'dev':dev,'pr':pr,'commit':commit,'comparison':comparison,'lap':lap,'owner':owner})
_,base_to_current=api('compare/'+EXPECTED_BASE+'...'+dev['object']['sha'])
assert base_to_current['merge_base_commit']['sha']==EXPECTED_BASE,'Remote lineage changed; preserve evidence and review before dispatch'
save('PASSED-BASE-VS-CURRENT-REMOTE.json',{'passed_base':EXPECTED_BASE,'checked_head':HEAD,'checked_tree':TREE,'actual_remote_at_dispatch':dev['object']['sha'],'comparison':base_to_current,'scope':'Root-approved immutable checked-tree coverage may start while a newer dev delta is integrated separately. NO latest combined coverage or merge approval claimed.'})
assert pr['head']['sha']==HEAD and pr['base']['ref']=='dev' and pr['state']=='open'
assert commit['tree']['sha']==TREE
assert comparison['merge_base_commit']['sha']==EXPECTED_BASE and comparison['behind_by']==0
assert lap['object']['sha']==C['lap_sha']
assert owner['message'].startswith('lap PR #1328 — Codex Green Tree PR1328 continuation ')
created=datetime.datetime.fromisoformat(owner['author']['date'].replace('Z','+00:00'))
assert created+datetime.timedelta(hours=3)-datetime.datetime.now(datetime.timezone.utc)>datetime.timedelta(minutes=160),'Renew exact own marker before150-minute jobs'
save('CANDIDATE.json',C)

try:
    status, ref = api('git/ref/heads/' + BRANCH)
except urllib.error.HTTPError as e:
    assert e.code == 404
    status, ref = api('git/refs', {'ref': 'refs/heads/' + BRANCH, 'sha': HEAD})
    assert status == 201
    save('created-verification-ref.json', ref)
assert ref['object']['sha'] == HEAD
query = 'actions/workflows/chicago-4d-smoke.yml/runs?branch=' + urllib.parse.quote(BRANCH, safe='') + '&event=workflow_dispatch&per_page=100'
_, before = api(query)
assert not before['workflow_runs'], 'Existing runs need reconciliation; do not dispatch duplicates'
save('PLAN.json', {'authorized_by': 'root2026-10-26 autonomous PR1328 endgame', 'PR':1328, 'head': HEAD, 'tree': TREE, 'branch': BRANCH, 'legs': PLAN,
    'native_workflow_sha256': 'f0f6c6f5cf942af4e49609b7854bdd1472bd98e06159e687ed76893138e7a73c',
    'command': 'node tools/smoke_renderer.mjs --published', 'scope': 'Validation of the exact checked candidate for its recorded passed base. A newer actual dev is recorded separately and requires appropriate delta validation before merge; no latest-combined claim. Native150-minute cap and all assertions unchanged.'})
seen = set()
runs = []
for viewport, stage in PLAN:
    _, current = api('git/ref/heads/' + BRANCH)
    assert current['object']['sha'] == HEAD, 'Verification ref moved; stop'
    payload = {'ref': BRANCH, 'inputs': {'viewport': viewport, 'stage': stage}}
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save('intent-'+viewport+'-'+stage+'.json',{'attempted_at':started,'request':payload})
    status, response = api('actions/workflows/chicago-4d-smoke.yml/dispatches', payload)
    assert status == 204
    save('accepted-' + viewport + '-' + stage + '.json', {'accepted_at': started, 'HTTP': status, 'request': payload, 'response': response})
    deadline = time.monotonic() + 100
    while True:
        _, got = api(query)
        new = [x for x in got['workflow_runs'] if x['id'] not in seen]
        if new:
            assert len(new) == 1, 'Ambiguous run IDs; preserve receipts and reconcile'
            run = new[0]
            assert run['head_sha'] == HEAD and run['head_branch'] == BRANCH and run['event'] == 'workflow_dispatch'
            seen.add(run['id'])
            row = {'id': run['id'], 'viewport': viewport, 'stage': stage, 'dispatch_accepted': True, 'observed_head': run['head_sha'], 'created_at': run['created_at'],'initial_run_attempt':run['run_attempt'], 'url': run['html_url']}
            runs.append(row)
            save('bound-' + viewport + '-' + stage + '.json', {'requested': row, 'actual_run': run})
            print(json.dumps(row), flush=True)
            break
        assert time.monotonic() < deadline, 'Dispatch accepted but run binding unavailable; do not retry dispatch'
        time.sleep(2)
save('COMPLETE_DISPATCH.json', {'PR':1328, 'head': HEAD, 'tree': TREE, 'branch':BRANCH,'base':EXPECTED_BASE,'actual_remote_at_dispatch':dev['object']['sha'],'runs':runs,
    'dispatched_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': '18_DISPATCH_ACCEPTED_HEAD_BOUND_NOT_PASS'})
print('COMPLETE18_DISPATCH_NOT_PASS', flush=True)
