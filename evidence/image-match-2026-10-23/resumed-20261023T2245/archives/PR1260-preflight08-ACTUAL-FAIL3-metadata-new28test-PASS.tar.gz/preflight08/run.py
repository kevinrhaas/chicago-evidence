from pathlib import Path
import subprocess,json,datetime,os,hashlib,shutil,sys
r=Path('/workspace/primary-human-runner-compat/chicago/4d');o=Path(__file__).resolve().parent;now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();git=lambda *a:subprocess.check_output(['git',*a],cwd=r)
assert not git('diff','--name-only').strip();assert not git('ls-files','--others','--exclude-standard').strip();assert git('rev-parse','HEAD').decode().strip()=='35f0c564cc25303d3f5641812d532dd9d2166b64'
assert not git('diff','--cached','--name-only','HEAD','--','data','assets','generators','docs/LIBERTIES.md').strip(),'Protected data/assets/recipes or original liberties drift'
initial=git('write-tree').decode().strip();patch=git('diff','--cached','--binary','HEAD');(o/'source-six-path.patch').write_bytes(patch)
env={**os.environ,'TMPDIR':'/workspace/tmp-t3081','PATH':'/workspace/shared/tools/usr/bin:'+os.environ['PATH'],'CHECK_JOBS':'4','C4D_GATE_REQUIRE_READERS':'1','PYTHONDONTWRITEBYTECODE':'1','npm_config_cache':'/workspace/shared/npm-cache'}
s={'status':'RUNNING','started':now(),'controller_pid':os.getpid(),'HEAD':git('rev-parse','HEAD').decode().strip(),'index_tree':initial,'source_patch_sha256':hashlib.sha256(patch).hexdigest(),'command':['bash','./tools/preflight.sh'],'CHECK_JOBS':4,'C4D_GATE_REQUIRE_READERS':1,'all_tracked_data_assets_generators_original_liberties_exact_H8':True,'actual_shadow_source_three_paths_exact_reviewed_1508':True,'local_extra_photo_probe':'FAIL_NSS_READONLY_TLS_BUDGET_PASS3955624','hosted_stage14_both':'PENDING'};save=lambda:(o/'receipt.json').write_text(json.dumps(s,indent=2)+'\n');save()
with(o/'preflight.log').open('x')as f:
 p=subprocess.Popen(s['command'],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT);s['child_pid']=p.pid;save();rc=p.wait()
s.update(exit_code=rc,finished=now(),status='PASS'if rc==0 else'FAILED',source_bytes_unchanged=git('write-tree').decode().strip()==initial and not git('diff','--name-only').strip() and git('diff','--cached','--binary','HEAD')==patch)
for name,src in [('check.log','/tmp/preflight-check.log'),('changelog.log','/tmp/preflight-cl.log'),('ids.log','/tmp/preflight-ids.log')]:
 if Path(src).exists():shutil.copy2(src,o/name);s[name+'_sha256']=hashlib.sha256((o/name).read_bytes()).hexdigest()
if not s['source_bytes_unchanged']:s['status']='FAILED_SOURCE_MOVED'
save();print(json.dumps(s,indent=2));sys.exit(0 if s['status']=='PASS'else(rc or 2))
