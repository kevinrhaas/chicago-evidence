"""Default read-only PLAN. --execute is allowed only at root's closed GT source phase boundary."""
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import quote
import os,json,hashlib,zlib,subprocess,time,signal,importlib.util,argparse,datetime,base64,stat
P=argparse.ArgumentParser(description=__doc__);P.add_argument('--output',required=True);P.add_argument('--execute',action='store_true');P.add_argument('--source-phase-lease');a=P.parse_args();os.sched_setaffinity(0,{1});os.nice(19)
PREP_ROOT=Path(__file__).parent;O=Path(a.output);O.mkdir(exist_ok=False);price=json.loads((PREP_ROOT/'COMPRESSED-PRICE.json').read_text());TIP='72c03a0ac4841e7eacd7ae55d0bebd94fd8ca217';OLD='ec16b8dd726fa7852ede885ef2d754d55b9b4c59';HEAD='b20f4200495c38f57f268d24870313e53ed366d9';BRANCH='steward/t2376-green-tree-current-four-20261029';C=Path('/workspace/chicago');R=Path('/tmp/chicago-current-objects-20261025');FLOOR=512*1024**2;RESERVE=16*1024**2;TMPFLOOR=1800000000;METACAP=8*1024**2;CAP=64*1024**2
assert price['tip']==TIP and price['tip_blob_count']==20 and price['tip_blob_raw_bytes']==15181281
sha=lambda b:hashlib.sha256(b).hexdigest();save=lambda n,x:(O/n).write_text(json.dumps(x,indent=2)+'\n');free=lambda p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize
plan={'status':'EXACT72C03_IMPORT_PREPARATION_PLAN_ONLY_NO_MUTATION','tip':TIP,'tree':price['tree'],'expected_primary_HEAD':HEAD,'expected_primary_branch':BRANCH,'expected_origin_dev':OLD,'origin_dev_compare_and_swap_target':TIP,'tip_blobs':20,'tip_blob_raw_bytes':15181281,'tip_blob_compressed_allocation':price['tip_blob_allocated_upper_4k'],'metadata_increment_cap':METACAP,'raw_total_cap':CAP,'workspace_floor':FLOOR,'additional_working_reserve':RESERVE,'unchanged_tmp_caller_floor':TMPFLOOR,'workspace_free':free('/workspace'),'tmp_free':free('/tmp'),'object_allocation_method':'RAM compressed payload -> exclusively created canonical Git object paths, full SHA1/SHA256/type/size readback; no duplicate payload directory','isolated_metadata':'Exact SHA blob:none/no-tags/no-FETCH_HEAD fetch into existing known isolated bare metadata cache, <=8MiB new metadata and unchanged TMP floor continuously enforced','source_guards':'Only at root closed source phase: before/after HEAD/index/config/refs/status plus every dirty/untracked public workingpath bytes/mode; no other source/index/working edits','later_dev':'Import targets immutable72c03 only; newer dev is observed and explicitly unqualified, never silently retargeted','no_primary_source_reads_or_writes_in_PLAN':True};save('PLAN.json',plan)
if not a.execute:print(json.dumps(plan,indent=2));raise SystemExit(0)
assert a.source_phase_lease=='root-closed-GT-source-phase-exact72c03-import'
spec=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(root,*args,input=None):return subprocess.check_output(['git','-C',str(root),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=E,input=input)
def state():
 x=m.snapshot();paths=set(git(C,'diff','--name-only','-z','HEAD').split(b'\0'))|set(git(C,'ls-files','--others','--exclude-standard','-z').split(b'\0'));rows={}
 for raw in paths:
  if not raw:continue
  p=raw.decode();f=C/p
  if not f.exists()and not f.is_symlink():rows[p]={'deleted':True};continue
  assert not f.is_symlink()and f.is_file(),'Refuse dirty link/non-file: '+p
  b=f.read_bytes();rows[p]={'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(f.stat().st_mode)}
 x['dirty_and_untracked_public_workingbytes']=rows;return x
before=state();save('SOURCE-BEFORE.json',before);assert before['HEAD']==HEAD and git(C,'branch','--show-current').decode().strip()==BRANCH and git(C,'rev-parse','origin/dev').decode().strip()==OLD and not(m.G/'MERGE_HEAD').exists();assert free('/workspace')>=FLOOR+RESERVE+price['tip_blob_allocated_upper_4k']+METACAP+1024**2 and free('/tmp')>=TMPFLOOR+METACAP+1024**2
remote=m.api('git/commits/'+TIP);tree=m.api('git/trees/'+remote['tree']['sha']+'?recursive=1');assert tree['sha']==price['tree'] and not tree['truncated'];leaves={r['path']:r for r in tree['tree']if r['type']!='tree'};blobrows={r['sha']:r for r in leaves.values()if r['type']=='blob'};unknown=set(blobrows)-m.indexed(blobrows);assert unknown=={r['sha']for r in price['rows']};assert len(leaves)==18038 and len(blobrows)==17523
save('REMOTE-COMMIT.json',remote);size=lambda:sum(p.stat().st_size for p in(R/'objects').rglob('*')if p.is_file());oldsize=size();abort=None;peak=oldsize
with(O/'EXACT-METADATA-FETCH.log').open('xb')as f:
 q=subprocess.Popen(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',TIP],env=E,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 while q.poll()is None:
  peak=max(peak,size())
  if peak-oldsize>METACAP or free('/tmp')<TMPFLOOR or b'filtering not recognized'in(O/'EXACT-METADATA-FETCH.log').read_bytes().lower():abort='Exact metadata cap/filter/TMP-floor refusal';os.killpg(q.pid,signal.SIGTERM);q.wait();break
  time.sleep(.15)
 rc=q.wait()
save('EXACT-METADATA-FETCH.json',{'exit':rc,'before_bytes':oldsize,'peak_bytes':peak,'delta_cap':METACAP,'abort':abort});assert rc==0 and abort is None
allmeta=set()
for idx in(R/'objects/pack').glob('*.idx'):
 for line in git(R,'show-index',input=idx.read_bytes()).decode().splitlines():allmeta.add(line.split()[1])
for folder in(R/'objects').iterdir():
 if folder.is_dir()and len(folder.name)==2:
  allmeta|={folder.name+p.name for p in folder.iterdir()if p.is_file()and len(p.name)==38}
metaids=allmeta-m.indexed(allmeta);assert len(metaids)<=256;payloads={};rows=[];total=0

def stage(s,kind,b,path):
 global total
 raw=kind.encode()+b' '+str(len(b)).encode()+b'\0'+b;assert hashlib.sha1(raw).hexdigest()==s;enc=zlib.compress(raw);payloads[s]=enc;total+=len(b);assert total<=CAP
 rows.append({'sha':s,'kind':kind,'bytes':len(b),'sha256':sha(b),'encoded_bytes':len(enc),'encoded_sha256':sha(enc),'allocated_upper_4k':((len(enc)+4095)//4096)*4096,'path':path})
if metaids:
 info=git(R,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(sorted(metaids))+'\n').encode()).decode().splitlines();assert sum(int(x.split()[2])for x in info)<=METACAP
 for line in info:
  s,kind,n=line.split();assert kind in {'commit','tree','tag'};b=git(R,'cat-file',kind,s);assert len(b)==int(n);stage(s,kind,b,'isolated exact-SHA metadata')
for r in price['rows']:
 with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+TIP+'/'+quote(r['paths'][0],safe='/'),headers={'User-Agent':'Chicago-exact72c03-canonical-object-import'}),timeout=60)as f:b=f.read(r['bytes']+1);assert f.status==200
 assert len(b)==r['bytes']and sha(b)==r['sha256'];stage(r['sha'],'blob',b,r['paths'][0]);assert rows[-1]['encoded_sha256']==r['encoded_sha256']
feature=m.api('commits/191c10da60b05127362f05ddd24350c7f53d1c8e');save('FEATURE-COMMIT.json',feature)
for r in feature['files']:
 if r['filename'].startswith('chicago/4d/changelog.d/')and r['status']=='added'and r['sha']not in m.indexed([r['sha']])and r['sha']not in payloads:
  ob=m.api('git/blobs/'+r['sha']);b=base64.b64decode(ob['content']);assert len(b)==ob['size']<4096;stage(r['sha'],'blob',b,r['filename'])
allocation=sum(r['allocated_upper_4k']for r in rows);save('ACTUAL-CANONICAL-OBJECT-PLAN.json',{'tip':TIP,'objects':len(rows),'raw_bytes':total,'raw_cap':CAP,'one_copy_allocation_upper':allocation,'rows':rows});assert free('/workspace')>=FLOOR+RESERVE+allocation+1024**2 and free('/tmp')>=TMPFLOOR and state()==before
for r in rows:
 s=r['sha'];assert s not in m.indexed([s]);d=m.G/'objects'/s[:2]/s[2:];assert not d.exists();d.parent.mkdir(exist_ok=True);tmp=d.with_name(d.name+'.exact72-'+str(os.getpid()));enc=payloads[s]
 with tmp.open('xb')as f:f.write(enc);f.flush();os.fsync(f.fileno())
 assert tmp.read_bytes()==enc;os.link(tmp,d);tmp.unlink();os.chmod(d,0o444);raw=zlib.decompress(d.read_bytes());h,b=raw.split(b'\0',1);assert h==r['kind'].encode()+b' '+str(len(b)).encode()and len(b)==r['bytes']and hashlib.sha1(raw).hexdigest()==s and sha(b)==r['sha256'];assert free('/workspace')>=FLOOR+RESERVE and free('/tmp')>=TMPFLOOR
ids={r['sha']for r in leaves.values()};assert ids<=m.indexed(ids);lines=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(sorted(blobrows))+'\n').encode()).decode().splitlines();actualsizes={s:int(n)for s,k,n in(map(str.split,lines))if k=='blob'};assert all(actualsizes[s]==r['size']for s,r in blobrows.items())
actual={}
for line in git(C,'ls-tree','-r','-z',TIP).split(b'\0'):
 if line:
  meta,p=line.split(b'\t');mode,kind,s=meta.decode().split();actual[p.decode()]=(mode,kind,s)
assert actual=={p:(r['mode'],r['type'],r['sha'])for p,r in leaves.items()}and git(C,'merge-base',OLD,TIP).decode().strip()==OLD;assert state()==before
fresh=m.api('git/ref/heads/dev')['object']['sha'];assert fresh==TIP or m.api('compare/'+TIP+'...'+fresh)['status']=='ahead';git(C,'update-ref','refs/remotes/origin/dev',TIP,OLD);after=state();save('SOURCE-AFTER.json',after)
expect=json.loads(json.dumps(before));expect['refs']=[x.replace('refs/remotes/origin/dev '+OLD,'refs/remotes/origin/dev '+TIP)for x in expect['refs']];assert after==expect
save('RESULT.json',{'status':'ACTUAL_EXACT72C03_SINGLECOPY_CANONICAL_IMPORT_ALLTIP_MODES_IDS_SIZES_SOURCEBYTES_GUARDS_AND_EC16_CAS_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tip':TIP,'tree':tree['sha'],'old_origin_dev':OLD,'cached_origin_dev':TIP,'source_head':HEAD,'source_branch':BRANCH,'tip_blobs_full_SHA1_SHA256_size':20,'all_tip_leaves_exact':len(leaves),'all_tip_blob_ids_sizes_exact':len(blobrows),'objects_imported':len(rows),'raw_bytes':total,'allocated_upper':allocation,'all_dirty_untracked_sourcebytes_and_HEAD_index_config_status_otherrefs_preserved':True,'objects_allocated_once_no_local_payload_copies':True,'observed_remote_dev':fresh,'later_dev_unqualified':fresh!=TIP,'workspace_free':free('/workspace'),'tmp_free':free('/tmp'),'source_merge_native_owners_gate_phone_commit_PR_CI_still_pending':True});print((O/'RESULT.json').read_text())
