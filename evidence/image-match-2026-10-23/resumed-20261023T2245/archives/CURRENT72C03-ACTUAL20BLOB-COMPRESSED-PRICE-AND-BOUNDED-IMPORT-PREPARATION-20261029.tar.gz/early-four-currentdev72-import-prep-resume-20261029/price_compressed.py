from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import quote
import json,hashlib,zlib,datetime,os
os.sched_setaffinity(0,{1});os.nice(19)
O=Path(__file__).parent;P=Path('/workspace/early-four-currentdev72-remote-price-no-primary-reads-resume-20261029/RESULT.json');r=json.loads(P.read_text());assert r['dev']=='72c03a0ac4841e7eacd7ae55d0bebd94fd8ca217'and r['missing_blob_ids']==20 and r['missing_raw_bytes']==15181281
rows=[]
for s,x in r['missing_blobs'].items():
 p=x['paths'][0]
 with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+r['dev']+'/'+quote(p,safe='/'),headers={'User-Agent':'Chicago-exact72c03-readonly-compression-price'}),timeout=60)as f:b=f.read(x['bytes']+1);assert f.status==200
 raw=b'blob '+str(len(b)).encode()+b'\0'+b;assert len(b)==x['bytes']and hashlib.sha1(raw).hexdigest()==s;c=zlib.compress(raw)
 rows.append({'sha':s,'kind':'blob','paths':x['paths'],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'encoded_bytes':len(c),'encoded_sha256':hashlib.sha256(c).hexdigest(),'allocated_upper_4k':((len(c)+4095)//4096)*4096})
result={'status':'ACTUAL_READONLY_EXACT20_BLOB_COMPRESSED_PRICE_NO_PAYLOAD_SAVED_OR_OBJECT_IMPORT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tip':r['dev'],'tree':r['tree'],'price_input_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'tip_blob_count':20,'tip_blob_raw_bytes':15181281,'tip_blob_encoded_bytes':sum(x['encoded_bytes']for x in rows),'tip_blob_allocated_upper_4k':sum(x['allocated_upper_4k']for x in rows),'metadata_raw_cap':8*1024**2,'isolated_metadata_fetch_delta_cap':8*1024**2,'total_raw_cap':64*1024**2,'workspace_floor':512*1024**2,'extra_working_headroom':16*1024**2,'unchanged_tmp_caller_floor':1800000000,'workspace_free_now':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize,'tmp_free_now':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'all_raw_payloads_RAM_only_discarded':True,'no_primary_source_refs_index_config_reads_or_writes':True,'rows':rows}
(O/'COMPRESSED-PRICE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2))
