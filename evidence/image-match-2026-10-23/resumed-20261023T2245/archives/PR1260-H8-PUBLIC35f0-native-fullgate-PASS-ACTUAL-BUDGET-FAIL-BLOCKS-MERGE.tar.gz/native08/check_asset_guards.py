from pathlib import Path
import subprocess,json,hashlib,sys
r=Path('/tmp/chicago-log-integration/chicago/4d');o=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'generators'));from mesh_inputs import structure_inputs_sha
get=lambda rev,rel:subprocess.check_output(['git','show',rev+':chicago/4d/'+rel],cwd=r)
incoming=subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=r,text=True).strip()
m=json.loads((r/'assets/manifest.json').read_bytes());old=json.loads(get('HEAD','assets/manifest.json'));d=json.loads(get(incoming,'assets/manifest.json'))
w=json.loads((r/'assets/manifest.web.json').read_bytes());ow=json.loads(get('HEAD','assets/manifest.web.json'));dw=json.loads(get(incoming,'assets/manifest.web.json'))
rows=[]
for name,row in m['assets'].items():
 if row.get('archetype') not in ('log_dwelling','frame_tavern'):
  assert row==d['assets'][name],('Incoming asset row drift',name);continue
 rel=f"data/structures/{row['structure_id']}.json";raw=(r/rel).read_bytes();assert raw==get('HEAD',rel),rel
 rec=json.loads(raw);phase=next(p for p in rec['phases']if p['id']==row['phase_id'])
 assert structure_inputs_sha(rec,phase,row['archetype'])==row['inputs_sha256'],('stale input',name)
 assert row==old['assets'][name],name
 for kind in ('gltf','web'):assert (r/'assets'/kind/name).read_bytes()==get('HEAD',f'assets/{kind}/{name}'),name
 assert w['masters'][name]==ow['masters'][name],name
 rows.append(name)
assert len(rows)==105
for name,value in w['masters'].items():
 if name not in rows:assert value==dw['masters'][name],('Incoming native web row drift',name)
state={'status':'PASS','source_HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'incoming':incoming,'rows':len(rows),'all105_input_hashes_fresh':True,'all105_raw_records_and210_GLBS_exact_source_HEAD':True,'all_unrelated_native_asset_registry_rows_exact_incoming':True,'protected':rows}
p=o/'final-105-asset-guards.json';p.write_text(json.dumps(state,indent=2)+'\n');print('PASS all105 input recipes,105 records and210 GLBs; unrelated native registry rows exact incoming')
