from pathlib import Path
import subprocess,json,datetime,os,hashlib,shutil,sys
r=Path('/tmp/chicago-log-integration/chicago/4d');o=Path(__file__).resolve().parent;now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();git=lambda *a:subprocess.check_output(['git',*a],cwd=r)
assert not git('diff','--name-only').strip(),'Stage every final native result first'
assert not git('ls-files','--others','--exclude-standard').strip(),'Unexpected untracked source'
for f in ['receipt.json','final-105-asset-guards.json']:assert json.loads((Path('/workspace/T3081-T3082-final-dev38-native08')/f).read_bytes())['status']=='PASS'
initial_tree=git('write-tree').decode().strip();incoming=git('rev-parse','MERGE_HEAD').decode().strip();patch=git('diff','--cached','--binary',incoming);(o/'own-final-source-against-incoming.patch').write_bytes(patch)
env={**os.environ,'TMPDIR':'/workspace/tmp-t3081','PATH':'/workspace/shared/tools/usr/bin:'+os.environ['PATH'],'CHECK_JOBS':'4','C4D_GATE_REQUIRE_READERS':'1','PYTHONDONTWRITEBYTECODE':'1'}
s={'status':'RUNNING','started':now(),'controller_pid':os.getpid(),'HEAD':git('rev-parse','HEAD').decode().strip(),'incoming':incoming,'index_tree':initial_tree,'source_patch_against_incoming_sha256':hashlib.sha256(patch).hexdigest(),'command':['bash','./tools/preflight.sh'],'CHECK_JOBS':4,'C4D_GATE_REQUIRE_READERS':1};save=lambda:(o/'receipt.json').write_text(json.dumps(s,indent=2)+'\n');save()
with(o/'preflight.log').open('x')as f:
 p=subprocess.Popen(s['command'],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT);s['child_pid']=p.pid;save();rc=p.wait()
s.update(exit_code=rc,finished=now(),status='PASS'if rc==0 else'FAILED',source_bytes_unchanged=git('write-tree').decode().strip()==initial_tree and not git('diff','--name-only').strip() and git('diff','--cached','--binary',incoming)==patch)
for name,src in [('check.log','/tmp/preflight-check.log'),('changelog.log','/tmp/preflight-cl.log'),('ids.log','/tmp/preflight-ids.log')]:
 if Path(src).exists():shutil.copy2(src,o/name);s[name+'_sha256']=hashlib.sha256((o/name).read_bytes()).hexdigest()
if not s['source_bytes_unchanged']:s['status']='FAILED_SOURCE_MOVED'
save();print(json.dumps(s,indent=2));sys.exit(0 if s['status']=='PASS'else(rc or 2))
