"""Run the reviewed native source gate, ordinary one-parent CP, three PR questions,
and normal remote FF. Runtime, required CI, PR body and dev merge remain separate.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Y='fb1cb6f7046ef5b2470a7343e7b6d49262c6fe81'
D='3de1877c4e9260cd9b94ea3d4af319525973b677'
LAP='/workspace/PR1456-official-native-lap-closed-provenance-monitor-20261030/RESULT.json'
LAPSHA='d61cb44494a38323e79cf4f4c83fe474f47d16cbf88d0b1f0f816e863ac7b0ef'

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for k in ['reviewed-manifest','reviewed-manifest-sha256','capsule-sha256','message-file','expected-lap','output']:ap.add_argument('--'+k,required=True)
 ap.add_argument('--execute',action='store_true');a=ap.parse_args();assert a.execute
 os.sched_setaffinity(0,{0,1,3,4});os.nice(19)
 assert sha(P/'CLOSED-MANIFEST.json')==a.capsule_sha256
 cap=json.loads((P/'CLOSED-MANIFEST.json').read_bytes())
 for name,row in cap['members'].items():assert sha(P/name)==row['sha256']
 assert sha(a.reviewed_manifest)==a.reviewed_manifest_sha256
 m=json.loads(Path(a.reviewed_manifest).read_bytes());assert m['root_reviewed'] is True and m['status']=='ROOT_REVIEWED_PR1456_ONE_PARENT_REPAIR_STAGED' and m['source_head']==Y and m['parents']==[Y] and m['canonical_dev']==D and sha(a.message_file)==m['checkpoint_message_sha256']
 o=Path(a.output).resolve();assert o.is_relative_to('/workspace') and not o.is_relative_to('/workspace/t2372-parallel-native-20261030') and not o.is_relative_to('/workspace/chicago') and not o.exists();o.mkdir()
 def save(n,x):(o/n).write_text(json.dumps(x,indent=2)+'\n')
 def pin(p):return {'path':str(Path(p).resolve()),'sha256':sha(p)}
 save('OWNER.json',{'pid':os.getpid(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_ONE_PARENT_REPAIR_GATE_CP_FF_STARTED_PENDING','source_head':Y,'intended_parents':[Y],'canonical_dev':D,'reviewed_manifest':pin(a.reviewed_manifest),'capsule':pin(P/'CLOSED-MANIFEST.json'),'no_fake_Y_checkpoint':True})
 def run(name,cmd):
  save(name+'-START.json',{'argv':cmd,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
  with (o/(name+'.log')).open('xb') as log:q=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  save(name+'-CLOSED.json',{'exit':q.returncode,'log':pin(o/(name+'.log'))});assert q.returncode==0,(name,q.returncode)
 try:
  gate=o/'native'
  run('gate',['python3','-B',str(P/'gate.py'),'--reviewed-manifest',a.reviewed_manifest,'--lap-provenance',LAP,'--lap-provenance-sha256',LAPSHA,'--canonical-dev',D,'--output',str(gate),'--execute'])
  run('checkpoint',['python3','-B',str(P/'checkpoint.py'),'--gate-dir',str(gate),'--message-file',a.message_file,'--execute'])
  cp=json.loads((gate/'CHECKPOINT-RESULT.json').read_bytes());assert cp['status']=='ACTUAL_PR1456_ONE_PARENT_REPAIR_NATIVE_ONE_PARENT_CHECKPOINT_PASS' and cp['parents']==[Y]
  run('publication',['python3','-B',str(P/'publish_native.py'),'--canonical-dev',D,'--checkpoint',str(gate/'CHECKPOINT-RESULT.json'),'--expect-head',cp['head'],'--expected-old',Y,'--expected-lap',a.expected_lap,'--output',str(o/'publication'),'--publish'])
  result=json.loads((o/'publication/RESULT.json').read_bytes());assert result['force'] is False and result['expected_old']==Y and result['head']==cp['head'] and result['parents']==[Y] and len(result['readback'])==2
  for name,row in cap['members'].items():assert sha(P/name)==row['sha256']
  assert sha(a.reviewed_manifest)==a.reviewed_manifest_sha256
  save('RESULT.json',{'status':'ACTUAL_PR1456_ONE_PARENT_REPAIR_NATIVE_GATE_CP_NORMAL_FF_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':cp['head'],'tree':cp['tree'],'parents':[Y],'source_gate':pin(gate/'GATE-RESULT.json'),'checkpoint':pin(gate/'CHECKPOINT-RESULT.json'),'publication':pin(o/'publication/RESULT.json'),'root_reviewed_manifest':pin(a.reviewed_manifest),'helper_capsule':pin(P/'CLOSED-MANIFEST.json'),'actual_LAP_Y_provenance':pin(LAP),'only_two_native_generated_outputs_repaired':True,'Y_not_given_fake_source_CP_or_preservation_PASS':True,'runtime_required_CI_PR_body_and_dev_merge_pending':True})
 except BaseException as e:
  save('ERROR.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'error':repr(e),'actual_gate_exists':(o/'native/GATE-RESULT.json').exists(),'actual_CP_exists':(o/'native/CHECKPOINT-RESULT.json').exists(),'actual_FF_exists':(o/'publication/RESULT.json').exists(),'no_force_or_dev_merge_requested':True});raise
 print((o/'RESULT.json').read_text())
if __name__=='__main__':main()
