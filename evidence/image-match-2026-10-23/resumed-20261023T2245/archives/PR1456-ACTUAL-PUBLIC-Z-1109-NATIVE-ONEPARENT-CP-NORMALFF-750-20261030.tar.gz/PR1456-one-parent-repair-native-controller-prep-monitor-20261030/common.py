"""Native full guards for an honest one-parent repair of two stale official-LAP outputs; actual Y is provenance, never a fake prior CP."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,shutil,subprocess,time
R=Path('/workspace/t2372-parallel-native-20261030');A=R/'chicago/4d';P=Path(__file__).resolve().parent
SOURCE=None;DEV=None;LAP=None;SHIM=Path('/workspace/PR1456-genuine54-lean-gate-v2-secondfort-20261030')
DEP='40453bde8ba1812925d61fef118782a30323f98e';BRANCH='steward/t2381-t2373-t2384-t2377-early-pictures-20261029'
TICKETS={'T-2381','T-2373','T-2384','T-2377'};REV='PR1456_ONE_PARENT_REPAIR'
PERF=['chicago/4d/renderers/web/js/railway.js','chicago/4d/tools/test_rail_geometry_lifecycle.mjs','chicago/4d/renderers/web/js/spatial-batch.js','chicago/4d/tools/check_confidence_lane.mjs']
FIXTURE_SHA='3a481450fb9324d285a08492a526e657a39f51d64aa918ee3f39cb6418bc4289'
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
sha=lambda b:hashlib.sha256(b).hexdigest();pf=lambda p:sha(Path(p).read_bytes());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def g(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def save(o,n,d):(o/n).write_text(json.dumps(d,indent=2)+'\n')
def refs():return dict(x.split(' ',1)for x in g('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines())
def index():return {k:sha(g(*a))for k,a in [('stage',('ls-files','--stage','-z')),('flags',('ls-files','-v','-z'))]}
def pathsha(rel):
 p=R/rel
 if not p.exists():assert not p.is_symlink();return None
 assert p.is_file()and not p.is_symlink();return pf(p)
def entries(commit=None):
 out={};raw=g('ls-tree','-rz',commit)if commit else g('ls-files','--stage','-z')
 for row in raw.split(b'\0'):
  if not row:continue
  meta,p=row.split(b'\t');a,b,c=meta.decode().split()
  if commit:assert b=='blob';mode,oid=a,c
  else:assert c=='0';mode,oid=a,b
  out[p.decode()]={'mode':mode,'blob':oid}
 return out
def proofs(rows):
 assert rows
 for row in rows:
  p=Path(row['path']);assert p.is_absolute()and p.is_file()and not p.is_symlink()and str(p).startswith('/workspace/')
  assert pf(p)==row['sha256']
def load(path):
 raw=Path(path).read_bytes();m=json.loads(raw)
 assert m['status']=='ROOT_REVIEWED_PR1456_ONE_PARENT_REPAIR_STAGED'and m['root_reviewed']is True
 assert m['source_head']==SOURCE and m['canonical_dev']==DEV and m['branch']==BRANCH
 assert re.fullmatch('[0-9a-f]{40}',m['tree'])and isinstance(m['expected_steps'],int)and 1000<=m['expected_steps']<=1200
 rows=m['staged_paths'];assert set(rows)=={'chicago/4d/data/liberties.json','chicago/4d/docs/measurements/source_use_coverage.md'};assert m['parents']==[SOURCE] and m['source_lap_provenance']=={'path':LAP['path'],'sha256':LAP['sha256']}
 for p,h in rows.items():assert not Path(p).is_absolute()and'..'not in Path(p).parts and(h is None or re.fullmatch('[0-9a-f]{64}',h))
 own=m['owned_original'];foreign=m['canonical_foreign_entrywise'];assert own['source_commit']=='3746b23bf1298c34a29946b4cdb6ee2d98abff8f'and set(own['tickets'])==TICKETS
 assert foreign['canonical_commit']==DEV and foreign['all_foreign_protected']is True
 proofs(own['proof_files']);proofs(foreign['proof_files']);proofs(m['new_owned_path_proof_files'])
 assert set(m['required404_dependency_paths'])==set(PERF[:2])and set(m['protected404_performance_paths'])==set(PERF[2:])
 for p,h in {**m['required404_dependency_paths'],**m['protected404_performance_paths']}.items():assert h==sha(g('show',DEP+':'+p))
 assert m['fixture_shim_sha256']==pf(SHIM/'bin/node')and m['fixture_test_sha256']==FIXTURE_SHA
 price=m['resource_price'];proofs(price['proof_files'])
 assert price['log_temp_reserve_bytes']>=96*1048576 and price['publication_reserve_bytes']>=359456768 and price['ignored_source_reserve_bytes']>=0 and price['ticket_reserve_bytes']>=0
 assert price['guard_reserve_bytes']>=32*1048576 and 0<=price['import_reserve_bytes']<=32*1048576
 assert price['native_transient_reserve_bytes']>=1500000000,'Actual ~1.538GB native DRIFT_ROOTS scratch price required in addition to96MiB log reserve'
 assert 4600000000>=price['clone_phase_limit_bytes']>=price['clone_projected_allocation_bytes']>0
 assert re.fullmatch('[0-9a-f]{64}',m['source_config_sha256'])
 return m,sha(raw)
def check(m,merging=True):
 assert g('rev-parse','HEAD').decode().strip()==SOURCE and g('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 assert g('rev-parse','origin/dev').decode().strip()==DEV
 assert not(R/'.git/MERGE_HEAD').exists()
 assert g('write-tree').decode().strip()==m['tree']
 assert not g('diff','--name-only')and not g('ls-files','-u')and not g('ls-files','--others','--exclude-standard')
 actual=set(g('diff','--cached','--name-only').decode().splitlines());assert actual==set(m['staged_paths'])
 ix=entries();canon=entries(DEV);full_working_bytes(ix)
 for p,h in m['staged_paths'].items():
  assert pathsha(p)==h
  if h is None:assert p not in ix
  else:
   b=(R/p).read_bytes();assert ix[p]['blob']==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 own=m['owned_original']['reviewed_paths'];mixed=m['canonical_foreign_entrywise']['mixed_paths'];repair=m['new_owned_path_sha256'];assert set(repair)=={'chicago/4d/tools/smoke_renderer.mjs','chicago/4d/renderers/web/js/yard.js'};allowed=set(own)|set(mixed)|set(m['required404_dependency_paths'])|set(repair)
 assert not(set(own)&set(mixed))and not((set(own)|set(mixed))&set(m['required404_dependency_paths'])),'Ownership classes must be explicit and disjoint'
 assert not(set(repair)&(set(own)|set(mixed)|set(m['required404_dependency_paths'])));assert allowed and all(pathsha(p)==h for p,h in {**own,**mixed,**repair}.items())
 for p in set(ix)|set(canon):
  if p not in allowed:assert ix.get(p)==canon.get(p),('Foreign canonical mode/blob/deletion changed',p)
 for p in m['canonical_foreign_entrywise']['exact_paths']:assert ix.get(p)==canon.get(p)
 for p,h in {**m['required404_dependency_paths'],**m['protected404_performance_paths']}.items():assert pathsha(p)==h
 assert pf(R/'.git/config')==m['source_config_sha256']and pf(A/'tools/test_repo_file.mjs')==FIXTURE_SHA
 proofs(m['owned_original']['proof_files']);proofs(m['canonical_foreign_entrywise']['proof_files']);proofs(m['new_owned_path_proof_files'])
 proofs(m['resource_price']['proof_files'])
 ticket_context(m)
 for p,h in m['ignored_dependencies']['source_sha256'].items():assert pathsha(p)==h
 return dict(index=index(),refs=refs(),config=pf(R/'.git/config'))
def ticket_context(m,previous=None):
 d=m['ignored_dependencies'];t=A/'tickets';assert(t/'.git').is_dir()and(t/'QUEUE.md').is_file()
 tg=lambda *a:subprocess.check_output(['git','-C',str(t),*a],env=E)
 assert d['canonical_origin']=='https://github.com/kevinrhaas/chicago-tickets.git'and d['tickets_branch']=='main'
 assert tg('remote','get-url','origin').decode().strip()==d['canonical_origin']and tg('branch','--show-current').decode().strip()=='main'
 assert not tg('status','--porcelain=v1','--untracked-files=all');head=tg('rev-parse','HEAD').decode().strip();assert head==tg('rev-parse','origin/main').decode().strip()
 for anchor in [d['tickets_head']]+([previous]if previous else[]):tg('merge-base','--is-ancestor',anchor,head)
 ids=set();assert len(d['ticket4_sha256'])==4 and'chicago/4d/tickets/QUEUE.md'not in d['source_sha256']
 for rel,h in d['ticket4_sha256'].items():
  f=t/rel;assert not Path(rel).is_absolute()and'..'not in Path(rel).parts and pf(f)==h;body=f.read_text();ids.add(re.search(r'^id: (T-\d+)$',body,re.M).group(1));assert '\npr: 1456\n'in body and'\nstate: review\n'in body
 assert ids==TICKETS
 return dict(head=head,QUEUE_sha256=pf(t/'QUEUE.md'),branch='main',canonical_origin=d['canonical_origin'],ticket4_sha256=d['ticket4_sha256'])
def resource(m,reserve=False):
 p=m['resource_price'];extra=sum(p[k]for k in ['publication_reserve_bytes','ignored_source_reserve_bytes','ticket_reserve_bytes','log_temp_reserve_bytes','guard_reserve_bytes','import_reserve_bytes','native_transient_reserve_bytes'])if reserve else 0
 ws=shutil.disk_usage('/workspace').free;tmp=shutil.disk_usage('/tmp').free
 alloc=int(subprocess.check_output(['du','-s','-B1',str(R)]).split()[0]);cap=p['clone_phase_limit_bytes']
 return dict(workspace_free=ws,shared_TMP_free=tmp,workspace_required=536870912+extra,shared_TMP_required=1800000000,workspace_pass=ws>=536870912+extra,shared_TMP_pass=tmp>=1800000000,clone_allocation=alloc,clone_phase_limit=cap,clone_cap_pass=alloc<=cap)
def native(o,name,cmd):
 rp=o/(name+'-REAPER.json');assert not rp.exists();t=time.monotonic()
 argv=['python3','/workspace/shared/run-with-reaping.py',str(rp),'--','nice','-n','19','taskset','-c','0,1,3,4',*cmd]
 with(o/(name+'.log')).open('xb')as log:q=subprocess.run(argv,cwd=A,env=E,stdout=log,stderr=subprocess.STDOUT)
 r=json.loads(rp.read_bytes());return dict(name=name,command=cmd,argv=argv,exit=q.returncode,seconds=time.monotonic()-t,reaper=str(rp),reaper_sha256=pf(rp),log=str(o/(name+'.log')),log_sha256=pf(o/(name+'.log'))),r
def env(o):
 tmp=o/'tmp';tmp.mkdir(exist_ok=True);(tmp/'OWNER.json').write_text(json.dumps(dict(owner=REV,source=SOURCE,merge=DEV))+'\n')
 E.update(CHECK_JOBS='4',CHECK_TIMINGS=str(o/'TIMINGS.tsv'),C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),NODE_COMPILE_CACHE=str(tmp/'node-compile-cache'),PATH=str(SHIM/'bin')+':'+E['PATH'],PR1456_FIXTURE_LOG=str(o/'NODE-INVOCATIONS.jsonl'))
def configure(lap_path,expected_sha,canonical_dev):
 global SOURCE,LAP,DEV
 SOURCE='fb1cb6f7046ef5b2470a7343e7b6d49262c6fe81';DEV=canonical_dev;assert DEV=='3de1877c4e9260cd9b94ea3d4af319525973b677'
 p=Path(lap_path).resolve();raw=p.read_bytes();assert sha(raw)==expected_sha=='d61cb44494a38323e79cf4f4c83fe474f47d16cbf88d0b1f0f816e863ac7b0ef';lap=json.loads(raw)
 assert lap['status']=='ACTUAL_NATIVE_PR1456_OFFICIAL_LAP_PUSH_AND_OWN_LOCK_REACQUIRE_PASS' and lap['bot_head']==SOURCE and lap['bot_tree']=='5aee8ef527cbbaa1f3cae3374bad4f8039a57a41' and lap['before_head']=='a3ce922cf74d367f3e9656eaf5ab510903bc689a' and lap['normal_fast_forward'] is True and lap['PR']==1456 and lap['branch']==BRANCH
 for k in ['workflow_run','actual_job','actual_job_log','own_release','own_reacquire','dispatch','predecessor_checkpoint','predecessor_publication']:proofs([lap[k]])
 run=json.loads(Path(lap['workflow_run']['path']).read_bytes());job=json.loads(Path(lap['actual_job']['path']).read_bytes());text=Path(lap['actual_job_log']['path']).read_text()
 assert run['status']==job['status']=='completed' and run['conclusion']==job['conclusion']=='success' and run['path']=='.github/workflows/chicago-4d-pr-lap.yml' and run['head_branch']=='dev' and run['head_sha']==DEV and job['run_id']==run['id']
 assert re.search(r'=== PR #1456\s+\('+re.escape(BRANCH)+r'\)',text) and 'pushed a3ce922cf → fb1cb6f70' in text
 cp=json.loads(Path(lap['predecessor_checkpoint']['path']).read_bytes());pub=json.loads(Path(lap['predecessor_publication']['path']).read_bytes())
 assert lap['predecessor_checkpoint']['sha256']=='23f0354e30763f453396c5f0ade02f956529fe872e06f938d19becf9825a0d7a' and lap['predecessor_publication']['sha256']=='7fd186317331ecc7dfa522abe1d82d0b744c2ecf9e739f99ed9f7a7abe97f4ac'
 assert cp['head']==pub['head']==lap['before_head'] and cp['clean'] is True and pub['force'] is False and pub['checkpoint_sha256']==lap['predecessor_checkpoint']['sha256']
 sgraw=Path(cp['source_gate']).read_bytes();sg=json.loads(sgraw);assert sha(sgraw)==cp['source_gate_sha256'] and sg['status']=='ACTUAL_PR1456_GENUINE_NAMED_DEV_FULL_SOURCE_PASS' and all(v is True for v in sg['guards'].values())
 assert g('show','-s','--format=%P',SOURCE).decode().strip().split()==[lap['before_head'],DEV] and g('rev-parse',SOURCE+'^{tree}').decode().strip()==lap['bot_tree'];g('merge-base','--is-ancestor',DEV,SOURCE)
 LAP=dict(path=str(p),sha256=expected_sha,head=SOURCE,tree=lap['bot_tree'],parents=[lap['before_head'],DEV],status=lap['status'],predecessor_checkpoint=lap['predecessor_checkpoint'],predecessor_publication=lap['predecessor_publication'])
def full_working_bytes(ix):
 for rel,row in ix.items():
  p=R/rel;mode=row['mode']
  if mode=='120000':assert p.is_symlink();raw=os.readlink(p).encode()
  else:
   assert mode in ['100644','100755']and p.is_file()and not p.is_symlink(),rel
   assert bool(p.stat().st_mode&0o111)==(mode=='100755'),rel;raw=p.read_bytes()
  assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['blob'],rel
