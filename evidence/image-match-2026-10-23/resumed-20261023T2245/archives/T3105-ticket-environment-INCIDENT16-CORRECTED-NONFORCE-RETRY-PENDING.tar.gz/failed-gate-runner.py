from pathlib import Path
import subprocess,os,json,hashlib,datetime,shutil
O=Path(__file__).resolve().parent;A=Path('/tmp/chicago-log-integration/chicago/4d');H=O.parent
assert json.loads((H/'H9-integration-actual/FINAL-GUARDS.json').read_text())['status'].startswith('PASS_')
start=datetime.datetime.now(datetime.timezone.utc).isoformat();env={**os.environ,'TMPDIR':'/workspace/T3105-tmp','PATH':'/workspace/shared/tools/usr/bin:'+os.environ['PATH'],'npm_config_cache':'/workspace/shared/npm-cache','PYTHONDONTWRITEBYTECODE':'1','C4D_GATE_REQUIRE_READERS':'1','CHECK_JOBS':'4','CHICAGO_TICKETS_DIR':'/workspace/chicago-tickets','BASE':'origin/dev'}
with(O/'preflight.log').open('x')as f:r=subprocess.run(['bash','tools/preflight.sh'],cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT)
for name in['preflight-check.log','preflight-cl.log','preflight-ids.log']:
 p=Path('/tmp')/name
 if p.exists():shutil.copy2(p,O/name)
d={'status':'PASS'if r.returncode==0 else'FAIL','exit_code':r.returncode,'start':start,'finish':datetime.datetime.now(datetime.timezone.utc).isoformat(),'HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=A,text=True).strip(),'required_readers':True,'jobs':4,'log':str(O/'preflight.log'),'scope':'Actualfullcurrentworkingtreebeforecommits; finalcommittedHEADchangelog/IDchecksrunagainaftertwoutilitycommits. No model/sourceacceptanceimplied.'};(O/'RESULT.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2));raise SystemExit(r.returncode)
