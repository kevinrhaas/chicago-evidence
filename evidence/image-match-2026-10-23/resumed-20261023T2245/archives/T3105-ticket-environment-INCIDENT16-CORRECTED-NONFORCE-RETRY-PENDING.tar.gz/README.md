# Closed ticket-environment incident

The first T3105 full preflight inherited CHICAGO_TICKETS_DIR=/workspace/chicago-tickets. Native isolated ticket fixtures inherited that override and wrote sixteen unintended commits to the real remote. This was an orchestration error; no app or assertion defect was inferred. Eleven fixture groups failed. The exact failed gate remains preserved.

The eight changed paths were QUEUE, T0001–T0003 and four artificial T3119–T3122 filings. All other tracked ticket files were unchanged. Normal additive correction d300fd03bbc0301c9cd0e075c8e3964f0fee1a09 restores the whole tracked ticket tree exactly to genuine pre-gate958cdd884c5ff7e5fcfcd25c17a4fc1bdd7b83c4. No force push or history rewriting was used. The Git bundle preserves all sixteen raw commits, including their intermediate states. Remote readback and exact-tree checks passed. An off-main discarded fixture commit is preserved in reflog, not classified as a pushed main change.

The unchanged mirror fixture passed with only the override removed. The new full gate explicitly removes the override and asserts it is absent before invoking preflight. No assertion changes or fixture bypass. This packet closes the incident diagnosis/correction only; the retry gate was running when captured and its final result is not claimed. Operational native commands retain their explicit repository argument.

After corrective remote readback, the normal T3106 claim joined T3105 without force; both utilities retain normal full acceptance. The What's New group was separately reduced to exactly two total items as requested. Original T3041/T2387 every-picture scope remains open/DIFFERS.
