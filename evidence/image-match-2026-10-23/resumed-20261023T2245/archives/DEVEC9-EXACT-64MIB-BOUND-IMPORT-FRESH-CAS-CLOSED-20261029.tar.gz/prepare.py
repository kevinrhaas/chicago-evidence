from pathlib import Path
import os,json,subprocess,hashlib,shutil,time,datetime,signal,zlib,urllib.request,urllib.parse,struct
os.sched_setaffinity(0,{1});os.nice(19)
B=Path(__file__).parent;C=Path('/workspace/chicago');G=C/'.git';R=Path('/tmp/chicago-current-objects-20261025');OLD='2d2f258ec73a90c9946f1b6694a839dff3ee20fc';TIP='ec9f5c932763e3a40df8cb15496d888df50f6a37';CAP=64*1024**2;ENVELOPE=CAP;FLOOR=512*1024**2
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(r,*args,input=None):return subprocess.check_output(['git','-C',str(r),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1',*args],env=env,input=input)
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+p]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':git(C,'rev-parse','HEAD').decode().strip(),'refs':git(C,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:sha(G/n)for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status_sha256':hashlib.sha256(git(C,'status','--porcelain','-z')).hexdigest()}
def indexed(ids):
 wanted=set(ids);found=set();obj=G/'objects'
 for s in wanted:
  if(obj/s[:2]/s[2:]).is_file():found.add(s)
 for idx in(obj/'pack').glob('*.idx'):
  remaining=wanted-found
  if not remaining:break
  with idx.open('rb')as f:
   head=f.read(8);v2=head[:4]==b'\xfftOc';off=8 if v2 else 0
   if v2:assert struct.unpack('>I',head[4:])[0]==2
   f.seek(off);fan=struct.unpack('>256I',f.read(1024));table=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
   for s in remaining:
    key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
    while a<z:
     m=(a+z)//2;f.seek(table+m*stride+delta);value=f.read(20)
     if value<key:a=m+1
     else:z=m
    f.seek(table+a*stride+delta)
    if a<fan[key[0]]and f.read(20)==key:found.add(s)
 return found


from concurrent.futures import ThreadPoolExecutor,as_completed
import base64
P=Path('/tmp/current-dev-ec9f-readonly-price-20261029');payload=Path('/workspace/shared/DEV-ec9f-encoded-payload-20261029');payload.mkdir(exist_ok=True)
price=json.loads((P/'PRICE.json').read_text());tree=json.loads((P/'TREE.json').read_text());leaves=[r for r in tree['tree']if r['type']!='tree'];missing=price['missing'];assert len(missing)==46 and sum(r['size']for r in missing)==36173291
before=snap();save('PREPARE-SOURCE-BEFORE.json',before);assert git(C,'rev-parse','origin/dev').decode().strip()==OLD
remote=api('git/ref/heads/dev');save('PREPARE-REMOTE.json',remote);assert remote['object']['sha']==TIP
with(B/'metadata-fetch.log').open('xb')as log:
 p=subprocess.Popen(['git','-C',str(R),'-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=1','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','https://github.com/kevinrhaas/chicago.git',TIP],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);abort=None;peak=0
 while p.poll()is None:
  size=sum(f.stat().st_size for f in(R/'objects').rglob('*')if f.is_file());peak=max(peak,size)
  if size>32*1024**2 or b'filtering not recognized'in(B/'metadata-fetch.log').read_bytes().lower():abort='filter/isolationbound';os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(.15)
 rc=p.wait()
save('METADATA-FETCH.json',{'exit':rc,'peak':peak,'abort':abort,'cap':32*1024**2});assert rc==0 and not abort
actual={}
for row in git(R,'ls-tree','-r','-z',TIP).split(b'\0'):
 if row:
  a,n=row.split(b'\t',1);m,t,s=a.decode().split();actual[n.decode()]={'mode':m,'type':t,'sha':s}
assert actual=={r['path']:{k:r[k]for k in ['mode','type','sha']}for r in leaves}
metadata={};packs=[]
for pack in sorted((R/'objects/pack').glob('*.pack')):
 if(G/'objects/pack'/pack.name).exists():continue
 ids=[]
 for line in git(R,'verify-pack','-v',str(pack.with_suffix('.idx'))).decode().splitlines():
  c=line.split()
  if len(c)>4 and len(c[0])==40 and c[1]in['commit','tree','tag','blob']:assert c[1]!='blob';ids.append(c[0])
 known=indexed(ids)
 for line in git(R,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines():
  obj,kind,size=line.split()
  if obj not in known:metadata[obj]={'kind':kind,'canonical_bytes':int(size)}
 packs.append(str(pack))
for name in ['LODGE-FEATURE','WALL-FEATURE']:
 feature=json.loads((P/(name+'.json')).read_text())
 for row in feature['files']:
  if row['filename'].startswith('chicago/4d/changelog.d/')and row['status']=='added'and row['sha']not in indexed([row['sha']]):
   ob=api('git/blobs/'+row['sha']);assert ob['encoding']=='base64';data=base64.b64decode(ob['content']);assert len(data)==ob['size']<4096;raw=b'blob '+str(len(data)).encode()+b'\0'+data;assert hashlib.sha1(raw).hexdigest()==row['sha'];f=payload/row['sha'];f.write_bytes(zlib.compress(raw));metadata[row['sha']]={'kind':'blob','canonical_bytes':len(data),'payload':str(f),'intermediate_path':row['filename']}
def fetch(row):
 for attempt in range(3):
  try:
   with urllib.request.urlopen('https://raw.githubusercontent.com/kevinrhaas/chicago/'+TIP+'/'+urllib.parse.quote(row['path'],safe='/'),timeout=90)as response:data=response.read(row['size']+65536)
   break
  except Exception:
   if attempt==2:raise
   time.sleep(1+attempt)
 raw=b'blob '+str(len(data)).encode()+b'\0'+data;assert len(data)==row['size']and hashlib.sha1(raw).hexdigest()==row['sha'];enc=zlib.compress(raw);f=payload/row['sha'];assert not f.exists();f.write_bytes(enc);assert hashlib.sha1(zlib.decompress(f.read_bytes())).hexdigest()==row['sha'];return {'path':row['path'],'sha':row['sha'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoded_bytes':len(enc),'payload':str(f)}
rows=[]
with ThreadPoolExecutor(max_workers=4)as ex:
 for future in as_completed([ex.submit(fetch,row)for row in missing]):rows.append(future.result());save('PREPARE-DOWNLOAD-PROGRESS.json',{'complete':len(rows),'total':len(missing)})
raw=sum(r['size']for r in missing)+sum(x['canonical_bytes']for x in metadata.values());assert raw<=CAP
save('PREPARED-PAYLOAD.json',{'old':OLD,'tip':TIP,'tree':tree['sha'],'tip_blob_rows':rows,'metadata':metadata,'pack_paths':packs,'canonical_raw_total':raw,'standing_raw_cap':CAP,'payload_allocated_bytes':sum(p.stat().st_blocks*512 for p in payload.iterdir()),'workspace_floor':FLOOR,'qualification':'Two individually inspecteddisjoint1904feature+foldpairs aggregateunder64MiB. PreparationONLY; sharedsourceobjects/refsunmodified.'});after=snap();save('PREPARE-SOURCE-AFTER.json',after);source_same=after['refs']==before['refs']and after['HEAD']==before['HEAD']and after['metadata']==before['metadata']
result={'status':'EXACT_EC9F_PAYLOAD_PREPARED_NO_SHARED_OBJECT_OR_REF_WRITES','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tip':TIP,'new_tip_blobs':len(rows),'canonical_raw_total':raw,'standing_raw_cap':CAP,'payload_allocated_bytes':sum(p.stat().st_blocks*512 for p in payload.iterdir()),'source_refs_HEAD_index_config_merge_unchanged':source_same,'preparation_has_shared_source_object_or_ref_writes':False,'note':'Authors may independentlycommitduringread-onlypreparation; actualmutationrequiresfreshstablebeforeafterguards.','workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free};save('PREPARE-RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
