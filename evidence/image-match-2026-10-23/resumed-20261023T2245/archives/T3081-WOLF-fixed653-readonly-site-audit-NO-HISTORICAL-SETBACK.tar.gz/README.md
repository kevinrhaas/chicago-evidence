# Current Wolf Point site audit — T3081

This is a read-only LIGHT audit of the integration worktree on parent96, after
root fixed the side-entry consumer and wrote the 653-door native entrance output.
The complete observed inputs and imported project source modules are regular
files under `inputs/`; `site-audit.json` binds all 70 files by SHA256.

## Model clearances

All distances below are between current model geometry. They do not establish a
historical setback. The record retains about 40 m along-bank and 20 m across-bank
placement uncertainty. The reconstructed concave body occupies 61.5 square metres;
its world bounds are E -78.85 to -68.75, N -54.70 to -47.50 in project-local metres.
The empty corner of its bounding box is not treated as occupied ground.

| Current region | Distance to river/west bank | Lowest sampled raw ground over water datum |
| --- | ---: | ---: |
| Occupied concave body | 3.6879 m | 0.8125 m |
| Primary east-facing apron | 2.1746 m | 0.5675 m |
| Primary doorway clearance zone | 3.6111 m | 0.8093 m |
| Additional south-facing apron | 11.4517 m | 1.0017 m |
| Additional doorway clearance zone | 12.5611 m | 1.0040 m |

Every region is disjoint from the actual `chicago_river_forks` water polygon and
all four water outer rings carried by the native forks, branch and harbor files.
The nearest line is the traced West Division shore. No shoreline or clearance
tolerance was introduced. EPSG:26916 coordinates are converted using exactly the
origin in `data/datum.json`, as the GeoJSON's own documentation specifies.

The actual shared side-face reader and native entrance output agree:

| Entry | Threshold local E,N | Outward bearing | Native path depth |
| --- | --- | ---: | ---: |
| Primary +Y face | -68.75, -51.05 | 90°, east | 3.4 m |
| Additional +X face | -75.50, -54.70 | 180°, south | 3.4 m |

Both native apron rings match the source functions exactly. The clearance zones
use the existing 0.30 m at each side and 1.80 m outward. Terrain heights use the
native raw bilinear heightfield reader at the existing clearance tool's maximum
0.10 m boundary-sample step. All samples lie within the real heightfield. These
are sampled ground elevations, not mesh-contact certification or a new dry-ground
acceptance threshold.

## Current objects and historical four

The actual native `measure_doorways.objects()` reader reports 3,515 placed point
or fence-segment records. None lies inside the occupied body, and none intersects
either actual declared doorway clearance zone. This includes the fixed side
entry. The source reader's existing own-stoop floor rule is retained; no new
allowance or exemption was added.

All four historical intrusion coordinates in the earlier centre-preserving trial
are absent from current outputs. The current Wolf frontage has one barrel at
(-68.20,-48.31) and one crate at (-68.20,-49.60). Each centre is 0.55 m outside the
current occupied footprint. These are newly read native placements, not the old
four accepted as exceptions. Object radii and mesh extents are outside this
point/segment instrument's claim.

## Side-entry omission found and repaired

The earlier audit saw only one native Wolf entry: the consumer checked a
nonexistent sidecar `form` while compiled sidecars carry those fields under
`attributes`, then passed the sidecar directly to a phase reader. Native drift
checks could reproduce that omission. `pre-fix-observation.json` preserves this
separate historical finding; it is not the current result.

Root repaired the reader to load the exact sidecar-selected phase by id and pass
that real phase and record to the builder's parameter reader. The fixed consumer
hash in this audit is
`3f87c62ebe2af44699998c723351df9e87baab4b18e2135cbbc397e4369b11b3`.
The final snapshot independently reads 653 entries for 651 buildings and both
Wolf entries/aprons. Root separately checked all prior 652 entrance rows unchanged
and the unknown-phase refusal. No consumer or canonical source edit was made by
this audit agent.

`parent-native-tail-binding.json` and the copied parent log bind the subsequent
fixed-consumer ordered tail: step147 through201, 55 steps, one lap, the last lap
moved nothing. Root reported session33322 exit0. A later reread found all 70
audited inputs unchanged after that completion. This is the settled parent96
snapshot before root's new-parent migration; it does not claim a gate verdict on
that future stack. Parent's entrance-row invariant/check receipts are also copied
under `history/`.

## Reproduction and limits

`snapshot-replay-proof.json` records exact reproduction of the geometry, entrance,
object, historical-comparison and terrain findings from the regular-file snapshot.
Run a copy of `audit_site.py` from a fresh output directory with:

```sh
python3 /tmp/NEW-OUTPUT/audit_site.py --root /tmp/log82-wolf-site-audit-20261023T2358/inputs --frozen-head 96ca50cbc8150f93576cbbd699b4359d73b6de01
```

Copy `history/object-check.json` beside that copied script as well, so replay does
not need the historical prototype directory. The script writes only beside
itself. Do not rerun inside this closed evidence packet.

No Blender, browser, fetch, native writer or full gate was run for this audit.
Actual 3D building/roof/prop contact, published app review, walker behavior and
original image matching remain owed. These results do not certify an interior
passage through the solid footprint. Parent's ordered derivation and full gate
have their own logs; this bounded audit does not substitute for them.
