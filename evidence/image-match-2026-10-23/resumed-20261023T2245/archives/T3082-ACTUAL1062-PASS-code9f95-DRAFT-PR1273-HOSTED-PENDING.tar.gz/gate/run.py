from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
OUT=Path(__file__).resolve().parent
APP=Path('/workspace/chicago/chicago/4d')
QA=Path('/workspace/T3082-QA-v3-final5d9-20261024')
assert json.loads((QA/'ORCHESTRATION.json').read_text())['status']=='PASS_ACTUAL_CASES_MANUAL_IMAGE_REVIEW_OWED'
assert (QA/'VISUAL-REVIEW.json').exists()
assert json.loads((QA/'VISUAL-REVIEW.json').read_text())['image_gate_verdict']=='differs'
assert not (OUT/'RECEIPT.json').exists()
env={**os.environ,'TMPDIR':'/workspace/T3082-preflight-tmp','TMP':'/workspace/T3082-preflight-tmp','TEMP':'/workspace/T3082-preflight-tmp','PATH':'/workspace/shared/tools/usr/bin:'+os.environ.get('PATH',''),'C4D_GATE_REQUIRE_READERS':'1','CHECK_JOBS':'4'}
Path(env['TMPDIR']).mkdir(exist_ok=True)
s={'status':'RUNNING','pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':['bash','tools/preflight.sh'],'scientific_readers_required':True,'check_jobs':4}
def save():(OUT/'RECEIPT.json').write_text(json.dumps(s,indent=2)+'\n')
save()
try:
 with (OUT/'preflight.log').open('x') as log:
  p=subprocess.Popen(s['command'],cwd=APP,env=env,stdout=log,stderr=subprocess.STDOUT);s['child_pid']=p.pid;save();code=p.wait()
 s.update(exit_code=code,status='PASS' if code==0 else 'FAILED')
 for name in ['preflight-check.log','preflight-cl.log','preflight-ids.log']:
  src=Path('/tmp')/name
  if src.exists():shutil.copyfile(src,OUT/name)
except BaseException as exc:s.update(status='FAILED',error=str(exc));raise
finally:s['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(s,indent=2))
raise SystemExit(s.get('exit_code',1))
