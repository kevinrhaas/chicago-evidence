The first Tremont House now uses a darker reconstructed roof stock, following the contrast in the credited Gifford drawing. Review cards now say “Historical review context.” and retain the original explanation and sources; loader notices follow the standing owner ruling that review flags do not block release. Flags, reasons, confidence, release conditions and unexpected-error handling are unchanged.

Depends on #1260. This draft includes that parent’s tested log-building and Full-culling changes so the combined runtime is checked before landing. It must remain draft until the parent is merged, final dev reconciliation and this PR’s hosted smoke acceptance are complete.

The official pinned producer rebuilt all 23 current frame-family masters and real compressed derivatives. The 22 other pairs are byte-identical. Tremont changes only three roof RGB scalars to one quarter of the former linear RGB; binary geometry, UVs, confidence and other material values remain exact. All current recipe inputs were recomputed before reusing the genuine exports, and all 82 inherited log rows and 164 asset files are preserved. The new Glessner package was verified/materialized normally; incompatible old local cache bytes were held intact separately.

Validation:

- Full preflight passes: 1,062 checks including 383 self-tests, scientific readers required, plus changelog and ticket-ID checks. The initial pooled resident-synthesis copy hit ENOSPC; the unchanged harness’s normal solitary retry passed after safe storage recovery. The original error is retained.
- All thirteen native phases pass; the complete 61-step ordered tail settles in two laps. Six lodging/placement/population/name-pool checks pass; all 22 cards, seated ledger and order book remain exact.
- Four actual published mobile/desktop Tremont and Cobweb app cases pass: geometry/contact/budgets, exact fourteen review notices, both card surfaces, Photos attribution and Sources, with zero page/network/cleanup errors. An initial external QA import-path failure is preserved; only the harness path was repaired, without assertion changes.
- Native same-camera photo_match rendered and was directly reviewed: DIFFERS. Complete hosted whole-body mobile/desktop smoke acceptance remains pending.
- Normal fast-forward to parent head 6024f0736 changes only the hosted runner to supported Ubuntu 24.04. The entire application input tree remains byte-exact to the parent used for native/browser/preflight checks. Result-only STATUS/ROADMAP suffixes record completed checks while preserving all incoming raw history.

T-2385 stays open and DIFFERS. Roof colour is reconstructed; the provisional camera, native flag silhouette, shutters/entries and missing source context remain unresolved. No historical pigment, flag/wind, calibrated reflectance, source-rights upgrade or accepted picture match is claimed. Gifford attribution and the existing scoped owner-approved project-use limits remain in Sources.
