def _tower_stone_palette(b, p: FortStructureParams):
    """Reuse a wall material only when its entire stone PBR descriptor agrees.

    The unit-tone bare stone is already M_WALL; a duplicate name would be lost
    by native derivative deduplication. Coated walls keep their separate stone.
    """
    base = WALL_RGBA['stone']
    wall = PAINT_OVER.get(p.paint, WALL_RGBA.get(p.construction, WALL_RGBA['log']))
    substrate = materials.wall_substrate(construction=p.construction, default='hewn_log')
    _, roughness = materials.resolve(substrate, materials.wall_finish(paint=p.paint))
    reuse = wall == base and roughness == .93
    return [M_WALL if t == 1.0 and reuse else b.named_mat(
        'tower_stone_'+str(i), tuple(min(1, v*t) for v in base[:3])+(1.,), .93)
        for i, t in enumerate((.78, .91, 1.0, 1.08, 1.16))]
