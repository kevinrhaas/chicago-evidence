from pathlib import Path
import datetime,hashlib,json,re,time,urllib.request,urllib.parse,concurrent.futures,sys,subprocess
HOLDER=Path('/workspace/shared/T2380-integrate-a575-20261026')
CFILE=Path(sys.argv[1]) if len(sys.argv)>1 else HOLDER/'FINAL-CANDIDATE.json'
C=json.loads(CFILE.read_text())
ROOT=HOLDER/'full18-e81'
D=json.loads((ROOT/'COMPLETE_DISPATCH.json').read_text())
OUT=ROOT/'observer'
OUT.mkdir(exist_ok=True)
HEAD=D['head'];API='https://api.github.com/repos/kevinrhaas/chicago/'
assert HEAD==C['head'] and D['tree']==C['tree']
assert len(D['runs'])==18 and len({x['id'] for x in D['runs']})==18
assert all(x['observed_head']==HEAD and x['dispatch_accepted'] for x in D['runs'])
for viewport in ('mobile','desktop'):
    parts=[]
    for x in D['runs']:
        if x['viewport']==viewport:
            endpoints=[int(v) for v in x['stage'].split('-')]
            parts.extend(range(endpoints[0],endpoints[-1]+1))
    assert sorted(parts)==list(range(1,16)) and len(parts)==15

def get(path,raw=False):
    result=subprocess.run(['gh','api','repos/kevinrhaas/chicago/'+path,'--header','Cache-Control: no-cache'],capture_output=True,timeout=90)
    if result.returncode:
        raise RuntimeError('GitHub CLI read failed: '+result.stderr.decode('utf-8','replace')[:500])
    return result.stdout if raw else json.loads(result.stdout)

def save(name,value):
    path=OUT/name
    data=value if isinstance(value,bytes) else (json.dumps(value,indent=2)+'\n').encode()
    if path.exists():
        assert path.read_bytes()==data,'Never overwrite preserved evidence'
    else:
        path.write_bytes(data)

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def harvest(row,run):
    attempt=run['run_attempt']
    result_path=OUT/('verified-'+str(row['id'])+'-attempt'+str(attempt)+'.json')
    if result_path.exists():
        result=json.loads(result_path.read_text())
        assert result['head']==HEAD and result['run_attempt']==attempt
        return result
    fresh=get('actions/runs/'+str(row['id']))
    assert fresh['head_sha']==HEAD and fresh['head_branch']==D['branch'] and fresh['event']=='workflow_dispatch'
    assert fresh['run_attempt']==attempt and fresh['status']=='completed'
    jobs=get('actions/runs/'+str(row['id'])+'/attempts/'+str(attempt)+'/jobs?per_page=100')
    save('run-'+str(row['id'])+'-attempt'+str(attempt)+'.json',fresh)
    save('jobs-'+str(row['id'])+'-attempt'+str(attempt)+'.json',jobs)
    matches=[j for j in jobs['jobs'] if j['name']=='smoke' and j['status']=='completed']
    assert len(matches)==1
    job=matches[0]
    assert job['head_sha']==HEAD
    assert job.get('run_attempt',attempt)==attempt
    raw=get('actions/jobs/'+str(job['id'])+'/logs',raw=True)
    name='run-'+str(row['id'])+'-attempt'+str(attempt)+'-job-'+str(job['id'])+'.log'
    save(name,raw)
    text=re.sub(r'\x1b\[[0-9;]*m','',raw.decode('utf-8','replace'))
    lines=text.splitlines();checkout=None
    for i,line in enumerate(lines[:-1]):
        if '[command]' in line and 'git log -1 --format=%H' in line:
            match=re.search(r'Z ([0-9a-f]{40})$',lines[i+1])
            if match:
                checkout=match.group(1)
    viewport=re.findall(r'SMOKE_VIEWPORT: ([^\s]+)',text)
    stages=re.findall(r'SMOKE_STAGE: ([^\s]+)',text)
    counts=[{'passed':int(a),'failed':int(b)} for a,b in re.findall(r'(\d+) passed, (\d+) failed',text)]
    steps={s['name']:s for s in job['steps']}
    publish_steps=[s for n,s in steps.items() if n=='Publish the mirror the smoke serves (site/4d/ is generated)']
    smoke_steps=[s for n,s in steps.items() if n=='Run the smoke against the published mirror']
    native_steps_ok=len(publish_steps)==1 and len(smoke_steps)==1 and publish_steps[0]['conclusion']=='success' and smoke_steps[0]['conclusion']=='success'
    result={'run':row['id'],'job':job['id'],'run_attempt':attempt,'head':HEAD,'branch':D['branch'],'viewport':row['viewport'],'stage':row['stage'],'actual_checkout':checkout,'actual_viewport':viewport,'actual_stage':stages,'counts':counts,'native_publish_and_smoke_steps_success':native_steps_ok,'run_conclusion':fresh['conclusion'],'job_conclusion':job['conclusion'],'smoke_pass':'SMOKE PASS' in text,'zero_page_errors':'zero page errors' in text,'suite_body_aborted':bool(re.search(r'FAIL[^\n]*the suite body ran to completion',text)),'log':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'failure_lines':[{'line':i+1,'text':line[:1200]} for i,line in enumerate(lines) if re.search(r'\bFAIL\b|FAILURES:|\bError:|TimeoutError',line) and 'self-test' not in line]}
    result['verified_success']=bool(checkout==HEAD and viewport==[row['viewport']] and stages==[row['stage']] and fresh['conclusion']=='success' and job['conclusion']=='success' and native_steps_ok and result['smoke_pass'] and result['zero_page_errors'] and counts and all(c['failed']==0 for c in counts) and not result['suite_body_aborted'])
    save(result_path.name,result)
    return result

query='actions/workflows/chicago-4d-smoke.yml/runs?branch='+urllib.parse.quote(D['branch'],safe='')+'&event=workflow_dispatch&per_page=100'
while True:
    errors=[];rows=[];results=[]
    try:
        batch=get(query)
        indexed={x['id']:x for x in batch['workflow_runs']}
    except Exception as error:
        indexed={}
        errors.append({'scope':'batch-metadata','type':type(error).__name__,'HTTP':getattr(error,'code',None)})
    terminal=[]
    for row in D['runs']:
        run=indexed.get(row['id'])
        if not run:
            errors.append({'id':row['id'],'type':'MISSING_METADATA_NOT_PASS'})
            continue
        try:
            assert run['head_sha']==HEAD and run['head_branch']==D['branch'] and run['event']=='workflow_dispatch'
            rows.append({'id':row['id'],'viewport':row['viewport'],'stage':row['stage'],'status':run['status'],'conclusion':run['conclusion'],'head_sha':run['head_sha'],'run_attempt':run['run_attempt']})
            if run['status']=='completed':
                terminal.append((row,run))
        except Exception as error:
            errors.append({'id':row['id'],'type':type(error).__name__})
    def one(pair):
        try:
            return harvest(*pair),None
        except Exception as error:
            return None,{'id':pair[0]['id'],'type':type(error).__name__,'HTTP':getattr(error,'code',None)}
    with concurrent.futures.ThreadPoolExecutor(4) as pool:
        harvested=list(pool.map(one,terminal))
    for result,error in harvested:
        if error:
            errors.append(error)
        else:
            results.append(result)
    aggregate={}
    for viewport in ('mobile','desktop'):
        subset=[x for x in results if x['viewport']==viewport]
        aggregate[viewport]={'verified_legs':sum(x['verified_success'] for x in subset),'terminal_logs':len(subset),'staged_summary_passed':sum(x['counts'][-1]['passed'] for x in subset if x['counts']),'staged_summary_failed':sum(x['counts'][-1]['failed'] for x in subset if x['counts']),'count_semantics':'Sum of final native staged summaries; common assertions repeat across legs, not a unique full-suite assertion count.'}
    snapshot={'at':stamp(),'head':HEAD,'tree':C['tree'],'base':C['base'],'branch':D['branch'],'runs':rows,'read_errors':errors,'verified_successes':sum(x['verified_success'] for x in results),'actual_log_results':results,'aggregate':aggregate,'all_18_actual_logs_success':len(results)==18 and not errors and all(x['verified_success'] for x in results),'actual_failures':[x for x in results if not x['verified_success']]}
    save('snapshot-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%f')+'.json',snapshot)
    (OUT/'LATEST.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    print(json.dumps({'at':snapshot['at'],'terminal':sum(x['status']=='completed' for x in rows),'verified_successes':snapshot['verified_successes'],'errors':errors,'actual_failures':[{'run':x['run'],'attempt':x['run_attempt'],'viewport':x['viewport'],'stage':x['stage']} for x in snapshot['actual_failures']]}),flush=True)
    if len(results)==18 and not errors:
        save('FINAL_ACTUAL_RESULTS.json',snapshot)
        raise SystemExit(0 if snapshot['all_18_actual_logs_success'] else 1)
    time.sleep(60)
