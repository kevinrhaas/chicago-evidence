from pathlib import Path
import os,json,subprocess,hashlib,datetime,time,shutil,re,signal,sys
os.sched_setaffinity(0,{4});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1',TMPDIR='/tmp/wolfpoint-native-tmp',PYTHONDONTWRITEBYTECODE='1')
repo=Path('/workspace/chicago');app=repo/'chicago/4d';out=Path('/tmp/WolfPoint-T2386-a575-native-closure-20261026');prep=json.loads((out/'PREPARED.json').read_bytes());floor=prep['floor_bytes'];resources=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def space(label):
 row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':label,'workspace_free':shutil.disk_usage(repo).free,'tmp_free':shutil.disk_usage('/tmp').free};resources.append(row);(out/'RESOURCE-OBSERVATIONS.json').write_text(json.dumps(resources,indent=2)+'\n');assert min(row['workspace_free'],row['tmp_free'])>=floor,('ROOT_EXTERNAL_RESERVE_512MIB_NO_NATIVE_ASSERT_CHANGE',row);return row
assert all(sha(app/r['path'])==r['sha256'] for r in prep['frozen_physical_assets_and_registry'])
def run(name,cmd):
 print(name,'START',space(name+' BEFORE'),flush=True);start=time.monotonic();p=subprocess.Popen(cmd,cwd=app,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
 try:
  with(out/(name+'.log')).open('x') as log:
   for line in p.stdout:
    log.write(line);log.flush()
    if re.match(r'^\s*\[\d+/\d+\]',line):
     try:space(name+' '+line.strip())
     except AssertionError:os.killpg(p.pid,signal.SIGTERM);p.wait();raise
  code=p.wait()
 finally:
  if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait()
 result={'command':cmd,'exit':code,'seconds':round(time.monotonic()-start,3),'space_after':space(name+' AFTER')};(out/(name+'-RESULT.json')).write_text(json.dumps(result,indent=2)+'\n');assert code==0,(name,code);print(name,'PASS',flush=True)
start=time.monotonic()
run('official-glessner-check',['python3','tools/recover_glessner_v4.py','--check'])
run('native-bootstrap-publish',['bash','tools/publish.sh'])
run('native-owning-tail61',['node','tools/rederive.mjs','--tail','tools/compile_liberties.py'])
log=(out/'native-owning-tail61.log').read_text();assert 'derived layer rebuilt from step 142' in log and 'the last one moved nothing' in log
assert all(sha(app/r['path'])==r['sha256'] for r in prep['frozen_physical_assets_and_registry']),'FROZEN_ASSET_OR_REGISTRY_MOVED'
assert all(sha(app/r['path'])==r['sha256'] for r in prep['frozen_authored_people_population_source_generator_inputs']),'FROZEN_AUTHORED_CONTROL_MOVED'
result={'status':'NATIVE_OFFICIAL_PACKAGE_PUBLISH_OWNING61_FIXEDPOINT_PASS_ALL44_AUDIT_PACKAGE5_OWED','base':prep['base'],'seconds':round(time.monotonic()-start,3),'cpu':[4],'frozen2920_asset_files_exact':True,'frozen3875_authored_source_people_population_generator_inputs_exact':True,'no_exports_no_gate_no_nativeapp':True}
(out/'TAIL-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
