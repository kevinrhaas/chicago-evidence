import pathlib,subprocess,json,hashlib,os,sys,importlib.util,datetime,shutil
R=pathlib.Path('/workspace/chicago'); A=R/'chicago/4d'; O=pathlib.Path('/tmp/WolfPoint-T2386-a575-integration-20261026');O.mkdir(exist_ok=True)
OLD='cb93ad9cd5ea38654737e05002b1f1904be14e54'; NEW='a575dddeed356333423b20361a1f90f3b39a862f'; DONOR='6a61ab6eca1f1ea2322302d131e847b383ac9c8b'
REC=pathlib.Path('/tmp/WolfPoint-T2386-deep-brown82-native-closure-20261026/SOURCE-RECOVERY')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=dict(os.environ,GIT_NO_LAZY_FETCH='1'))
def show(c,p):return git('show',c+':'+p)
assert git('rev-parse','HEAD').decode().strip()==OLD
assert not git('diff','--cached','--name-only')
assert git('merge-base','--is-ancestor',OLD,NEW)==b''
assert min(shutil.disk_usage(R).free,shutil.disk_usage('/tmp').free)>512*1024**2
recovery=json.loads((REC.parent/'SOURCE-RECOVERY.json').read_bytes())
for row in recovery['source_files']:assert sha((R/row['path']).read_bytes())==row['sha256'],row['path']
docs=['chicago/4d/docs/'+p for p in ['LIBERTIES.md','STATUS.md','ROADMAP.md','RESEARCH/wolf_point_tavern.md']]
suffixes={}
for p in docs:
 b=show(OLD,p);ours=(REC/p).read_bytes();assert ours.startswith(b),p;suffixes[p]=ours[len(b):]
direct=['chicago/4d/'+p for p in ['generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py','data/structures/wolf_point_tavern.json','assets/gltf/wolf_point_tavern__log_frame_1828.glb','assets/web/wolf_point_tavern__log_frame_1828.glb']]
for p in direct:assert show(OLD,p)==show(NEW,p),('INCOMING_TARGET_CHANGED',p)
registry=['chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json']
spec=importlib.util.spec_from_file_location('native_registry',A/'tools/merge_asset_registry.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
merged={p:mod.merge_texts(p,show(OLD,p).decode(),(REC/p).read_text(),show(NEW,p).decode()).encode()for p in registry}
donor=json.loads(pathlib.Path('/workspace/green-tree-strict-repair-donor-6a61.json').read_bytes())
for p,row in donor['paths'].items():
 if p.endswith('STATUS.md'):continue
 assert sha(show(NEW,p))==row['preimage_sha256'],p
 assert sha(show(DONOR,p))==row['donor_sha256'],p
dbase=show(donor['base'],'chicago/4d/docs/STATUS.md');dstatus=show(DONOR,'chicago/4d/docs/STATUS.md');assert dstatus.startswith(dbase);dsuffix=dstatus[len(dbase):]
if '--dry' in sys.argv:
 print(json.dumps({'status':'READONLY_PREIMAGES_DOC_PREFIXES_NATIVE_REGISTRY_MERGE_DONOR_PREIMAGES_PASS','owned_direct_paths':direct,'registry_paths':registry,'append_only_docs':docs,'merged_registry_sha256':{p:sha(b)for p,b in merged.items()}}));sys.exit(0)
# Real native stash preserves the old work without applying it over incoming files.
msg='T2386 deep-brown cb93 full WIP before verified a575 fast-forward'
stashlog=git('stash','push','--include-untracked','-m',msg)
(O/'NATIVE-STASH.log').write_bytes(stashlog)
stash=git('rev-parse','refs/stash').decode().strip();git('update-ref','refs/codex/checkpoints/t2386-deep-brown-cb93-full-stash-20261026',stash,'0'*40)
assert not git('status','--porcelain'),git('status','--short')
(O/'NORMAL-FF.log').write_bytes(git('merge','--ff-only',NEW))
assert git('rev-parse','HEAD').decode().strip()==NEW
assert not git('status','--porcelain')
for p in direct:(R/p).write_bytes((REC/p).read_bytes())
entry='chicago/4d/changelog.d/T-2386.json';assert not (R/entry).exists();(R/entry).write_bytes((REC/entry).read_bytes())
for p,b in merged.items():(R/p).write_bytes(b)
for p,suffix in suffixes.items():
 incoming=show(NEW,p);assert (R/p).read_bytes()==incoming
 (R/p).write_bytes(incoming+suffix)
for p,row in donor['paths'].items():
 if p.endswith('STATUS.md'):continue
 assert sha((R/p).read_bytes())==row['preimage_sha256'];(R/p).write_bytes(show(DONOR,p))
sp=R/'chicago/4d/docs/STATUS.md'
if b'### T-2376 \xe2\x80\x94 the full-scene batch census retains the lighthouse glass'not in sp.read_bytes():sp.write_bytes(sp.read_bytes()+dsuffix)
sp.write_bytes(sp.read_bytes()+b'\nT-2386 integration: the genuine deep-brown82 source/assets were preserved before normal fast-forward to dev a575. Exact checked shared strict smoke/drawn-placement repairs from 6a61 are included; incoming source, records, changelog and registry entries are retained. Native closure, final app checks and full preflight on this combined tree remain pending.\n')
# Current native recipe check: all82 LogDwelling rows must match real output recipe hashes.
sys.path.insert(0,str(A/'generators'));import mesh_inputs
master=json.loads((A/'assets/manifest.json').read_bytes())['assets'];rows=[]
for key,row in master.items():
 if row.get('archetype')!='log_dwelling':continue
 st=json.loads((A/'data/structures'/(row['structure_id']+'.json')).read_bytes());ph=next(p for p in st['phases']if p['id']==row['phase_id'])
 actual=mesh_inputs.structure_inputs_sha(st,ph,'log_dwelling');assert actual==row['inputs_sha256'],('STALE',key,actual,row)
 rows.append({'asset':key,'native_inputs_sha256':actual,'actual_master_sha256':sha((A/'assets/gltf'/key).read_bytes()),'actual_web_sha256':sha((A/'assets/web'/key).read_bytes())})
assert len(rows)==82,('COHORT_SELECTION',len(rows))
for p in direct[:3]:assert (R/p).read_bytes()==(REC/p).read_bytes()
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_head':OLD,'new_head':NEW,'full_native_stash':stash,'private_pre_stash_ref':recovery['private_ref'],'normal_fast_forward':True,'exact_donor':DONOR,'native_registry_merge':'merge_asset_registry.merge_texts entrywise, all incoming rows retained','native82_current_recipe_hashes_exact':rows,'no_reexports':True,'newbase_native_closure_apps_gate_pr_pending':True}
(O/'TRANSPLANT-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');(O/'SOURCE-STATUS.txt').write_bytes(git('status','--short'));print(json.dumps({k:v for k,v in result.items()if k!='native82_current_recipe_hashes_exact'}))
