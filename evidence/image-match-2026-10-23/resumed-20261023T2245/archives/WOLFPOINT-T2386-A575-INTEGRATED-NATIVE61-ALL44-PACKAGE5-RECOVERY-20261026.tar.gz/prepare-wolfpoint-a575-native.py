import pathlib,subprocess,json,hashlib,os,shutil,datetime
R=pathlib.Path('/workspace/chicago');A=R/'chicago/4d';O=pathlib.Path('/tmp/WolfPoint-T2386-a575-native-closure-20261026');O.mkdir(exist_ok=True)
OLD=pathlib.Path('/tmp/WolfPoint-T2386-deep-brown82-native-closure-20261026');NEW='a575dddeed356333423b20361a1f90f3b39a862f'
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=dict(os.environ,GIT_NO_LAZY_FETCH='1'))
def sha(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==NEW
old=json.loads((OLD/'PREPARED.json').read_bytes());binary=[]
for ent in old['binary44']:
 p=ent['path'];b=git('show',NEW+':'+p);assert (R/p).read_bytes()==b,('BASELINE_NOT_CLEAN',p)
 dst=O/'actual-a575-binary-baseline'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
 binary.append(dict(path=p,git_blob=git('rev-parse',NEW+':'+p).decode().strip(),mode=ent['mode'],bytes=len(b),sha256=sha(b),raw_baseline=str(dst)))
tracked=[p.decode()for p in git('ls-files','-z','chicago/4d').split(b'\0')if p]
def freeze(paths):
 out=[]
 for p in sorted(set(paths)):
  f=R/p
  if f.is_file():out.append(dict(path=str(f.relative_to(A)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
 return out
assets=freeze([p for p in tracked if p.startswith('chicago/4d/assets/')]+['chicago/4d/'+r['path']for r in old['frozen_physical_assets_and_registry']])
controls=freeze(p for p in tracked if p.startswith(tuple('chicago/4d/'+s for s in ['data/residents/','data/structures/','data/sources/','generators/'])))
prep=dict(old,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),base=NEW,binary44=binary,binary_baseline_dependency={'actual_immutable_base':NEW,'all44_raw_retained_in_this_packet':True},frozen_physical_assets_and_registry=assets,frozen_authored_people_population_source_generator_inputs=controls,workspace_free=shutil.disk_usage(R).free,tmp_free=shutil.disk_usage('/tmp').free)
(O/'PREPARED.json').write_text(json.dumps(prep,indent=2)+'\n')
for name in ['run-native-closure.py','audit-all44.py','run-package5-final-publish.py']:
 s=(OLD/name).read_text().replace(str(OLD),str(O)).replace('wolfpoint-deep82-native61-reaping-status.json','wolfpoint-a575-native61-reaping-status.json').replace('CB93','A575').replace('cb93','a575').replace('2920',str(len(assets))).replace('3870',str(len(controls)))
 (O/name).write_text(s)
print(json.dumps({'newbase':NEW,'frozen_asset_files':len(assets),'frozen_controls':len(controls),'binary44':len(binary),'workspace_free':prep['workspace_free'],'tmp_free':prep['tmp_free'],'ready_for_owning_native61':True}))
