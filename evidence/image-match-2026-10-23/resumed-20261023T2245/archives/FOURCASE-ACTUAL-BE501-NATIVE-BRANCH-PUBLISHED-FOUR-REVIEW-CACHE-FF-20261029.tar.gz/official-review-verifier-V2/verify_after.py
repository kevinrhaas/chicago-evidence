from pathlib import Path
import argparse,importlib.util,json,datetime,hashlib
from urllib.request import Request,urlopen
P=argparse.ArgumentParser();P.add_argument('--before',required=True);P.add_argument('--output',required=True);a=P.parse_args();O=Path(a.output);O.mkdir(exist_ok=False);b=json.loads((Path(a.before)/'BEFORE.json').read_text())
sp=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
app=m.snapshot();assert app==b['app_snapshot'],'Onlyignoredmirror isallowed onprimary; trackedsource/ref/index/configmuststayexact'
m.SOURCE=Path('/workspace/isolated-gt-ticket-renewal-native-v4-20261029/repo');m.G=m.SOURCE/'.git';m.REPO='kevinrhaas/chicago-tickets'
# Isolated native Git intentionally uses exactly this read-only primaryobjectalternate.
# Refuse unknownobjectreads, while recognizing IDs indexed in either declared objectstore.
primaryG=Path('/workspace/chicago/chicago/4d/tickets/.git')
assert (m.G/'objects/info/alternates').read_text()==str(primaryG/'objects')+'\n'
original_indexed=m.indexed
def indexed_with_verified_alternate(wanted):
 isolatedG=m.G
 found=original_indexed(wanted)
 try:
  m.G=primaryG;found|=original_indexed(set(wanted)-found)
 finally:m.G=isolatedG
 return found
m.indexed=indexed_with_verified_alternate
snap=m.snapshot();assert not snap['status'];head=snap['HEAD'];c=m.commit(head);assert len(c['parents'])==1;parent=c['parents'][0];old=m.commit(parent);oldfiles=m.leaves(old['tree']);newfiles=m.leaves(c['tree']);changed={p for p in set(oldfiles)|set(newfiles)if oldfiles.get(p)!=newfiles.get(p)};assert changed==set(b['own_paths'])
remoteparent=m.api('git/commits/'+parent);assert remoteparent['tree']['sha']==old['tree'];remotehead=m.api('git/commits/'+head);assert remotehead['tree']['sha']==c['tree']and[x['sha']for x in remotehead['parents']]==[parent]
strip=lambda raw:b'\n'.join(l for l in raw.split(b'\n')if not l.startswith((b'state:',b'pr:',b'group:')))
rows=[]
for p in sorted(changed):
 pre=m.obj('blob',oldfiles[p][2]);post=(m.SOURCE/p).read_bytes();assert b'state: claimed\n'in pre and b'pr: null\n'in pre and b'state: review\n'in post and b'pr: 1456\n'in post and b'group: T-2381,T-2373,T-2384,T-2377\n'in post;assert strip(pre)==strip(post)
 with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+head+'/'+p,headers={'User-Agent':'Chicago-four-officialnative-review-readback'}),timeout=60)as r:assert r.status==200;actual=r.read()
 assert actual==post;rows.append({'path':p,'bytes':len(post),'sha256':hashlib.sha256(post).hexdigest(),'git_blob':newfiles[p][2]})
assert all(newfiles[p]==v for p,v in oldfiles.items()if p not in changed)and set(newfiles)==set(oldfiles)
current=m.api('git/ref/heads/main')['object']['sha'];assert current==head or m.api('compare/'+head+'...'+current)['status']=='ahead'
(O/'RESULT.json').write_text(json.dumps({'status':'ACTUAL_OFFICIAL_NATIVE_FOUR_REVIEW_REMOTE_IMMUTABLE_READBACK_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'parent':parent,'tree':c['tree'],'ids':b['ids'],'PR':1456,'native_state':'review','actual_DONE':'NOT_YET; officialsettleonlyafteractualappPRmerge','all_foreign_paths_exact':len(oldfiles)-4,'all_other_own_fields_and_body_exact':True,'allowed_fields':['state','pr','group'],'readback':rows,'primary_app_tracked_HEAD_index_config_refs_status_unchanged':True,'primary_ignoredmirror':'Nativeboardrefreshedfromisolatedcurrentrepo; primaryolde055cacheunchangedandmustbesyncedbeforefuturelocalfullcheck/publish','no_main_promotion':True},indent=2)+'\n');print((O/'RESULT.json').read_text())
