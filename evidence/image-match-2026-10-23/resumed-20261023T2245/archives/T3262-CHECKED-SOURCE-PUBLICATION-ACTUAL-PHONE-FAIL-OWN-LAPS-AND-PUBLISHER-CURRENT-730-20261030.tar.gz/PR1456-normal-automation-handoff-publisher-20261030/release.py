from pathlib import Path
import os,sys,json,subprocess,hashlib,datetime,urllib.request,stat
O=Path(__file__).parent;OLD='de4e1ade21e03828a0ce20f5489a5431b46f262e';REF='refs/heads/lap/pr-1456';R=Path('/workspace/PR1456-fixed-branch-native-relap-prep-publisher-20261030/lock-scratch');API='https://api.github.com/repos/kevinrhaas/chicago/'
def get(p):return json.load(urllib.request.urlopen(urllib.request.Request(API+p,headers={'User-Agent':'Chicago1456-own-native-release'}),timeout=30))
p=get('pulls/1456');assert p['state']=='open' and p['head']['sha']=='3746b23bf1298c34a29946b4cdb6ee2d98abff8f' and not any(x['name'] in ['hold','do-not-merge','blocked-owner'] for x in p['labels'])
m=get('git/commits/'+OLD);assert get('git/ref/heads/lap/pr-1456')['object']['sha']==OLD
assert m['tree']['sha']=='4b825dc642cb6eb9a060e54bf8d69288fbee4904' and not m['parents'] and m['message'].startswith('lap PR #1456 — Codex four-building current-dev generated-data repair ')
assert datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(m['committer']['date'].replace('Z','+00:00'))+datetime.timedelta(hours=3)
B=O/'bin';B.mkdir(exist_ok=True)
shim='''#!/usr/bin/env python3
import os,sys,json,subprocess,urllib.request
from pathlib import Path
O=Path('/workspace/PR1456-normal-automation-handoff-publisher-20261030');R=Path('/workspace/PR1456-fixed-branch-native-relap-prep-publisher-20261030/lock-scratch');OLD='de4e1ade21e03828a0ce20f5489a5431b46f262e';REF='refs/heads/lap/pr-1456';a=sys.argv[1:]
assert Path.cwd().resolve().is_relative_to(R.resolve())
assert a==['push','origin','--delete','lap/pr-1456'],a
u='https://api.github.com/repos/kevinrhaas/chicago/git/ref/heads/lap/pr-1456'
m=json.load(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Chicago1456-exact-own-CAS-release'}),timeout=30));assert m['object']['sha']==OLD
cmd=['/usr/local/bin/git','-c','protocol.https.allow=always','push','origin',':'+REF,'--force-with-lease='+REF+':'+OLD]
(O/'EXACT-OWN-RELEASE-CAS.json').write_text(json.dumps({'native_args':a,'actual_args':cmd,'old':OLD,'only_own_empty_metadata_ref':True})+'\\n')
os.execve(cmd[0],cmd,dict(os.environ,GIT_NO_LAZY_FETCH='1'))
'''
s=B/'git';s.write_text(shim);s.chmod(0o700)
env=dict(os.environ,PATH=str(B)+':'+os.environ['PATH'],NODE_DISABLE_COMPILE_CACHE='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(O))
tool='/workspace/original-ready-CB-school-sparse-renewals-publisher-20261030/app/chicago/4d/tools/ticket.mjs'
assert hashlib.sha256(Path(tool).read_bytes()).hexdigest()=='34c9f9db3cd6f1091ef075ad1bf77874a9e3f064e9e3ea4e633dc6d5569c5e90'
# Native Git ROOT is derived from tool file; execute an exact byte copy under the isolated scratch.
T=R/'chicago/4d/tools/ticket.mjs';T.parent.mkdir(parents=True,exist_ok=True);T.write_bytes(Path(tool).read_bytes())
q=subprocess.run(['taskset','-c','2','node',str(T),'lap','1456','--release'],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(O/'NATIVE-RELEASE.log').write_text(q.stdout);assert q.returncode==0 and 'lap/pr-1456 released' in q.stdout,q.stdout
refs=get('git/matching-refs/heads/');assert not any(x['ref']==REF for x in refs)
b=json.loads((O/'BEFORE.json').read_text())['refs'];before={x['ref']:x['object']['sha'] for x in b if x['ref']!=REF};after={x['ref']:x['object']['sha'] for x in refs};changes={k:{'before':before.get(k),'after':after.get(k)} for k in set(before)|set(after) if before.get(k)!=after.get(k)}
result={'status':'OWN1456_NATIVE_RELEASE_EXACT_CAS_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old':OLD,'released_only_ref':REF,'native_exit':q.returncode,'native_log':q.stdout,'foreign_ref_changes_observed':changes,'all_foreign_advertised_refs_unchanged':not changes,'primary_git_operations':False,'code_ref_pushes':False};(O/'RELEASE-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
