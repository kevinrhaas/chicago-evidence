#!/usr/bin/env bash
#
# THE PR LAP. For every open PR into `dev` that is not a draft and not `hold`:
# merge `dev` in, regenerate what a tool owns, and push. It does NOT gate — CI
# does, on the push (see the long note above the push below) — and it does NOT
# merge the PR. The lap gating first cost ~7 minutes per PR and was why the
# queue never converged; lap 310 took 23.2 min for three pushes and lap 313,
# after the removal, took 37 SECONDS for four.
#
# WHAT DOES MERGE IT: `.github/steward/merge-ready.sh`. This line used to read
# "auto-merge does that once `gate` goes green", and that was not true. Nothing
# in this repository arms auto-merge except chicago-4d-bake.yml, and only on
# bakes; the fleet janitor believed the same sentence from the other side
# ("`custom` merges through the lap plus GitHub auto-merge") while deliberately
# excluding `custom` from its own roster. Checked 2026-09-14 against every PR
# that landed that day: #1327 and #1312 merged with `auto_merge: off`, armed by
# hand. So the lap made pull requests clean, CI made them green, and they sat —
# which is what an unmergeable queue looks like when every PR in it is mergeable.
#
# WHY THIS EXISTS (T-0857). GitHub's server-side merge NEVER runs a custom merge
# driver. `.gitattributes` can name `merge=generated`; only a clone that has run
# tools/setup-merge-drivers.sh can execute it, and GitHub has run nothing. So a
# branch that merges `dev` with ZERO conflicts here is reported as CONFLICTING by
# GitHub, auto-merge cannot fire, "Update branch" refuses, and the pile grows at
# exactly the rate the lane opens PRs. Measured 2026-09-06 on PR #940: clean
# locally, conflicted on GitHub, same commit.
#
# THE DRIVERS ARE REGISTERED FROM `dev`, NOT FROM THE BRANCH, and that is the
# other half. A merge driver that lives in the repo cannot resolve a merge on a
# branch cut BEFORE it: tools/merge-generated.mjs is simply absent from those
# trees. Copying dev's drivers aside and pointing git at the copies means a
# branch from before T-0831 gets the same clean merge as one from after it.
#
# It REFUSES rather than guesses. A conflict outside the generated set is a real
# disagreement about content — research claims, prose, tools — and picking a side
# is not a merge. Those PRs are left alone with one comment saying which files.
set -uo pipefail

# WHICH REPOSITORY (T-1656) — the same fault T-1655 removed from pr-rest.sh, three
# files over. This line used to read `REPO="${GITHUB_REPOSITORY:-kevinrhaas/chicago}"`,
# and that `:-` default reads as a safety net without being one: in an Actions job the
# variable is always SET, so the default never fires and the value is whatever
# repository owns the JOB — never the checkout this script is in.
#
# It was driven that way for real on 2026-09-27 (T-1652, chicago#104). A steward
# improve run executes inside a **polecat-platform** job and clones this repo into
# the workspace, so every call made from that clone named polecat-platform:
# pr-rest.sh's `create` failed loudly with a 422, and its `resume` SUCCEEDED
# SILENTLY AGAINST A STRANGER — commenting the handoff reason on, and applying
# `resume` to, polecat-platform#104, an unrelated PR. Both repositories had a #104
# open that day, which is the point: a number collision across repos is not rare.
#
# This one is less exposed than pr-rest.sh was, because this repository's own
# chicago-4d-pr-lap.yml runs it and there the ambient name is right. But it WRITES —
# the one comment it leaves on a real conflict — and a comment on a stranger's PR is
# the thing T-1577 exists to stop happening without the owner knowing why.
#
# So:
#
#   1. `--repo owner/name` NAMES it, and wins.
#   2. Otherwise it is the origin remote of THE CHECKOUT THIS FILE IS IN — resolved
#      from ${BASH_SOURCE[0]} and not from $PWD, because a caller drives this script
#      by absolute path from wherever it happens to be standing. That is why
#      `.github/workflows/chicago-4d-pr-lap.yml` passes no `--repo`: its
#      actions/checkout sets the origin this reads, so the right answer needs no
#      argument, while a clone of a DIFFERENT repository can no longer supply one.
#   3. Otherwise it REFUSES, in one line naming `--repo`. It never consults the
#      environment.
#
# Every pull request this touches came out of the list below, which is read from
# this same repository — so naming the repository right is the whole of the guard,
# and there is no stranger-PR left for a per-PR existence check to catch.
repo=""
while [ $# -gt 0 ]; do
  case "$1" in
    --repo)   repo=${2:-}; shift 2 ;;
    --repo=*) repo=${1#--repo=}; shift ;;
    *) echo "usage: $0 [--repo owner/name]  (everything else is an environment variable: see the header)" >&2; exit 2 ;;
  esac
done

checkout_repo() { # the origin remote of the checkout THIS FILE is in, as owner/name
  local root url
  root=$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && git rev-parse --show-toplevel 2>/dev/null) || return 1
  url=$(git -C "$root" remote get-url origin 2>/dev/null) || return 1
  url=${url%.git}
  # https://host/owner/name · https://user@host/owner/name · git@host:owner/name · ssh://host/owner/name
  url=$(printf '%s' "$url" | sed -E 's#^(https?://([^@/]+@)?[^/]+/|ssh://([^@/]+@)?[^/]+/|[^/@]+@[^:/]+:)##')
  printf '%s\n' "$url"
}

[ -n "$repo" ] || repo=$(checkout_repo) || repo=""
if ! [[ "$repo" =~ ^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$ ]]; then
  echo "::error::$0: cannot tell which repository to act on — pass --repo owner/name. The default is this checkout's origin remote and NEVER \$GITHUB_REPOSITORY (T-1655, T-1656); it resolved to '${repo}'."
  exit 2
fi
REPO="$repo"
BASE="${LAP_BASE:-dev}"
ONLY="${LAP_ONLY:-}"
DRIVERS="$(mktemp -d)"
WORK="$(git rev-parse --show-toplevel)"

# THE IDENTITY THIS SCRIPT COMMITS UNDER, SET ONCE — and this one line is why the
# lap has never lapped anything. `git merge` writes a COMMIT, so it needs an
# author, and actions/checkout sets none: the runner has no user.name and its
# user.email is a machine hostname git will not accept. The identity was passed
# with `-c` on the `git commit` below and nowhere else, so every merge in every
# lap died with
#
#   fatal: empty ident name (for <runner@runnervm….internal.cloudapp.net>)
#       not allowed
#
# leaving no conflict, no commit and — until the exit status above started being
# read — no complaint. Measured on run 82, 2026-09-10 08:15: FOUR open PRs, four
# identical failures, and the old code would have reported `pushed=4`. It reported
# `left-alone=4` instead, which is how this was finally visible.
git config user.name  "polecat-steward"
git config user.email "steward@polecat.live"

# Files a TOOL owns. A conflict here is never resolved by hand: the merge takes
# either side to clear the marker and the tool then rewrites the file from source.
GENERATED='
chicago/4d/tickets/BOARD.md
chicago/4d/tickets/tickets.json
chicago/4d/tickets/QUEUE.md
chicago/4d/tools/dev-smoke-state.json
chicago/4d/renderers/web/js/changelog.js
site/4d/build.json
site/4d/tickets.json
site/4d/js/changelog.js
site/4d/walk/index.html
site/4d/walk/js/changelog.js
'

# ...AND THE THREE OF THOSE THAT ARE NO LONGER TRACKED AT ALL (T-0937).
#
# BOARD.md and both tickets.json came off the PR surface entirely: they are
# .gitignored now, because a run's first act is `ticket.mjs claim`, which rewrites
# all three before any work is done, and GitHub's merge runs no driver to reconcile
# them (T-0857). An untracked file cannot conflict, which is the point.
#
# But every branch cut BEFORE that landed still tracks them AND still modifies them,
# so merging the base into one is a modify/delete conflict on all three — for as long
# as those branches stay open. They must be resolved by REMOVING, not by
# `checkout --ours`: taking ours would put the file back in the index, and the lap's
# own `git add -A` would then carry it into the PR, re-tracking on the merge exactly
# the file the base just untracked. The regeneration below rebuilds all three as
# ignored files a moment later, so nothing is lost by deleting them here.
UNTRACKED_GENERATED='
chicago/4d/tickets/BOARD.md
chicago/4d/tickets/tickets.json
site/4d/tickets.json
'

say() { printf '%s\n' "$*"; }

# --- the mirror, published BEFORE anything re-derives against it -------------
#
# `site/4d/` is GENERATED and untracked (T-0938), so the lap's checkout has no
# mirror at all — and one step of the derived layer READS it.
# `tools/rebuild_closing_set.py --build` is step 156 of 156, it takes the
# published-resident count out of `site/4d/data/residents/`, and rather than
# write a number it did not take it REFUSES:
#
#   REFUSED to write docs/RESEARCH/closing-convergence-2026-09.md: the mirror
#   is not published, so the published-resident count was not taken.
#
# That refusal is right, and it failed the whole rebuild, so the PR was
# `left alone` — on EVERY lap, for ever, because the next lap reaches the same
# step and cannot finish either. From outside that is indistinguishable from a
# queue the lap has not got to yet, which is how three PRs with GREEN gates came
# to sit unmergeable on 2026-09-21 (#1629, #1630, #1631) while lap 35624254338
# reported success (T-1521).
#
# `tools/check.sh` publishes first, before anything reads the mirror, for exactly
# this reason (its step 1). The lap never learned it; this is that lesson.
# A REAL publish, not a `--dry-run`, so publish.sh's own refusals still apply,
# and about a second on a warm tree. The regeneration block below publishes
# AGAIN once the queue and the scene have been rebuilt — that one produces the
# mirror the PR ships; this one only makes it readable. publish.sh is idempotent,
# so running it twice costs those seconds and nothing else.
lap_publish_mirror() {
  lap_refresh_package
  ( cd chicago/4d && bash tools/publish.sh ) >/tmp/lap-publish.log 2>&1
}

# ...AND THE GLESSNER PACKAGE IS UNPACKED AGAIN FROM THE MERGED TREE FIRST (T-2907).
# The three v4 GLBs too large to commit live in docs/RESEARCH/glessner-v4-recovery/
# as a packed archive, and publish.sh materializes them as IGNORED files. This one
# clone laps every PR in turn, and an ignored file survives every checkout and merge,
# so after a merge that brings dev's repacked archive the copy on disk is the OLD
# one — and publish.sh, rightly, refuses to publish an output that differs from its
# package. Measured 2026-10-19: #1116 repacked Glessner, and the very next lap
# merged #1114's registries (T-2892) and then left it alone at publish for that
# refusal, which no run could ever fix from the PR. Nothing in the lap ever authors
# these files; they are always the committed package's, so the lap deletes its
# unpacked copies and lets --materialize rebuild them from the merged archive. Only
# paths git calls IGNORED are touched, so a tracked file is never removed.
lap_refresh_package() {
  [ -f chicago/4d/tools/recover_glessner_v4.py ] || return 0
  ( cd chicago/4d && python3 -c '
import sys; sys.path.insert(0, "tools")
import recover_glessner_v4 as r
print("\n".join(r.targets()))' 2>/dev/null ) | while IFS= read -r rel; do
    [ -n "$rel" ] && [ -e "chicago/4d/$rel" ] && git check-ignore -q "chicago/4d/$rel" \
      && rm -f "chicago/4d/$rel"
  done
  return 0
}

# The newest `gate` check run on a head, as `status:conclusion`, or nothing when
# the head carries none (T-1362). NEWEST BY `started_at`, not array order — a
# re-gated head carries several, and pr-stuck.sh's `gate_verdict` reads it the
# same way for the same reason.
lap_gate_verdict() {
  gh api "repos/$REPO/commits/$1/check-runs?per_page=100" \
    --jq '[.check_runs[]? | select(.name=="gate")]
          | sort_by(.started_at // "") | last
          | if . == null then empty else "\(.status):\(.conclusion // "none")" end' \
    2>/dev/null
}

# --- dev's drivers, registered by absolute path so any branch can use them
git fetch origin "$BASE" -q
for f in merge-queue.mjs merge-changelog.mjs merge-generated.mjs merge-smoke-state.mjs; do
  git show "origin/$BASE:chicago/4d/tools/$f" > "$DRIVERS/$f" 2>/dev/null || true
done
reg() { [ -s "$DRIVERS/$2" ] && git config "merge.$1.driver" "node $DRIVERS/$2 %O %A %B %P" && say "  driver $1 <- $BASE"; }
reg queue      merge-queue.mjs
reg changelog  merge-changelog.mjs
reg generated  merge-generated.mjs
reg smokestate merge-smoke-state.mjs

# ...AND THE ATTRIBUTES FROM `dev` TOO, WHICH IS THE HALF THAT IS EASY TO MISS.
# Registering a driver is not enough: git reads `merge=` out of the .gitattributes
# in the WORKING TREE, so a branch cut before T-0831 routes nothing to the driver
# however well it is registered. $GIT_DIR/info/attributes outranks the tree, so
# dev's rules are injected there and every branch is merged under them.
# MEASURED on PR #841 (cut before T-0831): drivers alone left 8 conflicts, five of
# them generated; drivers PLUS these attributes left 3, and all three are real.
git show "origin/$BASE:.gitattributes" \
  | grep -E 'merge=(queue|changelog|generated|smokestate)' \
  > "$(git rev-parse --git-dir)/info/attributes"
say "  attributes <- $BASE ($(wc -l < "$(git rev-parse --git-dir)/info/attributes") rules)"

# EVERY DRIVER THE ATTRIBUTES ROUTE TO HAS TO BE REGISTERED, and nothing checked.
# `reg` skips SILENTLY when dev's copy of a driver cannot be read — a renamed or
# moved tool, a path that drifted — while the attributes above still route files
# to it. The first merge then dies with `fatal: custom merge driver <name> lacks
# command line`: no conflict to find, no commit made, and before this script
# learned to read `git merge`'s exit status, no complaint either. Reproduced
# 2026-09-10 against PR #1049's branch. It is armed by absence, so absence is
# what this looks for, and it stops the whole lap rather than lapping nothing.
MISSING=
for D in $(grep -v '^[[:space:]]*#' "$(git rev-parse --git-dir)/info/attributes" \
             | grep -oE 'merge=[a-z]+' | sed 's/merge=//' | grep -v '^union$' | sort -u); do
  git config --get "merge.$D.driver" >/dev/null 2>&1 || MISSING="$MISSING $D"
done
if [ -n "$MISSING" ]; then
  echo "::error::.gitattributes routes files to unregistered merge driver(s):$MISSING"
  echo "::error::Every merge would die with 'lacks command line' and lap nothing."
  echo "::error::Check that $BASE still carries chicago/4d/tools/merge-*.mjs under those names."
  exit 1
fi

# --- THE LAP LOCK, READ BEFORE A PR IS TOUCHED AND AGAIN BEFORE IT IS PUSHED (T-2929) ---
#
# A run that laps a `resume` PR takes `lap/pr-<N>` first (`ticket.mjs lap`, T-1721) so
# no sibling relaps it. This sweep never read that lock, so it was the one lapper the
# lock did not stop. Measured on #1132, 2026-10-20: the lock was taken at 13:00Z, this
# lap pushed df6ae544a over it at 13:19Z, and merge-ready merged that at 13:37Z — the
# holding run's merge of dev, its ten-minute re-derive, check.sh and smoke were all
# thrown away.
#
# So a PR whose lock a LIVE run holds is left to that run: it is lapping it already,
# and it gates before it pushes, which this does not. A DEAD run's lock (older than
# RUN_HOURS) is no hold, exactly as `lap` steals it. "Live" is not re-derived here:
# `ticket.mjs lap <N> --status` is the tool that takes the lock answering who holds
# it, so the two can never disagree. dev's copy, like the drivers above, because the
# tree below is each PR's in turn; run against THIS clone's git dir, because its
# origin is the remote this lap pushes to and the lock lives on.
#
# AN UNREADABLE LOCK IS LEFT ALONE, NOT LAPPED. `lap` proceeds when the remote cannot
# answer, and that is right for a run: a false stop strands an hour of budget. Here
# the costs run the other way — a PR skipped is one pass late, and the next push to
# dev laps it again; a PR lapped over a live run costs that run everything above. And
# a remote this lap cannot ls-remote is one it could not push to anyway. It is said
# per PR, with ticket.mjs's reason, so a lap that skipped everything says why.
LOCK_TOOL="$DRIVERS/lock/tools/ticket.mjs"     # its ROOT is $DRIVERS/lock: no tickets/ to load
mkdir -p "$(dirname "$LOCK_TOOL")"
git show "origin/$BASE:chicago/4d/tools/ticket.mjs" > "$LOCK_TOOL" 2>/dev/null || : > "$LOCK_TOOL"
LAP_GIT_DIR=$(git rev-parse --absolute-git-dir 2>/dev/null)

# lap_lock_free N — 0 when nobody live holds lap/pr-N; 1 when a live run does
# (LOCK_HELD=1) or the lock cannot be read. LOCK_SAID is ticket.mjs's one line.
lap_lock_free() {
  LOCK_SAID=; LOCK_HELD=
  if [ ! -s "$LOCK_TOOL" ] || [ -z "$LAP_GIT_DIR" ]; then
    LOCK_SAID="unknown — tools/ticket.mjs could not be read from origin/$BASE, so lap/pr-$1 cannot be"
    return 1
  fi
  local out rc
  out=$(GIT_DIR="$LAP_GIT_DIR" node "$LOCK_TOOL" lap "$1" --status 2>&1); rc=$?
  LOCK_SAID=$(printf '%s\n' "$out" | tail -1)
  case "$rc" in
    0) return 0 ;;
    3) LOCK_HELD=1; return 1 ;;
    *) LOCK_SAID="unknown (exit $rc) — ${LOCK_SAID:-ticket.mjs said nothing}"; return 1 ;;
  esac
}

# REST, NOT `gh pr list`, AND THE REASON IS A RATE LIMIT THAT ONLY BITES HERE.
# `gh pr list` is a GRAPHQL call. GitHub budgets GraphQL separately from REST and
# far more tightly, and on 2026-09-14 the steward's own PAT spent its GraphQL
# allowance — the loop, the janitor and Manager all draw on it — while REST sat
# untouched:
#
#   gh pr list (GraphQL, STEWARD_PAT)  GraphQL: API rate limit already exceeded
#                                      for user ID 4193586
#   every REST call in the same minute  answered normally
#
# Two full laps were dispatched against a queue of nine lappable PRs, seven of
# them green and five with auto-merge armed and unable to fire, and both laps
# reported `pushed=0 ... red=0` and exited green having listed nothing.
#
# The same question over REST costs one request against a 15,000/hour budget and
# needs no GraphQL at all. The field names differ — REST spells them `draft` and
# `head.ref` where gh's GraphQL layer spells them `isDraft` and `headRefName` —
# and that is the whole of the change; the filter is the one it always was.
#
# ONE LABEL IS FILTERED AND IT IS `hold` — and since T-1573 there is a second label
# that looks like it belongs in this filter and MUST NOT BE ADDED TO IT. `resume`
# marks a run's own unfinished work: the branch carries it, the run ran out of
# clock or budget or green, and a later run finishes it. Lapping such a PR is the
# FIRST thing that has to happen to it — merge `dev` in, rebuild the derived layer,
# push, let CI gate. A `resume` PR is therefore LIVE to this lap in every respect,
# indistinguishable from any other, and that is deliberate rather than an oversight
# in the filter. `hold` is the owner's park switch and stays the only exclusion;
# T-1573's fixture asserts that this filter names exactly one label.
PRS=$(gh api --paginate \
        "repos/$REPO/pulls?state=open&base=$BASE&per_page=100" \
        --jq '.[] | select(.draft==false)
                  | select([.labels[].name] | index("hold") | not)
                  | "\(.number)\t\(.head.ref)"')
# THE STATUS OF THAT CALL, BECAUSE AN EMPTY ANSWER AND A FAILED ONE LOOK
# IDENTICAL FROM HERE. `PRS=$(cmd)` carries cmd's exit status, and this script
# runs `set -uo pipefail` WITHOUT `-e`, so a failure does not stop it: PRS is
# simply empty, the loop below runs zero times, and the lap prints
#
#   PR lap: pushed=0 already-current=0 left-alone=0 red=0
#
# which is EXACTLY what a healthy lap with nothing to do prints. It then exits 0
# and the workflow goes green.
#
# Measured 2026-09-14 on run 301, dispatched with LAP_ONLY=1257 to lap a PR that
# was 39 commits behind dev:
#
#   GraphQL: API rate limit already exceeded for user ID 4193586.
#   PR lap: pushed=0 already-current=0 left-alone=0 red=0
#
# The run was GREEN. Nothing was lapped, nothing said so, and the only trace was
# one line of gh's stderr in the middle of a successful log. Every lap inside
# that rate-limit window reported clean while sweeping nothing — which is what a
# stuck PR queue looks like from the outside when the workflow list looks
# healthy.
#
# This is the same shape as the steward janitor's `set -e` abort (polecat-platform
# #165): a failure wearing the costume of a clean run. The janitor at least went
# RED. This went green, which is worse.
#
# So the lap now refuses to be quietly useless. If it cannot ASK, it fails, loudly
# — the lap's whole job is the list, and a lap that cannot see its PRs has not
# done that job. (If `set -e` is ever added to this script, this capture needs a
# `set +e` around it or it becomes unreachable — which is precisely the bug #165
# was.)
LIST_RC=$?
if [ "$LIST_RC" -ne 0 ]; then
  echo "::error::the PR-list call failed (exit $LIST_RC) — the lap cannot see the pull requests it exists to lap."
  echo "::error::A rate limit or an auth failure here is indistinguishable from an empty queue:"
  echo "::error::both leave the list empty, and the lap would print 'pushed=0 ... red=0' and exit 0."
  echo "::error::Failing instead, so a lap that swept nothing is never reported as a lap that found nothing."
  exit 1
fi

if [ -n "$ONLY" ]; then
  # A DISPATCH THAT NAMES A PR AND MATCHES NOTHING IS ALSO NOT "no work". The
  # operator asked for something specific; silence is the wrong answer whether the
  # number is wrong, the PR is closed, or — the case that cost an hour on
  # 2026-09-14 — it carries `hold`, which the filter above removes BEFORE this
  # line ever sees it.
  MATCHED=$(echo "$PRS" | awk -v n="$ONLY" -F'\t' '$1==n')
  if [ -z "$MATCHED" ]; then
    echo "::error::LAP_ONLY=$ONLY matched no lappable pull request into $BASE."
    echo "::error::The list above holds $(echo "$PRS" | grep -c . || true) PR(s). A PR is absent from it when it is"
    echo "::error::closed, a draft, labelled 'hold', or targets another base — the 'hold' filter runs"
    echo "::error::BEFORE this one, so a held PR can never be reached by naming it here. Remove the"
    echo "::error::label first if that is what you meant."
    exit 1
  fi
  PRS="$MATCHED"
fi

PUSHED=0; SKIPPED=0; NOOP=0; LAPPING=0
# No `RED` any more: the lap does not gate, so it has no red count to report.
# Printing `red=0` from a lap that never looked would be the same false
# reassurance as the blind lap's `pushed=0 ... red=0`.
while IFS=$'\t' read -r N BR; do
  [ -n "${N:-}" ] || continue
  # Per-PR state, cleared HERE and not where it is set. A `continue` can leave
  # the loop from a dozen places below, so anything set mid-body outlives this
  # iteration unless it is reset at the top — and a stale REDERIVED would silently
  # skip the derived-layer rebuild for the next PR, which is the exact fault the
  # rebuild exists to prevent.
  REDERIVED=; CURRENT_RED=; REGMERGED=
  say "=== PR #$N  ($BR)"
  # Before anything is fetched or spent: a PR a live run is lapping is that run's (T-2929).
  if ! lap_lock_free "$N"; then
    if [ -n "$LOCK_HELD" ]; then
      say "  BEING LAPPED by a live run — left to it ($LOCK_SAID)"
      LAPPING=$((LAPPING+1))
    else
      say "  lap lock UNREADABLE — left alone rather than lapped blind over a run that may hold it:"
      say "    $LOCK_SAID"
      SKIPPED=$((SKIPPED+1))
    fi
    continue
  fi
  # THE TWO GUARDS THAT SAID FOUR WORDS AND NOTHING ELSE (T-1565). Both of these
  # were `... 2>/dev/null || { say "  fetch failed"; ... }`, with git's stderr
  # thrown away and the two failures wearing nearly the same four-word label. So
  # when #1629 failed here on 2026-09-21 (lap run 35624254338) the run summary
  # carried no reason at all: not which of the two failed, not git's own message,
  # not the ref it could not resolve. T-1521 measured it as a SECOND fault in
  # that same lap run and could only say "and something else went wrong too".
  #
  # Every other refusal in this lap names its step and tails its log — the broken
  # merge, the failed rebuild, the real conflict — which is how T-1521 was found
  # in the first place. These were the exception, and an exception in the
  # reporting is exactly where a second fault hides behind the first.
  if ! git fetch origin "$BR" -q >/tmp/lap-fetch.log 2>&1; then
    say "  FETCH of \`$BR\` FAILED — left alone:"
    tail -5 /tmp/lap-fetch.log | sed 's/^/    /'
    # THE LIKELIEST CAUSE, NAMED RATHER THAN LEFT TO BE GUESSED. A head branch
    # deleted under the lap — its PR merged from elsewhere, or the run that owned
    # it tidied up — makes git say "couldn't find remote ref", which reads like a
    # transport fault to anyone who does not already know the branch is gone. One
    # question to the remote settles it.
    if git ls-remote --exit-code --heads origin "$BR" >/dev/null 2>&1; then
      say "    origin still HAS \`$BR\`, so this is not a deleted branch — read git's message above."
    else
      say "    origin has NO branch \`$BR\` any more: it was DELETED under the lap."
      say "    There is nothing to lap. PR #$N wants closing, or re-cutting from \`$BASE\`."
    fi
    SKIPPED=$((SKIPPED+1)); continue
  fi
  if ! git checkout -B "lap/$N" "origin/$BR" -q >/tmp/lap-checkout.log 2>&1; then
    say "  CHECKOUT of \`origin/$BR\` into \`lap/$N\` FAILED — left alone:"
    tail -5 /tmp/lap-checkout.log | sed 's/^/    /'
    # Two causes worth telling apart, because the remedy is not the same one.
    if ! git rev-parse --verify -q "origin/$BR^{commit}" >/dev/null 2>&1; then
      say "    \`origin/$BR\` does not resolve even though the fetch above succeeded —"
      say "    the remote-TRACKING ref is what is missing, not the branch. A narrow"
      say "    remote.origin.fetch refspec does this: the fetch lands in FETCH_HEAD only."
    fi
    # ...and the one where THIS PR is innocent: the previous iteration left the
    # working tree dirty and checkout refuses to overwrite it. Naming the PR
    # without naming the dirt sends the reader to the wrong branch.
    DIRT=$(git status --porcelain 2>/dev/null | head -5)
    if [ -n "$DIRT" ]; then
      say "    the working tree was NOT clean when the lap reached this PR:"
      printf '%s\n' "$DIRT" | sed 's/^/      /'
    fi
    SKIPPED=$((SKIPPED+1)); continue
  fi

  # CURRENT WITH THE BASE IS NOT CURRENT WITH THE BASE'S GATES (T-1362). This
  # line used to end the iteration on "nothing to merge", and so it ended it on a
  # branch the base had just made RED. #1480 landed a new gate on dev; #1487
  # already agreed with dev about every file, so the lap printed
  #
  #   === PR #1487  (steward/t-1340-books-arrival-lists)
  #     already current — nothing to lap
  #
  # while four manifest-owned files sat stale on it and its gate read 4 red of
  # 513. `rederive.mjs --run` turned all four green; nobody ran it, because the
  # only two places this script rebuilds are inside the merge, and a branch with
  # nothing to merge never reaches either. #1518 sat the same way for two hours.
  #
  # ASK THE GATE, DO NOT GUESS AT IT. The obvious cure — rebuild every current
  # branch on every lap — is ~10 minutes of `--run` per PR per lap on trees that
  # almost never need it, and a hand-kept list of "the cheap checks" goes stale
  # exactly the way the layer does (T-1362's own finding, corrected within the
  # hour of writing it: eleven checks found one of #1518's five reds). The one
  # authority on what is stale is check.sh, and CI has ALREADY run it on this very
  # head: its `gate` check run is the verdict. Reading it is one REST call —
  # measured 0.45-0.49 s on three open PRs, 2026-10-04 — so the path every clean
  # PR takes on every lap costs half a second, and only a branch that is current
  # AND red pays for a rebuild.
  #
  # A RED GATE IS NOT ALWAYS A STALE DERIVATION. It may be the branch's own fault,
  # which no rebuild fixes — so a rebuild that moves nothing pushes NOTHING (an
  # empty lap commit on every pass to every red branch would be worse than the
  # bug), says so on the PR once per head, and the next lap reads that note and
  # does not spend the rebuild on the same head again.
  CURRENT_RED=
  if [ "$(git rev-list --count "HEAD..origin/$BASE")" -eq 0 ]; then
    HEAD_SHA=$(git rev-parse HEAD)
    VERDICT=$(lap_gate_verdict "$HEAD_SHA")
    case "$VERDICT" in
      completed:failure|completed:timed_out) ;;
      *) say "  already current — nothing to lap (its gate: ${VERDICT:-not run on this head})"
         NOOP=$((NOOP+1)); continue ;;
    esac
    STALE_MARK="PR lap: re-derived \`${HEAD_SHA:0:12}\` and nothing changed"
    if gh api --paginate "repos/$REPO/issues/$N/comments" --jq '.[].body' 2>/dev/null \
         | grep -qF "$STALE_MARK"; then
      say "  already current, gate RED — and a re-derive of this head already moved nothing:"
      say "    the red is this branch's own, not a stale derivation; left for its owner"
      SKIPPED=$((SKIPPED+1)); continue
    fi
    say "  already current with $BASE, but its gate is RED ($VERDICT) — re-deriving in place (T-1362)"
    CURRENT_RED=1
  fi

  BEFORE=$(git rev-parse HEAD)
  if [ -n "$CURRENT_RED" ]; then
    MERGED=0; U=
  else
    git merge "origin/$BASE" --no-edit >/tmp/lap-merge.log 2>&1
    MERGED=$?
    U=$(git diff --name-only --diff-filter=U)
  fi

  # A MERGE CAN FAIL WITHOUT LEAVING A CONFLICT, and this used to read as success.
  # The exit status was discarded and only `--diff-filter=U` was consulted, so a
  # merge that died before it began — `fatal: custom merge driver queue lacks
  # command line` is the one that bit, when .gitattributes routes a file to a
  # driver this shell did not register — left no conflicts, and the lap sailed on
  # to gate an UNMERGED tree (green, of course: it is the branch as it already
  # was), push nothing, and report "pushed — auto-merge can fire". Measured
  # 2026-09-10: PRs #1049 and #1051 were both reported pushed by run 79 and
  # neither branch moved; #1049 sat at the same head for over two hours while the
  # lane looked healthy. A lap that cannot tell you it did nothing is worse than
  # no lap, because the pile it leaves looks like somebody else's problem.
  if [ "$MERGED" -ne 0 ] && [ -z "$U" ]; then
    say "  MERGE FAILED with no conflict to resolve — this is a broken merge, not a disagreement:"
    tail -5 /tmp/lap-merge.log | sed 's/^/    /'
    git merge --abort 2>/dev/null
    SKIPPED=$((SKIPPED+1)); continue
  fi
  if [ -n "$U" ]; then
    REAL=$(comm -23 <(echo "$U" | sort -u) <(echo "$GENERATED" | sed '/^$/d' | sort -u))

    # ...AND THE TWO ASSET REGISTRIES, MERGED ENTRY BY ENTRY (T-2892, owner 2026-10-19).
    # assets/manifest.json and assets/manifest.web.json are one JSON object for the
    # whole town, keyed by GLB, and every bake rewrites the file whole — so two PRs
    # that bake DIFFERENT structures conflict on it without disagreeing about
    # anything. Measured 2026-10-19: #1104 conflicted with dev on manifest.json and
    # nothing else, and was left alone for it here until a steward run paid a whole
    # lap. Neither list above fits: no one command rebuilds the registry (the bake
    # writes it entry by entry), and taking ours would drop the other side's entries.
    # merge_asset_registry.py takes each entry from the side that changed it. An
    # entry both sides changed is refused — both rebuilt the same master — with one
    # exception it proves rather than assumes: a pure-Python asset (K01, K13, ...)
    # whose recipe moved on one side or both is emitted again on the merged tree and
    # kept only if every GLB comes out byte-identical (#1104's 26 K01 houses, after
    # T-2841 and T-2842 each touched the K01 generators). It writes all or nothing;
    # a refusal leaves the files in $REAL and the PR is left alone exactly as before.
    # CI's gate then holds the result: validate.py reads any entry gone stale.
    #
    # ONLY WHEN THE REST OF THE MERGE CAN CLEAR. If anything else in $REAL is a real
    # conflict the PR is left alone regardless, and the emitters would be reading a
    # tree with conflict markers in it (#1109's k01_frontage.py, 2026-10-19).
    if [ -n "$REAL" ] && [ -f chicago/4d/tools/merge_asset_registry.py ]; then
      REG=$(comm -12 <(echo "$REAL" | sort -u) \
                     <(python3 chicago/4d/tools/merge_asset_registry.py --list | sort -u))
      REST=$(comm -23 <(echo "$REAL" | sort -u) <(echo "$REG" | sort -u))
      if [ -n "$REG" ] && { [ -z "$REST" ] || { [ -f chicago/4d/tools/rederive.mjs ] \
           && node chicago/4d/tools/rederive.mjs --resolvable $REST >/dev/null 2>&1; }; }; then
        if python3 chicago/4d/tools/merge_asset_registry.py --resolve $REG >/tmp/lap-registry.log 2>&1; then
          say "  $(echo "$REG" | grep -c .) asset registr$( [ "$(echo "$REG" | grep -c .)" = 1 ] && echo y || echo ies) merged entry by entry"
          git add $REG; REGMERGED=$REG
          REAL=$(comm -23 <(echo "$REAL" | sort -u) <(echo "$REG" | sort -u))
          # Out of $U too: the generated-set step below runs `checkout --ours` on
          # everything left in $U, which would put ours back over the merge.
          U=$(comm -23 <(echo "$U" | sort -u) <(echo "$REG" | sort -u))
        else
          sed 's/^/    /' /tmp/lap-registry.log | head -4
        fi
      fi
    fi

    # ...AND THE DERIVED RESEARCH LAYER, WHICH IS THE SAME KIND OF THING AS THE
    # GENERATED FIVE and was left out only because nobody had enumerated it.
    # Measured 2026-09-10, on the first laps that could merge at all (#1058):
    # every one of the three surviving PRs was left alone for a REAL CONFLICT,
    # and every conflicting file was a tool output two runs had each re-derived —
    # seven directory crosswalks on #1051, the land-sale crosswalk and spend and
    # identity_master on #1055, the scene sidecar and the audit workbook on
    # #1053. Not one was a disagreement about the town.
    #
    # `rederive.mjs --resolvable` answers from tools/derived_manifest.json, which
    # ENUMERATES rather than pattern-matches, so what is in scope can be read.
    # It refuses the set as a whole if any member is unlisted or declares
    # hand_authored — half a merge is not a merge. The gate is what PROVES the
    # rebuild, and since the lap stopped running it itself (see the push below)
    # that gate is CI's: a wrong manifest entry makes the PUSHED branch go red,
    # so the worst case is a red pull request rather than a merged bad rebuild.
    # Auto-merge fires on a green required check and on nothing else.
    if [ -n "$REAL" ] && [ -f chicago/4d/tools/rederive.mjs ] \
       && node chicago/4d/tools/rederive.mjs --resolvable $REAL >/tmp/lap-rederive.log 2>&1; then
      say "  $(echo "$REAL" | grep -c .) conflict(s) in the derived research layer — rebuilding from source"
      git checkout --ours $REAL >/dev/null 2>&1; git add $REAL
      if ! lap_publish_mirror; then
        say "  the publish the rebuild reads failed — left alone:"; tail -6 /tmp/lap-publish.log | sed 's/^/    /'
        git merge --abort 2>/dev/null; SKIPPED=$((SKIPPED+1)); continue
      fi
      if ! ( cd chicago/4d && node tools/rederive.mjs --run ) >>/tmp/lap-rederive.log 2>&1; then
        say "  the rebuild itself failed — left alone:"; tail -6 /tmp/lap-rederive.log | sed 's/^/    /'
        git merge --abort 2>/dev/null; SKIPPED=$((SKIPPED+1)); continue
      fi
      REAL=
      REDERIVED=1
    fi

    if [ -n "$REAL" ]; then
      say "  REAL CONFLICT — left alone:"; echo "$REAL" | sed 's/^/    /'
      [ -s /tmp/lap-rederive.log ] && sed 's/^/      /' /tmp/lap-rederive.log | head -8
      git merge --abort 2>/dev/null
      MARK="PR lap: this branch disagrees with \`$BASE\` about content"
      # REST for both halves of this, for the reason the list above moved: `gh pr
      # view` and `gh pr comment` are GRAPHQL, and the steward PAT's GraphQL
      # budget is the one that runs out. Measured on lap 307, the first lap able
      # to list anything all day — every REAL CONFLICT it found was followed by
      #
      #     GraphQL: API rate limit already exceeded for user ID 4193586.
      #
      # so five PRs were correctly refused and NOT ONE of them was told why. From
      # GitHub they read as stuck pull requests with no explanation, which is the
      # exact failure this whole comment exists to prevent.
      if ! gh api --paginate "repos/$REPO/issues/$N/comments" --jq '.[].body' 2>/dev/null | grep -qF "$MARK"; then
        { printf '%s, not about bookkeeping, so the lap left it alone rather than pick a side.\n\n' "$MARK"
          printf 'Conflicting outside the generated set:\n\n```\n%s\n```\n\n' "$REAL"
          printf 'The generated files (build.json, the mirrors, the smoke ledger — and BOARD.md and\n'
          printf 'tickets.json, which are not even tracked any more) are regenerated by the lap and\n'
          printf 'never hand-merged. These are not those. This wants the\n'
          printf 'run that owns the ticket — or closing and re-cutting on a current `%s`.\n\n' "$BASE"
          printf -- '---\n_Generated by [Claude Code](https://claude.ai/code)_\n'
        } > /tmp/lap-comment.md
        # `jq -Rs` wraps the file as a JSON string so the body reaches the API
        # intact — it carries backticks, a fenced block and the conflicting paths,
        # and none of that survives being interpolated into a shell argument.
        if jq -Rs '{body: .}' < /tmp/lap-comment.md \
             | gh api -X POST "repos/$REPO/issues/$N/comments" --input - >/dev/null 2>/tmp/lap-comment.err; then
          say "  said so on the PR"
        else
          # NOT silent, even though it is best-effort. A conflict the lap refused
          # and could not explain is the worst of both: the PR does not move and
          # nobody is told why.
          say "  could not comment on #$N — $(tail -1 /tmp/lap-comment.err 2>/dev/null | cut -c1-120)"
          say "  the conflict above stands; it is in this log and not on the PR"
        fi
      fi
      SKIPPED=$((SKIPPED+1)); continue
    fi
    say "  $(echo "$U" | grep -c .) generated conflict(s) — regenerating"
    # Split the generated conflicts: the ones the base still tracks are resolved by
    # taking ours and letting the tools rewrite them; the ones the base has
    # UNTRACKED are resolved by removing them (see UNTRACKED_GENERATED above).
    DROP=$(comm -12 <(echo "$U" | sort -u) <(echo "$UNTRACKED_GENERATED" | sed '/^$/d' | sort -u))
    KEEP=$(comm -23 <(echo "$U" | sort -u) <(echo "$UNTRACKED_GENERATED" | sed '/^$/d' | sort -u))
    if [ -n "$DROP" ]; then
      say "  $(echo "$DROP" | grep -c .) of them are untracked on $BASE — removing, not keeping (T-0937)"
      git rm -q -f --ignore-unmatch $DROP >/dev/null 2>&1
    fi
    if [ -n "$KEEP" ]; then
      git checkout --ours $KEEP >/dev/null 2>&1; git add $KEEP
    fi
  fi

  # TWO BRANCHES MINTED THE SAME TICKET ID — bookkeeping, so the lap heals it.
  # `ticket.mjs nextIdNum` scans every origin ref before it mints, so this is not
  # a missing guard but the window between minting an id and pushing the branch
  # that carries it; no scan can close it. Measured 2026-09-10: PRs #1048 and
  # #1049 each filed T-0988 ten minutes apart. The merge is CLEAN — git has no
  # opinion about two files with the same front-matter id — and then check.sh
  # fails on the duplicate AND on the survivor's queue line, which merge-queue.mjs
  # ate because it reconciles QUEUE.md by id. Neither branch is wrong about
  # anything. Same line this script already draws for the files a tool owns: a
  # number nobody chose on purpose is not a disagreement about the town.
  # It REFUSES rather than guess when it cannot tell which side is the branch's,
  # and a refusal is a non-zero exit that stops this PR here.
  if [ -f chicago/4d/tools/resolve_id_collisions.mjs ]; then
    if ! ( cd chicago/4d && node tools/resolve_id_collisions.mjs --base "origin/$BASE" ) \
         >/tmp/lap-ids.log 2>&1; then
      say "  TICKET ID COLLISION it would not resolve — left alone:"
      tail -6 /tmp/lap-ids.log | sed 's/^/    /'
      git merge --abort 2>/dev/null; SKIPPED=$((SKIPPED+1)); continue
    fi
    grep -E '^ticket ids: T-' /tmp/lap-ids.log | sed 's/^/  /' || true
  fi

  # THE DERIVED LAYER IS REBUILT ON EVERY MERGE, NOT ONLY ON A CONFLICT — and the
  # difference between those two is a whole class of red pull request.
  #
  # The block above rebuilds it when a conflicting file is one the manifest owns.
  # That covers the case where BOTH sides re-derived the same file. It does not
  # cover the one that actually bites: `$BASE` changes an INPUT to a derived file
  # that this branch never touched. git has no conflict to report — there is no
  # disagreement, only a new fact — so nothing triggered a rebuild, and the
  # branch carried a derived file that no longer follows from its own inputs.
  #
  # CAUGHT LIVE on #1316, 2026-09-14. Lap 314 merged `dev` into it with ZERO
  # conflicts and pushed. The gate then went red on one step of 397:
  #
  #   * …and the later HOME addresses re-derive through the residence clauses
  #
  # `dev` had just taken #1315 (T-1119), which added a fourth Sherman to the
  # residents layer. `residence_back_projection.json` reads that layer, so the
  # committed file said 57 addresses adjudicated where its own tool now derives
  # 58. Nothing in the merge disagreed about anything; the answer had simply
  # moved underneath it. Reproduced locally and confirmed: `rederive.mjs --run`
  # turns that step green (`58 residence addresses adjudicated, 11 placed, 47
  # refused`), and it is the ONLY file in the tree it changes.
  #
  # This is not new to the gate removal — the old lap hit the same stale file and
  # simply declined to push, leaving the PR `dirty` with no explanation instead
  # of red with one. Either way it did not merge. It is cheap to just fix:
  # measured 19 SECONDS for all 28 steps on a real lapped tree, against ~7
  # minutes for the gate this replaced.
  #
  # `--run` is idempotent by construction — every step re-derives from committed
  # inputs — so running it on a branch that needed nothing costs those seconds
  # and changes nothing, which is the right trade against a red PR nobody owns.
  # `$REDERIVED` is set by the conflict path above, which has already run exactly
  # this. Running it twice would only cost the same seconds again.
  if [ -z "${REDERIVED:-}" ] && [ -f chicago/4d/tools/rederive.mjs ]; then
    say "  publishing the mirror, then rebuilding the derived layer against the merged inputs"
    lap_publish_mirror || {
      say "  the publish the derived-layer rebuild reads failed — left alone:"
      tail -6 /tmp/lap-publish.log | sed 's/^/    /'
      git merge --abort 2>/dev/null; SKIPPED=$((SKIPPED+1)); continue; }
    ( cd chicago/4d && node tools/rederive.mjs --run ) >>/tmp/lap-rederive.log 2>&1 || {
      say "  the derived-layer rebuild failed — left alone:"
      tail -6 /tmp/lap-rederive.log | sed 's/^/    /'
      git merge --abort 2>/dev/null; SKIPPED=$((SKIPPED+1)); continue; }
  fi

  # RECONCILE, THEN PRUNE, BEFORE THE BOARD. Both halves of the same fault, and the
  # lap could only ever do one of them.
  #
  # PRUNE is the easy direction: a branch's QUEUE.md is a snapshot and `$BASE` closes
  # tickets under it, so an open PR ends up listing work that has already finished —
  # which `ticket.mjs check` refuses, and which was the commonest red a lap left
  # behind: #1387, #1389 and #1392 all went red on it on 2026-09-17 alone.
  #
  # RECONCILE is the direction that actually held the queue shut, and it is this
  # script's own doing. QUEUE.md is in GENERATED above, so a conflict in it is cleared
  # by taking a side and letting a tool rewrite the file — and for this file the tool
  # was `board`, which builds BOARD.md FROM the queue and can only preserve what the
  # side it took already said. Take the branch's side and every line `$BASE` added while
  # the PR was open is GONE. Measured the same afternoon on the two PRs this lap had
  # just pushed: #1400 missing 28 of dev's lines and #1392 missing 27, both red on the
  # single step `ticket queue` out of 439 — and `prune` ran on both, correctly, and
  # could do nothing, because a prune only deletes.
  #
  # Neither invents an ordering. `reconcile` rebuilds on the base's queue and puts each
  # of the branch's own lines back after the same line it followed on the branch; a line
  # that led the branch's queue goes back to the top. The owner ranks this file.
  # AND THE SCENE IS NOT RE-RUN ALONE (T-1661). This block re-runs compile_scene
  # because `rederive.mjs --run`'s SECOND PASS rewrites the resident cards the scene
  # is compiled from, so the scene the sequence built is stale by the time the
  # sequence ends. But the manifest places 37 more steps BELOW compile_scene, and
  # the first of them is `compile_source_use.py`, which exports "current-scene
  # membership" out of the two files compile_scene writes. Re-running the scene bare
  # therefore stranded source-use on the PRE-merge scene: measured on PR #105's lap
  # commit `4455713`, `owner_chicago_1835_reconstruction_spec_2026` was written with
  # 3582 claims where a correct derivation gives 3620 — 38 gone, nothing in the tree
  # saying so, and three of check.sh's 657 steps red on a branch GitHub reported as
  # merged and up to date. That is the worst shape a lap failure can take, because
  # this same sweep is what merges green steward PRs.
  #
  # `--tail` runs that step and every step the manifest puts after it, in manifest
  # order, and nothing else — no second pass, which sits above it and would move the
  # population back under what the tail just settled. Naming the step and letting the
  # manifest supply the rest is what keeps this fixed: a step inserted below
  # compile_scene tomorrow is picked up with no edit here. `rederive.mjs --callers`
  # is the gate that holds it, and check.sh runs it against this file.
  ( cd chicago/4d \
    && node tools/stamp-changelog.mjs \
    && bash tools/tickets.sh \
    && node tools/ticket.mjs reconcile --base "origin/$BASE" \
    && node tools/ticket.mjs prune \
    && node tools/ticket.mjs board \
    && node tools/rederive.mjs --tail tools/compile_scene.py \
    && ./tools/publish.sh ) >/tmp/lap-regen.log 2>&1 || {
      say "  regeneration failed — see log"; tail -5 /tmp/lap-regen.log | sed 's/^/    /'
      git merge --abort 2>/dev/null; SKIPPED=$((SKIPPED+1)); continue; }

  git add -A
  if [ -n "$CURRENT_RED" ]; then
    git -c user.name="polecat-steward" -c user.email="steward@polecat.live" \
        commit -q -m "Lap: re-derived against $BASE's gates — already current, and red

This branch had nothing to merge from $BASE, and its gate was red. The derived
layer was rebuilt from its own committed inputs (rederive.mjs --run, then the
settled tail) and this is what moved. Nothing in this branch's own diff was
touched; CI re-gates the push (T-1362)." 2>/dev/null
  else
  git -c user.name="polecat-steward" -c user.email="steward@polecat.live" \
      commit -q --no-edit -m "Lap onto $BASE: generated files regenerated, not merged

The five files a tool owns conflict on every merge and are never hand-merged —
ticket.mjs board, publish.sh and compile_scene rewrite them from source. Nothing
in this branch's own diff was touched.

Merge drivers registered from $BASE rather than from this branch, so a branch cut
before T-0831 resolves the same way one cut after it does (T-0857).${REGMERGED:+

Asset registries merged entry by entry (merge_asset_registry.py, T-2892): each
entry taken from the side that rebaked it, and any pure-Python asset whose recipe
moved on both sides emitted again on the merged tree, byte-identical.
$REGMERGED}" 2>/dev/null
  fi

  # THE LAP NO LONGER GATES BEFORE PUSHING, AND THIS IS THE ROOT-CAUSE FIX.
  #
  # It used to run the whole of `check.sh` here — ~15 minutes — and push only on
  # green. That is redundant and it is the reason the queue would not converge.
  #
  # REDUNDANT: chicago-4d-check.yml triggers on `push` to ANY branch under
  # `chicago/4d/**` AND on `pull_request`. The moment this push lands, the same
  # tree is gated by CI, and the PR's merge result is gated too. The lap was
  # doing the identical work first, on the critical path, and CI then did it
  # again.
  #
  # AND IT IS WHY THE QUEUE NEVER DRAINED. Every merge into `$BASE` re-dirties
  # every other open PR, because GitHub recomputes mergeability without this
  # repo's merge drivers (T-0857 above). The lap is the only cure — and it could
  # only apply that cure to about ONE PR every fifteen minutes, because each one
  # waited out a full gate. Measured 2026-09-14:
  #
  #   lap 297  42.1 min      lap 307  19.2 min, pushed=1
  #   lap 309  14.4 min      laps 301/303/304  1.4 min each — they pushed
  #                          NOTHING, so no gate ran, which is the tell
  #
  # Merges were landing every few minutes. A cure that takes fifteen minutes per
  # patient, against a disease that reinfects every patient every few minutes,
  # never catches up — and #1315 proved it: resolved by hand, gated green at 397
  # steps, pushed, and back to `dirty` the moment the next PR merged.
  #
  # NOTHING UNSAFE CAN MERGE AS A RESULT. Auto-merge fires only on a green
  # required check, so a bad merge pushed here becomes a RED pull request, which
  # is visible and recoverable — not a merged one. The refusal path above is
  # untouched: a conflict outside the generated set is still left alone, because
  # that is a judgement and not a gate.
  #
  # The trade, stated plainly: a PR branch may briefly carry a merge whose gate
  # then goes red. That is strictly better than the same PR sitting `dirty`
  # forever with nobody told why.

  # SAY WHAT ACTUALLY HAPPENED. `git push` to a ref that is already at HEAD is
  # "Everything up-to-date" and exits 0, so the old form printed "pushed — gate
  # will re-run and auto-merge can fire" for a push that moved nothing and a gate
  # that will not re-run. That sentence is the one a person reads to decide the
  # lane is healthy, so it has to be earned: compare HEAD against the head this
  # PR started the lap on, and only claim a push when the branch really moved.
  if [ "$(git rev-parse HEAD)" = "$BEFORE" ] && [ -n "$CURRENT_RED" ]; then
    say "  re-derived, and NOTHING CHANGED — the red is not a stale derivation; left for its owner"
    # Once per head, and only so the next lap can read it: the marker is what
    # stops a red branch paying for the same no-op rebuild on every pass.
    { printf '%s, so the lap left this red branch alone.\n\n' "$STALE_MARK"
      printf 'It was already current with `%s` and its `gate` read `%s`. The lap rebuilt the\n' "$BASE" "$VERDICT"
      printf 'derived layer in place from the branch'"'"'s own inputs and the tree came out identical,\n'
      printf 'so whatever the gate refuses is not a stale derivation — it wants the run that owns\n'
      printf 'the ticket. The lap will not re-derive this head again; a new push resets it (T-1362).\n\n'
      printf -- '---\n_Generated by [Claude Code](https://claude.ai/code)_\n'
    } > /tmp/lap-comment.md
    if jq -Rs '{body: .}' < /tmp/lap-comment.md \
         | gh api -X POST "repos/$REPO/issues/$N/comments" --input - >/dev/null 2>/tmp/lap-comment.err; then
      say "  said so on the PR"
    else
      say "  could not comment on #$N — $(tail -1 /tmp/lap-comment.err 2>/dev/null | cut -c1-120)"
      say "  the next lap will re-derive this head again, having no note to read"
    fi
    SKIPPED=$((SKIPPED+1))
  elif [ "$(git rev-parse HEAD)" = "$BEFORE" ]; then
    say "  the lap produced no new commit — nothing to push, and this PR is unchanged"
    NOOP=$((NOOP+1))
  # ...AND READ AGAIN AT THE PUSH (T-2929). The merge and the tail re-derive above take
  # minutes, and a run can take the lock inside them — #1132's was taken 19 minutes
  # before this lap pushed. Its lap wins: it gates before it pushes and this does not,
  # so this lap's commit is dropped here and never reaches the branch.
  elif ! lap_lock_free "$N"; then
    if [ -n "$LOCK_HELD" ]; then
      say "  a run took lap/pr-$N while this lap rebuilt — NOT pushed; its lap wins ($LOCK_SAID)"
      LAPPING=$((LAPPING+1))
    else
      say "  lap lock UNREADABLE at the push — NOT pushed: $LOCK_SAID"
      SKIPPED=$((SKIPPED+1))
    fi
  elif git push origin "HEAD:$BR" >/dev/null 2>&1; then
    say "  pushed $(git rev-parse --short "$BEFORE") → $(git rev-parse --short HEAD)"
    say "  — gate will re-run and auto-merge can fire"; PUSHED=$((PUSHED+1))
  else
    say "  push rejected (branch moved under the lap?)"; SKIPPED=$((SKIPPED+1))
  fi
done <<< "$PRS"

say ""

# --- claim markers nobody released ------------------------------------------
# A claim is a branch, `claim/t-NNNN`, and NOTHING ELSE COLLECTS THEM. The
# steward janitor sweeps open PULL REQUESTS and a marker has none; the 3h
# staleness rule only lets the NEXT claim on that same ticket steal it, which
# never comes once the ticket is closed and out of the queue.
#
# So they accumulated. Measured 2026-09-14: nineteen markers on the remote, the
# oldest three days old, and seventeen of the nineteen belonging to tickets that
# were no longer open. The largest single cause was `ticket.mjs split` never
# releasing — fixed in the tool — but a run that DIES mid-work leaves one too,
# and no fix in the tool can help there because the run is gone.
#
# The lap is the right broom: it already runs on every push to dev, it already
# holds the credentials, and `claims --sweep` deletes only markers older than
# RUN_HOURS — which the claim path itself already treats as dead and steals.
# Best-effort, and never the lap's exit status: a marker is litter, not a block.
# $WORK, not a relative path: the loop above walks in and out of checkouts, so
# the only directory this script can name with confidence is the one it resolved
# at the top.
if [ -f "$WORK/chicago/4d/tools/ticket.mjs" ]; then
  say "claim markers:"
  ( cd "$WORK/chicago/4d" && node tools/ticket.mjs claims --sweep 2>&1 ) \
    | tail -n 60 | while IFS= read -r line; do say "  $line"; done
else
  say "claim markers: tools/ticket.mjs is not in this checkout — not swept"
fi

say ""
say "PR lap: pushed=$PUSHED already-current=$NOOP left-alone=$SKIPPED being-lapped=$LAPPING"
say "  (gating is CI's — every push above re-runs the gate and the PR's merge result)"
