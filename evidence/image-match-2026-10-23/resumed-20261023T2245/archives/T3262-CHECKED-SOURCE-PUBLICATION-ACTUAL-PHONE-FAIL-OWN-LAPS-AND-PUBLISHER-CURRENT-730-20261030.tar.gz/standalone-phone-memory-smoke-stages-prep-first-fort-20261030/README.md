Optional generic native published-smoke performance legs. No source/runtime job launched here; original8controllerhelpers remain byte-exact/frozen.

Uses their bound actualsourcegate/nativecheckpoint and same guarded ordinaryPRIMARY publication, with explicit native stage and viewport scope. New outdir namespaces every log/reaper/raw/screenshot/receipt.

python3 /workspace/standalone-phone-memory-smoke-stages-prep-first-fort-20261030/smoke_stages.py --expect-head ACTUAL_NATIVE_HEAD --expect-tree ACTUAL_CHECKED_TREE --expect-branch ACTUAL_BRANCH --ticket T-3262 --stages 14 --viewports both --outdir /workspace/OWNED-NEW-PART14-OUTPUT --execute

For remaining diff-selected legs use explicit native --stages 1-3 or7-12 and matching unique --outdir; each can use --viewports desktop/mobile/both. The actual diff map is1-3,7-12,14. Only selectedpassedviewport×part cells are qualified. PartiallegPASS is notwholemapPASS; all15rendererparts are never claimed. Source-onlygeometry/bytecontracts are separateactualproofs, not substitution silently claimed here. Native smoke assertions, waits, viewports, screenshot pipeline and stage names are unchanged. Historicaldesktopstage14takes29min; no invented600sPASScriterion or shortenednativewaits. Actualfailedleglogs and remainingviewportlegresults remain honest.

Source/indexsemantics/config/allrefs/all7exactsourcehashes/criticalpublishedhashes are guarded beforeandafter eachleg. TMPshortowned/workspace24MiBreserve and512MiBfloor/callerTMP1.8GB unchanged; ownprivateprofiles retired only after actualreapers/sourceguards. Rootmustschedule serially; no import/sourcewriter/browser/meter overlap.
