# T-2372: source adoption refresh observed on 9117, future base unknown

**External proposal only.** Read-only preparation and validation passed against actual primary HEAD `9117b2263cf0aeb5fea33dec4a87ee519c5b41af`, while root owned the seven staged T-3262 files and its full gate. None of the old 2,177 resident serialization changes is presumed present. This packet does not apply sources, run a native owner/gate/browser, change Git refs or renew a claim. It contains no duplicate GLB or picture binaries and remains below 200 KB.

The actual post-performance, PR-1456 landing and changelog-fold base is **unknown**. `observation/ADOPTION-PLAN.json` deliberately says `final_base_known:false` and cannot be applied. The sole writer must prepare a new immutable entrywise binding against the actual final checkout after those operations; no future SHA is guessed.

## Accepted form and source review remain exact

The school keeps all 20 accepted leaf edits, including the previously reviewed research-note supersession, yielding exact record `bca1984c8d1993e107d502930380e5cec5b3443fca97249fbab7e6d8eac6e161`. The accepted native MASTER is `fb141fef3f348b494ffbf1bc2479427d0cec499001605cdcb34ce52c93c0787a`, WEB `f120aa9abc970bb5b0b28f82c5fd176b268ba67923cea9b31de9967c8c9bf804`; camera `ca0926793cd9e12293b10693dd0e9bfcfce3ca2a0e16a85e3cfe670a1ed9aa28` and source photograph `1a63b75fea04e52cbdbbc5ffb2e85749cf648454970cb1bec0d8426a2cba61b9` are unchanged. The separate reviewed match retains exactly seven dispositions: two fixed, two within tolerance and three not shown, with nothing open. The raw unreviewed capture and its original receipt stay in their closed authority.

The source record and credited stream remain exact. The owner's attributed project-reference approval is retained; unknown original publication/artist, school-versus-annex identification, date and camera/dimension limits are not upgraded to public domain or historical certainty. The explicit `not_pictured` ruling preserves honest building grade despite the diagnostic picture registration. No new photo question, follow-up ticket or geometry trial is proposed.

## Current recipe changed; do not relabel the old native row

The actual old selected-owner recipe was `2fe83632046f2462e58524944e13e970ace9824693f5141f3769c1b726537f44`. Current 9117 computes **`cbda020bf1a233f347520ca822a97c032efb99863e1bf9ab93b92ceb51856665`**. The current school geometry closure has six modules; only `log_dwelling.py` differs. Current parameters remove six unused optional fields, all previously `None`: end-gable courses, frame-addition front set-out/ridge stack/roof pitch/upper windows and ridge-stack cap. Frame addition is false for this school.

`PURE-PARITY.json` records an actual CPU2 pure-Python comparison of old native-source and current producers using the real mesh accumulator before Blender emission: **all 1,050 vertices, 263 faces, winding, confidence, material indices, named materials and material specifications are exact**. Shared resolved parameter fields are exact. This is useful default-path semantic proof; it is not a new native export. The old/current emit and shared geometry modules remain exact. K01/K08/K11 and other changed producer modules are explicitly bound and priced as outside the selected log-school execution/geometry closure. No blanket parity claim is made for those other building families.

Consequently the source proposal contains **no typed replacement recipe or historical whole registry postimage**. After source application, one ordinary selected canonical School build must produce the genuine current manifest row, followed by the official selected WEB step. Both are expected to reproduce the accepted fb14/f120 bytes; a different output stops for review instead of changing the accepted picture tuple. `verify_native_refresh.py` checks future actual native receipts, the one-name WROTE file, current computed recipe and exact model bytes, plus all foreign registry rows/order/outer metadata. It never manufactures a registry entry.

## Eight source operations, four native-owner outputs

The concrete observed proposal has eight source/review operations: 20 school-record leaves, exact diagnostic camera, credited image stream, exact reviewed match, actual accepted side-by-side, one own grade ruling, two own STORE entries and the exact 3,701-byte Liberty suffix. Shared grade/STORE data is merged into the current structures entrywise. Liberty application preserves the entire current prefix. Direct artifacts reference existing immutable donors; no raw model is copied into this packet.

The four model/registry paths are guarded current preimages and future native-owner outputs, not source-controller payload. Current jaunts and every source they cite remain protected. All **279 dependencies** are bound explicitly, including current generator sources, selected capture/decoder code, actual authority receipts, source/rights/image donors, owner tools, shared aggregates and four performance files. Neither railway.js, spatial-batch.js nor their two performance checks is an adoption target or part of the selected school geometry/capture module closure.

`apply_sources.py` defaults to read-only validation and passed on the observed 9117 proposal. Actual application requires a fresh `--final-base-known` proposal, the exact current head, a clean claimed `steward/t2372-*` branch, no active merge, the sole-writer lease and a current immutable original-School claim receipt. It atomically writes only eight source paths with a fsynced per-path journal; it cannot write assets/registries, stage, commit, run owners or update refs. School's coordinator-reported claim is valid through 13:31 UTC; root publisher must verify/renew the native original claim when needed. This packet does not extend that lease.

## Later commands, after the actual performance/1456 landing and fold

Run a fresh preparer on the actual clean School branch. Replace `ACTUAL_CURRENT_HEAD` with the real immutable HEAD, never the old observed 9117 value by assumption:

```sh
source /workspace/shared/resume-chicago-env.sh
python -B /workspace/T2372-adoption-ready-9117-secondfort-20261030/refresh.py --output /workspace/T2372-adoption-ready-9117-secondfort-20261030/rebound-ACTUAL --expected-head ACTUAL_CURRENT_HEAD --final-base-known
python -B /workspace/T2372-adoption-ready-9117-secondfort-20261030/apply_sources.py --plan /workspace/T2372-adoption-ready-9117-secondfort-20261030/rebound-ACTUAL/ADOPTION-PLAN.json --expected-head ACTUAL_CURRENT_HEAD
```

Only the sole writer, with current native claim receipt and released primary, may add `--apply-sources --claim-receipt ACTUAL_CURRENT_SCHOOL_RECEIPT` and `SCHOOL_ADOPTION_LEASE=original-T2372-claimed-primary-released`. That application has **not** run here.

After application and a separately scheduled native window, use ordinary pinned canonical `generators/build.py --only chappel_infant_school --scene 1835 --wrote ...` and `tools/web_derivatives.sh --only chappel_infant_school__log_1833.glb`, each with the usual reaper/CPU/floor wrapper. Verify those actual receipts with `verify_native_refresh.py --plan ... --build-reaper ... --web-reaper ... --wrote ...`. Do not transplant the old 2fe native row or update only its hash.

Then build the current Prairie image library, run the current native tail from `tools/compile_liberties.py`, and explicitly run `tools/generate_alley_lanes.py` plus `--check`; it is a checked owner outside the historic manifest tail and the narrower school removes the prior alley-mouth cut. Native scene/grade/picture/source/ground outputs come from those current owners, followed by official publish and the original School image gate.

Fresh Full 390×780 and 1280×800 Normal/ByGrade app review still owes materials, Images/Sources/Research/Liberties, ground/rear envelope/neighboring props and rails, and a street-to-door walking approach. Complete relevant published smoke/phone, source/preflight gate, checked commit, policy PR, exact current-head CI, safe dev merge and official settlement. No PR, app acceptance or T-2372 completion is claimed here.
