"""Entrywise external School source proposal. No application, owner, native or Git writes."""
from pathlib import Path
import argparse,copy,datetime,hashlib,json,os,stat,subprocess
import audit

P=Path(__file__).resolve().parent;R=Path('/workspace/chicago');A=R/'chicago/4d'
OLD=Path('/workspace/T2372-entrywise-refresh-20261030');BASE=OLD/'current-packet'
CANON=Path('/workspace/T2372-canonical-registration-prep-20261030');NATIVE=Path('/workspace/T2372-native-selected-bake-reuse-20261030')
LEAF=Path('/workspace/T2372-reprepared-BE501-school-agent-v3-20261029/bundle-v2/PLAN.json')
SID='chappel_infant_school';KEY=SID+'__log_1833.glb'
sha=lambda b:hashlib.sha256(b).hexdigest();pf=lambda p:sha(Path(p).read_bytes())
enc=lambda v:(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode()
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def state():return dict(head=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),
 branch=git('branch','--show-current').decode().strip(),index=pf(R/'.git/index'),config=pf(R/'.git/config'),
 refs=sha(git('show-ref')),status=sha(git('status','--porcelain=v1','-uno')),active_merge=(R/'.git/MERGE_HEAD').exists())
def bound(p):
 p=Path(p)
 if not p.exists():return None
 assert p.is_file()and not p.is_symlink(),str(p)
 return dict(bytes=p.stat().st_size,sha256=pf(p),mode=oct(stat.S_IMODE(p.stat().st_mode)))
def get(d,keys):
 for k in keys:
  if isinstance(d,dict)and k not in d:return {'__expected_absent__':True}
  d=d[k]
 return d
def put(d,keys,value):
 for k in keys[:-1]:d=d[k]
 d[keys[-1]]=copy.deepcopy(value)
def materialize(op):
 dest=R/op['path'];kind=op['kind']
 if kind=='copy_exact':return Path(op['donor']).read_bytes()
 if kind=='school20':
  d=json.loads(dest.read_bytes())
  for leaf in op['leaves']:
   assert get(d,leaf['path'])in [leaf['old'],leaf['new']],('Third-value School leaf',leaf['path'])
   put(d,leaf['path'],leaf['new'])
  expected=Path(op['donor']).read_bytes();assert d==json.loads(expected);return expected
 if kind=='grade_entry':
  d=json.loads(dest.read_bytes());r=op['entry'];key=lambda x:(x.get('scene'),x.get('structure'),x.get('picture'))
  assert not any(key(x)==key(r)for x in d['pictured']);own=[x for x in d['not_pictured']if key(x)==key(r)];assert not own or own==[r]
  if not own:d['not_pictured'].append(r)
  return enc(d)
 if kind=='STORE_entries':
  d=json.loads(dest.read_bytes())
  for name,row in op['entries'].items():assert name not in d['files']or d['files'][name]==row;d['files'][name]=row
  d['bytes']=sum(x['bytes']for x in d['files'].values());return(json.dumps(d,indent=1,ensure_ascii=False)+'\n').encode()
 if kind=='Liberty_suffix':
  prefix=dest.read_bytes();assert b'### L-T2372-narrow-school-front 'not in prefix;return prefix+Path(op['fragment']).read_bytes()
 raise AssertionError(kind)
def prepare(output,expected_head,final_base_known=False):
 os.sched_setaffinity(0,{2});before=state();assert before['head']==expected_head
 out=Path(output).resolve();assert out.is_relative_to(P)and not out.exists()
 if final_base_known:assert not before['active_merge']and not git('status','--porcelain=v1','--untracked-files=all')
 template=json.loads((BASE/'ADOPTION-PLAN.json').read_bytes());parity=audit.audit()
 deps={}
 def guard(p):
  p=Path(p);b=bound(p);assert b;deps[str(p)]=b
 for p in[A/'generators'/p.relative_to(A/'generators')for p in(A/'generators').rglob('*')if p.is_file()and'__pycache__'not in p.parts and p.suffix not in ['.pyc','.pyo']]:guard(p)
 for row in template['native_modules']+template['reused_closed_static']:guard(row['source']);assert pf(row['source'])==row['sha256']
 for p in[BASE/'ADOPTION-PLAN.json',OLD/'CLOSED-MANIFEST.json',CANON/'CLOSED-MANIFEST.json',CANON/'CAPTURE-RESULT.json',
  CANON/'RAW-NATIVE-UNREVIEWED.match.json',NATIVE/'CLOSED-MANIFEST.json',NATIVE/'RESULT.json',NATIVE/'closed-authority/NATIVE-ENTRIES.json',LEAF]:guard(p)
 leaves=copy.deepcopy(json.loads(LEAF.read_bytes())['leaf_changes']);assert len(leaves)==20
 record=NATIVE/'closed-authority/candidate'/f'{SID}.json';reviewed=json.loads(record.read_bytes());note=next(x for x in leaves if x['path']==['research_note']);assert reviewed['research_note'].startswith(note['new']);note['new']=reviewed['research_note']
 ops=[dict(path=f'chicago/4d/data/structures/{SID}.json',kind='school20',leaves=leaves,donor=str(record))]
 for rel in[f'chicago/4d/data/reference_views/{SID}/shore-drawing.json','chicago/prairie_1904_v1/research/images/stream-eliza-chappel-school-reference.json',
   f'chicago/4d/data/reference_views/{SID}/shore-drawing.match.json',f'chicago/4d/docs/RESEARCH/photo-match/{SID}/shore-drawing-side-by-side.jpg']:
  row=next(r for r in template['paths']if r['path']==rel);ops.append(dict(path=rel,kind='copy_exact',donor=row['postimage']))
 graded=json.loads((BASE/'postimages/chicago/4d/data/structure_grades.json').read_bytes());own=[r for r in graded['not_pictured']if r.get('structure')==SID];assert len(own)==1
 ops.append(dict(path='chicago/4d/data/structure_grades.json',kind='grade_entry',entry=own[0]))
 stored=json.loads((BASE/'postimages/chicago/prairie_1904_v1/research/images/STORE.json').read_bytes());names=template['source_rebind_proof']['STORE']['own_names']
 ops.append(dict(path='chicago/prairie_1904_v1/research/images/STORE.json',kind='STORE_entries',entries={n:stored['files'][n]for n in names}))
 fragment=BASE/'fragments/LIBERTY-APPEND.md';assert pf(fragment)==template['source_rebind_proof']['Liberty']['suffix_sha256'];guard(fragment)
 ops.append(dict(path='chicago/4d/docs/LIBERTIES.md',kind='Liberty_suffix',fragment=str(fragment)))
 for op in ops:
  if op.get('donor'):guard(op['donor'])
  op['before']=bound(R/op['path']);raw=materialize(op);op['after']=dict(bytes=len(raw),sha256=sha(raw),mode=op['before']['mode']if op['before']else'0o644')
 assert len(ops)==8 and len({o['path']for o in ops})==8
 protected=[]
 for jaunt in(A/'data/jaunts').glob('*.json'):
  guard(jaunt);text=jaunt.read_text();sources=[]
  for source in(A/'data/sources').glob('*.json'):
   if '"'+source.stem+'"'in text:guard(source);sources.append(str(source))
  protected.append(dict(jaunt=str(jaunt),source_paths=sources))
 for rel in['tools/derived_manifest.json','tools/compile_liberties.py','tools/compile_scene.py','tools/compile_source_use.py','tools/generate_alley_lanes.py','tools/publish.sh','tools/bake.sh','tools/web_derivatives.sh']:guard(A/rel)
 for rel in['railway.js','spatial-batch.js']:guard(A/'renderers/web/js'/rel)
 for rel in['check_confidence_lane.mjs','test_rail_geometry_lifecycle.mjs']:guard(A/'tools'/rel)
 source=A/'data/sources/eliza_chappel_school_shore_view.json';guard(source);assert pf(source)==template['source_catalogue']['sha256']
 camera_op=next(o for o in ops if o['path'].endswith('shore-drawing.json'));camera=json.loads(materialize(camera_op));photo=((R/camera_op['path']).parent/camera['photo']).resolve();guard(photo)
 match=json.loads(materialize(next(o for o in ops if o['path'].endswith('shore-drawing.match.json'))))
 assert match['verdict']=='matches'and len(match['differences'])==7 and all(x['status']!='open'for x in match['differences'])
 assert match['camera_sha256']==camera_op['after']['sha256']==template['camera']['sha256']and match['photo_sha256']==pf(photo)==template['original_photo']['sha256']
 native_expected={'MASTER':'fb141fef3f348b494ffbf1bc2479427d0cec499001605cdcb34ce52c93c0787a','WEB':'f120aa9abc970bb5b0b28f82c5fd176b268ba67923cea9b31de9967c8c9bf804'}
 for typ,folder in [('MASTER','native-master'),('WEB','native-web')]:p=NATIVE/'closed-authority'/folder/KEY;guard(p);assert pf(p)==native_expected[typ]
 assert match['glb_sha256']==native_expected['MASTER'] and camera['diagnostic_only']is True
 native_paths={rel:bound(R/rel)for rel in[f'chicago/4d/assets/gltf/{KEY}',f'chicago/4d/assets/web/{KEY}','chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json']}
 native_registry_guards={}
 for registry,table in [('manifest.json','assets'),('manifest.web.json','masters')]:
  d=json.loads((A/'assets'/registry).read_bytes());canon=lambda value:json.dumps(value,sort_keys=True,separators=(',',':')).encode()
  native_registry_guards[registry]=dict(table=table,rows=len(d[table]),foreign_ordered_rows_sha256=sha(canon([(k,v)for k,v in d[table].items()if k!=KEY])),outer_metadata_sha256=sha(canon({k:v for k,v in d.items()if k!=table})))
 assert state()==before
 plan=dict(status='FINAL_BASE_REBOUND_SOURCE_ONLY_PREPARED_NOT_APPLIED'if final_base_known else'CURRENT9117_OBSERVATION_FUTURE_BASE_UNKNOWN_NOT_APPLICABLE',
  at=datetime.datetime.now(datetime.timezone.utc).isoformat(),observed_state=before,final_base_known=final_base_known,
  future_performance_1456_merge_fold_base='UNKNOWN—fresh immutable entrywise rebind is required'if not final_base_known else expected_head,
  operations=ops,dependencies=deps,protected_jaunts_and_sources=protected,native_four_current_preimages=native_paths,native_registry_guards=native_registry_guards,
  native_expected=native_expected,accepted_record_sha256=pf(record),accepted_camera_sha256=template['camera']['sha256'],
  accepted_match_differences=match['differences'],source_catalogue=dict(path=str(source),sha256=pf(source)),
  old_actual_native_recipe=parity['old_native_recipe'],current_computed_recipe=parity['current_computed_recipe'],
  native_recipe_doc=parity['current_recipe_doc'],no_typed_recipe_or_registry_postimage=True,
  future_ordinary_selected_owner_required=True,no_raw_model_duplicates=True,source_operations=8,native_owner_output_paths=4,
  original_claim='School renewed through13:31UTC per coordinator; fresh official owner check/renewal by root publisher required at application',
  source_rights_identity_date_limits_preserved=True,original_ticket_DONE=False)
 out.mkdir();(out/'ADOPTION-PLAN.json').write_bytes(enc(plan));(out/'PURE-PARITY.json').write_bytes(enc(parity));return plan
if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',required=True,type=Path);ap.add_argument('--expected-head',required=True);ap.add_argument('--final-base-known',action='store_true');a=ap.parse_args();d=prepare(a.output,a.expected_head,a.final_base_known)
 print(json.dumps(dict(status=d['status'],head=d['observed_state']['head'],dependencies=len(d['dependencies']),source_operations=8,native_owner_outputs=4,current_recipe=d['current_computed_recipe'],future_base_known=d['final_base_known'],primary_writes=False),indent=2))
