"""Validate only by default. Eight source/review paths; no GLB/registry transplant, owners or Git writes."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,tempfile
from refresh import R,A,P,SID,KEY,bound,materialize,state,git,enc,sha,pf

ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--plan',type=Path,required=True);ap.add_argument('--expected-head',required=True);ap.add_argument('--apply-sources',action='store_true');ap.add_argument('--claim-receipt',type=Path);a=ap.parse_args()
os.sched_setaffinity(0,{2});assert a.plan.resolve().is_relative_to(P);d=json.loads(a.plan.read_bytes());before=state();assert before['head']==a.expected_head==d['observed_state']['head']
assert d['no_typed_recipe_or_registry_postimage']and d['future_ordinary_selected_owner_required']and len(d['operations'])==8
for path,row in d['dependencies'].items():assert bound(path)==row,('Changed dependency; fresh entrywise rebind required',path)
for path,row in d['native_four_current_preimages'].items():assert bound(R/path)==row,('Native baseline changed; rebind',path)
prepared=[]
for op in d['operations']:
 dest=R/op['path'];assert str(dest).startswith(str(R)+'/chicago/')and'..'not in Path(op['path']).parts
 assert '/assets/'not in op['path'],'Source controller cannot write model or registry authority'
 for ancestor in [dest,*dest.parents]:
  if ancestor==R.parent:break
  assert not ancestor.is_symlink(),str(ancestor)
 assert bound(dest)==op['before'],('Stale source entry; reprepare',op['path']);raw=materialize(op)
 assert len(raw)==op['after']['bytes']and sha(raw)==op['after']['sha256'];prepared.append((dest,raw,op))
import sys
sys.path.insert(0,str(A/'generators'));import mesh_inputs
record=json.loads(next(raw for dest,raw,op in prepared if dest.name==SID+'.json'))
assert json.dumps(mesh_inputs.structure_inputs_doc(record,record['phases'][0]),sort_keys=True)==json.dumps(d['native_recipe_doc'],sort_keys=True)
assert mesh_inputs.structure_inputs_sha(record,record['phases'][0])==d['current_computed_recipe']
assert state()==before
if a.apply_sources:
 assert d['final_base_known']is True,'Observed9117 is not the unknown post-performance/1456/fold adoption base'
 assert before['branch'].startswith('steward/t2372-')and not before['active_merge']
 assert not git('status','--porcelain=v1','--untracked-files=all')
 assert os.environ.get('SCHOOL_ADOPTION_LEASE')=='original-T2372-claimed-primary-released'
 assert a.claim_receipt and a.claim_receipt.is_file(),'Supply root publisher’s current immutable original-School native claim receipt'
 claim=json.loads(a.claim_receipt.read_bytes());assert 'T-2372' in claim['path']and claim.get('force_push')is False
 assert 'IMMUTABLE_READBACK_PASS'in claim['status']
 expiry=datetime.datetime.fromisoformat(claim['expires_utc'].replace('Z','+00:00'));assert datetime.datetime.now(datetime.timezone.utc)<expiry
 needed=sum(((len(raw)+4095)//4096)*4096 for _,raw,_ in prepared)
 assert shutil.disk_usage('/workspace').free>=536870912+needed+4*1024**2 and shutil.disk_usage('/tmp').free>=1800000000
 journal=P/('SOURCE-ADOPTION-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')+'.jsonl')
 with journal.open('x')as log:
  def note(v):log.write(json.dumps(v)+'\n');log.flush();os.fsync(log.fileno())
  note(dict(status='EIGHT_SOURCE_PATHS_STARTED_NATIVE_REFRESH_PENDING',head=before['head'],plan_sha256=pf(a.plan),claim_receipt_sha256=pf(a.claim_receipt)))
  for dest,raw,op in prepared:
   assert bound(dest)==op['before'];dest.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix='.school-source-',dir=dest.parent)
   try:
    with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
    os.chmod(tmp,int(op['after']['mode'],8));os.replace(tmp,dest)
   finally:
    if os.path.exists(tmp):os.unlink(tmp)
   assert bound(dest)==op['after'];note(dict(path=op['path'],sha256=op['after']['sha256']))
  # No metadata, model or registry writes are hidden in source application.
  after=state();assert all(after[k]==before[k]for k in ['head','tree','branch','index','config','refs','active_merge'])
  for path,row in d['native_four_current_preimages'].items():assert bound(R/path)==row
  note(dict(status='EIGHT_SOURCE_PATHS_APPLIED_ORDINARY_SELECTED_NATIVE_OWNER_REQUIRED',new_recipe=d['current_computed_recipe']))
 print(json.dumps(dict(status='EIGHT_SOURCES_APPLIED_NATIVE_REFRESH_AND_ALL_APP_POLICY_ACCEPTANCE_PENDING',journal=str(journal)),indent=2))
else:print(json.dumps(dict(status='READONLY_EIGHT_ENTRYWISE_SOURCE_OPERATIONS_AND_CURRENT279_DEPENDENCIES_PASS',head=before['head'],observed_future_base_unknown=not d['final_base_known'],current_recipe=d['current_computed_recipe'],primary_writes=False),indent=2))
