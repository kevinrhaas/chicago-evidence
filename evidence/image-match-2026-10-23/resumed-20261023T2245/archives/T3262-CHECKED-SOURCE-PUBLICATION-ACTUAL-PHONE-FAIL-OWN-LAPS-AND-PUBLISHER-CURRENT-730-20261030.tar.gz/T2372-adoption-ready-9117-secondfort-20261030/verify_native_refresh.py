"""Read-only check of a FUTURE actual ordinary selected School build/WEB; never makes registry rows."""
from pathlib import Path
import argparse,json,os,sys
from refresh import A,R,P,SID,KEY,pf,sha

ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--plan',type=Path,required=True);ap.add_argument('--build-reaper',type=Path,required=True);ap.add_argument('--web-reaper',type=Path,required=True);ap.add_argument('--wrote',type=Path,required=True);a=ap.parse_args();os.sched_setaffinity(0,{2});d=json.loads(a.plan.read_bytes());assert d['final_base_known']is True
for file in[a.build_reaper,a.web_reaper]:
 r=json.loads(file.read_bytes());assert r['command_exit']==0 and r['all_children_reaped']is True
assert a.wrote.read_text().splitlines()==[KEY]
sys.path.insert(0,str(A/'generators'));import mesh_inputs
record=json.loads((A/'data/structures'/f'{SID}.json').read_bytes());assert pf(A/'data/structures'/f'{SID}.json')==d['accepted_record_sha256']
assert json.dumps(mesh_inputs.structure_inputs_doc(record,record['phases'][0]),sort_keys=True)==json.dumps(d['native_recipe_doc'],sort_keys=True)
assert mesh_inputs.structure_inputs_sha(record,record['phases'][0])==d['current_computed_recipe']
assert pf(A/'assets/gltf'/KEY)==d['native_expected']['MASTER']and pf(A/'assets/web'/KEY)==d['native_expected']['WEB']
canon=lambda v:json.dumps(v,sort_keys=True,separators=(',',':')).encode()
for registry,g in d['native_registry_guards'].items():
 m=json.loads((A/'assets'/registry).read_bytes());t=g['table'];assert len(m[t])==g['rows']
 assert sha(canon([(k,v)for k,v in m[t].items()if k!=KEY]))==g['foreign_ordered_rows_sha256']
 assert sha(canon({k:v for k,v in m.items()if k!=t}))==g['outer_metadata_sha256']
 if t=='assets':assert m[t][KEY]['inputs_sha256']==d['current_computed_recipe']and m[t][KEY]['structure_id']==SID
 else:assert m[t][KEY]==d['native_expected']['MASTER']
print(json.dumps(dict(status='ACTUAL_FUTURE_SELECTED_NATIVE_SCHOOL_RECIPE_AND_BYTES_VERIFIED_READONLY',recipe=d['current_computed_recipe'],native_master=d['native_expected']['MASTER'],native_web=d['native_expected']['WEB'],foreign_registry_rows_order_metadata_exact=True,owners_and_app_policy_acceptance_still_pending=True),indent=2))
