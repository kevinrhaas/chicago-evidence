"""Pure school geometry/parameter parity. No Blender, export, native owner or browser."""
from pathlib import Path
import copy,dataclasses,hashlib,importlib.util,json,os,subprocess,sys,types

P=Path(__file__).resolve().parent;R=Path('/workspace/chicago');A=R/'chicago/4d'
N=Path('/workspace/T2372-native-selected-bake-reuse-20261030')
OLD=Path('/workspace/T2382-native-selected-bake-prep-20261030/closed-authority/native-producer/generators')
sha=lambda b:hashlib.sha256(b).hexdigest()
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
def audit():
 os.sched_setaffinity(0,{2});sys.path.insert(0,str(A/'generators'))
 # Only the Python accumulator is used. bpy is an inert import placeholder;
 # to_object is replaced by a collector before any producer call.
 assert 'bpy'not in sys.modules;sys.modules['bpy']=types.ModuleType('bpy')
 from common import mesh
 mesh.simple_material=lambda name,rgba=(.8,.8,.8,1),roughness=.75:dict(name=name,rgba=list(rgba),roughness=roughness)
 mesh.MeshBuilder.to_object=lambda self,materials=None:dict(verts=self.verts,faces=self.faces,confidence=self.conf,
   material_indices=self.mat_index,named_materials=self.named,materials=materials)
 native=json.loads((N/'closed-authority/NATIVE-ENTRIES.json').read_bytes())
 record=json.loads((N/'closed-authority/candidate/chappel_infant_school.json').read_bytes())
 assert sha((OLD/'archetypes/log_dwelling.py').read_bytes())==native['recipe_doc']['code']['archetypes/log_dwelling.py']
 native_plan=json.loads((N/'PLAN.json').read_bytes());old_bind={row['source']:row for row in native_plan['native_producer_bindings']}
 assert sha((OLD/'archetypes/log_dwelling_params.py').read_bytes())==old_bind[str(A/'generators/archetypes/log_dwelling_params.py')]['sha256']
 captures={};params={}
 for label,base in [('native_donor',OLD),('canonical_current',A/'generators')]:
  pm=module('archetypes.log_dwelling_params',base/'archetypes/log_dwelling_params.py')
  am=module('school_'+label+'_producer',base/'archetypes/log_dwelling.py')
  resolved=pm.from_phase(record['phases'][0],record);params[label]=dataclasses.asdict(resolved)
  captures[label]=am.build(resolved,'chappel_infant_school__log_1833')
 # These are the actual unexported mesh-builder arrays and material specs,
 # not a recording of a repeated implementation or a fake native GLB.
 assert captures['native_donor']==captures['canonical_current']
 out=captures['canonical_current'];enc=lambda v:json.dumps(v,sort_keys=True,separators=(',',':')).encode()
 before=params['native_donor'];after=params['canonical_current'];removed={k:before[k]for k in before.keys()-after.keys()}
 assert all(v is None for k,v in removed.items()),removed
 assert all(before[k]==after[k]for k in before.keys()&after.keys())
 import mesh_inputs
 doc=mesh_inputs.structure_inputs_doc(record,record['phases'][0]);recipe=mesh_inputs.structure_inputs_sha(record,record['phases'][0])
 changed=[]
 for row in native_plan['native_producer_bindings']:
  current=Path(row['source']);h=sha(current.read_bytes())
  if h!=row['sha256']:
   rel=str(current.relative_to(A/'generators'))
   changed.append(dict(module=rel,native_donor_sha256=row['sha256'],current_sha256=h,
     semantic_scope='School selected producer: pure full mesh/material/confidence accumulator exact; removed optional fields allNone, no frame addition/end courses/ridge cap selected.'if rel.startswith('archetypes/log_dwelling')else
       'Recipe helper mapping extends K01-specific helpers; school params/actual generator selection independent. Current resolved recipe is computed, never substituted.'if rel=='mesh_inputs.py'else
       'Outside selected log_dwelling geometry closure; emit.py is unchanged and dispatches actual school archetype. No blanket default parity for these other families is claimed.'))
 current_code=doc['code'];assert set(current_code)==set(native['recipe_doc']['code'])
 assert [k for k in current_code if current_code[k]!=native['recipe_doc']['code'][k]]==['archetypes/log_dwelling.py']
 # A fresh native registry row is still needed: mesh parity is not a
 # licence to relabel the old2fe official owner's recipe hash.
 return dict(status='ACTUAL_PURE_SCHOOL_DEFAULT_MESH_MATERIAL_CONFIDENCE_PARITY_PASS_NOT_NATIVE_REBAKE',
   selected_record_sha256=sha((N/'closed-authority/candidate/chappel_infant_school.json').read_bytes()),
   old_native_recipe=native['recipe_sha256'],current_computed_recipe=recipe,current_recipe_doc=doc,
   full_accumulator_sha256=sha(enc(out)),vertices=len(out['verts']),faces=len(out['faces']),
   arrays_materials_confidence_exact=True,shared_resolved_parameter_fields_exact=True,
   removed_inactive_none_fields=sorted(removed),school_frame_addition=False,
   changed_producer_bindings=changed,geometry_code_keys=sorted(current_code),
   K01_K08_K11_not_in_selected_geometry_closure=True,
   changed_recipe_does_not_license_typed_manifest_substitution=True,
   future_official_selected_owner_refresh_required=recipe!=native['recipe_sha256'],
   no_Blender_export_native_owner_browser_or_source_write=True)
if __name__=='__main__':print(json.dumps(audit(),indent=2))
