from pathlib import Path
import argparse,datetime,hashlib,json,os,re,subprocess
R=Path('/workspace/chicago');X=Path('/workspace/PR1456-standalone-phone-memory-extraction-20261030');O=Path(__file__).parent
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');sha=lambda b:hashlib.sha256(b).hexdigest()
g=lambda *a:subprocess.check_output(['git','-C',str(R),*a],env=E)
p=argparse.ArgumentParser();p.add_argument('--ticket',required=True);p.add_argument('--base',required=True);p.add_argument('--claim-proof',required=True);a=p.parse_args()
assert re.fullmatch('T-[0-9]{4,5}',a.ticket) and re.fullmatch('[0-9a-f]{40}',a.base)
proof=Path(a.claim_proof);assert proof.exists() and a.ticket.encode() in proof.read_bytes()
assert g('rev-parse','HEAD').decode().strip()=='3746b23bf1298c34a29946b4cdb6ee2d98abff8f' and not g('status','--porcelain=v1')
assert g('rev-parse','origin/dev').decode().strip()==a.base
plan=json.loads((X/'PLAN.json').read_bytes());config=sha((R/'.git/config').read_bytes());refs=dict(z.split(' ',1)for z in g('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines())
for row in plan['paths']:assert sha(g('show',a.base+':'+row['path']))==row['039_preimage_sha256']
branch='steward/'+a.ticket.lower().replace('-','')+'-phone-renderer-memory'
assert 'refs/heads/'+branch not in refs
changed=g('diff','--name-only','HEAD',a.base).decode().splitlines()
g('switch','-c',branch,a.base)
# Native checkout must leave every physically resident changed tracked path exact.
for rel in changed:
 path=R/rel
 if path.exists() and not path.is_symlink():
  exists=subprocess.run(['git','-C',str(R),'cat-file','-e',a.base+':'+rel],env=E,capture_output=True).returncode==0
  if exists:assert path.read_bytes()==g('show',a.base+':'+rel),rel
for row in plan['paths']:
 rel=row['path'];assert sha((R/rel).read_bytes())==row['039_preimage_sha256'];value=(X/'postimages'/rel).read_bytes();assert sha(value)==row['checked3746_postimage_sha256'];(R/rel).write_bytes(value)
for name in ['STATUS','ROADMAP']:
 rel='chicago/4d/docs/'+name+'.md';before=(R/rel).read_bytes();assert before==g('show',a.base+':'+rel)
 prefix=(O/(name+'-PREFIX-TEMPLATE.txt')).read_bytes().replace(b'TICKET',a.ticket.encode());assert len(prefix)<=4096
 (R/rel).write_bytes(prefix+before)
entry=json.loads((X/'changelog-entry.PROPOSED.json').read_bytes());entry['items']=['Nothing you can see changes. The railway yard uses less phone memory while retaining its tracks, ground, materials and evidence grades.']
changelog='chicago/4d/changelog.d/'+a.ticket+'.json';assert not(R/changelog).exists();(R/changelog).write_text(json.dumps(entry,indent=2)+'\n')
paths=[x['path']for x in plan['paths']]+['chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md',changelog]
assert set(g('diff','--name-only').decode().splitlines())==set(paths)-{changelog} and g('ls-files','--others','--exclude-standard').decode().splitlines()==[changelog]
g('add','--',*paths)
assert not g('diff','--name-only') and not g('ls-files','--others','--exclude-standard') and not g('ls-files','-u')
assert set(g('diff','--cached','--name-only').decode().splitlines())==set(paths)
assert sha((R/'.git/config').read_bytes())==config
assert dict(z.split(' ',1)for z in g('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines())=={**refs,'refs/heads/'+branch:a.base}
out={'status':'ACTUAL_NATIVE_STANDALONE_PERFORMANCE_BRANCH_AND_EXACT_SEVEN_STAGED_PATHS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':a.base,'branch':branch,'ticket':a.ticket,'tree':g('write-tree').decode().strip(),'paths':{rel:sha((R/rel).read_bytes())for rel in paths},'claim_proof':str(proof),'claim_proof_sha256':sha(proof.read_bytes()),'source_config_unchanged':True,'all_foreign_refs_unchanged':True,'ordinary_checkout_every_resident_changed_path_checked':True,'no_models_records_generated_metadata_changes_in_diff':True}
(O/'APPLIED.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
