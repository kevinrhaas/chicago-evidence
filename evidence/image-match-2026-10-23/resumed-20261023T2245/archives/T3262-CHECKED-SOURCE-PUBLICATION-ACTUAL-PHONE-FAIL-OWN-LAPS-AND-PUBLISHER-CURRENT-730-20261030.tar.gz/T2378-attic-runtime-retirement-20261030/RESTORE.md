Only `/workspace/T2378-native-attic-light-run-20261030/runtime` was retired.
The previous two-runtime receipt remains unchanged at
`/workspace/T2378-owned-runtime-retirement-20261030/RETIRED.json`.

Checkpoint726 was independently fetched again in RAM. Its two ordered immutable
GitHub transport parts passed byte count/SHA-256/Git-blob checks, the reassembled
archive passed SHA-256, and183 own actual/proposal/review members passed payload
SHA/size/mode. The complete attic actual source/input/output closure is durable,
not merely metadata. `PREFLIGHT.json` contains the archive URLs/part hashes,
every retired ordinary member and exact symlink reconstruction targets.

The142 ordinary runtime files and1048 symlinks matched the original RESTORE map
exactly. Reapers were closed, live cwd/argv/FD/maps checks were empty, ordinary
files had no extra hardlinks, and no special/unlisted files existed. Symlink-safe
removal recovered10,772,480 allocated bytes, equal to the observed free-space
increase555,384,832→566,157,312B. All79 nonruntime authority/raw/recipe/ROOTreview/
metadata files remained exact, as did all1048 linked targets and the three
private browser/TMP/XDG cache roots. Primary source/Git and Blender were untouched.

This funds the original phone threshold562,036,736B. It does **not** fund the new
568,291,328B import threshold: the gap is about2.2MB, depending on concurrent
ledger allocations. All three authorized Beaubien runtime directories are now
retired. No further cleanup of protected captures, authority/public metadata,
private profiles, shared files or another agent's work is assumed.

For restoration in a separate root phase, verify/reassemble the listed immutable
checkpoint726 archive and write ONLY the142 enumerated attic runtime ordinary
members to their original paths, with exact mode/size/SHA. Recreate only the1048
listed symlinks and validate their existing canonical targets; never follow them
for copying or deletion. Do not extract the whole archive, change primary refs,
or substitute current source bytes for archived9d97 native inputs.

All independent `closed-authority/` files and unchanged author manifests remain
available. A future adoption controller which insists every168 original member
is physically present must first restore the142 runtime inputs from the bank,
or use a newly reviewed bank-aware proof controller. Do not weaken or edit the
frozen54-file adoption preparation to skip its evidence checks. Future geometry
or browser work still needs its own actual source/resource/CPU qualification.
