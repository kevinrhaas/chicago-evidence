"""Retire only two explicitly authorized, durably banked, inactive native runtimes.

Default verifies immutable GitHub archives in RAM and writes an external preflight.
--retire also repeats ownership/payload/live-FD checks and removes only the two
allowlisted runtime directories. Source, authorities, raw records and caches stay.
"""
import argparse,datetime,gc,hashlib,io,json,os,pathlib,shutil,stat,tarfile,urllib.request
P=pathlib.Path(__file__).resolve().parent;W=pathlib.Path('/workspace')
NAMES=['T2378-native-attic-light-run-20261030']
KEEP='T2378-native-main-prototype-run-20261030'
BANKS=['next-a0fe-and-original-closures-checkpoint-publisher-20261030']
PREFIXES=NAMES+['T2378-attic-light-readiness-20261030','T2378-attic-root-review-20261030']
os.sched_setaffinity(0,{2});os.nice(19)
SHA=lambda b:hashlib.sha256(b).hexdigest();PF=lambda p:SHA(pathlib.Path(p).read_bytes())
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--retire',action='store_true');args=ap.parse_args()
def save(n,d):(P/n).write_text(json.dumps(d,indent=2)+'\n')
def ident(p,follow=True):
 s=p.stat()if follow else p.lstat()
 return {'dev':s.st_dev,'ino':s.st_ino,'mode':stat.S_IMODE(s.st_mode),'bytes':s.st_size,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns}
def runtime_scan(name):
 root=W/name;F=root/'runtime';assert not root.is_symlink()and not F.is_symlink()and F.is_dir()
 restore=json.loads((root/'RESTORE.json').read_text());assert restore['root']==str(root)and restore['runtime']==str(F)
 result=json.loads((root/'RESULT.json').read_text());assert result['all_children_reaped']and result['primary_source_Git_all_guards_exact']
 assert result['all_primary_asset_bytes_exact_count']==2073
 for stage in ['VERSION','BUILD','WEB','PHOTO']:
  r=json.loads((root/(stage+'-REAPER.json')).read_text());assert r['all_children_reaped']and r['command_exit']==0
 expected={r['path']:r for r in restore['ordinary_native_payloads']}
 declared_links=restore.get('guarded_links',restore.get('guarded_links_reconstruct_exact_targets'))
 expected_links={r['path']:r.get('target',r.get('source'))for r in declared_links}
 actual={};links={};dirs=[];allocated=0
 for q in [F,*F.rglob('*')]:
  s=q.lstat();allocated+=s.st_blocks*512;rel=str(q.relative_to(root))
  if stat.S_ISDIR(s.st_mode):dirs.append(rel)
  elif stat.S_ISLNK(s.st_mode):links[rel]=os.readlink(q)
  else:
   assert stat.S_ISREG(s.st_mode)and s.st_nlink==1,('Unknown/special/shared hardlink',str(q))
   actual[rel]={'path':str(q),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'sha256':PF(q),'inode':ident(q)}
 assert set(actual)==set(expected),('Unlisted ordinary input payload',name,set(actual)^set(expected))
 for rel,r in actual.items():
  e=expected[rel];assert r['bytes']==e['bytes']and r['sha256']==e['sha256']and r['mode']==int(e['mode'],8),rel
 assert links==expected_links,('Runtime symlink set/target drift',name)
 assert len(actual)==142 and len(links)==1048
 return {'root':str(root),'runtime':str(F),'runtime_inode':ident(F),'ordinary':actual,'links':links,'dirs':dirs,'allocated_B':allocated,'markers':{f:PF(root/f)for f in ['run.py','PLAN.json','RESULT.json','RESTORE.json','CLOSED-MANIFEST.json']},'all_children_reaped':True}
def active_paths():
 needles=[str(W/n/'runtime')for n in NAMES];found=[];inaccessible=[];scanned=0
 for proc in pathlib.Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  scanned+=1;pid=int(proc.name)
  for kind in ['cwd','exe','root']:
   try:target=os.readlink(proc/kind)
   except(OSError,PermissionError):continue
   if any(target==n or target.startswith(n+'/')for n in needles):found.append({'pid':pid,'kind':kind,'target':target})
  try:
   cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
   if any(n in cmd for n in needles):found.append({'pid':pid,'kind':'owned-runtime argv reference'})
  except(OSError,PermissionError):pass
  try:fds=list((proc/'fd').iterdir())
  except(OSError,PermissionError):inaccessible.append(pid);continue
  for fd in fds:
   try:target=os.readlink(fd)
   except(OSError,PermissionError):continue
   if any(target==n or target.startswith(n+'/')for n in needles):found.append({'pid':pid,'kind':'open fd','target':target})
  try:
   for line in(proc/'maps').read_text(errors='replace').splitlines():
    if any(n in line for n in needles):found.append({'pid':pid,'kind':'mapped owned-runtime path'})
  except(OSError,PermissionError):pass
 return {'scanned_visible_processes':scanned,'owned_runtime_references':found,'inaccessible_unrelated_fd_sets':inaccessible,'scope':'Only explicit owned runtime path references block. Unrelated daemon access limits are recorded, not universal blockers.'}
def protected():
 out={}
 for name in ['T2378-native-main-prototype-run-20261030','T2378-native-low-projection-run-20261030','T2378-native-attic-light-run-20261030']:
  root=W/name
  for p in root.rglob('*'):
   if name in NAMES and p.is_relative_to(root/'runtime'):continue
   if p.is_file()and not p.is_symlink():out[str(p)]={'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':PF(p)}
 return out
def verify_banks():
 covered={};records=[]
 for name in BANKS:
  B=W/name;pub=json.loads((B/'PUBLICATION.json').read_text());done=json.loads((B/'COMPLETE.json').read_text());assert done['status']=='PASS'
  m=json.loads((B/'MANIFEST.json').read_text());expected={r['relative_path']:r for r in m['files']if any(r['relative_path'].startswith(n+'/')for n in PREFIXES)}
  refs=[r for r in pub['readback']if r['path'].endswith('.tar.gz')or'.tar.gz.part-'in r['path']];refs.sort(key=lambda r:r['path'])
  record=pub['new_archive_records'][0];buffer=io.BytesIO();transport=[]
  for r in refs:
   url=r['immutable_raw_url'];assert pub['commit']in url
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Chicago4D owned-runtime bank verification'}),timeout=30)as response:
    assert response.status==200;raw=response.read(r['bytes']+1)
   assert len(raw)==r['bytes']and SHA(raw)==r['sha256']
   assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==r['git_blob']
   buffer.write(raw);transport.append({'url':url,'bytes':len(raw),'sha256':r['sha256'],'git_blob':r['git_blob']});del raw
  assert buffer.tell()==record['bytes']and SHA(buffer.getbuffer())==record['sha256']
  buffer.seek(0);got={}
  with tarfile.open(fileobj=buffer,mode='r|gz')as archive:
   for member in archive:
    if member.name not in expected:continue
    e=expected[member.name];assert member.isfile()and member.size==e['bytes']and member.mode==e['mode']
    stream=archive.extractfile(member);h=hashlib.sha256();size=0
    while True:
     chunk=stream.read(65536)
     if not chunk:break
     h.update(chunk);size+=len(chunk)
    assert size==e['bytes']and h.hexdigest()==e['sha256'],member.name
    row={'bytes':size,'mode':member.mode,'sha256':h.hexdigest(),'archive_member':member.name,'checkpoint':pub['archives_count'],'commit':pub['commit'],'archive_sha256':record['sha256']};got[member.name]=row;covered[member.name]=row
  assert set(got)==set(expected),('Missing durable archive payload',name,set(expected)-set(got))
  records.append({'checkpoint':pub['archives_count'],'commit':pub['commit'],'availability_commit':done['availability_commit'],'index':done['index'],'archive_sha256':record['sha256'],'archive_B':record['bytes'],'transport':transport,'owned_payload_members_verified':len(got)})
  buffer.close();gc.collect();print(json.dumps({'bank':pub['archives_count'],'owned_payload_members_verified':len(got),'immutable_archive_hash_and_member_bytes_modes':'PASS'}),flush=True)
 return covered,records
scans=[runtime_scan(n)for n in NAMES];live=active_paths();assert not live['owned_runtime_references'],live
target_meta={}
for scan in scans:
 for rel,t in scan['links'].items():
  link=pathlib.Path(scan['root'])/rel;target=(link.parent/t).resolve();assert target.is_file()and not any(target.is_relative_to(W/n/'runtime')for n in NAMES)
  target_meta[str(target)]=ident(target)
profile_meta={str(p):ident(p)for p in [W/'b2378p30',W/'b2378l30',W/'b2378a30']if p.exists()}
preserved=protected();covered,banks=verify_banks()
for scan in scans:
 for rel,r in scan['ordinary'].items():
  key=pathlib.Path(scan['root']).name+'/'+rel;assert key in covered
  assert all(covered[key][k]==r[k]for k in ['bytes','mode','sha256']),key
 for marker in ['RESTORE.json','CLOSED-MANIFEST.json']:
  key=pathlib.Path(scan['root']).name+'/'+marker;assert key in covered and covered[key]['sha256']==PF(pathlib.Path(scan['root'])/marker)
expected_bytes=sum(s['allocated_B']for s in scans);assert expected_bytes>=10*1024**2
plan={'status':'OWNED_ONE_ATTIC_RUNTIME_PREFLIGHT_DURABLE_PAYLOAD_AND_REAPERS_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'targets':scans,'durable_banks':banks,'archived_ordinary_restore_members':covered,'live_reference_scan':live,'protected_nonretired_files':preserved,'symlink_targets_metadata':target_meta,'private_profile_cache_roots_preserved':profile_meta,'expected_exclusive_allocated_reclaim_B':expected_bytes,'prior_two_retirement_receipt':'/workspace/T2378-owned-runtime-retirement-20261030/RETIRED.json','shared_primary_source_or_Git_operations':False,'retire_requested':args.retire}
save('PREFLIGHT.json',plan)
if not args.retire:print(json.dumps({'status':plan['status'],'expected_allocated_reclaim_B':expected_bytes,'ordinary_targets':sum(len(s['ordinary'])for s in scans),'symlinks_to_unlink_only':sum(len(s['links'])for s in scans),'unique_symlink_targets_to_preserve':len(target_meta)},indent=2));raise SystemExit(0)
assert not(P/'RETIRED.json').exists();assert shutil.rmtree.avoids_symlink_attacks
# Repeat CURRENT owned markers/payloads and FD scan immediately before unlinking.
again=[runtime_scan(n)for n in NAMES];assert again==scans
live=active_paths();assert not live['owned_runtime_references'],live
for p,m in target_meta.items():assert ident(pathlib.Path(p))==m
before={m:shutil.disk_usage(m).free for m in ['/workspace','/tmp']};removed=[]
for scan in scans:
 F=pathlib.Path(scan['runtime']);assert F in{W/n/'runtime'for n in NAMES}and ident(F)==scan['runtime_inode']
 shutil.rmtree(F);assert not F.exists();removed.append(str(F))
for p,m in target_meta.items():assert pathlib.Path(p).exists()and ident(pathlib.Path(p))==m,('Linked target changed',p)
for p,m in preserved.items():assert pathlib.Path(p).exists()and all(v==({'bytes':pathlib.Path(p).stat().st_size,'mode':stat.S_IMODE(pathlib.Path(p).stat().st_mode),'sha256':PF(pathlib.Path(p))})[k]for k,v in m.items()),p
for p,m in profile_meta.items():assert ident(pathlib.Path(p))==m,('Private profile/cache root changed',p)
after={m:shutil.disk_usage(m).free for m in before};delta=after['/workspace']-before['/workspace']
result={'status':'ONE_AUTHORIZED_OWNED_INACTIVE_ATTIC_RUNTIME_RETIRED_DURABLE_EXACT_RESTORE_PROOF_PRESERVED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'removed':removed,'exclusive_allocated_blocks_reclaimed_B':expected_bytes,'workspace_free_before_B':before['/workspace'],'workspace_free_after_B':after['/workspace'],'actual_observed_workspace_free_delta_B':delta,'shared_TMP_before_B':before['/tmp'],'shared_TMP_after_B':after['/tmp'],'all_1048_unique_symlink_targets_exist_identical_metadata':True,'all_nonruntime_authorities_raw_ROOTreview_metadata_preserved_count':len(preserved),'private_browser_TMP_XDG_profile_roots_untouched':list(profile_meta),'attic_unique_authority_retained':str(W/NAMES[0]/'closed-authority'),'ordinary_restore_manifest':'PREFLIGHT.json targets[].ordinary + archived_ordinary_restore_members + durable_banks/immutable URLs; use existing unchanged RESTORE maps','root_ledger_checkpoint':'next after728','primary_source_Git_index_refs_tickets_or_Blender_writes':False,'new_native_jobs':False}
save('RETIRED.json',result);print(json.dumps(result,indent=2))
