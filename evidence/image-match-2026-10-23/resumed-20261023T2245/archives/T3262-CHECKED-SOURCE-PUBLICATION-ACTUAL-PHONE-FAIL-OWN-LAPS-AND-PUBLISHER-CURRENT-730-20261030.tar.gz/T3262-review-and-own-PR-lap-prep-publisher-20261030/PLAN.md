Prepared only. No ticket state or lap change has run.

Prerequisites: Root supplies actual open PR number, current exact checked source SHA/tree and closed fresh standalone gate/phone/smoke receipts. GitHub API must confirm that PR is kevinrhaas/chicago, base dev, head steward/t3262-phone-renderer-memory at that actual SHA, title/body carry T-3262 and no foreign owner/lap.

Use unchanged native ticket.mjs SHA34c9f9db3cd6f1091ef075ad1bf77874a9e3f064e9e3ea4e633dc6d5569c5e90 in the existing isolated app context. CHICAGO_TICKETS_DIR must point at full /workspace/chicago-tickets, refreshed clean main through normal pull. Do not use the sparse3-ticket clone for new/done.

Before done, give the isolated native tool a complete READ-ONLY view of current primary data/docs and the actual ticket_liveness.py (copy exact native tool bytes into isolated tools; tickets read via CHICAGO_TICKETS_DIR). T-3262 has no parent. Confirm native image/tripwire/ancestor guards truly ran; no missing-directory pass and no --anyway override. No mirror directory exists in the isolated app, so native board regeneration cannot write primary site.

Run only after actual PR exists:
  node tools/ticket.mjs done T-3262 --pr ACTUAL_PR

The official repo-mode command writes REVIEW, never DONE, keeps the queue line/claim and records actual PR; settle marks DONE after actual merge. Guard old claimed_at/owner/body and PRnull against immutable claim0f81bcfc (or subsequent verified same-owner ticket main). Only state claimed→review and pr null→actualPR may change; all foreign paths/modes and queue order stay exact. Native normal-FF ticket main push; no force or original-ticket mutations.

Acquire a separate own lap with native command:
  node tools/ticket.mjs lap ACTUAL_PR --by 'Codex T-3262 phone renderer memory support 2026-10-30'

Precheck native --status plus actual ls-remote. Take only absent lap/pr-ACTUAL_PR with native parentless EMPTYtree nonce commit and exact absent-ref --force-with-lease metadata CAS. No --force steal, no release gap, no code ref push. Require actual marker SHA readback and all other advertised remote refs unchanged, honestly classify concurrent independent changes. An existing foreign/live or unknown marker stops acquisition. PR1456/de4e is unrelated and must not change.

All Git CLI calls are scoped to isolated app or full tickets clone. Primary source/HEAD/index/config/localrefs remain untouched. Command-scoped NODE_DISABLE_COMPILE_CACHE=1/PYTHONDONTWRITEBYTECODE=1, workspace TMPDIR, CPU2; unchanged caller floors and 8MiB metadata reserve. Execute serially with fresh guards and preserve exact command logs/remote proof; do not infer ownership from command exit0 if native says unknown.
