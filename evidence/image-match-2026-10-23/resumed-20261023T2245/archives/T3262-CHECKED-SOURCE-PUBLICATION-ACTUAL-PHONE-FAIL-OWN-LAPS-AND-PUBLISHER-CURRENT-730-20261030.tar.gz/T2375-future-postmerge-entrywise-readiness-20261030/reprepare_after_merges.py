"""Prepare Bridge only after actual performance+picture dev merges and their final fold.
No application, native export, renderer, ticket or Git/ref write is performed.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,stat,subprocess,sys
sys.dont_write_bytecode=True;os.sched_setaffinity(0,{2})
R=Path('/workspace/chicago');OLD=Path('/workspace/T2375-current-entrywise-adoption-prep-20261030');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');sha=lambda b:hashlib.sha256(b).hexdigest();g=lambda *a:subprocess.check_output(['git','-C',str(R),'-c','protocol.allow=never',*a],env=E)
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for k in ['expected-head','performance-merge','pictures-merge','final-fold']:ap.add_argument('--'+k,required=True)
 ap.add_argument('--output',required=True,type=Path);ap.add_argument('--prepare',action='store_true');args=ap.parse_args()
 vals=[args.expected_head,args.performance_merge,args.pictures_merge,args.final_fold];assert all(re.fullmatch('[0-9a-f]{40}',x)for x in vals)
 assert args.performance_merge!=args.pictures_merge,'Need actual separate normal dev squash SHAs, not old feature heads'
 assert g('rev-parse','HEAD').decode().strip()==args.expected_head and not(R/'.git/MERGE_HEAD').exists()and not g('status','--porcelain=v1')
 assert not args.output.exists()and R not in args.output.resolve().parents
 for old,new in [(args.performance_merge,args.final_fold),(args.pictures_merge,args.final_fold),(args.final_fold,args.expected_head)]:
  q=subprocess.run(['git','-C',str(R),'-c','protocol.allow=never','merge-base','--is-ancestor',old,new],env=E);assert q.returncode==0,('Actual postbothmerge/fold ancestry required',old,new)
 fold=g('show','-s','--format=%s',args.final_fold).decode().strip();assert fold.startswith('changelog: fold entry files'),'Use actual final native changelog-fold commit'
 raw=(OLD/'CLOSED-MANIFEST.json').read_bytes();assert sha(raw)=='c381cb09291a341779fd9542410655b946022bfa5012279839ad65f4058fe68d'
 for row in json.loads(raw)['files']:
  p=OLD/row['path'];assert p.is_file()and not p.is_symlink()and p.stat().st_size==row['bytes']and sha(p.read_bytes())==row['sha256']and stat.S_IMODE(p.stat().st_mode)==row['mode']
 print(json.dumps({'status':'ACTUAL_POSTBOTH_DEV_MERGES_AND_FINAL_FOLD_BINDING_VALIDATED_NO_APPLICATION','head':args.expected_head,'performance_merge':args.performance_merge,'pictures_merge':args.pictures_merge,'final_fold':args.final_fold,'old80_packet_exact':True,'prepare_requested':args.prepare}),flush=True)
 if args.prepare:
  # Existing reviewed preparer derives6complete input documents from current code,
  # checks actual nativeowner rows, and composes30postimages entrywise externally.
  # It refuses changed recipes or authored conflicts rather than replacing hashes.
  subprocess.run([sys.executable,str(OLD/'prepare.py'),'--output',str(args.output),'--expected-head',args.expected_head],env=E,check=True)
if __name__=='__main__':main()
