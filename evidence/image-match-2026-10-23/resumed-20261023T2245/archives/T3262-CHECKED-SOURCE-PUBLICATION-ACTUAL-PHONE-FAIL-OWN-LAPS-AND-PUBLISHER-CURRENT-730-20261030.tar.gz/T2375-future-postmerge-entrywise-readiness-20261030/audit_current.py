"""Read-only current-source bridge recipe/composition analysis; no native/test/app writes."""
from pathlib import Path
import argparse,ast,copy,datetime,hashlib,importlib.util,json,os,stat,subprocess,sys
sys.dont_write_bytecode=True;os.sched_setaffinity(0,{2})
O=Path(__file__).resolve().parent;R=Path('/workspace/chicago');A=R/'chicago/4d';OLD=Path('/workspace/T2375-current-entrywise-adoption-prep-20261030');N=Path('/workspace/T2375-native6-actual-closure-20261030');NP=Path('/workspace/T2375-native6-current35-prep-20261030/PLAN.json');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');sha=lambda b:hashlib.sha256(b).hexdigest();g=lambda *a:subprocess.check_output(['git','-C',str(R),'-c','protocol.allow=never',*a],env=E)
def state():return {'head':g('rev-parse','HEAD').decode().strip(),'index':sha((R/'.git/index').read_bytes()),'config':sha((R/'.git/config').read_bytes()),'refs':sha(g('for-each-ref','--format=%(refname) %(objectname)')),'status':g('status','--porcelain=v1').decode()}
def merge_ram(cur,base,own):
 fds=[]
 try:
  for b in [cur,base,own]:
   fd=os.memfd_create('bridge-readonly-merge',0);os.write(fd,b);os.lseek(fd,0,0);fds.append(fd)
  q=subprocess.run(['git','merge-file','-p',*('/proc/self/fd/'+str(fd)for fd in fds)],env=E,pass_fds=fds,capture_output=True);return q.returncode,q.stdout
 finally:
  for fd in fds:os.close(fd)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--expected-head',required=True);ap.add_argument('--output',required=True,type=Path);args=ap.parse_args();canon=args.expected_head;before=state();assert before['head']==canon
 applied_path=Path('/workspace/standalone-performance-root-preparation-20261030/APPLIED.json');applied=json.loads(applied_path.read_bytes());active={p:h for p,h in applied['paths'].items()};assert len(active)==7 and all(sha((R/p).read_bytes())==h for p,h in active.items())
 raw=(OLD/'CLOSED-MANIFEST.json').read_bytes();assert sha(raw)=='c381cb09291a341779fd9542410655b946022bfa5012279839ad65f4058fe68d';oldm=json.loads(raw)
 for r in oldm['files']:
  p=OLD/r['path'];assert p.is_file()and not p.is_symlink()and p.stat().st_size==r['bytes']and sha(p.read_bytes())==r['sha256']and stat.S_IMODE(p.stat().st_mode)==r['mode']
 plan=json.loads(NP.read_bytes());native=json.loads((N/'actual/closed-authority/NATIVE6-ENTRIES.json').read_bytes());template=json.loads((OLD/'SOURCE-TEMPLATE.json').read_bytes());code=plan['family'][0]['proposed_native_doc']['code']
 def canonical(rel):
  b=g('show',canon+':'+rel);assert(R/rel).read_bytes()==b;return b
 scaffold=[]
 for r in plan['copies']:
  rel='chicago/4d/'+r['rel'];b=canonical(rel)
  if sha(b)!=r['source']['sha256']:
   module=r['rel'].removeprefix('generators/');tree=ast.parse(b);expr=[ast.unparse(n.value)for n in tree.body if isinstance(n,ast.Expr)and isinstance(n.value,ast.Call)];scaffold.append({'module':module,'old_snapshot_sha256':r['source']['sha256'],'canonical_sha256':sha(b),'in_actual_bridge_recipe_code':module in code,'top_level_expression_calls':expr,'qualification':'Foreign-family module outside selected bridge_timber dispatch/recipe. No native parity claim for its own family.'})
 assert len(scaffold)==8 and all(not r['in_actual_bridge_recipe_code']for r in scaffold)
 sys.path.insert(0,str(A/'generators'));import mesh_inputs
 sp=importlib.util.spec_from_file_location('bridge_future_ready_params',OLD/'accepted-source/chicago/4d/generators/archetypes/bridge_timber_params.py');params=importlib.util.module_from_spec(sp);sys.modules[sp.name]=params;sp.loader.exec_module(params);oldresolve,oldsha=mesh_inputs.resolve_params,mesh_inputs._sha_file;bridgebytes=(OLD/'accepted-source/chicago/4d/generators/archetypes/bridge_timber.py').read_bytes();mesh_inputs.resolve_params=lambda arch,ph,record:params.from_phase(ph,record)if arch=='bridge_timber'else oldresolve(arch,ph,record);mesh_inputs._sha_file=lambda p:sha(bridgebytes)if p==A/'generators/archetypes/bridge_timber.py'else oldsha(p)
 resolved=[]
 try:
  for f in plan['family']:
   row=next(r for r in native['rows']if r['id']==f['id']);rel='chicago/4d/data/structures/'+f['id']+'.json';base=canonical(rel);assert sha(base)==f['record']['sha256'];record=json.loads((OLD/'accepted-source'/rel).read_bytes())if f['role']=='selected'else json.loads(base);ph=next(x for x in record['phases']if x['id']==f['phase']);doc=mesh_inputs.structure_inputs_doc(record,ph,'bridge_timber');recipe=mesh_inputs.structure_inputs_sha(record,ph,'bridge_timber');assert doc==f['proposed_native_doc']and recipe==row['native_entry']['inputs_sha256']
   for k,cat in [('MASTER','gltf'),('WEB','web')]:assert sha(canonical('chicago/4d/assets/'+cat+'/'+f['asset']))==f[k]['sha256']
   resolved.append({'id':f['id'],'phase':f['phase'],'recipe_sha256':recipe,'complete_params_properties_confidence_code_pin_document_equal_actual_native6':True,'full_doc_sha256':sha(json.dumps(doc,sort_keys=True).encode()),'current_record_sha256':sha(base),'current_MASTER_sha256':f['MASTER']['sha256'],'current_WEB_sha256':f['WEB']['sha256'],'native_control_status':'Actualselected c7408d/f7ab reusable; currentprimary is still baseline.'if f['role']=='selected'else'Prior actual defaultMASTER/WEB parity remains input/output exact.'})
 finally:mesh_inputs.resolve_params,mesh_inputs._sha_file=oldresolve,oldsha
 closure=[]
 for module,h in code.items():
  b=canonical('chicago/4d/generators/'+module);planned=bridgebytes if module=='archetypes/bridge_timber.py'else b;assert sha(planned)==h;closure.append({'module':module,'canonical_sha256':sha(b),'selected_overlay_sha256':sha(planned),'actual_native6_sha256':h,'intended_own_overlay':module=='archetypes/bridge_timber.py'})
 reg=json.loads(canonical('chicago/4d/assets/manifest.json'));web=json.loads(canonical('chicago/4d/assets/manifest.web.json'));names={f['asset']for f in plan['family']};assert{k for k,v in reg['assets'].items()if v.get('archetype')=='bridge_timber'}==names
 for f in plan['family']:assert reg['assets'][f['asset']]['inputs_sha256']==f['current_native_recipe']and web['masters'][f['asset']]==f['MASTER']['sha256']
 source=[]
 for r in template['paths']:
  rel=r['path'];p=R/rel;cur=canonical(rel)if p.exists()else None;basep=OLD/'baseline-source'/rel;base=basep.read_bytes()if basep.exists()else None;own=(OLD/('bridge-only-delta'if r['bridge_only_shared_delta']else'accepted-source')/rel).read_bytes();reason='exact_current_base'
  if rel.endswith('name_pool_keys.json'):
   b,o,c=map(json.loads,[base,own,cur]);add=[x for x in o['read']['structures']if x not in b['read']['structures']];assert len(add)==6;out=copy.deepcopy(c);out['read']['structures'] += [x for x in add if x not in out['read']['structures']];check=copy.deepcopy(out);check['read']['structures']=c['read']['structures'];assert check==c;result=(json.dumps(out,indent=2,ensure_ascii=False)+'\n').encode();reason='six_own_note_readers_entrywise_preserving_foreign_order_metadata'
  elif rel.endswith('docs/GLB-CONTRACT.md'):
   assert own.startswith(base);suffix=own[len(base):];assert b'## Optional span walk-surface profile (T-2375)'not in cur;result=cur+suffix;reason='own_suffix_append_current_prefix_preserved'
  elif cur==base:result=own
  elif cur==own:result=cur;reason='already_identical_own_source'
  elif cur is not None and base is not None:
   exit,result=merge_ram(cur,base,own);assert exit==0 and b'<<<<<<<'not in result,(rel,exit);reason='strict_clean_native_threeway_bridge_only_delta'
  else:raise AssertionError(('Ownpath collision/absence drift',rel))
  source.append({'path':rel,'canonical_preimage_sha256':sha(cur)if cur is not None else None,'canonical_preimage_bytes':len(cur)if cur is not None else 0,'candidate_sha256_if_same_inputs':sha(result),'semantic_composition':reason,'old_preimage_sha256':r['base_sha256'],'changed_from_old_base':cur!=base})
 assert state()==before and all(sha((R/p).read_bytes())==h for p,h in active.items())
 result={'status':'ACTUAL_READONLY_CANONICAL9117_BRIDGE_NATIVE6_SEMANTICS_AND_ENTRYWISE_SOURCE_READINESS_PASS_NO_APPLICATION','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'canonical_base':canon,'root_active_performance_branch':applied['branch'],'root_seven_applied_paths_unchanged':True,'source_Git_HEAD_index_config_refs_status_before_after_exact':True,'old80_manifest_sha256':sha(raw),'old80_all_members_rechecked_exact':True,'scaffold_only_incoming_drifts':scaffold,'actual_native_bridge_code_closure':closure,'all_six_actual_recipe_documents_recomputed_exact':resolved,'source20_current_entrywise_composition':source,'current_native_registry':{'MASTER_rows':len(reg['assets']),'WEB_rows':len(web['masters']),'exact_bridge_family_assets':sorted(names),'six_baseline_rows_still_exact_to_old_plan':True,'future_replacement':'Only six actualnativeownerrows mayupdate; preserve currentforeignrows/order/metadata. No stalewholemanifest or blindrecipehash replacement.'},'new_native_export_WEB_browser_test_gate_source_Gitref_or_API_write':False,'future_actual_post_T3262_and_PR1456_merge_fold_binding_required':True}
 assert not args.output.exists();args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'six_recipes':len(resolved),'scaffold_only_drifts':len(scaffold),'source_paths':len(source),'output':str(args.output)}))
if __name__=='__main__':main()
