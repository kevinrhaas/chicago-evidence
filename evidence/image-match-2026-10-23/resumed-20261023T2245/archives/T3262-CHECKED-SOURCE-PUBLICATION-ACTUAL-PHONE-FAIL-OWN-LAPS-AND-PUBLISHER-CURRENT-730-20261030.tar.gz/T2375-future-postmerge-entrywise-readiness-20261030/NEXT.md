# Bridge future rebind: semantic readiness on canonical9117, no adoption

The original accepted Bridge packet remains frozen:80files, manifest `c381cb09291a341779fd9542410655b946022bfa5012279839ad65f4058fe68d`. Every member was rehashed unchanged. This small packet contains only audit metadata, source-analysis code, a future preparation wrapper and these instructions. It duplicates no geometry, photographs, comparisons or whole source postimages.

The read-only audit ran while the primary writer's seven-path T-3262 source gate was active. Canonical HEAD was `9117b2263cf0aeb5fea33dec4a87ee519c5b41af`; all seven applied performance source hashes and HEAD/index/config/all refs/status stayed exact. No source, Git ref, native producer, browser, test harness, gate or API write ran.

## What the incoming producer changes mean

All six bridge records and all twelve current baseline MASTER/WEB assets are byte-exact to the earlier native6 bindings. The actual selected proposal still uses MASTER `c7408d424c67488f56650e190fdd7af6a23a667c67f005dff1849ef20c3b2f84` and official WEB `f7abac99a73e858b055c5668a61e093a7786385cb542cecb3245ebc55d7907ab`.

The native parameter resolver was called against current code with only the accepted bridge parameter/builder overlay. All six **complete** resolved documents—fields, derived properties, confidence floats, geometry module hashes and Blender pin—and their recipe hashes equal the actual canonical native6 receipt. This is semantic resolution, not replacing an old expected hash with a new one. Five current default bridge MASTER/WEB files remain exactly those already proved byte-identical during the actual six-model run. No repeat bake is indicated while that full agreement survives.

The bridge recipe selects `emit.py`, `archetypes/bridge_timber.py`, and common logwork/materials/mesh/openings. Five existing modules remain byte-exact; the bridge builder differs only because the accepted own overlay has not yet been adopted. K01, its parameter module, K08 and K11 changed in the broader copied scaffold. Frame/log dwelling builders and parameter modules changed too—eight scaffold-only drifts in total. None belongs to the selected bridge recipe. Their module-level expression-call ASTs remain unchanged. K01's MATERIALS updates act on its own dictionary and kit, not bridge common/materials; bridge dispatch selects only the bridge builder/parameter pair.

That qualifies the **bridge** dependency boundary. It does not assert fresh native byte parity for the foreign K01/K08/K11/frame/log families. Leave their current code, models and registry entries canonical and untouched. Do not blindly refresh all old scaffold hashes or run broad default controls merely because unrelated files share a copied directory.

The current manifests still contain exactly the same six bridge assets, and all six baseline rows remain exact. Future adoption updates only the six actual native owner rows entrywise, preserving all current foreign rows, order and metadata. The five unchanged bridge model files need no replacement.

## Future source composition

Read-only composition of the twenty authored paths against canonical9117 succeeded. Only the name-reader table's base had changed; the six own reader additions union entrywise while preserving every foreign value and order. The contract keeps the complete current prefix and appends its own suffix. Shared renderer/compiler changes use the original bridge-only delta, never old Green Tree whole files. The existing30-path preparer already rebuilds native registries and the Liberty prefix from current data; its old generated postimages must not be replayed on a future tree.

The accepted Earle and Andreas captures retain the root's T3153 qualitative-form acceptance and explicit illustration/camera/tone tolerances. The original raw native matches stay UNREVIEWED in their immutable evidence; the old80packet holds separate proposed canonical records. The original source credit is retained: **Chicago Tribune Editorial February 15, 1880**. The editorial was located, but the exact Baker illustration remains independently unlocated and reference-only. Geometry rests on identified cleared Andreas/Earle evidence and the secondary Norton/Moses-Kirkland text; no new Baker-derived geometry or clearance is claimed.

## Required actual post-merge binding

Do not apply Bridge work during T-3262 or PR1456 integration. First normally merge the performance support PR and PR1456 and let the native final changelog fold settle. Record their **actual dev merge/squash SHAs**, not their old feature branch heads. Root then takes the original T-2375 claim if available and creates its separate clean steward branch from actual current dev.

The future wrapper defaults to binding validation only. It requires both actual merge commits to be ancestors of the actual final native changelog-fold commit, and that fold to be an ancestor of clean current HEAD. All arguments must be full real commit IDs; no future ID is guessed:

```bash
source /workspace/shared/resume-chicago-env.sh
PYTHONDONTWRITEBYTECODE=1 python /workspace/T2375-future-postmerge-entrywise-readiness-20261030/reprepare_after_merges.py \
  --expected-head ACTUAL_CURRENT_DEV_HEAD \
  --performance-merge ACTUAL_T3262_DEV_MERGE \
  --pictures-merge ACTUAL_PR1456_DEV_MERGE \
  --final-fold ACTUAL_FINAL_CHANGELOG_FOLD \
  --output /workspace/T2375-rebound-ACTUAL
```

Add `--prepare` only in that later source phase. It invokes the existing reviewed preparer to derive six complete recipes again and produce fresh30entrywise postimages in the new external directory. It does not apply, stage, commit, claim, bake or render. Any changed actual recipe or authored conflict must stop for specific review. The wrapper has not been executed here because neither future merge/fold binding exists yet.

## Work still owed for the original T-2375 MPR

After legitimate source adoption, run current native owners/source/rights/grade/picture generation and publish, with the existing native6 recipe proofs bound to the adopted model bytes. Validate both canonical match registrations through the native image gate; do not retune already accepted pictures. Inspect any legitimate target-only rights-derivation repair and preserve foreign exemptions.

Current app acceptance remains unrun for this bridge proposal: desktop and390×780 Normal/ByGrade, full credited Images/Sources/Research/Liberties, real street-to-bridge approach and walking across the sloped draw to both banks, land/deck transitions and terrain contact, and full current neighboring prop/horse/vehicle/yard extents without overlap. A nominal human-root deck-top sampler that bridges8mm board gaps and ignores55mm proud joints does not certify whole-body, shoe/IK/wheel or vehicle contact. Check those actual consumers rather than extending the sampler's claim.

Finish the actual shared-runtime diff's required published smoke, unchanged complete phone budget, full source/preflight gates, current STATUS/ROADMAP notes, original T-2375 MPR, current-head required CI, safe normal dev merge and official settlement. No application acceptance, PR, ticket completion, new picture-fit trial or photo-follow-up is claimed by this readiness packet.
