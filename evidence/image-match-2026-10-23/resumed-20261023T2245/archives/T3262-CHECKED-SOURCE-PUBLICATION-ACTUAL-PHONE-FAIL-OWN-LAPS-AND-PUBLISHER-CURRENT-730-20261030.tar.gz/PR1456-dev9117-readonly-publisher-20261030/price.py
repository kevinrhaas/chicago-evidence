from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import quote
import os,json,hashlib,zlib,datetime,importlib.util,base64
os.sched_setaffinity(0,{2});os.nice(19)
O=Path(__file__).parent;TIP='9117b2263cf0aeb5fea33dec4a87ee519c5b41af';s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);save=lambda n,x:(O/n).write_text(json.dumps(x,indent=2)+'\n');sha=lambda b:hashlib.sha256(b).hexdigest();gitsha=lambda k,b:hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
commit=m.api('git/commits/'+TIP);tree=m.api('git/trees/'+commit['tree']['sha']+'?recursive=1');assert not tree['truncated'];leaves={r['path']:r for r in tree['tree']if r['type']!='tree'};blobs={r['sha']:r for r in leaves.values()if r['type']=='blob'};known=m.indexed(blobs);missing={s:r for s,r in blobs.items()if s not in known};assert sum(r['size']for r in missing.values())<=64*1024**2
allrows=[];newmeta={};metadata_known=[];paths={};groups={}
for r in tree['tree']:
 parent,_,name=r['path'].rpartition('/');groups.setdefault(parent,[]).append((name,r))
 paths[r['path']]=r
roots={'':tree['sha'],**{r['path']:r['sha']for r in tree['tree']if r['type']=='tree'}};knownTrees=m.indexed(roots.values())
for path,tid in roots.items():
 if tid in knownTrees:continue
 rows=sorted(groups[path],key=lambda x:x[0].encode()+ (b'/'if x[1]['type']=='tree'else b''));raw=b''.join((('40000'if r['type']=='tree'else r['mode']).encode()+b' '+name.encode()+b'\0'+bytes.fromhex(r['sha']))for name,r in rows);assert gitsha('tree',raw)==tid
 if tid in newmeta:assert newmeta[tid][1]==raw
 newmeta[tid]=('tree',raw,path)

def reconstruct(c):
 v=c['verification'];payload=v.get('payload');sig=v.get('signature')
 if payload and sig:
  h,msg=payload.encode().split(b'\n\n',1)
  for signature in [sig.encode(),sig.encode().rstrip(b'\n')]:
   lines=signature.split(b'\n');gpg=b'gpgsig '+b'\n '.join(lines);raw=h+b'\n'+gpg+b'\n\n'+msg
   if gitsha('commit',raw)==c['sha']:return raw
 if not sig:
  def actor(k):
   x=c[k];dt=datetime.datetime.fromisoformat(x['date'].replace('Z','+00:00'));return k+' '+x['name']+' <'+x['email']+'> '+str(int(dt.timestamp()))+' +0000'
  h=['tree '+c['tree']['sha'],*['parent '+p['sha']for p in c['parents']],actor('author'),actor('committer')]
  for ending in ['', '\n']:
   raw=('\n'.join(h)+'\n\n'+c['message']+ending).encode()
   if gitsha('commit',raw)==c['sha']:return raw
 raise AssertionError('Canonical commit reconstruction refused; no assumed timezone/signature: '+c['sha'])
queue=[TIP];seen=set();commitjson={}
while queue:
 s=queue.pop()
 if s in seen:continue
 seen.add(s);assert len(seen)<=16
 if s in m.indexed([s]):
  b=m.obj('commit',s);metadata_known.append({'sha':s,'kind':'commit','bytes':len(b),'sha256':sha(b)});continue
 c=m.api('git/commits/'+s);commitjson[s]=c;b=reconstruct(c);newmeta[s]=('commit',b,'exact immutable GitData commit');queue.extend(p['sha']for p in c['parents'])
# Preserve each new native commit's missing intermediate trees as well as the final tip.
extra_trees={}
def collect_tree(tid,path):
 if tid in newmeta or tid in m.indexed([tid]):return
 j=m.api('git/trees/'+tid);assert not j.get('truncated');extra_trees[tid]=j
 rows=sorted(j['tree'],key=lambda r:r['path'].encode()+(b'/'if r['type']=='tree'else b''))
 b=b''.join((('40000'if r['type']=='tree'else r['mode']).encode()+b' '+r['path'].encode()+b'\0'+bytes.fromhex(r['sha']))for r in rows);assert gitsha('tree',b)==tid
 newmeta[tid]=('tree',b,'intermediate nativecommit tree:'+path)
 for r in rows:
  if r['type']=='tree':collect_tree(r['sha'],path+'/'+r['path'])
for c in commitjson.values():collect_tree(c['tree']['sha'],c['sha'])
save('EXTRA-TREE-GITDATA.json',extra_trees)

for s,(kind,b,path)in newmeta.items():
 raw=kind.encode()+b' '+str(len(b)).encode()+b'\0'+b;enc=zlib.compress(raw);assert gitsha(kind,b)==s;allrows.append({'sha':s,'kind':kind,'path':path,'bytes':len(b),'sha256':sha(b),'encoded_bytes':len(enc),'encoded_sha256':sha(enc),'allocated_upper_4k':((len(enc)+4095)//4096)*4096})
for s,r in missing.items():
 path=r['path']
 with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+TIP+'/'+quote(path,safe='/'),headers={'User-Agent':'Chicago-exact9117-readonly-canonical-object-price'}),timeout=60)as f:b=f.read(r['size']+1);assert f.status==200
 assert len(b)==r['size']and gitsha('blob',b)==s;enc=zlib.compress(b'blob '+str(len(b)).encode()+b'\0'+b);allrows.append({'sha':s,'kind':'blob','path':path,'bytes':len(b),'sha256':sha(b),'encoded_bytes':len(enc),'encoded_sha256':sha(enc),'allocated_upper_4k':((len(enc)+4095)//4096)*4096})
# Retain genuine feature entry blobs absent from foldedtip for native history checks.
for feature in ['db1e6a2174cf3e2ef1829e07c0645b26101fe70d','40427ab4ca2b397ab85afd9c1ea2536d5928c6b5']:
 for r in m.api('commits/'+feature)['files']:
  if r['filename'].startswith('chicago/4d/changelog.d/')and r['status']=='added'and r['sha']not in m.indexed([r['sha']])and r['sha']not in {x['sha']for x in allrows}:
   j=m.api('git/blobs/'+r['sha']);b=base64.b64decode(j['content']);assert len(b)==j['size']<4096 and gitsha('blob',b)==r['sha'];enc=zlib.compress(b'blob '+str(len(b)).encode()+b'\0'+b);allrows.append({'sha':r['sha'],'kind':'blob','path':r['filename'],'feature_commit':feature,'bytes':len(b),'sha256':sha(b),'encoded_bytes':len(enc),'encoded_sha256':sha(enc),'allocated_upper_4k':((len(enc)+4095)//4096)*4096})
result={'status':'ACTUAL_9117_AFTER_IMPORTED_039_CANONICAL_TIP_AND_NATIVE_HISTORY_PRICE_RAM_ONLY_NO_IMPORT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tip':TIP,'tree':tree['sha'],'parents':[r['sha']for r in commit['parents']],'tip_leaf_entries':len(leaves),'tip_blob_ids':len(blobs),'missing_tip_blobs':len(missing),'missing_tip_blob_raw_bytes':sum(r['size']for r in missing.values()),'new_metadata_objects':len(newmeta),'new_metadata_raw_bytes':sum(len(r[1])for r in newmeta.values()),'known_boundary_commits_verified':metadata_known,'all_new_canonical_metadata_reconstructed_exact_SHA':True,'isolated_or_primary_fetch_needed':False,'new_total_objects':len(allrows),'new_total_raw_bytes':sum(r['bytes']for r in allrows),'new_total_allocation_upper_4k':sum(r['allocated_upper_4k']for r in allrows),'extra_genuine_feature_entries':sum('feature_commit'in r for r in allrows),'workspace_floor':536870912,'working_reserve':16777216,'workspace_additional_guard':1048576,'required_workspace_bytes':536870912+16777216+1048576+sum(r['allocated_upper_4k']for r in allrows),'workspace_free':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize,'tmp_free':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'unchanged_tmp_floor':1800000000,'raw_payloads_RAM_only_not_saved':True,'no_primary_source_HEAD_index_config_status_refs_reads_or_writes':True,'rows':allrows}
assert result['new_total_raw_bytes']<=64*1024**2;save('RESULT.json',result);save('NEW-COMMIT-GITDATA.json',commitjson);save('REMOTE-COMMIT.json',commit);print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2))

selected=json.loads(Path('/workspace/PR1456-standalone-phone-memory-extraction-20261030/PLAN.json').read_text())['paths'];bindings=[]
for selectedrow in selected:
 r=leaves[selectedrow['path']];assert r['mode']==selectedrow['mode'] and r['sha']==selectedrow['039_preimage_blob'];bindings.append({'path':r['path'],'mode':r['mode'],'blob':r['sha'],'bytes':r['size'],'exact039preimage':True})
save('FOUR-PERFORMANCE-PATHS-EXACT9117.json',{'status':'ALL_FOUR_IMMUTABLE9117_PERFORMANCE_PREIMAGES_EXACT039','tip':TIP,'tree':tree['sha'],'paths':bindings})
