# Standalone performance publication and ordinary PR — prepared, unrun

`publish_native.py` copies the proven native object reader/payload/reconstruction routines from the bc helper and narrows publication to exactly one ordinary native commit with one parent: the explicit current canonical base. Branch, base, head, qualified tree, ticket and actual gate receipt are parameters. The gate schema matches the frozen first_fort_ready standalone controller.

Exactly seven changed100644blob paths are permitted: railway.js, spatial-batch.js, check_confidence_lane.mjs, test_rail_geometry_lifecycle.mjs, STATUS.md, ROADMAP.md and changelog.d/<actual-ticket>.json, all under chicago/4d. No other source, model, registry, image/library, workbook, workflow or deletion is accepted. The root explicitly approved a4MiB raw source cap: current full STATUS+ROADMAP plus the four small files cost about2.97MB before the own entry. Both all-seven postimage bytes and new blob bytes must fit the hard cap; it cannot be raised above4MiB by CLI.

Default execution only plans and performs read-only immutable API checks. `--publish` uploads exact native blobs/tree/commit and creates the **absent** own branch. Existing branch refs are refused, never overwritten or forced. An already-created identical native GitData commit may be reused after a partial object-only attempt; source topology still must be exactly one commit on the declared base. Native author/committer/time/message/parent bytes stay exact, and a changed native SHA refuses.

Before publication the actual full-source PASS must bind all seven current hashes, the exact tree/base/branch/ticket, all true source/reaper guards, unchanged config and actual CHECKPASS footer. The current config must equal the gate's hash. The checked commit must be clean HEAD on the requested branch with no active merge. Every changed path is then fetched through its immutable raw commit URL and compared byte-for-byte/Gitblob/hash to the local native object. Every local HEAD/index/config/status/ref snapshot remains exact; no fetch, Git config change, local ref update, merge or production action occurs.

`--create-pr` with `--publish --title --body-file` creates an ordinary non-draft PR into dev only after the seven-path immutable readback passes. It sends the exact title/body through structured JSON, verifies the resulting head/base/title/body and records PR-CREATED.json. It refuses an already-open PR on the branch. No ticket state transition or merge is included. The PR's GitHub CI and any still-pending phone qualification remain the primary writer's next steps.

## Invocation after actual source gate/native checkpoint

Replace placeholders with the **actual** values; current base may be9117 rather than the older039 extraction base. Do not run against guessed commits or an uncommitted tree.

```bash
source /workspace/shared/resume-chicago-env.sh
PYTHONDONTWRITEBYTECODE=1 python /workspace/standalone-phone-memory-publication-prep-bridge-20261030/publish_native.py \
  --base ACTUAL_BASE --head ACTUAL_CHECKED_NATIVE_HEAD \
  --qualified-tree ACTUAL_CHECKED_TREE --branch steward/ACTUAL_OWN_BRANCH \
  --ticket T-ACTUAL --gate-proof ACTUAL_RUN/GATE-RESULT.json \
  --output /workspace/ACTUAL_READONLY_PUBLICATION_PLAN
```

After root review, use a **new** output directory and add `--publish --create-pr --title 'T-ACTUAL: …' --body-file /workspace/ACTUAL_BODY.md`. The4MiB approved cap is the default and remains hard. The default plan does not create a branch or PR.

PUBLICATION.json closes the immutable branch checkpoint before the PR call. If PR creation fails later, retain that receipt and the exact branch; do not delete or force it. Resume through a reviewed ordinary PR creation using the existing publication receipt, because a fresh publication invocation intentionally refuses the now-existing branch. Any partial negative outputs stay preserved.

PREPARED.json and PROVEN-HELPER-DIFF.patch show the exact semantic/source changes. Only Python syntax was checked in this preparation; no real gate, native commit, source/branch/ref/ticket/API write or controller execution was performed.
