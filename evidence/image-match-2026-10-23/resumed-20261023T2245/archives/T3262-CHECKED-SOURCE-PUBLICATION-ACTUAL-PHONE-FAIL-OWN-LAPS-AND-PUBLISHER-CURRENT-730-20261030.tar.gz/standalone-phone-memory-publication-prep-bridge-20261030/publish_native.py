"""Bounded native-commit transport. Default is read-only planning; no git push/fetch.

Run only after the actual checked final native commits exist. --publish additionally
requires the exact checked final tree, a passing gate receipt, and explicit expected
remote branch state. Native Git SHAs, trees, messages, author dates and parents stay exact.
"""
from pathlib import Path
import argparse,base64,datetime,hashlib,json,os,re,struct,subprocess
from urllib.request import Request,urlopen
from urllib.error import HTTPError

REPO='kevinrhaas/chicago';SOURCE=Path('/workspace/chicago');G=SOURCE/'.git'
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*args):
    return subprocess.check_output(['git','-C',str(SOURCE),'-c','gc.auto=0','-c','maintenance.auto=false','-c','protocol.allow=never',*args],env=ENV)
def shab(b):return hashlib.sha256(b).hexdigest()
def gitsha(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def api(path,data=None,method=None,missing=False):
    req=Request('https://api.github.com/repos/'+REPO+'/'+path,data=None if data is None else json.dumps(data).encode(),headers={'User-Agent':'Chicago-standalone-phone-memory-native-transport','Accept':'application/vnd.github+json','Content-Type':'application/json'},method=method or('GET'if data is None else'POST'))
    try:
        with urlopen(req,timeout=120)as r:return json.load(r)
    except HTTPError as e:
        if missing and e.code==404:return None
        raise
def indexed(wanted):
    wanted=set(wanted);found={s for s in wanted if(G/'objects'/s[:2]/s[2:]).is_file()}
    for p in(G/'objects/pack').glob('*.idx'):
        if wanted<=found:break
        with p.open('rb')as f:
            h=f.read(8);v2=h[:4]==b'\xfftOc';off=8 if v2 else 0
            if v2:assert struct.unpack('>I',h[4:])[0]==2
            f.seek(off);fan=struct.unpack('>256I',f.read(1024));tab=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
            for s in wanted-found:
                key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
                while a<z:
                    m=(a+z)//2;f.seek(tab+m*stride+delta)
                    if f.read(20)<key:a=m+1
                    else:z=m
                f.seek(tab+a*stride+delta)
                if a<fan[key[0]]and f.read(20)==key:found.add(s)
    return found
def obj(kind,s):
    assert s in indexed([s]),'Refuse unknown promisor-object read: '+s
    b=git('cat-file',kind,s);assert gitsha(kind,b)==s;return b
TREES={}
def leaves(s):
    if s in TREES:return TREES[s]
    b=obj('tree',s);i=0;out={}
    while i<len(b):
        n=b.index(b' ',i);mode=b[i:n].decode();z=b.index(b'\0',n+1);name=b[n+1:z].decode();child=b[z+1:z+21].hex();i=z+21
        assert name not in ('.','..')and'/'not in name
        if mode=='40000':out.update({name+'/'+p:v for p,v in leaves(child).items()})
        else:
            assert mode in('100644','100755','120000','160000')
            out[name]=(mode,'commit'if mode=='160000'else'blob',child)
    TREES[s]=out;return out
def commit(s):
    raw=obj('commit',s);header,msg=raw.split(b'\n\n',1);lines=header.decode().splitlines()
    return {'sha':s,'raw_sha256':shab(raw),'raw':raw,'lines':lines,'message':msg.decode(),'tree':next(x[5:]for x in lines if x.startswith('tree ')),'parents':[x[7:]for x in lines if x.startswith('parent ')]}
def native_payload(c):
    assert all(x.startswith(('tree ','parent ','author ','committer '))for x in c['lines']),'Unsupported signed/extra native header; do not rewrite native commit'
    p={'tree':c['tree'],'parents':c['parents'],'message':c['message']}
    for k in['author','committer']:
        line=next(x for x in c['lines']if x.startswith(k+' '));m=re.fullmatch(k+r' (.*) <([^>]+)> (\d+) ([+-]\d{4})',line);assert m
        zone=m[4];offset=(int(zone[1:3])*60+int(zone[3:]))*60*(1 if zone[0]=='+'else-1)
        dt=datetime.datetime.fromtimestamp(int(m[3]),datetime.timezone(datetime.timedelta(seconds=offset)))
        p[k]={'name':m[1],'email':m[2],'date':dt.isoformat()}
    return p
def snapshot():
    return {'HEAD':git('rev-parse','HEAD').decode().strip(),'refs':git('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:shab((G/n).read_bytes())for n in['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status':git('status','--porcelain','--untracked-files=all').decode()}
def main():
    from urllib.parse import quote
    a=argparse.ArgumentParser(description=__doc__)
    for name in ['base','head','qualified-tree','branch','ticket','gate-proof','output']:a.add_argument('--'+name,required=True)
    a.add_argument('--max-total-bytes',type=int,default=4*1024**2)
    a.add_argument('--publish',action='store_true');a.add_argument('--create-pr',action='store_true')
    a.add_argument('--title');a.add_argument('--body-file');args=a.parse_args()
    os.sched_setaffinity(0,{2});os.nice(19)
    assert all(re.fullmatch('[0-9a-f]{40}',x)for x in [args.base,args.head,args.qualified_tree])
    assert args.head!=args.base and re.fullmatch(r'T-\d{4,}',args.ticket)
    assert re.fullmatch(r'steward/[a-z0-9][a-z0-9._/-]*',args.branch)and'..'not in args.branch
    git('check-ref-format','refs/heads/'+args.branch)
    assert 0<args.max_total_bytes<=4*1024**2,'Explicit approved fourMiB hard cap'
    assert not args.create_pr or args.publish,'Creating ordinary PR requires actual immutable branch publication'
    body=None
    if args.create_pr:
        assert args.title and args.ticket in args.title and args.body_file
        body=Path(args.body_file).read_text();assert body.strip()and len(body.encode())<=65536
    allowed={
      'chicago/4d/renderers/web/js/railway.js','chicago/4d/renderers/web/js/spatial-batch.js',
      'chicago/4d/tools/check_confidence_lane.mjs','chicago/4d/tools/test_rail_geometry_lifecycle.mjs',
      'chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md',
      'chicago/4d/changelog.d/'+args.ticket+'.json',
    }
    out=Path(args.output);out.mkdir(exist_ok=False)
    save=lambda n,x:(out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
    before=snapshot();save('SOURCE-BEFORE.json',before)
    assert before['HEAD']==args.head and not before['status']and not(G/'MERGE_HEAD').exists()
    assert git('branch','--show-current').decode().strip()==args.branch
    base=commit(args.base);head=commit(args.head)
    assert head['tree']==args.qualified_tree and head['parents']==[args.base],'Exactly one ordinary native commit on the declared canonical base'
    payload=native_payload(head)
    gate_path=Path(args.gate_proof);gate_raw=gate_path.read_bytes();gate=json.loads(gate_raw)
    assert gate.get('status')=='ACTUAL_STANDALONE_PERFORMANCE_FULL_SOURCE_CHECK_PASS'and gate.get('exit')==0
    required={'HEAD','staged_tree','tracked_working_bytes','no_untracked','no_conflicts','staged_path_sha256','all_children_reaped'}
    assert required<=set(gate.get('guards',{}))and all(v is True for v in gate['guards'].values())
    assert gate.get('config_unchanged')is True and any('CHECK PASS'in s for s in gate.get('footer',[]))
    binding=gate.get('binding',{});checked=binding.get('all_staged_paths',{})
    assert binding.get('head')==args.base and binding.get('checked_final_staged_tree')==args.qualified_tree
    assert binding.get('branch')==args.branch and binding.get('ticket')==args.ticket
    assert binding.get('source_config_sha256')==shab((G/'config').read_bytes()),'Current config must match actual source gate'
    assert set(checked)==allowed and len(checked)==7
    assert all(re.fullmatch('[0-9a-f]{64}',h)and shab((SOURCE/p).read_bytes())==h for p,h in checked.items())
    old=leaves(base['tree']);cur=leaves(head['tree'])
    changes={p:cur.get(p)for p in sorted(set(old)|set(cur))if old.get(p)!=cur.get(p)}
    assert set(changes)==allowed and all(v is not None and v[:2]==('100644','blob')for v in changes.values())
    postimages={p:obj('blob',v[2])for p,v in changes.items()}
    assert all(shab(postimages[p])==checked[p]for p in allowed)
    total_source=sum(map(len,postimages.values()));assert total_source<=args.max_total_bytes
    remote_base=api('git/commits/'+args.base)
    assert remote_base['sha']==args.base and remote_base['tree']['sha']==base['tree']
    existing_commit=api('git/commits/'+args.head,missing=True)
    if existing_commit:
        assert existing_commit['tree']['sha']==head['tree']and[p['sha']for p in existing_commit['parents']]==[args.base]
    branch_path='git/ref/heads/'+quote(args.branch,safe='/')
    assert api(branch_path,missing=True)is None,'Expected absent own branch; never overwrite or force an existing ref'
    prior_prs=api('pulls?state=open&base=dev&head='+quote('kevinrhaas:'+args.branch,safe='')+'&per_page=100')
    assert prior_prs==[],'Do not duplicate or alter an existing open PR'
    remote_blobs={v[2]for v in old.values()if v[1]=='blob'}
    needed={v[2]:postimages[p]for p,v in changes.items()if v[2]not in remote_blobs}
    assert sum(map(len,needed.values()))<=args.max_total_bytes
    plan={'status':'EXACT_NATIVE_SINGLE_COMMIT_SEVEN_PATH_PUBLICATION_PLANNED_NO_WRITES','base':args.base,'head':args.head,'tree':args.qualified_tree,'branch':args.branch,'ticket':args.ticket,'parents':[args.base],'native_commit_raw_sha256':head['raw_sha256'],'expected_old':'absent','force':False,'native_commits':1,'already_remote_native_commit':existing_commit is not None,'paths':{p:{'mode':v[0],'blob':v[2],'bytes':len(postimages[p]),'sha256':checked[p]}for p,v in changes.items()},'new_blob_bytes':sum(map(len,needed.values())),'all_seven_postimage_bytes':total_source,'max_total_bytes':args.max_total_bytes,'gate':{'path':str(gate_path),'sha256':shab(gate_raw)},'ordinary_PR_requested':args.create_pr,'PR_title':args.title if args.create_pr else None,'PR_body_sha256':shab(body.encode())if body is not None else None}
    save('PLAN.json',plan);assert snapshot()==before
    if not args.publish:print(json.dumps({'status':plan['status'],'paths':7,'all_seven_postimage_bytes':total_source}));return
    for s,b in needed.items():
        result=api('git/blobs',{'encoding':'base64','content':base64.b64encode(b).decode()});assert result['sha']==s
    if not existing_commit:
        entries=[{'path':p,'mode':v[0],'type':v[1],'sha':v[2]}for p,v in changes.items()]
        result=api('git/trees',{'base_tree':base['tree'],'tree':entries});assert result['sha']==head['tree']
        result=api('git/commits',payload);save('NATIVE-COMMIT.json',result);assert result['sha']==args.head,'Refuse any native commit SHA rewrite'
    assert api(branch_path,missing=True)is None and snapshot()==before
    result=api('git/refs',{'ref':'refs/heads/'+args.branch,'sha':args.head});assert result['object']['sha']==args.head
    assert api(branch_path)['object']['sha']==args.head
    public=api('git/commits/'+args.head);assert public['sha']==args.head and public['tree']['sha']==args.qualified_tree and[p['sha']for p in public['parents']]==[args.base]
    readback=[]
    for p,v in sorted(changes.items()):
        request=Request('https://raw.githubusercontent.com/'+REPO+'/'+args.head+'/'+quote(p,safe='/'),headers={'User-Agent':'Chicago-standalone-phone-memory-native-transport'})
        with urlopen(request,timeout=120)as response:assert response.status==200;b=response.read()
        assert b==postimages[p]and gitsha('blob',b)==v[2];readback.append({'path':p,'bytes':len(b),'sha256':shab(b),'git_blob':v[2]})
    assert len(readback)==7 and snapshot()==before
    publication={'status':'EXACT_NATIVE_SINGLE_COMMIT_SEVEN_PATH_BRANCH_IMMUTABLE_READBACK_PASS','base':args.base,'head':args.head,'tree':args.qualified_tree,'parents':[args.base],'branch':args.branch,'ticket':args.ticket,'expected_old':'absent','force':False,'native_SHA_and_parents_preserved':True,'all_seven_postimage_bytes':total_source,'readback':readback,'source_HEAD_index_config_allrefs_status_unchanged':True}
    save('PUBLICATION.json',publication)
    pr_receipt=None
    if args.create_pr:
        # Structured native JSON body: preserve newlines and literal code safely.
        assert api(branch_path)['object']['sha']==args.head and snapshot()==before
        existing=api('pulls?state=open&base=dev&head='+quote('kevinrhaas:'+args.branch,safe='')+'&per_page=100');assert existing==[]
        made=api('pulls',{'title':args.title,'body':body,'head':args.branch,'base':'dev','draft':False})
        check=api('pulls/'+str(made['number']))
        assert check['state']=='open'and check['draft']is False and check['head']['sha']==args.head and check['head']['ref']==args.branch and check['base']['ref']=='dev'and check['title']==args.title and check['body']==body
        pr_receipt={'status':'ORDINARY_NON_DRAFT_DEV_PR_CREATED_EXACT_HEAD_TITLE_BODY_READBACK_PASS','number':check['number'],'url':check['html_url'],'head':args.head,'branch':args.branch,'base':'dev','title':args.title,'body_sha256':shab(body.encode()),'merged':False}
        save('PR-CREATED.json',pr_receipt)
    after=snapshot();save('SOURCE-AFTER.json',after);assert after==before
    save('RESULT.json',{'status':'EXACT_NATIVE_PERFORMANCE_BRANCH_PUBLICATION_AND_OPTIONAL_ORDINARY_PR_PASS','publication':publication,'PR':pr_receipt,'no_merge_main_promotion_or_ticket_mutation':True,'source_HEAD_index_config_allrefs_status_unchanged':True})
    print(json.dumps({'status':'EXACT_NATIVE_PERFORMANCE_BRANCH_PUBLICATION_AND_OPTIONAL_ORDINARY_PR_PASS','head':args.head,'PR':None if pr_receipt is None else pr_receipt['url']}))
if __name__=='__main__':main()
