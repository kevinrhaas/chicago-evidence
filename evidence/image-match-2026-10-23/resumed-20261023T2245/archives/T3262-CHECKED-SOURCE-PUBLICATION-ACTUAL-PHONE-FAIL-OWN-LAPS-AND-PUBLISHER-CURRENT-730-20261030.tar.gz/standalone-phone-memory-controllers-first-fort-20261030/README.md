Root-executed standalone performance controllers; external preparation only.

Exactly7 source paths: four extraction postimages, own changelog.d/T-NNNN.json, and tiny own-ticket STATUS/ROADMAP prefixes preserving actualbasebytes. The actual branch/base/head/tree/ticket are explicit CLI inputs. Base may be039or9117oractuallater head ONLY if allfour exact known preimages still match; no merge or inherited-workbook assumptions. No primary source/Git/runtime/API mutation during preparation.

Root commands after handing off actual branch/stagedsource (replace BASE TREE BRANCH TICKET with actual values):

python3 /workspace/standalone-phone-memory-controllers-first-fort-20261030/gate.py --expect-head BASE --expect-tree TREE --expect-branch BRANCH --ticket TICKET --execute
python3 /workspace/standalone-phone-memory-controllers-first-fort-20261030/checkpoint.py --expect-head BASE --expect-tree TREE --expect-branch BRANCH --ticket TICKET --execute

Then replace HEAD with actual native checkpointhead (same checkedTREE):

python3 /workspace/standalone-phone-memory-controllers-first-fort-20261030/phone.py --expect-head HEAD --expect-tree TREE --expect-branch BRANCH --ticket TICKET --execute
python3 /workspace/standalone-phone-memory-controllers-first-fort-20261030/smoke14.py --expect-head HEAD --expect-tree TREE --expect-branch BRANCH --ticket TICKET --outdir /workspace/ACTUAL-OWNED-STAGE14-OUTPUT --execute

Gate runs ordinaryPRIMARY bash tools/check.sh with4workers and actualfooter/reaper/source/index/config/foreignref guards. Existing reviewed node shim is limited to the identical tiny local scratch Git fixture. Checkpoint makes exactlyone ordinary native commit,parentactualbase, and runs changelog/ticket/fold checks. Allforeignrefs remain exact. Phone uses actual ordinaryPRIMARY fullgatepublication and unchanged officialcomplete1904mobile400MiB argv/config. No old3746measurement is relabelled. ShortownedworkspaceTMP/profiles retire only after reaper+sourceguards.

Optional smoke controller runs actualpublished stage14 desktop thenmobile with unmodified native waits/assertions. It keeps screenshots in the explicit ownnewoutputdirectory and logs/reapers in this packet. Stage14BOTH proves railway plus nativealways-on/vendor/pageerror checks, notwholemap1-3,7-12,14. Historicaldesktop29min is disclosed; there is no invented600sPASSassertion or timingbypass. Root must schedule runtime jobsserially and grant sufficient CPUwindow. PriorPeople/body/browsercaptures are not rerun or asserted by these performancecontrollers.

WSfloor512MiBplus8MiB gate-outputreserve/24MiB phone-or-smokereserve; callerTMP1.8GB before/after unchanged. Any actual failedfooter/guard/metric/assertion remains unqualified and rawoutputs retained. Native CI/publication/devmerge remain separate.
