The log jail lacked the high plank palisade described by Gale and shown in the credited 1902 plate. This adds a pointed board enclosure through the native renderer and preserves the tested entrance approach. Height, outline, stock and July continuity are reconstructed. Source comparisons reuse the actual enclosure meshes and bind their inputs; provisional cameras retain credits without a historical “From this spot” action.

Both original comparisons remain **DIFFERS**. The missing keeper house and unresolved full-compound/gate relationship remain open on T-2380.

Dependency #1328 is merged and its fold is integrated at `a575ddde`. Its release entry is removed only after the native reader confirmed exact title/kind/items already folded as v2302; incoming canonical history remains byte-exact.

Four reviewed smoke and placement checks also account for the existing lighthouse translucent batch, footprints with offset origins and already-landed 1904 buildings. These are the exact checked public `6a61ab6e` repairs. Renderer assets, positions, tolerances and frame ceilings are unchanged by those repairs.

Validation:

- Native 202-step resolution, seven-step second pass and one 57-step fixed-point lap passed, followed by package tail and publish. All 5,347 protected inputs stayed exact. All 44 XLSX/gzip artifacts were audited; three gzip files and two workbooks were restored to exact incoming bytes after whole-content equality, excluding only workbook modification timestamps. All 5,454 incoming source/generator/asset paths remain byte-exact.
- Actual 390×780 and 1280×800 normal/By Grade views, pointed tops, source credits/Lib, grounding, budgets and nine-step gateway paths were reviewed earlier. Captures used `9f7`; the selected jail master/web, fence JSON/renderer and sidecar remain byte-identical in the current published mirror. The separate coarse planner mismatch and readiness retry remain qualified. These are selected-shape evidence, not fresh whole-app performance results.
- All three required preflight questions passed on tree `350334217bdef7a6b27114d34cd20bfc567e5c50`. Actual native whole-check footer: CHECK PASS — 1072 steps, none red.. Committed-head changelog, IDs and native history checks passed on `e81e1d2d2352f152498564eff61d0fdf4c29c7c6`.

All 18 native published smoke groups PASS on this exact head: nine groups per viewport cover parts 1–15, with exact checkout/environment/native-step binding and positive assertion counts, zero failures and zero page errors. The staged summary sums are desktop830/mobile837; common assertions repeat across groups, so these are not unique full-body counts. The hosted gate also passed1072steps/384self-tests with required readers/base, on a synthetic checkout whose entire tree equals this checked head. Report and bake-warrant checks passed.

The automatic moving-frames attempt1 hit its unchanged30-minute job limit after the desktop step passed; it is preserved as CANCELLED. Exactly one retry on the same commit, workflow, caps and assertions passed both native steps, including the moving-frame ceiling gate and32upload-release checks. [Moving retry](https://github.com/kevinrhaas/chicago/actions/runs/40278868761/attempts/2) · [final desktop smoke group](https://github.com/kevinrhaas/chicago/actions/runs/40279159057).

The PR stays draft for the final fresh-head/base readiness decision. T-2380 remains an unfinished image match; no `matches` verdict or original-ticket closure is claimed. Recovery and preserved failures are in [chicago-evidence](https://github.com/kevinrhaas/chicago-evidence).
