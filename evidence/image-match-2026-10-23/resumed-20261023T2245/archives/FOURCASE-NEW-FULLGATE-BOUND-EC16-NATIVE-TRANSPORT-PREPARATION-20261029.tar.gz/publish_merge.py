"""Exact one-native-merge transport for the authored EC16 repair. Default PLAN ONLY.
Run only after actual new fullgate/postphone/reuse and clean native merge exist.
"""
from pathlib import Path
import os,json,hashlib,importlib.util,argparse,datetime,base64
from urllib.request import Request,urlopen
from urllib.parse import quote
P=argparse.ArgumentParser(description=__doc__)
for n in ['expected-old','head','upstream','gate-proof','post-proof','reuse-proof','qualification-proof','chronological-document','output']:P.add_argument('--'+n,required=True)
P.add_argument('--publish',action='store_true');P.add_argument('--max-total-bytes',type=int,default=64*1024**2);a=P.parse_args();os.sched_setaffinity(0,{1});os.nice(19)
assert a.expected_old=='24e4c333ab94864208141bb85234e33dadde841a'and a.upstream=='ec16b8dd726fa7852ede885ef2d754d55b9b4c59'
spec=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
O=Path(a.output);O.mkdir(exist_ok=False)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def shab(b):return hashlib.sha256(b).hexdigest()
def proof(p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and str(p).startswith('/workspace/');raw=p.read_bytes();return json.loads(raw),raw
before=m.snapshot();save('SOURCE-BEFORE.json',before);assert before['HEAD']==a.head and not before['status'];assert m.git('branch','--show-current').decode().strip()==m.BRANCH
old=m.commit(a.expected_old);up=m.commit(a.upstream);head=m.commit(a.head);assert head['parents']==[a.expected_old,a.upstream]
assert old['tree']=='e6b718e7f7407c6691c5008dd064dcd3108b3b50'and up['tree']=='247ea33b100431aa35c72acb07a43e6db164ba89'
for c in [old,up]:
 r=m.api('git/commits/'+c['sha']);assert r['sha']==c['sha']and r['tree']['sha']==c['tree']and[x['sha']for x in r['parents']]==c['parents']
gate,gatebytes=proof(a.gate_proof);post,postbytes=proof(a.post_proof);reuse,reusebytes=proof(a.reuse_proof);qual,qualbytes=proof(a.qualification_proof)
assert gate['status']=='ACTUAL_AUTHORED_CONFLICT_COMPOSITE_CHECK_PASS_SOURCE_UNCHANGED'and gate['exit']==0
required_guards={'HEAD','staged_tree','tracked_working_bytes','no_untracked','no_conflicts','staged_path_sha256','all_children_reaped'}
assert set(gate['guards'])==required_guards and all(v is True for v in gate['guards'].values())
assert gate['binding']['head']==a.expected_old and gate['binding']['checked_final_staged_tree']==head['tree']
assert any('CHECK PASS'in x for x in gate['footer'])
assert post['status']=='ACTUAL_AUTHORED_CONFLICT_FULLCHECK_PUBLISH_PHONE_NATIVE_MERGE_PR_QUESTIONS_PASS'and post['head']==a.head and post['tree']==head['tree']and post['parents']==head['parents']
assert post['full_gate']==a.gate_proof and post['full_gate_exact_tree']is True and post['all_children_reaped']is True and post['source_clean']is True
assert post['phone_limit_MiB']==400 and 0<post['mobile_peak_MiB']<=400
steps={r['name']:r for r in post['steps']};required_steps={'native-current-publish','CURRENT-PHONE-1904','changelog-entry','ticket-ids','fold-history','image-gates'}
assert required_steps<=set(steps)and all(steps[n]['exit']==0 and steps[n]['all_children_reaped']is True for n in required_steps)
phonecmd=steps['CURRENT-PHONE-1904']['command'];assert '--gate'in phonecmd and phonecmd[phonecmd.index('--year')+1]=='1904'and phonecmd[phonecmd.index('--only')+1]=='mobile';phonepath=phonecmd[phonecmd.index('--json')+1];phone,phonebytes=proof(phonepath)
rows=[r for r in phone['rows']if str(r['year'])=='1904'and r['viewport']=='mobile'];assert len(rows)==1 and 0<rows[0]['totals']['total']<=400*1024**2
assert abs(rows[0]['totals']['total']/1024**2-post['mobile_peak_MiB'])<1e-7
assert a.expected_old.startswith(phone['measured']['build']),'Actualnewphone must bind the source HEAD used before the native mergecommit, not an old BE501/f683 measurement'
assert reuse['schema']=='CHICAGO_EARLY_FOUR_COMPOSITE_INPUT_REUSE_V1'and reuse['status']=='ACTUAL_COMPOSITE_EARLY_SOURCE_AND_PUBLISHED_INPUT_REUSE_PASS'
assert reuse['own_checked_head']==a.expected_old and reuse['accepted_upstream']==a.upstream
assert reuse['protected_source_bindings_exact']>=533 and reuse['extra_physical_library_bindings_exact']>=12 and reuse['published_and_selected_native_dated_bindings_exact']>=305
for k in ['all706_log_frame_models_exact','all353_recipes_actual_fresh_at_native_audit','four_native_and_published_sidecar_WEB_camera_grade_photo_STORE_inputs_preserved','all29_early_relevant_liberty_rows_exact_and_native_published_full_output_equal']:assert reuse[k]is True
for k in ['source_native_audit','actual_native_publish_reaper','actual_native_publish_log']:
 r=reuse[k];p=Path(r['path']);assert p.is_file()and not p.is_symlink()and shab(p.read_bytes())==r['sha256']
assert qual['schema']=='CHICAGO_EARLY_FOUR_AUTHORED_EC16_QUALIFICATION_V1'and qual['status']=='ACTUAL_EC16_NATIVE_FULLGATE_POSTPHONE_EARLY_INPUTS_PASS'
b=qual['binding'];assert b['expected_old']==a.expected_old and b['upstream']==a.upstream and b['head']==a.head and b['tree']==head['tree']
assert b['gate_receipt_sha256']==shab(gatebytes)and b['post_receipt_sha256']==shab(postbytes)and b['reuse_receipt_sha256']==shab(reusebytes)
required={'current_fullgate_pass','native204_and_settled_tail_pass','all44_semantically_exact_or_native_derived','native_package5_pass','native_publish_pass','current_phone1904_pass','PR_event_questions_and_four_image_gates_pass','all_children_reaped','source533_nonK_and_3_upstream_K_matches','all706_models_353_rows_and_recipes_fresh','all305_dated_published_inputs_exact','chronological_append_and_next_append_native_test_pass'}
assert set(qual['checks'])==required and all(v is True for v in qual['checks'].values())
assert {'native_consumers','derived44'}<=set(qual['evidence'])
for k,r in qual['evidence'].items():
 p=Path(r['path']);assert p.is_file()and not p.is_symlink()and str(p).startswith('/workspace/')and p.suffix in {'.json','.log','.tsv','.md'}and'profile'not in str(p).lower()and'cert'not in str(p).lower();raw=p.read_bytes();assert len(raw)==r['bytes']and shab(raw)==r['sha256']
oldleaves=m.leaves(old['tree']);cur=m.leaves(head['tree']);upleaves=m.leaves(up['tree'])
protected=[p for p in set(oldleaves)|set(cur)if p.startswith('chicago/4d/generators/archetypes/')or(p.startswith('chicago/4d/renderers/web/')and p!='chicago/4d/renderers/web/js/changelog.js')or any('/'+s+'/'in p or p.endswith('/'+s+'.json')for s in ['miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832'])]
exceptions={'chicago/4d/generators/archetypes/k01_frontage.py','chicago/4d/generators/archetypes/k01_frontage_params.py','chicago/4d/generators/archetypes/k03_brick.py'}
assert len(protected)>=536 and {p for p in protected if oldleaves.get(p)!=cur.get(p)}==exceptions
assert all(cur[p]==upleaves[p]for p in exceptions)and all(oldleaves.get(p)==cur.get(p)for p in protected if p not in exceptions)
extra=['chicago/4d/data/structure_grades.json','chicago/4d/data/enclosures/town_entrance_aprons.json','chicago/4d/data/signage/town_business_signboards.json','chicago/4d/data/yard/town_trade_goods.json','chicago/4d/data/yard/town_woodpiles.json','chicago/4d/data/reconstruction/name_pool_keys.json','chicago/4d/data/reconstruction/1835_placement_policy.json','chicago/4d/tools/memory_ceilings.json',*m.LIBRARY_OUTPUTS]
assert all(oldleaves.get(p)==cur.get(p)for p in extra)
def js(leaves,p):return json.loads(m.obj('blob',leaves[p][2]))
assets=js(oldleaves,'chicago/4d/assets/manifest.json')['assets'];newassets=js(cur,'chicago/4d/assets/manifest.json')['assets'];family={n:r for n,r in assets.items()if r.get('archetype')in {'log_dwelling','frame_dwelling'}};assert len(family)==353
for n,r in family.items():
 assert newassets[n]==r
 for folder in ['gltf','web']:
  p='chicago/4d/assets/'+folder+'/'+n;assert oldleaves[p]==cur[p]
doc=Path(a.chronological_document).read_bytes();assert shab(doc)=='c3ff828ed9bce645e89e4f04da8ac7eb16172f7e791281d210741eccfc1998d8'and b['chronological_document_sha256']==shab(doc)
assert cur['chicago/4d/docs/LIBERTIES.md'][2]==m.gitsha('blob',doc)
changed={p:cur.get(p)for p in sorted(set(oldleaves)|set(cur))if oldleaves.get(p)!=cur.get(p)};assert changed and all(p.startswith('chicago/4d/')and v is not None and v[0]in {'100644','100755'}and v[1]=='blob'for p,v in changed.items())
checked=gate['binding']['all_staged_paths'];assert set(checked)==set(changed),'New native one-merge must change exactly the actual new fullgate-bound staged paths'
for p,v in changed.items():
 raw=(m.SOURCE/p).read_bytes();assert shab(raw)==checked[p]and m.gitsha('blob',raw)==v[2]
known={v[2]for leaves in [oldleaves,upleaves]for v in leaves.values()if v[1]=='blob'};needed={v[2]for v in changed.values()if v[2]not in known};prices={s:{'bytes':len(m.obj('blob',s)),'sha256':shab(m.obj('blob',s))}for s in needed};total=sum(r['bytes']for r in prices.values());assert total<=a.max_total_bytes
assert m.api('git/ref/heads/'+m.BRANCH)['object']['sha']==a.expected_old
freshdev=m.api('git/ref/heads/dev')['object']['sha'];assert freshdev==a.upstream or m.api('compare/'+a.upstream+'...'+freshdev)['status']=='ahead'
plan={'status':'ONE_NATIVE_AUTHORED_EC16_FULLGATE_MERGE_PLANNED_NO_REMOTE_WRITES','expected_old':a.expected_old,'head':a.head,'upstream':a.upstream,'tree':head['tree'],'parents':head['parents'],'new_fullgate_receipt_sha256':shab(gatebytes),'post_receipt_sha256':shab(postbytes),'reuse_receipt_sha256':shab(reusebytes),'qualification_sha256':shab(qualbytes),'actual_phone_MiB':post['mobile_peak_MiB'],'phone_cap_MiB':400,'protected_nonK_exact':len(protected)-3,'reviewed_K_paths_exact_upstream':sorted(exceptions),'all353_rows_706_models_exact':True,'changed_paths':list(changed),'new_blob_bytes':total,'new_blobs':prices,'force':False,'dev_observed_at_plan':freshdev,'behind_newer_dev':freshdev!=a.upstream,'later_dev_tree_qualified_by_this_branch':False,'scope':'Exactbranchcheckpointonly; NEWactualfullgatebindsTHISheadtree. RootmustreadrequiredCI/mergeabilityonfinalexactheadbeforestandarddevmerge. No admin/blind/protectionoverride/mainpromotion.'};save('PLAN.json',plan);assert m.snapshot()==before
if not a.publish:print(json.dumps({'status':plan['status'],'new_blob_bytes':total,'head':a.head}));raise SystemExit(0)
for s in needed:
 raw=m.obj('blob',s);assert len(raw)==prices[s]['bytes']and shab(raw)==prices[s]['sha256'];assert m.api('git/blobs',{'encoding':'base64','content':base64.b64encode(raw).decode()})['sha']==s
tr=m.api('git/trees',{'base_tree':old['tree'],'tree':[{'path':p,'mode':v[0],'type':v[1],'sha':v[2]}for p,v in changed.items()]});assert tr['sha']==head['tree'];created=m.api('git/commits',m.native_payload(head));save('CREATED-NATIVE-MERGE.json',created);assert created['sha']==a.head
assert m.api('git/ref/heads/'+m.BRANCH)['object']['sha']==a.expected_old and m.snapshot()==before
r=m.api('git/refs/heads/'+m.BRANCH,{'sha':a.head,'force':False},'PATCH');assert r['object']['sha']==a.head
public=m.api('git/commits/'+a.head);assert public['tree']['sha']==head['tree']and[p['sha']for p in public['parents']]==head['parents']and m.api('git/ref/heads/'+m.BRANCH)['object']['sha']==a.head
readback=[]
for p,v in changed.items():
 expect=m.obj('blob',v[2])
 with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+a.head+'/'+quote(p,safe='/'),headers={'User-Agent':'Chicago-exact-authored-repair-readback'}),timeout=120)as response:assert response.status==200;raw=response.read()
 assert raw==expect and m.gitsha('blob',raw)==v[2];readback.append({'path':p,'bytes':len(raw),'sha256':shab(raw),'mode':v[0],'git_blob':v[2]})
after=m.snapshot();save('SOURCE-AFTER.json',after);assert after==before
save('RESULT.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ONE_EXACT_NATIVE_AUTHORED_EC16_FULLGATE_MERGE_BRANCH_AND_IMMUTABLE_READBACK_PASS','expected_old':a.expected_old,'head':a.head,'upstream':a.upstream,'tree':head['tree'],'parents':head['parents'],'actual_new_fullgate_tree_bound':True,'actual_phone_MiB':post['mobile_peak_MiB'],'force':False,'native_SHA_preserved':True,'readback':readback,'all_source_HEAD_index_config_status_refs_unchanged':True,'current_CI':'Requiredonthisnewexacthead; rootmergesonlyafteractualgreen/clean. Laterdevifanyisunqualifiedbythisbranchcheckpoint.','PR_merge_performed':False});print(json.dumps({'status':'ONE_EXACT_NATIVE_AUTHORED_EC16_FULLGATE_MERGE_BRANCH_AND_IMMUTABLE_READBACK_PASS','head':a.head}))
