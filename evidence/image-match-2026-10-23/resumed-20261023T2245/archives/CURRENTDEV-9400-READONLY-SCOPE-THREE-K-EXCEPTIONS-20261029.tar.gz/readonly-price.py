from urllib.request import Request,urlopen
from pathlib import Path
import json,datetime,importlib.util,os,time,http.client,concurrent.futures
os.sched_setaffinity(0,{1});os.nice(19)
O=Path('/tmp/current-dev-9400-readonly-price-20261029');O.mkdir(exist_ok=False);base='be501b034cd24410843eedced9e1bf1b52a4ff4f'
def api(p):
 for a in range(4):
  try:
   with urlopen(Request('https://api.github.com/repos/kevinrhaas/chicago/'+p,headers={'User-Agent':'Chicago-bounded-readonly-dev-price','Accept':'application/vnd.github+json'}),timeout=60)as r:return json.load(r)
  except (http.client.IncompleteRead,TimeoutError,ConnectionError):
   if a==3:raise
   time.sleep(1)
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
r=api('git/ref/heads/dev');save('REF.json',r);tip=r['object']['sha']
if tip==base:save('RESULT.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CURRENT_DEV_EXACT_623E_UNCHANGED','base':base,'tip':tip,'no_local_mutation':True});print((O/'RESULT.json').read_text());raise SystemExit(0)
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:
 fut={n:ex.submit(api,p)for n,p in [('COMMIT.json','git/commits/'+tip),('COMPARE.json','compare/'+base+'...'+tip),('TREE.json','git/trees/'+tip+'?recursive=1')]};v={n:f.result()for n,f in fut.items()}
for n,x in v.items():save(n,x)
c=v['COMMIT.json'];comp=v['COMPARE.json'];tree=v['TREE.json'];assert not tree.get('truncated')
spec=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);leaves={x['path']:(x['mode'],x['type'],x['sha'])for x in tree['tree']if x['type']!='tree'};blobs={x['sha']:x for x in tree['tree']if x['type']=='blob'};known=m.indexed(blobs);missing=[dict(r)for s,r in blobs.items()if s not in known]
old={r['path']:(r['mode'],r['type'],r['sha'])for r in json.loads(Path('/tmp/current-dev-be501-readonly-price-20261029/TREE.json').read_text())['tree']if r['type']!='tree'};changed={p:{'old':old.get(p),'new':leaves.get(p)}for p in sorted(set(old)|set(leaves))if old.get(p)!=leaves.get(p)}
protected=[p for p in set(old)|set(leaves)if(p.startswith('chicago/4d/generators/archetypes/')or(p.startswith('chicago/4d/renderers/web/')and p!='chicago/4d/renderers/web/js/changelog.js')or any('/'+s+'/'in p or p.endswith('/'+s+'.json') for s in ['miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832']))]
protected_changes=[p for p in protected if old.get(p)!=leaves.get(p)]
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'READONLY_CURRENT_DEV_ADVANCE_PRICED_NO_IMPORT','base':base,'tip':tip,'tree':c['tree']['sha'],'ahead_by':comp['ahead_by'],'commits':[{'sha':x['sha'],'message':x['commit']['message'].splitlines()[0],'parents':[p['sha']for p in x['parents']]}for x in comp['commits']],'all_leaves':len(leaves),'unique_blob_ids':len(blobs),'missing_blobs':len(missing),'new_blob_bytes':sum(x['size']for x in missing),'changed_paths':changed,'protected_binding_count':len(protected),'protected_binding_changes':protected_changes,'source_HEAD_index_refs_working_unchanged_by_operation':True,'scope':'Read-only finite price/consumeridentity; no object import, cachedref update, source adoption or composite qualification. Actual gatebase remains623e.'};save('MISSING-BLOBS.json',missing);save('RESULT.json',result)
print(json.dumps({k:v for k,v in result.items()if k!='changed_paths'},indent=2));print(json.dumps({'changed_paths':list(changed)},indent=2))
