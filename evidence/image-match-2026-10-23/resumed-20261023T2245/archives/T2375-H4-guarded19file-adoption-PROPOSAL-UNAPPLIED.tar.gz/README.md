T-2375 future adoption composition against public H4 — CLOSED LIGHT PROPOSAL

Exact base: 5d9d44646f49c69a4add36ece56bfbdab8caad70 in
`/tmp/chicago-log-integration`. `bridge-H4-adoption.patch` is one guarded 19-file
composition of the closed bridge geometry/API/native-surface v2 and separate
standing-envelope proposals. It is not applied to a canonical checkout. No live
claim, branch/worktree, export, Blender/browser, producer or full gate was created.
Original T-2375 remains open/differs; no camera, rights or acceptance promotion.

Executable preimages and every underlying geometry/runtime dependency are byte-
exact to the banked proposals. All executable hunks apply without conflict.
Only `docs/LIBERTIES.md` advanced: its complete H4 bytes remain an exact prefix,
then the exact prior two normalized liberty fragments and bounded review caveats
are appended. Four name-pool reader additions preserve independent JSON content.
The generated combined patch was checked, applied and byte-replayed in fresh
minimal temporary H4 file fixtures, then those fixtures were removed. No complete
old file was copied over H4. Exact source preimage SHA256/Git object ids, postimages,
all 6 master/web/recipe/record hashes, input manifests and replay proof are in
`composition-receipt.json`.

H4 body/AABB diagnostics are preserved byte-for-byte and are not patch targets:
`renderers/web/js/buildings.js`, `building-body-bounds.js`, and the unchanged
`tools/smoke_renderer.mjs` assertions. Main/human integration hunks start from H4;
no old full renderer tree is overlaid. New helper comments and contract prose
carry the review qualifications below; executable helper code remains unchanged.

Banked proof, reused without rerunning research/runtime/dense/default tests:

- `/tmp/chicago-next-model/T-2375-adoption-kwonly`: 20 legacy positional parameters,
  defaults/factories/match args unchanged; 4 new fields keyword-only; 6 default raw
  geometry/material/confidence outputs unchanged; source/schema/liberty coverage.
- `/tmp/chicago-next-model/T-2375-native-surface-profile-v2`: native nominal-floor
  sampler/walker/router/exactHeight/anchor/root controls and rigid whole-placement/
  legacy-fallback refusal with transactional stream/state/tone-cache rollback.
  Native CPU yard inventory 1,417 objects/239,593 triangles; 1,418 anchors include one
  non-emitted water-place annotation. Native sidecar scanner positive/negative
  controls remain separate evidence. No real heightfield/canvas/app acceptance.
- `/tmp/T2375-dense-deck-independent-review`: exact same raw digest
  8db45fe611fb6b25d59b9c80808858905ab8a1b201834f216b1dd58668df10d3,
  27,640 vertices/6,846 polygons, all 296 plank-top polygons affine-coherent.
  333,151 mesh probes and 332,969 interior consumer points remain frozen.
- `/tmp/chicago-next-model/T-2375-standing-envelope-followup` and independent
  `/tmp/T2375-standing-envelope-independent-review`: exact verified b479 asset,
  schema-valid real-number analytic engineering refusal bound, radius 3.056324 m;
  current Western horse unaffected, contact/body-only overlap controls refuse
  before parser/clone, no same-revision retry/fallback. No full happy asset/image
  load or actual page/render/GPU acceptance. All five manifests are verified.

Non-negotiable proxy/bound limits in the composed contract:

The profile follows nominal plank tops. It bridges the actual 8 mm sawn-board gaps
and omits 55 mm proud draw-leaf threshold/edge timbers. It is not continuous material
coverage, a maximum-any-mesh height raycast, foot/IK/wheel/whole-body contact, or
real terrain/approach acceptance. Raw no-hit gap samples stay no-hit. Rails,
gallows and chains are not floor; the independent exact counterexamples remain.

The horse's exact-source/schema-valid real-number analytic refusal scope has
independent approval. Its numerical padding remains an engineering allowance,
not a traced universal FP/GPU/world-coordinate certificate. Malformed placement
rows retain preexisting native behavior outside the async catch: missing arrays
may throw in update, nonnumeric coordinates may prevent loading. This composition
does not expand into that unrelated validation issue. Clean-refusal claims apply
to schema-valid placement rows and verified source/spec/header metadata only.

What was actually rendered earlier remains proposal-only: full raised/boarded/
aligned-crib comparison under `/tmp/chicago-next-model/T-2375-next/preview/`, and
an independently rendered boards-only/flat/original-crib option under
`/tmp/chicago-next-model/T-2375/preview/`. Boards-plus-aligned-cribs without rise is
unrendered. The 1.2 m rise is reconstructed, the provisional camera principal point
reaches a bound, and retrospective perspective/mechanism remain uncertain.
Andreas 1884 p.631/L. Braunhold PD artwork correction and liberty fragments are
retained; separate Baker-Co record stays check_required. No borrowed-image texture,
accepted historical mechanism, measured rise or source/scene-date change is added.

Remaining blockers / next canonical sequence (NOT EXECUTED HERE):

1. Root owns ticket/branch/worktree and verifies latest-dev/source freshness before
   hunk adoption. This exact patch is guarded for H4, not automatically later dev.
2. Supported pinned Blender 4.5.3 native bake of all 6 bridge_timber masters, including
   the 5 unchanged defaults because shared recipe inputs changed; then all 6 web
   derivatives/recipes. Current family has zero versions. H4's supported selection:

       tools/bake.sh --only dearborn_street_drawbridge,lasalle_slough_crossing,north_branch_bridge,north_water_slough_crossing,slough_log_bridge,south_branch_raft_bridge

3. Native sidecars/grades/pictures/liberties/entrances and remaining ordered
   producers to fixed point, then supported publisher and full strict preflight.
   Keep default geometry and H4 body/AABB evidence distinct from new output proof.
4. Actual real-terrain/approach and nominal deck/gap/threshold checks; real rigid/
   yard/horse assets, H4 body diagnostic and app/card QA. Run current-policy exact-
   head published smokes at 390×780 and 1280×800, with actual required coverage and
   zero errors. No old receipt is new-head application acceptance.
5. Supported photo_match from the official baked/compiled scene, reviewed source
   cameras and actual image comparisons. All source views must truly match before
   original T-2375 closes; this increment keeps verdicts differs.

`verify.py` only reads public H4 objects and frozen/local manifests and performs
patch applicability/replay in disposable minimal file fixtures. `compose.py`
refuses to overwrite an existing receipt. No heavy/runtime test was repeated
because there was no new executable conflict. Root owns archival to private
chicago-evidence, any canonical adoption and subsequent CPU/browser/bake grants.
