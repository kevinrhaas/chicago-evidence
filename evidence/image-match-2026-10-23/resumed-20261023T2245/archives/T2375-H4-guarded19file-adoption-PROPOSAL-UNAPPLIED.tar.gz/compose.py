"""Hunk-only future composition against exact public H4; no checkout/index writes."""
from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json,re,subprocess,tempfile

OUT=Path(__file__).resolve().parent
REPO=Path('/tmp/chicago-log-integration')
HEAD='5d9d44646f49c69a4add36ece56bfbdab8caad70'
V2=Path('/tmp/chicago-next-model/T-2375-native-surface-profile-v2')
HORSE=Path('/tmp/chicago-next-model/T-2375-standing-envelope-followup')
API=Path('/tmp/chicago-next-model/T-2375-adoption-kwonly')
DENSE=Path('/tmp/T2375-dense-deck-independent-review')
REVIEW=Path('/tmp/T2375-standing-envelope-independent-review')
assert not(OUT/'composition-receipt.json').exists(),'Preserve closed/composed proposal'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def blob(rel):
 result=subprocess.run(['git','-C',str(REPO),'show',HEAD+':'+rel],capture_output=True)
 if result.returncode:
  assert result.returncode==128 and b'does not exist'in result.stderr,(rel,result.stderr)
  return None
 return result.stdout
assert git('rev-parse','HEAD').decode().strip()==HEAD
initial_status=git('status','--porcelain').decode()
inputs={}
for package in [V2,HORSE,API,DENSE,REVIEW]:
 manifest=(package/'MANIFEST.json').read_bytes();doc=json.loads(manifest)
 entries=doc if isinstance(doc,list) else doc['files'];entries={r['path']:r for r in entries}if isinstance(entries,list)else entries
 for rel,row in entries.items():
  raw=(package/rel).read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes'],str(package/rel)
 inputs[str(package/'MANIFEST.json')]={'sha256':sha(manifest),'files_verified':len(entries)}
for p in [V2/'combined-adoption.patch',HORSE/'standing-envelope-overlay.patch',API/'LIBERTIES-APPEND.md',DENSE/'REVIEW.md',DENSE/'dense-mesh-review.json',DENSE/'consumer-review.json',DENSE/'interior-counterexamples.json',REVIEW/'REVIEW.md',REVIEW/'analytic-review.json',REVIEW/'malformed-placement.json']:
 inputs[str(p)]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}

# Unified chunks are applied, never old complete source files copied over H4.
def chunks(text):return [s for s in re.split(r'(?m)(?=^--- (?:a/|/dev/null))',text)if s]
def target(chunk):return re.search(r'^\+\+\+ b/(.+)$',chunk,re.M).group(1)
v2_chunks=chunks((V2/'combined-adoption.patch').read_text())
ledger='chicago/4d/docs/LIBERTIES.md'
without_ledger=''.join(c for c in v2_chunks if target(c)!=ledger)
horse_patch=(HORSE/'standing-envelope-overlay.patch').read_text()
targets=list(dict.fromkeys([target(c)for c in v2_chunks]+[target(c)for c in chunks(horse_patch)]))
preimages={};before={}
for rel in targets:
 raw=blob(rel);before[rel]=raw
 preimages[rel]={'exists':raw is not None,'sha256':sha(raw)if raw is not None else None,'bytes':len(raw)if raw is not None else 0,
  'git_blob_oid':git('rev-parse',HEAD+':'+rel).decode().strip()if raw is not None else None}
vm=json.loads((V2/'preimages.json').read_text());hm=json.loads((HORSE/'preimages.json').read_text());old=json.loads((API/'inputs.json').read_text())
executable_drift=[];all_drift=[]
for rel,old_hash in vm['source_preimages'].items():
 path='chicago/4d/'+rel;raw=blob(path);entry={'path':path,'prior_sha256':old_hash,'H4_sha256':sha(raw)}
 if entry['H4_sha256']!=old_hash:
  all_drift.append(entry)
  if path!=ledger:executable_drift.append(entry)
assert not executable_drift,executable_drift
assert [r['path']for r in all_drift]==[ledger]
# Every underlying runtime/geometry/schema/source dependency remains byte-identical.
deps={}
for rel,expected in {**vm['support_source_sha256'],**hm['source_preimages']}.items():
 path='chicago/4d/'+rel;raw=blob(path);assert sha(raw)==expected,path
 deps[path]={'sha256':sha(raw),'bytes':len(raw),'same_as_banked_dependency':True}
for path,expected in old['preimage_sha256'].items():
 if '/generators/common/'in path or path.endswith('structures.schema.json') or path.endswith('source.schema.json'):
  raw=blob(path);assert sha(raw)==expected,path;deps[path]={'sha256':sha(raw),'bytes':len(raw),'same_as_banked_dependency':True}
for path in ['chicago/4d/generators/blender.pin','chicago/4d/tools/bake.sh','chicago/4d/tools/photo_match.mjs']:
 raw=blob(path);deps[path]={'sha256':sha(raw),'bytes':len(raw),'source_for_future_official_steps_only':True}
protected={}
for rel in ['chicago/4d/renderers/web/js/buildings.js','chicago/4d/renderers/web/js/building-body-bounds.js','chicago/4d/tools/smoke_renderer.mjs']:
 raw=blob(rel);assert rel not in targets;protected[rel]={'sha256':sha(raw),'bytes':len(raw),'git_blob_oid':git('rev-parse',HEAD+':'+rel).decode().strip(),'not_a_patch_target':True}

limits='''\n\n**Surface proxy qualification (integration reading, 2026-10-24):** The profile
follows nominal plank tops. It bridges the resolved8mm sawn-board gaps and omits
55mm proud draw-leaf threshold/edge timbers. It is not a maximum-height raycast
over rails, gallows, chains or all mesh faces, and does not certify foot or rigid-
body contact. The independent dense raw review proves affine plank-top coherence,
not continuous material coverage. The exact-source/schema-valid standing-horse
bound is an engineering refusal envelope; its padding is not a universal
floating-point/GPU/world-coordinate certificate. Original image verdicts remain
`differs`; supported bakes, real terrain/assets/app/browser/native gates remain
unrun for this composed adoption.\n'''
proxy_doc='''\n\n**Nominal plank-top proxy:** For the proposed Dearborn span, the walking profile
bridges8mm sawn-board gaps and omits55mm proud draw-leaf threshold/edge timbers.
It follows positive plank tops, not the continuous/topmost material surface.
Rails, gallows and chains are not floor. This does not certify foot, wheel, IK,
whole-body contact or real-terrain/app/image acceptance. Dense raw-triangle and
consumer evidence remains the separately frozen independent review.\n'''
old_horse_doc='''Standing-horse point contacts remain explicitly refused on the span; its full
skinned/animated envelope remains unqualified and requires a separate review.'''
new_horse_doc='''Standing-horse placement also uses the separately reviewed exact-asset,
schema-valid analytic skin envelope to refuse unsupported-span intersections
before parsing/cloning. This is an engineering refusal bound; its extra numerical
padding is not a traced universal floating-point, GPU or world-coordinate error
certificate. It is not a fitted anatomy/contact hull or full real-asset/browser
acceptance. Clean preparse refusal statements require schema-valid placements:
preexisting malformed-row handling outside the async catch is unchanged.'''
old_deck_comment='/** Point height above the water anchor. Callers retain their own covering/ground policy. */'
new_deck_comment='''/** Nominal plank-top height above the water anchor; covering/ground policy stays
 * with callers. Dearborn proxy bridges8mm board gaps and omits55mm proud leaf
 * thresholds; it is not a topmost-mesh raycast or foot/body contact certificate. */'''
old_numeric_comment='''  // Conservative IEEE binary32 allowance:256 scalar operations per source
  // joint-depth (matrix/quaternion work) plus four influence budgets. Round up
  // to a power of two. Real CPU world matrices are double; this overbounds them.
  // The +1 is the affine homogeneous coordinate, not an extra map exclusion.'''
new_numeric_comment='''  // Engineering binary32 allowance:256 scalar operations per source joint-depth
  // plus four influence budgets, rounded to a power of two. Independent review
  // approves the exact-source real-number analytic bound, not a traced universal
  // floating-point/GPU/world-coordinate error certificate. The +1 is affine w.''' 
with tempfile.TemporaryDirectory(prefix='compose-',dir=OUT)as scratch:
 root=Path(scratch)
 for rel,raw in before.items():
  if raw is not None:
   p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 def apply(text,name):
  patch=root/name;patch.write_text(text)
  check=subprocess.run(['git','apply','--check',str(patch)],cwd=root,capture_output=True,text=True);assert check.returncode==0,check.stderr
  result=subprocess.run(['git','apply',str(patch)],cwd=root,capture_output=True,text=True);assert result.returncode==0,result.stderr
 apply(without_ledger,'v2-no-shared-ledger.patch')
 apply(horse_patch,'horse-overlay.patch')
 # Current H4 ledger is an exact prefix, including its own later append history.
 prefix=before[ledger];addition=(API/'LIBERTIES-APPEND.md').read_bytes()
 assert b'L-dearborn-board-parapet-2375'not in prefix and b'L-dearborn-draw-profile-2375'not in prefix
 (root/ledger).write_bytes(prefix+addition+limits.encode())
 contract=root/'chicago/4d/docs/GLB-CONTRACT.md';text=contract.read_text();assert text.count(old_horse_doc)==1
 contract.write_text(text.replace(old_horse_doc,new_horse_doc)+proxy_doc)
 comment_only=[]
 for rel,prior_comment,new_comment in [('chicago/4d/renderers/web/js/deck-surface.js',old_deck_comment,new_deck_comment),('chicago/4d/renderers/web/js/standing-envelope.js',old_numeric_comment,new_numeric_comment)]:
  p=root/rel;text=p.read_text();assert text.count(prior_comment)==1;after=text.replace(prior_comment,new_comment);p.write_text(after)
  assert after.replace(new_comment,prior_comment)==text
  comment_only.append({'path':rel,'prior_sha256':sha(text.encode()),'composed_sha256':sha(after.encode()),'only_exact_documentation_comment_replacement':True})
 # Apply composition excludes any H4 diagnostic/AABB files by construction.
 assert (root/ledger).read_bytes().startswith(prefix)
 assert (root/ledger).read_bytes()[len(prefix):len(prefix)+len(addition)]==addition
 pool='chicago/4d/data/reconstruction/name_pool_keys.json';a=json.loads(before[pool]);b=json.loads((root/pool).read_text())
 expected={'phases[].form.'+k+'.note'for k in ['railing_kind','draw_profile','draw_rise_m','draw_bearing_supports']}
 assert set(b['read']['structures'])-set(a['read']['structures'])==expected
 b['read']['structures']=[x for x in b['read']['structures']if x not in expected];assert a==b
 patch_parts=[];postimages={}
 for rel in targets:
  after=(root/rel).read_bytes();base=before[rel]or b'';postimages[rel]={'sha256':sha(after),'bytes':len(after)}
  patch_parts.append(''.join(difflib.unified_diff(base.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel if before[rel]is not None else'/dev/null',tofile='b/'+rel)))
 combined=''.join(patch_parts);(OUT/'bridge-H4-adoption.patch').write_text(combined)
 # Check generated exact-H4 patch independently on a fresh minimal H4 fixture.
 for rel,raw in before.items():
  p=root/rel
  if raw is None:p.unlink()
  else:p.write_bytes(raw)
 subprocess.run(['git','apply','--check',str(OUT/'bridge-H4-adoption.patch')],cwd=root,check=True,capture_output=True)
 subprocess.run(['git','apply',str(OUT/'bridge-H4-adoption.patch')],cwd=root,check=True,capture_output=True)
 for rel,row in postimages.items():assert sha((root/rel).read_bytes())==row['sha256']

manifest_path='chicago/4d/assets/manifest.json';master_registry=json.loads(blob(manifest_path))['assets'];family=[]
for row in vm['six_bridge_family']:
 asset=row['asset'];assert master_registry[asset]==row['master_preimage_manifest']
 current={'asset':asset,'record_path':'chicago/4d/data/structures/'+row['structure_id']+'.json','record_sha256':sha(blob('chicago/4d/data/structures/'+row['structure_id']+'.json')),'manifest_recipe':master_registry[asset],'versions':row['versions']}
 assert current['record_sha256']==row['record_sha256']
 for folder,field in [('gltf','master_sha256'),('web','web_sha256')]:
  rel='chicago/4d/assets/'+folder+'/'+asset;current[field]=sha(blob(rel));assert current[field]==row[field]
 family.append(current)
refs=git('ls-tree','-r','--name-only',HEAD,'chicago/4d/data/reference_views/dearborn_street_drawbridge').decode().splitlines()
baker_path='chicago/4d/data/sources/dearborn_street_bridge_1834_engraving.json';baker=json.loads(blob(baker_path));assert baker['rights_status']=='check_required'
receipt={'status':'CLOSED FUTURE H4 COMPOSITION; no canonical adoption or acceptance','prepared_at_UTC':datetime.now(timezone.utc).isoformat(),'public_HEAD':HEAD,'checkout':str(REPO),'patch_targets':targets,'patch_sha256':sha((OUT/'bridge-H4-adoption.patch').read_bytes()),'input_manifests_and_proofs':inputs,
 'preimages':preimages,'postimages':postimages,'underlying_dependencies':deps,'protected_H4_body_diagnostics':protected,'shared_drift':all_drift,
 'composition':'All executable hunks apply without conflict. Only shared ledger drift: exact complete H4 prefix retained; exact prior own liberty fragments appended. Four reader additions preserve independent JSON content. Documentation-only proxy/engineering-bound qualifications added.',
 'comment_only_changes':comment_only,'exact_H4_patch_check_and_replay':True,'new_runtime_or_dense_tests_rerun':False,'reason_no_rerun':'No executable/source/common/default-family conflict. Frozen geometry/API/native/dense/independent envelope evidence reused with H4 dependency byte guards.',
 'six_bridge_family_H4':family,'six_family_official_refresh_required':True,'family_versions_count':0,'current_BakerCo_hold':{'path':baker_path,'sha256':sha(blob(baker_path)),'rights_status':baker['rights_status']},'canonical_Dearborn_reference_view_paths_H4':refs,
 'proxy_limits':'Nominal plank tops only: bridges actual8mm gaps; omits55mm proud leaf/edge thresholds; no maximum-any-mesh-floor, foot/IK/rigidbody contact or continuous material coverage claim.',
 'horse_bound_scope':'Independent review approves exact-source/schema-valid real-number analytic engineering refusal scope only. Padding is not a traced universal FP/GPU/world-coordinate certificate. Preexisting malformed placement behavior unchanged; clean refusal claims require schema-valid rows.',
 'image_gate':'T2375 remains open/differs; all prior provisional camera-bound/source/mechanism/metric-rise caveats retained; no accepted camera, source phase/date promotion or new rights claim.',
 'next_canonical_steps':['Root-owned claim/worktree and current-dev freshness review before any adoption.','Hunk-apply guarded proposal only after source/preimage check; preserve all current H4 body/AABB diagnostics.','Official pinned Blender supported bake/recipe refresh of all6bridge_timber masters and web derivatives; no versions presently.','Native compiler/sidecar/grades/pictures/liberties/entrances/other ordered derivative fixed point and supported publisher.','Full strict preflight and exact-head published both-viewport smokes per current policy.','Actual real-terrain/approach nominal floor and threshold/gap, rigid/yard/horse, H4 body/AABB and real-asset/app/card QA; supported source-photo comparison/camera work. Original image verdict stays differs until all source views truly match.'],
 'no_canonical_write':True,'no_external_claim_or_mutation':True,'no_browser_Blender_exports_fullgate':True}
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('status','--porcelain').decode()==initial_status
lineage={}
for rel,row in postimages.items():
 if not rel.endswith(('.js','.mjs','.py')):continue
 frozen=next(package/'candidate'/rel for package in [HORSE,V2]if(package/'candidate'/rel).is_file())
 comments={x['path']:x for x in comment_only};tested=comments[rel]['prior_sha256']if rel in comments else row['sha256']
 assert sha(frozen.read_bytes())==tested,rel
 lineage[rel]={'frozen_candidate':str(frozen),'frozen_sha256':tested,'composed_sha256':row['sha256'],'executable_content_unchanged':True,'comment_only_clarification':rel in comments}
receipt['executable_lineage']=lineage
receipt['root_checkout_before_after_status_exact']=True
receipt['root_checkout_status_porcelain']=initial_status
receipt['official_selected_bake_future_only']='tools/bake.sh --only dearborn_street_drawbridge,lasalle_slough_crossing,north_branch_bridge,north_water_slough_crossing,slough_log_bridge,south_branch_raft_bridge'
(OUT/'composition-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS hunk-only H4 composition/replay;19targets, shared ledger append only; no executable conflict or runtime rerun; H4 diagnostics untouched.')
