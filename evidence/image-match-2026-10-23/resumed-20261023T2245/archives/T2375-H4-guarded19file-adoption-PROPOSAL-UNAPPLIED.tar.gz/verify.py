"""Read-only public object/input/patch integrity. No runtime or production gates."""
from pathlib import Path
import hashlib,json,subprocess,tempfile,re,ast
OUT=Path(__file__).resolve().parent;d=json.loads((OUT/'composition-receipt.json').read_text());REPO=Path(d['checkout']);HEAD=d['public_HEAD']
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
assert git('rev-parse','HEAD').decode().strip()==HEAD
before=git('status','--porcelain')
assert sha((OUT/'bridge-H4-adoption.patch').read_bytes())==d['patch_sha256']
for path,row in d['input_manifests_and_proofs'].items():assert sha(Path(path).read_bytes())==row['sha256'],path
for path,row in d['executable_lineage'].items():assert sha(Path(row['frozen_candidate']).read_bytes())==row['frozen_sha256'],path
for path,row in {**d['underlying_dependencies'],**d['protected_H4_body_diagnostics']}.items():assert sha(git('show',HEAD+':'+path))==row['sha256'],path
for path in d['protected_H4_body_diagnostics']:assert path not in d['patch_targets']
for row in d['six_bridge_family_H4']:
 assert sha(git('show',HEAD+':'+row['record_path']))==row['record_sha256']
 for folder,key in [('gltf','master_sha256'),('web','web_sha256')]:assert sha(git('show',HEAD+':chicago/4d/assets/'+folder+'/'+row['asset']))==row[key]
 registry=json.loads(git('show',HEAD+':chicago/4d/assets/manifest.json'))['assets'];assert registry[row['asset']]==row['manifest_recipe']
with tempfile.TemporaryDirectory(prefix='verify-',dir=OUT)as tmp:
 root=Path(tmp)
 for path,row in d['preimages'].items():
  if not row['exists']:continue
  raw=git('show',HEAD+':'+path);assert sha(raw)==row['sha256']
  p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 subprocess.run(['git','apply','--check',str(OUT/'bridge-H4-adoption.patch')],cwd=root,check=True,capture_output=True)
 subprocess.run(['git','apply',str(OUT/'bridge-H4-adoption.patch')],cwd=root,check=True,capture_output=True)
 for path,row in d['postimages'].items():assert sha((root/path).read_bytes())==row['sha256'],path
for p in OUT.glob('*.py'):ast.parse(p.read_text(),str(p))
assert git('status','--porcelain')==before
if(OUT/'MANIFEST.json').exists():
 entries=json.loads((OUT/'MANIFEST.json').read_text())['files'];actual={str(p.relative_to(OUT))for p in OUT.rglob('*')if p.is_file()and p.name!='MANIFEST.json'};assert actual==set(entries)
 for rel,row in entries.items():assert sha((OUT/rel).read_bytes())==row['sha256']and(OUT/rel).stat().st_size==row['bytes'],rel
print('PASS H4 preimages/dependencies/frozen-code/family/diagnostic guards and exact patch replay. No runtime, bake, browser, fullgate or acceptance promotion.')
