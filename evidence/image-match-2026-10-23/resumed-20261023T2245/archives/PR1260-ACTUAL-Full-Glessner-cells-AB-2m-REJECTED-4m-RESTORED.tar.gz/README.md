# Closed actual Full Glessner4m/2m A/B: candidate rejected, exact4m restored

The unique authorized2m candidate did not fix the production normal1904 spawn budget. Actual triangles changed4,601,782→4,601,506, saving276 but still exceeding the unchanged4,600,000 cap by1506. Raw drawCalls changed5113→5131; raw rendererCalls stayed321. Candidate acceptance FAIL is preserved, and the exact original4m canonical/published bytes were restored with normal publish and readonly mirror checks both exit0. No alternative cell size or geometry/quality/budget change was tried.

Root's integrated latestdev60 source was based on HEAD460622123de7ec66c22c0d080309664ede498f50 with the resolved incoming Wheeler merge still uncommitted. The parent froze its prior baseline packet at `/workspace/T3081-dev60-bounded-native05-closed`, manifest prefixac8401. BASELINE-BINDINGS.json pins the relevant source, sidecar, assets, manifests and published mirror, including the real latest Wheeler webSHA38bb9347… . This is not a claim that HEAD alone contains those incoming assets.

The exact frozen proposal manifest8e405c7dd4e5e147e28d9b57fbe23ead517da135d8aa1ca0084e60b06202be35 and its six verified files are retained under proposal/. The existing Full opaque Glessner fallback was the only canonical edit: horizontalcellM4→2, heightM2 unchanged. Candidate codeSHA522571b7ef3a8e658dc7d917b1210bd350a42c93cd02e722f5122e5e15c7d80a; original/restoredSHA94a263119cef75295e22d7804d77772b26806142dcf7fd87ffdcdf7379bdc682. Canonical one-field diff and original bytes are included. Light/Balanced's explicit spatialCells, transparent roof order, source assets, detail/quality/caps, geometry and source/reference cameras were untouched.

## Actual native results

All rows use raw app.stats fields and the same normal desktop Full1280×800/DPR1 renderer. Supplemental poses reuse existing QA/native fly controls after the measured normal spawn. The normalspawn street excursions/picks are the native stage14 sequence; this is not the whole stage14 smoke.

|View|4m raw drawCalls/rendererCalls/triangles|2m raw drawCalls/rendererCalls/triangles|Triangle delta|Budget verdict4m→2m|
|---|---:|---:|---:|---|
|Normal spawn|5113 /321 /4,601,782|5131 /321 /4,601,506|−276|FAIL→FAIL|
|North/service|7179 /318 /3,864,020|7273 /318 /3,846,813|−17,207|PASS→PASS|
|Courtyard|4449 /504 /4,981,514|4575 /504 /4,952,042|−29,472|FAIL→FAIL|
|Roofline|5443 /316 /4,644,199|5457 /316 /4,628,101|−16,098|FAIL→FAIL|
|Aloft|4160 /428 /5,274,189|4160 /428 /5,274,189|0|FAIL→FAIL|

All raw drawCalls are below7800. Three supplemental views already exceed the triangle cap in the original4m baseline; those remain failed-budget observations, never passed QA stands. The candidate creates no new supplemental budget failure and does not worsen their existing triangle overruns, but it fails its required original spawn objective and is rejected.

COMPARISON.json reports42/43 checks pass; the required candidate spawn-budget assertion is the failure. Four paired supplemental runs preserve exact full structure bounds (including confidence/body readback), Glessner feet/placement matrices, camera/projection/near, pixel ratio/buffer, shadow state, transparent roof census, and complete Glessner geometry1,385,233triangles. Opaque partition instances increase: total3011→5722, with the same3transparent roof instances. Source/mirror/assets rebinding and actual loaded Kimball HTTP-bodySHA pass. Glessner source/mirrorSHA and actual native resourceURL/census are bound separately; its whole HTTP body was not independently copied by this probe.

Both closed actual probes have no page, HTTP, unexpected-request or cleanup errors. Each retains one raw people.json ERR_ABORTED, explicitly classified by the existing native smoke policy in this NEW probe. The earlier strict abort failure remains separate unchanged evidence. All eight completed stand observer reconciliations are exact under the documented native reset/pick accounting. METHOD.md explains the three preserved observer failures and corrections; no failed attempt is erased and no app counter/cap is changed.

End-to-spawn elapsed was146.578s baseline versus141.653s candidate. These are single software-renderer runs including welcome/navigation/native picks, not an isolated boot benchmark or hardware speedup. Stand submitMs is single JS submission timing and is retained raw; no FPS, GPU or real-device performance claim follows.

## Direct visual inspection

All five paired normal PNGs were directly inspected. No lost visible house, openings, masonry, staircase, courtyard tower, roof ridge/planes, chimneys or changed shadow shape was detected. Source geometry/roof census and full bounds are exact, providing evidence beyond those views. Original native trees and foliage remain: the north/service tree covers part of the facade, the roofline view is substantially obscured, and the aloft house sits near the lower edge. Offscreen/occluded surfaces are not visually certified. Native HUD/font/target timing differs and raw pixels are not equal; PIXEL-COMPARISON.json retains nonzero pixel counts rather than claiming identity. No source-image match, reference-camera acceptance, source-rights update or ticket completion is claimed.

## Durable execution and restoration

BASELINE-ORCHESTRATION.json preserves the first native unchanged spawn measurement. baseline-controls, baseline-controls-v2 and baseline-controls-v3 retain their failed external observer attempts. baseline-controls-v4/STATUS.json and candidate/STATUS.json are the complete authoritative paired measurements and raw screenshots. CONTINUATION.json and CANDIDATE-ORCHESTRATION.json retain process IDs, commands, exits and normal publish/check logs. The candidate orchestration ends `REJECTED_2M_EXACT4M_RESTORED`, exit1, recording failed acceptance and successful exact restoration. Every browser/server/orchestrator PID was stopped before CLEAR to root. The restored code/mirror hashes were verified equal94a263…; root then regained the heavy slot. No additional browser/native/fullgate work was run here.

To reproduce, restore the bound integrated baseline and current manifests/assets from root's checkpoint, verify all hashes, use the included probe/helper with its original absolute paths or a reviewed external staging copy, and obtain the normal exclusive heavy slot. The preserved original proposal CPU fixtures are synthetic kernel controls only; copy them before rerunning because their script writes CPU-CONTROLS.json. `compare-v2.py` adds explicit no-new/worsened supplemental cost checks while retaining all native raw verdicts. The earlier bound compare.py remains verbatim. All main full-preflight/remote smoke acceptance and any new candidate require root coordination.
