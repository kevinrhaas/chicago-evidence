from pathlib import Path
import os,subprocess,json,datetime,hashlib,sys
R=Path('/workspace/PR1260-cells-ab-20261024');A=Path('/tmp/chicago-log-integration/chicago/4d');S=R/'BASELINE-ORCHESTRATION.json';P=Path('/tmp/PR1260-full-glessner-cells-proposal-school-20261024');r={'status':'RUNNING','pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':[]}
if S.exists():raise SystemExit('Existing status refused')
env=os.environ.copy();env['TMPDIR']='/workspace/tmp-t3081';env['PW_EXECUTABLE']='/usr/bin/chromium';env['PATH']='/workspace/shared/tools/usr/bin:'+env.get('PATH','')
def save():S.write_text(json.dumps(r,indent=2)+'\n')
def stage(name,cmd):
 row={'stage':name,'command':cmd,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};r['stages'].append(row);save()
 with (R/(name+'.log')).open('w') as f:
  p=subprocess.Popen(cmd,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();rc=p.wait()
 row['exit_code']=rc;row['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 if rc:raise RuntimeError(name+' exited '+str(rc))
try:
 assert hashlib.sha256((P/'MANIFEST.json').read_bytes()).hexdigest()=='8e405c7dd4e5e147e28d9b57fbe23ead517da135d8aa1ca0084e60b06202be35'
 g=json.loads((P/'SOURCE-BINDINGS.json').read_text());assert hashlib.sha256((A/'renderers/web/js/buildings.js').read_bytes()).hexdigest()==g['before_buildings_sha256']
 r['guard']='PASS_UNCHANGED_4M';r['head']=subprocess.check_output(['git','-C',str(A),'rev-parse','HEAD'],text=True).strip();r['git_status_before']=subprocess.check_output(['git','-C',str(A),'status','--porcelain'],text=True);save()
 stage('readonly-mirror',['node','tools/check_published.mjs'])
 stage('baseline',['node','/tmp/PR1260-cells-ab-20261024/probe.mjs','--out',str(R/'baseline'),'--execute'])
 r['status']='BASELINE_CAPTURED_NOT_BUDGET_ACCEPTANCE';r['exit_code']=0
except BaseException as e:r['status']='FAIL_STOPPED';r['error']=str(e);r['exit_code']=1
finally:r['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(r));sys.exit(r['exit_code'])
