from pathlib import Path
import os,subprocess,json,datetime,hashlib,sys
R=Path('/workspace/PR1260-cells-ab-20261024');A=Path('/tmp/chicago-log-integration/chicago/4d');S=R/'CANDIDATE-ORCHESTRATION.json';P=Path('/tmp/PR1260-full-glessner-cells-proposal-school-20261024');r={'status':'RUNNING','pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':[]}
if S.exists():raise SystemExit('Existing status refused')
env=os.environ.copy();env['TMPDIR']='/workspace/tmp-t3081';env['PW_EXECUTABLE']='/usr/bin/chromium';env['PATH']='/workspace/shared/tools/usr/bin:'+env.get('PATH','')
def save():S.write_text(json.dumps(r,indent=2)+'\n')
def stage(name,cmd):
 row={'stage':name,'command':cmd,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};r['stages'].append(row);save()
 with (R/(name+'.log')).open('w') as f:
  p=subprocess.Popen(cmd,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();rc=p.wait()
 row['exit_code']=rc;row['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 if rc:raise RuntimeError(name+' exited '+str(rc))
try:
 assert hashlib.sha256((P/'MANIFEST.json').read_bytes()).hexdigest()=='8e405c7dd4e5e147e28d9b57fbe23ead517da135d8aa1ca0084e60b06202be35'
 g=json.loads((P/'SOURCE-BINDINGS.json').read_text());assert hashlib.sha256((A/'renderers/web/js/buildings.js').read_bytes()).hexdigest()==g['before_buildings_sha256']
 baseline=json.loads((R/'baseline-controls-v4/STATUS.json').read_text());assert baseline.get('exit_code')==0 and len(baseline.get('stands',[]))==4
 assert baseline['measurement']['stats']['triangles']==4601782 and not baseline['measurement']['stats']['withinBudget']
 for f in json.loads((P/'MANIFEST.json').read_text())['files']:assert hashlib.sha256((P/f['path']).read_bytes()).hexdigest()==f['sha256']
 baselineBindings=json.loads((R/'BASELINE-BINDINGS.json').read_text())
 for f in baselineBindings['files']:assert hashlib.sha256((A/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
 for f in g['source_files']:assert hashlib.sha256((A/f).read_bytes()).hexdigest()==g['source_files'][f]['sha256'],f
 target=A/'renderers/web/js/buildings.js';before=target.read_bytes();(R/'buildings-before4m.js').write_bytes(before)
 old=b"&& !material.transparent ? { cellM: 4, heightM: 2 } : null);";new=old.replace(b'cellM: 4',b'cellM: 2');assert before.count(old)==1
 after=before.replace(old,new);assert hashlib.sha256(after).hexdigest()==g['candidate_buildings_sha256'];target.write_bytes(after)
 r['guard']='PASS_EXACT_ONE_FIELD_4_TO_2';r['canonical_candidate_applied']=True;r['head']=subprocess.check_output(['git','-C',str(A),'rev-parse','HEAD'],text=True).strip();save()
 (R/'candidate-canonical.diff').write_bytes(subprocess.check_output(['git','-C',str(A),'diff','--','renderers/web/js/buildings.js']))
 stage('candidate-publish',['bash','tools/publish.sh'])
 stage('candidate-readonly-mirror',['node','tools/check_published.mjs'])
 binding={'status':'CANDIDATE_ONE_FIELD_SOURCE_MIRROR_BOUND','files':[],'published':[]}
 for f in baselineBindings['files']:
  q=A/f['path'];h=hashlib.sha256(q.read_bytes()).hexdigest();expected=g['candidate_buildings_sha256'] if f['path']=='renderers/web/js/buildings.js' else f['sha256'];assert h==expected,f['path'];binding['files'].append({'path':f['path'],'bytes':q.stat().st_size,'sha256':h})
 mirror=A.parent.parent/'site/4d'
 for f in baselineBindings['published']:
  q=mirror/f['path'];h=hashlib.sha256(q.read_bytes()).hexdigest()
  if f['path']!='build.json':assert h==(g['candidate_buildings_sha256'] if f['path']=='walk/js/buildings.js' else f['sha256']),f['path']
  binding['published'].append({'path':f['path'],'bytes':q.stat().st_size,'sha256':h})
 (R/'CANDIDATE-BINDINGS.json').write_text(json.dumps(binding,indent=2)+'\n')
 stage('candidate',['node','/tmp/PR1260-cells-ab-20261024/probe.mjs','--out',str(R/'candidate'),'--execute'])
 actual=json.loads((R/'candidate/STATUS.json').read_text());r['actual_budget_pass']=actual['measurement']['stats']['withinBudget'];save()
 if not r['actual_budget_pass']:raise RuntimeError('Actual2m normal spawn failed unchanged budget; rejected and restore required')
 r['status']='CANDIDATE_CAPTURED_PENDING_VISUAL_INVARIANT_ACCEPTANCE';r['exit_code']=0
except BaseException as e:
 r['status']='FAIL_STOPPED';r['error']=str(e);r['exit_code']=1;save()
 if r.get('canonical_candidate_applied'):
  try:
   assert hashlib.sha256(target.read_bytes()).hexdigest()==g['candidate_buildings_sha256'],'Refuse reverting unexpected canonical edits'
   assert hashlib.sha256(before).hexdigest()==g['before_buildings_sha256']
   target.write_bytes(before);r['canonical_reverted_to_exact4m']=True;save()
   stage('revert-publish',['bash','tools/publish.sh']);stage('revert-readonly-mirror',['node','tools/check_published.mjs'])
   r['status']='REJECTED_2M_EXACT4M_RESTORED'
  except BaseException as restore:r['restore_error']=str(restore)

finally:r['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(r));sys.exit(r['exit_code'])
