from pathlib import Path
import json,time,os,subprocess,datetime
R=Path('/workspace/PR1260-cells-ab-20261024');p=R/'CONTINUATION.json';r={'status':'WAITING_FOR_BASELINE_V4','pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save():p.write_text(json.dumps(r,indent=2)+'\n')
save()
while True:
 try:b=json.loads((R/'baseline-controls-v4/STATUS.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):time.sleep(2);continue
 if 'exit_code' in b:break
 time.sleep(2)
if b['exit_code']!=0:r.update(status='STOPPED_BASELINE_FAILURE',exit_code=1)
else:
 r.update(status='BASELINE_CLOSED_LAUNCHING_AUTHORIZED_CANDIDATE');save()
 with (R/'candidate-orchestrate.log').open('w') as log:
  q=subprocess.Popen(['python3',str(R/'candidate-orchestrate.py')],stdout=log,stderr=subprocess.STDOUT);r['candidate_orchestrator_pid']=q.pid;save();rc=q.wait()
 r.update(status='CANDIDATE_ORCHESTRATION_FINISHED',exit_code=rc)
r['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
