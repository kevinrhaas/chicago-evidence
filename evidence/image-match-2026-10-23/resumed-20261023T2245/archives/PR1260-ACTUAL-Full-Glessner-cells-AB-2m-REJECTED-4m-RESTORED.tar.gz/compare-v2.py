from pathlib import Path
import json,datetime
R=Path('/workspace/PR1260-cells-ab-20261024');a=json.loads((R/'baseline-controls-v4/STATUS.json').read_text());b=json.loads((R/'candidate/STATUS.json').read_text());checks=[];rows=[]
def check(name,value):checks.append({'check':name,'pass':bool(value)})
check('both probes completed exit0',a.get('exit_code')==b.get('exit_code')==0)
check('both have four existing stands',len(a.get('stands',[]))==len(b.get('stands',[]))==4)
check('source/stage/input binding unchanged',all(a[k]==b[k] for k in ['source_stage','smoke_source_sha256','spawn_input_hashes','expected_web_sha256','master_sha256','stand_helper_sha256']))
check('spawn pose/tier/camera/front picks exact',all(a['measurement'][k]==b['measurement'][k] for k in ['detail','home','at','spawn','projected_front','glessner_front_hits','camera','raw_problems']))
check('spawn budget exact',a['measurement']['stats']['budget']==b['measurement']['stats']['budget'])
check('actual candidate normal spawn budget passes',b['measurement']['stats']['withinBudget'])
check('no unexpected actual errors',all(not r.get('page_errors') and not r.get('http_errors') and not r.get('native_unexpected_requests') and not r.get('cleanup_errors') for r in [a,b]))
def row(name,x,y):
 return {'name':name,'baseline4m':{k:x[k] for k in ['drawCalls','rendererCalls','triangles','withinBudget']},'candidate2m':{k:y[k] for k in ['drawCalls','rendererCalls','triangles','withinBudget']},'delta2_minus4':{k:y[k]-x[k] for k in ['drawCalls','rendererCalls','triangles']}}
rows.append(row('normal-spawn',a['measurement']['stats'],b['measurement']['stats']))
for x,y in zip(a.get('stands',[]),b.get('stands',[])):
 n=x['name'];check(n+' same existing plan',x['plan']==y['plan'] and n==y['name']);check(n+' unchanged physical bounds/feet/matrix',all(x[k]==y[k] for k in ['allBounds','glessnerFeet','glessnerMatrix']))
 check(n+' unchanged camera/quality/buffer/shadow state',all(x[k]==y[k] for k in ['detail','camera','pixelRatio','buffer','shadow']))
 check(n+' unchanged total Glessner source triangles',x['glessnerTotalTriangles']==y['glessnerTotalTriangles'])
 tx=[r for r in x['glessnerCensus'] if r['transparent']];ty=[r for r in y['glessnerCensus'] if r['transparent']];check(n+' unchanged transparent roof census',tx==ty)
 check(n+' exact native frame counter reconciliation',x['profile']['reconciled'] and y['profile']['reconciled'])
 check(n+' no raw loader problems',not x['problems'] and not y['problems'])
 for k in ['drawCalls','triangles']:
  cap=x['stats']['budget'][k];check(n+' no new or worsened '+k+' budget failure',y['stats'][k]<=cap or (x['stats'][k]>cap and y['stats'][k]<=x['stats'][k]))
 rows.append(row(n,x['stats'],y['stats']))
r={'status':'SPAWN_AND_INVARIANTS_PASS_PENDING_VISUAL_REVIEW_SUPPLEMENTAL_BUDGETS_RETAINED' if all(c['pass'] for c in checks) else 'FAIL_INVARIANT_OR_SPAWN_BUDGET','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'counts':rows,'limits':'Normal browser experiment only; no fullstage14 acceptance, no hardware frame-pacing claim. Raw api.stats fields retained; per-stand budget may be preexisting different from initial spawn. Visual review still owed.'};(R/'COMPARISON.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
