from pathlib import Path
import ast,sys,json,math,dataclasses,importlib.util,hashlib
sys.dont_write_bytecode=True
root=Path('/workspace/chicago/chicago/4d');out=Path('/tmp/hogan-finite-review-20261029');base=out/'base/chicago/4d';candidate=out/'candidate/chicago/4d'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=module('hogan_old_params',base/'generators/archetypes/log_dwelling_params.py');new=module('hogan_new_params',candidate/'generators/archetypes/log_dwelling_params.py')
class Capture:
 def __init__(self):self.polys=[];self.boxes=[]
 def add_poly(self,*a,**kw):self.polys.append((tuple(a),kw))
 def add_box(self,*a,**kw):self.boxes.append((tuple(a),kw))
tree=ast.parse((root/'generators/common/mesh.py').read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MeshBuilder');fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='add_gable_roof');env={'math':math};exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'native-add-gable-roof','exec'),env);Capture.add_gable_roof=env['add_gable_roof']
def functions(path,pm):
 names={'_roof','_hip_end_roof','_shed_roof','_log_course_gable','_horizontal_end_courses','_ridge_stack'}
 nodes=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]+[n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names]
 env={'math':math,'resolved_core_ridge_axis':pm.resolved_core_ridge_axis,'M_ROOF':2,'M_LOG':0,'M_CHINK':1,'M_FRAME':3,'RELIEF_M':.028,'_STACK_HALF':.48}
 exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(path),'exec'),env);return env
of=functions(base/'generators/archetypes/log_dwelling.py',old);nf=functions(candidate/'generators/archetypes/log_dwelling.py',new)
def roof(env,pm,p):
 b=Capture();z=env['_roof'](b,p,*pm.core_extent(p),p.wall_height_m,p.conf('roof_type','inferred'));return b,z
def ridge(env,pm,p,z):
 b=Capture()
 for f in p.chimney_ridge_at or ():env['_ridge_stack'](b,p,*pm.core_extent(p),z,f,p.conf('chimneys','inferred'),6)
 return b
compared=[]
for file,entry in json.loads((root/'assets/manifest.json').read_text())['assets'].items():
 if entry.get('archetype')!='log_dwelling':continue
 rec=json.loads((root/'data/structures'/f"{entry['structure_id']}.json").read_text());ph=next(p for p in rec['phases'] if p['id']==entry['phase_id'])
 a=old.from_phase(ph,rec);b=new.from_phase(ph,rec)
 bd=dataclasses.asdict(b);bd.pop('end_gable_courses');bd.pop('ridge_stack_cap_m');assert bd==dataclasses.asdict(a),file
 ar,az=roof(of,old,a);br,bz=roof(nf,new,b);assert az==bz and ar.polys==br.polys,file
 assert ridge(of,old,a,az).boxes==ridge(nf,new,b,bz).boxes,file
 compared.append(file)
r=json.loads((candidate/'data/structures/hogan_store.json').read_text());p=new.from_phase(r['phases'][0],r);b,z=roof(nf,new,p);before,beforez=roof(of,old,old.from_phase(json.loads((base/'data/structures/hogan_store.json').read_text())['phases'][0]))
assert z==beforez and b.polys[:3]==before.polys[:3]
assert len(b.polys)>4 and all(poly[0][2]==3 for poly in b.polys[3:])
stack=ridge(nf,new,p,z);assert len(stack.boxes)==2
shaft,cap=stack.boxes;assert shaft[0][5]==cap[0][2] and cap[0][5]==z+.75
assert math.isclose(cap[0][3]-cap[0][0],.85) and math.isclose(cap[0][5]-cap[0][2],.12)
assert cap[0][6]==1.0 and shaft[1]['skip']==('bottom','top')
invalid=[{'end_gable_courses':'-x'},{'end_gable_courses':'+y'},{'roof_ridge_axis':'y'},{'front_gable_cladding':'log_courses'},{'ridge_stack_cap_m':(True,.12)},{'ridge_stack_cap_m':(.1,float('nan'))},{'ridge_stack_cap_m':(.1,)},{'ridge_stack_cap_m':(.8,.12)},{'ridge_stack_cap_m':(.1,.01)},{'chimney_ridge_at':None},{'chimney_ridge_at':(.2,.8),'chimneys':2}]
for change in invalid:
 try:dataclasses.replace(p,**change).validate()
 except new.ParamError:pass
 else:raise AssertionError(change)
for rel in ['generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py']:
 compile((candidate/rel).read_text(),rel,'exec');assert (base/rel).read_bytes()==(root/rel).read_bytes()
result={'status':'PASS','scope':'Pure native parameter resolution and actual roof/ridge producer function capture. No full builder, GLB, camera, Blender, native production or acceptance claim.','default_params_and_actual_roof_ridge_outputs_exact':len(compared),'rows':compared,'Hogan_ridge_roof_envelope_and_two_slopes_hidden_cap_exact':True,'Hogan_visible_end_course_surface_only':True,'Hogan_cap_top_preserves_head_height':True,'Hogan_cap_shaft_no_coplanar_top_overlap':True,'invalid_or_incompatible_optins_refused':len(invalid),'new_attributes_declared_CONSUMED':all(x in new.CONSUMED for x in ['end_gable_courses','ridge_stack_cap_m']),'source_producer_preimages_still_exact':True}
(out/'CANDIDATE-PURE-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
