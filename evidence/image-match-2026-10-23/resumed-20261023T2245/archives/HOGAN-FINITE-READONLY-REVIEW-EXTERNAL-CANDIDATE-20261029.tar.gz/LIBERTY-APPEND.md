
## L-hogan-gable-courses-cap-2377 — pictured end courses and stack cap

**Covers:** `hogan_store`, phase `log_1831`, `end_gable_courses` and `ridge_stack_cap_m` only.

**Decision:** Cameron's retrospective picture visibly has horizontal courses across the exposed gable and a projecting dark top on its short ridge stack. Those two depicted occurrences guide this reconstruction. The +X end assignment follows the existing diagnostic view; it is not a documented compass bearing. The 0.20 m course rhythm, 8 mm horizontal joints, 12 mm relief, neutral timber treatment and all unseen joinery are reconstructed first fits. The picture does not establish log versus board gable fabric. The cap projects 0.10 m from each shaft face and is 0.12 m thick, chosen as a first visible profile fit rather than a historic measurement; unseen depth and masonry/color remain reconstructed. Its top stays at the existing 0.75 m head height. No roof envelope, footprint, position, doorway/hatch, stack count or ridge station changes. A provisional drawing camera supplies neither independent metric scale nor a surveyed historic camera.

**Source:** `cameron_c1900_first_post_office`, local held image caption crediting Edgar S. Cameron and the Chicago Historical Society; existing source rights/attribution and circa-1900/publication uncertainty remain unchanged. This does not attest survival or use on 1 July 1835.

**Recorded:** 2026-10-29.

**Ticket:** T-2377, the original image-match case. No new photo follow-up.
