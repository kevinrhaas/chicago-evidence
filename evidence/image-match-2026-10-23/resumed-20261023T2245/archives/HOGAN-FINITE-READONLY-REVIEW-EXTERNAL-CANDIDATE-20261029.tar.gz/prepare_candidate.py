import pathlib,json,hashlib,difflib
ROOT=pathlib.Path('/workspace/chicago/chicago/4d');OUT=pathlib.Path('/tmp/hogan-finite-review-20261029')
paths=['generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py','data/structures/hogan_store.json']
def replace(s,a,b):
 assert s.count(a)==1,(a,s.count(a))
 return s.replace(a,b)
for p in paths:
 dest=OUT/'candidate'/'chicago/4d'/p;dest.parent.mkdir(parents=True,exist_ok=True)
 base=OUT/'base'/'chicago/4d'/p;base.parent.mkdir(parents=True,exist_ok=True)
 base.write_bytes((ROOT/p).read_bytes());dest.write_bytes(base.read_bytes())
p=OUT/'candidate/chicago/4d/generators/archetypes/log_dwelling_params.py';s=p.read_text()
s=replace(s,'"roof_ridge_axis", "front_gable_cladding",','"roof_ridge_axis", "front_gable_cladding", "end_gable_courses",')
s=replace(s,'"ridge_stack_w_m", "ridge_stack_head_m", "hip_end",','"ridge_stack_w_m", "ridge_stack_head_m", "ridge_stack_cap_m", "hip_end",')
s=replace(s,'    front_gable_cladding: str | None = field(default=None, kw_only=True)\n','    front_gable_cladding: str | None = field(default=None, kw_only=True)\n    # Pictured horizontal courses on the +X gable only; None leaves legacy caps.\n    end_gable_courses: str | None = field(default=None, kw_only=True)\n')
s=replace(s,'    ridge_stack_head_m: float | None = None\n','    ridge_stack_head_m: float | None = None\n    # (projection beyond each shaft face, thickness), reconstructed metres.\n    ridge_stack_cap_m: tuple | None = field(default=None, kw_only=True)\n')
a='    def validate(self) -> None:\n';b=a+'''        if self.end_gable_courses not in (None, "+x"):
            raise ParamError("end_gable_courses is None or +x")
        if self.end_gable_courses is not None:
            if (self.roof_type != "gable" or self.hip_end is not None or
                    self.compound_parts or self.frame_addition or self.loft or
                    self.front_gable_cladding is not None or
                    resolved_core_ridge_axis(self) != "x"):
                raise ParamError("end gable courses require a simple +X gable without hip, compound, frame addition or loft")
        if self.ridge_stack_cap_m is not None:
            cap = self.ridge_stack_cap_m
            if (self.chimney_ridge_at is None or self.compound_parts or
                    len(self.chimney_ridge_at) != 1 or not isinstance(cap, (tuple, list)) or
                    len(cap) != 2 or any(isinstance(v, bool) or not isinstance(v, (int, float)) or
                                         not math.isfinite(v) for v in cap)):
                raise ParamError("ridge_stack_cap_m needs one simple ridge stack and two finite dimensions")
            if not (0.02 <= cap[0] <= 0.20 and 0.04 <= cap[1] <= 0.25):
                raise ParamError("ridge_stack_cap_m needs 0.02..0.20m projection and 0.04..0.25m thickness")
'''
s=replace(s,a,b)
s=replace(s,'        front_gable_cladding=val("front_gable_cladding"),\n','        front_gable_cladding=val("front_gable_cladding"),\n        end_gable_courses=val("end_gable_courses"),\n')
s=replace(s,'        hip_end=(None if val("hip_end") is None else str(val("hip_end"))),\n','        ridge_stack_cap_m=(None if val("ridge_stack_cap_m") is None\n                           else tuple(val("ridge_stack_cap_m"))),\n        hip_end=(None if val("hip_end") is None else str(val("hip_end"))),\n')
p.write_text(s)
p=OUT/'candidate/chicago/4d/generators/archetypes/log_dwelling.py';s=p.read_text()
a='    if p.front_gable_cladding == "log_courses":\n';b='''    if p.end_gable_courses == "+x":
        # Same two slopes and hidden -X cap as the generic roof. Only the
        # pictured +X triangular finish changes; no ridge/footprint alteration.
        ax0, ay0, ax1, ay1 = x0-.25, y0-.25, x1+.25, y1+.25
        ym = (ay0+ay1)/2
        ridge_z = eave_z + (ay1-ay0)/2*math.tan(math.radians(p.roof_pitch_deg))
        b.add_poly([(ax0,ay0,eave_z),(ax1,ay0,eave_z),
                    (ax1,ym,ridge_z),(ax0,ym,ridge_z)],conf,M_ROOF)
        b.add_poly([(ax1,ay1,eave_z),(ax0,ay1,eave_z),
                    (ax0,ym,ridge_z),(ax1,ym,ridge_z)],conf,M_ROOF)
        b.add_poly([(ax0,ay0,eave_z),(ax0,ym,ridge_z),(ax0,ay1,eave_z)],conf,M_ROOF)
        _horizontal_end_courses(b, ax1, ay0, ay1, eave_z, ridge_z,
                                p.conf("end_gable_courses", "inferred"))
        return ridge_z
'''+a
s=replace(s,a,b)
a='    b.add_box(bx[0], bx[1], ridge_z - run - 0.25, bx[2], bx[3], ridge_z + head, conf, mat,\n              skip=("bottom",))\n'
b='    shaft_top = ridge_z + head - (p.ridge_stack_cap_m[1] if p.ridge_stack_cap_m is not None else 0.)\n    b.add_box(bx[0], bx[1], ridge_z - run - 0.25, bx[2], bx[3], shaft_top, conf, mat,\n              skip=("bottom", "top") if p.ridge_stack_cap_m is not None else ("bottom",))\n'
s=replace(s,a,b)
a='\n\ndef _facade_stack_cross(span: float) -> float:\n';b='''
    if p.ridge_stack_cap_m is not None:
        projection, thickness = p.ridge_stack_cap_m
        # Cap replaces the top band of the shaft: the stated overall head
        # height stays fixed. All unseen section dimensions are reconstructed.
        b.add_box(bx[0]-projection, bx[1]-projection, ridge_z+head-thickness,
                  bx[2]+projection, bx[3]+projection, ridge_z+head,
                  p.conf("ridge_stack_cap_m", "reconstructed"), mat)


def _facade_stack_cross(span: float) -> float:
'''
s=replace(s,a,b)
a='\ndef _log_course_gable(b,axis,plane,u0,u1,z0,z1,outward):\n';b='''
def _horizontal_end_courses(b, x, y0, y1, z0, z1, conf):
    """Pictured horizontal end courses, without asserting log versus board fabric.

    The 200mm rhythm, 8mm shadow joints and 12mm relief are reconstructed first
    fits. The +X surface remains behind the existing framed hatch at x+40mm.
    """
    mid=(y0+y1)/2;half=(y1-y0)/2;rise=z1-z0
    b.add_poly([(x,y0,z0),(x,y1,z0),(x,mid,z1)],conf,M_FRAME)
    course=.20;gap=.008;proud=.012
    for i in range(math.floor(z0/course),math.ceil(z1/course)):
        low=max(z0,i*course);high=min(z1,(i+1)*course-gap)
        if high <= low:
            continue
        lh=half*(1-(low-z0)/rise);hh=half*(1-(high-z0)/rise)
        b.add_poly([(x+proud,mid-lh,low),(x+proud,mid+lh,low),
                    (x+proud,mid+hh,high),(x+proud,mid-hh,high)],1.,M_FRAME)
        # Bottom return gives each horizontal joint geometric relief.
        b.add_poly([(x,mid-lh,low),(x,mid+lh,low),
                    (x+proud,mid+lh,low),(x+proud,mid-lh,low)],1.,M_FRAME)


def _log_course_gable(b,axis,plane,u0,u1,z0,z1,outward):
'''
s=replace(s,a,b);p.write_text(s)
p=OUT/'candidate/chicago/4d/data/structures/hogan_store.json';d=json.loads(p.read_text());f=d['phases'][0]['form']
f['end_gable_courses']={'value':'+x','confidence':'inferred','sources':['cameron_c1900_first_post_office'],'note':"Horizontal courses are visible across Cameron's retrospective gable around its framed rectangle; the local +X assignment follows the existing diagnostic view, not a surveyed compass bearing. This replaces the smooth roof-material triangle only on that visible end. The picture does not resolve log versus board fabric. The generator's 0.20m course rhythm, 8mm joints, 12mm relief and neutral timber treatment are reconstructed first fits, not measured historic fabric. Footprint, roof envelope, hidden end and existing hatch remain unchanged."}
f['ridge_stack_cap_m']={'value':[0.10,0.12],'confidence':'reconstructed','sources':['cameron_c1900_first_post_office'],'note':"Cameron depicts a projecting dark top on the short roof-piercing shaft, supporting the cap's occurrence/profile as inferred. Projection0.10m on every shaft side and thickness0.12m are reconstructed first fits, including the unseen depth and masonry treatment; no metric or original color is read from the monochrome surrogate. The cap occupies the existing head's top band, preserving the stated0.75m total head,0.65m shaft, count and ridge station."}
p.write_text(json.dumps(d,indent=2)+'\n')
patch=''
for rel in paths:
 a=(OUT/'base/chicago/4d'/rel).read_text().splitlines(True);b=(OUT/'candidate/chicago/4d'/rel).read_text().splitlines(True)
 patch+=''.join(difflib.unified_diff(a,b,fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel))
(OUT/'HOGAN-CANDIDATE.patch').write_text(patch)
print('Prepared',len(patch),'byte patch; no source edits')
