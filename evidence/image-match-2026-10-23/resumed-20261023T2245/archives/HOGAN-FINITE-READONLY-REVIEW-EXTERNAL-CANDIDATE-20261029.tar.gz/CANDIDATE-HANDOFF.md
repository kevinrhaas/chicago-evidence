# Original T-2377 bounded external candidate

This packet changes no application checkout. `HOGAN-CANDIDATE.patch` is an 11.6 KB unified patch against the exact existing primary Miller WIP, so its Miller flue and three-upper-window fields are preserved. `base/chicago/4d/` records all three preimages and `candidate/chicago/4d/` all three postimages. The base Hogan record matches current dev03b exactly; the primary producer/params include unmerged Miller work intentionally.

Two default-off keyword-only controls are added and declared CONSUMED:

- `end_gable_courses: '+x'` replaces only the smooth +X gable cap with horizontal timber course relief. It refuses non-simple/ridgeY/hip/compound/addition/loft combinations and simultaneous front-gable treatment. Pictured course presence is inferred; the helper's 200mm rhythm, 8mm joints, 12mm relief, neutral material and unseen log-versus-board interpretation are reconstructed. Existing hatch sits 40mm beyond the gable plane; new relief is12mm, so no hatch cover is introduced.
- `ridge_stack_cap_m: [0.10, 0.12]` gives the one stated ridge stack a projecting top. All numeric dimensions are R; source note distinguishes the inferred pictured occurrence/profile. The cap replaces the existing head's upper band, preserving total head height. The shaft top is omitted at the hidden cap interface to avoid coplanar overlap. Defaults retain exactly the old shaft box.

`verify_candidate.py` executes actual selected native parameter and roof/ridge functions as pure Python capture, with no bpy import/export. All82 current log record resolutions and actual default roof/ridge output captures are byte-for-byte/list-exact against their preimages; the candidate's two roof slopes, hidden cap, ridge height and overall head height remain exact; all11 malformed/incompatible opt-ins refuse; both controls are CONSUMED. `CANDIDATE-PURE-PROOF.json` records those limited actual results. This is not full-builder, native master/WEB, Blender, camera or image-gate qualification.

`LIBERTY-APPEND.md` has the required Covers/Decision/Source/Recorded/Ticket labels. Merge it append-only into the current liberty ledger once adopted; the group owns one visitor changelog and final native/app/preflight. No source/rights/attribute-grade upgrade is made. OriginalT2377 stays OPEN until actual current candidate comparison and all image acceptance support closure; the two concrete picture gaps justify this finite increment even if other broader acceptance remains.

Only these three source paths belong to this candidate:

1. generators/archetypes/log_dwelling.py
2. generators/archetypes/log_dwelling_params.py
3. data/structures/hogan_store.json

No model, manifest, image-store, comparison or native output has been created or changed. No heavy job or new ticket was started. The grouped owner may combine this with the same family82-master run after the Tremont lease releases; perform one finite Hogan pilot/comparison and do not delay the already successful Mary/lighthouse units for unbounded fitting.

## Canonical view enrollment prepared, not performed

`CANONICAL-CAMERA.candidate.json` belongs at `data/reference_views/hogan_store/cameron_1833.json`. It retains every actual old numeric ray/intrinsic and held source path while adding explicit scene1835/diagnostic_only and a truthful solve note. No library image, hosting or API is added. `CANONICAL-ENROLLMENT-BINDING.json` binds the old actual camera/model/review and new metadata hash; `PRIOR-ACTUAL-REVIEW.raw.json` is retained `differs`, never promoted. Native `photo_match.mjs` will create the canonical adjacent match record and research side-by-side from the actual new candidate. Review that genuine result and update only concrete T3153 dispositions; native `image_gate.mjs --structure hogan_store` is required before originalDONE.

The two held files are identical Cameron compositions, as `HELD-COMPOSITION-IDENTITY.json` proves. Alamy's differently licensed advertising copy was not downloaded or reused. The separate distant SouthWater painting is only an unreachable inventory lead with no held pixels identified; do not invent a solved camera or literal match for it. Source-credit link handling remains the existing image compiler's behavior, with no new historical Spot.
