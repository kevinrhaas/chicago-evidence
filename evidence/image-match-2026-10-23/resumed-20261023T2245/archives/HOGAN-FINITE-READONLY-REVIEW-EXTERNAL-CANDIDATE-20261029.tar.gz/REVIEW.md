# Hogan T-2377 finite picture review — 2026-10-29

This is a read-only review of the original ticket, not a new ticket, source edit, render, acceptance or completed image gate. The actual held Cameron picture and actual official after-comparison were directly viewed at full resolution. Current dev is `03b027ba6bed8d8ebf1a20e716462ea2b8b54739`.

The current Hogan source record is byte-exact with the older local source (`ac7fbf45d7b88258449cab2672eb3b905c5cb4b73c965b4df46d9848978e2ef0`). More importantly the actual current dev master Git blob is `87e1e758143aebf2468035fc6802362cc2500efe`, exactly the local official master bound by the existing comparison: SHA256 `687628d4780f2409e045c1cba6b53a871d02524657a475a6a2716591c0ab2182`, 45,616 bytes. Thus the viewed geometry is still the current geometry; this does not relabel the old capture as a fresh run. The current producer was fetched by exact commit through the API; the only difference from local producer is the unmerged Miller-specific flue work, not a Hogan behavior change.

## Two finite visible differences

1. **Visible gable material/course structure.** Cameron draws horizontal courses through the triangular gable around the small rectangular opening. The actual after-render has a single smooth dark triangle: generic `_roof` closes the gable using roof material. This is a wrong visible surface/element category over the whole gable, not a request to fit pixels or invent surveyed dimensions. The photograph does not safely distinguish hewn logs from narrow horizontal boards, so that distinction and all course dimensions must remain reconstructed. Preserve the existing hatch and overall gable/roof envelope.

   The existing `front_gable_cladding: log_courses` is not an available record-only solution: current parameter validation restricts it to simple **+Y gables with ridge axis Y**, while Hogan has ridge axis X and the pictured end is +X. A bounded end-specific horizontal-course consumer is needed if implemented. Do not rotate the footprint, change the ridge or alter all log-building defaults merely to use that control. A suitable finite source change would state horizontal visible-gable treatment only for Hogan's +X end, keep existing default geometry byte-exact, and preserve the hatch as an opening/proxy over the courses.

2. **Missing projecting chimney cap.** Cameron's short roof-piercing shaft terminates in a visibly projecting dark top/cap. The actual render's shaft terminates in the unbroken square-box outline, and `_ridge_stack` emits only that box. The missing cap changes an element's shape and is a T-3153 gap even if its projection is under 0.3 m. A default-off cap option for the stated Hogan ridge stack is a small bounded next increment. The depicted cap occurrence/profile can guide the shape; its unseen depth, precise overhang/thickness and material/color remain reconstructed, with no fake metric claim. Preserve the existing one-stack count, 0.6 ridge station, 0.65 m shaft width and 0.75 m head unless actual comparison justifies a change.

These two repairs could be worked together on T-2377; they do not require a new follow-up ticket. No new producer implementation or native output was created by this review.

## Objections that do not establish another geometry task here

The provisional six-wallpoint camera has inconsistent drawing convergence. Its 16.099 px RMS and 26.809 px maximum residual do not independently prove a greater-than-0.3 m footprint, height, opening-station or roof-pitch error. Keep the attested 45 by 20 ft rectangle and current placement rather than forcing a perspective drawing onto a lens. Existing monochrome tonal differences cannot establish original paint colors. Unresolved original publication, July-1835 survival and hidden elevations are provenance limits rather than visible geometry changes. A few-pixel sash-bar/board-ledge reading is not promoted to a third task by this review. The figure, cart, river and surrounding context are outside this finite building-shape increment; no blanket full-scene match is claimed.

After actual fixes, use the current native pipeline, same numeric comparison rays, direct review and actual app validation. Only a genuine final review may update the original discrepancy record or verdict. Original T-2377 remains open at this review.

## Exact inspected evidence

- `chicago/reference/images/chicago/chicago_first_post_office_1833.jpg`: SHA256 `bea3548297a7b81e76c73f1083af2d013e3884cda39dd3f5ed37c0a2423a903a`.
- `docs/RESEARCH/hogan-picture-match-T-3118/after/cameron-1833-after-side-by-side.jpg`: SHA256 `35637768d5dad9717f533e22a7b98ccdcb7bf549f20c87b490866e9bd19b9529`.
- Existing after-match camera SHA256 `e4a0a576d3ad33314623d75244d75d07cc3dcbc089935bcc5572e81b13bfa7e4`.
- Current source and producer copies plus master-blob binding are included beside this report. No heavy jobs ran.
