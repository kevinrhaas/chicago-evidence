import subprocess,json,pathlib,concurrent.futures,base64,datetime
out=pathlib.Path('/tmp/original-progress-20261027T0115')
def api(p):
 return json.loads(subprocess.check_output(['gh','api',p],text=True))
ref=api('repos/kevinrhaas/chicago-tickets/git/ref/heads/main')['object']['sha']
files=[p for p in pathlib.Path('/workspace/chicago-tickets/T-2250-2499').glob('*.md') if any(p.name.startswith(f'T-{i}-') for i in range(2372,2389))]
def read(p):
 r=api('repos/kevinrhaas/chicago-tickets/contents/T-2250-2499/'+p.name+'?ref='+ref)
 raw=base64.b64decode(r['content']); (out/p.name).write_bytes(raw)
 front=raw.decode().split('---',2)[1]
 kv=dict(line.split(':',1) for line in front.splitlines() if ':' in line)
 return {'ticket':p.name[:6],'path':r['path'],'blob':r['sha'],'bytes':len(raw),'frontmatter':{k:v.strip() for k,v in kv.items()}}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex: tickets=list(ex.map(read,files))
prs=[1260,1282,1283,1286,1298,1300,1323,1328,1333,1334,1336,1337,1348]
def readpr(n):
 p=api(f'repos/kevinrhaas/chicago/pulls/{n}')
 return {k:p.get(k) for k in ['number','title','state','draft','merged_at','merge_commit_sha','html_url']}|{'head':p['head']['sha'],'base':p['base']['ref']}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex: pulls=list(ex.map(readpr,prs))
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ticket_main':ref,'ticket_records':sorted(tickets,key=lambda x:x['ticket']),'prs':pulls,'scope':'Read-only live ticket/PR status; no fresh all-picture acceptance or estimated completion percentage.'}
(out/'LIVE-RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'at':result['at'],'ticket_main':ref,'states':[(x['ticket'],x['frontmatter'].get('status',x['frontmatter'].get('state'))) for x in result['ticket_records']],'merged':[(x['number'],x['merged_at']) for x in pulls if x['merged_at']],'open':[x['number'] for x in pulls if x['state']=='open']},indent=2))
