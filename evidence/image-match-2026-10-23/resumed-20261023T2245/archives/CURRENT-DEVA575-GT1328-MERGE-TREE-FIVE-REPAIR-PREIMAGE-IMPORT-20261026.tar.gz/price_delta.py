from pathlib import Path
import os,subprocess,json,urllib.request
B=Path('/tmp/current-dev-refresh-20261026-a575');R=Path('/tmp/chicago-current-objects-20261025');C=Path('/workspace/chicago');old='ce892142a6521d43cc5a9617abbb77b715042ea6';env=dict(os.environ);env['GIT_NO_LAZY_FETCH']='1'
if 4 in os.sched_getaffinity(0): os.sched_setaffinity(0,{4})
def git(repo,*a,input=None):return subprocess.check_output(['git','-C',str(repo),'-c','gc.auto=0','-c','maintenance.auto=false','-c','core.preloadIndex=false','-c','index.threads=1',*a],input=input,env=env)
head=git(R,'rev-parse','refs/heads/dev').decode().strip();assert head==json.loads((B/'dev-start.json').read_text())['object']['sha']
tree=git(R,'rev-parse',head+'^{tree}').decode().strip()
log=git(R,'log','--format=%H %s',old+'..'+head).decode();delta=git(R,'diff','--name-status','--no-renames',old,head).decode();(B/'commits.txt').write_text(log);(B/'changed-paths.txt').write_text(delta)
with urllib.request.urlopen('https://api.github.com/repos/kevinrhaas/chicago/git/trees/'+head+'?recursive=1',timeout=60)as r:raw=r.read()
(B/'tip-recursive-tree.json').write_bytes(raw);d=json.loads(raw);assert not d.get('truncated')
blobs=[x for x in d['tree']if x['type']=='blob'];ids=sorted({x['sha']for x in blobs});rows=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();missing={x.split()[0]for x in rows if x.endswith(' missing')};paths=[r for r in blobs if r['sha']in missing];unique={x['sha']:x['size']for x in paths}
result={'previous_dev':old,'dev':head,'tree':tree,'commits':log.splitlines(),'changed_paths':delta.splitlines(),'missing_unique_blob_count':len(unique),'missing_unique_blob_bytes':sum(unique.values()),'missing_blob_paths':paths,'all_tip_blob_unique_count':len(ids),'shared_objects_written':False,'refs_updated':False}
(B/'PRICE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
