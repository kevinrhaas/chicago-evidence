# Actual school front-gable course trial — differs

One official pinned-Blender export and one unchanged-camera capture completed successfully after root’s explicit second heavy-slot grant. Direct inspection of the full reference, actual blind-door before image, actual new full comparison and identical crop shows the horizontal gable courses visibly replacing the plain triangular roof-coloured cap. That moves the visible category toward the reference.

It remains different: the modeled logs/chinks are flat and uniformly toned, the roof covering is absent, frontage/camera and window/door proportions differ, the rear stack is not established by the cropped reference, and world/people/ground context is absent. Subject identity, original publication/artist/date and metric camera remain unresolved. The original image-match case remains open and no accepted reference view follows.

New master: `fe73a03a135811179b47ac603bf4169b35d1b0cc8b8d595d144885053189a8d8`, 528 triangles, 50,172 bytes. Baseline is the byte-original actual blind-door master `de08343a…` and its original bare PNG. All unchanged source/camera and frozen-input guards passed. Pure geometry comparison removed exactly one plain front-cap polygon; all original roof slopes, back gable, walls, opening/door and stack polygons/materials/confidence remain exact. The new cap/course geometry is reconstructed confidence1.0.

Original generated unreviewed research-match bytes are preserved separately; the local research match now records `differs`. No canonical source, model, rights, source credit, placement, date, footprint or ticket acceptance was changed. Browser/server/export children have exited; heavy slot is clear.
