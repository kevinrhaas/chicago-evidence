"""Dry geometry-only evaluation of the single opt-in school front-gable proposal."""
from pathlib import Path
from types import ModuleType
from dataclasses import replace, fields
from collections import Counter
import sys, json, hashlib, inspect

sys.dont_write_bytecode = True
H = Path(__file__).resolve().parent
sys.path.insert(0, str(H/'base/generators'))
sys.modules['bpy'] = ModuleType('bpy')


def load(name, path):
    m = ModuleType(name)
    m.__file__ = str(path)
    sys.modules[name] = m
    exec(compile(path.read_text(), str(path), 'exec'), m.__dict__)
    return m


oldp = load('school_front_gable_old_params', H/'base/generators/archetypes/log_dwelling_params.py')
newp = load('school_front_gable_new_params', H/'candidate/generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params'] = oldp
old = load('school_front_gable_old_mesh', H/'base/generators/archetypes/log_dwelling.py')
sys.modules['archetypes.log_dwelling_params'] = newp
new = load('school_front_gable_new_mesh', H/'candidate/generators/archetypes/log_dwelling.py')
from common.mesh import MeshBuilder


class Raw(MeshBuilder):
    def to_object(self, materials=None):
        self.materials = materials
        return self


for m in [old, new]:
    m.MeshBuilder = Raw
    m.simple_material = lambda *a, **kw: (a, kw)


def raw(m):
    return (m.verts, m.faces, m.conf, m.mat_index, m.named, m.materials)


def polygons(m):
    return Counter((tuple(m.verts[n] for n in f), tuple(m.conf[n] for n in f), m.mat_index[i]) for i, f in enumerate(m.faces))


scope = json.loads((H/'fixtures/freshness-scope.json').read_text())['assets']
assert len(scope) == 81
default_rows = []
for row in scope:
    record = json.loads((H/'fixtures/records'/f"{row['structure_id']}.json").read_text())
    phase = next(p for p in record['phases'] if p['id'] == row['phase_id'])
    op, np = oldp.from_phase(phase, record), newp.from_phase(phase, record)
    a, b = old.build(op, row['asset'][:-4]), new.build(np, row['asset'][:-4])
    assert raw(a) == raw(b), row['asset']
    default_rows.append({'asset': row['asset'], 'raw_material_confidence_exact': True})

old_pos = [f.name for f in fields(oldp.LogDwellingParams) if not f.kw_only]
new_pos = [f.name for f in fields(newp.LogDwellingParams) if not f.kw_only]
assert old_pos == new_pos
field = next(f for f in fields(newp.LogDwellingParams) if f.name == 'front_gable_cladding')
assert field.kw_only and field.default is None

br = json.loads((H/'base/data/structures/chappel_infant_school.json').read_text())
nr = json.loads((H/'candidate/data/structures/chappel_infant_school.json').read_text())
bp, np = oldp.from_phase(br['phases'][0], br), newp.from_phase(nr['phases'][0], nr)
a, b = old.build(bp, 'chappel_infant_school__log_1833'), new.build(np, 'chappel_infant_school__log_1833')
assert raw(a) != raw(b)
removed, added = polygons(a)-polygons(b), polygons(b)-polygons(a)
assert sum(removed.values()) == 1, 'Only the old plain front cap may disappear'
old_face = next(iter(removed))
assert len(old_face[0]) == 3 and old_face[2] == old.M_ROOF
plane = old_face[0][0][1]
assert all(abs(v[1]-plane) < 1e-10 for v in old_face[0])
assert plane > np.depth_m
assert all(v[1] >= plane-1e-10 and c == 1.0 for face, cs, mat in added for v,c in zip(face,cs))
assert {mat for face,cs,mat in added} == {new.M_LOG, new.M_CHINK}
assert a.materials == b.materials
assert min(v[0] for v in a.verts) == min(v[0] for v in b.verts)
assert max(v[0] for v in a.verts) == max(v[0] for v in b.verts)
assert max(v[2] for v in a.verts) == max(v[2] for v in b.verts)
# All pre-existing slope, back-gable, wall, opening, blind-door and stack polygons
# are identical because the multiset subtraction removed exactly that one cap.
for name in ['width_m','depth_m','wall_height_m','roof_pitch_deg','roof_ridge_axis','front_set_out','front_door_state','chimneys']:
    assert getattr(bp,name) == getattr(np,name), name

refused=[]
for label,kwargs in [('bad-value',{'front_gable_cladding':'board'}),('wrong-axis',{'roof_ridge_axis':'x'}),('shed',{'roof_type':'shed','roof_ridge_axis':None}),('hip',{'hip_end':'min'}),('loft',{'loft':True}),('frame-addition',{'frame_addition':True})]:
    try:
        replace(np,**kwargs).validate()
    except newp.ParamError:
        refused.append(label)
    else:
        raise AssertionError('Unsupported '+label+' accepted')

import jsonschema
schemas = H/'schemas'
jsonschema.validate(nr,json.loads((schemas/'structures.schema.json').read_text()))
ns = json.loads((H/'candidate/data/sources/eliza_chappel_school_shore_view.json').read_text())
jsonschema.validate(ns,json.loads((schemas/'source.schema.json').read_text()))
bs = json.loads((H/'base/data/sources/eliza_chappel_school_shore_view.json').read_text())
tmp=dict(ns);tmp['note']=bs['note'];assert tmp == bs
restored=json.loads(json.dumps(nr));restored['phases'][0]['form'].pop('front_gable_cladding');restored['research_note']=br['research_note'];assert restored == br
report={'status':'PASS_LIGHT_UNEXPORTED_UNRENDERED','default_family_count':len(default_rows),'default_family':default_rows,'positional_API_exact':old_pos,'new_field_keyword_only_default':None,'removed_plain_cap_count':sum(removed.values()),'added_front_cap_and_course_polygons':sum(added.values()),'all_other_polygons_materials_confidence_exact':True,'school_triangles_before':sum(len(f)-2 for f in a.faces),'school_triangles_after':sum(len(f)-2 for f in b.faces),'unsupported_refusals':refused,'source_rights_and_credits_unchanged':True,'source_structure_schemas':'PASS','canonical_changes':False,'new_exports_or_captures':0,'limits':'Pure helper equivalence on frozen81 records. No Blender/browser, GLB/web, current-dev adaptation, canonical schema/coverage note-reader integration, family rebake, application or image acceptance.'}
(H/'LIGHT-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['default_family','positional_API_exact']},indent=2))
