# School front-gable continuation — actual trial completed, differs

This is an isolated continuation of the actual recessed-door school baseline from run20261023-224621-281228. Root approved exactly one new official export and one same-camera capture, now closed at `runs/20261023-225301-130616/`. Source/full actual comparison and unchanged before/after detail were directly inspected. Horizontal log courses now replace the plain front-gable cap and visibly improve its category. The image still differs; no original ticket, accepted view, rights or identity/date ruling changes.

The patch adds keyword-only `front_gable_cladding=None|log_courses` to the copied log helper. Emptydefault preserves all51old positional API fields and exact raw/material/confidence output on the81 historical frozen-family fixtures. The opt-in is bounded to a simple +Y gable without hip, compound rooms, frame addition or loft. Its inherited340mm course rhythm,55mm chink-band proxy, small existing relief and colours are reconstructed—not image measurements. Only the front cap changes: all existing roof slopes, back cap, walls, opening/door/stack polygons and their materials/confidence remain exact. Actual raw496→528triangles; new GLB50,172bytes.

`front-gable-next.patch` is the stable four-file delta from `base/` to `candidate/`; `LIBERTY-APPEND.md` supplies the precise Cover. Both producer trees are execution support, not wholesale canonical replacements. Rebase the source/record notes selectively onto actualcurrentdev; preserve independent credits/rights/source updates and Hogan’s integrated values. The current family may have82masters: siblinglog81_adoption_plan is recounting/current-default auditing and composing this with latest Wolf controls. Never claim the81fixture check proves current82 production.

Integration still needs current consumed-field and name_pool_keys note-reading for `phases[].form.front_gable_cladding.note`, the existing not-yet-canonical front-door note reader, precise liberty/Covers compilation, official whole-family rebuild/web derivatives/freshness/consumers, full strict gates, actual mobile/desktop application QA and all-picture camera work. No canonical PR should silently adopt only the generated preview or substitute a recipe hash.

Light check:

```sh
python3 /tmp/chicago-next-model/T-2372-front-gable-next-20261023/check_light.py
```

The explicitly granted export/capture is already done. Do not rerun `run_next.py --execute-after-root-grant` merely to recover it. `snapshot.json` binds exact source/camera/producer inputs and actual baseline. `actual-door-baseline/` preserves the byte-original previous master/PNG/full comparison. The actual run preserves official export/decoded contract, source/camera/master match hashes, raw PNG/full comparison/detail and direct review. Original unreviewed bytes remain separate. Historical LIGHT-REVIEW.json correctly describes its own no-export helper check, while actual receipt/review record the subsequent real export/capture.

Reference: artist unidentified, reproduced by Digital Research Library of Illinois History Journal2018 Eliza Chappell article, https://drloihjournal.blogspot.com/2018/01/eliza-chappell-the-first-chicago-teacher-paid-by-public-funds-in-1833.html . Owner-approved attributed project use underT3053; not a public-domain, copyright-holder or original-identification finding. The former school had moved by1834; the drawing does not establish1835 occupants or an interior.
