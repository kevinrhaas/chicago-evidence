"""Compare unchanged crops; baseline is the prior byte-original actual blind-door PNG."""
from pathlib import Path
import sys,json
from PIL import Image,ImageDraw
H=Path(__file__).resolve().parent;run=Path(sys.argv[1]).resolve();assert run.is_relative_to(H/'runs')
box=(495,130,640,292);scale=3;w=(box[2]-box[0])*scale;h=(box[3]-box[1])*scale
sources=[('Journal reproduction; artist unknown',run/'before/data/sources/assets/21617595_10203558686525015_5452300313452439832_n.jpg'),('Before: actual blind doorway PNG',run/'reviews/before/render.png'),('After: front-gable log courses',run/'reviews/after/render.png')]
canvas=Image.new('RGB',(w*3+48,h+40),'white');draw=ImageDraw.Draw(canvas)
for i,(label,p) in enumerate(sources):
 im=Image.open(p).convert('RGB');assert im.size==(640,368)
 canvas.paste(im.crop(box).resize((w,h),Image.Resampling.NEAREST),(i*(w+24),40));draw.text((i*(w+24)+8,10),label,fill='black')
canvas.save(run/'reviews/source-before-after-detail.png')
(run/'reviews/detail-receipt.json').write_text(json.dumps({'crop_original_px':box,'integer_display_scale':scale,'interpolation':'nearest, same crop, no warp','baseline_quality':'byte-original PNG from closed actual blind-door run 20261023-224621-281228','camera_unchanged':True,'source_credit':'Artist unidentified; reproduced by Digital Research Library of Illinois History Journal,2018 Eliza Chappell article; owner-approved attributed project use (T3053), not public domain.','limits':'All image identification, date, scene perspective and full original acceptance remain unresolved.'},indent=2)+'\n')
