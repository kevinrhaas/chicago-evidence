### School front-gable horizontal courses — reconstructed proposal

The approved attributed school-shore picture visibly continues horizontal courses into the front gable. Its subject, date, artist and original publication remain unresolved. This design category guides an isolated default-off +Y-cap replacement; the existing 340mm course rhythm, 55mm chink bands, small existing relief and exact colour/section/joints are reconstructed model choices, not image measurements. Preserve roof silhouette, ridge, physical footprint, placement, camera, openings, blind doorway and all date/use limits. No rear-gable finish or occupant is asserted.

Covers: chappel_infant_school.log_1833.form.front_gable_cladding
