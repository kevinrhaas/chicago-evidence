"""Separate exact native one-merge transport. Original c164 source PASS stays dated.
Default plans only. Publication needs actual composite proof and root grant.
"""
from pathlib import Path
import os,json,hashlib,importlib.util,argparse,datetime
from urllib.request import Request,urlopen
P=argparse.ArgumentParser(description=__doc__)
for a in ['expected-old','head','upstream','original-gate','composite-proof','output','observed-fresh-dev','fresh-dev-scope-proof']:P.add_argument('--'+a,required=True)
P.add_argument('--publish',action='store_true');P.add_argument('--max-total-bytes',type=int,default=64*1024**2);a=P.parse_args();os.sched_setaffinity(0,{1});os.nice(19)
spec=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
O=Path(a.output);O.mkdir(exist_ok=False)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def shab(b):return hashlib.sha256(b).hexdigest()
before=m.snapshot();save('SOURCE-BEFORE.json',before);assert before['HEAD']==a.head and not before['status'];assert m.git('branch','--show-current').decode().strip()==m.BRANCH
old=m.commit(a.expected_old);up=m.commit(a.upstream);head=m.commit(a.head);assert head['parents']==[a.expected_old,a.upstream], 'Exactly one native merge with declared checked/code/upstream parents required'
for c in [old,up]:
 r=m.api('git/commits/'+c['sha']);assert r['sha']==c['sha']and r['tree']['sha']==c['tree']and[p['sha']for p in r['parents']]==c['parents']
assert old['tree']=='c1648b2b1edec693d3ccfec01b7675597e1d143e','Original published four-ticket head must still be the actually fully gated tree'
gatepath=Path(a.original_gate);gatebytes=gatepath.read_bytes();gate=json.loads(gatebytes);assert gate['status']=='ACTUAL_FINAL_FOUR_CHECK_PASS_SOURCE_UNCHANGED'and gate['exit']==0 and all(v is True for v in gate['guards'].values())and gate['binding']['checked_final_staged_tree']==old['tree']
proofpath=Path(a.composite_proof);proofbytes=proofpath.read_bytes();proof=json.loads(proofbytes)
assert proof['schema']=='CHICAGO_EARLY_FOUR_DISJOINT_COMPOSITE_V1'and proof['status']=='ACTUAL_COMPOSITE_NATIVE_PACKAGE_PHONE_EARLY_INPUTS_PASS'
b=proof['binding'];assert b['own_checked_head']==a.expected_old and b['accepted_upstream']==a.upstream and b['composite_head']==a.head and b['composite_tree']==head['tree']and b['original_gate_receipt_sha256']==shab(gatebytes)
required={'native_changed_consumers_pass','native_metadata_checks_pass','native_package5_pass','native_publish_pass','current_phone1904_pass','all_children_reaped','PR_event_questions_pass','all353_log_frame_recipes_fresh','all706_log_frame_models_preserved','all44_semantically_exact_or_native_derived','early_physical_inputs_preserved','all4_native_and_published_sidecar_WEB_camera_grade_photo_STORE_inputs_preserved'}
assert set(proof['checks'])==required and all(v is True for v in proof['checks'].values())
assert proof['phone']['limit_MiB']==400 and 0<proof['phone']['mobile_peak_MiB']<=400 and proof['phone']['gate_pass']is True
assert set(proof['evidence'])=={'native_consumers','package','publish','phone','early_input_reuse','pr_questions'}
for k,r in proof['evidence'].items():
 p=Path(r['path']);assert p.is_file()and not p.is_symlink()and str(p).startswith('/workspace/early-four-')and p.suffix in {'.json','.log','.tsv','.md'}and 'browser-profiles'not in str(p)and 'cert'not in str(p)
 raw=p.read_bytes();assert len(raw)==r['bytes']and shab(raw)==r['sha256'],('Actual composite evidence changed',k)
oldleaves=m.leaves(old['tree']);cur=m.leaves(head['tree']);upleaves=m.leaves(up['tree'])
protected=[p for p in set(oldleaves)|set(cur)if p.startswith('chicago/4d/generators/archetypes/')or(p.startswith('chicago/4d/renderers/web/')and p!='chicago/4d/renderers/web/js/changelog.js')or any('/'+s+'/'in p or p.endswith('/'+s+'.json')for s in ['miller_house','hogan_store','st_marys_church','chicago_lighthouse_1832'])]
assert len(protected)>=527 and all(oldleaves.get(p)==cur.get(p)for p in protected),'Actual early producer/renderer/target objects moved'
extra=['chicago/4d/data/structure_grades.json','chicago/4d/data/enclosures/town_entrance_aprons.json','chicago/4d/data/signage/town_business_signboards.json','chicago/4d/data/yard/town_trade_goods.json','chicago/4d/data/yard/town_woodpiles.json','chicago/4d/data/reconstruction/name_pool_keys.json','chicago/4d/data/reconstruction/1835_placement_policy.json',*m.LIBRARY_OUTPUTS]
assert all(oldleaves.get(p)==cur.get(p)for p in extra),'Physical/grade/picture inputs changed'
def js(leaves,p):return json.loads(m.obj('blob',leaves[p][2]))
assets=js(oldleaves,'chicago/4d/assets/manifest.json')['assets'];newassets=js(cur,'chicago/4d/assets/manifest.json')['assets'];family={n:r for n,r in assets.items()if r.get('archetype')in {'log_dwelling','frame_dwelling'}};assert len(family)==353
for n,r in family.items():
 assert newassets[n]==r
 for folder in ['gltf','web']:
  p='chicago/4d/assets/'+folder+'/'+n;assert oldleaves[p]==cur[p]
changed={p:cur.get(p)for p in sorted(set(oldleaves)|set(cur))if oldleaves.get(p)!=cur.get(p)};assert changed and all(p.startswith('chicago/4d/')and v is not None and v[0]in {'100644','100755'}and v[1]=='blob'for p,v in changed.items())
checked=b['changed_path_sha256'];assert set(checked)==set(changed)
for p,v in changed.items():assert shab((m.SOURCE/p).read_bytes())==checked[p]and m.gitsha('blob',(m.SOURCE/p).read_bytes())==v[2]
known={v[2]for tree in [oldleaves,upleaves]for v in tree.values()if v[1]=='blob'};needed={v[2]for v in changed.values()if v[2]not in known};prices={s:{'bytes':len(m.obj('blob',s)),'sha256':shab(m.obj('blob',s))}for s in needed};total=sum(r['bytes']for r in prices.values());assert total<=a.max_total_bytes
ref=m.api('git/ref/heads/'+m.BRANCH);assert ref['object']['sha']==a.expected_old
scopepath=Path(a.fresh_dev_scope_proof);scopebytes=scopepath.read_bytes();scope=json.loads(scopebytes)
assert scope['status']=='READONLY_CURRENT_DEV_ADVANCE_PRICED_NO_IMPORT'and scope['base']==a.upstream and scope['tip']==a.observed_fresh_dev
reviewed_exceptions={'chicago/4d/generators/archetypes/k01_frontage.py','chicago/4d/generators/archetypes/k01_frontage_params.py','chicago/4d/generators/archetypes/k03_brick.py'}
assert scope['protected_binding_count']>=527 and set(scope['protected_binding_changes'])<=reviewed_exceptions
assert scope['source_HEAD_index_refs_working_unchanged_by_operation']is True and scope['new_blob_bytes']<=64*1024**2
assert all(p.startswith('chicago/4d/')for p in scope['changed_paths'])
# Reviewed newer dev is not a parent of this independently qualified branch
# checkpoint. Publishing it never writes dev or claims the new dev was tested.
observed=m.api('git/commits/'+a.observed_fresh_dev);assert observed['tree']['sha']==scope['tree']
ancestry=m.api('compare/'+a.upstream+'...'+a.observed_fresh_dev);assert ancestry['status']in {'ahead','identical'}
freshdev=m.api('git/ref/heads/dev')['object']['sha']
if freshdev!=a.observed_fresh_dev:
 assert m.api('compare/'+a.observed_fresh_dev+'...'+freshdev)['status']=='ahead','New dev must descend from reviewed observation'
plan={'status':'ONE_NATIVE_COMPOSITE_MERGE_PLANNED_NO_REMOTE_WRITES','expected_old':a.expected_old,'head':a.head,'upstream':a.upstream,'tree':head['tree'],'parents':head['parents'],'protected_bindings_exact':len(protected),'all353_rows_706_models_exact':True,'changed_paths':list(changed),'new_blob_bytes':total,'new_blobs':prices,'composite_proof_sha256':shab(proofbytes),'original_gate_receipt_sha256':shab(gatebytes),'force':False,'reviewed_observed_dev':a.observed_fresh_dev,'reviewed_scope_sha256':shab(scopebytes),'reviewed_newdev_generator_exceptions':scope['protected_binding_changes'],'dev_observed_at_plan':freshdev,'behind_current_dev':freshdev!=a.upstream,'newer_dev_tree_qualified_by_this_branch':False,'scope':'Native composite transport only. Original whole-source PASS remains dated c164; current required CI checks on the new head remain mandatory before merging PR.'};save('PLAN.json',plan);assert m.snapshot()==before
if not a.publish:print(json.dumps({'status':plan['status'],'new_blob_bytes':total,'head':a.head}),flush=True);raise SystemExit(0)
import base64
for s in needed:
 raw=m.obj('blob',s);assert len(raw)==prices[s]['bytes']and shab(raw)==prices[s]['sha256'];assert m.api('git/blobs',{'encoding':'base64','content':base64.b64encode(raw).decode()})['sha']==s
tr=m.api('git/trees',{'base_tree':old['tree'],'tree':[{'path':p,'mode':v[0],'type':v[1],'sha':v[2]}for p,v in changed.items()]});assert tr['sha']==head['tree'];commit=m.api('git/commits',m.native_payload(head));save('CREATED-NATIVE-MERGE.json',commit);assert commit['sha']==a.head
assert m.api('git/ref/heads/'+m.BRANCH)['object']['sha']==a.expected_old and m.snapshot()==before
freshdev_before_ref=m.api('git/ref/heads/dev')['object']['sha']
if freshdev_before_ref!=a.observed_fresh_dev:
 assert m.api('compare/'+a.observed_fresh_dev+'...'+freshdev_before_ref)['status']=='ahead'
r=m.api('git/refs/heads/'+m.BRANCH,{'sha':a.head,'force':False},'PATCH');assert r['object']['sha']==a.head
public=m.api('git/commits/'+a.head);assert public['tree']['sha']==head['tree']and[p['sha']for p in public['parents']]==head['parents'];assert m.api('git/ref/heads/'+m.BRANCH)['object']['sha']==a.head
from urllib.parse import quote
readback=[]
for p,v in changed.items():
 expect=m.obj('blob',v[2])
 with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+a.head+'/'+quote(p,safe='/'),headers={'User-Agent':'Chicago-exact-composite-native-readback'}),timeout=120)as response:assert response.status==200;raw=response.read()
 assert raw==expect and m.gitsha('blob',raw)==v[2];readback.append({'path':p,'bytes':len(raw),'sha256':shab(raw),'mode':v[0],'git_blob':v[2]})
after=m.snapshot();save('SOURCE-AFTER.json',after);assert after==before
save('RESULT.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ONE_EXACT_NATIVE_COMPOSITE_MERGE_BRANCH_AND_READBACK_PASS','expected_old':a.expected_old,'head':a.head,'upstream':a.upstream,'tree':head['tree'],'parents':head['parents'],'native_SHA_preserved':True,'reviewed_observed_dev':a.observed_fresh_dev,'reviewed_scope_sha256':shab(scopebytes),'dev_observed_before_branch_ref':freshdev_before_ref,'newer_dev_tree_qualified':False,'behind_newer_dev_branch_checkpoint_only':True,'force':False,'readback':readback,'all_source_HEAD_index_config_status_refs_unchanged':True,'original_fullgate':'Dated c164; no new whole-source PASS claimed','current_CI':'Required on new exacthead before final PRmerge; no PRmerge performed by transport'});print(json.dumps({'status':'ONE_EXACT_NATIVE_COMPOSITE_MERGE_BRANCH_AND_READBACK_PASS','head':a.head}),flush=True)
