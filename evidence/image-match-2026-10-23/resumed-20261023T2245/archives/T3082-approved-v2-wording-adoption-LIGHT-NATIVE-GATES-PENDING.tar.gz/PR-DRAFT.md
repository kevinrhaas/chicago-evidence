T-3082: Darken Tremont’s roof and clarify historical review notes

The first Tremont House now selects a reconstructed roof contrast one quarter of its previous linear RGB, bringing the dark roof closer to the Gifford drawing. Cards also label retained notes as “Historical review context.” and keep the record’s explanation and sources; loader text follows the existing owner ruling that these annotations do not block release. Flags, confidence, conditions and unexpected-error checks are preserved.

Depends on #1260; targets dev. The inherited 82 log models and unrelated registry rows remain unchanged. All 23 frame models passed the pinned official export and native derivative pipeline; all 22 other files are byte-identical, and Tremont changes only three roof RGB values with binary geometry/UVs intact. Current recipe equality was reproved before transferring the genuine outputs onto this stack.

Three JavaScript syntax checks and focused extracted wording/control-flow/refusal checks pass. Current native picture/card review, downstream fixed-point checks, preflight/full gate and published mobile/desktop smoke remain pending; replace this paragraph with actual receipts before opening/merging. Original T-2385 remains open and differs. The separate flag-pose research is unadopted and source rights/attribution remain unchanged.
