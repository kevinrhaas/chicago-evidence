from pathlib import Path
import os,subprocess,json,importlib.util,hashlib,zlib,datetime,shutil,signal,time
from urllib.request import Request,urlopen
os.sched_setaffinity(0,{1});os.nice(10)
B=Path(__file__).parent;C=Path('/workspace/chicago');R=C/'chicago/4d/tickets';I=B/'repo';GT=Path('/tmp/chicago-green-tree-integration');GTTOOL=GT/'chicago/4d/tools/ticket.mjs';PTOOL=C/'chicago/4d/tools/ticket.mjs'
sp=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);m.SOURCE=R;m.G=R/'.git';m.REPO='kevinrhaas/chicago-tickets'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');CAP=60*1024**2;FLOOR=512*1024**2
sh=lambda b:hashlib.sha256(b).hexdigest()
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def git(root,*a,input=None):return subprocess.check_output(['git','-C',str(root),'-c','gc.auto=0','-c','maintenance.auto=false',*a],env=env,input=input)
def command(log,args,extra=None):
 with(B/log).open('xb')as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=extra or env)
 save(log+'.exit.json',{'exit':p.returncode});return p.returncode
before=m.snapshot();save('PRIMARY-TICKETS-BEFORE.json',before);assert not before['status']and before['HEAD']=='e055487da42c71e53a96852d6b3c1b1722d2470e'
primaryapp={n:sh((C/'.git'/n).read_bytes())for n in ['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(C/'.git'/n).is_file()};save('PRIMARY-APP-METADATA-BEFORE.json',primaryapp)
assert GTTOOL.read_bytes()==PTOOL.read_bytes()and not(GT/'site/4d').exists();assert git(GT,'branch','--show-current').decode().strip()=='steward/t2376-enclosed-annex-20261029'
ref=m.api('git/ref/heads/main');tip=ref['object']['sha'];commit=m.api('git/commits/'+tip);tree=m.api('git/trees/'+commit['tree']['sha']+'?recursive=1');assert not tree.get('truncated');save('REMOTE-REF.json',ref);save('REMOTE-COMMIT.json',commit);save('REMOTE-TREE.json',tree)
leaves=[r for r in tree['tree']if r['type']!='tree'];assert all(r['type']=='blob'and r['mode']=='100644'for r in leaves);work=sum(((r['size']+4095)//4096)*4096 for r in leaves);known=m.indexed([r['sha']for r in leaves]);missing=[r for r in leaves if r['sha']not in known];assert sum(r['size']for r in missing)<1024**2 and len(missing)<128;assert work+9*1024**2<CAP and shutil.disk_usage('/workspace').free>=FLOOR+CAP
save('PLAN.json',{'status':'ISOLATED_NATIVE_OWN_GT_RENEWAL_BOUNDED_PLAN','tip':tip,'all_working_files':len(leaves),'working_allocated_upper':work,'missing_blobs':len(missing),'missing_raw_bytes':sum(r['size']for r in missing),'allocation_cap':CAP,'workspace_floor':FLOOR,'primary_mutations':False,'native_tool_SHA256':sh(GTTOOL.read_bytes()),'native_command':['node',str(GTTOOL),'claim','T-2376','--force','--by','Codex Green Tree optional Andreas annex 2026-10-29'],'mirror':'GTsite/4dabsent nativewriter skips; primaryROOTneverused'})
assert command('CLONE.log',['git','-c','gc.auto=0','-c','maintenance.auto=false','clone','--shared','--no-checkout','--no-hardlinks',str(R),str(I)])==0
for k,v in [('remote.origin.url','https://github.com/kevinrhaas/chicago-tickets.git'),('remote.origin.promisor','true'),('remote.origin.partialclonefilter','blob:none'),('user.name','Kevin Haas'),('user.email','kevinroberthaas@gmail.com')]:git(I,'config',k,v)
# Only explicit immutable metadata fetch. Blob acquisition below stays finite and SHA verified.
assert command('METADATA-FETCH.log',['git','-C',str(I),'-c','gc.auto=0','-c','maintenance.auto=false','fetch','--no-tags','--no-write-fetch-head','--filter=blob:none','origin',tip])==0
metadata_bytes=sum(p.stat().st_size for p in(I/'.git/objects').rglob('*')if p.is_file());assert metadata_bytes<8*1024**2
rows=[]
for r in missing:
 with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+tip+'/'+r['path'],headers={'User-Agent':'Chicago-isolated-ownGT-native-renewal'}),timeout=60)as resp:assert resp.status==200;b=resp.read(r['size']+1)
 assert len(b)==r['size']and m.gitsha('blob',b)==r['sha'];raw=b'blob '+str(len(b)).encode()+b'\0'+b;d=I/'.git/objects'/r['sha'][:2]/r['sha'][2:];assert not d.exists();d.parent.mkdir(exist_ok=True);d.write_bytes(zlib.compress(raw));rows.append({'path':r['path'],'sha':r['sha'],'bytes':len(b),'sha256':sh(b)})
save('ISOLATED-HYDRATION.json',rows)
actual={}
for row in git(I,'ls-tree','-r','-z',tip).split(b'\0'):
 if row:
  x,n=row.split(b'\t');mode,kind,s=x.decode().split();actual[n.decode()]=(mode,kind,s)
expected={r['path']:(r['mode'],r['type'],r['sha'])for r in leaves};assert actual==expected
# All currenttip blobs now have verified native indexed IDs in primaryread-onlyalternate or isolatedloose.
assert {r['sha']for r in leaves}<=known|{r['sha']for r in rows}
assert command('CHECKOUT.log',['git','-C',str(I),'-c','gc.auto=0','-c','maintenance.auto=false','checkout','-B','main',tip])==0
git(I,'update-ref','refs/remotes/origin/main',tip)
assert not git(I,'status','--porcelain').strip();own='T-2250-2499/T-2376-match-the-green-tree-tavern-to-its-pictures.md';pre=(I/own).read_bytes();assert b'state: claimed\n'in pre and b'claimed_at: 2026-10-29T17:53:15.756Z'in pre
save('PRE-NATIVE.json',{'head':tip,'own_sha256':sh(pre),'foreign_paths':len(leaves)-1});assert m.snapshot()==before
extra=dict(env,CHICAGO_TICKETS_DIR=str(I));exitcode=command('NATIVE-CLAIM.log',['node',str(GTTOOL),'claim','T-2376','--force','--by','Codex Green Tree optional Andreas annex 2026-10-29'],extra)
head=git(I,'rev-parse','HEAD').decode().strip();save('POST-NATIVE.json',{'exit':exitcode,'head':head,'status':git(I,'status','--porcelain').decode(),'remote':m.api('git/ref/heads/main')['object']['sha']});assert exitcode==0,'Nativefailed: preserveactualcommit/rawlog; exactnativeRESTfallback needed'
assert not git(I,'status','--porcelain').strip();assert git(I,'show','-s','--format=%P',head).decode().strip().split()==[tip],'Concurrentnativepull branch: reviewactualnewparents'
aftertree={}
for row in git(I,'ls-tree','-r','-z',head).split(b'\0'):
 if row:
  x,n=row.split(b'\t');mode,kind,s=x.decode().split();aftertree[n.decode()]=(mode,kind,s)
assert set(aftertree)==set(expected)and all(aftertree[p]==v for p,v in expected.items()if p!=own)
post=(I/own).read_bytes();strip=lambda b:b'\n'.join(l for l in b.split(b'\n')if not l.startswith((b'claimed_by:',b'claimed_at:')));assert strip(pre)==strip(post)and pre!=post
native_at=next(l.decode().split(': ',1)[1]for l in post.splitlines()if l.startswith(b'claimed_at:'));dt=datetime.datetime.fromisoformat(native_at.replace('Z','+00:00'));assert dt>datetime.datetime(2026,10,29,20,0,tzinfo=datetime.timezone.utc)
with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+head+'/'+own,headers={'User-Agent':'Chicago-isolatedGT-exactnative-readback'}),timeout=60)as resp:assert resp.status==200;received=resp.read()
assert received==post
remote_head=m.api('git/ref/heads/main')['object']['sha'];assert remote_head==head or m.api('compare/'+head+'...'+remote_head)['status']=='ahead'
after=m.snapshot();save('PRIMARY-TICKETS-AFTER.json',after);assert after==before
appafter={n:sh((C/'.git'/n).read_bytes())for n in primaryapp};save('PRIMARY-APP-METADATA-AFTER.json',appafter);assert appafter==primaryapp
assert not(GT/'site/4d').exists();allocated=sum(p.stat().st_blocks*512 for p in I.rglob('*')if p.is_file()and not p.is_symlink());assert allocated<CAP and shutil.disk_usage('/workspace').free>=FLOOR
save('RESULT.json',{'status':'ACTUAL_OFFICIAL_NATIVE_OWN_GT_RENEWAL_REMOTE_NORMAL_PUSH_AND_IMMUTABLE_READBACK_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_head':head,'native_parent':tip,'native_command_exit':exitcode,'claimed_at':native_at,'expires_utc':(dt+datetime.timedelta(hours=3)).isoformat(),'only_changed_fields':['claimed_by','claimed_at'],'all_foreign_paths_exact':len(leaves)-1,'all_other_own_fields_and_body_exact':True,'immutable_postimage':{'path':own,'bytes':len(post),'sha256':sh(post)},'primary_ticket_HEAD_index_config_refs_working_unchanged':True,'primary_app_HEAD_index_config_MERGE_unchanged':True,'primary_ignored_ticketmirror_untouched':True,'GT_site4d_absent_untouched':True,'isolated_allocated_bytes':allocated,'workspace_free':shutil.disk_usage('/workspace').free,'qualification':'OfficialnativeownGTclaimrenewalonly; no appsource/adoption/model/app/PRmerge/originalDONE.'});print((B/'RESULT.json').read_text())
