from pathlib import Path
import datetime,hashlib,json,subprocess,stat
OUT=Path('/workspace/shared/T2385-own-lap-renewal-20261026T1735')
OUT.mkdir()
EXPECTED='6f34d931a451c1934ffc01a90a7aff4d9f47c18c'
HEAD='1290a23271b2771c77201fd17fed7cfa857ade14'
ACTOR='Codex Tremont Gale evidence 2026-10-26'
def get(path):
    return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path]))
def save(name,obj):
    p=OUT/name
    assert not p.exists()
    p.write_text(json.dumps(obj,indent=2)+'\n')
pr=get('pulls/1337');ref=get('git/ref/heads/lap/pr-1337');owner=get('git/commits/'+EXPECTED)
save('BEFORE.json',{'PR':pr,'ref':ref,'owner':owner})
assert pr['state']=='open' and pr['draft'] and pr['head']['sha']==HEAD and pr['base']['ref']=='dev'
assert ref['object']['sha']==EXPECTED
assert owner['sha']==EXPECTED and owner['parents']==[] and owner['author']['name']=='polecat-steward'
assert owner['author']['email']=='steward@polecat.live' and owner['author']['date']=='2026-10-26T15:32:44Z'
assert owner['message'].startswith('lap PR #1337 — '+ACTOR+' ')
fresh=get('git/ref/heads/lap/pr-1337');save('IMMEDIATE-REF.json',fresh)
assert fresh['object']['sha']==EXPECTED
cmd=['node','tools/ticket.mjs','lap','1337','--force','--by',ACTOR]
with (OUT/'native.log').open('x') as log:
    result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,cwd='/tmp/tremont-picture-20261026/chicago/4d')
assert result.returncode==0
after=get('git/ref/heads/lap/pr-1337');new=get('git/commits/'+after['object']['sha']);after_pr=get('pulls/1337')
save('AFTER.json',{'PR':after_pr,'ref':after,'owner':new})
assert after['object']['sha']!=EXPECTED and new['parents']==[]
assert new['message'].startswith('lap PR #1337 — '+ACTOR+' ')
assert new['author']['name']=='polecat-steward'
assert after_pr['state']=='open' and after_pr['draft'] and after_pr['head']['sha']==HEAD
created=datetime.datetime.fromisoformat(new['author']['date'].replace('Z','+00:00'))
save('RESULT.json',{'status':'OWNED_NATIVE_LAP_RENEWED_ONLY','old_sha':EXPECTED,'new_sha':after['object']['sha'],'created':created.isoformat(),'expires':(created+datetime.timedelta(hours=3)).isoformat(),'PR':1337,'head_unchanged':HEAD,'native_command':cmd,'native_exit':result.returncode,'ROOT_authorization':'Explicit17:34 ownmarker-only ACK, routinefutureownrenewalsauthorized; neverforeignforce','code_or_model_changes':False})
print((OUT/'RESULT.json').read_text(),flush=True)
