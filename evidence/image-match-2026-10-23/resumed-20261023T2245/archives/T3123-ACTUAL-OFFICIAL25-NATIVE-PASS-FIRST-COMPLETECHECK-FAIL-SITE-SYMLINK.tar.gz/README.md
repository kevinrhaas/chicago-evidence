# T-3123 export/native milestone and first check failure

This uncommitted roof utility uses the 7a base. The lighthouse and officers
piazza are prepared separately. All 25 masters were genuinely exported with
pinned Blender 4.5.3 and native web derivatives. Lake House changes from 66 to
64 triangles: exactly its 360-square-metre cap disappears. The other 24 master
and web files are byte exact. All 342 protected files and 105 master/web
registry rows are exact. The true native sequence, seven population passes,
stable 57-step tail and affected source/scene/entrance/stale checks passed.
The earlier no-conflict --resolve invocation was a no-op, not a rebuild.

All 11 workbook members retain exact XML tags, attributes, text and tails;
non-XML bytes are exact. Original source bytes were restored only after that
proof, then the normal package-index tail ran. Incoming Ames/e96 data is not
included. Integrate actual later dev normally with a new guard baseline before
final group app/matrix/PR work. Never restore this old workbook over incoming
changes.

The first local publish failed because /tmp filled up. Root authorized a
verified generated-mirror eviction and shared workspace cache. Native publish
then exited zero; its actual published-file checker passed 2,175 copies plus
3,208 declared transforms with no unmapped files. Its zero-megabyte footer was
a cosmetic find-on-symlink error, not an accepted size measurement.

The first complete required-reader check failed one of 1,065 steps, with all
18 source paths unchanged: measure_step_isolation.mjs asks git check-ignore
about site/4d/index.html, which Git refuses beyond the derived SITE symlink.
No model code or assertion was weakened. No commit, app acceptance, final
group preflight, CI or image match follows. Children closed normally. The
cache layout must be corrected and the complete check rerun.

TESTED-SOURCE.zip holds 18 exact source/artifact after-images, all SHA256/CRC
checked against the gate binding. Original T-2373, T-2379 and T-2388 remain
open with all picture obligations and DIFFERS/unresolved verdicts. This
selection excludes changing gate logs and live shared-cache bytes.
