"""Actual exported Float32 controls; reads only. No recipe or asset mutation."""
from pathlib import Path
from collections import Counter
import hashlib,json,subprocess,sys,tempfile,math
A=Path('/tmp/chicago-log-integration/chicago/4d');O=Path(__file__).resolve().parent;R=O/'T3123-official25';assert json.loads((R/'RESULT.json').read_text())['status'].startswith('PASS_ACTUAL_OFFICIAL25_')
sys.path.insert(0,str(A/'tools'));from measure_glbs import read_glb
src=Path('/tmp/chicago-fort-integration/T-3105/compare_actual_family.py');ns={'__file__':str(src)};exec(compile(src.read_text().split('manifest=json.loads',1)[0],'held-actual-GLB-reader','exec'),ns);values,signature=ns['values'],ns['signature'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def triangles(path):
 d,b=read_glb(path);out=[]
 for mesh in d['meshes']:
  for p in mesh['primitives']:
   keys=sorted(k for k in p['attributes']if not k.startswith('TEXCOORD_'));attrs={k:values(d,b,p['attributes'][k])for k in keys};inds=[x[0]for x in values(d,b,p['indices'])];mat=json.dumps(d['materials'][p['material']],sort_keys=True,separators=(',',':'))
   for j in range(0,len(inds),3):
    corners=[tuple((k,tuple(0. if x==0 else x for x in attrs[k][i]))for k in keys)for i in inds[j:j+3]];out.append((mat,min(tuple(corners[i:]+corners[:i])for i in range(3))))
 return Counter(out)
before=json.loads((R/'BEFORE.json').read_text());rows=[];target='lake_house_construction__shell_1835.glb'
with tempfile.TemporaryDirectory(prefix='roof-readback-',dir='/workspace/T3122-tmp')as tmp:
 for row in before['family']:
  name=row['asset'];old=Path(tmp)/name;old.write_bytes(subprocess.check_output(['git','show',before['baseline_git']+':chicago/4d/assets/gltf/'+name],cwd=A));assert sha(old)==row['files']['gltf'];new=A/'assets/gltf'/name
  oldsig,oldtris,oldnodes=signature(old);newsig,newtris,newnodes=signature(new);assert oldnodes==newnodes,name+':node drift';changed=name==target
  if changed:
   a,b=triangles(old),triangles(new);removed=list((a-b).elements());assert not(b-a)and len(removed)==2 and oldtris==66 and newtris==64
   area=0.
   for _,tri in removed:
    pts=[dict(c)['POSITION']for c in tri];assert all(p[1]==4.0 for p in pts);assert all(p[0]in(0.,24.)and p[2]in(0.,-15.)for p in pts)
    u=[b-a for a,b in zip(pts[0],pts[1])];v=[b-a for a,b in zip(pts[0],pts[2])];cross=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]);area+=math.sqrt(sum(x*x for x in cross))/2
   assert area==360.0
  else:
   assert (oldsig,oldtris)==(newsig,newtris),name+':default physical/material/confidence/tone/normal/winding drift'
   assert sha(A/'assets/web'/name)==row['files']['web'],name+':default web byte drift'
  rows.append({'asset':name,'target':changed,'old_master_sha256':row['files']['gltf'],'master_sha256':sha(new),'web_sha256':sha(A/'assets/web'/name),'master_byte_equal':sha(new)==row['files']['gltf'],'UV_equal':signature(old,True)[0]==signature(new,True)[0],'old_triangles':oldtris,'new_triangles':newtris,'physical_material_confidence_tone_normal_equal':oldsig==newsig,'cap_only_removed_m2':360 if changed else None});old.unlink()
assert len(rows)==25 and sum(x['target']for x in rows)==1
out={'status':'PASS_GENUINE25_LAKE_CAP_ONLY_24_DEFAULTS_EXACT','rows':rows,'UV_only_defaults':[x['asset']for x in rows if not x['target']and not x['master_byte_equal']],'default_web_bytes_exact':24,'limits':'Actual masters/default web bytes only. Target web loader/roof visibility/native/app/full gates remain owed; no picture match.'};(R/'ACTUAL25-COMPARISON.json').write_text(json.dumps(out,indent=2)+'\n');print(out['status'])
