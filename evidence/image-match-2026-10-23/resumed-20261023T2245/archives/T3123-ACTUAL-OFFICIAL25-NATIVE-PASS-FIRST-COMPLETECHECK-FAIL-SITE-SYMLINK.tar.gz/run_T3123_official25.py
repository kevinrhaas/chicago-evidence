"""Prepared native export/derivative runner. Execute only after root grants the lane."""
from pathlib import Path
import subprocess,os,json,hashlib,datetime
A=Path('/tmp/chicago-log-integration/chicago/4d');O=Path(__file__).resolve().parent
Path('/workspace/T3122-tmp').mkdir(exist_ok=True)
assert os.environ.get('CHICAGO_HEAVY_SLOT')=='T3123_ROOF','No heavy-slot grant'
assert hashlib.sha256((A/'generators/archetypes/fort_structure.py').read_bytes()).hexdigest()=='6c2b7d53ea6e62dbdb61ef331b0ff2ec646e7627b23ef81d16a3d6ea886b5027'
assert hashlib.sha256((A/'generators/archetypes/fort_structure_params.py').read_bytes()).hexdigest()=='81d6a7fbb345082d60272429f0cb92dee751d3c1cbe40624017f572d6e523a5d'
assert not (O/'T3123-official25').exists(),'Never overwrite or retry an actual run'
R=O/'T3123-official25';R.mkdir()
env={**os.environ,'TMPDIR':'/workspace/T3122-tmp','PYTHONDONTWRITEBYTECODE':'1','PATH':'/workspace/shared/tools/usr/bin:'+os.environ['PATH'],'npm_config_cache':'/workspace/shared/npm-cache'};env.pop('CHICAGO_TICKETS_DIR',None)
assert 'CHICAGO_TICKETS_DIR' not in env
assert env.get('ASSET_QUANT_BITS','14')=='14','Unexpected web quantization override'
pin={}
for line in (A/'generators/blender.pin').read_text().splitlines():
    if line.startswith('BLENDER_')and '='in line:
        k,v=line.split('=',1);pin[k]=v.strip().strip('"').strip("'")
assert pin['BLENDER_VERSION']=='4.5.3'
cache=Path('/workspace/shared/blender-dl');archive=cache/pin['BLENDER_URL'].split('/')[-1]
with archive.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==pin['BLENDER_SHA256']
manifest=json.loads((A/'assets/manifest.json').read_text());family={k:v for k,v in manifest['assets'].items()if v.get('archetype')=='fort_structure'};assert len(family)==25
ids=sorted({r['structure_id']for r in family.values()});assert len(ids)==25
baseline=[]
for name,row in sorted(family.items()):
    files={kind:hashlib.sha256((A/'assets'/kind/name).read_bytes()).hexdigest()for kind in ['gltf','web']};baseline.append({'asset':name,'row':row,'files':files})
(R/'BEFORE.json').write_text(json.dumps({'baseline_git':'7a58448ab207e67de14fb7d792ca01258ce8f748','HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=A,text=True).strip(),'scope':'T3123 roof only; incoming Hogan merged/folded; no lighthouse/piazza opt-ins','family':baseline},indent=2)+'\n')
state={'status':'RUNNING_ACTUAL_T3123_OFFICIAL25','start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[]}
def run(label,cmd):
    with(R/(label+'.log')).open('x')as f:p=subprocess.run(cmd,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT)
    state['steps'].append({'label':label,'command':list(map(str,cmd)),'exit_code':p.returncode})
    if p.returncode:state.update(status='FAIL_NATIVE_STEP',failed_step=label,finish=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (R/'RESULT.json').write_text(json.dumps(state,indent=2)+'\n')
    assert p.returncode==0,(label,p.returncode)
run('pinned-version',[str(cache/pin['BLENDER_DIR']/'blender'),'--version'])
assert (R/'pinned-version.log').read_text().splitlines()[0].startswith('Blender 4.5.3')
run('masters',[str(cache/pin['BLENDER_DIR']/'blender'),'--background','-noaudio','--factory-startup','--python','generators/build.py','--','--only',','.join(ids),'--wrote',str(R/'wrote.txt')])
wrote=(R/'wrote.txt').read_text().splitlines();assert sorted(wrote)==sorted(family)and len(wrote)==25
run('web',['bash','tools/web_derivatives.sh','--only',','.join(wrote)])
state.update(status='PASS_ACTUAL_OFFICIAL25_EXPORTS_REAL_WEB_DERIVATIVES_READBACK_OWED',finish=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_master_count=25,atomic_utility='T3123',source_bound_to_actual_current_inputs=True);(R/'RESULT.json').write_text(json.dumps(state,indent=2)+'\n');print(state['status'])
