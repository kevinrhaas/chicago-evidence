from pathlib import Path
import os,json,hashlib,urllib.request,tarfile,io,stat,datetime
os.sched_setaffinity(0,{1});os.nice(19)
B=Path(__file__).parent;ROOT=Path('/tmp/T2385-current-source-native-app-capsule-20261026T2115');EXPECTED='b5c5b287bc9ae88c10f83ff6f503f3860c197e8226230afd08a5f24480f7cc2c';REPO='kevinrhaas/chicago-evidence'
def save(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def h(b):return hashlib.sha256(b).hexdigest()
def gitblob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def raw(commit,path):
 with urllib.request.urlopen('https://raw.githubusercontent.com/'+REPO+'/'+commit+'/'+path,timeout=120)as r:assert r.status==200;return r.read()
def stamp(p):
 s=p.stat();return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,stat.S_IMODE(s.st_mode))
def readers():
 ancestors=set();pid=os.getpid()
 while pid>0 and pid not in ancestors:
  ancestors.add(pid)
  try:
   text=Path('/proc/'+str(pid)+'/stat').read_text();pid=int(text[text.rfind(')')+2:].split()[1])
  except OSError:break
 found=[];unobservable_fds=0;unobservable_maps=0
 for q in Path('/proc').iterdir():
  if not q.name.isdigit()or int(q.name)in ancestors:continue
  try:
   cmd=(q/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
   if str(ROOT)in cmd:found.append({'pid':q.name,'kind':'command','value':cmd[:2000]})
  except OSError:pass
  try:
   for fd in(q/'fd').iterdir():
    try:
     target=os.readlink(fd)
     if target==str(ROOT)or target.startswith(str(ROOT)+'/'):found.append({'pid':q.name,'kind':'fd','value':target})
    except OSError:unobservable_fds+=1
  except OSError:unobservable_fds+=1
  try:
   for line in(q/'maps').read_text().splitlines():
    if str(ROOT)in line:found.append({'pid':q.name,'kind':'map','value':line})
  except OSError:unobservable_maps+=1
 return {'found_readers':found,'unobservable_fd_entries':unobservable_fds,'unobservable_maps':unobservable_maps,'own_process_and_ancestors_excluded':sorted(ancestors),'qualification':'All readable proc cmdlines/FD links/maps examined; restricted sibling proc entries are disclosed, not asserted globally zero. Owner explicitly confirms no current/future native helper dependency on local capsule copies.'}
manifest_bytes=(ROOT/'MANIFEST.json').read_bytes();assert h(manifest_bytes)==EXPECTED;manifest=json.loads(manifest_bytes);rows=list(manifest['members']);rows.append({'path':'MANIFEST.json','bytes':len(manifest_bytes),'sha256':EXPECTED,'mode':stat.S_IMODE((ROOT/'MANIFEST.json').stat().st_mode)})
record=json.loads((B/'PUBLIC-RECORD.json').read_text());entry=json.loads((B/'PUBLIC-AVAILABILITY-ENTRY.json').read_text());commit=entry['verified_committed_at'];transport=record['remote_transport'];parts=[]
for row in transport['parts']:
 data=raw(commit,row['path']);assert len(data)==row['bytes']and h(data)==row['sha256']and gitblob(data)==row['git_blob'];parts.append(data)
archive=b''.join(parts);assert len(archive)==record['bytes']and h(archive)==record['sha256'];del parts
expected={r['path']:r for r in rows};assert len(expected)==len(rows)==137;remote=[]
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz')as tf:
 members=tf.getmembers();assert{m.name for m in members}==set(expected)and len(members)==len(rows)
 for m in members:
  r=expected[m.name];mode=int(r['mode'],0)if isinstance(r['mode'],str)else r['mode'];data=tf.extractfile(m).read();assert m.isfile()and m.size==r['bytes']and m.mode==mode and len(data)==r['bytes']and h(data)==r['sha256'];remote.append({'path':m.name,'bytes':len(data),'sha256':h(data),'mode':m.mode})
del archive
save('IMMUTABLE-ALL137-MEMBER-READBACK.json',{'status':'PASS','commit':commit,'transport':transport,'archive_sha256':record['sha256'],'members':remote})
localfiles={str(p.relative_to(ROOT))for p in ROOT.rglob('*')if p.is_file()};assert localfiles==set(expected);stamps={};local=[]
for name,row in expected.items():
 p=ROOT/name;assert not p.is_symlink();s=stamp(p);data=p.read_bytes();mode=int(row['mode'],0)if isinstance(row['mode'],str)else row['mode'];assert len(data)==row['bytes']and h(data)==row['sha256']and s[-1]==mode;assert stamp(p)==s;stamps[name]=s;local.append({'path':name,'bytes':len(data),'sha256':h(data),'mode':mode,'nlink':p.stat().st_nlink,'allocated':p.stat().st_blocks*512})
save('LOCAL-ALL137-MEMBER-EXACT-BEFORE.json',local);proc=readers();save('READERS-BEFORE.json',proc);assert not proc['found_readers'];assert all(stamp(ROOT/n)==s for n,s in stamps.items())
restore={'status':'REDUNDANT_CLOSED_LOCAL_PAYLOAD_COPIES_RETIRED_AFTER_FRESH_IMMUTABLE_ALL_MEMBER_VERIFICATION','original_manifest_sha256':EXPECTED,'source_manifest_retained':'MANIFEST.json','immutable_publication_commit':commit,'repository':REPO,'archive_sha256':record['sha256'],'archive_bytes':record['bytes'],'remote_transport':transport,'restoration':'Fetch the transport manifest and9ordered parts from the SAME immutable commit; verify each part bytes/SHA256/Gitblob, concatenate and verify whole archive bytes/SHA256, then restore only needed members with original mode and verified source manifest SHA/hash/size. Local payload absence is intentional.','scope':'Only author-confirmed redundant CLOSED b5c5 capsule copy; no source worktree/native holder/model/cache/original/sourceGit/installed runtime/live proof touched. All137 archived members were freshly verified against local original author manifest before retirement.','proc_observability':proc['qualification'],'owner_authorization':'Tremont source owner confirmed no active/future dependency; Mary currentWolf source owner confirms no imminent timed/all4 work and permits CPU1nice19 verification while sole native producer runsCPU3. Native guards unchanged; this optional headroom does not block/retry current producer.'}
before=os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize;removed=[]
for name,row in expected.items():
 if name=='MANIFEST.json':continue
 p=ROOT/name;assert stamp(p)==stamps[name];p.unlink();removed.append(name)
(ROOT/'PAYLOADS-RESTORE.json').write_text(json.dumps(restore,indent=2)+'\n');after=os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize
assert h((ROOT/'MANIFEST.json').read_bytes())==EXPECTED
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ONLY_EXACT_VERIFIED_REDUNDANT_CLOSED_TMP_CAPSULE_PAYLOADS_RETIRED','root':str(ROOT),'removed_members':len(removed),'removed_logical_bytes':sum(r['bytes']for r in rows if r['path']!='MANIFEST.json'),'removed_allocated_bytes_precheck':sum(r['allocated']for r in local if r['path']!='MANIFEST.json'),'tmp_free_before':before,'tmp_free_after':after,'actual_df_gain':after-before,'df_qualification':'A sole native producer is active onCPU3, so global df delta can include concurrent native allocations; per-member precheck allocated bytes are separately recorded.','manifest_retained':True,'restore_locator_retained':True,'immutable_archive_commit':commit,'immutable_source_members_all_verified':137,'no_source_git_or_worktree_or_holder_models_caches_originals_touched':True,'native_guards_unchanged':True};save('RESULT.json',result);print(json.dumps(result,indent=2))
