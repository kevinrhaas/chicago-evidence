"""Root-only V2 ordinary PRIMARY full check; exact4 new paths, aggregate7 versus9117."""
from common import *
a=args(__doc__);base=json.loads((O/'BASE-PREIMAGES.json').read_bytes());assert a.expect_head==base['base_head']and a.ticket==base['ticket'];current(a)
assert a.reviewed_postimages,'Supply the root-reviewed actual4-postimage JSON, never guessed V1/039 hashes'
proof_path=Path(a.reviewed_postimages).resolve();proof_raw=proof_path.read_bytes();proof=json.loads(proof_raw)
assert proof['status']=='ROOT_REVIEWED_T3262_V2_FOUR_SOURCE_PATHS'and proof['root_reviewed']is True
assert proof['head']==a.expect_head and proof['pr_base']==base['pr_base']and proof['tree']==a.expect_tree
four=base['four_paths'];seven=base['all7_paths'];actual=g('diff','--cached','--name-only').decode().splitlines()
assert set(actual)==set(four)==set(proof['postimages'])and len(actual)==4
aggregate=g('diff','--name-only',base['pr_base']).decode().splitlines();assert set(aggregate)==set(seven)and len(aggregate)==7
rows={p:sha((R/p).read_bytes())for p in actual};all7={p:sha((R/p).read_bytes())for p in seven};exact_working(all7)
for p in seven:
 assert sha(g('show',a.expect_head+':'+p))==base['actual_3c_preimage_sha256'][p]
 if p in four:assert re.fullmatch('[0-9a-f]{64}',proof['postimages'][p])and all7[p]==proof['postimages'][p]
 else:assert all7[p]==base['actual_3c_preimage_sha256'][p],('Unreviewed inherited path changed',p)
for p in ['chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md']:
 before=g('show',a.expect_head+':'+p);after=(R/p).read_bytes()
 assert after.endswith(before)and 0<len(after)-len(before)<=4096 and a.ticket.encode()in after[:-len(before)],'Only tiny own-ticket prefixes preserving actual3c bytes'
changelog='chicago/4d/changelog.d/'+a.ticket+'.json';assert changelog in seven and changelog not in four
assert(R/changelog).read_bytes()==g('show',a.expect_head+':'+changelog),'Own inherited first-commit changelog must remain exact'
assert g('rev-parse','origin/dev').decode().strip()==base['pr_base']
config=sha((R/'.git/config').read_bytes());assert config=='5536e1343e7abdacddfce3d5438e08872ad6a33295900466b529df5e0c57e730'
before_refs=refs();before_index=index();floors(8*1048576)
shim=Path('/workspace/early-four-node-fixture-scope-20261029/bin/node');fixture=A/'tools/test_repo_file.mjs'
assert sha(fixture.read_bytes())=='3a481450fb9324d285a08492a526e657a39f51d64aa918ee3f39cb6418bc4289'
prepared=json.loads((O/'PREPARATION.json').read_bytes());assert sha(shim.read_bytes())==prepared['reviewed_native_fixture_shim_sha256']
E['PATH']=str(shim.parent)+':'+E['PATH'];E.update(CHECK_JOBS='4',CHECK_TIMINGS=str(O/'TIMINGS.tsv'),C4D_GATE_REQUIRE_READERS='1',TMPDIR='/tmp',TMP='/tmp',TEMP='/tmp')
assert not(O/'GATE-RESULT.json').exists()
binding=dict(revision='V2',head=a.expect_head,pr_base=base['pr_base'],branch=a.expect_branch,ticket=a.ticket,
 checked_final_staged_tree=a.expect_tree,all_staged_paths=rows,all7_source_sha256=all7,
 exact_path_count=4,aggregate_path_count=7,source_config_sha256=config,index_semantics=before_index,all_refs_before=before_refs,
 reviewed_postimages=str(proof_path),reviewed_postimages_sha256=sha(proof_raw),actual_3c_preimage_sha256=base['actual_3c_preimage_sha256'],
 CHECK_JOBS=4,CPU_affinity=[0,1,3,4],workspace_floor_bytes=536870912,workspace_priced_log_output_reserve=8*1048576,
 caller_tmp_before_after_floor=1800000000,native_fixture_shim=str(shim),native_fixture_shim_sha256=prepared['reviewed_native_fixture_shim_sha256'],
 shim_scope='Existing exact test_repo_file.mjs local-file scratch fixture only. No source/test/runtime bypass.',
 no_inherited_workbook_or_merge_allowlist=True,old039_postimage_pins=False)
save('GATE-BINDING.json',binding);start=time.monotonic();step,reaper=native('check',['bash','tools/check.sh']);current(a);exact_working(all7)
guards=dict(HEAD=g('rev-parse','HEAD').decode().strip()==a.expect_head,staged_tree=g('write-tree').decode().strip()==a.expect_tree,
 tracked_working_bytes=not g('diff','--name-only'),no_untracked=not g('ls-files','--others','--exclude-standard'),no_conflicts=not g('ls-files','-u'),
 staged_path_sha256=all(sha((R/p).read_bytes())==s for p,s in rows.items()),source_hashes=all(sha((R/p).read_bytes())==s for p,s in all7.items()),
 all_refs_exact=refs()==before_refs,index_semantics_exact=index()==before_index,config_exact=sha((R/'.git/config').read_bytes())==config,
 reviewed_four_postimages_exact=all(rows[p]==proof['postimages'][p]for p in four),all_children_reaped=reaper['all_children_reaped'])
text=(O/'check.log').read_text();clean=re.sub(r'\x1b\[[0-9;]*m','',text)
passed=step['exit']==0 and reaper['command_exit']==0 and all(guards.values())and bool(re.search(r'^CHECK PASS — \d+ steps, none red\.$',clean,re.M));floors()
save('GATE-RESULT.json',dict(status='ACTUAL_STANDALONE_PERFORMANCE_V2_FULL_SOURCE_CHECK_PASS'if passed else'ACTUAL_STANDALONE_PERFORMANCE_V2_FULL_SOURCE_CHECK_NOT_QUALIFIED',
 revision='V2',at=now(),exit=step['exit'],seconds=time.monotonic()-start,binding=binding,guards=guards,config_unchanged=guards['config_exact'],footer=text.splitlines()[-15:],step=step,phone_commit_PR_CI_merge_pending=True))
print((O/'GATE-RESULT.json').read_text(),flush=True);raise SystemExit(0 if passed else 1)
