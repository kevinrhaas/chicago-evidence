# T-3262 V2 standalone source gate/checkpoint/current phone controllers

Prepared externally only. No source edit, gate, native commit, phone or smoke was launched by this helper task. V1's real 400.198647/400 MiB phone failure remains in closed checkpoint 730; it is not renamed or reused as a V2 result.

V2 source parent is actual `3c132cbe75bda7eb3960e723129af7fd0ce6d616`; PR comparison base is actual `9117b2263cf0aeb5fea33dec4a87ee519c5b41af` and local origin/dev must still name it. The final new head/tree remain unknown until root's actual gate and ordinary native checkpoint. `BASE-PREIMAGES.json` freezes all seven paths' real 3c preimages, without V1/039 postimage pins.

The new staged delta must be exactly four paths: railway.js, test_rail_geometry_lifecycle.mjs, STATUS.md and ROADMAP.md. The entire branch delta versus 9117 must still be exactly seven. All three inherited paths outside the four remain byte-exact to actual 3c, including the existing own changelog. Both documents must contain only a tiny own-ticket prefix, preserving the entire 3c body.

Root must supply its actual reviewed postimage JSON after applying/staging the four source changes. The schema is:

```json
{
  "status": "ROOT_REVIEWED_T3262_V2_FOUR_SOURCE_PATHS",
  "root_reviewed": true,
  "head": "3c132cbe75bda7eb3960e723129af7fd0ce6d616",
  "pr_base": "9117b2263cf0aeb5fea33dec4a87ee519c5b41af",
  "tree": "ACTUAL_REVIEWED_40_CHARACTER_STAGED_TREE",
  "postimages": {
    "chicago/4d/renderers/web/js/railway.js": "ACTUAL_SHA256",
    "chicago/4d/tools/test_rail_geometry_lifecycle.mjs": "ACTUAL_SHA256",
    "chicago/4d/docs/STATUS.md": "ACTUAL_SHA256",
    "chicago/4d/docs/ROADMAP.md": "ACTUAL_SHA256"
  }
}
```

The placeholders above are descriptive, never runnable inputs or approvals. Gate validation requires exact actual 40/64-character hashes. Root's source review covers lazy attachment of initially hidden tie-pair meshes while preserving their objects/matrices/colors and existing reach behavior; the helper adds no renderer workaround.

Root execution after review, using actual staged tree and branch values:

```sh
python -B /workspace/standalone-phone-memory-v2-controllers-second-fort-20261030/gate.py --expect-head 3c132cbe75bda7eb3960e723129af7fd0ce6d616 --expect-tree ACTUAL_TREE --expect-branch ACTUAL_BRANCH --ticket T-3262 --reviewed-postimages ACTUAL_ROOT_REVIEW_JSON --execute
python -B /workspace/standalone-phone-memory-v2-controllers-second-fort-20261030/checkpoint.py --expect-head 3c132cbe75bda7eb3960e723129af7fd0ce6d616 --expect-tree ACTUAL_TREE --expect-branch ACTUAL_BRANCH --ticket T-3262 --execute
```

Gate runs the unchanged complete ordinary-primary check with four workers, existing exact scratch-file fixture shim, reaper and the same resource/source/index/config/ref guards. `GATE-RESULT.json` status is `ACTUAL_STANDALONE_PERFORMANCE_V2_FULL_SOURCE_CHECK_PASS`; `binding.all_staged_paths` names exactly four, and `binding.all7_source_sha256` binds all seven. Binding also carries revision V2, head, pr_base, checked_final_staged_tree, branch/ticket, reviewed postimage receipt SHA, actual 3c preimages, index semantics, source config and all prior refs. Every guard and native CHECK PASS footer must actually pass.

Checkpoint creates exactly one ordinary native commit with parent 3c and unchanged checked tree. It runs all three PR questions against the 9117 comparison base where appropriate, preserving the first commit's own changelog: check-changelog-entry, resolve_id_collisions, check-changelog. Its status is `ACTUAL_STANDALONE_PERFORMANCE_V2_SOURCE_ONLY_NATIVE_CHECKPOINT_PASS`; actual new SHA is written only after the real commit, all questions and clean-source guards.

Then use that actual new head:

```sh
python -B /workspace/standalone-phone-memory-v2-controllers-second-fort-20261030/phone.py --expect-head ACTUAL_NEW_HEAD --expect-tree ACTUAL_TREE --expect-branch ACTUAL_BRANCH --ticket T-3262 --execute
```

The official complete1904 mobile command and 400 MiB configuration are unchanged. Phone binds the new V2 head/tree, exact gate/checkpoint receipt hashes, all seven current source hashes, source/index/config/refs and actual critical full-gate publication. The V2 gate's native publication is reused without a redundant publish; its working-source bytes are the exact new checked tree. A new result can pass only with a real complete row, no page errors and ≤400 MiB. Its short owned workspace TMP directory is `/workspace/spm2-ph`, retired after the same reaper/source guards. Failure preserves raw metrics and an explicit unqualified result.

`smoke14.py` remains a specifically labeled V2 stage14 BOTH helper. `smoke_map.py` is the generic actual V2-context future controller for native map 1–3,7–12,14, sequential desktop/mobile. It defaults to the entire required map; an explicit subset is allowed only as a partial requested-leg receipt. Full-map BOTH PASS requires all 20 actual stage/viewport runs. Native waits, assertions and timeouts are unchanged; historical long timings are not converted into timely PASS claims.

```sh
python -B /workspace/standalone-phone-memory-v2-controllers-second-fort-20261030/smoke_map.py --expect-head ACTUAL_NEW_HEAD --expect-tree ACTUAL_TREE --expect-branch ACTUAL_BRANCH --ticket T-3262 --outdir /workspace/ACTUAL_NEW_V2_SMOKE_OUTPUT --execute
```

All runtime jobs remain serial on CPUs0,1,3,4. Workspace floor536,870,912 B, shared TMP before/after floor1,800,000,000 B, gate log reserve8 MiB and phone/smoke reserve24 MiB are unchanged. No other native/browser work is implicitly authorized by this preparation. CI, normal fast-forward branch publication, PR1486 current-head checks and safe dev merge remain separate root/publisher work.
