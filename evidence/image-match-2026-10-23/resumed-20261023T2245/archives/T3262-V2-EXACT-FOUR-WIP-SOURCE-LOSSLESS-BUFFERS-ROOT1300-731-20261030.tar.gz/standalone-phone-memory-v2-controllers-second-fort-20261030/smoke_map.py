"""Actual V2 committed ordinary-primary smoke-map runs, sequential native waits/assertions."""
from common import *
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--expect-head',required=True);p.add_argument('--expect-tree',required=True);p.add_argument('--expect-branch',required=True);p.add_argument('--ticket',required=True);p.add_argument('--outdir',required=True);p.add_argument('--stages',default='1,2,3,7,8,9,10,11,12,14');p.add_argument('--execute',action='store_true');a=p.parse_args();assert a.execute
required=[1,2,3,7,8,9,10,11,12,14];stages=list(map(int,a.stages.split(',')));assert stages and len(stages)==len(set(stages))and set(stages)<=set(required)
guard,binding=committed(a);out=Path(a.outdir).resolve();assert out.is_relative_to('/workspace')and not out.is_relative_to(R)and not out.exists();floors(24*1048576);out.mkdir(mode=0o700)
tmp=Path('/workspace/spm2-map');assert not tmp.exists();tmp.mkdir(mode=0o700);(tmp/'OWNED-V2-SMOKE').write_text(a.expect_head+'\n');E.update(TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),SMOKE_TIMING='1')
binding.update(revision='V2',required_stages=required,requested_stages=stages,viewports=['desktop','mobile'],outdir=str(out),TMPDIR=str(tmp),command=['node','tools/smoke_renderer.mjs','--published'],scope='Actual requested stages on both viewports plus native always-on/vendor/page-error checks. Full changed-source map claimed only when every1-3,7-12,14 leg actually passes BOTH. No waits/assertions/timeouts changed.')
save('SMOKE-MAP-BINDING.json',binding);steps=[];pending=None
try:
 for stage in stages:
  for viewport in ['desktop','mobile']:
   guard();shots=out/('stage'+str(stage))/viewport;shots.mkdir(parents=True);E.update(SMOKE_STAGE=str(stage),SMOKE_VIEWPORT=viewport,SMOKE_SHOTS=str(shots))
   name='smoke-map-'+str(stage)+'-'+viewport;pending=name;row,rp=native(name,['node','tools/smoke_renderer.mjs','--published']);guard()
   text=(O/(name+'.log')).read_text();passed=row['exit']==0 and rp['command_exit']==0 and rp['all_children_reaped']and bool(re.search(r'^SMOKE PASS$',text,re.M))
   row.update(viewport=viewport,stage=stage,passed=passed,native_summary=text.splitlines()[-18:],screenshots=[dict(path=str(q),sha256=sha(q.read_bytes()),bytes=q.stat().st_size)for q in sorted(shots.glob('*.png'))]);steps.append(row);pending=None;save('SMOKE-MAP-STEPS.json',steps)
   if not passed:raise RuntimeError('Actual native V2 smoke failed; preserve raw evidence and stop without claiming remaining legs')
finally:
 assert(tmp/'OWNED-V2-SMOKE').read_text()==a.expect_head+'\n'
 reaped=bool(steps)and pending is None and all(r['all_children_reaped']for r in steps)
 if reaped:shutil.rmtree(tmp)
 guards_exact=True;guard_error=None
 try:guard()
 except BaseException as error:guards_exact=False;guard_error=str(error)
 floors();full=guards_exact and reaped and set(stages)==set(required)and len(steps)==2*len(required)and all(r['passed']for r in steps);partial=guards_exact and reaped and len(steps)==2*len(stages)and all(r['passed']for r in steps)
 save('SMOKE-MAP-RESULT.json',dict(status='ACTUAL_STANDALONE_V2_CURRENT_PUBLISHED_CHANGED_SOURCE_FULL_MAP_BOTH_PASS'if full else'ACTUAL_STANDALONE_V2_CURRENT_PUBLISHED_REQUESTED_SMOKE_LEGS_PASS'if partial else'ACTUAL_STANDALONE_V2_CURRENT_PUBLISHED_SMOKE_MAP_NOT_QUALIFIED',
  revision='V2',at=now(),head=a.expect_head,tree=a.expect_tree,source_parent=binding['base'],pr_base=binding['pr_base'],branch=a.expect_branch,ticket=a.ticket,steps=steps,required_stages=required,requested_stages=stages,all7_source_sha256=binding['all7_source_sha256'],source_gate_sha256=binding['source_gate_sha256'],native_checkpoint_sha256=binding['native_checkpoint_sha256'],
  full_changed_source_map_BOTH_ACTUALLY_passed=full,all_children_reaped=reaped,pending_or_unclosed_step=pending,guards_before_after_exact=guards_exact,guard_error=guard_error,native_waits_assertions_timeouts_viewports_unchanged=True,old3c_source_phone_or_smokes_not_relabelled=True))
print((O/'SMOKE-MAP-RESULT.json').read_text(),flush=True)
