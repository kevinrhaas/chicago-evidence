T-3262 finalV2 externalcandidate, readyforrootguardedadoption.

Only the2postimages listed inRESULT are adopted. All16V1files remain frozenbyteexact. V2 adds conditional instanceBoundingBox recomputation after count/fullarraysinstallation because a boundsvisitor may have cached an emptybox while a shell hadcount0. An uncomputed nullbox remainsnull; exactoriginalnearSphere and sharedfarSphere still computed asbefore. Newpure actual-producer oraclefirst cachesemptynear/farboxes thencomparesinstalledbounds toformer eagerbound computation.

ActualexternalNodeunitPASS434, allchildrenreaped, priorgoldenrailhash unchanged. Wholematrix/colorBYTEoracle, spheres/sharing/names/materials/Object3Did-slot order, canonical44B/fullfallback76B includingmixednoncanonical/-0, zero shells, tier/reach/reentry/installonce/disposal remainvalid. Nootherfeature or assertionchange.

TypedCPUaccount unchanged:123288ties/57zones,0fallbackzones; initial3945216B/3.762MiB lesspayload; conservative lightmax6zonefirstreach leaves3458400B/3.298MiB lesspayload. Flatheightaccount only validatescounts/fixedlanes, notactualterrain geometry or heapGC. Smallheaders/transientpacking/installpeaks excluded. Inactive invisiblecount0shells mayhaveuncomputedbounds; after reach visiblematrix/color/sphere and anyalreadycachedbox are exact. Analyticpicking/shader/precision/reach rules untouched. NoGPU-saving claim.

Primaryremainscleanrecorded3cHEAD/preimages. No source/Git/API/browser/publish/fullgate/meter run here. Rootmust complete actualnewsourcegate, currentofficial400phone and appropriatepublishedBOTHsmoke/CI beforemerge. The earlier400.198647phone remainsfailed and is notrerunforgreen.
