"""Bounded native-commit transport. Default is read-only planning; no git push/fetch.

Run only after the actual checked final native commits exist. --publish additionally
requires the exact checked final tree, a passing gate receipt, and explicit expected
remote branch state. Native Git SHAs, trees, messages, author dates and parents stay exact.
"""
from pathlib import Path
import argparse,base64,datetime,hashlib,json,os,re,struct,subprocess,time
from urllib.request import Request,urlopen
from urllib.error import HTTPError

REPO='kevinrhaas/chicago';SOURCE=Path('/workspace/chicago');G=SOURCE/'.git'
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*args):
    return subprocess.check_output(['git','-C',str(SOURCE),'-c','gc.auto=0','-c','maintenance.auto=false','-c','protocol.allow=never',*args],env=ENV)
def shab(b):return hashlib.sha256(b).hexdigest()
def gitsha(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def api(path,data=None,method=None,missing=False):
    # Mutable branch/PR/dev reads must never reuse a cached pre-create404.
    actual_method=method or ('GET'if data is None else'POST')
    if actual_method=='GET':path+=('&'if'?'in path else'?')+'codex_read='+str(time.time_ns())
    req=Request('https://api.github.com/repos/'+REPO+'/'+path,data=None if data is None else json.dumps(data).encode(),headers={'User-Agent':'Chicago-standalone-phone-memory-native-transport','Accept':'application/vnd.github+json','Content-Type':'application/json'},method=actual_method)
    try:
        with urlopen(req,timeout=120)as r:return json.load(r)
    except HTTPError as e:
        if missing and e.code==404:return None
        raise
def indexed(wanted):
    wanted=set(wanted);found={s for s in wanted if(G/'objects'/s[:2]/s[2:]).is_file()}
    for p in(G/'objects/pack').glob('*.idx'):
        if wanted<=found:break
        with p.open('rb')as f:
            h=f.read(8);v2=h[:4]==b'\xfftOc';off=8 if v2 else 0
            if v2:assert struct.unpack('>I',h[4:])[0]==2
            f.seek(off);fan=struct.unpack('>256I',f.read(1024));tab=off+1024;stride=20 if v2 else 24;delta=0 if v2 else 4
            for s in wanted-found:
                key=bytes.fromhex(s);a=0 if key[0]==0 else fan[key[0]-1];z=fan[key[0]]
                while a<z:
                    m=(a+z)//2;f.seek(tab+m*stride+delta)
                    if f.read(20)<key:a=m+1
                    else:z=m
                f.seek(tab+a*stride+delta)
                if a<fan[key[0]]and f.read(20)==key:found.add(s)
    return found
def obj(kind,s):
    assert s in indexed([s]),'Refuse unknown promisor-object read: '+s
    b=git('cat-file',kind,s);assert gitsha(kind,b)==s;return b
TREES={}
def leaves(s):
    if s in TREES:return TREES[s]
    b=obj('tree',s);i=0;out={}
    while i<len(b):
        n=b.index(b' ',i);mode=b[i:n].decode();z=b.index(b'\0',n+1);name=b[n+1:z].decode();child=b[z+1:z+21].hex();i=z+21
        assert name not in ('.','..')and'/'not in name
        if mode=='40000':out.update({name+'/'+p:v for p,v in leaves(child).items()})
        else:
            assert mode in('100644','100755','120000','160000')
            out[name]=(mode,'commit'if mode=='160000'else'blob',child)
    TREES[s]=out;return out
def commit(s):
    raw=obj('commit',s);header,msg=raw.split(b'\n\n',1);lines=header.decode().splitlines()
    return {'sha':s,'raw_sha256':shab(raw),'raw':raw,'lines':lines,'message':msg.decode(),'tree':next(x[5:]for x in lines if x.startswith('tree ')),'parents':[x[7:]for x in lines if x.startswith('parent ')]}
def native_payload(c):
    assert all(x.startswith(('tree ','parent ','author ','committer '))for x in c['lines']),'Unsupported signed/extra native header; do not rewrite native commit'
    p={'tree':c['tree'],'parents':c['parents'],'message':c['message']}
    for k in['author','committer']:
        line=next(x for x in c['lines']if x.startswith(k+' '));m=re.fullmatch(k+r' (.*) <([^>]+)> (\d+) ([+-]\d{4})',line);assert m
        zone=m[4];offset=(int(zone[1:3])*60+int(zone[3:]))*60*(1 if zone[0]=='+'else-1)
        dt=datetime.datetime.fromtimestamp(int(m[3]),datetime.timezone(datetime.timedelta(seconds=offset)))
        p[k]={'name':m[1],'email':m[2],'date':dt.isoformat()}
    return p
def snapshot():
    return {'HEAD':git('rev-parse','HEAD').decode().strip(),'refs':git('for-each-ref','--format=%(refname) %(objectname)').decode().splitlines(),'metadata':{n:shab((G/n).read_bytes())for n in['HEAD','index','config','MERGE_HEAD','MERGE_MSG']if(G/n).is_file()},'status':git('status','--porcelain','--untracked-files=all').decode()}
OLD='3c132cbe75bda7eb3960e723129af7fd0ce6d616'
PRBASE='9117b2263cf0aeb5fea33dec4a87ee519c5b41af'
BRANCH='steward/t3262-phone-renderer-memory';TICKET='T-3262';PR=1486
FOUR={'chicago/4d/renderers/web/js/railway.js','chicago/4d/tools/test_rail_geometry_lifecycle.mjs','chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md'}
SEVEN=FOUR|{'chicago/4d/renderers/web/js/spatial-batch.js','chicago/4d/tools/check_confidence_lane.mjs','chicago/4d/changelog.d/T-3262.json'}
def main():
    from urllib.parse import quote
    a=argparse.ArgumentParser(description='Exact ordinary V2 four-path FF update of existing T3262PR1486. Default readonly plan.')
    for k in ['base','head','qualified-tree','gate-proof','output']:a.add_argument('--'+k,required=True)
    a.add_argument('--expected-old',default=OLD);a.add_argument('--branch',default=BRANCH)
    a.add_argument('--max-total-bytes',type=int,default=4*1024**2);a.add_argument('--publish',action='store_true');args=a.parse_args()
    os.sched_setaffinity(0,{2});os.nice(19)
    assert args.base==PRBASE and args.expected_old==OLD and args.branch==BRANCH
    assert re.fullmatch('[0-9a-f]{40}',args.head)and re.fullmatch('[0-9a-f]{40}',args.qualified_tree)and args.head not in [OLD,PRBASE]
    assert 0<args.max_total_bytes<=4*1024**2
    out=Path(args.output);out.mkdir(exist_ok=False);save=lambda n,x:(out/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
    before=snapshot();save('SOURCE-BEFORE.json',before)
    assert before['HEAD']==args.head and not before['status']and not(G/'MERGE_HEAD').exists()and git('branch','--show-current').decode().strip()==BRANCH
    base=commit(PRBASE);old=commit(OLD);head=commit(args.head);assert old['parents']==[PRBASE]and head['parents']==[OLD]and head['tree']==args.qualified_tree
    payload=native_payload(head);oldleaves=leaves(old['tree']);tip=leaves(head['tree']);baseleaves=leaves(base['tree'])
    changes={p:tip.get(p)for p in sorted(set(oldleaves)|set(tip))if oldleaves.get(p)!=tip.get(p)}
    aggregate={p:tip.get(p)for p in sorted(set(baseleaves)|set(tip))if baseleaves.get(p)!=tip.get(p)}
    prior={p:oldleaves.get(p)for p in sorted(set(baseleaves)|set(oldleaves))if baseleaves.get(p)!=oldleaves.get(p)}
    assert set(changes)==FOUR and set(aggregate)==SEVEN and set(prior)==SEVEN
    assert all(v is not None and v[:2]==('100644','blob')for v in aggregate.values())
    assert all(tip[p]==oldleaves[p]for p in SEVEN-FOUR),'Other three source paths must remain exact3c'
    allbytes={p:obj('blob',v[2])for p,v in aggregate.items()};allsha={p:shab(b)for p,b in allbytes.items()};newbytes={p:allbytes[p]for p in FOUR}
    assert sum(map(len,allbytes.values()))<=args.max_total_bytes and sum(map(len,newbytes.values()))<=args.max_total_bytes
    gate_path=Path(args.gate_proof);gate_raw=gate_path.read_bytes();gate=json.loads(gate_raw)
    assert gate.get('status')=='ACTUAL_STANDALONE_PERFORMANCE_V2_FULL_SOURCE_CHECK_PASS'and gate.get('exit')==0
    needed_guards={'HEAD','staged_tree','tracked_working_bytes','no_untracked','no_conflicts','staged_path_sha256','all_children_reaped'}
    assert needed_guards<=set(gate.get('guards',{}))and all(v is True for v in gate['guards'].values())
    assert gate.get('config_unchanged')is True and any('CHECK PASS'in line for line in gate.get('footer',[]))
    b=gate.get('binding',{});assert b.get('head')==OLD and b.get('pr_base')==PRBASE and b.get('revision')=='V2'and b.get('checked_final_staged_tree')==args.qualified_tree
    assert b.get('branch')==BRANCH and b.get('ticket')==TICKET and b.get('source_config_sha256')==shab((G/'config').read_bytes())
    assert b.get('all_staged_paths')=={p:allsha[p]for p in FOUR}and b.get('all7_source_sha256')==allsha
    assert all(shab((SOURCE/p).read_bytes())==h for p,h in allsha.items())
    remote_old=api('git/commits/'+OLD);assert remote_old['tree']['sha']==old['tree']and[p['sha']for p in remote_old['parents']]==[PRBASE]
    existing=api('git/commits/'+args.head,missing=True)
    if existing:assert existing['tree']['sha']==head['tree']and[p['sha']for p in existing['parents']]==[OLD]
    branch_path='git/ref/heads/'+quote(BRANCH,safe='/')
    assert api(branch_path)['object']['sha']==OLD,'Fresh exact existing3c ref required; never recreate/force'
    pr=api('pulls/'+str(PR));assert pr['state']=='open'and pr['head']['sha']==OLD and pr['head']['ref']==BRANCH and pr['base']['ref']=='dev'
    dev_before=api('git/ref/heads/dev')['object']['sha']
    known_blobs={v[2]for v in oldleaves.values()if v[1]=='blob'};uploads={changes[p][2]:newbytes[p]for p in FOUR if changes[p][2]not in known_blobs}
    assert sum(map(len,uploads.values()))<=args.max_total_bytes
    plan={'status':'EXACT_NATIVE_V2_FOUR_PATH_FF_UPDATE_OF_EXISTING_PR1486_PLANNED_NO_WRITES','base':PRBASE,'expected_old':OLD,'head':args.head,'tree':args.qualified_tree,'parents':[OLD],'branch':BRANCH,'ticket':TICKET,'PR':PR,'force':False,'branch_creation_allowed':False,'new_PR_allowed':False,'cache_bust':'EveryGET appends codex_read=time_ns, including branch/PR/dev','current_dev_read_before':dev_before,'native_commit_raw_sha256':head['raw_sha256'],'changed_four':{p:{'blob':changes[p][2],'sha256':allsha[p],'bytes':len(allbytes[p])}for p in sorted(FOUR)},'aggregate_seven_source_sha256':allsha,'other_three_byte_exact_to3c':sorted(SEVEN-FOUR),'all_seven_postimage_bytes':sum(map(len,allbytes.values())),'four_postimage_bytes':sum(map(len,newbytes.values())),'new_upload_blob_bytes':sum(map(len,uploads.values())),'max_total_bytes':args.max_total_bytes,'already_remote_native_commit':existing is not None,'gate':{'path':str(gate_path),'sha256':shab(gate_raw)}}
    save('PLAN.json',plan);assert snapshot()==before
    if not args.publish:print(json.dumps({'status':plan['status'],'head':args.head,'four_postimage_bytes':plan['four_postimage_bytes']}));return
    for s,content in uploads.items():result=api('git/blobs',{'encoding':'base64','content':base64.b64encode(content).decode()});assert result['sha']==s
    if not existing:
        tree=api('git/trees',{'base_tree':old['tree'],'tree':[{'path':p,'mode':v[0],'type':v[1],'sha':v[2]}for p,v in changes.items()]});assert tree['sha']==head['tree']
        made=api('git/commits',payload);save('NATIVE-COMMIT.json',made);assert made['sha']==args.head,'Native SHA may not be rewritten'
    assert snapshot()==before and api(branch_path)['object']['sha']==OLD
    fresh_pr=api('pulls/'+str(PR));assert fresh_pr['state']=='open'and fresh_pr['head']['sha']==OLD and fresh_pr['head']['ref']==BRANCH and fresh_pr['base']['ref']=='dev'
    # The sole ref mutation: an ordinary fast-forward PATCH, never create orforce.
    changed=api('git/refs/heads/'+quote(BRANCH,safe='/'),{'sha':args.head,'force':False},method='PATCH');assert changed['object']['sha']==args.head
    assert api(branch_path)['object']['sha']==args.head
    public=api('git/commits/'+args.head);assert public['tree']['sha']==args.qualified_tree and[p['sha']for p in public['parents']]==[OLD]
    readback=[]
    for p,v in sorted(aggregate.items()):
        request=Request('https://raw.githubusercontent.com/'+REPO+'/'+args.head+'/'+quote(p,safe='/')+'?codex_read='+str(time.time_ns()),headers={'User-Agent':'Chicago-standalone-phone-memory-native-V2-FF-transport'})
        with urlopen(request,timeout=120)as response:assert response.status==200;content=response.read()
        assert content==allbytes[p]and gitsha('blob',content)==v[2];readback.append({'path':p,'sha256':shab(content),'git_blob':v[2],'bytes':len(content),'changed_in_V2':p in FOUR})
    save('IMMUTABLE-READBACK.json',{'status':'ALL_FOUR_V2_AND_ALL_SEVEN_AGGREGATE_IMMUTABLE_PATHS_BYTE_EXACT','head':args.head,'rows':readback})
    # GitHub may update PR metadata after the ref. Poll only fresh read-onlyGETs;
    # never retry a mutation or accept an unexpected third head.
    attempts=[];final_pr=None
    for attempt in range(12):
        current=api('pulls/'+str(PR));attempts.append({'attempt':attempt+1,'head':current['head']['sha'],'state':current['state']})
        assert current['state']=='open'and current['head']['ref']==BRANCH and current['base']['ref']=='dev'and current['head']['sha']in [OLD,args.head]
        if current['head']['sha']==args.head:final_pr=current;break
        time.sleep(1)
    save('PR-HEAD-READBACK.json',{'attempts':attempts,'actual_head':None if final_pr is None else final_pr['head']['sha']})
    assert final_pr is not None,'ExistingPR head not yet caught up; preserve published ref and all receipts, never recreate/force'
    assert api(branch_path)['object']['sha']==args.head
    after=snapshot();save('SOURCE-AFTER.json',after);assert after==before
    result={'status':'EXACT_NATIVE_V2_FF_EXISTING_BRANCH_PR1486_ALL_SEVEN_IMMUTABLE_READBACK_PASS','base':PRBASE,'expected_old':OLD,'head':args.head,'tree':args.qualified_tree,'parents':[OLD],'branch':BRANCH,'PR':PR,'PR_url':final_pr['html_url'],'force':False,'branch_created':False,'PR_created':False,'PR_body_or_title_API_write':False,'cache_busted_mutable_reads':True,'changed_four':sorted(FOUR),'readback':readback,'all7_source_sha256':allsha,'source_HEAD_index_config_refs_status_unchanged':True,'current_dev_read_before':dev_before,'current_dev_read_after':api('git/ref/heads/dev')['object']['sha'],'no_merge_ticket_state_main_or_production_action':True};save('RESULT.json',result);print(json.dumps({'status':result['status'],'head':args.head,'PR':final_pr['html_url']}))
if __name__=='__main__':main()
