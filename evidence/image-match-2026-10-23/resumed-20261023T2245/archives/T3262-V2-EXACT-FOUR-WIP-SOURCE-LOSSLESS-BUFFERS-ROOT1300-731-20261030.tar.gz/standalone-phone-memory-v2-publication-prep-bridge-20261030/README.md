# T-3262 V2: normal FF publication to existing PR1486 — prepared, unrun

This controller derives from the reviewed V1 native GitData helper. It is fixed to existing branch `steward/t3262-phone-renderer-memory`, current expected remote head `3c132cbe75bda7eb3960e723129af7fd0ce6d616`, initial PR base `9117b2263cf0aeb5fea33dec4a87ee519c5b41af` and existing PR1486.

The new native commit must have exactly the one parent3c. Its revision diff may change only railway.js, test_rail_geometry_lifecycle.mjs, STATUS.md and ROADMAP.md. Aggregate changes versus9117 must remain exactly the original seven paths; spatial-batch.js, check_confidence_lane.mjs and changelog.d/T-3262.json must remain byte-identical to3c. All postimages and new blobs stay below the approved4MiB cap.

The actual V2 full-source gate must bind those four hashes, all seven final source hashes, parent3c, PR base9117, revisionV2, branch/ticket, exact new tree and unchanged config, with the source/reaper guards and actual CHECKPASS footer. A clean native checked HEAD, exact native commit metadata/SHA/parent and all source/Git snapshot guards are required. The schema matches the second_fort_ready V2 gate controller; no old source/phone receipt can substitute.

## Cache and publication behavior

**Every GET appends `codex_read=time_ns`, including mutable branch, PR and current-dev reads.** This prevents reuse of the cached pre-create404 that affected the first branch publication. The branch must already exist at3c and PR1486 must be open on that head. There is no branch creation or PR creation path in this controller.

Default execution plans only. With `--publish`, the helper creates the four actual postimage blobs and exact native tree/commit if absent, freshly rechecks the existing ref at3c, then performs one ordinary PATCH with `force:false`. No force or branch recreation is possible. It reads all four revision paths and all seven aggregate paths through immutable commit URLs, verifies exact bytes/Gitblobs/hashes and reads PR1486 back at the new head. A short read-only fresh-GET poll permits PR metadata to catch up with its ref; an unexpected third head refuses. It never retries a mutation.

PUBLICATION is not a merge. The existing first phone failure400.198647MiB remains a failure; current source, later official phone and required GitHub CI must qualify the new head before any normal merge. No source/ref/controller execution has occurred during preparation.

## Later invocation after root review and actual new gate/native commit

```bash
source /workspace/shared/resume-chicago-env.sh
PYTHONDONTWRITEBYTECODE=1 python /workspace/standalone-phone-memory-v2-publication-prep-bridge-20261030/publish_native_v2.py \
  --base 9117b2263cf0aeb5fea33dec4a87ee519c5b41af \
  --expected-old 3c132cbe75bda7eb3960e723129af7fd0ce6d616 \
  --head ACTUAL_NEW_CHECKED_NATIVE_HEAD --qualified-tree ACTUAL_NEW_CHECKED_TREE \
  --gate-proof ACTUAL_V2_RUN/GATE-RESULT.json \
  --output /workspace/ACTUAL_V2_READONLY_PUBLICATION_PLAN
```

After reviewing the actual plan, use a new output directory and add `--publish`. Do not supply guessed IDs. If a later readback fails after the ref update, preserve every receipt and verify the already-published exact head; a fresh publication run intentionally refuses because the ref is no longer3c. Never recreate, reset or force the branch to recover.

The helper preserves native author/committer/timestamps/message/tree/parents; local HEAD/index/config/status/all refs stay exact. No new PR, body/title edit, ticket state transition, dev merge, main or production action is included. README, prepared metadata and V1-to-V2 semantic diff are frozen for root review. Only syntax was parsed; the controller and API were not executed in this task.
