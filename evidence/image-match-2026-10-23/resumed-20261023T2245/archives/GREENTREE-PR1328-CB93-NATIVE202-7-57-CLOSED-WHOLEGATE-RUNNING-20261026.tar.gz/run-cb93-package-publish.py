from pathlib import Path
import os,subprocess,json,datetime,shutil
r=Path('/tmp/chicago-green-tree-integration');a=r/'chicago/4d';h=Path('/tmp/green-tree-T2376-20261025')
os.sched_setaffinity(0,{1});env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(TMPDIR='/tmp/gt-nativecb',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
assert json.loads((h/'RESOLVECB93-RESULT.json').read_text())['exit_code']==0
assert json.loads((h/'ALL-BINARY-OUTSIDECB93-PARITY.json').read_text())['status']=='PASS'
mem_limit=int(Path('/sys/fs/cgroup/memory.max').read_text());mem_current=int(Path('/sys/fs/cgroup/memory.current').read_text());assert mem_limit-mem_current>=512*1024**2
assert shutil.disk_usage(env['TMPDIR']).free>=512*1024**2,'Root-required512MiB caller disk reserve'
results=[]
for command,name in [(['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'],'package5cb93.log'),(['bash','tools/publish.sh'],'publishcb93.log')]:
 assert shutil.disk_usage(env['TMPDIR']).free>=512*1024**2,'Caller disk reserve'
 assert int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text())>=512*1024**2,'Caller memory reserve'
 with (h/name).open('x')as log:process=subprocess.run(command,cwd=a,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':command,'exit_code':process.returncode,'log':str(h/name)})
 print('ACTUAL_COMMAND',command,process.returncode,flush=True)
 if process.returncode:break
passed=len(results)==2 and all(x['exit_code']==0 for x in results)
p={'status':'PASS'if passed else'FAIL','finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':results,'cpu_affinity':sorted(os.sched_getaffinity(0)),'caller_reserve_start':mem_limit-mem_current}
(h/'PACKAGE5-PUBLISHCB93-RESULT.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p,indent=2),flush=True);raise SystemExit(0 if passed else 1)
