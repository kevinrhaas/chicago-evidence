from pathlib import Path
import os,json,hashlib,subprocess,datetime
r=Path('/tmp/chicago-green-tree-integration');a=r/'chicago/4d';h=Path('/tmp/green-tree-T2376-20261025');g=json.loads((h/'GUARDS-CB93-BEFORE.json').read_text());binary=json.loads((h/'ALL-XLSX-GZIP-CB93-BASELINE.json').read_text())
def gitjson(ref,p):return json.loads(subprocess.check_output(['git','show',ref+':chicago/4d/'+p],cwd=r,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'}))
for name,group in [('protected',g['protected']),('physical_and_incoming_controls',g['asset_files']),('all44binary',{p:v['sha256']for p,v in binary['records'].items()})]:
 for p,value in group.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==value,p
manifests={}
family_keys={k for k,v in gitjson(g['own'],'assets/manifest.json')['assets'].items()if v.get('archetype')=='frame_tavern'}
assert len(family_keys)==23
for p in ['assets/manifest.json','assets/manifest.web.json']:
 key='assets'if p=='assets/manifest.json'else'masters'
 own=gitjson(g['own'],p)[key];incoming=gitjson(g['incoming'],p)[key];current=json.loads((a/p).read_text())[key];family={k:own[k]for k in family_keys};assert len(family)==23,(p,len(family))
 assert set(current)==set(incoming)|set(family),p
 for k,v in current.items():assert v==(family[k]if k in family else incoming[k]),(p,k)
 manifests[p]={'own_family_rows_exact':len(family),'incoming_nonfamily_rows_exact':len(current)-len(family)}
for p in ['data/sidecars/1835/green_tree_tavern.json']:
 assert json.loads((a/p).read_text())==gitjson(g['own'],p),p
source=json.loads((h/'CB93-STRICT-SMOKE-REPAIRS-CONTRACT.json').read_text())
for p,value in source['source'].items():assert hashlib.sha256((a/p).read_bytes()).hexdigest()==value,p
proof={'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'incoming':g['incoming'],'own':g['own'],'protected_exact':len(g['protected']),'physical_and_incoming_controls_exact':len(g['asset_files']),'all_binary_raw_incoming_exact':len(binary['records']),'manifest_rows':manifests,'GTsidecar_exact_own':True,'authorized5path_repair_source_exact':True,'no_family_rebake':True}
(h/'GUARDSCB93-AFTER.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
