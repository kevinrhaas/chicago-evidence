from pathlib import Path
import subprocess,json,time,datetime,hashlib
P=Path('/workspace/shared/T2380-integrate8f-endgame-20261026T1506');repo=Path('/tmp/jail-picture-c6');out=P/'private-publication-repeat-v2';out.mkdir(mode=0o700)
def save(n,x):(out/n).write_text(json.dumps(x,indent=2)+'\n')
print('WAIT actualwhole3closed0/1073/385; privateCODEcommit+newverificationref ONLY, neveroriginal1333branch/READY/merge.',flush=True)
while True:
 try:r=json.loads((P/'required-preflight-repeat-v2-reaper.json').read_text())
 except(FileNotFoundError,json.JSONDecodeError):time.sleep(5);continue
 if r['command_exit']is not None:break
 time.sleep(5)
assert r['command_exit']==0 and r['all_children_reaped'],('WHOLE3_NOT_CLOSED_PASS',r)
pre=json.loads((P/'required-preflight-repeat-v2/RESULT.json').read_text());assert pre['status']=='ALL3_NATIVE_PREFLIGHT_PASS'and pre['exact_expected_footer_count']and all(pre['guards'].values())
with(out/'normal-private-commit-and-endingchecks.log').open('x')as f:q=subprocess.run(['python3',str(P/'commit-private-after-repeat-v2.py')],stdout=f,stderr=subprocess.STDOUT)
assert q.returncode==0;C=json.loads((P/'checked-commit/RESULT.json').read_text());assert C['status']=='ACTUAL_CHECKED_TREE_NORMAL_COMMIT_AND_COMMITTED_GATES_PASS';head=C['head'];branch='verification/t2380-8f-release-partition-'+head[:12]+'-20261026';g=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo).decode().strip();assert g('rev-parse','HEAD')==head and not g('diff','--name-only');existing=g('ls-remote','origin','refs/heads/'+branch);assert not existing or existing.split()[0]==head,'Neveroverwriteforeignverificationref'
if not existing:
 with(out/'normal-new-verification-ref-push.log').open('x')as f:q=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','push','origin','HEAD:refs/heads/'+branch],cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 assert q.returncode==0,'No force/retryloop'
actual=g('ls-remote','origin','refs/heads/'+branch);assert actual.split()[0]==head;result={'status':'ACTUAL1073_385_ALL3_COMMITTED_ENDINGCHECKS_PRIVATE_CODE_REF_PUSHED_NOT_PUBLIC1333_UPDATE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'tree':C['tree'],'parents':C['parents'],'tested_base':C['actual_committed_base'],'verification_branch':branch,'remote_ref_verified':actual,'native_hashes':json.loads((P/'checked-commit/FROZEN-NATIVE-SMOKE-HASHES.json').read_text()),'PUBLIC1333':'Externallyowned6b724DRAFTfalse; no originalbranchpush/ready/merge bythisactor. Rootreviewsownership.','source_repair':'Native release metadata partition +meaningful21CLIgitfixturechecks; cantransferafterlegitimatepublishedJailmerge intoMaryownM','no_renderer_assert_caps_relaxed':True,'no_smoke_dispatch_or_acceptance':True,'original2380':'DIF/notDONE'};save('RESULT.json',result);files=[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':oct(p.stat().st_mode&0o777)}for p in sorted(out.iterdir())if p.is_file()];m=out/'MANIFEST.json';m.write_text(json.dumps({'files':files},indent=2)+'\n');print(json.dumps(result,indent=2),flush=True);print(str(m),hashlib.sha256(m.read_bytes()).hexdigest(),flush=True)
