from pathlib import Path
import sys,json,math,datetime,hashlib
r=Path('/tmp/chicago-green-tree-integration/chicago/4d');out=Path('/workspace/T2376-wagon-bay-followthrough-20261026');sys.path.insert(0,str(r/'tools'));import generate_yard_goods as geom
cars={}
for f in(r/'data/sidecars/1835').glob('*.json'):
 d=json.loads(f.read_text())
 if isinstance(d,dict)and d.get('id')and d.get('placement'):cars[d['id']]=d
sc=cars['green_tree_tavern'];place=sc['placement'];poly=sc['footprint']['polygon'];angle=math.radians(place['rotation_deg']);cs,sn=math.cos(angle),math.sin(angle)
def enu(u,v):return(place['local_e']+u*cs+v*sn,place['local_n']-u*sn+v*cs)
def local(e,n):return((e-place['local_e'])*cs-(n-place['local_n'])*sn,(e-place['local_e'])*sn+(n-place['local_n'])*cs)
def rectangle(at,bearing,length,depth):
 b=math.radians(bearing);c,s=math.cos(b),math.sin(b)
 return[(at[0]+u*c+v*s,at[1]-u*s+v*c)for u,v in[(-length/2,-depth/2),(length/2,-depth/2),(length/2,depth/2),(-length/2,depth/2)]]
u1=max(p[0]for p in poly);v0=min(p[1]for p in poly);v1=max(p[1]for p in poly);length=4.05;depth=3.2;goods=json.loads((r/'data/yard/town_trade_goods.json').read_text());shed=next(x for x in goods['sheds']if x['id']=='green_tree_tavern_wagon_shed');wagon=next(x for x in goods['wagons']if x['id']=='green_tree_tavern_shed_wagon');assert shed['at_local_enu_m']==wagon['at_local_enu_m'];world=geom._town_world(cars);walls=[x for x in world['walls']if x[0]!='green_tree_tavern'];world['walls']=walls;hf=world['hf'];ap=json.loads((r/'data/enclosures/town_entrance_aprons.json').read_text());door=next(x for x in ap['entrances']if x['structure_id']=='green_tree_tavern');du,dv=local(*door['at_local_enu_m']);assert abs(dv-v1)<.011,(du,dv,v1)
objects=[]
def scan(d,path,owner=None):
 if isinstance(d,dict):
  owner=d.get('belongs_to')or d.get('structure_id')or owner;at=d.get('at_local_enu_m')
  if isinstance(at,list)and len(at)==2:
   ident=d.get('id')or path;kind=d.get('kind','unknown')
   if ident not in['green_tree_tavern_wagon_shed','green_tree_tavern_shed_wagon']:
    if kind in['covered','farm_box','cart']:quad=geom._wagon_ground(d)
    elif kind=='bench':quad=rectangle(at,d.get('bearing_deg')or 0,1.83,.36)
    elif kind=='crate':quad=rectangle(at,d.get('bearing_deg')or 0,1.05,.72)
    else:quad=rectangle(at,d.get('bearing_deg')or 0,d.get('along_m',d.get('length_m',1)),d.get('depth_m',1))
    objects.append({'id':ident,'owner':owner,'kind':kind,'quad':quad})
  for k,v in d.items():
   if isinstance(v,(dict,list)):scan(v,path+'/'+k,owner)
 elif isinstance(d,list):
  for i,v in enumerate(d):scan(v,path+'/'+str(i),owner)
for f in(r/'data/yard').glob('*.json'):scan(json.loads(f.read_text()),f.name)
other_wagons=[geom._wagon_ground(x,geom.TOWN_GAP_M)for x in goods['wagons']if x['id']!='green_tree_tavern_shed_wagon'];rows={}
for label,va,vz in[('before',v0,v0+length),('candidate',v1-length,v1)]:
 corners=[enu(u,v)for u,v in[(u1,va),(u1,vz),(u1+depth,vz),(u1+depth,va)]];centre=enu(u1+depth/2,(va+vz)/2);heights=[hf.height(*enu(u1+depth*i/4,va+(vz-va)*j/4))for i in range(5)for j in range(5)];nearest=sorted([(sid,min(geom._dist_to_polygon(c,p)for c in corners))for sid,p in walls],key=lambda x:x[1]);nearprops=[]
 for obj in objects:
  dist=min([geom._dist_to_polygon(c,obj['quad'])for c in corners]+[geom._dist_to_polygon(c,corners)for c in obj['quad']]);nearprops.append({'id':obj['id'],'owner':obj['owner'],'kind':obj['kind'],'corner_min_signed_distance_m':dist,'quad_overlap':geom._quads_overlap(corners,obj['quad'])})
 nearprops.sort(key=lambda x:x['corner_min_signed_distance_m']);move_wagon={**wagon,'at_local_enu_m':list(centre)};wquad=geom._wagon_ground(move_wagon);generic=geom._stand_refusal(wquad,world,other_wagons);rows[label]={'centre_enu':centre,'corners_enu':corners,'native_corner_otherwall_min_m':nearest[0][1],'nearest_other_walls':nearest[:5],'height_grid25_min_m':min(heights),'height_grid25_max_m':max(heights),'height_relief_m':max(heights)-min(heights),'centre_ground_m':hf.height(*centre),'max_post_deviation_from_centre_ground_m':max(abs(hf.height(*c)-hf.height(*centre))for c in corners),'nearest_other_yard_objects':nearprops[:8],'other_yard_quad_overlaps':[x for x in nearprops if x['quad_overlap']],'generic_wagon_guard_with_own_host_wall_excluded':generic,'distance_to_actual_primary_door_m':math.dist(centre,door['at_local_enu_m']),'local_v_distance_to_actual_front_plane_m':abs(dv-(va+vz)/2),'coupled_wagon_same_centre':True,'native_primary_door':door,'wagon_ground_quad':wquad}
assert all(abs(x-y)< .011 for x,y in zip(rows['before']['centre_enu'],shed['at_local_enu_m']));delta=[rows['candidate']['centre_enu'][i]-rows['before']['centre_enu'][i]for i in [0,1]];dot=delta[0]*math.sin(math.radians(door['bearing_deg']))+delta[1]*math.cos(math.radians(door['bearing_deg']));assert dot>0 and rows['candidate']['local_v_distance_to_actual_front_plane_m']<rows['before']['local_v_distance_to_actual_front_plane_m']
proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'INDEPENDENT_LIGHT_STATIC_PLAN_NOT_NATIVE_BUILD_APP_OR_GATE','base':'a575dddeed356333423b20361a1f90f3b39a862f','placement_frame':'IndependentENUtransform fromGLBcontract; actualalreadycompiledprimarydoor proves +v frontplane','door_local_u_v':[du,dv],'front_plane_v1':v1,'world_delta_enu':delta,'delta_dot_actual_primary_door_outward_normal_m':dot,'rows':rows,'geom_utilities':'Existingdistance/SAT/heightfield and nativegenericwagonrefusal utilities read-only; producer itself NOTcalled/edited','limits':'Conservativeyardquad census, native/app grounding+visibility anddownstreamotherobjectsfreshderivation stillrequired; noflora proofyet','source_mutation':False};(out/'INDEPENDENT-PLACEMENT-PROBE.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
