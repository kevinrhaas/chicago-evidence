from pathlib import Path
import os,json,hashlib,subprocess,copy,datetime
r=Path('/tmp/chicago-green-tree-integration');a=r/'chicago/4d';o=Path('/workspace/T2376-wagon-bay-followthrough-20261026');b=json.loads((o/'NATIVE-SOURCE-BINDING.json').read_text());base=b['base'];b['source']=json.loads((o/'FORMAT-FIX-SOURCE-BINDING.json').read_text())['source_after_documenting_natural_GT_fuel'];env={**os.environ,'GIT_NO_LAZY_FETCH':'1'}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while block:=f.read(1024*1024):h.update(block)
 return h.hexdigest()
def old(p):return subprocess.check_output(['git','show',base+':'+p],cwd=r,env=env)
errors=[];counts={}
for name,group in [('source',b['source']),('protected',b['protected']),('all44binary',{p:v['sha256']for p,v in b['binary_records'].items()})]:
 for p,want in group.items():
  if not(r/p).is_file()or sha(r/p)!=want:errors.append({'group':name,'path':p})
 counts[name]=len(group)
for p,v in b['actual_meshes'].items():
 f=r/p
 if not f.is_file()or sha(f)!=v['sha256']or f.stat().st_size!=v['bytes']or oct(f.stat().st_mode&0o777)!=v['mode']:errors.append({'group':'physical_mesh','path':p})
counts['all_physical_meshes']=len(b['actual_meshes'])
additional=['data/structures/green_tree_tavern.json','data/sidecars/1835/green_tree_tavern.json','assets/manifest.json','assets/manifest.web.json']
for p in additional:
 rel='chicago/4d/'+p
 try:
  if(a/p).read_bytes()!=old(rel):errors.append({'group':'exact_inn_and_manifests','path':rel})
 except subprocess.CalledProcessError:errors.append({'group':'missing_guard_preimage','path':rel})
counts['exact_inn_and_manifests']=len(additional)
yard={};target='chicago/4d/data/yard/town_trade_goods.json';before=json.loads(old(target));after=json.loads((r/target).read_text());normalized=copy.deepcopy(after);changes=[]
for key,identity in [('sheds','green_tree_tavern_wagon_shed'),('wagons','green_tree_tavern_shed_wagon')]:
 oldrow=next(x for x in before[key]if x['id']==identity);row=next(x for x in normalized[key]if x['id']==identity)
 for field in ['at_local_enu_m','clearance_m','note']:
  if row.get(field)!=oldrow.get(field):changes.append({'record':identity,'field':field,'before':oldrow.get(field),'after':row.get(field)})
  row[field]=oldrow[field]
normalized['_doc']=before['_doc']
if normalized!=before:errors.append({'group':'other_yard_or_shape_count_material','path':target})
shed=next(x for x in after['sheds']if x['id']=='green_tree_tavern_wagon_shed');wagon=next(x for x in after['wagons']if x['id']=='green_tree_tavern_shed_wagon')
if shed['at_local_enu_m']!=wagon['at_local_enu_m']:errors.append({'group':'uncoupled_shed_wagon'})
if shed['clearance_m']<1 or wagon['clearance_m']<1:errors.append({'group':'other_wall_refusal'})
if shed['at_local_enu_m']!=[-34.87,-86.97]:errors.append({'group':'unexpected_candidate_station','actual':shed['at_local_enu_m']})
for p,want in b['yard_records_before'].items():
 if p==target:continue
 equal=sha(r/p)==want;yard[p]={'exact':equal}
 if not equal:
  if p=='chicago/4d/data/yard/town_woodpiles.json':
   fuel_before=json.loads(old(p));fuel_now=json.loads((r/p).read_text());accepted=json.loads((o/'EXACT-ACCEPTED-NATIVE-GT-FUEL-LOT.json').read_text());actual=[x for x in fuel_now['lots']if x['structure_id']=='green_tree_tavern'];assert len(actual)==1 and actual[0]==accepted
   assert accepted['confidence']=='reconstructed' and accepted['rule']=='Y-W6' and accepted['household']=='hh_ingersoll_chester'
   assert [x['kind']for x in accepted['items']]==['cordwood','cordwood','chopping_block']
   norm=copy.deepcopy(fuel_now);norm['lots']=[x for x in norm['lots']if x['structure_id']!='green_tree_tavern'];norm['refused']=copy.deepcopy(fuel_before['refused']);expected_counts=copy.deepcopy(fuel_before['counts'])
   for group,key,delta in [('by_row','keeper',1),('by_class','keeper',1),('by_basis','household_trade',1),('items','cordwood',2),('items','chopping_block',1)]:
    expected_counts[group][key]+=delta
   expected_counts['piled']+=1;expected_counts['refused']-=1;assert fuel_now['counts']==expected_counts
   norm['counts']=fuel_before['counts'];assert norm==fuel_before,'unaccepted woodpile metadata/foreignlot drift'
   yard[p]={'exact':False,'accepted_only_GT_new_lot':True,'existing_lots_exact':len(norm['lots']),'other_refused_exact':True,'fuel_confidence':'reconstructed','programme_sources_and_parameters_exact':True}
  else:errors.append({'group':'other_yard_record','path':p})
proof={'status':'PASS'if not errors else'FAIL','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'counts':counts,'yard_other_records':yard,'only_allowed_trade_goods_changes':changes,'counts_dimensions_materials_other_objects_exact':normalized==before,'shed_and_covered_wagon_coupled':shed['at_local_enu_m']==wagon['at_local_enu_m'],'errors':errors,'not_claimed':'Browser grounding/visibility/app/wholecheck remain pending.'};(o/'NATIVE-SCOPE-GUARDS-FINAL-FIELD.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2));raise SystemExit(bool(errors))
