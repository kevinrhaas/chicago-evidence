from pathlib import Path
import subprocess,json,hashlib,os,gzip,zipfile,io,shutil,datetime
import xml.etree.ElementTree as ET
r=Path('/tmp/chicago-green-tree-integration')
h=Path('/workspace/T2376-wagon-bay-followthrough-20261026')
binding=json.loads((h/'NATIVE-SOURCE-BINDING.json').read_text()); source={'incoming':binding['base'],'records':binding['binary_records']}
inc=source['incoming']
hold=h/'native-a575-serialization-held'
assert not hold.exists()
hold.mkdir()
def git(*args):
 return subprocess.check_output(['git',*args],cwd=r,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
def xml_node(node):
 text=node.text
 if text is not None and not text.strip() and len(node)>0:
  text=None
 tail=node.tail if node.tail and node.tail.strip() else None
 return (node.tag,tuple(sorted(node.attrib.items())),text,tail,tuple(xml_node(child) for child in node))
def xlsx_semantics(a,b):
 za=zipfile.ZipFile(io.BytesIO(a));zb=zipfile.ZipFile(io.BytesIO(b))
 names=sorted(za.namelist())
 if names!=sorted(zb.namelist()):
  return False,{'reason':'ZIP member set differs'}
 parts={}
 for name in names:
  aa=za.read(name);bb=zb.read(name)
  if name.endswith(('.xml','.rels')):
   same=xml_node(ET.fromstring(aa))==xml_node(ET.fromstring(bb))
   kind='XML semantic tree (all leaf text preserved)'
  else:
   same=aa==bb
   kind='exact non-XML bytes'
  parts[name]={'equal':same,'comparison':kind}
 return all(x['equal'] for x in parts.values()),parts
changed={};expected={}
for p,record in source['records'].items():
 current=(r/p).read_bytes()
 if hashlib.sha256(current).hexdigest()==record['sha256']:
  continue
 baseline=git('show',inc+':'+p)
 assert hashlib.sha256(baseline).hexdigest()==record['sha256']
 saved=hold/p
 saved.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(r/p,saved)
 if p.endswith('.gz'):
  equal=gzip.decompress(current)==gzip.decompress(baseline)
  details='exact decompressed byte stream'
 else:
  equal,details=xlsx_semantics(current,baseline)
 changed[p]={'equal':equal,'comparison':details,'generated_sha256':hashlib.sha256(current).hexdigest(),'baseline_sha256':record['sha256'],'held':str(saved)}
 expected[p]=baseline
outside={p for mode in [[],['--cached']] for p in git('diff',*mode,inc,'--name-only').decode().splitlines() if not p.startswith('chicago/4d/')}
unknown=sorted(outside-set(changed))
proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'incoming':inc,'all_binary_paths_scanned':len(source['records']),'all_dirty_outside4d':sorted(outside),'unclassified_outside4d':unknown,'changed':changed,'status':'PASS' if not unknown and all(x['equal'] for x in changed.values()) else 'FAIL','action':'No restore until the entire comprehensive scan passes; only semantic/decompressed-identity inherited serialization is restored.'}
(h/'ALL-BINARY-OUTSIDE-A575-PARITY.json').write_text(json.dumps(proof,indent=2)+'\n')
assert proof['status']=='PASS',json.dumps(proof)
for p,data in expected.items():
 (r/p).write_bytes(data)
if expected:
 subprocess.run(['git','add','--',*expected],cwd=r,check=True)
proof['restored_to_actual_incoming_bytes']=list(expected)
proof['completed']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(h/'ALL-BINARY-OUTSIDE-A575-PARITY.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'status':proof['status'],'all_binary_scanned':len(source['records']),'changed':{p:record['equal'] for p,record in changed.items()},'restored':list(expected),'unknown_outside':unknown},indent=2))
