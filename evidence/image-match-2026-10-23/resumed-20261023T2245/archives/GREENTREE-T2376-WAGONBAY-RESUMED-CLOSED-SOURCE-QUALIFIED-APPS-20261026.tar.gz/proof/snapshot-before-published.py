from pathlib import Path
import os,json,hashlib,shutil,datetime,subprocess
os.sched_setaffinity(0,{3})
o=Path('/workspace/T2376-wagon-bay-followthrough-20261026');site=Path('/tmp/chicago-green-tree-integration/site');dest=o/'before-published';dest.mkdir(exist_ok=False)
# Only immutable binary payloads may fall through; every other response is frozen.
immutable={'.glb','.png','.jpg','.jpeg','.webp','.ktx2','.woff','.woff2','.ttf','.ico','.mp3','.wav','.mp4','.pdf','.tif','.tiff','.bin'}
records={};copied=0;fallback=0
for p in sorted(site.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink(),str(p)
 rel=str(p.relative_to(site));data=p.read_bytes();h=hashlib.sha256(data).hexdigest();frozen=p.suffix.lower()not in immutable
 if frozen:
  out=dest/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out);assert out.read_bytes()==data;copied+=len(data)
 else:fallback+=len(data)
 records[rel]={'sha256':h,'bytes':len(data),'frozen_copy':frozen,'mode':oct(p.stat().st_mode&0o777)}
base='a575dddeed356333423b20361a1f90f3b39a862f';yard='chicago/4d/data/yard/town_trade_goods.json';raw=subprocess.check_output(['git','show',base+':'+yard],cwd=site.parent,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'});baseline=json.loads(raw)
# Find the actual published record wherever native publisher's contract places it.
hits=[]
for rel,v in records.items():
 if not rel.endswith('.json')or not v['frozen_copy']:continue
 try:
  value=json.loads((dest/rel).read_text())
  if isinstance(value,dict)and value.get('id')=='town_trade_goods':
   assert value==baseline,(rel,'published baseline differs from actual a575 goods');hits.append(rel)
 except (UnicodeDecodeError,json.JSONDecodeError):pass
assert hits,'No exact actuala575 published trade_goods payload found'
proof={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'source_site':str(site),'frozen_root':str(dest),'records':records,'files':len(records),'copied_bytes':copied,'immutable_fallback_bytes':fallback,'exact_published_base_trade_goods':hits,'contract':'Whole genuine native published baseline. Every text/JSON/runtime response copied; large binary response may use current native SITE ONLY after exact baseline SHA/size verification. No hardlinks, no source changes, no request interception. Metadata may reflect initial authoredsource notes; all physicalruntime inputs bound.'}
(o/'BEFORE-PUBLISHED-MANIFEST.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items()if k!='records'},indent=2))
