from pathlib import Path
import json,math,array,hashlib,datetime
from shapely.geometry import Polygon,Point
r=Path('/tmp/chicago-green-tree-integration/chicago/4d');out=Path('/workspace/T2376-wagon-bay-followthrough-20261026');sc=json.loads((r/'data/sidecars/1835/green_tree_tavern.json').read_text());place=sc['placement'];poly=sc['footprint']['polygon'];b=math.radians(place['rotation_deg']);cs,sn=math.cos(b),math.sin(b)
def enu(u,v):return(place['local_e']+u*cs+v*sn,place['local_n']-u*sn+v*cs)
u1=max(p[0]for p in poly);v0=min(p[1]for p in poly);v1=max(p[1]for p in poly);length=4.05;depth=3.2
m=json.loads((r/'data/terrain/epochs/e1834_harbor_cut/heightfield.json').read_text());samples=array.array('h');samples.frombytes((r/'data/terrain/epochs/e1834_harbor_cut/heightfield.bin').read_bytes())
def height(e,n):
 x=(e-m['origin_e'])/m['cell_m'];y=(n-m['origin_n'])/m['cell_m'];assert 0<=x<m['cols']-1and 0<=y<m['rows']-1;i,j=int(x),int(y);fx,fy=x-i,y-j
 return sum(samples[(j+dj)*m['cols']+i+di]*((fx if di else 1-fx)*(fy if dj else 1-fy))for di,dj in [(0,0),(1,0),(0,1),(1,1)])*m['scale']+m['offset']
walls=[]
for p in(r/'data/sidecars/1835').glob('*.json'):
 d=json.loads(p.read_text())
 if not isinstance(d,dict)or d.get('id')=='green_tree_tavern':continue
 ps=d.get('placement')or{};pg=(d.get('footprint')or{}).get('polygon')or[]
 if ps.get('local_e')is None or len(pg)<3:continue
 br=math.radians(ps.get('rotation_deg')or 0);c,s=math.cos(br),math.sin(br);pts=[(ps['local_e']+u*c+v*s,ps['local_n']-u*s+v*c)for u,v in pg];shape=Polygon(pts)
 if not shape.is_valid:shape=shape.buffer(0)
 walls.append((d['id'],shape))
ap=json.loads((r/'data/enclosures/town_entrance_aprons.json').read_text());aprons=[Polygon(x)for x in ap['ground']['interior_local_enu_m']if len(x)>=3]
def rectangle(at,bearing,along,depth):
 angle=math.radians(bearing);c,s=math.cos(angle),math.sin(angle)
 return Polygon([(at[0]+u*c+v*s,at[1]-u*s+v*c)for u,v in[(-along/2,-depth/2),(along/2,-depth/2),(along/2,depth/2),(-along/2,depth/2)]])
objects=[]
def scan(d,path,owner=None):
 if isinstance(d,dict):
  owner=d.get('belongs_to')or d.get('structure_id')or owner;at=d.get('at_local_enu_m')
  if isinstance(at,list)and len(at)==2:
   ident=d.get('id')or path;kind=d.get('kind','unknown')
   if ident not in ['green_tree_tavern_wagon_shed','green_tree_tavern_shed_wagon']:
    if kind in ['covered','farm_box','cart']:
     back=.99if kind=='cart'else 1.525;fore=back+(2.44if kind=='cart'else 2.75);ang=math.radians(d.get('bearing_deg')or 0);fe,fn=math.sin(ang),math.cos(ang);se,ss=math.cos(ang),-math.sin(ang);shape=Polygon([(at[0]+fe*a+se*w,at[1]+fn*a+ss*w)for a,w in[(-back,-.75),(-back,.75),(fore,.75),(fore,-.75)]])
    elif 'along_m'in d or 'length_m'in d:shape=rectangle(at,d.get('bearing_deg')or 0,d.get('along_m',d.get('length_m',1)),d.get('depth_m',.8))
    elif kind=='bench':shape=rectangle(at,d.get('bearing_deg')or 0,1.83,.36)
    elif kind=='crate':shape=rectangle(at,d.get('bearing_deg')or 0,1.05,.72)
    else:shape=Point(at).buffer(.5)
    objects.append({'id':ident,'kind':kind,'owner':owner,'shape':shape,'shape_strength':'conservativebox/disc; finalnative/app stillrequired'})
  for k,v in d.items():
   if isinstance(v,(dict,list)):scan(v,path+'/'+k,owner)
 elif isinstance(d,list):
  for i,v in enumerate(d):scan(v,path+'/'+str(i),owner)
for p in(r/'data/yard').glob('*.json'):scan(json.loads(p.read_text()),p.name)
rows={}
for label,va,vz in [('before',v0,v0+length),('candidate',v1-length,v1)]:
 corners=[enu(u,v)for u,v in[(u1,va),(u1,vz),(u1+depth,vz),(u1+depth,va)]];shape=Polygon(corners);centre=enu(u1+depth/2,(va+vz)/2);hs=[height(*enu(u1+depth*i/4,va+(vz-va)*j/4))for i in range(5)for j in range(5)];nearwalls=sorted([(ident,shape.distance(p))for ident,p in walls],key=lambda x:x[1]);nearobj=sorted([{'id':x['id'],'owner':x['owner'],'kind':x['kind'],'distance_m':shape.distance(x['shape']),'intersection_area_m2':shape.intersection(x['shape']).area}for x in objects],key=lambda x:x['distance_m']);rows[label]={'centre_enu':centre,'corners_enu':corners,'nearest_other_walls':nearwalls[:5],'native_corner_otherwall_min_m':min(Point(c).distance(w)for c in corners for _,w in walls),'height_grid25_min_m':min(hs),'height_grid25_max_m':max(hs),'height_relief_m':max(hs)-min(hs),'centre_ground_m':height(*centre),'max_post_deviation_from_centre_ground_m':max(abs(height(*c)-height(*centre))for c in corners),'minimum_apron_distance_m':min(shape.distance(x)for x in aprons),'positive_area_apron_intersections':[i for i,x in enumerate(aprons)if shape.intersection(x).area>1e-8],'nearest_other_yard_objects':nearobj[:10],'other_yard_shape_overlaps':[x for x in nearobj if x['intersection_area_m2']>1e-8]}
proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'INDEPENDENT_READONLY_LIGHT_PLACEMENT_PROBE; notnativeorappPASS','base':'a575dddeed356333423b20361a1f90f3b39a862f','inn_placement_unchanged':place,'length_m':length,'depth_m':depth,'unchanged_shed_and_wagon_count':1,'local_station_delta_m':v1-v0-length,'rows':rows,'other_objects_model_limit':'Conservative rectangles/discs fromcurrentyardrecords; no flora/roads fullbody/browser evaluation yet. Actualnative rejection/grounding guards+app required.','source_mutated':False};(out/'INDEPENDENT-PLACEMENT-PROBE.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'before':rows['before'],'candidate':rows['candidate']},indent=2))
