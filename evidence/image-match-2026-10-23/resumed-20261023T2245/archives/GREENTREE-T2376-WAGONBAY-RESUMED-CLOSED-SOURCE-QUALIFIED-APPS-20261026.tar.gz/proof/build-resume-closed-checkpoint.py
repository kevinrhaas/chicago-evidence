from pathlib import Path
import datetime,hashlib,json,shutil,stat,subprocess
h=Path('/workspace/T2376-wagon-bay-followthrough-20261026');r=Path('/tmp/chicago-green-tree-integration')
o=Path('/workspace/shared/T2376-wagonbay-resume-closed-20261026');assert not o.exists()
s=json.loads((h/'app-desktop-resume-20261026T1231-status.json').read_text());assert s['all_children_reaped'] and s['command_exit'] is not None
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()=='a575dddeed356333423b20361a1f90f3b39a862f'
o.mkdir()
def cp(src,rel):
 d=o/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,d)
for f in h.iterdir():
 if f.is_file():cp(f,Path('proof')/f.name)
for name in ['app-before-after','app-before-after-v2','app-before-after-v3','app-desktop-resume-20261026T1231']:
 for f in (h/name).rglob('*'):
  if f.is_file():cp(f,Path('proof')/name/f.relative_to(h/name))
paths=set(subprocess.check_output(['git','diff','HEAD','--name-only','-z'],cwd=r).decode().strip('\0').split('\0'))
paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=r).decode().strip('\0').split('\0'))
paths.discard('');assert paths and all(x.startswith('chicago/4d/')for x in paths)
for rel in sorted(paths):cp(r/rel,Path('source')/rel)
(o/'source.binary.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=r))
(o/'SOURCE-STATUS.txt').write_bytes(subprocess.check_output(['git','status','--short'],cwd=r))
state={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CLOSED_CURRENT_SOURCE_AND_ACTUAL_APP_COMPONENTS_PRESERVED_NOT_CODE_GATE_OR_PR','base':'a575dddeed356333423b20361a1f90f3b39a862f','branch':'steward/t2376-green-tree-wagon-bay-front','original_T2376':'OPEN/DIF, enclosedannex andlongwall gaps retained; noDONEcall','native_scope':'202+7+57 actualPASS, all44 serializationaudit,2059meshes/79protected,782otherLibrows/880names all exact; L134format repairthrough native142/150/pkg5/publishPASS','prior_proof_dependency':'index373 acceptednativefuel/publish with firstselectorFAIL, publicafdb846939f5ab38bc14928595e36db0aafb0ac0','app_status_receipt':'proof/APP-QUALIFIED-STATUS.json','desktop_resume_reaper':s,'source_changes_this_resume':False,'full3_code_gate_commit_PR_full18_latestdev_integration':'OWED; not claimedPASS','live_workers_in_packet':False,'before_world_large_copy_excluded':'proof/BEFORE-PUBLISHED-MANIFEST.json inventory; before-published158MBnotduplicated','source_paths':sorted(paths)}
(o/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
files={}
for f in o.rglob('*'):
 if f.is_file():
  b=f.read_bytes();files[str(f.relative_to(o))]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':stat.S_IMODE(f.stat().st_mode)}
manifest={**state,'files':files};(o/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifest':str(o/'MANIFEST.json'),'sha256':hashlib.sha256((o/'MANIFEST.json').read_bytes()).hexdigest(),'files':len(files),'bytes':sum(x['bytes']for x in files.values())},indent=2))
