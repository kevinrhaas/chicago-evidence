from pathlib import Path
import subprocess,os,json,hashlib,datetime,shutil
r=Path('/tmp/chicago-green-tree-integration');a=r/'chicago/4d';o=Path('/workspace/T2376-wagon-bay-followthrough-20261026');base='a575dddeed356333423b20361a1f90f3b39a862f';os.sched_setaffinity(0,{3});env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(TMPDIR='/tmp/gt-bay',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');Path(env['TMPDIR']).mkdir(exist_ok=True);free=shutil.disk_usage(env['TMPDIR']).free;assert free>=512*1024**2
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip()==base
paths=subprocess.check_output(['git','diff','--name-only'],cwd=r).decode().splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r).decode().splitlines();assert paths and all(p.startswith('chicago/4d/')for p in paths)
source={p:hashlib.sha256((r/p).read_bytes()).hexdigest()for p in sorted(set(paths))};meshes={}
for directory in [a/'assets/gltf',a/'assets/web']:
 for f in sorted(directory.rglob('*.glb')):
  digest=hashlib.sha256()
  with f.open('rb')as stream:
   while block:=stream.read(1024*1024):digest.update(block)
  meshes[str(f.relative_to(r))]={'sha256':digest.hexdigest(),'bytes':f.stat().st_size,'mode':oct(f.stat().st_mode&0o777)}
old=json.loads(Path('/workspace/green-tree-final-external-merge-native-handoff-20261026/GUARDS-EB1-BEFORE.json').read_text());protected={}
for p in old['protected']:
 if p in source:continue
 data=subprocess.check_output(['git','show',base+':'+p],cwd=r,env={**env,'GIT_NO_LAZY_FETCH':'1'});assert(r/p).read_bytes()==data,p;protected[p]=hashlib.sha256(data).hexdigest()
binaries={}
for p in json.loads(Path('/workspace/green-tree-final-external-merge-native-handoff-20261026/ALL-XLSX-GZIP-EB1-BASELINE.json').read_text())['records']:
 data=subprocess.check_output(['git','show',base+':'+p],cwd=r,env={**env,'GIT_NO_LAZY_FETCH':'1'});assert(r/p).read_bytes()==data,p;binaries[p]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
yard={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest()for p in(a/'data/yard').glob('*.json')}
m=json.loads((a/'tools/derived_manifest.json').read_text());first=next(i for i,s in enumerate(m['steps'])if s['command']==['python3','tools/compile_liberties.py']);cyclekeys={tuple(s['command'])for s in m['second_pass']};cycle=[i for i,s in enumerate(m['steps'])if tuple(s['command'])in cyclekeys];assert any(i>=first for i in cycle)
binding={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'branch':subprocess.check_output(['git','branch','--show-current'],cwd=r).decode().strip(),'source':source,'actual_meshes':meshes,'protected':protected,'binary_records':binaries,'yard_records_before':yard,'native_contract':{'earliest_authored_owner':first+1,'command':m['steps'][first]['command'],'feedback_positions':[i+1 for i in cycle],'full202_required':True},'cpu_affinity':sorted(os.sched_getaffinity(0)),'startup_free_bytes':free,'scope':'OnlyexistingGTshed/wagonstationpolicy, citedmetadata/oneT2376entry andsamefourcheckedstricttools. NoBlender/masterWEBfamilybake.'};(o/'NATIVE-SOURCE-BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
print('BOUND_SOURCE',len(source),'MESHES',len(meshes),'PROTECTED',len(protected),'BINARY',len(binaries),'FULL202_REQUIRED',flush=True)
results=[]
for command,name in [(['bash','tools/publish.sh'],'native-prereq-publish.log'),(['node','tools/rederive.mjs','--run'],'native-full202.log')]:
 assert shutil.disk_usage(env['TMPDIR']).free>=512*1024**2
 with(o/name).open('x')as log:process=subprocess.run(command,cwd=a,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':command,'exit_code':process.returncode,'log':str(o/name)})
 print('ACTUAL_NATIVE_COMMAND',command,process.returncode,flush=True)
 if process.returncode:break
passed=len(results)==2 and all(x['exit_code']==0 for x in results);same=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in source.items());proof={'status':'PASS'if passed and same else'FAIL','finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':results,'source_unchanged':same,'cpu_affinity':sorted(os.sched_getaffinity(0)),'no_bake':True,'next':'ONEall44audit/actualotherobjects+physicalmeshguards/pkg/publish andleasedapp/fullgate stillOWED'};(o/'OWNING-NATIVE-RESULT.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2),flush=True);raise SystemExit(0 if passed and same else 1)
