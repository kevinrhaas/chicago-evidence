from pathlib import Path
import subprocess,os,json,hashlib,datetime,stat
r=Path('/tmp/chicago-green-tree-integration');out=Path('/workspace/T2376-wagon-bay-followthrough-20261026');prior=Path('/workspace/green-tree-final-external-merge-native-handoff-20261026');env={**os.environ,'GIT_NO_LAZY_FETCH':'1'}
def git(*args,input=None):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=r,env=env,input=input)
head=git('rev-parse','HEAD').decode().strip();merge=git('rev-parse','MERGE_HEAD').decode().strip();branch=git('symbolic-ref','HEAD').decode().strip();assert head=='6a61ab6eca1f1ea2322302d131e847b383ac9c8b'and merge=='eb1cb6a41791f5936f536fbeff2d55c832d88f31';assert not git('diff','--name-only','--diff-filter=U').strip();assert not git('ls-files','--others','--exclude-standard').strip()
old=json.loads((prior/'MANIFEST.json').read_text());members={x['path']:x for x in old['files']};wip=git('diff','--name-only',merge).decode().splitlines();expected=json.loads((prior/'STATE.json').read_text())['archived_WIP_paths'];assert set(wip)==set(expected);hashes={}
for p in wip:
 f=r/p;b=f.read_bytes();mode=stat.S_IMODE(f.stat().st_mode);entry=members['WIP/'+p];assert hashlib.sha256(b).hexdigest()==entry['sha256']and oct(mode)==entry['mode'],p;hashes[p]={'sha256':entry['sha256'],'mode':entry['mode'],'bytes':len(b)}
metadata={}
for name in ['HEAD','MERGE_HEAD','MERGE_MSG','MERGE_MODE','ORIG_HEAD','index']:
 p=Path(git('rev-parse','--git-path',name).decode().strip());p=p if p.is_absolute()else r/p
 if p.exists():metadata[name+'.raw']=p.read_bytes()
stash=git('stash','create','PRIVATE RECOVERY T-2376 resolved old merge before fresh wagon-bay branch').decode().strip();assert len(stash)==40
assert git('rev-parse',stash+'^1').decode().strip()==head
subprocess.run(['git','diff','--quiet',stash],cwd=r,env=env,check=True);subprocess.run(['git','diff','--cached','--quiet',stash+'^2'],cwd=r,env=env,check=True)
for p,row in hashes.items():assert hashlib.sha256(git('show',stash+':'+p)).hexdigest()==row['sha256'],p
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');stashref='refs/codex/private/t2376-old-wip-stash-'+stamp;metaref='refs/codex/private/t2376-old-merge-metadata-'+stamp;git('update-ref',stashref,stash,'0'*40)
state={'status':'PRIVATE_RECOVERY_ONLY_NOT_CANDIDATE_CODE_COMMIT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_branch':branch,'HEAD':head,'MERGE_HEAD':merge,'stash':stash,'stash_ref':stashref,'index_parent':git('rev-parse',stash+'^2').decode().strip(),'all10_WIP_exact_public357':hashes,'metadata':{k:{'sha256':hashlib.sha256(v).hexdigest(),'bytes':len(v)}for k,v in metadata.items()},'normal_ticket_claim':'c36ba5c7c7702aafecfdb56ef9756766ec06efa9','source_worktree_not_cleared_yet':True}
metadata['STATE.json']=(json.dumps(state,indent=2)+'\n').encode();entries=[]
for name,b in metadata.items():
 oid=git('hash-object','-w','--stdin',input=b).decode().strip();entries.append(f'100644 blob {oid}\t{name}\n')
tree=git('mktree',input=''.join(sorted(entries)).encode()).decode().strip();commit=git('commit-tree',tree,'-p',stash,input=b'PRIVATE RECOVERY ONLY: T-2376 safe merge/index metadata; preserve old WIP, not candidate code\n').decode().strip();git('update-ref',metaref,commit,'0'*40)
for name,b in metadata.items():assert git('show',commit+':'+name)==b,name
assert git('rev-parse',stashref).decode().strip()==stash and git('rev-parse',metaref).decode().strip()==commit;assert git('rev-parse','HEAD').decode().strip()==head and git('rev-parse','MERGE_HEAD').decode().strip()==merge
state.update({'private_metadata_ref':metaref,'private_metadata_commit':commit,'private_metadata_tree':tree,'private_stash_working_tree_exact':True,'private_index_parent_exact':True,'all_metadata_blob_bytes_verified':True,'all10_archived357_byte_mode_verified':True});(out/'PRIVATE-OLD-WIP-RECOVERY-VERIFIED.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({'status':state['status'],'stash':stash,'stash_ref':stashref,'metadata_ref':metaref,'metadata_commit':commit,'old_branch':branch,'all10_verified':True,'private_working_index_merge_recovery_verified':True},indent=2))
