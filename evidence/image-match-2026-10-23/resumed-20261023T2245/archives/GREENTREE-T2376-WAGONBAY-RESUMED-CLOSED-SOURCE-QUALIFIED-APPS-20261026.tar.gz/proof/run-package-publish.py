from pathlib import Path
import os,subprocess,json,datetime,shutil
r=Path('/tmp/chicago-green-tree-integration');a=r/'chicago/4d';h=Path('/workspace/T2376-wagon-bay-followthrough-20261026')
os.sched_setaffinity(0,{3});env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(TMPDIR='/tmp/gt-bay',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
assert json.loads((h/'OWNING-NATIVE-RESULT.json').read_text())['status']=='PASS'
assert json.loads((h/'NATIVE-SCOPE-GUARDS-ACCEPTED-GT-FUEL.json').read_text())['status']=='PASS'
assert json.loads((h/'ALL-BINARY-OUTSIDE-A575-PARITY.json').read_text())['status']=='PASS'
mem_limit=int(Path('/sys/fs/cgroup/memory.max').read_text());mem_current=int(Path('/sys/fs/cgroup/memory.current').read_text());assert mem_limit-mem_current>=512*1024**2
assert shutil.disk_usage(env['TMPDIR']).free>=512*1024**2,'Root-required512MiB caller disk reserve'
results=[]
for command,name in [(['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'],'package5-a575.log'),(['bash','tools/publish.sh'],'publish-a575.log')]:
 assert shutil.disk_usage(env['TMPDIR']).free>=512*1024**2,'Caller disk reserve'
 assert int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text())>=512*1024**2,'Caller memory reserve'
 with (h/name).open('x')as log:process=subprocess.run(command,cwd=a,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':command,'exit_code':process.returncode,'log':str(h/name)})
 print('ACTUAL_COMMAND',command,process.returncode,flush=True)
 if process.returncode:break
passed=len(results)==2 and all(x['exit_code']==0 for x in results)
p={'status':'PASS'if passed else'FAIL','finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':results,'cpu_affinity':sorted(os.sched_getaffinity(0)),'caller_reserve_start':mem_limit-mem_current}
(h/'PACKAGE5-PUBLISH-A575-RESULT.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p,indent=2),flush=True);raise SystemExit(0 if passed else 1)
