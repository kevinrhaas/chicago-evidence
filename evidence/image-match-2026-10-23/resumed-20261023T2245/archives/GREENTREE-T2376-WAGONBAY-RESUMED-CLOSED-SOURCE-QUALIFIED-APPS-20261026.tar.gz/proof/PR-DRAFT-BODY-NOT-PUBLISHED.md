The Green Tree Tavern's existing open wagon bay and covered wagon stood beside its rear end. This moves them 8.14 m along the same north wall to the front gable, following the verified Trowbridge/Gale 1902 retrospective plate captioned 1835. The station comes from the committed inn footprint; its geographic position, physical meshes, bay dimensions, material and wagon count stay unchanged.

Vacating the rear bay also lets the unchanged household-fuel programme supply this inn's previously refused fuel lot: two reconstructed cordwood ricks and a chopping block. All 397 pre-existing woodpile lots and the other refusal remain exact. The drawing does not attest those fuel piles. L134 and the dossier retain the reconstructed dimensions, attachment and exact July-1835 presence, with the explanation visible in Sources.

This is a partial improvement on T-2376. Its image case remains OPEN/DIF for the separate enclosed-annex massing and long-wall opening pattern; the original discrepancy register keeps both visible differences open.

The change also carries the four previously checked smoke-tool repairs needed by this visible parcel: preserve the existing lighthouse glass bucket and opacity, use an independently transformed declared-footprint centroid for occupancy checks while retaining vertex/mirror checks, and include the already modelled 1904 Pullman range in the exact scene set.

Validation before this draft opens:

- Actual owning native 202 steps, seven feedback steps and 57-step closing tail; all 44 XLSX/gzip and outside-app outputs audited, with only proved serialization differences restored after preserving regenerated copies.
- All 2,059 physical mesh files, 79 protected source/people files, the inn record/sidecar and both asset manifests exact; only the coupled bay/wagon translations and the explicitly accepted own-inn fuel lot change physical yard data.
- Parser-field repair through the actual liberties/source-use owners and their native checks, package tail and native publisher; all 782 other liberty rows, 880 names and prior L134 fields exact.
- App: PENDING final aggregate of exact genuine published BEFORE and final AFTER at 390×780/DP2 and 1280×800/DP1, normal/ByGrade, source credits/L134, bay/fuel grounding, native 2 m/3 m entrance clearance, caps and errors. Historical harness-selector failure, disclosure-format failure and occluded auxiliary view retained explicitly.
- Required whole check, changelog and ticket-ID questions: PENDING actual final frozen source PASS and committed-HEAD repeats.

DRAFT: final published full 18-job matrix, current-base integration and merge checks remain pending. No previous failed or older-head matrix is presented as a final-head PASS.
