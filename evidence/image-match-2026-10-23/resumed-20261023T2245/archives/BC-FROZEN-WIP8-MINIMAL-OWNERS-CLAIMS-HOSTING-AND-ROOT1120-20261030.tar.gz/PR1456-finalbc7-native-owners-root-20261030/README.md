Root-executed minimal native closure for actual 9d97 + bc7 merge. Preparation only; no native compiler was launched by this agent.

Root prepass preserved separately at /workspace/PR1456-bc7-generated-conflict-resolution-root-20261030/RESULT.json. The index must still contain the exact three actual generated conflicts; staged spatial cleanup is captured in the authored baseline.

Run after root source/CPU freeze:

python3 /workspace/PR1456-finalbc7-native-owners-root-20261030/run.py --expect-head 9d97c8191a074a50f94576195614a16f55345a9f --expect-merge-parent bc7ecc3f7478d3c06e10ca3e85feec87e7139074 --execute

Two complete laps of official compile_liberties + compile_source_use; second lap must move no owned bytes. Then official 1904 scene and frontyard checks. Only explicit owner outputs are staged. Binary44, all2073models, staged authored bytes, native manifest, GitHEAD/MERGE_HEAD/config/allrefs and caller disk floors are guarded. No publish/browser/phone/61tail/204 run. Full source gate and fresh committed-head official phone remain mandatory after closure.
