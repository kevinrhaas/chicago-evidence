"""Only the exact already-merged PR1478 workflow inherited from the incoming dev parent."""
from pathlib import Path
import hashlib,json
PATH='.github/workflows/chicago-4d-moving-frames.yml'
MODE='100644'
BLOB='06f8ecab0758dff2aa67a11d9b179a18e2488458'
SHA256='d4147454a1cb572a8315c87758cfa7e08fa4620cf02a8ec63f82e81897b8faef'
INCOMING='bc7ecc3f7478d3c06e10ca3e85feec87e7139074'
PARENT='9d97c8191a074a50f94576195614a16f55345a9f'
MERGED1478='f0b920e238798dbfc2873b6339b090e2d9c61b56'
PROOF_SHA256='a724902fcf9e13df0d4ee63525ccc2bdf82ba8aa6d8aa3971849d962725bfe3b'
def proof():
 p=Path(__file__).parent/'INCOMING-FIXED-PATH-PROOF.json';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==PROOF_SHA256
 d=json.loads(raw);r=d['fixed_paths'][PATH];assert d['incoming']==INCOMING and d['parent']==PARENT and r['mode']==MODE and r['sha']==BLOB and r['size']==4972 and d['workflow_sha256']==SHA256
 assert d['workflow_no_staged_delta_allowed_because_already_same_in9d']is True;return d
def verify(root,git,working=True,index=True):
 proof();assert git('ls-tree',PARENT,'--',PATH).decode().strip()==MODE+' blob '+BLOB+'\t'+PATH;assert git('ls-tree',INCOMING,'--',PATH).decode().strip()==MODE+' blob '+BLOB+'\t'+PATH
 if index:assert git('ls-files','--stage','--',PATH).decode().strip()==MODE+' '+BLOB+' 0\t'+PATH
 if working:assert hashlib.sha256((root/PATH).read_bytes()).hexdigest()==SHA256
 return {'path':PATH,'mode':MODE,'inherited_blob':BLOB,'sha256':SHA256,'incoming':INCOMING,'already_merged_PR':1478,'proof_sha256':PROOF_SHA256}
