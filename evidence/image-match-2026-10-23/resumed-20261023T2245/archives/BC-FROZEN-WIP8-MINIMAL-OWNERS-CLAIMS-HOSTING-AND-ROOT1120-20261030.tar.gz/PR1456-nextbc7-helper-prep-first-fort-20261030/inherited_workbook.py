"""One exact inheritedbc7 workbook exception; never a directory whitelist."""
from pathlib import Path
import hashlib,json
import inherited_workflow as WF
PATH='chicago/reference/resident-research/final/audit/resident_audit_master.xlsx'
MODE='100644'
BLOB='532ca0bda028998d77565ce97502be83b538cb20'
SHA256='3623599e106af32ae7695e4093a18ade1e8bddd72a7ac5e48ff55eefd7460172'
INCOMING='bc7ecc3f7478d3c06e10ca3e85feec87e7139074'
PARENT='9d97c8191a074a50f94576195614a16f55345a9f'
PROOF_SHA256='a724902fcf9e13df0d4ee63525ccc2bdf82ba8aa6d8aa3971849d962725bfe3b'
LIBRARY={'chicago/prairie_1904_v1/data/images.json','chicago/prairie_1904_v1/research/images/STORE.json','chicago/prairie_1904_v1/research/images/stream-early-chicago-lighthouse-reference.json','chicago/prairie_1904_v1/research/images/stream-early-chicago-miller-hogan-references.json','chicago/prairie_1904_v1/research/images/stream-st-mary-reference.json'}
def proof():
 p=Path(__file__).parent/'INCOMING-FIXED-PATH-PROOF.json';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==PROOF_SHA256
 d=json.loads(raw);r=d['fixed_paths'][PATH];assert d['incoming']==INCOMING and d['parent']==PARENT and r['mode']==MODE and r['sha']==BLOB and r['size']==507390 and d['workbook_sha256']==SHA256
 for name,digest in d['classifications'].items():assert hashlib.sha256((Path(__file__).parent/name).read_bytes()).hexdigest()==digest
 logical=json.loads((Path(__file__).parent/'WORKBOOK-LOGICAL-CLASSIFICATION.json').read_bytes());assert logical['new']==INCOMING and len(logical['members'])==12 and logical['all_expanded_XML_infosets_equal']and logical['all_worksheet_cells_including_formulas_values_styles_exact']
 assert all(r['expanded_XML_infoset_equal_ignoring_attributeorder_namespaceprefixes']for r in logical['members'])and sum(r.get('different_cells',0)for r in logical['members'])==0
 rawclass=json.loads((Path(__file__).parent/'WORKBOOK-IMMUTABLE-MEMBER-CLASSIFICATION.json').read_bytes());assert rawclass['new']==INCOMING and rawclass['new_bytes']==507390 and rawclass['new_sha256']==SHA256
 return d
def allowed(path,digest=None):
 if path==WF.PATH:return False  # Already identical in both parents; no workflow change in this unit.
 if path==PATH:return digest==SHA256
 return path.startswith('chicago/4d/')or path in LIBRARY
def verify(root,git,working=True,index=True):
 proof();p=git('ls-tree',INCOMING,'--',PATH).decode().strip();assert p==MODE+' blob '+BLOB+'\t'+PATH
 if index:
  p=git('ls-files','--stage','--',PATH).decode().strip();assert p==MODE+' '+BLOB+' 0\t'+PATH
 if working:assert hashlib.sha256((root/PATH).read_bytes()).hexdigest()==SHA256
 workflow=WF.verify(root,git,working=working,index=index)
 return {'path':PATH,'mode':MODE,'inherited_blob':BLOB,'sha256':SHA256,'incoming':INCOMING,'proof_sha256':PROOF_SHA256,'inherited_workflow':workflow}
