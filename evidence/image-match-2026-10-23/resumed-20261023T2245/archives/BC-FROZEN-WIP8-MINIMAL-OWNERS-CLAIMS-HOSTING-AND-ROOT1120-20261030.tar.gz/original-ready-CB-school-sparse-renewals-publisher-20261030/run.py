from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
import os,json,hashlib,subprocess,datetime,base64,sys
O=Path(__file__).parent;R=O/'tickets';A=O/'app';TOOL=A/'chicago/4d/tools/ticket.mjs';P='T-2250-2499/T-2382-match-philo-carpenter-s-log-shop-the-sauganash-s.md';APPHEAD='5c4b2ea611e729a7fb9fd31da835f321c6f5685c';FLOOR=536870912
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',NODE_DISABLE_COMPILE_CACHE='1');sha=lambda b:hashlib.sha256(b).hexdigest();gs=lambda k,b:hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();save=lambda n,j:(O/n).write_text(json.dumps(j,indent=2)+'\n')
def api(repo,path,data=None,method=None):
 with urlopen(Request('https://api.github.com/repos/kevinrhaas/'+repo+'/'+path,data=None if data is None else json.dumps(data).encode(),headers={'User-Agent':'Chicago-official-sparse-same-owner-renewal','Accept':'application/vnd.github+json','Content-Type':'application/json','Cache-Control':'no-cache'},method=method or('GET'if data is None else'POST')),timeout=45)as f:return json.load(f)
def git(root,*a,input=None):return subprocess.check_output(['/usr/local/bin/git','-C',str(root),'-c','protocol.https.allow=never','-c','protocol.http.allow=never','-c','gc.auto=0','-c','maintenance.auto=false',*a],input=input,env=E,stderr=subprocess.PIPE)
def canonical(c):
 v=c['verification'];sig=v.get('signature');payload=v.get('payload')
 if sig and payload:
  h,msg=payload.encode().split(b'\n\n',1)
  for ss in [sig.encode(),sig.encode().rstrip(b'\n')]:
   b=h+b'\ngpgsig '+b'\n '.join(ss.split(b'\n'))+b'\n\n'+msg
   if gs('commit',b)==c['sha']:return b
 if not sig:
  for tz in ['+0000','-0500','-0600']:
   def who(k):
    x=c[k];dt=datetime.datetime.fromisoformat(x['date'].replace('Z','+00:00'));return k+' '+x['name']+' <'+x['email']+'> '+str(int(dt.timestamp()))+' '+tz
   h=['tree '+c['tree']['sha'],*['parent '+p['sha']for p in c['parents']],who('author'),who('committer')]
   for end in ['', '\n']:
    b=('\n'.join(h)+'\n\n'+c['message']+end).encode()
    if gs('commit',b)==c['sha']:return b
 raise AssertionError('Canonicalcommit reconstruction refused')
def put(root,k,b,s):assert gs(k,b)==s;assert git(root,'hash-object','-w','-t',k,'--stdin',input=b).decode().strip()==s
if (O/'BINDING.json').exists(): P=json.loads((O/'BINDING.json').read_text())['path']
if len(sys.argv)>1 and sys.argv[1]=='pull':
 os.execv(sys.executable,[sys.executable,str(O/'recover_pull.py')])
if len(sys.argv)>1 and sys.argv[1]=='push':
 import importlib.util
 sp=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);m.SOURCE=R;m.G=R/'.git';m.REPO='kevinrhaas/chicago-tickets';m.git=lambda *a:git(R,*a)
 def local_indexed(wanted):
  wanted=set(wanted)
  if not wanted:return set()
  out=git(R,'cat-file','--batch-check=%(objectname) %(objecttype)',input=('\n'.join(sorted(wanted))+'\n').encode()).decode().splitlines()
  return {line.split()[0] for line in out if len(line.split())==2 and line.split()[1] in ('tree','blob','commit','tag')}
 m.indexed=local_indexed
 bind=json.loads((O/'BINDING.json').read_text());BASE=bind['tip'];head=git(R,'rev-parse','HEAD').decode().strip();c=m.commit(head);assert c['parents']==[BASE] and not git(R,'status','--porcelain').strip();a=m.leaves(m.commit(BASE)['tree']);z=m.leaves(c['tree']);assert set(a)==set(z)and all(a[p]==z[p]for p in a if p!=P)
 before=(O/'ACTIVE-BEFORE.md').read_bytes();body=(R/P).read_bytes();strip=lambda b:b'\n'.join(l for l in b.split(b'\n')if not l.startswith((b'claimed_at:',b'claimed_by:')));assert strip(body)==strip(before)and body!=before
 fresh=api('chicago-tickets','git/ref/heads/main')['object']['sha'];
 if fresh!=BASE:print('[rejected] stale info: bounded normal-FF guard sees ticket main advanced; official native pull/rebase must retry',file=sys.stderr);raise SystemExit(1)
 blob=api('chicago-tickets','git/blobs',{'encoding':'utf-8','content':body.decode()});assert blob['sha']==z[P][2];tr=api('chicago-tickets','git/trees',{'base_tree':m.commit(BASE)['tree'],'tree':[{'path':P,'mode':'100644','type':'blob','sha':blob['sha']}]});assert tr['sha']==c['tree'];created=api('chicago-tickets','git/commits',m.native_payload(c));assert created['sha']==head
 assert api('chicago-tickets','git/ref/heads/main')['object']['sha']==BASE;ref=api('chicago-tickets','git/refs/heads/main',{'sha':head,'force':False},'PATCH');assert ref['object']['sha']==head
 with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+head+'/'+P,headers={'User-Agent':'Chicago-sameowner-GT-renewal-immutable-readback'}),timeout=45)as f:received=f.read()
 assert received==body and gs('blob',received)==blob['sha'];git(R,'update-ref','refs/remotes/origin/main',head,BASE);at=next(l.decode().split(': ',1)[1]for l in body.splitlines()if l.startswith(b'claimed_at:'));dt=datetime.datetime.fromisoformat(at.replace('Z','+00:00'));save('PUBLISHED-RENEWAL.json',{'status':'ACTUAL_OFFICIAL_SPARSE_SAME_OWNER_ORIGINAL_PICTURE_RENEWAL_NATIVE_SHA_NORMAL_FF_IMMUTABLE_READBACK_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'parent':BASE,'tree':c['tree'],'path':P,'claim_at':at,'expires_utc':(dt+datetime.timedelta(hours=3)).isoformat(),'all_foreign_paths_modes_SHA_exact':len(a)-1,'only_changed_fields':['claimed_at','claimed_by'],'native_commit_SHA_preserved':True,'force_push':False,'claim_force_exception':bind.get('claim_force_exception','No force exception; ordinary native same-owner renewal'),'partial_generated_Board_ignored_unpublished':True,'primary_app_source_Git_site_and_nested_mirror_writes':False});print((O/'PUBLISHED-RENEWAL.json').read_text());sys.exit(0)

assert not R.exists()and not A.exists();assert os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize>=1800000000;tip=api('chicago-tickets','git/ref/heads/main')['object']['sha'];c=api('chicago-tickets','git/commits/'+tip);t=api('chicago-tickets','git/trees/'+c['tree']['sha']+'?recursive=1');assert not t['truncated'];files={r['path']:r for r in t['tree']if r['type']=='blob'};assert P in files
with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago-tickets/'+tip+'/'+P,headers={'User-Agent':'Chicago-sparse-original-GT-owner'}),timeout=45)as f:own=f.read()
assert gs('blob',own)==files[P]['sha']and b'claimed_by: Codex Carpenter picture match 2026-10-29'in own and b'claimed_at: 2026-10-29T21:01:17.'in own
with urlopen(Request('https://raw.githubusercontent.com/kevinrhaas/chicago/'+APPHEAD+'/chicago/4d/tools/ticket.mjs',headers={'User-Agent':'Chicago-current-official-ticket-tool'}),timeout=45)as f:tool=f.read()
appcommit=api('chicago','git/commits/'+APPHEAD);groups={}
for r in t['tree']:
 par,_,name=r['path'].rpartition('/');groups.setdefault(par,[]).append((name,r))
roots={'':t['sha'],**{r['path']:r['sha']for r in t['tree']if r['type']=='tree'}};meta=[]
for path,sid in roots.items():
 entries=sorted(groups[path],key=lambda x:x[0].encode()+(b'/'if x[1]['type']=='tree'else b''));b=b''.join((('40000'if r['type']=='tree'else r['mode']).encode()+b' '+n.encode()+b'\0'+bytes.fromhex(r['sha']))for n,r in entries);assert gs('tree',b)==sid;meta.append(('tree',b,sid))
meta.extend([('commit',canonical(c),tip),('blob',own,files[P]['sha'])]);free=os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize;required=FLOOR+8*1024**2;assert free>=required
save('BINDING.json',{'tip':tip,'tree':t['sha'],'path':P,'old_blob':files[P]['sha'],'old_sha256':sha(own),'full_tree_entries':len(files),'only_materialized_tickets':[P,'T-2250-2499/T-2372-match-eliza-chappel-s-infant-school-to-its-pictu.md'],'tool_sha256':sha(tool),'app_policy_head':APPHEAD,'method':'Real Git non-cone sparse checkout; full actual index/tree, no invented foreign bodies. Native partial derived Board/JSON ignored and never published.','workspace_free':free,'required_conservative_workspace':required,'primary_or_nested_mirror_writes':False})
for root in [R,A]:
 subprocess.run(['/usr/local/bin/git','init','-q','--initial-branch=main',str(root)],env=E,check=True)
 for k,v in [('protocol.https.allow','never'),('protocol.http.allow','never'),('remote.origin.promisor','false'),('user.name','polecat-steward'),('user.email','steward@polecat.live')]:git(root,'config',k,v)
git(R,'config','remote.origin.url','https://github.com/kevinrhaas/chicago-tickets.git');git(A,'config','remote.origin.url','https://github.com/kevinrhaas/chicago.git')
# Preserve every foreign blob through read-only canonical object alternates; hydrate only genuinely missing current blobs.
(R/'.git/objects/info/alternates').write_text('/workspace/GT-sparse-official-renewal-publisher-20261030/tickets/.git/objects\n')
for k,b,s in meta:put(R,k,b,s)
ids={r['sha']:r for r in files.values()};check=git(R,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();missing=[ids[l.split()[0]]for l in check if l.endswith(' missing')];assert sum(r['size']for r in missing)<4*1024**2
hydrated=[]
for r in missing:
 j=api('chicago-tickets','git/blobs/'+r['sha']);b=base64.b64decode(j['content']);assert len(b)==r['size'];put(R,'blob',b,r['sha']);hydrated.append({'path':r['path'],'sha':r['sha'],'bytes':len(b),'sha256':sha(b)})
save('OBJECT-RECOVERY.json',{'status':'REAL_FULL_CURRENT_TREE_READONLY_ALTERNATES_BOUNDED_MISSING_BLOBS_ONLY','missing':hydrated,'primary_or_nested_writes':False})
(R/'.git/info/exclude').write_text('/BOARD.md\n/tickets.json\n')
git(R,'config','core.sparseCheckout','true');git(R,'config','core.sparseCheckoutCone','false');(R/'.git/info/sparse-checkout').write_text('/'+P+'\n/T-2250-2499/T-2372-match-eliza-chappel-s-infant-school-to-its-pictu.md\n');git(R,'update-ref','refs/heads/main',tip);git(R,'update-ref','refs/remotes/origin/main',tip);git(R,'read-tree','-mu','HEAD');assert not git(R,'status','--porcelain').strip()
put(A,'commit',canonical(appcommit),APPHEAD);git(A,'update-ref','--no-deref','HEAD',APPHEAD);TOOL.parent.mkdir(parents=True,exist_ok=True);TOOL.write_bytes(tool);assert not(A/'site/4d').exists()
index=git(R,'ls-files','--stage','-z');actual={}
for line in index.split(b'\0'):
 if line:
  h,p=line.split(b'\t');mode,s,stage=h.decode().split();assert stage=='0';actual[p.decode()]=(mode,s)
assert actual=={p:(r['mode'],r['sha'])for p,r in files.items()};materialized=[p for p in R.glob('T-*/T-*.md')if p.is_file()];assert set(materialized)=={R/P,R/'T-2250-2499/T-2372-match-eliza-chappel-s-infant-school-to-its-pictu.md'};(O/'ACTIVE-BEFORE.md').write_bytes(own)
# Repo-mode native pull reads current main, never a primary mirror; remote app branch scan is real ls-remote.
(O/'bin').mkdir();wrapper=O/'bin/git';wrapper.write_text('''#!/usr/bin/env python3
import os,sys,subprocess
from pathlib import Path
O=Path(__file__).resolve().parent.parent;R=O/'tickets';A=O/'app';a=sys.argv[1:];env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
if a in [['-C',str(R),'pull','--rebase','--quiet','origin','main'],['-C',str(R),'pull','--rebase','-q','origin','main']]:os.execv(sys.executable,[sys.executable,str(O/'run.py'),'pull'])
if a==['-C',str(R),'push','-q','origin','HEAD:main']:os.execv(sys.executable,[sys.executable,str(O/'run.py'),'push'])
if a==['ls-remote','--heads','origin']:os.execve('/usr/local/bin/git',['git','-c','protocol.https.allow=always','ls-remote','--heads','https://github.com/kevinrhaas/chicago.git'],env)
b=a[:]
while b and b[0]=='-C':
 assert Path(b[1]).resolve().is_relative_to(R.resolve()) or Path(b[1]).resolve().is_relative_to(A.resolve());b=b[2:]
if b and b[0]in ['rev-parse','status','diff','log','add','commit','rebase','reset','ls-files','show','symbolic-ref','cat-file']:
 os.execve('/usr/local/bin/git',['git','-c','protocol.https.allow=never','-c','protocol.http.allow=never',*a],env)
sys.exit('Sparse original-picture guard denied unexpected Git operation')
''');wrapper.chmod(0o700);env=dict(E,PATH=str(O/'bin')+':'+E['PATH'],CHICAGO_TICKETS_DIR=str(R))
cmd=['node',str(TOOL),'claim','T-2382','--by','Codex Carpenter picture match 2026-10-29'];q=subprocess.run(cmd,cwd=TOOL.parent.parent,env=env,capture_output=True,text=True,timeout=90);(O/'OFFICIAL-NO-FORCE.log').write_text(q.stdout+q.stderr)
status=git(R,'status','--porcelain').decode();unchanged=git(R,'rev-parse','HEAD').decode().strip()==tip and not status and(R/P).read_bytes()==own;save('RESULT.json',{'status':'ACTUAL_OFFICIAL_SPARSE_CB_NO_FORCE_REFUSAL'if q.returncode else'ACTUAL_OFFICIAL_SPARSE_CB_NO_FORCE_EXIT0_REVIEW_REQUIRED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':q.returncode,'log':q.stdout+q.stderr,'native_head':git(R,'rev-parse','HEAD').decode().strip(),'claim_fields_unchanged':unchanged,'full_index_foreign_modes_SHAs_preserved':index==git(R,'ls-files','--stage','-z'),'partial_board_JSON_not_published':not(A/'site/4d').exists(),'primary_source_nested_mirror_mutations':False,'workspace_allocated':sum(p.stat().st_blocks*512 for p in O.rglob('*')if p.is_file()and not p.is_symlink()),'workspace_free':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize});print((O/'RESULT.json').read_text())
