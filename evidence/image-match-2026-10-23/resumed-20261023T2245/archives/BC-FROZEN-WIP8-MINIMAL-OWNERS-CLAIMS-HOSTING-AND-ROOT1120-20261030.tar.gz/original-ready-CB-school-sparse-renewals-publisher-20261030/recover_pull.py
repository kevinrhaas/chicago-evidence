from pathlib import Path
import json,subprocess,os,datetime,base64,hashlib
O=Path(__file__).parent;ns={'__file__':str(O/'run.py')};src=(O/'run.py').read_text();exec(compile(src[:src.index("if len(sys.argv)>1")],str(O/'run.py'),'exec'),ns);api=ns['api'];g=ns['git'];put=ns['put'];canon=ns['canonical'];R=ns['R'];P=ns['P'];bind=json.loads((O/'BINDING.json').read_text());BASE=bind['tip'];head=g(R,'rev-parse','HEAD').decode().strip();fresh=api('chicago-tickets','git/ref/heads/main')['object']['sha']
if fresh==BASE:raise SystemExit(0)
c=api('chicago-tickets','git/commits/'+fresh);t=api('chicago-tickets','git/trees/'+c['tree']['sha']+'?recursive=1');assert not t['truncated'];rows={r['path']:r for r in t['tree']if r['type']=='blob'};assert rows[P]['sha']==bind['old_blob'],'Active original-picture ticket blob changed; not ours to renew blindly';assert not g(R,'status','--porcelain').strip();groups={}
for r in t['tree']:
 par,_,name=r['path'].rpartition('/');groups.setdefault(par,[]).append((name,r))
for path,sid in {'':t['sha'],**{r['path']:r['sha']for r in t['tree']if r['type']=='tree'}}.items():
 es=sorted(groups[path],key=lambda x:x[0].encode()+(b'/'if x[1]['type']=='tree'else b''));b=b''.join((('40000'if r['type']=='tree'else r['mode']).encode()+b' '+n.encode()+b'\0'+bytes.fromhex(r['sha']))for n,r in es);put(R,'tree',b,sid)
boundary='569704af79cd3695da93183704a4217cf5c34f0e';seen=set();pending=[fresh,BASE]
while pending:
 sid=pending.pop()
 if sid in seen or sid==boundary:continue
 seen.add(sid);assert len(seen)<=128,'Refuse unbounded claim-rebase metadata ancestry'
 try:
  raw=g(R,'cat-file','commit',sid);parents=[l[7:].decode()for l in raw.split(b'\n\n',1)[0].splitlines()if l.startswith(b'parent ')]
 except subprocess.CalledProcessError:
  q=api('chicago-tickets','git/commits/'+sid);put(R,'commit',canon(q),sid);parents=[x['sha']for x in q['parents']]
 pending.extend(parents)
ids={r['sha']:r for r in rows.values()};check=g(R,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();missing=[ids[l.split()[0]]for l in check if l.endswith(' missing')];assert sum(r['size']for r in missing)<4*1024**2
for r in missing:
 q=api('chicago-tickets','git/blobs/'+r['sha']);b=base64.b64decode(q['content']);assert len(b)==r['size'];put(R,'blob',b,r['sha'])
if head==BASE:
 g(R,'read-tree','-mu',fresh);g(R,'update-ref','refs/heads/main',fresh,BASE)
else:
 assert g(R,'show','-s','--format=%P',head).decode().strip()==BASE
 assert g(R,'diff','--name-only',BASE,head).decode().splitlines()==[P]
 out=g(R,'rebase','--reapply-cherry-picks','--onto',fresh,BASE);(O/'NATIVE-CLAIM-REBASE.log').write_bytes(out)
new=g(R,'rev-parse','HEAD').decode().strip();g(R,'update-ref','refs/remotes/origin/main',fresh,BASE);bind.update(tip=fresh,tree=t['sha'],previous_sparse_tip=BASE,full_tree_entries=len(rows));(O/'BINDING.json').write_text(json.dumps(bind,indent=2)+'\n');(O/'OFFICIAL-RECOVERY-REBASE.json').write_text(json.dumps({'status':'ACTUAL_NATIVE_SINGLE_CLAIM_REBASE_ON_FOREIGN_MAIN_WITH_ACTIVE_ORIGINAL_OLD_BLOB_UNCHANGED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'oldbase':BASE,'newbase':fresh,'oldhead':head,'new_native_head':new,'active_old_blob_unchanged':True,'missing_foreign_blobs_hydrated':len(missing),'no_forcepush':True},indent=2)+'\n')
