Only these two directories were retired, under root's explicit storage grant:

- `/workspace/T2378-native-main-prototype-run-20261030/runtime`
- `/workspace/T2378-native-low-projection-run-20261030/runtime`

The latest attic runtime is retained whole. All main/low nonruntime files and
every attic ordinary file were rehashed after retirement: 221 preserved files,
including independent closed-authority meshes, data, actual entries, raw render,
full source comparison, unreviewed match, ROOT reviews, recipes, controllers,
RESTORE maps and unchanged CLOSED manifests. Private browser/TMP/XDG roots
`/workspace/b2378p30`, `b2378l30` and `b2378a30` were not traversed or deleted;
their root inode/metadata remained exact.

`PREFLIGHT.json` is the ordinary restore manifest. Each target lists all142
regular files with original path/bytes/SHA-256/mode/inode, all1048 symlink paths
and exact targets, existing ownership markers/reapers, and durable archive member
bindings. There were no unknown/special files or multiply linked ordinary
payloads. All native stage descendants were reaped. Both pre-mutation scans
found no live process with a selected runtime in cwd/exe/argv, open FDs or maps.
Inaccessible unrelated daemon FD sets, if any, were recorded rather than treated
as evidence that these owned paths were active.

Immutable GitHub archives were independently fetched and verified **in RAM**:

| Checkpoint | Publication commit | Own archived members checked |
|---|---|---:|
|724|`e2b39226251f9ac748366bfd13c194576a0a7717`|167 main actual files including its author manifest|
|725|`1df35df33d10acdb10e8325f09de4ebb94eb1873`|12 lower-projection readiness/review files including its manifest|
|726|`bbbd2a5fdc59224187f2b386e32e892b426e42d7`|352 lower actual, attic actual/proposal/review members|

Each HTTP transport had exact byte count, SHA-256 and Git blob SHA-1. Full
reassembled gzip archive SHA-256 passed, followed by every selected tar member's
actual bytes, SHA-256 and mode. No local tar copy or replacement fixture was
created. The full immutable raw URLs, chunk order/hashes and archive SHA are in
`PREFLIGHT.json durable_banks`.

To restore later, first obtain a separate root phase. Download/reassemble the
listed immutable archive transport into memory (726 has two ordered parts),
check its recorded transport/blob/archive hashes, then extract ONLY the exact
`archived_ordinary_restore_members` whose paths are under the selected runtime.
Write each to its original `/workspace/<archive_member>` path, restore its mode,
and verify bytes/SHA/mode against `targets[].ordinary`. Recreate ONLY each
declared symlink with the exact saved target; never extract arbitrary archive
paths or follow links to copy/delete shared assets. Existing unchanged original
`RESTORE.json` maps remain outside the retired directories.

The bank contains the actual native input bytes; mutable primary files are not
substitutes. Symlinks point to the existing canonical primary/shared inputs.
Original PLAN recipes/guards describe the relevant frozen source revisions
(main trial430557a…, lower trial9d97c819…). Validate canonical input refs/expected
hashes before any replay. A restore does not authorize checking out or modifying
primary during a full gate, rerunning an old controller on a new head, or
restamping a native recipe. Reprepare a future controller for its actual checked
head and resource/CPU lease if another native run is needed.

Python's symlink-resistant `shutil.rmtree` removed only the two allowlisted
runtime roots after repeating ownership/payload/inode/live-reference checks.
All1048 unique symlink targets were snapshotted and remained present with exact
device/inode/size/nlink/mtime afterward; no target was followed for deletion.

`RETIRED.json` records exactly21,512,192 exclusive allocated bytes reclaimed,
equal to the observed workspace free-space increase:
551,358,464→572,870,656B. This exceeds the requested10MiB and the root phone
workspace precondition562,036,736B. Ledger writes consume a small part of that
remaining headroom; consult current free space before starting any job.

The sampled shared TMP space was1,795,977,216B both before and after mutation,
below the unchanged1,800,000,000B caller floor. This workspace-only retirement
did not write/delete TMP or caches and did not waive that separate precondition.
Root was told the concrete current TMP condition; a new phone/native job must
wait for its own phase to resolve it. No additional cleanup scope was assumed.

The original CLOSED manifests are intentionally unchanged, and now refer to
archive-restorable retired runtime members. Their independent output authority
and raw evidence remain live. Add this ledger to checkpoint728 so a successor
can distinguish safe retirement from missing unbanked work. Do not rerun the
retirement controller after its selected directories are absent.
