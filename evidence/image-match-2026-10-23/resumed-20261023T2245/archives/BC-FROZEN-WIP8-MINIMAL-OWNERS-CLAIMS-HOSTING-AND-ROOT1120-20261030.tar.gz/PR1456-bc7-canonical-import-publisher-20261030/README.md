# Exact bc canonical native object import and cached-origin CAS

Actual PASS10:55:05:82 missing canonicalobjects (47nativecommit/tree metadata including intermediatehistorytrees,33tipblobs,2genuinependingentries), raw28,828,485B/4Kallocationupper12,984,320B. Native Git SHAs/parents/signatures preserved; everybc/checked9d leaf and blob size verified. No isolatedsource/fetch/lazyfetch/GC/repack or primarysource/index/config write. Only cachedorigin/dev moved expected35→exactfreshbc afterreadbacks.

Checked9d/source137/pub5/all2073models/indexSTAGING+flags/config/otherrefs remainedexact. V1 stopped beforeANYobjectwrites because rawindexstatcache refreshed; failedreceipt preserved. Rootaccepted V2semanticindex+flags guard, withrawSHA separate. SuccessfulV2 happenedtorawSHA-match too, but no generalrawcacheidentity claim. A preparation-script syntax typo was corrected beforeitran; no sourceeffects.

FinalWS564355072B/TMP1803366400B. Allchildrenreaped0. This closes ONLYthe import phase: actualgenuinemerge/nativeowners/currentbcsourcegate/phone/PRpush/merge remain author-owned. Rootsourcelease released immediatelyafteractualreceipt. Parent audit has exactincomingworkbook532 semantic-only evidence, unchangedledger441/workflow06f8. No artifact should be retagged as laternative/source completion.
