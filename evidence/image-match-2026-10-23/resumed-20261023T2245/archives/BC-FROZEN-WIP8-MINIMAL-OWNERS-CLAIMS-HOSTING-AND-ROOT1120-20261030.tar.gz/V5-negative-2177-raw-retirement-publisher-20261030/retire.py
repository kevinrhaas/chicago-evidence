from pathlib import Path
import os,json,stat,hashlib,datetime

os.sched_setaffinity(0,{2});os.nice(19)
W=Path('/workspace');O=Path(__file__).parent
P=W/'negative-resident-restoration-and-original-readiness-checkpoint-publisher-20261030'
BASE=W/'PR1456-a0fe-object-only-prep-first-fort-20261030/fixture-v5/accidental-primary-native-postimages'
assert not (O/'RESULT.json').exists(),'Do not repeat completed retirement'
sha=lambda b:hashlib.sha256(b).hexdigest()
save=lambda n,j:(O/n).write_text(json.dumps(j,indent=2)+'\n')
def free():s=os.statvfs(W);return s.f_bavail*s.f_frsize
def ordinary_ancestors(p):
 for parent in p.parents:
  assert stat.S_ISDIR(os.lstat(parent).st_mode) and not parent.is_symlink(),parent
  if parent==W:break
def no_fds():
 matches=[];inaccessible_owned=[];unreadable_other=0;uid=os.getuid();live_references=[];zombies=0
 release=json.loads((W/'PR1456-a0fe-object-only-prep-first-fort-20261030/retirement/RESULT.json').read_bytes())
 assert release['all_native_children_closed_and_no_open_fixture_FDs']
 recorded=[]
 for row in release['all_native_reapers']:
  rp=Path(row['path']);assert sha(rp.read_bytes())==row['sha256'];rj=json.loads(rp.read_bytes());assert rj['all_children_reaped']
  for key in ['wrapper_pid','command_pid']:
   pid=rj.get(key)
   if not pid:continue
   try:
    status=Path('/proc',str(pid),'status').read_text();state=next(x for x in status.splitlines() if x.startswith('State:'))
    assert '\tZ' in state or '\tX' in state,('Recorded native phasePID still live',pid,state)
   except (FileNotFoundError,ProcessLookupError):state='ABSENT'
   recorded.append({'pid':pid,'state':state})
 for d in Path('/proc').iterdir():
  if not d.name.isdecimal():continue
  try:
   owner=(d/'status').read_text();u=next(x for x in owner.splitlines() if x.startswith('Uid:')).split()[1];state=next(x for x in owner.splitlines() if x.startswith('State:'))
  except (FileNotFoundError,ProcessLookupError):continue
  except PermissionError:unreadable_other+=1;continue
  if '\tZ' in state or '\tX' in state:zombies+=1;continue
  try:
   cmd=(d/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
   if any(s in cmd for s in [str(BASE),str(W/'PR1456-a0fe-object-only-prep-first-fort-20261030/fixture-v'),'/tmp/c4d-a0']):live_references.append({'pid':d.name,'kind':'commandline_owned_phase_reference'})
  except (FileNotFoundError,ProcessLookupError):continue
  except PermissionError:
   if int(u)==uid:raise AssertionError('Cannot classify liveowned process commandline '+d.name)
  try:
   for fd in (d/'fd').iterdir():
    try:target=os.readlink(fd)
    except (FileNotFoundError,ProcessLookupError):continue
    except PermissionError:
     if int(u)==uid:inaccessible_owned.append(str(fd))
     else:unreadable_other+=1
     continue
    if target.removesuffix(' (deleted)').startswith(str(BASE)+'/'):matches.append({'pid':d.name,'fd':fd.name,'path':target})
  except (FileNotFoundError,ProcessLookupError):continue
  except PermissionError:
   if int(u)==uid:inaccessible_owned.append(str(d/'fd'))
   else:unreadable_other+=1
 result={'matches':matches,'live_owned_phase_references':live_references,'recorded_phase_PIDs_closed':recorded,'zombies_with_no_open_files_by_definition':zombies,'inaccessible_unrelated_ownedUID_process_fds':inaccessible_owned,'unreadable_other_uid_entries':unreadable_other,'scope':'Root-approved preciseownedphase guard: allrecorded nativePIDs closed/reaped, no liveownedphase commandline or visible rawpathFD references. Unrelatedsandboxdaemon FD coverage reported honestly; author explicitlyreleased negativebytes. No universalvisibility claim.'}
 assert not matches and not live_references,result
 return result

complete=json.loads((P/'COMPLETE.json').read_bytes());pub=json.loads((P/'PUBLICATION.json').read_bytes())
assert complete['status']=='PASS' and complete['publication']==pub['commit']=='0c31499acc3f6e8abaefe30474ddf6b5a63355c4'
assert complete['availability_commit']=='9ea8e115c999d46658e3e22ebd2a668f366aa070' and pub['all_prior_remote_file_paths_independently_preserved']
record=pub['new_archive_records'][0];assert record['sha256']=='00b19d4a12ec833bddd94a536e1858a100990aacee5aa2cb1c0628c6b82f351d' and record['bytes']==12002482
assert record['source_manifest_sha256']=='3b152e13468afac65c3b90db966a6a1bbc9010bd5f51540e15e1872456c1d92a' and record['source_file_count']==2420
assert sha((P/'MANIFEST.json').read_bytes())==record['source_manifest_sha256']
assert all(r['status']=='PASS' for r in pub['readback']) and all(r['status']=='PASS' for r in complete['readback'])
transport=record['remote_transport'];assert transport['archive_sha256']==record['sha256'] and transport['archive_bytes']==record['bytes'] and len(transport['parts'])==2
plan=json.loads((P/'NEGATIVE-BACKUP-RESTORE-PLAN.json').read_bytes());rows=plan['members'];assert len(rows)==2177 and sum(r['bytes'] for r in rows)==37934319
author=W/'PR1456-a0fe-object-only-prep-first-fort-20261030/v5-public-negative-closure/CLOSED-MANIFEST.json';assert sha(author.read_bytes())=='6f7e9b0582291b66c1af1c1716499bd824765095e25c042818141c2eb3fed816'
a=json.loads(author.read_bytes());assert a['no_active_consumer_of_negative_raw_bytes']
eligible={r['path']:r for r in a['files'] if Path(r['path']).is_relative_to(BASE)}
assert set(eligible)=={r['path'] for r in rows} and len(eligible)==2177
restore={'status':'COMPLETE_727_STRICT_IMMUTABLE_ALL_MEMBER_PROOF_RESTORE_AUTHORITY','publication':pub['commit'],'availability_commit':complete['availability_commit'],'index':complete['index'],'archive_record':record,'transport':transport,'negative_author_manifest_sha256':sha(author.read_bytes()),'source_restore_plan_sha256':sha((P/'NEGATIVE-BACKUP-RESTORE-PLAN.json').read_bytes()),'members':rows,'instructions':plan['restoration'],'no_primary_source_restoration_from_negative_bytes':True}
save('RESTORE.json',restore)
before_free=free();checks=[]
for r in rows:
 p=Path(r['path']);assert p.is_relative_to(BASE) and '..' not in p.parts;ordinary_ancestors(p)
 st=os.lstat(p);assert stat.S_ISREG(st.st_mode) and not p.is_symlink() and st.st_nlink==1 and st.st_size==r['bytes'] and stat.S_IMODE(st.st_mode)==int(r['mode'],0),p
 assert sha(p.read_bytes())==r['sha256'],p
 checks.append({'path':str(p),'dev':st.st_dev,'inode':st.st_ino,'bytes':st.st_size,'mode':stat.S_IMODE(st.st_mode),'nlink':st.st_nlink,'ctime_ns':st.st_ctime_ns,'sha256':r['sha256'],'allocated_bytes':st.st_blocks*512})
fd_before=no_fds();save('PRECHECK.json',{'status':'ALL2177_EXACT_OWN_ORDINARY_NLINK1_HASH_SIZE_MODE_ANCESTORS_NOFD_PASS','files':checks,'fd_guard':fd_before,'workspace_free':before_free})
retired=[]
with (O/'RETIRED.jsonl').open('w') as journal:
 for r in checks:
  p=Path(r['path']);ordinary_ancestors(p);s=os.lstat(p)
  assert (s.st_dev,s.st_ino,s.st_size,stat.S_IMODE(s.st_mode),s.st_nlink,s.st_ctime_ns)==(r['dev'],r['inode'],r['bytes'],r['mode'],1,r['ctime_ns']) and stat.S_ISREG(s.st_mode),p
  assert sha(p.read_bytes())==r['sha256'],p
  p.unlink();journal.write(json.dumps(r)+'\n');journal.flush();retired.append(r)
assert len(retired)==2177 and all(not Path(r['path']).exists() for r in checks)
fd_after=no_fds();after_free=free()
result={'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'retired_count':len(retired),'raw_bytes':sum(r['bytes'] for r in retired),'allocated_file_bytes_unlinked':sum(r['allocated_bytes'] for r in retired),'workspace_free_before':before_free,'workspace_free_after':after_free,'observed_workspace_free_delta':after_free-before_free,'only_owned_closed_negative_raw_files':True,'restore_pointer':str(O/'RESTORE.json'),'immutable_publication':pub['commit'],'immutable_availability_commit':complete['availability_commit'],'strict727_all_members_verified_before_any_unlink':True,'all_metadata_classification_restoration_other_files_retained':True,'no_primary_source_Git_or_privateprofile_operations':True,'fd_guard_before':fd_before,'fd_guard_after':fd_after,'limits':'Observed free delta includes this retirementledger allocation and any unrelatedconcurrentmetadata. Exactreleasedfileblocks counted separately; no directory/otherfile deletion.'}
save('RESULT.json',result);print(json.dumps(result,indent=2))
