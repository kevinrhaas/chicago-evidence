from pathlib import Path
import base64,datetime,hashlib,json,os,shutil,subprocess
P=Path(__file__).resolve().parent;j=json.loads((P/'PREPARED.json').read_text());repo=j['repository'];branch='steward/t2378-beaubien-credited-source-images-20261030'
os.sched_setaffinity(0,{2});SHA=lambda b:hashlib.sha256(b).hexdigest();GIT=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def api(ep,data=None,method=None):
 cmd=['gh','api','repos/'+repo+'/'+ep,'--header','Cache-Control: no-cache']
 if method:cmd+=['--method',method]
 if data is not None:cmd+=['--input','-']
 return json.loads(subprocess.check_output(cmd,input=json.dumps(data).encode()if data is not None else None,env=E))
assert not(P/'PR-CREATED.json').exists()
assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
assert api('git/ref/heads/main')['object']['sha']==j['base'],'Main advanced: recompose native own-row union against current main; no force update'
base=json.loads((P/'IMAGE-MAIN-BASE.json').read_text());nodes=[]
for row in j['files']:
 raw=Path(row['path']).read_bytes();assert SHA(raw)==row['sha256']and len(raw)==row['bytes']
 b=api('git/blobs',{'encoding':'base64','content':base64.b64encode(raw).decode()},'POST');assert b['sha']==GIT(raw)
 nodes.append({'path':row['repo_path'],'mode':'100644','type':'blob','sha':b['sha']})
tree=api('git/trees',{'base_tree':j['base_tree'],'tree':nodes},'POST');full=api('git/trees/'+tree['sha']+'?recursive=1');assert not full.get('truncated')
old={r['path']:(r['mode'],r['type'],r['sha'])for r in base['leaves']if r['type']!='tree'};new={r['path']:(r['mode'],r['type'],r['sha'])for r in full['tree']if r['type']!='tree'};changed={r['repo_path']for r in j['files']}
assert set(new)-set(old)==changed-{'prairie-1904/MANIFEST.json'}and not(set(old)-set(new))
assert all(new[k]==v for k,v in old.items()if k not in changed)
title='T-2378: host the credited keyed Beaubien reference image'
commit=api('git/commits',{'message':title,'tree':tree['sha'],'parents':[j['base']]},'POST')
assert commit['tree']['sha']==tree['sha']and[r['sha']for r in commit['parents']]==[j['base']]
assert api('git/ref/heads/main')['object']['sha']==j['base']
ref=api('git/refs',{'ref':'refs/heads/'+branch,'sha':commit['sha']},'POST');assert ref['object']['sha']==commit['sha']
body='''T-2378 needs a credited held reference on the Beaubien homestead’s Images tab. This adds only the full keyed panorama’s native display JPEG and thumbnail plus their generated manifest rows. The scene is labelled1831; the exact keyed reproduction is verified in John Wentworth’s *Fort Dearborn* (1881), printedp86, and credits Juliette A.Kinzie’s *Wau-Bun* (1857). The engraver is not established. Existing public-domain status and the publication/source credit are retained; no new licence or independent historical identification is claimed.

The official Chicago `fetch_image.py` produced both derivatives from the already-held original (SHA-256624d8f1f52a75bf30653e8cbf37a388478b0ddf5a02f1fadf727cf2144b84c3f). The truthful local-file fetch receipt remains in provenance; the public catalog URL identifies the1881 publication. The official unmodified `sync_image_store.py` generated the two source/rights rows in an isolated curation folder. All1,314 existing manifest rows and every unrelated repository leaf are preserved, including the current manifest’s broader reference-copy policy text.

Validation: both JPEGs decoded and were directly inspected; dimensions are1400×760 and400×217, total288,252B. Exact byte counts/SHA-256 and immutable Git blob readback are checked. Application curation/camera/model adoption, source-scoped image review and browser checks follow in the separate Chicago app PR; this image-only PR does not close T-2378 or promote app main/production.
'''
(P/'PR-BODY.md').write_text(body)
pr=api('pulls',{'title':title,'head':branch,'base':'main','body':body,'draft':False},'POST');assert pr['head']['sha']==commit['sha']and pr['base']['ref']=='main'
received=[]
for row,node in zip(j['files'],nodes):
 raw=base64.b64decode(api('git/blobs/'+node['sha'])['content']);assert SHA(raw)==row['sha256']and GIT(raw)==node['sha']
 received.append({'path':row['repo_path'],'bytes':len(raw),'sha256':SHA(raw),'git_blob':node['sha']})
result={'status':'ACTUAL_THREE_PATH_BE AUBIEN_CREDITED_IMAGE_PR_CREATED_IMMUTABLE_READBACK_PASS'.replace('BE AUBIEN','BEAUBIEN'),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':repo,'base':j['base'],'head':commit['sha'],'tree':tree['sha'],'parents':[j['base']],'branch':branch,'PR':pr['number'],'url':pr['html_url'],'all_other_repository_leaves_exact':len(old)-1,'all_foreign_manifest_rows_preserved':j['all_existing_foreign_manifest_rows_preserved'],'native_files_immutable_readback':received,'merged':False,'Pages_verified':False,'app_primary_Git_source_site_tickets_written':False,'local_images_checkout_written':False}
(P/'PR-CREATED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='native_files_immutable_readback'},indent=2))
