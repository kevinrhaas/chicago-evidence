"""Read-only hosted-image/adoption-row guard. Does not authorize a stale app snapshot."""
from pathlib import Path
import argparse,hashlib,json,os
os.sched_setaffinity(0,{2});P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--snapshot',type=Path,default=Path('/workspace/T2378-current-graphic-adoption-prep-20261030/current9d97-images'));a=ap.parse_args()
D=a.snapshot;SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
public=json.loads((P/'PUBLIC-TWO-URL-READBACK.json').read_text());assert public['workflow_conclusion']=='success'
merged=json.loads((P/'MERGED.json').read_text());assert public['hosting_main_merge_commit']==merged['merged_commit']=='8458e64e7e788ec0e5b2254bfeca1cd41ffed40a'
plan=json.loads((D/'ADOPTION-PLAN.json').read_text());store=json.loads((D/'postimages/chicago/prairie_1904_v1/research/images/STORE.json').read_text())
records=json.loads((D/'postimages/chicago/prairie_1904_v1/research/images/stream-beaubien-picture-references.json').read_text());assert len(records)==1;record=records[0]
cam=json.loads((D/'postimages/chicago/4d/data/reference_views/jb_beaubien_homestead/keyed-1831-diagnostic.json').read_text())
manifest=json.loads((P/'COMPOSED-IMAGE-MANIFEST.json').read_text());assert cam['library_image']==record['id']=='early-beaubien-keyed-1831'
assert cam['source_id']=='kinzie_1857_chicago_1831_panorama'and cam['diagnostic_only']is True
assert SHA(D/'postimages/chicago/4d/data/reference_views/jb_beaubien_homestead/keyed-1831-diagnostic.json')==plan['canonical_camera']['sha256']
assert record['local']['original_sha256']=='624d8f1f52a75bf30653e8cbf37a388478b0ddf5a02f1fadf727cf2144b84c3f'
for row in public['public']:
 name=row['url'].rsplit('/',1)[1];assert row['status']==200 and row['exact_native_approved_bytes']
 assert store['files'][name]=={'bytes':row['bytes'],'sha256':row['sha256']}
 e=manifest['files'][name];assert e['bytes']==row['bytes']and e['sha256']==row['sha256']and e['record']==record['id']
 assert e['catalog_url']==record['catalog_url']and e['rights']==record['rights']and e['rights_basis']==record['rights_basis']
assert plan['recipe_sha256']=='fdac754ae1397f961e54d428d198e3d27d90bea7f4c67cece5f4b1cbeed7f5a7'
print(json.dumps({'status':'READONLY_HOSTED_BYTES_CREDIT_LIBRARY_CAMERA_STORE_BINDINGS_PASS','snapshot':str(D),'PR':14,'hosting_merge_commit':merged['merged_commit'],'public_two_JPEG_total_B':288252,'app_native_recipe_unchanged':plan['recipe_sha256'],'app_primary_writes':False,'does_not_approve_stale_app_preimages':True,'future_post1456_rebind_canonical_capture_owners_fullgate_BOTH_PR_merge':'still owed'},indent=2))
