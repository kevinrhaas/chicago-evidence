from pathlib import Path
import base64,datetime,hashlib,json,os,subprocess
P=Path(__file__).resolve().parent;j=json.loads((P/'PR-CREATED.json').read_text());repo=j['repository'];os.sched_setaffinity(0,{2})
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');SHA=lambda b:hashlib.sha256(b).hexdigest()
def api(ep,data=None,method=None):
 cmd=['gh','api','repos/'+repo+'/'+ep,'--header','Cache-Control: no-cache']
 if method:cmd+=['--method',method]
 if data is not None:cmd+=['--input','-']
 return json.loads(subprocess.check_output(cmd,input=json.dumps(data).encode()if data is not None else None,env=E))
assert not(P/'MERGED.json').exists();pr=api('pulls/'+str(j['PR']));checks=api('commits/'+j['head']+'/check-runs');statuses=api('commits/'+j['head']+'/status');files=api('pulls/'+str(j['PR'])+'/files?per_page=100');reviews=api('pulls/'+str(j['PR'])+'/reviews')
assert pr['state']=='open'and not pr['draft']and pr['mergeable']is True and pr['mergeable_state']=='clean'
assert pr['head']['sha']==j['head']and pr['base']['ref']=='main'
assert not{'hold','do not merge','blocked'}&{r['name'].lower()for r in pr['labels']}
assert not any(r['state']=='CHANGES_REQUESTED'for r in reviews)
assert all(r['status']=='completed'and r['conclusion']in['success','neutral','skipped']for r in checks['check_runs'])
assert all(r['state']=='success'for r in statuses['statuses'])
expected={r['path']for r in j['native_files_immutable_readback']};assert{r['filename']for r in files}==expected and len(files)==3
assert all(r['status']==('modified'if r['filename'].endswith('MANIFEST.json')else'added')for r in files)
assert api('git/ref/heads/main')['object']['sha']==j['base']
(P/'PREMERGE-CHECKS.json').write_text(json.dumps({'PR':j['PR'],'head':j['head'],'base':j['base'],'mergeable':pr['mergeable'],'mergeable_state':pr['mergeable_state'],'checks':checks,'statuses':statuses,'reviews':reviews,'files':files},indent=2)+'\n')
merged=api('pulls/'+str(j['PR'])+'/merge',{'sha':j['head'],'merge_method':'squash','commit_title':'T-2378: host the credited keyed Beaubien reference image (#14)'},'PUT');assert merged['merged']is True
tip=api('git/ref/heads/main')['object']['sha'];assert tip==merged['sha'];commit=api('git/commits/'+tip)
assert commit['tree']['sha']==j['tree']and[r['sha']for r in commit['parents']]==[j['base']]
for row in j['native_files_immutable_readback']:
 raw=base64.b64decode(api('git/blobs/'+row['git_blob'])['content']);assert SHA(raw)==row['sha256']and len(raw)==row['bytes']
now=api('pulls/'+str(j['PR']));assert now['merged']and now['merge_commit_sha']==tip
result={'status':'ACTUAL_IMAGE_PR14_EXPECTED_HEAD_NORMAL_SQUASH_MERGED_MAIN_TREE_AND_BLOBS_VERIFIED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':repo,'PR':j['PR'],'url':j['url'],'checked_head':j['head'],'merged_commit':tip,'tree':j['tree'],'parent':j['base'],'PR_check_runs_count':checks['total_count'],'PR_statuses_count':statuses['total_count'],'normal_GitHub_merge_no_force_or_bypass':True,'all_1314_foreign_manifest_rows_and_1346_unrelated_leaves_preserved':True,'Pages_verified':False,'app_primary_Git_source_site_tickets_and_localimages_checkout_written':False}
(P/'MERGED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
