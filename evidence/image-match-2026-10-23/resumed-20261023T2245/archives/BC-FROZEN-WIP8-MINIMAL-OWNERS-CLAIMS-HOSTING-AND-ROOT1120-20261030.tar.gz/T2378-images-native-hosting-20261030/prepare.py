"""Prepare ONLY two already-native-generated Beaubien JPEGs plus native manifest union."""
from pathlib import Path
import copy,datetime,hashlib,json,os,shutil,subprocess
from PIL import Image
P=Path(__file__).resolve().parent;Q=Path('/workspace/T2378-current-graphic-adoption-prep-20261030');R=Path('/workspace/chicago')
os.sched_setaffinity(0,{2});os.nice(19)
PF=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
assert not(P/'PREPARED.json').exists()
assert shutil.disk_usage('/workspace').free>=536870912+8*1024**2 and shutil.disk_usage('/tmp').free>=1800000000
base=json.loads((P/'IMAGE-MAIN-BASE.json').read_text());before=base['manifest'];assert set(before)=={'_doc','generated','files'}
payload=json.loads((Q/'IMAGE-HOST-ENTRYWISE.json').read_text());native=json.loads((Q/'IMAGE-NATIVE-PROOF.json').read_text())
record=json.loads((Q/'current9d97-images/postimages/chicago/prairie_1904_v1/research/images/stream-beaubien-picture-references.json').read_text())[0]
assert record['rights']=='public domain'and record['rights_basis']and record['catalog_url']
assert native['local']['original_sha256']=='624d8f1f52a75bf30653e8cbf37a388478b0ddf5a02f1fadf727cf2144b84c3f'
assert PF(R/'chicago/prairie_1904_v1/tools/fetch_image.py')==native['tool_sha256']
store=P/'native-store/prairie-1904/files';store.mkdir(parents=True,exist_ok=True)
files=[]
for row in payload['files']:
 src=Path(row['file']);assert PF(src)==row['sha256']and src.stat().st_size==row['bytes']
 assert row['name']not in before['files']and row['path']not in{r['path']for r in base['leaves']}
 dst=store/row['name'];shutil.copyfile(src,dst);assert PF(dst)==row['sha256']
 with Image.open(dst)as im:im.verify()
 with Image.open(dst)as im:px=list(im.size);assert max(px)<=(400 if'-thumb'in dst.name else 1400)
 files.append({'repo_path':row['path'],'path':str(dst),'bytes':row['bytes'],'sha256':row['sha256'],'px':px})
assert sum(r['bytes']for r in files)==288252
# Exact existing native sync owner, isolated collection/curation only. Its own
# generated two-entry manifest is then unioned into CURRENT remote ownership.
cur=P/'curation';(cur/'tools').mkdir(parents=True,exist_ok=True);(cur/'research/images').mkdir(parents=True,exist_ok=True)
shutil.copyfile(R/'chicago/prairie_1904_v1/tools/sync_image_store.py',cur/'tools/sync_image_store.py')
(cur/'research/images/stream-beaubien-picture-references.json').write_text(json.dumps([record],indent=2,ensure_ascii=False)+'\n')
env=dict(E,PRAIRIE_IMAGE_STORE=str(store))
with(P/'NATIVE-SYNC.log').open('a')as log:
 run=subprocess.run(['python3','-B','tools/sync_image_store.py'],cwd=cur,env=env,stdout=log,stderr=subprocess.STDOUT)
assert run.returncode==0
made=json.loads((store.parent/'MANIFEST.json').read_text());assert set(made['files'])=={r['name']for r in payload['files']}
for row in files:
 entry=made['files'][Path(row['repo_path']).name];assert entry['sha256']==row['sha256']and entry['bytes']==row['bytes']
 assert entry['record']==record['id']and entry['catalog_url']==record['catalog_url']and entry['rights']=='public domain'
 assert entry==payload['own_source_rows'][Path(row['repo_path']).name]
combined=copy.deepcopy(before);combined['generated']=made['generated']
# Current remote _doc includes the README's owner-approved reference-copy policy.
# The older native helper's narrower explanatory _doc is not a reason to regress
# that foreign metadata. Both new rows are existing-cleared public-domain items.
(P/'DOC-COMPOSITION.json').write_text(json.dumps({'current_remote_doc':before['_doc'],'native_helper_doc':made['_doc'],'current_remote_doc_preserved_exact':True,'new_native_rows_rights':'public domain','policy_basis':'Current remote README includes owner-approved attributed reference copies as well; do not replace its broader explanatory text.'},indent=2)+'\n')
assert not(set(before['files'])&set(made['files']));combined['files'].update(made['files']);combined['files']=dict(sorted(combined['files'].items()))
assert all(combined['files'][k]==v for k,v in before['files'].items())
assert[(k,v)for k,v in combined['files'].items()if k in before['files']]==list(before['files'].items())
out=P/'COMPOSED-IMAGE-MANIFEST.json';out.write_text(json.dumps(combined,indent=1,ensure_ascii=False)+'\n')
files.append({'repo_path':'prairie-1904/MANIFEST.json','path':str(out),'bytes':out.stat().st_size,'sha256':PF(out)})
prepared={'status':'ACTUAL_NATIVE_TWO_JPEGS_AND_NATIVE_SYNC_THREE_PATH_IMAGE_PR_READY','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':'kevinrhaas/chicago-images','base':base['head'],'base_tree':base['tree'],'files':files,'native_sync_exit':run.returncode,'native_sync_tool_sha256':PF(cur/'tools/sync_image_store.py'),'native_new_manifest_entries':made['files'],'all_existing_foreign_manifest_rows_preserved':len(before['files']),'all_other_root_manifest_metadata_preserved':True,'normal_branch_PR_merge_required':True,'app_primary_Git_source_tickets_or_images_local_checkout_written':False,'existing_closed_54file_packet_unchanged':True,'public_Pages_verified':False}
(P/'PREPARED.json').write_text(json.dumps(prepared,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'base':base['head'],'paths':len(files),'JPEG_bytes':288252,'foreign_rows_preserved':len(before['files']),'image_collection_total_B':sum(v['bytes']for v in combined['files'].values()),'free_B':{p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']}},indent=2))
