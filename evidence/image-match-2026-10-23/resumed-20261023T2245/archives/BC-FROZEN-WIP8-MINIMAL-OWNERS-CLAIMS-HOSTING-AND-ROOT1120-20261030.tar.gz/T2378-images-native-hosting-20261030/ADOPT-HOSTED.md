Image hosting is complete through normal [PR #14](https://github.com/kevinrhaas/chicago-images/pull/14).
Checked branch head `db3698ec06ff83e2d7560ff0fb8b17694a646b0a` was squash merged
to the image repository's hosting `main` as
`8458e64e7e788ec0e5b2254bfeca1cd41ffed40a`. Its parent is
`6013be1ded19f800526d2ce707af02577f02e7d6`; tree is
`66a886ce3fed4bad6c772fe66bb8ed09253cc604`.

The exact-commit [Pages deployment](https://github.com/kevinrhaas/chicago-images/actions/runs/41044239701)
succeeded. Both ordinary public URLs returned HTTP 200 and decoded as JPEG with
the exact approved native bytes:

| Asset | Bytes | SHA-256 |
|---|---:|---|
| [Display](https://kevinrhaas.github.io/chicago-images/prairie-1904/files/early-beaubien-keyed-1831.jpg) | 262,256 | `20c2baf03a905b446b76da3e75cf37f235a9e201b7a8a824f159a7d820d12d2c` |
| [Thumbnail](https://kevinrhaas.github.io/chicago-images/prairie-1904/files/early-beaubien-keyed-1831-thumb.jpg) | 25,996 | `9e0dbb1020b0c25e48331c9a8e7bd33615249b927fe8bad39d1914167fbb89b5` |

Only those two native-generated files and their native-generated source/rights
manifest rows changed. All 1,314 foreign manifest rows and 1,346 unrelated
repository leaves were preserved. The current remote manifest's broader
reference-copy explanatory text was retained; the older native sync helper's
narrower text did not replace it. No existing image was deleted or overwritten.
Both derivatives were directly inspected, JPEG-decoded and checked against the
closed native fetch receipt. They preserve the whole keyed frame and its credit.

Rights and attribution remain the existing public-domain source record: verified
1881 Wentworth keyed reproduction, printed Wau-Bun 1857 credit, 1831 depicted
scene, engraver unestablished after Juliette A. Kinzie. No new licence, independent
house identification, historical dimensions or app grade is claimed. The
truthful local-file native fetch receipt and public catalogue credit remain.

This publication supersedes ONLY the “image host pending” step in the immutable
54-file adoption preparation. Do not duplicate the image PR, refetch or regenerate
the approved files. `guard_app_bindings.py` verifies the hosted bytes, current
prepared library/STORE rows and canonical camera's library/source binding, with
no app writes:

```bash
source /workspace/shared/resume-chicago-env.sh
python -B /workspace/T2378-images-native-hosting-20261030/guard_app_bindings.py
```

For a newly rebound app snapshot, supply its path with `--snapshot`. This image
guard does not approve old app preimages. The future post1456 dev head is still
unknown: reprepare the entrywise app snapshot against its actual source and
native recipe pins. Preserve all current foreign STORE/manifest/Lib context.
The actual `fdac…` model and `6a44…` canonical metadata proposal retain their
existing qualification; fresh canonical native capture, reviewed match overlay,
native owners/grader, current full gate, BOTH desktop/phone, separate app MPR/CI
and merge to dev remain owed.

This work used GitHub metadata APIs for the image repository and light external
CPU2 preparation only. No app source/Git/index/ref/ticket/site or local images
checkout was written. No app main/production promotion occurred. The image
branch and normal merged PR preserve the checkpoint in GitHub; this folder
holds native sync, immutable blob, policy, merge, deployment and public HTTP
proof for the next evidence checkpoint.
