# Exact initial spatial-batch update-range cleanup — proposal only

The existing official 9d97 phone reading is **399.272855758667 MiB / 400 MiB**. It is not a reading of the newer combined bc tree. No failure or successful headroom for that tree is asserted here. Its relevant resident totals were JS heap108,613,364B, array buffers88,805,889B, GPU buffers161,054,304B and textures60,194,377B. Structures own96,732,356B of estimated GPU geometry, railway34,261,744B; the proposed change targets retained JS metadata, not those GPU buffers.

## One exact change

`spatial-batch.proposed.js` adds one cleanup at the end of `batchPieces`, after all pieces, bounds and existing coalescing have been assembled: clear each backing attribute's and index's initial updateRanges list. The before/proposed files and exact one-file patch are frozen beside this note. Nothing is applied to primary source.

The vendor's BatchedMesh.setGeometryAt appends one `{ start, count }` object per attribute and, for indexed pieces, one for the index. The first WebGLAttributes.createBuffer uploads the entire array through bufferData and calls the onUpload callback; it does not inspect or clear these partial-update lists. Consequently the initial lists survive even though they describe a whole initial backing already uploaded. An empty list on a later buffer update means upload the whole backing. A later setGeometryAt still appends its own fresh ranges because this cleanup runs once at assembly, not in a global upload hook.

`buildings.js` already performs this same exact cleanup for structure batches around lines1011–1017, with the earlier T3213 reading reporting about12MB in that structure path. **That figure is not the saving of this generic proposal.** Generic terrain, railway-ground, street and yard spatial batches currently do not clear their initial lists.

No typed array, vertex, index, attribute encoding, shader, material, confidence grade, instance matrix, bound, winding, coalescing selection or picking table is changed. Exact GPU/ArrayBuffer saving from this change is zero. The intended benefit is garbage collection of no-longer-reachable JS update-range objects and their array slots.

## Counts and limits

`KNOWN-RANGE-COUNTS.json` contains exact counts from the currently published1835 records:38,224 ground range objects,30,012 continuous-base objects and9,512 street objects, totaling77,748. These are explicitly1835, not a substitute count for1904.

For1904, the current e1871_postfire281×361 heightfield's unprotected stride6/15m continuous base has2,820 cells/5,640 triangles. Counting their exact x/z triangle centroids on the existing40m partition yields414 pieces, or1,656 initial range objects across its three attributes and index. This is arithmetic over the existing grid record, not a mesh export, render or memory test. Current1904 frontage is absent, so the no-protected-crossing path applies; a future protection input must be recounted.

The official phone receipt does not record per-batch piece/range counts. Remaining1904 terrain and railway ground metadata is therefore unpriced. V8 object headers, property layout and array capacity cannot be inferred exactly from that receipt. A transparent planning estimate of40–80 retained bytes per range gives64.7–129.4KiB for the known1904 base alone; the known1835 subtotal gives2.97–5.93MiB. Neither is a measured resident saving, a generic12MB claim or a promise that this change by itself accommodates the incoming Hibbard model/planting bytes.

## Meaningful qualification if adopted

After the genuine bc integration, apply only if its current source still equals the frozen before SHA. The existing tests below cover the affected contract:

```bash
node tools/check_spatial_batch.mjs
node tools/test_batch_coalesce.mjs
node tools/check_upload_release.mjs
```

The first already verifies indexed and nonindexed triangles, winding and all attributes, exact materials/depth policy, identity matrices, boundary bounds, raycast points/distances, frustum selection and reversible reach. Its randomized worker/fallback parity covers attribute/index bytes. The second verifies unchanged coalesced draws; the third protects post-upload release behavior. These commands are recommendations, **not run by this read-only task**.

A focused additional assertion in the existing spatial-batch contract should verify initial range lists are empty, then modify an existing geometry through the vendor setGeometryAt and verify fresh nonempty update ranges and the expected backing bytes. This distinguishes dropping dead assembly metadata from disabling legitimate later uploads. It should not change the renderer behavior or weaken any existing assertion.

The current source/full gate must still pass. The final official complete1904 mobile measurement on the actual committed integrated head determines budget acceptance under the unchanged400MiB ceiling. This proposal does not require a new whole visual matrix if exact buffers, bounds and selections remain identical under the existing tests; qualify the changed spatial-batch consumer explicitly when reusing older app/geometry evidence. No source edits, tests, browser, native build or ticket filing ran here.
