from pathlib import Path
import subprocess,json,hashlib,datetime
R=Path('/tmp/st-mary-picture-20261025');O=Path('/tmp/Mary1334-currentdev-ending-20261026T2110');oldjail='8cd2db60777947a16399459fd2945eb804849a51';own='bffc4cff33670bde34e718751ea8712e087eef8b';incoming='373851d158a7b6fc701b9cae1a651aa4b3823f97'
def blob(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=R)
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=R).decode().strip()==incoming
resolved=[];report=[]
for path in ['chicago/4d/docs/LIBERTIES.md','chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md']:
 base=blob(oldjail,path);ours=blob(own,path);theirs=blob(incoming,path);assert ours.startswith(base),('OWN_NOT_APPEND_ONLY',path);tail=ours[len(base):];assert b'T-2384'in tail or b'St Mary'in tail;assert tail.strip()not in theirs;result=theirs+tail;(R/path).write_bytes(result);assert result.startswith(theirs);resolved.append(path);report.append({'path':path,'incoming_prefix_bytes':len(theirs),'own_append_bytes':len(tail),'incoming_sha256':hashlib.sha256(theirs).hexdigest()})
path='chicago/4d/tools/check.sh';assert blob(own,path)==blob(oldjail,path),'UnexpectedMarycheckregistrationchange';(R/path).write_bytes(blob(incoming,path));resolved.append(path);report.append({'path':path,'action':'EXACT_INCOMING_ALL_NEW_REGISTRATIONS_PRESERVED'})
path='chicago/4d/assets/manifest.web.json';base=json.loads(blob('a9c5bd4a9715e4d5634c536d0efcd516ea9c3f01',path));ours=json.loads(blob(own,path));theirs=json.loads(blob(incoming,path));absent=object();choices=[]
def merge(b,a,c,parts=()):
 if a==c:return a
 if a==b:return c
 if c==b:return a
 if isinstance(a,dict)and isinstance(c,dict)and isinstance(b,dict):
  result={}
  for key in sorted(set(b)|set(a)|set(c)):
   value=merge(b.get(key,absent),a.get(key,absent),c.get(key,absent),parts+(key,))
   if value is not absent:result[key]=value
  return result
 if len(parts)==2 and parts[0]=='masters':
  f=R/'chicago/4d/assets/gltf'/parts[1];actual=hashlib.sha256(f.read_bytes()).hexdigest();matches=[label for label,v in [('own',a),('incoming',c)]if v==actual];assert len(matches)==1,('NO_UNIQUE_ALREADY_PRODUCED_MASTER_ROW',parts,matches,actual);value=a if matches[0]=='own'else c;choices.append({'path':'/'.join(parts),'selected_already_produced_row':matches[0],'actual_master_sha256':actual});return value
 raise RuntimeError(('UNCLASSIFIED_MANIFEST_CONFLICT',parts))
merged=merge(base,ours,theirs);(R/path).write_text(json.dumps(merged,indent=2)+'\n');resolved.append(path);report.append({'path':path,'action':'THREE_WAY_EXISTING_NATIVE_DERIVATIVE_ROWS_ONLY','conflicting_existing_rows':choices,'no_invented_fingerprint':True})
path='chicago/4d/changelog.d/T-2380.json';f=R/path
if f.exists():
 old=f.read_bytes();pending=json.loads(old);published=json.loads(blob('499a0e72d98f6c351d95bc62bac06a2ffa8c3c41',path));assert pending['title']==published['title'];assert published['items'][:len(pending['items'])]==pending['items'],'OLD_PENDING_NOT_EXACT_PUBLISHED_PREFIX';assert pending['title'].encode()in blob(incoming,'chicago/4d/renderers/web/js/changelog.js');(O/'retained-already-folded-T2380-pending.json').write_bytes(old);f.unlink();resolved.append(path);report.append({'path':path,'action':'REMOVE_RESURRECTED_ALREADY_FOLDED_DUPLICATE','exact_title_and_item_prefix_of_native499_entry':True,'canonical_incoming_373_unchanged':True})
subprocess.run(['git','add','--',*resolved],cwd=R,check=True)
for p in ['chicago/4d/renderers/web/js/main.js','chicago/4d/renderers/web/js/railway.js','chicago/4d/renderers/web/js/ktx2.js','chicago/4d/renderers/web/js/buildings.js','chicago/4d/renderers/web/js/changelog.js']:
 assert(R/p).read_bytes()==blob(incoming,p),('LATEST_RUNTIME_OR_CANONICAL_HISTORY_CHANGED',p)
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'AUTHORED_APPEND_ONLY_AND_NATIVE_ROW_MERGE_RESOLVED','rows':report,'remaining':subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=R).decode().splitlines()};(O/'AUTHORED-RESOLUTION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
