def _roof(b: MeshBuilder, p: FortStructureParams, x0, y0, x1, y1,
          eave_z: float, conf: float, c_wall: float = None, grid0: float = 0.0) -> float:
    """The roof, with the walls under it carried up to meet it.

    T-2123, on the owner's report that the artillery house's roof was "hovering".
    It was: this function drew a shed roof's high edge 1.6 m above a wall that
    stopped at the eave, with nothing under either end, and every gable roof here
    drew its gable triangles IN ROOF SHINGLE, a quarter-metre outboard of the wall
    and floating at the eave line a hand's breadth above the wall head. A roof sits
    ON its walls: the wall plane under a gable or a shed's high side is the wall,
    built of what the wall is built of (`_gable_wall`), and the roof plane passes
    through the wall head at the wall line and runs on DOWN to its eave, so there
    is no slot of sky between the two.
    """
    c_wall = conf if c_wall is None else c_wall
    t = math.tan(math.radians(p.roof_pitch_deg))
    if p.roof_type in ("flat", "none"):
        b.add_poly([(x0, y0, eave_z), (x0, y1, eave_z), (x1, y1, eave_z),
                    (x1, y0, eave_z)], conf, M_ROOF)
        return eave_z
    if p.roof_type == "gable":
        return _gable_roof(b, p, x0, y0, x1, y1, eave_z, t, conf, c_wall, grid0)
    if p.roof_type == "shed":
        return _shed_roof(b, p, x0, y0, x1, y1, eave_z, t, conf, c_wall, grid0)
    return _hip_roof(b, x0, y0, x1, y1, eave_z, p.roof_pitch_deg, conf,
                     pyramid=(p.roof_type == "pyramid"))
