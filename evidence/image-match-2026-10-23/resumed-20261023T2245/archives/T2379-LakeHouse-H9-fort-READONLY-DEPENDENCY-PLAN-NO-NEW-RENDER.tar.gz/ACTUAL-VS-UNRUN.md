# Evidence timepoints

| Evidence | Actual scope | Status here |
|---|---|---|
| Original T-2379 proposal | Focused AST/schema/parameter checks; two-file proposal | Unapplied; original no-render handoff is not the last evidence |
| Fort-combined 20261023-050131-135464 | Pinned Blender 4.5.3 old before/after exports; four fixed 800×640 neutral engineering images | ACTUAL, reopened directly; not source-camera/native-app/current-recipe proof |
| T-2379 context packet | Three-file source/record/dossier proposal; focused Photos/grade/index estimate | Actual old LIGHT checks, UNAPPLIED; no new render; old 168 KB/21-byte dependency is stale |
| Public H9 5112aadaa | Lake House record exact to old baseline; roof none still builds cap; inferred grade; no reference-view camera | Pinned object audit only, no new build/browser |
| Fort T-3105 current checkpoint | Genuine official 25 masters; seven fort targets, eighteen default controls | ACTUAL producer receipt; Lake House remains byte-exact 66-triangle default; no Lake House fix/scaffold adopted |
| This audit | Source/picture/GLB-header/AST/blob/dependency reading | LIGHT only; no claims, canonical edits or new producer/render/native acceptance |
| Post-T-3105 roof split and optional later-context adoption | Minimal future authored delta, genuine25 refresh, derivatives/native/card/gates | UNRUN; not authorized for execution by this audit |
| Work scaffold or calibrated later-print camera | No fort scaffold control or keyed date-correct July image | Not prepared/executed/adopted; no match promotion |
