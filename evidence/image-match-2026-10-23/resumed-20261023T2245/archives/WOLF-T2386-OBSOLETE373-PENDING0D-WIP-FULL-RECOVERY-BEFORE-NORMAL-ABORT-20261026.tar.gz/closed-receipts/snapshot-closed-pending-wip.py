from pathlib import Path
import subprocess,json,hashlib,os,shutil,datetime
R=Path('/workspace/chicago');S=Path('/tmp/Wolf1336-currentdev-ending-20261026T2152');O=Path('/tmp/Wolf1336-OBSOLETE373-PENDING-WIP-PRESERVED-20261026T2314');O.mkdir();env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');env.pop('GIT_NO_LAZY_FETCH',None)
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R,env=env)
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
head=git('rev-parse','HEAD').decode().strip();merge=git('rev-parse','MERGE_HEAD').decode().strip();assert head=='373851d158a7b6fc701b9cae1a651aa4b3823f97'and merge=='0d17d69463f6a4e8227e96750d03d93b418353f3';assert json.loads((S/'native-reaper.json').read_text())['all_children_reaped'];gitdir=Path(git('rev-parse','--absolute-git-dir').decode().strip());indexBefore=sha((gitdir/'index').read_bytes());configBefore=sha((gitdir/'config').read_bytes())
parents={};known={}
for ref in [head,merge]:
 d={}
 for row in git('ls-tree','-rz','--full-tree',ref).split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,kind,key=meta.decode().split();path=path.decode();d[path]={'mode':mode,'type':kind,'blob':key}
  if kind=='blob':known.setdefault(key,{'ref':ref,'path':path,'mode':mode})
 parents[ref]=d
(O/'git-metadata').mkdir()
for n in ['index','HEAD','MERGE_HEAD','MERGE_MSG','ORIG_HEAD','AUTO_MERGE']:
 p=gitdir/n
 if p.is_file():shutil.copy2(p,O/'git-metadata'/n)
index=git('ls-files','-s','-z');(O/'git-metadata/index-stages.z').write_bytes(index);(O/'git-metadata/status-porcelain-v2.txt').write_bytes(git('status','--porcelain=v2','--untracked-files=all'));(O/'git-metadata/diff-names-vs-373.z').write_bytes(git('diff','--name-only','-z',head));stored={}
def store_blob(b):
 key=oid(b)
 if key not in stored:
  p=O/'unique-blobs'/key;p.parent.mkdir(exist_ok=True);p.write_bytes(b);stored[key]={'path':p.relative_to(O).as_posix(),'bytes':len(b),'sha256':sha(b)}
 return key
stageRefs=[]
for entry in index.split(b'\0'):
 if not entry:continue
 meta,path=entry.split(b'\t',1);mode,key,stage=meta.decode().split()
 if key not in known:
  b=git('cat-file','blob',key);assert oid(b)==key;store_blob(b);stageRefs.append({'path':path.decode(),'stage':int(stage),'mode':mode,'blob':key,'capsule_blob':stored[key]['path']})
changed=set(x.decode()for x in git('diff','--name-only','-z',head).split(b'\0')if x);changed.update(x.decode()for x in git('ls-files','--others','--exclude-standard','-z').split(b'\0')if x);rows=[]
for path in sorted(changed):
 p=R/path
 if not p.exists()and not p.is_symlink():rows.append({'path':path,'state':'deleted'});continue
 b=os.readlink(p).encode()if p.is_symlink()else p.read_bytes();key=oid(b);row={'path':path,'bytes':len(b),'sha256':sha(b),'git_blob':key,'filesystem_mode':p.lstat().st_mode&0o777,'symlink':p.is_symlink()}
 if key in known:row.update(storage='IMMUTABLE_PUBLIC_PARENT_BLOB',restore=known[key])
 else:store_blob(b);row.update(storage='CAPSULE_UNIQUE_BLOB',restore=stored[key])
 rows.append(row)
(O/'WORKTREE-PATHS.json').write_text(json.dumps(rows,indent=2)+'\n');(O/'UNIQUE-INDEX-BLOBS.json').write_text(json.dumps(stageRefs,indent=2)+'\n');(O/'PUBLIC-PARENT-TIP-MAPS.json').write_text(json.dumps(parents,indent=2)+'\n')
(O/'closed-receipts').mkdir()
for p in S.iterdir():
 if p.is_file()and p.suffix in ['.json','.log','.py']:shutil.copy2(p,O/'closed-receipts'/p.name)
assert git('rev-parse','HEAD').decode().strip()==head and git('rev-parse','MERGE_HEAD').decode().strip()==merge;assert sha((gitdir/'index').read_bytes())==indexBefore and sha((gitdir/'config').read_bytes())==configBefore
files=[]
for p in sorted(O.rglob('*')):
 if p.is_file():b=p.read_bytes();files.append({'path':p.relative_to(O).as_posix(),'bytes':len(b),'sha256':sha(b),'mode':p.stat().st_mode&0o777})
v={'closed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETE_OBSOLETE373_WOLF_PENDING_MERGE_WIP_PRESERVED_READONLY_BEFORE_NORMAL_ABORT','HEAD':head,'MERGE_HEAD':merge,'public_tip_0d_is_child_of_checked562':True,'every_changed_worktree_path':len(rows),'unique_content_blobs':len(stored),'unique_blob_bytes':sum(r['bytes']for r in stored.values()),'staged_unique_refs':len(stageRefs),'index_and_merge_metadata_copied_exact':True,'index_and_config_unchanged_after_readonly_capture':True,'GIT_OPTIONAL_LOCKS':0,'all_other_content_recoverable_from_immutable_public_parent_blobs':True,'nativeFAILED_ENOSPC_notchecked_notready':True,'no_force_no_codecommit_no_source_deletion_or_abort_yet':True,'required_next_step':'Wait immutable publisher readback; then normal abort ONLY this owned pendingmerge, start newprivate currentcheckedMary/currentdev branch and normally merge actualpublic0d17; one currentnative202+full3. No fakeMERGE_HEAD or uncheckedcommit.','restore_note':'On same public parents recreate normal pendingmerge, materialize unique capsule blobs into Git with hash verification, restore each changed path from its immutable public parent or capsule blob with recorded mode, then restore index stages. Ignored generated mirrors/protectedGlessner caches were intentionally not touched or copied.','files':files};p=O/'MANIFEST.json';p.write_text(json.dumps(v,indent=2)+'\n');print(str(p),sha(p.read_bytes()),len(files),sum(f['bytes']for f in files),'changed',len(rows),'unique',sum(r['bytes']for r in stored.values()))
