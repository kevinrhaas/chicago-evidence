from pathlib import Path
import os,subprocess,json,datetime,time,hashlib,zipfile,gzip,io,xml.etree.ElementTree as ET,shutil
R=Path('/workspace/chicago');A=R/'chicago/4d';O=Path('/tmp/Wolf1336-currentdev-ending-20261026T2152');incoming='373851d158a7b6fc701b9cae1a651aa4b3823f97';head='373851d158a7b6fc701b9cae1a651aa4b3823f97';merge='0d17d69463f6a4e8227e96750d03d93b418353f3';os.sched_setaffinity(0,{3});env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(PYTHONPATH='/workspace/shared/python',NODE_PATH='/workspace/shared/node/node_modules',PW_EXECUTABLE='/usr/bin/chromium',TMPDIR='/tmp/Wolf1336-native-tmp-20261026',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',CHECK_JOBS='1',C4D_RULINGS_BASE=incoming);Path(env['TMPDIR']).mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=R,env=env)
def save(name,value):(O/name).write_text(json.dumps(value,indent=2)+'\n')
def sha(data):return hashlib.sha256(data).hexdigest()
print('WAIT for Mary owning native actual reaper; then only Wolf owning derivation on CPU3, no browser/full3.',flush=True)
while True:
 try:lease=json.loads(Path('/tmp/Mary1334-currentdev-ending-20261026T2110/native-reaper.json').read_text())
 except(FileNotFoundError,json.JSONDecodeError):time.sleep(2);continue
 if lease['command_exit'] is not None:break
 time.sleep(2)
assert lease['command_exit']==0 and lease['all_children_reaped'],lease
assert git('rev-parse','HEAD').decode().strip()==head;assert git('rev-parse','MERGE_HEAD').decode().strip()==merge
assert shutil.disk_usage(env['TMPDIR']).free>=1000000000
protected=json.loads((O/'PROTECTED-AUTHORED-MODELS-BEFORE-NATIVE.json').read_text())
def check_protected():
 bad=[]
 for path,digest in protected.items():
  f=R/path;data=os.readlink(f).encode() if f.is_symlink() else f.read_bytes()
  if sha(data)!=digest:bad.append(path)
 assert not bad,bad
check_protected();steps=[]
def command(name,cmd):
 print('START',name,now(),flush=True)
 with(O/(name+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit':p.returncode,'closed_at':now()};steps.append(row);save('NATIVE-STEPS.json',steps);print('CLOSED',name,p.returncode,now(),flush=True);assert p.returncode==0,(name,p.returncode)
command('native-resolve',['node','tools/rederive.mjs','--resolve']);assert not git('diff','--name-only','--diff-filter=U').strip();check_protected()
def xlsx(data):
 with zipfile.ZipFile(io.BytesIO(data))as archive:
  result={}
  for name in archive.namelist():
   value=archive.read(name)
   if name.endswith(('.xml','.rels')):
    root=ET.fromstring(value)
    if name=='docProps/core.xml':
     for element in list(root):
      if element.tag=='{http://purl.org/dc/terms/}modified':root.remove(element)
    result[name]=ET.canonicalize(ET.tostring(root,encoding='unicode'))
   else:result[name]=value.hex()
  return result
rows=[];artifacts=json.loads((O/'ALL44-INCOMING-METADATA.json').read_text());known={row['path']for row in artifacts}
for row in artifacts:
 path=row['path'];f=R/path;actual=f.read_bytes();before=git('show',incoming+':'+path);equal=actual==before;kind='BYTE_EXACT'
 if not equal:
  raw=O/'raw-regenerated-artifacts'/path;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_bytes(actual)
  if path.endswith('.xlsx'):equal=xlsx(actual)==xlsx(before);kind='ALL_ZIP_MEMBERS_C14N_EXCEPT_CORE_MODIFIED'
  elif path.endswith('.gz'):
   equal=gzip.decompress(actual)==gzip.decompress(before);kind='GZIP_DECOMPRESSED_BYTES'
   if not equal:
    try:equal=json.loads(gzip.decompress(actual))==json.loads(gzip.decompress(before));kind='GZIP_JSON_ALL_FIELDS'
    except(ValueError,UnicodeError):pass
  if equal:f.write_bytes(before)
 rows.append({'path':path,'regenerated_sha256':sha(actual),'incoming_sha256':sha(before),'comparison':kind,'equal':equal,'restored_serialization_only':actual!=before and equal})
save('ALL44-NATIVE-AUDIT.json',rows);assert len(rows)==44 and all(row['equal']for row in rows)
changed=git('diff','--name-only',incoming).decode().splitlines();unexpected=[p for p in changed if (p.endswith(('.xlsx','.gz'))or not p.startswith('chicago/4d/'))and p not in known];assert not unexpected,unexpected
command('native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']);command('native-publish',['bash','tools/publish.sh']);check_protected();assert not git('diff','--name-only','--diff-filter=U').strip()
result={'at':now(),'status':'WOLF_CURRENTDEV_OWNING_RESOLUTION_ALL44_PACKAGE_PUBLISH_PASS','head':head,'incoming':incoming,'cpu_affinity':[3],'protected_paths_exact':len(protected),'all44_audited':True,'steps':steps,'optional_sill_API_not_adopted':True,'current_full3_and_app_pending':True};save('NATIVE-RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
