from pathlib import Path
import subprocess,os,json,urllib.request,hashlib,collections
B=Path('/tmp/current-dev-import-20261025');R=Path('/tmp/chicago-current-objects-20261025');C=Path('/workspace/chicago')
env=dict(os.environ);env['GIT_NO_LAZY_FETCH']='1'
def git(repo,*args,input=None):
 return subprocess.check_output(['git','-C',str(repo),'-c','gc.auto=0','-c','maintenance.auto=false','-c','core.preloadIndex=false','-c','index.threads=1',*args],input=input,env=env)
head=git(R,'rev-parse','refs/heads/dev').decode().strip()
start=json.loads((B/'dev-start.json').read_text())['object']['sha'];assert head==start,(head,start)
commits=git(R,'rev-list','--parents','dev').decode().splitlines()
commit_ids=sorted({s for line in commits for s in line.split()})
batch=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(commit_ids)+'\n').encode()).decode().splitlines()
known=[x.split()[0]for x in batch if ' missing' not in x]
with urllib.request.urlopen('https://api.github.com/repos/kevinrhaas/chicago/git/trees/'+head+'?recursive=1',timeout=60)as r:raw=r.read()
(B/'tip-recursive-tree.json').write_bytes(raw);tree=json.loads(raw);assert not tree.get('truncated')
blobs=[x for x in tree['tree']if x['type']=='blob'];ids=sorted({x['sha']for x in blobs})
batch=git(C,'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(ids)+'\n').encode()).decode().splitlines();missing={x.split()[0]for x in batch if x.endswith(' missing')}
rows=[x for x in blobs if x['sha']in missing]
unique={x['sha']:x['size']for x in rows}
result={'dev':head,'tree':tree['sha'],'recursive_tree_metadata_bytes':len(raw),'fetched_commit_count':len(commits),'known_shared_commit_ancestors':known,'all_tip_blob_paths':len(blobs),'unique_tip_blobs':len(ids),'missing_tip_blob_paths':len(rows),'missing_unique_tip_blobs':len(unique),'missing_unique_blob_bytes':sum(unique.values()),'largest_missing':sorted(rows,key=lambda x:x['size'],reverse=True)[:30],'missing_blob_paths':rows,'metadata_pack_bytes':sum(p.stat().st_size for p in(R/'objects').rglob('*')if p.is_file()),'refs_changed':False,'shared_objects_written':False}
(B/'PRICE.json').write_text(json.dumps(result,indent=2)+'\n')
brief={k:v for k,v in result.items()if k not in['missing_blob_paths','largest_missing']};brief['largest_missing']=[{k:x[k]for k in ['path','sha','size']}for x in result['largest_missing'][:12]]
print(json.dumps(brief,indent=2))
