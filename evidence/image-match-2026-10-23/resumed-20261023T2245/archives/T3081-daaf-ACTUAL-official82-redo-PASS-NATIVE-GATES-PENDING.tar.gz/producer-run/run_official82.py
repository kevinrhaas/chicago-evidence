from pathlib import Path
import argparse,datetime as dt,json,hashlib,subprocess,sys,os
ROOT=Path('/tmp/chicago-log-integration/chicago/4d'); OUT=Path(__file__).resolve().parent; PIN=Path('/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender'); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'generators'));import mesh_inputs
ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['prepare','masters','web']);args=ap.parse_args()
def load(p):return json.loads(p.read_bytes())
def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
def scope():
 dates=[dt.date.fromisoformat(load(p)['target_date'])for p in sorted((ROOT/'data/scenes').glob('*.json'))]; result=[]
 for path in sorted((ROOT/'data/structures').glob('*.json')):
  st=load(path)
  if st.get('archetype')!='log_dwelling':continue
  seen=set()
  for t in dates:
   hits=[p for p in st.get('phases',[])if dt.date.fromisoformat(p['documented_range']['from'])<=t<=dt.date.fromisoformat(p['documented_range']['to'])];assert len(hits)<=1,(st['id'],t)
   if not hits:continue
   ph=hits[0]
   if ph['id'] in seen:continue
   seen.add(ph['id']);result.append({'asset':st['id']+'__'+ph['id']+'.glb','structure_id':st['id'],'phase_id':ph['id'],'inputs_sha256':mesh_inputs.structure_inputs_sha(st,ph,'log_dwelling')})
 return result
rows=scope();names={r['asset']for r in rows};assert len(rows)==len(names)==82
if args.phase=='prepare':
 assert not (OUT/'binding.json').exists()
 guards=load(Path('/tmp/log82-integration-evidence/hogan-before-guards.json'))
 for p,v in guards.items():assert sha(ROOT/p)==v['sha256'],p
 assert sha(PIN)=='5e15447670804c855fef6033ac9b8fd82696b762095becf0df79b1c2f8034397'
 assert subprocess.check_output([str(PIN),'--version'],text=True).splitlines()[0]=='Blender 4.5.3 LTS'
 protected={str(p.relative_to(ROOT)):sha(p)for sub in ['gltf','web']for p in (ROOT/'assets'/sub).glob('*.glb')if p.name not in names}
 paths={x['path']for x in load(Path('/tmp/T3081-daaf-authored-overlay/report.json'))['files']}
 sources={p:sha(ROOT.parent.parent/p)for p in paths}
 b={'prepared':now(),'HEAD':head(),'scope':rows,'hogan':guards,'protected_unrelated_assets':protected,'authored_sources':sources,'before_assets':{r['asset']:{k:sha(ROOT/'assets'/k/r['asset'])for k in ['gltf','web']}for r in rows},'native_manifest':load(ROOT/'assets/manifest.json'),'web_manifest':load(ROOT/'assets/manifest.web.json'),'blender_binary_sha256':sha(PIN)}
 (OUT/'binding.json').write_text(json.dumps(b,indent=2)+'\n');print('PREPARED actual current all-scene family:82 assets; protected',len(protected),'unrelated assets; source HEAD',b['HEAD']);sys.exit(0)
b=load(OUT/'binding.json');assert rows==b['scope'];assert head()==b['HEAD'];assert sha(PIN)==b['blender_binary_sha256']
for p,v in b['hogan'].items():assert sha(ROOT/p)==v['sha256'],p
for p,v in b['authored_sources'].items():assert sha(ROOT.parent.parent/p)==v,p
for p,v in b['protected_unrelated_assets'].items():assert sha(ROOT/p)==v,p
receipt={'phase':args.phase,'started':now(),'HEAD':head(),'scope':82,'status':'RUNNING','producer':'normal pinned generators/build.py'if args.phase=='masters'else'normal tools/web_derivatives.sh','population_writers':False};rp=OUT/('official-'+args.phase+'-receipt.json')
def save():rp.write_text(json.dumps(receipt,indent=2)+'\n')
try:
 before_native=load(ROOT/'assets/manifest.json');before_web=load(ROOT/'assets/manifest.web.json')
 if args.phase=='masters':argv=[str(PIN),'-b','-noaudio','--factory-startup','--python',str(ROOT/'generators/build.py'),'--','--only',','.join(sorted({r['structure_id']for r in rows})),'--wrote',str(OUT/'written-masters.txt')]
 else:
  assert load(OUT/'official-masters-receipt.json')['status']=='PASS';assert set((OUT/'written-masters.txt').read_text().splitlines())==names
  argv=['bash','tools/web_derivatives.sh','--only',','.join((OUT/'written-masters.txt').read_text().splitlines())]
 receipt['command']=argv;save()
 with (OUT/('official-'+args.phase+'.log')).open('w')as log:q=subprocess.run(argv,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','npm_config_cache':'/workspace/shared/npm-cache'})
 receipt['exit_code']=q.returncode;assert q.returncode==0,'actual producer failed'
 written=(OUT/'written-masters.txt').read_text().splitlines();assert len(written)==82 and set(written)==names
 assert scope()==b['scope'];assert head()==b['HEAD']
 for p,v in b['hogan'].items():assert sha(ROOT/p)==v['sha256'],p
 for p,v in b['authored_sources'].items():assert sha(ROOT.parent.parent/p)==v,p
 for p,v in b['protected_unrelated_assets'].items():assert sha(ROOT/p)==v,p
 after=load(ROOT/'assets/manifest.json');assert {k:v for k,v in before_native['assets'].items()if k not in names}=={k:v for k,v in after['assets'].items()if k not in names}
 for r in rows:assert after['assets'][r['asset']]['inputs_sha256']==r['inputs_sha256']
 if args.phase=='web':
  afterweb=load(ROOT/'assets/manifest.web.json');assert {k:v for k,v in before_web['masters'].items()if k not in names}=={k:v for k,v in afterweb['masters'].items()if k not in names}
  for n in names:assert afterweb['masters'][n]==sha(ROOT/'assets/gltf'/n)
 kind='gltf'if args.phase=='masters'else'web';changed=[n for n in sorted(names)if sha(ROOT/'assets'/kind/n)!=b['before_assets'][n][kind]];targets={'chappel_infant_school','cobweb_castle','miller_house','philo_carpenter_log_shop','wolf_point_tavern'};unexpected={r['structure_id']for r in rows if r['asset']in changed}-targets
 if unexpected:
  assert args.phase=='masters'and unexpected=={'kinzie_stable_1812'}
  known='9a0bd88ee3ab69910f4afb7f52c1082184d67994f0e97116632c3391cfbaa84f';assert sha(ROOT/'assets/gltf/kinzie_stable_1812__kinzie_1804.glb')==known
  controls=load(Path('/tmp/log82-official-checkpoint-20261023T2335/verification/kinzie-uv-control/receipt.json'));assert len(controls)==2 and all(x['sha256']==known for x in controls)
  assert load(Path('/tmp/log82-official-checkpoint-20261023T2335/verification/master-review.json'))['status']=='PASS';receipt['reviewed_exact_prior_UV_export']='kinzie_stable_1812, exact prior independently controlled9a0 hash; web must stay exact'
 receipt.update(status='PASS',finished=now(),changed_assets=changed,unchanged_assets=82-len(changed),Hogan_four_guards_exact=True,unrelated_asset_bytes_and_manifest_rows_exact=True,all82_recipe_inputs_recomputed_exact=True);save();print(json.dumps(receipt,indent=2))
except BaseException as exc:receipt.update(status='FAILED',error=str(exc));save();raise
