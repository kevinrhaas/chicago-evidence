# Guarded private gallery trial — prepared and UNRUN

This NEW controller consumes revised packet `e8877684` and immutable earlier packet `a8a11180`; it changes neither. Root approved only a private reconstructed same-west-range hypothesis. A new later heavy grant is still required. There is no canonical adoption, identity ruling, grade upgrade, source-spend claim or formal matched 1835 view.

The revised candidate SHA256 is `4fa5785909c1c6c49149a8e9803c9dc267b66fc53454a4a54dc15a3796150650`. The exact repaired backend SHA256 is `fc645a66b889e8ca837520e73d2bdee4806b0892e33591099714bff10178d64e`. The original record SHA256 is `2daff425a61fc89102628698583aa2e96da9066a1f5d9b21130035d491d81039`.

The source argument stays in the revised packet: Hubbard's retrospective 1818 upper piazza is primary; 1827/1830 west-log-range association and Kinzie's 1831 building-group continuity support an unresolved working identity. Outside/within-pickets disagreement and lack of a dated alteration record remain. All metrics, rails, canopy and existing opening positions are reconstructed. External stairs remain unmodelled and all original 16 comparisons remain DIFFERS. No 1827 occupants or uses are transferred to the 1835 population.

`camera1855-diagnostic.json` preserves the earlier seed's exact pose, intrinsics, source pixels, context members and lighting. Only its prose `solve` is clarified so it does not claim the revised hypothesis backdates 1855 fittings. It is an UNFITTED **1855 diagnostic bracket**, never a formal 1835 matched view. The left endpoint is clipped and the camera may frame poorly. Actual images must be inspected after execution; a completed script is not an appearance PASS. No source image pixels are cropped or edited.

The controller requires a NEW, clean, isolated Git checkout whose directory name begins `T2388-`, with the actually completed current baseline: all 25 fort recipes fresh, all current master/web bindings correct, the exact repaired producer/params and original officers' record. Root must prepare that checkout from the final fort source after its local work closes. This launcher does not copy a producer overlay, materialize unrelated packages, fetch, create a worktree, or mutate either active canonical writer. It refuses stale/incompatible source instead of manufacturing freshness.

The actual later command, once root supplies that checkout and the normal installed pinned Blender binary, is:

```bash
cd /workspace/T2388-private-trial-source/chicago/4d
source generators/blender.pin
PATH=/workspace/shared/tools/usr/bin:$PATH PW_EXECUTABLE=/usr/bin/chromium python -B /workspace/T2388-private-trial-execution-prep-e887-20261024/run_private_trial.py --repo /workspace/T2388-private-trial-source --out /workspace/T2388-private-gallery-actual-001 --blender "/opt/blender-dl/$BLENDER_DIR/blender" --root-heavy-granted
```

The checkout and actual-output paths above are future parameters, not existing executed results. The output directory must not exist, so each failed attempt remains distinct. `--root-heavy-granted` records the required later grant; its presence in this documentation is not permission to run it now.

The execution sequence is bounded: verify all packet hashes/source/provenance/current-input bindings; capture baseline from the 1855 diagnostic camera; apply only the three-field record candidate in the assigned isolated checkout; run normal pinned `generators/build.py --only fort_dearborn_officers_quarters --scene 1835 --wrote ...`; require exactly one written master and no unrelated manifest changes; run normal `tools/web_derivatives.sh --only fort_dearborn_officers_quarters__log_1816.glb`; verify all unrelated GLB hashes and placements; capture the candidate from identical camera/source bytes; preserve all logs, inputs, baseline bytes and outcomes. The result awaits human image review even if every command succeeds.

No native writer, standalone scene compiler, publisher, app QA, full gate or acceptance promotion runs. Git deltas are bounded to the isolated candidate record, selected master/web and their two manifests. Actual process groups/PIDs and exit/failure receipts are durable; timeouts terminate only that step's own process group. Existing photo_match cleanup remains in its normal producer. Failed attempts are preserved; nothing restores/deletes old evidence or commits/pushes a branch.

The safe read-only preparation check, already run, is:

```bash
python -B /workspace/T2388-private-trial-execution-prep-e887-20261024/run_private_trial.py --check
```

Root must inspect actual before/after images and geometric joints before considering any further action. This launcher performs a private test only. The former 1855-only packet, revised hypothesis and current canonical source remain separate.
