"""Small serial raw geometry/API tests; bpy runtime forbidden; no export/native writer."""
from pathlib import Path
from types import ModuleType
from dataclasses import asdict,replace
import ast,hashlib,importlib.util,inspect,json,math,os,subprocess,sys
sys.dont_write_bytecode=True;os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
H=Path(__file__).resolve().parent;P=Path('/tmp/chicago-next-model/T3041-gallery-front-adoption-20261024');R=Path('/tmp/chicago-next-model/T3041-native-readiness-20261024/published6bf/chicago/4d');C=H/'candidate/chicago/4d';F=P/'candidate/chicago/4d';B=P/'baseline/chicago/4d';HEAD='5d9d44646f49c69a4add36ece56bfbdab8caad70';REPO='/tmp/chicago-log-integration';sha=lambda b:hashlib.sha256(b).hexdigest()
# This existing CPU dependency store is byte-identical to actual public H4; do not copy or read dirty trees.
guards=[]
for row in json.loads((P/'read-only-dependencies.json').read_text())['files']:
 if not(row['path'].startswith('generators/')or row['path']in['data/structures.schema.json','data/source.schema.json']):continue
 raw=subprocess.check_output(['git','-C',REPO,'show',HEAD+':chicago/4d/'+row['path']]);assert sha(raw)==row['sha256'],row['path'];assert not(R/row['path']).exists()or sha((R/row['path']).read_bytes())==row['sha256'];guards.append(row)
sys.path.insert(0,str(R/'generators'))
class ForbiddenBpy(ModuleType):
 def __getattr__(self,name):raise AssertionError('bpy runtime forbidden: '+name)
sys.modules['bpy']=ForbiddenBpy('bpy');import archetypes

def load(path,name):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m

def collect(self,materials=None):
 mats=list(materials or []);base=len(mats)
 for name,(_idx,rgba,rough)in sorted(self.named.items(),key=lambda kv:kv[1][0]):mats.append({'name':name,'rgba':list(rgba),'roughness':rough})
 return {'verts':self.verts,'faces':self.faces,'confidence':self.conf,'tone':self.tone,'material_index':[base+(mi-self.NAMED_BASE)if mi>=self.NAMED_BASE else mi for mi in self.mat_index],'materials':mats}

def generator(paramsfile,codefile,label):
 p=load(paramsfile,'archetypes.fort_structure_params');archetypes.fort_structure_params=p;g=load(codefile,label);g.TonedBuilder.to_object=collect;g.simple_material=lambda name,rgba=(.8,.8,.8,1),roughness=.75:{'name':name,'rgba':list(rgba),'roughness':roughness};return p,g
old,og=generator(B/'generators/archetypes/fort_structure_params.py',B/'generators/archetypes/fort_structure.py','front_shape_original')
frozen,fg=generator(F/'generators/archetypes/fort_structure_params.py',F/'generators/archetypes/fort_structure.py','front_shape_frozen')
new,ng=generator(F/'generators/archetypes/fort_structure_params.py',C/'generators/archetypes/fort_structure.py','front_shape_new')
assert inspect.signature(frozen.FortStructureParams)==inspect.signature(new.FortStructureParams)
assert old.FortStructureParams.__match_args__==new.FortStructureParams.__match_args__ and len(old.FortStructureParams.__match_args__)==16
for k,v in inspect.signature(old.FortStructureParams).parameters.items():assert v==inspect.signature(new.FortStructureParams).parameters[k]
for key in ['gallery_storeys','face_openings']:assert inspect.signature(new.FortStructureParams).parameters[key].kind==inspect.Parameter.KEYWORD_ONLY

def param(mod,rec,ph):return mod.from_phase(next(x for x in rec['phases']if x['id']==ph),rec)
def build(mod,gen,rec,row):return gen.build(param(mod,rec,row['phase_id']),row['asset'].removesuffix('.glb'))
def digest(raw):return sha(json.dumps(raw,sort_keys=True,separators=(',',':')).encode())
manifest=json.loads((P/'review-manifest.json').read_text());rows=[];posts=[]
for row in manifest['family']:
 sid=row['structure_id'];raw=subprocess.check_output(['git','-C',REPO,'show',HEAD+':chicago/4d/data/structures/'+sid+'.json']);current=json.loads(raw);assert current==json.loads((R/'data/structures'/f'{sid}.json').read_text())
 before=build(old,og,current,row);default=build(new,ng,current,row);assert before==default,sid+':disabled/default changed'
 q=param(new,current,row['phase_id']);legacy=new.FortStructureParams(*[getattr(q,k)for k in q.__match_args__]);legacy.validate();assert asdict(legacy)==asdict(q)
 frozenfile=F/'data/structures'/f'{sid}.json';prior=json.loads(frozenfile.read_text())if frozenfile.exists()else current
 path=C/'data/structures'/f'{sid}.json';candidate=json.loads(path.read_text())if path.exists()else prior
 a,b=build(frozen,fg,prior,row),build(new,ng,candidate,row)
 if not path.exists():assert a==b,sid+':non-target overlay geometry/material/confidence changed'
 else:
  assert a!=b
  p=param(new,candidate,row['phase_id']);centres=ng._gallery_post_centres(p,.14);assert len(centres)==max(2,int(round(p.width_m/3)))+1
  margin=.07+ng.openings.CASING_W_M+ng.openings.SILL_HORN_M
  for x in centres:
   for o in new.wall_openings(p,'front'):assert x<=o['u0']-margin+1e-9 or x>=o['u1']+margin-1e-9,(sid,x,o)
  assert all(y-x>=.14-1e-9 for x,y in zip(centres,centres[1:]))
  assert centres==ng._gallery_post_centres(p,.14),'placement must be deterministic'
  # Legacy/manual double-gallery objects with absent or empty explicit fronts stay exact.
  for faces in [None,[]]:
   priorp=param(frozen,prior,row['phase_id']);newp=param(new,candidate,row['phase_id']);priorp=replace(priorp,face_openings=faces);newp=replace(newp,face_openings=faces,chimneys=priorp.chimneys,confidence=priorp.confidence)
   assert fg.build(priorp,sid)==ng.build(newp,sid),sid+':manual double-gallery fallback changed'
  assert all(o['kind']=='window'for o in p.face_openings if o['face']=='front'and o['z0']>=p.storey_height_m)
  assert sum(o['kind']=='door'and o['z0']<.3 for o in p.face_openings if o['face']=='front')==1
  posts.append({'structure':sid,'post_centres_local_u_m':centres,'all_posts_clear_both_storeys_casing_and_horn_envelopes':True})
 assert len(b['verts'])==len(b['confidence'])==len(b['tone'])and len(b['faces'])==len(b['material_index'])
 assert all(math.isfinite(v)for pt in b['verts']for v in pt);assert all(0<=v<=1 for v in b['confidence'])
 rows.append({'structure':sid,'phase':row['phase_id'],'old_default_sha256':digest(before),'new_disabled_sha256':digest(default),'prior_gallery_sha256':digest(a),'new_proposal_sha256':digest(b),'changed_by_this_overlay':path.exists()})
assert len(rows)==25 and sum(r['changed_by_this_overlay']for r in rows)==5
# Generic invalid dense-front case fails rather than drawing supports over openings.
p=param(new,json.loads((C/'data/structures/first_fort_dearborn_north_range.json').read_text()),'first_fort_1803');dense=replace(p,face_openings=[{'face':'front','kind':'window','u0':0.01,'u1':p.width_m-.01,'z0':1,'z1':2}]);dense.validate()
try:ng._gallery_post_centres(dense,.14)
except ValueError:pass
else:raise AssertionError('end support would cover explicit opening')
def nodes(p):return{n.name:n for n in ast.parse(p.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=nodes(F/'generators/archetypes/fort_structure.py'),nodes(C/'generators/archetypes/fort_structure.py');assert set(b)==set(a)|{'_gallery_post_centres'}
for key in a:
 if key!='_gallery_two_storeys':assert ast.dump(a[key])==ast.dump(b[key]),key
report={'status':'PASS','H4_exact_common_schema_guards':guards,'serial_cpu_affinity':sorted(os.sched_getaffinity(0)),'real_generator_and_mesh_calls_no_bpy_runtime':True,'all25_old_defaults_exact_vertices_faces_materials_confidence_tone':True,'all20_non_target_overlay_records_exact_to_frozen_gallery_stage':True,'only5_ranges_change_in_overlay':True,'legacy16_positionals_and_existing2_kwonly_fields_exact':True,'manual_double_gallery_None_or_empty_front_fallback_exact_all5':True,'posts_clear_both_storeys_full_casing_horn_envelopes':posts,'dense_front_refuses_instead_of_occluding':True,'all_other_generator_functions_AST_exact':True,'family':rows,'limitations':'Pure raw CPU geometry, not Blender UV/normal/GLB parity, official25 bake, app review or image acceptance. New proposal unrendered; all full image gates remain open/differs.'}
(H/'cpu-proof.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS:25 default/20 overlay non-target raw parity;5 explicit fronts/post clearances;API/fallback;no bpy runtime or export')
