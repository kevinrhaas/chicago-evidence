"""Serial source/schema/native facade/admission tests; no writer/export/browser."""
from pathlib import Path
from types import SimpleNamespace
import ast,copy,hashlib,importlib.util,json,os,subprocess,sys
sys.dont_write_bytecode=True;os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
H=Path(__file__).resolve().parent;P=Path('/tmp/chicago-next-model/T3041-gallery-front-adoption-20261024');R=Path('/tmp/chicago-next-model/T3041-native-readiness-20261024/published6bf/chicago/4d');C=H/'candidate/chicago/4d';HEAD='5d9d44646f49c69a4add36ece56bfbdab8caad70';REPO='/tmp/chicago-log-integration';sha=lambda b:hashlib.sha256(b).hexdigest();sys.path[:0]=[str(R/'tools'),str(R/'generators')]
def blob(rel):return subprocess.check_output(['git','-C',REPO,'show',HEAD+':chicago/4d/'+rel])
def load(p,name):
 sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m
import jsonschema,archetypes
params=load(P/'candidate/chicago/4d/generators/archetypes/fort_structure_params.py','archetypes.fort_structure_params');archetypes.fort_structure_params=params
facade=load(P/'candidate/chicago/4d/generators/archetypes/facade_openings.py','refine_facade')
for rel in ['tools/grade_structures.py','tools/compile_liberties.py','tools/generate_business_signboards.py','data/structures.schema.json']:
 target=R/rel
 if rel=='tools/generate_business_signboards.py':target=P/'baseline/chicago/4d'/rel
 if target.exists():assert sha(blob(rel))==sha(target.read_bytes()),rel+' native preimage changed'
controls=json.loads((H/'controls.json').read_text())['controls'];schema=json.loads(blob('data/structures.schema.json'));records={};claims=[]
for row in controls:
 sid=row['structure'];rec=json.loads((C/'data/structures'/f'{sid}.json').read_text());old=json.loads((P/'candidate/chicago/4d/data/structures'/f'{sid}.json').read_text());jsonschema.validate(rec,schema);records[sid]=rec
 assert {k:v for k,v in old.items()if k!='phases'}=={k:v for k,v in rec.items()if k!='phases'}
 a,b=old['phases'][0],rec['phases'][0];assert {k:v for k,v in a.items()if k!='form'}=={k:v for k,v in b.items()if k!='form'}
 assert {k for k in set(a['form'])|set(b['form'])if a['form'].get(k)!=b['form'].get(k)}=={'face_openings','gallery_storeys','chimneys'}
 p=params.from_phase(b,rec);front=facade.front_wall('fort_structure',p);storey=p.storey_height_m
 for level in [0,1]:
  openings=sorted([o for o in front['openings']if (o['z0']>=storey)==bool(level)],key=lambda o:o['u0'],reverse=True)
  shapes=['S'if round(o['z0']-level*storey,5)==.65 else'T'for o in openings];assert shapes==row['screen_shapes_both_storeys']
 assert all(o['kind']=='window'for o in front['openings']if o['z0']>=storey)
 assert sum(o['kind']=='door'and o['z0']<.3 for o in front['openings'])==1
 assert b['form']['chimneys']['value']==row['visible_source_chimneys']and b['form']['chimneys']['confidence']=='inferred'
 for field in ['face_openings','gallery_storeys','chimneys']:
  for source in b['form'][field].get('sources',[]):
   srcpath=C/'data/sources'/f'{source}.json'
   source_doc=json.loads((P/'candidate/chicago/4d/data/sources'/f'{source}.json').read_text())if source=='currey_1912_first_fort_birdseye'else json.loads(blob(f'data/sources/{source}.json'))
   assert source_doc['rights_status']=='public_domain',source
# Actual native ground-door/overlap functions against the same declared front, both scene dates.
def functions(path):return{n.name:n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
fns=functions(P/'candidate/chicago/4d/tools/generate_business_signboards.py');ns={'STRUCTURES':C/'data/structures','_RESOLVERS':{'fort_structure':params.from_phase},'_load':lambda p:json.loads(p.read_text()),'facade_openings':facade,'TARGET_DATE':'1812-08-14'};exec(compile('from __future__ import annotations\n'+ast.unparse(fns['_front_wall']),'<native front reader>','exec'),ns)
ens={'gbs':SimpleNamespace(_front_wall=ns['_front_wall'],facade_openings=facade),'ENTRANCE_KINDS':('door','shop_door','open_bay'),'GROUND_Z_M':.3,'OPENING_GAP_M':.15,'SHOPFRONT':frozenset({'shop_door','show_window'})}
# Load exact H4 entrance functions, not a canonical working file.
module=ast.parse(blob('tools/generate_entrances.py'));defs={n.name:n for n in module.body if isinstance(n,ast.FunctionDef)}
for name in ['front_doors','merged_openings']:exec(compile('from __future__ import annotations\n'+ast.unparse(defs[name]),'<actual H4 entrance '+name+'>','exec'),ens)
for sid in records:assert len(ens['front_doors']({'id':sid,'archetype':'fort_structure'})[0])==1 and not ens['merged_openings']({'id':sid,'archetype':'fort_structure'})
ns['TARGET_DATE']='1835-07-01'
for sid in records:assert ens['front_doors']({'id':sid,'archetype':'fort_structure'})==([],None)
# Native parser on the real H4 ledger + original three admissions + this new admission.
lib=load(R/'tools/compile_liberties.py','refine_liberty_parser');oldledger=blob('docs/LIBERTIES.md').decode();priorfrags=[(P/'liberty-fragments'/name).read_text()for name in ['first-fort-galleries.md','first-fort-face-layout.md','first-fort-chimneys-3041.md']];newfrag=(H/'liberty-fragment.md').read_text();known={p.stem:json.loads(p.read_text()).get('name','')for p in(R/'data/structures').glob('*.json')};base_ids=[m.group(1)for m in lib.HEADING.finditer(oldledger)]
for text in priorfrags+[newfrag]:assert text.split(' — ')[0].removeprefix('### ')not in set(base_ids)
ledger='## Per-subject liberties\n\n'+'\n\n'.join(priorfrags+[newfrag]);entries,problems=lib.parse(ledger,known);assert not problems,problems[:10];newentry=next(e for e in entries if e['id']=='L-first-fort-visible-front-refinement');assert len(newentry['covers'])==15
for c in newentry['covers']:
 assert c['domain']=='structure';ph=next(p for p in records[c['structure']]['phases']if p['id']==c['phase']);node=ph
 for token in c['aspect'].split('.'):node=node[token]
 assert node['confidence']in['inferred','reconstructed']
# Native grade mechanism remains separate; source admission does not alter geometry confidence.
gr=load(R/'tools/grade_structures.py','refine_grader');add=json.loads((H/'grade-rulings-fragment.json').read_text());sids={x['id']for x in json.loads(blob('data/sidecars/1812/index.json'))['structures']};assert not gr.check_rulings(add,{'1812':sids},{'whistler_1808_fort_dearborn_draught':json.loads(blob('data/sources/whistler_1808_fort_dearborn_draught.json'))})
basegrades=json.loads(blob('data/structure_grades.json'));merged={**basegrades,'pictured':basegrades['pictured']+add['pictured']}
for sid in records:assert gr.grade_structure(sid,'inferred',[],[],merged,'1812')['value']=='attested'
keys=json.loads((P/'candidate/chicago/4d/data/reconstruction/name_pool_keys.json').read_text())['read']['structures'];assert all('phases[].form.'+k+'.note'in keys for k in['face_openings','gallery_storeys','chimneys'])
# Evidence stays immutable, and no actual new comparison is claimed for this proposal.
evidence=[]
for packet,manifest in [(P,P/'PACKET-SHA256.json'),(Path('/tmp/chicago-next-model/T3041-ten-front-runner-ready-20261024/head-H4-5d9d4464'),Path('/tmp/chicago-next-model/T3041-ten-front-runner-ready-20261024/head-H4-5d9d4464/CLOSED-ARTIFACTS.json'))]:
 d=json.loads(manifest.read_text());assert all(sha((packet/x['path']).read_bytes())==x['sha256']for x in d['files']);evidence.append({'manifest':str(manifest),'sha256':sha(manifest.read_bytes()),'files_unchanged':len(d['files'])})
report={'status':'PASS','five_structure_schemas':True,'changed_form_attributes_only':['face_openings','gallery_storeys','chimneys'],'source_screen_patterns_reversed_into_local_u_correctly':True,'upper_long_windows_remain_reconstructed_no_upper_doors':True,'exact_H4_native_entrance_reader_one1812_ground_door_zero1835':True,'all_source_ids_registered_or_original_PD_Currey_proposal':True,'actual_H4_existing_heading_count_only_not_scope_revalidation':len(base_ids),'native_parser_additive_entries':len(entries),'full_H4_scope_revalidation':'Not run in this minimal source-only fixture; the complete native ledger gate remains owed at adoption, without bypassing any existing scope counter','new_exact_Covers_claims':15,'no_new_prose_READ_paths':True,'separate_five_native_grade_rulings_admissible':True,'evidence_unchanged':evidence,'new_actual_render_or_export':False}
(H/'source-api-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
