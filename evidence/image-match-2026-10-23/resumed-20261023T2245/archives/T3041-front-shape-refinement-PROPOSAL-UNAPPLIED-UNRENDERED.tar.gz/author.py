"""Author only a NEW bounded overlay over closed gallery/front prototype files."""
from pathlib import Path
import copy,difflib,hashlib,json,subprocess
H=Path(__file__).resolve().parent;P=Path('/tmp/chicago-next-model/T3041-gallery-front-adoption-20261024');B=P/'candidate';HEAD='5d9d44646f49c69a4add36ece56bfbdab8caad70';REPO='/tmp/chicago-log-integration';files=[];patch=''
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,raw):
 global patch
 old=(B/rel).read_bytes();path=H/'candidate'/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);assert old!=raw
 patch+='diff --git a/'+rel+' b/'+rel+'\n'+''.join(difflib.unified_diff(old.decode().splitlines(True),raw.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 files.append({'path':rel,'frozen_gallery_preimage_path':str(B/rel),'frozen_gallery_preimage_sha256':sha(old),'candidate_sha256':sha(raw),'application':'apply only on top of the rematerialized original first-fort-only gallery/front patch; not directly to current public H4'})
rel='chicago/4d/generators/archetypes/fort_structure.py';s=(B/rel).read_text();needle='    n = max(2, int(round(w / 3.0)))\n    for i in range(n + 1):\n        x = w * i / n\n';before,tail=s.split('def _gallery_two_storeys(',1);assert tail.count(needle)==1
s=before+'def _gallery_two_storeys('+tail.replace(needle,'    for x in _gallery_post_centres(p, post):\n')
s+='''

def _gallery_post_centres(p: FortStructureParams, post: float) -> list[float]:
    """Keep the old support rhythm, projecting explicit-front posts onto solid piers.

    Only the opt-in two-storey gallery calls this. Missing/empty explicit fronts
    retain the exact old grid. Where a front is declared, posts clear the union
    of BOTH storeys' rectangles plus their existing casing/sill horns. Project
    each old interior centre to the nearest permitted interval, left on ties;
    reserve one post width between centres. Count/sections and this placement
    rule remain reconstructed, not joinery measured from Whistler's drawing.
    """
    w = p.width_m
    n = max(2, int(round(w / 3.0)))
    legacy = [w * i / n for i in range(n + 1)]
    front = wall_openings(p, "front")
    if not front:
        return legacy
    # The existing window kit's horn extends farther than its cap or door trim.
    # Include half the actual post section so its whole face clears that kit.
    margin = post / 2 + openings.CASING_W_M + openings.SILL_HORN_M
    for o in front:
        if o["u0"] - margin <= 0 or o["u1"] + margin >= w:
            raise ValueError("explicit gallery front leaves no clear end support")
    spans = [(post, w - post)]

    def subtract(spans, lo, hi):
        out = []
        for a, b in spans:
            if hi <= a or lo >= b:
                out.append((a, b))
            else:
                if a < lo:
                    out.append((a, lo))
                if hi < b:
                    out.append((hi, b))
        return [(a, b) for a, b in out if b >= a]

    for o in front:
        spans = subtract(spans, o["u0"] - margin, o["u1"] + margin)
    result = [0.0, w]
    for wanted in legacy[1:-1]:
        if not spans:
            raise ValueError("explicit gallery front has no clear support pier")
        x = min((min(max(wanted, a), b) for a, b in spans),
                key=lambda v: (abs(v - wanted), v))
        result.append(x)
        spans = subtract(spans, x - post, x + post)
    return sorted(result)
'''
put(rel,s.encode())
# Screen-order fractions are qualitative readings, not a survey of this folded view.
# Existing diagnostic cameras reverse local u: local coordinate = width*(1-screen fraction).
controls={
'north_range':([.10,.28,.65,.83],['T','S','S','T']),
'officers_barracks':([.10,.30,.50,.70,.90],['S','T','S','T','S']),
'commanding_officers_barracks':([.12,.30,.53,.82],['S','S','T','S']),
'soldiers_barracks_sw':([.13,.31,.67,.84],['T','S','S','T']),
'soldiers_barracks_se':([.15,.31,.67,.84],['T','S','S','T'])}
notes=[]
for part,(centres,classes)in controls.items():
 sid='first_fort_dearborn_'+part;rel='chicago/4d/data/structures/'+sid+'.json';rec=json.loads((B/rel).read_text());ph=rec['phases'][0];width=max(q[0]for q in ph['footprint']['polygon']);storey=ph['form']['wall_height_m']['value']/ph['form']['stories']['value'];existing=ph['form']['face_openings'];back=[copy.deepcopy(o)for o in existing['value']if o['face']!='front'];new=[];door_bay=classes.index('T')
 for level in [0,1]:
  for screen_bay,(f,shape)in enumerate(zip(centres,classes)):
   c=width*(1-f);kind='door'if level==0 and screen_bay==door_bay else'window';sill=.02 if kind=='door'else(.10 if shape=='T'else .65)
   new.append({'face':'front','kind':kind,'u0':round(c-.36,6),'u1':round(c+.36,6),'z0':round(level*storey+sill,6),'z1':round(level*storey+2.05,6)})
 new.sort(key=lambda o:(o['z0']>=storey,o['u0']))
 ph['form']['face_openings']['value']=new+back
 ph['form']['face_openings']['note']=(f"Whistler’s actual 1808 upright folded front reads {'/'.join(classes)} in SCREEN order on both storeys (T extends lower, S is shorter). Source-relative horizontal fractions {centres} record a qualitative rhythm, not surveyed bay coordinates. Source count/relative silhouette is inferred; all metre set-out remains reconstructed: width 0.72 m, common 2.05 m head per existing storey, short sill 0.65 m and long-window sill 0.10 m. The single modelled lower door is the leftmost source-long bay in the upright crop, at reconstructed 0.02 m sill; this does not establish an actual door identity or entrance count. Upper long rectangles remain reconstructed glazed windows, not attested gallery doors. Existing rear rectangles retained. Long/short distinctions are weaker in the southern drawings; ignore lettering and ink noise. No plan, wall/storey height, position, bearing, roof, camera or date changes; 1808-to-1812 continuity remains inferred. Actual reviewed comparisons still differ.")
 oldgal=ph['form']['gallery_storeys']['note'];ph['form']['gallery_storeys']['note']=oldgal+" Follow-up support placement: where explicit front rectangles exist, retain the old support count/rhythm but project a colliding post centre to the nearest solid pier clearing both storeys' rectangles and the existing casing/sill-horn envelope. This algorithm/placement and all sections remain reconstructed. Rail density/height and remaining occlusion are unresolved; no upper entrance or accessible gallery interior is asserted."
 count=3 if part=='officers_barracks'else(2 if part=='commanding_officers_barracks'else 1)
 ph['form']['chimneys']={'value':count,'confidence':'inferred','sources':['whistler_1808_fort_dearborn_draught'],'note':f"The source’s identified 1808 folded front visibly shows {count} clear stack(s), checked in the actual drawing. Use that visible count for this first-fort occurrence with inferred continuity to 1812. No hidden or ambiguous stack is added. Exact position, height, section, brick treatment and survival unchanged to the scene date are not attested; the existing procedural set-out remains reconstructed."}
 put(rel,(json.dumps(rec,indent=2,ensure_ascii=False)+'\n').encode());notes.append({'structure':sid,'screen_fractions':centres,'screen_shapes_both_storeys':classes,'local_shapes_both_storeys':list(reversed(classes)),'reconstructed_ground_door_screen_bay_1based':door_bay+1,'front_rectangle_width_m':.72,'short_sill_m':.65,'long_window_sill_m':.10,'ground_door_sill_m':.02,'common_head_m':2.05,'visible_source_chimneys':count})
(H/'front-refinement.patch').write_text(patch);(H/'preimages.json').write_text(json.dumps({'base_public_head':HEAD,'overlay_requires_frozen_first_fort_patch':str(P/'first-fort-only.patch'),'files':files,'no_canonical_writes':True,'new_render_or_export':False},indent=2)+'\n');(H/'controls.json').write_text(json.dumps({'metric_status':'All chosen metre values and projection from qualitative image rhythm to existing width are reconstructed, not dimensions measured from a folded elevation.','controls':notes},indent=2)+'\n')
