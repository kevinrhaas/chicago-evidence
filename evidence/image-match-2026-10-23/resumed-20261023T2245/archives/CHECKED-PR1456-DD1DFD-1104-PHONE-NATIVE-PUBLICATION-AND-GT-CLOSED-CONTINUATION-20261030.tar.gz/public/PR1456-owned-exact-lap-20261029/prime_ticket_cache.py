from pathlib import Path
from urllib.request import Request,urlopen
import base64,datetime,hashlib,json,os,subprocess
R=Path('/workspace/chicago/chicago/4d/tickets');O=Path(__file__).parent;E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');REPO='kevinrhaas/chicago-tickets';rows=[]
def g(*a,input=None):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*a],input=input,env=E,stderr=subprocess.PIPE)
def api(p):
 with urlopen(Request('https://api.github.com/repos/'+REPO+'/'+p,headers={'User-Agent':'Chicago-bounded-current-ticket-object-prime','Accept':'application/vnd.github+json'}),timeout=45)as f:return json.load(f)
def exists(s):return subprocess.run(['/usr/local/bin/git','-C',str(R),'cat-file','-e',s],env=E,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
def put(k,b,s):
 assert hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==s
 if not exists(s):assert g('hash-object','-w','-t',k,'--stdin',input=b).decode().strip()==s;rows.append({'sha':s,'type':k,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
def rebuild(c):
 v=c['verification'];payload=v.get('payload');sig=v.get('signature')
 if payload and sig:
  h,msg=payload.encode().split(b'\n\n',1)
  for signature in [sig.encode(),sig.encode().rstrip(b'\n')]:
   raw=h+b'\ngpgsig '+b'\n '.join(signature.split(b'\n'))+b'\n\n'+msg
   if hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==c['sha']:return raw
 if not sig:
  def actor(k,tz):
   x=c[k];dt=datetime.datetime.fromisoformat(x['date'].replace('Z','+00:00'));return k+' '+x['name']+' <'+x['email']+'> '+str(int(dt.timestamp()))+' '+tz
  for tz in ['+0000','-0500','-0600']:
   h=['tree '+c['tree']['sha'],*['parent '+p['sha']for p in c['parents']],actor('author',tz),actor('committer',tz)]
   for end in ['', '\n']:
    raw=('\n'.join(h)+'\n\n'+c['message']+end).encode()
    if hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==c['sha']:return raw
 raise AssertionError('Canonical commit refused '+c['sha'])
tip=api('git/ref/heads/main')['object']['sha'];pending=[tip];commits=[]
while pending:
 s=pending.pop()
 if exists(s):continue
 assert len(commits)<20
 c=api('git/commits/'+s);raw=rebuild(c);commits.append((s,raw));pending.extend(p['sha']for p in c['parents'])
c=api('git/commits/'+tip);t=api('git/trees/'+c['tree']['sha']+'?recursive=1');assert not t['truncated'];groups={}
for r in t['tree']:
 par,_,name=r['path'].rpartition('/');groups.setdefault(par,[]).append((name,r))
roots={'':t['sha'],**{r['path']:r['sha']for r in t['tree']if r['type']=='tree'}}
for path,s in roots.items():
 if exists(s):continue
 entries=sorted(groups.get(path,[]),key=lambda x:x[0].encode()+(b'/'if x[1]['type']=='tree'else b''));b=b''.join((('40000'if r['type']=='tree'else r['mode']).encode()+b' '+n.encode()+b'\0'+bytes.fromhex(r['sha']))for n,r in entries);put('tree',b,s)
missing=[r for r in t['tree']if r['type']=='blob'and not exists(r['sha'])];assert sum(r['size']for r in missing)<8000000
for r in missing:
 j=api('git/blobs/'+r['sha']);b=base64.b64decode(j['content']);assert len(b)==r['size'];put('blob',b,r['sha'])
for s,b in commits:put('commit',b,s)
j={'status':'ACTUAL_BOUNDED_CURRENT_TICKET_TIP_OBJECTS_MATERIALIZED_NO_FETCH','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tip':tip,'missing_blobs':len(missing),'written':rows,'HEAD_index_refs_working_files_unchanged':True,'fetches':0};(O/'TICKET-CACHE-PRIME.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps({'tip':tip,'blobs':len(missing),'objects':len(rows),'bytes':sum(r['bytes']for r in rows)}))
