from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, sys, datetime
R=Path('/workspace/chicago');A=R/'chicago/4d';P=Path('/workspace/T2376-b20f-authored-rebind-20261029');OUT=Path(__file__).resolve().parent
BASE='b20f4200495c38f57f268d24870313e53ed366d9';CURRENT='5f12e94ee80e9881486bbf43eb869e0cbf6a5281'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,body=None):
 return subprocess.check_output(['git','-C',str(R),*args],input=body,env=env)
def state():
 return {'head':git('rev-parse','HEAD').decode().strip(),'index_sha256':sha((R/'.git/index').read_bytes()),'config_sha256':sha((R/'.git/config').read_bytes()),'refs_sha256':sha(git('show-ref'))}
def existing(oid,kind=None):
 line=git('cat-file','--batch-check=%(objectname) %(objecttype)',body=(oid+'\n').encode()).decode().strip();assert 'missing'not in line,line
 if kind:assert line==oid+' '+kind,line
 return line
before=state();existing(BASE,'commit');existing(CURRENT,'tree')
def entries(tree):
 d={}
 for row in git('ls-tree','-rz',tree).split(b'\0'):
  if row:
   meta,p=row.split(b'\t',1);mode,kind,oid=meta.decode().split();d[p.decode()]={'mode':mode,'kind':kind,'oid':oid}
 return d
base=entries(BASE);cur=entries(CURRENT)
def blob(row):
 assert row['kind']=='blob';existing(row['oid'],'blob');return git('cat-file','blob',row['oid'])
inv=json.loads(Path('/workspace/T2376-final67-before-currentdev-composition-20261029/MANIFEST.json').read_text());paths=[];counts={}
aggregate={'chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json','chicago/4d/assets/manifest.versions.json','chicago/prairie_1904_v1/research/images/STORE.json','chicago/4d/data/structure_grades.json'}
def action(p):
 if p=='chicago/4d/docs/LIBERTIES.md':return 'chronological_GT_suffix_splice_into_current'
 if p in aggregate:return 'entrywise_union_preserving_every_current_foreign_row'
 if p=='chicago/prairie_1904_v1/data/images.json':return 'official_library_builder_from_unioned_streams_STORE'
 if p.startswith('chicago/4d/data/sidecars/') or p in {'chicago/4d/data/enclosures/town_entrance_aprons.json','chicago/4d/data/frontage/green_tree_frontage.json','chicago/4d/data/liberties.json','chicago/4d/data/signage/town_business_signboards.json','chicago/4d/data/yard/town_trade_goods.json','chicago/4d/data/yard/town_woodpiles.json','chicago/4d/docs/measurements/source_use_coverage.md'}:return 'regenerate_with_official_current_owner_do_not_restore_old_aggregate'
 return 'exact_final67_postimage_after_current_preimage_or_absence_guard'
for row in inv['rows']:
 path=row['path'];b=base.get(path);c=cur.get(path);kind='new_absent_both'if b is None and c is None else'unchanged_existing'if b==c else'upstream_overlap';counts[kind]=counts.get(kind,0)+1
 old=P/'postimages'/path;match=old.exists()and sha(old.read_bytes())==row['sha256'];paths.append({'path':path,'classification':kind,'action':action(path),'current_preimage_oid':c['oid']if c else None,'b20f_preimage_oid':b['oid']if b else None,'final_GT_sha256':row['sha256'],'final_GT_bytes':row['bytes'],'old48_rebind_postimage_is_final67_exact':match,'current_preimage_sha256':sha(blob(c))if c else None})
# Native recipe query against the CURRENT repair source, substituting only the
# declared final GT parameter reader and producer bytes without writing files.
sys.dont_write_bytecode=True;sys.path.insert(0,str(A/'generators'));import mesh_inputs
spec=importlib.util.spec_from_file_location('gt_replay_candidate_params',P/'postimages/chicago/4d/generators/archetypes/frame_tavern_params.py');params=importlib.util.module_from_spec(spec);sys.modules[spec.name]=params;spec.loader.exec_module(params)
oldresolve=mesh_inputs.resolve_params;oldsha=mesh_inputs._sha_file
mesh_inputs.resolve_params=lambda arch,phase,record:params.from_phase(phase,record)if arch=='frame_tavern'else oldresolve(arch,phase,record)
mesh_inputs._sha_file=lambda p:sha((P/'postimages/chicago/4d/generators/archetypes/frame_tavern.py').read_bytes())if p==A/'generators/archetypes/frame_tavern.py'else oldsha(p)
adopt=json.loads((P/'ADOPTION.json').read_text());regs={n:json.loads((P/'postimages/chicago/4d/assets'/n).read_text())for n in ['manifest.json','manifest.versions.json']};native=[]
for reg in adopt['registries']:
 name=Path(reg['path']).name
 if name not in regs:continue
 for key in reg['changed_keys']:
  row=regs[name]['assets'][key];sid=row['structure_id'];rp='data/structures/'+sid+'.json'if'version_label'not in row else'data/structures/versions/'+sid+'/'+row['version_label']+'.json';f=P/'postimages/chicago/4d'/rp
  if not f.exists():f=A/rp
  r=json.loads(f.read_text());phase=next(p for p in r['phases']if p['id']==row['phase_id']);doc=mesh_inputs.structure_inputs_doc(r,phase,row['archetype']);actual=sha(json.dumps(doc,sort_keys=True).encode());assert actual==row['inputs_sha256'],(key,actual,row['inputs_sha256'])
  # Every current primary record/dependency read must belong to the staged tree.
  used=[A/'generators'/p for p in doc['code']if p!='archetypes/frame_tavern.py']+[A/'generators/mesh_inputs.py',A/'generators/code_inputs.py',A/'generators/blender.pin']
  if not f.is_relative_to(P):used.append(f)
  for u in used:
   rel=u.relative_to(R).as_posix();body=u.read_bytes();assert hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==cur[rel]['oid'],rel
  native.append({'asset':key,'inputs_sha256':actual,'exact':True,'record_path':'chicago/4d/'+rp,'record_sha256':sha(f.read_bytes())})
assert len(native)==26
libpath='chicago/4d/docs/LIBERTIES.md';b=blob(base[libpath]);c=blob(cur[libpath]);g=(P/'postimages'/libpath).read_bytes();assert g.startswith(b);suffix=g[len(b):]
assert sha(g)==next(r['sha256']for r in inv['rows']if r['path']==libpath)
anchor=b'### L-pullman-18th-street-trees-1934';assert c.count(anchor)==1;at=c.index(anchor);prefix=c[:at];tail=c[at:];combined=prefix+suffix+tail
pat=re.compile(r'^###\s+(L\d+[a-z]?|L-[a-z0-9]+(?:-[a-z0-9]+)*)\s*[—-]\s*(.+?)\s*$',re.M)
def blocks(raw):
 text=raw.decode();ms=list(pat.finditer(text));return {m[1]:text[m.start():ms[i+1].start()if i+1<len(ms)else len(text)].strip()for i,m in enumerate(ms)}
be,ce,ge,xe=map(blocks,[b,c,g,combined]);assert len(xe)==len(ce)+2==873;assert all(xe[k]==v for k,v in ce.items());assert all(xe[k]==ge[k]for k in ge.keys()-be.keys())
libproof={'source_suffix_bytes':len(suffix),'source_suffix_sha256':sha(suffix),'new_GT_ids':sorted(ge.keys()-be.keys()),'incoming_added_ids':sorted(ce.keys()-be.keys()),'incoming_modified_existing_ids':[k for k in be if k in ce and be[k]!=ce[k]],'current_entire_b20f_prefix':c.startswith(b),'insertion_before_existing_new_tail_heading':anchor.decode(),'current_all_entry_blocks_preserved_exact':True,'combined_entry_count':len(xe),'combined_expected_sha256':sha(combined),'combined_bytes':len(combined),'limits':'RAM composition only. No primary write and no actual compile_liberties run or final full gate claimed.'}
after=state();assert before==after
result={'status':'EXACT_STAGED_FOUR_TREE_GT67_REPLAY_CLASSIFIED_NATIVE26_PARITY_PASS_NOT_APPLIED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':BASE,'target_staged_tree':CURRENT,'path_counts':counts,'paths':paths,'native26':native,'liberty_splice':libproof,'primary_state_before_after_equal':True,'primary_state':before,'no_Git_network_or_history_walk':True,'limits':'Target is an uncommitted staged source tree. No new GT commit/full gate/phone/application/broad smoke qualification. Final185-member archive/checkpoint710 is the final postimage authority;22 old48 rebind payloads differ from final67 and must not be blindly copied.'}
(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'result':str(OUT/'RESULT.json'),'counts':counts,'native26':len(native),'liberty':libproof},indent=2))
