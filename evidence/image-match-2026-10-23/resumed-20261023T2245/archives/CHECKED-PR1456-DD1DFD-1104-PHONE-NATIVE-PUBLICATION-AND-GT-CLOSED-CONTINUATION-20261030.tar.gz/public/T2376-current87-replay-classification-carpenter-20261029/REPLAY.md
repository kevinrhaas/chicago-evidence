# GT67 replay onto the checked four-building repair

Target staged tree: `5f12e94ee80e9881486bbf43eb869e0cbf6a5281`, currently uncommitted. This is a read-only report. No primary source/index/ref/config changes were made; no render/bake/check/PR was run. GIT_NO_LAZY_FETCH=1 and GIT_OPTIONAL_LOCKS=0 were used, object types/existence proved before reading bodies, no network Git or history walk.

## Exact work left after four commit

`RESULT.json.paths` has every final67 path with target preimage OID+SHA256 (or required absence), final GT SHA/bytes, classification, and replay action.44existing paths have identical baseline/current tree entries,17new paths are absent in both,6paths overlap new upstream work. The only overlaps are the main MASTER/WEB registries, LibMD/JSON, compiled source index and source-use coverage; none is an authored GT producer/runtime/model conflict.

All45 paths whose action is `exact_final67_postimage_after_current_preimage_or_absence_guard` have a verified `exact_local_final67_donor`:39in the original rebind `postimages`,6in its `root-review-postimages`. No archive download or new large source snapshot is needed. The six later rootreview versions are Andreas match, Kurz match+sideby, STATUS, ROADMAP, optional README. Never blindly restore the original48packet:22of its files differ from the final67 state, mostly generated aggregates.

After the four-building checked commit is published and the primary writer holds a fresh GT branch/source lease, verify the current branch/tree/index state and all perpath target preimages before the first write. Restore only the45 verified exact final donors, with their declared final modes. Do not hardlink active source files to evidence. Current full commit must have this exact tree or the overlapping check must be redone; a new unrelated dev does not inherit this proof automatically.

## The22 aggregate paths

Five paths use entrywise union: MASTER registry `assets`, WEB registry `masters`, versions registry `assets`, STORE `files`, and structure_grades `pictured/not_pictured` rulings. Compute the GT delta from b20f to the finalGT donor, apply only changed keys/rulings to the current target, refuse any third conflicting value, preserve every foreign current entry exactly. MASTER recipe delta is23canonical rows, versions3rows, WEB only the canonicalGT model; STORE adds six named credited GT image files and recomputes its bytes count. Preserve existing filename keys, all unrelated rows, and top-level metadata. The old rebind `finish_packet.py` shows the registry union but cannot itself be rerun: it is hard-bound to clean b20f and would repeat old48 state.

LibMD is a chronological splice. Final GT was b20f plus exactly5261B, SHA `d6d115f147b918bd7da6bcb6dfaa8e7a630fe1ab02d1c026bc00dcb2a45da28c`, two entries (enclosed-left-reading and sign-post). Current doc has871entries, including new Pullman3164,Hibbard3241,Pullman18thtrees1934 and a real edited old Hibbard3240. It does NOT start with entireb20f. Keep current document and insert the exact GT suffix before its single `### L-pullman-18th-street-trees-1934` tail heading. The actual RAM composition preserved every current entry block exactly and added exactly2:873entries,3424775B, SHA `102c00c69b9dca910f44d545e8533843dc6aedcf9b58d7e9a279d9fc44ac4751`. Do not replace wholeLib or erase changed Hibbard. RecompileLibJSON officially.

Fifteen files are generated: do not restore older b20f aggregates over current foreign data. Run official owners/full native sequence and mandatory settled tail. These include doorway aprons/frontage/signboards/yard goods/woodpiles, LibJSON and scene/source/versions sidecars plus source-use report. The last aggregate is Prairie `data/images.json`: use its official library builder from the unioned stream+STORE; preserve every foreign image record and lookup. Sources/cache publication remains normal native work.

## Native outputs can be reused

The native current `mesh_inputs.structure_inputs_doc` was actually queried for all23canonical+3version frame_tavern rows, substituting only declared finalGT producer/parameter reader/GTrecords in RAM. Every full recipe SHA matched its accepted native output, including current Blenderpin and all6 geometry-code modules. All primary dependency/record reads were proved identical to exact staged-tree blob OIDs. This is stronger than unchanged-file-name reasoning: ALL26 full resolved recipes are exact. Therefore no family/frame bake is needed after replaying these exact authored values. Preserve all model bytes and transfer only owned registry-row changes; run normal freshness validation.

Existing targeted GT Full canonical+optional desktop/mobile app proofs and image comparisons are dated accepted b20f evidence. Their body inputs retain exact recipes, but this report does not substitute them for final current-owner/gate/phone or broad smoke qualifications. Do the relevant current app/input binding proof and standard final foreground source check before commit. Then normal dev draft PR and the already-prepared30native smoke dispatch can proceed.

## Exact owner route, avoiding another204-step population pass

`name_pool_keys.json` is an AUTHORED whitelist, not a generated artifact. GT adds only `phases[].form.enclosed_left_annex.note` to `read.structures`. It is now one of45 guarded exact donor restores (39original+6rootreview). Do not call the resident-replacement writer to produce it.

The eight actual owner commands are recorded under `RESULT.json.owner_plan.owners`, with current manifest indices:144Libcompiler,148compile_scene --all (main+version sidecars),149entrances,152source_use (sourcecards/index/coverage),154businesssignboards,160frontage,179yardgoods,182woodpiles. Every one is at/below144. After source/registry/grade/STORE unions, run the official library builder from the correct directory, publish the mirror (closing-report reader needs it), then the SINGLE native controller command:

```bash
node tools/rederive.mjs --tail tools/compile_liberties.py
```

This is61steps per lap, including EVERY reader below, repeated by the native controller until a final lap moves nothing (max3). It is NOT61 manually cherry-picked commands and NOT a bare scene rebuild. No new resident/seating input moved: the original GT204+second7 proof and current four native qualification stand for that already-tested part, while this61-step current tail owns the actual current aggregate union. Do not restore old compiledLib/sidecars/sourceindex over current foreign entries. Keep raw serializer changes if genuine; any equivalent-only restoration needs the same exact semantic audit discipline as earlier44. Publish again after actualsettlement; current `--check` and full foreground sourcegate/phone still required.
