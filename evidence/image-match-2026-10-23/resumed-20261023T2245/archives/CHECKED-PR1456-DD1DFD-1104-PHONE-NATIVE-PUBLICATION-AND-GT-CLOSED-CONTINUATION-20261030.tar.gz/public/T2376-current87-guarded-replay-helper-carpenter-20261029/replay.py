"""Default PLAN. Apply only on the reviewed, checked clean native four-repair commit.

This helper never stages, commits, updates refs or runs a generator. All bodies
and unions are prepared and checked in RAM before the first primary replacement.
"""
from pathlib import Path
import argparse
import copy
import datetime
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/chicago')
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
SHA = lambda b: hashlib.sha256(b).hexdigest()


def git(*args, body=None):
    return subprocess.check_output(['git', '-C', str(REPO), *args], input=body, env=ENV)


def existing(oid, kind=None):
    got = git('cat-file', '--batch-check=%(objectname) %(objecttype)',
              body=(oid + '\n').encode()).decode().strip()
    assert 'missing' not in got, got
    if kind:
        assert got == oid + ' ' + kind, got


def tree_entries(tree):
    result = {}
    for row in git('ls-tree', '-rz', tree).split(b'\0'):
        if row:
            meta, path = row.split(b'\t', 1)
            mode, kind, oid = meta.decode().split()
            result[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
    return result


def index_entries():
    result = {}
    for row in git('ls-files', '--stage', '-z').split(b'\0'):
        if row:
            meta, path = row.split(b'\t', 1)
            mode, oid, stage = meta.decode().split()
            assert stage == '0', 'Unmerged index'
            result[path.decode()] = {'mode': mode,
                                    'kind': 'commit' if mode == '160000' else 'blob',
                                    'oid': oid}
    return result


def blob(entry):
    assert entry['kind'] == 'blob'
    existing(entry['oid'], 'blob')
    return git('cat-file', 'blob', entry['oid'])


def state():
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'branch': git('branch', '--show-current').decode().strip(),
            'index_sha256': SHA((REPO / '.git/index').read_bytes()),
            'config_sha256': SHA((REPO / '.git/config').read_bytes()),
            'refs_sha256': SHA(git('show-ref'))}


def no_symlink_path(path):
    assert path.is_relative_to(REPO)
    for part in [path, *path.parents]:
        if part == REPO.parent:
            break
        assert not part.is_symlink(), f'Symlink is not an owned source path: {part}'


def union_mapping(base, own, current, member):
    """Only changed owned entries move; no third value or foreign loss is allowed."""
    assert isinstance(base[member], dict) and isinstance(own[member], dict)
    assert isinstance(current[member], dict)
    result = copy.deepcopy(current)
    changed = [k for k in sorted(set(base[member]) | set(own[member]))
               if base[member].get(k) != own[member].get(k)]
    for key in changed:
        b, o, c = base[member].get(key), own[member].get(key), current[member].get(key)
        assert c == b or c == o, f'Third registry value: {member}/{key}'
        assert o is not None, f'Unexpected GT registry deletion: {key}'
        result[member][key] = copy.deepcopy(o)
    foreign_before = [(k, v) for k, v in current[member].items() if k not in changed]
    foreign_after = [(k, v) for k, v in result[member].items() if k not in changed]
    assert foreign_before == foreign_after, 'Foreign values/order changed'
    assert set(current[member]).issubset(result[member]), 'Current key removed'
    for key in current:
        if key != member:
            assert result[key] == current[key]
    return result, changed, len(foreign_before)


def rule_key(rule):
    assert isinstance(rule, dict)
    return (rule.get('scene'), rule.get('structure'), rule.get('picture'))


def union_rules(base, own, current):
    result = copy.deepcopy(current)
    proof = []
    for section in ['pictured', 'not_pictured']:
        b = {rule_key(v): v for v in base[section]}
        o = {rule_key(v): v for v in own[section]}
        c = {rule_key(v): v for v in current[section]}
        assert len(b) == len(base[section]) and len(o) == len(own[section])
        assert len(c) == len(current[section])
        changed = {k for k in set(b) | set(o) if b.get(k) != o.get(k)}
        assert all(k[1:] == ('green_tree_tavern', 'chm_green_tree_1859') for k in changed)
        for key in changed:
            assert c.get(key) == b.get(key) or c.get(key) == o.get(key), (section, key)
        out = []
        for old in current[section]:
            key = rule_key(old)
            if key not in changed:
                out.append(copy.deepcopy(old))
            elif key in o:
                out.append(copy.deepcopy(o[key]))
        included = {rule_key(v) for v in out}
        for rule in own[section]:
            key = rule_key(rule)
            if key in changed and key not in included:
                out.append(copy.deepcopy(rule))
                included.add(key)
        assert [v for v in current[section] if rule_key(v) not in changed] == [
            v for v in out if rule_key(v) not in changed], 'Foreign rulings/order changed'
        result[section] = out
        proof.append({'section': section, 'changed_keys': [list(k) for k in sorted(changed)],
                      'foreign_rows_exact': sum(rule_key(v) not in changed for v in out)})
    for key in current:
        if key not in ['pictured', 'not_pictured']:
            assert result[key] == current[key]
    return result, proof


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--expect-head', required=True,
                    help='Explicit actual native commit SHA; apply needs its checked clean exact tree')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--report', help='Optional external report under this helper directory')
    args = ap.parse_args()
    bindings_bytes = (HERE / 'BINDINGS.json').read_bytes()
    bindings = json.loads(bindings_bytes)
    expected = bindings['required_checked_HEAD_tree']
    assert len(args.expect_head) == 40 and all(c in '0123456789abcdef' for c in args.expect_head)
    before = state()
    assert before['head'] == args.expect_head, 'HEAD changed or wrong --expect-head'
    existing(args.expect_head, 'commit')
    existing(expected, 'tree')
    existing(bindings['baseline'], 'commit')
    current = tree_entries(expected)
    base = tree_entries(bindings['baseline'])
    assert index_entries() == current, 'Index is not the exact reviewed four-repair tree'
    assert not git('diff', '--name-only', '--no-ext-diff', '--no-textconv'), 'Unstaged changes'
    status = git('status', '--porcelain=v1', '--untracked-files=all').decode()
    head_tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    if args.apply:
        assert head_tree == expected, 'Apply requires the checked native HEAD tree, not staged WIP'
        assert not status, 'Apply requires a wholly clean primary checkout'
        assert os.environ.get('GT_REPLAY_READY') == 'root-reviewed-checked-current87-final67', (
            'Apply requires explicit root-reviewed source lease')

    payloads = []
    proof = []
    for row in bindings['rows']:
        rel = row['path']
        target = REPO / rel
        donor = Path(row['donor'])
        no_symlink_path(target)
        assert donor.is_file() and not donor.is_symlink(), donor
        assert oct(stat.S_IMODE(donor.stat().st_mode)) == row['donor_mode'], donor
        own_bytes = donor.read_bytes()
        assert SHA(own_bytes) == row['final_GT_sha256'] and len(own_bytes) == row['final_GT_bytes'], donor
        if row['current_preimage_oid'] is None:
            assert rel not in current and not target.exists(), f'Expected absence: {rel}'
            before_bytes = None
        else:
            assert current[rel]['oid'] == row['current_preimage_oid']
            assert target.is_file(), rel
            before_bytes = target.read_bytes()
            assert SHA(before_bytes) == row['current_preimage_sha256'], f'Current preimage changed: {rel}'
        mode = int(row['final_GT_mode'], 8)
        assert mode in [0o600, 0o644, 0o755], (rel, mode)
        how = row['action']
        notes = None
        if how.startswith('exact_'):
            out = own_bytes
        elif how.startswith('entrywise_'):
            assert rel in base and before_bytes is not None
            b = json.loads(blob(base[rel]))
            o = json.loads(own_bytes)
            c = json.loads(before_bytes)
            if rel.endswith('structure_grades.json'):
                out_doc, notes = union_rules(b, o, c)
            else:
                member = 'masters' if rel.endswith('manifest.web.json') else 'files' if rel.endswith('STORE.json') else 'assets'
                for key in set(b) | set(o):
                    if key not in [member, 'bytes']:
                        assert b.get(key) == o.get(key), f'Unexpected owned metadata delta: {rel}/{key}'
                out_doc, changed, foreign = union_mapping(b, o, c, member)
                notes = {'member': member, 'changed_keys': changed, 'foreign_rows_exact': foreign}
                if member == 'files':
                    out_doc['bytes'] = sum(v['bytes'] for v in out_doc['files'].values())
                else:
                    assert out_doc.keys() == c.keys(), rel
            indent = 1 if rel.endswith('STORE.json') else 2
            out = (json.dumps(out_doc, indent=indent) + '\n').encode()
        elif rel == 'chicago/4d/docs/LIBERTIES.md':
            baseline = blob(base[rel])
            assert own_bytes.startswith(baseline), 'Old GT Liberty is not its declared baseline plus suffix'
            suffix = own_bytes[len(baseline):]
            lp = bindings['liberty']
            assert len(suffix) == lp['source_suffix_bytes'] and SHA(suffix) == lp['source_suffix_sha256']
            anchor = lp['insertion_before_existing_new_tail_heading'].encode()
            assert before_bytes.count(anchor) == 1
            assert all(('### ' + lid + ' ').encode() not in before_bytes for lid in lp['new_GT_ids'])
            at = before_bytes.index(anchor)
            out = before_bytes[:at] + suffix + before_bytes[at:]
            assert SHA(out) == lp['combined_expected_sha256'] and len(out) == lp['combined_bytes']
            # The qualified873-entry composition was independently compared entry by entry.
            assert out[:at] == before_bytes[:at] and out[at + len(suffix):] == before_bytes[at:]
            notes = {'current_bytes_preserved_exact_except_insertion': True,
                     'new_GT_entries': lp['new_GT_ids'], 'expected_entries': 873}
        else:
            raise AssertionError(('Unowned replay action', rel, how))
        payloads.append((target, out, mode))
        proof.append({'path': rel, 'action': how, 'before_sha256': SHA(before_bytes) if before_bytes is not None else None,
                      'after_sha256': SHA(out), 'after_bytes': len(out), 'after_mode': oct(mode), 'union': notes})

    assert len(payloads) == 51 and len({str(p) for p, _, _ in payloads}) == 51
    assert sum(x['action'].startswith('exact_') for x in proof) == 45
    assert sum(x['action'].startswith('entrywise_') for x in proof) == 5
    # Conservative peak: reserve every new payload's allocated size, even where
    # replacement will retire an old inode, plus8MiB for directories/receipts.
    allocation = sum(((len(b) + 4095) // 4096) * 4096 for _, b, _ in payloads)
    required = bindings['workspace_floor'] + allocation + 8 * 1024**2
    workspace_free = shutil.disk_usage('/workspace').free
    tmp_free = shutil.disk_usage('/tmp').free
    assert workspace_free >= required, (workspace_free, required, 'workspace caller floor/reserve')
    assert tmp_free >= bindings['tmp_floor'], (tmp_free, bindings['tmp_floor'], 'TMP caller floor')
    prepared_state = state()
    assert prepared_state == before, ('Primary Git state changed while preparing replay',
                                     {k: [before[k], prepared_state[k]] for k in before
                                      if before[k] != prepared_state[k]})
    result = {'status': 'PLAN_ALL51_GUARDS_AND_RAM_UNIONS_PASS',
              'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'apply_requested': args.apply,
              'head': before['head'], 'HEAD_tree': head_tree, 'required_tree': expected,
              'native_committed_clean_ready': head_tree == expected and not status,
              'bindings_sha256': SHA(bindings_bytes), 'primary_state': before,
              'workspace_free': workspace_free, 'workspace_required_with_conservative_reserve': required,
              'tmp_free': tmp_free, 'rows': proof,
              'not_run': ['native generators/owners', 'current GT app qualification', 'phone', 'full check', 'commit', 'PR', 'merge']}
    if args.report:
        report = Path(args.report).resolve()
        assert report.is_relative_to(HERE), 'Report must remain external to primary under helper directory'
        assert not report.exists(), 'Do not overwrite earlier receipts'
        report.write_text(json.dumps(result, indent=2) + '\n')
    if not args.apply:
        print(json.dumps({k: v for k, v in result.items() if k != 'rows'}, indent=2))
        return

    # Recheck every precondition immediately before the first primary write.
    assert state() == before and not git('status', '--porcelain=v1', '--untracked-files=all')
    for row in bindings['rows']:
        target = REPO / row['path']
        donor = Path(row['donor'])
        assert SHA(donor.read_bytes()) == row['final_GT_sha256']
        assert oct(stat.S_IMODE(donor.stat().st_mode)) == row['donor_mode']
        assert (SHA(target.read_bytes()) if target.exists() else None) == row['current_preimage_sha256']
    assert shutil.disk_usage('/workspace').free >= required
    assert shutil.disk_usage('/tmp').free >= bindings['tmp_floor']
    journal = HERE / ('APPLIED-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S') + '.jsonl')
    assert not journal.exists()
    with journal.open('x') as receipt:
        receipt.write(json.dumps({'status': 'APPLY_STARTED', 'head': before['head'], 'bindings_sha256': SHA(bindings_bytes)}) + '\n')
        receipt.flush()
        os.fsync(receipt.fileno())
        for target, out, mode in payloads:
            target.parent.mkdir(parents=True, exist_ok=True)
            fd, temporary = tempfile.mkstemp(prefix='.gt51-replay-', dir=str(target.parent))
            try:
                with os.fdopen(fd, 'wb') as dest:
                    dest.write(out)
                    dest.flush()
                    os.fsync(dest.fileno())
                os.chmod(temporary, mode)
                os.replace(temporary, target)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
            assert SHA(target.read_bytes()) == SHA(out)
            assert stat.S_IMODE(target.stat().st_mode) == mode
            receipt.write(json.dumps({'path': target.relative_to(REPO).as_posix(), 'sha256': SHA(out), 'mode': oct(mode)}) + '\n')
            receipt.flush()
            os.fsync(receipt.fileno())
        assert state() == before, 'Unexpected Git state mutation'
        assert shutil.disk_usage('/workspace').free >= bindings['workspace_floor']
        assert shutil.disk_usage('/tmp').free >= bindings['tmp_floor']
        receipt.write(json.dumps({'status': 'ALL51_SOURCE_PATHS_APPLIED_GIT_STATE_EXACT', 'not_run': result['not_run']}) + '\n')
        receipt.flush()
        os.fsync(receipt.fileno())
    print(json.dumps({'status': 'ALL51_SOURCE_PATHS_APPLIED_GIT_STATE_EXACT', 'journal': str(journal),
                      'native_owners_and_final_gates_remain': True}))


if __name__ == '__main__':
    main()
