# Exact GT51 source replay helper — pending one clean-HEAD PLAN

Root read-review only. No apply has run. The two original readonly PLAN attempts reached all51 current preimage/donor/RAM union checks, then safely refused while the separate four-building source gate was active. First: final primary Git-state guard differed, but that first version did not retain the field values, so which field changed is unknown. Second: actual TMP1799905280B was below unchanged1800000000B caller floor. Both raw stderr transcripts are retained. No source/index/ref/config writes occurred, no floors were lowered, and no active temporary file was cleaned. Do not retry until the primary writer announces its actual checked native commit and postgate closure.

The helper's default is PLAN. Root/writer should supply the full actual checked native four-repair commit SHA:

```bash
python3 -B /workspace/T2376-current87-guarded-replay-helper-carpenter-20261029/replay.py --expect-head "$four_checked_native_commit" --report /workspace/T2376-current87-guarded-replay-helper-carpenter-20261029/PLAN-clean-native-HEAD.json
```

PLAN may inspect a source index matching exact5f12 while HEAD is older, but apply cannot: it requires a wholly clean primary checkout whose actual HEAD tree is5f12e94ee80e9881486bbf43eb869e0cbf6a5281, explicit exactHEAD, exact completeindex, all51 target preimage hashes/absence, all donor modes+SHAs, all source unions and exact873-entry LibSHA, unchanged Git state and conservative disk resources. It also requires the root-granted source lease marker `GT_REPLAY_READY=root-reviewed-checked-current87-final67`. These controls do not replace root's verification that the native source gate passed before that commit.

Only after root approves the concrete clean-HEAD PLAN, the source owner may repeat with `--apply`. It writes45 exact authored/model/camera payloads+5entrywise unions+1chronological Lib splice. It never restores15old generated aggregates or the library cache: those remain for the documented native61-step settled tail and official library builder. It does not stage, commit, update refs or run owners. Atomic perfile replacement preserves the FINAL67 modes, which intentionally differ from several evidence-donor modes (notably executable tools). Every donor's existing mode is independently bound and checked. Each applied path gets a small fsynced external journal; active files are never hardlinked to immutable evidence.

On an interruption during apply, the journal names exactly which owned paths landed; the already committed clean preimages remain available through that checked HEAD and the final GT51 payloads remain independently bound. Do not blindly rerun after partial apply, because preimage guards correctly refuse it; root/source owner should review the journal and choose explicit recovery.
