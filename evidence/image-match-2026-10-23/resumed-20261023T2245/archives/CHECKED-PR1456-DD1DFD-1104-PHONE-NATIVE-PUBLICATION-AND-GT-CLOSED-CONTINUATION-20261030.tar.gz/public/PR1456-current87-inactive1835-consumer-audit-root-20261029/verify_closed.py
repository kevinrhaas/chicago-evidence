"""Read-only revalidation of the reviewed, narrowly dated 1835 consumer reuse."""
from pathlib import Path
import hashlib
import json

home = Path(__file__).resolve().parent
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
result = json.loads((home / "RESULT.json").read_text())
bindings = home / "305-CONSUMER-BINDINGS.json"
assert digest(bindings) == result["bindings_sha256"]
rows = json.loads(bindings.read_text())
assert len(rows) == 305 and sum(row["exact"] for row in rows) == 304
for row in rows:
    assert digest(row["path"]) == row["current_sha256"], row["path"]
module = result["changed_module"]
for path in [module["source_path"], module["published_path"]]:
    assert digest(path) == module["current_sha256"], path
route = result["actual1835_inactive_route"]
for path in [route["native_scene"], route["published_scene"]]:
    assert digest(path) == route["scene_sha256"], path
    assert "street_trees" not in json.loads(Path(path).read_text())["layers"]
for relative in ["chicago/4d/renderers/web/js/main.js", "site/4d/walk/js/main.js"]:
    assert digest(Path("/workspace/chicago") / relative) == route["unchanged_main_layer_dispatch_sha256"]
print("PASS: all 304 exact consumers plus the sole reviewed inactive-1835 module and its dispatch bindings remain exact")
