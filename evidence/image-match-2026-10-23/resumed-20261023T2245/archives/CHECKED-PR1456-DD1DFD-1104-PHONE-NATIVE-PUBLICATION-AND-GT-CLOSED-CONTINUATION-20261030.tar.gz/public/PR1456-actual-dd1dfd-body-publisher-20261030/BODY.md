Give the Miller House its pictured low log wing beside the tall range, add Hogan’s horizontal gable courses and chimney cap, raise St Mary’s front sash, and add the credited Castelnau harbour view to the lighthouse card. Sources retain disputed dates, unresolved details and picture conflicts; comparison cameras remain diagnostic.

Validation at native head `b20f4200`, merging `EC16` into the four-building branch:

- All 1,104 foreground checks passed on exact tree `d630e015`. Native regeneration and publication passed; all 44 derived outputs were audited. The merge preserves 533 relevant source bindings, three reviewed upstream K helpers, all 706 log/frame models and all 353 fresh recipes. Four image gates and committed PR checks passed.
- The current 1904 phone measurement passed at **395.68 MiB / 400 MiB**.
- Desktop/mobile app evidence is bound through 305 unchanged published inputs. Miller’s updated Full-detail runs passed both viewports with zero page errors, credited image viewing and clear approaches to both doors. This is dated evidence for unchanged consumers; no fresh whole-app matrix or frame-rate measurement is claimed.
- Both sets of documentation appendices are preserved in chronological order. A native next-append merge test passed. All 60 changed paths in the native merge were read back from GitHub byte-for-byte.

T-2381, T-2373, T-2384 and T-2377 remain in official review for this PR. Newer `dev` includes separate Pullman glasshouse work; the native PR lap must integrate it and required CI must pass on the final head before merging.

Recovery and exact receipts: [checkpoint 695](https://github.com/kevinrhaas/chicago-evidence/blob/7b56439590f6850acb5a6ac64a284c8a33ec2f3b/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md).

### Current repaired head and validation (2026-10-30 UTC)

Native head `dd1dfd88808ee36187825706cb71a5ad70bdd262` preserves parents `009d542` and current `dev` `87c03bc`, with checked tree `5f12e94ee80e9881486bbf43eb869e0cbf6a5281`. It is published to this existing PR by a normal fast-forward, with all 31 changed paths independently read back from the immutable GitHub commit. The four original tickets remain in review until the actual merge and official settlement.

- The complete foreground source gate passed **1,104 steps**, with all seven source/index/tree/reaper guards true.
- A fresh published 1904 mobile run passed at **395.685513 MiB / 400 MiB**. The dated four-building consumer bindings were revalidated, including the explicit inactive-1835 exception; all 29 relevant Liberty rows and the full **871-entry** published/native Liberty register agree exactly.
- The actual PR-event questions and image gates passed. GitHub's newly triggered required gate must still pass on this exact remote head before the normal merge to `dev`; local validation is not substituted for that check.

### Generated-data repair required by this PR

CI on the earlier bot-updated branch exposed a PR-lap bug: the controller successfully rebuilt conflicted derived files, then its later generated-conflict pass restored the old staged copies. The visitor-facing Liberty register consequently omitted new upstream admissions even though the authored Markdown merged correctly. The prior `009d542` diagnosis found 868 committed entries versus 870 expected at that head. After the subsequent current-`dev` merge, the official compiler now produces 871 entries.

This repair removes successfully rebuilt derived paths from the later restore list and adds a regression that runs the real controller. The original script reproduces stale output; the patched script preserves freshly compiled output. This narrow controller change unblocks the picture work for the Miller House (T-2381), 1832 lighthouse (T-2373), St Mary's church (T-2384), and Hogan's store/first post office (T-2377). All incoming current-`dev` source and picture changes were preserved. No production/main promotion is involved.

[Recovery checkpoint710: final Green Tree WIP, closed app evidence, exact Liberty diagnosis, and controller before-red/after-green proof](https://github.com/kevinrhaas/chicago-evidence/blob/59d3c813d2ae426209a14ba65ca83afce38286a6/evidence/image-match-2026-10-23/resumed-20261023T2245/RECOVERY.md). The checked repair and publication receipt are being included in the next normal continuation checkpoint.
