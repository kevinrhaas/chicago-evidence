# T-2382: next original ready to implement

This review found no additional requested geometry controls. The accepted three-control prototype removes the visitor-noticeable roof height, inward stack and wrong exposed-gable finish. Andreas, Trowbridge, Petford and Kurz14 share the low annex, two sash beside a dark doorway and the same attached single-pen form. Trowbridge/Kurz are retrospective dependent drawings; their projection, occlusion and colour disagreements do not justify another fitting loop. This does not mark unrendered comparisons MATCHES.

## Source adoption after GT releases its lease

Use a clean current branch and refresh the same existing Carpenter claim through the official CLI. The packet has one structure and one Andreas camera postimage, not two camera postimages. Capture fresh HEAD and full Liberty SHA, then run:

```bash
python3 /workspace/T2382-canonical-three-control-packet-20261029/apply_packet.py --repo /workspace/chicago --expect-head "$carpenter_head" --expect-lib-sha "$carpenter_lib_sha"
```

Only after validation, run the identical command with `--apply-source`. Five original source/camera bindings are exact at the dated b20f reading in RESULT.json. The guard validates HEAD, full Liberty preimage, the old prefix and every source/camera preimage before replacing anything. If upstream chronological composition changed the old Liberty prefix, refresh ONLY this prefix guard against the reviewed current append-only input; never restore the old document. Append the packet's1804B Liberty entry after all incoming/GT entries. Placement/footprint/2.5m eave/openings, dates and former-use/current-use qualifications are retained.

## Produce, capture, close

From `chicago/4d`, with the shared pinned environment active, run `bash tools/bake.sh --only philo_carpenter_log_shop`. This is one record, no changed producer and no family bake. The actual prototype took0.189s native emit and2.855s WEB generation; current official bake owns its recipe/manifest/summary and should reproduce the accepted shape. Do not hand-write a recipe or copy old family registries. Compare all non-Carpenter rows/assets exact.

Run the official native owning rederive sequence and settled tail, publish, then actual metadata-bound Andreas capture:

```bash
node tools/photo_match.mjs data/reference_views/philo_carpenter_log_shop/andreas-1884.json --out docs/RESEARCH/photo-match/philo_carpenter_log_shop/andreas-1884
```

The numeric annex rays are already accepted. Its0.472m eye is diagnostic only. Metadata changed and the raw old match is stale: capture anew and directly review actual current output before writing MATCHES/fixed/within-tolerance/not-shown. Preserve raw historical records externally.

Create one finite source-specific Trowbridge comparison against the same native annex (1902 PD source, held `chicago_sauganash_tavern_1835.jpg`); the current tree has no such camera. Include a Kurz14 panel comparison or explicit dependent-copy disposition. Do not tune geometry to fit inconsistent hotel projections; T-2383 remains separate. Petford exact publication remains unresolved: retain qualified reference-only comparison and textual/source credit, do not generate an asset from it or invent rights clearance. No new source clearance is needed to implement the Andreas-derived3controls.

Current Images already links the Andreas library row through `library_image`. Trowbridge/Kurz source cards can be linked by camera source_id and are compiled by compile_pictures; direct displayable copies require the normal credited library stream records rather than invented Prairie building_ids. Do not claim all credited full-image links work until actual desktop/mobile HTTP+render checks pass.

Check actual app ground contact and street-to-door access, Normal/ByGrade, Images credits/full images/Sources/Research at desktop and390x780, zero page errors. Run relevant native published smoke, phone budget and foreground full check before commit; add one small visitor changelog entry. `node tools/image_gate.mjs --structure philo_carpenter_log_shop` must close every current view. Open dev PR, official `done --pr` to REVIEW, normal exact-green merge, official settle to DONE. Expect about60–90min to a checked PR once source lease is available, then20–30min current required CI; no broad15-stage runtime smoke is triggered by an unchanged shared runtime itself.
