from pathlib import Path
import subprocess,json,os,datetime,hashlib,importlib.util,sys
R=Path('/workspace/chicago/chicago/4d/tickets');O=Path(__file__).parent;E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');P='T-2250-2499/T-2376-match-the-green-tree-tavern-to-its-pictures.md';INITIAL='59298ffccb73097a573031bb5436f51f440c3f6e';BASE='879ef25a70cd7337a2c68f0a716143653eb5b64c';prime=json.loads((O/'TICKET-CACHE-PRIME.json').read_text());TIP=prime['tip']
s=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.SOURCE=R;m.G=R/'.git';m.REPO='kevinrhaas/chicago-tickets'
def g(*a):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),'-c','protocol.https.allow=never','-c','protocol.http.allow=never','-c','gc.auto=0','-c','maintenance.auto=false',*a],env=E,stderr=subprocess.STDOUT)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
m.git=g
if sys.argv[1]=='pull':
 assert g('rev-parse','HEAD').decode().strip()==INITIAL and not g('status','--porcelain').strip()
 assert m.api('git/ref/heads/main')['object']['sha']==TIP
 cmp=m.api('compare/'+BASE+'...'+TIP);assert cmp['status']in('ahead','identical')and P not in {x['filename']for x in cmp.get('files',[])}
 assert g('diff','--name-only',BASE,INITIAL).decode().splitlines()==[P]
 raw=m.commit(INITIAL);assert raw['parents']==[BASE]
 before=m.snapshot();save('NESTED-BEFORE.json',before)
 out=g('rebase','--onto',TIP,BASE);(O/'NATIVE-REBASE.log').write_bytes(out)
 head=g('rev-parse','HEAD').decode().strip();new=m.commit(head);assert new['parents']==[TIP]and new['message']==raw['message']
 old=m.leaves(m.commit(TIP)['tree']);after=m.leaves(new['tree']);assert set(old)==set(after)and all(old[p]==after[p]for p in old if p!=P)
 assert g('diff','--name-only',TIP,head).decode().splitlines()==[P]
 own=m.obj('blob',after[P][2]);baseline=m.obj('blob',old[P][2]);strip=lambda b:b'\n'.join(x for x in b.splitlines()if not x.startswith((b'claimed_by:',b'claimed_at:')))
 assert strip(own)==strip(baseline)and b'claimed_at: 2026-10-29T23:35:57.'in own
 assert not g('status','--porcelain').strip()
 save('NATIVE-REBASE.json',{'status':'OFFICIAL_TICKETS_PUSH_PULL_NATIVE_SINGLE_RENEWAL_REBASE_PASS','initial':INITIAL,'initial_parent':BASE,'onto':TIP,'head':head,'tree':new['tree'],'parents':new['parents'],'only_changed_path':P,'all_other_remote_paths_exact':len(old)-1,'only_changed_fields':['claimed_by','claimed_at']});print(out.decode(),end='')
elif sys.argv[1]=='push':
 reb=json.loads((O/'NATIVE-REBASE.json').read_text());head=g('rev-parse','HEAD').decode().strip();assert head==reb['head'];c=m.commit(head);assert c['parents']==[TIP]and not g('status','--porcelain').strip()
 before=m.snapshot();old=m.commit(TIP);oldleaves=m.leaves(old['tree']);leaves=m.leaves(c['tree']);assert set(oldleaves)==set(leaves)and all(oldleaves[p]==leaves[p]for p in leaves if p!=P)
 assert m.api('git/ref/heads/main')['object']['sha']==TIP,'Remote moved: retain native renewal, stop rather than overwrite'
 own=m.obj('blob',leaves[P][2]);b=m.api('git/blobs',{'encoding':'utf-8','content':own.decode()});assert b['sha']==leaves[P][2]
 tr=m.api('git/trees',{'base_tree':old['tree'],'tree':[{'path':P,'mode':'100644','type':'blob','sha':b['sha']}]});assert tr['sha']==c['tree']
 created=m.api('git/commits',m.native_payload(c));save('REMOTE-NATIVE-COMMIT.json',created);assert created['sha']==head
 assert m.api('git/ref/heads/main')['object']['sha']==TIP
 ref=m.api('git/refs/heads/main',{'sha':head,'force':False},'PATCH');assert ref['object']['sha']==head
 remote=m.api('git/commits/'+head);assert remote['tree']['sha']==c['tree']and[p['sha']for p in remote['parents']]==[TIP]
 from urllib.request import Request,urlopen
 with urlopen(Request('https://raw.githubusercontent.com/'+m.REPO+'/'+head+'/'+P,headers={'User-Agent':'Chicago-exact-native-GT-renewal-readback'}),timeout=60)as f:received=f.read();assert f.status==200
 assert received==own and m.gitsha('blob',received)==b['sha'];assert m.snapshot()==before
 at=next(x.split(': ',1)[1].strip()for x in own.decode().splitlines()if x.startswith('claimed_at:'));expiry=datetime.datetime.fromisoformat(at.replace('Z','+00:00'))+datetime.timedelta(hours=3)
 save('RESULT.json',{'status':'EXACT_NATIVE_GT_RENEWAL_SINGLE_COMMIT_REBASE_FF_REST_AND_IMMUTABLE_READBACK_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':m.REPO,'initial_official_claim_commit':INITIAL,'initial_parent':BASE,'remote_base':TIP,'native_head':head,'tree':c['tree'],'parents':[TIP],'only_changed_path':P,'only_changed_fields':['claimed_by','claimed_at'],'all_other_remote_paths_exact':len(leaves)-1,'native_commit_SHA_preserved':True,'official_tickets_sh_push_pull_entrypoint':True,'remote_force':False,'immutable_ticket_bytes':len(own),'immutable_ticket_sha256':hashlib.sha256(own).hexdigest(),'claim_at':at,'claim_expiry_utc':expiry.isoformat(),'local_ticket_source_HEAD_index_config_refs_unchanged_during_REST':True,'primary_app_source_index_ref_writes':False});print((O/'RESULT.json').read_text())
else:raise AssertionError('Unexpected action')
