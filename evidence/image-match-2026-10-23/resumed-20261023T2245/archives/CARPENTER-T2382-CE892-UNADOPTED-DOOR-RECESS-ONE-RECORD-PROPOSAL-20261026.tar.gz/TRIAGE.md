# Remaining-original triage against ce892 (read only)

Re-review of saved actual comparisons/registers, not a new source-reading or a complete all-picture acceptance pass. No original closes.

| Original | Current useful finding / why not next |
| --- | --- |
| T-2372 school | Recess and front-gable courses already landed. Broad frontage, roof/camera and unresolved subject/date remain; no fresh bounded source metric selected. Owner-approved attributed use remains distinct from public domain. |
| T-2374 Cobweb | Connected five rooms and raised heads already landed. Tiny panorama subject/camera join remains unresolved; partial siding chronology is not established. |
| T-2377 Hogan | Recess, boarded gable proxy and short ridge head already landed (T3118). Remaining fabric/texture/cap/proportions need a genuinely new bounded control; do not redeliver old patch. |
| T-2378 Beaubien | Existing /workspace/T2378-readiness-bd316-20261024/READINESS.md already rules no geometry-ready candidate. Preferred inferred identity/source-only patch is recoverable there; no reliable height/stack prescription. |
| T-2379 Lake House | none-cap fix and reconstructed chronology correction already landed (T3123). Later complete-hotel print does not prescribe July construction progress/scaffold/excavation. |
| T-2381 Miller | Saved native comparison clearly has conspicuous tall exterior stack. Current controls do not independently place its source-like short ridge stack atop frame range; do not shorten core below taller roof clearance or blindly adopt coupled camera proportions. |
| T-2382 Carpenter | BEST: closed board leaf visibly differs from Andreas dark occupied opening; existing one-storey recess API admits this record. Only one record/master/web; candidate attached. |
| T-2383 Sauganash | Current upper/attic main-end cladding improvements already exist; saved camera, wing/roof/opening/context gaps remain. A producer expansion would cost frame family rather than this one-master unit. |
| T-2387 first fort | T3105 facade/gallery improvements delivered. Current panel/register retains cupola identity/date disagreement, camera/75ft-staff framing and compound/proportion gaps; not a justified tiny record-only increment. |
| T-2388 second fort | T3124 gallery already present on ce892; do not adopt its old private WIP again. Outside stairs, commandant return and camera remain, with Hubbard outside/inside/continuity limits. New stair backend is larger than Carpenter existing control. |

Full original image gates stay OPEN/DIFFERS. These are candidate-selection notes, not blanket source-camera rulings. The source/master/camera hashes and exact before/after record preimages for the recommended next unit are in BINDINGS-AND-GUARDS.json.
