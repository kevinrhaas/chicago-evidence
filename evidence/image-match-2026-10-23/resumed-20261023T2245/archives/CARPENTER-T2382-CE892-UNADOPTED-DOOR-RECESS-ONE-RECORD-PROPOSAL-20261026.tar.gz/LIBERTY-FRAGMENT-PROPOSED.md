
## L-carpenter-blind-doorway-2382 (UNADOPTED proposal)

Original T-2382: the annex's dark pictured doorway in `andreas_1884_sauganash_hotel_plate` is represented, if adopted, by the existing `front_door_state: recess` consumer: a 300 mm blind exterior shadow proxy. Its depth, returned casing and dark back are reconstructed, not an interior, leaf angle, person or passable portal. Door dimensions/station, full building collision, surveyed placement and all date/use/occupant limits stay unchanged. Petford and the dependent Trowbridge retrospective view share the dark doorway but do not establish its state on 1 July 1835. Original image match remains DIFFERS. Append only after the complete then-current ledger when adopting; do not import a historical whole ledger.
