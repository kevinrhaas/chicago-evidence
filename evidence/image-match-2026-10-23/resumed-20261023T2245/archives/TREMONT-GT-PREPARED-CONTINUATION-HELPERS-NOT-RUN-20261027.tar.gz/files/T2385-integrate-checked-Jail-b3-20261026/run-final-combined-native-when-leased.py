from pathlib import Path
import os,json,hashlib,subprocess,datetime,shutil,zipfile,io,gzip,xml.etree.ElementTree as ET,fnmatch
repo=Path('/tmp/tremont-picture-20261026');app=repo/'chicago/4d';holder=Path('/workspace/T2385-integrate-checked-Jail-b3-20261026');out=Path(os.environ['T2385_FINAL_NATIVE_OUT']);out.mkdir(exist_ok=False)
base=os.environ['T2385_FINAL_BASE'];pending='b3fb939f510a4ffe009a7c45f104ddadc76d3761';head='1290a23271b2771c77201fd17fed7cfa857ade14';sha=lambda b:hashlib.sha256(b).hexdigest()
env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(TMPDIR='/tmp/T2385-GT-final-native-scratch-20261027',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',CHECK_JOBS='1',C4D_RULINGS_BASE=base);Path(env['TMPDIR']).mkdir(exist_ok=True)
def g(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=repo,env=env)
assert g('rev-parse','HEAD').decode().strip()==head
assert g('rev-parse','MERGE_HEAD').decode().strip()==pending
assert g('rev-parse','origin/dev').decode().strip()==base
assert g('rev-parse',base+'^{tree}').decode().strip()==os.environ['T2385_FINAL_BASE_TREE']

assert subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/dev','--jq','.object.sha'],env=env).decode().strip()==base,'Fresh actual base moved before native source freeze'
# Same pinned modules, selected through a task-local runtime prefix for native
# ESM tools that fall back to npm root -g. No shared/runtime source edits.
n=int(env.get('GIT_CONFIG_COUNT','0'))
for k,v in [('gc.auto','0'),('maintenance.auto','false'),('remote.origin.tagOpt','--no-tags')]:
 env[f'GIT_CONFIG_KEY_{n}']=k;env[f'GIT_CONFIG_VALUE_{n}']=v;n+=1
env['GIT_CONFIG_COUNT']=str(n)
assert shutil.disk_usage('/tmp').free>=1_800_000_000,'Measured one-copy startup floor'
from importlib import import_module
import sys
sys.path.insert(0,str(app/'generators'))
mesh_inputs=import_module('mesh_inputs');gt=json.loads((app/'data/structures/green_tree_tavern.json').read_bytes())
assert mesh_inputs.structure_inputs_sha(gt,gt['phases'][0])=='38d1d02c87618a7a6af8b67bef60a97f3c8a72e3bfc3a882802040ea1c04167d'
for tier,want in [('gltf','f69934897306e608bad55f6ffecfdcb53adf030675b6df0df9fa1004ba3a4d2c'),('web','7526b262499e7a3a24175eb37afcbc74472a8bf4b290e8af030625b5ea4a2ffd')]:
 assert sha((app/'assets'/tier/'green_tree_tavern__frame_1833.glb').read_bytes())==want
assert os.environ['PRAIRIE_IMAGE_STORE']==str(holder/'image-card/native-store/prairie-1904/files')
image_before=json.loads((repo/'chicago/prairie_1904_v1/research/images/STORE.json').read_bytes())
prelude_steps=[]
for name,args in [('00a-native-image-store-union',['python3','tools/sync_image_store.py']),('00b-native-image-store-check',['python3','tools/sync_image_store.py','--check']),('00c-native-library-build',['python3','tools/build_images.py']),('00d-native-library-check',['python3','tools/build_images.py','--check'])]:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(out/(name+'.log')).open('x')as log:q=subprocess.run(args,cwd=repo/'chicago/prairie_1904_v1',env=env,stdout=log,stderr=subprocess.STDOUT)
 prelude_steps.append({'name':name,'command':args,'started':start,'exit':q.returncode})
 (out/'IMAGE-PRELUDE-STEPS.json').write_text(json.dumps(prelude_steps,indent=2)+'\n')
 assert q.returncode==0,(name,q.returncode)
image_after=json.loads((repo/'chicago/prairie_1904_v1/research/images/STORE.json').read_bytes())
assert all(image_after['files'].get(k)==v for k,v in image_before['files'].items()),'Existing native image rows changed'
for name in ['early-andreas-1884-sauganash.jpg','early-andreas-1884-sauganash-thumb.jpg','early-gifford-first-tremont.jpg','early-gifford-first-tremont-thumb.jpg','early-moss-1884-st-marys.jpg','early-moss-1884-st-marys-thumb.jpg']:assert name in image_after['files']
(out/'IMAGE-UNION-PROOF.json').write_text(json.dumps({'status':'NATIVE_ALL_THREE_HELD_IMAGE_STREAMS_PRESERVED','before_rows':len(image_before['files']),'after_rows':len(image_after['files']),'every_prior_row_exact':True},indent=2)+'\n')
before44=[];people=[]
for path in g('ls-tree','-r','--name-only',base).decode().splitlines():
 if path.lower().endswith(('.xlsx','.gz')):
  raw=g('show',base+':'+path);current=(repo/path).read_bytes()
  before44.append({'path':path,'sha256':sha(raw),'current_before_sha256':sha(current),'bytes':len(raw)})
assert len(before44)==44 and sum(r['path'].endswith('.xlsx')for r in before44)==23 and sum(r['path'].endswith('.gz')for r in before44)==21
(out/'ACTUAL_FINAL_INCOMING_44_PRE_NATIVE.json').write_text(json.dumps(before44,indent=2)+'\n')
isolated=[]
for row in before44:
 p=repo/row['path']
 if p.stat().st_nlink>1:
  import tempfile
  fd,tmp=tempfile.mkstemp(dir=p.parent,prefix='.t2385-binary-');os.close(fd);shutil.copy2(p,tmp);os.replace(tmp,p);isolated.append(row['path'])
(out/'BINARY-HARDLINK-ISOLATION.json').write_text(json.dumps({'only_owned44paths_isolated_if_shared':isolated,'all_bytes_preserved':all(sha((repo/r['path']).read_bytes())==r['current_before_sha256']for r in before44)},indent=2)+'\n')
manifest=json.loads((app/'tools/derived_manifest.json').read_text());gen={p for s in manifest['steps']for p in s.get('resolves',[])}
def generated(p):return p in {'chicago/4d/data/frontage/town_street_edge.json','chicago/4d/data/signage/town_business_signboards.json','chicago/4d/data/yard/town_trade_goods.json'} or any(p==q or p.startswith(q.rstrip('/')+'/') or fnmatch.fnmatch(p,q)for q in gen)
paths={p for p in (g('ls-files','-z')+g('ls-files','--others','--exclude-standard','-z')).decode().split('\0')if p}
protected={p:sha((repo/p).read_bytes())for p in paths if p.startswith('chicago/4d/') and (repo/p).is_file() and not generated(p) and not p.startswith('chicago/4d/data/sidecars/')}
for p in paths:
 if (p.startswith('.github/workflows/')or p.startswith('chicago/prairie_1904_v1/'))and(repo/p).is_file():protected[p]=sha((repo/p).read_bytes())
# The authored incoming changelog and strict tools are held despite any broad manifest entry.
for p in ['chicago/4d/renderers/web/js/changelog.js','chicago/4d/tools/smoke_renderer.mjs','chicago/4d/tools/drawn_placement_census.mjs','chicago/4d/tools/test_drawn_placement_census.mjs','chicago/4d/tools/measure_drawn_placement.mjs']:
 protected[p]=sha((repo/p).read_bytes())
(out/'PROTECTED_BEFORE.json').write_text(json.dumps(protected,indent=2)+'\n')
assert shutil.disk_usage('/tmp').free>=1_800_000_000,'Measured one-copy native drift startup floor1.8GB'
assert os.sched_getaffinity(0)=={int(x)for x in os.environ['T2385_FINAL_CPU_IDS'].split(',')},'Use only actual coordinated native lease'
def memory_available():
 info=Path('/proc/meminfo').read_text().splitlines();available=int(next(x.split()[1]for x in info if x.startswith('MemAvailable:')))*1024
 maximum=Path('/sys/fs/cgroup/memory.max');current=Path('/sys/fs/cgroup/memory.current')
 if maximum.exists()and current.exists()and maximum.read_text().strip()!='max':available=min(available,int(maximum.read_text())-int(current.read_text()))
 return available
steps=[]
def command(name,args):
 free=shutil.disk_usage('/tmp').free;assert free>=536870912,(name,'native_helper512MiBreserve',free);assert memory_available()>=536870912,(name,'native_memory512MiBreserve',memory_available())
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();print(name,'START',start,flush=True)
 with (out/(name+'.log')).open('x') as log:r=subprocess.run(args,cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':args,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'free_before':free,'free_after':shutil.disk_usage('/tmp').free};steps.append(row);(out/'STEPS.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0,(name,r.returncode)
def protect(label):
 changed=[p for p,v in protected.items() if not(repo/p).exists()or sha((repo/p).read_bytes())!=v];assert not changed,(label,'authoredsource_or_assets_moved',changed)
 changed=[row['path']for row in people if sha((repo/row['path']).read_bytes())!=row['sha256']];assert not changed,(label,'resident_capacity_alternate_changed',changed)
 (out/(label+'-PROTECTIONS.json')).write_text(json.dumps({'all_authored_assets_controls_exact':len(protected),'people_capacities_versions_exact':len(people)},indent=2)+'\n')
command('01-native-metadata-tail',['node','tools/rederive.mjs','--tail','tools/compile_liberties.py'])
assert not g('diff','--name-only','--diff-filter=U').strip()
protect('post-resolve')
def canonical_xlsx(b):
 with zipfile.ZipFile(io.BytesIO(b)) as z:
  members={}
  for n in sorted(z.namelist()):
   raw=z.read(n)
   if n.endswith(('.xml','.rels')):
    root=ET.fromstring(raw)
    if n=='docProps/core.xml':
     for node in list(root):
      if node.tag=='{http://purl.org/dc/terms/}modified':root.remove(node)
    members[n]=ET.canonicalize(ET.tostring(root,encoding='unicode'))
   else:members[n]=raw
  return members
rows=[]
for row in before44:
 p=repo/row['path'];now=p.read_bytes();old=g('show',base+':'+row['path']);assert sha(old)==row['sha256'];same=now==old;kind='EXACT_BYTES'
 if not same:
  save=out/'regenerated-before-normalization'/row['path'];save.parent.mkdir(parents=True,exist_ok=True);save.write_bytes(now)
  if row['path'].lower().endswith('.xlsx'):same=canonical_xlsx(now)==canonical_xlsx(old);kind='ALL_XLSX_MEMBERS_CANONICAL_XML_EXCEPT_CORE_MODIFIED'
  else:same=gzip.decompress(now)==gzip.decompress(old);kind='GZIP_DECOMPRESSED_BYTES'
  if same:
   import tempfile
   fd,tmp=tempfile.mkstemp(dir=p.parent,prefix='.t2385-serialization-');os.close(fd);Path(tmp).write_bytes(old);shutil.copymode(p,tmp);os.replace(tmp,p)
 rows.append({'path':row['path'],'current_sha256':sha(now),'incoming_sha256':sha(old),'equivalent':same,'proof':kind,'action':'UNCHANGED'if now==old else'RESTORE_PROVEN_SERIALIZATION_ONLY'if same else'RETAIN_REAL_CHANGE'})
(out/'ONE_ALL44_ACTUAL_INCOMING_AUDIT.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(r['equivalent']for r in rows),'Actual binary data changed: preserve and review'
command('02-native-package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py'])
command('03-native-publish',['bash','tools/publish.sh'])
for name,args in [('04-lodging-check',['python3','tools/build_lodging_model_1835.py','--check']),('05-boarders-check',['python3','tools/seat_lodgers_1835.py','--check']),('06-business-check',['python3','tools/reconstruct_businesses_1835.py','--check']),('07-staffing-check',['python3','tools/staffing_mint_order_1835.py','--check']),('08-strict-placement-fixtures',['node','tools/test_drawn_placement_census.mjs']),('09-independent-farwalk-census',['node','tools/check_far_plank_tops.mjs','--json'])]:command(name,args)
protect('final')
assert all(sha((repo/r['path']).read_bytes())==r['sha256']for r in before44)
result={'status':'PASS_CURRENT_COMBINED_TREMONT_GT_NATIVE_CLOSURE_NO_FINAL_CODE_GATES_OR_APP','head':head,'merge_head':pending,'actual_incoming_dev':base,'steps':steps,'image_prelude_steps':prelude_steps,'all44_byteexact_actual_incoming_dev_after_proven_normalization':True,'old1290_full18_covers_this_WIP':False,'original_DONE':False,'protected_people_capacity_alternate':len(people),'protected_authored_assets':len(protected),'pending':'Actualbothviewportcombinedapp, ONEfinalfull3, sourceidenticalnormalpendingb3codecommit+actualdevancestry, committedquestions/normalFFpush, applicablepublishedqualification, Ready/standardexpectedheadMERGEdev. T2376annexstaysOPEN; onlyT2385mayfinishafteractualacceptance/merge.'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
