# Original Chicago image-ticket progress — 2026-10-29

Live read-only GitHub snapshot at 2026-10-29T14:28:41.908774+00:00. Ticket repository main `0c8beeb82f3a9e9c65ecbefcaad37d1087ec4654`.

13 previously tracked app PRs are merged into `dev`. These are bounded visible improvements, not 13 completed original image tickets. Zero of the 17 original records currently reads `done`; T-2387 is split and the other 16 are open or claimed.

| Original | Live state |
|---|---|
| T-2372 | claimed |
| T-2373 | claimed |
| T-2374 | open |
| T-2375 | open |
| T-2376 | claimed |
| T-2377 | open |
| T-2378 | open |
| T-2379 | open |
| T-2380 | claimed |
| T-2381 | claimed |
| T-2382 | claimed |
| T-2383 | open |
| T-2384 | claimed |
| T-2385 | claimed |
| T-2386 | claimed |
| T-2387 | split |
| T-2388 | open |

Current resumed work: a corrective Tremont/Green Tree PR after PR1337 merged its old head; then one grouped Miller/Mary/lighthouse app PR. Current remote dev `03b027ba6bed8d8ebf1a20e716462ea2b8b54739` still has the two-storey Tremont default, while the directly inspected drawing shows three. Preserve the text-based two-storey account as an optional version.

Mary and lighthouse scoped image checks passed on the explicitly dated preparation inputs. Their final current app integration, policy checks, PR and merge remain outstanding. Miller has two genuinely produced visible corrections but whole-picture acceptance remains under a finite independent review. No fresh global scene acceptance or completion-time estimate is implied.

The complete previous per-ticket scope and remaining gaps remain historical at `/tmp/original-progress-audit-closed-20261026T1808/ORIGINAL-PROGRESS-20261026T1730.md`; this snapshot does not restamp those old reviews as new.
