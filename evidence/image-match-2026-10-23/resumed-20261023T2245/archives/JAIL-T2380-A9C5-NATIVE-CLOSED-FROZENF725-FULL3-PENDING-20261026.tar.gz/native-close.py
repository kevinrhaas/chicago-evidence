from pathlib import Path
import subprocess,json,hashlib,os,datetime,shutil,gzip,zipfile,io,xml.etree.ElementTree as ET
os.sched_setaffinity(0,{1,4});repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';out=Path('/workspace/shared/T2380-integrate-a9c5-20261026T1235');base='a9c5bd4a9715e4d5634c536d0efcd516ea9c3f01';env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None);env.update(PYTHONPATH='/workspace/shared/python',NODE_PATH='/workspace/shared/node/node_modules',PATH='/workspace/shared/tools/usr/bin:/workspace/shared/gltf-transform/node_modules/.bin:'+env['PATH'],PW_EXECUTABLE='/usr/bin/chromium',TMPDIR='/tmp/jail-a9c5-native-tmp',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',npm_config_cache='/workspace/shared/npm-cache');Path(env['TMPDIR']).mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=repo,env=env);protected=json.loads((out/'PROTECTED-NORMAL-INTEGRATED-BEFORE.json').read_text());canonical=git('show',base+':chicago/4d/renderers/web/js/changelog.js');steps=[]
def save(n,d):(out/n).write_text(json.dumps(d,indent=2)+'\n')
def guards(tag):
 changed={p:{'before':h,'after':sha((repo/p).read_bytes())}for p,h in protected.items()if sha((repo/p).read_bytes())!=h};save('PROTECTED-'+tag+'.json',{'count':len(protected),'changed':changed});assert not changed,changed
 assert(app/'renderers/web/js/changelog.js').read_bytes()==canonical,'INCOMING_CANONICAL_CHANGED'
def command(name,c):
 free=shutil.disk_usage(env['TMPDIR']).free;assert free>=512*1024**2,('CALLER_512M_STARTUP',name,free)
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();print('START',name,start,'TMPFREE',free,flush=True)
 with(out/(name+'.log')).open('x')as log:p=subprocess.run(c,cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
 steps.append({'name':name,'command':c,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'tmp_free_start':free});save('NATIVE-STEPS.json',steps);print('CLOSED',name,p.returncode,flush=True);assert p.returncode==0,(name,p.returncode)
assert git('rev-parse','MERGE_HEAD').decode().strip()==base;guards('PRE');save('NATIVE-RUNNING.json',{'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'affinity':sorted(os.sched_getaffinity(0)),'external_TMP':env['TMPDIR'],'caller_reserve_bytes':512*1024**2,'resource_authority':'Root2026-10-26explicit512MiBfornative202/tails/audit/pkg/publish;notnativequalityassertion','actual_free':shutil.disk_usage(env['TMPDIR']).free,'protected':len(protected),'all44_before_exact':True,'no_model_or_web_bakes':True})
command('official-glessner-check',['python3','tools/recover_glessner_v4.py','--check'])
command('owning-native-resolve',['node','tools/rederive.mjs','--resolve']);guards('POST-OWNING')
art=json.loads((out/'ALL44-ARTIFACTS-INCOMING-BEFORE.json').read_text())['paths'];dirty=set(git('diff',base,'--name-only','-z').decode().strip('\0').split('\0'));targets=sorted(set(art)|{p for p in dirty if p and not p.startswith('chicago/4d/')})
def xlsx(b):
 with zipfile.ZipFile(io.BytesIO(b))as z:
  result={}
  for name in z.namelist():
   data=z.read(name)
   if name.endswith(('.xml','.rels')):
    root=ET.fromstring(data)
    if name=='docProps/core.xml':
     for node in list(root):
      if node.tag=='{http://purl.org/dc/terms/}modified':root.remove(node)
    result[name]=ET.canonicalize(ET.tostring(root,encoding='unicode'))
   else:result[name]=data.hex()
  return result
proof=[]
for rel in targets:
 p=repo/rel;now=p.read_bytes();old=git('show',base+':'+rel);exact=now==old;equal=exact;kind='BYTE_EXACT_SHORT_CIRCUIT'
 if not exact and rel.endswith('.xlsx'):kind='ALL_CANONICAL_ZIP_MEMBERS_EXCEPT_MODIFIED_TIMESTAMP';equal=xlsx(now)==xlsx(old)
 elif not exact and rel.endswith('.gz'):
  kind='GZIP_DECOMPRESSED_BYTES';equal=gzip.decompress(now)==gzip.decompress(old)
  if not equal:
   try:equal=json.loads(gzip.decompress(now))==json.loads(gzip.decompress(old));kind='GZIP_JSON_SEMANTICS'
   except(ValueError,UnicodeError):pass
 elif not exact:
  try:equal=json.loads(now)==json.loads(old);kind='WHOLE_JSON_SEMANTICS'
  except(ValueError,UnicodeError):kind='REAL_OR_UNCLASSIFIED_OUTSIDE_CHANGE';equal=False
 rec={'path':rel,'before_native_incoming':art.get(rel),'kind':kind,'equal':equal,'regenerated_sha256':sha(now),'incoming_sha256':sha(old),'action':'UNCHANGED'if exact else'RESTORE_EXACT_A9C5'if equal else'PRESERVE_REAL_CHANGE'};proof.append(rec)
 if not exact:
  dest=out/'regenerated-before-normalization'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(now)
  if equal:p.write_bytes(old)
save('ALL44-AND-OUTSIDE-AUDIT.json',proof);assert all(x['equal']for x in proof),[x for x in proof if not x['equal']]
restored=[x['path']for x in proof if x['action']=='RESTORE_EXACT_A9C5']
if restored:subprocess.run(['git','add','--',*restored],cwd=repo,env=env,check=True)
command('package5-tail',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']);guards('POST-PACKAGE')
command('final-publish',['bash','tools/publish.sh']);guards('FINAL')
assert(repo/'site/4d/js/changelog.js').read_bytes()==canonical
assert all(sha((repo/x['path']).read_bytes())==x['incoming_sha256']for x in proof)
assert not git('diff','--name-only','--diff-filter=U').decode().strip()
# Native owning resolution stages its outputs; stage final whole-proven serialization restores and native tail outputs.
subprocess.run(['git','add','-u'],cwd=repo,env=env,check=True)
assert subprocess.run(['git','diff','--quiet'],cwd=repo,env=env).returncode==0
result={'status':'NATIVE_OWNING_CONTRACT_AUDIT44_PACKAGE5_PUBLISH_PASS','closed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'head':git('rev-parse','HEAD').decode().strip(),'merge_head':git('rev-parse','MERGE_HEAD').decode().strip(),'staged_tree':git('write-tree').decode().strip(),'protected_count':len(protected),'all_protected_exact':True,'actual_all_artifacts':len(art),'actual_audit_paths':len(proof),'serialization_only_restored':restored,'canonical_incoming_source_published_sha256':sha(canonical),'steps':steps,'no_new_bakes_or_app_render':True,'pending':'Assigned2jobwhole3questionlease then normalcodecommit/committedCLIDs/push1333/full18finalcheckedhead. Original2380 remainsDIFFERS.'};save('NATIVE-RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
