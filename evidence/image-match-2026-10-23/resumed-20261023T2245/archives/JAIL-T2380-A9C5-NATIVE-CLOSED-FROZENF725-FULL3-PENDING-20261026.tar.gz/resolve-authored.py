from pathlib import Path
import subprocess,json,hashlib,os,re,datetime
os.sched_setaffinity(0,{1,4});repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';out=Path('/workspace/shared/T2380-integrate-a9c5-20261026T1235');base='a9c5bd4a9715e4d5634c536d0efcd516ea9c3f01';head='e81e1d2d2352f152498564eff61d0fdf4c29c7c6';env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None);env.pop('CHICAGO_TICKETS_DIR',None)
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo,env=env)
def blob(ref,p):return git('show',ref+':'+p)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,d):(out/n).write_text(json.dumps(d,indent=2)+'\n')
assert git('rev-parse','HEAD').decode().strip()==head and git('rev-parse','MERGE_HEAD').decode().strip()==base
p='chicago/4d/docs/LIBERTIES.md';incoming=blob(base,p);ours=blob(head,p);marker=b'### L-jail-palisade-2380 ';assert ours.count(marker)==1 and marker not in incoming;suffix=ours[ours.index(marker):];(repo/p).write_bytes(incoming.rstrip(b'\n')+b'\n\n\n'+suffix);save('LIBERTIES-AUTHORED-RESOLUTION.json',{'rule':'Whole incoming bytes, trailing newlines normalized only at append boundary, plus exact own Jail suffix; no incoming text dropped','incoming_sha256':sha(incoming),'own_suffix_sha256':sha(suffix),'resolved_sha256':sha((repo/p).read_bytes())})
# Automatic merge combined two independently-added ranges IDs. Preserve incoming's complete exact strict list and keep all other Jail/native oracle fixes.
p='chicago/4d/tools/smoke_renderer.mjs';current=(repo/p).read_text();incoming=blob(base,p).decode();pattern=r'const PLACED_1904 = \[.*?\]\.sort\(\);';old=re.search(pattern,current,re.S).group();new=re.search(pattern,incoming,re.S).group();assert current.count(old)==1 and old.count("'pullman_house_1729_prairie_ranges'")==2 and new.count("'pullman_house_1729_prairie_ranges'")==1
(out/'AUTO-MERGED-DUPLICATE-1904-LIST.txt').write_text(old+'\n');(out/'EXACT-INCOMING-1904-LIST.txt').write_text(new+'\n');(repo/p).write_text(current.replace(old,new))
js="""import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';const list=fs.readFileSync(process.argv[1],'utf8');const expected=vm.runInNewContext(list+'PLACED_1904');const idx=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));const actual=idx.structures.map(x=>x.id).sort();assert.equal(expected.length,283);assert.equal(new Set(expected).size,283);assert.equal(JSON.stringify(expected),JSON.stringify(actual));console.log(JSON.stringify({status:'STRICT_EXACT_1904_SET_RETAINED',expected,actual_count:actual.length,unique_count:new Set(expected).size}));"""
proof=subprocess.check_output(['node','--input-type=module','-e',js,str(out/'EXACT-INCOMING-1904-LIST.txt'),str(app/'data/sidecars/1904/index.json')],cwd=app,env=env);(out/'STRICT-1904-LIST-PROOF.json').write_bytes(proof)
# Other code repairs remain exact current-head bytes; incoming did not modify these paths.
for p in ['chicago/4d/tools/drawn_placement_census.mjs','chicago/4d/tools/test_drawn_placement_census.mjs','chicago/4d/tools/measure_drawn_placement.mjs']:assert(repo/p).read_bytes()==blob(head,p)
canonical=blob(base,'chicago/4d/renderers/web/js/changelog.js');assert(app/'renderers/web/js/changelog.js').read_bytes()==canonical
assert(app/'changelog.d/T-2380.json').read_bytes()==blob(head,'chicago/4d/changelog.d/T-2380.json')
subprocess.run(['git','add','--','chicago/4d/docs/LIBERTIES.md','chicago/4d/tools/smoke_renderer.mjs'],cwd=repo,env=env,check=True)
unmerged=git('diff','--name-only','--diff-filter=U').decode().splitlines();assert sorted(unmerged)==['chicago/4d/data/liberties.json','chicago/4d/docs/measurements/source_use_coverage.md'];save('REMAINING-NATIVE-DERIVED-CONFLICTS.json',unmerged)
oldpaths=json.loads(Path('/workspace/shared/T2380-integrate-a575-20261026/PROTECTED-NORMAL-INTEGRATED-BEFORE.json').read_text());allpaths=set(git('ls-files','-z').decode().strip('\0').split('\0'));prefixes=['chicago/4d/data/reconstruction/','chicago/4d/data/residents/','chicago/4d/data/structures/','chicago/4d/assets/gltf/','chicago/4d/assets/web/'];paths=set(oldpaths)|{p for p in allpaths if any(p.startswith(t)for t in prefixes)}
protected={p:sha((repo/p).read_bytes())for p in sorted(paths)};save('PROTECTED-NORMAL-INTEGRATED-BEFORE.json',protected)
art={}
for p in sorted(x for x in allpaths if x.endswith(('.xlsx','.gz'))):
 old=blob(base,p);now=(repo/p).read_bytes();assert now==old,p;art[p]={'incoming_sha256':sha(old),'incoming_bytes':len(old),'current_sha256':sha(now)}
assert len(art)==44 and sum(p.endswith('.xlsx')for p in art)==23 and sum(p.endswith('.gz')for p in art)==21;save('ALL44-ARTIFACTS-INCOMING-BEFORE.json',{'actual_count':44,'xlsx':23,'gz':21,'basis':base,'paths':art})
save('AUTHORED-RESULT.json',{'status':'EXACT_INCOMING_PLUS_OWN_JAIL_SUFFIX_STRICT_1904_DUPLICATE_REMOVED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'base':base,'protected_count':len(protected),'derived_conflicts':unmerged,'all44_exact_incoming':True,'canonical_incoming_sha256':sha(canonical),'no_asset_bakes':True});print((out/'AUTHORED-RESULT.json').read_text())
