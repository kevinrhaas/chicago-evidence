from pathlib import Path
import subprocess,json,datetime,hashlib,shutil
repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';out=Path(__file__).parent
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo).decode().strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert json.loads((out/'NATIVE-RESULT.json').read_text())['status']=='NATIVE_OWNERS_RESOLVE_PASS'
audit=json.loads((out/'ALL44-AND-MODEL-AUDIT.json').read_text());assert audit['status']=='PASS'
expected={'chicago/4d/changelog.d/T-2380.json','chicago/4d/data/sidecars/1835/philo_carpenter_log_shop.json','chicago/4d/data/structure_grades.json','chicago/4d/docs/ROADMAP.md','chicago/4d/docs/STATUS.md','chicago/4d/renderers/web/js/changelog.js'}
assert set(git('diff','HEAD','--name-only').splitlines())==expected
assert git('rev-parse','MERGE_HEAD')=='373851d158a7b6fc701b9cae1a651aa4b3823f97'
protected={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in expected if p!='chicago/4d/changelog.d/T-2380.json'}
results=[]
for name,cmd in [('package5',['node','tools/rederive.mjs','--tail','tools/export_resident_research_package.py']),('publish',['bash','tools/publish.sh'])]:
 assert shutil.disk_usage('/tmp').free>=512*1024**2
 start=now()
 with (out/(name+'-v2.log')).open('w') as f:code=subprocess.call(cmd,cwd=app,stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,started=start,finished=now(),exit=code))
 if code:break
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in protected.items())
assert set(git('diff','HEAD','--name-only').splitlines())==expected
assert git('diff','--cached','--name-status','--','chicago/4d/changelog.d/T-2380.json')=='D\tchicago/4d/changelog.d/T-2380.json'
subprocess.run(['git','add','--',*[p for p in sorted(expected) if (repo/p).exists()]],cwd=repo,check=True)
assert not git('ls-files','-u') and not git('diff','--name-only')
grade=json.loads((repo/'site/4d/data/sidecars/1835/philo_carpenter_log_shop.json').read_text())['grade'] if (repo/'site/4d/data/sidecars/1835/philo_carpenter_log_shop.json').exists() else json.loads((app/'data/sidecars/1835/philo_carpenter_log_shop.json').read_text())['grade']
r=dict(status='PASS' if len(results)==2 and all(x['exit']==0 for x in results) else 'FAIL_RETAINED',at=now(),head=git('rev-parse','HEAD'),incoming=git('rev-parse','MERGE_HEAD'),tree=git('write-tree'),actual_index_entry_count=len(git('ls-files','-s').splitlines()),steps=results,source_protected=protected,grade=grade,planned_changed_paths=sorted(expected),no_other_source_changes=True,pending='Full3 and bothviewport publishedcardreview; no codecommit/push orDEV merge claim.')
(out/'CLOSED-READY-FOR-FULL3.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(0 if r['status']=='PASS' else 1)
