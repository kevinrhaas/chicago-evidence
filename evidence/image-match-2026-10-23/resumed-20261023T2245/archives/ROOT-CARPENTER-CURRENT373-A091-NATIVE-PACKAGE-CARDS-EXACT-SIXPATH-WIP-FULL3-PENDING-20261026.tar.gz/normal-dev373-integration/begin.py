from pathlib import Path
import subprocess,json,hashlib,datetime,shutil
repo=Path('/tmp/jail-picture-c6');out=Path(__file__).parent;prior=out.parent/'alias-count-native-tail'
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo)
head=git('rev-parse','HEAD').decode().strip();base=git('rev-parse','origin/dev').decode().strip()
assert head=='f311c2a9b7628e22835973933c9de41b83a2b531'
assert base=='373851d158a7b6fc701b9cae1a651aa4b3823f97'
remote=subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/dev','--jq','.object.sha'],text=True).strip();assert remote==base
wip=json.loads((prior/'CURRENT-WIP.json').read_text());proof=json.loads((prior/'WIP-PATCH-READBACK.json').read_text());assert proof['status']=='PASS'
files=[x['path'] for x in wip['files']];assert git('diff','--name-only').decode().splitlines()==files
assert not git('diff','--cached','--name-only').strip()
assert hashlib.sha256((prior/'derived-alias-WIP.patch').read_bytes()).hexdigest()==wip['patch_sha256']
for x in wip['files']:assert hashlib.sha256((repo/x['path']).read_bytes()).hexdigest()==x['sha256']
b=dict(status='BOUND_BEFORE_NORMAL_MERGE',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,tree=git('rev-parse','HEAD^{tree}').decode().strip(),actual_dev=base,remote_dev=remote,wip_patch=str(prior/'derived-alias-WIP.patch'),wip_files=wip['files'],working_before=git('status','--short').decode(),workspace_free=shutil.disk_usage('/workspace').free,tmp_free=shutil.disk_usage('/tmp').free)
(out/'BEFORE.json').write_text(json.dumps(b,indent=2)+'\n')
# Restore only our four independently recoverable WIP files before the normal merge.
for p in files:(repo/p).write_bytes(git('show',head+':'+p))
assert not git('status','--porcelain').strip()
with (out/'normal-merge.log').open('w') as log:
 code=subprocess.call(['git','-c','gc.auto=0','-c','maintenance.auto=false','merge','--no-commit','--no-ff',base],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
r=dict(status='NORMAL_MERGE_STARTED_NOT_RESOLVED_NOT_GATED',exit=code,head=git('rev-parse','HEAD').decode().strip(),merge_head=git('rev-parse','MERGE_HEAD').decode().strip(),status_text=git('status','--short').decode(),unmerged=git('ls-files','-u').decode())
(out/'MERGE-STATE.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
