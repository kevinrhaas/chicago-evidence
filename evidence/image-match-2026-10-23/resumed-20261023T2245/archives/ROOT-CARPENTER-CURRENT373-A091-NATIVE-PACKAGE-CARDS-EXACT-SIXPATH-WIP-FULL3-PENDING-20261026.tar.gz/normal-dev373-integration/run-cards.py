from pathlib import Path
import subprocess,json,os,datetime
repo=Path('/tmp/jail-picture-c6');out=Path(__file__).parent;target=out.parent/'alias-card-review-after-dev373'
def git(*a):return subprocess.check_output(['git',*a],cwd=repo,text=True).strip()
expected='a091a9d69f816e374e2c6503670b3e1602b8e09d';assert git('write-tree')==expected and not git('diff','--name-only');assert not target.exists()
b=dict(status='RUNNING',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=git('rev-parse','HEAD'),merge=git('rev-parse','MERGE_HEAD'),tree=expected,affinity=sorted(os.sched_getaffinity(0)),scope='Only current Photos/Sources/Research alias-card behavior. Prior physical scene review is separately scoped by exactsource/model/253runtimeJS proof; no full3/currentwhole18/performancecertificate claim.')
(out/'card-review-BINDING.json').write_text(json.dumps(b,indent=2)+'\n')
env=dict(os.environ,CARPENTER_APP_OUT=str(target),CARPENTER_TRUST_PROFILE='/tmp/carpenter-browser-trust-20261026/profile')
with (out/'card-review.log').open('w') as f:code=subprocess.call(['node',str(out/'review-published-cards-only.mjs')],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
guards=dict(tree=git('write-tree')==expected,working_bytes=not git('diff','--name-only'))
r=dict(status='PASS' if code==0 and all(guards.values()) else 'FAIL_RETAINED',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),binding=b,exit=code,guards=guards,result=str(target/'RESULT.json'))
(out/'CARD-REVIEW-RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(0 if r['status']=='PASS' else 1)
