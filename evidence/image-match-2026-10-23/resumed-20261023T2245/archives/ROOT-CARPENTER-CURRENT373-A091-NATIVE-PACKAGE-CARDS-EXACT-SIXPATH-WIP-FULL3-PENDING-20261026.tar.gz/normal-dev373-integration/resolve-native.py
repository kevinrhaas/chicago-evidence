from pathlib import Path
import subprocess,os,json,hashlib,shutil,datetime
repo=Path('/tmp/jail-picture-c6');app=repo/'chicago/4d';out=Path(__file__).parent
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo).decode().strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert git('rev-parse','HEAD')=='f311c2a9b7628e22835973933c9de41b83a2b531';assert git('rev-parse','MERGE_HEAD')=='373851d158a7b6fc701b9cae1a651aa4b3823f97'
assert {l.split('\t')[1] for l in git('ls-files','-u').splitlines()}=={'chicago/4d/data/liberties.json','chicago/4d/docs/measurements/source_use_coverage.md'}
wip=json.loads((out.parent/'alias-count-native-tail/CURRENT-WIP.json').read_text());authored={x['path']:x['sha256'] for x in wip['files'] if '/sidecars/' not in x['path']}
for p,h in authored.items():assert hashlib.sha256((repo/p).read_bytes()).hexdigest()==h
assert shutil.disk_usage('/tmp').free>=1000000000
binding=dict(status='NATIVE_OWNERS_RESOLVE_ACTIVE',at=now(),head=git('rev-parse','HEAD'),incoming=git('rev-parse','MERGE_HEAD'),actual_dev=git('rev-parse','origin/dev'),authored=authored,affinity=sorted(os.sched_getaffinity(0)),command=['node','tools/rederive.mjs','--resolve'],scope='Native ownership resolution after genuine373merge and boundedcanonicalpicturealias data correction. No full3 or appPASS claimed yet.')
(out/'NATIVE-BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
with (out/'native-resolve.log').open('w') as f:code=subprocess.call(binding['command'],cwd=app,stdout=f,stderr=subprocess.STDOUT)
grade=json.loads((app/'data/sidecars/1835/philo_carpenter_log_shop.json').read_text())['grade'];guards=dict(head=git('rev-parse','HEAD')==binding['head'],incoming=git('rev-parse','MERGE_HEAD')==binding['incoming'],authored=all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in authored.items()),no_unmerged=not git('ls-files','-u'),canonical_grade=grade=={'value':'attested','why':'Pictured: a picture on the Images tab shows it.','pictures':['early-andreas-1884-sauganash']})
r=dict(status='NATIVE_OWNERS_RESOLVE_PASS' if code==0 and all(guards.values()) else 'NATIVE_OWNERS_RESOLVE_FAIL_RETAINED',at=now(),binding=binding,exit=code,guards=guards,grade=grade,changed_paths=git('diff','HEAD','--name-only').splitlines(),pending='Full binary/model audit, package/publish and full3, actual bothviewportcard review, commit/push and qualifiedDEV ending.')
(out/'NATIVE-RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(0 if r['status']=='NATIVE_OWNERS_RESOLVE_PASS' else 1)
