from pathlib import Path
import os, subprocess, json, datetime, shutil, re

repo = Path('/tmp/jail-picture-c6')
app = repo / 'chicago/4d'
out = Path('/workspace/T2382-currentdev-integration-20261026/finisher373-full3')
out.mkdir()
os.sched_setaffinity(0, {0, 1, 4})
env = dict(os.environ)
for key in ['GIT_NO_LAZY_FETCH', 'CHICAGO_TICKETS_DIR']:
    env.pop(key, None)
env.update(CHECK_JOBS='3', C4D_GATE_REQUIRE_READERS='1',
           C4D_GATE_REQUIRE_BASE='1', GITHUB_BASE_REF='dev',
           C4D_RULINGS_BASE='373851d158a7b6fc701b9cae1a651aa4b3823f97',
           TMPDIR='/tmp/carpenter-finisher373-check-tmp',
           OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1',
           MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1')
Path(env['TMPDIR']).mkdir(exist_ok=True)
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', *args], cwd=repo, env=env).decode().strip()
def save(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n')
assert json.loads((out.parent/'normal-dev373-integration/CLOSED-READY-FOR-FULL3.json').read_text())['status'] == 'PASS'
assert not git('ls-files', '-u')
assert not git('diff', '--name-only')
assert not git('ls-files', '--others', '--exclude-standard')
head, incoming, tree = [git('rev-parse', 'HEAD'), git('rev-parse', 'MERGE_HEAD'), git('write-tree')]
assert head == 'f311c2a9b7628e22835973933c9de41b83a2b531'
assert incoming == '373851d158a7b6fc701b9cae1a651aa4b3823f97'
assert tree == json.loads((out.parent/'normal-dev373-integration/CLOSED-READY-FOR-FULL3.json').read_text())['tree']
base = git('rev-parse', 'origin/dev')
remote = subprocess.check_output(['gh', 'api', 'repos/kevinrhaas/chicago/git/ref/heads/dev', '--jq', '.object.sha'], env=env).decode().strip()
assert base == remote
free = shutil.disk_usage(env['TMPDIR']).free
assert free >= 1000000000
binding = dict(at=now(), head=head, merge_head=incoming, staged_tree=tree,
               actual_dev=base, freshly_read_remote_dev=remote,
               actual_merge_base=git('merge-base', base, 'HEAD'),
               checked_Jail_delta_tree='897824de45d16cd90fe2400cd3b8aace341d42ea',
               actual_checked_Jail_commit='bbbe518720601b785e79628bf247ee4b9f9d4ed8',
               affinity=[0, 1, 4], CHECK_JOBS=3, tmp_free_bytes=free,
               orchestration_startup_floor_bytes=1000000000,
               native_resource_guards_unchanged=True,
               scope='Actual three native preflight questions for normalcurrent373 integration plus existing picturedruling canonicalID correction. Earlier f311 full3 is not relabelled. Final upstream attachments require fresh source/tree qualification.')
save('BINDING.json', binding)
print(json.dumps(binding), flush=True)
steps=[]
for name, cmd in [
    ('1-wholecheck', ['bash', 'tools/check.sh']),
    ('2-changelog', ['node', 'tools/check-changelog-entry.mjs', binding['actual_merge_base'], 'HEAD']),
    ('3-ids', ['node', 'tools/resolve_id_collisions.mjs', '--base', base, '--check'])]:
    started = now()
    print('START', name, started, flush=True)
    with (out/(name+'.log')).open('x') as log:
        process = subprocess.run(cmd, cwd=app, env=env, stdout=log, stderr=subprocess.STDOUT)
    steps.append(dict(name=name, command=cmd, started=started, finished=now(), exit=process.returncode))
    save('STEPS.json', steps)
    print('CLOSED', name, process.returncode, now(), flush=True)
guards = dict(head=git('rev-parse','HEAD')==head,
              incoming=git('rev-parse','MERGE_HEAD')==incoming,
              staged_tree=git('write-tree')==tree,
              working_bytes=not git('diff','--name-only'),
              no_untracked=not git('ls-files','--others','--exclude-standard'))
log=re.sub(r'\x1b\[[0-9;]*m', '', (out/'1-wholecheck.log').read_text(errors='replace'))
footer=bool(re.search(r'^CHECK PASS — \d+ steps, none red\.$', log, re.M))
passed=all(step['exit']==0 for step in steps) and all(guards.values()) and footer
result=dict(status='ALL3_NATIVE_PREFLIGHT_PASS' if passed else 'ACTUAL_PREFLIGHT_FAIL_RETAINED',
            at=now(), binding=binding, steps=steps, guards=guards,
            native_footer=log.strip().splitlines()[-4:],
            pending='Actual published bothviewport single-picture card review, normal checked mergecommit and ending checks, public push/hosted qualification plus upstream endings before expectedheadDEV merge. PRalreadyREADY; originalT2382 remainsDIFFERS.')
save('RESULT.json', result)
print(json.dumps(result, indent=2), flush=True)
raise SystemExit(0 if passed else 1)
