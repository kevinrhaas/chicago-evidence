import {readFileSync,writeFileSync}from'node:fs';
import {loadSamples}from'./load-samples.mjs';
import {buildingBodyBounds}from'./candidate/renderers/web/js/building-body-bounds.js';
const app=new URL('./inputs/project',import.meta.url).pathname;
const sidecar=JSON.parse(readFileSync(app+'/data/sidecars/1835/wolf_point_tavern.json'));
const out={};
for(const kind of ['gltf','web']){
 const {samples,quantStep}=await loadSamples(app+'/assets/'+kind+'/wolf_point_tavern__log_frame_1828.glb');
 const result=buildingBodyBounds(sidecar,samples,quantStep);
 const min=[0,1,2].map(k=>Math.min(...samples.map(s=>s.point[k]))),max=[0,1,2].map(k=>Math.max(...samples.map(s=>s.point[k])));
 out[kind]={result,fullSize:max.map((x,i)=>x-min[i]),roles:[...new Set(samples.map(s=>s.role))]};
}
console.log(JSON.stringify(out,null,2));writeFileSync(new URL('actual-cpu-probe.json',import.meta.url),JSON.stringify(out,null,2)+'\n');
