#!/usr/bin/env python3
"""Exact source preimages; optional already-reviewed wording-v2 smoke preimage."""
from pathlib import Path
import argparse,hashlib,json,os
p=argparse.ArgumentParser();p.add_argument('project_root',type=Path);p.add_argument('--apply',action='store_true');a=p.parse_args()
packet=Path(__file__).resolve().parent; guards=json.loads((packet/'replacement-guards.json').read_text());pending=[];receipt=[]
wording_sha='2f0bb1af8d7703bde55e06cc58161ea06b32f6df3b89595725158a577d496fab'
for rel,g in guards.items():
 target=a.project_root/rel;candidate=packet/'candidate'/rel
 if hashlib.sha256(candidate.read_bytes()).hexdigest()!=g['after_sha256']:raise SystemExit('REFUSED changed candidate: '+rel)
 if g['before_sha256'] is None:
  if target.exists():raise SystemExit('REFUSED new helper already exists')
  data=candidate.read_bytes();actual=None
 else:
  old=target.read_bytes();actual=hashlib.sha256(old).hexdigest();allowed=[g['before_sha256']]
  if rel=='tools/smoke_renderer.mjs':allowed.append(wording_sha)
  if actual not in allowed:raise SystemExit('REFUSED changed/unknown preimage: '+rel)
  text=old.decode()
  for span in g['spans']:
   if text.count(span['before'])!=1:raise SystemExit('REFUSED missing/duplicate guarded span: '+rel)
   text=text.replace(span['before'],span['after'],1)
  data=text.encode()
  if actual==g['before_sha256'] and hashlib.sha256(data).hexdigest()!=g['after_sha256']:raise SystemExit('REFUSED output differs from frozen candidate: '+rel)
 receipt.append({'path':rel,'before_sha256':actual,'after_sha256':hashlib.sha256(data).hexdigest()});pending.append((target,data))
if a.apply:
 for target,data in pending:
  target.parent.mkdir(parents=True,exist_ok=True);temp=target.with_name(target.name+'.body-diagnostic.tmp')
  with temp.open('xb')as f:f.write(data)
  if target.exists():os.chmod(temp,target.stat().st_mode)
  os.replace(temp,target)
print(json.dumps({'status':'APPLIED'if a.apply else'PASS_READONLY_PREFLIGHT','files':receipt},indent=2))
