import {readFileSync} from 'node:fs';
import {MeshoptDecoder} from './inputs/meshopt_decoder.module.mjs';
export async function loadSamples(path){
 const bytes=readFileSync(path),len=bytes.readUInt32LE(12),json=JSON.parse(bytes.subarray(20,20+len)),bin=bytes.subarray(28+len);
 await MeshoptDecoder.ready;
 const views=json.bufferViews.map(v=>{const e=v.extensions?.EXT_meshopt_compression;if(!e)return bin.subarray(v.byteOffset||0,(v.byteOffset||0)+v.byteLength);const out=new Uint8Array(e.count*e.byteStride);MeshoptDecoder.decodeGltfBuffer(out,e.count,e.byteStride,bin.subarray(e.byteOffset,e.byteOffset+e.byteLength),e.mode,e.filter);return out;});
 const samples=[];
 for(const node of json.nodes){if(node.mesh==null)continue;if(node.rotation||node.matrix)throw Error('CPU fixture expects actual translation/uniform-scale nodes only');const t=node.translation||[0,0,0],s=node.scale||[1,1,1];
  for(const primitive of json.meshes[node.mesh].primitives){const a=json.accessors[primitive.attributes.POSITION],v=json.bufferViews[a.bufferView],data=views[a.bufferView],d=new DataView(data.buffer,data.byteOffset,data.byteLength);const n=a.componentType===5126?4:2,stride=v.byteStride||n*3,role=json.materials[primitive.material].name;
   for(let i=0;i<a.count;i++){const point=[];for(let k=0;k<3;k++){let x=a.componentType===5126?d.getFloat32((a.byteOffset||0)+i*stride+k*n,true):d.getInt16((a.byteOffset||0)+i*stride+k*n,true);if(a.normalized)x=Math.max(-1,x/32767);point.push(Math.fround(x*s[k]+t[k]));}samples.push({point,role});}
  }
 }
 const scale=Math.max(...samples.flatMap(s=>s.point.map(Math.abs))),quantStep=scale/32767;
 for(const s of samples)s.point=s.point.map(x=>Math.max(-32767,Math.min(32767,Math.round(x*32767/scale)))/32767*scale);
 return {samples,quantStep};
}
