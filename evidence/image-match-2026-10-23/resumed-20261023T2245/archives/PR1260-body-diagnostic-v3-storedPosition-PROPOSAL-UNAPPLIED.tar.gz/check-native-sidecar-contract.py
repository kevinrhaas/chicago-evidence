#!/usr/bin/env python3
"""Run the unchanged real native sidecar scanner against a temporary renderer overlay."""
from pathlib import Path
import sys,hashlib,json,tempfile,shutil
sys.dont_write_bytecode=True
packet=Path(__file__).resolve().parent;root=Path('/tmp/chicago-log-integration/chicago/4d')
sys.path.insert(0,str(root/'tools'))
import validate as V
shape=V.sidecar_shape();validator_hash=hashlib.sha256((root/'tools/validate.py').read_bytes()).hexdigest()
rows=[]
with tempfile.TemporaryDirectory(prefix='body-contract-',dir='/tmp')as temp:
 fixture=Path(temp)
 for source in sorted((root/'renderers').rglob('*.js')):
  if 'vendor'in source.parts:continue
  rel=source.relative_to(root);target=fixture/rel;target.parent.mkdir(parents=True,exist_ok=True)
  candidate=packet/'candidate'/rel;data=candidate.read_bytes()if candidate.exists()else source.read_bytes();target.write_bytes(data)
  rows.append({'path':str(rel),'sha256':hashlib.sha256(data).hexdigest()})
 V.ROOT=fixture
 # Freeze the exact real union once; no altered field allowances or scanner logic.
 V.sidecar_shape=lambda:shape
 positive=V.Report();V.check_sidecar_contract(positive);assert not positive.errors,positive.errors
 # The precise v2 alias collision must continue to be caught by the same scanner.
 buildings=fixture/'renderers/web/js/buildings.js';buildings.write_bytes((Path('/tmp/PR1260-wall-body-diagnostic-proposal-v2')/'candidate/renderers/web/js/buildings.js').read_bytes())
 old=V.Report();V.check_sidecar_contract(old)
 assert all(any('placement.'+key in e for e in old.errors)for key in ['count','getX','getY','getZ']),old.errors
 buildings.write_bytes((packet/'candidate/renderers/web/js/buildings.js').read_bytes())
 broken=fixture/'renderers/web/js/negative-body-contract.js';broken.write_text('const side = record.sidecar; const p = side.placement; p.not_a_compiled_field;\n')
 negative=V.Report();V.check_sidecar_contract(negative);assert any('placement.not_a_compiled_field'in e for e in negative.errors),negative.errors
report={'status':'PASS','scope':'unchanged native check_sidecar_contract only; temporary renderer overlay; no dataset/native writers/fullgate','validator_sha256':validator_hash,'shape_sha256':hashlib.sha256(json.dumps(shape,sort_keys=True).encode()).hexdigest(),'positive_errors':positive.errors,'positive_notes':positive.notes,'old_v2_alias_errors':old.errors,'negative_guard_errors':negative.errors,'renderers':rows}
(packet/'native-sidecar-contract.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS: proposed renderer sidecar contract; old v2 four aliases still fail; invented placement field still fails')
