import {readFileSync,writeFileSync}from'node:fs';
import assert from'node:assert/strict';
import {loadSamples}from'./load-samples.mjs';
import {buildingBodyBounds}from'./candidate/renderers/web/js/building-body-bounds.js';
const app=new URL('./inputs/project',import.meta.url).pathname;
const sidecar=JSON.parse(readFileSync(app+'/data/sidecars/1835/wolf_point_tavern.json'));
const {samples,quantStep}=await loadSamples(app+'/assets/web/wolf_point_tavern__log_frame_1828.glb');
const clone=x=>JSON.parse(JSON.stringify(x));
const wall=sidecar.attributes.wall_height_m.value;
const pass=(s,points=samples,q=quantStep)=>{const b=buildingBodyBounds(s,points,q);return !!b?.valid && b.size[1]>=wall*.9 && b.size[1]<=wall*2.6+3;};
const cases=[];const check=(name,result)=>{assert(result,name);cases.push(name);};
const immutable=JSON.stringify({sidecar,samples});
check('actual decoded/requantized web with declared pole passes body gate',pass(sidecar));
check('diagnostic mutates no input sample/declaration',immutable===JSON.stringify({sidecar,samples}));
const fullHeight=Math.max(...samples.map(s=>s.point[1]))-Math.min(...samples.map(s=>s.point[1]));
check('old full height fails unchanged wall threshold',fullHeight>wall*2.6+3);
const undeclared=clone(sidecar);delete undeclared.attributes.sign_pole_set_out;
check('no declaration returns null; full bounds remain applicable',buildingBodyBounds(undeclared,samples,quantStep)===null);
check('undeclared tall appendage still fails original wall guard',!(fullHeight>=wall*.9&&fullHeight<=wall*2.6+3));
const isPole=s=>(s.role==='log' && s.point[0]>5.2 && -s.point[2]>5.2) || ['sign','paint'].includes(s.role) || (s.role==='dark'&&s.point[1]>7);
const remap=fn=>samples.map(s=>({role:s.role,point:fn(s)}));
check('body collapsed vertically with original valid pole fails',!pass(sidecar,remap(s=>isPole(s)?s.point:s.point.map((v,i)=>i===1?v*.1:v))));
check('body uniformly clamped to 2m with original valid pole fails',!pass(sidecar,remap(s=>isPole(s)?s.point:s.point.map(v=>Math.max(-1,Math.min(1,v))))));
check('inflated occupied walls with original valid pole fail',!pass(sidecar,remap(s=>isPole(s)?s.point:s.point.map((v,i)=>i===1?v*4:v))));
check('missing body with valid sign samples fails',!pass(sidecar,samples.filter(isPole)));
check('taller undeclared extension fails',!pass(sidecar,[...samples,{role:'log',point:[6.45,15,-6]}]));
check('oversized lower shaft fails even below roof height',!pass(sidecar,[...samples,{role:'log',point:[6.2,1,-7.3]}]));
check('oversized board fails even when below original height cap',!pass(sidecar,[...samples,{role:'sign',point:[6.5,5,-7]}]));
const tooTall=clone(sidecar);tooTall.attributes.sign_pole_set_out.value.head_xyz[2]=15;
check('oversized declared pole refused',!pass(tooTall));
const malformed=clone(sidecar);malformed.attributes.sign_pole_set_out.value.board_wh=[1.6,NaN];
check('malformed declaration refused',!pass(malformed));
check('unknown material names do not exempt high geometry',!pass(sidecar,samples.map(s=>({...s,role:'unknown'}))));
check('coarse dropped-dequantization precision refused',!pass(sidecar,samples,.1));
const spans=JSON.parse(readFileSync(new URL('replacement-guards.json',import.meta.url)));
for(const rel of ['renderers/web/js/buildings.js','tools/smoke_renderer.mjs']){
 let after=readFileSync(new URL('candidate/'+rel,import.meta.url),'utf8');
 for(const g of [...spans[rel].spans].reverse()){assert.equal(after.split(g.after).length-1,1);after=after.replace(g.after,g.before);}
 check(`${rel}: all bytes outside explicit guarded hunks unchanged`,after===readFileSync(new URL('before/'+rel,import.meta.url),'utf8'));
}
// Exercise the actual candidate smoke predicate, not merely the helper result.
const smokeSource=readFileSync(new URL('candidate/tools/smoke_renderer.mjs',import.meta.url),'utf8');
const filterSource=smokeSource.match(/const claimed = scale\.perStructure\.filter\((.*?)\);/s)?.[1];
assert(filterSource);
const isClaimed=new Function(`return (${filterSource});`)();
const offSource=smokeSource.match(/const offClaim = claimed\.filter\(\(s\) => \{([\s\S]*?)\n    \}\);/)?.[1];
assert(offSource);
const isOff=new Function('s',offSource);
for(const [name,value] of [['missing',undefined],['numeric string','2.6'],['false',false],['NaN',NaN],['Infinity',Infinity]]){
 const doc=clone(sidecar);
 if(value===undefined)delete doc.attributes.wall_height_m;else doc.attributes.wall_height_m.value=value;
 const body=buildingBodyBounds(doc,samples,quantStep);
 const row={declaredAppendage:true,wallHeight:value,body,size:[7.44,fullHeight,10.34]};
 check(`smoke keeps declared sign with ${name} wall height`,isClaimed(row));
 check(`smoke refuses declared sign with ${name} wall height`,isOff(row) && !body.valid);
}
for(const h of [0,1,2.6,10,NaN,Infinity])check(`old numeric claim inclusion preserved (${h})`,isClaimed({wallHeight:h,declaredAppendage:false}));
for(const h of [undefined,'2.6',false])check(`unrelated nonnumeric unclaimed row preserved (${h})`,!isClaimed({wallHeight:h,declaredAppendage:false}));
check('actual numeric declared body still passes smoke',!isOff({declaredAppendage:true,wallHeight:wall,body:buildingBodyBounds(sidecar,samples,quantStep),size:[7.44,fullHeight,10.34]}));

const body=buildingBodyBounds(sidecar,samples,quantStep);
writeFileSync(new URL('cpu-checks.json',import.meta.url),JSON.stringify({status:'PASS',tests:cases,actual_full_height_m:fullHeight,wall_threshold_m:wall*2.6+3,actual_body:body,scope:'CPU glTF meshopt decoding + normalized local transform + Float32 + batch Int16 quantization; no browser/native/fullgate'},null,2)+'\n');
console.log(`PASS ${cases.length} controls; full${fullHeight.toFixed(6)}m, body${body.size[1].toFixed(6)}m; threshold${(wall*2.6+3).toFixed(2)}m unchanged`);
