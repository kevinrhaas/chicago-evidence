from pathlib import Path
import json,os,subprocess,hashlib,datetime
R=Path('/workspace/chicago');A=R/'chicago/4d';T=Path('/workspace/isolated-gt-ticket-renewal-native-v4-20261029/repo');O=Path('/workspace/T2382-official-claim-school-agent-v3-20261029');O.mkdir()
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1',CHICAGO_TICKETS_DIR=str(T))
g=lambda root,*a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=root,env=E,text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return {'HEAD':g(R,'rev-parse','HEAD'),'index':sha(R/'.git/index'),'status':g(R,'status','--porcelain=v1'),'refs':g(R,'show-ref')}
before=snap();theadt=g(T,'rev-parse','HEAD');assert theadt=='b92d033c528e40d0896d7304027443dcf24ed8c2';assert not g(T,'status','--porcelain=v1')
files={str(p.relative_to(T)):sha(p)for p in T.glob('T-*/T-*.md')};assert len(files)>3000
(O/'BEFORE.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':before,'tickets_head':theadt,'all_ticket_files':files},indent=2)+'\n')
cmd=['python3','/workspace/shared/run-with-reaping.py',str(O/'NATIVE-CLAIM-REAPER.json'),'--','node','tools/ticket.mjs','claim','T-2382','--by','Codex Carpenter picture match 2026-10-29']
with(O/'NATIVE-CLAIM.log').open('x')as f:q=subprocess.run(cmd,cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
(O/'EXIT.json').write_text(json.dumps({'exit':q.returncode,'command':cmd},indent=2)+'\n');print('nativeclaimexit',q.returncode);assert q.returncode==0
reaper=json.loads((O/'NATIVE-CLAIM-REAPER.json').read_text());assert reaper['all_children_reaped'];after=snap();assert before==after,'No primarytrackedsource/index/refs allowed'
changed=[p for p,h in files.items()if sha(T/p)!=h];assert len(changed)==1 and '/T-2382-'in changed[0],changed
head=g(T,'rev-parse','HEAD');(O/'AFTER.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':after,'tickets_head':head,'changed_original_ticket_files':changed,'all_other_ticket_files_exact':True,'allchildrenreaped':True,'remote_readback_pending':True},indent=2)+'\n');print(head,changed)
