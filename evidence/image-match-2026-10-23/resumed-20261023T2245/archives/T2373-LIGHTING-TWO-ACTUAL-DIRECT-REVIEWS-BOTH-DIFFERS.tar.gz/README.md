# Exact8021 lighthouse directional-overcast A/B — actual review

Both fresh native captures exited0, full frozen input guards passed, and source/both complete comparisons/both raw renders/original tower detail were directly viewed. Both remain **DIFFERS**. Moving only the neutral overcast key toward the left/front visibly brightens that shaft face while the right remains nearly unchanged. This improves broad lighting direction, but does not resolve the uniformly dark crown, regular cage/rail, literal muted masonry, crisp apertures, provisional camera or missing keeper-house/shore/steps context. No geometry or material was changed and no accepted camera/appearance claim follows.

The first attempt failed before any capture because Chromium's Unix socket path exceeded its length limit. That full failure is retained. The new immutable v2 launcher changed only the runtime temporary path; original120adb inputs/cameras/native code remain exact. Two actual captures then succeeded, rawPNG files were copied from the owned short temporary directory into the run and that short directory removed. No browser profiles or crash dumps remain in the selected run. All launcher children closed; root/resume_tremont were notified LOCALCLEAR, without granting another lane.

Actual run: /workspace/T2373-8021-lighting-runs/20261024T152428-562158Z
Preserved zero-capture failure: /workspace/T2373-8021-lighting-runs/20261024T152242-579481Z

Open reviews/overcast-baseline/camera-side-by-side.jpg and reviews/directional-overcast/camera-side-by-side.jpg beneath the actual run. The standalone raw renders are tmp/photo-match-GsT3EG/camera-render.png and tmp/photo-match-cN8mna/camera-render.png respectively. Identical source halves were verified; pixel-box statistics are explanatory, not source-fit scores. The native raw match records remain unreviewed as issued; this separate research review records DIFFERS without mutating them or their output manifest.

Next action belongs to root after independent viewing. No third trial, local crown material increment, shared producer adoption or fullfort-family bake was performed/authorized by this review. Original T2373 stays OPEN, all other source limits remain, and actual visible geometry adoption is still owed.
