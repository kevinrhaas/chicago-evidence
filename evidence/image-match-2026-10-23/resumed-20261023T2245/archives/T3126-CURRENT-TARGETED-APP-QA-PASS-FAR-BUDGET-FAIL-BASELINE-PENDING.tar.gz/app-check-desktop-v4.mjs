// Actual published Dearborn scene/card review. No content or API is injected.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire('/workspace/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const root='/tmp/hogan-pr1229-integration/site';
const out=path.resolve(new URL('./app-qa-desktop-v4/',import.meta.url).pathname);
fs.mkdirSync(out,{recursive:true});
const write=(name,v)=>fs.writeFileSync(path.join(out,name),typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon'};
const serverErrors=[];
const server=http.createServer((req,res)=>{
 try{
  let file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
  if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
  if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
  if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
  res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');
  const stream=fs.createReadStream(file);stream.on('error',e=>{serverErrors.push(e.message);res.destroy(e);});stream.pipe(res);
 }catch(e){serverErrors.push(e.message);res.writeHead(500).end();}
});
let browser;
const results=[];
const expected=JSON.parse(fs.readFileSync(new URL('./app-expected.json',import.meta.url),'utf8'));
async function settle(page){await page.locator('.navigator').evaluate(async n=>{getComputedStyle(n).width;await Promise.all(n.getAnimations().filter(a=>Number.isFinite(a.effect.getComputedTiming().endTime)).map(a=>a.finished));});}
async function pane(page,key){
 await page.locator(`#nav-app-inspect [data-insp-tab="${key}"]`).click();
 await page.waitForFunction(k=>document.querySelector(`#nav-app-inspect [data-insp-pane="${k}"]`)?.dataset.filled==='yes',key,{timeout:45000});
 await settle(page);
 return page.locator(`#nav-app-inspect [data-insp-pane="${key}"]`);
}
async function observe(page,target,label,key){
 const v=await target.evaluate(p=>({text:p.innerText,links:[...p.querySelectorAll('a')].filter(a=>a.checkVisibility()).map(a=>a.href),visible:p.checkVisibility(),pageOverflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1}));
 write(`${label}-${key}.json`,v);assert(v.visible);assert.equal(v.pageOverflow,false);assert.equal(v.paneOverflow,false);
 await page.screenshot({path:path.join(out,`${label}-${key}.png`)});return v;
}
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 for(const [label,width,height,touch] of [['desktop',1280,800,false]]){
  const context=await browser.newContext({viewport:{width,height},hasTouch:touch,deviceScaleFactor:touch?2:1});
  const errors=[],network=[];let page;
  try{
   await context.addInitScript(()=>localStorage.setItem('chicago4d.researcher','on'));
   page=await context.newPage();page.setDefaultTimeout(90000);
   page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});});page.on('requestfailed',r=>network.push({url:r.url(),failure:r.failure()}));
   const response=await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835&keep-geometry=1`);assert.equal(response.status(),200);
   await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:240000,polling:1000});
   await page.evaluate(async()=>{const a=window.__chicago4d,until=Date.now()+90000;while(a.welcome?.state!=='world'&&Date.now()<until){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}if(a.welcome&&a.welcome.state!=='world')throw Error('welcome did not enter world');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();a.setAnimationHold(true);a.navigator.dock();assertFrame();function assertFrame(){if(!a.frame('dearborn_street_drawbridge'))throw Error('Dearborn cannot frame');}await a.capture(1);});
   const data=await page.evaluate(()=>{const a=window.__chicago4d,s=a.registry.get('dearborn_street_drawbridge')?.sidecar;return {grade:s?.grade,attributes:s?.attributes,phase:s?.phase,placement:s?.placement,bounds:a.buildings.instanceBounds()['dearborn_street_drawbridge'],problems:a.problems??[],expectedReviews:[...a.registry.values()].filter(r=>r.sidecar?.review_required).map(r=>r.sidecar.id).sort(),scene:a.scene?.id};});
   write(`${label}-diagnostic.json`,{data,errors,network});assert.equal(data.scene,'1835');assert.equal(data.phase,expected.phase);assert.deepEqual(data.grade,expected.grade);
   assert.equal(data.attributes.railing_kind.value,'board');assert.equal(data.attributes.railing_kind.confidence,'inferred');
   assert.deepEqual(data.attributes.railing_kind.sources,['andreas_1884_dearborn_drawbridge_plate']);
   for(const [key,attr] of Object.entries(expected.attributes)){
    assert.deepEqual(data.attributes[key]?.value,attr.value,key+' value');
    assert.equal(data.attributes[key]?.confidence,attr.confidence,key+' confidence');
   }
   for(const [key,value] of Object.entries(expected.placement))assert.equal(data.placement[key],value,'placement '+key);
   assert(data.bounds?.size?.every(v=>Number.isFinite(v)&&v>0));
   assert.deepEqual(data.problems.filter(p=>/review_required is set/.test(p)).map(p=>p.split(':',1)[0]).sort(),data.expectedReviews);
   const unexpected=data.problems.filter(p=>!/provisional|PLACEHOLDER|placeholder|review_required is set/i.test(p));assert.deepEqual(unexpected,[]);
   await settle(page);
   const poses=[];
   for(const kind of ['full','boards']){
    const pose=await page.evaluate(async kind=>{
     const a=window.__chicago4d,s=a.registry.get('dearborn_street_drawbridge').sidecar,p=s.placement,b=a.buildings.instanceBounds()['dearborn_street_drawbridge'];
     const t=p.rotation_deg*Math.PI/180,poly=s.footprint.polygon;
     const loU=Math.min(...poly.map(v=>v[0])),hiU=Math.max(...poly.map(v=>v[0])),loV=Math.min(...poly.map(v=>v[1])),hiV=Math.max(...poly.map(v=>v[1])),span=hiU-loU,midV=(loV+hiV)/2;
     const world=(u,v)=>({e:p.local_e+u*Math.cos(t)+v*Math.sin(t),n:p.local_n-u*Math.sin(t)+v*Math.cos(t)});
     const aim=kind==='full'?{...world((loU+hiU)/2,midV),y:(b.min[1]+b.max[1])/2}:{...world(loU+span*.34,loV),y:p.walk_surface_m+.45};
     a.setFly(true);let result;
     for(let scale=1;scale<=3;scale+=.25){
      const localEye=kind==='full'?{u:loU+span*(.5+.12*scale),v:midV-span*.8*scale,y:45*scale}:{u:loU+span*.34-8,v:loV-9,y:6};
      const eye=world(localEye.u,localEye.v),distance=Math.hypot(aim.e-eye.e,aim.n-eye.n),yaw=Math.atan2(aim.e-eye.e,aim.n-eye.n)*180/Math.PI,pitch=Math.atan2(aim.y-localEye.y,distance)*180/Math.PI;
      const surface=a.walker.surfaceAt(eye.e,eye.n);
      a.walker.teleport({local_e:eye.e,local_n:eye.n,yaw_deg:yaw,pitch_deg:pitch,altitude_m:localEye.y-surface});await a.capture(1);
      const corners=[];for(const u of [b.min[0],b.max[0]])for(const v of [-b.max[2],-b.min[2]])for(const y of [b.min[1],b.max[1]]){const w=world(u,v);corners.push({u,v,y,...a.project(w.e,w.n,y)});}
      result={kind,eye:{...eye,y:localEye.y},aim,yaw,pitch,state:{...a.walker.state},bounds:b,corners,scale,liveFly:{walker:a.walker.state.flying,hud:a.hud.flying,intent:a.intent.flying},frozenApiFlyAlias:a.flying};
      if(kind!=='full'||corners.every(c=>Math.abs(c.x)<.88&&Math.abs(c.y)<.88&&c.z>-1&&c.z<1))break;
     }
     if(!a.walker.state.flying||!a.hud.flying||!a.intent.flying)throw Error('live walker/HUD/intent Fly did not persist');
     if(kind==='full'&&!result.corners.every(c=>Math.abs(c.x)<.88&&Math.abs(c.y)<.88&&c.z>-1&&c.z<1))throw Error('full bridge bounds outside camera');
     return result;
    },kind);poses.push(pose);write(`${label}-${kind}-pose.json`,pose);
    for(const [view,on] of [['normal',false],['confidence',true]]){
     await page.evaluate(async on=>{const a=window.__chicago4d;a.setConfidenceView(on);await a.capture(1);},on);
     await page.screenshot({path:path.join(out,`${label}-${kind}-${view}.png`)});
     const stats=await page.evaluate(()=>({...window.__chicago4d.stats(),confidenceView:window.__chicago4d.confidenceView,flying:window.__chicago4d.walker.state.flying,hudFlying:window.__chicago4d.hud.flying,intentFlying:window.__chicago4d.intent.flying}));assert.equal(stats.confidenceView,on);assert.equal(stats.flying,true);assert.equal(stats.hudFlying,true);assert.equal(stats.intentFlying,true);write(`${label}-${kind}-${view}-stats.json`,stats);assert(stats.withinBudget,`${label}/${kind}/${view} within unchanged native budgets`);
    }
   }
   await page.evaluate(async()=>{const a=window.__chicago4d;a.setConfidenceView(false);a.pick('dearborn_street_drawbridge');await a.navigator.select('inspect');a.navigator.open(2);});
   await page.waitForFunction(()=>document.querySelector('#nav-app-inspect')?.dataset.structure==='dearborn_street_drawbridge',null,{timeout:30000});
   const photosPane=await pane(page,'photos');await photosPane.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});
   const photos=await observe(page,photosPane,label,'photos');assert.match(photos.text,/Braunhold/i);assert(photos.links.some(h=>/historyofchicago01andr/.test(h)));
   const sourcesPane=await pane(page,'sources');await sourcesPane.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});
   const sources=await observe(page,sourcesPane,label,'sources');assert.match(sources.text,/Braunhold/i);assert.match(sources.text,/Andreas/i);
   const credit=sourcesPane.locator('.cite-text').filter({hasText:'Braunhold'}).first();assert(await credit.count());
   await credit.evaluate(el=>el.scrollIntoView({block:'end'}));
   const visibleCredit=await credit.evaluate(el=>{const text=el.firstChild,from=text.textContent.indexOf('Drawing signed');if(from<0)throw Error('signature clause missing');const range=document.createRange();range.setStart(text,from);range.setEnd(text,text.length);const rect=range.getBoundingClientRect();let parent=el.parentElement;while(parent&&!(parent.scrollHeight>parent.clientHeight+1&&/(auto|scroll)/.test(getComputedStyle(parent).overflowY)))parent=parent.parentElement;const clip=parent?.getBoundingClientRect();return {text:range.toString(),rect:{top:rect.top,bottom:rect.bottom,left:rect.left,right:rect.right},clip:clip?{top:clip.top,bottom:clip.bottom}:null};});
   assert.match(visibleCredit.text,/L\. Braunhold, del\./);assert(visibleCredit.rect.top>=Math.max(0,visibleCredit.clip?.top??0)-2);assert(visibleCredit.rect.bottom<=Math.min(height,visibleCredit.clip?.bottom??height)+2);assert(visibleCredit.rect.left>=-2&&visibleCredit.rect.right<=width+2);
   write(`${label}-visible-credit-range.json`,visibleCredit);
   await page.screenshot({path:path.join(out,`${label}-source-credit.png`)});
   assert.match(sources.text,/Dearborn's boarded parapets/i);
   const liberty=sourcesPane.locator('.src-lib').filter({hasText:"Dearborn's boarded parapets"});assert.equal(await liberty.count(),1);
   await liberty.locator(':scope > summary').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(out,`${label}-building-liberty.png`)});
   write(`${label}-building-liberty.json`,{visible:await liberty.isVisible(),text:await liberty.innerText()});
   assert.deepEqual(errors,[]);assert.deepEqual(network,[]);assert.deepEqual(serverErrors,[]);
   const contacts=await page.evaluate(()=>{
    const a=window.__chicago4d,s=a.registry.get('dearborn_street_drawbridge').sidecar,p=s.placement;a.setFly(false);
    const angle=p.rotation_deg*Math.PI/180,poly=s.footprint.polygon;
    const us=poly.map(v=>v[0]),vs=poly.map(v=>v[1]),lo=Math.min(...us),span=Math.max(...us)-lo,v=(Math.min(...vs)+Math.max(...vs))/2;
    const samples=[];
    for(const fraction of [.25,.5,.75]){
     const u=lo+span*fraction,e=p.local_e+u*Math.cos(angle)+v*Math.sin(angle),n=p.local_n-u*Math.sin(angle)+v*Math.cos(angle);
     const surface=a.walker.surfaceAt(e,n),routed=a.router.heightAt(e,n),blocked=a.router.blockedAt(e,n);
     a.walker.teleport({local_e:e,local_n:n,yaw_deg:0,pitch_deg:0});
     samples.push({fraction,e,n,water:a.terrain.isWater(e,n),surface,routed,blocked,ground:a.walker.state.groundY,eye:a.walker.state.eyeY,actualE:a.walker.state.e,actualN:a.walker.state.n,expectedDeck:p.walk_surface_m,flying:a.walker.state.flying,hudFlying:a.hud.flying,intentFlying:a.intent.flying});
    }
    return samples;
   });
   write(`${label}-deck-contacts.json`,contacts);
   for(const c of contacts){assert.equal(c.flying,false);assert.equal(c.hudFlying,false);assert.equal(c.intentFlying,false);assert(c.water);assert.equal(c.blocked,false);assert(Math.abs(c.surface-c.expectedDeck)<1e-6);assert(Math.abs(c.ground-c.expectedDeck)<1e-6);assert(Math.abs(c.routed-c.expectedDeck)<.02);assert(Number.isFinite(c.eye)&&c.eye>c.ground);assert(Math.hypot(c.actualE-c.e,c.actualN-c.n)<.01);}
   await page.evaluate(async()=>{const a=window.__chicago4d;a.navigator.dock();await a.capture(1);});await settle(page);
   await page.screenshot({path:path.join(out,`${label}-deck-contact.png`)});
   assert.deepEqual(errors,[]);assert.deepEqual(network,[]);assert.deepEqual(serverErrors,[]);
   const result={viewport:label,width,height,status:'PASS',errors,network,loaderUnexpected:unexpected,grade:data.grade,attributes:data.attributes,poses,contacts,photos,sources,limits:'Targeted actual published Dearborn normal/confidence/card QA; screenshots require visual review. Not full renderer smoke or accepted source-image match.'};
   results.push(result);write(`${label}-result.json`,result);console.log(`${label}: actual Dearborn scene/grade/attributes/Images/source credit PASS, zero page/network/unexpected loader errors`);
  }catch(e){write(`${label}-failure.json`,{message:e.message,stack:e.stack,errors,network});if(page)await page.screenshot({path:path.join(out,`${label}-failure.png`)}).catch(()=>{});throw e;}
  finally{await context.close();}
 }
 write('results.json',{status:'PASS',results,serverErrors});
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));server.closeAllConnections();}
