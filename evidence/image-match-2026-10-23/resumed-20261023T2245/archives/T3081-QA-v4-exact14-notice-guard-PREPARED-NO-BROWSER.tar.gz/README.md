# T-3081 QA v4 — exact retained-review notice semantics

V1–V3 and the first actual failed-v3 packet remain unchanged. V3's first mobile school case drew the correct published model, door, Photos and Sources with no page/network errors, but rejected every nonempty `a.problems`. The native smoke instead verifies that the reported review notices exactly agree with the registry's flags before distinguishing them from unexpected loader problems (`tools/smoke_renderer.mjs:1847–1863`).

Root authorized this external-only correction. V4 freezes the exact current14 record IDs and their exact legacy loader messages; the live registry-declared IDs and actual reported IDs/messages must each equal that set. Duplicated, missing, changed or new notices fail. Every other native problem fails, including any uncategorized finding. All raw messages remain in actual receipts. Page, HTTP, request and cleanup failures remain unfiltered. No geometry, entrance, credit, source-card, picture, budget or contact assertion changed.

The authoritative meaning is AGENTS.md:130–146, owner ruling2026-10-16: `review_required` and `touches_removal` flags and explanatory prose remain, but **“They do not block a scene from being marked released”**. The legacy phrase “this scene cannot be released” is recorded verbatim as historical runtime evidence. It does not create a consultation permission requirement or override the owner ruling. No flag or source data was changed. The earlier failed-v3 packet's references to “blockers” describe its old diagnostic, not a new approval condition.

LIGHT checks prove the baseline14 passes and missing/new/duplicate/changed notices or unknown problems fail. Authored-record guarded dry mode and JS/shell syntax pass. `models.json` retains v3's five records (including Cobweb5.05m head) and all existing doorway/camera/source/credit expectations; only scene-notice metadata is added. Sources/images are still the original frozen-v1 bytes. Nothing in this prepared packet is an actual browser result or an accepted image match.

Root's exclusive grant permits exactly ten actual published cases at PR1260 head `6bf9d0e91fef27dedb9d364132e290706dd27609`, after verifying the clean source and previously published6bf mirror. The prior normal publish exited0 and left source clean. The new durable orchestration owns that verification and will run:

```sh
TMPDIR=/workspace/tmp-t3081 PW_EXECUTABLE=/usr/bin/chromium bash /tmp/T3081-published-qa-v4-20261024/run-sequential.sh published --execute-after-root-grant /workspace/T3081-PR1260-published-qa-v4
```

Cases run sequentially and stop at any genuine app or unexpected assertion failure. Their output is separate from the preserved failed-v3 run. No photo comparison, Blender, full gate, source writer or second publisher is included. Photo comparisons require a separate grant. See v3/v2 READMEs for unchanged methods and source/camera limitations. Targeted application PASS never means an image matches or the full smoke gate passed.
