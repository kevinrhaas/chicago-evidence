"""Observe only the root-bound T3126 full18 jobs; never dispatch or mutate GitHub."""
import argparse,pathlib,json,datetime,subprocess,time,os,re
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--dispatch',required=True)
ap.add_argument('--head',required=True)
ap.add_argument('--pr',type=int,required=True)
ap.add_argument('--out',required=True)
a=ap.parse_args()
assert a.pr>0 and re.fullmatch('[0-9a-f]{40}',a.head)
d=json.loads(pathlib.Path(a.dispatch).read_text())
assert d['head']==a.head and d['PR']==a.pr and len(d['runs'])==18
assert len({r['id'] for r in d['runs']})==18
groups={'1-2','3-4','5','6-7','8','9-12','13','14','15'}
for viewport in ['desktop','mobile']:
    rows=[r for r in d['runs'] if r['viewport']==viewport]
    assert len(rows)==9 and {r['stage'] for r in rows}==groups
assert all(r.get('dispatch_accepted') and r.get('observed_head')==a.head for r in d['runs'])
out=pathlib.Path(a.out)
assert out.is_absolute() and str(out).startswith('/workspace/')
out.mkdir(exist_ok=False)
with (out/'ACTIVE_OBSERVER_LOCK.json').open('x') as f:
    json.dump({'pid':os.getpid(),'head':a.head,'PR':a.pr,'scope':'GET only'},f)
def now():return datetime.datetime.now(datetime.timezone.utc)
def state(phase,**extra):
    value={'pid':os.getpid(),'expected_head':a.head,'PR':a.pr,'phase':phase,'heartbeat_at':now().isoformat(),**extra}
    tmp=out/'WATCHER_STATE.tmp';tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(out/'WATCHER_STATE.json')
cmd=['python',str(pathlib.Path(__file__).parent/'watch_controller.py'),'--dispatch',a.dispatch,'--head',a.head,'--pr',str(a.pr),'--out',str(out),'--harvest']
last=None
while True:
    started=now();state('POLL_RUNNING',last_summary=last)
    q=subprocess.run(cmd,capture_output=True,text=True)
    stamp=started.strftime('%Y%m%dT%H%M%S%fZ')
    (out/('observer-output-'+stamp+'.json')).write_text(q.stdout)
    if q.stderr:(out/('observer-stderr-'+stamp+'.txt')).write_text(q.stderr)
    if q.returncode:
        event={'at':now().isoformat(),'status':'READ_ERROR_NOT_A_CI_VERDICT','exit':q.returncode,'stderr':q.stderr[-1200:]}
    else:
        try:
            last=json.loads(q.stdout)
            event={k:last.get(k) for k in ['at','counts','actual_terminal_log_count','actual_verified_successes','all_18_success','read_errors','log_read_errors','PR_head','expected_head_is_current_PR_head','dev','required_checks']}
            event['failed_runs']=[{k:r.get(k) for k in ['id','viewport','stage','conclusion']} for r in last.get('failed_runs',[])]
        except Exception as e:
            event={'at':now().isoformat(),'status':'UNREADABLE_OUTPUT_NOT_A_CI_VERDICT','error':str(e)}
    with (out/'EVENTS.jsonl').open('a') as f:f.write(json.dumps(event)+'\n')
    print(json.dumps(event),flush=True)
    if q.returncode==0 and last and last.get('actual_terminal_log_count')==18 and not last.get('read_errors') and not last.get('log_read_errors'):
        state('COMPLETE_18_TERMINAL_LOGS',completed_at=now().isoformat(),last_summary=last)
        break
    due=started+datetime.timedelta(seconds=300)
    while now()<due:
        state('WAITING',last_summary=last,next_poll_at=due.isoformat())
        time.sleep(min(45,max(0,(due-now()).total_seconds())))
