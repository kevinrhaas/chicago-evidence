ACTUAL BOTHVIEWPORT PR1260 stage3-4 failures at6bf.

Mobile137PASS1FAIL; desktop134PASS1FAIL; zero pageerrors both. Both exact6bfcheckout/requestedviewport/stage; both onlyreportedfailure Wolfwholebbox11m vswall2.6m. Read-only sourcehypothesis signpole10.96m included inwholeinstance envelope retained; noassertionchange/repair/acceptance. Rootinformed. Snapshot02:28 shows11success2failure5running,fullcoveragePENDING. No writers/lap/merge/dispatch/cancel/browser/heavyjobs bymonitor.
