"""Focused CPU/API parity proof; bpy object/material emission alone is stubbed."""
from pathlib import Path
import ast
import copy
import dataclasses
import hashlib
import importlib.util
import inspect
import json
import sys
import types

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
BASE = OUT / 'baseline/chicago/4d'
NEW = OUT / 'candidate/chicago/4d'
RENDERED = OUT / 'rendered-candidate'
inputs = json.loads((OUT / 'inputs.json').read_text())
sys.path.insert(0, str(BASE / 'generators'))
sys.modules.setdefault('bpy', types.ModuleType('bpy'))
from common import mesh

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def pair(tag, root):
    params = load(tag + '_params', root / 'generators/archetypes/bridge_timber_params.py')
    sys.modules['archetypes.bridge_timber_params'] = params
    builder = load(tag + '_builder', root / 'generators/archetypes/bridge_timber.py')
    class Raw(mesh.MeshBuilder):
        def to_object(self, mats=None):
            self.captured_materials = mats
            return self
    builder.MeshBuilder = Raw
    builder.simple_material = lambda name, *a, **kw: dict(name=name, args=a, kwargs=kw)
    return params, builder

legacy, old_build = pair('legacy', BASE)
unfixed, rendered_build = pair('rendered', RENDERED)
fixed, new_build = pair('fixed', NEW)
old_signature = inspect.signature(legacy.BridgeTimberParams)
new_signature = inspect.signature(fixed.BridgeTimberParams)
old_fields = list(old_signature.parameters)
old_parameters = list(old_signature.parameters.values())
new_positional = [p for p in new_signature.parameters.values()
                  if p.kind != inspect.Parameter.KEYWORD_ONLY]
assert old_parameters == new_positional, 'Legacy names/order/kinds/defaults/annotations changed'
assert legacy.BridgeTimberParams.__match_args__ == fixed.BridgeTimberParams.__match_args__
expected_new = dict(railing_kind='pole', draw_profile='flat',
                    draw_rise_m=0.0, draw_bearing_supports=False)
actual_new = {p.name: p.default for p in new_signature.parameters.values()
              if p.kind == inspect.Parameter.KEYWORD_ONLY}
assert actual_new == expected_new
for name in old_fields:
    a = legacy.BridgeTimberParams.__dataclass_fields__[name]
    b = fixed.BridgeTimberParams.__dataclass_fields__[name]
    for attr in ['default', 'default_factory', 'init', 'repr', 'hash', 'compare', 'kw_only']:
        assert getattr(a, attr) == getattr(b, attr), (name, attr)

# The API correction consists of exactly the four field initializers; builder is exact.
path = 'generators/archetypes/bridge_timber_params.py'
old_ast = ast.parse((RENDERED / path).read_text())
new_ast = ast.parse((NEW / path).read_text())
def remove_four_initializers(tree):
    tree = copy.deepcopy(tree)
    for node in ast.walk(tree):
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            if node.target.id in expected_new:
                node.value = ast.Constant(value=None)
    return ast.dump(tree, include_attributes=False)
assert remove_four_initializers(old_ast) == remove_four_initializers(new_ast)
assert (RENDERED / 'generators/archetypes/bridge_timber.py').read_bytes() == (
    NEW / 'generators/archetypes/bridge_timber.py').read_bytes()

def raw(builder, params, seed):
    b = builder.build(params, seed)
    return {k: getattr(b, k) for k in
            ['verts', 'faces', 'conf', 'mat_index', 'named', 'captured_materials']}

def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

records = []
for item in inputs['six_bridge_family']:
    record = json.loads((BASE / 'data/structures' / (item['structure_id'] + '.json')).read_text())
    phase = next(x for x in record['phases'] if x['id'] == item['phase_id'])
    old = legacy.from_phase(phase, record)
    new = fixed.from_phase(phase, record)
    for name in old_fields:
        assert getattr(old, name) == getattr(new, name), (item['asset'], name)
    for name, value in expected_new.items():
        assert getattr(new, name) == value
    args = [copy.deepcopy(getattr(old, name)) for name in old_fields]
    old_pos = legacy.BridgeTimberParams(*args)
    new_pos = fixed.BridgeTimberParams(*args)
    old_pos.validate()
    new_pos.validate()
    assert all(getattr(old_pos, x) == getattr(new_pos, x) for x in old_fields)
    # Demonstrate that the archived proposal really broke the same call shape.
    wrong = unfixed.BridgeTimberParams(*args)
    assert any(getattr(wrong, x) != getattr(old_pos, x) for x in old_fields)
    try:
        fixed.BridgeTimberParams(*args, 'board')
    except TypeError:
        pass
    else:
        raise AssertionError('New fields still accepted positionally')
    a = raw(old_build, old, item['structure_id'] + '__' + item['phase_id'])
    b = raw(new_build, new, item['structure_id'] + '__' + item['phase_id'])
    assert a == b, item['asset']
    records.append({'asset': item['asset'], 'all_legacy_positional_values_exact': True,
                    'raw_vertices_faces_materials_confidence_exact': True,
                    'raw_sha256_including_material_calls': sha(a),
                    'vertices': len(a['verts']), 'polygon_faces': len(a['faces'])})

record_path = 'data/structures/dearborn_street_drawbridge.json'
record = json.loads((NEW / record_path).read_text())
assert (NEW / record_path).read_bytes() == (RENDERED / record_path).read_bytes()
phase = record['phases'][0]
rp = unfixed.from_phase(phase, record)
fp = fixed.from_phase(phase, record)
assert dataclasses.asdict(rp) == dataclasses.asdict(fp)
a = raw(rendered_build, rp, 'dearborn_street_drawbridge__draw_1834')
b = raw(new_build, fp, 'dearborn_street_drawbridge__draw_1834')
assert a == b
assert len(b['verts']) == 27640 and len(b['faces']) == 6846
old_digest = {k: b[k] for k in ['verts', 'faces', 'conf', 'mat_index']}
old_digest = hashlib.sha256(json.dumps(old_digest, separators=(',', ':')).encode()).hexdigest()
assert old_digest == '8db45fe611fb6b25d59b9c80808858905ab8a1b201834f216b1dd58668df10d3'
old_source = json.loads((BASE / record_path).read_text())
for name in ['position', 'footprint']:
    assert record.get(name) == old_source.get(name)
for before, after in zip(old_source['phases'], record['phases']):
    for name in ['id', 'start', 'end', 'footprint']:
        assert before.get(name) == after.get(name)

# Native record schemas; no source-use/compiler/full-gate invocation.
import jsonschema
schema_checks = []
for schema, target in [('structures.schema.json', record_path),
                       ('source.schema.json', 'data/sources/andreas_1884_dearborn_drawbridge_plate.json')]:
    jsonschema.validate(json.loads((NEW / target).read_text()), json.loads((BASE / 'data' / schema).read_text()))
    schema_checks.append(target)

for path, expected in inputs['frozen_original_sha256'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected
for path, expected in inputs['preimage_sha256'].items():
    assert hashlib.sha256((Path(inputs['repo']) / path).read_bytes()).hexdigest() == expected

report = {'status': 'PASS; focused CPU/API/schema checks only',
    'legacy_positional_parameter_count': len(old_fields), 'legacy_positional_names': old_fields,
    'legacy_signature': str(old_signature), 'corrected_signature': str(new_signature),
    'legacy_dataclass_defaults_factories_and_match_args_exact': True,
    'four_new_fields_keyword_only': expected_new,
    'archived_positional_regression_demonstrated_all_six_records': True,
    'all_six_current_default_raw_outputs': records,
    'rendered_candidate_resolved_values_and_raw_mesh_exact': True,
    'rendered_candidate_raw_sha256': old_digest,
    'candidate_raw_sha256_including_material_calls': sha(b),
    'rendered_GLB_sha256': '107b76243e85ccf10a980cc96a2aa18487a2345a5a5e45f1db00a310be452648',
    'rendered_GLB_is_prior_raw_preview_not_a_new_export': True,
    'only_four_initializer_AST_changes_vs_rendered_module': True,
    'builder_and_Dearborn_record_exact_rendered_inputs': True,
    'native_schema_passes': schema_checks,
    'frozen_originals_and_current_preimages_unchanged': True,
    'official_freshness': 'NOT ESTABLISHED; all six recipes need real refresh after adoption',
    'image_verdict': 'differs; original T-2375 remains open',
    'Blender_browser_fullgates_claims_canonical_writes': False}
(OUT / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS: legacy', len(old_fields), 'positional parameters; six default raw meshes/materials/confidences exact; rendered Dearborn candidate exact; schemas pass.')
