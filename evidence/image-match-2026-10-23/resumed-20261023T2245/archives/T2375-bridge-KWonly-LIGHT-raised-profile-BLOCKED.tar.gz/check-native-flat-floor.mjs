/** Actual native walker, pure Node; no browser, DOM, GL or network. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { decksFrom, createWalker } from '/workspace/chicago/chicago/4d/renderers/web/js/walker.js';

const dir = path.dirname(fileURLToPath(import.meta.url));
const { sidecar, samples } = JSON.parse(fs.readFileSync(path.join(dir, 'height-samples.json')));
const decks = decksFrom(new Map([['dearborn_street_drawbridge', {
  id: 'dearborn_street_drawbridge', sidecar,
}]]));
assert.equal(decks.length, 1);
const terrain = { isWater: () => true, walkHeight: () => 4, surfaceHeight: () => 0 };
const walker = createWalker({ camera: null, terrain, decks });
const actual = samples.map(s => ({
  ...s, native_walker_floor_m: walker.surfaceAt(s.world_e, s.world_n),
}));
for (const row of actual) assert.equal(row.native_walker_floor_m, sidecar.placement.walk_surface_m);
assert(Math.abs(actual[3].actual_generated_board_top_m - actual[3].native_walker_floor_m - 1.2) < 1e-9);
fs.writeFileSync(path.join(dir, 'native-flat-floor.json'), JSON.stringify({
  status: 'Existing native walker confirmed flat; profile adoption blocked',
  no_browser_GL_or_network: true, samples: actual,
}, null, 2) + '\n');
console.log('Confirmed actual native walker floor 2.22m; generated centre boards 3.42m.');
