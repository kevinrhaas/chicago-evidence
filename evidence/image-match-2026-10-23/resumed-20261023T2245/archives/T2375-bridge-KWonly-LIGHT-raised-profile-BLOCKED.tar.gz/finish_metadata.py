"""Normalize only machine-readable integration declarations in the owned proposal."""
from pathlib import Path
import difflib
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
OLD = Path('/tmp/chicago-next-model/T-2375-next')
REPO = Path('/workspace/chicago')
APP = REPO / 'chicago/4d'
report = json.loads((OUT / 'inputs.json').read_text())
for path, expected in report['preimage_sha256'].items():
    assert hashlib.sha256((REPO / path).read_bytes()).hexdigest() == expected

board = (OLD / 'LIBERTY-board-entry.md').read_text()
profile = (OLD / 'LIBERTY-profile-entry.md').read_text()
board, n = re.subn(r'\*\*Covers:\*\*.*?(?=\n\*\*)', '', board, flags=re.S)
assert n == 1
profile, n = re.subn(r'\*\*Covers:\*\*.*?(?=\n\*\*)',
    '**Covers:** `dearborn_street_drawbridge.draw_1834.form.draw_rise_m`.',
    profile, flags=re.S)
assert n == 1
append = board + profile + (
    '\n**Integration reading:** The draw-profile entry supersedes only the board '
    'entry\'s first-stage flat-deck retention. Both historical entries remain. '
    'Boarded parapet/profile/bearing categories are inferred; their chosen '
    'sections and metric rise remain reconstructed. Only the new reconstructed '
    'record attribute is named in Covers; all image verdicts remain differs.\n')
(OUT / 'LIBERTIES-APPEND.md').write_text(append)

relative = 'chicago/4d/data/reconstruction/name_pool_keys.json'
raw = (REPO / relative).read_bytes()
doc = json.loads(raw)
old = doc['read']['structures']
added = ['phases[].form.' + name + '.note' for name in
         ['railing_kind', 'draw_profile', 'draw_rise_m', 'draw_bearing_supports']]
assert not set(added) & set(old)
new = sorted(old + added)
assert [x for x in new if x not in added] == old, 'Do not reorder existing readers'
doc['read']['structures'] = new
for area in ['baseline', 'candidate']:
    target = OUT / area / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw if area == 'baseline' else (json.dumps(doc, indent=2) + '\n').encode())
report['preimage_sha256'][relative] = hashlib.sha256(raw).hexdigest()
if relative not in report['patch_targets']:
    report['patch_targets'].append(relative)
report['integration_declaration_normalization'] = {
    'original_fragments_preserved': True,
    'substantive_original_prose_retained': True,
    'board_inferred_category_not_claimed_as_invention': True,
    'new_reconstructed_cover': 'dearborn_street_drawbridge.draw_1834.form.draw_rise_m',
    'new_note_readers': added,
    'all_existing_reader_paths_and_order_retained': True,
}
(OUT / 'inputs.json').write_text(json.dumps(report, indent=2) + '\n')

parts = []
for path in report['patch_targets']:
    before = (REPO / path).read_text()
    after = (before + append if path == 'chicago/4d/docs/LIBERTIES.md'
             else (OUT / 'candidate' / path).read_text())
    parts.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
        fromfile='a/' + path, tofile='b/' + path))
(OUT / 'bridge-adoption.patch').write_text(''.join(parts))
print('Normalized liberty Covers and four note-reader declarations; no other code/data changes.')
