"""Read-only adoption guard; no apply, generation, metadata or external writes."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, default=Path('/workspace/chicago'))
args = parser.parse_args()
OUT = Path(__file__).resolve().parent
inputs = json.loads((OUT / 'inputs.json').read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for relative, expected in inputs['preimage_sha256'].items():
    assert sha(args.repo / relative) == expected, ('preimage changed; recompose outside worktree', relative)
for path, expected in inputs['frozen_original_sha256'].items():
    assert sha(Path(path)) == expected, ('frozen original changed', path)
for path, expected in json.loads((OUT / 'consumer-source-hashes.json').read_text()).items():
    assert sha(args.repo / 'chicago/4d' / path) == expected, ('consumer changed; reassess blocker', path)
manifest_path = OUT / 'MANIFEST.json'
if manifest_path.exists():
    for item in json.loads(manifest_path.read_text()):
        path = OUT / item['path']
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], item['path']
current = json.loads((args.repo / 'chicago/4d/assets/manifest.json').read_text())['assets']
family = {n: v for n, v in current.items() if v.get('archetype') == 'bridge_timber'}
assert set(family) == {x['asset'] for x in inputs['six_bridge_family']}
for item in inputs['six_bridge_family']:
    assert family[item['asset']] == item['master_preimage_manifest'], item['asset']
    assert sha(args.repo / 'chicago/4d/assets/gltf' / item['asset']) == item['master_sha256']
    assert sha(args.repo / 'chicago/4d/assets/web' / item['asset']) == item['web_sha256']
subprocess.run(['git', 'apply', '--check', str(OUT / 'bridge-adoption.patch')], cwd=args.repo, check=True)
print('PASS: guarded source/family/asset preimages, frozen originals and patch applicability. Full peaked-profile adoption remains BLOCKED on the native surface contract.')
