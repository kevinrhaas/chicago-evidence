# T-2375 guarded geometry/API proposal

**Full peaked-profile adoption is BLOCKED on the native surface contract.**
The geometry/API correction is ready for review, not canonical application.
`CONSUMER-DEPENDENCY.md` names the coherent next change. The current walker stays
at 2.22 m while the proposed centre boards reach 3.42 m; router exact-point height
and anchor reporting also assume a scalar. The rise has not been silently removed.

## Concrete patch and compatibility

`bridge-adoption.patch` changes six files relative to the guarded current tree:
the two bridge modules, Dearborn record, cleared Andreas source correction,
append-only liberty fragments, and four additive name-pool note-reader paths.
No scene, GLB, manifest, accepted camera, ticket or claim is written.

Only four dataclass initializers differ from the already-rendered proposal:
`railing_kind`, `draw_profile`, `draw_rise_m`, `draw_bearing_supports` use
`field(default=..., kw_only=True)`. All **20** prior positional parameter names,
order, kinds, defaults, factories and `__match_args__` remain exact. The builder
and Dearborn record remain byte-identical to the rendered v2 inputs.

`validation.json` proves all six current default raw vertex/face/material-call/
confidence outputs unchanged, and corrected Dearborn raw output equal to the
previously rendered candidate: 27,640 vertices, 6,846 polygons; original four-list
digest `8db45fe611fb6b25d59b9c80808858905ab8a1b201834f216b1dd58668df10d3`.
Native structure/source schemas pass. These are CPU/API tests, not a new export.

The saved fragments' invalid Covers shorthand was normalized: the new typed
Cover names only `dearborn_street_drawbridge.draw_1834.form.draw_rise_m`.
Inferred board/profile/bearing categories are not falsely claimed as inventions.
Substantive historical prose remains, with explicit first-stage flat-deck
supersession. `metadata-checks.json` records native parsing, forward coverage and
preservation of every existing note-reader path/order.

## Inputs, rights and existing images

`inputs.json` lists exact current preimage hashes, six current master/derivative
hashes and manifest recipes, frozen original hashes and patch targets. It names
these six assets; **zero bridge versions** were found:

- `dearborn_street_drawbridge__draw_1834.glb`
- `lasalle_slough_crossing__crossing_1835.glb`
- `north_branch_bridge__log_1832.glb`
- `north_water_slough_crossing__crossing_1835.glb`
- `slough_log_bridge__log_1833.glb`
- `south_branch_raft_bridge__log_1833.glb`

Andreas 1884 p.631 is independently cleared public-domain artwork. The composed
source correction preserves its retrospective/date/metric limits and corrects
the visible Braunhold signature, lighthouse, warehouses and background masts.
The separate Baker-Co source remains `check_required` and is not cleared or used
to license this increment. The 1.2 m rise and metric sections are reconstructed.

Existing actual v2 comparison:
`/tmp/chicago-next-model/T-2375-next/preview/comparisons/andreas-provisional-side-by-side.jpg`.
Existing raw GLB SHA:
`107b76243e85ccf10a980cc96a2aa18487a2345a5a5e45f1db00a310be452648`.
Actual committed-before image:
`/tmp/chicago-next-model/T-2375-next/preview/committed-before/andreas-committed-before-side-by-side.jpg`.

Both actual comparisons were inspected as **differs**. Camera principal point
hits a bound; it is not calibrated geographic/metric evidence. Machinery,
support/trestle, materials/context and the second engraving remain unresolved.
T-2375 stays open. The independently rendered **board-only** option and the
unrendered board-plus-aligned-cribs variant are distinguished in the consumer note.

## Review commands and later adoption

Read-only preimage/payload/applicability guard:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 verify.py --repo /path/to/intended/checkout
```

Focused CPU checks, only in this owned proposal directory:

```sh
PYTHONPATH=/workspace/shared/python PYTHONDONTWRITEBYTECODE=1 python3 validate.py
PYTHONPATH=/workspace/shared/python PYTHONDONTWRITEBYTECODE=1 python3 check_metadata.py
PYTHONPATH=/workspace/shared/python PYTHONDONTWRITEBYTECODE=1 python3 consumer_audit.py
node --no-warnings --experimental-loader ./node-importmap-loader.mjs ./check-native-flat-floor.mjs
```

The Node check imports the actual walker with its existing browser Three mapping;
it uses no browser/DOM/GL/network and confirms the missing profile consumer.
No Blender, browser, full gate, publisher or external claim ran here.

Do not apply a patch after a guard fails. Recompose only in a new owned proposal
against current inputs, preserving unrelated root work. Do not restore a full
saved ledger or old generated manifest. Parent must choose a coherent native
surface implementation or reviewed smaller increment before canonical adoption.
All six changed recipes require a genuine supported family refresh/derivatives;
old preview hashes are not final freshness. Native derivation, source/liberty/
name-pool compilation, published app/mobile/desktop checks and full gates require
a later root grant. No recipe restamping or image-match promotion is permitted.
