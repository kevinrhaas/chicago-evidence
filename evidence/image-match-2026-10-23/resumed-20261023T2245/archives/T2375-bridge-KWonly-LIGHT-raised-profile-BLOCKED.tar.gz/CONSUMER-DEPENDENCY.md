# Raised profile: native surface contract required

**The full peaked candidate must not be adopted yet.** It is retained unchanged in
the proposal; no silent downgrade or native image acceptance is claimed.

Positive CPU samples intersect the actual proposed deck triangles at the centre
and quarter points. The deck top is 2.22 m at the two draw bearings, 2.82 m at
the quarter points and 3.42 m at the centre. The unchanged approaches are 2.22 m.
`consumer-audit.json` contains the exact local/world stations and ray results.
An actual native walker, imported in Node using the existing browser's Three
import mapping, answers 2.22 m at all those points. The centre visitor would stand
1.2 m below the visible planks. No browser, GL renderer or terrain drawing ran.

## Current consumers

| Consumer | Current behaviour | Required handling |
|---|---|---|
| `tools/compile_scene.py:232` and placement near line 3067 | Reads scalar `deck_height_m` into `walk_surface_m`; does not inspect GLB triangles. | Retain scalar defaults; optionally carry an engine-neutral local-span height profile from resolved archetype parameters. |
| `renderers/web/js/walker.js:199` and `surfaceAt` near line 285 | `decksFrom` makes a constant `y`; all movement/teleport/fly landing paths sample that scalar. | One shared pointwise profile sampler, preserving highest-deck/water/land policy and all flat defaults. |
| `renderers/web/js/route.js:338` and `exactHeight` near line 542 | Grid centres can call walker, but `deckBoxes` drops extra properties and its exact-point/string-pull path independently reads flat `y`. | Preserve the profile in deck boxes and use the same sampler for grid fallback and exact route checks. Walker-only repair is insufficient. |
| `tools/measure_anchors.mjs:209–240` | Anchor reports use the same scalar; no mesh sampling. | Sample the profile at each anchor, retaining current flat output. |
| `renderers/web/js/main.js:3369` | Supplies walker sampling to the router; it does not repair router's separate exact path. | Keep the shared contract coherent; no new world-coordinate guesses. |
| Bridge `ground_contact_z`, vertical anchor and terrain approaches | End contact uses base deck height; rise is zero at both span ends. | No terrain raise or anchor relocation is needed. Preserve endpoint checks. |
| `tools/generate_frontage_works.py:2097` and analogous slough footway functions | Named La Salle/slough footways read their host's scalar deck height. | Those other five bridge defaults stay flat. No Dearborn footway is produced here; a future non-flat host needs explicit handling/refusal. |
| `parked-transport.js:198,237,250` and tongue contact near line 125 | 1835 support contacts default to terrain; tongue bracket directly calls terrain even with another wheel sampler. | No current 1835 parked centre lies on this bridge. Before allowing future bridge placements, use the shared surface for **all** wheel/support/tongue contacts or explicitly refuse them. |
| `yard.js:1303` and `humans.js:603` | Terrain-only ground height, not bridge mesh. | No scanned yard point anchor lies on this bridge. Future bridge goods/figures need the same surface contract or refusal; current meshes/clearance were not certified. |

The parked and yard checks are point-anchor enumeration, not complete prop/vehicle
mesh contact or clearance. `consumer-audit.json` records their counts and limits.

## Minimum coherent next implementation

1. Expose a pure archetype profile declaration derived from the same parameters
   as the deck deformation. The sidecar may carry optional local-span metre
   stations, for example `[[0,2.22],[lo,2.22],[mid,3.42],[hi,2.22],[span,2.22]]`.
   The labels stand for resolved numeric values, not strings in serialized data.
   Keep this engine-neutral and omit it for flat/default bridges, leaving existing
   scalar output byte-identical. Do not duplicate geometry formulas in renderers.
2. Use one shared pointwise runtime sampler, transforming world ENU back into the
   declared local span frame. Keep the existing scalar `y` fallback. Walker,
   router grid fallback and exact/string-pull paths must all use it; copying only
   polygon and scalar into `deckBoxes` is no longer sufficient.
3. Use the same numeric contract in anchor reporting and explicitly guard future
   vehicle/prop/human bridge placements. Retain current endpoint contact and
   terrain policies. Keep every old flat case unchanged.
4. Prove positive quarter/centre samples against actual deck triangles, approach
   continuity, rotated coordinates and overlapping deck selection. Then run the
   supported six-family refresh, native derivation, published mobile/desktop
   walk/route comparisons and full gates under a later root grant.

This is a separate shared-consumer dependency, **not implemented** by this patch.
No supported native acceptance follows from the old isolated photo render.

## Independently rendered smaller option

The original **board-only** preview really ran and was inspected as `differs`:

- GLB: `/tmp/chicago-next-model/T-2375/preview/fixture/assets/gltf/dearborn-board-preview.glb`
- SHA256: `8552ab10ecb1c201631a09ce1f512382000a22dea0982b076a1b73f6225bdc42`
- Comparison: `/tmp/chicago-next-model/T-2375/preview/comparisons/andreas-provisional-side-by-side.jpg`

`consumer_audit.py` proves that the corrected API reproduces its exact raw
geometry/materials with flat profile, zero rise and original support stations;
its actual deck top agrees with the scalar walk floor. This is evidence for a
reviewed smaller increment, not substitution into the full proposed record.
**Board parapets plus aligned cribs without rise has not been rendered.**

Both cameras remain provisional and at a principal-point bound; mechanism,
metric sections, scene dating, materials and the second engraving remain open.
