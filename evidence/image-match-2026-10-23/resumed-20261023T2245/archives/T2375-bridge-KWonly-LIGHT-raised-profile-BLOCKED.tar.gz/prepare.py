"""Prepare a small guarded proposal; never write the inspected repository."""
from pathlib import Path
import ast
import datetime
import difflib
import hashlib
import json
import subprocess

OUT = Path(__file__).resolve().parent
REPO = Path('/workspace/chicago')
APP = REPO / 'chicago/4d'
OLD = Path('/tmp/chicago-next-model/T-2375-next')
AUDIT = Path('/tmp/chicago-next-model/T-2375-source-audit-closed-20261023T1150')
assert OUT.is_relative_to(Path('/tmp')) and not OUT.is_relative_to(REPO)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def put(relative, data):
    target = OUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

def readj(path):
    return json.loads(path.read_text())

assert not (OUT / 'inputs.json').exists(), 'Do not overwrite a prepared package'
manifest = readj(APP / 'assets/manifest.json')['assets']
family = [dict(asset=n, **v) for n, v in manifest.items()
          if v.get('archetype') == 'bridge_timber']
assert len(family) == 6
preimages = {}
paths = [
    'generators/archetypes/bridge_timber.py',
    'generators/archetypes/bridge_timber_params.py',
    'data/sources/andreas_1884_dearborn_drawbridge_plate.json',
    'data/sources/dearborn_street_bridge_1834_engraving.json',
    'data/structures.schema.json', 'data/source.schema.json',
]
paths += [f"data/structures/{x['structure_id']}.json" for x in family]
paths += ['generators/common/' + x for x in
          ['__init__.py', 'mesh.py', 'logwork.py', 'materials.py']]
for path in paths:
    data = (APP / path).read_bytes()
    preimages['chicago/4d/' + path] = digest(data)
    put('baseline/chicago/4d/' + path, data)
    put('candidate/chicago/4d/' + path, data)

# Apply only the already-reviewed patches to the wholly-owned copied fixture.
for patch in [OLD / 'T-2375-next-cumulative.patch',
              AUDIT / 'source-prose-correction.patch']:
    subprocess.run(['git', 'apply', str(patch)], cwd=OUT / 'candidate', check=True)

candidate = OUT / 'candidate/chicago/4d'
params_path = candidate / 'generators/archetypes/bridge_timber_params.py'
before = params_path.read_text()
replacements = {
    '    railing_kind: str = "pole"':
    '    railing_kind: str = field(default="pole", kw_only=True)',
    '    draw_profile: str = "flat"':
    '    draw_profile: str = field(default="flat", kw_only=True)',
    '    draw_rise_m: float = 0.0':
    '    draw_rise_m: float = field(default=0.0, kw_only=True)',
    '    draw_bearing_supports: bool = False':
    '    draw_bearing_supports: bool = field(default=False, kw_only=True)',
}
after = before
for old, new in replacements.items():
    assert after.count(old) == 1
    after = after.replace(old, new)
params_path.write_text(after)
assert before == (OLD / 'after/generators/archetypes/bridge_timber_params.py').read_text()
for path in ['generators/archetypes/bridge_timber.py',
             'data/structures/dearborn_street_drawbridge.json']:
    assert (candidate / path).read_bytes() == (OLD / 'after' / path).read_bytes()
    assert (candidate / path).read_bytes() == (OLD / 'preview/fixture' / path).read_bytes()

# Retain the exact two historical entries, explicitly state their staged supersession.
fragments = [(OLD / x).read_bytes() for x in
             ['LIBERTY-board-entry.md', 'LIBERTY-profile-entry.md']]
ledger = (APP / 'docs/LIBERTIES.md').read_bytes()
assert b'L-dearborn-board-parapet-2375' not in ledger
assert b'L-dearborn-draw-profile-2375' not in ledger
append = b''.join(fragments) + (
    b'\n**Integration reading:** The following draw-profile entry supersedes only '
    b'the board entry\'s first-stage flat-deck retention. Both entries remain '
    b'historical; all image verdicts remain differs, and no historic lifting '
    b'mechanism or metric rise is attested.\n')
put('LIBERTIES-APPEND.md', append)
preimages['chicago/4d/docs/LIBERTIES.md'] = digest(ledger)

changed = ['generators/archetypes/bridge_timber.py',
           'generators/archetypes/bridge_timber_params.py',
           'data/structures/dearborn_street_drawbridge.json',
           'data/sources/andreas_1884_dearborn_drawbridge_plate.json']
patch_parts = []
for path in changed:
    source = (APP / path).read_text()
    target = (candidate / path).read_text()
    patch_parts.extend(difflib.unified_diff(source.splitlines(True), target.splitlines(True),
        fromfile='a/chicago/4d/' + path, tofile='b/chicago/4d/' + path))
patch_parts.extend(difflib.unified_diff(ledger.decode().splitlines(True),
    (ledger + append).decode().splitlines(True),
    fromfile='a/chicago/4d/docs/LIBERTIES.md',
    tofile='b/chicago/4d/docs/LIBERTIES.md'))
put('bridge-adoption.patch', ''.join(patch_parts).encode())

frozen = {}
for path in [OLD / 'T-2375-next-cumulative.patch', AUDIT / 'source-prose-correction.patch',
             *[OLD / x for x in ['LIBERTY-board-entry.md', 'LIBERTY-profile-entry.md']],
             OLD / 'preview/andreas-provisional.json',
             OLD / 'preview/andreas-provisional.match.json',
             OLD / 'preview/fixture/assets/gltf/dearborn-profile-preview.glb',
             OLD / 'preview/comparisons/andreas-provisional-side-by-side.jpg',
             OLD / 'preview/committed-before/andreas-committed-before-side-by-side.jpg']:
    frozen[str(path)] = digest(path.read_bytes())

# Only the small producer code/record is copied; existing large visuals stay referenced.
for path in ['generators/archetypes/bridge_timber_params.py',
             'generators/archetypes/bridge_timber.py',
             'data/structures/dearborn_street_drawbridge.json']:
    put('rendered-candidate/' + path, (OLD / 'preview/fixture' / path).read_bytes())
for name in ['mesh.py', 'logwork.py', 'materials.py']:
    path = 'generators/common/' + name
    assert (APP / path).read_bytes() == (OLD / 'preview/fixture' / path).read_bytes()

baker = readj(APP / 'data/sources/dearborn_street_bridge_1834_engraving.json')
assert baker['rights_status'] == 'check_required'
assert readj(OLD / 'preview/andreas-provisional.match.json')['verdict'] == 'differs'
for row in family:
    record_path = APP / 'data/structures' / (row['structure_id'] + '.json')
    row['record_sha256'] = digest(record_path.read_bytes())
    row['master_sha256'] = digest((APP / 'assets/gltf' / row['asset']).read_bytes())
    row['web_sha256'] = digest((APP / 'assets/web' / row['asset']).read_bytes())
    row['master_preimage_manifest'] = manifest[row['asset']]
    row['versions'] = []
versions = list((APP / 'data/structures/versions').rglob('*.json'))
for path in versions:
    record = readj(path)
    assert record.get('archetype') != 'bridge_timber', f'New bridge version: {path}'

report = {'prepared_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'repo_HEAD': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'preimage_sha256': preimages, 'six_bridge_family': family,
    'frozen_original_sha256': frozen, 'four_keyword_only_fields': list(replacements),
    'patch_targets': ['chicago/4d/' + x for x in changed] + ['chicago/4d/docs/LIBERTIES.md'],
    'raw_bake_required': 'All six current bridge masters and derivatives; zero versions.',
    'canonical_writes': False, 'official_bake': False,
    'image_verdict': 'differs; original T-2375 remains open',
    'Baker_Co': 'check_required, unchanged and not a geometry source',
    'no_external_claim': True}
put('inputs.json', (json.dumps(report, indent=2) + '\n').encode())
for relative, expected in preimages.items():
    assert digest((REPO / relative).read_bytes()) == expected
subprocess.run(['git', 'apply', '--check', str(OUT / 'bridge-adoption.patch')],
    cwd=REPO, check=True)
print('Prepared guarded five-file patch; originals/source tree unchanged; six-family scope captured.')

if __name__ == '__main__':
    pass
