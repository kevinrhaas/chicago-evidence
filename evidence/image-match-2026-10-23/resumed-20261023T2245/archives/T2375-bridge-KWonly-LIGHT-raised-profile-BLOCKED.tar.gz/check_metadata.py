"""Focused native liberty parse/forward coverage and note-reader preservation."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
APP = Path('/workspace/chicago/chicago/4d')
sys.path.insert(0, str(APP / 'tools'))

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

compiler = load('bridge_liberty_parser', APP / 'tools/compile_liberties.py')
validator = load('bridge_coverage_validator', APP / 'tools/validate.py')
record = json.loads((OUT / 'candidate/chicago/4d/data/structures/dearborn_street_drawbridge.json').read_text())
known = {record['id']: record['name']}
append = (OUT / 'LIBERTIES-APPEND.md').read_text()
entries, problems = compiler.parse('## Per-subject liberties\n' + append, known)
assert not problems, problems
assert len(entries) == 2
claims = [c for e in entries for c in e['covers']]
assert claims == [{'domain': 'structure', 'structure': 'dearborn_street_drawbridge',
                   'phase': 'draw_1834', 'aspect': 'form.draw_rise_m'}], claims
assert record['phases'][0]['form']['draw_rise_m']['confidence'] == 'reconstructed'
for field in ['railing_kind', 'draw_profile', 'draw_bearing_supports']:
    assert record['phases'][0]['form'][field]['confidence'] == 'inferred'
base_liberties = json.loads((APP / 'data/liberties.json').read_text())
joined = dict(base_liberties, liberties=base_liberties['liberties'] + entries)
rep = validator.Report()
validator.check_liberties_coverage({record['id']: record}, joined, rep, forward_only=True)
assert not rep.errors, rep.errors
old = json.loads((OUT / 'baseline/chicago/4d/data/reconstruction/name_pool_keys.json').read_text())
new = json.loads((OUT / 'candidate/chicago/4d/data/reconstruction/name_pool_keys.json').read_text())
expected = {'phases[].form.' + x + '.note' for x in
            ['railing_kind', 'draw_profile', 'draw_rise_m', 'draw_bearing_supports']}
assert set(new['read']['structures']) - set(old['read']['structures']) == expected
filtered = json.loads(json.dumps(new))
filtered['read']['structures'] = [x for x in filtered['read']['structures'] if x not in expected]
assert filtered == old
source = json.loads((OUT / 'candidate/chicago/4d/data/sources/andreas_1884_dearborn_drawbridge_plate.json').read_text())
assert source['rights_status'] == 'public_domain'
baker = json.loads((OUT / 'baseline/chicago/4d/data/sources/dearborn_street_bridge_1834_engraving.json').read_text())
assert baker['rights_status'] == 'check_required'
report = {'status': 'PASS; focused native parser/forward coverage only',
          'native_parsed_liberties': [x['id'] for x in entries],
          'precise_new_reconstructed_covers': claims,
          'inferred_categories_not_claimed_as_reconstructed': True,
          'all_Dearborn_reconstructed_values_have_existing_or_new_admissions': True,
          'native_forward_coverage_notes': rep.notes,
          'only_four_new_note_reader_paths': sorted(expected),
          'all_other_note_reader_data_and_order_exact': True,
          'Andreas_public_domain_and_Baker_Co_hold_preserved': True,
          'not_full_compiler_or_gate': True}
(OUT / 'metadata-checks.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS: two parsed liberties, exact reconstructed rise Cover, native forward coverage, four additive note-reader paths, rights limits.')
