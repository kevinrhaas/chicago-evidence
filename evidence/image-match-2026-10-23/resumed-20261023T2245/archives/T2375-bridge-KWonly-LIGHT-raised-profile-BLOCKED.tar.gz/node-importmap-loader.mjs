/** The existing browser's bare-three mapping, scoped to this CPU proof only. */
const vendor = new URL('file:///workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/');
export function resolve(specifier, context, nextResolve) {
  if (specifier === 'three') return { url: new URL('three.module.js', vendor).href, shortCircuit: true };
  if (specifier.startsWith('three/addons/')) return {
    url: new URL('addons/' + specifier.slice('three/addons/'.length), vendor).href, shortCircuit: true,
  };
  return nextResolve(specifier, context);
}
