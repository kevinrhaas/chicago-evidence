
### L-dearborn-board-parapet-2375 — Dearborn's boarded parapets


**Decision:** Replace the open pole rail with horizontal-board parapets, read from
the public-domain Andreas 1884 plate, p. 631
(`andreas_1884_dearborn_drawbridge_plate`;
`chicago/reference/images/chicago/chicago_dearborn_drawbridge_1834.png`).
The plate shows the broad boarded sides and horizontal joints. It is retrospective,
so this is inferred form for the 1835 bridge, not a contemporary specification.
**What is invented:** retain the existing 0.95 m height and approximately 2.2 m
post spacing; use five boards, each 162 mm high and 40 mm thick, with 10 mm gaps,
starting 40 mm above the deck, under a 200 mm wide, 60 mm thick cap. These sections,
course count, joints and neutral weathered-deck material are reconstructed.
Boards and cap are jointed at post bays, draw ends and the two leaves' meeting line;
neither becomes a continuous timber across a moving leaf. Post heads stop at
the cap underside (0.89 m above the deck); the 0.95 m figure is the overall
parapet height. This avoids overlapping coplanar cap/post top faces.
**What remains unresolved:** the pictures' raised central deck profile, approach
geometry, camera calibration and the remaining image comparison. The flat closed
deck is retained; this change does not claim the bridge matches its pictures.
**How to resolve:** the trustees' specification, premium drawing or repair accounts
could replace the reconstructed sections; a completed camera solve and rendered
comparison must resolve the visible differences before the ticket closes.
**Ticket:** T-2375.
**Recorded:** 2026-10-22.

### L-dearborn-draw-profile-2375 — Dearborn's closed central rise and frame bearings

**Covers:** `dearborn_street_drawbridge.draw_1834.form.draw_rise_m`.
**Decision:** Test the clearly raised central closed-draw/parapet profile in the
retrospective Andreas1884 p.631 engraving (`andreas_1884_dearborn_drawbridge_plate`)
in place of the model's flat run. The qualitative central rise and bearing beneath
the gallows are inferred from the actual public-domain plate; neither is a survey,
a contemporary specification, a geographic control or an attested mechanism.
**What is invented:** A1.2m central rise, piecewise-linear from zero at the existing
draw endpoints, is a reconstructed visual trial. It is not measured from the
provisional camera, whose principal point reaches a bound. Long stringer/deck/rail
faces are split at both draw ends and centre so all follow that display profile;
these timber folds/joints are reconstruction, not evidence for a historic hinge.
The nearest surviving support on each approach is stationed at its existing
frame/draw bearing; remaining support count, crib type and approach spacing stay
reconstructed. For this record12surviving supports are retained. Cribs remain
horizontal and grounded, gallows remain vertical with level heads, and chain
endpoints follow the raised centre. No leaf is animated or represented as hoisted.
**What is retained:** The text-derived18.288m draw, footprint, map placement,
abutment/deck-end heights, gallows height and the first board proposal's nominal
parapet sections. The first raw preview is preserved as the before condition.
Raised geometry takes the worst of its old confidence and the reconstructed rise;
no reconstructed rise is presented as an attested dimension.
**What remains unresolved:** The camera is not calibrated, the retrospective
perspective is inconsistent, other support/trestle and approach details remain
unmatched, and the neutral preview omits the river/shore scene. No image match,
accepted camera, supported bake or ticket closure follows from this proposal.
**How to resolve:** A reliable bridge specification or drawn profile could replace
the invented rise/support layout; every source camera and the actual full-scene
comparison must be adjudicated before the original image-gate ticket closes.
**Ticket:** T-2375.
**Recorded:** 2026-10-22.

**Integration reading:** The draw-profile entry supersedes only the board entry's first-stage flat-deck retention. Both historical entries remain. Boarded parapet/profile/bearing categories are inferred; their chosen sections and metric rise remain reconstructed. Only the new reconstructed record attribute is named in Covers; all image verdicts remain differs.
