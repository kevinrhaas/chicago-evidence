"""Positive raw-floor samples and bounded existing-consumer trace; no new runtime."""
from pathlib import Path
import ast
import hashlib
import json
import math
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
APP = Path('/workspace/chicago/chicago/4d')
import validate as proof

p = proof.fp
raw = proof.b
side = json.loads((APP / 'data/sidecars/1835/dearborn_street_drawbridge.json').read_text())

# Execute the exact existing native scalar reader with the copied candidate params.
source_path = APP / 'tools/compile_scene.py'
tree = ast.parse(source_path.read_text())
node = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == 'walk_surface_m')
scope = {'ROOT': proof.NEW, 'sys': sys}
exec(compile(ast.Module(body=[node], type_ignores=[]), str(source_path), 'exec'), scope)
native_scalar = scope['walk_surface_m'](proof.record, proof.phase)
assert native_scalar == p.deck_height_m == side['placement']['walk_surface_m']

def barycentric_z(triangle, x, y):
    a, b, c = triangle
    det = (b[1]-c[1])*(a[0]-c[0]) + (c[0]-b[0])*(a[1]-c[1])
    if abs(det) < 1e-12:
        return None
    u = ((b[1]-c[1])*(x-c[0]) + (c[0]-b[0])*(y-c[1])) / det
    v = ((c[1]-a[1])*(x-c[0]) + (a[0]-c[0])*(y-c[1])) / det
    w = 1-u-v
    return u*a[2]+v*b[2]+w*c[2] if min(u, v, w) >= -1e-9 else None

def actual_board_top(x, y, mesh_data=raw):
    hits = []
    for face, material in zip(mesh_data['faces'], mesh_data['mat_index']):
        if material != proof.new_build.M_DECK:
            continue
        points = [mesh_data['verts'][i] for i in face]
        for i in range(1, len(points)-1):
            z = barycentric_z([points[0], points[i], points[i+1]], x, y)
            if z is not None:
                hits.append(z)
    assert hits, ('Sample falls in an actual board gap', x, y)
    return max(hits)

mid = p.span_m/2
lo, hi = mid-p.draw_span_m/2, mid+p.draw_span_m/2
samples = []
placement = side['placement']
angle = math.radians(placement['rotation_deg'])
c, s = math.cos(angle), math.sin(angle)
for label, x in [('south approach', .1), ('south draw bearing', lo),
                 ('rising quarter', (lo+mid)/2), ('draw centre', mid),
                 ('falling quarter', (mid+hi)/2), ('north draw bearing', hi),
                 ('north approach', p.span_m-.1)]:
    y = p.width_m/2
    expected = p.deck_height_m + proof.new_build._draw_rise(p, x)
    actual = actual_board_top(x, y)
    assert abs(actual-expected) < 1e-9
    samples.append({'label': label, 'local_x_m': x, 'local_y_m': y,
                    'world_e': placement['local_e']+x*c+y*s,
                    'world_n': placement['local_n']-x*s+y*c,
                    'actual_generated_board_top_m': actual,
                    'expected_profile_top_m': expected,
                    'current_scalar_consumer_m': native_scalar,
                    'current_boot_error_m': expected-native_scalar})
assert math.isclose(samples[3]['current_boot_error_m'], 1.2, abs_tol=1e-9)

def in_poly(e, n, poly):
    inside = False
    for a, b in zip(poly, poly[1:]+poly[:1]):
        if (a[1] > n) != (b[1] > n) and e < (b[0]-a[0])*(n-a[1])/(b[1]-a[1])+a[0]:
            inside = not inside
    return inside

poly = [[placement['local_e']+u*c+v*s, placement['local_n']-u*s+v*c]
        for u, v in side['footprint']['polygon']]
parked = json.loads((APP / 'data/transport/parked/placements.json').read_text())['scenes']['1835']
parked_hits = [x['id'] for x in parked if in_poly(*x['at_local_enu_m'], poly)]
yard_points = []
def collect(value, path):
    if isinstance(value, dict):
        point = value.get('at_local_enu_m')
        if isinstance(point, list) and len(point) == 2 and all(isinstance(x, (int, float)) for x in point):
            yard_points.append({'file': path, 'id': value.get('id'), 'point': point})
        for child in value.values():
            collect(child, path)
    elif isinstance(value, list):
        for child in value:
            collect(child, path)
for path in (APP / 'data/yard').glob('*.json'):
    collect(json.loads(path.read_text()), str(path.relative_to(APP)))
yard_hits = [x for x in yard_points if in_poly(*x['point'], poly)]
assert not parked_hits and not yard_hits

# Identify the already-rendered smaller option without replacing the peaked proposal.
board_root = Path('/tmp/chicago-next-model/T-2375-next/before-board')
bp, bb = proof.pair('board_only_frozen', board_root)
br = json.loads((board_root / 'data/structures/dearborn_street_drawbridge.json').read_text())
board_params = proof.fixed.from_phase(br['phases'][0], br)
assert board_params.railing_kind == 'board' and board_params.draw_profile == 'flat'
assert board_params.draw_rise_m == 0 and not board_params.draw_bearing_supports
board_old = proof.raw(bb, bp.from_phase(br['phases'][0], br), 'dearborn_street_drawbridge__draw_1834')
board_new = proof.raw(proof.new_build, board_params, 'dearborn_street_drawbridge__draw_1834')
assert board_new == board_old
assert abs(actual_board_top(mid, p.width_m/2, board_new)-native_scalar) < 1e-9
board_glb = Path('/tmp/chicago-next-model/T-2375/preview/fixture/assets/gltf/dearborn-board-preview.glb')
assert hashlib.sha256(board_glb.read_bytes()).hexdigest() == '8552ab10ecb1c201631a09ce1f512382000a22dea0982b076a1b73f6225bdc42'

report = {'status': 'BLOCKED: native bridge-floor contract is flat',
    'native_compile_scene_walk_surface_m': native_scalar,
    'actual_mesh_positive_samples': samples,
    'centre_boot_error_if_geometry_adopted_alone_m': 1.2,
    'native_reader_source_sha256': hashlib.sha256(source_path.read_bytes()).hexdigest(),
    'samples_match_actual_board_triangle_intersections': True,
    'terrain_end_contact_unchanged': 'rise is zero at both endpoints; water anchor and approach grading stay unchanged',
    'parked_1835_placement_centres_checked': len(parked), 'parked_centres_on_bridge': parked_hits,
    'yard_point_anchors_checked_all_records': len(yard_points), 'yard_point_anchors_on_bridge': yard_hits,
    'placement_limits': 'Point anchors only, not full prop/wheel/contact mesh clearance; no browser or terrain draw inspected',
    'minimum_coherent_dependency': 'Engine-neutral optional sidecar profile plus one shared pointwise deck sampler used by walker and router grid/exactHeight; anchor reporting must use the same sampler. Scalar default remains exact.',
    'future_transport_prop_support': 'Existing 1835 parked/yard anchors are outside this bridge. Their generic terrain-only support/tongue paths must be extended or refused before any future bridge placement; no current clearance claim.',
    'independent_board_only_option': {
        'actually_rendered_GLB': str(board_glb),
        'GLB_sha256': '8552ab10ecb1c201631a09ce1f512382000a22dea0982b076a1b73f6225bdc42',
        'actual_comparison': '/tmp/chicago-next-model/T-2375/preview/comparisons/andreas-provisional-side-by-side.jpg',
        'actual_export_and_browser_exit': 0, 'verdict': 'differs',
        'corrected_API_raw_geometry_and_materials_equal_frozen_board_only_producer': True,
        'flat_walk_surface_matches_actual_board_top': True,
        'no_support_alignment_or_rise': True,
        'not_substituted_into_main_proposal': True},
    'board_plus_aligned_cribs_but_no_rise_variant': 'Not actually rendered; do not inherit board-only or full-profile acceptance.',
    'canonical_writes_browser_Blender_gate': False}
(OUT / 'consumer-audit.json').write_text(json.dumps(report, indent=2)+'\n')
(OUT / 'height-samples.json').write_text(json.dumps({'sidecar': side, 'samples': samples}, indent=2)+'\n')
print('BLOCKER confirmed: positive raw triangle samples match profile; native scalar leaves centre boots 1.2m below boards.')
