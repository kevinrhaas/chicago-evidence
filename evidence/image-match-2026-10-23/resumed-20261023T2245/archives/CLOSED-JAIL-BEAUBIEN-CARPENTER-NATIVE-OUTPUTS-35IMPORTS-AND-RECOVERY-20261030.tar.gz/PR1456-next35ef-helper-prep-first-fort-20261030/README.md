# PR1456: exact430 + incoming35ef integration helpers

Prepared externally, not launched. Root owns all primary mutations, CPU grants and qualification. Previous helper packets are unchanged. Source parent is430557a76ad9c8fc70f0fbfb353765bfe8c83857/treefe96; incoming parent35efd89976913d8739245c98367a2b2166fd17e9/tree8ea1ad6bdc87df3f1d57415bbab98fe6ae6357fa. Actual merged staged tree/path count are unknown and must come from the genuine merge/native output, never an old receipt.

The only new outside-4d exception is `.github/workflows/chicago-4d-moving-frames.yml`, mode100644, blob06f8ecab0758dff2aa67a11d9b179a18e2488458,4972bytes, SHAd4147454a1cb572a8315c87758cfa7e08fa4620cf02a8ec63f82e81897b8faef. Independent official API proof shows PR1478 actually merged to dev atf0b920e238798dbfc2873b6339b090e2d9c61b56 and is an ancestor of35ef; exact incoming tree trace and payload SHA are verified. `inherited_workflow.py` pins that evidence and verifies exact incoming/index/working mode/blob/hash. Transport permits that path only as the exact inherited tuple with literal genuine [430557a…,35efd899…] merge parents. It grants no authored workflow permission and no directory exception.

The previous five library paths and fixed inherited workbook path/mode/blob3ce2acf…/SHA630e934… stay guarded. A new independent35ef tree trace proves the same canonical workbook; its zero-cell-change timestamp/container classification from1449 remains pinned unchanged. Incoming ledger441149…/SHA07799e9… is also verified unchanged. `ledger_os.py` is byte-identical to reviewed V2: exact known gzip610454bytes may differ only at OS byte9 FF→03; every other byte and decompressed12958902bytes/SHAa4c16a… must match. Native raw output is preserved first. Any other gzip or workbook semantic change stops; nothing is broadly restored or whitelisted.

`INCOMING-NATIVE-OWNER-API-PROOF.json` derives the actual incoming manifest:204steps, liberty step144,61 sequence-tail commands; railway incoming SHA3117e6… and required K01 check remain exact. Root handles the actual owner controller, merged frontyard union and scratch routing/budget. The helpers below retain native-result/final-settled-lap,44canonical binary, all model/authored, branch/parent/tree, railway, index/config/source, exact SHA scope, floors, unchanged four-core full gate and all-child reaper guards. The source checkpoint remains ordinary native Git and the transport preserves native SHAs/parents/author dates, normal nonforce remote update and immutable readback. No source or required check is skipped.

## Root launch order after review and actual native61 PASS

These are commands for root, not operations already executed by this prep. Source/native/CPU ownership must remain exclusive as root coordinates. First read the actual native RESULT and its guards/final unchanged lap at `/workspace/PR1456-final35ef-native61-root-20261030`; classify genuine semantic differences before any close attempt.

```
source /workspace/shared/resume-chicago-env.sh
P=/workspace/PR1456-next35ef-helper-prep-first-fort-20261030
taskset -c 2 env PYTHONDONTWRITEBYTECODE=1 python "$P/full_gate/close_and_check.py"
```

Close preserves native serialization-only raw evidence and stages only proved canonical bytes, verifies the real [430,35] parents, records actual staged path SHA/tree/count dynamically, then launches unchanged `full_gate/run.py` using its native reaper and CPUs0,1,3,4. Gate still requires workspace536870912B and caller/tmp1800000000B before launch. Do not lower caller floors or reuse obsolete1af full-gate results. When the actual complete gate PASS and reaper/source guards are closed:

```
taskset -c 2 env PYTHONDONTWRITEBYTECODE=1 python "$P/checkpoint/run.py"
```

That creates an ordinary native merge commit, rechecks exact parent/tree/source and actual PR-event/changelog/ticket-ID/four original image gates, and labels its result SOURCE-ONLY. Fresh same-head phone, current People acceptance, required CI and dev merge are still pending. The inherited workflow is outside4d only because it already merged in the incoming parent, never because this run authored it.

Native transport is separately root-authorized. Substitute the actual new native checkpoint HEAD/TREE and staged COUNT from this packet's real passing receipts; expected old remote is430 only if fresh API still says so. An unexpected remote/base/head/count must stop for review, with no force push or invented ancestry. This integration normally adds one native merge commit beyond430, so pass `--expected-new-commits 1` explicitly (the inherited tool's default remains4 and is not silently relaxed). Existing explicit checked-path and payload bounds remain; root must review any bound failure before making a separate helper revision.

```
taskset -c 2 env PYTHONDONTWRITEBYTECODE=1 python "$P/transport/publish_native.py" --base 430557a76ad9c8fc70f0fbfb353765bfe8c83857 --head ACTUAL_NATIVE_HEAD --qualified-tree ACTUAL_TREE --gate-proof "$P/full_gate/RESULT.json" --expected-old 430557a76ad9c8fc70f0fbfb353765bfe8c83857 --expected-new-commits 1 --expected-checked-paths ACTUAL_COUNT --output /workspace/PR1456-ACTUAL35-TRANSPORT-PLAN
# After root reviews the fresh exact bounded plan, same parameters with a NEW output path and --publish.
```

Incoming35ef changes common People/Inspect rank sorting (head/spouse/children/kin/staff) active in1835. Old body/phone evidence cannot establish this interaction. Root owes fresh current targeted People BOTH8captures plus current full phone before merge; source checkpoint/transport never claim them. Incoming Census1900 adds one source row (19foreign sources versus18 at430), preserving the four original target joins and its text-only scope. New exact native/source/phone/runtime evidence and required green PR checks must bind the actual final head before normal dev merge and settlement.

Seventeen tests use RAM payloads and actual transport AST predicates; all helper ASTs parse and fixed V2 ledger bytes match. No helper main, native owner, full gate, browser, source/index/ref write or remote mutation ran during this preparation. API payloads stayed in RAM; small proof summaries and seven external helper copies are retained. Every helper/diff/proof is hash-bound by MANIFEST.json. Future actual execution may add receipts; do not edit the frozen helper files.
