"""Read-only helper predicates against RAM data; never execute a helper main or primary Git."""
from pathlib import Path
import ast,base64,concurrent.futures,hashlib,json,sys,types
from urllib.request import Request,urlopen
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import inherited_workbook as IW,inherited_workflow as WF,ledger_os as LD
sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def check(name,fn):fn();rows.append({'name':name,'pass':True})
def refuses(fn):
 try:fn()
 except (AssertionError,RuntimeError):return
 raise AssertionError('expected refusal')
def raw(blob):
 with urlopen(Request('https://api.github.com/repos/kevinrhaas/chicago/git/blobs/'+blob,headers={'User-Agent':'Chicago35ef-readonly-helper-negative-tests'}),timeout=45)as r:d=json.load(r)
 b=base64.b64decode(d['content']);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==blob;return b
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:bodies=dict(zip([IW.PATH,WF.PATH,LD.PATH],ex.map(raw,[IW.BLOB,WF.BLOB,LD.BLOB])))
class MemoryRoot:
 def __truediv__(self,p):return types.SimpleNamespace(read_bytes=lambda:bodies[p])
root=MemoryRoot()
def fakegit(*args):
 path=args[-1];module=IW if path==IW.PATH else WF
 if args[0]=='ls-tree':assert args[1]==IW.INCOMING;return (module.MODE+' blob '+module.BLOB+'\t'+path+'\n').encode()
 assert args[:2]==('ls-files','--stage');return (module.MODE+' '+module.BLOB+' 0\t'+path+'\n').encode()
check('strict workbook ancestor/classification proof and exact workflow1478 proof',lambda:(IW.proof(),WF.proof()))
check('incoming/index/working exact two fixed paths accepted in RAM',lambda:IW.verify(root,fakegit))
check('all existing five library outputs still accepted',lambda:exec('assert all(IW.allowed(p) for p in IW.LIBRARY)'))
check('other workflow paths and wrong fixed digests refused',lambda:exec("assert not IW.allowed('.github/workflows/other.yml',WF.SHA256) and not IW.allowed(WF.PATH,'0'*64) and not IW.allowed(WF.PATH) and not IW.allowed(IW.PATH,'0'*64)"))
check('wrong incoming workflow mode refuses',lambda:refuses(lambda:WF.verify(root,lambda *a:fakegit(*a).replace(b'100644',b'100755'))))
check('wrong workflow index blob refuses',lambda:refuses(lambda:WF.verify(root,lambda *a:fakegit(*a).replace(WF.BLOB.encode(),b'0'*40)if a[0]=='ls-files'else fakegit(*a))))
body=bodies[WF.PATH];bodies[WF.PATH]=body+b'\n'
try:check('wrong workflow working bytes refuse',lambda:refuses(lambda:WF.verify(root,fakegit)))
finally:bodies[WF.PATH]=body
original=bodies[LD.PATH];native=original[:9]+b'\x03'+original[10:];check('unchanged exact ledger OS-byte classifier accepts only actual known payload',lambda:LD.classify(LD.PATH,original,native))
check('different gzip path refuses',lambda:refuses(lambda:LD.classify('chicago/4d/data/other.gz',original,native)))
changed=bytearray(native);changed[-8]^=1;check('ledger non-OS byte drift refuses',lambda:refuses(lambda:LD.classify(LD.PATH,original,bytes(changed))))
changed=bytearray(native);changed[9]=0;check('ledger alternative OS byte refuses',lambda:refuses(lambda:LD.classify(LD.PATH,original,bytes(changed))))
tree=ast.parse((P/'transport/publish_native.py').read_text());predicate=next(n.test for n in ast.walk(tree)if isinstance(n,ast.Assert)and isinstance(n.msg,ast.Constant)and str(n.msg.value).startswith('Code transport scope'));expr=compile(ast.Expression(predicate),'<actual transport scope predicate>','eval');changes={WF.PATH:(WF.MODE,'blob',WF.BLOB)}
check('actual transport inherited workflow tuple scope accepts',lambda:exec('assert eval(expr,globals())'))
changes={WF.PATH:('100755','blob',WF.BLOB)};check('actual transport workflow executable-mode drift refuses',lambda:exec('assert not eval(expr,globals())'))
changes={WF.PATH:None};check('actual transport workflow deletion refuses',lambda:exec('assert not eval(expr,globals())'))
node=next(n for n in ast.walk(tree)if isinstance(n,ast.If)and ast.unparse(n.test)=='IW.WF.PATH in changes');code=compile(ast.fix_missing_locations(ast.Module(body=node.body,type_ignores=[])),'<actual inherited workflow parent predicates>','exec');changes={WF.PATH:(WF.MODE,'blob',WF.BLOB)};args=types.SimpleNamespace(base=WF.PARENT);c={'parents':[WF.PARENT,IW.INCOMING]};available={IW.INCOMING:{'tree':'incoming'}};leaves=lambda t:{WF.PATH:(WF.MODE,'blob',WF.BLOB)}
check('actual transport requires exact genuine430+35 inherited parents',lambda:exec(code,globals()))
c={'parents':[WF.PARENT,'0'*40]};check('different incoming native parent refuses',lambda:refuses(lambda:exec(code,globals())))
c={'parents':['0'*40,IW.INCOMING]};args.base='0'*40;check('different declared base/native first parent refuses',lambda:refuses(lambda:exec(code,globals())))
for p in P.rglob('*.py'):ast.parse(p.read_bytes())
assert (P/'ledger_os.py').read_bytes()==Path('/workspace/PR1456-next1af-v2-helper-prep-first-fort-20261030/ledger_os.py').read_bytes()
(P/'STATIC-READONLY-TESTS.json').write_text(json.dumps({'status':'PASS','tests':rows,'all_helpers_AST_parsed':True,'ledger_classifier_byte_identical_V2':True,'helper_main_or_primary_Git_native_source_browser_commands_run':False,'payloads_RAM_only':True,'CPU_affinity':'CPU2'},indent=2)+'\n');print(json.dumps({'PASS':len(rows),'no_primary_operations':True}))
