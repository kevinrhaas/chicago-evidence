"""Only the exact already-merged PR1478 workflow inherited from the incoming dev parent."""
from pathlib import Path
import hashlib,json
PATH='.github/workflows/chicago-4d-moving-frames.yml'
MODE='100644'
BLOB='06f8ecab0758dff2aa67a11d9b179a18e2488458'
SHA256='d4147454a1cb572a8315c87758cfa7e08fa4620cf02a8ec63f82e81897b8faef'
INCOMING='35efd89976913d8739245c98367a2b2166fd17e9'
PARENT='430557a76ad9c8fc70f0fbfb353765bfe8c83857'
MERGED1478='f0b920e238798dbfc2873b6339b090e2d9c61b56'
PROOF_SHA256='e89eb8c4d6f48ea77aaab302fb785746596ff5be30dd5ef934b26b697670faf5'
def proof():
 p=Path(__file__).parent/'INHERITED-WORKFLOW-API-PROOF.json';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==PROOF_SHA256
 d=json.loads(raw);assert d['status']=='READONLY_API_35EF_INHERITS_EXACT_ALREADY_MERGED_PR1478_WORKFLOW'and d['incoming']==INCOMING and d['path']==PATH and d['mode']==MODE and d['blob']==BLOB and d['sha256']==SHA256 and d['bytes']==4972
 assert d['tree']=='8ea1ad6bdc87df3f1d57415bbab98fe6ae6357fa'and d['tree_trace'][-1]['sha']==BLOB and d['tree_trace'][-1]['mode']==MODE
 pr=d['PR1478'];assert pr['number']==1478 and pr['merged']is True and pr['base_ref']=='dev'and pr['merge_commit_sha']==MERGED1478
 assert d['ancestor_proof']['status']=='ahead'and d['ancestor_proof']['merge_base']==MERGED1478
 prior=d['inherited_fixed_blob_payload_proof'];assert hashlib.sha256(Path(prior['path']).read_bytes()).hexdigest()==prior['sha256'];return d
def verify(root,git,working=True,index=True):
 proof();assert git('ls-tree',INCOMING,'--',PATH).decode().strip()==MODE+' blob '+BLOB+'\t'+PATH
 if index:assert git('ls-files','--stage','--',PATH).decode().strip()==MODE+' '+BLOB+' 0\t'+PATH
 if working:assert hashlib.sha256((root/PATH).read_bytes()).hexdigest()==SHA256
 return {'path':PATH,'mode':MODE,'inherited_blob':BLOB,'sha256':SHA256,'incoming':INCOMING,'already_merged_PR':1478,'proof_sha256':PROOF_SHA256}
