from pathlib import Path
from urllib.request import Request,urlopen
import os,sys,json,subprocess,datetime,hashlib,re

O=Path(__file__).parent; R=Path('/workspace/PR1456-fixed-branch-native-relap-prep-publisher-20261030/lock-scratch')
OLD='f4601adf14cdda4eed5370eab728133f71954713';EMPTY='4b825dc642cb6eb9a060e54bf8d69288fbee4904';CODE='430557a76ad9c8fc70f0fbfb353765bfe8c83857'
BRANCH='steward/t2381-t2373-t2384-t2377-early-pictures-20261029';REF='refs/heads/lap/pr-1456'
assert len(sys.argv)==4 and sys.argv[1:3]==['--root-phase','closed-native35-readonly-fullgate'], 'PREPARE ONLY: require actual root closed-native/read-only-gate handoff and exact staged tree'
TREE=sys.argv[3];assert re.fullmatch('[0-9a-f]{40}',TREE)
assert not (O/'RESULT.json').exists(), 'Do not duplicate renewal'
os.sched_setaffinity(0,{2});os.nice(19)
E=dict(os.environ,PATH=str(O/'bin')+':'+os.environ['PATH'],NODE_DISABLE_COMPILE_CACHE='1',PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',TMPDIR=str(O))
def save(n,j):(O/n).write_text(json.dumps(j,indent=2)+'\n')
def api(path):
 with urlopen(Request('https://api.github.com/repos/kevinrhaas/chicago/'+path,headers={'User-Agent':'Chicago-live-sameowner-ownlap-renewal','Cache-Control':'no-cache'}),timeout=45) as f:return json.load(f)
def refs():
 s=subprocess.check_output(['/usr/local/bin/git','-c','protocol.https.allow=always','-c','protocol.http.allow=never','ls-remote','--refs','https://github.com/kevinrhaas/chicago.git'],env=E,text=True)
 return {name:sid for sid,name in map(str.split,s.splitlines())}
def free(p):s=os.statvfs(p);return s.f_bavail*s.f_frsize
closed=Path('/workspace/PR1456-final35ef-native61-root-20261030/CLOSED-FINAL.json');c=json.loads(closed.read_bytes())
assert c['head']==CODE and c['merge_parent'].startswith('35ef') and c['tree']==TREE
assert c.get('native61_last_lap_unchanged') and c.get('all_models_exact')==2073 and c.get('all44_canonical_binary_bytes_exact')
assert free('/workspace')>=536870912+8*1024**2 and free('/tmp')>=1800000000
assert hashlib.sha256((R/'tools/ticket.mjs').read_bytes()).hexdigest()=='34c9f9db3cd6f1091ef075ad1bf77874a9e3f064e9e3ea4e633dc6d5569c5e90'
before=refs();assert before[REF]==OLD and before['refs/heads/'+BRANCH]==CODE
marker=api('git/commits/'+OLD);assert marker['tree']['sha']==EMPTY and not marker['parents'] and marker['author']['name']=='polecat-steward' and marker['author']['email']=='steward@polecat.live'
assert marker['message'].startswith('lap PR #1456 — Codex four-building current-dev generated-data repair ')
created=datetime.datetime.fromisoformat(marker['committer']['date'].replace('Z','+00:00'));assert datetime.datetime.now(datetime.timezone.utc)<created+datetime.timedelta(hours=3), 'This is a LIVE same-owner renewal only; reassess expired owner explicitly'
save('BEFORE.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':marker,'refs':before,'same_live_owner':True,'source_closed_native_receipt_sha256':hashlib.sha256(closed.read_bytes()).hexdigest(),'source_head':CODE,'source_staged_tree':TREE,'source_binding_from_closed_external_receipt_no_primary_operations':True,'workspace_free':free('/workspace'),'tmp_free':free('/tmp')})
cmd=['node','tools/ticket.mjs','lap','1456','--force','--by','Codex four-building current-dev generated-data repair']
q=subprocess.run(cmd,cwd=R,env=E,capture_output=True,text=True,timeout=120);(O/'NATIVE.log').write_text(q.stdout+q.stderr);print(q.stdout+q.stderr,flush=True)
assert q.returncode==0, 'No successful renewal claimed; inspect exact native log/newmarker'
new=json.loads((O/'NEW-MARKER.json').read_bytes());sid=new['sha'];actual=api('git/commits/'+sid);after=refs()
assert actual['tree']['sha']==EMPTY and not actual['parents'] and actual['message'].rstrip()==new['message'].rstrip()
assert after[REF]==sid and after['refs/heads/'+BRANCH]==CODE and sid!=OLD
foreign_changes={k:{'before':before.get(k),'after':after.get(k)} for k in before.keys()|after.keys() if k!=REF and before.get(k)!=after.get(k)}
dt=datetime.datetime.fromisoformat(actual['committer']['date'].replace('Z','+00:00'))
result={'status':'ACTUAL_LIVE_SAME_OWNER1456_ATOMIC_LAP_RENEWAL_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_sha':OLD,'new_sha':sid,'sha':sid,'created':dt.isoformat(),'expires':(dt+datetime.timedelta(hours=3)).isoformat(),'owner':actual,'native_exit':q.returncode,'unchanged_code_head':CODE,'source_staged_tree':TREE,'all_advertised_foreign_refs_unchanged':not foreign_changes,'foreign_ref_changes':foreign_changes,'only_own_marker_write_allowed':True,'no_release_gap':True,'primary_source_Git_operations':False,'wording_qualification':'Native --force may say stole a dead lap; oldf460 was actually LIVE and owned by this same userthread. Exactbefore/after owners are saved; onlyownmarker atomicexactOLDlease replacement, no codeforce.'}
save('RESULT.json',result);Path('/workspace/PR1456-OWN-LAP-CURRENT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
assert not foreign_changes, 'Own marker renewed, but concurrent advertised foreign refs changed; report honestly rather than claiming all unchanged'
