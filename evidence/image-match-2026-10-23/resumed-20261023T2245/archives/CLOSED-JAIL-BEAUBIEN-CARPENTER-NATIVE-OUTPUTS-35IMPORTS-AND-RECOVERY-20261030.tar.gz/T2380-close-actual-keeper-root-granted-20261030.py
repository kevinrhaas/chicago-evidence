from pathlib import Path
import datetime,hashlib,importlib.util,json,os,shutil,stat,subprocess
os.sched_setaffinity(0,{2});os.nice(19)
P=Path('/workspace/T2380-native-one-keeper-v2-prep-20261030');R=P/'run';O=Path('/workspace/T2380-actual-one-keeper-closure-20261030');A=Path('/workspace/chicago/chicago/4d');C=A.parents[1];HEAD='430557a76ad9c8fc70f0fbfb353765bfe8c83857';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');h=lambda b:hashlib.sha256(b).hexdigest();sha=lambda p:h(p.read_bytes());free=lambda p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize;save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(C),*args],env=E)
def primary_state():
 return {'HEAD':git('rev-parse','HEAD').decode().strip(),'index_sha256':sha(C/'.git/index'),'config_sha256':sha(C/'.git/config'),'status':git('status','--porcelain=v1').decode(),'refs':git('show-ref').decode().splitlines()}
before=primary_state();
if O.exists():assert not(O/'RETIREMENT.json').exists() and json.loads((O/'PRIMARY-BEFORE.json').read_text())==before
assert before['HEAD']==HEAD and not before['status'] and not(C/'.git/MERGE_HEAD').exists();assert free('/workspace')>536870912+4000000
spec=importlib.util.spec_from_file_location('oldkeeper',P/'controller.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.baseline_guard();m.checked_source_guard(HEAD)
for rel in ['receipts/KEEPER/BUILD-REAPER.json','receipts/KEEPER/WEB-REAPER.json','receipts/KEEPER-CAPTURE/PHOTO-REAPER.json']:
 x=json.loads((R/rel).read_text());assert x['all_children_reaped']and x['command_exit']==0
# No child or file consumer may still own the retired task fixture or cache trees.
retired_dirs=[R/x for x in ['fixture','tmp','cache','config']]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:
  cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  assert not any(str(d)+'/' in cmd for d in retired_dirs),('active command uses old runtime',proc.name)
  for fd in (proc/'fd').iterdir():
   try:target=os.readlink(fd)
   except OSError:continue
   assert not any(target==str(d)or target.startswith(str(d)+'/')for d in retired_dirs),('active file consumer',proc.name,target)
 except (PermissionError,FileNotFoundError,ProcessLookupError):continue
O.mkdir(exist_ok=True);save(O/'PRIMARY-BEFORE.json',before);copied=[]
def copy(rel,target=None):
 p=R/rel;assert p.is_file()and not p.is_symlink();dst=O/(target or rel);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst);assert p.read_bytes()==dst.read_bytes() and stat.S_IMODE(p.stat().st_mode)==stat.S_IMODE(dst.stat().st_mode);copied.append({'old':str(p),'preserved':str(dst),'bytes':dst.stat().st_size,'mode':oct(stat.S_IMODE(dst.stat().st_mode)),'sha256':sha(dst)})
for n in ['NATIVE-COMPILER-CONTROL.json','EXECUTION-START.json','INITIAL-REGISTRIES.json']:copy(n)
for p in sorted((R/'receipts').rglob('*')):
 if p.is_file()and not p.is_symlink():copy(str(p.relative_to(R)))
for n in ['data/structures/log_jail_keeper_house.json','data/sidecars/1835/log_jail_keeper_house.json','data/sidecars/1835/log_jail.json','data/reference_views/log_jail_keeper_house/gale_1902.json','data/reference_views/log_jail_keeper_house/gale_1902.match.json','data/enclosures/index.json','data/enclosures/log_jail_palisade.json','assets/manifest.json','assets/manifest.web.json','assets/manifest.versions.json','assets/gltf/log_jail_keeper_house__frame_1835.glb','assets/web/log_jail_keeper_house__frame_1835.glb']:copy('fixture/'+n,'native/'+n)
copy('capture/gale_1902-side-by-side.jpg')
raw=list((R/'tmp').glob('photo-match-*/gale_1902-render.png'));assert len(raw)==1;copy(str(raw[0].relative_to(R)),'capture/gale_1902-render.png')
photo=Path(m.PLAN['original_photo']['source']);dst=O/'source/gale_1902-full-original.jpg';dst.parent.mkdir(exist_ok=True);shutil.copy2(photo,dst);assert sha(dst)==m.PLAN['original_photo']['sha256'];copied.append({'old':str(photo),'preserved':str(dst),'bytes':dst.stat().st_size,'mode':oct(stat.S_IMODE(dst.stat().st_mode)),'sha256':sha(dst)})
rootlog=Path('/workspace/T2380-keeper-v2-native-execution-root-20261030.log');shutil.copy2(rootlog,O/'root-execution.log');assert rootlog.read_bytes()==(O/'root-execution.log').read_bytes()
(O/'ROOT-REVIEW.md').write_text('''# Root direct review — native first keeper capture\n\nRoot reported directly viewing the full Gale comparison after BUILD1.112s, WEB3.322s and PHOTO3.368s all exited0/reaped. The native keeper is large and clipped at the upper edge; compound alignment is not qualified. This misframed comparison gives no geometry acceptance. No271default controls were launched. The raw match remains unreviewed, no grade or original-ticket DONE is claimed. This note records the parent’s review, not a new image verdict or another capture. Source1836 depiction versus July1835 continuity remains reconstructed.\n''')
asset=O/'native/assets/gltf/log_jail_keeper_house__frame_1835.glb';assert sha(asset)=='e613511742b21a569ae21880555b1d40053e7afec4eb01bd6c1a4182992e8fb2';rec=json.loads((O/'receipts/KEEPER/CLOSED-RESULT.json').read_text());assert rec['assets'][0]['native_master_entry']['inputs_sha256']==m.PLAN['expected_keeper_recipe_sha256'];assert sha(O/'native/assets/web/log_jail_keeper_house__frame_1835.glb')==rec['assets'][0]['actual_web']['sha256']
# Restore every actual unique output from a durable regular copy; unchanged code
# from a verified source path plus checked430 Git blob; aliases restore as links.
preserved={r['old']:r for r in copied};copy_rows={str((R/'fixture'/r['relative'])):r for r in m.PLAN['copies']};ledger=[]
for d in retired_dirs:
 for root,ds,fs in os.walk(d,followlinks=False):
  for n in ds+fs:
   p=Path(root)/n;s=p.lstat();row={'path':str(p),'mode':oct(stat.S_IMODE(s.st_mode)),'mtime_ns':s.st_mtime_ns}
   if p.is_symlink():row.update(kind='symlink',restore_target=os.readlink(p))
   elif p.is_dir():row.update(kind='directory')
   elif p.is_file():
    row.update(kind='regular',bytes=s.st_size,sha256=sha(p))
    if str(p)in preserved:row['restore']=preserved[str(p)]['preserved']
    elif str(p)in copy_rows:
     specrow=copy_rows[str(p)];src=Path(specrow['postimage']or specrow['source']);assert p.read_bytes()==src.read_bytes();row['restore']=str(src)
     if not specrow['postimage']:row['checked_Git_fallback']={'head':HEAD,'path':'chicago/4d/'+specrow['relative']}
    elif p.suffix=='.pyc' and '__pycache__'in p.parts:
     py=p.parent.parent/(p.name.split('.cpython-',1)[0]+'.py');assert str(py)in copy_rows and py.is_file();specrow=copy_rows[str(py)];authority=Path(specrow['postimage']or specrow['source']);assert py.read_bytes()==authority.read_bytes();row['restore']='Regenerated pinned-Blender Python bytecode cache; not a unique native model/public output';row['source_authority']={'path':str(authority),'sha256':sha(authority),'fixture_source':str(py)}
    elif any(p.is_relative_to(q)for q in [R/'tmp',R/'cache',R/'config']):row['restore']='Regenerated owned private runtime/cache state; no unique source or public output and no private profile payload archived.'
    else:raise AssertionError('Unpreserved unique fixture regular file: '+str(p))
   else:raise AssertionError('Unexpected runtime object '+str(p))
   ledger.append(row)
save(O/'RESTORE-LEDGER.json',{'status':'ALL_UNIQUE_NATIVE_OUTPUTS_PRESERVED_BEFORE_OWN_INACTIVE_RUNTIME_RETIREMENT','owned_roots':[str(p)for p in retired_dirs],'rows':ledger,'copied_outputs':copied,'aliases_only_no_symlink_targets_removed':True,'checked_source_head':HEAD,'restore_instructions':'Recreate declared directories and symlinks, copy each regular source listed by restore after checking its hash/mode, use checked430 Git fallback only when a primary code source has since changed. Recreate owned private caches empty. Never restore over a newer primary or selected keeper output.'})
assert primary_state()==before
for row in copied:
 p=Path(row['preserved']);assert sha(p)==row['sha256']and p.stat().st_size==row['bytes']
free_before=free('/workspace')
for d in retired_dirs:assert d.parent==R and not d.is_symlink();shutil.rmtree(d)
after=primary_state();assert after==before;m.baseline_guard();save(O/'PRIMARY-AFTER.json',after)
save(O/'RETIREMENT.json',{'status':'ONLY_OWN_INACTIVE_KEEPER_FIXTURE_TMP_CACHE_CONFIG_RETIRED_ALL_UNIQUE_OUTPUTS_PRESERVED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workspace_free_before':free_before,'workspace_free_after':free('/workspace'),'reclaimed_bytes':free('/workspace')-free_before,'primary_HEAD_index_config_status_refs_and_all271_inputs_unchanged':True,'all_three_actual_reapers_closed':True,'no_active_consumers_before_retirement':True,'private_profile_payload_archived':False,'original_controller_and_all_old_packets_untouched':True})
files=[]
for p in sorted(O.rglob('*')):
 if p.is_file():b=p.read_bytes();files.append({'path':str(p.relative_to(O)),'bytes':len(b),'sha256':h(b),'mode':oct(stat.S_IMODE(p.stat().st_mode))})
save(O/'CLOSED-MANIFEST.json',{'status':'CLOSED_ACTUAL_ONE_KEEPER_NATIVE_OUTPUTS_WITH_QUALIFIED_NEGATIVE_FRAMING_REVIEW','closed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'total_bytes':sum(r['bytes']for r in files),'native_keeper_recipe':m.PLAN['expected_keeper_recipe_sha256'],'native_MASTER_sha256':sha(asset),'no_geometry_acceptance_or_matches_grade_or_DONE':True,'default271controls_not_run':True,'runtime_roots_retired_after_complete_unique_public_closure':True})
print(json.dumps({'closure':str(O),'files':len(files),'bytes':sum(r['bytes']for r in files),'manifest_sha256':sha(O/'CLOSED-MANIFEST.json'),'retirement':json.loads((O/'RETIREMENT.json').read_text())},indent=2))
