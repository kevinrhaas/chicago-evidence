"""Preview entrywise Carpenter adoption; apply only reviewed clean post1456 branch under root lease."""
from pathlib import Path
import argparse,copy,datetime,hashlib,json,os,shutil,subprocess,sys
from urllib.request import Request,urlopen
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import core
PLAN=json.loads((P/'PLAN.json').read_text());E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def need(c,m):
 if not c:raise RuntimeError(m)
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(core.dump(x))
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],env=E)
def state(repo):
 return {'head':git(repo,'rev-parse','HEAD').decode().strip(),'tree':git(repo,'rev-parse','HEAD^{tree}').decode().strip(),'branch':git(repo,'branch','--show-current').decode().strip(),'status':git(repo,'status','--porcelain=v1','--untracked-files=all').decode(),'config_sha256':core.pf(repo/'.git/config'),'index_sha256':core.pf(repo/'.git/index')}
def api(path):
 with urlopen(Request('https://api.github.com/repos/kevinrhaas/chicago/'+path,headers={'User-Agent':'Chicago-Carpenter-fresh-post1456-entrywise-preflight'}),timeout=45)as r:return json.load(r)
def post1456(repo,args):
 need(args.expect_dev and args.merged_1456 and args.expect_branch,'Clean apply needs actual dev/fold,1456squash and feature branch')
 s=state(repo);need(s['head']==args.expect_head and s['branch']==args.expect_branch and s['branch'].startswith('steward/t2382-'),'Wrong clean Carpenter branch');need(not s['status']and not(repo/'.git/MERGE_HEAD').exists(),'Source must be clean, outside1456 merge')
 need(git(repo,'rev-parse','origin/dev').decode().strip()==args.expect_dev,'Local dev changed; rebind')
 for earlier,later in [(args.merged_1456,args.expect_dev),(args.expect_dev,args.expect_head)]:subprocess.run(['git','-C',str(repo),'merge-base','--is-ancestor',earlier,later],env=E,check=True)
 pr=api('pulls/1456');dev=api('git/ref/heads/dev');need(pr['merged']and pr['merge_commit_sha']==args.merged_1456,'Actual1456merge not proved');need(dev['object']['sha']==args.expect_dev,'Remote dev advanced; rebind before apply')
 return {'merged_PR':1456,'merge_commit_sha':args.merged_1456,'reviewed_dev_tip':args.expect_dev,'head':s['head'],'branch':s['branch']}
def bindings(repo):
 out={}
 for r in PLAN['source_bindings']:need(core.pf(repo/r['repo_path'])==r['sha256'],'Source/context drift needs explicit review: '+r['repo_path'])
 for r in PLAN['donor_bindings']:need(core.pf(Path(r['path']))==r['sha256'],'Closed authority donor changed')
 return out
def compose(repo):
 bindings(repo);capture_proof=core.capture_reuse(repo);A=repo/'chicago/4d';out={};pre={}
 source_rel='chicago/4d/data/structures/'+core.SID+'.json';current=json.loads((repo/source_rel).read_text());need(current['phases'][0]['id']=='log_1832','Phase order changed; rebind source operations');candidate=core.apply_ops(current,PLAN['structure_operations'])
 for r in PLAN['direct_postimages']:
  rel=r['repo_path'];p=repo/rel;before=core.pf(p)if p.is_file()else None;pre[rel]=before
  if rel==source_rel:body=core.dump(candidate)
  else:
   need(before==r['before_sha256'],'Direct target drift requires reviewed rebind: '+rel);body=(P/r['postimage']).read_bytes();need(core.sha(body)==r['after_sha256'],'Postimage donor changed')
  out[rel]=body
 for r in PLAN['native_registry_operations']:
  rel=r['repo_path'];p=repo/rel;pre[rel]=core.pf(p);d=json.loads(p.read_text());old=copy.deepcopy(d);need(d[r['map_key']][r['entry_key']]==r['before_entry'],'Target native entry changed');d[r['map_key']][r['entry_key']]=r['after_entry'];need({k:v for k,v in old[r['map_key']].items()if k!=r['entry_key']}=={k:v for k,v in d[r['map_key']].items()if k!=r['entry_key']},'Foreign native map row changed');need({k:v for k,v in old.items()if k!=r['map_key']}=={k:v for k,v in d.items()if k!=r['map_key']},'Foreign native root metadata changed');out[rel]=core.dump(d)
 fragment=json.loads(Path(PLAN['STORE_fragment']).read_text());rel=fragment['repo_path'];p=repo/rel;pre[rel]=core.pf(p);store=json.loads(p.read_text());need(all(store[k]==v for k,v in fragment['base_root_fields'].items()),'STORE host metadata changed; rebind hosted URLs')
 for key,value in fragment['actual_native_new_files'].items():
  need(key not in store['files']or store['files'][key]==value,'Conflicting owned STORE row');store['files'][key]=value
 store['bytes']=sum(r['bytes']for r in store['files'].values());out[rel]=core.dump(store)
 append=Path(PLAN['liberties_append']).read_text();rel='chicago/4d/docs/LIBERTIES.md';p=repo/rel;pre[rel]=core.pf(p);prefix=p.read_bytes();need(b'### L-carpenter-low-roof-gable-2382 'not in prefix,'Liberty already present');out[rel]=prefix+append.encode()
 rel='chicago/4d/changelog.d/T-2382.json';need(not(repo/rel).exists(),'Existing ticket changelog entry requires review');pre[rel]=None;out[rel]=core.dump(PLAN['changelog'])
 stream=json.loads(out['chicago/prairie_1904_v1/research/images/stream-carpenter-picture-references.json']);proof=core.native_proofs(repo,candidate,stream,store,append);proof['canonical_capture_binding_proof']=capture_proof
 return out,pre,proof

def preview(args):
 repo=Path(args.repo).resolve();need(state(repo)['head']==args.expect_head,'HEAD changed');allow=args.snapshot_during_merge;future=None
 if allow:need(not args.apply_reviewed,'Merge snapshot cannot apply')
 else:future=post1456(repo,args)
 before=state(repo);out,pre,proof=compose(repo);foreign=core.foreign_fingerprints(repo);target=Path(args.out).resolve();need(not target.exists(),'Review output already exists');target.mkdir(mode=0o700);rows=[]
 for rel,body in out.items():
  dest=target/'postimages'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body);rows.append({'repo_path':rel,'postimage':str(dest),'before_sha256':pre[rel],'after_sha256':core.sha(body),'bytes':len(body),'mode':oct(dest.stat().st_mode&0o777)})
 need(state(repo)==before,'Source state changed during preview');save(target/'NATIVE-READONLY-PROOFS.json',proof);save(target/'REVIEW.json',{'status':'CURRENT_ENTRYWISE_POSTIMAGES_REVIEW_ONLY_NOT_APPLIED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repo':str(repo),'source_state':before,'snapshot_during_merge':allow,'post1456_proof':future,'rows':rows,'foreign_fingerprints':foreign,'native_recipe':proof['native_recipe'],'no_bake_or_capture_needed_if_fixed_inputs_remain_exact':True,'current_app_BOTH_not_claimed':'Dated2b proof retained; current runtime and published bytes must be independently rebound','no_primary_writes':True})
 print(json.dumps({'status':'REVIEW_READY_NOT_APPLIED','files':len(rows),'native_recipe':proof['native_recipe'],'foreign_library_rows_exact':proof['foreign_current_library_rows_exact'],'foreign_picture_entries_exact':proof['all_foreign_picture_entries_exact'],'foreign_liberties_exact':proof['foreign_current_liberty_rows_and_order_exact'],'review':str(target/'REVIEW.json')},indent=2))

def apply_reviewed(args):
 need(os.environ.get('CB_ENTRYWISE_SOURCE_LEASE')=='root-approved-clean-post1456-branch','Root source lease required');repo=Path(args.repo).resolve();post1456(repo,args);review=json.loads((Path(args.apply_reviewed)/'REVIEW.json').read_text());need(not review['snapshot_during_merge']and review['post1456_proof'],'Old merge snapshot is never apply authority');need(state(repo)==review['source_state'],'Reviewed clean state changed');bindings(repo)
 need(shutil.disk_usage('/workspace').free>=536870912+8*1024*1024 and shutil.disk_usage('/tmp').free>=1800000000,'Caller floor/reserve');before=core.foreign_fingerprints(repo);need(before==review['foreign_fingerprints'],'Foreign input rows changed; rebind');out,pre,proof=compose(repo);need(proof['native_recipe']==review['native_recipe'],'Actual recipe changed; rebuild owed')
 rows=review['rows'];need(set(out)=={r['repo_path']for r in rows},'Scope changed')
 for r in rows:
  need(core.sha(out[r['repo_path']])==r['after_sha256']and pre[r['repo_path']]==r['before_sha256'],'Reviewed proposed bytes changed');need(core.pf(Path(r['postimage']))==r['after_sha256'],'Reviewed external postimage changed')
 # No Git add/commit/ref operation: root runs the separately declared native owners and gate.
 for r in rows:
  dest=repo/r['repo_path'];need(not dest.is_symlink(),'Refuse source output symlink');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(out[r['repo_path']])
 need(core.foreign_fingerprints(repo)==before,'Foreign map/library/grade/source/jaunt rows changed');need(git(repo,'rev-parse','HEAD').decode().strip()==args.expect_head,'HEAD changed during apply')
 save(Path(args.apply_reviewed)/'APPLIED-SOURCE-ONLY.json',{'status':'EXACT_REVIEWED_ENTRYWISE_SOURCE_ONLY_APPLIED_NO_NATIVE_OWNER_GATE_OR_COMMIT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':args.expect_head,'rows':rows,'foreign_fingerprints_exact':True,'native_recipe_reused':proof['native_recipe'],'native_owners_publish_targeted_current_BOTH_phone_fullcheck_PR_merge_settle_pending':True});print('Source-only applied; native owners and qualification remain pending.')

def verify_native(args):
 repo=Path(args.repo).resolve();need(git(repo,'rev-parse','HEAD').decode().strip()==args.expect_head,'HEAD changed during native qualification');review=json.loads((Path(args.verify_native)/'REVIEW.json').read_text());need(core.foreign_fingerprints(repo)==review['foreign_fingerprints'],'A foreign registry/library/grade/source-detail/jaunt row changed under native owners')
 A=repo/'chicago/4d';L=repo/'chicago/prairie_1904_v1';pics=json.loads((A/'data/pictures/1835.json').read_text())['by_structure'][core.SID];expected=json.loads((Path(args.verify_native)/'NATIVE-READONLY-PROOFS.json').read_text());need(pics==expected['candidate_held_pictures'],'Actual current native picture tiles changed');side=json.loads((A/f'data/sidecars/1835/{core.SID}.json').read_text());need(side['grade']==expected['native_candidate_grade'],'Native target grade differs');need(len({r['id']for r in json.loads((L/'data/images.json').read_text())['images']} & core.IDS)==2,'Both library records missing')
 cmd=['node','tools/image_gate.mjs','--structure',core.SID];q=subprocess.run(cmd,cwd=A,env=E,capture_output=True,text=True);need(q.returncode==0,'Actual native image gate failed: '+q.stdout+q.stderr);print(json.dumps({'status':'CURRENT_NATIVE_FOREIGN_ROWS_TARGET_PICTURES_GRADE_AND_IMAGE_GATE_PASS','source_only_not_fullgate_or_APP_BOTH':True,'output':q.stdout},indent=2))

def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',default='/workspace/chicago');p.add_argument('--expect-head',required=True);p.add_argument('--expect-branch');p.add_argument('--expect-dev');p.add_argument('--merged-1456');p.add_argument('--out');p.add_argument('--snapshot-during-merge',action='store_true');p.add_argument('--apply-reviewed');p.add_argument('--verify-native');a=p.parse_args()
 if a.apply_reviewed:apply_reviewed(a)
 elif a.verify_native:verify_native(a)
 else:need(a.out,'Preview needs new --out');preview(a)
if __name__=='__main__':main()
