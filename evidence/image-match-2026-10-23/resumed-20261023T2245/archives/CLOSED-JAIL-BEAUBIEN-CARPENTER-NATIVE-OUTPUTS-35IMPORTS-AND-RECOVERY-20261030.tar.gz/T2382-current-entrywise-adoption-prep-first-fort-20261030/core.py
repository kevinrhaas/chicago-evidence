"""Carpenter source composition only. Native derivation bodies stay unchanged and read-only."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
SID='philo_carpenter_log_shop';NAME=SID+'__log_1832.glb'
C=Path('/workspace/T2382-canonical-capture-prep-20261030');H=Path('/workspace/T2382-images-native-hosting-20261030');N=Path('/workspace/T2382-native-selected-bake-prep-20261030');V=Path('/workspace/T2382-native-sidecar-app-prep-20261030')
IDS={'early-carpenter-trowbridge-1902','early-carpenter-kurz-allison-1893-panel14'}
SOURCES={'andreas_1884_sauganash_hotel_plate','trowbridge_sauganash_hotel','kurz_allison_1893'}
sha=lambda b:hashlib.sha256(b).hexdigest()
pf=lambda p:sha(p.read_bytes())
canon=lambda x:sha(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
def dump(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def loadmod(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
def pointer(doc,path):
 for p in path:doc=doc[p]
 return doc
def differences(a,b,path=()):
 if isinstance(a,dict)and isinstance(b,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   if k not in a:out.append({'path':[*path,k],'present':False,'after':b[k]})
   elif k not in b:out.append({'path':[*path,k],'present':True,'before':a[k],'delete':True})
   else:out+=differences(a[k],b[k],(*path,k))
  return out
 if isinstance(a,list)and isinstance(b,list)and len(a)==len(b):return [r for i,(x,y)in enumerate(zip(a,b))for r in differences(x,y,(*path,i))]
 return []if a==b else[{'path':list(path),'present':True,'before':a,'after':b}]
def apply_ops(doc,ops):
 out=copy.deepcopy(doc)
 for r in ops:
  parent=pointer(out,r['path'][:-1]);key=r['path'][-1];exists=(isinstance(parent,list)and isinstance(key,int)and key<len(parent))or(isinstance(parent,dict)and key in parent)
  assert exists==r['present'],r['path']
  if exists:assert parent[key]==r['before'],r['path']
  if r.get('delete'):del parent[key]
  else:parent[key]=copy.deepcopy(r['after'])
 return out
class InputOverlay:
 def __init__(self,path,overrides):self.path=Path(path);self.overrides=overrides
 def __truediv__(self,part):return InputOverlay(self.path/part,self.overrides)
 def __fspath__(self):return str(self.path)
 def __str__(self):return str(self.path)
 def __lt__(self,other):return str(self)<str(other)
 def __getattr__(self,name):return getattr(self.path,name)
 def is_file(self):return str(self.path)in self.overrides or self.path.is_file()
 def exists(self):return str(self.path)in self.overrides or self.path.exists()
 def read_text(self,*args,**kwargs):return self.overrides.get(str(self.path),None)if str(self.path)in self.overrides else self.path.read_text(*args,**kwargs)
 def glob(self,pattern):
  found={str(p):p for p in self.path.glob(pattern)}
  for name in self.overrides:
   p=Path(name)
   if p.parent==self.path and p.match(pattern):found[name]=p
  return [InputOverlay(p,self.overrides)for p in found.values()]
def native_proofs(repo,candidate,stream,store,append):
 A=repo/'chicago/4d';L=repo/'chicago/prairie_1904_v1';sys.path.insert(0,str(A/'generators'));sys.path.insert(0,str(A/'tools'));sys.path.insert(0,str(L/'tools'))
 import mesh_inputs
 entry=json.loads((N/'closed-authority/NATIVE-ENTRIES.json').read_text());recipe=mesh_inputs.structure_inputs_sha(candidate,candidate['phases'][0]);assert recipe==entry['recipe_sha256'],'Recipe changed: genuine selected rebuild required before model reuse'
 lib=loadmod('carpenter_current_native_build_images',L/'tools/build_images.py');old,oldplan,errors=lib.build();assert not errors;current=json.loads((L/'data/images.json').read_text());assert old==current,'Native current library baseline must reproduce'
 overrides={str(L/'research/images/STORE.json'):dump(store).decode(),str(L/'research/images/stream-carpenter-picture-references.json'):dump(stream).decode()};lib.P=InputOverlay(L,overrides);new,newplan,errors=lib.build();assert not errors,errors;assert oldplan==newplan==json.loads((L/'data/site-plan.json').read_text())
 oldrows={r['id']:r for r in old['images']};newrows={r['id']:r for r in new['images']};assert set(newrows)-set(oldrows)==IDS;assert all(newrows[k]==v for k,v in oldrows.items())
 cp=loadmod('carpenter_current_native_pictures',A/'tools/compile_pictures.py');inputs=cp.read_tree();before=cp.derive(*inputs);_,tsv,sources,texts,scenes,views=inputs;texts=copy.deepcopy(texts);texts[SID]=dump(candidate).decode();views=copy.deepcopy(views);views[SID]=[json.loads((C/f'postimages/chicago/4d/data/reference_views/{SID}/{v}.json').read_text())for v in ['andreas-1884','trowbridge-1902','kurz-allison-1893-panel14']];after=cp.derive(new,tsv,sources,texts,scenes,views);foreign=0
 for scene,doc in before.items():
  for other,records in doc['by_structure'].items():
   if other!=SID:assert after[scene]['by_structure'][other]==records;foreign+=1
 hosted=json.loads((H/'HOSTED-RECORDS-CLOSED.json').read_text())['native_compiled_CB_held_pictures'];assert after['1835']['by_structure'][SID]==hosted
 gp=loadmod('carpenter_current_native_grader',A/'tools/grade_structures.py');rulings=gp.load_rulings();grade=gp.grade_structure(SID,'inferred',after['1835']['by_structure'][SID],views[SID],rulings,'1835');assert grade['value']=='attested'and set(grade['pictures'])==IDS|{'early-andreas-1884-sauganash'}
 lc=loadmod('carpenter_current_native_liberties',A/'tools/compile_liberties.py');prefix=(A/'docs/LIBERTIES.md').read_text();assert '### L-carpenter-low-roof-gable-2382 'not in prefix
 class Appended:
  def read_text(self,*a,**k):return prefix+append
  def read_bytes(self):return(prefix+append).encode()
 lc.SOURCE=Appended();newlib,issues=lc.build();assert not issues,issues;oldlib=json.loads((A/'data/liberties.json').read_text());lid='L-carpenter-low-roof-gable-2382';oldL={x['id']:x for x in oldlib['liberties']};newL={x['id']:x for x in newlib['liberties']};assert set(newL)-set(oldL)=={lid};assert all(newL[k]==v for k,v in oldL.items());assert [x['id']for x in newlib['liberties']if x['id']!=lid]==[x['id']for x in oldlib['liberties']];assert newL[lid]['subjects']==[SID]and newL[lid]['section']=='per_subject'and len(newL[lid]['covers'])==2
 return {'native_recipe':recipe,'rebuild_required':False,'foreign_current_library_rows_exact':len(oldrows),'native_library_before':len(oldrows),'native_library_after':len(newrows),'all_current_siteplan_exact':True,'all_foreign_picture_entries_exact':foreign,'candidate_held_pictures':hosted,'native_candidate_grade':grade,'grade_rulings_file_unchanged':True,'foreign_current_liberty_rows_and_order_exact':len(oldL),'native_added_liberty':newL[lid],'pure_native_input_overrides':'Only input source text/stream/STORE in RAM, original native build/derive/grade functions unmodified; no file-emitting main called','library_foreign_rows_digest':canon(old['images']),'current_selected_sidecar_projection':project_sidecar(repo,candidate,new,(new,tsv,sources,texts,scenes,views)),'native_tool_hashes':{str(p.relative_to(repo)):pf(p)for p in [L/'tools/build_images.py',A/'tools/compile_pictures.py',A/'tools/grade_structures.py',A/'tools/compile_liberties.py']}}
def foreign_fingerprints(repo):
 A=repo/'chicago/4d';L=repo/'chicago/prairie_1904_v1';images=json.loads((L/'data/images.json').read_text());store=json.loads((L/'research/images/STORE.json').read_text());newkeys=set(json.loads((H/'APP-STORE-ENTRYWISE-4ROWS.json').read_text())['actual_native_new_files']);out={}
 out['library_foreign_rows']=canon([r for r in images['images']if r['id']not in IDS]);out['library_siteplan']=pf(L/'data/site-plan.json');out['STORE_foreign_rows']=canon({k:v for k,v in store['files'].items()if k not in newkeys});out['STORE_root_fields']=canon({k:v for k,v in store.items()if k not in ['files','bytes']})
 for file,key in [('manifest.json','assets'),('manifest.web.json','masters')]:
  d=json.loads((A/'assets'/file).read_text());out[file+'_foreign_rows']=canon({k:v for k,v in d[key].items()if k!=NAME});out[file+'_root_fields']=canon({k:v for k,v in d.items()if k!=key})
 out['grade_rulings']=pf(A/'data/structure_grades.json');grade_rows={};source_details={};jaunts={}
 for p in (A/'data/sidecars').glob('*/*.json'):
  if p.stem==SID:continue
  d=json.loads(p.read_text())
  if 'grade'in d:grade_rows[str(p.relative_to(A))]=d['grade']
 for p in (A/'data/sidecars/1835/sources').glob('*.json'):
  if p.stem not in SOURCES|{'index'}:source_details[p.name]=pf(p)
 for folder in ['data/jaunts','data/sidecars/1835/jaunts']:
  for p in (A/folder).rglob('*.json'):jaunts[str(p.relative_to(A))]=pf(p)
 out['all_foreign_native_grades']=canon(grade_rows);out['all_foreign_1835_source_details']=canon(source_details);out['jaunts_and_catalogs']=canon(jaunts)
 return out

def capture_reuse(repo):
 """Validate unchanged native rays/source/placement against planned exact model bytes; restamp nothing."""
 import subprocess,os
 code=r'''import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const root=process.argv[1],packet=process.argv[2],approved=process.argv[3];
const{renderGroup,groupReview}=await import('file://'+path.join(root,'chicago/4d/tools/photo_match_group.mjs'));
const app=path.join(root,'chicago/4d'),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),rows=[];
for(const name of ['andreas-1884','trowbridge-1902','kurz-allison-1893-panel14']){
 const rel='chicago/4d/data/reference_views/philo_carpenter_log_shop/'+name+'.json',cameraFile=path.join(packet,'postimages',rel),bytes=fs.readFileSync(cameraFile),cam=JSON.parse(bytes),match=JSON.parse(fs.readFileSync(cameraFile.replace(/\.json$/,'.match.json')));
 let photo=path.resolve(path.dirname(path.join(root,rel)),cam.photo);if(!fs.existsSync(photo))photo=path.join(packet,'postimages',path.relative(root,photo));
 if(sha(bytes)!==match.camera_sha256||sha(fs.readFileSync(photo))!==match.photo_sha256)throw Error('camera/photo drift '+name);
 const group=groupReview(app,renderGroup(app,cam));
 if(group.rendered_members.length!==2||group.rendered_members[0].structure_id!=='philo_carpenter_log_shop'||group.rendered_members[1].structure_id!=='sauganash_hotel')throw Error('unexpected native anchor/context roster');
 // Hash the actual approved planned anchor payload at its unchanged canonical path.
 // This is a planned-postimage verification only; archived native records are never edited.
 group.rendered_members[0].glb_sha256=sha(fs.readFileSync(approved));
 const planned=sha(JSON.stringify(group.rendered_members));
 if(planned!==match.group_sha256||match.glb_sha256!==group.rendered_members[0].glb_sha256||match.verdict!=='matches'||match.differences.some(d=>d.status==='open'))throw Error('native group/verdict drift '+name);
 rows.push({view:name,actual_archived_native_camera_sha256:match.camera_sha256,actual_archived_native_photo_sha256:match.photo_sha256,planned_exact_model_and_current_placement_group_sha256:planned,members:group.rendered_members.length,archived_native_MATCHES_retained:true,restamped:false});
}console.log(JSON.stringify(rows));'''
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
 return json.loads(subprocess.check_output(['node','--input-type=module','-e',code,str(repo),str(C),str(N/'closed-authority/native-master'/NAME)],env=env,text=True))


def project_sidecar(repo,candidate,newimages,new_inputs):
 """Return the unchanged native selected builder before its emission loop; no main/emit."""
 import ast
 A=repo/'chicago/4d';source=A/'tools/compile_scene.py';parsed=ast.parse(source.read_bytes())
 outer=next(n for n in parsed.body if isinstance(n,ast.FunctionDef)and n.name=='compile_scene');nested=next(n for n in outer.body if isinstance(n,ast.FunctionDef)and n.name=='build_sidecar')
 prefix=copy.deepcopy(outer.body[:outer.body.index(nested)+1]);filtered=[];removed=0
 for node in prefix:
  if isinstance(node,ast.Expr)and isinstance(node.value,ast.Call)and isinstance(node.value.func,ast.Attribute)and isinstance(node.value.func.value,ast.Name)and node.value.func.value.id=='outdir'and node.value.func.attr=='mkdir':removed+=1
  else:filtered.append(node)
 assert removed==1
 assert not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='emit'for n in ast.walk(ast.Module(body=filtered,type_ignores=[])))
 selected=copy.deepcopy(outer);selected.name='_selected_native_sidecar_builder';selected.body=filtered+[ast.Return(value=ast.Name(id='build_sidecar',ctx=ast.Load()))]
 assert ast.dump(next(n for n in selected.body if isinstance(n,ast.FunctionDef)),include_attributes=False)==ast.dump(nested,include_attributes=False)
 module=ast.fix_missing_locations(ast.Module(body=[selected],type_ignores=[]));m=loadmod('carpenter_current_native_scene',source);exec(compile(module,str(source),'exec'),m.__dict__)
 sources={}
 for p in sorted((A/'data/sources').glob('*.json')):
  d=m.load(p);sources[d['id']]=d
 scene=m.load(A/'data/scenes/1835.json');target=m.dt.date.fromisoformat(scene['target_date']);old=m.load(A/f'data/structures/{SID}.json');builder=m._selected_native_sidecar_builder('1835',sources,m.load(A/'data/exclusions.json'))
 oldside=m.reader_copy(SID+'.json',builder(old,m.resolve_phase(old,target)));assert oldside==m.load(A/f'data/sidecars/1835/{SID}.json'),'Native old sidecar does not reproduce'
 import compile_pictures as actual_cp
 original=actual_cp.read_tree
 try:
  actual_cp.read_tree=lambda:new_inputs;m._GRADER=None;newside=m.reader_copy(SID+'.json',builder(candidate,m.resolve_phase(candidate,target)))
 finally:actual_cp.read_tree=original
 accepted=json.loads((V/'CANDIDATE-NATIVE-SIDECAR.json').read_text());assert newside==accepted,'Candidate native sidecar drift needs explicit review before historical BOTH reuse'
 return {'old_current_record_native_reproduced':True,'current_candidate_semantically_exact_to_dated_BOTH_candidate':True,'dated_candidate_sha256':pf(V/'CANDIDATE-NATIVE-SIDECAR.json'),'unchanged_nested_builder_AST_sha256':sha(ast.dump(nested,include_attributes=False).encode()),'compiler_sha256':pf(source),'only_adapter_change':'Return original nested builder, omit only outdir.mkdir; never emit/main','does_not_qualify_current_runtime_BOTH':True}
