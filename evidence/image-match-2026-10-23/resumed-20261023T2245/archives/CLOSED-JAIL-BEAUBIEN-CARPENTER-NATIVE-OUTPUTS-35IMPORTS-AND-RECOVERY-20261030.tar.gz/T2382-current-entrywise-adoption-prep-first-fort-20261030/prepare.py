from pathlib import Path
import json,hashlib,sys,shutil,datetime,ast
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import core
R=Path('/workspace/chicago');A=R/'chicago/4d';C=core.C;H=core.H;N=core.N;V=core.V
base=json.loads((C/'ADOPTION-PLAN.json').read_text());direct=[];donors=[]
for r in base['direct_postimages']:
 source=H/'FINAL-CARPENTER-LIBRARY-RECORDS.json'if r['repo_path'].endswith('stream-carpenter-picture-references.json')else C/r['postimage'];dest=P/'postimages'/r['repo_path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest);before=core.pf(R/r['repo_path'])if(R/r['repo_path']).is_file()else None;assert before==r['before_sha256'];direct.append({**r,'postimage':str(dest.relative_to(P)),'after_sha256':core.pf(dest),'bytes':dest.stat().st_size});donors.append({'path':str(source),'sha256':core.pf(source)})
old=json.loads((A/f'data/structures/{core.SID}.json').read_text());new=json.loads((C/f'postimages/chicago/4d/data/structures/{core.SID}.json').read_text());ops=core.differences(old,new);assert core.apply_ops(old,ops)==new
manifest_paths=[Path('/workspace/T2382-canonical-three-control-packet-20261029/MANIFEST.json'),N/'CLOSED-MANIFEST.json',C/'CLOSED-MANIFEST.json',Path('/workspace/T2382-published-BOTH-current2b01-20261030/CLOSED-V3-APP-MANIFEST.json'),H/'CLOSED-HOSTING-METADATA-MANIFEST.json']
# Verify retained actual native/model/photo/source payloads explicitly without re-reading unrelated runtime screenshots.
for mp in manifest_paths:
 m=json.loads(mp.read_text());rows=m['files']if isinstance(m.get('files'),list)else m['members'];assert isinstance(rows,list)
 for r in rows:
  p=Path(r['path'])
  if any(k in str(p)for k in ['postimages/','closed-authority/native-','NATIVE-ENTRIES.json','ACTUAL-CAPTURES.json','DIRECT-VISUAL-REVIEW.json','QUALIFIED-BOTH-COMPOSITE.json','desktop/RESULT.json','mobile/RESULT.json','mobile-body-completion-retry/RESULT.json','HOSTED-RECORDS-CLOSED.json']):assert p.stat().st_size==r['bytes']and core.pf(p)==r['sha256'],str(p)
 donors.append({'path':str(mp),'sha256':core.pf(mp)})
for p in [V/'LIBERTIES-APPEND-v3.md',H/'APP-STORE-ENTRYWISE-4ROWS.json',H/'FINAL-CARPENTER-LIBRARY-RECORDS.json',N/'closed-authority/NATIVE-ENTRIES.json',C/'ENTRYWISE-NATIVE-REGISTRIES.json']:
 donors.append({'path':str(p),'sha256':core.pf(p)})
plan={'status':'CURRENT_FROZEN1AF_SOURCE_ENTRYWISE_PREPARATION_ONLY','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'direct_postimages':direct,'structure_operations':ops,'native_registry_operations':json.loads((C/'ENTRYWISE-NATIVE-REGISTRIES.json').read_text()),'STORE_fragment':str(H/'APP-STORE-ENTRYWISE-4ROWS.json'),'liberties_append':str(V/'LIBERTIES-APPEND-v3.md'),'source_bindings':base['source_bindings'],'donor_bindings':donors,'changelog':{'title':"Carpenter's former shop follows its pictures",'kind':'fix','items':['The low log annex beside the Sauganash has a lower roof, an endward chimney and timber across its exposed gable.','Three credited picture comparisons distinguish visible details from retrospective and unresolved evidence.']},'derived_files_not_directly_written':['chicago/prairie_1904_v1/data/images.json','chicago/4d/data/structure_grades.json','chicago/4d/data/sidecars','chicago/4d/data/pictures','chicago/4d/data/liberties.json'],'actual_future_dev_squash_fold_unknown_recheck_required':True,'no_1456_current_merge_application':True,'Petford_reference_only_no_new_derived_camera':True}
(P/'PLAN.json').write_bytes(core.dump(plan));print(json.dumps({'direct_postimages':len(direct),'source_structure_operations':len(ops),'native_recipe_expected':'498ba51e434b99cb489b0dcf20150394cb3e4b00335dce00d95efde5011ef165','authorities_verified':len(manifest_paths),'primary_writes':False}))
for f in ['core.py','controller.py']:ast.parse((P/f).read_text())
