# Actual native Beaubien main-mass prototype, unreviewed comparison

ONE real selected prototype completed under root's explicit import-complete
CPU3,4/source grant. Blender4.5.3 version passed; unchanged official
`generators/build.py --only jb_beaubien_homestead` built exactly one asset in1.002s;
official `tools/web_derivatives.sh --only jb_beaubien_homestead__log_1822.glb`
completed in3.204s; native fixed-camera photo_match completed in2.403s. All stages
exited0 and all descendants were reaped. Total controller time was10.92s including
setup/guards. No second candidate, camera fit or control bake ran.

Actual MASTER `47aee10fae5f034f47f4f04549da929a921d72b465f6e5a186bae7ffa1dcff93`
is82,592B/918triangles. Actual normal WEB
`f87a55f3fd25ee1dfaf6089be084258b348e52f91ea773883068f1dc33106397` is24,712B.
The native-written manifest entry has expected full input recipe
`f8d59ea8ca88e0d49f8d81bd4b16aac6886e2ee509e0da075544b3a82f72eeb2`;
the native WEB record binds that actual MASTER. No registry hash was handcrafted.
`closed-authority/NATIVE-ENTRIES.json` extracts the real owner-written entries and
resolved recipe document. Unique native artifacts are independently preserved
under `closed-authority/`.

The capture used ordinary native manifest lookup with no GLB override. Camera
`c914ab0a92c25ec883121a23b81441406935f46415687218725d3e0fcca9f134` and original
whole source `624d8f1f52a75bf30653e8cbf37a388478b0ddf5a02f1fadf727cf2144b84c3f`
remain exact. The raw match is **unreviewed**. Root must directly inspect
`closed-authority/source-comparison.jpg` and `native-render.png`; this run does
not assign matches, accept identity, change a structure grade or close T2378.

The worker directly viewed the whole-source native comparison and raw render.
The main mass now reads taller, with a steeper right gable and two ridge stacks,
as intended. The missing low front projection, inherited opening arrangement,
finish/monochrome interpretation and retrospective source/1835 continuity limits
remain explicit. This is a bounded main-massing prototype, not a whole-house
match or app/material/terrain/access acceptance. No further automatic tuning or
second prototype follows from the one run.

All2,073 primary MASTER/WEB files, every guarded source/code/photo/camera input,
Git HEAD/index/config/refs/status and primary registries remained exact. Actual
primary HEAD430557a76ad9c8fc70f0fbfb353765bfe8c83857 stayed unchanged throughout.
Every foreign native registry row/order/metadata and the versions registry were
preserved. The selected data-only prototype was the only model built, in the
external runtime; the old69cb primary model, existing WEB and actual role-test
baseline are unchanged.

The honest32MiB reserve priced138 native/data/tool copies (5,199,860B), necessary
foreign-MASTER existence aliases, metadata/output allowance and16MiB browser
scratch. Official WEB prunes missing foreign MASTER records, so1,035 guarded
MASTER symlinks preserve its genuine current registry semantics. They were never
baked or copied as control models; no WEB alias tree or primary output path was
used. Runtime/source closure contains current unmodified producer/CLI/reader/pin
files, three actual registry copies, real scene/datum and the actual packaged
MASTER manifest. No scaffolding exemption or modified native pipeline was used.

Owned short scratch `/workspace/b2378p30/{t,c,k}` kept TMPDIR/XDG caches in
workspace, with a75-character socket bound. Minimum workspace750,522,368B and
shared TMP1,804,906,496B retained the unchanged536,870,912B/1,800,000,000B floors.
The fixture and scratch are now inactive. Retire ONLY these owned runtime/scratch
paths after root direct review and a verified checkpoint/restoration mapping;
never remove primary symlink targets or installed dependencies. `RESTORE.json`
records ordinary payloads and exact link reconstruction. The closed manifest
includes actual ordinary native input/output authority, not private browser
profiles. Root was notified that all stages were reaped and the primary source
freeze could be released before any later integration mutation.
