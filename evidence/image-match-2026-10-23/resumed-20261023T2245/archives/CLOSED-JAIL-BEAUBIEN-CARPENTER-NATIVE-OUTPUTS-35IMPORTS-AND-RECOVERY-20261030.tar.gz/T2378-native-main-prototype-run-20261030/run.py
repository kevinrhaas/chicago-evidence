"""One actual native selected build+official WEB+fixed-camera prototype comparison.

Default is read-only preflight; execution requires root's granted CPU/source lease.
"""
import argparse,datetime,hashlib,json,os,pathlib,re,shutil,signal,stat,subprocess,sys,time
P=pathlib.Path(__file__).resolve().parent;F=P/'runtime';A=pathlib.Path('/workspace/chicago/chicago/4d');R=A.parents[1]
SHORT=pathlib.Path('/workspace/b2378p30');SID='jb_beaubien_homestead';NAME=SID+'__log_1822.glb'
SHA=lambda b:hashlib.sha256(b).hexdigest();PF=lambda p:SHA(pathlib.Path(p).read_bytes())
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true');args=ap.parse_args()
os.sched_setaffinity(0,{2});sys.dont_write_bytecode=True;plan=json.loads((P/'PLAN.json').read_text())
E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',
 OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',
 NODE_DISABLE_COMPILE_CACHE='1',TMPDIR=str(SHORT/'t'),XDG_CACHE_HOME=str(SHORT/'c'),XDG_CONFIG_HOME=str(SHORT/'k'),
 npm_config_logs_dir=str(SHORT/'npm-logs'),npm_config_update_notifier='false')
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def state():return {'head':git('rev-parse','HEAD').decode().strip(),'index':PF(R/'.git/index'),'config':PF(R/'.git/config'),
 'refs':SHA(git('for-each-ref','--format=%(refname) %(objectname)')),'status':SHA(git('status','--porcelain=v1','-uno'))}
def check():
 assert PF(P/'run.py')==plan['controller_sha256']
 for row in plan['bindings']:assert PF(row['source'])==row['sha256'],row['source']
 assert state()['head']=='430557a76ad9c8fc70f0fbfb353765bfe8c83857'
 sys.path.insert(0,str(A/'generators'));import mesh_inputs
 rec=json.loads(pathlib.Path(plan['candidate']).read_text());assert mesh_inputs.structure_inputs_sha(rec,rec['phases'][0])==plan['recipe_sha256']
 assert json.dumps(mesh_inputs.structure_inputs_doc(rec,rec['phases'][0]),sort_keys=True)==json.dumps(plan['recipe_doc'],sort_keys=True)
 assert not list((A/'data/structures/versions'/SID).glob('*.json'))
 return rec
check()
if not args.execute:
 print(json.dumps({'status':'READONLY_PREPARATION_PASS_NO_BUILD_BROWSER_OR_FIXTURE','price':plan['price'],
  'commands':plan['commands'],'socket_path_upper_bound':len(str(SHORT/'t'))+len('/playwright_chromiumdev_profile-XXXXXX/SingletonSocket'),
  'workspace_required_B':536870912+plan['reserve_B'],'shared_TMP_required_B':1800000000,
  'free':{p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']}},indent=2));raise SystemExit(0)
assert os.environ.get('BEAUBIEN_NATIVE_PROTOTYPE_LEASE')=='root-4f9-import-closed-one-prototype-3-4'
assert not (P/'RESULT.json').exists()and not F.exists()and not SHORT.exists()
assert not (R/'.git/MERGE_HEAD').exists()and not git('status','--porcelain=v1','--untracked-files=all')
assert shutil.disk_usage('/workspace').free>=536870912+plan['reserve_B']and shutil.disk_usage('/tmp').free>=1800000000
before=state();assets={str(p):PF(p)for d in ['gltf','web']for p in(A/'assets'/d).rglob('*.glb')}
(P/'PRIMARY-ASSET-GUARDS.json').write_text(json.dumps(assets,indent=2)+'\n')
started=time.monotonic();minimum={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']}
F.mkdir();SHORT.mkdir(mode=0o700)
for name in ['t','c','k','npm-logs']:(SHORT/name).mkdir(mode=0o700)
for row in plan['copies']:
 dest=F/row['target'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(row['source'],dest);os.chmod(dest,int(row['mode'],8));assert PF(dest)==row['sha256']
for row in plan['links']:
 dest=F/row['target'];dest.parent.mkdir(parents=True,exist_ok=True);dest.symlink_to(row['source'])
assert not(F/'assets/gltf'/NAME).exists()and not(F/'assets/web'/NAME).exists()
registries={k:json.loads((F/'assets'/k).read_text())for k in ['manifest.json','manifest.web.json','manifest.versions.json']}
stages=[]
for stage,command in plan['commands']:
 check();assert state()==before
 remaining=300-(time.monotonic()-started);assert remaining>0,'300s controller deadline exceeded'
 reap=P/(stage+'-REAPER.json');log=P/(stage+'.log')
 wrapped=['python3','/workspace/shared/run-with-reaping.py',str(reap),'--','nice','-n','19','taskset','-c','3,4',*command]
 t=time.monotonic();stop=None
 with log.open('x')as stream:
  child=subprocess.Popen(wrapped,cwd=F,env=E,stdout=stream,stderr=subprocess.STDOUT)
  while child.poll()is None:
   for mount in minimum:minimum[mount]=min(minimum[mount],shutil.disk_usage(mount).free)
   if minimum['/workspace']<536870912 or minimum['/tmp']<1800000000:stop=stop or 'caller floor breached'
   if time.monotonic()-started>300:stop=stop or '300s controller deadline'
   if stop and child.poll()is None:child.send_signal(signal.SIGTERM)
   time.sleep(.2)
  code=child.wait()
 rp=json.loads(reap.read_text());row={'stage':stage,'exit':code,'seconds':time.monotonic()-t,'all_children_reaped':rp['all_children_reaped'],'stop':stop,'argv':command};stages.append(row)
 (P/'STAGES.json').write_text(json.dumps(stages,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert not stop and code==0 and rp['command_exit']==0 and rp['all_children_reaped'],log.read_text()[-5000:]
 if stage=='VERSION':assert 'Blender 4.5.3'in log.read_text()
 if stage=='BUILD':assert (P/'WROTE.txt').read_text().splitlines()==[NAME]
 if stage=='WEB':assert 'gltf-transform unavailable'not in log.read_text()and 'fell back'not in log.read_text()
post={k:json.loads((F/'assets'/k).read_text())for k in registries}
for registry,key in [('manifest.json','assets'),('manifest.web.json','masters')]:
 old,new=registries[registry],post[registry];assert list(old[key])==list(new[key]);assert {n:v for n,v in old[key].items()if n!=NAME}=={n:v for n,v in new[key].items()if n!=NAME};assert {n:v for n,v in old.items()if n!=key}=={n:v for n,v in new.items()if n!=key}
assert post['manifest.versions.json']==registries['manifest.versions.json']
master=F/'assets/gltf'/NAME;web=F/'assets/web'/NAME
assert post['manifest.json']['assets'][NAME]['inputs_sha256']==plan['recipe_sha256']
assert post['manifest.web.json']['masters'][NAME]==PF(master)
assert PF(master)!='69cb6bfcc2e71aaaa48a424f11e9231294335b178df7b22611aae500162156b1'
cam=F/plan['camera_relative'];match=cam.with_suffix('.match.json');review=json.loads(match.read_text())
assert review['verdict']=='unreviewed'and review['camera_sha256']==plan['camera_sha256']and review['photo_sha256']==plan['photo_sha256']and review['glb_sha256']==PF(master)
assert state()==before and all(PF(p)==h for p,h in assets.items());check()
assert not list((F/'generators').rglob('__pycache__'))
C=P/'closed-authority';C.mkdir();closed=[]
def preserve(src,relative):
 dest=C/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);closed.append({'path':str(dest),'bytes':dest.stat().st_size,'sha256':PF(dest)})
preserve(master,'native-master/'+NAME);preserve(web,'native-web/'+NAME);preserve(F/'data/structures'/f'{SID}.json','candidate/'+SID+'.json');preserve(cam,'native-camera.json');preserve(match,'native-unreviewed.match.json')
side=F/review['side_by_side'];preserve(side,'source-comparison.jpg')
raw=re.search(r'\n\s+(/[^\n]+-render\.png)\n',(P/'PHOTO.log').read_text());assert raw
raw=pathlib.Path(raw.group(1));assert raw.is_relative_to(SHORT/'t');preserve(raw,'native-render.png')
entries={'master':post['manifest.json']['assets'][NAME],'web_master_sha256':post['manifest.web.json']['masters'][NAME],'recipe_sha256':plan['recipe_sha256'],'recipe_doc':plan['recipe_doc']};(C/'NATIVE-ENTRIES.json').write_text(json.dumps(entries,indent=2)+'\n');closed.append({'path':str(C/'NATIVE-ENTRIES.json'),'bytes':(C/'NATIVE-ENTRIES.json').stat().st_size,'sha256':PF(C/'NATIVE-ENTRIES.json')})
result={'status':'ACTUAL_ONE_SELECTED_NATIVE_BUILD_WEB_FIXED_CAMERA_PASS_UNREVIEWED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'seconds_total':time.monotonic()-started,'stages':stages,'MASTER_sha256':PF(master),'WEB_sha256':PF(web),'native_recipe_sha256':plan['recipe_sha256'],
 'native_master_entry':entries['master'],'camera_sha256':plan['camera_sha256'],'photo_sha256':plan['photo_sha256'],
 'all_foreign_registry_rows_order_metadata_exact':True,'all_primary_asset_bytes_exact_count':len(assets),'primary_source_Git_all_guards_exact':True,
 'all_children_reaped':True,'minimum_free_B':minimum,'current_free_B':{m:shutil.disk_usage(m).free for m in minimum},
 'raw_match':'unreviewed','matches_identity_grade_or_DONE_claimed':False,'remaining_gap':'Low front projection and opening arrangement not solved; root direct review still owed',
 'members':closed,'fixture_retirement':'WAIT root direct review/checkpoint. Never retire while active; preserve unique outputs/restoration mappings first.'}
assert result['current_free_B']['/workspace']>=536870912 and result['current_free_B']['/tmp']>=1800000000
(P/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='members'},indent=2),flush=True)
