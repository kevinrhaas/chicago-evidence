import fs from 'node:fs';
import vm from 'node:vm';
import crypto from 'node:crypto';
const app='/workspace/chicago/chicago/4d',out='/workspace/T3106-flora-prerequisite-20261024';
const source=fs.readFileSync(app+'/renderers/web/js/trees.js','utf8');
const literal=source.match(/  const STEMS = (\{[\s\S]*?\n  \});/)[1];
const expression=source.match(/  const keep = ([^;]+);/)[1];
const table=vm.runInNewContext('('+literal+')'),rows=[];
for(const sceneId of ['1812','1835','1904',null])for(const level of ['full','balanced','light']){
 const stems=table[level],actual=vm.runInNewContext(expression,{stems,sceneId,level}),expected=sceneId==='1812'&&level==='light'?.225:stems.keep;
 if(Math.abs(actual-expected)>1e-12||stems.trees!==(level==='full'?4700:level==='balanced'?3800:2100))throw Error('Actual existing keep/cap control differs: '+JSON.stringify({sceneId,level,actual,expected,stems}));
 rows.push({scene:sceneId,level,actual_keep:actual,cap:stems.trees,unchanged:actual===stems.keep});
}
const report={status:'PASS_ACTUAL_KEEP_EXPRESSION_AND_UNCHANGED_CAPS',source_sha256:crypto.createHash('sha256').update(source).digest('hex'),actual_expression:expression,rows,meaning:'Only1812Light changes the existing acceptance probability, uniformly with no position predicate. Every other scene/tier tested returns its previous keep, all backstop literals unchanged.'};
fs.writeFileSync(out+'/KEEP-CONTROLS.json',JSON.stringify(report,null,2)+'\n');console.log(report.status);
