// T3082 V2 final5d9: separate current wording/native card QA; all older QA preserved.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {checkReviewNotices} from './review-notices.mjs';
import {readReviewSurfaceInPage,checkReviewSurface} from './review-surfaces.mjs';

const QA_DIR=path.dirname(fileURLToPath(import.meta.url));
const args=process.argv.slice(2), option=(k,d)=>{const i=args.indexOf(k);return i<0?d:args[i+1];};
const config=JSON.parse(fs.readFileSync(path.join(QA_DIR,'models.json'),'utf8'));
const app=path.resolve(option('--app',config.app)), site=path.resolve(app,'../../site/4d');
const bindings=JSON.parse(fs.readFileSync(path.join(QA_DIR,'input-bindings.json'),'utf8'));
for(const b of bindings.files){const base=b.root==='app'?app:site;const got=crypto.createHash('sha256').update(fs.readFileSync(path.join(base,b.path))).digest('hex');if(got!==b.sha256)throw Error('Frozen current source/published input drift: '+b.root+'/'+b.path);}
const viewportName=option('--viewport','mobile');
if(!['mobile','desktop'].includes(viewportName))throw Error('viewport must be mobile or desktop');
const chosen=option('--ids','').split(',').filter(Boolean);
const models=config.models.filter(x=>!chosen.length||chosen.includes(x.id));
if(!models.length||chosen.some(id=>!models.some(m=>m.id===id)))throw Error('Unknown or empty model selection');
const out=path.resolve(option('--out',path.join(QA_DIR,'runs',new Date().toISOString().replaceAll(':','-'))));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const m of models){
 const actual=sha(fs.readFileSync(path.join(app,'data/structures',m.id+'.json')));
 if(actual!==m.record_sha256)throw Error(m.id+': authored record drift; update/review expectation rather than overwrite it');
}
if(!args.includes('--execute')){
 console.log(JSON.stringify({status:'PREPARED_ONLY_NOT_EXECUTED',app,site,viewportName,ids:models.map(x=>x.id),out,
  limits:'No browser, publish, fetch, Blender, full gate, acceptance or canonical write. Pass --execute only after root assigns browser slot and native publish finishes.'},null,2));
 process.exit(0);
}
if(fs.existsSync(out))throw Error('Refusing to overwrite existing run: '+out);
fs.mkdirSync(out,{recursive:true});
const report={status:'RUNNING',started_at:new Date().toISOString(),app,site,viewport:viewportName,
 method:'Actual native published /walk/ app, visitor light/full tier, Inspect Photos/Sources, native framing and live feet through actual placement matrices. No source camera solving or automatic image-match acceptance.',
 limits:'Targeted seven-model first-fort application QA; not whole published smoke or an image-match verdict. Door/apron checks read declared access geometry; solid footprints still have no walk-through interiors. Burial is reported, not silently allowed as new evidence.',
 source_config_sha256:sha(fs.readFileSync(path.join(QA_DIR,'models.json'))),models:[],page_errors:[],http_errors:[],request_failures:[],web_asset_responses:[]};
const nativeRequestErrors=()=>report.request_failures.filter(r=>!/ERR_ABORTED/.test(typeof r.failure==='object'?(r.failure?.errorText||''):String(r.failure??'')));
const save=()=>fs.writeFileSync(path.join(out,'QA-RESULT.json'),JSON.stringify(report,null,2)+'\n');
save();
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.glb':'model/gltf-binary','.svg':'image/svg+xml','.wasm':'application/wasm','.ktx2':'image/ktx2'};
const server=http.createServer((req,res)=>{
 try{
  const url=new URL(req.url,'http://localhost');let p=path.resolve(site,'.'+decodeURIComponent(url.pathname));
  if(p!==site&&!p.startsWith(site+path.sep)){res.writeHead(403);res.end();return;}
  if(fs.statSync(p).isDirectory())p=path.join(p,'index.html');
  res.writeHead(200,{'Content-Type':types[path.extname(p)]||'application/octet-stream'});fs.createReadStream(p).pipe(res);
 }catch{res.writeHead(404);res.end('missing');}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let browser=null,context=null,failure=null;
const responseTasks=[],inflight=new Map();
try{
 for(const m of models){
  const web=fs.readFileSync(path.join(app,'assets/web',m.asset));
  const published=fs.readFileSync(path.join(site,'data/gltf',m.asset));
  if(sha(web)!==sha(published))throw Error(m.id+': published web GLB is stale');
  m.expected_web_sha256=sha(web);
 }
 let require=createRequire(path.join(app,'tools/qa.mjs'));
 try{require.resolve('playwright');}catch{require=createRequire('/workspace/__qa__.mjs');}
 const {chromium}=require('playwright');
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE||'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 const viewport=viewportName==='mobile'?{width:390,height:780}:{width:1280,height:800};
 context=await browser.newContext({viewport,deviceScaleFactor:viewportName==='mobile'?2:1,isMobile:false,hasTouch:viewportName==='mobile'});
 report.browser_context={viewport,deviceScaleFactor:viewportName==='mobile'?2:1,isMobile:false,hasTouch:viewportName==='mobile'};
 const page=await context.newPage();page.setDefaultTimeout(240000);
 page.on('pageerror',e=>report.page_errors.push(String(e)));
 page.on('request',r=>inflight.set(r,r.url()));
 page.on('requestfinished',r=>inflight.delete(r));
 page.on('requestfailed',r=>{inflight.delete(r);report.request_failures.push({url:r.url(),method:r.method(),resource_type:r.resourceType(),failure:r.failure()});});
 page.on('response',r=>{
  if(r.status()>=400)report.http_errors.push({url:r.url(),status:r.status()});
  const m=models.find(m=>r.url().split('?')[0].endsWith('/data/gltf/'+m.asset));
  if(m)responseTasks.push((async()=>{
   const b=await r.body();report.web_asset_responses.push({id:m.id,url:r.url(),status:r.status(),bytes:b.length,sha256:sha(b),expected_sha256:m.expected_web_sha256});
  })().catch(e=>{report.request_failures.push({id:m.id,url:r.url(),failure:String(e)});}));
 });
 const base='http://127.0.0.1:'+server.address().port;
 await page.goto(base+'/walk/?year='+encodeURIComponent(config.scene),{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:240000,polling:500});
 const boot=await page.evaluate(()=>({ready:__chicago4d.ready,error:__chicago4d.error,scene:__chicago4d.scene?.id}));
 if(!boot.ready||boot.error||String(boot.scene)!==String(config.scene))throw Error('Native app did not boot the configured scene: '+JSON.stringify(boot));
 await page.waitForFunction(()=>__chicago4d.welcome?.state==='welcome',null,{timeout:240000});
 await page.evaluate(async detail=>{
  const a=__chicago4d;await a.setDetail(detail);
  if(!a.welcome.enter('spawn'))throw Error('welcome entry failed');
  document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();
  a.renderer.setAnimationLoop(null);a.setAnimationHold(true);a.step();
 },viewportName==='mobile'?'light':'full');
 await page.waitForFunction(()=>document.getElementById('gate').hidden);
 report.boot=boot;
 const pictures=JSON.parse(fs.readFileSync(path.join(site,'data/pictures/'+config.scene+'.json'),'utf8'));
 report.published_pictures_sha256=sha(fs.readFileSync(path.join(site,'data/pictures/'+config.scene+'.json')));
 const apron=JSON.parse(fs.readFileSync(path.join(site,'data/enclosures/town_entrance_aprons.json'),'utf8'));
 for(const m of models){
  const row={id:m.id,phase:m.phase,expected_web_sha256:m.expected_web_sha256,failures:[]};
  report.models.push(row);save();
  row.entrances=apron.entrances.filter(x=>x.structure_id===m.id);
  if(row.entrances.length!==m.expected_entrances.length)row.failures.push('Declared entrance count mismatch');
  for(const want of m.expected_entrances){
   const got=row.entrances.find(x=>x.id===want.id);
   if(!got||got.at_local_enu_m.some((v,i)=>Math.abs(v-want.at_local_enu_m[i])>.011)||Math.abs(got.width_m-want.width_m)>.011||Math.abs(((got.bearing_deg-want.bearing_deg+540)%360)-180)>.011)row.failures.push('Entrance station/width/bearing mismatch: '+want.id);
  }
  row.geometry=await page.evaluate(id=>{
   const a=__chicago4d,rec=a.registry.get(id),bounds=a.buildings.instanceBounds()[id],matrix=a.buildings.matrixOf(id),feet=a.buildings.feetOf(id);
   if(!rec||!bounds||!matrix||!feet?.length)throw Error(id+': missing actual record/bounds/matrix/feet');
   const samples=feet.map(([x,z])=>{const e=matrix.elements;const wx=e[0]*x+e[8]*z+e[12],wy=e[1]*x+e[9]*z+e[13],wz=e[2]*x+e[10]*z+e[14];return {e:wx,n:-wz,base_y:wy,terrain_y:a.terrain.surfaceHeight(wx,-wz),gap_m:wy-a.terrain.surfaceHeight(wx,-wz)};});
   if(!a.frame(id,{card:false}))throw Error(id+': native framing failed');a.step();
   return {grade:rec.sidecar.grade,phase:rec.sidecar.phase,asset:rec.sidecar.asset,bounds,placement:rec.sidecar.placement,feet:feet.length,max_gap_m:Math.max(...samples.map(x=>x.gap_m)),min_gap_m:Math.min(...samples.map(x=>x.gap_m)),samples,roll_missing:a.buildings.roll.missing,stats:a.stats(),problems:a.problems,registry_review_ids:[...a.registry.values()].filter(r=>r.sidecar?.review_required).map(r=>r.sidecar.id).sort(),framing:a.framing(id,{card:false}),player:{e:a.player.e,n:a.player.n,blocked:a.router.blockedAt(a.player.e,a.player.n),class:a.router.classAt(a.player.e,a.player.n)}};
  },m.id);
  if(row.geometry.phase!==m.phase||row.geometry.asset!=='gltf/'+m.asset)row.failures.push('Wrong selected phase/asset');
  if(row.geometry.grade?.value!==m.expected_grade)row.failures.push('Actual native structure grade differs from source-identity ruling');
  if(row.geometry.bounds.size.some(x=>!Number.isFinite(x)||x<=0)||row.geometry.roll_missing.includes(m.id))row.failures.push('Actual rendered geometry absent or degenerate');
  if(!row.geometry.samples.length||row.geometry.samples.some(p=>!Object.values(p).every(Number.isFinite)))row.failures.push('Nonfinite or empty actual contact samples');
  if(row.geometry.max_gap_m>.15)row.failures.push('Wall foot hovers above native0.15m ceiling');
  if(!row.geometry.stats.withinBudget)row.failures.push('Actual stand exceeds native detail budget');
  if(row.geometry.player.blocked)row.failures.push('Native framing left walker on blocked ground');
  row.flora=await page.evaluate(()=>{
   const a=__chicago4d,t=a.trees,s=t.stats,stations=t.group.userData.stations??[],sweep=s.sweep,deciles=Array(10).fill(0);
   for(const p of stations){const k=Math.max(0,Math.min(9,Math.floor((p.n-sweep.n[0])/(sweep.n[1]-sweep.n[0])*10)));deciles[k]++;}
   return {detail:a.detail,keep:s.keep,trees:s.trees,planted:s.planted,planted_stems:s.plantedStems,sweep,stations:stations.length,max_n:Math.max(...stations.map(p=>p.n)),min_n:Math.min(...stations.map(p=>p.n)),deciles,tree_problems:a.problems.filter(p=>p.startsWith('trees:')),stats:a.stats()};
  });
  if(row.flora.detail!=='light'||Math.abs(row.flora.keep-.225)>1e-12||row.flora.trees>=2100||row.flora.tree_problems.length)row.failures.push('1812 Light uniform thinning or hard flora problem remains');
  if(row.flora.max_n<1100||row.flora.deciles[9]<=0)row.failures.push('1812 Light woodland fails existing native northern reach floor');
  const expectedPlanted=['kinzie_poplar_1','kinzie_poplar_2','kinzie_poplar_3','kinzie_poplar_4','ouilmette_currant_1','ouilmette_currant_2','ouilmette_currant_3','ouilmette_currant_4','ouilmette_currant_5','ouilmette_currant_6'];
  if(expectedPlanted.some(id=>row.flora.planted_stems.filter(p=>p.id===id).length!==1))row.failures.push('Declared four poplars/six currants not actually planted exactly once');
  row.review_notices=checkReviewNotices(config.scene_review_notices,row.geometry.registry_review_ids,row.geometry.problems);
  row.failures.push(...row.review_notices.failures);
  await page.screenshot({path:path.join(out,m.id+'-'+viewportName+'-native.png')});
  row.grade_mode=await page.evaluate(async()=>{
   const a=__chicago4d;const take=async()=>{const p=a.capture();a.step();return await p;};
   a.setConfidenceView(false);const normal=await take();
   a.setConfidenceView(true);const bygrade=await take();
   return {normal,bygrade,state_on:a.confidenceView,stats:a.stats()};
  });
  if(row.grade_mode.state_on!==true||!row.grade_mode.normal.cells||row.grade_mode.normal.cells.length!==row.grade_mode.bygrade.cells.length)row.failures.push('By grade actual mode/signature missing');
  const gradeDeltas=row.grade_mode.normal.cells.map((x,i)=>Math.abs(x-row.grade_mode.bygrade.cells[i]));
  row.grade_mode.delta={mean:gradeDeltas.reduce((a,b)=>a+b,0)/gradeDeltas.length,worst:Math.max(...gradeDeltas)};
  if(row.grade_mode.delta.worst<6||row.grade_mode.delta.mean<.6)row.failures.push('By grade must visibly change the actual rendered model');
  if(!row.grade_mode.stats.withinBudget)row.failures.push('By grade exceeds native detail budget');
  await page.screenshot({path:path.join(out,m.id+'-'+viewportName+'-by-grade.png')});
  await page.evaluate(()=>{const a=__chicago4d;a.setConfidenceView(false);a.step();});
  if(await page.evaluate(()=>__chicago4d.confidenceView)!==false)row.failures.push('Normal appearance did not restore');
  row.popup_review=await page.evaluate(readReviewSurfaceInPage,{id:m.id,surface:'popup'});
  row.failures.push(...checkReviewSurface(m.review_expected,row.popup_review));
  await page.screenshot({path:path.join(out,m.id+'-'+viewportName+'-popup.png')});
  row.cards=await page.evaluate(async ({id,pictures,scene})=>{
   const {photosTab,creditOf}=await import('/walk/js/photos-tab.js');
   const tab=photosTab(pictures,id,Number(scene));if(!tab)throw Error('Published picture rows absent: '+id);
   const expectedTiles=tab.count<=12?tab.all:tab.best;
   const a=__chicago4d;const wait=async f=>{for(let n=0;n<300&&!f();n++)await new Promise(r=>setTimeout(r,100));if(!f())throw Error('Inspect timed out: '+id);};
   if(!a.openBuilding(id))throw Error('Native Inspect open failed: '+id);
   const root=()=>document.getElementById('nav-app-inspect');await wait(()=>root()?.dataset.structure===id&&!!root().querySelector('.insp-tabs'));
   const out={};
   for(const key of ['people','photos','sources']){
    root().querySelector('[data-insp-tab="'+key+'"]')?.click();const pane=()=>root()?.querySelector('[data-insp-pane="'+key+'"]');
    await wait(()=>['yes','failed'].includes(pane()?.dataset.filled));
    pane().querySelectorAll('details').forEach(d=>d.open=true);
    out[key]={selected:root().querySelector('[data-insp-tab="'+key+'"]')?.getAttribute('aria-selected'),filled:pane().dataset.filled,shown:!pane().hidden,text:pane().innerText,credits:[...pane().querySelectorAll('.ph-credit,.ph-link-list .nav-sub')].map(x=>x.textContent.trim()),links:[...pane().querySelectorAll('a[href]')].map(x=>({href:x.href,text:x.textContent.trim()})),photo_tiles:pane().querySelectorAll('.ph-item').length,link_only:pane().querySelectorAll('.ph-link-list li').length,overflow:document.documentElement.scrollWidth>innerWidth};
    if(key==='photos'){
     const gotTiles=[...pane().querySelectorAll('.ph-item')],gotLinks=[...pane().querySelectorAll('.ph-link-list li')];
     out[key].published_row_checks={expected_tiles:expectedTiles.map(p=>({id:p.id,credit:creditOf(p)})),expected_links:tab.links.map(p=>({id:p.id,title:p.title,url:p.url,credit:creditOf(p)})),
      tiles:gotTiles.map((li,i)=>({id:li.dataset.photo,credit:li.querySelector('.ph-credit')?.textContent.trim()??'',expected_id:expectedTiles[i]?.id,expected_credit:expectedTiles[i]?creditOf(expectedTiles[i]):null})),
      links:gotLinks.map((li,i)=>({expected_id:tab.links[i]?.id,expected_credit:tab.links[i]?creditOf(tab.links[i]):null,expected_url:tab.links[i]?.url??null,href:li.querySelector('a')?.href??null,lines:[...li.querySelectorAll('.nav-sub')].map(n=>n.textContent.trim())}))};
     const c=out[key].published_row_checks;
     c.pass=gotTiles.length===expectedTiles.length&&gotLinks.length===tab.links.length&&
      c.tiles.every(r=>r.id===r.expected_id&&r.credit&&r.credit===r.expected_credit)&&
      c.links.every(r=>r.expected_credit&&r.lines.includes(r.expected_credit)&&(!/^https?:\/\//.test(String(r.expected_url??''))||r.href===new URL(r.expected_url,location.href).href));
     // Lazy thumbnails are checked only after each is actually brought into view.
     out[key].images=[];
     for(const img of pane().querySelectorAll('.ph-thumb')){
      img.scrollIntoView({block:'center'});await wait(()=>img.complete);
      out[key].images.push({src:img.currentSrc||img.src,complete:img.complete,naturalWidth:img.naturalWidth,naturalHeight:img.naturalHeight});
     }
    }
   }
   return out;
  },{id:m.id,pictures,scene:config.scene});
  await page.evaluate(()=>document.getElementById('nav-app-inspect')?.querySelector('[data-insp-tab="people"]')?.click());
  await page.waitForFunction(()=>document.querySelector('#nav-app-inspect [data-insp-pane="people"]')?.dataset.filled==='yes');
  row.people_review=await page.evaluate(readReviewSurfaceInPage,{id:m.id,surface:'people'});
  row.failures.push(...checkReviewSurface(m.review_expected,row.people_review));
  await page.screenshot({path:path.join(out,m.id+'-'+viewportName+'-people.png')});
  for(const [key,card] of Object.entries(row.cards))if(card.selected!=='true'||card.filled!=='yes'||!card.shown||!card.text.trim()||card.overflow)row.failures.push(key+' card failed/empty/overflow');
  const sc=row.cards.sources;
  if(!sc.text.includes(m.primary_source.citation_prefix)&&!sc.links.some(x=>m.primary_source.url&&x.href===m.primary_source.url))row.failures.push('Primary source absent from actual Sources card');
  if(!row.cards.photos.published_row_checks?.pass)row.failures.push('Photos pictures/links/credits do not match their published rows');
  if(m.photos_expectation.kind==='empty_unresolved_subject'){
   if(row.cards.photos.photo_tiles||row.cards.photos.link_only||!row.cards.photos.text.includes(m.photos_expectation.empty_text))row.failures.push('Expected honest empty Photos state for unresolved panorama subject');
   if(!sc.text.includes(m.primary_source.citation_prefix)||!sc.links.some(x=>x.href===m.primary_source.url)||!/panorama/i.test(sc.text)||!/reconstructed/i.test(sc.text))row.failures.push('Empty Photos must retain credited Wau-Bun book URL and visible panorama/reconstruction uncertainty in Sources');
  }else if(m.photos_expectation.kind==='baseline_plan_only_empty'){if(row.cards.photos.photo_tiles||row.cards.photos.link_only||row.cards.photos.published_row_checks.expected_tiles.length||row.cards.photos.published_row_checks.expected_links.length)row.failures.push('Exact baseline expected zero published picture rows');}else if(row.cards.photos.photo_tiles+row.cards.photos.link_only<1)row.failures.push('Expected credited pictures or links are missing');
  if(row.cards.photos.images.some(x=>!x.complete||x.naturalWidth<=0||x.naturalHeight<=0))row.failures.push('Displayed picture thumbnail failed to load');
  for(const key of ['photos','sources']){
   await page.evaluate(({key,credits,primary})=>{
    const r=document.getElementById('nav-app-inspect');r.querySelector('[data-insp-tab="'+key+'"]')?.click();const p=r.querySelector('[data-insp-pane="'+key+'"]');
    const target=key==='photos'?(p.querySelector('.ph-credit')||[...p.querySelectorAll('.ph-link-list .nav-sub')].find(n=>credits.includes(n.textContent.trim()))||p.querySelector('.nav-sub')):
     ([...p.querySelectorAll('a[href]')].find(a=>a.href===primary.url)||[...p.querySelectorAll('.cites li')].find(n=>n.textContent.includes(primary.citation_prefix))||p.querySelector('summary'));
    target?.scrollIntoView({block:'center'});
   },{key,credits:row.cards.photos.published_row_checks.expected_links.map(p=>p.credit),primary:m.primary_source});
   await page.screenshot({path:path.join(out,m.id+'-'+viewportName+'-'+key+'.png')});
  }
  await page.evaluate(()=>{const a=__chicago4d;a.closeBuilding();a.navigator.select('home');a.navigator.dock();});
  save();
 }
 const networkDeadline=Date.now()+30000;
 while(inflight.size&&Date.now()<networkDeadline)await new Promise(r=>setTimeout(r,100));
 report.pending_requests=[...inflight.values()];
 if(inflight.size)throw Error('Native app requests did not finish: '+JSON.stringify(report.pending_requests));
 await Promise.all(responseTasks);
 for(const m of models){const got=report.web_asset_responses.filter(x=>x.id===m.id);if(!got.length||got.some(x=>x.status!==200||x.sha256!==m.expected_web_sha256))throw Error(m.id+': actual loaded published web asset binding failed');}
 const failures=report.models.flatMap(x=>x.failures.map(f=>x.id+': '+f));
 if(report.page_errors.length||report.http_errors.length||nativeRequestErrors().length)failures.push('Page/network errors: see unfiltered receipts');
 if(failures.length)throw Error(failures.join('\n'));
 report.status='PASS_TARGETED_APP_QA_NOT_IMAGE_MATCH';
}catch(e){failure=e;report.status='FAIL';report.error=String(e.stack||e);}
finally{
 try{await context?.close();}catch(e){report.cleanup_errors??=[];report.cleanup_errors.push(String(e));}
 try{await browser?.close();}catch(e){report.cleanup_errors??=[];report.cleanup_errors.push(String(e));}
 await new Promise(r=>server.close(r));
 if(report.page_errors.length||report.http_errors.length||nativeRequestErrors().length||report.cleanup_errors?.length){
  report.status='FAIL';failure??=Error('Page/network/cleanup errors: see unfiltered receipts');report.error??=String(failure);
 }
 report.native_network_classification={policy:'Exact native smoke_renderer.mjs ERR_ABORTED exclusion; all unfiltered events remain above',hard_errors:nativeRequestErrors(),aborted_requests:report.request_failures.filter(r=>!nativeRequestErrors().includes(r))};
 report.ended_at=new Date().toISOString();save();
}
console.log(JSON.stringify({status:report.status,out,error:report.error??null},null,2));
if(failure)process.exitCode=1;
