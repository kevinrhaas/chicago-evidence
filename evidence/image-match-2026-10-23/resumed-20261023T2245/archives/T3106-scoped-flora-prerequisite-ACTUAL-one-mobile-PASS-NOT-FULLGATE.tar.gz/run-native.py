import subprocess,json,pathlib,time,os
out=pathlib.Path('/workspace/T3106-flora-prerequisite-20261024');app=pathlib.Path('/workspace/chicago/chicago/4d')
checks=[('js-syntax',['node','--check','renderers/web/js/trees.js']),('flora-reach',['python3','tools/measure_flora_reach.py','--gate']),('planting-reach',['python3','tools/measure_planting_reach.py','--gate']),('liberties',['python3','tools/compile_liberties.py','--check']),('source-validation',['python3','tools/validate.py','--params','--licenses','--stale','--strict']),('published',['node','tools/check_published.mjs'])]
rows=[]
for label,cmd in checks:
 with(out/(label+'.log')).open('w')as f:
  start=time.monotonic();r=subprocess.run(cmd,cwd=app,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','npm_config_cache':'/workspace/shared/npm-cache'},timeout=240)
 rows.append({'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'NATIVE-CHECKS.json').write_text(json.dumps({'status':'RUNNING','checks':rows},indent=2)+'\n')
 if r.returncode:break
print(json.dumps(rows,indent=2));(out/'NATIVE-CHECKS.json').write_text(json.dumps({'status':'PASS'if len(rows)==len(checks)and not any(x['exit_code']for x in rows)else'FAIL','checks':rows},indent=2)+'\n')
