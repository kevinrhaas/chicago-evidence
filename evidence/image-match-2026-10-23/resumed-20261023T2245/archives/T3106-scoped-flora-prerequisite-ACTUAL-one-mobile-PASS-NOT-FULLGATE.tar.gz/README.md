# T-3106 scoped flora prerequisite, closed evidence

`RESULT.json` is the verdict; `SOURCE-FINAL.json` binds the exact dirty utility branch and changed files. The browser ran once against the native-published candidate on da65119 and PASSes targeted mobile1812Light application QA. It is not an image match or full release verdict.

Use `runtime-three-files.patch` for the three real runtime/data changes. `authored-six-files.patch` also carries the source documentation. `full-seven-files.patch` includes natively derived liberties for exact reconstruction on da65119. On the different fort tree, preserve its appended documents and regenerate liberties from the combined source; never hand-merge generated data. No code commit or push has been made.

Original failed fort and actual public-baseline JSON receipts remain FAIL in `original-failures/`; the earlier baseline packet is independently archived at private recovery commit cc014125919c9ff6b448141e41a983b6f84e200a. Native ERR_ABORTED classification is explicit and all raw events remain in the candidate result.

CPU native generated shrub-envelope results, negative controls and helper development failures are retained. Standard focused native validation passes; optional earlier warnings-as-errors strict validation failed with zero errors/281 warnings and stays preserved. Final standard --all has zero errors/283 warnings. Full check.sh and canonical integration/qualification remain owed. Browser/export/full gate slot is CLEAR.
