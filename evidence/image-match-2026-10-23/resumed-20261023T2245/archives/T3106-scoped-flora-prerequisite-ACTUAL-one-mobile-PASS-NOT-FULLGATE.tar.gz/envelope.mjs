import fs from 'node:fs';
import crypto from 'node:crypto';
import * as THREE from 'three';
import {TreeInstances} from '/workspace/chicago/chicago/4d/renderers/web/js/tree-instances.js';
import {footprintsFrom} from '/workspace/chicago/chicago/4d/renderers/web/js/walker.js';
const app='/workspace/chicago/chicago/4d',out='/workspace/T3106-flora-prerequisite-20261024';
const read=p=>JSON.parse(fs.readFileSync(p));
const zone=read(app+'/data/flora/zones/z10_settled_town.json');
const sp=zone.species.find(s=>s.id==='ribes_spp');
const rgb=sp.july.foliage_rgb,dark=(rgb[0]<<16)|(rgb[1]<<8)|rgb[2];
const light=(Math.min(255,Math.round(rgb[0]*1.34+26))<<16)|(Math.min(255,Math.round(rgb[1]*1.28+22))<<8)|Math.min(255,Math.round(rgb[2]*1.42+20));
const rec=read(app+'/data/flora/plantings/ouilmette_garden_1812.json');
const side='/workspace/chicago/site/4d/data/sidecars/1812';
const registry=new Map(fs.readdirSync(side).filter(f=>f.endsWith('.json')).map(f=>read(side+'/'+f)).filter(s=>s.id&&s.footprint).map(s=>[s.id,{id:s.id,sidecar:s}]));
const fps=footprintsFrom(registry).concat(footprintsFrom(registry,{camps:true}));
const dist=(p,a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1];const t=Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy)));return Math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy);};
const polyDistance=(p,pts)=>{let inside=false;for(let i=0,j=pts.length-1;i<pts.length;j=i++){const a=pts[i],b=pts[j];if((a[1]>p[1])!==(b[1]>p[1])&&p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])inside=!inside;}return {inside,distance:Math.min(...pts.map((v,i)=>dist(p,v,pts[(i+1)%pts.length])))};};
const rows=[],materials=[new THREE.MeshBasicMaterial(),new THREE.MeshBasicMaterial()];
for(const level of ['light','full']){
 const grown=new TreeInstances({level,cull:true});
 for(const s of rec.stems)grown.add({speciesId:sp.id,common:sp.common,form:'edge_shrub',h:[s.height_m,s.height_m],crownW:sp.width_m,dark,light,bark:0x6a5c4b,conf:.5,head:null},s.at_local_enu_m[0],0,-s.at_local_enu_m[1]);
 const native=await grown.build({woodMat:materials[0],leafMat:materials[1]});
 for(let i=0;i<grown.stems.length;i++){
  const st=grown.stems[i],source=rec.stems[i],scale=st.h/st.v.H,width=scale*(.92+st.pick*.16),mat=new THREE.Matrix4().compose(new THREE.Vector3(st.x,-.2*scale,st.z),new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),st.yaw),new THREE.Vector3(width,scale,width));
  const limits={e:[Infinity,-Infinity],n:[Infinity,-Infinity],y:[Infinity,-Infinity]};let vertices=0;
  for(const [set,lods] of Object.entries(st.v.ids))for(const ids of Object.values(lods))for(const part of ['wood','leaves']){
   const batch=native.group.getObjectByName('timber-'+set+'-'+part),range=batch.getGeometryRangeAt(ids[part],{}),a=batch.geometry.attributes.position;
   const actualMatrix=new THREE.Matrix4();batch.getMatrixAt(st.inst[set][part],actualMatrix);
   if(actualMatrix.elements.some((v,k)=>v!==Math.fround(mat.elements[k])))throw Error('Analysis matrix differs from actual native Float32 instance: '+JSON.stringify({actual:actualMatrix.elements,expected:mat.elements.map(Math.fround)}));
   for(let k=range.vertexStart;k<range.vertexStart+range.vertexCount;k++){const p=new THREE.Vector3().fromBufferAttribute(a,k).applyMatrix4(actualMatrix);for(const[key,v]of [['e',p.x],['n',-p.z],['y',p.y]]){limits[key][0]=Math.min(limits[key][0],v);limits[key][1]=Math.max(limits[key][1],v);}vertices++;}
  }
  const stemChecks=fps.map(f=>({id:f.id,...polyDistance(source.at_local_enu_m,f.pts)}));
  const bad=stemChecks.filter(x=>x.inside||x.distance<4.5);
  const house=registry.get('ouilmette_house_1812').sidecar;
  const houseNorth=Math.max(...fps.find(f=>f.id===house.id).pts.map(p=>p[1]));
  const row={level,id:source.id,at:source.at_local_enu_m,vertices,rendered_world_bounds:limits,minimum_registry_stem_distance_m:Math.min(...stemChecks.map(x=>x.distance)),registry_stem_rejections:bad,house_back_n:houseNorth,static_rendered_house_clearance_m:limits.n[0]-houseNorth,wind_reserved_m:1};
  if(bad.length||row.static_rendered_house_clearance_m<=row.wind_reserved_m)throw Error('Actual native shrub geometry or unchanged4.5m stem guard fails: '+JSON.stringify(row));
  rows.push(row);
 }
 native.dispose();
}
const old=rec.stems.map((s,i)=>({id:s.id,at:[s.at_local_enu_m[0],i<3?350.2:352]})).map(s=>({id:s.id,...polyDistance(s.at,fps.find(f=>f.id==='ouilmette_house_1812').pts)}));
if(old.some(x=>x.inside||x.distance>=4.5))throw Error('Original negative control not rejected as recorded');
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const report={status:'PASS_NATIVE_GENERATED_SHRUB_ENVELOPE_AND_UNCHANGED_STEM_GUARD',method:'Unmodified native TreeInstances.add/build, native generated wood+leaf vertices at all emitted LODs and exact current instance yaw/width/height matrices; native footprintsFrom for the actual published registry. Static envelope with conservative1m reserve, not universal arbitrary wind/GPU proof. Original positions independently fail unchanged4.5m margin. No house exemption.',rows,old_position_negative_control:old,files:['renderers/web/js/tree-instances.js','renderers/web/js/tree-model.js','renderers/web/js/walker.js','data/flora/zones/z10_settled_town.json','data/flora/plantings/ouilmette_garden_1812.json'].map(path=>({path,sha256:sha(app+'/'+path)}))};
fs.writeFileSync(out+'/SHRUB-ENVELOPE.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,rows:rows.length,minPhysicalHouseClearance:Math.min(...rows.map(x=>x.static_rendered_house_clearance_m)),minStemMargin:Math.min(...rows.map(x=>x.minimum_registry_stem_distance_m))},null,2));
