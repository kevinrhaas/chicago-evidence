"""Plan or dispatch the repository's existing single-PR lap. No code edits or merge.
Root must explicitly grant --dispatch after actual branch checkpoint and native lap release.
"""
from pathlib import Path
import argparse,datetime,json,importlib.util,hashlib
from urllib.request import Request,urlopen
P=argparse.ArgumentParser(description=__doc__);P.add_argument('--head',required=True);P.add_argument('--output',required=True);P.add_argument('--dispatch',action='store_true');a=P.parse_args()
spec=importlib.util.spec_from_file_location('m','/workspace/four-case-code-rest-transport-v5-20261029/publish_native.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
O=Path(a.output);O.mkdir(exist_ok=False)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
pr=m.api('pulls/1456');save('PR-BEFORE.json',pr);assert pr['state']=='open'and not pr['draft']and pr['head']['sha']==a.head and pr['head']['ref']==m.BRANCH and pr['base']['ref']=='dev'and pr['base']['repo']['full_name']==m.REPO
assert 'hold'not in{x['name']for x in pr['labels']}
dev=m.api('git/ref/heads/dev')['object']['sha'];workflow=m.api('actions/workflows/chicago-4d-pr-lap.yml');save('WORKFLOW.json',workflow);assert workflow['state']=='active'and workflow['path']=='.github/workflows/chicago-4d-pr-lap.yml'
lock=m.api('git/ref/heads/lap/pr-1456',missing=True);save('LAP-LOCK-BEFORE.json',lock)
plan={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SINGLE_PR_NATIVE_LAP_PLAN_ONLY','repository':m.REPO,'PR':1456,'expected_branch_head':a.head,'dev_observed':dev,'workflow_id':workflow['id'],'workflow_path':workflow['path'],'body':{'ref':'dev','inputs':{'only':'1456'}},'native_lap_lock_absent':lock is None,'requirements':['Root official done --pr1456 must set originals REVIEW; native lap1456 release must finish before dispatch','Any hand-authored conflict is refused; no manual picking side','Lap pushes regenerated branch without localgate; exactnewhead requiredCI gate must succeed','After lap observe actual PR head+parents/latestdev scope, exact currentchecks andclean mergeability','Root performs standard expectedsha merge into dev only; no main promotion'],'no_primary_source_objects_refs_or_ticket_mutations':True};save('PLAN.json',plan)
if not a.dispatch:print(json.dumps(plan,indent=2));raise SystemExit(0)
assert lock is None,'Native own lap must be explicitly released before remote lap dispatch'
fresh=m.api('pulls/1456');assert fresh['state']=='open'and not fresh['draft']and fresh['head']['sha']==a.head and fresh['base']['ref']=='dev'and'hold'not in{x['name']for x in fresh['labels']}
assert m.api('git/ref/heads/lap/pr-1456',missing=True)is None
started=datetime.datetime.now(datetime.timezone.utc).isoformat();req=Request('https://api.github.com/repos/'+m.REPO+'/actions/workflows/chicago-4d-pr-lap.yml/dispatches',data=json.dumps(plan['body']).encode(),headers={'User-Agent':'Chicago-PR1456-single-native-lap','Accept':'application/vnd.github+json','Content-Type':'application/json'},method='POST')
with urlopen(req,timeout=60)as r:assert r.status==204 and r.read()==b''
save('DISPATCH.json',{'status':'ACTUAL_SINGLE_PR_NATIVE_LAP_DISPATCH_ACCEPTED_NOT_LAP_RESULT','started_at':started,'HTTP':204,'workflow_path':workflow['path'],'body':plan['body'],'head_before':a.head,'dev_before':dev,'no_merge_or_CI_success_claim':True});print('Single-PR1456 native lap dispatch accepted; actual run/head/gate must be observed separately.')
