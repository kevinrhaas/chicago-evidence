from pathlib import Path
import json
P=Path(__file__).resolve().parent;F=P/'frozen-inputs';D=P/'prototype'
s=(F/'fort_structure_params.py').read_text()
def replace(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
replace('"upper_overhang_m", "lantern", "gallery_storeys", "face_openings",','"upper_overhang_m", "lantern", "gallery_storeys", "face_openings", "gallery_access",')
replace('    gallery_storeys: int = field(default=1, kw_only=True)','    gallery_storeys: int = field(default=1, kw_only=True)\n    gallery_access: dict | None = field(default=None, kw_only=True)')
replace('        if self.gallery_storeys == 2:\n','        if self.gallery_access is not None:\n            gallery_access_layout(self)\n        if self.gallery_storeys == 2:\n')
replace('        gallery_storeys=val("gallery_storeys", 1),','        gallery_storeys=val("gallery_storeys", 1),\n        gallery_access=val("gallery_access", None),')
layout=Path('/tmp/T2388-gallery-access-next-increment-20261029/geometry_plan.py').read_text();layout=layout[layout.index('def gallery_access_layout'):]
start='def gallery_access_layout(width,depth,wall_height,storeys,gallery,gallery_storeys,spec=None):'
layout=layout.replace(start,'''def gallery_access_layout(p: FortStructureParams):
    width,depth,wall_height,storeys,gallery,gallery_storeys,spec=(p.width_m,p.depth_m,p.wall_height_m,p.stories,p.gallery,p.gallery_storeys,p.gallery_access)''')
layout=layout.replace("    if not gallery or gallery_storeys != 2 or storeys != 2:","    if p.kind not in ('quarters','barracks') or not gallery or gallery_storeys != 2 or storeys != 2:")
layout=layout.replace("    level=wall_height/storeys;", """    if p.face_openings is None:
        raise ValueError('gallery access needs explicit aperture layouts, including the selected end')
    level=wall_height/storeys;
    ytop=depth-back
    face='left' if spec['end']=='min' else 'right'
    for opening in wall_openings(p,face):
        if max(opening['u0'],ytop)<min(opening['u1'],depth) and max(opening['z0'],level-.14)<min(opening['z1'],level):
            raise ValueError('gallery return deck would cross a stated end-wall aperture')
    """)
layout=layout.replace("raise ValueError(","raise ParamError(")
s+='\n\n'+layout
(D/'fort_structure_params.py').write_text(s)
s=(F/'fort_structure.py').read_text();s=s.replace('FortStructureParams, wall_openings, tower_opening_layout','FortStructureParams, wall_openings, tower_opening_layout, gallery_access_layout')
a='    for x in (0.0, w - post):\n        b.add_box(x, d, upper + rail - 0.10,'
b='''    for x in (0.0, w - post):
        if p.gallery_access is not None and x == (0.0 if p.gallery_access['end'] == 'min' else w-post):
            continue
        b.add_box(x, d, upper + rail - 0.10,''';assert s.count(a)==1;s=s.replace(a,b)
a='''               c, M_ROOF)


def _explicit_openings''';b='''               c, M_ROOF)
    if p.gallery_access is not None:
        _gallery_access(b, p)


def _explicit_openings''';assert s.count(a)==1;s=s.replace(a,b)
s+='\n'+(P/'access_geometry_fragment.py').read_text();(D/'fort_structure.py').write_text(s)
r=json.loads(Path('/tmp/T2388-gallery-access-next-increment-20261029/COMMANDANT-WITH-ACCESS-UNSUPPORTED-CANDIDATE.json').read_text());f=r['phases'][0]['form']
f['gallery_access']['note']=f['gallery_access']['note'].replace('PREPARATION ONLY, NOT CONSUMED BY THE CURRENT KIT. ','')+' Timber sections, fifteen-riser layout, ground seating and end assignment are reconstructed proxies; no authentic period regulation, hidden door or1835continuity is asserted. New timber stringer tails seat0.195m below nominal grade as a reconstructed socket; actual terrain/ground walking still requires verification.'
f['gallery']['note']=f['gallery']['note'].replace('PROPOSED T-2388 PARTIAL FRONT-GALLERY HYPOTHESIS, NOT ADOPTED. ','').replace('The existing two-storey front helper supplies one straight gallery only. The visible corner return, outside stairs and source-specific group-camera fit remain unresolved;','The existing two-storey front and the explicit reconstructed access layout supply one return and outside stair. Source-specific group-camera fit remains unresolved;')
(D/'fort_dearborn_commandants_quarters.json').write_text(json.dumps(r,indent=2)+'\n');print('External implementation generated; primary unchanged')
