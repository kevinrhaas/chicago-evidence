from pathlib import Path
import sys,types,importlib.util,json,dataclasses,hashlib,datetime,math,copy
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(A/'generators'))
# The native raw MeshBuilder lists are pure Python until to_object. No bpy API is
# called: this empty module only permits importing the same helper class.
sys.modules['bpy']=types.ModuleType('bpy')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
oldp=load('old_fort_access_params',P/'frozen-inputs/fort_structure_params.py');newp=load('new_fort_access_params',P/'prototype/fort_structure_params.py')
def loadbuilder(name,path,params):
 sys.modules['archetypes.fort_structure_params']=params
 return load(name,path)
old=loadbuilder('old_fort_access_builder',P/'frozen-inputs/fort_structure.py',oldp);new=loadbuilder('new_fort_access_builder',P/'prototype/fort_structure.py',newp)
def geometry(module,p,name):
 p.validate();b=module.TonedBuilder(name)
 fn={'parade':module._parade,'root_house':module._root_house,'tower':module._tower,'flagstaff':module._flagstaff}.get(p.kind,module._building);fn(b,p)
 value={'verts':b.verts,'faces':b.faces,'conf':b.conf,'mat_index':b.mat_index,'tone':b.tone,'named':b.named}
 return b,value,hashlib.sha256(json.dumps(value,separators=(',',':'),sort_keys=True,allow_nan=False).encode()).hexdigest()
manifest=json.loads((A/'assets/manifest.json').read_text());family={k:v for k,v in manifest.get('assets',manifest).items()if v.get('archetype')=='fort_structure'};rows=[]
for key,e in family.items():
 path=A/'data/structures'/(e['structure_id']+'.json');raw=path.read_bytes();r=json.loads(raw);phase=next(x for x in r['phases']if x['id']==e['phase_id']);a=oldp.from_phase(phase,r);b=newp.from_phase(phase,r);ad=dataclasses.asdict(a);bd=dataclasses.asdict(b);assert bd.pop('gallery_access')is None;assert ad==bd,key
 ab,av,ah=geometry(old,a,key.removesuffix('.glb'));bb,bv,bh=geometry(new,b,key.removesuffix('.glb'));assert av==bv and ah==bh,key
 assert path.read_bytes()==raw
 rows.append({'asset':key,'record_sha256':hashlib.sha256(raw).hexdigest(),'pure_geometry_sha256':ah,'verts':len(ab.verts),'faces':len(ab.faces),'triangles_untriangulated_fan_count':sum(len(f)-2 for f in ab.faces),'all_vertex_face_confidence_material_tone_named_exact':True})
r=json.loads((P/'prototype/fort_dearborn_commandants_quarters.json').read_text());p=newp.from_phase(r['phases'][0],r);b,v,h=geometry(new,p,'fort_dearborn_commandants_quarters__brick_1816');layout=newp.gallery_access_layout(p)
# Isolate the new helper to inspect every raw polygon and confidence directly.
access=new.TonedBuilder('access_only');new._gallery_access(access,p)
assert all(c==1. for c in access.conf)
assert all(math.isfinite(x) for pt in access.verts for x in pt)
degenerate=[]
for i,face in enumerate(access.faces):
 pts=[access.verts[k]for k in face];total=[0.,0.,0.]
 for a,bb in zip(pts,pts[1:]+pts[:1]):
  total[0]+=(a[1]-bb[1])*(a[2]+bb[2]);total[1]+=(a[2]-bb[2])*(a[0]+bb[0]);total[2]+=(a[0]-bb[0])*(a[1]+bb[1])
 if sum(x*x for x in total)<1e-18:degenerate.append(i)
assert not degenerate,degenerate
refused=[]
for label,change in [('bad_end',{'end':'east'}),('nan',{'stair_run_m':float('nan')}),('bool',{'stair_width_m':True}),('too_long',{'return_m':4,'stair_run_m':5}),('bad_tread',{'stair_run_m':2}),('extra',{'hidden':1})]:
 rr=copy.deepcopy(r);rr['phases'][0]['form']['gallery_access']['value'].update(change)
 try:newp.from_phase(rr['phases'][0],rr);raise AssertionError(label)
 except newp.ParamError as e:refused.append({'case':label,'error':str(e)})
# Wrong structure/gallery context also refuses, before mesh generation.
for label,changes in [('no_gallery',{'gallery':False}),('single_story',{'stories':1}),('wrong_kind',{'kind':'tower'}),('unread_end',{'face_openings':None}),('deck_hits_window',{'face_openings':[{'face':'left','kind':'window','u0':5.,'u1':6.,'z0':2.5,'z1':3.5}]})]:
 try:dataclasses.replace(p,**changes).validate();raise AssertionError(label)
 except newp.ParamError as e:refused.append({'case':label,'error':str(e)})
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'PURE raw native MeshBuilder capture ONLY: bpy stub never used, no to_object/export/UV/GLB/app/walking. Native25-master proof remains required.','default_records':len(rows),'defaults':rows,'candidate':{'geometry_sha256':h,'verts':len(b.verts),'faces':len(b.faces),'triangles_fan_count':sum(len(f)-2 for f in b.faces),'access_only_verts':len(access.verts),'access_only_faces':len(access.faces),'access_only_triangles_fan_count':sum(len(f)-2 for f in access.faces),'all_new_confidence_reconstructed':True,'degenerate_raw_polygons':degenerate,'bounds_min':[min(q[i]for q in access.verts)for i in range(3)],'bounds_max':[max(q[i]for q in access.verts)for i in range(3)],'layout':layout},'invalid_refusals':refused,'primary_write':False}
(P/'PURE-DEFAULT25-GEOMETRY-CAPTURE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'default_records':len(rows),'all_default_geometry_exact':True,'candidate_triangles':result['candidate']['triangles_fan_count'],'access_triangles':result['candidate']['access_only_triangles_fan_count'],'invalid_refusals':len(refused)}))
