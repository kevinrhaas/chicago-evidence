
def _gallery_access(b: MeshBuilder, p: FortStructureParams) -> None:
    """One opt-in side return and straight exterior flight; every new piece is R."""
    layout = gallery_access_layout(p)
    if layout is None:
        return
    reach, post, deck, rail, pale = 2.1, 0.14, 0.14, 0.95, 0.055
    end = p.gallery_access['end']
    upper, d, wz = p.storey_height_m, p.depth_m, p.wall_height_m
    back, run, sw = (p.gallery_access[k] for k in ('return_m','stair_run_m','stair_width_m'))
    ytop, ybottom = d-back, d-back-run
    c = max(1.0, p.conf('gallery_access'))
    def point(u,v,z):
        return (u if end == 'min' else p.width_m-u, v, z)
    def poly(pts, mat=M_TRIM):
        mapped=[point(*q) for q in pts]
        b.add_poly(mapped if end == 'min' else list(reversed(mapped)), c, mat)
    def box(u0,v0,z0,u1,v1,z1,mat=M_TRIM,skip=()):
        a,bx=(u0,u1) if end == 'min' else (p.width_m-u1,p.width_m-u0)
        b.add_box(a,v0,z0,bx,v1,z1,c,mat,skip=skip)
    def prism(u0,u1,v0,v1,z0,z1,thick):
        # A constant-vertical-section sloping timber; face order is outward.
        top=[(u0,v0,z0),(u1,v0,z0),(u1,v1,z1),(u0,v1,z1)]
        bottom=[(u,v,z-thick) for u,v,z in top]
        poly(top);poly(list(reversed(bottom)))
        for i in range(4):
            j=(i+1)%4;poly([bottom[i],bottom[j],top[j],top[i]])
    R=reach+.15
    def roof_z(u,v):
        return wz-.45*max(max(-u,0)/R,max(v-d,0)/R)
    # Side canopy plus two mitered corner triangles: one surface at every point.
    if ytop < d:
        poly([(-R,ytop,roof_z(-R,ytop)),(0,ytop,wz),(0,d,wz),(-R,d,roof_z(-R,d))],M_ROOF)
    poly([(0,d,wz),(-R,d+R,wz-.45),(-R,d,wz-.45)],M_ROOF)
    poly([(0,d,wz),(0,d+R,wz-.45),(-R,d+R,wz-.45)],M_ROOF)
    # No second coplanar beam top: the canopy itself caps each contact.
    beam_bottom=wz-.45-post
    def beam_footprint(uv):
        bottom=[(u,v,beam_bottom) for u,v in uv]
        top=[(u,v,roof_z(u,v)) for u,v in uv]
        poly(list(reversed(bottom)))
        for i in range(len(uv)):
            j=(i+1)%len(uv);poly([bottom[i],bottom[j],top[j],top[i]])
    if ytop<d:
        beam_footprint([(-reach,ytop),(-reach+post,ytop),(-reach+post,d),(-reach,d)])
    beam_footprint([(-reach,d),(-reach+post,d),(-reach+post,d+reach-post),(-reach,d+reach)])
    beam_footprint([(-reach+post,d+reach-post),(-reach+post,d+reach),(-reach,d+reach)])
    n=max(1,math.ceil((back+reach)/3.0))
    for i in range(n+1):
        v=ytop+post/2+(back+reach-post)*i/n
        box(-reach,v-post/2,0.,-reach+post,v+post/2,beam_bottom,skip=('bottom',))
    # New upper deck meets the retained front deck on its selected end edge.
    box(-reach,ytop,upper-deck,0,d+reach,upper)
    # Outer end-gallery rail. Close its far edge except the actual stair-width gap.
    box(-reach,ytop,upper+rail-.10,-reach+post,d+reach,upper+rail)
    count=max(1,math.ceil((back+reach)/.18))
    for i in range(count):
        v=ytop+(back+reach)*(i+.5)/count
        box(-reach+(post-pale)/2,v-pale/2,upper,-reach+(post+pale)/2,v+pale/2,upper+rail-.10)
    if sw<reach-post:
        box(-reach+sw,ytop,upper+rail-.10,0,ytop+post,upper+rail)
        count=max(1,math.ceil((reach-sw)/.18))
        for i in range(count):
            u=-reach+sw+(reach-sw)*(i+.5)/count
            box(u-pale/2,ytop+(post-pale)/2,upper,u+pale/2,ytop+(post+pale)/2,upper+rail-.10)
    # Open timber treads; the final top meets upper exactly. Stringer tails seat
    # 0.195 m below nominal grade as an explicit reconstructed ground socket.
    steps=layout['steps'];rise=layout['rise_m'];tread=layout['tread_m']
    for i in range(steps):
        top=(i+1)*rise
        box(-reach,ybottom+i*tread,top-.055,-reach+sw,ybottom+(i+1)*tread,top)
    for u0,u1 in ((-reach,-reach+.09),(-reach+sw-.09,-reach+sw)):
        prism(u0,u1,ybottom,ytop,-.055,upper-.055,.14)
    # Two sloping handrails, with posts seated at successive tread boundaries.
    for u in (-reach+post/2,-reach+sw-post/2):
        prism(u-post/2,u+post/2,ybottom,ytop,rail,upper+rail,.10)
        for i in range(steps+1):
            v=ybottom+i*tread;z=i*rise
            box(u-pale/2,v-pale/2,z,u+pale/2,v+pale/2,z+rail-.10)
