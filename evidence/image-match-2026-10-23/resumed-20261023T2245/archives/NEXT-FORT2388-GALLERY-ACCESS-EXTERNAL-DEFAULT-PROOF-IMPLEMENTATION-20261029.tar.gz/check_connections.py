from pathlib import Path
import runpy,dataclasses,json,math,collections,datetime
P=Path(__file__).resolve().parent;g=runpy.run_path(str(P/'capture_geometry.py'));new,newp,p=g['new'],g['newp'],g['p'];geometry=g['geometry']
_,base,_=geometry(new,dataclasses.replace(p,gallery_access=None),'fort_dearborn_commandants_quarters__brick_1816')
_,actual,_=geometry(new,p,'fort_dearborn_commandants_quarters__brick_1816')
access=new.TonedBuilder('access_only');new._gallery_access(access,p)
removed=new.TonedBuilder('removed_end_rail');w,d,upper=p.width_m,p.depth_m,p.storey_height_m;post,reach,rail,baluster,pitch=.14,2.1,.95,.055,.18;c=1.;x=0.
removed.add_box(x,d,upper+rail-.10,x+post,d+reach-post,upper+rail,c,new.M_TRIM)
count=max(1,math.ceil((reach-post)/pitch))
for i in range(count):
 y=d+(reach-post)*(i+.5)/count;removed.add_box(x+(post-baluster)/2,y-baluster/2,upper,x+(post+baluster)/2,y+baluster/2,upper+rail-.10,c,new.M_TRIM)
def value(b):return {'verts':b.verts,'faces':b.faces,'conf':b.conf,'mat_index':b.mat_index,'tone':b.tone}
def faces(v):
 return collections.Counter((tuple((v['verts'][j],v['conf'][j],v['tone'][j])for j in f),v['mat_index'][i])for i,f in enumerate(v['faces']))
expected=faces(base)-faces(value(removed))+faces(value(access));assert expected==faces(actual)
min_b=new.TonedBuilder('min_access');new._gallery_access(min_b,p)
mirrored=dataclasses.replace(p,gallery_access=dict(p.gallery_access,end='max'));max_b=new.TonedBuilder('max_access');new._gallery_access(max_b,mirrored)
assert len(min_b.faces)==len(max_b.faces)
# Each corresponding polygon must mirror and reverse winding, up to cyclic start.
def cyc(points):return min(tuple(points[i:]+points[:i])for i in range(len(points)))
expected_mirror=collections.Counter(cyc([(w-u,v,z)for u,v,z in [min_b.verts[j]for j in f]][::-1])for f in min_b.faces)
actual_mirror=collections.Counter(cyc([max_b.verts[j]for j in h])for h in max_b.faces)
assert expected_mirror==actual_mirror
for b in [min_b,max_b]:
 for i,f in enumerate(b.faces):
  if b.mat_index[i]!=new.M_ROOF:continue
  pts=[b.verts[j]for j in f];signed=sum(a[0]*q[1]-q[0]*a[1]for a,q in zip(pts,pts[1:]+pts[:1]));assert signed>0
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'PURE raw polygons only; no native export/clearance/walking acceptance','front_only_triangles_fan':sum(len(f)-2 for f in base['faces']),'removed_selected_end_rail_triangles_fan':sum(len(f)-2 for f in removed.faces),'added_access_triangles_fan':sum(len(f)-2 for f in access.faces),'final_candidate_triangles_fan':sum(len(f)-2 for f in actual['faces']),'only_change_to_existing_gallery':'Exact selected end-rail removal; all remaining prior polygons/confidence/material/tone preserved, plus isolated access geometry.','min_max_mirror_and_winding_exact':True,'all_new_roof_polygons_face_up':True,'no_native_mesh_default_proof':True};(P/'PURE-CONNECTIONS-AND-MIRROR-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
