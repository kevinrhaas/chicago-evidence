from pathlib import Path
import json,difflib,hashlib,datetime
root=Path('/workspace/chicago/chicago/4d'); out=Path('/tmp/miller-next-20261027'); base={}; candidates={}
def edit(rel, fn):
 raw=(root/rel).read_text(); new=fn(raw); assert new!=raw
 base[rel]={'sha256':hashlib.sha256(raw.encode()).hexdigest(),'bytes':len(raw.encode())}
 dest=out/'candidate'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(new);candidates[rel]=new
 return raw,new
def once(s,a,b):
 assert s.count(a)==1,(a[:60],s.count(a)); return s.replace(a,b)
def params(s):
 s=once(s,'    frame_addition_cladding: str = field(default="clapboard", kw_only=True)\n','''    frame_addition_cladding: str = field(default="clapboard", kw_only=True)
    # Pictured short flue through the addition's own ridge: (fraction, width, head
    # above ridge). None keeps the existing exterior end stack. All metric choices
    # are reconstructed; this never relocates the log core's separate first stack.
    frame_addition_ridge_stack: tuple | None = field(default=None, kw_only=True)
''')
 s=once(s,'        if self.chimney_ridge_at is not None:\n            if len(self.chimney_ridge_at) != self.chimneys:', '''        if self.frame_addition_ridge_stack is not None:
            if not self.frame_addition or self.chimneys != 2 or self.chimney_ridge_at is not None:
                raise ParamError("frame_addition_ridge_stack needs one core stack and one "
                                 "addition stack, not a core-ridge list")
            spec = self.frame_addition_ridge_stack
            if len(spec) != 3 or any(isinstance(v, bool) or not isinstance(v, (int, float))
                                     or not math.isfinite(v) for v in spec):
                raise ParamError("frame_addition_ridge_stack is (ridge fraction, width m, head m)")
            f, width, head = spec
            if not 0.05 <= f <= 0.95 or not 0.4 <= width <= 1.2 or not 0.3 <= head <= 1.5:
                raise ParamError("frame_addition_ridge_stack needs fraction 0.05..0.95, "
                                 "width 0.4..1.2 m and head 0.3..1.5 m")
        if self.chimney_ridge_at is not None:
            if len(self.chimney_ridge_at) != self.chimneys:''')
 s=once(s,'        frame_addition_cladding=str(val("frame_addition_cladding", "clapboard")),\n','''        frame_addition_cladding=str(val("frame_addition_cladding", "clapboard")),
        frame_addition_ridge_stack=(None if val("frame_addition_ridge_stack") is None
                                    else tuple(val("frame_addition_ridge_stack"))),
''')
 return s
def producer(s):
 s=once(s,"      gable, mirroring the core's. The addition's roof is always built ridge-along-x\n", "      gable by default, mirroring the core's. A stated frame_addition_ridge_stack\n      instead puts its short flue through the addition's own ridge. That roof is built ridge-along-x\n")
 s=once(s,'''        _stack(b, ax0, ay0, ax1, ay1, add_ridge_z, conf, mat, at_min=False,
               gable_axis="x")''','''        if p.frame_addition_ridge_stack is None:
            _stack(b, ax0, ay0, ax1, ay1, add_ridge_z, conf, mat, at_min=False,
                   gable_axis="x")
        else:
            # The addition always runs its ridge along x, independently of the
            # log core's axis. Only its existing second stack changes disposition.
            f, width, head = p.frame_addition_ridge_stack
            half = width / 2.0
            rx0 = ax0 + 0.26 if p.frame_addition_side == "end" else ax0
            x = rx0 + f * (ax1 - rx0)
            y = (ay0 + ay1) / 2.0
            foot = add_ridge_z - half * math.tan(math.radians(p.roof_pitch_deg)) - 0.25
            b.add_box(x - half, y - half, foot, x + half, y + half,
                      add_ridge_z + head,
                      p.worst_conf("chimneys", "frame_addition_ridge_stack"), mat,
                      skip=("bottom",))''')
 return s
def record(s):
 r=json.loads(s);form=r['phases'][0]['form']; old=form['chimneys'];
 new=dict(old);new['note']='The count remains the existing inference of one stack per element. The 1867 Blanchard/Shober retrospective 1833 view visibly shows a short flue penetrating the tall range\'s ridge; frame_addition_ridge_stack records that inferred form. Its exact station and section are reconstructed. The separate low cabin\'s stack is not resolved in that view and retains its existing inferred exterior placement, not a pictured claim or an absence finding.'
 spec={'value':[0.4,0.45,0.45],'confidence':'reconstructed','sources':['blanchard_shober_1867_wolf_point'],'note':'The cleared 1867 lithograph, labelled Wolf\'s Point in 1833, shows a small head through the ridge of Miller\'s tall log-and-board range. This replaces its conspicuous full-height exterior end stack, leaving the low cabin\'s inferred stack and the count of two unchanged. The picture supports roof penetration and a short visible head, not exact dimensions: fraction 0.40 from the addition\'s -x ridge end, 0.45 m square shaft and 0.45 m head above ridge are reconstructed first-fit choices to be checked in the unchanged native comparison camera. They are not surveyed measurements, an independently solved historical pose, or evidence of unchanged condition on 1 July 1835. The source is retrospective and only pictured form is inferred. L-miller-frame-ridge-stack-2381 records the metric choices. Remaining massing, opening count, side-wing composition and all-picture fit stay open.'}
 def member(name,obj):
  lines=json.dumps(obj,indent=2,ensure_ascii=True).splitlines();return '        '+json.dumps(name)+': '+lines[0]+'\n'+'\n'.join('        '+x for x in lines[1:])
 return once(s,member('chimneys',old),member('chimneys',new)+',\n'+member('frame_addition_ridge_stack',spec))
patch=[]
for rel,fn in [('generators/archetypes/log_dwelling_params.py',params),('generators/archetypes/log_dwelling.py',producer),('data/structures/miller_house.json',record)]:
 a,b=edit(rel,fn);patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel))
(out/'PROPOSED.patch').write_text(''.join(patch))
lib='''### L-miller-frame-ridge-stack-2381 — the Miller range's short roof flue

The 1867 Blanchard/Shober lithograph labelled Wolf's Point in 1833 (blanchard_shober_1867_wolf_point) shows a small flue through the tall range's ridge, unlike the previous full-height exterior end stack. Roof penetration and a short head are inferred pictured form. Fraction 0.40 along the addition's own x ridge, 0.45 m square shaft and 0.45 m exposed head are reconstructed first-fit values, not measurements. The separate log core's existing inferred stack, total count, massing and placement remain. The retrospective depiction does not prove identical July 1835 appearance. Actual same-camera comparison, other-view review and all normal qualification remain owed; no matches or original completion is claimed.
'''
(out/'LIBERTY-PARAGRAPH.md').write_text(lib)
(out/'BASE-INPUTS.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_root':str(root),'paths':base,'source_mutated':False,'proposal_only':True},indent=2)+'\n')
print(json.dumps({'patch_bytes':(out/'PROPOSED.patch').stat().st_size,'candidate_paths':list(candidates),'base_guard':base},indent=2))
