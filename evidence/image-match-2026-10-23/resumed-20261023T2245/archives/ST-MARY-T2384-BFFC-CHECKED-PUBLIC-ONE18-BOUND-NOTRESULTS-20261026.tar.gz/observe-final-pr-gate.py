from pathlib import Path
import datetime,hashlib,json,re,time,urllib.request,sys,subprocess
H=Path('/workspace/shared/st-mary-jail8cd-stack-runtime-20261026T1316')
CFILE=Path(sys.argv[1]) if len(sys.argv)>1 else H/'FINAL-CANDIDATE.json'
C=json.loads(CFILE.read_text())
HEAD=C['head'];TREE=C['tree'];BASE=C['base']
OUT=H/('native-final-pr-gate-'+HEAD[:12]);OUT.mkdir(exist_ok=True)
API='https://api.github.com/repos/kevinrhaas/chicago/'
def get(path,raw=False):
    result=subprocess.run(['gh','api','repos/kevinrhaas/chicago/'+path,'--header','Cache-Control: no-cache'],capture_output=True,timeout=90)
    if result.returncode:
        raise RuntimeError('GitHub CLI read failed: '+result.stderr.decode('utf-8','replace')[:500])
    return result.stdout if raw else json.loads(result.stdout)

def save(name,value):
    path=OUT/name;data=value if isinstance(value,bytes) else (json.dumps(value,indent=2)+'\n').encode()
    if path.exists():
        assert path.read_bytes()==data,'Never overwrite preserved evidence'
    else:
        path.write_bytes(data)
def harvest(run):
    attempt=run['run_attempt'];rid=run['id'];prefix='run-'+str(rid)+'-attempt'+str(attempt)
    jobs=get('actions/runs/'+str(rid)+'/attempts/'+str(attempt)+'/jobs?per_page=100')
    save(prefix+'-metadata.json',run);save(prefix+'-jobs.json',jobs)
    matches=[j for j in jobs['jobs'] if j['name']=='gate' and j['status']=='completed']
    assert len(matches)==1
    job=matches[0]
    assert job.get('run_attempt',attempt)==attempt
    raw=get('actions/jobs/'+str(job['id'])+'/logs',raw=True)
    name=prefix+'-job-'+str(job['id'])+'.log';save(name,raw)
    text=re.sub(r'\x1b\[[0-9;]*m','',raw.decode('utf-8','replace'))
    lines=text.splitlines();checkout=None
    for i,line in enumerate(lines[:-1]):
        if '[command]' in line and 'git log -1 --format=%H' in line:
            match=re.search(r'Z ([0-9a-f]{40})$',lines[i+1])
            if match:
                checkout=match.group(1)
    assert checkout,'Missing actual checkout hash is not a pass'
    commit=get('git/commits/'+checkout);save(prefix+'-actual-checkout-commit.json',commit)
    compare=get('compare/'+HEAD+'...'+checkout);save(prefix+'-head-to-actual-checkout.json',compare)
    cleaned=[re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+Z\s?','',line) for line in lines]
    full='\n'.join(cleaned)
    footer=re.findall(r'^CHECK PASS — (\d+) steps, none red\.$',full,re.M)
    selftests=re.findall(r'^\s*(\d+) of them are self-tests that prove a gate by breaking it;',full,re.M)
    args=re.findall(r'check-changelog-entry\.mjs\s+"?([0-9a-f]{40})"?\s+"?([0-9a-f]{40})"?',full)
    steps={s['name']:s for s in job['steps']}
    actual_steps={name:steps.get(name) for name in ['Install validator dependencies','Run the gate','Does this change carry a changelog entry?']}
    steps_ok=all(value and value['conclusion']=='success' for value in actual_steps.values())
    readers=bool(re.search(r'^\s*C4D_GATE_REQUIRE_READERS: 1\s*$',full,re.M))
    required_base=bool(re.search(r'^\s*C4D_GATE_REQUIRE_BASE: 1\s*$',full,re.M))
    result={'head':HEAD,'expected_tree':TREE,'base':BASE,'run':rid,'run_attempt':attempt,'job':job['id'],'workflow_id':run['workflow_id'],'event':run['event'],'run_head_sha':run['head_sha'],'actual_checkout':checkout,'actual_checkout_tree':commit['tree']['sha'],'actual_checkout_parents':[x['sha'] for x in commit['parents']],'actual_head_to_checkout_merge_base':compare['merge_base_commit']['sha'],'run_conclusion':run['conclusion'],'job_conclusion':job['conclusion'],'gate_steps':int(footer[-1]) if footer else None,'self_tests':int(selftests[-1]) if selftests else None,'required_readers':readers,'required_base':required_base,'actual_changelog_argument_pairs':[list(x) for x in sorted(set(args))],'required_steps':actual_steps,'raw_log':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    result['status']='PASS' if (run['event']=='pull_request' and run['head_sha']==HEAD and run['conclusion']=='success' and job['conclusion']=='success' and steps_ok and commit['tree']['sha']==TREE and compare['merge_base_commit']['sha']==HEAD and readers and required_base and footer and int(footer[-1])==C['expected_gate_steps'] and selftests and int(selftests[-1])==C['expected_self_tests'] and args and all(x==(BASE,HEAD) for x in args)) else 'FAIL'
    # Keep strict PASS unchanged; distinguish an actually green GitHub merge tree
    # from certification of this older immutable cumulative source candidate.
    actual_native_success=bool(run['event']=='pull_request' and run['head_sha']==HEAD and run['conclusion']=='success' and job['conclusion']=='success' and steps_ok and readers and required_base and footer and int(footer[-1])==C['expected_gate_steps'] and selftests and int(selftests[-1])==C['expected_self_tests'] and args)
    result['actual_native_gate_success']=actual_native_success
    result['frozen_candidate_certified']=result['status']=='PASS'
    if result['status']!='PASS' and actual_native_success:
        result['status']='HOSTED_NATIVE_PASS_DIFFERENT_MERGE_INPUTS_NOT_FROZEN_CANDIDATE_CERTIFICATE'
        result['qualification']='Current dev can advance after candidate freeze. Actual native pass is retained, but different checkout tree/base args do not certify this frozen source; latest integration/native hash proof and required revalidation remain pending.'
    save(prefix+'-VERIFIED.json',result);save('FINAL_ACTUAL_RESULT.json',result)
    return result
while True:
    errors=[];selected=None
    try:
        response=get('actions/workflows/chicago-4d-check.yml/runs?event=pull_request&head_sha='+HEAD+'&per_page=100')
        rows=[r for r in response['workflow_runs'] if r['head_sha']==HEAD and r['event']=='pull_request' and any(p['number']==1334 for p in r['pull_requests'])]
        if rows:
            selected=max(rows,key=lambda r:r['id'])
            assert selected['head_branch']==C['code_branch']
    except Exception as error:
        errors.append({'type':type(error).__name__,'HTTP':getattr(error,'code',None)})
    snapshot={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':HEAD,'tree':TREE,'base':BASE,'run':selected,'read_errors':errors,'state':'WAIT_NOT_PASS'}
    save('snapshot-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%f')+'.json',snapshot)
    (OUT/'LATEST.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    print(json.dumps({'at':snapshot['at'],'run':selected['id'] if selected else None,'status':selected['status'] if selected else 'NOT_FOUND_NOT_PASS','attempt':selected['run_attempt'] if selected else None,'errors':errors}),flush=True)
    if selected and selected['status']=='completed' and not errors:
        try:
            result=harvest(selected)
        except Exception as error:
            print(json.dumps({'actual_harvest_error':type(error).__name__,'HTTP':getattr(error,'code',None),'message':str(error)[:300]}),flush=True)
        else:
            print(json.dumps(result,indent=2),flush=True)
            raise SystemExit(0 if result['status']=='PASS' else 1)
    time.sleep(60)
