from pathlib import Path
import subprocess,json,time,datetime,hashlib
P=Path('/workspace/shared/st-mary-jail8cd-stack-runtime-20261026T1316');repo=Path('/tmp/st-mary-picture-20261025');branch='steward/t2384-st-mary-picture';oldhead='3f74a5514ed6ed3cd75a80512a6cccfbab4ed919';expectedlap='3805d5c0b61913e03d3479995fa3d2f241dc604d';out=P/'git-transport-fallback';out.mkdir(mode=0o700)
def save(n,d):(out/n).write_text(json.dumps(d,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=repo).decode().strip()
print('WAIT existing sourcepipeline closure; fallback ONLY actualcheckedcommit and explicitRESTcredentialfailure.',flush=True)
while True:
 try:r=json.loads((P/'source-pipeline-reaper.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):time.sleep(5);continue
 if r.get('command_exit')is not None:break
 time.sleep(5)
assert r['all_children_reaped']
if r['command_exit']==0:
 save('RESULT.json',{'at':now(),'status':'NO_FALLBACK_NEEDED_SOURCE_PIPELINE_SUCCEEDED','no_mutation':True});raise SystemExit(0)
if not(P/'checked-commit/RESULT.json').exists():
 save('RESULT.json',{'at':now(),'status':'NO_FALLBACK_ALLOWED_NO_ACTUAL_CHECKED_COMMIT','source_pipeline_exit':r['command_exit'],'no_mutation':True});raise SystemExit(0)
logs='\n'.join(q.read_text(errors='replace')for q in P.glob('*automatic.log'))
assert 'Bad credentials'in logs or'HTTP 401'in logs,'Unclassified failure: do not guess or bypass it'
pre=json.loads((P/'required-preflight/RESULT.json').read_text());c=json.loads((P/'checked-commit/RESULT.json').read_text());assert pre['status']=='ALL3_NATIVE_PREFLIGHT_PASS'and all(pre['guards'].values())and all(q['exit']==0 for q in pre['steps']);assert c['status']=='ACTUAL_CHECKED_TREE_NORMAL_COMMIT_AND_COMMITTED_GATES_PASS'and all(q['exit']==0 for q in c['steps']);assert git('rev-parse','HEAD')==c['head']and git('rev-parse','HEAD^{tree}')==c['tree']and not git('diff','--name-only');assert git('merge-base',oldhead,c['head'])==oldhead
raw=git('ls-remote','origin','refs/heads/'+branch,'refs/heads/lap/pr-1334','refs/heads/dev');(out/'BEFORE-REMOTE-REFS.log').write_text(raw+'\n');refs={line.split()[1]:line.split()[0]for line in raw.splitlines()};assert refs['refs/heads/'+branch]in(oldhead,c['head']);assert refs.get('refs/heads/lap/pr-1334')==expectedlap,('OWN_LAP_REF_CHANGED_STOP',refs.get('refs/heads/lap/pr-1334'))
marker=json.loads(Path('/workspace/shared/jail-mary-own-laps-20261026T1227/1334-marker.json').read_text());assert marker['message'].startswith('lap PR #1334 — Codex St Mary picture frontage ');expires=datetime.datetime.fromisoformat(marker['committer']['date'].replace('Z','+00:00'))+datetime.timedelta(hours=3);assert expires>datetime.datetime.now(datetime.timezone.utc),('OWN_LAP_EXPIRED_STOP',expires.isoformat())
action='ALREADY_CHECKED_HEAD_ON_PUBLIC_BRANCH'
if refs['refs/heads/'+branch]!=c['head']:
 with(out/'normal-ff-push.log').open('x')as f:q=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','push','origin','HEAD:refs/heads/'+branch],cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 assert q.returncode==0,('NORMAL_PUSH_FAILED_NO_FORCE',q.returncode);action='NORMAL_FF_PUSH_CHECKED_HEAD_GIT_TRANSPORT'
after=git('ls-remote','origin','refs/heads/'+branch);(out/'AFTER-REMOTE-HEAD.log').write_text(after+'\n');assert after.split()[0]==c['head'];frozen=json.loads((P/'checked-commit/FROZEN-NATIVE-SMOKE-HASHES.json').read_text())
body=f'''St Mary's gains its reconstructed pictured chapel form: open belfry/cross/bell, five sash and an end door, blank gables, lower roof and far-end stack. Original footprint, placement and dates stay fixed. Original T-2384 remains DIFFERS: the visible sash setout gap is open. No original completion or new follow-up is claimed.

DRAFT dependency: Jail #1333 must land first. Checked source head `{c['head']}` merges tested Jail dependency `{c['incoming_checked_dependency']}`; tested dev base is `{c['actual_committed_base']}`, while newer remote changes remain unintegrated. The final ready-to-merge diff must contain only Mary's work.

Actual native 202 + feedback + fixed point, all 44 workbook/gzip comparisons, all 5,362 protected inputs, package/publish and all three native preflight questions passed. The code footer is {next(s for s in c['whole_footer'].splitlines()if 'CHECK PASS'in s)}. Committed changelog, ending-ID and history checks passed. All 588 selected model files remain exact; the 271 own phase rows and all other upstream registry rows remain exact. Clean native global hash `{frozen['native_global_hash']}` and separate changelog hash `{frozen['native_changelog_hash']}` are captured for later exact-input comparison.

GitHub REST credential errors blocked automatic PR-body updates and renderer dispatch. The checked branch push is confirmed by the normal Git transport; current PR/check/matrix status is not inferred from that push. Existing old-head `3f74a551` full18 evidence does not certify this cumulative candidate. After REST access returns, inspect existing/partial dispatch receipts before requesting exactly one current-head matrix. Actual latest dev integration, native hash equality/revalidation and hosted checks are still mandatory before READY/merge. Root owns READY/merge. Prior screenshot timeout and real Jail moving-frame failure remain qualified in recovery evidence.
'''
(out/'PR-BODY-PENDING-REST.md').write_text(body);result={'at':now(),'status':'CHECKED_BRANCH_NORMAL_GIT_PUSH_CONFIRMED_REST_METADATA_AND_MATRIX_UNVERIFIED','action':action,'head':c['head'],'tree':c['tree'],'known_pr':1334,'known_pr_url':'https://github.com/kevinrhaas/chicago/pull/1334','branch':branch,'tested_dev_base':c['actual_committed_base'],'incoming_checked_dependency':c['incoming_checked_dependency'],'fresh_remote_dev_from_git':refs.get('refs/heads/dev'),'expected_own_lap':expectedlap,'own_lap_expiry':expires.isoformat(),'native_hashes':frozen,'body_saved_only':True,'no_REST_PR_or_matrix_claim':True,'dispatch_recovery':'Inspect sourcepipeline FINISH-STEPS and full18-final/BOUND_DISPATCH/ACCEPTED receipts before anyresume; no dispatch bythisfallback','source_pipeline_exit':r['command_exit'],'upstream_must_land_first':True,'original2384':'DIF/notDONE','READY_merge':'rootonly/notperformed'};save('RESULT.json',result);files=[{'path':q.name,'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'mode':oct(q.stat().st_mode&0o777)}for q in sorted(out.iterdir())if q.is_file()];m=out/'MANIFEST.json';m.write_text(json.dumps({'files':files},indent=2)+'\n');print(json.dumps(result,indent=2),flush=True);print('MANIFEST',m,hashlib.sha256(m.read_bytes()).hexdigest(),flush=True)
