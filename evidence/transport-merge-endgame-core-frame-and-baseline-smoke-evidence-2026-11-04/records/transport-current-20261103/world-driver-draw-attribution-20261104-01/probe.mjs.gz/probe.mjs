import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {execSync} from 'node:child_process';
const APP='/workspace/chicago-driver-interaction-integration-20261104/chicago/4d';
const ROOT=path.resolve(APP,'../../site/4d'), OUT=process.argv[2], MODE=process.argv[3];
assert(OUT && ['light','shadow1904'].includes(MODE));
const smoke=fs.readFileSync(path.join(APP,'tools/smoke_renderer.mjs'),'utf8');
const report={mode:MODE,sourceSmokeSha256:crypto.createHash('sha256').update(smoke).digest('hex'),checks:[],errors:[],httpErrors:[]};
report.mode='ORIGINAL_C_INITIAL_LIGHT_EXACT_DRIVER_ATTRIBUTION';report.served={};
const save=()=>fs.writeFileSync(path.join(OUT,'PROBE.json'),JSON.stringify(report,null,2)+'\n');
const check=(name,pass,details)=>{report.checks.push({name,pass:!!pass,details});save();assert(pass,name+': '+details)};
const signatureDistance=new Function(smoke.slice(smoke.indexOf('function signatureDistance(a, b) {'),smoke.indexOf('\n/** Diagnostic bracket',smoke.indexOf('function signatureDistance(a, b) {')))+'; return signatureDistance;')();
const server=http.createServer((req,res)=>{const rel=decodeURIComponent(req.url.split('?')[0]);let file=path.join(ROOT,rel);if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');if(!file.startsWith(ROOT+'/')||!fs.existsSync(file)){res.writeHead(404);res.end(rel);return}if(['/walk/js/main.js','/walk/js/far-merge.js'].includes(rel)){const b=fs.readFileSync(file);report.served[rel]={sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length};save();}res.setHeader('content-type',({'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.wasm':'application/wasm','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg'})[path.extname(file)]||'application/octet-stream');fs.createReadStream(file).pipe(res)});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let ns;try{ns=await import('playwright')}catch{ns=await import(path.join((process.env.NODE_PATH||execSync('npm root -g',{encoding:'utf8'})).trim().split(path.delimiter)[0],'playwright/index.js'))}const{chromium}=ns.chromium?ns:ns.default;
let browser;
try{
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE,args:['--enable-unsafe-swiftshader']});
 const ctx=await browser.newContext({viewport:{width:390,height:780},hasTouch:true,isMobile:false,deviceScaleFactor:2});
 const page=await ctx.newPage();page.setDefaultTimeout(90000);
 page.on('pageerror',e=>{report.errors.push(String(e));save()});page.on('console',m=>{if(m.type()==='error'){report.errors.push(m.text());save()}});page.on('response',r=>{if(r.status()>=400){report.httpErrors.push({status:r.status(),url:r.url()});save()}});
 const url=`http://127.0.0.1:${server.address().port}/walk/?keep-geometry=1`;
 await page.goto(url,{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>window.__chicago4d?.ready===true||!!window.__chicago4d?.error,null,{timeout:240000,polling:1000});
 check('1835 reaches ready',await page.evaluate(()=>window.__chicago4d?.ready===true));
 const contracts=await import('file://'+path.join(APP,'tools/world_smoke_contracts.mjs'));
 const bstart=smoke.indexOf('    const batchCensus = await page.evaluate(() => {');
 const bend=smoke.indexOf('    await page.evaluate(() => window.__chicago4d.setAnimationHold(true));',bstart);
 const batchCode=smoke.slice(bstart,bend);
 report.batchSourceSha256=crypto.createHash('sha256').update(batchCode).digest('hex');
 const constants={STRUCTURE_BATCHES:contracts.STRUCTURE_BATCH_KEYS.length,TEXTURED_STRUCTURE_BATCHES:Number(smoke.match(/const TEXTURED_STRUCTURE_BATCHES = ([0-9]+)/)[1]),ROUGHNESS_VALUES_MIN:Number(smoke.match(/const ROUGHNESS_VALUES_MIN = ([0-9]+)/)[1]),structureBatchContract:contracts.structureBatchContract};
 report.batchCensus=await new Function('page','check','label',...Object.keys(constants), 'return(async()=>{'+batchCode+';return batchCensus;})()')(page,check,'mobile 390x780',...Object.values(constants));save();
 const bootStart=smoke.indexOf('    const bootPose = await page.evaluate(() => {');
 const bootEnd=smoke.indexOf('    // Stand where the thresholds were measured.',bootStart);
 const bootCode=smoke.slice(bootStart,bootEnd);
 report.bootPoseSourceSha256=crypto.createHash('sha256').update(bootCode).digest('hex');
 report.bootPose=await new Function('page','return(async()=>{'+bootCode+';return bootPose;})()')(page);save();
 const estart=smoke.indexOf('  const enterTown = () => page.evaluate(async () => {');
 const eend=smoke.indexOf('  // A click on the HUD chrome',estart);
 const enterCode=smoke.slice(estart,eend);
 report.enterTownSourceSha256=crypto.createHash('sha256').update(enterCode).digest('hex');save();
 await new Function('page','return(async()=>{'+enterCode+';return enterTown();})()')(page);
 report.enteredTown=true;save();
 const standText=smoke.match(/  \{\n    id: 'prairie_west'[^]*?\n  \},/)[0].trim().replace(/,$/,'');
 const stand=new Function('return ('+standText+');')();report.stand=stand;
 report.attribution=await page.evaluate(async(st)=>{
  const a=window.__chicago4d;
  if(a.detail!=='light')throw new Error('attribution requires supported initial/default Light; no Full/Light replant');
  a.setFly(false);a.walker.teleport(st.pose);
  await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));a.step();
  const before=a.stats(),renderer=a.renderer,meter=renderer.__driverDraws,original=renderer.renderBufferDirect,rows=[];
  if(!meter)throw new Error('actual driver meter unavailable');
  const summary=(object,geometry,material)=>{
   let top=object;while(top?.parent&&top.parent!==a.scene3d)top=top.parent;
   return {object:object.name||object.type,uuid:object.uuid,layer:top?.parent===a.scene3d?(top.name||top.type):'OUTSIDE_MAIN_SCENE',
    material:material.name||material.type,materialType:material.type,materialUUID:material.uuid,
    transparent:material.transparent,side:material.side,forceSinglePass:material.forceSinglePass,
    opacity:material.opacity,materialUserDataKeys:Object.keys(material.userData??{}),
    night:material.userData?.nightWindows??null,roof:material.userData?.chiRoofRelief??null,wall:material.userData?.chiWallRelief??null,
    batched:!!object.isBatchedMesh,instanced:!!object.isInstancedMesh,
    multiDrawCount:object._multiDrawCount??null,instances:object._instanceInfo?.length??object.count??null,
    geometries:object._geometryInfo?.length??null,perObjectFrustumCulled:object.perObjectFrustumCulled??null,
    sortObjects:object.sortObjects??null,customSort:typeof object.customSort==='function',frustumCulled:object.frustumCulled,
    coalesced:object.userData?.coalesced??false,castShadow:object.castShadow,receiveShadow:object.receiveShadow,
    vertices:geometry.attributes.position?.count??null,indexCount:geometry.index?.count??null,
    geometryUUID:geometry.uuid,drawRange:{...geometry.drawRange}};
  };
  a.setAnimationHold(true);
  renderer.renderBufferDirect=function(...args){
   const start=meter.draws,nativeStart=renderer.info.render.calls,trisStart=renderer.info.render.triangles;
   try{return original.apply(this,args)}finally{
    const[camera,scene,geometry,material,object]=args;
    rows.push({...summary(object,geometry,material),pass:scene===null?'SHADOW_OR_OFFSCREEN':'COLOUR',cameraType:camera.type,
     draws:meter.draws-start,rendererCalls:renderer.info.render.calls-nativeStart,triangles:renderer.info.render.triangles-trisStart});
   }
  };
  let after;
  try{a.step();after=a.stats();}finally{renderer.renderBufferDirect=original;a.setAnimationHold(false);}
  const total=rows.reduce((n,x)=>n+x.draws,0),nativeTotal=rows.reduce((n,x)=>n+x.rendererCalls,0),tris=rows.reduce((n,x)=>n+x.triangles,0);
  const layers={};for(const r of rows){const k=r.layer+' / '+r.pass;if(!layers[k])layers[k]={draws:0,rendererCalls:0,triangles:0,objects:0};layers[k].draws+=r.draws;layers[k].rendererCalls+=r.rendererCalls;layers[k].triangles+=r.triangles;layers[k].objects++;}
  return {scope:'ONE_HELD_FORCED_INITIAL_LIGHT_FRAME_NOT_RATIO_OR_MEMORY_PROOF',before,after,total,nativeTotal,triangles:tris,
   meterNative:meter.native,unattributed:after.drawCalls-total,wrapperRestored:renderer.renderBufferDirect===original,
   layers,rows};
 },stand);save();
 check('actual driver delta attribution reconciles complete frame',report.attribution.total===report.attribution.after.drawCalls&&report.attribution.nativeTotal===report.attribution.after.rendererCalls&&report.attribution.triangles===report.attribution.after.triangles,JSON.stringify({sum:report.attribution.total,frame:report.attribution.after.drawCalls,rendererSum:report.attribution.nativeTotal,rendererFrame:report.attribution.after.rendererCalls,trisSum:report.attribution.triangles,trisFrame:report.attribution.after.triangles}));
 check('renderBufferDirect observer restores original function',report.attribution.wrapperRestored);
 check('all draw deltas are exact nonnegative integers',report.attribution.rows.every(x=>Number.isInteger(x.draws)&&x.draws>=0));
 report.status='DRIVER_ATTRIBUTION_COMPLETE';report.noMissingRequests=report.httpErrors.length===0;save();
}catch(e){report.status='NONPASS';report.failure=String(e.stack||e);save();console.error(report.failure);process.exitCode=1}
finally{await browser?.close();await new Promise(r=>server.close(r));save()}
