from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,subprocess,sys,datetime
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
P=Path('/workspace/.cloud-setup/transport-joseph-walking-increment-v2-20261104')
C=Path('/workspace/chicago-driver-interaction-integration-20261104');A=C/'chicago/4d'
EXPECTED={C:('8057b7d6b125a80aad907b4e52f7aa8838b1ff8a','5ed4ece968a7d876974a3f5fef0bb99533a28e79'),Path('/workspace/chicago-driver-pace-rendezvous-20261104'):('b83f60edd8486afb3813b6d1ba5a8276425ac22b','8058a804fc431e5063df063b7cd637bff9bfcee9'),Path('/workspace/chicago-transport-current-20261103'):('27d52718290a2708f70ca536c6b796a83a936601','f2d0bc74730766d3309a8b23900e39c112e1fffe')}
SUP=Path('/workspace/.cloud-setup/transport-supervise.py');GUARD=Path('/workspace/.cloud-setup/transport-current-20261103/resource_guard.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(D/name).write_text(json.dumps(value,indent=2)+'\n')
def git(r,*args):return subprocess.check_output(['git','-C',str(r),*args],env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'),timeout=30)
def source(r):return dict(HEAD=git(r,'rev-parse','HEAD').decode().strip(),TREE=git(r,'rev-parse','HEAD^{tree}').decode().strip(),index_sha256=hashlib.sha256(git(r,'ls-files','--stage','-z')).hexdigest(),status=git(r,'status','--porcelain=v1','--untracked-files=all').decode(),diff_sha256=hashlib.sha256(git(r,'diff','HEAD','--binary')).hexdigest())
assert not (D/'OWNER.json').exists() and not (D/'CLOSED.json').exists(),'one attempt only; use new output after Root review'
assert sha(SUP)=='a312967552479c5a85f4de3ffb398ee2dd6007190e6fff9666689792c6b2452c'
assert sha(GUARD)=='ac68e89608a6828d71d0933a4e3403ca09585a8f362551e28582e33ea4a73a3c'
assert sha(P/'MANIFEST.json')=='572370f5d470452a335783ccfa2ef6e1d0590cbdccdee89f470ed3592bc25b54'
assert sha(P/'JOSEPH-WALKING-INCREMENT.patch')=='820dcb7da33e68fb7b761261d42ed3a1e59550074865c2c6b6de6a62860f4189'
lock=open('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
spec=importlib.util.spec_from_file_location('guard',GUARD);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
original={str(r):source(r) for r in EXPECTED}
for r,(head,tree) in EXPECTED.items():assert original[str(r)]['HEAD']==head and original[str(r)]['TREE']==tree and original[str(r)]['status']=='',original[str(r)]
manifest=json.loads((P/'MANIFEST.json').read_text());driver_pins={str(D/n):sha(D/n) for n in ['run.py','full.py','INPUTS.json']}
def pins():return sha(P/'MANIFEST.json')=='572370f5d470452a335783ccfa2ef6e1d0590cbdccdee89f470ed3592bc25b54' and all(sha(P/rel)==rec['sha256'] for rel,rec in manifest['source_inputs_and_candidates'].items()) and all(sha(Path(path))==h for path,h in driver_pins.items()) and {str(r):source(r) for r in EXPECTED}==original
assert pins()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',C4D_TEST_APP=str(A))
save('OWNER.json',dict(owner='joseph_walking_increment',pid=os.getpid(),affinity=list(os.sched_getaffinity(0)),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),originals=original,manifest_sha256=sha(P/'MANIFEST.json'),driver_pins=driver_pins))
ledger=[];status='RUNNING'
try:
 phases=[('candidate-native-full',[sys.executable,str(D/'full.py')],{},'PASS'),('oldC-cold-negative',['node',str(P/'route-clock-regressions.mjs')],{'C4D_HUMAN_SOURCE':str(A/'renderers/web/js/humans.js')},'EXPECTED_COLD_ASSERTION'),('candidate-real-class',['node',str(P/'route-clock-regressions.mjs')],{'C4D_HUMAN_SOURCE':str(P/'candidate/chicago/4d/renderers/web/js/humans.js')},'PASS')]
 for label,command,extra,expect in phases:
  assert pins(),'source pin changed'
  before=g.snapshot();save(label+'-RESOURCE-BEFORE.json',before);assert g.check(before)['accepted']
  save('STATE.json',dict(status='RUNNING',active=label,expected=expect,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
  with (D/(label+'.stdout')).open('xb') as stdout:
   q=subprocess.run([sys.executable,str(SUP),'--prefix',str(D/label),'--cwd',str(P/'candidate/chicago/4d'),'--timeout','120','--',*command],env=dict(env,**extra),stdout=stdout,stderr=subprocess.STDOUT)
  result=json.loads((D/(label+'.result.json')).read_text());cleanup=json.loads((D/(label+'.cleanup.json')).read_text());after=g.snapshot();save(label+'-RESOURCE-AFTER.json',after);resources=g.pair(before,after)
  log=(D/(label+'.log')).read_text();passed=(q.returncode==0 and result['returncode']==0)
  if expect=='EXPECTED_COLD_ASSERTION':passed=q.returncode==1 and result['returncode']==1 and 'AssertionError' in log and 'cold actor never travels at invented fallback speed' in log and not any(x in log for x in ['ReferenceError:','SyntaxError:','TypeError:'])
  row=dict(label=label,expected=expect,result=result,cleanup=cleanup,resources=resources,source_unchanged=pins(),expectation_met=passed,log_sha256=sha(D/(label+'.log')));ledger.append(row);save('LEDGER.json',ledger)
  assert not result['timed_out'] and result['requested_timeout_seconds']==120 and result['effective_timeout_seconds']==120 and result['timeout_override_reason'] is None and cleanup['cleanup_complete'] and not cleanup['remaining_owned_children'] and resources['accepted'] and pins()
  if not passed:status=label.upper().replace('-','_')+'_NONPASS';break
 else:status='JOSEPH_V2_NATIVE_UNITS_COMPLETE'
except BaseException as e:
 status='RUNNER_NONPASS';save('ERROR.json',dict(error=repr(e)))
finally:
 save('CLOSED.json',dict(status=status,ledger=ledger,all_original_source_pins_unchanged={str(r):source(r) for r in EXPECTED}==original,parcel_unchanged=pins(),asset_geometry_browser_world_or_photo_proof=False,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 print(json.dumps(dict(status=status,receipt=str(D/'CLOSED.json'))),flush=True)
 fcntl.flock(lock,fcntl.LOCK_UN)
sys.exit(0 if status=='JOSEPH_V2_NATIVE_UNITS_COMPLETE' else 1)
