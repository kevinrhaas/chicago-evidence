from pathlib import Path
import subprocess
P=Path('/workspace/.cloud-setup/transport-joseph-walking-increment-v2-20261104/candidate/chicago/4d')
for command in [['node','--check',str(P/'renderers/web/js/humans.js')],['node','--check',str(P/'tools/test_human_frame_time.mjs')],['node',str(P/'tools/test_human_frame_time.mjs')]]:
 print('COMMAND',command,flush=True)
 subprocess.run(command,cwd=P,check=True)
