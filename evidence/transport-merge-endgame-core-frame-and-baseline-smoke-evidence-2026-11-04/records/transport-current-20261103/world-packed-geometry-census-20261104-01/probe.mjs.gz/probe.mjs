import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {execSync} from 'node:child_process';
const APP='/workspace/chicago-driver-interaction-integration-20261104/chicago/4d';
const ROOT=path.resolve(APP,'../../site/4d'), OUT=process.argv[2], MODE=process.argv[3];
assert(OUT && ['light','shadow1904'].includes(MODE));
const smoke=fs.readFileSync(path.join(APP,'tools/smoke_renderer.mjs'),'utf8');
const report={mode:MODE,sourceSmokeSha256:crypto.createHash('sha256').update(smoke).digest('hex'),checks:[],errors:[],httpErrors:[]};
report.mode='READONLY_ACTUAL_PACKED_GEOMETRY_CENSUS';report.served={};
const save=()=>fs.writeFileSync(path.join(OUT,'PROBE.json'),JSON.stringify(report,null,2)+'\n');
const check=(name,pass,details)=>{report.checks.push({name,pass:!!pass,details});save();assert(pass,name+': '+details)};
const signatureDistance=new Function(smoke.slice(smoke.indexOf('function signatureDistance(a, b) {'),smoke.indexOf('\n/** Diagnostic bracket',smoke.indexOf('function signatureDistance(a, b) {')))+'; return signatureDistance;')();
const server=http.createServer((req,res)=>{const rel=decodeURIComponent(req.url.split('?')[0]);let file=path.join(ROOT,rel);if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');if(!file.startsWith(ROOT+'/')||!fs.existsSync(file)){res.writeHead(404);res.end(rel);return}if(['/walk/js/main.js','/walk/js/batch-coalesce.js','/walk/js/batch-instance.js'].includes(rel)){const b=fs.readFileSync(file);report.served[rel]={sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length};save();}res.setHeader('content-type',({'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.wasm':'application/wasm','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg'})[path.extname(file)]||'application/octet-stream');fs.createReadStream(file).pipe(res)});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let ns;try{ns=await import('playwright')}catch{ns=await import(path.join((process.env.NODE_PATH||execSync('npm root -g',{encoding:'utf8'})).trim().split(path.delimiter)[0],'playwright/index.js'))}const{chromium}=ns.chromium?ns:ns.default;
let browser;
try{
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE,args:['--enable-unsafe-swiftshader']});
 const ctx=await browser.newContext({viewport:{width:390,height:780},hasTouch:true,isMobile:false,deviceScaleFactor:2});
 const page=await ctx.newPage();page.setDefaultTimeout(90000);
 page.on('pageerror',e=>{report.errors.push(String(e));save()});page.on('console',m=>{if(m.type()==='error'){report.errors.push(m.text());save()}});page.on('response',r=>{if(r.status()>=400){report.httpErrors.push({status:r.status(),url:r.url()});save()}});
 const url=`http://127.0.0.1:${server.address().port}/walk/?keep-geometry=1`;
 await page.goto(url,{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>window.__chicago4d?.ready===true||!!window.__chicago4d?.error,null,{timeout:240000,polling:1000});
 check('1835 reaches ready',await page.evaluate(()=>window.__chicago4d?.ready===true));
 const contracts=await import('file://'+path.join(APP,'tools/world_smoke_contracts.mjs'));
 const bstart=smoke.indexOf('    const batchCensus = await page.evaluate(() => {');
 const bend=smoke.indexOf('    await page.evaluate(() => window.__chicago4d.setAnimationHold(true));',bstart);
 const batchCode=smoke.slice(bstart,bend);
 report.batchSourceSha256=crypto.createHash('sha256').update(batchCode).digest('hex');
 const constants={STRUCTURE_BATCHES:contracts.STRUCTURE_BATCH_KEYS.length,TEXTURED_STRUCTURE_BATCHES:Number(smoke.match(/const TEXTURED_STRUCTURE_BATCHES = ([0-9]+)/)[1]),ROUGHNESS_VALUES_MIN:Number(smoke.match(/const ROUGHNESS_VALUES_MIN = ([0-9]+)/)[1]),structureBatchContract:contracts.structureBatchContract};
 report.batchCensus=await new Function('page','check','label',...Object.keys(constants), 'return(async()=>{'+batchCode+';return batchCensus;})()')(page,check,'mobile 390x780',...Object.values(constants));save();
 const bootStart=smoke.indexOf('    const bootPose = await page.evaluate(() => {');
 const bootEnd=smoke.indexOf('    // Stand where the thresholds were measured.',bootStart);
 const bootCode=smoke.slice(bootStart,bootEnd);
 report.bootPoseSourceSha256=crypto.createHash('sha256').update(bootCode).digest('hex');
 report.bootPose=await new Function('page','return(async()=>{'+bootCode+';return bootPose;})()')(page);save();
 const estart=smoke.indexOf('  const enterTown = () => page.evaluate(async () => {');
 const eend=smoke.indexOf('  // A click on the HUD chrome',estart);
 const enterCode=smoke.slice(estart,eend);
 report.enterTownSourceSha256=crypto.createHash('sha256').update(enterCode).digest('hex');save();
 await new Function('page','return(async()=>{'+enterCode+';return enterTown();})()')(page);
 report.enteredTown=true;save();
 await page.exposeFunction('__worldMetaProgress',x=>{report.progress=x;save()});
 const standText=smoke.match(/  \{\n    id: 'prairie_west'[^]*?\n  \},/)[0].trim().replace(/,$/,'');const stand=new Function('return ('+standText+');')();report.stand=stand;
 report.census=await page.evaluate(async(st)=>{
  const a=window.__chicago4d;if(a.detail!=='light')throw new Error('requires initial/default Light; no replant');
  a.setFly(false);a.walker.teleport(st.pose);await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));a.step();
  const {joinRuns}=await import('/walk/js/batch-coalesce.js');
  const rows=[];const baseline=a.stats();a.setAnimationHold(true);
  try{
   const batches=a.buildings.batches.filter(b=>!b.material.transparent&&!b.material.transmission
    &&!b.material.userData?.nightWindows&&!b.material.userData?.chiRoofRelief&&!b.material.userData?.chiWallRelief
    &&!['map','normalMap','aoMap','roughnessMap','alphaMap','displacementMap'].some(k=>b.material[k]));
   for(const batch of batches){
    const g=batch.geometry,n=batch._multiDrawCount,drawIDs=batch._indirectTexture.image.data.slice(0,n);
    const originalStarts=batch._multiDrawStarts.slice(0,n),originalCounts=batch._multiDrawCounts.slice(0,n);
    const fake={_multiDrawCount:n,_multiDrawStarts:batch._multiDrawStarts.slice(),_multiDrawCounts:batch._multiDrawCounts.slice(),
     _indirectTexture:{image:{data:batch._indirectTexture.image.data.slice()},needsUpdate:false},
     _instanceInfo:batch._instanceInfo,_matricesTexture:batch._matricesTexture,_colorsTexture:batch._colorsTexture,
     userData:{batchIndex:batch.userData.batchIndex}};
    const joined=joinRuns(fake,g,batch.material);
    const sameOriginal=batch._multiDrawCount===n&&drawIDs.every((x,i)=>batch._indirectTexture.image.data[i]===x)
     &&originalStarts.every((x,i)=>batch._multiDrawStarts[i]===x)&&originalCounts.every((x,i)=>batch._multiDrawCounts[i]===x);
    if(!sameOriginal)throw new Error('original draw list mutated by copied-list coalescer');
    const attrs=Object.keys(g.attributes).sort(),index=g.index;
    const version=attrs.map(k=>[k,g.attributes[k],g.attributes[k].array,g.attributes[k].version]);
    const indexSaved=index&&[index,index.array,index.version];
    const keptCounts=new Map();for(const id of drawIDs){const gid=batch._instanceInfo[id].geometryIndex;keptCounts.set(gid,(keptCounts.get(gid)||0)+1);}
    const payload=(gid)=>{
     const range=batch.getGeometryRangeAt(gid,{});
     if(!range||![range.vertexStart,range.vertexCount,range.start,range.count].every(Number.isInteger)||range.vertexStart<0||range.vertexCount<1)throw new Error('unsupported actual geometry range');
     if(Object.keys(g.morphAttributes??{}).length||g.groups.length)throw new Error('unsupported morph/draw-group layout');
     if(g.drawRange.start!==0||g.drawRange.count<range.start+range.count)throw new Error('partial backing draw range');
     const layouts=[],views=[];
     for(const name of attrs){const z=g.attributes[name];if(!z.array||z.isInterleavedBufferAttribute||z.isInstancedBufferAttribute||!ArrayBuffer.isView(z.array)||z.array instanceof DataView)throw new Error('unsupported attribute '+name);
      const types=['Float32Array','Int8Array','Uint8Array','Uint8ClampedArray','Int16Array','Uint16Array','Int32Array','Uint32Array'];if(!types.includes(z.array.constructor.name))throw new Error('unsupported attribute type');
      const count=range.vertexCount*z.itemSize,start=range.vertexStart*z.itemSize;if(start+count>z.array.length)throw new Error('attribute range outside backing');
      const view=new Uint8Array(z.array.buffer,z.array.byteOffset+start*z.array.BYTES_PER_ELEMENT,count*z.array.BYTES_PER_ELEMENT);
      layouts.push({name,type:z.array.constructor.name,itemSize:z.itemSize,normalized:z.normalized,gpuType:z.gpuType,bytes:view.byteLength});views.push(view);
     }
     let localIndex=null;if(index){if(!index.array||index.itemSize!==1||index.normalized||![range.indexStart,range.indexCount].every(Number.isInteger)||range.indexStart!==range.start||range.indexCount!==range.count)throw new Error('unsupported index layout/range');
      localIndex=new Uint32Array(range.indexCount);for(let i=0;i<localIndex.length;i++){const v=index.array[range.indexStart+i]-range.vertexStart;if(!Number.isInteger(v)||v<0||v>=range.vertexCount)throw new Error('index crosses actual vertex range');localIndex[i]=v;}
     }else if(range.start!==range.vertexStart||range.count!==range.vertexCount)throw new Error('unsupported nonindexed range');
     const metadata={material:batch.material.uuid,vertexCount:range.vertexCount,count:range.count,indexed:!!index,indexCount:localIndex?.length??0,
      indexType:index?.array?.constructor.name??null,layouts,drawGroups:g.groups,positionBoxes:g.userData.positionBoxes??null,positionQuantized:g.userData.positionQuantized??null,confidenceLane:g.userData.confidenceLane??null,confidence:g.userData.confidence??null};
     const header=new TextEncoder().encode(JSON.stringify(metadata));let bytes=header.byteLength;for(const v of views)bytes+=v.byteLength;if(localIndex)bytes+=localIndex.byteLength;
     const out=new Uint8Array(bytes);out.set(header);let at=header.byteLength;for(const v of views){out.set(v,at);at+=v.byteLength;}if(localIndex)out.set(new Uint8Array(localIndex.buffer),at);
     return {bytes:out,range};
    };
    const groups=new Map(),unsupported=[];let hashed=0,totalBytes=0;
    for(let gid=0;gid<batch._geometryInfo.length;gid++){
     if(!batch._geometryInfo[gid]?.active)continue;
     let packed;try{packed=payload(gid);}catch(e){unsupported.push({gid,reason:String(e)});continue;}
     totalBytes+=packed.bytes.byteLength;
     const digest=await crypto.subtle.digest('SHA-256',packed.bytes),hash=[...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');
     let group=groups.get(hash);if(group){const other=payload(group.first).bytes;if(other.byteLength!==packed.bytes.byteLength||!packed.bytes.every((x,i)=>other[i]===x))throw new Error('hash collision/non-equivalent packed data');}
     else{group={hash,first:gid,geometryIds:[],keptInstances:0,keptGeometryIds:[]};groups.set(hash,group);}
     group.geometryIds.push(gid);const kept=keptCounts.get(gid)||0;group.keptInstances+=kept;if(kept)group.keptGeometryIds.push(gid);hashed++;
     if(hashed%250===0)await window.__worldMetaProgress({phase:'hashing',hashed,of:batch._geometryInfo.length,totalBytes});
    }
    const classes=[...groups.values()],keptClasses=classes.filter(x=>x.keptInstances>0),keptHashed=keptClasses.reduce((z,x)=>z+x.keptInstances,0);
    const unchanged=version.every(([k,z,array,v])=>g.attributes[k]===z&&z.array===array&&z.version===v)&&(!indexSaved||g.index===indexSaved[0]&&indexSaved[0].array===indexSaved[1]&&indexSaved[0].version===indexSaved[2]);
    if(!unchanged)throw new Error('packed source inputs changed during sequential census');
    rows.push({object:batch.name,material:batch.material.uuid,drawnEntries:n,geometries:batch._geometryInfo.length,instances:batch._instanceInfo.length,
     existingCoalescer:{removed:joined,remaining:fake._multiDrawCount,originalListUnchanged:sameOriginal},
     exactGeometry:{hashed,totalBytes,unsupported,classes:classes.length,duplicateClasses:classes.filter(x=>x.geometryIds.length>1),keptHashed,
      keptClasses:keptClasses.length,potentialExistingRegroupDrawsSaved:keptHashed-keptClasses.length,sourceInputsUnchanged:unchanged}});
   }
  }finally{a.setAnimationHold(false);}
  return {scope:'ACTUAL_KEPT_IDS_EXACT_PACKED_BYTE_EQUALITY_NOT_RENDERED_SAVING_OR_RATIO_PROOF',baseline,rows};
 },stand);save();
 check('dominant opaque batch actually included in exact census',report.census.rows.some(x=>x.drawnEntries>=1000));
 check('copied-list coalescer leaves all real draw lists unchanged',report.census.rows.every(x=>x.existingCoalescer.originalListUnchanged));
 check('all hashed source bindings/versions unchanged',report.census.rows.every(x=>x.exactGeometry.sourceInputsUnchanged));
 report.status='PACKED_GEOMETRY_CENSUS_COMPLETE';save();
}catch(e){report.status='NONPASS';report.failure=String(e.stack||e);save();console.error(report.failure);process.exitCode=1}
finally{await browser?.close();await new Promise(r=>server.close(r));save()}
