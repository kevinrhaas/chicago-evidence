Prepared only; no new reference or POST is authorized.

Use the existing G feature branch if its actual public TREE equals the actual prospective merge S/TREE. Otherwise Root may authorize one ordinary `measurement/pr1700-merge-<S12>-20261104` branch pointing directly to existing S. Both original workflows lack `source_ref`; the dispatch `ref` is what checkout reads.

Eight exact smoke payloads are in CONCRETE-INERT-REQUESTS.json: viewport mobile/desktop × stage1-4,5-8,9-12,13-15. Original150-minute jobs and every assertion limit stay unchanged; every stage appears exactly once per viewport. One original frame request on the same source covers all9 original25-minute jobs, including the unchanged1904mobile400MiB bar.

Wait for the new public G head after all4 native parts and publication. Verify open/unmerged head, heldG8220, prospectiveS/parents/TREE, actual workflow hashes and Root’s exact dispatch GO. Fresh exact-source run lists and a single-intent ledger prevent duplicates; any automatic qualifying frame run is used without an extra POST. Reconcile each POST before issuing the next; never retry an uncertain mutation automatically. Actual checkout/TREE/log/footer/artifact proof is required; DIRTY/noS or any failed/censored/missing result remains unqualified. Old79e, N8057 and private44faf evidence are not relabelled as fresh target proof.
