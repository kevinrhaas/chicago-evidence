# V15 and V17 matched catalogue views — prepared, unrun

This is a separate, once-only V15 baseline versus V17 recessed opaque rear-quarter comparison. The V15 fixture, camera hypothesis, projection, crop, floor, lights and disposal checks are unchanged. V17 uses its already packaged indexed-near asset; V16 material changes are absent. Only candidate labels and the actual model hash, byte count and triangle count were repinned. No geometry generation or packaging occurs here.

The eight expected normal browser images are desktop and mobile, detail and full-quarter, for each model. Original1893 plate0095 is the image reference. Its camera remains a weighted perspective hypothesis, not calibrated photographic acceptance. V17's opaque quarter is an unmeasured reconstruction; this does not assert glass, a curtain or a documented construction.

Do not launch until root releases the shared graphics lane after the active full preflight. The caller requires an explicit root release bound to the two manifests. It preserves first-attempt output and refuses a blind replay. No app, Git or ticket changes were made.
