# Bardwell seated clothing correction, version 2

This is a separately versioned, source-only proposal. It clears the actual W01 bench in CPU counterfactuals of all four current canonical Bardwell LODs. **It is not a corrected canonical export, rendered pose, accepted driving assignment, bench contact or load-transfer result. The live driver remains disabled.**

The failed 14.08 mm proposal and its LOD2/3 intersection witnesses remain unchanged. Their all-LOD capsule is `c904faa890cfb1bf19cb3c7a150fa8281676d2f38836f258e7faceacd3297d3f`; the earlier near-only capsule is `a5912aa71313722d8c892914a65baeb666cdc67262727bf39ed51a226877c675`.

## Target and posture bounds

Before solving, `PREDECLARED-TARGET-AND-BOUNDS.json` fixed a **+0.100 mm minimum clothing clearance**, a maximum internal pelvis/trunk rise of **25 mm**, and no more than **5 degrees of added world rotation** for each thigh or calf. Complete original foot and ball frames, every shoe vertex, rest data and limb lengths must remain unchanged. These are conservative authored posture bounds, not anatomical certification. No benchmark or application threshold changes.

The selected rise is **22.096 mm**. The source's internal root datum moves with its pelvis and trunk, preserving the existing strict root-to-pelvis chain guard. The outer asset wrapper remains identity. Both legs use rigid two-bone IK to hold their complete original foot and ball frames. This is not a rigid lift of the whole person.

## Actual all-LOD result

Each canonical raw asset was loaded independently from primary `assets/humans`, with its own rest transforms, inverse binds, positions, indices and weights. The actual `sit_drive` clip was sampled at 0.5 seconds. The proposed source-frame delta was applied to those actual posed frames, and pinned Three CPU skinning evaluated every trouser triangle and every shoe vertex. Texture decoding, rendering and model generation were not used.

The unchanged W01 master is `274e737b…`. Its actual 12-triangle, eight-corner bench and footboard were decoded. Clipping uses exact drawn float32 boundaries and bench top Y = 1.5800000429153442 m. Positive clearance over the entire rectangular footprint excludes collision with the full bench slab, rather than only checking a pelvis socket or selected vertices.

| LOD | Canonical raw SHA prefix | Minimum trouser clearance | Bench-top crossings | Shoe vertices | Maximum shoe movement |
| --- | --- | ---: | ---: | ---: | ---: |
| 0 | `84cdeb6d` | +4.489537 mm | 0 | 450 | exactly 0 |
| 1 | `e2ff6d6d` | +4.489537 mm | 0 | 338 | exactly 0 |
| 2 | `bc7ab675` | +3.160517 mm | 0 | 226 | exactly 0 |
| 3 | `8d36cead` | **+0.100252 mm** | 0 | 170 | exactly 0 |

The numerical target boundary is bracketed to 1 micrometre of pelvis rise: **22.095 mm** gives LOD3 clearance **+0.099713 mm**, which fails the declared +0.100 mm target; **22.096 mm** gives **+0.100251574 mm**, which passes. This brackets the tested boundary, not a global optimum over arbitrary postures. The positive target margin is not assumed to survive a new float32 export; the actual exported clip must be checked again.

All four complete foot and ball matrices are unchanged. Every shoe vertex stays in its original position, and each per-LOD fixed sole set stays approximately 0.208–0.321 micrometres above the actual footboard. Body vertices blended partly to the moving calf are measured separately in the reports; they are not mislabeled as rigid shoes or wholly fixed foot surfaces.

## Posture and hands

Added thigh world rotation is **3.228435 degrees** per side; added calf world rotation is **0.544559 degrees**. Knee flexion, with zero meaning straight, changes from **64.117942 to 60.375966 degrees**. Thigh/calf lengths remain **0.4207842929685104 m** and **0.4395494596340219 m**, unchanged to roundoff. Source parent-chain error is at most 4.44e-16 m and rotation orthonormality error at most 3.33e-16.

The actual counterfactual wrist heads move from `[±0.199999751, 1.919999763, 1.040000277]` m to `[±0.199999751, 1.942095763, 1.040000277]` m. Thus wrists and upper-body palm proxies rise **22.096 mm**. There is no claim that old rein endpoints remain valid, or that wrists define a palm grip. Finger closure, bit identification and reins remain unresolved.

The near LODs now have a **minimum 4.49 mm clothing support gap** above the bench. The coarse LOD controls the required lift. This source correction solves geometric nonintersection; it does not establish pelvic support, pressure, force transfer, continuous collision or a convincing seated appearance. A rendered/exported pose could still need an explicit contact-preserving LOD or tailoring amendment.

## Meaningful controls and source scope

- The old 14.08 mm pose remains a failed all-LOD control, with its actual positive-barycentric LOD2/3 crossing witnesses preserved.
- The 22.095 mm under-target pose fails the stated clearance target at LOD3; it is not described as a penetration failure.
- A naive whole-rig lift of 22.096 mm clears clothing but moves shoes by 22.096 mm. All four LODs reject it.
- Independent 3 mm left-foot and left-ball frame drifts move shoe vertices by 3 mm. All four LODs reject both controls.
- All ten existing unmodified seated source and refusal tests pass against the version 2 proposal, including non-rigid matrix, stretched child chain, wrong identity/date/body and empty-wagon refusals. External exact-preimage `git apply --check` also passes; no patch was applied to the app.

The patch changes only Bardwell's existing opt-in seated source pose and his binding row, with truthful shared status text. The existing identity is `rc_bardwell_otis`, a reconstructed 1835 teamster. Dufresne and Flynn rows remain exactly unchanged. No default pose, standing idle, recipe, rest bone, skin weight, mesh, material, UV, wagon or bench is changed. The existing source loader requires no relaxation.

Review `BARDWELL-SEATED-CLOTHING-CORRECTION-V2.patch`, `SOURCE-CORRECTION-CONTROLS.json` and `proposed/`. Proposed pose SHA is `d002ddf1ee12723c83bd1ad0bd02843340974e775fc44a3fe5bca7d979664cb4`; binding SHA is `c7329afcc158f35c2c6402adba14af12bffeb2b550932a644d3a07efd49cdb39`. The unchanged app preimages are recorded exactly.

All native commands used one math thread, nice19 and a 15-second wall cap; the final all-LOD readback took 0.875 seconds and exited 0. Raw logs, solve samples and rejected controls are retained. Nothing in this packet authorizes live intake before a corrected canonical export and actual all-LOD contact/appearance review.
