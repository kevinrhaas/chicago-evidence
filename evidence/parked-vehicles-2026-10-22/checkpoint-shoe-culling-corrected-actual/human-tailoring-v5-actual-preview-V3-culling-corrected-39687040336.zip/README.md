# Actual V3 — culling corrected; fit/photo acceptance OPEN

The one released V3 run completed with24original PNGs, zero errors, all24actual-vertex framing guards and all24posed shoe-render assertions passing. Browser and server closed; server closure was2026-10-22T00:36:39.987883Z.

Independent read-only inspection of six remaining seated views confirms brown shoes now visibly render in before/after desktop-quarter and mobile-profile plus desktop-after-profile and mobile-after-front. The full figure is framed. Fuller trousers and a closed lower waistcoat remain visible; jagged hems and crude/incomplete garments and footwear remain. This is source-array appearance evidence, not complete fit or photographic acceptance.

The prior V2 bare-foot pictures and original receipts remain preserved as a historical preview culling defect. Its broad shoe-source FAIL interpretation was superseded by the finite CPU proof:10stale-idle-sphere negative camera controls and2mobile-quarter positive controls matched the historical pixels. V3 only matches production HumanActor by disabling original skinned-mesh frustum culling and logging/asserting actual draw participation. All original V2 geometry, source arrays, poses, camera values and bone frames are unchanged. No shoe geometry repair occurred.

immutable-actual-V3/ is self-contained for the exact data/caller/proof: all24actual PNG bytes, full receipts and framing/render/bone logs, actual baseline GLB, copied vendor, source-generated V5 arrays, caller, release/intent, original input/source manifests and the full finite CPU diagnosis capsule. Runtime dependency binaries are not installed or duplicated. Top-level frozen manifest hashes every member. Prepared-state documents inside are preserved historical inputs; actual execution status is stated here and in the actual runtime receipt.

V5 remains unapplied and canonically unqualified. Complete shoe/garment enclosure, period completion, normal/sole requalification, photographic/world/occupied acceptance and T1789 remain OPEN. Forty inherited negatives and deferred cuffs/full-shirt/seat/lapels/buttons/finishing remain OPEN.

No new browser/server, geometry, app, Git, ref, CI or source action was performed for this review and freeze.

## Independently inspected actual seated PNGs

- [1280-before-sit_drive-quarter.png](immutable-actual-V3/1280-before-sit_drive-quarter.png)
- [1280-after-sit_drive-quarter.png](immutable-actual-V3/1280-after-sit_drive-quarter.png)
- [390-before-sit_drive-profile.png](immutable-actual-V3/390-before-sit_drive-profile.png)
- [390-after-sit_drive-profile.png](immutable-actual-V3/390-after-sit_drive-profile.png)
- [1280-after-sit_drive-profile.png](immutable-actual-V3/1280-after-sit_drive-profile.png)
- [390-after-sit_drive-front.png](immutable-actual-V3/390-after-sit_drive-front.png)

Root has separately planned four views listed in INDEPENDENT-READONLY-PIXEL-REVIEW.json; this independent report does not claim those were inspected. Other PNGs are preserved with their technical receipts and are not visually accepted.
