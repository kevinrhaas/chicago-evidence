# Actual source comparison — four normal PNGs

2026-10-22. Actually viewed all four exact PNGs in `actual/`: desktop-indexed-v10-source-body.png, desktop-indexed-v10-source-detail.png, mobile-indexed-v10-source-body.png, mobile-indexed-v10-source-detail.png. They show the valid native 1893 catalog plate0095 through a CSS crop beside/above the actual frozen indexed V10 render. Untouched source/model/camera pins are in INPUTS/PREPARED and runtime receipt. No source photo or full-ticket acceptance.

Actual caller PASS: four normal screenshots, all model parts enabled including inferred parked pole, zero page/console/HTTP/request/GL errors, source/model exact hashes. Browser finished04:14:12.206Z, owner3.545seconds/EXIT0, browser and server closed. Desktop/mobile both dispose to zero geometries/textures/scene children with one actual DFG disposal, live-to-dead handle and idempotence preserved. This is runtime execution/cleanup success, not visual acceptance.

The whole visible carriage remains recognizably the catalog Brougham type, with differential front/rear wheels, rounded hanging lower body, upper window/quarter division and flowing roof. This does not establish precise silhouette likeness or photographic appearance. No corruption of the PNG files is visible. The body and detail frames are intentional source windows; full vehicle/pole framing and hidden ground/hitch/occupation clearance are not covered.

The leading visual blocker is conspicuous angular dark mottling/triangles across the near door and lower body, visible at desktop detail and mobile. The actual image alone does not distinguish self-shadow artifacts, coincident faces, normals or material issues. No mechanism is asserted without source/numeric evidence, and no shadow bias, light change, hidden-part mask or material suppression was used.

Visible source-detail priorities after the defect is understood:

1. Near-door bright fitting/latch beside the forward edge and smaller central decorative mark are missing. The source supports their visible presence and approximate image position; exact identity, operation and physical depth remain inferred. Do not label the mark as a crest without evidence.
2. Source fine continuous bright edging traces window, stiles and rounded lower door, while the render has weak/thin disconnected edging and hard planar seams. The lower rendered U is more pointed/angular than the source's softer rounded base. Compare actual silhouette, not all-vertex bounding boxes.
3. Source steps have small oval treads and curved/swept hangers; model shows broad rectangular boards and straight braces. Near visible contour can guide reconstruction; opposite-side depth and complete attachment geometry are not attested.
4. The source lamp has ornate paired/curved features; the model's straight faceted lantern is a coarse stand-in. Roof front lip, contour transition and window frame appearance still need source-guided attention; V9-to-V10 roof improvement alone did not prove this plate likeness.
5. Glass, painted wood, metal and upholstery remain very flat/simplified. The unoccupied front perch and braces differ strongly in silhouette, but source coachmen/robes cover critical parts: their clothes must not become model upholstery evidence. Fine wheels/underbody connections remain simplified.

The source is a printed catalog illustration, not a photograph. Paper foxing, grain, ink scratches and signature marks do not attest vehicle material wear. Cabin-quarter material remains ambiguous; a dark opaque reconstruction is an explicit choice rather than proof of glass/curtain/leather. Opposite side, interior, metric dimensions, exact1904specimen and Chicago ownership are unproved. Maker/type availability before1904 is supported; no Pullman, Glessner or Dearborn identity is asserted.

Root personally reviewed desktop body/detail and agreed town near-release is blocked pending an exact source-owned defect trace and minimal repair. No further browser run or generation is authorized by this review. Original prelaunch sandbox denial and intent are preserved separately; no browser was created during that failed transport startup.
