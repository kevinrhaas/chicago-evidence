const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const{chromium}=require('./node_modules/playwright');const ROOT=__dirname,OUT=path.join(ROOT,'actual'),port=Number(process.argv[2]);
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');const need=(v,m)=>{if(!v)throw Error(m)};
need(fs.existsSync(path.join(ROOT,'RUN-INTENT.json')),'Released owner required');fs.mkdirSync(OUT);let browser=null;
const result={scope:'Four normal actual source-plate/indexed-V10 comparisons; fixed historical camera hypothesis, original lighting; no photographic acceptance',started:new Date().toISOString(),pass:false,rows:[],errors:[],disposal:[],browserClosed:false,expectedImages:4,inputs_manifest_sha256:hash(path.join(ROOT,'INPUTS.json'))};
const save=()=>fs.writeFileSync(path.join(OUT,'receipt.json'),JSON.stringify(result,null,2));const watchdog=setTimeout(()=>{result.error='165 second deadline';save();browser?.close().finally(()=>process.exit(124));},165000);
(async()=>{try{
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox'],timeout:15000});
 for(const[viewport,width,height]of[['desktop',1280,800],['mobile',390,780]]){
 const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:1});
 const note=(kind,message)=>{result.errors.push({viewport,kind,message});save()};page.on('pageerror',e=>note('page',e.message));page.on('console',m=>{if(m.type()==='error')note('console',m.text())});page.on('requestfailed',r=>note('request',r.url()+': '+r.failure()?.errorText));page.on('response',r=>{if(r.status()>=400)note('http',r.status()+' '+r.url())});
 await page.route('**/*',r=>{const u=new URL(r.request().url());return ['data:','blob:'].includes(u.protocol)||(u.protocol==='http:'&&u.hostname==='127.0.0.1'&&u.port===String(port))?r.continue():r.abort('blockedbyclient')});
 await page.goto(`http://127.0.0.1:${port}/transport/v10/`,{waitUntil:'load',timeout:15000});await page.waitForFunction(()=>window.broughamReady&&window.setSourceComparison&&document.querySelector('#reference img').complete,null,{timeout:15000});
 const modelHash=await page.evaluate(()=>comparisonInputHash()),sourceHash=await page.evaluate(()=>sourceInputHash());need(modelHash==='a90648c02b140a74183491e021ae37a433963a709f39cf2577bc26a515031d9b','Indexed model hash');need(sourceHash==='b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe','Actual valid plate hash');
 for(const view of['body','detail']){
 const row=await page.evaluate(view=>setSourceComparison(view),view);need(row.poleVisible&&row.sourceTriangles===30782,'Source model guard');need(row.glError===0&&result.errors.length===0,'Actual runtime errors');need(row.lighting.shadowsEnabled&&row.lighting.sun.normalBias===0&&row.lighting.sun.bias===-.0002&&row.lighting.exposure===1.3,'Original lighting');
 for(const d of[row.dom.canvas,row.dom.reference])need(d.width>100&&d.height>100&&d.left>=0&&d.top>=row.dom.header.bottom&&d.right<=width+1&&d.bottom<=height+1,'Normal framing guard');
 await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));const png=`${viewport}-indexed-v10-source-${view}.png`;await page.screenshot({path:path.join(OUT,png),timeout:10000});result.rows.push({viewport,view,png,normalBrowserScreenshot:true,image_sha256:hash(path.join(OUT,png)),loaded_model_sha256:modelHash,source_sha256:sourceHash,...row});save();
 }
 try{result.disposal.push({viewport,...await page.evaluate(()=>disposeComparison())})}catch(error){result.disposal.push({viewport,error:String(error),resourceCleanup:await page.evaluate(()=>window.broughamCleanupReceipt||null).catch(()=>null)});save();throw error}save();await page.close();
 }
 need(result.rows.length===4&&result.disposal.length===2&&result.errors.length===0,'Four-frame completeness');result.pass=true;
 }catch(e){result.error=String(e.stack||e);process.exitCode=1}finally{clearTimeout(watchdog);if(browser){await browser.close();result.browserClosed=true}result.finished=new Date().toISOString();save()}if(!result.pass)throw Error(result.error);console.log('PASS four fixed-source-camera normal comparison frames; browser closed.');})().catch(e=>{console.error(e);process.exitCode=1});
