# T-2800 broader anatomy authoring amendment

## Concrete outcome and present state

Replace the visibly schematic installed horse's anatomical surface, rather than fairing its rump in isolation. The new source is `quad_cage_authoring.py` plus `anatomy-authoring-controls.json`, generated only as a **source JSON** by `author_controls.py`. It defines one shared quad control cage with genuine apertures/branch loops for limbs, ears, eye/lid and nostril surfaces; Catmull-Clark subdivision rounds the connected muscle forms. It writes a **static unmounted development GLB** into a new outside-app directory only when explicitly invoked. There is no implicit reuse of the old horse's invalid stance, rig, socket fit or movement qualification.

**No build(), subdivision, new geometry export or browser preview has run.** `SOURCE-ONLY-REVIEW.json` reports ten AST/control checks only. The next independent reviewer should examine source topology and dimensions before authorizing an actual bounded build. The earlier croup-only fairing and original installed horse remain byte-unchanged. The old protected-range comparator is **not applicable** to this intentionally broader amendment.

## Evidence actually inspected

The baseline is the fresh installed89b048 four-view run, not an old head/neck candidate:

- `/workspace/shared/horse-installed-baseline-20261022-first/1280-side.png`
- `/workspace/shared/horse-installed-baseline-20261022-first/1280-three-quarter.png`
- `390-side.png` and `390-three-quarter.png` in the same folder.

All four were actually viewed. Root independently viewed both desktop frames and agrees they are schematic. The 5.10s capture terminal and exact served715,316B/14,172tri hash are archived separately; the browser lane was returned after it ended. No photo acceptance follows from capture success.

Cleared references were re-opened as pixels during this amendment:

| Resolved source | Actual anatomy use | Explicit limit |
| --- | --- | --- |
| `vassil_2014_konik_horse_anatomy` | Full side-body photograph: continuous shoulder, curved croup, neck breadth, hair roots and real limb proportions | Modern stocky Konik, not the selected historical breed/individual/coat |
| `joselodos_2025_horse_anatomy` | CC0 oblique broadside with head toward camera: substantial shoulder/forearm volume, head width, prominent lid/orbit, short tapered ears, curved muzzle/nostrils | Modern pose with one hind leg resting; do not copy that stance, blaze, socks or exact color |
| `ellenberger_baum_dittrich_equine_plates` | Tafel6 figs30/31/36/37: cheek/jaw, zygomatic/orbital relief, eye/lid and pinna/concha; Tafel12 figs8/9: hip/thigh/gaskin muscle transitions | Anatomical plates, not an exterior metric survey, edition-date ambiguity remains in source record |
| `seton_1892_equine_skeleton` | Distinguish scapula/humerus/radius/carpus/metacarpus and pelvis/femur/tibia/hock/metatarsus | Far-side scapula/ribs/jaws intentionally omitted; skeleton is not a neutral external contour or metric source |

`REFERENCE-PINS.json` records the exact viewed files/hashes. All metric authoring controls are declared reconstruction dimensions around a1.55m withers target. No new measurement, breed ancestry, Chicago presence, owner, marking or coat attestation is manufactured.

## Intended surface changes against the actual baseline

| Actual baseline defect | Concrete authored source change | What remains to prove |
| --- | --- | --- |
| Long rigid upright ear blades | Root1.97m to tip2.12m (150mm reconstruction), width taper, outward/backward tip, shallow front concha, connected pinna root | Actual pinna silhouette/concha, material boundary, shape after subdivision |
| Flat wedge head, bead eyes, pasted nostril | Continuous cheek/jaw/nasal/muzzle controls; shared orbital aperture with upper/lower lid annulus and a shallow convex wet eye; separate actual recessed nostril cup aperture | Head landmarks, eyelid/nostril depth, natural lip relief, close detail and clearance |
| Angular triangular neck/shoulder | Smooth continuous body→neck→poll/cheek cage; distinct shoulder, lower/middle neck stations; remove separate primitive cheek/neck volumes | Correct throatlatch/crest/withers shape in both views; no gummy or webbed surface |
| Upper legs look like disconnected flat-cut tubes | Remove trunk quads to form shared shoulder/hip boundaries and bridge into shaped upper-arm/thigh/forearm/gaskin rings | Closed two-manifold topology, shoulder/hip muscle planes, no saddle-like webs or intersections |
| Both fore and hind lower chains look severely bent at rest | Explicit elbow→forearm→carpus→metacarpus and hip/thigh→stifle→gaskin→hock→metatarsus control sequences; no synthetic2-link IK | Anatomical proportions and weight-bearing stance; exact support/sole check after subdivision |
| Round fetlock beads and primitive hooves | Integrated fetlock/pastern/coronet/wall/sole rings; sharp sole perimeter preserves an authored planar base | Hoof angles, heel/toe widths, all actual sole vertices/contacts after export; hooves plate review still required |
| Flat detached tail / effectively absent mane, flat coat | **Not concealed:** first source build isolates anatomy and leaves hair/UV/PBR explicitly unfinished; next appearance stage roots grooming to the corrected surface and adds coat/eye/muzzle detail | Real hair volume/grooming and surface quality before photographic acceptance |

The first build must be reviewed against these concrete hypotheses. It may fail; the source is not evidence that a connected cage automatically makes correct anatomy. Standard subdivision is a shaping tool, not a photo-quality certificate.

## Explicit amendment of old protections

Keep the original GLB89b048 and all old source/parameters pinned, the metre/+Y/+Z convention, ground root, source/license register and vehicle contract. Do **not** retain bad vertex positions or the15-joint fixture merely because earlier engineering tests pinned them.

This source intentionally replaces body, head, ears, eye/lid, nostril, neck, shoulder, hip, limb and hoof geometry and normals. The planned static development animal has **zero rig joints and zero clips**, and exports **no old saddle/seat/trace/breeching/shaft/bit sockets**. The current two-link chain's names do not correctly represent every biological joint; T-2803 must derive a genuine anatomical skeleton from the reviewed static master. The original animation remains preserved only in the original fixture.

Support positions also change explicitly: fore anatomical-left[.20,0,.48] versus old[.195,0,.455], hind[.20,0,-.56] versus old[.195,0,-.605], mirrored right. These modest stance adjustments are authoring hypotheses; they are not an instruction to move the animal upward to fake ground/hitch fit. Old mechanical coupling/gear tests do not transfer.

## Source topology implementation and risks to review first

`Cage.remove_patch` finds one perimeter of explicitly named source quads and retires them. `split_boundary` inserts shared edge midpoints into retained neighbor faces, avoiding hidden T-junctions. Branch profiles reuse the actual aperture loop and pick a cyclic frame against it. Shared source vertices join skin at shoulder/hip/ear/lid/nostril boundaries. Closed orientation walks the face adjacency and refuses missing/nonmanifold/nonorientable/disconnected surfaces. Subdivision preserves material/region ownership and explicit sole-edge creases. Export refuses degenerate triangles and writes no skeleton/socket claim.

These are **unexecuted safeguards**. In particular, source review must check the least-stretch branch frame, ring ordering, local folded surfaces, tangent transitions, eyebrow/nostril aperture positions and material boundaries. A manifold can still self-intersect or look wrong. Global subdivision may erase bony landmarks, thin the muzzle/ears or make a rubbery animal. Eye/lid source regions will need an independently moving eyeball and suitable topology in the eventual rig. The first static cornea patch is a diagnostic surface only.

## Next bounded work after independent source review and lane release

1. **One build:** execute the static source into a new outside-app directory, wall-limit60s, capture exact stdout/stderr and first failure. No automatic retries and no tracked overwrite. Record actual source/control hashes and actual source/output counts; do not promote the ten source checks to geometry proof.
2. **Decode and inspect:** actual glTF nodes/axes/metres, finite/unit normals, zero indices outside accessors, manifold/shared source region ownership and actual sole plane; source-free check after export. Khronos0errors/0warnings required before preview. No broad historical SAT/harness chain.
3. **One matched preview:** fixed whole side and quarter at the baseline cameras/light, front and a genuinely close head detail, desktop1280/mobile390. Display static/unaccepted status; no invented gait. Compare actual frames to actual cleared pixels, record mismatches. Reject or amend visibly bad proportions first.
4. **Appearance stage:** sculpt the verified surface further where the photos/plates expose errors. Add natural closed lips, periocular relief, muzzle softness and hoof wall/heel definition. Root mane/forelock/tail mass to the actual scalp/dock and use bounded browser hair clumps with authored strand-flow detail, not flat strips. Preserve source region authority and prove root ownership/clearance explicitly.
5. **UV/PBR:** make a reproducible atlas over the authored regions. Use original material/noise maps derived from cleared anatomy observations, not copied unknown photographs. First shared horse texture set target:1024² color+normal+packed roughness/occlusion, at most16MiB decoded with full mips total; measure actual memory, use shared textures across instances, reduce if phone budget requires. Do not call a plain brown material photographic. Color/grooming stay reconstruction.
6. **Master/LOD/rig handoff:** review deformation-friendly control topology and semantic landmarks; then T-2803 can author/bind the anatomical skeleton. Produce compressed near/mid/far derivatives (planning ceilings~40k/12k/3ktri, actual quality/budgets govern), tested browser memory/draws/frame costs. Tack, animation, people, vehicle routing and ride/boarding remain later gated tickets.

The first static anatomical build is a development step toward T-2800, not completion. All of T-2800's actual near/detail image comparisons, material/hair quality, topology, LOD and browser metrics must be satisfied before photo acceptance/closure. Do not publish this provisional bald/unrigged source model into the town simply because a decoder passes.

## Future invocation, intentionally NOT RUN

```sh
python /workspace/shared/horse-anatomical-master-authoring-next-20261022/quad_cage_authoring.py --execute-reviewed-source --output-dir /workspace/shared/horse-anatomical-static-first-20261022
```

The source refuses an existing output directory. The explicit flag is not a claim that review/lane release occurred. Root remains sole tracked app/ticket/Git writer. No heavy work is authorized by this document itself.
