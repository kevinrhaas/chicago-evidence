# SPDX-License-Identifier: CC0-1.0
"""Read/parse controls only. Does NOT import authoring module or create geometry."""
from pathlib import Path
import ast,hashlib,json,math
p=Path(__file__).resolve().parent
source=(p/'quad_cage_authoring.py').read_text();ast.parse(source)
c=json.loads((p/'anatomy-authoring-controls.json').read_text())
checks={}
checks['source_ast_parses_without_execution']=True
checks['withers_control_target_1_55']=abs(c['body_profile'][6][1]+c['body_profile'][6][4]-1.55)<1e-12
checks['ear_length_in_declared_reconstruction_bound']=c['ear_authoring']['ear_length_reconstruction_bound_m'][0]<=c['ear_authoring']['tip_y_m']-c['ear_authoring']['root_center_y_m']<=c['ear_authoring']['ear_length_reconstruction_bound_m'][1]
checks['source_control_soles_at_y0']=c['fore_l'][-1][1]==c['hind_l'][-1][1]==0
checks['distinct_fore_elbow_carpus_and_hind_stifle_hock_controls']=all(name in c['fore_l_landmarks'] for name in ['elbow','carpus']) and all(name in c['hind_l_landmarks'] for name in ['stifle','hock'])
checks['positive_control_radii']=all(row[3]>0 and row[4]>0 for key in ['body_profile','fore_l','hind_l'] for row in c[key])
N=c['body_sides'];holes={x['part']:x for x in c['body_root_holes']}
checks['right_branch_holes_reflect_left_body_columns']=all(set(holes[name+'_r']['circumferential_columns'])=={(N//2-k-1)%N for k in holes[name+'_l']['circumferential_columns']} for name in ['fore','hind'])
checks['old_15_joint_clips_and_sockets_explicitly_not_transferred']=any('NOT transferred' in text for text in c['amendments_to_bad_baseline']) and any('obsolete/unfitted' in text for text in c['amendments_to_bad_baseline'])
checks['entrypoint_guard_present']='--execute-reviewed-source' in source and "if not a.execute_reviewed_source:p.error" in source
root=Path('/workspace/chicago/chicago/4d/data/sources')
checks['all_declared_reference_source_ids_resolve']=all((root/(x+'.json')).is_file() for x in c['reference_ids'])
result={'status':'PASS source controls only' if all(checks.values()) else 'FAIL source controls','checks':checks,'scope':'AST and authored JSON controls only. build(), subdivision, GLB export and browser are NOT RUN. Source cage manifold/shape/scale/contacts and photographic acceptance remain UNPROVEN.','source_sha256':hashlib.sha256(source.encode()).hexdigest()}
(p/'SOURCE-ONLY-REVIEW.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
