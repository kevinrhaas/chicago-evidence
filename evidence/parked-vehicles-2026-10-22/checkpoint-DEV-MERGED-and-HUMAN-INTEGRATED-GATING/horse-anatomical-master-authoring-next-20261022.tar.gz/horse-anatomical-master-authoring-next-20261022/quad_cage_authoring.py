# SPDX-License-Identifier: CC0-1.0
"""Original static horse authoring source. UNEXECUTED geometry draft.

The only entry point requires explicit --execute-reviewed-source and a NEW output
folder. Source compilation/JSON checks do not call build(). No old GLB is read or
modified. This is not a qualified anatomical/photo master or a rigged export.
"""
import argparse, collections, json, math, pathlib, struct

def average(points):
 return tuple(sum(p[k] for p in points)/len(points) for k in range(3))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def sub(a,b):return tuple(a[k]-b[k] for k in range(3))
def length(a):return math.sqrt(sum(x*x for x in a))
def edge(a,b):return tuple(sorted((a,b)))

class Cage:
 def __init__(self):self.v=[];self.f=[];self.material=[];self.region=[];self.sharp=set()
 def vertex(self,p):
  if len(p)!=3 or not all(math.isfinite(x) for x in p):raise ValueError('Nonfinite authoring vertex')
  self.v.append(tuple(p));return len(self.v)-1
 def face(self,ids,material=0,region='body'):
  if len(ids)<3 or len(set(ids))!=len(ids):raise ValueError('Degenerate source face')
  self.f.append(tuple(ids));self.material.append(material);self.region.append(region);return len(self.f)-1
 def bridge(self,a,b,material=0,region='body',per_face=None):
  if len(a)!=len(b):raise ValueError('Boundary cardinality mismatch')
  for k in range(len(a)):
   self.face([a[k],a[(k+1)%len(a)],b[(k+1)%len(b)],b[k]],per_face(k) if per_face else material,region)
 def split_boundary(self,loop):
  # Insert midpoints into every retained face owning a boundary edge. Adjacent
  # ngons remain explicit and subdivision handles them; no hidden T-junctions.
  mids={edge(a,b):self.vertex(average([self.v[a],self.v[b]])) for a,b in zip(loop,loop[1:]+loop[:1])}
  for i,face in enumerate(self.f):
   if face is None:continue
   expanded=[]
   for a,b in zip(face,face[1:]+face[:1]):
    expanded.append(a)
    if edge(a,b) in mids:expanded.append(mids[edge(a,b)])
   self.f[i]=tuple(expanded)
  result=[]
  for a,b in zip(loop,loop[1:]+loop[:1]):result.extend([a,mids[edge(a,b)]])
  return result
 def remove_patch(self,face_indices):
  counts=collections.Counter();directed=[]
  for fi in face_indices:
   face=self.f[fi]
   if face is None:raise ValueError('Overlapping source patches')
   directed.extend(zip(face,face[1:]+face[:1]));counts.update(edge(a,b) for a,b in zip(face,face[1:]+face[:1]))
  boundary=[(a,b) for a,b in directed if counts[edge(a,b)]==1]
  nexts=dict(boundary)
  if len(nexts)!=len(boundary):raise ValueError('Patch has a branched boundary')
  first=boundary[0][0];loop=[first]
  while nexts[loop[-1]]!=first:
   loop.append(nexts[loop[-1]])
   if len(loop)>len(boundary):raise ValueError('Unclosed source boundary')
  if len(loop)!=len(boundary):raise ValueError('Multiple source boundary loops')
  for fi in face_indices:self.f[fi]=None
  return loop
 def compact(self):
  active=[i for i,f in enumerate(self.f) if f is not None]
  self.f=[self.f[i] for i in active];self.material=[self.material[i] for i in active];self.region=[self.region[i] for i in active]
 def orient_closed(self):
  self.compact();owners=collections.defaultdict(list)
  for fi,f in enumerate(self.f):
   for a,b in zip(f,f[1:]+f[:1]):owners[edge(a,b)].append((fi,a,b))
  if any(len(v)!=2 for v in owners.values()):raise ValueError('Source cage must be closed two-manifold at every edge')
  adjacency=collections.defaultdict(list)
  for records in owners.values():
   (i,a,b),(j,c,d)=records;same=(a,b)==(c,d);adjacency[i].append((j,same));adjacency[j].append((i,same))
  flip={0:False};q=[0]
  while q:
   i=q.pop()
   for j,same in adjacency[i]:
    wanted=flip[i]^same
    if j in flip and flip[j]!=wanted:raise ValueError('Nonorientable authoring surface')
    if j not in flip:flip[j]=wanted;q.append(j)
  if len(flip)!=len(self.f):raise ValueError('Expected one connected anatomical skin cage')
  self.f=[tuple(reversed(f)) if flip[i] else f for i,f in enumerate(self.f)]
  volume=0.
  for f in self.f:
   for k in range(1,len(f)-1):volume+=sum(self.v[f[0]][j]*cross(self.v[f[k]],self.v[f[k+1]])[j] for j in range(3))/6
  if abs(volume)<1e-12:raise ValueError('Zero signed source volume')
  if volume<0:self.f=[tuple(reversed(f)) for f in self.f]
 def subdivide(self):
  # Ordinary Catmull-Clark with explicit sharp sole edges. Material and region
  # labels follow source faces; this is not automatic rig-ready retopology.
  fp=[average([self.v[i] for i in f]) for f in self.f]
  owners=collections.defaultdict(list);incident=collections.defaultdict(list)
  for fi,f in enumerate(self.f):
   for v in f:incident[v].append(fi)
   for a,b in zip(f,f[1:]+f[:1]):owners[edge(a,b)].append(fi)
  if any(len(v)!=2 for v in owners.values()):raise ValueError('Nonmanifold subdivision input')
  neighbors=collections.defaultdict(list)
  for a,b in owners:neighbors[a].append(b);neighbors[b].append(a)
  new=Cage()
  for i,p in enumerate(self.v):
   sharp=[j for j in neighbors[i] if edge(i,j) in self.sharp]
   if len(sharp)>=3:point=p
   elif len(sharp)==2:point=tuple((6*p[k]+self.v[sharp[0]][k]+self.v[sharp[1]][k])/8 for k in range(3))
   else:
    n=len(incident[i]);F=average([fp[j] for j in incident[i]]);E=average([average([p,self.v[j]]) for j in neighbors[i]])
    point=tuple((F[k]+2*E[k]+(n-3)*p[k])/n for k in range(3))
   new.vertex(point)
  ep={}
  for e,faces in owners.items():
   a,b=e
   point=average([self.v[a],self.v[b]]) if e in self.sharp else average([self.v[a],self.v[b],fp[faces[0]],fp[faces[1]]])
   ep[e]=new.vertex(point)
   if e in self.sharp:new.sharp.update([edge(a,ep[e]),edge(ep[e],b)])
  facepoints=[new.vertex(p) for p in fp]
  for fi,f in enumerate(self.f):
   for k,v in enumerate(f):new.face([v,ep[edge(v,f[(k+1)%len(f)])],facepoints[fi],ep[edge(f[k-1],v)]],self.material[fi],self.region[fi])
  return new

def ring_positions(center,rx,ry,u,v,angles,warp=None):
 result=[]
 for t in angles:
  p=tuple(center[k]+rx*math.cos(t)*u[k]+ry*math.sin(t)*v[k] for k in range(3))
  result.append(warp(p,t) if warp else p)
 return result

def attach(cage,loop,profile,u,v,region,material_at=lambda j:0,warps=None,per_faces=None,sole=False):
 # Choose one cyclic frame using the actual aperture to avoid an arbitrary
 # twisted bridge. Subsequent rings keep exactly that frame and cardinality.
 n=len(loop);first=profile[0];options=[]
 for winding in [1,-1]:
  for phase in range(n):
   angles=[(phase+winding*k)*2*math.pi/n for k in range(n)]
   p=ring_positions(first[:3],first[3],first[4],u,v,angles)
   score=sum(sum((cage.v[a][j]-b[j])**2 for j in range(3)) for a,b in zip(loop,p));options.append((score,angles))
 angles=min(options,key=lambda item:item[0])[1]
 for j,row in enumerate(profile):
  points=ring_positions(row[:3],row[3],row[4],u,v,angles,warps[j] if warps else None)
  ring=[cage.vertex(p) for p in points]
  cage.bridge(loop,ring,material_at(j),region,(lambda k:per_faces(j,k,angles)) if per_faces else None);loop=ring
 if sole:cage.sharp.update(edge(a,b) for a,b in zip(loop,loop[1:]+loop[:1]))
 cage.face(list(reversed(loop)),material_at(len(profile)-1),region)
 return loop

def build(c):
 cage=Cage();N=c['body_sides'];rings=[];grid={}
 for row in c['body_profile']:
  x,y,z,rx,ry=row;rings.append([cage.vertex((x+rx*math.cos(k*2*math.pi/N),y+ry*math.sin(k*2*math.pi/N),z)) for k in range(N)])
 for j in range(len(rings)-1):
  for k in range(N):grid[j,k]=cage.face([rings[j][k],rings[j][(k+1)%N],rings[j+1][(k+1)%N],rings[j+1][k]],4 if j>=12 else 0,c['body_regions'][j])
 cage.face(list(reversed(rings[0])),0,'tail_dock');cage.face(rings[-1],4,'lip_front')
 for hole in c['body_root_holes']:
  name=hole['part'];side=1 if name.endswith('_l') else -1
  loop=cage.remove_patch([grid[hole['body_interval'],k] for k in hole['circumferential_columns']])
  rows=c['fore_l' if name.startswith('fore') else 'hind_l'];profile=[[side*x,y,z,rx,rz] for x,y,z,rx,rz in rows]
  hoof_start=len(profile)-3
  attach(cage,loop,profile,(1,0,0),(0,0,1),name,lambda j:2 if j>=hoof_start else 0,sole=True)
 ear=c['ear_authoring']
 for side,column in [(1,ear['left_column']),(-1,ear['right_column'])]:
  loop=cage.split_boundary(cage.remove_patch([grid[ear['root_body_interval'],column]]));x=side*ear['root_center_x_m'];y=ear['root_center_y_m'];z=ear['root_center_z_m']
  profile=[[x,y,z,.022,.009],[x+side*.003,y+.035,z-.003,.030,.012],[x+side*.008,y+.090,z-.010,.022,.009],[x+side*.012,ear['tip_y_m'],z-.015,.0015,.0015]]
  warps=[]
  for j,row in enumerate(profile):
   exposure=math.sin(math.pi*j/(len(profile)-1))
   warps.append(lambda p,t,e=exposure:(p[0],p[1],p[2]-.008*max(0,math.sin(t))**2*e))
  attach(cage,loop,profile,(1,0,0),(0,0,1),'ear_'+str(side),warps=warps,per_faces=lambda j,k,angles:5 if j in (1,2) and math.sin((angles[k]+angles[(k+1)%len(angles)])/2)>0 else 0)
 eye=c['eye_authoring']
 for side,column in [(1,eye['left_column']),(-1,eye['right_column'])]:
  loop=cage.split_boundary(cage.remove_patch([grid[eye['root_body_interval'],column]]));y=eye['center_y_m'];z=eye['center_z_m']
  profile=[[side*eye['rim_x_m'],y,z,eye['outer_half_height_m'],eye['outer_half_length_m']],[side*.116,y,z,eye['visible_half_height_m'],eye['visible_half_length_m']],[side*eye['eye_surface_x_m'],y,z,.0015,.002]]
  attach(cage,loop,profile,(0,1,0),(0,0,1),'orbit_'+str(side),lambda j:3 if j==2 else 0)
 nose=c['nostril_authoring']
 for side,column in [(1,nose['left_column']),(-1,nose['right_column'])]:
  loop=cage.split_boundary(cage.remove_patch([grid[nose['root_body_interval'],column]]));y=nose['center_y_m'];z=nose['center_z_m']
  profile=[[side*nose['outer_x_m'],y,z,nose['half_height_m'],nose['half_length_m']],[side*(nose['outer_x_m']-.007),y,z,.017,.027],[side*nose['cavity_x_m'],y,z,.010,.018]]
  attach(cage,loop,profile,(0,1,0),(0,0,1),'nostril_'+str(side),lambda j:1 if j==2 else 4)
 cage.orient_closed()
 authored={'vertices':len(cage.v),'faces':len(cage.f),'sharp_edges':len(cage.sharp),'regions':dict(collections.Counter(cage.region))}
 for _ in range(c['subdivision']['iterations_first_preview']):cage=cage.subdivide()
 cage.orient_closed()
 return cage,authored

def export_static(cage,c,out,authored):
 # One shared, connected surface; material batches duplicate only exported
 # attribute arrays, not source coordinates. No old skeleton/socket is implied.
 materials=[]
 settings=c['material_reconstruction']
 for key in ['coat','hair','hoof','eye','muzzle','inner_ear']:
  materials.append({'name':'equine_'+key,'pbrMetallicRoughness':{'baseColorFactor':settings[key+'_rgb_linear']+[1],'metallicFactor':0,'roughnessFactor':settings[key+'_roughness']}})
 normals=[[0.,0.,0.] for _ in cage.v];triangles=[]
 for fi,f in enumerate(cage.f):
  for k in range(1,len(f)-1):
   a,b,d=f[0],f[k],f[k+1];normal=cross(sub(cage.v[b],cage.v[a]),sub(cage.v[d],cage.v[a]));triangles.append((a,b,d,cage.material[fi]))
   if length(normal)<1e-12:raise ValueError('Degenerate exported triangle; stop before output')
   for vertex in (a,b,d):normals[vertex]=[normals[vertex][j]+normal[j] for j in range(3)]
 normals=[[x/length(n) for x in n] for n in normals]
 d={'asset':{'version':'2.0','generator':'original connected equine quad-cage anatomy study; unaccepted'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'name':'horse_anatomy_static_reconstruction','mesh':0,'extras':{'status':'UNACCEPTED static anatomy development; no rig/tack/interaction','license':'CC0-1.0','frame':c['frame']}}],'materials':materials,'meshes':[{'name':'connected_anatomical_surface','primitives':[]}],'buffers':[],'bufferViews':[],'accessors':[]};blob=bytearray()
 def acc(rows,kind,component=5126):
  while len(blob)%4:blob.append(0)
  flat=[x for row in rows for x in (row if isinstance(row,(list,tuple)) else [row])];offset=len(blob);blob.extend(struct.pack('<'+('f' if component==5126 else 'I')*len(flat),*flat));vi=len(d['bufferViews']);d['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':len(blob)-offset});a={'bufferView':vi,'componentType':component,'count':len(rows),'type':kind}
  if kind=='VEC3':a.update(min=[min(r[j] for r in rows) for j in range(3)],max=[max(r[j] for r in rows) for j in range(3)])
  d['accessors'].append(a);return len(d['accessors'])-1
 p=acc(cage.v,'VEC3');n=acc(normals,'VEC3')
 for material in sorted({t[3] for t in triangles}):
  indices=[v for a,b,d0,m in triangles if m==material for v in (a,b,d0)];index=acc(indices,'SCALAR',5125);d['meshes'][0]['primitives'].append({'attributes':{'POSITION':p,'NORMAL':n},'indices':index,'material':material})
 d['buffers']=[{'byteLength':len(blob)}];js=json.dumps(d,separators=(',',':')).encode();js+=b' '*((-len(js))%4);blob+=b'\0'*((-len(blob))%4);glb=struct.pack('<III',0x46546c67,2,28+len(js)+len(blob))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(blob),0x004e4942)+blob
 report={'status':'UNACCEPTED new static anatomical authoring study, NOT photographic/rig/tack/production qualified','license':'CC0-1.0','frame':c['frame'],'source_control_cage':authored,'vertices':len(cage.v),'triangles':len(triangles),'draws':len(d['meshes'][0]['primitives']),'bytes':len(glb),'textures':0,'texture_memory_bytes':0,'animations':[],'skin_joints':0,'sockets':[],'anatomy_controls':c,'missing':['actual anatomical/photographic review','independent topology/scale/pose checks','hair/mane/tail grooming','UV/PBR microdetail','rig-ready retopology review','anatomical skeleton and motion','fitted tack','LODs and browser memory/frame costs']}
 (out/'horse-anatomical-static-unaccepted.glb').write_bytes(glb);(out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
 (out/'static-subdivided-surface.json').write_text(json.dumps({'license':'CC0-1.0','note':'Subdivided static development surface; author controls and source remain canonical','vertices':cage.v,'faces':cage.f,'materials':cage.material,'regions':cage.region},separators=(',',':'))+'\n')

def main():
 p=argparse.ArgumentParser();p.add_argument('--controls',type=pathlib.Path,default=pathlib.Path(__file__).with_name('anatomy-authoring-controls.json'));p.add_argument('--output-dir',type=pathlib.Path,required=True);p.add_argument('--execute-reviewed-source',action='store_true');a=p.parse_args()
 if not a.execute_reviewed_source:p.error('Source is UNEXECUTED; require explicit reviewed source execution')
 if a.output_dir.exists():p.error('Refuse existing output directory')
 c=json.loads(a.controls.read_text());cage,authored=build(c);a.output_dir.mkdir();export_static(cage,c,a.output_dir,authored)
 print(json.dumps({'output':str(a.output_dir),'status':'UNACCEPTED static source study; review required'}))
if __name__=='__main__':main()
