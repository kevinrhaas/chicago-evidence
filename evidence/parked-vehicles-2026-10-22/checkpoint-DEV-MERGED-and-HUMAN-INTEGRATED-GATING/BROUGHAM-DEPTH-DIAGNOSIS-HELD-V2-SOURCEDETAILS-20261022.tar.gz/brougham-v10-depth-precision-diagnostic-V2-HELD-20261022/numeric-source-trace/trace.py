from pathlib import Path
import struct,json,hashlib
import numpy as np
R=Path(__file__).parent;P=Path('/workspace/shared/studebaker-brougham-v10-roof-source-20261021/candidate/brougham.glb');b=P.read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);off=20+n;bn=struct.unpack_from('<I',b,off)[0];buf=b[off+8:off+8+bn]
def access(i):
 a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];return np.frombuffer(buf,dtype='<f4',count=a['count']*3,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,3).astype(float)
mesh=next(m for m in j['meshes'] if m['name']=='surface_vehicle_body_0');p=mesh['primitives'][0];vs=access(p['attributes']['POSITION']).reshape(-1,3,3);ns=access(p['attributes']['NORMAL']).reshape(-1,3,3);g=np.cross(vs[:,1]-vs[:,0],vs[:,2]-vs[:,0]);g/=np.linalg.norm(g,axis=1)[:,None];rows=[]
for part in j['extras']['parts']:
 if part['frame']!='vehicle_body' or part['material']!=0:continue
 a=part['triangle_start_in_batch'];z=a+part['triangles'];v=vs[a:z];norm=ns[a:z];geom=g[a:z];dot=np.sum(norm*geom[:,None,:],axis=2);near=geom[:,0]>.8;light=np.array([4,8,5])/np.linalg.norm([4,8,5]);lam=np.sum(norm*light,axis=2)
 rows.append({'name':part['name'],'start':a,'triangles':part['triangles'],'bounds':[v.min(axis=(0,1)).tolist(),v.max(axis=(0,1)).tolist()],'normal_length_minmax':[float(np.linalg.norm(norm,axis=2).min()),float(np.linalg.norm(norm,axis=2).max())],'normal_vs_face_dot_minmax':[float(dot.min()),float(dot.max())],'near_facing_triangles':int(near.sum()),'near_lambert_minmax':None if not near.any() else [float(lam[near].min()),float(lam[near].max())]})
result={'model_sha256':hashlib.sha256(b).hexdigest(),'scope':'One frozen raw master body material0 decode, unit normal/geometric face alignment and source face bounds; no generation/browser or causal assumption','body_triangles':len(vs),'parts':rows};(R/'BODY-NORMAL-AND-BOUNDS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
# Bounded exact geometric light-ray check: one centroid per near-facing door cap,
# all original triangles once, and fixed original sun direction. No renderer approximation.
alltri=[];names=[]
nodeWorld={}
parents={c:i for i,n in enumerate(j['nodes']) for c in n.get('children',[])}
def world(i):
 if i not in nodeWorld:nodeWorld[i]=np.array(j['nodes'][i].get('translation',[0,0,0]),float)+(world(parents[i]) if i in parents else 0)
 return nodeWorld[i]
for ni,node in enumerate(j['nodes']):
 if 'mesh' not in node:continue
 mesh=j['meshes'][node['mesh']];primitive=mesh['primitives'][0];arr=access(primitive['attributes']['POSITION']).reshape(-1,3,3)+world(ni);frame=j['nodes'][parents[ni]]['name'];mat=primitive.get('material',0)
 labels=[mesh['name']]*len(arr)
 for part in j['extras']['parts']:
  if part['frame']==frame and part['material']==mat:
   aa=part['triangle_start_in_batch'];zz=aa+part['triangles'];labels[aa:zz]=[part['name']]*part['triangles']
 alltri.extend(arr);names.extend(labels)
A=np.array(alltri);v0=A[:,0];e1=A[:,1]-v0;e2=A[:,2]-v0;d=np.array([4,8,5])/np.linalg.norm([4,8,5]);h=np.cross(np.broadcast_to(d,e2.shape),e2);det=np.sum(e1*h,axis=1);valid=np.abs(det)>1e-12;inv=np.zeros_like(det);inv[valid]=1/det[valid];rays=[]
for part in j['extras']['parts']:
 if part['name'] not in ['deep_U_closed_door','deep_curved_lower_body'] or part['frame']!='vehicle_body':continue
 aa=part['triangle_start_in_batch'];zz=aa+part['triangles']
 for k in range(aa,zz):
  if g[k,0]<.8 or vs[k,:,0].mean()<0:continue
  o=vs[k].mean(axis=0);s=o-v0;u=inv*np.sum(s*h,axis=1);q=np.cross(s,e1);v=inv*(q@d);t=inv*np.sum(e2*q,axis=1);hit=valid&(u>=-1e-9)&(v>=-1e-9)&(u+v<=1+1e-9)&(t>1e-5)
  ids=np.where(hit)[0];idx=None if not len(ids) else ids[np.argmin(t[ids])]
  rays.append({'part':part['name'],'batch_triangle':k,'point':o.tolist(),'normal_dot_sun':float(g[k]@d),'occluder':None if idx is None else names[idx],'distance':None if idx is None else float(t[idx])})
result={'scope':'88 bounded near positive-X outer-cap triangle centroids; exact frozen original306? triangle ray intersections toward unchanged directional sun; finite lower-body/door only, not raster/PCF proof','rays':rays,'count':len(rays),'shadowed':sum(x['occluder'] is not None for x in rays),'occluders':{n:sum(x['occluder']==n for x in rays) for n in sorted(set(x['occluder'] for x in rays if x['occluder']))}};(R/'BODY-EXACT-SUN-RAYS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rays'},indent=2))
# A bounded analytic nine-offset back-face depth probe, not an actual PCF raster.
# Uses original sun basis and recorded unchanged V10 shadow camera extents.
right=np.cross([0,1,0],d);right/=np.linalg.norm(right);up=np.cross(d,right);dx=(1.968832662476255-(-3.2110057739748767))/2048;dy=(3.056495163578449-(-2.9013050964541733))/2048
normal=np.cross(e1,e2);back=(normal@d)<-1e-12;probes=[]
for partname in ['deep_curved_lower_body','deep_U_closed_door']:
 selected=[r for r in rays if r['part']==partname and r['occluder'] is None][::6][:7]
 for r in selected:
  tests=[]
  for ix,iy in [(0,0),(-1,-1),(0,-1),(1,-1),(-1,0),(1,0),(-1,1),(0,1),(1,1)]:
   o=np.array(r['point'])+ix*dx*right+iy*dy*up;s=o-v0;u=inv*np.sum(s*h,axis=1);q=np.cross(s,e1);v=inv*(q@d);t=inv*np.sum(e2*q,axis=1);hit=valid&back&(u>=-1e-9)&(v>=-1e-9)&(u+v<=1+1e-9)&(np.abs(t)<20);ids=np.where(hit)[0];idx=None if not len(ids) else ids[np.argmax(t[ids])];tests.append({'offsetTexels':[ix,iy],'backFace':None if idx is None else names[idx],'towardSunDistance':None if idx is None else float(t[idx]),'analyticallyShadowed':False if idx is None else bool(t[idx]>.0002*(12.828405444828892-6.086382601289634))})
  probes.append({'part':partname,'point':r['point'],'directRayUnoccluded':True,'tests':tests,'shadowedOffsets':sum(x['analyticallyShadowed'] for x in tests)})
(R/'BOUNDED-ANALYTIC-BACKFACE-DEPTH-PROBE.json').write_text(json.dumps({'scope':'12or fewer exact centroid probes, nine offsets at one original shadow texel. Not actual GPU raster/PCF interpolation or causal proof. No lights or geometry altered.','probes':probes},indent=2)+'\n');print('Analytic backface probes:',[(x['part'],x['shadowedOffsets']) for x in probes])
receipt=json.loads(Path('/workspace/shared/brougham-v10-source-actual4-TRANSPORT-HELD-20261022/actual/receipt.json').read_text());cam=receipt['rows'][0]['camera'];W=np.array(cam['world']).reshape(4,4,order='F');V=np.linalg.inv(W);Pr=np.array(cam['projection']).reshape(4,4,order='F');C=np.array(cam['position']);bodyPart=next(part for part in j['extras']['parts'] if part['name']=='deep_curved_lower_body' and part['triangle_start_in_batch']==504);aa=bodyPart['triangle_start_in_batch'];zz=aa+bodyPart['triangles'];B=vs[aa:zz];be1=B[:,1]-B[:,0];be2=B[:,2]-B[:,0]
def depth(p):
 q=Pr@V@np.r_[p,1.];return float((q[2]/q[3]+1)/2)
collisions=[]
for r in rays:
 if r['part']!='deep_U_closed_door':continue
 o=np.array(r['point']);direction=C-o;direction/=np.linalg.norm(direction);hh=np.cross(np.broadcast_to(direction,be2.shape),be2);dd=np.sum(be1*hh,axis=1);ok=np.abs(dd)>1e-12;iv=np.zeros_like(dd);iv[ok]=1/dd[ok];ss=o-B[:,0];uu=iv*np.sum(ss*hh,axis=1);qq=np.cross(ss,be1);vv=iv*(qq@direction);tt=iv*np.sum(be2*qq,axis=1);hit=ok&(uu>=-1e-9)&(vv>=-1e-9)&(uu+vv<=1+1e-9)&(tt< -1e-5);ids=np.where(hit)[0]
 if not len(ids):continue
 k=ids[np.argmax(tt[ids])];bp=o+tt[k]*direction;d1,d2=depth(o),depth(bp);collisions.append({'door_batch_triangle':r['batch_triangle'],'doorPoint':o.tolist(),'underlyingBodyPoint':bp.tolist(),'underlyingBodyTriangle':int(aa+k),'separationAlongCameraRayM':float(-tt[k]),'doorDepth':d1,'bodyDepth':d2,'depthDifference':d2-d1,'depth24BitUnits':(d2-d1)*(2**24-1),'quantized24Equal':round(d1*(2**24-1))==round(d2*(2**24-1)),'float32DepthEqual':bool(np.float32(d1)==np.float32(d2))})
near,far=cam['near'],cam['far'];D=np.linalg.norm(C);res={'scope':'Exact frozen actual camera/projection, original raw master triangle intersections; overlapping front-facing door/body skins measured along identical camera ray. Depth24 quantization and float32 depth equality are mathematical susceptibility proofs; actual GPU DEPTH_BITS was not captured in this run.','camera':cam,'distanceM':float(D),'near':near,'far':far,'depth24WorldQuantumAtRootM':float(D*D*(far-near)/(far*near)/(2**24-1)),'samples':len(collisions),'quantized24Equal':sum(x['quantized24Equal'] for x in collisions),'float32DepthEqual':sum(x['float32DepthEqual'] for x in collisions),'maxDepth24Units':max(x['depth24BitUnits'] for x in collisions),'rows':collisions};(R/'EXACT-DOOR-BODY-PROJECTED-DEPTH-COMPETITION.json').write_text(json.dumps(res,indent=2)+'\n');print('Projected depth:',{k:v for k,v in res.items() if k not in ['camera','rows']})
