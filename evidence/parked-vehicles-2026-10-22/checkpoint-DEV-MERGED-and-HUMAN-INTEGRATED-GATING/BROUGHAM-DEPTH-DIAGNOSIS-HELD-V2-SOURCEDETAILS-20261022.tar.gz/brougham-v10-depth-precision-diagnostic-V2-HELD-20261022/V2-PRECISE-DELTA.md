# V2 precise correction — unrun

Original V1 actual failed the exact nondepth matrix guard after preserving original desktop PNG; browser/server closed. Its failure is untouched. Pure pinned Three camera arithmetic reproduces projection[0] delta -5.684341886080802e-14 and [5] delta -2.842170943040401e-14 when near changes because perspective construction multiplies and divides by near. Camera pose/FOV/other nondepth fields are exact; no camera refit occurred.

V2 retains the original projection matrix nondepth elements verbatim and changes only depth elements10 and14 from the near100 calculation before inversion. Existing exact projection/extrinsic/FOV/sourcecrop/DOM/light guard remains unchanged. This preserves the desired xy framing exactly, rather than tolerating a numerical drift. Actual default-framebuffer DEPTH_BITS and full model/floor insideclip guards remain. Each attempted row is now saved before equality checks, and failure-finally explicitly attempts proven owned zero-resource cleanup before browser close. No model, source, physical materials/lights/shadows or camera fit changes.

Fresh outsideapp directory and exclusive intent/output; root must explicitly release one175s/165s run. Four normal detail frames desktop/mobile × original/tightnear. It is instrument diagnosis only; source fidelity, geometry repair, photographic and mainworld acceptance remain open.
