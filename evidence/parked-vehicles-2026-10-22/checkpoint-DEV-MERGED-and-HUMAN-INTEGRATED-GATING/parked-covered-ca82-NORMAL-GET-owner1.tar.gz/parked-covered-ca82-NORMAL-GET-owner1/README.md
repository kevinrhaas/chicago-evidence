# Current ca82 normal CI — PASS and CLOSED

One bounded GET-only collector finished 2026-10-22T04:15:11.251815+00:00. All three normal jobs qualified at exact source ca82d06541b31a560d0c29e426668e777db3ad61 / tree c0b314187a80cbcf8cc115ffeec8f400386b827e. Sourcegate printed CHECK PASS1041steps, none red, and its separate changelog step passed. Moving-frames passed both motion ceilings and phone GPU/release checks. Report passed all actual required steps.

Both pull_request job logs identify actual synthetic merge9a581978a78c36db87f8355660ebf8dc1c75a690; GitHub commit GET proves parents exactly[fdb227dbf5ed952921ef652f5a02480fffdad462,ca82d06541b31a560d0c29e426668e777db3ad61]. The push report checked out source ca82 itself. Run events, branch, workflow IDs/source bytes and attempt1 were verified. Final PR head/base and remote branch checks stayed current through collector closure. Full job logs and all supporting API responses remain here.

Periodic polling was61seconds with a45minute ceiling, after the initial discovery/source-pin reads. One additional root-requested current-step GET is explicitly preserved as SUPPLEMENT; no second polling observer ran. No POST, rerun, dispatch, cancellation, old18 reschedule, merge, app/index/mirror or source mutation occurred. Root was notified of final success before capsule assembly. CollectorPID867091 and exec80432 departed/exited0.

Root still performs its fresh required-check/mergeability reading and ordinary merge. This capsule records these exact-head/base normal CI results; it does not claim old smoke jobs were rerun or manufacture a result for another head.

| Workflow | Run | Job | Actual checkout |
| --- | ---: | ---: | --- |
| chicago-4d-pr-stuck.yml | [39719285501](https://github.com/kevinrhaas/chicago/actions/runs/39719285501) | 119628758665 | ca82d06541b31a560d0c29e426668e777db3ad61 |
| chicago-4d-check.yml | [39719291796](https://github.com/kevinrhaas/chicago/actions/runs/39719291796) | 119628778617 | 9a581978a78c36db87f8355660ebf8dc1c75a690 |
| chicago-4d-moving-frames.yml | [39719291472](https://github.com/kevinrhaas/chicago/actions/runs/39719291472) | 119628776010 | 9a581978a78c36db87f8355660ebf8dc1c75a690 |
