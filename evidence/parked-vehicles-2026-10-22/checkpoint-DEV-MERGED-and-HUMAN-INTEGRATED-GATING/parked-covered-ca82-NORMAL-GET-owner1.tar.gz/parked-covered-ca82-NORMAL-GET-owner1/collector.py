#!/usr/bin/env python3
"""One finite GET-only collector for current PR1174 normal jobs; no mutation APIs."""
import pathlib,importlib.util,json,subprocess,time,datetime,hashlib,base64,os,re
SHARED=pathlib.Path('/workspace/shared');HELPER=SHARED/'parked-covered-2981-NEXT-HEAD-CI-HELD/observe-GET-only.py'
spec=importlib.util.spec_from_file_location('normal_job_auditor',HELPER);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
HEAD='ca82d06541b31a560d0c29e426668e777db3ad61';TREE='c0b314187a80cbcf8cc115ffeec8f400386b827e';PR=1174
BRANCH='steward/parked-period-vehicles-20261021';REPO='kevinrhaas/chicago'
OUT=SHARED/'parked-covered-ca82-NORMAL-GET-owner1';OUT.mkdir(exist_ok=False)
(SHARED/'parked-covered-ca82-NORMAL-GET.lock').mkdir(exist_ok=False)
start=time.monotonic();deadline=start+45*60;counter=0;audited={};failures={};retrieved={};last=None;commits={}
state={'sha':HEAD,'tree':TREE,'repository':REPO,'branch':BRANCH,'pr':PR,'started':h.now(),'observer_pid':os.getpid(),'observer_source_sha256':h.sha(pathlib.Path(__file__).read_bytes()),'reused_auditor_sha256':h.sha(HELPER.read_bytes()),'scope':'GET-only exact current-head normal sourcegate/movingframes/report+changelog; no old18 or rerun/dispatch/merge','normal_qualification_pass':False,'POSTs':0,'interval_seconds':61,'max_minutes':45,'closed':False}
h.save(OUT/'owner.json',state)
def get(label,endpoint,plain=False):
 global counter
 for attempt in range(1,4):
  h.need(time.monotonic()<deadline,'45minute collector deadline');counter+=1;stem=OUT/(f'{counter:04d}-{label}-attempt{attempt}')
  r=subprocess.run(['gh','api','--method','GET','repos/'+REPO+'/'+endpoint],text=True,capture_output=True,timeout=min(45,max(1,deadline-time.monotonic())))
  stem.with_suffix('.stdout').write_text(r.stdout);stem.with_suffix('.stderr').write_text(r.stderr)
  transient=not re.search(r'HTTP (?:401|403)\b',r.stderr) and bool(re.search(r'HTTP (?:502|503|504)\b|unexpected EOF|connection reset by peer|transport read',r.stderr,re.I));retry=bool(r.returncode and transient and attempt<3)
  with(OUT/'GET-ATTEMPTS.jsonl').open('a')as f:f.write(json.dumps({'at':h.now(),'endpoint':endpoint,'label':label,'attempt':attempt,'returncode':r.returncode,'retry':retry,'stdout_sha256':h.sha(r.stdout.encode()),'stderr_sha256':h.sha(r.stderr.encode())})+'\n')
  if retry:time.sleep(2**attempt);continue
  h.need(r.returncode==0,'Actual GET failed: '+label+' '+r.stderr[-1000:]);return r.stdout if plain else json.loads(r.stdout)
def route():
 p=get('pr','pulls/'+str(PR));h.need(p['state']=='open'and p['head']['sha']==HEAD and p['head']['ref']==BRANCH and p['head']['repo']['full_name']==REPO and p['base']['ref']=='dev','PR source/base/head route changed')
 return p
def brief(r):return{k:r.get(k)for k in ['id','path','event','head_sha','head_branch','run_attempt','status','conclusion','html_url']}
def checkout(log,event,base):
 clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log);lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+Z\s*','',x)for x in clean.splitlines()]
 hashes=[lines[k+1]for k,line in enumerate(lines[:-1])if line.endswith('git log -1 --format=%H')and re.fullmatch('[a-f0-9]{40}',lines[k+1])]
 h.need(bool(hashes),'Actual checkout commit missing in completed log');actual=hashes[0]
 if actual not in commits:commits[actual]=get('checkout-commit-'+actual[:12],'git/commits/'+actual)
 parents=[p['sha']for p in commits[actual]['parents']]
 proof={'checkout_sha':actual,'parents':parents,'expected_source_head':HEAD,'initial_pr_base':base,'event':event,'checkout_log_values':hashes,'merge_ref_in_log':'refs/remotes/pull/1174/merge'in clean}
 if event=='pull_request':h.need(proof['merge_ref_in_log']and parents==[base,HEAD],'Actual PR merge checkout/base/source mismatch: '+json.dumps(proof))
 else:h.need(actual==HEAD,'Push report did not checkout current source head')
 proof['PASS']=True;return proof
try:
 pr=route();base=pr['base']['sha'];state['initial_pr']={'head':pr['head']['sha'],'base':base,'base_ref':pr['base']['ref'],'merge_commit_sha':pr.get('merge_commit_sha'),'mergeable':pr.get('mergeable'),'mergeable_state':pr.get('mergeable_state')}
 listing=get('initial-current-head-runs','actions/runs?head_sha='+HEAD+'&per_page=100');state['runs']=[brief(r)for r in listing['workflow_runs']];h.save(OUT/'latest.json',state);print(json.dumps({'discovered_current_head_runs':state['runs'],'initial_pr':state['initial_pr']}),flush=True)
 h.need(get('source-commit','git/commits/'+HEAD)['tree']['sha']==TREE,'Root frozen tree/source commit differs');h.need(get('source-branch','git/ref/heads/'+BRANCH)['object']['sha']==HEAD,'Remote source branch moved')
 pins={};ids={}
 for path in h.NORMAL:
  obj=get('workflow-source-'+pathlib.Path(path).stem,'contents/'+path+'?ref='+HEAD);raw=base64.b64decode(obj['content']);h.need(raw==(pathlib.Path('/workspace/chicago')/path).read_bytes(),'Current workflow differs from exact pushed source')
  wf=get('workflow-id-'+pathlib.Path(path).stem,'actions/workflows/'+pathlib.Path(path).name);h.need(wf['path']==path,'Workflow path/id differs');pins[path]=h.sha(raw);ids[path]=wf['id'];(OUT/(pathlib.Path(path).name+'.source.yml')).write_bytes(raw)
 state.update(source_workflow_sha256=pins,workflow_ids=ids);h.save(OUT/'owner.json',state)
 while time.monotonic()<deadline:
  tick=time.monotonic();listing=get('current-head-runs','actions/runs?head_sha='+HEAD+'&per_page=100');runs=listing['workflow_runs'];h.need(listing['total_count']==len(runs),'Incomplete current-head workflow list')
  unexpected=[brief(r)for r in runs if r['path']not in h.NORMAL];h.need(not unexpected,'Unexpected current-head workflow; no qualification: '+json.dumps(unexpected))
  for path in h.NORMAL:h.need(sum(r['path']==path for r in runs)<=1,'Duplicate normal run at current source head')
  state['runs']=[brief(r)for r in runs];h.save(OUT/'latest.json',state)
  for run in runs:
   event,name,required=h.NORMAL[run['path']];h.need(run['head_sha']==HEAD and run['head_branch']==BRANCH and run['run_attempt']==1 and run['event']==event and run['workflow_id']==ids[run['path']],'Run source/event/ref/attempt/workflow mismatch')
   key=str(run['id'])
   if run['status']!='completed'or key in retrieved:continue
   jobs=get('jobs-'+key,'actions/runs/'+key+'/jobs?per_page=100');h.need(jobs['total_count']==len(jobs['jobs'])==1,'Exactly one actual normal job expected');job=jobs['jobs'][0];log=get('job-'+str(job['id'])+'-log','actions/jobs/'+str(job['id'])+'/logs',True);h.need(bool(log.strip()),'Completed job log is empty')
   info={'run_id':run['id'],'job_id':job['id'],'workflow':run['path'],'event':event,'head_sha':HEAD,'conclusion':run['conclusion'],'job_log_sha256':h.sha(log.encode()),'log_bytes':len(log.encode()),'html_url':run['html_url'],'steps':job['steps']}
   try:
    info['checkout']=checkout(log,event,base)
    info.update(h.audit_job(job,run,HEAD,name,required))
    h.need(run['conclusion']=='success','Workflow conclusion not success')
    if name=='gate':h.need(bool(re.search(r'CHECK PASS',re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log))),'Successful source gate lacks actual CHECK PASS')
    audited[key]=info;print(json.dumps({'qualified_completed_job':info}),flush=True)
   except Exception as error:info['qualification_error']=str(error);failures[key]=info;print(json.dumps({'ACTUAL_TERMINAL_FAILURE_OR_QUALIFICATION_DEFECT':info}),flush=True)
   retrieved[key]=info;h.save(OUT/'audited-jobs.json',list(audited.values()));h.save(OUT/'failures.json',list(failures.values()))
  state.update(at=h.now(),runs=[brief(r)for r in runs],audited=list(audited.values()),failures=list(failures.values()),normal_strict_success=len(audited),terminal_jobs_retrieved=len(retrieved),api_requests=counter)
  h.save(OUT/'latest.json',state);summary=tuple((r['id'],r['status'],r['conclusion'])for r in runs)
  if summary!=last:
   with(OUT/'transitions.jsonl').open('a')as f:f.write(json.dumps(state)+'\n')
   print(json.dumps({'transition':state['runs'],'normal_strict_success':len(audited),'retrieved':len(retrieved)}),flush=True);last=summary
  if len(runs)==3 and len(retrieved)==3:
   fresh=route();state['final_pr']={k:fresh.get(k)for k in ['number','state','mergeable','mergeable_state','merge_commit_sha']};state['final_pr']['base_sha']=fresh['base']['sha'];h.need(fresh['base']['sha']==base,'PR base advanced; prior merge checkouts cannot qualify fresh current base')
   state['checks']=get('final-current-head-check-runs','commits/'+HEAD+'/check-runs?per_page=100');state['statuses']=get('final-current-head-status','commits/'+HEAD+'/status');h.need(get('final-source-branch','git/ref/heads/'+BRANCH)['object']['sha']==HEAD,'Remote source branch moved')
   state['normal_qualification_pass']=len(audited)==3 and not failures;break
  remaining=min(61-(time.monotonic()-tick),deadline-time.monotonic())
  while remaining>0:time.sleep(min(5,remaining));remaining=min(61-(time.monotonic()-tick),deadline-time.monotonic())
 h.need(state['normal_qualification_pass'],'Actual current-head job failure/qualification defect or45minute deadline; original logs retained')
except Exception as error:state['error']=str(error)
finally:
 state.update(ended=h.now(),elapsed_seconds=time.monotonic()-start,api_requests=counter,closed=True);h.save(OUT/'latest.json',state);h.save(OUT/'terminal.json',state);print(json.dumps({'TERMINAL':True,'normal_qualification_pass':state['normal_qualification_pass'],'normal_strict_success':len(audited),'retrieved':len(retrieved),'error':state.get('error'),'output':str(OUT),'closed':True}),flush=True)
raise SystemExit(0 if state['normal_qualification_pass']else 1)
