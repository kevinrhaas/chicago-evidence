# Bardwell waistcoat finishing — prepared source, execution held

One visible target: replace the flat V-front reading with folded facings, a quiet closure placket and five small cloth-covered buttons. This is a Bardwell-only authoring proposal against qualified canonical source `34cf462ed343b8b2b70da70303344fff7e5e083f`, run [39712579846](https://github.com/kevinrhaas/chicago/actions/runs/39712579846). It is not a rendered improvement or a canonical replacement. No geometry function, Blender, browser, server, export or CI action has run for this packet. Root alone owns integration/release.

The patch adds one pure-Python helper, two opt-in builder hooks, Bardwell-only recipe configuration and narrow additions to the two existing Mount source-use descriptions. Existing `human_workwear_fit.py`, body, rig, source normals, source UVs, feet, poses, eyes, skin, hair, shirt, trouser hems and export guards are unchanged. Dufresne/Martin and other-era/default behavior have no finishing opt-in. The two actual web PNGs under `actual-canonical-before/` are **before only** from the qualified run, not new proposal captures.

## Visible construction

The helper clips narrow facing bands on actual canonical waistcoat triangles, using retained original-source barycentrics for the V-edge field. The 24 mm facing rises toward the opening by an original 4.5 mm roll; the assembled boundary has a 1.5 mm thickness return. A 22 mm placket rises 1.6 mm on the closed lower front. Five 8.4 mm diameter cloth-covered buttons use actual front-shell triangle support and inherited interpolated skin weights. Their dimensions, cloth covering, color and construction are original reconstructed choices; no painting pixels, tracing, sampling or period measurements are used. This is a layered fitted facing study, not a newly cut and draped whole waistcoat.

Normals are derived from the indexed existing shell before clipping/UV expansion. New detail UV corners interpolate the existing garment UVs; button UVs are original radial coordinates. At most four new skin influences are retained with the existing 2.5 percent discarded-mass refusal. Existing source body custom-normal/readback handling is untouched, including raw 0.001. Existing 2 mm sole guards are untouched. New returns, button shading and LOD behavior have not been evaluated. Geometry failure must stop, not weaken those guards.

## Source reading and limits

The exact saved Mount reproduction JPGs and saved rights metadata are included. They were locally viewed, with no new network request. In *Bargaining for a Horse*, the standing right-hand man's pale waistcoat provides folded/reversed front cues above a closed lower front. *Bar-room Scene* provides small front-button rows and layered front/fold cues; a coat fold is not relabeled a measured waistcoat pattern. The paintings are year-only 1835 American genre analogies. They do not establish July 1 availability, a Chicago outfit, Bardwell's clothing/likeness, employment, hardware, fibers, weave, exact colors or dimensions. Original faithful painting reproductions are public domain under the saved metadata; source code is GPL-3.0-or-later, original generated graphical arrays remain CC0-1.0. No reproduction pixels enter an exported asset.

Root must assign an append-only LIBERTIES/provenance entry and update derived source-use/license documentation if this proposal is integrated. Existing L418 is historical baseline provenance, not approval of this new unexecuted detail layer. No invented liberty ID or tracked documentation has been written here.

## Review and next bounded release

Review `BARDWELL-WAISTCOAT-FINISHING-SOURCE-HELD.patch`, `EXACT-PREIMAGES.json` and `STATIC-SCOPE-RECEIPT.json`. The patch dry-run is against a disposable outside-app copy of exact 34cf inputs, never the live app/index. Fifteen static checks cover syntax, exact recipe opt-in scope, unchanged builder functions outside `build`, entire unchanged body-normal path, source-reading additions and patch applicability. These are source preparation checks, not geometry/fit controls.

Only after explicit parent release: evaluate **one Bardwell LOD0** canonical waistcoat plus this helper in an outside-app directory. Keep all original arrays for before/after identity comparison; inspect the actual generated band topology, source UV continuity, winding/area, weights, front-shell support and indexed normals. Stop on an unsupported input or failed weight/topology guard. Do not proceed automatically to Blender, a new browser caller, dense fit sweep, all residents, export or CI. The next GPU lane and new actual preview require separate coordination with root. No runnable browser harness is included.

Two additional skinned detail meshes and one extra cloth-button material are proposed for Bardwell (per original body mesh/LOD); buttons have 120 authored triangles before existing LOD reduction. Facing triangle count, exported bytes/draws and lower-LOD detail survival remain unmeasured until release. Existing public budgets are unchanged. The extra material is explicitly a garment, not footwear or eye material. No shoe repair is present.

## Acceptance remains open

The 40 inherited idle source-face negative projections (historical minimum about -8.98 mm) remain open and are neither masked nor claimed repaired. Existing skin is not hidden. Shirt fullness, collar/neckcloth, realistic cuffs/seams, hair/neckline, skin response, full waistcoat cut/drape, complete animated/LOD fit, seated coverage and photographic quality remain open. The current canonical standing Bardwell initial visible increment remains a separate honest reconstruction; this source proposal cannot retroactively upgrade it or imply T1789 closure.

`RELEASE-HELD.json` is false. This frozen packet records exact source preimages and actual canonical GLB/artifact member hashes for reacquisition without duplicating large GLBs. No app/Git/index/mirror/ticket write or CI/ref movement occurred.
