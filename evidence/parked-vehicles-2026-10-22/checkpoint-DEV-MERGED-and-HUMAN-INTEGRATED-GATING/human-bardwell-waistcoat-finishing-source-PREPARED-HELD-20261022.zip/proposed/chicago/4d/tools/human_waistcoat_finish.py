# SPDX-License-Identifier: GPL-3.0-or-later
"""HELD original Bardwell waistcoat finishing study; generated arrays CC0-1.0.

Qualitative Mount 1835 analogies only. Not an attested outfit, pattern or likeness.
Adds layers to an unchanged canonical waistcoat; cannot repair its inherited fit.
No module-level geometry generation, Blender, body edits or source image sampling.
"""
from __future__ import annotations
import math
from human_workwear_fit import _clip, _unit
from human_source_normals import source_shared_normals


def waistcoat_finishing(shell, source_mesh, recipe, bones, height, scale, config):
    """Derive folded facings/placket and five cloth-covered buttons, held/unrun.

    Coordinates are the unchanged prepared Y-up/+Z-forward frame. Actual indexed
    shell normals are computed BEFORE clipping or any UV expansion. Source UVs,
    barycentrics and interpolated skin mappings travel with each cut. Body arrays,
    existing shell arrays and their source normals are never written.
    """
    if config.get('id') != 'bardwell_waistcoat_finishing_v1' or scale <= 0:
        raise ValueError('explicit supported Bardwell finishing configuration required')
    if config.get('status') != 'source_proposal_unrendered':
        raise ValueError('unreviewed finishing cannot carry an acceptance status')
    expected = {'lapel_width_m': .024, 'lapel_roll_m': .0045,
                'cloth_thickness_m': .0015, 'placket_width_m': .022,
                'placket_raise_m': .0016, 'button_radius_m': .0042,
                'button_height_m': .0017, 'button_count': 5,
                'button_segments': 12}
    if config['construction'] != expected:
        raise ValueError('this finite source study requires its exact reviewed parameters')
    cfg = expected
    ps, fs = shell['positions_m'], shell['triangles']
    normals = source_shared_normals(ps, fs, list(range(len(ps))))
    # Recover original source coordinates without inventing a nearest-body map.
    sid_positions = {}
    for sid, p in zip(source_mesh['source_vertex_indices'], source_mesh['positions_m']):
        if sid in sid_positions and math.dist(sid_positions[sid], p) > 1e-12:
            raise ValueError('source ID has inconsistent rest coordinates')
        sid_positions[sid] = p
    def source(v):
        return [math.fsum(sid_positions[k][a]*w for k,w in v['basis'].items()) for a in range(3)]
    def skin(mapping):
        ordered = sorted(((b,w) for b,w in mapping.items() if w>1e-12), key=lambda x:(-x[1],x[0]))
        if math.fsum(w for b,w in ordered[4:]) > .025:
            raise ValueError('new detail exceeds unchanged 2.5 percent skin-drop guard')
        total = math.fsum(w for b,w in ordered[:4])
        if total <= 0: raise ValueError('detail lacks skin support')
        return {b:w/total for b,w in ordered[:4]}
    waist = recipe['waist_height_fraction']*height/scale
    shoulder = bones['upperarm_l']['head_m'][1]
    closure = waist+recipe['workwear_tailoring_v5']['waistcoat_closed_front_torso_fraction']*(shoulder-waist)
    slope = .105/max(.01,shoulder-closure)
    lo = waist-.04
    width = cfg['lapel_width_m']/scale
    facing = {'positions_m':[], 'triangles':[], 'uvs':[], 'weights':[], 'corner_uvs':[]}
    cache, support, boundary = {}, [], {}
    def vertex(v, raise_m):
        n = _unit(v['n']); w = skin(v['w'])
        p = [v['p'][a]+n[a]*raise_m/scale for a in range(3)]
        key = (tuple(p),tuple(sorted(w.items())))
        if key not in cache:
            cache[key] = len(facing['positions_m'])
            facing['positions_m'].append(p);facing['uvs'].append(v['uv']);facing['weights'].append(w)
            support.append((v,n,raise_m))
        return cache[key]
    def polygon(poly, lift):
        if len(poly)<3:return
        ids = [vertex(v,lift(v)) for v in poly]
        for k in range(1,len(ids)-1):
            tri=[ids[0],ids[k],ids[k+1]]
            if len(set(tri))<3:continue
            a,b,c=[facing['positions_m'][i] for i in tri]
            u=[b[j]-a[j] for j in range(3)];v=[c[j]-a[j] for j in range(3)]
            if math.hypot(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])<1e-18:continue
            facing['triangles'].append(tri)
            facing['corner_uvs'].append([poly[j]['uv'] for j in (0,k,k+1)])
    shell_polys=[]
    for fi,face in enumerate(fs):
        poly=[{'p':ps[i], 'uv':shell['corner_uvs'][fi][j], 'w':shell['weights'][i],
               'n':normals[i], 'basis':shell['source_basis'][i]} for j,i in enumerate(face)]
        front=_clip(poly,lambda v:source(v)[2])
        shell_polys.append(front)
        for side in (-1,1):
            def d(v):
                p=source(v);return side*p[0]-slope*(p[1]-closure)
            band=_clip(front,lambda v:side*source(v)[0])
            band=_clip(band,lambda v:source(v)[1]-closure)
            band=_clip(_clip(band,d),lambda v:width-d(v))
            polygon(band,lambda v:.001+cfg['lapel_roll_m']*max(0.,min(1.,1-d(v)/width)))
        placket=_clip(front,lambda v:cfg['placket_width_m']/(2*scale)-source(v)[0])
        placket=_clip(placket,lambda v:cfg['placket_width_m']/(2*scale)+source(v)[0])
        placket=_clip(placket,lambda v:source(v)[1]-(lo+.016/scale))
        placket=_clip(placket,lambda v:closure-.006/scale-source(v)[1])
        polygon(placket,lambda v:cfg['placket_raise_m'])
    if not facing['triangles']:raise ValueError('empty source-derived waistcoat facings')
    # Thickness returns occur at the assembled layer boundary only; no per-face
    # prisms or internal fins. Side return retains local source UV edge lengths.
    for face in facing['triangles']:
        for a,b in zip(face,face[1:]+face[:1]):
            key=tuple(sorted((a,b)));boundary.setdefault(key,[]).append((a,b))
    for edges in boundary.values():
        if len(edges)>2:raise ValueError('nonmanifold facing; stop rather than hide it')
        if len(edges)!=1:continue
        a,b=edges[0];low=[]
        for i in (a,b):
            v,n,lift=support[i];p=facing['positions_m'][i]
            drop=min(cfg['cloth_thickness_m'],lift-.0002)/scale
            low.append(len(facing['positions_m']))
            facing['positions_m'].append([p[j]-n[j]*drop for j in range(3)])
            facing['uvs'].append(list(facing['uvs'][i]));facing['weights'].append(dict(facing['weights'][i]))
        for tri in ([b,a,low[0]],[b,low[0],low[1]]):
            facing['triangles'].append(tri);facing['corner_uvs'].append([facing['uvs'][i] for i in tri])
    buttons={'positions_m':[], 'triangles':[], 'uvs':[], 'weights':[], 'corner_uvs':[]}
    def support_at(x,y):
        candidates=[]
        for poly in shell_polys:
            for k in range(1,len(poly)-1):
                tri=[poly[j] for j in (0,k,k+1)];a,b,c=[v['p'] for v in tri]
                det=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
                if abs(det)<1e-16:continue
                u=((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(y-c[1]))/det
                v=((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(y-c[1]))/det
                bc=[u,v,1-u-v]
                if min(bc)<-1e-10:continue
                p=[math.fsum(t['p'][j]*w for t,w in zip(tri,bc)) for j in range(3)]
                n=_unit([math.fsum(t['n'][j]*w for t,w in zip(tri,bc)) for j in range(3)])
                weights=skin({bone:math.fsum(t['w'].get(bone,0)*w for t,w in zip(tri,bc)) for bone in set().union(*(t['w'] for t in tri))})
                candidates.append((p,n,weights))
        if not candidates:raise ValueError('button has no actual front-shell support')
        return max(candidates,key=lambda item:item[0][2])
    y0,y1=lo+.032/scale,closure-.025/scale
    if y1-y0<.08/scale:raise ValueError('insufficient closed-front button band')
    for j in range(cfg['button_count']):
        p,n,w=support_at(.004/scale,y0+(y1-y0)*j/(cfg['button_count']-1))
        # Upright tangent projected onto the actual local front normal.
        up=_unit([-n[1]*n[0],1-n[1]*n[1],-n[1]*n[2]])
        right=[up[1]*n[2]-up[2]*n[1],up[2]*n[0]-up[0]*n[2],up[0]*n[1]-up[1]*n[0]]
        N=cfg['button_segments'];base=len(buttons['positions_m'])
        # Back/front centers and a shallow rounded rim; closed original geometry.
        local=[(0,0,cfg['placket_raise_m']+.0004), (0,0,cfg['placket_raise_m']+cfg['button_height_m'])]
        local += [(cfg['button_radius_m']*math.cos(2*math.pi*k/N),cfg['button_radius_m']*math.sin(2*math.pi*k/N),cfg['placket_raise_m']+.001) for k in range(N)]
        for x,y,z in local:
            buttons['positions_m'].append([p[a]+(x*right[a]+y*up[a]+z*n[a])/scale for a in range(3)])
            buttons['uvs'].append([.5+x/(2*cfg['button_radius_m']),.5+y/(2*cfg['button_radius_m'])]);buttons['weights'].append(dict(w))
        for k in range(N):
            nxt=(k+1)%N
            for tri in ([base,base+2+nxt,base+2+k],[base+1,base+2+k,base+2+nxt]):
                buttons['triangles'].append(tri);buttons['corner_uvs'].append([buttons['uvs'][i] for i in tri])
    receipt={'id':config['id'],'status':'source_proposal_unrendered','body_mutated':False,
             'base_waistcoat_mutated':False,'fit_accepted':False,'inherited_negative_projections':'OPEN: 40; historical minimum about -8.98 mm',
             'source_scope':'Mount 1835 qualitative analogy only; original dimensions/materials, not traced or measured',
             'deferred':['collar/neckcloth','shirt fullness','cuffs/seams','hair/skin','complete fit','photo quality'],
             'new_materials':1,'new_meshes_per_body_mesh':2,'button_triangles':len(buttons['triangles'])}
    return [('facings','garment_outer__waistcoat_wool',facing),
            ('buttons',config['button_material']['name'],buttons)],receipt
