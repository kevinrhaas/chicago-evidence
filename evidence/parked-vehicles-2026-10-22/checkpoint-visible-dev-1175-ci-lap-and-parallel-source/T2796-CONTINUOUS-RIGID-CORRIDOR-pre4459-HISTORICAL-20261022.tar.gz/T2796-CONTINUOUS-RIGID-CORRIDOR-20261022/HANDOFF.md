# T2796 continuous provisional circuit and shoulder ruling

**Historical pre-4459 source proof only. Primary is deliberately integrating new DEV data; the final street/index guards failed correctly. A coherent current-source comparison/rerun is pending root producer closure. No current-source qualification is claimed. See `historical-pre4459-PASS/FREEZE-NOTE.json`.**

The source-only route now has an explicit reconstructed shoulder-use ruling and a continuous plan-view clearance certificate for the full current provisional rigid-team envelope. **The route remains inactive.** No app, ticket, Git ref, model, road, wear mask, parked wagon, lot or survey data was changed. This is technical preparation for the existing claim, not a new approval dependency or a claim of world, hitch, gait or photographic completion.

`proposed/` contains the original held controller and its eleven tests unchanged, plus the dated route JSON with updated provenance and corridor ruling. `ROUTE-METADATA-ONLY.patch` is the delta against the earlier unapplied route. `SOURCE-ONLY-UNAPPLIED.patch` is the complete three-file source proposal. Root owns application and the canonical liberties/ticket updates. `LIBERTY-APPEND.md` supplies the readable liberty text without allocating a competing canonical liberty number.

## Reasonable authored shoulder use

The existing 503.189879571 m loop remains Randolph eastbound, Clark northbound, Lake westbound and La Salle southbound. Its 17 m radius requires 7.870419924 degrees of steering, below the unchanged 8-degree W01 limit. The speed, pauses, stops at curvature changes and repeated journey remain reconstructed behavior. No named driver's historical action, schedule or vehicle ownership is invented.

Using the existing firm, dry worked-earth shoulders within ROW is adopted as an evidence-bounded reconstruction under AGENTS' instruction to build at the reconstructed tier and declare the liberty. It does not claim that the narrower wear evidence fits the team, or turn ROW membership alone into an attested traffic surface. Ordinary worked width remains 15.60576 m; Lake's principal worked width remains 19.5072 m. These are the existing `WORKED_SHARE`/L327 choices. No mask, affordance, width, land control or obstacle is changed.

The reader declares `CORRIDOR_LINE = 'both'` and explains the two questions. Drawn reaches locate the actual rendered road and its relationship to blocks and obstacles. Existing `corridors(from_control=True)` finite rings independently bound platted ROW. Randolph and Lake have a centred verdict and zero shift. Clark and La Salle explicitly report `no_control` with the existing zero-offset fallback; they are not relabeled as surveyed-centred. No drawn/control disagreement is resolved by moving the town.

## Independent native envelope

`read_corridor_and_native.py` independently decodes every W01 POSITION and its actual translation-only hierarchy from master SHA `274e737b…`. It measures body, pole, front pivot and wheel bounds; continuous wheel roll is bounded by each actual maximum radial distance. The original licensed horse's default skin is evaluated in native world coordinates, then converted using the measured source origin and 0.36440688373115426 metres per native unit, followed by the declared standing-support quaternion. No old89b sockets or new animation bounds are inherited.

Closed-form sine/cosine extrema cover every steering angle from −8 to +8 degrees. They include current native W01 geometry, the old explicitly unaccepted rigid pair at X ±0.8 m / Z 3.9 m, and the current adapter's **unaccepted** rest-to-0.95 m diagnostic pole-pitch range. That pole-height choice remains a geometric control, not a fitted hitch. A different fitted pole or horse arrangement requires new bounds.

The independent union in rear-axle coordinates is:

- X: **−1.746730320 to +1.745630711 m**;
- Z: **−0.685000023 to +6.746590901 m**.

It fits the unchanged conservative route rectangle X ±1.75 m, Z [−1, 6.8] m. Minimum transverse containment slack is only **3.27 mm**; no gait, head/tail idle, leading-horse heading, fitted harness or extra gear can inherit that small allowance without a new envelope. The old broader rear overbound remains safely inside the same held rectangle; no smaller route footprint was substituted to force clearance.

## Continuous clearance rather than isolated poses

`certify_continuous.mjs` splits at exact line/arc boundaries, then adaptively bisects only intervals whose conservative bounds cannot yet certify clearance. For any local point within radius ρ of the rear axle, `|dW/ds| ≤ 1 + ρ|κ|`. Integrating over half an interval bounds every intermediate point and heading, not just endpoints. A finite lattice covers the entire local rectangle with a maximum 0.349161943 m cover distance.

Finite worked-road and ROW margins are 1-Lipschitz. Their lattice margins therefore bound the full moving rectangle after subtracting spatial cover and interval motion. Whole-rectangle AABB distance is a conservative lower bound against each registered obstacle proxy; subtracting the same motion covers the full interval. Every accepted bound also subtracts the unchanged **0.25 m clearance** and a 1e-7 m arithmetic guard. Failed parent intervals are refined, not discarded. Leaf intervals are verified to partition every exact piece through the lap seam, without gaps. At stationary steering joins the reference pose is fixed and the native all-angle envelope already covers the steering sweep.

The certificate evaluates **195 intervals**, retains **102 accepted leaves**, and reaches at most depth **5**. The minimum residual margins after those deductions are:

| Domain | Certified residual |
| --- | ---: |
| Existing dry worked roadway | **+0.033785745 m** |
| Existing finite control-derived ROW rings | **+3.399365083 m** |
| Registered obstacle projections | **+0.681540548 m** |

The census retains 678 building footprints, 1,128 fence segments, 297 conservative gate-swing disks, 111 sidewalk segments, 51 hitching posts and 86 static wagon records. The one previously reviewed `town_wagon_lake_23` refinement remains its same constructor-bounded oriented box at the unchanged location and heading. No obstacle was deleted or moved. Loose yard cargo, trees and geometry beyond these declared proxies are not silently included.

## The shoulders are actually dry and untrimmed in the source construction

Nominal worked width alone would be insufficient: `streets.js` trims shoulders where water or more than 0.35 m crown drop demands it. The packet proves the local corridor rectangles with exact bilinear height bounds. It splits each height rectangle at the terrain grid lines, where each bilinear patch takes its extrema at corners, and uses at-most-1 m longitudinal intervals. This bounds every crown-to-shoulder height difference, including all lateral interior points. The proof extends 5 m beyond the certified finite travel rectangles, covering the renderer's 2.25 m panel rows; these reaches are away from source polyline ends and joins.

All four local widths stay dry and untrimmed. Maximum certified crown drop is **0.177983 m**, below the unchanged 0.35 m rule. Minimum continuous local ground height is **+0.48 m**, above the actual −0.10 m water cutoff. This is a source-constructor projection proof, not a newly rendered triangle/pixel result, wheel-grade test or soil-strength measurement.

## Negative controls remain negative

The original narrow-core certificate remains **FAIL at −3.600220059 m**. An independent actual footprint witness at `[568.103768619, −250.883109253]` is **2.708649369 m outside every current opened street's narrow track band**, with Randolph closest. `GLOBAL-WORN-CORE-WITNESS.json` checks all opened streets; it does not claim an executed router raster result. No narrow track is widened or reclassified.

An injected point obstacle at a real route reference rejects with margin −0.2500001 m, while the unchanged real proxies there certify +7.571038783 m. The injected record is a test only; actual obstacle data stays unchanged. A falsely shrunken hull X ±1.74 m is rejected by the independent native containment guard even though a smaller footprint would make road tests easier.

The original eleven controller regressions still pass with the new metadata. Source input hashes are checked for all 723 current files read by the geographic/ROW census. Native/dry/ROW CPU work took about 0.20 seconds and the continuous proof about 0.09 seconds, with one math thread, nice19 and a 15-second command cap. The earlier route/proof capsules remain unchanged.

## Limits before activation

This certificate is **plan-view clearance for an unaccepted rigid diagnostic assembly**. It does not qualify actual animated limbs, hooves, head/tail motion, leading-horse yaw, fitted harness/doubletree/traces/reins, seated driver and garments, ground pitch/roll, suspension, overhead clearance or wheel/hoof support. It also supplies no world rendering or mobile budget receipt. All existing live-admission flags remain false. Complete those technical steps and reprice the actual dynamic envelope before activating the circuit; no further owner permission is needed merely to author this declared shoulder behavior.
