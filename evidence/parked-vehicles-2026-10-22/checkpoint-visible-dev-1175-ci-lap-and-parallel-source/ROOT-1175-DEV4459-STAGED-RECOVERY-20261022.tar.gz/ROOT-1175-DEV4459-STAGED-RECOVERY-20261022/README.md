# Recover the current person integration

This is a resolved but uncommitted source checkpoint. Full preflight is pending. Fetch both exact commits in RECOVERY.json. On an isolated branch at its base, apply SOURCE-TEXT.patch and restore each listed binary from its specified source commit using git show. Stage these paths only; git write-tree must equal the recorded tree. No duplicate binary payload is needed because every byte is already pushed in03ef. Preserve ordinary DEV PR flow and full rendering requirements.
