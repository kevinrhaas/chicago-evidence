# T2796: coherent 4459 source snapshot

The fixed 503.189879571 m circuit has a fresh **continuous plan-view PASS for the provisional rigid envelope** on the coherent 4459 merge inputs. It remains inactive. This is source preparation for T2796, not app intake, world acceptance, a main merge gate result or a complete moving-team clearance certificate.

The source was read from `/workspace/chicago/chicago/4d` after root's supported producer closed. HEAD was `03ef5178977184928cf454011737ea2b17607b5d`, with uncommitted MERGE_HEAD `4459c0e22a10563b93b0bec88b0b567f4ff916c6`. HEAD's parent tree was `82061871547ba5e73215c445911c58410ff503ab`; that is explicitly **not** the pending integration tree. The actual 727-file dependency projection is SHA256 `a290f1d67def5dcf95a6692bc9ddefe0844a745b497c3050ba1f3fa886b669ea`. Every dependency was verified before and after the proof.

## Why a new proof was needed

Twenty of the old 715 census input files changed. The terrain metadata and heightfield bytes also changed. The source change therefore could not be dismissed as metadata or inherited as a prior PASS. `DEPENDENCY-COMPARISON.json` contains the exact old/new hashes and obstacle geometry changes: eight building footprints, 41 fence segments, 11 gate disks, two sidewalk segments and three static-wagon proxies differ. Counts remain unchanged; these are replacements in the comparison, not obstacles removed to make the route pass.

All four selected road records are identical as parsed objects, not merely their widths. The route coordinates, 17 m radius, 8-degree steering cap, provisional rectangle, 0.25 m clearance, refinement limits and arithmetic guard are unchanged. A fresh read of the altered terrain yields the same local dry-shoulder bounds; this was measured again, rather than inferred from remote Green Tree changes. The geographic/ROW/terrain/native readers ran against current coherent inputs.

The certifier's only code change from the historical proof is an additional check of the complete 727-file dependency map. `CERTIFIER-GUARD-ONLY.diff` makes that scope inspectable. All mathematical tests, limits and controls remain unchanged.

## Actual results

The proof evaluated 195 intervals, accepted 102 leaves and reached depth five. Every leaf partitions an exact line or arc through the lap seam. The full rectangle X ±1.75 m, Z [−1, 6.8] m is covered continuously using the same spatial cover and integrated motion bound.

| Domain | Minimum residual after all deductions |
| --- | ---: |
| Dry worked roadway | +0.033785745 m |
| Finite control-derived ROW | +3.399365083 m |
| Declared obstacle proxies | +0.681540548 m |

The census retains 678 footprints, 1,128 fence segments, 297 gate disks, 111 sidewalk segments, 51 hitching posts and 86 static wagons. The Lake wagon's constructor-bounded proxy remains at its original location and heading. The source dry-shoulder proof gives minimum ground +0.48 m and maximum crown-drop bound 0.177983 m, below the unchanged 0.35 m trim rule. This describes the source surface constructor, not a new rendered mesh or soil load-bearing measurement.

The independent W01 decoder again measures the exact master `274e737b…`, including body, pole, wheel roll and continuous front steering. Its union with the explicitly unaccepted default rigid horse pair fits the same held rectangle. Its minimum lateral containment slack is only 3.27 mm. Native/dry/ROW work closed in about 1.21 s wall time; the continuous proof itself took 0.158 s. Each command was bounded to 15 seconds, nice19, with one math thread.

All eleven controller regressions passed. A complete three-file patch was checked and applied in an external empty directory and the resulting bytes matched `proposed/`. No app, index, ticket, Git ref, source mask, lot, road or model was written.

## Negative evidence remains visible

The original narrow worn-core certificate remains **FAIL at −3.600220059 m**. The current source still places a real footprint point 2.708649369 m outside every opened street's narrow track band; all 29 opened street records were checked. This is geometric source-band evidence, not an executed router raster or a change to its permissions. An injected blocking point still rejects at −0.2500001 m, and a falsely shrunken ±1.74 m hull still fails native containment.

The original route capsule, the historical pre-4459 PASS snapshot and both actual source-drift guard failures remain unchanged in their previous directories and archive. This fresh packet supersedes none of those historical outcomes.

## Source ruling and remaining limits

`LIBERTY-APPEND.md` and the proposed route declare reconstructed low-speed traffic on the existing firm dry worked-earth shoulders within ROW. This uses the existing rendered width, with no wear-mask widening or new claim of historic shoulder wear. The reader declares `CORRIDOR_LINE = 'both'`: drawn lines answer rendered road/block relationships; control rings answer platted ROW. Randolph and Lake have existing centred zero-offset control. Clark and La Salle retain their disclosed `no_control` zero-offset fallback. This is no new owner-approval dependency.

All live and actor-qualification flags stay false. The envelope excludes actual gait, head/tail idle sweep, leading-horse yaw, fitted collars/harness/doubletree/traces/reins, seated driver and garments, ground pitch/roll, wheel/hoof support and overhead clearance. Loose cargo, trees and geometry outside the declared proxy census are not covered. The old ±0.8 m / Z 3.9 m pair and 0.95 m pole-height span remain unaccepted diagnostic hypotheses. A fitted or animated assembly requires a newly measured dynamic envelope and world/mobile receipts before activation.

## Reproduction

Use the frozen current inputs listed in `CURRENT-SOURCE-DEPENDENCIES.json`. Run `prepare_environment.mjs`, then `read_corridor_and_native.py`, and then `certify_continuous.mjs`; the terrain/native reader refreshes its receipt hash, so update only the route's `independent_source_envelope_sha256` and the environment's copy of that metadata before freezing a new receipt. This does not change route geometry. The source projection guard rejects changed app dependencies; do not repin it without another explicit comparison.

Run the existing controller checks with `node proposed/tools/test_transport_circuit.mjs`. The native helper uses the separately saved, licensed original horse file with exact SHA `41acd9be…`; this packet does not duplicate that asset. Set `T2796_HORSE_SOURCE` only to those exact same source bytes if its local path differs.
