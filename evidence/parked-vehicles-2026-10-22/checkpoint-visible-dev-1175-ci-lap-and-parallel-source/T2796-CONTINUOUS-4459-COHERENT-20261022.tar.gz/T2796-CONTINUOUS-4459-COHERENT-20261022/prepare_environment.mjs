// SPDX-License-Identifier: GPL-3.0-or-later
// Finite actual-data route diagnosis only. No scene/global admission; no writes in app.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root = path.dirname(new URL(import.meta.url).pathname), app = '/workspace/chicago/chicago/4d';
const inputHashes = {};
const read = p => { const bytes = fs.readFileSync(path.join(app,p));inputHashes[p]=crypto.createHash('sha256').update(bytes).digest('hex');return JSON.parse(bytes); };
const sha = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const source = fs.readFileSync(root + '/proposed/renderers/web/js/transport-circuit.js');
const { compileTransportCircuit } = await import(`data:text/javascript;base64,${source.toString('base64')}`);
const route = JSON.parse(fs.readFileSync(root + '/proposed/data/transport/routes/w01-1835-circuit.json'));
for (const [p, digest] of Object.entries(route.source_inputs_sha256)) if (sha(app + '/' + p) !== digest) throw Error('changed route source ' + p);
const circuit = compileTransportCircuit(route), streets = read('data/streets/1835.json');
const roads = streets.streets.filter(r => route.road_ids.includes(r.id)).map(r => ({ id: r.id,
  line: r.drawn_track_local_enu_m ?? r.path_local_enu_m, core: r.track_width_m / 2,
  worked: Math.max(r.track_width_m, ({ principal: .80, ordinary: .64, light: .44 }[r.traffic] ?? .44) * (r.corridor_width_m ?? 24.384)) / 2,
  row: (r.corridor_width_m ?? 24.384) / 2 }));
const sub = (a, b) => [a[0] - b[0], a[1] - b[1]], dot = (a, b) => a[0] * b[0] + a[1] * b[1];
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
function segmentDistance(p, a, b) { const d = sub(b, a), t = Math.max(0, Math.min(1, dot(sub(p, a), d) / dot(d, d))); return dist(p, [a[0] + t * d[0], a[1] + t * d[1]]); }
const inside = (p, poly) => { let yes = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) if ((poly[i][1] > p[1]) !== (poly[j][1] > p[1]) && p[0] < (poly[j][0] - poly[i][0]) * (p[1] - poly[i][1]) / (poly[j][1] - poly[i][1]) + poly[i][0]) yes = !yes; return yes; };
const edge = poly => poly.map((p, i) => [p, poly[(i + 1) % poly.length]]);
function crossing(a, b, c, d) { const u = sub(b, a), v = sub(d, c), w = sub(c, a), den = u[0] * v[1] - u[1] * v[0]; if (Math.abs(den) < 1e-12) return false; const t = (w[0] * v[1] - w[1] * v[0]) / den, q = (w[0] * u[1] - w[1] * u[0]) / den; return t >= 0 && t <= 1 && q >= 0 && q <= 1; }
function polygonDistance(a, b) { if (inside(a[0], b) || inside(b[0], a)) return 0; let min = Infinity; for (const [p, q] of edge(a)) for (const [r, s] of edge(b)) { if (crossing(p, q, r, s)) return 0; min = Math.min(min, segmentDistance(p, r, s), segmentDistance(q, r, s), segmentDistance(r, p, q), segmentDistance(s, p, q)); } return min; }
const box = pts => ({ e0: Math.min(...pts.map(p => p[0])), e1: Math.max(...pts.map(p => p[0])), n0: Math.min(...pts.map(p => p[1])), n1: Math.max(...pts.map(p => p[1])) });
const overlap = (a, b, pad) => a.e0 <= b.e1 + pad && a.e1 >= b.e0 - pad && a.n0 <= b.n1 + pad && a.n1 >= b.n0 - pad;
const obstacles = [], coverage = { buildings: 0, fenceSegments: 0, gateSwingDisks: 0, sidewalks: 0, hitchingPosts: 0, staticWagons: 0 };
function obstacle(id, pts, pad, kind) { obstacles.push({ id, pts, pad, kind, bounds: box(pts) }); coverage[kind]++; }
const index = read('data/sidecars/1835/index.json');
for (const record of index.structures) {
  const sidecar = read('data/' + record.sidecar), raw = sidecar.footprint, poly = Array.isArray(raw) ? raw : raw?.polygon, p = sidecar.placement;
  if (!poly?.length || !p || p.vertical_anchor === 'water') continue;
  const theta = (p.rotation_deg ?? 0) * Math.PI / 180;
  // Conservatively includes drawn_by/camp footprints; no passages opened for a team.
  obstacle(record.id, poly.map(([u, v]) => [p.local_e + u * Math.cos(theta) + v * Math.sin(theta), p.local_n - u * Math.sin(theta) + v * Math.cos(theta)]), 0, 'buildings');
}
for (const rec of read('data/enclosures/index.json').enclosures) {
  const data = read('data/enclosures/' + rec.file);
  for (const run of data.runs ?? []) {
    const points = run.path_local_enu_m ?? [];
    for (let i = 1; i < points.length; i++) obstacle(rec.id + '/' + run.id + '/' + i, [points[i - 1], points[i]], .20, 'fenceSegments');
  }
  for (const opening of data.openings ?? []) if (opening.gate && opening.gate.kind !== 'opening' && opening.at_local_enu_m && Number.isFinite(opening.width_m))
    obstacle(rec.id + '/' + opening.id, [opening.at_local_enu_m, opening.at_local_enu_m], opening.width_m + .20, 'gateSwingDisks');
}
const front = read('data/frontage/town_street_edge.json');
for (const walk of front.walks) if (walk.kind === 'plank_walk') for (let i = 1; i < walk.centreline_local_enu_m.length; i++) obstacle(walk.id, walk.centreline_local_enu_m.slice(i - 1, i + 1), walk.width_m / 2, 'sidewalks');
for (const fence of front.fences) for (let i = 1; i < fence.path_local_enu_m.length; i++) obstacle(fence.id, fence.path_local_enu_m.slice(i - 1, i + 1), .20, 'fenceSegments');
for (const fence of front.fences) for (const opening of fence.openings ?? []) if (opening.gate && opening.gate.kind !== 'opening' && opening.at_local_enu_m && Number.isFinite(opening.width_m))
  obstacle(fence.id + '/' + opening.id, [opening.at_local_enu_m, opening.at_local_enu_m], opening.width_m + .20, 'gateSwingDisks');
for (const p of front.posts) obstacle(p.id, [p.at_local_enu_m, p.at_local_enu_m], .20, 'hitchingPosts');
const wagonIds = new Set();
let refinedStaticProxy = null;
for (const rec of read('data/yard/index.json').yard) for (const w of read('data/yard/' + rec.file).wagons ?? []) {
  if (wagonIds.has(w.id)) continue; wagonIds.add(w.id);
  if (true && w.id === 'town_wagon_lake_23') {
    const yard = read('data/yard/' + rec.file), body = yard.form?.wagon_body_m?.value;
    if (w.kind !== 'farm_box' || w.tilt !== false || w.yoke !== false || JSON.stringify(body) !== JSON.stringify([3.05, 1.07, .55])) throw Error('static wagon refinement source/form mismatch');
    // Constructor-derived conservative local enclosure: rearaxle−1.175−rearR.685
    // =−1.86; tongue startsL/2=1.525, own length2.75 plus pole section <4.35;
    // tyre/hub/bolster/stake all inside±.80 (wheelcentre .605, hub length .154).
    // No canvas/yoke/driver/source replacement is silently omitted.
    const theta = w.bearing_deg * Math.PI / 180;
    const pts = [[-.8, -1.90], [.8, -1.90], [.8, 4.35], [-.8, 4.35]].map(([x, z]) =>
      [w.at_local_enu_m[0] + x * Math.cos(theta) + z * Math.sin(theta), w.at_local_enu_m[1] - x * Math.sin(theta) + z * Math.cos(theta)]);
    obstacle(w.id, pts, 0, 'staticWagons');
    refinedStaticProxy = { id: w.id, method: 'analytical conservative constructor enclosure, not a generated mesh or exact contact polygon', local_x_m: [-.8, .8], local_z_m: [-1.90, 4.35], bearing_deg: w.bearing_deg, at_local_enu_m: w.at_local_enu_m,
      source_sha256: { yard_js: sha(app + '/renderers/web/js/yard.js'), record: sha(app + '/data/yard/' + rec.file) }, preserved: 'Same obstacle and placement; only coarse5m disk replaced by source-bounded oriented box. All other proxies unchanged.' };
  } else obstacle(w.id, [w.at_local_enu_m, w.at_local_enu_m], 5, 'staticWagons');
}
for (const w of read('data/transport/parked/placements.json').scenes['1835']) if (!wagonIds.has(w.replaces)) obstacle(w.id, [w.at_local_enu_m, w.at_local_enu_m], 5, 'staticWagons');

const result={route,roads,obstacles,coverage,refinedStaticProxy,inputHashes,streetSourceSha256:sha(app+'/renderers/web/js/streets.js'),controllerSha256:crypto.createHash('sha256').update(source).digest('hex'),status:'Read-only current-source geographic snapshot; old unchanged static-wagon refinement retained, no deleted obstacles'};fs.writeFileSync(root+'/ENVIRONMENT.json',JSON.stringify(result)+'\n');console.log(JSON.stringify({coverage,refinedStaticProxy,input_files:Object.keys(inputHashes).length}));
