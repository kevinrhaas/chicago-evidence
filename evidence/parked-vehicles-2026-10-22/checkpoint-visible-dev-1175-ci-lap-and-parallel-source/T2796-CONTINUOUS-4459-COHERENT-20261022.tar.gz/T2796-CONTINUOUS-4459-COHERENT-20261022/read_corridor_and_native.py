# SPDX-License-Identifier: GPL-3.0-or-later
"""Current finite ROW, dry-shoulder bounds and independently decoded W01 envelope.
Read-only CPU work. No model, data, road, lot, mask or app mutation.
"""
import json,math,struct,hashlib,sys,time,itertools,importlib.util
from pathlib import Path
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');start=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
CORRIDOR_LINE='both'
CORRIDOR_LINE_WHY='Drawn reaches locate rendered travel and block-relative obstacles; control-centred finite rings independently bound platted ROW. Existing no_control fallback is disclosed, never turned into a new survey assertion.'
sys.path.insert(0,str(A/'tools'));from plat_corridors import corridors,control_offsets
env=json.loads((P/'ENVIRONMENT.json').read_text());ids=env['route']['road_ids'];cr=corridors(from_control=True);drawn=corridors();offsets=control_offsets();row={i:{**cr[i],'drawn_ring_comparison':drawn[i]['ring'],'drawn_centre_comparison':drawn[i]['centre'],'control_details':offsets[i]}for i in ids}
inputs={p:sha(A/p)for p in ['tools/plat_corridors.py','tools/generate_plat_lots.py','data/traces/street_control.json','data/datum.json','data/streets/1835.json','renderers/web/js/streets.js','renderers/web/js/terrain.js','docs/CORRIDOR-LINES.md','AGENTS.md']}
(P/'CONTROL-ROW.json').write_text(json.dumps({'CORRIDOR_LINE':CORRIDOR_LINE,'CORRIDOR_LINE_WHY':CORRIDOR_LINE_WHY,'roads':row,'inputs_sha256':inputs},indent=2)+'\n')
# Exact bilinear height extrema on an axis-aligned rectangle: split at every
# heightfield grid line. Each resulting bilinear patch has extrema at corners.
mp=A/'data/terrain/epochs/e1834_harbor_cut/heightfield.json';meta=json.loads(mp.read_text());raw=mp.with_suffix('.bin').read_bytes();cell=meta['cell_m']
def height(e,n):
 x=(e-meta['origin_e'])/cell;z=(n-meta['origin_n'])/cell;i=math.floor(x);j=math.floor(z);u=x-i;v=z-j
 if not(0<=i<meta['cols']-1 and 0<=j<meta['rows']-1):raise ValueError('outside exact measured grid')
 def H(x,z):return struct.unpack_from('<h',raw,2*(z*meta['cols']+x))[0]*meta['scale']+meta['offset']
 return H(i,j)*(1-u)*(1-v)+H(i+1,j)*u*(1-v)+H(i,j+1)*(1-u)*v+H(i+1,j+1)*u*v
def hbounds(box):
 e0,e1,n0,n1=box;xs=[e0,e1]+[meta['origin_e']+i*cell for i in range(math.floor((e0-meta['origin_e'])/cell)+1,math.ceil((e1-meta['origin_e'])/cell))];zs=[n0,n1]+[meta['origin_n']+i*cell for i in range(math.floor((n0-meta['origin_n'])/cell)+1,math.ceil((n1-meta['origin_n'])/cell))];values=[height(e,n)for e in xs for n in zs];return[min(values),max(values)]
def bbox(points):return[min(p[0]for p in points),max(p[0]for p in points),min(p[1]for p in points),max(p[1]for p in points)]
roi=[435,590,-275,-95]
def segment_clip(a,b,box):
 lo,hi=0,1
 for k,mn,mx in [(0,box[0],box[1]),(1,box[2],box[3])]:
  d=b[k]-a[k]
  if abs(d)<1e-14:
   if not mn<=a[k]<=mx:return None
  else:
   c,d=(mn-a[k])/d,(mx-a[k])/d;lo=max(lo,min(c,d));hi=min(hi,max(c,d))
 return[lo,hi]if lo<hi else None
terrain_segments=[];certs=[]
for road in env['roads']:
 for segment,(a,b)in enumerate(zip(road['line'],road['line'][1:])):
  clipped=segment_clip(a,b,roi)
  if not clipped:continue
  vec=[b[k]-a[k]for k in range(2)];L=math.hypot(*vec);u=[x/L for x in vec];normal=[-u[1],u[0]];lo,hi=[t*L for t in clipped]
  # The certified polygon uses the exact finite subsegment. Terrain is proved
  # an extra5m each end, beyond the renderer's2.25m panel-row spacing.
  elo,ehi=max(0,lo-5),min(L,hi+5);assert elo>0 and ehi<L,'selected source reach must stay away from source ends/joins';worst=0;minimum=math.inf;maxbound=None;count=math.ceil(ehi-elo)
  for i in range(count):
   s0=elo+(ehi-elo)*i/count;s1=elo+(ehi-elo)*(i+1)/count;crown=[[a[k]+u[k]*s for k in range(2)]for s in [s0,s1]];outer=[[p[k]+sgn*normal[k]*road['worked']for k in range(2)]for p in crown for sgn in [-1,1]];hc=hbounds(bbox(crown));ho=hbounds(bbox(outer));drop=max(ho[1]-hc[0],hc[1]-ho[0]);minimum=min(minimum,ho[0]);
   if drop>worst:worst=drop;maxbound={'s_interval_m':[s0,s1],'crown_box_m':bbox(crown),'outer_box_m':bbox(outer),'crown_height_bounds_m':hc,'outer_height_bounds_m':ho}
  assert minimum>-.10 and worst<.35,'actual dry/shoulder trim bound failed'
  centre=[[a[k]+u[k]*s for k in range(2)]for s in [lo,hi]]
  terrain_segments.append({'road_id':road['id'],'original_segment':segment,'a':centre[0],'b':centre[1],'core_half_width_m':road['core'],'worked_half_width_m':road['worked'],'row_half_width_m':road['row']})
  certs.append({'road_id':road['id'],'source_segment':segment,'centre_domain_m':centre,'extended_source_row_domain_m':[[a[k]+u[k]*s for k in range(2)]for s in [elo,ehi]],'intervals':count,'maximum_interval_m':(ehi-elo)/count,'maximum_certified_crown_drop_m':worst,'drawn_shoulder_drop_limit_m':.35,'minimum_continuous_ground_y_m':minimum,'actual_water_cutoff_y_m':-.10,'all_dry_and_untrimmed':True,'worst_interval':maxbound})
(P/'DRY-WORKED-SHOULDER-CERTIFICATE.json').write_text(json.dumps({'status':'Continuous local dry/untrimmed source-width certificate; not rendered pixels or wheel contact','method':'Bilinear extrema at clipped grid-line corners bound all source crown and full lateral positions in each at-most1m longitudinal interval. Their interval difference bounds every shoulder drop; proof extends5m beyond finite travel rectangles, covering renderer panel rows.','roi_enu_m':roi,'finite_drawn_worked_segments':terrain_segments,'certificates':certs,'terrain_sha256':{'meta':sha(mp),'bin':sha(mp.with_suffix('.bin'))},'surface_terrain_contract':'terrain.surfaceHeight is the same committed bilinear field; isWater iff height<−.10m. Height quantisation is already the drawn surface, not a survey accuracy claim.'},indent=2)+'\n')
# Independent stdlib GLB reader. W01 has translation-only native node hierarchy.
wg=A/'renderers/web/transport/parked-wagon/wagon-w01.glb';b=wg.read_bytes();assert hashlib.sha256(b).hexdigest()=='274e737b51872983df792d0b24de8e75de8631890a8d586a32d9c6f0066484fb';n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);binary=b[n+28:];world={}
def walk(i,base):
 node=g['nodes'][i];assert not any(k in node for k in ['matrix','rotation','scale']);world[i]=[base[k]+node.get('translation',[0,0,0])[k]for k in range(3)]
 for child in node.get('children',[]):walk(child,world[i])
for i in g['scenes'][g.get('scene',0)]['nodes']:walk(i,[0,0,0])
def descendants(i):
 yield i
 for c in g['nodes'][i].get('children',[]):yield from descendants(c)
def points(nodes):
 out=[]
 for i in nodes:
  node=g['nodes'][i]
  if 'mesh'not in node:continue
  for prim in g['meshes'][node['mesh']]['primitives']:
   a=g['accessors'][prim['attributes']['POSITION']];assert a['componentType']==5126 and a['type']=='VEC3';v=g['bufferViews'][a['bufferView']];offset=v.get('byteOffset',0)+a.get('byteOffset',0)
   for j in range(a['count']):out.append([x+world[i][k]for k,x in enumerate(struct.unpack_from('<fff',binary,offset+j*v.get('byteStride',12)))])
 return out
node=lambda name:next(i for i,x in enumerate(g['nodes'])if x.get('name')==name)
def bounds3(points):return[[min(p[k]for p in points)for k in range(3)],[max(p[k]for p in points)for k in range(3)]]
front_nodes=set(descendants(node('vehicle_steer_front')));allpoints=points(world);front=points(front_nodes);static=points(set(world)-front_nodes);body=points(descendants(node('vehicle_body')));pole=points(descendants(node('vehicle_tongue')));pivot=world[node('vehicle_steer_front')];frontbox=bounds3(front);staticbox=bounds3(static)
# All future wheel rotations about their own current axle are bounded by actual
# maximum decoded radial distance, not only the current polygon's angular phase.
wheel_bounds=[]
for name in ['vehicle_wheel_front_left','vehicle_wheel_front_right','vehicle_wheel_rear_left','vehicle_wheel_rear_right']:
 centre=world[node(name)];pp=points(descendants(node(name)));r=max(math.hypot(p[1]-centre[1],p[2]-centre[2])for p in pp);bb=bounds3(pp);bb[0][1]=centre[1]-r;bb[1][1]=centre[1]+r;bb[0][2]=centre[2]-r;bb[1][2]=centre[2]+r;target=frontbox if'front'in name else staticbox
 for k in range(3):target[0][k]=min(target[0][k],bb[0][k]);target[1][k]=max(target[1][k],bb[1][k])
 wheel_bounds.append({'name':name,'actual_max_radius_m':r,'continuous_roll_bounds_m':bb})
# Decode current original horse skin in world space, then metric/source-origin
# conversion and the separately declared standing support quaternion. The pair
# roots below remain an explicitly unaccepted conservative diagnostic hypothesis.
hp=P/'support/read_native_pose.py';spec=importlib.util.spec_from_file_location('T2796_native_horse',hp);d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
import numpy as np
native=np.concatenate([p for _,p in d.points({})]);origin=np.array([.0013648444640481372,-.09537431257051576,-.0034172495824063565]);metric=(native-origin)*.36440688373115426;q=[.0034569299659433193,8.186949270382101e-8,2.3682575088531932e-5,.9999940245193165];x,y,z,w=q;R=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]]);supported=metric@R.T;hb=[supported.min(0).tolist(),supported.max(0).tolist()]
limit=math.radians(8)
def extrema(A,B,low=-limit,high=limit):
 candidates=[low,high];angle=math.atan2(B,A)
 for t in [angle-math.pi,angle,angle+math.pi]:
  if low<=t<=high:candidates.append(t)
 values=[A*math.cos(t)+B*math.sin(t)for t in candidates];return[min(values),max(values)]
def steer_box(bb):
 xx=[];zz=[]
 for x,z in itertools.product([bb[0][0]-pivot[0],bb[1][0]-pivot[0]],[bb[0][2]-pivot[2],bb[1][2]-pivot[2]]):xx+=extrema(x,z);zz+=extrema(z,-x)
 return[[min(xx)+pivot[0],bb[0][1],min(zz)+pivot[2]],[max(xx)+pivot[0],bb[1][1],max(zz)+pivot[2]]]
tongue_pivot=world[node('vehicle_tongue')];pitch_low=-math.asin((.95-.535)/2.75);pitch_box=bounds3(pole);yy=[];zz=[]
for y,z in itertools.product([pitch_box[0][1]-tongue_pivot[1],pitch_box[1][1]-tongue_pivot[1]],[pitch_box[0][2]-tongue_pivot[2],pitch_box[1][2]-tongue_pivot[2]]):yy+=extrema(y,-z,pitch_low,0);zz+=extrema(z,y,pitch_low,0)
pitch_box[0][1]=min(yy)+tongue_pivot[1];pitch_box[1][1]=max(yy)+tongue_pivot[1];pitch_box[0][2]=min(zz)+tongue_pivot[2];pitch_box[1][2]=max(zz)+tongue_pivot[2]
parts=[{'name':'actual static W01 including continuous rear-wheel roll','bounds_m':staticbox},{'name':'actual front running gear and rest pole over continuous±8degree steering and wheel roll','bounds_m':steer_box(frontbox)}]
parts.append({'name':'actual native pole through continuous rest-to-unaccepted-current95cm diagnostic pitch and steering; no hitch-height fit','bounds_m':steer_box(pitch_box)})
for sign in [-1,1]:
 bb=[[hb[0][0]+sign*.8,hb[0][1],hb[0][2]+3.9],[hb[1][0]+sign*.8,hb[1][1],hb[1][2]+3.9]];parts.append({'name':f'unaccepted rigid horse source pair side{sign}, X±.8/Z3.9, continuous front yaw','bounds_m':steer_box(bb)})
union=[[min(p['bounds_m'][0][k]for p in parts)for k in range(3)],[max(p['bounds_m'][1][k]for p in parts)for k in range(3)]];rear=[[p[0],p[1],p[2]+1.175]for p in union];hull=[[-1.75,-1],[1.75,6.8]];margins=[rear[0][0]-hull[0][0],hull[1][0]-rear[1][0],rear[0][2]-hull[0][1],hull[1][1]-rear[1][2]];assert min(margins)>0
proof={'status':'Independent actual native W01 and current source-default rigid-horse steering envelope fits held route box','vehicle_sha256':sha(wg),'actual_all_vertex_bounds_m':bounds3(allpoints),'actual_body_bounds_m':bounds3(body),'actual_rest_pole_bounds_m':bounds3(pole),'actual_front_pivot_m':pivot,'wheel_rotation_bounds':wheel_bounds,'horse_source_sha256':hashlib.sha256(d.B).hexdigest(),'horse_native_reader_sha256':sha(hp),'horse_conversion':'Evaluate native default skin/world, subtract stated source origin, scale.36440688373115426, then declared support quaternion. No old89b sockets or current head/tail/gait sweep inherited.','horse_support_bounds_m':hb,'steering_interval_rad':[-limit,limit],'continuous_method':'Closed-form endpoints and every in-range derivative-zero angle of A*cos(theta)+B*sin(theta) for all conservative source-AABB corners. Includes every interior angle, not steer samples.','parts':parts,'continuous_union_vehicle_root_m':union,'continuous_union_rear_axle_m':rear,'held_route_hull_xz_m':hull,'containment_margins_m':margins,'pole_pitch_interval_rad':[pitch_low,0],'pole_pitch_scope':'Actual rest pole and the old current adapter diagnostic .95m endpoint span are included analytically. The .95m choice remains unaccepted; higher/fitted pitch or changed poles require new bounds. No .95m or1.04m hitch fit is certified.','excluded':['horse animation including current idle head/tail sweep','leading-horse heading during a turn','actual fitted collar/harness/doubletree/traces/reins','seated driver/garments and their motion','vehicle ground pitch/roll and wheel/hoof contact','vertical/overhead obstacle clearance'],'live_activation_allowed':False,'elapsed_seconds':time.monotonic()-start}
(P/'INDEPENDENT-NATIVE-ENVELOPE.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'native_rear_axle_bounds_m':rear,'containment_margins_m':margins,'dry_shoulder_certificates':[{k:v for k,v in c.items()if k in ['road_id','intervals','maximum_certified_crown_drop_m','minimum_continuous_ground_y_m']}for c in certs],'elapsed_seconds':time.monotonic()-start},indent=2))
