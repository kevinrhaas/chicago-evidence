#!/usr/bin/env node
// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import fs from 'node:fs';
const source = fs.readFileSync(new URL('../renderers/web/js/transport-circuit.js', import.meta.url), 'utf8');
const { compileTransportCircuit, createTransportCircuitController, circuitBudgetAdmission } = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const route = JSON.parse(fs.readFileSync(new URL('../data/transport/routes/w01-1835-circuit.json', import.meta.url)));
const make = r => createTransportCircuitController(r ?? route, { id: 'route-test-actor' });
const circuit = compileTransportCircuit(route), distance = (a, b) => Math.hypot(a.e - b.e, a.n - b.n);
const angle = (a, b) => Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b)));
let checks = 0; const check = (message, fn) => { fn(); checks++; console.log(`PASS ${message}`); };
check('the actual closed circuit joins position and tangent, including the lap seam', () => {
  for (let i = 0; i < circuit.pieces.length; i++) {
    const a = circuit.pieceSample(i, circuit.pieces[i].length), b = circuit.pieceSample((i + 1) % circuit.pieces.length, 0);
    assert(distance(a, b) < 1e-8); assert(angle(a.bearing_rad, b.bearing_rad) < 1e-10);
  }
  assert(distance(circuit.sampleDistance(circuit.length_m - 1e-5), circuit.sampleDistance(circuit.length_m + 1e-5)) < 2.1e-5);
  assert(Math.abs(circuit.sampleDistance(circuit.length_m - 1e-5).yaw_rad - circuit.sampleDistance(circuit.length_m + 1e-5).yaw_rad) < 1e-7, 'raw yaw must not wrap at the seam');
  assert.equal(circuit.sampleDistance(circuit.length_m * 100).lap, 100);
});
check('native +Z and compass heading map to world E/−N with signed left curvature', () => {
  for (let i = 0; i < circuit.pieces.length; i++) {
    const p = circuit.pieces[i], s = p.length / 2, a = circuit.pieceSample(i, s), b = circuit.pieceSample(i, s + 1e-4);
    const de = (b.e - a.e) / 1e-4, dn = (b.n - a.n) / 1e-4;
    assert(Math.abs(de - Math.sin(a.yaw_rad)) < 1e-5);
    assert(Math.abs(dn + Math.cos(a.yaw_rad)) < 1e-5);
    assert(Math.abs(Math.atan2(Math.sin(b.yaw_rad - a.yaw_rad), Math.cos(b.yaw_rad - a.yaw_rad)) / 1e-4 - a.curvature_m_inv) < 1e-6);
  }
});
check('large turns or duplicate/nonconvex/consumed corners refuse instead of tightening the steering cap', () => {
  assert.throws(() => make({ ...route, turn_radius_m: 16 }), /steering limit/);
  assert.throws(() => make({ ...route, corners_enu_m: [[0, 0], [0, 0], [90, 90]] }), /duplicate/);
  assert.throws(() => make({ ...route, corners_enu_m: [[0, 0], [90, 90], [0, 90], [90, 0]] }), /convex/);
  assert.throws(() => make({ ...route, corners_enu_m: [[0, 0], [20, 0], [20, 20], [0, 20]] }), /consume/);
});
check('time partition and camera-culling independence preserve the same route/distance', () => {
  const a = make(), b = make(); let x, y;
  for (let i = 0; i < 500; i++) x = a.update(1, { visible: false });
  for (let i = 0; i < 2000; i++) y = b.update(.25, { visible: true });
  assert(distance(x, y) < 1e-9); assert(Math.abs(x.distance_m - y.distance_m) < 1e-9);
  assert.equal(x.id, y.id); assert.equal(x.selection_id, 'route-test-actor');
});
check('moving join speed reaches zero and at-rest steering is continuous and bounded', () => {
  const actor = make();
  // Approach every exact phase boundary using updates of at most one second.
  let prior = actor.sample();
  for (const p of actor.timeline) {
    const target = p.start + p.duration;
    while (actor.sample().simulation_s < target - 1e-7) {
      const state = actor.update(Math.min(.1, target - actor.sample().simulation_s));
      assert(Math.abs(state.steer_rad) <= 8 * Math.PI / 180 + 1e-12);
      assert(Math.abs(state.steer_rad - prior.steer_rad) <= .021);
      if (state.phase === 'steering') assert.equal(state.speed_m_s, 0);
      assert(state.distance_m + 1e-8 >= prior.distance_m); prior = state;
    }
    assert(prior.speed_m_s < 1e-6, `join must stop: ${JSON.stringify(prior)}`);
  }
});
check('pause, blocked crossing and reduced motion freeze, then resume without catch-up', () => {
  const actor = make(); for (let i = 0; i < 30; i++) actor.update(1);
  const before = actor.sample();
  for (const policy of ['paused', 'blocked', 'reducedMotion']) {
    for (let i = 0; i < 5; i++) {
      const held = actor.update(1, { [policy]: true });
      assert.equal(held.distance_m, before.distance_m); assert.equal(held.simulation_s, before.simulation_s);
      assert.equal(held.speed_m_s, 0); assert.equal(held[policy], true); assert.equal(distance(held, before), 0);
      assert.equal(actor.sample()[policy], true, 'separate sample retains the active hold policy');
    }
  }
  const next = actor.update(.01); assert(next.distance_m >= before.distance_m && next.distance_m - before.distance_m <= .0080001);
  for (const dt of [-1, NaN, Infinity, 1.01]) assert.throws(() => actor.update(dt), /delta/);
});
check('caller mutations cannot rewrite a running actor or its compiled geometry', () => {
  const input = structuredClone(route), actor = make(input), before = actor.sample();
  input.wheelbase_m = 900; input.scene = '1904'; input.corners_enu_m[0][0] += 900;
  assert.deepEqual(actor.sample(), before); actor.update(1); assert.equal(actor.sample().scene, '1835');
  assert.throws(() => { actor.circuit.pieces[0].a[0] += 99; }, TypeError);
});
check('a frame straddling a stop yields exact ordered boundary samples, never mixed move/steer increments', () => {
  const actor = make(); let previous = actor.sample(), boundaries = 0;
  for (let i = 0; i < Math.ceil(actor.cycle_duration_s * 2); i++) {
    const frame = actor.update(.5);
    assert(frame.integration_samples.length <= 3);
    boundaries += frame.integration_samples.length - 1;
    for (const sample of frame.integration_samples) {
      const ds = sample.distance_m - previous.distance_m;
      const dy = Math.atan2(Math.sin(sample.yaw_rad - previous.yaw_rad), Math.cos(sample.yaw_rad - previous.yaw_rad));
      if (ds > 1e-10) {
        assert(Math.abs(sample.steer_rad - previous.steer_rad) < 1e-8);
        assert(Math.abs(dy - sample.curvature_m_inv * ds) < 1e-7);
      } else assert(Math.abs(dy) < 1e-10);
      previous = sample;
    }
  }
  assert(boundaries >= 16, 'the complete lap crosses real steering/motion boundaries');
});
check('complete lap returns to the same place and stopped heading without resetting unwrapped travel', () => {
  const actor = make(), begin = actor.sample();
  let left = actor.cycle_duration_s;
  while (left > 1e-8) { const dt = Math.min(left, 1); actor.update(dt); left -= dt; }
  const end = actor.sample();
  assert(distance(begin, end) < 1e-7); assert(angle(begin.bearing_rad, end.bearing_rad) < 1e-10);
  assert(Math.abs(end.distance_m - circuit.length_m) < 1e-7); assert(end.speed_m_s < 1e-6);
});
check('30Hz floating-point phase-boundary samples cannot rewind distance just before a lap', () => {
  const actor = make(); let previous = actor.sample(), crossed = 0;
  for (let i = 0; i < Math.ceil(actor.cycle_duration_s * 30 * 2); i++) {
    for (const state of actor.update(1 / 30).integration_samples) {
      assert(state.distance_m + 1e-10 >= previous.distance_m, 'no sub-ulp modulo seam rewind');
      assert(distance(state, previous) <= state.distance_m - previous.distance_m + 1e-7, 'no geographic seam jump');
      assert(Math.abs(state.yaw_rad - previous.yaw_rad) < .01, 'no raw yaw2pi jump across a piece or lap');
      if (state.lap > previous.lap) crossed++;
      previous = state;
    }
  }
  assert(crossed >= 1);
});
check('unknown hitch/gait/mobile proof cannot admit and historical rendererCalls never become driver units', () => {
  assert.equal(circuitBudgetAdmission().admitted, false);
  const qualification = Object.fromEntries(['route', 'vehicle', 'horseGait', 'harness', 'driver', 'mobile'].map(k => [k, true]));
  const snapshot = { actual: true, units: 'driver_draws', scene: '1835', tier: 'light', viewport: 'mobile', stand: 'same', drawCalls: 7000, triangles: 1100000, textureBytes: 500, geometryBytes: 500, p95FrameMs: 10 };
  const limits = { drawCalls: 7800, triangles: 1190000, textureBytes: 1000, geometryBytes: 1000, p95FrameMs: 20 };
  assert.throws(() => circuitBudgetAdmission({ baseline: { ...snapshot, units: 'rendererCalls' }, candidate: snapshot, limits, qualification }), /driver counter/);
  assert.equal(circuitBudgetAdmission({ baseline: snapshot, candidate: snapshot, limits, qualification }).admitted, true);
  for (const key of Object.keys(limits)) {
    const result = circuitBudgetAdmission({ baseline: snapshot, candidate: { ...snapshot, [key]: limits[key] + 1 }, limits, qualification });
    assert.deepEqual(result.violations, [key]); assert.equal(result.admitted, false);
  }
  assert.throws(() => circuitBudgetAdmission({ baseline: snapshot, candidate: { ...snapshot, tier: 'full' }, limits, qualification }), /same-view/);
});
console.log(`TRANSPORT CIRCUIT ${checks} meaningful behavior controls PASS; no browser, asset, gait or scene acceptance`);
