// SPDX-License-Identifier: GPL-3.0-or-later
// T-2796: metres/ENU, rear-axle reference. No renderer, clock, assets or scene writes.
const finite = Number.isFinite;
const need = (ok, why) => { if (!ok) throw new Error(why); };
const norm = v => Math.hypot(...v);
const sub = (a, b) => [a[0] - b[0], a[1] - b[1]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1];
const cross = (a, b) => a[0] * b[1] - a[1] * b[0];
// Do not add a positive divisor to an already nonnegative remainder: at the
// final sub-ulp before a lap that addition can round to2*period and reset s to0
// while the unwrapped lap is still0. The signed-only branch preserves it.
const mod = (a, b) => { const r = a % b; return r < 0 ? r + b : r; };
const smooth = t => t * t * (3 - 2 * t);

/** Round a simple closed convex road-intersection polygon; reject short/sharp edges.
 * Curvature is positive LEFT in ENU (bearing decreases, model yaw increases).
 * Geometry is C1. The controller below stops and changes steering at rest at each
 * line/arc join; it never presents this curvature step as moving smooth steering.
 */
export function compileTransportCircuit(route) {
  need(route?.schema === 'transport_closed_circuit_v1' && route.units === 'm', 'circuit schema/metres');
  need(route.scene === '1835' && route.reference === 'rear_axle', 'explicit era and rear axle');
  const points = route.corners_enu_m?.map(p => [...p]);
  need(points?.length >= 3 && points.length <= 8 && points.every(p => p.length === 2 && p.every(finite)), '3–8 finite corners');
  const radius = route.turn_radius_m, wheelbase = route.wheelbase_m, limit = route.steer_limit_deg;
  need(finite(radius) && radius > 0 && finite(wheelbase) && wheelbase > 0 && finite(limit) && limit > 0 && limit <= 8, 'bounded steering controls');
  need(Math.atan(wheelbase / radius) <= limit * Math.PI / 180 + 1e-12, 'turn exceeds authored steering limit');
  const count = points.length, bends = [];
  let sign = 0;
  for (let i = 0; i < count; i++) {
    const corner = points[i], a = sub(corner, points[(i + count - 1) % count]), b = sub(points[(i + 1) % count], corner);
    need(norm(a) > 0 && norm(b) > 0, 'duplicate corners');
    const u = a.map(x => x / norm(a)), v = b.map(x => x / norm(b));
    const turn = Math.atan2(cross(u, v), dot(u, v));
    need(Math.abs(turn) > 1e-6 && Math.abs(turn) < Math.PI - 1e-6, 'degenerate turn');
    const direction = Math.sign(turn); sign ||= direction;
    need(direction === sign, 'first circuit must be convex');
    const tangent = radius * Math.tan(Math.abs(turn) / 2);
    const entry = corner.map((x, j) => x - u[j] * tangent), exit = corner.map((x, j) => x + v[j] * tangent);
    const centre = [entry[0] - direction * u[1] * radius, entry[1] + direction * u[0] * radius];
    bends.push({ entry, exit, centre, turn, tangent, startAngle: Math.atan2(entry[1] - centre[1], entry[0] - centre[0]) });
  }
  // Convexity alone does not reject a star ordering; each nonadjacent corner
  // must lie on the same side of every boundary edge.
  for (let i = 0; i < count; i++) {
    const edge = sub(points[(i + 1) % count], points[i]);
    for (let j = 0; j < count; j++) need(sign * cross(edge, sub(points[j], points[i])) >= -1e-8, 'self-intersecting/nonconvex circuit');
    need(norm(edge) > bends[i].tangent + bends[(i + 1) % count].tangent + 1, 'turns consume road edge');
  }
  const pieces = [];
  const line = (a, b) => {
    const d = sub(b, a), length = norm(d); need(length > 1e-8, 'zero line');
    pieces.push(Object.freeze({ kind: 'line', a: Object.freeze(a), tangent: Object.freeze(d.map(x => x / length)), length, curvature: 0 }));
  };
  const start = bends[0].entry.map((v, j) => (v + bends.at(-1).exit[j]) / 2);
  line(start, bends[0].entry);
  for (let i = 0; i < count; i++) {
    const b = bends[i];
    pieces.push(Object.freeze({ kind: 'arc', centre: Object.freeze(b.centre), radius, startAngle: b.startAngle,
      turn: b.turn, length: radius * Math.abs(b.turn), curvature: Math.sign(b.turn) / radius }));
    line(b.exit, i === count - 1 ? [...start] : bends[i + 1].entry);
  }
  const length = pieces.reduce((sum, p) => sum + p.length, 0);
  const yawStarts = []; let yaw = Math.PI - Math.atan2(pieces[0].tangent[0], pieces[0].tangent[1]);
  for (const p of pieces) { yawStarts.push(yaw); yaw += p.curvature * p.length; }
  const totalTurn = yaw - yawStarts[0];
  function pieceSample(index, s) {
    const p = pieces[index]; let e, n, tangent;
    if (p.kind === 'line') { [e, n] = p.a.map((v, j) => v + p.tangent[j] * s); tangent = p.tangent; }
    else {
      const angle = p.startAngle + Math.sign(p.turn) * s / p.radius;
      e = p.centre[0] + p.radius * Math.cos(angle); n = p.centre[1] + p.radius * Math.sin(angle);
      tangent = [-Math.sign(p.turn) * Math.sin(angle), Math.sign(p.turn) * Math.cos(angle)];
    }
    const bearing = Math.atan2(tangent[0], tangent[1]);
    return { e, n, bearing_rad: bearing, bearing_deg: mod(bearing * 180 / Math.PI, 360),
      yaw_rad: yawStarts[index] + p.curvature * s, curvature_m_inv: p.curvature, steer_rad: Math.atan(wheelbase * p.curvature), piece: index };
  }
  function sampleDistance(distance) {
    need(finite(distance) && distance >= 0, 'nonnegative finite distance');
    let s = mod(distance, length), index = 0;
    while (index < pieces.length - 1 && s >= pieces[index].length) s -= pieces[index++].length;
    const lap = Math.floor(distance / length), pose = pieceSample(index, s);
    return { ...pose, yaw_rad: pose.yaw_rad + lap * totalTurn, distance_m: distance, lap_distance_m: mod(distance, length), lap };
  }
  return Object.freeze({ length_m: length, turn_rad: totalTurn, pieces: Object.freeze(pieces), sampleDistance, pieceSample });
}

/** Analytic, partition-independent repeating controller. Root motion never depends
 * on camera visibility or animation LOD. No scene activation or admission implied.
 * Every join stops before steering; the lap seam is on a straight and has no
 * positional/heading jump. Pause/reduced motion freeze the same simulation time.
 */
export function createTransportCircuitController(route, { id } = {}) {
  need(typeof id === 'string' && id.length > 0, 'stable actor ID required');
  route = { ...route }; // Subsequent caller metadata edits cannot change a running actor.
  const circuit = compileTransportCircuit(route);
  const { speed_m_s: speed, acceleration_m_s2: acceleration, steering_settle_s: settle, lap_pause_s: pause } = route;
  need(finite(speed) && speed > 0 && speed <= 1.5 && finite(acceleration) && acceleration > 0 && acceleration <= 0.5, 'bounded walking motion');
  need(finite(settle) && settle >= 1 && settle <= 5 && finite(pause) && pause >= 0 && pause <= 30, 'bounded steering/pause durations');
  const timeline = []; let clock = 0, travelled = 0;
  const add = p => { p.start = clock; clock += p.duration; timeline.push(Object.freeze(p)); };
  if (pause) add({ kind: 'dwell', duration: pause, distance: 0, piece: 0, curvature: 0 });
  for (let i = 0; i < circuit.pieces.length; i++) {
    const p = circuit.pieces[i], previous = circuit.pieces[mod(i - 1, circuit.pieces.length)];
    if (previous.curvature !== p.curvature) add({ kind: 'steering', duration: settle, distance: travelled,
      piece: i, fromSteer: Math.atan(route.wheelbase_m * previous.curvature), toSteer: Math.atan(route.wheelbase_m * p.curvature) });
    const ramp = Math.min(speed / acceleration, Math.sqrt(p.length / acceleration));
    const peak = acceleration * ramp, cruise = Math.max(0, (p.length - acceleration * ramp * ramp) / peak);
    add({ kind: 'moving', duration: 2 * ramp + cruise, distance: travelled, piece: i, ramp, peak, cruise, length: p.length });
    travelled += p.length;
  }
  let elapsed = 0, policy = { paused: false, reducedMotion: false, blocked: false };
  function sampleAt(at, { paused, reducedMotion, blocked } = policy) {
    const lap = Math.floor(at / clock), t = mod(at, clock);
    const phase = timeline.find(p => t < p.start + p.duration) ?? timeline.at(-1), u = t - phase.start;
    let distance = phase.distance, velocity = 0, offset = 0;
    let steer = Math.atan(route.wheelbase_m * circuit.pieces[phase.piece].curvature);
    if (phase.kind === 'moving') {
      if (u < phase.ramp) { offset = acceleration * u * u / 2; velocity = acceleration * u; }
      else if (u < phase.ramp + phase.cruise) { offset = acceleration * phase.ramp ** 2 / 2 + phase.peak * (u - phase.ramp); velocity = phase.peak; }
      else { const left = Math.max(0, phase.duration - u); offset = phase.length - acceleration * left * left / 2; velocity = acceleration * left; }
      distance += offset;
    } else if (phase.kind === 'steering') steer = phase.fromSteer + (phase.toSteer - phase.fromSteer) * smooth(u / phase.duration);
    const pose = circuit.pieceSample(phase.piece, offset);
    return { ...pose, yaw_rad: pose.yaw_rad + lap * circuit.turn_rad, id, selection_id: id, scene: route.scene, reference: 'rear_axle',
      simulation_s: at, distance_m: lap * circuit.length_m + distance, lap_distance_m: distance, lap,
      curvature_m_inv: Math.tan(steer) / route.wheelbase_m, steer_rad: steer,
      path_curvature_m_inv: circuit.pieces[phase.piece].curvature,
      speed_m_s: paused || reducedMotion || blocked ? 0 : velocity,
      phase: phase.kind, paused, reducedMotion, blocked };
  }
  const sample = () => sampleAt(elapsed);
  return Object.freeze({ circuit, cycle_duration_s: clock, timeline: Object.freeze(timeline), sample,
    update(dt, options = {}) {
      need(finite(dt) && dt >= 0 && dt <= 1, 'delta must be finite in [0,1]; hidden-tab catchup must not teleport');
      for (const key of ['paused', 'reducedMotion', 'blocked']) need(options[key] === undefined || typeof options[key] === 'boolean', 'boolean motion policy');
      policy = { paused: options.paused ?? false, reducedMotion: options.reducedMotion ?? false, blocked: options.blocked ?? false };
      const before = elapsed, samples = [];
      if (!policy.paused && !policy.reducedMotion && !policy.blocked) elapsed += dt;
      // A frame can straddle braking/steering. Preserve exact stop boundaries for
      // wheel/hitch integration: never merge ds>0 and steering-at-rest into one
      // approximate mixed increment. <=1s input bounds this tiny list.
      for (let lap = Math.floor(before / clock); lap <= Math.floor(elapsed / clock); lap++) for (const phase of timeline) {
        const boundary = lap * clock + phase.start + phase.duration;
        if (boundary > before && boundary < elapsed) samples.push(sampleAt(boundary));
      }
      const state = sample(); samples.push(state);
      return { ...state, integration_samples: samples };
    } });
}

/** No historic90-call rendererCalls value is converted to the current driver
 * counter. Caller supplies unchanged actual app ceilings in the SAME units.
 * Unknown coupled-team/driver/harness/phone costs fail closed; no geometry loads.
 */
export function circuitBudgetAdmission({ baseline, candidate, limits, qualification } = {}) {
  const required = ['route', 'vehicle', 'horseGait', 'harness', 'driver', 'mobile'];
  if (!required.every(k => qualification?.[k] === true)) return { admitted: false, reason: 'unqualified coupled actor', missing: required.filter(k => qualification?.[k] !== true) };
  need(baseline?.actual === true && candidate?.actual === true && baseline.units === 'driver_draws' && candidate.units === baseline.units, 'actual driver counter receipts required');
  need(['scene', 'tier', 'viewport', 'stand'].every(k => baseline[k] && baseline[k] === candidate[k]), 'same-view/tier baseline required');
  const keys = ['drawCalls', 'triangles', 'textureBytes', 'geometryBytes', 'p95FrameMs'];
  need(keys.every(k => finite(baseline[k]) && baseline[k] >= 0 && finite(candidate[k]) && candidate[k] >= 0 && finite(limits?.[k]) && limits[k] >= 0), 'actual whole-frame phone memory/timing/GL ceilings required');
  const violations = keys.filter(k => candidate[k] > limits[k]);
  return { admitted: violations.length === 0, violations, scope: 'Caller actual whole-frame measurements; no reserved budget or photographic acceptance' };
}
