from pathlib import Path
import shutil,difflib,json,hashlib
out=Path(__file__).resolve().parent;old=Path('/workspace/shared/HORSE-IDLE-YARD-SMOKE-PREPARED-20261022');s=(old/'capture_smoke.mjs').read_text();baseline=s
needle="  // Observe the ordinary production host clock, not a synthetic mixer or direct pose assignment."
assert s.count(needle)==1
instrument=r'''  // DIAGNOSTIC ONLY: transparent forwarding of the existing production layer.update.
  // Never changes dt, options, return value, curves, camera, rendering or test thresholds.
  report.idle_diagnostic_before=await page.evaluate(()=>{
   const a=window.__chicago4d,layer=a.standingHorses,i=layer.instances[0],original=layer.update;
   const start=performance.now(),initial=i.idle.status,rows=[],counts={calls:0,positive_dt_calls:0,forwarded_dt_sum_s:0,maximum_forwarded_dt_s:0,eligible_dt_sum_s:0,paused_calls:0,reduced_calls:0,hidden_document_calls:0,invisible_calls:0};
   const ancestry=()=>{const nodes=[];for(let n=layer.group;n;n=n.parent)nodes.push({name:n.name||n.type,visible:n.visible});return nodes;};
   const state=()=>{const chain=ancestry(),media=matchMedia('(prefers-reduced-motion: reduce)').matches,distance=a.camera.getWorldPosition(a.camera.position.clone()).distanceTo(i.group.position),reach={full:70,balanced:40,light:0}[a.detail]??0;return{elapsed_s:i.idle.status.elapsed_s,idle:i.idle.status,document_hidden:document.hidden,visibility_state:document.visibilityState,document_has_focus:document.hasFocus(),media_reduce:media,instance_visible:i.group.visible,ancestor_visibility:chain,confidence_hidden_reconstructed:Boolean(a.confidence.hidden.reconstructed),distance_m:distance,reach_m:reach,within_reach:distance<reach,welcome_state:a.welcome.state,gate_dom_hidden:document.getElementById('gate')?.hidden??null,renderer_frame:a.renderer.info.render.frame??null,rounded_fps:a.stats().fps,governor:a.governor};};
   const observed=function(...args){const before=i.idle.status.elapsed_s,dt=Number(args[1]??0),opts=args[2]??{};const result=original.apply(this,args);const st=state(),visible=st.instance_visible&&!st.document_hidden&&st.ancestor_visibility.every(n=>n.visible),reduced=opts.reducedMotion??st.media_reduce,paused=opts.paused??false;
    counts.calls++;counts.positive_dt_calls+=Number(dt>0);counts.forwarded_dt_sum_s+=dt;counts.maximum_forwarded_dt_s=Math.max(counts.maximum_forwarded_dt_s,dt);counts.eligible_dt_sum_s+=!paused&&!reduced&&visible?dt:0;counts.paused_calls+=Number(paused);counts.reduced_calls+=Number(reduced);counts.hidden_document_calls+=Number(st.document_hidden);counts.invisible_calls+=Number(!visible);
    rows.push({at_ms:performance.now()-start,forwarded_host_dt_s:dt,paused_argument:paused,reduced_motion_argument:opts.reducedMotion??null,effective_reduced_motion_from_public_media:reduced,visible,elapsed_before_s:before,elapsed_after_s:st.elapsed_s,renderer_frame:st.renderer_frame,document_hidden:st.document_hidden,media_reduce:st.media_reduce,distance_m:st.distance_m,reach_m:st.reach_m});if(rows.length>32)rows.shift();return result;};
   layer.update=observed;
   const snapshot=()=>({wall_ms:performance.now()-start,initial_status:initial,current:state(),counts:{...counts},last32_updates:rows.slice(),scope:'Observed production-layer forwarded dt; not raw private THREE.Clock delta. No arguments/poses/source mutated.'});
   window.__horseIdleYardDiagnostic={snapshot,restore(){if(layer.update===observed)layer.update=original;}};
   return snapshot();
  });
'''
s=s.replace(needle,instrument+needle)
wait="  await page.waitForFunction(()=>{const o=window.__horseIdleYardObservation,i=window.__chicago4d.standingHorses.instances[0];return i.idle.status.elapsed_s-o.before.elapsed>=1.5;},null,{timeout:15000,polling:100});"
assert s.count(wait)==1
s=s.replace(wait,"  try{\n"+wait+"\n  }catch(error){report.idle_timeout_diagnostic=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());throw error;}\n  report.idle_diagnostic_after_wait=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());")
s=s.replace("  report.teardown=await page.evaluate(async()=>{", "  await page.evaluate(()=>window.__horseIdleYardDiagnostic?.restore());\n  report.teardown=await page.evaluate(async()=>{")
s=s.replace(" if(browser)await browser.close();", " if(page&&!page.isClosed()){try{await page.evaluate(()=>window.__horseIdleYardDiagnostic?.restore());}catch{}}\n if(browser)await browser.close();")
(out/'capture_smoke.mjs').write_text(s);shutil.copy2(old/'run_owned.py',out/'run_owned.py')
(out/'DIAGNOSTIC-ONLY.patch').write_text(''.join(difflib.unified_diff(baseline.splitlines(True),s.splitlines(True),fromfile='immutable9b7325cd/capture_smoke.mjs',tofile='diagnosticV2/capture_smoke.mjs')))
# Existing releases record an already executed attempt. New templates are explicitly HELD.
for phase in ['yard-desktop','yard-mobile']:
 j=json.loads(Path('/workspace/shared/HORSE-IDLE-fde6-YARD-RELEASED-20261022',phase+'-ROOT-RELEASE.json').read_text());j['released']=False;j['browser_lane_free']=False
 for name in ['capture_smoke.mjs','run_owned.py']:
  j['expected_files'].pop(str(old/name));j['expected_files'][str(out/name)]=hashlib.sha256((out/name).read_bytes()).hexdigest()
 j['note']='HELD diagnostic-only caller revision. Sourcefde6/tree8da/pins unchanged. Root must separately release ONE freshdesktop diagnostic after personPR1175 gate4. Exact cameras/assertions/15s bound/360s owned cap retained; original failure remainsimmutable. No automatic retry or mobile.'
 (out/(phase+'-RELEASE-HELD.json')).write_text(json.dumps(j,indent=2)+'\n')
