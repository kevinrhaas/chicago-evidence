HELD diagnostic-only revision for pushed horsefde6/tree8da. No app edit, browser, gate or model generation occurred. Original failed desktop/PNGs and immutable9b7325cd caller remain preserved.

This copies the existing caller/wrapper and adds transparent observation around the production standingHorses.update: original arguments/receiver/result are forwarded unchanged; telemetry counts calls, forwarded dt totals/max, eligible visibility/media/pause delta, current idle elapsed and last32calls. A timeout now records the actual current elapsed, forwarded dt, rounded FPS, renderer frame counter, document.hidden/visibilityState/hasFocus, media reduce, all ancestor visibility, reconstructed-confidence flag, measured distance/reach, welcome state and gate DOM hidden flag. The hook is restored before teardown and in finally. It does not expose the private raw THREE.Clock delta; forwarded host dt is labeled accurately. No fake update, phase, pose, camera movement, media setting, scale or render option is injected beyond the original caller's actions.

The exact original15s wait/1.5s owned-elapsed assertion remains, together with original cameras, all source/indexed-vertex .97/contact/cache/coarse/budget/card/disposal assertions and360/350s owned caps. Both new release templates arefalse. Root must separately release one fresh desktop diagnostic after personPR1175gate4. Mobile and all retries remainheld.

The actual prior source still provides no reason to edit app code. Each drawn host frame contributes at most.25s; the measured instance has.5750385086s initial restdelay/.9802204318rate, so1.5s animation progress needs2.10530655eligiblehostseconds, at least9eligible drawnframes. Both static captures reported roundedFPS0. Slow software rendering therefore plausibly explains the15wallsecond failure, but the old receipt cannot exclude paused/hidden/media/ancestor/gate defects. Nothing has yet proved which applies. Page focus/visibility and real forwarded deltas must be observed before changing source or test semantics.

For a separately root-released desktop, use the same command form:

    python3 /workspace/shared/HORSE-IDLE-YARD-DIAGNOSTIC-V2-HELD-20261022/run_owned.py \
      --lane-released --phase yard-desktop \
      --release-file /workspace/shared/HORSE-IDLE-DIAGNOSTIC-V2-DESKTOP-ROOT-RELEASED.json \
      --output-dir /workspace/shared/HORSE-IDLE-DIAGNOSTIC-V2-DESKTOP-ACTUAL-20261022

Root copies the held release to that separate released path only on lane release. No automatic attempt has run. Interpret a low eligible sum as insufficient observed host time, paused/hidden/media counters as their actual scope, and eligible sum beyond restdelay+1.5/rate without corresponding elapsed as a source/runtime discrepancy. Preserve the full failed result either way; no criterion is relaxed here.
