"""Actual serialized rest triangle-plane contours; never edits frozen first rig."""
import hashlib,json,pathlib,time
import numpy as np
from actual_model import Model
P=pathlib.Path(__file__).resolve().parent
F=pathlib.Path('/workspace/shared/T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb')
start=time.monotonic();m=Model(F);assert hashlib.sha256(m.raw).hexdigest()=='03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36'
control=json.loads(pathlib.Path('/workspace/shared/T2803-native-rerig-fallback-20261022/RERIG-CONTROLS-PROPOSAL.json').read_text())
tri=[]
for ni in [26,27,28]:
 points,*_,pr=m.mesh(ni);tri.append(points[m.accessor(pr['indices']).astype(int).reshape(-1,3)])
tri=np.concatenate(tri)
def loops(y):
 segments=[]
 for t in tri[np.logical_and(tri[:,:,1].min(1)<y,tri[:,:,1].max(1)>y)]:
  hits=[]
  for a,b in [(0,1),(1,2),(2,0)]:
   da,db=t[a,1]-y,t[b,1]-y
   if da*db<0:hits.append((t[a]+da/(da-db)*(t[b]-t[a]))[[0,2]])
  if len(hits)==2:segments.append(hits)
 points={};adj={};quant=1e-5
 for a,b in segments:
  ka,kb=[tuple(np.rint(v/quant).astype(int))for v in [a,b]]
  if ka==kb:continue
  points[ka]=a;points[kb]=b;adj.setdefault(ka,set()).add(kb);adj.setdefault(kb,set()).add(ka)
 remaining=set(adj);polys=[];unclosed=0
 while remaining:
  todo=[remaining.pop()];component=[]
  while todo:
   k=todo.pop();component.append(k)
   for nxt in adj[k]:
    if nxt in remaining:remaining.remove(nxt);todo.append(nxt)
  if not all(len(adj[k])==2 for k in component):unclosed+=1;continue
  first=component[0];order=[first];prev=None;cur=first
  while True:
   nxt=next(n for n in adj[cur]if n!=prev)
   if nxt==first:break
   order.append(nxt);prev,cur=cur,nxt
   assert len(order)<=len(component)
  assert len(order)==len(component)
  polys.append(np.array([points[k]for k in order]))
 return polys,unclosed
def containment(p,poly):
 a=poly;b=np.roll(poly,-1,axis=0);d=b-a;t=np.clip(np.einsum('ni,ni->n',p-a,d)/np.einsum('ni,ni->n',d,d),0,1);distance=np.linalg.norm(p-a-t[:,None]*d,axis=1).min()
 crossings=((a[:,1]>p[1])!=(b[:,1]>p[1]))&(p[0]<((b[:,0]-a[:,0])*(p[1]-a[:,1])/(b[:,1]-a[:,1]+1e-300)+a[:,0]))
 return bool(np.count_nonzero(crossings)%2),float(distance)
rows=[];new=json.loads(json.dumps(control));new['schema']='host_specific_reconstructed_horse_rig_proposal_v2_section_correction';new['status']='SOURCE PROPOSAL ONLY; corrected actual section containment evidence, no new export or gait acceptance'
for node in new['nodes']:
 if node['index']<6 or node['index']in [6,11,16,21]:continue
 xyz=np.array(node['rest_world_pivot_m']);polys,unclosed=loops(xyz[1]);candidates=[p for p in polys if p[:,0].mean()*np.sign(xyz[0])>.04 and p[:,1].mean()*np.sign(xyz[2])>.08 and np.ptp(p[:,0])<.4 and np.ptp(p[:,1])<.52]
 assert candidates,node['name'];poly=min(candidates,key=lambda p:np.linalg.norm(p.mean(0)-xyz[[0,2]]));inside,margin=containment(xyz[[0,2]],poly)
 row={'node':node['index'],'name':node['name'],'pivot_m':xyz.tolist(),'height_m':float(xyz[1]),'closed_ordered_contour_vertices':len(poly),'actual_inside_closed_polygon':inside,'distance_to_contour_m':margin,'wirepoint_mean_xz_m':poly.mean(0).tolist(),'distance_to_wirepoint_mean_m':float(np.linalg.norm(poly.mean(0)-xyz[[0,2]])),'contour_xz_m':poly.tolist(),'unclosed_other_components':unclosed};rows.append(row)
 node['basis']='Reconstructed hidden joint, NOT anatomical measurement. Actual closed triangle-plane contour containment: '+('inside'if inside else'OUTSIDE')+f'; nearest contour distance {margin:.9f}m. See SECTION-CONTAINMENT.json. Prior first-artifact metadata only justified section AABB containment.'
out={'status':'ACTUAL CLOSED-SECTION TEST COMPLETE; failed containment is preserved','original_source_sha256':control['original_host_source_sha256'],'actual_rig_sha256':hashlib.sha256(m.raw).hexdigest(),'claim_correction':'Original inside actual measured plane contour text exceeded prior proof. Prior proof was section AABB containment only. This independent test uses ordered closed contours and point-in-polygon, not bounding boxes or wire means. Hidden anatomical axes remain reconstructed even when inside.','endpoint_welding_tolerance_m':1e-5,'all_actual_triangles':len(tri),'rows':rows,'outside_names':[r['name']for r in rows if not r['actual_inside_closed_polygon']],'elapsed_seconds':time.monotonic()-start,'first_artifact_unchanged':True}
(P/'SECTION-CONTAINMENT.json').write_text(json.dumps(out,indent=2)+'\n');(P/'RERIG-CONTROLS-PROPOSAL-V2.json').write_text(json.dumps(new,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='rows'}));print(json.dumps([{k:v for k,v in r.items()if k!='contour_xz_m'}for r in rows],indent=2))
