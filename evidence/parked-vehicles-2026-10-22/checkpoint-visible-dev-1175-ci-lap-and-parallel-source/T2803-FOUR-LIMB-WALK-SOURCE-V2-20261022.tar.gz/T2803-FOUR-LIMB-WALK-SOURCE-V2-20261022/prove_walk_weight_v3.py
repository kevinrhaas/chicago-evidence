"""Bounded actual serialized-skin CPU counterfactual; no GLB/animation export."""
import hashlib,json,pathlib,time,math
import numpy as np
from actual_model import Model
from walk_source import pose,PARAMETERS as PARAM,THRESHOLDS as LIMIT
P=pathlib.Path(__file__).resolve().parent;start=time.monotonic()
F=pathlib.Path('/workspace/shared/T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb');m=Model(F);assert hashlib.sha256(m.raw).hexdigest()=='03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36';assert not m.g.get('animations')
controls=json.loads((P/'RERIG-CONTROLS-PROPOSAL-V2.json').read_text());side=json.loads(pathlib.Path('/workspace/shared/horse-standing-intake-proposal-V2-20261022/proposed/data/transport/parked/horse-sevket-sidecar.json').read_text());piv=np.array([m.world(i)[:3,3]for i in range(26)]);ib=m.accessor(m.g['skins'][0]['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1);parents=[n['parent_index']for n in controls['nodes']];limbs=controls['limbs']
parts=[];rest=[];edges=[];baseareas=[];basenorm=[]
for ni in [26,27,28]:
 node=m.g['nodes'][ni];pr=m.g['meshes'][node['mesh']]['primitives'][0];a=pr['attributes'];pos=m.accessor(a['POSITION']).astype(float);normal=m.accessor(a['NORMAL']).astype(float);joint=m.accessor(a['JOINTS_0']).astype(int);weight=m.accessor(a['WEIGHTS_0']).astype(float);ix=m.accessor(pr['indices']).astype(int).reshape(-1,3);points=m.mesh(ni)[0];parts.append((pos,normal,joint,weight,ix));rest.append(points);tris=points[ix];edges.append(np.linalg.norm(tris[:,[1,2,0]]-tris[:,[0,1,2]],axis=2));norm=np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0]);basenorm.append(norm);baseareas.append(np.linalg.norm(norm,axis=1))
patch={label:np.unique(parts[1][4][row['source_triangle_ids']].ravel())for label,row in side['contacts'].items()};hoof_min={label:float(rest[1][ids,1].min())for label,ids in patch.items()};assert {k:len(v)for k,v in patch.items()}=={'fore_l':59,'fore_r':59,'hind_l':13,'hind_r':10}
for label,ids in patch.items():
 own=limbs[label]['joints'][-1];j,w=parts[1][2:4];assert np.all(np.where(j[ids]==own,w[ids],0).sum(1)==1)
from weight_proposal_v3 import weights_for_mesh
for mi,(pos,nor,j,w,ix) in enumerate(parts):
 force={}
 if mi==1:
  for label,ids in patch.items():
   for vi in ids:force[int(vi)]=label
 jj,ww=weights_for_mesh(rest[mi],j,w,controls,force);parts[mi]=(pos,nor,jj.astype(int),ww.astype(float),ix)
# One common representative per actual source position avoids material-seam weight cracks.
shared={}
for mi,(pos,nor,j,w,ix) in enumerate(parts):
 for vi,point in enumerate(rest[mi]):
  key=tuple(np.rint(point/1e-6).astype(int))
  if key in shared:j[vi],w[vi]=shared[key]
  else:shared[key]=(j[vi].copy(),w[vi].copy())
def skin(matrices):
 transforms=matrices@ib;out=[];normals=[]
 for pos,nor,j,w,_ in parts:
  blend=np.einsum('nw,nwij->nij',w,transforms[j]);out.append(np.einsum('nij,nj->ni',blend,np.c_[pos,np.ones(len(pos))])[:,:3]);n=np.einsum('nij,nj->ni',blend,np.c_[nor,np.zeros(len(nor))])[:,:3];n/=np.linalg.norm(n,axis=1)[:,None];normals.append(n)
 return out,normals
seamclass={}
for mi,points in enumerate(rest):
 for vi,p in enumerate(points):seamclass.setdefault(tuple(np.rint(p/1e-6).astype(int)),[]).append((mi,vi))
seams=[v for v in seamclass.values()if len(v)>1];seampairs=[((v[0][0],v[0][1]),(a,b))for v in seams for a,b in v[1:]]
surface=[{'mesh':i,'vertices':len(r),'triangles':len(parts[i][4]),'edge_ratio_min':1.,'edge_ratio_max':1.,'area_ratio_min':1.,'area_ratio_max':1.,'max_rest_relative_normal_dot_negative_count':0,'minimum_y_m':1e9}for i,r in enumerate(rest)];stance={k:{'vertices':len(v),'stance_samples':0,'world_patch_drift_m':0.,'target_residual_m':0.,'minimum_swing_patch_y_m':1e9,'max_swing_patch_min_y_m':0.}for k,v in patch.items()};anchors={};length_error=parent_error=seamgap=0.;finite=True;reach=1e9;frames=[];contact_centers=[]
times=np.linspace(0,PARAM['period_s'],65)
for t in times:
 matrices,states=pose(float(t),piv,limbs,hoof_min);moved,normals=skin(matrices);route=np.array([0.,0.,PARAM['nominal_speed_m_s']*t]);finite=finite and all(np.isfinite(p).all()and np.isfinite(n).all()for p,n in zip(moved,normals));frames.append({'time_s':float(t),'global_body_frame_matrices':matrices.tolist(),'limb_states':states})
 for label,row in limbs.items():
  ids=row['joints'];reach=min(reach,states[label]['reach_margin_m'])
  for a,b in zip(ids[:-1],ids[1:]):length_error=max(length_error,abs(np.linalg.norm(matrices[b,:3,3]-matrices[a,:3,3])-np.linalg.norm(piv[b]-piv[a])));expected=matrices[a,:3,3]+matrices[a,:3,:3]@(piv[b]-piv[a]);parent_error=max(parent_error,float(np.linalg.norm(matrices[b,:3,3]-expected)))
  pts=moved[1][patch[label]]+route;row=stance[label];st=states[label];row['stance_samples']+=int(st['stance'])
  if st['stance']:
   cycle=math.floor(t/PARAM['period_s']+PARAM['phase_offsets'][label]);key=(label,cycle);anchor=anchors.setdefault(key,pts.copy());row['world_patch_drift_m']=max(row['world_patch_drift_m'],float(np.linalg.norm(pts-anchor,axis=1).max()));expected=rest[1][patch[label]]+np.array([0.,-hoof_min[label],PARAM['stride_m']*(PARAM['stance_fraction']/2-PARAM['phase_offsets'][label]+cycle)]);row['target_residual_m']=max(row['target_residual_m'],float(np.linalg.norm(pts-expected,axis=1).max()))
  else:row['minimum_swing_patch_y_m']=min(row['minimum_swing_patch_y_m'],float(pts[:,1].min()));row['max_swing_patch_min_y_m']=max(row['max_swing_patch_min_y_m'],float(pts[:,1].min()))
 for mi,points in enumerate(moved):
  s=surface[mi];ix=parts[mi][4];tri=points[ix];edge=np.linalg.norm(tri[:,[1,2,0]]-tri[:,[0,1,2]],axis=2);valid=edges[mi]>1e-8;ratio=edge[valid]/edges[mi][valid];s['edge_ratio_min']=min(s['edge_ratio_min'],float(ratio.min()));s['edge_ratio_max']=max(s['edge_ratio_max'],float(ratio.max()));norm=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);area=np.linalg.norm(norm,axis=1);v=baseareas[mi]>1e-12;rat=area[v]/baseareas[mi][v];s['area_ratio_min']=min(s['area_ratio_min'],float(rat.min()));s['area_ratio_max']=max(s['area_ratio_max'],float(rat.max()));s['max_rest_relative_normal_dot_negative_count']=max(s['max_rest_relative_normal_dot_negative_count'],int(np.count_nonzero((np.einsum('ni,ni->n',basenorm[mi],norm)<0)&v)));s['minimum_y_m']=min(s['minimum_y_m'],float(points[:,1].min()))
 for (ma,va),(mb,vb) in seampairs:seamgap=max(seamgap,float(np.linalg.norm(moved[ma][va]-moved[mb][vb])))
first,_=pose(0.,piv,limbs,hoof_min);last,_=pose(PARAM['period_s'],piv,limbs,hoof_min);looppos=float(np.abs(first[:,:3,3]-last[:,:3,3]).max());looprot=float(np.abs(first[:,:3,:3]-last[:,:3,:3]).max());root_loop_distance=PARAM['period_s']*PARAM['nominal_speed_m_s']
# Meaningful corruptions evaluated by the same metric definitions.
slipping=PARAM['nominal_speed_m_s']*PARAM['period_s']*PARAM['stance_fraction'];bad=first.copy();bad[10,1,3]+=.003;length_control=abs(np.linalg.norm(bad[10,:3,3]-bad[9,:3,3])-np.linalg.norm(piv[10]-piv[9]));loop_control=float(np.abs(first[:,:3,3]-bad[:,:3,3]).max())
mechanics=finite and length_error<=LIMIT['segment_length_error_m']and parent_error<=LIMIT['segment_length_error_m']and looppos<=LIMIT['loop_position_m']and looprot<=LIMIT['loop_rotation_matrix_abs']and all(r['world_patch_drift_m']<=LIMIT['stance_patch_drift_m']and r['target_residual_m']<=LIMIT['stance_patch_drift_m']for r in stance.values())
deformation=all(r['edge_ratio_min']>=LIMIT['minimum_triangle_edge_ratio']and r['edge_ratio_max']<=LIMIT['maximum_triangle_edge_ratio']and r['area_ratio_min']>=LIMIT['minimum_triangle_area_ratio']and r['area_ratio_max']<=LIMIT['maximum_triangle_area_ratio']and r['max_rest_relative_normal_dot_negative_count']==0 and r['minimum_y_m']>=LIMIT['minimum_all_surface_y_m']for r in surface)and seamgap<=LIMIT['minimum_seam_gap_tolerance_m']
result={'status':'DRAFT WALK MECHANICS PASS; DEFORMATION UNACCEPTED'if mechanics and not deformation else'DRAFT SOURCE CONTROL RESULT','source_sha256':controls['original_host_source_sha256'],'actual_rig_sha256':hashlib.sha256(m.raw).hexdigest(),'weight_proposal_sha256':hashlib.sha256((P/'weight_proposal_v3.py').read_bytes()).hexdigest(),'walk_source_sha256':hashlib.sha256((P/'walk_source.py').read_bytes()).hexdigest(),'parameters_frozen_before_run':PARAM,'thresholds_frozen_before_run':LIMIT,'actual_evaluation':{'poses_inclusive':len(times),'vertices_per_pose':sum(len(r)for r in rest),'full_vertex_position_and_normal_samples':len(times)*sum(len(r)for r in rest),'triangles_per_pose':sum(len(r[4])for r in parts),'all_finite':finite,'maximum_segment_length_error_m':length_error,'maximum_parent_chain_residual_m':parent_error,'minimum_IK_reach_margin_m':reach,'loop_position_error_m':looppos,'loop_rotation_matrix_abs_error':looprot,'route_root_advance_per_loop_m':root_loop_distance,'maximum_seam_gap_m':seamgap},'annotated_hoof_patches_only':stance,'surfaces':surface,'controls':{'naive_rest_hoofs_plus_moving_body_stance_slip_m':slipping,'three_mm_hoof_only_translation_detected_segment_error_m':length_control,'three_mm_last_frame_hoof_drift_detected_loop_error_m':loop_control,'all_detected':slipping>.001 and length_control>LIMIT['segment_length_error_m']and loop_control>.001},'mechanics_pass':mechanics,'deformation_screen_pass':deformation,'walk_accepted':False,'limitations':['Actual immutable26joint rig rest/geometry/IB plus counterfactual source-weight proposalV3; weights not serialized into GLB. No new GLB or actual animation clip serialized. Native CPU counterfactual, not actual GLTFLoader/Mixer or rendered gait.','Annotated hoof patches are rigid, not a complete flat sole/hoof/contact area or force/load-transfer proof. Uneven default hoof minima explicitly lowered individually to common plane; fixed body lowered30mm to allow measured forechain reach. Entry/exit from this posture unproved.','Rest-relative triangle normal dot screen is not a triangle inversion or selfintersection proof. All-pairs body/limb/hoof collision, anatomy, visual/photo quality, turning/slopes, hitch/riding/teams remain unproved.','No original15rig clip or donor motion array played, copied or relabelled; explicit reconstructed schedule only.'],'elapsed_seconds':time.monotonic()-start}
(P/'ACTUAL-WALK-WEIGHT-V3-CPU-READBACK.json').write_text(json.dumps(result,indent=2)+'\n');(P/'AUTHORED-NATIVE-WALK-WEIGHT-V3-POSES.json').write_text(json.dumps({'status':'UNACCEPTED COUNTERFACTUAL SOURCE POSES ONLY','frames':frames},separators=(',',':'))+'\n');print(json.dumps(result,indent=2))
if not mechanics or not deformation:raise SystemExit(2)
