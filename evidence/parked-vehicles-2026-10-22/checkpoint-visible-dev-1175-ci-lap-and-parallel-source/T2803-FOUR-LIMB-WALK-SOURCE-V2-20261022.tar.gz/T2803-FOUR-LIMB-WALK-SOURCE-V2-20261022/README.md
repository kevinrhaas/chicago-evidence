# Four-limb walk source study — CLOSED, skin failure retained

This is a concrete **unaccepted source proposal**, not a shipped walk or photographic/anatomical result. No app, Git, ticket, original asset, GLB export, browser or heavy producer was changed/run. All bounded CPU commands used nice19, one math thread and a15-second cap; all processes are closed.

## Corrected section claim

The first03a1 rig's wording “inside actual measured plane contour” exceeded its original evidence, which only tested section AABBs. That immutable source/artifact is preserved. `RERIG-CONTROLS-PROPOSAL-V2.json` corrects the proof history and cites the new actual closed-section measurement.

`inspect_sections.py` decoded all14,986 actual serialized rest triangles, intersected planes and ordered degree-two closed contours, welding endpoints at10µm. All16 tested distal pivots are inside their selected polygons. The four elbow/stifle pivots are49.2–59.0mm from the nearest contour boundary, despite42.6–54.2mm offsets from wire-point means. Independent finite contour arithmetic finds no proper nonadjacent segment crossings. Containment is surface geometry evidence; hidden joints and axes remain reconstructed. Proximal shoulders/hips are not independently isolated anatomical contours.

## Explicit first straight walk

`walk_source.py` authors a1.6s cycle,240mm stride and150mm/s body speed, with75% stance duty and30mm unloaded hoof arc. Touchdown sequence is hind-left, fore-left, hind-right, fore-right. This is an authored lateral-sequence four-beat schedule, not calibrated donor motion. No old clip was copied, played or relabelled.

The actual forechain is nearly straight. The proposal explicitly lowers the body30mm to allow the measured reach; each existing annotated hoof minimum is lowered independently to the commonY=0 plane. This is a changed walking posture, not proof of entering that posture from standing. Upper/lower links use rigid two-bone IK; lower carpus/hock→fetlock→hoof link directions and hoof orientations remain fixed. Quintic unloaded travel matches stationary world stance velocity/acceleration at boundaries. Body-frame curves loop exactly; route translation advances240mm per cycle.

`PREDECLARED-WALK-BOUNDS.json` freezes source hashes, parameters and numerical screens before the first run:≤10µm stance drift,≤1nm chain/loop error,0.9–1.1 edge ratios,0.8–1.2 area ratios, no rest-relative normal-dot negatives, no material-seam gap above1µm, no surface below−10µm. These are explicit engineering screens, not anatomy certification, and were never weakened.

`prove_walk.py` reads actual03a1 positions, weights, inverse binds and indices.65 inclusive poses evaluate all11,556 vertex positions/normals and14,986 triangles per pose:751,140 full vertex evaluations. Mechanics pass: stance patch drift≤2.23e−16m, segment/parent errors≤1.47e−15m, minimum IK reach margin6.79mm, exact loop/seams0, finite output and no sampled ground penetration. The four patch sizes remain59/59/13/10; these annotated patches do not prove complete flat sole contact or force transfer. Meaningful bad controls detect180mm sliding,2.903mm segment error and3mm loop drift.

## Skin blocker, including failed weight correction

| Body mesh screen | Immutable serialized03a1 weights | Counterfactual hinge-band V3 |
|---|---:|---:|
| Edge ratio range |0.260–2.107|0.266–5.072|
| Triangle area ratio range |0.068–3.498|0.166–9.638|
| Maximum rest-relative triangle normal-dot negatives |6|5|

Both commands correctly exit2. The current rig weights fail badly even though contacts and rigid chains pass. `weight_proposal_v3.py` replaces interpolation over entire links with adjacent hinge bands and explicit segment-start controls. The same fixed walk and screens reject this version too: body territories/weight transitions worsen. **V3 is withdrawn as a candidate; do not export or integrate it.** First failure, rejected V3, logs and explicit source poses remain immutable review evidence. There is no accepted animated skin or live gait in this packet.

Next source work must locate offending weight transitions on actual surface edges and produce a skin that passes the same screens. Then actual serialized curves/weights, GLTFLoader/Mixer, selfcontact/whole-hoof checks, neutral/flexed visuals, transition and grounded route checks remain necessary. No start/stop/turn/slope, hitch, team, driver/rider, photographic or anatomical acceptance is implied. Rest-relative normal-dot screening is not an exhaustive inversion or selfintersection test.

## Provenance

Original unchanged surface: **Horse by sevketkabatas**, CC BY4.0, https://sketchfab.com/3d-models/horse-53a6eb7ccf054aa2a378dd7ec08f88fe , SHA41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988. Actual immutable reconstructed26-joint bind study SHA03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36; original UV/maps/materials/geometry retained. Prior hierarchy reference: **Rigged Mid-Poly Horse by antemeossa**, CC BY4.0, https://sketchfab.com/3d-models/rigged-mid-poly-horse-fea999c1d8d64eb4a9c2bb1fac1e7d83 , SHA51ab71106472321b565a47aabe281235e2c0801804bcee7694f729192913e22c. This packet authors new reconstructed schedules/IK/weight proposals and metadata; it copies no donor geometry or motion arrays. Both source credits/licenses and changes must accompany any future derivative. Original licensing/acquisition evidence remains in the frozen prior source packets.
