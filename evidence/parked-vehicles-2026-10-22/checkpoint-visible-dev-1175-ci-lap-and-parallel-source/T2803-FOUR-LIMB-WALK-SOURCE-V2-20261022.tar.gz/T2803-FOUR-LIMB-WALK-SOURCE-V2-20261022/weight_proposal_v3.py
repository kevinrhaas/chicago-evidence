"""UNACCEPTED source weights proposal: segment-start binding and hinge bands.

Corrects the earlier closest-polyline recipe's interpolation along whole links.
Below .76m four isolated surface limbs are independent; each rigid lower chain
uses its own hoof control because the authored walk holds all distal rotations
fixed. That is a walk-specific study, not general flexion or anatomical approval.
No geometry, UV, rig pivot, rest frame, index, material or map is changed/exported.
"""
import numpy as np
def smooth(a,b,x):
 t=np.clip((x-a)/(b-a),0,1)
 return t*t*(3-2*t)
def weights_for_mesh(points,joints,weights,controls,force_hoof):
 piv=np.array([r['rest_world_pivot_m']for r in controls['nodes']]);dense=np.zeros((len(points),26));np.add.at(dense,(np.arange(len(points))[:,None],joints),weights)
 for i,(x,y,z) in enumerate(points):
  if i in force_hoof:
   dense[i]=0;dense[i,controls['limbs'][force_hoof[i]]['joints'][-1]]=1;continue
  if y>=1.16 or abs(x)<=.04 or abs(z)<=.10:continue
  label=('fore_'if z>0 else'hind_')+('l'if x>0 else'r');a,b,c,d,e=controls['limbs'][label]['joints'];center=np.array([np.interp(y,piv[[e,d,c,b,a],1],piv[[e,d,c,b,a],k])for k in [0,2]]);radius=np.linalg.norm(np.array([x,z])-center)
  if y>=.76 and radius>=.25:continue
  if y<.76 and radius>=.24:continue
  # Upper/lower links are controlled by their proximal node, with smooth
  # adjacent-link blending only around actual authored hinge heights.
  body=smooth(.90,1.16,y);radial=smooth(.11,.25,radius)*smooth(.76,.94,y);body=1-(1-body)*(1-radial)
  above_elbow=smooth(piv[b,1]-.09,piv[b,1]+.09,y);above_carpus=smooth(piv[c,1]-.09,piv[c,1]+.09,y)
  row=np.zeros(26);row[1]=body;row[a]=(1-body)*above_elbow;row[b]=(1-body)*(1-above_elbow)*above_carpus;row[e]=(1-body)*(1-above_elbow)*(1-above_carpus)
  dense[i]=row
 # Retain exactly matching weights at existing UV/material seam classes via
 # common source-position recipe. The caller evaluates all classes acrossmeshes.
 order=np.argsort(-dense,axis=1,kind='stable')[:,:4];w=np.take_along_axis(dense,order,axis=1);w/=w.sum(1)[:,None]
 return order.astype(np.uint16),w.astype(np.float32)
