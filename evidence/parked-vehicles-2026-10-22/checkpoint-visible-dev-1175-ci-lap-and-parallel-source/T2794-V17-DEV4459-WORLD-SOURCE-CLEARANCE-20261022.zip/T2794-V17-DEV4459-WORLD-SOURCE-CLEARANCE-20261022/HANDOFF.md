# Current V17 world-source analysis found a real load blocker

The unchanged stand is E1397.9,N−3240,bearing178.99. The installed tree remains **a6f05c6532c254bb39a1f19264b98bb053bf2244**; no app file, index, pose, camera, geometry or threshold was changed during this analysis.

The actual production road-clipping and `carriagewayHeight` closure were re-executed from exact current `street-grid.js` source ranges, with the exact current grid/surface/section data. Only mesh buffering was suppressed. Ground used the actual `Heightfield.adopt/sample` source and current e1871 int16 samples, including Float32 conversion. Every tested vehicle point lies inside the real loaded heightfield, so no apron, context or flat fallback was used. This is a source-level execution, not a claim that a browser has adopted the same files or rendered mesh.

The four wheel-ground samples span **4.599391mm**, passing the existing30mm guard. The current wheel-only base is4.0750232396m. But the four fixed ground-shoe contacts penetrate **4.636807–4.865790mm**, failing the unchanged1mm limit. The current production consumer will refuse the Brougham at this stand and omit it. This functional failure should be repaired before its first costly full preflight or main capture.

Actual near geometry supplied40,074vertex samples and134,008triangle edge-midpoint/centroid samples. All174,082 samples are over the clipped carriageway. The minimum is−4.865789698mm at an actual ground-shoe vertex. All13source anchors and the full pole are included. The remaining wooden pole surface has a minimum sampled5.195915mm gap. Finite samples do not prove continuous triangle/terrain extrema; they do give a direct failure witness.

Other concrete source screens found no plan overlap:

- Full actual-vertex hull versus all236 street-band polygons: nearest curb0.486878m, parkway0.639203m, walk2.619145m. This uses the actual vehicle hull, not rotated AABB corners.
- Actual C02 vertices, all hierarchy rotations, fixed shafts and separate shaft-rest geometry: **6.815127m** horizontal hull separation. C02 is unchanged.
- All91 source carriage-block boxes, with the production dimensions and orientation: nearest actual plan hull10.868631m away.
- All201 building footprint polygons, using the current walker's exact footprint transform: nearest footprint hull9.200238m (Keith), Glessner9.201011m. Footprints do not include every eave, stoop, projection or rendered triangle; those remain unproved.
- Nearest source elm centre is1.598309m from the vehicle hull. That is only a centre measurement. Leaning trunks, limbs/crowns and current wind geometry require actual rendered inspection; no radius or canopy-clearance pass is inferred.

The first bounded reader completed the actual geometry/provider measurements in7.698seconds but then failed its artificial+31mm lift control: the existing4.866mm sink meant that lift was still inside the30mm gap guard. That caller failure is preserved. The expanded second reader hit its strict15second caller limit and has no final verdict; it is retained as a timeout. A separate0.307second completion reused the completed first geometry observations only after re-verifying every exact source/asset/stand pin, then completed building/block screens and six negative controls. It reports `standSourceChecksPass:false`; the analysis completing is not a clearance pass. No partial failure was relabeled as a passing full run.

## Concrete repair candidate for root review — not applied

The minimal rigid base over **all declared wheel and shoe contacts** is4.0798890292m,4.865790mm above the wheel-only result. On the same source provider it gives a maximum wheel gap9.465180mm and shoe gaps0–0.228983mm, preserving the existing30mm wheel/30mm shoe-gap/1mm penetration limits. The minimum existing finite geometry sample would become−0.000000077mm, numerical zero. This is a physically grounded contact-set base solve, not a change to ENU/bearing, geometry, camera, materials or budgets. Root must review the concrete production change before it is applied; actual browser/published proof is still required afterward.

## Next graphics window

`read_installed_world.cjs` is a prepared read-only hook for the existing normal main-page fixture. Load the1904 main page normally, wait for `__chicago4d.ready`, then add this script and call `window.readInstalledBroughamWorld()`. It uses the actual main `streetGrid.carriagewayHeight`, manifest, installed model, served indexed asset hash, merged world vertices and unchanged C02. It does not inject a candidate or move a camera/stand. If the production consumer omits the Brougham, it returns the actual parked-layer problems and failed contacts rather than installing a workaround.

The existing V13 normal-main fixture's `main-control.cjs` contains rendered building/curb/block/tree broad/narrow inspection hooks, but its old32678triangle/six-batch/V13asset pins and candidate injection must not be reused unchanged. The installed V17 needs33502triangles/sevenbatches and its actual served hash. Keep normal lighting, quality, scene budget and both viewport assertions; save diagnostics before any assertion. Full published desktop/phone, actual geometry obstacle checks, card/picking/confidence/tier/disposal and scene budgets remain open. No browser or renderer was started here.
