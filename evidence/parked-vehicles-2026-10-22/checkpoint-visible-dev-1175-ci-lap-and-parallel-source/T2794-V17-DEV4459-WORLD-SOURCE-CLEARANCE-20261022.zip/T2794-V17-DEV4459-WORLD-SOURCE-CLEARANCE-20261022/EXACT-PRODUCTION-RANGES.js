const FT = 0.3048;
const CLASSES = {
  carriageway: { lift: 0.03, colour: 0x7a7066, offset: -8, tier: 'inferred' },
  alley: { lift: 0.035, colour: 0x857a6c, offset: -9, tier: 'inferred' },
  margin: { lift: 0.05, colour: 0x7c8a66, offset: -10, tier: 'inferred' },
  parkway: { lift: 0.05, colour: 0x7c8a66, offset: -10, tier: 'reconstructed' },
  walk: { lift: 0.055, colour: 0xc2bdb2, offset: -11, tier: 'reconstructed' },
  curb: { lift: 0.06, colour: 0xd9d5cc, offset: -12, tier: 'reconstructed' },
};

const PRIORITY_LIFT_M = 0.003;
const TUCK_M = 0.15;
const SEAM_M = 1.6;
const sub = (p, q) => [p[0] - q[0], p[1] - q[1]];
const dot = (p, q) => p[0] * q[0] + p[1] * q[1];
const lerp = (p, q, f) => [p[0] + (q[0] - p[0]) * f, p[1] + (q[1] - p[1]) * f];
const len = (p) => Math.hypot(p[0], p[1]);

/**
 * A quad as the grid writes it — a, b along one side and d, c along the other —
 * relabelled so that a->b runs ALONG the street, with a metric frame: `t` along,
 * `n` across towards d. A multi-quad record (a curve cut every 5 m) steps along
 * a->b already; a single quad is along its longer side, which is how a cross
 * street's one quad (written across-first) comes out right.
 */
function framed(q, alongIsAB) {
  let [a, b, c, d] = q;
  if (!alongIsAB) [b, d] = [d, b];
  const ab = sub(b, a);
  const L = len(ab) || 1;
  const t = [ab[0] / L, ab[1] / L];
  let n = [-t[1], t[0]];
  if (dot(n, sub(d, a)) < 0) n = [-n[0], -n[1]];
  return { a, b, c, d, t, n, along: L };
}

/**
 * The framed quad to plan triangles on a grid no coarser than MAX_EDGE_M either
 * way, by bilinear interpolation, each vertex carrying its metric (along, across)
 * position in the record's frame. So a strip 15 cm wide costs two triangles per
 * 2.5 m of its length, not the hundreds an isotropic subdivision spends on a sliver.
 */
function quadTriangles(f, origin, offset) {
  const { a, b, c, d } = f;
  const along = Math.max(len(sub(b, a)), len(sub(c, d)));
  const across = Math.max(len(sub(d, a)), len(sub(c, b)));
  const nu = Math.max(1, Math.ceil(along / MAX_EDGE_M));
  const nv = Math.max(1, Math.ceil(across / MAX_EDGE_M));
  const ccw = (b[0] - a[0]) * (d[1] - a[1]) - (b[1] - a[1]) * (d[0] - a[0]) >= 0;
  const at = (u, v) => {
    const p = lerp(lerp(a, b, u), lerp(d, c, u), v);
    const r = sub(p, origin);
    return [p[0], p[1], offset + dot(r, f.t), dot(r, f.n)];
  };
  const out = [];
  for (let i = 0; i < nu; i += 1) {
    for (let j = 0; j < nv; j += 1) {
      const p00 = at(i / nu, j / nv); const p10 = at((i + 1) / nu, j / nv);
      const p11 = at((i + 1) / nu, (j + 1) / nv); const p01 = at(i / nu, (j + 1) / nv);
      // counter-clockwise in plan, so the normals point up
      if (ccw) out.push([p00, p10, p11], [p00, p11, p01]);
      else out.push([p00, p11, p10], [p00, p01, p11]);
    }
  }
  return out;
}

function pointInPolygon(e, n, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i, i += 1) {
    const [xi, yi] = poly[i]; const [xj, yj] = poly[j];
    if ((yi > n) !== (yj > n) && e < ((xj - xi) * (n - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

/** Twice the signed area of a plan polygon: positive counter-clockwise. */
function area2(poly) {
  let s = 0;
  for (let i = 0; i < poly.length; i += 1) {
    const [x0, y0] = poly[i]; const [x1, y1] = poly[(i + 1) % poly.length];
    s += x0 * y1 - x1 * y0;
  }
  return s;
}
const ccwOf = (poly) => (area2(poly) >= 0 ? poly : [...poly].reverse());

/** The part of a convex polygon on the left of the line p -> q (Sutherland-Hodgman). */
function clipLeft(poly, p, q) {
  const t = sub(q, p);
  const side = (x) => t[0] * (x[1] - p[1]) - t[1] * (x[0] - p[0]);
  const out = [];
  for (let i = 0; i < poly.length; i += 1) {
    const cur = poly[i]; const nxt = poly[(i + 1) % poly.length];
    const sc = side(cur); const sn = side(nxt);
    if (sc >= 0) out.push(cur);
    if ((sc >= 0) !== (sn >= 0)) out.push(lerp(cur, nxt, sc / (sc - sn)));
  }
  return out;
}

/** A piece left beside a roadway thinner than this (2 x area / perimeter) joins it. */
const SLIVER_M = 0.6;
/** T-2692: a piece of one, cut by a roadway crossing it, shorter than this is left out. */
const SLIVER_STUB_M = 6.0;
/** Square metres below which a clipped piece is a rounding sliver, not a surface. */
const PIECE_EPS_M2 = 0.01;

/**
 * T-2475: a convex plan polygon minus the convex polygon `h` laid over it, as the
 * convex pieces outside `h` (none, when `h` covers it). `h` is counter-clockwise.
 *
 * T-2691: the edge cutting off the most is taken first. Each cut runs the edge's
 * whole line across what is left, so a side edge cut first split a roadway running
 * on past `h` lengthwise for its full length (Prairie Avenue's 16th-18th block, by
 * the 18th-20th roadway's west edge, 1.5 m in from its curb), and the two long pieces
 * drew a hairline seam up the block. The end edge first leaves the side edges only
 * the stretch beside `h`.
 */
function perimeterOf(poly) {
  let p = 0;
  for (let j = 0; j < poly.length; j += 1) p += len(sub(poly[(j + 1) % poly.length], poly[j]));
  return p;
}

/** A convex counter-clockwise polygon with every edge moved `d` out. */
function growConvex(poly, d) {
  const lines = poly.map((p, i) => {
    const q = poly[(i + 1) % poly.length];
    const t = sub(q, p); const L = len(t) || 1;
    const n = [t[1] / L * d, -t[0] / L * d];
    return [[p[0] + n[0], p[1] + n[1]], t];
  });
  return lines.map(([a, ta], i) => {
    const [b, tb] = lines[(i + lines.length - 1) % lines.length];
    const den = tb[0] * ta[1] - tb[1] * ta[0];
    if (Math.abs(den) < 1e-12) return a;
    const k = ((a[0] - b[0]) * ta[1] - (a[1] - b[1]) * ta[0]) / den;
    return [b[0] + tb[0] * k, b[1] + tb[1] * k];
  });
}

/** A convex counter-clockwise polygon with every edge moved `d` in. */
function insetConvex(poly, d) {
  let out = poly;
  for (let i = 0; i < poly.length && out.length >= 3; i += 1) {
    const p = poly[i]; const q = poly[(i + 1) % poly.length];
    const t = sub(q, p); const L = len(t) || 1;
    const n = [-t[1] / L * d, t[0] / L * d];
    out = clipLeft(out, [p[0] + n[0], p[1] + n[1]], [q[0] + n[0], q[1] + n[1]]);
  }
  return out;
}

function minusConvex(poly, h) {
  const pieces = [];
  let rest = poly;
  const edges = h.map((p, i) => [p, h[(i + 1) % h.length]]);
  while (edges.length && rest.length >= 3) {
    let best = 0; let bestArea = -1;
    edges.forEach(([p, q], i) => {
      const a = Math.abs(area2(clipLeft(rest, q, p)));
      if (a > bestArea) { best = i; bestArea = a; }
    });
    const [p, q] = edges.splice(best, 1)[0];
    const outside = clipLeft(rest, q, p);
    if (outside.length >= 3 && Math.abs(area2(outside)) / 2 > PIECE_EPS_M2) pieces.push(outside);
    rest = clipLeft(rest, p, q);
  }
  if (rest.length < 3 || Math.abs(area2(rest)) / 2 <= PIECE_EPS_M2) return { pieces: [poly], covered: null };
  return { pieces, covered: rest };
}

/**
 * The convex polygon in triangles no longer than about MAX_EDGE_M on a side, each
 * vertex with its metric (along, across) position in `frame` from `origin`. It is
 * cut on the frame's own grid, as quadTriangles cuts a quad: strips across, cells
 * along, each cell (convex, at most a few vertices) in a fan. So a 280 m roadway
 * piece costs what its quad did, not the square of its length.
 */
function polyTriangles(poly, frame, origin) {
  const U = (p) => dot(sub(p, origin), frame.t);
  const V = (p) => dot(sub(p, origin), frame.n);
  const us = poly.map(U); const vs = poly.map(V);
  const u0 = Math.min(...us); const u1 = Math.max(...us);
  const v0 = Math.min(...vs); const v1 = Math.max(...vs);
  const nu = Math.max(1, Math.ceil((u1 - u0) / MAX_EDGE_M));
  const nv = Math.max(1, Math.ceil((v1 - v0) / MAX_EDGE_M));
  const P = (u, v) => [origin[0] + frame.t[0] * u + frame.n[0] * v, origin[1] + frame.t[1] * u + frame.n[1] * v];
  const at = (p) => [p[0], p[1], U(p), V(p)];
  let shape = ccwOf(poly);
  const out = [];
  // clipLeft keeps the left of a line; "u >= c" is the left of the line running -n at u = c
  // when (t, n) is right-handed, so test the handedness once.
  const rh = frame.t[0] * frame.n[1] - frame.t[1] * frame.n[0] > 0;
  const keepUAbove = (sh, c) => (rh ? clipLeft(sh, P(c, 1), P(c, 0)) : clipLeft(sh, P(c, 0), P(c, 1)));
  const keepVAbove = (sh, c) => (rh ? clipLeft(sh, P(0, c), P(1, c)) : clipLeft(sh, P(1, c), P(0, c)));
  for (let i = 0; i < nu; i += 1) {
    const ua = u0 + ((u1 - u0) * i) / nu; const ub = u0 + ((u1 - u0) * (i + 1)) / nu;
    let strip = i > 0 ? keepUAbove(shape, ua) : shape;
    if (i + 1 < nu) strip = ccwOf(clipLeft(ccwOf(strip), ...(rh ? [P(ub, 0), P(ub, 1)] : [P(ub, 1), P(ub, 0)])));
    if (strip.length < 3) continue;
    for (let j = 0; j < nv; j += 1) {
      const va = v0 + ((v1 - v0) * j) / nv; const vb = v0 + ((v1 - v0) * (j + 1)) / nv;
      let cell = j > 0 ? keepVAbove(ccwOf(strip), va) : strip;
      if (j + 1 < nv) cell = clipLeft(ccwOf(cell), ...(rh ? [P(1, vb), P(0, vb)] : [P(0, vb), P(1, vb)]));
      if (cell.length < 3 || Math.abs(area2(cell)) < 1e-6) continue;
      cell = ccwOf(cell);
      for (let k = 1; k + 1 < cell.length; k += 1) out.push([cell[0], cell[k], cell[k + 1]].map(at));
    }
  }
  return out;
}


function surfaceOf(surfaces, kind, id, band = null, face = null) {
  if (!surfaces) return null;
  if (kind === 'carriageway') return surfaces.carriageways?.[id] ?? null;
  if (kind === 'alley') return surfaces.alleys?.[id] ?? null;
  return surfaces.faces?.[face]?.[band] ?? surfaces.bands?.[band] ?? null;
}


class Heightfield {
  constructor() {
    this.loaded = false;
    this.cols = 0;
    this.rows = 0;
    this.cellM = 1;
    this.originE = 0;
    this.originN = 0;
    this.data = null;
    this.meta = null;
    this.contextCoast = null;
    /** T-2502: a scene's apron field (terrain-apron.js) — a second Heightfield
     *  answered outside this one's grid, before the fallback. */
    this.apron = null;
    /** Height used outside the grid and before anything is loaded. */
    this.fallbackY = 0;
  }

  get widthM() { return (this.cols - 1) * this.cellM; }
  get depthM() { return (this.rows - 1) * this.cellM; }

  /**
   * @param {object} meta  { cols, rows, cell_m, origin_e, origin_n, encoding?, scale?, offset? }
   * @param {ArrayBuffer} buffer  raw samples, row-major from the south-west corner
   */
  adopt(meta, buffer) {
    const cols = meta.cols | 0;
    const rows = meta.rows | 0;
    if (!(cols > 1 && rows > 1)) throw new Error('heightfield: cols/rows must be > 1');

    const encoding = meta.encoding || 'float32';
    let data;
    if (encoding === 'float32') {
      data = new Float32Array(buffer, 0, cols * rows);
    } else if (encoding === 'int16') {
      // Quantised metres: y = raw * scale + offset. The plan quantises to
      // <= 0.25 ft, which int16 carries comfortably over 15 ft of relief.
      const raw = new Int16Array(buffer, 0, cols * rows);
      const scale = meta.scale ?? 0.01;
      const offset = meta.offset ?? 0;
      data = new Float32Array(raw.length);
      for (let i = 0; i < raw.length; i++) data[i] = raw[i] * scale + offset;
    } else {
      throw new Error(`heightfield: unknown encoding '${encoding}'`);
    }
    if (data.length < cols * rows) {
      throw new Error(`heightfield: ${data.length} samples for a ${cols}x${rows} grid`);
    }

    this.cols = cols;
    this.rows = rows;
    this.cellM = meta.cell_m ?? meta.cellM ?? 1;
    this.originE = meta.origin_e ?? meta.originE ?? 0;
    this.originN = meta.origin_n ?? meta.originN ?? 0;
    this.data = data;
    this.meta = meta;
    this.loaded = true;
    return this;
  }

  async load(metaUrl, binUrl) {
    const meta = await (await fetch(metaUrl)).json();
    const buffer = await (await fetch(binUrl ?? new URL(meta.bin, metaUrl))).arrayBuffer();
    return this.adopt(meta, buffer);
  }

  /** True when (e, n) lies on the loaded grid. Outside it, `sample()` answers
   * with `fallbackY` rather than a measurement — callers that refine geometry
   * against the field (streets.js, T-0110) must not treat that constant as
   * ground truth, so this is the test that separates the two. */
  contains(e, n) {
    if (!this.loaded) return false;
    const gx = (e - this.originE) / this.cellM;
    const gy = (n - this.originN) / this.cellM;
    return gx >= 0 && gy >= 0 && gx <= this.cols - 1 && gy <= this.rows - 1;
  }

  /** Elevation in metres at local ENU (e, n). Bilinear; clamped at the edges. */
  sample(e, n) {
    if (!this.loaded) return this.fallbackY;
    const gx = (e - this.originE) / this.cellM;
    const gy = (n - this.originN) / this.cellM;
    if (gx < 0 || gy < 0 || gx > this.cols - 1 || gy > this.rows - 1) {
      if (this.apron?.contains(e, n)) return this.apron.sample(e, n);
      if (this.contextCoast) return contextSample(this, e, n, (ce, cn) => this.sample(ce, cn));
      return this.fallbackY;
    }

    const x0 = Math.min(Math.floor(gx), this.cols - 2);
    const y0 = Math.min(Math.floor(gy), this.rows - 2);
    const fx = gx - x0;
    const fy = gy - y0;
    const d = this.data;
    const r0 = y0 * this.cols;
    const r1 = r0 + this.cols;
    const h00 = d[r0 + x0], h10 = d[r0 + x0 + 1];
    const h01 = d[r1 + x0], h11 = d[r1 + x0 + 1];
    return (h00 * (1 - fx) + h10 * fx) * (1 - fy) + (h01 * (1 - fx) + h11 * fx) * fy;
  }

  /** Surface normal by central differences — for slope limits and shading. */
  normal(e, n, target = new THREE.Vector3()) {
    if (!this.loaded) return target.set(0, 1, 0);
    const d = this.cellM;
    const dydE = (this.sample(e + d, n) - this.sample(e - d, n)) / (2 * d);
    const dydN = (this.sample(e, n + d) - this.sample(e, n - d)) / (2 * d);
    return target.set(-dydE, 1, dydN).normalize();
  }
}

/**
 * Load the terrain for one epoch: the heightfield the walker samples, the
 * ground mesh, and the water surface.
 *
 * Degrades in one step at a time. No heightfield means a flat plane at the
 * datum and a recorded problem; no ground GLB means a mesh built here from the
 * heightfield, which is the same surface by construction and costs one boot
 * frame. Nothing here silently renders a fiction.
 *
 * @param {object} o
 * @param {URL} o.dataBase        where data/ lives
 * @param {URL} o.assetBase       where the GLBs live
 * @param {string} o.epochId      terrain epoch, from the scene file
 * @param {URL|null} [o.substrateBase] where the flora manifest the ground's sand and
 *                                marsh colours come from lives; null paints none
 * @param {object} [o.confidence] the confidence view, to patch the materials into
 * @param {string[]} [o.problems] collector, same list the scene loader writes to
 */

  const FALL = section ? (section.section?.fall?.in_per_3ft ?? 0) / 36 : 0;
  const ROAD = section ? (section.section?.road_m ?? 0) : 0;
  const bboxOf = (pts) => {
    const b = [Infinity, Infinity, -Infinity, -Infinity];
    for (const [e, n] of pts) { b[0] = Math.min(b[0], e); b[1] = Math.min(b[1], n); b[2] = Math.max(b[2], e); b[3] = Math.max(b[3], n); }
    return b;
  };
  const inBox = (b, e, n) => e >= b[0] && e <= b[2] && n >= b[1] && n <= b[3];
  const sideFaces = (grid.faces ?? []).map((f) => {
    const quads = Object.values(f.bands ?? {}).flat();
    const xs = grid.cross_sections?.[f.cross_section] ?? {};
    return {
      f, quads, box: bboxOf(quads.flat()), line: f.street_line_local_m ?? [],
      W: (xs.sidewalk_space_ft?.value ?? 14) * FT,
    };
  });
  const roadQuads = (grid.carriageways ?? []).flatMap((c) => c.quads_local_m ?? []).map((q) => ({ q, box: bboxOf(q) }));
  /** Across distance from a face's street line: to the nearest segment's own line,
   *  so a point in the corner square past the line's end still measures across. */
  const acrossOf = (line, e, n) => {
    let best = Infinity; let across = 0;
    for (let i = 1; i < line.length; i += 1) {
      const a = line[i - 1]; const b = line[i];
      const t = sub(b, a); const L = len(t) || 1;
      const u = Math.max(0, Math.min(1, dot(sub([e, n], a), t) / (L * L)));
      const p = lerp(a, b, u);
      const d = len(sub([e, n], p));
      if (d < best) { best = d; across = Math.abs((t[0] * (n - a[1]) - t[1] * (e - a[0])) / L); }
    }
    return across;
  };
  /** How far below the field (e, n) is drawn: the fall across a sidewalk space (the
   *  larger across distance where two spaces meet at a corner, so they agree), the
   *  roadway's level in a carriageway, nothing elsewhere. */
  const offsetAt = (e, n) => {
    if (!section) return 0;
    let s = -1; let W = 0;
    for (const sf of sideFaces) {
      if (!inBox(sf.box, e, n) || !sf.quads.some((q) => pointInPolygon(e, n, q))) continue;
      const a = acrossOf(sf.line, e, n);
      if (a > s) { s = a; W = sf.W; }
    }
    if (s >= 0) return -FALL * Math.min(s, W);
    for (const r of roadQuads) if (inBox(r.box, e, n) && pointInPolygon(e, n, r.q)) return ROAD;
    return 0;
  };
  out.offsetAt = offsetAt;


  const carriageById = new Map((grid.carriageways ?? []).map((c) => [c.id, c]));
  const centroid = (rec) => {
    const q = (rec?.quads_local_m ?? [])[0];
    if (!q) return null;
    return [(q[0][0] + q[1][0] + q[2][0] + q[3][0]) / 4, (q[0][1] + q[1][1] + q[2][1] + q[3][1]) / 4];
  };

  /*
   * T-2475 — one roadway surface at every crossing. The carriageways run through
   * their intersections, so two (brick and asphalt at Indiana and 18th) used to lie
   * in the same place a few millimetres apart and flicker against each other from
   * any distance. Now each piece is ranked (its priority, then its order in the
   * grid), and every piece is cut out from under each higher one that crosses its
   * whole width; a margin SEAM_M deep is kept at each edge it meets and drawn OVER
   * the higher roadway in a fading overlay, so one paving wears into the next.
   */
  const ways = [];
  for (const c of grid.carriageways ?? []) {
    const s = surfaceOf(surfaces, 'carriageway', c.id);
    const quads = c.quads_local_m ?? [];
    const priority = s?.priority ?? 0;
    if (s?.pieces?.length && quads.length === 1) {
      // A segment whose surface changes at a cross street (Calumet at 21st): cut
      // the one quad where the cross street's centre falls along it.
      const q = quads[0];
      const f = framed(q, len(sub(q[1], q[0])) >= len(sub(q[3], q[0])));
      let lo = 0;
      s.pieces.forEach((piece, i) => {
        let hi = 1;
        if (piece.until) {
          const cen = centroid(carriageById.get(piece.until));
          hi = cen ? Math.min(1, Math.max(lo, dot(sub(cen, f.a), f.t) / f.along)) : 1;
        }
        const cut = [lerp(f.a, f.b, lo), lerp(f.a, f.b, hi), lerp(f.d, f.c, hi), lerp(f.d, f.c, lo)];
        ways.push({ id: `${c.id}#${i}`, quads: [cut], tier: c.geometry_tier, surface: piece, priority,
          pieceOf: { origin: f.a, t: f.t, n: f.n } });
        lo = hi;
      });
      out.census.surfaced += 1;
    } else if (quads.length === 1) {
      const q = quads[0];
      const f = framed(q, len(sub(q[1], q[0])) >= len(sub(q[3], q[0])));
      ways.push({ id: c.id, quads: [[f.a, f.b, f.c, f.d]], tier: c.geometry_tier, surface: s, priority,
        pieceOf: { origin: f.a, t: f.t, n: f.n } });
      if (s) out.census.surfaced += 1;
    } else {
      // A curve cut every 5 m: its quads already step along a -> b.
      ways.push({ id: c.id, quads: quads.map((q) => [...q]), tier: c.geometry_tier, surface: s, priority, pieceOf: null });
      if (s) out.census.surfaced += 1;
    }
    out.census.carriageways += 1;
  }
  ways.forEach((w, i) => {
    w.stacking = w.priority * 1000 + i;
    // Every quad as an item: kept whole while nothing is laid over it, a convex
    // polygon once cut. Each keeps the frame its tiles are laid in.
    w.items = w.quads.map((q) => {
      const f = framed(q, w.quads.length > 1 || w.pieceOf || len(sub(q[1], q[0])) >= len(sub(q[3], q[0])));
      return { quad: q, poly: null, frame: w.pieceOf ?? { origin: f.a, t: f.t, n: f.n } };
    });
    // The edges a lower roadway can fade over: a quad's sides, less the ones it
    // shares with the next quad of its own curve.
    const outer = [];
    for (const q of w.quads) {
      const cq = ccwOf(q);
      for (let j = 0; j < cq.length; j += 1) {
        const p0 = cq[j]; const p1 = cq[(j + 1) % cq.length];
        const t = sub(p1, p0); const L = len(t) || 1;
        const probe = [(p0[0] + p1[0]) / 2 + (t[1] / L) * 0.05, (p0[1] + p1[1]) / 2 - (t[0] / L) * 0.05];
        if (!w.quads.some((o) => o !== q && pointInPolygon(probe[0], probe[1], o))) outer.push([p0, p1]);
      }
    }
    w.edges = outer;
    w.margins = [];
    w.extra = [];
  });
  const above = [];   // every piece of the roadways ranked higher: { poly (ccw), box, way }
  // T-2692: the hair-thin pieces handed to the roadway above, which give way in turn to
  // any lower roadway crossing them: { polys (ccw), box }.
  const slivers = [];
  out.census.seams = 0; out.census.cuts = 0; out.census.slivers = 0;
  for (const w of [...ways].sort((x, y) => y.stacking - x.stacking)) {
    let items = w.items;
    for (const h of above) {
      const next = [];
      for (const it of items) {
        const shape = it.poly ?? it.quad;
        const box = bboxOf(shape);
        if (box[2] < h.box[0] || box[0] > h.box[2] || box[3] < h.box[1] || box[1] > h.box[3]) { next.push(it); continue; }
        // Under a roadway ranked higher (and so laid higher), this one runs on TUCK_M.
        const cutBy = h.way.priority > w.priority ? (h.tucked ??= insetConvex(h.poly, TUCK_M)) : h.poly;
        const { pieces, covered: under } = cutBy.length >= 3 ? minusConvex(ccwOf(shape), cutBy) : { pieces: [shape], covered: null };
        if (!under) { next.push(it); continue; }
        // The fading margin still starts at the higher roadway's own edge.
        const covered = cutBy === h.poly ? under : (minusConvex(ccwOf(shape), h.poly).covered ?? under);
        out.census.cuts += 1;
        for (const poly of pieces) {
          // A hair-thin piece left beside the roadway above (two segments of one
          // street, never the same width to the centimetre) goes to that roadway,
          // or it would draw as a thin line of the other paving down its side.
          const a = Math.abs(area2(poly)) / 2;
          let perim = 0;
          for (let j = 0; j < poly.length; j += 1) perim += len(sub(poly[(j + 1) % poly.length], poly[j]));
          if (a > 0 && (2 * a) / perim < SLIVER_M) {
            // T-2692: it is not laid over the roadways ranked below, as the roadway
            // above's own pieces are: one running across it (East 18th through the
            // crossing, where Prairie's 16th-18th segment is 0.35 m a side wider than
            // its 18th-20th one) keeps its paving there, and fades into the roadway
            // above from that roadway's own edge, with no strip of the other paving
            // left between them.
            const sl = { polys: [ccwOf(poly)], box: bboxOf(poly) };
            h.way.extra.push({ sliver: sl, frame: h.frame });
            slivers.push(sl);
            out.census.slivers += 1;
            continue;
          }
          next.push({ quad: null, poly, frame: it.frame });
        }
        // A margin under each edge of the roadway above that this one runs out
        // past: SEAM_M deep, drawn over it, fading (the seam overlay).
        for (const [p0, p1] of h.way.edges) {
          // Only where this roadway runs on past the edge, not a hair beside it (two
          // segments of one street rarely share a side line to the centimetre).
          const t = sub(p1, p0); const L = len(t) || 1;
          const out1 = [p0[0] + t[1], p0[1] - t[0]]; const out2 = [p1[0] + t[1], p1[1] - t[0]];
          // beside the edge itself, not anywhere along its line
          const outside = clipLeft(clipLeft(clipLeft(ccwOf(shape), p1, p0), p0, out1), out2, p1);
          const past = Math.max(0, ...outside.map((x) => (t[0] * (p0[1] - x[1]) - t[1] * (p0[0] - x[0])) / L));
          if (outside.length < 3 || past < SEAM_M / 2) continue;
          const inward = [-t[1] / L * SEAM_M, t[0] / L * SEAM_M];
          // Under a higher roadway the fade starts TUCK_M out over this one's own
          // paving, so its first, part-covered pixels blend this paving with itself
          // and not with the darker one beneath the edge.
          let strip;
          if (cutBy !== h.poly) {
            const grown = (h.grown ??= growConvex(h.poly, TUCK_M));
            const out0 = [p0[0] - (inward[0] / SEAM_M) * TUCK_M, p0[1] - (inward[1] / SEAM_M) * TUCK_M];
            const out1 = [p1[0] - (inward[0] / SEAM_M) * TUCK_M, p1[1] - (inward[1] / SEAM_M) * TUCK_M];
            strip = clipLeft(minusConvex(ccwOf(shape), grown).covered ?? covered, out0, out1);
          } else strip = clipLeft(covered, p0, p1);
          strip = clipLeft(strip, [p1[0] + inward[0], p1[1] + inward[1]], [p0[0] + inward[0], p0[1] + inward[1]]);
          if (strip.length < 3 || Math.abs(area2(strip)) / 2 <= PIECE_EPS_M2) continue;
          w.margins.push({ poly: strip, frame: it.frame, edge: [p0, p1] });
        }
      }
      items = next;
    }
    w.items = items;
    for (const it of items) {
      const poly = ccwOf(it.poly ?? it.quad);
      const box = bboxOf(poly);
      above.push({ poly, box, way: w, frame: it.frame });
      for (const sl of slivers) {
        if (sl.box[2] < box[0] || sl.box[0] > box[2] || sl.box[3] < box[1] || sl.box[1] > box[3]) continue;
        // What is left past the crossing's far side is a stub a few metres long standing
        // out over the corner's gutter and curb, where neither roadway is: dropped.
        sl.polys = sl.polys.flatMap((q) => {
          const { pieces, covered } = minusConvex(q, poly);
          return covered ? pieces.filter((x) => perimeterOf(x) / 2 >= SLIVER_STUB_M).map(ccwOf) : [q];
        });
      }
    }
  }
  const roadStandSurfaces = [];
  for (const w of ways) {
    const quads = w.items.filter((it) => it.quad).map((it) => it.quad);
    const polys = [...w.items.filter((it) => it.poly),
      ...w.extra.flatMap((x) => (x.sliver ? x.sliver.polys.map((poly) => ({ poly, frame: x.frame })) : [x]))];
    if (quads.length || polys.length) {
      push('carriageway', w.id, quads, w.tier, w.surface, { priority: w.priority, pieceOf: w.pieceOf, polys });
      roadStandSurfaces.push({ polygons: [...quads, ...polys.map(p => p.poly)],
        lift: CLASSES.carriageway.lift + w.priority * PRIORITY_LIFT_M });
    }
    for (const m of w.margins) {
      push('carriageway', w.id, [], w.tier, w.surface, { priority: w.priority, seam: m.edge, polys: [m] });
      out.census.seams += 1;
    }
  }
  // Vehicles stand on the same clipped carriageway and display lift we just drew,
  // not the uncut heightfield above the depressed road (T-2979).
  out.carriagewayHeight = (e, n) => {
    let lift = null;
    for (const surface of roadStandSurfaces) {
      if (surface.polygons.some(poly => pointInPolygon(e, n, poly))) {
        lift = Math.max(lift ?? -Infinity, surface.lift);
      }
    }
    const ground = terrain.surfaceHeight(e, n);
    return lift === null || !Number.isFinite(ground) ? null : ground + ROAD + lift;
  };

globalThis.READER={out,roadStandSurfaces,pointInPolygon,offsetAt,Heightfield,minusConvex,ccwOf};