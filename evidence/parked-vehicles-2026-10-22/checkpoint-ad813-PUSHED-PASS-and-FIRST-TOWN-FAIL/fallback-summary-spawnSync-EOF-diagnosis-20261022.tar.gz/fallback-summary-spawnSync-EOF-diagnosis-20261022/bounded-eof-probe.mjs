import {spawnSync} from 'node:child_process';import fs from 'node:fs';
const data=JSON.parse(fs.readFileSync(new URL('./ACTUAL-INPUTS.json',import.meta.url),'utf8'));const tools='/workspace/chicago/chicago/4d/tools';
const bare='import sys; d=sys.stdin.read(); print(len(d))';
const sent=`import json,sys
sys.path.insert(0,${JSON.stringify(tools)})
from compile_summaries import sentences
print(json.dumps([sentences(t) for t in json.loads(sys.stdin.read())]))`;
const lint=`import json,sys
sys.path.insert(0,${JSON.stringify(tools)})
from compile_summaries import lint_string
print(json.dumps([bool(lint_string(s)) for s in json.loads(sys.stdin.read())]))`;
const cases=[['small-bare',bare,'[]'],['exact-sentence-count',sent,JSON.stringify(data.leads)],['exact-small-lint',lint,JSON.stringify(data.cases)],['large-bare',bare,'x'.repeat(1048576)]];
let completed=0;for(let cycle=0;cycle<10;cycle++)for(const [name,code,input] of cases){console.log(JSON.stringify({event:'start',cycle,name,inputBytes:Buffer.byteLength(input),node:process.version}));const t=performance.now();const r=spawnSync('python3',['-c',code],{input,encoding:'utf8'});console.log(JSON.stringify({event:'end',cycle,name,status:r.status,signal:r.signal,error:r.error?{code:r.error.code,errno:r.error.errno,syscall:r.error.syscall,message:r.error.message}:null,stdoutBytes:r.stdout?.length,stderr:r.stderr,ms:performance.now()-t}));if(r.status!==0)process.exit(2);completed++;}console.log(JSON.stringify({event:'complete',node:process.version,completed}));
