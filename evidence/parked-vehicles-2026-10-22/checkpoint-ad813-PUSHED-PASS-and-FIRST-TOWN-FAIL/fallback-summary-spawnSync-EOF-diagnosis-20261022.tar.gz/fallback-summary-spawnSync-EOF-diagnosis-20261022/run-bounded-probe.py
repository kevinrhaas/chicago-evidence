import pathlib,subprocess,os,signal,json,time,sys,hashlib
p=pathlib.Path('/workspace/shared/fallback-summary-spawnSync-EOF-diagnosis-20261022');label=sys.argv[1];node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node';prefix='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:';env={**os.environ,'PATH':prefix+os.environ['PATH']};t=time.monotonic();timed=False;child=None
try:
 child=subprocess.Popen([node,str(p/'bounded-eof-probe.mjs')],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:out,err=child.communicate(timeout=12)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(child.pid,signal.SIGKILL);out,err=child.communicate(timeout=2)
except Exception as e:out=b'';err=repr(e).encode()
(p/(label+'.stdout')).write_bytes(out);(p/(label+'.stderr')).write_bytes(err);rows=[]
for line in out.decode(errors='replace').splitlines():
 try:rows.append(json.loads(line))
 except ValueError:pass
ends=[x for x in rows if x.get('event')=='end'];report={'label':label,'node':node,'gate_PATH_prefix':prefix,'outer_process_group_seconds':12,'child_pid':child.pid if child else None,'child_exit':child.returncode if child else None,'outer_deadline_reached':timed,'elapsed_seconds':time.monotonic()-t,'actual_input_sha256':hashlib.sha256((p/'ACTUAL-INPUTS.json').read_bytes()).hexdigest(),'exact_sentence_input_bytes':next((x['inputBytes'] for x in rows if x.get('name')=='exact-sentence-count' and x.get('event')=='start'),None),'exact_lint_input_bytes':next((x['inputBytes'] for x in rows if x.get('name')=='exact-small-lint' and x.get('event')=='start'),None),'completed_spawn_calls':len(ends),'spawn_error_rows':[x for x in ends if x.get('error') or x.get('status')!=0],'last_event':rows[-1] if rows else None,'stderr':err.decode(errors='replace'),'gate_processes_signaled':0,'app_changes':0};(p/(label+'.json')).write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(report,indent=2))
