# Actual clarified static junction-repair build

ONE root-released build completed exit0 in0.365s with nice10, single-thread environment and owned process-group60s deadline. No owned process remained. Source archive3f4014cec1, algorithm0d046d63 and controls cbcfd75f were hash-verified before invocation. No retry, browser, old rig/clip/socket carryover or tracked mutation occurred.

- Actual GLB593,688B, SHA256 `772dab7c1b9ee2bebbf0aba3d75049835c45044540ef06e3b58b522ba5add296`.
- Manifest:12,306vertices/24,608triangles/6material batches, zero clips/joints/sockets.
- Accessor bounds: X±.2890503767, Y0..2.1181770833, Z−.8883289931..1.2844447700m.
- Root definition: ground below the equal arithmetic mean of four authored sole-center controls. This does not claim actual sole-vertex centroid0; the same independent decoded readback metric remains mandatory.
- Nonuniform aperture angles intentionally propagate through the lower legs/hooves; retained radii/centers do not imply unchanged sampled surfaces.

Export success is **not a geometry, anatomy, appearance or photographic pass**. Independent actual vertex-link/manifold/normal/finite/index/scale/sole and all-proper-intersections readback is mandatory before any normal appearance preview. Original failed4fa3 mesh and586 actual crossings/witnesses remain unchanged failure evidence. Only source/export stage completed here. Logs/terminal: sibling `/workspace/shared/horse-anatomical-static-junction-repair-first-run-20261022/`.
