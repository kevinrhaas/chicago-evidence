# SPDX-License-Identifier: CC0-1.0
"""Linux-only owned-descendant cleanup, including detached Playwright Chromium.

This process becomes a child subreaper and starts exactly one owned child. PID and
start-time pairs prevent signaling reused PIDs. Other agents' browser processes
are outside this ancestry and are never targeted. No browser is launched here.
"""
import ctypes, json, os, pathlib, signal, subprocess, time

def read_process(pid):
 try:
  data=(pathlib.Path('/proc')/str(pid)/'stat').read_text();tail=data.rsplit(')',1)[1].split()
  return {'pid':int(pid),'state':tail[0],'ppid':int(tail[1]),'pgid':int(tail[2]),'start_time_ticks':int(tail[19])}
 except (OSError,ValueError,IndexError):return None

def process_records():
 records={}
 for path in pathlib.Path('/proc').iterdir():
  if path.name.isdigit():
   record=read_process(int(path.name))
   if record:records[record['pid']]=record
 return records

def owned_descendants(owner):
 records=process_records();owned=set();parents={owner}
 while parents:
  children={pid for pid,record in records.items() if record['ppid'] in parents and pid not in owned}
  owned.update(children);parents=children
 return [records[pid] for pid in sorted(owned)]

def matching_signal(record,sig):
 current=read_process(record['pid'])
 if not current or current['start_time_ticks']!=record['start_time_ticks']:return False
 try:os.kill(record['pid'],sig);return True
 except ProcessLookupError:return False

def reap_adopted():
 result=[]
 while True:
  try:pid,status=os.waitpid(-1,os.WNOHANG)
  except ChildProcessError:break
  if pid==0:break
  result.append({'pid':pid,'status':status})
 return result

def run_owned(command,logdir,whole_timeout=180,execution_timeout=170):
 logdir=pathlib.Path(logdir);logdir.mkdir()
 libc=ctypes.CDLL(None,use_errno=True)
 if libc.prctl(36,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'PR_SET_CHILD_SUBREAPER failed; browser not launched')
 owner=os.getpid();started=time.monotonic()
 report={'status':'RUNNING','command':command,'whole_deadline_seconds':whole_timeout,'execution_timeout_seconds':execution_timeout,'supervisor_pid':owner,'subreaper_enabled':True,'ownership':'only descendants of this supervisor, including detached Chromium adopted as child subreaper; PID start-time identity checked','cleanup_signals':[]}
 oldterm=signal.getsignal(signal.SIGTERM)
 def interrupted(signum,frame):raise KeyboardInterrupt('Supervisor interrupted')
 signal.signal(signal.SIGTERM,interrupted)
 child=None
 try:
  with (logdir/'capture.stdout').open('wb') as stdout,(logdir/'capture.stderr').open('wb') as stderr:
   child=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True)
   report['owned_node_pid']=child.pid;report['owned_node_pgid']=child.pid
   try:
    child.wait(timeout=execution_timeout);report['status']='TERMINAL';report['exit_code']=child.returncode
   except subprocess.TimeoutExpired:report['status']='TIMEOUT';report['exit_code']=124
   except BaseException as exc:report['status']='INTERRUPTED';report['exit_code']=130;report['interruption']=repr(exc)
   finally:
    report['cleanup_initial_descendants']=owned_descendants(owner)
    term_deadline=min(started+whole_timeout-2,time.monotonic()+2)
    while True:
     descendants=owned_descendants(owner);active=[r for r in descendants if r['state']!='Z']
     if not active:break
     for record in reversed(active):
      if matching_signal(record,signal.SIGTERM):report['cleanup_signals'].append({'signal':'SIGTERM',**record})
     if child.poll() is not None:report.setdefault('reaped_adopted_children',[]).extend(reap_adopted())
     if time.monotonic()>=term_deadline:break
     time.sleep(.05)
    for record in reversed(owned_descendants(owner)):
     if record['state']!='Z' and matching_signal(record,signal.SIGKILL):report['cleanup_signals'].append({'signal':'SIGKILL',**record})
    try:child.wait(timeout=max(.05,started+whole_timeout-time.monotonic()))
    except subprocess.TimeoutExpired:report['owned_node_wait_timeout']=True
    if child.poll() is not None:report.setdefault('reaped_adopted_children',[]).extend(reap_adopted())
    report['remaining_owned_active_pids']=[r for r in owned_descendants(owner) if r['state']!='Z']
    if report['remaining_owned_active_pids']:report['status']='FAILED owned cleanup';report['exit_code']=125
 except BaseException as exc:
  report['status']='FAILED supervisor/launch';report['exit_code']=1;report['error']=repr(exc)
 finally:
  signal.signal(signal.SIGTERM,oldterm)
  report['elapsed_seconds']=time.monotonic()-started
  (logdir/'terminal.json').write_text(json.dumps(report,indent=2)+'\n')
 return report
