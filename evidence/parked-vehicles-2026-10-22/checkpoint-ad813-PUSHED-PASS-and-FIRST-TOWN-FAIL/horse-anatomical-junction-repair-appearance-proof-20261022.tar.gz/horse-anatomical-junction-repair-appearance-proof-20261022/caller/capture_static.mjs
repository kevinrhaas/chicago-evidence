// SPDX-License-Identifier: CC0-1.0
// Source-only preparation. Requires root's explicit GPU-lane release before run.
import {createServer} from 'node:http';import fs from 'node:fs/promises';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const model='/workspace/shared/horse-anatomical-static-junction-repair-first-20261022';
const vendor='/workspace/chicago/chicago/4d/renderers/web/vendor';
const want='772dab7c1b9ee2bebbf0aba3d75049835c45044540ef06e3b58b522ba5add296';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const readbackBytes=await fs.readFile(path.join(here,'INDEPENDENT-READBACK.json'));
if(sha(readbackBytes)!=='ca8ceb43d603642047b9cf033c5ac02b8e372b994a2f8abf4c3af6c0cd4dbde1')throw Error('Independent readback pin changed');
const readback=JSON.parse(readbackBytes);
if(readback.GLB_sha256!==want||readback.bad_edge_count!==0||readback.bad_vertex_links.length!==0||readback.proper_intersection_screen.actual_proper_crossing_pairs!==0)throw Error('Actual static specimen not cleared for appearance review');
const args=process.argv.slice(2);
if(args.length!==3||args[0]!=='--lane-released'||args[1]!=='--output-dir')throw Error('After root release: --lane-released --output-dir <new-directory>');
const out=path.resolve(args[2]);
const manifestBytes=await fs.readFile(path.join(model,'manifest.json'));
if(sha(manifestBytes)!=='4f3b0a6427ab81375dbac398c685addb61deb7df692a61247faedcebca61b54f')throw Error('Actual build manifest pin changed');
const baselineReceipt=JSON.parse(await fs.readFile('/workspace/shared/horse-installed-baseline-20261022-first/receipt.json','utf8'));
const glb=await fs.readFile(path.join(model,'horse-anatomical-static-unaccepted.glb'));
if(glb.length!==593688||sha(glb)!==want)throw Error('Candidate pin changed');
await fs.mkdir(out,{recursive:false});
const report={status:'RUNNING',scope:'UNACCEPTED static anatomy preview only; no production/photographic/rig/tack qualification',model_sha256:want,model_bytes:glb.length,errors:[],served:[],views:[],caller_sha256:sha(await fs.readFile(new URL(import.meta.url)))};
let browser,server;
try{
 const allowed=new Map([['/candidate/',path.join(here,'index.html')],['/candidate/index.html',path.join(here,'index.html')],['/candidate/demo.js',path.join(here,'demo.js')],['/candidate/horse.glb',path.join(model,'horse-anatomical-static-unaccepted.glb')],['/candidate/manifest.json',path.join(model,'manifest.json')]]);
 const mime={'.html':'text/html','.js':'text/javascript','.json':'application/json','.glb':'model/gltf-binary'};
 server=createServer(async(req,res)=>{try{const name=decodeURIComponent(new URL(req.url,'http://localhost').pathname);let file=allowed.get(name);if(!file&&name.startsWith('/vendor/')){file=path.resolve(vendor,name.slice('/vendor/'.length));if(!file.startsWith(vendor+path.sep))throw Error('Path escape');}if(!file)throw Error('Route unavailable');const bytes=await fs.readFile(file);if(name==='/candidate/horse.glb'){if(sha(bytes)!==want)throw Error('Candidate served pin changed');report.served.push({path:name,sha256:sha(bytes),bytes:bytes.length});}res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'});res.end(bytes);}catch{res.writeHead(404);res.end('Unavailable');}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 const {chromium}=await import('/workspace/shared/chicago-browser/node_modules/playwright/index.mjs');
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const origin=`http://127.0.0.1:${server.address().port}`;
 for(const viewport of [{width:1280,height:800},{width:390,height:780}]){
  const page=await browser.newPage({viewport,deviceScaleFactor:1,reducedMotion:'reduce'});page.on('pageerror',e=>report.errors.push(String(e)));page.on('response',r=>{if(r.status()>=400&&!r.url().endsWith('/favicon.ico'))report.errors.push(`HTTP ${r.status()} ${r.url()}`);});
  await page.goto(origin+'/candidate/',{waitUntil:'networkidle',timeout:45000});await page.waitForFunction(()=>window.fixture?.ready,null,{timeout:30000});
  for(const view of ['side','three-quarter']){
   await page.selectOption('#view',view);await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   const info=await page.evaluate(()=>{const f=window.fixture;f.horse.updateMatrixWorld(true);f.camera.updateMatrixWorld(true);const framing={indexed_vertex_samples:0,outside_clip_volume:0,ndc_min:[Infinity,Infinity,Infinity],ndc_max:[-Infinity,-Infinity,-Infinity]};const q=f.camera.position.clone();f.horse.traverse(m=>{if(!m.isMesh)return;const attribute=m.geometry.attributes.position;const ids=m.geometry.index?new Set(m.geometry.index.array):Array.from({length:attribute.count},(_,i)=>i);for(const i of ids){q.fromBufferAttribute(attribute,i).applyMatrix4(m.matrixWorld).project(f.camera);const xyz=q.toArray();framing.indexed_vertex_samples++;if(xyz.some(v=>!Number.isFinite(v))||Math.abs(xyz[0])>.995||Math.abs(xyz[1])>.995||xyz[2]<-1||xyz[2]>1)framing.outside_clip_volume++;for(let k=0;k<3;k++){framing.ndc_min[k]=Math.min(framing.ndc_min[k],xyz[k]);framing.ndc_max[k]=Math.max(framing.ndc_max[k],xyz[k]);}}});return{framing,camera:{position:f.camera.position.toArray(),quaternion:f.camera.quaternion.toArray(),projection:f.camera.projectionMatrix.toArray()},renderer:{draw_calls:f.renderer.info.render.calls,triangles:f.renderer.info.render.triangles},bounds:{min:f.bounds.min.toArray(),max:f.bounds.max.toArray()},manifest:{triangles:f.manifest.triangles,draws:f.manifest.draws,vertices:f.manifest.vertices,bytes:f.manifest.bytes,skin_joints:f.manifest.skin_joints,animations:f.manifest.animations,sockets:f.manifest.sockets}};});
   if(info.framing.outside_clip_volume!==0)throw Error('Actual indexed model vertices outside fixed baseline clip volume; do not reframe');
   const reference=baselineReceipt.views.find(r=>r.viewport.width===viewport.width&&r.viewport.height===viewport.height&&r.view===view);
   if(!reference)throw Error('Missing actual installed baseline camera');
   for(const property of ['position','quaternion','projection'])if(info.camera[property].some((v,i)=>Math.abs(v-reference.camera[property][i])>1e-12))throw Error('Camera differs from recorded baseline: '+property);
   const filename=`${viewport.width}-${view}.png`;const png=await page.screenshot({path:path.join(out,filename),fullPage:true});report.views.push({viewport,view,file:filename,sha256:sha(png),...info});
  }await page.close();
 }
 if(report.errors.length)throw Error('Page/network errors');
 if(report.views.length!==4||report.served.length!==2)throw Error('Incomplete actual capture');
 report.status='CAPTURED four actual matched views; appearance UNREVIEWED';
}catch(e){report.status='FAILED first static capture';report.errors.push(String(e.stack||e));process.exitCode=1;}
finally{if(browser)await browser.close();if(server)await new Promise(r=>server.close(r));await fs.writeFile(path.join(out,'receipt.json'),JSON.stringify(report,null,2)+'\n');}
