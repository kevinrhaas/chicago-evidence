# SPDX-License-Identifier: CC0-1.0
"""Prepared only. Root must explicitly release GPU lane before invocation."""
import json,pathlib,sys
from ownership_supervisor import run_owned

def main():
 here=pathlib.Path(__file__).resolve().parent
 if sys.argv[1:]!=['--lane-released']:raise SystemExit('Require root GPU-lane release: --lane-released')
 output='/workspace/shared/horse-anatomical-junction-repair-first-views-20261022'
 if pathlib.Path(output).exists():raise SystemExit('Refuse existing capture output')
 command=['node',str(here/'capture_static.mjs'),'--lane-released','--output-dir',output]
 report=run_owned(command,here/'actual-first-run',whole_timeout=180,execution_timeout=170)
 print(json.dumps(report,indent=2));print('STDERR:',(here/'actual-first-run/capture.stderr').read_text());raise SystemExit(report['exit_code'])
if __name__=='__main__':main()
