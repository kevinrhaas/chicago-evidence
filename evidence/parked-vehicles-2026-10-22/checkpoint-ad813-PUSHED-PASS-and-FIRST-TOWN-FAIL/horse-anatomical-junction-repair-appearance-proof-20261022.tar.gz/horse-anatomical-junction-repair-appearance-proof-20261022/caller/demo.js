// SPDX-License-Identifier: CC0-1.0
// Unexecuted static preview caller. Baseline light, ground and side/quarter cameras.
import * as THREE from 'three';
import {GLTFLoader} from '/vendor/three-0.185.1/addons/loaders/GLTFLoader.js';
const viewportHeight=()=>innerWidth<500?Math.max(200,innerHeight-270):innerHeight;
const scene=new THREE.Scene();scene.background=new THREE.Color('#d9ddd8');
const camera=new THREE.PerspectiveCamera(38,innerWidth/viewportHeight(),.01,100);
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setSize(innerWidth,viewportHeight());renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.shadowMap.enabled=true;renderer.outputColorSpace=THREE.SRGBColorSpace;document.body.append(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xeaf2ff,0x70634d,2.2));const sun=new THREE.DirectionalLight(0xffedda,3);sun.position.set(3,6,4);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);sun.shadow.camera.left=-3;sun.shadow.camera.right=3;sun.shadow.camera.top=3;sun.shadow.camera.bottom=-3;sun.shadow.normalBias=.02;scene.add(sun);
const floor=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.MeshStandardMaterial({color:0xb5b9ab,roughness:1}));floor.rotation.x=-Math.PI/2;floor.position.y=-.003;floor.receiveShadow=true;scene.add(floor);
const ground=new THREE.GridHelper(12,48,0xa3ad9f,0xa3ad9f);ground.position.y=.001;scene.add(ground);
function setView(name){const look=new THREE.Vector3(0,1,0);if(name==='side')camera.position.set(4.5,1.7,0);else if(name==='front')camera.position.set(0,1.65,5);else if(name==='head'){camera.position.set(.85,1.95,1.75);look.set(0,1.82,.91);}else camera.position.set(3.5,2.25,3.8);if(innerWidth<500&&name!=='head')camera.position.multiplyScalar(1.45);camera.lookAt(look);}
setView('three-quarter');document.querySelector('#view').onchange=()=>setView(document.querySelector('#view').value);
const manifest=await fetch('/candidate/manifest.json').then(r=>{if(!r.ok)throw Error('Manifest load failed');return r.json();});
const g=await new GLTFLoader().loadAsync('/candidate/horse.glb');const horse=g.scene;scene.add(horse);
if(g.animations.length)throw Error('Unexpected animation in static specimen');
horse.traverse(o=>{if(o.isSkinnedMesh)throw Error('Unexpected rigged mesh in static specimen');if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});
horse.updateMatrixWorld(true);window.fixture={ready:true,manifest,scene,horse,renderer,camera,setView,bounds:new THREE.Box3().setFromObject(horse)};
function tick(){requestAnimationFrame(tick);renderer.render(scene,camera);document.querySelector('#stats').textContent=`Static · ${manifest.triangles.toLocaleString()} model triangles\n${manifest.draws} material batches · no rig, gait or fit acceptance`;}
requestAnimationFrame(tick);
onresize=()=>{camera.aspect=innerWidth/viewportHeight();camera.updateProjectionMatrix();renderer.setSize(innerWidth,viewportHeight());setView(document.querySelector('#view').value);};
