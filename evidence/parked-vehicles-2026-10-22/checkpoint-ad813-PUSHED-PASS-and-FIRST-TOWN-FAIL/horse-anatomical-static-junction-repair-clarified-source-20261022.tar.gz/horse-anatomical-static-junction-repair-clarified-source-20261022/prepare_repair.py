# SPDX-License-Identifier: CC0-1.0
"""Prepare source/controls only against the exact failed first-build inputs."""
from pathlib import Path
import json,hashlib,difflib,ast
here=Path(__file__).resolve().parent;out=here/'proposed';out.mkdir(exist_ok=True)
old=Path('/workspace/shared/horse-anatomical-master-authoring-next-20261022')
raw=(old/'anatomy-authoring-controls.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='646a5eadd4724e20d5d84d0fca168b6bfa4afa5aa7e68c8cdffd3bb0197bf58b'
c=json.loads(raw)
for hole in c['body_root_holes']:hole['circumferential_columns']=[12,13,14] if hole['part'].endswith('_l') else [9,10,11]
# Upper-arm/thigh muscles are represented by the retained torso/root aperture,
# not a horizontal ring embedded inside it. The first child rings sit below the
# exact minimum of each lower aperture after an18mm outward/downward collar.
c['fore_l']=[[.205,.84,.31,.105,.085],[.205,.76,.33,.075,.080]]+c['fore_l'][3:]
c['hind_l']=[[.205,.80,-.49,.115,.120]]+c['hind_l'][3:]
c['fore_l_landmarks']=['lower_upper_arm_surface','forearm','carpus','metacarpal_mid','fetlock','pastern','coronet','hoof_wall','sole']
c['hind_l_landmarks']=['lower_thigh_surface','gaskin','hock','metatarsal_mid','fetlock','pastern','coronet','hoof_wall','sole']
c['profile_centers_are_not_all_bone_joint_centers']=True
c['skeletal_landmark_hypotheses_left_m']={'scapula':[.20,1.36,.30],'shoulder_joint':[.20,1.23,.39],'elbow':[.20,1.03,.22],'carpus':[.20,.50,.40],'hip':[.20,1.30,-.65],'stifle':[.20,.90,-.37],'hock':[.20,.49,-.76]}
c['skeletal_landmark_status']='Separate bounded anatomical hypotheses, not a skinned rig, fitted attachments or external surface-profile centers. T2803 must review them.'
c['limb_aperture_collar_m']=.018
c['nostril_authoring']['left_columns']=[15,0];c['nostril_authoring']['right_columns']=[7,8]
for key in ['left_column','right_column','center_y_m','center_z_m','outer_x_m','cavity_x_m','half_height_m','half_length_m']:c['nostril_authoring'].pop(key)
c['nostril_authoring']['cup_sections']=[{'contraction':.82,'normal_offset_m':.0015,'material':4},{'contraction':.64,'normal_offset_m':-.006,'material':4},{'contraction':.35,'normal_offset_m':-.014,'material':1},{'contraction':.12,'normal_offset_m':-.017,'material':1}]
c['nostril_authoring']['target']='Boundary-conforming nested homothetic aperture cups; projected contour remains inside its real opening, with inward local-normal depth.'
# Fix the independently measured40mm source-datum mismatch INSIDE all authored
# coordinate controls. This is not a runtime node/scene translation or a y lift.
shift=.04
for key in ['body_profile','fore_l','hind_l']:
 for row in c[key]:row[2]+=shift
for key in ['ear_authoring','eye_authoring']:
 field='root_center_z_m' if key=='ear_authoring' else 'center_z_m';c[key][field]+=shift
for row in c['proposed_contacts_m'].values():row[2]+=shift
for row in c['skeletal_landmark_hypotheses_left_m'].values():row[2]+=shift
c['source_frame_amendment']={'old_support_midpoint_m':[0,0,-.04],'authored_coordinate_shift_m':[0,0,.04],'runtime_node_translation':[0,0,0],'new_support_midpoint_m':[0,0,0],'reason':'Correct false support-midpoint origin declaration in first source. All authoring controls shift consistently; no scene offset/rescale/y lift.'}
c['amendments_to_bad_baseline']=[('Contact points after explicit40mm source-datum correction: fore left[.20,0,.52], hind left[.20,0,-.52], mirrored right. This combines the prior stance reconstruction and the frame correction; no y offset or runtime transform.' if text.startswith('Contact points intentionally move:') else text) for text in c['amendments_to_bad_baseline']]
c['schema']='original_equine_control_cage_authoring_v0.2_junction_repair_unexecuted'
c['status']='Unexecuted source correction to actual first4fa3 folded mesh; no geometry/collision/visual acceptance'
c['amendments_to_bad_baseline'].append('First static4fa3 source failed586 actual proper crossings. Replace lateral limb ports/embedded root rings with lower ports, aperture collar and ordered below-trunk profiles; use contracted boundary-derived nostril cups. Whole sourceZ datum shifts+40mm to put true support midpoint at root0.')
# Clarification only: keep geometry/algorithm unchanged. The datum is the mean
# of four authored sole-center controls, not mean of sampled/subdivided vertices.
c['frame']['root_origin']='ground below arithmetic mean of four authored sole-center controls'
c['frame']['datum_definition']='four proposed_contacts_m controls, each weighted equally; actual sole-vertex centroid is measured separately'
c['source_frame_amendment']['old_authored_sole_center_control_mean_m']=c['source_frame_amendment'].pop('old_support_midpoint_m')
c['source_frame_amendment']['new_authored_sole_center_control_mean_m']=c['source_frame_amendment'].pop('new_support_midpoint_m')
c['source_frame_amendment']['actual_sole_vertex_centroid_status']='UNMEASURED for the next subdivided export; retain the same decoded sole-vertex-mean readback metric, without redefining it as control centers'
c['source_frame_amendment']['reason']='Put arithmetic mean of four authored sole-center controls at source root0. All controls shift consistently; no scene offset/rescale/y lift. This does not imply zero sampled or subdivided sole-vertex mean.'
c['downstream_sampling_amendment']={'method':'ordered irregular aperture angles are reused through every lower-limb/hoof profile','scope':'center/radius values may be retained but angular samples and resulting lower-limb/hoof surface geometry change; no exact lower-mesh shape preservation claim','source_only_predicted_fore_sole_ring_mean_z_m':.5217443474,'source_only_predicted_hind_sole_ring_mean_z_m':-.5205637468,'source_only_predicted_four_ring_sample_mean_z_m':.0005903003,'prediction_limit':'not actual subdivided sole-vertex centroid; decoded readback required'}
c['amendments_to_bad_baseline']=[text.replace('to put true support midpoint at root0','to put the mean of four authored sole-center controls at root0; actual sole-vertex centroid is separately measured') for text in c['amendments_to_bad_baseline']]
(out/'anatomy-authoring-controls.json').write_text(json.dumps(c,indent=2)+'\n')
s=(old/'quad_cage_authoring.py').read_text();before=s
helper='''
def aperture_normal(cage,loop):
 # Newell normal of the real removed-face perimeter. Source winding is retained;
 # global orientation repair is not used to pretend an embedding is correct.
 n=[0.,0.,0.]
 for a,b in zip(loop,loop[1:]+loop[:1]):
  p,q=cage.v[a],cage.v[b]
  n[0]+=(p[1]-q[1])*(p[2]+q[2]);n[1]+=(p[2]-q[2])*(p[0]+q[0]);n[2]+=(p[0]-q[0])*(p[1]+q[1])
 L=length(n)
 if L<1e-10:raise ValueError('Collapsed aperture normal')
 return tuple(x/L for x in n)

def ordered_aperture_angles(cage,loop,u,v):
 # Keep the exact cyclic source order. The failed generic least-distance frame
 # could choose either winding; it never certified a nonfolded bridge.
 points=[cage.v[i] for i in loop];center=average(points)
 projected=[(sum((p[k]-center[k])*u[k] for k in range(3)),sum((p[k]-center[k])*v[k] for k in range(3))) for p in points]
 area=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(projected,projected[1:]+projected[:1]))
 if abs(area)<1e-10:raise ValueError('Aperture projection collapsed')
 sign=1 if area>0 else -1;rx=max(abs(p[0]) for p in projected);ry=max(abs(p[1]) for p in projected)
 if min(rx,ry)<1e-8:raise ValueError('Thin aperture projection')
 raw=[math.atan2(y/ry,x/rx) for x,y in projected];angles=[raw[0]]
 for value in raw[1:]:
  while sign*(value-angles[-1])<=1e-10:value+=sign*2*math.pi
  if sign*(value-angles[-1])>=math.pi:raise ValueError('Non-star-shaped aperture order')
  angles.append(value)
 gap=sign*(angles[0]+sign*2*math.pi-angles[-1])
 if not 1e-10<gap<math.pi:raise ValueError('Aperture angular cycle folds')
 return angles

def outside_aperture_collar(cage,loop,distance,region):
 normal=aperture_normal(cage,loop)
 if normal[1]>=-.2:raise ValueError('Limb port must face below/outside trunk')
 ring=[cage.vertex(tuple(cage.v[i][k]+distance*normal[k] for k in range(3))) for i in loop]
 cage.bridge(loop,ring,0,region)
 return ring

def inset_aperture_cup(cage,loop,sections,region):
 # Each projected ring is a strict homothetic contraction of the ACTUAL opening;
 # normal recession adds no tangential relocation. No unrelated ellipse is fit.
 points=[cage.v[i] for i in loop];center=average(points);normal=aperture_normal(cage,loop)
 for a,b in zip(points,points[1:]+points[:1]):
  fan=cross(sub(a,center),sub(b,center))
  if sum(fan[k]*normal[k] for k in range(3))<=1e-10:raise ValueError('Aperture center must lie in strict projected kernel')
 previous=1.
 for section in sections:
  scale=section['contraction'];offset=section['normal_offset_m']
  if not 0<scale<previous:raise ValueError('Cup rings must contract strictly')
  ring=[cage.vertex(tuple(center[k]+scale*(p[k]-center[k])+offset*normal[k] for k in range(3))) for p in points]
  cage.bridge(loop,ring,section['material'],region);loop=ring;previous=scale
 cage.face(list(reversed(loop)),sections[-1]['material'],region)
'''
anchor='\ndef attach(cage,loop,profile,u,v,region,material_at=lambda j:0,warps=None,per_faces=None,sole=False):'
assert anchor in s
s=s.replace(anchor,helper+'\ndef attach(cage,loop,profile,u,v,region,material_at=lambda j:0,warps=None,per_faces=None,sole=False,angles_override=None):')
s=s.replace(" angles=min(options,key=lambda item:item[0])[1]", " angles=angles_override if angles_override is not None else min(options,key=lambda item:item[0])[1]")
oldblock="""  hoof_start=len(profile)-3
  attach(cage,loop,profile,(1,0,0),(0,0,1),name,lambda j:2 if j>=hoof_start else 0,sole=True)"""
newblock="""  loop=outside_aperture_collar(cage,loop,c['limb_aperture_collar_m'],name)
  if min(cage.v[i][1] for i in loop)<=profile[0][1]+.005:raise ValueError('First limb ring must be below whole aperture collar')
  angles=ordered_aperture_angles(cage,loop,(1,0,0),(0,0,1))
  hoof_start=len(profile)-3
  attach(cage,loop,profile,(1,0,0),(0,0,1),name,lambda j:2 if j>=hoof_start else 0,sole=True,angles_override=angles)"""
assert oldblock in s;s=s.replace(oldblock,newblock)
a=s.index(" for side,column in [(1,nose['left_column'])");b=s.index(' cage.orient_closed()',a)
s=s[:a]+""" for side,columns in [(1,nose['left_columns']),(-1,nose['right_columns'])]:
  loop=cage.split_boundary(cage.remove_patch([grid[nose['root_body_interval'],col] for col in columns]))
  inset_aperture_cup(cage,loop,nose['cup_sections'],'nostril_'+str(side))
"""+s[b:]
ast.parse(s);(out/'quad_cage_authoring.py').write_text(s)
(here/'JUNCTION-REPAIR.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='a/quad_cage_authoring.py',tofile='b/quad_cage_authoring.py')))
print(json.dumps({'status':'source/control correction prepared; build/subdivision/export NOT run','new_source_sha256':hashlib.sha256(s.encode()).hexdigest(),'new_controls_sha256':hashlib.sha256((out/'anatomy-authoring-controls.json').read_bytes()).hexdigest()},indent=2))
