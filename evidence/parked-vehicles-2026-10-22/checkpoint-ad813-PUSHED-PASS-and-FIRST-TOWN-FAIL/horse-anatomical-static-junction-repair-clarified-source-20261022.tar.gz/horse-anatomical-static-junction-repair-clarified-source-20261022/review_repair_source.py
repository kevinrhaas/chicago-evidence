# SPDX-License-Identifier: CC0-1.0
"""Finite coordinate/control review only. NEVER calls Cage/build/subdivision/export."""
from pathlib import Path
import ast,collections,hashlib,json,math
here=Path(__file__).resolve().parent;source=here/'proposed';c=json.loads((source/'anatomy-authoring-controls.json').read_text());text=(source/'quad_cage_authoring.py').read_text();tree=ast.parse(text)
allowed={'average','cross','sub','length','aperture_normal','ordered_aperture_angles'}
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in allowed];ns={'math':math}
exec(compile(ast.Module(body=functions,type_ignores=[]),'<pure-aperture-coordinate-functions>','exec'),ns)
class CoordinatesOnly:
 def __init__(self,v):self.v=v
 def vertex(self,*a):raise RuntimeError('Geometry creation prohibited in source review')
 def face(self,*a):raise RuntimeError('Geometry creation prohibited in source review')
N=c['body_sides']
def point(j,k):
 x,y,z,rx,ry=c['body_profile'][j];t=k*2*math.pi/N;return [x+rx*math.cos(t),y+ry*math.sin(t),z]
def opening(j,cols,split=False):
 fs=[[(j,k),(j,(k+1)%N),(j+1,(k+1)%N),(j+1,k)] for k in cols];es=[(a,b) for f in fs for a,b in zip(f,f[1:]+f[:1])];counts=collections.Counter(tuple(sorted(e)) for e in es);boundary=[(a,b) for a,b in es if counts[tuple(sorted((a,b)))]==1];nxt=dict(boundary);seq=[boundary[0][0]]
 while nxt[seq[-1]]!=seq[0]:seq.append(nxt[seq[-1]])
 ps=[point(j,k) for j,k in seq]
 if split:
  expanded=[]
  for a,b in zip(ps,ps[1:]+ps[:1]):expanded.extend([a,ns['average']([a,b])])
  ps=expanded
 return ps
def trunk_floor(z):
 for a,b in zip(c['body_profile'],c['body_profile'][1:]):
  if a[2]-1e-12<=z<=b[2]+1e-12:
   t=(z-a[2])/(b[2]-a[2]);return (a[1]-a[4])*(1-t)+(b[1]-b[4])*t
 raise ValueError('Coordinate outside trunk')
checks={'source_AST_parses_without_build':True};limbs=[]
for h in c['body_root_holes']:
 ps=opening(h['body_interval'],h['circumferential_columns']);obj=CoordinatesOnly(ps);loop=list(range(len(ps)));n=ns['aperture_normal'](obj,loop);collar=[[p[k]+c['limb_aperture_collar_m']*n[k] for k in range(3)] for p in ps];angles=ns['ordered_aperture_angles'](CoordinatesOnly(collar),loop,(1,0,0),(0,0,1));rows=c['fore_l' if h['part'].startswith('fore') else 'hind_l'];first=rows[0];low=min(p[1] for p in collar);zlo,zhi=first[2]-first[4],first[2]+first[4];breaks=[zlo,zhi]+[p[2] for p in c['body_profile'] if zlo<p[2]<zhi];floor=min(trunk_floor(z) for z in breaks)
 limbs.append({'region':h['part'],'aperture_unit_normal':n,'collar_min_y_m':low,'first_profile_y_m':first[1],'collar_to_profile_y_gap_m':low-first[1],'original_trunk_min_floor_over_profile_z_m':floor,'profile_below_original_floor_gap_m':floor-first[1],'angular_order_radians':angles,'all_child_ring_y_strictly_descending':all(a[1]>b[1] for a,b in zip(rows,rows[1:]))})
checks['all_limb_apertures_face_down_outside']=all(r['aperture_unit_normal'][1]<-.2 for r in limbs)
checks['first_rings_below_entire_collar_by_more_than_5mm']=all(r['collar_to_profile_y_gap_m']>.005 for r in limbs)
checks['first_rings_below_original_trunk_envelope']=all(r['profile_below_original_floor_gap_m']>0 for r in limbs)
checks['all_child_profile_heights_strictly_descending']=all(r['all_child_ring_y_strictly_descending'] for r in limbs)
nose=c['nostril_authoring'];cups=[]
for side,key in [(1,'left_columns'),(-1,'right_columns')]:
 ps=opening(nose['root_body_interval'],nose[key],True);obj=CoordinatesOnly(ps);loop=list(range(len(ps)));normal=ns['aperture_normal'](obj,loop);center=ns['average'](ps);margins=[]
 for a,b in zip(ps,ps[1:]+ps[:1]):
  fan=ns['cross'](ns['sub'](a,center),ns['sub'](b,center));margins.append(sum(fan[k]*normal[k] for k in range(3)))
 cups.append({'side':side,'source_aperture_vertices':len(ps),'strict_projected_kernel_fan_area_min_m2':min(margins),'normal':normal})
checks['nostril_aperture_centers_in_strict_projected_kernel']=all(x['strict_projected_kernel_fan_area_min_m2']>1e-10 for x in cups)
scales=[1]+[x['contraction'] for x in nose['cup_sections']]
checks['nostril_ring_contractions_strict_and_positive']=all(0<b<a for a,b in zip(scales,scales[1:]))
checks['four_authored_sole_center_controls_mean_zero']=all(abs(sum(row[k] for row in c['proposed_contacts_m'].values())/4)<1e-12 for k in range(3))
checks['right_aperture_columns_reflect_left']=all(set(next(h['circumferential_columns'] for h in c['body_root_holes'] if h['part']==name+'_r'))=={(N//2-k-1)%N for k in next(h['circumferential_columns'] for h in c['body_root_holes'] if h['part']==name+'_l')} for name in ['fore','hind'])
checks['profile_centers_distinguished_from_bone_landmarks']=c['profile_centers_are_not_all_bone_joint_centers'] and 'skeletal_landmark_hypotheses_left_m' in c
report={'status':'PASS source-control hypotheses only' if all(checks.values()) else 'FAIL source-control review','scope':'Pure aperture/profile coordinate arithmetic and source AST; no full cage, subdivision, export, geometry intersection check or browser','checks':checks,'limb_control_evidence':limbs,'nostril_control_evidence':cups,'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'controls_sha256':hashlib.sha256((source/'anatomy-authoring-controls.json').read_bytes()).hexdigest(),'explicit_unproven':['post-subdivision vertex-link manifoldness','new source edge orientation','root/crotch embedding','self/interpart crossings','actual soles/axes/export','muscle volumes and photographic appearance']}
(here/'SOURCE-CORRECTION-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));raise SystemExit(0 if all(checks.values()) else 1)
