# T-2800 failed first mesh: concrete junction/cup source correction

## Blocking actual result preserved

The actual first static mesh **4fa3dce8** is **FAILED**, even though its exporter completed. Independent decoded readback found586 proper noncoplanar crossing triangle pairs, including shoulder/forelimb, croup/hindlimb, limb self-folds, nose/nostril and nostril self-folds. All11,778 vertex links are single cycles, all edges have two owners, Euler2 and all four soles have49 vertices at y0. This is a folded embedding, not a topological seam crack. Global winding or correct ground markers cannot waive real intersections.

The exact independent `READBACK.json` and16 region-pair crossing witnesses are copied under `failed-first-mesh-evidence/`. Original GLB/surface/manifest/terminal and frozen source remain unchanged. The first actual archive remains `/workspace/shared/horse-anatomical-static-first-actual-20261022.tar.gz`, SHA256 `332598b6b6e61d885cd6d2ea06aee9c2b399a47ff18b383dd2ad58daf93696d5`. The unexecuted4fa3 normal preview caller **must remain held**; no production/photographic or geometry-pass claim is allowed.

## Exact diagnosis, not parameter guessing

`OLD-PROFILE-DIAGNOSIS.json` evaluates only the failed source's small aperture/profile coordinate lists. It does not rebuild a cage or run subdivision/export.

- Fore first horizontal root ring:4/8 points inside the original trunk, including a point projected below a retained trunk face. Hind first root:5/8 inside, including two under retained trunk faces. The openings were narrow lateral YZ-like rectangles while the child rings lay in horizontalXZ atY1.17/1.20, inside the torso. The bridge entered surviving skin.
- Each old nostril's axis-aligned outer ellipse puts6/8 vertices outside the actual slanted single-quad YZ aperture, up to13.800056mm. Moving that unrelated contour inward then cuts across retained nose skin and folds the cup.
- The old least-distance cyclic mapping could choose either winding but certified only a distance score. Face orientation and manifold links already passed in the actual mesh, so flipping face winding is not a geometric correction. The issue is the position/order/embedding of the profiles.

These findings align with actual witnesses: croup/hind_l[1317,12858], withers_shoulder/fore_l[3150,7210], nose/nostril_1[6246,22110], nostril_1 self[21894,22120]. They remain genuine failures with independently certified crossing points/barycentric margins.

## Proposed source correction, not yet executed

The exact source and control amendments are under `proposed/`, with both patches and old/new hashes in `EXACT-PREIMAGES.json`.

1. Move limb ports from lateral sectors14,15,0 to **lower/ventral**12,13,14 on the left, with reflected9,10,11 on the right. Their normals now point below/outside the trunk. Axial fore/hind source intervals remain5/2. Left/right ports share the natural ventral boundary edge; that crotch junction needs actual post-build vertex-link and embedding review.
2. Add an18mm collar following each actual aperture normal and preserving its exact cyclic vertices. Set the first child horizontal rings below the entire collar and the original local trunk envelope: foreY.84 and hindY.80. Separate old embedded horizontal upper-muscle rings are retired; retained trunk/root patch represents upper-arm/thigh muscle. Source bone landmarks are recorded separately because not every skin-profile center is a joint.
3. Parameterize following limb rings by the actual aperture's strict cyclic angular order. Refuse collapsed/non-star-shaped projections. Do not select an opposite winding just because its Euclidean distance happens to be smaller. All following child profileY values strictly descend to the unchanged support plane. The irregular aperture angles propagate through every lower-leg/hoof ring, so their sampled vertices and resultant surface shapes intentionally change even where center/radius values are retained.
4. Give each nostril a two-quad opening around the side centerline. All cup contours are **strict homothetic contractions of the actual boundary** around its projected-kernel center, with local-normal recession. No independent axis-aligned ellipse or tangential recentering is introduced. Guard the projected kernel and strict contraction sequence before source export. Recession stages are+1.5mm outward rim, then−6/−14/−17mm inward, all original reconstruction dimensions.
5. Correct the false origin declaration explicitly. The first model's support mean wasZ−40mm although its frame said support midpoint0. Shift **all authored geometric controls and landmark/contact coordinates**+40mmZ so the four authored sole-center controls are fore±X.20,Z+.52 and hind±X.20,Z−.52, with their equal-weight arithmetic mean0. That defined control datum is distinct from the mean of sampled or subdivided sole vertices. GLB root stays identity. No runtime node/scene translation, rescale or y offset hides the discrepancy. This full-source coordinate amendment is separate from the local collision repair and must be reviewed as such.

Eyes, ears and body/neck controls retain their relative geometric input values except the declared common source-frame shift. Lower-limb/hoof centers and radii may retain their values, but the nonuniform angular samples alter those surfaces; no exact lower-geometry preservation is claimed. Hair/UV/PBR/LOD/rig/photo scope remains unfinished. No earlier fit or animation qualification transfers.

## Source-only evidence already checked

`SOURCE-CORRECTION-REVIEW.json` reports ten finite source-coordinate/AST checks:

- Port normals have negativeY (fore−.66776, hind−.77596).
- First child loops are below all collar vertices by27.980mm fore /16.033mm hind, and below the original local trunk lower envelope by43.611/37.143mm.
- Actual aperture angular cycles remain strictly ordered; child heights strictly descend; right ports reflect left.
- Nostril opening centers lie in the strict projected kernel; contour scales strictly decrease and stay positive.
- The four authored sole-center controls average to root0, and skin profiles are distinguished from skeletal landmark hypotheses. This is the explicitly defined datum, not a measurement of the actual sole-vertex mean. Independent source-only sampling predicts fore sole-ring meanZ+.5217443474m and hind−.5205637468m, overall+.0005903003m; this is not the unmeasured subdivided sole centroid.

These are source hypotheses, **not proof of the new subdivided surface**. Root/crotch folds, body intersections, post-subdivision vertex links, the revised nostril cups, normal/scale/sole readback and anatomy all remain UNPROVEN. The retained torso near the port can be moved by subdivision; the source envelope margin does not certify the final embedding or muscle appearance.

## Next finite step after independent review and root release

No rebuild/browser runs are authorized by this packet. Independent source review is requested from the existing confidence agent while root's gate runs. After explicit root release, one new outside-app build should use the pinned proposed source/controls, the same nice/single-thread <=60s owned deadline, and a new output directory. Stop on the first actual build failure; do not iterate parameters blindly.

Then run the unchanged independent actual topology/vertex-link/sole/finite/normal/intersection screen, with the original4fa3 mesh and exact positive witnesses retained as failure controls. A zero proper-crossing screen still does not prove no coplanar contact, containment or photographic anatomy. Only after the actual surface is clean enough for inspection should root release a correctly pinned static preview of the **new** output at the same cameras/light; the old4fa3 caller cannot be relabeled as the new result.

Root remains sole tracked app/ticket/Git writer. No app/ticket/mirror/Git changes, second cage build, GLB rewrite or browser execution occurred in this repair preparation.

## Clarified freeze

The original4b1996ac archive and first failed4fa3 mesh remain untouched. `CLARIFICATION-DELTA.json` independently asserts byte-identical authoring algorithm and unchanged numerical geometric controls. Only datum/sampling metadata and accompanying notes/source-check labels change. New source-control hash is recorded in `EXACT-PREIMAGES.json`; old source checks are preserved separately as `HISTORICAL-REPAIR-SOURCE-CHECKS.json`. The independent initial repair review is copied as `INDEPENDENT-REPAIR-SOURCE-REVIEW.md`; the reviewer must confirm this clarification delta before root releases one next build. No actual build/subdivision/export/readback/browser occurred.
