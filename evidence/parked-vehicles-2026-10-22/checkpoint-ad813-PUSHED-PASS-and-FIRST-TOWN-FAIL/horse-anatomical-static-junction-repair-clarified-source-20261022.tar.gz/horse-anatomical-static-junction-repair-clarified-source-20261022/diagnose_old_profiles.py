# SPDX-License-Identifier: CC0-1.0
"""Finite source-coordinate diagnosis only; does not run build/subdivision/export."""
from pathlib import Path
import collections,math,json,hashlib
here=Path(__file__).resolve().parent
old=Path('/workspace/shared/horse-anatomical-master-authoring-next-20261022')
c=json.loads((old/'anatomy-authoring-controls.json').read_text());N=c['body_sides']
def average(ps):return [sum(p[j] for p in ps)/len(ps) for j in range(3)]
def point(j,k):
 x,y,z,rx,ry=c['body_profile'][j];a=k*2*math.pi/N;return [x+rx*math.cos(a),y+ry*math.sin(a),z]
def aperture(j,cols,split=False):
 faces=[[(j,k),(j,(k+1)%N),(j+1,(k+1)%N),(j+1,k)] for k in cols]
 edges=[(a,b) for f in faces for a,b in zip(f,f[1:]+f[:1])];counts=collections.Counter(tuple(sorted(e)) for e in edges);boundary=[(a,b) for a,b in edges if counts[tuple(sorted((a,b)))]==1];nexts=dict(boundary);seq=[boundary[0][0]]
 while nexts[seq[-1]]!=seq[0]:seq.append(nexts[seq[-1]])
 pts=[point(j,k) for j,k in seq]
 if split:
  expanded=[]
  for a,b in zip(pts,pts[1:]+pts[:1]):expanded.extend([a,average([a,b])])
  pts=expanded
 return pts
def old_ring(loop,center,rx,ry,u,v):
 options=[];n=len(loop)
 for winding in [1,-1]:
  for phase in range(n):
   angles=[(phase+winding*k)*2*math.pi/n for k in range(n)]
   ps=[[center[j]+rx*math.cos(a)*u[j]+ry*math.sin(a)*v[j] for j in range(3)] for a in angles]
   options.append((sum(sum((a[j]-b[j])**2 for j in range(3)) for a,b in zip(loop,ps)),winding,phase,ps))
 return min(options,key=lambda x:x[0])
def original_trunk_coordinates(p):
 for j,(a,b) in enumerate(zip(c['body_profile'],c['body_profile'][1:])):
  if a[2]-1e-12<=p[2]<=b[2]+1e-12:
   t=(p[2]-a[2])/(b[2]-a[2]);y=a[1]*(1-t)+b[1]*t;rx=a[3]*(1-t)+b[3]*t;ry=a[4]*(1-t)+b[4]*t
   xx=p[0]/rx;yy=(p[1]-y)/ry
   return {'axial_interval':j,'ellipse_level':xx*xx+yy*yy,'theta_column':(math.atan2(yy,xx)%(2*math.pi))*N/(2*math.pi)}
 return None
def yz_margin(poly,p):
 # Independent signed half-plane distances for the convex actual aperture's
 # YZ projection. Its nonparallel edge shear is retained; no fitted ellipse.
 q=[(v[1],v[2]) for v in poly];area=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(q,q[1:]+q[:1]));sign=1 if area>0 else -1
 margins=[]
 for a,b in zip(q,q[1:]+q[:1]):
  ex=b[0]-a[0];ey=b[1]-a[1];L=math.hypot(ex,ey)
  margins.append(sign*(ex*(p[2]-a[1])-ey*(p[1]-a[0]))/L)
 return min(margins)
report={'scope':'Source-control coordinate diagnosis against the failed actual4fa3 mesh; not a new cage build, subdivision, surface collision trial or export','failed_glb_sha256':'4fa3dce85d53c10cf7b570519497a1759013e9cea7696a6d5237dcecaae9313d','limb_root_profiles':[],'nostril_profiles':[]}
for hole in c['body_root_holes']:
 name=hole['part'];s=1 if name.endswith('_l') else -1;row=c['fore_l' if name.startswith('fore') else 'hind_l'][0];center=[s*row[0],row[1],row[2]];loop=aperture(hole['body_interval'],hole['circumferential_columns']);score,winding,phase,ps=old_ring(loop,center,row[3],row[4],[1,0,0],[0,0,1]);inside=[]
 for k,p in enumerate(ps):
  local=original_trunk_coordinates(p)
  if local and local['ellipse_level']<1:
   projected_col=int(math.floor(local['theta_column']))%N
   retained=local['axial_interval']!=hole['body_interval'] or projected_col not in hole['circumferential_columns']
   inside.append({'ring_vertex':k,'point_m':p,'inside_original_trunk_level':local['ellipse_level'],'projected_trunk_face_retained':retained,'axial_interval':local['axial_interval'],'angular_column':projected_col})
 report['limb_root_profiles'].append({'region':name,'actual_aperture_control_points':loop,'source_first_profile_center':center,'first_profile_plane':'horizontalXZ versus lateral YZ-ish body aperture','chosen_old_winding':winding,'chosen_old_phase':phase,'first_profile_points_inside_trunk':inside})
n=c['nostril_authoring']
for s,col in [(1,n['left_column']),(-1,n['right_column'])]:
 loop=aperture(n['root_body_interval'],[col],split=True);center=[s*n['outer_x_m'],n['center_y_m'],n['center_z_m']];score,winding,phase,ps=old_ring(loop,center,n['half_height_m'],n['half_length_m'],[0,1,0],[0,0,1]);margins=[yz_margin(loop,p) for p in ps]
 report['nostril_profiles'].append({'region':'nostril_'+str(s),'actual_aperture_control_points':loop,'chosen_old_winding':winding,'chosen_old_phase':phase,'outer_ring_points':ps,'YZ_aperture_signed_margins_m':margins,'ring_vertices_projected_outside_real_aperture':sum(x< -1e-12 for x in margins),'worst_outside_distance_m':max(0,-min(margins))})
report['winding_conclusion']='The old least-distance cyclic frame is not an embedding proof. Global face orientation and single-cycle links passed on the actual mesh, but do not stop bridges entering retained skin. A face-winding flip cannot repair these actual folded surfaces.'
(here/'OLD-PROFILE-DIAGNOSIS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'limb_inside_counts':{r['region']:len(r['first_profile_points_inside_trunk']) for r in report['limb_root_profiles']},'limb_inside_under_retained_face_counts':{r['region']:sum(p['projected_trunk_face_retained'] for p in r['first_profile_points_inside_trunk']) for r in report['limb_root_profiles']},'nostril_outside_aperture_counts':{r['region']:r['ring_vertices_projected_outside_real_aperture'] for r in report['nostril_profiles']},'nostril_max_outside_m':report['nostril_profiles'][0]['worst_outside_distance_m']},indent=2))
