# Independent source review: static horse junction repair

Verdict: CLEAR FOR ONE finite next static build, after root separately frees the heavy lane and releases these exact inputs. This is a mechanically credible source experiment, not proof of a valid embedded surface or approval for a browser preview. No geometry build, subdivision, export, browser or tracked mutation was performed by this reviewer.

Reviewed frozen archive 4b1996acdbc885b3e3a910b637c90015674f70b3983abb11be70d77a9d019b43, manifest 2cc35804b287791d35dff6fa43b652fef4f586baad75195471c1cf3ec0cff8c9, source 0d046d6337a37aa0800ee11742672eab3400a47052d4ecf2c7d804844a0f0582 and controls 22479ee7563064268f11b6aea68bdf135f340335743c5120eed987ea6da0cf05. All 14 manifest file hashes/lengths and both original preimage hashes independently matched. Original failed mesh4fa3dce8 and its positive crossing witnesses remain failed evidence.

## Connection to actual failures

The first mesh had 586 actual proper crossings despite closed edges and single-cycle vertex links. Concrete retained controls include croup/hind_l[1317,12858], withers_shoulder/fore_l[3150,7210], nose/nostril_1[6246,22110] and nostril self[21894,22120]. The repair changes the embedding rather than proposing winding or smoothing as a waiver.

Old horizontal upper-root rings were partly inside retained torso skin. New port columns12/13/14 and reflected9/10/11 lie on the lower/ventral trunk, with negative-Y normals. Each18mm collar is a translation of its actual removed-patch perimeter along the computed outward normal. The first child loops lie below the entire collar by source-only27.98mm fore/16.03mm hind, and below the original trunk lower-envelope bounds by43.61/37.14mm. Thus this proposal directly addresses the known inside-torso first-ring mechanism. Adjacent left/right ports share a ventral edge; the two outward collars diverge and retain the intended shared source junction, but actual crotch embedding and vertex links require readback.

The old least-distance frame could reverse/order a loop without certifying its embedding. The replacement keeps each aperture's actual cyclic angular order, refuses collapsed projections and angular steps of180degrees or more, then uses the same ordering down strictly descending-Y limb profiles. This is credible against twisted root strips; it does not certify the nonplanar bridge, descendant self-folds or post-subdivision body clearance.

The old nostril ellipse exceeded its slanted opening. New two-quad openings use the actual boundary, including boundary midpoints, with a strict projected-kernel center check. Each subsequent contour is a homothetic contraction with only local-normal displacement: scales .82/.64/.35/.12 and offsets +1.5/−6/−14/−17mm. This removes the unrelated axis-aligned ellipse/tangential recentering that caused the known cut across surviving nose skin. The initial outward rim followed by inward recession and the eventual cap still need actual crossing/containment/normal checks. Projection containment alone does not establish a clean nonplanar cup after subdivision.

## Frame and scope

Metres, +Y up, +Z forward and anatomical left+X remain. Existing body rows, lower-profile centers, ears/eyes and contacts receive the disclosed+40mm source-Z shift; relative ear offsets and radii are not shifted. Newly revised upper limb/cup controls are separately owned reconstruction changes. The exporter still uses an identity root, without a runtime node translation, scale or Y lift. New declared contact centers are foreZ+.52/hindZ−.52, mirrored X±.20, so their arithmetic mean is zero. No old15-joint rig, socket or animation qualification transfers. Skeletal landmarks are separately labeled hypotheses rather than mislabeling every skin-profile center as a bone joint.

Two source claims must remain qualified:

1. Applying nonuniform aperture angles to every downstream limb/hoof ring changes sampled lower-limb/hoof geometry, even where center/radius values are retained. It is not exact relative-shape preservation of the failed first mesh.
2. Declared profile/contact centers averaging zero does not prove actual sole geometry has that midpoint. From the proposed angle lists alone, source sole sample means are foreZ+.5217443474 and hindZ−.5205637468, averagingZ+.0005903003m. This is not a decoded subdivided sole centroid, but it already prevents an unqualified assertion that every definition of geometric support midpoint is exactly zero. Keep the old actual readback definition and report the new result honestly; do not silently redefine it to make a check pass. The declared support-center frame can be stated separately.

## Bounded next result required

One exact new output may establish whether this source change actually repairs the embedding. Preserve the first failed mesh/witnesses unchanged. Repeat the independent decoded vertex-link, finite/index/normal, soles/scale/frame and proper-crossing screen against the new output; root/crotch and both nostril cups are explicit unresolved regions. Do not infer success from exporter completion or closed-edge counts. A zero proper noncoplanar crossing screen still leaves coplanar contact, containment, anatomy, visual seam and photographic quality unproved. Browser inspection remains held until root reviews actual geometry evidence. Hair, UV/PBR, rig, tack, LOD and interaction remain outside this static build's acceptance.
