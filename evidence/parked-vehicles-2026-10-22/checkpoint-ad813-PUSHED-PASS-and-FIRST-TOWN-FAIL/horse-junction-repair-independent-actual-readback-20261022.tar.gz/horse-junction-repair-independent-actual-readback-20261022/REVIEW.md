# Repaired horse actual mesh readback

CLEAR for one matched-view appearance review of exact new GLB772dab7c1b9ee2bebbf0aba3d75049835c45044540ef06e3b58b522ba5add296 after root releases it. No browser/build/app mutation was performed by this reviewer. This is not photographic or production acceptance.

The unchanged independent crossing algorithm evaluated all192,354 AABB candidates in11.07s and found zero strict proper noncoplanar crossings, versus586 in the original failed4fa3 mesh. All old failure region pairs and every new region were included. Actual12306vertices/12304quads/24608triangles form one connected component, Euler2, zero bad edges and zero bad vertex links. GLB Float32 positions and indices match the surface; finite normals have lengths .99999994..1. Minimum triangle area remains positive (see COMPARISON.json).

All four actual soles have49vertices at Y0. The unchanged sole-vertex-mean metric gives equal-foot meanZ+.5903095mm; the declared authored sole-center control mean is separately0. This confirms the clarified prediction rather than replacing the actual geometry metric.

READBACK.json contains the complete region-pair count and all actual positive pair IDs (empty). COMPARISON.json preserves old586 region counts and immutable old readback hash. The old positive crossing witnesses remain genuine failed controls; changed topology makes old triangle IDs unsuitable as new triangle identities.

Strict proper crossings exclude coplanar overlaps/tangencies and do not prove absence of containment, visual seams, anatomical faults or shading artifacts. Whole/face/limb matched views of the actual new output are now useful; rig, tack, hair, UV/PBR, LOD, historical individual and photographic acceptance remain open.
