# One initial standing Otis Bardwell increment — prepared for root

READY FOR ROOT REVIEW/INTEGRATION; not applied, published or visually reviewed in the town. Root remains the sole tracked writer. No CI dispatch/rerun/cancel, browser/server, branch movement or application write occurred in preparing this candidate.

Actual canonical human run39712579846/head34cf462ed343b8b2b70da70303344fff7e5e083f completed SUCCESS; strict qualification COMPLETE. It contains the reviewed V5/V6 garments and source provenance on the same canonical body/rig. The full qualification and29 actual PNG review capsule is ../human-next-head-actual-review-39712579846-34cf462e.zip, SHA2566ce72b4d0951d44fb6707b346ae5bfc045e0bffabb3e8e72430cd369465a0fb0. Root personally reviewed actual published Bardwell standing-quarter and close-front; the other27 reviewed images are independent agent reviews. This is a coherent initial visible increment, not photographic/full-tailoring or T-1789 completion.

## Concrete parcel

Exactly one instance hi_rc_bardwell_otis_1835 binds to existing rc_bardwell_otis and its own resident_card. That person's name, age20–29, teamster trade, presence and west division are already reconstructed records; no person is minted. The household's modeled Kinzie employment has unplaceable premises, so the stand makes NO workplace/ownership/tavern-employment/observed-action claim. The invented stand is in the existing Wolf Point Tavern yard at E−94,N−36.5, heading90°, idle phase0, terrain anchor, unchanged autoLOD. It is near existing unhitched wagons without occupying them. No seated interface, route, reins, dialogue, dated likeness or face derived from community is added. Appearance/actions are reconstructed under L418.

STATIC-PLACEMENT-PROOF.json proves this finite source-data stand: committed terrain root0.9992m; a0.75m actor reserve; full reserve-square bilinear terrain extrema; actual decoded source/web all4LOD sole offsets give at most1.6805mm conservative sole-height error, below unchanged2mm. The square has2.4mm peak-to-peak terrain variation, which is not the per-foot deviation from its own root. This is not called flat. All committed structure footprints and enclosure runs are tested; nearest footprint6.325m, nearest fence3m. Exact actual parked model AABBs, including analytic full tongue hinge sweeps, leave at least1.753m beyond the actor reserve. Nearby source-recorded wood/shrub/trunk reserves clear. Decorative canopy/ground vegetation and actual in-town visibility remain for the required scene review; this finite static proof is not continuous collision or occupied-fit acceptance. Actual canonical source idle root/pelvis/leg/foot/ball accessors are constant at all decoded keys (zero change); no body/root/pose modification was authored.

## Exact import and budgets

proposal/chicago/4d/assets/humans contains ONLY the8 exact same-run Bardwell GLBs: sourceLOD0–3 and published webLOD0–3,38,265,304bytes total. EXACT-IMPORT-MANIFEST.json pins each archive member/hash/byte count/destination. No blend, duplicate hierarchy control, raw diagnostic GLB or other resident is imported. The actual canonical master remains preserved in the bound artifact and can be reacquired as inert bytes; import does not reconstruct or execute it. The existing LICENSES.md already licenses these exact paths CC0-1.0 with separate graphical base/skin/hair provenance; append the actual hash receipt using LICENSES-APPEND.md, retaining all existing notices.

The existing publisher already copies data/humans and compressed assets/humans/web to public data/humans; no publisher/loader/rig/pose/material patch is needed. Source GLBs remain beside their Meshopt derivatives for existing contract checks. Proposed data/humans/bardwell_otis_1835.measure.json discloses actual perLOD costs, source binding and open quality status publicly.

|LOD|Published bytes|Triangles|Material draws (one pass)|
|---|---:|---:|---:|
|0|4,439,324|40,931|9|
|1|1,564,256|24,927|9|
|2|617,540|12,335|9|
|3|308,100|6,022|9|

All four published files sum6,929,220bytes; the nearLOD0 is4,439,324bytes. The existing full/balanced/light floors,8/20/45m bands and140m draw cutoff remain unchanged. Material counts do not include shadow passes. Scene p95, GPU completion, phone memory/performance and additive whole-town budget are NOT yet measured. Root must run the applicable published desktop/mobile/performance checks after integration, with the one actor actually visible and its normal LOD swaps; no new performance acceptance is inferred from standalone CI.

## Minimal text change

standing-candidate-text.patch contains five paths: human_contract.py,1835 scene layer addition, one instance, validated browser index and public measurement JSON. Twenty-one finite positive/negative controls PASS in FINITE-CONTROLS.json. The new discover_instances validates exact scene/index shape, safe unique ids, existing regular record files, index/filename/id/scene identity and complete inventory. It separates index metadata while every actual record still goes through the unchanged full instance validator. Existing self_test gains the controls; no new gate tool enters the application. check_instance,check_glb and every other existing contract function are AST-exact; only main and self_test wire the new inventory function. No guard/asset-format tolerance changes occur.

The helper+scene preimages match BOTH current dd147 vehicle checkout and exact canonical human34cf. Current vehicle checkout lacks the later Mount source/provenance appendices; canonical-source/ contains the two immutable actual source records read from34cf with pinned hashes. CANONICAL-SOURCE-COMPARISON.json records the differences. The first finite actual-instance check correctly refused missing sources on that vehicle-only context; the passing check uses the verified canonical records. Root must combine the qualified human source/provenance before applying this candidate; do not discard the metadata appendices while merging. All copied asset and person identities are exact. No pretend source was created.

## Root commands and remaining verification

Before writing, compare TEXT-PREIMAGES.json and current target bytes, ensure canonical human source/provenance is retained, then git apply --check and git apply standing-candidate-text.patch from repository root. Copy the8 exact files under proposal/chicago/4d/assets/humans into the corresponding repository paths, comparing every SHA256 from EXACT-IMPORT-MANIFEST.json immediately after copy. These are root-only application actions; no import script is launched by this support packet.

Append LICENSES-APPEND.md and DOCS-APPEND.md to the corresponding existing append-only documentation sections, and update the current T-1789 changelog entry to describe the one actually visible increment with quality limits. Root owns that tracked writing and ticket handling. Do not close the parent.

Run the existing python tools/human_contract.py --self-test and --check, normal publish/preflight and applicable published desktop/mobile checks on the new integrated tree. They must prove exactly one actor bound to Bardwell, his own card opens, real terrain sole contact stays within2mm at all4LODs, no static collision or failed fetch/GL error, no extra era population, actual9material draws and byte costs, and public town budget. Look at actual standing front/profile/quarter at both viewports in context, including shoes/cuffs, hair/eyes/neckline and visibility from a reachable viewpoint. No browser preview was prepared or run here. Root coordinates the lane and may adjust the invented stand only with a new recorded terrain/collision receipt; no hidden root translation or mask.

T1789-REMAINING-SOURCE-FIXES.md maps the remaining acceptance work to source-level repairs. Final period/photographic, full animated clothing/LOD enclosure, seated/riding interfaces and world acceptance remain open. HumanPR1175 dependency/vehicle CI status still applies independently; this capsule does not authorize merging a red parent or claim production deployment.
