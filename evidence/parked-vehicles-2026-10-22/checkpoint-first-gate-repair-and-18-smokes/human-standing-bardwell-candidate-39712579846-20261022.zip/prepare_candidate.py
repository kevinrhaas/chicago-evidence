import pathlib,json,hashlib,zipfile,stat,difflib,datetime
R=pathlib.Path('/workspace/chicago/chicago/4d');D=pathlib.Path(__file__).resolve().parent;P=D/'proposal/chicago/4d';P.mkdir(parents=True,exist_ok=True)
q=pathlib.Path('/workspace/shared/human-next-head-qualified-39712579846-terminal1');qualified=json.loads((q/'QUALIFICATION.json').read_text());assert qualified['mechanical_qualified'] and qualified['sha']=='34cf462ed343b8b2b70da70303344fff7e5e083f'
base=(R/'tools/human_contract.py').read_text()
helper='''def discover_instances(root: Path) -> tuple[list[Path], list[Finding]]:
    """Validate the browser's index separately; every instance still gets its full checks."""
    paths = sorted(root.glob("*/*.json")) if root.exists() else []
    instances = [p for p in paths if p.name != "index.json"]
    out = []
    for directory in sorted({p.parent for p in paths}):
        index = directory / "index.json"
        if not index.is_file():
            out.append(Finding("instance.index_missing", f"{directory.name} has instances but no browser index"))
            continue
        try:
            record = load_json(index)
        except (ValueError, OSError) as error:
            out.append(Finding("instance.index_schema", f"{index}: {error}"))
            continue
        if (not isinstance(record, dict) or set(record) != {"scene", "instances"}
                or record["scene"] != directory.name or not re.fullmatch(r"[0-9]{4}", directory.name)
                or not isinstance(record["instances"], list)
                or any(not isinstance(i, str) or not re.fullmatch(r"hi_[a-z0-9_]+", i)
                       for i in record["instances"])):
            out.append(Finding("instance.index_schema", f"{index}: exact scene and safe instance-id list required"))
            continue
        ids = record["instances"]
        if len(ids) != len(set(ids)):
            out.append(Finding("instance.index_duplicate", f"{index}: repeated instance id"))
        for ident in set(ids):
            path = directory / f"{ident}.json"
            if not path.is_file() or path.is_symlink():
                out.append(Finding("instance.index_missing_file", f"{index}: {ident} has no regular record file"))
                continue
            try:
                instance = load_json(path)
            except (ValueError, OSError) as error:
                out.append(Finding("instance.index_record", f"{path}: {error}"))
                continue
            if not isinstance(instance, dict) or instance.get("id") != ident or instance.get("scene") != directory.name:
                out.append(Finding("instance.index_record", f"{path}: index, filename, id and scene must agree"))
        if {p.stem for p in instances if p.parent == directory} != set(ids):
            out.append(Finding("instance.index_inventory", f"{index}: listed ids and instance files differ"))
    return instances, out


'''
assert base.count('def known_sources()')==1
new=base.replace('def known_sources()',helper+'def known_sources()',1)
old='        insts = sorted(INSTANCES.glob("*/*.json")) if INSTANCES.exists() else []'
replacement='''        insts, index_findings = discover_instances(INSTANCES)
        for finding in index_findings:
            print(f"FAIL instance index: {finding}")
        bad += len(index_findings)'''
assert old in new;new=new.replace(old,replacement)
tests='''    print("instance browser indexes")
    with tempfile.TemporaryDirectory() as td:
        directory = Path(td) / "1835"
        directory.mkdir()
        ident = "hi_existing_resident_1835"
        path = directory / f"{ident}.json"
        index = directory / "index.json"
        original_record = {"id": ident, "scene": "1835"}
        def reset_index():
            path.write_text(json.dumps(original_record))
            index.write_text(json.dumps({"scene": "1835", "instances": [ident]}))
        reset_index()
        found, findings = discover_instances(Path(td))
        expect("browser manifest is not treated as an instance", findings, None)
        expect("every listed instance is still discovered", [] if found == [path] else
               [Finding("instance.index_discovery", "instance was skipped")], None)
        index.unlink()
        expect("records without a browser index refuse", discover_instances(Path(td))[1], "instance.index_missing")
        for label, record, code in [
            ("repeated ids", {"scene": "1835", "instances": [ident, ident]}, "instance.index_duplicate"),
            ("missing listed file", {"scene": "1835", "instances": ["hi_absent_1835"]}, "instance.index_missing_file"),
            ("unlisted record", {"scene": "1835", "instances": []}, "instance.index_inventory"),
            ("index scene mismatch", {"scene": "1904", "instances": [ident]}, "instance.index_schema"),
            ("unsafe id", {"scene": "1835", "instances": ["../outside"]}, "instance.index_schema"),
            ("non-list ids", {"scene": "1835", "instances": ident}, "instance.index_schema"),
        ]:
            reset_index()
            index.write_text(json.dumps(record))
            expect(label, discover_instances(Path(td))[1], code)
        for label, record in [
            ("record id differs from filename", {"id": "hi_other_1835", "scene": "1835"}),
            ("record scene differs from directory", {"id": ident, "scene": "1904"}),
        ]:
            reset_index()
            path.write_text(json.dumps(record))
            expect(label, discover_instances(Path(td))[1], "instance.index_record")
        reset_index()
        index.write_text("{")
        expect("malformed index", discover_instances(Path(td))[1], "instance.index_schema")
        reset_index()
        path.unlink()
        path.symlink_to(index)
        expect("symlink record", discover_instances(Path(td))[1], "instance.index_missing_file")

'''
assert new.count('    anonymous_test = subprocess.run(')==1;new=new.replace('    anonymous_test = subprocess.run(',tests+'    anonymous_test = subprocess.run(',1)
files={'tools/human_contract.py':new}
scene=json.loads((R/'data/scenes/1835.json').read_text());assert 'humans' not in scene['layers'];scene['layers'].append('humans');files['data/scenes/1835.json']=json.dumps(scene,indent=2)+'\n'
ident='hi_rc_bardwell_otis_1835'
record={'id':ident,'contract_version':1,'scene':'1835','person_id':'rc_bardwell_otis','appearance':{'asset_id':'bardwell_otis_1835'},'placement':{'local_e':-94.0,'local_n':-36.5,'heading_deg':90,'anchor':'terrain'},'animation':{'clip':'idle','loop':True,'phase':0},'behaviour':{'state':'standing'},'interaction':{'selectable':True,'radius_m':3,'opens':'resident_card'},'lod':{'policy':'auto'},'display':'shown','review_required':False,'provenance':{'grade':'reconstructed','basis':'Initial reconstructed standing depiction of existing reconstructed resident Otis Bardwell in the west-side Wolf Point Tavern yard near an existing unhitched wagon. Exact qualified canonical run39712579846/head34cf462ed343b8b2b70da70303344fff7e5e083f supplies the reusable body, clothing and idle pose. His name, age band and teamster role are model records, not documentary identity or likeness. This stand is an invented demonstration, not an observed action, tavern employment or wagon ownership. Simplified garment/skin/hair appearance is an initial visible increment; period-complete tailoring, full animated fit and photographic quality remain open.','sources':['mount_1835_bargaining_for_a_horse','mount_1835_bar_room_scene'],'liberty':'L418','seed':'rc_bardwell_otis:1835:initial-standing:20261022','replaceable_by':'A better qualified depiction or evidence replacing this reconstructed resident slot; exact location/action has no documentary claim.'}}
files[f'data/humans/instances/1835/{ident}.json']=json.dumps(record,indent=2)+'\n';files['data/humans/instances/1835/index.json']=json.dumps({'scene':'1835','instances':[ident]},indent=2)+'\n'
patch=[];pre=[]
for rel,content in files.items():
 target=P/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(content)
 src=R/rel;old=src.read_text() if src.exists() else ''
 pre.append({'path':'chicago/4d/'+rel,'preimage_sha256':hashlib.sha256(src.read_bytes()).hexdigest() if src.exists() else None,'proposed_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
 patch.extend(difflib.unified_diff(old.splitlines(keepends=True),content.splitlines(keepends=True),fromfile='a/chicago/4d/'+rel if src.exists() else '/dev/null',tofile='b/chicago/4d/'+rel))
(D/'standing-candidate-text.patch').write_text(''.join(patch));(D/'TEXT-PREIMAGES.json').write_text(json.dumps(pre,indent=2)+'\n')
idx=json.loads((q/'artifact-file-index.json').read_text());assetrows=[]
with zipfile.ZipFile(q/'resident-studies.zip') as z:
 for kind in ['', 'web/']:
  for lod in range(4):
   suffix=f'chicago/4d/assets/humans/{kind}bardwell_otis_1835.lod{lod}.glb';row=next(x for x in idx if x['file'].endswith('/'+suffix));info=z.getinfo(row['file']);assert not stat.S_ISLNK(info.external_attr>>16);b=z.read(info);assert b[:4]==b'glTF' and hashlib.sha256(b).hexdigest()==row['sha256'];p=P/'assets/humans'/kind/f'bardwell_otis_1835.lod{lod}.glb';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);assetrows.append({**row,'destination':str(p.relative_to(P)),'lod':lod,'runtime':'published' if kind else 'source'})
(D/'EXACT-IMPORT-MANIFEST.json').write_text(json.dumps({'run_id':39712579846,'source_sha':qualified['sha'],'artifact_zip_sha256':qualified['artifact_zip_sha256'],'artifact_id':12398870779,'only_bardwell_all4_source_and_web_lods':True,'geometry_rig_material_animation_bytes_unchanged':True,'members':assetrows},indent=2)+'\n')
budgets=[]
for kind in ['source','web']:
 j=json.loads((q/(kind+'-inspection.json')).read_text())
 for row in j['runs']:
  if 'bardwell_otis_1835.' in row['file'] and row['viewport_name']=='desktop':
   importrow=next(r for r in assetrows if r['runtime']==('source' if kind=='source' else 'published') and r['lod']==row['lod'])
   budgets.append({k:row[k] for k in ['file','lod','sha256','triangles','skinned_meshes','bone_count','standing_frame','footwear_min_y_m','capture_framing']}|{'bytes':importrow['bytes'],'draw_material_slots':len(row['materials']),'decoded_images':[{'material':m['name'],'textures':m['textures']} for m in row['materials']]})
(D/'PUBLIC-ASSET-BUDGETS.json').write_text(json.dumps({'scope':'Actual same-run asset costs. One actor only. Scene p95/GPU/phone/full-town additive costs are not yet measured; no public budget acceptance asserted. Existing production tier LOD policy is unchanged.','tiers':{'full':[0,1,2,3],'balanced':[1,2,3],'light':[2,3]},'lod_bands_m':[8,20,45],'assets':budgets},indent=2)+'\n')
print(json.dumps({'prepared':str(D),'text_patch_sha256':hashlib.sha256((D/'standing-candidate-text.patch').read_bytes()).hexdigest(),'asset_files':len(assetrows),'asset_bytes':sum(r['bytes'] for r in assetrows)}))
