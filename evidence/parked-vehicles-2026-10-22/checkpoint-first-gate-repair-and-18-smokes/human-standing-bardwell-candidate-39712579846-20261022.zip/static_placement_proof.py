import sys;sys.dont_write_bytecode=True
import pathlib,json,math,ast,hashlib,struct,itertools,importlib.util
import numpy as np
D=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/chicago/chicago/4d');C=(-94.,-36.5);reserve=.75;pins=[]
def read(p):
 b=p.read_bytes();pins.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)});return json.loads(b)
# Reuse the production generator's exact placement and signed-distance functions, not a second sign convention.
p=R/'tools/generate_yard_goods.py';src=p.read_text();pins.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size});tree=ast.parse(src);keep={'_to_enu','_footprint_world','_poly_contains','_dist_to_polygon','_dist_to_path'};env={'math':math};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in keep],type_ignores=[]),str(p),'exec'),env)
structures=[]
for p in (R/'data/sidecars/1835').glob('*.json'):
 j=json.loads(p.read_text());poly=env['_footprint_world'](j)
 if poly:
  distance=env['_dist_to_polygon'](C,poly)
  if distance<20:pins.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
  structures.append({'id':j.get('id'),'distance_to_footprint_m':distance,'standing_reserve_gap_m':distance-reserve})
assert min(x['standing_reserve_gap_m'] for x in structures)>0
fences=[]
for p in (R/'data/enclosures').glob('*.json'):
 j=json.loads(p.read_text())
 for run in j.get('runs',[]):
  path=run.get('path_local_enu_m')
  if path:
   distance=env['_dist_to_path'](C,path)
   if distance<20:pins.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
   fences.append({'id':j.get('id'),'run':run.get('id'),'centerline_distance_m':distance,'reserve_gap_after_conservative_0_30m_fence_envelope_m':distance-reserve-.30})
assert min(x['reserve_gap_after_conservative_0_30m_fence_envelope_m'] for x in fences)>0
# Original actual model AABBs including a full analytic X-rotation sweep of the hinged tongue.
def corners(lo,hi):return np.array([[*v,1.] for v in itertools.product(*zip(lo,hi))])
def matrix(node,omit_x=False):
 if 'matrix' in node:return np.array(node['matrix']).reshape((4,4),order='F')
 x,y,z,w=node.get('rotation',[0.,0.,0.,1.]);
 if omit_x:assert abs(y)<1e-10 and abs(z)<1e-10;(x,y,z,w)=(0.,0.,0.,1.)
 m=np.eye(4);m[:3,:3]=[[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]];m[:3,:3]=m[:3,:3]@np.diag(node.get('scale',[1.,1.,1.]));m[:3,3]=node.get('translation',[0.,0.,0.]);return m
sweep=[]
def model_bounds(path):
 b=path.read_bytes();pins.append({'path':str(path.relative_to(R)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)});assert b[:4]==b'glTF';j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]])
 def vertices(index,parent,special=True):
  node=j['nodes'][index]
  if special and node.get('name')=='vehicle_tongue':
   local=vertices(index,np.eye(4),False);inv=np.linalg.inv(matrix(node));local=(inv@local.T).T;r=max(math.hypot(v[1],v[2]) for v in local);lo=local[:,:3].min(axis=0);hi=local[:,:3].max(axis=0);lo[1:]=-r;hi[1:]=r;sweep.append({'model':str(path.relative_to(R)),'hinge':node['name'],'full_x_rotation_radius_m':r});return (parent@matrix(node,True)@corners(lo,hi).T).T
  world=parent@matrix(node);rows=[]
  if 'mesh' in node:
   for primitive in j['meshes'][node['mesh']]['primitives']:
    a=j['accessors'][primitive['attributes']['POSITION']];assert len(a['min'])==len(a['max'])==3;rows.append((world@corners(a['min'],a['max']).T).T)
  for child in node.get('children',[]):rows.append(vertices(child,world,special))
  return np.concatenate(rows) if rows else np.empty((0,4))
 points=np.concatenate([vertices(i,np.eye(4)) for i in j['scenes'][j.get('scene',0)]['nodes']]);assert np.isfinite(points).all();return points[:,:3].min(axis=0),points[:,:3].max(axis=0)
placements=read(R/'data/transport/parked/placements.json');vehicles=[]
for row in placements['scenes']['1835']:
 if math.dist(C,row['at_local_enu_m'])>20:continue
 lo,hi=model_bounds(R/'renderers/web'/placements['models'][row['model']]['file']);pts=corners(lo,hi);yaw=math.pi-math.radians(row['bearing_deg']);co,si=math.cos(yaw),math.sin(yaw);xy=[(row['at_local_enu_m'][0]+co*v[0]+si*v[2],row['at_local_enu_m'][1]-(-si*v[0]+co*v[2])) for v in pts];xs=[v[0] for v in xy];ys=[v[1] for v in xy];box=[(min(xs),min(ys)),(max(xs),min(ys)),(max(xs),max(ys)),(min(xs),max(ys))];distance=env['_dist_to_polygon'](C,box);vehicles.append({'id':row['id'],'world_conservative_AABB_enu_m':box,'includes_full_tongue_rotation_sweep':True,'distance_m':distance,'reserve_gap_m':distance-reserve});assert distance>reserve
props=[]
for folder in ['yard','flora/plantings','frontage']:
 for p in (R/'data'/folder).glob('*.json'):
  j=json.loads(p.read_text());used=False
  def walk(v,trail=''):
   global used
   if isinstance(v,dict):
    at=v.get('at_local_enu_m') or v.get('local_enu_m');at=at if isinstance(at,list) else [v.get('local_e'),v.get('local_n')]
    if len(at)>=2 and all(isinstance(x,(int,float)) for x in at[:2]) and math.dist(C,at[:2])<12:
     if 'wagons' not in trail:
      if folder=='flora/plantings':bound=max(1.,v.get('height_m',0.)) # Entire height as a conservative horizontal radius.
      elif v.get('kind')=='cordwood':bound=math.hypot(v['length_m'],v['depth_m'])/2+.30
      elif v.get('kind')=='chopping_block':bound=1.
      else:raise AssertionError(('unhandled nearby prop',p,trail,v))
      distance=math.dist(C,at[:2]);props.append({'record':str(p.relative_to(R)),'pointer':trail,'point':at[:2],'conservative_radius_m':bound,'reserve_gap_m':distance-bound-reserve});used=True
    for k,w in v.items():walk(w,trail+'/'+k)
   elif isinstance(v,list):
    for i,w in enumerate(v):walk(w,trail+'/'+str(i))
  walk(j)
  if used:pins.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
# Tall-tree crowns are vertically above a standing adult; separately retain the very conservative full-height overlap as OPEN, and require generous trunk stand clearance.
for prop in props:
 if prop['reserve_gap_m']<0 and prop['record'].startswith('data/flora/'):
  prop['full_height_disc_overlaps_but_not_trunk_proof']=True;prop['trunk_reserved_radius_m']=2.;prop['trunk_gap_m']=math.dist(C,prop['point'])-2.-reserve;assert prop['trunk_gap_m']>0
 else:assert prop['reserve_gap_m']>0
# Terrain bilinear extrema over the complete 1.5m reserve square: sample all grid/border intersections, not only one chosen point.
hpath=R/'tools/heightfield.py';spec=importlib.util.spec_from_file_location('readonly_hf',hpath);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);epoch=R/'data/terrain/epochs/e1834_harbor_cut';h=mod.Heightfield.load(epoch);meta=read(epoch/'heightfield.json');binpath=epoch/meta.get('bin','heightfield.bin');pins.append({'path':str(binpath.relative_to(R)),'sha256':hashlib.sha256(binpath.read_bytes()).hexdigest(),'bytes':binpath.stat().st_size})
xs={C[0]-reserve,C[0]+reserve};ys={C[1]-reserve,C[1]+reserve}
for i in range(math.floor((C[0]-reserve-h.origin_e)/h.cell_m),math.ceil((C[0]+reserve-h.origin_e)/h.cell_m)+1):
 x=h.origin_e+i*h.cell_m
 if C[0]-reserve<x<C[0]+reserve:xs.add(x)
for i in range(math.floor((C[1]-reserve-h.origin_n)/h.cell_m),math.ceil((C[1]+reserve-h.origin_n)/h.cell_m)+1):
 y=h.origin_n+i*h.cell_m
 if C[1]-reserve<y<C[1]+reserve:ys.add(y)
terrain=[{'e':x,'n':y,'height_m':h.height(x,y)} for x in sorted(xs) for y in sorted(ys)];assert all(h.covers(x['e'],x['n']) for x in terrain);floor=h.height(*C);variation=max(x['height_m'] for x in terrain)-min(x['height_m'] for x in terrain);terrain_max_deviation=max(abs(x['height_m']-floor) for x in terrain);assert floor>0 and terrain_max_deviation<.002
q=pathlib.Path('/workspace/shared/human-next-head-qualified-39712579846-terminal1');feet=[]
for kind in ['source','web']:
 j=json.loads((q/(kind+'-inspection.json')).read_text())
 for row in j['runs']:
  if 'bardwell_otis_1835.' in row['file'] and row['viewport_name']=='desktop':
   feet.append({'runtime':kind,'lod':row['lod'],'sha256':row['sha256'],'actual_phase0_idle_footwear_heights_above_terrain_m':row['footwear_min_y_m'],'world_feet_y_m':{k:floor+v for k,v in row['footwear_min_y_m'].items()},'conservative_sole_height_error_bound_over_complete_reserve_m':terrain_max_deviation+max(abs(v) for v in row['footwear_min_y_m'].values())});assert terrain_max_deviation+max(abs(v) for v in row['footwear_min_y_m'].values())<=.002
# Negative controls exercise the same signed-distance tests against actual wall and wagon envelopes.
wall=next(x for x in structures if x['id']=='wolf_point_tavern');sc=json.loads((R/'data/sidecars/1835/wolf_point_tavern.json').read_text());poly=env['_footprint_world'](sc);inside=tuple(sum(v[k] for v in poly)/len(poly) for k in range(2));assert env['_dist_to_polygon'](inside,poly)<0
for v in vehicles:
 box=v['world_conservative_AABB_enu_m'];center=tuple(sum(p[k] for p in box)/4 for k in range(2));assert env['_dist_to_polygon'](center,box)<0
report={'passed':True,'scope':'Finite source-data static clearance and actual same-run phase0 idle sole-to-terrain proof at unchanged2mm. No browser, world visual acceptance, continuous cloth/interaction collision or scene/GPU performance claim.','stand_enu_m':C,'heading_deg':90,'reserved_disc_radius_m':reserve,'terrain_m':floor,'reserve_square_bilinear_variation_m':variation,'maximum_height_deviation_from_actor_root_m':terrain_max_deviation,'first_flat_square_assumption_refused':True,'first_assumption_note':'The reserve square has2.4mm peak-to-peak variation. The relevant per-foot error is its1.65mm maximum deviation from root height plus actual decoded sole offset, required below unchanged2mm. No placement/terrain/sole guard was moved.','terrain_extrema_points':terrain,'source_and_web_lod_feet':feet,'all_committed_structure_footprints_tested':len(structures),'nearest_structures':sorted(structures,key=lambda r:r['distance_to_footprint_m'])[:8],'all_enclosure_runs_tested':len(fences),'nearest_fences':sorted(fences,key=lambda r:r['centerline_distance_m'])[:8],'actual_parked_vehicle_analytic_bounds':vehicles,'tongue_sweeps':sweep,'nearby_yard_frontage_and_planted_objects':props,'negative_actual_wall_and_vehicle_controls_passed':True,'remaining':'Source-data static ground-obstacle clearance includes a conservative2m tree-trunk reserve; exact decorative canopy/grass geometry and actual in-town standing preview and public-budget check still required before root accepts integration. No walking route or seated interface is supplied.','input_pins':list({r['path']:r for r in pins}.values())};(D/'STATIC-PLACEMENT-PROOF.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':True,'terrain':floor,'variation':variation,'nearest_wall_m':min(r['distance_to_footprint_m'] for r in structures),'nearest_fence_m':min(r['centerline_distance_m'] for r in fences),'vehicles':vehicles,'props':props},indent=2))
