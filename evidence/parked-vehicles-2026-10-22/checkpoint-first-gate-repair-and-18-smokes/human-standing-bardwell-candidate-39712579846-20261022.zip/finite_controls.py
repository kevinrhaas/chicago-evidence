import sys;sys.dont_write_bytecode=True
import pathlib,json,runpy,ast,tempfile,copy,hashlib
D=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/chicago/chicago/4d');p=D/'proposal/chicago/4d/tools/human_contract.py';m=runpy.run_path(str(p));checks=[]
def expect(label,findings,code):
 codes=[f.code for f in findings];ok=not codes if code is None else code in codes;checks.append({'control':label,'expected':code,'actual':codes,'passed':ok});assert ok,(label,codes,code)
# Run exactly the new inventory controls from the existing self-test; no GLB sweeps or child test suite.
tree=ast.parse(p.read_text());f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='self_test');start=next(i for i,n in enumerate(f.body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and n.value.args and isinstance(n.value.args[0],ast.Constant) and n.value.args[0].value=='instance browser indexes');end=next(i for i,n in enumerate(f.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='anonymous_test' for t in n.targets));env={**m,'expect':expect};exec(compile(ast.Module(body=f.body[start:end],type_ignores=[]),str(p),'exec'),env)
# Real proposed manifest must discover the real shown record; all full instance guards remain active.
instroot=D/'proposal/chicago/4d/data/humans/instances';files,findings=m['discover_instances'](instroot);expect('actual proposed browser index',findings,None);assert len(files)==1
fun=m['check_instance'];g=fun.__globals__;g['ASSETS']=D/'proposal/chicago/4d/assets/humans';g['SCENES']=R/'data/scenes';g['SIDECARS']=R/'data/sidecars';g['SOURCES']=R/'data/sources';g['LIBERTIES']=R/'docs/LIBERTIES.md';c=json.loads((R/'data/humans/contract.json').read_text());schema=json.loads((R/'data/humans/human_instance.schema.json').read_text());rec=json.loads(files[0].read_text())
sources={p.stem for p in (R/'data/sources').glob('*.json')}|{p.stem for p in (D/'canonical-source').glob('*.json')}
def actual(x,ctx=None):
 context=ctx if ctx is not None else {};context['sources']=sources
 return fun(x,c,schema,where=str(files[0]),ctx=context)
expect('actual shown Bardwell identity, source assets, provenance and schema',actual(rec),None)
x=copy.deepcopy(rec);x['person_id']='nobody_at_all';expect('unknown person remains refused',actual(x),'instance.unknown_person')
x=copy.deepcopy(rec);x['appearance']['asset_id']='missing_canonical_asset';expect('shown missing asset remains refused',actual(x),'instance.no_asset')
x=copy.deepcopy(rec);x['scene']='1904';expect('record scene cannot drift from filename',actual(x),'instance.location')
ctx={};actual(rec,ctx);expect('duplicate same resident remains refused',actual(rec,ctx),'instance.duplicate_person')
x=copy.deepcopy(c);x['l1']={**x['l1'],'in_force':True};expect('synthetic emergency L1 remains refused',fun(rec,x,schema,ctx={'sources':sources}), 'instance.l1')
x=copy.deepcopy(rec);x.pop('placement');expect('invalid indexed instance still receives full schema checks',actual(x),'instance.schema')
report={'finite_only':True,'new_inventory_tests_in_existing_self_test':True,'no_browser_no_full_replay':True,'proposed_helper_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'controls':checks,'passed':all(r['passed'] for r in checks)};(D/'FINITE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':report['passed'],'controls':len(checks)}))
