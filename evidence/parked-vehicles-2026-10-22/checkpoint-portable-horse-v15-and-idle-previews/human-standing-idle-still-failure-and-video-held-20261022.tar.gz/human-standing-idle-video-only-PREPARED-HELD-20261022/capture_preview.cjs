// Separate VIDEO-ONLY continuation; preserves all first-run PNGs/failed receipts.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const out=__dirname,hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
if(!fs.existsSync(path.join(out,'RUN-INTENT.json')))throw Error('Use released Python caller; video intent missing');
const support=JSON.parse(fs.readFileSync(path.join(out,'REGISTRY-SUPPORT.json')));
const core=path.dirname(require.resolve('playwright-core/package.json'));
if(require(path.join(core,'package.json')).version!==support.playwright_version)throw Error('Unreviewed Playwright version');
for(const row of support.external_inputs)if(hash(row.path)!==row.sha256)throw Error('External executable/registry byte mismatch: '+row.path);
fs.accessSync(support.explicit_ffmpeg_path,fs.constants.X_OK);
const registry=require(path.join(core,'lib/server/registry/index.js')).registry;
const ffmpeg=registry.findExecutable('ffmpeg'),priorPath=ffmpeg.executablePath();
if(Object.isFrozen(ffmpeg)||!Object.getOwnPropertyDescriptor(ffmpeg,'executablePathOrDie')?.writable)throw Error('Pinned registry tool is not mutable as reviewed');
// Observed internal API, pinned above. Only this process's registry object changes.
ffmpeg.executablePath=()=>support.explicit_ffmpeg_path;
ffmpeg.executablePathOrDie=()=>support.explicit_ffmpeg_path;
if(registry.findExecutable('ffmpeg')!==ffmpeg||ffmpeg.executablePathOrDie()!=='/usr/bin/ffmpeg')throw Error('Explicit existing ffmpeg selection failed');
const {chromium}=require('playwright');
const scope='VIDEO-ONLY COUNTERFACTUAL SOURCE POSE. Unchanged actual canonical96c4 skin and proposed explicit bone keys; not candidate export, world, lifelike or photographic acceptance.';
(async()=>{
 const started=new Date().toISOString(),videos=[],errors=[],inputs=JSON.parse(fs.readFileSync(path.join(out,'INPUTS.json')));
 const framing=JSON.parse(fs.readFileSync(path.join(out,'inputs/frozen-framing.json'))).framing;
 let browser=null,closed=false,failed=null;
 try{
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
  fs.mkdirSync(path.join(out,'video-work'),{recursive:true});
  for(const view of['front','quarter']){
   const context=await browser.newContext({viewport:{width:1280,height:900},recordVideo:{dir:path.join(out,'video-work'),size:{width:1280,height:900}}});
   const page=await context.newPage(),note=(kind,message)=>errors.push({kind,message,view,at:new Date().toISOString()});
   page.on('pageerror',e=>note('page',e.message));page.on('console',m=>{if(m.type()==='error')note('console',m.text());});
   page.on('requestfailed',r=>note('request',r.url()+': '+r.failure()?.errorText));page.on('response',r=>{if(r.status()>=400)note('http',r.status()+' '+r.url());});
   await page.route('**/*',route=>{const u=new URL(route.request().url());return u.protocol==='data:'||u.protocol==='blob:'||u.hostname==='127.0.0.1'?route.continue():route.abort();});
   await page.goto('http://127.0.0.1:'+process.argv[2]+'/',{timeout:10000});await page.waitForFunction(()=>window.preview?.ready,null,{timeout:10000});
   await page.evaluate(f=>preview.useFraming(f),framing);await page.evaluate(()=>preview.load(true));await page.evaluate(()=>preview.pose('idle',0));
   const guard=r=>{if(r.framing?.passed!==true||r.posed_render?.shoe_rendered!==true||r.posed_render?.shoe_frustumCulled!==false||r.glError!==0||errors.length)throw Error('Framing, shoe draw, GL or browser guard failed');};
   const initial=await page.evaluate(v=>preview.view(v),view);guard(initial);
   const animation=await page.evaluate(()=>preview.animate8());const final=await page.evaluate(v=>preview.view(v),view);guard(final);
   const recording=page.video();await context.close();const file=`counterfactual-${view}-motion.webm`;await recording.saveAs(path.join(out,file));
   if(fs.statSync(path.join(out,file)).size<1024)throw Error('Video output empty or implausibly small');
   videos.push({file,bytes:fs.statSync(path.join(out,file)).size,sha256:hash(path.join(out,file)),view,animation,initial,final,
                scope:'Unedited viewport video includes setup followed by8s motion; source-pose preview only'});
   fs.writeFileSync(path.join(out,'VIDEO-PARTIAL.json'),JSON.stringify({scope,started,videos,errors,browser_closed:false},null,2));
  }
 }catch(e){failed={name:e.name,message:e.message,stack:e.stack};}
 finally{
  if(browser){await browser.close();closed=true;}
  fs.writeFileSync(path.join(out,'VIDEO-SOURCE-PREVIEW.json'),JSON.stringify({scope,started,finished:new Date().toISOString(),inputs,
   caller_sha256:hash(__filename),fixture_sha256:hash(path.join(out,'preview.html')),ffmpeg_selection:{prior_registry_path:priorPath,explicit_path:support.explicit_ffmpeg_path,adaptation:support.adaptation},
   videos,errors,browser_closed:closed,failed,technical_video_capture_complete:!failed&&errors.length===0&&videos.length===2,
   first_failed_run_preserved:true,first_PNGs_overwritten:false,actual_candidate_export:false,lifelike_accepted:false,canonical_or_photographic_accepted:false},null,2));
 }
 if(failed)throw Error(failed.message);
 console.log('Video-only continuation captured2motion videos. Browser closed; visual acceptance remains open.');
})().catch(e=>{console.error(e);process.exitCode=1;});
