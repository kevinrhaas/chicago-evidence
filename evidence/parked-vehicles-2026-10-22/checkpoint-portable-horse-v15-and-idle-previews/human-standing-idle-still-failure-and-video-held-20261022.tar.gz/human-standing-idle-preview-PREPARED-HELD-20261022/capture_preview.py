"""Prepared finite caller; no server/browser may launch without an explicit root release receipt."""
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from threading import Thread
import argparse,json,mimetypes,subprocess,os,signal,hashlib,datetime
HERE=Path(__file__).parent.resolve()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(ok,message):
 if not ok:raise ValueError(message)
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--release',type=Path,required=True);a=p.parse_args()
release=json.loads(a.release.read_text());inputs=json.loads((HERE/'INPUTS.json').read_text());prepared=json.loads((HERE/'PREPARED-CALLER.json').read_text())
need(release.get('authorization_owner')=='root' and release.get('release_preview') is True and release.get('covered_browser_lane_closed') is True,'Explicit root release after covered browser lane closes is required')
need(release.get('inputs_manifest_sha256')==digest(HERE/'INPUTS.json'),'release must bind exact inputs manifest')
need(release.get('prepared_manifest_sha256')==digest(HERE/'PREPARED-CALLER.json'),'release must bind prepared caller and safeguards')
for row in inputs['files']+prepared['caller_files']:
 file=(HERE/row['path']).resolve();need(file.is_relative_to(HERE) and file.is_file() and digest(file)==row['sha256'],'prepared byte mismatch: '+row['path'])
need(not (HERE/'RUN-INTENT.json').exists(),'One preview intent already exists; root must reconcile, no blind replay')
with (HERE/'RUN-INTENT.json').open('x') as f:json.dump({'requested_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'release':release,'source':'COUNTERFACTUAL SOURCE POSE; actual96c4 Bardwell source skin plus proposed native bone keys; no candidate export','bounded_browser_seconds':80},f,indent=2)
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  name=self.path.split('?',1)[0];path=(HERE/('preview.html' if name=='/' else name.lstrip('/'))).resolve()
  allowed=name=='/' or name.startswith('/vendor/') or name in {'/inputs/bardwell_otis_1835.lod0.glb','/inputs/native-bone-curves.json'}
  if not allowed or not path.is_relative_to(HERE) or not path.is_file():self.send_error(404);return
  data=path.read_bytes();self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(path.name)[0] or 'application/octet-stream');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 process=subprocess.Popen(['node',str(HERE/'capture_preview.cjs'),str(server.server_address[1])],env={**os.environ,'NODE_PATH':'/workspace/shared/chicago-browser/node_modules'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 try:stdout,stderr=process.communicate(timeout=80)
 except subprocess.TimeoutExpired:
  os.killpg(process.pid,signal.SIGKILL);stdout,stderr=process.communicate(timeout=3)
  (HERE/'PREVIEW-stdout.log').write_text(stdout);(HERE/'PREVIEW-stderr.log').write_text(stderr);raise RuntimeError('bounded preview timeout; owned process group killed')
 (HERE/'PREVIEW-stdout.log').write_text(stdout);(HERE/'PREVIEW-stderr.log').write_text(stderr)
 need(process.returncode==0,'owned browser failed: '+stderr[-1500:])
finally:
 server.shutdown();server.server_close();thread.join(timeout=2)
 (HERE/'SERVER-CLOSED.json').write_text(json.dumps({'closed':True,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
print('Finite preview complete; owned browser and server closed.')
