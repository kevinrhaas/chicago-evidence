"""Prepare explicit native key curves from the already qualified source pose.
No model export, generation, browser or server execution.
"""
import sys,pathlib,json,hashlib,importlib.util
sys.dont_write_bytecode=True
import numpy as np
from scipy.spatial.transform import Rotation
HERE=pathlib.Path(__file__).resolve().parent
PROPOSAL=pathlib.Path('/workspace/shared/human-standing-idle-proposal-20261022')
OLD=pathlib.Path('/workspace/shared/human-standing-idle-native-readback-20261022')
APP=pathlib.Path('/workspace/chicago/chicago/4d')
sys.path.insert(0,str(PROPOSAL/'proposed/tools'));sys.path.insert(0,str(APP/'tools'))
import human_standing_idle as I
from human_grounded_gait import prepare_legs
recipe=json.loads((PROPOSAL/'proposed/data/humans/recipes/worker_1835.json').read_text())
variant=next(v for v in recipe['proof_variants']if v['id']=='bardwell_otis_1835')
assert variant['standing_idle_profile']==I.PROFILE
prepared=json.loads((APP/variant['body_input']).read_text())
legs=prepare_legs({b['name']:b for b in prepared['skeleton']},recipe.get('height_scale',1))
path=HERE/'inputs/bardwell_otis_1835.lod0.glb';sys.argv=[__file__,str(path)]
spec=importlib.util.spec_from_file_location('native_reader',OLD/'read_gltf.py')
D=importlib.util.module_from_spec(spec);spec.loader.exec_module(D)
G=D.G;rest=D.worlds({});names={n['name']:i for i,n in enumerate(G['nodes'])}
idle=next(a for a in G['animations']if a['name']=='idle');base={}
for ch in idle['channels']:
 s=idle['samplers'][ch['sampler']];base.setdefault(ch['target']['node'],{})[ch['target']['path']]=D.acc(s['output'])[0].tolist()
keys=[]
for t in np.linspace(0,1,241):
 pose=I.pose_at_phase(legs,float(t));over={i:dict(v)for i,v in base.items()}
 for name,E in pose['relative_source_rotation_matrices'].items():
  ni=names[name];parent=D.PARENT[ni]
  over[ni]['rotation']=Rotation.from_matrix(rest[parent][:3,:3].T@np.array(E)@rest[ni][:3,:3]).as_quat().tolist()
 ni=names['pelvis'];parent=D.PARENT[ni]
 over[ni]['translation']=(np.array(base[ni]['translation'])+np.linalg.solve(rest[parent][:3,:3],pose['pelvis_delta_m'])).tolist();keys.append(over)
tracks=[]
for ni,parts in keys[0].items():
 for kind in parts:
  values=np.array([k[ni][kind]for k in keys]);times=np.linspace(0,8,241)
  if np.max(np.ptp(values,axis=0))<1e-12:values=values[[0,-1]];times=times[[0,-1]]
  if kind=='rotation':
   for i in range(1,len(values)):
    if float(values[i]@values[i-1])<0:values[i]*=-1
  tracks.append({'node_name':G['nodes'][ni]['name'],'property':'quaternion'if kind=='rotation'else'position','times_s':times.tolist(),'values':values.ravel().tolist(),'interpolation':'LINEAR'})
out={'scope':'COUNTERFACTUAL SOURCE POSE, not actual Blender candidate export or photographic acceptance',
     'canonical_source_head':'96c4da4b1fe68e6dec3b18c15da2f14c596a60c5','canonical_run':39736567239,
     'canonical_GLBlod0_sha256':hashlib.sha256(D.B).hexdigest(),'duration_s':8,'tracks':tracks,
     'profile':I.PROFILE,'helper_sha256':hashlib.sha256((PROPOSAL/'proposed/tools/human_standing_idle.py').read_bytes()).hexdigest(),
     'native_qualification_sha256':hashlib.sha256((PROPOSAL/'ACTUAL-SKIN-SOURCE-POSE-QUALIFICATION.json').read_bytes()).hexdigest()}
(HERE/'inputs/native-bone-curves.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
print('Prepared112 explicit bone tracks; no browser/server/export.')
