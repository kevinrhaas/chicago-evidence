// Adapted finite caller from the existing V3 human source-preview fixture.
const {chromium}=require('playwright');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const out=__dirname,hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
if(!fs.existsSync(path.join(out,'RUN-INTENT.json')))throw Error('Use released Python caller; preview intent missing');
const scope='COUNTERFACTUAL SOURCE POSE on unchanged actual canonical96c4 Bardwell webLOD0. Explicit proposed native bone curves only. No candidate Blender export, world, photographic or lifelike acceptance.';
(async()=>{
 const started=new Date().toISOString(),captures=[],videos=[],errors=[],inputs=JSON.parse(fs.readFileSync(path.join(out,'INPUTS.json')));
 let browser=null,closed=false,failed=null,framing=null;
 const attach=page=>{
  const note=(kind,message)=>errors.push({kind,message,at:new Date().toISOString()});
  page.on('pageerror',e=>note('page',e.message));page.on('console',m=>{if(m.type()==='error')note('console',m.text());});
  page.on('requestfailed',r=>note('request',r.url()+': '+r.failure()?.errorText));page.on('response',r=>{if(r.status()>=400)note('http',r.status()+' '+r.url());});
  return page.route('**/*',route=>{const u=new URL(route.request().url());return u.protocol==='data:'||u.protocol==='blob:'||u.hostname==='127.0.0.1'?route.continue():route.abort();});
 };
 const open=async context=>{const page=await context.newPage();await attach(page);await page.goto('http://127.0.0.1:'+process.argv[2]+'/',{timeout:10000});await page.waitForFunction(()=>window.preview?.ready,null,{timeout:10000});return page;};
 const guard=r=>{if(r.framing?.passed!==true||r.posed_render?.shoe_rendered!==true||r.posed_render?.shoe_frustumCulled!==false||r.glError!==0||errors.length)throw Error('Framing, actual shoe draw, GL or browser guard failed');};
 try{
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
  const context=await browser.newContext({viewport:{width:1280,height:900}}),page=await open(context);
  framing=await page.evaluate(()=>preview.prepareFraming());fs.writeFileSync(path.join(out,'FRAMING-PREFLIGHT.json'),JSON.stringify({scope,started,framing},null,2));
  for(const after of[false,true]){
   await page.evaluate(v=>preview.load(v),after);
   for(const view of['front','quarter'])for(const time_s of[0,.5,1,2,6,8]){
    await page.evaluate(t=>preview.pose('idle',t),time_s);const r=await page.evaluate(v=>preview.view(v),view);guard(r);
    const png=`${after?'counterfactual':'canonical'}-${view}-t${String(time_s).replace('.','p')}.png`;
    await page.screenshot({path:path.join(out,png)});captures.push({png,sha256:hash(path.join(out,png)),...r});
    fs.writeFileSync(path.join(out,'PARTIAL.json'),JSON.stringify({scope,started,captures,videos,errors,browser_closed:false},null,2));
   }
  }
  await page.evaluate(()=>preview.dispose());await context.close();
  fs.mkdirSync(path.join(out,'video-work'),{recursive:true});
  for(const view of['front','quarter']){
   const context=await browser.newContext({viewport:{width:1280,height:900},recordVideo:{dir:path.join(out,'video-work'),size:{width:1280,height:900}}});
   const page=await open(context);await page.evaluate(f=>preview.useFraming(f),framing);await page.evaluate(()=>preview.load(true));
   await page.evaluate(()=>preview.pose('idle',0));const initial=await page.evaluate(v=>preview.view(v),view);guard(initial);
   const animation=await page.evaluate(()=>preview.animate8());const final=await page.evaluate(v=>preview.view(v),view);guard(final);
   const recording=page.video();await context.close();const file=`counterfactual-${view}-motion.webm`;await recording.saveAs(path.join(out,file));
   videos.push({file,sha256:hash(path.join(out,file)),bytes:fs.statSync(path.join(out,file)).size,view,animation,initial,final,
                scope:'Unedited Playwright viewport video includes setup followed by8seconds proposed motion; original pixels, no candidate export claim'});
  }
 }catch(e){failed={name:e.name,message:e.message,stack:e.stack};}
 finally{
  if(browser){await browser.close();closed=true;}
  fs.writeFileSync(path.join(out,'RUNTIME-SOURCE-PREVIEW.json'),JSON.stringify({scope,started,finished:new Date().toISOString(),inputs,
   caller_sha256:hash(__filename),fixture_sha256:hash(path.join(out,'preview.html')),captures,videos,framing,errors,browser_closed:closed,failed,
   technical_capture_complete:!failed&&errors.length===0&&captures.length===24&&videos.length===2,
   actual_candidate_export:false,lifelike_accepted:false,canonical_or_photographic_accepted:false},null,2));
 }
 if(failed)throw Error(failed.message);
 console.log('Finite source-pose preview captured24PNGs and2motion videos. Browser closed; visual acceptance remains open.');
})().catch(e=>{console.error(e);process.exitCode=1;});
