# SPDX-License-Identifier: GPL-3.0-or-later
"""Restrained reconstructed standing motion, with analytic planted-ankle IK.

Pure source-Y-up mathematics. No body, rest bone, weights or mesh edits.
This proposes kinematics, not measured breathing or physical load transfer.
"""
from __future__ import annotations
import math

PROFILE = {
    'id': 'bardwell_grounded_standing_v1',
    'duration_s': 8.0,
    'fps': 30,
    'pelvis_lateral_amplitude_m': .008,
    'pelvis_lowering_m': .001,
    'pelvis_extra_lowering_m': .0005,
    'breath_rotation_deg': .6,
    'head_yaw_deg': 2.2,
    'head_nod_deg': .35,
}
IDENTITY = ((1.,0.,0.),(0.,1.,0.),(0.,0.,1.))

def add(a,b):return tuple(x+y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def mul(a,s):return tuple(x*s for x in a)
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def norm(a):return math.sqrt(dot(a,a))
def unit(a):
    length=norm(a)
    if length<1e-10:raise ValueError('degenerate idle direction')
    return mul(a,1/length)
def transpose(m):return tuple(zip(*m))
def matmul(a,b):return tuple(tuple(dot(row,col)for col in zip(*b))for row in a)

def shortest_arc(a,b):
    a,b=unit(a),unit(b);c=dot(a,b)
    if c < -.999999:raise ValueError('idle antiparallel bone frame')
    x,y,z=cross(a,b);k=((0.,-z,y),(z,0.,-x),(-y,x,0.));kk=matmul(k,k)
    return tuple(tuple(IDENTITY[i][j]+k[i][j]+kk[i][j]/(1+c)for j in range(3))for i in range(3))

def axis_rotation(axis,angle):
    c,s=math.cos(angle),math.sin(angle)
    if axis=='x':return ((1.,0.,0.),(0.,c,-s),(0.,s,c))
    if axis=='y':return ((c,0.,s),(0.,1.,0.),(-s,0.,c))
    raise ValueError('unsupported idle rotation axis')

def validate_profile(profile):
    if profile!=PROFILE:raise ValueError('unreviewed standing idle profile')
    return profile

def pose_at_phase(legs,phase,profile=PROFILE):
    validate_profile(profile)
    if not math.isfinite(phase):raise ValueError('finite standing idle phase required')
    # Exact endpoint closure before trigonometry, including rotation channels.
    phase=phase%1.0;angle=2*math.pi*phase
    lateral=profile['pelvis_lateral_amplitude_m']*math.sin(angle)
    lowering=profile['pelvis_lowering_m']+profile['pelvis_extra_lowering_m']*math.sin(angle)**2
    delta=(lateral,-lowering,0.)
    rotations={};witnesses={}
    for side,leg in legs.items():
        hip,knee,ankle=map(tuple,(leg['hip'],leg['knee'],leg['ankle']))
        l1,l2=leg['lengths'];newhip=add(hip,delta);u=unit(sub(ankle,newhip));distance=norm(sub(ankle,newhip))
        if not abs(l1-l2)<distance<l1+l2:raise ValueError('unreachable planted idle ankle')
        # Knee bends toward source +Z; the pole is projected perpendicular to
        # the actual hip-ankle line, allowing lateral hip motion without a
        # coronal-only sideways knee hinge.
        pole=unit(sub((0.,0.,1.),mul(u,u[2])))
        along=(l1*l1-l2*l2+distance*distance)/(2*distance)
        height=math.sqrt(max(0.,l1*l1-along*along))
        newknee=add(add(newhip,mul(u,along)),mul(pole,height))
        thigh=shortest_arc(sub(knee,hip),sub(newknee,newhip))
        calf=shortest_arc(sub(ankle,knee),sub(ankle,newknee))
        rotations.update({'thigh_'+side:thigh,'calf_'+side:matmul(transpose(thigh),calf),
                          'foot_'+side:transpose(calf),'ball_'+side:IDENTITY})
        witnesses[side]={'hip_m':newhip,'knee_m':newknee,'fixed_ankle_m':ankle,
                         'segment_lengths_m':(norm(sub(newknee,newhip)),norm(sub(ankle,newknee))),
                         'rest_segment_lengths_m':(l1,l2)}
    rotations['spine_02']=axis_rotation('x',math.radians(profile['breath_rotation_deg'])*math.sin(2*angle))
    rotations['head']=matmul(axis_rotation('y',math.radians(profile['head_yaw_deg'])*math.sin(angle)),
                            axis_rotation('x',math.radians(profile['head_nod_deg'])*math.sin(2*angle)))
    return {'pelvis_delta_m':delta,'relative_source_rotation_matrices':rotations,'legs':witnesses}
