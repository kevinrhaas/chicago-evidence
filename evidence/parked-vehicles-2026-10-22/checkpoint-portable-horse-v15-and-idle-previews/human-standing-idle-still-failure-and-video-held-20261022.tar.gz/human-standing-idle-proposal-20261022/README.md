# Bardwell restrained standing idle — prepared source proposal

**Source kinematics qualified; actual Blender export and browser review remain held.** `proposal.patch` contains the complete three-file proposal; `proposed/` contains the reviewable files. Nothing was installed in the app.

The existing canonical pipeline is pinned to source head **96c4da4b1fe68e6dec3b18c15da2f14c596a60c5**, run **39736567239**. Eight authoring source-input hashes still match that canonical record. All four original Bardwell web GLB hashes and byte counts also match. Body, wardrobe, rest meshes, bone rest geometry, armature, weights, material authoring and non-Bardwell recipe entries are unchanged. No new person is created.

Only Bardwell opts into an **8-second idle** with 241 inclusive keys at 30fps. The existing ±0.6° torso breathing-like bend now has a four-second period. The head independently yaws ±2.2° and nods ±0.35°. The pelvis moves ±8mm laterally with 1–1.5mm lowering. An analytic three-dimensional two-bone leg solve preserves each original ankle location, uses a forward knee pole, preserves both segment lengths and compensates foot orientation. It changes bone pose only; it does not move the figure root or translate shoe meshes independently. The slight lowering avoids stretching the originally straight legs. Actual visual knee/hip/garment appearance still needs review.

`ACTUAL-SKIN-SOURCE-POSE-QUALIFICATION.json` evaluates the proposed source rotations and translations on the **unchanged actual canonical GLB rest matrices, inverse binds and skin weights**. This is a counterfactual source-pose proof, not a newly exported candidate. Full original shoe surfaces were skinned at **241 authored keys plus 240 between-key samples** for each of the four LODs. Every other original mesh was fully skinned at 17 inclusive phases.

The final native pass completed in **5.90 seconds** under a 14-second CPU ceiling. Maximum original-shoe drift was **0.000043mm**, including between-key samples. Maximum actual leg segment-length error was **0.000076mm**; source analytic length error was below 2e-16m. Source/export rest-joint rounding differed by at most **0.000268mm**. All mesh endpoint position seams were zero. The root stayed stationary; the pelvis moved 16mm laterally peak to peak. These results support planted-feet pelvis sway, not physical pressure or load-transfer simulation.

Two actual-skin negative controls were detected: removing foot-orientation compensation moved shoe surfaces **12.44mm**; removing leg IK moved them **8.14mm**. The proof therefore checks actual shoe skin deformation rather than only reporting fixed ankle targets.

`MANIFEST.json` preserves canonical/source pins, unchanged-source checks, proposal hashes and outstanding work. Use **proposal.patch** for the complete final change. The original canonical assets and master remain untouched.

Before integrating, one actual canonical Blender build/export must demonstrate that the source-to-Blender rest-basis adapter produces the predicted transforms. Then qualify actual exported master/web LODs, shoe contacts and interpolation, cloth/body intersections, idle/walk transitions and desktop/mobile pixels. Visual naturalness, biomechanics, photographic quality and production acceptance remain open. No browser, gate, Git ref/index, ticket, PR or app-source mutation occurred in this work.
