"""Counterfactual source-pose qualification on unchanged actual canonical GLBs.

No asset export: evaluates proposed source transforms through actual LBS weights.
"""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(14,14))
import sys,pathlib,json,time,importlib.util,hashlib
sys.dont_write_bytecode=True
import numpy as np
OUT=pathlib.Path(__file__).resolve().parent
APP=pathlib.Path('/workspace/chicago/chicago/4d')
OLD=pathlib.Path('/workspace/shared/human-standing-idle-native-readback-20261022')
sys.path.insert(0,str(OUT/'proposed/tools'));sys.path.insert(0,str(APP/'tools'))
import human_standing_idle as I
from human_grounded_gait import prepare_legs
started=time.monotonic()
recipe=json.loads((OUT/'proposed/data/humans/recipes/worker_1835.json').read_text())
variant=next(v for v in recipe['proof_variants']if v['id']=='bardwell_otis_1835')
assert variant['standing_idle_profile']==I.PROFILE
prepared=json.loads((APP/variant['body_input']).read_text())
bones={b['name']:b for b in prepared['skeleton']};legs=prepare_legs(bones,recipe.get('height_scale',1))
keyphases=np.linspace(0,1,241);keyposes=[I.pose_at_phase(legs,float(t))for t in keyphases]

def matrixq(m):
    # All selected source rotations and actual joint rest frames are away from
    # the 180degree singularity in this pipeline; use robust eigen decomposition.
    from scipy.spatial.transform import Rotation
    return Rotation.from_matrix(m).as_quat()
def slerp(a,b,f):
    dot=float(a@b)
    if dot<0:b=-b;dot=-dot
    if dot>.9995:
        q=a*(1-f)+b*f;return q/np.linalg.norm(q)
    angle=np.arccos(np.clip(dot,-1,1));return(a*np.sin((1-f)*angle)+b*np.sin(f*angle))/np.sin(angle)

rows=[];controls=[];worst_length=0.;worst_source_world_joint=0.
for pose in keyposes:
    for leg in pose['legs'].values():worst_length=max(worst_length,max(abs(a-b)for a,b in zip(leg['segment_lengths_m'],leg['rest_segment_lengths_m'])))
for lod in range(4):
    path=APP/f'assets/humans/web/bardwell_otis_1835.lod{lod}.glb'
    sys.argv=[__file__,str(path)]
    spec=importlib.util.spec_from_file_location(f'reader{lod}',OLD/'read_gltf.py')
    D=importlib.util.module_from_spec(spec);spec.loader.exec_module(D)
    G=D.G;rest=D.worlds({});names={n['name']:i for i,n in enumerate(G['nodes'])};idle=next(a for a in G['animations']if a['name']=='idle')
    base={}
    for ch in idle['channels']:
        s=idle['samplers'][ch['sampler']];base.setdefault(ch['target']['node'],{})[ch['target']['path']]=D.acc(s['output'])[0].tolist()
    for side,leg in legs.items():
        for label,node in [('hip','thigh'),('knee','calf'),('ankle','foot')]:
            worst_source_world_joint=max(worst_source_world_joint,float(np.linalg.norm(rest[names[node+'_'+side]][:3,3]-leg[label])))
    for m in rest.values():assert np.max(np.abs(m[:3,:3].T@m[:3,:3]-np.eye(3)))<1e-5
    keys=[]
    for pose in keyposes:
        over={i:dict(v)for i,v in base.items()}
        for name,E in pose['relative_source_rotation_matrices'].items():
            ni=names[name];parent=D.PARENT[ni]
            local=rest[parent][:3,:3].T@np.array(E)@rest[ni][:3,:3]
            over[ni]['rotation']=matrixq(local).tolist()
        pi=names['pelvis'];pp=D.PARENT[pi]
        over[pi]['translation']=(np.array(base[pi]['translation'])+np.linalg.solve(rest[pp][:3,:3],pose['pelvis_delta_m'])).tolist()
        keys.append(over)
    skin=G['skins'][0];ib=D.acc(skin['inverseBindMatrices']).reshape((-1,4,4)).transpose(0,2,1)
    meshes=[]
    for node in G['nodes']:
        if 'mesh'not in node:continue
        for pr in G['meshes'][node['mesh']]['primitives']:
            a=pr['attributes'];p=D.acc(a['POSITION']);j=D.acc(a['JOINTS_0']).astype(int);w=D.acc(a['WEIGHTS_0'])
            # Full original shoe surfaces at every key and midpoint. Full other
            # meshes at17 phases to verify actual posed surface movement/seams.
            meshes.append((node['name'],np.c_[p,np.ones(len(p))],j,w))
    arrays={name:[]for name,*_ in meshes};sample_times=[];ankles={s:[]for s in legs};pivots={n:[]for n in['head','pelvis','root']};segmenterrors=[];footrot=[]
    for step in range(481):
        i=step//2;f=.5 if step%2 else 0.;over=keys[i]
        if f:
            over={ni:{k:(slerp(np.array(v),np.array(keys[i+1][ni][k]),f).tolist()if k=='rotation'else((np.array(v)+keys[i+1][ni][k])*.5).tolist())for k,v in parts.items()}for ni,parts in keys[i].items()}
        world=D.worlds(over);matrices=np.stack([world[x]for x in skin['joints']])@ib
        sample_times.append(step/60)
        for side,leg in legs.items():
            hip,knee,ankle=[world[names[n+'_'+side]][:3,3]for n in['thigh','calf','foot']]
            ankles[side].append(ankle.tolist())
            segmenterrors.extend([abs(np.linalg.norm(knee-hip)-leg['lengths'][0]),abs(np.linalg.norm(ankle-knee)-leg['lengths'][1])])
            footrot.append(float(np.max(np.abs(world[names['foot_'+side]][:3,:3]-rest[names['foot_'+side]][:3,:3]))))
        for name in pivots:pivots[name].append(world[names[name]][:3,3].tolist())
        for name,p,j,w in meshes:
            if 'closed_shoes'not in name and step%30:continue
            v=np.einsum('nw,nwi->ni',w,np.einsum('nwij,nj->nwi',matrices[j],p))[:,:3]
            assert np.isfinite(v).all();arrays[name].append(v)
    metrics={}
    for name,points in arrays.items():
        v=np.array(points);delta=np.linalg.norm(v-v[0],axis=2)
        metrics[name]={'vertices':v.shape[1],'sample_count':len(v),'maximum_displacement_from_first_m':float(delta.max()),
                       'loop_position_seam_m':float(np.linalg.norm(v[-1]-v[0],axis=1).max()),
                       'maximum_per_vertex_xyz_span_m':np.ptp(v,axis=0).max(axis=0).tolist()}
        if 'closed_shoes'in name:
            metrics[name].update({'alltime_min_y_m':float(v[:,:,1].min()),'alltime_max_y_m':float(v[:,:,1].max()),
                                 'minimum_y_span_m':float(np.ptp(v[:,:,1].min(axis=1))),
                                 'max_keyframe_displacement_m':float(delta[::2].max()),'max_between_key_displacement_m':float(delta[1::2].max()),
                                 'position_seam_velocity_finite_difference_m_s':float(np.linalg.norm((v[-1]-v[-2]-v[1]+v[0])*60,axis=1).max())})
    if lod==0:
        shoe=next(x for x in meshes if 'closed_shoes'in x[0]);name,p,j,w=shoe
        reference=arrays[name][0]
        for label,removed in [('missing_foot_orientation_compensation',['foot_l','foot_r']),
                              ('missing_all_leg_IK',['thigh_l','calf_l','foot_l','thigh_r','calf_r','foot_r'])]:
            bad={ni:dict(values)for ni,values in keys[60].items()}
            for n in removed:bad[names[n]]['rotation']=base[names[n]]['rotation']
            world=D.worlds(bad);matrices=np.stack([world[x]for x in skin['joints']])@ib
            points=np.einsum('nw,nwi->ni',w,np.einsum('nwij,nj->nwi',matrices[j],p))[:,:3]
            drift=float(np.linalg.norm(points-reference,axis=1).max())
            controls.append({'name':label,'phase':.25,'actual_shoe_surface_drift_m':drift,'detected_by_0_1mm_limit':drift>.0001})
    rows.append({'lod':lod,'asset_path':str(path),'asset_sha256':hashlib.sha256(D.B).hexdigest(),'bytes':len(D.B),
                 'mesh_metrics':metrics,'fixed_ankle_max_error_from_original_m':{s:float(np.linalg.norm(np.array(v)-legs[s]['ankle'],axis=1).max())for s,v in ankles.items()},
                 'segment_length_max_error_m':max(segmenterrors),'foot_world_orientation_max_component_error':max(footrot),
                 'world_pivot_xyz_span_m':{k:np.ptp(v,axis=0).tolist()for k,v in pivots.items()}})
receipt={'scope':'COUNTERFACTUAL SOURCE-POSE QUALIFICATION ONLY: proposed exact source rotations/translation applied to unchanged actual canonical GLB rest matrices and original LBS surfaces. Not actual Blender-exported candidate, browser/pixel, garment collision or biomechanical load-transfer acceptance.',
         'canonical_source_head':'96c4da4b1fe68e6dec3b18c15da2f14c596a60c5','canonical_run':39736567239,
         'profile':I.PROFILE,'source_key_times_s':(keyphases*8).tolist(),'shoe_sample_times_s':sample_times,
         'actual_skinning':'full original shoes every30fps key and60fps midpoint; full other original meshes at17 inclusive phases',
         'source_analytic_segment_length_error_m':worst_length,'source_vs_export_rest_joint_error_m':worst_source_world_joint,
         'negative_controls':controls,'LODs':rows,'elapsed_s':time.monotonic()-started}
assert all(c['detected_by_0_1mm_limit']for c in controls)
receipt['source_contact_qualified']=all(next(v for k,v in r['mesh_metrics'].items()if 'closed_shoes'in k)['maximum_displacement_from_first_m']<.0001 and r['segment_length_max_error_m']<1e-5 for r in rows)
(OUT/'ACTUAL-SKIN-SOURCE-POSE-QUALIFICATION.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
