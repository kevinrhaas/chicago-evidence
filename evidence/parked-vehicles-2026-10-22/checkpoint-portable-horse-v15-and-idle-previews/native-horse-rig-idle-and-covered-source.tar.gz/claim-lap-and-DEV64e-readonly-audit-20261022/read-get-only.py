import subprocess,json,pathlib,concurrent.futures,datetime
out=pathlib.Path(__file__).parent
wanted=[1789,2794,2800,2980,2803,2795,2796]
def get(name,endpoint):
 r=subprocess.run(['gh','api','--method','GET','-H','Cache-Control: no-cache',endpoint],capture_output=True,text=True,timeout=30)
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
 if r.returncode:raise RuntimeError(name+':'+r.stderr)
 return json.loads(r.stdout)
first=[('tickets-main','repos/kevinrhaas/chicago-tickets/git/ref/heads/main'),('claim-refs','repos/kevinrhaas/chicago/git/matching-refs/heads/claim/'),('lap1175-ref','repos/kevinrhaas/chicago/git/matching-refs/heads/lap/pr-1175'),('pr1175','repos/kevinrhaas/chicago/pulls/1175'),('DEV-delta','repos/kevinrhaas/chicago/compare/a66484db3f5ddb1a3943bc6d0b5ff44e4dfd6f36...64e83fcd')]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:result=dict(zip([n for n,e in first],pool.map(lambda x:get(*x),first)))
main=result['tickets-main']['object']['sha']; tasks=[]
for n in wanted:
 paths=list(pathlib.Path('/workspace/chicago-tickets').glob('T-*/T-'+str(n)+'-*.md'));p=paths[0].relative_to('/workspace/chicago-tickets')
 tasks.append(('ticket-'+str(n),'repos/kevinrhaas/chicago-tickets/contents/'+str(p)+'?ref='+main))
refs=[r for r in result['claim-refs'] if r['ref'].split('/')[-1] in ['t-'+str(n) for n in wanted]]+result['lap1175-ref']
for r in refs:tasks.append(('marker-'+r['ref'].replace('/','__'),'repos/kevinrhaas/chicago/git/commits/'+r['object']['sha']))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:more=dict(zip([n for n,e in tasks],pool.map(lambda x:get(*x),tasks)))
print(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tickets_main':main,'read':len(first)+len(tasks),'markers':[(r['ref'],r['object']['sha']) for r in refs],'comparison':{k:result['DEV-delta'].get(k) for k in ['status','ahead_by','total_commits']},'delta_files':[{'filename':f['filename'],'status':f['status'],'changes':f['changes']} for f in result['DEV-delta'].get('files',[])],'pr1175':{k:result['pr1175'].get(k) for k in ['state','draft','updated_at','mergeable_state']},'pr1175_head':result['pr1175']['head']['sha'],'pr1175_base':result['pr1175']['base']['sha']}))
