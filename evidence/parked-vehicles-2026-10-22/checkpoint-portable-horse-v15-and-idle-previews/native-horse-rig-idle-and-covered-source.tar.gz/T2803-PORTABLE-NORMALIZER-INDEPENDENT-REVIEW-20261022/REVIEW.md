V3 is clear for one separately root-authorized experimental normalization with structural and full Khronos validation. It is not accepted for application intake, idle playback, or loaded parity.

V1/V2 promoted nonidentity matrices would introduce three skinned-local-transform warnings. V3 identity roots resolve that source blocker; JOINTS views explicitly use ARRAY_BUFFER. All decoded animation data and contributing skin indices are preserved. Skeleton hierarchy and IBMs remain unchanged. The declared mesh basis change needs actual loaded POSITION and NORMAL parity, including the native default state and six one-key Armature overrides. Position cancellation algebra alone does not establish normal parity.

The held command performs one source-pinned export, independent decoded structural checks, then unlimited-issue Khronos validation. It retains any failure and never retries. It does not append idle or touch app files.
