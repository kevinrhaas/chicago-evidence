"""Root-release-only one-shot experiment; no browser, app writes or animation acceptance."""
import argparse, hashlib, json, os, pathlib, struct, subprocess, sys
import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
PACK = pathlib.Path('/workspace/shared/T2803-LOSSLESS-PORTABLE-NORMALIZER-SOURCE-V3-20261022')
SOURCE = pathlib.Path('/workspace/shared/horse-public-base-search-20261022/horse-53a6eb7ccf054aa2a378dd7ec08f88fe.glb')
PIN = '41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988'
PRODUCER = 'd4b4dbff99ea1479d07bee970b10a929892f7cacf62356643b64eeff43b30dd8'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):
    b=p.read_bytes(); assert struct.unpack_from('<III',b)==(0x46546c67,2,len(b))
    n,t=struct.unpack_from('<II',b,12); assert t==0x4e4f534a
    size,kind=struct.unpack_from('<II',b,20+n); assert kind==0x004e4942 and size==len(b)-28-n
    return json.loads(b[20:20+n]),b[28+n:]
def decoded(d,b,i):
    a=d['accessors'][i]; v=d['bufferViews'][a['bufferView']]; assert not a.get('sparse')
    dtype=np.dtype({5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']]); w={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
    return np.ndarray((a['count'],w),dtype=dtype,buffer=b,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*dtype.itemsize),dtype.itemsize)).copy()
def main():
    p=argparse.ArgumentParser(); p.add_argument('--root-release',required=True); p.add_argument('--output-dir',type=pathlib.Path,required=True); a=p.parse_args()
    assert a.root_release=='ONE_V3_NORMALIZATION_STRUCTURAL_KHRONOS_ONLY'
    out=a.output_dir.resolve(); assert out.is_relative_to(pathlib.Path('/workspace/shared')) and not out.exists()
    assert sha(SOURCE)==PIN and sha(PACK/'normalize_portable_import.py')==PRODUCER
    for row in json.loads((PACK/'MANIFEST.json').read_text())['files']:
        f=PACK/row['path']; assert f.stat().st_size==row['bytes'] and sha(f)==row['sha256']
    subprocess.run([sys.executable,'-B',str(PACK/'normalize_portable_import.py'),'--lane-released','--output-dir',str(out)],check=True,stdout=subprocess.DEVNULL)
    original,oldbin=load(SOURCE); result,newbin=load(out/'horse-sevket-portable-import-v3.glb')
    receipt=json.loads((out/'NORMALIZATION-RECEIPT.json').read_text()); assert receipt['source_unchanged_after'] and newbin[:len(oldbin)]==oldbin
    assert result['accessors'][:len(original['accessors'])]==original['accessors']
    assert result['bufferViews'][:len(original['bufferViews'])]==original['bufferViews']
    expected=json.loads(json.dumps(original)); expected['accessors']=result['accessors']; expected['bufferViews']=result['bufferViews']; expected['buffers']=result['buffers']; expected['asset']=result['asset']
    assert result['buffers'][0]['byteLength']<=len(newbin)
    asset=dict(result['asset']); extras=dict(asset.get('extras',{})); extras.pop('portable_import_adaptation');
    if extras: asset['extras']=extras
    else: asset.pop('extras',None)
    assert asset==original['asset']
    replacements={}
    for ai,si,field,old,new in receipt['animation_reference_changes']:
        assert original['animations'][ai]['samplers'][si][field]==old and result['animations'][ai]['samplers'][si][field]==new
        assert decoded(original,oldbin,old).tobytes()==decoded(result,newbin,new).tobytes()
        assert 'byteStride' not in result['bufferViews'][result['accessors'][new]['bufferView']]
        replacements[new]=old; expected['animations'][ai]['samplers'][si][field]=new
    changes=0
    for r in receipt['zero_weight_joint_changes']:
        mi,pi,key=r['mesh'],r['primitive'],r['joint_key']; old,new=r['old_accessor'],r['new_accessor']
        attrs=original['meshes'][mi]['primitives'][pi]['attributes']; assert attrs[key]==old
        j=decoded(original,oldbin,old); w=decoded(original,oldbin,attrs['WEIGHTS_'+key.split('_')[1]])
        wanted=j.copy(); wanted[w==0]=0; actual=decoded(result,newbin,new); assert actual.tobytes()==wanted.tobytes()
        count=int(np.count_nonzero(wanted!=j)); assert count==r['zero_weight_components_changed']; changes+=count
        assert result['bufferViews'][result['accessors'][new]['bufferView']]['target']==34962
        expected['meshes'][mi]['primitives'][pi]['attributes'][key]=new; replacements[new]=old
    assert changes==15897 and set(replacements)==set(range(len(original['accessors']),len(result['accessors'])))
    for r in receipt['promoted_mesh_nodes']:
        i=r['node']; assert i in (21,22,23) and r['original_parent']==4
        expected['nodes'][4]['children'].remove(i)
        for key in ('matrix','translation','rotation','scale'): expected['nodes'][i].pop(key,None)
        for scene in r['scene_membership']: expected['scenes'][scene]['nodes'].append(i)
    assert len(receipt['promoted_mesh_nodes'])==3 and result==expected
    assert sha(SOURCE)==PIN and sha(PACK/'normalize_portable_import.py')==PRODUCER
    check={'status':'STRUCTURAL_PASS_ONLY','source_sha256':PIN,'producer_sha256':PRODUCER,'derived_sha256':sha(out/'horse-sevket-portable-import-v3.glb'),'original_bin_prefix_exact':True,'zero_weight_joint_components_changed':changes,'decoded_animation_values_exact':True,'skeleton_skins_geometry_weights_uv_maps_materials_exact':True,'declared_mesh_parent_and_basis_changes_only':True,'loaded_position_normal_mixer_parity':'NOT_RUN_NOT_ACCEPTED','idle_not_appended':True}
    (out/'INDEPENDENT-STRUCTURAL.json').write_text(json.dumps(check,indent=2)+'\n')
    subprocess.run(['node',str(HERE/'validate-held.cjs'),str(out)],check=True)
    print(json.dumps(check))
if __name__=='__main__': main()
