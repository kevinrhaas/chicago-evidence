#!/usr/bin/env bash
set -euo pipefail
# HELD: root must explicitly authorize ONE run; fresh output path required.
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
ulimit -t 15
exec timeout --signal=TERM --kill-after=1s 15s nice -n 15 python3 -B /workspace/shared/T2803-PORTABLE-NORMALIZER-INDEPENDENT-REVIEW-20261022/run-held.py --root-release ONE_V3_NORMALIZATION_STRUCTURAL_KHRONOS_ONLY --output-dir "$1"
