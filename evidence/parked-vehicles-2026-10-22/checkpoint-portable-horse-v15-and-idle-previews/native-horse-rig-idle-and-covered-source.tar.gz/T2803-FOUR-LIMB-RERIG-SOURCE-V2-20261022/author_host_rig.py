"""Source-specific rig/weight authoring proposal. --inspect-only does native arithmetic ONLY.
No model export is implemented here: require independent anatomy/source review before bake.
"""
import argparse,hashlib,json,pathlib,sys,time,resource
resource.setrlimit(resource.RLIMIT_CPU,(12,12))
import numpy as np
ORIGINAL='41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988'
ROOT=pathlib.Path('/workspace/shared');CONTROL=ROOT/'T2803-native-rerig-fallback-20261022/RERIG-CONTROLS-PROPOSAL.json';CONTACT=ROOT/'horse-standing-intake-proposal-V2-20261022/proposed/data/transport/parked/horse-sevket-sidecar.json'
CONTROL_SHA='594cc73f55c79a63b847e71340f23a5003e7988f799a430a73bdc41154f22d07';CONTACT_SHA='3ba16db2f4fee984431c75477867a7780fe55378fdd4ac3f89cb91465dade80a'
sys.path.insert(0,str(ROOT/'horse-public-base-search-20261022'));import read_native_pose as D

def smooth(a,b,x):
 t=np.clip((x-a)/(b-a),0,1);return float(t*t*(3-2*t))
def closest(point,chain):
 best=None
 for k in range(len(chain)-1):
  a,b=chain[k:k+2];d=b-a;t=float(np.clip(np.dot(point-a,d)/np.dot(d,d),0,1));dist=float(np.linalg.norm(point-a-t*d))
  if best is None or dist<best[0]:best=(dist,k,t)
 return best

def recipe(point,controls,force_hoof=None):
 nodes=controls['nodes'];piv=np.array([x['rest_world_pivot_m']for x in nodes]);x,y,z=point
 if force_hoof is not None:return {controls['limbs'][force_hoof]['joints'][-1]:1.},'hoof_'+force_hoof
 # Reconstructed tail territory, distinct from limb territories; review actual transitions.
 if z<-.83 and abs(x)<.255 and y<1.40:
  amount=smooth(.83,.99,-z);tip=1-smooth(.38,1.12,y)
  return {1:1-amount,4:amount*(1-tip),5:amount*tip},'tail_reconstructed'
 # Isolated surface sections below .76m provide four separate legs. Proximal extension
 # to1.04m is an explicit reconstructed blend, not hidden anatomical measurement.
 if y<1.04 and abs(x)>.04 and abs(z)>.10:
  label=('fore_'if z>0 else'hind_')+('l'if x>0 else'r');ids=controls['limbs'][label]['joints'];dist,k,t=closest(point,piv[ids])
  radius=.22 if y<.76 else .28
  if dist<radius:
   body=smooth(.76,1.04,y);return {ids[k]:(1-body)*(1-t),ids[k+1]:(1-body)*t,1:body},'limb_'+label
 # Source-authored control-volume assignment: head/neck territories are reconstructed.
 if z>.40 and y>1.0:
  neck=smooth(.40,.78,z)*smooth(1.0,1.24,y);head=smooth(.92,1.18,z)
  return {1:1-neck,2:neck*(1-head),3:neck*head},'neck_head_reconstructed'
 return {1:1.},'body'

def deformation_readback(c,canonical,arrays,bodyidx,sidecar,classes,members):
 piv=np.array([n['rest_world_pivot_m']for n in c['nodes']]);parents=[n['parent_index']for n in c['nodes']];ib=np.repeat(np.eye(4)[None],26,axis=0);ib[:,:3,3]=-piv
 def pose(rotations):
  world=[]
  for i in range(26):
   m=np.eye(4);m[:3,3]=piv[i]-(piv[parents[i]]if parents[i]is not None else 0)
   angle=rotations.get(i,0)*np.pi/180;co,si=np.cos(angle),np.sin(angle);m[:3,:3]=[[1,0,0],[0,co,-si],[0,si,co]];world.append((world[parents[i]]if parents[i]is not None else np.eye(4))@m)
  transforms=np.array(world)@ib;out=[]
  for points,(joints,weights)in zip(canonical,arrays):
   p=np.einsum('nwij,nj->nwi',transforms[joints],np.c_[points,np.ones(len(points))]);out.append(np.einsum('nw,nwi->ni',weights,p)[:,:3])
  return out,transforms
 rest,_=pose({});phases=[('front_left_elbow_flex8',{7:8},['fore_l']),('front_right_elbow_flex8',{12:8},['fore_r']),('rear_left_stifle_flex_minus8',{17:-8},['hind_l']),('rear_right_stifle_flex_minus8',{22:-8},['hind_r']),('independent_diagonal_control',{7:8,22:-8},['fore_l','hind_r'])];results=[]
 for name,rotations,active in phases:
  moved,transforms=pose(rotations);feet={}
  for label,entry in sidecar['contacts'].items():
   ids=np.unique(bodyidx[np.array(entry['source_triangle_ids'],dtype=int)].ravel());a,b=rest[1][ids],moved[1][ids];own=c['limbs'][label]['joints'][-1];expect=(transforms[own]@np.c_[canonical[1][ids],np.ones(len(ids))].T).T[:,:3]
   feet[label]={'active':label in active,'patch_vertices':len(ids),'maximum_patch_displacement_m':float(np.linalg.norm(b-a,axis=1).max()),'minimum_y_m':float(b[:,1].min()),'rigid_own_hoof_transform_max_error_m':float(np.abs(b-expect).max()),'pairwise_distance_max_error_m':float(np.abs(np.linalg.norm(b[:,None]-b[None,:],axis=2)-np.linalg.norm(a[:,None]-a[None,:],axis=2)).max())}
  # Exact seam source classes must still agree; this checks all material/UV duplicates.
  seam=0.
  for group in members.values():
   if len(group)>1:
    points=np.array([moved[mi][vi]for mi,vi in group]);seam=max(seam,float(np.linalg.norm(points-points[0],axis=1).max()))
  surfaces=[]
  for mi,(a,b)in enumerate(zip(rest,moved)):
   idx=D.acc(D.G['meshes'][mi]['primitives'][0]['indices']).astype(int).reshape((-1,3));ta,tb=a[idx],b[idx];na=np.cross(ta[:,1]-ta[:,0],ta[:,2]-ta[:,0]);nb=np.cross(tb[:,1]-tb[:,0],tb[:,2]-tb[:,0]);area=np.linalg.norm(na,axis=1);now=np.linalg.norm(nb,axis=1);valid=area>1e-12;dots=np.einsum('ni,ni->n',na,nb)
   ea=np.linalg.norm(ta[:,[1,2,0]]-ta[:,[0,1,2]],axis=2);eb=np.linalg.norm(tb[:,[1,2,0]]-tb[:,[0,1,2]],axis=2);edgevalid=ea>1e-8;ratios=eb[edgevalid]/ea[edgevalid]
   surfaces.append({'mesh':mi,'finite':bool(np.isfinite(b).all()),'triangle_normal_dot_negative_count':int(np.count_nonzero((dots<0)&valid)),'triangle_area_ratio_min':float((now[valid]/area[valid]).min()),'triangle_area_ratio_max':float((now[valid]/area[valid]).max()),'edge_ratio_min':float(ratios.min()),'edge_ratio_max':float(ratios.max())})
  results.append({'phase':name,'joint_rotation_x_deg':rotations,'feet':feet,'maximum_seam_class_gap_m':seam,'surfaces':surfaces})
 return {'scope':'Finite CPU draftskin controls only, not source animation or gait; no asset/bake/render. Canonical default ground, no yard support tilt. No proper triangle intersection screen or visual/anatomical approval.','phases':results}

def inspect(out):
 start=time.monotonic();assert hashlib.sha256(D.B).hexdigest()==ORIGINAL
 assert hashlib.sha256(CONTROL.read_bytes()).hexdigest()==CONTROL_SHA
 assert hashlib.sha256(CONTACT.read_bytes()).hexdigest()==CONTACT_SHA
 c=json.loads(CONTROL.read_text());s=json.loads(CONTACT.read_text());assert c['joint_count']==26 and c['original_host_source_sha256']==ORIGINAL
 origin=np.array(s['origin_native']);scale=s['uniform_metres_per_native_unit'];pieces=D.points({});canonical=[(p-origin)*scale for _,p in pieces]
 # Same-position classes apply one recipe across UV/material seams. No original indexing changes.
 classes={};members={};hoof={}
 for mi,p in enumerate(canonical):
  for vi,point in enumerate(p):
   key=tuple(np.rint(point/1e-6).astype(int));classes.setdefault(key,[]).append(point);members.setdefault(key,[]).append((mi,vi))
 body=D.G['meshes'][1]['primitives'][0];bodyidx=D.acc(body['indices']).astype(int).reshape((-1,3))
 for name,entry in s['contacts'].items():
  for vi in np.unique(bodyidx[np.array(entry['source_triangle_ids'],dtype=int)].ravel()):
   key=tuple(np.rint(canonical[1][vi]/1e-6).astype(int));hoof.setdefault(key,set()).add(name)
 # Reject ambiguous original hoof assignment rather than silently borrowing a different foot.
 assert all(len(v)==1 for v in hoof.values())
 assigned={};class_regions={};regions={};max_spread=0.
 for key,points in classes.items():
  a=np.asarray(points);max_spread=max(max_spread,float(np.linalg.norm(a-a[0],axis=1).max()));assert max_spread<=2e-6
  force=next(iter(hoof[key]))if key in hoof else None;weights,region=recipe(a.mean(0),c,force)
  weights={int(k):float(v)for k,v in weights.items()if v>1e-12};total=sum(weights.values());assert total>0 and len(weights)<=4
  weights={k:v/total for k,v in weights.items()};assert all(0<=k<26 and v>=0 for k,v in weights.items())
  assigned[key]=weights;class_regions[key]=region;regions[region]=regions.get(region,0)+len(members[key])
 # Eight explicit graph diffusion steps use only actual source triangle edges and exact
 # seam classes; no Euclidean nearest-surface connections across disconnected anatomy.
 keys=list(classes);keyid={k:i for i,k in enumerate(keys)};edges=set()
 for mi,points in enumerate(canonical):
  index=D.acc(D.G['meshes'][mi]['primitives'][0]['indices']).astype(int).reshape((-1,3))
  vertexclass=[keyid[tuple(np.rint(p/1e-6).astype(int))]for p in points]
  for tri in index:
   for a,b in [(0,1),(1,2),(2,0)]:
    u,v=vertexclass[tri[a]],vertexclass[tri[b]]
    if u==v:continue
    ra,rb=class_regions[keys[u]],class_regions[keys[v]]
    def leglabel(region):
     if region.startswith('hoof_'):return region[5:]
     if region.startswith('limb_'):return region[5:]
     return None
    la,lb=leglabel(ra),leglabel(rb)
    if la and lb and la!=lb:continue
    edges.add(tuple(sorted((u,v))))
 edges=np.array(sorted(edges),dtype=int);u,v=edges[:,0],edges[:,1];degree=np.bincount(np.r_[u,v],minlength=len(keys));dense=np.zeros((len(keys),26));allowed=np.ones_like(dense,dtype=bool)
 for i,key in enumerate(keys):
  for j,w in assigned[key].items():dense[i,j]=w
  region=class_regions[key];center=np.mean(classes[key],axis=0)
  if region.startswith('limb_')and center[1]<.76:
   allowed[i]=False;allowed[i,c['limbs'][region[5:]]['joints']]=True
  elif region=='tail_reconstructed':allowed[i]=False;allowed[i,[1,4,5]]=True
  elif region=='neck_head_reconstructed':allowed[i]=False;allowed[i,[1,2,3]]=True
 fixed=np.array([key in hoof for key in keys]);original=dense.copy()
 for iteration in range(8):
  sums=np.zeros_like(dense);np.add.at(sums,u,dense[v]);np.add.at(sums,v,dense[u]);mean=sums/np.maximum(1,degree[:,None]);candidate=.55*dense+.45*mean;candidate[degree==0]=dense[degree==0];candidate[~allowed]=0
  # Sparsity remains explicit, maximum4 influences. Equal-weight ties use stable jointorder.
  order=np.argsort(-candidate,axis=1,kind='stable');keep=np.zeros_like(allowed);np.put_along_axis(keep,order[:,:4],True,axis=1);candidate[~keep]=0;totals=candidate.sum(1);assert np.all(totals>0);candidate/=totals[:,None];candidate[fixed]=original[fixed];dense=candidate
 for i,key in enumerate(keys):assigned[key]={j:float(w)for j,w in enumerate(dense[i])if w>0}
 smoothing={'iterations':8,'neighbor_fraction':.45,'graph_edges':len(edges),'fixed_hoof_classes':int(np.count_nonzero(fixed)),'cross_limb_direct_edges_excluded':True,'distal_limb_weights_isolated_below_m':.76,'surface_graph_only':True,'maximum_influences':4,'no_actual_geometry_or_weight_stream_export':True}
 # Per-vertex draft arrays are inspected in memory only, not an asset/weight-stream export.
 arrays=[];counts=[];zero_rest_error=0.
 piv=np.array([x['rest_world_pivot_m']for x in c['nodes']]);jworld=np.repeat(np.eye(4)[None],26,axis=0);jworld[:,:3,3]=piv;inverse=np.linalg.inv(jworld)
 for mi,points in enumerate(canonical):
  joints=np.zeros((len(points),4),np.uint16);weights=np.zeros((len(points),4),np.float32)
  for vi,point in enumerate(points):
   key=tuple(np.rint(point/1e-6).astype(int));row=sorted(assigned[key].items(),key=lambda x:(-x[1],x[0]));
   for k,(joint,weight)in enumerate(row):joints[vi,k]=joint;weights[vi,k]=weight
  assert np.max(np.abs(weights.sum(1)-1))<2e-7
  transforms=jworld@inverse;rest=np.einsum('nwij,nj->nwi',transforms[joints],np.c_[points,np.ones(len(points))]);rest=np.einsum('nw,nwi->ni',weights,rest)[:,:3];zero_rest_error=max(zero_rest_error,float(np.abs(rest-points).max()))
  edge=D.acc(D.G['meshes'][mi]['primitives'][0]['indices']).astype(int).reshape((-1,3));l1=[]
  for triangle in edge:
   for a,b in [(0,1),(1,2),(2,0)]:
    wa=assigned[tuple(np.rint(points[triangle[a]]/1e-6).astype(int))];wb=assigned[tuple(np.rint(points[triangle[b]]/1e-6).astype(int))];l1.append(sum(abs(wa.get(k,0)-wb.get(k,0))for k in set(wa)|set(wb)))
  arrays.append((joints,weights));counts.append({'mesh':mi,'vertices':len(points),'weight_sum_max_error':float(np.abs(weights.sum(1)-1).max()),'influenced_vertices_per_joint':{c['nodes'][j]['name']:int(np.count_nonzero(np.any((joints==j)&(weights>0),axis=1)))for j in range(26)},'maximum_edge_weight_l1_jump':max(l1),'edge_weight_l1_over_1_count':int(np.count_nonzero(np.array(l1)>1))})
 out.mkdir(exist_ok=False)
 result={'status':'ACTUAL CPU SOURCE-RECIPE INSPECTION ONLY; no weight stream/geometry/skin/animation asset export','source_sha256':ORIGINAL,'control_sha256':CONTROL_SHA,'source_vertices':sum(len(p)for p in canonical),'joint_count':26,'maximum_influences':4,'regions_reconstructed':regions,'smoothing':smoothing,'seam_classes':len(classes),'classes_with_multiple_source_vertices':sum(len(v)>1 for v in members.values()),'class_spread_max_m':max_spread,'original_hoof_patch_vertex_counts':{name:len(np.unique(bodyidx[np.array(entry['source_triangle_ids'],dtype=int)].ravel()))for name,entry in s['contacts'].items()},'recipe_neutral_bind_position_max_error_m':zero_rest_error,'neutral_scope':'In-memory translation-basis inversebind and draftFloat32weights only; NOT actual GLB/GLTFLoader neutral proof','meshes':counts,'body_proximal_limit':'No isolated anatomical contours above.76m; shoulder/hip/stifle/neck/head controls and blend volumes remain reconstructed source proposal. No animated bend quality acceptance.','default_four_foot_gap_preserved_m':.005237669216761922,'walk':False,'weight_shift':False,'hitch':False,'riding':False,'elapsed_seconds':time.monotonic()-start,'source_unchanged':hashlib.sha256(D.F.read_bytes()).hexdigest()==ORIGINAL}
 result['deformation_controls']=deformation_readback(c,canonical,arrays,bodyidx,s,classes,members)
 (out/'SEGMENTATION-READBACK.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--inspect-only',required=True,action='store_true');p.add_argument('--output-dir',type=pathlib.Path,required=True);a=p.parse_args();assert a.output_dir.resolve().is_relative_to(ROOT);inspect(a.output_dir)
