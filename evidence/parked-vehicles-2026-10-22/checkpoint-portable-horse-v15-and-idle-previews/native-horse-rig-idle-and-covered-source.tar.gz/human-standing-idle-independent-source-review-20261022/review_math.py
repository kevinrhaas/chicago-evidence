import sys, pathlib,json,importlib.util,math,resource
resource.setrlimit(resource.RLIMIT_CPU,(8,8));sys.dont_write_bytecode=True
import numpy as np
P=pathlib.Path('/workspace/shared/human-standing-idle-proposal-20261022');A=pathlib.Path('/workspace/chicago/chicago/4d');O=pathlib.Path(__file__).parent
sys.path.insert(0,str(P/'proposed/tools'));sys.path.insert(0,str(A/'tools'))
import human_standing_idle as I
from human_grounded_gait import prepare_legs
r=json.loads((P/'proposed/data/humans/recipes/worker_1835.json').read_text());v=next(x for x in r['proof_variants']if x['id']=='bardwell_otis_1835');body=json.loads((A/v['body_input']).read_text());legs=prepare_legs({x['name']:x for x in body['skeleton']},r.get('height_scale',1))
sys.argv=[__file__,str(A/'assets/humans/web/bardwell_otis_1835.lod0.glb')]
s=importlib.util.spec_from_file_location('reader','/workspace/shared/human-standing-idle-native-readback-20261022/read_gltf.py');D=importlib.util.module_from_spec(s);s.loader.exec_module(D)
R=D.worlds({});names={n['name']:i for i,n in enumerate(D.G['nodes'])};C=np.array(((1.,0,0),(0,0,-1),(0,1,0)))
maxerr=0.;maxbasis=0.;maxrot=0.;minmargin=1.;maxlength=0.;kneeforward=1.
for t in np.linspace(0,1,241):
 p=I.pose_at_phase(legs,float(t));E=p['relative_source_rotation_matrices']
 for side,l in legs.items():
  th=np.array(E['thigh_'+side]);ca=th@np.array(E['calf_'+side]);foot=ca@np.array(E['foot_'+side]);
  hip=np.array(l['hip'])+p['pelvis_delta_m'];knee=hip+th@(np.array(l['knee'])-l['hip']);ankle=knee+ca@(np.array(l['ankle'])-l['knee']);maxerr=max(maxerr,float(np.linalg.norm(ankle-l['ankle'])));maxrot=max(maxrot,float(np.max(abs(foot-np.eye(3)))))
  minmargin=min(minmargin,sum(l['lengths'])-np.linalg.norm(np.array(l['ankle'])-hip));maxlength=max(maxlength,max(abs(a-b)for a,b in zip(p['legs'][side]['segment_lengths_m'],l['lengths'])));kneeforward=min(kneeforward,knee[2]-hip[2])
 for name,e in E.items():
  e=np.array(e);ni=names[name];bi=C@R[ni][:3,:3];bp=C@R[D.PARENT[ni]][:3,:3];eb=C@e@C.T;localpose=bi.T@eb@bi
  # Blender parent-relative rest rotation times local matrix_basis,
  # expressed back in GLTF/source coordinates.
  via_bpy=(bp.T@bi)@localpose;via_direct=R[D.PARENT[ni]][:3,:3].T@e@R[ni][:3,:3]
  maxbasis=max(maxbasis,float(np.max(abs(via_bpy-via_direct))))
  assert np.max(abs(e.T@e-np.eye(3)))<1e-12 and abs(np.linalg.det(e)-1)<1e-12
p0=I.pose_at_phase(legs,0);p1=I.pose_at_phase(legs,1);assert p0==p1
neg=[]
for label,value in [('nonfinite_phase',float('nan')),('nonfinite_phase_inf',float('inf'))]:
 try:I.pose_at_phase(legs,value);neg.append([label,False])
 except ValueError:neg.append([label,True])
try:I.validate_profile({**I.PROFILE,'pelvis_lateral_amplitude_m':.08});neg.append(['changed_profile',False])
except ValueError:neg.append(['changed_profile',True])
assert all(x[1]for x in neg)
assert maxerr<1e-12 and maxrot<1e-12 and maxbasis<1e-6 and minmargin>0
out={'verdict':'SOURCE_MATH_PASS_NOT_BLENDER_BUILD','phases':241,'ankle_target_max_error_m':maxerr,'foot_rotation_max_error':maxrot,'basis_formula_max_error':maxbasis,'minimum_reach_slack_m':float(minmargin),'segment_length_max_error_m':maxlength,'minimum_knee_forward_of_hip_m':float(kneeforward),'loop_exact':p0==p1,'negative_controls':neg,'limitation':'Uses actual exported orthonormal rest frames to verify coordinate algebra. Does not execute BPy, exporter, new mesh skinning or interpolation.'}
(O/'MATH-RESULT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
