One root-authorized V3 normalization completed EXIT0. Structural and unlimited Khronos checks pass (0 errors, 0 warnings, 97 informational issues). 95 UNUSED_OBJECT infos correspond to retained original data now superseded by packed/copied views; two empty nodes are retained. Full report is untruncated. Original and failed first idle exports remain unchanged.

This derivative contains no appended idle. Promoted mesh nodes have identity root transforms; skeleton/IBMs remain unchanged. The changed mesh basis has NOT passed actual GLTFLoader/Mixer full indexed POSITION/NORMAL parity at default or old-clip phases. No app integration or playback is approved by this receipt.

Frozen independent source review and exact execution helpers: /workspace/shared/T2803-PORTABLE-NORMALIZER-INDEPENDENT-REVIEW-20261022. All writes here are outside app; no browser ran.
