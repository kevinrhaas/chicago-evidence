# T2980: ready narrow visible sag refinement, not reproducibility repair

Concrete next deliverable: install the already produced stronger reconstructed canvas drape on exactly Western Hotel blue/oxide and Wolf Point oak/darkoak yard_1 wagons, with original IDs/stands/bearings/seeds/aging/yokes and running gear. This is a small visible cloth-form increment. It does not complete photographic, LOD or occupied acceptance.

Current intake audit: app core is still1a36e350 and products9b6575/c6f698, exactly the proposal's original before files. The accepted reproducibility/source-chart repair is already in DEV; it is not current claim work. Candidate source679fc439 and actual aaffa339/22072e6f products are present, frozen and not integrated. No additional generator work is needed to make the initial change reviewable.

Prepared six exact files in proposed/:

- tools/transport/wagon_covered/build.py: one sag formula changes8–10mm to20–28mm; one honest exported fold-description line.
- assets/authored/transport/wagon_covered/SOURCE.json: core source hash and both actual product/sidecar pairs updated, every old identity/finish/terrain/ownership field retained.
- two covered-w01.json files: only actual source hash, GLB hash and byte length change.
- two actual covered-w01.glb files: original produced bytes, not regenerated or edited.

Four text changes are in PROPOSED-FOUR-TEXT-FILES.patch SHA93d5318e439f829366742179597e5eb7e01d83366e46735dce3f4a9751f41d57; binary sources are supplied at final relative paths. INTAKE.json records exact old/new hashes and unchanged recipe/placements/wrapper/checker. Text/source products preserve every original production wrapper guard: expected new source/product hashes change explicitly, with no exception or fallback. Source_commit inside retained SOURCE is historical initial integration lineage, not the future sag commit; root should label/append actual refinement lineage and correct its initial no-main-comparisons limitation when writing integrated status. No new attested maker/source/license is introduced: geometryGPL, unchanged analytic pixelsCC0.

Actual structural proof: /workspace/shared/covered-cloth-drape-proposal-2026-10-22/ACTUAL-RESULT-v1.md, owner/receipts/readback and both originals preserved there. One generation PASS/CLOSED22.424s; each candidate17292triangles/nine material groups/2970448bytes, same P/N/UV/material ownership outside owned cloth streams;101protected attributes and1883588-byte original parent prefix exact. Four narrowphase controls and4032cloth/hem vs1920bow triangles pass, no intersections. This is not all-component/self-intersection or occupied clearance proof.

Actual mobile evidence: /workspace/shared/covered-cloth-mobile-6PLUS2-proof-20261022/README.md and VERIFIED-SUMMARY.json. Original525.553s execution stays FAIL with6PNGs; remaining-pair298.837s execution PASS means only its2PNGs and cleanup. Root viewed Western side and WolfPoint quarter, found sag subtle/coherent; no final photo ruling. /workspace/shared/covered-cloth-mobile-6PLUS2-independent-review-20261022/REVIEW.md records Bardwell appearing only in candidate and foliage changing. Wagon/camera identity is matched; whole population, per-pixel lighting/shadows and wagon-only cost are not isolated. Desktop8 is unexecuted; old held configs pin ad813 and cannot be launched unchanged against new DEV. No fresh browser run is prepared here.

Suggested root-owned next sequence, after current PR1175 merge work:

1. Review/apply these six exact files as a new bounded visible T2980 increment, append truthful source/status/changelog/license lineage. No coordinates, renderer, common lighting, finish, thresholds or old evidence rewrites.
2. Run existing production covered wrapper --verify and existing covered/parked tests on the integrated candidate, full required preflight and current-head CI/publish/mirror plus relevant published smoke. The wrapper regenerates from original source chain rather than accepting cached parents, retaining the original source/parts/recipe guards.
3. Before additional normal-main comparison, explicitly choose the remaining scope. Desktop side/quarter for both finishes remains required by the saved16-image plan; current-scene async population must be qualified for an honest A/B or comparisons must state local-wagon appearance only. No automatic rerun is assumed. Retain current mobile evidence and its caveat.
4. Keep T2980 open for photographic/material/cloth-construction/LOD acceptance. Distinct compressed mid/far, sameframe resource accounting, all original source/published close/distant coverage and reference match still need final ruling; no fleet expansion or parent closure.

Suggested replacement claim/workplan wording: 'T2980: ready six-file stronger canvas-drape intake for the same two individual wagons; actual structural generation PASS and mobile6FAIL+2continuationPASS preserved; current intake/preflight/CI and remaining desktop appearance qualification next. Reproducibility repair already landed; full photographic/LOD scope open.' If root defers this refinement, release the active claim with this exact candidate artifact and next step rather than retaining the stale CI-repair claim.

No app/ticket/Git/index/mirror changes, generator/browser/gate or model rewrite occurred. This packet copies only original frozen candidate bytes into reviewable intake paths; no installation or promotion is implied.
