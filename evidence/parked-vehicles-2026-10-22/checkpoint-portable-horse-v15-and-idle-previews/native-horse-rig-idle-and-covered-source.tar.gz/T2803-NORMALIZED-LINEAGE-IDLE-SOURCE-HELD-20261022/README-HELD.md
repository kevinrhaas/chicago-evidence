Normalized-lineage idle SOURCE ONLY; no append executed, future output and actual receipt hashes remain null.

The producer accepts only the exact ceefa279 normalized GLB, its actual normalization receipt, and unchanged a759bf11 curve bundle derived from original41acd. It requires the actual peer 199-pose parity PASS receipt and explicit receipt SHA before any output. Existing normalized BIN/views/accessors/six animations/nodes/skins/materials/maps are retained exactly; three appended views/accessors plus the same node17/node19 CUBICSPLINE clip are the only append edits. Relative to original41acd, prior normalization exceptions are expressly recorded (packed animation references, 15,897 exact-zero-weight JOINTS entries, three identity-root skinned meshes).

Runtime guard changes only lineage checks, requiring the actual new append receipt and independently byte-verified exported SHA. Source original identity, actual names and loader raw names, exact two leaves/rest quaternions, three shared fifteen-bone skins, four nonempty bounded hoof patches, no hoof weights on idle leaves, rest-state ownership, host delta/visibility/reduced-motion/pause, single Mixer and disposal guards remain. No future hash or actual export acceptance is asserted.

AFTER actual peer parity PASS and a separate root release, one append command is:

`PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 timeout --signal=TERM --kill-after=1s 15s nice -n 15 python3 -B /workspace/shared/T2803-NORMALIZED-LINEAGE-IDLE-SOURCE-HELD-20261022/append_normalized_idle_glb.py --lane-released --parity-receipt /workspace/shared/T2803-PORTABLE-NORMALIZER-V3-MIXER-PARITY-ACTUAL-20261022/ACTUAL-LOADED-PARITY.json --parity-sha256 ACTUAL_RECEIPT_SHA --output-dir FRESH_OUTSIDE_APP_DIR`

The actual APPEND-RECEIPT.json must be hashed and bound by the final host integration after export; runtime verifiedDerivedSha256 must come from the actual exported bytes. No idle playback approval follows from the prior normalization parity. Original producerb23c1c73, originalfailed V1 append and runtime17f438d0 are unchanged. Python syntax checks only; no producer/Mixer/browser/build execution in this preparation.
