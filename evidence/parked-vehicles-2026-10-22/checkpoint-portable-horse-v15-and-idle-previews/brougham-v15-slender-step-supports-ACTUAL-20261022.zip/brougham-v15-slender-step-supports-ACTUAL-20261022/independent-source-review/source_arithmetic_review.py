from pathlib import Path
import ast,collections,hashlib,json,math,struct,time
P=Path('/workspace/shared/brougham-v15-slender-step-supports-SOURCE-PROPOSAL-20261022');D=Path('/workspace/shared/brougham-v15-slender-step-supports-INDEPENDENT-REVIEW-20261022');D.mkdir();H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic();base=(P/'baseline/generate.py').read_text();new=(P/'proposed/generate.py').read_text();begin=new.index('        # V15 source proposal:');end=new.index('\n\n    # Front and rear cabin',begin);oldline="        for z in [-.20,.07]:beam('step_support',body,(side*.45,.65,z),(side*.72,.35,z),.022,4)";assert new[:begin]+oldline+new[end:]==base
for f in (P/'baseline').iterdir():
 if f.is_file() and f.name!='generate.py':assert f.read_bytes()==(P/'proposed'/f.name).read_bytes()
bind=json.loads((P/'BASELINE-AND-PIXEL-INPUTS.json').read_bytes());assert H(P/'baseline/generate.py')==bind['baseline_generator_sha256'] and H(P/'proposed/generate.py')==bind['proposed_generator_sha256'] and H(P/'PROSPECTIVE-V15-FOUR-SUPPORTS-ONLY.patch')==bind['patch_sha256']
for r in bind['inputs']:assert Path(r['path']).stat().st_size==r['bytes'] and H(Path(r['path']))==r['sha256']
# Independent scalar Hermite evaluation of the literal source controls, no producer execution.
main=next(n for n in ast.parse(new).body if isinstance(n,ast.FunctionDef) and n.name=='main');calls=[n for n in ast.walk(main) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='catmull' and isinstance(n.args[0],ast.List) and len(n.args[0].elts)==7];assert len(calls)==1
q=ast.literal_eval(calls[0].args[0]);steps=ast.literal_eval(calls[0].args[1]);assert steps==3
curve=[]
for i in range(len(q)-1):
 p0=q[max(0,i-1)];p1=q[i];p2=q[i+1];p3=q[min(len(q)-1,i+2)]
 for k in range(steps):
  t=k/steps;h00=2*t**3-3*t*t+1;h10=t**3-2*t*t+t;h01=-2*t**3+3*t*t;h11=t**3-t*t
  curve.append([h00*p1[j]+h10*(p2[j]-p0[j])/2+h01*p2[j]+h11*(p3[j]-p1[j])/2 for j in range(2)])
curve.append(q[-1]);assert len(curve)==19
sub=lambda a,b:[x-y for x,y in zip(a,b)];dot=lambda a,b:math.fsum(x*y for x,y in zip(a,b));cross=lambda a,b:[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];norm=lambda a:math.sqrt(dot(a,a));scale=1.13;offset=.03;bars=[];allbar=[]
for side in [-1,1]:
 for order,z in enumerate([-.20,.07]):
  v=[];producer=[]
  for i,c in enumerate(curve):
   tangent=sub(curve[min(i+1,18)],curve[max(i-1,0)]);ln=norm(tangent);assert ln>0;ux,uy=[x/ln for x in tangent];qv=[uy*.004,-side*ux*.004,0];worldt=[side*ux,uy,0];assert abs(dot(worldt,qv))<1e-17
   for aa,bb in [(-1,-1),(1,-1),(1,1),(-1,1)]:
    w=[side*c[0]+bb*qv[0],c[1]+bb*qv[1],z+aa*.008];producer.append(w);v.append([w[0],w[1]*scale+offset,w[2]])
  faces=[[3,2,1,0],list(range(72,76))]+[[4*i+j,4*i+(j+1)%4,4*(i+1)+(j+1)%4,4*(i+1)+j] for i in range(18) for j in range(4)]
  triangles=[[f[0],f[k],f[k+1]] for f in faces for k in range(1,len(f)-1)];assert len(v)==76 and len(triangles)==148;edges=collections.defaultdict(list);areas=[];vols=[]
  for f in triangles:
   a,b,c=[v[k] for k in f];areas.append(norm(cross(sub(b,a),sub(c,a)))/2);vols.append(dot(a,cross(b,c))/6)
   for x,y in zip(f,f[1:]+f[:1]):edges[tuple(sorted((x,y)))].append((x,y))
  assert len(edges)==222 and all(len(e)==2 and e[0]==tuple(reversed(e[1])) for e in edges.values());volume=math.fsum(vols);assert volume>0 and min(areas)>1e-10
  adjacency=collections.defaultdict(set)
  for a,b in edges:adjacency[a].add(b);adjacency[b].add(a)
  seen={0};todo=[0]
  while todo:
   for k in adjacency[todo.pop()]-seen:seen.add(k);todo.append(k)
  assert len(seen)==76
  for cap,center in [(producer[:4],[side*.45,.65,z]),(producer[-4:],[side*.72,.35,z])]:assert all(abs(math.fsum(p[j] for p in cap)/4-center[j])<1e-15 for j in range(3))
  cap=producer[-4:];assert all(.34<p[1]<.36 and ((p[0]-side*.72)/.14)**2+((p[2]-z)/.065)**2<math.cos(math.pi/12)**2 for p in cap)
  # Independent planar-ribbon nonadjacent segment intersection check.
  poly=[p[:2] for p in producer[::4]]+[p[:2] for p in producer[2::4]][::-1];hits=[]
  c2=lambda a,b:a[0]*b[1]-a[1]*b[0]
  for i in range(len(poly)):
   a,b=poly[i],poly[(i+1)%len(poly)];u=sub(b,a)
   for j in range(i+1,len(poly)):
    if j==i+1 or(i==0 and j==len(poly)-1):continue
    c,d=poly[j],poly[(j+1)%len(poly)];w=sub(d,c);den=c2(u,w)
    if abs(den)<1e-16:continue
    t=c2(sub(c,a),w)/den;s=c2(sub(c,a),u)/den
    if 1e-8<t<1-1e-8 and 1e-8<s<1-1e-8:hits.append((i,j))
  assert not hits
  bars.append({'part_index':13+order if side<0 else 28+order,'vertices':76,'triangles':148,'edges':222,'Euler':2,'components':1,'closed_opposite_directed_edges':True,'positive_volume_m3':volume,'minimum_triangle_area_m2':min(areas),'minimum_lower_cap_pad_Y_inset_root_m':min(min(p[1]-.34,.36-p[1])*scale for p in cap),'source_endpoint_centers_exact':True,'stroke_crossings':hits});allbar.extend(v)
# Read the frozen actual V14GLB as inert bytes; no generator/import/export/model creation.
raw=Path(bind['inputs'][0]['path']).read_bytes();magic,version,total=struct.unpack_from('<4sII',raw,0);assert magic==b'glTF' and version==2 and total==len(raw);nj,typ=struct.unpack_from('<I4s',raw,12);assert typ==b'JSON';doc=json.loads(raw[20:20+nj]);nb,typ=struct.unpack_from('<I4s',raw,20+nj);assert typ==b'BIN\x00';blob=raw[28+nj:28+nj+nb];parts=doc['extras']['parts'];assert len(parts)==466 and doc['extras']['statistics']['triangles']==32830
for i in [13,14,28,29]:assert parts[i]['name']=='step_support' and parts[i]['triangles']==12 and parts[i]['material']==4 and parts[i]['frame']=='vehicle_body'
for i in [12,27]:assert parts[i]['name']=='door_step' and parts[i]['triangles']==88
world={}
def visit(i,parent):
 n=doc['nodes'][i];assert not any(k in n for k in ['matrix','rotation','scale']);world[i]=[parent[k]+n.get('translation',[0,0,0])[k] for k in range(3)]
 for child in n.get('children',[]):visit(child,world[i])
for i in doc['scenes'][doc.get('scene',0)]['nodes']:visit(i,[0,0,0])
bounds=[[math.inf]*3,[-math.inf]*3];keep=[[math.inf]*3,[-math.inf]*3]
for ni,node in enumerate(doc['nodes']):
 if 'mesh' not in node:continue
 mesh=doc['meshes'][node['mesh']]
 for prim in mesh['primitives']:
  acc=doc['accessors'][prim['attributes']['POSITION']];view=doc['bufferViews'][acc['bufferView']];assert acc['type']=='VEC3' and acc['componentType']==5126;off=view.get('byteOffset',0)+acc.get('byteOffset',0);stride=view.get('byteStride',12)
  spans=[(3*parts[i]['triangle_start_in_batch'],3*(parts[i]['triangle_start_in_batch']+parts[i]['triangles'])) for i in [13,14,28,29]] if mesh['name']=='surface_vehicle_body_4' else []
  for k in range(acc['count']):
   p=[x+y for x,y in zip(struct.unpack_from('<fff',blob,off+k*stride),world[ni])];owned=any(a<=k<b for a,b in spans)
   for j in range(3):
    bounds[0][j]=min(bounds[0][j],p[j]);bounds[1][j]=max(bounds[1][j],p[j])
    if not owned:keep[0][j]=min(keep[0][j],p[j]);keep[1][j]=max(keep[1][j],p[j])
assert bounds==keep and all(bounds[0][j]<min(p[j] for p in allbar)<=max(p[j] for p in allbar)<bounds[1][j] for j in range(3))
report={'status':'INDEPENDENT_SOURCE_ARITHMETIC_CLEAR_NO_GENERATION','baseline_generator_sha256':H(P/'baseline/generate.py'),'proposed_generator_sha256':H(P/'proposed/generate.py'),'patch_sha256':H(P/'PROSPECTIVE-V15-FOUR-SUPPORTS-ONLY.patch'),'exactly_one_source_block_changed':True,'all_other_supporting_source_files_byte_exact':True,'other_part_PN_preserved_by_unchanged_source':462,'footplate_parts12_27_actual_triangles_each':88,'predicted_whole_part_count':466,'predicted_whole_triangles':32830+4*(148-12),'predicted_triangle_delta':544,'actual_V14_global_bounds_root':bounds,'actual_unowned_geometry_keeps_all_six_extrema':True,'source_material_and_node_anchor_construction_unchanged':True,'bars':bars,'elapsed_seconds':time.monotonic()-start,'source_generator_or_full_model_executed':False,'new_GLB_or_render_or_app_Git_claim_writes':False,'limits':'Source arithmetic only; exact emittedPN/metadata/materials/13anchors/globalbounds need actualgeneration verification. Body emergence/occlusion/contact and period/photo appearance need actual matched views; endpoint centers are not welded/structural join proof.'}
(D/'INDEPENDENT-SOURCE-ARITHMETIC.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','predicted_whole_part_count','predicted_whole_triangles','predicted_triangle_delta','elapsed_seconds']},indent=2))
