from pathlib import Path
from collections import Counter
import hashlib,json,math,struct,traceback
R=Path(__file__).resolve().parent;S=Path('/workspace/shared/brougham-v14-footplates-ACTUAL-20261022');REPORT=R/'OWNERSHIP.json'
def need(c,m):
 if not c:raise ValueError(m)
def read(p):
 raw=p.read_bytes();need(raw[:4]==b'glTF','GLBheader');n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);return raw,g,raw[28+n:]
def stream(g,b,mi,kind):
 a=g['accessors'][g['meshes'][mi]['primitives'][0]['attributes'][kind]];v=g['bufferViews'][a['bufferView']];need(a['componentType']==5126 and a['type']=='VEC3' and 'byteStride' not in v,'Float3');off=v.get('byteOffset',0)+a.get('byteOffset',0);return b[off:off+a['count']*12]
def component(g,b,p,kind):
 name=f"surface_{p['frame']}_{p['material']}";ids=[i for i,m in enumerate(g['meshes']) if m['name']==name];need(ids,'Ownerbatch')
 # Repeated hubcap local ranges are additionally protected mesh-by-mesh below.
 mi=ids[0];start=p['triangle_start_in_batch']*36;raw=stream(g,b,mi,kind)[start:start+p['triangles']*36];need(len(raw)==p['triangles']*36,'Part range');return raw
def pts(raw):return list(struct.iter_unpack('<fff',raw))
def bounds(g,b):
 tr={}
 def visit(i,t):
  n=g['nodes'][i];need(not any(k in n for k in ['matrix','rotation','scale']),'Translation-only reviewed nodes');tr[i]=[t[k]+n.get('translation',[0,0,0])[k] for k in range(3)]
  for c in n.get('children',[]):visit(c,tr[i])
 for n in g['scenes'][g.get('scene',0)]['nodes']:visit(n,[0,0,0])
 lo=[math.inf]*3;hi=[-math.inf]*3
 for i,n in enumerate(g['nodes']):
  if 'mesh' not in n:continue
  for p in pts(stream(g,b,n['mesh'],'POSITION')):
   for k in range(3):v=p[k]+tr[i][k];lo[k]=min(lo[k],v);hi[k]=max(hi[k],v)
 return {'min':lo,'max':hi}
def main():
 r={'pass':False,'scope':'Actual four-support raw ownership/closedness/normals/envelope only; no appearance/occupied or exhaustive intersection acceptance'}
 try:
  ar,a,ab=read(S/'raw/brougham.glb');cr,c,cb=read(R/'raw/brougham.glb');need(hashlib.sha256(ar).hexdigest()=='ed15f00934809cf04f7946377c18a6d3c2c0a5501041ebcd5ff257b96a1d8f8e','FrozenV14');r['actual_sha256']=hashlib.sha256(cr).hexdigest();r['actual_bytes']=len(cr)
  for key in ['nodes','materials','scenes','scene','extensionsUsed']:need(a.get(key)==c.get(key),'Protected metadata '+key)
  need(a['extras']['parameters']==c['extras']['parameters'],'All exactV14 recipe/source metadata')
  pa,pc=a['extras']['parts'],c['extras']['parts'];need(len(pa)==len(pc)==466,'466parts');need(len(a['meshes'])==len(c['meshes'])==24,'24meshes')
  protected=0;changed=[];protected_mesh_streams=0
  for i,(ma,mc) in enumerate(zip(a['meshes'],c['meshes'])):
   need(ma==mc,'Batch layout/material/accessor identity')
   if ma['name'] not in ['surface_vehicle_body_4']:
    for kind in ['POSITION','NORMAL']:need(stream(a,ab,i,kind)==stream(c,cb,i,kind),'Protected mesh stream '+str(i));protected_mesh_streams+=1
  for i,(old,new) in enumerate(zip(pa,pc)):
   need(all(old[k]==new[k] for k in ['name','frame','material']),'Part identity/order '+str(i))
   if i not in [13,14,28,29]:
    need(old['triangles']==new['triangles'],'Unowned cost '+str(i))
    for kind in ['POSITION','NORMAL']:need(component(a,ab,old,kind)==component(c,cb,new,kind),'Unowned PN '+str(i)+'/'+kind)
    protected+=1;continue
   need(new['triangles']==148,'Owned trianglecount');p=pts(component(c,cb,new,'POSITION'));ns=pts(component(c,cb,new,'NORMAL'));need(all(math.isfinite(x) for q in p+ns for x in q),'Finite owned streams');need(all(abs(math.sqrt(math.fsum(x*x for x in n))-1)<1e-5 for n in ns),'Unit normals');edges=Counter();directed=Counter();volume=0.
   for k in range(0,len(p),3):
    q=p[k:k+3];u=[q[1][j]-q[0][j] for j in range(3)];v=[q[2][j]-q[0][j] for j in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];length=math.sqrt(math.fsum(x*x for x in cross));need(length>1e-10,'Nondegenerate triangles');need(all(math.fsum(cross[j]*ns[k+t][j] for j in range(3))/length>.9999 for t in range(3)),'Geometric normals/winding')
    det=[q[1][1]*q[2][2]-q[1][2]*q[2][1],q[1][2]*q[2][0]-q[1][0]*q[2][2],q[1][0]*q[2][1]-q[1][1]*q[2][0]];volume+=math.fsum(q[0][j]*det[j] for j in range(3))/6
    for x,y in [(0,1),(1,2),(2,0)]:edges[tuple(sorted((q[x],q[y])))]+=1;directed[(q[x],q[y])]+=1
   need(all(n==2 for n in edges.values()) and all(n==1 and directed[(y,x)]==1 for (x,y),n in directed.items()) and volume>0,'Closed opposite-edge positive volume '+str(i));need(len(set(p))==76 and len(edges)==222 and len(p)//3==148,'Actual support topology counts');need(component(a,ab,old,'POSITION')!=component(c,cb,new,'POSITION'),'Actual owned position change')
   changed.append({'part_index':i,'name':new['name'],'triangles':new['triangles'],'signed_volume_m3':volume,'closed_finite_normals_winding':'PASS'})
  need(protected==462 and len(changed)==4,'Exactly4owned/462protected');b0,b1=bounds(a,ab),bounds(c,cb);need(b0==b1,'Exact full world bounds');need(c['extras']['statistics']=={'triangles':33374,'meshes':24,'nodes':41},'Actual33374tri')
  supports=[]
  for pi in [13,14,28,29]:
   support=pc[pi];points=pts(component(c,cb,support,'POSITION'));cap=sorted(set(points[6:12]));need(len(cap)==4,'Actual four support endcap corners')
   sign=1 if cap[0][0]>0 else -1;zc=math.fsum(q[2] for q in cap)/4;pad=pts(component(c,cb,pc[27 if sign>0 else 12],'POSITION'));ylo=min(q[1] for q in pad);yhi=max(q[1] for q in pad)
   need(all(ylo<q[1]<yhi and ((q[0]-sign*.72)/.14)**2+((q[2]-zc)/.065)**2<math.cos(math.pi/12)**2 for q in cap),'Actual support-to-pad containment')
   supports.append({'part_index':pi,'actual_endcap_corners_inside_pad':True,'minimum_Y_inset_m':min(min(q[1]-ylo,yhi-q[1]) for q in cap)})
  need(all(pc[i]['name']=='door_step' and pc[i]['triangles']==88 for i in [12,27]),'V14 footplate identity/count preserved');r.update(pass_status='PASS',protected_part_PN_exact=protected,protected_full_mesh_streams_exact=protected_mesh_streams,owned=changed,nodes_materials_scenes_anchors_exact=True,parameters_source_metadata_exact=True,global_bounds_exact=b1,statistics=c['extras']['statistics'],actual_support_to_pad= supports);r['pass']=True
 except BaseException as e:r['error']=repr(e);r['traceback']=traceback.format_exc();raise
 finally:REPORT.write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps(r))
if __name__=='__main__':main()
