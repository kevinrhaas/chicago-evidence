from pathlib import Path
import math,ast,json,collections,sys,struct
R=Path(__file__).parent;s=(R/'proposed/generate.py').read_text();base=(R/'baseline/generate.py').read_text()
new=s[s.index('        # Prospective source-footplate'):s.index('        for z in [-.20,.07]:beam')];old=base[base.index('        # Original step under the door'):base.index('        for z in [-.20,.07]:beam')]
assert s.replace(new,'OWNED_STEP_BLOCK\n')==base.replace(old,'OWNED_STEP_BLOCK\n')
rows=[]
for side in [-1,1]:
 out={}
 def geometry(name,parent,vertices,faces,mat):out.update(name=name,vertices=vertices,faces=faces,material=mat)
 exec('\n'.join(line[8:] for line in new.splitlines()),{'math':math,'side':side,'body':1,'geometry':geometry})
 P=[[x,y*1.13+.03,z] for x,y,z in out['vertices']];F=[ [f[0],f[k],f[k+1]] for f in out['faces'] for k in range(1,len(f)-1)]
 E=collections.defaultdict(list);volume=0;minarea=math.inf
 for a,b,c in F:
  p,q,r=P[a],P[b],P[c];u=[q[k]-p[k] for k in range(3)];v=[r[k]-p[k] for k in range(3)];n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];minarea=min(minarea,math.hypot(*n)/2);volume+=math.fsum(p[k]*[q[1]*r[2]-q[2]*r[1],q[2]*r[0]-q[0]*r[2],q[0]*r[1]-q[1]*r[0]][k] for k in range(3))/6
  for i,j in [(a,b),(b,c),(c,a)]:E[tuple(sorted((i,j)))].append((i,j))
 assert all(len(v)==2 and v[0]==tuple(reversed(v[1])) for v in E.values()) and volume>0 and minarea>0
 # Actual retained22mm support endpoint section, from unchanged beam construction.
 # u=(side*.27,-.30,0)/length; endcap q gives X/Y offsets, v gives Z.
 L=math.hypot(.27,.30);qx=-.30/L*.011;qy=-side*.27/L*.011
 caps=[[side*.72+sx*qx,.35+sx*qy,z+sz*.011] for z in [-.20,.07] for sx in [-1,1] for sz in [-1,1]]
 capchecks=[.34<p[1]<.36 and ((p[0]-side*.72)/.14)**2+((p[2]-z)/.065)**2<math.cos(math.pi/12)**2 for z in [-.20,.07] for p in caps if abs(p[2]-z)<.02]
 assert all(capchecks)
 rows.append({'side':side,'source_part_index':12 if side<0 else 27,'vertices':len(P),'triangles':len(F),'closed_oriented_two_components':True,'euler_characteristic':len(P)-len(E)+len(F),'positive_volume_m3':volume,'minimum_triangle_area_m2':minarea,'bounds_root_m':{'min':[min(p[k] for p in P) for k in range(3)],'max':[max(p[k] for p in P) for k in range(3)]},'support_endcap_corners_inside_authored_tread_ellipse_and_slab':all(capchecks)})
sys.path.insert(0,str(R/'baseline'))
from index_streams import read_glb,attribute_rows
doc,binary=read_glb(Path('/workspace/shared/brougham-v13-two-joins-ACTUAL-20261022/raw/brougham.glb'))
parents={child:i for i,n in enumerate(doc['nodes']) for child in n.get('children',[])}
body_id=next(i for i,n in enumerate(doc['nodes']) if n['name']=='vehicle_body')
stream=next([struct.unpack('<fff',raw) for raw in attribute_rows(doc,binary,p['attributes']['POSITION'])]
            for i,n in enumerate(doc['nodes']) if n.get('mesh') is not None and parents[i]==body_id
            for p in doc['meshes'][n['mesh']]['primitives'] if p['material']==4)
actual_caps=[]
for pi in [13,14,28,29]:
 part=doc['extras']['parts'][pi];assert part['name']=='step_support'
 pts=stream[3*part['triangle_start_in_batch']:3*(part['triangle_start_in_batch']+part['triangles'])]
 caps=sorted(set(p for p in pts if abs(p[0])>.70));assert len(caps)==4
 sign=1 if caps[0][0]>0 else -1;zc=sum(p[2] for p in caps)/4
 assert all(.4142<p[1]<.4368 and ((p[0]-sign*.72)/.14)**2+((p[2]-zc)/.065)**2<math.cos(math.pi/12)**2 for p in caps)
 actual_caps.append({'part_index':pi,'four_actual_root_cap_corners_m':caps,'all_inside_proposed_polygon_and_slab':True,'maximum_above_old_tread_top_m':max(p[1] for p in caps)-.4294550120830536,'minimum_new_slab_Y_inset_m':min(min(p[1]-.4142,.4368-p[1]) for p in caps)})
report={'status':'ISOLATED_FOOTPLATE_SOURCE_MATH_ONLY_NOT_FULL_MODEL_GENERATION','only_two_owned_step_blocks_change':True,'expected_other_protected_part_PN_streams':464,'expected_model_parts':466,'expected_triangles':32678+2*(88-12),'new_part_triangles_each':88,'triangle_delta':152,'actual_original_support_endcap_readback':actual_caps,'original_supports_unchanged':True,'original_materials_nodes_anchors_unchanged_by_source':True,'top_height_delta_root_m':(.36-.3535)*1.13,'outer_X_extents_preserved':True,'step_Z_old_interval_m':[-.275,.115],'step_Z_proposed_union_bounds_m':[-.265,.135],'separated_tread_gap_along_Z_m':.14,'rows':rows,'limits':['Analytical geometry of the two proposed parts only; full raw PN/protected-range/bounds/Khronos/readback/render must follow separately released generation','Tread shape count has source support; hidden/opposite side, physical metres and20mm iron depth reconstructed','Straight support beams remain untouched and do not become source-matched by this tread proposal']}
(R/'FOOTPLATE-SOURCE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
