from pathlib import Path
import sys,json,hashlib,importlib.util,copy,struct,time
R=Path(__file__).parent;tool=R/'baseline';sys.path[:0]=[str(R/'proposed'),str(tool)]
from static_master import static_master_contract
from index_streams import read_glb
spec=importlib.util.spec_from_file_location('baseline_wrapper',R/'baseline/build_portable.py');wrapper=importlib.util.module_from_spec(spec);spec.loader.exec_module(wrapper)
raw=Path('/workspace/shared/brougham-v13-two-joins-ACTUAL-20261022/raw/brougham.glb');sha=hashlib.sha256(raw.read_bytes()).hexdigest();assert sha==wrapper.MASTER
start=time.monotonic();doc,binary=read_glb(raw);world,bounds=wrapper.inspect(doc,binary);out=static_master_contract(doc,binary,world,sha)
assert all(abs(sum(v*v for v in a['rotation_xyzw'])-1)<1e-12 for a in out['named_targets'])
assert len(out['named_targets'])==8 and len(out['seats'])==3 and len(out['entries'])==2
assert all(not v for v in out['capabilities'].values()) and not out['hitch']['hitch_ready_pose_available']
assert all(r['step_top_to_floor_top_m']>0 and not r['entry_aperture_available'] for r in out['entries'])
assert out['hitch']['parked_translation_root_m']==[0.,.037,3.8]
checks=[]
for label in ['missing_step','missing_hitch','out_of_range_part','nonfinite_vertex']:
 d=copy.deepcopy(doc);b=bytearray(binary)
 if label=='missing_step':d['extras']['parts']=[p for p in d['extras']['parts'] if p['name']!='door_step']
 elif label=='missing_hitch':next(n for n in d['nodes'] if n['name']=='vehicle_hitch_team')['name']='unsupported_hitch_removed'
 elif label=='out_of_range_part':d['extras']['parts'][12]['triangles']=10000000
 else:
  a=d['accessors'][d['meshes'][0]['primitives'][0]['attributes']['POSITION']];v=d['bufferViews'][a['bufferView']];struct.pack_into('<f',b,v.get('byteOffset',0)+a.get('byteOffset',0),float('nan'))
 try:static_master_contract(d,b,world,sha)
 except (ValueError,KeyError,StopIteration) as e:checks.append({'name':label,'refused':True,'actual_reason':type(e).__name__+': '+str(e)})
 else:raise AssertionError('Invalid static input accepted: '+label)
(R/'V13-ACTUAL-GEOMETRY-STATIC-CONTRACT.json').write_text(json.dumps(out,indent=2)+'\n')
summary={'status':'SOURCE_METADATA_READBACK_ONLY_NO_GLB_OR_EXPORT','elapsed_seconds':time.monotonic()-start,'exact_source_sha256':sha,'source_master_unchanged':True,'named_targets':len(out['named_targets']),'compound_proxy_boxes':len(out['collision_proxy']['components']),'raw_scene_bounds_root_m':bounds,'door_entries':out['entries'],'negative_controls':checks,'limits':'Coarse source-derived bounds/root target frames only; no continuous collision/door aperture/human fit/working coupling/publication/photo acceptance'}
(R/'STATIC-CONTROLS.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
