from pathlib import Path
import difflib,hashlib,json,ast
R=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=(R/'baseline/build_portable.py').read_text();assert "from index_streams import read_glb,attribute_rows,write_indexed\n" in b
b=b.replace('from index_streams import read_glb,attribute_rows,write_indexed\n','from index_streams import read_glb,attribute_rows,write_indexed\nfrom static_master import static_master_contract\n',1)
b=b.replace("V13actualraw ownership+3old-protrusion-ray controls PASS;no V13image yet. Historical V12matched8 established earlierwaist/U improvement only. V13source/mainPMREM/photographic acceptance OPEN","Actual V12/V13 matched8 source comparison includes4 V13 desktop/mobile detail/fullquarter PNGs: two closure/floor protrusions improve; source-visible step/finish discrepancy remains. Normalmain/indexedLOD/photographic acceptance OPEN",1)
b=b.replace('Frozen source metadata/parameters retain V12history while originalproducerV13 repairs only frontclosure/floor. Actual rawV13 is ownership/ray/Khronos-qualified but UNRENDERED;new source/mainPMREM views remain required. Indexed/mid/far appearance remains OPEN.','Frozen raw/parameters preserve historical proposal-status strings as lineage. Actual V13 source8 comparison and two-part ownership/rays/Khronos PASS; source8 is not production PMREM, LOD, physical or photographic acceptance. Current sidecar status supersedes historical unrendered notes without rewriting rawV13.',1)
needle="        (args.output/'brougham.json').write_text(json.dumps(side,indent=2)+'\\n')";assert b.count(needle)==1
b=b.replace("doc,_=read_glb(args.output/'brougham-source.glb')","doc,binary=read_glb(args.output/'brougham-source.glb')",1)
b=b.replace(needle,"        side['static_master']=static_master_contract(doc,binary,canonical_world,MASTER)\n"+needle,1)
(R/'proposed/build_portable.py').write_text(b)
s=(R/'baseline/generate.py').read_text();old="        # Original step under the door, narrow and low unlike an open flat wagon.\n        box('door_step',body,(side*.72,.34,-.08),(.28,.027,.39),4)"
new="""        # Prospective source-footplate refinement: the visible plate has two
        # separated small treads. Exact metres/hidden/opposite construction are
        # reconstructed. Preserve existing support endpoints and outerX; reconstructed
        #20mm producer-thickness encloses each actual support end cap.
        # One owned part per side still; no support/door/body/pivot amendment.
        step_vertices=[];step_faces=[];step_sides=12
        for step_z in [-.20,.07]:
            step_base=len(step_vertices)
            for step_y in [.34,.36]:
                step_vertices.extend([[side*.72+.14*math.cos(step_i*math.tau/step_sides),
                                       step_y,step_z+.065*math.sin(step_i*math.tau/step_sides)]
                                      for step_i in range(step_sides)])
            step_faces.extend([[step_base+step_i for step_i in range(step_sides)],
                               [step_base+step_sides+step_i for step_i in reversed(range(step_sides))]])
            step_faces.extend([[step_base+step_i,step_base+step_sides+step_i,
                                step_base+step_sides+(step_i+1)%step_sides,
                                step_base+(step_i+1)%step_sides]
                               for step_i in range(step_sides)])
        geometry('door_step',body,step_vertices,step_faces,4)"""
assert s.count(old)==1;s=s.replace(old,new,1);(R/'proposed/generate.py').write_text(s)
def patch(name,changes):
 t=''
 for file,old,new in changes:
  t+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/chicago/4d/tools/transport/brougham/'+file if old else '/dev/null',tofile='b/chicago/4d/tools/transport/brougham/'+file))
 (R/name).write_text(t)
patch('V13-STATIC-MASTER-METADATA.patch',[('build_portable.py',(R/'baseline/build_portable.py').read_text(),b),('static_master.py','',(R/'proposed/static_master.py').read_text())])
patch('PROSPECTIVE-TWO-FOOTPLATES-ONLY.patch',[('generate.py',(R/'baseline/generate.py').read_text(),s)])
for p in (R/'proposed').glob('*.py'):ast.parse(p.read_text())
print(json.dumps({'status':'SOURCE_ONLY_PREPARED_NO_GENERATION','baseline_generator_sha256':sha(R/'baseline/generate.py'),'baseline_wrapper_sha256':sha(R/'baseline/build_portable.py'),'static_patch_sha256':sha(R/'V13-STATIC-MASTER-METADATA.patch'),'footplate_patch_sha256':sha(R/'PROSPECTIVE-TWO-FOOTPLATES-ONLY.patch')}))
