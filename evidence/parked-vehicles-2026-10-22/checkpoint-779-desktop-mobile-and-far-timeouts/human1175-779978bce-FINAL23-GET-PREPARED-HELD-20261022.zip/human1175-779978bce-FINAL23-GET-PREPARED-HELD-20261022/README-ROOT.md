# HELD final 23-run qualification — 779978bce

This packet does not release or start an observer. All four release/review flags are false and all three local receipt hashes are null. The one finite GET snapshot reconciles inventory only; it does not qualify job logs or outcomes. No old 143 result qualifies this head.

Exact head `779978bcee51c62096778a846292c2473b9ec7af`, tree `bd514a647a68aed461f541fc2124a9cc49598626`, DEV base `142f295bde6ac501415ff5b7ccf347d72a27394d`, PR merge `d475697ab06f2297663d9f1900fb9d6d5b034b30`.

The activation binds all 18 once-dispatched smokes plus gate 39787592317, moving 39787592267, report 39787583120, humans 39787592497, and guarded bake 39787583096. All 23 must be attempt 1. Moving is now the ordinary pull_request route. Polling remains 61 seconds, maximum 150 minutes; no rerun/cancel/POST capability is added. Required guards, job/log/source/workflow checks and failure preservation remain in the unchanged collector.

Canonical input bytes are b06f82906f933b9bc59df1cdc1cc7693cf896d6d4e330220e6c127e967755dd4 at the exact absolute path in the activation. All three town phases must bind that same path and input set. `bound-input-copies/` contains inert recovery copies, not alternate execution paths. Desktop functional is four required loader checks followed by ordinary AUTO far in a warm process; it makes no cold-far acceptance claim.

Root release procedure, only after actual desktop_visual, desktop_functional and mobile_full PASS/CLOSED/unchanged and actual PNG review:

1. Confirm fresh PR/head/ref/base/merge still match the exact pins. If anything moved, stop; this packet does not authorize rebinding or redispatch.
2. Use the actual three receipt paths (the functional/mobile names are held intended names). Never synthesize receipt success. After review, run the local-only audit and write a **new** immutable release using the command below. It imports the existing collector without invoking main, browser, or network.
3. Authorize exactly one collector owner and a fresh output directory. Existing collector ownership/lock checks remain mandatory. This preparation did not start one.

```bash
python3 -B - <<'PYROOT'
import hashlib, importlib.util, json, pathlib, sys
packet=pathlib.Path('/workspace/shared/human1175-779978bce-FINAL23-GET-PREPARED-HELD-20261022')
code=pathlib.Path('/workspace/shared/human1175-14323534-guarded-bake-PREPARED-HELD-20261022')
r=json.loads((packet/'ROOT-FINAL23-OBSERVE-HELD.json').read_bytes())
assert r['released'] is False and r['allow_GET_collection'] is False
assert hashlib.sha256((code/'collect-GET-only.py').read_bytes()).hexdigest()==r['collector_sha256']
assert hashlib.sha256((code/'guarded_bake.py').read_bytes()).hexdigest()==r['guarded_bake_audit_sha256']
for pathkey, hashkey in [('dispatch_receipt','dispatch_receipt_sha256'),('final_diff_pricing','final_diff_pricing_sha256'),('canonical_inputs_path','canonical_inputs_sha256')]:
    assert hashlib.sha256(pathlib.Path(r[pathkey]).read_bytes()).hexdigest()==r[hashkey]
# Correct only the held functional/mobile path strings here if actual output names differ.
for e in r['focused_town_receipts']:
    e['sha256']=hashlib.sha256(pathlib.Path(e['path']).read_bytes()).hexdigest()
# Root's actual completed review is prerequisite to these declarations.
r['focused_published_desktop_mobile_PASS']=True
r['focused_town_pngs_reviewed']=True
sys.path.insert(0,str(code))
spec=importlib.util.spec_from_file_location('existing_strict_collector',code/'collect-GET-only.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b=(code/'CANONICAL-BARDWELL-BASELINE.json').read_bytes()
assert hashlib.sha256(b).hexdigest()==r['canonical_baseline_sha256']
print(json.dumps(m.audit_focused_town(r,r['sha'],json.loads(b)),indent=2))
r.update(released=True,allow_GET_collection=True,status='ROOT_RELEASED_HUMAN1175_FINAL_GET_COLLECTION')
r['note']='Root released after actual three-phase final-head PASS and actual PNG review; historical failures retained. Exact23 attempt1 GET qualification only.'
out=pathlib.Path('/workspace/shared/ROOT-1175-779978bce-FINAL23-GET-RELEASE.json')
with out.open('x') as f: json.dump(r,f,indent=2);f.write('\n')
print(out,hashlib.sha256(out.read_bytes()).hexdigest())
PYROOT
```

Then root's one authorized GET-only collector command (network escalation required in this environment):

```bash
python3 -B /workspace/shared/human1175-14323534-guarded-bake-PREPARED-HELD-20261022/collect-GET-only.py --release /workspace/shared/ROOT-1175-779978bce-FINAL23-GET-RELEASE.json --output /workspace/shared/ROOT-1175-779978bce-FINAL23-GET-ACTUAL
```

Do not run while any release/review prerequisite is pending. A failure remains a failure with its actual logs; no automatic repeat is authorized. Initial visible Bardwell placement is not photographic/full-tailoring acceptance or T1789 closure.
