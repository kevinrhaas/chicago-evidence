#!/usr/bin/env python3
"""Synthetic local schema controls only, never remote/runtime qualification."""
from pathlib import Path
import copy,hashlib,importlib.util,json,tempfile,sys
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
s=importlib.util.spec_from_file_location('sibling',D/'collect-GET-only.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
C=Path('/workspace/shared/human-standing-bardwell-NEXT-HEAD-LOADER-FIRST-TIMED-PREPARED-HELD-20261022/CANONICAL-EXPECTED-INPUTS-HELD.json');cb=C.read_bytes();can=json.loads(cb);H=lambda b:hashlib.sha256(b).hexdigest();base=json.loads((D/'CANONICAL-BARDWELL-BASELINE.json').read_bytes())
results=[]
with tempfile.TemporaryDirectory(prefix='SYNTHETIC-NOT-RUNTIME-fourcase-',dir='/workspace/shared') as td:
 p=Path(td);image=b'local schema fixture bytes only';pins={str(C):H(cb)}
 rows={}
 for phase in ['desktop_visual','desktop_loaders','desktop_warm_far','mobile_full']:
  r={'identity':'actual_published_bardwell_final_head_split_v1','phase':phase,'head':can['final_head'],'pass':True,'closed':True,'sourceUnchanged':True,'indexDigest':can['final_index_digest'],'inputPins':pins,'config':{'phase':phase,'viewport':'mobile' if phase=='mobile_full' else 'desktop','expectedHead':can['final_head'],'expectedIndexDigest':can['final_index_digest'],'expectedCanonicalInputsSHA':H(cb),'maxMillis':540000,'released':True,'rootLaneClosed':True},'captures':[]}
  if phase in ['desktop_visual','mobile_full']:
   r['timing']={'samples':7}
   for i in range(4):
    f=p/(phase+str(i)+'.png');f.write_bytes(image);r['captures'].append({'file':f.name,'sha256':H(image),'bytes':len(image)})
  if phase=='desktop_visual':r['desktopVisualPass']=True
  if phase in ['desktop_loaders','mobile_full']:r['loader']=[{'lod':i} for i in range(4)]
  if phase=='mobile_full':r['far']={'state':{'lod':3}}
  if phase in ['desktop_loaders','desktop_warm_far']:
   r.update(observerRevision='v5_four_case_split_original_caps',captureCallerSHA=H((D/'capture_town.cjs').read_bytes()),browserHelperSHA=H((D/'browser_review.cjs').read_bytes()))
  if phase=='desktop_loaders':r['desktopLoadersPass']=True
  if phase=='desktop_warm_far':r.update(desktopWarmFarPass=True,warmLoader={'lod':3},far={'state':{'lod':3},'warm_process_after_required_loader3_check':True},farWarmContext={'classification':'warm_process_after_required_loader3_acquire_release'})
  rows[phase]=r
 def audit(rr,mutate_release=lambda r:None):
  rows2=copy.deepcopy(rr);entries=[]
  v=rows2['desktop_visual'];vp=p/'desktop_visual.json';vb=(json.dumps(v,indent=2)+'\n').encode();vp.write_bytes(vb)
  for phase,row in rows2.items():
   if phase in ['desktop_loaders','desktop_warm_far']:row['inheritedVisual']={'receipt':str(vp),'sha256':H(vb),'head':can['final_head'],'separateExecution':True}
   b=(json.dumps(row,indent=2)+'\n').encode();rp=p/(phase+'.json');rp.write_bytes(b);entries.append({'phase':phase,'path':str(rp),'sha256':H(b)})
  r={'focused_published_desktop_mobile_PASS':True,'focused_town_pngs_reviewed':True,'canonical_inputs_path':str(C),'canonical_inputs_sha256':H(cb),'focused_town_receipts':entries};mutate_release(r)
  return m.audit_focused_town(r,can['final_head'],base)
 assert audit(rows)['PASS'];results.append('positive explicit four cases')
 changes=[('missing loader2',lambda x:x['desktop_loaders']['loader'].pop(2)),('wrong warm LOD',lambda x:x['desktop_warm_far']['warmLoader'].update(lod=2)),('deadlineReached',lambda x:x['desktop_warm_far'].update(deadlineReached=True)),('old combined phase',lambda x:x['desktop_loaders'].update(phase='desktop_functional')),('missing mobile',lambda x:x.pop('mobile_full')),('wrong caller identity',lambda x:x['desktop_loaders'].update(captureCallerSHA='0'*64)),('far in loaders case',lambda x:x['desktop_loaders'].update(far={'state':{'lod':3}})),('unclosed case',lambda x:x['desktop_warm_far'].update(closed=False))]
 for label,change in changes:
  rr=copy.deepcopy(rows);change(rr)
  try:audit(rr)
  except (ValueError,KeyError):results.append('reject '+label)
  else:raise AssertionError(label)
 try:audit(rows,lambda r:r.update(focused_town_pngs_reviewed=False))
 except ValueError:results.append('reject unreviewed PNGs')
 else:raise AssertionError('unreviewed')
(D/'FINITE-FOUR-CASE-AUDIT.json').write_text(json.dumps({'PASS':True,'scope':'Synthetic schema-only positive/negative controls; no actual runtime PASS fabricated or accepted','controls':results},indent=2)+'\n');print(len(results),'four-case audit controls PASS')
