#!/usr/bin/env python3
"""Outside-app pin/release JSON preparation only; never launches browser/build/publish or network."""
import argparse,datetime,hashlib,json,os,pathlib,re,subprocess
D=pathlib.Path(__file__).resolve().parent;REPO=pathlib.Path('/workspace/chicago');APP=REPO/'chicago/4d';SITE=REPO/'site/4d';REF=D/'IMMUTABLE-CANONICAL-IMPORT-REFERENCE';CAN=pathlib.Path('/workspace/shared/human-standing-bardwell-NEXT-HEAD-LOADER-FIRST-TIMED-PREPARED-HELD-20261022/CANONICAL-EXPECTED-INPUTS-HELD.json');SOURCE='96c4da4b1fe68e6dec3b18c15da2f14c596a60c5';ZIP='9ca4e1e692da77d3cbb1e0089f2d53cc01cd360d8cafc2b0e97230434326d5f5'
def H(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def write(p,j):pathlib.Path(p).write_text(json.dumps(j,indent=2)+'\n')
def need(ok,msg):
 if not ok:raise ValueError(msg)
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
def final_state(expected_head,passed_tree):
 head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip();idx=H(git('ls-files','--stage'))
 need(re.fullmatch('[a-f0-9]{40}',expected_head or '') and head==expected_head and head!='ad813a6278b7d76961b78ef3483f1bbf3e106c02','Actual final committed HEAD mismatch')
 need(re.fullmatch('[a-f0-9]{40}',passed_tree or '') and tree==passed_tree,'HEAD tree differs from actually passed full-gate tree')
 for args in [('diff','--quiet'),('diff','--cached','--quiet')]:need(subprocess.run(['git',*args],cwd=REPO,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}).returncode==0,'Tracked working tree/index not clean')
 return head,tree,idx
def pin(a):
 need(a.gate_closed_pass,'HELD: root must verify actual full-gate CLOSED/PASS first')
 canonical=read(CAN);need(canonical['final_head'] is None and not (D/'FINAL-PIN-RECEIPT.json').exists(),'Already pinned; preserve old identity rather than silently repin')
 head,tree,idx=final_state(a.expected_head,a.passed_tree);root=read(REF/'ROOT-ACTUAL-IMPORT.json');q=read(REF/'QUALIFICATION.json');im=read(REF/'INTAKE-EXACT-IMPORT-MANIFEST.json');inputs=read(REF/'EXACT-SOURCE-INPUTS.json')
 need(q['status']=='COMPLETE' and q['mechanical_qualified'] is True and q['sha']==root['source']==im['source_sha']==SOURCE and q['run_id']==root['run']==im['run_id']==39736567239 and root['artifact']==im['artifact_id']==12408480668 and q['artifact_zip_sha256']==root['zip_sha256']==im['artifact_zip_sha256']==ZIP,'Canonical qualification/import binding mismatch')
 need(root['assets']==im['members'] and len(root['assets'])==8 and root['unchanged_fixture8_verified'] is True,'Actual root eight-asset import identity mismatch')
 pins={}
 def check(p,h=None,n=None):
  b=p.read_bytes();digest=H(b);need((h is None or digest==h) and (n is None or len(b)==n),'Actual byte pin mismatch '+str(p));pins[str(p)]={'sha256':digest,'bytes':len(b)};return b
 source_lods=[];web_lods=[]
 for row in root['assets']:
  b=check(APP/row['destination'],row['sha256'],row['bytes']);need(git('show','HEAD:chicago/4d/'+row['destination'])==b,'Imported bytes are not actual committed HEAD '+row['destination'])
  target={'filename':pathlib.Path(row['destination']).name,'sha256':row['sha256'],'bytes':row['bytes']}
  if row['runtime']=='web':check(SITE/'data/humans/web'/target['filename'],target['sha256'],target['bytes']);web_lods.append(target)
  else:source_lods.append(target)
 for rel,h in im['unchanged_other_assets'].items():check(APP/rel,h)
 for rel,row in inputs.items():need(H(git('show','HEAD:'+rel))==row['sha256'],'Final authoring source differs from exact canonical source '+rel)
 for rel in ['data/scenes/1835.json','data/humans/contract.json','data/humans/instances/1835/index.json','data/humans/instances/1835/hi_rc_bardwell_otis_1835.json','data/sidecars/1835/people.json','data/humans/fixture.measure.json','data/humans/bardwell_otis_1835.measure.json']:need(check(APP/rel)==check(SITE/rel),'Stale published data '+rel)
 for name in ['main.js','humans.js','human-identity.js','scene-loader.js','people.js','terrain.js','walker.js','travel-settings.js','angles.js']:need(check(APP/'renderers/web/js'/name)==check(SITE/'walk/js'/name),'Stale published runtime '+name)
 for rel in ['tools/smoke_renderer.mjs','tools/smoke_budget.mjs']:check(APP/rel)
 build=read(SITE/'build.json');check(SITE/'build.json');need(build['version']==head[:9],'Published build.json does not identify actual postcommit HEAD')
 registry=read(APP/'data/humans/fixture.measure.json');by={x['file']:x for x in registry['files']};expected={x['destination']:x['sha256'] for x in root['assets']}|im['unchanged_other_assets'];need(len(by)==len(registry['files'])==len(expected)==16 and set(by)==set(expected),'Installed registry inventory mismatch')
 for file,h in expected.items():need(by[file]['sha256']==h and by[file]['verdicts'] and all(v['ok'] is True for v in by[file]['verdicts']),'Actual same-file registry hash/verdict mismatch '+file)
 public=read(APP/'data/humans/bardwell_otis_1835.measure.json');need(public['canonical_source_sha']==SOURCE and public['canonical_run_id']==39736567239 and public['canonical_artifact_id']==12408480668 and public['canonical_artifact_zip_sha256']==ZIP,'Published canonical public metadata identity mismatch')
 canonical.update(state='ROOT_PINNED_FINAL_CANONICAL_INPUTS',final_head=head,final_index_digest=idx,canonical_run_id=39736567239,canonical_source_sha=SOURCE,canonical_artifact_id=12408480668,artifact_zip_sha256=ZIP,instance_sha256=H((APP/'data/humans/instances/1835/hi_rc_bardwell_otis_1835.json').read_bytes()),web_lods=sorted(web_lods,key=lambda x:x['filename']),source_lods=sorted(source_lods,key=lambda x:x['filename']),root_import_receipt_sha256=H((REF/'ROOT-ACTUAL-IMPORT.json').read_bytes()),note='Pinned from actual clean final committed/published tree and exact successful96c4 artifact/import. Browser phases remain HELD; source4 also protected by exact tracked HEAD/index. Broadphoto/fullfit acceptance remains open.')
 write(CAN,canonical);canonical_sha=H(CAN.read_bytes())
 for phase in ['desktop_visual','desktop_loaders','desktop_warm_far','mobile_full']:
  path=D/f'RELEASE-{phase}-HELD.json';cfg=read(path);need(cfg['released'] is False and cfg['rootLaneClosed'] is False,'Unexpected released template');cfg.update(expectedHead=head,expectedIndexDigest=idx,expectedCanonicalInputsSHA=canonical_sha);write(path,cfg)
 receipt={'status':'FINAL_PINS_CAPTURED_BROWSER_STILL_HELD','final_head':head,'passed_tree':tree,'final_index_digest':idx,'canonical_inputs_sha256':canonical_sha,'canonical_source':SOURCE,'canonical_run':39736567239,'artifact':12408480668,'zip_sha256':ZIP,'root_import_record_historical_status':root['status'],'published_build':build,'verified_files':pins,'all_releases_remain_false':True,'network_or_browser_used':False,'app_written':False,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};write(D/'FINAL-PIN-RECEIPT.json',receipt);print(json.dumps({'canonical_inputs_sha256':canonical_sha,'head':head,'index':idx,'all_releases_remain_false':True}))
def release(a):
 need(a.lane_closed,'HELD: explicit actual closed/free lane required');pr=read(D/'FINAL-PIN-RECEIPT.json');head,tree,idx=final_state(pr['final_head'],pr['passed_tree']);need(idx==pr['final_index_digest'] and H(CAN.read_bytes())==pr['canonical_inputs_sha256'],'Pinned final state drift')
 for p,row in pr['verified_files'].items():need(H(pathlib.Path(p).read_bytes())==row['sha256'],'Frozen runtime/source/published pin drift '+p)
 out=pathlib.Path(a.output).resolve();dest=pathlib.Path(a.release).resolve();need(str(out).startswith('/workspace/shared/') and not out.exists() and str(dest).startswith('/workspace/shared/') and not dest.exists(),'Fresh outside output/release files required')
 cfg=read(D/f'RELEASE-{a.phase}-HELD.json');need(cfg['released'] is False and cfg['rootLaneClosed'] is False,'Unexpected pre-released template');cfg.update(released=True,rootLaneClosed=True,output=str(out),note='Root explicitly creates one final-head phase release on actual free lane; no launch occurs in this helper.')
 if a.phase in ['desktop_loaders','desktop_warm_far']:
  need(a.visual_receipt,'New actual desktop_visual receipt required');p=pathlib.Path(a.visual_receipt).resolve();v=read(p);need(v.get('phase')=='desktop_visual' and v.get('pass') is True and v.get('desktopVisualPass') is True and v.get('closed') is True and v.get('sourceUnchanged') is True and not v.get('deadlineReached') and v.get('head')==head and v.get('indexDigest')==idx and len(v.get('captures',[]))==4 and v.get('timing',{}).get('samples')==7,'Actual new successful visual phase binding failed');cfg.update(baseVisualReceipt=str(p),baseVisualReceiptSHA=H(p.read_bytes()))
 write(dest,cfg);print(json.dumps({'release_file':str(dest),'release_sha256':H(dest.read_bytes()),'phase':a.phase,'browser_launched':False}))
def main():
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True);s=sub.add_parser('pin');s.add_argument('--expected-head',required=True);s.add_argument('--passed-tree',required=True);s.add_argument('--gate-closed-pass',action='store_true');s=sub.add_parser('release');s.add_argument('--phase',choices=['desktop_visual','desktop_loaders','desktop_warm_far','mobile_full'],required=True);s.add_argument('--lane-closed',action='store_true');s.add_argument('--release',required=True);s.add_argument('--output',required=True);s.add_argument('--visual-receipt');a=p.parse_args();(pin if a.command=='pin' else release)(a)
if __name__=='__main__':main()
