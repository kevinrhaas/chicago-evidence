# HELD explicit four-case coverage for 779978bce

No browser, collector, dispatch or app write was performed. The original desktop_functional run remains FAIL at its global 540-second cap; four loader rows completed, but far did not finish inside that cap. Its exact receipt is retained as HISTORICAL-COMBINED-540-FAIL.json (404fe03f…). Neither this proposal nor future split success changes that result.

The alternative requires four actual same-head cases:

| Case | Required coverage | Status at preparation |
| --- | --- | --- |
| desktop_visual | Original three views, card, timing | Existing actual receipt; root review remains required |
| desktop_loaders | Existing production loaderOne(0), (1), (2), (3), including original mesh/rig/clip guards and release | HELD, new execution required |
| desktop_warm_far | Existing production loaderOne(3), normal release, then unchanged ordinary AUTO far | HELD, new execution required |
| mobile_full | Original complete mobile grid, unchanged caller | Actual PASS/CLOSED/sourceUnchanged; root personally reviewed all four PNGs |

Each new execution retains its own original 540-second global cap, actual 90-second AUTO wait condition, same source/index/public/instance/GLB/material/body/rig/camera/framing/sole/shoe/lifecycle guards. The warm case is explicitly a warm process after one mandatory LOD3 acquire/release. No retained preload or guaranteed cache is claimed. No source/runtime/helper/route/LOD-force changes were made. The browser helper is byte-exact a8cf3f35….

The new caller uses the original canonical absolute path with the exact b06f bytes. This intentionally keeps its inputPins compatible with the already completed visual and the original running mobile. Do not relocate or repin that canonical JSON. Copies here are recovery evidence. All proposed release files remain released=false/rootLaneClosed=false.

The sibling collector changes only the focused local audit from three phases to these four explicit cases; the original strict collector is unchanged. It rejects desktop_functional as substitute, missing/late/unclosed cases, wrong caller/helper identity, incomplete LOD coverage, absent warm LOD3 guard or absent original mobile. All remote 23-run inventories/attempt1/job/log/workflow/61s/150min/source checks are unchanged. ROOT-FINAL23-FOUR-CASE-OBSERVE-HELD.json binds that sibling and keeps all four release/review flags false. No old combined 540s PASS is claimed.

After peer approval and root's explicit free-lane release, execute desktop_warm_far FIRST, then desktop_loaders after closure. The original mobile is now actual PASS/CLOSED and root-reviewed. Prepare and execute each new case separately (not in parallel). These commands do not authorize execution themselves:

```bash
python3 -B /workspace/shared/human-standing-bardwell-779978bce-FOUR-CASE-SPLIT-PREPARED-HELD-20261022/final_pins.py release --phase desktop_warm_far --lane-closed --visual-receipt /workspace/shared/bardwell-779978bce-town-desktop-visual/receipt.json --release /workspace/shared/ROOT-BARDWELL-779978bce-DESKTOP-WARM-FAR-RELEASE.json --output /workspace/shared/bardwell-779978bce-town-desktop-warm-far
node /workspace/shared/human-standing-bardwell-779978bce-FOUR-CASE-SPLIT-PREPARED-HELD-20261022/capture_town.cjs /workspace/shared/ROOT-BARDWELL-779978bce-DESKTOP-WARM-FAR-RELEASE.json
```

After warm far closes and root releases the next lane:

```bash
python3 -B /workspace/shared/human-standing-bardwell-779978bce-FOUR-CASE-SPLIT-PREPARED-HELD-20261022/final_pins.py release --phase desktop_loaders --lane-closed --visual-receipt /workspace/shared/bardwell-779978bce-town-desktop-visual/receipt.json --release /workspace/shared/ROOT-BARDWELL-779978bce-DESKTOP-LOADERS-RELEASE.json --output /workspace/shared/bardwell-779978bce-town-desktop-loaders
node /workspace/shared/human-standing-bardwell-779978bce-FOUR-CASE-SPLIT-PREPARED-HELD-20261022/capture_town.cjs /workspace/shared/ROOT-BARDWELL-779978bce-DESKTOP-LOADERS-RELEASE.json
```

Use network/subprocess escalation required by this environment for actual browser execution. No automatic retry is authorized. A deadline remains a failure.

Only after all four actual cases PASS/CLOSED/unchanged and root's actual final-head PNG review: fill the four actual receipt hashes in a new immutable release copied from the HELD activation, set the two review flags true, run this sibling's audit_focused_town with the pinned canonical baseline locally, and only then set released/allow_GET_collection true and status ROOT_RELEASED_HUMAN1175_FINAL_GET_COLLECTION. Fresh-check the actual head/ref/base/merge first; no old result qualifies source drift. Use a fresh release/output name and exactly one collector owner. The prior three-phase README command must not be used to fabricate a combined functional PASS.

Finite validation is source-only: 4 inert extracted orchestration/order/deadline controls and 10 synthetic four-case audit controls, plus Node/Python syntax. Synthetic test receipts are temporary and deleted; they are not actual runtime proof. Full photographic/tailoring acceptance and T1789 remain open.

Root's local-only four-case audit/release command, **only after** the actual results and review above (it does not launch the collector):

```bash
python3 -B - <<'PYROOT'
import hashlib, importlib.util, json, pathlib, sys
p=pathlib.Path('/workspace/shared/human-standing-bardwell-779978bce-FOUR-CASE-SPLIT-PREPARED-HELD-20261022')
r=json.loads((p/'ROOT-FINAL23-FOUR-CASE-OBSERVE-HELD.json').read_bytes())
H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert r['released'] is False and r['allow_GET_collection'] is False
assert H(p/'collect-GET-only.py')==r['collector_sha256']
assert H(p/'guarded_bake.py')==r['guarded_bake_audit_sha256']
for a,b in [('dispatch_receipt','dispatch_receipt_sha256'),('final_diff_pricing','final_diff_pricing_sha256'),('canonical_inputs_path','canonical_inputs_sha256')]:assert H(pathlib.Path(r[a]))==r[b]
for entry in r['focused_town_receipts']:entry['sha256']=H(pathlib.Path(entry['path']))
r['focused_published_desktop_mobile_PASS']=True
r['focused_town_pngs_reviewed']=True
sys.path.insert(0,str(p));spec=importlib.util.spec_from_file_location('fourcase',p/'collect-GET-only.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b=p/'CANONICAL-BARDWELL-BASELINE.json';assert H(b)==r['canonical_baseline_sha256']
print(json.dumps(m.audit_focused_town(r,r['sha'],json.loads(b.read_bytes())),indent=2))
r.update(released=True,allow_GET_collection=True,status='ROOT_RELEASED_HUMAN1175_FINAL_GET_COLLECTION')
r['note']='Root released exact23 GET after actual four-case PASS and PNG review; original combined540FAIL retained and not relabelled.'
out=pathlib.Path('/workspace/shared/ROOT-1175-779978bce-FINAL23-FOUR-CASE-GET-RELEASE.json')
with out.open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(out,H(out))
PYROOT
```

Then root may release exactly one existing strict GET collector owner with a fresh output:

```bash
python3 -B /workspace/shared/human-standing-bardwell-779978bce-FOUR-CASE-SPLIT-PREPARED-HELD-20261022/collect-GET-only.py --release /workspace/shared/ROOT-1175-779978bce-FINAL23-FOUR-CASE-GET-RELEASE.json --output /workspace/shared/ROOT-1175-779978bce-FINAL23-FOUR-CASE-GET-ACTUAL
```

Independent source peer: /workspace/shared/bardwell-four-case-split-independent-review-20261022/REVIEW.md — SHA256 1057f0ba1709741e241c2eef92603b507a393338221259d34133bf41cdc7fd88. CLEAR; independently ran the 14 finite controls and reverse-patch proof. No runtime execution by the peer.
