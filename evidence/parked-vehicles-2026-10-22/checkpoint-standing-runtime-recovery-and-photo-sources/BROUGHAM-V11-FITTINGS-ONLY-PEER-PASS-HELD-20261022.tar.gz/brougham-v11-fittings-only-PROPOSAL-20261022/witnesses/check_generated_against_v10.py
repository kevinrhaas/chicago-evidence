"""HELD followup: verify additive V11 raw master against frozen V10, after release."""
from pathlib import Path
from collections import Counter
import argparse,hashlib,json,math,struct
BASE_SHA='645e3a9c3dcb448469a4d9d1bd3bcbb8ffde81fddf5aa401a39e08e44e731c0e'
def need(ok,msg):
    if not ok:raise ValueError(msg)
def read(p):
    b=p.read_bytes();need(b[:4]==b'glTF','GLB signature');n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);off=20+n;bn=struct.unpack_from('<I',b,off)[0];return j,b[off+8:off+8+bn]
def streams(j,b):
    rows={}
    for mesh in j['meshes']:
        prim=mesh['primitives'][0]
        for kind in ['POSITION','NORMAL']:
            a=j['accessors'][prim['attributes'][kind]];v=j['bufferViews'][a['bufferView']];need(a['componentType']==5126 and a['type']=='VEC3' and not v.get('byteStride'),'Raw float3 source expected');off=v.get('byteOffset',0)+a.get('byteOffset',0);rows[(mesh['name'],kind)]=b[off:off+a['count']*12]
    return rows
def decoded_global_bounds(j,rows):
    translations={}
    def visit(i,parent):
        node=j['nodes'][i];need(not any(k in node for k in ['matrix','rotation','scale']),'Unexpected transformed-node form');t=node.get('translation',[0,0,0]);translations[i]=[parent[k]+t[k] for k in range(3)]
        for child in node.get('children',[]):visit(child,translations[i])
    for root in j['scenes'][j.get('scene',0)]['nodes']:visit(root,[0,0,0])
    lo=[math.inf]*3;hi=[-math.inf]*3
    for i,node in enumerate(j['nodes']):
        if 'mesh' not in node:continue
        mesh=j['meshes'][node['mesh']]
        for point in struct.iter_unpack('<fff',rows[(mesh['name'],'POSITION')]):
            for k in range(3):
                value=point[k]+translations[i][k];lo[k]=min(lo[k],value);hi[k]=max(hi[k],value)
    return {'min':lo,'max':hi}
cli=argparse.ArgumentParser();cli.add_argument('--baseline',type=Path,required=True);cli.add_argument('--candidate',type=Path,required=True);cli.add_argument('--report',type=Path,required=True);args=cli.parse_args();need(hashlib.sha256(args.baseline.read_bytes()).hexdigest()==BASE_SHA,'Frozen V10 source mismatch');a,ab=read(args.baseline);c,cb=read(args.candidate);old,new=a['extras']['parts'],c['extras']['parts'];need(new[:len(old)]==old,'Original part records/order changed');need(len(new)==len(old)+9,'Expected9 additive parts only');sa,sc=streams(a,ab),streams(c,cb);base_bounds=decoded_global_bounds(a,sa);candidate_bounds=decoded_global_bounds(c,sc);need(base_bounds==candidate_bounds,'Decoded actual global vehicle bounds changed')
for part in old:
    mesh=f"surface_{part['frame']}_{part['material']}";start=part['triangle_start_in_batch']*36;end=start+part['triangles']*36
    for kind in ['POSITION','NORMAL']:need(sa[(mesh,kind)][start:end]==sc[(mesh,kind)][start:end],'Protected component changed '+part['name']+'/'+kind)
for key in ['nodes','scenes','materials','scene']:need(a.get(key)==c.get(key),'Protected metadata changed '+key)
need(c['extras']['statistics']=={'triangles':31870,'meshes':24,'nodes':41},'Unexpected additive cost');need(len(c['materials'])==6,'Unexpected material count')
pa,pc=a['extras']['parameters'],c['extras']['parameters'];need(set(pc)==set(pa)|{'source_detail_v11'},'Unexpected parameter fields');need(all(pc[k]==pa[k] for k in pa if k not in ['revision','limits']),'Protected dimension changed');need(pc['revision']==11 and pc['limits'][:-1]==pa['limits'],'Unexpected revision/limits rewrite')
expected_new=Counter({'source_near_forward_oval_latch':1,'source_near_latch_attachment_inferred':2,'source_near_central_open_fitting':1,'source_near_central_fitting_prong':3,'source_near_fitting_attachment_inferred':2});need(Counter(p['name'] for p in new[len(old):])==expected_new,'Exact additive part whitelist mismatch')
added=[]
for part in new[len(old):]:
    need(part['frame']=='vehicle_body' and part['material']==3 and part['name'].startswith('source_near_'),'New part outside whitelist');mesh='surface_vehicle_body_3';start=part['triangle_start_in_batch']*36;end=start+part['triangles']*36;p=list(struct.iter_unpack('<fff',sc[(mesh,'POSITION')][start:end]));n=list(struct.iter_unpack('<fff',sc[(mesh,'NORMAL')][start:end]));need(all(math.isfinite(v) for row in p+n for v in row),'New nonfinite vertex');need(all(abs(math.sqrt(sum(v*v for v in row))-1)<1e-5 for row in n),'New nonunit normal');edges=Counter();volume=0.0
    for i in range(0,len(p),3):
        tri=p[i:i+3];u=[tri[1][k]-tri[0][k] for k in range(3)];v=[tri[2][k]-tri[0][k] for k in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];need(sum(x*x for x in cross)>1e-20,'New degenerate triangle');length=math.sqrt(sum(x*x for x in cross));need(all(sum(cross[k]*n[i+j][k] for k in range(3))/length>.9999 for j in range(3)),'New normal orientation mismatch');volume+=sum(tri[0][k]*[tri[1][1]*tri[2][2]-tri[1][2]*tri[2][1],tri[1][2]*tri[2][0]-tri[1][0]*tri[2][2],tri[1][0]*tri[2][1]-tri[1][1]*tri[2][0]][k] for k in range(3))/6
        for aa,bb in [(0,1),(1,2),(2,0)]:edges[tuple(sorted((tri[aa],tri[bb])))]+=1
    need(all(v==2 for v in edges.values()),'New feature not closed-welded '+part['name']);need(volume>0,'New closed feature must have positive signed volume');need(min(v[0] for v in p)>0,'Unattested opposite-side fitting');added.append({'name':part['name'],'triangles':part['triangles'],'closed_welded':True,'positive_signed_volume_m3':volume})
report={'pass':True,'scope':'Generated additive source geometry contract only; no actual visual/photographic or mainworld acceptance','candidate_sha256':hashlib.sha256(args.candidate.read_bytes()).hexdigest(),'all_existing_part_records_and_position_normal_streams_exact':True,'protected_parts':len(old),'all_nodes_scenes_materials_exact':True,'baseline_decoded_global_bounds_m':base_bounds,'candidate_decoded_global_bounds_m':candidate_bounds,'actual_decoded_global_bounds_exact':True,'closed_volume_does_not_prove_no_intersections':True,'old_dimensions_unchanged':True,'new_parts':added,'statistics':c['extras']['statistics']};args.report.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
