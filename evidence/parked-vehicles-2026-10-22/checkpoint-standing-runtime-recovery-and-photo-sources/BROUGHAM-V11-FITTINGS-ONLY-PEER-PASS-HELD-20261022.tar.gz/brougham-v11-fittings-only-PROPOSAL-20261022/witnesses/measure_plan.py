"""Cheap analytic feature path/bounds witness only; no producer/GLB/render runs."""
from pathlib import Path
import importlib.util,json,math,hashlib
R=Path(__file__).parents[1];spec=importlib.util.spec_from_file_location('source_details',R/'proposed/source_details.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=json.loads((R/'proposed/parameters.json').read_text());features=m.feature_plan(p);h=json.loads(Path('/workspace/shared/brougham-v10-source-reference-preparation-20261022/FROZEN-CAMERA-HYPOTHESIS.json').read_text())['fit'];dot=lambda a,b:sum(x*y for x,y in zip(a,b))
def project(v):
 d=h['distance_m']-dot(v,h['basis']['towardCamera']);return[h['principal_px'][0]+h['focal_px']*dot(v,h['basis']['right'])/d,h['principal_px'][1]-h['focal_px']*dot(v,h['basis']['up'])/d]
def world(v):return[v[0],v[1]*1.13+.03,v[2]]
def bound(f):
 pts=f.get('path',[f.get('start'),f.get('end')]);r=f['radius_m'] if f['kind']=='tube' else f['width_m']/math.sqrt(2)
 lo=[min(x[k] for x in pts)-r for k in range(3)];hi=[max(x[k] for x in pts)+r for k in range(3)];lo,hi=world(lo),world(hi);corners=[[x,y,z] for x in [lo[0],hi[0]] for y in [lo[1],hi[1]] for z in [lo[2],hi[2]]];pr=[project(v) for v in corners];return{'world_bounds_m':[lo,hi],'source_projection_conservative_bounds_px':[[min(v[k] for v in pr) for k in range(2)],[max(v[k] for v in pr) for k in range(2)]],'bound_method':'Path expanded by tube radius or conservative beam diagonal before unchanged bodyYaffine; projected AABB corners, not visible silhouette.'}
def tri(f,sides):
 if f['kind']=='beam':return 12
 n=len(f['path']);closed=math.dist(f['path'][0],f['path'][-1])<1e-10
 return 2*(n-1)*sides+(0 if closed else 2*(sides-2))
rows=[{'name':f['name'],'kind':f['kind'],'material':f['material'],'path_points':len(f.get('path',[])),**bound(f),'predicted_added_triangles':{d:tri(f,s) for d,s in [('near',8),('mid',6),('far',4)]}} for f in features]
lo=[min(r['world_bounds_m'][0][k] for r in rows) for k in range(3)];hi=[max(r['world_bounds_m'][1][k] for r in rows) for k in range(3)];base=[[-.8600000143,0,-1.83655285835],[.8600000143,2.18829989433,3.82500004768]]
result={'state':'ANALYTIC_SOURCE_PLAN_WITNESS_NOT_GENERATED_GEOMETRY_OR_VISUAL_ACCEPTANCE','features':rows,'total_new_parts':len(rows),'new_geometry_bounds_m':[lo,hi],'within_frozen_full_vehicle_bounds':all(base[0][k]<=lo[k]<=hi[k]<=base[1][k] for k in range(3)),'predicted_added_triangles':{d:sum(r['predicted_added_triangles'][d] for r in rows) for d in ['near','mid','far']},'predicted_total_triangles':{d:basecount+sum(r['predicted_added_triangles'][d] for r in rows) for d,basecount in [('near',30782),('mid',18310),('far',10170)]},'side_policy':'PositiveX observed side only; no invented opposite-side matching fittings','remaining_source_ambiguity':'No lower central mark interpretation, unseen lock mechanism, tread-side reassignment or additional tread.'}
(R/'witnesses/ANALYTIC-FEATURE-BOUNDS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='features'},indent=2))
