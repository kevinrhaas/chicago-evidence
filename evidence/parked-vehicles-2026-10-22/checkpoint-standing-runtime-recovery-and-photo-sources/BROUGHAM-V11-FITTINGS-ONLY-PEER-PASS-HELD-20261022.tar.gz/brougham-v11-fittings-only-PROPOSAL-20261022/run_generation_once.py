"""HELD: root-reviewed single-thread original-source V11 near master only, no browser."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,signal,subprocess,time
R=Path(__file__).parent.resolve();START=time.monotonic();BUDGET=90
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def need(ok,msg):
    if not ok:raise ValueError(msg)
cli=argparse.ArgumentParser();cli.add_argument('--release',type=Path,required=True);args=cli.parse_args();release=json.loads(args.release.read_text());manifest=json.loads((R/'SOURCE-MANIFEST.json').read_text())
need(release.get('authorization_owner')=='root' and release.get('release_generation') is True and release.get('local_heavy_lane_free') is True,'Explicit root source-generation release required')
need(release.get('source_manifest_sha256')==sha(R/'SOURCE-MANIFEST.json'),'Exact reviewed source manifest release required')
for row in manifest['files']:
    p=(R/row['path']).resolve();need(p.is_relative_to(R) and p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'Frozen input drift '+row['path'])
for row in manifest['runtime_binaries']:
    p=Path(row['path']);need(p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'Runtime binary drift')
need(not (R/'GENERATION-INTENT.json').exists() and not (R/'first').exists() and not (R/'repeat').exists(),'Exclusive intent/output already exists; no automatic retry')
with (R/'GENERATION-INTENT.json').open('x') as f:json.dump({'root_release':release,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'budget_seconds':BUDGET},f,indent=2)
receipt={'pass':False,'scope':'V11 raw near source only; no portable LOD, render, mainworld or photographic acceptance','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':[]};python=manifest['python_executable'];node=manifest['node_executable'];env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def save():
    (R/'GENERATION-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(label,args):
    remaining=BUDGET-(time.monotonic()-START)-2;need(remaining>0,'90 second owner deadline');p=subprocess.Popen(['nice','-n','10',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True,env=env)
    try:out,err=p.communicate(timeout=remaining)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate(timeout=1);(R/(label+'.stdout.log')).write_text(out);(R/(label+'.stderr.log')).write_text(err);raise TimeoutError('90second owner deadline; owned process group killed')
    (R/(label+'.stdout.log')).write_text(out);(R/(label+'.stderr.log')).write_text(err);receipt['stages'].append({'label':label,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-START});save();need(p.returncode==0,'Stage failed '+label)
try:
    for label in ['first','repeat']:run(label,[python,str(R/'proposed/generate.py'),'--parameters',str(R/'proposed/parameters.json'),'--detail','near','--lod-recipe',str(R/'baseline/lods.json'),'--output',str(R/label)])
    names=sorted(p.name for p in (R/'first').iterdir());need(names==sorted(p.name for p in (R/'repeat').iterdir()),'Repeat output list differs');receipt['repeat_byteexact']={}
    for n in names:need((R/'first'/n).read_bytes()==(R/'repeat'/n).read_bytes(),'Same-input nondeterminism '+n);receipt['repeat_byteexact'][n]=sha(R/'first'/n)
    run('protected-geometry-check',[python,str(R/'witnesses/check_generated_against_v10.py'),'--baseline',str(R/'baseline/brougham-v10.glb'),'--candidate',str(R/'first/brougham.glb'),'--report',str(R/'PROTECTED-GEOMETRY-CHECK.json')])
    run('khronos',[node,str(R/'witnesses/validate_raw.cjs'),str(R/'first/brougham.glb'),str(R/'KHRONOS-V11-RAW.json')]);receipt['pass']=True
except Exception as e:receipt['error']=repr(e)
finally:receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['seconds']=time.monotonic()-START;save()
need(receipt['pass'],'Finite generation failed; preserve actual receipt; no retry')
print('PASS finite raw-source generation/reproduction/protection/Khronos; no browser/portable/app work.')
