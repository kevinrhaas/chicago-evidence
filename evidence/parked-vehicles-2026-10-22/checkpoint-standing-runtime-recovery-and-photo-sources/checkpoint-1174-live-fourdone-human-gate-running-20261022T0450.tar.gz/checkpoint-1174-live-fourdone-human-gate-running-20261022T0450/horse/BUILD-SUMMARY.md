# Actual first static anatomical build

ONE reviewed build from frozen source archivefc60f902 completed exit0 in0.416s under nice10, single-thread environment and an owned process-group60s deadline. No process remained. Logs/terminal live at `/workspace/shared/horse-anatomical-static-first-run-20261022/`.

- Actual GLB:568,192 B, SHA256 `4fa3dce85d53c10cf7b570519497a1759013e9cea7696a6d5237dcecaae9313d`.
- Source cage:760vertices/714faces; subdivided export:11,778vertices/23,552triangles/6material batches.
- Actual accessor bounds: X±.3375244823, Y0..2.1181770833, Z−.9283289931..1.2444565430metres.
- Zero animations, rig joints or sockets; no old fits carried over.
- Original installed89b048 bytes and app/ticket/Git/mirror files unchanged.

These counts and source exporter guards are not independent geometry or appearance proof. Vertex-link manifoldness, self-intersections, local root folds, normals, exact exported support/sole, anatomical volume, hair/material quality and photographic acceptance remain **UNPROVEN** until actual readback and frames. No browser or second build ran. Root received terminal immediately and reclaimed the heavy lane for its full gate.
