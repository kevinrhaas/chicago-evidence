# One-shot generation — HELD until root release

Command, after explicit heavy-lane release only:

    python3 -B /workspace/shared/covered-cloth-drape-proposal-2026-10-22/run-once.py --release

The caller has not been executed. `CALLER-PINS.json` binds the caller, validator, candidate, frozen parent274e, parts2fb and unchanged covered recipece25, and both original models/sidecars. It uses one `nice15`, single-thread candidate-core process to generate BOTH distinct finishes. No parent/hardware regeneration, app imports/writes, browser, full tests, installed packages, network or fallback. `ATTEMPT-v1.lock` refuses any repeat, including after interruption. Work deadline118 seconds plus up to2 seconds to terminate its owned process group; no retries. Logs and outputs survive failure. Durable `owner-v1.json` records caller/child ownership and terminal CLOSED departure; the starting tool session ID must additionally be reported when released.

After generation, one readback worker under the same deadline checks actual GLB streams and sidecars. It requires exact original parent BIN prefix; identical nodes/pivots/children, scenes, materials/images/textures and protected attribute bytes; exact authored mapping already asserted by the candidate producer against the strict2fb source; unchanged coordinates, bearing, ID, yoke, seed/age/finish and remaining sidecar fields; and exactly the intended cloth POSITION/NORMAL/TANGENT changes while cloth UV bytes remain exact. JSON changes are limited to corresponding accessor bounds and the honest fold description. Both models must remain distinct. No source or existing accepted pin is updated.

It also reads Float32 triangles for the sheet and seam/hem meshes and all five bows in their shared structure frame. A50mm grid and AABB broadphase precede segment/triangle plus coplanar2D narrowphase. Touching counts as intersection. Crossing/coplanar/edge-touch/separated analytical controls must pass. Baseline and candidate both must have zero cloth-versus-bow intersections; the first found intersection is preserved and fails. This is NOT a positive minimum-distance certificate or an exhaustive self/intersection check against the rest of the vehicle. Actual source model/render appearance still requires separate review.

Only after actual mesh success should a separate caller be reviewed for matched normal default-main-light side and quarter images for both distinct finishes. No photographic acceptance or cleared historical canvas measurement is claimed. The baseline models remain saved under `before/` regardless of outcome.
