#!/usr/bin/env python3
"""Finite generated-file readback only. No app imports, renderer or mutations."""
import copy, hashlib, itertools, json, math, struct, sys, traceback
from pathlib import Path
HERE=Path(__file__).resolve().parent
OUT=HERE/'actual-v1'
REPORT=HERE/'readback-v1.json'
PARENT='274e737b51872983df792d0b24de8e75de8631890a8d586a32d9c6f0066484fb'
PARTS='2fb3709d233e896280c50342618c28f9e340029e52c67b328100e05a125e2c27'
CLOTH={'covered_original_canvas_sheet','covered_original_sewn_and_folded_hems'}
DIMS={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def need(c,m):
 if not c: raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def readglb(p):
 raw=p.read_bytes();magic,version,length=struct.unpack_from('<III',raw)
 need(magic==0x46546c67 and version==2 and length==len(raw),'GLB header '+str(p))
 n,t=struct.unpack_from('<II',raw,12);need(t==0x4e4f534a,'JSON chunk')
 g=json.loads(raw[20:20+n]);bn,bt=struct.unpack_from('<II',raw,20+n)
 need(bt==0x004e4942 and bn==len(raw)-28-n,'BIN chunk')
 return raw,g,raw[28+n:]
def stream(g,b,idx):
 a=g['accessors'][idx];v=g['bufferViews'][a['bufferView']]
 need(a['componentType']==5126 and 'sparse' not in a and 'byteStride' not in v,'Contiguous Float32 accessor')
 d=DIMS[a['type']];off=v.get('byteOffset',0)+a.get('byteOffset',0);raw=b[off:off+a['count']*d*4]
 need(len(raw)==a['count']*d*4,'Accessor byte range');return raw

def points(g,b,idx):
 a=g['accessors'][idx];d=DIMS[a['type']];flat=struct.unpack('<'+'f'*(a['count']*d),stream(g,b,idx))
 need(all(math.isfinite(x) for x in flat),'Finite attribute')
 return [flat[i:i+d] for i in range(0,len(flat),d)]
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def dot(a,b):return math.fsum(x*y for x,y in zip(a,b))
def norm(a):return math.sqrt(dot(a,a))
def segment_triangle(p,q,t):
 d=sub(q,p);e1=sub(t[1],t[0]);e2=sub(t[2],t[0]);h=cross(d,e2);det=dot(e1,h)
 if abs(det)<1e-13:return False
 inv=1/det;s=sub(p,t[0]);u=inv*dot(s,h)
 if u < -1e-9 or u > 1+1e-9:return False
 r=cross(s,e1);v=inv*dot(d,r)
 if v < -1e-9 or u+v > 1+1e-9:return False
 k=inv*dot(e2,r);return -1e-9<=k<=1+1e-9

def orient(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def coplanar(a,b,n):
 drop=max(range(3),key=lambda k:abs(n[k]));project=lambda p:tuple(v for k,v in enumerate(p) if k!=drop)
 a=[project(p) for p in a];b=[project(p) for p in b];eps=1e-10
 def in_tri(p,t):
  s=[orient(t[i],t[(i+1)%3],p) for i in range(3)];return min(s)>=-eps or max(s)<=eps
 def onseg(p,q,r):return min(p[0],q[0])-eps<=r[0]<=max(p[0],q[0])+eps and min(p[1],q[1])-eps<=r[1]<=max(p[1],q[1])+eps
 for i in range(3):
  p,q=a[i],a[(i+1)%3]
  for j in range(3):
   r,s=b[j],b[(j+1)%3];x,y=orient(p,q,r),orient(p,q,s);z,w=orient(r,s,p),orient(r,s,q)
   if x*y < 0 and z*w < 0:return True
   if (abs(x)<=eps and onseg(p,q,r)) or (abs(y)<=eps and onseg(p,q,s)) or (abs(z)<=eps and onseg(r,s,p)) or (abs(w)<=eps and onseg(r,s,q)):return True
 return in_tri(a[0],b) or in_tri(b[0],a)
def intersect(a,b):
 n=cross(sub(a[1],a[0]),sub(a[2],a[0]));m=cross(sub(b[1],b[0]),sub(b[2],b[0]));nn=norm(n);mm=norm(m)
 need(nn>1e-12 and mm>1e-12,'Nondegenerate cloth/bow triangle')
 n=tuple(x/nn for x in n);m=tuple(x/mm for x in m)
 if norm(cross(n,m))<1e-8:
  if max(abs(dot(n,sub(p,a[0]))) for p in b)<=1e-8:return coplanar(a,b,n)
  return False
 return any(segment_triangle(a[i],a[(i+1)%3],b) or segment_triangle(b[i],b[(i+1)%3],a) for i in range(3))
def triangles(g,b,name):
 mesh=next(m for m in g['meshes'] if m['name']==name);need(len(mesh['primitives'])==1,'One primitive')
 p=mesh['primitives'][0];need('indices' not in p,'Nonindexed triangles');v=points(g,b,p['attributes']['POSITION']);need(len(v)%3==0,'Triangle list');return [v[i:i+3] for i in range(0,len(v),3)]
def bounds(t):return tuple(min(p[k] for p in t) for k in range(3)),tuple(max(p[k] for p in t) for k in range(3))
def cells(box):return itertools.product(*(range(math.floor(box[0][k]/.05),math.floor(box[1][k]/.05)+1) for k in range(3)))
def cloth_bow(g,b):
 bows=triangles(g,b,'covered_original_five_bows');bb=[bounds(t) for t in bows];grid={}
 for i,box in enumerate(bb):
  for cell in cells(box):grid.setdefault(cell,[]).append(i)
 result={'bow_triangles':len(bows),'cloth_triangles':0,'aabb_overlapping_triangle_pairs':0,'intersections':[],'method':'Readback Float32 triangles; 50mm grid broadphase, exact AABB filter, segment/triangle and coplanar2D narrowphase; touching counts as intersection; no positive-clearance-distance claim'}
 for name in sorted(CLOTH):
  tt=triangles(g,b,name);result['cloth_triangles']+=len(tt)
  for i,t in enumerate(tt):
   box=bounds(t);potential=set(j for cell in cells(box) for j in grid.get(cell,[]))
   for j in sorted(potential):
    if any(box[1][k]<bb[j][0][k] or bb[j][1][k]<box[0][k] for k in range(3)):continue
    result['aabb_overlapping_triangle_pairs']+=1
    if intersect(t,bows[j]):
     result['intersections'].append({'mesh':name,'cloth_triangle':i,'bow_triangle':j})
     return result
 return result

def main():
 report={'status':'RUNNING','models':[],'limits':['No rendered visual acceptance','No exhaustive non-bow self-intersection or positive separation-distance proof','Both cloth meshes tested against all five rendered bow meshes in shared structure frame']}
 try:
  # Known crossing, coplanar overlap, edge touch and separated controls exercise the narrowphase before any model result.
  triangle=[(0.,0.,0.),(1.,0.,0.),(0.,1.,0.)]
  controls={'crossing':intersect(triangle,[(.2,.2,-1.),(.2,.2,1.),(.8,.2,0.)]),'coplanar_overlap':intersect(triangle,[(.1,.1,0.),(.4,.1,0.),(.1,.4,0.)]),'edge_touch':intersect(triangle,[(1.,0.,0.),(2.,0.,0.),(1.,1.,0.)]),'separated':not intersect(triangle,[(0.,0.,.01),(1.,0.,.01),(0.,1.,.01)])}
  report['intersection_predicate_controls']=controls;need(all(controls.values()),'Intersection predicate control failed')
  parent,pg,pb=readglb(HERE/'inputs/parent-wagon-w01.glb');need(sha(parent)==PARENT,'Parent pin')
  need(sha((HERE/'inputs/authored-parts.json').read_bytes())==PARTS,'Parts pin')
  params=json.loads((HERE/'inputs/covered-w01.json').read_text());seen=set();hashes=[]
  for variant in params['variants']:
   model=variant['asset_id'];need(model not in seen,'Duplicate variant');seen.add(model)
   raw,g,b=readglb(OUT/model/'covered-w01.glb');old,og,ob=readglb(HERE/'before'/model/'covered-w01.glb')
   s=json.loads((OUT/model/'covered-w01.json').read_text());os=json.loads((HERE/'before'/model/'covered-w01.json').read_text())
   item={'model':model,'before_sha256':sha(old),'candidate_sha256':sha(raw)};report['models'].append(item)
   need(b[:len(pb)]==pb and b[:len(pb)]==ob[:len(pb)],'Protected parent BIN prefix')
   need(g['nodes']==og['nodes'] and g['scenes']==og['scenes'],'Original nodes/pivots/sockets/children unchanged')
   need(g['materials']==og['materials'] and g['textures']==og['textures'] and g['images']==og['images'],'All material/texture definitions unchanged')
   info=g['extras']['covered_derivative'];need(info['legacy_record_id']==variant['id'] and info['yoke']==variant['yoke'],'Original ID/yoke')
   need(s['seeded_coat']==variant['coat']==os['seeded_coat'],'Original individual finish/seed/age')
   need(s['original_coordinates']==variant['at_local_enu_m'] and s['original_bearing_deg']==variant['bearing_deg'],'Original stand/bearing')
   need(s['parent_sha256']==PARENT and s['authored_parts_sha256']==PARTS,'Strict frozen source identity')
   need(s['glb_sha256']==sha(raw) and s['source_sha256']==sha((HERE/'candidate/build.py').read_bytes()),'Actual output/source sidecar hashes')
   need(s['parentBINprefixExact'] and s['originalNodeTransformsPivotsAndChildPrefixesExact'],'Producer protected assertions')
   normalized=copy.deepcopy(s)
   for key in ['glb_sha256','bytes','source_sha256']:normalized[key]=os[key]
   need(normalized==os,'Sidecar has only expected source/product/byte changes')
   ng=copy.deepcopy(g);changed=[];unchanged=0
   need(len(g['meshes'])==len(og['meshes']),'Same mesh count')
   for mesh,omesh in zip(g['meshes'],og['meshes']):
    need(mesh==omesh,'Same names/material bindings/accessor layout')
    for primitive in mesh['primitives']:
     for attr,idx in primitive['attributes'].items():
      newstream=stream(g,b,idx);oldstream=stream(og,ob,idx)
      if mesh['name'] in CLOTH and attr in {'POSITION','NORMAL','TANGENT'}:
       need(g['accessors'][idx]['count']==og['accessors'][idx]['count'],'Same cloth topology/count')
       data=points(g,b,idx)
       for kind,fn in [('min',min),('max',max)]:
        actual=[fn(p[k] for p in data) for k in range(len(data[0]))]
        need(max(abs(a-c) for a,c in zip(actual,g['accessors'][idx][kind]))<2e-6,'Finite accurate cloth accessor bounds')
        ng['accessors'][idx][kind]=og['accessors'][idx][kind]
       changed.append({'mesh':mesh['name'],'attribute':attr,'bytes_differ':newstream!=oldstream})
      else:need(newstream==oldstream,'Protected attribute changed: '+mesh['name']+'/'+attr);unchanged+=1
   ng['extras']['covered_derivative']['folds']=og['extras']['covered_derivative']['folds']
   need(ng==og,'GLB JSON changes limited to cloth attribute bounds and honest fold description')
   need(all(x['bytes_differ'] for x in changed),'All intended cloth geometric attributes actually changed')
   item.update(protected_parent_prefix_bytes=len(pb),protected_attribute_streams=unchanged,changed_cloth_streams=changed,producer_mapping=s['retainedBatchReceipt'],identity_and_sidecar='PASS')
   item['baseline_cloth_bow']=cloth_bow(og,ob)
   need(not item['baseline_cloth_bow']['intersections'],'Baseline cloth/bow intersection found; preserve and review')
   item['candidate_cloth_bow']=cloth_bow(g,b)
   need(not item['candidate_cloth_bow']['intersections'],'Candidate cloth/bow intersection')
   hashes.append(sha(raw));item['status']='PASS';REPORT.write_text(json.dumps(report,indent=2)+'\n')
  need(len(seen)==2 and len(set(hashes))==2,'Two distinct output variants')
  report['status']='PASS'
 except BaseException as e:
  report['status']='FAIL';report['failure']=repr(e);report['traceback']=traceback.format_exc();raise
 finally:REPORT.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'status':'PASS','models':[{k:m[k] for k in ['model','candidate_sha256','status']} for m in report['models']]}))
if __name__=='__main__':main()
