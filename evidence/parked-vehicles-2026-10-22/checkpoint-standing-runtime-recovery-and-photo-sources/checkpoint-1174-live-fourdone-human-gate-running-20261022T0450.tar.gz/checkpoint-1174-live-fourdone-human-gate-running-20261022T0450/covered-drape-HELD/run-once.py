#!/usr/bin/env python3
"""HELD until root release. One attempt,120s total; no app writes or fallback."""
import argparse,datetime,hashlib,json,os,platform,signal,subprocess,sys,time,traceback
from pathlib import Path
HERE=Path(__file__).resolve().parent
STATE=HERE/'owner-v1.json'
ACTIVE=None
START=None
CURRENT={}
PINFILE=HERE/'CALLER-PINS.json'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(**extra):
 CURRENT.update(extra);temp=STATE.with_suffix('.json.tmp');temp.write_text(json.dumps(CURRENT,indent=2)+'\n');temp.replace(STATE)
def stop_owned():
 global ACTIVE
 if ACTIVE is None:return
 if ACTIVE.poll() is None:
  try:os.killpg(ACTIVE.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:ACTIVE.wait(timeout=1)
  except subprocess.TimeoutExpired:
   try:os.killpg(ACTIVE.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   ACTIVE.wait(timeout=1)
 save(owned_child_pid=None,owned_child_returncode=ACTIVE.returncode)
 ACTIVE=None

def interrupted(signum,frame):raise RuntimeError('Caller interrupted by signal '+str(signum))
def child(phase,args,env):
 global ACTIVE
 remaining=118-(time.monotonic()-START)
 if remaining<=0:raise TimeoutError('118s work deadline reached before '+phase)
 cmd=['nice','-n','15',sys.executable,'-B',*map(str,args)]
 with (HERE/(phase+'.stdout')).open('xb') as stdout,(HERE/(phase+'.stderr')).open('xb') as stderr:
  ACTIVE=subprocess.Popen(cmd,cwd=HERE,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  save(phase=phase,owned_child_pid=ACTIVE.pid,owned_child_process_group=ACTIVE.pid,command=cmd,phase_started_utc=utc())
  try:rc=ACTIVE.wait(timeout=remaining)
  except subprocess.TimeoutExpired:raise TimeoutError('118s total work deadline exceeded in '+phase)
  save(owned_child_pid=None,owned_child_returncode=rc)
  ACTIVE=None
  if rc:raise RuntimeError(phase+' exited '+str(rc)+'; preserved stdout/stderr')
def main():
 global START
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--release',action='store_true',required=True,help='Use only after explicit root heavy-lane release');ap.parse_args()
 # An O_EXCL attempt record forbids retries even after an interrupted caller.
 fd=os.open(HERE/'ATTEMPT-v1.lock',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.write(fd,str(os.getpid()).encode());os.close(fd)
 START=time.monotonic();signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
 CURRENT.update(status='RUNNING',caller_pid=os.getpid(),caller_ppid=os.getppid(),started_utc=utc(),python=sys.version,python_executable=sys.executable,platform=platform.platform(),max_wall_seconds=120,work_deadline_seconds=118,server='NONE',browser='NONE',output=str(HERE/'actual-v1'),progress_path=str(STATE),pins_path=str(PINFILE),scope='One candidate core invocation for both finishes, then actual readback; no app writes')
 result=1
 try:
  pins=json.loads(PINFILE.read_text())
  for name,pin in pins['files'].items():
   if digest(HERE/name)!=pin:raise ValueError('Frozen caller/input changed: '+name)
  if (HERE/'actual-v1').exists():raise ValueError('Fresh output required')
  env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',BLIS_NUM_THREADS='1')
  save(phase='PINNED',thread_environment={k:env[k] for k in ['PYTHONDONTWRITEBYTECODE','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS']})
  child('generation',[HERE/'candidate/build.py','--parent',HERE/'inputs/parent-wagon-w01.glb','--authored-parts',HERE/'inputs/authored-parts.json','--parameters',HERE/'inputs/covered-w01.json','--output',HERE/'actual-v1'],env)
  save(phase='GENERATED')
  child('readback',[HERE/'validate-readback.py'],env)
  save(status='PASS',phase='VERIFIED',readback=str(HERE/'readback-v1.json'));result=0
 except BaseException as e:
  save(status='FAIL',failure=repr(e),traceback=traceback.format_exc())
 finally:
  stop_owned();save(lifecycle='CLOSED',owner_departed_utc=utc(),elapsed_seconds=time.monotonic()-START,owned_child_pid=None)
 print(json.dumps(CURRENT));return result
if __name__=='__main__':sys.exit(main())
