# SPDX-License-Identifier: CC0-1.0
import os,pathlib,signal,subprocess,time,json,hashlib
here=pathlib.Path(__file__).resolve().parent
source=pathlib.Path('/workspace/shared/horse-anatomical-master-authoring-next-20261022')
archive=pathlib.Path('/workspace/shared/horse-anatomical-master-authoring-next-20261022.tar.gz')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(archive.read_bytes())=='fc60f90291c7fed77f3038bbe204819ec3b9e9a3b61a3ac94d64cf792798d3e5','Frozen archive pin changed'
for entry in json.loads((source/'MANIFEST.json').read_text())['files']:
 raw=(source/entry['path']).read_bytes();assert len(raw)==entry['bytes'] and sha(raw)==entry['sha256'],entry['path']
output='/workspace/shared/horse-anatomical-static-first-20261022'
assert not pathlib.Path(output).exists(),'Refuse existing output'
cmd=['nice','-n','10','python',str(source/'quad_cage_authoring.py'),'--execute-reviewed-source','--output-dir',output]
env=os.environ.copy()
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:env[key]='1'
start=time.monotonic();report={'status':'RUNNING','command':cmd,'frozen_archive_sha256':sha(archive.read_bytes()),'source_sha256':sha((source/'quad_cage_authoring.py').read_bytes()),'controls_sha256':sha((source/'anatomy-authoring-controls.json').read_bytes()),'source_pins_verified':True,'whole_deadline_seconds':60,'execution_timeout_seconds':55,'scope':'ONE outside-app STATIC build only; no browser, rig/clip/socket carryover or tracked mutation','output_dir':output}
with (here/'build.stdout').open('wb') as stdout,(here/'build.stderr').open('wb') as stderr:
 p=subprocess.Popen(cmd,env=env,stdout=stdout,stderr=stderr,start_new_session=True);report['owned_pid']=p.pid;report['owned_pgid']=p.pid
 try:p.wait(timeout=55);report['exit_code']=p.returncode;report['status']='TERMINAL'
 except subprocess.TimeoutExpired:report['exit_code']=124;report['status']='TIMEOUT'
 finally:
  try:os.killpg(p.pid,signal.SIGTERM);report['cleanup_term_sent']=True
  except ProcessLookupError:report['cleanup_term_sent']=False
  try:p.wait(timeout=max(.1,58-(time.monotonic()-start)))
  except subprocess.TimeoutExpired:pass
  try:os.killpg(p.pid,signal.SIGKILL);report['cleanup_kill_sent']=True
  except ProcessLookupError:report['cleanup_kill_sent']=False
  if p.poll() is None:p.wait(timeout=max(.1,60-(time.monotonic()-start)))
report['elapsed_seconds']=time.monotonic()-start
report['actual_outputs']=[{'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in pathlib.Path(output).glob('*') if f.is_file()]
(here/'terminal.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
print('STDOUT:',(here/'build.stdout').read_text());print('STDERR:',(here/'build.stderr').read_text())
raise SystemExit(report['exit_code'])
