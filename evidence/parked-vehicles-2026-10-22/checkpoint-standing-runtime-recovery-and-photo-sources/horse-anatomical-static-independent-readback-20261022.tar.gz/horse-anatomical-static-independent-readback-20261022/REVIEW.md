# Actual static horse readback — BLOCKED for matched-view qualification

InputGLB4fa3dce85d53c10cf7b570519497a1759013e9cea7696a6d5237dcecaae9313d,568192bytes. SurfaceJSON00b5b9fb76d6ff4e19ee1f0c573d43052c1cbc09e7117b40a02295d3ae2e0ac7; manifest controls equal the reviewedfc60f902 source controls. The original first build remains failed evidence, not an accepted master. No app/index/Git writes, rebuild, browser or CI execution occurred.

**Blocking finding: actual self-intersecting skin.** A complete5cm-grid AABB broad phase found189638 candidate triangle pairs. Strict interior non-coplanar segment/triangle testing found586 crossing pairs:436 around limb/body junctions and folded limb roots,150 around the two nostril cups/nose. These are triangle-pair counts, not586 distinct defects. Symmetric fore/hind and both nostrils are affected. The topology can be closed while its physical embedding folds through itself.

`PROPER-CROSSING-WITNESSES.json` independently confirms16 region-pair examples using signed-plane edge interpolation and Gram-matrix barycentrics rather than the first screen's Moller-Trumbore calculation. Witnesses include actualFloat32 positions/indices, strict-interior segment t/barycentrics, crossing point and opposite endpoint signed-plane distances. Examples:

|Surface-order triangles|Regions|Interior target barycentrics|Endpoint plane distances|
|---|---|---|---|
|1317 /12858|croup /hind_l|0.3111,0.3763,0.3126|−7.18mm,+14.84mm|
|3150 /7210|withers_shoulder /fore_l|0.4677,0.3095,0.2228|−3.70mm,+0.86mm|
|6246 /22110|nose /nostril_1|0.7889,0.0610,0.1501|−4.88mm,+1.46mm|
|21894 /22120|nostril_1 /itself|0.0865,0.3827,0.5308|+1.56mm,−0.85mm|

Triangle IDs refer to fan triangulation of `static-subdivided-surface.json` in face order; quad face index=triangle_id//2. They are not material-group draw offsets. Vertex IDs are the actualGLB POSITION accessor indices. The source author received exact examples/region mapping. The lateral body-aperture→horizontal limb-root transition and nostril ring embedding must be corrected at source; materials or scene offsets cannot remove the crossings. No further build is authorized by this review.

**Separate contract discrepancy:** controls/node metadata say root is ground under support midpoint. Actual four sole centers average[~0,0,−0.03999996]m while root remains[0,0,0]. Clarify the datum or explicitly recenter authoring and every affected semantic frame in a reviewed revision; do not silently offset only the scene instance. This does not explain or excuse the self-intersections.

Structural/readback checks that did pass:

-11778vertices,11776quads,23552triangles; one11778-vertex connected component;23552edges; Euler characteristic2.
- Every edge has two oppositely directed owners and every actual vertex link is one connected2-regular cycle. No pinched/bow-tie vertex link was found. Shared source regions use actual common vertex IDs, not coincident duplicate seam coordinates.
- ExportedFloat32 POSITION bytes agree with source-surface conversion; exported triangle-index multiset agrees exactly. Positions/normals are finite; normal lengths0.99999994–1.0; minimum triangle area1.71e−7m². One static node, no skins/animations/sockets.
- All four feet have49 actual vertices exactly at y=0. Sole center x/z match declared contacts to about0.1µm. No vertex is below ground. BoundsX±0.3375245,Y0–2.1181772,Z−0.9283290–1.2444565m. Full height includes ears and is not a withers measurement.

The initial bounded screen took10.44s with one math thread and a15s CPU cap; scalar witness follow-ups were below1s and did not repeat the global screen. No exhaustive coplanar-overlap/tangency or photographic/anatomical shape claim follows from these checks. Positive crossings already establish the blocker.

**Verdict: not clear for the ordinary matched-view browser review.** Preserve this first mesh and failure receipt, correct shared-junction/cup embedding, then let root decide one bounded corrected build. Photographic anatomy, hair/PBR, rigging, tack, people and town integration remain unqualified.
