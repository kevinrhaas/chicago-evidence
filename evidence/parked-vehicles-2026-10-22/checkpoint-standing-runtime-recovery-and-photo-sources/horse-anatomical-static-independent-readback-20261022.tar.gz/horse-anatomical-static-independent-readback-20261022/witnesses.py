import pathlib,json,struct,math,collections,time,hashlib,resource
resource.setrlimit(resource.RLIMIT_CPU,(8,8))
import numpy as np
P=pathlib.Path('/workspace/shared/horse-anatomical-static-first-20261022');O=pathlib.Path(__file__).parent;a=json.loads((O/'READBACK.json').read_text());s=json.loads((P/'static-subdivided-surface.json').read_text());V=np.asarray(s['vertices'],dtype='<f4').astype(float);T=[];R=[]
for f,r in zip(s['faces'],s['regions']):
 for k in range(1,len(f)-1):T.append([f[0],f[k],f[k+1]]);R.append(r)
T=np.asarray(T,dtype=int);A=V[T];lo=A.min(1);hi=A.max(1)
def witnesses(i,j):
 # Independent scalar plane-interpolation + Gram-matrix barycentrics, not Moller-Trumbore.
 out=[]
 for source,target,ii,jj in [(A[i],A[j],i,j),(A[j],A[i],j,i)]:
  e0=target[1]-target[0];e1=target[2]-target[0];normal=np.cross(e0,e1);nlen=np.linalg.norm(normal);d00=float(e0@e0);d01=float(e0@e1);d11=float(e1@e1);den=d00*d11-d01*d01
  if abs(den)<1e-22:continue
  for k in range(3):
   p,q=source[k],source[(k+1)%3];dp=float(normal@(p-target[0]));dq=float(normal@(q-target[0]))
   if dp*dq>=0:continue
   t=dp/(dp-dq)
   if not 1e-7<t<1-1e-7:continue
   x=p+t*(q-p);v=x-target[0];d20=float(v@e0);d21=float(v@e1);b=(d11*d20-d01*d21)/den;c=(d00*d21-d01*d20)/den;ba=[1-b-c,b,c]
   if min(ba)>1e-7:
    out.append({'source_triangle':int(ii),'target_triangle':int(jj),'source_edge_vertex_slots':[k,(k+1)%3],'segment_t':t,'target_barycentric':ba,'intersection_point_m':x.tolist(),'target_plane_error_m':abs(float(normal@(x-target[0])))/nlen,'source_edge_endpoint_signed_plane_distances_m':[dp/nlen,dq/nlen]})
 return out
examples={}
for pair in a['proper_intersection_screen']['positive_examples']:
 i,j=pair['triangle_ids'];ws=witnesses(i,j)
 if ws:
  key=tuple(sorted([R[i],R[j]]));score=max(min(w['target_barycentric'])for w in ws)
  if key not in examples or score>examples[key]['robustness_min_barycentric']:
   examples[key]={'surface_order_triangle_ids':[i,j],'surface_quad_face_ids':[i//2,j//2],'regions':[R[i],R[j]],'indices':[T[i].tolist(),T[j].tolist()],'triangle_coordinates_m':[A[i].tolist(),A[j].tolist()],'robustness_min_barycentric':score,'witnesses':ws}
# Add head witnesses without repeating the global intersection pass.
head_candidates=0
for region in ['nostril_1','nostril_-1']:
 aa=np.asarray([i for i,r in enumerate(R)if r==region]);bb=np.asarray([i for i,r in enumerate(R)if r in [region,'nose']]);mask=((lo[aa,None,:]<=hi[bb][None,:,:]+1e-10)&(lo[bb][None,:,:]<=hi[aa,None,:]+1e-10)).all(2);ii,jj=np.where(mask)
 for ai,bj in zip(aa[ii],bb[jj]):
  if ai==bj:continue
  ai,bj=sorted([int(ai),int(bj)])
  head_candidates+=1;key=tuple(sorted([R[ai],R[bj]]))
  if key in examples:continue
  ws=witnesses(ai,bj)
  if ws:examples[key]={'surface_order_triangle_ids':[int(ai),int(bj)],'surface_quad_face_ids':[int(ai)//2,int(bj)//2],'regions':[R[ai],R[bj]],'indices':[T[ai].tolist(),T[bj].tolist()],'triangle_coordinates_m':[A[ai].tolist(),A[bj].tolist()],'robustness_min_barycentric':max(min(w['target_barycentric'])for w in ws),'witnesses':ws}
# One independent witness at each missing fore/body source seam; no repeat global enumeration.
for region in ['fore_l','fore_r']:
 aa=np.asarray([i for i,r in enumerate(R)if r==region and hi[i,1]>.95]);bb=np.asarray([i for i,r in enumerate(R)if r in ['barrel_front','shoulder_rear','withers_shoulder']]);mask=((lo[aa,None,:]<=hi[bb][None,:,:]+1e-10)&(lo[bb][None,:,:]<=hi[aa,None,:]+1e-10)).all(2);ii,jj=np.where(mask)
 for ai,bj in zip(aa[ii],bb[jj]):
  ai,bj=sorted([int(ai),int(bj)]);key=tuple(sorted([R[ai],R[bj]]))
  if key in examples:continue
  ws=witnesses(ai,bj)
  if ws:examples[key]={'surface_order_triangle_ids':[ai,bj],'surface_quad_face_ids':[ai//2,bj//2],'regions':[R[ai],R[bj]],'indices':[T[ai].tolist(),T[bj].tolist()],'triangle_coordinates_m':[A[ai].tolist(),A[bj].tolist()],'robustness_min_barycentric':max(min(w['target_barycentric'])for w in ws),'witnesses':ws}
out={'GLB_sha256':a['GLB_sha256'],'verdict':'FAILED embedded-surface qualification; no ordinary matched-view acceptance preview release','proof_method':'Independent signed-plane edge crossing + scalar Gram barycentrics; proper interior points with strictly opposite endpoint signs','triangle_id_convention':'Fan triangulation of static-subdivided-surface.json face order; surface quad face=triangle_id//2. These are not material-group draw offsets; vertex indices are the actual GLB position accessor indices.','positive_region_pair_examples':list(examples.values()),'head_AABB_pairs_considered':head_candidates,'limits':'Positive witnesses prove actual self-intersection. No conclusion about photographic shape is needed to reject these folds; no new build/browser occurred.'};(O/'PROPER-CROSSING-WITNESSES.json').write_text(json.dumps(out,indent=2)+'\n');print('independentlyconfirmed regionpairs',len(examples));print([(k,x['surface_order_triangle_ids'],x['robustness_min_barycentric'])for k,x in examples.items()])
