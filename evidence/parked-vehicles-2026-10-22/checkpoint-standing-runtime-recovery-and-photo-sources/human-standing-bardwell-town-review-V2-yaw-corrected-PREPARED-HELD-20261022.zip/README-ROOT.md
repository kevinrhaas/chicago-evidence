# Actual Bardwell town caller V2 — corrected source, held before first browser

Use this directory's capture_town.cjs/browser_review.cjs for the first released run. The original held directory and ZIP remain unchanged. TICKET-AND-API-REVIEW.md gives the exact ticket mapping, concrete two-defect diagnosis and remaining runtime risks; FINITE-SOURCE-REVIEW.json records actual production walker/bearing/LOD controls and clean-guard cases. This is source/CPU preparation, not a browser result.

Only two behavioral corrections: route yaw now imports/uses production angles.js bearingToYaw; clean() now requires both unstaged AND staged clean. V2 additionally pins the new imported angles.js mirror and uses a distinct receipt identity. Original route points, cameras, normal materials/actor/pose, union-independent actual framing, sole tolerances, assets, budgets, 4 captures per viewport, 540 s cap and no-retry policy are unchanged.

Root release remains required after the current frozen full gate and any browser lane have CLOSED, final commit/push/source publication checks and exact HEAD/index reconciliation. The legacy release flag gate79092_closed now means the current coordinated heavy lane is closed; setting it for an older completed gate while another heavy lane runs is not authorization. RELEASE-HELD.json stays released:false with null source/output/viewport. No automatic launch.

Root fills one immutable final release JSON per viewport, with released:true, gate79092_closed:true, actual final 40-hex expectedHead, SHA256 of raw `git ls-files --stage` output as expectedIndexDigest, desktop/mobile, a new outside-app output and unchanged maxMillis540000. Then run exactly one foreground viewport command at a time on the free lane:

```sh
PW_EXECUTABLE=/usr/bin/chromium node /workspace/shared/human-standing-bardwell-town-review-V2-yaw-corrected-PREPARED-HELD-20261022/capture_town.cjs /workspace/shared/FINAL-BARDWELL-TOWN-DESKTOP.json > /workspace/shared/bardwell-town-desktop.log 2>&1
PW_EXECUTABLE=/usr/bin/chromium node /workspace/shared/human-standing-bardwell-town-review-V2-yaw-corrected-PREPARED-HELD-20261022/capture_town.cjs /workspace/shared/FINAL-BARDWELL-TOWN-MOBILE.json > /workspace/shared/bardwell-town-mobile.log 2>&1
```

The caller is read-only to app/Git/index/site/CI and reconciles all pinned bytes on closure. It serves the actual published site and checks exact qualified canonical GLBs; it does not publish/copy/rebuild them. First-run failures must preserve receipt/logs and stop. Root must inspect actual desktop/mobile normal front/profile/quarter and resident card images before accepting this initial visible increment. T-1789 and all broader people/photo scopes remain open; no Mark ticket can close on Bardwell.

Finite controls can be repeated without browser with `node verify_corrections.mjs`; they ran once and passed. They use the production walker on an explicitly flat/no-obstacle fixture and production chooseHumanLod, not a fake actual-yard proof. Syntax checks passed for both callers. No app edit, browser/server, Git mutation, ticket write, CI action, or canonical/ref movement occurred.

Applicable normal published coverage remains all15parts at both widths (18 nightly legs) for the standing scene/smoke changes; saved existing pricing is included. No budgets or workflows changed in this caller correction. Reprice the final integrated diff with existing smoke_budget before the root-owned normal runs.
