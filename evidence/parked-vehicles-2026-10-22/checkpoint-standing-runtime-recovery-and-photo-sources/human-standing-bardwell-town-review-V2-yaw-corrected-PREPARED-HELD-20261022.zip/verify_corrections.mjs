// Finite CPU/source regression controls. No browser, GLB parsing, app write or Git mutation.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { register } from 'node:module';
import { fileURLToPath } from 'node:url';
const here=new URL('.',import.meta.url),runtime=new URL('file:///workspace/chicago/chicago/4d/renderers/web/js/'),vendor=new URL('../vendor/three-0.185.1/',runtime).href;
register(`data:text/javascript,${encodeURIComponent(`export function resolve(s,c,next){if(s==='three')return{url:'${vendor}three.module.js',shortCircuit:true};if(s.startsWith('three/addons/'))return{url:'${vendor}addons/'+s.slice(13),shortCircuit:true};return next(s,c);}`)}`,import.meta.url);
const THREE=await import('three'),{bearingToYaw}=await import(new URL('angles.js',runtime)),{createWalker,WALK}=await import(new URL('walker.js',runtime));
const caller=fs.readFileSync(new URL('browser_review.cjs',here),'utf8'),capture=fs.readFileSync(new URL('capture_town.cjs',here),'utf8'),oldCaller=fs.readFileSync(new URL('original-callers/browser_review.cjs',here),'utf8'),oldCapture=fs.readFileSync(new URL('original-callers/capture_town.cjs',here),'utf8');
assert(caller.includes("{bearingToYaw}=await import(new URL('js/angles.js',document.baseURI).href)"));
assert(caller.includes('const yaw=bearingToYaw(bearing);a.walker.state.yaw=yaw;'));
assert(!caller.includes('Math.PI-bearing*Math.PI/180'));
assert(capture.includes("'travel-settings.js','angles.js'"));
// Use the actual production createWalker and actual bearing conversion. Flat,
// obstacle-free fixture isolates directional regression; it is NOT yard/terrain
// route acceptance. No source constants or camera coordinates are changed.
const flat={walkHeight:()=>0,surfaceHeight:()=>0,isWater:()=>false};
const points=[[-86.5,-33.1],[-88,-34.2],[-94,-34.2],[-91.85,-36.5],[-92.1,-34.6]],segments=points.slice(1).map((p,i)=>[points[i],p]),rows=[];
for(const [from,target] of segments){
 const de=target[0]-from[0],dn=target[1]-from[1],bearing=Math.atan2(de,dn)*180/Math.PI,distance=Math.hypot(de,dn),dt=Math.min(.10,distance/WALK.speed);
 const run=yaw=>{const w=createWalker({camera:new THREE.PerspectiveCamera(),terrain:flat,spawn:{local_e:from[0],local_n:from[1]}});w.state.yaw=yaw;w.update(dt,{forward:1,strafe:0,sprint:false,flying:false,yawDelta:0,pitchDelta:0,clearLook(){}});return{end:w.enu,miss:Math.hypot(w.enu.e-target[0],w.enu.n-target[1])};};
 const positive=run(bearingToYaw(bearing)),negative=run(Math.PI-bearing*Math.PI/180);
 assert(positive.miss<distance,'production yaw must approach target');assert(negative.miss>distance,'old human-heading yaw must move away');
 rows.push({from,target,initial_miss_m:distance,positive,negative});
}
// Exercise actual production walker for the whole planned route in the same
// declared flat fixture, retaining original loop/step/miss guards.
const walker=createWalker({camera:new THREE.PerspectiveCamera(),terrain:flat,spawn:{local_e:points[0][0],local_n:points[0][1]}}),fullRoute=[];
for(const[e,n]of points.slice(1)){let steps=0;while(Math.hypot(walker.enu.e-e,walker.enu.n-n)>.025&&steps++<160){const now=walker.enu,de=e-now.e,dn=n-now.n,bearing=Math.atan2(de,dn)*180/Math.PI;walker.state.yaw=bearingToYaw(bearing);walker.update(Math.min(.10,Math.hypot(de,dn)/WALK.speed),{forward:1,strafe:0,sprint:false,flying:false,yawDelta:0,pitchDelta:0,clearLook(){}});}const miss=Math.hypot(walker.enu.e-e,walker.enu.n-n);assert(miss<.05);fullRoute.push({target:[e,n],actual:walker.enu,steps,miss_m:miss});}
// Execute clean() source itself with explicit process-return controls. No Git
// process is launched. Old guard must miss staged-only dirt; corrected guard must
// reject either dirty side and process failure, at start and reconciliation.
const getClean=src=>src.match(/clean=(\(\)=>[^;]+);/)[1];
function guard(src,unstaged,staged){const calls=[];const fn=vm.runInNewContext(getClean(src),{repo:'/unused',process:{env:{}},spawnSync:(name,args)=>{calls.push(args);return{status:args.includes('--cached')?staged:unstaged};}});return{value:fn(),calls};}
const cleanCases=[];
for(const[u,s,want]of [[0,0,true],[1,0,false],[0,1,false],[1,1,false],[0,null,false]]){const got=guard(capture,u,s);assert.equal(got.value,want);cleanCases.push({unstaged_status:u,staged_status:s,expected:want,...got});}
assert.equal(guard(oldCapture,0,1).value,true,'original staged-only regression control');
assert.equal((capture.match(/clean\(\)/g)||[]).length,2,'both entry and final reconciliation call corrected clean()');
const scene=JSON.parse(fs.readFileSync('/workspace/chicago/chicago/4d/data/scenes/1835.json','utf8')),anchor=scene.anchors.find(x=>x.id==='lake_at_canal'),farDistance=Math.hypot(anchor.local_e+94,anchor.local_n+36.5);
const{chooseHumanLod}=await import(new URL('humans.js',runtime));
assert.equal(chooseHumanLod(farDistance,'full',0,{policy:'auto'}),3);assert.equal(chooseHumanLod(farDistance,'light',2,{policy:'auto'}),3);
const report={status:'FINITE_CPU_AND_STATIC_PASS_NO_BROWSER',production_modules:{bearing:'angles.js bearingToYaw',walker:'walker.js createWalker/update',lod:'humans.js chooseHumanLod'},scope:'Production yaw/walker on a declared flat no-obstacle fixture; actual yard route, camera framing, ground contact, loader/card and performance remain unrun.',directional_positive_negative_controls:rows,planned_route_flat_control:fullRoute,clean_guard_truth_table:cleanCases,far_anchor_static:{anchor,plan_distance_m:farDistance,full_lod:3,light_lod:3},original_held_caller_immutable:true};
fs.writeFileSync(new URL('FINITE-SOURCE-REVIEW.json',here),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({pass:true,directional_controls:rows.length,route_segments:fullRoute.length,clean_cases:cleanCases.length,farDistance}));
