// Evaluated only inside the actual published town after explicit root release.
module.exports = async function installBardwellReview({ expectedId, expectedPerson, expectedAsset, viewport }) {
  const a=window.__chicago4d,actor=a.humans?.get(expectedId),must=(v,s)=>{if(!v)throw Error(s);};
  must(a.ready&&a.scene.id==='1835'&&a.sceneLayers.includes('humans'),'actual1835 human layer not ready');
  must(a.humans.count===1&&a.humans.records.length===1&&!a.humans.refused.length&&!a.humans.withheld.length,'exactly one eligible human required');
  must(actor&&actor.personId===expectedPerson&&actor.identity.kind==='person'&&actor.person?.grade==='reconstructed'&&actor.instance.appearance.asset_id===expectedAsset,'actual resident/asset binding differs');
  must(actor.e===-94&&actor.n===-36.5&&actor.heading===90&&actor.state==='standing'&&actor.instance.animation.clip==='idle'&&actor.instance.lod.policy==='auto','exact standing instance differs');
  const T=await import('three'),{WALK}=await import(new URL('js/travel-settings.js',document.baseURI).href),originalRoot=actor.root.position.toArray(),initialInstance=JSON.stringify(actor.instance),draws={},hooks=new Map();
  const cameras={front:{local_e:-91.85,local_n:-36.5,yaw_deg:270,pitch_deg:-17.3},profile:{local_e:-94,local_n:-34.2,yaw_deg:180,pitch_deg:-16.3},quarter:{local_e:-92.1,local_n:-34.6,yaw_deg:225,pitch_deg:-14.0}};
  const pause=ms=>new Promise(r=>setTimeout(r,ms));
  async function waitForBody(lod){const end=performance.now()+90000;while(performance.now()<end){if(actor.body&&actor.lod===lod&&!actor.pending)return;await pause(100);}throw Error('actual autoLOD '+lod+' did not settle');}
  // pending is cleared to null by HumanActor after its awaited load; no body/pose is replaced here.
  function instrument(){for(const mesh of actor.body.meshes)if(!hooks.has(mesh)){const prior=mesh.onAfterRender;hooks.set(mesh,prior);draws[mesh.uuid]=0;mesh.onAfterRender=function(...args){draws[mesh.uuid]++;prior?.apply(this,args);};}}
  function vertex(mesh,i,out){mesh.getVertexPosition(i,out);return out.applyMatrix4(mesh.matrixWorld);}
  function snapshot({framing=true}={}){
    must(JSON.stringify(actor.instance)===initialInstance&&actor.root.position.toArray().every((v,i)=>v===originalRoot[i]),'instance or actor root translated');
    must(actor.root.visible&&actor.body&&actor.body.meshes.every(m=>m.frustumCulled===false),'actual production skinned culling policy differs');
    actor.root.updateMatrixWorld(true);for(const m of actor.body.meshes)m.skeleton.update();a.camera.updateMatrixWorld(true);
    const p=new T.Vector3(),projected=new T.Vector3(),bounds=new T.Box3(),ndc={min:[Infinity,Infinity,Infinity],max:[-Infinity,-Infinity,-Infinity]},shoes={left:[],right:[]};let vertices=0;
    for(const m of actor.body.meshes){const pos=m.geometry.getAttribute('position'),footwear=/closed_shoes|footwear/.test(m.name+' '+[].concat(m.material).map(v=>v.name).join(' '));
      const skinIndex=m.geometry.getAttribute('skinIndex'),skinWeight=m.geometry.getAttribute('skinWeight');
      for(let i=0;i<pos.count;i++){vertex(m,i,p);must([p.x,p.y,p.z].every(Number.isFinite),'nonfinite posed vertex');bounds.expandByPoint(p);projected.copy(p).project(a.camera);for(let k=0;k<3;k++){ndc.min[k]=Math.min(ndc.min[k],projected.getComponent(k));ndc.max[k]=Math.max(ndc.max[k],projected.getComponent(k));}vertices++;
        if(footwear){let left=0,right=0;for(let lane=0;lane<4;lane++){const bone=m.skeleton.bones[skinIndex.getComponent(i,lane)]?.name||'',w=skinWeight.getComponent(i,lane);if(/^(foot|ball)_l$/.test(bone))left+=w;if(/^(foot|ball)_r$/.test(bone))right+=w;}const side=left>.9?'left':right>.9?'right':null;must(side,'actual shoe has ambiguous foot ownership');shoes[side].push({x:p.x,y:p.y,z:p.z,mesh:m.name,index:i});}
      }
    }
    if(framing)must(ndc.min[0]>=-.8&&ndc.max[0]<=.8&&ndc.min[1]>=-.8&&ndc.max[1]<=.8&&ndc.min[2]>=-1&&ndc.max[2]<=1,'posed full figure outside10% canvas padding: '+JSON.stringify(ndc));
    const sole={};for(const side of ['left','right']){must(shoes[side].length>0,'missing actual '+side+' shoe vertices');const min=Math.min(...shoes[side].map(p=>p.y)),selected=shoes[side].filter(p=>p.y<=min+.0001),errors=selected.map(p=>p.y-a.terrain.surfaceHeight(p.x,-p.z));must(selected.length>=3,'too few actual sole vertices');must(Math.min(...errors)>=-.002&&Math.max(...errors)<=.002,'actual standing soles exceed unchanged2mm against local terrain');sole[side]={selected:selected.length,minimum_error_m:Math.min(...errors),maximum_error_m:Math.max(...errors),tolerance_m:.002};}
    const gl_error=a.renderer.getContext().getError();must(gl_error===0,'actual WebGL error '+gl_error);const stats=a.stats(),tier=a.detail;must(stats.budget.drawCalls===7800,'existing driver draw budget changed');must(stats.triangles<=stats.budget.triangles&&stats.drawCalls<=stats.budget.drawCalls,'actual local stand over existing public budget');if(tier==='light')must(stats.drawCalls<=5900,'actual light stand over existing5900 driver-draw cap');
    const shoeMeshes=actor.body.meshes.filter(m=>/closed_shoes|footwear/.test(m.name+' '+[].concat(m.material).map(v=>v.name).join(' ')));
    const rendered=shoeMeshes.map(m=>({name:m.name,frustumCulled:m.frustumCulled,actual_render_count:draws[m.uuid]||0}));if(framing)must(rendered.length&&rendered.every(m=>m.actual_render_count>0),'actual shoe was not rendered');
    const skeleton=actor.body.meshes[0].skeleton;
    return {instance_id:actor.id,person_id:actor.personId,asset:expectedAsset,detail:tier,lod:actor.lod,clip:actor.clipName,root:actor.root.position.toArray(),root_heading:actor.root.rotation.y,camera:{position:a.camera.position.toArray(),quaternion:a.camera.quaternion.toArray(),fov:a.camera.fov,projection:a.camera.projectionMatrix.toArray(),flying:a.walker.state.flying,walker:a.walker.enu},posed_world_bounds:{min:bounds.min.toArray(),max:bounds.max.toArray()},posed_all_vertex_count:vertices,projected_bounds:ndc,canvas_padding:.1,sole,shoe_rendered:rendered,bones:skeleton.bones.map(b=>({name:b.name,matrixWorld:b.matrixWorld.toArray()})),stats,gl_error};
  }
  async function settle(){await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));a.step();}
  async function routeTo(name){
    const target=cameras[name];must(target,'unknown fixed camera');a.setFly(false);
    // Actual walker.update uses production wall/step/deck collision; render is never held.
    const from=a.walker.enu,route=name==='profile'?[[-86.5,-33.1],[-88,-34.2],[-94,-34.2]]:[[target.local_e,target.local_n]],rows=[];
    if(name==='profile')a.walker.teleport({local_e:route[0][0],local_n:route[0][1],yaw_deg:270});
    for(const [e,n] of route){let steps=0;while(Math.hypot(a.walker.enu.e-e,a.walker.enu.n-n)>.025&&steps++<160){const now=a.walker.enu,de=e-now.e,dn=n-now.n,bearing=Math.atan2(de,dn)*180/Math.PI;const yaw=Math.PI-bearing*Math.PI/180;a.walker.state.yaw=yaw;const speed=WALK.speed,dt=Math.min(.10,Math.hypot(de,dn)/speed);a.walker.update(dt,{forward:1,strafe:0,sprint:false,flying:false,yawDelta:0,pitchDelta:0,clearLook(){}});}
      const got=a.walker.enu,miss=Math.hypot(got.e-e,got.n-n);must(miss<.05,'production walker could not reach camera route point');rows.push({target:[e,n],actual:got,steps,miss_m:miss,blocked:a.walker.state.blocked});}
    a.walker.teleport(target);must(!a.walker.state.flying&&!a.terrain.isWater(target.local_e,target.local_n),'review camera is not on reachable dry ground');await settle();await waitForBody(viewport==='desktop'?0:2);instrument();await settle();
    return {name,route_start:from,route:rows,state:snapshot()};
  }
  window.__bardwellTownReview={cameras,initial:{root:originalRoot,instance:JSON.parse(initialInstance)},view:routeTo,snapshot,
    async card(){const hit=a.humans.select(expectedId);must(hit?.personId===expectedPerson,'production selection does not bind Bardwell');const end=performance.now()+60000;while(performance.now()<end&&(a.people?.state?.open!==expectedPerson||document.querySelector('#people-card .people-card-body')?.getAttribute('aria-busy')==='true'))await pause(100);must(a.people?.state?.open===expectedPerson,'own resident card did not open');const el=document.getElementById('people-card');must(el&&!el.hidden&&el.innerText.includes('Otis Bardwell')&&!el.querySelector('[aria-busy=true]'),'wrong or unfinished actual resident card');return {state:a.people.state,text:el.innerText};},
    closeCard(){a.people?.close();a.hud.setPanel(false);document.getElementById('nav-grip')?.blur();},
    async loader(){const rows=[];for(let lod=0;lod<4;lod++){const gltf=await a.humans.assets.acquire(expectedAsset,lod);try{const meshes=[];gltf.scene.traverse(m=>{if(m.isSkinnedMesh)meshes.push(m);});must(meshes.length===9&&meshes.every(m=>m.skeleton.bones.length===56),'actual production loader mesh/rig count differs');must(['idle','walk','sit_drive'].every(n=>gltf.animations.some(c=>c.name===n)),'actual loaded clips incomplete');rows.push({lod,meshes:meshes.length,bone_counts:meshes.map(m=>m.skeleton.bones.length),clips:gltf.animations.map(c=>c.name),url:a.humans.assets.url(expectedAsset,lod).href});}finally{a.humans.assets.release(expectedAsset,lod);}}return rows;},
    async far(){must(a.goTo('lake_at_canal'),'existing reachable far anchor missing');await settle();await waitForBody(3);instrument();await settle();must(actor.distance>45&&actor.distance<140,'actual far anchor does not exercise LOD3');return {anchor:'lake_at_canal',distance:actor.distance,costs:actor.costsNow,state:snapshot({framing:false})};},
    async timing(){const times=[];for(let i=0;i<8;i++)await new Promise(r=>requestAnimationFrame(t=>{times.push(t);r();}));const ms=times.slice(1).map((t,i)=>t-times[i]).sort((a,b)=>a-b);return {scope:'Normal-loop rAF intervals on this software renderer; diagnostic only, no phone/GPU or moving-flora gate claim.',samples:ms.length,p50_ms:ms[Math.floor(ms.length*.5)],p95_ms:ms[Math.floor(ms.length*.95)],max_ms:ms.at(-1)};},
    restoreHooks(){for(const [mesh,prior] of hooks)mesh.onAfterRender=prior;}
  };
  return {instance:actor.instance,person:actor.person,policy:actor.instance.lod,cameras,initial_root:originalRoot};
};
