# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import datetime,hashlib,json,tarfile
D=Path(__file__).resolve().parent
assert json.loads((D/'INTEGRATION-AUDIT.json').read_text())['PASS']
status={'state':'FROZEN_SOURCE_INTEGRATION_PROPOSAL_UNAPPLIED','base':'2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3','V5_capsule_sha256':'c26f48fbd71cf716fea6fcb4e9e90e6c326183aec3dcff77aaa78291448a07ce','V6_capsule_sha256':'e29b619590e9e0c6f2644204d4ddaf22a61fce33c8424da5033ad4b59405965b','V6_actual_source_preview_zip_sha256':'8713e2efb9d5e44d5dc224168a1e95794d9d1c16ef14fe41c5086a7b83decd0f','patch_files':2,'metadata_literal_corrections_beyond_reviewed_source':2,'all_three_existing_finite_source_replays_PASS':True,'app_git_index_mirror_ci_browser_actions':False,'canonical_fullfit_photographic_or_world_accepted':False,'inherited_idle_negative_source_face_projections_OPEN':40,'broad_shoe_source_FAIL_interpretation':'superseded: historical V2 stale preview-sphere culling; full seated enclosure remains unaccepted','frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(D/'FREEZE-STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
files=[p for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ('CAPSULE-MANIFEST.json','MANIFEST.sha256')]
manifest={'state':status['state'],'files':[{'path':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]};(D/'CAPSULE-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');(D/'MANIFEST.sha256').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in manifest['files'])+hashlib.sha256((D/'CAPSULE-MANIFEST.json').read_bytes()).hexdigest()+'  CAPSULE-MANIFEST.json\n')
archive=D.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as tar:tar.add(D,arcname=D.name)
sha=hashlib.sha256(archive.read_bytes()).hexdigest();archive.with_suffix(archive.suffix+'.sha256').write_text(sha+'  '+archive.name+'\n')
for r in manifest['files']:assert hashlib.sha256((D/r['path']).read_bytes()).hexdigest()==r['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha,'files_verified':len(files),'patch_sha256':hashlib.sha256((D/'V5-V6-INTEGRATION-AGAINST-2f75.patch').read_bytes()).hexdigest()},indent=2))
