# Actual V5 versus V6 hem source preview — fit/photo OPEN

The one released run completed24original captures with0errors, all actual-vertex framing and shoe-render guards passing. Browser/server closed at2026-10-22T00:48:44.599322Z. Before/after camera values and all bone frames match within every paired pose/view/viewport.

Both variants are source-array garments on the same actual V4 canonical body/rig: before=V5trousers+V5waistcoat; after=exact frozen V6trousers+the SAME V5waistcoat. Neither garment variant is canonical. Only the already-frozen level hem trim differs; no new geometry was generated for this review.

Eight independently inspected full PNGs show V6 removes the standing V5 sawtooth cuff outline and gives shorter/cleaner seated edges. Brown shoes remain visible. Complete ankle enclosure, finished cuffs/thickness, motion clearance and full garment/footwear fit remain unaccepted. Tight/crude shirt/sleeves, fuller seat/thigh drape, lapels/buttons, cloth materials/finishing and photographic quality remain open.

immutable-actual-V6-preview/ contains ALL24actual PNG bytes, full actual runtime/framing/bone/draw receipts, exact baseline GLB/vendor/source V5 and V6 arrays, caller, release/intent, source manifests, frozen source controls and finite UV/weight compatibility checks. Historical PREPARED documents inside are preserved inputs; actual status is documented here and in the runtime receipt. No runtime dependencies were installed or duplicated.

V5/V6 remain unapplied and canonically unqualified. Normal/sole requalification, period/photographic/world/occupied acceptance and T1789 remain OPEN;40inherited negative projections remain OPEN. The earlier whole-shoe disappearance remains a preserved historical V2 preview-culling defect, not a V6 geometry repair. No new browser, geometry, app, Git or CI action occurred during this freeze.

## Independently inspected actual images

- [1280-v5-before-idle-front.png](immutable-actual-V6-preview/1280-v5-before-idle-front.png)
- [1280-v6-after-idle-front.png](immutable-actual-V6-preview/1280-v6-after-idle-front.png)
- [1280-v5-before-idle-profile.png](immutable-actual-V6-preview/1280-v5-before-idle-profile.png)
- [1280-v6-after-idle-profile.png](immutable-actual-V6-preview/1280-v6-after-idle-profile.png)
- [1280-v5-before-sit_drive-quarter.png](immutable-actual-V6-preview/1280-v5-before-sit_drive-quarter.png)
- [1280-v6-after-sit_drive-quarter.png](immutable-actual-V6-preview/1280-v6-after-sit_drive-quarter.png)
- [390-v5-before-sit_drive-profile.png](immutable-actual-V6-preview/390-v5-before-sit_drive-profile.png)
- [390-v6-after-sit_drive-profile.png](immutable-actual-V6-preview/390-v6-after-sit_drive-profile.png)

Root planned three separate views, listed in INDEPENDENT-READONLY-PIXEL-REVIEW.json. This independent review does not claim those were inspected; remaining images are technically preserved rather than visually accepted.
