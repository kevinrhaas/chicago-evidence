# SPDX-License-Identifier: GPL-3.0-or-later
"""Run the existing small source-control packet, sequentially outside the app."""
from pathlib import Path
import json,os,subprocess,sys
D=Path(__file__).resolve().parent
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
for script,output in [('v5_finite_controls.py','V5-FINITE-SOURCE-CONTROLS.stdout.json'),('v5_supplemental_controls.py','V5-SUPPLEMENTAL-SOURCE-CONTROLS.stdout.json'),('v6_finite_controls.py','V6-FINITE-SOURCE-CONTROLS.stdout.json'),('integration_audit.py','INTEGRATION-AUDIT.stdout.json')]:
 with (D/output).open('w') as stream:subprocess.run([sys.executable,str(D/script)],check=True,cwd=D,env=env,stdout=stream)
print(json.dumps({'PASS':True,'scope':'Source-only existing finite controls and temporary-preimage patch audit; no full gate, BPy, browser or CI'},indent=2))
