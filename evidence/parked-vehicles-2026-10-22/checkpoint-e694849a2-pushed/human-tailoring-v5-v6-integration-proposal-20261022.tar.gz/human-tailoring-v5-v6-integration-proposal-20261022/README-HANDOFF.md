# V5 + V6 canonical source integration proposal

A two-file source patch against exact pushed human baseline `2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3`. It combines the reviewed fuller V5 lower trousers and closed lower waistcoat with the reviewed V6 level cuff trim. The canonical builder already imports this helper and supplies this recipe, so it needs no wiring change. This proposal is entirely outside the application and has not been applied, committed, mirrored, exported or sent to CI.

## Apply scope

`V5-V6-INTEGRATION-AGAINST-2f75.patch` changes only:

| Source | Exact preimage SHA-256 | Proposed SHA-256 |
|---|---|---|
| `chicago/4d/tools/human_workwear_fit.py` | `3e04cba04ac654f5cf94535938c8736101a99e694ab2b0cb6f066fab522cb612` | `89428acdb85b7ba8ed126babb95ecb3eea7f33110cb51b6637164f231375de48` |
| `chicago/4d/data/humans/recipes/worker_1835.json` | `4e79cf2c6dd6a21d1c1e987533778b2578533c4dc57caf2df01d6de19d2354e0` | `45d4b4e5686cf9f6bd5a10d2cdc1aec9d3404c203923fa78f439e254527045ee` |

Patch SHA-256: `b95efacb541e6a5026228091c9dfd22bee1655b277a92a3ca2786cc385822a74`.

`preimages/` contains the exact saved Git-object originals and `proposed/` the replacements. Twelve canonical builder, eye/normal helper, exporter and 1812/1904 opt-in source/manifest paths are pinned under `audit-preimages/` only. None appears in the patch. All original recipe keys, identity variants and grades, body/skin/rig references, colors/material parameters, sources, default recipe/era paths and export flags remain exact baseline. No new test or gate tool is proposed inside the app.

The patch preserves all existing helper function ASTs except `garment_shell`; adds the same three reviewed top-level pure helpers; and leaves shoe/collar/clip calculations and normal/sole guards unchanged. V6 clips only the narrow jagged ankle band at the highest existing cuff-cycle point, retaining V5 geometry and breadth above that trim. It is a shortening of the low parts, not an invented historical measurement. Original body/skin/UV/source identity, rig, materials and pose/root frame are untouched. There is no mask or guard waiver.

## Review lineage and truthful metadata

- Reviewed V5 source capsule: `c26f48fbd71cf716fea6fcb4e9e90e6c326183aec3dcff77aaa78291448a07ce`.
- Reviewed V6 source capsule: `e29b619590e9e0c6f2644204d4ddaf22a61fce33c8424da5033ad4b59405965b`.
- Actual V6 source-array preview ZIP: `8713e2efb9d5e44d5dc224168a1e95794d9d1c16ef14fe41c5086a7b83decd0f`;24 captures,0 errors, actual-vertex framing/shoe-render guards PASS; root3 + peer8 full images inspected. Its existing receipt/review is included; this task launched no browser and claims no additional pixel inspection.

The proposed source contains two explicitly disclosed metadata corrections beyond the reviewed V5/V6 originals: one V6 receipt scope literal and the V5 recipe status literal. They record the actual source-preview hem technical PASS and canonical/full-fit/photo work still pending. They also correct the earlier broad shoe-source failure interpretation: historical whole-shoe disappearance was V2 stale preview-sphere culling, corrected in actual V3/V6 preview; production already uses `frustumCulled=false`. **No shoe geometry or runtime culling change is included here. Complete seated footwear enclosure remains unaccepted.**

`lineage/` retains the exact reviewed producer, recipe and both V6 arrays with hashes. `METADATA-CORRECTIONS.json` lists the only string replacements. `INTEGRATION-AUDIT.json` proves the proposed helper is byte-exact reviewed V6 after precisely that one string replacement, the recipe equals reviewed V5 after precisely its status replacement, and both newly constructed arrays equal the frozen reviewed V6 arrays after precisely that receipt replacement. Geometry/UV/skin/rig calculations and arrays are exact reviewed content. Older copied reports retain their historical wording; these explicit corrections supersede it without changing that evidence.

## Finite verification

All three existing finite source controls were redirected to the pinned inputs and proposed source and passed sequentially at nice15 with one-thread settings (about28 seconds total while the primary gate had priority):

- V5 original finite controls:96 deterministic leg source-face samples per age; separated lower-leg envelopes; existing source weights/UV/barycentrics; actually closed vest seam and preserved UV/skin lanes.
- V5 supplemental controls: same-body/rig/identity immutability, unchanged shirt arrays,32 newly closed waistcoat-front source faces per age and actual limb support sections.
- V6 finite controls: exact upper V5 geometry/faces; two level closed cuff perimeter cycles per age; finite normalized skin/barycentric/UV data; source-edge cut orientation and source-normal projection range; three adversarial input refusals. All four existing shoe LOD arrays remain exact. Newly cut corner signed projections remain positive, minimum23.44/24.71mm for ages25/35. Those are affected-source-face checks, not a collision/enclosure proof.

The integration audit also dry-ran and applied the two-file patch only to temporary exact preimages and reproduced the proposed source byte-for-byte. It confirms the existing canonical builder directly calls `garment_shell(m,kind,offset,recipe,bones,height,scale)` and preserves its default1835 recipe path. There is no new full gate, pose sweep, install, BPy, canonical master/export, browser/server, app/index/Git/mirror or CI action.

For a self-contained replay, extract/copy this packet to a disposable external directory, then run:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 nice -n 15 python run_finite_controls.py
```

The replay writes reports/arrays only inside that copied packet. It does not run the full application gate.

## Root integration directions and limitations

Root remains the sole tracked writer. Before applying, compare the two target files to the exact preimage hashes above; preserve intervening changes if they differ. From the repository root, inspect then apply the absolute patch path:

```sh
git apply --check /workspace/shared/human-tailoring-v5-v6-integration-proposal-20261022/V5-V6-INTEGRATION-AGAINST-2f75.patch
git apply /workspace/shared/human-tailoring-v5-v6-integration-proposal-20261022/V5-V6-INTEGRATION-AGAINST-2f75.patch
```

Only root should execute those application mutations. Compare the resulting two SHA-256 values to the proposed hashes. Root owns later changelog/docs/ticket handling and required gates; no earlier gate on a different tree qualifies these new source changes. The combined source still needs canonical master/export and normal/sole requalification. Existing canonical run39687040336 remains V4 evidence, not V5/V6 qualification.

**Forty inherited idle negative source-face projections remain OPEN.** Full clothing/footwear enclosure, animated clearance, decimated LOD fit, finished cuffs/thickness, upper seat/thigh/sleeves, buttons/lapels/cloth materials, period-complete and photographic quality, occupied/world acceptance and the parent people ticket remain open. Actual source-array preview PASS is limited to its captured views and unchanged source arrays. Historical references remain analogy; no exact historical garment measurements or named-person likeness are claimed.
