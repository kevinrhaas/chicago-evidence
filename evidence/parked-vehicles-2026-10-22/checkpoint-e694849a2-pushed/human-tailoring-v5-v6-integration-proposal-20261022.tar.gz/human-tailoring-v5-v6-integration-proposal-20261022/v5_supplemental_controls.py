"""One finite static source pass, using only the capsule's pinned inputs.

No renderer, body mask, pose loop, exhaustive face sweep or acceptance waiver.
"""
from pathlib import Path
import ast,hashlib,importlib.util,json,math,sys,time
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D/'inputs/chicago/4d/tools'))
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out);return out
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def sourcepos(basis,lookup):return [math.fsum(v*lookup[int(i)][k] for i,v in basis.items()) for k in range(3)]
old=module('pinned_fit',D/'preimages/chicago/4d/tools/human_workwear_fit.py')
new=module('proposed_fit',D/'reference-v5/chicago/4d/tools/human_workwear_fit.py')
r=json.loads((D/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text())
report={'scope':'Finite static body-preservation, unchanged shirt, newly closed front and real limb-envelope controls only','canonical_39687040336_tests_v5':False,'complete_fit_accepted':False,'photographic_accepted':False,'ages':[],'inherited_negatives':{'idle0_negative_source_face_projections':40,'status':'OPEN, inherited from V4; not reevaluated by this finite static pass','provenance':'inherited-evidence/V4-RELEASE-ACTIVE-PLAN.json'},'new_negative_controls':[]}
start=time.monotonic()
for age in (25,35):
 path=D/f'inputs/chicago/4d/assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json';body=json.loads(path.read_bytes());initial=digest(body)
 m=body['meshes'][0];bones={b['name']:b for b in body['skeleton']};lookup=dict(zip(m['source_vertex_indices'],m['positions_m']));height=max(p[1] for p in m['positions_m']);scale=r['height_scale']
 shirt_old=old.garment_shell(m,'shirt',r['shirt_offset_m'],r,bones,height*scale,scale);shirt_new=new.garment_shell(m,'shirt',r['shirt_offset_m'],r,bones,height*scale,scale)
 # V5 adds metadata fields, so compare actual geometry/skin/UV/source identity.
 for key in shirt_old:
  if key!='receipt':assert shirt_old[key]==shirt_new[key],('shirt changed',age,key)
 vest=new.garment_shell(m,'waistcoat',r['waistcoat_offset_m'],r,bones,height*scale,scale)
 origins=[sourcepos(b,lookup) for b in vest['source_basis']];closure=vest['receipt']['waistcoat_front_closure_y_m'];lower=r['waist_height_fraction']*height-.04
 # Independent source triangles touching the actual newly closed centre seam.
 candidates=[(i,fi) for i,(face,fi) in enumerate(zip(vest['triangles'],vest['source_triangle_indices'])) if any(abs(origins[v][0])<1e-12 and origins[v][2]>0 and lower+1e-8<origins[v][1]<closure-1e-8 for v in face)]
 assert candidates
 selected=[candidates[round(i*(len(candidates)-1)/min(31,len(candidates)-1))] for i in range(min(32,len(candidates)))] if len(candidates)>1 else candidates
 samples=[]
 for garment_face,fi in selected:
  f=m['triangles'][fi];p=[m['positions_m'][v] for v in f];n=cross([p[1][k]-p[0][k] for k in range(3)],[p[2][k]-p[0][k] for k in range(3)]);n=[v/math.hypot(*n) for v in n]
  values=[sum((vest['positions_m'][v][k]-origins[v][k])*n[k] for k in range(3)) for v in vest['triangles'][garment_face]]
  samples.append({'source_face':fi,'garment_face':garment_face,'minimum_incident_source_normal_projection_m':min(values)})
 negative=[s for s in samples if s['minimum_incident_source_normal_projection_m']<0]
 if negative:report['new_negative_controls'].append({'age':age,'component':'newly closed waistcoat front','samples':negative,'status':'OPEN; proposal not accepted'})
 trousers=new.garment_shell(m,'trousers',r['trouser_offset_m'],r,bones,height*scale,scale)
 envelopes=[]
 for side,s in trousers['receipt']['trouser_hang_profile']['sides'].items():
  chain={j+'_'+side for j in ('thigh','calf','foot','ball')};points=[p for p,w in zip(m['positions_m'],m['weights']) if s['fit_band_y_m'][0]<=p[1]<=s['fit_band_y_m'][1] and math.fsum(v for j,v in w.items() if j in chain)>.9]
  radial=max(math.hypot((p[0]-s['axis_x_m'])/s['section_rx_m'],(p[2]-s['axis_z_m'])/s['section_rz_m']) for p in points)
  assert radial<=1+1e-12
  envelopes.append({'side':side,'actual_source_support_vertices':len(points),'maximum_body_elliptic_radius_fraction':radial,'body_enclosed_in_untapered_design_support_section':True,'limit':'A support section is not a tapered garment/triangle enclosure or collision proof'})
 assert digest(body)==initial,'in-memory source/body/rig/identity was mutated'
 report['ages'].append({'age':age,'source_body_memory_sha256_before_after':initial,'body_and_all_skin_rig_identity_metadata_unchanged_in_memory':True,'shirt_geometry_weights_uv_source_identity_exact':True,'newly_closed_front_samples':samples,'newly_closed_front_minimum_m':min(s['minimum_incident_source_normal_projection_m'] for s in samples),'newly_closed_front_negative_count':len(negative),'real_limb_section_support':envelopes})
report['finite_static_controls_pass']=not report['new_negative_controls'];report['elapsed_s']=time.monotonic()-start
(D/'V5-SUPPLEMENTAL-SOURCE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'finite_static_controls_pass':report['finite_static_controls_pass'],'inherited_negatives_open':40,'new_negative_controls':report['new_negative_controls'],'ages':[{'age':a['age'],'new_front_samples':len(a['newly_closed_front_samples']),'new_front_minimum_m':a['newly_closed_front_minimum_m']} for a in report['ages']],'elapsed_s':report['elapsed_s']},indent=2))
