T2662 exact-source first-visible-tap repair —PREPARED/HELD

Failure preserved: immutablefe9832a149, run39854658597/job120089609346, mobile9–12. Seven terms,7lines,FAQquestions,max50words passed; Homefirsttap failed withnullterm/no bubble. T3021 intentionally converted Confidenceviewstatus into appbutton; term-tips skips controls. This is an absent-target caller mismatch, not evidence ofevent,listener,layout orslowloadfailure.

One-file test-only patch: beforeanyenterTown/stagework atinitialifready, stageOn12 waits existinguntilLanded thenuses existinghit-testedclickChrome onactualvisibleWelcomeintroReconstructed, records exactmeaning/shown/viewport/welcome+landed state; secondhit-testedtaprecordsdismissal. Failuresarekept inreading.error andthefinalT2662assertfails. LaterGuide7terms/FAQ/readability remain unchanged, plusfirsttapactualreading. NoDOMinjection,resetTerms,hiddenelementtap,thresholdrelaxation,newjourney or producttilechange. Fullcombinedruns mayreloadlater; thecaptureisexplicitlytheinitialWelcomedocument, notmislabelledaslaterGuide/Home.

Expectedsourceboundmeaning: Reconstructed No record exists. We built it so the street makes sense, and say so.

Source binding: welcome.show setsrealintro/markTerms beforearrivaljourneylanded; glossarydata andlockedtermstring table agree; gatez40/term-tipz60 allowsbubbleaboveWelcome. ExistingclickChrome verifiesenabled/nonzero/settled/scrolled/topmost target. Actualpixel,interaction andfullstagevalidation have NOT run. App/index/Git untouched; rootownsapply/validation aftercurrentgatecloses.

Separate follow-up: main marksLiberties inside h3.ev-topic-title, CSS hides thattitle, visiblepaneltitle isplaintext. Retargetingtohiddenbuttonwouldnotprovevisitorfirstappearance. No runtimefixincludedonthishumanmergecriticalpath.
