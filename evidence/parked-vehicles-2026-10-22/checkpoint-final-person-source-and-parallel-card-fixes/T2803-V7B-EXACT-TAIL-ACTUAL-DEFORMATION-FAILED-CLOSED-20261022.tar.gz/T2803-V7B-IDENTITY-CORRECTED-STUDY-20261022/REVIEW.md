# V7B actual source walk result — deformation FAILED, closed

The separately authorized identity-only correction compares the proved fixture's exact969unique source vertex IDs in sorted order. OriginalV7's ordering failure and source pins remain immutable in its previous capsule. The actual field correction remains one precise ownership change: preserve every original source joint-slot/weight value on the independently proved isolated901-class tail component. The component must match the exact sourcevertex set, material, whole-component graph identity, bounds, body/tail-only influences and zero hoof/limb involvement. No blanket hair/disconnected-geometry rule is used.

One nice19/math1 pass closed exit2 in3.145594wall seconds, without timeout, retries or parameter tuning. All component identity and per-vertex original tail equality checks passed. The V6 genuine head/neck/tail sourcejoint dominance rule remains in the body; upper-trunk/hoof anchors, finite-geodesic and solver guards,0.326395563m screening length, original mesh26restjoints,65poses,240mmstride and original deformation limits were unchanged.

Actual source solve has6506hard classes/1018unknown;940incidental-or-nondominant head/tail classes are released from the old ownership rule, while the proved901tailclasses preserve their original weights. There are no ambiguous exact dominance ties. The solve residual is1.33e-15.

Neutral position95.23nm, finite data, all stance patches/rigid chains, exactloop, seam and meaningful corruption controls PASS. Full11556vertices/14986triangles were checked at each of65poses. The exact original969tailvertex joint slots/weights are preserved, including UV duplicates.

Body DEFORMATION STILL FAILS: edge ratios .778392–1.348984 against .9–1.1; area ratios .520688–1.485031 against .8–1.2. Rest-relative negative normal-dot count is0. The actual worst stretched edge is triangle5313,3240→3228,8.996994mm at1.175s; its weight L1jump .139292 gives5.793368mm gradient displacement. Complete rest/posed vertices, weights and extreme edge/area/normal witnesses are saved. Original tail/hair and eye surfaces retain near-rigid behavior; this does not qualify anatomy or appearance.

Four-weight pruning now discards up to9.403054%mass (p95 1.611972%). It may contribute to the9mm edge's palette jump, but this is NOT yet established as the cause. The previous unpruned diagnostic concernedV5's different field, so its conclusion cannot simply be transferred toV7B. Any next investigation should compare exact unpruned/current-four witnesses on this frozen source before another field proposal. Do not retune length scale, reduce stride or relax bounds.

This task stops after this actual result and checkpoint. No accepted weight field, GLB/animation export, app/product integration, rendered gait, anatomical/photographic acceptance, ticket closure or merge qualification. Earlier actual failures are retained.
