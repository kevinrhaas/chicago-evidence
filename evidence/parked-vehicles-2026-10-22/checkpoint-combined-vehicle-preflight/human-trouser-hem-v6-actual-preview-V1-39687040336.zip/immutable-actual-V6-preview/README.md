# V6 hem preview V1 — PREPARED / HELD

No browser/server or source producer has run. Root owns parent-only exec36280 and will review/release only after it is CLOSED. The release template is false; this directory contains no release, run intent, PNG or runtime receipt.

Before now means frozen V5 source trousers + V5 source waistcoat. After means exact frozen V6 source trousers + the SAME V5 source waistcoat. Both run on the same actual V4 canonical Bardwell body/rig/materials; neither garment variant is canonical. Only the already-frozen V6 level hem trim differs. No new hem geometry is created. The exact V6 packet is e29b619590e9e0c6f2644204d4ddaf22a61fce33c8424da5033ad4b59405965b.

The correctedV3 geometry/install/pose/bounds/union-camera/view functions remain byte-exact, including production skinned frustumCulled=false, actual shoe draw/render-count assertions, indexed normals before corner-UV expansion, actual all-vertex10percent padding/depth guards and all model/bone/bind logs. Both variants share paired union cameras per pose/viewport/view. Protected body/skin/shirt/eyes/shoes/hair, actual materials, skeleton, poses and animations remain unchanged; there is no mask, pose/root translation or guard change.

SOURCE-ARRAY-COMPATIBILITY.json records finite array/layout/joint checks and12new hem-corner original source-UV/barycentric-skin checks. The frozen arrays and all source packet hashes were verified; no dense body/fit/pose sweep or producer replay occurred. Existing V3 inputs/captures and frozen V5/V6 packets remain unchanged.

One future run is24images: v5-before/v6-after × desktop/mobile × idle/sit_drive0 × front/profile/quarter. The caller retains the85second owned cap, exclusive intent, no retries and owned browser/server cleanup. Unsupported/error/framing/draw failure stops the one run.

After root review and parent/browser lane closure, root may copy RELEASE-TEMPLATE.json to RELEASE.json, set its two release flags true while preserving both manifest hashes, then run once:

```bash
python /workspace/shared/human-trouser-hem-v6-preview-V1-prepared-held-39687040336/capture_preview.py --release /workspace/shared/human-trouser-hem-v6-preview-V1-prepared-held-39687040336/RELEASE.json
```

Frozen V6 source documents retain their old broad seated-shoe FAIL wording as history. INHERITED-SHOE-FINDING-CORRECTION.json records its superseding stale-preview-culling diagnosis; actual correctedV3 showed shoes. No new geometry repair is implied. Complete shoe/garment fit, shorter-hem ankle coverage in poses, V5/V6 canonical/LOD, normal/sole requalification, period/photo/world/occupied acceptance and T1789 remain OPEN. Forty inherited negative projections and deferred finishing remain OPEN. No app, Git, CI, ref, ticket, browser/server or install action occurred during this preparation.
