'use strict';
const crypto=require('node:crypto');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const close=(x,y)=>{if(typeof x==='number'&&typeof y==='number')return Math.abs(x-y)<=1e-8;if(Array.isArray(x))return Array.isArray(y)&&x.length===y.length&&(x.every((v,i)=>close(v,y[i]))||(x.length===4&&x.every((v,i)=>close(v,-y[i]))));if(x&&typeof x==='object')return y&&Object.keys(x).every(k=>close(x[k],y[k]));return x===y;};
module.exports=function validate({seed,receiptBytes,supervisorBytes,closedBytes,detail,quality}){
 const check=(v,m)=>{if(!v)throw Error('Inherited seed rejected: '+m);};
 check(seed.schema==='parked-parent-continuation-v1','schema');
 check(sha(receiptBytes)===seed.source.receipt_sha256,'receipt hash');check(sha(supervisorBytes)===seed.source.supervisor_sha256,'supervisor hash');check(sha(closedBytes)===seed.source.root_closed_sha256,'root closed hash');
 const r=JSON.parse(receiptBytes),s=JSON.parse(supervisorBytes),c=JSON.parse(closedBytes),n=seed.new_arm;
 check(c.status==='CLOSED_DEADLINE_STOP'&&c.guard_after_PASS&&c.prepared_after_PASS,'root CLOSED status/guards');
 check(c.receipt_sha256===sha(receiptBytes)&&c.supervisor_sha256===sha(supervisorBytes),'root CLOSED source binding');
 check(s.guard_before?.PASS&&s.guard_after?.PASS&&s.prepared_inputs_after?.PASS&&s.deadline_reached===true,'source supervisor guards/deadline');
 check(s.manifest_sha256===seed.source.manifest_sha256&&seed.source.manifest_sha256==='734f3991e2554319ba446bfaa3b72a73a19b5a40684cb1efcd0e3ffa2eae0438','source manifest');
 check(seed.source.caller_sha256==='14c28eac45442d214eaf8d581aa41a73e512c04e6c627498282d33b57ad7c5cb','source caller');
 check(r.status==='STOPPED'&&n.arm==='new'&&typeof n.ended==='string'&&n.ended.length>0,'completed new arm inside original STOPPED receipt');
 check(JSON.stringify(r.arms.filter(a=>a.arm==='new'))===JSON.stringify([n]),'exact original new subtree');
 check(seed.config.detail===detail&&seed.config.quality===quality&&r.config.detail===detail&&r.config.quality===quality,'explicit source detail/quality');
 check(n.initial.detail===detail&&n.pose.state.detail===detail,'actual detail');
 check(Array.isArray(n.samples)&&n.samples.map(s=>s.mode).join(',')==='normal,xray,ghost40','three ordered unique modes');
 check(n.errors?.length===0&&r.serverErrors?.length===0,'captured errors');
 const keys=Object.keys(n.initial.storage).sort(),allow=['chicago4d.settings','chicago4d.device','chicago4d.confidence','chicago4d.confidence.hidden'].sort();check(keys.length===4&&keys.every((k,i)=>k===allow[i]),'exact four-key storage');
 check(Object.keys(n.initial.prebuilt).length===5&&Object.values(n.initial.prebuilt).every(p=>p?.used===true),'all five used prebuilt layers');
 for(const x of n.samples){check(x.reconciliation?.PASS===true,'reconciliation '+x.mode);check(x.stats.budget.drawCalls===7800,'production7800 budget '+x.mode);check(x.glError===0,'GL '+x.mode);check(close(x.pose.position,n.pose.camera.position)&&close(x.pose.quaternion,n.pose.camera.quaternion),'source saved pose '+x.mode);}
 check(seed.provenance.inherited===true&&seed.provenance.executed_in_continuation_process===false&&seed.provenance.separate_execution===true,'separate execution provenance');
 return {PASS:true,inherited_modes:n.samples.map(x=>x.mode),source_detail:detail,source_quality:quality,executed_new_arms:0};
};
