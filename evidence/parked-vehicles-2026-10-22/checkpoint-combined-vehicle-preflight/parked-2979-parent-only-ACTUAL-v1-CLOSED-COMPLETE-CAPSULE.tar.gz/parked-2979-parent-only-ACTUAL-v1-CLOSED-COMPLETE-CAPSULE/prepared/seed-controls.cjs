'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const B=__dirname,sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const args={seed:JSON.parse(fs.readFileSync(path.join(B,'COMPLETED-NEW-ARM-SEED.json'))),receiptBytes:fs.readFileSync(path.join(B,'SOURCE-V4b-RECEIPT.json')),supervisorBytes:fs.readFileSync(path.join(B,'SOURCE-V4b-SUPERVISOR.json')),closedBytes:fs.readFileSync(path.join(B,'SOURCE-V4b-ROOT-CLOSED.json')),detail:'full',quality:1},validate=require('./seed-validation.cjs');
const positive=validate(args),cases=[];
for(const [name,change]of [['receipt bytes mismatch',a=>{a.receiptBytes=Buffer.from('{}');}],['new subtree modified',a=>{a.seed.new_arm.samples[1].stats.drawCalls++;}],['incomplete modes',a=>{a.seed.new_arm.samples.pop();}],['different controlled detail',a=>{a.detail='balanced';}],['different quality',a=>{a.quality=.75;}],['inherited provenance missing',a=>{a.seed.provenance.separate_execution=false;}]]){
 const a={...args,seed:JSON.parse(JSON.stringify(args.seed))};change(a);assert.throws(()=>validate(a),/Inherited seed rejected/);cases.push({name,PASS:true});
}
const caller=fs.readFileSync(path.join(B,'compare.cjs'),'utf8'),old=fs.readFileSync('/workspace/shared/parked-2979-paired-overlay-PREPARED-HELD-v4b/compare.cjs','utf8'),tail='  // Passive GL commands are counted';
assert(caller.includes("for(const arm of ['parent'])"));assert(!caller.includes("for(const arm of ['new','parent'])"));assert(caller.includes('let pairedPose=seed.new_arm.pose,pairedStorage=seed.new_arm.initial.storage,pairedPrebuilt=seed.new_arm.initial.prebuilt;'));assert.equal(caller.slice(caller.indexOf(tail)),old.slice(old.indexOf(tail)));
const result={PASS:true,browser_launches:0,source_receipt_sha256:sha(args.receiptBytes),seed_sha256:sha(fs.readFileSync(path.join(B,'COMPLETED-NEW-ARM-SEED.json'))),caller_sha256:sha(caller),positive,reject_controls:cases,only_parent_outer_loop:true,new_arm_runtime_replay:false,raw_instrumentation_modes_and_comparison_tail_identical:true,raw_tail_sha256:sha(caller.slice(caller.indexOf(tail))),scope:'Actual terminal bytes/subtree/prebuilt/pose/reconciliation checks, offline structural controls only; no browser'};
process.stdout.write(JSON.stringify(result,null,2)+'\n');
