# CLOSED diagnostic comparison — separate executions

The parent-only continuation completed EXIT0 with all original pose/state/confidence, primary-driver reconciliation, GL and live/prepared guard checks intact. It inherited the exact completed new arm from the CLOSED V4b deadline run; only parent ran in this continuation. This is diagnostic evidence, not official CI qualification.

| Mode | New draws | Parent draws | Difference | Original draw bar |
|---|---:|---:|---:|---:|
| NORMAL |3695|3694|+1|7800|
| Xray |8223|8222|+1|7800|
| Ghost40% |8466|8465|+1|7800|

The entire draw difference is shadow/yard21 versus20 in every mode. All other pass/layer draw counts match. The three new parked groups are invisible at this pose, with no direct parked draw bucket. Therefore the measured+1 is described by its actual shadow-yard attribution, not asserted to be direct visible parked geometry cost.

Both arms exceed the original7800 draw bar in Xray and Ghost40. Xray triangles also exceed the recorded3,470,000 triangle bar: new3,654,224, parent3,656,436. NORMAL triangles2,842,422/2,844,634 and Ghost3,448,962/3,451,174 are below it. Budget identities were preserved; successful diagnostic gates do not make those performance readings pass.

All six samples reconcile primary GL exactly to shipped counters, with picking0/extra0/residual0 and GL0. No picking-counter fix was exercised. Xray terrain ghost3908 and structures ghost2604 dominate both arms; Ghost40 terrain3857 and structures2472 likewise match. Raw ghost-target counts differ because the scenes contain different objects; full counters and eligibility records remain in the receipts.

NewXray8223 equals CI8223; newGhost8466 differs from CI8469 by−3. Historic CI camera/state remains unknown, so neither equality nor the small paired delta changes the recorded strict CI failures. The actual common substrate is the original pinned mirror with exact candidate2aeb and parentfdb overlays, not a historical parent publication. No budget/source/policy change, browser retry, official dispatch or merge was performed by this evidence work.

Exact source receipts, seed, manifests, root releases/closures, original caller/control/support, both executions' raw served-request bindings and actual stdout/config are included. See TERMINAL-DIAGNOSIS.json and FILES.json for provenance and hashes. The mirror and runtime/vendor binaries are omitted with exact reacquisition metadata; this capsule is not standalone runnable. Root owns subsequent product/performance decisions; this handoff proposes no source change or new run.
