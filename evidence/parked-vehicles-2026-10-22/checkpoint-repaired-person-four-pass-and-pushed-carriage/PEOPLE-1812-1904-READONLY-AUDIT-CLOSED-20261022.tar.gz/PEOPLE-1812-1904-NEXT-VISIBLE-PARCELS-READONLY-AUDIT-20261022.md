# Existing people for the next1812 and1904 visible parcels

Read-only review for existing T-1789. Current PR1175 must land unchanged; this note changes no asset, application, person, source, ticket or eligibility flag. Two existing named identities are already compiled, so an anonymous fallback is unnecessary. These are the best current identity/authoring starting points, not a claim that qualified portrait evidence has been found.

| Scene date | Selected existing person | Identity/presence | Appearance and wardrobe now |
| --- | --- | --- | --- |
|1812-08-14|`kinzie_john_elder`, John Kinzie the elder, household `hh_kinzie_john_elder`|Inferred; present inferred between12August council and15August land-column departure;48or49 from birth-year1763|Reconstructed; no qualified likeness, garment source or accepted photographic appearance. Existing study chooses age49/height1.75m, not measured personal dimensions.|
|1904-07-01|`glessner_john_j`, John J. Glessner, household `hh_glessner_john_j`|Attested identity/residence; household-year evidence is not an eyewitness observation at a particular July1 position;60or61 from birth-year1843|Reconstructed; no qualified likeness or source-matched suit. Existing study chooses age61/height1.75m, not measured personal dimensions.|

##1812: John Kinzie the elder

Actual current records: `data/residents_1812/households/hh_kinzie_john_elder.json` and `data/sidecars/1812/people.json`. An older `docs/RESEARCH/transport-human-candidates.md` says the1812 person layer is absent; that inventory is superseded by these real files.

Real identity citations:

* `moses_kirkland_history_of_chicago_v1`: John Moses/Joseph Kirkland, History of Chicago, Illinois, vol1,1895, https://archive.org/details/historyofchicago01mose . The household records exact retained OCR spans: birth-year line5185; silversmith/trader lines5151–5153;12August council interpreter lines7290–7296;15August column lines7458–7466. This is compilation/family-narrative mediated, not contemporary attendance on14August.
* `currey_1912_story_of_old_fort_dearborn`: J.Seymour Currey, The Story of Old Fort Dearborn,1912, chII, https://www.gutenberg.org/ebooks/52346 ; residence/arrival context, not likeness/clothes.
* Local original Wau-Bun EPUB, `/workspace/chicago/chicago/reference/Wau-bun/wau-bun-pg12183-images-3.epub`, chapterXVIII, paragraphs id00830–id00849, was read during this audit. It supports the elder trader biography/pack-horse commerce, not a dated portrait or his clothes. The Gutenberg transcription prints an apparent birth-year typo “1163”; do not use that typo or silently pretend a scan was collated. The household's1763 rests on its separately cited compilation.

Portrait/wardrobe status: no elder-Kinzie portrait or cleared likeness pixels were established by the actual files read. Do not use John Harris Kinzie's portrait/card: he is the elder's son, aged9 here. Existing dossier's Bradbury deerskin hunting coat describes Bradbury's own1809–1811 Missouri journey; it does not clothe Kinzie. The narrative's broadcloth/calico trade goods likewise do not establish his garments. Pyne's British wagon-driver plates remain unopened comparative leads, not accepted Chicago clothing patterns.

Existing authoring paths: `data/humans/recipes/era_studies/1812.json`; `assets/authored/humans/era_studies/1812/{body.json,garments.json,body-target.json}`; `tools/human_era_study_1812.py`, shared `tools/human_era_study_common.py` and `tools/human_era_study_blend.py`. Current original garments are `plain_shirt_conjectural_cut`, `plain_waistcoat_conjectural_open_front`, `plain_trousers_conjectural_front_envelope`, `plain_low_shoes_conjectural`.

Next concrete visible parcel: a fully fitted1812 civilian shirt/waistcoat/trousers/shoe set for this existing mature body, first standing/walking. Before claiming period-source match, acquire and actually view a dated pre1812 American civilian garment/pattern/object reference for cut, collar, waist/leg closure and footwear. New garment surfaces must enclose shoulders/armholes, torso/back, waist/crotch/seat and upper legs with proper layered openings rather than disconnected sheets; retain the portable rig and original source/derived visibility maps. A fall-front closure remains a proposal until the selected dated reference supports it. Skin/hair/face age treatment needs a separate mature reference; no invented personal likeness or ethnographic costume. No soldier uniform, fringe, ceremony, evacuation event or professional-driver role is inferred from his name/trade.

##1904: John J. Glessner

Actual current records: `data/residents_1904/households/hh_glessner_john_j.json` and `data/sidecars/1904/people.json`. The other compiled resident is Frances M.Glessner,56; selecting John reuses an already authored mature civilian study, not a claim his portrait evidence outranks hers.

Real identity citations:

* `habs_glessner_house_il_1015_data_pages`, HABS ILL-1015, https://www.loc.gov/item/il0118/ , data p4 for birth/career; household's arrival/home references also cite data pp1–2/9. Rights recorded no-known-restrictions for HABS data, asset_use text_only.
* `glessner_house_family_page`, museum biographies, https://www.glessnerhouse.org/glessner-family . Existing verified text supports1843 birth/career and family residence; the registry is check_required/text_only, not portrait-image clearance.
* Existing carriage-context note `/workspace/shared/resident-1904-candidate.md` records HABS PDFp9/data p8,1886 horse/buggy ownership with George driving, and PDFp10/data p9,1887 carriage outing. Those do not identify a1904 vehicle, chauffeur or observed driving event.

No dated/cleared Glessner portrait or civilian suit pattern is registered in the reviewed human recipe. A single bounded direct fetch of the existing museum biography URL failed immediately: local proxy port8080 unavailable. No browser, alternate network route or retry was used, so no new portrait pixels/date/rights were verified. This is an evidence gap, not permission to invent his face or say a portrait does not exist anywhere. The sensible acquisition target is a dated museum-held family portrait/full-length photograph with collection credit, subject/date and reuse basis checked, followed by a close-dated civilian suit source; no invented accession number/source ID.

Existing authoring paths: `data/humans/recipes/era_studies/1904.json`; `assets/authored/humans/era_studies/1904/{glessner_john_j_1904.prepared.json,glessner_john_j_1904.garments.json,body-target.json}`; `tools/human_era_study_1904.py` plus shared composition modules. This is a separate civilian coat/waistcoat/shirt-front/collar/trousers/shoe study, not the Sears work-jacket mesh.

Actual image reviewed: `/workspace/shared/human-visible-next/era-studies/published/glessner_john_j_1904_study.lod0-desktop-standing-front.png`. The coat/shirt leave shoulders and upper chest exposed; the trouser shapes leave broad upper-thigh skin exposed. The head reads young despite the61-year recipe. These are visible unfinished authoring defects, not a near-complete photographed gentleman.

Highest-value next visible parcel: repair this1904 civilian wardrobe as a coherent fitted suit over the mature body. Own coat shoulder/neck/armhole transitions and set-in sleeves; layer shirt/collar and waistcoat; construct an actual trouser waist/seat/crotch/upper-leg envelope connecting to both legs; fit closed shoes. Use real dated civilian evidence for cut/lapels/closures, then restrained wool/linen/leather surface response with physical material scale. Do not hide gaps by just darkening exposed anatomy or relabel the1835 worker. After coverage, mature head/skin/hair must be reviewed against qualified evidence; the current young skin atlas cannot substantiate a61-year-old likeness.

The1902 Sears41R742 checked-denim jacket in `generic-human-period-clothing.md` is real close-dated workwear vocabulary, not Glessner's suit or an attested personal purchase. Harvey-house attendants'1880–1899 image is link-only/rights-unknown and does not name a Glessner chauffeur. Choose standing/walking first; later passenger fitting is appropriate as reconstructed action. Do not assign a professional coachman/teamster occupation or a documented1904 driving/riding event.

## Existing mechanical assets do not establish eligibility

Both era recipes explicitly have `production_eligible:false`, `appearance_grade:reconstructed`, `garment_sources:[]`. Shared young CC0 skin and short04 hair are reusable engineering inputs, not mature skin/hairstyle or personal-appearance evidence. Keep those disclosures and clear-source provenance.

The recipe metadata `SOURCE_ONLY_BPY_UNEXECUTED` is stale relative to actual saved receipts: `/workspace/shared/human-visible-next/era-studies/{1812,1904}/master-receipt.json` says BPy executed/master written, original body normal readback PASS below.001, but photographic/scene acceptance false. Master-receipt `exported:false` records that authoring stage, not proof later GLBs/images are absent;1904 exports and the actual PNG exist. No missing-pipeline framework needs building just to start these tailoring parcels.

Acceptance should use actual source/export desktop/mobile full-body and close front/profile/three-quarter views, neutral light plus intended scene; inspect age, eyes/hair, all skin-to-garment coverage, seam normals, layered clothing and shoe contact. Then examine natural idle/walk poses for armhole/crotch/coat deformation and ground contact. Mechanical export green is not photographic completion. New wardrobe/appearance evidence remains a real prerequisite for a claimed source match, not a new owner approval ceremony.

## Date exclusions and minimal sequence

* Do not backdate Mark Beaubien: his current household records arrival1826, inferred from the1895 actual-settlers table. He does not supply an1812 adult at Chicago. Do not substitute his1835 clothing.
* Do not substitute the son `kinzie_john_h` for the elder. Do not move1835 Otis Bardwell into either scene. Do not place George Pullman alive in1904; he is absent from the actual compiled1904 people selection, and the user explicitly excludes post-death placement.
* Liberty White and the Lee farm deaths precede14August1812; the elder's next-day family boat/evacuation is not a14August street event.
* Finish unchanged PR1175's1835 example first. Work the two named-era tailoring/source parcels separately under existing T-1789, with1904 Glessner clothing coverage the clearest currently pictured repair and1812 Kinzie dated-clothing acquisition plus fitted set in parallel. No new gallery, identity or general framework is required.
