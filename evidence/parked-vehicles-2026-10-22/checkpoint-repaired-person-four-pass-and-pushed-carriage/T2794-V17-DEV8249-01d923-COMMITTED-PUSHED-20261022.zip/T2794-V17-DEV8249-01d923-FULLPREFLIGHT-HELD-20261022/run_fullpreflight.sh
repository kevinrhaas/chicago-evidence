#!/usr/bin/env bash
set -uo pipefail
cd /tmp/chicago-covered-sag/chicago/4d || exit 2
task_dir=/workspace/shared/T2794-V17-DEV8249-01d923-FULLPREFLIGHT-HELD-20261022
python3 "$task_dir/pin_state.py" start || exit 2
env PATH=/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:$PATH BASE=824957fe47dd70fad729c3b117cb18b695d54b0b CHECK_JOBS=4 C4D_GATE_REQUIRE_READERS=1 CHECK_TIMINGS="$task_dir/CHECK-TIMINGS.tsv" OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 ./tools/preflight.sh > "$task_dir/FULL-PREFLIGHT.log" 2>&1
gate_code=$?
python3 "$task_dir/pin_state.py" finish "$gate_code"
terminal_code=$?
tail -n 24 "$task_dir/FULL-PREFLIGHT.log"
exit "$terminal_code"
