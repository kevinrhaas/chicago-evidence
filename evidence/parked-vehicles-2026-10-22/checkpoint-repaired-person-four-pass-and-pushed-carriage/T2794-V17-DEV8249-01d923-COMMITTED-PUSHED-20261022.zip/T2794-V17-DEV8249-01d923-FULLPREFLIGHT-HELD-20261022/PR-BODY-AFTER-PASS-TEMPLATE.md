Adds one empty parked carriage reconstructed from the 1893 Studebaker Brougham catalogue design to the 1904 Prairie scene at the disclosed reconstructed stand E1397.9, N−3240, bearing178.99°. The existing C02 carriage stays at its separate stand. The catalogue identifies a design; this specimen's Chicago presence, ownership and exact dimensions are not attested. Occupancy, hitching, driving, boarding and riding remain unavailable, and T-2794 remains open.

The installed V17 indexed near model has 33,502 triangles, exact raw/source/license records and thirteen source anchors. A Brougham-only rigid vertical solve covers its wheels and complete fixed pole shoe while retaining the existing 1mm penetration and 30mm gap guards. Reviewed matched catalogue views support an initial development model; photographic completion remains open.

This update preserves the complete incoming DEV824957fe history, materializes its exact Glessner package, and rebuilds derivatives through the supported compiler order. Its Brougham-only popup lead explicitly identifies an empty reconstructed example and unattested individual, ownership and location. The actual installed card's type, basis and structured catalogue reference were already valid; the regression test preserves those and all six legacy parked cards/openings/rendered HTML.

Validation at feature commit `@HEAD@`, tree `01d923aab229502a54e2804a4f816c17946018e3`:

- Normal fullpreflight PASS: @CHECKS@ checks, including @SELFTESTS@ self-tests, CHECK_JOBS4/required readers/one math thread, exact raw BASE824957fe and unchanged assertions.
- Supported derived tail PASS: 59 steps from compile_liberties.py, two automatic laps and no final change; actual liberty count and records both689. Exact current Glessner recovery, native V17 and parked-placement checks PASS.
- New card test isolation measured no live-tree writes; audit PASS779 tools/1022 declared steps.
- Actual committed-HEAD changelog/ID/whitespace checks and postcommit publish/mirror PASS; the local published build identifies @SHORTHEAD@.

Draft qualification remains pending. Integration beyond the exact incorporated DEV824957fe is not qualified by this local run. Actual normal published desktop and mobile inspection must still prove vehicle adoption, full pole/body/ground and tree/canopy/other-obstacle clearance, picking/cards/confidence/tier/disposal and unchanged whole-scene budgets. The prepared focused diagnostic retains CPU geometry and does not substitute for normal mobile memory or full smoke acceptance. T3032's baseline tree reduction does not establish added-carriage headroom. No world, photographic, occupied or parent-ticket completion is claimed.
