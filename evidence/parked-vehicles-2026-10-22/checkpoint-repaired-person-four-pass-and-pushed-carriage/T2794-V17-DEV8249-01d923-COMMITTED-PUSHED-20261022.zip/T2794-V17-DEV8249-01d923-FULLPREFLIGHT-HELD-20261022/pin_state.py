"""Root-released finite fullpreflight state guard and immediate terminal capture."""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, sys
D = Path(__file__).parent

def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()

# Copy globals FIRST at terminal, before hashes or Git can consume any time.
copied = []
if sys.argv[1] == 'finish':
    target = D / 'IMMEDIATE-GLOBAL-TMP-COPIES'
    target.mkdir(exist_ok=False)
    for p in sorted(Path('/tmp').glob('preflight*.log')):
        if p.is_file():
            q = target / p.name
            shutil.copyfile(p, q)
            copied.append({'source': str(p), 'copy': str(q), 'bytes': q.stat().st_size, 'sha256': digest(q)})
plan = json.loads((D / 'PLAN.json').read_bytes())
W = Path(plan['worktree'])
def git(*a): return subprocess.check_output(['git', *a], cwd=W, stderr=subprocess.PIPE).decode().strip()
def state():
    failures = []
    actual = {'head': git('rev-parse', 'HEAD'), 'head_tree': git('rev-parse', 'HEAD^{tree}'), 'merge_head': git('rev-parse', 'MERGE_HEAD'), 'index_tree': git('write-tree'), 'status': git('status', '--porcelain'), 'unstaged': git('diff', '--name-only').splitlines(), 'unmerged': git('ls-files', '-u').splitlines()}
    for key in ['head', 'head_tree', 'merge_head', 'index_tree', 'status']:
        if actual[key] != plan['expected_' + key]: failures.append('Expected ' + key + ' drifted')
    if actual['unstaged'] or actual['unmerged']: failures.append('Unstaged or unmerged source')
    for p, pin in plan['source_pins'].items():
        q = W / p
        if q.stat().st_size != pin['bytes'] or digest(q) != pin['sha256']: failures.append('Source pin drift: ' + p)
    for p, pin in plan['glessner_ignored_output_pins'].items():
        q = Path(plan['app']) / p
        if q.stat().st_size != pin['bytes'] or digest(q) != pin['sha256']: failures.append('Glessner ignored output drift: ' + p)
    return actual, failures
if sys.argv[1] == 'start':
    release = json.loads((D / 'ACTUAL-ROOT-FULLGATE-RELEASE.json').read_bytes())
    assert release.get('released') is True and release.get('plan_sha256') == digest(D / 'PLAN.json'), 'Exact root fullgate release absent'
    for p, pin in plan['runner_pins'].items(): assert digest(D / p) == pin, 'Runner pin drift: ' + p
    actual, failures = state()
    assert not failures, failures
    with (D / 'START.json').open('x') as out:
        json.dump({'state': 'RUNNING', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'actual': actual, 'plan_sha256': digest(D / 'PLAN.json'), 'BASE': plan['base'], 'CHECK_JOBS': 4, 'readers': 1, 'math_threads': 1, 'outer_timeout': None}, out, indent=2)
    print('Exact root release, source tree and three ignored Glessner outputs verified; starting ordinary fullpreflight')
else:
    code = int(sys.argv[2])
    actual, failures = state()
    r = {'state': 'CLOSED_PASS' if code == 0 and not failures else 'CLOSED_FAIL', 'preflight_exit': code, 'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'actual': actual, 'pins_unchanged': not failures, 'pin_failures': failures, 'global_tmp_logs_copied_immediately': copied, 'outer_timeout': None}
    (D / 'TERMINAL.json').write_text(json.dumps(r, indent=2) + '\n')
    print(json.dumps(r, indent=2))
    raise SystemExit(0 if r['state'] == 'CLOSED_PASS' else 1)
