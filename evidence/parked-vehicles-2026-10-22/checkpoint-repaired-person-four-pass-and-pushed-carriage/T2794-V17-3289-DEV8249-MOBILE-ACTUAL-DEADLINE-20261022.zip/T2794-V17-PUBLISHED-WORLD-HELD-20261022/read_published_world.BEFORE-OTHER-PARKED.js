// Read-only actual published geometry diagnostics. Never installs/replaces a model.
window.readPublishedBroughamWorld = async function () {
 const T=await import('three'),a=window.__chicago4d,plan=window.BroughamWorldPlan;
 const need=(v,m)=>{if(!v)throw Error(m)},begin=performance.now();
 need(plan&&a?.ready&&String(a.year)==='1904','Pinned ready main1904 required');
 need(location.pathname==='/site/4d/walk/','Exact published main door required');
 need(document.getElementById('gate-build')?.textContent.includes(plan.expectedHead.slice(0,9)),'Published exact feature build stamp');
 need(!a.confidence.ghosting,'Normal view required; no Ghost budget substitution');
 const result=await window.readInstalledBroughamWorld();
 result.scope='Focused actual published main contact/anchors/street-elm surface and budget readback; not the complete smoke or full solid collision proof';
 result.satControls=window.BroughamSurfaceSAT.controls();
 result.expectedBuild=plan.expectedHead;result.budgetMatchesUnchangedCaps=result.stats.budget.drawCalls===7800&&result.stats.budget.triangles===plan.profiles.find(p=>p.detail===a.detail)?.triangles;
 if(!result.installed){result.accepted=false;return result}
 const instance=a.parkedTransport.instances.find(i=>i.row.id==='prairie_parked_studebaker_brougham');
 const hash=async b=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(v=>v.toString(16).padStart(2,'0')).join('');
 const metadataUrl=new URL('transport/parked-brougham/brougham.json',document.baseURI),res=await fetch(metadataUrl,{cache:'no-cache'});need(res.ok,'Served metadata');const bytes=await res.arrayBuffer(),metadata=JSON.parse(new TextDecoder().decode(bytes));
 result.metadata_sha256=await hash(bytes);need(result.metadata_sha256===plan.metadataSha256,'Exact current metadata pin');
 need(metadata.anchors.length===13,'Actual13 source anchors');
 instance.group.updateMatrixWorld(true);
 result.anchors=metadata.anchors.map(x=>{const p=new T.Vector3(...x.translation_root_m).applyMatrix4(instance.group.matrixWorld);return{name:x.node,root_m:x.translation_root_m,world_enu:[p.x,-p.z,p.y],dynamic_binding_supported:x.dynamic_binding_supported}});
 result.anchorsScope='Pinned source-root metadata anchors transformed by the actual installed static group; native checker binds these to the raw/near node hierarchy, which static material batching removes.';
 const bounds=vs=>({min:[0,1,2].map(k=>Math.min(...vs.map(v=>v[k]))),max:[0,1,2].map(k=>Math.max(...vs.map(v=>v[k])))});
 const overlap=(x,y,tol=1e-8)=>x.min.every((v,k)=>v<=y.max[k]+tol&&x.max[k]>=y.min[k]-tol);
 const expand=(b,d)=>({min:b.min.map((x,k)=>x-d[k]),max:b.max.map((x,k)=>x+d[k])});
 const merge=(x,y)=>({min:x.min.map((v,k)=>Math.min(v,y.min[k])),max:x.max.map((v,k)=>Math.max(v,y.max[k]))});
 const triAt=(mesh,k,matrix)=>{const g=mesh.geometry,p=g.getAttribute('position'),ix=g.index;need(p?.array?.length,'Actual CPU position array unavailable');return[0,1,2].map(j=>new T.Vector3().fromBufferAttribute(p,ix?ix.getX(k+j):k+j).applyMatrix4(matrix).toArray())};
 const vehicle=[],allVertices=[],actualShoe=new Map(),inverse=instance.group.matrixWorld.clone().invert();
 instance.group.traverse(mesh=>{if(!mesh.isMesh)return;const g=mesh.geometry,p=g.getAttribute('position'),count=g.index?g.index.count:p.count;need(p.array?.length,'Actual parked CPU buffers');for(let k=0;k<count;k+=3){const tri=triAt(mesh,k,mesh.matrixWorld);vehicle.push({v:tri,b:bounds(tri),mesh:mesh.name,triangle:k/3})}for(let k=0;k<p.count;k++){const q=new T.Vector3().fromBufferAttribute(p,k).applyMatrix4(mesh.matrixWorld);allVertices.push(q.toArray());const r=q.clone().applyMatrix4(inverse);if(Math.abs(r.y)<1e-8&&r.z>3.7&&Math.abs(r.x)<.04)actualShoe.set(q.toArray().map(x=>x.toFixed(10)).join(','),q.toArray())}});
 need(vehicle.length===33502&&actualShoe.size===4,'Actual merged native triangles and shoe corners');
 const full=vehicle.reduce((b,q)=>merge(b,q.b),vehicle[0].b),cell=.25,index=new Map();
 function keys(b,s=cell){const out=[];for(let x=Math.floor(b.min[0]/s);x<=Math.floor(b.max[0]/s);x++)for(let y=Math.floor(b.min[1]/s);y<=Math.floor(b.max[1]/s);y++)for(let z=Math.floor(b.min[2]/s);z<=Math.floor(b.max[2]/s);z++)out.push(`${x},${y},${z}`);return out}
 for(let j=0;j<vehicle.length;j++)for(const key of keys(vehicle[j].b)){if(!index.has(key))index.set(key,[]);index.get(key).push(j)}
 const candidates=b=>{const ids=new Set(),clipped={min:b.min.map((x,k)=>Math.max(x,full.min[k])),max:b.max.map((x,k)=>Math.min(x,full.max[k]))};if(!overlap(b,full))return ids;for(const key of keys(clipped))for(const j of index.get(key)??[])if(overlap(vehicle[j].b,b))ids.add(j);return ids};
 // Actual triangulated carriageway: seams are overlays, not support surfaces.
 const roads=[];a.streetGrid.group.updateMatrixWorld(true);a.streetGrid.group.traverse(mesh=>{if(!mesh.isMesh||mesh.userData.cls!=='carriageway'||mesh.geometry.getAttribute('seam'))return;const p=mesh.geometry.getAttribute('position'),count=mesh.geometry.index?.count??p.count;for(let k=0;k<count;k+=3){const v=triAt(mesh,k,mesh.matrixWorld),b=bounds(v);if(b.min[0]<=full.max[0]&&b.max[0]>=full.min[0]&&b.min[2]<=full.max[2]&&b.max[2]>=full.min[2])roads.push({v,b,mesh:mesh.name,triangle:k/3})}});
 need(roads.length>0,'Actual carriageway triangles under model');
 const roadIndex=new Map(),roadCell=.5;
 for(const r of roads)for(let x=Math.floor(r.b.min[0]/roadCell);x<=Math.floor(r.b.max[0]/roadCell);x++)for(let z=Math.floor(r.b.min[2]/roadCell);z<=Math.floor(r.b.max[2]/roadCell);z++){const key=`${x},${z}`;if(!roadIndex.has(key))roadIndex.set(key,[]);roadIndex.get(key).push(r)}
 function roadHeight(x,z){let top=null;for(const r of roadIndex.get(`${Math.floor(x/roadCell)},${Math.floor(z/roadCell)}`)??[]){const[p,q,t]=r.v,den=(q[2]-t[2])*(p[0]-t[0])+(t[0]-q[0])*(p[2]-t[2]);if(Math.abs(den)<1e-14)continue;const u=((q[2]-t[2])*(x-t[0])+(t[0]-q[0])*(z-t[2]))/den,v=((t[2]-p[2])*(x-t[0])+(p[0]-t[0])*(z-t[2]))/den,w=1-u-v;if(Math.min(u,v,w)>=-1e-8){const y=u*p[1]+v*q[1]+w*t[1];if(top===null||y>top)top=y}}return top}
 const sample={vertices:0,edgeMidpointsAndCentroids:0,missingRoad:0,minGap_m:Infinity,witness:null};
 const check=(p,kind)=>{sample[kind]++;const ground=roadHeight(p[0],p[2]);if(ground===null){sample.missingRoad++;return}const gap=p[1]-ground;if(gap<sample.minGap_m){sample.minGap_m=gap;sample.witness={world_enu:[p[0],-p[2],p[1]],actual_triangle_road_y:ground,gap_m:gap}}};
 for(const p of allVertices)check(p,'vertices');
 for(const {v}of vehicle){for(let k=0;k<3;k++)check(v[k].map((x,j)=>(x+v[(k+1)%3][j])/2),'edgeMidpointsAndCentroids');check(v[0].map((x,j)=>(x+v[1][j]+v[2][j])/3),'edgeMidpointsAndCentroids')}
 result.actualRoadGeometry={triangles:roads.length,...sample,pass:sample.missingRoad===0&&sample.minGap_m>=-.001,scope:'Actual rendered-road triangle interpolation at every merged vertex and all edge midpoints/centroids; full body continuous extrema remain unproved'};
 // Clip the entire ACTUAL flat bottom against every nearby actual road face.
 const shoe=[...actualShoe.values()],cx=shoe.reduce((s,p)=>s+p[0],0)/4,cz=shoe.reduce((s,p)=>s+p[2],0)/4;shoe.sort((p,q)=>Math.atan2(p[2]-cz,p[0]-cx)-Math.atan2(q[2]-cz,q[0]-cx));
 const cross=(p,q,r)=>(q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0]);let patchMinimumGap=Infinity,patchMaximumGap=-Infinity,patchVertices=0;
 const area=poly=>poly.length<3?0:Math.abs(poly.slice(1,-1).reduce((s,p,k)=>s+cross(poly[0],p,poly[k+2]),0))/2;
 const clipConvex=(input,clip)=>{let poly=input.slice();for(let k=0;k<clip.length&&poly.length;k++){const p=clip[k],q=clip[(k+1)%clip.length],out=[];for(let j=0;j<poly.length;j++){const s=poly[j],e=poly[(j+1)%poly.length],ds=cross(p,q,s),de=cross(p,q,e);if(ds>=0)out.push(s);if((ds>=0)!==(de>=0)){const t=ds/(ds-de);out.push(s.map((v,i)=>v+t*(e[i]-v)))}}poly=out}return poly};
 const shoePoly=shoe.map(p=>[p[0],p[2]]),pieces=[];
 for(const road of roads){const clip=road.v.map(p=>[p[0],p[2]]);if(cross(...clip)<0)clip.reverse();const poly=clipConvex(shoePoly,clip);if(area(poly)>1e-14)pieces.push(poly);for(const p of poly){const h=roadHeight(p[0],p[1]);need(h!==null,'Clipped shoe patch ground');const gap=shoe[0][1]-h;patchMinimumGap=Math.min(patchMinimumGap,gap);patchMaximumGap=Math.max(patchMaximumGap,gap);patchVertices++}}
 need(patchVertices>0,'Complete shoe patch intersects actual road');
 const patchArea=area(shoePoly),coveredArea=pieces.reduce((s,p)=>s+area(p),0);let duplicateArea=0;for(let i=0;i<pieces.length;i++)for(let j=i+1;j<pieces.length;j++)duplicateArea+=area(clipConvex(pieces[i],pieces[j]));const fullCoverage=Math.abs(coveredArea-patchArea)<1e-10&&duplicateArea<1e-10;
 result.actualFullShoePatch={cornersWorldENU:shoe.map(p=>[p[0],-p[2],p[1]]),clipVerticesTested:patchVertices,patchArea_m2:patchArea,coveredArea_m2:coveredArea,pairwiseOverlapArea_m2:duplicateArea,fullCoverage,minGap_m:patchMinimumGap,maxGap_m:patchMaximumGap,pass:fullCoverage&&patchMinimumGap>=-.001&&patchMaximumGap<=.03,scope:'Piecewise-affine extrema over full flat shoe polygon clipped against actual road triangles; same original1mm/30mm limits. Full coverage requires equal area and disjoint clipped interiors.'};
 // Current selected tree geometry + shader wind. CPU reads preserve the real
 // matrices/LOD selection. Alpha leaf cards are conservative surface geometry.
 const tree={batches:0,activeInstances:0,nearbyInstances:0,trianglesExamined:0,currentPhaseCandidatePairs:0,currentPhaseIntersectionCount:0,currentPhaseIntersections:[],allPhaseEnvelopeCandidatePairs:0,uniformReads:[],scope:'Actual selected street-tree BatchedMesh triangles and instance matrices. Exact pinned wind arithmetic at live uniform phase; all-phase envelope is conservative, not an intersection assertion. Alpha cards count as their whole triangle. At most32 intersection witnesses are retained, with total count separate.'};
 a.streetTrees.group.updateMatrixWorld(true);
 for(const batch of a.streetTrees.group.getObjectsByProperty('isBatchedMesh',true)){
  tree.batches++;const geometry=batch.geometry,p=geometry.getAttribute('position'),flex=geometry.getAttribute('aFlex');need(p?.array?.length&&flex?.array?.length,'Actual tree buffers required');
  const uniforms=a.renderer.properties.get(batch.material)?.uniforms,t=uniforms?.uWind?.value;need(Number.isFinite(t),'Live exact tree wind uniform required');tree.uniformReads.push({batch:batch.name,time:t});
  const info=batch._instanceInfo;need(Array.isArray(info),'Pinned current three instance metadata');
  for(let id=0;id<info.length;id++){if(!info[id].active||!batch.getVisibleAt(id))continue;tree.activeInstances++;const geometryId=batch.getGeometryIdAt(id),range=batch.getGeometryRangeAt(geometryId),matrix=new T.Matrix4().multiplyMatrices(batch.matrixWorld,batch.getMatrixAt(id,new T.Matrix4())),box=batch.getBoundingBoxAt(geometryId,new T.Box3());
   let maxFlex=0;for(let k=range.vertexStart;k<range.vertexStart+range.vertexCount;k++)maxFlex=Math.max(maxFlex,Math.abs(flex.getX(k)));
   box.expandByVector(new T.Vector3(.9*.42*maxFlex,0,.9*.26*maxFlex)).applyMatrix4(matrix);if(!overlap({min:box.min.toArray(),max:box.max.toArray()},full))continue;tree.nearbyInstances++;
   const linear=new T.Matrix3().setFromMatrix4(matrix);
   for(let k=range.indexStart;k<range.indexStart+range.indexCount;k+=3){const current=[],envelope=[];for(let j=0;j<3;j++){const vi=geometry.index.getX(k+j),q=new T.Vector3().fromBufferAttribute(p,vi),f=flex.getX(vi),w=q.clone().applyMatrix4(matrix),v=new T.Vector3(.42*f,0,.26*f).applyMatrix3(linear),s=Math.sin(t*.85+w.x*.055+w.z*.041)*.62+Math.sin(t*1.63+w.x*.113-w.z*.087)*.28;current.push(w.clone().addScaledVector(v,s).toArray());envelope.push(w.clone().addScaledVector(v,.9).toArray(),w.clone().addScaledVector(v,-.9).toArray())}tree.trianglesExamined++;const all=bounds(envelope);if(!overlap(all,full))continue;const ids=candidates(all);tree.allPhaseEnvelopeCandidatePairs+=ids.size;const now=bounds(current);if(!overlap(now,full))continue;for(const vid of candidates(now)){tree.currentPhaseCandidatePairs++;if(window.BroughamSurfaceSAT.intersects(current,vehicle[vid].v)){tree.currentPhaseIntersectionCount++;if(tree.currentPhaseIntersections.length<32)tree.currentPhaseIntersections.push({batch:batch.name,instance:id,geometryId,treeTriangle:(k-range.indexStart)/3,vehicleTriangle:vid,treeWorld:current,vehicleWorld:vehicle[vid].v})}}}
  }
 }
 need(tree.batches===4&&tree.activeInstances>0,'Actual summer street elms must be present');
 tree.currentPhaseSurfacePass=tree.currentPhaseIntersectionCount===0;tree.allWindEnvelopeDisjoint=tree.allPhaseEnvelopeCandidatePairs===0;
 // Actual geometry controls do not modify any scene object or placement.
 const actualTriangle=vehicle[0].v;need(window.BroughamSurfaceSAT.intersects(actualTriangle,actualTriangle),'Actual self-overlap control');need(!window.BroughamSurfaceSAT.intersects(actualTriangle,actualTriangle.map(p=>p.map((x,k)=>x+(k===0?100:0)))),'Actual translated disjoint control');
 tree.actualGeometryControls={selfOverlapDetected:true,translatedCopyDisjoint:true,sceneMutated:false};result.actualStreetTreeSurface=tree;
 result.actualWheelTriangleGround=result.wheels.map(p=>{const y=roadHeight(p.e,-p.n);return{...p,actualTriangleGround:y,gap_m:y===null?null:instance.group.position.y-y}});
 result.actualWheelTriangleGroundPass=result.actualWheelTriangleGround.every(p=>Number.isFinite(p.gap_m)&&p.gap_m>=-.001&&p.gap_m<=.03);
 result.accepted=result.accepted&&result.budgetMatchesUnchangedCaps&&result.actualRoadGeometry.pass&&result.actualFullShoePatch.pass&&result.actualWheelTriangleGroundPass&&tree.currentPhaseSurfacePass&&tree.allWindEnvelopeDisjoint;
 result.unproved=['Continuous full-body versus road extrema beyond finite vertex/edge/centroid samples','Building/roof/eave and all non-tree obstacles/solid containment','All normal card/picking/confidence/tier/disposal smoke assertions','Normal mobile CPU-array release and memory profile: keep-geometry=1 retains diagnostic buffers','GPU vertex feedback: this readback evaluates pinned wind arithmetic in CPU doubles','Photographic and occupied/riding/boarding/hitch acceptance'];
 result.seconds=(performance.now()-begin)/1000;return result;
};
