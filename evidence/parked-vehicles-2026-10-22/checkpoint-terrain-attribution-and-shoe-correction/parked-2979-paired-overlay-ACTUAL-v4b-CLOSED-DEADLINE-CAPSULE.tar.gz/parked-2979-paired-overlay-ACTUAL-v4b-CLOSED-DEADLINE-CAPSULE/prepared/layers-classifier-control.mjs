// Actual pinned Three Layers and actual caller-expression controls; no browser.
import fs from 'node:fs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { Layers } from './mirror/walk/vendor/three-0.185.1/three.core.js';
const here=path.dirname(fileURLToPath(import.meta.url));
const caller=fs.readFileSync(path.join(here,'compare.cjs'),'utf8');
const legacy=fs.readFileSync(path.join(here,'historical-v1-caller.txt'),'utf8');
const confidence=fs.readFileSync(path.join(here,'mirror/walk/js/confidence.js'),'utf8');
const GHOST_LAYER=Number(/export const GHOST_LAYER = (\d+);/.exec(confidence)[1]);
const expression=text=>/probe\.pass=(.*?)\?'ghost':'opaque'/.exec(text)[1];
const classify=new Function('camera','a','return '+expression(caller));
const oldClassify=new Function('camera','a','return '+expression(legacy));
const a={confidence:{GHOST_LAYER}};
const normal=new Layers(),ghost=new Layers(),other=new Layers();ghost.set(GHOST_LAYER);other.set(30);
const cases=[
 {name:'normal mask1 negative',mask:normal.mask,expected:false,actual:classify({layers:normal},a)},
 {name:'actual ghost31 positive',mask:ghost.mask,expected:true,actual:classify({layers:ghost},a)},
 {name:'other layer30 negative',mask:other.mask,expected:false,actual:classify({layers:other},a)},
 {name:'V1 signed comparison refuses actual ghost31: regression reproduction',mask:ghost.mask,expected:false,actual:oldClassify({layers:ghost},a)},
];
if(GHOST_LAYER!==31||normal.mask!==1||ghost.mask!==2147483648||cases.some(c=>c.actual!==c.expected))throw Error('Actual Layers classifier control failed');
const sha=f=>crypto.createHash('sha256').update(fs.readFileSync(path.join(here,f))).digest('hex');
const result={PASS:true,browser_launches:0,source:'Actual pinned Three Layers.set and exact expressions extracted from V1/V2 callers',GHOST_LAYER,v1_expression:expression(legacy),v2_expression:expression(caller),three_core_sha256:sha('mirror/walk/vendor/three-0.185.1/three.core.js'),confidence_sha256:sha('mirror/walk/js/confidence.js'),caller_sha256:sha('compare.cjs'),legacy_caller_sha256:sha('historical-v1-caller.txt'),cases};
fs.writeFileSync(path.join(here,'ACTUAL-LAYERS-CLASSIFIER-CONTROL.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
