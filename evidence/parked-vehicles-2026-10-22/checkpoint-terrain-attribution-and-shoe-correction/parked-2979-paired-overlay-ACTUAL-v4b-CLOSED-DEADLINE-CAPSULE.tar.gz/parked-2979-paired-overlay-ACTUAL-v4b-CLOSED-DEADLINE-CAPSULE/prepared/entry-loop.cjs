'use strict';
// Original bounded entry intent, checked on each poll; no browser dependency.
module.exports=async function enterTownBounded(readState,enter,wait,now,trace){
 const started=now(),deadline=started+30000;
 trace.started=started;trace.initialState=readState();trace.polls=[];
 while(now()<deadline){
  const state=readState(),poll={at:now(),state};trace.polls.push(poll);
  if(state==='world'){trace.endState=state;trace.ended=now();return trace;}
  if(state==='welcome'){
   const result=enter('spawn');poll.enterReturn=result===undefined?'undefined':result;
  }
  await wait(100);
 }
 trace.endState=readState();trace.ended=now();
 if(trace.endState==='world')return trace;
 throw Error('Town entry deadline');
};
