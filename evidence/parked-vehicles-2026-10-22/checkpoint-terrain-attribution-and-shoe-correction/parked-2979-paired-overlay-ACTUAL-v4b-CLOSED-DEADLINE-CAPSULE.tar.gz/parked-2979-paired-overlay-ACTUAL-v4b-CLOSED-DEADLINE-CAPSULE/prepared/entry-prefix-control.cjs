'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const enter=require('./entry-loop.cjs'),here=__dirname;
const check=(c,m)=>{if(!c)throw Error(m);};
(async()=>{
 const cases=[];let clock=0,asked=null,enterCalls=0;const trace={};
 const read=()=>asked!==null&&clock>=asked+200?'world':clock<200?'arrival':'welcome';
 await enter(read,how=>{check(how==='spawn','wrong entry');enterCalls++;if(asked!==null)return false;asked=clock;return true;},async ms=>{clock+=ms;},()=>clock,trace);
 check(trace.initialState==='arrival'&&trace.endState==='world'&&asked===200&&enterCalls===2&&trace.ended===400,'deferred welcome FSM failed');cases.push({name:'arrival -> deferred welcome -> world',PASS:true,trace,enterCalls});
 for(const state of ['arrival','welcome']){clock=0;let calls=0;const stuck={};let error=null;try{await enter(()=>state,()=>{calls++;return false;},async ms=>{clock+=ms;},()=>clock,stuck);}catch(e){error=e.message;}check(error==='Town entry deadline'&&clock===30000&&stuck.endState===state,'stuck entry deadline failed');cases.push({name:'stuck '+state+' refuses at original30s',PASS:true,error,ended:clock,enterCalls:calls,polls:stuck.polls.length});}
 const caller=fs.readFileSync(path.join(here,'compare.cjs'),'utf8');const match=caller.match(/a\.goToTarget\((\{kind:'person',id:'hogan_john_s_c'\})\)/);check(!!match,'actual person target missing');const target=Function('return '+match[1])();
 const main=fs.readFileSync(path.join(here,'mirror/walk/js/main.js'),'utf8'),start=main.indexOf('function goToTarget(target) {'),end=main.indexOf('\n  }\n\n  /**',start)+4,body=main.slice(start,end);check(start>0&&end>start,'actual source function not found');
 const calls=[];const destinations={resolve:t=>({kind:t.kind,id:t.id,structureId:t.kind==='person'?'hogan_store':t.id,label:'control'}),byId:()=>null};
 const go=Function('jauntRuntime','destinations','travel','hud','api','openBusiness','pick','return ('+body+')')(null,destinations,{go:t=>{calls.push(t);return true;}},{},{},()=>{},()=>{});
 check(go(target)===true,'actual source route refused');const actual=calls.pop();check(actual.kind==='structure'&&actual.id==='hogan_store'&&actual.person==='hogan_john_s_c','actual source lost person');
 go({kind:'structure',id:'hogan_store',person:'hogan_john_s_c'});const legacy=calls.pop();check(legacy.person===null,'legacy precision failure not reproduced');
 check(caller.includes("st.mode!=='horse'||st.dest_id!=='hogan_store'||st.person!=='hogan_john_s_c'"),'actual travel-state assertions missing');
 cases.push({name:'actual main goToTarget body preserves person destination and strips legacy structure decoration',PASS:true,callerTarget:target,actualTravelTarget:actual,legacyTravelTarget:legacy,scope:'Actual main reconstruction body; deterministic resolved-catalog stub only; no runtime/physics claim'});
 const sha=x=>crypto.createHash('sha256').update(x).digest('hex');const result={PASS:true,browser_launches:0,entry_helper_sha256:sha(fs.readFileSync(path.join(here,'entry-loop.cjs'))),caller_sha256:sha(caller),actual_main_function_sha256:sha(body),timeout_ms:30000,poll_ms:100,cases};fs.writeFileSync(path.join(here,'ENTRY-PREFIX-CONTROL.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({PASS:true,browser_launches:0,cases:cases.map(x=>({name:x.name,PASS:x.PASS})),caller_sha256:result.caller_sha256}));
})().catch(e=>{console.error(e);process.exitCode=1;});
