# V3 culling-policy-only preview — PREPARED / HELD

No V3 browser/server has run. Root owns the active performance diagnosis lane; no preview release is present. Review the included SOURCE-CPU-DIAGNOSIS.zip first and wait for root's explicit release after the lane closes.

V2's absent seated shoes came from its stale idle SkinnedMesh bounding sphere. A finite CPU proof reproduces10negative camera culls and two mobile-quarter positive controls; historical positive-control PNGs show brown shoes. The broad inherited shoe-source failure interpretation is superseded. No shoe geometry repair is warranted from that disappearance. Complete posed enclosure/full fit remains OPEN, including higher midfoot samples that do not follow rigid ball motion exactly.

This new V3 identity changes only the preview culling policy: every original canonical skinned mesh gets frustumCulled=false at load, matching exact2f75 production HumanActor. V5 replacement meshes already used that policy. Runtime assertions verify the actual shoe flag, record each posed frame's draw counts and skinned mesh onAfterRender participation, and require the shoe draw callback for each image.

All V2 geometry/install/pose/bounds/union-camera functions remain byte-exact. The same actual V4 GLB and frozen V5 trousers/waistcoat arrays, skins/bones/binds/materials/animations/source-normal ordering,24capture grid and85second lifecycle cap are retained. Actual vertex10percent-padding and full bone/frame logging remain unchanged. No geometry/V6, body mask, pose/root shift or camera adjustment is included. V1 and V2 inputs/receipts/images remain immutable.

INPUTS.json and PREPARED-CALLER.json bind exact bytes. Only after root review and performance/browser lane closure may root copy RELEASE-TEMPLATE.json to RELEASE.json, set its two release flags true without changing either hash, and run once:

```bash
python /workspace/shared/human-tailoring-v5-runtime-preview-V3-culling-policy-prepared-39687040336/capture_preview.py --release /workspace/shared/human-tailoring-v5-runtime-preview-V3-culling-policy-prepared-39687040336/RELEASE.json
```

No future corrected pixels or full garment/footwear fit, V5 canonical/LOD,2mmsole, period, photographic/world/occupied acceptance is established. V5 is still unapplied/canonically unqualified, T1789 and40 inherited negatives remain OPEN. No browser/server, app/Git/ref/ticket/CI/export/install or geometry action occurred in preparation.
