

### T-2980 — Wagon reproduction across Python runtimes, 2026-10-22

The covered-wagon CI gate exposed different built-in floating-point summation in Python 3.11 and 3.12. Ten floating sums in the two hardware helpers and covered core now use explicit math.fsum. Native 3.11 reproduces the reviewed authored-parts digest, final W01 and both covered GLBs exactly; root 3.12 production wrappers independently reproduce the same three shipped GLB byte streams. The original failure, unchanged-core secondary failure and corrected proofs are retained. Every original raw-parts, parent and final-product hash guard and recipe remains intact. Only the three sidecars' source-code hashes and their SOURCE manifests are refreshed. Geometry, materials, textures, individual finishes, placement, budgets and runtime JavaScript are unchanged. This repairs reproducibility; it adds no photographic, occupied or motion acceptance.
