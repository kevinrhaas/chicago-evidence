// SPDX-License-Identifier: GPL-3.0-or-later
// Prepared only. Invoke through the hash-bound, root-released Python owner.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const{chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
const ROOT=__dirname,OUT=path.join(ROOT,'actual'),port=Number(process.argv[2]);
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
if(!fs.existsSync(path.join(ROOT,'RUN-INTENT.json')))throw Error('Root-released owner required');
if(!Number.isInteger(port)||port<1||port>65535)throw Error('Invalid owned port');
fs.mkdirSync(OUT);let browser=null;
const result={scope:'Finite same-camera original-light V9/V10 roof-only source preview;12normal fullvehicle browser screenshots. Not plate pixel match, photographic, mainworld, collision, LOD or occupied acceptance.',started:new Date().toISOString(),pass:false,rows:[],errors:[],disposal:[],browserClosed:false,expectedImages:12,inputs_manifest_sha256:hash(path.join(ROOT,'INPUTS.json')),caller_sha256:hash(__filename)};
const save=()=>fs.writeFileSync(path.join(OUT,'receipt.json'),JSON.stringify(result,null,2));
const need=(yes,msg)=>{if(!yes)throw Error(msg);};
let watchdog=setTimeout(()=>{result.error='165second owned browser deadline';save();browser?.close().finally(()=>process.exit(124));},165000);
(async()=>{
 try{
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox'],timeout:15000});
  const inputs=JSON.parse(fs.readFileSync(path.join(ROOT,'INPUTS.json'))),bindings=new Map();
  for(const[viewport,width,height]of[['desktop',1280,800],['mobile',390,780]]){
   for(const version of['v9','v10']){
    const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:1});
    const note=(kind,message)=>{result.errors.push({viewport,version,kind,message,at:new Date().toISOString()});save();};
    page.on('pageerror',e=>note('page',e.message));page.on('console',m=>{if(m.type()==='error')note('console',m.text());});
    page.on('requestfailed',r=>note('request',r.url()+': '+r.failure()?.errorText));page.on('response',r=>{if(r.status()>=400)note('http',r.status()+' '+r.url());});
    await page.route('**/*',route=>{const u=new URL(route.request().url());return ['data:','blob:'].includes(u.protocol)||(u.protocol==='http:'&&u.hostname==='127.0.0.1'&&u.port===String(port))?route.continue():route.abort('blockedbyclient');});
    await page.goto(`http://127.0.0.1:${port}/transport/${version}/`,{waitUntil:'load',timeout:15000});
    await page.waitForFunction(()=>window.broughamReady&&window.setFullComparisonView,null,{timeout:15000});
    const loadedHash=await page.evaluate(()=>comparisonInputHash()),expected=inputs.files.find(x=>x.path===`fixture/transport/${version}/brougham.glb`).sha256;
    need(loadedHash===expected,'Runtime GLB hash mismatch');
    for(const view of['quarter','front','profile']){
     const key=viewport+':'+view,binding=bindings.get(key)||null;
     const row=await page.evaluate(({view,binding})=>{const r=setFullComparisonView(view,binding),c=document.querySelector('canvas').getBoundingClientRect(),h=document.querySelector('header').getBoundingClientRect(),last=document.querySelector('header p:last-child').getBoundingClientRect();return{...r,dom:{canvas:c.toJSON(),header:h.toJSON(),lastText:last.toJSON(),viewport:[innerWidth,innerHeight]}};},{view,binding});
     if(!binding)bindings.set(key,row);
     need(row.glError===0&&result.errors.length===0,'Actual GL/browser error');need(row.sourceTriangles===30782&&row.poleVisible,'Actual geometry/pole guard');
     need(row.framing.entireSelectedBoundsInside&&row.framing.ndcMin.slice(0,2).every(x=>x>=-.98)&&row.framing.ndcMax.slice(0,2).every(x=>x<=.98),'Fullvehicle framing guard');
     need(row.dom.canvas.right<=width+1&&row.dom.canvas.bottom<=height+1&&row.dom.header.bottom<=row.dom.canvas.top+1&&row.dom.lastText.bottom<=row.dom.canvas.top+1,'Normal viewport/header guard');
     need(row.lighting.shadowsEnabled&&row.lighting.sun.normalBias===0&&row.lighting.sun.bias===-.0002&&row.lighting.exposure===1.3,'Original lighting guard');
     await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
     const png=`${viewport}-${version}-${view}.png`;await page.screenshot({path:path.join(OUT,png),timeout:10000});
     result.rows.push({viewport,version,view,normalBrowserScreenshot:true,png,image_sha256:hash(path.join(OUT,png)),loaded_model_sha256:loadedHash,samePoseAsV9:version==='v9'?null:JSON.stringify(row.camera)===JSON.stringify(binding.camera),...row});save();
    }
    result.disposal.push({viewport,version,...await page.evaluate(()=>disposeComparison())});save();await page.close();
   }
  }
  need(result.rows.length===12&&result.disposal.length===4&&result.errors.length===0,'Finite completeness/error guard');result.pass=true;
 }catch(e){result.error=String(e.stack||e);process.exitCode=1;}
 finally{clearTimeout(watchdog);if(browser){await browser.close();result.browserClosed=true;}result.finished=new Date().toISOString();save();}
 if(!result.pass)throw Error(result.error);console.log('PASS12finite original-light V9/V10 captures;owned browser closed;photographic acceptance OPEN.');
})().catch(e=>{console.error(e);process.exitCode=1;});
