from pathlib import Path
import shutil,json,hashlib,datetime
HERE=Path(__file__).parent
SRC=Path('/workspace/shared/studebaker-brougham-v10-roof-source-20261021')
OLD=Path('/workspace/shared/studebaker-brougham-1904-2026-10-21/reference-inspection-v9-paired')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cap=Path('/workspace/shared/STUDEBAKER-BROUGHAM-V10-ROOF-SOURCE-UNRENDERED-20261021.tar.gz')
assert sha(cap)=='2c00175cc07410688e17fdb87cbb25ff5ca089795bd8606a9ffdf0b7f5605bcf'
manifest=json.loads((SRC/'MANIFEST.json').read_text())
for n,v in manifest.items():assert (SRC/n).stat().st_size==v['bytes'] and sha(SRC/n)==v['sha256'],n
for v,part in [('v9','baseline'),('v10','candidate')]:
 d=HERE/'fixture/transport'/v;d.mkdir(parents=True,exist_ok=True)
 shutil.copy2(SRC/part/'brougham.glb',d/'brougham.glb')
 shutil.copy2(SRC/'proposed/camera-hypothesis.json',d/'camera-hypothesis.json')
 original=OLD/'fixture/transport/brougham-v9'
 shutil.copy2(original/'index.html',d/'index.html')
 (d/'demo.js').write_bytes((original/'demo.js').read_bytes()+(HERE/'compare-extension.js').read_bytes())
 assert (d/'demo.js').read_bytes().startswith((original/'demo.js').read_bytes())
shutil.copytree(OLD/'fixture/vendor',HERE/'fixture/vendor',dirs_exist_ok=True)
proof=HERE/'source-proof';proof.mkdir(exist_ok=True)
for n in ['README-HANDOFF.md','SOURCE-GEOMETRY-AUDIT.json','KHRONOS.json','MANIFEST.json','LICENSE','reference/studebaker-brougham-cdn.jpg','reference/PROPOSED-SOURCE-RECORD-NOT-APP-INSTALLED.json','reference/BROUGHAM-UPPER-REAR-QUARTER-RULING.md']:
 p=proof/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(SRC/n,p)
originals=HERE/'previous-caller-readonly';originals.mkdir(exist_ok=True)
for s,n in [(OLD/'capture.cjs','capture.cjs'),(OLD/'fixture/transport/brougham-v9/demo.js','demo.js'),(OLD/'fixture/transport/brougham-v9/index.html','index.html')]:shutil.copy2(s,originals/n)
rows=[{'path':str(p.relative_to(HERE)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(HERE.rglob('*')) if p.is_file() and ('fixture' in p.parts or 'source-proof' in p.parts or 'previous-caller-readonly' in p.parts)]
(HERE/'INPUTS.json').write_text(json.dumps({'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'capsule_sha256':sha(cap),'source_manifest_entries_verified':len(manifest),'baseline_v9_matches_previous_actual_fixture':(SRC/'baseline/brougham.glb').read_bytes()==(OLD/'fixture/transport/brougham-v9/brougham.glb').read_bytes(),'camera_hypothesis_exact_v9_v10_previous_fixture':(SRC/'preimage/camera-hypothesis.json').read_bytes()==(SRC/'proposed/camera-hypothesis.json').read_bytes()==(OLD/'fixture/transport/brougham-v9/camera-hypothesis.json').read_bytes(),'files':rows},indent=2)+'\n')
print('Prepared',len(rows),'pinned files; no browser or server launched.')
