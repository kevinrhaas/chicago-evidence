# Exact frozen V5 unpruned field diagnostic — closed

One separately root-released read-only pass closed exit0 in2.280858wall seconds. It transparently observed the ORIGINAL V5 solver return and returned that unchanged. Reconstruction of the unpruned class field reproduced every original four-weight joint/weight array exactly before evaluating the same65poses/all3meshes. No alternative field, solver parameter, source, pose or threshold was used.

Both versions fail the original deformation screen. Unpruned body edges .759237–1.211062 / areas .398214–1.457164; actual four-weight body edges .756937–1.204688 / areas .399403–1.453721. Neither has negative rest-relative triangle-normal dots. Four-weight reduction changes vertices by at most2.760291mm across all samples. It is not the main cause of the remaining deformation; its exact effects and every worst edge/area/normal witness are preserved in ACTUAL-UNPRUNED-VS-FOUR.json.

The actual worst compressed edge3253→3247 has74.804mm rest length and about20mm weight-gradient displacement at.25s. Vertex3253 retainsbody.998428/neck.001572 and is a V5 HARD anchor only because its tiny neck influence exceeds1e-8. Nearby3247 is body.781 plus limb fields. Worst collapsed triangle5342 similarly includes3255,body.99949 plus tiny neck. Treating incidental neck influence as hard ownership is an implementation error, not anatomical evidence.

The next separately authorized V6 changes ONLY hard-anchor ownership to an original head/neck/tail joint that strictly dominates every original body/limb joint, with exact ties reported rather than guessed. V5 source and all actual files remain immutable. No accepted gait, GLB/animation export or app change follows from this diagnostic.
