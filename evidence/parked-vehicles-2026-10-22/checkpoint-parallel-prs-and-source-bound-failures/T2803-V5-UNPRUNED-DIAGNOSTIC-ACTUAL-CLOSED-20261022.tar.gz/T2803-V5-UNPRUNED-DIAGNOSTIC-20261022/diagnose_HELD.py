"""ONE separately released read-only frozen-V5 field-vs-four-weight diagnosis."""
import pathlib,json,hashlib,sys,time
import numpy as np
P=pathlib.Path(__file__).resolve().parent;S=pathlib.Path('/workspace/shared/T2803-V4-INDEPENDENT-SKIN-REVIEW-20261022');sys.path.insert(0,str(S));start=time.monotonic()
release=json.loads(pathlib.Path(sys.argv[1]).read_text());assert release.get('released') is True and release.get('authorization')=='ONE_ROOT_V5_UNPRUNED_DIAGNOSTIC';assert release['caller_sha256']==hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest();assert hashlib.sha256((S/'screened_harmonic_v5_HELD.py').read_bytes()).hexdigest()=='ce0ba29173f13e2de91fc04401a748800875005de8ec9761c3a5f3029ef057b9'
from actual_model import Model
import screened_harmonic_v5_HELD as candidate
m=Model(pathlib.Path('/workspace/shared/T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb'));assert hashlib.sha256(m.raw).hexdigest()=='03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36'
controls=json.loads((S/'RERIG-CONTROLS-PROPOSAL-V2.json').read_text());side=json.loads(pathlib.Path('/workspace/shared/horse-standing-intake-proposal-V2-20261022/proposed/data/transport/parked/horse-sevket-sidecar.json').read_text());ib=m.accessor(m.g['skins'][0]['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1);parts=[];rest=[]
for ni in [26,27,28]:
 pr=m.g['meshes'][m.g['nodes'][ni]['mesh']]['primitives'][0];a=pr['attributes'];parts.append((m.accessor(a['POSITION']).astype(float),m.accessor(a['NORMAL']).astype(float),m.accessor(a['JOINTS_0']).astype(int),m.accessor(a['WEIGHTS_0']).astype(float),m.accessor(pr['indices']).astype(int).reshape(-1,3)));rest.append(m.mesh(ni)[0])
patch={label:np.unique(parts[1][4][row['source_triangle_ids']].ravel())for label,row in side['contacts'].items()};capture={};original=candidate.spsolve
def observe(matrix,rhs):
 result=original(matrix,rhs);capture['solution']=result.copy();capture['shape']=matrix.shape;return result
candidate.spsolve=observe
try:four,solve=candidate.build(rest,parts,controls,patch)
finally:candidate.spsolve=original
# Reconstruct only the exact frozen builder's class/known indexing to read back
# the observed solution. No changed source field, solver argument or return.
keys={};members=[];points=[];vc=[]
for mi,ps in enumerate(rest):
 ids=[]
 for vi,p in enumerate(ps):
  key=tuple(np.rint(p/1e-6).astype(int))
  if key not in keys:keys[key]=len(points);points.append(p);members.append([])
  ci=keys[key];members[ci].append((mi,vi));ids.append(ci)
 vc.append(np.asarray(ids,dtype=int))
points=np.asarray(points);N=len(points);tri=np.concatenate([vc[mi][part[4]]for mi,part in enumerate(parts)]);tp=points[tri];area=np.linalg.norm(np.cross(tp[:,1]-tp[:,0],tp[:,2]-tp[:,0]),axis=1)/2;mass=np.zeros(N)
for k in range(3):np.add.at(mass,tri[:,k],area/3)
dense=np.zeros((N,26))
for ci,group in enumerate(members):
 mi,vi=group[0]
 for j,w in zip(parts[mi][2][vi],parts[mi][3][vi]):dense[ci,int(j)if j<6 else 1]+=w
dense/=dense.sum(1)[:,None];fixed=(points[:,1]>=1.14)|(dense[:,2:6].sum(1)>1e-8)|(mass<=0)
for label,ids in patch.items():
 classes=np.unique(vc[1][ids]);fixed[classes]=True;dense[classes]=0;dense[classes,controls['limbs'][label]['joints'][-1]]=1
unknown=np.flatnonzero(~fixed);assert len(unknown)==capture['solution'].shape[0];dense[unknown]=np.clip(capture['solution'],0,1);dense/=dense.sum(1)[:,None]
raw=[dense[x]for x in vc];four_dense=[]
for j,w in four:
 d=np.zeros((len(j),26));np.add.at(d,(np.arange(len(j))[:,None],j),w);four_dense.append(d)
expected_four=[]
for d in raw:
 order=np.argsort(-d,axis=1,kind='stable')[:,:4];w=np.take_along_axis(d,order,axis=1);w/=w.sum(1)[:,None];expected_four.append((order,w.astype(np.float32)))
assert all(np.array_equal(j,expected_four[mi][0])and np.array_equal(w,expected_four[mi][1])for mi,(j,w)in enumerate(four)),'Observed field reconstruction must reproduce exact frozen four-weight output'
frames_path=S/'AUTHORED-NATIVE-WALK-WEIGHT-V5-POSES.json';frames=json.loads(frames_path.read_text())['frames'];assert len(frames)==65
witnesses={version:{}for version in ['unpruned_frozen_field','actual_four_weight_output']};stats={version:[]for version in witnesses};max_position_difference=0.;bad_counts={version:{'edge_samples':0,'area_samples':0}for version in witnesses}
for mi,part in enumerate(parts):
 pos,normal,oldj,oldw,ix=part;p=np.c_[pos,np.ones(len(pos))];rt=rest[mi][ix];re=np.linalg.norm(rt[:,[1,2,0]]-rt[:,[0,1,2]],axis=2);rn=np.cross(rt[:,1]-rt[:,0],rt[:,2]-rt[:,0]);ra=np.linalg.norm(rn,axis=1);valid=re>1e-8;av=ra>1e-12;local={version:{'mesh':mi,'edge_min':1.,'edge_max':1.,'area_min':1.,'area_max':1.,'maximum_negative_normal_dot_count':0}for version in witnesses}
 for frame in frames:
  transform=np.asarray(frame['global_body_frame_matrices'])@ib;allpositions=np.einsum('kij,nj->nki',transform,p)[:,:,:3];unpruned=np.einsum('nk,nki->ni',raw[mi],allpositions);pruned=np.einsum('nk,nki->ni',four_dense[mi],allpositions);max_position_difference=max(max_position_difference,float(np.linalg.norm(pruned-unpruned,axis=1).max()))
  for version,moved,weights in [('unpruned_frozen_field',unpruned,raw[mi]),('actual_four_weight_output',pruned,four_dense[mi])]:
   t=moved[ix];edge=np.linalg.norm(t[:,[1,2,0]]-t[:,[0,1,2]],axis=2);ratio=np.divide(edge,re,out=np.ones_like(edge),where=valid);nn=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);aa=np.linalg.norm(nn,axis=1);ar=np.divide(aa,ra,out=np.ones_like(aa),where=av);cos=np.divide(np.einsum('ni,ni->n',rn,nn),ra*aa,out=np.ones_like(aa),where=ra*aa>1e-15);r=local[version];r['edge_min']=min(r['edge_min'],float(ratio.min()));r['edge_max']=max(r['edge_max'],float(ratio.max()));r['area_min']=min(r['area_min'],float(ar.min()));r['area_max']=max(r['area_max'],float(ar.max()));r['maximum_negative_normal_dot_count']=max(r['maximum_negative_normal_dot_count'],int(np.count_nonzero((cos<0)&av)));bad_counts[version]['edge_samples']+=int(np.count_nonzero(((ratio<.9)|(ratio>1.1))&valid));bad_counts[version]['area_samples']+=int(np.count_nonzero(((ar<.8)|(ar>1.2))&av))
   for metric,value,maximize in [('edge_max',ratio,True),('edge_min',ratio,False),('area_max',ar,True),('area_min',ar,False),('normal_min',cos,False)]:
    flat=int(np.argmax(value)if maximize else np.argmin(value));number=float(value.flat[flat]);old=witnesses[version].get(metric)
    if old is not None and ((number<=old['value'])if maximize else(number>=old['value'])):continue
    ti=flat//3 if value.ndim==2 else flat;ids=ix[ti];row={'mesh':mi,'triangle':int(ti),'time_s':frame['time_s'],'value':number,'vertices':[]}
    for vi in ids:row['vertices'].append({'id':int(vi),'rest_m':rest[mi][vi].tolist(),'posed_m':moved[vi].tolist(),'weights':[{'joint':int(ji),'name':controls['nodes'][ji]['name'],'weight':float(we)}for ji,we in enumerate(weights[vi])if we>1e-12]})
    if value.ndim==2:
     a,b=int(ids[flat%3]),int(ids[(flat%3+1)%3]);common=np.einsum('k,kij,j->i',weights[b],transform,p[b]-p[a])[:3];gradient=np.einsum('k,kij,j->i',weights[b]-weights[a],transform,p[a])[:3];row['edge']={'vertices':[a,b],'rest_length_m':float(re[ti,flat%3]),'weight_L1_jump':float(np.abs(weights[b]-weights[a]).sum()),'common_affine_edge_m':common.tolist(),'weight_gradient_term_m':gradient.tolist(),'gradient_magnitude_m':float(np.linalg.norm(gradient))}
    witnesses[version][metric]=row
 for version in witnesses:stats[version].append(local[version])
expected=json.loads((S/'ACTUAL-WALK-WEIGHT-V5-CPU-READBACK.json').read_text())['surfaces'][1];actual=stats['actual_four_weight_output'][1]
assert max(abs(actual[k]-expected[{'edge_min':'edge_ratio_min','edge_max':'edge_ratio_max','area_min':'area_ratio_min','area_max':'area_ratio_max'}[k]])for k in ['edge_min','edge_max','area_min','area_max'])<1e-10
result={'scope':'Exact frozenV5 unpruned field versus its actual four-weight output. Read-only solver observer returns original result unchanged; no alternative solve/field/pose/threshold.','caller_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((S/'screened_harmonic_v5_HELD.py').read_bytes()).hexdigest(),'poses_sha256':hashlib.sha256(frames_path.read_bytes()).hexdigest(),'poses':65,'source_classes':N,'exact_four_weight_reproduction':True,'maximum_vertex_position_difference_due_to_four_weight_reduction_m':max_position_difference,'pruning_receipt':solve,'surfaces':stats,'violating_sample_counts':bad_counts,'witnesses':witnesses,'accepted':False,'elapsed_s':time.monotonic()-start};(P/'ACTUAL-UNPRUNED-VS-FOUR.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['witnesses','pruning_receipt']},indent=2))
