# Semantic anchor V6 — actual precondition failure, closed

Root authorized one semantic change from frozenV5: a hard neck/head/tail owner must have genuine original joint dominance over all original body/limb joints, rather than merely ANY incidental influence above1e-8. Mesh/rest26joints/stride/65poses/screeninglength/deformationlimits remained unchanged. Exact dominance ties are disclosed and do not create a hard head/tail anchor.

The one actual nice19/math1 pass closed exit1 in0.577186wall seconds, before solving the field or evaluating the65poses. The actualsource3253/3255 tiny-neck fixture and genuine-neck/limb-dominant/tie controls passed. The next existing guard refused a disconnected unknown source component with no actual upper-trunk anchor. This is a PRECONDITION FAILURE, not a measured V6 skin-deformation verdict. No retry, numerical candidate/threshold tuning or source edit followed.

Actual component/material ownership must be audited before a fix. The model primitives identify Hair12Main2k, HorseMain4k00 and Eye_brown. A disconnected mane/tail surface may legitimately retain its original source ownership independent of body/limb dominance, but this is currently a hypothesis; the offending component has not been classified. Do not drop the finite-geodesic guard or blindly hard-pin every disconnected vertex.

V4/V5 original failures and the exact diagnostic remain preserved. V6 candidateee5c2e6a…/callerd981cdd0… and actual release/terminal/fixture are in this capsule. No accepted weights, exported asset, rendered gait, app change, ticket closure or merge qualification.
