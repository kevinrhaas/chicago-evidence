import json,sys,pathlib,hashlib,time
import numpy as np
start=time.monotonic();src=pathlib.Path('/workspace/shared/T2803-WALK-WEIGHT-DIAGNOSIS-20261022');out=pathlib.Path(__file__).parent;sys.path.insert(0,str(src))
from actual_model import Model
from harmonic_weight_candidate_v4 import build
assert hashlib.sha256((src/'harmonic_weight_candidate_v4.py').read_bytes()).hexdigest()=='cba3336bbd781641acd2936b3834d75648556a0e5f3aa060e92be9573e72eec8'
m=Model(pathlib.Path('/workspace/shared/T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb'));assert hashlib.sha256(m.raw).hexdigest()=='03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36'
controls=json.loads((src/'RERIG-CONTROLS-PROPOSAL-V2.json').read_text());side=json.loads(pathlib.Path('/workspace/shared/horse-standing-intake-proposal-V2-20261022/proposed/data/transport/parked/horse-sevket-sidecar.json').read_text());ib=m.accessor(m.g['skins'][0]['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1);parts=[];rest=[]
for ni in [26,27,28]:
 pr=m.g['meshes'][m.g['nodes'][ni]['mesh']]['primitives'][0];a=pr['attributes'];parts.append((m.accessor(a['POSITION']).astype(float),m.accessor(a['NORMAL']).astype(float),m.accessor(a['JOINTS_0']).astype(int),m.accessor(a['WEIGHTS_0']).astype(float),m.accessor(pr['indices']).astype(int).reshape(-1,3)));rest.append(m.mesh(ni)[0])
patch={label:np.unique(parts[1][4][row['source_triangle_ids']].ravel())for label,row in side['contacts'].items()};arrays,solve=build(rest,parts,controls,patch);frames=json.loads((src/'AUTHORED-NATIVE-WALK-WEIGHT-V4-POSES.json').read_text())['frames'];pos=parts[1][0];ix=parts[1][4];j,w=arrays[1];dense=np.zeros((len(pos),26));np.add.at(dense,(np.arange(len(pos))[:,None],j),w);p=np.c_[pos,np.ones(len(pos))];tri=rest[1][ix];edge=np.linalg.norm(tri[:,[1,2,0]]-tri[:,[0,1,2]],axis=2);rn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);ra=np.linalg.norm(rn,axis=1);best={}
for frame in frames:
 transforms=np.asarray(frame['global_body_frame_matrices'])@ib;blend=np.einsum('nw,nwij->nij',w,transforms[j]);moved=np.einsum('nij,nj->ni',blend,p)[:,:3];t=moved[ix];rat=np.linalg.norm(t[:,[1,2,0]]-t[:,[0,1,2]],axis=2)/edge;nn=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);area=np.linalg.norm(nn,axis=1);ar=np.divide(area,ra,out=np.ones_like(area),where=ra>1e-12);cos=np.divide(np.einsum('ni,ni->n',rn,nn),ra*area,out=np.ones_like(area),where=ra*area>1e-15)
 for metric,v,maximize in [('edge_max',rat,True),('edge_min',rat,False),('area_max',ar,True),('area_min',ar,False),('normal_min',cos,False)]:
  k=int(np.argmax(v) if maximize else np.argmin(v));value=float(v.flat[k]);old=best.get(metric)
  if old is not None and ((value<=old['value']) if maximize else (value>=old['value'])):continue
  ti=k//3 if v.ndim==2 else k;ids=ix[ti];row={'value':value,'time_s':frame['time_s'],'triangle':int(ti),'vertices':[],'rest_area_twice_m2':float(ra[ti])}
  for vi in ids:
   row['vertices'].append({'id':int(vi),'rest_m':rest[1][vi].tolist(),'posed_m':moved[vi].tolist(),'weights':[{ 'joint':int(a),'name':controls['nodes'][int(a)]['name'],'weight':float(b),'pose_matrix':transforms[int(a)].tolist(),'displacement_at_vertex_m':(transforms[int(a)]@p[vi]-p[vi])[:3].tolist()}for a,b in zip(j[vi],w[vi])if b>0]})
  if v.ndim==2:
   a=int(ids[k%3]);b=int(ids[(k%3+1)%3]);delta=p[b]-p[a];common=np.einsum('n,nij,j->i',dense[b],transforms,delta)[:3];gradient=np.einsum('n,nij,j->i',dense[b]-dense[a],transforms,p[a])[:3];actual=moved[b]-moved[a]
   row['edge']={'ids':[a,b],'rest_length_m':float(np.linalg.norm(rest[1][b]-rest[1][a])),'posed_length_m':float(np.linalg.norm(actual)),'weight_L1_jump':float(np.abs(dense[b]-dense[a]).sum()),'common_affine_edge_m':common.tolist(),'weight_gradient_term_m':gradient.tolist(),'gradient_magnitude_m':float(np.linalg.norm(gradient)),'decomposition_residual_m':float(np.linalg.norm(actual-common-gradient))}
  best[metric]=row
result={'scope':'ONE read-only exact V4 witness diagnostic. No candidate, modified weights, geometry export or acceptance.','actual_rig_sha256':hashlib.sha256(m.raw).hexdigest(),'candidate_source_sha256':hashlib.sha256((src/'harmonic_weight_candidate_v4.py').read_bytes()).hexdigest(),'poses_sha256':hashlib.sha256((src/'AUTHORED-NATIVE-WALK-WEIGHT-V4-POSES.json').read_bytes()).hexdigest(),'pose_count':len(frames),'body_vertices':len(pos),'body_triangles':len(ix),'maximum_nonzero_influences':int(np.count_nonzero(dense,axis=1).max()),'witnesses':best,'elapsed_s':time.monotonic()-start}
(out/'ACTUAL-V4-WITNESSES.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'elapsed_s':result['elapsed_s'],'witnesses':{k:{x:v for x,v in r.items()if x!='vertices'}for k,r in best.items()}},indent=2))
