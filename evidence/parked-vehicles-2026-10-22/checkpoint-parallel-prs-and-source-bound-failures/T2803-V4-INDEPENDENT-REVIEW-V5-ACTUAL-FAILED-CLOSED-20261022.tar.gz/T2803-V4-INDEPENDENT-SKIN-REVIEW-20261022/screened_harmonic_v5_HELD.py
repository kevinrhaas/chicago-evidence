"""HELD counterfactual: source-surface screened weights, no ROI body clamps.

Only hoof contacts and actual upper-trunk/head/tail source anchors are hard.
Bone capsule targets are soft. Positive area/edge² conductance with lumped
triangle mass gives a physical screened-Poisson length scale. The scale is the
actual median reconstructed proximal-link length, not a trial fit to the gate.
No anatomical, deformation, serialization, gait or visual acceptance follows
from solving this field. Actual post-four-weight pose screens remain required.
"""
import numpy as np
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import spsolve
from scipy.sparse.csgraph import dijkstra
DECLARED={'version':'V5_HELD_GLOBAL_SCREENED_SURFACE_WEIGHTS','maximum_influences':4,'seam_position_quantization_m':1e-6,'maximum_seam_class_spread_m':2e-6,'hard_upper_trunk_y_m':1.14,'proximal_capsule_radius_m':.13,'lower_capsule_radius_m':.12,'distal_capsule_radius_m':.13,'screening_length':'median actual reconstructed proximal segment length','body_prior_length':'same actual proximal segment length','kernel':'C2 Wendland (1-r)^4*(4r+1), r<1; otherwise0','signed_x_or_z_ROI_hard_boundary':False,'nonhoof_bone_Dirichlet_handles':False,'physical_gradient_bound':'NOT guaranteed by smoothness; disclose edge weight jumps and require unchanged actual65pose edge/area/normal/ground/hoof/seam screens','original_gait_and_thresholds_unchanged':True}
def build(rest,parts,controls,hoof_patch_ids):
 keys={};members=[];points=[];vc=[]
 for mi,ps in enumerate(rest):
  ids=[]
  for vi,p in enumerate(ps):
   key=tuple(np.rint(p/1e-6).astype(int))
   if key not in keys:keys[key]=len(points);points.append(p);members.append([])
   ci=keys[key];members[ci].append((mi,vi));ids.append(ci)
  vc.append(np.asarray(ids,dtype=int))
 points=np.asarray(points);N=len(points);spread=max(np.linalg.norm(rest[mi][vi]-points[ci])for ci,group in enumerate(members)for mi,vi in group);assert spread<=2e-6
 tri=np.concatenate([vc[mi][part[4]]for mi,part in enumerate(parts)]);tp=points[tri];area=np.linalg.norm(np.cross(tp[:,1]-tp[:,0],tp[:,2]-tp[:,0]),axis=1)/2;mass=np.zeros(N)
 for k in range(3):np.add.at(mass,tri[:,k],area/3)
 rawedge=np.concatenate([np.sort(tri[:,[a,b]],axis=1)for a,b in [(0,1),(1,2),(2,0)]]);areaedge=np.tile(area/3,3);valid=(rawedge[:,0]!=rawedge[:,1])&(areaedge>0);rawedge,areaedge=rawedge[valid],areaedge[valid];edges,inverse=np.unique(rawedge,axis=0,return_inverse=True);u,v=edges.T;length=np.linalg.norm(points[u]-points[v],axis=1);assert np.all(length>1e-8);conductance=np.zeros(len(edges));np.add.at(conductance,inverse,areaedge/(np.linalg.norm(points[rawedge[:,0]]-points[rawedge[:,1]],axis=1)**2));assert np.all(conductance>0)
 graph=coo_matrix((np.r_[conductance,conductance],(np.r_[u,v],np.r_[v,u])),shape=(N,N)).tocsr();lap=diags(np.asarray(graph.sum(1)).ravel())-graph;metric=coo_matrix((np.r_[length,length],(np.r_[u,v],np.r_[v,u])),shape=(N,N)).tocsr()
 baseline=np.zeros((N,26))
 for ci,group in enumerate(members):
  mi,vi=group[0]
  for j,w in zip(parts[mi][2][vi],parts[mi][3][vi]):baseline[ci,int(j)if j<6 else 1]+=w
 baseline/=baseline.sum(1)[:,None]
 fixed=(points[:,1]>=DECLARED['hard_upper_trunk_y_m'])|(baseline[:,2:6].sum(1)>1e-8)|(mass<=0);trunk=(points[:,1]>=DECLARED['hard_upper_trunk_y_m'])&(baseline[:,1]>.999999);assert trunk.any()
 piv=np.asarray([r['rest_world_pivot_m']for r in controls['nodes']]);limbs=controls['limbs'];ell=float(np.median([np.linalg.norm(piv[row['joints'][1]]-piv[row['joints'][0]])for row in limbs.values()]));assert .1<ell<.6
 distance=dijkstra(metric,directed=False,indices=np.flatnonzero(trunk),min_only=True);unknown=np.flatnonzero(~fixed);assert np.isfinite(distance[unknown]).all(),'Disconnected unknown source component lacks actual trunk anchor'
 target=np.zeros((N,26));target[:,1]=np.exp(-(distance/ell)**2)
 def score(a,b,radius):
  delta=b-a;t=np.clip((points-a)@delta/(delta@delta),0,1);r=np.linalg.norm(points-a-t[:,None]*delta,axis=1)/radius;q=np.maximum(0,1-r);return q**4*(4*r+1)
 for label,row in limbs.items():
  a,b,c,d,e=row['joints']
  for joint,start,end,radius in [(a,a,b,.13),(b,b,c,.12),(e,c,e,.13)]:target[:,joint]+=score(piv[start],piv[end],radius)
 # Only explicit annotated rigid hoof patches override the source anchors.
 hoof={label:np.unique(vc[1][ids])for label,ids in hoof_patch_ids.items()}
 for label,classes in hoof.items():
  joint=limbs[label]['joints'][-1];fixed[classes]=True;baseline[classes]=0;baseline[classes,joint]=1
 unknown=np.flatnonzero(~fixed);known=np.flatnonzero(fixed);assert np.all(target[unknown].sum(1)>0);target[unknown]/=target[unknown].sum(1)[:,None]
 screen=mass/(ell*ell);assert np.all(screen[unknown]>0);matrix=(lap[unknown][:,unknown]+diags(screen[unknown])).tocsc();rhs=-(lap[unknown][:,known]@baseline[known])+screen[unknown,None]*target[unknown];solution=spsolve(matrix,rhs);residual=float(np.abs(matrix@solution-rhs).max());assert np.isfinite(solution).all()and residual<1e-8;assert solution.min()>=-1e-9 and solution.max()<=1+1e-9;assert np.abs(solution.sum(1)-1).max()<1e-8
 dense=baseline.copy();dense[unknown]=np.clip(solution,0,1);dense/=dense.sum(1)[:,None];order=np.argsort(-dense,axis=1,kind='stable')[:,:4];w=np.take_along_axis(dense,order,axis=1);kept=w.sum(1);removed=1-kept;w/=kept[:,None];w=w.astype(np.float32);j=order.astype(np.uint16);pruned=np.zeros_like(dense);np.add.at(pruned,(np.arange(N)[:,None],j),w)
 for label,classes in hoof.items():assert np.all(np.where(j[classes]==limbs[label]['joints'][-1],w[classes],0).sum(1)==1)
 jumps=np.abs(pruned[u]-pruned[v]).sum(1);worst=int(np.argmax(jumps/length));arrays=[(j[x].astype(int),w[x].astype(float))for x in vc]
 return arrays,{'status':'HELD candidate source; numerical solution is not skin or gait acceptance','method':DECLARED,'classes':N,'edges':len(edges),'physical_screening_length_m':ell,'hard_source_anchor_classes':len(known),'unknown_classes':len(unknown),'maximum_harmonic_residual_abs':residual,'maximum_class_spread_m':float(spread),'maximum_discarded_mass_before_4_weight_renormalization':float(removed.max()),'discarded_mass_p95':float(np.quantile(removed,.95)),'maximum_post_pruning_edge_weight_L1_jump':float(jumps.max()),'maximum_post_pruning_edge_weight_L1_per_m':float((jumps/length).max()),'worst_weight_gradient_edge_class_ids':edges[worst].tolist(),'gait_and_deformation_assertions_changed':False,'anatomical_or_visual_qualification':False}
