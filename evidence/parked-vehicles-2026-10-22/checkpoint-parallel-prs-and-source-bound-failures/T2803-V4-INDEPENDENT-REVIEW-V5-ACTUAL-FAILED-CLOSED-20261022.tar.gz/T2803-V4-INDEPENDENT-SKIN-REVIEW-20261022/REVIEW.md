# Independent horse walk skin review — actual V5 failure, closed

The V4 harmonic interpolation was infeasible at 26 edges before its interior solve began. Hard BODY values and hard bone-handle values directly shared triangle edges. Positive interpolation of unknown vertices cannot alter those endpoints.

The actual worst source edge is body-mesh triangle5408, vertices3294→3295 at1.05s. Its25.772854mm rest length becomes120.651195mm (4.681328×). Vertex3294 is100%horse_body;3295 is100%fore_l_shoulder. The107.272063mm weight-gradient term dominates the ordinary transformed25.77mm edge; the decomposition residual is8.17e-17m. This is a real centimeter-scale edge, not a degenerate-edge or floating-point artifact. Final max4 truncation is not V4's cause: its fields already have at most4nonzero weights.

The one independent actual witness pass closed exit0 in0.6395s. A separately root-authorized paired audit/V5pass closed exit2 in6.2598wall seconds (3.5032s reported caller evaluation), without timeout or retry. Every owned process is closed.

## Complete hard-handle audit

All26body triangle edges whose endpoints had differing exact hard joint labels violate the original pointwise edge bounds over the frozen65poses:12BODY/fore-left-shoulder,12BODY/fore-right-shoulder and2BODY/hind-left-hip. ACTUAL-V4-CONTRADICTORY-HANDLES.json records every actual edge and its original pose extrema. The source's signed-X/Z/radius compartment boundary and broad proximal handle selection put incompatible rigid values next to one another. This audit does not infer anatomy from section boxes or call a rest-relative normal dot an intersection proof.

## One principled V5 source experiment — improved, still FAILED

V5 removes artificial signed-X/Z/radius BODY Dirichlet cuts. Exact hoof patches and existing upper-trunk/head/tail anchors remain hard; proximal/lower/distal controls become soft C2 capsule priors. The positive source graph uses triangle area/edge-length² conductance and lumped triangle mass. Its screened-Poisson length0.326395563m is the actual median reconstructed proximal-link length, not a trial-selected gate fit. The body prior uses true source-edge geodesic distance. Source mesh,26joint rest/bind,65poses,240mmstride and all earlier numerical acceptance limits remain unchanged.

Actual body edge ratios improve from V4 .4034–4.6813 toV5 .756937–1.204688. Area ratios improve from .02015–4.72654 to .399403–1.453721. Rest-relative negative normal-dot count falls from5to0. These improvements DO NOT satisfy the unchanged .9–1.1edge/.8–1.2area limits. Walk acceptance staysfalse. No GLB or animation export, app edit, rendered gait, anatomical or photographic acceptance occurred.

Neutral position error95.23nm, all stance/segment/loop/finite/seam controls and their original meaningful corruptions still pass. Hoof evidence covers only the original annotated patches, not complete soles, forces or load transfer.

V5's final four-weight reduction discards up to4.615929%mass (p95 .225083%). That is disclosed, not identified as the remaining cause. A future diagnostic should compare the exact unpruned field and four-weight output under these same poses and collect actual worst-edge/area witnesses before any further weight proposal. Do not retune screening length, stride or assertions by repeated guesses.

## Reproducibility and recovery

Source GLB03a1f747…/original host41acd9be… and immutable V4 sourcecba3336b… retain their original provenance and source-capsule ownership. Their binary inputs already live in the earlier parent checkpoints; this compact capsule contains no replacement asset. Local copies of actual_model.py, walk_source.py and controls are byte copies of the earlier source. V5 candidatece0ba291… and caller7a469661… were pinned before the single released run. RELEASE-TEMPLATE-HELD.json staysfalse; RELEASED-V5-ROOT.json records the actual separate authorization. An AST-only authoring typo was corrected before any import/evaluation and preserved in its own file. Original V2/V3/V4 failure/source capsules were untouched.

The original all-part parent app/DEV qualifications are outside this source-only review. No ticket closure or merge qualification is supplied here.
