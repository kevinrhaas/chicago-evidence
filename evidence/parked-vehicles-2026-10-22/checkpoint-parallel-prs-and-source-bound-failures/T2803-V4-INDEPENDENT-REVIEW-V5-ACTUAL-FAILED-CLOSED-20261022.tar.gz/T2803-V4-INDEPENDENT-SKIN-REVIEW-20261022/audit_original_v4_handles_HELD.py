"""HELD read-only audit of every contradictory adjacent hard V4 handle.
No altered candidate fields; source V4 weights and all frozen65 poses only.
"""
import importlib.util,pathlib,hashlib
import numpy as np
SOURCE=pathlib.Path('/workspace/shared/T2803-WALK-WEIGHT-DIAGNOSIS-20261022/harmonic_weight_candidate_v4.py')
def audit(rest,parts,controls,hoof_patch_ids,frames,ib):
 assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()=='cba3336bbd781641acd2936b3834d75648556a0e5f3aa060e92be9573e72eec8'
 spec=importlib.util.spec_from_file_location('immutable_original_v4_weights',SOURCE);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);arrays,unused=module.build(rest,parts,controls,hoof_patch_ids)
 keys={};points=[];vc=[]
 for ps in rest:
  ids=[]
  for p in ps:
   key=tuple(np.rint(p/1e-6).astype(int))
   if key not in keys:keys[key]=len(points);points.append(p)
   ids.append(keys[key])
  vc.append(np.asarray(ids,dtype=int))
 points=np.asarray(points);N=len(points);limbs=controls['limbs'];names=list(limbs);piv=np.asarray([x['rest_world_pivot_m']for x in controls['nodes']]);domain=np.full(N,-1,dtype=int)
 for ci,(x,y,z)in enumerate(points):
  if y>=1.14 or abs(x)<=.04 or abs(z)<=.10:continue
  label=('fore_'if z>0 else'hind_')+('l'if x>0 else'r');ids=limbs[label]['joints'];ordered=ids[::-1];center=np.array([np.interp(y,piv[ordered,1],piv[ordered,k])for k in [0,2]])
  if np.linalg.norm(np.asarray([x,z])-center)<.30:domain[ci]=names.index(label)
 tris=np.concatenate([vc[mi][part[4]]for mi,part in enumerate(parts)]);edges=np.unique(np.concatenate([np.sort(tris[:,[a,b]],axis=1)for a,b in [(0,1),(1,2),(2,0)]]),axis=0);u,v=edges.T;boundary=np.zeros(N,dtype=bool);mask=domain[u]!=domain[v];boundary[u[mask]]=True;boundary[v[mask]]=True;kind=np.full(N,'OUTSIDE_DOMAIN',dtype=object);hard=domain<0
 def segment(ps,a,b):
  d=b-a;t=np.clip((ps-a)@d/(d@d),0,1);return np.linalg.norm(ps-a-t[:,None]*d,axis=1),t
 for di,label in enumerate(names):
  a,b,c,d,e=limbs[label]['joints'];region=np.flatnonzero(domain==di);eligible=region[~boundary[region]];kind[region]='HARMONIC_UNKNOWN';hard[region[boundary[region]]]=True;kind[region[boundary[region]]]='BODY_DOMAIN_BOUNDARY';dist,t=segment(points[eligible],piv[a],piv[b]);upper=eligible[(dist<.13)&(t>=.25)&(t<=.75)];dist,t=segment(points[eligible],piv[b],piv[c]);lower=eligible[(dist<.12)&(t>=.25)&(t<=.75)];distal=np.union1d(eligible[points[eligible,1]<=.30],vc[1][hoof_patch_ids[label]])
  for label2,ids in [('PROXIMAL_HANDLE',upper),('LOWER_HANDLE',lower),('RIGID_DISTAL_HANDLE',distal)]:hard[ids]=True;kind[ids]=label2
 # Actual body triangle edges; duplicate UV vertices remain actual source ids.
 tri=parts[1][4];be=np.unique(np.concatenate([np.sort(tri[:,[a,b]],axis=1)for a,b in [(0,1),(1,2),(2,0)]]),axis=0);j,w=arrays[1];pure=np.where(np.max(w,axis=1)>=1-1e-7,j[np.arange(len(j)),np.argmax(w,axis=1)],-1);a,b=be.T;good=hard[vc[1][a]]&hard[vc[1][b]]&(pure[a]>=0)&(pure[b]>=0)&(pure[a]!=pure[b]);be=be[good];a,b=be.T;pa=np.c_[parts[1][0][a],np.ones(len(a))];pb=np.c_[parts[1][0][b],np.ones(len(b))];length=np.linalg.norm(rest[1][b]-rest[1][a],axis=1);assert np.all(length>1e-8);mx=np.ones(len(a));mn=np.ones(len(a));times=np.zeros(len(a));positions={}
 for frame in frames:
  t=np.asarray(frame['global_body_frame_matrices'])@ib;ma=np.einsum('nij,nj->ni',t[pure[a]],pa)[:,:3];mb=np.einsum('nij,nj->ni',t[pure[b]],pb)[:,:3];ratio=np.linalg.norm(mb-ma,axis=1)/length;update=ratio>mx;mx=np.maximum(mx,ratio);mn=np.minimum(mn,ratio);times[update]=frame['time_s']
 failed=(mx>1.1)|(mn<.9);rows=[];pairs={}
 for k in np.flatnonzero(failed):
  va,vb=int(a[k]),int(b[k]);ja,jb=int(pure[va]),int(pure[vb]);pair=' / '.join(sorted([controls['nodes'][ja]['name'],controls['nodes'][jb]['name']]))
  rows.append({'vertices':[va,vb],'classes':[int(vc[1][va]),int(vc[1][vb])],'joint_ids':[ja,jb],'handle_types':[str(kind[vc[1][va]]),str(kind[vc[1][vb]])],'rest_edge_length_m':float(length[k]),'actual_ratio_min':float(mn[k]),'actual_ratio_max':float(mx[k]),'maximum_ratio_time_s':float(times[k])});group=pairs.setdefault(pair,{'edge_count':0,'ratio_min':1.,'ratio_max':1.});group['edge_count']+=1;group['ratio_min']=min(group['ratio_min'],float(mn[k]));group['ratio_max']=max(group['ratio_max'],float(mx[k]))
 return {'scope':'Actual hard V4 handle contradictions; no changed candidate or acceptance','actual_body_triangle_count':len(tri),'all_disagreeing_pure_hard_joint_edges':len(be),'hard_edges_infeasible_under_original_pointwise_edge_bounds':int(failed.sum()),'by_joint_pair':pairs,'edges':rows,'normal_and_area_assertions_not_weakened':True,'reason':'Both endpoints are exact Dirichlet values. Interior harmonic changes cannot repair any listed edge while these hard values/poses remain fixed.'}
