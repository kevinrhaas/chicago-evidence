#!/usr/bin/env bash
set -uo pipefail
cd /tmp/chicago-covered-sag/chicago/4d || exit 2
task_dir=/workspace/shared/T2794-V17-DEVd1cea-FULLPREFLIGHT-20261022
python3 - <<'PY'
import pathlib,subprocess,json,datetime
D=pathlib.Path('/workspace/shared/T2794-V17-DEVd1cea-FULLPREFLIGHT-20261022')
git=lambda *a:subprocess.check_output(['git',*a],stderr=subprocess.PIPE).decode().strip()
head=git('rev-parse','HEAD');tree=git('write-tree');assert head=='d1cea81204f33a4ae66fd59571b89b0f50f0f321' and tree=='3acbf2788b8196e11c1f82e96f14d9280e5c918f' and not git('diff','--name-only')
D.joinpath('START.json').write_text(json.dumps({'state':'RUNNING','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'staged_tree':tree,'origin_dev':git('rev-parse','origin/dev'),'command':'./tools/preflight.sh','CHECK_JOBS':4,'C4D_GATE_REQUIRE_READERS':1,'math_threads':1,'outer_timeout':None,'worktree':'/tmp/chicago-covered-sag'},indent=2)+'\n')
PY
if [ "$?" -ne 0 ]; then exit 2; fi
env PATH=/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:$PATH CHECK_JOBS=4 C4D_GATE_REQUIRE_READERS=1 CHECK_TIMINGS="$task_dir/CHECK-TIMINGS.tsv" OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 ./tools/preflight.sh > "$task_dir/FULL-PREFLIGHT.log" 2>&1
gate_code=$?
python3 - "$gate_code" <<'PY'
import pathlib,subprocess,json,datetime,shutil,sys,hashlib
D=pathlib.Path('/workspace/shared/T2794-V17-DEVd1cea-FULLPREFLIGHT-20261022')
copied=[]
for p in sorted(pathlib.Path('/tmp').glob('preflight*.log')):
 if p.is_file():
  target=D/'IMMEDIATE-GLOBAL-TMP-COPIES'/p.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(p,target);copied.append({'source':str(p),'copy':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
git=lambda *a:subprocess.check_output(['git',*a],stderr=subprocess.PIPE).decode().strip()
start=json.loads((D/'START.json').read_bytes());head=git('rev-parse','HEAD');tree=git('write-tree');code=int(sys.argv[1]);unstaged=git('diff','--name-only').splitlines()
result={'state':'CLOSED_PASS' if code==0 else 'CLOSED_FAIL','exit':code,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'staged_tree':tree,'exact_start_head_and_tree_unchanged':head==start['head'] and tree==start['staged_tree'],'unstaged_files':unstaged,'origin_dev_at_terminal':git('rev-parse','origin/dev'),'global_tmp_logs_copied_immediately':copied,'outer_timeout':None}
(D/'TERMINAL.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
PY
tail -n 24 "$task_dir/FULL-PREFLIGHT.log"
exit "$gate_code"
