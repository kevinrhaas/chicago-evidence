"""ONE released source-topology/material/weight ownership audit, no weight solve."""
import pathlib,json,sys,hashlib,time
import numpy as np
from scipy.sparse.csgraph import connected_components
from scipy.spatial import cKDTree
P=pathlib.Path(__file__).parent;S=pathlib.Path('/workspace/shared/T2803-V6-DOMINANT-ANCHOR-STUDY-20261022');sys.path.insert(0,str(S));start=time.monotonic();release=json.loads(pathlib.Path(sys.argv[1]).read_text());assert release.get('released')is True and release.get('authorization')=='ONE_ROOT_V6_COMPONENT_AUDIT';assert release['caller_sha256']==hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest();assert hashlib.sha256((S/'screened_harmonic_v6_HELD.py').read_bytes()).hexdigest()=='ee5c2e6a51d2784f058c88e4ff609f1a3ccfa306126f1d0aa83374e26b5d6f02'
from actual_model import Model
import screened_harmonic_v6_HELD as candidate
m=Model(pathlib.Path('/workspace/shared/T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb'));assert hashlib.sha256(m.raw).hexdigest()=='03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36';controls=json.loads((S/'RERIG-CONTROLS-PROPOSAL-V2.json').read_text());side=json.loads(pathlib.Path('/workspace/shared/horse-standing-intake-proposal-V2-20261022/proposed/data/transport/parked/horse-sevket-sidecar.json').read_text());parts=[];rest=[];materials=[]
for ni in [26,27,28]:
 pr=m.g['meshes'][m.g['nodes'][ni]['mesh']]['primitives'][0];a=pr['attributes'];parts.append((m.accessor(a['POSITION']).astype(float),m.accessor(a['NORMAL']).astype(float),m.accessor(a['JOINTS_0']).astype(int),m.accessor(a['WEIGHTS_0']).astype(float),m.accessor(pr['indices']).astype(int).reshape(-1,3)));rest.append(m.mesh(ni)[0]);materials.append(m.g['materials'][pr['material']]['name'])
patch={label:np.unique(parts[1][4][row['source_triangle_ids']].ravel())for label,row in side['contacts'].items()};capture={};original_dijkstra=candidate.dijkstra;original_solver=candidate.spsolve
class SolverForbidden(Exception):pass
def observe(graph,*args,**kwargs):
 result=original_dijkstra(graph,*args,**kwargs);capture['graph']=graph;capture['distance']=result;capture['trunk']=np.asarray(kwargs['indices']);return result
def no_solver(*args,**kwargs):raise SolverForbidden('Audit forbids any weight solve')
candidate.dijkstra=observe;candidate.spsolve=no_solver
try:
 candidate.build(rest,parts,controls,patch)
 raise RuntimeError('FrozenV6guard unexpectedly did not reject')
except AssertionError as e:
 assert str(e)=='Disconnected unknown source component lacks actual trunk anchor';guard=str(e)
finally:candidate.dijkstra=original_dijkstra;candidate.spsolve=original_solver
keys={};members=[];points=[];vc=[]
for mi,ps in enumerate(rest):
 ids=[]
 for vi,p in enumerate(ps):
  key=tuple(np.rint(p/1e-6).astype(int))
  if key not in keys:keys[key]=len(points);points.append(p);members.append([])
  ci=keys[key];members[ci].append((mi,vi));ids.append(ci)
 vc.append(np.asarray(ids,dtype=int))
points=np.asarray(points);N=len(points);original=np.zeros((N,26));mass=np.zeros(N);tri=np.concatenate([vc[mi][part[4]]for mi,part in enumerate(parts)]);tp=points[tri];area=np.linalg.norm(np.cross(tp[:,1]-tp[:,0],tp[:,2]-tp[:,0]),axis=1)/2
for k in range(3):np.add.at(mass,tri[:,k],area/3)
for ci,group in enumerate(members):
 mi,vi=group[0];np.add.at(original[ci],parts[mi][2][vi],parts[mi][3][vi])
original/=original.sum(1)[:,None];ownership,ties=candidate.original_joint_ownership(original);fixed=(points[:,1]>=1.14)|ownership|(mass<=0);hoof_classes={label:np.unique(vc[1][ids])for label,ids in patch.items()}
for ids in hoof_classes.values():fixed[ids]=True
unanchored=(~fixed)&~np.isfinite(capture['distance']);assert unanchored.any();ncomp,comp=connected_components(capture['graph'],directed=False);bad_components=np.unique(comp[unanchored]);body=rest[1];body_tri=body[parts[1][4]];body_min=body_tri.min(1);body_max=body_tri.max(1);tree=cKDTree(body)
def vertex_to_actual_body_surface(point):
 upper,index=tree.query(point);valid=np.all(body_min<=point+upper+1e-12,axis=1)&np.all(body_max>=point-upper-1e-12,axis=1);ids=np.flatnonzero(valid);ts=body_tri[ids];a,b,c=ts[:,0],ts[:,1],ts[:,2];ab=b-a;ac=c-a;ap=point-a;dot00=np.einsum('ni,ni->n',ab,ab);dot01=np.einsum('ni,ni->n',ab,ac);dot11=np.einsum('ni,ni->n',ac,ac);dot20=np.einsum('ni,ni->n',ap,ab);dot21=np.einsum('ni,ni->n',ap,ac);den=dot00*dot11-dot01*dot01;v=np.divide(dot11*dot20-dot01*dot21,den,out=np.zeros(len(ts)),where=den>1e-24);w=np.divide(dot00*dot21-dot01*dot20,den,out=np.zeros(len(ts)),where=den>1e-24);projection=a+v[:,None]*ab+w[:,None]*ac;inside=(den>1e-24)&(v>=0)&(w>=0)&(v+w<=1);best=np.where(inside,np.linalg.norm(projection-point,axis=1),np.inf);closest=projection.copy()
 for x,y in [(a,b),(b,c),(c,a)]:
  delta=y-x;ss=np.einsum('ni,ni->n',delta,delta);t=np.divide(np.einsum('ni,ni->n',point-x,delta),ss,out=np.zeros(len(ts)),where=ss>0);q=x+np.clip(t,0,1)[:,None]*delta;d=np.linalg.norm(q-point,axis=1);mask=d<best;best[mask]=d[mask];closest[mask]=q[mask]
 k=int(np.argmin(best));return float(best[k]),int(ids[k]),closest[k].tolist()
rows=[]
for cid in bad_components:
 classes=np.flatnonzero(comp==cid);unknown=classes[unanchored[classes]];pairs=[(mi,vi)for ci in classes for mi,vi in members[ci]];indexed_edges=int(capture['graph'][classes][:,classes].nnz//2);part_counts={str(mi):sum(a==mi for a,b in pairs)for mi in range(3)};weights=original[classes];jointrows=[{'joint':j,'name':controls['nodes'][j]['name'],'maximum_weight':float(weights[:,j].max()),'sum_weights_over_classes':float(weights[:,j].sum()),'positive_class_count':int(np.count_nonzero(weights[:,j]>0))}for j in range(26)if np.any(weights[:,j]>0)];nearest={'distance_m':float('inf')}
 for ci in classes:
  distance,ti,q=vertex_to_actual_body_surface(points[ci])
  if distance<nearest['distance_m']:nearest={'distance_m':distance,'component_class':int(ci),'component_members':members[ci],'component_point_m':points[ci].tolist(),'actual_body_triangle':ti,'actual_body_closest_point_m':q}
 rows.append({'component_id':int(cid),'classes':len(classes),'unanchored_unknown_classes':len(unknown),'already_hard_anchor_classes':int(fixed[classes].sum()),'upper_trunk_anchor_classes':int(np.count_nonzero((points[classes,1]>=1.14))),'genuine_head_tail_owned_classes':int(ownership[classes].sum()),'exact_dominance_ties':int(ties[classes].sum()),'edges':indexed_edges,'primitive_vertex_counts':part_counts,'materials':[materials[mi]for mi in range(3)if int(part_counts[str(mi)])>0],'bounds_min_m':points[classes].min(0).tolist(),'bounds_max_m':points[classes].max(0).tolist(),'source_original_bone_influences':jointrows,'maximum_total_source_limb_weight':float(weights[:,6:].sum(1).max()),'annotated_hoof_patch_class_counts':{label:int(np.intersect1d(classes,ids).size)for label,ids in hoof_classes.items()},'nearest_component_vertex_to_actual_body_triangle':nearest,'attachment_scope':'Minimum over all component source vertices to full actual body triangles. Does not establish triangle/triangle intersection, physical attachment, or anatomy.','actual_member_vertex_ids':{str(mi):[vi for a,vi in pairs if a==mi]for mi in range(3)}})
result={'scope':'Exact frozenV6guard/topology/material/source-weight ownership audit. No weight solve or new candidate.','caller_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((S/'screened_harmonic_v6_HELD.py').read_bytes()).hexdigest(),'guard_reproduced':guard,'total_source_classes':N,'total_graph_components':int(ncomp),'total_unanchored_unknown_classes':int(unanchored.sum()),'unanchored_components':rows,'accepted':False,'weight_solve_executed':False,'elapsed_s':time.monotonic()-start};(P/'ACTUAL-COMPONENT-OWNERSHIP.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='unanchored_components'},indent=2));print(json.dumps([{k:v for k,v in r.items()if k!='actual_member_vertex_ids'}for r in rows],indent=2))
