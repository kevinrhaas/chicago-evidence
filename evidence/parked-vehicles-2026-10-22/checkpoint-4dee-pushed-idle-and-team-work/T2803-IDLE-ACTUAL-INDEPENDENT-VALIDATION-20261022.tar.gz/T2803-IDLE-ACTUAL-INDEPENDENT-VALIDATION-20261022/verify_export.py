from pathlib import Path
import json,hashlib,struct,math,time
R=Path(__file__).resolve().parent;start=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=Path('/workspace/shared/horse-public-base-search-20261022/horse-53a6eb7ccf054aa2a378dd7ec08f88fe.glb');derived=Path('/workspace/shared/T2803-IDLE-APPEND-ACTUAL-20261022/horse-sevket-filtered-idle-v1.glb');bundle=Path('/workspace/shared/T2803-sevket-native-clips-20261022/engine-neutral-idle-clip.json')
def read(p):
 raw=p.read_bytes();assert struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw));n,k=struct.unpack_from('<II',raw,12);assert k==0x4e4f534a;g=json.loads(raw[20:20+n]);size,kind=struct.unpack_from('<II',raw,20+n);assert kind==0x004e4942 and 28+n+size==len(raw);return raw,g,raw[28+n:]
a,g,b=read(original);d,j,db=read(derived);assert sha(original)=='41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988';assert sha(derived)=='2f590ee389d2262f944c2d2f860d85df95ca94757da585c338060088bcf90edf';assert len(a)==3211248 and len(d)==3231864
assert db[:len(b)]==b and len(db)-len(b)==19300
for k,v in g.items():
 if k not in ['buffers','bufferViews','accessors','animations']:assert j[k]==v,k
for k,extra in [('bufferViews',3),('accessors',3),('animations',1)]:assert j[k][:len(g[k])]==g[k] and len(j[k])-len(g[k])==extra
assert {k:v for k,v in j['buffers'][0].items() if k!='byteLength'}=={k:v for k,v in g['buffers'][0].items() if k!='byteLength'} and j['buffers'][0]['byteLength']==len(db)
for v in g['bufferViews']:
 off=v.get('byteOffset',0);assert db[off:off+v['byteLength']]==b[off:off+v['byteLength']]
clip=j['animations'][6];data=json.loads(bundle.read_text());assert clip['name']==data['animation']['name']=='sevket_reconstructed_head_tail_idle_v1';assert clip['extras']==data['animation']['extras'];assert len(clip['channels'])==len(clip['samplers'])==2 and {c['target']['node'] for c in clip['channels']}=={17,19}
def stream(i):
 ac=j['accessors'][i];v=j['bufferViews'][ac['bufferView']];assert ac['componentType']==5126 and not v.get('byteStride');width={'VEC4':4,'SCALAR':1}[ac['type']];off=v.get('byteOffset',0)+ac.get('byteOffset',0);assert off%4==0;return ac,db[off:off+ac['count']*width*4]
tracks=[]
for channel,expected in zip(clip['channels'],data['animation']['tracks']):
 assert channel['target']==expected['target'];sampler=clip['samplers'][channel['sampler']];assert sampler['interpolation']=='CUBICSPLINE'
 inp,times=stream(sampler['input']);out,vals=stream(sampler['output']);assert inp['type']=='SCALAR' and inp['count']==193 and inp['min']==[0] and inp['max']==[12];assert out['type']=='VEC4' and out['count']==579
 assert times==struct.pack('<193f',*expected['sampler']['input_times_s']);assert vals==struct.pack('<2316f',*expected['sampler']['output_in_value_out_quaternions_xyzw']);assert not j['nodes'][channel['target']['node']].get('children')
 q=struct.unpack('<2316f',vals);assert all(math.isfinite(x) for x in q);default=j['nodes'][channel['target']['node']]['rotation'];assert list(q[4:8])==list(q[-8:-4])==default;assert all(x==0 for x in q[:4]+q[8:12]+q[-12:-8]+q[-4:]);tracks.append({'node':channel['target']['node'],'actual_exported_float32_stream_equals_reviewed_bundle':True,'input_count':193,'output_VEC4_count':579,'actual_new_view_no_byteStride':True,'native_endpoint_values_and_zero_tangents':True})
o=json.loads((R/'KHRONOS-ACTUAL-ORIGINAL.json').read_text());n=json.loads((R/'KHRONOS-ACTUAL-IDLE.json').read_text());assert o['report']['issues']==n['report']['issues'];issues=n['report']['issues'];assert len([m for m in issues['messages'] if m['severity']==0])==90 and all(m['code']=='ANIMATION_SAMPLER_ACCESSOR_WITH_BYTESTRIDE' and m['pointer'].startswith(tuple('/animations/'+str(i)+'/' for i in range(6))) for m in issues['messages'] if m['severity']==0);assert not any(m['pointer'].startswith('/animations/6') for m in issues['messages']);assert not issues['truncated']
report={'structural_export_verdict':'PASS_ORIGINAL_PROTECTED_AND_NEW_IDLE_STREAMS_EXACT','whole_asset_khronos_verdict':'FAIL_90_ERRORS_15900_WARNINGS_PRESERVED_SOURCE_NOT_CONFORMANT','append_delta_khronos':'ZERO_NEW_ISSUES; EXACT_FULL_ISSUE_ARRAY_EQUALS_INDEPENDENT_ORIGINAL_BASELINE','source_sha256':sha(original),'derived_sha256':sha(derived),'derived_bytes':len(d),'original_BIN_bytes':len(b),'appended_BIN_bytes':len(db)-len(b),'original_buffer_prefix_and_all_views_exact':True,'original_nodes_skins_inversebinds_meshes_maps_materials_accessors_and_6animations_exact':True,'new_tracks':tracks,'original_khronos_sha256':sha(R/'KHRONOS-ACTUAL-ORIGINAL.json'),'derived_khronos_sha256':sha(R/'KHRONOS-ACTUAL-IDLE.json'),'whole_asset_errors':issues['numErrors'],'whole_asset_warnings':issues['numWarnings'],'new_animation6_issues':0,'issue_arrays_exact':True,'elapsed_seconds':time.monotonic()-start,'scope':'Actual native derivative bytes/conformance differential only; no Mixer/skin deformation/browser/app/currenthead acceptance'}
(R/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
