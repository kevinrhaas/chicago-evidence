"""Read-only bounded sparse native motion inspection; no all-vertex/contact/gait qualification."""
import hashlib,json,math,pathlib,resource,sys,time
resource.setrlimit(resource.RLIMIT_CPU,(12,12));started=time.monotonic()
import numpy as np
sys.path.insert(0,'/workspace/shared/horse-public-base-search-20261022')
import read_native_pose as D
OUT=pathlib.Path(__file__).resolve().parent
S=pathlib.Path('/workspace/chicago-waistcoat/chicago/4d/data/transport/parked/horse-sevket-sidecar.json');spec=json.loads(S.read_text());G=D.G
body=G['meshes'][G['nodes'][spec['contact_mesh']['source_node_index']]['mesh']]['primitives'][0];attr=body['attributes'];skin=G['skins'][0]
pos=D.acc(attr['POSITION']);joint=D.acc(attr['JOINTS_0']).astype(int);weight=D.acc(attr['WEIGHTS_0']);ib=D.acc(skin['inverseBindMatrices']).reshape((-1,4,4)).transpose(0,2,1)
ids={k:v['minimum_vertex_id']for k,v in spec['contacts'].items()};rest=D.worlds({});origin=np.array(spec['origin_native']);scale=spec['uniform_metres_per_native_unit']
def qnorm(a):a=np.array(a,dtype=float);return a/np.linalg.norm(a)
def qangle(a,b):return math.degrees(2*math.acos(min(1,abs(float(np.dot(qnorm(a),qnorm(b)))))))
def lerp_q(a,b,f):
 a,b=qnorm(a),qnorm(b);dot=float(a@b)
 if dot<0:b=-b;dot=-dot
 if dot>.9995:return qnorm(a+(b-a)*f)
 ang=math.acos(min(1,dot));return a*math.sin((1-f)*ang)/math.sin(ang)+b*math.sin(f*ang)/math.sin(ang)
def over_at(channels,t):
 over={}
 for node,kind,times,values in channels:
  if len(times)==1 or t<=times[0]:v=values[0]
  elif t>=times[-1]:v=values[-1]
  else:
   i=int(np.searchsorted(times,t,side='right'))-1;f=(t-times[i])/(times[i+1]-times[i]);v=lerp_q(values[i],values[i+1],f)if kind=='rotation'else values[i]*(1-f)+values[i+1]*f
  over.setdefault(node,{})[kind]=v.tolist()
 return over
def sparse(w):
 mats=np.stack([w[i]for i in skin['joints']])@ib;v={}
 for name,idx in ids.items():
  p=np.r_[pos[idx],1.];v[name]=sum(weight[idx,k]*(mats[joint[idx,k]]@p)[:3]for k in range(4))
 return v
r=sparse(rest)
for name,p in r.items():assert np.max(np.abs(p-spec['contacts'][name]['minimum_vertex_native']))<1e-10
rig=[]
for si,ni in enumerate(skin['joints']):
 rig.append({'skin_joint_index':si,'node_index':ni,'name':G['nodes'][ni].get('name'),'parent_node_index':D.PARENT.get(ni),'native_world_pivot':rest[ni][:3,3].tolist(),'canonical_world_pivot_m':((rest[ni][:3,3]-origin)*scale).tolist(),'weighted_vertex_counts_each_primitive':[int(np.count_nonzero(np.any((D.acc(p['attributes']['JOINTS_0']).astype(int)==si)&(D.acc(p['attributes']['WEIGHTS_0'])>1e-6),axis=1)))for m in G['meshes']for p in m['primitives']]})
clips=[]
for ai,a in enumerate(G['animations']):
 channels=[];summ=[]
 for ch in a['channels']:
  sm=a['samplers'][ch['sampler']];assert sm.get('interpolation','LINEAR')=='LINEAR';ts=D.acc(sm['input']).ravel().astype(float);v=D.acc(sm['output']).astype(float);kind=ch['target']['path'];ni=ch['target']['node'];assert np.isfinite(ts).all()and np.all(np.diff(ts)>0)and len(ts)==len(v)
  channels.append((ni,kind,ts,v));summ.append({'node_index':ni,'node_name':G['nodes'][ni].get('name'),'property':kind,'keys':len(ts),'first_time_s':float(ts[0]),'last_time_s':float(ts[-1]),'start_end_rotation_difference_deg':qangle(v[0],v[-1])if kind=='rotation'else None,'largest_rotation_from_first_key_deg':max(qangle(v[0],q)for q in v)if kind=='rotation'else None})
 duration=max(float(x[2][-1])for x in channels);times=np.linspace(0,duration,33);points={name:[]for name in ids};root=[]
 for t in times:
  w=D.worlds(over_at(channels,float(t)));v=sparse(w)
  root.append(w[5][:3,3].tolist())
  for name,p in v.items():points[name].append(((p-origin)*scale).tolist())
 metrics={}
 for name,v in points.items():
  p=np.array(v);delta=duration/32;start_v=(p[1]-p[0])/delta;end_v=(p[-1]-p[-2])/delta
  metrics[name]={'minimum_y_m':float(p[:,1].min()),'maximum_y_m':float(p[:,1].max()),'xyz_span_m':np.ptp(p,axis=0).tolist(),'maximum_displacement_from_first_m':float(np.linalg.norm(p-p[0],axis=1).max()),'loop_position_seam_m':float(np.linalg.norm(p[-1]-p[0])),'finite_difference_velocity_seam_m_s':float(np.linalg.norm(end_v-start_v)),'first_pose_difference_from_default_m':float(np.linalg.norm(p[0]-(r[name]-origin)*scale))}
 clips.append({'index':ai,'exact_name':a.get('name'),'name_codepoints':[hex(ord(c))for c in a.get('name','')],'duration_s':duration,'channels':summ,'translation_channels':sum(c[1]=='translation'for c in channels),'scale_channels':sum(c[1]=='scale'for c in channels),'sampled_native_root_joint_translation_span':np.ptp(np.array(root),axis=0).tolist(),'samples_s':times.tolist(),'canonical_sparse_minimum_vertex_paths_m':points,'foot_proxy_metrics':metrics,'loop_maximum_channel_orientation_seam_deg':max(s['start_end_rotation_difference_deg']or 0 for s in summ),'locomotion_approved':False})
legacy=pathlib.Path('/workspace/chicago/chicago/4d/renderers/web/transport/horse/equine_light_harness_skinned_prototype_01.glb')
result={'scope':'ACTUAL native authored key data and33timepoints×4 existing minimum-hoof vertices×6clips only. No all-vertex sampling, complete sole/contact, intersection, biological-gait, gear, visual or production acceptance. No source transform/material/export changes; canonical metre normalization from accepted static sidecar only, NO parked whole-root tilt or ylift.','source_sha256':hashlib.sha256(D.B).hexdigest(),'source_bytes':len(D.B),'sidecar_sha256':hashlib.sha256(S.read_bytes()).hexdigest(),'reader_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'legacy89b_actual_sha256':hashlib.sha256(legacy.read_bytes()).hexdigest(),'sparse_foot_vertex_ids':ids,'default_anchor_parity_max_m':max(float(np.linalg.norm(r[k]-spec['contacts'][k]['minimum_vertex_native'])*scale)for k in ids),'rig':rig,'clips':clips,'elapsed_seconds':time.monotonic()-started,'native_source_unmodified':hashlib.sha256(D.F.read_bytes()).hexdigest()==hashlib.sha256(D.B).hexdigest()}
(OUT/'NATIVE-CLIP-READBACK.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'elapsed_seconds':result['elapsed_seconds'],'legacy_sha256':result['legacy89b_actual_sha256'],'clips':[{'index':c['index'],'name':c['exact_name'],'duration_s':c['duration_s'],'max_orientation_seam_deg':c['loop_maximum_channel_orientation_seam_deg'],'foot_max_displacement_m':{k:round(v['maximum_displacement_from_first_m'],6)for k,v in c['foot_proxy_metrics'].items()}}for c in clips]},indent=2))
