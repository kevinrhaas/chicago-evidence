"""Finite skin-coefficient read only; no animation evaluation or geometry export."""
import json,pathlib,sys,hashlib,resource,time
resource.setrlimit(resource.RLIMIT_CPU,(10,10));start=time.monotonic()
sys.path.insert(0,'/workspace/shared/horse-public-base-search-20261022');import read_native_pose as D
import numpy as np
O=pathlib.Path(__file__).resolve().parent
source=pathlib.Path('/workspace/shared/horse-standing-intake-proposal-V2-20261022/proposed/data/transport/parked/horse-sevket-sidecar.json')
s=json.loads(source.read_text());G=D.G;n=s['contact_mesh']['source_node_index'];p=G['meshes'][G['nodes'][n]['mesh']]['primitives'][0];a=p['attributes'];tri=D.acc(p['indices']).astype(int).reshape((-1,3));j=D.acc(a['JOINTS_0']).astype(int);w=D.acc(a['WEIGHTS_0']);joints=G['skins'][0]['joints'];out={}
for label,patch in s['contacts'].items():
 ids=np.unique(tri[patch['source_triangle_ids']].ravel());members=[]
 for node in [17,19]:
  si=joints.index(node);weights=np.where(j[ids]==si,w[ids],0).sum(1);members.append({'node_index':node,'skin_joint_index':si,'name':G['nodes'][node]['name'],'vertices_nonzero':int(np.count_nonzero(weights)),'maximum_weight':float(weights.max()),'sum_weights':float(weights.sum())})
 idx=patch['minimum_vertex_id'];out[label]={'annotated_source_triangles':len(patch['source_triangle_ids']),'unique_patch_vertices':len(ids),'minimum_vertex_id':idx,'minimum_vertex_weight_bindings':[{'skin_joint_index':int(si),'node_index':joints[int(si)],'name':G['nodes'][joints[int(si)]]['name'],'weight':float(v)}for si,v in zip(j[idx],w[idx])if v>0],'proposed_leaf_idle_bones':members}
result={'source_sha256':hashlib.sha256(D.B).hexdigest(),'reader_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'frozen_sidecar_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Actual skin coefficients for original four annotated lower-hoof surface patches only. Leaf17/head and leaf19/tail alone are proposed. No posed deformation/contact/wholelimb/visual acceptance. Nonzero coefficients require explicit derivative reweighting or refusing that channel; never waive tiny values.','leaf_children':{str(i):G['nodes'][i].get('children',[])for i in [17,19]},'patches':out,'all_patch_weights_exactly_zero':all(x['vertices_nonzero']==0 for p in out.values()for x in p['proposed_leaf_idle_bones']),'elapsed_seconds':time.monotonic()-start}
(O/'IDLE-SUPPORT-WEIGHTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
