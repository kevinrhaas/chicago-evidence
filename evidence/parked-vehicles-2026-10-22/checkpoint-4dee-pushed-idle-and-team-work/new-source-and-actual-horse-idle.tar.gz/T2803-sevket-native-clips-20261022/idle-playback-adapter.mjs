// SPDX-License-Identifier: GPL-3.0-or-later
// SOURCE PROPOSAL: playback of an explicit exported glTF idle; no curve invention in renderer.
const ORIGINAL='41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988';
const CLIP='sevket_reconstructed_head_tail_idle_v1',OWNER=Symbol('sourceBoundIdle');
const check=(ok,msg)=>{if(!ok)throw Error('HorseIdleContract: '+msg);};
function stableHash(text){let h=2166136261;for(const c of text){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
export function createExportedHorseIdle({T,root,clips,verifiedDerivedSha256,appendReceipt,source,instanceId}){
 check(appendReceipt.original_sha256===ORIGINAL&&appendReceipt.derived_sha256===verifiedDerivedSha256,'actual derived byte proof mismatched');
 check(appendReceipt.original_nodes_skins_meshes_materials_images_asset_exact&&appendReceipt.original_accessors_and_six_animations_exact,'original protection proof missing');
 check(typeof instanceId==='string'&&instanceId.length>0,'stable instance identity required');
 check(!root.userData[OWNER],'another source idle owns this clone');
 const meshes=[];root.traverse(n=>{if(n.isMesh)meshes.push(n);});check(meshes.length===3&&meshes.every(m=>m.isSkinnedMesh&&m.skeleton.bones.length===15),'source skin inventory changed');
 const bones=meshes[0].skeleton.bones;check(meshes.every(m=>m.skeleton.bones.every((b,i)=>b===bones[i])),'source joint identity/order changed');
 const clip=clips.find(c=>c.name===CLIP);check(clips.length===7&&clips.filter(c=>c.name===CLIP).length===1&&clip.duration===12&&clip.tracks.length===2,'explicit exported idle missing/changed');
 const targets=new Set();for(const track of clip.tracks){const p=T.PropertyBinding.parseTrackName(track.name);check(p.propertyName==='quaternion','only quaternion tracks permitted');const node=T.PropertyBinding.findNode(root,p.nodeName);check(node===bones[12]||node===bones[14],'unapproved bone track');check(!node.children.some(n=>n.isBone),'idle target no longer a leaf');targets.add(node);}check(targets.size===2,'head/tail leaves must each occur once');
 const body=root.getObjectByName(source.support_guard.mesh_renderer_name),idx=body?.geometry.index,ji=body?.geometry.getAttribute('skinIndex'),sw=body?.geometry.getAttribute('skinWeight');check(body?.isSkinnedMesh&&idx&&ji&&sw,'source contact body missing');
 const ids=new Set();for(const faces of Object.values(source.support_guard.triangles_by_hoof))for(const face of faces)for(let k=0;k<3;k++)ids.add(idx.getX(face*3+k));
 for(const id of ids)for(const axis of ['X','Y','Z','W'])if([12,14].includes(ji['get'+axis](id)))check(sw['get'+axis](id)===0,'idle leaf influences annotated hoof surface');
 // Caller must construct at exact rest and own all animation clocks for this clone.
 for(const c of source.derived_channels)check(bones[c.skin_joint_index].quaternion.angleTo(new T.Quaternion().fromArray(c.native_default_quaternion_xyzw))<1e-5,'actor not in source rest pose');
 const mixer=new T.AnimationMixer(root),action=mixer.clipAction(clip);action.setLoop(T.LoopRepeat,Infinity);action.play();mixer.setTime(0);root.userData[OWNER]=true;
 const initialRestDelay=2*(stableHash(instanceId)/4294967295),rate=.96+.08*(stableHash(instanceId+'|rate')/4294967295);
 let disposed=false,elapsed=0,age=0;
 return{update(dt,{visible=true,reducedMotion=false,paused=false}={}){if(disposed)return;check(Number.isFinite(dt)&&dt>=0,'invalid clock');if(!visible||reducedMotion||paused)return;const step=Math.min(dt,.1),before=age;age+=step;const advance=(Math.max(0,age-initialRestDelay)-Math.max(0,before-initialRestDelay))*rate;elapsed+=advance;mixer.update(advance);},
  get status(){return{elapsed_s:elapsed,disposed,clip:CLIP,initial_rest_delay_s:initialRestDelay,deterministic_playback_rate:rate,mixer_count:disposed?0:1,weight_shift:false,independent_ear_motion:false,walk:false,trot:false};},
  // Host removes/hides the clone before retiring its player, avoiding visible reset on teardown.
  dispose(){if(disposed)return;disposed=true;mixer.stopAllAction();mixer.uncacheRoot(root);delete root.userData[OWNER];},
 };
}
