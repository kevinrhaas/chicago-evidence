"""Append ONLY standard quaternion animation streams to the pinned licensed original.
Source proposal; execute only after coordinator release. No geometry generation/re-rig.
"""
import argparse,copy,hashlib,json,pathlib,struct
SOURCE='41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988'
HERE=pathlib.Path(__file__).resolve().parent

def build(source_file,bundle_file,out):
 out=out.resolve();assert out.is_relative_to(pathlib.Path('/workspace/shared')),'Outside-app fresh output required'
 assert not out.exists(),'Refuse existing output; no automatic retry'
 raw=source_file.read_bytes();assert hashlib.sha256(raw).hexdigest()==SOURCE and len(raw)==3211248
 magic,version,total=struct.unpack_from('<III',raw);assert(magic,version,total)==(0x46546c67,2,len(raw))
 n,kind=struct.unpack_from('<II',raw,12);assert kind==0x4e4f534a
 original=json.loads(raw[20:20+n]);bn,btype=struct.unpack_from('<II',raw,20+n);assert btype==0x004e4942 and 28+n+bn==len(raw)
 oldbin=raw[28+n:];assert len(original['buffers'])==1 and'uri'not in original['buffers'][0]
 doc=copy.deepcopy(original);binary=bytearray(oldbin);bundle=json.loads(bundle_file.read_text());assert bundle['source_sha256']==SOURCE
 animation={'name':bundle['animation']['name'],'extras':bundle['animation']['extras'],'channels':[],'samplers':[]}
 def append(values,width,kind,minimum=None,maximum=None):
  while len(binary)%4:binary.append(0)
  offset=len(binary);data=struct.pack('<'+'f'*len(values),*values);binary.extend(data)
  bv=len(doc['bufferViews']);doc['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':len(data)})
  aid=len(doc['accessors']);acc={'bufferView':bv,'componentType':5126,'count':len(values)//width,'type':kind}
  if minimum is not None:acc['min']=minimum;acc['max']=maximum
  doc['accessors'].append(acc);return aid
 tracks=bundle['animation']['tracks'];assert len(tracks)==2 and{t['target']['node']for t in tracks}=={17,19}
 times=tracks[0]['sampler']['input_times_s'];assert len(times)==193 and times[0]==0 and times[-1]==12 and all(a<b for a,b in zip(times,times[1:]))
 input_id=append(times,1,'SCALAR',[0],[12])
 for track in tracks:
  assert track['target']['path']=='rotation'and track['sampler']['interpolation']=='CUBICSPLINE'and track['sampler']['input_times_s']==times
  values=track['sampler']['output_in_value_out_quaternions_xyzw'];assert len(values)==193*12
  output_id=append(values,4,'VEC4');si=len(animation['samplers']);animation['samplers'].append({'input':input_id,'output':output_id,'interpolation':'CUBICSPLINE'});animation['channels'].append({'sampler':si,'target':track['target']})
 assert len(doc['animations'])==6;doc['animations'].append(animation);doc['buffers'][0]['byteLength']=len(binary)
 for key,value in original.items():
  if key not in ['buffers','bufferViews','accessors','animations']:assert doc[key]==value,key
 for key in ['bufferViews','accessors','animations']:assert doc[key][:len(original[key])]==original[key],key
 assert binary[:len(oldbin)]==oldbin
 # Every original embedded image and all geometry/old animation buffer slices remain in the exact old prefix.
 for view in original['bufferViews']:
  start=view.get('byteOffset',0);end=start+view['byteLength'];assert bytes(binary[start:end])==oldbin[start:end]
 encoded=json.dumps(doc,ensure_ascii=False,separators=(',',':')).encode();encoded+=b' '*((-len(encoded))%4)
 while len(binary)%4:binary.append(0)
 result=struct.pack('<III',magic,2,28+len(encoded)+len(binary))+struct.pack('<II',len(encoded),0x4e4f534a)+encoded+struct.pack('<II',len(binary),0x004e4942)+binary
 out.mkdir();model=out/'horse-sevket-filtered-idle-v1.glb';model.write_bytes(result)
 receipt={'status':'ACTUAL_APPEND_EXPORT_ONLY; posed/fullsurface/Mixer/browser/productionapproval still open','original_source':str(source_file),'original_sha256':SOURCE,'original_bytes':len(raw),'derived_file':model.name,'derived_bytes':len(result),'derived_sha256':hashlib.sha256(result).hexdigest(),'bundle_sha256':hashlib.sha256(bundle_file.read_bytes()).hexdigest(),'generator_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'original_buffer_prefix_exact':True,'every_original_buffer_view_exact':True,'original_nodes_skins_meshes_materials_images_asset_exact':True,'original_accessors_and_six_animations_exact':True,'new_animation':animation['name'],'new_channels':[17,19],'new_interpolation':'CUBICSPLINE','new_duration_s':12,'animation_count':7,'skin_joints':15,'license':'CC-BY-4.0','source_credit':'Horse by sevketkabatas, CC BY4.0, via Objaverse. New source-relative head/tail-only reconstructed idle; no original geometry/texture/skin/nativeclip alteration.','original_source_unchanged_after':hashlib.sha256(source_file.read_bytes()).hexdigest()==SOURCE}
 (out/'APPEND-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--lane-released',action='store_true',required=True);p.add_argument('--output-dir',type=pathlib.Path,required=True);a=p.parse_args()
 build(pathlib.Path('/workspace/shared/horse-public-base-search-20261022/horse-53a6eb7ccf054aa2a378dd7ec08f88fe.glb'),HERE/'engine-neutral-idle-clip.json',a.output_dir)
