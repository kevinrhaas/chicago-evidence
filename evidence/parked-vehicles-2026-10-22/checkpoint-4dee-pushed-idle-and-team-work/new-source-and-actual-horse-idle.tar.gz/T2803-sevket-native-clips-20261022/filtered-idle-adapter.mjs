// SPDX-License-Identifier: GPL-3.0-or-later
// SOURCE PROPOSAL: original41acd source retains CC BY4.0. No native clips renamed/mutated.
const SOURCE='41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988';
const owner=Symbol('sourceBoundFilteredIdleOwner');
const requireValue=(ok,msg)=>{if(!ok)throw Error('FilteredIdleContract: '+msg);};
const qOf=(T,a)=>new T.Quaternion().fromArray(a).normalize();
function nativeAt(T,c,t){
 const times=c.native_times_s,values=c.native_quaternions_xyzw;
 if(t<=times[0])return qOf(T,values[0]);if(t>=times.at(-1))return qOf(T,values.at(-1));
 let lo=0,hi=times.length-1;while(hi-lo>1){const m=(lo+hi)>>1;if(times[m]<=t)lo=m;else hi=m;}
 return qOf(T,values[lo]).slerp(qOf(T,values[hi]),(t-times[lo])/(times[hi]-times[lo]));
}
/** Reconstructed small local rest-relative leaf motion; closure never borrows limb/root tracks. */
export function filteredQuaternion(T,source,channel,phase){
 requireValue(Number.isFinite(phase)&&phase>=0&&phase<=1,'phase must be within one finite loop');
 const rest=qOf(T,channel.native_default_quaternion_xyzw);
 if(phase===0||phase===1)return rest;
 const start=qOf(T,channel.native_quaternions_xyzw[0]);
 const delta=start.invert().multiply(nativeAt(T,channel,phase*channel.native_times_s.at(-1))).normalize();
 if(delta.w<0)delta.set(-delta.x,-delta.y,-delta.z,-delta.w);
 const angle=new T.Quaternion().angleTo(delta),cap=channel.maximum_reconstructed_amplitude_deg*Math.PI/180;
 const amplitude=Math.min(source.native_delta_amplitude_fraction,angle>0?cap/angle:1)*Math.sin(Math.PI*phase)**2;
 return rest.multiply(new T.Quaternion().slerp(delta,amplitude)).normalize();
}
/** Runtime binding uses actual loaded skin order/identity, never old89b bone names or sockets. */
export function buildFilteredIdleClip({T,root,source,verifiedSourceSha256}){
 requireValue(verifiedSourceSha256===SOURCE&&source.source_sha256===SOURCE,'actual loader byte proof must match original41acd source');
 requireValue(source.derived_channels.length===2&&source.derived_idle_duration_s===12,'unreviewed source controls');
 const meshes=[];root.traverse(m=>{if(m.isMesh)meshes.push(m);});
 requireValue(meshes.length===3&&meshes.every(m=>m.isSkinnedMesh&&m.skeleton.bones.length===15),'actual source skin inventory changed');
 const bones=meshes[0].skeleton.bones;
 requireValue(meshes.every(m=>m.skeleton.bones.every((b,i)=>b===bones[i])),'skin bone identity/order diverged');
 const body=root.getObjectByName(source.support_guard.mesh_renderer_name);
 requireValue(body?.isSkinnedMesh&&body.geometry.getAttribute('position').count===source.support_guard.vertex_count,'source contact body does not resolve');
 const ji=body.geometry.getAttribute('skinIndex'),sw=body.geometry.getAttribute('skinWeight'),index=body.geometry.index;
 requireValue(ji&&sw&&index,'actual skin/contact indices missing');
 const supportIds=new Set();for(const faces of Object.values(source.support_guard.triangles_by_hoof))for(const f of faces)for(let k=0;k<3;k++)supportIds.add(index.getX(f*3+k));
 const component=['X','Y','Z','W'];
 for(const id of supportIds)for(let k=0;k<4;k++)if(source.support_guard.expected_leaf_skin_joint_indices.includes(ji['get'+component[k]](id)))requireValue(sw['get'+component[k]](id)===0,'proposed idle leaf influences a declared hoof surface');
 const tracks=[];const samples=193;
 for(const c of source.derived_channels){
  requireValue([12,14].includes(c.skin_joint_index),'unreviewed bone');const bone=bones[c.skin_joint_index];
  requireValue(!bone.children.some(n=>n.isBone),'idle target is no longer a leaf');
  requireValue(bone.quaternion.angleTo(qOf(T,c.native_default_quaternion_xyzw))<1e-5,'actor is not in exact source rest pose; do not reset it');
  const times=[],values=[];
  for(let i=0;i<samples;i++){const phase=i/(samples-1);times.push(phase*source.derived_idle_duration_s);filteredQuaternion(T,source,c,phase).toArray(values,values.length);}
  tracks.push(new T.QuaternionKeyframeTrack(bone.uuid+'.quaternion',times,values));
 }
 return {clip:new T.AnimationClip('sevket_reconstructed_head_tail_idle_v1',source.derived_idle_duration_s,tracks),support_guard:{vertices:supportIds.size,maximum_leaf_weight:0,scope:'original annotated lower-hoof surface only; fullsurface/visual/body limits remain unvalidated'}};
}
/** Future caller owns detail/visibility/distance policy and removes actor before disposal. */
export function createFilteredIdleAdapter({T,root,source,verifiedSourceSha256}){
 requireValue(!root.userData[owner],'another filtered idle already owns this actor');
 const built=buildFilteredIdleClip({T,root,source,verifiedSourceSha256}),mixer=new T.AnimationMixer(root);
 const action=mixer.clipAction(built.clip);action.setLoop(T.LoopRepeat,Infinity);action.play();mixer.setTime(0);root.userData[owner]=true;
 let disposed=false,elapsed=0;
 return {clip:built.clip,supportGuard:built.support_guard,
  update(delta,{reducedMotion=false,paused=false,visible=true}={}){
   if(disposed)return;requireValue(Number.isFinite(delta)&&delta>=0,'invalid clock');
   if(reducedMotion||paused||!visible)return;const dt=Math.min(delta,.1);elapsed+=dt;mixer.update(dt);
  },
  get status(){return{elapsed_s:elapsed,disposed,mixer_count:disposed?0:1,tracks:2,mode:'filtered-head-tail-only',walk:false,weight_shift:false};},
  dispose(){if(disposed)return;disposed=true;mixer.stopAllAction();mixer.uncacheRoot(root);delete root.userData[owner];},
 };
}
