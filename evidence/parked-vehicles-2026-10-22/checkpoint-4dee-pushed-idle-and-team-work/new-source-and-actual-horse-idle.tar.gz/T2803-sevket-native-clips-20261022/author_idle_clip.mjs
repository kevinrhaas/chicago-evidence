// SPDX-License-Identifier: GPL-3.0-or-later
// Original reconstruction arithmetic; extracted arrays retain sevketkabatas CC BY4.0.
import fs from'node:fs';import path from'node:path';import{fileURLToPath}from'node:url';import assert from'node:assert/strict';import crypto from'node:crypto';
import * as T from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js';
import{filteredQuaternion}from'./filtered-idle-adapter.mjs';
const P=path.dirname(fileURLToPath(import.meta.url)),source=JSON.parse(fs.readFileSync(P+'/filtered-idle-source.json'));
const duration=12,count=193,tracks=[],metrics=[];
for(const c of source.derived_channels){
 const times=[],values=[],derivatives=[],rest=new T.Quaternion().fromArray(c.native_default_quaternion_xyzw).normalize();
 const eps=1e-5;
 for(let i=0;i<count;i++){
  const phase=i/(count-1);times.push(phase*duration);
  const q=filteredQuaternion(T,source,c,phase);values.push((i===0||i===count-1)?[...c.native_default_quaternion_xyzw]:q.toArray());
  if(i===0||i===count-1)derivatives.push([0,0,0,0]);
  else{
   const lo=filteredQuaternion(T,source,c,phase-eps),hi=filteredQuaternion(T,source,c,phase+eps);
   const a=lo.toArray(),b=hi.toArray();if(lo.dot(hi)<0)for(let k=0;k<4;k++)b[k]*=-1;
   derivatives.push(a.map((x,k)=>(b[k]-x)/(2*eps*duration)));
  }
 }
 const outputs=values.flatMap((q,i)=>[...derivatives[i],...q,...derivatives[i]]);
 tracks.push({target:{node:c.native_node_index,path:'rotation'},sampler:{interpolation:'CUBICSPLINE',input_times_s:times,output_in_value_out_quaternions_xyzw:outputs},source_skin_joint_index:c.skin_joint_index,source_clip_index:c.source_clip_index,source_clip_exact_name:c.source_clip_exact_name,role:c.role,maximum_reconstructed_amplitude_deg:c.maximum_reconstructed_amplitude_deg});
 // Decode the exact future Float32 output and normalize as glTF cubic quaternion interpolation requires.
 const f32=new Float32Array(outputs),actual=[];
 for(let i=0;i<1537;i++){
  const time=i/1536*duration,index=Math.min(count-2,Math.floor(time/duration*(count-1))),dt=duration/(count-1),u=(time-times[index])/dt;
  const a=(2*u**3-3*u**2+1),b=(u**3-2*u**2+u),d=(-2*u**3+3*u**2),e=(u**3-u**2);
  const q=new T.Quaternion(...[0,1,2,3].map(k=>a*f32[index*12+4+k]+b*dt*f32[index*12+8+k]+d*f32[(index+1)*12+4+k]+e*dt*f32[(index+1)*12+k])).normalize();
  actual.push(q);
 }
 const maxAngle=Math.max(...actual.map(q=>rest.angleTo(q)))*180/Math.PI;
 const seam=actual[0].angleTo(actual.at(-1));assert(maxAngle<c.maximum_reconstructed_amplitude_deg);assert(seam<1e-7);assert.deepEqual(derivatives[0],[0,0,0,0]);assert.deepEqual(derivatives.at(-1),[0,0,0,0]);
 metrics.push({role:c.role,keyframes:count,decoded_float32_cubic_samples:actual.length,maximum_angle_from_source_rest_deg:maxAngle,loop_orientation_seam_rad:seam,exact_start_end_tangents_zero:true,first_last_raw_quaternion_equal_source_default:true});
}
const bundle={schema:'glTF_animation_append_bundle_v1',source_sha256:source.source_sha256,source_bytes:source.source_bytes,status:'Authored engine-neutral quaternion clip data; NOT exported/posed/fullsurface/browser/production approved',animation:{name:'sevket_reconstructed_head_tail_idle_v1',duration_s:duration,tracks,extras:{license:'CC-BY-4.0',source_url:source.source_url,source_author:'sevketkabatas',source_native_sha256:source.source_sha256,change_notice:'New rest-relative small head/tail-only idle: source headclip1/node17 and tailclip2/node19,6% localdelta,12s retiming,sine-squared closure,normalized quaternion interpolation,zero endtangents; original geometry/materials/skin/6clips retained. No ear/neck/root/body/limb/weightshift/walk/trot animation.',approval:'UNREVIEWED_ANIMATION_DERIVATIVE_STUDY',walk:false,weight_shift:false}},protection:'Producer must preserve every original buffer byte as prefix; every original accessor/bufferView/node/skin/mesh/image/material and all6originalanimations exact; only originalbuffer.byteLength is extended. Source41acd GLB unchanged.'};
fs.writeFileSync(P+'/engine-neutral-idle-clip.json',JSON.stringify(bundle,null,2)+'\n');
fs.writeFileSync(P+'/IDLE-CLIP-MATH.json',JSON.stringify({scope:'CPU quaternion arithmetic and decodedFloat32 cubic interpolation only; no actor/skinning/rendering/geometryexport',source_sha256:source.source_sha256,source_input_sha256:crypto.createHash('sha256').update(fs.readFileSync(P+'/filtered-idle-source.json')).digest('hex'),duration_s:duration,tracks:metrics,pass:true},null,2)+'\n');console.log(JSON.stringify(metrics));
