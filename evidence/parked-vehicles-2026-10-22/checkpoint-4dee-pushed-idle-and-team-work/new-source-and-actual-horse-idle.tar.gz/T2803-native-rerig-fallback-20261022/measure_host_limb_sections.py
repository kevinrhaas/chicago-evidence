"""One default-pose source surface measurement, no animation/export/reweight/model edits."""
import pathlib,sys,json,hashlib,time,resource
resource.setrlimit(resource.RLIMIT_CPU,(12,12));start=time.monotonic()
import numpy as np
sys.path.insert(0,'/workspace/shared/horse-public-base-search-20261022');import read_native_pose as D
P=pathlib.Path(__file__).resolve().parent;S=pathlib.Path('/workspace/shared/horse-standing-intake-proposal-V2-20261022/proposed/data/transport/parked/horse-sevket-sidecar.json');s=json.loads(S.read_text());origin=np.array(s['origin_native']);scale=s['uniform_metres_per_native_unit']
pieces=D.points({});verts=[(v-origin)*scale for _,v in pieces];triangles=[]
for m,v in zip(D.G['meshes'],verts):
 p=m['primitives'][0];indices=D.acc(p['indices']).astype(int).reshape((-1,3));triangles.append(v[indices])
tri=np.concatenate(triangles);anchors={k:(np.array(v['minimum_vertex_native'])-origin)*scale for k,v in s['contacts'].items()}
levels=[.04,.08,.16,.25,.36,.48,.62,.76,.90,1.04,1.18];sections=[]
for y in levels:
 segments=[]
 for t in tri:
  hits=[]
  for a,b in [(0,1),(1,2),(2,0)]:
   dy0,dy1=t[a,1]-y,t[b,1]-y
   if dy0*dy1<0:hits.append(t[a]+dy0/(dy0-dy1)*(t[b]-t[a]))
  if len(hits)==2:segments.append(hits)
 points={};adj={}
 for a,b in segments:
  ka,kb=[tuple(np.round(v[[0,2]]/1e-5).astype(int))for v in [a,b]]
  if ka==kb:continue
  points[ka]=a;points[kb]=b;adj.setdefault(ka,set()).add(kb);adj.setdefault(kb,set()).add(ka)
 remaining=set(adj);components=[]
 while remaining:
  todo=[remaining.pop()];c=[]
  while todo:
   k=todo.pop();c.append(k)
   for n in adj[k]:
    if n in remaining:remaining.remove(n);todo.append(n)
  v=np.array([points[k]for k in c]);components.append({'nodes':len(c),'closed_degree2':all(len(adj[k])==2 for k in c),'center_wire_point_mean_m':v.mean(0).tolist(),'bounds_m':[v.min(0).tolist(),v.max(0).tolist()],'span_xz_m':np.ptp(v,axis=0)[[0,2]].tolist()})
 selected={}
 for label,a in anchors.items():
  signx=1 if label.endswith('_l')else-1;signz=1 if label.startswith('fore')else-1
  candidates=[c for c in components if c['center_wire_point_mean_m'][0]*signx>.04 and c['center_wire_point_mean_m'][2]*signz>.08 and c['span_xz_m'][0]<.40 and c['span_xz_m'][1]<.52]
  if candidates:
   best=min(candidates,key=lambda c:np.linalg.norm(np.array(c['center_wire_point_mean_m'])[[0,2]]-a[[0,2]]))
   if np.linalg.norm(np.array(best['center_wire_point_mean_m'])[[0,2]]-a[[0,2]])<.4:selected[label]=best
 sections.append({'height_m':y,'all_surface_crosssection_components':len(components),'selected_isolated_limb_contours':selected})
# Coefficient-only lower-limb regions supplement the exact annotated-foot support proof.
regions={}
for label,a in anchors.items():
 rows=[]
 for mesh,v in zip(D.G['meshes'],verts):
  p=mesh['primitives'][0];used=np.unique(D.acc(p['indices']).astype(int).ravel());mask=(v[:,1]<.75)&(v[:,1]>=-.01)&(np.abs(v[:,0]-a[0])<.20)&(np.abs(v[:,2]-a[2])<.30)&(v[:,0]*(1 if label.endswith('_l')else-1)>.04);ids=used[mask[used]];j=D.acc(p['attributes']['JOINTS_0']).astype(int);w=D.acc(p['attributes']['WEIGHTS_0']);weights=np.where(np.isin(j[ids],[12,14]),w[ids],0).sum(1)
  rows.append({'material':p['material'],'actual_indexed_vertices_in_declared_box':len(ids),'idle_leaf_weight_nonzero_vertices':int(np.count_nonzero(weights)),'maximum_idle_leaf_weight':float(weights.max())if len(weights) else 0})
 regions[label]=rows
out={'source_sha256':hashlib.sha256(D.B).hexdigest(),'frozen_sidecar_sha256':hashlib.sha256(S.read_bytes()).hexdigest(),'reader_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'scope':'ONE default/rest actual source skin decode only, all14986triangles, canonicalmetres from frozen static sidecar. No animated sampling/bake/rebind/reweight. Crosssections measured on actual triangle edge intersections; wirepointmean is a surface statistic, NOT an anatomical bonepivot. Missing isolated contours are not silently invented.','native_axes':{'up':'+Y','forward':'+Z','anatomical_left':'+X'},'canonical_bounds_m':[np.concatenate(verts).min(0).tolist(),np.concatenate(verts).max(0).tolist()],'actual_minimum_hoof_anchors_m':{k:v.tolist()for k,v in anchors.items()},'triangle_plane_sections':sections,'lower_limb_coefficient_regions':regions,'elapsed_seconds':time.monotonic()-start,'native_source_unchanged':hashlib.sha256(D.F.read_bytes()).hexdigest()==hashlib.sha256(D.B).hexdigest()}
(P/'HOST-REST-LIMB-MEASUREMENTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'elapsed_seconds':out['elapsed_seconds'],'sections':[{ 'height_m':x['height_m'],'limbs':{k:[round(z,4)for z in c['center_wire_point_mean_m']]for k,c in x['selected_isolated_limb_contours'].items()}}for x in sections],'lower_limb_weights':regions},indent=2))
