from pathlib import Path
import json,struct,hashlib,math,time
P=Path('/workspace/shared/T2803-sevket-native-clips-20261022');R=Path(__file__).resolve().parent;start=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((P/'MANIFEST.json').read_text())
for row in manifest['files']:assert (P/row['path']).stat().st_size==row['bytes'] and sha(P/row['path'])==row['sha256']
bundle=json.loads((P/'engine-neutral-idle-clip.json').read_text());source=json.loads((P/'filtered-idle-source.json').read_text());raw=Path('/workspace/shared/horse-public-base-search-20261022/horse-53a6eb7ccf054aa2a378dd7ec08f88fe.glb').read_bytes();assert hashlib.sha256(raw).hexdigest()==bundle['source_sha256']==source['source_sha256']=='41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988'
n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);binary=raw[28+n:]
def values(i):
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];fmt={5121:'B',5123:'H',5125:'I',5126:'f'}[a['componentType']];width={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']];size=struct.calcsize(fmt)*width;off=v.get('byteOffset',0)+a.get('byteOffset',0);return [struct.unpack_from('<'+fmt*width,binary,off+k*v.get('byteStride',size)) for k in range(a['count'])]
assert len(g['animations'])==6 and len(g['skins'])==1 and g['skins'][0]['joints'][12]==17 and g['skins'][0]['joints'][14]==19
assert not any(g['nodes'][i].get('children') for i in [17,19]);assert not any(p.get('targets') for m in g['meshes'] for p in m['primitives'])
tracks=[]
for t in bundle['animation']['tracks']:
 assert t['target']=={'node':t['target']['node'],'path':'rotation'} and t['target']['node'] in [17,19]
 times=t['sampler']['input_times_s'];out=t['sampler']['output_in_value_out_quaternions_xyzw'];assert len(times)==193 and times[0]==0 and times[-1]==12 and all(math.isfinite(v) for v in times+out) and all(a<b for a,b in zip(times,times[1:]));assert len(out)==193*12
 f=struct.unpack('<'+'f'*len(out),struct.pack('<'+'f'*len(out),*out));default=g['nodes'][t['target']['node']]['rotation'];norm=lambda q:math.sqrt(math.fsum(x*x for x in q));max_key_norm_error=max(abs(norm(f[i*12+4:i*12+8])-1) for i in range(193));assert max_key_norm_error<1e-6
 assert list(f[4:8])==default and list(f[-8:-4])==default and all(x==0 for x in f[:4]+f[8:12]+f[-12:-8]+f[-4:])
 minnorm=1e9;maxangle=0;rest=[x/norm(default) for x in default];projection_lower=math.inf;orthogonal_upper=0
 for k in range(192):
  q0=f[k*12+4:k*12+8];q1=f[(k+1)*12+4:(k+1)*12+8];m0=f[k*12+8:k*12+12];m1=f[(k+1)*12:(k+1)*12+4];controls=[q0,[q0[j]+.0625*m0[j]/3 for j in range(4)],[q1[j]-.0625*m1[j]/3 for j in range(4)],q1]
  for control in controls:
   projection=math.fsum(a*b for a,b in zip(rest,control));projection_lower=min(projection_lower,projection);orthogonal_upper=max(orthogonal_upper,norm([control[j]-projection*rest[j] for j in range(4)]))
 assert projection_lower>.999
 for i in range(1537):
  timepoint=i*12/1536;k=min(191,int(timepoint/.0625));u=(timepoint-times[k])/.0625;a=2*u**3-3*u**2+1;b=u**3-2*u**2+u;d=-2*u**3+3*u**2;e=u**3-u**2
  q=[a*f[k*12+4+j]+b*.0625*f[k*12+8+j]+d*f[(k+1)*12+4+j]+e*.0625*f[(k+1)*12+j] for j in range(4)];normq=norm(q);minnorm=min(minnorm,normq);assert normq>.999
  unit=[x/normq for x in q];angle=2*math.acos(min(1,abs(math.fsum(a*b for a,b in zip(rest,unit)))));maxangle=max(maxangle,angle)
 tracks.append({'node':t['target']['node'],'inputs':193,'output_accessor_VEC4_count':579,'maximum_key_norm_error':max_key_norm_error,'minimum_raw_cubic_norm':minnorm,'continuous_Bezier_projection_lower_bound':projection_lower,'continuous_rotation_angle_upper_bound_deg':math.degrees(2*math.atan2(orthogonal_upper,projection_lower)),'independent_1537_sample_maximum_angle_deg':math.degrees(maxangle),'endpoints_exact_native_f32':True,'endpoint_tangents_zero':True})
assert {t['node'] for t in tracks}=={17,19}
# Independent actual index/skin coefficient inspection at the four frozen annotated patches.
guard=source['support_guard'];p=g['meshes'][g['nodes'][22]['mesh']]['primitives'][0];index=[x[0] for x in values(p['indices'])];joint=values(p['attributes']['JOINTS_0']);weight=values(p['attributes']['WEIGHTS_0']);assert len(joint)==len(weight)==guard['vertex_count']==4313
patches=[]
for name,faces in guard['triangles_by_hoof'].items():
 assert name in ['fore_l','fore_r','hind_l','hind_r'] and all(type(f)is int and 0<=3*f+2<len(index) for f in faces)
 ids={index[3*f+k] for f in faces for k in range(3)};assert ids and all(type(i)is int and 0<=i<4313 for i in ids)
 nonzero=[(i,k,w) for i in ids for k,w in zip(joint[i],weight[i]) if k in [12,14] and w!=0];assert not nonzero
 patches.append({'hoof':name,'triangles':len(faces),'actual_vertices':len(ids),'exact_nonzero_target_leaf_weights':len(nonzero)})
assert len(patches)==4
report={'verdict':'CLEAR_FOR_ONE_ROOT_RELEASED_APPEND_OF_EXACT_FROZEN_BUNDLE; runtime_hardening_recommendations_before_Mixer_test; no_activation_approval','elapsed_seconds':time.monotonic()-start,'reviewed_manifest_sha256':sha(P/'MANIFEST.json'),'source_original_sha256':hashlib.sha256(raw).hexdigest(),'bundle_sha256':sha(P/'engine-neutral-idle-clip.json'),'append_producer_sha256':sha(P/'append_idle_glb.py'),'runtime_adapter_sha256':sha(P/'idle-playback-adapter.mjs'),'checks':{'all_frozen_manifest_entries_match':True,'both_targets_actual_skin_leaves':True,'native_original_clips':6,'original_morph_targets':False,'source_sha_and_node_mapping_exact':True},'tracks':tracks,'actual_native_hoof_coefficient_checks':patches,'scope':'Source arithmetic and exact skin coefficients only; no append invocation/generatedGLB/posedskin/Mixer/browser/app/prodtest'}
(R/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
