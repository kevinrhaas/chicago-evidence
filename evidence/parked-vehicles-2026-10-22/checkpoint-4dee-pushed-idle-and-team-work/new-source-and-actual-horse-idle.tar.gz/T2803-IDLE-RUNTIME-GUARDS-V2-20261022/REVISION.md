# Runtime guard revision V2

Frozen V1 source packet remains unchanged. The reviewed clip bundle a759bf11 and append producer b23c1c73 are unchanged; this revision only hardens the proposed runtime adapter. It rejects wrong source identity, missing/empty/extra hoof patches, invalid triangle/vertex ranges, changed 4313-vertex contact body, and empty/duplicate/misidentified source channels or rest quaternions before creating a Mixer.

The adapter no longer caps delta at 0.1 seconds. It consumes finite nonnegative host delta only while visible, unpaused and not in reduced motion. Hidden/paused time is discarded. Seeded instance variation fixes initial rest delay and playback rate; this is not a claim of wall-clock determinism. Large host deltas can skip visible intermediate poses, as with any sampled renderer; production host scheduling remains subject to review.

Guard controls use actual decoded GLB contact arrays and Three classes but deliberately stop before Mixer construction. They are rejection/contract tests, not actual animation loading, posed-surface, contact, rendering or photographic approval. Actual append/export is separate at ../T2803-IDLE-APPEND-ACTUAL-20261022.

Actual controls: 18 source/geometry contract cases PASS plus four stub-Mixer clock bookkeeping cases PASS. One valid-source false rejection was caught first (nonunit native Float32 quaternion); preserve FIRST-GUARD-CONTROL-FAILURE.txt. Orientation checks now normalize temporary copies and separately bound the live quaternion norm; native source values remain unchanged. Clock partition check compares one20s active delta against200×0.1s with the same seed to1e-10s; this tests bookkeeping only, not actual Mixer poses or wall-clock scheduling.
