// Actual source arrays + real Three inventory; stop BEFORE Mixer. No posed-surface proof.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as THREE from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.core.js';
import {createExportedHorseIdle} from './idle-playback-adapter.mjs';
const base='/workspace/shared/T2803-sevket-native-clips-20261022/';
const source=JSON.parse(fs.readFileSync(base+'filtered-idle-source.json'));
const receipt=JSON.parse(fs.readFileSync('/workspace/shared/T2803-IDLE-APPEND-ACTUAL-20261022/APPEND-RECEIPT.json'));
const raw=fs.readFileSync(receipt.original_source),n=raw.readUInt32LE(12),doc=JSON.parse(raw.subarray(20,20+n)),bin=raw.subarray(28+n);
function attr(id){const a=doc.accessors[id],v=doc.bufferViews[a.bufferView],width={SCALAR:1,VEC3:3,VEC4:4}[a.type],types={5126:Float32Array,5125:Uint32Array,5123:Uint16Array,5121:Uint8Array},C=types[a.componentType],out=new C(a.count*width),size=C.BYTES_PER_ELEMENT;for(let i=0;i<a.count;i++)for(let k=0;k<width;k++){const off=(v.byteOffset||0)+(a.byteOffset||0)+i*(v.byteStride||size*width)+k*size;out[i*width+k]=a.componentType===5126?bin.readFloatLE(off):size===4?bin.readUInt32LE(off):size===2?bin.readUInt16LE(off):bin.readUInt8(off);}return new THREE.BufferAttribute(out,width,!!a.normalized);}
function fixture(){const root=new THREE.Group(),bones=doc.skins[0].joints.map(id=>{const b=new THREE.Bone();b.name=doc.nodes[id].name;b.quaternion.fromArray(doc.nodes[id].rotation||[0,0,0,1]);root.add(b);return b;});const skeleton=new THREE.Skeleton(bones);for(let i=0;i<3;i++){const g=new THREE.BufferGeometry(),m=new THREE.SkinnedMesh(g,new THREE.MeshBasicMaterial());m.skeleton=skeleton;m.name=i===0?source.support_guard.mesh_renderer_name:'inventory-only-'+i;if(i===0){const p=doc.meshes[doc.nodes[22].mesh].primitives[0];g.setIndex(attr(p.indices));for(const [key,name]of [['POSITION','position'],['JOINTS_0','skinIndex'],['WEIGHTS_0','skinWeight']])g.setAttribute(name,attr(p.attributes[key]));}root.add(m);}const tracks=source.derived_channels.map(c=>new THREE.QuaternionKeyframeTrack(c.native_node_name+'.quaternion',[0,12],[...c.native_default_quaternion_xyzw,...c.native_default_quaternion_xyzw]));return {root,clips:[...Array.from({length:6},(_,i)=>new THREE.AnimationClip('native'+i,1,[])),new THREE.AnimationClip('sevket_reconstructed_head_tail_idle_v1',12,tracks)]};}
const T={...THREE,AnimationMixer:class{constructor(){throw Error('PREMIXER_OK');}}};
const outcomes=[];
function run(name,mutate,expected){const f=fixture(),s=structuredClone(source);mutate(s,f);let error;try{createExportedHorseIdle({T,...f,source:s,verifiedDerivedSha256:receipt.derived_sha256,appendReceipt:receipt,instanceId:'guard-test'});}catch(e){error=e.message;}assert.match(error||'',expected,name);outcomes.push({name,result:'PASS',terminal:error});}
run('actual valid source reaches Mixer boundary',()=>{},/^PREMIXER_OK$/);
run('wrong source hash',s=>s.source_sha256='wrong',/source identity/);
run('empty patch map',s=>s.support_guard.triangles_by_hoof={},/exact four hoof/);
run('missing patch',s=>delete s.support_guard.triangles_by_hoof.fore_l,/exact four hoof/);
run('extra patch',s=>s.support_guard.triangles_by_hoof.extra=[1],/exact four hoof/);
run('empty patch',s=>s.support_guard.triangles_by_hoof.fore_l=[],/nonempty hoof/);
run('negative triangle',s=>s.support_guard.triangles_by_hoof.fore_l=[-1],/triangle out/);
run('fractional triangle',s=>s.support_guard.triangles_by_hoof.fore_l=[1.5],/triangle out/);
run('oversized triangle',s=>s.support_guard.triangles_by_hoof.fore_l=[1e8],/triangle out/);
run('invalid selected index',(s,f)=>f.root.getObjectByName(s.support_guard.mesh_renderer_name).geometry.index.setX(s.support_guard.triangles_by_hoof.fore_l[0]*3,4313),/vertex out/);
run('wrong declared vertex count',s=>s.support_guard.vertex_count=4312,/contact identity/);
run('wrong actual vertex count',(s,f)=>f.root.getObjectByName(s.support_guard.mesh_renderer_name).geometry.attributes.position.count=4312,/attribute dimensions/);
run('empty channels',s=>s.derived_channels=[],/exact two source/);
run('duplicate channels',s=>s.derived_channels[1]=structuredClone(s.derived_channels[0]),/channel cardinality/);
run('wrong native node',s=>s.derived_channels[0].native_node_index=18,/channel identity/);
run('changed rest quaternion',s=>s.derived_channels[0].native_default_quaternion_xyzw[0]+=1e-4,/rest quaternion/);
run('leaf hoof weight introduced',(s,f)=>{const g=f.root.getObjectByName(s.support_guard.mesh_renderer_name).geometry,id=g.index.getX(s.support_guard.triangles_by_hoof.fore_l[0]*3);g.attributes.skinIndex.setX(id,12);g.attributes.skinWeight.setX(id,.01);},/leaf influences/);
run('bone order identity changed',(s,f)=>f.root.children.find(n=>n.name==='Bone.011_Armature').name='wrong',/leaf name/);
const clockOutcomes=[];
function clockFixture(){let total=0;const F={...THREE,AnimationMixer:class{clipAction(){return{setLoop(){},play(){}};}setTime(){}update(dt){total+=dt;}stopAllAction(){}uncacheRoot(){}}},f=fixture();const player=createExportedHorseIdle({T:F,...f,source,verifiedDerivedSha256:receipt.derived_sha256,appendReceipt:receipt,instanceId:'clock-test'});return{player,total:()=>total};}
const one=clockFixture(),many=clockFixture();one.player.update(20);for(let i=0;i<200;i++)many.player.update(.1);assert.ok(Math.abs(one.total()-many.total())<1e-10);clockOutcomes.push({name:'same active host delta across partitions without hidden clamp',result:'PASS',single_delta_s:one.total(),partitioned_delta_s:many.total()});
const frozen=clockFixture();for(const option of [{visible:false},{reducedMotion:true},{paused:true}])frozen.player.update(20,option);assert.equal(frozen.total(),0);assert.equal(frozen.player.status.elapsed_s,0);clockOutcomes.push({name:'visibility reduced-motion and explicit pause discard time',result:'PASS'});
assert.throws(()=>frozen.player.update(-1),/invalid clock/);assert.throws(()=>frozen.player.update(NaN),/invalid clock/);clockOutcomes.push({name:'invalid host delta rejection',result:'PASS'});
frozen.player.dispose();frozen.player.dispose();frozen.player.update(1);assert.equal(frozen.total(),0);assert.equal(frozen.player.status.mixer_count,0);clockOutcomes.push({name:'idempotent disposal and no later clock advance',result:'PASS'});
console.log(JSON.stringify({clock_scope:'stub Mixer clock bookkeeping only; no actual animation evaluation',clockOutcomes,status:'PASS rejection controls only; actual Mixer/posed surface NOT executed',cases:outcomes.length,outcomes},null,2));
