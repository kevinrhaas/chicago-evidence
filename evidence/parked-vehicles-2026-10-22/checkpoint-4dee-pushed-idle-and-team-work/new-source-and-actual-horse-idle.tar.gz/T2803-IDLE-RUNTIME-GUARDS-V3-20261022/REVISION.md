# Runtime guard V3

V2 remains frozen, source-reviewed failure: it compared actual GLTFLoader bone.name against raw source names containing dots. Actual GLTFLoader removes dots using PropertyBinding.sanitizeNodeName and stores original names in userData.name. V3 requires both exact sanitized name and exact original userData.name, with unchanged joint index, leaf hierarchy and track-target whitelist. Guard fixture now follows those actual loader name semantics, rather than handbuilding raw names. This is not an actual GLTFLoader/Mixer or posed surface test.

All V2 source identity/contact/channel/rest/clock guard changes remain. Original bundle a759bf11/producer b23c1c73 unchanged; first append2f590 is NOT intake approved because inherited Khronos errors/warnings remain. Separate normalization proposal will address those without overwriting the licensed original.
