import json,pathlib,hashlib
root=pathlib.Path(__file__).parent
ns={'__file__':str(root/'prepare-route.py')};exec((root/'prepare-route.py').read_text().split('# Eastward')[0],ns)
base=json.loads((root/'first-failed-route/route.json').read_bytes());folder=root/'six-alternative-routes';folder.mkdir(exist_ok=True)
cases=[('lake','randolph','wells','lasalle'),('lake','randolph','lasalle','clark'),('lake','randolph','franklin','wells'),('randolph','washington','wells','lasalle'),('randolph','washington','lasalle','clark'),('south_water','lake','lasalle','clark')]
for i,(north,south,west,east) in enumerate(cases):
 data=dict(base);data['id']=f'w01_1835_closed_block_{i+1}_{north}_{south}_{west}_{east}'
 pairs=[(south,west),(south,east),(north,east),(north,west)]
 data['corners_enu_m']=[ns['intersection'](*p) for p in pairs]
 data['road_ids']=[south,east,north,west]
 data['source_ids']=sorted(set(ns['data']['sources']+[s for name in data['road_ids'] for s in ns['roads'][name].get('sources',[])]))
 p=folder/f'{i+1}.route.json';p.write_text(json.dumps(data,indent=2)+'\n')
print('prepared exactly6 alternate actual-road closed blocks')
