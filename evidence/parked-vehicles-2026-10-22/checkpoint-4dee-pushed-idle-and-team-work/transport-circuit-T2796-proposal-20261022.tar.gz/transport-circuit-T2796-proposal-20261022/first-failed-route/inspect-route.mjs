// Finite actual-data route diagnosis only. No scene/global admission; no writes in app.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root = path.dirname(new URL(import.meta.url).pathname), app = '/workspace/chicago/chicago/4d';
const read = p => JSON.parse(fs.readFileSync(path.join(app, p)));
const sha = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const source = fs.readFileSync(root + '/proposed/renderers/web/js/transport-circuit.js');
const { compileTransportCircuit } = await import(`data:text/javascript;base64,${source.toString('base64')}`);
const route = JSON.parse(fs.readFileSync(root + '/proposed/data/transport/routes/w01-1835-circuit.json'));
for (const [p, digest] of Object.entries(route.source_inputs_sha256)) if (sha(app + '/' + p) !== digest) throw Error('changed route source ' + p);
const circuit = compileTransportCircuit(route), streets = read('data/streets/1835.json');
const roads = streets.streets.filter(r => route.road_ids.includes(r.id)).map(r => ({ id: r.id,
  line: r.drawn_track_local_enu_m ?? r.path_local_enu_m, core: r.track_width_m / 2,
  worked: Math.max(r.track_width_m, ({ principal: .80, ordinary: .64, light: .44 }[r.traffic] ?? .44) * (r.corridor_width_m ?? 24.384)) / 2,
  row: (r.corridor_width_m ?? 24.384) / 2 }));
const sub = (a, b) => [a[0] - b[0], a[1] - b[1]], dot = (a, b) => a[0] * b[0] + a[1] * b[1];
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
function segmentDistance(p, a, b) { const d = sub(b, a), t = Math.max(0, Math.min(1, dot(sub(p, a), d) / dot(d, d))); return dist(p, [a[0] + t * d[0], a[1] + t * d[1]]); }
const inside = (p, poly) => { let yes = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) if ((poly[i][1] > p[1]) !== (poly[j][1] > p[1]) && p[0] < (poly[j][0] - poly[i][0]) * (p[1] - poly[i][1]) / (poly[j][1] - poly[i][1]) + poly[i][0]) yes = !yes; return yes; };
const edge = poly => poly.map((p, i) => [p, poly[(i + 1) % poly.length]]);
function crossing(a, b, c, d) { const u = sub(b, a), v = sub(d, c), w = sub(c, a), den = u[0] * v[1] - u[1] * v[0]; if (Math.abs(den) < 1e-12) return false; const t = (w[0] * v[1] - w[1] * v[0]) / den, q = (w[0] * u[1] - w[1] * u[0]) / den; return t >= 0 && t <= 1 && q >= 0 && q <= 1; }
function polygonDistance(a, b) { if (inside(a[0], b) || inside(b[0], a)) return 0; let min = Infinity; for (const [p, q] of edge(a)) for (const [r, s] of edge(b)) { if (crossing(p, q, r, s)) return 0; min = Math.min(min, segmentDistance(p, r, s), segmentDistance(q, r, s), segmentDistance(r, p, q), segmentDistance(s, p, q)); } return min; }
const box = pts => ({ e0: Math.min(...pts.map(p => p[0])), e1: Math.max(...pts.map(p => p[0])), n0: Math.min(...pts.map(p => p[1])), n1: Math.max(...pts.map(p => p[1])) });
const overlap = (a, b, pad) => a.e0 <= b.e1 + pad && a.e1 >= b.e0 - pad && a.n0 <= b.n1 + pad && a.n1 >= b.n0 - pad;
const obstacles = [], coverage = { buildings: 0, fenceSegments: 0, sidewalks: 0, hitchingPosts: 0, staticWagons: 0 };
function obstacle(id, pts, pad, kind) { obstacles.push({ id, pts, pad, kind, bounds: box(pts) }); coverage[kind]++; }
const index = read('data/sidecars/1835/index.json');
for (const record of index.structures) {
  const sidecar = read('data/' + record.sidecar), raw = sidecar.footprint, poly = Array.isArray(raw) ? raw : raw?.polygon, p = sidecar.placement;
  if (!poly?.length || !p || p.vertical_anchor === 'water') continue;
  const theta = (p.rotation_deg ?? 0) * Math.PI / 180;
  // Conservatively includes drawn_by/camp footprints; no passages opened for a team.
  obstacle(record.id, poly.map(([u, v]) => [p.local_e + u * Math.cos(theta) + v * Math.sin(theta), p.local_n - u * Math.sin(theta) + v * Math.cos(theta)]), 0, 'buildings');
}
for (const rec of read('data/enclosures/index.json').enclosures) {
  const data = read('data/enclosures/' + rec.file);
  for (const run of data.runs ?? []) {
    const points = run.path_local_enu_m ?? [];
    for (let i = 1; i < points.length; i++) obstacle(rec.id + '/' + run.id + '/' + i, [points[i - 1], points[i]], .20, 'fenceSegments');
  }
}
const front = read('data/frontage/town_street_edge.json');
for (const walk of front.walks) if (walk.kind === 'plank_walk') for (let i = 1; i < walk.centreline_local_enu_m.length; i++) obstacle(walk.id, walk.centreline_local_enu_m.slice(i - 1, i + 1), walk.width_m / 2, 'sidewalks');
for (const fence of front.fences) for (let i = 1; i < fence.path_local_enu_m.length; i++) obstacle(fence.id, fence.path_local_enu_m.slice(i - 1, i + 1), .20, 'fenceSegments');
for (const p of front.posts) obstacle(p.id, [p.at_local_enu_m, p.at_local_enu_m], .20, 'hitchingPosts');
const wagonIds = new Set();
for (const rec of read('data/yard/index.json').yard) for (const w of read('data/yard/' + rec.file).wagons ?? []) { if (!wagonIds.has(w.id)) { wagonIds.add(w.id); obstacle(w.id, [w.at_local_enu_m, w.at_local_enu_m], 5, 'staticWagons'); } }
for (const w of read('data/transport/parked/placements.json').scenes['1835']) if (!wagonIds.has(w.replaces)) obstacle(w.id, [w.at_local_enu_m, w.at_local_enu_m], 5, 'staticWagons');
// Provisional over-envelope from actual support-oriented horse bounds at pairX±.8,
// rootZ3.90 relativeW01, W01root1.175 ahead of rearaxle. Native wagon proof pending.
const hull = { x0: -1.30, x1: 1.30, z0: -1, z1: 6.80, status: 'provisional; must bind exact coupled native bounds before qualification' };
const local = [[hull.x0, hull.z0], [hull.x1, hull.z0], [hull.x1, hull.z1], [hull.x0, hull.z1]];
const radius = Math.max(...local.map(p => Math.hypot(...p))), step = .50, clearance = .25;
const divisions = [Math.ceil((hull.x1 - hull.x0) / .5), Math.ceil((hull.z1 - hull.z0) / .5)];
const cover = Math.hypot((hull.x1 - hull.x0) / divisions[0], (hull.z1 - hull.z0) / divisions[1]) / 2;
const grid = [];
for (let i = 0; i <= divisions[0]; i++) for (let j = 0; j <= divisions[1]; j++) grid.push([hull.x0 + i * (hull.x1 - hull.x0) / divisions[0], hull.z0 + j * (hull.z1 - hull.z0) / divisions[1]]);
const summary = { route: route.id, length_m: circuit.length_m, radius_m: route.turn_radius_m, steer_deg: Math.atan(route.wheelbase_m / route.turn_radius_m) * 180 / Math.PI, hull, coverage,
  road_clearance: Object.fromEntries(['core', 'worked', 'row'].map(k => [k, { minimum_certified_margin_m: Infinity, failures: 0, firstFailure: null }])), obstacles: { minimum_certified_margin_m: Infinity, failures: 0, firstFailures: [] },
  proof: { method: 'Each rigid rectangle covered by finite lattice; maximum lattice distance + halfstation travel*(1+maxpointRadius*maxcurvature) bounds every continuous swept point, including across C1 joins. Road distance-to-segment is1-Lipschitz. Exact whole rectangle distance to obstacle segments/polygons minus motion/clearance bounds each sweep interval.', station_step_m: step, local_lattice_cover_radius_m: cover, clearance_m: clearance, stationary_steering_scope: 'Provisional hull must also enclose native all-steering hardware and fitted hitch/team. This is not yet proven.' }, source_head: 'b0924b41c25d0d9bf975feb9b6e245a1b3f288e3', live_enabled: false };
const metaPath = `data/terrain/epochs/${route.terrain_epoch}/heightfield.json`, meta = read(metaPath), bin = fs.readFileSync(app + '/' + metaPath.replace('.json', '.bin'));
if (meta.encoding !== 'int16' || bin.length !== meta.cols * meta.rows * 2) throw Error('actual heightfield encoding/length');
const terrain = { minimum_bound_y_m: Infinity, outside_cells: 0, cell_vertex_reads: 0,
  method: 'All heightfield cell vertices under each inflated oriented-hull AABB; bilinear ground stays within four cell heights. Overbounding boxes cover continuous between-station sweep. No wheel/hoof-grade/contact claim.',
  sha256: { metadata: sha(app + '/' + metaPath), binary: sha(app + '/' + metaPath.replace('.json', '.bin')) } };
let stations = 0;
for (let s = 0; s < circuit.length_m; s += step) {
  const p = circuit.sampleDistance(s), theta = p.bearing_rad, motion = step / 2 * (1 + radius / route.turn_radius_m);
  const world = ([x, z]) => [p.e + x * Math.cos(theta) + z * Math.sin(theta), p.n - x * Math.sin(theta) + z * Math.cos(theta)];
  // +X asset LEFT, so +X maps WEST at headingNorth (yawPi), not EAST.
  const modelWorld = ([x, z]) => world([-x, z]);
  const poly = local.map(modelWorld), bb = box(poly);
  const groundPad = motion + clearance;
  const x0 = Math.floor((bb.e0 - groundPad - meta.origin_e) / meta.cell_m), x1 = Math.floor((bb.e1 + groundPad - meta.origin_e) / meta.cell_m) + 1;
  const z0 = Math.floor((bb.n0 - groundPad - meta.origin_n) / meta.cell_m), z1 = Math.floor((bb.n1 + groundPad - meta.origin_n) / meta.cell_m) + 1;
  for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
    if (x < 0 || z < 0 || x >= meta.cols || z >= meta.rows) { terrain.outside_cells++; continue; }
    terrain.minimum_bound_y_m = Math.min(terrain.minimum_bound_y_m, bin.readInt16LE((z * meta.cols + x) * 2) * meta.scale + meta.offset); terrain.cell_vertex_reads++;
  }
  for (const point of grid.map(modelWorld)) for (const key of ['core', 'worked', 'row']) {
    let roadMargin = -Infinity;
    for (const road of roads) for (let i = 1; i < road.line.length; i++) roadMargin = Math.max(roadMargin, road[key] - segmentDistance(point, road.line[i - 1], road.line[i]));
    const margin = roadMargin - cover - motion - clearance, record = summary.road_clearance[key];
    record.minimum_certified_margin_m = Math.min(record.minimum_certified_margin_m, margin);
    if (margin < 0) { record.failures++; record.firstFailure ??= { s, point, margin }; }
  }
  for (const obstacle of obstacles) if (overlap(bb, obstacle.bounds, motion + clearance + obstacle.pad)) {
    let gap;
    if (obstacle.pts.length === 2 && dist(...obstacle.pts) === 0) {
      gap = inside(obstacle.pts[0], poly) ? 0 : Math.min(...edge(poly).map(([a, b]) => segmentDistance(obstacle.pts[0], a, b)));
    } else gap = polygonDistance(poly, obstacle.pts);
    const margin = gap - obstacle.pad - motion - clearance;
    summary.obstacles.minimum_certified_margin_m = Math.min(summary.obstacles.minimum_certified_margin_m, margin);
    if (margin < 0) { summary.obstacles.failures++; if (summary.obstacles.firstFailures.length < 12) summary.obstacles.firstFailures.push({ s, id: obstacle.id, kind: obstacle.kind, margin }); }
  }
  stations++;
}
summary.stations = stations;
summary.terrain = terrain;
summary.scope = 'Finite conservative geometric diagnosis using current authored road centreline strips and registered obstacle projections; provisional assembly hull, no actual rendered road triangle/terrain/harness/traffic contact or scene qualification. ROW result is geometry only, never travel permission. Stationary steering does not move the reference but hardware must fit the hull.';
summary.road_line_hashes = route.source_inputs_sha256;
fs.writeFileSync(root + '/ROUTE-CLEARANCE-DIAGNOSIS.json', JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify(summary));
