import json,math,pathlib,hashlib
app=pathlib.Path('/workspace/chicago/chicago/4d');root=pathlib.Path(__file__).parent
street=app/'data/streets/1835.json';data=json.loads(street.read_bytes());roads={r['id']:r for r in data['streets']}
def line(name):
 r=roads[name];return r.get('drawn_track_local_enu_m',r['path_local_enu_m'])
def intersection(a,b):
 cross=lambda a,b:a[0]*b[1]-a[1]*b[0]
 hits=[]
 for ai,(aa,ab) in enumerate(zip(line(a),line(a)[1:])):
  for bi,(ba,bb) in enumerate(zip(line(b),line(b)[1:])):
   u=[ab[j]-aa[j] for j in range(2)];v=[bb[j]-ba[j] for j in range(2)];den=cross(u,v)
   if abs(den)<1e-9:continue
   delta=[ba[j]-aa[j] for j in range(2)];t=cross(delta,v)/den;q=cross(delta,u)/den
   if -0.01/math.hypot(*u)<=t<=1+0.01/math.hypot(*u) and -0.01/math.hypot(*v)<=q<=1+0.01/math.hypot(*v):hits.append([aa[j]+t*u[j] for j in range(2)])
 unique=[]
 for point in hits:
  if not any(math.dist(point,previous)<1e-8 for previous in unique):unique.append(point)
 assert len(unique)==1,(a,b,unique)
 return unique[0]
# Eastward along Lake, north along LaSalle, west along SouthWater, south Wells.
pairs=[('lake','wells'),('lake','lasalle'),('south_water','lasalle'),('south_water','wells')]
sources=sorted(set(data['sources']+[s for a,b in pairs for name in (a,b) for s in roads[name].get('sources',[])]))
for source in sources:assert (app/'data/sources'/f'{source}.json').is_file(),source
route={'schema':'transport_closed_circuit_v1','id':'w01_lake_wells_lasalle_1835_circuit_candidate','scene':'1835','target_date':data['target_date'],'units':'m','axes':'ENU e,n; +Yup/+Zforward asset; model yaw=pi-bearing','reference':'rear_axle','grade':'reconstructed','historical_schedule':None,'owner':None,'driver_person_id':None,'live_enabled':False,'source_ids':sources,'source_scope':'Street existence/alignment only; the repeating traffic, direction, stopping and speed are original mechanical reconstruction, not evidence of a specific daily journey. Modern coordinates already anchor existing dated roads; no new modern network imported.','road_ids':['lake','lasalle','south_water','wells'],'corner_construction':'Intersections of current drawn reaches; maximum allowed endpoint extrapolation10mm, needed because source street ends differ by about4mm at SouthWater. No authored line is moved.', 'corners_enu_m':[intersection(*p) for p in pairs],'turn_radius_m':17,'wheelbase_m':2.35,'steer_limit_deg':8,'speed_m_s':0.8,'acceleration_m_s2':0.25,'steering_settle_s':1,'lap_pause_s':2,'road_classification':'Validate worn core separately from existing renderer worked earth; no platted ROW used as inferred traffic permission.','terrain_epoch':'e1834_harbor_cut','source_inputs_sha256':{str(street.relative_to(app)):hashlib.sha256(street.read_bytes()).hexdigest(),'renderers/web/js/streets.js':hashlib.sha256((app/'renderers/web/js/streets.js').read_bytes()).hexdigest()},'qualification':{'route':False,'vehicle':False,'horseGait':False,'harness':False,'driver':False,'mobile':False}}
p=root/'proposed/data/transport/routes/w01-1835-circuit.json';p.write_text(json.dumps(route,indent=2)+'\n');print(json.dumps({'corners':route['corners_enu_m'],'sources':sources,'route_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
