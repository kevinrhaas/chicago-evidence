import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const root='/workspace/shared/transport-circuit-T2796-proposal-20261022',peer='/workspace/shared/T2795-W01-PAIR-SOURCE-HELD-20261022';
const source=fs.readFileSync(root+'/proposed/renderers/web/js/transport-circuit.js');
const {createTransportCircuitController}=await import(`data:text/javascript;base64,${source.toString('base64')}`);
const peerFile=peer+'/proposed/chicago/4d/renderers/web/js/moving-team-kinematics.mjs';
const {createW01TeamKinematics}=await import(peerFile);
const contract=JSON.parse(fs.readFileSync(peer+'/NATIVE-INPUTS-AND-FIT-CONTRACT.json'));
const route=JSON.parse(fs.readFileSync(root+'/proposed/data/transport/routes/w01-1835-circuit.json'));
const actor=createTransportCircuitController(route,{id:'w01_existing_bardwell_team_diagnostic'}),rig=createW01TeamKinematics(contract);
let samples=0,maxSteer=0,maxDs=0,previous=actor.sample();
rig.step(actor.sample(),[0,0,0,0]);
let left=actor.cycle_duration_s;
while(left>1e-8){const dt=Math.min(1/30,left),state=actor.update(dt);left-=dt;for(const s of state.integration_samples){let pose;try{pose=rig.step(s,[0,0,0,0]);}catch(e){console.error(JSON.stringify({error:e.message,previous,s}));throw e;}previous=s;assert.equal(pose.liveActivationAllowed,false);maxSteer=Math.max(maxSteer,Math.abs(pose.vehicle.steer_rad));maxDs=Math.max(maxDs,pose.increments.rear_axle_distance_m);samples++;}}
const end=actor.sample();assert(Math.abs(end.distance_m-actor.circuit.length_m)<1e-6);
for(const key of ['paused','reducedMotion','blocked']){const hold=actor.update(.5,{[key]:true});for(const s of hold.integration_samples){const pose=rig.step(s,[0,0,0,0]);assert(Math.abs(pose.increments.rear_axle_distance_m)<1e-10);}}
const result={status:'PASS_CPU_SOURCE_INTEROPERABILITY_ONLY',scene:'1835',samples,full_cycle_s:actor.cycle_duration_s,closed_circuit_m:actor.circuit.length_m,max_steer_deg:maxSteer*180/Math.PI,max_rear_axle_increment_m:maxDs,flat_ground_fixture:[0,0,0,0],actual_route_ground_contact_test:false,source_sha256:crypto.createHash('sha256').update(source).digest('hex'),peer_source_sha256:crypto.createHash('sha256').update(fs.readFileSync(peerFile)).digest('hex'),peer_contract_sha256:crypto.createHash('sha256').update(fs.readFileSync(peer+'/NATIVE-INPUTS-AND-FIT-CONTRACT.json')).digest('hex'),gait_or_harness_or_driver_fit_accepted:false,live_activation_allowed:false};
fs.writeFileSync(root+'/PEER-INTEROPERABILITY.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
