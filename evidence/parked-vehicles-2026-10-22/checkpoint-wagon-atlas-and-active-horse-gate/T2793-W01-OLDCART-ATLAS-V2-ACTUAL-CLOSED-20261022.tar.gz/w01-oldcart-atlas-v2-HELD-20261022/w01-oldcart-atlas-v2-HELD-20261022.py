"""GPL-3.0-or-later. ONE native-sampling atlas consolidation of frozenW01V1.

No geometry, triangle, paint/iron, pivot, variant or app change. More texture
memory is explicitly retained; no resampling conceals that cost.
"""
from pathlib import Path
import copy,hashlib,importlib.util,json,struct,time
import numpy as np
from PIL import Image
BASE=Path('/workspace/shared/w01-oldcart-material-transfer-v1-HELD-20261022')
spec=importlib.util.spec_from_file_location('w01_frozen_surface_helpers',BASE/'refine_timber_surface.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
OUT=Path('/workspace/shared/w01-oldcart-atlas-v2-HELD-20261022')
V1_SHA='da5df4b37ce6830af04f055453f6cb11890be29b3b28e9f4bd31a26bd3ff86ec'
SIZE=(2576,264);ORIGIN={'side':np.array([4,4]),'end':np.array([2060,4])};TILE={'side':np.array([512,128]),'end':np.array([128,128])}

def sample(image,uv):
 h,w=image.shape[:2];q=uv*np.array([w,h])-.5;lo=np.floor(q).astype(int);f=q-lo;a=image[lo[:,1]%h,lo[:,0]%w].astype(float);b=image[lo[:,1]%h,(lo[:,0]+1)%w].astype(float);c=image[(lo[:,1]+1)%h,lo[:,0]%w].astype(float);d=image[(lo[:,1]+1)%h,(lo[:,0]+1)%w].astype(float)
 return a*(1-f[:,0,None])*(1-f[:,1,None])+b*f[:,0,None]*(1-f[:,1,None])+c*(1-f[:,0,None])*f[:,1,None]+d*f[:,0,None]*f[:,1,None]
def world_normal(rgb,n,t):
 v=rgb/127.5-1;v[:,:2]*=.35;v/=np.linalg.norm(v,axis=1)[:,None];n=n/np.linalg.norm(n,axis=1)[:,None];t0=t[:,:3]-n*np.einsum('ij,ij->i',t[:,:3],n)[:,None];t0/=np.linalg.norm(t0,axis=1)[:,None];b=np.cross(n,t0)*t[:,3,None];w=t0*v[:,0,None]+b*v[:,1,None]+n*v[:,2,None];return w/np.linalg.norm(w,axis=1)[:,None]
def main():
 start=time.monotonic();m.need(not OUT.exists(),'Fresh output only');OUT.mkdir();(OUT/'textures').mkdir();receipt={'status':'RUNNING','visual_GPU_budget_acceptance':False}
 try:
  original=(m.ROOT/'renderers/web/transport/parked-wagon/wagon-w01.glb').read_bytes();v1=(BASE/'candidate-normalized/wagon-w01.glb').read_bytes();m.need(m.sha(original)==m.PARENT_SHA and m.sha(v1)==V1_SHA,'Frozen inputs changed');g,oldbin=m.unpack(original);before=copy.deepcopy(g);g1,b1=m.unpack(v1);binary=bytearray(oldbin);source={};atlas={};map_reports={}
  yy,xx=np.mgrid[:SIZE[1],:SIZE[0]]
  for kind in ['color','normal','orm']:
   side=np.asarray(Image.open(BASE/'candidate-normalized/textures'/('oldcart_timber_'+kind+'.png')).convert('RGB'));end=np.asarray(Image.open(BASE/'candidate-normalized/textures'/('original_cutend_'+kind+'.png')).convert('RGB'));m.need(side.shape==(128,512,3)and end.shape==(128,128,3),'Native source map sizes changed');source[kind]={'side':side,'end':end};a=side[(yy-4)%128,(xx-4)%512].copy();a[:,2056:]=end[(yy[:,2056:]-4)%128,(xx[:,2056:]-2060)%128];atlas[kind]=a;data=m.png(a);(OUT/'textures'/('shared_wood_'+kind+'.png')).write_bytes(data);map_reports[kind]={'pixels':list(SIZE),'sha256':m.sha(data),'bytes':len(data),'side_source_pixels':[512,128],'end_source_pixels':[128,128],'source_pixels_resampled':False,'gutter_pixels':4,'side_origin_pixels':[4,4],'end_origin_pixels':[2060,4],'side_exact_repeat_tiles':[4,2],'end_exact_repeat_tiles':[4,1]}
  def view(data,target=None):
   binary.extend(b'\0'*((-len(binary))%4));i=len(g['bufferViews']);v={'buffer':0,'byteOffset':len(binary),'byteLength':len(data)}
   if target:v['target']=target
   g['bufferViews'].append(v);binary.extend(data);return i
  def attr(a):
   a=np.asarray(a,dtype='<f4');vi=view(a.tobytes(),34962);i=len(g['accessors']);g['accessors'].append({'bufferView':vi,'componentType':5126,'count':len(a),'type':'VEC'+str(a.shape[1]),'min':a.min(0).tolist(),'max':a.max(0).tolist()});return i
  for kind,field in [('color','baseColorTexture'),('normal','normalTexture'),('orm','metallicRoughnessTexture')]:
   holder=g['materials'][1]if kind=='normal'else g['materials'][1]['pbrMetallicRoughness'];ti=holder[field]['index'];ii=g['textures'][ti]['source'];g['images'][ii]={'bufferView':view(m.png(atlas[kind])),'mimeType':'image/png'}
  for mi in [1,2,3]:
   g['materials'][mi]['normalTexture']['scale']=.35;g['materials'][mi]['extras']={'grade':'reconstructed unmeasured optical study','current_pixel_provenance':'Old Cart Lyskilde/longtail CC-BY-4.0 side timber; original CC0-1.0 cut ends','cut_end_chart':'separate region of shared wood atlas','historical_identity':'No maker/date/Dearborn/Chicago specimen established'}
  # Restore each original single primitive. Triangle-soup vertices are already
  # independent; integer UV rebase per triangle changes no texture phase and
  # requires neither vertex/face splitting nor added geometry.
  proofs=[];bary=np.array([[1/3,1/3,1/3],[.6,.2,.2],[.2,.6,.2],[.2,.2,.6]])
  for mesh,mesh1 in zip(g['meshes'],g1['meshes']):
   p=mesh['primitives'][0]
   if p['material']not in [1,2,3]:continue
   count=before['accessors'][p['attributes']['POSITION']]['count'];uv=np.zeros((count,2));tangent=None;records=[]
   for p1 in mesh1['primitives']:
    kind='end'if g1['materials'][p1['material']]['name'].endswith('_cut_end')else'side';old_uv=m.array(g1,b1,p1['attributes']['TEXCOORD_0']);tangent=m.array(g1,b1,p1['attributes']['TANGENT']);ids=m.array(g1,b1,p1['indices']).reshape(-1);faces=ids.reshape(-1,3);u=old_uv[faces];shift=np.floor(u.min(axis=1));new=((u-shift[:,None,:])*TILE[kind]+ORIGIN[kind])/np.array(SIZE);uv[ids]=new.reshape(-1,2);records.append((kind,faces,u))
   p['attributes']['TEXCOORD_0']=attr(uv);p['attributes']['TANGENT']=attr(tangent)
   # Sample serialized Float32 UVs, not ideal authoring doubles.
   actual_uv=m.array(g,binary,p['attributes']['TEXCOORD_0']);normal=m.array(g,binary,p['attributes']['NORMAL']);max_pixels={k:0. for k in atlas};max_normal=0.;num=0
   for kind,faces,old_u in records:
    q0=np.einsum('bj,fjk->fbk',bary,old_u).reshape(-1,2);q1=np.einsum('bj,fjk->fbk',bary,actual_uv[faces]).reshape(-1,2);n=np.einsum('bj,fjk->fbk',bary,normal[faces]).reshape(-1,3);tt=np.einsum('bj,fjk->fbk',bary,tangent[faces]).reshape(-1,4)
    for key in atlas:max_pixels[key]=max(max_pixels[key],float(np.max(np.abs(sample(source[key][kind],q0)-sample(atlas[key],q1)))))
    n0=world_normal(sample(source['normal'][kind],q0),n,tt);n1=world_normal(sample(atlas['normal'],q1),n,tt);max_normal=max(max_normal,float(np.linalg.norm(n1-n0,axis=1).max()));num+=len(q0)
   m.need(max(max_pixels.values())<.1,'Serialized atlas UV changes >.1 of one8bit sample step');m.need(max_normal<.0001,'Atlas world normal difference exceeds1e-4');proofs.append({'batch':mesh['name'],'sample_points':num,'maximum_bilinear_channel_error_in_8bit_units':max_pixels,'maximum_world_normal_vector_delta':max_normal})
  m.need(len(g['materials'])==6 and all(len(x['primitives'])==1 for x in g['meshes']),'Original material/primitive counts changed')
  for a,b in zip(g['meshes'],before['meshes']):
   p=a['primitives'][0];old=b['primitives'][0];m.need(p['attributes']['POSITION']==old['attributes']['POSITION']and p['attributes']['NORMAL']==old['attributes']['NORMAL']and p.get('indices')==old.get('indices')and p['material']==old['material'],'Original oriented geometry/material ownership changed')
  for key in ['nodes','skins','animations','scenes','scene']:m.need(g.get(key)==before.get(key),'Protected '+key+' changed')
  for mi in [0,4,5]:m.need(g['materials'][mi]==before['materials'][mi],'Protected original paint/iron/hubs changed')
  m.need(binary[:len(oldbin)]==oldbin,'Original binary prefix changed');g['asset']['copyright']=m.ATTRIBUTION;g['extras']['timber_surface_atlas_candidate']={'status':'UNACCEPTED:close/far visual and GPU/budget review pending','parent_sha256':m.PARENT_SHA,'v1_sha256':V1_SHA,'source_crop_native_pixels':[145,40],'source_author':'Lyskilde / longtail','source_license':'CC-BY-4.0','source_historical_identity':'not established','source_oriented_triangles_unchanged':True,'atlas_size_pixels':list(SIZE),'base_sampling':'native source texels repeated without resampling; integer per-triangle rebase','higher_mips':'4px gutters support bounded near-level filtering; coarse atlas mip bleed is unaccepted, not claimed identical at all levels'}
  if'material_study'in g['extras']:g['extras']['material_study'].update(images='CC-BY-4.0 donor-authored timber detail plus originalCC0 cut ends; no photo-resolution or period-finish attestation',endfaces='original reconstructed endgrain in shared atlas; painted hubs unchanged')
  binary.extend(b'\0'*((-len(binary))%4));g['buffers'][0]['byteLength']=len(binary);head=json.dumps(g,separators=(',',':')).encode();head+=b' '*((-len(head))%4);raw=struct.pack('<III',0x46546c67,2,28+len(head)+len(binary))+struct.pack('<II',len(head),0x4e4f534a)+head+struct.pack('<II',len(binary),0x004e4942)+binary;(OUT/'wagon-w01.glb').write_bytes(raw);(OUT/'ATTRIBUTION.txt').write_text(m.ATTRIBUTION+'\n')
  receipt.update(status='ACTUAL_ATLAS_STRUCTURE_AND_NATIVE_SAMPLE_PASS_UNRENDERED',candidate_sha256=m.sha(raw),candidate_bytes=len(raw),parent_sha256=m.PARENT_SHA,v1_sha256=V1_SHA,triangles=12104,meshes=23,primitives=23,material_definitions=6,referenced_materials=5,images=len(g['images']),all_original_material_assignments_and_color_factors=True,positions_normals_oriented_triangles_pivots_skins_animations_exact=True,paint_iron_original_images_and_materials_unchanged=True,all_other_variants_untouched=True,original_binary_prefix_exact=True,texture_maps=map_reports,native_sample_proofs=proofs,source_native_detail_pixels=[145,40],normal_sampling_scope='Actual serialized Float32 UV,4barycentric points/wood triangle,linear-repeat samples and corresponding worldTBN normal. Base level only; no claim all coarse mips or visual match.',normal_map_scale=.35,RGBA8_plus_mips_4over3_estimate=((SIZE[0]*SIZE[1]+1024*64+256*256)*3*4*4//3),minimum_texture_size_capability_required_pixels=max(SIZE),no_budget_thresholds_changed=True,elapsed_seconds=time.monotonic()-start)
 except Exception as exc:receipt.update(status='ACTUAL_EXCEPTION',error=repr(exc),elapsed_seconds=time.monotonic()-start)
 finally:(OUT/'ACTUAL-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items()if k not in ['texture_maps','native_sample_proofs']},indent=2));return 0 if receipt['status']=='ACTUAL_ATLAS_STRUCTURE_AND_NATIVE_SAMPLE_PASS_UNRENDERED'else 2
if __name__=='__main__':raise SystemExit(main())
