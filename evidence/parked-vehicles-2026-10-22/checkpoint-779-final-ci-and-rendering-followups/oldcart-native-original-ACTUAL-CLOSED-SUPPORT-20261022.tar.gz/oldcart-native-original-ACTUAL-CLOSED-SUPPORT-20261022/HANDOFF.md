# Old Cart — actual original native inspection CLOSED

One explicitly released run: EXIT0, 7.96 seconds, unchanged owned-descendant supervisor; supervisor/caller departed and no owned active descendants. No retries. Three actual 1280×800 images: front, three-quarter and side. All 51,595 indexed POSITION samples per view passed fixed camera framing; native bounds agree with independent accessor readback. No page/HTTP errors.

Actual image review: weathered planks, joints, metal wheel rims/hubs and steered front axle are visible and materially more detailed than a schematic procedural wagon. Thin shafts and narrow wooden freight bed remain the actual donor form. This is a promising generic farm-wagon development base; not an authenticated Dearborn, 1835 Chicago wagon or named maker/date specimen.

The 9,809,548-byte SHA13600b73… GLB was served unchanged. Original source hierarchy, matrices, meshes and materials retained; scene outer root identity all views. No rescale, reorientation, neutralization, export, texture conversion or app intake. Fixed neutral lights, display floor and shadow-render flags are presentation only. Source +Y is up, -X front; units uncalibrated. Source credits: “Old Cart” by Lyskilde / longtail, CC BY4.0, via individual Objaverse file; exact original credits included.

17 renderer draws/35,014 triangles include inspection shadows/floor and are not application budget evidence. Terrain fit, calibrated scale, narrow model integration, compressed derivative loading, memory/driver costs and honest period disclosure remain pending. No app/Git/ticket/publish mutation occurred.

See CLOSED-RECEIPT.json for original and PNG hashes, actual closure, archive reacquisition and portability limitations. Original GLB is already durable in the two-public-GLB audit archive, so this support does not duplicate it. Browser lane was released to root immediately at actual closure.
