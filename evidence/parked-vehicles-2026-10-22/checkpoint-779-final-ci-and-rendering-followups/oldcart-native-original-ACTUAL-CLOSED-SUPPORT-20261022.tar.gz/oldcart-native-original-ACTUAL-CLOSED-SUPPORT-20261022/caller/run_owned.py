"""Prepared only. Never launch without root's separate browser-lane release."""
import json,pathlib,sys
from ownership_supervisor import run_owned
def main():
 here=pathlib.Path(__file__).resolve().parent
 if sys.argv[1:]!=['--lane-released']:raise SystemExit('Require root lane release')
 output='/workspace/shared/oldcart-native-original-first-views-20261022'
 if pathlib.Path(output).exists():raise SystemExit('Refuse existing capture output')
 r=run_owned(['node',str(here/'capture_native.mjs'),'--lane-released','--output-dir',output],here/'actual-first-run',whole_timeout=180,execution_timeout=170)
 print(json.dumps(r,indent=2));print('STDERR:',(here/'actual-first-run/capture.stderr').read_text());raise SystemExit(r['exit_code'])
if __name__=='__main__':main()
