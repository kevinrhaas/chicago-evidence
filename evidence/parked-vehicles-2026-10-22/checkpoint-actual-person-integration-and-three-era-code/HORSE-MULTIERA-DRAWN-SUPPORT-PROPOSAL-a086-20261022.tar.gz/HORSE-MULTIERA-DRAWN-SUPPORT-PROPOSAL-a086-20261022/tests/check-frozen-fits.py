"""Independent arithmetic readback of frozen constructor triangles and actual horse samples."""
import hashlib, json, math, struct
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
APP=Path('/workspace/chicago-waistcoat/chicago/4d')
spec=json.loads((APP/'data/transport/parked/horse-sevket-sidecar.json').read_text())
def rotate(v,q):
    x,y,z,w=q;vx,vy,vz=v
    tx,ty,tz=2*(y*vz-z*vy),2*(z*vx-x*vz),2*(x*vy-y*vx)
    return [vx+w*tx+y*tz-z*ty,vy+w*ty+z*tx-x*tz,vz+w*tz+x*ty-y*tx]
def height(values,e,n):
    found=[];z=-n
    for i in range(0,len(values),9):
        x0,y0,z0,x1,y1,z1,x2,y2,z2=values[i:i+9]
        d=(x1-x0)*(z2-z0)-(x2-x0)*(z1-z0)
        if abs(d)<1e-12:continue
        u=((e-x0)*(z2-z0)-(z-z0)*(x2-x0))/d
        v=((x1-x0)*(z-z0)-(z1-z0)*(e-x0))/d
        if u>=-1e-9 and v>=-1e-9 and u+v<=1+1e-9:found.append(y0+u*(y1-y0)+v*(y2-y0))
    assert found,'Missing exact triangle coverage'
    return max(found)
def evaluate(fit,values,q=None,lift=0):
    q=q or fit['support_quaternion_xyzw'];yaw=math.pi-math.radians(fit['bearing_deg']);co,si=math.cos(yaw),math.sin(yaw)
    def patch(samples):
        result=[]
        for p in samples:
            x,y,z=rotate(p,q);g=height(values,fit['at_local_enu_m'][0]+co*x+si*z,fit['at_local_enu_m'][1]+si*x-co*z);result.append((y,g))
        return result
    originals={name:patch(p['samples_m']) for name,p in spec['contacts'].items()}
    base=max(g-y for p in originals.values() for y,g in p)+lift
    hoof={name:min(base+y-g for y,g in ps) for name,ps in originals.items()}
    slab={name:min(base+y-g for y,g in patch(p['equal_10mm_slab_samples_m'])) for name,p in spec['contacts'].items()}
    minimum=min(base+y-g for p in originals.values() for y,g in p)
    tilt=math.degrees(math.acos(max(-1,min(1,rotate([0,1,0],q)[1]))))
    passed=abs(sum(x*x for x in q)-1)<1e-7 and tilt<=2 and max(hoof.values())<=.001 and min(minimum,*slab.values())>=-.00001
    return {'pass':passed,'base':base,'hoof':hoof,'slab':slab,'minimum':minimum,'tilt':tilt}
results={}
for year in ('1812','1904'):
    folder=ROOT/f'actual-{year}-canvas-v2';fit=json.loads((folder/'FIT.json').read_text());drawn=json.loads((folder/'DRAWN-TRIANGLES.json').read_text());values=drawn['triangles_world_xyz']
    assert hashlib.sha256(struct.pack('<'+'d'*len(values),*values)).hexdigest()==fit['provider_triangle_sha256']==drawn['snapshot']['sha256']
    actual=evaluate(fit,values);assert actual['pass']
    assert abs(actual['base']-fit['measurements']['root_y_m'])<1e-11
    assert all(abs(actual['hoof'][k]-v)<1e-11 for k,v in fit['measurements']['minimum_gap_by_hoof_m'].items())
    assert not evaluate(fit,values,q=[0,0,0,1])['pass'],'Upright source must preserve its real unequal-feet failure'
    assert not evaluate(fit,values,lift=.0011)['pass'],'Whole-root lift cannot pass the unchanged minimum-gap rule'
    assert not evaluate(fit,values,lift=-.00002)['pass'],'20um penetration must fail the unchanged -10um rule'
    angle=math.radians(2.1);assert not evaluate(fit,values,q=[math.sin(angle/2),0,0,math.cos(angle/2)])['pass']
    results[year]={'independent_actual_fit_pass':True,'maximum_per_hoof_minimum_gap_m':max(actual['hoof'].values()),'minimum_source_sample_gap_m':actual['minimum'],'upright_negative':True,'whole_root_lift_negative':True,'penetration_negative':True,'over_tilt_negative':True,'Float64LE_triangle_hash':True}
receipt={'status':'PASS independent frozen-source arithmetic only','results':results,'world_qualified':False,'scope':'Actual four-triangle snapshots +488 original/474 clipped-slab sample points; not continuous sole contact, full pose collision, browser or world acceptance.'}
(ROOT/'FROZEN-FIT-CONTROLS.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
