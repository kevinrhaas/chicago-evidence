import {APP,PROPOSED,reads} from './setup.mjs';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
const T=await import('three');
const head='a086cd7dab31935f52adcb1ca8494a12726f9f27';
assert.equal(execFileSync('git',['-C',APP,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),head);
const year=process.argv[2];assert(['1812','1904'].includes(year));
const out=path.resolve(fileURLToPath(new URL('../actual-'+year+'/',import.meta.url)));fs.mkdirSync(out,{recursive:false});
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const get=relative=>JSON.parse(fs.readFileSync(path.join(APP,'data',relative)));
const spec=get('transport/parked/horse-sevket-sidecar.json'),scene=get('scenes/'+year+'.json');
const row=year==='1812'?{id:'first_fort_stable_north_standing_horse_01',at_local_enu_m:[1067.5,144],bearing_deg:0,ground_record_id:'terrain_e1830_natural',ground_support_region_id:'first_fort_stable_north_horse_support_01',surface_kind:'terrain_triangle'}:{id:'prairie_eighteenth_standing_horse_01',at_local_enu_m:[1397.5,-3221.2],bearing_deg:178.99,ground_record_id:'prairie_18_20',ground_support_region_id:'prairie_eighteenth_horse_support_01',surface_kind:'carriageway_triangle'};
const yaw=Math.PI-row.bearing_deg*Math.PI/180,co=Math.cos(yaw),si=Math.sin(yaw);
const all=Object.values(spec.contacts).flatMap(p=>[...p.samples_m,...p.equal_10mm_slab_samples_m]);
const xy=all.map(p=>[row.at_local_enu_m[0]+co*p[0]+si*p[2],row.at_local_enu_m[1]+si*p[0]-co*p[2]]);
const bounds=[[Math.min(...xy.map(p=>p[0]))-.05,Math.min(...xy.map(p=>p[1]))-.05],[Math.max(...xy.map(p=>p[0]))+.05,Math.max(...xy.map(p=>p[1]))+.05]];
const region={id:row.ground_support_region_id,record_id:row.ground_record_id,bounds_enu_m:bounds,scene_id:year,target_date:scene.target_date,surface_kind:row.surface_kind};
const problems=[],started=performance.now();let layer=null,terrain=null;
const report={source_head:head,scene_id:year,target_date:scene.target_date,row_id:row.id,enabled:false,world_qualified:false,region,problems};
try{
 const dataBase=pathToFileURL(path.resolve(APP,'../../site/4d/data')+'/');
 if(year==='1812'){
  const {createTerrain}=await import(pathToFileURL(PROPOSED+'/renderers/web/js/terrain.js'));
  layer=await createTerrain({dataBase,assetBase:dataBase,epochId:scene.terrain_epoch,substrateBase:null,sceneId:year,targetDate:scene.target_date,apronPath:scene.terrain_apron,supportRegions:[region],problems});
 }else{
  const {Heightfield}=await import(pathToFileURL(APP+'/renderers/web/js/terrain.js'));
  const meta=get('terrain/epochs/'+scene.terrain_epoch+'/heightfield.json');
  const raw=fs.readFileSync(path.join(APP,'data/terrain/epochs',scene.terrain_epoch,meta.bin));
  const hf=new Heightfield().adopt(meta,raw.buffer.slice(raw.byteOffset,raw.byteOffset+raw.byteLength));
  // Exact constructor vertex sampler inside the measured field. The distant
  // coast is not queried by this source candidate; no contact uses bilinear.
  terrain={surfaceHeight:(e,n)=>hf.sample(e,n),setGroundCut:()=>{},protectGroundUnder:()=>{},grid:{cellM:hf.cellM},inBounds:(e,n)=>hf.contains(e,n)};
  const {createStreetGrid}=await import(pathToFileURL(PROPOSED+'/renderers/web/js/street-grid.js'));
  layer=await createStreetGrid({dataBase,assetBase:null,sceneId:year,targetDate:scene.target_date,terrain,supportRegions:[region],problems});
 }
 const provider=layer.drawnStaticSupport;
 report.snapshot=provider?.snapshot(row.ground_record_id,region.id)??null;
 if(!report.snapshot)throw Error('Exact constructor support snapshot unavailable: '+problems.join('; '));
 fs.writeFileSync(path.join(out,'DRAWN-TRIANGLES.json'),JSON.stringify({snapshot:report.snapshot,triangles_world_xyz:Array.from(provider.copyTriangles(row.ground_record_id,region.id))},null,2)+'\n');
 let evaluations=0;
 const evaluate=(rx,rz)=>{
  evaluations++;const q=new T.Quaternion().setFromEuler(new T.Euler(rx,0,rz,'XYZ'));
  const tilt=new T.Vector3(0,1,0).applyQuaternion(q).angleTo(new T.Vector3(0,1,0))*180/Math.PI;
  if(tilt>2)return{score:Infinity};
  const transform=values=>values.map(v=>{const p=new T.Vector3().fromArray(v).applyQuaternion(q);const ground=provider.heightAt(row.at_local_enu_m[0]+co*p.x+si*p.z,row.at_local_enu_m[1]+si*p.x-co*p.z,row.ground_record_id,region.id);if(!Number.isFinite(ground))throw Error('Actual triangle coverage missing at contact');return{y:p.y,ground};});
  const patches=Object.fromEntries(Object.entries(spec.contacts).map(([k,p])=>[k,transform(p.samples_m)]));
  const flat=Object.values(patches).flat(),base=Math.max(...flat.map(p=>p.ground-p.y));
  const hoof=Object.fromEntries(Object.entries(patches).map(([k,ps])=>[k,Math.min(...ps.map(p=>base+p.y-p.ground))]));
  const slab=Object.fromEntries(Object.entries(spec.contacts).map(([k,p])=>[k,Math.min(...transform(p.equal_10mm_slab_samples_m).map(p=>base+p.y-p.ground))]));
  const minSamples=Math.min(...flat.map(p=>base+p.y-p.ground)),minSlab=Math.min(...Object.values(slab));
  return{rx,rz,q:q.toArray(),tilt,base,hoof,slab,minSamples,score:Math.max(...Object.values(hoof),.001-.00001-minSlab)};
 };
 const old=new T.Euler().setFromQuaternion(new T.Quaternion().fromArray(spec.proposed_static_support_pose.local_quaternion_xyzw));
 let best=[evaluate(0,0),evaluate(old.x,old.z)].sort((a,b)=>a.score-b.score)[0];
 const original=JSON.parse(JSON.stringify(best));
 for(let step=.5*Math.PI/180;step>1e-8;step/=2){
  for(let repeat=0;repeat<4;repeat++){
   let next=best;for(const dx of [-1,0,1])for(const dz of [-1,0,1]){const value=evaluate(best.rx+dx*step,best.rz+dz*step);if(value.score<next.score)next=value;}
   if(next===best)break;best=next;
  }
 }
 const pass=Math.max(...Object.values(best.hoof))<=.001&&best.minSamples>=-.00001&&Math.min(...Object.values(best.slab))>=-.00001;
 const fit={schema:'standing_horse_drawn_support_fit_v1',status:pass?'source_cpu_fit_pass':'source_cpu_fit_failed',scene_id:year,target_date:scene.target_date,row_id:row.id,at_local_enu_m:row.at_local_enu_m,bearing_deg:row.bearing_deg,surface_kind:row.surface_kind,record_id:row.ground_record_id,region_id:region.id,bounds_enu_m:bounds,runtime_asset_sha256:spec.runtime_asset.sha256,provider_triangle_sha256:report.snapshot.sha256,support_quaternion_xyzw:pass?best.q:null,limits:{max_tilt_deg:2,maximum_per_hoof_minimum_gap_m:.001,minimum_sample_clearance_m:-.00001},measurements:{tilt_deg:best.tilt,root_y_m:best.base,minimum_gap_by_hoof_m:best.hoof,equal_10mm_slab_minimum_gaps_m:best.slab,minimum_all_samples_gap_m:best.minSamples},world_qualified:false};
 fs.writeFileSync(path.join(out,'FIT.json'),JSON.stringify(fit,null,2)+'\n');
 Object.assign(report,{status:fit.status,fit,solver_evaluations:evaluations,original_seed:original,elapsed_ms:performance.now()-started});
}catch(error){Object.assign(report,{status:'source_cpu_fit_unavailable',support_quaternion_xyzw:null,cause:String(error.stack??error),elapsed_ms:performance.now()-started});}
finally{
 try{layer?.dispose();}catch(error){report.disposal_error=String(error);}
 report.read_inputs=Object.fromEntries([...reads].map(([p,bytes])=>[p,sha(bytes)]));
 report.source_inputs_unchanged=[...reads].every(([p,bytes])=>sha(fs.readFileSync(p))===sha(bytes));
 report.final_head=execFileSync('git',['-C',APP,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
 fs.writeFileSync(path.join(out,'READBACK.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report,null,2));
}
