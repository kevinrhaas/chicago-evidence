import {register} from 'node:module';
import fs from 'node:fs';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
export const APP='/workspace/chicago-waistcoat/chicago/4d';
export const PROPOSED=path.resolve(fileURLToPath(new URL('../proposed',import.meta.url)));
const vendor=pathToFileURL(APP+'/renderers/web/vendor/three-0.185.1/').href;
register(`data:text/javascript,${encodeURIComponent(`
import fs from 'node:fs';import{fileURLToPath,pathToFileURL}from'node:url';
export function resolve(s,c,next){
 if(s==='three')return{url:${JSON.stringify(vendor+'three.module.js')},shortCircuit:true};
 if(s.startsWith('three/addons/'))return{url:${JSON.stringify(vendor+'addons/')}+s.slice(13),shortCircuit:true};
 if(s.startsWith('./')&&c.parentURL?.startsWith(${JSON.stringify(pathToFileURL(PROPOSED+'/renderers/web/js/').href)})){
  const u=new URL(s,c.parentURL);if(!fs.existsSync(fileURLToPath(u)))return{url:new URL(s,${JSON.stringify(pathToFileURL(APP+'/renderers/web/js/').href)}).href,shortCircuit:true};
 }return next(s,c);
}`)}`,import.meta.url);
export const reads=new Map();
globalThis.window={location:pathToFileURL(APP+'/renderers/web/index.html')};
globalThis.document={createElement:()=>({getContext:()=>null})};
const originalFetch=globalThis.fetch;
globalThis.fetch=async(input,init)=>{
 const u=new URL(String(input));
 if(u.protocol!=='file:')throw Error('Source readback forbids network fetch: '+u);
 const p=fileURLToPath(u);if(!fs.existsSync(p))return new Response(null,{status:404});
 const bytes=fs.readFileSync(p);reads.set(p,bytes);return new Response(bytes,{status:200});
};
