from pathlib import Path
import json,hashlib,difflib,shutil
p=Path(__file__).resolve().parent;old=Path('/workspace/shared/HORSE-IDLE-YARD-DIAGNOSTIC-V2-HELD-20261022');s=(old/'capture_smoke.mjs').read_text();baseline=s
s=s.replace("started:new Date().toISOString()", "started:new Date().toISOString(),product_checks:{}")
s=s.replace("let server,browser,page;", "let server,browser,page,timingFailure=null,productFailure=false;")
s=s.replace("const start=performance.now(),initial=i.idle.status,rows=[]", "const start=performance.now(),initial=i.idle.status,initialReduced=matchMedia('(prefers-reduced-motion: reduce)').matches,rows=[]")
s=s.replace("reduced=opts.reducedMotion??st.media_reduce,paused=opts.paused??false", "reduced=opts.reducedMotion===undefined?st.media_reduce:opts.reducedMotion,paused=opts.paused===undefined?false:opts.paused")
s=s.replace("rows.push({at_ms:", "rows.push({phase:window.__horseIdleYardDiagnostic?.phase??'install',eligible:!paused&&!reduced&&visible,at_ms:")
s=s.replace("forwarded_host_dt_s:dt", "forwarded_dt_s:dt")
s=s.replace("});if(rows.length>32)rows.shift();return result;", "});return result;")
s=s.replace("initial_status:initial,current:state()", "initial_status:initial,initial_media_reduce:initialReduced,current:state()")
s=s.replace("last32_updates:rows.slice()", "all_forwarded_updates:rows.slice()")
s=s.replace("scope:'Observed production-layer forwarded dt; not raw private THREE.Clock delta. No arguments/poses/source mutated.'", "scope:'All actual forwarded layer dt, including unchanged explicit hidden/restoration probes labeled by phase; not raw private Clock delta. Original arguments/poses/source unchanged.'")
s=s.replace("window.__horseIdleYardDiagnostic={snapshot,restore()", "window.__horseIdleYardDiagnostic={phase:'original_timing_observation',snapshot,restore()")
oldcatch="  }catch(error){report.idle_timeout_diagnostic=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());throw error;}\n  report.idle_diagnostic_after_wait=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());"
assert oldcatch in s
newcatch=r'''   report.original_timing_check={status:'PASS',owned_progress_target_s:1.5,wall_timeout_ms:15000};
  }catch(error){timingFailure=String(error.stack??error);report.original_timing_check={status:'FAIL',owned_progress_target_s:1.5,wall_timeout_ms:15000,error:timingFailure};report.idle_timeout_diagnostic=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());process.exitCode=1;}
  report.idle_diagnostic_after_wait=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());
  // Continue collecting independent product evidence; never erase the original timing FAIL.
  const productStep=async(name,run)=>{try{await page.evaluate(n=>{window.__horseIdleYardDiagnostic.phase=n;},name);const value=await run();report.product_checks[name]={status:'PASS',result:value};return value;}catch(error){productFailure=true;process.exitCode=1;report.product_checks[name]={status:'FAIL',error:String(error.stack??error)};return null;}finally{try{report.all_forwarded_clock_updates=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());}catch(error){productFailure=true;process.exitCode=1;report.clock_trace_error=String(error);report.product_checks[name].trace_status='FAIL';}await fs.writeFile(path.join(out,'progress.json'),JSON.stringify(report,null,2)+'\n');}};
  const clockAccounting=()=>page.evaluate(()=>{const d=window.__horseIdleYardDiagnostic.snapshot(),initial=d.initial_status;
   if(initial.elapsed_s!==0||d.initial_media_reduce!==true)throw Error('Accounting requires fresh zero-age clone under original initial reduce preference');
   let age=0,elapsed=0,maximumError=0;for(const row of d.all_forwarded_updates){if(!Number.isFinite(row.forwarded_dt_s)||row.forwarded_dt_s<0)throw Error('Nonfinite/negative actual forwarded dt');if(row.elapsed_before_s!==elapsed)throw Error('Unexpected owned-clock advance outside observed updates');const before=age;if(row.eligible)age+=row.forwarded_dt_s;elapsed+=(Math.max(0,age-initial.initial_rest_delay_s)-Math.max(0,before-initial.initial_rest_delay_s))*initial.deterministic_playback_rate;maximumError=Math.max(maximumError,Math.abs(row.elapsed_after_s-elapsed));if(maximumError!==0)throw Error('Actual forwarded-dt accounting differs from source-owned elapsed');}
   if(d.current.elapsed_s!==elapsed)throw Error('Current elapsed differs from complete forwarded-dt accounting');
   return{status:'SOURCE_CLOCK_ACCOUNTING_PASS',fresh_zero_age_basis:'Original new clone loaded under initial reduced motion, no prior eligible phase',observed_updates:d.all_forwarded_updates.length,eligible_age_s:age,source_delay_s:initial.initial_rest_delay_s,source_rate:initial.deterministic_playback_rate,expected_elapsed_s:elapsed,actual_elapsed_s:d.current.elapsed_s,maximum_absolute_error_s:maximumError,arithmetic_tolerance_s:0,scope:'Owned host-delta accounting only; original wall-clock timing result remains independent'};});
  await productStep('source_clock_accounting_after_original_wait',clockAccounting);'''
s=s.replace(oldcatch,newcatch)
# Wrap existing entire check expressions without changing their callbacks/assertions.
for name in ['idle_motion','idle_hidden','selection','teardown']:
 start=s.index('  report.'+name+'=await page.evaluate(');end=s.index('\n',start)
 line=s[start:end]
 # selection is multiline; locate its exact terminator instead.
 if name=='selection':end=s.index('\n  });',start)+len('\n  });');line=s[start:end]
 assert line.endswith('});')
 expression=line[len('  report.'+name+'=await '):-1]
 s=s[:start]+'  report.'+name+"=await productStep('"+name+"',()=>"+expression+');'+s[end:]
# Active snapshot/framing/budget/capture remains the same code inside its own result scope.
line="  const activeState=await snapshot('yard');if(!activeState.stats.withinBudget)throw Error('Existing public render budget exceeded during idle');await shot('quarter-idle-active',activeState);"
assert line in s;s=s.replace(line,"  await productStep('active_view_framing_budget_capture',async()=>{"+line.strip()+"return{captured:'quarter-idle-active.png'};});")
# Keep the complete original actual-media pause procedure, including both rAF waits and thresholds.
start=s.index("  await page.emulateMedia({reducedMotion:'reduce'});",s.index('clockAccounting='));end=s.index('  report.idle_hidden=',start);block=s[start:end]
block=block.replace('  report.idle_reduced_motion=await page.evaluate(', '  const result=await page.evaluate(')
s=s[:start]+"  report.idle_reduced_motion=await productStep('idle_reduced_motion',async()=>{\n"+block+"  return result;\n  });\n"+s[end:]
# Account all reduced/hidden/selection deltas before restoring instrumentation for retirement.
restore="  await page.evaluate(()=>window.__horseIdleYardDiagnostic?.restore());"
assert s.count(restore)==1;s=s.replace(restore,"  await productStep('source_clock_accounting_after_pause_and_visibility',clockAccounting);\n"+restore)
# teardown productStep runs after restore; all prior updates are still accessible and original function restored.
s=s.replace("if(report.errors.length)throw Error('Browser errors recorded');report.pass=true;", "if(report.errors.length)throw Error('Browser errors recorded');report.product_checks_status=productFailure?'FAIL':'PASS';report.pass=!timingFailure&&!productFailure;if(timingFailure){report.error=timingFailure;process.exitCode=1;}if(productFailure)process.exitCode=1;")
(p/'capture_smoke.mjs').write_text(s);shutil.copy2(old/'run_owned.py',p/'run_owned.py');(p/'CONTINUE-DIAGNOSTIC.patch').write_text(''.join(difflib.unified_diff(baseline.splitlines(True),s.splitlines(True),fromfile='immutableV2/capture_smoke.mjs',tofile='continueAfterTimingFail/capture_smoke.mjs')))
for phase in ['yard-desktop','yard-mobile']:
 j=json.loads((old/(phase+'-RELEASE-HELD.json')).read_text())
 for name in ['capture_smoke.mjs','run_owned.py']:j['expected_files'].pop(str(old/name));j['expected_files'][str(p/name)]=hashlib.sha256((p/name).read_bytes()).hexdigest()
 j['note']='HELD root-reviewed separate continuation needed. Preserve original15s/1.5owned timing assertion and FAIL/exit1; only collect independent productcheck results after itsfailure. No source/camera/timeout/threshold change, no retry/nextphase automatic.'
 (p/(phase+'-RELEASE-HELD.json')).write_text(json.dumps(j,indent=2)+'\n')
