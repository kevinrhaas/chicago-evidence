// HELD: one finite phase; existing owned-process supervisor handles deadlines/cleanup.
import fs from 'node:fs/promises';import path from 'node:path';import crypto from 'node:crypto';
import {createServer} from 'node:http';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),args=process.argv.slice(2);
if(args.length!==4||args[0]!=='--lane-released'||!['yard-desktop','yard-mobile'].includes(args[1]))throw Error('Require one explicit released phase');
const phase=args[1],cfg=JSON.parse(await fs.readFile(args[2],'utf8')),out=path.resolve(args[3]);
if(cfg.released!==true||cfg.browser_lane_free!==true||cfg.phase!==phase||!Object.keys(cfg.expected_files??{}).length)throw Error('HELD: root release and exact phase/input pins required');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const [file,hash]of Object.entries(cfg.expected_files))if(sha(await fs.readFile(file))!==hash)throw Error('Input changed: '+file);
const model=await fs.readFile(cfg.source_model);if(model.length!==3377384||sha(model)!=='c2559073966cfb5b2c9d2c536ca03fbf03b71734f9a11ffcff48d4ec86e4d25c')throw Error('Normalized source-bound idle derivative pin mismatch');
await fs.mkdir(out,{recursive:false});
const report={phase,scope:'Development-base standing head/tail idle smoke only, no photographic/anatomical/continuous-contact/ride/hitch/phone-hardware acceptance',pass:false,errors:[],requests:[],captures:[],inputPins:cfg.expected_files,started:new Date().toISOString(),product_checks:{}};
let server,browser,page,timingFailure=null,productFailure=false;
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.bin':'application/octet-stream','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.css':'text/css','.wasm':'application/wasm','.svg':'image/svg+xml','.md':'text/markdown'};
try{
 const app=cfg.app_root,vendor=path.join(app,'renderers/web/vendor');
 server=createServer(async(req,res)=>{try{
  const u=new URL(req.url,'http://localhost');if(u.pathname==='/favicon.ico'){res.writeHead(204);return res.end();}
  let file,bytes;
  if(phase==='materials'){
   if(u.pathname==='/fixture/')file=path.join(here,'materials.html');
   else if(u.pathname==='/fixture/materials.js')file=path.join(here,'materials.js');
   else if(u.pathname==='/transport/standing-horse/horse-sevket-native.glb')file=cfg.source_model;
   else if(u.pathname.startsWith('/vendor/')){file=path.resolve(vendor,u.pathname.slice(8));if(!file.startsWith(vendor+'/'))throw Error('Path');}
   else if(u.pathname.startsWith('/runtime/')){const name=u.pathname.slice(9);if(name.includes('/')||name.includes('..'))throw Error('Path');file=name==='standing-horses.js'?path.join(cfg.proposal_root,'renderers/web/js',name):path.join(app,'renderers/web/js',name);}
   else{const m=u.pathname.match(/^\/case\/(source_native|organic_dielectric_v1)\/data\/transport\/parked\/(standing-horses|horse-sevket-sidecar)\.json$/);if(!m)throw Error('Route');file=path.join(cfg.proposal_root,'data/transport/parked',m[2]+'.json');if(m[2]==='standing-horses'){const j=JSON.parse(await fs.readFile(file,'utf8'));j.scenes['1835'][0].material_variant=m[1];bytes=Buffer.from(JSON.stringify(j));}}
  }else{
   file=path.resolve(cfg.site_root,'.'+decodeURIComponent(u.pathname));if(!file.startsWith(cfg.site_root+'/'))throw Error('Path');if((await fs.stat(file)).isDirectory())file=path.join(file,'index.html');
  }
  bytes??=await fs.readFile(file);res.writeHead(200,{'Content-Type':mime[path.extname(file)]??'application/octet-stream','Cache-Control':'no-store'});res.end(bytes);
 }catch{res.writeHead(404);res.end('Unavailable');}});
 await new Promise((r,j)=>{server.once('error',j);server.listen(0,'127.0.0.1',r);});const origin='http://127.0.0.1:'+server.address().port;
 const {chromium}=await import('/workspace/shared/chicago-browser/node_modules/playwright/index.mjs');
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const mobile=phase==='yard-mobile';page=await browser.newPage({viewport:mobile?{width:390,height:780}:{width:1280,height:800},deviceScaleFactor:mobile?2:1,hasTouch:mobile,isMobile:mobile,reducedMotion:'reduce'});
 page.setDefaultTimeout(45000);page.on('pageerror',e=>report.errors.push(String(e)));page.on('response',r=>{if(r.status()>=400)report.errors.push(`HTTP${r.status()} ${r.url()}`);});page.on('request',r=>{if((/horse-sevket.*\.glb/.test(r.url())||r.url().includes('/standing-horse-idle/')))report.requests.push(r.url());});
 const shot=async(name,state)=>{const file=name+'.png',bytes=await page.screenshot({path:path.join(out,file)});report.captures.push({file,sha256:sha(bytes),state});await fs.writeFile(path.join(out,'progress.json'),JSON.stringify(report,null,2)+'\n');};
 // Same actual indexed-vertex readback for fixture and town; no fitting/reposing.
 const snapshot=async(kind)=>page.evaluate(async kind=>{
  const a=window.__chicago4d,f=window.fixture,layer=kind==='materials'?f.layer:a.standingHorses,camera=kind==='materials'?f.camera:a.camera;
  const i=layer.instances[0];if(!i)throw Error('Missing standing horse');const T=await import('three'),p=new T.Vector3(),b=new T.Box3();
  let count=0,clipped=0;const ndc={min:[Infinity,Infinity,Infinity],max:[-Infinity,-Infinity,-Infinity]},meshes=[];
  i.root.updateMatrixWorld(true);camera.updateMatrixWorld(true);
  i.root.traverse(m=>{if(!m.isMesh)return;if(!m.isSkinnedMesh||!m.visible||m.skeleton.bones.length!==15)throw Error('Lost actual source mesh/skin');m.skeleton.update();const ids=new Set(m.geometry.index.array);for(const id of ids){m.getVertexPosition(id,p).applyMatrix4(m.matrixWorld);b.expandByPoint(p);p.project(camera);count++;if(!p.toArray().every(Number.isFinite)||Math.abs(p.x)>.97||Math.abs(p.y)>.97||p.z< -1||p.z>1)clipped++;for(let k=0;k<3;k++){ndc.min[k]=Math.min(ndc.min[k],p.getComponent(k));ndc.max[k]=Math.max(ndc.max[k],p.getComponent(k));}}meshes.push({name:m.name,bones:m.skeleton.bones.length,vertices:m.geometry.attributes.position.count,metalness:m.material.metalness,confidence_values:Array.from(new Set(m.geometry.attributes._confidence.array)),scale:m.scale.toArray()});});
  if(meshes.length!==3||clipped)throw Error('Actual source groups missing/clipped in fixed view; no camera adaptation: '+JSON.stringify({clipped,ndc}));
  const renderer=kind==='materials'?f.renderer:a.renderer;if(renderer.getContext().getError()!==0)throw Error('WebGL error');
  if(kind==='yard'&&(i.asset.animations.length!==7||i.receipt.mixer_count!==1||!i.receipt.autoplay||i.receipt.original_six_autoplay!==false||i.idle?.status.clip!=='sevket_reconstructed_head_tail_idle_v1'))throw Error('Enabled source-bound idle identity mismatch');
  return{idle_status:i.idle?.status,indexed_vertices:count,projected_bounds:ndc,world_bounds:[b.min.toArray(),b.max.toArray()],meshes,clips:i.asset.animations.map(c=>c.name),receipt:i.receipt,camera:{position:camera.position.toArray(),quaternion:camera.quaternion.toArray(),fov:camera.fov},stats:kind==='materials'?{draws:renderer.info.render.calls,triangles:renderer.info.render.triangles}:a.stats()};
 },kind);
 if(phase==='materials'){
  for(const variant of ['source_native','organic_dielectric_v1']){
   await page.goto(origin+'/fixture/?variant='+variant,{waitUntil:'networkidle',timeout:45000});await page.waitForFunction(()=>window.fixture?.ready);
   for(const view of ['side','three-quarter']){await page.evaluate(view=>window.fixture.setView(view),view);await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));const state=await snapshot('materials');if(state.meshes.some(m=>m.metalness!==(variant==='source_native'?1:0)))throw Error('Undeclared material response');await shot(variant+'-'+view,state);}
   await page.evaluate(()=>window.fixture.layer.dispose());
  }
 }else{
  const initial=mobile?'light':'full';await page.addInitScript(detail=>localStorage.setItem('chicago4d.settings',JSON.stringify({detail})),initial);
  await page.goto(origin+'/walk/?year=1835',{waitUntil:'domcontentloaded',timeout:45000});await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:240000,polling:1000});
  await page.evaluate(()=>{const a=window.__chicago4d;if(!a.ready||a.error||!a.standingHorses)throw Error('Actual new layer not ready');if(a.welcome.state==='welcome')a.welcome.enter('spawn');});
  await page.waitForFunction(()=>{const w=window.__chicago4d?.welcome;if(w?.state==='welcome')w.enter('spawn');return w?.state==='world';},null,{timeout:30000,polling:100});if(report.requests.length)throw Error('Far spawn fetched horse GLB');
  report.initial=await page.evaluate(()=>({detail:window.__chicago4d.detail,coarse:matchMedia('(pointer:coarse)').matches,instances:window.__chicago4d.standingHorses.instances.length}));
  const views=mobile?{side:{local_e:-127.5,local_n:-289.5,yaw_deg:180,pitch_deg:-7},quarter:{local_e:-123.1,local_n:-291.6,yaw_deg:225,pitch_deg:-7}}:{side:{local_e:-127.5,local_n:-291.4,yaw_deg:180,pitch_deg:-12},quarter:{local_e:-124.9,local_n:-293.4,yaw_deg:225,pitch_deg:-12}};
  if(mobile){await page.evaluate(p=>{const a=window.__chicago4d;a.setFly(false);a.walker.teleport(p);a.step();},views.side);if(report.requests.length)throw Error('Light near stand fetched horse GLB');await page.evaluate(async()=>{const a=window.__chicago4d;await a.setDetail('balanced');a.step();await a.standingHorses.ready;});}
  for(const [name,camera]of Object.entries(views)){
   await page.evaluate(async p=>{const a=window.__chicago4d;a.setFly(false);a.walker.teleport(p);a.step();await a.standingHorses.ready;},camera);
   await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));const state=await snapshot('yard');if(!state.stats.withinBudget)throw Error('Existing public render budget exceeded');await shot(name,state);
  }
  report.ground=await page.evaluate(async()=>{
   const a=window.__chicago4d,T=await import('three'),i=a.standingHorses.instances[0],spec=await fetch(new URL('transport/parked/horse-sevket-sidecar.json',a.dataBase)).then(r=>r.json());
   const body=i.root.getObjectByName(spec.contact_mesh.renderer_name),p=new T.Vector3(),feet={};i.root.updateMatrixWorld(true);body.skeleton.update();
   for(const [name,patch]of Object.entries(spec.contacts)){const values=[];for(const fi of patch.source_triangle_ids){const v=[];for(let j=0;j<3;j++){body.getVertexPosition(body.geometry.index.getX(fi*3+j),p).applyMatrix4(body.matrixWorld);v.push(p.clone());}for(const q of [...v,v[0].clone().add(v[1]).multiplyScalar(.5),v[1].clone().add(v[2]).multiplyScalar(.5),v[2].clone().add(v[0]).multiplyScalar(.5),v[0].clone().add(v[1]).add(v[2]).multiplyScalar(1/3)]){const h=a.yards.drawnBaseHeightAt(q.x,-q.z,i.row.ground_record_id,i.row.ground_support_region_id);if(!Number.isFinite(h))throw Error('Missing actual retained yard triangle');values.push(q.y-h);}}const min=Math.min(...values),max=Math.max(...values);if(min< -1e-5||min>.001)throw Error('Actual source surface contact fails accepted development bound');feet[name]={actual_triangle_vertex_edge_centroid_samples:values.length,minimum_gap_m:min,maximum_gap_m:max};}
   const support={...a.yards.staticSupport};if(support.regions!==1||support.triangles>32||support.bytes>4096)throw Error('Support retention cap failed');
   const released=a.yards.group.children.map(m=>({name:m.name,position_null:m.geometry.attributes.position.array===null,index_empty:!m.geometry.index||m.geometry.index.array.length===0}));
   return{feet,support,yard_source_cpu_arrays:released,coarse:matchMedia('(pointer:coarse)').matches,query:location.search,receipt:i.receipt};
  });
  if(mobile&&(!report.ground.coarse||!report.ground.yard_source_cpu_arrays.every(x=>x.position_null&&x.index_empty)))throw Error('Normal coarse upload-release path not exercised; no keep-geometry workaround');
  // Additive current-target observation. Existing cameras, graphics budgets and contact guards remain unchanged.
  report.idle_setup=await page.evaluate(async()=>{
   const a=window.__chicago4d,T=await import('three'),i=a.standingHorses.instances[0],spec=await fetch(new URL('transport/parked/horse-sevket-sidecar.json',a.dataBase)).then(r=>r.json());
   if(!i.idle||!i.row.animation.enabled||!spec.idle.enabled)throw Error('Qualified idle is not enabled');
   const body=i.root.getObjectByName(spec.contact_mesh.renderer_name),bones=body.skeleton.bones;
   const sourceBones=[];i.asset.scene.traverse(n=>{if(n.isBone)sourceBones.push(n);});
   if(bones.some(b=>sourceBones.includes(b)))throw Error('Clone shares source bones');
   const patches={};for(const [name,patch]of Object.entries(spec.contacts)){patches[name]=[...new Set(patch.source_triangle_ids.flatMap(fi=>[0,1,2].map(k=>body.geometry.index.getX(fi*3+k))))];}
   if(Object.keys(patches).length!==4||Object.values(patches).some(v=>!v.length))throw Error('Missing nonempty hoof patches');
   const roles={head:[],tail:[]},index=body.geometry.index,skin=body.geometry.getAttribute('skinIndex'),weight=body.geometry.getAttribute('skinWeight');
   for(const id of new Set(index.array))for(const [role,joint]of [['head',12],['tail',14]])if(['X','Y','Z','W'].some(k=>skin['get'+k](id)===joint&&weight['get'+k](id)>0))roles[role].push(id);
   if(!roles.head.length||!roles.tail.length)throw Error('No actual head/tail weighted surface');
   const sample=()=>{i.root.updateMatrixWorld(true);body.skeleton.update();const point=id=>body.getVertexPosition(id,new T.Vector3()).applyMatrix4(body.matrixWorld).toArray();return{elapsed:i.idle.status.elapsed_s,patches:Object.fromEntries(Object.entries(patches).map(([k,ids])=>[k,ids.map(point)])),roles:Object.fromEntries(Object.entries(roles).map(([k,ids])=>[k,ids.map(point)])),bones:bones.map(b=>b.quaternion.toArray()),source_bones:sourceBones.map(b=>b.quaternion.toArray())};};
   const compare=(before,after)=>{const distances=(aa,bb)=>Math.max(...aa.map((v,k)=>Math.hypot(...v.map((x,j)=>x-bb[k][j]))));return{hoof_maximum_drift_m:Object.fromEntries(Object.keys(patches).map(k=>[k,distances(before.patches[k],after.patches[k])])),head_maximum_displacement_m:distances(before.roles.head,after.roles.head),tail_maximum_displacement_m:distances(before.roles.tail,after.roles.tail),bone_component_maximum_delta:Math.max(...before.bones.flatMap((q,k)=>q.map((v,j)=>Math.abs(v-after.bones[k][j])))),source_bone_component_maximum_delta:Math.max(...before.source_bones.flatMap((q,k)=>q.map((v,j)=>Math.abs(v-after.source_bones[k][j]))))};};
   window.__horseIdleYardObservation={sample,compare,before:sample()};
   return{status:i.idle.status,hoof_unique_vertices:Object.fromEntries(Object.entries(patches).map(([k,v])=>[k,v.length])),weighted_role_vertices:Object.fromEntries(Object.entries(roles).map(([k,v])=>[k,v.length])),clone_bones_disjoint:true,original_six_autoplay_receipt:i.receipt.original_six_autoplay};
  });
  // DIAGNOSTIC ONLY: transparent forwarding of the existing production layer.update.
  // Never changes dt, options, return value, curves, camera, rendering or test thresholds.
  report.idle_diagnostic_before=await page.evaluate(()=>{
   const a=window.__chicago4d,layer=a.standingHorses,i=layer.instances[0],original=layer.update;
   const start=performance.now(),initial=i.idle.status,initialReduced=matchMedia('(prefers-reduced-motion: reduce)').matches,rows=[],counts={calls:0,positive_dt_calls:0,forwarded_dt_sum_s:0,maximum_forwarded_dt_s:0,eligible_dt_sum_s:0,paused_calls:0,reduced_calls:0,hidden_document_calls:0,invisible_calls:0};
   const ancestry=()=>{const nodes=[];for(let n=layer.group;n;n=n.parent)nodes.push({name:n.name||n.type,visible:n.visible});return nodes;};
   const state=()=>{const chain=ancestry(),media=matchMedia('(prefers-reduced-motion: reduce)').matches,distance=a.camera.getWorldPosition(a.camera.position.clone()).distanceTo(i.group.position),reach={full:70,balanced:40,light:0}[a.detail]??0;return{elapsed_s:i.idle.status.elapsed_s,idle:i.idle.status,document_hidden:document.hidden,visibility_state:document.visibilityState,document_has_focus:document.hasFocus(),media_reduce:media,instance_visible:i.group.visible,ancestor_visibility:chain,confidence_hidden_reconstructed:Boolean(a.confidence.hidden.reconstructed),distance_m:distance,reach_m:reach,within_reach:distance<reach,welcome_state:a.welcome.state,gate_dom_hidden:document.getElementById('gate')?.hidden??null,renderer_frame:a.renderer.info.render.frame??null,rounded_fps:a.stats().fps,governor:a.governor};};
   const observed=function(...args){const before=i.idle.status.elapsed_s,dt=Number(args[1]??0),opts=args[2]??{};const result=original.apply(this,args);const st=state(),visible=st.instance_visible&&!st.document_hidden&&st.ancestor_visibility.every(n=>n.visible),reduced=opts.reducedMotion===undefined?st.media_reduce:opts.reducedMotion,paused=opts.paused===undefined?false:opts.paused;
    counts.calls++;counts.positive_dt_calls+=Number(dt>0);counts.forwarded_dt_sum_s+=dt;counts.maximum_forwarded_dt_s=Math.max(counts.maximum_forwarded_dt_s,dt);counts.eligible_dt_sum_s+=!paused&&!reduced&&visible?dt:0;counts.paused_calls+=Number(paused);counts.reduced_calls+=Number(reduced);counts.hidden_document_calls+=Number(st.document_hidden);counts.invisible_calls+=Number(!visible);
    rows.push({phase:window.__horseIdleYardDiagnostic?.phase??'install',eligible:!paused&&!reduced&&visible,at_ms:performance.now()-start,forwarded_dt_s:dt,paused_argument:paused,reduced_motion_argument:opts.reducedMotion??null,effective_reduced_motion_from_public_media:reduced,visible,elapsed_before_s:before,elapsed_after_s:st.elapsed_s,renderer_frame:st.renderer_frame,document_hidden:st.document_hidden,media_reduce:st.media_reduce,distance_m:st.distance_m,reach_m:st.reach_m});return result;};
   layer.update=observed;
   const snapshot=()=>({wall_ms:performance.now()-start,initial_status:initial,initial_media_reduce:initialReduced,current:state(),counts:{...counts},all_forwarded_updates:rows.slice(),scope:'All actual forwarded layer dt, including unchanged explicit hidden/restoration probes labeled by phase; not raw private Clock delta. Original arguments/poses/source unchanged.'});
   window.__horseIdleYardDiagnostic={phase:'original_timing_observation',snapshot,restore(){if(layer.update===observed)layer.update=original;}};
   return snapshot();
  });
  // Observe the ordinary production host clock, not a synthetic mixer or direct pose assignment.
  await page.emulateMedia({reducedMotion:'no-preference'});
  await page.evaluate(()=>window.__chicago4d.setAnimationHold(false));
  try{
  await page.waitForFunction(()=>{const o=window.__horseIdleYardObservation,i=window.__chicago4d.standingHorses.instances[0];return i.idle.status.elapsed_s-o.before.elapsed>=1.5;},null,{timeout:15000,polling:100});
   report.original_timing_check={status:'PASS',owned_progress_target_s:1.5,wall_timeout_ms:15000};
  }catch(error){timingFailure=String(error.stack??error);report.original_timing_check={status:'FAIL',owned_progress_target_s:1.5,wall_timeout_ms:15000,error:timingFailure};report.idle_timeout_diagnostic=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());process.exitCode=1;}
  report.idle_diagnostic_after_wait=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());
  // Continue collecting independent product evidence; never erase the original timing FAIL.
  const productStep=async(name,run)=>{try{await page.evaluate(n=>{window.__horseIdleYardDiagnostic.phase=n;},name);const value=await run();report.product_checks[name]={status:'PASS',result:value};return value;}catch(error){productFailure=true;process.exitCode=1;report.product_checks[name]={status:'FAIL',error:String(error.stack??error)};return null;}finally{try{report.all_forwarded_clock_updates=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());}catch(error){productFailure=true;process.exitCode=1;report.clock_trace_error=String(error);report.product_checks[name].trace_status='FAIL';}await fs.writeFile(path.join(out,'progress.json'),JSON.stringify(report,null,2)+'\n');}};
  const clockAccounting=()=>page.evaluate(()=>{const d=window.__horseIdleYardDiagnostic.snapshot(),initial=d.initial_status;
   if(initial.elapsed_s!==0||d.initial_media_reduce!==true)throw Error('Accounting requires fresh zero-age clone under original initial reduce preference');
   let age=0,elapsed=0,maximumError=0;for(const row of d.all_forwarded_updates){if(!Number.isFinite(row.forwarded_dt_s)||row.forwarded_dt_s<0)throw Error('Nonfinite/negative actual forwarded dt');if(row.elapsed_before_s!==elapsed)throw Error('Unexpected owned-clock advance outside observed updates');const before=age;if(row.eligible)age+=row.forwarded_dt_s;elapsed+=(Math.max(0,age-initial.initial_rest_delay_s)-Math.max(0,before-initial.initial_rest_delay_s))*initial.deterministic_playback_rate;maximumError=Math.max(maximumError,Math.abs(row.elapsed_after_s-elapsed));if(maximumError!==0)throw Error('Actual forwarded-dt accounting differs from source-owned elapsed');}
   if(d.current.elapsed_s!==elapsed)throw Error('Current elapsed differs from complete forwarded-dt accounting');
   return{status:'SOURCE_CLOCK_ACCOUNTING_PASS',fresh_zero_age_basis:'Original new clone loaded under initial reduced motion, no prior eligible phase',observed_updates:d.all_forwarded_updates.length,eligible_age_s:age,source_delay_s:initial.initial_rest_delay_s,source_rate:initial.deterministic_playback_rate,expected_elapsed_s:elapsed,actual_elapsed_s:d.current.elapsed_s,maximum_absolute_error_s:maximumError,arithmetic_tolerance_s:0,scope:'Owned host-delta accounting only; original wall-clock timing result remains independent'};});
  await productStep('source_clock_accounting_after_original_wait',clockAccounting);
  report.idle_motion=await productStep('idle_motion',()=>page.evaluate(()=>{const o=window.__horseIdleYardObservation,after=o.sample(),delta=o.compare(o.before,after);o.after=after;if(Math.max(...Object.values(delta.hoof_maximum_drift_m))>1e-5||delta.source_bone_component_maximum_delta!==0||delta.head_maximum_displacement_m<=1e-8||delta.tail_maximum_displacement_m<=1e-8)throw Error('Actual host idle motion/clone/planted-hoof observation failed: '+JSON.stringify(delta));return{...delta,elapsed_before_s:o.before.elapsed,elapsed_after_s:after.elapsed,host_clock_observed:true};}));
  await productStep('active_view_framing_budget_capture',async()=>{const activeState=await snapshot('yard');if(!activeState.stats.withinBudget)throw Error('Existing public render budget exceeded during idle');await shot('quarter-idle-active',activeState);return{captured:'quarter-idle-active.png'};});
  report.idle_reduced_motion=await productStep('idle_reduced_motion',async()=>{
  await page.emulateMedia({reducedMotion:'reduce'});
  // Capture only after the actual media preference has reached the production layer.
  await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  const reducedStart=await page.evaluate(()=>{const o=window.__horseIdleYardObservation;o.pauseBefore=o.sample();return o.pauseBefore.elapsed;});
  await page.evaluate(()=>new Promise(r=>{let n=0;const next=()=>++n>=8?r():requestAnimationFrame(next);requestAnimationFrame(next);}));
  const result=await page.evaluate(start=>{const o=window.__horseIdleYardObservation,after=o.sample(),d=o.compare(o.pauseBefore,after);if(!matchMedia('(prefers-reduced-motion: reduce)').matches||after.elapsed!==start||d.bone_component_maximum_delta!==0||Math.max(...Object.values(d.hoof_maximum_drift_m))>1e-5)throw Error('Actual reduced-motion host pause failed');return{elapsed_s:after.elapsed,bone_component_maximum_delta:d.bone_component_maximum_delta,hoof_maximum_drift_m:d.hoof_maximum_drift_m,media_preference_observed:true,render_frames_observed:8};},reducedStart);
  return result;
  });
  report.idle_hidden=await productStep('idle_hidden',()=>page.evaluate(()=>{const a=window.__chicago4d,o=window.__horseIdleYardObservation,prior=a.confidence.hidden.reconstructed;a.setAnimationHold(true);const before=o.sample();a.confidence.setHidden('reconstructed',true);a.standingHorses.update(a.camera,1,{reducedMotion:false});const after=o.sample(),d=o.compare(before,after),i=a.standingHorses.instances[0];if(i.group.visible||after.elapsed!==before.elapsed||d.bone_component_maximum_delta!==0)throw Error('Confidence-hidden owned idle did not pause');a.confidence.setHidden('reconstructed',prior);a.standingHorses.update(a.camera,0,{reducedMotion:true});return{hidden_scope:'existing reconstructed-confidence visibility; not OS document visibility',elapsed_s:after.elapsed,bone_component_maximum_delta:d.bone_component_maximum_delta,hoof_maximum_drift_m:d.hoof_maximum_drift_m,visible_after_restore:i.group.visible};}));
  // Keep the original selection/card/confidence assertions and disposal after the observations.
  report.selection=await productStep('selection',()=>page.evaluate(async()=>{
   const a=window.__chicago4d,T=await import('three'),i=a.standingHorses.instances[0],p=new T.Vector3(i.group.position.x,i.group.position.y+.95,i.group.position.z).project(a.camera),hit=a.standingHorses.pickAt(new T.Vector2(p.x,p.y),a.camera);if(hit?.id!==i.row.id)throw Error('Horse layer pick failed');a.popup.show(hit.record);const text=document.querySelector('#popup').innerText;if(!text.includes('sevketkabatas')||!text.includes('Unidentified'))throw Error('Actual selection card lacks source credit/identity limit');a.popup.close();const prior=a.confidence.hidden.reconstructed;a.confidence.setHidden('reconstructed',true);a.standingHorses.update(a.camera);if(i.group.visible||a.standingHorses.pickAt(new T.Vector2(p.x,p.y),a.camera))throw Error('Hidden reconstructed horse still draws/picks');a.confidence.setHidden('reconstructed',prior);a.standingHorses.update(a.camera);return{id:hit.id,text,confidence_hide_pick_pass:true};
  }));
  await productStep('source_clock_accounting_after_pause_and_visibility',clockAccounting);
  await page.evaluate(()=>window.__horseIdleYardDiagnostic?.restore());
  report.teardown=await productStep('teardown',()=>page.evaluate(async()=>{const a=window.__chicago4d,i=a.standingHorses.instances[0],disposed={geometry:0,material:0};i.root.traverse(m=>{if(m.isMesh){m.geometry.addEventListener('dispose',()=>disposed.geometry++);m.material.addEventListener('dispose',()=>disposed.material++);}});await a.standingHorses.setTier('light');if(a.standingHorses.instances.length)throw Error('Light did not retire horse');a.standingHorses.dispose();if(!i.idle.status.disposed||i.idle.status.mixer_count!==0)throw Error('Owned idle not retired before clone disposal');return{disposed,idle_status:i.idle.status,instances:a.standingHorses.instances.length};}));
 }
 if(report.errors.length)throw Error('Browser errors recorded');report.product_checks_status=productFailure?'FAIL':'PASS';report.pass=!timingFailure&&!productFailure;if(timingFailure){report.error=timingFailure;process.exitCode=1;}if(productFailure)process.exitCode=1;
}catch(error){report.error=String(error.stack??error);process.exitCode=1;}
finally{
 if(page&&!page.isClosed()){try{await page.evaluate(()=>window.__horseIdleYardDiagnostic?.restore());}catch{}}
 if(browser)await browser.close();if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}
 report.closed=true;report.ended=new Date().toISOString();report.inputs_unchanged=true;
 for(const [file,hash]of Object.entries(cfg.expected_files))if(sha(await fs.readFile(file))!==hash)report.inputs_unchanged=false;
 if(!report.inputs_unchanged){report.pass=false;process.exitCode=1;}
 await fs.writeFile(path.join(out,'receipt.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({phase,pass:report.pass,captures:report.captures.length,closed:report.closed,error:report.error}));
}
