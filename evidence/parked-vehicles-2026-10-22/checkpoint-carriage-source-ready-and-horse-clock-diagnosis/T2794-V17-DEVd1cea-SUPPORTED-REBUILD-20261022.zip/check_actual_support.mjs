// Single-purpose source proof. No browser, producer, app writes or synthetic ground.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
const APP='/tmp/chicago-covered-sag/chicago/4d', HERE=path.dirname(new URL(import.meta.url).pathname);
const OLD=HERE+'/PRE-FIX-WORLD-SOURCE';
const read=p=>fs.readFileSync(path.join(APP,p)), json=p=>JSON.parse(read(p));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const need=(v,m)=>{if(!v)throw Error(m)}, started=performance.now();
const result={state:'RUNNING',pass:false,scope:'Brougham rigid support arithmetic against actual current production source provider; not rendered world acceptance',negativeControls:[],sourcePins:{}};
const save=()=>fs.writeFileSync(path.join(HERE,'ACTUAL-SUPPORT-RESULT.json'),JSON.stringify(result,null,2)+'\n');
save();
try {
  const oldBytes=fs.readFileSync(OLD+'/ACTUAL-SOURCE-COMPLETION.json'), old=JSON.parse(oldBytes);
  result.preservedPreFix={sha256:hash(oldBytes),standSourceChecksPass:old.standSourceChecksPass,shoeGuardPass:old.road.productionShoeGuardPass};
  need(old.standSourceChecksPass===false&&!old.road.productionShoeGuardPass,'Historical failure must remain failure');
  for(const [rel,pin] of Object.entries(old.sourcePins)) {
    if(rel==='renderers/web/js/parked-transport.js')continue;
    need(hash(read(rel))===pin.sha256,'Actual dependency drift '+rel);
    result.sourcePins[rel]={sha256:hash(read(rel)),bytes:read(rel).length};
  }
  const current=read('renderers/web/js/parked-transport.js').toString(),before=fs.readFileSync(HERE+'/PRE-FIX-parked-transport.js','utf8');
  need(hash(before)===old.sourcePins['renderers/web/js/parked-transport.js'].sha256,'Preserved helper preimage');
  result.sourcePins['renderers/web/js/parked-transport.js']={sha256:hash(current),bytes:Buffer.byteLength(current)};
  const T=await import(pathToFileURL(APP+'/renderers/web/vendor/three-0.185.1/three.module.js'));
  const context=vm.createContext({THREE:T,grid:json('data/street_grid/1904.json'),surfaces:json('data/street_surfaces/1904.json'),section:json('data/street_section/1904.json'),out:{census:{carriageways:0,surfaced:0}},terrain:{surfaceHeight:()=>{throw Error('Unbound actual heightfield')}},push:()=>{}});
  const exact=fs.readFileSync(OLD+'/EXACT-PRODUCTION-RANGES.js','utf8');
  result.extractedProviderSha256=hash(exact);
  vm.runInContext(exact,context,{timeout:3000});
  const r=context.READER,bin=read('data/terrain/epochs/e1871_postfire/heightfield.bin');
  const field=new r.Heightfield().adopt(json('data/terrain/epochs/e1871_postfire/heightfield.json'),bin.buffer.slice(bin.byteOffset,bin.byteOffset+bin.byteLength));
  context.terrain.surfaceHeight=(e,n)=>{need(field.contains(e,n),'No fallback ground allowed');return field.sample(e,n)};
  const ground=r.out.carriagewayHeight,record=json('data/transport/parked/placements.json');
  const row=record.scenes['1904'].find(x=>x.id==='prairie_parked_studebaker_brougham'),spec=record.models[row.model];
  need(JSON.stringify([row.at_local_enu_m,row.bearing_deg])===JSON.stringify([[1397.9,-3240],178.99]),'Unchanged exact stand');
  const yaw=Math.PI-row.bearing_deg*Math.PI/180,co=Math.cos(yaw),si=Math.sin(yaw);
  const en=([x,y,z])=>[row.at_local_enu_m[0]+co*x+si*z,row.at_local_enu_m[1]+si*x-co*z];
  function compile(text) {
    const start=text.indexOf('          const yaw = yawOf(row.bearing_deg)'),end=text.indexOf('          const parking = parkTongue',start);
    need(start>=0&&end>start,'Exact runtime support range');
    const body=text.slice(start,end)+'\nreturn {base,wheelGap,staticSupport};';
    return vm.runInNewContext('(function(row,spec,heightAt,yawOf){'+body+'})',{}, {timeout:1000});
  }
  const runtime=compile(current),previous=compile(before),yawOf=b=>Math.PI-b*Math.PI/180;
  const execute=(fn,a=row,b=spec,g=ground)=>fn(a,b,g,yawOf);
  function rejected(name,run,pattern) {let error=null;try{run()}catch(e){error=e.message}need(error&&pattern.test(error),'Negative control was not rejected: '+name+' '+error);result.negativeControls.push({name,rejected:true,error})}
  rejected('Actual unchanged stand under preserved wheel-only source',()=>execute(previous),/Static support exceeds 1mm penetration\/30mm gap limits/);
  const actual=execute(runtime);
  need(Math.abs(actual.base-4.07988902922361)<1e-12,'Expected actual all-contact base');
  need(actual.wheelGap<.03&&actual.staticSupport.minimum_gap_m>=-.001&&actual.staticSupport.maximum_gap_m<.03,'Unchanged actual guards');
  result.actual={...actual,previousWheelBase_m:old.road.base,verticalDelta_m:actual.base-old.road.base,stand:row.at_local_enu_m,bearing_deg:row.bearing_deg};
  // Match the full actual raw shoe bottom and indexed near bottom, not an AABB
  // substitution for the rest of the vehicle. These vertices are exactly flat.
  function shoeBottom(rel) {
    const b=read(rel),length=b.readUInt32LE(12),g=JSON.parse(b.subarray(20,20+length)),start=28+length,found=[];
    const matrices=new Map();
    function visit(i,parent){const n=g.nodes[i],m=new T.Matrix4();if(n.matrix)m.fromArray(n.matrix);else m.compose(new T.Vector3(...(n.translation??[0,0,0])),new T.Quaternion(...(n.rotation??[0,0,0,1])),new T.Vector3(...(n.scale??[1,1,1])));m.premultiply(parent);matrices.set(i,m);for(const j of n.children??[])visit(j,m)}
    for(const i of g.scenes[g.scene??0].nodes)visit(i,new T.Matrix4());
    for(const [i,m] of matrices){const n=g.nodes[i];if(n.mesh===undefined)continue;for(const p of g.meshes[n.mesh].primitives){const a=g.accessors[p.attributes.POSITION],v=g.bufferViews[a.bufferView];need(a.componentType===5126&&a.type==='VEC3'&&!a.sparse,'Native position accessor');for(let j=0;j<a.count;j++){const off=start+(v.byteOffset??0)+(a.byteOffset??0)+j*(v.byteStride??12);const q=new T.Vector3(b.readFloatLE(off),b.readFloatLE(off+4),b.readFloatLE(off+8)).applyMatrix4(m);if(Math.abs(q.y)<1e-8&&q.z>3.7&&Math.abs(q.x)<.04)found.push(q.toArray())}}}
    const unique=[...new Map(found.map(q=>[q.join(','),q])).values()];need(unique.length===4,'Exact four real shoe-bottom corners '+rel);return unique;
  }
  const near=shoeBottom('renderers/web/transport/parked-brougham/brougham-near.glb'),raw=shoeBottom('renderers/web/transport/parked-brougham/brougham-source.glb');
  need(JSON.stringify(near.slice().sort())===JSON.stringify(raw.slice().sort()),'Raw and near actual bottom match');
  for(const p of near)need(spec.static_support_contacts_m.some(q=>q.every((x,i)=>Math.abs(x-p[i])<1e-7)),'Declared corners match actual geometry');
  const contactCorners=spec.static_support_contacts_m,actualCorners=near;
  function patchProof(corners) {
    const ordered=[corners[0],corners[1],corners[3],corners[2]],poly=ordered.map(en);
    // All raw/near corners occur in one cell. On a single bilinear patch, the
    // world-gradient components are linear. If their ranges exclude zero with
    // the signs below, their projections along both rotated rectangle edges
    // also exclude zero: full patch maximum is a corner, without sampling gaps.
    const cells=poly.map(([e,n])=>[Math.floor((e-field.originE)/field.cellM),Math.floor((n-field.originN)/field.cellM)]);
    need(cells.every(q=>q[0]===cells[0][0]&&q[1]===cells[0][1]),'Patch crosses source field cell');
    const [ix,iy]=cells[0],d=field.data,c=field.cols,h00=d[iy*c+ix],h10=d[iy*c+ix+1],h01=d[(iy+1)*c+ix],h11=d[(iy+1)*c+ix+1];
    const gradients=poly.map(([e,n])=>{const u=(e-field.originE)/field.cellM-ix,v=(n-field.originN)/field.cellM-iy;return[((h10-h00)*(1-v)+(h11-h01)*v)/field.cellM,((h01-h00)*(1-u)+(h11-h10)*u)/field.cellM]});
    const gx=gradients.map(q=>q[0]*co+q[1]*si),gz=gradients.map(q=>q[0]*si-q[1]*co);
    need(Math.max(...gx)<0&&Math.min(...gz)>0,'Actual patch monotonic directions');
    const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
    function inside(p){const cs=poly.map((a,i)=>cross(a,poly[(i+1)%4],p));return cs.every(x=>x>=0)||cs.every(x=>x<=0)}
    function intersects(a,b,c,d){return cross(a,b,c)*cross(a,b,d)<=0&&cross(c,d,a)*cross(c,d,b)<=0&&Math.max(Math.min(a[0],b[0]),Math.min(c[0],d[0]))<=Math.min(Math.max(a[0],b[0]),Math.max(c[0],d[0]))&&Math.max(Math.min(a[1],b[1]),Math.min(c[1],d[1]))<=Math.min(Math.max(a[1],b[1]),Math.max(c[1],d[1]))}
    let boundaries=0;for(const surface of r.roadStandSurfaces)for(const p of surface.polygons){need(poly.every(q=>r.pointInPolygon(...q,p)===r.pointInPolygon(...poly[0],p)),'Road membership changes at patch corners');for(let i=0;i<p.length;i++){need(!inside(p[i]),'Road boundary vertex inside patch');for(let k=0;k<4;k++){boundaries++;need(!intersects(p[i],p[(i+1)%p.length],poly[k],poly[(k+1)%4]),'Road boundary crosses patch')}}}
    const heights=poly.map(p=>ground(...p));need(heights.every(Number.isFinite),'Actual patch is carriageway');
    return {corners:ordered,worldENU:poly,cell:cells[0],heightfieldCornerValues_m:[h00,h10,h01,h11],gradientAlongLocalXRange:[Math.min(...gx),Math.max(...gx)],gradientAlongLocalZRange:[Math.min(...gz),Math.max(...gz)],roadBoundarySegmentPairsChecked:boundaries,noRoadBoundaryCrossings:true,minimumGap_m:actual.base-Math.max(...heights),maximumGap_m:actual.base-Math.min(...heights),scope:'Entire fixed rectangular flat bottom over this one current bilinear source cell and constant road lift; not a rendered-triangle contact assertion'};
  }
  // Normalize raw vertex ordering to the declared corner order before proof.
  const sortedActual=contactCorners.map(q=>actualCorners.find(p=>p.every((x,i)=>Math.abs(x-q[i])<1e-7)));
  result.fullShoePatch={declared:patchProof(contactCorners),actualRawAndNear:patchProof(sortedActual)};
  need(result.fullShoePatch.actualRawAndNear.minimumGap_m>=-1e-8,'Actual full shoe patch must clear within Float32 geometry roundoff');
  const pointKey=p=>p.map(x=>x.toFixed(8)).join(','),supportKeys=new Set(contactCorners.map(en).map(pointKey));
  const altered=(delta,missing)=>((e,n)=>supportKeys.has(pointKey([e,n]))?(missing??ground(e,n)+delta):ground(e,n));
  rejected('Actual support surface raised41mm still rejects wheel gap',()=>execute(runtime,row,spec,altered(.041)),/Stand exceeds 30mm wheel-plane variation/);
  rejected('Actual support surface lowered41mm still rejects shoe gap',()=>execute(runtime,row,spec,altered(-.041)),/Static support exceeds 1mm penetration\/30mm gap limits/);
  rejected('Null support ground refused before numeric coercion',()=>execute(runtime,row,spec,(e,n)=>supportKeys.has(pointKey([e,n]))?null:ground(e,n)),/No rendered ground under all static support contacts/);
  rejected('NaN support ground refused',()=>execute(runtime,row,spec,(e,n)=>supportKeys.has(pointKey([e,n]))?NaN:ground(e,n)),/No rendered ground under all static support contacts/);
  const wheelKeys=new Set(spec.wheel_contacts_m.map(([x,z])=>pointKey(en([x,0,z]))));
  rejected('Null wheel ground refused',()=>execute(runtime,row,spec,(e,n)=>wheelKeys.has(pointKey([e,n]))?null:ground(e,n)),/No ground under all four wheels/);
  const firstWheel=[...wheelKeys][0];
  rejected('Actual one-wheel41mm rise retains original wheel-span guard',()=>execute(runtime,row,spec,(e,n)=>ground(e,n)+(pointKey([e,n])===firstWheel ? .041 : 0)),/Stand exceeds 30mm wheel-plane variation/);
  rejected('Malformed static support contact refused',()=>execute(runtime,row,{...spec,static_support_contacts_m:[[0,NaN,0]]}),/Invalid static support contacts/);
  rejected('Other model ID does not receive the Brougham solve',()=>execute(runtime,{...row,model:'carriage_c02'},spec),/Static support exceeds 1mm penetration\/30mm gap limits/);
  // The actual main caller uses the 1835 terrain directly, rather than the
  // 1904 road provider. Compare both old and new paths on their real providers.
  const legacyPins=['renderers/web/js/main.js','data/scenes/1835.json','data/terrain/epochs/e1834_harbor_cut/heightfield.json','data/terrain/epochs/e1834_harbor_cut/heightfield.bin'];
  for(const rel of legacyPins)result.sourcePins[rel]={sha256:hash(read(rel)),bytes:read(rel).length};
  need(read(legacyPins[0]).toString().includes("groundHeight: String(YEAR) === '1904' ? (e, n) => streetGrid.carriagewayHeight(e, n) : null"),'Exact caller provider selection');
  need(json(legacyPins[1]).terrain_epoch==='e1834_harbor_cut','Current 1835 epoch');
  const legacyBin=read(legacyPins[3]),legacyField=new r.Heightfield().adopt(json(legacyPins[2]),legacyBin.buffer.slice(legacyBin.byteOffset,legacyBin.byteOffset+legacyBin.byteLength));
  const legacyGround=(e,n)=>{need(legacyField.contains(e,n),'No 1835 fallback ground allowed');return legacyField.sample(e,n)};
  result.legacyPaths=[];
  for(const [scene,rows]of Object.entries(record.scenes))for(const rr of rows){if(rr.model===row.model)continue;const ss=record.models[rr.model];need(!ss.static_support_contacts_m,'Unexpected second static support model');const provider=scene==='1835'?legacyGround:ground;let a,b;try{a={value:execute(previous,rr,ss,provider)}}catch(e){a={error:e.message}}try{b={value:execute(runtime,rr,ss,provider)}}catch(e){b={error:e.message}}need(JSON.stringify(a)===JSON.stringify(b),'Legacy source behavior changed '+rr.id);need(a.value,'Actual legacy support result must succeed '+rr.id);result.legacyPaths.push({scene,id:rr.id,result:a,provider:scene==='1835'?'Exact e1834_harbor_cut Heightfield.adopt/sample':'Exact 1904 street-grid carriagewayHeight'})}
  result.unchangedGeometryFiniteSamples={originalCount:old.geometryGround.vertexSamples+old.geometryGround.midpointAndCentroidSamples,minimumGapAfterVerticalShift_m:old.geometryGround.minGroundGap_m+actual.base-old.road.base,geometryAndPosePinsReverified:true,scope:'Algebraic vertical translation of preserved completed finite source samples; no claim of continuous full-body or obstacle clearance'};
  result.unproved=old.unproved;
  result.pass=true;result.state='CLOSED_SOURCE_SUPPORT_PASS';
}catch(error){result.state='CLOSED_SOURCE_SUPPORT_FAILURE';result.error=String(error.stack??error);process.exitCode=1}
finally{result.seconds=(performance.now()-started)/1000;save();console.log(JSON.stringify({state:result.state,pass:result.pass,seconds:result.seconds,actual:result.actual,fullShoePatch:result.fullShoePatch,negativeControls:result.negativeControls,legacyPaths:result.legacyPaths?.length,error:result.error},null,2))}
