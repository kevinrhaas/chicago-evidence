Actual preflight79000 CLOSED EXIT1, one failed step of1047: liberties derivation. Changelog and IDs passed. Exact2ad/03ef/4459 tree stayed unchanged; all three global logs copied immediately. No commit/push/publication-finish or automatic retry.

Immutable2ad shows687 headings and687 JSON entries but declared count686. Local resolver started149 (source-use conflict), skipped liberties compiler142, and settled only that52-step tail. No compilerbug proven. Existing canonicalCI lap runs full--run atpr-lap.sh618/743, so covers142.

A later read-only expectedJSON build raced rootmergeabort and is explicitlyINVALID as2adproof. Preserve original fullgate logs and immutableGitblob comparison; do not use racing expectedJSON as a repair. Root owns abort/scopedCI lap and futureappchanges. Canonical ticket writes allowed afteractualgateclosure/logcapture.
