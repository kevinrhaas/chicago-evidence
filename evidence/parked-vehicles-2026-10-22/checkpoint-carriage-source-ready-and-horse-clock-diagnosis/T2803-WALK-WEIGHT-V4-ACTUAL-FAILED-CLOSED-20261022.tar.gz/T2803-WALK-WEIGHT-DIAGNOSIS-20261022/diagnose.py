"""ONE bounded witness readback on preserved failed skins. No candidate solve."""
import pathlib,sys,json,hashlib,time,math
import numpy as np
ROOT=pathlib.Path('/workspace/shared');P=pathlib.Path(__file__).resolve().parent;OLD=ROOT/'T2803-FOUR-LIMB-WALK-SOURCE-V2-20261022';sys.path.insert(0,str(OLD))
from actual_model import Model
from weight_proposal_v3 import weights_for_mesh
start=time.monotonic();F=ROOT/'T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb';m=Model(F);assert hashlib.sha256(m.raw).hexdigest()=='03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36';control=json.loads((OLD/'RERIG-CONTROLS-PROPOSAL-V2.json').read_text());frames=json.loads((OLD/'AUTHORED-NATIVE-WALK-POSES.json').read_text())['frames'];side=json.loads((ROOT/'horse-standing-intake-proposal-V2-20261022/proposed/data/transport/parked/horse-sevket-sidecar.json').read_text());ib=m.accessor(m.g['skins'][0]['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1);parts=[];rest=[];dense=[];labels={i:('body'if i<6 else next(k for k,v in control['limbs'].items()if i in v['joints']))for i in range(26)}
for ni in [26,27,28]:
 pr=m.g['meshes'][m.g['nodes'][ni]['mesh']]['primitives'][0];a=pr['attributes'];pos=m.accessor(a['POSITION']).astype(float);j=m.accessor(a['JOINTS_0']).astype(int);w=m.accessor(a['WEIGHTS_0']).astype(float);ix=m.accessor(pr['indices']).astype(int).reshape(-1,3);parts.append((pos,j,w,ix));rest.append(m.mesh(ni)[0]);de=np.zeros((len(pos),26));np.add.at(de,(np.arange(len(pos))[:,None],j),w);dense.append(de)
v3=[]
for mi,(pos,j,w,ix)in enumerate(parts):
 force={}
 if mi==1:
  for label,row in side['contacts'].items():
   for vi in np.unique(ix[row['source_triangle_ids']].ravel()):force[int(vi)]=label
 jj,ww=weights_for_mesh(rest[mi],j,w,control,force);v3.append([jj.astype(int),ww.astype(float)])
shared={}
for mi,(j,w)in enumerate(v3):
 for vi,point in enumerate(rest[mi]):
  key=tuple(np.rint(point/1e-6).astype(int))
  if key in shared:j[vi],w[vi]=shared[key]
  else:shared[key]=(j[vi].copy(),w[vi].copy())
def vertex(mi,i,j,w,moved):
 return {'id':int(i),'rest_m':rest[mi][i].tolist(),'posed_m':moved[i].tolist(),'weights':[{'joint':int(a),'name':control['nodes'][int(a)]['name'],'compartment':labels[int(a)],'weight':float(b)}for a,b in zip(j[i],w[i])if b>0]}
result={}
for version in ['immutable_serialized_V2','rejected_source_V3']:
 witnesses={key:[]for key in ['edge_stretch','edge_compression','area_stretch','area_compression','normal_rotation']};stats=[]
 for mi,(pos,j0,w0,ix)in enumerate(parts):
  j,w=(j0,w0)if version=='immutable_serialized_V2'else v3[mi];tris=rest[mi][ix];ev=np.linalg.norm(tris[:,[1,2,0]]-tris[:,[0,1,2]],axis=2);rn=np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0]);ra=np.linalg.norm(rn,axis=1);valid=ra>1e-12;edgevalid=ev>1e-8;worstmax=1.;worstmin=1.;positive_otherlimb=0
  for vi in range(len(pos)):
   compartments={labels[int(a)]for a,b in zip(j[vi],w[vi])if b>0};positive_otherlimb+=len(compartments-{'body'})>1
  for frame in frames:
   mats=np.asarray(frame['global_body_frame_matrices']);trans=mats@ib;blend=np.einsum('nw,nwij->nij',w,trans[j]);moved=np.einsum('nij,nj->ni',blend,np.c_[pos,np.ones(len(pos))])[:,:3];tri=moved[ix];edge=np.linalg.norm(tri[:,[1,2,0]]-tri[:,[0,1,2]],axis=2);ratio=np.divide(edge,ev,out=np.ones_like(edge),where=edgevalid);normal=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);area=np.linalg.norm(normal,axis=1);ar=np.divide(area,ra,out=np.ones_like(area),where=valid);cos=np.divide(np.einsum('ni,ni->n',normal,rn),ra*area,out=np.ones(len(ra)),where=valid&(area>1e-15));worstmax=max(worstmax,float(ratio.max()));worstmin=min(worstmin,float(ratio.min()))
   for key,values,kind in [('edge_stretch',ratio,'max'),('edge_compression',ratio,'min'),('area_stretch',ar,'max'),('area_compression',ar,'min'),('normal_rotation',cos,'min')]:
    flat=int(np.argmax(values)if kind=='max'else np.argmin(values));value=float(values.flat[flat]);ti=flat//3 if values.ndim==2 else flat;ids=ix[ti];vtx=[vertex(mi,int(i),j,w,moved)for i in ids];row={'mesh':mi,'triangle':int(ti),'time_s':frame['time_s'],'metric_value':value,'rest_triangle_area_twice_m2':float(ra[ti]),'vertices':vtx}
    if values.ndim==2:
     k=flat%3;a,b=ids[k],ids[(k+1)%3];dd=np.zeros((2,26));np.add.at(dd,(np.arange(2)[:,None],j[[a,b]]),w[[a,b]]);row.update({'edge_vertex_ids':[int(a),int(b)],'rest_edge_length_m':float(ev[ti,k]),'edge_weight_L1_difference':float(np.abs(dd[0]-dd[1]).sum())})
    rows=witnesses[key];rows.append(row);rows.sort(key=lambda x:x['metric_value'],reverse=kind=='max');del rows[5:]
  stats.append({'mesh':mi,'vertices':len(pos),'vertices_with_multiple_limb_compartments':positive_otherlimb,'edge_ratio_min':worstmin,'edge_ratio_max':worstmax})
 result[version]={'witnesses':witnesses,'compartment_statistics':stats}
out={'status':'ACTUAL FAILED SKIN WITNESSES; NO CANDIDATE OR GAIT ACCEPTANCE','source_original_sha256':'41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988','actual_rig_sha256':hashlib.sha256(m.raw).hexdigest(),'frozen_walk_poses_sha256':hashlib.sha256((OLD/'AUTHORED-NATIVE-WALK-POSES.json').read_bytes()).hexdigest(),'sample_count':len(frames),'vertices_per_sample':sum(len(p[0])for p in parts),'versions':result,'scope':'All actual triangle edges/areas/rest-relative normal directions across same65failed source poses. V3 counterfactual reproduces exact existing rejected recipe; no candidate modification. Rest-relative normal rotation is not an inversion/selfintersection proof.','elapsed_seconds':time.monotonic()-start}
(P/'ACTUAL-WORST-WITNESSES.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'elapsed_s':out['elapsed_seconds'],'summary':{version:{'stats':v['compartment_statistics'],'worst':{k:{a:b for a,b in rows[0].items()if a!='vertices'}for k,rows in v['witnesses'].items()}}for version,v in result.items()}},indent=2))
