"""HELD, UNEXECUTED source candidate. Actual surface-edge Dirichlet weights.

The positive symmetric graph energy sum((wi-wj)^2/edge_length) has one exact
Dirichlet solve, not repeated paint guesses. Mesh position classes weld existing
UV/material seams only. No nearest-Euclidean surface connections are created.
Each limb domain has body-valued boundary vertices, so another limb never leaks
across compartments and a radius/sign boundary never retains an old moving mix.

Handles/axes and all domains remain reconstructed. Surface-harmonic interpolation
is an engineering proposal, not anatomy or plausible loaded-gait certification.
"""
import numpy as np
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import spsolve

DECLARED={'version':'V4_HELD_SURFACE_GRAPH_HARMONIC','maximum_influences':4,'seam_position_quantization_m':1e-6,'maximum_seam_class_spread_m':2e-6,'positive_graph_conductance':'1/source_edge_length_m','domain_top_y_m':1.14,'domain_maximum_chain_XZ_radius_m':.30,'domain_signed_x_minimum_m':.04,'domain_signed_z_minimum_m':.10,'proximal_handle_segment_fraction':[.25,.75],'proximal_handle_surface_distance_m':.13,'lower_handle_segment_fraction':[.25,.75],'lower_handle_surface_distance_m':.12,'rigid_distal_handle_maximum_y_m':.30,'maximum_harmonic_residual_abs':1e-8,'negative_roundoff_bound':1e-9,'same_gait_and_surface_thresholds':True}

def build(rest,parts,controls,hoof_patch_ids):
 # Returns counterfactual source arrays only. Never writes an asset or app file.
 keys={};members=[];points=[];vertex_class=[]
 for mi,ps in enumerate(rest):
  ids=[]
  for vi,p in enumerate(ps):
   key=tuple(np.rint(p/DECLARED['seam_position_quantization_m']).astype(int))
   if key not in keys:keys[key]=len(points);points.append(p);members.append([])
   ci=keys[key];members[ci].append((mi,vi));ids.append(ci)
  vertex_class.append(np.array(ids,dtype=int))
 points=np.asarray(points);N=len(points);spread=max(np.linalg.norm(rest[mi][vi]-points[ci])for ci,group in enumerate(members)for mi,vi in group);assert spread<=DECLARED['maximum_seam_class_spread_m']
 all_edges=[]
 for mi,part in enumerate(parts):
  tri=vertex_class[mi][part[4]]
  for a,b in [(0,1),(1,2),(2,0)]:all_edges.append(np.sort(tri[:,[a,b]],axis=1))
 edges=np.unique(np.concatenate(all_edges),axis=0);edges=edges[edges[:,0]!=edges[:,1]];u,v=edges.T;length=np.linalg.norm(points[u]-points[v],axis=1);assert np.all(length>1e-8);conductance=1/length
 graph=coo_matrix((np.r_[conductance,conductance],(np.r_[u,v],np.r_[v,u])),shape=(N,N)).tocsr();lap=diags(np.asarray(graph.sum(1)).ravel())-graph
 piv=np.array([row['rest_world_pivot_m']for row in controls['nodes']]);limbs=controls['limbs'];names=list(limbs);domain=np.full(N,-1,dtype=int)
 for ci,(x,y,z) in enumerate(points):
  if y>=DECLARED['domain_top_y_m']or abs(x)<=DECLARED['domain_signed_x_minimum_m']or abs(z)<=DECLARED['domain_signed_z_minimum_m']:continue
  label=('fore_'if z>0 else'hind_')+('l'if x>0 else'r');ids=limbs[label]['joints'];ordered=ids[::-1];center=np.array([np.interp(y,piv[ordered,1],piv[ordered,k])for k in [0,2]])
  if np.linalg.norm(np.array([x,z])-center)<DECLARED['domain_maximum_chain_XZ_radius_m']:domain[ci]=names.index(label)
 # Every vertex incident to an edge leaving its domain is exactly BODY. This
 # is an explicit shared Dirichlet seam, not an abrupt old-weight fallback.
 boundary=np.zeros(N,dtype=bool);different=domain[u]!=domain[v];boundary[u[different]]=True;boundary[v[different]]=True
 hoof={label:np.unique(vertex_class[1][ids])for label,ids in hoof_patch_ids.items()}
 # Unchanged non-limb source weights retain head/neck/tail membership. Old limb
 # influences outside solved domains become body influence; no moving fallback.
 dense=np.zeros((N,26))
 for ci,group in enumerate(members):
  mi,vi=group[0];j,w=parts[mi][2][vi],parts[mi][3][vi]
  for a,b in zip(j,w):dense[ci,int(a) if a<6 else 1]+=b
  dense[ci]/=dense[ci].sum()
 reports=[]
 def segment_distance(ps,a,b):
  d=b-a;t=np.clip((ps-a)@d/(d@d),0,1);return np.linalg.norm(ps-a-t[:,None]*d,axis=1),t
 for di,label in enumerate(names):
  ids=limbs[label]['joints'];a,b,c,d,e=ids;region=np.flatnonzero(domain==di);assert len(region)>0
  # Within the domain all four fields have consistent semantic slots:
  # body, actual proximal control, actual lower control, own hoof control.
  desired=np.zeros((N,4));desired[:,0]=1.;fixed=np.ones(N,dtype=bool);fixed[region]=False;fixed[region[boundary[region]]]=True
  body_boundary=np.flatnonzero((domain==di)&boundary);assert len(body_boundary)>0
  eligible=region[~boundary[region]];dist1,t1=segment_distance(points[eligible],piv[a],piv[b]);dist2,t2=segment_distance(points[eligible],piv[b],piv[c]);lo,hi=DECLARED['proximal_handle_segment_fraction'];upper=eligible[(dist1<DECLARED['proximal_handle_surface_distance_m'])&(t1>=lo)&(t1<=hi)];lo,hi=DECLARED['lower_handle_segment_fraction'];lower=eligible[(dist2<DECLARED['lower_handle_surface_distance_m'])&(t2>=lo)&(t2<=hi)];distal=eligible[points[eligible,1]<=DECLARED['rigid_distal_handle_maximum_y_m']]
  # No two contradictory painted handles may silently overwrite one another.
  assert len(upper)>0 and len(lower)>0 and len(distal)>0
  assert not np.intersect1d(upper,lower).size and not np.intersect1d(upper,distal).size and not np.intersect1d(lower,distal).size
  assert np.all(domain[hoof[label]]==di)and not np.any(boundary[hoof[label]])
  distal=np.union1d(distal,hoof[label]);handle_groups=[upper,lower,distal]
  for slot,handle in enumerate(handle_groups,1):fixed[handle]=True;desired[handle]=0;desired[handle,slot]=1
  unknown=np.flatnonzero((domain==di)&~fixed);known=np.flatnonzero(fixed);assert len(unknown)>0
  matrix=lap[unknown][:,unknown].tocsc();rhs=-(lap[unknown][:,known]@desired[known]);solution=spsolve(matrix,rhs);assert np.isfinite(solution).all();residual=float(np.abs(matrix@solution-rhs).max());assert residual<DECLARED['maximum_harmonic_residual_abs'];assert solution.min()>=-DECLARED['negative_roundoff_bound']and solution.max()<=1+DECLARED['negative_roundoff_bound'];assert np.abs(solution.sum(1)-1).max()<1e-8
  desired[unknown]=np.clip(solution,0,1);desired[unknown]/=desired[unknown].sum(1)[:,None];dense[region]=0;dense[np.ix_(region,[1,a,b,e])]=desired[region]
  energy=[float(desired[:,k]@(lap@desired[:,k]))for k in range(4)]
  reports.append({'limb':label,'region_classes':len(region),'body_boundary_classes':len(body_boundary),'upper_handle_classes':len(upper),'lower_handle_classes':len(lower),'rigid_distal_handle_classes':len(distal),'original_hoof_classes':len(hoof[label]),'unknown_classes':len(unknown),'maximum_harmonic_residual_abs':residual,'positive_graph_energy_by_field':energy})
 # Float32 is deliberate: actual new candidate weight streams must later be
 # serialized and independently decoded; this is source counterfactual only.
 order=np.argsort(-dense,axis=1,kind='stable')[:,:4];w=np.take_along_axis(dense,order,axis=1);assert np.count_nonzero(dense>0,axis=1).max()<=4;w/=w.sum(1)[:,None];w=w.astype(np.float32);j=order.astype(np.uint16)
 for label,classes in hoof.items():
  own=limbs[label]['joints'][-1];assert np.all(np.where(j[classes]==own,w[classes],0).sum(1)==1)
 arrays=[(j[vc].astype(int),w[vc].astype(float))for vc in vertex_class]
 return arrays,{'status':'HELD CANDIDATE SOLVED ONLY IF EXPLICITLY EXECUTED; no quality acceptance','method':DECLARED,'classes':N,'edges':len(edges),'maximum_class_spread_m':float(spread),'limbs':reports,'original_head_tail_weights_outside_limb_domains_retained':True,'multiple_limb_compartments_per_vertex':False,'neutral_geometry_preservation_requires_actual_CPU_check':True}
