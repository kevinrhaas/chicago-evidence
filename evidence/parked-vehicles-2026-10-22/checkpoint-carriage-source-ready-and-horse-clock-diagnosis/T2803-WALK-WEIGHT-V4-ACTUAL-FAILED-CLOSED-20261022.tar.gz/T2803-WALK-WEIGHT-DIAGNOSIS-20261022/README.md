# Actual failure witnesses and one HELD harmonic-weight candidate

The root-authorized diagnostic pass is CLOSED: one15s-capped nice19/math1 process, exit0,1.477674s. It reads the unchanged03a1 GLB and the same65 frozen walk poses. It evaluates both previously failed weight versions; this is not a new candidate run. Original assets, app, Git, tickets, browsers and Blender are untouched.

## Actual failure location

The immutable serialized weights have254 body-mesh vertices with influence from more than one limb compartment. The worst failures lie in the upper foreleg/chest transition, not sub-micrometre degenerate edges:

| Metric | Actual body triangle / witness | Actual result |
|---|---|---:|
| V2 stretch |5373, edge3282–3242, time1.075s, rest19.367mm |2.106869×|
| V2 compression |5291, edge2963–3227, time0.25s, rest20.074mm |0.260358×|
| V2 area stretch |5379, time0.25s |3.498097×|
| V2 area compression |5296, time1.1s |0.068018×|
| V2 rest-normal cosine |5296, time1.075s |−0.999196|
| V3 stretch |5376, edge3278–3282, time1.075s, rest10.460mm |5.071663×|

For V2, upper chest vertices atY=.789–.904m carry26–75% elbow influence even though the reconstructed elbow pivot isY=.76m. Whole-link interpolation therefore moves proximal surface points with a distal control. It also blends across limb compartments.

For V3, the witness is a concrete domain discontinuity: vertex3278, `[.17278,.90121,.70562]`, retains old55.1% body/22.9% elbow/21.5% shoulder weights just outside the overwrite radius; neighbouring3282, `[.17636,.90391,.69617]`, becomes89.2% body/10.8% shoulder. Their weight L1 jump is.680784 over10.460mm. The old failure source, counterfactual skin and thresholds remain unchanged. Negative rest-normal cosine here means the triangle rotated more than90° relative to rest; it is not an exhaustive inversion or selfintersection proof.

`ACTUAL-WORST-WITNESSES.json` retains the top five measurements per metric with exact sample time, triangle/vertex IDs, rest/posed coordinates, named weights, compartment labels and edge lengths. No pixels or models were generated.

## One reasoned candidate, PREPARED/HELD

`harmonic_weight_candidate_v4.py` prepares one positive surface-graph Dirichlet solve. Existing source-position seam classes share weights; conductance is inverse actual source-edge length. It introduces no Euclidean links between disconnected surfaces. Each exclusive limb domain has body-valued boundary vertices. No boundary keeps an old moving mix, and another limb cannot diffuse into it. Actual proximal/lower-link handle bands and original rigid annotated hoof handles guide interpolation; every region uses at most body+proximal+lower+own-hoof controls. The proposed body/domain/handle values are explicit reconstructed choices, not anatomical measurements. Positive harmonic fields provide discrete graph continuity; they do not establish good deformation before the actual skin screen.

This directly addresses the measured whole-link semantic error, cross-compartment leakage and retained-weight cutoff. It preserves the26 pivots/rest/inverse binds, all original geometry/indices/materials/maps and the exact240mm stride/1.6s source poses. No old native clips are inherited. Head/neck/tail source weights outside limb domains are retained; leaked limb influences outside solved domains become body influences. All existing contact/chain/loop/edge/area/normal/ground/seam thresholds remain fixed. Neutral position parity additionally uses the prior1µm threshold.

`prove_walk_weight_v4_HELD.py` is a source-only adaptation of the frozen native CPU reader. It refuses to run without an exact source-pinned `RELEASE.json`. Only `RELEASE-TEMPLATE-HELD.json` exists. It must not execute until root releases one≤15s nice19/math1 pass after the active gate closes. No numeric candidate solve, skin evaluation, export, render, or candidate PASS has occurred. An initial source-only syntax typo was caught by AST parsing and corrected before any execution; its failure note is preserved.

The candidate can fail handle coverage, matrix residual, neutral parity or the unchanged skin screens. Any such failure must remain a failure, with no parameter/threshold/stride tuning retry in this parcel. Actual serialization, GLTFLoader/Mixer, proper whole-body/hoof contact and selfcollision, start/stop/turn/slope, hitch/team/riding and photographic/anatomical acceptance remain open.

## Rights and lineage

Original **Horse by sevketkabatas**, CC BY4.0: https://sketchfab.com/3d-models/horse-53a6eb7ccf054aa2a378dd7ec08f88fe , unchanged original SHA41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988. Immutable reconstructed bind-study SHA03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36. Prior hierarchy reference **Rigged Mid-Poly Horse by antemeossa**, CC BY4.0: https://sketchfab.com/3d-models/rigged-mid-poly-horse-fea999c1d8d64eb4a9c2bb1fac1e7d83 , SHA51ab71106472321b565a47aabe281235e2c0801804bcee7694f729192913e22c. This parcel adds new diagnostic arithmetic and a reconstructed weight-source proposal; no donor motion arrays/geometry were copied. Both credits/licenses and derivative changes must accompany any future derived asset. Prior full source/license evidence remains frozen in the acquisition and first-rig packets.
