V4 actual result supersedes PREPARED/HELD status for this ONE released run.

Root released the pinned candidate after primary gate CLOSED/copied20:31:59. One nice19/math1 process under15s wall cap completed2.660430s, exit2, all owned processes closed. No retry or source/threshold/gait tuning followed. Earlier prepared capsule7d0f709b and original manifests remain unchanged.

Actual positive surface-graph solve:7,524 source-position classes,22,499 actual source edges; maximum residual4.62e-14. No multiple-limb-compartment weight per vertex; neutral position delta9.5234e-8m (<prior1e-6m limit). The unchanged65poses evaluated751,140 full vertex position/normal samples and all14,986triangles perpose. Stance, exactloop, rigidchain, finite, ground and seam controls retain their passing numerical results.

Actual body skin FAIL:edge ratio0.403417–4.681328; area ratio0.020151–4.726535; five maximum simultaneous rest-relative triangle normal-dot negatives. Smooth positive graph interpolation alone does not guarantee acceptable nonlinear posed skin shape. No accepted candidate, exported clip, anatomical/photographic result or app/live walk. Raw solve receipt/skin receipt/terminal preserve this failure. Further source work requires new review and authorization; do not retune/execute this candidate.
