HELD one original MOBILE caller release; no execution. Caller9b7325cd/wrapperd706e244 remain unchanged at /workspace/shared/HORSE-IDLE-YARD-SMOKE-PREPARED-20261022. Sourcefde6/tree8da/c255 and all29expected input pins verified. Root must release one separately copied JSON after the activecarriageproducer closes; no browser/fullgate now.

Use original caller and same15s/1.5ownedsecond criterion, same390x780/DPR2coarse context, initialLight/nearLightnoGLB-or-idlefetch, explicitBalancedload, exact mobilecameras, .97allindexedframing, four finitecontact minima1mm/no samplepenetration, actual12tri864Bcache under32/4096caps, coarseoriginal-arraynull/indexempty, unchangedbudget/card/confidence/ownedidleretirement assertions. No keepgeometry. No criterion relaxed and no desktopFAILrelabelledPASS. No diagnosticV2 hook in this original mobilecaller.

After explicit rootrelease, one fresh-output command:

    python3 /workspace/shared/HORSE-IDLE-YARD-SMOKE-PREPARED-20261022/run_owned.py \
      --lane-released --phase yard-mobile \
      --release-file /workspace/shared/HORSE-IDLE-MOBILE-ORIGINAL-ROOT-RELEASED-20261022.json \
      --output-dir /workspace/shared/HORSE-IDLE-MOBILE-ORIGINAL-ACTUAL-20261022

Whole360s/execution350s ownedcleanup and exact old15s wait remain. Preserve everyfail/PNG/terminal; no automatic retry. Original desktop bound failed, V2 independently proved actualproductionclock arithmetic correct under3slow renderedframes; those are separate facts, not mobile/performance/photographic acceptance.
