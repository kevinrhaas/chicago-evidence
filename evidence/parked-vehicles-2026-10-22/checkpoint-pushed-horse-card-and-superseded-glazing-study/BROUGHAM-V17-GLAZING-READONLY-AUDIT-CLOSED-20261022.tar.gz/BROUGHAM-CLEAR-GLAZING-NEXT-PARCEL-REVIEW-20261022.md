# Next visible carriage parcel: clear cabin glazing

Read-only review of actual V17 desktop/mobile detail and full-quarter images. This is a proposed follow-up after PR1213 lands unchanged. No candidate, producer run, browser, app edit or acceptance claim is included.

## Why this parcel

The existing front and door panes read as broad pale-grey panels, especially in the desktop near detail. The 1893 Studebaker catalogue plate0095 depicts the door as glazed, with people/background visible through it. Improving that large visible surface should contribute more than another small hardware detail.

Primary reference: `data/sources/studebaker_1893_illustrated_souvenir.json`, Studebaker Brothers, Illustrated Souvenir (1893), Library of Congress copy, https://archive.org/details/illustratedsouve00stud . Plate identity/hash is pinned in `tools/transport/brougham/parameters.json`: scan0095, SHA256 b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe. This is a period lithograph, not a calibrated photograph or an optical-material measurement.

Reviewed evidence: `/workspace/shared/brougham-v15-v17-rear-quarter-native-source8-HELD-20261022/actual/{desktop,mobile}-v17-source-{detail,fullquarter}-near100.png`. The unaltered full plate is `/workspace/shared/brougham-v11-v12-largeforms-preview8-HELD-20261022/fixture/transport/v12/plate0095.jpg`.

## Exact bounded ownership

Producer root: `/tmp/chicago-covered-sag/chicago/4d`.

* `tools/transport/brougham/generate.py`: two `side_door_glass` instances (around line182), one `front_glass` (around line255), current material5 (around line413), and document `extensionsUsed` declaration.
* Existing material5 is blue-grey `[.38,.49,.50,.25]`, roughness .10, alpha BLEND. It is shared with `lamp_glass`; do not silently change the lamps.
* Preserve all part POSITION/NORMAL streams and shapes, including the current9mm pane solids, window profiles/divisions, body affine, roof, door and interior. Preserve transforms, sockets, silhouette, wheel/step/pole contacts and all placement data.
* Preserve `rear-quarter.json`, `quarter_surface.py` and opaque quarter material6 exactly. The plate does not adjudicate that quarter as glass, curtain or lining.

## One predeclared physical-glass candidate

Add a separate recipe block in `tools/transport/brougham/parameters.json` for the three cabin panes only, and consume it in `generate.py`; clone a distinct material rather than editing shared lamp material5. Proposed optical reconstruction, not historical measurements:

* Name `reconstructed_cabin_clear_glass`; white baseColor `[1,1,1,1]`; metallic0; roughness .04.
* `KHR_materials_transmission.transmissionFactor: 1`; `KHR_materials_ior.ior: 1.52`; alpha OPAQUE, rather than pigment-like alpha BLEND. Register both used extensions.
* No tint, absorption, dirt, invented waviness, image decal or added volume thickness. The current geometric pane thickness remains an explicitly unmeasured reconstruction. Do not claim restoration of attested1893 optical properties.

Physical transmission preserves Fresnel surface reflection while allowing the empty cabin/background to read through the windows. These values are one bounded starting proposal, not a tuning loop or accepted result. Lamps retain material5; quarter remains material6. A new cabin material creates one additional body material batch; account for its actual mesh/node/draw and transmission-resource cost rather than pretending counts are unchanged.

## Shadow behavior that belongs to the same parcel

`renderers/web/js/parked-transport.js:55` currently makes every static material batch cast and receive shadows. The isolated source fixture's `demo.js` likewise sets every mesh to castShadow=true. Untextured alpha glass therefore participates as an opaque shadow caster with the default depth material; current source code supplies no glass-specific transmission shadow solution.

For this pane-only material, disable opaque shadow casting in both the source comparison and eventual app integration. Do not disable shadows on the cabin frame/body or lamp material. This is an explicit approximation to light through clear glass, not simulated refracted caustics. Keep receiving behavior initially unchanged. No lighting, exposure, background or camera change belongs to this parcel.

## Acceptance after PR1213, not a condition of that PR

1. Produce one fresh source-only candidate outside the app, preserving V17 baseline and all original evidence. Confirm exact per-part POSITION/NORMAL and transform equality, unchanged contacts, lamp material and opaque quarter; only the three pane material assignments and their optical recipe may differ.
2. Compare the same desktop/mobile source-detail and full-quarter near100 views at the existing native indexed-near stream, fixed camera hypothesis, original floor/lights/exposure and source crop. The panes should read clear with retained frames and subtle surface reflection; no pale diffuse slab, missing cabin wall, lost window or false see-through quarter. Do not add the catalogue occupants to make the comparison resemble the plate.
3. Inspect a front-oblique and side view of the empty cabin to catch transmission ordering, duplicate faces and inside-view failures. In the eventual1904 parked app view, check windows against actual street/background geometry and preserve the parking contacts. Fixed-source fixtures alone cannot establish app appearance.
4. Record actual before/after images and material/resource costs. Run the normal relevant checks only when integration is authorized; transmission's extra render target/pass must fit the real budget. Reject or hold the candidate if it does not visibly improve the carriage. No photographic-completion claim before actual reviewed images.

No geometry, source, application, workflow or ticket files were changed during this review.

## Follow-up causal audit: physical-transmission first candidate superseded

The proposed KHR transmission candidate above is SUPERSEDED and NOT AUTHORIZED. A single authorized read-only triangle audit completed in0.046s, exit0, with native-math threads1 and nice19. Script: `/workspace/shared/brougham-v17-pane-ray-audit-20261022.py`; actual evidence: `/workspace/shared/brougham-v17-pane-ray-audit-ACTUAL-20261022.json`. Frozen V17 fixture GLB SHA256 ec2bfc0da49b570429dbcd8db39250aa6f1bbf55587570f0dafad9a42afc4ee5;33,502 triangles. No source or candidate changed.

Ten rays use the existing source-camera origin/basis and points within the actual front/door apertures. This is a sparse exact-geometry audit, not a pixel mask or optical render:

* Three forward side-window rays at producer z+.12, y1.42/1.58/1.71 cross the near and opposite glazed door, then open background: no opaque triangle intersects either face of the entire ray. Example y1.58: near glass189.3387888m, far glass190.5598805m from camera.
* Four front-window rays cross front glass, opposite side glass, then open background; one additionally crosses the lamp glass in front. No opaque triangle blocks these samples.
* Three rear side-window rays at z−.23 cross near glass, then the opposite original `rear_quarter_panel`, ~1.211m farther along the ray. Example y1.58: near glass189.4035760m, opposite wall190.6148978m, position[-.585,1.7620696,-.4562457]. This is actual far-side quarter geometry, not a sheet incorrectly filling the door aperture. Preserve it.

Therefore the broad forward pale areas are tinted alpha glass over the fixture's uniform pale background; they are not an opaque hidden door/interior insert. The rear-looking region legitimately contains an opposite wall. Exact pixel contributions from lighting/shadow and transparency remain unmeasured. Two visible .25-alpha pane surfaces yield background throughput .75²=.5625 in the simple blend equation, so two-window views can have substantial diffuse tint even without any opaque wall. The pinned GLTFLoader already sets `depthWrite=false` for BLEND (lines3618–3623); this is not a missing depth-write flag.

### Existing architecture argues against introducing transmission casually

`renderers/web/js/glass.js` documents T2109: the existing Glessner transmission pass cost about half the1904 landing frame in still-frame measurements. It supplies cheaper clear alpha/dark options; T2183 makes dark the default on every tier. Its clear approximation deliberately keeps no transmission, blended panes and depthWrite=false. `parked-transport.js` does not call `cheapenGlass`; a new transmissive carriage material would therefore bypass that existing accommodation. Do not reuse house-specific blind/backing/waviness shaders on a carriage.

Pinned Three0.185.1 `three.module.js:17747` invokes `renderTransmissionPass` whenever any transmissive object is visible. At18035 onward the pass renders ALL visible opaque objects into a full-viewport target (default `transmissionResolutionScale=1`, at least4 samples, mipmaps), then the ordinary scene renders again. Stats reset before both passes, so those extra triangles/calls are counted. It does not merely redraw the small carriage. If current triangle count is D and the visible opaque subset O, the new frame is approximately D+O (less any small saved glass-shadow work), not automatically exactly2D; shadows/transparent geometry need not be duplicated.

Historical source-code budget examples, NOT new measurements: main.js records full Glessner4,274,524 against4,600,000 (325,476 spare), and balanced West prairie2,607,952 against2,625,000 (17,048 spare). An added opaque pass larger than those spare counts would exhaust those respective historical margins. At the all-opaque upper bound these examples would approach8,549,048 and5,215,904 triangles. Lowering transmission target resolution reduces pixel cost, not triangle/call statistics. Current exact margins require actual authorized app evidence; no gate was run here.

### Revised first bounded experiment

Retain the existing alpha approximation and all geometry. The next visual evidence is ordinary1904 app views of unchanged PR1213: a real street/background may already make these panes read correctly. Only if that evidence supports it, a future pane-only removal of opaque shadow casting is a bounded hypothesis; isolate panes from lamps and compare under unchanged conditions when separately authorized. This has no whole-scene transmission pass. No shadow candidate or new optical number is accepted or authorized by this audit. Do not remove the legitimate opposite quarter wall or change the opaque rear quarter. PR1213 remains frozen and lands first.
