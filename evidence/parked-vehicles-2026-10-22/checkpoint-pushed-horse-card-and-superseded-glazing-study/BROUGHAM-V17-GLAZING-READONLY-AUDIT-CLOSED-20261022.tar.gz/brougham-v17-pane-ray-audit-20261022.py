"""Read-only frozen-GLB ray audit; no rendering or candidate changes."""
import hashlib,json,struct,time
from pathlib import Path
import numpy as np
start=time.monotonic()
root=Path('/workspace/shared/brougham-v15-v17-rear-quarter-native-source8-HELD-20261022/fixture/transport/v17')
blob=(root/'brougham.glb').read_bytes();jl,jt=struct.unpack_from('<II',blob,12)
doc=json.loads(blob[20:20+jl]);bl,bt=struct.unpack_from('<II',blob,20+jl);buf=memoryview(blob)[28+jl:28+jl+bl]
def accessor(i):
 a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];off=v.get('byteOffset',0)+a.get('byteOffset',0);item=np.dtype(dt).itemsize
 return np.ndarray((a['count'],n),dtype=dt,buffer=buf,offset=off,strides=(v.get('byteStride',n*item),item)).copy()
parent={c:i for i,n in enumerate(doc['nodes']) for c in n.get('children',[])};world={}
def matrix(i):
 if i in world:return world[i]
 n=doc['nodes'][i]
 if 'matrix'in n:m=np.array(n['matrix']).reshape((4,4),order='F')
 else:
  x,y,z,w=n.get('rotation',[0,0,0,1]);m=np.eye(4);m[:3,:3]=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])@np.diag(n.get('scale',[1,1,1]));m[:3,3]=n.get('translation',[0,0,0])
 world[i]=matrix(parent[i])@m if i in parent else m
 return world[i]
tris=[];mats=[];labels=[]
for ni,node in enumerate(doc['nodes']):
 if 'mesh'not in node:continue
 for primitive in doc['meshes'][node['mesh']]['primitives']:
  p=accessor(primitive['attributes']['POSITION']);indices=accessor(primitive['indices']).reshape(-1) if 'indices'in primitive else np.arange(len(p));t=p[indices].reshape(-1,3,3).astype(float);m=matrix(ni);t=t@m[:3,:3].T+m[:3,3];mat=primitive.get('material',0)
  names=np.full(len(t),node['name'],dtype=object);frame=doc['nodes'][parent[ni]]['name']
  for part in doc['extras']['parts']:
   if part['frame']==frame and part['material']==mat:
    a=part['triangle_start_in_batch'];b=a+part['triangles'];assert b<=len(t);names[a:b]=part['name']
  tris.append(t);mats.extend([mat]*len(t));labels.extend(names.tolist())
t=np.concatenate(tris);mats=np.array(mats);labels=np.array(labels);v0=t[:,0];e1=t[:,1]-v0;e2=t[:,2]-v0
hyp=json.loads((root/'camera-hypothesis.json').read_text());origin=np.array(hyp['fit']['basis']['towardCamera'])*hyp['fit']['distance_m'];shape=doc['extras']['parameters']['body_vertical_affine'];aff=lambda y:y*shape['scale_y']+shape['offset_y_m']
targets=[(f'side_z{z}_y{y}',[.609,aff(y),z])for z in [.12,-.23]for y in [1.42,1.58,1.71]]+[(f'front_x{x}_y{y}',[x,aff(y),.2595])for x in [-.25,.25]for y in [1.45,1.70]]
rows=[]
for name,target in targets:
 d=np.array(target)-origin;d/=np.linalg.norm(d);h=np.cross(np.broadcast_to(d,e2.shape),e2);det=np.einsum('ij,ij->i',e1,h);valid=abs(det)>1e-12;inv=np.zeros(len(t));inv[valid]=1/det[valid];s=origin-v0;u=inv*np.einsum('ij,ij->i',s,h);q=np.cross(s,e1);v=inv*(q@d);dist=inv*np.einsum('ij,ij->i',e2,q);mask=valid&(u>=-1e-8)&(v>=-1e-8)&(u+v<=1+1e-8)&(dist>0);ids=np.flatnonzero(mask);ids=ids[np.argsort(dist[ids])];hits=[]
 for i in ids:
  hits.append({'triangle':int(i),'distance_m':round(float(dist[i]),7),'material':int(mats[i]),'part':str(labels[i]),'front_facing':bool(det[i]>0),'point_m':(origin+dist[i]*d).round(7).tolist()})
 fronts=[h for h in hits if h['front_facing']];first_opaque=next((h for h in fronts if doc['materials'][h['material']].get('alphaMode','OPAQUE')!='BLEND'),None)
 rows.append({'target':name,'point_m':target,'first_front_facing':fronts[0]if fronts else None,'first_opaque_front_facing':first_opaque,'ordered_intersections':hits})
out={'kind':'actual frozen V17 triangle-order audit; no raster/optical acceptance','glb_sha256':hashlib.sha256(blob).hexdigest(),'triangles':len(t),'camera_position_m':origin.tolist(),'materials':doc['materials'],'samples':rows,'elapsed_seconds':time.monotonic()-start}
path=Path('/workspace/shared/brougham-v17-pane-ray-audit-ACTUAL-20261022.json');path.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'output':str(path),'glb_sha256':out['glb_sha256'],'triangles':len(t),'elapsed_seconds':out['elapsed_seconds'],'samples':[{'target':r['target'],'first':r['first_front_facing'],'first_opaque':r['first_opaque_front_facing']}for r in rows]},indent=2))
