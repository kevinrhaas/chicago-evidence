Adds one reconstructed horse in the 1835 Western Hotel wagon yard, using a licensed textured development model and a gentle source-derived head/tail idle. The individual, breed and owner remain unidentified. The original model and attribution are preserved. Full/Balanced load it lazily; Light keeps no horse model or idle player. A small retained yard-support cache permits grounding after coarse-device CPU geometry release.

The selection card now identifies the horse as reconstructed and keeps the modern 2021 author/license credit outside historical confidence grades. Its production adapter/popup regression retains citations and rejects the former false historical attestation. Model, idle, placement, support and non-card consumer logic are unchanged by this repair.

Validation at pushed `a086cd7dab31935f52adcb1ca8494a12726f9f27` (tree `4eda1bf9303d1d968fffeb2f686396637a513b3c`, normal merge of exact DEV `824957fe`):

- Full preflight passed **1,049 checks, including 381 self-tests**, with required readers and unchanged source. All terminal logs were preserved.
- Actual-commit changelog/ID checks, normal publication and mirror checks passed. The published card helper, consumer, idle adapter, sidecar and selected model match their source bytes. The worktree is clean and the remote branch head is verified.
- The focused own-card check passes against the real adapter and popup lead, including controls for the old false-attestation defect and a missing modern citation.

Earlier browser evidence remains labeled pushed `fde6bc317`; protected model/idle/placement/support and non-card runtime bytes are unchanged:

- The unchanged original mobile yard caller passed head/tail movement, zero drift of four annotated hoof patches, reduced-motion/confidence-hidden pause, coarse array release, selection and disposal. Three images were reviewed; the quarter camera is partly occluded by the real fence. That run exposed the card defect repaired here.
- Desktop model/framing/budget/finite-contact checks passed. Both original desktop 15-wall-second/1.5-owned-second checks **failed** and remain failed. Diagnostics show exact source-clock accounting under three slow software-rendered frames; independent review identifies that bound as a private caller heuristic. Later desktop product checks were not completed. No desktop performance qualification is claimed.

**Still draft:** the repaired card and final integrated world need bounded published browser verification; live-DEV integration/CI remains separate from the exact validated base above. This horse feature has no technical dependency on person PR #1175. T-2800/T-2803 remain open for photographic refinement, actual locomotion, fitted gear and interaction. Anatomy, eyes, solid mane/tail and the 1K coat remain visible limits. No walking, hitching, riding, photographic-master, whole-ticket or merge clearance is claimed.
