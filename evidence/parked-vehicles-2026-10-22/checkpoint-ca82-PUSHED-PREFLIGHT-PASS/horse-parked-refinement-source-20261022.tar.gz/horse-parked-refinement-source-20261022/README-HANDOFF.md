# T-2800 parked horse source draft — frozen, not executed

This is a small original CC0 croup/trunk authoring proposal against the **installed** horse producer, not an update to any outside-app head/mouth/neck candidate. Do not apply it before fresh matched baseline views and explicit release of the local heavy lane. T-2800 is still open/unclaimed; T-2799 is the research/spec prerequisite. No app, ticket, Git, mirror or CI output was changed.

## Exact installed producer

`INSTALLED-PRODUCER-MAPPING.json` independently matches all four current hashes to the committed historical `head-neck-refinement/trot-inputs.json` and `regeneration.json`. The latter records two identical rebuilds and equality to the installed output. Copies are included under `producer-evidence/`. This proves the existing recorded association; **a fresh source replay has not run in this task**.

- Geometry producer `tools/transport/horse_geometry.py`: `d0dd08076180e9964648ff19b8eb8e2271f63c3abefae18f5122269e0f3f95db`.
- Skin wrapper `tools/transport/generate_horse.py`: `890ddda0852b2fd0714ceb19fa08d2b6defffe65c705b62493fb06ac69ec2791`.
- Parameters `data/transport/studies/horse.json`: `0c10cfcfc536e7a6eb657756c84dfc3b45d8c5268f559996696ab681d800be01`.
- Installed GLB `renderers/web/transport/horse/equine_light_harness_skinned_prototype_01.glb`: **715,316 B**, **14,172 triangles**, 6 materials, 15 joints; SHA256 `89b048b7cda748e6f3a7111aa8e4f3198b01fabf6015cae644c78ed02d385bc6`. Counts were decoded anew without generation/browser.

## Proposed visible correction

The current source pinches the rear torso into a small end section whose top is 1.23 m, below the unchanged 1.38 m tail frame. Raise that rear section center by 80 mm and its vertical radius by 35 mm, with a 15 mm width increase; the section top becomes 1.345 m. Raise the next rear section center by 20 mm and widen it by 10 mm. These are authored, bounded reconstruction values, **not measurements read from a photograph**. The croup maximum control (1.52 m), barrel, withers, shoulder and four neck controls remain unchanged.

Fair only the trunk intervals using component-wise shape-preserving cubic interpolation. Original knots remain exact and inserted coordinates remain inside each source interval. This rounds the croup-to-barrel transition and reduces the broad angular back/belly silhouette. The proposed source has 25 body/neck rings instead of 10: predicted +360 vertices / +720 triangles, no new materials/textures. Actual exported cost is unmeasured. Exact 24-vertex neck interface and its band are located from the final ring count, preserving their original position values. All source after `head=node(...)` is byte-identical: no head/ear/muzzle, mane/tail, limb, joint, clip, contact or socket authoring change.

**Do not mistake fairing for anatomical completion.** This draft intentionally does not pretend the primitive limb chains are anatomically correct. Their 0.65 m upper and 0.55 m lower links collapse several biological segments; scapula/humerus/radius, pelvis/femur/tibia and corresponding joints need the fuller T-2799 rig contract before believable motion. Continuous shoulder/hindquarter-to-limb topology, face, eyes, mouth, hooves, body surface definition, hair, UV/PBR and LODs remain open. Preserving those anchors for a small static diagnostic is an integration precaution, not approval of their proportions.

## Actually viewed reference bounds

- `vassil_2014_konik_horse_anatomy`: CC0 modern side view, `/workspace/shared/horse-reference-2026-10-21/Konik Polski Solutré 26102014 4 (cropped).jpg`. Its continuous rounded rump/tail-dock transition and broad muscular quarter support the **qualitative** target. This stocky Konik is not a selected historical Chicago breed or the exact body to copy. No pixel distance was promoted to metres; no matched camera has yet been solved.
- `ellenberger_baum_dittrich_equine_plates`: public-domain posterior Tafel 12 figs 8/9, `/workspace/shared/horse-reference-2026-10-21/Horse anatomy posterior view.jpg`, actually viewed. It distinguishes the hip/upper thigh musculature from the lower limb, exposing the current generic tube limitation. The plate does not directly determine this profile reconstruction's numerical controls.
- `seton_1892_equine_skeleton` and the T-2799 approved anatomy register remain the next skeletal authority. No breed, date-specific coat or individual identity is inferred from the anatomy images.
- Historical saved screenshots were inspected as diagnostics: `horse-skinned/desktop-idle.png` is an older render with 27,746 displayed triangles; the Oct21 static coat comparison uses outside 419a. **Neither is fresh appearance proof of installed 89b048.** Fresh views below must precede candidate generation.

See `REFERENCE-PINS.json` for exact viewed-image hashes and source IDs. No uncertain-license picture/mesh was used. Proposal code/license: project-authored CC0-1.0, preserving the canonical source license.

## Ready next command: baseline only

After root releases the lane, this command serves the existing installed source tree and captures **side and three-quarter, idle phase 0**, at 1280×800 and 390×780. It checks exact served GLB SHA, records actual cameras/contacts/manifest/render counters and page/network errors, and refuses an existing output directory. It does not generate a model or mutate app files.

```sh
node /workspace/shared/horse-parked-refinement-source-20261022/capture_installed_baseline.mjs --lane-released --output-dir /workspace/shared/horse-installed-baseline-20261022-first
```

The script has passed syntax review only; Playwright launch and captures are **UNRUN**. `--lane-released` is an execution guard for the colleague running it, not evidence that the lane is actually free. Desktop/mobile renderer counters include ground/shadow draws and are not standalone model counts or a frame performance benchmark. Review all four actual frames, then choose or amend the bounded croup change against those frames. Do not execute an old study's capture/source chain.

## After fresh baseline review

1. Copy exact installed `generate_horse.py`, `horse_geometry.py` and `horse.json` into a unique outside-app replay directory. Run unmodified producer and require exact installed GLB hash above. Stop on divergence and diagnose it; do not proceed with a different baseline.
2. Only then copy the **proposed** `horse_geometry.py` into a distinct source directory beside the exact wrapper, and generate once into a new outside-app output. This draft is a one-file exact-preimage patch, `horse-trunk-source.patch`. Do not apply it to the tracked app first.
3. Decode actual output and compare protected rig/clips/sockets, lower-limb/hoof/sole arrays, head and original neck-interface/band vertices by semantic source ranges. Added trunk topology shifts offsets: whole-buffer equality is inappropriate. Record all changed normals and vertex ranges honestly. New body normals may change; protected lower-part geometry may not.
4. Capture the candidate at the same recorded cameras, phase and light. Explicitly route only the horse GLB/manifest in an isolated preview or copied fixture. Inspect actual before/after side and quarter views at both viewports. Reject unhelpful bulk, new cracks, an artificial rump or hidden regressions before expensive checks.
5. For a useful visible candidate, run finite exporter/Khronos/topology/ground-contact and **bounded idle** body versus limb/hair self-contact checks. Existing static engineering defects stay recorded; do not waive a new one as inherited. Do not start the historical 63-pose harness/SAT chain for an unmounted parked appearance trial.
6. Tack, gait, rider, photo master, LOD, memory and scene placement acceptance remain separately open. No ticket closure follows from this draft or one static improvement.

## Source checks already run

`python verify_source.py`: **14 checks PASS**. These verify source compilation, two-row-only control amendments, protected original controls/seam, shape bounds at subdivisions 2/4/7/100, positive radii/section order, identity at subdivision one and invalid-input rejection. `node --check capture_installed_baseline.mjs` passes. No GLB, collision or render is implied by those pure source checks. `SOURCE-REVIEW.json` records the exact scope and unrun gates.
