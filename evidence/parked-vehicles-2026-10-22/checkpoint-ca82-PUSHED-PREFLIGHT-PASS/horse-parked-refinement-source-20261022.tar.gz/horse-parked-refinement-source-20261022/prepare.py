from pathlib import Path
import hashlib, json, difflib, ast
root=Path('/workspace/chicago/chicago/4d')
out=Path('/workspace/shared/horse-parked-refinement-source-20261022')
rel='tools/transport/horse_geometry.py'
old=(root/rel).read_text()
start=old.index('# Barrel, croup, shoulders, rising neck')
end=old.index("head=node('head'",start)
replacement='''# Original bounded trunk contour reconstruction. Cleared modern CC0 anatomy
# informs the rounded tail-dock/croup transition only; no breed/date is inferred.
# Preserve all existing control knots except the two explicitly authored rear
# sections. The unchanged neck and head interface is still 24 vertices.
def fair_trunk_profile(rings, subdivisions=4, last_interval=4):
 # Component-wise shape-preserving cubic Hermite interpolation. Each inserted
 # coordinate stays inside its source interval; original control rows stay exact.
 if not isinstance(subdivisions,int) or subdivisions < 1:
  raise ValueError('subdivisions must be a positive integer')
 if not 0 <= last_interval < len(rings)-1:
  raise ValueError('trunk interval outside profile')
 controls=rings[:last_interval+2]
 if any(len(row)!=6 or not all(math.isfinite(x) for x in row) for row in rings):
  raise ValueError('finite six-component profile required')
 tangents=[]
 for axis in range(6):
  values=[row[axis] for row in controls]
  delta=[b-a for a,b in zip(values,values[1:])]
  def endpoint(a,b):
   value=(3*a-b)/2
   if value*a <= 0:return 0.
   if a*b < 0 and abs(value)>3*abs(a):return 3*a
   return value
  if len(delta)==1:slopes=[delta[0],delta[0]]
  else:
   slopes=[endpoint(delta[0],delta[1])]
   slopes.extend(0. if a*b<=0 else 2*a*b/(a+b) for a,b in zip(delta,delta[1:]))
   slopes.append(endpoint(delta[-1],delta[-2]))
  tangents.append(slopes)
 result=[]
 for segment in range(last_interval+1):
  a,b=controls[segment:segment+2]
  result.append(a)
  for step in range(1,subdivisions):
   t=step/subdivisions
   h00=2*t**3-3*t*t+1;h10=t**3-2*t*t+t
   h01=-2*t**3+3*t*t;h11=t**3-t*t
   result.append(tuple(h00*a[k]+h10*tangents[k][segment]+h01*b[k]+h11*tangents[k][segment+1] for k in range(6)))
 result.extend(rings[last_interval+1:])
 return result
# Rear tip y: 1.19 -> 1.27 m; width .035 -> .050 m; vertical
# radius .040 -> .075 m. Next croup y: 1.22 -> 1.24 m, width .21
# -> .22 m. These are reconstruction dimensions, not photo measurements.
# Rear top rises from 1.23 to 1.345 m toward the unchanged 1.38 m tail
# frame; the croup maximum, withers, barrel, shoulder and neck stay exact.
body_neck_controls=[(0,1.27,-.90,.050,.075,0),(0,1.24,-.78,.22,.25,0),(0,1.20,-.55,.27,.32,0),(0,1.16,-.22,.28,.35,0),(0,1.17,.10,.25,.34,-.015),(0,1.25,.34,.25,.31,-.11),(0,1.43,.47,.17,.21,-.14),(0,1.63,.65,.13,.18,-.12),(0,1.80,.70,.10,.15,-.10),(0,1.89,.78,.08,.10,-.07)]
body_neck_profile=fair_trunk_profile(body_neck_controls)
neck_join=loft('continuous_body_neck',body_neck_profile,coat,cap_end=False)
neck_interface=(len(body_neck_profile)-1)*24
D['nodes'][neck_join]['extras']={'equine_join':{'role':'neck','interface':list(range(neck_interface,neck_interface+24)),'band':list(range(neck_interface-24,neck_interface)),'head_weight':.25}}
'''
new=old[:start]+replacement+old[end:]
ast.parse(new)
p=out/'proposed'/rel;p.write_text(new)
(out/'horse-trunk-source.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
sha=lambda b:hashlib.sha256(b).hexdigest()
pins={rel:{'preimage_sha256':sha(old.encode()),'proposal_sha256':sha(new.encode())}}
for rel2 in ['tools/transport/generate_horse.py','data/transport/studies/horse.json','renderers/web/transport/horse/equine_light_harness_skinned_prototype_01.glb']:
 pins[rel2]={'input_sha256':sha((root/rel2).read_bytes())}
(out/'INPUT-PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'prepared_source':str(p),'pins':pins},indent=2))
