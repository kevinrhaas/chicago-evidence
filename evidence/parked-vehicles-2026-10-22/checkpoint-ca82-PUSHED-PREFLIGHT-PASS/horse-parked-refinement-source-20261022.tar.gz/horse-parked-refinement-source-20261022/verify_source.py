"""Pure authoring-source review: does not run the generator or create a model."""
import ast, hashlib, json, math
from pathlib import Path
p=Path(__file__).resolve().parent
src=(p/'proposed/tools/transport/horse_geometry.py').read_text()
base=Path('/workspace/chicago/chicago/4d/tools/transport/horse_geometry.py').read_text()
module=ast.parse(src)
helper=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='fair_trunk_profile')
ns={'math':math}
exec(compile(ast.Module(body=[helper],type_ignores=[]),'<pure-trunk-helper>','exec'),ns)
f=ns['fair_trunk_profile']
assignment=next(n for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='body_neck_controls' for t in n.targets))
controls=ast.literal_eval(assignment.value)
profile=f(controls)
oldcall=next(n.value for n in ast.parse(base).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='neck_join' for t in n.targets))
old=ast.literal_eval(oldcall.args[1])
checks={}
checks['source_compiles']=True
checks['profile_25_rings']=len(profile)==25
checks['all_original_authored_knots_exact']=all(profile[i*4]==controls[i] for i in range(6)) and profile[21:]==controls[6:]
checks['only_two_original_control_rows_amended']=[i for i,(a,b) in enumerate(zip(old,controls)) if a!=b]==[0,1]
checks['all_four_neck_rows_exact']=profile[-4:]==old[-4:]
checks['barrel_withers_shoulder_controls_exact']=controls[2:]==old[2:]
checks['preserved_24_vertex_join_and_band']=profile[-2:]==old[-2:] and (len(profile)-1)*24==576
# Independent dense sample: each inserted component remains in each knot interval.
bounded=True
for subdivision in [2,4,7,100]:
 dense=f(controls,subdivisions=subdivision)
 for interval in range(5):
  for row in dense[interval*subdivision:(interval+1)*subdivision+1]:
   for axis in range(6):
    low,high=sorted((controls[interval][axis],controls[interval+1][axis]))
    bounded &= low-1e-12<=row[axis]<=high+1e-12
checks['component_bounds_no_spline_overshoot']=bounded
checks['radial_extents_positive']=all(row[3]>0 and row[4]>0 for row in profile)
checks['forward_section_order_preserved']=all(a[2]<b[2] for a,b in zip(profile,profile[1:]))
checks['identity_when_subdivision_one']=f(controls,1)==controls
checks['source_before_and_after_proposal_identical']=base[:base.index('# Barrel, croup, shoulders, rising neck')]==src[:src.index('# Original bounded trunk contour reconstruction')] and base[base.index("head=node('head'"):]==src[src.index("head=node('head'"):]
failures=[]
for args in [(controls,0),(controls,1.5),(controls,4,9),([[0,0,float('nan'),1,1,0]]*2,4,0)]:
 try:f(*args)
 except ValueError:continue
 failures.append(args)
checks['invalid_input_negative_controls_reject']=not failures
# Source ring radii only: no GLB, contact or visible-anatomy conclusion.
checks['root_and_hair_frames_unchanged_by_source_suffix']=checks['source_before_and_after_proposal_identical']
result={'status':'PASS' if all(checks.values()) else 'FAIL','scope':'pure authoring-source checks; no generator/model/geometry/collision/browser run','checks':checks,'counts':{'old_trunk_rings':len(old),'proposed_trunk_rings':len(profile),'extra_vertices_source_prediction':15*24,'extra_triangles_source_prediction':15*24*2},'reconstructed_delta_m':{'rear_section_center_y':controls[0][1]-old[0][1],'rear_section_top_y':controls[0][1]+controls[0][4]-old[0][1]-old[0][4],'next_section_center_y':controls[1][1]-old[1][1]},'explicitly_unrun':['actual generator','decoded GLB','Khronos','self/interpart penetration','matched browser captures','motion','tack fit','photographic acceptance']}
(p/'SOURCE-REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
