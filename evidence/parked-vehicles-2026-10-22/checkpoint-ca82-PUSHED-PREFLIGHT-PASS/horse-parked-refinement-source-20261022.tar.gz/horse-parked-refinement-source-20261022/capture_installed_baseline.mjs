// SPDX-License-Identifier: CC0-1.0
// UNEXECUTED preparation. Run only after root releases the local heavy lane.
import {createServer} from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root='/workspace/chicago/chicago/4d/renderers/web';
const horse='transport/horse/equine_light_harness_skinned_prototype_01.glb';
const want='89b048b7cda748e6f3a7111aa8e4f3198b01fabf6015cae644c78ed02d385bc6';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const args=process.argv.slice(2);
if(args.length!==3||args[0]!=='--lane-released'||args[1]!=='--output-dir')throw Error('After root lane release only: --lane-released --output-dir <new-directory>');
const out=path.resolve(args[2]);
const bytes=await fs.readFile(path.join(root,horse));
if(bytes.length!==715316||sha(bytes)!==want)throw Error('Installed baseline changed; stop and reassess pins');
await fs.mkdir(out,{recursive:false});
const receipt={status:'RUNNING baseline appearance capture only',installed_glb_sha256:want,installed_glb_bytes:bytes.length,views:[],errors:[],responses:[],capture_source_sha256:sha(await fs.readFile(new URL(import.meta.url))),not_qualified:['anatomy','photographic quality','new geometry','tack','motion','riding']};
let browser,server;
try{
 const mime={'.html':'text/html','.js':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.png':'image/png'};
 server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://localhost');
   const name=decodeURIComponent(url.pathname).replace(/^\/+/, '');
   let file=path.resolve(root,name);
   if(file!==root&&!file.startsWith(root+path.sep))throw Error('Invalid path');
   if((await fs.stat(file)).isDirectory())file=path.join(file,'index.html');
   const body=await fs.readFile(file);
   if(file===path.join(root,horse)){
    if(sha(body)!==want)throw Error('Race: served baseline hash changed');
    receipt.responses.push({url:url.pathname,sha256:sha(body),bytes:body.length});
   }
   res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'});res.end(body);
  }catch(e){res.writeHead(404);res.end('Unavailable');}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 let pw;
 try{pw=await import('playwright');}
 catch{const globalRoot=execFileSync('npm',['root','-g'],{encoding:'utf8'}).trim();pw=await import(path.join(globalRoot,'playwright/index.js'));}
 const chromium=pw.chromium||pw.default?.chromium;
 if(!chromium)throw Error('Playwright Chromium unavailable; no install attempted');
 browser=await chromium.launch({headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const origin=`http://127.0.0.1:${server.address().port}`;
 for(const viewport of [{width:1280,height:800},{width:390,height:780}]){
  const page=await browser.newPage({viewport,deviceScaleFactor:1,reducedMotion:'reduce'});
  page.on('pageerror',e=>receipt.errors.push(String(e)));
  page.on('response',r=>{if(r.status()>=400&&!r.url().endsWith('/favicon.ico'))receipt.errors.push(`HTTP ${r.status()} ${r.url()}`);});
  await page.goto(origin+'/transport/horse/',{waitUntil:'networkidle',timeout:45000});
  await page.waitForFunction(()=>window.fixture?.ready,null,{timeout:30000});
  await page.evaluate(()=>{const f=window.fixture;f.pause();f.setClip('idle');f.setPhase(0);document.querySelector('#travel').checked=false;});
  for(const view of ['side','three-quarter']){
   await page.selectOption('#view',view);
   await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   const evidence=await page.evaluate(()=>{const f=window.fixture;return{pose:{clip:'idle',phase:0},camera:{position:f.camera.position.toArray(),quaternion:f.camera.quaternion.toArray(),projection:f.camera.projectionMatrix.toArray()},renderer:{draw_calls:f.renderer.info.render.calls,triangles:f.renderer.info.render.triangles},contacts:f.measure(),manifest:{bytes:f.manifest.bytes,triangles:f.manifest.triangles,mesh_draws:f.manifest.mesh_draws,skin_joints:f.manifest.skin_joints},stats:document.querySelector('#stats').textContent};});
   const name=`${viewport.width}-${view}.png`;
   const screenshot=await page.screenshot({path:path.join(out,name),fullPage:true});
   receipt.views.push({viewport,view,screenshot:name,screenshot_sha256:sha(screenshot),...evidence});
  }
  await page.close();
 }
 if(receipt.errors.length)throw Error('Browser errors: '+receipt.errors.join('; '));
 if(receipt.responses.length!==2||receipt.views.length!==4)throw Error('Missing loaded baseline or matched views');
 receipt.status='CAPTURED: two fixed idle views at desktop/mobile; unreviewed appearance';
}catch(e){receipt.status='FAILED baseline capture; no candidate run';receipt.errors.push(String(e.stack||e));process.exitCode=1;}
finally{if(browser)await browser.close();if(server)await new Promise(r=>server.close(r));await fs.writeFile(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');}
