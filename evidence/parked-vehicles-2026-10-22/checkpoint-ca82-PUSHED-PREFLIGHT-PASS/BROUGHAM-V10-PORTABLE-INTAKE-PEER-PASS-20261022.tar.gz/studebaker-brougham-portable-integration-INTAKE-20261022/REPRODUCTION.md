# Reproducing the portable Brougham exports

The actual successful run used Python **3.11.17**, NumPy **2.3.5**, and `gltf-validator` **2.0.0-dev.3.10**. NumPy is the producer's only nonstandard Python dependency. Use the project's configured environment; this packet does not install anything or require Blender. The independent delivery checker uses only Python's standard library.

Run the public wrapper with an output directory that **does not yet exist**. Its default output is already supplied in this packet and deliberately refuses overwrite. For example, from this packet's root, choose a fresh destination:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1   python proposed/chicago/4d/tools/transport/brougham/build_portable.py   --output /tmp/brougham-fresh-output

python proposed/chicago/4d/tools/transport/brougham/check_portable.py   --directory /tmp/brougham-fresh-output   --receipt /tmp/brougham-fresh-independent-check.json
```

The wrapper resolves source parameters, LOD recipe, generator and GPL license relative to this supplied tree and works from another current directory as well. The low-level generator is an internal helper; invoke the wrapper, which passes the correct parameter file. No byte or geometry result depends on the external output path. Repeat into another fresh directory to compare all seven output files. The raw near master must hash to `645e3a9c3dcb448469a4d9d1bd3bcbb8ffde81fddf5aa401a39e08e44e731c0e`; otherwise the build stops. Native indexing preserves each triangle's exact position/normal stream, with no quantization or external decoder.

`validate_exports.cjs` is the recorded independent validator caller. In this workspace it resolves the preinstalled validator at `/workspace/shared/transport-tools/node_modules/gltf-validator`; reproduce with that exact version and deliberately update only the dependency selector if another environment locates it elsewhere. Its arguments are the fresh output directory and a new JSON report path. A new source, toolchain or parameter change requires fresh qualification rather than editing expected hashes.

The original frozen candidate and its independent review are preserved separately as archive `e71bd0837c1eec6c578d0ebca8e1d97edcf73f7b2cc8f238f967c6205c81cc3b`. This intake copy omits the incidental `__pycache__` file and historical HELD/WIP notes. Every retained producer, data, patch, source and generated asset byte is unchanged from that reviewed candidate. The added reproduction instructions resolve the peer's nonblocking documentation note. No generation was repeated to create this intake copy, and no runtime or photographic acceptance is added.
