# SPDX-License-Identifier: GPL-3.0-or-later
"""Generate original static Brougham master and lossless-indexed near/mid/far candidates."""
from pathlib import Path
import argparse,copy,hashlib,json,math,subprocess,sys,tempfile
from index_streams import read_glb,attribute_rows,write_indexed
ROOT=Path(__file__).resolve().parents[3]
MASTER='645e3a9c3dcb448469a4d9d1bd3bcbb8ffde81fddf5aa401a39e08e44e731c0e'

def inspect(doc,binary):
    world={}
    def visit(i,parent):
        node=doc['nodes'][i]
        if any(k in node for k in ['rotation','scale','matrix']):raise ValueError('Unexpected new transform form')
        t=node.get('translation',[0,0,0]);world[i]=[parent[k]+t[k] for k in range(3)]
        for child in node.get('children',[]):visit(child,world[i])
    for root in doc['scenes'][doc.get('scene',0)]['nodes']:visit(root,[0,0,0])
    vertices=[]
    for i,node in enumerate(doc['nodes']):
        if 'mesh' in node:
            for prim in doc['meshes'][node['mesh']]['primitives']:
                for raw in attribute_rows(doc,binary,prim['attributes']['POSITION']):
                    import struct
                    p=struct.unpack('<fff',raw);vertices.append([p[k]+world[i][k] for k in range(3)])
    if not all(math.isfinite(v) for p in vertices for v in p):raise ValueError('Nonfinite source vertex')
    return world,{'min':[min(p[k] for p in vertices) for k in range(3)],'max':[max(p[k] for p in vertices) for k in range(3)]}

def main():
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('--parameters',type=Path,default=ROOT/'data/transport/parked/studebaker-brougham-parameters.json');cli.add_argument('--output',type=Path,default=ROOT/'renderers/web/transport/parked-brougham');args=cli.parse_args()
    if args.output.exists():raise ValueError('Fresh portable output directory required')
    args.output.mkdir(parents=True);tool=Path(__file__).parent;rows=[];canonical_nodes=None;canonical_materials=None;canonical_world=None
    (args.output/'LICENSE').write_bytes((tool/'LICENSE').read_bytes())
    with tempfile.TemporaryDirectory(prefix='brougham-portable-') as tmp:
        for detail in ['near','mid','far']:
            source=Path(tmp)/detail
            subprocess.run([sys.executable,str(tool/'generate.py'),'--parameters',str(args.parameters),'--detail',detail,'--output',str(source)],check=True)
            glb=source/'brougham.glb';rawsha=hashlib.sha256(glb.read_bytes()).hexdigest();doc,binary=read_glb(glb);world,bounds=inspect(doc,binary)
            if detail=='near':
                if rawsha!=MASTER:raise ValueError('Near master must reproduce the frozen actually viewed V10')
                canonical_nodes=doc['nodes'];canonical_materials=doc['materials'];canonical_world=world
                (args.output/'brougham-source.glb').write_bytes(glb.read_bytes())
            elif doc['nodes']!=canonical_nodes or doc['materials']!=canonical_materials or world!=canonical_world:raise ValueError('LOD changed node frames, materials or anchors')
            indexed=args.output/f'brougham-{detail}.glb';encoded=write_indexed(glb,indexed)
            row={'detail':detail,'file':indexed.name,'triangles':doc['extras']['statistics']['triangles'],'raw_mesh_batches':len(doc['meshes']),'parked_material_groups':len({p['material'] for m in doc['meshes'] for p in m['primitives']}),'nodes':len(doc['nodes']),'bounds_m':bounds,**encoded};rows.append(row)
        if not rows[0]['triangles']>rows[1]['triangles']>rows[2]['triangles']:raise ValueError('LOD triangle costs must strictly decrease')
        doc,_=read_glb(args.output/'brougham-source.glb')
        anchors=[]
        for i,node in enumerate(doc['nodes']):
            if 'mesh' not in node and node['name'].startswith('vehicle_'):
                anchors.append({'node_index':i,'node':node['name'],'translation_local_m':node.get('translation',[0,0,0]),'translation_root_m':canonical_world[i],'rotation_xyzw':[0,0,0,1],'scale':[1,1,1],'dynamic_binding_supported':False})
        side={'asset_id':'studebaker_1893_brougham_reconstruction_01','license':'GPL-3.0-or-later','frame':{'units':'m','up':'+Y','forward':'+Z','origin':'ground midpoint between axles'},'scene_eligibility':'1904 reconstructed empty unhitched parked example;catalogue type predates scene,particular specimen/presence/owner/stop invented','grade':'reconstructed','design_reference':{'maker':'Studebaker Brothers Manufacturing Company','type':'Brougham','date':1893,'source_id':'studebaker_1893_illustrated_souvenir','reference_sha256':'b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe','note':'Attested catalogue maker/type availability before1904;not household ownership or actual1904specimen evidence.'},'source_master_sha256':MASTER,'parameters_sha256':hashlib.sha256(args.parameters.read_bytes()).hexdigest(),'near_actual_visual_evidence':'12normal source-guided original-light V9/V10 fullvehicle views2026-10-22;leadingcurl improved,photographic/mainworld acceptance OPEN','lods':rows,'lod_runtime_selection_enabled':False,'lod_appearance_accepted':{'near_original_master_only':True,'indexed_near':False,'mid':False,'far':False},'authored_texture_bytes':0,'rendering':'Original PBR factors;no image textures;native indexing only,no meshopt/quantization. Runtime static merger groups six shared materials;actual main cost remains to measure.','wheel_contacts_root_m':[[-.67,0,-1.15],[.67,0,-1.15],[-.67,0,1.15],[.67,0,1.15]],'static_pole_ground_shoe_contact_root_m':[[-.0325,0,3.725],[.0325,0,3.725],[-.0325,0,3.825],[.0325,0,3.825]],'pole_policy':'vehicle_team_pole is pre-authored static parked-down geometry with a ground shoe. It is NOT a hinged vehicle_tongue;do not rename it or rotate around root. Actual support height/road-plane qualification required.','anchors':anchors,'unsupported_interfaces':['driver/passenger fit','door operation','boarding/disembark','hitch/team coupling','steering/wheel animation','traffic','collision/rider/camera','horse/tack binding'],'status':'Portable source/delivery candidate only;not app installed,main-ground/budget/mobile-published/LOD appearance or photographic accepted','source_history_note':'Frozen master extras retain the original pre-render V10UNRENDERED note as historical source text;this sidecar links later actual bounded comparison without rewriting the master bytes.'}
        (args.output/'brougham.json').write_text(json.dumps(side,indent=2)+'\n')
        (args.output/'BUILD-RECEIPT.json').write_text(json.dumps({'rows':rows,'near_master_reproduced_exactly':True,'all_semantic_nodes_materials_world_anchors_exact_across_lods':True,'zero_authored_textures':True,'status':'generation/indexing proof,not runtime or photographic acceptance'},indent=2)+'\n')
    print(json.dumps({'output':str(args.output),'lod_triangles':[x['triangles'] for x in rows],'lod_bytes':[x['indexed_bytes'] for x in rows]}))
if __name__=='__main__':main()
