import subprocess,pathlib,json,hashlib,struct,csv,io
from openpyxl import load_workbook
T='c0b314187a80cbcf8cc115ffeec8f400386b827e';OLD='0999c385f47b10d2410a53ca13625c9ed6b9fc8d';R='/workspace/chicago';P=pathlib.Path(__file__).parent
read=lambda p,t=T:subprocess.check_output(['git','show',t+':'+p],cwd=R);app=lambda p:read('chicago/4d/'+p);sha=lambda b:hashlib.sha256(b).hexdigest()
source=json.loads(app('assets/authored/transport/wagon_parked/SOURCE.json'));hashproof=[]
for group in ['generated_files_sha256','authored_chart_inputs_sha256']:
 for p,h in source[group].items():
  actual=sha(app(p));assert actual==h,(p,actual,h);hashproof.append({'path':p,'sha256':actual,'PASS':True})
side=json.loads(app('renderers/web/transport/parked-wagon/wagon-w01.json'))
for p,h in side['source_sha256'].items():
 prefix='tools/transport/'if p=='generate_parked_wagon.py'else'tools/transport/wagon_parked/'
 assert sha(app(prefix+p))==h,p
ref=pathlib.Path('/workspace/shared/w01-python-sum-recovery-20261022/native311-material/wagon-w01.glb').read_bytes();assert sha(ref)==source['parent_geometry_material_study_sha256']
n=struct.unpack_from('<I',ref,12)[0];g=json.loads(ref[20:20+n]);binary=ref[n+28:];base='assets/authored/transport/wagon_parked/charts/';manifest_raw=app(base+'original-w01-charts.json');manifest=json.loads(manifest_raw);payload=app(base+'original-w01-charts.bin');mapping_raw=app(base+'original-w01-charts.mapping.json');mapping=json.loads(mapping_raw);streams=[]
for batch,mesh in zip(manifest['batches'],g['meshes']):
 assert batch['name']==mesh['name'];attrs=mesh['primitives'][0]['attributes']
 for sem,width in [('TEXCOORD_0',2),('TANGENT',4)]:
  item=batch['attributes'][sem];a=g['accessors'][attrs[sem]];v=g['bufferViews'][a['bufferView']];off=v.get('byteOffset',0)+a.get('byteOffset',0);original=binary[off:off+a['count']*width*4];frozen=payload[item['byte_offset']:item['byte_offset']+item['byte_length']]
  assert original==frozen and sha(frozen)==item['sha256'];assert {k:item[k]for k in ['componentType','count','type','min','max']}=={k:a[k]for k in ['componentType','count','type','min','max']};streams.append({'batch':batch['name'],'semantic':sem,'bytes':len(frozen),'exact':True})
assert len(streams)==46
old=json.loads(pathlib.Path('/workspace/shared/w01-python-sum-recovery-20261022/native311-material/receipt.json').read_text());assert mapping['source_mapping']==old['source_mapping'] and len(mapping['source_mapping'])==158
wire=json.loads((P/'NODE-GZIP.json').read_text());assert wire['sum']==45965
changed=subprocess.check_output(['git','diff','--name-only','HEAD',T],cwd=R,text=True).splitlines();protected=[x for x in changed if x.endswith(('.glb','.png'))or x.startswith('chicago/4d/data/transport/')or x.startswith('chicago/4d/data/scenes/')or x.startswith('chicago/4d/renderers/web/js/')];assert not protected
# Read generated resident exports: exact citation/notes refresh only, no identity/adjudication changes.
prefix='chicago/reference/resident-research/T-0462/';name='T-0462_resident_research.csv';before=list(csv.DictReader(io.StringIO(read(prefix+name,OLD).decode())));after=list(csv.DictReader(io.StringIO(read(prefix+name).decode())));assert len(before)==len(after);csvdiff=[]
for i,(x,y)in enumerate(zip(before,after),2):
 for k in x:
  if x[k]!=y[k]:csvdiff.append({'row':i,'column':k,'before':x[k],'after':y[k]})
assert len(csvdiff)==2 and len({x['row']for x in csvdiff})==1
name='T-0462_resident_research_working.xlsx';wbs=[load_workbook(io.BytesIO(read(prefix+name,t)),read_only=True,data_only=False)for t in [OLD,T]];assert wbs[0].sheetnames==wbs[1].sheetnames;xldiff=[]
for sn in wbs[0].sheetnames:
 a,b=[w[sn]for w in wbs];assert (a.max_row,a.max_column)==(b.max_row,b.max_column)
 for i,(x,y)in enumerate(zip(a.iter_rows(values_only=True),b.iter_rows(values_only=True)),1):
  for j,(xx,yy)in enumerate(zip(x,y),1):
   if xx!=yy:xldiff.append({'sheet':sn,'row':i,'column':j,'before':xx,'after':yy})
kinzie=json.loads(app('data/sources/kinzie_waubun_1856.json'));assert len(xldiff)==4;assert {(x['row'],x['column'])for x in xldiff if x['sheet']=='Sources'}=={(27,5),(27,6)};assert all(x['after']==kinzie['locator'if x['column']==5 else'note']if x['sheet']=='Sources'else x['after']in[d['after']for d in csvdiff]for x in xldiff)
changelog=json.loads(app('changelog.d/T-2792.json'));assert changelog['kind']=='chore'
proof={'tree':T,'initial_tree':OLD,'scope':'Independent finite pinned-tree review. No producer/browser/fullgate/CI or tracked mutation.','verdict':'No blocking finding in requested scope','all46_original_Float32_streams_and_accessor_metadata_exact':True,'canonical_reference_sha256':sha(ref),'original_158_mapping_rows_equal_saved_author_time_receipt':True,'hash_and_source_provenance_checks':hashproof,'source_index_accounting':wire,'raw_index_bytes':161435,'raw_budget_bytes':168000,'raw_headroom_bytes':6565,'wire_budget_unchanged':120000,'wire_headroom_bytes':74035,'protected_GLΒ_PNG_recipe_scene_runtimeJS_staged_changes':protected,'generated_resident_export_changes':{'CSV':csvdiff,'XLSX':xldiff,'identity_adjudication_cells_changed':False},'chart_stream_evidence':streams,'limits':'Cross-backend wrapper/gate/CI runs are root-owned evidence, not re-executed or independently promoted by this review. App source/tier/rights policy additions do not establish model photographic/gear-fit acceptance.'}
(P/'EVIDENCE-c0b314.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:proof[k]for k in ['tree','verdict','all46_original_Float32_streams_and_accessor_metadata_exact','original_158_mapping_rows_equal_saved_author_time_receipt','raw_headroom_bytes','wire_headroom_bytes']},indent=2));print('residentCSV',[(x['row'],x['column'])for x in csvdiff]);print('residentXLSX',[(x['sheet'],x['row'],x['column'])for x in xldiff])
