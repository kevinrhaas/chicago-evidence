# Covered cloth mobile8: six partialFAIL images + two continuationPASS images

Verification PASS applies to this evidence assembly, not to the original failed execution or photographic quality. All8PNG hashes/lengths/dimensions and4matched baseline/candidate pairs verified. Each pair has exactly equal saved camera, projection, pose, lighting, detail, fixedView and physical canvas; each frame passed the existing draw/triangle budget and zeroGL guard. BOTH original identity/asset validations ran in EACH execution; both used the same exact original/candidate model hashes, input pins, HEADad813 and raw index76a3. Shared caller/helper bytes are exact. No new browser/render/build/app/Git/ticket operation occurred during packaging.

The two execution lineages remain separate:

- `original-partial-FAIL/`: actual525.553s deadlineFAIL,6savedPNGs, owner1075357. Browser/server CLOSED, owned_live_pids=[], input pins unchanged. Original end-of-page comparison cleanup was not saved. Receipt SHA256 `5e3f68f59a181de0bc7ba0ea802ab79b661f4c799b4d8eafd0f23b2d279d1018`.
- `remaining-pair-PASS/`: actual298.837s PASS,2WolfPointquarterPNGs, owner1078470. It restored baseline children, disposed candidate native instances, CLOSED browser/server, owned_live_pids=[], input pins unchanged. Receipt SHA256 `6f18307e4999c96db1dff7c475284107814d97b99568603fed1eea7e4571c21a` binds the original failed receipt/archive in its config. This PASS means ONLY that pair+newpagecleanup; it cannot prove oldpagecleanup or turn its deadlineFAIL into PASS.

Actual visual review: four primary files (two complete pairs):

1. `original-partial-FAIL/actual-v1/mobile-western-side-baseline.png`
2. `original-partial-FAIL/actual-v1/mobile-western-side-candidate.png`
3. `remaining-pair-PASS/actual-v1/mobile-wolfpoint-front-quarter-baseline.png`
4. `remaining-pair-PASS/actual-v1/mobile-wolfpoint-front-quarter-candidate.png`

The Western quarter pair is also available under `original-partial-FAIL/actual-v1/mobile-western-front-quarter-{baseline,candidate}.png`; WolfPoint side is alongside it. No photograph has been repeated or synthesized. Exact PNG hashes and original budget readings are in `VERIFIED-SUMMARY.json` and original receipts. Actual PNG size780x1560 reflects mobile390x780/DPR2.

Remaining scope: all8desktop images are still unexecuted; full photographic/material/cloth-construction/all-angle/LOD acceptance remains OPEN. These normal main screenshots retain ordinary shadows and occlusion. Live background activity can move; camera equality is not a claim of whole-image pixel equality. A source-pixel review must still judge whether the20–28mm drape is better. No candidate integration or pin promotion is authorized by this capsule.

This compact capsule includes all8PNGs, complete original owner/config/progress/receipt/log/lock directories, both script-pin manifests and exact other-config preimages, common caller source once, and the verified assembly summary. It pins the separate19,978,240byte generation capsule SHA5719460a9e8a6e352e76c196871c2b98599f8f568aadbefb7d88566c41699b13 rather than duplicating model/world assets. The earlier4,935,680byte six-imageFAIL archive remains preserved asdb414b96ef4c17999ce8c3dd0c20302c7acf4ac47869183623f4b06a11dd679e.
