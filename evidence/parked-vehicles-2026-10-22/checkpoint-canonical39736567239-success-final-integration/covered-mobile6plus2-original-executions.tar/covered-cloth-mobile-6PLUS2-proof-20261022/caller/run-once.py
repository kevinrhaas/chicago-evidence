#!/usr/bin/env python3
"""Run only after root release and intended checkout/config reconciliation."""
import argparse,datetime,hashlib,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
BASE=Path(__file__).resolve().parent
HERE=None
CHILD=None
STATE={}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(**updates):
 STATE.update(updates);p=HERE/'owner-v1.json';tmp=p.with_suffix('.json.tmp');tmp.write_text(json.dumps(STATE,indent=2)+'\n');tmp.replace(p)
def interrupt(signum,frame):raise RuntimeError('Owner received signal '+str(signum))
def cleanup():
 browser=None
 try:browser=json.loads((HERE/'actual-v1/progress.json').read_text()).get('browserPid')
 except (OSError,ValueError):pass
 owned={CHILD.pid} if CHILD else set()
 if isinstance(browser,int):owned.add(browser)
 # Snapshot only PID/PPID, never command lines or environment secrets.
 try:
  rows=[tuple(map(int,line.split())) for line in subprocess.check_output(['ps','-eo','pid=,ppid='],text=True).splitlines()]
  for _ in range(8):owned.update(pid for pid,ppid in rows if ppid in owned)
 except (OSError,ValueError,subprocess.SubprocessError):pass
 if CHILD and CHILD.poll() is None:
  try:os.killpg(CHILD.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:CHILD.wait(timeout=8)
  except subprocess.TimeoutExpired:
   try:os.killpg(CHILD.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   try:CHILD.wait(timeout=1)
   except subprocess.TimeoutExpired:pass
 # launchServer exposes its actual browser PID. Kill only that exact owned group if graceful close failed.
 if isinstance(browser,int):
  try:
   pgid=os.getpgid(browser)
   if pgid==browser:os.killpg(pgid,signal.SIGKILL)
   else:os.kill(browser,signal.SIGKILL)
  except ProcessLookupError:pass
 if CHILD:
  try:os.killpg(CHILD.pid,signal.SIGKILL)
  except ProcessLookupError:pass
 for pid in owned:
  try:os.kill(pid,signal.SIGKILL)
  except ProcessLookupError:pass
 def live(pid):
  try:return Path('/proc/'+str(pid)+'/stat').read_text().split(') ',1)[1][0]!='Z'
  except (OSError,IndexError):return False
 end=time.monotonic()+1
 while any(live(pid) for pid in owned) and time.monotonic()<end:time.sleep(.05)
 remaining=[pid for pid in sorted(owned) if live(pid)]
 if remaining:STATE.update(status='FAIL',cleanup_failure='Owned live PID remains after bounded cleanup')
 save(owned_node_pid=None,owned_node_exit=CHILD.poll() if CHILD else None,browser_pid_recorded=browser,owned_live_pids=remaining,owned_cleanup_checked_pids=sorted(owned))
def main():
 global CHILD,HERE
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--release',action='store_true',required=True);ap.add_argument('--phase',choices=['desktop-western','desktop-oak','mobile'],required=True);args=ap.parse_args();HERE=BASE/args.phase
 lock=os.open(HERE/'ATTEMPT-v1.lock',os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.write(lock,str(os.getpid()).encode());os.close(lock)
 start=time.monotonic();signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt)
 save(status='RUNNING',caller_pid=os.getpid(),started_utc=utc(),max_total_seconds=540,work_deadline_seconds=525,progress=str(HERE/'actual-v1/progress.json'),scope='One actual-main viewport phase; no retry',phase=args.phase,planned_screenshots=json.loads((HERE/'config.json').read_text())['expectedScreenshots'])
 code=1
 try:
  pins=json.loads((BASE/'SCRIPT-PINS.json').read_text())
  for name,expected in pins.items():
   if hashlib.sha256((BASE/name).read_bytes()).hexdigest()!=expected:raise ValueError('Prepared file changed '+name)
  with (HERE/'caller.stdout').open('xb') as stdout,(HERE/'caller.stderr').open('xb') as stderr:
   CHILD=subprocess.Popen(['node',str(BASE/'capture.cjs'),str(HERE/'config.json')],cwd=HERE,stdout=stdout,stderr=stderr,start_new_session=True)
   save(owned_node_pid=CHILD.pid,owned_node_group=CHILD.pid)
   try:rc=CHILD.wait(timeout=max(0,525-(time.monotonic()-start)))
   except subprocess.TimeoutExpired:raise TimeoutError('525s global work deadline; preserve partial frames and stop')
   if rc:raise RuntimeError('Actual main caller exited '+str(rc)+'; preserve exact receipt/log failure')
   receipt=json.loads((HERE/'actual-v1/receipt.json').read_text())
   if not receipt.get('pass') or not receipt.get('browserAndServerClosed'):raise ValueError('Actual main receipt not PASS/CLOSED')
   save(status='PASS');code=0
 except BaseException as e:save(status='FAIL',failure=repr(e),traceback=traceback.format_exc())
 finally:
  cleanup();save(lifecycle='CLOSED',owner_departed_utc=utc(),elapsed_seconds=time.monotonic()-start)
 print(json.dumps(STATE));return 0 if code==0 and STATE['status']=='PASS' else 1
if __name__=='__main__':sys.exit(main())
