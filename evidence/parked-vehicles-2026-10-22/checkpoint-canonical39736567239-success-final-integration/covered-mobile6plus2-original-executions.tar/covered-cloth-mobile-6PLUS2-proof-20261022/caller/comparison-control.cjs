// Outside-app asset substitution only; production batching/articulation and main lighting/loop unchanged.
module.exports=async function installComparison(contract){
 const a=window.__chicago4d,need=(c,m)=>{if(!c)throw Error(m);};
 const{createParkedTransport}=await import(new URL('js/parked-transport.js',location.href).href);
 const problems=[],candidate=await createParkedTransport({dataBase:new URL('/__covered_drape/candidate/data/',location.origin),sceneId:'1835',terrain:a.terrain,confidence:a.confidence,detail:contract.detail,problems});
 need(!problems.length&&candidate.instances.length===2,'Candidate native production loading failed '+JSON.stringify(problems));
 const targets=new Map();
 for(const t of contract.targets){
  const original=a.parkedTransport.instances.find(i=>i.row.replaces===t.originalId),fresh=candidate.instances.find(i=>i.row.replaces===t.originalId);
  need(original&&fresh&&original.draw_batches===9&&fresh.draw_batches===9,'Both native nine-batch models required');
  for(const k of['position','rotation','scale'])need(JSON.stringify(original.group[k].toArray())===JSON.stringify(fresh.group[k].toArray()),'Candidate native transform differs '+k);
  need(JSON.stringify(original.parking)===JSON.stringify(fresh.parking)&&original.wheel_clearance_m===fresh.wheel_clearance_m,'Candidate native articulation/ground differs');
  need(JSON.stringify(original.row)===JSON.stringify(fresh.row),'Candidate scene row differs');
  const raw=await(await fetch(t.candidateUrl)).arrayBuffer(),hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',raw))].map(x=>x.toString(16).padStart(2,'0')).join('');
  need(hash===t.candidateSha256,'Candidate fetched hash differs');
  targets.set(t.originalId,{original,fresh,before:[...original.group.children],after:[...fresh.group.children],version:'baseline'});
 }
 function swap(id,version){
  need(targets.has(id)&&['baseline','candidate'].includes(version),'Unknown comparison target/version');
  // Keep every other object on its baseline; the selected target is the only substitution.
  for(const[key,t]of targets){const selected=key===id&&version==='candidate';t.original.group.clear();t.original.group.add(...(selected?t.after:t.before));t.version=selected?'candidate':'baseline';}
  return{id,version,scope:'Native production-batched immutable GLB children in original main instance; world renderer/pose/lighting unchanged'};
 }
 function cleanup(){
  for(const t of targets.values()){t.original.group.clear();t.original.group.add(...t.before);t.fresh.group.clear();t.fresh.group.add(...t.after);}
  window.__coveredInspection.cleanup();candidate.dispose();
  return{restoredBaseline:true,candidateInstances:candidate.instances.length};
 }
 window.__coveredDrape={swap,cleanup};
 return{nativeCandidateCount:candidate.instances.length,problems,scope:'Bounded main-scene asset appearance only; not new world-placement, occupied-interface or photographic acceptance'};
};
