// PREPARED/HELD. One normal main browser; sequential desktop/mobile contexts;16 screenshots.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto');
const{execFileSync}=require('node:child_process'),{chromium}=require('/workspace/shared/chicago-browser/node_modules/playwright');
const install=require('./browser-control-v2.cjs'),comparison=require('./comparison-control.cjs');
const here=__dirname,cfg=JSON.parse(fs.readFileSync(path.resolve(process.argv[2]))),out=path.resolve(cfg.output),root='/workspace/chicago';
if(!out.startsWith(here+'/')||cfg.pages.length!==1)throw Error('One viewport phase and outside-app output required');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),git=(...args)=>execFileSync('git',args,{cwd:root,maxBuffer:16*1024*1024}).toString().trim(),index=()=>sha(execFileSync('git',['ls-files','--stage'],{cwd:root,maxBuffer:16*1024*1024}));
let browser,browserServer,context,page,server,current,interrupted=false;
const receipt={pass:false,lifecycle:'RUNNING',started:new Date().toISOString(),callerPid:process.pid,browserPid:null,config:cfg,pages:[],servedMappings:[],scope:'Single-viewport bounded actual-main asset appearance comparison; not new world-placement or photographic acceptance'};
const persist=()=>fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify(receipt,null,2)+'\n');
const stamp=(name,extra={})=>{(receipt.phases??=[]).push({name,at:new Date().toISOString(),elapsed_ms:Date.now()-Date.parse(receipt.started),...extra});persist();};
function pins(){if(git('rev-parse','HEAD')!==cfg.expectedHead||index()!==cfg.expectedIndexDigest||git('diff','--name-only'))throw Error('Frozen app HEAD/index/working files changed');for(const[p,h]of Object.entries(cfg.inputPins))if(sha(fs.readFileSync(p))!==h)throw Error('Frozen input changed '+p);}
function classification(pr){return pr.failures.map(f=>{const ok=f.method==='HEAD'&&f.error==='net::ERR_ABORTED'&&/^\/(?:chicago\/4d|site\/4d)\/data\/sidecars\/1835\/people\.json$/.test(new URL(f.url).pathname)&&pr.responses.some(r=>r.id===f.id&&r.status===200);return{...f,accepted:ok,reason:ok?'V2 exact successful people HEAD/ERR_ABORTED exception':'Unclassified failure'};});}
async function shutdown(){
 if(context)await context.close().catch(e=>{receipt.contextCloseError=e.message;receipt.pass=false;});context=null;
 if(browser)await browser.close().catch(e=>{receipt.browserCloseError=e.message;receipt.pass=false;});browser=null;
 if(browserServer)await browserServer.close().catch(e=>{receipt.browserServerCloseError=e.message;receipt.pass=false;});browserServer=null;
 if(server?.listening){server.closeAllConnections();await new Promise(r=>server.close(r));}
 receipt.lifecycle='CLOSED';receipt.browserPid=null;receipt.browserAndServerClosed=true;receipt.ended=new Date().toISOString();
 try{pins();receipt.inputsUnchanged=true;}catch(e){receipt.inputsUnchanged=false;receipt.reconciliationError=e.message;receipt.pass=false;}
 fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');persist();
 console.log(JSON.stringify({pass:receipt.pass,closed:true,saved:receipt.pages.reduce((n,p)=>n+p.captures.filter(c=>c.saved).length,0),error:receipt.error}));
}
process.on('SIGTERM',()=>{interrupted=true;receipt.error='Finite outer watchdog SIGTERM';receipt.pass=false;void shutdown().finally(()=>process.exit(1));});
process.on('SIGINT',()=>{process.kill(process.pid,'SIGTERM');});
(async()=>{
 fs.mkdirSync(out,{recursive:false});persist();pins();
 const mapping=Object.fromEntries(Object.entries(cfg.requestMapping).map(([url,m])=>{const raw=fs.readFileSync(m.file);if(sha(raw)!==m.sha256)throw Error('Request map pin '+url);return[url,{...m,raw}];}));
 const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.css':'text/css','.wasm':'application/wasm'};
 server=http.createServer((req,res)=>{const url=new URL(req.url,'http://local').pathname;if(url==='/favicon.ico'){res.writeHead(204);return res.end();}try{
  if(mapping[url]){const m=mapping[url];receipt.servedMappings.push({url,sha256:m.sha256,method:req.method});res.setHeader('Content-Type',mime[path.extname(m.file)]||'application/octet-stream');res.setHeader('Cache-Control','no-store');res.end(m.raw);return;}
  let f=path.resolve(root,'.'+decodeURIComponent(url));if(!f.startsWith(root+'/'))throw Error('Path');if(fs.statSync(f).isDirectory())f=path.join(f,'index.html');res.setHeader('Content-Type',mime[path.extname(f)]||'application/octet-stream');res.end(fs.readFileSync(f));
 }catch(e){res.writeHead(404);res.end('not found');}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 browserServer=await chromium.launchServer({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});receipt.browserPid=browserServer.process().pid;persist();browser=await chromium.connect(browserServer.wsEndpoint());
 for(const job of cfg.pages){
  pins();current={label:job.label,phase:'boot',errors:[],messages:[],failures:[],responses:[],captures:[]};receipt.pages.push(current);persist();
  context=await browser.newContext({viewport:{width:job.width,height:job.height},hasTouch:job.mobile,deviceScaleFactor:job.dpr});page=await context.newPage();page.setDefaultTimeout(90000);
  const pr=current,ids=new WeakMap();let seq=0;const id=r=>{if(!ids.has(r))ids.set(r,++seq);return ids.get(r);};
  page.on('pageerror',e=>pr.errors.push({phase:pr.phase,error:e.message}));page.on('requestfailed',r=>pr.failures.push({id:id(r),phase:pr.phase,url:r.url(),method:r.method(),error:r.failure()?.errorText}));
  page.on('response',r=>{if(r.request().method()==='HEAD'||r.status()>=400)pr.responses.push({id:id(r.request()),url:r.url(),method:r.request().method(),status:r.status()});if(r.status()>=400)pr.errors.push({phase:pr.phase,error:'HTTP'+r.status()+' '+r.url()});});
  page.on('console',m=>{if(['warning','error'].includes(m.type()))pr.messages.push({phase:pr.phase,type:m.type(),text:m.text()});});
  await page.addInitScript(detail=>localStorage.setItem('chicago4d.settings',JSON.stringify({detail})),job.detail);
  await page.goto(origin+'/chicago/4d/renderers/web/?year=1835&keep-geometry=1',{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:180000,polling:1000});
  await page.evaluate(async detail=>{const a=window.__chicago4d;if(!a.ready)throw Error(a.error);const end=performance.now()+60000;while(a.welcome?.state!=='world'&&performance.now()<end){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}if(a.welcome?.state!=='world')throw Error('Welcome did not enter world');document.getElementById('control-help-gotit')?.click();document.exitPointerLock?.();if(a.detail!==detail)await a.setDetail(detail);},job.detail);
  if(pr.errors.length||pr.messages.some(m=>m.type==='error')||classification(pr).some(f=>!f.accepted))throw Error('Actual boot error/request failure');
  stamp('world_entered');pr.phase='install';pr.original=await page.evaluate(install,{targets:cfg.targets,detail:job.detail});pr.nativeCandidate=await page.evaluate(comparison,{targets:cfg.targets,detail:job.detail});stamp('native_comparison_installed');
  if(pr.errors.length||pr.messages.some(m=>m.type==='error')||classification(pr).some(f=>!f.accepted))throw Error('Actual native candidate install error/request failure');
  for(const target of cfg.targets.filter(t=>cfg.captureTargets.includes(t.model)))for(const angle of cfg.angles){
   await page.evaluate(id=>window.__coveredDrape.swap(id,'baseline'),target.originalId);
   stamp('view_started',{target:target.label,angle});const fixedView=await page.evaluate(({id,angle})=>window.__coveredInspection.view(id,angle),{id:target.originalId,angle});
   stamp('view_ready',{target:target.label,angle});let previous;
   for(const version of['baseline','candidate']){
    pr.phase=[target.label,angle,version].join('-');await page.evaluate(({id,version})=>window.__coveredDrape.swap(id,version),{id:target.originalId,version});
    stamp('capture_state_started',{target:target.label,angle,version});const state=await page.evaluate(id=>window.__coveredInspection.capture(id,'refined'),target.originalId);
    if(previous)for(const key of['camera','projection','lighting','pose','detail','actualCanvas'])if(JSON.stringify(previous[key])!==JSON.stringify(state[key]))throw Error('Matched pair changed '+key);
    previous=state;const name=[job.label,target.label,angle,version].join('-'),entry={name,version,angle,fixedView,state,saved:false,modelSha256:version==='baseline'?target.glbSha256:target.candidateSha256};pr.captures.push(entry);persist();
    stamp('normal_screenshot_started',{name});await page.screenshot({path:path.join(out,name+'.png'),timeout:90000});const raw=fs.readFileSync(path.join(out,name+'.png'));entry.saved=true;entry.sha256=sha(raw);entry.bytes=raw.length;entry.pngSize=[raw.readUInt32BE(16),raw.readUInt32BE(20)];stamp('normal_screenshot_saved',{name});console.log('SAVED '+name);
    if(pr.errors.length||pr.messages.some(m=>m.type==='error')||classification(pr).some(f=>!f.accepted))throw Error('Actual page error/request failure');
   }
  }
  pr.phase='cleanup';pr.cleanup=await page.evaluate(()=>window.__coveredDrape.cleanup());pr.requestClassification=classification(pr);pr.pass=!pr.errors.length&&!pr.messages.some(m=>m.type==='error')&&!pr.requestClassification.some(f=>!f.accepted)&&pr.captures.length===cfg.expectedScreenshots&&pr.captures.every(c=>c.saved);persist();if(!pr.pass)throw Error('Page failed '+job.label);
  await context.close();context=null;page=null;pr.phase='CLOSED';persist();
 }
 if(receipt.pages.reduce((n,p)=>n+p.captures.length,0)!==cfg.expectedScreenshots)throw Error('Planned phase screenshot count differs');pins();receipt.pass=true;
})().catch(e=>{receipt.pass=false;receipt.error=e.stack;process.exitCode=1;}).finally(async()=>{if(!interrupted){await shutdown();if(!receipt.pass)process.exitCode=1;}});
