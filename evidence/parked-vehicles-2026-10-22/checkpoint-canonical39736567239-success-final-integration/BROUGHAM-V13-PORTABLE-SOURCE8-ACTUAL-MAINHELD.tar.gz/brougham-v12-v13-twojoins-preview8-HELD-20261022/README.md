# V12→V13 matched two-join comparison — HELD, no browser

Exactly eight normal screenshots: desktop1280×800/mobile390×780 ×rawV12/rawV13 ×fixed detail/fullquarter source camera. Reuses the actual-passed earlier V11/V12 fixture/caller and original lighting, source plate0095 b458565e, source camera dad2ebb2 and depth-valid near100/far1000 with exact original nondepth XY projection. All geometry including inferred pole enabled, no masks/light/bias/material/camera fitting changes. Detail naturally crops lower/hidden parts; fullquarter must frame the whole bounds/pole. No source/photo/world acceptance follows from the CPU ray repair checks.

V13 changes only cabin_front_lower and interior_floor; actual raw469ff52b/32678tri,464otherpartsPN exact and three old protrusion rays now body. Both master fullbounds/nodes/materials/anchors identical. Whole-source physical dimensions/hidden details and remaining photographic quality stay reconstructed/open.

One separately released175s owner/165s browser, same owned cleanup including DFG attribution/zero resources and server closure, no automatic retry. All fixture/module/input hashes and runtime binary pins frozen outside app. No browser/generator/app/Git writes during preparation. Root must release after covered mobile4192 closes.
