// Outside-app adapter of covered normal-main production-path helper. No app script edits.
module.exports=async function installBroughamMain(c){
 const a=window.__chicago4d,T=await import('three'),need=(v,m)=>{if(!v)throw Error(m);};
 need(a?.ready&&String(a.year)==='1904'&&a.parkedTransport&&a.streetGrid?.carriagewayHeight,'Actual1904 main APIs required');
 need(a.detail===c.detail&&a.detail!=='light','Requested normal detail required');
 const main=a.parkedTransport,update=main.update,scene=a.scene3d,env=scene.environment;
 need(env?.isTexture&&env.mapping===T.CubeUVReflectionMapping,'Normal main calibrated PMREM required');
 const beforeInstances=main.instances.map(i=>{i.group.updateMatrixWorld(true);return{id:i.row.id,row:JSON.stringify(i.row),group:i.group,children:[...i.group.children],matrix:i.group.matrix.toArray()};});
 const generic=beforeInstances.find(i=>i.id==='prairie_parked_carriage');need(generic,'Distinct existing C02 required');
 const sceneChildren=[...scene.children],beforeMemory={...a.renderer.info.memory},problems=[],progress={phase:'native-load'};
 const{createParkedTransport}=await import(new URL('js/parked-transport.js',location.href).href);
 const candidate=await createParkedTransport({dataBase:new URL('/__brougham_v13/data/',location.origin),sceneId:'1904',terrain:a.terrain,confidence:a.confidence,detail:c.detail,problems,groundHeight:(e,n)=>a.streetGrid.carriagewayHeight(e,n)});
 need(!problems.length&&candidate.instances.length===1,'Native candidate load: '+JSON.stringify(problems));
 const i=candidate.instances[0];need(i.row.id===c.row.id&&JSON.stringify(i.row)===JSON.stringify(c.row),'Exact reconstructed stand row required');
 need(!i.row.replaces&&i.draw_batches===6&&i.parking===null,'Distinct six-batch fixed-pole production path required');
 need(i.wheel_clearance_m<=.03,'Unchanged production30mm wheel guard');
 const raw=await(await fetch(c.candidateUrl)).arrayBuffer();
 const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',raw))].map(v=>v.toString(16).padStart(2,'0')).join('');need(hash===c.candidateSha256,'Exact indexed near source bytes required');
 const geometries=new Set(),materials=new Set(),disposedGeometries=new Set(),disposedMaterials=new Set();
 i.group.traverse(n=>{if(n.isMesh){geometries.add(n.geometry);materials.add(n.material);need(n.castShadow&&n.receiveShadow,'Native normal shadows required');}});
 for(const g of geometries)g.addEventListener('dispose',()=>disposedGeometries.add(g));
 for(const m of materials)m.addEventListener('dispose',()=>disposedMaterials.add(m));
 need(geometries.size===6&&materials.size===6,'Exact shared material batching');
 scene.add(candidate.group);
 // The original main render loop calls this same object. Retain its original update and append native candidate update.
 const hooked=function(camera){update.call(main,camera);candidate.update(camera);};main.update=hooked;
 const ground=(x,z)=>{const y=a.streetGrid.carriagewayHeight(x,-z);need(Number.isFinite(y),'Missing actual rendered carriageway at '+[x,-z]);return y;};
 function lighting(){
  const list=[];scene.traverse(n=>{if(n.isLight)list.push({uuid:n.uuid,name:n.name,type:n.type,intensity:n.intensity,color:n.color?.getHexString(),position:n.position.toArray(),targetPosition:n.target?.position.toArray(),castShadow:n.castShadow,shadow:n.shadow?{bias:n.shadow.bias,normalBias:n.shadow.normalBias,mapSize:n.shadow.mapSize.toArray(),camera:{up:n.shadow.camera.up.toArray(),left:n.shadow.camera.left,right:n.shadow.camera.right,top:n.shadow.camera.top,bottom:n.shadow.camera.bottom,near:n.shadow.camera.near,far:n.shadow.camera.far,zoom:n.shadow.camera.zoom,projection:n.shadow.camera.projectionMatrix.toArray()}}:null});});
  return{shadowEnabled:a.renderer.shadowMap.enabled,shadowType:a.renderer.shadowMap.type,toneMapping:a.renderer.toneMapping,exposure:a.renderer.toneMappingExposure,environment:{uuid:scene.environment?.uuid,mapping:scene.environment?.mapping,type:scene.environment?.type,format:scene.environment?.format,width:scene.environment?.image?.width,height:scene.environment?.image?.height,intensity:scene.environmentIntensity,rotation:scene.environmentRotation?.toArray()},sunDirection:a.world.direction.toArray(),sunDate:a.world.sunDate,shadowRig:{...a.world.shadowRig},list};
 }
 need(a.world?.light?.isDirectionalLight&&a.world.light.name==='sun','Pinned production sun rig required');
 const sun=a.world.light,normalLighting=lighting();progress.initialLighting=normalLighting;progress.lightingChecks=[];
 function fixedLighting(value){return{...value,list:value.list.map(row=>{if(row.uuid!==sun.uuid)return row;const{position,targetPosition,...fixed}=row;return fixed;})};}
 const fixedBaseline=fixedLighting(normalLighting);
 function checkLighting(label){
  const actual=lighting(),direction=a.world.direction,cam=sun.shadow.camera,basis=new T.Matrix4().lookAt(direction.clone().multiplyScalar(320),new T.Vector3(),cam.up),right=new T.Vector3().setFromMatrixColumn(basis,0),up=new T.Vector3().setFromMatrixColumn(basis,1),target=new T.Vector3(a.camera.position.x,0,a.camera.position.z),rig=a.world.shadowRig;
  if(rig.snapped){const e=target.dot(right),u=target.dot(up),texel=rig.texelM;target.addScaledVector(right,Math.round(e/texel)*texel-e).addScaledVector(up,Math.round(u/texel)*texel-u);}
  const offset=direction.clone().multiplyScalar(320),expectedLight=target.clone().add(offset),actualTarget=sun.target.position.clone(),actualLight=sun.position.clone(),actualOffset=actualLight.clone().sub(actualTarget);
  const check={label,camera:a.camera.position.toArray(),baseline:normalLighting,actual,expectedTarget:target.toArray(),expectedLight:expectedLight.toArray(),expectedOffset:offset.toArray(),actualOffset:actualOffset.toArray(),targetError_m:target.distanceTo(actualTarget),lightError_m:expectedLight.distanceTo(actualLight),offsetError_m:offset.distanceTo(actualOffset),fixedParametersEqual:JSON.stringify(fixedLighting(actual))===JSON.stringify(fixedBaseline),sameEnvironmentObject:scene.environment===env};
  // Store BEFORE assertion: a failed comparison must retain actual before/after evidence.
  progress.lightingChecks.push(check);
  need(check.sameEnvironmentObject&&check.fixedParametersEqual,'Normal main environment/fixed lighting parameters changed');
  need(check.targetError_m<=1e-8&&check.lightError_m<=1e-8&&check.offsetError_m<=1e-9,'Normal main source-defined snapped sun motion differs');
  return check;
 }
 function preserved(label='frame'){
  checkLighting(label);need(main.instances.length===beforeInstances.length,'Existing instance count changed');
  for(const old of beforeInstances){const n=main.instances.find(n=>n.row.id===old.id);n?.group.updateMatrixWorld(true);need(n?.group===old.group&&JSON.stringify(n.row)===old.row&&JSON.stringify(n.group.matrix.toArray())===JSON.stringify(old.matrix)&&n.group.children.length===old.children.length&&n.group.children.every((ch,k)=>ch===old.children[k]),'Existing carriage/wagon modified '+old.id);}
  need(sceneChildren.every(ch=>scene.children.includes(ch)),'Existing world group removed');
 }
 function frame(){a.step();a.step();a.renderer.getContext().finish();const s=a.stats(),gl=a.renderer.getContext();const r={driverDraws:s.drawCalls,rendererCalls:s.rendererCalls,triangles:s.triangles,budget:s.budget,withinBudget:s.withinBudget,geometries:s.geometries,textures:s.textures,glError:gl.getError()};need(r.withinBudget===true&&r.glError===0,'Canonical actual main budget/GL failed');preserved();return r;}
 const corners=b=>{const vs=[];for(const x of[b.min.x,b.max.x])for(const y of[b.min.y,b.max.y])for(const z of[b.min.z,b.max.z])vs.push(new T.Vector3(x,y,z));return vs;};
 function view(angle){
  progress.beforeView={angle,camera:a.camera.position.toArray(),lighting:lighting()};
  need(['side','front-quarter'].includes(angle),'Frozen normal view required');i.group.updateMatrixWorld(true);const whole=new T.Box3().setFromObject(i.group,true),centre=whole.getCenter(new T.Vector3()),local=(angle==='side'?new T.Vector3(1,0,.01):new T.Vector3(.9,0,1)).applyQuaternion(i.group.quaternion).normalize(),right=new T.Vector3().crossVectors(new T.Vector3(0,1,0),local).normalize();
  const tv=Math.tan(a.camera.fov*Math.PI/360),th=tv*a.camera.aspect;let distance=4;
  for(const v of corners(whole)){const q=v.clone().sub(centre),d=q.dot(local);distance=Math.max(distance,d+Math.abs(q.dot(right))/(th*.88),d+Math.abs(q.y)/(tv*.88));}
  let bounds,pose;
  for(let attempt=0;attempt<6;attempt++){
   const eye=centre.clone().addScaledVector(local,distance),e=eye.x,n=-eye.z,yaw=Math.atan2(centre.x-e,-centre.z-n)*180/Math.PI;
   a.setFly(false);a.walker.teleport({local_e:e,local_n:n,yaw_deg:yaw,pitch_deg:0,altitude_m:null});const pitch=Math.atan2(centre.y-a.walker.state.eyeY,Math.hypot(centre.x-e,centre.z-eye.z))*180/Math.PI;a.walker.teleport({local_e:e,local_n:n,yaw_deg:yaw,pitch_deg:pitch,altitude_m:null});frame();
   const pp=corners(whole).map(v=>v.project(a.camera));bounds={minX:Math.min(...pp.map(v=>v.x)),maxX:Math.max(...pp.map(v=>v.x)),minY:Math.min(...pp.map(v=>v.y)),maxY:Math.max(...pp.map(v=>v.y)),near:Math.min(...pp.map(v=>v.z)),far:Math.max(...pp.map(v=>v.z))};pose={...a.walker.state};
   if(Math.max(...[bounds.minX,bounds.maxX,bounds.minY,bounds.maxY].map(Math.abs))<.95&&bounds.near>-1&&bounds.far<1)break;distance*=1.22;
  }
  need(Math.max(...[bounds.minX,bounds.maxX,bounds.minY,bounds.maxY].map(Math.abs))<.95&&bounds.near>-1&&bounds.far<1,'Actual full model/pole not framed');need(i.group.visible,'Candidate outside native detail reach');
  return{angle,pose,bounds,worldBounds:{min:whole.min.toArray(),max:whole.max.toArray()},framing:'Actual whole native six-batch vehicle including fixed inferred pole; normal ground walker camera',aerialInspection:false};
 }
 function capture(){const draw=frame();need(i.group.visible&&i.group.children.every(n=>n.visible),'All native candidate batches required visible');const materialRows=[...materials].map(m=>{const compiled=a.renderer.properties.get(m);need(compiled.envMap===env,'Actual compiled physical material must use unchanged main PMREM');return{name:m.name,type:m.type,color:m.color?.getHexString(),roughness:m.roughness,metalness:m.metalness,clearcoat:m.clearcoat,clearcoatRoughness:m.clearcoatRoughness,transparent:m.transparent,opacity:m.opacity,depthWrite:m.depthWrite,envMapIntensity:m.envMapIntensity,compiledEnvironmentUuid:compiled.envMap?.uuid};});return{draw,lightingCheck:structuredClone(progress.lightingChecks.at(-1)),pose:{...a.walker.state},camera:a.camera.matrixWorld.toArray(),projection:a.camera.projectionMatrix.toArray(),lighting:lighting(),detail:a.detail,actualCanvas:[a.renderer.domElement.width,a.renderer.domElement.height],candidate:{id:i.row.id,visible:i.group.visible,batches:i.draw_batches,wheelPlaneSpan_m:i.wheel_clearance_m,parking:i.parking,materials:materialRows},genericC02:{id:generic.id,retained:true},problems};}
 function clearance(){
  progress.phase='clearance';i.group.updateMatrixWorld(true);const box=new T.Box3().setFromObject(i.group,true),sample={vertices:0,minGroundClearance_m:Infinity,scope:'Actual merged vertex samples against same rendered carriagewayHeight used by production wheels; not continuous ground triangle proof'};progress.sample=sample;
  // Rotate actual source vertices, not the local source AABB: rotated AABB corners
  // are conservative points that need not belong to this vehicle's actual hull.
  const view=new DataView(raw),jsonBytes=view.getUint32(12,true),g=JSON.parse(new TextDecoder().decode(new Uint8Array(raw,20,jsonBytes))),bin=20+jsonBytes+8,world=new Map(),sourceLocal=new T.Box3(),sourceWorld=new T.Box3();let decodedVertices=0;
  function visit(id,parent){const n=g.nodes[id];need(!['matrix','rotation','scale'].some(k=>k in n),'Pinned source translation-only nodes required');const tr=parent.clone().add(new T.Vector3(...(n.translation??[0,0,0])));world.set(id,tr);for(const child of n.children??[])visit(child,tr);}
  for(const id of g.scenes[g.scene??0].nodes)visit(id,new T.Vector3());
  for(const[id,tr]of world){const n=g.nodes[id];if(n.mesh===undefined)continue;for(const prim of g.meshes[n.mesh].primitives){const ac=g.accessors[prim.attributes.POSITION],bv=g.bufferViews[ac.bufferView];need(ac.componentType===5126&&ac.type==='VEC3'&&!ac.sparse&&!bv.byteStride,'Exact source float3 positions required');const points=new Float32Array(raw,bin+(bv.byteOffset??0)+(ac.byteOffset??0),ac.count*3);for(let k=0;k<points.length;k+=3){decodedVertices++;const v=new T.Vector3(points[k],points[k+1],points[k+2]).add(tr);sourceLocal.expandByPoint(v);sourceWorld.expandByPoint(v.applyMatrix4(i.group.matrixWorld));}}}
  const expectedLocal=new T.Box3(new T.Vector3(...c.sourceBounds.min),new T.Vector3(...c.sourceBounds.max));progress.bounds={actual:{min:box.min.toArray(),max:box.max.toArray()},sourceVertexWorld:{min:sourceWorld.min.toArray(),max:sourceWorld.max.toArray()},sourceDecodedLocal:{min:sourceLocal.min.toArray(),max:sourceLocal.max.toArray()},decodedVertices};need(decodedVertices===c.expectedDecodedVertices,'Decoded source vertex count changed');need(sourceLocal.equals(expectedLocal),'Decoded reviewed source bounds differ');need(box.min.distanceTo(sourceWorld.min)<.000001&&box.max.distanceTo(sourceWorld.max)<.000001,'Actual merged world bounds differ from actual source vertex transforms');
  const triangles=[...geometries].reduce((n,g)=>n+(g.index?.count??g.getAttribute('position').count)/3,0);progress.triangles=triangles;need(triangles===32678,'Reviewed near triangle count changed');
  i.group.traverse(n=>{if(!n.isMesh)return;const p=n.geometry.getAttribute('position');for(let k=0;k<p.count;k++){const v=new T.Vector3().fromBufferAttribute(p,k).applyMatrix4(n.matrixWorld);sample.vertices++;sample.minGroundClearance_m=Math.min(sample.minGroundClearance_m,v.y-ground(v.x,v.z));}});
  need(sample.minGroundClearance_m>=-.001,'Actual merged vehicle vertex below rendered road by more than1mm');
  const supports=c.supportContacts.map(p=>{const v=new T.Vector3().fromArray(p).applyMatrix4(i.group.matrixWorld);return{world:v.toArray(),ground:ground(v.x,v.z),gap_m:v.y-ground(v.x,v.z)};});progress.supports=supports;need(supports.every(p=>p.gap_m>=-.001&&p.gap_m<=.03),'Fixed pole shoe outside actual road1mm penetration/30mm gap limits');
  const gap=(b,d)=>Math.hypot(Math.max(b.min.x-d.max.x,d.min.x-b.max.x,0),Math.max(b.min.y-d.max.y,d.min.y-b.max.y,0),Math.max(b.min.z-d.max.z,d.min.z-b.max.z,0));
  const others=main.instances.map(n=>{n.group.updateMatrixWorld(true);const b=new T.Box3().setFromObject(n.group,true);return{id:n.row.id,gap_m:gap(box,b),min:b.min.toArray(),max:b.max.toArray()};});need(others.every(n=>n.gap_m>0),'Conservative actual other parked vehicle bounds intersect');
  const buildings=[];for(const[id,b]of Object.entries(a.buildings.instanceBounds())){const matrix=a.buildings.matrixOf(id);need(matrix,'Actual building placement missing '+id);const world=new T.Box3(new T.Vector3().fromArray(b.min),new T.Vector3().fromArray(b.max)).applyMatrix4(matrix),d=gap(box,world);need(d>0,'Conservative actual building box overlaps '+id);if(d<30)buildings.push({id,gap_m:d,min:world.min.toArray(),max:world.max.toArray()});}
  // Actual triangle versus whole-vehicle AABB is conservative. Broad phase excludes distant triangles.
  // No canopy/trunk inference from source photos or record radii; inspect rendered trees/street obstacles.
  const obstacles={meshes:0,instances:0,trianglesNarrowPhase:0,intersections:[],scope:'Rendered street non-carriageway bands/curbs/blocks and street-tree geometry against conservative whole-vehicle AABB; not every world object or dynamic collision'};progress.obstacles=obstacles;
  const tri=new T.Triangle(),v=new T.Vector3(),m=new T.Matrix4();
  function test(mesh,matrix,start=0,count=null){const g=mesh.geometry,pos=g.getAttribute('position'),index=g.index;if(!pos)return;count=count??(index?.count??pos.count);for(let k=start;k<start+count;k+=3){const arr=[tri.a,tri.b,tri.c];for(let q=0;q<3;q++)arr[q].fromBufferAttribute(pos,index?index.getX(k+q):k+q).applyMatrix4(matrix);const tb=new T.Box3().setFromPoints(arr);if(!box.intersectsBox(tb))continue;obstacles.trianglesNarrowPhase++;if(box.intersectsTriangle(tri)){if(obstacles.intersections.length<12)obstacles.intersections.push({mesh:mesh.name,triangle:k/3});}}}
  function scan(group,street=false){group?.updateMatrixWorld(true);group?.traverse(n=>{if(!n.isMesh||street&&['carriageway','alley'].includes(n.userData.cls))return;obstacles.meshes++;if(n.isBatchedMesh){for(let k=0;k<n.instanceCount;k++){if(!n.getVisibleAt(k))continue;const id=n.getGeometryIdAt(k),b=n.getBoundingBoxAt(id,new T.Box3());n.getMatrixAt(k,m);m.premultiply(n.matrixWorld);obstacles.instances++;if(!box.intersectsBox(b.applyMatrix4(m)))continue;const r=n.getGeometryRangeAt(id);test(n,m,r.start,r.count);}}else if(n.isInstancedMesh){for(let k=0;k<n.count;k++){n.getMatrixAt(k,m);m.premultiply(n.matrixWorld);obstacles.instances++;test(n,m);}}else{n.geometry.computeBoundingBox();if(box.intersectsBox(n.geometry.boundingBox.clone().applyMatrix4(n.matrixWorld)))test(n,n.matrixWorld);}});}
  scan(a.streetGrid.group,true);scan(a.streetTrees?.group);need(obstacles.intersections.length===0,'Rendered conservative street/tree obstacle intersects vehicle envelope');
  return{sample,supports,others,buildings,obstacles,actualWorldBounds:{min:box.min.toArray(),max:box.max.toArray()},scope:'Actual wheel/provider/support/vertex and conservative rendered selected obstacle checks. World dynamic movement, hidden nonselected layers, solid intersections and occupied collision remain OPEN.'};
 }
 async function cleanup(){need(main.update===hooked,'Main update hook ownership changed');main.update=update;scene.remove(candidate.group);candidate.dispose();await Promise.resolve();await Promise.resolve();a.step();a.step();a.renderer.getContext().finish();preserved();need(candidate.instances.length===0&&candidate.group.children.length===0&&candidate.group.parent===null,'Owned candidate remains');need(disposedGeometries.size===geometries.size&&disposedMaterials.size===materials.size,'Owned merged geometry/material disposal incomplete');need(scene.children.length===sceneChildren.length&&sceneChildren.every((n,k)=>scene.children[k]===n),'World scene restoration differs');return{lightingChecks:structuredClone(progress.lightingChecks),restoredMainUpdate:main.update===update,existingGenericC02Retained:true,disposedMergedGeometries:disposedGeometries.size,disposedMaterials:disposedMaterials.size,ownedInstances:candidate.instances.length,beforeMemory,afterMemory:{...a.renderer.info.memory},sharedEnvironmentRetained:scene.environment===env,scope:'Dispose owned production candidate only, retain shared main renderer/PMREM/DFG; original asset disposal is production disposeLoadedAsset path'};}
 window.__broughamMain={view,capture,clearance,cleanup,diagnostic:()=>progress};progress.phase='installed';return{problems,modelSha256:hash,batches:i.draw_batches,normalLighting,scope:'New distinct parked native production candidate in actual1904 main; no global pick/card integration, photographic or occupied acceptance'};
};
