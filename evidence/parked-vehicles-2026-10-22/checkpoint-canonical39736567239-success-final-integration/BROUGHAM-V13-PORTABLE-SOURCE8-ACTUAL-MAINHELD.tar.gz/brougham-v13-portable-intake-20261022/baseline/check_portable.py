# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent native-GLB delivery/anchor checks; no renderer or historical acceptance."""
from pathlib import Path
import argparse,hashlib,json,math,struct
EXPECTED_MASTER='8016867da68e3f061d98864ef46a94b98d8356a683ff9d0c39113abdf1504590'
EXPECTED_REF='b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe'

def read(path):
    b=path.read_bytes();assert struct.unpack_from('<III',b)==(0x46546c67,2,len(b)), 'Invalid GLB envelope'
    n,t=struct.unpack_from('<II',b,12);assert t==0x4e4f534a
    j=json.loads(b[20:20+n]);m,t=struct.unpack_from('<II',b,20+n);assert t==0x004e4942
    return j,b[28+n:28+n+m]

def values(j,b,i):
    a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];assert not a.get('sparse')
    width={'VEC3':3,'SCALAR':1}[a['type']];fmt={5126:'f',5123:'H',5125:'I'}[a['componentType']];size=struct.calcsize(fmt)*width;off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size)
    assert off>=0 and off+(a['count']-1)*stride+size<=len(b), 'Accessor outside binary'
    return [struct.unpack_from('<'+fmt*width,b,off+k*stride) for k in range(a['count'])]

def expanded(j,b):
    h=hashlib.sha256();tris=0
    for m in j['meshes']:
        for p in m['primitives']:
            assert p.get('mode',4)==4 and set(p['attributes'])=={'POSITION','NORMAL'}
            pts=values(j,b,p['attributes']['POSITION']);norms=values(j,b,p['attributes']['NORMAL']);assert len(pts)==len(norms)
            ids=[q[0] for q in values(j,b,p['indices'])] if 'indices' in p else list(range(len(pts)))
            assert len(ids)%3==0;tris+=len(ids)//3
            for k in ids:
                assert 0<=k<len(pts)
                assert all(math.isfinite(x) for x in pts[k]+norms[k]);assert abs(math.sqrt(sum(x*x for x in norms[k]))-1)<1e-4
                h.update(struct.pack('<ffffff',*(pts[k]+norms[k])))
            for off in range(0,len(ids),3):
                a,c,d=[pts[i] for i in ids[off:off+3]];u=[c[k]-a[k] for k in range(3)];v=[d[k]-a[k] for k in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
                assert sum(x*x for x in cross)>1e-20, 'Degenerate delivered triangle'
    return h.hexdigest(),tris

def world_nodes(j):
    world={}
    def visit(i,prev):
        n=j['nodes'][i];assert not any(k in n for k in ['scale','rotation','matrix'])
        world[i]=[prev[k]+n.get('translation',[0,0,0])[k] for k in range(3)]
        for c in n.get('children',[]):visit(c,world[i])
    for i in j['scenes'][j.get('scene',0)]['nodes']:visit(i,[0,0,0])
    return world

def decoded_bounds(j,b,world):
    points=[]
    for i,node in enumerate(j['nodes']):
        if 'mesh' not in node:continue
        for prim in j['meshes'][node['mesh']]['primitives']:
            for p in values(j,b,prim['attributes']['POSITION']):points.append([p[k]+world[i][k] for k in range(3)])
    return {'min':[min(p[k] for p in points) for k in range(3)],'max':[max(p[k] for p in points) for k in range(3)]}

def check(directory):
    side=json.loads((directory/'brougham.json').read_text());master=directory/'brougham-source.glb';assert hashlib.sha256(master.read_bytes()).hexdigest()==EXPECTED_MASTER
    j,b=read(master);signature,near_triangles=expanded(j,b);assert near_triangles==32670;world=world_nodes(j);master_bounds=decoded_bounds(j,b,world)
    assert side['source_master_sha256']==EXPECTED_MASTER and side['grade']=='reconstructed'
    assert side['design_reference']['date']==1893 and side['design_reference']['source_id']=='studebaker_1893_illustrated_souvenir' and side['design_reference']['reference_sha256']==EXPECTED_REF
    assert side['lod_runtime_selection_enabled'] is False and side['authored_texture_bytes']==0
    assert len(side['anchors'])==13 and all(a['dynamic_binding_supported'] is False for a in side['anchors'])
    for a in side['anchors']:
        n=j['nodes'][a['node_index']];assert a['node']==n['name'] and a['translation_root_m']==world[a['node_index']] and a['rotation_xyzw']==[0,0,0,1] and a['scale']==[1,1,1], 'Anchor drift'
    assert side['wheel_contacts_root_m']==[[-.67,0,-1.15],[.67,0,-1.15],[-.67,0,1.15],[.67,0,1.15]]
    assert side['static_pole_ground_shoe_contact_root_m']==[[-.0325,0,3.725],[.0325,0,3.725],[-.0325,0,3.825],[.0325,0,3.825]]
    assert len(side['lods'])==3 and (directory/'LICENSE').is_file()
    rows=[]
    for expected,row in zip(['near','mid','far'],side['lods']):
        assert row['detail']==expected;file=directory/row['file'];assert file.name==f'brougham-{expected}.glb' and hashlib.sha256(file.read_bytes()).hexdigest()==row['indexed_sha256']
        d,bin=read(file);actual,tri=expanded(d,bin);assert actual==row['expanded_triangle_PN_sha256'] and tri==row['triangles']
        assert d['nodes']==j['nodes'] and d['materials']==j['materials'] and d['scenes']==j['scenes'] and world_nodes(d)==world
        assert decoded_bounds(d,bin,world_nodes(d))==master_bounds==row['bounds_m'],'Actual LOD fullbounds drift'
        if expected=='near':assert actual==signature, 'Lossless near master stream drift'
        assert len(d['meshes'])==24 and len(d['nodes'])==41 and not d.get('images') and not d.get('textures') and all('uri' not in q for q in d['buffers'])
        rows.append({'detail':expected,'triangles':tri,'bytes':file.stat().st_size,'expanded_PN_sha256':actual})
    assert len(rows)==3 and rows[0]['triangles']>rows[1]['triangles']>rows[2]['triangles']
    return {'passed':True,'scope':'Independent delivered index streams/finite vertices/normals/areas/identity/frames/unsupported interfaces;not visual/ground/collision/photographic acceptance','rows':rows,'anchors':len(side['anchors']),'actual_decoded_bounds_m':master_bounds,'actual_decoded_bounds_exact_all_lods':True}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',type=Path,required=True);p.add_argument('--receipt',type=Path);a=p.parse_args();result=check(a.directory)
    if a.receipt:a.receipt.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
