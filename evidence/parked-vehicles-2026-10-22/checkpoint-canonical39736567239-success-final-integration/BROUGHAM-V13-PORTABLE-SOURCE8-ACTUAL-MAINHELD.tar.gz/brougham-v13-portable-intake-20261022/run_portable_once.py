from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time,sys
R=Path(__file__).parent.resolve();START=time.monotonic();BUDGET=90;PY='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python';NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node';T=R/'proposed/chicago/4d/tools/transport/brougham';PARAM=R/'proposed/chicago/4d/data/transport/parked/studebaker-brougham-parameters.json';OUT=R/'proposed/chicago/4d/renderers/web/transport/parked-brougham'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def need(ok,msg):
 if not ok:raise ValueError(msg)
m=json.loads((R/'PREPARED-PIPELINE.json').read_text())
for row in m['files']:
 p=(R/row['path']).resolve();need(p.is_relative_to(R) and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'Pinned pipeline drift '+row['path'])
need(not(R/'GENERATION-INTENT.json').exists() and not OUT.exists() and not(R/'repeat').exists(),'Fresh exclusive intent/output required; no retry')
with(R/'GENERATION-INTENT.json').open('x') as f:json.dump({'authorization_owner':'root','authorization':'Root authorizes ONE bounded supported portableV13generation/intake while covered mobile4192 owns browser;expected4-5s nice/singlethread,90s strict owner bound;no browser/app/Git or automatic amendment/retry.','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prepared_pipeline_sha256':sha(R/'PREPARED-PIPELINE.json'),'budget_seconds':BUDGET},f,indent=2)
receipt={'pass':False,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual rawV13 reproduced/indexed near/mid/far delivery and validation; no runtime/photographic/mainworld qualification','stages':[]};env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def save():(R/'GENERATION-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(label,args):
 remaining=BUDGET-(time.monotonic()-START)-2;need(remaining>0,'90second ownerdeadline');p=subprocess.Popen(['nice','-n','10',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True,env=env)
 try:out,err=p.communicate(timeout=remaining)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate(timeout=1);(R/(label+'.stdout.log')).write_text(out);(R/(label+'.stderr.log')).write_text(err);raise TimeoutError('90second ownerdeadline;owned subprocess killed')
 (R/(label+'.stdout.log')).write_text(out);(R/(label+'.stderr.log')).write_text(err);receipt['stages'].append({'label':label,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-START});save();need(p.returncode==0,'Stage failed '+label)
try:
 for name,dest in [('first',OUT),('repeat',R/'repeat')]:run(name,[PY,str(T/'build_portable.py'),'--parameters',str(PARAM),'--output',str(dest)])
 names=sorted(p.name for p in OUT.iterdir());need(names==sorted(p.name for p in(R/'repeat').iterdir()),'Repeat outputlist differs');receipt['all_files_byteexact']={}
 for name in names:need((OUT/name).read_bytes()==(R/'repeat'/name).read_bytes(),'Same-input nondeterminism '+name);receipt['all_files_byteexact'][name]=sha(OUT/name)
 run('independent-delivery-check',[PY,str(T/'check_portable.py'),'--directory',str(OUT),'--receipt',str(R/'INDEPENDENT-DELIVERY-CHECK.json')]);run('khronos-all4',[NODE,str(R/'validate_exports.cjs'),str(OUT),str(R/'KHRONOS-ALL4.json')]);receipt['pass']=True
except Exception as e:receipt['error']=repr(e)
finally:receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['seconds']=time.monotonic()-START;save()
need(receipt['pass'],'Portable generation failed;preserve actualevidence;no automaticamend/retry');print('PASS portableV13 first/repeat/nativeindex/anchors/actualbounds/Khronos4;no browser/app work.')
