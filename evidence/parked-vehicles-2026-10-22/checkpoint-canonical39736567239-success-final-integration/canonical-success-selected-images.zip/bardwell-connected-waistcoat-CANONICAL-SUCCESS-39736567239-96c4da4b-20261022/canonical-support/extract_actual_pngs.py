#!/usr/bin/env python3
"""Finite inert PNG/JSON extraction from this exact strictly qualified run only."""
import pathlib,json,hashlib,zipfile,stat,argparse
p=argparse.ArgumentParser();p.add_argument('--qualified',required=True,type=pathlib.Path);p.add_argument('--out',required=True,type=pathlib.Path);a=p.parse_args();q=json.loads((a.qualified/'QUALIFICATION.json').read_text());assert q['mechanical_qualified'] is True and q['run_id']==39736567239 and q['sha']=='96c4da4b1fe68e6dec3b18c15da2f14c596a60c5';a.out.mkdir(exist_ok=False);blob=a.qualified/'resident-studies.zip';digest=lambda b:hashlib.sha256(b).hexdigest();assert digest(blob.read_bytes())==q['artifact_zip_sha256'];assets=['bardwell_otis_1835','dufresne_joseph_1835','flynn_martin_1835'];wanted=set()
for kind in ['source','web']:
 for asset in assets:
  for view in ['standing-front','standing-profile','standing-threequarter','close-front']:
   wanted.add(f'tmp/teamster-studies/{kind}/{asset}.lod0-desktop-{view}.png')
  wanted.add(f'tmp/teamster-studies/{kind}/{asset}.lod0-mobile-standing-front.png')
for asset in assets:
 for width in [1280,390]:
  for view in ['front','side','threequarter']:wanted.add(f'tmp/teamster-studies/seated-driver/{asset}-{width}-{view}.png')
for kind in ['source','published']:
 for suffix in ['1280-threequarter','390-side']:wanted.add(f'tmp/teamster-studies/wagon-driver-{kind}/{suffix}.png')
rows=[];sole=[]
with zipfile.ZipFile(blob) as z:
 names=set()
 for item in z.infolist():
  n=item.filename;parts=n.rstrip('/').split('/');assert not n.startswith('/') and '\\' not in n and ':' not in parts[0] and not any(v in ('','..','.') for v in parts),'unsafe archive path';mode=stat.S_IFMT(item.external_attr>>16);assert mode in (0,stat.S_IFREG,stat.S_IFDIR),'symlink/device/special file refused';assert n not in names,'duplicate member';names.add(n)
 assert wanted<=names,sorted(wanted-names)
 for n in sorted(wanted):
  info=z.getinfo(n);assert 0<info.file_size<8*1024*1024;data=z.read(n);assert data.startswith(b'\x89PNG\r\n\x1a\n');dest=a.out/'images'/n;dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as f:f.write(data)
  rows.append({'artifact_member':n,'relative_path':str(dest.relative_to(a.out)),'bytes':len(data),'sha256':digest(data),'pixel_review':'NOT_YET_VIEWED','root_review':'NOT_ATTESTED'})
 for n in sorted(names):
  if n.endswith('-sole-contact.json') and '/teamster-studies/' in n:
   data=z.read(n);j=json.loads(data);assert j['passed'] and j['tolerance_m']==.002;sole.append({'artifact_member':n,'bytes':len(data),'sha256':digest(data),'passed':j['passed'],'tolerance_m':j['tolerance_m'],'metrics':j.get('metrics'),'provenance':j.get('provenance')})
assert len(sole)==24
(a.out/'PNG-EXTRACTION-MANIFEST.json').write_text(json.dumps({'run_id':39736567239,'head_sha':q['sha'],'artifact_zip_sha256':q['artifact_zip_sha256'],'read_only_inert_pngs_only':True,'all_archive_paths_checked':True,'extracted':rows},indent=2)+'\n');(a.out/'SOLE-RECEIPT-METRICS.json').write_text(json.dumps(sole,indent=2)+'\n');print(json.dumps({'output':str(a.out),'PNG_count':len(rows),'PNG_bytes':sum(r['bytes'] for r in rows),'sole_receipts':len(sole)}))
