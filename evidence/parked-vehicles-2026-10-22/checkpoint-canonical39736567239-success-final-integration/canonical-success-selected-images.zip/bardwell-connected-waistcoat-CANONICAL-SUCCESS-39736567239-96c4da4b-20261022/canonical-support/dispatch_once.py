#!/usr/bin/env python3
"""One opt-in canonical dispatch. Plan-only unless --dispatch; no retry of POST.
Requires final reviewed workflow pin activation before any network request.
"""
import argparse,base64,datetime,hashlib,json,pathlib,re,subprocess,time
REPO='kevinrhaas/chicago';BRANCH='steward/bardwell-connected-waistcoat-20261022';WORKFLOW='chicago-4d-humans.yml'
PINNED_WORKFLOW_SHA256='62048edeed40b6d5fe8c42feec1a031b7b2581a39ec7215ce0a20b170769c847' # Known reviewed workflow identity; NEW immutable activation JSON holds execution.
SOURCE_PIN_PATHS=['chicago/4d/data/humans/recipes/worker_1835.json', 'chicago/4d/tools/human_teamster_blend.py', 'chicago/4d/tools/human_workwear_fit.py', 'chicago/4d/tools/human_eye_components.py', 'chicago/4d/tools/human_export.py', 'chicago/4d/tools/human_export.sh', 'chicago/4d/tools/human_source_normals.py', 'chicago/4d/tools/human_sole_contact.mjs']
INPUTS={'build_teamsters':True,'build_seated_driver_study':True}
def need(ok,why):
 if not ok:raise ValueError(why)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--sha',required=True);p.add_argument('--out',required=True);p.add_argument('--dispatch',action='store_true');p.add_argument('--activation',required=True,type=pathlib.Path);a=p.parse_args();need(re.fullmatch('[0-9a-f]{40}',a.sha),'full40SHArequired')
 plan={'repository':REPO,'branch':BRANCH,'sha':a.sha,'workflow':WORKFLOW,'inputs':INPUTS,'out':a.out,'execute':a.dispatch,'pinned_workflow_sha256':PINNED_WORKFLOW_SHA256}
 if not a.dispatch:print(json.dumps(plan,indent=2));return
 need(PINNED_WORKFLOW_SHA256 is not None,'final reviewed workflow pin not frozen; no execution')
 activation=json.loads(a.activation.read_text());need(activation.get('sha')==a.sha and a.sha!='2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3','activation must bind the NEW final head; old or null head cannot execute')
 need(activation.get('branch')==BRANCH and activation.get('workflow')=='.github/workflows/chicago-4d-humans.yml' and activation.get('workflow_sha256')=='62048edeed40b6d5fe8c42feec1a031b7b2581a39ec7215ce0a20b170769c847','activation workflow/ref differs')
 need(all(activation.get(k) is True for k in ['root_released_for_one_dispatch','full_gate_passed','final_diff_reviewed','commit_and_push_verified']),'root release after actual full gate/final diff/commit/push is required')
 need(activation.get('inputs')=={'build_teamsters':True,'build_seated_driver_study':True} and re.fullmatch('[0-9a-f]{40}',activation.get('commit_tree_sha') or ''),'both true inputs and final commit tree pin required')
 need(set(activation.get('source_pins',{}))==set(SOURCE_PIN_PATHS),'exact eight final runtime source pins required')
 for pin in activation['source_pins'].values():need(set(pin)=={'git_blob_sha','sha256'} and re.fullmatch('[0-9a-f]{40}',pin.get('git_blob_sha') or '') and re.fullmatch('[0-9a-f]{64}',pin.get('sha256') or ''),'final source blob/hash pin missing')
 activation_sha256=hashlib.sha256(a.activation.read_bytes()).hexdigest()
 out=pathlib.Path(a.out);need(out.is_absolute() and str(out).startswith('/workspace/shared/'),'outside shared receipt required');need(not out.exists(),'receipt exists; reconcile without redispatch')
 def api(endpoint,body=None):
  args=['gh','api','--method','GET' if body is None else 'POST','repos/'+REPO+'/'+endpoint]
  if body is not None:args+=['--input','-']
  r=subprocess.run(args,input=None if body is None else json.dumps(body),text=True,capture_output=True,timeout=45);need(r.returncode==0,'normalGitHubrequestfailed; no retry');return json.loads(r.stdout) if r.stdout.strip() else None
 def head():return api('git/ref/heads/'+BRANCH)['object']['sha']
 def runs():
  r=api('actions/workflows/'+WORKFLOW+'/runs?event=workflow_dispatch&per_page=100');need(len(r['workflow_runs'])<=100,'invalidrunresponse');return r['workflow_runs']
 need(head()==a.sha,'remotehead differs beforedispatch')
 # Source code audit only: Gitblob API, never CI artifacts/logs.
 blob=api('contents/.github/workflows/'+WORKFLOW+'?ref='+a.sha);need(blob.get('encoding')=='base64','workflow code encoding');need(hashlib.sha256(base64.b64decode(blob['content'])).hexdigest()==PINNED_WORKFLOW_SHA256,'workflow source pin differs')
 commit=api('git/commits/'+a.sha);need(commit['tree']['sha']==activation['commit_tree_sha'],'actual final commit tree differs')
 for path,expected in activation['source_pins'].items():
  blob=api('contents/'+path+'?ref='+a.sha);need(blob.get('encoding')=='base64','final source encoding differs: '+path);need({'git_blob_sha':blob['sha'],'sha256':hashlib.sha256(base64.b64decode(blob['content'])).hexdigest()}==expected,'actual final source differs: '+path)
 before={x['id'] for x in runs()};receipt={**plan,'activation_sha256':activation_sha256,'activation':activation,'before_run_ids':sorted(before),'post_succeeded':False,'requested_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'coverage':'UNPROVEN until actual terminal mandatory jobs/steps'}
 with out.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
 def save():out.write_text(json.dumps(receipt,indent=2)+'\n')
 need(head()==a.sha,'remotehead changed immediately beforePOST')
 # Ambiguous POST error MUST leave false intent receipt; never redispatch automatically.
 api('actions/workflows/'+WORKFLOW+'/dispatches',{'ref':BRANCH,'inputs':{k:'true' for k in INPUTS}});receipt['post_succeeded']=True;save()
 for n in range(10):
  found=[r for r in runs() if r['id'] not in before and r['head_sha']==a.sha and r['head_branch']==BRANCH and r['event']=='workflow_dispatch'];receipt['runs']=found;save();need(len(found)<=1,'multipleactualruns; reconcilewithoutPOST')
  if len(found)==1:break
  if n<9:time.sleep(3)
 receipt['remote_head_after']=head();save();need(receipt['remote_head_after']==a.sha and len(receipt.get('runs',[]))==1,'incomplete discovery/headchange; reconcilewithoutPOST');print(json.dumps({'receipt':str(out),'run_id':receipt['runs'][0]['id'],'sha':a.sha}))
if __name__=='__main__':main()
