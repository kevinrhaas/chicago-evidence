#!/usr/bin/env bash
set -u
cd /workspace/chicago-waistcoat/chicago/4d || exit 2
waistcoat_gate_dir=/workspace/shared/bardwell-connected-waistcoat-preflight-V2-20261022
mkdir "$waistcoat_gate_dir" || exit 2
export PATH=/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:$PATH
export C4D_GATE_REQUIRE_READERS=1 CHECK_JOBS=4 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
export CHECK_TIMINGS="$waistcoat_gate_dir/step-wall-timings.tsv"
date -u +%FT%TZ > "$waistcoat_gate_dir/started-utc.txt"
timeout 1100s bash tools/preflight.sh > "$waistcoat_gate_dir/preflight.log" 2>&1
waistcoat_gate_result=$?
cp /tmp/preflight-check.log "$waistcoat_gate_dir/check.log"
cp /tmp/preflight-cl.log "$waistcoat_gate_dir/changelog.log"
cp /tmp/preflight-ids.log "$waistcoat_gate_dir/ids.log"
printf '%s\n' "$waistcoat_gate_result" > "$waistcoat_gate_dir/exit-code.txt"
date -u +%FT%TZ > "$waistcoat_gate_dir/closed-utc.txt"
tail -12 "$waistcoat_gate_dir/preflight.log"
exit "$waistcoat_gate_result"
