#!/usr/bin/env python3
"""One final immutable activation; refuses before actual isolated PASS/clean push."""
import datetime,hashlib,json,pathlib,subprocess
D=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/chicago-waistcoat');G=pathlib.Path('/workspace/shared/bardwell-connected-waistcoat-preflight-V2-20261022')
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
assert (G/'exit-code.txt').read_text().strip()=='0'
assert 'PREFLIGHT PASS' in (G/'preflight.log').read_text()
assert 'CHECK PASS' in (G/'check.log').read_text()
assert not git('status','--porcelain').strip(),'isolated tracked/untracked source is not clean'
a=json.loads((D/'ACTIVATION-HELD.json').read_text());sha=git('rev-parse','HEAD').decode().strip();branch=git('branch','--show-current').decode().strip();assert branch==a['branch'];assert sha!=a['source_repair_base']
remote=git('ls-remote','--heads','origin','refs/heads/'+branch).decode().split();assert remote[0]==sha,'actual remote commit differs'
workflow=git('show',sha+':'+a['workflow']);assert hashlib.sha256(workflow).hexdigest()==a['workflow_sha256']
for path,pin in a['source_pins'].items():
 data=git('show',sha+':'+path);pin.update(git_blob_sha=git('rev-parse',sha+':'+path).decode().strip(),sha256=hashlib.sha256(data).hexdigest())
peer=json.loads(pathlib.Path('/workspace/shared/human-bardwell-waistcoat-independent-source-review-20261022/EVIDENCE.json').read_text())
for path,digest in peer['proposed_hashes'].items():assert hashlib.sha256(git('show',sha+':'+path.removeprefix('proposed/'))).hexdigest()==digest
changed={path:{'git_blob_sha':git('rev-parse',sha+':'+path).decode().strip(),'sha256':hashlib.sha256(git('show',sha+':'+path)).hexdigest()} for path in git('diff','--name-only',a['source_repair_base'],sha).decode().splitlines()}
a.update(state='PARENT_AUTHORIZED_EXACT_ISOLATED_SOURCE_ONCE',sha=sha,commit_tree_sha=git('rev-parse',sha+'^{tree}').decode().strip(),root_released_for_one_dispatch=True,full_gate_passed=True,final_diff_reviewed=True,commit_and_push_verified=True,full_gate_evidence={str(f):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in G.iterdir() if f.is_file()},final_changed_files_since_source_repair_base=changed,released_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_review='38571a64c3cbc1493cc51e09dfa3a42cb0c4978ae8572741247b9075476ff37b',geometry_source_delta_only=sorted(peer['proposed_hashes']))
f=D/('FINAL-ACTIVATION-'+sha+'.json')
with f.open('x') as handle:json.dump(a,handle,indent=2);handle.write('\n')
print(f)
