# Exact96c4 Bardwell replacement proposal — ready for root review

One authorized local-only preparation completed, unchanged held helperSHA76554c64. Source96c4da4b1fe68e6dec3b18c15da2f14c596a60c5/tree686c475e41c556beaab90d1782057240094d27d0, canonical39736567239/attempt1 SUCCESS, both build inputs true, artifact12408480668, original505541888B ZIP9ca4e1e6 reused. No new download, app/Git write, browser/build or artifact-code execution. Source qualifier supplied actual mechanical PASS; root personally viewed publishedLOD0front/profile and cleared repaired upper panels for the initial visible placement increment. Photographic/full-fit/occupied acceptance remains open.

proposal/ contains exactly8 Bardwell GLBs plus four affected text files: fixture.measure.json, bardwell_otis_1835.measure.json, the existing Bardwell instance and assets/LICENSES.md. Total imported GLB bytes38,328,104 (old38,265,304,+62,800). Published4 sum6,945,368 (old6,929,220,+16,148). Existing caps/LOD/bands/root/placement/card/identity/material count are retained.

|LOD|Web bytes|Triangles|Skinned meshes / bones /material slots|
|---|---:|---:|---:|
|0|4,447,008|41,555|9 /56 /9|
|1|1,568,968|25,301|9 /56 /9|
|2|619,964|12,509|9 /56 /9|
|3|309,428|6,098|9 /56 /9|

The16-entry registry includes8 exact actual new canonical Bardwell rows plus8 exact unchanged fixture row values and their original measurement provenance. Each row's original selected-entry hash is independently checked; every SHA equals its actual installed-or-proposed file and every verdict remains true. No32-entry registry import, newly built fixture/Joseph/Martin replacement or fabricated browser/timing reading. Both public cost metadata and exact source/ZIP/member→published path links are recorded. Source canonical master remains only in original artifact (actual index52d43c7f.../10,885,374B), never executed or copied to app.

Root sequence:
1. Retain/integrate the exact reviewed96c4 source repair first. Do not apply new binary bytes with older authoring recipe. Source inputs and canonical qualification copies are in this folder.
2. Review TEXT-PREIMAGES.json before applying METADATA-LICENSE-INSTANCE.patch (text only, no binary diff). New instance changes only canonical-source wording and scoped panel-repair statement. License appends new8 hashes/bytes while retaining prior rights/historical notices. No unrelated instance fields change.
3. Copy exactly8 proposal/assets/humans GLBs listed in EXACT-IMPORT-MANIFEST.json to matching app-relative destinations, verify every SHA/bytes afterward. Preserve the eight non-Bardwell files in unchanged_other_assets. This proposal has not installed them.
4. Confirm exact16 registry inventory, then existing human_contract.py --check and human_fixture.mjs --check before the full integration gate. Root owns source/gate/changelog/status, commit/push/publish and new-head qualification. No full gate or smoke is launched here.
5. After publish compare all4 public data/humans/web files to new web hashes. Town/viewport/ground/shoe/card/LOD/performance and complete visual acceptance remain actual follow-up evidence, coordinated on root's lane.

App assets and affected metadata hash guards agree with their before-preparation bytes. No app target was changed. This packet supplies a narrow reviewable import; no previous town or movingCI result is renamed current-head green. Full asset bytes stay in proposal/ for direct root import; compact support capsule excludes all8 GLBs and pins their original artifact/member hashes for reacquisition.
