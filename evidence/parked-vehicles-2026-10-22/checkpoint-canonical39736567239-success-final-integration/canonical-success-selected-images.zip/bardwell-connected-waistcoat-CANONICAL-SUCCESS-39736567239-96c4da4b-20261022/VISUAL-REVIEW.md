# Actual visual review — repaired shoulders, initial intake only

31 new same-run LOD0 PNGs were personally viewed by ci_human_recovery, as enumerated in actual-pngs/IMAGE-REVIEW-INDEX.md. Root separately attested the new published Bardwell standing front/profile and cleared the eight-asset initial standing placement intake. The other21 extracted PNGs have no pixel-review claim.

Bardwell source and published front/profile/quarter now show connected black waistcoat panels over both shoulders and around the back, correcting the actual missing-panel V-apron defect. Published mobile front shows the same large-form coverage. Standing closed brown shoes, level trouser hems and opaque eyes remain visible. All six Bardwell named seated images retain upper panels with arms raised; wagon boards obscure lower legs/feet, so these pixels do not establish seated footwear coverage. Mobile whole-wagon figures are too small for fine tailoring review.

The shirt/waistcoat remain tight and simplified, with thin uneven neckline edges and light/speckled edge/hem artifacts. Faces/skin remain generic and simplified; hair remains serrated/clumpy. This is not photographic likeness, complete period tailoring, complete layer fit or continuous-animation acceptance. Forty inherited negative body projections remain open. Upper-body source controls and discrete sole receipts do not waive those issues.

Dufresne/Flynn retain their old missing upper-panel appearance, as expected from the16 byte-identical unchanged GLBs. They were not repaired or promoted. W01 source/published support images show an empty engineering wagon; they do not establish an occupied production interface. Named seated studies are separate.

The old published front under baseline-provenance/ is explicitly from run39712579846/source34cf, personally viewed as the earlier low V-apron comparison. It is never labeled a new-run image. No browser or artifact code was executed during qualification, extraction or packaging. Historical extraction refusal for unavailable LOD1-3 PNGs is preserved; it was an extraction-request error, not CI failure.

Town placement, public performance, full fit, occupied controls and photographic parent T1789 remain their own current-head acceptance work. Root owns all integration and further tracked changes.
