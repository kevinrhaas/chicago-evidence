# Supported source-use regeneration — advice only

From the resolved merged chicago/4d root, using the required Python3.11 environment:

```sh
python3 tools/compile_source_use.py
python3 tools/compile_source_use.py --check
```

The supported producer writes data/sidecars/1812/sources/uses.json, data/sidecars/1835/sources/index.json, data/sidecars/1904/sources/uses.json and docs/measurements/source_use_coverage.md, plus its other per-source outputs. It reads registered sources and general scene sidecars, not those conflicting generated source outputs. Resolve authored inputs first, regenerate, inspect the actual diff and stage generated results. Do not hand-union generated JSON. If upstream general scene sidecars themselves require regeneration, use the existing dependency tail `node tools/rederive.mjs --tail tools/compile_scene.py` instead of duplicating producers or rebuilding everything. No regeneration was run by this packaging task.
