# SPDX-License-Identifier: CC0-1.0
"""Prepare bounded HEAD/ORBIT/PINNA/THROATLATCH source only, never geometry."""
from pathlib import Path
import ast,json,hashlib,difflib
here=Path(__file__).resolve().parent;out=here/'proposed';base=Path('/workspace/shared/horse-anatomical-static-junction-repair-clarified-source-20261022/proposed')
oldcontrols=(base/'anatomy-authoring-controls.json').read_bytes();oldsource=(base/'quad_cage_authoring.py').read_text()
assert hashlib.sha256(oldcontrols).hexdigest()=='cbcfd75f6d933f6dba3dd95b977582776f94453760383c4b22a6e1590e796d2c'
assert hashlib.sha256(oldsource.encode()).hexdigest()=='0d046d6337a37aa0800ee11742672eab3400a47052d4ecf2c7d804844a0f0582'
c=json.loads(oldcontrols);old=json.loads(oldcontrols)
# Keep body/port/lower-neck controls0..7 and every limb/collar/cup/contact
# unchanged. Reconstruct only upper neck→poll→jaw→orbital band→nasal/muzzle.
c['body_profile']=c['body_profile'][:8]+[
 [0,1.680,.700,.155,.185],
 [0,1.840,.800,.125,.125],
 [0,1.800,.910,.140,.180],
 [0,1.790,.970,.128,.145],
 [0,1.750,1.050,.105,.115],
 [0,1.660,1.160,.080,.080],
 [0,1.630,1.250,.088,.070],
 [0,1.625,1.285,.070,.060],
]
c['body_ring_radial_z_m']=[0.]*8+[-.115,-.055,.020,.015,.015,0.,0.,0.]
c['body_regions']=c['body_regions'][:8]+['neck_middle','poll','cheek_jaw','orbital_band','nasal_bridge','nose','muzzle','upper_lower_lip_front']
c['muzzle_material_start_interval']=13
c['nostril_authoring']['root_body_interval']=13
c['eye_authoring']={
 'root_body_interval':10,'left_column':0,'right_column':7,
 'quad_uv_center_left':[.60,.50],'quad_uv_center_right':[.40,.50],
 'sections':[
  {'radius_u':.35,'radius_v':.46,'normal_offset_m':.004,'material':0},
  {'radius_u':.26,'radius_v':.38,'normal_offset_m':.007,'material':0},
  {'radius_u':.18,'radius_v':.34,'normal_offset_m':.010,'material':0},
  {'radius_u':.17,'radius_v':.32,'normal_offset_m':.012,'material':3},
  {'radius_u':.025,'radius_v':.025,'normal_offset_m':.017,'material':3},
 ],
 'target':'Integrated brow/orbit and upper/lower lid volume on the actual cheek-to-orbital-band quad, with wet convex eye surface. UV rings stay strictly inside the real aperture.',
 'uncertainty':'All radii/depths are original reconstruction controls, not measured photo anatomy. Iris/lid detail, retopology and biological gaze remain unqualified.'
}
c['ear_authoring']={
 'root_body_interval':9,'left_column':2,'right_column':5,
 'root_placement':'x/z mean of actual aperture, y max(aperture)+root_raise_above_perimeter_max_m',
 'root_raise_above_perimeter_max_m':.018,
 'blade_length_m':.155,'profile_fractions':[0.,.24,.62,1.],
 'half_width_profile_m':[.026,.045,.034,.0025],
 'half_depth_profile_m':[.010,.014,.010,.002],
 'splay_yaw_deg':28.,'outward_tip_offset_x_m':.010,'backward_tip_offset_z_m':-.012,
 'concha_recession_m':.010,
 'target':'Broad lower/middle pinna tapering to a point, locally recessed front and outward/forward-facing opening rather than two edge-on spikes.',
 'uncertainty':'Ear attention/yaw/size and all dimensions reconstructed; this closed initial mass is not a claim of anatomically exact pinna tissue thickness or historical grooming.'
}
c['head_largeform_amendment']={
 'base_actual_asset_sha256':'772dab7c1b9ee2bebbf0aba3d75049835c45044540ef06e3b58b522ba5add296',
 'source_observation_refs':['vassil_2014_konik_horse_anatomy','joselodos_2025_horse_anatomy','ellenberger_baum_dittrich_equine_plates'],
 'protected_numeric_controls':['body_profile0..7','body_root_holes','fore_l','hind_l','proposed_contacts_m','limb_aperture_collar_m','nostril cup sections','all material factors/roughness'],
 'intentional_changes':['upper-neck cross-section tilt for crest/throatlatch','broader/deeper cheek/jaw and shorter posterior-to-muzzle head','one added orbital-band station','boundary-parametric brow/lids/cornea placement','pinna width/yaw/root placement/concha mass','nose/muzzle radius increases5mm; nostril port index follows added orbital band'],
 'subdivision_halo':'Neighboring head/neck positions/normals can change under subdivision; no unmeasured final-mesh byte preservation claim. Existing body/leg junction methods stay unchanged and require actual requalification.',
 'not_claimed':['modern reference breed/individual/markings','photographic master','hair/UV/PBR','rig/animation/tack','new geometry/collision or browser success']
}
c['schema']='original_equine_control_cage_authoring_v0.3_head_largeforms_unexecuted'
c['status']='UNEXECUTED bounded head/orbit/pinna/throatlatch source proposal against actual772; no geometry or photographic acceptance'
(out/'anatomy-authoring-controls.json').write_text(json.dumps(c,indent=2)+'\n')
s=oldsource
oldbody=""" for row in c['body_profile']:
  x,y,z,rx,ry=row;rings.append([cage.vertex((x+rx*math.cos(k*2*math.pi/N),y+ry*math.sin(k*2*math.pi/N),z)) for k in range(N)])"""
newbody=""" radial_z=c.get('body_ring_radial_z_m',[0.]*len(c['body_profile']))
 if len(radial_z)!=len(c['body_profile']):raise ValueError('One explicit radial-Z coefficient per body ring required')
 for j,row in enumerate(c['body_profile']):
  x,y,z,rx,ry=row;rz=radial_z[j]
  rings.append([cage.vertex((x+rx*math.cos(k*2*math.pi/N),y+ry*math.sin(k*2*math.pi/N),z+rz*math.sin(k*2*math.pi/N))) for k in range(N)])"""
assert oldbody in s;s=s.replace(oldbody,newbody)
s=s.replace("4 if j>=12 else 0", "4 if j>=c.get('muzzle_material_start_interval',12) else 0")
helper='''
def attach_quad_orbit(cage,loop,corners,settings,side,region):
 # Parameterize the real cheek aperture, avoiding a free ellipse that can leave
 # the skin opening. All rings remain in the strict interior of its UV square.
 if len(corners)!=4 or len(loop)!=8:raise ValueError('One quad and one boundary midpoint split required for orbit')
 normal=aperture_normal(cage,loop);u0,v0=settings['quad_uv_center_left' if side>0 else 'quad_uv_center_right']
 A,B,C,D=[cage.v[i] for i in corners]
 def on_patch(u,v):return tuple((1-v)*((1-u)*A[k]+u*B[k])+v*((1-u)*D[k]+u*C[k]) for k in range(3))
 previous_ru=previous_rv=1.;previous_depth=-1.
 for section in settings['sections']:
  ru,rv,depth=section['radius_u'],section['radius_v'],section['normal_offset_m']
  if not (0<ru<previous_ru and 0<rv<previous_rv and previous_depth<depth):raise ValueError('Orbit rings must nest and advance outward')
  if not (0<u0-ru<u0+ru<1 and 0<v0-rv<v0+rv<1):raise ValueError('Orbit UV contour outside actual aperture')
  points=[]
  for k in range(len(loop)):
   t=-3*math.pi/4+2*math.pi*k/len(loop);p=on_patch(u0+ru*math.cos(t),v0+rv*math.sin(t))
   points.append(tuple(p[j]+depth*normal[j] for j in range(3)))
  ring=[cage.vertex(p) for p in points];cage.bridge(loop,ring,section['material'],region);loop=ring
  previous_ru,previous_rv,previous_depth=ru,rv,depth
 cage.face(list(reversed(loop)),settings['sections'][-1]['material'],region)
'''
anchor='\ndef build(c):'
assert anchor in s;s=s.replace(anchor,helper+anchor)
a=s.index(" ear=c['ear_authoring']");b=s.index(" nose=c['nostril_authoring']",a)
s=s[:a]+""" ear=c['ear_authoring']
 for side,column in [(1,ear['left_column']),(-1,ear['right_column'])]:
  loop=cage.split_boundary(cage.remove_patch([grid[ear['root_body_interval'],column]]))
  aperture=[cage.v[i] for i in loop];center=average(aperture);x=center[0];y=max(p[1] for p in aperture)+ear['root_raise_above_perimeter_max_m'];z=center[2]
  angle=math.radians(ear['splay_yaw_deg']);u=(math.cos(angle),0,-side*math.sin(angle));v=(side*math.sin(angle),0,math.cos(angle))
  profile=[]
  for t,width,depth in zip(ear['profile_fractions'],ear['half_width_profile_m'],ear['half_depth_profile_m']):
   profile.append([x+side*ear['outward_tip_offset_x_m']*t,y+ear['blade_length_m']*t,z+ear['backward_tip_offset_z_m']*t,width,depth])
  warps=[]
  for j,row in enumerate(profile):
   exposure=math.sin(math.pi*ear['profile_fractions'][j])
   warps.append(lambda p,t,e=exposure,v=v:tuple(p[k]-v[k]*ear['concha_recession_m']*max(0,math.sin(t))**2*e for k in range(3)))
  attach(cage,loop,profile,u,v,'ear_'+str(side),warps=warps,per_faces=lambda j,k,angles:5 if j in (1,2) and math.sin(angles[k])+math.sin(angles[(k+1)%len(angles)])>0 else 0)
 eye=c['eye_authoring']
 for side,column in [(1,eye['left_column']),(-1,eye['right_column'])]:
  face=grid[eye['root_body_interval'],column];corners=cage.f[face]
  loop=cage.split_boundary(cage.remove_patch([face]));attach_quad_orbit(cage,loop,corners,eye,side,'orbit_'+str(side))
"""+s[b:]
ast.parse(s);(out/'quad_cage_authoring.py').write_text(s)
for name,oldtext,newtext in [('quad_cage_authoring.py',oldsource,s),('anatomy-authoring-controls.json',oldcontrols.decode(),(out/'anatomy-authoring-controls.json').read_text())]:
 (here/(name+'.patch')).write_text(''.join(difflib.unified_diff(oldtext.splitlines(True),newtext.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
pins=[{'file':name,'preimage_sha256':hashlib.sha256((base/name).read_bytes()).hexdigest(),'proposed_sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()} for name in ['quad_cage_authoring.py','anatomy-authoring-controls.json']]
(here/'EXACT-PREIMAGES.json').write_text(json.dumps(pins,indent=2)+'\n');print(json.dumps({'status':'HEAD source/controls prepared only; geometry NOT run','pins':pins},indent=2))
