# T2800: bounded head large-form revision, unexecuted

The actual repaired 772 horse passed the bounded proper-crossing/topology screen but failed appearance review. Root viewed the side and quarter images and rejected it as an anatomical or photographic master. It is not installed. This proposal changes head, orbit, pinna and upper-neck/throatlatch source forms before hair or surface detail. No mesh, image capture, app install or ticket closure is included here.

The preserved actual appearance proof is `/workspace/shared/horse-anatomical-junction-repair-appearance-proof-20261022.tar.gz`, SHA256 `631e5003cd0205db60150a3726b07c2cb36532cac04ce32efeec0f46450c638d` (664,171 bytes). The installed app remains the older 89b048 horse, not 772. `baseline_glb_sha256` in the inherited controls identifies that older installed baseline; `head_largeform_amendment.base_actual_asset_sha256` explicitly identifies 772 as this source revision's parent.

## Actual reference pixels and reconstruction boundary

`REFERENCE-PIXEL-OBSERVATIONS.json` records three image hashes, dimensions, visible landmarks, occlusions, qualitative navigation windows and uncertainty. The files were actually opened as images. The modern CC0 Konik and Joselodos photos show rounded masseter/jaw and muzzle volume, substantial eyelid/orbit relief, broad pinna leaves and a distinct jaw/neck transition. The public-domain head plate, especially figures30/31/36/37, resolves the masseter/mandibular ramus, orbit, lids and pinna/concha relationships. These are anatomy analogies. Their camera poses and scales are unsolved, and some landmarks are hidden by forelock. No pixel distance is promoted to metres, and no historical Chicago breed, individual, owner, marking or exact grooming is inferred. Source/licensing authority remains the cleared T2799 register.

## Concrete source changes

| Observed problem in actual772 | Bounded authored change | What remains unproven |
| --- | --- | --- |
| Flat wedge-like cheek and narrow muzzle | Increase cheek radiusX .115→.140m and radiusY .150→.180m; shorten the posterior head by moving the poll/cheek forward while keeping lip-frontZ1.285m; increase nose/muzzle radii5mm | Rounded jaw/ramus, face angle and front width after subdivision |
| Weak throatlatch/continuous straight neck funnel | Tilt only upper cross-sections using explicit radialZ coefficients: neck_middle−.115m, poll−.055m, cheek+.020m, orbital/nasal+.015m | Whether the ventral throat notch is readable or too sharp; no new crossing guarantee |
| Tiny detached-looking eyes | Add one orbital-band station; derive the brow/lid/convex eye rings from the actual removed cheek quad using strictly interior nested UV contours and outward-normal offsets4–17mm | Lid shape, iris/gaze, visible aperture and biological plausibility; no claim that dark material alone fixes the eye |
| Narrow edge-on spike ears | Derive roots from actual poll aperture;155mm blade, max90mm full width,28° yaw,10mm concha recess, tapered leaf; local concha warp uses ear frame | Subdivided silhouette, actual thickness/folds/root continuity and ear pose |

The orbit surface center before its outward sculpt is `[±.1278799144,1.8323116347,.9440181760]m`. This is derived from the authored patch, not measured from a photograph. The ear's source control-section projected quarter width grows47.03→87.36mm; this is not an actual subdivided image width. The throat control separation grows; it is an explicit hypothesis requiring the actual side view, not acceptance evidence.

Exact old/new source hashes are in `EXACT-PREIMAGES.json`; `.patch` files describe the two replacements. The source is based on the repaired clarified producer0d046d63 and controlscbcfd75f that generated actual772. The source arithmetic review does not execute its geometry entry point.

## Protected inputs and honest scope

Body profile rows0–7, limb profiles, lower/ventral port indices,18mm collars, boundary-derived nostril-cup algorithm and section values, four authored sole controls, datum definitions and every material factor remain unchanged. Shared cage/junction/nostril helpers are AST-identical. The inserted head station shifts the nostril and muzzle-material interval12→13 intentionally. Upper head geometry, ear/orbit topology, upper-neck silhouette and nose dimensions change. Subdivision can affect neighboring geometry and normals; protected inputs do not establish byte-identical final body geometry or carry forward old collision clearance.

All source coordinates retain metres,+Y up,+Z forward,+X anatomical left. Root remains the arithmetic mean of the four authored sole-center controls. The previous actual sole-vertex meanZ was+.5903095mm; do not redefine that separate measurement as zero. No runtime translation/rescaling, old skin weights, clips, tack, rider sockets or obsolete certification is carried over. Existing root/collar embedding repair is preserved as source, and the earlier failed4fa3 mesh with586 crossings remains preserved separately.

## Finite next step, only after independent review and root lane release

1. Independently review the proposed source, quad contour ordering, pinna attachment/root frame and declared scope. Source-only review cannot prove embedding or anatomy.
2. Root may authorize one nice10/single-thread static build with a60s whole-process limit into a fresh outside-app folder. The unchanged producer CLI is `python3 proposed/quad_cage_authoring.py --execute-reviewed-source --output-dir <NEW_FOLDER>`. Do not run it merely because it is documented here. Preserve terminal, exact input hashes and actual output, including any failure; no blind retry.
3. Decode that actual output independently. Recheck exact exported positions/indices, finite unit normals, connected two-owner edges, vertex-link cycles/Euler, soles and datum, complete bounded proper-triangle crossing screen and region witnesses. Zero proper crossings alone does not prove coplanar-contact/containment freedom. The772 clearance does not transfer automatically.
4. Only after root's separate appearance-lane release, capture the exact old four baseline cameras/materials/lights/native frame, all-part clip guards and owned cleanup. Review actual side and quarter images. A separate explicitly declared head-detail view may clarify the orbit/pinna but must not replace the matched whole-horse views or disguise silhouette defects.
5. Root decides whether the large forms improved enough to continue. Any failed build/screen/view remains in the evidence packet. No installation or T2800 completion follows from this proposal.

`SOURCE-ONLY-REVIEW.json` currently passes16 AST/data/arithmetic checks. Its list of unproven actual properties is part of the handoff. Hair/mane/tail, UV/PBR coat and eye microdetail, hindlimb/joint anatomy, rig-ready topology, fitted tack, animation/boarding, LODs, browser costs and photographic approval remain open.
