# SPDX-License-Identifier: CC0-1.0
"""Original static horse authoring source. UNEXECUTED geometry draft.

The only entry point requires explicit --execute-reviewed-source and a NEW output
folder. Source compilation/JSON checks do not call build(). No old GLB is read or
modified. This is not a qualified anatomical/photo master or a rigged export.
"""
import argparse, collections, json, math, pathlib, struct

def average(points):
 return tuple(sum(p[k] for p in points)/len(points) for k in range(3))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def sub(a,b):return tuple(a[k]-b[k] for k in range(3))
def length(a):return math.sqrt(sum(x*x for x in a))
def edge(a,b):return tuple(sorted((a,b)))

class Cage:
 def __init__(self):self.v=[];self.f=[];self.material=[];self.region=[];self.sharp=set()
 def vertex(self,p):
  if len(p)!=3 or not all(math.isfinite(x) for x in p):raise ValueError('Nonfinite authoring vertex')
  self.v.append(tuple(p));return len(self.v)-1
 def face(self,ids,material=0,region='body'):
  if len(ids)<3 or len(set(ids))!=len(ids):raise ValueError('Degenerate source face')
  self.f.append(tuple(ids));self.material.append(material);self.region.append(region);return len(self.f)-1
 def bridge(self,a,b,material=0,region='body',per_face=None):
  if len(a)!=len(b):raise ValueError('Boundary cardinality mismatch')
  for k in range(len(a)):
   self.face([a[k],a[(k+1)%len(a)],b[(k+1)%len(b)],b[k]],per_face(k) if per_face else material,region)
 def split_boundary(self,loop):
  # Insert midpoints into every retained face owning a boundary edge. Adjacent
  # ngons remain explicit and subdivision handles them; no hidden T-junctions.
  mids={edge(a,b):self.vertex(average([self.v[a],self.v[b]])) for a,b in zip(loop,loop[1:]+loop[:1])}
  for i,face in enumerate(self.f):
   if face is None:continue
   expanded=[]
   for a,b in zip(face,face[1:]+face[:1]):
    expanded.append(a)
    if edge(a,b) in mids:expanded.append(mids[edge(a,b)])
   self.f[i]=tuple(expanded)
  result=[]
  for a,b in zip(loop,loop[1:]+loop[:1]):result.extend([a,mids[edge(a,b)]])
  return result
 def remove_patch(self,face_indices):
  counts=collections.Counter();directed=[]
  for fi in face_indices:
   face=self.f[fi]
   if face is None:raise ValueError('Overlapping source patches')
   directed.extend(zip(face,face[1:]+face[:1]));counts.update(edge(a,b) for a,b in zip(face,face[1:]+face[:1]))
  boundary=[(a,b) for a,b in directed if counts[edge(a,b)]==1]
  nexts=dict(boundary)
  if len(nexts)!=len(boundary):raise ValueError('Patch has a branched boundary')
  first=boundary[0][0];loop=[first]
  while nexts[loop[-1]]!=first:
   loop.append(nexts[loop[-1]])
   if len(loop)>len(boundary):raise ValueError('Unclosed source boundary')
  if len(loop)!=len(boundary):raise ValueError('Multiple source boundary loops')
  for fi in face_indices:self.f[fi]=None
  return loop
 def compact(self):
  active=[i for i,f in enumerate(self.f) if f is not None]
  self.f=[self.f[i] for i in active];self.material=[self.material[i] for i in active];self.region=[self.region[i] for i in active]
 def orient_closed(self):
  self.compact();owners=collections.defaultdict(list)
  for fi,f in enumerate(self.f):
   for a,b in zip(f,f[1:]+f[:1]):owners[edge(a,b)].append((fi,a,b))
  if any(len(v)!=2 for v in owners.values()):raise ValueError('Source cage must be closed two-manifold at every edge')
  adjacency=collections.defaultdict(list)
  for records in owners.values():
   (i,a,b),(j,c,d)=records;same=(a,b)==(c,d);adjacency[i].append((j,same));adjacency[j].append((i,same))
  flip={0:False};q=[0]
  while q:
   i=q.pop()
   for j,same in adjacency[i]:
    wanted=flip[i]^same
    if j in flip and flip[j]!=wanted:raise ValueError('Nonorientable authoring surface')
    if j not in flip:flip[j]=wanted;q.append(j)
  if len(flip)!=len(self.f):raise ValueError('Expected one connected anatomical skin cage')
  self.f=[tuple(reversed(f)) if flip[i] else f for i,f in enumerate(self.f)]
  volume=0.
  for f in self.f:
   for k in range(1,len(f)-1):volume+=sum(self.v[f[0]][j]*cross(self.v[f[k]],self.v[f[k+1]])[j] for j in range(3))/6
  if abs(volume)<1e-12:raise ValueError('Zero signed source volume')
  if volume<0:self.f=[tuple(reversed(f)) for f in self.f]
 def subdivide(self):
  # Ordinary Catmull-Clark with explicit sharp sole edges. Material and region
  # labels follow source faces; this is not automatic rig-ready retopology.
  fp=[average([self.v[i] for i in f]) for f in self.f]
  owners=collections.defaultdict(list);incident=collections.defaultdict(list)
  for fi,f in enumerate(self.f):
   for v in f:incident[v].append(fi)
   for a,b in zip(f,f[1:]+f[:1]):owners[edge(a,b)].append(fi)
  if any(len(v)!=2 for v in owners.values()):raise ValueError('Nonmanifold subdivision input')
  neighbors=collections.defaultdict(list)
  for a,b in owners:neighbors[a].append(b);neighbors[b].append(a)
  new=Cage()
  for i,p in enumerate(self.v):
   sharp=[j for j in neighbors[i] if edge(i,j) in self.sharp]
   if len(sharp)>=3:point=p
   elif len(sharp)==2:point=tuple((6*p[k]+self.v[sharp[0]][k]+self.v[sharp[1]][k])/8 for k in range(3))
   else:
    n=len(incident[i]);F=average([fp[j] for j in incident[i]]);E=average([average([p,self.v[j]]) for j in neighbors[i]])
    point=tuple((F[k]+2*E[k]+(n-3)*p[k])/n for k in range(3))
   new.vertex(point)
  ep={}
  for e,faces in owners.items():
   a,b=e
   point=average([self.v[a],self.v[b]]) if e in self.sharp else average([self.v[a],self.v[b],fp[faces[0]],fp[faces[1]]])
   ep[e]=new.vertex(point)
   if e in self.sharp:new.sharp.update([edge(a,ep[e]),edge(ep[e],b)])
  facepoints=[new.vertex(p) for p in fp]
  for fi,f in enumerate(self.f):
   for k,v in enumerate(f):new.face([v,ep[edge(v,f[(k+1)%len(f)])],facepoints[fi],ep[edge(f[k-1],v)]],self.material[fi],self.region[fi])
  return new

def ring_positions(center,rx,ry,u,v,angles,warp=None):
 result=[]
 for t in angles:
  p=tuple(center[k]+rx*math.cos(t)*u[k]+ry*math.sin(t)*v[k] for k in range(3))
  result.append(warp(p,t) if warp else p)
 return result

def aperture_normal(cage,loop):
 # Newell normal of the real removed-face perimeter. Source winding is retained;
 # global orientation repair is not used to pretend an embedding is correct.
 n=[0.,0.,0.]
 for a,b in zip(loop,loop[1:]+loop[:1]):
  p,q=cage.v[a],cage.v[b]
  n[0]+=(p[1]-q[1])*(p[2]+q[2]);n[1]+=(p[2]-q[2])*(p[0]+q[0]);n[2]+=(p[0]-q[0])*(p[1]+q[1])
 L=length(n)
 if L<1e-10:raise ValueError('Collapsed aperture normal')
 return tuple(x/L for x in n)

def ordered_aperture_angles(cage,loop,u,v):
 # Keep the exact cyclic source order. The failed generic least-distance frame
 # could choose either winding; it never certified a nonfolded bridge.
 points=[cage.v[i] for i in loop];center=average(points)
 projected=[(sum((p[k]-center[k])*u[k] for k in range(3)),sum((p[k]-center[k])*v[k] for k in range(3))) for p in points]
 area=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(projected,projected[1:]+projected[:1]))
 if abs(area)<1e-10:raise ValueError('Aperture projection collapsed')
 sign=1 if area>0 else -1;rx=max(abs(p[0]) for p in projected);ry=max(abs(p[1]) for p in projected)
 if min(rx,ry)<1e-8:raise ValueError('Thin aperture projection')
 raw=[math.atan2(y/ry,x/rx) for x,y in projected];angles=[raw[0]]
 for value in raw[1:]:
  while sign*(value-angles[-1])<=1e-10:value+=sign*2*math.pi
  if sign*(value-angles[-1])>=math.pi:raise ValueError('Non-star-shaped aperture order')
  angles.append(value)
 gap=sign*(angles[0]+sign*2*math.pi-angles[-1])
 if not 1e-10<gap<math.pi:raise ValueError('Aperture angular cycle folds')
 return angles

def outside_aperture_collar(cage,loop,distance,region):
 normal=aperture_normal(cage,loop)
 if normal[1]>=-.2:raise ValueError('Limb port must face below/outside trunk')
 ring=[cage.vertex(tuple(cage.v[i][k]+distance*normal[k] for k in range(3))) for i in loop]
 cage.bridge(loop,ring,0,region)
 return ring

def inset_aperture_cup(cage,loop,sections,region):
 # Each projected ring is a strict homothetic contraction of the ACTUAL opening;
 # normal recession adds no tangential relocation. No unrelated ellipse is fit.
 points=[cage.v[i] for i in loop];center=average(points);normal=aperture_normal(cage,loop)
 for a,b in zip(points,points[1:]+points[:1]):
  fan=cross(sub(a,center),sub(b,center))
  if sum(fan[k]*normal[k] for k in range(3))<=1e-10:raise ValueError('Aperture center must lie in strict projected kernel')
 previous=1.
 for section in sections:
  scale=section['contraction'];offset=section['normal_offset_m']
  if not 0<scale<previous:raise ValueError('Cup rings must contract strictly')
  ring=[cage.vertex(tuple(center[k]+scale*(p[k]-center[k])+offset*normal[k] for k in range(3))) for p in points]
  cage.bridge(loop,ring,section['material'],region);loop=ring;previous=scale
 cage.face(list(reversed(loop)),sections[-1]['material'],region)

def attach(cage,loop,profile,u,v,region,material_at=lambda j:0,warps=None,per_faces=None,sole=False,angles_override=None):
 # Choose one cyclic frame using the actual aperture to avoid an arbitrary
 # twisted bridge. Subsequent rings keep exactly that frame and cardinality.
 n=len(loop);first=profile[0];options=[]
 for winding in [1,-1]:
  for phase in range(n):
   angles=[(phase+winding*k)*2*math.pi/n for k in range(n)]
   p=ring_positions(first[:3],first[3],first[4],u,v,angles)
   score=sum(sum((cage.v[a][j]-b[j])**2 for j in range(3)) for a,b in zip(loop,p));options.append((score,angles))
 angles=angles_override if angles_override is not None else min(options,key=lambda item:item[0])[1]
 for j,row in enumerate(profile):
  points=ring_positions(row[:3],row[3],row[4],u,v,angles,warps[j] if warps else None)
  ring=[cage.vertex(p) for p in points]
  cage.bridge(loop,ring,material_at(j),region,(lambda k:per_faces(j,k,angles)) if per_faces else None);loop=ring
 if sole:cage.sharp.update(edge(a,b) for a,b in zip(loop,loop[1:]+loop[:1]))
 cage.face(list(reversed(loop)),material_at(len(profile)-1),region)
 return loop

def attach_quad_orbit(cage,loop,corners,settings,side,region):
 # Parameterize the real cheek aperture, avoiding a free ellipse that can leave
 # the skin opening. All rings remain in the strict interior of its UV square.
 if len(corners)!=4 or len(loop)!=8:raise ValueError('One quad and one boundary midpoint split required for orbit')
 normal=aperture_normal(cage,loop);u0,v0=settings['quad_uv_center_left' if side>0 else 'quad_uv_center_right']
 A,B,C,D=[cage.v[i] for i in corners]
 def on_patch(u,v):return tuple((1-v)*((1-u)*A[k]+u*B[k])+v*((1-u)*D[k]+u*C[k]) for k in range(3))
 previous_ru=previous_rv=1.;previous_depth=-1.
 for section in settings['sections']:
  ru,rv,depth=section['radius_u'],section['radius_v'],section['normal_offset_m']
  if not (0<ru<previous_ru and 0<rv<previous_rv and previous_depth<depth):raise ValueError('Orbit rings must nest and advance outward')
  if not (0<u0-ru<u0+ru<1 and 0<v0-rv<v0+rv<1):raise ValueError('Orbit UV contour outside actual aperture')
  points=[]
  for k in range(len(loop)):
   t=-3*math.pi/4+2*math.pi*k/len(loop);p=on_patch(u0+ru*math.cos(t),v0+rv*math.sin(t))
   points.append(tuple(p[j]+depth*normal[j] for j in range(3)))
  ring=[cage.vertex(p) for p in points];cage.bridge(loop,ring,section['material'],region);loop=ring
  previous_ru,previous_rv,previous_depth=ru,rv,depth
 cage.face(list(reversed(loop)),settings['sections'][-1]['material'],region)

def build(c):
 cage=Cage();N=c['body_sides'];rings=[];grid={}
 radial_z=c.get('body_ring_radial_z_m',[0.]*len(c['body_profile']))
 if len(radial_z)!=len(c['body_profile']):raise ValueError('One explicit radial-Z coefficient per body ring required')
 for j,row in enumerate(c['body_profile']):
  x,y,z,rx,ry=row;rz=radial_z[j]
  rings.append([cage.vertex((x+rx*math.cos(k*2*math.pi/N),y+ry*math.sin(k*2*math.pi/N),z+rz*math.sin(k*2*math.pi/N))) for k in range(N)])
 for j in range(len(rings)-1):
  for k in range(N):grid[j,k]=cage.face([rings[j][k],rings[j][(k+1)%N],rings[j+1][(k+1)%N],rings[j+1][k]],4 if j>=c.get('muzzle_material_start_interval',12) else 0,c['body_regions'][j])
 cage.face(list(reversed(rings[0])),0,'tail_dock');cage.face(rings[-1],4,'lip_front')
 for hole in c['body_root_holes']:
  name=hole['part'];side=1 if name.endswith('_l') else -1
  loop=cage.remove_patch([grid[hole['body_interval'],k] for k in hole['circumferential_columns']])
  rows=c['fore_l' if name.startswith('fore') else 'hind_l'];profile=[[side*x,y,z,rx,rz] for x,y,z,rx,rz in rows]
  loop=outside_aperture_collar(cage,loop,c['limb_aperture_collar_m'],name)
  if min(cage.v[i][1] for i in loop)<=profile[0][1]+.005:raise ValueError('First limb ring must be below whole aperture collar')
  angles=ordered_aperture_angles(cage,loop,(1,0,0),(0,0,1))
  hoof_start=len(profile)-3
  attach(cage,loop,profile,(1,0,0),(0,0,1),name,lambda j:2 if j>=hoof_start else 0,sole=True,angles_override=angles)
 ear=c['ear_authoring']
 for side,column in [(1,ear['left_column']),(-1,ear['right_column'])]:
  loop=cage.split_boundary(cage.remove_patch([grid[ear['root_body_interval'],column]]))
  aperture=[cage.v[i] for i in loop];center=average(aperture);x=center[0];y=max(p[1] for p in aperture)+ear['root_raise_above_perimeter_max_m'];z=center[2]
  angle=math.radians(ear['splay_yaw_deg']);u=(math.cos(angle),0,-side*math.sin(angle));v=(side*math.sin(angle),0,math.cos(angle))
  profile=[]
  for t,width,depth in zip(ear['profile_fractions'],ear['half_width_profile_m'],ear['half_depth_profile_m']):
   profile.append([x+side*ear['outward_tip_offset_x_m']*t,y+ear['blade_length_m']*t,z+ear['backward_tip_offset_z_m']*t,width,depth])
  warps=[]
  for j,row in enumerate(profile):
   exposure=math.sin(math.pi*ear['profile_fractions'][j])
   warps.append(lambda p,t,e=exposure,v=v:tuple(p[k]-v[k]*ear['concha_recession_m']*max(0,math.sin(t))**2*e for k in range(3)))
  attach(cage,loop,profile,u,v,'ear_'+str(side),warps=warps,per_faces=lambda j,k,angles:5 if j in (1,2) and math.sin(angles[k])+math.sin(angles[(k+1)%len(angles)])>0 else 0)
 eye=c['eye_authoring']
 for side,column in [(1,eye['left_column']),(-1,eye['right_column'])]:
  face=grid[eye['root_body_interval'],column];corners=cage.f[face]
  loop=cage.split_boundary(cage.remove_patch([face]));attach_quad_orbit(cage,loop,corners,eye,side,'orbit_'+str(side))
 nose=c['nostril_authoring']
 for side,columns in [(1,nose['left_columns']),(-1,nose['right_columns'])]:
  loop=cage.split_boundary(cage.remove_patch([grid[nose['root_body_interval'],col] for col in columns]))
  inset_aperture_cup(cage,loop,nose['cup_sections'],'nostril_'+str(side))
 cage.orient_closed()
 authored={'vertices':len(cage.v),'faces':len(cage.f),'sharp_edges':len(cage.sharp),'regions':dict(collections.Counter(cage.region))}
 for _ in range(c['subdivision']['iterations_first_preview']):cage=cage.subdivide()
 cage.orient_closed()
 return cage,authored

def export_static(cage,c,out,authored):
 # One shared, connected surface; material batches duplicate only exported
 # attribute arrays, not source coordinates. No old skeleton/socket is implied.
 materials=[]
 settings=c['material_reconstruction']
 for key in ['coat','hair','hoof','eye','muzzle','inner_ear']:
  materials.append({'name':'equine_'+key,'pbrMetallicRoughness':{'baseColorFactor':settings[key+'_rgb_linear']+[1],'metallicFactor':0,'roughnessFactor':settings[key+'_roughness']}})
 normals=[[0.,0.,0.] for _ in cage.v];triangles=[]
 for fi,f in enumerate(cage.f):
  for k in range(1,len(f)-1):
   a,b,d=f[0],f[k],f[k+1];normal=cross(sub(cage.v[b],cage.v[a]),sub(cage.v[d],cage.v[a]));triangles.append((a,b,d,cage.material[fi]))
   if length(normal)<1e-12:raise ValueError('Degenerate exported triangle; stop before output')
   for vertex in (a,b,d):normals[vertex]=[normals[vertex][j]+normal[j] for j in range(3)]
 normals=[[x/length(n) for x in n] for n in normals]
 d={'asset':{'version':'2.0','generator':'original connected equine quad-cage anatomy study; unaccepted'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'name':'horse_anatomy_static_reconstruction','mesh':0,'extras':{'status':'UNACCEPTED static anatomy development; no rig/tack/interaction','license':'CC0-1.0','frame':c['frame']}}],'materials':materials,'meshes':[{'name':'connected_anatomical_surface','primitives':[]}],'buffers':[],'bufferViews':[],'accessors':[]};blob=bytearray()
 def acc(rows,kind,component=5126):
  while len(blob)%4:blob.append(0)
  flat=[x for row in rows for x in (row if isinstance(row,(list,tuple)) else [row])];offset=len(blob);blob.extend(struct.pack('<'+('f' if component==5126 else 'I')*len(flat),*flat));vi=len(d['bufferViews']);d['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':len(blob)-offset});a={'bufferView':vi,'componentType':component,'count':len(rows),'type':kind}
  if kind=='VEC3':a.update(min=[min(r[j] for r in rows) for j in range(3)],max=[max(r[j] for r in rows) for j in range(3)])
  d['accessors'].append(a);return len(d['accessors'])-1
 p=acc(cage.v,'VEC3');n=acc(normals,'VEC3')
 for material in sorted({t[3] for t in triangles}):
  indices=[v for a,b,d0,m in triangles if m==material for v in (a,b,d0)];index=acc(indices,'SCALAR',5125);d['meshes'][0]['primitives'].append({'attributes':{'POSITION':p,'NORMAL':n},'indices':index,'material':material})
 d['buffers']=[{'byteLength':len(blob)}];js=json.dumps(d,separators=(',',':')).encode();js+=b' '*((-len(js))%4);blob+=b'\0'*((-len(blob))%4);glb=struct.pack('<III',0x46546c67,2,28+len(js)+len(blob))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(blob),0x004e4942)+blob
 report={'status':'UNACCEPTED new static anatomical authoring study, NOT photographic/rig/tack/production qualified','license':'CC0-1.0','frame':c['frame'],'source_control_cage':authored,'vertices':len(cage.v),'triangles':len(triangles),'draws':len(d['meshes'][0]['primitives']),'bytes':len(glb),'textures':0,'texture_memory_bytes':0,'animations':[],'skin_joints':0,'sockets':[],'anatomy_controls':c,'missing':['actual anatomical/photographic review','independent topology/scale/pose checks','hair/mane/tail grooming','UV/PBR microdetail','rig-ready retopology review','anatomical skeleton and motion','fitted tack','LODs and browser memory/frame costs']}
 (out/'horse-anatomical-static-unaccepted.glb').write_bytes(glb);(out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
 (out/'static-subdivided-surface.json').write_text(json.dumps({'license':'CC0-1.0','note':'Subdivided static development surface; author controls and source remain canonical','vertices':cage.v,'faces':cage.f,'materials':cage.material,'regions':cage.region},separators=(',',':'))+'\n')

def main():
 p=argparse.ArgumentParser();p.add_argument('--controls',type=pathlib.Path,default=pathlib.Path(__file__).with_name('anatomy-authoring-controls.json'));p.add_argument('--output-dir',type=pathlib.Path,required=True);p.add_argument('--execute-reviewed-source',action='store_true');a=p.parse_args()
 if not a.execute_reviewed_source:p.error('Source is UNEXECUTED; require explicit reviewed source execution')
 if a.output_dir.exists():p.error('Refuse existing output directory')
 c=json.loads(a.controls.read_text());cage,authored=build(c);a.output_dir.mkdir();export_static(cage,c,a.output_dir,authored)
 print(json.dumps({'output':str(a.output_dir),'status':'UNACCEPTED static source study; review required'}))
if __name__=='__main__':main()
