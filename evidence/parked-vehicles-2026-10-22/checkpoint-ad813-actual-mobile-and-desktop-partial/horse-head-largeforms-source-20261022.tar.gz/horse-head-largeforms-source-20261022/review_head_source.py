# SPDX-License-Identifier: CC0-1.0
"""Pure source/control arithmetic only. Does NOT instantiate Cage/build/export."""
import ast,hashlib,json,math
from pathlib import Path
p=Path(__file__).resolve().parent;base=Path('/workspace/shared/horse-anatomical-static-junction-repair-clarified-source-20261022/proposed')
c=json.loads((p/'proposed/anatomy-authoring-controls.json').read_text());old=json.loads((base/'anatomy-authoring-controls.json').read_text());src=(p/'proposed/quad_cage_authoring.py').read_text();tree=ast.parse(src);oldtree=ast.parse((base/'quad_cage_authoring.py').read_text())
checks={'source_AST_parses_without_execution':True,'body_controls0_through7_exact':c['body_profile'][:8]==old['body_profile'][:8]}
protected=['body_root_holes','fore_l','hind_l','proposed_contacts_m','limb_aperture_collar_m','material_reconstruction','frame','source_frame_amendment','downstream_sampling_amendment']
checks['protected_data_groups_exact']=all(c[x]==old[x] for x in protected)
checks['nostril_cup_sections_exact']=c['nostril_authoring']['cup_sections']==old['nostril_authoring']['cup_sections']
helpers=['Cage','aperture_normal','ordered_aperture_angles','outside_aperture_collar','inset_aperture_cup','attach']
def dump(t,name):return ast.dump(next(n for n in t.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==name),include_attributes=False)
checks['good_junction_and_cup_algorithm_ASTs_exact']=all(dump(tree,n)==dump(oldtree,n) for n in helpers)
checks['parallel_control_region_coefficient_lengths']=len(c['body_profile'])==len(c['body_regions'])==len(c['body_ring_radial_z_m'])==16
z_margins=[b[2]-a[2]-abs(c['body_ring_radial_z_m'][j+1]-c['body_ring_radial_z_m'][j]) for j,(a,b) in enumerate(zip(c['body_profile'],c['body_profile'][1:]))]
checks['corresponding_crosssection_Z_order_strict']=min(z_margins)>0
progress=[.5*(a[4]+b[4])*(b[2]-a[2])-.5*(c['body_ring_radial_z_m'][j]+c['body_ring_radial_z_m'][j+1])*(b[1]-a[1]) for j,(a,b) in enumerate(zip(c['body_profile'],c['body_profile'][1:]))]
checks['crosssection_center_progress_positive']=min(progress)>0
checks['material_and_nostril_indices_follow_inserted_orbital_band']=c['body_regions'][c['nostril_authoring']['root_body_interval']]=='nose' and c['muzzle_material_start_interval']==13
E=c['ear_authoring'];checks['ear_parallel_profile_arrays']=len(E['profile_fractions'])==len(E['half_width_profile_m'])==len(E['half_depth_profile_m'])==4
checks['ear_length_and_width_bounded']=.14<=E['blade_length_m']<=.18 and .035<=max(E['half_width_profile_m'])<=.05
O=c['eye_authoring'];checks['orbit_UV_contours_strictly_in_apertures']=all(0<center[0]-s['radius_u']<center[0]+s['radius_u']<1 and 0<center[1]-s['radius_v']<center[1]+s['radius_v']<1 for center in [O['quad_uv_center_left'],O['quad_uv_center_right']] for s in O['sections'])
checks['orbit_UV_centers_mirror']=abs(O['quad_uv_center_left'][0]+O['quad_uv_center_right'][0]-1)<1e-12 and O['quad_uv_center_left'][1]==O['quad_uv_center_right'][1]
ru=[1]+[s['radius_u'] for s in O['sections']];rv=[1]+[s['radius_v'] for s in O['sections']];depth=[0]+[s['normal_offset_m'] for s in O['sections']]
checks['orbit_contours_nest_and_advance_outside']=all(a>b for a,b in zip(ru,ru[1:])) and all(a>b for a,b in zip(rv,rv[1:])) and all(a<b for a,b in zip(depth,depth[1:]))
def point(j,k):
 x,y,z,rx,ry=c['body_profile'][j];t=k*2*math.pi/c['body_sides'];return [x+rx*math.cos(t),y+ry*math.sin(t),z+c['body_ring_radial_z_m'][j]*math.sin(t)]
def patch(j,col,u,v):
 A,B,C,D=point(j,col),point(j,col+1),point(j+1,col+1),point(j+1,col)
 return [(1-v)*((1-u)*A[k]+u*B[k])+v*((1-u)*D[k]+u*C[k]) for k in range(3)]
centers={str(side):patch(O['root_body_interval'],O['left_column' if side>0 else 'right_column'],*O['quad_uv_center_left' if side>0 else 'quad_uv_center_right']) for side in [1,-1]}
checks['derived_orbit_surface_centers_mirror']=abs(centers['1'][0]+centers['-1'][0])<1e-12 and all(abs(centers['1'][k]-centers['-1'][k])<1e-12 for k in [1,2])
refs=json.loads((p/'REFERENCE-PIXEL-OBSERVATIONS.json').read_text());checks['actually_viewed_reference_files_match_hashes']=all(hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256'] for r in refs['observations'])
# Source outer-section projections only, NOT subdivided width measurements.
yaw=math.radians(E['splay_yaw_deg']);new_u=(math.cos(yaw),-math.sin(yaw));new_v=(math.sin(yaw),math.cos(yaw));right=(3.8/math.hypot(3.8,3.5),-3.5/math.hypot(3.8,3.5))
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
new_quarter=2*math.hypot(.045*dot(new_u,right),.014*dot(new_v,right));old_quarter=2*math.hypot(.030*right[0],.012*right[1]);new_side=2*math.hypot(.045*new_u[1],.014*new_v[1])
report={'status':'PASS source hypotheses only' if all(checks.values()) else 'FAIL source review','scope':'AST/data/coordinate arithmetic only; no geometry build/subdivision/export/collision/browser. No photo acceptance.','checks':checks,'minimum_same_angle_Z_separation_m':min(z_margins),'minimum_crosssection_center_progress':min(progress),'derived_orbit_surface_centers_m':centers,'source_control_pinna_projection_only':{'old_left_quarter_max_width_m':old_quarter,'proposed_left_quarter_max_width_m':new_quarter,'proposed_side_max_width_m':new_side,'limit':'Control section before subdivision, no actual visible-width proof'},'explicit_unproven':['actual jaw/orbit/pinna/throatlatch appearance','new head/ear/orbit embedding and vertex links','existing body/leg junction post-subdivision halo and exact readback','actual axes/soles/frame','coplanar contact/containment','anatomical/photographic acceptance']}
(p/'SOURCE-ONLY-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));raise SystemExit(0 if all(checks.values()) else 1)
