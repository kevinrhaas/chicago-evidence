# V3 fixed front inspection recipe — prepared/held, no browser

The first actual desktop V2 run remains **FAILED**. Its profile was captured and passed the actual guards; front failed the unchanged10% padding guard at minNDCy -0.819306057, beyond -0.8. That run CLOSED with sourceUnchanged:true and zero page/network errors. Full V2 source, receipt/progress/log and actual profile PNG are preserved under immutable-failed-V2/ with hashes. This V3 is a separately identified, prospectively checked source correction authorized by root; no prior run is renamed complete or retried automatically.

**Only front pitch changes, -17.3° → -19.0°.** Front stays E−91.85/N−36.5/yaw270,2.15m from the actor. Profile and quarter cameras, route points, production walker yaw/collision path, terrain, FOV, actor/body/rig/animation/materials/LODs/root and all source/published bytes remain unchanged. No adaptive per-frame fitting, camera search or image fitting is present. The browser review helper differs by that single fixed pitch value. Capture wrapper additionally changes its receipt identity and adds local phase timestamps; it introduces no new page evaluations or omitted work.

## Prospective proof (CPU only)

prove_static_framing.mjs decodes the four exact qualified published GLBs with the repository's own vendored GLTFLoader/Meshopt/Three implementation. Its CPU-only plugin skips texture reads; no browser, DOM, WebGL, GPU or artifact code runs. It creates no new garment geometry and writes no application data. GLB hashes match canonical39712579846 and current committed ad813a627. Large GLB/vendor bytes are not duplicated; SOURCE-PINS.json and CANONICAL-EXPECTED-INPUTS.json specify exact reacquisition.

The exact actual V2 profile bone matrices reconstruct every posed vertex and its captured projected extrema with **zero NDC error**. This grounds the decoder/skinning/projection pipeline in the actual failed-run receipt rather than guessing a body box.

For the future fixed recipe, each exact LOD is evaluated at idle phase0. The source clip is proved to have exactly one varying track, spine_02 quaternion (61 authored keys); all other tracks are constant. A conservative sphere around each actual skinned vertex bounds the complete shortest-slerp idle rotation arc plus both production blink targets over0..1. It uses actual source weights and the transformed support distances of descendant-bone contributions; the parent matrix Frobenius condition bound widens rotation displacement rather than assuming a perfectly unit transform. A1µm numerical slack is added. This reads61 key quaternions but does not perform61 geometry sweeps or a dense fit study. Default morph weights must be zero. Walk/seated/greeting/expression changes are outside this idle standing recipe.

An initially exact-unit-parent assumption was refused because actual exported parent column scales are [1,0.9999999981718642,0.9999999981718642]. CPU-ASSUMPTION-CORRECTION.json preserves that finding. The correction uses norm(A)×norm(inverse(A)) (about3) as a conservative upper bound, widening the geometry envelope. No existing normal, sole or framing guard was relaxed.

Projection uses the actual source heightfield at every unchanged camera and the actual default FOVs: desktop55°/aspect1.6, mobile94°/aspect0.5. It bounds sphere projection using extrema of x/y and positive depth, and checks the full near/far sphere depth. All24 cases (4LODs×3views×2viewports) pass ±0.8 x/y padding. Across all LODs the revised desktop front bound is minY≥−0.752797 / maxY≤+0.767842. Every old front -17.3° case fails its negative control. Profile and quarter retain margin without changes. This is a prospective algebra check, not future rendered acceptance.

Terrain camera eye heights (1.68m above each actual field point): profile2.67704m, front2.67722m, quarter2.67500m. Actor root is unchanged at0.9992m. No camera translation or obstacle-clearance assumption is added, so the actual V2 route evidence remains applicable to the unchanged front position.

## Bounded work and unchanged acceptance

The old run started05:16:50.881Z; actual profile PNG finished05:21:16.961Z (266.080s). Front padding failed and closed at05:21:44.828Z (293.947s), leaving246.053s of the unchanged540s cap at that point. The cap itself was not reached. There is no measured price for the omitted later work, so this packet does not claim it fits by extrapolation. V3 records boot/landing/entry/install, per-view guard/capture, card, timing, four-LOD loader and far phases to identify any actual bound failure without changing assertions or reducing the required grid.

Each actual viewport must still produce profile/front/quarter plus its completed own-resident-card PNG, all four production-loader LOD checks, near/far automatic LOD, normal-loop timing diagnostics, actual shoe render counters and culling policy, all-vertex 10% padding, unchanged2mm sole-to-terrain checks and unchanged public budgets. Source/HEAD/index/mirror reconciliation and owned browser/server closure remain mandatory. T1789/full fit/photo remain open, including40 inherited negative projections.

## Root release command

RELEASE-HELD.json remains released:false. On the free lane, root supplies one new immutable release JSON per viewport with actual committed ad813a627 HEAD/index, unique output, closed-lane flag and unchanged540000ms cap. The original V2 output must never be reused. Then root runs one foreground viewport at a time:

```sh
PW_EXECUTABLE=/usr/bin/chromium node /workspace/shared/human-standing-bardwell-town-review-V3-fixed-front-PREPARED-HELD-20261022/capture_town.cjs /workspace/shared/ROOT-BARDWELL-V3-DESKTOP-RELEASE.json > /workspace/shared/bardwell-ad813-town-desktop-V3.log 2>&1
PW_EXECUTABLE=/usr/bin/chromium node /workspace/shared/human-standing-bardwell-town-review-V3-fixed-front-PREPARED-HELD-20261022/capture_town.cjs /workspace/shared/ROOT-BARDWELL-V3-MOBILE-RELEASE.json > /workspace/shared/bardwell-ad813-town-mobile-V3.log 2>&1
```

No browser/server or new CI action was launched during this preparation. Root must inspect the eventual normal images; technical/CPU PASS is not photographic acceptance. Any new actual guard/cap failure is preserved and stops; no automatic camera adjustment or retry occurs.
