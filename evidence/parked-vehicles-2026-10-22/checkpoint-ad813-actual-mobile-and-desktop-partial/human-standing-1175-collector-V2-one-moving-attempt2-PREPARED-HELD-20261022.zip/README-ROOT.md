# Collector V2 — one exact diagnostic moving attempt2, held

This collector permits **only** moving run39727250726 at source `ad813a6278b7d76961b78ef3483f1bbf3e106c02`, workflow `.github/workflows/chicago-4d-moving-frames.yml` / ID374947050 / workflow_dispatch, at expected attempt2. Every smoke and every other normal workflow remains strict attempt1. It adds no general retry permission and cannot send a rerun, dispatch or cancel. Root owns the one authorized diagnostic POST. No network/observer/rerun has occurred during preparation.

The actual first attempt remains **failure**, permanently retained. Mandatory capsule SHA256 is `75e08066c250447e180725208be20b3d52d840038358dca03af3af34a6a9999e`. The complete111KB original capsule, actual run/jobs metadata, full job log, failed moving step and attempt1 logZIP are copied under attempt1/ and checked against literal source-pinned hashes before ownership/network work. Failure-evidence SHA256 `6fcd9796f8ab52351fc6880ce9a097ac1be24fd6afc42045c11df7a08b669744`; full-job log `7a9f8829050e2cb9251abf9f365875dd147c0c6e363184518d57a71584aa5fad`; failed-step log `f4196b0b86df3cc24c42f2be478c2314da0aaa40c6ce2c166d1ea9ed22042e20`; logZIP `8b20d67ef62fd38ecd48fc2f7eb495618491132ab42fa87a6c10b14cef054ee6`. These bytes are not executed or extracted.

Root's diagnosis supports one diagnostic repeat: exact flora/tool/workflow bytes match the passing ca82 comparator; all12 sample counts match and all12 flora p95 values improve; one Light maximum fails. Human update is outside the timed flora wrapper. This does not prove runner noise or rule out an indirect human effect. The actual attempt1 Light/travel maximum38.6ms exceeded its unchanged21ms ceiling; the phone step was skipped. The rerun does not erase that finding or relax the threshold.

## Exact source delta

Original V1 collector is preserved in original-v1/. V2 keeps its strict smoke, normal-job, human-dependent-skip, ordinary-population and checkout helpers unchanged. It adds a separate moving-attempt2 audit rather than changing the old attempt1 helper or disguising attempt2 as1. The exact-run selector is literal; another source/workflow/event/ID or attempt3 is refused. New moving job/check IDs must differ from original119653898622, and **all** original moving/phone required steps and post steps must complete successfully. Other selected/normal jobs still use the original attempt1 audit.

Attempt-specific job and failure-log GETs use the expected attempt (2 only for this moving run,1 everywhere else). On release the collector also GET-confirms original attempt1 failure and original failed job ID, while preserving the pinned log hashes locally and copying the original evidence into the new output. Any attempt2 failure is preserved and stops; there is no automatic further repeat. The success status explicitly reads EXACT_AD813_CI_QUALIFIED_AFTER_ONE_DIAGNOSTIC_MOVING_RERUN, with first_pass_qualification:false and first_attempt_failure retained in owner/latest/terminal state.

All previous guards remain: exact source/tree/PR base/merge/workflow bytes+IDs, checkout logs, selected18 actual viewport/stage+ordinary-person positive proofs, gate/report/humans attempt1, live PR/ref reconciliation, final job/check-run binding,61s polling/150min observation bound, individual GET45s cap, unique ownership and durable progress/failures. Existing source/CI performance thresholds are untouched. The original V1 preparation and failure capsule remain unchanged.

## Root activation after the single actual POST

ROOT-RERUN-RECEIPT-TEMPLATE-HELD.json is a schema template, not an actual result or an execution tool. Root preserves its actual once-only rerun request/result bytes and writes a separate immutable receipt using status ROOT_ONE_DIAGNOSTIC_MOVING_RERUN_ACCEPTED, actual requested_at/accepted_at and post_result returncode0, exact source/run/workflow, original_attempt1/expected_attempt2, authorized_reruns1 and mandatory first-failure hash. Endpoint may be only this run's `/rerun` or `/rerun-failed-jobs`; both rerun the sole moving job. No other run is authorized. If that POST is ambiguous, stop for root reconciliation; do not manufacture accepted status or repeat the request.

Root then copies ROOT-OBSERVE-HELD.json to a new immutable collector release with status ROOT_RELEASED_HUMAN1175_ONE_MOVING_ATTEMPT2_GET_COLLECTION, released:true/allow_GET_collection:true, final tree/base/merge, complete original18 smoke dispatch/reconciliation receipt+hash, final pricing+hash, the four actual normal run IDs and this V2 collector hash. The moving normal entry must remain the **same** run39727250726/workflow_dispatch, not a newly dispatched substitute. Pin diagnostic_rerun_receipt and diagnostic_rerun_receipt_sha256 to the actual root receipt. All other release fields/caps retain their previous meanings.

Only after root delegates one observer:

```sh
python /workspace/shared/human-standing-1175-collector-V2-one-moving-attempt2-PREPARED-HELD-20261022/collect-GET-only.py --release /workspace/shared/ROOT-HUMAN1175-GET-V2-RELEASE.json --output /workspace/shared/human1175-ad813-GET-V2-moving-attempt2-owner1 > /workspace/shared/human1175-ad813-GET-V2-moving-attempt2-owner1.log 2>&1
```

The release remains false here. No command to issue the rerun is supplied or run by this preparation. The observer uses a distinct persistent V2 ownership lock and the same live-process duplicate check; it must not overlap a V1 owner. Root must prove any old owner absent before a recovery owner. No observer is launched now.

32 offline controls pass. Actual attempt1 evidence is verified; future attempt2 success and accepted-root-receipt positive cases are explicitly synthetic schema controls. Negatives reject wrong source/workflow/event/ID, another run's attempt2, attempt3, reused job/check IDs, skipped phone, failed moving step, altered first-failure log and a held/unperformed root receipt. These tests are not actual rerun acceptance. T1789/photo/fit and root's fresh merge review remain separate.
