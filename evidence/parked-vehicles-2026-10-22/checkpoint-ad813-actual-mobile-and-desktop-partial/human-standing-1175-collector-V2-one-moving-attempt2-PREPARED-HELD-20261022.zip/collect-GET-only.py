#!/usr/bin/env python3
"""HELD finite GET-only qualification of already-dispatched new-standing-head CI.
V2 permits only moving run39727250726 attempt2 at exactad813, preserving attempt1 failure. Every other run remains attempt1. No POST/rerun/cancel capability.
"""
import argparse,base64,datetime,hashlib,json,os,pathlib,re,shutil,subprocess,time
REPO='kevinrhaas/chicago'
BRANCH='steward/1835-workwear-repair-20261021'
SMOKE='.github/workflows/chicago-4d-smoke.yml'
RANGES=['1-2','3-4','5','6-7','8','9-12','13','14','15']
SMOKE_STEPS=['Set up job','Run actions/checkout@v4','Run actions/setup-node@v4','Install Playwright','Publish the mirror the smoke serves (site/4d/ is generated)','Run the smoke against the published mirror','Complete job']
NORMAL={
 '.github/workflows/chicago-4d-check.yml':('gate',['Set up job','Run actions/checkout@v4','Run actions/setup-python@v5','Run actions/setup-node@v4','Install validator dependencies','How many cores this runner has','Run the gate','Does this change carry a changelog entry?','Complete job']),
 '.github/workflows/chicago-4d-moving-frames.yml':('moving-frames',['Set up job','Run actions/checkout@v4','Run actions/setup-node@v4','Install Playwright','Publish the mirror the gate serves (site/4d/ is generated)','Walk, turn, fly and ride; hold the flora frame to its ceilings','A phone keeps the town on the GPU, not twice','Complete job']),
 '.github/workflows/chicago-4d-pr-stuck.yml':('report',['Set up job','Check the secret before doing anything','Run actions/checkout@v4','Report every pull request nothing can move','Complete job']),
 '.github/workflows/chicago-4d-humans.yml':('humans',['Set up job','Run actions/checkout@v4','Run actions/setup-python@v5','Run actions/setup-node@v4','Run pip install --quiet jsonschema','Read the Blender pin','Cache Blender','Rebuild the fixture and require the committed bytes','Install Playwright','Open every human GLB in the browser, at both viewports','Drive the browser actor with the fixture, at both viewports','Complete job']),
}


def need(c,m):
 if not c:raise ValueError(m)

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(data):return hashlib.sha256(data).hexdigest()

def save(path,value):
 tmp=path.with_suffix(path.suffix+'.new');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)

def smoke_cell(text):
 """Bind inputs to the actual published-smoke step's env, never dispatch order."""
 clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text)
 lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+Z\s*','',x) for x in clean.splitlines()]
 starts=[i for i,x in enumerate(lines) if x=='##[group]Run node tools/smoke_renderer.mjs --published']
 need(len(starts)==1,'Expected exactly one actual published-smoke log group')
 start=starts[0];end=next((i for i in range(start+1,len(lines)) if lines[i]=='##[endgroup]'),None)
 need(end is not None,'Incomplete published-smoke log group')
 group='\n'.join(lines[start:end])
 viewport=re.findall(r'^\s*SMOKE_VIEWPORT:\s*(\S+)\s*$',group,re.M)
 stage=re.findall(r'^\s*SMOKE_STAGE:\s*(\S+)\s*$',group,re.M)
 need(len(viewport)==len(stage)==1,'Missing or ambiguous actual viewport/stage')
 viewport,stage=viewport[0],stage[0]
 need(viewport in ['desktop','mobile'] and stage in RANGES,'Unexpected actual smoke cell')
 need(f'NOT THE FULL GATE — viewports filtered to "{viewport}"' in lines,'Runtime viewport does not match step env')
 need(f'NOT THE FULL GATE — stages filtered to "{stage}" of 15' in lines,'Runtime stage does not match step env')
 need(lines.count('SMOKE PASS')==1,'Actual single-cell smoke did not print one terminal PASS')
 return viewport,stage

def audit_job(job,run,head,name,required):
 need(job['run_id']==run['id'] and job.get('run_attempt')==1 and job.get('head_sha')==head,'Job identity/attempt drift')
 need(job['name']==name and job['status']=='completed' and job['conclusion']=='success','Job did not succeed')
 steps=job.get('steps',[])
 for wanted in required:
  matches=[s for s in steps if s['name']==wanted]
  need(len(matches)==1 and matches[0]['status']=='completed' and matches[0]['conclusion']=='success','Required actual step did not succeed: '+wanted)
 need(all(s['conclusion']=='success' for s in steps),'Unexpected skipped/failed job step')
 return {'run_id':run['id'],'job_id':job['id'],'job_name':name,'required_steps':required,'PASS':True}


def checkout_sha(text,expected):
    clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text)
    lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+Z\s*','',x) for x in clean.splitlines()]
    values=[]
    for i,line in enumerate(lines):
        if re.fullmatch(r'\[command\].*[/ ]git log -1 --format=%H',line):
            need(i+1<len(lines) and re.fullmatch('[a-f0-9]{40}',lines[i+1]),'Missing exact checkout log SHA')
            values.append(lines[i+1])
    need(values==[expected],'Actual checkout SHA differs or is ambiguous: '+repr(values))
    return values[0]


def audit_human_jobs(jobs,run,head):
    names={j['name']:j for j in jobs}
    need(len(names)==len(jobs) and set(names)=={'humans','teamster-studies'},'Expected normal humans and explicit skipped dependent job')
    skipped=names['teamster-studies']
    need(skipped['run_id']==run['id'] and skipped.get('run_attempt')==1 and skipped.get('head_sha')==head and skipped['status']=='completed' and skipped['conclusion']=='skipped','Normal PR must not rebuild canonical teamster studies')
    name,steps=NORMAL['.github/workflows/chicago-4d-humans.yml']
    proof=audit_job(names[name],run,head,name,steps)
    proof['expected_skipped_dependent_job_id']=skipped['id']
    return names[name],proof



def audit_population_boot(text,viewport):
    # This positive ordinary-scene line is emitted before stage filtering. Old
    # zero-human smoke logs cannot qualify a first standing-population run.
    label='desktop 1280x800' if viewport=='desktop' else 'mobile 390x780'
    for suffix in ["the human layer mounts exactly the scene's eligible records",'human requests obey the exact scene-year gate']:
        matches=[line for line in text.splitlines() if 'pass  '+label+': '+suffix in line]
        need(len(matches)==1,'Missing/ambiguous actual new ordinary-population bootstrap PASS: '+suffix)
    return {'ordinary_eligible_human_boot_PASS':True,'exact_scene_year_request_gate_PASS':True}

MOVING_RUN=39727250726
MOVING_HEAD='ad813a6278b7d76961b78ef3483f1bbf3e106c02'
MOVING_PATH='.github/workflows/chicago-4d-moving-frames.yml'
MOVING_WORKFLOW_ID=374947050
FIRST_JOB_ID=119653898622
ATTEMPT1_PINS={'FAILURE-EVIDENCE.json': '6fcd9796f8ab52351fc6880ce9a097ac1be24fd6afc42045c11df7a08b669744', 'run.json': 'ee8215f0fed0e59caac17b94931c948542bdcc97a6f3a42d204e7318c6002d77', 'jobs.json': 'c4f26261ebfbc5c16ff2a0d63d4eb85f9812272edee1a43c82b9514d086541ed', 'full-job.log': '7a9f8829050e2cb9251abf9f365875dd147c0c6e363184518d57a71584aa5fad', 'failed-step.log': 'f4196b0b86df3cc24c42f2be478c2314da0aaa40c6ce2c166d1ea9ed22042e20', 'logs.zip': '8b20d67ef62fd38ecd48fc2f7eb495618491132ab42fa87a6c10b14cef054ee6', 'capsule.tar.gz': '75e08066c250447e180725208be20b3d52d840038358dca03af3af34a6a9999e'}


def expected_attempt(run):
    if run['id'] != MOVING_RUN:return 1
    need(run.get('head_sha')==MOVING_HEAD and run.get('path')==MOVING_PATH and run.get('event')=='workflow_dispatch' and run.get('workflow_id')==MOVING_WORKFLOW_ID,'Only the exact original moving run/source/workflow may use attempt2')
    return 2


def preserve_attempt1(source):
    folder=source.parent/'attempt1'
    for name,digest in ATTEMPT1_PINS.items():
        need(sha((folder/name).read_bytes())==digest,'Mandatory first-failure evidence changed: '+name)
    evidence=json.loads((folder/'FAILURE-EVIDENCE.json').read_bytes())
    run=json.loads((folder/'run.json').read_bytes())
    jobs=json.loads((folder/'jobs.json').read_bytes())
    need(run['id']==MOVING_RUN and run['head_sha']==MOVING_HEAD and run['run_attempt']==1 and run['conclusion']=='failure' and run['path']==MOVING_PATH and run['workflow_id']==MOVING_WORKFLOW_ID,'Original first-attempt metadata is not the pinned failure')
    need(jobs['total_count']==len(jobs['jobs'])==1 and jobs['jobs'][0]['id']==FIRST_JOB_ID and jobs['jobs'][0]['conclusion']=='failure','Original failed job identity differs')
    need(evidence['attempt1_log_ZIP_sha256']==ATTEMPT1_PINS['logs.zip'] and evidence['full_job_log_sha256']==ATTEMPT1_PINS['full-job.log'] and evidence['failed_step_log_sha256']==ATTEMPT1_PINS['failed-step.log'],'First-attempt log hashes differ')
    return {'run_id':MOVING_RUN,'attempt':1,'conclusion':'failure','job_ids':[FIRST_JOB_ID],'capsule_sha256':ATTEMPT1_PINS['capsule.tar.gz'],'evidence_sha256':ATTEMPT1_PINS['FAILURE-EVIDENCE.json'],'full_job_log_sha256':ATTEMPT1_PINS['full-job.log'],'failed_step_log_sha256':ATTEMPT1_PINS['failed-step.log'],'attempt_log_ZIP_sha256':ATTEMPT1_PINS['logs.zip'],'permanent':True,'never_relabel_first_pass':True}


def validate_rerun_receipt(obj):
    need(obj.get('status')=='ROOT_ONE_DIAGNOSTIC_MOVING_RERUN_ACCEPTED' and obj.get('repository')==REPO and obj.get('run_id')==MOVING_RUN and obj.get('head_sha')==MOVING_HEAD and obj.get('branch')==BRANCH and obj.get('workflow_path')==MOVING_PATH,'Root diagnostic rerun receipt source/run binding differs')
    need(obj.get('original_attempt')==1 and obj.get('expected_attempt')==2 and obj.get('authorized_reruns')==1 and obj.get('post_attempted') is True and obj.get('post_succeeded') is True and obj.get('method')=='POST','Not exactly one root-accepted attempt1-to2 diagnostic rerun')
    need(obj.get('endpoint') in ['repos/'+REPO+'/actions/runs/'+str(MOVING_RUN)+'/rerun','repos/'+REPO+'/actions/runs/'+str(MOVING_RUN)+'/rerun-failed-jobs'],'Root rerun endpoint is not this exact moving run')
    need(obj.get('post_result',{}).get('returncode')==0 and obj.get('first_attempt_failure_capsule_sha256')==ATTEMPT1_PINS['capsule.tar.gz'] and obj.get('first_attempt_failure_remains') is True and obj.get('no_automatic_retry') is True,'Root accepted result/mandatory first failure/no-repeat binding differs')
    need(isinstance(obj.get('requested_at'),str) and isinstance(obj.get('accepted_at'),str),'Actual root request/result timestamps required')
    return True


def audit_moving_attempt2_job(job,run,head):
    # Explicit separate audit; never normalize attempt2 to1 for the old helper.
    need(head==MOVING_HEAD and expected_attempt(run)==2 and run.get('run_attempt')==2,'Moving attempt2 source/run identity differs')
    need(job['run_id']==MOVING_RUN and job.get('run_attempt')==2 and job.get('head_sha')==MOVING_HEAD and job['id']!=FIRST_JOB_ID and job['check_run_url']!='https://api.github.com/repos/'+REPO+'/check-runs/'+str(FIRST_JOB_ID),'Diagnostic rerun must have distinct new actual job/check IDs')
    need(job['name']=='moving-frames' and job['status']=='completed' and job['conclusion']=='success','Actual moving attempt2 job did not succeed')
    required=NORMAL[MOVING_PATH][1]
    for wanted in required:
        matches=[step for step in job.get('steps',[]) if step['name']==wanted]
        need(len(matches)==1 and matches[0]['status']=='completed' and matches[0]['conclusion']=='success','Attempt2 required moving/phone step did not succeed: '+wanted)
    need(all(step['conclusion']=='success' for step in job.get('steps',[])),'Attempt2 skipped/failed step remains')
    return {'run_id':MOVING_RUN,'run_attempt':2,'job_id':job['id'],'job_name':'moving-frames','required_steps':required,'PASS':True,'first_attempt_failed':True,'single_root_diagnostic_rerun':True,'first_pass':False,'first_failure_capsule_sha256':ATTEMPT1_PINS['capsule.tar.gz']}


def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--release',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True)
 a=p.parse_args();release=json.loads(a.release.read_bytes());source=pathlib.Path(__file__)
 need(release.get('released') is True and release.get('status')=='ROOT_RELEASED_HUMAN1175_ONE_MOVING_ATTEMPT2_GET_COLLECTION' and release.get('allow_GET_collection') is True,'HELD: root immutable GET collection release required')
 need(release.get('collector_sha256')==sha(source.read_bytes()),'Collector identity differs')
 need(release.get('repository')==REPO and release.get('branch')==BRANCH and release.get('pr')==1175 and release.get('base_ref')=='dev','Release route differs')
 head,tree,base,merge=[release.get(k) for k in ['sha','tree','base_sha','merge_sha']]
 need(head==MOVING_HEAD,'This V2 is confined to exactad813, never another source head')
 first_failure=preserve_attempt1(source)
 rerun_path=pathlib.Path(release['diagnostic_rerun_receipt']);need(sha(rerun_path.read_bytes())==release.get('diagnostic_rerun_receipt_sha256'),'Root actual rerun receipt hash differs');rerun=json.loads(rerun_path.read_bytes());validate_rerun_receipt(rerun)
 need(all(isinstance(x,str) and re.fullmatch('[a-f0-9]{40}',x) for x in [head,tree,base,merge]),'Root must pin final head/tree/base/merge')
 need(head not in ['34cf462ed343b8b2b70da70303344fff7e5e083f','2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3'],'Historical canonical head cannot qualify new standing population')
 need(release.get('poll_seconds')==61 and release.get('max_minutes')==150,'Fixed61s polling/150min bound required')
 receipt_path=pathlib.Path(release['dispatch_receipt']);d=json.loads(receipt_path.read_bytes())
 need(release.get('dispatch_receipt_sha256')==sha(receipt_path.read_bytes()),'Dispatch receipt binding differs')
 need(d.get('lane_identity')=='human-standing-1175-nexthead-v1' and d.get('repository')==REPO and d.get('branch')==BRANCH and d.get('sha')==head and d.get('tree')==tree and d.get('pr')==1175 and d.get('dispatch_complete') is True and not d.get('error'),'Not completed exact new-head dispatch/reconciliation')
 need(d.get('caller_sha256')==sha((source.parent/'dispatch-once.py').read_bytes()),'Dispatcher source binding differs')
 pins=json.loads((source.parent/'PREPARED-WORKFLOW-PINS.json').read_bytes())['pins']
 need(d.get('prepared_workflow_identity_pins')==pins,'Prepared workflow identity changed')
 cells={(v,s) for v in ['desktop','mobile'] for s in RANGES};selected={r['id'] for r in d['discovered_runs']}
 need(len(selected)==len(d['discovered_runs'])==18 and len(d['dispatches'])==18 and all(x.get('post_succeeded') for x in d['dispatches']) and {(x['viewport'],x['stage']) for x in d['dispatches']}==cells,'Exact18 accepted/discovered smoke grid required')
 normal=release.get('normal_runs');need(isinstance(normal,list) and len(normal)==4 and {x['path'] for x in normal}==set(NORMAL),'Pin exactly gate/moving/report/humans routes')
 normal_by_id={x['id']:x for x in normal};need(len(normal_by_id)==4 and not selected.intersection(normal_by_id),'Duplicate selected/normal run IDs')
 need(normal_by_id.get(MOVING_RUN,{}).get('path')==MOVING_PATH and normal_by_id[MOVING_RUN].get('event')=='workflow_dispatch','Only original moving39727250726 may qualify at attempt2')
 expected_events={'.github/workflows/chicago-4d-check.yml':'pull_request','.github/workflows/chicago-4d-pr-stuck.yml':'push','.github/workflows/chicago-4d-humans.yml':'pull_request'}
 pricepath=pathlib.Path(release['final_diff_pricing']);price=json.loads(pricepath.read_bytes())
 need(sha(pricepath.read_bytes())==release.get('final_diff_pricing_sha256') and price.get('sha')==head and price.get('tree')==tree and price.get('pr_base')==base and price.get('expected_normal_contract') is True,'Final diff pricing/source/base binding differs')
 expected_events['.github/workflows/chicago-4d-moving-frames.yml']=price['moving_required_event']
 need(all(x.get('event')==expected_events[x['path']] for x in normal),'Normal trigger route does not match actual final diff')
 out=a.output.resolve();need(out.is_relative_to('/workspace/shared') and not out.exists(),'Fresh shared output required')
 # A persistent exact-head lock prevents duplicate owners, even after interruption.
 for proc in pathlib.Path('/proc').iterdir():
  if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
  try:args=[x.decode(errors='replace') for x in (proc/'cmdline').read_bytes().split(b'\0') if x]
  except (FileNotFoundError,PermissionError,ProcessLookupError):continue
  need(not(args and 'python' in pathlib.Path(args[0]).name and any(x.endswith('/collect-GET-only.py') for x in args[1:]) and '--release' in args),'A GET collector is already live; no duplicate owner')
 lock=pathlib.Path('/workspace/shared')/('human-standing-1175-'+head+'.GET-owner-V2-one-moving-attempt2.lock');lock.mkdir(exist_ok=False);out.mkdir(exist_ok=False)
 started=time.monotonic();deadline=started+150*60;counter=0;audited={};bound={};last=None;workflow_ids={}
 state={'status':'GET_COLLECTING_V2_ONE_MOVING_ATTEMPT2','qualification_pass':False,'first_pass_qualification':False,'first_attempt_failure':first_failure,'diagnostic_rerun_receipt_sha256':sha(rerun_path.read_bytes()),'head':head,'tree':tree,'base_ref':'dev','base_sha':base,'merge_sha':merge,'pr':1175,'branch':BRANCH,'observer_pid':os.getpid(),'started':now(),'deadline_utc':(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=150)).isoformat(),'poll_seconds':61,'max_minutes':150,'collector_sha256':sha(source.read_bytes()),'release_sha256':sha(a.release.read_bytes()),'dispatch_receipt_sha256':sha(receipt_path.read_bytes()),'POSTs':0,'reruns':0,'cancellations':0,'scope':'Exactad813 smoke18 + gate/report/humans remain attempt1. Only original moving39727250726 may qualify at attempt2 after one root diagnostic rerun, with first attempt failure permanently retained. No general retry permission, threshold change, first-pass claim, photo/ticket/merge permission.'}
 shutil.copytree(source.parent/'attempt1',out/'mandatory-attempt1-failure');save(out/'owner.json',state);save(lock/'owner.json',{'pid':os.getpid(),'output':str(out),'release':str(a.release),'started':state['started']})
 def api(label,endpoint,kind='json'):
  nonlocal counter
  need(time.monotonic()<deadline,'Observer150min deadline reached');counter+=1;stem=out/(f'{counter:04d}-'+label)
  try:
   result=subprocess.run(['gh','api','--method','GET','repos/'+REPO+'/'+endpoint],capture_output=True,timeout=min(45,max(1,deadline-time.monotonic())))
  except subprocess.TimeoutExpired as error:
   stem.with_suffix('.stdout').write_bytes(error.stdout or b'');stem.with_suffix('.stderr').write_bytes((error.stderr or b'')+b'\nGET process exceeded bounded timeout; no retry.\n')
   with (out/'GET-ATTEMPTS.jsonl').open('a') as f:f.write(json.dumps({'at':now(),'method':'GET','endpoint':endpoint,'timed_out':True,'stdout_file':stem.with_suffix('.stdout').name,'stderr_file':stem.with_suffix('.stderr').name})+'\n')
   raise
  stem.with_suffix('.stdout').write_bytes(result.stdout);stem.with_suffix('.stderr').write_bytes(result.stderr)
  record={'at':now(),'method':'GET','endpoint':endpoint,'returncode':result.returncode,'stdout_file':stem.with_suffix('.stdout').name,'stderr_file':stem.with_suffix('.stderr').name,'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr)}
  with (out/'GET-ATTEMPTS.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
  need(result.returncode==0,'GET failed; preserve output and stop, no automatic mutation/retry: '+label+' '+result.stderr.decode(errors='replace')[-1000:])
  if kind=='json':return json.loads(result.stdout)
  if kind=='text':return result.stdout.decode('utf8')
  return {'file':str(stem.with_suffix('.stdout')),'bytes':len(result.stdout),'sha256':sha(result.stdout)}
 def bind_pr():
  pull=api('PR1175','pulls/1175')
  need(pull['state']=='open' and pull['head']['sha']==head and pull['head']['ref']==BRANCH and pull['head']['repo']['full_name']==REPO and pull['base']['ref']=='dev' and pull['base']['sha']==base and pull['merge_commit_sha']==merge,'PR source/base/merge changed; qualification held')
  need(api('human-ref','git/ref/heads/'+BRANCH)['object']['sha']==head,'Human source ref moved')
  return {k:pull.get(k) for k in ['number','state','draft','mergeable','mergeable_state','updated_at']}
 def retain_failure(run,jobs):
  evidence={'run':run,'jobs':jobs,'job_logs':[],'retrieval_errors':[]}
  for job in jobs.get('jobs',[]):
   if job.get('status')!='completed' or job.get('conclusion')=='skipped':continue
   try:evidence['job_logs'].append({'job_id':job['id'],'log':api('failure-job-'+str(job['id']),'actions/jobs/'+str(job['id'])+'/logs','bytes')})
   except Exception as err:evidence['retrieval_errors'].append(str(err))
  try:evidence['artifacts']=api('failure-artifacts-'+str(run['id']),'actions/runs/'+str(run['id'])+'/artifacts?per_page=100')
  except Exception as err:evidence['retrieval_errors'].append(str(err))
  try:evidence['run_attempt_logs']=api('failure-run-'+str(run['id'])+'-attempt'+str(expected_attempt(run))+'-logs','actions/runs/'+str(run['id'])+'/attempts/'+str(expected_attempt(run))+'/logs','bytes')
  except Exception as err:evidence['retrieval_errors'].append(str(err))
  save(out/('FAILURE-'+str(run['id'])+'.json'),evidence)
 try:
  state['pr_state']=bind_pr()
  first_live=api('mandatory-moving-attempt1','actions/runs/'+str(MOVING_RUN)+'/attempts/1')
  need(first_live['id']==MOVING_RUN and first_live['head_sha']==MOVING_HEAD and first_live['run_attempt']==1 and first_live['path']==MOVING_PATH and first_live['conclusion']=='failure','Actual first-attempt failure no longer matches immutable evidence')
  first_jobs=api('mandatory-moving-attempt1-jobs','actions/runs/'+str(MOVING_RUN)+'/attempts/1/jobs?per_page=100')
  need(first_jobs['total_count']==len(first_jobs['jobs'])==1 and first_jobs['jobs'][0]['id']==FIRST_JOB_ID and first_jobs['jobs'][0]['conclusion']=='failure','Actual original failed job metadata differs')
  state['first_attempt_live_failure_reconfirmed']=True
  commit=api('source-commit','git/commits/'+head);need(commit['tree']['sha']==tree,'Actual remote source tree differs')
  merge_commit=api('PR-merge-commit','git/commits/'+merge);need([x['sha'] for x in merge_commit['parents']]==[base,head],'Actual PR merge parents differ from pinned base/head')
  for path,digest in {**d['pins'],**pins}.items():
   blob=d['git_blob_pins'][path] if path in d['git_blob_pins'] else None
   if blob is None:
    content=api('workflow-pin-'+str(counter),'contents/'+path+'?ref='+head)
   else:
    # Git blob API accepts the actual >1MiB smoke source, unlike Contents.
    content=api('source-pin-'+str(counter),'git/blobs/'+blob)
    need(content['sha']==blob,'Actual source Git blob pin differs: '+path)
   need(content.get('encoding')=='base64' and sha(base64.b64decode(content['content']))==digest,'Exact final source byte pin differs: '+path)
  for path in [SMOKE,*NORMAL]:
   metadata=api('workflow-'+pathlib.Path(path).stem,'actions/workflows/'+pathlib.Path(path).name)
   need(metadata['path']==path and metadata['state']=='active','Actual workflow path not active');workflow_ids[path]=metadata['id']
   if path in NORMAL and any(x['path']==path and x['event']=='pull_request' for x in normal):
    content=api('merge-workflow-'+str(counter),'contents/'+path+'?ref='+merge)
    need(content.get('encoding')=='base64' and sha(base64.b64decode(content['content']))==pins[path],'PR checkout workflow bytes differ from pinned source')
  while time.monotonic()<deadline:
   tick=time.monotonic();listing=api('runs','actions/runs?head_sha='+head+'&per_page=100')
   need(listing['total_count']==len(listing['workflow_runs']),'Incomplete exact-head run listing')
   byid={r['id']:r for r in listing['workflow_runs']};expected=selected|set(normal_by_id)
   need(expected<=set(byid),'A pinned actual selected/normal run is absent; no implicit redispatch')
   need(set(byid)==expected,'Unexpected exact-head runs; inspect before admitting duplicates or new scopes')
   current=[]
   for ident in sorted(expected):
    run=byid[ident];path=SMOKE if ident in selected else normal_by_id[ident]['path'];event='workflow_dispatch' if ident in selected else normal_by_id[ident]['event']
    need(run['head_sha']==head and run['head_branch']==BRANCH and run['run_attempt']==expected_attempt(run) and run['event']==event and run['path']==path and run['workflow_id']==workflow_ids[path] and run['repository']['full_name']==REPO,'Run source/workflow/event/attempt identity changed')
    if event=='pull_request':
     matches=[x for x in run.get('pull_requests',[]) if x.get('number')==1175]
     need(len(matches)==1 and matches[0]['head']['sha']==head and matches[0]['base']['sha']==base and matches[0]['base']['ref']=='dev','Actual PR run base/head binding differs')
    current.append({k:run.get(k) for k in ['id','path','event','head_sha','run_attempt','status','conclusion','html_url']})
    if ident in audited or run['status']!='completed':continue
    jobs=api('jobs-'+str(ident),'actions/runs/'+str(ident)+'/attempts/'+str(expected_attempt(run))+'/jobs?per_page=100')
    if jobs['total_count']!=len(jobs['jobs']):
     retain_failure(run,jobs);raise ValueError('Incomplete expected-attempt jobs')
    if run['conclusion']!='success':
     retain_failure(run,jobs);raise ValueError('Actual run failed: '+str(ident)+' '+str(run['conclusion']))
    try:
     if path=='.github/workflows/chicago-4d-humans.yml':job,proof=audit_human_jobs(jobs['jobs'],run,head)
     else:
      need(len(jobs['jobs'])==1,'Unexpected selected job count');job=jobs['jobs'][0]
      name,steps=('smoke',SMOKE_STEPS) if ident in selected else NORMAL[path];proof=audit_moving_attempt2_job(job,run,head) if ident==MOVING_RUN else audit_job(job,run,head,name,steps)
     text=api('job-'+str(job['id'])+'-log','actions/jobs/'+str(job['id'])+'/logs','text')
     proof['actual_checkout_sha']=checkout_sha(text,merge if event=='pull_request' else head)
     proof.update(workflow_path=path,event=event,run_attempt=job['run_attempt'],job_log_sha256=sha(text.encode()),check_run_url=job['check_run_url'])
     if ident in selected:
      cell=smoke_cell(text);need(cell not in bound,'Two actual runs claim one viewport/stage');bound[cell]=ident;proof.update(viewport=cell[0],stage=cell[1],**audit_population_boot(text,cell[0]))
    except Exception:
     retain_failure(run,jobs);raise
    audited[ident]=proof;save(out/'audited-jobs.json',list(audited.values()))
   state.update(at=now(),pr_state=bind_pr(),runs=current,selected_strict_success=len(selected.intersection(audited)),normal_strict_success=len(set(normal_by_id).intersection(audited)),bound_cells=[{'viewport':v,'stage':s,'run_id':ident} for (v,s),ident in sorted(bound.items())],api_requests=counter)
   save(out/'latest.json',state)
   summary=(state['selected_strict_success'],state['normal_strict_success'],tuple((r['id'],r['status'],r['conclusion']) for r in current))
   if summary!=last:
    with (out/'transitions.jsonl').open('a') as f:f.write(json.dumps(state)+'\n')
    print(json.dumps({'at':state['at'],'selected':state['selected_strict_success'],'normal':state['normal_strict_success'],'deadline':state['deadline_utc']}),flush=True);last=summary
   if set(audited)==expected:
    need(set(bound)==cells,'Incomplete actual log-bound18 grid')
    state['final_check_runs']=api('final-check-runs','commits/'+head+'/check-runs?per_page=100')
    state['final_statuses']=api('final-statuses','commits/'+head+'/status')
    need(state['final_check_runs']['total_count']==len(state['final_check_runs']['check_runs']),'Incomplete final check-run inventory')
    checks={c['url']:c for c in state['final_check_runs']['check_runs']}
    for proof in audited.values():
     check=checks.get(proof['check_run_url']);need(check is not None and check['head_sha']==head and check['status']=='completed' and check['conclusion']=='success' and check['name']==proof['job_name'],'Final check-run/job binding differs')
    state.update(status='EXACT_AD813_CI_QUALIFIED_AFTER_ONE_DIAGNOSTIC_MOVING_RERUN',qualification_pass=True,ready_for_root_fresh_merge_review=True);break
   remaining=min(61-(time.monotonic()-tick),deadline-time.monotonic())
   # Never block the steward for >60s; cadence remains at least61s.
   while remaining>0:
    delay=min(remaining,30);time.sleep(delay);remaining-=delay
  need(state['qualification_pass'],'Observer150min deadline without complete qualification; no cancel/rerun')
 except Exception as error:state.update(status='STOPPED_WITH_EVIDENCE',error=str(error))
 finally:
  state.update(ended=now(),elapsed_seconds=time.monotonic()-started,api_requests=counter,selected_strict_success=len(selected.intersection(audited)),normal_strict_success=len(set(normal_by_id).intersection(audited)))
  save(out/'latest.json',state);save(out/'terminal.json',state)
  print(json.dumps({'output':str(out),'status':state['status'],'qualification_pass':state['qualification_pass'],'selected':state['selected_strict_success'],'normal':state['normal_strict_success'],'error':state.get('error')}),flush=True)
 return 0 if state['qualification_pass'] else 1
if __name__=='__main__':raise SystemExit(main())
