#!/usr/bin/env python3
import sys;sys.dont_write_bytecode=True
import ast,copy,hashlib,importlib.util,json,pathlib,shutil,subprocess,tempfile
D=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('collector_v2',D/'collect-GET-only.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]
def check(name,cond):
 if not cond:raise AssertionError(name)
 checks.append({'name':name,'PASS':True})
def refuses(name,fn):
 try:fn()
 except (ValueError,AssertionError):check(name,True);return
 raise AssertionError('Negative accepted: '+name)
old=ast.parse((D/'original-v1/collect-GET-only.py').read_text());new=ast.parse((D/'collect-GET-only.py').read_text())
for name in ['audit_job','smoke_cell','audit_human_jobs','audit_population_boot','checkout_sha']:
 one=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name==name);two=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name==name)
 check('strict V1 helper unchanged '+name,ast.dump(one,include_attributes=False)==ast.dump(two,include_attributes=False))
first=m.preserve_attempt1(D/'collect-GET-only.py');check('actual mandatory first failure/local hashes verified',first['conclusion']=='failure' and first['permanent'])
run=json.loads((D/'attempt1/run.json').read_text());job=json.loads((D/'attempt1/jobs.json').read_text())['jobs'][0]
refuses('actual first failure cannot pass moving attempt2 audit',lambda:m.audit_moving_attempt2_job(job,run,m.MOVING_HEAD))
# Explicit synthetic future-success schema control; never actual attempt2 proof.
r2=copy.deepcopy(run);r2.update(run_attempt=2,status='completed',conclusion='success');j2=copy.deepcopy(job);j2.update(id=119999999999,run_attempt=2,status='completed',conclusion='success',check_run_url='https://api.github.com/repos/kevinrhaas/chicago/check-runs/119999999999')
for s in j2['steps']:s.update(status='completed',conclusion='success')
check('only exact moving run uses expected2',m.expected_attempt(r2)==2)
check('synthetic exact attempt2 full moving+phone success accepted',m.audit_moving_attempt2_job(j2,r2,m.MOVING_HEAD)['run_attempt']==2)
refuses('original strict helper still refuses moving job attempt2',lambda:m.audit_job(j2,r2,m.MOVING_HEAD,'moving-frames',m.NORMAL[m.MOVING_PATH][1]))
for name,field,value in [('wrong head','head_sha','b'*40),('wrong workflow','path','.github/workflows/chicago-4d-smoke.yml'),('wrong workflow ID','workflow_id',999),('wrong event','event','pull_request')]:
 bad=copy.deepcopy(r2);bad[field]=value;refuses('moving exception rejects '+name,lambda bad=bad:m.expected_attempt(bad))
other=copy.deepcopy(r2);other['id']+=1;check('another run remains expected attempt1',m.expected_attempt(other)==1)
third=copy.deepcopy(r2);third['run_attempt']=3;refuses('third attempt refused',lambda:m.audit_moving_attempt2_job(j2,third,m.MOVING_HEAD))
same=copy.deepcopy(j2);same['id']=m.FIRST_JOB_ID;refuses('reused first attempt job ID refused',lambda:m.audit_moving_attempt2_job(same,r2,m.MOVING_HEAD))
same=copy.deepcopy(j2);same['check_run_url']=job['check_run_url'];refuses('reused first attempt check ID refused',lambda:m.audit_moving_attempt2_job(same,r2,m.MOVING_HEAD))
skip=copy.deepcopy(j2);next(s for s in skip['steps'] if s['name']=='A phone keeps the town on the GPU, not twice')['conclusion']='skipped';refuses('attempt2 skipped phone refused',lambda:m.audit_moving_attempt2_job(skip,r2,m.MOVING_HEAD))
failed=copy.deepcopy(j2);next(s for s in failed['steps'] if s['name'].startswith('Walk, turn, fly'))['conclusion']='failure';refuses('attempt2 moving ceiling failure refused',lambda:m.audit_moving_attempt2_job(failed,r2,m.MOVING_HEAD))
receipt=json.loads((D/'ROOT-RERUN-RECEIPT-TEMPLATE-HELD.json').read_text());refuses('unperformed held root rerun receipt refused',lambda:m.validate_rerun_receipt(receipt));receipt.update(status='ROOT_ONE_DIAGNOSTIC_MOVING_RERUN_ACCEPTED',post_attempted=True,post_succeeded=True,requested_at='SYNTHETIC_REQUEST_NOT_ACTUAL',accepted_at='SYNTHETIC_ACCEPT_NOT_ACTUAL',post_result={'returncode':0});check('synthetic single accepted root receipt schema',m.validate_rerun_receipt(receipt))
for field,value in [('authorized_reruns',2),('expected_attempt',3),('run_id',m.MOVING_RUN+1),('first_attempt_failure_remains',False),('post_succeeded',False)]:
 bad=copy.deepcopy(receipt);bad[field]=value;refuses('root receipt rejects '+field,lambda bad=bad:m.validate_rerun_receipt(bad))
with tempfile.TemporaryDirectory(prefix='first-failure-hash-control-',dir=D) as temp:
 p=pathlib.Path(temp);shutil.copytree(D/'attempt1',p/'attempt1');(p/'attempt1/full-job.log').write_bytes(b'altered')
 refuses('changed first failure log refused',lambda:m.preserve_attempt1(p/'collect-GET-only.py'))
heldout=D/'MUST-NOT-EXIST-HELD-CONTROL';assert not heldout.exists();result=subprocess.run([sys.executable,str(D/'collect-GET-only.py'),'--release',str(D/'ROOT-OBSERVE-HELD.json'),'--output',str(heldout)],capture_output=True,text=True);check('held collector refuses before output/network/ownership',result.returncode!=0 and not heldout.exists() and 'HELD: root immutable GET collection release required' in result.stderr)
source=(D/'collect-GET-only.py').read_text();check('sole gh transport remains literal GET',source.count("['gh','api','--method','GET'")==1 and "['gh','api','--method','POST'" not in source)
check('fixed61s/150min guards unchanged',"release.get('poll_seconds')==61 and release.get('max_minutes')==150" in source and 'deadline=started+150*60' in source)
check('attempt-specific GET job/log endpoints',"'/attempts/'+str(expected_attempt(run))+'/jobs?per_page=100'" in source and "'/attempts/'+str(expected_attempt(run))+'/logs'" in source)
report={'status':'OFFLINE_V2_PREPARATION_PASS_NO_ACTUAL_RERUN_RESULT','checks':checks,'source_sha':m.MOVING_HEAD,'only_run_attempt_exception':{'run_id':m.MOVING_RUN,'expected_attempt':2},'first_attempt_failure':first,'future_attempt2_and_root_receipt_positive_controls':'EXPLICITLY_SYNTHETIC; no observed success/POST','POSTs':0,'GETs':0,'observer_started':False}
(D/'OFFLINE-CONTROLS-V2.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'PASS':len(checks),'GETs':0,'POSTs':0}))
