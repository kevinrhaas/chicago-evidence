"""Root-released finite V12 source build/readback. No browser or app changes."""
from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
R=Path(__file__).parent.resolve();START=time.monotonic();BUDGET=90;EXPECTED='327fc0ad0af555556af6c62c7bb0da83e286f278f0627a263adf77e6dda5624b';PY='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python';NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def need(ok,msg):
 if not ok:raise ValueError(msg)
need(sha(R/'SOURCE-MANIFEST.json')==EXPECTED,'Exact root-reviewed source manifest required');m=json.loads((R/'SOURCE-MANIFEST.json').read_text())
for row in m['files']:
 p=(R/row['path']).resolve();need(p.is_relative_to(R) and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'Source input drift '+row['path'])
need(not (R/'GENERATION-INTENT.json').exists() and not (R/'first').exists() and not (R/'repeat').exists(),'Prior intent/output exists; no blind retry')
with (R/'GENERATION-INTENT.json').open('x') as f:json.dump({'authorization_owner':'root','authorization':'Root read independent review7fb13b8a and releases ONE finite V12 generation of exact327fc0ad/patch860e5249. Only6ownedinstances may change,460protectedincl9fittings; no automaticamend/browser/app/ticketclosure. Same-input repeat is a bounded determinism check, not a failed-run retry.','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_manifest_sha256':EXPECTED,'owner_budget_seconds':BUDGET,'python':PY,'node':NODE},f,indent=2)
receipt={'pass':False,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual V12 raw-near source and existing ownership/bounds/Khronos checks only; no visual/photographic/mainworld acceptance','stages':[]};env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def save(): (R/'GENERATION-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(label,args):
 remaining=BUDGET-(time.monotonic()-START)-2;need(remaining>0,'90second owner deadline');p=subprocess.Popen(['nice','-n','10',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True,env=env)
 try:out,err=p.communicate(timeout=remaining)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate(timeout=1);(R/(label+'.stdout.log')).write_text(out);(R/(label+'.stderr.log')).write_text(err);raise TimeoutError('90second owner deadline; owned processgroup killed')
 (R/(label+'.stdout.log')).write_text(out);(R/(label+'.stderr.log')).write_text(err);receipt['stages'].append({'label':label,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-START});save();need(p.returncode==0,'Stage failed '+label)
try:
 for name in ['first','repeat']:run(name,[PY,str(R/'proposed/generate.py'),'--parameters',str(R/'proposed/parameters.json'),'--detail','near','--lod-recipe',str(R/'baseline/lods.json'),'--output',str(R/name)])
 names=sorted(p.name for p in (R/'first').iterdir());need(names==sorted(p.name for p in (R/'repeat').iterdir()),'Repeat output list differs');receipt['repeat_byteexact']={}
 for n in names:need((R/'first'/n).read_bytes()==(R/'repeat'/n).read_bytes(),'Same-input nondeterminism '+n);receipt['repeat_byteexact'][n]=sha(R/'first'/n)
 run('owned-geometry-check',[PY,str(R/'witnesses/check_v12_owned_geometry.py'),'--baseline',str(R/'baseline/brougham-v11.glb'),'--candidate',str(R/'first/brougham.glb'),'--report',str(R/'ACTUAL-OWNERSHIP-CHECK.json')])
 run('khronos',[NODE,str(R/'validate_raw.cjs'),str(R/'first/brougham.glb'),str(R/'KHRONOS-V12-RAW.json')]);receipt['pass']=True
except Exception as e:receipt['error']=repr(e)
finally:receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['seconds']=time.monotonic()-START;save()
need(receipt['pass'],'Finite generation failed; preserve actual failure; no automatic amendment/retry')
print('PASS V12 raw-near source/repeat/460protected/6owned/bounds/Khronos; no browser/app work.')
