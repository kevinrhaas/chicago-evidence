"""HELD prospective V12 ownership contract; no execution before generation release."""
from pathlib import Path
from collections import Counter
import argparse,hashlib,json,math,struct
BASE_SHA='e77ec6fc194db3c8e88e06cbc4fcd6c8a18f1b218d8a98755bedeceb101a35d2'
OWNED={'deep_curved_lower_body':228,'deep_U_closed_door':276,'door_edge_lining':840}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def read(p):
 b=p.read_bytes();need(b[:4]==b'glTF','GLBsignature');n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);off=20+n;bn=struct.unpack_from('<I',b,off)[0];return j,b[off+8:off+8+bn]
def streams(j,b):
 rows={}
 for mesh in j['meshes']:
  prim=mesh['primitives'][0]
  for kind in ['POSITION','NORMAL']:
   a=j['accessors'][prim['attributes'][kind]];v=j['bufferViews'][a['bufferView']];need(a['componentType']==5126 and a['type']=='VEC3' and not v.get('byteStride'),'Rawfloat3source expected');off=v.get('byteOffset',0)+a.get('byteOffset',0);rows[(mesh['name'],kind)]=b[off:off+a['count']*12]
 return rows
def component(rows,p,kind):
 key=(f"surface_{p['frame']}_{p['material']}",kind);start=p['triangle_start_in_batch']*36;return rows[key][start:start+p['triangles']*36]
def bounds(j,rows):
 world={}
 def visit(i,t):
  n=j['nodes'][i];need(not any(k in n for k in ['matrix','rotation','scale']),'Unexpectedtransform');world[i]=[t[k]+n.get('translation',[0,0,0])[k] for k in range(3)]
  for c in n.get('children',[]):visit(c,world[i])
 for root in j['scenes'][j.get('scene',0)]['nodes']:visit(root,[0,0,0])
 lo=[math.inf]*3;hi=[-math.inf]*3
 for i,n in enumerate(j['nodes']):
  if 'mesh' not in n:continue
  name=j['meshes'][n['mesh']]['name']
  for p in struct.iter_unpack('<fff',rows[(name,'POSITION')]):
   for k in range(3):v=p[k]+world[i][k];lo[k]=min(lo[k],v);hi[k]=max(hi[k],v)
 return{'min':lo,'max':hi}
cli=argparse.ArgumentParser();cli.add_argument('--baseline',type=Path,required=True);cli.add_argument('--candidate',type=Path,required=True);cli.add_argument('--report',type=Path,required=True);args=cli.parse_args();need(hashlib.sha256(args.baseline.read_bytes()).hexdigest()==BASE_SHA,'FrozenV11mismatch');a,ab=read(args.baseline);c,cb=read(args.candidate);sa,sc=streams(a,ab),streams(c,cb);pa,pc=a['extras']['parts'],c['extras']['parts'];need(len(pa)==len(pc)==466,'Partcountchanged');protected=0;owned=[];fittings=0
for old,new in zip(pa,pc):
 need(all(old[k]==new[k] for k in ['name','frame','material']),'Partorder/identitychanged');name=old['name']
 if name not in OWNED:
  need(old['triangles']==new['triangles'],'Unownedcostchanged '+name)
  for kind in ['POSITION','NORMAL']:need(component(sa,old,kind)==component(sc,new,kind),'Unownedstreamchanged '+name+'/'+kind)
  protected+=1;fittings+=int(name.startswith('source_near_'));continue
 need(new['triangles']==OWNED[name],'Ownedcostunexpected '+name);pp=list(struct.iter_unpack('<fff',component(sc,new,'POSITION')));nn=list(struct.iter_unpack('<fff',component(sc,new,'NORMAL')));need(all(math.isfinite(x) for p in pp+nn for x in p),'Nonfiniteownedvertex');need(all(abs(math.sqrt(sum(x*x for x in n))-1)<1e-5 for n in nn),'Nonunitownednormal');edges=Counter();volume=0.0
 for i in range(0,len(pp),3):
  p=pp[i:i+3];u=[p[1][k]-p[0][k] for k in range(3)];v=[p[2][k]-p[0][k] for k in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];length=math.sqrt(sum(x*x for x in cross));need(length>1e-10,'Degenerateownedtriangle');need(all(sum(cross[k]*nn[i+t][k] for k in range(3))/length>.9999 for t in range(3)),'Ownednormaldirection');det=[p[1][1]*p[2][2]-p[1][2]*p[2][1],p[1][2]*p[2][0]-p[1][0]*p[2][2],p[1][0]*p[2][1]-p[1][1]*p[2][0]];volume+=sum(p[0][k]*det[k] for k in range(3))/6
  for x,y in [(0,1),(1,2),(2,0)]:edges[tuple(sorted((p[x],p[y])))]+=1
 need(all(v==2 for v in edges.values()) and volume>0,'Ownedclosedvolumecheck '+name);owned.append({'name':name,'material':new['material'],'triangles':new['triangles'],'signed_volume_m3':volume,'closed_welded':True,'position_changed':component(sa,old,'POSITION')!=component(sc,new,'POSITION')})
need(protected==460 and fittings==9,'Expected460protectedincl9fittings');need(Counter(p['name'] for p in owned)==Counter({k:2 for k in OWNED}),'Ownedinstancecount');need(all(p['position_changed'] for p in owned),'Expectedownedshapechange')
for key in ['nodes','scenes','scene','materials']:need(a.get(key)==c.get(key),'Protectedmetadatachanged '+key)
b0,b1=bounds(a,sa),bounds(c,sc);need(b0==b1,'Actualglobalboundschanged');need(c['extras']['statistics']=={'triangles':32670,'meshes':24,'nodes':41},'Unexpectedglobalcost')
x,y=a['extras']['parameters'],c['extras']['parameters'];allowed={'revision','limits','door_profile_z_y_m','lower_side_profile_z_y_m'};need(set(y)==set(x)|{'door_profile_sampling','large_forms_v12'},'Unexpectedparameterfields');need(all(y[k]==x[k] for k in x if k not in allowed),'Protecteddimension/featureparamschanged');need(y['revision']==12 and y['limits'][:-1]==x['limits'],'Unexpectedrevisionlimits')
report={'pass':True,'scope':'OwnedV12rawgeometrycontract only; no actualsource/photographic/mainworld orintersectionacceptance','candidate_sha256':hashlib.sha256(args.candidate.read_bytes()).hexdigest(),'unmodified_part_PN_exact':protected,'fittings9_PN_exact':True,'owned_instances':owned,'all_nodes_materials_scenes_anchors_exact':True,'actual_global_bounds_exact':True,'actual_global_bounds_m':b1,'statistics':c['extras']['statistics'],'closed_volume_does_not_establish_no_intersections':True};args.report.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
