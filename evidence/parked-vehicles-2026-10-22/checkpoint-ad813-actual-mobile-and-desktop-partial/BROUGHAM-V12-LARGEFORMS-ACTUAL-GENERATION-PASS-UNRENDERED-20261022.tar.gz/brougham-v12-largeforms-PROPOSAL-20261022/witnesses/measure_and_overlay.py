"""Prospective boundary math/SVG only; never invokes a model producer or renderer."""
from pathlib import Path
import json,math,html,base64,importlib.util
R=Path(__file__).parents[1];old=json.loads((R/'baseline/parameters.json').read_text());new=json.loads((R/'proposed/parameters.json').read_text());h=json.loads((R/'baseline/camera-hypothesis.json').read_text())['fit'];source=json.loads((R/'witnesses/SOURCE-EDGE-LANDMARKS.json').read_text());width=lambda y:old['body_half_width_m']-.18*max(0,min(1,(1.26-y)/.91));dot=lambda a,b:sum(x*y for x,y in zip(a,b))
def sample(q,steps,closed=False):
 out=[];n=len(q)
 for i in range(n if closed else n-1):
  a=q[(i-1)%n] if closed else q[max(0,i-1)];b=q[i];c=q[(i+1)%n];d=q[(i+2)%n] if closed else q[min(n-1,i+2)]
  for k in range(steps):
   t=k/steps;out.append([.5*(2*b[j]+(-a[j]+c[j])*t+(2*a[j]-5*b[j]+4*c[j]-d[j])*t*t+(-a[j]+3*b[j]-3*c[j]+d[j])*t*t*t) for j in range(2)])
 return out if closed else out+[q[-1]]
def profile(p,name):
 q=p[name]
 return sample(q,5,True) if name=='door_profile_z_y_m' and p['revision']==12 else sample(q[:-1],5 if name.startswith('door') else 4)+[q[-1]]
def world(q,off):
 z,y=q;return[width(y)+off,y*1.13+.03,z]
def project(v):
 d=h['distance_m']-dot(v,h['basis']['towardCamera']);return[h['principal_px'][0]+h['focal_px']*dot(v,h['basis']['right'])/d,h['principal_px'][1]-h['focal_px']*dot(v,h['basis']['up'])/d]
def intersect(a,b,c,d):
 cross=lambda p,q,r:(q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
 return cross(a,b,c)*cross(a,b,d)<-1e-14 and cross(c,d,a)*cross(c,d,b)<-1e-14
def simple(q):
 edges=list(zip(q,q[1:]+q[:1]));bad=[]
 for i,(a,b) in enumerate(edges):
  for j,(c,d) in enumerate(edges):
   if j<=i+1 or (i==0 and j==len(edges)-1):continue
   if intersect(a,b,c,d):bad.append([i,j])
 return bad
paths={}
for k,off in [('door_profile_z_y_m',.052),('lower_side_profile_z_y_m',.026)]:
 for version,p in [('v11',old),('v12',new)]:
  q=profile(p,k);paths[version+'_'+k]={'producer_z_y_m':q,'world_m':[world(v,off) for v in q],'projected_source_px':[project(world(v,off)) for v in q],'proper_self_intersections':simple(q)}
def inside(point,poly):
 x,y=point;yes=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:yes=not yes
 return yes
spec=importlib.util.spec_from_file_location('details',R/'proposed/source_details.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);features=m.feature_plan(new);mounts=[]
for f in features:
 if f['kind']=='beam':
  v=f['start'];mounts.append({'name':f['name'],'producer_y_z_m':[v[1],v[2]],'inside_candidate_door_profile':inside([v[2],v[1]],paths['v12_door_profile_z_y_m']['producer_z_y_m'])})
allworld=[v for key,row in paths.items() if key.startswith('v12') for v in row['world_m']];lo=[min(v[k] for v in allworld) for k in range(3)];hi=[max(v[k] for v in allworld) for k in range(3)];doorN=len(paths['v12_door_profile_z_y_m']['producer_z_y_m']);bodyN=len(paths['v12_lower_side_profile_z_y_m']['producer_z_y_m']);addedcap=2*((4*doorN-4)-184)+2*((4*bodyN-4)-196);extra={}
for detail,base,sides in [('near',31870,6),('mid',19134,6),('far',10730,4)]:extra[detail]={'changed_caps_added_triangles':addedcap,'changed_lining_added_triangles':2*2*sides*(doorN-47),'predicted_total_triangles':base+addedcap+2*2*sides*(doorN-47)}
result={'state':'PROSPECTIVE_NUMERIC_BOUNDARY_ONLY_NO_MODEL_OR_RENDER','paths':paths,'candidate_boundary_bounds_m':[lo,hi],'counts':{'door_boundary_vertices':doorN,'body_boundary_vertices':bodyN},'predicted_cost':extra,'mount_centerline_containment':mounts,'fittings9_plan_exact':features==m.feature_plan(old),'preserved_existing_glass_bottom_source_px':[project([old['body_half_width_m']+.019,y*1.13+.03,z]) for z,y in old['side_door_glass_profile_z_y_m']],'limits':'Prospective cap boundary checks are not fullmesh validation. Centerline-in-polygon is not attachment volume/intersection/lock operation proof. Opposite side is an inferred mirror. No actual geometry, normals, shadow, source fidelity or photographic acceptance.'};(R/'witnesses/PROSPECTIVE-CONTOUR-WITNESS.json').write_text(json.dumps(result,indent=2)+'\n')
# A scientific SVG overlay of unchanged source pixels with independently projected plan paths.
encoded=base64.b64encode((R/'baseline/valid-1893-plate0095.jpg').read_bytes()).decode();colors={'v11_door_profile_z_y_m':'#ff4869','v12_door_profile_z_y_m':'#22ffd2','v11_lower_side_profile_z_y_m':'#ff9f43','v12_lower_side_profile_z_y_m':'#54adff'}
def path(q):return'M'+' L'.join(','.join(f'{v:.3f}' for v in p) for p in q)+' Z'
for group,keys,crop in [('door',['v11_door_profile_z_y_m','v12_door_profile_z_y_m'],[950,600,190,245]),('body',['v11_lower_side_profile_z_y_m','v12_lower_side_profile_z_y_m'],[900,600,390,255]),('waist',['v11_door_profile_z_y_m','v12_door_profile_z_y_m'],[955,595,185,70])]:
 parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1140" height="{int(1140*crop[3]/crop[2])}" viewBox="{" ".join(map(str,crop))}"><title>PROSPECTIVE V12 {group} boundary overlay, not actual rendered geometry</title>',f'<image href="data:image/jpeg;base64,{encoded}" x="0" y="0" width="1556" height="1145"/>']
 for key in keys:parts.append(f'<path d="{path(paths[key]["projected_source_px"])}" fill="none" stroke="{colors[key]}" stroke-width="1" '+('stroke-dasharray="3 2"' if key.startswith('v11') else '')+'/>')
 controls=source['door_controls'] if group!='body' else source['lowerbody_controls']
 for i,r in enumerate(controls):
  x,y=r['native_px'];e=r['uncertainty_px'];parts.append(f'<g stroke="#fff26a" fill="none" stroke-width=".5"><path d="M{x-e},{y}H{x+e} M{x},{y-e}V{y+e}"/><circle cx="{x}" cy="{y}" r="1.1"/></g>')
 glass=result['preserved_existing_glass_bottom_source_px'];parts.append(f'<path d="{path(glass)}" fill="none" stroke="#df92ff" stroke-width=".6" stroke-dasharray="1 2"/>');parts.append('</svg>');(R/'witnesses'/('PROSPECTIVE-'+group.upper()+'-OVERLAY.svg')).write_text(''.join(parts))
page='''<!doctype html><meta charset="utf-8"><title>Prospective V12 contour witnesses</title><style>body{font:16px system-ui;max-width:1140px;margin:30px auto;background:#17201d;color:#eee}img{width:100%;display:block;margin:15px 0}code{color:#f6cf6e}</style><h1>Prospective V12 boundary overlays</h1><p>These are numerical source-plane projections drawn over unchanged source JPEG pixels, <b>not rendered candidate geometry or an actual appearance pass</b>. Dashed red/orange: V11 door/body. Solid cyan/blue: proposed V12. Yellow crosses: informal observed controls with uncertainty. Dotted lilac: existing glass outline, preserved. Multiple bright edges and hidden construction remain uncertain; source is an1893catalog illustration, not a photograph.</p>'''
for name in ['WAIST','DOOR','BODY']:page+=f'<h2>{name.title()}</h2><img src="PROSPECTIVE-{name}-OVERLAY.svg" alt="Prospective {name.lower()} source boundary overlay">'
page+='<p>No model generation, browser, material/light/camera changes or photographic acceptance.</p>';(R/'witnesses/INDEX.html').write_text(page)
print(json.dumps({'counts':result['counts'],'cost':extra,'mounts':mounts,'fittings9_plan_exact':result['fittings9_plan_exact'],'proper_intersections':{k:row['proper_self_intersections'] for k,row in paths.items() if k.startswith('v12')}},indent=2))
