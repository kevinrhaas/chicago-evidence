# Desktop functional continuation V1 — HELD

No launch during preparation. Root must verify mobile CLOSED and the heavy/browser lane free before creating an explicit release file. This is a separate540s execution against exact pushed ad813a6278b7d76961b78ef3483f1bbf3e106c02, index76a3eaf8fa5363811ff1abc96b8a8824c6f9091ed796bbc9d5617db8b08680d6 and the original desktop V3 app/published/canonical pins. No app, Git, mirror, timing threshold or geometry edits.

Original desktop V3 is an actual **partial/FAIL**, deadlineReached:true, pass:false, sourceUnchanged:true, closed:true. It completed profile/front/quarter/card PNGs and seven-rAF diagnostic, with the last completed phase timing and next phase loader_started at449033ms. It timed out before the combined loader returned and before far was reached. Its full receipt, progress, log and four PNGs are archived separately; no partial loader result is invented.

This caller repeats only ordinary boot/entry/installation, then executes unchanged far() at Lake-at-Canal **first**. All original snapshot, actual autoLOD3,45–140m distance, root/instance, culling, shoe/terrain, GL and public-budget assertions remain. Far intentionally uses the original framing:false scope; no new promise of near-camera10% padding or shoe pixel visibility is made for this far observation.

Then lod0,1,2,3 are acquired one at a time through the same production humans.assets API, checked for9 skinned meshes,56 bones each and idle/walk/sit_drive clips, and released in finally. The existing loader body is extracted as loaderOne(lod); loader() remains a compatible four-row wrapper. Each completed row is immediately written as loader-lodN.json and included in progress.json before the next request. Pending work at a deadline remains missing, never PASS.

No view screenshot, own-card interaction or seven-rAF timing is replayed. Their original exact receipt hash and capture metadata are recorded as **separate-execution inherited evidence**. A later continuation pass is only this functional phase, never a whole V3 run PASS or moving-CI qualification. Existing540000ms cap, boot/entry bounds, server/browser ownership/cleanup and final source/index/pin reconciliation remain unchanged. Existing error assertions remain; no automatic retries or camera/render adaptation.

Review EXACT-V3-TO-CONTINUATION.patch and STATIC-CONTROLS.json. Both source files pass node --check. Static controls compare byte-identical far and snapshot blocks, original loader guard/release body and cleanup tail. They are preparation checks, not browser acceptance.

Root copies RELEASE-HELD.json to /workspace/shared/ROOT-BARDWELL-DESKTOP-FUNCTIONAL-CONTINUATION-V1-RELEASE.json, changes released and gate79092_closed to true only after real lane closure, and retains every exact pin. Output must remain fresh (mkdir recursive:false).

```sh
PW_EXECUTABLE=/usr/bin/chromium node /workspace/shared/human-standing-bardwell-DESKTOP-FUNCTIONAL-CONTINUATION-V1-HELD-20261022/capture_town.cjs /workspace/shared/ROOT-BARDWELL-DESKTOP-FUNCTIONAL-CONTINUATION-V1-RELEASE.json > /workspace/shared/bardwell-ad813-DESKTOP-FUNCTIONAL-CONTINUATION-V1-ACTUAL-20261022.log 2>&1
```

Run in the authorized escalated execution environment, as prior callers required Git/child-process access there. No observer, browser or server is started by this support packet. Large app/vendor/GLB inputs are external; CANONICAL-EXPECTED-INPUTS.json and original inputPins specify their exact current bytes. This archive alone is not a runnable published town.
