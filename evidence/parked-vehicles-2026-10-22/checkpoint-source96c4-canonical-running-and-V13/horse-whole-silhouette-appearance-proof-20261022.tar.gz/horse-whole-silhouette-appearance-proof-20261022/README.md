# T2800 whole-silhouette actual outcome

One exact source-reviewed static build, one bounded independent actual geometry screen, one exact four-camera capture. Build exit0/.526s; readback exit0/15.904s wall under explicitly authorized25CPU/40wall and unchanged600000candidatecap; capture exit0/6.144s. No automatic retries. No app install, rig, sockets or ticket closure.

Actual GLB2fa2e6f4 is847176bytes/35168tri/17586vertices/6material groups. All264770AABB candidate pairs screened: zero strict proper crossings, valid two-owner edges/vertex links/Euler2, one actual component, exact exported positions/indices, finite unit normals. Four feet have49Y0sole vertices each. Because changed shoulder ports alter propagated angular samples, actual four-sole vertex meanZ is now+.281512737mm, separately measured from authoredcontactmean0 and replacing the previous+.5903095mm actual result. This is not a hidden scene offset or redefinition.

New source intentionally modifies lower-neck station7 with8mm flank relief, beyond subdivision halo. All actual scope is disclosed in the build receipt and source review. This bounded screen does not certify coplanar contact/tangency/containment, hair thickness, anatomical appearance or photographic quality.

All four new images were personally opened. Whole silhouette improves, particularly straighter lower hindlimbs and more readable joints, but the horse remains schematic: hose-like tail, solid mane ridge, soft unresolved anatomy, deerlike head and no photographic surface detail. Read APPEARANCE-REVIEW.json. Root must inspect actual images and decide next scope; do not install or close T2800 from mechanical passes. A substantially better cleared realistic base should take precedence when normally acquirable.

Exact source and caller archives, independent source review, actual model, actual four images, parentd356comparison images, camera/clip receipts, ownership cleanup and geometry-reader source/adaptation/terminal are included. Earlier failed and rejected packets remain preserved.
