import pathlib,json,hashlib,struct,collections,time,math,resource
resource.setrlimit(resource.RLIMIT_CPU,(25,25))
import numpy as np
P=pathlib.Path('/workspace/shared/horse-whole-silhouette-static-first-20261022');O=pathlib.Path(__file__).parent;start=time.monotonic();sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(P/'horse-anatomical-static-unaccepted.glb').read_bytes();assert sha(raw)=='2fa2e6f46fb981d61eb50deec115c4a72f85bf854a74d9c93bc591965a7dcd38';sraw=(P/'static-subdivided-surface.json').read_bytes();s=json.loads(sraw);m=json.loads((P/'manifest.json').read_text());c=json.loads(pathlib.Path('/workspace/shared/horse-whole-silhouette-source-20261022/proposed/anatomy-authoring-controls.json').read_text());assert m['anatomy_controls']==c
v=s['vertices'];faces=s['faces'];regions=s['regions'];mats=s['materials'];V=np.asarray(v);assert np.isfinite(V).all();edges=collections.defaultdict(list);links=[collections.defaultdict(list)for _ in v];tri=[];trireg=[];trimat=[]
for fi,f in enumerate(faces):
 assert len(f)==len(set(f))==4 and all(type(x)is int and 0<=x<len(v)for x in f)
 for i,x in enumerate(f):
  prev,nxt=f[i-1],f[(i+1)%len(f)];links[x][prev].append(nxt);links[x][nxt].append(prev);edges[tuple(sorted((x,nxt)))].append((fi,x,nxt))
 for i in range(1,len(f)-1):tri.append([f[0],f[i],f[i+1]]);trireg.append(regions[fi]);trimat.append(mats[fi])
badedges=[(e,x)for e,x in edges.items()if len(x)!=2 or x[0][1:]==x[1][1:]];badlinks=[]
for i,graph in enumerate(links):
 bad=not graph or any(len(ns)!=2 for ns in graph.values());seen=set();q=[next(iter(graph))]if graph else[]
 while q:
  a=q.pop()
  if a in seen:continue
  seen.add(a);q.extend(graph[a])
 if bad or len(seen)!=len(graph):badlinks.append({'vertex':i,'degrees':[len(z)for z in graph.values()],'components_connected':len(seen)==len(graph)})
# Actual glTF accessors, finite/index/normal checks, independent correspondence to source surface.
n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);blob=raw[n+28:]
def acc(index):
 a=g['accessors'][index];b=g['bufferViews'][a['bufferView']];width={'VEC3':3,'SCALAR':1}[a['type']];dt='<f4'if a['componentType']==5126 else'<u4';return np.frombuffer(blob,dtype=dt,count=a['count']*width,offset=b.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,width)
prims=g['meshes'][0]['primitives'];pos=acc(prims[0]['attributes']['POSITION']);nor=acc(prims[0]['attributes']['NORMAL']);assert np.array_equal(pos,np.asarray(v,dtype='<f4'));assert np.isfinite(nor).all();nl=np.linalg.norm(nor,axis=1);alltri=[]
for p in prims:
 ids=acc(p['indices']).reshape(-1,3);assert ids.min()>=0 and ids.max()<len(v);alltri.extend(tuple(x)for x in ids.tolist())
assert collections.Counter(map(tuple,tri))==collections.Counter(alltri);assert not g.get('skins')and not g.get('animations')and len(g['nodes'])==1
T=np.asarray(tri,dtype=np.int32);A=pos[T].astype(np.float64);N=np.cross(A[:,1]-A[:,0],A[:,2]-A[:,0]);area=np.linalg.norm(N,axis=1)/2;assert np.isfinite(area).all()
# Each semantic region seam has actually shared vertex IDs; no positional welding is assumed.
vr=collections.defaultdict(set)
for f,r in zip(faces,regions):
 for i in f:vr[i].add(r)
seams=collections.Counter(tuple(sorted(rs))for rs in vr.values()if len(rs)>1)
sole={}
for name in ['fore_l','fore_r','hind_l','hind_r']:
 ids={x for f,r in zip(faces,regions)if r==name for x in f};ps=pos[sorted(ids)];flat=ps[np.abs(ps[:,1])<1e-8];sole[name]={'region_vertices':len(ids),'actual_y_min':float(ps[:,1].min()),'sole_plane_vertex_count':len(flat),'sole_x_bounds':[float(flat[:,0].min()),float(flat[:,0].max())],'sole_z_bounds':[float(flat[:,2].min()),float(flat[:,2].max())],'sole_mean_x_z':[float(flat[:,0].mean()),float(flat[:,2].mean())],'declared_contact':c['proposed_contacts_m'][name]}
# Full AABB candidate enumeration on a5cm grid; hard finite cap prevents a dense surprise from burdening the gate.
lo=A.min(1);hi=A.max(1);grid=collections.defaultdict(list);step=.05
for i,(ll,hh)in enumerate(zip(lo,hi)):
 low=np.floor(ll/step).astype(int);high=np.floor(hh/step).astype(int)
 for x in range(low[0],high[0]+1):
  for y in range(low[1],high[1]+1):
   for z in range(low[2],high[2]+1):grid[x,y,z].append(i)
pairs=set();cap=600000
for ids in grid.values():
 for k,a in enumerate(ids):
  for b in ids[k+1:]:
   if a>b:a0,b0=b,a
   else:a0,b0=a,b
   if np.all(lo[a0]<=hi[b0]+1e-10)and np.all(lo[b0]<=hi[a0]+1e-10):pairs.add((a0,b0))
 if len(pairs)>cap:raise RuntimeError('Finite candidate cap exceeded; do not assert intersection clearance')
C=np.asarray(sorted(pairs),dtype=np.int32);hit=np.zeros(len(C),dtype=bool)
def segments_into(a,b):
 e1=b[:,1]-b[:,0];e2=b[:,2]-b[:,0];out=np.zeros(len(a),dtype=bool)
 for k in range(3):
  origin=a[:,k];direction=a[:,(k+1)%3]-origin;h=np.cross(direction,e2);det=np.einsum('ij,ij->i',e1,h);valid=np.abs(det)>1e-12;inv=np.divide(1.,det,out=np.zeros_like(det),where=valid);s=origin-b[:,0];u=inv*np.einsum('ij,ij->i',s,h);q=np.cross(s,e1);vv=inv*np.einsum('ij,ij->i',direction,q);t=inv*np.einsum('ij,ij->i',e2,q);out|=valid&(u>1e-8)&(vv>1e-8)&(u+vv<1-1e-8)&(t>1e-8)&(t<1-1e-8)
 return out
for k in range(0,len(C),20000):
 cc=C[k:k+20000];a=A[cc[:,0]];b=A[cc[:,1]];hit[k:k+len(cc)]=segments_into(a,b)|segments_into(b,a)
hits=C[hit];positive=[]
for i,j in hits[:200]:positive.append({'triangle_ids':[int(i),int(j)],'regions':[trireg[i],trireg[j]],'shared_vertices':sorted(set(tri[i])&set(tri[j])),'triangles_m':[A[i].tolist(),A[j].tolist()]})
summary=collections.Counter(tuple(sorted([trireg[i],trireg[j]]))for i,j in hits)
result={'scope':'Independent finite actual decoded geometry screen; no producer/build/browser/CI or app write','GLB_sha256':sha(raw),'surface_sha256':sha(sraw),'frozen_source_archive_sha256':'6beb0a4ce5495c606c17eb09dd60af452b7e8c37892b9c1c796f70ba4e57da1c','controls_match_frozen':True,'vertices':len(v),'quad_faces':len(faces),'triangles':len(tri),'edge_count':len(edges),'Euler_V_E_F':len(v)-len(edges)+len(faces),'bad_edge_count':len(badedges),'bad_vertex_links':badlinks,'finite_and_export_positions_indices_match':True,'normal_length_minmax':[float(nl.min()),float(nl.max())],'triangle_area_min':float(area.min()),'bounds_minmax':[pos.min(0).tolist(),pos.max(0).tolist()],'shared_region_seam_vertices':[{'regions':list(k),'shared_vertices':z}for k,z in seams.items()],'sole_readback':sole,'proper_intersection_screen':{'grid_cell_m':step,'AABB_candidate_pairs':len(C),'actual_proper_crossing_pairs':len(hits),'region_pair_counts':[{'regions':list(k),'pairs':z}for k,z in summary.items()],'positive_examples':positive,'all_positive_triangle_pairs':hits.tolist(),'limits':'Strict interior segment/triangle crossings only. Does not certify coplanar overlap/tangency or photographic shape; actual visuals remain required.'},'elapsed_seconds':time.monotonic()-start}
(O/'READBACK.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['vertices','quad_faces','triangles','Euler_V_E_F','bad_edge_count','bad_vertex_links','normal_length_minmax','bounds_minmax','elapsed_seconds']},indent=2));print('INTERSECTIONS',len(C),len(hits),summary);print('SOLES',json.dumps(sole))
