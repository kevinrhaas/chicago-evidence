from pathlib import Path
import json,hashlib,difflib,shutil
R=Path(__file__).parent;V=Path('/workspace/shared/human-standing-bardwell-town-review-V3-fixed-front-PREPARED-HELD-20261022');F=Path('/workspace/shared/human-standing-bardwell-DESKTOP-FUNCTIONAL-CONTINUATION-V1-HELD-20261022');s=(V/'capture_town.cjs').read_text();original=s
s=s.replace("cfg.gate79092_closed!==true||!['desktop','mobile'].includes(cfg.viewport)","cfg.rootLaneClosed!==true||!['desktop_visual','desktop_functional','mobile_full'].includes(cfg.phase)||({desktop_visual:'desktop',desktop_functional:'desktop',mobile_full:'mobile'})[cfg.phase]!==cfg.viewport")
s=s.replace("||cfg.maxMillis!==540000)throw Error(","||cfg.expectedHead==='ad813a6278b7d76961b78ef3483f1bbf3e106c02'||!/^[a-f0-9]{64}$/.test(cfg.expectedCanonicalInputsSHA||'')||cfg.maxMillis!==540000)throw Error(")
s=s.replace("const canonical=JSON.parse(fs.readFileSync(path.join(__dirname,'CANONICAL-EXPECTED-INPUTS.json'))),pins={},pin=", "const canonicalPath=path.join(__dirname,'CANONICAL-EXPECTED-INPUTS-HELD.json'),canonicalBytes=fs.readFileSync(canonicalPath),canonical=JSON.parse(canonicalBytes),pins={[canonicalPath]:sha(canonicalBytes)},pin=")
needle="for(const rel of ['data/scenes/1835.json'"
guard="""const oldWebHashes=new Set(['47132fdfe27c1c144039e2db708bca6da6db63c201b37351a7632f1c0f45a953','485856360666b48ea0534e645ebda0e678af63be9e66514be78df0621a262454','b9976874ae6a20a1e884bec62d97c4039312ae2e8ac4bd5cfbffd8148192485a','c86fff664ac893d0fb5d6877040a0d0a9d388dc9f25acfc208be0eeb13e12ad2']);
if(sha(canonicalBytes)!==cfg.expectedCanonicalInputsSHA||canonical.state!=='ROOT_PINNED_FINAL_CANONICAL_INPUTS'||canonical.final_head!==cfg.expectedHead||canonical.final_index_digest!==cfg.expectedIndexDigest||!Number.isInteger(canonical.canonical_run_id)||canonical.canonical_run_id===39712579846||!/^[a-f0-9]{40}$/.test(canonical.canonical_source_sha||'')||!/^[a-f0-9]{64}$/.test(canonical.artifact_zip_sha256||'')||!/^[a-f0-9]{64}$/.test(canonical.instance_sha256||'')||canonical.web_lods?.length!==4||canonical.web_lods.some((r,i)=>r.filename!==`bardwell_otis_1835.lod${i}.glb`||!/^[a-f0-9]{64}$/.test(r.sha256||'')||oldWebHashes.has(r.sha256)||!Number.isInteger(r.bytes)||r.bytes<=0))throw Error('HELD: final imported/committed/published canonical source/artifact/instance/four NEW web LOD pins required');
"""
assert needle in s;s=s.replace(needle,guard+needle,1)
old="for(const r of canonical.web_lods){if(sha(pin(app,'assets/humans/web/'+r.filename))!==r.sha256||sha(pin(site,'data/humans/web/'+r.filename))!==r.sha256)throw Error('Actual published canonical GLB bytes differ '+r.filename);}"
new="for(const r of canonical.web_lods){const source=pin(app,'assets/humans/web/'+r.filename),published=pin(site,'data/humans/web/'+r.filename);if(source.length!==r.bytes||published.length!==r.bytes||sha(source)!==r.sha256||sha(published)!==r.sha256)throw Error('Actual published canonical GLB bytes differ '+r.filename);}"
assert old in s;s=s.replace(old,new)
needle="const out=path.resolve(cfg.output);"
inherit="""let visualReceipt=null;
if(cfg.phase==='desktop_functional'){
 if(!cfg.baseVisualReceipt?.startsWith('/workspace/shared/')||!/^[a-f0-9]{64}$/.test(cfg.baseVisualReceiptSHA||''))throw Error('HELD: NEW same-head completed visual receipt required');
 const b=fs.readFileSync(cfg.baseVisualReceipt);visualReceipt=JSON.parse(b);
 if(sha(b)!==cfg.baseVisualReceiptSHA||visualReceipt.phase!=='desktop_visual'||visualReceipt.desktopVisualPass!==true||visualReceipt.pass!==true||!visualReceipt.closed||!visualReceipt.sourceUnchanged||visualReceipt.deadlineReached||visualReceipt.head!==cfg.expectedHead||visualReceipt.indexDigest!==cfg.expectedIndexDigest||visualReceipt.captures?.length!==4||visualReceipt.timing?.samples!==7||Object.keys(pins).length!==Object.keys(visualReceipt.inputPins||{}).length||Object.entries(pins).some(([p,h])=>visualReceipt.inputPins[p]!==h))throw Error('NEW same-head visual evidence/pins mismatch; old ad813 partial cannot qualify');
}
"""
assert needle in s;s=s.replace(needle,inherit+needle,1)
s=s.replace("identity:'actual_published_bardwell_standing_town_v3_prospective_fixed_front',scope:","identity:'actual_published_bardwell_final_head_split_v1',phase:cfg.phase,inheritedVisual:visualReceipt?{receipt:cfg.baseVisualReceipt,sha256:cfg.baseVisualReceiptSHA,head:visualReceipt.head,captures:visualReceipt.captures.map(({file,sha256,bytes})=>({file,sha256,bytes})),timing:visualReceipt.timing,separateExecution:true}:null,scope:")
s=s.replace("One finite published-town normal viewport, exact canonical assets and fixed reachable standing cameras; initial visible increment, not photographic/occupied/world completion. Focused local budget readings do not replace normal smoke part5 worst-stand gate.","One final-head phase only: desktop_visual=views/card/timing; desktop_functional=far-first/four loader rows; mobile_full=full V3 grid. Separate desktop executions do not become a monolithic V3 PASS. No photographic/moving-CI/full-smoke qualification. Local budget readings do not replace part5 worst-stand.")
start=" for(const view of ['profile','front','quarter'])"
assert start in s;s=s.replace(start," if(cfg.phase!=='desktop_functional'){\n"+start,1)
old="phase('loader_started');receipt.loader=await page.evaluate(()=>window.__bardwellTownReview.loader());phase('far_started');receipt.far=await page.evaluate(()=>window.__bardwellTownReview.far());phase('all_planned_work_completed');"
new="""phase('visual_work_completed');}
 if(cfg.phase==='desktop_functional'){
  phase('far_started');receipt.far=await page.evaluate(()=>window.__bardwellTownReview.far());phase('far_completed');receipt.loader=[];
  for(let lod=0;lod<4;lod++){remaining();phase('loader_one_started',{lod});const row=await page.evaluate(lod=>window.__bardwellTownReview.loaderOne(lod),lod);receipt.loader.push(row);fs.writeFileSync(path.join(out,'loader-lod'+lod+'.json'),JSON.stringify(row,null,2)+'\\n');phase('loader_one_completed',{lod});}
 }else if(cfg.phase==='mobile_full'){phase('loader_started');receipt.loader=await page.evaluate(()=>window.__bardwellTownReview.loader());phase('far_started');receipt.far=await page.evaluate(()=>window.__bardwellTownReview.far());}
 phase('all_planned_phase_work_completed');"""
assert old in s;s=s.replace(old,new,1)
old="if(receipt.captures.length!==4||receipt.loader.length!==4||receipt.far.state.lod!==3)throw Error('Finite planned capture/LOD grid incomplete');receipt.pass=true;"
new="""if(cfg.phase==='desktop_visual'){if(receipt.captures.length!==4||receipt.timing?.samples!==7||receipt.loader||receipt.far)throw Error('Desktop visual phase incomplete');receipt.desktopVisualPass=true;}
 else if(cfg.phase==='desktop_functional'){if(receipt.captures.length!==0||receipt.loader?.length!==4||receipt.loader.some((r,i)=>r.lod!==i)||receipt.far?.state.lod!==3)throw Error('Desktop functional phase incomplete');receipt.desktopFunctionalPass=true;}
 else if(receipt.captures.length!==4||receipt.timing?.samples!==7||receipt.loader?.length!==4||receipt.far?.state.lod!==3)throw Error('Mobile full V3 grid incomplete');receipt.pass=true;"""
assert old in s;s=s.replace(old,new,1)
(R/'capture_town.cjs').write_text(s);shutil.copy2(F/'browser_review.cjs',R/'browser_review.cjs')
canonical={'state':'HELD_PENDING_ACTUAL_NEW_CANONICAL_IMPORT_COMMIT_AND_PUBLISH','final_head':None,'final_index_digest':None,'canonical_run_id':None,'canonical_source_sha':None,'artifact_zip_sha256':None,'instance_sha256':None,'web_lods':[{'filename':f'bardwell_otis_1835.lod{i}.glb','sha256':None,'bytes':None}for i in range(4)],'note':'Root fills from actual new canonical source/run/artifact and imported committed published bytes. Old ad813/39712579846/old web GLBs are forbidden as new qualification.'}
(R/'CANONICAL-EXPECTED-INPUTS-HELD.json').write_text(json.dumps(canonical,indent=2)+'\n')
for phase,viewport in [('desktop_visual','desktop'),('desktop_functional','desktop'),('mobile_full','mobile')]:
 cfg={'released':False,'rootLaneClosed':False,'phase':phase,'viewport':viewport,'expectedHead':None,'expectedIndexDigest':None,'expectedCanonicalInputsSHA':None,'output':None,'maxMillis':540000,'note':'HELD. Root repins only after actual canonical import/commit/publish; one phase on a free lane; fixed V3 cameras and all original guards unchanged.'}
 if phase=='desktop_functional':cfg.update(baseVisualReceipt=None,baseVisualReceiptSHA=None)
 (R/('RELEASE-'+phase+'-HELD.json')).write_text(json.dumps(cfg,indent=2)+'\n')
patch=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='original-v3/capture_town.cjs',tofile='final-split/capture_town.cjs'))
patch+=''.join(difflib.unified_diff((V/'browser_review.cjs').read_text().splitlines(True),(R/'browser_review.cjs').read_text().splitlines(True),fromfile='original-v3/browser_review.cjs',tofile='final-split/browser_review.cjs'))
(R/'V3-TO-FINAL-SPLIT.patch').write_text(patch)
# Static controls only: no caller, app, Git, source sweep or browser execution.
a=(V/'browser_review.cjs').read_text();b=(R/'browser_review.cjs').read_text();block=lambda t,x,y:t[t.index(x):t.index(y,t.index(x))]
checks={'exact_prior_continuation_helper_bytes':(R/'browser_review.cjs').read_bytes()==(F/'browser_review.cjs').read_bytes(),'snapshot_block_exact':block(a,'  function snapshot','  async function settle')==block(b,'  function snapshot','  async function settle'),'route_and_cameras_exact':block(a,'  const cameras=','  const pause=')==block(b,'  const cameras=','  const pause=') and block(a,'  async function routeTo','  window.__bardwellTownReview')==block(b,'  async function routeTo','  window.__bardwellTownReview'),'far_guard_line_exact':next(l for l in a.splitlines()if 'async far()'in l)==next(l for l in b.splitlines()if 'async far()'in l),'card_timing_lines_exact':all(next(l for l in a.splitlines()if x in l)==next(l for l in b.splitlines()if x in l)for x in ['async card()','async timing()','closeCard()']),'cleanup_tail_exact':original[original.index('})().catch'):]==s[s.index('})().catch'):],'no_changed_deadline':s.count('cfg.maxMillis!==540000')==1,'all_release_templates_HELD':all(not json.loads(p.read_text())['released']for p in R.glob('RELEASE-*-HELD.json')),'all_new_canonical_identity_and_asset_pins_HELD':all(canonical[k]is None for k in ['final_head','final_index_digest','canonical_run_id','canonical_source_sha','artifact_zip_sha256','instance_sha256']) and all(p['sha256']is None and p['bytes']is None for p in canonical['web_lods'])}
assert all(checks.values());(R/'STATIC-CONTROLS.json').write_text(json.dumps({'prepared_only':True,'checks':checks},indent=2)+'\n')
print(json.dumps(checks,indent=2))
