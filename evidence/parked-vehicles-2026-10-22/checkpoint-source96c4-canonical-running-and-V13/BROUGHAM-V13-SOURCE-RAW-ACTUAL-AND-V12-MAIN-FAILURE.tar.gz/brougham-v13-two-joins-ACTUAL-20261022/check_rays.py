from pathlib import Path
import json,struct,hashlib,os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np
HERE=Path(__file__).resolve().parent
model=HERE/'raw/brougham.glb'
receipt=Path('/workspace/shared/brougham-v11-v12-largeforms-preview8-HELD-20261022/actual/receipt.json')
raw=model.read_bytes();n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);binary=raw[28+n:];rr=json.loads(receipt.read_text());row=next(x for x in rr['rows'] if x['viewport']=='desktop' and x['version']=='v12' and x['view']=='detail');assert hashlib.sha256(raw).hexdigest()==json.loads((HERE/'OWNERSHIP.json').read_text())['actual_sha256']
parent={c:i for i,node in enumerate(g['nodes']) for c in node.get('children',[])}
def matrix(i):
 node=g['nodes'][i]
 if 'matrix' in node:m=np.array(node['matrix']).reshape(4,4,order='F')
 else:
  x,y,z,w=node.get('rotation',[0,0,0,1]);m=np.eye(4);m[:3,:3]=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])@np.diag(node.get('scale',[1,1,1]));m[:3,3]=node.get('translation',[0,0,0])
 return matrix(parent[i])@m if i in parent else m
def accessor(i):
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];assert a['componentType']==5126 and a['type']=='VEC3' and 'byteStride' not in v
 return np.frombuffer(binary,dtype='<f4',count=a['count']*3,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,3).astype(float)
parts=g['extras']['parts'];triangles=[];owner=[];normals=[];hubcap_slot=0
for ni,node in enumerate(g['nodes']):
 if 'mesh' not in node:continue
 mesh=g['meshes'][node['mesh']];mat=mesh['primitives'][0]['material'];prim=mesh['primitives'][0];v=accessor(prim['attributes']['POSITION']);nn=accessor(prim['attributes']['NORMAL']);m=matrix(ni);v=(np.c_[v,np.ones(len(v))]@m.T)[:,:3];nm=np.linalg.inv(m[:3,:3]).T;nn=nn@nm.T;nn/=np.linalg.norm(nn,axis=1)[:,None]
 frame=mesh['name'].removeprefix('surface_').removesuffix('_'+str(mat));ranges=[(idx,p) for idx,p in enumerate(parts) if p['frame']==frame and p['material']==mat]
 if frame=='hubcap':
  # Four same-named hubcap frames have repeated local ranges; source generation emits them in node/batch order. None of the targeted lower-body ownership conclusions relies on hubcap IDs.
  ranges=ranges[hubcap_slot*2:hubcap_slot*2+2];hubcap_slot+=1
 labels=[None]*(len(v)//3)
 for idx,p in ranges:
  for j in range(p['triangle_start_in_batch'],p['triangle_start_in_batch']+p['triangles']):assert labels[j] is None;labels[j]=idx
 assert all(x is not None for x in labels)
 triangles.extend(v.reshape(-1,3,3));normals.extend(nn.reshape(-1,3,3));owner.extend(labels)
tri=np.array(triangles);normal=np.array(normals);owner=np.array(owner);e1=tri[:,1]-tri[:,0];e2=tri[:,2]-tri[:,0]
world=np.array(row['camera']['world']).reshape(4,4,order='F');proj=np.array(row['camera']['projection']).reshape(4,4,order='F');invproj=np.linalg.inv(proj);view=np.linalg.inv(world);canvas=row['dom']['canvas']
def project(v):
 q=np.c_[v,np.ones(len(v))]@view.T@proj.T;q=q[:,:3]/q[:,3,None];return np.c_[canvas['x']+(q[:,0]+1)*canvas['width']/2,canvas['y']+(1-q[:,1])*canvas['height']/2]
def ray(x,y):
 q=invproj@np.array([2*(x-canvas['x'])/canvas['width']-1,1-2*(y-canvas['y'])/canvas['height'],0,1]);q/=q[3];point=(world@q)[:3];origin=world[:3,3];d=point-origin;d/=np.linalg.norm(d)
 pvec=np.cross(d,e2);det=np.einsum('ij,ij->i',e1,pvec);inv=np.divide(1.,det,out=np.zeros_like(det),where=abs(det)>1e-12);tvec=origin-tri[:,0];u=np.einsum('ij,ij->i',tvec,pvec)*inv;qvec=np.cross(tvec,e1);v=np.einsum('j,ij->i',d,qvec)*inv;t=np.einsum('ij,ij->i',e2,qvec)*inv;valid=(det>1e-12)&(u>=-1e-8)&(v>=-1e-8)&(u+v<=1+1e-8)&(t>0)
 ii=np.where(valid)[0];ii=ii[np.argsort(t[ii])];hits=[];seen=set()
 for i in ii:
  pi=int(owner[i]);p=parts[pi]
  if pi in seen:continue
  seen.add(pi);nn=(1-u[i]-v[i])*normal[i,0]+u[i]*normal[i,1]+v[i]*normal[i,2];nn/=np.linalg.norm(nn)
  hits.append({'part_index':pi,**p,'material_name':g['materials'][p['material']]['name'],'point_world':(origin+t[i]*d).tolist(),'normal_world':nn.tolist(),'distance':float(t[i]),'triangle_global':int(i)})
  if len(hits)>=4:break
 return {'pixel':[x,y],'front_to_back':hits}
coords=[(723,480),(749,463),(758,511),(767,534),(661,432),(680,481),(686,570),(754,579),(711,544),(831,663),(842,702),(920,681),(929,724),(668,545),(1002,477),(1006,545),(748,485),(748,505),(735,490)]
result={'scope':'Finite actual GLB world projection and19camera rays. Front-side triangle intersections, transparency not integrated; no renderer/light diagnostic or physical attachment certification.','model_sha256':hashlib.sha256(raw).hexdigest(),'image_sha256':row['image_sha256'],'camera_and_dom':{'camera':row['camera'],'canvas':canvas},'rays':[ray(x,y) for x,y in coords]}
interesting={'small_door_hardware','cabin_front_lower','driver_perch_base','driver_backboard','driver_footboard','perch_support','footboard_support','step_support','door_step','deep_curved_lower_body','deep_U_closed_door','front_sill_connector'}
result['component_projection']=[]
for i,p in enumerate(parts):
 if p['name'] not in interesting:continue
 v=tri[owner==i].reshape(-1,3);pp=project(v);result['component_projection'].append({'part_index':i,**p,'material_name':g['materials'][p['material']]['name'],'world_min':v.min(axis=0).tolist(),'world_max':v.max(axis=0).tolist(),'screen_min':pp.min(axis=0).tolist(),'screen_max':pp.max(axis=0).tolist()})
result['scope']='ActualV13 Float32 geometry under immutable originalV12 camera;19CPU rays, no newrender. Not a shader or physical-load test.'
expected={(723,480):15,(754,579):15,(686,570):0}
result['positive_protrusion_witnesses']={}
for pixel,part in expected.items():
 witness=next(row for row in result['rays'] if tuple(row['pixel'])==pixel)
 actual=witness['front_to_back'][0]['part_index'] if witness['front_to_back'] else None
 result['positive_protrusion_witnesses'][str(pixel)]={'expected_shell_part':part,'actual_front_part':actual,'pass':actual==part}
result['pass']=all(row['pass'] for row in result['positive_protrusion_witnesses'].values())
(HERE/'READBACK.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['pass'],'Actual prior protrusion rays do not now reach the expected shell'
print('Model actualSHA',result['model_sha256'],'triangles',len(tri),'rays',len(coords))
for r in result['rays']:print(r['pixel'],[(h['part_index'],h['name'],h['material_name'],[round(x,4) for x in h['point_world']]) for h in r['front_to_back'][:2]])
