from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time,traceback
R=Path(__file__).resolve().parent;S=Path('/workspace/shared/brougham-v13-two-joins-PROPOSAL-20261022');START=time.monotonic();ACTIVE=None;BUDGET=120
PY='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python';NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def need(c,m):
 if not c:raise ValueError(m)
with (R/'ATTEMPT.lock').open('x') as f:f.write(str(os.getpid()))
receipt={'pass':False,'owner_pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'max_seconds':120,'stages':[],'scope':'ONE exactsourceV13near generation thenownership/rays/Khronos; no portable/browser/app changes'}
def save(): (R/'OWNER.json').write_text(json.dumps(receipt,indent=2)+'\n')
def kill():
 global ACTIVE
 if ACTIVE and ACTIVE.poll() is None:
  os.killpg(ACTIVE.pid,signal.SIGKILL);ACTIVE.wait(timeout=1)
 ACTIVE=None;receipt['owned_child_pid']=None

def interrupted(signum,frame):raise RuntimeError('Owner interrupted '+str(signum))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def run(label,args):
 global ACTIVE
 remain=118-(time.monotonic()-START);need(remain>0,'118s work deadline');ACTIVE=subprocess.Popen(['nice','-n','15',*args],env=env,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True);receipt.update(phase=label,owned_child_pid=ACTIVE.pid);save()
 try:out,err=ACTIVE.communicate(timeout=remain)
 except subprocess.TimeoutExpired:
  kill();raise TimeoutError('118s work deadline '+label)
 (R/(label+'.stdout')).write_text(out);(R/(label+'.stderr')).write_text(err);rc=ACTIVE.returncode;ACTIVE=None;receipt['stages'].append({'label':label,'returncode':rc,'owner_elapsed_seconds':time.monotonic()-START});receipt['owned_child_pid']=None;save();need(rc==0,'Actual stage failed '+label+'; no amendment/retry')
try:
 need(sha(S/'FILES.json')=='9982ae8f50ae888d7e996e177f388dd48d0827890c831b84c6df70ae406380dc','Released source manifest')
 for name,item in json.loads((S/'FILES.json').read_text()).items():need(sha(S/name)==item['sha256'],'Frozen source changed '+name)
 need(sha(S/'PROPOSED-V13-TWO-JOINS.patch')=='70c67cbd87a974fb657b2739df262c3759a06181e9f5158c916ee2a0ed1d3f92','Released patch');need(not(R/'raw').exists(),'Fresh output only');save()
 run('generation',[PY,str(S/'proposed/generate.py'),'--parameters',str(S/'proposed/parameters.json'),'--detail','near','--lod-recipe',str(S/'proposed/lods.json'),'--output',str(R/'raw')])
 receipt['actual_sha256']=sha(R/'raw/brougham.glb');save()
 run('ownership',[PY,str(R/'check_actual.py')]);run('rays',[PY,str(R/'check_rays.py')]);run('khronos',[NODE,'/workspace/shared/brougham-v12-largeforms-PROPOSAL-20261022/validate_raw.cjs',str(R/'raw/brougham.glb'),str(R/'KHRONOS.json')]);receipt['pass']=True
except BaseException as e:receipt['failure']=repr(e);receipt['traceback']=traceback.format_exc()
finally:kill();receipt.update(lifecycle='CLOSED',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-START);save()
print(json.dumps(receipt));raise SystemExit(0 if receipt['pass'] else 1)
