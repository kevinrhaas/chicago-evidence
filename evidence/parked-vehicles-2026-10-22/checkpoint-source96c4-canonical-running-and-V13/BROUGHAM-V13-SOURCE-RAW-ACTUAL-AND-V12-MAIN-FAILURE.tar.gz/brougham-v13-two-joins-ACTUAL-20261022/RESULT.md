# Actual V13 raw generation — PASS / CLOSED

One root-released generation from exact proposal manifest9982ae8f/patch70c67cbd, followed by raw ownership, geometry, original-camera rays and Khronos checks. Started2026-10-22T06:54:23.635966Z; closed06:54:24.726773Z,1.090929s total. Owner1075179, exec56331 exited0; no remaining owned child, browser or server. Horse browser had already reported CLOSED before this run. Root and portable owner were notified immediately at terminal, before further packaging. No retry, source amendment, app/Git/ticket/pin write, browser or portable conversion occurred.

Actual raw `raw/brougham.glb` SHA256 `469ff52b2166a41e3aa1ee0a0d49ca91f86d7f108d0f743893098ca74c2f8fee`,2,434,504bytes. Actual32,678triangles(+8),24meshes,41nodes,6materials. OriginalV12 and its801686raw/source preimages remain untouched in the source proposal's `baseline-v12/`.

`OWNERSHIP.json` PASS: exactlyIDs30 `cabin_front_lower` and39 `interior_floor` changed; all464otherpart POSITION/NORMAL byte streams exact using each version's updated ranges.44additional full-mesh streams outside the two affected body material batches are independently exact by mesh index, covering repeated-name hubcaps too. Original part order/identity, node/pivot/socket/anchor structure, materials/scenes and parameter/source-reference metadata remain exact. Full active world bounds are exactly unchanged:

    min[-.8600000143051147,0,-1.8365528583526611]
    max[ .8600000143051147,2.1882998943328857,3.825000047683716]

Actual front closure has20triangles and signed volume.013224131911618578m3; floor has12triangles and.03777960227652612m3. Both have finite, nondegenerate, correctly wound closed welded geometry and unit normals. Floor's full-thickness X/Z bounds pass the original raw shell envelope with at least2.99mm engineering inset tolerance; front's three actual rows follow the original width breakpoint. These are bounded two-part source/geometry checks, not an exhaustive assembly intersection or occupied-support certificate.

`READBACK.json` reuses the immutable actualV12 desktop/detail camera and recasts19rays against the NEW raw Float32 model; no new render. All three positive original protrusion witnesses now reach the correct shell FIRST:

| Old pixel | Old first part | V13 actual first part |
|---|---|---|
|723,480|30front closing cap|15near-side lower shell|
|754,579|39interior floor|15near-side lower shell|
|686,570|39interior floor|0far-side lower shell|

`KHRONOS.json`:0errors,0warnings,4existing empty-node infos, not truncated. Single-thread native Python3.11 production source generation and all stage stdout/stderr, one-attempt lock, owner/session receipts, source manifest binding and failures (none) are retained.

No appearance, photographic, new physical support, main-world or material acceptance. Root owns release of covered_visual_review's portable follow-on and subsequent matched normal-main preview. The previous step geometry, generic hardware chip and any remaining same-body shadow/material patches were not changed by this repair.
