"""Read existing V12 only; compare declared proposed bounds, not a generated V13."""
from pathlib import Path
import json,struct,hashlib,collections,math
HERE=Path(__file__).resolve().parent
raw=(HERE/'baseline-v12/brougham.glb').read_bytes();jlen=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+jlen]);binary=raw[28+jlen:]
assert hashlib.sha256(raw).hexdigest()=='8016867da68e3f061d98864ef46a94b98d8356a683ff9d0c39113abdf1504590'
mesh=next(m for m in g['meshes'] if m['name']=='surface_vehicle_body_0');attrs=mesh['primitives'][0]['attributes']
def points(attr):
 a=g['accessors'][attrs[attr]];v=g['bufferViews'][a['bufferView']];off=v.get('byteOffset',0)+a.get('byteOffset',0);vals=struct.unpack_from('<'+'f'*(a['count']*3),binary,off);return list(zip(vals[::3],vals[1::3],vals[2::3]))
pos=points('POSITION');normal=points('NORMAL');part=g['extras']['parts'][15];start=part['triangle_start_in_batch']*3;end=start+part['triangles']*3
edges=collections.Counter();coordinates={}
for k in range(start,end,3):
 if normal[k][0]>=-.5:continue
 tri=pos[k:k+3]
 for p in tri:coordinates[(p[1],p[2])]=p[0]
 for a,b in zip(tri,tri[1:]+tri[:1]):edges[tuple(sorted(((a[1],a[2]),(b[1],b[2]))))]+=1
boundary=[e for e,count in edges.items() if count==1];adj=collections.defaultdict(list)
for a,b in boundary:adj[a].append(b);adj[b].append(a)
assert all(len(n)==2 for n in adj.values());first=min(adj);loop=[first];previous=None;current=first
while True:
 nxt=next(n for n in adj[current] if n!=previous)
 if nxt==first:break
 loop.append(nxt);previous,current=current,nxt
assert len(loop)==len(adj)
def span(y):
 hits=[]
 for (y0,z0),(y1,z1) in zip(loop,loop[1:]+loop[:1]):
  if (y0<=y<y1) or (y1<=y<y0):
   q=(y-y0)/(y1-y0);hits.append((z0+q*(z1-z0),coordinates[(y0,z0)]+q*(coordinates[(y1,z1)]-coordinates[(y0,z0)])))
 assert len(hits)==2,(y,hits)
 return sorted(hits)
affine=g['extras']['parameters']['body_vertical_affine'];world=lambda y:y*affine['scale_y']+affine['offset_y_m']
ys=sorted(set([world(.75),world(.79)]+[y for y,z in loop if world(.75)<y<world(.79)]))
sections=[{'world_y':y,'rear_z':span(y)[0][0],'front_z':span(y)[1][0],'inner_half_width':min(x for z,x in span(y))} for y in ys]
# Declared source design values evaluated from exact recipe; no candidate module imported/executed.
planned={'floor_half_width':.4811208791208791,'floor_z_min':-.5136300250457809,'floor_z_max':.355}
slack_x=min(s['inner_half_width']-planned['floor_half_width'] for s in sections);slack_rear=min(planned['floor_z_min']-s['rear_z'] for s in sections);slack_front=min(s['front_z']-planned['floor_z_max'] for s in sections)
assert slack_x>.00299 and slack_rear>.00299 and slack_front>0
old_x=min(s['inner_half_width']-.52 for s in sections);old_rear=min(-.595-s['rear_z'] for s in sections)
assert old_x<0 and old_rear<0
# Declared front cap has an explicit row at the existing width clamp breakpoint; evaluate each actual ruled band independently.
front=[];x0=.585-.18*((1.26-.97)/.91);x1=.585
for k in range(64):
 source_y=.97+(1.2599-.97)*k/63;w_y=world(source_y);inner=min(x for z,x in span(w_y));declared=x0+(x1-x0)*(source_y-.97)/(1.26-.97)
 front.append({'producer_y':source_y,'body_inner_x':inner,'declared_front_cap_x':declared,'inside_inner_slack_m':inner-declared,'old_front_cap_exterior_slack_m':inner+.026-.58})
assert min(v['inside_inner_slack_m'] for v in front)>-1e-6
assert min(v['old_front_cap_exterior_slack_m'] for v in front)<-.02
r={'status':'PASS_SOURCE_DESIGN_AGAINST_ACTUAL_V12_ONLY','candidate_generated':False,'actual_v12_sha256':hashlib.sha256(raw).hexdigest(),'actual_side_inner_profile_vertices':len(loop),'method':'Boundary reconstructed independently from actual Float32 near-side inner-wall triangles; evaluate horizontal floor sections at endpoints and every actual polygon vertex level. No candidate producer executes. Front64height samples are finite design controls, not exhaustive candidate proof.','floor_sections':sections,'declared_proposed_floor_bounds':planned,'declared_minimum_slacks_m':{'floor_x':slack_x,'floor_rear_z':slack_rear,'floor_front_z':slack_front},'old_geometry_refusal_controls_m':{'floor_inner_x_slack':old_x,'floor_rear_z_slack':old_rear,'front_cap_exterior_slack':min(v['old_front_cap_exterior_slack_m'] for v in front)},'front_samples':front,'front_three_row_source_design':[.97,1.26,1.27],'refused_old_two_row_join_inset_at_breakpoint_m':.585-(x0+(x1-x0)*(1.26-.97)/.30),'limits':['No newGLB exists','Actual candidate attributes/rays/visual comparison remain HELD','No fixture, shadow, physical-load or source-step diagnosis']}
(HERE/'EXISTING-V12-ENVELOPE-CONTROLS.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['status','actual_side_inner_profile_vertices','declared_minimum_slacks_m','old_geometry_refusal_controls_m']},indent=2))
