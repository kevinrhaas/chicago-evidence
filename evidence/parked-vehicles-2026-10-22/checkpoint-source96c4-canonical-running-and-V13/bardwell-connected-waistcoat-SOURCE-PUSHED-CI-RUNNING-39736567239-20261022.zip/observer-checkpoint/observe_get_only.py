"""One bounded GET-only observer; no dispatcher/qualifier invocation or heavy artifact work."""
import pathlib,json,subprocess,datetime,time,os,hashlib,ast
HERE=pathlib.Path(__file__).parent.resolve();RUN=39736567239;SHA='96c4da4b1fe68e6dec3b18c15da2f14c596a60c5';BRANCH='steward/bardwell-connected-waistcoat-20261022';REPO='kevinrhaas/chicago';WORKFLOW='.github/workflows/chicago-4d-humans.yml'
SUPPORT=pathlib.Path('/workspace/shared/bardwell-connected-waistcoat-canonical-support-20261022');ACT=SUPPORT/('FINAL-ACTIVATION-'+SHA+'.json');RECEIPT=pathlib.Path('/workspace/shared/bardwell-connected-waistcoat-canonical-dispatch-'+SHA+'.json')
activation=json.loads(ACT.read_text());receipt=json.loads(RECEIPT.read_text());assert activation['sha']==SHA and hashlib.sha256(ACT.read_bytes()).hexdigest()==receipt['activation_sha256'];assert receipt['post_succeeded'] and receipt['inputs']=={'build_teamsters':True,'build_seated_driver_study':True} and len(receipt['runs'])==1 and receipt['runs'][0]['id']==RUN
required=next(ast.literal_eval(n.value) for n in ast.parse((SUPPORT/'qualify_get_only.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='REQUIRED' for t in n.targets))
started=datetime.datetime.now(datetime.timezone.utc);deadline=started+datetime.timedelta(minutes=60);end=time.monotonic()+3600;pid=os.getpid()
owner={'owner':'ci_human_recovery','pid':pid,'started_utc':started.isoformat(),'deadline_utc':deadline.isoformat(),'interval_seconds':61,'duration_cap_seconds':3600,'run_id':RUN,'sha':SHA,'workflow':WORKFLOW,'workflow_id':380427937,'attempt':1,'scope':'GET-only observer; terminal qualification/artifact work separate, actual new exported-panel images required'}
with (HERE/'OWNER.json').open('x') as f:json.dump(owner,f,indent=2);f.write('\n')
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def note(value):
 line=json.dumps(value,separators=(',',':'));print(line,flush=True)
 with (HERE/'observer.log').open('a') as f:f.write(line+'\n')
def get(endpoint):
 remaining=end-time.monotonic()
 if remaining<=0:raise TimeoutError('observer60minute deadline reached')
 r=subprocess.run(['gh','api','--method','GET','repos/'+REPO+'/'+endpoint],capture_output=True,timeout=min(45,remaining))
 if r.returncode:raise RuntimeError('GET failed: '+r.stderr.decode(errors='replace')[:1200])
 return json.loads(r.stdout)
note({'event':'OWNED_OBSERVER_STARTED',**owner});previous=None
try:
 for n in range(61):
  if time.monotonic()>=end:break
  now=datetime.datetime.now(datetime.timezone.utc);folder=HERE/('poll-%03d-'%n+now.strftime('%Y%m%dT%H%M%SZ'));folder.mkdir()
  run=get('actions/runs/'+str(RUN));save(folder/'run.json',run)
  assert run['id']==RUN and run['head_sha']==SHA and run['head_branch']==BRANCH and run['path']==WORKFLOW and run['event']=='workflow_dispatch' and run['run_attempt']==1 and run['workflow_id']==380427937,'run source/ref/workflow/event/attempt identity changed'
  jobs=get('actions/runs/'+str(RUN)+'/attempts/1/jobs?per_page=100');save(folder/'jobs.json',jobs);assert jobs['total_count']==len(jobs['jobs']),'truncated jobs inventory'
  ref=get('git/ref/heads/'+BRANCH);save(folder/'remote-ref.json',ref);assert ref['object']['sha']==SHA,'remote human ref moved; root reconciliation required'
  inventory={};missing=[]
  for name,expected in required.items():
   matches=[j for j in jobs['jobs'] if j['name']==name];assert len(matches)<=1,'ambiguous mandatory job'
   if not matches:missing.append(name);continue
   j=matches[0];inventory[name]={'id':j['id'],'status':j['status'],'conclusion':j['conclusion'],'active':[s['name'] for s in j['steps'] if s['status']=='in_progress'],'required_steps':[{k:s.get(k) for k in ['name','status','conclusion']} for s in j['steps'] if s['name'] in expected]}
  state={'owner_pid':pid,'observed_utc':now.isoformat(),'deadline_utc':deadline.isoformat(),'poll':n,'run_id':RUN,'sha':SHA,'status':run['status'],'conclusion':run['conclusion'],'attempt':1,'missing_dependent_jobs_pending_not_failure':missing,'jobs':inventory,'snapshot_dir':str(folder),'terminal':run['status']=='completed'};save(folder/'snapshot.json',state);save(HERE/'STATE.json',state);note({'event':'SNAPSHOT',**state})
  if state['terminal']:
   save(HERE/'TERMINAL.json',state);note({'event':'TERMINAL_OBSERVED','run_id':RUN,'conclusion':run['conclusion'],'snapshot_dir':str(folder),'heavy_qualification_not_yet_run':True});break
  remaining=end-time.monotonic()
  if remaining<=0:break
  time.sleep(min(61,remaining))
 else:pass
 if not (HERE/'TERMINAL.json').exists():
  save(HERE/'DEADLINE.json',{'status':'BOUNDED_OBSERVER_STOPPED_AT_DEADLINE','run_id':RUN,'sha':SHA,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});note({'event':'DEADLINE_STOP','run_id':RUN})
except Exception as e:
 save(HERE/'OBSERVER-ERROR.json',{'status':'GET_OR_IDENTITY_RECONCILIATION_REQUIRED','error':str(e),'run_id':RUN,'sha':SHA,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});note({'event':'STOPPED_ERROR','error':str(e)});raise
finally:save(HERE/'OBSERVER-CLOSED.json',{'pid':pid,'closed':True,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
