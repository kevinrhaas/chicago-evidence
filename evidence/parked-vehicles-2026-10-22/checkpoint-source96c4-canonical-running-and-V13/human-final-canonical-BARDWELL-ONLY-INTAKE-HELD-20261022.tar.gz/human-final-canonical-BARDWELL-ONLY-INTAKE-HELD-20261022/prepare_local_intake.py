#!/usr/bin/env python3
"""Local inert ZIP/JSON intake only. Never downloads, runs artifact code, or writes the app."""
import argparse,hashlib,json,pathlib,re,stat,struct,zipfile
HERE=pathlib.Path(__file__).resolve().parent
ASSET='bardwell_otis_1835'
TARGETS=[f'assets/humans/{web}{ASSET}.lod{lod}.glb' for web in ['', 'web/'] for lod in range(4)]
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text())
def emit(root,n,j):
 p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,indent=2)+'\n')
def require(ok,msg):
 if not ok:raise ValueError(msg)
def read_member(z,suffix):
 rows=[i for i in z.infolist() if i.filename==suffix or i.filename.endswith('/'+suffix)]
 require(len(rows)==1,'Missing/ambiguous exact archive member '+suffix);i=rows[0]
 require(not i.is_dir() and not stat.S_ISLNK(i.external_attr>>16) and i.file_size<=100_000_000,'Unsafe/oversized member '+i.filename)
 b=z.read(i);require(len(b)==i.file_size,'Archive byte count mismatch');return i.filename,b
def glb_json(b):
 require(len(b)>=20 and b[:4]==b'glTF','Not a GLB');_,v,n=struct.unpack_from('<4sII',b);require(v==2 and n==len(b),'GLB version/length mismatch')
 size,kind=struct.unpack_from('<II',b,12);require(kind==0x4e4f534a and 20+size<=len(b),'Missing GLB JSON');return json.loads(b[20:20+size])
def main():
 p=argparse.ArgumentParser();p.add_argument('--activation',required=True);a=p.parse_args();c=load(a.activation)
 require(c['status']=='ROOT_RELEASED_LOCAL_CANONICAL_INTAKE' and c['build_inputs']=={'build_teamsters':True,'build_seated_driver_study':True},'HELD: exact successful build/inputs must first be verified by CI owner')
 require(re.fullmatch('[a-f0-9]{40}',c['source_sha'] or '') and c['source_sha'] not in ['34cf462ed343b8b2b70da70303344fff7e5e083f','ad813a6278b7d76961b78ef3483f1bbf3e106c02'],'New repaired source SHA required')
 require(all(isinstance(c[k],int) and c[k]>0 for k in ['run_id','artifact_id']) and c['run_id']!=39712579846,'New actual run/artifact IDs required')
 q=load(c['qualification_json']);require(q['status']=='COMPLETE' and q['mechanical_qualified'] is True and q['sha']==c['source_sha'] and q['run_id']==c['run_id'] and q['repository']=='kevinrhaas/chicago' and q['workflow']=='.github/workflows/chicago-4d-humans.yml','Exact external CI qualification mismatch')
 source_inputs_bytes=pathlib.Path(c['source_inputs_json']).read_bytes();source_inputs=json.loads(source_inputs_bytes);require(isinstance(source_inputs,dict) and source_inputs,'Actual exact-head source-input manifest required')
 archive=pathlib.Path(c['archive']);archive_sha=sha(archive.read_bytes());require(archive_sha==c['artifact_zip_sha256']==q['artifact_zip_sha256'],'Actual artifact ZIP hash mismatch')
 app=pathlib.Path(c['installed_root']).resolve();out=pathlib.Path(c['output']).resolve();require(str(out).startswith('/workspace/shared/') and not out.exists() and not out.is_relative_to(app),'Fresh outside-app output required')
 baseline=load(HERE/'INSTALLED-NON-BARDWELL-BASELINE.json');installed=sorted(str(f.relative_to(app)) for d in ['assets/humans','assets/humans/web'] for f in (app/d).glob('*.glb'))
 require(set(installed)==set(TARGETS)|set(baseline['files']),'Installed human asset inventory drift: stop for review')
 for rel,h in baseline['files'].items():require(sha((app/rel).read_bytes())==h,'Non-Bardwell bytes drifted: '+rel)
 old=load(app/'data/humans/fixture.measure.json');old_by={x['file']:x for x in old['files']};require(len(old_by)==len(old['files']),'Duplicate installed registry entries')
 payload={};members=[];registry=[];costs=[];entry_sources=[]
 with zipfile.ZipFile(archive) as z:
  measure_name,measure_bytes=read_member(z,'chicago/4d/data/humans/fixture.measure.json');measured=json.loads(measure_bytes);by={x['file']:x for x in measured['files']};require(len(by)==len(measured['files']),'Duplicate canonical registry entries')
  inspections={}
  for mode in ['source','web']:
   name,b=read_member(z,'tmp/teamster-studies/'+mode+'/inspection.json');j=json.loads(b);require(j['mechanical_passed'] is True and not j.get('failures'),'Actual '+mode+' inspections failed');inspections[mode]=j
  for rel in TARGETS:
   name,b=read_member(z,'chicago/4d/'+rel);g=glb_json(b);h=sha(b);lod=int(re.search(r'\.lod([0-3])\.glb$',rel)[1]);e=by.get(rel)
   require(e and e['sha256']==h and e['bytes']==len(b) and e['lod']==lod and e['verdicts'] and all(v['ok'] is True for v in e['verdicts']),'Missing/stale/failed actual same-file registry entry '+rel)
   prov=[s.get('extras',{}).get('chicago4d_human') for s in g.get('scenes',[])];prov=[x for x in prov if x];require(len(prov)==1 and prov[0]['asset_id']==ASSET and prov[0]['lod']==lod and prov[0]['person_reference_id']=='rc_bardwell_otis','GLB resident/LOD provenance mismatch '+rel)
   mode='web' if '/web/' in rel else 'source';rows=[r for r in inspections[mode]['runs'] if r['file']==rel and r['viewport_name']=='desktop'];require(len(rows)==1,'Exact actual inspection row missing '+rel);r=rows[0]
   require(r['skinned_meshes']==9 and r['bone_count']==56 and len(r['materials'])==9,'Unexpected mesh/rig/material count: stop for root review '+rel)
   require(r['sha256']==h and r['triangles']==e['triangles'] and r['bone_count']==e['joints'] and r['gl_error']==0 and not r['page_errors'] and not r['failed_requests'],'Inspection/registry/file mismatch '+rel)
   payload[rel]=b;registry.append(e);members.append({'member':name,'destination':rel,'bytes':len(b),'sha256':h,'lod':lod,'runtime':mode})
   costs.append({k:r[k] for k in ['file','lod','sha256','triangles','skinned_meshes','bone_count','standing_frame','footwear_min_y_m']}|{'bytes':len(b),'draw_material_slots':len(r['materials']),'decoded_images':[{'material':m['name'],'textures':m['textures']} for m in r['materials']]})
   entry_sources.append({'file':rel,'entry_sha256':sha(json.dumps(e,separators=(',',':')).encode()),'origin':'new canonical same-file actual registry','registry_member':measure_name,'registry_member_sha256':sha(measure_bytes),'run_id':c['run_id']})
 for rel in sorted(baseline['files']):
  e=old_by.get(rel);require(e and e['sha256']==baseline['files'][rel] and e['verdicts'] and all(v['ok'] is True for v in e['verdicts']),'Unchanged installed file lacks original successful actual measure '+rel);registry.append(e)
  entry_sources.append({'file':rel,'entry_sha256':sha(json.dumps(e,separators=(',',':')).encode()),'origin':'retained unchanged installed actual measurement','original_measurement_source':old.get('measurement_source',old.get('measurement_sources'))})
 require(len(registry)==len(installed) and {e['file'] for e in registry}==set(installed),'Selected registry inventory incomplete')
 tiers={}
 for name,lods in [('full',[0,1,2,3]),('balanced',[1,2,3]),('light',[2,3])]:
  rows=[by[f'assets/humans/web/{ASSET}.lod{l}.glb'] for l in lods];tiers[name]={'lods':lods,'web_bytes_if_all_fetched':sum(r['bytes'] for r in rows),'nearest_lod_triangles':rows[0]['triangles']}
 out.mkdir();proposal=out/'proposal'
 for rel,b in payload.items():p=proposal/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 new_registry={k:v for k,v in old.items() if k not in ['files','tiers','measurement_source','measurement_sources','_doc']};new_registry.update(_doc='New Bardwell8 same-file actual canonical readings plus unchanged installed fixture readings. Separate measurement origins retained; no local browser/town or photographic acceptance claimed.',files=sorted(registry,key=lambda x:x['file']),tiers=tiers,measurement_sources=entry_sources)
 emit(proposal,'data/humans/fixture.measure.json',new_registry)
 public=load(app/'data/humans/bardwell_otis_1835.measure.json');public.update(canonical_source_sha=c['source_sha'],canonical_run_id=c['run_id'],canonical_artifact_id=c['artifact_id'],canonical_artifact_zip_sha256=archive_sha,mechanical_qualified=True,photographic_accepted=False,assets=costs)
 emit(proposal,'data/humans/bardwell_otis_1835.measure.json',public)
 emit(out,'EXACT-HEAD-SOURCE-INPUTS-COPIED.json',source_inputs)
 emit(out,'EXACT-IMPORT-MANIFEST.json',{'exact_head_source_inputs_sha256':sha(source_inputs_bytes),'source_sha':c['source_sha'],'run_id':c['run_id'],'artifact_id':c['artifact_id'],'artifact_zip_sha256':archive_sha,'members':members,'unchanged_other_assets':baseline['files'],'selected_actual_registry_entries':entry_sources,'qualification_scope':'Externally qualified canonical mechanics only; this helper performed inert local byte/metadata selection. No app install, browser/town/full-fit/photo qualification.'})
 emit(out,'HELD-TEXT-DEPENDENCIES.json',{'root_review_required':['Retain repaired source commit and exact source-input hashes','Append actual8 hashes/run/asset/component notices to assets/LICENSES.md without removing historical notices','Update instance provenance canonical run/head wording only, preserving person/placement/LOD/card/grade','Review exact new published byte/tri/material costs and existing thresholds, not merely previous totals','Update T1789 changelog/status with actual limited outcome; do not claim photographic completion'],'ready_for_app_integration':False,'app_written':False,'network_used':False,'artifact_code_executed':False})
 print(json.dumps({'output':str(out),'assets':len(members),'registry_entries':len(registry),'app_written':False}))
if __name__=='__main__':main()
