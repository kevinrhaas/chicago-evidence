from pathlib import Path
import subprocess,json,time,datetime,hashlib,re,concurrent.futures
HEAD='e694849a2c516a9862a2564c5ff86d97406e09ab';RUN=39705450602;B=Path('/workspace/shared/parked-covered-2981-'+HEAD+'-CI-GET-owner1/failure-gate-'+str(RUN));B.mkdir(exist_ok=False);start=time.monotonic();attempts=[]
def get(label,endpoint,plain=False):
 for n in range(1,4):
  assert time.monotonic()-start<100
  r=subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/'+endpoint],capture_output=True,timeout=40);(B/(label+f'-attempt{n}.stdout')).write_bytes(r.stdout);(B/(label+f'-attempt{n}.stderr')).write_bytes(r.stderr)
  err=r.stderr.decode(errors='replace');transient=bool(r.returncode and not re.search(r'HTTP (?:401|403)\b',err) and re.search(r'HTTP (?:502|503|504)\b|unexpected EOF|connection reset by peer|transport read',err,re.I));retry=transient and n<3
  attempts.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'GET','endpoint':endpoint,'attempt':n,'returncode':r.returncode,'retry':retry,'delay':2**n if retry else 0,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest()})
  if retry:time.sleep(2**n);continue
  assert r.returncode==0,err
  return r.stdout if plain else json.loads(r.stdout)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:
 a=p.submit(get,'run','actions/runs/'+str(RUN));b=p.submit(get,'jobs','actions/runs/'+str(RUN)+'/jobs?per_page=100');run=a.result();jobs=b.result()
assert run['head_sha']==HEAD and run['event']=='pull_request' and run['path']=='.github/workflows/chicago-4d-check.yml' and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='failure'
assert jobs['total_count']==len(jobs['jobs'])==1;j=jobs['jobs'][0];assert j['head_sha']==HEAD and j['run_attempt']==1 and j['run_id']==RUN and j['name']=='gate'
log=get('job-log','actions/jobs/'+str(j['id'])+'/logs',True);text=log.decode(errors='replace');lines=text.splitlines();failed=[s for s in j['steps'] if s['conclusion'] not in ['success','skipped']];contexts=[]
for i,l in enumerate(lines):
 if 'CHECK FAIL' in l or ('##[error]' in l and 'self-test |' not in l):contexts.append({'line':i+1,'context':'\n'.join(lines[max(0,i-6):min(len(lines),i+15)])})
r={'status':'ACTUAL_FAILED_GATE_BOUND','head':HEAD,'run_id':RUN,'job_id':j['id'],'workflow_path':run['path'],'run_attempt':run['run_attempt'],'conclusion':run['conclusion'],'failed_actual_steps':failed,'log_sha256':hashlib.sha256(log).hexdigest(),'log_bytes':len(log),'log_lines':len(lines),'failure_contexts':contexts,'log_tail':'\n'.join(lines[-110:]),'GET_attempts':attempts,'POSTs':0,'no_retry_workflow':True};(B/'FAILURE-EVIDENCE.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps(r,indent=2))
