from pathlib import Path
import hashlib,json,tarfile
D=Path(__file__).parent;assert json.loads((D/'FOLLOWUP-AUDIT.json').read_text())['PASS']
files=[p for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ('CAPSULE-MANIFEST.json','MANIFEST.sha256')];records=[{'path':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
(D/'CAPSULE-MANIFEST.json').write_text(json.dumps({'state':'FROZEN_PROVENANCE_ONLY_UNAPPLIED','files':records},indent=2)+'\n');(D/'MANIFEST.sha256').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in records)+hashlib.sha256((D/'CAPSULE-MANIFEST.json').read_bytes()).hexdigest()+'  CAPSULE-MANIFEST.json\n')
archive=D.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as t:t.add(D,arcname=D.name)
sha=hashlib.sha256(archive.read_bytes()).hexdigest();archive.with_suffix(archive.suffix+'.sha256').write_text(sha+'  '+archive.name+'\n')
for r in records:assert hashlib.sha256((D/r['path']).read_bytes()).hexdigest()==r['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha,'files_verified':len(files)},indent=2))
