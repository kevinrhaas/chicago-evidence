# V5/V6 provenance-only follow-up after b95

This is a separate three-file metadata/source patch after the pinned V5/V6 integration patch. It adds two genuine saved period-comparator source records and links them from the 1835 recipe. No model, helper, array, image asset, app/index/Git/mirror/browser/CI or derived source-use output was changed. Root owns application, append-only documentation integration, normal derivation and the next full gate.

The existing geometry patch remains SHA-256 `b95efacb541e6a5026228091c9dfd22bee1655b277a92a3ca2786cc385822a74`. The historical integration capsule remains byte-exact SHA-256 `6b914d2eb0654a9472cb743d8cc926823024283ef2355b2ff827871e013b444c`; neither was overwritten. This new handoff corrects the broader test-coverage wording in that older README.

## Exact saved sources and limits

- `mount_1835_bargaining_for_a_horse`: William Sidney Mount, *Bargaining for a Horse (Farmers Bargaining)*, 1835; New-York Historical Society, accession 1858.59. The saved museum HTML confirms title/artist, signed 1835 date and accession. The exact 1029 x 829 reproduction matches saved Commons imageinfo SHA1 `9e2f29f542773622bb33d6c50214391ccbc95e5b`.
- `mount_1835_bar_room_scene`: William Sidney Mount, *Bar-room Scene*, 1835; Art Institute of Chicago, accession 1939.392 / artwork 30709, as supplied by the saved Commons metadata/file title/catalog link. The exact 3000 x 2444 reproduction matches saved imageinfo SHA1 `4459dcccf69068ef6e8eb537488669b459991dce`. The V5 brief records direct AIC webpage403/API503; there is no saved successful museum response, and none is claimed.

Both saved Commons records explicitly say Public domain, Copyrighted=False, AttributionRequired=false and identify PD-Art/PD-old categories. Original JPG bytes, those metadata responses, NYHS HTML, the V5 brief and hash/crop receipts are copied under `saved-proof/`, with exact hashes in `SAVED-PROOF-MANIFEST.json`. The original full pixels were re-viewed locally in this task; root also personally viewed both originals. No new fetch or unrelated research occurred. V5's reference manifest lists `horse-wikidata.json`, which is absent from the frozen directory; this proposal neither uses nor claims it.

Both records use type `illustration`, tier1 for the original painting's date and `asset_use: cross_check`. They supply qualitative American circa1835 genre-painting analogy: hanging lower trousers and closed lower waistcoat fronts. Tier1 is not an upgrade to Chicago eyewitness status. They do not establish completion before1835-07-01, any named resident's exact outfit/likeness/occupation, historical dimensions/materials/cuff height or authority to trace geometry. No painting pixels, texture sampling or images are added to application assets.

The follow-up recipe adds both IDs to top-level `sources` and to the specific V5 tailoring block, whose direct-image reading is recorded separately from the existing transcription-mediated newspaper terminology. Its updated `source_scope` distinguishes these uses and keeps the July4 newspaper limitation. `source_registration_note` now names the registered comparators, saved proof and AIC limitation. All recipe numeric, geometry, identity, rig/skin/material and status values remain untouched.

## Accurate layered controls and independent review

The existing integration packet uses a meaningful layered bridge, not three independent executions of the final V6 producer:

1. `v5_finite_controls.py` compares the frozen V5 helper with the exact2f75 baseline and exercises its original finite leg/vest controls.
2. `v5_supplemental_controls.py` tests that same frozen V5 stage against the baseline for shirt/body preservation, and checks V5's new waistcoat-front/support sections.
3. `v6_finite_controls.py` runs the final proposed V6 helper against that frozen V5 stage and checks the level hem, exact retained upper V5 geometry, source UV/skin, and unchanged shirt/waistcoat/shoes.

The integration audit binds the final helper to exact reviewed V6 and the recipe to exact reviewed V5 except the two disclosed truthful metadata strings. The three finite controls passed, but the first two do not directly execute final V6. The V6 bridge and exact final-array comparisons provide the final-stage preservation evidence. This follow-up performs no new geometry construction or pose sweep: it proves that only citation/reading metadata and two source JSONs differ, and verifies that applying the geometry patch followed by this metadata patch in a temporary directory preserves the exact helper bytes.

Root reports independent `ci_human_recovery` review PASS, identified as `peer33eaa6b3`, with the coverage-wording precision finding above. Root also reports both b95 proposed hashes match after its application. That outcome is root-relayed here; no new independent canonical qualification is inferred. This task did not run or inspect a new full gate.

The separate actual V6 source-array preview ZIP remains `8713e2efb9d5e44d5dc224168a1e95794d9d1c16ef14fe41c5086a7b83decd0f`,24 captures/0errors with technical framing/shoe-render PASS. It is not canonical garment qualification. Historical whole-shoe disappearance was V2 stale preview-sphere culling, not a demonstrated source-shoe defect; complete seated enclosure remains unaccepted.

## Apply and suggested append-only prose

`PROVENANCE-FOLLOWUP-AFTER-b95.patch` changes only:

- `chicago/4d/data/sources/mount_1835_bargaining_for_a_horse.json` (new)
- `chicago/4d/data/sources/mount_1835_bar_room_scene.json` (new)
- `chicago/4d/data/humans/recipes/worker_1835.json` (citation/reading metadata only)

Recipe preimage SHA-256: `45d4b4e5686cf9f6bd5a10d2cdc1aec9d3404c203923fa78f439e254527045ee`.
Recipe result SHA-256: `72ec4cd9fef1acf217dc40f42d61d1012ad49cbd9ccf7681343246280671b018`.
Follow-up patch SHA-256: `201375c4fff880ce3722035b178bbaad0996a53eba9b143d78923a4713cabe3f`.

Root may check/apply this separate patch after b95 from the repository root. The new source paths must be absent and the recipe must match the stated preimage. `FOLLOWUP-AUDIT.json` records successful schema validation, saved image/rights comparisons, and temporary-only geometry-then-follow-up application reproducing the proposed files. `LIBERTIES-APPEND-SUGGESTION.md` is an additive paragraph under existing L418; `STATUS-APPEND-SUGGESTION.md` is a separate new paragraph. Neither is an app edit or a docs replacement patch. Root should derive source-use normally; it has not been manually edited or fabricated here.

Canonical qualification,40 inherited idle negative source-face projections, complete clothing/footwear/animation/LOD fit, finished tailoring/materials, photographic quality and occupied/world acceptance remain open. These two year-only analogies change no scene date or resident identity grade.
