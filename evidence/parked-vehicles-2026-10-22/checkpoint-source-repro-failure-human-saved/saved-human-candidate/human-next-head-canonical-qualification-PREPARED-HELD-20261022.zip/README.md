# Next human head canonical qualification — PREPARED / HELD

**Final source SHA is null. No dispatch is released or performed.** Root owns the one final POST after the integrated human tree passes its NEW full gate, is committed/pushed, and its exact final diff/source pins are reviewed. The V4 run39687040336 and head2f75ef23 are historical context only and are explicitly rejected for this next-head execution.

Known canonical workflow identity remains pinned: `kevinrhaas/chicago`, workflow ID380427937, `.github/workflows/chicago-4d-humans.yml`, SHA256 `62048edeed40b6d5fe8c42feec1a031b7b2581a39ec7215ce0a20b170769c847`, Git blob `bbeb04e12c66b356a9b66acb2c83a21808c2e897`,17,063bytes. The saved reviewed bytes equal the current workspace workflow. Recheck its final committed/remote bytes; changed workflow bytes require review, not a changed pin to force execution.

The previous known once-only dispatcher and GET qualifier are copied with a small visible adaptation in MINIMAL-SUPPORT-ADAPTATION.patch: one immutable activation JSON binds the NEW final head/tree/source pins and explicit root release, is embedded+hashed into the exclusive dispatch intent, and must remain byte-identical for qualification. No Python helper edit is needed after final SHA. Existing once-only POST/discovery, attempt1, job/step/log/artifact/runtime/seated/W01/normal/sole checks are retained. Three nonempty canonical master members and the existing0.002m sole tolerance are also checked explicitly. No helper, network, browser, full source control or gate was executed for this preparation.

## Trigger and finite cost

PR path filters include `tools/human_*`, human source/data/assets, Blender/derivative pins, vendor/runtime human paths and this workflow. The same push filter applies only on `dev`. The dependent `teamster-studies` job runs only on workflow_dispatch; an ordinary green fixture/PR badge cannot establish new workwear qualification. Although workflow defaults are false and its dependent-job expression uses OR, **both build_teamsters=true and build_seated_driver_study=true are mandatory here**.

One released dispatch has sequential job caps20minutes fixture +30minutes studies. The previous V4 run took about15minutes and produced a505,306,368-byte artifact; those are historical observations, not a timing/size promise for the new tree. This preparation authorizes no extra run, smoke or source-control replay. Metadata7/T2981 or the prior vehicle full gate does not qualify the new integrated human tree.

Concurrency is keyed to the ref with cancel-in-progress=true. After dispatch, do not push/move the human ref, dispatch again, rerun or cancel while evidence is being reconciled. The parked reference stays fixed. HumanPR1175 remains dependency blocked until the vehicle lands; the parent stays open.

## Root final preflight and diff review

Root must first finish V5/V6 + actual source-provenance followup + reviewed vehiclee694 integration. Run the normal full gate on that exact combined tree using the root-owned lane (`cd /workspace/chicago/chicago/4d && bash tools/check.sh`) and preserve its actual PASS evidence. Do not reuse a gate from the earlier vehicle-only or source-preview tree. Commit and push under root ownership; no mutation command is executed by this packet.

After the actual commit, root can review the final source with these read-only commands. Set variables to actual reviewed values; these commands are not run during preparation:

```bash
HUMAN_REPO=/workspace/chicago
HUMAN_SUPPORT=/workspace/shared/human-next-head-canonical-qualification-PREPARED-HELD-20261022
HUMAN_FINAL_SHA="$(git -C "$HUMAN_REPO" rev-parse HEAD)"
# Use the FULL reviewed vehicle commit, not the literal placeholder below.
VEHICLE_SOURCE_SHA=ROOT_REVIEWED_FULL_E694_COMMIT
HUMAN_GATE_EVIDENCE=/workspace/shared/ROOT_ACTUAL_NEW_HUMAN_GATE_PASS_EVIDENCE

git -C "$HUMAN_REPO" show --no-patch --format=fuller "$HUMAN_FINAL_SHA"
git -C "$HUMAN_REPO" diff --stat 2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3 "$HUMAN_FINAL_SHA"
git -C "$HUMAN_REPO" diff --name-status 2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3 "$HUMAN_FINAL_SHA"
git -C "$HUMAN_REPO" diff --check 2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3 "$HUMAN_FINAL_SHA"
git -C "$HUMAN_REPO" diff 2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3 "$HUMAN_FINAL_SHA" -- chicago/4d/tools/human_workwear_fit.py chicago/4d/data/humans/recipes/worker_1835.json .github/workflows/chicago-4d-humans.yml
git -C "$HUMAN_REPO" merge-base --is-ancestor "$VEHICLE_SOURCE_SHA" "$HUMAN_FINAL_SHA"
gh api --method GET repos/kevinrhaas/chicago/git/ref/heads/steward/1835-workwear-repair-20261021
gh api --method GET "repos/kevinrhaas/chicago/commits/$HUMAN_FINAL_SHA/check-runs?per_page=100"
```

Review the complete final diff, including the merged vehicle and source metadata, not only the two geometry files. The reviewed integration helper was SHA256 `89428acdb85b7ba8ed126babb95ecb3eea7f33110cb51b6637164f231375de48`; consciously reconcile any deviation. The recipe's final hash MUST include the actual source-only provenance followup; do not pin the earlier proposal recipe45d4b4e5 or the V4 recipe. Source hashing below proves bytes, not review or gate success. Root must inspect its actual gate PASS, final source/provenance diff, merged vehicle identity and successful commit/push before creating an activation.

## Root immutable activation and the one POST

ACTIVATION-TEMPLATE-HELD.json remains sha:null and all release flags false. The following local source-pin command creates a NEW exclusive FINAL-ACTIVATION file from actual committed bytes. **Executing it is root's explicit attestation that the prerequisites above passed and release of ONE final dispatch.** File existence alone does not prove a gate PASS; inspect the real result first. Supply the actual full vehicle commit and gate-evidence file. Never edit the resulting activation after dispatch.

```bash
python - "$HUMAN_REPO" "$HUMAN_SUPPORT" "$HUMAN_GATE_EVIDENCE" "$VEHICLE_SOURCE_SHA" <<'PY'
import pathlib,sys,subprocess,json,hashlib,re,datetime
repo,support,gate,vehicle=map(pathlib.Path,sys.argv[1:])
vehicle=str(vehicle)
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
sha=git('rev-parse','HEAD').decode().strip()
assert re.fullmatch('[0-9a-f]{40}',sha) and sha!='2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3'
assert re.fullmatch('[0-9a-f]{40}',vehicle) and gate.is_file()
assert git('branch','--show-current').decode().strip()=='steward/1835-workwear-repair-20261021'
subprocess.run(['git','-C',str(repo),'merge-base','--is-ancestor',vehicle,sha],check=True)
a=json.loads((support/'ACTIVATION-TEMPLATE-HELD.json').read_text())
workflow=git('show',sha+':'+a['workflow'])
assert hashlib.sha256(workflow).hexdigest()==a['workflow_sha256']
pins={}
for name in a['source_pins']:
    data=git('show',sha+':'+name)
    pins[name]={'git_blob_sha':git('rev-parse',sha+':'+name).decode().strip(),'sha256':hashlib.sha256(data).hexdigest()}
changed={}
for name in git('diff','--name-only','--no-renames','2f75ef23dbb316ebe4cf53e65ce3af8b04f140d3',sha).decode().splitlines():
    r=subprocess.run(['git','-C',str(repo),'show',sha+':'+name],capture_output=True)
    changed[name]={'deleted':True} if r.returncode else {'git_blob_sha':git('rev-parse',sha+':'+name).decode().strip(),'sha256':hashlib.sha256(r.stdout).hexdigest()}
a.update(state='ROOT_RELEASED_EXACT_NEW_HEAD_ONCE',sha=sha,commit_tree_sha=git('rev-parse',sha+'^{tree}').decode().strip(),source_pins=pins,final_changed_files_since_historical_V4=changed,full_gate_evidence=str(gate),reviewed_source_provenance_and_vehicle_merge={'vehicle_commit':vehicle,'source_provenance_in_actual_recipe':True},root_released_for_one_dispatch=True,full_gate_passed=True,final_diff_reviewed=True,commit_and_push_verified=True,released_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
dest=support/('FINAL-ACTIVATION-'+sha+'.json')
with dest.open('x') as f:json.dump(a,f,indent=2);f.write('\n')
print(dest)
PY
HUMAN_ACTIVATION="$HUMAN_SUPPORT/FINAL-ACTIVATION-$HUMAN_FINAL_SHA.json"
HUMAN_DISPATCH_RECEIPT="/workspace/shared/human-next-head-dispatch-$HUMAN_FINAL_SHA.json"

# Optional finite local plan: does not GET or POST.
python "$HUMAN_SUPPORT/dispatch_once.py" --sha "$HUMAN_FINAL_SHA" --activation "$HUMAN_ACTIVATION" --out "$HUMAN_DISPATCH_RECEIPT"

# ROOT ONLY: execute exactly ONCE after all actual prerequisites above.
python "$HUMAN_SUPPORT/dispatch_once.py" --sha "$HUMAN_FINAL_SHA" --activation "$HUMAN_ACTIVATION" --out "$HUMAN_DISPATCH_RECEIPT" --dispatch
```

The dispatcher GET-verifies remote branch/head, known workflow bytes, final commit tree and eight actual final runtime source blob/hashes before POST. The exclusive intent is written before the sole POST; both inputs are sent as true. It discovers at most one new exact-head workflow_dispatch run and rechecks the branch. An error, timeout, ambiguous POST, missing run discovery or head movement means GET reconciliation of that existing intent, **never another blind POST or a new receipt path to bypass the intent**. Root owns the allowance; an absent local receipt from a failed pre-intent GET is not automatic permission to dispatch.

## Actual new-run GET qualification

Get the actual run ID from the new dispatch receipt, never from an old green badge or run39687040336. Prefer terminal success. These are root/read-only observation commands after that one dispatch:

```bash
HUMAN_RUN_ID=ACTUAL_NEW_RUN_ID

gh api --method GET "repos/kevinrhaas/chicago/actions/runs/$HUMAN_RUN_ID"
gh api --method GET "repos/kevinrhaas/chicago/actions/runs/$HUMAN_RUN_ID/attempts/1/jobs?per_page=100"

# Use a FRESH output directory for ONE finite terminal snapshot.
python "$HUMAN_SUPPORT/qualify_get_only.py" --sha "$HUMAN_FINAL_SHA" --run-id "$HUMAN_RUN_ID" --activation "$HUMAN_ACTIVATION" --dispatch-receipt "$HUMAN_DISPATCH_RECEIPT" --out "/workspace/shared/human-next-head-qualified-$HUMAN_RUN_ID-terminal1"
```

The same immutable activation must match the actual dispatch intent. Exact new SHA/ref/workflow/event, attempt1, commit tree, actual source pins, required fixture and study jobs/all named steps are enforced. Missing/skipped/failed/cancelled steps never qualify. The helper retrieves a fresh attempt log ZIP and unique unexpired `resident-teamster-studies-NEW_SHA` artifact bound to this actual run/ref/head; it hashes every member and reads inert bytes only. It requires3actual canonical masters; source24 + published24 inspections;12sole receipts each at0.002m with actual GLB provenance;6hierarchy/raw-frame comparisons;24error-free untruncated container validations;6named seated runs +3refusals; source/published W01 at both viewports and browser/server closure. The known workflow/export path preserves original raw-normal0.001 and sole2mm guards. No uploaded artifact is executed or blindly extracted.

Known legacy snapshot boundaries remain explicit: a dependent job may not yet exist, causing an early schema refusal rather than a CI failure. Use later GET observation or a fresh terminal snapshot; no dispatch. Failed terminal runs save run/jobs but return before logs/artifact download. Obtain fresh failure evidence by GET and stop for reconciliation:

```bash
gh api --method GET "repos/kevinrhaas/chicago/actions/runs/$HUMAN_RUN_ID/attempts/1/logs" > "/workspace/shared/human-next-head-$HUMAN_RUN_ID-failure-attempt1-logs.zip"
gh api --method GET "repos/kevinrhaas/chicago/actions/runs/$HUMAN_RUN_ID/artifacts?per_page=100" > "/workspace/shared/human-next-head-$HUMAN_RUN_ID-failure-artifacts.json"
```

Do not rerun/cancel/re-dispatch or weaken schemas/normal/sole guards on failure. Artifact/network or source-schema issues require evidence and GET reconciliation, not a new run.

## Mandatory same-new-run visual review and acceptance limits

Mechanical PASS is not tailoring, photographic, occupied or world acceptance. After actual terminal qualification, safely extract selected PNG/JSON data only, rejecting absolute/traversal/backslash/symlink paths and recording member/hash/bytes. Preserve the full original ZIP SHA256 and downloadable metadata. Review the NEW same-run source and published LOD0 standing front/profile/quarter/face views for all3residents, actual seated front/side/quarter at desktop/mobile, visible cuffs/ankles/shoes, W01 and sole receipts/metrics. Check actual frame/clip identities; do not substitute V5/V6 runtime-swap PNGs, V4 artifacts or earlier technical receipts. Additional GLB inspection, if needed, must use the new exact artifact GLB bytes and an explicitly owned browser lane.

V1 bad-camera and V2 stale-culling preview history remain historical defects; corrected V3/V6 source previews provide no future canonical acceptance. Forty inherited negatives remain OPEN. Full cloth/footwear enclosure, animation/LOD fit, full seat/thigh/shirt/sleeve drape, finished cuffs/thickness/buttons/lapels/materials, period/photographic/world/occupied acceptance and T1789 remain OPEN unless actual new evidence explicitly addresses them. No town figure is enabled by this preparation.
