#!/usr/bin/env python3
"""HELD caller: verify only by default; launch requires a reviewed root release file."""
import argparse,datetime,hashlib,json,os,pathlib,signal,subprocess,time
B=pathlib.Path(__file__).resolve().parent; ROOT=pathlib.Path('/workspace/chicago')
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for v in iter(lambda:f.read(1024*1024),b''):h.update(v)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
def check(c,m):
 if not c:raise RuntimeError(m)
def guard():
 g=read(B/'CHECKOUT-GUARD.json');head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}).decode().strip();check(head==g['HEAD'],'Checkout HEAD changed from prepared guard');check(digest(ROOT/'.git/index')==g['index_sha256'],'Checkout index differs from prepared guard; root must rebind preparation explicitly')
 for f in g['files']:check((ROOT/f['path']).is_file() and digest(ROOT/f['path'])==f['sha256'],'Checkout bytes changed: '+f['path'])
 return {'files':len(g['files']),'index_sha256':g['index_sha256'],'PASS':True}
def browsers():
 out=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   comm=(p/'comm').read_text().strip();stat=(p/'stat').read_text();state=stat[stat.rfind(')')+2:].split()[0]
   if state!='Z' and any(k in comm.lower() for k in ('chromium','chrome','crashpad')):out.append({'pid':int(p.name),'name':comm})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return out
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--release',type=pathlib.Path);p.add_argument('--verify-only',action='store_true');a=p.parse_args();start=time.monotonic()
m=read(B/'PREPARED-MANIFEST.json')
for f in m['files']:check(digest(B/f['path'])==f['sha256'],'Prepared input changed: '+f['path'])
for f in m['external_runtime_pins']:check(digest(pathlib.Path(f['path']))==f['sha256'],'Runtime dependency changed: '+f['path'])
g=guard();active=browsers()
if a.verify_only or not a.release:
 print(json.dumps({'status':'PREPARED/HELD','browser_launches':0,'verified_bundle_files':len(m['files']),'runtime_pins':len(m['external_runtime_pins']),'checkout_guard':g,'currently_active_browser_processes':active,'elapsed_seconds':time.monotonic()-start}));raise SystemExit(0)
r=read(a.release);check(r.get('release')=='ROOT_RELEASED' and r.get('covered_lane_status')=='CLOSED' and r.get('allow_browser') is True,'Missing explicit root release after covered CLOSED')
check(r.get('prepared_manifest_sha256')==digest(B/'PREPARED-MANIFEST.json'),'Release does not bind this prepared manifest')
terminal=pathlib.Path(r['covered_terminal_evidence']);check(terminal.is_relative_to('/workspace/shared') and terminal.is_file(),'Covered CLOSED evidence must exist under shared');check(digest(terminal)==r.get('covered_terminal_sha256'),'Covered CLOSED evidence digest differs')
check(isinstance(r.get('covered_owner_pids'),list) and len(r['covered_owner_pids'])>0,'Root must bind departed covered owner PID(s)')
for pid in r['covered_owner_pids']:check(isinstance(pid,int) and pid>1 and not pathlib.Path('/proc',str(pid)).exists(),'Covered owner PID still exists or invalid')
check(not active,'Browser process already active; browser lane is not free: '+str(active))
check(r.get('allow_coalescer_candidate') is False,'This passive caller contains no active candidate phase')
check(r.get('detail') in ['full','balanced','light'] and r.get('quality') in [0.5,0.75,1,1.5,2],'Explicit controlled detail/quality required')
out=pathlib.Path(r['output']);check(out.is_relative_to('/workspace/shared') and not out.exists(),'Fresh shared output required');check(not out.is_relative_to(B),'Runtime output must be outside frozen preparation')
config={'output':str(out),'detail':r['detail'],'quality':r['quality'],'baseline':'fdb227dbf5ed952921ef652f5a02480fffdad462','candidate':'2aebef95f6a5b6fa1bd8353db936c7674a73c32f','historic_ci_pose_known':False,'diagnosis_only':True}
cfg=pathlib.Path(str(out)+'.config.json');cfg.write_text(json.dumps(config,indent=2)+'\n')
report={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'release':str(a.release),'release_sha256':digest(a.release),'manifest_sha256':digest(B/'PREPARED-MANIFEST.json'),'guard_before':g,'deadline_seconds':600,'term_at_seconds':595,'process_group_policy':'Single new process group; Playwright spawn detached=false; no other browser permitted','browser_launch_authorized':True}
child=None
try:
 with pathlib.Path(str(out)+'.stdout').open('x') as stdout,pathlib.Path(str(out)+'.stderr').open('x') as stderr:
  child=subprocess.Popen(['node',str(B/'compare.cjs'),str(cfg)],stdout=stdout,stderr=stderr,start_new_session=True,env={**os.environ,'PARKED_OVERLAY_SUPERVISED':'released-v3'})
  report['caller_pid']=child.pid;report['process_group']=os.getpgid(child.pid)
  remaining=max(0,595-(time.monotonic()-start))
  try:report['exit_code']=child.wait(timeout=remaining)
  except subprocess.TimeoutExpired:
   report['deadline_reached']=True;os.killpg(child.pid,signal.SIGTERM)
   try:report['exit_code']=child.wait(timeout=max(0,600-(time.monotonic()-start)))
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);report['exit_code']=child.wait(timeout=2)
finally:
 if child:
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
 try:report['guard_after']=guard()
 except Exception as e:report['guard_after']={'PASS':False,'error':str(e)}
 try:
  for f in m['files']:check(digest(B/f['path'])==f['sha256'],'Prepared file changed during caller: '+f['path'])
  for f in m['external_runtime_pins']:check(digest(pathlib.Path(f['path']))==f['sha256'],'Runtime dependency changed during caller: '+f['path'])
  report['prepared_inputs_after']={'PASS':True}
 except Exception as e:report['prepared_inputs_after']={'PASS':False,'error':str(e)}
 report['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['elapsed_seconds']=time.monotonic()-start
 pathlib.Path(str(out)+'.supervisor.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
raise SystemExit(0 if report.get('exit_code')==0 and report.get('guard_after',{}).get('PASS') and report.get('prepared_inputs_after',{}).get('PASS') else 1)
