"""Prepare exact-preimage scoped diff outside app. Never apply to app."""
import difflib,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');patch=[];pre=[]
def update(rel,edits):
 path=A/rel;before=path.read_text();after=before
 for old,new,count in edits:
  assert after.count(old)==count,(rel,old,after.count(old),count)
  after=after.replace(old,new)
 patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel,n=4));pre.append({'path':rel,'preimage_sha256':hashlib.sha256(before.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(after.encode()).hexdigest()})
update('renderers/web/js/main.js',[
("import { createParkedTransport } from './parked-transport.js';","import { createParkedTransport } from './parked-transport.js';\nimport { createStandingHorses } from './standing-horses.js';",1),
('  api.parkedTransport = parkedTransport;','''  api.parkedTransport = parkedTransport;
  const standingHorses = await createStandingHorses({
    dataBase: layerBase('standing_horses'), sceneId: YEAR, confidence, detail: detailLevel,
    problems: layerProblems('standing_horses'), hostMissing,
    groundHeight: (e, n, recordId) => yards.drawnBaseHeightAt(e, n, recordId),
  });
  scene3d.add(standingHorses.group); settleOnGpu(standingHorses.group);
  api.standingHorses = standingHorses;
  standingHorses.update(camera);''',1),
('void parkedTransport.setTier(level);','void parkedTransport.setTier(level);\n      void standingHorses.setTier(level);',2),
('    if (vehicle?.record && (!hit || vehicle.distance < hit.distance)) hit = vehicle;','''    if (vehicle?.record && (!hit || vehicle.distance < hit.distance)) hit = vehicle;
    const horse = standingHorses.pickAt(ndc, camera);
    if (horse?.record && (!hit || horse.distance < hit.distance)) hit = horse;''',1),
('    parkedTransport.update(camera);','    parkedTransport.update(camera);\n    standingHorses.update(camera);',1)])
update('data/scenes/1835.json', [('    "parked_transport",','    "parked_transport",\n    "standing_horses",',1)])
update('renderers/web/js/yards.js',[
('    treatmentAt: () => null,','''    treatmentAt: () => null,
    // Actual triangle height for static support only, not a collision system.
    drawnBaseHeightAt: () => null,''',1),
('  out.dispose = () => { for (const d of disposables) d.dispose?.(); };','''  const supportRay = new THREE.Raycaster();
  const supportOrigin = new THREE.Vector3(), supportDown = new THREE.Vector3(0, -1, 0);
  let supportDisposed = false;
  out.drawnBaseHeightAt = (e, n, recordId) => {
    if (supportDisposed || !Number.isFinite(e) || !Number.isFinite(n)) return null;
    const interior = out.interiors.find(item => item.record === recordId
      && pointInPolygon(item.pts, e, n));
    if (!interior || interior.treatment !== 'worn_earth') return null;
    const height = terrain.surfaceHeight(e, n);
    if (!Number.isFinite(height)) return null;
    // Intersect the actual published/built BatchedMesh triangles. The caller
    // never duplicates LIFT_M or assumes bilinear heightfield==triangle drape.
    group.updateWorldMatrix(true, true);
    supportOrigin.set(e, height + 2, -n); supportRay.set(supportOrigin, supportDown);
    supportRay.near = 0; supportRay.far = 4;
    const bases = group.children.filter(mesh => mesh.name === 'yard-worn_earth');
    const hit = supportRay.intersectObjects(bases, false)[0];
    return hit ? hit.point.y : null;
  };
  out.dispose = () => { supportDisposed = true; for (const d of disposables) d.dispose?.(); };''',1)])
(P/'SCOPED-INTEGRATION.patch').write_text(''.join(patch));(P/'APP-PREIMAGES.json').write_text(json.dumps(pre,indent=2)+'\n')
print(json.dumps({'scoped_files':len(pre),'patch_bytes':(P/'SCOPED-INTEGRATION.patch').stat().st_size,'app_modified':False}))
