import ast,pathlib,json,types,copy,hashlib,collections
D=pathlib.Path(__file__).parent;R=pathlib.Path('/workspace/chicago/chicago/4d');P=D/'proposed/chicago/4d'
def function(path,name):
 tree=ast.parse(path.read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name);env={};exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),env);return env[name]
check_node=next(n for n in ast.parse((P/'tools/test_people_scene.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='check_how_known')
def regression(label,path):
 fn=function(path,'how_known');fails=[];passes=[];env={'json':json,'DATA':R/'data','copy':copy,'cs':types.SimpleNamespace(how_known=fn),'fail':fails.append,'ok':passes.append};exec(compile(ast.Module(body=[check_node],type_ignores=[]),str(P/'tools/test_people_scene.py'),'exec'),env);env['check_how_known']();return {'label':label,'fails':fails,'passes':passes}
old=regression('exact143 preimage',(D/'preimages/chicago/4d/tools/compile_scene.py'))
broad=regression('rejectedV1 broad-grade proposal',pathlib.Path('/workspace/shared/bardwell-person-card-honesty-source-PROPOSAL-20261022/proposed/chicago/4d/tools/compile_scene.py'))
new=regression('boundedV2',(P/'tools/compile_scene.py'))
assert old['fails'] and broad['fails'] and not new['fails']
before=function(D/'preimages/chicago/4d/tools/compile_scene.py','how_known');after=function(P/'tools/compile_scene.py','how_known');rows=json.loads((R/'data/sidecars/1835/people.json').read_text())['people'];cache={};changes=[];preserved=[];counts=collections.Counter()
for row in rows:
 file=R/'data/residents'/row['file']
 if file not in cache:cache[file]=json.loads(file.read_text())
 person=next(p for p in cache[file]['persons'] if p['id']==row['id']);transient=row['how_known']=='transient';old_key=before(person,transient);new_key=after(person,transient)
 if old_key!=new_key:
  assert row['grade']=='reconstructed' and row['resident_subtype']=='reconstructed_trade_head' and row['stage']=='trade_households'
  assert (person.get('name_basis') or{}).get('basis',{}).get('id')=='1835_invented_name_pools' and not person.get('name_as_read')
  changes.append({'id':row['id'],'name':row['name'],'old':old_key,'new':new_key,'raw_record':str(file),'raw_sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
 elif row['id'] in ['stephen_r_beggs','susan_anderson','pay_co_je_bai','nau_con_ne_bec','maub_biss']:
  preserved.append({'id':row['id'],'grade':row['grade'],'name_as_read':person['name_as_read'],'how_known':new_key,'source_ids':person.get('sources')})
 counts[(row.get('stage'),row['grade'],new_key)]+=1
assert len(changes)==309 and len(preserved)==5
result={'passed':True,'scope':'Actual proposed/preimage how_known functions and actual extended existing test function, AST-executed without generating sidecars/browser. Full population comparison reads frozen143raw records; no model/identity/source writes.','existing_extended_regression':{'preimage_failure_count':len(old['fails']),'rejectedV1_failure_count':len(broad['fails']),'boundedV2_failure_count':len(new['fails']),'boundedV2_checks':new['passes'],'old_failures':old['fails'][:5],'rejectedV1_failures':broad['fails']},'actual_directory_rows':len(rows),'changed_exactly309_trade_heads':changes,'actual_source_named_negative_controls_preserved':preserved,'other_rows_unchanged':len(rows)-len(changes)}
(D/'FINITE-CLASSIFICATION-CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':True,'changed':len(changes),'other_rows_unchanged':len(rows)-len(changes),'named_controls_preserved':len(preserved),'V2_regression_failures':len(new['fails']),'V1_rejected_regression_failures':len(broad['fails'])}))
