"""Narrow exact trade-head revision of rejected broad-grade V1. Outside app only."""
import pathlib,json,hashlib,difflib
V1=pathlib.Path('/workspace/shared/bardwell-person-card-honesty-source-PROPOSAL-20261022')
D=pathlib.Path(__file__).parent
def rep(s,a,b):assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
changes=[];patch=[]
for rel in ['tools/compile_scene.py','renderers/web/js/people.js','tools/test_people_scene.py','tools/smoke_renderer.mjs']:
 pre=(V1/'preimages/chicago/4d'/rel).read_text();s=(V1/'proposed/chicago/4d'/rel).read_text()
 if rel=='tools/compile_scene.py':
  s=rep(s,'    # A model-created identity is never a source-named person, even without mint flags.\n    if person.get("grade") == "reconstructed":\n        return "reconstructed"\n','')
  s=rep(s,'    if person.get("resident_subtype") == "projected_resident":\n        return "projected"\n    return "documented"','    if person.get("resident_subtype") == "projected_resident":\n        return "projected"\n    # This explicit mint category invents names; grade alone does not.\n    # Readmitted and underdocumented source-read names keep their evidence category.\n    if (person.get("grade") == "reconstructed"\n            and person.get("resident_subtype") == "reconstructed_trade_head"\n            and (person.get("reconstruction") or {}).get("stage") == "trade_households"):\n        return "reconstructed"\n    return "documented"')
 elif rel=='renderers/web/js/people.js':
  s=rep(s,"  reconstructed: 'created by the model',","  reconstructed: 'reconstructed identity',")
  old="""/** Defensive for older compiled rows too: a reconstructed identity cannot inherit the documented fallback. */
function knownKey(r) {
  return r.grade === 'reconstructed' && r.how_known !== 'transient' ? 'reconstructed' : r.how_known;
}"""
  new="""/** Explicit trade-head mint semantics, never grade or an id-prefix guess. Preserve source-read categories first. */
function knownKey(r) {
  if (r.transient || r.how_known === 'transient') return 'transient';
  if (r.letter_list_only || r.how_known === 'letter_list') return 'letter_list';
  if (r.civic_mint || r.how_known === 'civic_mint') return 'civic_mint';
  if (r.resident_subtype === 'projected_resident' || r.how_known === 'projected') return 'projected';
  return r.grade === 'reconstructed' && r.resident_subtype === 'reconstructed_trade_head'
    && r.stage === 'trade_households' ? 'reconstructed' : r.how_known;
}"""
  s=rep(s,old,new)
  s=rep(s,"  documented: (r) => r.grade !== 'reconstructed' && !r.letter_list_only && !r.civic_mint && r.resident_subtype !== 'projected_resident',\n  reconstructed: (r) => r.grade === 'reconstructed',","  documented: (r) => knownKey(r) === 'documented',\n  reconstructed: (r) => knownKey(r) === 'reconstructed',")
  s=rep(s,"['reconstructed', 'created by the model']","['reconstructed', 'reconstructed identity']")
 elif rel=='tools/test_people_scene.py':
  begin=s.index('def check_how_known():');end=s.index('def check():',begin)
  new='''def check_how_known():
    """Only the explicit invented trade-head category loses the source-named fallback."""
    rows = json.loads((DATA / "sidecars/1835/people.json").read_text())["people"]
    by_id = {row["id"]: row for row in rows}
    def raw(ident):
        card = json.loads((DATA / "residents" / by_id[ident]["file"]).read_text())
        return next(p for p in card["persons"] if p["id"] == ident)
    person = raw("rc_bardwell_otis")
    before = copy.deepcopy(person)
    cases = [("actual invented Bardwell", person, False, "reconstructed"),
             ("attested source-named", {"grade": "attested"}, False, "documented"),
             ("inferred source-named", {"grade": "inferred"}, False, "documented"),
             ("grade-reconstructed projected source name", {"grade": "reconstructed", "resident_subtype": "projected_resident"}, False, "projected"),
             ("grade-reconstructed post-office name", {"grade": "reconstructed", "letter_list_only": True}, False, "letter_list"),
             ("grade-reconstructed civic name", {"grade": "reconstructed", "civic_mint": True}, False, "civic_mint"),
             ("visitor category retained", person, True, "transient"),
             ("trade category with civic evidence", {**person, "civic_mint": True}, False, "civic_mint"),
             ("trade category with letter evidence", {**person, "letter_list_only": True}, False, "letter_list"),
             ("grade alone proves no invented name", {"grade": "reconstructed"}, False, "documented")]
    for ident in ("stephen_r_beggs", "susan_anderson", "pay_co_je_bai", "nau_con_ne_bec", "maub_biss"):
        source_named = raw(ident)
        if not source_named.get("name_as_read"):
            fail(f"{ident}: source-read negative control lost its actual name provenance")
        cases.append((f"actual source-read {ident}", source_named, False, "documented"))
    for label, row, transient, expected in cases:
        got = cs.how_known(row, transient=transient)
        if got != expected:
            fail(f"{label}: how_known {got!r}, expected {expected!r}")
        else:
            ok(f"{label}: {expected}")
    trade_rows = [row for row in rows if row.get("resident_subtype") == "reconstructed_trade_head"]
    for row in trade_rows:
        minted = raw(row["id"])
        basis = (minted.get("name_basis") or {}).get("basis") or {}
        if (minted.get("name_as_read") or basis.get("id") != "1835_invented_name_pools"
                or (minted.get("reconstruction") or {}).get("stage") != "trade_households"
                or cs.how_known(minted) != "reconstructed"):
            fail(f"{row['id']}: trade-head category no longer proves a model-minted identity")
    if not trade_rows:
        fail("actual reconstructed trade-head provenance control is empty")
    else:
        ok(f"all {len(trade_rows)} actual trade heads retain explicit invented-name provenance")
    if person != before:
        fail("how_known changed the person's existing identity/grade/source record")


'''
  s=s[:begin]+new+s[end:]
 elif rel=='tools/smoke_renderer.mjs':
  s=rep(s,"reconstructedCard.mark === 'created by the model'","reconstructedCard.mark === 'reconstructed identity'")
 for sub,body in [('preimages',pre),('proposed',s)]:
  p=D/sub/'chicago/4d'/rel;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(body)
 changes.append({'file':'chicago/4d/'+rel,'preimage_sha256':hashlib.sha256(pre.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(s.encode()).hexdigest()})
 patch.extend(difflib.unified_diff(pre.splitlines(True),s.splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel))
(D/'SOURCE.patch').write_text(''.join(patch))
(D/'SOURCE-BINDINGS.json').write_text(json.dumps({'source_head':'14323534e9493a3630ac9dcbe1b8daa1db3ae454','state':'PROPOSED_OUTSIDE_APP_NO_BROWSER','rejected_V1':str(V1),'predicate':'Existing grade reconstructed + reconstructed_trade_head subtype + trade_households stage; preserve transient/letter/civic/projected first; no ID prefix or grade-only inference. All309 actual trade-head raw invented-name basis audited.','files':changes,'patch_sha256':hashlib.sha256((D/'SOURCE.patch').read_bytes()).hexdigest(),'no_person_grade_source_employer_or_geometry_changes':True},indent=2)+'\n')
print(json.dumps(changes,indent=2))
