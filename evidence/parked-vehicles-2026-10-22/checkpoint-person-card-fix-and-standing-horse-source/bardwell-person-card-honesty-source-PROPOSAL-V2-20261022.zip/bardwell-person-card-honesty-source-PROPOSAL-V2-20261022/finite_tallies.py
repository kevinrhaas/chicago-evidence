import pathlib,ast,json,copy
from finite_classification import function
D=pathlib.Path(__file__).parent;P=D/'proposed/chicago/4d';R=pathlib.Path('/workspace/chicago/chicago/4d');source=ast.parse((P/'tools/compile_scene.py').read_text());old=json.loads((R/'data/sidecars/1835/people.json').read_text());projected=copy.deepcopy(old);how=function(P/'tools/compile_scene.py','how_known');cache={}
for row in projected['people']:
 p=R/'data/residents'/row['file']
 if p not in cache:cache[p]=json.loads(p.read_text())
 raw=next(p for p in cache[p]['persons'] if p['id']==row['id']);row['how_known']=how(raw,row['how_known']=='transient')
rows=projected['people'];resident_rows=[r for r in rows if r['how_known']!='transient']
known_node=next(n.value for n in ast.walk(source) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='known' for t in n.targets));known=eval(compile(ast.Expression(known_node),'proposed actual known tally','eval'),{'resident_rows':resident_rows,'rows':rows})
count_fields={'letter_list_only':'letter_list','civic_mint':'civic_mint','projected_residents':'projected','documented':'documented','reconstructed_identities':'reconstructed'}
for field,key in count_fields.items():projected['counts'][field]=known[key]
test=function(P/'tools/test_people_scene.py','check_known_tallies')
def check(doc):
 fails=[];test.__globals__.update(json=json,DATA=R/'data',fail=fails.append,ok=lambda s:None);test(doc);return fails
assert check(projected)==[]
negative=[]
for label,mutate in [('old documentedcount includes309inventednames',lambda d:d['counts'].update(documented=old['counts']['documented'])),('missing reconstructed tally',lambda d:d['counts'].pop('reconstructed_identities')),('wrong actualtrade cardtype',lambda d:next(r for r in d['people'] if r['id']=='rc_bardwell_otis').update(how_known='documented')),('changed overlapping civic tally',lambda d:d['counts'].update(civic_mint=d['counts']['civic_mint']+1))]:
 doc=copy.deepcopy(projected);mutate(doc);fails=check(doc);assert fails,label;negative.append({'control':label,'refused':fails})
r={'passed':True,'scope':'Exact proposed compiler known-dict AST evaluated over actual rows projected by actual proposed how_known; exact existing-test check_known_tallies exercised with positive and4negative mutations. No fullscene regeneration/browser claim.','known':known,'emitted_count_fields':{f:projected['counts'][f] for f in count_fields},'actual309_identity_category_consistent':True,'negative_controls':negative};(D/'FINITE-TALLY-CONTROLS.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'passed':True,'known':known,'negative_controls':len(negative)}))
