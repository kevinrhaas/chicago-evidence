PREPARED ONLY. No browser is authorized until root gate/commit/postcommitpublish and explicit release. No source/CI mutations or new assertions.

Use the existing app tool in its original location, since it derives published site/4d relative to import.meta.url. The saved copy is for review only. Root must bind final HEAD, source hash and fresh published mirror after publishing; no live checkout/index/mirror guard is frozen now.

Exact child command, to run only inside root existing <=600-second browser ownership/supervision with detached-browser cleanup:

    env NODE_PATH=/workspace/shared/chicago-browser/node_modules PW_EXECUTABLE=/usr/bin/chromium SOURCES_EVIDENCE=/workspace/shared/parked-covered-T2792-T2799-SOURCES-ACTUAL-nexthead-owner1 /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node /workspace/chicago/chicago/4d/tools/measure_sources.mjs

The original tool writes screenshots and results.json only to SOURCES_EVIDENCE. It runs390mobile,1280desktop,and a second mobile boot with503 catalog failure recovery. Each ready wait permits180s; its original body controls animation as authored. Root must enforce the whole process/browser deadline. GNUtimeout around Node alone may leave Playwright detached Chromium after a timeout,so do not use it as the sole closure proof.

Success requires actual exit0,both width results with rows404 and no page errors,raw index161435<=168000,first-open45965<=120000,and logged unavailable-catalog/otherEvidence recovery PASS. These are inspections of actual original results/log,not added tool assertions. Original code asserts consistency with reported catalog totals rather than literal404; this limitation is explicit. Preserve any assertion/timeout failure and no automatic retry. Root should verify no browser remains and source/index/mirror unchanged before releasing lane.
