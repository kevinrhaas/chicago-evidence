#!/usr/bin/env python3
"""One root-released existing Sources invocation; no app/tool edits or retries."""
import pathlib,subprocess,json,hashlib,os,time,datetime,signal
R=pathlib.Path('/workspace/chicago');O=pathlib.Path('/workspace/shared/parked-covered-T2792-T2799-SOURCES-ACTUAL-nexthead-owner1')
HEAD='ca82d06541b31a560d0c29e426668e777db3ad61';TREE='c0b314187a80cbcf8cc115ffeec8f400386b827e';TOOL=R/'chicago/4d/tools/measure_sources.mjs'
EXPECTED='e36420246ad5deba1d6bce84ed8cf607f89da6c010c34ab45005b9d828499bbc';start=time.monotonic();O.mkdir(exist_ok=False)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,d):(O/n).write_bytes((json.dumps(d,indent=2)+'\n').encode())
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},timeout=30)
def processes():
 d={}
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   s=(p/'stat').read_text();v=s[s.rfind(')')+2:].split();d[int(p.name)]={'pid':int(p.name),'name':(p/'comm').read_text().strip(),'state':v[0],'ppid':int(v[1]),'pgrp':int(v[2]),'start_ticks':v[19]}
  except (OSError,ValueError,IndexError):pass
 return d
def browser(x):return x['state']!='Z' and any(v in x['name'].lower() for v in ['chromium','chrome','crashpad'])
def guard(label):
 head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip();assert head==HEAD and tree==TREE,(head,tree)
 assert not git('diff','--name-only').strip(),'Tracked working source changed';assert not git('diff','--cached','--name-only').strip(),'Index changed'
 index=pathlib.Path(git('rev-parse','--git-path','index').decode().strip());index=index if index.is_absolute() else R/index
 rows=[]
 paths=[R/x.decode() for x in git('ls-files','-z','--','chicago/4d').split(b'\0') if x]
 paths += [x for x in (R/'site/4d').rglob('*') if x.is_file()]
 for p in sorted(set(paths)):
  if p.is_file():rows.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':digest(p)})
 save('GUARD-'+label+'.json',{'HEAD':head,'tree':tree,'index_sha256':digest(index),'files':rows,'scope':'Tracked chicago/4d source + full published site/4d; ignored external ticket working repository is outside tracked-source scope.'})
 assert digest(TOOL)==EXPECTED,'Existing Sources tool identity differs'
 build=json.loads((R/'site/4d/build.json').read_bytes());assert build['version']=='ca82d0654',build
 return {'HEAD':head,'tree':tree,'index_sha256':digest(index),'files':len(rows),'build':build,'PASS':True}, {x['path']:x for x in rows}
report={'status':'STARTING','started':now(),'root_explicit_release':'Parent task message: one existing Sources run at exactca82/treec0, <=600s, no automatic retry','HEAD':HEAD,'tree':TREE,'source_sha256':EXPECTED,'whole_budget_seconds':600,'term_at_seconds':585,'kill_by_seconds':590,'browser_launch_attempts':1,'automatic_retries':0,'tool_changes':0,'app_source_index_mirror_writes':0}
child=None;known={};baseline=processes();assert not [x for x in baseline.values() if browser(x)],'Browser lane not free'
def remember():
 ps=processes();parents={child.pid} if child else set()
 parents.update(known)
 for _ in range(8):
  added={pid for pid,x in ps.items() if x['ppid'] in parents and pid not in baseline}
  if added<=parents:break
  parents.update(added)
 for pid,x in ps.items():
  if pid not in baseline and (pid in parents or browser(x)):known.setdefault(pid,x)
 return ps
def cleanup(sig):
 ps=remember();groups=set()
 for pid,x in known.items():
  if pid in ps and ps[pid]['start_ticks']==x['start_ticks'] and ps[pid]['state']!='Z':
   groups.add(ps[pid]['pgrp'])
 for group in groups:
  if group==os.getpgrp():continue
  members=[x for x in ps.values() if x['pgrp']==group and x['state']!='Z']
  if members and all(x['pid'] in known and known[x['pid']]['start_ticks']==x['start_ticks'] for x in members):
   try:os.killpg(group,sig)
   except ProcessLookupError:pass
 for pid,x in known.items():
  if pid in ps and ps[pid]['start_ticks']==x['start_ticks'] and ps[pid]['state']!='Z':
   try:os.kill(pid,sig)
   except ProcessLookupError:pass
try:
 report['guard_before'],before=guard('BEFORE');save('OWNER.json',{'pid':os.getpid(),'started':now(),'HEAD':HEAD,'source_sha256':EXPECTED,'status':'RUNNING_EXISTING_TOOL_ONCE'})
 env={**os.environ,'NODE_PATH':'/workspace/shared/chicago-browser/node_modules','PW_EXECUTABLE':'/usr/bin/chromium','SOURCES_EVIDENCE':str(O)}
 cmd=['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node',str(TOOL)];report['command']=cmd;report['environment']={k:env[k] for k in ['NODE_PATH','PW_EXECUTABLE','SOURCES_EVIDENCE']}
 with (O/'tool.stdout').open('xb') as out,(O/'tool.stderr').open('xb') as err:
  child=subprocess.Popen(cmd,cwd=R/'chicago/4d',env=env,stdout=out,stderr=err,start_new_session=True);report['child_pid']=child.pid;save('LIVE.json',report)
  while child.poll() is None and time.monotonic()-start<585:remember();time.sleep(.5)
  if child.poll() is None:
   report['deadline_reached']=True;cleanup(signal.SIGTERM)
   try:child.wait(timeout=max(0,590-(time.monotonic()-start)))
   except subprocess.TimeoutExpired:cleanup(signal.SIGKILL)
  report['exit_code']=child.wait(timeout=2)
except Exception as e:report['error']=repr(e)
finally:
 if child:
  cleanup(signal.SIGTERM);time.sleep(.5);cleanup(signal.SIGKILL)
  try:child.wait(timeout=2)
  except subprocess.TimeoutExpired:report['cleanup_wait_failed']=True
 save('OWNED-PROCESSES.json',list(known.values()))
 remaining=[x for x in processes().values() if browser(x)];report['active_browsers_after']=remaining
 try:
  report['guard_after'],after=guard('AFTER');diff=[{'path':k,'before':before.get(k),'after':after.get(k)} for k in sorted(before.keys()|after.keys()) if before.get(k)!=after.get(k)];save('GUARD-DIFF.json',diff)
  report['guard_differences']=diff;report['only_permitted_ticket_sidecar_differences']=all(x['path']=='site/4d/tickets.json' for x in diff);assert report['guard_before']['index_sha256']==report['guard_after']['index_sha256'],'Index bytes changed';assert report['only_permitted_ticket_sidecar_differences'],'Unexpected guarded byte changes'
 except Exception as e:report['guard_error']=repr(e)
 report['ended']=now();report['elapsed_seconds']=time.monotonic()-start
 result=O/'results.json'
 if result.exists():
  try:report['original_results']=json.loads(result.read_bytes())
  except Exception as e:report['results_parse_error']=repr(e)
 report['status']='CLOSED_PASS' if report.get('exit_code')==0 and not report.get('error') and not report.get('guard_error') and not remaining else 'CLOSED_STOP'
 save('TERMINAL.json',report);print(json.dumps({k:report.get(k) for k in ['status','child_pid','exit_code','error','guard_error','elapsed_seconds','original_results','active_browsers_after']},indent=2),flush=True)
raise SystemExit(0 if report['status']=='CLOSED_PASS' else 1)
