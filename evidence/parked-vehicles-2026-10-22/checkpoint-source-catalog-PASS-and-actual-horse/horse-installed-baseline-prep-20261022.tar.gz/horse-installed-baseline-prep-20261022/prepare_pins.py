from pathlib import Path
import hashlib,json,shutil
root=Path('/workspace/chicago/chicago/4d')
out=Path(__file__).resolve().parent
files=['tools/transport/horse_geometry.py','tools/transport/generate_horse.py','data/transport/studies/horse.json','renderers/web/transport/horse/manifest.json','renderers/web/transport/horse/demo.js','renderers/web/transport/horse/index.html','renderers/web/transport/horse/equine_light_harness_skinned_prototype_01.glb']
pins=[]
for f in files:
 b=(root/f).read_bytes();pins.append({'path':str(root/f),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
 target=out/('pinned-producer' if f.startswith(('tools/','data/')) else 'pinned-installed')/Path(f).name
 target.parent.mkdir(exist_ok=True);target.write_bytes(b)
(out/'EXACT-INPUT-PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
original=Path('/workspace/shared/horse-parked-refinement-source-20261022/capture_installed_baseline.mjs').read_text()
anchor="const out=path.resolve(args[2]);"
extra="""\nconst exactPins=JSON.parse(await fs.readFile(new URL('./EXACT-INPUT-PINS.json',import.meta.url),'utf8'));
for(const pin of exactPins){const input=await fs.readFile(pin.path);if(input.length!==pin.bytes||sha(input)!==pin.sha256)throw Error('Installed source/input pin changed: '+pin.path);}
"""
(out/'capture_installed_baseline.mjs').write_text(original.replace(anchor,anchor+extra))
print(json.dumps({'pinned':len(pins),'copied_producer_bytes':sum(x['bytes'] for x in pins[:3]),'browser_script':'prepared, UNRUN'}))
