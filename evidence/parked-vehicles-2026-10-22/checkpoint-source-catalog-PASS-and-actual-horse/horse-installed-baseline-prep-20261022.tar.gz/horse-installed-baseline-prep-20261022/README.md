# T-2800 exact installed baseline preparation

This packet contains **no newly generated horse and no new browser render**. Root normally claimed T-2800 after the T-2799 research prerequisite was pushed for review. The shared browser lane remains held until root explicitly releases it.

The pinned production study is `89b048b7cda748e6f3a7111aa8e4f3198b01fabf6015cae644c78ed02d385bc6`, 715,316 B / 14,172 triangles. `EXACT-INPUT-PINS.json` pins seven installed producer/parameter/manifest/fixture/asset files, and copies preserve them under `pinned-producer/` and `pinned-installed/`. Current producer hashes and output match the committed historical two-rebuild mapping described in `/workspace/shared/horse-parked-refinement-source-20261022/INSTALLED-PRODUCER-MAPPING.json`. No new producer execution occurred.

## Next command, only after root releases the lane

```sh
node /workspace/shared/horse-installed-baseline-prep-20261022/capture_installed_baseline.mjs --lane-released --output-dir /workspace/shared/horse-installed-baseline-20261022-first
```

This supersedes the earlier capture command by checking all seven input pins before browser launch. It uses the installed fixture, fixed idle phase0, side and three-quarter views, desktop1280×800/mobile390×780. It records actual served GLB hash, camera matrices, contacts, source manifest counts, renderer counters, screenshots, page/network errors. It refuses an existing output directory and stops on a changed pin. **Syntax passed; browser execution is UNRUN.** Actual four frames need independent inspection before choosing or generating any geometry revision. The flag documents the caller's release; it does not determine lane availability.

## Protected data snapshot and later candidate comparison

`installed-protected-inventory-with-faces.json` inventories the actual installed GLB's 24 semantic source ranges: exact raw POSITION/NORMAL/JOINTS_0/WEIGHTS_0 hashes, normalized source-local triangle hashes/counts and range ownership. No model/collision/render is inferred from that inventory.

After a fresh baseline source reproduction exactly matches installed89b048 and a separately approved croup trial is generated outside app, run:

```sh
python /workspace/shared/horse-installed-baseline-prep-20261022/compare_protected.py --candidate-glb <new-candidate.glb> --candidate-manifest <new-manifest.json> --output <new-protected-comparison.json>
```

The comparator is intentionally scoped to the frozen one-file trunk proposal from `/workspace/shared/horse-parked-refinement-source-20261022/`: body count601, preserved original controls2..9 with remapped ring indices, exact final neck interface/band. It checks exact non-body vertex attributes AND normalized triangles, materials, nodes/rig/sockets, skin inverse binds, animation descriptors and raw sampler bytes. New trunk topology can shift the coat group's subsequent offsets; semantic names resolve those ranges. It fails unsupported cross-part triangles and sparse attributes. A different approved geometry scope needs a separately reviewed comparator amendment, not a silent relaxation. This does not evaluate skinning, intersections, solids, biological proportions, visual or photo quality.

`COMPARATOR-SOURCE-REVIEW.json`: six pure checks PASS. Unchanged non-body data passes; unchanged GLB is refused as a new candidate; one-bit hoof position damage, removed head triangle, moved bit socket and one-bit clip output damage are detected. These are in-memory controls only. No modified GLB was saved or used as production evidence.

## Frozen earlier draft

The original croup/trunk source-only archive remains byte-unchanged:
`/workspace/shared/horse-parked-refinement-source-20261022.tar.gz`, SHA256 `440795c1a99e5c1ee6460cb34d9041f574eedb8dc5e456a7fc15e99702834cc3`.

Its actual anatomy, topology, rig, hair, materials and LOD limitations remain explicit. No ticket photo acceptance or closure is implied. No app, ticket, Git, mirror or CI files were changed by this preparation.
