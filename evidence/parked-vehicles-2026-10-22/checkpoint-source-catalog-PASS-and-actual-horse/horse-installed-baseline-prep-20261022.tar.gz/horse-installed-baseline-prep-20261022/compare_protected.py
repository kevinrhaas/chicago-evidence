# SPDX-License-Identifier: CC0-1.0
"""Read-only installed-horse protection inventory; optional future static-candidate comparison."""
import argparse, hashlib, json, pathlib, struct
BASE=pathlib.Path('/workspace/chicago/chicago/4d/renderers/web/transport/horse')
WANT='89b048b7cda748e6f3a7111aa8e4f3198b01fabf6015cae644c78ed02d385bc6'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(glb,manifest):
 raw=pathlib.Path(glb).read_bytes()
 if struct.unpack_from('<III',raw,0)!=(0x46546c67,2,len(raw)):raise ValueError('Invalid GLB header')
 n,kind=struct.unpack_from('<II',raw,12)
 if kind!=0x4e4f534a:raise ValueError('JSON first chunk required')
 d=json.loads(raw[20:20+n]);bn,bk=struct.unpack_from('<II',raw,20+n)
 if bk!=0x004e4942:raise ValueError('BIN second chunk required')
 blob=raw[28+n:28+n+bn]
 m=json.loads(pathlib.Path(manifest).read_text())
 if m['bytes']!=len(raw):raise ValueError('Manifest length mismatch')
 def accessor(index):
  a=d['accessors'][index];v=d['bufferViews'][a['bufferView']]
  if 'sparse' in a:raise ValueError('Sparse accessor unsupported by this bounded comparator')
  lanes={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
  width={5126:4,5125:4,5123:2,5121:1}[a['componentType']]*lanes
  stride=v.get('byteStride',width);start=v.get('byteOffset',0)+a.get('byteOffset',0)
  if start+(a['count']-1)*stride+width>len(blob):raise ValueError('Accessor outside BIN')
  return [blob[start+i*stride:start+i*stride+width] for i in range(a['count'])]
 primitives={}
 for mesh in d['meshes']:
  for p in mesh['primitives']:
   if p['material'] in primitives:raise ValueError('Expected one primitive per material')
   primitives[p['material']]=p
 ranges={}
 for r in m['vertex_ranges']:
  if r['original_node'] in ranges:raise ValueError('Duplicate semantic source range')
  p=primitives[r['material']];start=r['vertex_start'];stop=start+r['vertex_count']
  attrs={name:accessor(index)[start:stop] for name,index in p['attributes'].items()}
  if any(len(rows)!=r['vertex_count'] for rows in attrs.values()):raise ValueError('Source range outside attribute')
  index_accessor=d['accessors'][p['indices']]
  fmt={5125:'<I',5123:'<H',5121:'<B'}[index_accessor['componentType']]
  indices=[struct.unpack(fmt,row)[0] for row in accessor(p['indices'])]
  triangles=[]
  for i in range(0,len(indices),3):
   face=indices[i:i+3];inside=[start<=x<stop for x in face]
   if any(inside) and not all(inside):raise ValueError('Cross-source-part triangle unsupported by this explicit trial')
   if all(inside):triangles.append(tuple(x-start for x in face))
  ranges[r['original_node']]={'range':r,'attributes':attrs,'triangles':triangles}
 return {'raw':raw,'d':d,'m':m,'accessor':accessor,'ranges':ranges}
def digest_range(r):
 return {key:sha(b''.join(value)) for key,value in r['attributes'].items()}
def baseline():
 b=load(BASE/'equine_light_harness_skinned_prototype_01.glb',BASE/'manifest.json')
 if sha(b['raw'])!=WANT:raise ValueError('Installed horse pin changed; stop')
 return b
def inventory(b):
 return {'baseline_sha256':WANT,'baseline_bytes':len(b['raw']),'scope':'Exact installed exporter ranges and raw vertex attribute hashes; no generation/browser/pose/collision acceptance','parts':{name:{'range':r['range'],'attribute_sha256':digest_range(r),'triangles':len(r['triangles']),'normalized_triangle_sha256':sha(json.dumps(r['triangles'],separators=(',',':')).encode())} for name,r in b['ranges'].items()}}
def compare(b,c):
 checks={}
 checks['new_candidate_distinct_from_baseline']=sha(c['raw'])!=WANT
 checks['exact_source_part_names']=set(b['ranges'])==set(c['ranges'])
 checks['materials_exact']=b['d']['materials']==c['d']['materials']
 checks['scene_and_nodes_exact']=b['d']['scenes']==c['d']['scenes'] and b['d']['nodes']==c['d']['nodes']
 checks['skin_descriptor_exact']=b['d']['skins']==c['d']['skins']
 checks['inverse_bind_bytes_exact']=all(b['accessor'](a['inverseBindMatrices'])==c['accessor'](z['inverseBindMatrices']) for a,z in zip(b['d']['skins'],c['d']['skins']))
 checks['animation_descriptors_exact']=b['d']['animations']==c['d']['animations']
 checks['animation_accessor_bytes_exact']=all(b['accessor'](s[k])==c['accessor'](s[k]) for anim in b['d']['animations'] for s in anim['samplers'] for k in ['input','output'])
 part_checks={}
 for name,old in b['ranges'].items():
  if name=='continuous_body_neck':continue
  new=c['ranges'].get(name)
  part_checks[name]=new is not None and old['range']['vertex_count']==new['range']['vertex_count'] and old['range']['material']==new['range']['material'] and old['range']['joint']==new['range']['joint'] and old['attributes']==new['attributes'] and old['triangles']==new['triangles']
 checks['all_nonbody_raw_attributes_exact']=all(part_checks.values())
 old=b['ranges']['continuous_body_neck'];new=c['ranges'].get('continuous_body_neck')
 checks['expected_trunk_source_count_601']=new is not None and new['range']['vertex_count']==601
 # Original controls 2..5 reappear at new ring indices 8,12,16,20;
 # untouched original neck rings 6..9 reappear at 21..24. Compare exact float32
 # POSITION/JOINTS/WEIGHTS for those old source points. Adjacent trunk normals
 # may legitimately change, so report them rather than silently excluding them.
 protected=[]
 if new:
  for oldring,newring in [(2,8),(3,12),(4,16),(5,20),(6,21),(7,22),(8,23),(9,24)]:
   for attr in ['POSITION','JOINTS_0','WEIGHTS_0']:
    protected.append(old['attributes'][attr][oldring*24:(oldring+1)*24]==new['attributes'][attr][newring*24:(newring+1)*24])
 checks['unchanged_trunk_controls_positions_weights_exact']=bool(protected) and all(protected)
 checks['neck_interface_and_band_all_attributes_exact']=bool(new) and all(old['attributes'][attr][192:240]==new['attributes'][attr][552:600] for attr in old['attributes'])
 return {'status':'PASS protected export data only' if all(checks.values()) else 'FAIL protected export data','baseline_sha256':WANT,'candidate_sha256':sha(c['raw']),'checks':checks,'nonbody_part_checks':part_checks,'scope':'Stored exported attributes/rig/clips only; no skinning evaluation, collisions, appearance, motion, tack or photo qualification'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--candidate-glb',type=pathlib.Path);p.add_argument('--candidate-manifest',type=pathlib.Path);args=p.parse_args()
 if bool(args.candidate_glb)!=bool(args.candidate_manifest):p.error('both candidate files required')
 if args.output.exists():p.error('refuse existing output; preserve earlier evidence')
 b=baseline();result=compare(b,load(args.candidate_glb,args.candidate_manifest)) if args.candidate_glb else inventory(b)
 args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'output':str(args.output),'status':result.get('status','baseline inventoried'),'parts':len(b['ranges'])}))
 return int(result.get('status','').startswith('FAIL'))
if __name__=='__main__':raise SystemExit(main())
