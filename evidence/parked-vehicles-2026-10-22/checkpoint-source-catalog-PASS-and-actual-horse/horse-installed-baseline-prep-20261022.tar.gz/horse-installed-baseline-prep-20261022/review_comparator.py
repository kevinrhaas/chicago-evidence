# SPDX-License-Identifier: CC0-1.0
"""Pure in-memory checker controls. No model generation or app mutation."""
import importlib.util,json,pathlib
here=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('horse_protected_compare',here/'compare_protected.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b=m.baseline()
def fresh():return m.load(m.BASE/'equine_light_harness_skinned_prototype_01.glb',m.BASE/'manifest.json')
checks={}
c=fresh();r=m.compare(b,c)
checks['identical_model_refused_as_new_candidate']=not r['checks']['new_candidate_distinct_from_baseline']
checks['unchanged_nonbody_attributes_and_topology_pass']=r['checks']['all_nonbody_raw_attributes_exact']
c=fresh();part=c['ranges']['fore_l_hoof'];row=part['attributes']['POSITION'][0];part['attributes']['POSITION'][0]=bytes([row[0]^1])+row[1:]
r=m.compare(b,c);checks['one_bit_hoof_position_damage_detected']=not r['nonbody_part_checks']['fore_l_hoof']
c=fresh();part=c['ranges']['head_material_equine_coat'];part['triangles'].pop();r=m.compare(b,c);checks['removed_protected_head_triangle_detected']=not r['nonbody_part_checks']['head_material_equine_coat']
c=fresh();n=next(x for x in c['d']['nodes'] if x['name']=='socket_equine_bit_l');n['translation'][1]+=.001;r=m.compare(b,c);checks['moved_bit_socket_detected']=not r['checks']['scene_and_nodes_exact']
c=fresh();oldaccess=c['accessor'];damaged=c['d']['animations'][0]['samplers'][0]['output']
def accessor(i):
 rows=oldaccess(i)
 if i==damaged:
  first=rows[0];rows[0]=bytes([first[0]^1])+first[1:]
 return rows
c['accessor']=accessor;r=m.compare(b,c);checks['one_bit_clip_output_damage_detected']=not r['checks']['animation_accessor_bytes_exact']
report={'status':'PASS' if all(checks.values()) else 'FAIL','scope':'in-memory negative controls against installed GLB only; candidate and browser UNRUN','checks':checks}
(here/'COMPARATOR-SOURCE-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
