# SPDX-License-Identifier: CC0-1.0
import os, pathlib, signal, subprocess, time, json
here=pathlib.Path(__file__).resolve().parent
output=pathlib.Path('/workspace/shared/horse-installed-baseline-20261022-first')
cmd=['node',str(here/'capture_installed_baseline.mjs'),'--lane-released','--output-dir',str(output)]
started=time.monotonic()
report={'command':cmd,'whole_deadline_seconds':180,'capture_deadline_seconds':175,'ownership':'new session and process group created only for this node capture; cleanup targets this owned group only','status':'RUNNING'}
with (here/'capture.stdout').open('wb') as stdout,(here/'capture.stderr').open('wb') as stderr:
 p=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True)
 report['owned_pid']=p.pid;report['owned_pgid']=p.pid
 try:
  p.wait(timeout=175);report['status']='TERMINAL';report['exit_code']=p.returncode
 except subprocess.TimeoutExpired:
  report['status']='TIMEOUT';report['exit_code']=124
 finally:
  try:os.killpg(p.pid,signal.SIGTERM);report['cleanup_term_sent']=True
  except ProcessLookupError:report['cleanup_term_sent']=False
  try:p.wait(timeout=max(0.1,178-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:pass
  try:os.killpg(p.pid,signal.SIGKILL);report['cleanup_kill_sent']=True
  except ProcessLookupError:report['cleanup_kill_sent']=False
  if p.poll() is None:p.wait(timeout=max(.1,180-(time.monotonic()-started)))
report['elapsed_seconds']=time.monotonic()-started
(here/'terminal.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(report['exit_code'])
