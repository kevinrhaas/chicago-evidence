# Narrow official mesh acquisition — no suitable mesh obtained

22 October 2026. Read the saved horse-reference-review pack first. No prior Sketchfab401 or BlendSwap interstitial was retried. No authentication bypass, viewer extraction, guessed asset/private URL, account creation, paid purchase, browser or app/ticket edit occurred. Public metadata/pages only; no mesh payload or file above32MB downloaded.

The bounded official-source check found no directly usable photographic living-horse or period wagon/carriage mesh. This is a negative result for the channels below, not a claim that none exists elsewhere.

|Official channel / actual query|Actual result|Suitability|
|---|---|---|
|[Smithsonian3D horse](https://3d.si.edu/explore?edan_q=horse)|14/14 results; artwork/figurines, burials and unrelated objects, not a complete living-horse exterior candidate.|No horse mesh selected. An open horse figurine or equestrian statue is not a photographic living-horse asset.|
|[Smithsonian3D Equus](https://3d.si.edu/explore?edan_q=Equus)|1/1 result: [Equus quagga burchelli](https://3d.si.edu/object/3d/equus-quagga-burchelli:28dad3f1-dd2a-4497-a301-36bb6bec4bb3), USNM PAL708181, NMNH Paleobiology.|Actual object page read: “Limb. Femur. Left proximal + shaft”; collected1973, Marsabit, Kenya. Official page advertisesCC0 media/downloads, but this is a zebra bone fragment, not a horse body or period gear. No irrelevant bone payload fetched.|
|[Smithsonian3D wagon](https://3d.si.edu/explore?edan_q=wagon), [buggy](https://3d.si.edu/explore?edan_q=buggy)|Both explicitly return no results.|No candidate/download advertised by these searches.|
|[Smithsonian3D carriage](https://3d.si.edu/explore?edan_q=carriage)|1/1 result, Gunboat Philadelphia.|Not a passenger carriage or freight wagon candidate.|
|[Smithsonian3D cart](https://3d.si.edu/explore?edan_q=cart)|4/4: Lincoln, hatch reproduction, photograph album and Pullman-company step stool.|No period road-vehicle candidate. A Pullman-company artifact is not evidence for Pullman's personal carriage.|
|[Smithsonian Conestoga object](https://www.si.edu/object/conestoga-wagon%3Anmah_842999)|Fresh object page succeeds: CC0 photograph/metadata, overall dimensions, replica-cover declaration. No advertised3D model in the inspected record.|Remains cleared photographic construction reference, not an acquired mesh. No proof of local1812/1835 specimen.|
|[PolyHaven official model index](https://api.polyhaven.com/assets?t=models)|521 model metadata records returned. Horse/vehicle term screening yields only bronze `horse_head` bust, porcelain `horse_statue_01`, modern carts/equipment and irrelevant carton/cartridge matches.|These are decorative/modern assets, not a live animal or period road vehicle. No mesh downloaded.|

Smithsonian's old `/search` route returned404; its actual `/explore?edan_q=...` route worked. That route correction is captured, not misreported as universal access denial. A broad discovery feed gave generic Smithsonian links and supplied no usable candidate; no result from it was treated as a source/license determination.

The earlier best visual horse lead remains BlueMesh's specific draft-horse model, but its previously observed ordinary download401 is still a real acquisition prerequisite. Its preview/license declaration alone does not supply mesh rights/package content or a working direct download. Henry's prior401 likewise remains unresolved. This pass does not authorize another download attempt or convert either preview into a finished asset.

Practical result: there is no newly acquired shortcut to land. Continue the original source-guided anatomy/body remodeling, or use a later legitimately authenticated creator download with its actual archive/license and static quality review. No synthetic/procedural model, scanned sculpture or zebra bone has been promoted to photographic/period-correct completion.

Saved HTML/JSON and SHA manifest retain exact responses. No production model or geometry was generated.
