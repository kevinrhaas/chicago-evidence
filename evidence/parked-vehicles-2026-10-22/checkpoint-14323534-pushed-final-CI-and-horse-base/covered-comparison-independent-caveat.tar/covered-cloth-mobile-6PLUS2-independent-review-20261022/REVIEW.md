# Independent addendum: matched wagon/camera guards do not freeze the population

**The Wolf Point quarter pair is not a whole-frame identical-scene comparison.** The baseline PNG has no standing person at right; the candidate has one (identified by root as Bardwell). I independently viewed both actual files and also see changed tree foliage. All original PNGs, receipts, manifest and archive remain byte-exact and unedited. This sidecar accompanies the original capsule; it does not replace it or relabel either execution.

Original capsule: `/workspace/shared/covered-cloth-mobile-6PLUS2-proof-20261022.tar`, SHA256 `d3d21063871bc039162687dcd148876c7e910d44be770ff161ff7768d2625dce`; manifest `6e2f60d06444bffd9cdd4edb43a7ddd088c29bef7fde48ec71c84f1ee32c8355`. Successful remaining-pair receipt remains `6f18307e4999c96db1dff7c475284107814d97b99568603fed1eea7e4571c21a`.

## What was actually matched

The caller compares saved camera/projection, walker pose, detail tier, physical canvas and its `lights()` snapshot. The target wagon's exact immutable geometry versions, native transform/parking, nine-batch identity and old/new exclusivity are checked. Each state independently must meet the budget with GL0. Both target identities/assets are validated in each execution.

It does NOT require equality of draw/resource counts, resident IDs/body availability, pending acquisition, actor LOD/visibility, animation time, tree/wind phase or shadow-casting occluders. `lighting` records light properties and selected renderer settings, not the complete per-pixel illumination/environment/shadow state. The comment that other objects stay on baseline means the harness does not substitute their geometry; it does not hold their ordinary runtime state still.

The actual saved Wolf Point readings make this limitation concrete:

| Reading | Baseline | Candidate | Delta |
|---|---:|---:|---:|
| Driver draws |3059|3077|+18|
| Renderer calls |294|312|+18|
| Triangles |1,930,125|1,979,979|+49,854|
| Geometries |692|710|+18|
| Textures |562|588|+26|

Both satisfy the independently checked existing7800draw/2,625,000triangle budgets and GL0. Equality of these readings was never an assertion. The ordinary loop kept running; baseline state was recorded around204.739s and its screenshot completed246.678s, candidate state254.835s and screenshot293.785s. State returned before a screenshot is not an actor-state snapshot at the exact eventual PNG frame. Budget/GL readings likewise describe the recorded forced-step frame, not synchronized telemetry from the exact eventual PNG; the draw delta must not be attributed to wagon cost. Successful asset GET completion/actor pending states were not logged; no exact Bardwell load time or actor-specific causal trace can be recovered from this receipt.

## Exact captured-source explanation

`source-ad813/main.js` is recovered read-only from the actual captured commit; its SHA256 matches the original receipt input pin. The same commit's `humans.js` is preserved alongside it.

- `main.js:4957` updates humans in the live loop. Its world `ready` is set after `firstFrame` at5394–5399, not after all camera-dependent actor bodies are loaded.
- `humans.js:417–418` sets root visibility from body availability and starts `setLod(lod)` asynchronously without awaiting it.
- `humans.js:202–223` awaits asset acquisition, builds and installs the body, then clears pending state after completion. Animation also continues at423.
- Frozen caller `capture.cjs:57` enumerates only camera/projection/lighting/pose/detail/canvas equality. `browser-control-v2.cjs:14–17` advances two ordinary steps and checks individual budget/GL. No resident/scene-stability barrier exists.

This is a concrete supported mechanism consistent with a person appearing between frames and the added draws/resources. It is not a claim that the source proves which actor/LOD completed at which time in these PNGs.

## Bounded comparison validity and future prerequisite

The images still document the two exact wagon forms at the same saved framing/stand/articulation and recorded light settings. They support qualitative local silhouette/drape review with this caveat. They do not isolate every changed pixel, material response, cast shadow or whole-scene cost to the wagon. A newly visible person or moving foliage can also change occlusion/shadows; even canopy shading should not be treated as a controlled causal difference. Source/geometry readback remains separate from visual acceptance. Root's subtle/coherent drape observation is not promoted to photographic completion.

Before a future same-population normal-main pair: establish the FINAL camera first; await every required in-range actor's body and wanted LOD, no pending acquisition; record expected IDs, body/LOD/visibility and relevant scene state; require stable normal-frame pre/post-PNG snapshots. Merely waiting for worldready or two extra frames is insufficient. Whole-frame/pixel-shadow identity additionally requires a separately reviewed way to align animation/wind and dynamic-occluder phase, or an explicitly narrower comparison claim. Do not silently hide residents, change detail/lighting, pause normal rendering, alter these PNGs or weaken existing guards. No such change or rerun is made here.

Original six-image run stays FAIL; the continuation stays PASS only for its two images and cleanup. Desktop8 and full photographic/all-angle/LOD acceptance remain open. This addendum contains read-only inspection and source snapshots only; no app/Git/ticket writes, browser or build.
