// Finite CPU loader/build diagnostic only: stub image bitmap dimensions, no renderer/browser.
import fs from 'node:fs';
import crypto from 'node:crypto';
import {performance} from 'node:perf_hooks';
globalThis.self=globalThis;
// Existing canonical browser receipts verify actual image decode; this CPU control tests geometry/actor build.
globalThis.createImageBitmap=async()=>({width:2048,height:2048,close(){}});
const{HumanActor,createHumanAssets}=await import('/workspace/chicago/chicago/4d/renderers/web/js/humans.js');
const{Vector3}=await import('three');
const root='/workspace/chicago/site/4d/';
const fetchImpl=async url=>{const pathname=new URL(url).pathname,p=root+pathname.replace(/^\//,'');const b=fs.readFileSync(p);return{ok:true,arrayBuffer:async()=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)};};
const assets=createHumanAssets({assetBase:new URL('file:///data/'),fetchImpl});
const instance=JSON.parse(fs.readFileSync(root+'data/humans/instances/1835/hi_rc_bardwell_otis_1835.json'));
const actor=new HumanActor({instance,assets,heightAt:()=>.9992000007629392,tier:'full'});
const start=performance.now(),g=fs.readFileSync(root+'data/humans/web/bardwell_otis_1835.lod0.glb');
const result={scope:'Actual production createHumanAssets parse + HumanActor build/play/clone on exact final GLB. ImageBitmap dimensions stubbed; no image-pixel/browser/town acceptance.',glb_sha256:crypto.createHash('sha256').update(g).digest('hex')};
try{
 await actor.setLod(0);
 await new Promise(r=>setTimeout(r,0));
 actor.update(.05,new Vector3(-94,2.677040002822875,34.2));
 result.passed=!!actor.body&&actor.lod===0&&!actor.pending;
 result.actor={lod:actor.lod,wanted:actor.wanted,pending:!!actor.pending,clip:actor.clipName,body_meshes:actor.body?.meshes.length,bone_counts:actor.body?.meshes.map(m=>m.skeleton.bones.length),inRange:actor.inRange,recheck:actor.recheck,distance:actor.distance,counters:actor.counters,visible:actor.root.visible};
}catch(e){result.passed=false;result.error=e.stack;process.exitCode=1;}
result.elapsed_ms=performance.now()-start;
console.log(JSON.stringify(result,null,2));
fs.writeFileSync(new URL('./CPU-PRODUCTION-BUILD.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
actor.dispose();
