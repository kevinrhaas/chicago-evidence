import pathlib,hashlib,json,difflib
S=pathlib.Path('/workspace/shared/human-standing-bardwell-FINAL-HEAD-SPLIT-EXECUTION-96c4-HELD-20261022')
D=pathlib.Path('/workspace/shared/bardwell-final-town-loader-diagnosis-20261022/proposed-town-observation-only-V2')
assert not D.exists();D.mkdir()
def replace_once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
evidence=[];patch=[]
for name in ('browser_review.cjs','capture_town.cjs'):
 before=(S/name).read_text();after=before
 if name=='browser_review.cjs':
  anchor="  async function waitForBody(lod){const end=performance.now()+90000;while(performance.now()<end){if(actor.body&&actor.lod===lod&&!actor.pending)return;await pause(100);}throw Error('actual autoLOD '+lod+' did not settle');}"
  code="""  // Observation only: no clock, camera, LOD, source, instance, pose or threshold changes.
  const diagnostic={identity:'actual-town-observation-only-v2',events:[],history:[],update_samples:[],observation_errors:[]},observedPending=new WeakSet(),originalUpdate=actor.update,originalSetLod=actor.setLod,originalAcquire=a.humans.assets.acquire;
  const safe=fn=>{try{return fn();}catch(e){try{diagnostic.observation_errors.push(String(e));}catch{}return null;}};
  const record=(name,extra={})=>safe(()=>{diagnostic.events.push({at_ms:performance.now(),name,...extra});});
  const actorState=()=>safe(()=>({at_ms:performance.now(),body:!!actor.body,lod:actor.lod,wanted:actor.wanted,pending:!!actor.pending,recheck:actor.recheck,tier:actor.tier,inRange:actor.inRange,distance:Number.isFinite(actor.distance)?actor.distance:null,visible:actor.root.visible,disposed:actor.disposed,clip:actor.clipName,counters:{...actor.counters},camera:a.camera.position.toArray(),root:actor.root.position.toArray(),welcome:a.welcome?.state,journey:document.documentElement.dataset.journey,panelOpen:a.hud.panelOpen?.(),loaded:a.humans.assets.loaded}));
  const watchPending=()=>safe(()=>{const p=actor.pending;if(p&&!observedPending.has(p)){observedPending.add(p);record('pending_observed',{state:actorState()});p.then(()=>safe(()=>record('pending_fulfilled',{state:actorState()})),e=>safe(()=>record('pending_rejected',{error:e?.stack||String(e),state:actorState()})));}});
  actor.update=function(...args){const before=actorState();try{return originalUpdate.apply(this,args);}finally{safe(()=>{diagnostic.update_samples.push({dt:args[0],before,after:actorState()});if(diagnostic.update_samples.length>256)diagnostic.update_samples.shift();watchPending();});}};
  actor.setLod=function(...args){record('setLod_called',{lod:args[0],state:actorState()});const p=originalSetLod.apply(this,args);safe(()=>p.then(()=>safe(()=>record('setLod_fulfilled',{lod:args[0],state:actorState()})),e=>safe(()=>record('setLod_rejected',{lod:args[0],error:e?.stack||String(e),state:actorState()}))));return p;};
  a.humans.assets.acquire=function(...args){record('acquire_called',{asset:args[0],lod:args[1]});const p=originalAcquire.apply(this,args);safe(()=>p.then(()=>safe(()=>record('acquire_fulfilled',{asset:args[0],lod:args[1]})),e=>safe(()=>record('acquire_rejected',{asset:args[0],lod:args[1],error:e?.stack||String(e)}))));return p;};
  window.__bardwellTownReviewDiagnostics=()=>{safe(()=>{watchPending();diagnostic.current=actorState();});return diagnostic;};
  record('installed',{state:actorState()});watchPending();
  async function waitForBody(lod){const end=performance.now()+90000;record('wait_started',{expected_lod:lod,state:actorState()});let last=-Infinity;while(performance.now()<end){watchPending();safe(()=>{if(performance.now()-last>=1000){diagnostic.history.push(actorState());last=performance.now();}});if(actor.body&&actor.lod===lod&&!actor.pending){record('wait_fulfilled',{expected_lod:lod,state:actorState()});return;}await pause(100);}record('wait_failed',{expected_lod:lod,state:actorState()});throw Error('actual autoLOD '+lod+' did not settle; observed '+safe(()=>JSON.stringify(actorState())));}"""
  after=replace_once(after,anchor,code)
  after=replace_once(after,'    restoreHooks(){for(const [mesh,prior] of hooks)mesh.onAfterRender=prior;}','    restoreHooks(){for(const [mesh,prior] of hooks)mesh.onAfterRender=prior;actor.update=originalUpdate;actor.setLod=originalSetLod;a.humans.assets.acquire=originalAcquire;record(\'observation_hooks_restored\');}')
 else:
  after=replace_once(after,"identity:'actual_published_bardwell_final_head_split_v1'","identity:'actual_published_bardwell_final_head_split_v1',observerRevision:'v2_observation_only'")
  after=replace_once(after,"phase:cfg.phase,inheritedVisual:","captureCallerSHA:sha(fs.readFileSync(__filename)),browserHelperSHA:sha(fs.readFileSync(path.join(__dirname,'browser_review.cjs'))),phase:cfg.phase,inheritedVisual:")
  after=replace_once(after,"page.on('pageerror',e=>receipt.pageErrors.push(e.message));","page.on('pageerror',e=>receipt.pageErrors.push(e.message));receipt.observedConsoleErrors=[];receipt.observedHumanNetwork=[];page.on('console',m=>{if(m.type()==='error')receipt.observedConsoleErrors.push({at:new Date().toISOString(),text:m.text()});});page.on('response',r=>{if(/\\/humans\\//.test(new URL(r.url()).pathname))receipt.observedHumanNetwork.push({at:new Date().toISOString(),event:'response',url:r.url(),status:r.status(),contentLength:r.headers()['content-length']});});page.on('requestfinished',r=>{if(/\\/humans\\//.test(new URL(r.url()).pathname))receipt.observedHumanNetwork.push({at:new Date().toISOString(),event:'requestfinished',url:r.url()});});")
  after=replace_once(after," phase('all_planned_phase_work_completed');"," receipt.observation=await page.evaluate(()=>window.__bardwellTownReviewDiagnostics?.());phase('all_planned_phase_work_completed');")
  after=replace_once(after,"})().catch(e=>{receipt.error=e.stack;receipt.pass=false;process.exitCode=1;})","})().catch(async e=>{receipt.error=e.stack;receipt.pass=false;if(page)receipt.observation=await page.evaluate(()=>window.__bardwellTownReviewDiagnostics?.()).catch(()=>null);process.exitCode=1;})")
 (D/name).write_text(after)
 (D/('ORIGINAL-'+name)).write_text(before)
 evidence.append({'name':name,'original_path':str(S/name),'original_sha256':hashlib.sha256(before.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(after.encode()).hexdigest()})
 patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='original/'+name,tofile='proposed/'+name))
(D/'OBSERVATION-ONLY.patch').write_text(''.join(patch))
(D/'PREPARED-HELD.json').write_text(json.dumps({'state':'PREPARED_HELD_NO_FULL_TOWN_RUN','released':False,'original_failure':'/workspace/shared/bardwell-FINAL-town-desktop-visual-20261022/receipt.json','unchanged':['production/app/published bytes','all3fixedcameras and reachable routes','AUTOLOD/tier','original90s wait and540s globalcap','10%allvertexpadding','2mmsole/actualshoerender/bodyroot/instance/card/loader/far/budget guards'],'changed':'Observation wrappers preserve original method inputs/return promises; ring256 actual dt/before/after states, pending/acquire/setLod outcomes, human request completion, console errors. Failure receipt contains read-only snapshot. No new pass/fail waiver or hidden clock adjustment.','files':evidence},indent=2)+'\n')
print(json.dumps(evidence,indent=2))
