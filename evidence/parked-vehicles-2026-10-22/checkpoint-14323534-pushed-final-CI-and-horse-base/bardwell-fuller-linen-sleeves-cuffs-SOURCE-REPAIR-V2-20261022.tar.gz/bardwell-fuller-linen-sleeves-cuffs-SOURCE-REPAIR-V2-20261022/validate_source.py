from pathlib import Path
import sys,json,time,hashlib,importlib.util,math,collections,traceback,ast,copy
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'proposed'))
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=module('baseline_workwear',R/'baseline/human_workwear_fit.py');new=module('new_workwear',R/'proposed/human_workwear_fit.py')
from human_shirt_sleeve import _boundaries
H=lambda x:hashlib.sha256(json.dumps(x,separators=(',',':'),sort_keys=True).encode()).hexdigest()
def main():
 started=time.monotonic();bodypath=Path('/workspace/chicago-waistcoat/chicago/4d/assets/authored/humans/makehuman_hm08/prepared_adult_25.json');body=json.loads(bodypath.read_text());body_hash=H(body);mesh=body['meshes'][0];bones={x['name']:x for x in body['skeleton']};recipe=json.loads((R/'baseline/worker_1835.json').read_text());after_recipe=json.loads((R/'proposed/worker_1835.json').read_text());scale=recipe.get('height_scale',1);height=max(p[1] for m in body['meshes'] for p in m['positions_m'])*scale;variant=next(x for x in after_recipe['proof_variants'] if x['id']=='bardwell_otis_1835');active={**recipe,'shirt_sleeve_pattern':variant['shirt_sleeve_pattern']}
 old=base.garment_shell(mesh,'shirt',recipe['shirt_offset_m'],recipe,bones,height,scale);default=new.garment_shell(mesh,'shirt',recipe['shirt_offset_m'],recipe,bones,height,scale);result=new.garment_shell(mesh,'shirt',recipe['shirt_offset_m'],active,bones,height,scale);nv=len(old['positions_m']);nf=len(old['triangles']);checks=[]
 def check(name,v,detail=None):
  checks.append({'name':name,'passed':bool(v),'detail':detail})
  if not v:raise ValueError(name+': '+str(detail))
 check('body JSON,source bones,morphs,weights unchanged',H(body)==body_hash)
 check('no-opt-in shirt result exact baseline',default==old)
 check('all existing shirt vertex weights preserved',result['weights'][:nv]==old['weights'])
 check('all existing per-corner UVs preserved',result['corner_uvs'][:nf]==old['corner_uvs'])
 check('all existing source-basis/triangle IDs preserved',result['source_basis'][:nv]==old['source_basis'] and result['source_triangle_indices'][:nf]==old['source_triangle_indices'])
 check('all existing triangles and vertex UV values preserved',result['triangles'][:nf]==old['triangles'] and result['uvs'][:nv]==old['uvs'])
 check('non-sleeve original torso and collar vertices exact',all(result['positions_m'][i]==p for i,p in enumerate(old['positions_m']) if abs(p[0])<=bones['upperarm_l']['head_m'][0]))
 check('all new and old weights normalized and <=4',all(len(w)<=4 and min(w.values())>=0 and abs(math.fsum(w.values())-1)<1e-12 for w in result['weights']))
 check('all positions finite',all(all(math.isfinite(v) for v in p) for p in result['positions_m']))
 minimum_area=math.inf;edge_dirs=collections.defaultdict(list)
 for f in result['triangles']:
  a,b,c=[result['positions_m'][i] for i in f];u=[b[k]-a[k] for k in range(3)];v=[c[k]-a[k] for k in range(3)];area=math.hypot(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])/2;minimum_area=min(minimum_area,area)
  for x,y in zip(f,f[1:]+f[:1]):edge_dirs[tuple(sorted((x,y)))].append((x,y))
 check('all triangles retain nonzero area',minimum_area>1e-18,minimum_area)
 check('shared cuff seams have exactly two opposite edge owners',all(len(e)<=2 and (len(e)==1 or e[0]==tuple(reversed(e[1]))) for e in edge_dirs.values()))
 cycles,edges=_boundaries(result);check('four original garment openings remain complete cycles',len(cycles)==4,[len(x) for x in cycles]);cuff=result['receipt']['full_linen_sleeves_cuffs'];check('two full cuff bands share original wrist IDs',len(cuff['cuffs'])==2 and all(len(x['shared_original_wrist_ids'])==23 and x['full_perimeter_closed'] and x['hand_passage_open'] for x in cuff['cuffs']))
 check('new cuff faces explicitly authored not counterfeit body faces',all(x is None for x in result['source_triangle_indices'][nf:]))
 # All defaults and non-Bardwell variant metadata remain byte-in-value equivalent.
 original_recipe=copy.deepcopy(recipe);test_recipe=copy.deepcopy(after_recipe);next(x for x in test_recipe['proof_variants'] if x['id']=='bardwell_otis_1835').pop('shirt_sleeve_pattern');check('only Bardwell explicit recipe addition',test_recipe==original_recipe)
 for kind,offset in [('waistcoat',recipe['waistcoat_offset_m']),('trousers',recipe['trouser_offset_m'])]:
  check(kind+' source geometry remains exact even with Bardwell sleeve opt-in',base.garment_shell(mesh,kind,offset,recipe,bones,height,scale)==new.garment_shell(mesh,kind,offset,active,bones,height,scale))
 # Fixed source sections near mid-upperarm and mid-forearm, reported without a rendered fit claim.
 sections=[]
 for side,sign in [('l',1),('r',-1)]:
  axis=bones['upperarm_'+side]['head_m'];elbow=bones['lowerarm_'+side]['head_m'];hand=bones['hand_'+side]['head_m']
  for label,at in [('mid_upperarm',(abs(axis[0])+abs(elbow[0]))/2),('mid_forearm',(abs(elbow[0])+abs(hand[0]))/2)]:
   row={'side':side,'section':label,'longitudinal_plane_m':at}
   for name,s in [('before',old),('after',result)]:
    ps=[p for p in s['positions_m'] if abs(sign*p[0]-at)<.015 and sign*p[0]>0];radii=[math.hypot(p[1]-axis[1],p[2]-axis[2]) for p in ps];row[name]={'sample_vertices':len(ps),'minimum_radius_m':min(radii),'maximum_radius_m':max(radii),'mean_radius_m':math.fsum(radii)/len(radii)}
   sections.append(row)
 moves=[math.dist(a,b) for a,b in zip(old['positions_m'],result['positions_m'][:nv])];check('authored source movements bounded below65mm',max(moves)<.065,max(moves));check('every new cuff support keeps original minimum6mm radial clearance',min(x['radial_clearance_m'] for x in cuff['source_supports'])>=.006)
 report={'status':'FINITE_SOURCE_MATH_PASS_NOT_EXPORTED_OR_RENDERED','source_body_sha256':hashlib.sha256(bodypath.read_bytes()).hexdigest(),'elapsed_seconds':time.monotonic()-started,'checks':checks,'before':{'shirt_vertices':nv,'shirt_triangles':nf,'boundary_cycles':[len(x) for x in _boundaries(old)[0]]},'after':{'shirt_vertices':len(result['positions_m']),'shirt_triangles':len(result['triangles']),'boundary_cycles':[len(x) for x in cycles],'added_vertices':len(result['positions_m'])-nv,'added_triangles':len(result['triangles'])-nf,'maximum_existing_vertex_displacement_m':max(moves),'minimum_triangle_area_m2':minimum_area},'source_sections':sections,'cuffs':cuff['cuffs'],'support_samples':len(cuff['source_supports']),'minimum_cuff_radial_source_clearance_m':min(x['radial_clearance_m'] for x in cuff['source_supports']),'unproven':['source-ray samples do not prove all cloth triangles or animated garment/body/vest contact','no Blender,canonical export,raw normal readback,LOD,deformed source/meshopt inspection or visual acceptance','body/rig/sole source data exact does not transfer future end-to-end normal/shoe/framing checks','original40 inherited fit negatives remain open; no masks or changed tolerances']}
 (R/'FINITE-SOURCE-MATH-RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
try:main()
except Exception as e:
 (R/'FINITE-SOURCE-MATH-ACTUAL-FAILURE.json').write_text(json.dumps({'status':'SOURCE_CHECK_FAILED','error':traceback.format_exc()},indent=2)+'\n');raise
