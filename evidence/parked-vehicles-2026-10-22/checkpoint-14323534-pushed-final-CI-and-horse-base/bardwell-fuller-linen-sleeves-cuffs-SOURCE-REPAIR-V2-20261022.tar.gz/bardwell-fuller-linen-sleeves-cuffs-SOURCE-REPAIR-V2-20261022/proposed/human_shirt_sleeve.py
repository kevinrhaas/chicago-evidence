# SPDX-License-Identifier: GPL-3.0-or-later
"""Original source-only linen sleeve/cuff construction. Generated arrays CC0-1.0.

Authored dimensions, not measured historic garments. Existing body, rig, old
corner UVs and weights are untouched. New cuff UVs/weights/support are explicit.
Actual Blender/export/animation/LOD/fit/appearance acceptance remains pending.
"""
import collections,copy,math

def _dot(a,b):return math.fsum(x*y for x,y in zip(a,b))
def _sub(a,b):return [x-y for x,y in zip(a,b)]
def _clamp(t):return max(0.,min(1.,t))
def _smooth(t):t=_clamp(t);return t*t*(3-2*t)
def _boundaries(shell):
    edges=collections.defaultdict(list)
    for f in shell['triangles']:
        for a,b in zip(f,f[1:]+f[:1]):edges[tuple(sorted((a,b)))].append((a,b))
    if any(len(v)>2 for v in edges.values()):raise ValueError('nonmanifold input shirt edge')
    graph=collections.defaultdict(list)
    for (a,b),rows in edges.items():
        if len(rows)==1:graph[a].append(b);graph[b].append(a)
    if any(len(v)!=2 for v in graph.values()):raise ValueError('shirt requires degree-two boundary cycles')
    cycles=[];seen=set()
    for start in sorted(graph):
        if start in seen:continue
        cycle=[];previous=None;current=start
        while current not in seen:
            cycle.append(current);seen.add(current)
            previous,current=current,next(i for i in graph[current] if i!=previous)
        if current!=start:raise ValueError('shirt boundary did not close')
        cycles.append(cycle)
    return cycles,edges

def fuller_linen_sleeves(shell,body,bones,parameters,scale=1.):
    """Bardwell explicit opt-in only; shared sleeve/cuff topology before decimation."""
    if parameters.get('id')!='bardwell_full_linen_sleeves_cuffs_v1' or scale<=0:raise ValueError('unsupported sleeve pattern')
    full=parameters['maximum_added_radial_fullness_m']/scale
    fold=parameters['fold_radial_amplitude_m']/scale
    width=parameters['cuff_width_m']/scale
    setback=parameters['cuff_hand_edge_before_wrist_m']/scale
    ease=parameters['cuff_source_clearance_m']/scale
    thickness=parameters['cuff_return_thickness_m']/scale
    depth=parameters['cuff_return_depth_m']/scale
    if not (0<fold<full<.04/scale and .02/scale<=width<=.04/scale and 0<setback<.015/scale and 0<thickness<ease and 0<depth<width/2):raise ValueError('invalid reconstructed sleeve/cuff dimensions')
    cycles,edges=_boundaries(shell);out=copy.deepcopy(shell);old_nv=len(shell['positions_m']);old_nf=len(shell['triangles']);frames={};cuffs={}
    for side,sign in [('l',1),('r',-1)]:
        shoulder=bones['upperarm_'+side]['head_m'];elbow=bones['lowerarm_'+side]['head_m'];wrist=bones['hand_'+side]['head_m']
        if any(abs(p[k]-shoulder[k])>1e-12 for p in [elbow,wrist] for k in [1,2]) or not sign*shoulder[0]<sign*elbow[0]<sign*wrist[0]:raise ValueError('expected exact cleared horizontal T-pose arm frame')
        owned=[c for c in cycles if all(sign*shell['positions_m'][i][0]>sign*wrist[0]-.06/scale and math.fsum(w for n,w in shell['weights'][i].items() if n in ['lowerarm_'+side,'hand_'+side])>.9 for i in c)]
        if len(owned)!=1:raise ValueError('need one exact source-owned wrist loop '+side)
        ids=owned[0];old_end=max(sign*shell['positions_m'][i][0] for i in ids);end=sign*wrist[0]-setback;start=end-width
        if not sign*elbow[0]<start<old_end<sign*wrist[0]+.015/scale:raise ValueError('cuff exceeds actual source forearm')
        frames[side]={'sign':sign,'shoulder':shoulder,'elbow':elbow,'wrist':wrist,'old_end':old_end,'start':start,'end':end};cuffs[side]=ids
    changed=[]
    for i,(p,w) in enumerate(zip(shell['positions_m'],shell['weights'])):
        side='l' if p[0]>=0 else 'r';f=frames[side];sign=f['sign'];q=sign*p[0];x0=sign*f['shoulder'][0];xe=sign*f['elbow'][0]
        mass=math.fsum(v for n,v in w.items() if n in ['clavicle_'+side,'upperarm_'+side,'lowerarm_'+side,'hand_'+side]);own=_smooth((mass-.25)/.5)
        if q<=x0 or own==0:continue
        if q>xe:q=xe+(q-xe)*(f['start']-xe)/(f['old_end']-xe)
        t=_clamp((q-x0)/(f['start']-x0));dy=p[1]-f['shoulder'][1];dz=p[2]-f['shoulder'][2];radius=math.hypot(dy,dz)
        if radius<=1e-12:raise ValueError('source sleeve point lies on arm axis')
        theta=math.atan2(dz,dy);envelope=max(0.,math.sin(math.pi*t))**.7
        added=own*envelope*(full+fold*math.cos(4*theta+2*math.pi*t))
        out['positions_m'][i]=[sign*q,p[1]+added*dy/radius,p[2]+added*dz/radius]
        changed.append(i)
    # Radial source supports at exact cuff planes. No sampled photograph/mesh is used.
    source_weights={}
    for sid,w in zip(body['source_vertex_indices'],body['weights']):
        if sid in source_weights and source_weights[sid]!=w:raise ValueError('source UV duplicate weights disagree')
        source_weights[sid]=w
    support_rows=[];cuff_rows=[]
    for side,ids in cuffs.items():
        f=frames[side];sign=f['sign'];cy,cz=f['shoulder'][1:]
        # Keep the exact old boundary IDs/edges. The centroid-selected source
        # cut is axially jagged and its projected atan2 can backtrack: casting
        # those raw angles onto a common plane folds otherwise valid topology.
        # Transport its cyclic three-dimensional arclength, with the original
        # phase and signed projected area, to one strictly monotone revolution.
        source_loop=[shell['positions_m'][i] for i in ids]
        lengths0=[math.dist(a,b) for a,b in zip(source_loop,source_loop[1:]+source_loop[:1])]
        area=math.fsum((a[1]-cy)*(b[2]-cz)-(a[2]-cz)*(b[1]-cy) for a,b in zip(source_loop,source_loop[1:]+source_loop[:1]))
        if min(lengths0)<=1e-12 or abs(area)<=1e-12:raise ValueError('degenerate source wrist traversal')
        direction=1 if area>0 else -1;phase=math.atan2(source_loop[0][2]-cz,source_loop[0][1]-cy);perimeter0=math.fsum(lengths0)
        rays=[phase+direction*2*math.pi*math.fsum(lengths0[:k])/perimeter0 for k in range(len(ids))]
        candidates=[]
        for fi,face in enumerate(body['triangles']):
            xs=[sign*body['positions_m'][i][0] for i in face]
            if min(xs)<=f['end'] and max(xs)>=f['start']:candidates.append((fi,face))
        def cross(a,b):return a[0]*b[1]-a[1]*b[0]
        def support(q,theta,clearance):
            direction=(math.cos(theta),math.sin(theta));hits=[]
            for fi,face in candidates:
                intersections=[]
                for ia,ib in zip(face,face[1:]+face[:1]):
                    a,b=body['positions_m'][ia],body['positions_m'][ib];ax,bx=sign*a[0],sign*b[0]
                    if not ((ax<q<bx) or (bx<q<ax)):continue
                    t=(q-ax)/(bx-ax);point=[a[k]+t*(b[k]-a[k]) for k in range(3)]
                    intersections.append((point,{body['source_vertex_indices'][ia]:1-t,body['source_vertex_indices'][ib]:t}))
                if len(intersections)!=2:continue
                (a,wa),(b,wb)=intersections;A=(a[1]-cy,a[2]-cz);E=(b[1]-a[1],b[2]-a[2]);den=cross(direction,E)
                if abs(den)<1e-15:continue
                radius=cross(A,E)/den;u=cross(A,direction)/den
                if radius<=0 or not -1e-10<=u<=1+1e-10:continue
                u=_clamp(u);basis={sid:(1-u)*wa.get(sid,0)+u*wb.get(sid,0) for sid in set(wa)|set(wb)};hits.append((radius,fi,basis))
            hits.sort(key=lambda x:x[0]);unique=[]
            for hit in hits:
                if not unique or abs(hit[0]-unique[-1][0])>1e-8:unique.append(hit)
            if len(unique)!=1:raise ValueError('cuff source ray must cross one boundary '+repr((side,q,theta,len(unique))))
            radius,fi,basis=unique[0];point=[sign*q,cy+(radius+clearance)*direction[0],cz+(radius+clearance)*direction[1]]
            weights={n:math.fsum(v*source_weights[sid].get(n,0) for sid,v in basis.items()) for n in sorted(set().union(*(source_weights[sid] for sid in basis)))}
            weights=sorted(((n,v) for n,v in weights.items() if v>1e-12),key=lambda x:(-x[1],x[0]));drop=math.fsum(v for n,v in weights[4:])
            if drop>.025:raise ValueError('new cuff exceeds original2.5percent discarded skin mass')
            weights=dict(weights[:4]);total=math.fsum(weights.values());weights={n:v/total for n,v in weights.items()}
            return point,fi,basis,weights,radius
        # The original sleeve wrist IDs become the shared cuff base; old weights/UVs stay exact.
        for k,(i,theta) in enumerate(zip(ids,rays)):
            point,fi,basis,w,radius=support(f['start'],theta,ease);out['positions_m'][i]=point
            support_rows.append({'side':side,'vertex':i,'source_triangle':fi,'plane_m':f['start']*scale,'source_radial_m':radius*scale,'radial_clearance_m':ease*scale,'old_vertex_weights_preserved':True})
        lengths=[math.dist(out['positions_m'][a],out['positions_m'][b]) for a,b in zip(ids,ids[1:]+ids[:1])];perimeter=math.fsum(lengths);us=[math.fsum(lengths[:k])/perimeter for k in range(len(ids))];rings=[ids]
        for fraction,clearance in [(0.5,ease),(1.,ease),(1.-depth/width,ease-thickness)]:
            ring=[];q=f['start']+fraction*width
            for k,theta in enumerate(rays):
                point,fi,basis,w,radius=support(q,theta,clearance);idx=len(out['positions_m']);ring.append(idx);out['positions_m'].append(point);out['weights'].append(w);out['uvs'].append([us[k],len(rings)/3]);out['source_basis'].append(basis)
                support_rows.append({'side':side,'vertex':idx,'source_triangle':fi,'source_basis':basis,'plane_m':q*scale,'source_radial_m':radius*scale,'radial_clearance_m':clearance*scale,'old_vertex_weights_preserved':False})
            rings.append(ring)
        flip=edges[tuple(sorted(ids[:2]))][0]==tuple(ids[:2]);N=len(ids)
        for row,(lower,upper) in enumerate(zip(rings,rings[1:])):
            for k in range(N):
                n=(k+1)%N;a,b,c,d=lower[k],lower[n],upper[n],upper[k];u0,u1=us[k],us[n] if n else 1.;v0,v1=row/3,(row+1)/3
                for face,uv in [([a,b,c],[[u0,v0],[u1,v0],[u1,v1]]),([a,c,d],[[u0,v0],[u1,v1],[u0,v1]])]:
                    if flip:face.reverse();uv.reverse()
                    out['triangles'].append(face);out['corner_uvs'].append(uv);out['source_triangle_indices'].append(None)
        cuff_rows.append({'side':side,'shared_original_wrist_ids':ids,'new_ring_ids':rings[1:],'angular_parameterization':{'method':'original_3D_boundary_arclength_monotone_revolution','source_projected_signed_double_area_m2':area,'phase_rad':phase,'winding':direction,'angles_rad':rays,'source_edge_lengths_m':lengths0,'preserved_original_ID_edge_order':True},'original_boundary_longitudinal_span_m':[(sign*shell['positions_m'][i][0])*scale for i in ids],'cuff_start_m':f['start']*scale,'cuff_end_m':f['end']*scale,'width_m':width*scale,'full_perimeter_closed':True,'hand_passage_open':True,'same_linen_material':True,'new_triangles':6*N})
    out['receipt']['full_linen_sleeves_cuffs']={'parameters':parameters,'old_vertices':old_nv,'old_triangles':old_nf,'old_vertex_weights_and_corner_UVs_unchanged':True,'moved_original_sleeve_vertices':changed,'cuffs':cuff_rows,'source_supports':support_rows,'units':'metres; dimensions are reconstruction choices','scope':'Pure source construction only. No actual exported/animated/LOD/garment-contact/photographic acceptance; body/rig/pose/material source unchanged.'}
    return out
