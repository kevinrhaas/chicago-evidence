from pathlib import Path
import sys,json,collections,time,hashlib
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'baseline'));from human_workwear_fit import garment_shell
p=Path('/workspace/chicago-waistcoat/chicago/4d/assets/authored/humans/makehuman_hm08/prepared_adult_25.json');body=json.loads(p.read_text());recipe=json.loads((R/'baseline/worker_1835.json').read_text());bones={b['name']:b for b in body['skeleton']};scale=recipe.get('height_scale',1);height=max(v[1] for m in body['meshes'] for v in m['positions_m'])*scale;t=time.monotonic();m=body['meshes'][0];s=garment_shell(m,'shirt',recipe['shirt_offset_m'],recipe,bones,height,scale)
e=collections.Counter(tuple(sorted((a,b))) for f in s['triangles'] for a,b in zip(f,[f[1],f[2],f[0]]));g=collections.defaultdict(list)
for (a,b),count in e.items():
 if count==1:g[a].append(b);g[b].append(a)
print('max boundarydegree',max(map(len,g.values())))
cycles=[];seen=set()
for start in sorted(g):
 if start in seen:continue
 cycle=[];previous=None;current=start
 for _ in range(len(g)+1):
  if current==start and cycle:break
  if current in cycle:raise ValueError('branchcycle')
  cycle.append(current);seen.add(current);neighbours=[x for x in g[current] if x!=previous];previous,current=current,neighbours[0]
 cycles.append(cycle)
rows=[]
for c in cycles:
 ps=[s['positions_m'][i] for i in c];rows.append({'vertices':len(c),'mean':[sum(p[k] for p in ps)/len(ps) for k in range(3)],'min':[min(p[k] for p in ps) for k in range(3)],'max':[max(p[k] for p in ps) for k in range(3)],'firstweights':s['weights'][c[0]]})
j={'source_body':str(p),'source_body_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'seconds':time.monotonic()-t,'shirt_vertices':len(s['positions_m']),'shirt_triangles':len(s['triangles']),'boundary_cycles':rows,'boundaries_degree_two':all(len(v)==2 for v in g.values())};(R/'BASELINE-SOURCE-BOUNDARY-INSPECTION.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j,indent=2))
