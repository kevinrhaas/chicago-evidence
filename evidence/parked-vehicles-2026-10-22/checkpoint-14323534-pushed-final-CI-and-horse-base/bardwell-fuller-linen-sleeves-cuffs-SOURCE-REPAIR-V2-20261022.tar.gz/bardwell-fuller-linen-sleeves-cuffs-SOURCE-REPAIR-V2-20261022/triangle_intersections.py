"""Finite geometric intersection witnesses; shared topology exempts only its locus."""
import math
EPS=1e-9

def sub(a,b):return [x-y for x,y in zip(a,b)]
def dot(a,b):return math.fsum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def distance_segment(p,a,b):
 d=sub(b,a);den=dot(d,d);t=max(0.,min(1.,dot(sub(p,a),d)/den)) if den else 0.
 return math.dist(p,[a[k]+t*d[k] for k in range(3)])
def inside(p,tri):
 a,b,c=tri;v0=sub(b,a);v1=sub(c,a);v2=sub(p,a);d00=dot(v0,v0);d01=dot(v0,v1);d11=dot(v1,v1);d20=dot(v2,v0);d21=dot(v2,v1);den=d00*d11-d01*d01
 if den<=1e-30:return False
 u=(d11*d20-d01*d21)/den;v=(d00*d21-d01*d20)/den
 return u>=-1e-8 and v>=-1e-8 and u+v<=1+1e-8

def intersection_witnesses(A,B,shared=()):
 nA=cross(sub(A[1],A[0]),sub(A[2],A[0]));nB=cross(sub(B[1],B[0]),sub(B[2],B[0]));la=math.hypot(*nA);lb=math.hypot(*nB)
 if min(la,lb)<1e-20:raise ValueError('degenerate triangle')
 nA=[x/la for x in nA];nB=[x/lb for x in nB];da=[dot(sub(p,B[0]),nB) for p in A];db=[dot(sub(p,A[0]),nA) for p in B]
 if min(da)>EPS or max(da)<-EPS or min(db)>EPS or max(db)<-EPS:return []
 hits=[]
 for P,T,n in [(A,B,nB),(B,A,nA)]:
  for a,b in zip(P,P[1:]+P[:1]):
   d0=dot(sub(a,T[0]),n);d1=dot(sub(b,T[0]),n)
   if abs(d0)<=EPS and inside(a,T):hits.append(a)
   if d0*d1<0:
    t=d0/(d0-d1);p=[a[k]+t*(b[k]-a[k]) for k in range(3)]
    if inside(p,T):hits.append(p)
 if max(map(abs,da+db))<=EPS:
  drop=max(range(3),key=lambda k:abs(nA[k]));keep=[k for k in range(3) if k!=drop]
  def cr(u,v):return u[0]*v[1]-u[1]*v[0]
  for a,b in zip(A,A[1:]+A[:1]):
   av=[a[k] for k in keep];v=[b[k]-a[k] for k in keep]
   for c,d in zip(B,B[1:]+B[:1]):
    cv=[c[k] for k in keep];w=[d[k]-c[k] for k in keep];den=cr(v,w)
    if abs(den)<1e-18:continue
    delta=[cv[k]-av[k] for k in range(2)];t=cr(delta,w)/den;u=cr(delta,v)/den
    if -1e-8<=t<=1+1e-8 and -1e-8<=u<=1+1e-8:hits.append([a[k]+t*(b[k]-a[k]) for k in range(3)])
 def legitimate(p):
  if len(shared)==1:return math.dist(p,shared[0])<=EPS*4
  if len(shared)==2:return distance_segment(p,*shared)<=EPS*4
  return False
 return [p for p in hits if not legitimate(p)]

def bounds(T):return [(min(p[k] for p in T),max(p[k] for p in T)) for k in range(3)]
def overlap(a,b):return all(a[k][0]<=b[k][1]+EPS and b[k][0]<=a[k][1]+EPS for k in range(3))

def controls():
 A=[[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]]
 cases=[('transverse_crossing',[[.2,.2,-1],[.2,.2,1],[.8,.2,0]],(),True),('disjoint',[[2.,0.,0.],[3.,0.,0.],[2.,1.,0.]],(),False),('coplanar_overlap',[[.1,.1,0],[.8,.1,0],[.1,.8,0]],(),True),('legitimate_shared_edge',[[0.,0.,0.],[0.,1.,0.],[-1.,0.,0.]],(A[0],A[2]),False),('overlap_beyond_shared_edge',[[0.,0.,0.],[0.,1.,0.],[.4,.2,0.]],(A[0],A[2]),True),('shared_vertex_legitimate',[[0.,0.,0.],[-1.,0.,0.],[0.,-1.,0.]],(A[0],),False),('shared_vertex_crossing',[[0.,0.,0.],[.6,.2,-1.],[.2,.6,1.]],(A[0],),True)]
 rows=[]
 for name,B,shared,expected in cases:
  actual=bool(intersection_witnesses(A,B,shared));rows.append({'name':name,'expected_intersection':expected,'actual_intersection':actual});assert actual==expected,name
 return rows
