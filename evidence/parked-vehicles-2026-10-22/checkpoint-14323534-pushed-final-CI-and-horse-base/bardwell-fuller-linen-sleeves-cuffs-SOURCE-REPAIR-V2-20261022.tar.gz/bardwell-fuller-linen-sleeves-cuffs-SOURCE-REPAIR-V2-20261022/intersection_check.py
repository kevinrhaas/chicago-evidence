from pathlib import Path
exec(Path(__file__).with_name('review.py').read_text().split('# Independent ray/triangle')[0])
from triangle_intersections import *
start=time.monotonic();control_rows=controls();P=shirt['positions_m'];F=shirt['triangles'];nf=len(old['triangles']);cuff_ids=set(i for c in shirt['receipt']['full_linen_sleeves_cuffs']['cuffs'] for ring in [c['shared_original_wrist_ids']]+c['new_ring_ids'] for i in ring)
# All authored cuff faces and every inherited face incident to a moved shared wrist vertex.
selected=[i for i,f in enumerate(F) if any(v in cuff_ids for v in f)];Ts=[[P[v] for v in f] for f in F];Bs=[bounds(t) for t in Ts];self_hits=[];self_pairs=0
for i in selected:
 for j in range(len(F)):
  if i==j or (j in selected and j<i) or not overlap(Bs[i],Bs[j]):continue
  self_pairs+=1;shared=[P[v] for v in set(F[i])&set(F[j])];w=intersection_witnesses(Ts[i],Ts[j],shared)
  if w:self_hits.append({'triangles':[i,j],'witness_m':w[0],'shared_vertex_ids':sorted(set(F[i])&set(F[j]))})
bodyTs=[[mesh['positions_m'][v] for v in f] for f in mesh['triangles']];bodyBs=[bounds(t) for t in bodyTs];body_hits=[];body_pairs=0
for i in selected:
 for j,b in enumerate(bodyBs):
  if not overlap(Bs[i],b):continue
  body_pairs+=1;w=intersection_witnesses(Ts[i],bodyTs[j])
  if w:body_hits.append({'shirt_triangle':i,'body_triangle':j,'witness_m':w[0]})
report={'status':'FINITE_EXACT_REST_POSE_INTERSECTION_RESULT','elapsed_seconds':time.monotonic()-start,'epsilon_m':EPS,'selected_cuff_and_shared_boundary_transition_triangles':len(selected),'selected_triangle_ids':selected,'all_shirt_triangles_tested_against':len(F),'all_source_body_triangles_tested_against':len(bodyTs),'self_bbox_candidates':self_pairs,'body_bbox_candidates':body_pairs,'self_intersections':self_hits,'source_body_intersections':body_hits,'algorithm_controls':control_rows,'shared_topology_rule':'Only actual shared vertex or shared edge locus exempted; triangles sharing IDs still tested elsewhere. Coplanar overlap included.','limitations':['finite rest-pose floating-point surface intersection, not animation/LOD/export proof','no Blender/browser/build/app writes','no cloth thickness collision/physical clearance or photographic acceptance']}
(O/'TRIANGLE-INTERSECTION-RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='selected_triangle_ids'},indent=2))

assert not self_hits and not body_hits, "cuff/transition surface intersection"
