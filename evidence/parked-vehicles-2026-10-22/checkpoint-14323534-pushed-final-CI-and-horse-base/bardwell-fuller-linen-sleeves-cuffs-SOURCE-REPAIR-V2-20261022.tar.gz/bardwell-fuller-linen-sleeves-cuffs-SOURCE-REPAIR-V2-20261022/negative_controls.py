from pathlib import Path
import json,sys,copy
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'proposed'));from human_shirt_sleeve import fuller_linen_sleeves
recipe=json.loads((R/'proposed/worker_1835.json').read_text());base=next(v for v in recipe['proof_variants'] if v['id']=='bardwell_otis_1835')['shirt_sleeve_pattern'];rows=[]
for name,changes,scale in [('unknown feature ID',{'id':'other'},1),('zero scale',{},0),('negative fold',{'fold_radial_amplitude_m':-.01},1),('fold exceeds fullness',{'fold_radial_amplitude_m':.04},1),('oversized cuff',{'cuff_width_m':.08},1),('negative wrist setback',{'cuff_hand_edge_before_wrist_m':-.01},1),('return reaches through clearance',{'cuff_return_thickness_m':.02},1),('return beyond half cuff',{'cuff_return_depth_m':.02},1)]:
 p={**base,**changes}
 try:fuller_linen_sleeves({}, {}, {}, p,scale);raise AssertionError('invalid source pattern accepted')
 except ValueError as e:rows.append({'control':name,'refused':True,'actual_reason':str(e)})
(R/'FINITE-NEGATIVE-CONTROLS.json').write_text(json.dumps({'passed':True,'controls':rows,'no_body_geometry_evaluated':True},indent=2)+'\n');print('8 source-domain negative controls PASS')
