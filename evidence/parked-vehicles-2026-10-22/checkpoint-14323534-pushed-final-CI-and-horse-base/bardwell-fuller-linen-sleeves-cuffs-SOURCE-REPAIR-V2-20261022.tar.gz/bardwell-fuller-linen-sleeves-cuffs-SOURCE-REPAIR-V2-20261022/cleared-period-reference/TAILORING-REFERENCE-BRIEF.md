# Practical 1835 male tailoring reference

I inspected the actual current preview, `human-tailoring-v4-runtime-preview-2026-10-21/1280-after-quarter.png`, and exactly **two historical depictions**. This is a clothing-design review, not a new figure, asset export or photographic acceptance.

## References and rights

1. **William Sidney Mount, *Bargaining for a Horse (Farmers Bargaining)*, 1835.** New-York Historical Society, accession **1858.59**. The museum record was retrieved successfully and confirms the artist, signed date 1835, and Long Island setting. The image used here is the public-domain faithful reproduction from Wikimedia Commons, 1029 × 829 pixels. Original painting: oil on canvas, 24 × 30 inches; those are canvas dimensions, not human measurements. Museum record: <https://emuseum.nyhistory.org/objects/22396/bargaining-for-a-horse-farmers-bargaining>. Commons file: <https://commons.wikimedia.org/wiki/File:Bargaining_for_a_Horse_1835_William_Sidney_Mount.jpg>.

2. **William Sidney Mount, *Bar-room Scene*, 1835.** Art Institute of Chicago, accession **1939.392**. The actual image used here is the public-domain reproduction linked to museum artwork 30709 by Commons metadata, 3000 × 2444 pixels. Commons metadata supplies the title, artist and 1835 date. The current museum webpage returned 403 and the API returned 503, so this review does not claim a fresh successful museum-record read for this second painting. Museum catalog link: <https://www.artic.edu/artworks/30709>. Commons file: <https://commons.wikimedia.org/wiki/File:William_Sidney_Mount_-_Bar-room_Scene_-_1939.392_-_Art_Institute_of_Chicago.jpg>.

Both Commons records explicitly state **Public domain**, `Copyrighted: False`, and no required attribution; Mount died in 1868 and the paintings date to 1835. The downloaded reproductions are of two-dimensional public-domain works. Retain author/title/institution/URLs as source provenance even though attribution is not a license condition. No modern museum photograph of a three-dimensional garment is being borrowed.

The first image is a scene of farmers bargaining in a barnyard, not proof that either man was a Chicago teamster or stable keeper. The second is a staged genre scene, not an occupational uniform survey. They are useful American clothing comparators; neither identifies Otis Bardwell, Joseph Dufresne or Martin Flynn, nor proves a particular outfit in Chicago. The year 1835 does not establish a completion day before July 1. Use the depicted clothing as a circa-1835 analogy for declared reconstruction, without claiming an exact July outfit or backdating later garments.

## Visible observations, separated from recommended construction

| Component | What the source actually shows | Recommended original tailoring for the next model |
| --- | --- | --- |
| Shirt body and sleeves | In *Bargaining*, both men have light shirts. The sleeves stand away from the upper arms and form soft lengthwise folds, with accumulated cloth at bent elbows. They do not follow deltoid/biceps contours like a tight undershirt. | Add real volume around the upper arms, elbow and underarm; allow cloth to hang instead of reproducing the body surface. Keep the torso tucked under the waistcoat/trousers. Use a few broad folds first; do not add noise to a tight shell and call it drape. Exact ease and seam geometry remain engineering choices. |
| Collar and neck | The horse-bargaining figures have distinct white shirt-collar edges and dark neckcloths. The seated man in *Bar-room* has visible light collar/neckcloth shapes. The neck is layered, not one continuous round high-neck surface. | Replace the preview's continuous high seal with a separate collar shape and a clear front opening. A modest dark tied neckcloth is a supported design option for a reconstructed workday outfit; the light neckcloth is another pictured option. Do not make the painted folds into an invented exact knot pattern. |
| Cuffs | *Bargaining* shows full sleeve cloth narrowing at the wrist; the boundary between sleeve and cuff is readable. In *Bar-room*, a little white shirt edge appears beyond the coat sleeve. Exact cuff fasteners are not resolved in the small image. | Add a distinct fitted cuff band with sleeve fullness gathering into it. Give it thickness and a small overlap/closure as original construction. Do not assert a period cuff-button count, stitched pattern or fastening material from these pixels. |
| Waistcoat front | The buff waistcoat in *Bargaining* covers the lower chest/abdomen and closes at the front. The seated *Bar-room* man has a brown waistcoat with a visible row of small contrasting buttons and a defined front edge. | Build two actual front panels with a narrow closure/placket and a lower front that meets. End the open V well above the hem, leaving a substantial closed/buttoned portion. The preview's long V reaching almost to the waist reads as missing cloth. Add collar/lapel facets where the chosen variant needs them, rather than drawing a V-shaped color patch. |
| Waistcoat length and back | The red-backed garment in *Bargaining* ends around the high trouser waist, with a shaped back and visible light fastening/adjustment marks. The view does not reveal a complete cutting pattern. | Keep a short waist-length garment and a defined lower edge that covers the shirt-to-trouser junction. An adjustable back is a plausible optional reconstruction, but do not copy ambiguous marks as a certified buckle or exact lacing system. Avoid a long modern cardigan hem. |
| Trousers | In *Bargaining*, dark trousers are full at the seat and upper leg, with hanging folds from the high waist; the legs descend broadly toward the shoe. In the seated *Bar-room* figure, cloth spans the thigh and folds around the knee instead of tracing the kneecap and calf. | Raise the apparent waist under the waistcoat and enlarge seat/thigh/knee/calf silhouettes. Let the leg hang nearly straight below the knee, with modest taper and cloth meeting the shoe. Preserve articulation clearance. Do not retain the preview's muscle-shaped thighs, tight crotch or narrow exposed ankles as the final trouser silhouette. Hidden fly/waist fasteners remain unobserved; no modern zipper, elastic ankle or jeans styling is warranted. |
| Buttons and surface detail | Small contrasting waistcoat buttons and larger coat buttons are visible in the seated second reference. Shirt-front buttons are mostly covered; neither painting gives a reliable sewing diagram. | Add a small coherent waistcoat button row, matching actual panel closure. Pick count, spacing and material as disclosed original design parameters, not measured source facts. Add original seams, cloth texture and restrained wear only after silhouette/drape are fixed. |

## Priority changes from the current preview

1. **Change the trouser silhouette.** This will produce the strongest difference: a high waist, fuller seat/thighs and hanging lower legs rather than leggings. Keep shoes and garment boundaries separate and retain the existing fit/sole guards.
2. **Give the shirt sleeves room to hang.** The current tight straight sleeve and smoothly fitted shoulder read as a base-mesh garment. Build fullness above the cuff and a few soft elbow/underarm folds.
3. **Close and finish the waistcoat.** Add panel overlap, button row, readable front edges and a substantial closed lower section. Keep the high waist transition covered.
4. **Separate collar, neckcloth and cuffs.** These are small shapes but strong period cues. They should survive ordinary viewing distance before fine texture work.

Do not copy faces, body proportions, social roles or the exact red/yellow outfits onto the named residents. Those are examples, not their likenesses or inventories. Dark brown/gray waistcoats and off-white shirts remain defensible reconstructed alternatives. The paintings do not establish fiber identity, weave count, cloth thickness, pigment chemistry or PBR roughness. Do not turn the paintings' yellowed varnish, canvas crackle or brush marks into fabric texture.

No numerical garment measurements or 3-D ease values were extracted from posed paintings. Root/model author should choose and document those as original fit parameters and test them on the actual rig. This review recommends a construction direction; it does not certify garment intersections, LOD fit, animation or photographic quality.

## Files

- `horse-1835-original.jpg` and `barroom-1835-original.jpg`: the two acquired depictions, both actually viewed.
- `horse-1835-men-source-crop.png`: exact original-pixel crop of both barnyard men.
- `barroom-1835-seated-source-crop.png`: exact original-pixel crop of the seated clothed man.
- `CROP-PROVENANCE.json`: source hashes, source sizes and crop rectangles. No resizing or retouching was used.
- `horse-commons-metadata.json`, `barroom-commons-metadata.json`, `horse-nyhistory-record.html`: date/rights/catalog evidence actually acquired. AIC failed requests are reported above, not relabeled as successful reads.

No app, ticket, Git, model, bake, browser or full-gate operation was performed.
