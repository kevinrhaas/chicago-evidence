from pathlib import Path
exec(Path(__file__).with_name('review.py').read_text().split('# Independent ray/triangle')[0])
from triangle_intersections import sub,dot,cross
nf=len(old['triangles']);nv=len(old['positions_m']);checks=[]
def check(name,value):
 checks.append({'name':name,'passed':bool(value)})
 if not value:raise ValueError(name)
check('original vertex weights/UVs and triangle/corner UV topology exact',shirt['weights'][:nv]==old['weights'] and shirt['uvs'][:nv]==old['uvs'] and shirt['triangles'][:nf]==old['triangles'] and shirt['corner_uvs'][:nf]==old['corner_uvs'])
check('new vertex and corner UVs agree except declared U0/1 seam',all(abs(uv[1]-shirt['uvs'][i][1])<1e-12 and (abs(uv[0]-shirt['uvs'][i][0])<1e-12 or (abs(uv[0]-1)<1e-12 and abs(shirt['uvs'][i][0])<1e-12)) for f,uvs in zip(shirt['triangles'][nf:],shirt['corner_uvs'][nf:]) for i,uv in zip(f,uvs) if i>=nv))
uvareas=[]
for u in shirt['corner_uvs'][nf:]:uvareas.append(abs((u[1][0]-u[0][0])*(u[2][1]-u[0][1])-(u[1][1]-u[0][1])*(u[2][0]-u[0][0]))/2)
check('all authored cuff UV triangles nondegenerate',min(uvareas)>1e-12)
source_weights={sid:w for sid,w in zip(mesh['source_vertex_indices'],mesh['weights'])};maxdrop=0;maxweightdiff=0
for i in range(nv,len(shirt['positions_m'])):
 basis=shirt['source_basis'][i];check('source basis normalized vertex '+str(i),abs(math.fsum(basis.values())-1)<1e-12 and min(basis.values())>=0)
 w={n:math.fsum(v*source_weights[s].get(n,0) for s,v in basis.items()) for n in sorted(set().union(*(source_weights[s] for s in basis)))};ws=sorted(((n,v) for n,v in w.items() if v>1e-12),key=lambda t:(-t[1],t[0]));drop=math.fsum(v for n,v in ws[4:]);maxdrop=max(maxdrop,drop);w=dict(ws[:4]);total=math.fsum(w.values());w={n:v/total for n,v in w.items()};maxweightdiff=max(maxweightdiff,max(abs(shirt['weights'][i].get(n,0)-w.get(n,0)) for n in set(w)|set(shirt['weights'][i])))
check('all new weights derive exact source basis with <=2.5percent loss',maxdrop<=.025 and maxweightdiff<1e-12)
# Do not exempt transition faces simply because their topology is inherited.
shared=set(i for c in shirt['receipt']['full_linen_sleeves_cuffs']['cuffs'] for i in c['shared_original_wrist_ids']);ids=[i for i,f in enumerate(old['triangles']) if set(f)&shared];orient=[]
for fi in ids:
 row={'triangle':fi}
 for name,s in [('before',old),('after',shirt)]:
  a,b,c=[s['positions_m'][i] for i in s['triangles'][fi]];p=[(a[k]+b[k]+c[k])/3 for k in range(3)];side='l' if p[0]>0 else 'r';axis=bones['upperarm_'+side]['head_m'];n=cross(sub(b,a),sub(c,a));row[name]=dot(n,[0,p[1]-axis[1],p[2]-axis[2]]);row[name+'_normal']=n;row['all_original_boundary_vertices']=all(i in shared for i in s['triangles'][fi])
 orient.append(row)
check('nonplanar inherited transition sides stay outward radial',all(r['before']>0 and r['after']>0 for r in orient if not r['all_original_boundary_vertices']))
# All-three-boundary ears become exact plane faces under the common-plane
# construction. Their outward normal is axial toward the shoulder, opposite the cuff extension;
# radial dot is exactly zero by geometry, not a tolerance relaxation.
check('four exact common-plane boundary ears face shoulder opposite cuff extension',sum(r['all_original_boundary_vertices'] for r in orient)==4 and all(r['after']==0 and r['after_normal'][0]*(1 if old['positions_m'][old['triangles'][r['triangle']][0]][0]>0 else -1)<0 for r in orient if r['all_original_boundary_vertices']))
report={'status':'SOURCE_UV_WEIGHT_TRANSITION_ORIENTATION_PASS','checks':checks,'authored_UV_seam':'New cuff chart at original wrist boundary; U=0/1 wrap uses per-corner UV. All original UVs stay exact. New ring vertices and nonseam corners agree; V advances0,1/3,2/3,1 along cuff surface including inner return.','minimum_new_UV_area':min(uvareas),'maximum_discarded_skin_weight_mass':maxdrop,'maximum_new_weight_source_interpolation_error':maxweightdiff,'inherited_transition_triangles':orient,'limits':['rest pose only; future exported skin/normals/UV/animation/LOD/sole acceptance still required']}
(O/'UV-WEIGHT-TRANSITION-RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['checks','inherited_transition_triangles']},indent=2))
