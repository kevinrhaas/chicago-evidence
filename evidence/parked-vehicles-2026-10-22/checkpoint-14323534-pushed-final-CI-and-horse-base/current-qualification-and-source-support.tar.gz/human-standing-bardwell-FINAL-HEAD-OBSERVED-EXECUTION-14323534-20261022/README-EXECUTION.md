# Separate final96c4 execution copy — HELD, no browser or final pins yet

This is a small execution copy of the immutable FINAL-HEAD-SPLIT prepared packet. capture_town.cjs and browser_review.cjs are byte-identical; all actual camera, route, vertex/sole/shoe/budget/card/timing/loader/far/cap/cleanup behavior stays unchanged. Original prepared package and historical failures are untouched. No final HEAD/index has been guessed, no app file changed, no browser/publish/build/network action or pin-helper execution occurred.

Exact canonical authority is copied under IMMUTABLE-CANONICAL-IMPORT-REFERENCE/: mechanically qualified source96c4da4b1fe68e6dec3b18c15da2f14c596a60c5/tree686c475e41c556beaab90d1782057240094d27d0, run39736567239/attempt1, artifact12408480668, ZIP9ca4e1e692da77d3cbb1e0089f2d53cc01cd360d8cafc2b0e97230434326d5f5, root's actual8-asset import receipt and exact selected member manifest. Root import receipt honestly retains its original UNCOMMITTED status; the future pin helper independently proves final clean committed/published bytes before issuing a distinct final pin receipt.

final_pins.py has two explicit local-only operations. Neither launches a browser, shell build, publisher or network request. They write only this execution copy's JSON or fresh /workspace/shared release files. Run in the authorized escalated child-process environment.

**Do not run pin until full preflight84904 actually CLOSED/PASS and root committed/pushed/published the final tree.** Current passed-tree target is5d88d092719c44c379e66f75ac87cebaee52c783; if root changes the staged tree, use the actually passed final tree instead, never claim the old gate covers it.

```sh
python /workspace/shared/human-standing-bardwell-FINAL-HEAD-SPLIT-EXECUTION-96c4-HELD-20261022/final_pins.py pin --expected-head "$(git -C /workspace/chicago rev-parse HEAD)" --passed-tree 5d88d092719c44c379e66f75ac87cebaee52c783 --gate-closed-pass
```

pin refuses staged/dirty trees, unexpected tree/HEAD, noncommitted import bytes, wrong source authoring hashes, missing/nonmatching canonical/import metadata, wrong16-file actual registry/fixture8 hashes, stale published runtime/data/GLBs or stale postcommit build.json. It reads all8 master/web source files and matches their exact lengths/hashes to both root actual import and96c4 intake; source4 and web4 are recorded in canonical JSON. The original caller directly pins web4 source/published bytes and canonical JSON; source4 additionally stay bound by its clean exact tracked HEAD/index guard. No caller edit is needed.

pin also verifies all4 public data/humans/web files, current source/public instance and metadata, the original runtime/data paths used by the caller, and published build.version==actual final HEAD first9. It records explicit target-file hashes in FINAL-PIN-RECEIPT.json; this is not a claim every mirror file is unchanged. It calculates the exact caller-compatible index digest as SHA256 of raw `git ls-files --stage` bytes from repo root. It populates CANONICAL-EXPECTED-INPUTS-HELD.json (filename retained for original caller compatibility), whose state becomes ROOT_PINNED_FINAL_CANONICAL_INPUTS. Its SHA256, actual HEAD/index then populate three RELEASE-*-HELD.json templates, **all still released:false/rootLaneClosed:false/output:null**. It refuses silent repinning.

Only after root verifies the browser/heavy lane is actually free, create one fresh immutable phase release (this step still does not launch):

```sh
python /workspace/shared/human-standing-bardwell-FINAL-HEAD-SPLIT-EXECUTION-96c4-HELD-20261022/final_pins.py release --phase desktop_visual --lane-closed --release /workspace/shared/ROOT-BARDWELL-FINAL-desktop_visual-RELEASE.json --output /workspace/shared/bardwell-FINAL-town-desktop-visual-20261022
PW_EXECUTABLE=/usr/bin/chromium node /workspace/shared/human-standing-bardwell-FINAL-HEAD-SPLIT-EXECUTION-96c4-HELD-20261022/capture_town.cjs /workspace/shared/ROOT-BARDWELL-FINAL-desktop_visual-RELEASE.json > /workspace/shared/bardwell-FINAL-town-desktop-visual-20261022.log 2>&1
```

After actual desktop_visual CLOSED/PASS, root may separately release desktop_functional, passing that NEW actual receipt:

```sh
python /workspace/shared/human-standing-bardwell-FINAL-HEAD-SPLIT-EXECUTION-96c4-HELD-20261022/final_pins.py release --phase desktop_functional --lane-closed --visual-receipt /workspace/shared/bardwell-FINAL-town-desktop-visual-20261022/receipt.json --release /workspace/shared/ROOT-BARDWELL-FINAL-desktop_functional-RELEASE.json --output /workspace/shared/bardwell-FINAL-town-desktop-functional-20261022
```

Run the same caller with that new release path only after root's actual lane decision. It will verify exact same new head/index/canonical/all caller inputPins plus4 completed captures/7 timing samples and closed/sourceUnchanged before proceeding far-first then individual loader rows. Old ad813 partial evidence cannot qualify this phase.

Mobile is another sole-owner explicit release using `--phase mobile_full`, a fresh ROOT-BARDWELL-FINAL-mobile_full-RELEASE.json and fresh /workspace/shared/bardwell-FINAL-town-mobile-full-20261022 output, then the same caller. All phases remain540000ms. No automatic launch, next phase, retry, deadline extension or guard weakening is implemented. Separate desktop phase results remain separate; broad photographic/full-fit and current-head CI/smoke qualification remain open until their own actual evidence.

Validation of the new pin utility is AST syntax and static controls only; it has not been run against the current staged app or hypothetical final tree. Inherited callers were previously syntax/control checked and are byte-identical. Preparation manifest describes the HELD pre-pin package; future FINAL-PIN-RECEIPT.json explicitly identifies intentional later canonical/template pin updates and source/runtime/published hashes. Do not mistake the preparation manifest for a post-pin freeze receipt.
