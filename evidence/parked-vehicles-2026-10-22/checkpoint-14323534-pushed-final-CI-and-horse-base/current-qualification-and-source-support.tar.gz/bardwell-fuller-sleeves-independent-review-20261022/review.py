import pathlib,json,hashlib,sys,importlib.util,math,time,ast
R=pathlib.Path('/workspace/shared/bardwell-fuller-linen-sleeves-cuffs-SOURCE-PROPOSAL-20261022');O=pathlib.Path(__file__).parent
sys.path.insert(0,str(R/'proposed'))
def mod(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
t0=time.monotonic();base=mod('independent_base',R/'baseline/human_workwear_fit.py');new=mod('independent_new',R/'proposed/human_workwear_fit.py')
manifest=json.loads((R/'MANIFEST.json').read_text());bad=[r['path'] for r in manifest['files'] if h(R/r['path'])!=r['sha256']]
pre=json.loads((R/'EXACT-96C4-SOURCE-PREIMAGES.json').read_text());preimages=[{'path':r['path'],'current_equals_preimage':h(pathlib.Path('/workspace/chicago')/r['path'])==r['sha256']} for r in pre]
recipe=json.loads((R/'baseline/worker_1835.json').read_text());proposed=json.loads((R/'proposed/worker_1835.json').read_text());bv=next(v for v in recipe['proof_variants'] if v['id']=='bardwell_otis_1835');pv=next(v for v in proposed['proof_variants'] if v['id']=='bardwell_otis_1835')
active_old={**recipe,'waistcoat_shoulder_pattern':bv['waistcoat_shoulder_pattern']};active_new={**proposed,'waistcoat_shoulder_pattern':pv['waistcoat_shoulder_pattern'],'shirt_sleeve_pattern':pv['shirt_sleeve_pattern']}
bp=pathlib.Path('/workspace/chicago-waistcoat/chicago/4d/assets/authored/humans/makehuman_hm08/prepared_adult_25.json');body=json.loads(bp.read_text());mesh=body['meshes'][0];bones={x['name']:x for x in body['skeleton']};scale=recipe.get('height_scale',1);height=max(p[1] for m in body['meshes'] for p in m['positions_m'])*scale
old=base.garment_shell(mesh,'shirt',recipe['shirt_offset_m'],active_old,bones,height,scale);default=new.garment_shell(mesh,'shirt',recipe['shirt_offset_m'],active_old,bones,height,scale);shirt=new.garment_shell(mesh,'shirt',recipe['shirt_offset_m'],active_new,bones,height,scale)
vestold=base.garment_shell(mesh,'waistcoat',recipe['waistcoat_offset_m'],active_old,bones,height,scale);vestnew=new.garment_shell(mesh,'waistcoat',recipe['waistcoat_offset_m'],active_new,bones,height,scale)
# Independent ray/triangle intersection at each authored cuff-face centroid.
def sub(a,b):return [a[i]-b[i] for i in range(3)]
def dot(a,b):return math.fsum(a[i]*b[i] for i in range(3))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def hit(o,d,face):
 a,b,c=[mesh['positions_m'][i] for i in face];e1=sub(b,a);e2=sub(c,a);v=cross(d,e2);det=dot(e1,v)
 if abs(det)<1e-14:return None
 t=sub(o,a);u=dot(t,v)/det
 if not -1e-9<=u<=1+1e-9:return None
 q=cross(t,e1);v=dot(d,q)/det
 if v< -1e-9 or u+v>1+1e-9:return None
 distance=dot(e2,q)/det
 return distance if distance>1e-9 else None
samples=[]
for fi,face in enumerate(shirt['triangles'][len(old['triangles']):],len(old['triangles'])):
 ps=[shirt['positions_m'][i] for i in face];p=[math.fsum(v[k] for v in ps)/3 for k in range(3)];side='l' if p[0]>0 else 'r';axis=bones['upperarm_'+side]['head_m'];o=[p[0],axis[1],axis[2]];r=math.hypot(p[1]-o[1],p[2]-o[2]);d=[0,(p[1]-o[1])/r,(p[2]-o[2])/r]
 candidates=[f for f in mesh['triangles'] if min(mesh['positions_m'][i][0] for i in f)<=p[0]<=max(mesh['positions_m'][i][0] for i in f)]
 hits=sorted(x for f in candidates if (x:=hit(o,d,f)) is not None)
 if not hits:raise ValueError('independent body ray missed')
 samples.append({'shirt_triangle':fi,'position_m':p,'radial_clearance_m':r-hits[0]})
# Count negative directed radial normals for cuff outer rows vs return: finite orientation check, not all-body acceptance.
orientation=[]
for row in range(3):
 ds=[]
 for cuff in shirt['receipt']['full_linen_sleeves_cuffs']['cuffs']:
  side=cuff['side'];ids=set(sum(cuff['new_ring_ids'],[])+cuff['shared_original_wrist_ids']);faces=[f for f in shirt['triangles'][len(old['triangles']):] if all(i in ids for i in f)][row*46:(row+1)*46]
  for f in faces:
   a,b,c=[shirt['positions_m'][i] for i in f];p=[(a[k]+b[k]+c[k])/3 for k in range(3)];axis=bones['upperarm_'+side]['head_m'];n=cross(sub(b,a),sub(c,a));ds.append(dot(n,[0,p[1]-axis[1],p[2]-axis[2]]))
 orientation.append({'ring_band':row,'positive':sum(x>0 for x in ds),'negative':sum(x<0 for x in ds)})
report={'status':'FINITE_STATIC_MATH_REVIEW_ONLY','elapsed_seconds':time.monotonic()-t0,'manifest_mismatches':bad,'current_app_preimages':preimages,'source_body_sha256':h(bp),'default_shirt_exact':old==default,'actual_inherited_shoulder_waistcoat_exact':vestold==vestnew,'inherited_vest_vertices':len(vestold['positions_m']),'inherited_vest_triangles':len(vestold['triangles']),'new_shirt_vertices':len(shirt['positions_m']),'new_shirt_triangles':len(shirt['triangles']),'new_cuff_centroid_body_ray_samples':len(samples),'minimum_centroid_radial_clearance_m':min(x['radial_clearance_m'] for x in samples),'minimum_clearance_witness':min(samples,key=lambda x:x['radial_clearance_m']),'negative_centroid_clearances':sum(x['radial_clearance_m']<0 for x in samples),'cuff_face_radial_orientation':orientation,'limitations':['centroids and vertices do not prove every triangle or animated fit','no Blender/build/export/browser/app writes','qualitative source and default/vesting exactness only; no visual/source acceptance']}
assert not bad and all(x['current_equals_preimage'] for x in preimages) and old==default and vestold==vestnew
(O/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
