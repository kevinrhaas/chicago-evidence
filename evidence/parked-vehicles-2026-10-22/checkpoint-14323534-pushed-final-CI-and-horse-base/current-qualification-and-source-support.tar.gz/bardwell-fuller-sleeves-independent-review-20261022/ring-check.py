from pathlib import Path
exec(Path(__file__).with_name('review.py').read_text().split('# Independent ray/triangle')[0])
def cross2(a,b):return a[0]*b[1]-a[1]*b[0]
rows=[]
for cuff in shirt['receipt']['full_linen_sleeves_cuffs']['cuffs']:
 for ri,ids in enumerate([cuff['shared_original_wrist_ids']]+cuff['new_ring_ids']):
  points=[shirt['positions_m'][i][1:] for i in ids];n=len(ids);crossings=[];steps=[]
  axis=bones['upperarm_'+cuff['side']]['head_m'];angles=[math.atan2(p[1]-axis[2],p[0]-axis[1]) for p in points]
  for i in range(n):steps.append(math.atan2(math.sin(angles[(i+1)%n]-angles[i]),math.cos(angles[(i+1)%n]-angles[i])))
  for i in range(n):
   a,b=points[i],points[(i+1)%n];v=[b[k]-a[k] for k in range(2)]
   for j in range(i+1,n):
    if j==i+1 or (i==0 and j==n-1):continue
    c,d=points[j],points[(j+1)%n];w=[d[k]-c[k] for k in range(2)];den=cross2(v,w)
    if abs(den)<1e-18:continue
    ca=[c[k]-a[k] for k in range(2)];t=cross2(ca,w)/den;u=cross2(ca,v)/den
    if 1e-9<t<1-1e-9 and 1e-9<u<1-1e-9:
     crossings.append({'edges':[[ids[i],ids[(i+1)%n]],[ids[j],ids[(j+1)%n]]],'edge_parameters':[t,u],'position_yz_m':[a[k]+t*v[k] for k in range(2)],'crossing_edge_lengths_m':[math.hypot(*v),math.hypot(*w)]})
  rows.append({'side':cuff['side'],'ring':ri,'positive_angle_steps':sum(x>0 for x in steps),'negative_angle_steps':sum(x<0 for x in steps),'angle_steps_rad':steps,'strict_self_crossings':crossings})
report={'status':'FINITE_RING_SELF_INTERSECTION_CHECK','rows':rows};(O/'RING-RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
