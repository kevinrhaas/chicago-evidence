"""Finite synthetic parser/source controls. Never final-head evidence or network/browser work."""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json,tempfile,sys
sys.dont_write_bytecode=True
P=Path(__file__).parent;OLD=Path('/workspace/shared/human-standing-1175-final-head-smokes-PREPARED-HELD-20261022');sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def need(ok,msg):
 if not ok:raise AssertionError(msg)
 checks.append(msg)
def refuse(label,operation):
 try:operation()
 except (ValueError,KeyError,FileNotFoundError):checks.append(label);return
 raise AssertionError('Synthetic negative accepted: '+label)
spec=importlib.util.spec_from_file_location('candidate_collector',P/'collect-GET-only.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
for name in ['smoke_cell','audit_job','audit_population_boot','checkout_sha','audit_human_jobs']:
 old=next(n for n in ast.parse((OLD/'collect-GET-only.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name);new=next(n for n in ast.parse((P/'collect-GET-only.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name);need(ast.dump(old,include_attributes=False)==ast.dump(new,include_attributes=False),'Strict original helper unchanged: '+name)
for source in ['dispatch-once.py','collect-GET-only.py','price-final-diff.py']:
 ast.parse((P/source).read_text());checks.append('Syntax '+source)
s=(P/'dispatch-once.py').read_text();old=(OLD/'dispatch-once.py').read_text();need(s[s.index(' need(a.output is not None'):]==old[old.index(' need(a.output is not None'):],'Entire dispatch/reconcile network/once-only/cap tail unchanged')
need("'expected_guarded_bake':guarded_bake" in (P/'price-final-diff.py').read_text(),'Pricing narrow guarded-bake metadata is explicit')
need("release.get('focused_published_desktop_mobile_PASS') is True" not in s,'No future focused PASS required to start independent CI')
need("release.get('focused_town_required_before_merge') is True" in s,'Dispatch explicitly retains focused-before-merge obligation')
with tempfile.TemporaryDirectory(prefix='synthetic-final1175-focused-',dir='/workspace/shared') as temp:
 d=Path(temp);head='1'*40;index='2'*64;baseline=json.loads((P/'CANONICAL-BARDWELL-BASELINE.json').read_text());canonical={'state':'ROOT_PINNED_FINAL_CANONICAL_INPUTS','final_head':head,'final_index_digest':index,**{k:baseline[k] for k in ['canonical_run_id','canonical_source_sha','artifact_zip_sha256','instance_sha256','web_lods']}};cp=d/'SYNTHETIC-CANONICAL.json';cp.write_text(json.dumps(canonical));pins={str(cp):sha(cp.read_bytes()),'synthetic-source-file':'3'*64};entries=[];rows={}
 for phase in ['desktop_visual','desktop_functional','mobile_full']:
  folder=d/phase;folder.mkdir();r={'identity':'actual_published_bardwell_final_head_split_v1','config':{'phase':phase,'viewport':'mobile' if phase=='mobile_full' else 'desktop','expectedHead':head,'expectedIndexDigest':index,'expectedCanonicalInputsSHA':sha(cp.read_bytes()),'maxMillis':540000,'released':True,'rootLaneClosed':True},'phase':phase,'head':head,'indexDigest':index,'pass':True,'closed':True,'sourceUnchanged':True,'inputPins':pins,'captures':[],'pageErrors':[],'httpErrors':[]}
  if phase!='desktop_functional':
   r['timing']={'samples':7}
   for k in range(4):
    f=folder/('SYNTHETIC-'+str(k)+'.png');f.write_bytes(('SYNTHETIC-IMAGE-CONTROL-'+str(k)).encode());r['captures'].append({'file':f.name,'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size})
  if phase=='desktop_visual':r['desktopVisualPass']=True
  else:r['loader']=[{'lod':k} for k in range(4)];r['far']={'state':{'lod':3}}
  if phase=='desktop_functional':r.update(desktopFunctionalPass=True,inheritedVisual={'receipt':entries[0]['path'],'sha256':entries[0]['sha256'],'head':head,'separateExecution':True})
  f=folder/'SYNTHETIC-RECEIPT.json';f.write_text(json.dumps(r));entries.append({'phase':phase,'path':str(f),'sha256':sha(f.read_bytes())});rows[phase]=r
 release={'focused_published_desktop_mobile_PASS':True,'focused_town_pngs_reviewed':True,'canonical_inputs_path':str(cp),'canonical_inputs_sha256':sha(cp.read_bytes()),'focused_town_receipts':entries}
 need(m.audit_focused_town(release,head,baseline)['PASS'],'SYNTHETIC complete three-phase parser accepted (not actual evidence)')
 for field in ['focused_published_desktop_mobile_PASS','focused_town_pngs_reviewed']:
  bad=copy.deepcopy(release);bad[field]=False;refuse('Actual '+field+' required',lambda b=bad:m.audit_focused_town(b,head,baseline))
 bad=copy.deepcopy(release);bad['focused_town_receipts']=bad['focused_town_receipts'][:2];refuse('Missing mobile or functional coverage refused',lambda:m.audit_focused_town(bad,head,baseline))
 refuse('Wrong final head refused',lambda:m.audit_focused_town(release,'4'*40,baseline))
 bad=copy.deepcopy(release);bad['canonical_inputs_sha256']='0'*64;refuse('Wrong canonical file pin refused',lambda:m.audit_focused_town(bad,head,baseline))
 badbase=copy.deepcopy(baseline);badbase['canonical_run_id']=39712579846;refuse('Historical canonical baseline refused',lambda:m.audit_focused_town(release,head,badbase))
 def modified(phase,mutate):
  bad=copy.deepcopy(release);entry=next(e for e in bad['focused_town_receipts'] if e['phase']==phase);path=Path(entry['path']);before=path.read_bytes();row=json.loads(before);mutate(row);path.write_text(json.dumps(row));entry['sha256']=sha(path.read_bytes())
  try:return m.audit_focused_town(bad,head,baseline)
  finally:path.write_bytes(before)
 for label,phase,fn in [('wrong identity','desktop_visual',lambda r:r.update(identity='historical_other_caller')),('wrong phase viewport','desktop_visual',lambda r:r['config'].update(viewport='mobile')),('widened local cap','mobile_full',lambda r:r['config'].update(maxMillis=600000)),('deadline failure','desktop_visual',lambda r:r.update(deadlineReached=True)),('missing card image','mobile_full',lambda r:r['captures'].pop()),('incomplete timings','desktop_visual',lambda r:r['timing'].update(samples=6)),('missing loader','desktop_functional',lambda r:r['loader'].pop()),('bad far LOD','mobile_full',lambda r:r['far']['state'].update(lod=2)),('old inherited visual','desktop_functional',lambda r:r['inheritedVisual'].update(sha256='0'*64)),('mismatched sourcepins','mobile_full',lambda r:r['inputPins'].update(other='5'*64)),('mismatched index','desktop_visual',lambda r:r.update(indexDigest='0'*64)),('source changed','mobile_full',lambda r:r.update(sourceUnchanged=False))]:
  refuse('Synthetic '+label+' refused',lambda ph=phase,f=fn:modified(ph,f))
 pic=d/'desktop_visual/SYNTHETIC-0.png';orig=pic.read_bytes();pic.write_bytes(b'CHANGED');refuse('Changed actual image bytes refused',lambda:m.audit_focused_town(release,head,baseline));pic.write_bytes(orig)
report={'status':'OFFLINE_SYNTHETIC_AND_SOURCE_CONTROLS_PASS_NOT_FINAL_QUALIFICATION','PASS_count':len(checks),'checks':checks,'synthetic_control_inputs_explicit':True,'final_head':None,'POSTs':0,'GETs':0,'browser_started':False,'app_writes':False};(P/'SEQUENCING-OFFLINE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'PASS':len(checks),'POSTs':0,'GETs':0,'final_head':None}))
