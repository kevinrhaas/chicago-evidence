"""Finite actual saved guard audit and explicit negative controls; no network/build/browser."""
from pathlib import Path
import ast,copy,json,hashlib,sys,importlib.util
sys.dont_write_bytecode=True
from guarded_bake import audit_guarded_bake_jobs,audit_guarded_bake_log,BAKE
P=Path(__file__).parent;D=Path('/workspace/shared/final14323534-bake-guard-readonly-20261022');OLD=Path('/workspace/shared/human1175-final96c4-parallel18-PREPARED-HELD-20261022');head='14323534e9493a3630ac9dcbe1b8daa1db3ae454';sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def check(ok,label):
 if not ok:raise AssertionError(label)
 checks.append(label)
def refuse(label,fn):
 try:fn()
 except (ValueError,KeyError):checks.append(label);return
 raise AssertionError('Accepted '+label)
spec=importlib.util.spec_from_file_location('guarded_collector',P/'collect-GET-only.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
run=json.loads((D/'bake-run.stdout.json').read_bytes());jobsdoc=json.loads((D/'bake-attempt1-jobs.stdout.json').read_bytes());jobs=jobsdoc['jobs'];text=(D/'warranted-job-log.stdout').read_text();check(run['id']==39743057474 and run['head_sha']==head and run['event']=='push' and run['path']==BAKE and run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1 and jobsdoc['total_count']==len(jobs)==6,'Actual saved run and complete six-job inventory')
job,proof=audit_guarded_bake_jobs(jobs,run,head);proof.update(audit_guarded_bake_log(text));proof['actual_checkout_sha']=m.checkout_sha(text,head);check(proof['PASS'] and proof['actual_checkout_sha']==head,'Actual guard jobs/log/checkout PASS')
for label,fn in [('actual bake success',lambda j:next(v for v in j if v['name']=='bake').update(conclusion='success')),('failed q',lambda j:next(v for v in j if v['name']=='warranted')['steps'][3].update(conclusion='failure')),('unexpected live execution',lambda j:next(v for v in j if v['name']=='warranted')['steps'][4].update(conclusion='success')),('missing dependent job',lambda j:j.pop()),('extra job',lambda j:j.append(copy.deepcopy(j[0]))),('wrong step number',lambda j:next(v for v in j if v['name']=='warranted')['steps'][4].update(number=6)),('wrong head',lambda j:j[0].update(head_sha='0'*40))]:
 j=copy.deepcopy(jobs);fn(j);refuse(label,lambda j=j:audit_guarded_bake_jobs(j,run,head))
notice='##[notice]SKIPPING — nothing this branch owns under generators/, tools/bake.sh'
refuse('echo-only/missing emitted notice',lambda:audit_guarded_bake_log(text.replace(notice,'NOT-EMITTED')))
refuse('other skip reason',lambda:audit_guarded_bake_log(text.replace(notice,'##[notice]SKIPPING — outputs current')))
refuse('duplicate emitted notice',lambda:audit_guarded_bake_log(text+'\n'+notice))
refuse('wrong pushed ref',lambda:audit_guarded_bake_log(text.replace('REF: steward/1835-workwear-repair-20261021','REF: dev')))
for name in ['smoke_cell','audit_job','checkout_sha','audit_human_jobs','audit_population_boot','audit_focused_town']:
 a=next(n for n in ast.parse((OLD/'collect-GET-only.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name);b=next(n for n in ast.parse((P/'collect-GET-only.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name);check(ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False),'Original strict helper exact: '+name)
check((P/'dispatch-once.py').read_bytes()==(OLD/'dispatch-once.py').read_bytes(),'Dispatcher complete bytes unchanged')
price=json.loads((P/'PRICING-WITH-GUARDED-BAKE.json').read_bytes());check(price['expected_normal_contract'] is True and price['expected_guarded_bake']['source_owned'] is False and len(price['predicted_normal_runs'])==4,'Expected guarded run retained in truthful pricing')
proof.update(scope='Actual saved source-ownership guard only; does not replace18smokes/normal4/localtown/finalmerge proof',run_id=run['id'],head=head,guard_run_json_sha256=sha((D/'bake-run.stdout.json').read_bytes()),jobs_json_sha256=sha((D/'bake-attempt1-jobs.stdout.json').read_bytes()),job_log_sha256=sha(text.encode()),check_run_url=job['check_run_url']);(P/'ACTUAL-GUARDED-BAKE-PASS.json').write_text(json.dumps(proof,indent=2)+'\n')
(P/'GUARD-OFFLINE-CONTROLS.json').write_text(json.dumps({'status':'ACTUAL_SAVED_GUARD_PLUS_NEGATIVE_SOURCE_CONTROLS_PASS','PASS_count':len(checks),'checks':checks,'POSTs':0,'GETs':0,'browser_started':False,'not_full_CI_qualification':True},indent=2)+'\n');print(json.dumps({'PASS':len(checks),'actual_guard_run':run['id'],'POSTs':0,'GETs':0}))
