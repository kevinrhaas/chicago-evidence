#!/usr/bin/env python3
"""Read-only exact-commit push/PR trigger pricing; no workflow invocation."""
import argparse,hashlib,json,os,pathlib,re,subprocess,yaml
ROOT=pathlib.Path('/workspace/chicago');BRANCH='steward/1835-workwear-repair-20261021'
def git(*a):return subprocess.check_output(['git','-C',str(ROOT),*a],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
def sha(b):return hashlib.sha256(b).hexdigest()
def match(value,pattern):
 # Current workflow filters use literals,* or **. Unknown minimatch syntax stops.
 if any(c in pattern for c in '[]+?{}\\'):raise ValueError('Unsupported workflow glob; inspect '+pattern)
 return bool(re.fullmatch(re.escape(pattern).replace(r'\*\*','.*').replace(r'\*','[^/]*'),value))
def accepts(value,patterns):
 selected=False
 for p in patterns:
  negative=p.startswith('!');p=p[1:] if negative else p
  if match(value,p):selected=not negative
 return selected
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--sha',required=True);p.add_argument('--push-base',required=True);p.add_argument('--pr-base',required=True);a=p.parse_args()
assert re.fullmatch('[0-9a-f]{40}',a.sha)
head=git('rev-parse',a.sha).decode().strip();pushbase=git('rev-parse',a.push_base).decode().strip();prbase=git('rev-parse',a.pr_base).decode().strip();mb=git('merge-base',prbase,head).decode().strip()
pushfiles=git('diff','--name-only',pushbase,head).decode().splitlines();prfiles=git('diff','--name-only',mb,head).decode().splitlines();paths=git('ls-tree','-r','--name-only',head,'.github/workflows').decode().splitlines();workflows=[];predicted=[]
for path in paths:
 if not path.endswith(('.yml','.yaml')):continue
 raw=git('show',head+':'+path);d=yaml.load(raw,Loader=yaml.BaseLoader);events=d.get('on',{});assert isinstance(events,dict),'Inspect non-map workflow events: '+path
 for event,files,branch in [('push',pushfiles,BRANCH),('pull_request',prfiles,'dev')]:
  if event not in events:continue
  rule=events[event] or {};assert isinstance(rule,dict),'Inspect event rule: '+path
  ok=True
  if 'branches' in rule:ok=ok and accepts(branch,rule['branches'])
  if 'branches-ignore' in rule:ok=ok and not accepts(branch,rule['branches-ignore'])
  matched=files
  if 'paths' in rule:matched=[f for f in files if accepts(f,rule['paths'])];ok=ok and bool(matched)
  if 'paths-ignore' in rule:matched=[f for f in files if not accepts(f,rule['paths-ignore'])];ok=ok and bool(matched)
  item={'workflow_path':path,'workflow_sha256':sha(raw),'event':event,'branch_filter_value':branch,'rule':rule,'matches':matched,'predicted_trigger':bool(ok)};workflows.append(item)
  if ok:predicted.append({'path':path,'event':event})
required=[{'path':'.github/workflows/chicago-4d-check.yml','event':'pull_request'},{'path':'.github/workflows/chicago-4d-pr-stuck.yml','event':'push'},{'path':'.github/workflows/chicago-4d-humans.yml','event':'pull_request'}]
moving={'path':'.github/workflows/chicago-4d-moving-frames.yml','event':'pull_request'}
actual={tuple(sorted(x.items())) for x in predicted};minimum={tuple(sorted(x.items())) for x in required};allowed=minimum|{tuple(sorted(moving.items()))}
# A merge from DEV may match push paths while this branch owns NONE of them.
# Keep that run visible and require its real successful ownership guard/skipped jobs.
guarded={'path':'.github/workflows/chicago-4d-bake.yml','event':'push'}
guarded_key=tuple(sorted(guarded.items()))
owned_bake_paths=[f for f in prfiles if accepts(f,['chicago/4d/generators/**','chicago/4d/tools/bake.sh','.github/workflows/chicago-4d-bake.yml'])]
guarded_bake=None
if guarded_key in actual and BRANCH!='dev' and not owned_bake_paths and sha(git('show',head+':.github/workflows/chicago-4d-bake.yml'))=='cf7e706a594e12c0cb2628c6acb4826b35faf2bb8fd4302702a5b0ea0e62d145':
    allowed.add(guarded_key)
    guarded_bake={**guarded,'source_owned':False,'source_owned_trigger_paths':owned_bake_paths,'workflow_sha256':'cf7e706a594e12c0cb2628c6acb4826b35faf2bb8fd4302702a5b0ea0e62d145','expected_guard_output':'bake=0','actual_guard_qualification':'REQUIRED_SEPARATELY; expected trigger is not actual skip PASS','required_actual_proof':'Successful warranted/q source-ownership notice, skipped live step and all five downstream jobs skipped; never exclude an actual build'}
normal_ok=minimum<=actual<=allowed
moving_automatic=tuple(sorted(moving.items())) in actual
report={'repository':'kevinrhaas/chicago','branch':BRANCH,'sha':head,'tree':git('rev-parse',head+'^{tree}').decode().strip(),'push_base':pushbase,'pr_base':prbase,'pr_merge_base':mb,'push_diff_paths':pushfiles,'pr_diff_paths':prfiles,'workflow_trigger_pricing':workflows,'predicted_normal_runs':predicted,'expected_normal_contract':normal_ok,'expected_guarded_bake':guarded_bake,'moving_automatic':moving_automatic,'moving_required_event':'pull_request' if moving_automatic else 'workflow_dispatch','selected_manual_requests':18,'selected_cells':[[v,s] for v in ['desktop','mobile'] for s in ['1-2','3-4','5','6-7','8','9-12','13','14','15']],'manual_workflow':'.github/workflows/chicago-4d-smoke.yml','smoke_job_cap_minutes':150,'selected_runner_cap_minutes_upper_bound':2700,'price_scope':'Final-source push/PR trigger and dispatch-cap pricing, not runtime prediction. Existing nightly grid is used through 18 ordinary smoke dispatches. Human PR fixture proof is required, with teamster-studies explicitly skipped. A single root-owned moving dispatch is needed only if not auto-triggered. No canonical human rebuild, bake, unfiltered duplicate or production action.','read_only':True,'POSTs':0}
print(json.dumps(report,indent=2))
