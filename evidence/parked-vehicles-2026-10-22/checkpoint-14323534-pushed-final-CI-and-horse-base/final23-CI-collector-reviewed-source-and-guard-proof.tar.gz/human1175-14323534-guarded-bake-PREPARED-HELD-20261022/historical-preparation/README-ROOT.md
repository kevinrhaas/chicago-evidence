# PR1175 new standing-head smoke plan — held

Prepare-only, outside app. **Final SHA/tree/base/merge remain null; both releases are false.** No POST/GET/network request, observer, browser, server, Git/index/mirror/ticket mutation or ref movement occurred. The canonical run39712579846/34cf artifact remains the imported asset baseline; it does not qualify the new standing population. Historical parked e694 smoke runs are parser-control evidence only, never substituted for new-head jobs.

This packet minimally adapts the existing exact18 dispatcher/GET collector and trigger-pricing scripts. Originals are under reused-original/. It pins current actual workflow bytes, including smoke `00ae307a…` and humans `62048ede…`; the complete hashes and workflow preimages are included. New collector uses the original strict `smoke_cell` and `audit_job` ASTs unchanged, then adds actual checkout/base/workflow binding, the ordinary positive population bootstrap proof, and normal human-fixture/dependent-skip handling. OFFLINE-CONTROLS.json records27 finite source/parser controls, including actual old logs as explicitly historical positive controls and old zero-population logs as a negative control. No final-source dry plan/pricing was invented before the commit exists.

## Scope and cost

Exactly18 ordinary `chicago-4d-smoke.yml` workflow_dispatch requests: desktop/mobile × `1-2,3-4,5,6-7,8,9-12,13,14,15`. This is the **current actual nightly18-cell grid**, carried through the existing ordinary manual workflow's viewport/stage inputs. Each manual smoke job has a150min cap; the nightly matrix has40min per leg. These are distinct workflow/job caps; neither is changed.18×150=2700 runner-minutes is a cap sum, not a predicted bill/runtime. No unfiltered duplicate. Existing smoke_budget output and final diff pricing belong to root's final review.

Required fresh normal proofs on the exact final source are gate (pull_request), report (push) and humans (pull_request), plus moving-frames. **Moving is path-filtered:** final diff pricing decides whether its event is pull_request automatically. If not, root may authorize exactly one moving-frames workflow_dispatch after GET proves no applicable automatic run; never send both. The source-only helper/GLB/data/smoke changes alone do not imply moving auto-trigger. No canonical resident master dispatch, content bake, deployment, promotion, rerun or cancellation is part of this plan.

Normal humans must have its fixture job and all actual required steps succeed; its `teamster-studies` job must be explicitly skipped under pull_request. A skipped/absent dependent job while a run is pending is not inspected as terminal failure. The collector only requires its terminal schema after run completion. This proves the normal fixture/runtime regression check, not newly rebuilt canonical resident masters or photographic quality.

## Root final commit and one dispatch

After final source derivation/full preflight, commit and push, root pins exact final source head/tree, actual DEV base and PR merge commit (merge parents must be base then head). The human ref must stay fixed. The V2 published-town caller must have passed desktop/mobile at the final committed head, its normal images must be reviewed, and the owned browser/server must be CLOSED before the root smoke release. Keep full tailoring/photo/T1789 open.

Run the existing source-trigger pricing against actual immutable SHAs (read-only):

```sh
python /workspace/shared/human-standing-1175-final-head-smokes-PREPARED-HELD-20261022/price-final-diff.py --sha FINAL40SHA --push-base PREVIOUS_REMOTE40SHA --pr-base ACTUAL_DEV_BASE40SHA > /workspace/shared/human1175-FINAL40SHA-final-diff-pricing.json
python /workspace/shared/human-standing-1175-final-head-smokes-PREPARED-HELD-20261022/dispatch-once.py --sha FINAL40SHA --pr 1175 > /workspace/shared/human1175-FINAL40SHA-dry-plan.json
```

Pricing must report expected_normal_contract:true; unexpected extra triggers require inspection, not silent exclusion. `moving_required_event` is the exact event root later pins. The dry plan reads the actual final commit/tree/source inputs and all four canonical web GLBs, checking the reviewed standing instance and same-run web hashes. It does no network request or POST.

Root copies ROOT-DISPATCH-HELD.json to a new immutable activation, fills released:true / allow_dispatch:true / status ROOT_RELEASED_HUMAN1175_EXACT_HEAD_SMOKE_DISPATCH, exact sha/tree/base_sha/merge_sha, dispatcher hash, final pricing path/hash and actual committed_pushed/full_preflight_PASS/focused_published_desktop_mobile_PASS. Then root alone executes once:

```sh
python /workspace/shared/human-standing-1175-final-head-smokes-PREPARED-HELD-20261022/dispatch-once.py --sha FINAL40SHA --pr 1175 --activation /workspace/shared/ROOT-FINAL1175-DISPATCH.json --execute --output /workspace/shared/human1175-FINAL40SHA-dispatch-once
```

The existing dispatcher has a180s finite operation bound, durable POST-intent receipts, a persistent exact-head once-only POST lock, no POST retry, exact clean HEAD including staged/unstaged checks, remote source/tree/PR-base/merge checks and exactly18 accepted requests. Any ambiguous POST/discovery stops. Preserve the receipt; never execute again. If all18 POSTs succeeded but run discovery was incomplete, use the existing GET-only reconciliation operation with a new output:

```sh
python /workspace/shared/human-standing-1175-final-head-smokes-PREPARED-HELD-20261022/dispatch-once.py --reconcile /workspace/shared/human1175-FINAL40SHA-dispatch-once/receipt.json --output /workspace/shared/human1175-FINAL40SHA-GET-reconciliation
```

Reconciliation cannot fix an unaccepted/ambiguous POST and never dispatches anything. Root inspects any failure.

## Root pins discovery, then one delegated GET owner

After actual automatic/manual normal discovery, root copies ROOT-OBSERVE-HELD.json to a new immutable activation. Fill released:true / allow_GET_collection:true / status ROOT_RELEASED_HUMAN1175_FINAL_GET_COLLECTION, source head/tree/base/merge, collector hash, complete dispatcher/reconciliation receipt path/hash and final pricing path/hash. Normal_runs must contain exactly four `{id,path,event}` entries for the actual gate/moving/report/humans run IDs; moving event must match pricing. Root must GET the actual runs before pinning IDs. Do not guess normal run IDs from ordering or convert a missing trigger into a false failure. Dispatch receipt selects the18 smoke run IDs; actual step logs bind viewport/stage, not POST order.

Then release one observer command only:

```sh
python /workspace/shared/human-standing-1175-final-head-smokes-PREPARED-HELD-20261022/collect-GET-only.py --release /workspace/shared/ROOT-FINAL1175-GET-RELEASE.json --output /workspace/shared/human1175-FINAL40SHA-GET-owner1 > /workspace/shared/human1175-FINAL40SHA-GET-owner1.log 2>&1
```

No observer starts from the false held release. The collector has a single explicit `gh api --method GET` transport,61s polling cadence and150min total finite observation bound. Each GET subprocess is capped45s; timeout partial output/stderr is saved. No single sleep exceeds30s. The cap never cancels remote CI. It records owner PID/output/deadline, append-only GET attempts/outputs, atomic latest state, transitions, audited jobs and terminal state. An exact-head lock and live-process check prevent a duplicate observer. It never removes or steals an ownership lock automatically. On interruption, root must prove the prior PID absent and preserve its evidence before any separately reviewed recovery owner.

## Strict evidence and terminal behavior

- Actual remote commit tree, exact final source-byte/Git-blob pins and current immutable workflow bytes/IDs must match. PR workflows additionally match exact workflow bytes on the pinned merge checkout. Final source tree binds the imported GLBs and registry corrections; focused town receipts check actual published bytes.
- Every selected run must match repository/branch/source SHA/path/event/workflow ID/attempt1. PR run metadata must bind PR1175/head/base; current PR source/base/merge and branch ref are checked throughout. Checkout logs must show exactly the source SHA for push/dispatch, or the independently parent-checked PR merge SHA for pull_request. Unknown/duplicate exact-head workflows stop qualification rather than being ignored.
- Each smoke step env and runtime filter markers must bind one unique exact viewport/stage and terminal SMOKE PASS. Every log must also contain the actual new positive ordinary eligible-human bootstrap and scene-year request-gate PASS. Old no-person logs cannot qualify the new standing scene. Gate/moving/report/humans job/step guards remain strict; final check-run URLs must bind to those actual job successes.
- At an actual failed run or terminal job/step/log qualification problem, preserve attempt1 jobs, raw individual logs, artifact metadata and run-attempt logZIP as inert bytes, then STOP. Smoke/normal workflows currently upload no data artifacts; if a nonempty artifact list appears, its exact metadata is saved for root's read-only retrieval decision. No artifact code is run or extracted. Retrieval errors remain explicit beside all available failure evidence. No rerun/cancel/source repair is performed by the collector.
- Success requires all18 unique log-bound cells and all4 normal run proofs, final checks/status snapshots and unchanged PR/source/base. It grants only exact-head CI qualification for root's fresh merge review. It never merges, closes tickets or claims photographic/full population acceptance.

Root may need escalated execution for gh network access in this managed environment. That does not authorize a new dispatch; released immutable activations remain mandatory.
