#!/usr/bin/env python3
"""Finite source/log-parser controls only; no network, browser or Git mutation."""
import sys;sys.dont_write_bytecode=True
import ast,copy,hashlib,importlib.util,json,pathlib,subprocess
D=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('held_collector',D/'collect-GET-only.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
checks=[]
def check(name,cond):
 if not cond:raise AssertionError(name)
 checks.append({'name':name,'PASS':True})
def refuses(name,fn):
 try:fn()
 except (ValueError,AssertionError):check(name,True);return
 raise AssertionError('Accepted negative control: '+name)
for p in D.glob('*.py'):ast.parse(p.read_text());check('syntax '+p.name,True)
oldast=ast.parse((D/'reused-original/observe-GET-only.py').read_text());newast=ast.parse((D/'collect-GET-only.py').read_text())
for name in ['smoke_cell','audit_job']:
 old=next(n for n in oldast.body if isinstance(n,ast.FunctionDef) and n.name==name);new=next(n for n in newast.body if isinstance(n,ast.FunctionDef) and n.name==name)
 check('original strict helper AST unchanged: '+name,ast.dump(old,include_attributes=False)==ast.dump(new,include_attributes=False))
# Actual original successful job log: positive parser control only, never new-head qualification.
fixtures=D/'offline-fixtures';fixtures.mkdir(exist_ok=True)
folder=pathlib.Path('/workspace/shared/parked-covered-2981-e694849a2c516a9862a2564c5ff86d97406e09ab-HISTORICAL-SMOKES-TERMINAL-CAPSULE/historical-collector')
selected=None
for p in sorted(folder.glob('*job-*-log-*.stdout')):
 try:cell=mod.smoke_cell(p.read_text());selected=p;break
 except ValueError:continue
assert selected
log=selected.read_text();(fixtures/'actual-historical-success-job.log').write_bytes(selected.read_bytes())
check('actual historical successful smoke cell parser',mod.smoke_cell(log)==cell)
refuses('mismatched runtime viewport refused',lambda:mod.smoke_cell(log.replace('SMOKE_VIEWPORT: '+cell[0],'SMOKE_VIEWPORT: '+('mobile' if cell[0]=='desktop' else 'desktop'))))
refuses('missing actual terminal PASS refused',lambda:mod.smoke_cell(log.replace('SMOKE PASS','SMOKE OMITTED')))
refuses('old zero-population logs cannot qualify new standing population',lambda:mod.audit_population_boot(log,cell[0]))
label='desktop 1280x800' if cell[0]=='desktop' else 'mobile 390x780'
synthetic='\n'.join('  pass  '+label+': '+s for s in ["the human layer mounts exactly the scene's eligible records",'human requests obey the exact scene-year gate'])
check('synthetic current positive population parser control',mod.audit_population_boot(synthetic,cell[0])['ordinary_eligible_human_boot_PASS'])
refuses('duplicate population PASS line refused',lambda:mod.audit_population_boot(synthetic+'\n'+synthetic,cell[0]))
oldhead='e694849a2c516a9862a2564c5ff86d97406e09ab'
check('actual job checkout SHA binding',mod.checkout_sha(log,oldhead)==oldhead)
refuses('wrong checkout SHA refused',lambda:mod.checkout_sha(log,'b'*40))
refuses('ambiguous duplicated checkout refused',lambda:mod.checkout_sha(log+'\n'+log,oldhead))
# Actual fixture humans steps reused only to verify new schema logic. The normal
# skipped dependent job is an explicitly synthetic schema control, not CI proof.
jobs=json.loads(pathlib.Path('/workspace/shared/human-next-head-actual-review-39712579846-34cf462e/qualification/jobs.json').read_text())['jobs']
human=next(j for j in jobs if j['name']=='humans');head=human['head_sha'];run={'id':human['run_id']};skip={'id':987654321,'name':'teamster-studies','run_id':run['id'],'run_attempt':1,'head_sha':head,'status':'completed','conclusion':'skipped','steps':[]}
check('actual fixture steps + synthetic expected PR skip accepted',mod.audit_human_jobs([human,skip],run,head)[1]['PASS'])
bad=copy.deepcopy(human);next(s for s in bad['steps'] if s['name']=='Rebuild the fixture and require the committed bytes')['conclusion']='skipped'
refuses('missing real fixture verification refused',lambda:mod.audit_human_jobs([bad,skip],run,head))
refuses('missing normal dependent job at terminal refused',lambda:mod.audit_human_jobs([human],run,head))
wrong=copy.deepcopy(skip);wrong['conclusion']='success';refuses('unexpected canonical build under normal PR refused',lambda:mod.audit_human_jobs([human,wrong],run,head))
# Held invocation exits before any output/lock/network work.
output=D/'MUST-NOT-EXIST-HELD-CONTROL'
assert not output.exists()
proc=subprocess.run([sys.executable,str(D/'collect-GET-only.py'),'--release',str(D/'ROOT-OBSERVE-HELD.json'),'--output',str(output)],capture_output=True,text=True)
check('HELD invocation refuses before output/ownership/network',proc.returncode!=0 and not output.exists() and 'HELD: root immutable GET collection release required' in proc.stderr)
# The collector has exactly one gh transport; its method is a literal GET.
source=(D/'collect-GET-only.py').read_text();check('collector sole transport is explicit GET',source.count("['gh','api','--method','GET'")==1 and "'POST'" not in source)
check('fixed interval and finite cap enforced',"release.get('poll_seconds')==61 and release.get('max_minutes')==150" in source and 'deadline=started+150*60' in source)
check('all18parts exactly once each viewport',all(sorted(n for v,s in [(v,s) for v in ['desktop','mobile'] for s in mod.RANGES] if v==vp for n in range(int(s.split('-')[0]),int(s.split('-')[-1])+1))==list(range(1,16)) for vp in ['desktop','mobile']))
import yaml
manual=yaml.load((D/'workflow-preimages/chicago-4d-smoke.yml').read_text(),Loader=yaml.BaseLoader)
nightly=yaml.load((D/'workflow-preimages/chicago-4d-bake.yml').read_text(),Loader=yaml.BaseLoader)
check('ordinary workflow has exact viewport/stage dispatch inputs',set(manual['on']['workflow_dispatch']['inputs'])=={'viewport','stage'})
check('ordinary smoke cap stays150min',manual['jobs']['smoke']['timeout-minutes']=='150')
check('actual nightly grid matches18 exactcells',nightly['jobs']['smoke']['strategy']['matrix']=={'viewport':['mobile','desktop'],'stage':mod.RANGES})
check('actual nightly cap stays40min',nightly['jobs']['smoke']['timeout-minutes']=='40')
report={'status':'OFFLINE_PREPARATION_PASS_NOT_CI_QUALIFICATION','checks':checks,'actual_log_control':{'source':str(selected),'sha256':hashlib.sha256(selected.read_bytes()).hexdigest(),'cell':cell,'historical_head':oldhead,'new_head_qualification':False},'synthetic_controls_explicit':True,'POSTs':0,'GETs':0,'browser_started':False,'source_sha':None,'source_tree':None}
(D/'OFFLINE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'PASS':len(checks),'network_requests':0,'source_head':None}))
