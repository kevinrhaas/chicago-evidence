# Root operational sequence — future commands only

1. Finish exact imported96c4 assets/registry/provenance and derived-source conflict resolution. Close actual full preflight PASS on the frozen source; commit, postcommit publish and normal check_published, push PR1175. Record actual40char FINAL_HEAD, TREE, raw index SHA256, previous push source PUSH_BASE, actual DEV_BASE and PR_MERGE (parents DEV_BASE then FINAL_HEAD). Keep that source fixed. Reconfirm the baseline standing-instance/four web hashes from the committed source and published bytes. Re-pin any actual changed workflow identity; current six workflow files still match the prepared hashes, but no future equality is assumed.

2. Immediately price exact final source and obtain a dry18 plan, using this reviewed copy (or one immutable final activation copy):

    python3 -B <CI_PACKET>/price-final-diff.py --sha FINAL_HEAD --push-base PUSH_BASE --pr-base DEV_BASE > <fresh-final-pricing.json>
    python3 -B <CI_PACKET>/dispatch-once.py --sha FINAL_HEAD --pr 1175 > <fresh-final18-plan.json>

   Require expected_normal_contract:true, exact18 cells and actual source/tree. Pin both JSONs and current code/baseline hashes. Root fills a NEW dispatch activation from ROOT-DISPATCH-HELD.json: actual head/tree/base/merge, committed_pushed/full_preflight_PASS true only after evidence; focused flag remains its ACTUAL current false until town passes; focused_town_required_before_merge true. Then execute ONCE:

    python3 -B <CI_PACKET>/dispatch-once.py --sha FINAL_HEAD --pr 1175 --activation <ROOT-FINAL-DISPATCH.json> --execute --output <fresh-final18-dispatch>

   If all18 requests were accepted but discovery incomplete, use only `--reconcile <receipt.json> --output <fresh-GET-reconciliation>`; never replay POST. Normal gate(PR), report(push), humans(PR) must be discovered from real run metadata. Pricing determines moving(PR); if not triggered, root first GETs absence and releases exactly one ordinary `gh workflow run chicago-4d-moving-frames.yml --repo kevinrhaas/chicago --ref steward/1835-workwear-repair-20261021`. No canonical rebuild/bake/deploy/unfiltered duplicate.

3. While remote CI runs, copy `/workspace/shared/human-standing-bardwell-FINAL-HEAD-SPLIT-PREPARED-HELD-20261022` ONCE to a fresh town execution directory. Fill its CANONICAL-EXPECTED-INPUTS-HELD.json with ROOT_PINNED_FINAL_CANONICAL_INPUTS, actual final HEAD/index, run39736567239/source96c4/artifact9ca4 and exact final instance/new four web SHA+bytes. Verify final provenance, then hash JSON. Fill each NEW phase release with actual head/index/canonicalSHA/fresh output, maxMillis540000 and real free-lane release. Use ONE browser/phase at a time:

    PW_EXECUTABLE=/usr/bin/chromium node <TOWN_PACKET>/capture_town.cjs <ROOT-desktop_visual.json>
    PW_EXECUTABLE=/usr/bin/chromium node <TOWN_PACKET>/capture_town.cjs <ROOT-desktop_functional.json>
    PW_EXECUTABLE=/usr/bin/chromium node <TOWN_PACKET>/capture_town.cjs <ROOT-mobile_full.json>

   Functional release additionally pins the NEW successful visual receipt path+SHA. Inspect actual final-head PNGs. Require each phase pass/closed/sourceUnchanged, expected coverage and no deadline. Keep separate executions separate; old ad813 partial and coveredmobile continuation remain historical, not new-head PASS. Local town and remote CI are independent proof; neither substitutes for the other.

4. After the three actual town phases pass and PNGs are reviewed, discover/pin real18 runIDs and four normal runIDs/events, actual current PR base/merge, complete dispatch/reconciliation receipt SHA and final pricing SHA. Fill a NEW observation activation: focused_published_desktop_mobile_PASS=true and focused_town_pngs_reviewed=true ONLY now; canonical_inputs_path/SHA and all three phase receipt paths/SHAs; current collector/baseline hashes; other existing exact identities. Start ONE observer:

    python3 -B <CI_PACKET>/collect-GET-only.py --release <ROOT-FINAL-GET.json> --output <fresh-final-GET-owner>

   It rejects incomplete local proof BEFORE network and rechecks it before remote qualification. It retains all strict actual18+4 CI logs/job/check-run bindings and final unchanged source/base checks. No cancellation/rerun/automatic ownership stealing.

5. Root verifies terminal EXACT_FINAL_HEAD_CI_QUALIFIED + qualification_pass + ready_for_root_fresh_merge_review, actual local receipts/PNG review, current PR1175 head still FINAL_HEAD/base still DEV_BASE and no active incompatible lap. Use the ordinary repo merge-ready review scoped to1175 (first MERGE_ONLY=1175 MERGE_DRY_RUN=1, then ordinary root-authorized merge only while GitHub reports clean). It pins the current head in its squash merge request. Any head/base/source change means re-review/requalification, not transplanting old PASS. Record actual DEV merge SHA and retain handover/remaining photo/occupied work.

V13 carriage's oldad813 single-side caller remains HELD. After final commit/publish/root browser release, copy/repin it to current HEAD/index/ALL current source/published inputs (including changed DEV building assets), retain every original guard and actual V13source-specific proof. No stalehead town/carriage preview qualifies final integration.
