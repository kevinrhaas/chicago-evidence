const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const s=fs.readFileSync(__dirname+'/browser_review.cjs','utf8'),ctx=vm.createContext({});vm.runInContext(s.slice(s.indexOf('  function timedReadiness('),s.indexOf('  async function waitForBody(')),ctx);
const ready=(at,lod=0,pending=false)=>({at_ms:at,body:true,lod,pending});
const event=(at,lod=0,pending=false,name='pending_fulfilled')=>({name,state:ready(at,lod,pending)});
const begin=149682,deadline=239682,latePoll=248466.3,checks=[];
const check=(name,events,current,polledAt,want)=>{const d=ctx.timedReadiness(events,0,begin,deadline,polledAt,current);assert.equal(d.accepted,want,name);checks.push({name,accepted:d.accepted,readiness:JSON.parse(JSON.stringify(d))});return d;};
check('actual observed failure timeline: late poll after timely exact observation', [event(233750.7)],ready(latePoll),latePoll,true);
check('ordinary early polling ready',[],ready(begin+10),begin+10,true);
check('merely late final ready without timestamp proof',[],ready(latePoll),latePoll,false);
check('late fulfillment does not qualify',[event(deadline+.001)],ready(latePoll),latePoll,false);
check('exact deadline is excluded as original strict bound',[event(deadline)],ready(latePoll),latePoll,false);
check('wrong LOD fulfillment does not qualify',[event(begin+5,2)],ready(latePoll),latePoll,false);
check('pending true at fulfillment does not qualify',[event(begin+5,0,true)],ready(latePoll),latePoll,false);
check('acquire fulfillment alone is not actor readiness',[event(begin+5,0,false,'acquire_fulfilled')],ready(latePoll),latePoll,false);
check('old wait fulfillment excluded',[event(begin-1)],ready(latePoll),latePoll,false);
check('current wrong LOD fails despite old timely state',[event(begin+5)],ready(latePoll,2),latePoll,false);
check('current pending fails despite old timely state',[event(begin+5)],ready(latePoll,0,true),latePoll,false);
check('missing body fails',[event(begin+5)],{at_ms:latePoll,body:false,lod:0,pending:false},latePoll,false);
check('nonfinite timestamp fails',[event(NaN)],ready(latePoll),latePoll,false);
(async()=>{
 const loopControls=[];
 for(const scenario of [{name:'actual async loop accepts84s fulfillment after99s poll',fulfilled:84000,lod:0,want:true},{name:'actual async loop rejects91s fulfillment after99s poll',fulfilled:91000,lod:0,want:false},{name:'actual async loop rejects84s wrongLOD fulfillment',fulfilled:84000,lod:2,want:false}]){
  let now=0;const actor={body:null,lod:-1,pending:true},diagnostic={events:[],history:[]};
  const context=vm.createContext({actor,diagnostic,performance:{now:()=>now},safe:fn=>{try{return fn();}catch{return null;}},watchPending(){},actorState:()=>({at_ms:now,body:!!actor.body,lod:actor.lod,pending:!!actor.pending}),record:(name,extra)=>diagnostic.events.push({at_ms:now,name,...extra}),pause:async()=>{actor.body={};actor.lod=scenario.lod;actor.pending=false;diagnostic.events.push(event(scenario.fulfilled,scenario.lod));now=99000;}});
  vm.runInContext(s.slice(s.indexOf('  function timedReadiness('),s.indexOf('  // pending is cleared')),context);
  let accepted=true;try{await vm.runInContext('waitForBody(0)',context);}catch{accepted=false;}
  assert.equal(accepted,scenario.want,scenario.name);assert.equal(diagnostic.events.find(e=>e.name==='wait_started').deadline_ms,90000);loopControls.push({name:scenario.name,accepted,terminal:JSON.parse(JSON.stringify(diagnostic.events.at(-1)))});
 }
 const r={passed:true,scope:'Exact proposed pure decision plus actual async waiter, finite simulated clocks, original failure timeline and explicit negative boundaries; no browser run or retroactive PASS claim',checks,loopControls};fs.writeFileSync(__dirname+'/TIMED-CONTROLS.json',JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify({passed:true,checks:checks.length,actual_async_waiter_controls:loopControls.length}));
})().catch(e=>{console.error(e);process.exitCode=1;});
