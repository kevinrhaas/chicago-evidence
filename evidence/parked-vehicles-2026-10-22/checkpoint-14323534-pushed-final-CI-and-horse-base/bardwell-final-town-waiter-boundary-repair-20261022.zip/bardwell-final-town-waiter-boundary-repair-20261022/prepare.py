import pathlib,hashlib,json,difflib,shutil
S=pathlib.Path('/workspace/shared/human-standing-bardwell-FINAL-HEAD-OBSERVED-EXECUTION-14323534-20261022')
D=pathlib.Path(__file__).parent
assert not (D/'browser_review.cjs').exists()
helper=(S/'browser_review.cjs').read_text()
start=helper.index('  async function waitForBody(lod)')
end=helper.index('  // pending is cleared',start)
replacement='''  // A late timer poll may use only an actual requested-state observation made inside this wait's original bound.
  function timedReadiness(events,lod,begin,deadline,polledAt,current){
    const exact=s=>s?.body===true&&s.lod===lod&&s.pending===false;
    const candidates=events.filter(e=>['pending_fulfilled','setLod_fulfilled'].includes(e.name)&&exact(e.state)&&Number.isFinite(e.state.at_ms)&&e.state.at_ms>=begin&&e.state.at_ms<deadline).map(e=>({observed_ms:e.state.at_ms,source:e.name,state:e.state}));
    if(exact(current)&&polledAt>=begin&&polledAt<deadline)candidates.push({observed_ms:polledAt,source:'in_bound_poll',state:current});
    candidates.sort((a,b)=>a.observed_ms-b.observed_ms);
    const proof=candidates[0]??null;
    return {accepted:!!proof&&exact(current),begin_ms:begin,deadline_ms:deadline,bound_ms:deadline-begin,observed_completion_ms:proof?.observed_ms??null,completion_source:proof?.source??null,completion_state:proof?.state??null,polled_at_ms:polledAt,poll_after_deadline:polledAt>=deadline,current_exact:exact(current)};
  }
  async function waitForBody(lod){
    const begin=performance.now(),deadline=begin+90000;
    record('wait_started',{expected_lod:lod,begin_ms:begin,deadline_ms:deadline,bound_ms:90000,state:actorState()});
    let last=-Infinity;
    while(true){
      watchPending();
      const polledAt=performance.now(),current={at_ms:polledAt,body:!!actor.body,lod:actor.lod,pending:!!actor.pending};
      const decision=timedReadiness(diagnostic.events,lod,begin,deadline,polledAt,current);
      safe(()=>{if(polledAt-last>=1000){diagnostic.history.push(actorState());last=polledAt;}});
      if(decision.accepted){record('wait_fulfilled',{expected_lod:lod,readiness:decision,state:actorState()});return;}
      if(polledAt>=deadline){record('wait_failed',{expected_lod:lod,readiness:decision,state:actorState()});throw Error('actual autoLOD '+lod+' did not settle inside original90s bound; readiness '+JSON.stringify(decision));}
      await pause(100);
    }
  }
'''
after=helper[:start]+replacement+helper[end:]
caller=(S/'capture_town.cjs').read_text()
assert caller.count("observerRevision:'v2_observation_only'")==1
caller_after=caller.replace("observerRevision:'v2_observation_only'","observerRevision:'v3_timed_readiness'")
changes=[];patch=[]
for name,before,proposed in [('browser_review.cjs',helper,after),('capture_town.cjs',caller,caller_after)]:
 (D/('ORIGINAL-'+name)).write_text(before);(D/name).write_text(proposed)
 changes.append({'file':name,'original_path':str(S/name),'original_sha256':hashlib.sha256(before.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(proposed.encode()).hexdigest()})
 patch.extend(difflib.unified_diff(before.splitlines(True),proposed.splitlines(True),fromfile='original/'+name,tofile='proposed/'+name))
(D/'TIMED-READINESS.patch').write_text(''.join(patch))
for name in ['CANONICAL-EXPECTED-INPUTS-HELD.json','RELEASE-desktop_visual-HELD.json','RELEASE-desktop_functional-HELD.json','RELEASE-mobile_full-HELD.json']:
 shutil.copy2(S/name,D/name)
 if name.startswith('RELEASE'):assert json.loads((D/name).read_text())['released'] is False
failed=pathlib.Path('/workspace/shared/bardwell-FINAL-town-desktop-visual-OBSERVED-20261022/receipt.json')
shutil.copy2(failed,D/'ACTUAL-OBSERVED-FAILURE-UNCHANGED.json')
original=pathlib.Path('/workspace/shared/bardwell-FINAL-town-desktop-visual-20261022/receipt.json')
shutil.copy2(original,D/'ACTUAL-FIRST-FAILURE-UNCHANGED.json')
manifest={'state':'PREPARED_HELD_NO_BROWSER','released':False,'scope':'Caller-only time-bound correctness repair; no app/runtime/model/AUTO/camera/route/fit/budget/90s/540s change. Root makes one further execution copy for all3 phases. Original both failed runs and exact executed sourcepreimages retained.','protocol':'actual_published_bardwell_final_head_split_v1','observerRevision':'v3_timed_readiness','files':changes,'failed_receipts':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (original,failed)]}
(D/'PREPARED-HELD.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
