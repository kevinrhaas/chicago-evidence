"""Read-only licensed GLB skin/rest-pose diagnostics. Never export/alter a model."""
import hashlib,json,struct
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent;F=P/'horse-53a6eb7ccf054aa2a378dd7ec08f88fe.glb'
B=F.read_bytes();assert hashlib.sha256(B).hexdigest()=='41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988'
N=struct.unpack_from('<I',B,12)[0];G=json.loads(B[20:20+N]);BIN=B[N+28:]
WIDTH={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16};DT={5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'}
def acc(i):
 a=G['accessors'][i];v=G['bufferViews'][a['bufferView']];d=np.dtype(DT[a['componentType']]);w=WIDTH[a['type']]
 x=np.ndarray((a['count'],w),dtype=d,buffer=BIN,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*d.itemsize),d.itemsize)).copy()
 if a.get('normalized'):
  x=x.astype(float)/np.iinfo(d).max
  if d.kind=='i':x=np.maximum(x,-1)
 return x
def local(node,over):
 if 'matrix'in node:return np.asarray(node['matrix']).reshape((4,4),order='F')
 x,y,z,w=over.get('rotation',node.get('rotation',[0,0,0,1]));r=np.asarray([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
 m=np.eye(4);m[:3,:3]=r@np.diag(over.get('scale',node.get('scale',[1,1,1])));m[:3,3]=over.get('translation',node.get('translation',[0,0,0]));return m
PARENT={kid:i for i,n in enumerate(G['nodes'])for kid in n.get('children',[])}
def worlds(over):
 result={}
 def get(i):
  if i not in result:result[i]=(get(PARENT[i])if i in PARENT else np.eye(4))@local(G['nodes'][i],over.get(i,{}))
  return result[i]
 for i in range(len(G['nodes'])):get(i)
 return result
def points(over):
 w=worlds(over);out=[]
 for node in G['nodes']:
  if 'mesh'not in node:continue
  s=G['skins'][node['skin']];ib=acc(s['inverseBindMatrices']).reshape((-1,4,4)).transpose(0,2,1);mats=np.stack([w[i]for i in s['joints']])@ib
  for pr in G['meshes'][node['mesh']]['primitives']:
   at=pr['attributes'];p=acc(at['POSITION']);j=acc(at['JOINTS_0']).astype(int);weights=acc(at['WEIGHTS_0']);v=np.einsum('nwij,nj->nwi',mats[j],np.c_[p,np.ones(len(p))]);v=np.einsum('nw,nwi->ni',weights,v)[:,:3];assert np.isfinite(v).all();out.append((pr['material'],v))
 return out
def measure(over):
 pieces=points(over);v=np.concatenate([x for _,x in pieces]);body=np.concatenate([x for mat,x in pieces if mat==1]);h=v[:,1].max()-v[:,1].min();feet=[]
 # Spatial candidates, not certified anatomical soles. Body material excludes
 # tail/mane; low band and quadrant divide must be visually confirmed later.
 for fore,zsign in [('fore',1),('hind',-1)]:
  for side,xsign in [('left',1),('right',-1)]:
   a=body[(body[:,1]<v[:,1].min()+.28*h)&(body[:,0]*xsign>.1)&(body[:,2]*zsign>0)]
   if not len(a):feet.append({'label':fore+'_'+side,'candidate_vertices':0});continue
   low=a[a[:,1]<a[:,1].min()+.025]
   feet.append({'label':fore+'_'+side,'candidate_vertices':len(a),'minimum_y_native':float(a[:,1].min()),'lowest_band_vertices':len(low),'lowest_band_center_native':low.mean(0).tolist(),'lowest_band_bounds_native':[low.min(0).tolist(),low.max(0).tolist()]})
 mins=[f['minimum_y_native']for f in feet if 'minimum_y_native'in f]
 return {'bounds_native':[v.min(0).tolist(),v.max(0).tolist()],'height_native':float(h),'spatial_foot_candidates':feet,'four_candidate_minima_range_native':max(mins)-min(mins)if len(mins)==4 else None,'limitation':'Source-unit candidates only; no units, four-foot support, hoof anatomy or neutral pose accepted before actual all-part views and contact review.'}
def pose_at_key_start(a):
 over={}
 for ch in a['channels']:
  s=a['samplers'][ch['sampler']];assert s.get('interpolation','LINEAR')in['STEP','LINEAR'];over.setdefault(ch['target']['node'],{})[ch['target']['path']]=acc(s['output'])[0].tolist()
 return over
if __name__=='__main__':
 result={'scope':'Read-only native default and authoredclip start evaluation; no reposing/normalizing/exporting of model','GLB_sha256':hashlib.sha256(B).hexdigest(),'default_pose':measure({}),'authored_clip_starts':[{'index':i,'name':a.get('name'),**measure(pose_at_key_start(a))}for i,a in enumerate(G.get('animations',[]))]}
 (P/'NATIVE-FOOT-CANDIDATES.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
