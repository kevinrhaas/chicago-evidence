from pathlib import Path
import sys,json,hashlib,copy
R=Path(__file__).parent;sys.path.insert(0,str(R/'source'));from index_streams import read_glb
S=Path('/workspace/shared/brougham-v17-rear-quarter-ACTUAL-20261022');H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert H(S/'OWNER.json')=='750b32ba6414319b79497be3cbf36477ed799903988503b66f004a340bdf478b';assert H(R/'raw/brougham.glb')==H(S/'raw/brougham.glb')=='b74e00937871eef8666fe048501456a8409b18df185c87a0905b083b7a2448fa'
for p in (S/'source').iterdir():
 if p.is_file():assert (R/'source'/p.name).read_bytes()==p.read_bytes()
g,b=read_glb(R/'raw/brougham.glb');j,bb=read_glb(R/'portable-near/brougham-near.glb')
assert all(g[k]==j[k]for k in g if k not in ['buffers','bufferViews','accessors','meshes'])
def semantics(meshes):
 q=copy.deepcopy(meshes)
 for m in q:
  for p in m['primitives']:
   p.pop('indices',None);p['attributes']=sorted(p['attributes'])
 return q
assert semantics(g['meshes'])==semantics(j['meshes'])
report={'pass':True,'original_first_owner_still_FAIL':json.loads((S/'OWNER.json').read_text())['pass']is False,'no_regeneration':True,'raw_bytes_exact_first_trial':True,'source_all_exact_first_trial':True,'all_nonindex_document_metadata_exact_raw_to_indexed':True,'all_mesh_semantics_exact_except_required_index_accessor_numbers':True,'raw_sha256':H(R/'raw/brougham.glb'),'indexed_sha256':H(R/'portable-near/brougham-near.glb')};(R/'METADATA-READBACK.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
