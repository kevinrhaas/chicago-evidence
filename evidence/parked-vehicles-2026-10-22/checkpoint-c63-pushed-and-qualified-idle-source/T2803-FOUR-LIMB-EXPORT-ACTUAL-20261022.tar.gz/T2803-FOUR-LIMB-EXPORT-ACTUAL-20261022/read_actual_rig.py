"""Independent actual-byte reader: no producer/weight-helper imports. Static only."""
import hashlib,json,pathlib,struct,time
import numpy as np
P=pathlib.Path(__file__).resolve().parent
ORIGINAL=pathlib.Path('/workspace/shared/horse-public-base-search-20261022/horse-53a6eb7ccf054aa2a378dd7ec08f88fe.glb')
DERIVED=P/'horse-sevket-reconstructed-four-limb-bind-study-v1.glb'
SIDE=pathlib.Path('/workspace/shared/horse-standing-intake-proposal-V2-20261022/proposed/data/transport/parked/horse-sevket-sidecar.json')
CONTROLS=pathlib.Path('/workspace/shared/T2803-native-rerig-fallback-20261022/RERIG-CONTROLS-PROPOSAL.json')
class Model:
 def __init__(self,p):
  self.raw=p.read_bytes();n=struct.unpack_from('<I',self.raw,12)[0];self.g=json.loads(self.raw[20:20+n]);self.bin=self.raw[28+n:];self.parent={c:i for i,n in enumerate(self.g['nodes'])for c in n.get('children',[])};self.w={}
 def accessor(self,i):
  a=self.g['accessors'][i];v=self.g['bufferViews'][a['bufferView']];dtype=np.dtype({5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']]);width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
  out=np.empty((a['count'],width),dtype=dtype)
  for row in range(a['count']):
   start=v.get('byteOffset',0)+a.get('byteOffset',0)+row*v.get('byteStride',width*dtype.itemsize);out[row]=np.frombuffer(self.bin,dtype=dtype,count=width,offset=start)
  if a.get('normalized'):out=out.astype(float)/np.iinfo(dtype).max
  return out
 def world(self,i):
  if i in self.w:return self.w[i]
  n=self.g['nodes'][i]
  if'matrix'in n:m=np.asarray(n['matrix']).reshape(4,4,order='F')
  else:
   x,y,z,w=n.get('rotation',[0,0,0,1]);v=np.array([x,y,z]);cross=np.array([[0,-z,y],[z,0,-x],[-y,x,0]]);rot=np.eye(3)+2*w*cross+2*cross@cross;m=np.eye(4);m[:3,:3]=rot@np.diag(n.get('scale',[1,1,1]));m[:3,3]=n.get('translation',[0,0,0])
  self.w[i]=(self.world(self.parent[i])if i in self.parent else np.eye(4))@m;return self.w[i]
 def mesh(self,node_id):
  node=self.g['nodes'][node_id];pr=self.g['meshes'][node['mesh']]['primitives'][0];a=pr['attributes'];skin=self.g['skins'][node['skin']];ib=self.accessor(skin['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1);jw=np.array([self.world(i)for i in skin['joints']]);joint=self.accessor(a['JOINTS_0']).astype(int);weights=self.accessor(a['WEIGHTS_0']);matrix=(jw@ib)[joint];position=self.accessor(a['POSITION']);normal=self.accessor(a['NORMAL']);p=np.einsum('nw,nwij,nj->ni',weights,matrix,np.c_[position,np.ones(len(position))])[:,:3];n=np.einsum('nw,nwij,nj->ni',weights,matrix,np.c_[normal,np.zeros(len(normal))])[:,:3];inv=np.linalg.inv(self.world(node_id)[:3,:3]);n=(inv.T@inv@n.T).T;n/=np.linalg.norm(n,axis=1)[:,None];return p,n,joint,weights,pr
start=time.monotonic();old,new=Model(ORIGINAL),Model(DERIVED);side=json.loads(SIDE.read_text());controls=json.loads(CONTROLS.read_text());origin=np.array(side['origin_native']);scale=side['uniform_metres_per_native_unit'];assert hashlib.sha256(old.raw).hexdigest()=='41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988';assert hashlib.sha256(new.raw).hexdigest()=='03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36'
assert new.bin[:len(old.bin)]==old.bin
for k in ['materials','images','textures','samplers']:assert old.g.get(k)==new.g.get(k),k
assert len(new.g['skins'])==1 and new.g['skins'][0]['joints']==list(range(26)) and not new.g.get('animations')
assert len(new.g['nodes'])==29 and [n['name']for n in new.g['nodes'][:26]]==[c['name']for c in controls['nodes']]
source_nodes=[i for i,n in enumerate(old.g['nodes'])if'mesh'in n];rows=[];origpoints=[];newpoints=[];joints_rows=[];weight_rows=[];triangles=0
for mi,(oi,ni)in enumerate(zip(source_nodes,[26,27,28])):
 assert ni in new.g['scenes'][0]['nodes'] and all(k not in new.g['nodes'][ni]for k in ['matrix','translation','rotation','scale'])
 a,an,_,_,op=old.mesh(oi);b,bn,j,w,np_=new.mesh(ni);a=(a-origin)*scale;origpoints.append(a);newpoints.append(b);joints_rows.append(j);weight_rows.append(w)
 assert np.array_equal(old.accessor(op['indices']),new.accessor(np_['indices']));triangles+=len(new.accessor(np_['indices']))//3
 for k in ['TEXCOORD_0','TEXCOORD_1']:assert np.array_equal(old.accessor(op['attributes'][k]),new.accessor(np_['attributes'][k]))
 assert np_.get('material')==op.get('material') and np.isfinite(b).all() and np.isfinite(bn).all() and np.all((j>=0)&(j<26)) and np.all((w>=0)&(w<=1))
 error=float(np.abs(b-a).max());angles=np.rad2deg(np.arccos(np.clip(np.einsum('ni,ni->n',an,bn),-1,1)));assert error<1e-6 and float(angles.max())<.01
 rows.append({'mesh':mi,'vertices':len(a),'static_world_position_max_abs_delta_m':error,'static_world_normal_max_angle_degrees':float(angles.max()),'position_tolerance_m':1e-6,'normal_tolerance_degrees':.01,'weight_sum_max_abs_error':float(np.abs(w.sum(1)-1).max()),'UV_indices_material_exact':True,'finite_positions_normals':True})
bodyidx=new.accessor(new.g['meshes'][1]['primitives'][0]['indices']).astype(int).reshape(-1,3);feet={}
for label,c in side['contacts'].items():
 ids=np.unique(bodyidx[np.array(c['source_triangle_ids'],dtype=int)].ravel());own=controls['limbs'][label]['joints'][-1];j,w=joints_rows[1][ids],weight_rows[1][ids];assert np.all(np.where(j==own,w,0).sum(1)==1)and np.all(np.where(j!=own,w,0)==0)
 feet[label]={'annotated_vertices':len(ids),'own_joint':own,'own_joint_weight_exact_one':True,'static_max_delta_m':float(np.abs(newpoints[1][ids]-origpoints[1][ids]).max()),'static_min_y_m':float(newpoints[1][ids,1].min())}
classes={}
for mi,points in enumerate(origpoints):
 for vi,p in enumerate(points):classes.setdefault(tuple(np.rint(p/1e-6).astype(int)),[]).append((mi,vi))
seam_gap=0.
for group in classes.values():
 if len(group)<2:continue
 ps=np.array([newpoints[m][v]for m,v in group]);seam_gap=max(seam_gap,float(np.linalg.norm(ps-ps[0],axis=1).max()));m,v=group[0]
 for mm,vv in group[1:]:assert np.array_equal(joints_rows[m][v],joints_rows[mm][vv])and np.array_equal(weight_rows[m][v],weight_rows[mm][vv])
assert triangles==14986 and seam_gap==0
r={'status':'ACTUAL DECODED STATIC PARITY PASS; not GLTFLoader/Mixer/visual/anatomy/gait proof','source_sha256':hashlib.sha256(old.raw).hexdigest(),'derived_sha256':hashlib.sha256(new.raw).hexdigest(),'reader_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'scope':'Independent actual-byte parser/generic quaternion matrix+LBS; imports no producer or weight helper. Native rest only, no posed serialized sample proof.','joint_count':26,'meshes':rows,'triangles':triangles,'original_BIN_prefix_exact':True,'original_maps_materials_UV_indices_exact':True,'original_six_clips_deliberately_absent':True,'mesh_root_identity_exact':True,'annotated_hoofs':feet,'seam_max_gap_m':seam_gap,'seam_weights_exact':True,'default_grounding_qualified':'Canonical original default only. Existing5.238mm foot offset persists; no yard tilt or continuous sole stance approval.','capabilities':{'walk':False,'weight_shift':False,'hitch':False,'riding':False,'photographic_or_anatomical_acceptance':False},'elapsed_seconds':time.monotonic()-start};(P/'ACTUAL-STATIC-READBACK.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
