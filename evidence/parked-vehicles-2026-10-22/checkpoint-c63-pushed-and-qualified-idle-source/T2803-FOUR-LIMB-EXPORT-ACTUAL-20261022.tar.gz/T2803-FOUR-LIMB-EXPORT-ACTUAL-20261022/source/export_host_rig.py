"""UNEXECUTED producer source: source-rest surface + explicit independent26joint rig.
No walk, native clip transfer, hidden pose correction or appearance-quality acceptance.
"""
import argparse,copy,hashlib,json,pathlib,struct
import numpy as np
import draft_weights as W
D=W.D
HERE=pathlib.Path(__file__).resolve().parent
EXPECTED_WEIGHTS='20c06548068f972ec3bcd38035177b87fcb88b082b009dd4450c65a862d4cc25'
def build(out):
 assert hashlib.sha256((HERE/'draft_weights.py').read_bytes()).hexdigest()==EXPECTED_WEIGHTS
 assert out.resolve().is_relative_to(pathlib.Path('/workspace/shared')) and not out.exists()
 data=W.inspect(out);points=data['canonical'];arrays=data['arrays'];controls=data['controls'];sidecar=data['sidecar'];original=copy.deepcopy(D.G);doc=copy.deepcopy(original);binary=bytearray(D.BIN)
 def append(a,kind,target=None):
  a=np.asarray(a);assert a.dtype in [np.dtype('<f4'),np.dtype('<u2')];assert np.isfinite(a).all()
  while len(binary)%4:binary.append(0)
  view={'buffer':0,'byteOffset':len(binary),'byteLength':a.nbytes}
  if target is not None:view['target']=target
  doc['bufferViews'].append(view);binary.extend(a.tobytes(order='C'));acc={'bufferView':len(doc['bufferViews'])-1,'componentType':5126 if a.dtype==np.dtype('<f4')else 5123,'count':len(a),'type':kind}
  if kind=='VEC3' and target==34962:acc['min']=a.min(0).tolist();acc['max']=a.max(0).tolist()
  doc['accessors'].append(acc);return len(doc['accessors'])-1
 # New bind-pose geometry is source default SKINNED world surface, converted uniformly
 # to declared canonical metres. Original unskinned accessors remain in protected prefix.
 source_world=D.worlds({});source_mesh_nodes=[i for i,n in enumerate(D.G['nodes'])if'mesh'in n];normal_notes=[]
 for mi,(position,(joints,weights))in enumerate(zip(points,arrays)):
  source_node=D.G['nodes'][source_mesh_nodes[mi]];primitive=original['meshes'][source_node['mesh']]['primitives'][0];attrs=primitive['attributes'];skin=original['skins'][source_node['skin']]
  invbind=D.acc(skin['inverseBindMatrices']).reshape((-1,4,4)).transpose(0,2,1);mats=np.stack([source_world[i]for i in skin['joints']])@invbind;ji=D.acc(attrs['JOINTS_0']).astype(int);sw=D.acc(attrs['WEIGHTS_0']);norm=D.acc(attrs['NORMAL'])
  weighted=np.einsum('nwij,nj->nwi',mats[ji],np.c_[norm,np.zeros(len(norm))]);weighted=np.einsum('nw,nwi->ni',sw,weighted)[:,:3]
  # Exact source-default Three attached-bind world-normal formula at identity view:
  # transpose(inv(meshWorld3)) * inv(meshWorld3) * weightedBoneNormal.
  # This must be checked against actual loaded GPU/CPU normals before accepting.
  mesh_world3=source_world[source_mesh_nodes[mi]][:3,:3];inv=np.linalg.inv(mesh_world3);world_normal=(inv.T@inv@weighted.T).T;length=np.linalg.norm(world_normal,axis=1);assert np.all(length>1e-10);world_normal/=length[:,None]
  p=doc['meshes'][mi]['primitives'][0];p['attributes']['POSITION']=append(np.asarray(position,dtype='<f4'),'VEC3',34962);p['attributes']['NORMAL']=append(np.asarray(world_normal,dtype='<f4'),'VEC3',34962);p['attributes']['JOINTS_0']=append(np.asarray(joints,dtype='<u2'),'VEC4',34962);p['attributes']['WEIGHTS_0']=append(np.asarray(weights,dtype='<f4'),'VEC4',34962)
  for key in attrs:
   if key not in ['POSITION','NORMAL','JOINTS_0','WEIGHTS_0']:assert p['attributes'][key]==attrs[key]
  assert p['indices']==primitive['indices'] and p['material']==primitive['material']
  normal_notes.append({'mesh':mi,'source_normal_accessors_untouched':True,'new_normals':'source-default attached-bind world directions, normalized; actual loader parity unproven','maximum_float32_position_roundoff_m':float(np.abs(np.asarray(position,dtype='<f4').astype(float)-position).max())})
 piv=np.array([n['rest_world_pivot_m']for n in controls['nodes']]);nodes=[]
 for i,c in enumerate(controls['nodes']):
  parent=c['parent_index'];local=piv[i]-(piv[parent]if parent is not None else 0);nodes.append({'name':c['name'],'translation':local.tolist(),'extras':{'anatomical_status':'reconstructed source-specific control; not historical individual anatomy','control_basis':c['basis']}})
 for i,c in enumerate(controls['nodes']):
  if c['parent_index']is not None:nodes[c['parent_index']].setdefault('children',[]).append(i)
 # Identity-local skinned nodes at scene root; no original serial rig/socket inheritance.
 for mi,oldnode in enumerate(source_mesh_nodes):nodes.append({'name':original['nodes'][oldnode]['name'],'mesh':mi,'skin':0})
 ibm=np.repeat(np.eye(4)[None],26,axis=0);ibm[:,:3,3]=-piv;ib_accessor=append(np.asarray(ibm.transpose(0,2,1).reshape(26,16),dtype='<f4'),'MAT4')
 doc['nodes']=nodes;doc['skins']=[{'name':'source_specific_reconstructed_26joint_horse','joints':list(range(26)),'skeleton':0,'inverseBindMatrices':ib_accessor}];doc['scenes']=[{'name':'Horse reconstructed independent four-limb bind pose','nodes':[0,26,27,28]}];doc['scene']=0
 # The old six clips target the original serial rig. They remain SOURCE only, not misleading
 # playable tracks on this new hierarchy. Exact bytes remain protected in original BIN prefix.
 doc.pop('animations',None)
 provenance={'original_host_sha256':W.ORIGINAL,'reference_rig_sha256':controls['reference_rig_sha256'],'host_credit':controls['source_credit_host'],'rig_reference_credit':controls['source_credit_rig_motion_reference'],'adaptation':'Source default world-skin surface baked to canonical metres, new source-specific26joint rig and topology-smoothed weights; original UV/index/material/image data retained. Old six incompatible serial-rig animations omitted from derivative playback, preserved in original separate source/BINprefix. All control placement and appearance remain reconstructed. No original joint/socket/gait compatibility.','native_origin':sidecar['origin_native'],'uniform_metres_per_native_unit':sidecar['uniform_metres_per_native_unit'],'walk':False,'weight_shift':False,'hitch':False,'riding':False,'historical_breed_or_individual_attestation':False,'actual_loader_visual_or_photographic_acceptance':False}
 doc['asset'].setdefault('extras',{})['new_rig_adaptation']=provenance;doc['buffers'][0]['byteLength']=len(binary)
 assert doc['materials']==original['materials'] and doc['images']==original['images'] and doc['textures']==original['textures'] and doc.get('samplers')==original.get('samplers')
 assert binary[:len(D.BIN)]==D.BIN
 encoded=json.dumps(doc,ensure_ascii=False,separators=(',',':')).encode();encoded+=b' '*((-len(encoded))%4)
 while len(binary)%4:binary.append(0)
 result=struct.pack('<III',0x46546c67,2,28+len(encoded)+len(binary))+struct.pack('<II',len(encoded),0x4e4f534a)+encoded+struct.pack('<II',len(binary),0x004e4942)+binary
 model=out/'horse-sevket-reconstructed-four-limb-bind-study-v1.glb';model.write_bytes(result)
 receipt={'status':'EXPERIMENTAL ACTUAL RIG EXPORT ONLY; validators/actual loaded neutral+flexion+normals/visual/contact/intersection all pending','derived_file':model.name,'derived_sha256':hashlib.sha256(result).hexdigest(),'derived_bytes':len(result),'generator_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'weights_producer_sha256':EXPECTED_WEIGHTS,'original_BIN_prefix_exact':True,'original_source_unchanged':hashlib.sha256(D.F.read_bytes()).hexdigest()==W.ORIGINAL,'joint_count':26,'mesh_count':3,'triangle_count_unchanged':14986,'positions_and_normals_rebaked_not_original_accessor_parity':normal_notes,'old_six_animations_incompatible_omitted_from_playback':True,'native_default_support_tilt_not_baked':True,'provenance':provenance}
 (out/'RIG-EXPORT-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--lane-released',required=True,action='store_true');p.add_argument('--output-dir',required=True,type=pathlib.Path);a=p.parse_args();build(a.output_dir)
