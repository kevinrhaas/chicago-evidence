from pathlib import Path
import sys,json,hashlib
R=Path(__file__).parent;B=Path('/workspace/shared/brougham-v15-slender-step-supports-ACTUAL-20261022');sys.path.insert(0,str(R/'source'));from index_streams import write_indexed
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert H(R/'flag-off/brougham.glb')==H(B/'raw/brougham.glb')=='3a323a9b0033a9d1493c5e3434dd687f183bba1cb8551bc306a3738799e8d185'
assert (R/'flag-off/brougham.json').read_bytes()==(B/'raw/brougham.json').read_bytes();write_indexed(R/'flag-off/brougham.glb',R/'flag-off/brougham-near.glb');assert H(R/'flag-off/brougham-near.glb')==H(B/'portable-near/brougham-near.glb')=='ddbbe9f20779ddaa103fe4f28652d4e984440f1ebabf8b540f322915e4e09eca'
(R/'FLAG-OFF-CHECK.json').write_text(json.dumps({'pass':True,'raw_GLB_exactV15':True,'raw_JSON_exactV15':True,'indexed_near_exactV15':True},indent=2)+'\n')
