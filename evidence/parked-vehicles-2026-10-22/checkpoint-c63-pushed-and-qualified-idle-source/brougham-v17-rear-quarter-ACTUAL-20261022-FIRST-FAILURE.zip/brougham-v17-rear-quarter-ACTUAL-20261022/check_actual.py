from pathlib import Path
from collections import Counter
import json,math,hashlib
from existing_geometry_readers import read,stream,component,pts,bounds,need
R=Path(__file__).parent;B=Path('/workspace/shared/brougham-v15-slender-step-supports-ACTUAL-20261022');H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
_,a,ab=read(B/'raw/brougham.glb');cr,c,cb=read(R/'raw/brougham.glb');pa=a['extras']['parts'];pc=c['extras']['parts'];recipe=json.loads((R/'rear-quarter.json').read_text());new=[p for p in pc if p['name']=='rear_quarter_recessed_surface'];existing=[p for p in pc if p['name']!='rear_quarter_recessed_surface'];assert len(pa)==len(existing)==466 and len(pc)==468 and len(new)==2
assert c['materials'][:6]==a['materials'] and c['materials'][6]==recipe['material'] and len(c['materials'])==7 and c['extensionsUsed']==a['extensionsUsed']
assert c['scenes']==a['scenes'] and c['scene']==a['scene'] and c['asset']==a['asset'] and c['extras']['parameters']==a['extras']['parameters']
for k,v in a['extras'].items():
 if k not in ['parts','statistics']:assert c['extras'][k]==v,k
assert set(c['extras'])==set(a['extras'])|{'rear_quarter_study'}
assert c['extras']['rear_quarter_study']=={'recipe_sha256':H(R/'rear-quarter.json'),'interpretation':recipe['interpretation'],'appearance_accepted':False}
def nodemap(g):
 out={}
 def visit(i,parent):
  n=g['nodes'][i];key=parent+(n['name'],);assert key not in out;out[key]={'data':{k:v for k,v in n.items()if k not in ['children','mesh']},'children':sorted(g['nodes'][j]['name']for j in n.get('children',[])),'mesh_name':g['meshes'][n['mesh']]['name']if 'mesh'in n else None}
  for j in n.get('children',[]):visit(j,key)
 for i in g['scenes'][g['scene']]['nodes']:visit(i,())
 return out
na,nc=nodemap(a),nodemap(c);extra=set(nc)-set(na);assert len(extra)==1 and next(iter(extra))==('vehicle_root','vehicle_body','surface_vehicle_body_6') and len(na)==41 and len(nc)==42
for key,row in na.items():
 newrow=dict(nc[key]);newrow['children']=[x for x in newrow['children']if x!='surface_vehicle_body_6'];assert newrow==row,('Original semantic node',key)
oldmeshes=list(enumerate(a['meshes']));newmeshes=[(i,m)for i,m in enumerate(c['meshes'])if m['name']!='surface_vehicle_body_6'];assert len(oldmeshes)==len(newmeshes)==24 and len(c['meshes'])==25
protected_meshes=0
for (i,ma),(j,mc)in zip(oldmeshes,newmeshes):
 assert ma['name']==mc['name'] and ma['primitives'][0]['material']==mc['primitives'][0]['material'] and set(ma['primitives'][0]['attributes'])==set(mc['primitives'][0]['attributes'])=={'POSITION','NORMAL'}
 if ma['name']!='surface_vehicle_body_0':
  assert all(stream(a,ab,i,k)==stream(c,cb,j,k)for k in ['POSITION','NORMAL']);protected_meshes+=1
protected=0;owned=[]
for old,p in zip(pa,existing):
 assert all(old[k]==p[k]for k in ['name','frame','material'])
 if old['name']!='rear_quarter_panel':
  assert old['triangles']==p['triangles'] and all(component(a,ab,old,k)==component(c,cb,p,k)for k in ['POSITION','NORMAL']);protected+=1
 else:
  assert old['triangles']==124 and p['triangles']==158 and p['material']==0
  owned.append((old,p))
assert protected==464 and len(owned)==2 and protected_meshes==23
shells=[]
for (old,rim),inset in zip(owned,new):
 assert inset['triangles']==30 and inset['material']==6 and inset['frame']==rim['frame']=='vehicle_body'
 pp=pts(component(c,cb,rim,'POSITION'))+pts(component(c,cb,inset,'POSITION'));nn=pts(component(c,cb,rim,'NORMAL'))+pts(component(c,cb,inset,'NORMAL'));edges=Counter();directed=Counter();adj={};volume=0
 for k in range(0,len(pp),3):
  q=pp[k:k+3];u=[q[1][j]-q[0][j]for j in range(3)];v=[q[2][j]-q[0][j]for j in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];ln=math.sqrt(math.fsum(x*x for x in cross));assert ln>1e-10
  for n in nn[k:k+3]:assert all(math.isfinite(x)for x in n)and abs(math.sqrt(math.fsum(x*x for x in n))-1)<1e-5 and math.fsum(cross[j]*n[j]for j in range(3))/ln>.9999
  assert all(math.isfinite(x)for p in q for x in p);volume+=math.fsum(q[0][j]*[q[1][1]*q[2][2]-q[1][2]*q[2][1],q[1][2]*q[2][0]-q[1][0]*q[2][2],q[1][0]*q[2][1]-q[1][1]*q[2][0]][j]for j in range(3))/6
  for x,y in zip(q,q[1:]+q[:1]):edges[tuple(sorted((x,y)))]+=1;directed[(x,y)]+=1;adj.setdefault(x,set()).add(y);adj.setdefault(y,set()).add(x)
 assert all(v==2 for v in edges.values())and all(v==1 and directed[(y,x)]==1 for (x,y),v in directed.items())and volume>0
 vertices=set(pp);seen=set();stack=[next(iter(vertices))]
 while stack:
  x=stack.pop()
  if x not in seen:seen.add(x);stack.extend(adj[x]-seen)
 assert seen==vertices and len(vertices)==96 and len(edges)==282 and len(pp)//3==188 and len(vertices)-len(edges)+len(pp)//3==2
 # Original front/back outline vertices retained exactly, not just equal bbox.
 original=set(pts(component(a,ab,old,'POSITION')));assert original<=vertices
 sign=1 if pp[0][0]>0 else -1;ox=max(sign*x[0]for x in original);bx=min(sign*x[0]for x in original);insetpts=pts(component(c,cb,inset,'POSITION'));ix={sign*x[0]for x in insetpts};assert len(ix)==1 and abs(ox-next(iter(ix))-.008)<1e-7 and abs(next(iter(ix))-bx-.017)<1e-7
 shells.append({'side':sign,'triangles':188,'welded_vertices':96,'edges':282,'Euler':2,'components':1,'opposite_directed_edges':True,'positive_volume_m3':volume,'original_outer_back_outline_vertices_exact':True,'actual_recess_m':ox-next(iter(ix)),'actual_remaining_thickness_m':next(iter(ix))-bx,'unit_geometric_normals':True})
assert bounds(a,ab)==bounds(c,cb)and c['extras']['statistics']=={'triangles':33502,'meshes':25,'nodes':42}
report={'pass':True,'candidate_raw_sha256':H(R/'raw/brougham.glb'),'candidate_raw_bytes':len(cr),'protected_original_part_PN_exact':464,'protected_full_mesh_PN_exact':23,'combined_two_material_shells':shells,'original_six_materials_exact':True,'only_new_material_slot6':True,'original41_semantic_node_paths_transforms_mesh_names_exact':True,'one_added_render_node':'surface_vehicle_body_6','13anchors_pending_exact_static_contract_check':True,'global_bounds_exact':bounds(c,cb),'statistics':c['extras']['statistics'],'scope':'Actual two opaquequarter replacements only; no exhaustive solid intersection/optical/period/photo acceptance'}
(R/'OWNERSHIP.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
