from pathlib import Path
import ast,math,json,hashlib,importlib.util,collections,sys
import numpy as np
S=Path('/workspace/shared/brougham-v17-rear-quarter-SOURCE-20261022');P=Path('/workspace/shared/brougham-v17-rear-quarter-INDEPENDENT-REVIEW-20261022');P.mkdir(exist_ok=True);h=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
for n,v in json.loads((S/'FILES.json').read_text()).items():assert h(S/n)==v
B=Path('/workspace/shared/brougham-v15-slender-step-supports-ACTUAL-20261022/source')
for n in ['LICENSE','index_streams.py','lods.json','parameters.json','source_details.py','static_master.py']:assert (S/'source'/n).read_bytes()==(B/n).read_bytes()
tree=ast.parse((S/'source/generate.py').read_text());main=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='main');fns=[x for x in main.body if isinstance(x,ast.FunctionDef)and x.name in ['earclip','catmull']];ctx={'np':np};exec(compile(ast.Module(body=fns,type_ignores=[]),'selected-existing-functions','exec'),ctx);prof=next(ast.literal_eval(x.value)for x in ast.walk(main)if isinstance(x,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='rearprof'for t in x.targets));profile=ctx['catmull'](prof,4,True).tolist();spec=importlib.util.spec_from_file_location('quarter',S/'source/quarter_surface.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q);recipe=json.loads((S/'rear-quarter.json').read_text());half=json.loads((S/'source/parameters.json').read_text())['body_half_width_m'];print('HALF',half)
center=np.array([math.fsum(p[k]for p in profile)/len(profile)for k in range(2)]);cross=lambda a,b,c:(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);area=sum(a[0]*b[1]-b[0]*a[1]for a,b in zip(profile,profile[1:]+profile[:1]));assert area>0;star=[cross(a,b,center)for a,b in zip(profile,profile[1:]+profile[:1])];assert min(star)>0
rows=[]
for side in [-1,1]:
 v,f,iv,iff=q.quarter_surface(profile,side,half,.025,recipe,ctx['earclip']);allv=v+iv;allf=f+[[len(v)+i for i in face]for face in iff];tri=[]
 for face in allf:
  for k in range(1,len(face)-1):tri.append([face[0],face[k],face[k+1]])
 pts=np.asarray(allv);pts[:,1]=pts[:,1]*1.13+.03;pts=np.asarray(pts,dtype='<f4').astype(float);edges=collections.Counter();direct=collections.Counter();vol=0;mint=math.inf;verts=set();adj={}
 for t in tri:
  a,b,c=pts[t];n=np.cross(b-a,c-a);mint=min(mint,float(np.linalg.norm(n)));vol+=float(np.dot(a,np.cross(b,c)))/6
  r=[tuple(pts[i])for i in t];verts.update(r)
  for x,y in zip(r,r[1:]+r[:1]):edges[tuple(sorted((x,y)))]+=1;direct[(x,y)]+=1;adj.setdefault(x,set()).add(y);adj.setdefault(y,set()).add(x)
 assert all(n==2 for n in edges.values()) and all(n==1 and direct[(y,x)]==1 for (x,y),n in direct.items()) and vol>0 and mint>1e-10
 seen=set();stack=[next(iter(verts))]
 while stack:
  x=stack.pop()
  if x not in seen:seen.add(x);stack.extend(adj[x]-seen)
 assert seen==verts and len(verts)-len(edges)+len(tri)==2
 # Every radial reveal lies inside star-shaped original polygon; homothetic inner and noncrossing ring.
 inner=np.asarray(iv)[:,[2,1]];assert np.allclose(inner,center+recipe['inner_profile_scale']*(np.asarray(profile)-center),rtol=0,atol=0)
 rows.append({'side':side,'profile_vertices':len(profile),'unique_welded_vertices':len(verts),'edges':len(edges),'triangles':len(tri),'components':1,'Euler':2,'minimum_double_triangle_area_m2':mint,'signed_volume_m3':vol,'closed_opposite_edges':True,'original_outer_outline_exact':v[:len(profile)]==[[side*(half+.025),y,z]for z,y in profile],'recess_m':.008,'remaining_min_thickness_m':.017,'inner_scale':.94})
report={'pass':True,'scope':'Finite sourcehelper arithmetic only, no full generator/export/browser','profile_area_twice':area,'star_center_all_edges_positive_min':min(star),'profiles':rows,'predicted_total_triangles':33374+2*(rows[0]['triangles']-124),'predicted_parts':468,'protected_original_parts':464,'predicted_meshes':25,'predicted_nodes':42,'material_slots':7,'original_six_materials_unchanged_by_source':True,'new_mesh_node_does_not_imply_original_node_array_identity':True};(P/'SOURCE-ARITHMETIC.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
