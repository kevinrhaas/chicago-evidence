# Rear upper quarter: evidence and ONE source hypothesis (not generated)

## Actually viewed
Full original plate0095 (SHA b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe) and actual V15 desktop source-detail PNG at brougham-v14-v15-slender-supports-native-source8-HELD-20261022/actual/desktop-v15-source-detail-near100.png. In the paired crop, the source's rear upper region is near-black at its top/right, with a diagonal transition into a stippled lighter lower/front region and a light curved lower surround. It is visibly distinct from green lower body. V15 fills that entire outline with the same flat green as the body.

This is NOT enough to adjudicate glass versus an opaque covered quarter or interior/curtain. No clear through-scene feature is identifiable there, no curtain folds or tie-back are unambiguous, and lithographic stippling alone is not leather grain, glass reflection or textile proof. The front door window DOES show distinct scene/people behind it, unlike this region. A glass replacement would therefore be an unsupported strong interpretation; opaque-green correctness is equally unproved. No additional cleared photographic comparator was found in the local ledger search; research agent queried for retained sources. Source ledger supports appearance analogy, not material species/chemistry.

## Actual construction cause
V15 generate.py184–187 calls profile_solid(rear_quarter_panel,...half,.025,0) on BOTH sides. Slot0 is deep_green_painted_body. The panel is a closed25mm-solid extrusion with the bright fine lining outside it; it is not glass and not a cabin aperture. Actual raw GLB has466parts total; two rear_quarter_panel parts each124tri. Every other464part must be protected (stronger than requested462). Nodes/13anchors/shape/bounds/rig stay exact; source V15 materials all preserved.

## Chosen bounded hypothesis
Create a recessed DARK OPAQUE surface inside the existing exact quarter silhouette, with a restrained green reveal, retaining original fine lining and pillar. This adds real8mm depth and a6% profile inset, not a fake photographic speckle or a camera-painted diagonal highlight. The construction is expressly an original display hypothesis, NOT asserted glass, curtain, leather covering or attested quarter construction. Existing other glazing/interior is untouched. No transparent cavity is invented.

`rear-quarter.json` fixes recess8mm inside original25mm thickness; inner outline is94% scale about original profile mean. New opaque surface linear albedo[.006,.007,.006],roughness.46,metal0. Exact physical cut and optics conjectural. Original exterior outline/backplane retained. Existing source triangulator used on back and inset, rather than invalid arbitrary polygon fans. New helper never samples source image pixels, embeds photos or borrows texture rights. Code/derived asset GPL-3.0-or-later under existing producer license.

This may improve visible separation and framing; actual source8 images must judge whether a plain dark recess is sufficient. It will NOT recreate the plate's light stippled wedge by baking unexplained lighting or claiming a curtain. If stronger glass/canvas identification becomes available, it requires a separate explicitly reviewed hypothesis.

## Source package / proposed next checks
source/ is V15 producer+optional --rear-quarter-recipe only. Omitted option must preserve V15 raw3a323a... and near ddbbe9... byteexact, UNRUN. Frozen V16 material-response packet untouched. This proposal does not depend on it.

Future command, NOT RUN:
`python source/generate.py --parameters source/parameters.json --lod-recipe source/lods.json --detail near --rear-quarter-recipe rear-quarter.json --output FRESH_OUTPUT`

Before actual export: independent source review normals, original profile star-centre/reveal simplicity, inner outline containment and exact seam topology. Before appearance: actual decoded P/N for all464protected parts, every frame/anchor/transform, original globalbounds and outline vertices; all six original materials exact; only two retired panel streams and two new recessed surfaces. Actual changed surfaces must be finite/nondegenerate/unit-normal, back/rim/inset seam opposite-directed and closed as combined per side; no inside-out rims. One extra body material batch expected, not measured. Original side profile and roof/pillar/fine lining exact. No claim newquarter is full solid-intersection cleared. Khronos0errors/0warnings required; existing source/index/static pipeline only. Existing matched source8 desktop/mobile image comparison, same cameras/light/exposure. All construction/validation/rendering remains UNRUN, no photographic acceptance.
