from pathlib import Path
from collections import Counter
import hashlib,json,math,struct,traceback
R=Path(__file__).resolve().parent;S=Path('/workspace/shared/brougham-v14-footplates-ACTUAL-20261022');REPORT=R/'OWNERSHIP.json'
def need(c,m):
 if not c:raise ValueError(m)
def read(p):
 raw=p.read_bytes();need(raw[:4]==b'glTF','GLBheader');n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);return raw,g,raw[28+n:]
def stream(g,b,mi,kind):
 a=g['accessors'][g['meshes'][mi]['primitives'][0]['attributes'][kind]];v=g['bufferViews'][a['bufferView']];need(a['componentType']==5126 and a['type']=='VEC3' and 'byteStride' not in v,'Float3');off=v.get('byteOffset',0)+a.get('byteOffset',0);return b[off:off+a['count']*12]
def component(g,b,p,kind):
 name=f"surface_{p['frame']}_{p['material']}";ids=[i for i,m in enumerate(g['meshes']) if m['name']==name];need(ids,'Ownerbatch')
 # Repeated hubcap local ranges are additionally protected mesh-by-mesh below.
 mi=ids[0];start=p['triangle_start_in_batch']*36;raw=stream(g,b,mi,kind)[start:start+p['triangles']*36];need(len(raw)==p['triangles']*36,'Part range');return raw
def pts(raw):return list(struct.iter_unpack('<fff',raw))
def bounds(g,b):
 tr={}
 def visit(i,t):
  n=g['nodes'][i];need(not any(k in n for k in ['matrix','rotation','scale']),'Translation-only reviewed nodes');tr[i]=[t[k]+n.get('translation',[0,0,0])[k] for k in range(3)]
  for c in n.get('children',[]):visit(c,tr[i])
 for n in g['scenes'][g.get('scene',0)]['nodes']:visit(n,[0,0,0])
 lo=[math.inf]*3;hi=[-math.inf]*3
 for i,n in enumerate(g['nodes']):
  if 'mesh' not in n:continue
  for p in pts(stream(g,b,n['mesh'],'POSITION')):
   for k in range(3):v=p[k]+tr[i][k];lo[k]=min(lo[k],v);hi[k]=max(hi[k],v)
 return {'min':lo,'max':hi}
