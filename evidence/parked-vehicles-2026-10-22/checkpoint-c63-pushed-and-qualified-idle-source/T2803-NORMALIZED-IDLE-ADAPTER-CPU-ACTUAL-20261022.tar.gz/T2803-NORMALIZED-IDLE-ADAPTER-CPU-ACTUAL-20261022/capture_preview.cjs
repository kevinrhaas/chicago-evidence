const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{chromium}=require('playwright');
const out=__dirname,hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
if(!fs.existsSync(path.join(out,'RUN-INTENT.json')))throw Error('Owned released caller required');
(async()=>{
 const started=new Date().toISOString(),errors=[],warnings=[],config=JSON.parse(fs.readFileSync(path.join(out,'PREFLIGHT.json')));
 let browser=null,page=null,report=null,closed=false,failure=null;
 try{
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-gpu']});
  page=await browser.newPage();page.on('pageerror',e=>errors.push({kind:'page',message:e.message}));page.on('console',m=>{if(m.type()==='error')errors.push({kind:'console',message:m.text()});if(m.type()==='warning')warnings.push(m.text());});
  page.on('requestfailed',r=>errors.push({kind:'request',message:r.url()+': '+r.failure()?.errorText}));page.on('response',r=>{if(r.status()>=400)errors.push({kind:'http',message:r.status()+' '+r.url()});});
  await page.route('**/*',r=>{const u=new URL(r.request().url());return u.protocol==='data:'||u.protocol==='blob:'||u.hostname==='127.0.0.1'?r.continue():r.abort();});
  await page.goto('http://127.0.0.1:'+process.argv[2]+'/',{timeout:10000});await page.waitForFunction(()=>window.ready===true,null,{timeout:10000});
  report=await page.evaluate(()=>window.compare());
 }catch(e){failure={name:e.name,message:e.message,stack:e.stack};if(page)try{report=await page.evaluate(()=>window.cpuReport??null);}catch{}}
 finally{
  if(browser){await browser.close();closed=true;}
  report??={status:'ACTUAL_NORMALIZED_IDLE_CPU_FAIL',source_sha256:config.source_sha256,normalized_sha256:config.normalized_sha256,poses_complete:false,pose_count:0};
  if(failure||errors.length)report.status='ACTUAL_NORMALIZED_IDLE_CPU_FAIL';
  Object.assign(report,{started,finished:new Date().toISOString(),browser_closed:closed,browser_errors:errors,browser_warnings:warnings,caller_failure:failure,preflight_sha256:hash(path.join(out,'PREFLIGHT.json')),caller_sha256:hash(__filename),fixture_sha256:hash(path.join(out,'preview.html')),actual_candidate_export:false,app_Git_mutation:false,retries:0});
  fs.writeFileSync(path.join(out,'ACTUAL-IDLE-ADAPTER-CPU.json'),JSON.stringify(report,null,2));
 }
 if(report.status!=='ACTUAL_NORMALIZED_IDLE_CPU_PASS')throw Error('Actual parity failed; preserved receipt, no retry');
 console.log(JSON.stringify({status:report.status,pose_count:report.pose_count,positions:report.positions,normals:report.normals,browser_closed:closed}));
})().catch(e=>{console.error(e);process.exitCode=1;});
