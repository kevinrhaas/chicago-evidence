# Actual normalized horse idle adapter CPU proof — PASS, closed

One root-authorized CPU-only browser run used exact asset **c2559073…**, actual binding **39c6ba57…**, and the **unchanged actual runtime adapter56a236a9…**. The normalized idle's full Khronos receipt had0errors/0warnings before the run. No renderer, WebGL scene, app, export or Git change occurred.

The actual GLTFLoader decoded normalized static and idle assets; all six inherited decoded clip keys and loaded maps/materials matched. **Only `sevket_reconstructed_head_tail_idle_v1` was played.** An actual `AnimationAction.play` observer recorded seven test-player calls, all for that clip. All seven players retired successfully.

The actual adapter drove **193 exported keys plus192 between-key times** over12seconds. All **11,556 indexed skin vertices** were evaluated at every one of **385 poses**: **4,449,060 position and shader-normal evaluations**, covering **17,308,830 index references**. The reader reuses the previously qualified actual `applyBoneTransform` path and shader-normal algebra, not an inverse transpose of a blended bone matrix.

Full annotated hoof patches were nonempty:59/59/13/10vertices, covering63/63/7/6triangles. Every patch vertex had **exactly0m drift**. All source-measured lower-limb box vertices—200/200/166/166—also had **exactly0m drift**, below the predeclared1e-5m limit at the existing0.36440688373115426m/native-unit scale. Rest surface comparison and loop endpoint position/normal differences were exactly0. The fixed1,311 indexed vertices also had0position/normal drift. All positions and normals were finite; the minimum ground envelope and conservative source-geometry radius bounds were preserved.

Actual head-weighted geometry moved at most **8.542mm**, with **1.14736°** maximum local head rotation; tail-weighted geometry moved **29.238mm**, with **1.42525°** maximum tail rotation. These stayed inside the predeclared3°/2°caps and geometry-derived envelopes. The receipt preserves actual rest and animated bounds.

Actual adapter controls passed: paused/hidden/reduced-motion calls froze both clock and bone values; resume changed actual bones; large host deltas remained unclamped; equal seeds gave identical rates/delays/poses; different seeds changed parameters; frame partitioning differed by only4.0e-15seconds. Real SkeletonUtils clones had independent moving bones. Duplicate ownership, unsanitized names and corrupted original-name metadata were rejected. Disposal was idempotent and ownership could be rebound.

The immutable actual receipt is `ACTUAL-IDLE-ADAPTER-CPU.json`, SHA256 **027543999fc85bf9dda15c8618a5b96833e554514666e783ed8fe9a04c9b5941**. Computation took3.45seconds; browser interval4.13seconds. Browser and owned server closed at18:24:44UTC with zero errors/warnings. No retry occurred.

**Contact scope is limited.** This checks complete annotated hoof surfaces, measured lower limbs, stationary body vertices, finite geometry, ground envelope and source-derived rotation-radius envelopes. It does not perform exhaustive triangle/triangle or neck/tail self-intersection/clearance tests. Native visual quality, continuous-time behavior between the stated samples, photographic acceptance and production activation remain unproved. This head/tail-only idle adds no weight shift, independent ear movement, walk or trot.
