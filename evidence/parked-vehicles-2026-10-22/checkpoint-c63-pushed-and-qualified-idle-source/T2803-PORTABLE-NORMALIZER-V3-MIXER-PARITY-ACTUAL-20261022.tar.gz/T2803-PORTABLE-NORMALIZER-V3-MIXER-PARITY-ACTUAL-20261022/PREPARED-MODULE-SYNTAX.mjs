
import * as T from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
const need=(x,message)=>{if(!x)throw Error(message);};
const get=(a,i,k)=>k===0?a.getX(i):k===1?a.getY(i):k===2?a.getZ(i):a.getW(i);
const bytesEqual=(a,b)=>a.byteLength===b.byteLength&&new Uint8Array(a.buffer,a.byteOffset,a.byteLength).every((v,i)=>v===new Uint8Array(b.buffer,b.byteOffset,b.byteLength)[i]);
const pixelHashes=new WeakMap();
async function textureInfo(texture){
 if(!texture)return null;
 const image=texture.image;need(image&&image.width&&image.height,'actual decoded map image unavailable');
 let pixel_sha256=pixelHashes.get(image);
 if(!pixel_sha256){const canvas=new OffscreenCanvas(image.width,image.height),ctx=canvas.getContext('2d');ctx.drawImage(image,0,0);const pixels=ctx.getImageData(0,0,image.width,image.height).data;pixel_sha256=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',pixels)),v=>v.toString(16).padStart(2,'0')).join('');pixelHashes.set(image,pixel_sha256);}
 return{width:image.width,height:image.height,pixel_sha256,colorSpace:texture.colorSpace,flipY:texture.flipY,channel:texture.channel,wrapS:texture.wrapS,wrapT:texture.wrapT,minFilter:texture.minFilter,magFilter:texture.magFilter,offset:texture.offset.toArray(),repeat:texture.repeat.toArray(),rotation:texture.rotation};
}
async function maps(model){const rows=[];for(const m of model.meshes){const slots=[];for(const material of[].concat(m.material)){const textures={};for(const key of['map','normalMap','roughnessMap','metalnessMap','aoMap','emissiveMap','alphaMap','bumpMap','lightMap'])textures[key]=await textureInfo(material[key]);slots.push({name:material.name,type:material.type,color:material.color?.toArray(),side:material.side,roughness:material.roughness,metalness:material.metalness,opacity:material.opacity,alphaTest:material.alphaTest,transparent:material.transparent,normalScale:material.normalScale?.toArray(),textures});}rows.push({mesh_key:m.userData.parityKey,materials:slots});}return rows;}
async function load(url){
 const loader=new GLTFLoader(),gltf=await loader.loadAsync(url),meshes=[];
 gltf.scene.traverse(o=>{if(o.isSkinnedMesh){const a=gltf.parser.associations.get(o);need(a&&Number.isInteger(a.meshes)&&Number.isInteger(a.primitives),'actual parser mesh correspondence missing');o.userData.parityKey=a.meshes+':'+a.primitives;meshes.push(o);}});
 meshes.sort((a,b)=>a.userData.parityKey.localeCompare(b.userData.parityKey));need(meshes.length===3&&new Set(meshes.map(m=>m.userData.parityKey)).size===3,'three unique original mesh primitives required');
 const bind=[];gltf.scene.traverse(o=>bind.push([o,o.position.clone(),o.quaternion.clone(),o.scale.clone()]));return{...gltf,meshes,bind,mixer:new T.AnimationMixer(gltf.scene)};
}
function pose(model,clip,time){model.mixer.stopAllAction();for(const[o,p,q,s]of model.bind){o.position.copy(p);o.quaternion.copy(q);o.scale.copy(s);}if(clip!==null){const action=model.mixer.clipAction(model.animations[clip]);action.reset();action.setLoop(T.LoopOnce,1);action.clampWhenFinished=true;action.play();model.mixer.setTime(time);}model.scene.updateMatrixWorld(true);for(const m of model.meshes)m.skeleton.update();}
function cache(mesh){
 const g=mesh.geometry,position=g.attributes.position,normal=g.attributes.normal,skinIndex=g.attributes.skinIndex,skinWeight=g.attributes.skinWeight,index=g.index;
 need(position&&normal&&skinIndex&&skinWeight&&index,'indexed normal/skinned geometry required');need(!Object.values(g.morphAttributes).some(a=>a.length),'morphs require separate explicit handling');
 const ids=[...new Set(index.array)].sort((a,b)=>a-b),j=new Uint32Array(position.count*4),w=new Float64Array(position.count*4),bn=new Float64Array(position.count*3),B=mesh.bindMatrix.elements;let zeroOut=0;
 for(const i of ids){need(i>=0&&i<position.count,'index outside position buffer');const x=normal.getX(i),y=normal.getY(i),z=normal.getZ(i);bn.set([B[0]*x+B[4]*y+B[8]*z,B[1]*x+B[5]*y+B[9]*z,B[2]*x+B[6]*y+B[10]*z],i*3);for(let k=0;k<4;k++){j[i*4+k]=get(skinIndex,i,k);w[i*4+k]=get(skinWeight,i,k);if(w[i*4+k]!==0)need(j[i*4+k]<mesh.skeleton.bones.length,'positive weight outside actual bone palette');else if(j[i*4+k]>=mesh.skeleton.bones.length)zeroOut++;}}
 return{mesh,position,normal,index,ids,j,w,bn,zero_weight_out_of_palette_components:zeroOut};
}
function normalContext(c){
 const m=c.mesh,b=m.skeleton.boneMatrices;for(let i=0;i<b.length;i+=16)need(b[i+3]===0&&b[i+7]===0&&b[i+11]===0&&b[i+15]===1,'nonaffine bone matrices unsupported');
 // Exact affine factorization of ShaderChunk.skinnormal_vertex and
 // defaultnormal_vertex with identity view: normalMatrix(world) * B^-1 *
 // [sum(w_j * actual GPU boneMatrix_j)] * B * vec4(normal,0).
 // Deliberately no inverse transpose of the weighted bone blend.
 return{b,prefix:new T.Matrix3().getNormalMatrix(m.matrixWorld).multiply(new T.Matrix3().setFromMatrix4(m.bindMatrixInverse))};
}
function shaderNormal(c,frame,i,out){const q=i*3,bx=c.bn[q],by=c.bn[q+1],bz=c.bn[q+2],b=frame.b;let x=0,y=0,z=0;for(let k=0;k<4;k++){const w=c.w[i*4+k];if(w===0)continue;const o=c.j[i*4+k]*16;x+=w*(b[o]*bx+b[o+4]*by+b[o+8]*bz);y+=w*(b[o+1]*bx+b[o+5]*by+b[o+9]*bz);z+=w*(b[o+2]*bx+b[o+6]*by+b[o+10]*bz);}out.set(x,y,z).applyMatrix3(frame.prefix);need(Number.isFinite(out.lengthSq())&&out.lengthSq()>1e-24,'degenerate/nonfinite shader normal');return out.normalize();}
function keyFacts(a,b){need(a.animations.length===6&&b.animations.length===6,'exact six original clips required');const rows=[];for(let i=0;i<6;i++){const x=a.animations[i],y=b.animations[i];need(x.name===y.name&&x.duration===y.duration&&x.tracks.length===y.tracks.length,'actual decoded clip inventory differs');for(let j=0;j<x.tracks.length;j++){const p=x.tracks[j],q=y.tracks[j];need(p.name===q.name&&p.ValueTypeName===q.ValueTypeName&&p.getInterpolation()===q.getInterpolation()&&bytesEqual(p.times,q.times)&&bytesEqual(p.values,q.values),'actual decoded animation keys differ');}rows.push({index:i,exact_name:x.name,duration_s:x.duration,tracks:x.tracks.length,all_loaded_key_bytes_exact:true});}return rows;}
window.compare=async()=>{
 const config=await(await fetch('/PREFLIGHT.json')).json(),started=performance.now();
 const report=window.cpuReport={status:'ACTUAL_LOADED_PARITY_INCOMPLETE',source_sha256:config.source_sha256,normalized_sha256:config.normalized_sha256,source_flags:config.source_flag,positions:{tolerance_m:config.position_tolerance_m,additional_native_tolerance:config.additional_stricter_native_position_tolerance,metres_per_native_unit:config.metres_per_native_unit,maximum_delta_m:0,maximum_delta_native:0,evaluations:0,indexed_observations:0,complete:false},normals:{tolerance_degrees:config.normal_tolerance_degrees,maximum_angle_degrees:0,evaluations:0,complete:false,algebra:'normalMatrix(mesh.matrixWorld; identity view) * bindMatrixInverse * sum(weights * skeleton.boneMatrices.Float32) * bindMatrix * vec4(objectNormal,0), direction normalized; exact affine factorization, JS double arithmetic; no inverse transpose weighted blend'},poses:[],pose_count:0,poses_complete:false,decoded_key_equivalence:false,maps_decoded_equivalent:false,WebGL_contexts_created:0,renderer_camera_world_created:false,app_clip_activation:false};
 let a,b;
 try{
  need(T.ShaderChunk.skinnormal_vertex.includes('skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;')&&T.ShaderChunk.defaultnormal_vertex.includes('transformedNormal = normalMatrix * transformedNormal;'),'pinned actual shader algebra changed');report.actual_shader_chunks={skinnormal:T.ShaderChunk.skinnormal_vertex,defaultnormal:T.ShaderChunk.defaultnormal_vertex};
  [a,b]=await Promise.all([load('/inputs/source.glb'),load('/inputs/normalized.glb')]);report.clips=keyFacts(a,b);report.decoded_key_equivalence=true;
  const am=await maps(a),bm=await maps(b);report.loaded_maps={source:am,normalized:bm};need(JSON.stringify(am)===JSON.stringify(bm),'actual decoded map/material differences');report.maps_decoded_equivalent=true;
  const ac=a.meshes.map(cache),bc=b.meshes.map(cache);report.meshes=[];for(let n=0;n<3;n++){const x=ac[n],y=bc[n];need(x.mesh.userData.parityKey===y.mesh.userData.parityKey&&x.position.count===y.position.count&&bytesEqual(x.index.array,y.index.array)&&JSON.stringify(x.ids)===JSON.stringify(y.ids),'indexed vertex correspondence differs');report.meshes.push({key:x.mesh.userData.parityKey,source_name:x.mesh.name,normalized_name:y.mesh.name,vertices:x.position.count,indexed_unique_vertices:x.ids.length,index_entries:x.index.count,source_zero_weight_out_of_palette:x.zero_weight_out_of_palette_components,normalized_zero_weight_out_of_palette:y.zero_weight_out_of_palette_components});}
  report.positions.unique_vertices_per_pose=ac.reduce((s,c)=>s+c.ids.length,0);report.positions.index_entries_per_pose=ac.reduce((s,c)=>s+c.index.count,0);
  const p=new T.Vector3(),q=new T.Vector3(),na=new T.Vector3(),nb=new T.Vector3(),cross=new T.Vector3();
  function comparePose(clip,phase){const time=clip===null?null:phase*a.animations[clip].duration;pose(a,clip,time);pose(b,clip,time);let maxP=0,maxN=0,wP=null,wN=null;
   for(let n=0;n<3;n++){const x=ac[n],y=bc[n],nx=normalContext(x),ny=normalContext(y);for(const i of x.ids){x.mesh.applyBoneTransform(i,p.fromBufferAttribute(x.position,i)).applyMatrix4(x.mesh.matrixWorld);y.mesh.applyBoneTransform(i,q.fromBufferAttribute(y.position,i)).applyMatrix4(y.mesh.matrixWorld);const delta=p.distanceTo(q);need(Number.isFinite(delta),'nonfinite actual applyBoneTransform result');if(delta>maxP){maxP=delta;wP={mesh_key:x.mesh.userData.parityKey,vertex:i,source:p.toArray(),normalized:q.toArray()};}shaderNormal(x,nx,i,na);shaderNormal(y,ny,i,nb);const angle=Math.atan2(cross.crossVectors(na,nb).length(),na.dot(nb))*180/Math.PI;need(Number.isFinite(angle),'nonfinite shader direction angle');if(angle>maxN){maxN=angle;wN={mesh_key:x.mesh.userData.parityKey,vertex:i,source_normal:na.toArray(),normalized_normal:nb.toArray()};}report.positions.evaluations++;report.normals.evaluations++;}report.positions.indexed_observations+=x.index.count;}
   const row={kind:clip===null?'default':'original_clip',clip_index:clip,exact_clip_name:clip===null?null:a.animations[clip].name,phase,time_s:time,maximum_delta_native:maxP,maximum_delta_m:maxP*config.metres_per_native_unit,maximum_normal_angle_degrees:maxN,position_witness:wP,normal_witness:wN};report.poses.push(row);report.pose_count++;report.positions.maximum_delta_native=Math.max(report.positions.maximum_delta_native,maxP);report.positions.maximum_delta_m=Math.max(report.positions.maximum_delta_m,row.maximum_delta_m);report.normals.maximum_angle_degrees=Math.max(report.normals.maximum_angle_degrees,maxN);
  }
  comparePose(null,null);for(let clip=0;clip<6;clip++)for(let i=0;i<33;i++)comparePose(clip,i/32);
  report.poses_complete=report.pose_count===199;report.positions.complete=report.poses_complete;report.normals.complete=report.poses_complete;
  const pass=report.poses_complete&&report.maps_decoded_equivalent&&report.decoded_key_equivalence&&report.positions.maximum_delta_m<=config.position_tolerance_m&&report.positions.maximum_delta_native<=config.additional_stricter_native_position_tolerance&&report.normals.maximum_angle_degrees<=config.normal_tolerance_degrees;
  report.status=pass?'ACTUAL_LOADED_FULL_SURFACE_PARITY_PASS':'ACTUAL_LOADED_FULL_SURFACE_PARITY_FAIL';
 }catch(error){report.status='ACTUAL_LOADED_FULL_SURFACE_PARITY_FAIL';report.failure={name:error.name,message:error.message,stack:error.stack};}
 finally{for(const m of[a,b])if(m){m.mixer.stopAllAction();m.mixer.uncacheRoot(m.scene);}report.elapsed_ms=performance.now()-started;report.limits='All indexed unique vertex directions/positions at stated199 poses only; no GPU rounding/shading/normal-map render, continuous-time proof, gait, idle activation, photographic or world acceptance.';}
 return report;
};window.ready=true;
