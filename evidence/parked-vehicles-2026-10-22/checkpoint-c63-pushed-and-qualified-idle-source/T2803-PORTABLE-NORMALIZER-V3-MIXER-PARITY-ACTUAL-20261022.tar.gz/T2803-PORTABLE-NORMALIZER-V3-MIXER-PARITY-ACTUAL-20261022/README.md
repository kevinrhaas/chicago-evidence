# Actual loaded horse normalization parity — PASS, closed

One root-authorized CPU-only browser run compared original **41acd9…** with normalized **ceefa279…**. The full normalized Khronos receipt had **0 errors,0 warnings** before this run. No app, export, Git, renderer, camera or WebGL scene was created or changed.

The actual application's vendored **GLTFLoader** decoded both complete GLBs and their materials/maps. **AnimationMixer** evaluated the default plus **33 inclusive phases of each of all six original clips**, restoring every default local transform between poses. All loaded animation track names, interpolation, key-time bytes and value bytes matched exactly. The original Armature4 constant key remains one float32 ULP from its default; it was retained rather than silently replaced.

All **11,556 indexed vertices** across three mesh primitives were compared at all **199 poses**: **2,299,644 paired position comparisons** and the same number of normal-direction comparisons, covering **8,946,642 triangle-index references**. Repeated indices refer to the same evaluated vertex; no referenced vertex was omitted. Positions use actual Three.js `applyBoneTransform` followed by mesh world matrices.

The fixed position limit was **1e-5m**, with an additional stricter **1e-5 native-unit** limit. Maximum difference was **2.981109e-15 native units**, or **1.086337e-15m** using the existing static sidecar's0.36440688373115426m/native-unit scale. Neither model was rescaled, tilted, repositioned or otherwise adapted during comparison.

The fixed normal limit was **0.01°**; maximum difference was **8.702567e-6°**. The reader uses the exact affine factorization of the pinned shader algebra: `normalMatrix(meshWorld; identity view) × bindMatrixInverse × Σ(weight × actual Float32 boneMatrix) × bindMatrix × vec4(normal,0)`, then normalizes direction. It does **not** use an inverse transpose of the weighted bone blend. Arithmetic is JavaScript double precision over actual loaded/uniform matrix data; this is not GPU float-rounding or shaded-pixel validation.

All **nine used map bindings**, representing **six unique decoded images**, matched in decoded RGBA pixel hashes and texture/material settings. No map was stripped to make CPU loading easier. Map decoding used the actual loader and a2D canvas only; no WebGL context was requested.

`ACTUAL-LOADED-PARITY.json` is the immutable actual receipt: SHA256 **2a119de7db254f469d11b41633be15028a7d61144eafedfb4dbceb24b105f36a**. It preserves all pose times, maxima and witnesses, loaded map facts, shader chunks, source flags and exact input/caller hashes. The comparison took **2.84s**; the browser interval was **3.62s**. Browser/server closed at18:06:23UTC with zero errors and warnings. No retry occurred.

This proves the stated import parity at the stated poses. It does not append or activate idle/walk, approve a gait, prove continuous-time behavior, validate rendered shading, or establish photographic/world acceptance. The normalized idle producer remains subject to a separate root release.
