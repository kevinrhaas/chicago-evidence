# One material-only response refinement (SOURCE ONLY)

Actual viewed inputs: full retained1893 plate0095, desktop V14 native source-fullquarter and source-detail PNGs. V15 actual producer/GLB and materials were inspected as source; no V15 rendered image exists at the supplied ACTUAL path. V14 pixels are a bounded material baseline because V15 receipt says all materials and462 non-support streams unchanged; they are NOT V15 visual acceptance.

## Visible observations
The close view's large door/sidewall/roof are near-uniform dark green; narrow trim and framing scarcely separate. Source plate illustrates long light edge strokes and larger changing dark/highlight regions. Those marks are illustration, printing and scene cues, not measurable BRDF, paint colour or wood texture. Driver cushion is uniform brown; metal hub/trim has few reflection cues. Large windshield is opaque-looking grey in this view; unchanged in this proposal because changing optical/transparency rendering simultaneously would confound the finish study. Silhouette, panel curvature/faceting and closed specimen remain limiting; materials cannot repair them.

Native V14 fixture has hemisphere and one directional light, exposure1.3, but NO scene.environment. A scalar coating change can improve direct highlights but cannot generate broad studio reflections from an absent environment. Do not compensate by inflating metal albedo or exposure. First comparison must keep the actual existing light/camera/exposure; if little visible improvement, report that result. A separate existing-renderer environment proposal can follow, not bundled here.

## Fixed hypothesis and recipe
`finish-response.json` replaces only existing six material slots (glass byte-equivalent). No new batches/UVs/tangents/textures, no mesh remapping, no painted grain showing through opaque paint, no scratches/dirt/age narrative.

Body retains exact existing green linear albedo. Increase coat factor .28→.72, coat roughness .20→.16; underlying paint roughness .29→.34. This separates a narrow dielectric surface reflection from the broader pigmented substrate rather than simply making the whole diffuse body brighter. Black timber retains albedo, substrate roughness .40, coat .48/.23. It remains opaque painted timber, not exposed wooden planks.

Brown leather retains colour; roughness .67→.48 and very low reconstructed sheen (.025,.018,.012), roughness .8. This is an optical study, not an attested hide/finish. Trim retains albedo, metal1, roughness.20; no brass/chrome/silver identification. Running iron receives reconstructed opaque black paint: metal.85→0, roughness.43 with only.15 coat. Metalness models exposed surface, not substrate metallurgy. Glass remains unchanged. Roof shares original body material and remains painted-surface study; NO historical claim it was leather/canvas. Separating roof covering needs independent source/ownership evidence and would add batches, so deferred.

All optical coefficients and finishing family choices are original unmeasured engineering reconstruction. Plate does not attest chemical lacquer/varnish, exact gloss, roof covering, hardware alloy, maker of an actual1904 specimen or owner. This is not a Pullman carriage claim. Code and derived asset inherit existing GPL-3.0-or-later; supplied LICENSE copied verbatim. No external images are embedded/derived as textures; no new texture rights inputs or procedural-noise photogrammetry claim.

## Concrete producer
Existing seven producer inputs copied/pinned under source/. `generator.patch` adds optional `--material-recipe`; omission retains original code path/material JSON/extension order. The helper touches only material definitions; geometry/part ownership/anchors/transforms unchanged by construction. Exact output identity remains UNRUN, not inferred as passed.

Future separately authorized ONE generation command (NOT RUN):
```
python source/generate.py --parameters source/parameters.json --lod-recipe source/lods.json --detail near --material-recipe finish-response.json --output NEW_FRESH_OUTPUT
```
Run through existing V15 static/index packaging, not a new renderer/framework. Read back actual raw and indexed candidate: same BIN/accessors/views/meshes/nodes/scenes/parts/anchors/statistics/parameters, except material definitions and truthful study extras; same expanded P/N and bounds;33,374tri/24rawbatches/6parkedmaterialgroups. Flagoff V15 raw3a323a9b... and indexedddbbe9f... must be exact. No new textures/image decode cost; existing shader extension may change shader cost, unmeasured. Require Khronos0errors/0warnings, retain infos. Then existing native matched8 source views; same cameras/light/exposure, actual all8 inspection. No actual build/export/browser/Khronos/photographic acceptance has run for this proposal.
