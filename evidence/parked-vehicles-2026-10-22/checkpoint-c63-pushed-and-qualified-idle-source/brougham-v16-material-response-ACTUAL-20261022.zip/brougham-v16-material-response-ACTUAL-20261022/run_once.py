from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time,traceback
R=Path(__file__).parent;START=time.monotonic();ACTIVE=None;PY='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin/python';NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node';VAL='/workspace/shared/brougham-v12-largeforms-PROPOSAL-20261022/validate_raw.cjs';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(R/'ATTEMPT.lock').open('x') as f:f.write(str(os.getpid()))
receipt={'pass':False,'owner_pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'max_seconds':15,'stages':[],'scope':'One exactreviewedV16candidate+explicitflagoffbytecontrol within15s;allV15geometryexact/materialonly,existingtopology+nativeindex+Khronos;no browser/app/Git/retry/fullLOD'}
def save():(R/'OWNER.json').write_text(json.dumps(receipt,indent=2)+'\n')
def kill():
 global ACTIVE
 if ACTIVE and ACTIVE.poll() is None:
  os.killpg(ACTIVE.pid,signal.SIGKILL);ACTIVE.wait(timeout=1)
 ACTIVE=None;receipt['owned_child_pid']=None

def interrupted(signum,frame):raise RuntimeError('Owner interrupted '+str(signum))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def run(label,args):
 global ACTIVE
 remain=13-(time.monotonic()-START)
 if remain<=0:raise TimeoutError('13s workdeadline')
 ACTIVE=subprocess.Popen(['nice','-n','15',*args],env=env,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True);receipt.update(phase=label,owned_child_pid=ACTIVE.pid);save()
 try:out,err=ACTIVE.communicate(timeout=remain)
 except subprocess.TimeoutExpired:kill();raise TimeoutError('13s workdeadline '+label)
 (R/(label+'.stdout')).write_text(out);(R/(label+'.stderr')).write_text(err);rc=ACTIVE.returncode;ACTIVE=None;receipt['stages'].append({'label':label,'returncode':rc,'owner_elapsed_seconds':time.monotonic()-START});receipt['owned_child_pid']=None;save()
 if rc:raise ValueError('Actual stage failed '+label+';preservefailure,noamendment/retry')
try:
 for row in json.loads((R/'PREPARED-INPUTS.json').read_text())['files']:
  if sha(R/row['path'])!=row['sha256']:raise ValueError('Preparedsourcechanged '+row['path'])
 if (R/'raw').exists() or (R/'portable-near').exists():raise ValueError('Freshoutputonly')
 if sha(Path('/workspace/shared/brougham-v14-footplates-ACTUAL-20261022/raw/brougham.glb'))!='ed15f00934809cf04f7946377c18a6d3c2c0a5501041ebcd5ff257b96a1d8f8e':raise ValueError('Frozenbaselinechanged')
 save();run('flag-off-generation',[PY,str(R/'source/generate.py'),'--parameters',str(R/'source/parameters.json'),'--detail','near','--lod-recipe',str(R/'source/lods.json'),'--output',str(R/'flag-off')]);run('generation',[PY,str(R/'source/generate.py'),'--parameters',str(R/'source/parameters.json'),'--detail','near','--lod-recipe',str(R/'source/lods.json'),'--material-recipe',str(R/'finish-response.json'),'--output',str(R/'raw')]);receipt['actual_sha256']=sha(R/'raw/brougham.glb');save()
 run('material-only',[PY,str(R/'material_only_check.py')]);run('ownership',[PY,str(R/'check_actual.py')]);run('portable-near',[PY,str(R/'portable_near.py')]);run('khronos-raw',[NODE,VAL,str(R/'raw/brougham.glb'),str(R/'KHRONOS-RAW.json')]);run('khronos-near',[NODE,VAL,str(R/'portable-near/brougham-near.glb'),str(R/'KHRONOS-NEAR.json')]);receipt['pass']=True
except BaseException as e:receipt['failure']=repr(e);receipt['traceback']=traceback.format_exc()
finally:kill();receipt.update(lifecycle='CLOSED',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-START);save()
print(json.dumps(receipt));raise SystemExit(0 if receipt['pass'] else 1)
