from pathlib import Path
import sys,json,hashlib,copy,struct
R=Path(__file__).parent;B=Path('/workspace/shared/brougham-v15-slender-step-supports-ACTUAL-20261022');sys.path.insert(0,str(R/'source'))
from index_streams import read_glb,write_indexed
from material_response import apply_finish
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a,ab=read_glb(B/'raw/brougham.glb');c,cb=read_glb(R/'raw/brougham.glb');recipe=json.loads((R/'finish-response.json').read_text());m,ext=apply_finish(a['materials'],recipe)
assert c['materials']==m and len(m)==6 and m[5]==a['materials'][5]
assert [m[i]['pbrMetallicRoughness']['baseColorFactor'] for i in range(6)]==[x['pbrMetallicRoughness']['baseColorFactor'] for x in a['materials']]
assert c['extensionsUsed']==sorted(set(a['extensionsUsed']+ext))==['KHR_materials_clearcoat','KHR_materials_sheen']
cc=copy.deepcopy(c);aa=copy.deepcopy(a);study=cc['extras'].pop('material_study');assert study=={'recipe_sha256':H(R/'finish-response.json'),'finish':'Original unmeasured reconstruction,not period chemistry/color calibration','geometry_changed':False,'appearance_accepted':False}
for key in ['materials','extensionsUsed']:cc.pop(key);aa.pop(key)
assert cc==aa and cb==ab, 'All nonmaterial JSON and entire BIN exact V15'
assert json.loads((R/'raw/brougham.json').read_text())==c['extras']
assert H(R/'flag-off/brougham.glb')==H(B/'raw/brougham.glb')=='3a323a9b0033a9d1493c5e3434dd687f183bba1cb8551bc306a3738799e8d185'
assert (R/'flag-off/brougham.json').read_bytes()==(B/'raw/brougham.json').read_bytes()
write_indexed(R/'flag-off/brougham.glb',R/'flag-off/brougham-near.glb');assert H(R/'flag-off/brougham-near.glb')==H(B/'portable-near/brougham-near.glb')=='ddbbe9f20779ddaa103fe4f28652d4e984440f1ebabf8b540f322915e4e09eca'
report={'pass':True,'all_nonmaterial_JSON_exact_V15_except_explicit_material_study':True,'entire_BIN_exact_V15':True,'slots':6,'replaced_slots':[0,1,2,3,4],'glass_slot5_exact':True,'all_base_colors_exact':True,'extensionsUsed':c['extensionsUsed'],'flag_off_actual_raw_GLB_byteexact':True,'flag_off_actual_raw_JSON_byteexact':True,'flag_off_actual_indexed_near_byteexact':True,'candidate_raw_sha256':H(R/'raw/brougham.glb'),'candidate_raw_bytes':(R/'raw/brougham.glb').stat().st_size,'no_visual_acceptance':True}
(R/'MATERIAL-ONLY-CHECK.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
