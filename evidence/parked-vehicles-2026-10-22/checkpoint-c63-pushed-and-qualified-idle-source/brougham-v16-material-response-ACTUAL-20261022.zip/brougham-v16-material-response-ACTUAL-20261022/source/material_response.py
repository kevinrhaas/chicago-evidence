# SPDX-License-Identifier: GPL-3.0-or-later
"""Original unmeasured scalar PBR finish study; no geometry/IO at import."""
import copy,math

def require(q,message):
 if not q:raise ValueError(message)
def apply_finish(baseline,recipe):
 require(recipe.get('schema')==1 and recipe.get('production_accepted') is False,'Unaccepted schema1 study only')
 require([m['name']for m in baseline]==recipe['baseline_material_names'],'Exact original six material cohort')
 rows=recipe['materials'];require(len(rows)==6 and rows[5] is None,'Six slots; glass unchanged')
 allowed={'KHR_materials_clearcoat':{'clearcoatFactor','clearcoatRoughnessFactor'},'KHR_materials_sheen':{'sheenColorFactor','sheenRoughnessFactor'}}
 result=copy.deepcopy(baseline);extensions=set()
 for i,m in enumerate(rows):
  if m is None:continue
  require(set(m)<= {'name','pbrMetallicRoughness','extensions'},'No unsupported material fields')
  p=m['pbrMetallicRoughness'];require(set(p)=={'baseColorFactor','metallicFactor','roughnessFactor'},'Scalar-only PBR recipe')
  require(len(p['baseColorFactor'])==4 and p['baseColorFactor'][3]==1,'Opaque original material')
  values=list(p['baseColorFactor'])+[p['metallicFactor'],p['roughnessFactor']]
  for ext,data in m.get('extensions',{}).items():
   require(ext in allowed and set(data)==allowed[ext],'Standard scalar glTF material extension only')
   extensions.add(ext)
   for value in data.values():values.extend(value if isinstance(value,list)else[value])
  require(all(type(v)in(int,float)and math.isfinite(v)and 0<=v<=1 for v in values),'Finite unit-range optical coefficients')
  result[i]=copy.deepcopy(m)
 return result,sorted(extensions)
