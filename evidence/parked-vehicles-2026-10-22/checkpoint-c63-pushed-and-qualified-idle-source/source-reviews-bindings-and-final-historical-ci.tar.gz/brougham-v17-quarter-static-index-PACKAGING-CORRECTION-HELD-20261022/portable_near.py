from pathlib import Path
import sys,json,hashlib,shutil,importlib.util
R=Path(__file__).parent;sys.path.insert(0,str(R/'source'))
from index_streams import read_glb,write_indexed
from static_master import static_master_contract
spec=importlib.util.spec_from_file_location('existing_independent_readers','/workspace/shared/brougham-v13-portable-intake-20261022/proposed/chicago/4d/tools/transport/brougham/check_portable.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
raw=R/'raw/brougham.glb';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();g,b=read_glb(raw);sig,tri=v.expanded(g,b);assert tri==33502;world=v.world_nodes(g);bounds=v.decoded_bounds(g,b,world)
out=R/'portable-near';out.mkdir();shutil.copy2(raw,out/'brougham-source.glb');shutil.copy2(R/'source/LICENSE',out/'LICENSE');encoded=write_indexed(raw,out/'brougham-near.glb');j,bb=read_glb(out/'brougham-near.glb');isig,itri=v.expanded(j,bb)
assert isig==sig==encoded['expanded_triangle_PN_sha256'] and itri==tri and j['nodes']==g['nodes'] and j['materials']==g['materials'] and j['scenes']==g['scenes'] and v.decoded_bounds(j,bb,v.world_nodes(j))==bounds
baseline_side=json.loads(Path('/workspace/shared/brougham-v15-slender-step-supports-ACTUAL-20261022/portable-near/brougham.json').read_text());side=json.loads(json.dumps(baseline_side));side.update(revision='v17_recessed_opaque_quarter_near_study',source_master_sha256=h(raw),near_actual_visual_evidence='Actual V17 two-opaque-quarter geometry study, not yet rendered; actual V15 matchedsource8 remains separate historical baseline.',lods=[{'detail':'near','file':'brougham-near.glb','triangles':tri,'raw_mesh_batches':len(g['meshes']),'parked_material_groups':7,'nodes':len(g['nodes']),'bounds_m':bounds,**encoded}],static_master=static_master_contract(g,b,world,h(raw)),status='Actual V17 raw/indexed-near quarter geometry study only; no V17 image/mainworld/publication/fullLOD/photographic/occupied acceptance',source_history_note='Historical raw/parameter V10/V11/V12 notes remain lineage. V17 changes only two quarter panels, all464otherparts exact; sixoriginalmaterials exact plus one explicitlyunidentified darkopaque material. Unmeasured optics, actual response and hidden attachment/contact remain open.',pending_deliverables=['near appearance','mid/far V17 delivery','normalmain/phone/published qualification','photographic review','full fit/doors/hitch/boarding/collision'])
expected_static=json.loads(json.dumps(baseline_side['static_master']));expected_static['source_master_sha256']=h(raw)
# Two newly inserted inset records shift original source references, not measured interfaces.
# Every other static field still compares exactly; do not waive coordinate/capability checks.
base_doc,_=read_glb(Path('/workspace/shared/brougham-v15-slender-step-supports-ACTUAL-20261022/raw/brougham.glb'))
kept=[i for i,p in enumerate(g['extras']['parts']) if p['name']!='rear_quarter_recessed_surface']
assert len(kept)==len(base_doc['extras']['parts'])==466
part_map=dict(enumerate(kept))
assert all(all(base_doc['extras']['parts'][i][k]==g['extras']['parts'][j][k] for k in ['name','frame','material']) for i,j in part_map.items())
assert {i:part_map[i] for i in [1,12,16,27]}=={1:1,12:13,16:17,27:29}
for entry in expected_static['entries']:
 for key in ['door_part_index','step_part_index']:entry[key]=part_map[entry[key]]
assert side['anchors']==baseline_side['anchors'] and side['static_master']==expected_static;assert len(side['anchors'])==13 and len(side['static_master']['named_targets'])==8 and all(x is False for x in side['static_master']['capabilities'].values()) and len(side['static_master']['collision_proxy']['components'])==9
(out/'brougham.json').write_text(json.dumps(side,indent=2)+'\n');(out/'BUILD-RECEIPT.json').write_text(json.dumps({'source_generated_once':True,'near_lossless_PN_exact':True,'rows':side['lods'],'not_regenerated_mid_far':True,'originalV13_MASTER_guard_unmodified':True},indent=2)+'\n')
report={'pass':True,'scope':'Actual existing native indexer+independent generic source readers on V17near only; old canonicalV13check() intentionallynotinvoked orchanged','source_sha256':h(raw),'indexed_near_sha256':h(out/'brougham-near.glb'),'source_bytes':raw.stat().st_size,'indexed_bytes':(out/'brougham-near.glb').stat().st_size,'actual_triangles':tri,'lossless_expanded_PN_sha256':sig,'nodes':len(g['nodes']),'meshes':len(g['meshes']),'materials':len(g['materials']),'anchors':len(side['anchors']),'metadata_targets':8,'inert_collision_proxy_boxes':9,'actual_global_bounds_m':bounds,'actual_updated_entries':side['static_master']['entries'],'limits':'No mid/far generation, repeat-generation proof, runtime/browser/image/collision/human or photographic acceptance'}
(R/'PORTABLE-NEAR-CHECK.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
