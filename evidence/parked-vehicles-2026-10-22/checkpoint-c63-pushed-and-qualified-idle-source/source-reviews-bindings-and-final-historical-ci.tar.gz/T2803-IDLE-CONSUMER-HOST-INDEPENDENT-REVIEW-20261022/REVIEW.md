CLEAR for separately root-authorized gentle head/tail idle enable, on the pinned source consumer/host only. No app edits or browser/runtime execution by this reviewer.

The model and idle data stay lazy behind era/reach/tier guards. Light still reads the existing placement manifest, but no model or idle contract. Model bytes and both idle JSON files are hashed to exact reviewed pins. Revisions and disposal checks after awaits prevent a stale asynchronous candidate becoming active. Clone-owned Mixer starts after existing source/ground verification; only declared leaves animate. All original six actions remain unplayed.

Main supplies its existing capped host frameDt and explicit hold/gate pause. The consumer gates advancement on document visibility, ancestor visibility, reconstructed confidence, distance, reduced motion and explicit pause. It makes no wall-clock phase claim: suspended RAF can supply the existing capped .25s first-visible delta.

Picking updates matrices/skeleton/current skinned spheres at selection rather than scanning vertices every frame. Retirement removes the clone, stops/uncaches its Mixer, disposes clone skeletons/materials/geometry and then shared source resources. Async stale or failed parses are cleaned; no automatic same-revision retry.

The separate actual385-pose CPU proof is02754399. This source review does not establish world rendering, native visuals, complete selfcontact or photographic completion. Root owns final enable flags and public validation; capability/status booleans must agree with activation.
