from pathlib import Path
import json,subprocess,importlib.util,sys,hashlib,re,base64,datetime
P=Path('/workspace/shared/human1175-4dee6d5-FINITE-CI-AUDIT-20261022');D=Path('/workspace/shared/human1175-2f1bad56-IMMUTABLE-SOURCE-SNAPSHOT-CI-ONLY-PREPARED-HELD-20261022');sys.path.insert(0,str(D));s=importlib.util.spec_from_file_location('strict',D/'collect-GET-only.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);H=lambda b:hashlib.sha256(b).hexdigest();records=[];proofs=[]
def get(n,e):
 r=subprocess.run(['gh','api','--method','GET','repos/'+m.REPO+'/'+e],capture_output=True,timeout=40);(P/(n+'.stdout')).write_bytes(r.stdout);(P/(n+'.stderr')).write_bytes(r.stderr);records.append({'method':'GET','endpoint':e,'sha256':H(r.stdout),'returncode':r.returncode});m.need(r.returncode==0,r.stderr.decode());return r.stdout
def obj(n,e):return json.loads(get(n,e))
try:
 for i in [39824984068,39824984106,39817882437]:
  run=obj('run-'+str(i),'actions/runs/'+str(i));historical=i==39817882437;head='b0924b41c25d0d9bf975feb9b6e245a1b3f288e3' if historical else '4dee6d5f6f04681133316538ba5d8d5ceea21940';path=m.SMOKE if historical else (m.BAKE if i==39824984106 else '.github/workflows/chicago-4d-pr-stuck.yml');event='workflow_dispatch' if historical else 'push';m.need(run['id']==i and run['head_sha']==head and run['head_branch']==m.BRANCH and run['run_attempt']==1 and run['path']==path and run['event']==event and run['status']=='completed' and run['conclusion']=='success' and run['repository']['full_name']==m.REPO,'Actual run identity/status differs')
  wf=obj('workflow-'+str(i),'actions/workflows/'+Path(path).name);m.need(wf['id']==run['workflow_id'] and wf['path']==path and wf['state']=='active','Workflow binding differs')
  paths=[path]+(['chicago/4d/tools/smoke_renderer.mjs','chicago/4d/renderers/web/js/humans.js'] if historical else [])
  for n,p in enumerate(paths):
   raw=subprocess.check_output(['git','-C','/workspace/chicago','show',head+':'+p]);blob=subprocess.check_output(['git','-C','/workspace/chicago','rev-parse',head+':'+p]).decode().strip();remote=obj('source-'+str(i)+'-'+str(n),'git/blobs/'+blob);m.need(remote['sha']==blob and H(base64.b64decode(remote['content']))==H(raw),'Source blob bytes differ')
  inv=obj('jobs-'+str(i),'actions/runs/'+str(i)+'/attempts/1/jobs?per_page=100');m.need(inv['total_count']==len(inv['jobs']),'Truncated jobs')
  if path==m.BAKE:job,proof=m.audit_guarded_bake_jobs(inv['jobs'],run,head)
  else:
   m.need(len(inv['jobs'])==1,'Unexpected jobs');job=inv['jobs'][0];name,steps=('smoke',m.SMOKE_STEPS) if historical else m.NORMAL[path];proof=m.audit_job(job,run,head,name,steps)
  log=get('log-'+str(i),'actions/jobs/'+str(job['id'])+'/logs');text=log.decode();proof.update(actual_checkout_sha=m.checkout_sha(text,head),job_log_sha256=H(log),source_label='HISTORICAL_B092_DESKTOP14' if historical else 'CURRENT_4DEE_PUSH_NORMAL',workflow_path=path)
  if path==m.BAKE:proof.update(m.audit_guarded_bake_log(text))
  if historical:
   cell=m.smoke_cell(text);m.need(cell==('desktop','14'),'Wrong actual smoke cell');proof.update(viewport='desktop',stage='14',**m.audit_population_boot(text,'desktop'))
  check=obj('check-'+str(i),job['check_run_url'].split('/repos/'+m.REPO+'/')[1]);m.need(check['head_sha']==head and check['name']==proof['job_name'] and check['status']=='completed' and check['conclusion']=='success' and re.search('/actions/runs/'+str(i)+'(?:/|$)',check['details_url']),'Check binding differs');proofs.append(proof)
 summary={'strict_proofs':proofs,'current_4dee_normal_strict_successes':2,'current_4dee_normal_missing_from_actual_check_inventory':['gate','humans','moving'],'historical_b092_desktop14_strict_SUCCESS':True,'current_head_all5_PASS':False,'merge_qualification':False,'POSTs':0,'observer':False,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat()};(P/'STRICT-SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'strict':len(proofs),'current4dee':2,'historicalb092desktop14':True,'missing':['gate','humans','moving'],'path':str(P/'STRICT-SUMMARY.json')}))
finally:(P/'GET-RECEIPTS.json').write_text(json.dumps(records,indent=2)+'\n')
