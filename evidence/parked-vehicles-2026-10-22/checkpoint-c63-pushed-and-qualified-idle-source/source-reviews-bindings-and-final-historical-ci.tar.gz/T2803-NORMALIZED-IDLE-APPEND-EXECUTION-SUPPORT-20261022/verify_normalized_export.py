from pathlib import Path
import json,hashlib,struct,math,time
import sys
R=Path(sys.argv[1]);start=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=Path('/workspace/shared/T2803-PORTABLE-NORMALIZER-V3-ACTUAL-20261022/horse-sevket-portable-import-v3.glb');derived=R/'horse-sevket-portable-filtered-idle-v1.glb';bundle=Path('/workspace/shared/T2803-sevket-native-clips-20261022/engine-neutral-idle-clip.json')
def read(p):
 raw=p.read_bytes();assert struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw));n,k=struct.unpack_from('<II',raw,12);assert k==0x4e4f534a;g=json.loads(raw[20:20+n]);size,kind=struct.unpack_from('<II',raw,20+n);assert kind==0x004e4942 and 28+n+size==len(raw);return raw,g,raw[28+n:]
a,g,b=read(original);d,j,db=read(derived);assert sha(original)=='ceefa279b1602b97eac707cec19b2fbbb25c4442788981d82b20ac99ca205afc';receipt=json.loads((R/'APPEND-RECEIPT.json').read_text());assert sha(derived)==receipt['derived_sha256'];assert len(a)==3356764 and len(d)==receipt['derived_bytes'];assert sha(bundle)=='a759bf114a84a94f067fc50003473527677082dd6a4c6337bdff39babc7e73ba'
assert db[:len(b)]==b and len(db)-len(b)==19300
for k,v in g.items():
 if k not in ['buffers','bufferViews','accessors','animations']:assert j[k]==v,k
for k,extra in [('bufferViews',3),('accessors',3),('animations',1)]:assert j[k][:len(g[k])]==g[k] and len(j[k])-len(g[k])==extra
assert {k:v for k,v in j['buffers'][0].items() if k!='byteLength'}=={k:v for k,v in g['buffers'][0].items() if k!='byteLength'} and j['buffers'][0]['byteLength']==len(db)
for v in g['bufferViews']:
 off=v.get('byteOffset',0);assert db[off:off+v['byteLength']]==b[off:off+v['byteLength']]
clip=j['animations'][6];data=json.loads(bundle.read_text());assert clip['name']==data['animation']['name']=='sevket_reconstructed_head_tail_idle_v1';assert clip['extras']==data['animation']['extras'];assert len(clip['channels'])==len(clip['samplers'])==2 and {c['target']['node'] for c in clip['channels']}=={17,19}
def stream(i):
 ac=j['accessors'][i];v=j['bufferViews'][ac['bufferView']];assert ac['componentType']==5126 and not v.get('byteStride');width={'VEC4':4,'SCALAR':1}[ac['type']];off=v.get('byteOffset',0)+ac.get('byteOffset',0);assert off%4==0;return ac,db[off:off+ac['count']*width*4]
tracks=[]
for channel,expected in zip(clip['channels'],data['animation']['tracks']):
 assert channel['target']==expected['target'];sampler=clip['samplers'][channel['sampler']];assert sampler['interpolation']=='CUBICSPLINE'
 inp,times=stream(sampler['input']);out,vals=stream(sampler['output']);assert inp['type']=='SCALAR' and inp['count']==193 and inp['min']==[0] and inp['max']==[12];assert out['type']=='VEC4' and out['count']==579
 assert times==struct.pack('<193f',*expected['sampler']['input_times_s']);assert vals==struct.pack('<2316f',*expected['sampler']['output_in_value_out_quaternions_xyzw']);assert not j['nodes'][channel['target']['node']].get('children')
 q=struct.unpack('<2316f',vals);assert all(math.isfinite(x) for x in q);default=j['nodes'][channel['target']['node']]['rotation'];assert list(q[4:8])==list(q[-8:-4])==default;assert all(x==0 for x in q[:4]+q[8:12]+q[-12:-8]+q[-4:]);tracks.append({'node':channel['target']['node'],'actual_exported_float32_stream_equals_reviewed_bundle':True,'input_count':193,'output_VEC4_count':579,'actual_new_view_no_byteStride':True,'native_endpoint_values_and_zero_tangents':True})
baseline=Path('/workspace/shared/T2803-PORTABLE-NORMALIZER-V3-ACTUAL-20261022/KHRONOS-ACTUAL-V3.json');o=json.loads(baseline.read_text());n=json.loads((R/'KHRONOS-ACTUAL-NORMALIZED-IDLE.json').read_text());issues=n['report']['issues'];assert o['report']['issues']==issues;assert issues['numErrors']==0 and issues['numWarnings']==0 and not issues['truncated'];assert not any(m.get('pointer','').startswith('/animations/6') for m in issues['messages'])
report={'status':'ACTUAL_NORMALIZED_APPEND_STRUCTURAL_CURVE_KHRONOS_PASS_ONLY','source_sha256':sha(original),'derived_sha256':sha(derived),'derived_bytes':len(d),'normalized_BIN_bytes':len(b),'appended_BIN_bytes':len(db)-len(b),'normalized_buffer_prefix_and_all_views_exact':True,'normalized_nodes_skins_inversebinds_meshes_maps_materials_accessors_and_6animations_exact':True,'original_six_decoded_keys_preserved_by_verified_normalized_lineage':True,'new_tracks':tracks,'baseline_khronos_sha256':sha(baseline),'derived_khronos_sha256':sha(R/'KHRONOS-ACTUAL-NORMALIZED-IDLE.json'),'whole_asset_errors':issues['numErrors'],'whole_asset_warnings':issues['numWarnings'],'whole_asset_infos':issues['numInfos'],'untruncated':not issues['truncated'],'new_animation6_issues':0,'issue_arrays_exact':True,'elapsed_seconds':time.monotonic()-start,'scope':'Actual normalized derivative byte/curve/conformance proof only; idle Mixer/fullsurface/contact/selfcontact/native visuals and application acceptance NOT RUN'}
(R/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
