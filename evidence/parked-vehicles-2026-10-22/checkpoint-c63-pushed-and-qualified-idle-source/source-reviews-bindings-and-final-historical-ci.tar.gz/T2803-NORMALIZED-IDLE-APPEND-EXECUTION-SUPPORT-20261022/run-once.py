import hashlib,json,pathlib,subprocess,sys
P=pathlib.Path('/workspace/shared/T2803-NORMALIZED-LINEAGE-IDLE-SOURCE-HELD-20261022')
H=pathlib.Path(__file__).resolve().parent
O=pathlib.Path('/workspace/shared/T2803-NORMALIZED-IDLE-APPEND-ACTUAL-20261022')
R=pathlib.Path('/workspace/shared/T2803-PORTABLE-NORMALIZER-V3-MIXER-PARITY-ACTUAL-20261022/ACTUAL-LOADED-PARITY.json')
assert not O.exists()
assert hashlib.sha256((P/'append_normalized_idle_glb.py').read_bytes()).hexdigest()=='9118e85588e677f9f4c19f2ebbc9e56815997c7361468eb7238504ecc4a6c3b1'
assert hashlib.sha256(R.read_bytes()).hexdigest()=='2a119de7db254f469d11b41633be15028a7d61144eafedfb4dbceb24b105f36a'
subprocess.run([sys.executable,'-B',str(P/'append_normalized_idle_glb.py'),'--lane-released','--output-dir',str(O),'--parity-receipt',str(R),'--parity-sha256','2a119de7db254f469d11b41633be15028a7d61144eafedfb4dbceb24b105f36a'],check=True,stdout=subprocess.DEVNULL)
subprocess.run(['node',str(H/'validate-normalized-idle.cjs'),str(O)],check=True)
subprocess.run([sys.executable,'-B',str(H/'verify_normalized_export.py'),str(O)],check=True)
