# V14 versus actual V15 native component comparison

One separately authorized capture, after horse native-parity browser CLOSED. Exactly8 normal PNGs: desktop1280x800/mobile390x780, V14baseline/V15actual indexed-near, original fixed source detail/fullquarter camera/lights/normal settings. Near100/far1000 and exact nondepth projection retained. All model nodes/pole enabled; fullquarter all-bounds guard unchanged; original GL/error/framing/zero-resource cleanup unchanged. Owner175s/browser165s, no retry. Sourceplate0095/camera exact previous fixture; source-extension/owner exact previous bytes.

Actual V15 one-shot2.222s validated:33374triangles; only step_support13/14/28/29 change,462otherparts exact including pads12/27. Same nodes/materials/anchors/staticmetadata/globalbounds. Candidate remains reconstructed; no world, photographic, period-dimension, material, occupied, entry, structural, exhaustive intersection or hitch acceptance. No browser ran during preparation.
