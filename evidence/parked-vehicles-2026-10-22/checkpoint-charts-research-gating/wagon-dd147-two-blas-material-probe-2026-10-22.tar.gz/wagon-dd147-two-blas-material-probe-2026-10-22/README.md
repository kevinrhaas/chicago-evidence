# Two material-only BLAS architecture probes: CLOSED, concrete output sensitivity

Exactly two sequential unchanged production material invocations ran with native CPython3.11.17, NumPy2.3.5, SciPy1.17.0 and Pillow12.3.0. Actual OpenBLAS get_corename/get_num_threads APIs confirmed Haswell then Nehalem, each1thread/nice15. Source/input hashes remained exact; no package installation, hardware regeneration, full gate, browser, source patch, Git/index/mirror/CI operation or third invocation ran. Total invocation wall time8.911120495s, below released120s combined ceiling; both exited0 and controller/child PIDs departed.

| Controlled core | Actual output SHA256 | Difference from frozen0138 baseline |
| --- | --- | --- |
| Haswell | cf2adf71f424dcea8d7d076e7cbf9837b4a35ccf02388068e14fe44ec16e71a3 | JSON exact; BIN36858bytes differ;1UVstream/12tangentstreams |
| Nehalem | 4fcbdbe6e7a9790bbc40d1e04d0ca477d4db0f03a2a8611b8318fb231e4576bf | JSON2tangent-accessor-extrema differ; BIN69287bytes differ;1UVstream/12tangentstreams |

All POSITION/NORMAL streams and all9 encoded PNG/decoded RGB streams are exact for both probes. UV changes localize to vehicle_body_iron: Haswell4bench washers+4stems; Nehalem adds16stakebolts.64parts have UV/tangent differences;60parts have tangentXYZ differences; tangent handedness flips912/2544vertices respectively. Maximum absolute UV delta0.956664741; tangent component delta2.0. These are not merely last-bit or PNG compression differences. Full per-stream counts/extrema/hash, per-part ownership ranges and study-receipt deltas are saved as JSON; both complete generated outputs remain intact.

This proves dependence on the controlled BLAS architecture axis in this fixed native numerical stack. It does not identify actual CI's resolved dependencies/core or claim that either hash equals CI's unsaved failing material. The existing0138 parent guard would properly refuse both outputs. NEXT-FIX-ASSESSMENT.md describes a viable original-authored-chart input contract retaining every existing byte guard; no proposal or source implementation was made.

EXACT-COMMANDS.txt, controller.py, material-wrapper.py, both runtime JSONs and logs preserve reproduction commands and actual numerical backend environment. frozen-inputs includes exact04820hardware,2fbparts,materialrecipe,unchanged producer sources and exact0138baseline for self-contained comparison. Native runtime/package binaries are environment dependencies identified in the runtime records; they are not bundled. All work is outside the application.
