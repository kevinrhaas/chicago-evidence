import os,sys,json,platform,ctypes,io,contextlib,runpy,time
from pathlib import Path
import numpy as np,scipy,PIL
root=Path(sys.argv[1]);arch=sys.argv[2];script=Path(sys.argv[3]);arguments=sys.argv[4:]
libraries=sorted((Path(np.__file__).resolve().parent.parent/'numpy.libs').glob('*openblas*.so'))
assert len(libraries)==1,libraries
lib=ctypes.CDLL(str(libraries[0]))
def function(names,restype):
 for name in names:
  try:f=getattr(lib,name);f.restype=restype;return name,f()
  except AttributeError:pass
 raise RuntimeError('Actual OpenBLAS runtime query unavailable: '+str(names))
core_symbol,core=function(['scipy_openblas_get_corename64_','openblas_get_corename64_','openblas_get_corename'],ctypes.c_char_p)
thread_symbol,threads=function(['scipy_openblas_get_num_threads64_','openblas_get_num_threads64_','openblas_get_num_threads'],ctypes.c_int)
config_symbol,config=function(['scipy_openblas_get_config64_','openblas_get_config64_','openblas_get_config'],ctypes.c_char_p)
text=io.StringIO()
with contextlib.redirect_stdout(text):np.show_config();np.show_runtime()
runtime={'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'numpy':np.__version__,'scipy':scipy.__version__,'Pillow':PIL.__version__,'requestedArchitecture':arch,'actualOpenBLASCore':core.decode(),'actualOpenBLASThreads':threads,'library':str(libraries[0]),'coreQuerySymbol':core_symbol,'threadQuerySymbol':thread_symbol,'OpenBLASConfig':config.decode(),'nice':os.getpriority(os.PRIO_PROCESS,0),'controlledEnvironment':{k:os.environ[k]for k in ['OPENBLAS_CORETYPE','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','BLIS_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS','PYTHONDONTWRITEBYTECODE']},'numpyConfigAndRuntime':text.getvalue()}
(root/(arch+'-runtime.json')).write_text(json.dumps(runtime,indent=2)+'\n')
assert core.decode().lower()==arch.lower(),runtime
assert threads==1 and runtime['nice']>=15,runtime
sys.path.insert(0,str(script.parent));sys.argv=[str(script),*arguments]
runpy.run_path(str(script),run_name='__main__')
