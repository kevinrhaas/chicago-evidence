from pathlib import Path
import json,hashlib,shutil,difflib,tarfile,sys
import jsonschema
P=Path(__file__).parent;E=P/'proposed/tickets/evidence/period-transport-2026-10-18';A=Path('/workspace/chicago/chicago/4d');T=Path('/workspace/chicago-tickets');sha=lambda b:hashlib.sha256(b).hexdigest()
f=E/'vehicle-master-handoff.json';f.write_text(f.read_text().replace('GLΒ','GLB'))
# Attach exact small public metadata/error receipts, never source pixels.
N=E/'t2792-network';N.mkdir(exist_ok=True)
for f in (P/'network').glob('*.json'):shutil.copy2(f,N/f.name)
f=E/'inspected-image-register.json';a=json.loads(f.read_text());a['live_loc_metadata_evidence']='t2792-network/';f.write_text(json.dumps(a,indent=2)+'\n')
pre=json.loads((P/'PREIMAGES.json').read_text());newfiles=[]
for root in ['tickets','app']:
 for f in sorted((P/'proposed'/root).rglob('*')):
  if f.is_file() and str(f.relative_to(P/'proposed'))not in pre:pre[str(f.relative_to(P/'proposed'))]=None
# Validate current preimage identity and absence, all JSON and source schema.
checks=[]
for rel,pin in pre.items():
 repo=T if rel.startswith('tickets/')else A.parents[1];target=repo/rel.split('/',1)[1]
 if pin is None:assert not target.exists(),str(target)+' already exists'
 else:assert target.is_file() and sha(target.read_bytes())==pin,str(target)+' preimage changed'
checks.append('All exact live preimages match; all new targets absent')
for f in (P/'proposed').rglob('*.json'):json.loads(f.read_text())
checks.append('Every proposed JSON parses')
schema=json.loads((A/'data/source.schema.json').read_text())
for f in (P/'proposed/app/chicago/4d/data/sources').glob('*.json'):jsonschema.Draft202012Validator(schema).validate(json.loads(f.read_text()))
checks.append('All3 proposed source records validate against existing source schema')
reg=json.loads((E/'inspected-image-register.json').read_text());assert len(reg['relevant_inspected_images'])==14;assert len({x['id']for x in reg['relevant_inspected_images']})==14;assert len(reg['current_coverage']['targeted_pass_ids'])==83;assert reg['snapshot_current_prairie_records']==947;assert reg['current_coverage']['current_records_without_recorded_visual_coverage']==863
checks.append('14 unique detailed viewer records; exact83+1 Prairie scope;947−84=863;24 pre-fire IDs')
hand=json.loads((E/'vehicle-master-handoff.json').read_text());assert hand['current_compatibility_profiles'][0]['root_socket_straight_pose_m']==[0,.535,4.275];assert hand['current_compatibility_profiles'][2]['capabilities']['boarding']is False
available={f.stem for f in (A/'data/sources').glob('*.json')}|{f.stem for f in(P/'proposed/app/chicago/4d/data/sources').glob('*.json')}
assert all(x['source_id']in available for x in hand['selected_next_historical_masters']);assert all(x['source_id']in available for x in json.loads((E/'selected-cleared-source-register.json').read_text()))
checks.append('All selected-master and cleared-source IDs resolve in existing+proposed sources; reserved/covered capabilities false')
for f in (P/'proposed/tickets/evidence/period-transport-2026-10-18').glob('*.md'):
 import re
 for link in re.findall(r'\]\(([^):]+)\)',f.read_text()):
  if link.startswith('http')or ' 'in link:continue
  assert (f.parent/link).exists()or(T/'evidence/period-transport-2026-10-18'/link).exists(),str(f)+' bad local link '+link
checks.append('All relative Markdown links resolve in proposal+existing evidence')
(P/'PREIMAGES.json').write_text(json.dumps(pre,indent=2)+'\n')
# Two exact-preimage patches, no application. The downstream root must validate/commit normally.
(P/'patches').mkdir(exist_ok=True)
for root in ['tickets','app']:
 patch=[]
 for f in sorted((P/'proposed'/root).rglob('*')):
  if not f.is_file():continue
  rel=str(f.relative_to(P/'proposed'/root));before=P/'preimages'/root/rel;old=before.read_text().splitlines(keepends=True)if before.exists()else[]
  patch.extend(difflib.unified_diff(old,f.read_text().splitlines(keepends=True),fromfile='a/'+rel if before.exists()else'/dev/null',tofile='b/'+rel))
 (P/'patches'/(root+'.patch')).write_text(''.join(patch))
(P/'FINITE-CHECKS.json').write_text(json.dumps({'status':'PASS','checks':checks,'limits':'Read-only/prepared artifacts only. No app/ticket/Git/index writes, browser, model generation, full gate, CI mutation, publication or model/photo acceptance.'},indent=2)+'\n')
print(json.dumps({'checks':checks,'app_patch_bytes':(P/'patches/app.patch').stat().st_size,'tickets_patch_bytes':(P/'patches/tickets.patch').stat().st_size},indent=2))
