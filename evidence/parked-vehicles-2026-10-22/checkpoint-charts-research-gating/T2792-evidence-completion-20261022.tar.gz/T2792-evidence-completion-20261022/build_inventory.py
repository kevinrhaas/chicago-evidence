from pathlib import Path
import json,hashlib,struct,io,subprocess,datetime
from PIL import Image
R=Path('/workspace/chicago/chicago/4d');P=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['wagon/wagon-w01.glb','wagon-driver/wagon-w01.glb','carriage/carriage-c01.glb','carriage-c02/carriage-c02.glb','parked-wagon/wagon-w01.glb','parked-carriage/carriage-c02.glb','parked-carriage/shaft-rest.glb','covered-wagon/covered_w01_western_blue/covered-w01.glb','covered-wagon/covered_w01_wolfpoint_oak/covered-w01.glb']
rows=[]
for path in paths:
 f=R/'renderers/web/transport'/path;b=f.read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);bin=b[28+n:];prim=[p for m in g.get('meshes',[]) for p in m['primitives']];tri=sum(g['accessors'][p.get('indices',p['attributes']['POSITION'])]['count']//3 for p in prim if p.get('mode',4)==4);textures=[]
 for image in g.get('images',[]):
  if 'bufferView' in image:
   v=g['bufferViews'][image['bufferView']];z=bin[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];im=Image.open(io.BytesIO(z));textures.append({'encoded_bytes':len(z),'sha256':sha(z),'pixels':list(im.size),'RGBA8_mips_estimate_bytes':im.width*im.height*4*4/3})
 rows.append({'path':str(f.relative_to(R)),'sha256':sha(b),'bytes':len(b),'triangles_index_count':tri,'primitive_count_not_driver_draws':len(prim),'meshes':len(g.get('meshes',[])),'nodes':len(g.get('nodes',[])),'materials':len(g.get('materials',[])),'embedded_images':textures,'decoded_RGBA8_plus_mips_estimate_bytes':sum(x['RGBA8_mips_estimate_bytes']for x in textures),'metadata':g.get('extras',{}),'portable_frames':[x for x in g.get('nodes',[]) if 'mesh' not in x and x.get('name','').startswith('vehicle_')],'LOD_extension_or_levels_present':bool(g.get('extensions',{}).get('MSFT_lod')) or any('MSFT_lod'in x.get('extensions',{})for x in g.get('nodes',[]))})
trade=json.loads((R/'data/yard/town_trade_goods.json').read_text());water=json.loads((R/'data/yard/town_water_cart.json').read_text());places=json.loads((R/'data/transport/parked/placements.json').read_text());reads=['data/yard/town_trade_goods.json','data/yard/town_water_cart.json','data/transport/parked/placements.json','renderers/web/js/yard.js','renderers/web/js/parked-transport.js','assets/LICENSES.md','renderers/web/transport/LICENSES.md']
inv={'ticket':'T-2792','captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository_HEAD_at_capture':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/chicago',text=True).strip(),'scope':'Read-only existing data/GLB inventory; no generation, browser, runtime visibility or performance measurement','preimage_sha256':{s:sha((R/s).read_bytes())for s in reads},'trade_counts':trade['counts'],'water_counts':water['counts'],'trade_wagon_records':trade['wagons'],'water_wagon_records':water['wagons'],'parked_placements':places,'assets':rows}
(P/'existing-vehicle-inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
print('\n'.join(f"{x['path']}: {x['bytes']}B {x['triangles_index_count']}tri {x['primitive_count_not_driver_draws']}primitives {int(x['decoded_RGBA8_plus_mips_estimate_bytes'])}estimatedRGBA8mipsB"for x in rows))
