
// Root-held comparison adaptation; geometry and original lighting are unchanged.
// Full vehicle incl pole. Source-direction quarter is newly framed to full bounds.
window.setFullComparisonView=(name,binding=null)=>{
 if(disposed)throw Error('Comparison already disposed');
 if(!['quarter','front','profile'].includes(name))throw Error('Unknown finite view');
 pole.visible=true;
 const w=canvas.clientWidth,h=canvas.clientHeight,aspect=w/h;
 renderer.setSize(w,h,false);const camera=perspective;activeCamera=camera;
 camera.clearViewOffset();camera.filmOffset=0;camera.aspect=aspect;camera.fov=40;camera.near=.05;camera.far=100;
 const center=full.getCenter(new T.Vector3());
 const direction=new T.Vector3(...(name==='quarter'?hypothesis.fit.basis.towardCamera:name==='profile'?[1,.12,0]:[0,.18,1])).normalize();
 camera.position.copy(center).addScaledVector(direction,10);camera.lookAt(center);camera.updateMatrixWorld(true);
 const inv=camera.quaternion.clone().invert(),local=corners(full).map(p=>p.clone().sub(center).applyQuaternion(inv));
 const tanV=Math.tan(T.MathUtils.degToRad(camera.fov/2)),tanH=tanV*aspect;let distance=0;
 for(const p of local)distance=Math.max(distance,p.z+Math.abs(p.x)/(tanH*.86),p.z+Math.abs(p.y)/(tanV*.86));
 camera.position.copy(center).addScaledVector(direction,distance);camera.lookAt(center);camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
 if(binding){
  if(binding.name!==name||binding.viewport[0]!==w||binding.viewport[1]!==h)throw Error('Paired view/viewport drift');
  camera.position.fromArray(binding.camera.position);camera.quaternion.fromArray(binding.camera.quaternion);
  camera.fov=binding.camera.fov;camera.aspect=binding.camera.aspect;camera.near=binding.camera.near;camera.far=binding.camera.far;
  camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
 }
 renderer.render(scene,camera);
 const projected=corners(full).map(p=>p.clone().project(camera));
 const lo=[0,1,2].map(k=>Math.min(...projected.map(p=>p.getComponent(k)))),hi=[0,1,2].map(k=>Math.max(...projected.map(p=>p.getComponent(k))));
 const row={name,viewport:[w,h],scope:'Full vehicle including original parked team pole. Quarter retains nonunique source-direction basis; framing is full bounds, not original plate crop.',camera:{position:camera.position.toArray(),quaternion:camera.quaternion.toArray(),fov:camera.fov,aspect:camera.aspect,near:camera.near,far:camera.far,projection:camera.projectionMatrix.toArray(),world:camera.matrixWorld.toArray()},bounds:{min:full.min.toArray(),max:full.max.toArray()},framing:{ndcMin:lo,ndcMax:hi,entireSelectedBoundsInside:lo.every(v=>v>=-1)&&hi.every(v=>v<=1)},lighting:{outputColorSpace:renderer.outputColorSpace,toneMapping:renderer.toneMapping,exposure:renderer.toneMappingExposure,background:scene.background.getHex(),hemisphere:scene.children.filter(x=>x.isHemisphereLight).map(x=>({color:x.color.getHex(),groundColor:x.groundColor.getHex(),intensity:x.intensity})),sun:{color:sun.color.getHex(),intensity:sun.intensity,position:sun.position.toArray(),castShadow:sun.castShadow,normalBias:sun.shadow.normalBias,bias:sun.shadow.bias,mapSize:sun.shadow.mapSize.toArray(),camera:[sun.shadow.camera.left,sun.shadow.camera.right,sun.shadow.camera.top,sun.shadow.camera.bottom,sun.shadow.camera.near,sun.shadow.camera.far]},shadowsEnabled:renderer.shadowMap.enabled,shadowType:renderer.shadowMap.type},sourceTriangles:gltf.parser.json.extras.statistics.triangles,sourceBytes:buffer.byteLength,drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles,glError:renderer.getContext().getError(),poleVisible:pole.visible};
 if(binding&&JSON.stringify(row.camera)!==JSON.stringify(binding.camera))throw Error('Paired numeric camera mismatch');
 if(binding&&JSON.stringify(row.lighting)!==JSON.stringify(binding.lighting))throw Error('Paired original lighting mismatch');
 if(binding&&JSON.stringify(row.bounds)!==JSON.stringify(binding.bounds))throw Error('Paired full-bounds mismatch');
 return row;
};
window.comparisonInputHash=async()=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',buffer))).map(x=>x.toString(16).padStart(2,'0')).join('');
window.disposeComparison=()=>{
 const gs=new Set(),ms=new Set();scene.traverse(n=>{if(n.geometry)gs.add(n.geometry);for(const m of Array.isArray(n.material)?n.material:[n.material])if(m)ms.add(m);});
 let g=0,m=0;gs.forEach(x=>x.addEventListener('dispose',()=>g++));ms.forEach(x=>x.addEventListener('dispose',()=>m++));
 window.disposeBrougham();const once={geometryEvents:g,materialEvents:m};window.disposeBrougham();
 const row={expectedGeometries:gs.size,expectedMaterials:ms.size,geometryEvents:g,materialEvents:m,idempotent:once.geometryEvents===g&&once.materialEvents===m,sceneChildren:scene.children.length,remainingGeometries:renderer.info.memory.geometries,remainingTextures:renderer.info.memory.textures,disposed,resourceCleanup:window.broughamCleanupReceipt};
 if(g!==gs.size||m!==ms.size||!row.idempotent||row.sceneChildren!==0||row.remainingGeometries!==0||row.remainingTextures!==0||!disposed)throw Error('Actual disposal guard failed '+JSON.stringify(row));return row;
};
