# HELD — bounded production validation after explicit root release

No production invocation has run for this proposal. The completed pure-file reader check is recorded in PURE-READER-VALIDATION.json. Root must release the one heavy lane after people-CI artifacts and carriage preview scheduling.

Prepared command (not run):

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /workspace/shared/wagon-original-charts-repair-proposal-2026-10-22/HELD-validate-two-architectures.py /workspace/shared/wagon-original-charts-two-architecture-validation-FIRST
```

The output path must be fresh. This caller runs at most two sequential actual material-only invocations, HASWELL then NEHALEM, each nice15/one thread/PYTHONDONTWRITEBYTECODE=1. It queries the actual OpenBLAS core and thread count through the existing native runtime wrapper. It limits each to60s and their combined invocation window to120s, preserves stdout/stderr/runtime/GLB outputs, requires exact original0138 material SHA and stops at the first failure. No retries, package installation, hardware regeneration, finish/covered generation, full gate, browser, Git/index/mirror/CI action is included.

The caller uses the existing native3.11 runtime, saved exact04820/2fb/material recipe and original generate_tiles.py on the app import path (whose hash is checked). Only the outside-app candidate apply_materials.py/helper/chart assets are new. All input source hashes are checked before/after. On both success, root may separately release its normal source wrappers/full checks; those are not part of this two-invocation caller. The explicit numerical authoring flag is intentionally not exercised in the held default-path verification.
