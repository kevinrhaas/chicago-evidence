from pathlib import Path
import subprocess,sys,os,time,json,hashlib,datetime
out=Path(sys.argv[1]).resolve();assert str(out).startswith('/workspace/shared/') and not out.exists();out.mkdir();app=Path('/workspace/chicago/chicago/4d');base=Path('/workspace/shared/w01-python-sum-recovery-20261022')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={'apply':Path('/workspace/shared/wagon-original-charts-repair-proposal-2026-10-22/tree/chicago/4d/tools/transport/wagon_parked/apply_materials.py'),'tiles':app/'tools/transport/wagon_parked/generate_tiles.py','hardware':base/'native311-fsum/wagon-w01.glb','parts':base/'native311-fsum/authored-parts.json','parameters':base/'recipe.json'}
expected={'apply':'c5b49d0cf275985f4748547192c3c01b89e6bb11bac4869e86201eb464070fb6','tiles':'f7bcef9103a12dcd02d68396699d487cb7163fe266f5eba06dec074ff3d65df0','hardware':'04820fc15b16c6f1b9b12487c2d6ceb3500d03c94094d84c73554f2b2d1f5709','parts':'2fb3709d233e896280c50342618c28f9e340029e52c67b328100e05a125e2c27'}
for key,h in expected.items():assert sha(inputs[key])==h
receipt={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'HELD candidate verification: at most two sequential material-only production invocations; all original0138 material bytes required','maximumInvocationTimeSeconds':120,'maximumAttempts':2,'inputs':{k:{'path':str(p),'sha256':sha(p)}for k,p in inputs.items()},'attempts':[],'closed':False}
(out/'owner.json').write_text(json.dumps({'pid':os.getpid(),'controller':str(Path(__file__)),'started':receipt['started']},indent=2)+'\n')
def save():(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
save();deadline=time.monotonic()+120
for architecture in ['HASWELL','NEHALEM']:
 remaining=deadline-time.monotonic()
 if remaining<=0:receipt['stoppedReason']='Total120s deadline reached';break
 output=out/(architecture+'-material');assert not output.exists()
 controlled={'OPENBLAS_CORETYPE':architecture,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','BLIS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(app/'tools/transport/wagon_parked')}
 command=['/usr/bin/nice','-n','15',str(base/'venv311/bin/python'),'/workspace/shared/wagon-dd147-two-blas-material-probe-2026-10-22/material-wrapper.py',str(out),architecture,str(inputs['apply']),'--vehicle',str(inputs['hardware']),'--parts',str(inputs['parts']),'--parameters',str(inputs['parameters']),'--output',str(output)]
 row={'architecture':architecture,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'controlledEnvironment':controlled,'timeoutSeconds':min(60,remaining),'output':str(output)};receipt['attempts'].append(row);save();start=time.monotonic()
 try:
  with (out/(architecture+'-stdout.log')).open('wb')as stdout,(out/(architecture+'-stderr.log')).open('wb')as stderr:
   child=subprocess.Popen(command,env={**os.environ,**controlled},stdout=stdout,stderr=stderr);row['childPid']=child.pid;save()
   try:row['exit']=child.wait(timeout=min(60,remaining))
   except subprocess.TimeoutExpired:child.kill();child.wait();row['exit']=child.returncode;row['timeout']=True
 except Exception as e:row['error']=repr(e)
 row['elapsedSeconds']=time.monotonic()-start;row['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();row['productSha256']=sha(output/'wagon-w01.glb')if(output/'wagon-w01.glb').exists()else None;row['exactOriginal0138']=row['productSha256']=='0138ad2565f3e8b08029ef788c5196c65c80c79643313e944c726b993ff31ee4';save();print(json.dumps(row),flush=True)
 if row.get('exit')!=0 or not row['exactOriginal0138']:receipt['stoppedReason']='First actual failure; no retry';break
receipt['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['closed']=True;receipt['inputsUnchanged']=all(sha(inputs[k])==r['sha256']for k,r in receipt['inputs'].items());save();print(json.dumps({'closed':True,'attempts':len(receipt['attempts']),'inputsUnchanged':receipt['inputsUnchanged']}),flush=True)
