# T-2799 completed research/specification proposal

All work is outside the app. No Git/index/ticket/mirror/CI mutation, model generation, browser or Blender install. Root owns integration.

Apply `T2799-HORSE-REFERENCE-SPEC.patch` from repository root. It adds3 documentation files and4 source records, and updates existing `data/sources/john_moore_harness_catalog_1891.json` against exact saved preimage. PATCH-FILES.json pins all8 preimages/results; FINITE-CHECKS.json and PATCH-REPLAY.log prove source-schema/source-ID closure, proposedrig DAG and exact replay into an external scratch directory. No gate tool or source-code registration is added.

The master-specJSON is engineering authoring input and actualbaseline interface inventory, not a live schema or acceptedmodel. Source records keep modernanatomy cross-checks distinct from periodChicago evidence. Originalhorsegeometry/license stays unchanged; no sourceimage pixels are added to app assets. Proof folder contains only public-domain/CC0 material and explicit savedrights; uncertainhistorical photos are URL/hash-only citations.

Newly read primaryevidence: Moore1891 directprintedp1 confirms25.4mmNo1trace text; p16 separatescoachcollar/hames family; p34 is actualEnglishridingsaddleengraving. Exact originalpages/metadata/OCR hashes/requests are preserved. n3image really printedp2; the initiallymisnamed file and correction are retained rather than misrepresented. The source does not attest1835gear orChicagoownership.

After integration, run normal compile_source_use.py for new/changedsource registrations and the required fullpreflight before commit. Derive otherdata only if normal owningtool requires it; no manual generatedJSON edits. Parentmay associate fullysatisfied T2799 researchscope with thegreenvehiclebatch. Do notclose T2800/bodyphoto orT2801/2gear basedonthisspec.

Next concreteT2800 work: originalneutralcontinuousbody first (head/eyes/ears/muzzle/neck/shoulder/barrel/croup/limbs/hooves/mane/tail), actualmatched anatomy/sourcecamera comparisons, canonicalauthoring+licensedPBR/LODs; keep15jointoldprototype asregression. Broaderfit/gait/driver/traffic/riding work follows explicit dependencies. Existingidentityfirst steering applies to the human driver/rider, not an invented horse pedigree.
