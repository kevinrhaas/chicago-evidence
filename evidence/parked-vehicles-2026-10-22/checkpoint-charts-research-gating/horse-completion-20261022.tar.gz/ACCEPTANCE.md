# T-2799 acceptance map

Research/specification ready for root review; no geometry, animation, tack-fit or photographic ticket closure.

| Ticket clause | Concrete deliverable / evidence | Result |
| --- | --- | --- |
| Inventory meshes/rigs/human reuse/routes/camera modes/gates | CURRENT-INVENTORY.json + INPUT-PINS.json; master-spec MD actual715316B/14172tri/6draw/15joint horse and602980B/8012tri/36part harness, source/travel/human paths; old L1/no-mesh statements superseded | PASS for research scope |
| Dated source register: teams/riding/coat/anatomy/gear/rights | Proposed horse-reference-register-20261022.json,16 actually viewed historical/anatomy/period-book images, localSHA/publicURL/date/rights/use limits;4 newcleared/anatomy source records and Moore source update | PASS for research scope |
| Review Chrimes, Smith, Harvey, disputedstable, Sauganash | All5 actual full saved reference images viewed in this task; explicit current observations, rights/date/ownership/coupling uncertainty; historical images not republished in this packet | PASS |
| Bounded horse/master spec, dimensions/tiers/materials/skeleton/gaits/tack/rider/LOD/matchedviews; reconcile vehicle frame | New MD+machineJSON: reconstructed mediumlight-harness firstbody, licensedanatomy refs, actualprototype inventory, productionrig DAG, geometry/material sequence, metre/+Y/+Z/+X, socket contracts, actual W01/C02 transforms+parkedpitch+covereddisabled flags, proposedgates andactualbaseline distinction | PASS specification, not implementation |
| Denials/nextsources/concretehand-off | Old401 modeldownload remainsacquisitionlead; ordinaryIAmetadata/OCR/pages now200, directp1/16/34proof; n3printedp2 correction retained. T2800 anatomical firstbody sequence and separateT2801/2periodgear/remainingdate gaps explicit | PASS |

Root still must integrate, regenerate derived source-use data normally, run required full gate, commit/push and associate this completed research scope with its real PR. Only then use normal ticket.mjs done T-2799 --pr N (review until merge). T-2800..T-2805 remain open; the first photographic master itself is not delivered.
