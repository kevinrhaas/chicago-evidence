"""Read-only source intake checks using actual current app inputs and candidate files."""
from pathlib import Path
from copy import deepcopy
import importlib.util, json, os, sys, tempfile

HERE=Path(__file__).resolve().parent
P=HERE/'proposed/chicago/4d'
APP=Path('/workspace/chicago/chicago/4d')
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

# The fixture reads current covered assets and source through symlinks; the new
# delivered files stay outside the app. No clone, publisher or app write occurs.
with tempfile.TemporaryDirectory(prefix='v17-intake-readonly-',dir='/tmp') as temp:
    root=Path(temp)
    for name in ['data','assets']:(root/name).symlink_to(APP/name,target_is_directory=True)
    (root/'renderers/web/transport').mkdir(parents=True)
    (root/'renderers/web/js').symlink_to(APP/'renderers/web/js',target_is_directory=True)
    for child in (APP/'renderers/web/transport').iterdir():
        (root/'renderers/web/transport'/child.name).symlink_to(child,target_is_directory=child.is_dir())
    (root/'renderers/web/transport/parked-brougham').symlink_to(HERE/'validation-delivery',target_is_directory=True)
    sys.path.insert(0,str(P/'tools/transport'))
    validator=load('candidate_placements',P/'tools/transport/check_parked_placements.py')
    validator.ROOT=root
    current=json.loads((APP/'data/transport/parked/placements.json').read_text())
    proposed=json.loads((P/'data/transport/parked/placements.json').read_text())
    assert validator.validate(current)==6
    assert validator.validate(proposed)==7
    assert proposed['scenes']['1835']==current['scenes']['1835']
    assert proposed['scenes']['1904'][:-1]==current['scenes']['1904']
    assert all(proposed['models'][k]==v for k,v in current['models'].items())
    failures=[]
    def refuse(label,fn):
        record=deepcopy(proposed);fn(record)
        try:validator.validate(record)
        except (AssertionError,KeyError):failures.append(label);return
        raise AssertionError('Accepted invalid candidate: '+label)
    def b(r):return r['scenes']['1904'][-1]
    def backdate(r):r['scenes']['1835'].append(r['scenes']['1904'].pop())
    refuse('no 1835 backdating',backdate)
    refuse('no invented household owner',lambda r:b(r).update(belongs_to='glessner_house'))
    refuse('no C02 replacement',lambda r:b(r).update(replaces='prairie_parked_carriage'))
    refuse('no silent stand move',lambda r:b(r).update(at_local_enu_m=[1397.91,-3240]))
    refuse('no silent bearing change',lambda r:b(r).update(bearing_deg=179))
    refuse('no duplicate instance',lambda r:r['scenes']['1904'].append(deepcopy(b(r))))
    refuse('no source substitution',lambda r:b(r).update(source_ids=[]))
    refuse('no generic C02 rebranding',lambda r:r['models']['carriage_c02'].update(design_reference=deepcopy(r['models']['studebaker_brougham_1893']['design_reference'])))
    refuse('no unknown family through covered allowance',lambda r:r['models'].__setitem__('unknown_model',deepcopy(r['models']['carriage_c02'])))
    refuse('no missing required C02',lambda r:r['models'].pop('carriage_c02'))
    refuse('near-only cannot advertise obsolete mid/far',lambda r:r['models']['studebaker_brougham_1893']['delivery_lods'].update(mid='transport/parked-brougham/brougham-mid.glb'))

print(json.dumps({'pass':True,'actual_old_count':6,'actual_candidate_count':7,'old_models_and_rows_exact':True,'covered_subset_preserved':True,'negative_refusals':failures,'app_writes':False,'browser_or_fullgate':False},indent=2))
