# V17 parked Brougham intake — concrete source patch, held outside the app

This packet adds an empty catalogue-guided Brougham to the 1904 Prairie scene. It preserves all six existing parked instances, all original model values and every 1835 row. Generic C02 remains at E1397.6,N−3228.2. The new stand remains the earlier proposed E1397.9,N−3240,bearing178.99, with no owner and no replacement. No app, ticket, Git index or published mirror was changed by preparing this packet.

The source patch applies cleanly to the exact current preimages recorded in `BASE-AND-DELTA-PINS.json`. It includes the actual V17 generator, quarter helper/recipe, existing indexer and static-interface source; exact near-only validation; placement/card/static-shoe integration; provenance; append-only liberties, status and roadmap notes; and one proposed changelog entry. The two binary payloads are separate and hash-bound in `BINARY-RESTORE-MANIFEST.json`. No obsolete V13 three-LOD checker or V16 material experiment was copied.

## Exact asset and classification

The raw master is `b74e00937871eef8666fe048501456a8409b18df185c87a0905b083b7a2448fa`,2,495,128bytes. The indexed near is `ec2bfc0da49b570429dbcd8db39250aa6f1bbf55587570f0dafad9a42afc4ee5`,1,249,944bytes. It has33,502triangles,25meshes,42nodes and7materials, no images, textures, skins or animations. The original13anchors,8metadata targets,9inert obstacle bounds and all disabled capability flags remain unchanged. Two new inset source records require the reviewed index map1→1,12→13,16→17,27→29; actual door/step component bounds are checked against these indices.

The existing public-domain first-party source `studebaker_1893_illustrated_souvenir` remains unchanged. It supports Studebaker's1893 Brougham design before1904. The vehicle instance, metric dimensions, hidden construction, material optics, opposite-side symmetry, owner and stop are reconstructed. `belongs_to:null` and the reconstructed individual-maker card remain distinct from the attested catalogue design reference. No Pullman or Glessner ownership is asserted. Original project source and geometry retain GPL-3.0-or-later provenance in the runtime license, transport LICENSES and assets LICENSES. No file under assets/ is added.

The placement file is the selection manifest. Its Brougham model references only the exact indexed-near path, four wheel contacts and four static shoe contacts. Full100m/Balanced65m/Light0 reach is unchanged; no distance LOD selection or mid/far model is advertised. The existing publisher already copies the renderer transport tree and parked data recursively, so no publisher or building asset manifest edit is needed. No generated liberty/scene/source-sidecar output was hand-edited: root must run the supported rebuild after intake.

## Actual checks performed

- `git apply --check` passed against the current primary tree. Exact preimages remain the authority if DEV advances.
- The read-only native near checker passed on the actual V17 raw/near assets and proposed metadata/source. Expanded P-N streams match, all delivered triangles remain finite/nondegenerate with unit normals, actual frame/bounds/wheels/shoe/full-pole/hitch are read back, and464 original V15 parts plus46 whole-mesh streams remain exact.
- Current archived Khronos receipts are pinned to their exact V17 input hashes:0errors,0warnings,4inherited empty-anchor infos. These are archived conformance checks; no fresh validator execution occurred in this task.
- Candidate placement validation passed with6old and7new instances. Eleven actual rejection controls preserve era, ownership, C02 identity, stand/bearing, unique instance, source, required model families and near-only delivery.
- A pure source-card check preserves all six old card structures and separates the catalogue design from this reconstructed individual. JSON/Python parsing, Node and shell syntax passed. These are source checks, not browser acceptance.
- The actual earlier source8 run passed eight desktop/mobile matched catalogue views with no runtime errors and clean disposal. All eight were personally inspected; V17's dark quarter improves on V15. Flat paint, the uniform inset, gray empty glass and smaller fittings still differ from the illustration. Photographic completion remains open.

## Required work before an ordinary DEV merge

Actual world contact and obstacle clearance remain unresolved. The current1904 host passes `streetGrid.carriagewayHeight` as the wheel provider; the proposed static-shoe guard reuses that same provider and refuses nonfinite values before arithmetic. It retains30mm wheel-span,1mm penetration and30mm shoe-gap limits. This is a fixed parked-down paired-team pole, not `vehicle_tongue`, a new hinge or a working-height hitch. Point contacts do not prove full body/pole/curb/sidewalk/obstacle clearance. Test the exact geometry and stand; do not relocate, tilt, shorten or hide parts to qualify it.

The new stand is25.157275m from current spawnE1410.12,N−3218.01, inside both Full and Balanced ranges. It can add33,502triangles and up to7material groups to an already-red1904 scene. T3032's known4,603,239triangles exceeds4,600,000 before this intake; reducing that3,239 excess alone does not establish sufficient headroom. Actual integrated published measurements must pass unchanged limits. No new budget pass is claimed here.

Root should inspect the patch and payload manifest, verify preimages, and apply only when its source lane is available. Then measure the new normal step using `node tools/measure_step_isolation.mjs --tool tools/check_brougham_near.py` and `node tools/audit_step_isolation.mjs`. The tiny flat wrapper is necessary because the existing isolation selector recognizes flat tools/*.py; the prior nested checker command would select no step. No isolation row was fabricated or measured during preparation.

After the supported rebuild and normal full preflight, run actual main/published desktop and phone qualification for ground/full-pole obstacles, exact asset/hash, source/type/maker/no-owner card, picking, confidence filters, Full/Balanced/Light no-fetch behavior, C02 preservation, disposal and whole-scene budgets. Source-view images do not substitute for these checks. No PR or photographic, occupied, door, hitch, traffic, boarding, riding or collision acceptance is claimed.

## Reproduction source

The preserved source can generate the native master using `python3 tools/transport/brougham/generate.py --output <fresh-directory> --rear-quarter-recipe tools/transport/brougham/rear-quarter.json`. Defaults read the included parameters and LOD recipe; do not supply the separate V16 material study. Its existing `index_streams.write_indexed` produces lossless indexed near from that master. This preparation did not rerun either producer or claim repeated-generation proof. Existing actual generation, first packaging failure and reviewed completion remain in their earlier immutable evidence capsules.

`verify_preimages.py` is read-only. `CANDIDATE-UNAPPLIED.patch` is root-relative to `/workspace/chicago`; binary payload destinations are separately explicit. The retained full proposed text copies are for review and must not overwrite newer shared documents wholesale if their preimages have changed.
