from pathlib import Path
import ast, copy, difflib, hashlib, json, math, shutil, struct

HERE = Path(__file__).resolve().parent
APP = Path('/workspace/chicago/chicago/4d')
OLD = Path('/workspace/shared/brougham-v14-APP-INTAKE-TEXT-HELD-20261022/proposed/chicago/4d')
V14CHECK = Path('/workspace/shared/brougham-v14-NEAR-VALIDATION-REGISTRATION-HELD-20261022/proposed/chicago/4d/tools/transport/brougham/check_near.py')
ACTUAL = Path('/workspace/shared/brougham-v17-existing-raw-PACKAGING-COMPLETION-ACTUAL-20261022')
V15 = Path('/workspace/shared/brougham-v15-slender-step-supports-ACTUAL-20261022')
P = HERE/'proposed/chicago/4d'
P.mkdir(parents=True, exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def put(rel, data):
    p = P/rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data if isinstance(data, bytes) else data.encode('utf-8', 'surrogateescape'))
    return p
def text(p): return p.read_text(errors='surrogateescape')
def dump(rel, obj): return put(rel, json.dumps(obj, indent=2)+'\n')

# Reuse the reviewed V14 consumer/guard changes; current source must still match
# the exact preimages of that packet. No current app file is written here.
old_pins = json.loads((OLD.parents[2]/'BASE-AND-DELTA-PINS.json').read_text())
pins_by_path = {r['path'].removeprefix('chicago/4d/'): r for r in old_pins['changes']}
for rel in ['renderers/web/js/parked-transport.js', 'tools/transport/check_parked_placements.py',
            'tools/transport/wagon_covered/check.py', 'tools/transport/wagon_covered/test_identity.py']:
    assert sha(APP/rel) == pins_by_path[rel]['base_sha256'], ('Rebase current authored delta', rel)
    put(rel, (OLD/rel).read_bytes())

base = json.loads((APP/'data/transport/parked/placements.json').read_text())
old = json.loads((OLD/'data/transport/parked/placements.json').read_text())
record = copy.deepcopy(base)
record['_doc'] = 'Parked type reconstructions. Existing 1835 stands and generic 1904 C02 remain separate. The additional Brougham follows an evidenced 1893 catalogue design; its individual presence, owner and stop are reconstructed. L-parked-vehicles-2979; L-covered-wagons-2980; L-brougham-parked-2794.'
spec = copy.deepcopy(old['models']['studebaker_brougham_1893'])
spec['basis'] = "Original empty, unhitched Brougham reconstruction guided by Studebaker's 1893 catalogue illustration, leaf 0095. A shaped roof, deep curved door, separated footplates, slender step supports and recessed dark opaque rear quarters distinguish the design. Metric dimensions, hidden construction, surface materials and this individual vehicle's 1904 presence, ownership and stop are reconstructed. V17 is preferred over V15 in matched catalogue views, but its uniform paint and inset, glass and smaller fittings remain simplified. Photographic quality remains open. Only the exact indexed near model is delivered; mid/far and runtime distance LOD selection are unsupported."
record['models']['studebaker_brougham_1893'] = spec
record['scenes']['1904'].append(copy.deepcopy(old['scenes']['1904'][-1]))
assert record['scenes']['1835'] == base['scenes']['1835']
assert record['scenes']['1904'][:-1] == base['scenes']['1904']
assert all(record['models'][k] == v for k,v in base['models'].items())
dump('data/transport/parked/placements.json', record)

# Preserve the actual V17 producer, source recipes and indexer, not the obsolete
# V13 three-LOD checker or any V16 material experiment.
for p in sorted((ACTUAL/'source').iterdir()):
    if p.is_file(): put('tools/transport/brougham/'+p.name, p.read_bytes())
put('tools/transport/brougham/rear-quarter.json', (ACTUAL/'rear-quarter.json').read_bytes())
for name in ['brougham.json', 'BUILD-RECEIPT.json', 'LICENSE']:
    put('renderers/web/transport/parked-brougham/'+name, (ACTUAL/'portable-near'/name).read_bytes())
side = json.loads((P/'renderers/web/transport/parked-brougham/brougham.json').read_text())
side['near_actual_visual_evidence'] = 'Actual V15/V17 matched catalogue source8 passed on 2026-10-22: eight desktop/mobile detail/full-quarter images, unchanged camera and light, zero runtime errors and clean disposal. V17 dark inset preferred for development; image differences, actual world placement and photographic completion remain open.'
side['rendering'] = 'Original PBR factors; no image textures. Native indexing only, no meshopt or quantization. Existing runtime static merger groups seven shared materials; actual world and phone cost remain to measure.'
side['status'] = 'Actual raw/indexed-near V17 with reviewed native catalogue images; main-world terrain, obstacle, card/tier/pick/disposal and published renderer acceptance remain pending. Photographic and occupied completion remain open.'
side['pending_deliverables'] = ['material and source-image refinement', 'optional mid/far V17 delivery', 'normal main/phone/published qualification', 'actual world terrain and full pole/body obstacle clearance', 'photographic review', 'fit/doors/hitch/boarding/collision']
dump('renderers/web/transport/parked-brougham/brougham.json', side)

# Reuse the existing generic decoder and checks. V17 protects 464 unchanged V15
# parts by their old role ordering; the two new inset records must not change
# source-index identity. The unchanged 23 meshes similarly use semantic ordering.
checker = V14CHECK.read_text()
start = checker.index('def protected_signatures(j,b):')
stop = checker.index('def subtree(j,i):')
protected = '''def protected_signatures(j,b):
    part=hashlib.sha256();count=0
    original=[p for p in j['extras']['parts'] if p['name']!='rear_quarter_recessed_surface']
    assert len(original)==466
    for i,p in enumerate(original):
        if p['name']=='rear_quarter_panel':continue
        part.update(struct.pack('<I',i));part.update(json.dumps([p['name'],p['frame'],p['material'],p['triangles']],separators=(',',':')).encode())
        for kind in ['POSITION','NORMAL']:part.update(component(j,b,p,kind))
        count+=1
    mesh=hashlib.sha256();streams=0
    original_meshes=[(i,row) for i,row in enumerate(j['meshes']) if row['name']!='surface_vehicle_body_6']
    assert len(original_meshes)==24
    for old_i,(i,row) in enumerate(original_meshes):
        if row['name']=='surface_vehicle_body_0':continue
        mesh.update(struct.pack('<I',old_i));mesh.update(row['name'].encode())
        for kind in ['POSITION','NORMAL']:mesh.update(raw_stream(j,b,i,kind));streams+=1
    return {'parts':count,'protected_part_PN_sha256':part.hexdigest(),'mesh_streams':streams,'protected_mesh_PN_sha256':mesh.hexdigest()}

'''
checker = checker[:start]+protected+checker[stop:]
checker = checker.replace('V14','V17').replace('32830','33502')
checker = checker.replace("len(j['nodes'])==41 and len(j['meshes'])==24 and len(j['materials'])==6 and len(j['extras']['parts'])==466", "len(j['nodes'])==42 and len(j['meshes'])==25 and len(j['materials'])==7 and len(j['extras']['parts'])==468")
checker = checker.replace("c['protected_V13_streams']", "c['protected_V15_streams']").replace('464part/46mesh protected baseline streams', '464part/46stream role-mapped V15 baseline')
checker = checker.replace("report['info']['drawCallCount']==24", "report['info']['drawCallCount']==25")
anchor = "    measured=native_contacts(j,b);"
extra = '''    assert side['static_master']==c['static_master'], 'Exact inert V17 interfaces'
    for entry in side['static_master']['entries']:
        for role,index_key,bounds_key in [('deep_U_closed_door','door_part_index','closed_door_bounds_root_m'),('door_step','step_part_index','step_bounds_root_m')]:
            part=j['extras']['parts'][entry[index_key]]
            assert part['name']==role and part['frame']=='vehicle_body', 'Actual source part-index role'
            ps=list(struct.iter_unpack('<fff',component(j,b,part,'POSITION')))
            assert bounds(ps)==entry[bounds_key], 'Actual static source part-index bounds'
'''
assert checker.count(anchor)==1
checker = checker.replace(anchor, extra+anchor)
ns={}
exec(checker[:checker.index('def check_near(')],ns)
g,b=ns['read'](ACTUAL/'raw/brougham.glb')
vg,vb=ns['read'](V15/'raw/brougham.glb')
prot=ns['protected_signatures'](g,b)
assert prot==ns['protected_signatures'](vg,vb) and prot['parts']==464 and prot['mesh_streams']==46
near,nb=ns['read'](ACTUAL/'portable-near/brougham-near.glb')
contacts=ns['native_contacts'](g,b)
assert contacts==ns['native_contacts'](near,nb)
source_dir=P/'tools/transport/brougham'
metadata_dir=P/'renderers/web/transport/parked-brougham'
contract={'scope':'V17 exact NEAR ONLY native source/delivery contract; not terrain, world, public, mid/far, occupied or photographic acceptance',
          'raw_sha256':sha(ACTUAL/'raw/brougham.glb'),'near_sha256':sha(ACTUAL/'portable-near/brougham-near.glb'),
          'raw_bytes':2495128,'near_bytes':1249944,'triangles':33502,'expanded_PN_sha256':ns['expanded'](g,b)[0],
          'bounds_m':ns['decoded_bounds'](g,b,ns['world_nodes'](g)),'protected_V15_streams':prot,'native_contacts':contacts,
          'source_files':{p.name:sha(p) for p in sorted(source_dir.iterdir()) if p.is_file()},
          'delivery_metadata_files':{p.name:sha(p) for p in sorted(metadata_dir.iterdir()) if p.is_file()},
          'static_master':side['static_master'],'source_part_index_map_from_V15':{'1':1,'12':13,'16':17,'27':29},
          'archived_khronos':[], 'scene_eligibility':side['scene_eligibility'],
          'reference_sha256':'b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe',
          'protected_baseline_raw_sha256':sha(V15/'raw/brougham.glb'),'baseline_compared_at_preparation_only':True}
for name,file in [('KHRONOS-RAW.json','brougham-source.glb'),('KHRONOS-NEAR.json','brougham-near.glb')]:
    put('tools/transport/brougham/archived-khronos/'+name,(ACTUAL/name).read_bytes())
    contract['archived_khronos'].append({'report':name,'report_sha256':sha(ACTUAL/name),'bound_file':file,
        'actual_input_sha256':contract['raw_sha256' if 'RAW' in name else 'near_sha256'],
        'scope':'Archived actual V17 packaging-completion validation on 2026-10-22. Legacy URI brougham-v12.glb is tool text; exact input SHA binds identity. Not a fresh Khronos execution.'})
cpath=dump('tools/transport/brougham/near-contract.json',contract)
checker=checker.replace("EXPECTED_CONTRACT='ca6f640e8dd015bab6389e33ab55419f233dcd9363936b709ed9fd05789ef18a'",'EXPECTED_CONTRACT='+repr(sha(cpath)))
put('tools/transport/brougham/check_near.py',checker)
put('tools/check_brougham_near.py', '''# SPDX-License-Identifier: GPL-3.0-or-later
"""Read the exact V17 near delivery; no producer or browser is launched."""
from pathlib import Path
import json
from transport.brougham.check_near import check_near
ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
    print(json.dumps(check_near(ROOT/'renderers/web/transport/parked-brougham', ROOT/'tools/transport/brougham')))
''')
sh=text(APP/'tools/check.sh')
needle='step "Parked vehicles keep their exact wagon stands and cannot cross era boundaries (T-2979)"'
assert sh.count(needle)==1
sh=sh.replace(needle,'step "Catalogue Brougham preserves exact V17 near source, contacts and inert interfaces (T-2794)" \\\n  python3 tools/check_brougham_near.py\n\n'+needle)
put('tools/check.sh',sh)

lib='''

### L-brougham-parked-2794 — catalogue-guided parked Brougham in 1904

**Decision:** Add one empty, unhitched Brougham at local ENU E1397.9, N−3240, bearing178.99, retaining generic C02 at its separate stand. The 1893 Studebaker catalogue leaf0095, source `studebaker_1893_illustrated_souvenir`, attests a maker/type design before1904. It does not attest this individual specimen, Chicago/Prairie presence, a Pullman/Glessner connection, ownership or this stop. `belongs_to` remains null.

**Reconstructed:** all absolute metres, hidden sides/interior/construction, pigments and optical materials, support/hardware attachment, opposite-side symmetry and the stop. V17 has separated footplates, slender curved step supports and two 8mm recessed dark opaque rear-quarter surfaces; the illustration does not identify these as glass, curtains or a specific lining. No image pixels are embedded. Matched native catalogue views prefer V17 over V15, but its flat paint, uniform inset, glass and smaller fittings remain visibly simplified. Photographic completion remains open.

**Delivery and limits:** only the indexed near model is supplied. Full100m/Balanced65m/Light0 reach and existing confidence/picking/material batching remain unchanged. The fixed paired-team pole and its original ground shoe are parked-down geometry, not a new hinge or working-height hitch. The same rendered carriageway provider checks all wheels and four shoe points, refusing nonfinite ground, wheel span over30mm, penetration over1mm or shoe gap over30mm. These point checks do not prove full pole/body/obstacle clearance. Actual world, phone, publication and whole-scene budget acceptance remain pending. No automatic relocation, tilt, support change or weakened renderer limit qualifies a failed stand.

**Unsupported:** occupants, boarding, door operation, steering/wheel animation, horse/rein/hitch coupling, collision physics, traffic and riding. All source interface capability flags remain false. The native hitch[0,.037,3.8]m is a parked datum. T-2794 photographic and occupied work remains OPEN.
'''
put('docs/LIBERTIES.md',(APP/'docs/LIBERTIES.md').read_bytes()+lib.encode())
note='''

## T-2794 — V17 catalogue-guided parked Brougham intake

The concrete source intake uses original rawb74e0093 (2,495,128B) and indexed-nearec2bfc0d (1,249,944B),33,502triangles/25meshes/42nodes/7materials, with13anchors and inert static interfaces. The reviewed source8 comparison passed all eight desktop/mobile images with unchanged camera/light and clean disposal; the dark recessed quarter improves on V15, while paint, inset texture, glass and smaller fittings remain simplified. Photographic completion remains open.

The proposed extra1904 Prairie stand is E1397.9,N−3240,bearing178.99, no owner and no replacement of genericC02. It is about25.16m from the current1904 spawn, within Full100m and Balanced65m reach. Its33,502triangles and up to7material groups require actual integrated budget qualification; T3032's existing1904 spawn draw-budget failure is separate and fixing its3,239-triangle excess alone does not establish sufficient headroom. Same-provider wheel/shoe guards do not prove full pole/body terrain and obstacle clearance. Normal main/public desktop+phone card, confidence, pick, tier and disposal proof remains pending, as do fullpreflight and ordinary DEV PR eligibility. No model was installed or world tested by preparation of this packet. All occupied, hitch, boarding, traffic, door and collision capabilities stay off.
'''
for name in ['STATUS','ROADMAP']:put('docs/'+name+'.md',(APP/('docs/'+name+'.md')).read_bytes()+note.encode())
license_note='''

## V17 catalogue-guided Brougham (T-2794)

Original project GPL-3.0-or-later source and generated geometry: tools/transport/brougham/{generate.py,source_details.py,quarter_surface.py,index_streams.py,static_master.py,parameters.json,lods.json,rear-quarter.json,LICENSE}. Rawmaster SHA256b74e00937871eef8666fe048501456a8409b18df185c87a0905b083b7a2448fa; indexed-near SHA256ec2bfc0da49b570429dbcd8db39250aa6f1bbf55587570f0dafad9a42afc4ee5. Runtime files, sidecar, build receipt and LICENSE are under renderers/web/transport/parked-brougham. Source appearance reference is public-domain US1893 Studebaker catalogue leaf0095, source studebaker_1893_illustrated_souvenir, plateSHAb458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe. No external model, image texture or plate pixels are embedded. Maker/type availability is evidenced; this specimen, owner, placement, metres, hidden construction and materials remain reconstructed. No Pullman/Glessner ownership is claimed. One added opaque material is an unidentified surface interpretation; V16 optical changes are not included. Near-only technical/native-view proof does not establish photographic, occupied or world acceptance. No file under assets/ is added.
'''
for rel in ['renderers/web/transport/LICENSES.md','assets/LICENSES.md']:
    put(rel,(APP/rel).read_bytes()+license_note.encode())
dump('changelog.d/T-2794.json',{'title':'A catalogue-guided Brougham on Prairie Avenue','kind':'feature','items':['An additional empty Brougham follows the1893 Studebaker catalogue design, with a shaped roof, curved door, fine step supports and recessed dark rear quarters. The existing unidentified carriage remains nearby.','The individual vehicle, dimensions, finish and stop are reconstructed. Photographic refinement continues; boarding and driving are unavailable.']})

# The binary restore is explicit and separate. No copying to the app occurs.
delivery=[]
for source,target in [(ACTUAL/'raw/brougham.glb','brougham-source.glb'),(ACTUAL/'portable-near/brougham-near.glb','brougham-near.glb')]:
    delivery.append({'source':str(source),'target':'chicago/4d/renderers/web/transport/parked-brougham/'+target,'bytes':source.stat().st_size,'sha256':sha(source),'installed':False})
(HERE/'BINARY-RESTORE-MANIFEST.json').write_text(json.dumps(delivery,indent=2)+'\n')
(HERE/'ACTUAL-NATIVE-CONTACT-READBACK.json').write_text(json.dumps({'native_contacts':contacts,'bounds_m':contract['bounds_m'],'world_terrain_and_obstacle_clearance_verified':False},indent=2)+'\n')
patch=[];pins=[]
for f in sorted(P.rglob('*')):
    if not f.is_file():continue
    rel=f.relative_to(P);a=APP/rel
    if a.exists() and a.read_bytes()==f.read_bytes():continue
    aa=text(a).splitlines(True) if a.exists() else []
    patch.extend(difflib.unified_diff(aa,text(f).splitlines(True),fromfile='a/chicago/4d/'+str(rel) if a.exists() else '/dev/null',tofile='b/chicago/4d/'+str(rel)))
    pins.append({'path':'chicago/4d/'+str(rel),'base_sha256':sha(a) if a.exists() else None,'candidate_sha256':sha(f),'candidate_bytes':f.stat().st_size})
(HERE/'CANDIDATE-UNAPPLIED.patch').write_bytes(''.join(patch).encode('utf-8','surrogateescape'))
spawn=json.loads((APP/'data/scenes/1904.json').read_text())['spawn']
dist=math.hypot(1397.9-spawn['local_e'],-3240-spawn['local_n'])
(HERE/'BASE-AND-DELTA-PINS.json').write_text(json.dumps({'state':'HELD_OUTSIDE_APP_NOT_WORLD_QUALIFIED','changes':pins,'binary_restore':delivery,'retained_source_sha256':sha(APP/'data/sources/studebaker_1893_illustrated_souvenir.json'),'unchanged_C02_and_1835':True,'spawn_distance_m':dist,'additional_native_triangles':33502,'static_material_groups':7,'source8_actual_receipt':{'path':'/workspace/shared/brougham-v15-v17-rear-quarter-native-source8-HELD-20261022/actual/receipt.json','sha256':sha(Path('/workspace/shared/brougham-v15-v17-rear-quarter-native-source8-HELD-20261022/actual/receipt.json'))},'step_isolation_measured':False,'fullpreflight_run':False,'app_mutated':False},indent=2)+'\n')
for f in P.rglob('*.json'):json.loads(f.read_text(errors='surrogateescape'))
for f in P.rglob('*.py'):ast.parse(text(f))
print(json.dumps({'prepared':str(HERE),'changed_files':len(pins),'patch_sha256':sha(HERE/'CANDIDATE-UNAPPLIED.patch'),'contract_sha256':sha(cpath),'spawn_distance_m':dist,'protected_V15':prot},indent=2))
