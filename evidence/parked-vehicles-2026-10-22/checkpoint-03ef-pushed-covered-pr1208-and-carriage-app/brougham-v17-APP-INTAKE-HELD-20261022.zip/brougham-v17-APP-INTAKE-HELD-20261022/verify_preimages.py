"""Verify this source patch's exact preimages without writing to the app."""
from pathlib import Path
import argparse, hashlib, json
HERE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--repository',type=Path,default=Path('/workspace/chicago'))
a=ap.parse_args()
record=json.loads((HERE/'BASE-AND-DELTA-PINS.json').read_text())
for row in record['changes']:
    p=a.repository/row['path']
    actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
    assert actual==row['base_sha256'], ('Preimage changed; review/rebase packet',row['path'],actual,row['base_sha256'])
for row in json.loads((HERE/'BINARY-RESTORE-MANIFEST.json').read_text()):
    p=HERE/row['capsule_payload']
    assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
    assert not (a.repository/row['target']).exists(), ('Binary target already exists; review before overwrite',row['target'])
print('PASS exact authored preimages and two binary payloads; no app writes.')
