from pathlib import Path
import datetime, hashlib, importlib.util, json, os, subprocess, time

HERE=Path(__file__).resolve().parent
APP=Path('/tmp/chicago-covered-sag/chicago/4d')
BACKUP=Path('/tmp/t2794-v17-glessner-before-ccad-20261022')
START=time.monotonic()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=APP,text=True).strip()=='ccad6214da4b2c90ddd788a8f611711d8e8b5e15'
assert not BACKUP.exists()
BACKUP.mkdir()
record={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'worktree':str(APP),'base':'ccad6214da4b2c90ddd788a8f611711d8e8b5e15','phase':'verify_current_package','pass':False,'rebaked_or_repacked':False,'old_outputs':[]}
def save():(HERE/'RECOVERY-AND-REBUILD.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
    module=APP/'tools/recover_glessner_v4.py'
    spec=importlib.util.spec_from_file_location('current_glessner_recovery',module)
    recovery=importlib.util.module_from_spec(spec);spec.loader.exec_module(recovery)
    members=recovery.verified_members()
    record['package_manifest_sha256']=sha(recovery.RECOVERY/'manifest.json')
    for name in recovery.targets(APP):
        target=APP/name
        assert name in members
        if target.exists():
            assert subprocess.run(['git','check-ignore','-q',str(target)],cwd=APP).returncode==0, 'Existing target must be ignored'
            data=target.read_bytes()
            row={'path':name,'old_sha256':hashlib.sha256(data).hexdigest(),'old_bytes':len(data),'stale':data!=members[name],'was_symlink':target.is_symlink()}
            if row['stale']:
                dest=BACKUP/name;dest.parent.mkdir(parents=True,exist_ok=True)
                target.rename(dest);row['retained_backup']=str(dest)
            record['old_outputs'].append(row)
            save()
    record['phase']='materialize_exact_tracked_package';save()
    record['materialized']=recovery.materialize()
    record['verified_outputs']=[]
    for name in recovery.targets(APP):
        p=APP/name;assert p.read_bytes()==members[name]
        record['verified_outputs'].append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
    del members
    record['phase']='supported_tail_from_compile_liberties';save()
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    env['PATH']='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:'+env['PATH']
    args=['node','tools/rederive.mjs','--tail','tools/compile_liberties.py']
    record['rederive_command']=args;save()
    with (HERE/'SUPPORTED-REDERIVE.log').open('wb') as log:
        result=subprocess.run(args,cwd=APP,env=env,stdout=log,stderr=subprocess.STDOUT)
    record['rederive_exit']=result.returncode
    if result.returncode:raise RuntimeError('Supported tail failed; preserve logs')
    record['pass']=True;record['phase']='CLOSED_PASS'
except BaseException as error:
    record['error']=repr(error);record['phase']='CLOSED_FAIL'
    raise
finally:
    record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['seconds']=time.monotonic()-START;save()
print(json.dumps(record,indent=2))
