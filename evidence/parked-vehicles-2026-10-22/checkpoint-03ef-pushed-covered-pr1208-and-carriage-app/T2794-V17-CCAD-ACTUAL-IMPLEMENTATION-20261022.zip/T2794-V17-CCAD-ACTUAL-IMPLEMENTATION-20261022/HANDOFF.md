# T2794 V17 actual app implementation — source frozen, gates held

The existing covered-wagon worktree was verified clean at0656467069, then reused on a new independent branch `steward/t2794-brougham-v17-20261022` based on exactDEVccad6214. The covered branch and commit remain intact. No new worktree or clone was created.

The installed31-file source includes the exact V17 raw/indexed assets and29 authored/check/metadata files from the prepared intake, retargeted to ccad. Five shared documents preserve every ccad byte and append only this carriage's own text. The primary person's unmerged entries and check registrations were not imported. The non-document delta applied cleanly; its check.sh insertion contains only the new Brougham step. No generated output was hand-merged.

Actual installed native near, placements7, covered identity10negative/chart12negative, changelog-entry, Node syntax and shell syntax checks all passed at low priority in less than2seconds total. The earlier outside-app11 placement-negative proof and six unchanged cards remain valid source evidence. The exact source/near native triangles, full frame/contact readback, source licenses, static-interface part-index map and all capability flags are checked. Complete staged binary patch and exact tree are included.

No supported rebuild, isolation measurement, full preflight, browser, commit, push or PR has occurred for this branch. Root's fullgate owns the shared lane. Wait for root release before running supported producers, publication/fullgate or graphics. The three ignored Glessner outputs still need exact currentccad recovery materialization; preserve any mismatched old output in an owned backup and inventory, never rebake it.

The additive1904 stand E1397.9,N−3240,bearing178.99 retains C02 and all1835 records. Actual carriageway/full-pole/body/obstacle clearance and main/public phone/desktop budget remain unresolved. The stand is25.157m from spawn; its33,502triangles and7material groups can add to the known T3032 draw-budget red. No moved stand, hidden geometry, distance change or threshold waiver qualifies this. Source-view review prefers V17 for development but photographic, occupied, hitch, boarding, door, traffic, riding and collision completion remain open.

Root remains the sole canonical ticket/claim writer for T2794. Do not mark that broad ticket complete for this parked increment.
