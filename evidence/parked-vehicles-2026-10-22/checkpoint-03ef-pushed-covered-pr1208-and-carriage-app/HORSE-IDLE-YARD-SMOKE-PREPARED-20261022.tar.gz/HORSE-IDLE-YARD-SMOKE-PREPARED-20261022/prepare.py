from pathlib import Path
import hashlib,json,difflib,shutil
out=Path(__file__).resolve().parent
old=Path('/workspace/shared/horse-standing-smoke-ARRIVAL-ENTRY-FIX-20261022')
s=(old/'capture_smoke.mjs').read_text(); original=s
s=s.replace("const model=await fs.readFile(cfg.source_model);if(model.length!==3211248||sha(model)!=='41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988')throw Error('Unchanged licensed source pin mismatch');", "const model=await fs.readFile(cfg.source_model);if(model.length!==3377384||sha(model)!=='c2559073966cfb5b2c9d2c536ca03fbf03b71734f9a11ffcff48d4ec86e4d25c')throw Error('Normalized source-bound idle derivative pin mismatch');")
s=s.replace("scope:'Development-base static smoke only,", "scope:'Development-base standing head/tail idle smoke only,")
s=s.replace("const app='/workspace/chicago/chicago/4d'", "const app=cfg.app_root")
s=s.replace("r.url().includes('horse-sevket-native.glb')", "(/horse-sevket.*\\.glb/.test(r.url())||r.url().includes('/standing-horse-idle/'))")
s=s.replace(" return{indexed_vertices:count,", " if(kind==='yard'&&(i.asset.animations.length!==7||i.receipt.mixer_count!==1||!i.receipt.autoplay||i.receipt.original_six_autoplay!==false||i.idle?.status.clip!=='sevket_reconstructed_head_tail_idle_v1'))throw Error('Enabled source-bound idle identity mismatch');\n  return{idle_status:i.idle?.status,indexed_vertices:count,")
needle="  report.selection=await page.evaluate(async()=>{"
assert needle in s
addition=r'''  // Additive current-target observation. Existing cameras, graphics budgets and contact guards remain unchanged.
  report.idle_setup=await page.evaluate(async()=>{
   const a=window.__chicago4d,T=await import('three'),i=a.standingHorses.instances[0],spec=await fetch(new URL('transport/parked/horse-sevket-sidecar.json',a.dataBase)).then(r=>r.json());
   if(!i.idle||!i.row.animation.enabled||!spec.idle.enabled)throw Error('Qualified idle is not enabled');
   const body=i.root.getObjectByName(spec.contact_mesh.renderer_name),bones=body.skeleton.bones;
   const sourceBones=[];i.asset.scene.traverse(n=>{if(n.isBone)sourceBones.push(n);});
   if(bones.some(b=>sourceBones.includes(b)))throw Error('Clone shares source bones');
   const patches={};for(const [name,patch]of Object.entries(spec.contacts)){patches[name]=[...new Set(patch.source_triangle_ids.flatMap(fi=>[0,1,2].map(k=>body.geometry.index.getX(fi*3+k))))];}
   if(Object.keys(patches).length!==4||Object.values(patches).some(v=>!v.length))throw Error('Missing nonempty hoof patches');
   const roles={head:[],tail:[]},index=body.geometry.index,skin=body.geometry.getAttribute('skinIndex'),weight=body.geometry.getAttribute('skinWeight');
   for(const id of new Set(index.array))for(const [role,joint]of [['head',12],['tail',14]])if(['X','Y','Z','W'].some(k=>skin['get'+k](id)===joint&&weight['get'+k](id)>0))roles[role].push(id);
   if(!roles.head.length||!roles.tail.length)throw Error('No actual head/tail weighted surface');
   const sample=()=>{i.root.updateMatrixWorld(true);body.skeleton.update();const point=id=>body.getVertexPosition(id,new T.Vector3()).applyMatrix4(body.matrixWorld).toArray();return{elapsed:i.idle.status.elapsed_s,patches:Object.fromEntries(Object.entries(patches).map(([k,ids])=>[k,ids.map(point)])),roles:Object.fromEntries(Object.entries(roles).map(([k,ids])=>[k,ids.map(point)])),bones:bones.map(b=>b.quaternion.toArray()),source_bones:sourceBones.map(b=>b.quaternion.toArray())};};
   const compare=(before,after)=>{const distances=(aa,bb)=>Math.max(...aa.map((v,k)=>Math.hypot(...v.map((x,j)=>x-bb[k][j]))));return{hoof_maximum_drift_m:Object.fromEntries(Object.keys(patches).map(k=>[k,distances(before.patches[k],after.patches[k])])),head_maximum_displacement_m:distances(before.roles.head,after.roles.head),tail_maximum_displacement_m:distances(before.roles.tail,after.roles.tail),bone_component_maximum_delta:Math.max(...before.bones.flatMap((q,k)=>q.map((v,j)=>Math.abs(v-after.bones[k][j])))),source_bone_component_maximum_delta:Math.max(...before.source_bones.flatMap((q,k)=>q.map((v,j)=>Math.abs(v-after.source_bones[k][j]))))};};
   window.__horseIdleYardObservation={sample,compare,before:sample()};
   return{status:i.idle.status,hoof_unique_vertices:Object.fromEntries(Object.entries(patches).map(([k,v])=>[k,v.length])),weighted_role_vertices:Object.fromEntries(Object.entries(roles).map(([k,v])=>[k,v.length])),clone_bones_disjoint:true,original_six_autoplay_receipt:i.receipt.original_six_autoplay};
  });
  // Observe the ordinary production host clock, not a synthetic mixer or direct pose assignment.
  await page.emulateMedia({reducedMotion:'no-preference'});
  await page.evaluate(()=>window.__chicago4d.setAnimationHold(false));
  await page.waitForFunction(()=>{const o=window.__horseIdleYardObservation,i=window.__chicago4d.standingHorses.instances[0];return i.idle.status.elapsed_s-o.before.elapsed>=1.5;},null,{timeout:15000,polling:100});
  report.idle_motion=await page.evaluate(()=>{const o=window.__horseIdleYardObservation,after=o.sample(),delta=o.compare(o.before,after);o.after=after;if(Math.max(...Object.values(delta.hoof_maximum_drift_m))>1e-5||delta.source_bone_component_maximum_delta!==0||delta.head_maximum_displacement_m<=1e-8||delta.tail_maximum_displacement_m<=1e-8)throw Error('Actual host idle motion/clone/planted-hoof observation failed: '+JSON.stringify(delta));return{...delta,elapsed_before_s:o.before.elapsed,elapsed_after_s:after.elapsed,host_clock_observed:true};});
  const activeState=await snapshot('yard');if(!activeState.stats.withinBudget)throw Error('Existing public render budget exceeded during idle');await shot('quarter-idle-active',activeState);
  await page.emulateMedia({reducedMotion:'reduce'});
  // Capture only after the actual media preference has reached the production layer.
  await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  const reducedStart=await page.evaluate(()=>{const o=window.__horseIdleYardObservation;o.pauseBefore=o.sample();return o.pauseBefore.elapsed;});
  await page.evaluate(()=>new Promise(r=>{let n=0;const next=()=>++n>=8?r():requestAnimationFrame(next);requestAnimationFrame(next);}));
  report.idle_reduced_motion=await page.evaluate(start=>{const o=window.__horseIdleYardObservation,after=o.sample(),d=o.compare(o.pauseBefore,after);if(!matchMedia('(prefers-reduced-motion: reduce)').matches||after.elapsed!==start||d.bone_component_maximum_delta!==0||Math.max(...Object.values(d.hoof_maximum_drift_m))>1e-5)throw Error('Actual reduced-motion host pause failed');return{elapsed_s:after.elapsed,bone_component_maximum_delta:d.bone_component_maximum_delta,hoof_maximum_drift_m:d.hoof_maximum_drift_m,media_preference_observed:true,render_frames_observed:8};},reducedStart);
  report.idle_hidden=await page.evaluate(()=>{const a=window.__chicago4d,o=window.__horseIdleYardObservation,prior=a.confidence.hidden.reconstructed;a.setAnimationHold(true);const before=o.sample();a.confidence.setHidden('reconstructed',true);a.standingHorses.update(a.camera,1,{reducedMotion:false});const after=o.sample(),d=o.compare(before,after),i=a.standingHorses.instances[0];if(i.group.visible||after.elapsed!==before.elapsed||d.bone_component_maximum_delta!==0)throw Error('Confidence-hidden owned idle did not pause');a.confidence.setHidden('reconstructed',prior);a.standingHorses.update(a.camera,0,{reducedMotion:true});return{hidden_scope:'existing reconstructed-confidence visibility; not OS document visibility',elapsed_s:after.elapsed,bone_component_maximum_delta:d.bone_component_maximum_delta,hoof_maximum_drift_m:d.hoof_maximum_drift_m,visible_after_restore:i.group.visible};});
  // Keep the original selection/card/confidence assertions and disposal after the observations.
'''
s=s.replace(needle,addition+needle)
s=s.replace("return{disposed,instances:a.standingHorses.instances.length};", "if(!i.idle.status.disposed||i.idle.status.mixer_count!==0)throw Error('Owned idle not retired before clone disposal');return{disposed,idle_status:i.idle.status,instances:a.standingHorses.instances.length};")
# This revision is yard-only. It must not accidentally mutate/run the historical materials fixture.
s=s.replace("!['materials','yard-desktop','yard-mobile'].includes(args[1])", "!['yard-desktop','yard-mobile'].includes(args[1])")
(out/'capture_smoke.mjs').write_text(s)
(out/'YARD-IDLE-DELTA.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='arrival-entry-fixed/capture_smoke.mjs',tofile='idle-yard-prepared/capture_smoke.mjs')))
shutil.copy2(old/'run_owned.py',out/'run_owned.py')
