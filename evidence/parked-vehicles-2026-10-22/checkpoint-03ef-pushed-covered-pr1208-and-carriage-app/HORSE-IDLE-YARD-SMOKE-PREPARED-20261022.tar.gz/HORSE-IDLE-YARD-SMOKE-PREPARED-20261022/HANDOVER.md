Prepared only: enabled standing head/tail idle, no browser or full gate executed.

Source target is the isolated /workspace/chicago-waistcoat app, HEAD b0924b41c25d0d9bf975feb9b6e245a1b3f288e3 plus staged tree 2c805cba64dfa8fb4f22cea096005c14cf3ce0a1. Root must gate/commit and normally publish before release. The expected published pins deliberately describe the frozen source target; they do not certify that the older current mirror already has those bytes. This packet does not touch the app, index, source branches, original material fixture or old receipts.

Source-only checks: node --check caller passed. Owned wrapper is byte-identical to the previously successful arrival-entry wrapper. Syntax alone is not actual browser qualification. Root's full gate and explicit browser-lane release remain required. No automatic next phase or retry.

Run one separately released phase, fresh output, using ordinary Chrome/loopback escalation:

    python3 /workspace/shared/HORSE-IDLE-YARD-SMOKE-PREPARED-20261022/run_owned.py \
      --lane-released --phase yard-desktop \
      --release-file /workspace/shared/HORSE-IDLE-YARD-DESKTOP-ROOT-RELEASED.json \
      --output-dir /workspace/shared/HORSE-IDLE-YARD-DESKTOP-ACTUAL-20261022

After root has viewed/accepted actual desktop output, the separately released mobile command is:

    python3 /workspace/shared/HORSE-IDLE-YARD-SMOKE-PREPARED-20261022/run_owned.py \
      --lane-released --phase yard-mobile \
      --release-file /workspace/shared/HORSE-IDLE-YARD-MOBILE-ROOT-RELEASED.json \
      --output-dir /workspace/shared/HORSE-IDLE-YARD-MOBILE-ACTUAL-20261022

Root copies the corresponding *-RELEASE-HELD.json into the phase-specific released file after checking normal publication parity and authorizing the lane, changing released/browser_lane_free to true. Preserve the held templates. Each original 360s whole/350s execution cap and explicit Playwright/Chromium/owned cleanup remains. The caller checks every frozen source/published/proof/caller pin before launch and again at termination. A legitimate new source tree requires a new declared packet; do not silently update these expected hashes.

Inherited checks are preserved: actual published site, welcome-arrival entry, ordinary year=1835, distant no-fetch, mobile light no-fetch then explicit balanced load, desktop1280x800/DPR1 and mobile390x780/DPR2, the actual .97 all-indexed-vertex fixed-camera guard, original budget, actual finite yard triangle support cache caps32/4096, same1mm per-foot sampled minima/-1e-5 penetration bound, coarse actual position-null/index-empty release, credit/unknown identity selection card, confidence draw/pick refusal and disposal. Requests now track the selected derivative plus lazy idle JSON as well as the original GLB pattern.

Exact original successful cameras remain: desktop side E-127.5/N-291.4 bearing180 pitch-12 and quarter E-124.9/N-293.4 bearing225 pitch-12; mobile side E-127.5/N-289.5 bearing180 pitch-7 and quarter E-123.1/N-291.6 bearing225 pitch-7. No fitting, source reposing or camera adaptation. The original two fixed screenshots use reduced motion, matching prior fixture conditions. One additional quarter-idle-active screenshot uses the same current quarter camera and full indexed framing/budget guard.

New observable checks use the real loaded c255 source-bound seven-clip asset,15-joint cloned skeleton and production host update; no arbitrary pose, synthetic mixer, new frame clock or invented animation is injected. They assert the qualified idle is enabled, the one owned mixer reports the declared head/tail clip and original-six-autoplay=false, and source and instance bone objects are disjoint. The source asset bone quaternions must stay exactly fixed. All four annotated hoof triangle patch vertices are sampled in world metres at the beginning/end of observed visible head/tail motion and remain within1e-5m. Actual positively head/tail-weighted body vertices must change (>1e-8m each). The actual production elapsed clock must advance by1.5s within a bounded15s wait after media no-preference, naturally honoring seeded rest delay and host frame cap. No wall-clock determinism claim.

Reduced-motion proof switches the real browser media preference to reduce, lets the production listener settle for2rAFs, then observes8rendered frames with exact unchanged elapsed time and bone quaternions plus planted hoof patch bounds. Hidden proof is specifically the real reconstructed-confidence visibility setting: with the existing animationHold hook preventing concurrent host clocks, the production layer receives a nonzero1s update with reducedMotion=false; hidden visibility must prevent any elapsed/bone change. The setting is restored. This is not an OS document.hidden test; the existing385-pose CPU proof separately covers adapter visibility semantics. Light teardown now additionally asserts the actual owned player disposed/mixer_count0 before reporting completion.

The caller cannot introspect private mixer actions; the original-six nonplay assertion is the receipt/current adapter API contract, corroborated separately by actual CPU proof02754399. This packet does not invent an action-introspection result. It does not prove exhaustive neck/tail self-contact, full-cycle world contact, gait, anatomical/photo quality or physical phone performance. Actual output/errors/terminal cleanup must be preserved and personally viewed before current-target native visual acceptance.

Original41acd source remains pristine. Selected derivative c2559073966cfb5b2c9d2c536ca03fbf03b71734f9a11ffcff48d4ec86e4d25c is3,377,384B; consumer532db89f, host507fcefb and runtime56a236a9 match reviewed source. CPU proof02754399 and peer reviewf0360598 are included as immutable input pins, not borrowed yard PASSes.
