from pathlib import Path
import json,hashlib,subprocess,difflib
here=Path(__file__).resolve().parent
app=Path('/workspace/chicago-waistcoat/chicago/4d'); site=Path('/workspace/chicago-waistcoat/site/4d')
hash=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
# Bind expected published bytes to the frozen app sources, NOT to the older currently published mirror.
paired={}
for name in ['main.js','yards.js','yard-static-support.js','standing-horses.js','standing-horse-idle.js']:
 paired[str(app/'renderers/web/js'/name)]=str(site/'walk/js'/name)
for name in ['scenes/1835.json','transport/parked/standing-horses.json','transport/parked/horse-sevket-sidecar.json','transport/parked/standing-horse-idle/source.json','transport/parked/standing-horse-idle/append-receipt.json']:
 paired[str(app/'data'/name)]=str(site/'data'/name)
for name in ['horse-sevket-native.glb','horse-sevket-portable-filtered-idle-v1.glb']:
 paired[str(app/'renderers/web/transport/standing-horse'/name)]=str(site/'walk/transport/standing-horse'/name)
expected={}
for source,published in paired.items(): expected[source]=hash(source);expected[published]=hash(source)
for p in [here/'capture_smoke.mjs',here/'run_owned.py',Path('/workspace/shared/horse-sevket-native-preview-source-20261022/ownership_supervisor.py'),Path('/workspace/shared/T2803-NORMALIZED-IDLE-ADAPTER-CPU-ACTUAL-20261022/ACTUAL-IDLE-ADAPTER-CPU.json'),Path('/workspace/shared/T2803-IDLE-CONSUMER-HOST-INDEPENDENT-REVIEW-20261022/REVIEW.json')]:expected[str(p)]=hash(p)
for phase in ['yard-desktop','yard-mobile']:
 cfg={'released':False,'browser_lane_free':False,'phase':phase,'app_root':str(app),'site_root':str(site),'source_model':str(app/'renderers/web/transport/standing-horse/horse-sevket-portable-filtered-idle-v1.glb'),'source_sha256':'c2559073966cfb5b2c9d2c536ca03fbf03b71734f9a11ffcff48d4ec86e4d25c','source_staged_tree':'2c805cba64dfa8fb4f22cea096005c14cf3ce0a1','expected_files':expected,'note':'HELD. Expected published hashes are frozen-source target hashes, not current mirror observations. Root must normally publish this exact gated/committed source, verify all pins, then copy this template and explicitly release ONE phase. No camera adaptation or retry. Desktop must pass and be personally reviewed before separate mobile release.'}
 (here/(phase+'-RELEASE-HELD.json')).write_text(json.dumps(cfg,indent=2)+'\n')
(here/'PUBLISHED-COPY-PINS.json').write_text(json.dumps({'status':'EXPECTED_AFTER_NORMAL_PUBLISH_NOT_OBSERVED','source_to_published':paired},indent=2)+'\n')
status=subprocess.run(['git','-C','/workspace/chicago-waistcoat','status','--porcelain=v1'],capture_output=True,text=True,check=True).stdout
(here/'SOURCE-STATUS-PREPARED.txt').write_text(status)
manifest={str(p.relative_to(here)):{'sha256':hash(p),'bytes':p.stat().st_size}for p in sorted(here.rglob('*'))if p.is_file()and p.name!='MANIFEST.json'}
(here/'MANIFEST.json').write_text(json.dumps({'state':'PREPARED_ONLY_NO_BROWSER_NO_GATE','source_staged_tree':'2c805cba64dfa8fb4f22cea096005c14cf3ce0a1','files':manifest},indent=2)+'\n')
