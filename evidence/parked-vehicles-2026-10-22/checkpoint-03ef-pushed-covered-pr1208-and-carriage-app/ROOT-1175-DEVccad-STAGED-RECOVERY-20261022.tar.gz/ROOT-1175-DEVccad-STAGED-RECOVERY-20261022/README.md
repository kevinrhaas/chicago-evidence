# Recover the resolved person integration

This is an uncommitted source checkpoint, not a gate pass. Fetch both commits named in RECOVERY.json. Start an isolated branch at the exact base; apply SOURCE-TEXT.patch; restore each binary path with `git show SOURCE_COMMIT:PATH` from its specified commit. Stage only these paths. `git write-tree` must equal the recorded staged tree. Then run full preflight and published rendering coverage before any normal DEV merge. All binary bytes are already pushed in the source commit; no large duplicate is included.

The supported resolver exited0, removed all3 generated conflicts, and left no unstaged changes. Exact incoming disclosure history survives with one5936-byte person insertion. No actual source gate on this merged tree is claimed.
