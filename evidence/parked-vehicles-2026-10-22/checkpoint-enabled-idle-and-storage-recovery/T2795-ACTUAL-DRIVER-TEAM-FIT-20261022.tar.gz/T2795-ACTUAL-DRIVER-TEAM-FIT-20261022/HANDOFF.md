# T2795 actual seated-driver and straight-team fit advance

Source-only Bardwell correction is ready for review. **Current canonical driver remains disabled.** No model, app, ticket, Git ref, browser, renderer or world change was made. Every native CPU invocation used one math thread, nice15 and a15s wall cap; actual longest was under1s.

## Exact actual inputs

- W01 parked refined master `274e737b…` (1,926,852 bytes), physical bench and footboard retained unchanged.
- Canonical96c4-lineage Bardwell sourceLOD0 `84cdeb6d…` (8,656,876 bytes), actual `sit_drive` at .5s; existing `rc_bardwell_otis`, reconstructed1835 teamster. No duplicate person or invented documentary driving assignment.
- Experimental26-joint horse `03a1f747…` (3,766,696 bytes), already in canonical metres. Original licensed native `41acd9be…` is evaluated in world skin coordinates, then subtracts origin `[.0013648444640481372,-.09537431257051576,-.0034172495824063565]` and scales by `.36440688373115426`. Do **not** repeat that conversion on03a1. Its independent default-parity receipt finds ≤.152µm position difference from that original shape. No original mesh, UV, materials, period attribution or rights changed here.

## Real old failure and proposed correction

`ACTUAL-POSED-POINTS.json` binds all three full input hashes and actual GLTFLoader/Mixer/LBS positions. Texture loading is suppressed only for CPU reading; no model/material content changes. `ACTUAL-CONTACT-MEASUREMENTS.json` clips every actual trouser triangle to the bench XZ footprint, rather than checking only body bones or vertices.

- Bench drawn topY1.5800000429153442m; board drawn topY1.1200000047683716m. Source rectangular edge dimensions differ from decoded float32 edges by ≤4.3e−8m; quoted penetration uses source XZ bounds and actual drawn top.
- Old trouser minimum over bench is −7.817783496mm, with56 clipped triangles crossing top. `PROPER-BENCH-CROSSING-WITNESSES.json` retains54 strict noncoplanar crossings with positive barycentric coordinates inside both actual serialized triangles, including cloth57 / bench8 at `[-.06483701934590837,1.5800000429153442,.6442022015198081]`. This is a genuine interior crossing.
- Hidden body minimum was +1.015859µm. Both33-vertex fixed sole sets have +.208297–.320785µm gaps; all450 shoe vertices fit board XZ. Whole-shoe heel margin is2.593114mm and toe margin28.704826mm.
- Moving the entire person up would float the shoes. Five bounded longitudinal checks over board-legal extremes also retain5.910–8.082mm penetration; no exhaustive arbitrary six-axis fit claim follows.

The two-file patch `BARDWELL-SEATED-CLOTHING-CORRECTION.patch` (SHA256 `ae4c28b6d8f95e009b280c6485867145179080e6491ca0e137fdd510e7d197c1`) changes only Bardwell's existing opt-in source pose and his row in the seated bindings, plus honest shared status text. Dufresne/Flynn rows are exactly unchanged, and no default pose, rest bone, scale, weights, mesh, recipe or bench changes.

The source internal root datum/pelvis/trunk rise14.08mm; two-bone IK fixes both **complete original foot/ball world frames**. This deliberately preserves the existing strict source-parent-chain guard: source root→pelvis both shift; the asset wrapper stays identity, and the full person is not rigidly lifted. `seated_clothing_correction.py` records the law-of-cosines/shortest-arc authoring operation, following the existing standing-idle math. It is external reproduction support, not a required new runtime helper.

`COUNTERFACTUAL-SEATED-FIT.json` and `CORRECTED-COUNTERFACTUAL-POINTS.json` evaluate these frames against the **unchanged actual canonical skin**, not merely source-body geometry:

| CPU control | Minimum trouser/bench gap | Crossing triangles | All450 shoe vertex movement |
| --- | ---: | ---: | ---: |
| Original actual clip | −7.817783mm |56 |0 |
| Insufficient13.8mm internal raise/IK |−.049306mm |4 |0 |
| Proposed14.08mm internal raise/IK |+.105583mm |0 |**exactly0** |
| Rejected whole-asset9mm lift |+1.182217mm |0 |9mm |
| Rejected3mm left-foot-frame drift |+.105583mm |0 |3mm |

The proposed clearance intentionally exceeds .1mm numerical allowance; zero-clearance is bracketed between13.8 and13.9mm, not claimed as an analytic global optimum. Final source parent-chain error ≤4.44e−16m; leg lengths .4207842929685104/.4395494596340218m remain unchanged to roundoff; rotation orthonormality error≤3.33e−16. Existing unmodified `load_study` accepts all56 bones; all10 existing seated source/refusal tests pass with the proposed Bardwell row and unchanged other poses. `git apply --check` passes against the disposable external exact preimages; no application occurred.

The final source pelvis isY1.6838198418267082m (actual-skin counterfactual1.6838199804505796m). Wrist heads move fromY1.919999763 to1.934079763m; hand-surface proxies rise equally. **No palm grip/rein endpoint is certified or kept artificially at its old height.** `FIT-METADATA-AND-HELD-ADAPTER-PARAMS.json` records numeric attachment offsets. Clothes now nearly touch the bench toward its front edge; this does not certify pelvic load distribution, biological seating, all-garment fit, animation transitions or appearance.

An initial counterfactual report used `getWorldPosition` for its *metadata* after the correct skin calculation; Three refreshed old local hierarchy for those metadata fields. It is retained as `COUNTERFACTUAL-INITIAL-METADATA-GETTER-REFRESH.json`. The final evaluator reads candidate matrix translations directly, asserts exact proposed-source equality, and verifies baseline, under-raise and both bad-foot controls. No original asset or actual failure was reclassified.

## Horse/tongue coupling: concrete seed, actual gap still open

The held metadata gives actual body triangle5198/5200 transverse points atY1.04,Z.46, with positive barycentric coordinates, and all actual rostral-most50mm body-band IDs/bounds. The band is a spatial head/muzzle vicinity proxy, **not a located mouth/bit**. Reconstructed internal shoulder/head controls are labeled controls, never certified surface sockets.

A straight diagnostic seed uses rootsX±.605m (actual axle half-track, explicitly reconstructed team-spacing choice) andZ3.815m (actual rest pole-endZ4.275 minus declared shoulder-sectionZ.46). This replaces neither old unacceptedZ3.9 nor .95m hitch-height with a claim of acceptance. Under this new stated seed, whole static horse AABBs clear the pole side by≥.211165m and the front wagon box longitudinally by≥1.103314m. Head and shoulder surface coordinates for each side are fully enumerated. No old89b socket or standing-only support tilt is inherited; source-default asymmetric hoof gaps persist and gait remains unqualified.

The actual tongue rests atY.535m, **.505m below** that declared shoulder section. Raising its unchanged2.75m pole toY1.04 would require −10.58164° pitch and move endpointZ to4.228234m; this is a geometric counterfactual only, not approved yoke height or pole operation. It would also change the aligned root station to3.768234m, so the old arbitrary height/Z combination cannot silently be reused.

**There is no actual doubletree, swingletree, collar/hames, trace or pole-support geometry in the current assembly.** Their positions and physical load path remain null, not invented contacts. Likewise bit/rein/finger contacts, four-foot walking/stride, articulated swept bounds, slope, mobile budget and world review remain open. The static seed is useful to author those fittings, but no assembly motion or actual hitch is enabled.

## Root integration boundary

Review the two-file patch using `SOURCE-CORRECTION-CONTROLS.json` exact preimages and `proposed/`. If accepted, canonical generation/export must still prove the new serialized clip, full clothes/bench and complete shoe positions, normals/weights/rig contract and actual static appearance. No candidate GLB hash exists here. The existing source-loader and refusal logic need no modification. Do not call this photographic, harness, gait, route, boarding or production acceptance.
