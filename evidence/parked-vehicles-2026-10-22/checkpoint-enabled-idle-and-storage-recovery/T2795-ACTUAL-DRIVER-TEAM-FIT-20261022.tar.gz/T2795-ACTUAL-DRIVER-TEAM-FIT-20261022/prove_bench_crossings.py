"""Proper triangle/seat-plane witnesses from pinned actual posed arrays, no model changes."""
import json,math,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;raw=(P/'ACTUAL-POSED-POINTS.json').read_bytes();g=json.loads(raw);cloth=next(m for m in g['objects']['driver']['meshes']if 'trousers'in m['name']);wood=next(m for m in g['objects']['wagon']['meshes']if m['name']=='vehicle_body_timber');top=1.5800000429153442
def triangles(m):
 for j in range(0,len(m['triangles']),3):yield j//3,[m['positions'][i]for i in m['triangles'][j:j+3]]
seat=[(j,p)for j,p in triangles(wood)if all(abs(q[1]-top)<1e-10 for q in p)]
def bary(p,tri):
 a,b,c=tri;ux=b[0]-a[0];uz=b[2]-a[2];vx=c[0]-a[0];vz=c[2]-a[2];det=ux*vz-vx*uz
 if abs(det)<1e-12:return None
 u=((p[0]-a[0])*vz-vx*(p[2]-a[2]))/det;v=(ux*(p[2]-a[2])-(p[0]-a[0])*uz)/det;return[1-u-v,u,v]
w=[]
for j,p in triangles(cloth):
 hits=[]
 for ai,bi in [(0,1),(1,2),(2,0)]:
  a,b=p[ai],p[bi];da=a[1]-top;db=b[1]-top
  if da*db>=0:continue
  t=da/(da-db);point=[a[k]+t*(b[k]-a[k])for k in range(3)];bc=[0,0,0];bc[ai]=1-t;bc[bi]=t;hits.append((point,bc))
 if len(hits)!=2:continue
 q=[(hits[0][0][k]+hits[1][0][k])/2 for k in range(3)];cb=[(hits[0][1][k]+hits[1][1][k])/2 for k in range(3)]
 for ji,t in seat:
  bb=bary(q,t)
  if bb and min(bb)>1e-6 and min(cb)>1e-6:
   w.append({'clothing_mesh':cloth['name'],'clothing_triangle':j,'clothing_vertex_ids':cloth['triangles'][j*3:j*3+3],'clothing_vertices_m':p,'seat_mesh':wood['name'],'seat_triangle':ji,'point_m':q,'positive_clothing_barycentric':cb,'positive_seat_barycentric':bb,'clothing_vertex_signed_distances_to_seat_plane_m':[v[1]-top for v in p]});break
out={'status':'Actual proper noncoplanar triangle crossings confirmed; no visual/contact acceptance','source_readback_sha256':hashlib.sha256(raw).hexdigest(),'method':'Clothing edges strictly straddle actual bench top plane; mid-segment point is strictly inside both clothing and actual serialized bench triangles. All positive barycentric witnesses retained.','actual_bench_top_triangles':seat,'proper_crossing_witness_count':len(w),'witnesses':w};assert w;assert all(min(x['positive_clothing_barycentric'])>0 and min(x['positive_seat_barycentric'])>0 for x in w);(P/'PROPER-BENCH-CROSSING-WITNESSES.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'proper_crossing_witness_count':len(w),'first':w[0]},indent=2))
