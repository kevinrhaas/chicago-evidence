"""Actual point/triangle contacts only, no geometry authoring or mutation."""
import hashlib,json,math,time
from pathlib import Path
P=Path(__file__).resolve().parent;start=time.monotonic();raw=(P/'ACTUAL-POSED-POINTS.json').read_bytes();g=json.loads(raw)
def bounds(p):return [[min(q[k]for q in p)for k in range(3)],[max(q[k]for q in p)for k in range(3)]]
def clip(poly,axis,value,sign):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  da=sign*(a[axis]-value);db=sign*(b[axis]-value)
  if da>=0:out.append(a)
  if (da>=0)!=(db>=0):
   t=da/(da-db);out.append([a[k]+t*(b[k]-a[k])for k in range(3)])
 return out
def footprint(mesh,rect,level):
 points=[];cross=[];tri=mesh['triangles'];p=mesh['positions'];count=0
 for j in range(0,len(tri),3):
  poly=[p[i]for i in tri[j:j+3]]
  for ax,val,sgn in [(0,rect[0],1),(0,rect[1],-1),(2,rect[2],1),(2,rect[3],-1)]:
   poly=clip(poly,ax,val,sgn)
   if not poly:break
  if not poly:continue
  count+=1;points+=poly;lo=min(q[1]for q in poly);hi=max(q[1]for q in poly)
  if lo<level<hi:cross.append(j//3)
 return {'clipped_triangle_count':count,'clipped_surface_bounds_m':bounds(points)if points else None,'minimum_signed_gap_to_top_m':min(q[1]-level for q in points)if points else None,'triangles_strictly_crossing_top_within_XZ':cross,'lowest_clipped_point_m':min(points,key=lambda q:q[1])if points else None}
driver=g['objects']['driver'];wagon=g['objects']['wagon'];horse=g['objects']['horse'];ms=driver['meshes'];shoe=next(m for m in ms if 'closed_shoes'in m['name']);trousers=next(m for m in ms if 'trousers'in m['name']);body=next(m for m in ms if 'body_0'in m['name']);furniture=wagon['extras']['driver_furniture'];seat=next(x for x in furniture['parts']if x['name']=='driver_bench_plank');fb=next(x for x in furniture['parts']if x['name']=='driver_footboard');seatrect=[seat['min_m'][0],seat['max_m'][0],seat['min_m'][2],seat['max_m'][2]];boardrect=[fb['min_m'][0],fb['max_m'][0],fb['min_m'][2],fb['max_m'][2]]
# Actual float32 board/bench triangles corroborate source metadata.
wood=next(m for m in wagon['meshes']if m['name']=='vehicle_body_timber')
def top_vertices(y,rect):return [q for q in wood['positions']if abs(q[1]-y)<1e-6 and rect[0]-1e-6<=q[0]<=rect[1]+1e-6 and rect[2]-1e-6<=q[2]<=rect[3]+1e-6]
seat_top=max(q[1]for q in top_vertices(1.58,seatrect));board_top=max(q[1]for q in top_vertices(1.12,boardrect))
feet={}
for side,sign in [('left',1),('right',-1)]:
 ix=[i for i,p in enumerate(shoe['rest'])if p[0]*sign>0];restlow=min(shoe['rest'][i][1]for i in ix);sole=[i for i in ix if shoe['rest'][i][1]<=restlow+.001];pp=[shoe['positions'][i]for i in sole];allp=[shoe['positions'][i]for i in ix];lo,hi=bounds(allp)
 feet[side]={'selection':'Closed-shoe original-rest sideX; sole is original-rest minimumY+1mm, same fixed vertex IDs posed by actual Mixer','shoe_vertices':len(ix),'fixed_sole_vertices':len(sole),'sole_vertex_ids':sole,'posed_sole_bounds_m':bounds(pp),'posed_whole_shoe_bounds_m':[lo,hi],'minimum_sole_gap_m':min(p[1]-board_top for p in pp),'maximum_sole_gap_m':max(p[1]-board_top for p in pp),'whole_shoe_XZ_inside_board_margins_m':{'left':lo[0]-boardrect[0],'right':boardrect[1]-hi[0],'rear':lo[2]-boardrect[2],'front':boardrect[3]-hi[2]}}
hands={}
for side,suffix in [('left','l'),('right','r')]:
 ix=[i for i,sk in enumerate(body['skin'])if sum(w for name,w in sk if name=='hand_'+suffix)>.5];pp=[body['positions'][i]for i in ix];hands[side]={'selection':'Actual body surface vertices with >0.5 weight on named hand bone; palm-core proxy, not certified rein socket or finger grip','vertex_ids':ix,'vertex_count':len(ix),'bounds_m':bounds(pp),'arithmetic_vertex_mean_m':[math.fsum(q[k]for q in pp)/len(pp)for k in range(3)],'wrist_bone_position_m':driver['frames']['hand_'+suffix]['position_m']}
seatcontact=footprint(trousers,seatrect,seat_top)
bodyseat=footprint(body,seatrect,seat_top)
# Narrow inverse point support along a world X line; every returned point lies on an
# actual serialized triangle, not an AABB/control pivot. Dedup coincident UV splits.
hb=horse['meshes'][1]
def surface_line(mesh,y,z):
 hits={};ps=mesh['positions'];tr=mesh['triangles']
 for j in range(0,len(tr),3):
  a,b,c=[ps[i]for i in tr[j:j+3]];dy1=b[1]-a[1];dz1=b[2]-a[2];dy2=c[1]-a[1];dz2=c[2]-a[2];det=dy1*dz2-dy2*dz1
  if abs(det)<1e-14:continue
  u=((y-a[1])*dz2-dy2*(z-a[2]))/det;v=(dy1*(z-a[2])-(y-a[1])*dz1)/det
  if u>=-1e-10 and v>=-1e-10 and u+v<=1+1e-10:
   x=a[0]+u*(b[0]-a[0])+v*(c[0]-a[0]);hits.setdefault(round(x,9),{'point_m':[x,y,z],'triangle':j//3,'barycentric':[1-u-v,u,v]})
 return sorted(hits.values(),key=lambda p:p['point_m'][0])
shoulder=surface_line(hb,1.04,.46)
chest_rows=[{'y_m':y,'z_m':z,'hits':surface_line(hb,y,z)}for y,z in [(.95,.46),(1.04,.46),(1.15,.46),(.95,.60),(1.04,.60),(1.15,.60)]]
zmax=max(p[2]for p in hb['positions']);muzzle_ix=[i for i,p in enumerate(hb['positions'])if p[2]>=zmax-.05]
features={'shoulder_plane_surface_intersections':{'declaration':'Actual body triangle intersection of Y1.04,Z.46 transverse line, selected from reconstructed proximal rig pivot band; not collar/neck-yoke contact approval','hits':shoulder},'additional_transverse_sections':chest_rows,'rostral_50mm_surface_band':{'declaration':'Pure spatial maximum-forward50mm body band; likely muzzle vicinity, not identified mouth/bit anatomy','vertex_ids':muzzle_ix,'bounds_m':bounds([hb['positions'][i]for i in muzzle_ix]),'mean_m':[math.fsum(hb['positions'][i][k]for i in muzzle_ix)/len(muzzle_ix)for k in range(3)]},'rig_pivots_are_not_contact_sockets':{k:v['position_m']for k,v in horse['frames'].items()if k in ['fore_l_shoulder','fore_r_shoulder','horse_neck','horse_head']},'horse_bounds_m':horse['bounds_m']}
pelvis=driver['frames']['pelvis']['position_m'];seatpoint=[0,seat_top,.65]
result={'status':'ACTUAL NUMERIC FIT OBSERVATION; not whole assembly/contact/world acceptance','source_readback_sha256':hashlib.sha256(raw).hexdigest(),'driver':{'person_id':'rc_bardwell_otis','identity_grade':'reconstructed','role':'teamster','scene':'1835','canonical_clip':'sit_drive','time_s':.5,'root_wrapper_transform':'identity; clip already authored in wagon metric frame','physical_bench_top_m':seat_top,'physical_footboard_top_m':board_top,'bench_XZ_m':seatrect,'footboard_XZ_m':boardrect,'pelvis_bone_m':pelvis,'pelvis_bone_offset_from_seat_m':[pelvis[k]-seatpoint[k]for k in range(3)],'trousers_over_bench':seatcontact,'body_over_bench_hidden_layer_control':bodyseat,'feet':feet,'hands':hands,'support_vertical_interval_m':{'explanation':'Exact no-penetration common rigidY adjustment lower bound across trousers/bench and both shoes/board; upper limit is explicitly1mm development sample support only, not historical/continuous/contact approval','nonpenetration_dy_min':max(-seatcontact['minimum_signed_gap_to_top_m'],*[-x['minimum_sole_gap_m']for x in feet.values()]),'within_1mm_dy_max':min(.001-seatcontact['minimum_signed_gap_to_top_m'],*[.001-x['minimum_sole_gap_m']for x in feet.values()])}},'horse':features,'missing_actual_geometry':['doubletree','swingletrees','collars/hames','traces','pole straps/neck-yoke','reins/bit contact identification'],'elapsed_seconds':time.monotonic()-start}
(P/'ACTUAL-CONTACT-MEASUREMENTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
