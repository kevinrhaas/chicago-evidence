# Fixed seated correction: all four current canonical Bardwell LODs

**The fixed14.08mm source correction does not clear all LODs. A separately reviewed correction is required.** No pose, threshold, model, app, Git ref or browser state was changed. The original near-only proposal/capsule remains unchanged.

Actual pinned primary `assets/humans/bardwell_otis_1835.lod{0,1,2,3}.glb` were loaded separately using pinned vendored Three/GLTFLoader. Each retained its own positions, skin indices, weights, rest transforms and inverse binds. Each actual `sit_drive` clip was sampled at .5s. The same fixed source-frame delta from proposed poseSHA `413bd3589d92169cd92c22331b24f52df7761643e52cafff28e496cda811c855` was then applied to that LOD's own posed bone frames. No LOD0 skin palette or shoe vertex IDs were reused for another LOD.

The actual W01 `274e737b…` timber bench/footboard was decoded too. All12 physical bench triangles/8 corners are retained in the report; exact drawn float32 XZ boundaries and topY1.5800000429153442m were used. Every trouser triangle was clipped against that footprint, without triangle/vertex subsampling. A positive minimum above top excludes contact with the full rectangular bench slab. For failures, strict noncoplanar crossing witnesses include positive barycentric coordinates in both an actual trouser triangle and an actual bench top triangle.

| LOD | Trouser triangles checked | Old gap mm | Fixed correction gap mm | Top crossings | Shoe vertices checked | All-shoe displacement |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
|0 |2717 |−7.817785 |+.105582 |0 |450 |exactly0 |
|1 |1629 |−7.817785 |+.105582 |0 |338 |exactly0 |
|2 |760 |−9.175907 |**−1.236442** |**6** |226 |exactly0 |
|3 |326 |−12.135700 |**−4.264882** |**6** |170 |exactly0 |

LOD2 retains2 strict interior witnesses; LOD3 retains4. First examples are trouser121/bench8 at `[-.1088983315,1.5800000429,.7940928984]` and trouser57/bench8 at `[-.1223742552,1.5800000429,.7951684282]`. Full positions, triangle/vertex IDs and positive barycentrics are saved, not only minimum-gap summaries.

All four complete original foot and ball bone matrices remain exactly unchanged. Every shoe vertex is tested, not just the soles. Per-LOD original-rest sole selection is derived afresh; every selected sole is still .208–.321µm above the board and each complete shoe fits inside board XZ.

Every vertex in every mesh with any ball-bone weight was also inspected:2002/1266/692/372 vertices respectively. All exclusively foot/ball-weighted vertices remain exactly unchanged. Body vertices also blended to the changing calf move by at most .017814/.017814/.007580/.004675mm; these are disclosed and are **not** described as fixed rigid shoe vertices or as proven full body/garment fit.

The near result differs from the original near-only clipped minimum by only1.65nm because this extension uses exact decoded bench XZ edges instead of nominal decimal source edges. It retains the same positive .1mm margin. No acceptance threshold was relaxed: zero clothing penetration, the original .1mm engineering clearance, exact all-shoe immobility and unchanged sole limits remain in the reader.

`read_all_lods.mjs` completed in .388887s with one math thread, nice19 and15s wall cap; actual terminal is **EXIT2**, denoting the retained LOD2/3 failures. An initial reader assertion counted16 candidate faces because cleat tops touch the bench bottom plane. Its source/stderr are preserved. The final selector additionally requires actual part-corner coordinates, isolating exactly the12 bench faces; this corrects reader membership and does not change assets, bounds or thresholds.

`SUMMARY.json` is the concise handoff; `ALL-LOD-ACTUAL-COUNTERFACTUAL.json` contains the full numeric evidence and bindings. Original near capsule SHA remains `a5912aa71313722d8c892914a65baeb666cdc67262727bf39ed51a226877c675`.

Next work must explicitly own the coarse-LOD clearance failure. The near-only two-file correction must not be treated as all-LOD accepted. A revised source-pose or contact-preserving LOD proposal needs review and fresh all-four CPU evidence; corrected canonical export and actual contact/render review remain mandatory afterward. No revised pelvis height is selected here. Current driver remains disabled.
