# T2980 covered sag — implemented, ready for fullgate release

Own worktree: /workspace/chicago-covered-sag
Branch: steward/t2980-covered-sag-20261022
Exact observed origin/dev and unchanged HEAD: 64e83fcd0a4fa48ba4373778af5666ec2c448de8
Staged candidate tree: 6593357c4e0f98003ff3169392ce4ca5be4b6e9a
Staged listing SHA256: e516ddb12b7ef1adfdee84ba237223356b19458624ffdc289f32cec4ddabde4a
Unstaged diff: empty. Eleven staged files; no commit/push. Root primary and secondary checkouts were not edited.

The six exact intake files are installed: two already produced actual GLBs and sidecars, the two-line core change, SOURCE pins. SOURCE now adds truthful baseline/refinement evidence lineage and the population caveat instead of treating the old initial no-main wording as current. Existing L-covered-wagons-2980 is extended, supported compile_liberties regenerates only that existing entry in data/liberties.json; no new liberty/identity/source/ticket. STATUS/ROADMAP and one T-2980 pending changelog describe the visible refinement and remaining scope. Original recipes/placements/runtime/materials/textures and all other models are unchanged.

Current existing production wrapper --verify EXIT0: actual source chain rebuilt both reviewed candidates, two variants/seven products exact. Single thread, nice15 and120-second cap. Covered identity (2 models +8 actual negatives), original chart contract (23 batches +12 negatives), placements6, source-use408, one changelog and final683-liberty markdown/JSON consistency all PASS. Complete logs/commands and exact file hashes are in STAGED-RECEIPT.json/TARGETED-CHECKS.json. git diff --cached --check passes.

No fullgate or browser ran; no commit until required check.sh PASS under root's released lane. Root can release ordinary full preflight next on this frozen staged tree. A later baseline merge/rederive must be recorded honestly; current partial results are not a later-tree/fullgate PASS. T3032's independent1904 budget red and every threshold remain untouched.

Historical mobile6FAIL+2continuationPASS and background-person/foliage caveat remain; desktop8/current source-published photographic comparison, distinct compressed LODs and occupied/photo acceptance are open. This is a bounded visible canvas refinement, not ticket or parent closure.

Pre-existing DEV64e docs/ROADMAP.md includes invalidUTF8 around offset425651. The implementation preserves every original byte outside its one T2980 row; no document recovery was attempted. Historical original geometry and proof capsules stay immutable. No ticket/queue changes.

ACTUAL-STAGED.patch is a complete Git binary patch against64e, including both actual GLBs and the new changelog. Its SHA256 is 5a4dc2eba5dcab3bcc09de1bb30a999e26b8f584899f91c23d0afdf466a41cce. This is a durable uncommitted backup, not a commit or approval to merge.
