from pathlib import Path
import ast,collections,hashlib,json,math,sys,time
import numpy as np
R=Path(__file__).parent;START=time.monotonic();base=(R/'baseline/generate.py').read_text();new=(R/'proposed/generate.py').read_text();oldline="        for z in [-.20,.07]:beam('step_support',body,(side*.45,.65,z),(side*.72,.35,z),.022,4)";begin=new.index('        # V15 source proposal:');end=new.index('\n\n    # Front and rear cabin',begin);block=new[begin:end];assert new.replace(block,oldline)==base
main=next(x for x in ast.parse(base).body if isinstance(x,ast.FunctionDef) and x.name=='main');cat=next(x for x in main.body if isinstance(x,ast.FunctionDef) and x.name=='catmull');env={'np':np};exec(compile(ast.fix_missing_locations(ast.Module(body=[cat],type_ignores=[])),'existing_catmull','exec'),env)
rows=[];outputs=[]
for side in [-1,1]:
 captures=[]
 def geometry(name,parent,vertices,faces,mat):captures.append((name,np.array(vertices),faces,mat))
 scope={**env,'side':side,'body':1,'geometry':geometry};exec('\n'.join(line[8:] for line in block.splitlines()),scope)
 assert len(captures)==2
 for order,(name,producer,faces,mat) in enumerate(captures):
  assert name=='step_support' and mat==4
  P=producer.copy();P[:,1]=P[:,1]*1.13+.03;F=np.array([[f[0],f[k],f[k+1]] for f in faces for k in range(1,len(f)-1)]);tri=P[F];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);length=np.linalg.norm(cross,axis=1);assert np.isfinite(P).all() and min(length)>1e-13
  E=collections.defaultdict(list)
  for f in F.tolist():
   for a,b in zip(f,f[1:]+f[:1]):E[tuple(sorted((a,b)))].append((a,b))
  assert all(len(v)==2 and v[0]==tuple(reversed(v[1])) for v in E.values())
  volume=math.fsum(float(np.dot(a,np.cross(b,c)))/6 for a,b,c in tri);assert volume>0
  # The broad faces are a planar stroke extruded alongZ: test its actual XY boundary.
  lower=producer[::4,:2];upper=producer[2::4,:2];polygon=np.concatenate([lower,upper[::-1]]);crossings=[]
  cr=lambda a,b:a[0]*b[1]-a[1]*b[0]
  for i in range(len(polygon)):
   a,b=polygon[i],polygon[(i+1)%len(polygon)];v=b-a
   for j in range(i+1,len(polygon)):
    if j==i+1 or (i==0 and j==len(polygon)-1):continue
    c,d=polygon[j],polygon[(j+1)%len(polygon)];w=d-c;den=cr(v,w)
    if abs(den)<1e-16:continue
    t=cr(c-a,w)/den;u=cr(c-a,v)/den
    if 1e-8<t<1-1e-8 and 1e-8<u<1-1e-8:crossings.append([i,j])
  assert not crossings
  source_z=[-.20,.07][order];first=producer[:4].mean(axis=0);last=producer[-4:].mean(axis=0);assert np.allclose(first,[side*.45,.65,source_z],rtol=0,atol=1e-15) and np.allclose(last,[side*.72,.35,source_z],rtol=0,atol=1e-15)
  # New lower cap is strictly inside unchanged V14 pad slab and conservative inscribed12gon.
  cap=producer[-4:];assert all(.34<p[1]<.36 and ((p[0]-side*.72)/.14)**2+((p[2]-source_z)/.065)**2<math.cos(math.pi/12)**2 for p in cap)
  pi=[13,14][order] if side<0 else [28,29][order]
  rows.append({'part_index':pi,'name':name,'vertices':len(P),'triangles':len(F),'closed_opposite_edges':True,'Euler':len(P)-len(E)+len(F),'positive_signed_volume_m3':volume,'minimum_triangle_area_m2':float(min(length)/2),'stroke_self_crossings':crossings,'original_attachment_centers_retained':True,'lower_cap_inside_V14_pad':True,'minimum_pad_Y_inset_root_m':min(min(p[1]-.34,.36-p[1])*1.13 for p in cap),'predicted_root_bounds_m':{'min':P.min(axis=0).tolist(),'max':P.max(axis=0).tolist()}});outputs.append(P)
# Actual V14 source extrema with only4support triangle ranges omitted: immutable others still determine fullbounds.
sys.path.insert(0,str(R/'baseline'));from index_streams import read_glb,attribute_rows
raw=Path('/workspace/shared/brougham-v14-footplates-ACTUAL-20261022/raw/brougham.glb');doc,binary=read_glb(raw);assert hashlib.sha256(raw.read_bytes()).hexdigest()=='ed15f00934809cf04f7946377c18a6d3c2c0a5501041ebcd5ff257b96a1d8f8e'
world={}
def visit(i,parent):
 world[i]=[parent[k]+doc['nodes'][i].get('translation',[0,0,0])[k] for k in range(3)]
 for child in doc['nodes'][i].get('children',[]):visit(child,world[i])
for i in doc['scenes'][doc.get('scene',0)]['nodes']:visit(i,[0,0,0])
allp=[];nonowned=[]
for i,node in enumerate(doc['nodes']):
 if 'mesh' not in node:continue
 mesh=doc['meshes'][node['mesh']]
 for prim in mesh['primitives']:
  pts=np.frombuffer(b''.join(attribute_rows(doc,binary,prim['attributes']['POSITION'])),dtype='<f4').reshape(-1,3).astype(float)+world[i];mask=np.ones(len(pts),dtype=bool)
  if mesh['name']=='surface_vehicle_body_4':
   for pi in [13,14,28,29]:
    p=doc['extras']['parts'][pi];assert p['name']=='step_support';start=3*p['triangle_start_in_batch'];mask[start:start+3*p['triangles']]=False
  allp.append(pts);nonowned.append(pts[mask])
a=np.concatenate(allp);keep=np.concatenate(nonowned);proposed=np.concatenate(outputs);assert np.array_equal(a.min(axis=0),keep.min(axis=0)) and np.array_equal(a.max(axis=0),keep.max(axis=0));assert np.all(proposed.min(axis=0)>a.min(axis=0)) and np.all(proposed.max(axis=0)<a.max(axis=0))
report={'status':'FINITE_SOURCE_MATH_PASS_NOT_FULL_GENERATION_OR_RENDER','elapsed_seconds':time.monotonic()-START,'precisely_one_owned_source_block_changed':True,'owned_existing_parts':[13,14,28,29],'prospective_other_part_PN_exact':462,'V14_footplate_parts12_27_protected':True,'prospective_parts':466,'V14_actual_triangles':32830,'prospective_triangles':32830+sum(r['triangles']-12 for r in rows),'source_reconstructed_section_m':{'along_Z':.016,'across_bend':.008,'body_Y_affine_retained':1.13},'all_other_helpers_recipe_nodes_materials_anchors_exact_by_source':True,'actual_other_V14_geometry_preserves_all_global_extrema':True,'proposed_bars_strictly_inside_actual_global_bounds':True,'bars':rows,'limits':['Pure source arithmetic only; no new GLB, GPU normals, ownership hash, full collision or image acceptance','Curved thin near stems have source support; precise hidden route, section and opposite mirror are original reconstruction','Predicted counts and protected462PN/globalbounds must be verified after separately released actualgeneration']};(R/'SOURCE-MATH-RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
