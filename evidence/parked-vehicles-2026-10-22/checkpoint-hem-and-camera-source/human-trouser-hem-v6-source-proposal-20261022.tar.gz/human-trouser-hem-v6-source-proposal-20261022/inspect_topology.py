from pathlib import Path
import sys,json,importlib.util,collections
sys.dont_write_bytecode=True
V=Path('/workspace/shared/human-tailoring-v5-source-proposal');sys.path.insert(0,str(D/'inputs/chicago/4d/tools'))
s=importlib.util.spec_from_file_location('v5',D/'preimages/chicago/4d/tools/human_workwear_fit.py');fit=importlib.util.module_from_spec(s);s.loader.exec_module(fit)
r=json.loads((D/'inputs/chicago/4d/data/humans/recipes/worker_1835.json').read_text());out=[]
for age in (25,35):
 b=json.loads((D/f'inputs/chicago/4d/assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json').read_text());m=b['meshes'][0];bones={x['name']:x for x in b['skeleton']};g=fit.garment_shell(m,'trousers',.007,r,bones,max(p[1] for p in m['positions_m']));ps=g['positions_m'];edges=collections.Counter(tuple(sorted(e)) for t in g['triangles'] for e in zip(t,t[1:]+t[:1]));adj=collections.defaultdict(set)
 for e,n in edges.items():
  if n==1:adj[e[0]].add(e[1]);adj[e[1]].add(e[0])
 seen=set();comps=[]
 for v in adj:
  if v in seen:continue
  todo=[v];vs=[]
  while todo:
   i=todo.pop()
   if i in seen:continue
   seen.add(i);vs.append(i);todo.extend(adj[i]-seen)
  comps.append({'vertices':len(vs),'degree_counts':dict(collections.Counter(len(adj[i]) for i in vs)),'x_range':[min(ps[i][0] for i in vs),max(ps[i][0] for i in vs)],'y_range':[min(ps[i][1] for i in vs),max(ps[i][1] for i in vs)],'indices':vs,'ys':sorted(set(ps[i][1] for i in vs))})
 out.append({'age':age,'vertices':len(ps),'faces':len(g['triangles']),'nonmanifold_edges':sum(n>2 for n in edges.values()),'ankles':{side:bones['foot_'+side]['head_m'] for side in ('l','r')},'boundaries':comps})
print(json.dumps(out,indent=2));Path(__file__).with_name('V5-TOPOLOGY-INSPECTION.json').write_text(json.dumps(out,indent=2)+'\n')
