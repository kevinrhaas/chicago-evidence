"""One finite source-only V6 replay on the two pinned prepared bodies; no poses."""
from pathlib import Path
import ast,collections,copy,hashlib,importlib.util,json,math,sys,time
sys.dont_write_bytecode=True
D=Path(__file__).parent;V=Path('/workspace/shared/human-tailoring-v5-source-proposal');INPUT=D/'inputs/chicago/4d';sys.path.insert(0,str(INPUT/'tools'))
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def need(v,s):
 if not v:raise AssertionError(s)
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def sub(a,b):return [x-y for x,y in zip(a,b)]
def boundaries(g):
 edges=collections.Counter(tuple(sorted(e)) for f in g['triangles'] for e in zip(f,f[1:]+f[:1]));need(max(edges.values())<=2,'manifold edges');adj=collections.defaultdict(set)
 for (a,b),c in edges.items():
  if c==1:adj[a].add(b);adj[b].add(a)
 need(all(len(v)==2 for v in adj.values()),'all boundary vertices degree two');seen=set();cycles=[]
 for first in adj:
  if first in seen:continue
  todo=[first];cycle=[]
  while todo:
   i=todo.pop()
   if i in seen:continue
   seen.add(i);cycle.append(i);todo.extend(adj[i]-seen)
  cycles.append(cycle)
 return cycles
rel=Path('chicago/4d/tools/human_workwear_fit.py');old=module('v5',D/'preimages'/rel);new=module('v6',D/'proposed'/rel);recipe=json.loads((D/'inputs/chicago/4d/data/humans/recipes/worker_1835.json').read_text());start=time.monotonic();report={'scope':'UNRENDERED finite source-only trim on prepared ages25/35; no full-fit, photo, canonical, world, LOD or animation acceptance','ages':[],'open_untouched':['Forty inherited idle0 negative source-face projections','Confirmed V4/V5 seated footwear coverage FAIL','All photographic/rendered acceptance and dense posed clothing coverage remain unqualified']}
funcs=lambda path:{n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(path.read_text())) if isinstance(n,ast.FunctionDef)}
a=funcs(D/'preimages'/rel);b=funcs(D/'proposed'/rel)
for name in a:
 if name!='garment_shell':need(a[name]==b[name],'original helper AST exact '+name)
for age in (25,35):
 path=INPUT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json';raw=path.read_bytes();body=json.loads(raw);m=body['meshes'][0];saved=copy.deepcopy(m);bones={x['name']:x for x in body['skeleton']};height=max(p[1] for p in m['positions_m']);before=old.garment_shell(m,'trousers',.007,recipe,bones,height);after=new.garment_shell(m,'trousers',.007,recipe,bones,height)
 need(m==saved and path.read_bytes()==raw,'same-body source input preserved');need(after==new.garment_shell(m,'trousers',.007,recipe,bones,height),'deterministic finite construction')
 if age==25:
  negatives=[]
  bad=copy.deepcopy(before);bad['triangles'].append(bad['triangles'][0]);cases=[('nonmanifold duplicated input face',bad,bones)]
  bad=copy.deepcopy(before);low=[i for c in boundaries(before) if max(before['positions_m'][i][1] for i in c)<.5 for i in c]
  for i in low:bad['weights'][i]={'pelvis':1.}
  cases.append(('ambiguous hem ownership',bad,bones));badbones=copy.deepcopy(bones)
  for side in ('l','r'):badbones['foot_'+side]['head_m'][1]+=.2
  cases.append(('invalid source ankle band',before,badbones))
  for name,bad,bb in cases:
   try:new.level_trouser_hems(bad,bb)
   except ValueError as e:negatives.append({'control':name,'refused':str(e)})
   else:raise AssertionError('negative control admitted '+name)
  report['negative_controls']=negatives
 for kind,offset in [('shirt',.006),('waistcoat',.014)]:need(old.garment_shell(m,kind,offset,recipe,bones,height)==new.garment_shell(m,kind,offset,recipe,bones,height),'entire '+kind+' exact V5 arrays and receipt')
 for lod in range(4):need(old.fitted_shoes(body,bones,lod)==new.fitted_shoes(body,bones,lod),'shoe arrays and guard exact lod'+str(lod))
 cut=after['receipt']['trouser_level_hem_v6'];levels={side:v['level_y_m'] for side,v in cut['sides'].items()};plane=max(levels.values());cycles=boundaries(after);need(len(cycles)==3,'exactly waist plus two closed cuff perimeters');hemcycles=[c for c in cycles if max(after['positions_m'][i][1] for i in c)<.5];need(len(hemcycles)==2,'two leg hem cycles')
 for cycle in hemcycles:
  ys={after['positions_m'][i][1] for i in cycle};need(len(ys)==1 and next(iter(ys)) in levels.values(),'closed cuff perimeter is level')
 index={ (tuple(p),tuple(sorted(w.items()))):i for i,(p,w) in enumerate(zip(after['positions_m'],after['weights']))};preserved=0
 for i,p in enumerate(before['positions_m']):
  if p[1]>=plane:
   j=index.get((tuple(p),tuple(sorted(before['weights'][i].items()))));need(j is not None,'existing geometry above narrow hem band exact');need(before['source_basis'][i]==after['source_basis'][j],'retained source basis exact');preserved+=1
 old_upper=[(tuple(tuple(before['positions_m'][i]) for i in f),uv,fi) for f,uv,fi in zip(before['triangles'],before['corner_uvs'],before['source_triangle_indices']) if min(before['positions_m'][i][1] for i in f)>=plane]
 new_upper=[(tuple(tuple(after['positions_m'][i]) for i in f),uv,fi) for f,uv,fi in zip(after['triangles'],after['corner_uvs'],after['source_triangle_indices']) if min(after['positions_m'][i][1] for i in f)>plane]
 need(all(x in old_upper for x in new_upper),'all upper faces are exact original V5 faces');need(len(new_upper)==len([x for x in old_upper if min(p[1] for p in x[0])>plane]),'no upper faces lost')
 for p,uv,w,basis in zip(after['positions_m'],after['uvs'],after['weights'],after['source_basis']):
  need(all(math.isfinite(x) for x in p+uv+list(w.values())+list(basis.values())),'finite arrays');need(1<=len(w)<=4 and abs(math.fsum(w.values())-1)<1e-12 and min(w.values())>0,'portable normalized skin');need(abs(math.fsum(basis.values())-1)<1e-12 and min(basis.values())>0,'source convex barycentric basis')
 lookup={sid:p for sid,p in zip(m['source_vertex_indices'],m['positions_m'])};sids=m['source_vertex_indices'];minimum=math.inf;uvmax=0.;newverts={i for i,basis in enumerate(after['source_basis']) if len(basis)>1};checked=set();oldbyfi={fi:f for f,fi in zip(before['triangles'],before['source_triangle_indices'])};minarea=math.inf;newmin=math.inf
 for f,uvs,fi in zip(after['triangles'],after['corner_uvs'],after['source_triangle_indices']):
  pts=[after['positions_m'][i] for i in f];nnew=cross(sub(pts[1],pts[0]),sub(pts[2],pts[0]));area=math.hypot(*nnew);need(area>1e-18,'no degenerate faces');minarea=min(minarea,area)
  source=m['triangles'][fi];uv={sids[i]:m['uvs'][i] for i in source};src=[m['positions_m'][i] for i in source];n=cross(sub(src[1],src[0]),sub(src[2],src[0]));n=[x/math.hypot(*n) for x in n]
  for i,corner in zip(f,uvs):
   basis=after['source_basis'][i];need(set(basis)<=set(uv),'source identity lies on stated original face');expected=[math.fsum(v*uv[sid][k] for sid,v in basis.items()) for k in range(2)];uvmax=max(uvmax,math.dist(corner,expected))
  if any(i in newverts for i in f):
   checked.add(fi);oldface=oldbyfi[fi];oldpts=[before['positions_m'][i] for i in oldface];on=cross(sub(oldpts[1],oldpts[0]),sub(oldpts[2],oldpts[0]));need(sum(x*y for x,y in zip(nnew,on))>0,'new cut triangle orientation retains V5 face')
   oldoffsets=[]
   for i in oldface:
    basis=before['source_basis'][i];p=[math.fsum(w*lookup[sid][k] for sid,w in basis.items()) for k in range(3)];oldoffsets.append(sum(x*y for x,y in zip(sub(before['positions_m'][i],p),n)))
   for i in f:
    basis=after['source_basis'][i];p=[math.fsum(w*lookup[sid][k] for sid,w in basis.items()) for k in range(3)];offset=sum(x*y for x,y in zip(sub(after['positions_m'][i],p),n));minimum=min(minimum,offset)
    if i in newverts:newmin=min(newmin,offset)
    need(min(oldoffsets)-1e-12<=offset<=max(oldoffsets)+1e-12,'new-corner source offset remains convex V5 range')
 need(uvmax<1e-12,'all face corner UVs retain actual source barycentrics');need(newmin>0,'new hem corners have positive actual source-face projected offsets');need(cut['maximum_discarded_cut_weight']<=.025,'unchanged discarded mass guard')
 rec={'age':age,'body_sha256':hashlib.sha256(raw).hexdigest(),'v5_vertices_faces':[len(before['positions_m']),len(before['triangles'])],'v6_vertices_faces':[len(after['positions_m']),len(after['triangles'])],'unchanged_original_vertices_above_hem':preserved,'new_source_edge_cut_vertices':len(newverts),'closed_cuff_cycle_vertices':[len(c) for c in hemcycles],'hem':cut,'newface_source_indices':sorted(checked),'newface_minimum_source_projection_m':minimum,'newcorner_minimum_source_projection_m':newmin,'maximum_source_corner_uv_error':uvmax,'minimum_twice_triangle_area_m2':minarea,'PASS':True};report['ages'].append(rec);(D/f'trousers-adult{age}.json').write_text(json.dumps([after],separators=(',',':')))
report['PASS']=True;report['elapsed_s']=time.monotonic()-start;report['preservation']='Original helper functions except garment_shell AST exact; only new pure hem helper plus trouser-only postprocess call. Body/identity/rig/skin, other garments, all shoe LOD arrays/guards, recipe and V5 breadth/upper faces exact. No masks, pose/root shift or guard relaxation.';(D/'FINITE-SOURCE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
