from pathlib import Path
import datetime,difflib,hashlib,json,shutil,subprocess,tempfile,tarfile
D=Path(__file__).parent;rel=Path('chicago/4d/tools/human_workwear_fit.py');old=D/'preimages'/rel;new=D/'proposed'/rel
patch=''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
(D/'V6-LEVEL-HEM-AGAINST-FROZEN-V5.patch').write_text(patch)
with tempfile.TemporaryDirectory(prefix='v6-hem-patch-',dir='/tmp') as temp:
 p=Path(temp)/rel;p.parent.mkdir(parents=True);shutil.copyfile(old,p)
 dry=subprocess.run(['patch','--dry-run','--batch','-p1'],input=patch,text=True,cwd=temp,capture_output=True);assert dry.returncode==0,dry.stderr+dry.stdout
 apply=subprocess.run(['patch','--batch','-p1'],input=patch,text=True,cwd=temp,capture_output=True);assert apply.returncode==0,apply.stderr+apply.stdout;assert p.read_bytes()==new.read_bytes()
controls=json.loads((D/'FINITE-SOURCE-CONTROLS.json').read_text());assert controls['PASS'];audit={'state':'FROZEN_SOURCE_ONLY_UNRENDERED','patch_dryrun_on_temporary_preimages_only':True,'proposed_file_byte_exact_after_patch':True,'finite_source_controls_pass':True,'app_index_git_ci_browser_server_mutations':False,'recipe_unchanged':True,'canonical_fullfit_or_photographic_acceptance':False,'inherited_idle0_negative_source_face_projections_open':40,'seated_footwear_coverage_FAIL_open':True,'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(D/'FINALIZATION-AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
files=[p for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ('CAPSULE-MANIFEST.json','MANIFEST.sha256')]
manifest={'state':'SOURCE_ONLY_UNRENDERED','files':[{'path':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]};(D/'CAPSULE-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');(D/'MANIFEST.sha256').write_text(''.join(f"{r['sha256']}  {r['path']}\n" for r in manifest['files'])+hashlib.sha256((D/'CAPSULE-MANIFEST.json').read_bytes()).hexdigest()+'  CAPSULE-MANIFEST.json\n')
archive=D.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as tar:tar.add(D,arcname=D.name)
sha=hashlib.sha256(archive.read_bytes()).hexdigest();archive.with_suffix(archive.suffix+'.sha256').write_text(sha+'  '+archive.name+'\n');print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha,'files':len(files)},indent=2))
