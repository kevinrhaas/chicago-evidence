"""One explicitly released focused viewport; no publish, preparation or retry."""
import hashlib
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SUPERVISOR = Path('/workspace/shared/horse-sevket-native-preview-source-20261022/ownership_supervisor.py')
assert hashlib.sha256(SUPERVISOR.read_bytes()).hexdigest() == '778e5623d81821a48aeae5080a8cbff4ef57901570ceea9935fa98ecd9bd0ce5'
RELEASE_RUNNER = HERE.parent / 'run_released.py'
assert hashlib.sha256(RELEASE_RUNNER.read_bytes()).hexdigest() == '076813a0ad4f31628e5cf01a0db621014ad8ce665484b12116d914f88349bccd'
sys.path.insert(0, str(SUPERVISOR.parent))
from ownership_supervisor import run_owned

assert len(sys.argv) == 3 and sys.argv[1] == '--released'
config_path = Path(sys.argv[2]).resolve()
cfg = json.loads(config_path.read_text())
assert cfg['released'] is True and cfg['browser_lane_free'] is True
assert cfg['scope'] == 'FOCUSED_RELEASE_FEED_SIX_NOT_QA11_OR_WHOLE13'
assert cfg['viewport'] == 'desktop'
assert Path(cfg['prepared_root']).resolve() == HERE
assert cfg['whole_timeout_seconds'] == 360
assert cfg['execution_timeout_seconds'] == 350
assert cfg['supervisor_output_root'] and cfg['output_root']
assert Path(cfg['supervisor_output_root']).resolve() != Path(cfg['output_root']).resolve()

# A second viewport cannot overlap another invocation of this prepared packet.
# An interrupted owner leaves a visible lock for root to inspect; no stale-lock retry.
lock_path = HERE / '.focused-browser-lane.lock'
descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
try:
    os.write(descriptor, json.dumps({'supervisor_pid': os.getpid(), 'viewport': cfg['viewport'], 'release': str(config_path)}).encode())
    os.close(descriptor)
    result = run_owned(
        [sys.executable, str(RELEASE_RUNNER), '--released', str(config_path)],
        cfg['supervisor_output_root'], whole_timeout=360, execution_timeout=350,
    )
    print(json.dumps(result, indent=2))
finally:
    lock_path.unlink()
sys.exit(result['exit_code'])
