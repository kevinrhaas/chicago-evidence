"""One explicitly released focused viewport. No preparation, publish or retry."""
import sys, json, hashlib, os, subprocess, datetime
from pathlib import Path

assert len(sys.argv) == 3 and sys.argv[1] == '--released'
cfg = json.loads(Path(sys.argv[2]).read_text())
assert cfg['released'] is True and cfg['browser_lane_free'] is True
assert cfg['viewport'] == 'desktop'
assert cfg['scope'] == 'FOCUSED_RELEASE_FEED_SIX_NOT_QA11_OR_WHOLE13'
app, site, prepared, out = map(Path, (cfg['app_root'], cfg['site_root'], cfg['prepared_root'], cfg['output_root']))
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *args: subprocess.check_output(['git', '-C', str(app), *args], text=True).strip()
assert git('rev-parse', 'HEAD') == cfg['expected_head']
assert git('rev-parse', 'HEAD^{tree}') == cfg['expected_tree']
assert not git('status', '--porcelain', '--', 'renderers', 'data', 'assets', 'tools/smoke_renderer.mjs')
manifest = json.loads((prepared / 'PREPARED-HELD.json').read_text())
assert sha((app / 'tools/smoke_renderer.mjs').read_bytes()) == manifest['source_sha256'] == cfg['expected_source_sha256']
caller = prepared / 'tools/focused_smoke.mjs'
assert sha(caller.read_bytes()) == manifest['caller_sha256'] == cfg['expected_caller_sha256']
required = [app / 'renderers/web/js/changelog.js', site / 'walk/js/changelog.js', site / 'walk/index.html']
assert cfg['expected_files'] and all(str(p) in cfg['expected_files'] for p in required)
assert all(sha(Path(p).read_bytes()) == pin for p, pin in cfg['expected_files'].items())
# T-0722 current publication contract: one exact feed and its exact production shim.
feed = site / 'js/changelog.js'
shim_source = app / 'tools/changelog_shim.mjs'
assert str(feed) in cfg['expected_files'] and str(shim_source) in cfg['expected_files']
assert required[0].read_bytes() == feed.read_bytes()
expected_shim = subprocess.check_output(['node', '--input-type=module', '-e',
    'const m = await import(process.argv[1]); process.stdout.write(m.WALK_SHIM)', shim_source.as_uri()])
assert required[1].read_bytes() == expected_shim
for name, pin in manifest['helpers'].items():
    assert sha((app / 'tools' / name).read_bytes()) == pin
    assert sha((prepared / 'tools' / name).read_bytes()) == pin
out.mkdir(exist_ok=False)
receipt = {'scope': cfg['scope'], 'whole_part13': False, 'whole_gate': False, 'pass': False, 'head': cfg['expected_head'], 'tree': cfg['expected_tree'], 'viewport': cfg['viewport'], 'caller_sha256': cfg['expected_caller_sha256'], 'source_sha256': cfg['expected_source_sha256'], 'input_pins': cfg['expected_files'], 'started': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
env = dict(os.environ, SMOKE_ROOT=str(site), SMOKE_STAGE='13', SMOKE_VIEWPORT=cfg['viewport'], SMOKE_YEAR='1835', SMOKE_TARGET='published', SMOKE_PORT=str(cfg['port']))
env.pop('SMOKE_ENTRY', None)
env.pop('SMOKE_SHOTS', None)
if cfg.get('pw_executable'): env['PW_EXECUTABLE'] = cfg['pw_executable']
with (out / 'stdout.log').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
    result = subprocess.run(['node', str(caller), '--published'], env=env, stdout=stdout, stderr=stderr)
receipt['exit_code'] = result.returncode
receipt['inputs_unchanged'] = all(sha(Path(p).read_bytes()) == pin for p, pin in cfg['expected_files'].items())
text = (out / 'stdout.log').read_text()
receipt['pass'] = result.returncode == 0 and receipt['inputs_unchanged'] and 'FOCUSED_RELEASE_FEED_PASS — SIX ORIGINAL ASSERTIONS; NOT QA11/WHOLE13/FULLGATE' in text
receipt['six_original_pass_labels'] = ['a first-time visitor is told there are unread notes', "the what's-new tab renders every release", 'entries carry a title and a stamped date', 'opening the tab clears the unread marker', 'a first visit flags nothing (no "last time" to differ from)', 'a returning visitor sees only what shipped since last time']
receipt['six_original_labels_observed_pass'] = all(('  pass  desktop 1280x800: ' + title) in text for title in receipt['six_original_pass_labels'])
receipt['fresh_Normal_precondition_observed_pass'] = '  pass  desktop 1280x800: focused release feed starts in an actual fresh Normal and unseen state' in text
receipt['QA11_retested'] = False
receipt['pass'] = receipt['pass'] and receipt['six_original_labels_observed_pass'] and receipt['fresh_Normal_precondition_observed_pass']
receipt['ended'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
sys.exit(0 if receipt['pass'] else 1)
