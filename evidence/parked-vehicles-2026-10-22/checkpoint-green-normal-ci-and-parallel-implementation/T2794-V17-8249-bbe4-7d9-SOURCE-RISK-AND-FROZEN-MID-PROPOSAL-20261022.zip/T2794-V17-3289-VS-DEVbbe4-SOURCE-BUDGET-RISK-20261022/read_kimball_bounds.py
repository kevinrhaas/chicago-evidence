"""Finite immutable Git-object read, reusing the pinned source-read function only."""
from pathlib import Path
import ast, hashlib, json, struct, subprocess, time, datetime
import numpy as np
D=Path(__file__).parent;W=Path('/tmp/chicago-covered-sag');source=D/'read_glessner_delta.py';text=source.read_text();tree=ast.parse(text);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='analyse')
def sha(b):return hashlib.sha256(b).hexdigest()
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(source),'exec'))
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
base='824957fe47dd70fad729c3b117cb18b695d54b0b';mid='bbe4de604ed3fed8133a54e09e92e4fa0aab8528';current='7d9afc0ecd8653f71c283dff05d951a9a57fda47';start=time.monotonic();rows=[]
for name in ['kimball_house_1801_prairie__as_mapped_1904.glb','first_presbyterian_church_2029_indiana__draft_1904.glb']:
 p='chicago/4d/assets/gltf/'+name;old=analyse(git('show',base+':'+p),True);new=analyse(git('show',mid+':'+p),True);identical=git('rev-parse',mid+':'+p)==git('rev-parse',current+':'+p);assert identical;rows.append({'path':p,'old':old,'bbe4':new,'7d9_same_exact_Git_blob':identical,'triangle_delta':new['default_scene_triangles']-old['default_scene_triangles']})
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'bbe4':mid,'current7d9':current,'helper_source_sha256':sha(source.read_bytes()),'seconds':round(time.monotonic()-start,3),'scope':'Actual referenced native POSITION vertices and node transforms, not actual rendered frustum/collision/budget','geometry':rows,'source_or_ref_mutations':0,'browser_runs':0};(D/'KIMBALL-CHURCH-ACTUAL-NATIVE-BOUNDS-DELTA.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'seconds':r['seconds'],'geometry':[{'name':q['path'],'old':q['old']['actual_node_transformed_bounds'],'new':q['bbe4']['actual_node_transformed_bounds'],'tri_delta':q['triangle_delta'],'same_in7d9':q['7d9_same_exact_Git_blob']}for q in rows]},indent=2))
