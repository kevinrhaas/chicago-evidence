"""One finite read of pinned existing packages; no materialize, producer or app write."""
from pathlib import Path
import sys, subprocess, tempfile, json, struct, hashlib, datetime, time
import numpy as np
W=Path('/tmp/chicago-covered-sag');A=W/'chicago/4d';D=Path(__file__).parent
sys.path.insert(0,str(A/'tools'))
from recover_glessner_v4 import verified_members
BASE='824957fe47dd70fad729c3b117cb18b695d54b0b'
CUR='7d9afc0ecd8653f71c283dff05d951a9a57fda47'
def git(*args):return subprocess.check_output(['git',*args],cwd=W)
def sha(b):return hashlib.sha256(b).hexdigest()
def analyse(blob,actual_positions=False):
 magic,version,total=struct.unpack_from('<4sII',blob);assert magic==b'glTF'and version==2 and total==len(blob)
 n,kind=struct.unpack_from('<II',blob,12);assert kind==0x4e4f534a;j=json.loads(blob[20:20+n]);binbase=28+n
 access=j['accessors'];views=j.get('bufferViews',[]);mesh=[]
 for m in j.get('meshes',[]):
  t=0
  for p in m['primitives']:
   assert p.get('mode',4)==4
   a=access[p['indices']]if'indices'in p else access[p['attributes']['POSITION']];assert a['count']%3==0;t+=a['count']//3
  mesh.append(t)
 def matrix(node):
  if'matrix'in node:return np.array(node['matrix'],dtype=float).reshape(4,4,order='F')
  x,y,z,w=node.get('rotation',[0,0,0,1]);r=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]],dtype=float);out=np.eye(4);out[:3,:3]=r*np.array(node.get('scale',[1,1,1]));out[:3,3]=node.get('translation',[0,0,0]);return out
 def array(i):
  a=access[i];v=views[a['bufferView']];assert 'extensions'not in v and not a.get('sparse');dtype={5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']];dims={'SCALAR':1,'VEC3':3}[a['type']];dt=np.dtype(dtype);return np.ndarray((a['count'],dims),dtype=dt,buffer=blob,offset=binbase+v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',dt.itemsize*dims),dt.itemsize))
 lo=np.array([np.inf]*3);hi=-lo;vertices=0;triangles=0
 def walk(i,parent,ancestors):
  nonlocal lo,hi,vertices,triangles
  assert i not in ancestors;node=j['nodes'][i];m=parent@matrix(node)
  if'mesh'in node:
   assert 'EXT_mesh_gpu_instancing'not in node.get('extensions',{});triangles+=mesh[node['mesh']]
   if actual_positions:
    for p in j['meshes'][node['mesh']]['primitives']:
     pos=array(p['attributes']['POSITION']);assert pos.dtype==np.dtype('<f4')
     idx=array(p['indices']).reshape(-1)if'indices'in p else None;count=len(idx)if idx is not None else len(pos)
     for k in range(0,count,65536):
      q=pos[idx[k:k+65536]]if idx is not None else pos[k:k+65536];points=q.astype(float)@m[:3,:3].T+m[:3,3];lo=np.minimum(lo,points.min(axis=0));hi=np.maximum(hi,points.max(axis=0));vertices+=len(points)
  for c in node.get('children',[]):walk(c,m,ancestors|{i})
 for i in j['scenes'][j.get('scene',0)]['nodes']:walk(i,np.eye(4),set())
 return {'bytes':len(blob),'sha256':sha(blob),'default_scene_triangles':triangles,'meshes':len(mesh),'nodes':len(j.get('nodes',[])),'actual_referenced_vertices_tested':vertices,'actual_node_transformed_bounds':{'min':lo.tolist(),'max':hi.tolist()}if actual_positions else None,'bounds_scope':'Actual referenced POSITION Float32 vertices transformed through the default native node hierarchy, not world placement or terrain.'if actual_positions else'Bounds not decoded for compressed web derivative.'}
start=time.monotonic();prefix='chicago/4d/docs/RESEARCH/glessner-v4-recovery/';oldmanifest=json.loads(git('show',BASE+':'+prefix+'manifest.json'));newbytes=git('show',CUR+':'+prefix+'manifest.json');newmanifest=json.loads(newbytes);old={}
for name,pin in oldmanifest['files'].items():
 blob=(A/name).read_bytes();assert len(blob)==pin['bytes']and sha(blob)==pin['sha256'];old[name]=analyse(blob,name.startswith('assets/gltf/'));del blob
with tempfile.TemporaryDirectory(prefix='t2794-budget-package-read-')as directory:
 recovery=Path(directory);(recovery/'manifest.json').write_bytes(newbytes)
 for part in newmanifest['parts']:(recovery/part['name']).write_bytes(git('show',CUR+':'+prefix+part['name']))
 # Existing read-only verifier checks every chunk, archive, exact member set and
 # each complete GLB's hash. No materialize/pack/restore call is made.
 members=verified_members(recovery)
 new={name:analyse(blob,name.startswith('assets/gltf/'))for name,blob in members.items()}
rows=[{'path':name,'old':old[name],'new':new[name],'triangle_delta':new[name]['default_scene_triangles']-old[name]['default_scene_triangles']}for name in old]
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Source-only exact existing package geometry deltas; no world or budget prediction','base':BASE,'current':CUR,'old_manifest_sha256':sha(git('show',BASE+':'+prefix+'manifest.json')),'new_manifest_sha256':sha(newbytes),'existing_verifier':'tools/recover_glessner_v4.py:verified_members only','package_all_parts_archive_and_complete_member_hashes_verified':True,'materialize_pack_restore_rebake_calls':0,'app_writes':0,'browser_runs':0,'seconds':round(time.monotonic()-start,3),'geometry':rows}
(D/'GLESSNER-8249-TO-7d9-EXACT-SOURCE-DELTA.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'seconds':r['seconds'],'geometry':[{'path':q['path'],'old':q['old']['default_scene_triangles'],'new':q['new']['default_scene_triangles'],'delta':q['triangle_delta'],'old_bounds':q['old']['actual_node_transformed_bounds'],'new_bounds':q['new']['actual_node_transformed_bounds']}for q in rows]},indent=2))
