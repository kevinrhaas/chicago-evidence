"""GPL-3.0-or-later: original external Glessner1904 coverage repair study.

No BPy, image pixels, body/likeness editing, canonical output or app writes.
Original CC0 garment output remains reconstructed and production-ineligible.
"""
from pathlib import Path
import copy,difflib,hashlib,json,math,time
import numpy as np

ROOT=Path('/tmp/chicago-covered-sag/chicago/4d')
OUT=Path('/workspace/shared/glessner1904-coverage-v1-HELD-20261022')
BODY='assets/authored/humans/era_studies/1904/glessner_john_j_1904.prepared.json'
GARMENT='assets/authored/humans/era_studies/1904/glessner_john_j_1904.garments.json'
BODY_SHA='8459b40305b07ad1a481958736160dabe43bf53f4fdc95d8503b6fe103483625'
GARMENT_SHA='5ee0032745a683d81cbd6baceda2394e7580046b42299cf9c099a3fd017c2482'
REFERENCE=Path('/workspace/chicago-images/prairie-1904/files/cgn-1620-tribune-1898-robert-law-portrait.jpg')
REFERENCE_SHA='0a98116e99b060f91262231c878d0a247e681cca6882ff1b7c0b898b6f2c00b7'
NAMES=['civilian_shirt_coverage_repair','civilian_coat_shoulder_coverage_repair','civilian_upper_trouser_coverage_repair']

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(condition,message):
 if not condition:raise ValueError(message)
def load_pin(relative,expected):
 p=ROOT/relative;require(digest(p)==expected,'Input SHA changed: '+relative)
 return json.loads(p.read_text())
def triangles(mesh):return np.asarray(mesh['positions_m'],float)[np.asarray(mesh['triangles'],int)]
def first_hit(origin,direction,meshes):
 best=None
 for mesh in meshes:
  t=triangles(mesh);e1=t[:,1]-t[:,0];e2=t[:,2]-t[:,0];h=np.cross(direction,e2);det=np.einsum('ij,ij->i',e1,h);ok=np.abs(det)>1e-11;inv=np.zeros(len(t));inv[ok]=1/det[ok];s=origin-t[:,0];u=inv*np.einsum('ij,ij->i',s,h);q=np.cross(s,e1);v=inv*(q@direction);distance=inv*np.einsum('ij,ij->i',e2,q)
  ids=np.flatnonzero(ok&(u>=-1e-8)&(v>=-1e-8)&(u+v<=1+1e-8)&(distance>1e-5)&(distance<.12))
  if len(ids):
   i=int(ids[np.argmin(distance[ids])]);candidate={'part':mesh['name'],'triangle':i,'distance_m':float(distance[i]),'front_facing':bool(det[i]>0)}
   if best is None or candidate['distance_m']<best['distance_m']:best=candidate
 return best

def main():
 start=time.monotonic();require(not OUT.exists(),'Fresh output only; do not overwrite actual result');OUT.mkdir()
 receipt={'status':'RUNNING','production_eligible':False,'scope':'Rest-source garment coverage only; no BPy/visual/pose/period-pattern acceptance'}
 try:
  body=load_pin(BODY,BODY_SHA);old=load_pin(GARMENT,GARMENT_SHA);require(digest(REFERENCE)==REFERENCE_SHA,'Period comparator changed')
  require(body['license']==old['license']=='CC0-1.0','Cleared source only');require(old['person_reference_id']=='glessner_john_j'and old['scene_date']=='1904-07-01'and old['appearance_grade']=='reconstructed'and old['production_eligible']is False,'Identity/era/eligibility changed')
  mesh=body['meshes'][0];p=np.asarray(mesh['positions_m'],float);f=np.asarray(mesh['triangles'],int);t=p[f];centers=t.mean(axis=1);cross=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);area=np.linalg.norm(cross,axis=1);require(np.all(area>1e-14),'Source degenerate face');face_normals=cross/area[:,None]
  # Smooth through ONLY explicitly documented source UV duplicates. The body
  # positions, topology, UVs, weights and IDs remain immutable.
  ids=np.asarray(mesh['source_vertex_indices'],int);normal_groups=np.zeros((int(ids.max())+1,3));
  for k in range(3):np.add.at(normal_groups,ids[f[:,k]],cross)
  lens=np.linalg.norm(normal_groups,axis=1);normal_groups[lens>0]/=lens[lens>0,None];normals=normal_groups[ids]
  require(np.all(np.linalg.norm(normals,axis=1)>.99),'Undefined body normal')
  bones={b['name']:b for b in body['skeleton']};height=body['report']['chosen_height_m'];waist=height*.585;shoulder=bones['upperarm_l']['head_m'][1];neck=bones['neck_01']['head_m'][1];wrist=abs(bones['hand_l']['head_m'][0]);knee=bones['calf_l']['head_m'][1]
  # These are explicit engineering coverage regions/ease, NOT dated patterns.
  # Wider whole-torso shirt backing closes the old narrow floating shirt front.
  shirt=(centers[:,1]>=waist-.10)&(centers[:,1]<=neck+.012)&(np.abs(centers[:,0])<.255)
  # Preserve the coat's open V; add only missing shoulder/back fabric above its
  # torso top. Existing coat, lapels, sleeves and shirt collar stay byte-exact.
  coat=(centers[:,1]>=shoulder-.055)&(centers[:,1]<=neck+.008)&(np.abs(centers[:,0])<.31)&~((centers[:,2]>0)&(np.abs(centers[:,0])<.105))
  # Cover actual pelvis/crotch/seat and both upper legs; overlap the old lower
  # tubes. No source anatomy is deleted, hidden by a new mask or recolored.
  lower=(centers[:,1]>=knee+.055)&(centers[:,1]<=waist+.025)&(np.abs(centers[:,0])<.30)
  definitions=[(NAMES[0],'shirt_plain_reconstructed',shirt,.010),(NAMES[1],'coat_dark_plain_reconstructed',coat,.022),(NAMES[2],'trousers_plain_reconstructed',lower,.024)]
  candidate=copy.deepcopy(old);repairs=[];shape_stats=[]
  for name,material,mask,ease in definitions:
   face_ids=np.flatnonzero(mask);selected=f[face_ids];used=np.unique(selected);remap=np.full(len(p),-1,dtype=int);remap[used]=np.arange(len(used));positions=p[used]+normals[used]*ease;local_faces=remap[selected];new_t=positions[local_faces];new_cross=np.cross(new_t[:,1]-new_t[:,0],new_t[:,2]-new_t[:,0]);new_area=np.linalg.norm(new_cross,axis=1);orientation=np.einsum('ij,ij->i',new_cross,cross[face_ids]);require(np.all(new_area>1e-14),'Repair degenerate face '+name)
   # Offset concavities may produce folds: retain the actual result and refuse
   # its guard rather than reducing clearance/relaxing orientation automatically.
   minimum_orientation=float(np.min(orientation));inverted=int(np.count_nonzero(orientation<=0))
   repair={'name':name,'material':material,'positions_m':positions.tolist(),'triangles':local_faces.tolist(),'uvs':[mesh['uvs'][i]for i in used],'weights':[mesh['weights'][i]for i in used],'repair_vertex_to_body_vertex':used.tolist(),'repair_triangle_to_body_triangle':face_ids.tolist(),'source_vertex_indices':ids[used].tolist(),'construction':'Original body-fitted offset coverage surface; not a sewn/draped or period-pattern accepted garment','normal_ease_m':ease}
   repairs.append(repair);shape_stats.append({'part':name,'vertices':len(used),'triangles':len(selected),'normal_ease_m':ease,'inverted_source_normal_faces':inverted,'minimum_area_m2':float(new_area.min()/2),'minimum_orientation_dot':minimum_orientation})
  candidate['meshes'].extend(repairs);candidate['coverage_repair']={'version':1,'source_body_sha256':BODY_SHA,'source_garment_sha256':GARMENT_SHA,'person_likeness_changed':False,'source_body_changed':False,'original_garment_parts_changed':False,'production_eligible':False,'period_comparator':{'record':'cgn-1620-tribune-1898-robert-law-portrait','date':'1898-02-25','catalog_url':'https://chicagology.com/chicagostreets/prairieavenue/1620prairie/','sha256':REFERENCE_SHA,'rights_basis':'Existing image-library public-domain ruling:1898US publication, faithful reproduction','observed':'Actually viewed bust drawing: civilian coat shoulders/lapels over closed shirt/collar and neckwear','limit':'Robert Law, not Glessner; six years earlier; no trousers shown. No face, clothing pixels, pattern or metric cut copied.'},'acceptance':'HELD: rest coverage checks only; no pose/LOD/normal-export/render/source-match acceptance'}
  candidate['limitations'].append('Added body-fitted coverage shells repair exposed-region study only; overlaps, fit/drape, animation, sewn construction and photographic appearance remain unaccepted')
  require(candidate['meshes'][:len(old['meshes'])]==old['meshes'],'Original garment parts changed');require(candidate['skeleton']==old['skeleton']==body['skeleton'],'Skeleton changed');require(candidate['materials']==old['materials'],'Palette changed')
  for m in repairs:
   require(all(m['weights'][j]==mesh['weights'][i]and m['uvs'][j]==mesh['uvs'][i]for j,i in enumerate(m['repair_vertex_to_body_vertex'])),'Body weight/UV derivation changed')
   for w in m['weights']:require(0<len(w)<=4 and abs(sum(w.values())-1)<1e-8,'Invalid skin weights')
  output=OUT/'glessner1904.coverage-v1.garments.json';output.write_text(json.dumps(candidate,separators=(',',':'))+'\n');new_sha=digest(output)
  # Deliver an unapplied exact adapter patch. New source-derived surfaces retain
  # the body's winding and do not enter the legacy reversed-parts list.
  adapter_path='tools/human_era_study_1904.py';adapter=(ROOT/adapter_path).read_text();modified=adapter.replace('GARMENT_SHA="'+GARMENT_SHA+'"','GARMENT_SHA="'+new_sha+'"');needle='"civilian_closed_shoe_l","civilian_straight_trouser_r","civilian_closed_shoe_r"]';require(needle in modified,'Adapter component-list preimage changed');modified=modified.replace(needle,needle[:-1]+','+','.join('"'+n+'"'for n in NAMES)+']');(OUT/'human_era_study_1904.py').write_text(modified);(OUT/'adapter.patch').write_text(''.join(difflib.unified_diff(adapter.splitlines(True),modified.splitlines(True),fromfile='a/'+adapter_path,tofile='b/'+adapter_path)))
  # Independent frontal witnesses are selected from actual body faces, not
  # from repair output. Broad skin samples include the demonstrated regions.
  targets=[('upper',x,y)for x in [-.18,-.12,0,.12,.18]for y in [1.36,1.43,1.48]]+[('thigh',x,y)for x in [-.16,-.10,.10,.16]for y in [.73,.84,.95]]
  witnesses=[];seen=set()
  for region,x,y in targets:
   valid=np.flatnonzero((face_normals[:,2]>.35)&(np.abs(centers[:,0]-x)<.035)&(np.abs(centers[:,1]-y)<.035))
   require(len(valid)>0,'No independent body witness near '+str((region,x,y)));i=int(valid[np.argmin((centers[valid,0]-x)**2+(centers[valid,1]-y)**2)]);
   if i in seen:continue
   seen.add(i);point=centers[i];before=first_hit(point,np.array([0.,0.,1.]),old['meshes']);after=first_hit(point,np.array([0.,0.,1.]),candidate['meshes']);witnesses.append({'region':region,'body_triangle':i,'body_point_m':point.tolist(),'before':before,'after':after})
  before_missing=[w for w in witnesses if w['before']is None];after_missing=[w for w in witnesses if w['after']is None]
  require(digest(ROOT/BODY)==BODY_SHA and digest(ROOT/GARMENT)==GARMENT_SHA,'Immutable inputs modified')
  receipt.update({'status':'ACTUAL_REST_COVERAGE_PASS'if not after_missing and all(s['inverted_source_normal_faces']==0 for s in shape_stats)and len(before_missing)>0 else 'ACTUAL_REST_COVERAGE_FAIL','source_pins':{BODY:BODY_SHA,GARMENT:GARMENT_SHA,adapter_path:digest(ROOT/adapter_path),'period_reference':REFERENCE_SHA},'candidate_sha256':new_sha,'candidate_components':len(candidate['meshes']),'candidate_triangles':sum(len(m['triangles'])for m in candidate['meshes']),'unchanged_original_components':len(old['meshes']),'normal_orientation':shape_stats,'witness_count':len(witnesses),'before_missing':len(before_missing),'after_missing':len(after_missing),'baseline_negative_control_has_missing':len(before_missing)>0,'witnesses':witnesses,'body_unchanged':True,'skeleton_unchanged':True,'original_meshes_unchanged':True,'elapsed_seconds':time.monotonic()-start})
 except Exception as exc:
  receipt.update(status='ACTUAL_EXCEPTION',error=repr(exc),elapsed_seconds=time.monotonic()-start)
 finally:
  (OUT/'ACTUAL-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items()if k not in ['witnesses','source_pins']},indent=2));return 0 if receipt['status']=='ACTUAL_REST_COVERAGE_PASS'else 2
if __name__=='__main__':raise SystemExit(main())
