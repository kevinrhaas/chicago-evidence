# Glessner1904: held source clothing-coverage repair

This is ONE external follow-up parcel for existing John J.Glessner, after unchanged PR1175. No app, Git, ticket, asset eligibility, body/likeness or source registry was changed. No Blender, browser, fullgate, rendering, export, LOD generation or animation was run. Rest-geometry checks passed; photographic appearance has not been inspected.

## Concrete output

`glessner1904.coverage-v2.garments.json` is a new original reconstructed garment candidate, SHA25663074327e78d3be6da9028c6b7e4d9b41bc48052523b88a670820e18388cfb12. It retains the exact13 original1904 civilian garment meshes and5 materials and adds4 same-material coverage surfaces: full shirt backing, a body-fitted coat shoulder/back patch, and left/right upper-trouser envelopes. Total17 components/10,754 triangles versus original13/5,408. No1835 garment was copied or relabeled. The original portable56-joint skeleton, body, age/height, UVs/skin, hair, eyes, likeness, shoes and material palette are untouched.

The actual saved front PNG motivating this work is `/workspace/shared/human-visible-next/era-studies/published/glessner_john_j_1904_study.lod0-desktop-standing-front.png`: exposed shoulder/chest and large upper-thigh regions. This candidate addresses those rest-coverage holes, not the still-young-looking head or finished tailoring.

## Source/period boundaries

The identity remains `glessner_john_j`, attested, scene1904-07-01, depiction reconstructed and production-ineligible. Existing source recipe has `garment_sources:[]` and explicitly no dated civilian pattern. Preserve that until a real registry source is read/added; do not make a source ID from a filename.

A real period comparator WAS found in the existing research library and actually viewed: Chicago Tribune, February25,1898, Robert Law portrait drawing, record `cgn-1620-tribune-1898-robert-law-portrait`. Public-domain basis in the existing MANIFEST:1898US publication, faithful reproduction. Catalog https://chicagology.com/chicagostreets/prairieavenue/1620prairie/ . Local image `/workspace/chicago-images/prairie-1904/files/cgn-1620-tribune-1898-robert-law-portrait.jpg`, SHA2560a98116e99b060f91262231c878d0a247e681cca6882ff1b7c0b898b6f2c00b7. Actual pixels show civilian coat shoulders/lapels over a closed shirt/collar and neckwear. This bounds the visible layered civilian coverage, six years before1904. It is NOT Glessner, not his likeness or personal clothing, does not show trousers, and does not qualify a complete1904 suit pattern. No portrait or garment pixels, facial features, measurements or traced cut were copied.

Trousers' exact cut, all numerical ease, cloth colors and new topology remain original reconstruction. Sears1902 workwear and1835 Mount paintings were not spent as Glessner's civilian suit evidence. The museum portrait/likeness and mature-skin gaps remain real.

## Actual geometry work and results

The V1 external candidate added smoothed body-normal offsets. Actual result:27 frozen frontal body-surface witnesses changed from12 uncovered to0, but the noninversion guard failed on2 shirt and62 trouser faces. `../glessner1904-coverage-v1-HELD-20261022/ACTUAL-RECEIPT.json` and `ACTUAL-FOLD-WITNESSES.json` preserve the failure. Shirt folds were bilateral nipple-detail triangles; trouser folds were inner-groin/rear-cleft concavities. Clothing must bridge those details, not inflate anatomical topology.

V2 therefore replaces only those failed shirt/trouser coverage surfaces with newly authored radial loft topology fitted around actual body sections. Their positive-height rings bridge anatomical concavities and have explicit original ease12mm shirt/18mm upper trousers. The successful V1 coat shoulder patch is retained exactly. This is a construction change, not a lower clearance, dropped triangle, threshold waiver or parameter sweep.

`ACTUAL-RECEIPT.json`:0.379s nice19, all numerical thread counts1, exit0. Exact SAME27 frozen frontal body-face witnesses: original12 uncovered; V2zero uncovered. All new loft faces have positive radial orientation and nonzero area; all retained coat shoulder faces keep positive source orientation. The independent section-containment maximum error is4.44e-16. The original13 meshes/body/skeleton/palette remain unchanged; removing the4 repairs reproduces original12 witness failures. These are sparse front-facing rest tests, not universal enclosure or a rendered image.

`ACTUAL-ADAPTER-ARRAY-CHECK.json`: existing1904 adapter's actual `validate_mesh` function validates all17 candidate components, UV/weight/triangle arrays and normalized≤4 skin influences. Adapter exact component list and candidate/recipe SHA agree. No BPy import/execution. The lofts inherit actual nearest-body-vertex skin weights unchanged; new cylindrical UVs are original, with no image texture transfer.

## Unapplied integration source and exact handoff

Original source checkout during this read was `/tmp/chicago-covered-sag/chicago/4d`, HEAD3289b16cdc671a6ddf4c2e25587e8f0bd670fdb3. Inputs are pinned by file SHA, not by assuming that head is the next merge base:

* `assets/authored/humans/era_studies/1904/glessner_john_j_1904.prepared.json`:8459b40305b07ad1a481958736160dabe43bf53f4fdc95d8503b6fe103483625.
* Original `glessner_john_j_1904.garments.json`:5ee0032745a683d81cbd6baceda2394e7580046b42299cf9c099a3fd017c2482.
* Full adapter/recipe/helper/period-reference input hashes are in `ACTUAL-RECEIPT.json`. Both actualV1FAIL and actualV2PASS are retained separately.

Files delivered:

* `UNAPPLIED-source.patch`: exact small adapter+recipe patch. It updates the pinned garment SHA and exact allowed component names; no guard is removed or generalized.
* `human_era_study_1904.py`: full external proposed adapter copy.
* `1904.coverage-v2.recipe.json`: external proposed manifest copy; appearance/production/source qualifications are unchanged.
* `glessner1904.coverage-v2.garments.json`: generated candidate array file; it must accompany the small patch if later integrating.
* Sibling `/workspace/shared/glessner1904-coverage-v{1,2}-HELD-20261022.py`: reproducible no-BPy source builders, with fresh-output refusal and actual failure receipts. V2 imports V1's pinned read-only helpers and copies only the known positive V1 coat patch.

Do NOT apply the old complete adapter over a newer authoring checkout. After current PR1175 lands, a future integrator should compare exact file pins against the then-current1904 module/recipe, reconcile the4 owned new components and garment SHA, and retain all newer normal, morphology, rig, export, context and visibility fixes. The existing `prepare_canonical_meshes` shoe/mask policy remains unchanged. The new same-material components add4 source meshes; actual draw calls, LOD reduction and resource budgets need measurement rather than assumptions.

If later authorized to integrate for actual visual review: install the candidate arrays at the existing1904 garment path together with only the reviewed adapter/manifest changes; use the existing canonical era-study pipeline and unchanged guards. First inspect neutral-light and intended-scene full/close front/profile/three-quarter views on both viewports. Check shoulders/neck/armholes, back/sides, V/lapels, trouser waist/crotch/seat/inner leg, layering, hands and closed shoes. Then inspect idle/walk/passenger deformation and allLODs. No integration or run is authorized by this note itself.

Known remaining limits: new coverage surfaces overlap existing garment sheets and the two upper-trouser envelopes overlap near the crotch; their joins are not sewn. No whole-body self-intersection, anatomical clearance, pose, drape, custom-normal/export, back/side appearance, LOD, source-matched cut, mature face/skin or photographic acceptance is claimed. Do not hide any newly exposed issue with deleted body faces or an expanded body mask. This parcel is a concrete saved next-source improvement with actual bounded checks, not a production release.
