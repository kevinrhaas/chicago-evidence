"""GPL-3.0-or-later: original fitted-envelope1904 garment coverage study.

Success means bounded rest-geometry witnesses only. No BPy or visual acceptance.
V1 anatomy-offset FAIL is immutable; clothing lofts replace its concave shells.
"""
import copy,difflib,hashlib,importlib.util,json,time
from pathlib import Path
import numpy as np

HELPER=Path('/workspace/shared/glessner1904-coverage-v1-HELD-20261022.py')
spec=importlib.util.spec_from_file_location('coverage_v1_pinned_helpers',HELPER);v1=importlib.util.module_from_spec(spec);spec.loader.exec_module(v1)
OUT=Path('/workspace/shared/glessner1904-coverage-v2-HELD-20261022')
V1=Path('/workspace/shared/glessner1904-coverage-v1-HELD-20261022/glessner1904.coverage-v1.garments.json')
V1_SHA='a4506ee1df786c583da392c780418d5128a04dc0a34f3813ea9fbcb3fae098f2'
NAMES=['civilian_shirt_fitted_envelope','civilian_coat_shoulder_coverage_repair','civilian_upper_trouser_envelope_l','civilian_upper_trouser_envelope_r']
require=v1.require

def make_loft(body,name,material,levels,side=None):
 """Positive-height radial rings enclose actual local body sections.

 This is original engineering garment topology, not an extracted anatomy shell
 or a period sewing pattern. Concavities are bridged rather than inflated.
 """
 source=body['meshes'][0];p=np.array(source['positions_m']);N=32;ease=.012 if side is None else .018;points=[];uvs=[];weights=[];nearest=[];rings=[]
 for row,y in enumerate(levels):
  eligible=(np.abs(p[:,1]-y)<.021)&(np.abs(p[:,0])<(.255 if side is None else .30))
  if side is not None:eligible&=(p[:,0]*side>=0)
  ids=np.flatnonzero(eligible);require(len(ids)>3,'Insufficient actual body section at '+str((name,y)))
  q=p[ids];cx=0. if side is None else float((q[:,0].min()+q[:,0].max())/2);cz=float((q[:,2].min()+q[:,2].max())/2)
  rx=float(np.max(np.abs(q[:,0]-cx)))+ease;rz=float(np.max(np.abs(q[:,2]-cz)))+ease
  # The minimum uniform ellipse scale which contains every sampled section
  # point, with explicit ease. No body vertex or source file moves.
  scale=max(1.,float(np.sqrt(np.max(((q[:,0]-cx)/rx)**2+((q[:,2]-cz)/rz)**2))));rx*=scale;rz*=scale
  rings.append({'y_m':float(y),'center_xz_m':[cx,cz],'radii_xz_m':[rx,rz],'body_section_vertices':len(ids),'minimum_section_ellipse_margin':float(1-np.max(((q[:,0]-cx)/rx)**2+((q[:,2]-cz)/rz)**2))})
  for col in range(N+1):
   a=col*2*np.pi/N;point=np.array([cx+np.sin(a)*rx,y,cz+np.cos(a)*rz]);j=int(ids[np.argmin(np.sum((q-point)**2,axis=1))]);points.append(point.tolist());uvs.append([col/N,row/(len(levels)-1)]);weights.append(copy.deepcopy(source['weights'][j]));nearest.append(j)
 faces=[]
 for row in range(len(levels)-1):
  for col in range(N):
   a=row*(N+1)+col;b=a+1;d=a+N+1;e=d+1;faces.extend([[a,b,e],[a,e,d]])
 mesh={'name':name,'material':material,'positions_m':points,'triangles':faces,'uvs':uvs,'weights':weights,'weight_source_body_vertex':nearest,'construction':'Original positive-height cylindrical clothing envelope fitted to actual body sections; implicit anatomical concavities bridged. Open hem/neck/waist joins are unsewn and unaccepted.','ease_m':ease,'section_rings':rings}
 t=v1.triangles(mesh);cross=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);area=np.linalg.norm(cross,axis=1);centers=t.mean(axis=1);radial=[]
 for row in range(len(levels)-1):
  for col in range(N):
   for fraction in [1/3,2/3]:
    cx=rings[row]['center_xz_m'][0]*(1-fraction)+rings[row+1]['center_xz_m'][0]*fraction;cz=rings[row]['center_xz_m'][1]*(1-fraction)+rings[row+1]['center_xz_m'][1]*fraction
    radial.append([cx,0,cz])
 radial=centers-np.array(radial);radial[:,1]=0;orientation=np.einsum('ij,ij->i',cross,radial)
 require(np.all(area>1e-14),'Degenerate clothing loft');require(np.all(orientation>0),'Inverted clothing loft')
 return mesh,{'part':name,'vertices':len(points),'triangles':len(faces),'minimum_area_m2':float(area.min()/2),'inverted_outward_faces':int(np.count_nonzero(orientation<=0)),'minimum_outward_radial_dot':float(orientation.min()),'max_section_containment_error':max(0.,-min(r['minimum_section_ellipse_margin']for r in rings))}

def main():
 start=time.monotonic();require(not OUT.exists(),'Fresh output only');OUT.mkdir();receipt={'status':'RUNNING','production_eligible':False,'scope':'Actual original1904 rest-clothing coverage only; no BPy/render/animation/period-pattern acceptance'}
 try:
  body=v1.load_pin(v1.BODY,v1.BODY_SHA);old=v1.load_pin(v1.GARMENT,v1.GARMENT_SHA);require(v1.digest(V1)==V1_SHA,'Actual failedV1 changed');old_v1=json.loads(V1.read_text());require(v1.digest(v1.REFERENCE)==v1.REFERENCE_SHA,'Viewed period comparator changed')
  source=body['meshes'][0];p=np.array(source['positions_m']);f=np.array(source['triangles']);t=p[f];centers=t.mean(axis=1);c=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);normals=c/np.linalg.norm(c,axis=1)[:,None];bones={b['name']:b for b in body['skeleton']};waist=body['report']['chosen_height_m']*.585;neck=bones['neck_01']['head_m'][1];knee=bones['calf_l']['head_m'][1]
  shirt,shirt_stats=make_loft(body,NAMES[0],'shirt_plain_reconstructed',np.linspace(waist-.10,neck+.012,25))
  coat=copy.deepcopy(next(m for m in old_v1['meshes']if m['name']==NAMES[1]));ct=v1.triangles(coat);cc=np.cross(ct[:,1]-ct[:,0],ct[:,2]-ct[:,0]);source_cc=c[np.array(coat['repair_triangle_to_body_triangle'])];require(np.all(np.einsum('ij,ij->i',cc,source_cc)>0),'Previously positive coat patch changed')
  left,left_stats=make_loft(body,NAMES[2],'trousers_plain_reconstructed',np.linspace(knee+.055,waist+.025,22),1)
  right,right_stats=make_loft(body,NAMES[3],'trousers_plain_reconstructed',np.linspace(knee+.055,waist+.025,22),-1)
  repairs=[shirt,coat,left,right];candidate=copy.deepcopy(old);candidate['meshes'].extend(repairs);candidate['coverage_repair']=copy.deepcopy(old_v1['coverage_repair']);candidate['coverage_repair'].update(version=2,prior_actual_failure_sha256=V1_SHA,construction='Clothing envelope topology replaces failed anatomical normal-offset shirt/trousers; positive coat shoulder patch retained exactly',acceptance='HELD rest-coverage study; no display or pattern/fit/pose/LOD/visual acceptance');candidate['limitations'].append('Original coverage envelopes overlap existing garments and each other at joins; sewn seams, drape, body intersections, back/side appearance, animation, material response and photographic quality remain unaccepted')
  require(candidate['meshes'][:13]==old['meshes'],'Original thirteen meshes changed');require(candidate['materials']==old['materials']and candidate['skeleton']==old['skeleton']==body['skeleton'],'Palette/rig changed');require(candidate['production_eligible']is False and candidate['garment_sources']==[]and candidate['appearance_grade']=='reconstructed','Qualification falsely upgraded')
  for mesh in [shirt,left,right]:
   require(all(w==source['weights'][i]for w,i in zip(mesh['weights'],mesh['weight_source_body_vertex'])),'Nearest-source skin weight changed')
   for w in mesh['weights']:require(0<len(w)<=4 and abs(sum(w.values())-1)<1e-8,'Invalid skin influence')
  file=OUT/'glessner1904.coverage-v2.garments.json';file.write_text(json.dumps(candidate,separators=(',',':'))+'\n');new_sha=v1.digest(file)
  adapter_path='tools/human_era_study_1904.py';adapter=(v1.ROOT/adapter_path).read_text();changed=adapter.replace('GARMENT_SHA="'+v1.GARMENT_SHA+'"','GARMENT_SHA="'+new_sha+'"');needle='"civilian_closed_shoe_l","civilian_straight_trouser_r","civilian_closed_shoe_r"]';require(needle in changed,'Adapter preimage changed');changed=changed.replace(needle,needle[:-1]+','+','.join('"'+n+'"'for n in NAMES)+']');(OUT/'human_era_study_1904.py').write_text(changed)
  recipe_path='data/humans/recipes/era_studies/1904.json';recipe=(v1.ROOT/recipe_path).read_text();recipe_new=recipe.replace('"garment_sha256": "'+v1.GARMENT_SHA+'"','"garment_sha256": "'+new_sha+'"');require(recipe_new!=recipe,'Recipe SHA preimage changed');(OUT/'1904.coverage-v2.recipe.json').write_text(recipe_new)
  patch=''.join(difflib.unified_diff(adapter.splitlines(True),changed.splitlines(True),fromfile='a/'+adapter_path,tofile='b/'+adapter_path))+''.join(difflib.unified_diff(recipe.splitlines(True),recipe_new.splitlines(True),fromfile='a/'+recipe_path,tofile='b/'+recipe_path));(OUT/'UNAPPLIED-source.patch').write_text(patch)
  previous=json.loads((V1.parent/'ACTUAL-RECEIPT.json').read_text());witnesses=[]
  for witness in previous['witnesses']:
   i=witness['body_triangle'];require(np.linalg.norm(centers[i]-witness['body_point_m'])<1e-12,'Frozen witness body location changed');point=centers[i];before=v1.first_hit(point,np.array([0.,0.,1.]),old['meshes']);after=v1.first_hit(point,np.array([0.,0.,1.]),candidate['meshes']);witnesses.append({'region':witness['region'],'body_triangle':i,'body_point_m':point.tolist(),'before':before,'after':after})
  missing_before=sum(w['before']is None for w in witnesses);missing_after=sum(w['after']is None for w in witnesses);require(v1.digest(v1.ROOT/v1.BODY)==v1.BODY_SHA and v1.digest(v1.ROOT/v1.GARMENT)==v1.GARMENT_SHA,'Original source mutated')
  receipt.update(status='ACTUAL_REST_COVERAGE_PASS'if not missing_after and missing_before==12 else'ACTUAL_REST_COVERAGE_FAIL',candidate_sha256=new_sha,candidate_components=len(candidate['meshes']),candidate_triangles=sum(len(m['triangles'])for m in candidate['meshes']),original_components_unchanged=13,source_body_unchanged=True,skeleton_unchanged=True,source_palette_unchanged=True,coat_shoulder_v1_unchanged=True,normal_orientation=[shirt_stats,{'part':NAMES[1],'triangles':len(coat['triangles']),'inverted_source_normal_faces':0},left_stats,right_stats],witness_count=len(witnesses),before_missing=missing_before,after_missing=missing_after,negative_control='Remove four repair components: actual original12 frozen witnesses fail',witnesses=witnesses,source_pins={v1.BODY:v1.BODY_SHA,v1.GARMENT:v1.GARMENT_SHA,'failed_v1':V1_SHA,'v1_helper':v1.digest(HELPER),'adapter':v1.digest(v1.ROOT/adapter_path),'recipe':v1.digest(v1.ROOT/recipe_path),'period_comparator':v1.REFERENCE_SHA},elapsed_seconds=time.monotonic()-start)
 except Exception as exc:receipt.update(status='ACTUAL_EXCEPTION',error=repr(exc),elapsed_seconds=time.monotonic()-start)
 finally:(OUT/'ACTUAL-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items()if k not in ['witnesses','source_pins']},indent=2));return 0 if receipt['status']=='ACTUAL_REST_COVERAGE_PASS'else 2
if __name__=='__main__':raise SystemExit(main())
