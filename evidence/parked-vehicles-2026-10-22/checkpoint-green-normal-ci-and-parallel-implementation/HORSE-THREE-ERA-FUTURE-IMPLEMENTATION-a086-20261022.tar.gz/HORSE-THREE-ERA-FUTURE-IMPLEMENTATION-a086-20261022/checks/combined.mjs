// Combined source integration only. No constructor producer, GLB parse, DOM, browser or rendering.
import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
import {existsSync,readFileSync} from 'node:fs';
const ROOT=new URL('../',import.meta.url),S=new URL('source/chicago/4d/',ROOT),D=new URL('review-only/chicago/4d/',ROOT),F=new URL('fixtures/',ROOT);
registerHooks({resolve(s,c,next){
 if(s==='three')return next(new URL('renderers/web/vendor/three-0.185.1/three.module.js',F).href,c);
 if(s.startsWith('three/addons/'))return next(new URL('renderers/web/vendor/three-0.185.1/'+s.slice(6),F).href,c);
 if(s.startsWith('.')&&c.parentURL&&(c.parentURL.startsWith(S.href)||c.parentURL.startsWith(D.href))){
  let u=new URL(s,c.parentURL);
  if(!existsSync(u)&&u.href.startsWith(D.href))u=new URL(u.href.slice(D.href.length),S);
  if(!existsSync(u)&&u.href.startsWith(S.href))u=new URL(u.href.slice(S.href.length),F);
  return next(u.href,c);
 }return next(s,c);
}});
const T=await import('three');
const {retainDrawnStaticSupport}=await import('../source/chicago/4d/renderers/web/js/drawn-static-support.js');
const ship=await import('../source/chicago/4d/renderers/web/js/standing-horse-contract.js');
const review=await import('../review-only/chicago/4d/renderers/web/js/standing-horse-contract.js');
const {createStandingHorses:shipLoader}=await import('../source/chicago/4d/renderers/web/js/standing-horses.js');
const {createStandingHorses:reviewLoader}=await import('../review-only/chicago/4d/renderers/web/js/standing-horses.js');
const {standingHorseCard}=await import('../source/chicago/4d/renderers/web/js/standing-horse-card.js');
const read=(r,b=S)=>JSON.parse(readFileSync(new URL(r,b))),manifest=read('data/transport/parked/standing-horses.json');
const legacy=read('data/transport/parked/standing-horses.json',F),spec=read('data/transport/parked/horse-sevket-sidecar.json',F);
assert.deepEqual(manifest.scenes['1835'],legacy.scenes['1835']);assert.deepEqual(manifest.models,legacy.models);
const digest=async bytes=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
const results=[];
for(const year of ['1812','1904']){
 const scene=read(`data/scenes/${year}.json`),context=ship.horseSceneContext(year,scene.target_date),row=manifest.scenes[year][0],region=scene.static_support_regions[0];
 const fileBytes=readFileSync(new URL('data/'+row.support_fit_file,S)),fit=JSON.parse(fileBytes);
 assert.equal(await digest(fileBytes),row.support_fit_sha256);assert.equal(row.enabled,false);assert.equal(fit.world_qualified,false);
 const captured=read(`evidence/${year}/DRAWN-TRIANGLES.json`,ROOT);
 // Replay saved actual constructor world triangles through the actual provider implementation.
 // Float64 CPU attributes preserve captured coordinates exactly, without regenerating terrain or road.
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.BufferAttribute(new Float64Array(captured.triangles_world_xyz),3));
 const mesh=new T.Mesh(geometry,new T.MeshBasicMaterial()),group=new T.Group();group.add(mesh);
 const problems=[];const cache=await retainDrawnStaticSupport({group,regions:[region],sceneId:year,targetDate:scene.target_date,surfaceKind:row.surface_kind,sources:()=>[{mesh}],problems});
 assert.deepEqual(problems,[]);assert.equal(cache.census.triangles,4);assert.equal(cache.census.bytes,288);
 const snapshot=cache.snapshot(row.ground_record_id,row.ground_support_region_id);assert.deepEqual(snapshot,captured.snapshot);assert.equal(snapshot.sha256,fit.provider_triangle_sha256);
 const options={hostPresent:()=>true,supportRegions:scene.static_support_regions};
 assert.deepEqual(ship.standingHorseRows(manifest,context,options),{active:[],inactive:[row]});
 assert.throws(()=>ship.validateHorseSupportFit(fit,row,spec,context,region,snapshot),/world qualification/);
 assert.deepEqual(review.standingHorseRows(manifest,context,options),{active:[row],inactive:[]});
 assert.equal(row.enabled,false,'review selection does not falsify the row flag');
 assert.equal(review.validateHorseSupportFit(fit,row,spec,context,region,snapshot),fit);
 assert.throws(()=>review.validateHorseSupportFit({...fit,world_qualified:true},row,spec,context,region,snapshot),/REVIEW FIXTURE ONLY/);
 const wrong=review.standingHorseRows({...manifest,scenes:{[year]:[{...row,support_fit_sha256:'f'.repeat(64)}]}},context,options);assert.equal(wrong.active.length,0);
 // Cross-package contact replay: actual sidecar samples + per-era serialized q + actual provider.
 const rotation=new T.Quaternion().fromArray(row.support_quaternion_xyzw),yaw=Math.PI-row.bearing_deg*Math.PI/180,co=Math.cos(yaw),si=Math.sin(yaw);
 let sampleCount=0;const collect=values=>values.map(v=>{sampleCount++;const p=new T.Vector3().fromArray(v).applyQuaternion(rotation);const e=row.at_local_enu_m[0]+co*p.x+si*p.z,n=row.at_local_enu_m[1]+si*p.x-co*p.z;const y=cache.heightAt(e,n,row.ground_record_id,row.ground_support_region_id);assert(Number.isFinite(y));return{y:p.y,ground:y};});
 const original=Object.fromEntries(Object.entries(spec.contacts).map(([k,v])=>[k,collect(v.samples_m)]));let base=-Infinity;
 for(const foot of Object.values(original))for(const p of foot)base=Math.max(base,p.ground-p.y);
 const minimums=Object.fromEntries(Object.entries(original).map(([k,v])=>[k,Math.min(...v.map(p=>base+p.y-p.ground))]));
 const slabs=Object.fromEntries(Object.entries(spec.contacts).map(([k,v])=>[k,Math.min(...collect(v.equal_10mm_slab_samples_m).map(p=>base+p.y-p.ground))]));
 assert.equal(sampleCount,962);assert(Math.abs(base-fit.measurements.root_y_m)<1e-10);
 for(const key of Object.keys(spec.contacts)){assert(Math.abs(minimums[key]-fit.measurements.minimum_gap_by_hoof_m[key])<1e-10);assert(Math.abs(slabs[key]-fit.measurements.equal_10mm_slab_minimum_gaps_m[key])<1e-10);assert(minimums[key]<=.001&&slabs[key]>=-.00001);}
 // Public normal loader keeps disabled rows cold. Diagnostic-only loader reaches source GLB fetch,
 // deliberately stopped at404; no actualGLTFLoader/skin/world acceptance can be inferred.
 let served=manifest;const calls=[];
 globalThis.fetch=async input=>{const u=new URL(input),name=u.pathname.split('/').pop();calls.push(name);if(name==='standing-horses.json')return Response.json(served);if(name==='horse-sevket-sidecar.json')return Response.json(spec);if(name===row.support_fit_file.split('/').pop())return new Response(fileBytes);return new Response('INTENTIONAL CPU INTEGRATION STOP BEFORE GLB PARSE',{status:404});};
 const camera=new T.PerspectiveCamera();camera.position.set(row.at_local_enu_m[0],0,-row.at_local_enu_m[1]);
 const params={dataBase:new URL('https://unit.invalid/data/'),sceneId:year,targetDate:scene.target_date,detail:'full',hostPresent:()=>true,supportRegions:scene.static_support_regions,groundHeight:(e,n,id,reg,kind)=>kind===row.surface_kind?cache.heightAt(e,n,id,reg):null,groundSnapshot:(id,reg,kind)=>kind===row.surface_kind?cache.snapshot(id,reg):null};
 let errs=[];let layer=await shipLoader({...params,problems:errs});layer.update(camera);await layer.ready;assert.deepEqual(calls.splice(0),['standing-horses.json']);assert.equal(layer.instances.length,0);layer.dispose();assert.deepEqual(errs,[]);
 served=structuredClone(manifest);served.scenes[year][0].enabled=true;errs=[];layer=await shipLoader({...params,problems:errs});layer.update(camera);await layer.ready;assert.deepEqual(calls.splice(0),['standing-horses.json','horse-sevket-sidecar.json',row.support_fit_file.split('/').pop()]);assert(errs[0].includes('world qualification'));layer.dispose();
 served=manifest;errs=[];layer=await reviewLoader({...params,problems:errs});assert.equal(layer.records[0].enabled,false);assert.equal(layer.group.userData.worldQualified,false);layer.update(camera);await layer.ready;assert.deepEqual(calls.splice(0),['standing-horses.json','horse-sevket-sidecar.json',row.support_fit_file.split('/').pop(),manifest.models[row.model].file.split('/').pop()]);assert(errs[0].includes('GLB HTTP404'));layer.dispose();
 assert.equal(row.enabled,false);assert.equal(fit.world_qualified,false);
 const card=standingHorseCard(row,spec,context);assert(card.sidecar.change_note.includes(scene.target_date));assert(Object.values(card.sidecar.attributes).every(x=>x.confidence==='reconstructed'&&!x.sources.includes(spec.source.id)));
 results.push({year,normal_inactive:true,normal_unqualified_fit_refused:true,review_only_selected_pinned_inactive_row:true,world_qualified:false,provider_sha256:snapshot.sha256,provider_triangles:4,provider_bytes:288,contact_samples_replayed:sampleCount,maximum_per_hoof_minimum_gap_m:Math.max(...Object.values(minimums)),minimum_slab_gap_m:Math.min(...Object.values(slabs))});cache.dispose();geometry.dispose();mesh.material.dispose();
}
assert(!readFileSync(new URL('renderers/web/js/main.js',S),'utf8').includes('horse-support-review-only'));
assert(readFileSync(new URL('renderers/web/js/main.js',D),'utf8').includes('horse-support-review-only'));
console.log(JSON.stringify({status:'PASS',scope:'combined source/provider/serialized real-fit/schema-data lifecycle; saved actual triangles replayed; no geometry producer/browser/WebGL/GLB parse/world approval',legacy_row_and_model_identity:true,results}));
