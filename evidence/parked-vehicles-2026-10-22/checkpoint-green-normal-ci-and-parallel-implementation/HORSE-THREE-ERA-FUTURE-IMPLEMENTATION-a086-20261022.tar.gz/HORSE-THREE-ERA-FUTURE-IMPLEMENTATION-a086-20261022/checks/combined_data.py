from pathlib import Path
import json,hashlib
from jsonschema import Draft202012Validator
R=Path(__file__).resolve().parents[1];S=R/'source/chicago/4d';B=R/'base/chicago/4d';F=R/'fixtures'
read=lambda p:json.loads(p.read_text())
m=read(S/'data/transport/parked/standing-horses.json');original=read(B/'data/transport/parked/standing-horses.json')
Draft202012Validator(read(S/'data/standing_horses.schema.json')).validate(m)
assert m['scenes']['1835']==original['scenes']['1835'] and m['models']==original['models']
scene_validator=Draft202012Validator(read(S/'data/scene.schema.json'));sources=set()
for y in ['1812','1904']:
 scene=read(S/f'data/scenes/{y}.json');base=read(B/f'data/scenes/{y}.json');scene_validator.validate(scene)
 compare=dict(scene);regions=compare.pop('static_support_regions');assert compare.pop('layers')==base['layers']+['standing_horses'];rest=dict(base);rest.pop('layers');assert compare==rest,'unrelated scene state changed';assert scene['released'] is False
 row=m['scenes'][y][0];assert row['enabled'] is False and row['confidence']=='reconstructed';assert len(m['scenes'][y])==1
 assert row['liberty']=='L-standing-horses-additional-eras-source-review'
 f=S/'data'/row['support_fit_file'];assert hashlib.sha256(f.read_bytes()).hexdigest()==row['support_fit_sha256'];fit=read(f);assert fit['world_qualified'] is False
 assert fit==read(R/f'evidence/{y}/FIT.json');assert fit['target_date']==scene['target_date'] and fit['scene_id']==y
 assert fit['bounds_enu_m']==regions[0]['bounds_enu_m'];assert fit['support_quaternion_xyzw']==row['support_quaternion_xyzw']
 for sid in row['source_ids']:
  source=read(F/f'data/sources/{sid}.json');assert source['id']==sid;sources.add(sid)
 assert 'sevketkabatas_2021_horse_model' not in row['source_ids'],'modern credit cannot attest the historical individual'
assert m['scenes']['1812'][0]['belongs_to']=='first_fort_outer_stable_north';assert m['scenes']['1904'][0]['belongs_to'] is None
assert (S/'docs/LIBERTIES.md').read_bytes().startswith((B/'docs/LIBERTIES.md').read_bytes()),'liberty history must be append-only'
assert not (S/'data/scenes/1835.json').exists(),'subset must not edit existing1835scene'
print(json.dumps({'status':'PASS','scope':'actual consolidated manifest/scenes/full schemas/source references and append-only liberty; no compiler/gate/browser','resolved_existing_historical_sources':sorted(sources),'legacy1835_row_and_models_exact':True,'new_rows_enabled':False,'real_fits_world_qualified':False,'scene_release_flags_and_other_fields_preserved':True}))
