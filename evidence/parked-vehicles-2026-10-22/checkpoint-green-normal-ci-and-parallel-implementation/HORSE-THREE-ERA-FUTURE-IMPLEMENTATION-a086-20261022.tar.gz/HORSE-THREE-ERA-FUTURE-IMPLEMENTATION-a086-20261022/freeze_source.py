from pathlib import Path
import difflib,hashlib,json,subprocess,datetime,os,time
R=Path(__file__).resolve().parent;S=R/'source';B=R/'base';BASE='a086cd7dab31935f52adcb1ca8494a12726f9f27';changes={};patch=[]
for p in sorted(S.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(S);base=B/rel;before=base.read_bytes() if base.exists() else b'';after=p.read_bytes()
 if before==after:continue
 if base.exists():assert subprocess.check_output(['git','-C','/workspace/chicago-waistcoat','show',BASE+':'+str(rel)])==before
 patch.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+str(rel) if base.exists() else '/dev/null',tofile='b/'+str(rel)))
 changes[str(rel)]={'base_sha256':hashlib.sha256(before).hexdigest() if base.exists() else None,'sha256':hashlib.sha256(after).hexdigest(),'bytes':len(after)}
(R/'THREE-ERA.patch').write_text(''.join(patch));checks=[]
for name,cwd,patchfile in [('SHIP',B,R/'THREE-ERA.patch'),('REVIEW_ONLY',S,R/'REVIEW-ONLY-DO-NOT-SHIP.patch')]:
 p=subprocess.run(['git','apply','--check',str(patchfile)],cwd=cwd,capture_output=True,text=True);checks.append({'name':name,'command':p.args,'cwd':str(cwd),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'writes':False});assert p.returncode==0
# Syntax only: no imports, constructors or application startup.
env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');syntax=[]
for tree in [S,R/'review-only']:
 for p in sorted(tree.rglob('*.js')):
  t=time.monotonic();result=subprocess.run(['timeout','15s','nice','-n','19','node','--check',str(p)],env=env,capture_output=True,text=True);syntax.append({'file':str(p.relative_to(R)),'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-t,'stderr':result.stderr});assert result.returncode==0
(R/'SOURCE-PINS.json').write_text(json.dumps({'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'changes':changes,'ship_patch_sha256':hashlib.sha256((R/'THREE-ERA.patch').read_bytes()).hexdigest(),'review_only_patch_sha256':hashlib.sha256((R/'REVIEW-ONLY-DO-NOT-SHIP.patch').read_bytes()).hexdigest(),'review_only_is_excluded_from_ship':True},indent=2)+'\n')
(R/'PATCH-SYNTAX-CHECKS.json').write_text(json.dumps({'checks':checks,'syntax':syntax,'status':'PASS','no_app_writes':True,'no_producer_or_browser':True},indent=2)+'\n');print(json.dumps({'files':len(changes),'ship_patch_bytes':(R/'THREE-ERA.patch').stat().st_size,'ship_patch_sha256':hashlib.sha256((R/'THREE-ERA.patch').read_bytes()).hexdigest(),'review_patch_sha256':hashlib.sha256((R/'REVIEW-ONLY-DO-NOT-SHIP.patch').read_bytes()).hexdigest(),'syntax_checks':len(syntax),'patch_checks':len(checks)}))
