from pathlib import Path
import json,shutil,hashlib,difflib
R=Path(__file__).resolve().parent;S=R/'source/chicago/4d';D=R/'review-only/chicago/4d'
manifest=json.loads((S/'data/transport/parked/standing-horses.json').read_text())
pins={year:{'row_id':manifest['scenes'][year][0]['id'],'fit_sha256':manifest['scenes'][year][0]['support_fit_sha256']} for year in ['1812','1904']}
for name in ['standing-horse-contract.js','standing-horses.js','main.js']:
 p=D/'renderers/web/js'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((S/'renderers/web/js'/name).read_bytes())
p=D/'renderers/web/js/standing-horse-contract.js';s=p.read_text();prefix='''// REVIEW FIXTURE ONLY. Excluded from THREE-ERA.patch. Not a production bypass.\n// Fixed inactive candidates only; no URL/env switch and no world-qualified flag mutation.\nconst REVIEW_ONLY_CANDIDATES = Object.freeze('''+json.dumps(pins,indent=2)+''');\nconst reviewCandidate = (row, scene) => row.enabled === false\n  && row.id === REVIEW_ONLY_CANDIDATES[scene.sceneId]?.row_id\n  && row.support_fit_sha256 === REVIEW_ONLY_CANDIDATES[scene.sceneId]?.fit_sha256;\n''';s=prefix+s
s=s.replace('const legacy = isLegacyHorseRow(row, scene), enabled = row.enabled ?? legacy;', 'const legacy = isLegacyHorseRow(row, scene), enabled = row.enabled ?? legacy;\n    const reviewOnly = reviewCandidate(row, scene);')
s=s.replace('      if (enabled) {','      if (enabled || reviewOnly) {')
s=s.replace('if (!enabled || hostMissing(row.belongs_to))', 'if ((!enabled && !reviewOnly) || hostMissing(row.belongs_to))')
s=s.replace("assert(fit.world_qualified === true, 'new-era activation awaits its own world qualification');", "assert(fit.world_qualified === false && reviewCandidate(row, scene),\n    'REVIEW FIXTURE ONLY: exact inactive candidate and authentic unqualified fit required');")
p.write_text(s)
p=D/'renderers/web/js/standing-horses.js';s=p.read_text().replace("const group = new THREE.Group(); group.name = 'standing-horses';", "const group = new THREE.Group(); group.name = 'standing-horses';\n  group.userData.supportReviewOnly = true; group.userData.worldQualified = false;")
s=s.replace('        candidate.receipt.native = nativeReceipt;', "        candidate.receipt.native = nativeReceipt;\n        if (row.surface_kind) {\n          candidate.receipt.support_scope = 'DIAGNOSTIC_SOURCE_CPU_FIT_ONLY';\n          candidate.receipt.world_qualified = false; candidate.receipt.normal_activation = false;\n          candidate.card.sidecar.change_note = 'DIAGNOSTIC REVIEW ONLY — SOURCE CPU FIT; WORLD QUALIFICATION OPEN. ' + candidate.card.sidecar.change_note;\n        }")
p.write_text(s)
p=D/'renderers/web/js/main.js';s=p.read_text().replace('  const standingHorses = await createStandingHorses({', '''  // HELD review fixture only; never include this overlay in the ship patch.\n  const horseSupportReviewBanner = document.createElement('div');\n  horseSupportReviewBanner.id = 'horse-support-review-only';\n  horseSupportReviewBanner.textContent = 'DIAGNOSTIC HORSE REVIEW — SOURCE CPU FIT ONLY; WORLD / VISUAL QUALIFICATION OPEN';\n  Object.assign(horseSupportReviewBanner.style, { position: 'fixed', top: '0', left: '0',\n    right: '0', zIndex: '2147483647', padding: '8px', background: '#6b1700', color: '#fff',\n    font: 'bold 13px sans-serif', pointerEvents: 'none' });\n  document.body.append(horseSupportReviewBanner);\n  const standingHorses = await createStandingHorses({''')
p.write_text(s)
patch=[]
for p in sorted(D.rglob('*.js')):
 rel=p.relative_to(D);patch.extend(difflib.unified_diff((S/rel).read_text().splitlines(True),p.read_text().splitlines(True),fromfile='a/chicago/4d/'+str(rel),tofile='b/chicago/4d/'+str(rel)))
(R/'REVIEW-ONLY-DO-NOT-SHIP.patch').write_text(''.join(patch));(R/'REVIEW-ONLY-CANDIDATE-PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
print('Prepared separate review-only overlay; authentic data flags remain false')
