// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit era/placement/support binding. No ground solver or historical inference.
export const SUPPORT_KINDS = Object.freeze(['terrain_triangle', 'carriageway_triangle']);
export const SUPPORT_LIMITS = Object.freeze({ max_tilt_deg: 2,
  maximum_per_hoof_minimum_gap_m: 0.001, minimum_sample_clearance_m: -0.00001 });
const HOOFS = ['fore_l', 'fore_r', 'hind_l', 'hind_r'];
const ID = /^[a-z0-9_]+$/, SHA = /^[a-f0-9]{64}$/;
const assert = (ok, message) => { if (!ok) throw Error(`HorsePlacementContract: ${message}`); };
const finiteVector = (v, n) => Array.isArray(v) && v.length === n && v.every(Number.isFinite);
const exactVector = (a, b) => Array.isArray(a) && Array.isArray(b) && a.length === b.length
  && a.every((v, i) => Array.isArray(v) ? exactVector(v, b[i]) : v === b[i]);
export const isLegacyHorseRow = (row, scene) => scene.sceneId === '1835'
  && scene.targetDate === '1835-07-01' && row.surface_kind === undefined
  && row.support_fit_file === undefined && row.support_fit_sha256 === undefined;

export function horseSceneContext(sceneId, targetDate) {
  const id = String(sceneId);
  // Existing1835caller compatibility only. Every additional era supplies its real date.
  const date = targetDate ?? (id === '1835' ? '1835-07-01' : null);
  assert(/^\d{4}$/.test(id) && typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date)
    && date.slice(0, 4) === id && Number.isFinite(Date.parse(date))
    && new Date(date).toISOString().slice(0, 10) === date, 'explicit matching scene date required');
  return Object.freeze({ sceneId: id, targetDate: date });
}

/** Validate declared rows before a sidecar/GLB is requested; inactive means no load. */
export function standingHorseRows(manifest, scene, { hostMissing = () => false,
  hostPresent = null, supportRegions = [] } = {}) {
  assert(manifest?.schema === 'standing_horse_placements_v1' && manifest.models
    && manifest.scenes && typeof manifest.scenes === 'object', 'placement manifest shape changed');
  const rows = manifest.scenes[scene.sceneId] ?? [];
  assert(Array.isArray(rows) && rows.length <= 1, 'one declared standing horse per scene');
  const active = [], inactive = [];
  for (const row of rows) {
    assert(row && ID.test(row.id) && manifest.models[row.model], 'unknown model or invalid row ID');
    assert(finiteVector(row.at_local_enu_m, 2) && Number.isFinite(row.bearing_deg), 'finite stand required');
    assert(typeof row.name === 'string' && row.name.length && typeof row.location === 'string'
      && row.location.length && row.confidence === 'reconstructed', 'reconstructed named stand required');
    assert(Array.isArray(row.source_ids) && row.source_ids.length > 0 && row.source_ids.every(x => ID.test(x)),
      'explicit historical context source IDs required');
    assert(row.belongs_to === null || typeof row.belongs_to === 'string' && ID.test(row.belongs_to),
      'host is explicit and does not identify an owner');
    assert(row.enabled === undefined || typeof row.enabled === 'boolean', 'enabled must be explicit boolean');
    const legacy = isLegacyHorseRow(row, scene), enabled = row.enabled ?? legacy;
    if (!legacy) {
      assert(['walk_trot_gallop_approved', 'hitching', 'riding', 'boarding', 'tying',
        'halter_or_harness_fitted', 'certified_sockets', 'driver_interface', 'collision_physics',
        'historical_individual_or_breed_identified', 'photographic_master_complete']
        .every(key => row.capabilities?.[key] === false), 'standing-only capabilities must remain explicitly disabled');
      assert(typeof row.enabled === 'boolean' && SUPPORT_KINDS.includes(row.surface_kind),
        'new-era rows need explicit activation and drawn support kind');
      assert(ID.test(row.ground_record_id) && ID.test(row.ground_support_region_id), 'drawn support identity required');
      if (enabled) {
        assert(typeof row.support_fit_file === 'string'
          && /^transport\/parked\/support\/[a-z0-9_-]+\.json$/.test(row.support_fit_file)
          && SHA.test(row.support_fit_sha256), 'active new-era row needs hash-pinned support fit');
        assert(finiteVector(row.support_quaternion_xyzw, 4), 'active support quaternion required');
        const region = supportRegions.find(x => x.id === row.ground_support_region_id);
        assert(region && region.record_id === row.ground_record_id && region.surface_kind === row.surface_kind
          && region.scene_id === scene.sceneId && region.target_date === scene.targetDate,
        'scene support region identity/date mismatch');
        assert(typeof hostPresent === 'function' && (!row.belongs_to || hostPresent(row.belongs_to)),
          'new-era host must resolve in this scene');
      } else {
        assert(row.support_fit_file === null || typeof row.support_fit_file === 'string', 'inactive fit path must be explicit null or path');
        assert(row.support_fit_sha256 === null || SHA.test(row.support_fit_sha256), 'inactive fit hash must be explicit null or SHA');
        assert(row.support_quaternion_xyzw === null || finiteVector(row.support_quaternion_xyzw, 4),
          'inactive quaternion must be explicit null or measured');
      }
    }
    if (!enabled || hostMissing(row.belongs_to)) inactive.push(row); else active.push(row);
  }
  return { active, inactive };
}

/** Exact provider and site bindings; actual ground contacts are still recomputed by loader. */
export function validateHorseSupportFit(fit, row, spec, scene, region, snapshot) {
  assert(fit?.schema === 'standing_horse_drawn_support_fit_v1' && fit.status === 'source_cpu_fit_pass',
    'successful drawn-support source fit required');
  assert(fit.world_qualified === true, 'new-era activation awaits its own world qualification');
  for (const [key, expected] of Object.entries({ scene_id: scene.sceneId, target_date: scene.targetDate,
    row_id: row.id, surface_kind: row.surface_kind, record_id: row.ground_record_id,
    region_id: row.ground_support_region_id, bearing_deg: row.bearing_deg,
    runtime_asset_sha256: spec.runtime_asset.sha256 })) assert(fit[key] === expected, `${key} changed since support fit`);
  assert(exactVector(fit.at_local_enu_m, row.at_local_enu_m), 'stand moved since support fit');
  assert(region && exactVector(fit.bounds_enu_m, region.bounds_enu_m), 'support rectangle changed');
  const b = fit.bounds_enu_m;
  assert(Array.isArray(b) && b.length === 2 && b.every(x => finiteVector(x, 2))
    && b[1][0] > b[0][0] && b[1][1] > b[0][1]
    && (b[1][0] - b[0][0]) * (b[1][1] - b[0][1]) <= 4, 'bounded support rectangle required');
  assert(snapshot && SHA.test(snapshot.sha256) && fit.provider_triangle_sha256 === snapshot.sha256,
    'actual retained triangle hash changed');
  for (const [key, expected] of Object.entries({ record_id: row.ground_record_id, region_id: row.ground_support_region_id,
    surface_kind: row.surface_kind, scene_id: scene.sceneId, target_date: scene.targetDate })) {
    assert(snapshot[key] === expected, `provider ${key} mismatched`);
  }
  assert(exactVector(snapshot.bounds_enu_m, b), 'provider rectangle mismatched');
  assert(Object.keys(SUPPORT_LIMITS).every(k => fit.limits?.[k] === SUPPORT_LIMITS[k]), 'support limits changed');
  assert(row.support_limits?.maximum_per_hoof_minimum_gap_m === SUPPORT_LIMITS.maximum_per_hoof_minimum_gap_m
    && row.support_limits.minimum_sample_clearance_m === SUPPORT_LIMITS.minimum_sample_clearance_m,
  'placement support limits changed');
  const q = fit.support_quaternion_xyzw;
  assert(finiteVector(q, 4) && Math.abs(Math.hypot(...q) - 1) < 1e-7
    && exactVector(q, row.support_quaternion_xyzw), 'site quaternion changed');
  const tilt = Math.acos(Math.max(-1, Math.min(1, 1 - 2 * (q[0] ** 2 + q[2] ** 2)))) * 180 / Math.PI;
  assert(tilt <= SUPPORT_LIMITS.max_tilt_deg && Number.isFinite(fit.measurements?.tilt_deg)
    && Math.abs(tilt - fit.measurements.tilt_deg) <= 1e-5, 'support tilt exceeds or contradicts measured fit');
  const values = fit.measurements;
  for (const key of ['minimum_gap_by_hoof_m', 'equal_10mm_slab_minimum_gaps_m']) {
    assert(values[key] && Object.keys(values[key]).sort().join() === [...HOOFS].sort().join(), 'four nonempty measured hoof results required');
    for (const value of Object.values(values[key])) assert(Number.isFinite(value)
      && value >= SUPPORT_LIMITS.minimum_sample_clearance_m, 'measured support penetration');
  }
  assert(Object.values(values.minimum_gap_by_hoof_m).every(v => v <= SUPPORT_LIMITS.maximum_per_hoof_minimum_gap_m)
    && Number.isFinite(values.minimum_all_samples_gap_m)
    && values.minimum_all_samples_gap_m >= SUPPORT_LIMITS.minimum_sample_clearance_m, 'measured contact bounds failed');
  return fit;
}
