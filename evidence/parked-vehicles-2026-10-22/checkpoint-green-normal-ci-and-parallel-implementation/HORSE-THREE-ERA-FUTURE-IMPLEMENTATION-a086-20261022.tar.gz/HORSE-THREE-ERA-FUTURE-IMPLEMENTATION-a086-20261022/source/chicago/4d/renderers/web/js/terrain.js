/**
 * terrain.js — the ground, the river, and the frame everything else is placed in.
 *
 * Three jobs:
 *
 *   1. Own the coordinate convention. The dataset speaks local ENU metres
 *      (`local_e` east, `local_n` north from the datum origin). three speaks
 *      Y-up right-handed. The mapping, fixed here once so nothing else guesses:
 *
 *          world.x = +local_e        east
 *          world.y = +elevation      up (Z = 0 at the summer-1835 lake surface)
 *          world.z = -local_n        north is -Z, the way a camera at yaw 0 looks
 *
 *      `yaw_deg` in the dataset is a compass bearing: 0 = north, 90 = east,
 *      clockwise. three's rotation about +Y runs the other way, so
 *      `object.rotation.y = -bearing`.
 *
 *   2. Sample ground height, bilinearly, out of `heightfield.bin` — the same
 *      grid `generators/terrain_gen.py` built the ground mesh from, so what the
 *      walker stands on and what the walker sees are the same surface. The
 *      generator measures that agreement by ray-casting the decimated mesh
 *      against the field and refuses to export if it drifts past 30 mm.
 *
 *   3. Put the river on the screen. The water needs no shoreline geometry: the
 *      water surface IS the plane Y = 0, which is the vertical datum, and the
 *      ground crosses that plane exactly along the bank line traced off the
 *      Wright 1834 survey. So the waterline you see is the traced waterline,
 *      drawn by the depth buffer rather than by a second outline that could
 *      drift out of step with it.
 *
 * Wading, and why `walkHeight()` is not `surfaceHeight()`
 * --------------------------------------------------------
 * The heightfield carries the real channel bed — about -12 ft in the main stem.
 * A walker whose eye is pinned to that surface walks into the river and ends up
 * looking at the world from under the water, which reads as a bug rather than
 * as a river. `walkHeight()` therefore reports the WALKABLE surface: dry ground
 * where there is dry ground, and a wall at the waterline where there is not, so
 * the walker stops at the water's edge the way a person without a boat does.
 * `surfaceHeight()` still reports the real surface, the mesh still draws it, and
 * the heightfield still stores it. This is a navigation rule, not a claim about
 * the terrain — the moment there is a boat or a bridge it should be revisited.
 *
 * Its one edge: a walker TELEPORTED into the channel stands on the barrier and
 * appears to float. Walking cannot get you there, and every camera anchor in the
 * scene file is on land, so it is unreachable in normal use — but see
 * docs/LIBERTIES.md L9 rather than rediscovering it.
 */

import * as THREE from 'three';
import { retainDrawnStaticSupport } from './drawn-static-support.js';
import { spatialBatch, spatialBatchAsync, batchPieces } from './spatial-batch.js';
import { adaptiveGroundGrid } from './terrain-base.js';
import { contextSample, replaceApron } from './coast-extension.js';
import { apronGeometry, apronCut } from './terrain-apron.js';
import { floraInScene } from './flora.js';
import { PRAIRIE_TILE_PX, prairieTilePixels, prairieTileMeanLuma, srgbToLinear } from './prairie-tile.js';
import { MACRO_PX, MACRO_M, macroPixels, macroStats } from './prairie-macro.js';
import { GRASS_GRAIN_PX, GRASS_GRAIN_M, grassGrainPixels, grassGrainMean } from './grass-grain.js';
import { TURF_TILE_PX, TURF_TILE_M, turfTilePixels, turfTileMeanGrain, bareCut } from './turf-tile.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { registerKTX2 } from './ktx2.js';
import { HORIZON_HAZE } from './world.js';
import { loadMeshoptDecoder } from './scene-loader.js';
import { SEASON_HEAD, seasonShaderUniforms } from './season.js';
import { passageDepth } from './passage-ground.js';

// DEG and the bearing/yaw conversions are pure arithmetic and live in angles.js,
// so a caller that needs only those does not load three behind them (T-1257).
import { DEG, bearingToYaw, yawToBearing } from './angles.js';
import {
  lakeShoreLine, shoreUniform, shoreGlslHead, softExtentGlsl,
} from './lakeshore.js';
export { DEG, bearingToYaw, yawToBearing };

/** The vertical datum: the summer-1835 lake and river water surface. */
export const WATER_Y = 0;
/** Below this the ground is under water and the walker may not stand on it. */
const SHORE_Y = -0.10;
/** What `walkHeight()` reports over water: high enough that the walker's 0.35 m
 *  step-up rule refuses it from any bank in the dataset. */
const WATER_BARRIER_Y = 4.0;

/** T-0466's 36-tile rule was a measured answer for the former 2,020 × 800 m
 *  ground. T-0464 made the mesh 7,340 × 10,240 m, and T-1238 then gave it a
 *  visibility reach. At 5 × 8, however, a tile was about 1.3 km wide: its near
 *  corner kept a million-triangle field submitted long after most of that tile
 *  was haze. T-1245 measures the rule in metres instead. A tile side is at most
 *  240 m — about a tenth of the 2,644.9 m haze reach, an eighth of it when
 *  T-1245 set the figure against a thicker air — so the reach can reject
 *  ground with bounded edge overdraw as the modelled box changes again. */
/** The grid the last ground build actually used, for the harness to read back.
 *  Written by tileGround(); read by `groundTiling()` and by nothing in the scene. */
let lastGroundTiling = null;

/** The culling grid the ground currently stands on, or null before one is built. */
export function groundTiling() { return lastGroundTiling; }

// A reach can only reject whole tiles. Hold each side to a small fraction of
// the haze reach so a boundary tile cannot buy hundreds of metres of detailed
// ground merely because one corner remains visible (T-1245). 240 m was "roughly
// one eighth" of the 1,883 m reach that density gave; T-1635 thinned the air to
// the apron it has to close over and the reach is 2,644.9 m, so the same 240 m
// is now about a TENTH of it — finer than the rule asks, which is the safe
// direction, and the tile count is unchanged at 217. It is left alone
// deliberately: re-cutting the grid is a draw-call bargain T-1595 measured in
// its own right, and nothing in T-1635's reading asks for it.
const GROUND_TILE_TARGET_M = 240;
/**
 * …AND A TILE TOO THIN TO BE WORTH A DRAW CALL IS NOT A TILE (T-1595).
 *
 * The ground mesh is not all ground. Every epoch's `heightfield.json`
 * gives it a SKIRT: an apron 2,659.84 m wide on all four sides that
 * carries each boundary vertex outward at its own height, so the modelled box
 * does not end in a cliff at the horizon. It is a rim of long quads and it is
 * nearly free — the whole apron of the committed field is **2,489 triangles**.
 *
 * The tiling above cut it on the same 240 m grid as the modelled ground, which
 * gave it 130 tiles of about NINETEEN TRIANGLES EACH, every one its own draw
 * call. Measured on dev @ 13662e62, published mirror, desktop 1280x800, at the
 * `light` tier — the tier whose 90-call floor this ticket is about:
 *
 *              tiles   triangles   visible   of the frame's calls
 *   modelled     230   1,101,477       6-9   the ground the town stands on
 *   apron        130       2,489        66   about 30 at the open aerial,
 *                                            17 at Lake and Market
 *
 * Thirty draw calls, at the stand that was reading 99 against a floor of 90,
 * for one thousand three hundred triangles. `far-merge.js` states the general
 * form of this: chunking is a price paid in calls for what the frustum can
 * then reject, and it is only worth paying while something is bought with it.
 * Nineteen triangles buy nothing — the apron is flat, it is at the horizon,
 * and a visitor cannot tell which part of it was skipped.
 *
 * So a bucket that cannot hold a 16 x 16 patch of the 2.5 m field is not a
 * patch of ground; it is a sliver of the apron, and every one of them is
 * submitted as ONE mesh instead. The threshold sits three orders of magnitude
 * away from both populations above — 13x the apron's per-tile count, 19x under
 * the modelled ground's — so it is not a number tuned between two neighbours.
 *
 * This is a change of BATCHING and nothing else, and the same three things are
 * true of it that are true of the far merge: no vertex is moved, dropped or
 * re-typed, the material is the ground's own, and the confidence attribute
 * rides along in the merged buffer. Nothing a visitor can see changes at any
 * tier.
 *
 * WHAT IT BOUGHT AND WHAT IT COST, re-read on the published mirror with
 * `tools/measure_detail_ceilings.mjs` at T-0135's five stands:
 *
 *                     light worst calls          full worst calls
 *   desktop 1280x800   99 -> 82 (Lake & Market)   183 -> 156 (the forks)
 *   mobile   390x780         74 (Lake & Market)         155 (Lake at Canal)
 *
 * The cost is that the remainder is one bounding box wrapped round the whole
 * scene and so is never frustum-culled: its 2,489 triangles are now drawn in
 * every frame, and every stand reads about 3,600 triangles heavier. That is
 * why the threshold is only ever allowed to hold slivers — a remainder made of
 * real ground would be a worse bargain than the calls it saves, which is the
 * same test `far-merge.js` puts its own merge to.
 */
const GROUND_TILE_MIN_TRIS = 256;
// The continuous low-detail field beneath the detailed tiles: 6 heightfield
// cells = 15 m on the committed field. It carries the terrain beyond the detail
// reach without carrying the expanded field's million triangles with it.
const GROUND_BASE_STEP = 6;
const GROUND_DETAIL_REACH_M = 600;
/**
 * How far inside the detail reach the base's hole stops. A tile is kept while
 * any corner of its box is within the reach (updateGroundReach), and the box
 * holds the detailed surface; the base stands at most ~0.3 m from that surface
 * (the deepest street bed T-1812 cut, plus its own 3 cm drop), so a base
 * fragment nearer than the reach less this margin always lies over a tile that
 * is drawn. Ten metres is thirty times that, and at 590 m it is a sliver of
 * the frame.
 */
const NEAR_HOLE_MARGIN_M = 10;
/** The base's hole radius for a given haze reach: everywhere the detailed
 *  tiles are certainly drawn, and nowhere else. */
function baseHoleM(reachM, detailReachM = GROUND_DETAIL_REACH_M) {
  return Math.max(0, Math.min(reachM, detailReachM, GROUND_DETAIL_REACH_M) - NEAR_HOLE_MARGIN_M);
}

/**
 * THE GROUND'S REACH — how far out the ground is submitted at all (T-1154).
 *
 * The ground had no distance rule of any kind. Every other far-reaching layer
 * has one — the furniture its reach (T-0150), the wood its horizon cap, the
 * flora its falloff — and while the modelled box was 2,020 x 800 m the ground
 * did not need one: the whole of it was near. Two tickets moved that. T-1123
 * carried the ground north to Kinzie's Addition (809 x 661 samples) and T-0464
 * carried it south to Twenty-Second Street (809 x 1,969), so the box went from
 * 2,020 x 800 m to 2,020 x 4,920 m — 6.1 times the area at an unchanged 2.5 m
 * sample — in the eight days after the last desktop part-4 PASS. Measured on the
 * published mirror of `dev`, by hiding one scene layer at a time and reading
 * `renderer.info` back: at Lake and Market the ground alone is 994,528 of the
 * frame's 1,432,679 triangles at the `light` tier, and 96.7 per cent of the
 * WHOLE ground mesh is inside one downtown frustum. The culling grid is not the
 * problem — T-0466 already measured that, and 12 x 12 buys 58,287 triangles for
 * fifteen draw calls — because what the frustum is taking is not badly cut, it
 * is simply all of it, out to the camera's 3,000 m far plane.
 *
 * THE RULE IS THE HAZE, AND IT IS DERIVED RATHER THAN CHOSEN. `world.js` draws
 * the scene under `FogExp2`, whose surviving fraction of a surface's own colour
 * at distance d is exp(-(d * density)^2). Beyond the distance where that falls
 * under one part in `steps`, the surface cannot move an 8-bit channel: it is
 * already the horizon haze, to the last representable step. Solve it and the
 * reach is sqrt(ln steps) / density — 2,644.9 m at the scene's 0.00089, against
 * a far plane at 3,000. So this is not a cheapening of a tier a visitor chose:
 * it is the distance past which the ground is provably not drawn even when it is
 * drawn, and it is why the reach is applied at EVERY tier and not only at
 * `light`.
 *
 * **THE DENSITY MOVED ONCE, AND THIS REACH MOVED 761.7 m WITH IT FOR NOTHING
 * (T-1635).** It read 1,883 m at the old 0.00125, which `world.js` had set
 * against L17's since-retired "total by 1500 m"; the density is now derived from
 * the ground apron's own published width and the reach is 2,644.9 m. Measured on
 * the published mirror at desktop 1280x800, before and after, at T-0135's five
 * stands and all three sealed tiers: every one of the fifteen triangle and
 * draw-call readings is IDENTICAL, and so is the owner's own aerial pose (30 of
 * 217 tiles drawn either way). What lies between the two reaches at those stands
 * is apron, and T-1595's sliver merge already submits the whole apron as one
 * always-drawn mesh of 2,489 triangles. So this rule is cheaper than it looks to
 * loosen — but it is still a rule, and the density that sets it is gated against
 * the apron by `tools/check_haze_reach.mjs`.
 *
 * WHAT IT IS NOT. Nothing is un-built, re-graded or moved. The detailed ground
 * remains within 600 m and a continuous 15 m-sampled rendition of the same
 * heightfield carries the distance beyond it. `surfaceHeight` and
 * `walkableHeight` read the original 2.5 m field and never either mesh, so
 * footing, water, flora roots and every anchored record are untouched. Beyond
 * the outer haze reach even the skirt is withheld, exactly as T-1238 measured —
 * and since T-1635 the reach and the skirt's outer edge stand 14.9 m apart, so
 * what is withheld out there is a sliver of the apron rather than most of it.
 *
 * @param {number} density  the scene fog's `FogExp2` density
 * @param {number} steps    how many representable steps the channel has
 * @returns {number} the reach in metres, or Infinity where there is no fog
 */
export function hazeReachM(density, steps = 255) {
  if (!(density > 0) || !(steps > 1)) return Infinity;
  return Math.sqrt(Math.log(steps)) / density;
}

/**
 * The culling grid for a ground of this shape (T-1245).
 *
 * A fixed tile count grows fixed kilometre-wide tiles when the ground expands.
 * The reach then cannot reject the far part of a tile whose near edge still lies
 * inside it. Bound each side in metres instead: the committed 7,340 × 10,240 m
 * mesh becomes 31 × 43, and any later extension adds tiles rather than silently
 * making every existing tile coarser.
 *
 * @param {number} spanX  the ground's east-west extent, metres
 * @param {number} spanZ  its north-south extent, metres
 * @returns {{cols: number, rows: number}} cuts along X and along Z
 */
export function groundTileGrid(spanX, spanZ, targetM = GROUND_TILE_TARGET_M) {
  if (!(spanX > 0) || !(spanZ > 0)) return { cols: 1, rows: 1 };
  return {
    cols: Math.max(1, Math.ceil(spanX / targetM)),
    rows: Math.max(1, Math.ceil(spanZ / targetM)),
  };
}

/** local ENU metres -> three world position. */
export function enuToWorld(e, n, y = 0, target = new THREE.Vector3()) {
  return target.set(e, y, -n);
}

/** three world position -> local ENU metres. */
export function worldToEnu(v) {
  return { e: v.x, n: -v.z, y: v.y };
}


/**
 * A regular grid of elevations, sampled bilinearly.
 *
 * Layout, which `generators/terrain_gen.py` writes and this reads: row-major
 * Float32 (or scaled Int16) samples, row 0 at the SOUTH edge, column 0 at the
 * WEST edge, `cell_m` metres apart, the sample at [0][0] sitting exactly on
 * (`origin_e`, `origin_n`) in local ENU metres.
 */
export class Heightfield {
  constructor() {
    this.loaded = false;
    this.cols = 0;
    this.rows = 0;
    this.cellM = 1;
    this.originE = 0;
    this.originN = 0;
    this.data = null;
    this.meta = null;
    this.contextCoast = null;
    /** T-2502: a scene's apron field (terrain-apron.js) — a second Heightfield
     *  answered outside this one's grid, before the fallback. */
    this.apron = null;
    /** Height used outside the grid and before anything is loaded. */
    this.fallbackY = 0;
  }

  get widthM() { return (this.cols - 1) * this.cellM; }
  get depthM() { return (this.rows - 1) * this.cellM; }

  /**
   * @param {object} meta  { cols, rows, cell_m, origin_e, origin_n, encoding?, scale?, offset? }
   * @param {ArrayBuffer} buffer  raw samples, row-major from the south-west corner
   */
  adopt(meta, buffer) {
    const cols = meta.cols | 0;
    const rows = meta.rows | 0;
    if (!(cols > 1 && rows > 1)) throw new Error('heightfield: cols/rows must be > 1');

    const encoding = meta.encoding || 'float32';
    let data;
    if (encoding === 'float32') {
      data = new Float32Array(buffer, 0, cols * rows);
    } else if (encoding === 'int16') {
      // Quantised metres: y = raw * scale + offset. The plan quantises to
      // <= 0.25 ft, which int16 carries comfortably over 15 ft of relief.
      const raw = new Int16Array(buffer, 0, cols * rows);
      const scale = meta.scale ?? 0.01;
      const offset = meta.offset ?? 0;
      data = new Float32Array(raw.length);
      for (let i = 0; i < raw.length; i++) data[i] = raw[i] * scale + offset;
    } else {
      throw new Error(`heightfield: unknown encoding '${encoding}'`);
    }
    if (data.length < cols * rows) {
      throw new Error(`heightfield: ${data.length} samples for a ${cols}x${rows} grid`);
    }

    this.cols = cols;
    this.rows = rows;
    this.cellM = meta.cell_m ?? meta.cellM ?? 1;
    this.originE = meta.origin_e ?? meta.originE ?? 0;
    this.originN = meta.origin_n ?? meta.originN ?? 0;
    this.data = data;
    this.meta = meta;
    this.loaded = true;
    return this;
  }

  async load(metaUrl, binUrl) {
    const meta = await (await fetch(metaUrl)).json();
    const buffer = await (await fetch(binUrl ?? new URL(meta.bin, metaUrl))).arrayBuffer();
    return this.adopt(meta, buffer);
  }

  /** True when (e, n) lies on the loaded grid. Outside it, `sample()` answers
   * with `fallbackY` rather than a measurement — callers that refine geometry
   * against the field (streets.js, T-0110) must not treat that constant as
   * ground truth, so this is the test that separates the two. */
  contains(e, n) {
    if (!this.loaded) return false;
    const gx = (e - this.originE) / this.cellM;
    const gy = (n - this.originN) / this.cellM;
    return gx >= 0 && gy >= 0 && gx <= this.cols - 1 && gy <= this.rows - 1;
  }

  /** Elevation in metres at local ENU (e, n). Bilinear; clamped at the edges. */
  sample(e, n) {
    if (!this.loaded) return this.fallbackY;
    const gx = (e - this.originE) / this.cellM;
    const gy = (n - this.originN) / this.cellM;
    if (gx < 0 || gy < 0 || gx > this.cols - 1 || gy > this.rows - 1) {
      if (this.apron?.contains(e, n)) return this.apron.sample(e, n);
      if (this.contextCoast) return contextSample(this, e, n, (ce, cn) => this.sample(ce, cn));
      return this.fallbackY;
    }

    const x0 = Math.min(Math.floor(gx), this.cols - 2);
    const y0 = Math.min(Math.floor(gy), this.rows - 2);
    const fx = gx - x0;
    const fy = gy - y0;
    const d = this.data;
    const r0 = y0 * this.cols;
    const r1 = r0 + this.cols;
    const h00 = d[r0 + x0], h10 = d[r0 + x0 + 1];
    const h01 = d[r1 + x0], h11 = d[r1 + x0 + 1];
    return (h00 * (1 - fx) + h10 * fx) * (1 - fy) + (h01 * (1 - fx) + h11 * fx) * fy;
  }

  /** Surface normal by central differences — for slope limits and shading. */
  normal(e, n, target = new THREE.Vector3()) {
    if (!this.loaded) return target.set(0, 1, 0);
    const d = this.cellM;
    const dydE = (this.sample(e + d, n) - this.sample(e - d, n)) / (2 * d);
    const dydN = (this.sample(e, n + d) - this.sample(e, n - d)) / (2 * d);
    return target.set(-dydE, 1, dydN).normalize();
  }
}

/**
 * Load the terrain for one epoch: the heightfield the walker samples, the
 * ground mesh, and the water surface.
 *
 * Degrades in one step at a time. No heightfield means a flat plane at the
 * datum and a recorded problem; no ground GLB means a mesh built here from the
 * heightfield, which is the same surface by construction and costs one boot
 * frame. Nothing here silently renders a fiction.
 *
 * @param {object} o
 * @param {URL} o.dataBase        where data/ lives
 * @param {URL} o.assetBase       where the GLBs live
 * @param {string} o.epochId      terrain epoch, from the scene file
 * @param {URL|null} [o.substrateBase] where the flora manifest the ground's sand and
 *                                marsh colours come from lives; null paints none
 * @param {object} [o.confidence] the confidence view, to patch the materials into
 * @param {string[]} [o.problems] collector, same list the scene loader writes to
 */
export async function createTerrain({
  dataBase, assetBase, epochId, substrateBase = dataBase, confidence = null, problems = [],
  sceneId = null, apronPath = null, targetDate = null, supportRegions = [],
  /** T-2693: `{ index, bin }` from `fetchPrebuiltGround` (or a promise of it),
   *  used in place of the ground GLB when it is current (THE GROUND, PREBUILT). */
  prebuilt = null,
  /** T-2709: `{ index, bin }` from `fetchPrebuiltBase` (or a promise of it), the
   *  distant base's pieces used in place of its grid and cut (THE DISTANT BASE, PREBUILT). */
  prebuiltBase = null,
} = {}) {
  const group = new THREE.Group();
  group.name = 'terrain';
  const heightfield = new Heightfield();
  const disposables = [];

  let meta = null;
  // The bytes as fetched, so a prebuilt ground can be held to them (T-2693).
  let metaBytes = null;
  let binBytes = null;
  let fieldHashes = null;
  if (dataBase && epochId) {
    const metaUrl = new URL(`terrain/epochs/${epochId}/heightfield.json`, dataBase);
    try {
      metaBytes = await (await fetchOk(metaUrl)).arrayBuffer();
      meta = JSON.parse(new TextDecoder().decode(metaBytes));
      const bin = await (await fetchOk(new URL(meta.bin, metaUrl))).arrayBuffer();
      heightfield.adopt(meta, bin);
      binBytes = bin;
      if (prebuilt && globalThis.crypto?.subtle) {
        fieldHashes = Promise.all([metaBytes, bin].map(sha256Hex)).then(([json, raw]) => new Map([
          [`data/terrain/epochs/${epochId}/heightfield.json`, json],
          [`data/terrain/epochs/${epochId}/${meta.bin}`, raw]]), () => null);
      }
    } catch (err) {
      problems.push(`terrain ${epochId}: no heightfield (${err.message}) — `
        + 'the ground is a flat plane at the datum and the walker will not climb a bank');
      meta = null;
    }
  }

  // ---- the ground -------------------------------------------------------- //

  // `substrateBase` is null for a scene that plants none of the 1835 zones (T-1739):
  // their extents are what paint the sand belt and the marsh, so it gets none of them.
  // The lake's edge, read off the field this epoch just adopted (T-1819): the
  // beach is a band measured from it, so the sand follows the modelled shore
  // rather than a box. lakeshore.js; null without a heightfield.
  const lakeShore = lakeShoreLine(heightfield);
  const zones = await substrateZones(substrateBase, problems, sceneId);
  // T-2085: the town's turf, one uniform set for both ground materials, filled
  // when the sward hands over where it stopped drawing cards (`setTurf`).
  const turf = turfGround();
  // T-2783: the far sward's colour map, filled by flora.js (`setFarSward`).
  const farSward = farSwardGround();
  const groundMat = groundMaterial(zones, lakeShore, { turf, farSward });
  let walkOffset = null;
  let passageGround = [];
  /** The radius around the eye inside which the 15 m base is not drawn. See
   *  the base below, and `baseHoleM()` for how it follows the reach. */
  const baseHole = { value: baseHoleM(Infinity) };
  // `.map` is null here — the prairie tile is bound as a shader uniform, not as
  // the standard material map, so disposing `.map` disposed nothing and leaked
  // the canvas texture on every epoch change.
  disposables.push(groundMat, groundMat.userData.groundTex, groundMat.userData.swardTex, turf,
    farSward);
  confidence?.patch(groundMat);

  let ground = null;
  const groundPath = meta?.glb?.ground;
  // T-2693: the ground's tiles prebuilt at publish stand in for the GLB, which
  // is then not fetched at all. Any refusal is recorded and the GLB loads.
  const prebuiltGround = { used: false, why: prebuilt ? null : 'none offered' };
  let replay = null;
  if (prebuilt && groundPath && assetBase && heightfield.loaded) {
    const offered = await prebuilt;
    const field = {};
    prebuiltGround.why = await prebuiltGroundRefusal(offered,
      { sceneId, epochId, meta, metaBytes, binBytes, groundPath, field });
    // T-2710: the SHA-256 of each heightfield file read, by path, when it was hashed.
    if (Object.keys(field).length) prebuiltGround.field = field;
    if (!prebuiltGround.why) replay = offered;
  } else if (prebuilt) {
    prebuiltGround.why = 'this epoch names no ground GLB or no heightfield loaded';
  }
  if (groundPath && assetBase && !replay) {
    ground = await loadGlbMesh(new URL(groundPath, assetBase))
      .catch((err) => {
        problems.push(`terrain ${epochId}: ${groundPath} (${err.message}) — `
          + 'ground rebuilt from the heightfield instead');
        return null;
      });
  }
  let groundFit = null;
  if (replay) {
    // Conformed in Node by the same function, against the field just hashed.
    groundFit = { ...replay.index.conform };
  } else if (ground) {
    confidence?.ensureAttribute(ground.geometry, `terrain ${epochId} ground`);
    // BEFORE tiling, which splits this geometry into the meshes that are drawn.
    // See conformGroundToField: the published GLB's heights are quantised onto a
    // 306 mm lattice and the town is anchored to the heightfield, so the ground a
    // visitor sees is read back off the field rather than off the compressor.
    groundFit = conformGroundToField(ground.geometry, heightfield);
    // 10 µm: four orders of magnitude inside the 30 mm the ground is held to,
    // and a comfortable margin over the 0.24 µm float32 storage costs.
    if (groundFit && groundFit.residual_max_m > 1e-5) {
      problems.push(`terrain ${epochId}: the ground mesh still departs from the heightfield by `
        + `${(groundFit.residual_max_m * 1000).toFixed(1)} mm after conforming — `
        + 'the road and the flora are drawn under the ground where it does');
    }
  } else {
    ground = new THREE.Mesh(gridGeometry(heightfield));
    ground.name = `terrain__${epochId ?? 'flat'}`;
    // Built from the field itself, so it is conformed by construction.
    groundFit = { vertices: ground.geometry.attributes.position.count, moved: 0,
                  correction_max_m: 0, residual_max_m: 0 };
  }
  // T-2495: replace the straight extrusion outside Prairie Avenue with the
  // generated historical-map apron. Adopt its sampler only once both files load.
  if (sceneId === '1904' && heightfield.loaded && !replay) {
    try {
      const url = new URL(`terrain/epochs/${epochId}/context.json`, dataBase);
      const coast = await (await fetchOk(url)).json();
      const apron = await loadGlbMesh(new URL(coast.ground_glb, url));
      const old = ground.geometry;
      ground.geometry = replaceApron(old, apron.geometry, heightfield);
      old.dispose(); apron.geometry.dispose();
      heightfield.contextCoast = coast;
    } catch (err) {
      problems.push(`terrain 1904 context coast: ${err.message}`);
    }
  }
  // T-2502: the scene's apron field (its `terrain_apron`), ground off the box.
  // Sampled outside the box before the fallback, drawn from its own samples, and
  // the box's carried apron cut out from under it. Adopted only once it loads; a
  // failure leaves the carried apron standing and says so.
  let apronMesh = null;
  let apronGroundCut = null;
  if (apronPath && dataBase && heightfield.loaded) {
    try {
      const url = new URL(`terrain/epochs/${apronPath}`, dataBase);
      const apronMeta = await (await fetchOk(url)).json();
      const bin = await (await fetchOk(new URL(apronMeta.bin, url))).arrayBuffer();
      const apron = new Heightfield().adopt(apronMeta, bin);
      const mat = groundMaterial(zones, lakeShore, { groundTex: groundMat.userData.groundTex,
        swardTex: groundMat.userData.swardTex, turf, farSward });
      confidence?.patch(mat);
      apronMesh = new THREE.Mesh(apronGeometry(apron, apronMeta.skirt_to_n_m ?? apron.originN), mat);
      apronMesh.name = `terrain_apron__${apronPath.replace(/\W+/g, '_')}`;
      apronMesh.receiveShadow = true;
      apronMesh.castShadow = false;
      apronGroundCut = apronCut(apronMeta.cut_local_enu_m);
      disposables.push(mat, apronMesh.geometry, apronGroundCut.mask);
      heightfield.apron = apron;
    } catch (err) {
      problems.push(`terrain apron ${apronPath}: ${err.message} — the box's carried apron stands `
        + 'there instead, and the ground off the box is the fallback');
      apronMesh = null;
      apronGroundCut = null;
    }
  }
  if (ground) {
    ground.material = groundMat;
    ground.receiveShadow = true;
    ground.castShadow = false;
  }
  // The ground was `frustumCulled = false` because one mesh wrapped around the
  // camera always intersects the frustum, so testing it could only ever cost time
  // or throw the floor away by mistake. True of one mesh; not true of the ground.
  // Cut it into tiles and the half of the world behind you stops being drawn —
  // see tileGround() for the measurements behind the grid below.
  const sourceTiles = replay ? null : tileGround(ground, groundTileGrid);
  // Keep each source tile's draw call, but give its dense ground 40 m pieces
  // with independently tested bounds. The 240 m Light reach used to retain a
  // whole ~235 m tile when only its nearest corner was in range. Batching keeps
  // every original triangle/attribute and the same reach; the continuous base
  // already carries everything beyond it. The small apron remainder stays one
  // mesh: it is deliberately outside the detailed heightfield's reach policy.
  // T-2599: the tiles are partitioned on the job pool, all at once, so the
  // densest ground in the town is cut into pieces off the main thread and on as
  // many cores as the pool has; the batches are the same, in the same order.
  // T-2693: or, prebuilt, the same pieces read off the file and batched here.
  let tiles = null;
  if (replay) {
    tiles = prebuiltGroundTiles(replay.index, replay.bin, groundMat);
    lastGroundTiling = { ...replay.index.tiling };
    Object.assign(prebuiltGround, { used: true, why: null, build: replay.index.build, bytes: replay.index.bytes,
      tiles: tiles.length });
    // The batches hold copies; the resolved promise must not keep the buffer alive.
    replay.bin = null;
    replay.index = null;
  } else tiles = sourceTiles && await Promise.all(sourceTiles.map(async (tile) => {
    if (tile.name.endsWith('__tthin')) return tile;
    const batch = await spatialBatchAsync(tile.geometry, tile.material);
    batch.name = tile.name;
    batch.receiveShadow = tile.receiveShadow;
    batch.castShadow = tile.castShadow;
    tile.geometry.dispose();
    return batch;
  }));
  /** One banked WORLD bounding box per ground tile, for the reach below.
   *  Empty when the ground was too coarse to tile, which is the case the reach
   *  has nothing to say about: one mesh around the camera is always near. */
  const groundBounds = [];
  if (tiles) {
    for (const tile of tiles) {
      group.add(tile);
      disposables.push(tile.isBatchedMesh ? tile : tile.geometry);
    }
    // The source mesh is never added to the scene, so nothing else will dispose it.
    ground?.geometry.dispose();
    ground = tiles[0];
  } else {
    // A ground too coarse to tile is small enough not to need it.
    ground.frustumCulled = false;
    group.add(ground);
    disposables.push(ground.geometry);
  }

  if (apronMesh) {
    group.add(apronMesh);
    applyCut(groundMat, apronGroundCut);
  }

  // One continuous, modest ground under the detailed tiles. The detail tiles
  // are exact near the visitor; this 15 m field carries the same heightfield at
  // distance, where fog and perspective make the baked 2.5 m sampling wasteful.
  // A 3 cm drop prevents z-fighting where both levels are present. Navigation,
  // flora and anchored records still sample `heightfield` itself, never this LOD.
  //
  // NOT DRAWN WHERE THE DETAILED TILES ARE (the owner, 2026-10-02: walking a
  // dirt road on dev, "the grass area seems to grow and show up over the dirt
  // road as you approach it"). The 3 cm drop was enough while the field was
  // smooth at 15 m. T-1812 then graded every opened street BELOW its walks, and
  // a 15 m triangle cannot see a street bed: across Lake Street it runs from
  // lot to lot over the lowered bed, so this mesh stood up to 239 mm ABOVE the
  // road's own drape and above the detailed ground. Measured at Lake and Market
  // on 42,796 road points at 0.25 m: it beat the ribbon at 8,539 of them (20 %).
  // Far off the road's polygon offset — which scales with the depth slope, and
  // the slope is huge at a grazing angle — held it under; walking up to it, the
  // view steepens, the offset shrinks and its prairie came up through the dirt in
  // the hard-edged, faceted patches of the owner's two photographs.
  // A third ground level would only move the fault; so the base is cut out
  // inside the radius where the detail tiles are drawn, which is the only
  // place it was ever hidden anyway (see NEAR_HOLE_MARGIN_M).
  let groundBase = null;
  // T-2709: the base prebuilt at publish, already laid over frontage's crossing
  // footprints and cut into its pieces; protectGroundUnder holds it to the
  // footprints frontage then publishes, and lays and cuts its own if they differ.
  const prebuiltDistant = { used: false, why: prebuiltBase ? null : 'none offered' };
  let baseReplay = null;
  if (heightfield.loaded) {
    const baseMat = groundMaterial(zones, lakeShore,
      { nearHole: baseHole, groundTex: groundMat.userData.groundTex,
        swardTex: groundMat.userData.swardTex, turf, farSward });
    disposables.push(baseMat);
    confidence?.patch(baseMat);
    const baseName = `terrain_base__${epochId ?? 'field'}`;
    if (prebuiltBase) {
      const offered = await prebuiltBase;
      prebuiltDistant.why = await prebuiltRefusal(offered, { sceneId, epochId, meta, metaBytes, binBytes })
        ?? (offered.index.tiles?.[0]?.name !== baseName ? `prebuilt as ${offered.index.tiles?.[0]?.name}, this base is ${baseName}` : null);
      if (!prebuiltDistant.why) baseReplay = offered;
    }
    if (baseReplay) {
      const { index } = baseReplay;
      groundBase = prebuiltGroundTiles(index, baseReplay.bin, baseMat)[0];
      Object.assign(prebuiltDistant, { used: true, why: null, build: index.build,
        bytes: index.bytes, pieces: groundBase.userData.spatialBatch.pieces });
      // The batch holds copies; the resolved promise must not keep the buffer alive.
      baseReplay.bin = null;
      baseReplay.index = null;
      baseReplay = { footprints: index.footprints_key, adaptive: index.adaptive };
      disposables.push(groundBase);
    } else {
      groundBase = new THREE.Mesh(gridGeometry(heightfield, GROUND_BASE_STEP), baseMat);
      disposables.push(groundBase.geometry);
      // batchDistantGround() re-reads these arrays after a phone has already
      // uploaded the terrain layer, so they must outlive that upload (T-2180).
      groundBase.geometry.userData.rereadBeforeRelease = true;
    }
    groundBase.name = baseName;
    groundBase.position.y = -0.03;
    groundBase.receiveShadow = true;
    groundBase.castShadow = false;
    groundBase.frustumCulled = true;
    group.add(groundBase);
  } else if (prebuiltBase) {
    prebuiltDistant.why = 'no heightfield loaded';
  }

  // ---- the water --------------------------------------------------------- //

  const waterMat = waterMaterial();
  disposables.push(waterMat, waterMat.normalMap);
  confidence?.patch(waterMat);

  let water = null;
  const waterPath = meta?.glb?.water;
  if (waterPath && assetBase) {
    // NOT swallowed. The fallback below is a flat square the size of the town,
    // and substituting it silently for the traced river is the difference
    // between a reconstruction and a flood — the failure has to reach the
    // problems list where the gate and the Evidence panel can see it.
    water = await loadGlbMesh(new URL(waterPath, assetBase)).catch((err) => {
      problems.push(`water: ${waterPath} did not load (${err.message}) — falling back to a `
        + 'flat plane at the datum, which is NOT the traced river');
      return null;
    });
  }
  if (!water) {
    const g = new THREE.PlaneGeometry(2400, 2400, 1, 1);
    g.rotateX(-Math.PI / 2);
    // The confidence channel is part of the contract even for a fallback mesh:
    // the water surface at the datum is the one DOCUMENTED thing in this layer.
    g.setAttribute('_confidence', new THREE.BufferAttribute(new Float32Array(4), 1));
    water = new THREE.Mesh(g);
    water.name = `water__${epochId ?? 'flat'}`;
  } else {
    confidence?.ensureAttribute(water.geometry, `terrain ${epochId} water`);
  }
  water.material = waterMat;
  water.position.y = WATER_Y;
  water.receiveShadow = false;
  water.castShadow = false;
  water.frustumCulled = false;
  // Draw the water AFTER the ground so the depth buffer rejects the water
  // fragments the bank hides — which is most of them, this being a 640 m box
  // with a river through it rather than a lake.
  water.renderOrder = 1;
  group.add(water);
  disposables.push(water.geometry);

  let t = 0;

  // ---- the ground's reach (T-1154) --------------------------------------- //
  // Banked once, here, for the same reason the furniture's spheres are banked:
  // the per-frame test must do no matrix work and no allocation. A sphere was
  // deliberately conservative, but on a kilometre-wide ground tile its empty
  // corners extended the reach by hundreds of metres. The axis-aligned tile
  // boxes are exact for this unmoving grid, so the haze boundary tests the tile
  // itself rather than the circle wrapped around it (T-1245).
  if (tiles) {
    group.updateWorldMatrix(true, true);
    for (const tile of tiles) {
      if (tile.isBatchedMesh) {
        for (let instance = 0; instance < tile.userData.spatialBatch.pieces; instance++) {
          // spatialBatch owns one geometry per identity instance, in the same
          // order. Read its actual bounds, including corners across a grid edge.
          const box = tile.getBoundingBoxAt(instance, new THREE.Box3()).clone();
          box.applyMatrix4(tile.matrixWorld);
          const e = (box.min.x + box.max.x) / 2;
          const n = -(box.min.z + box.max.z) / 2;
          groundBounds.push({ mesh: tile, instance, min: box.min, max: box.max,
                              overField: heightfield.contains(e, n) });
        }
        continue;
      }
      if (!tile.geometry.boundingBox) tile.geometry.computeBoundingBox();
      const box = tile.geometry.boundingBox?.clone();
      if (!box) continue;
      box.applyMatrix4(tile.matrixWorld);
      const e = (box.min.x + box.max.x) / 2;
      const n = -(box.min.z + box.max.z) / 2;
      groundBounds.push({ mesh: tile, min: box.min, max: box.max,
                          overField: heightfield.contains(e, n) });
    }
  }
  /** The reach in force, in metres. `Infinity` draws every tile, which is what
   *  the ground did before this and what it still does until a scene with a fog
   *  sets one — see hazeReachM(). */
  let groundReachM = Infinity;
  // The detailed tiles' own reach, per scene-detail tier (T-1976). Starts at the
  // constant every tier carried until then; `setDetailReach` moves it.
  let groundDetailReachM = GROUND_DETAIL_REACH_M;
  let groundDrawn = groundBounds.length;
  let groundHeld = 0;

  /** The haze the water has been ASKED for, which is not always the haze it has
   *  been given: the `uSky` uniform does not exist until the material compiles,
   *  a frame or two after this object does, and the view may not turn again for
   *  minutes. So the wish is kept and re-offered every frame until it lands. */
  let hazeWanted = null;
  function applyHaze() {
    const u = waterMat?.userData?.chiSkyUniform;
    if (!u || !hazeWanted || u.value.equals(hazeWanted)) return false;
    u.value.copy(hazeWanted);
    return true;
  }

  const staticSupport = await retainDrawnStaticSupport({ group, regions: supportRegions,
    sceneId, targetDate, surfaceKind: 'terrain_triangle', problems,
    sources: region => region.record_id === `terrain_${epochId}`
      && region.bounds_enu_m.every(([e,n]) => heightfield.contains(e,n))
      ? (tiles ?? [ground]).map(mesh => ({mesh})) : [],
  });
  return {
    group,
    drawnStaticSupport: staticSupport,
    mesh: ground,
    water,
    material: groundMat,
    /** T-2085. Paint the short turf where the sward has stopped drawing cards.
     *  Called by flora.js with its own mask; false if the spec is unusable. */
    setTurf(spec) { return turf.set(spec); },
    /** T-2783. Paint the far sward's colour past the near rings. Called by
     *  flora.js with its own map; false if the spec is unusable. */
    setFarSward(spec) { return farSward.set(spec); },
    waterMaterial: waterMat,
    /** Keep the far base below emitted crossing decks without moving timber.
     * One replacement per frontage load; the current geometry has exactly one
     * disposal entry even if a caller rebuilds the protection later. */
    protectGroundUnder(footprints) {
      if (!groundBase || !heightfield.loaded) return null;
      if (baseReplay) {
        // T-2709: the prebuilt base was laid over these footprints, or it was not.
        const { footprints: key, adaptive } = baseReplay;
        baseReplay = null;
        if (key === footprintsKey(footprints)) return adaptive;
        Object.assign(prebuiltDistant, { used: false,
          why: 'frontage published other crossing footprints than the base was prebuilt over' });
      }
      const geometry = gridGeometry(heightfield, GROUND_BASE_STEP, footprints);
      if (groundBase.isBatchedMesh) {
        const next = spatialBatch(geometry, groundBase.material);
        next.name = groundBase.name;
        next.position.copy(groundBase.position);
        next.receiveShadow = groundBase.receiveShadow;
        next.castShadow = groundBase.castShadow;
        const slot = disposables.indexOf(groundBase);
        if (slot >= 0) disposables[slot] = next;
        else disposables.push(next);
        group.remove(groundBase);
        groundBase.dispose();
        geometry.dispose();
        group.add(next);
        groundBase = next;
        return geometry.userData.adaptiveGround;
      }
      const previous = groundBase.geometry;
      geometry.userData.rereadBeforeRelease = true;
      const slot = disposables.indexOf(previous);
      if (slot >= 0) disposables[slot] = geometry;
      else disposables.push(geometry);
      groundBase.geometry = geometry;
      previous.dispose();
      return geometry.userData.adaptiveGround;
    },
    /** Batch the protected continuous base too: one draw call, with original
     *  triangles behind the eye or beyond the frustum omitted per piece. Called
     *  after frontage publishes its accepted crossing protection at boot.
     *  T-2600: the cells are cut on the job pool, so this resolves; the base it
     *  read draws until then, and if the base or its geometry was replaced
     *  meanwhile the batch is dropped, unseen, and this resolves false.
     *  (protectGroundUnder's batched branch above stays synchronous: it runs
     *  only on a second frontage publication, which no page path makes.) */
    async batchDistantGround() {
      if (!groundBase || groundBase.isBatchedMesh) return false;
      const previous = groundBase;
      const read = previous.geometry;
      const batch = await spatialBatchAsync(read, previous.material);
      if (groundBase !== previous || previous.geometry !== read) { batch.dispose(); return false; }
      batch.name = previous.name;
      batch.position.copy(previous.position);
      batch.receiveShadow = previous.receiveShadow;
      batch.castShadow = previous.castShadow;
      const slot = disposables.indexOf(previous.geometry);
      if (slot >= 0) disposables[slot] = batch;
      else disposables.push(batch);
      group.remove(previous);
      previous.geometry.dispose();
      group.add(batch);
      groundBase = batch;
      return true;
    },
    /**
     * Point the water at the same distance the air is pointing at — T-1631.
     *
     * The grazing-angle term mixes toward `world.js`'s haze, and that haze now
     * follows the bearing the visitor is looking along, so a water surface left
     * on the boot-time colour would read a different distance from the plain it
     * lies in. The uniform does not exist until the material has compiled, which
     * is a frame or two after this object does, so the write is guarded rather
     * than assumed.
     *
     * @param {THREE.Color} colour the scene fog's colour, live
     * @returns {boolean} whether a uniform was actually written
     */
    setHaze(colour) {
      if (colour) hazeWanted = (hazeWanted ?? new THREE.Color()).copy(colour);
      return applyHaze();
    },
    heightfield,
    meta,
    epochId,
    loaded: heightfield.loaded,

    /** How far the ground a visitor SEES had to move to become the ground the
     * town is anchored to, and what is left over afterwards. The gate reads
     * `residual_max_m`; `correction_max_m` is the size of the fault repaired,
     * and it is a number worth watching rather than asserting, because it
     * belongs to the compressor and not to this renderer. */
    groundFit,

    /** T-2693: whether the ground's tiles came prebuilt, and if not, why not. */
    prebuilt: prebuiltGround,
    /** T-2709: whether the distant base came prebuilt, and if not, why not. */
    prebuiltBase: prebuiltDistant,

    /** T-2711: the SHA-256 of the heightfield.json and .bin this page read, keyed
     *  as a prebuild's inputs are (`data/terrain/epochs/<epoch>/…`), for a layer
     *  whose prebuild was laid on this field (yards.js § THE YARDS, PREBUILT).
     *  A promise, started as the field is read whenever a prebuilt ground is
     *  offered (main.js always offers one), so the bytes are not kept; null otherwise. */
    heightfieldHashes: () => fieldHashes,

    /** The lake's edge as E per 40 m of N, read off this epoch's heightfield
     * (lakeshore.js) — the line the beach is measured from, by the ground
     * shader and, through flora-zones.js's extent matcher, by the sward and the
     * trees. Null without a heightfield. T-1819. */
    lakeShore,

    /**
     * THE GROUND'S REACH (T-1154) — the setter, the reading and the per-frame
     * test. See hazeReachM() above for what the distance is and why.
     *
     * `reachCulled` is recorded on the mesh as well as counted, so a probe can
     * tell a tile held back for distance from one the frustum rejected: both
     * end up `visible === false` to three, and only one of them is this rule.
     */
    setGroundReach(m) {
      groundReachM = typeof m === 'number' && Number.isFinite(m) && m > 0 ? m : Infinity;
      baseHole.value = baseHoleM(groundReachM, groundDetailReachM);
      return groundReachM;
    },
    /** How far out the DETAILED tiles are drawn before the 15 m base carries
     *  the ground alone (T-1976). Never past `GROUND_DETAIL_REACH_M`, the
     *  reach every tier carried before a tier could ask for less; anything
     *  that is not a positive finite number restores it. */
    setDetailReach(m) {
      groundDetailReachM = typeof m === 'number' && Number.isFinite(m) && m > 0
        ? Math.min(m, GROUND_DETAIL_REACH_M) : GROUND_DETAIL_REACH_M;
      // The base's hole follows the tiles in, or Light (240 m) would leave a
      // ring from there to 590 m with no ground drawn at all.
      baseHole.value = baseHoleM(groundReachM, groundDetailReachM);
      return groundDetailReachM;
    },
    /** What the reach is doing this frame: the distance, and the tile counts. */
    groundReach() {
      return { reachM: Number.isFinite(groundReachM) ? groundReachM : null,
               detailReachM: groundDetailReachM,
               baseTriangles: groundBase
                 ? groundBase.geometry.index.count / 3 : 0,
               tiles: groundBounds.length, drawn: groundDrawn, held: groundHeld };
    },
    /** Per frame, before the render: hold back the ground the haze has already
     *  finished. One subtraction and one comparison per tile, over the few dozen
     *  the grid comes to. */
    updateGroundReach(eye) {
      // T-1631: the same per-frame moment, and the cheapest place to land a
      // haze the material was not yet compiled to receive. A colour compare.
      applyHaze();
      if (!groundBounds.length) return groundReachM;
      let drawn = 0;
      let held = 0;
      for (const bound of groundBounds) {
        // Exact squared distance from the eye to an axis-aligned box. A zero on
        // an axis means the eye is between that pair of faces. This keeps a tile
        // whenever ANY of its ground can be inside the reach, with no sphere's
        // empty corner buying it extra distance.
        const dx = Math.max(bound.min.x - eye.x, 0, eye.x - bound.max.x);
        const dy = Math.max(bound.min.y - eye.y, 0, eye.y - bound.max.y);
        const dz = Math.max(bound.min.z - eye.z, 0, eye.z - bound.max.z);
        const reach = bound.overField
          ? Math.min(groundReachM, groundDetailReachM) : groundReachM;
        const far = dx * dx + dy * dy + dz * dz > reach * reach;
        if (bound.instance !== undefined) bound.mesh.setVisibleAt(bound.instance, !far);
        else {
          bound.mesh.visible = !far;
          bound.mesh.userData.reachCulled = far;
        }
        if (far) held++; else drawn++;
      }
      groundDrawn = drawn;
      groundHeld = held;
      return groundReachM;
    },

    /** The one rendered terrain surface in metres at local ENU (e, n).
     * Buildings, streets, trees and plant roots all anchor to this sampler. */
    surfaceHeight(e, n) { return heightfield.sample(e, n); },
    get contextCoast() { return heightfield.contextCoast ?? null; },

    /**
     * The WALKABLE surface: the rendered terrain on land, with the documented
     * navigation barrier over open water. See the note at the top of this file.
     */
    walkHeight(e, n) {
      const h = heightfield.sample(e, n);
      if (h < SHORE_Y) return WATER_BARRIER_Y;
      const sunk = passageGround.length ? passageDepth(passageGround, e, n) : null;
      if (sunk !== null) return h + sunk;
      return walkOffset ? h + walkOffset(e, n) : h;
    },

    /**
     * T-2976: a building that lays its own ground below the field (Glessner's sunk
     * carriage way, approach to court ramp) has the field cut out over it exactly, and
     * the walk follows its paving: `pieces` from walker.js `passageGroundFrom`, each a
     * convex quad `pts` of [e, n] and `z` its paving height over the ground at each
     * corner. [] clears it. `surfaceHeight()` keeps reporting the field.
     */
    setPassageGround(pieces = []) {
      passageGround = Array.isArray(pieces) ? pieces.slice(0, PASS_CUT_MAX) : [];
      for (const m of [groundMat, groundBase?.material]) applyPassCut(m, passageGround);
    },

    /**
     * T-2474: a layer that draws the ground lower than the field (the 1904
     * roadway below its curbs) cuts the field's own mesh out there — `mask` is a
     * coverage texture over the world box `x0, z0, width, depth` — and tells the
     * walker how far down it put the surface: `offset(e, n)` in metres, 0 off it.
     * `surfaceHeight()` keeps reporting the field; only the walk follows the cut.
     */
    setGroundCut({ mask, x0, z0, width, depth, offset = null } = {}) {
      for (const m of [groundMat, groundBase?.material]) {
        // Clearing a street's cut hands the tiles back to the apron field's (T-2502).
        if (!mask && m === groundMat && apronGroundCut) applyCut(m, apronGroundCut);
        else applyCut(m, { mask, x0, z0, width, depth });
      }
      walkOffset = typeof offset === 'function' ? offset : null;
    },

    /** Backward-compatible names for older harnesses and external consumers. */
    height(e, n) {
      const h = heightfield.sample(e, n);
      return h < SHORE_Y ? WATER_BARRIER_Y : h;
    },
    groundHeight(e, n) { return heightfield.sample(e, n); },

    /** True where the terrain is below the water surface. */
    isWater(e, n) { return heightfield.sample(e, n) < SHORE_Y; },
    /** The height below which `isWater` answers true (T-2695: flora's worker
     *  ground asks the same question of the same grid). */
    shoreY: SHORE_Y,

    /** True where (e, n) is on the measured grid — where `surfaceHeight()` is
     * a sample rather than the out-of-bounds fallback (T-0110). */
    inBounds(e, n) { return heightfield.contains(e, n); },

    /** The sample lattice `surfaceHeight()` interpolates between (T-1812): the
     * bilinear ground is straight along any line between two of its grid lines,
     * which is where a draped mesh needs its vertices and nowhere else. */
    get grid() {
      return { cellM: heightfield.cellM, originE: heightfield.originE,
        originN: heightfield.originN };
    },

    /** Drift the ripples. One line in the render loop; nothing else animates. */
    update(dt) {
      t += dt;
      const nm = waterMat.normalMap;
      if (nm) {
        nm.offset.set((t * 0.011) % 1, (t * 0.0068) % 1);
        nm.needsUpdate = false;      // offset is a uniform, not a re-upload
      }
    },

    dispose() {
      staticSupport.dispose();
      for (const d of disposables) d?.dispose?.();
    },
  };
}

async function fetchOk(url) {
  const res = await fetch(url, { cache: 'no-cache' });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
  return res;
}

/**
 * Cut the ground into a grid of tiles so frustum culling has something to bite on.
 *
 * The ground arrives as ONE mesh spanning the whole 2 km × 800 m box, and a single
 * mesh that surrounds the camera always intersects the frustum — so culling it can
 * never help, which is exactly why it was switched off. That was the correct
 * conclusion from a false premise: the premise is that the ground has to be one
 * mesh. Cut into tiles, each tile gets its own bounding sphere, and the ones behind
 * you stop being drawn.
 *
 * T-0466 first measured this on the former 247,527-triangle, 2,020 × 800 m ground.
 * T-1245 repeated the real-renderer comparison after the field grew to
 * 7,340 × 10,240 m: even 32 × 48 alone left the binding light stand at 957,505
 * triangles. The final 240 m rule works with the continuous 15 m base and 600 m
 * detailed reach above; `data/render/ground_detail_lod.json` keeps the rejected
 * grid-only readings and all six closing viewport/tier readings. Tiles remain cheap
 * draw calls (one shared material, no state change), not free ones, which is why the
 * same reading also holds them under the existing 215-call budget.
 *
 * The split is by triangle CENTROID, so no triangle is duplicated and no seam is
 * introduced: every triangle lands in exactly one tile and the surface is the same
 * surface. Every attribute travels with it — `_confidence` included, which the
 * confidence view reads, and which a naive position-only split would silently drop.
 */
// Exported for tools/prebuild_layers.mjs (T-2692), which tiles the ground in Node
// with this same function so its pieces can be built ahead of the visit.
export function tileGround(mesh, grid) {
  const geo = mesh.geometry;
  const pos = geo.attributes.position;
  if (!pos) return null;
  const index = geo.index ? geo.index.array : null;
  const triCount = index ? index.length / 3 : pos.count / 3;

  geo.computeBoundingBox();
  const bb = geo.boundingBox;
  // The grid is asked for AFTER the box is known, because it is a function of the
  // box — see groundTileGrid(). `lastGroundTiling` is what the measurement harness
  // and `?debug=1` read back; nothing in the scene depends on it.
  const { cols, rows } = grid(bb.max.x - bb.min.x, bb.max.z - bb.min.z);
  lastGroundTiling = { cols, rows,
                       spanX: bb.max.x - bb.min.x, spanZ: bb.max.z - bb.min.z,
                       tileX: (bb.max.x - bb.min.x) / cols,
                       tileZ: (bb.max.z - bb.min.z) / rows };
  if (triCount < cols * rows * 4) return null;   // too coarse to be worth splitting

  const spanX = (bb.max.x - bb.min.x) / cols;
  const spanZ = (bb.max.z - bb.min.z) / rows;
  if (!(spanX > 0) || !(spanZ > 0)) return null;

  const px = pos.array;
  const buckets = new Map();
  for (let t = 0; t < triCount; t++) {
    const a = index ? index[t * 3] : t * 3;
    const b = index ? index[t * 3 + 1] : t * 3 + 1;
    const c = index ? index[t * 3 + 2] : t * 3 + 2;
    const cx = (px[a * 3] + px[b * 3] + px[c * 3]) / 3;
    const cz = (px[a * 3 + 2] + px[b * 3 + 2] + px[c * 3 + 2]) / 3;
    const col = Math.min(cols - 1, Math.max(0, Math.floor((cx - bb.min.x) / spanX)));
    const row = Math.min(rows - 1, Math.max(0, Math.floor((cz - bb.min.z) / spanZ)));
    const key = row * cols + col;
    let bucket = buckets.get(key);
    if (!bucket) { bucket = []; buckets.set(key, bucket); }
    bucket.push(a, b, c);
  }
  if (buckets.size < 2) return null;

  // THE SLIVERS COME OUT FIRST (T-1595). A bucket under GROUND_TILE_MIN_TRIS
  // is the apron, not the ground, and it is folded into one remainder bucket
  // before any mesh is built — so the merge costs a pass over the keys rather
  // than a second copy of any vertex. The remainder keeps the key `thin` so it
  // is nameable in a probe, and it is left out of the sort above precisely
  // because it belongs to no cell.
  const thin = [];
  for (const [key, verts] of [...buckets.entries()]) {
    if (verts.length / 3 >= GROUND_TILE_MIN_TRIS) continue;
    for (const v of verts) thin.push(v);
    buckets.delete(key);
  }
  // A ground whose every cell is thin is a ground too coarse to tile at all,
  // which is the case the guard above already names — say so the same way
  // rather than returning one mesh that pretends to be a tiling.
  if (buckets.size < 2) return null;

  const names = Object.keys(geo.attributes);
  const tiles = [];
  const built = [...buckets.entries()].sort((x, y) => x[0] - y[0]);
  if (thin.length) built.push(['thin', thin]);
  // T-2158: an indexed ground stays indexed in its tiles. Copying three vertices
  // per triangle made each tile about six times the vertices the grid shares —
  // 98 MB of ground, held once in the page and again on the GPU, which is what a
  // phone ran out of. A tile's corners are the source's own vertices, renumbered,
  // so every triangle reads exactly the values it read before.
  const local = index ? new Int32Array(pos.count).fill(-1) : null;
  for (const [key, verts] of built) {
    const tileGeo = new THREE.BufferGeometry();
    let picks = verts;
    if (local) {
      picks = [];
      const tileIndex = new Uint32Array(verts.length);
      for (let i = 0; i < verts.length; i++) {
        const v = verts[i];
        if (local[v] < 0) { local[v] = picks.length; picks.push(v); }
        tileIndex[i] = local[v];
      }
      for (const v of picks) local[v] = -1;
      tileGeo.setIndex(new THREE.BufferAttribute(
        picks.length <= 65535 ? Uint16Array.from(tileIndex) : tileIndex, 1));
    }
    for (const name of names) {
      const src = geo.attributes[name];
      const size = src.itemSize;
      const out = new Float32Array(picks.length * size);
      for (let i = 0; i < picks.length; i++) {
        const v = picks[i];
        for (let k = 0; k < size; k++) out[i * size + k] = src.array[v * size + k];
      }
      tileGeo.setAttribute(name, new THREE.BufferAttribute(out, size));
    }
    tileGeo.computeBoundingSphere();
    const tile = new THREE.Mesh(tileGeo, mesh.material);
    tile.name = `${mesh.name || 'terrain'}__t${key}`;
    tile.receiveShadow = mesh.receiveShadow;
    tile.castShadow = mesh.castShadow;
    tile.frustumCulled = true;
    tiles.push(tile);
  }
  // Reported rather than swallowed, the way the far merge's state is: `built`
  // is how many meshes the grid actually came to and `thinTriangles` how many
  // the remainder holds, so `?debug=1` and the measurement harness can see the
  // coalescing happen instead of reading a tile count that no longer matches
  // cols x rows (T-1595).
  lastGroundTiling.built = tiles.length;
  lastGroundTiling.thinTriangles = thin.length / 3;
  return tiles;
}

/**
 * A plain float copy of an attribute, whatever it was stored as.
 *
 * This is not tidiness. It is the fix for the bug that made the whole town
 * knee-high, twice, and it belongs anywhere geometry is transformed after it is
 * loaded.
 *
 * Under `KHR_mesh_quantization` a POSITION arrives as a *normalized*
 * `Int16Array`: the stored integer divided by 32767, so the attribute can only
 * represent values in [-1, 1], and the real metres come from the node's
 * dequantisation scale — 6.25 on the Sauganash. `BufferAttribute.applyMatrix4`
 * reads denormalised floats, transforms them, and writes the result *back into
 * the same normalized Int16Array*. So the moment the dequantisation matrix is
 * applied, every coordinate past one metre is clamped to 1: a twelve-metre
 * tavern becomes a two-metre box, and because the clamp is per-axis and the
 * building is not centred, its parts are pulled apart on the way.
 *
 * That single write-back is what both of this project's scale regressions were.
 * Discarding the node transform gave two-metre buildings; applying it gave
 * two-metre buildings in pieces. Float first, transform second — the quantised
 * form has already done its job by the time the bytes are off the wire.
 *
 * The terrain GLBs are float today, so this is prevention there rather than
 * repair; the day the bake starts compressing them, the ground would collapse
 * the same way and look like a flood, which is exactly how it read the first
 * time.
 */
export function toFloatAttribute(attr, itemSize = attr.itemSize) {
  const out = new Float32Array(attr.count * itemSize);
  const read = [attr.getX, attr.getY, attr.getZ, attr.getW];
  for (let i = 0; i < attr.count; i += 1) {
    for (let k = 0; k < itemSize; k += 1) out[i * itemSize + k] = read[k].call(attr, i);
  }
  return new THREE.BufferAttribute(out, itemSize);
}

/** Every attribute of a geometry in plain float form, ready to be transformed. */
export function dequantizeGeometry(geo) {
  for (const [name, attr] of Object.entries(geo.attributes)) {
    if (attr.normalized || !(attr.array instanceof Float32Array)) {
      geo.setAttribute(name, toFloatAttribute(attr));
    }
  }
  return geo;
}

/* -------------------------------------------------------------------------- */
/* THE GROUND, PREBUILT (T-2693)                                               */
/* -------------------------------------------------------------------------- */

/**
 * T-2693, the second piece of T-2678. The 1835 ground's load, conform, tiling and
 * partition cost 3.0 s of the terrain phase at the phone profile (T-2692's
 * measurement), with the same answer for every visitor. `tools/publish.sh` runs
 * this file's own loadGlbMesh, conformGroundToField and tileGround, and
 * spatial-batch.js's spatialPieces, in Node (`tools/prebuild_layers.mjs --layer
 * ground`, byte-equal to the page's batches since T-2692) and writes
 * `data/prebuilt/<year>/ground.{json,bin.gz}`: every tile's 40 m pieces. The page
 * then has only to batch them (`batchPieces`), and does not fetch the ground GLB.
 * The trade is bytes for CPU: the published GLB is meshopt-packed, 1.3 MB on the
 * wire, and the prebuild is 10.8 MB, so the first visit carries about 9 MB more
 * for about 2.6 s less terrain at the phone profile (docs/SITE-BUDGET.md § 4g).
 *
 * WHEN IT IS USED. Only when every one of these holds; otherwise the ground is
 * loaded and cut in the browser exactly as before (the source tree always is):
 *   - the page carries a build stamp and the prebuild was written by the same
 *     publish (`index.build`), so the GLB and the code that cut it are the
 *     page's own — the GLB is the one input the page does not read itself;
 *   - it is this scene's (`index.year`), and the scene lays no 1904 context
 *     coast, which rewrites the ground after loading and is never prebuilt;
 *   - the heightfield.json and heightfield.bin this page fetched hash (SHA-256)
 *     to what the index lists for them, and the GLB the heightfield names is the
 *     one the index was built from: the field it was conformed to is this one;
 *   - the buffer is the length the index says;
 *   - the visitor has not asked to save data and the browser does not rate the
 *     connection 3G or slower (`navigator.connection`, where there is one).
 * `tools/check_published.mjs` refuses a published prebuild whose inputs have
 * moved, so the page's check is the second line, as it is for the frontage.
 */
export const PREBUILT_GROUND_FORMAT = 1;

/**
 * Fetch `data/prebuilt/<year>/ground.{json,bin}`, or say why not. Started by
 * main.js before the scene phase, so the download runs under it. Resolves
 * `{ index, bin }` or `{ why }`; it never rejects.
 */
export async function fetchPrebuiltGround({ dataBase, year, build }) {
  return fetchPrebuiltPieces({ dataBase, year, build, layer: 'ground', format: PREBUILT_GROUND_FORMAT,
    own: 'cuts its own ground', instead: 'loads the 1.3 MB ground GLB instead' });
}

/**
 * `data/prebuilt/<year>/<layer>.{json,bin}`, inflated and held to its index's
 * format, build and length: the ground's fetch, shared with the distant base's
 * (T-2709). Resolves `{ index, bin }` or `{ why }`; it never rejects.
 */
async function fetchPrebuiltPieces({ dataBase, year, build, layer, format, own, instead }) {
  if (!dataBase || !year) return { why: `no scene year to fetch a ${layer} for` };
  if (!build) return { why: `this page carries no build stamp, so it ${own} (the source tree)` };
  // The prebuild is about 10 MB on the wire against the ground GLB's 1.3 MB: a
  // trade of bytes for the phone's CPU, which a visitor asking to save data, or on
  // a connection the browser rates 3G or slower, is better off not making.
  const link = globalThis.navigator?.connection;
  if (link?.saveData || /(^|-)(2g|3g)$/.test(link?.effectiveType ?? '')) {
    return { why: `a ${link.saveData ? 'data-saving' : link.effectiveType} connection ${instead}` };
  }
  // Ask only for what publish wrote (prebuilt-index.js): it prebuilds the scenes that
  // draw a frontage, and a request for any other year's layer was a 404 on every boot.
  // Imported here, not at the top: the node harnesses that load this file as a data:
  // URL never reach the fetch, as with jobs/pool.js below.
  const { prebuiltAbsent } = await import('./prebuilt-index.js');
  const absent = await prebuiltAbsent({ dataBase, year, build, layer });
  if (absent) return { why: `${absent}, so the page ${own}` };
  const base = new URL(`prebuilt/${year}/`, dataBase);
  try {
    const res = await fetch(new URL(`${layer}.json`, base));
    if (!res.ok) return { why: `no prebuilt ${layer} (${res.status})` };
    const index = await res.json();
    if (index.format !== format) {
      return { why: `prebuilt ${layer} format ${index.format}, this page reads ${format}` };
    }
    if (index.build !== build) return { why: `prebuilt by build ${index.build}, this page is build ${build}` };
    const binRes = await fetch(new URL(index.bin, base));
    if (!binRes.ok) return { why: `no prebuilt ${layer} buffer (${binRes.status})` };
    let bin = await binRes.arrayBuffer();
    // Gzipped twice on disk (prebuild_layers.mjs); a server that sent it with
    // Content-Encoding has inflated the outer pass, so read the magic bytes.
    const head = new Uint8Array(bin, 0, Math.min(2, bin.byteLength));
    if (index.encoding === 'gzip' && head[0] === 0x1f && head[1] === 0x8b) {
      if (typeof DecompressionStream !== 'function') return { why: `this browser cannot inflate the prebuilt ${layer}` };
      // On a pool worker, as the frontage's is (jobs/inflate-kernel.js). Imported
      // here: the Node harnesses that load this file never reach it.
      const { runJob } = await import('./jobs/pool.js');
      const { bytes } = await runJob('inflateGzip', { bytes: new Uint8Array(bin), passes: index.passes ?? 1 },
        { transfer: [bin] });
      bin = bytes.byteOffset === 0 && bytes.byteLength === bytes.buffer.byteLength
        ? bytes.buffer : bytes.slice().buffer;
    }
    if (bin.byteLength !== index.bytes) {
      return { why: `prebuilt ${layer} buffer is ${bin.byteLength} bytes, its index says ${index.bytes}` };
    }
    return { index, bin };
  } catch (err) {
    return { why: `prebuilt ${layer} did not load: ${err.message}` };
  }
}

async function sha256Hex(bytes) {
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  return Array.from(digest, (b) => b.toString(16).padStart(2, '0')).join('');
}

/** Why `offered` may not stand for this page's ground, or null when it may. */
async function prebuiltGroundRefusal(offered, { sceneId, epochId, meta, metaBytes, binBytes, groundPath, field = null }) {
  const why = await prebuiltRefusal(offered, { sceneId, epochId, meta, metaBytes, binBytes, field });
  if (why) return why;
  if (!offered.index.inputs.files.some((f) => f.path === `assets/${groundPath}`)) {
    return `built from another ground GLB than ${groundPath}`;
  }
  return null;
}

/**
 * Why `offered` (the ground's tiles or the distant base's pieces) may not stand
 * for this page's, or null when it may: this scene's, and built against the
 * heightfield this page fetched, by hash. The build stamp has already been held
 * to the page's (fetchPrebuiltPieces).
 */
async function prebuiltRefusal(offered, { sceneId, epochId, meta, metaBytes, binBytes, field = null }) {
  const { index } = offered;
  if (!index) return offered.why ?? 'none offered';
  if (String(index.year) !== String(sceneId)) return `prebuilt for ${index.year}, this scene is ${sceneId}`;
  if (String(sceneId) === '1904') return 'the 1904 context coast rewrites the ground after loading';
  if (!metaBytes || !binBytes) return 'no heightfield was read, so there is nothing to hold it to';
  if (!globalThis.crypto?.subtle) return 'this page cannot hash what it read (no SubtleCrypto)';
  const dir = `data/terrain/epochs/${epochId}/`;
  const listed = new Map(index.inputs.files.map((f) => [f.path, f.sha256]));
  const read = [[`${dir}heightfield.json`, metaBytes], [`${dir}${meta.bin}`, binBytes]];
  for (const [file, bytes] of read) {
    const sha256 = await sha256Hex(bytes);
    // T-2710: kept, so the streets' prebuild is held to the field this page read.
    if (field) field[file] = sha256;
    if (listed.get(file) !== sha256) return `built from another heightfield (${file})`;
  }
  return null;
}

/**
 * A prebuilt tile's pieces, each `[[offset, byteLength] per attribute, [indexType,
 * offset, byteLength] | null]`. The ground lists them so. T-2709: the distant
 * base's 7,503 pieces would make that list 0.54 MB of index, so its tile carries
 * `at` (where its first array lies) and `counts` (each piece's vertex and index
 * count, -1 for none) instead, and the spans follow from the packer's own rule:
 * every array 4-byte aligned, a piece's attributes then its index, in order, and
 * the index 16-bit unless a local index reaches 65535 (jobs/spatial-kernel.js).
 * tools/prebuild_layers.mjs replays through this function and refuses to write a
 * tile it does not reproduce.
 */
export function prebuiltPieceSpans(t) {
  if (!t.counts) return t.pieces;
  const spans = [];
  let offset = t.at;
  const take = (byteLength) => {
    offset += (4 - (offset % 4)) % 4;
    const at = offset;
    offset += byteLength;
    return [at, byteLength];
  };
  for (let i = 0; i < t.counts.length; i += 2) {
    const vertices = t.counts[i];
    const indices = t.counts[i + 1];
    const arrays = t.attributes.map((a) => take(vertices * a.itemSize * globalThis[a.type].BYTES_PER_ELEMENT));
    const type = vertices - 1 >= 65535 ? 'Uint32Array' : 'Uint16Array';
    spans.push([arrays, indices < 0 ? null : [type, ...take(indices * globalThis[type].BYTES_PER_ELEMENT)]]);
  }
  return spans;
}

/** The prebuild's tiles: each tile's pieces batched, the thin remainder as itself. */
function prebuiltGroundTiles(index, bin, material) {
  const view = (type, offset, byteLength) => new globalThis[type](bin, offset,
    byteLength / globalThis[type].BYTES_PER_ELEMENT);
  const geometry = (t, [arrays, ix], own) => {
    const geo = new THREE.BufferGeometry();
    // A batch copies its pieces' arrays; the thin tile is drawn from its own, so
    // it takes copies and the 27 MB buffer can go once the batches are made.
    const read = (type, offset, byteLength) => (own ? view(type, offset, byteLength).slice()
      : view(type, offset, byteLength));
    if (ix) geo.setIndex(new THREE.BufferAttribute(read(...ix), 1));
    t.attributes.forEach((a, i) => {
      geo.setAttribute(a.name, new THREE.BufferAttribute(read(a.type, ...arrays[i]), a.itemSize, a.normalized));
    });
    return geo;
  };
  return index.tiles.map((t) => {
    const pieces = prebuiltPieceSpans(t);
    let mesh;
    if (t.thin) {
      const geo = geometry(t, pieces[0], true);
      geo.computeBoundingSphere();
      mesh = new THREE.Mesh(geo, material);
      mesh.frustumCulled = true;
    } else {
      mesh = batchPieces(pieces.map((p) => geometry(t, p, false)), material);
    }
    mesh.name = t.name;
    mesh.receiveShadow = true;
    mesh.castShadow = false;
    return mesh;
  });
}

/* -------------------------------------------------------------------------- */
/* THE DISTANT BASE, PREBUILT (T-2709)                                         */
/* -------------------------------------------------------------------------- */

/**
 * T-2709, the first piece of T-2705. The distant base is the field gridded every
 * GROUND_BASE_STEP metres, laid again over frontage's crossing footprints
 * (protectGroundUnder) and cut into 40 m pieces (batchDistantGround): 0.8 s of
 * boot at the phone profile (T-2703's reading), the same for every visitor.
 * `tools/publish.sh` runs distantBaseGeometry and spatialPieces in Node over the
 * footprints the Node frontage build publishes (`tools/prebuild_layers.mjs
 * --layer base`, byte-equal to the page's batch since T-2703) and writes
 * `data/prebuilt/<year>/base.{json,bin.gz}`. createTerrain batches those pieces
 * in place of the bare grid, so neither the grid, the protected grid nor the cut
 * is made here.
 *
 * WHEN IT IS USED: every condition the prebuilt ground is held to (the build
 * stamp, the scene, the heightfield by hash, the buffer's length, no data-saving
 * or 3G connection), and one of its own. The base is laid over the footprints
 * frontage publishes, and frontage is built after the terrain, so the file
 * carries `footprints_key` (footprintsKey, below) and protectGroundUnder holds
 * the footprints it is handed to it. If they differ it lays and cuts its own
 * base, as it would on a second publication, and `prebuiltBase.why` says so.
 */
export const PREBUILT_BASE_FORMAT = 2;

/** `fetchPrebuiltGround` for the distant base. Resolves `{ index, bin }` or `{ why }`. */
export function fetchPrebuiltBase({ dataBase, year, build }) {
  return fetchPrebuiltPieces({ dataBase, year, build, layer: 'base', format: PREBUILT_BASE_FORMAT,
    own: 'lays its own distant base', instead: 'lays the distant base in the browser instead' });
}

/** The crossing footprints a base was laid over, as one FNV-1a word of their JSON:
 *  what the Node build writes and protectGroundUnder compares. */
export function footprintsKey(footprints = []) {
  const text = JSON.stringify(footprints);
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 0x01000193);
  return `${(h >>> 0).toString(16).padStart(8, '0')}:${footprints.length}`;
}

/** Load a GLB and hand back its first mesh, detached from the loaded scene.
 *  Exported for tools/prebuild_layers.mjs (T-2692): the ground built in Node is
 *  read through this loader, not a copy of it. */
export async function loadGlbMesh(url) {
  const buffer = await (await fetchOk(url)).arrayBuffer();
  const loader = registerKTX2(new GLTFLoader());
  // THE GROUND AND THE RIVER ARE COMPRESSED TOO, and this loader is not the one
  // scene-loader.js configures for the buildings.
  //
  // It went unnoticed because it was true and harmless for months: the terrain
  // GLBs were the only assets gltf-transform had never been run over, so a bare
  // loader could read them. The moment they were rebaked they came back
  // meshopt-compressed, this loader threw `setMeshoptDecoder must be called
  // before loading compressed files`, and both meshes fell back — the ground to
  // a grid rebuilt from the heightfield, which looks perfectly right, and the
  // WATER to a flat 2400 m square laid over the whole town. The river vanished
  // and the town read as flooded, which is exactly what a visitor reported.
  //
  // The decoder is shared with scene-loader's, so there is one instance and one
  // place that decides how compressed assets are read.
  loader.setMeshoptDecoder(await loadMeshoptDecoder());
  const gltf = await new Promise((resolve, reject) => {
    loader.parse(buffer, String(url), resolve, reject);
  });
  let found = null;
  gltf.scene.traverse((o) => { if (!found && o.isMesh) found = o; });
  if (!found) throw new Error('no mesh in the GLB');
  // BAKE the node transform into the geometry before flattening it. Resetting
  // position/rotation/scale to identity is the right normalisation for an
  // AUTHORED transform and catastrophic for an ENCODED one: under
  // `KHR_mesh_quantization` the dequantisation lives on the node as a scale and
  // a translation, so discarding it collapses the ground to a fraction of its
  // size and drops it under the water plane. Applying it first keeps the mesh
  // exactly where the file says while still handing back something at identity.
  found.updateWorldMatrix(true, false);
  // Float BEFORE the transform: a normalized integer attribute cannot hold a
  // metre, so applying the matrix into one clamps the mesh to a 2 m cube. See
  // toFloatAttribute above.
  found.geometry = dequantizeGeometry(found.geometry.clone());
  found.geometry.applyMatrix4(found.matrixWorld);
  found.removeFromParent();
  found.position.set(0, 0, 0);
  found.rotation.set(0, 0, 0);
  found.scale.set(1, 1, 1);
  found.updateMatrix();
  return found;
}

/**
 * The apron's termination reading, as one array per edge indexed the way the
 * boundary is.
 *
 * `heightfield.json` publishes it as runs — the sand bar is 34 consecutive
 * columns of the south edge — because that is how the generator found it and a
 * run states which landform it belongs to. A per-vertex loop wants a lookup, so
 * it is widened once here rather than searched 300,000 times. Where two runs
 * overlap (two landforms truncated at the same vertex, which no epoch has yet)
 * the shorter taper wins, matching the generator's own corner rule.
 *
 * @returns {{[edge: string]: {extent: Float32Array, baseY: Float32Array}}|null}
 *          null when the epoch truncates no landform, which is the mesh the
 *          skirt has always been.
 */
function skirtTerminations(hf) {
  const runs = hf?.meta?.skirt?.terminations;
  if (!runs) return null;
  const out = {};
  for (const [edge, list] of Object.entries(runs)) {
    if (!list?.length) continue;
    const count = (edge === 'south' || edge === 'north') ? hf.cols : hf.rows;
    const extent = new Float32Array(count);
    const baseY = new Float32Array(count);
    for (const run of list) {
      for (let k = 0; k < run.extent_m.length; k += 1) {
        const i = run.index0 + k;
        if (i < 0 || i >= count) continue;
        if (extent[i] > 0 && extent[i] <= run.extent_m[k]) continue;
        extent[i] = run.extent_m[k];
        baseY[i] = run.base_y[k];
      }
    }
    out[edge] = { extent, baseY };
  }
  return Object.keys(out).length ? out : null;
}

/**
 * Put the ground mesh's heights back on the heightfield the town is anchored to.
 *
 * THE MESH THAT SHIPS IS NOT THE MESH THE GENERATOR CHECKED. `terrain_gen.py`
 * ray-casts its decimated ground against the heightfield and refuses to export
 * past 30 mm, because "the walker's eye is pinned to the heightfield, so it would
 * visibly float or sink" — and the master it exports honours that to **2.5 mm**.
 * The file a browser loads is the derivative written afterwards by
 * `gltf-transform optimize` in `tools/bake.sh`, which quantises POSITION under
 * ONE UNIFORM node scale. That scale is set by the widest axis, and this mesh is
 * 5,120 m wide (a 2,020 m box plus 1.55 km of skirt) and 9.0 m tall, so at the
 * 14 bits it once shipped at the vertical lattice was **306 mm**. Measured on
 * those bytes by `tools/measure_terrain_fit.mjs`: rms 85 mm, max 228 mm. No
 * setting fixed it — 16 bits, which it ships at now, is the maximum the format
 * offers and still lands on 78 mm.
 *
 * That is the whole of R-BUG3c. The road is drawn 22 mm above the sampler
 * (`LIFT_M`) onto ground the compressor lifted by up to 228 mm, so near the
 * camera — where depth resolution is finest and the polygon offset cannot save it
 * — the roadway, the grass tufts and every rooted plant are simply underneath the
 * ground, at a constant radius, with the clean horizontal edge the owner
 * photographed twice.
 *
 * So the heights are read back off the field at load. Not a correction factor and
 * not a fudge: the heightfield is already the authority for collision, for
 * building anchoring, for flora roots and for street drape, and this makes the
 * surface a visitor SEES the same surface, by construction rather than by
 * tolerance. What the GLB is still trusted for is everything the field cannot
 * carry — the decimated topology, the normals, and the `_CONFIDENCE` channel the
 * ground dithers under.
 *
 * The skirt is carried, not flattened. It lies outside the modelled box, where
 * `sample()` returns its fallback rather than clamping, and snapping it to that
 * would drop 1.55 km of apron onto the water plane. Sampling at the clamped
 * position instead reproduces the generator's own rule for it — "carry each
 * boundary vertex outward, keeping its own height" — so the seam at the box edge
 * closes exactly.
 *
 * EXCEPT WHERE THE BOUNDARY IS A SECTION OF SOMETHING THAT ENDS (T-0939).
 * Carrying is right for ground that continues past the box, and the mainland's
 * does — its traced shore runs stop at the edge of the tracing window, which is
 * where the reading stopped and not where the land did. It is wrong for a
 * landform the box has CUT: the 1834 sand bar left the south edge at a constant
 * +1.21 m and was extruded 1.55 km south as a straight ribbon, three and a half
 * times longer than the 660 m island it is a section of, running to the haze
 * without a taper or an end. The only evidence that can say a landform ends is a
 * closed traced outline the box truncates, so `generators/terrain_gen.py`
 * publishes that reading into `heightfield.json` — per boundary vertex, how far
 * out its landform actually reaches (`extent_m`, off the ring) and the height of
 * the water it stands in (`base_y`). Here the ground falls from the boundary
 * height to `base_y` across `extent_m` and holds it beyond, which is the same
 * arithmetic the generator placed its vertices with. The factor is 1.0 at zero
 * outward distance, so the seam still closes exactly, and an epoch whose spec
 * truncates no landform publishes no terminations and is conformed exactly as
 * before.
 *
 * WHY READING BACK ONLY Y IS ENOUGH, WHICH IT WAS NOT UNTIL 2026-08-23. A height
 * is read at the vertex's SHIPPED (E, N), so a vertex the quantiser moved in
 * plan gets the field's answer for the wrong place — and the cost of that is
 * (slope × displacement), which is nothing on decimated prairie and was 77 mm on
 * the 60-90 % bank faces the east extension brought in, against the 22 mm the
 * road ribbon is lifted by. The repair is on the generator's side of the bake and
 * it removes the displacement rather than correcting it: `terrain_gen.py`
 * DERIVES the skirt margin so the quantiser's uniform scale makes its POSITION
 * rung an exact submultiple of the 2.5 m terrain grid (78.125 mm, the grid cell
 * over 32), which puts every ground vertex on a rung, so quantising rounds each
 * one to itself. Measured on the shipped bytes by
 * `tools/measure_terrain_horizontal.mjs --gate`, which `tools/check.sh` runs:
 * plan movement **0.0 mm**, and the drawn surface within 6.7 mm of the field at
 * all 259,689 of its sample points — the master's own decimation error, with the
 * compressor contributing nothing. See T-0152.
 *
 * @returns {{vertices: number, moved: number, correction_max_m: number,
 *            residual_max_m: number}|null} null when there is no field to conform to
 */
export function conformGroundToField(geometry, hf) {
  if (!hf?.loaded) return null;
  const pos = geometry.attributes.position;
  const eMin = hf.originE;
  const eMax = hf.originE + hf.widthM;
  const nMin = hf.originN;
  const nMax = hf.originN + hf.depthM;
  const term = skirtTerminations(hf);
  let moved = 0;
  let worst = 0;
  for (let i = 0; i < pos.count; i += 1) {
    // glTF is Y-up with +Z south, so ENU north is -z. Clamped into the box: see
    // the skirt note above.
    const outE = pos.getX(i);
    const outN = -pos.getZ(i);
    const e = Math.min(eMax, Math.max(eMin, outE));
    const n = Math.min(nMax, Math.max(nMin, outN));
    let y = hf.sample(e, n);
    if (term) {
      // How far this vertex stands outside each edge, and where along that edge
      // it sits. A corner is outside two of them; the deepest taper wins, which
      // is the landform that has ended by the furthest margin.
      const col = Math.round((e - eMin) / hf.cellM);
      const row = Math.round((n - nMin) / hf.cellM);
      let f = 0;
      let base = 0;
      const take = (side, idx, d) => {
        const t = term[side];
        if (!t || d <= 0 || idx < 0 || idx >= t.extent.length) return;
        const extent = t.extent[idx];
        if (!(extent > 0)) return;
        const g = Math.min(1, d / extent);
        if (g > f) { f = g; base = t.baseY[idx]; }
      };
      take('south', col, nMin - outN);
      take('north', col, outN - nMax);
      take('west', row, eMin - outE);
      take('east', row, outE - eMax);
      if (f > 0) y += (base - y) * f;
    }
    const d = Math.abs(y - pos.getY(i));
    if (d > 0) {
      moved += 1;
      if (d > worst) worst = d;
    }
    pos.setY(i, y);
  }
  pos.needsUpdate = true;
  // Re-read rather than assume: every vertex inside the box now holds the
  // sampler's own answer, so the residual is zero but for float32 storage —
  // measured at 0.24 µm on the committed ground — and anything larger means this
  // walked the wrong axis. The gate asserts it rather than trusting the loop.
  let residual = 0;
  for (let i = 0; i < pos.count; i += 1) {
    const e = pos.getX(i);
    const n = -pos.getZ(i);
    if (e < eMin || e > eMax || n < nMin || n > nMax) continue;
    residual = Math.max(residual, Math.abs(pos.getY(i) - hf.sample(e, n)));
  }
  return { vertices: pos.count, moved, correction_max_m: worst, residual_max_m: residual };
}

/**
 * Build the ground straight from the heightfield. Used when the baked GLB is
 * missing; identical surface, more triangles, and it means a missing asset
 * degrades to "slower" rather than to "no ground".
 */
/**
 * T-2703. The distant base as protectGroundUnder lays it over frontage's crossing
 * footprints (the same call; tools/check_plank_ground.mjs reads that method's own
 * source, so it calls gridGeometry itself): the geometry batchDistantGround cuts
 * into spatial-batch pieces at boot, and the one tools/prebuild_layers.mjs
 * --layer base cuts in Node, whose --parity read holds the two equal.
 */
export function distantBaseGeometry(hf, footprints = []) {
  return gridGeometry(hf, GROUND_BASE_STEP, footprints);
}

function gridGeometry(hf, step = 1, footprints = []) {
  if (!hf.loaded) {
    const g = new THREE.PlaneGeometry(2400, 2400, 1, 1);
    g.rotateX(-Math.PI / 2);
    g.setAttribute('_confidence',
      new THREE.BufferAttribute(new Float32Array(4).fill(1), 1));
    return g;
  }
  if (step > 1) {
    // Only crossing footprints request finer cells; surrounding coarse cells
    // share their edge samples, so no terrain crack or depth override is needed.
    const mesh = adaptiveGroundGrid(hf, step, 0.025, footprints);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(mesh.position, 3));
    const conf = new Float32Array(mesh.position.length / 3);
    for (let i = 0; i < conf.length; i++) conf[i] = mesh.position[i * 3 + 1] < SHORE_Y ? 1 : 0.5;
    g.setAttribute('_confidence', new THREE.BufferAttribute(conf, 1));
    g.setIndex(new THREE.BufferAttribute(mesh.index, 1));
    g.computeVertexNormals();
    g.userData.adaptiveGround = mesh.stats;
    return g;
  }
  const { cols, rows, cellM, originE, originN } = hf;
  const stride = Math.max(1, Math.floor(step));
  const sampleCols = [];
  const sampleRows = [];
  for (let c = 0; c < cols; c += stride) sampleCols.push(c);
  for (let r = 0; r < rows; r += stride) sampleRows.push(r);
  if (sampleCols.at(-1) !== cols - 1) sampleCols.push(cols - 1);
  if (sampleRows.at(-1) !== rows - 1) sampleRows.push(rows - 1);
  const outCols = sampleCols.length;
  const outRows = sampleRows.length;
  const pos = new Float32Array(outCols * outRows * 3);
  const conf = new Float32Array(outCols * outRows).fill(0.5);
  for (let rr = 0; rr < outRows; rr++) {
    const r = sampleRows[rr];
    for (let cc = 0; cc < outCols; cc++) {
      const c = sampleCols[cc];
      const vi = rr * outCols + cc;
      const i = vi * 3;
      const y = hf.data[r * cols + c];
      pos[i] = originE + c * cellM;
      pos[i + 1] = y;
      pos[i + 2] = -(originN + r * cellM);
      if (y < SHORE_Y) conf[vi] = 1.0;
    }
  }
  const idx = new Uint32Array((outCols - 1) * (outRows - 1) * 6);
  let k = 0;
  for (let r = 0; r < outRows - 1; r++) {
    for (let c = 0; c < outCols - 1; c++) {
      const a = r * outCols + c;
      // Rows run NORTHWARD (row r stands at originN + r·cellM, and the sampler
      // reads gy = (n − originN) / cellM), and world −Z is north, so a step to
      // the next row is a step toward −Z and a step to the next column is +X.
      // Counter-clockwise seen from above is therefore a → a+1 → a+outCols,
      // which puts the face normal UP.
      //
      // IT WAS THE OTHER WAY ROUND UNTIL 2026-09-27, under a comment claiming
      // the opposite, and every face of this mesh pointed DOWN. From above the
      // whole far ground was back-face culled: it drew nothing. Past 600 m the
      // detailed tiles hand the ground to this mesh (GROUND_DETAIL_REACH_M), so
      // everything beyond that ring was a hole, and what showed through it was
      // the datum-level water plane laid under the whole box — hazed to the
      // sky's colour. That is the "flooded" horizon the owner reported from
      // the air three times; T-1631 and T-1635 tuned the haze over it, which
      // is why neither fixed it. Measured by drawing this mesh double-sided at
      // the owner's poses: the holes fill and the far river reads as river.
      idx[k++] = a; idx[k++] = a + 1; idx[k++] = a + outCols;
      idx[k++] = a + 1; idx[k++] = a + outCols + 1; idx[k++] = a + outCols;
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('_confidence', new THREE.BufferAttribute(conf, 1));
  g.setIndex(new THREE.BufferAttribute(idx, 1));
  g.computeVertexNormals();
  return g;
}

/* -------------------------------------------------------------------------- */
/* materials                                                                   */
/* -------------------------------------------------------------------------- */

export const WORLD_POS_VERT = /* glsl */`
  vChiWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;
`;

/**
 * THE SUBSTRATE ZONES — the flora records the ground mesh is allowed to read.
 *
 * `groundMaterial` below documented its own limit and predicted this function:
 * "there is no plant-community record in `data/` for it to read yet ... When
 * those records land, the zone a point falls in belongs here — and the ground
 * stops being one green." The records landed. Every zone in `data/flora` carries
 * `ground.rgb` and `ground.wet_rgb`, and nothing was reading them for the mesh —
 * `data/flora/index.json`'s own `_doc` records the measurement, "ROADMAP K42
 * measured that no renderer file fetches this manifest for the ground at all:
 * terrain.js never opens data/flora." So the beach and the sand bar have been
 * drawn in the prairie's green for as long as they have had ground under them,
 * and the 2026-08-11 priority raise on z08/z09 could never have moved it:
 * priority decides which community PLANTS, and the mesh was not asking.
 *
 * ONLY BOX EXTENTS, AND THE REASON IS THE FRAGMENT SHADER. A zone's extent is a
 * box, a polygon, a water buffer or an elevation band. A box is the only one of
 * the four a per-fragment test evaluates exactly and in a handful of
 * instructions, and this shader runs over most of the screen — the file's own
 * one-texture-fetch rule is the same budget. The elevation bands are already
 * what the procedural path paints, keyed on the same height. THE LIMIT THIS
 * LEAVES, written down rather than discovered later: where a higher-priority
 * polygon or buffer zone overlaps a box — z04_marsh (70) reaches 8 m inland of
 * every waterline, including the beach inside z08 — the sward plants the marsh
 * and the mesh still shows the sand. That ground is a strip a few metres wide at
 * the harbour mouth; carrying the other three extent kinds is a separate piece
 * of work and not a silent omission.
 *
 * Read off the manifest rather than the ten zone records: the manifest
 * denormalises `extent`, `priority`, `ground_rgb`, `ground_wet_rgb` and
 * `plantable_in_scene`, and `tools/validate.py` fails the build if a copy
 * disagrees with the record it came from. One fetch, gated.
 *
 * Degrades to today's behaviour: no manifest, no zones, and the ground is the
 * prairie everywhere, with the problem recorded.
 */
async function substrateZones(dataBase, problems, sceneId = null) {
  if (!dataBase) return [];
  let index = null;
  try {
    index = await (await fetchOk(new URL('flora/index.json', dataBase))).json();
  } catch (err) {
    problems.push(`terrain: no flora manifest (${err.message}) — the ground is `
      + 'the prairie tile everywhere, including the sand belt and the bar');
    return [];
  }
  const out = [];
  for (const z of index.zones || []) {
    // A box, or since T-1819 a band measured from the lake's edge
    // (`kind: "lake_shore"`, lakeshore.js) — the two extents a fragment can
    // evaluate in a handful of instructions.
    const shore = z.extent?.kind === 'lake_shore';
    const box = z.extent?.kind === 'everywhere' || shore ? z.extent.box : null;
    if (!box && !shore) continue;
    // A community the scene does not plant does not paint the ground it does not
    // stand on either. z07_bur_oak_savanna is the one, 5.6 km SSW of the forks.
    if (z.plantable_in_scene === false) continue;
    // Nor does a zone scoped to another scene (T-0471).
    if (!floraInScene(z, sceneId)) continue;
    if (!Array.isArray(z.ground_rgb) || !Array.isArray(z.ground_wet_rgb)) {
      problems.push(`terrain: flora zone ${z.id} has a box extent but records no `
        + 'ground colour — the mesh leaves it as prairie');
      continue;
    }
    out.push({
      id: z.id,
      priority: z.extent?.priority ?? z.priority ?? 0,
      e0: box?.e?.[0], e1: box?.e?.[1], n0: box?.n?.[0], n1: box?.n?.[1],
      extent: z.extent,
      // The records state sRGB 0-255; the shader works in the renderer's linear
      // space and `chiTex` arrives there already (the tile is SRGBColorSpace).
      // Converted explicitly rather than by a string parse, so the colour space
      // of a recorded triple is visible at the place it is read.
      dry: new THREE.Color().setRGB(...z.ground_rgb.map((v) => v / 255), THREE.SRGBColorSpace),
      wet: new THREE.Color().setRGB(...z.ground_wet_rgb.map((v) => v / 255), THREE.SRGBColorSpace),
    });
  }
  // Ascending, so the shader mixes the higher-priority zone in last and it wins
  // where two boxes overlap — the same order the sward resolves them in.
  out.sort((a, b) => a.priority - b.priority);
  return out;
}

/**
 * How far a zone's declared colour reaches past its own box edge, metres.
 *
 * Not zero, and the zone records say why: "No survey drew these lines" (z01),
 * "It is a reading of the terrain, not evidence, and a critic should treat the
 * line as ours" (z02), "The north-south bounds are the scene's own, not the
 * belt's" (z08, z09). A hard edge on the mesh would draw those admissions as a
 * surveyed boundary. The width is the terrain spec's own transition: z09's note
 * places the State Street break-of-slope band "between E +780 and +880", a 100 m
 * ramp whose midpoint is 830 — ten metres off this zone's own west edge at 840.
 * So the ramp across a box edge is that band's width, and at the one edge where
 * the sand meets the prairie it lands on the break of slope the terrain already
 * builds there.
 */
const ZONE_EDGE_RAMP_M = 50;

/**
 * Whether a substrate zone's ground is SWARD (T-2089) — grass standing on it, so
 * it takes the grass grain's tone and relief like the prairie it replaces — or
 * bare ground that does not. The lake shore is the one bare zone: its record is
 * a beach, and blades printed on sand would be a lawn on the strand. The sand
 * prairie keeps the grain; it is grassland on a sand soil. Reconstructed (L-entry
 * in docs/LIBERTIES.md): no record states a zone's surface relief.
 */
function zoneIsSward(z) {
  return z.extent?.kind !== 'lake_shore';
}
const swardTone = (z) => (zoneIsSward(z) ? ' * chiSwardTone' : '');
const swardOff = (z) => (zoneIsSward(z) ? '' : '\n    chiSwardW *= 1.0 - w;');

/**
 * The substrate zones as fragment code, generated from the records at material
 * build time rather than carried as uniforms.
 *
 * Ten zones is a scene constant, and the ones with box extents are two. Baking
 * them into the source costs the frame four smoothsteps per zone and no uniform
 * fetch, and — the reason that matters here — it costs EXACTLY NOTHING when
 * there are none: this returns an empty string, the prairie statements above are
 * the whole function, and the compiled shader is the one this file shipped
 * before the zones were read.
 *
 * WHAT A ZONE IS ALLOWED TO CHANGE. Its `ground.rgb` and `ground.wet_rgb`, and
 * nothing else. The grain is the prairie tile's, taken as LUMINANCE and divided
 * by the tile's own mean, so the sand carries the same texture relief at the
 * same relative strength and none of the tile's hue: a beach is mottled in tone,
 * not in colour, and the tile's khaki thatch is a prairie's dead litter. Because
 * the divisor is the tile's measured mean, the mean albedo inside a zone is the
 * recorded triple itself — the record is not scaled, tinted or approached, it is
 * what the ground averages.
 *
 * The patch tone (`chiPatch`, the variation map's since T-2552 retired the
 * community mosaic) is deliberately NOT carried onto a zone: it is a statement
 * about prairie stands, not about sand.
 *
 * Clamped at 1.0 because an albedo cannot exceed it — a GUARD, and on the
 * committed records it never binds: the tile's brightest texel is 1.378 times
 * its mean and z08_lakeshore is the brightest zone, which puts the largest
 * product any channel reaches at 0.778. So the clamp costs the picture nothing
 * today and stops a future record whose triple is brighter from turning into a
 * flat white patch instead of an obviously-too-bright one. `tools/
 * measure_ground_albedo.mjs --gate` runs this same arithmetic over the same
 * pixels and holds every zone's mean to within one sRGB unit of its record;
 * it currently reports 0.00 on all four triples.
 */
function zoneGlsl(zones, lakeShore = null) {
  // A shore band with no shore read holds nothing — the same answer
  // lakeshore.js softExtentWeight gives the sward, so neither draws a beach.
  zones = zones.filter((z) => z.extent?.kind !== 'lake_shore' || lakeShore);
  if (!zones.length) return '';
  const F = ZONE_EDGE_RAMP_M.toFixed(1);
  const f = (v) => (Number.isInteger(v) ? v.toFixed(1) : String(v));
  const v3 = (c) => `vec3(${c.r.toFixed(6)}, ${c.g.toFixed(6)}, ${c.b.toFixed(6)})`;
  const blocks = zones.map((z) => (softExtentGlsl(z.extent) ? `
  // ${z.id} — priority ${z.priority}, ${z.extent.kind === 'lake_shore'
    ? `within ${z.extent.distance_m?.[1]} m of the lake's edge` : 'a box with wandering, ramped sides'}
  // (T-1819, lakeshore.js — the rule the sward and the trees also read)
  {
    ${softExtentGlsl(z.extent)}
    vec3 c = mix(${v3(z.dry)}, ${v3(z.wet)}, chiWet);
    chiPrairie = mix(chiPrairie, diffuseColor.rgb * min(vec3(1.0), c * chiGrain${swardTone(z)}), w);${swardOff(z)}
  }` : `
  // ${z.id} — priority ${z.priority}, e ${z.e0}..${z.e1}, n ${z.n0}..${z.n1}
  {
    float w = smoothstep(${f(z.e0 - ZONE_EDGE_RAMP_M)}, ${f(z.e0 + ZONE_EDGE_RAMP_M)}, chiE)
            * (1.0 - smoothstep(${f(z.e1 - ZONE_EDGE_RAMP_M)}, ${f(z.e1 + ZONE_EDGE_RAMP_M)}, chiE))
            * smoothstep(${f(z.n0 - ZONE_EDGE_RAMP_M)}, ${f(z.n0 + ZONE_EDGE_RAMP_M)}, chiN)
            * (1.0 - smoothstep(${f(z.n1 - ZONE_EDGE_RAMP_M)}, ${f(z.n1 + ZONE_EDGE_RAMP_M)}, chiN));
    vec3 c = mix(${v3(z.dry)}, ${v3(z.wet)}, chiWet);
    chiPrairie = mix(chiPrairie, diffuseColor.rgb * min(vec3(1.0), c * chiGrain${swardTone(z)}), w);${swardOff(z)}
  }`)).join('\n');
  return `
  // ---- the substrate zones (${zones.map((z) => z.id).join(', ')}) ---------- //
  // Scene coordinates off world position: the ground is built at x = e and
  // z = -n (see gridGeometry), so this is the same frame the records use.
  float chiE = vChiWorld.x;
  float chiN = -vChiWorld.z;
  // The tile's relief as a scalar, normalised by its own measured mean, so a
  // zone's mean albedo is exactly what its record states. Mixed in ASCENDING
  // priority — the last zone written wins where two boxes overlap, which is the
  // order the sward resolves them in. The edges ramp over ${ZONE_EDGE_RAMP_M} m
  // because no survey drew them; see ZONE_EDGE_RAMP_M.
  float chiGrain = dot(chiTex, vec3(0.2126, 0.7152, 0.0722)) / max(uPrairieLuma, 1e-6);
${blocks}
`;
}

/**
 * THE PRAIRIE, as fragment code — the statements `groundMaterial` splices in place
 * of `<map_fragment>`, lifted out unchanged so a second surface can paint the SAME
 * prairie rather than a copy of it (T-1797: the ground strip feathers into the
 * terrain at its edges, and a copy would drift the first time this one is tuned).
 * The compiled ground shader was byte for byte the one it had been; T-1825 has
 * since moved the fetch below the mosaic, which it borrows to break the tile's
 * repeat (see the comment at the fetch). It expects
 * `varying vec3 vChiWorld` and `uniform sampler2D uGround` (the prairie tile) and
 * leaves `chiTex`, `chiPatch`, `chiWet` and `chiPrairie` declared.
 */
export const PRAIRIE_FRAGMENT = /* glsl */`
  // The prairie's texture budget. The ground covers most of the screen, so
  // every instruction here is paid a million times a frame. The finer octaves
  // are baked INTO the colour tile (see prairieTexture); the sward grain below
  // is the second fetch (T-2089); the variation map is the third (T-2552), and
  // it paid for itself by retiring the three sines that stood where it does.

  // THE VARIATION MAP (T-2552) — lush and thin stands at 16-256 m, a dry lean,
  // the tile's variant index and its lookup shear, one fetch of prairie-macro.js's 512 px map over
  // 3,072 m. It replaces a "community mosaic" that was sin(x) * sin(z) plus one
  // diagonal: an egg-crate of 42 x 48 m cells square to the compass, which is a
  // plaid by construction, and from 1,197 ft up the owner saw exactly that
  // (2026-10-16). The map's repeat is longer than the haze reach, and it is
  // turned 27 degrees off the compass so no residue of its noise lattice lines
  // up with the streets. Every channel is read over its own measured mean, so
  // it moves light and colour around the ground and adds none.
  vec2 chiMacroUV = mat2(0.8910, -0.4540, 0.4540, 0.8910) * vChiWorld.xz / uMacroM;
  vec4 chiMacro = texture2D(uMacro, chiMacroUV) - uMacroMean;
  // chiPatch keeps its old role, sign and spread (MOSAIC_STD), so everything
  // tuned against the mosaic — the tone below, the sward's shear — reads it as
  // it did. Only the regularity is gone.
  float chiPatch = chiMacro.r * uMacroGain;

  // How far the eye is. Walking ground (under 150 m) is drawn as it was; by
  // 600 m the tile has eased a third of the way to its mean and the stands have
  // doubled their say, so from the air the ground is mottled by stands rather
  // than by the tile.
  float chiFar = smoothstep(150.0, 600.0, distance(vChiWorld, cameraPosition));

  // THE COLOUR TILE, WITH ITS REPEAT BROKEN (T-2552). The map's G channel is a
  // variant index, and the tile is drawn from two offsets of itself picked by
  // it (the R2 low-discrepancy sequence, so neighbouring variants never agree
  // and no sine is spent) and cross-faded, the darker texel winning a little
  // early so a seam reads as a clump's edge rather than a dissolve. That is
  // Inigo Quilez's two-fetch repeat break, with one change: the two variants
  // are STAGGERED half a band apart, so each one's offset jumps only where its
  // own weight is exactly zero (A's at a whole band, where wB = 1; B's at a
  // half band, where wB = 0; the darker-texel bias moves the fade by at most
  // 0.079, 0.6 x the tile's measured spread of linear channel means, so it
  // cannot reach either end). A jump does break the implicit derivative of
  // the fetch it lands in, but that fetch is weighted out there, so plain
  // texture2D draws no seam and needs neither explicit gradients nor a branch
  // (both measured slower: textureGrad cost a software frame 30 %, and the
  // branch saved nothing). A band runs about 22 m (measured), so the 11 m lattice that
  // read as rows to the haze, and as a plaid from the air, no longer lines up.
  //
  // The only shear left is the B channel's, along a diagonal and smooth over
  // 100 m and more. T-1825's shear by the mosaic is retired with it: riding on
  // a field with 16 m detail it bent the tile into visible swirls, and the
  // variants now do the job it was doing.
  vec2 chiTileUV = vChiWorld.xz * 0.0909 + vec2(0.7071, 0.7071) * (chiMacro.b * 0.5);
  float chiVk = (chiMacro.g + uMacroMean.g) * 8.0;
  vec2 chiOffA = fract(floor(chiVk) * vec2(0.7548777, 0.5698403));
  vec2 chiOffB = fract((floor(chiVk + 0.5) + 0.5) * vec2(0.7548777, 0.5698403));
  vec3 chiTexA = texture2D(uGround, chiTileUV + chiOffA).rgb;
  vec3 chiTexB = texture2D(uGround, chiTileUV + chiOffB).rgb;
  float chiWB = abs(2.0 * fract(chiVk) - 1.0);
  vec3 chiTex = mix(chiTexA, chiTexB,
    smoothstep(0.3, 0.7, chiWB - 0.6 * dot(chiTexB - chiTexA, vec3(0.3333))));

  // And past ~150 m the tile's own contrast eases toward its measured mean,
  // so the stands carry the ground from the air and the tile is grain within
  // them. A mix toward the mean moves no albedo.
  chiTex = mix(chiTex, uPrairieMean, 0.35 * chiFar);

  // Wet ground: the marshy shore strip, keyed on height above the datum.
  // Dossier zone 11 puts that strip at +0.5 to +2.0 ft and the heightfield puts
  // it at +1.25 ft, so elevation is the honest driver — it paints the mud wide
  // on the low South Division shore and narrow on the higher north and west
  // banks, which is what the sources say. The top of the band is pulled in to
  // 0.70 m so it stops at the foot of the plain (p25 of the land is 0.83 m)
  // instead of tinting it. It keys the SUBSTRATE zones too, between their own
  // two declared colours, so the reading is one rule and not two.
  float chiWet = 1.0 - smoothstep(0.05, 0.70, vChiWorld.y);

  // THE PRAIRIE PATH, arithmetically what it has always been — the three
  // statements below are the previous revision's, moved onto a local so the
  // substrate can be mixed against them. Where no zone covers a fragment the
  // weight is 0.0, and mix(a, b, 0.0) is a exactly, so "nothing outside the
  // zones moves" is a property of the code rather than a claim about a
  // screenshot. (No backticks in here: this is a JS template literal.)
  // The patch tone grows with distance as the tile's contrast eases. The dry lean
  // is zero-mean: yellower here, fresher there, the July mean unmoved.
  vec3 chiPrairie = diffuseColor.rgb * chiTex
                  * (1.0 + mix(0.10, 0.20, chiFar) * chiPatch)
                  * (vec3(1.0) + vec3(0.07, 0.035, -0.13) * mix(1.0, 1.3, chiFar) * chiMacro.a);
  chiPrairie = mix(chiPrairie,
                   chiPrairie * vec3(0.46, 0.42, 0.30) + vec3(0.042, 0.034, 0.020),
                   chiWet);
  // Drier mesic prairie on the rises. A July shift, not a September one: a few
  // per cent lighter and a few per cent less blue, so the crown of the plain
  // reads finer and yellower than the swale beside it and still reads green.
  chiPrairie *= mix(vec3(1.0), vec3(1.05, 1.03, 0.92),
                    smoothstep(0.95, 1.28, vChiWorld.y));

  // THE SWARD'S OWN RELIEF (T-2089) — the road's method, on grass. One more
  // fetch, the grass grain (grass-grain.js: 256 px over 1.6 m, R height, G/B
  // normal), in WORLD space so nothing stretches across the bake's dissolves,
  // and sheared by the mosaic already in hand so its 1.6 m repeat does not
  // line up into rows (T-1825's trick on the colour tile). NO value noise for
  // the clumping: the colour tile in hand already carries the 0.7 m clumps and
  // the 1.4-2.75 m growth patches, so its own luminance decides how strongly
  // each clump shows its blades — lusher, brighter clumps more, thin ground
  // less, at the cost of no instruction a noise would add to the one surface
  // that covers most of the screen. The grain is read over its own
  // measured mean and is independent of the colour tile, so mix(1, grain, k)
  // averages 1.0 whatever k is: a zone's mean albedo is still the triple its
  // record states. The relief is lit through chiSwardXY by whoever owns the
  // normal stage; wet ground carries less of it.
  vec2 chiSwardEN = vec2(vChiWorld.x, -vChiWorld.z);
  vec4 chiSward = texture2D(uSward, chiSwardEN / uSwardM + vec2(0.31, 0.23) * chiPatch);
  float chiSwardGrain = chiSward.r / max(uSwardMean, 1e-6);
  float chiSwardClump = clamp(dot(chiTex, vec3(0.2126, 0.7152, 0.0722))
                              / max(uPrairieLuma, 1e-6) - 0.45, 0.0, 1.0);
  float chiSwardK = mix(0.20, 0.44, chiSwardClump) * (1.0 - 0.55 * chiWet);
  float chiSwardTone = mix(1.0, chiSwardGrain, chiSwardK);
  chiPrairie *= chiSwardTone;
  // How much of the sward a fragment carries: 1 on grass, taken down by any
  // substrate zone that is not sward (zoneGlsl).
  float chiSwardW = 1.0;
  vec2 chiSwardXY = (chiSward.gb * 2.0 - 1.0) * (0.9 - 0.55 * chiWet);
`;

/**
 * What `PRAIRIE_FRAGMENT` needs declared beside `uGround` and `uPrairieLuma`:
 * the grass grain (T-2089) and the variation map (T-2552). Every material that
 * splices the prairie in splices this into its fragment head too, and binds
 * `uSward*` from `swardUniforms()` and `uMacro*` / `uPrairieMean` from
 * `variationUniforms()`.
 */
export const SWARD_HEAD = /* glsl */`
uniform sampler2D uSward;
uniform float uSwardM;
uniform float uSwardMean;
uniform sampler2D uMacro;
uniform float uMacroM;
uniform vec4 uMacroMean;
uniform float uMacroGain;
uniform vec3 uPrairieMean;
`;

/**
 * The sward's relief lit by the sun — the normal stage for a surface that is
 * prairie through and through (the terrain). The ground strip and the worked
 * bank fold `chiSwardXY` into their own normal stages at their prairie weight
 * instead, so the relief runs on across their feathered edges without a seam.
 */
export const SWARD_NORMAL = /* glsl */`
  vec2 chiSwXY = chiSwardXY * chiSwardW;
  vec3 chiSwTn = normalize(vec3(chiSwXY, 1.0));
  vec3 chiSwEastV = normalize((viewMatrix * vec4(1.0, 0.0, 0.0, 0.0)).xyz);
  vec3 chiSwT = normalize(chiSwEastV - normal * dot(chiSwEastV, normal));
  vec3 chiSwB = cross(normal, chiSwT);
  normal = normalize(chiSwT * chiSwTn.x + chiSwB * chiSwTn.y + normal * chiSwTn.z);
`;

/**
 * T-2085 — THE TOWN'S SHORT TURF, painted by the ground instead of planted.
 *
 * The owner, 2026-10-04: "a lower grass ... with some strong textures and be
 * reusable so you don't have to spend much rendering on it". On a community
 * `turf-tile.js` calls turf, `flora.js` keeps only its near tufts and draws no
 * mid or far clump cards; this is what stands in for them. It is the road's
 * method (T-1797/T-1811): one seeded grain-and-normal tile in world space,
 * the coarse scales as value noise, the recorded tones times the grain.
 *
 * WHERE: a mask the SWARD rasterises off its own zone finder and hands over
 * (`setTurf`), so the ground paints turf exactly where the placer has stopped
 * drawing cards — one rule, read once, and no polygon test per fragment. Until
 * it arrives `uTurfBox` is zero and the test below fails before any fetch.
 *
 * WHAT IT COSTS: no draw call, no mesh. Outside the mask's box, two compares.
 * Inside it, two fetches — the mask (unfiltered by mip, so it is safe inside
 * the branch) and the tile, by explicit gradient so the branch cannot spoil its
 * mip choice. The one-fetch rule above is about the prairie, which is most of
 * the screen everywhere; this is paid only on the town's own ground.
 *
 * WHAT IS RECORDED AND WHAT IS NOT: the sod's two greens are the community
 * palette's, the bare ground is the record's ground colour (the manifest's
 * `ground_rgb`), dust its palette's dry glaze, wet ground the manifest's
 * `ground_wet_rgb`, and the share left bare is the record's
 * `bare_soil_fraction`, measured off the very noise drawn here (`bareCut`).
 * The pattern is reconstructed — docs/LIBERTIES.md.
 */
const TURF_HEAD = /* glsl */`
uniform sampler2D uTurfMask;
uniform sampler2D uTurfTile;
uniform vec4 uTurfBox;
uniform vec3 uTurfSodDark;
uniform vec3 uTurfSodLight;
uniform vec3 uTurfBare;
uniform vec3 uTurfDust;
uniform vec3 uTurfWet;
uniform float uTurfCut;
uniform float uTurfTileM;
uniform float uTurfGrainMean;
float chiTurfHash(vec2 p) {
  vec3 q = fract(vec3(p.xyx) * 0.1031);
  q += dot(q, q.yzx + 33.33);
  return fract((q.x + q.y) * q.z);
}
float chiTurfNoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(chiTurfHash(i), chiTurfHash(i + vec2(1.0, 0.0)), u.x),
             mix(chiTurfHash(i + vec2(0.0, 1.0)), chiTurfHash(i + vec2(1.0, 1.0)), u.x), u.y);
}
`;

const TURF_FRAGMENT = /* glsl */`
  // ---- T-2085, the town's short turf (turf-tile.js) ----------------------- //
  vec2 chiTurfEN = vec2(vChiWorld.x, -vChiWorld.z);
  vec2 chiTurfUv = chiTurfEN / uTurfTileM;
  vec2 chiTurfDx = dFdx(chiTurfUv);
  vec2 chiTurfDy = dFdy(chiTurfUv);
  vec2 chiTurfQ = (chiTurfEN - uTurfBox.xy) * uTurfBox.zw;
  float chiTurfW = 0.0;
  vec2 chiTurfSlope = vec2(0.0);
  if (chiTurfQ.x > 0.0 && chiTurfQ.y > 0.0 && chiTurfQ.x < 1.0 && chiTurfQ.y < 1.0) {
    float chiTurfM = textureLod(uTurfMask, chiTurfQ, 0.0).r;
    if (chiTurfM > 0.002) {
      // The mask is the SHARE of the sward the town holds (T-2125: the zone
      // finder blends the edge over about 100 m), so the turf grades across that
      // whole band — broken into 20 m tongues and patches of worn ground and
      // ragged at 3 m — and the town's ground meets the prairie as a margin
      // that thins out, not a contour.
      chiTurfW = smoothstep(0.12, 0.88, chiTurfM
        + 0.30 * (chiTurfNoise(chiTurfEN / 21.0 + 9.4) - 0.5)
        + 0.30 * (chiTurfNoise(chiTurfEN / 3.3 + 5.1) - 0.5));
      // The turf carries its own relief, so the prairie's grass grain (T-2089)
      // gives way to it, as it does inside every zone that is not prairie.
      chiSwardW *= 1.0 - chiTurfW;
      // A 9 m drift shears the 2 m tile against itself: no lattice at 20 m.
      vec2 chiTurfShear = vec2(chiTurfNoise(chiTurfEN / 9.0),
                               chiTurfNoise(chiTurfEN / 9.0 + 13.7)) - 0.5;
      vec4 chiTurfT = textureGrad(uTurfTile, chiTurfUv + 0.6 * chiTurfShear,
                                  chiTurfDx, chiTurfDy);
      float chiTurfG = chiTurfT.r;
      // Sod or bare, at the record's share: 1.7 m patches, 0.62 m edges, a
      // 5.5 m drift (turfSodField), with the grain fraying the patch edge.
      float chiTurfS = 0.55 * chiTurfNoise(chiTurfEN / 1.7)
                     + 0.30 * chiTurfNoise(chiTurfEN / 0.62 + vec2(7.3, 2.9))
                     + 0.15 * chiTurfNoise(chiTurfEN / 5.5 + vec2(3.1, 11.7));
      float chiTurfSod = smoothstep(uTurfCut - 0.05, uTurfCut + 0.05,
                                    chiTurfS + 0.30 * (chiTurfG - uTurfGrainMean));
      // Sod does not stand in the wet band; the soil there is the record's mud.
      chiTurfSod *= 1.0 - chiWet;
      float chiTurfVig = chiTurfNoise(chiTurfEN / 0.9 + 21.0) - 0.5;
      // The palette's darkest green, in the shade between the blades, up to its
      // sunlit third green on a blade tip: the grain decides which, steeply.
      vec3 chiTurfGreen = mix(uTurfSodDark * 0.62, uTurfSodLight,
                              clamp((chiTurfG - 0.22) * 2.1 + 0.30 * chiTurfVig, 0.0, 1.0));
      // Bare ground takes the crumbs and not the blades: a blade stroke in the
      // dirt would read as a scratch.
      vec3 chiTurfSoil = mix(uTurfBare, uTurfDust,
                             smoothstep(0.35, 0.80, chiTurfNoise(chiTurfEN / 3.1 + 40.0)))
                       * (0.74 + 1.1 * min(chiTurfG, 0.32));
      chiTurfSoil = mix(chiTurfSoil, uTurfWet, chiWet);
      vec3 chiTurfC = mix(chiTurfSoil, chiTurfGreen, chiTurfSod);
      chiPrairie = mix(chiPrairie, diffuseColor.rgb * min(vec3(1.0), chiTurfC), chiTurfW);
      chiTurfSlope = (chiTurfT.gb * 2.0 - 1.0) * mix(0.55, 1.0, chiTurfSod) * chiTurfW;
    }
  }
`;

// The tile's relief in a world tangent frame (east, north, up), as the road's
// grit is lit (streets.js ROAD_NORMAL). Weighted to nothing off the turf.
const TURF_NORMAL = /* glsl */`
  if (chiTurfW > 0.0) {
    vec3 chiTurfTn = normalize(vec3(chiTurfSlope, 1.0));
    vec3 chiTurfEastV = normalize((viewMatrix * vec4(1.0, 0.0, 0.0, 0.0)).xyz);
    vec3 chiTurfTt = normalize(chiTurfEastV - normal * dot(chiTurfEastV, normal));
    vec3 chiTurfBt = cross(normal, chiTurfTt);
    normal = normalize(chiTurfTt * chiTurfTn.x + chiTurfBt * chiTurfTn.y + normal * chiTurfTn.z);
  }
`;

/**
 * The turf's shared uniforms and the call that fills them. One object for both
 * ground materials (the tiles and the base), so a hand-over reaches both.
 * Inert until `set`: a 1x1 mask and tile and a zero box.
 */
function turfGround() {
  const blank = (format, bytes) => {
    const t = new THREE.DataTexture(new Uint8Array(bytes), 1, 1, format);
    t.needsUpdate = true;
    return t;
  };
  const placeholders = [blank(THREE.RedFormat, [0]), blank(THREE.RGBAFormat, [0, 128, 128, 255])];
  const c = () => new THREE.Color(0, 0, 0);
  const uniforms = {
    uTurfMask: { value: placeholders[0] },
    uTurfTile: { value: placeholders[1] },
    uTurfBox: { value: new THREE.Vector4(0, 0, 0, 0) },
    uTurfSodDark: { value: c() }, uTurfSodLight: { value: c() },
    uTurfBare: { value: c() }, uTurfDust: { value: c() }, uTurfWet: { value: c() },
    uTurfCut: { value: 0 },
    uTurfTileM: { value: TURF_TILE_M },
    uTurfGrainMean: { value: 0.4 },
  };
  let tile = null;
  let mask = null;
  const tone = (rgb) => new THREE.Color().setRGB(...rgb.map((v) => v / 255), THREE.SRGBColorSpace);
  return {
    uniforms,
    /** `spec`: { box: {e0,e1,n0,n1}, mask: {data, w, h}, sodDark, sodLight,
     *  bare, dust, wet (sRGB 0-255 triples), bareFraction } — see flora.js. */
    set(spec) {
      if (!spec?.box || !spec.mask?.data) return false;
      if (!tile) {
        const px = turfTilePixels();
        tile = new THREE.DataTexture(new Uint8Array(px.buffer), TURF_TILE_PX, TURF_TILE_PX,
          THREE.RGBAFormat);
        tile.name = 'town-turf';
        tile.colorSpace = THREE.NoColorSpace;
        tile.wrapS = tile.wrapT = THREE.RepeatWrapping;
        tile.magFilter = THREE.LinearFilter;
        tile.minFilter = THREE.LinearMipmapLinearFilter;
        tile.generateMipmaps = true;
        tile.anisotropy = 4;
        // The pixels live on the GPU once uploaded; the JS copy is let go so
        // the phone's heap does not carry the tile twice.
        tile.onUpdate = () => { tile.image.data = null; };
        tile.needsUpdate = true;
        uniforms.uTurfTile.value = tile;
        uniforms.uTurfGrainMean.value = turfTileMeanGrain(px);
      }
      mask?.dispose();
      mask = new THREE.DataTexture(spec.mask.data, spec.mask.w, spec.mask.h, THREE.RedFormat);
      mask.name = 'town-turf-mask';
      mask.unpackAlignment = 1;
      mask.magFilter = mask.minFilter = THREE.LinearFilter;
      mask.generateMipmaps = false;
      const m = mask;
      m.onUpdate = () => { m.image.data = null; };
      mask.needsUpdate = true;
      uniforms.uTurfMask.value = mask;
      const { e0, e1, n0, n1 } = spec.box;
      uniforms.uTurfBox.value.set(e0, n0, 1 / (e1 - e0), 1 / (n1 - n0));
      uniforms.uTurfSodDark.value.copy(tone(spec.sodDark));
      uniforms.uTurfSodLight.value.copy(tone(spec.sodLight));
      uniforms.uTurfBare.value.copy(tone(spec.bare));
      uniforms.uTurfDust.value.copy(tone(spec.dust));
      uniforms.uTurfWet.value.copy(tone(spec.wet));
      uniforms.uTurfCut.value = bareCut(spec.bareFraction);
      return true;
    },
    dispose() {
      tile?.dispose();
      mask?.dispose();
      for (const t of placeholders) t.dispose();
    },
  };
}

/**
 * T-2783 — THE FAR SWARD, painted by the ground where the plants thin out.
 *
 * Past the near ring the sward is a few cards a metre apart, then the far band's
 * aggregates, then nothing; and the ground under them was the prairie TILE, whose
 * colour is a reading of litter and soil between the stems — right at the walker's
 * feet, where the stems are drawn, and wrong at forty metres, where a July sward
 * seen almost edge-on is nothing but stems. So the plain past the near ring read
 * as a lighter, yellower paint than the grass standing on it, and the line where
 * the tufts stop was the line where the colour changed.
 *
 * WHAT IT PAINTS: from `start` metres out to `full` (the tier's own near and mid
 * rings, handed over by flora.js), the ground eases from the tile toward the
 * sward's own colour — the mean of the grass records the placer deals at that
 * point, the same `matColor` its cards are tinted with — at the share of the
 * ground the community's record says its grass covers (`matrix_fraction`). And it
 * carries the grass grain once more, at a coarse scale, which perspective lays
 * down into the long horizontal streaks a distant sward shows; the variation map
 * and the dry lean move it as they move the prairie.
 *
 * WHERE: a map flora.js rasterises off its own zone finder over the heightfield
 * (`setFarSward`), so the ground takes the grass colour exactly where the placer
 * would stand grass, and none on water, on the town's turf (which paints itself
 * after this) or where no community grows grass. Until it arrives the map is a
 * 1x1 texel of zero weight and nothing moves.
 *
 * WHAT IT COSTS: no draw call, no mesh; two fetches on the ground (the map, at
 * level 0 of a texture with no mips, and the grain), and one 16 m texel map of a
 * few hundred kilobytes. The colour is read from the records; the ramp, the
 * gain and the streaks are reconstructed (docs/LIBERTIES.md L-far-sward-2783).
 */
const FAR_SWARD_HEAD = /* glsl */`
uniform sampler2D uFarSwMap;
uniform vec4 uFarSwBox;
uniform vec4 uFarSwRamp;
uniform vec3 uFarSwGain;
`;

const FAR_SWARD_FRAGMENT = /* glsl */`
  // ---- T-2783, the far sward ---------------------------------------------- //
  {
    vec2 chiFsEN = vec2(vChiWorld.x, -vChiWorld.z);
    vec2 chiFsQ = (chiFsEN - uFarSwBox.xy) * uFarSwBox.zw;
    // Square-root encoded (linear = stored squared), so the dark greens keep
    // their steps in eight bits. The map's own rim is weightless and it clamps
    // to its edge, so off the map the weight ramps to nothing over a texel.
    vec4 chiFs = textureLod(uFarSwMap, chiFsQ, 0.0);
    float chiFsW = chiFs.a
                 * smoothstep(uFarSwRamp.x, uFarSwRamp.y, distance(vChiWorld, cameraPosition))
                 * (1.0 - 0.6 * chiWet);
    // The grass grain again, coarse and turned off the fine read's axes so the
    // two never line up: blade strokes a few metres long, which a grazing view
    // compresses into streaks across the plain.
    vec2 chiFsUv = mat2(0.6157, 0.7880, -0.7880, 0.6157) * chiFsEN / uFarSwRamp.w;
    float chiFsGrain = texture2D(uSward, chiFsUv).r / max(uSwardMean, 1e-6);
    vec3 chiFsC = chiFs.rgb * chiFs.rgb * uFarSwGain
                * (1.0 + mix(0.18, 0.30, chiFar) * chiPatch)
                * (vec3(1.0) + vec3(0.07, 0.035, -0.13) * chiMacro.a)
                * mix(1.0, chiFsGrain, uFarSwRamp.z);
    chiPrairie = mix(chiPrairie, diffuseColor.rgb * min(vec3(1.0), chiFsC), chiFsW);
  }
`;

/** The far sward's uniforms and the call that fills them (T-2783). One object
 *  for both ground materials, as the turf's is. Inert until `set`. */
function farSwardGround() {
  const blank = new THREE.DataTexture(new Uint8Array([0, 0, 0, 0]), 1, 1, THREE.RGBAFormat);
  blank.needsUpdate = true;
  const uniforms = {
    uFarSwMap: { value: blank },
    uFarSwBox: { value: new THREE.Vector4(0, 0, 0, 0) },
    uFarSwRamp: { value: new THREE.Vector4(1e6, 2e6, 0, 7.2) },
    uFarSwGain: { value: new THREE.Vector3(1, 1, 1) },
  };
  let map = null;
  return {
    uniforms,
    /** `spec`: { box: {e0,e1,n0,n1}, map: {data (RGBA, rgb = sqrt of linear),
     *  w, h}, start, full, streak, grainM, gain: [r,g,b] } — see flora.js. */
    set(spec) {
      if (!spec?.box || !spec.map?.data) return false;
      map?.dispose();
      map = new THREE.DataTexture(spec.map.data, spec.map.w, spec.map.h, THREE.RGBAFormat);
      map.name = 'far-sward';
      map.colorSpace = THREE.NoColorSpace;
      map.magFilter = map.minFilter = THREE.LinearFilter;
      map.generateMipmaps = false;
      const m = map;
      m.onUpdate = () => { m.image.data = null; };
      map.needsUpdate = true;
      uniforms.uFarSwMap.value = map;
      const { e0, e1, n0, n1 } = spec.box;
      uniforms.uFarSwBox.value.set(e0, n0, 1 / (e1 - e0), 1 / (n1 - n0));
      uniforms.uFarSwRamp.value.set(spec.start, spec.full, spec.streak ?? 0, spec.grainM ?? 7.2);
      if (Array.isArray(spec.gain)) uniforms.uFarSwGain.value.set(...spec.gain);
      return true;
    },
    dispose() {
      map?.dispose();
      blank.dispose();
    },
  };
}

/**
 * Ground: a procedural prairie sampled in WORLD space, darkening to wet mud as
 * the surface approaches the water.
 *
 * World-space sampling rather than UVs, deliberately. The bake decimates the
 * ground wherever it is planar — which is most of it, this being Chicago — and
 * a UV set carried through a planar dissolve stretches across every dissolved
 * region. Sampling by world XZ cannot stretch, and it costs the GLB no
 * attribute at all.
 *
 * The wetness band is not decoration: dossier zone 11 puts a strip along the
 * South Division shore "where land and water mingled, covered with tall grass,
 * reeds and rushes" at +0.5 to +2.0 ft, and the heightfield puts that strip at
 * +1.25 ft. Keying the mud on elevation therefore paints exactly the zone the
 * source describes, and paints it narrow on the higher north and west banks —
 * which is also what the sources say.
 *
 * WHAT THE DRY BAND MAY AND MAY NOT DO. It used to multiply the high ground by
 * (1.12, 1.06, 0.85) across `smoothstep(0.55, 1.25)`. The committed heightfield
 * puts the whole west-side plain between 0.87 and 1.24 m — its own gradient audit
 * reports under 0.5 ft of relief per 300 ft — so that band was not selecting
 * anything: it applied at 77–92 % strength over the entire open prairie and
 * turned it straw. Straw is the October negative control, not July. The
 * replacement is a narrow, gentle mesic tint over the top of the actual
 * elevation range: enough that the driest ground is a lighter, yellower green
 * than the swales, nowhere near enough to senesce it.
 *
 * So what this paints is WETNESS, from the heightfield, and nothing else. It is
 * not a community map: there is no plant-community record in `data/` for it to
 * read yet, and a renderer that invented the boundary between wet and mesic
 * prairie would be filling a gap silently. When those records land, the zone a
 * point falls in belongs here — and the ground stops being one green.
 */
function groundMaterial(zones = [], lakeShore = null,
  { nearHole = null, groundTex = null, swardTex = null, turf = null, farSward = null } = {}) {
  const mat = new THREE.MeshStandardMaterial({
    color: 0xffffff, roughness: 1, metalness: 0,
  });
  // The base shares the tiles' tile: one canvas, one upload.
  const tex = groundTex ?? prairieTexture();
  mat.map = null;
  mat.userData.groundTex = tex;
  // And the grass grain (T-2089), shared the same way.
  const sward = swardTex ?? swardTexture();
  mat.userData.swardTex = sward;
  mat.userData.substrateZones = zones.map((z) => z.id);
  // T-2474: a street layer may cut the ground out where it draws its own lower
  // surfaces (the 1904 roadway below its curbs). A uniform switch, off until
  // `setGroundCut` turns it on: the program key is fixed when confidence.js
  // patches this material, so the cut cannot be a second program.
  const cut = { on: { value: 0 }, tex: { value: null }, box: { value: new THREE.Vector4() } };
  mat.userData.cut = cut;
  // T-2976: a building's sunk ground (Glessner's carriage way), cut out exactly by up to
  // PASS_CUT_MAX convex quads — the 0.5 m street mask would leave a lip a quarter-metre
  // wide over a 2.4 m drive. Off (count 0) until `setPassageGround`.
  const pass = {
    quads: { value: Array.from({ length: PASS_CUT_MAX * 2 }, () => new THREE.Vector4()) },
    count: { value: 0 },
    box: { value: new THREE.Vector4(0, 0, -1, -1) },
  };
  mat.userData.passCut = pass;

  const prior = mat.onBeforeCompile;
  mat.onBeforeCompile = (shader, renderer) => {
    if (typeof prior === 'function') prior(shader, renderer);
    shader.uniforms.uGround = { value: tex };
    shader.uniforms.uChiCutOn = cut.on;
    shader.uniforms.uChiCut = cut.tex;
    shader.uniforms.uChiCutBox = cut.box;
    shader.uniforms.uChiPassCut = pass.quads;
    shader.uniforms.uChiPassCutN = pass.count;
    shader.uniforms.uChiPassBox = pass.box;
    shader.uniforms.uPrairieLuma = { value: tex.userData.meanLinearLuma };
    Object.assign(shader.uniforms, swardUniforms(sward), variationUniforms(tex));
    if (lakeShore) shader.uniforms.uChiShore = { value: shoreUniform(lakeShore, THREE) };
    if (nearHole) shader.uniforms.uChiNearHole = nearHole;
    if (turf) Object.assign(shader.uniforms, turf.uniforms);
    if (farSward) Object.assign(shader.uniforms, farSward.uniforms);
    seasonShaderUniforms(shader);
    shader.vertexShader = 'varying vec3 vChiWorld;\n' + shader.vertexShader.replace(
      '#include <begin_vertex>', '#include <begin_vertex>' + WORLD_POS_VERT,
    );
    shader.fragmentShader = `
varying vec3 vChiWorld;
${SEASON_HEAD}
uniform sampler2D uGround;
uniform float uPrairieLuma;
${SWARD_HEAD}
${nearHole ? 'uniform float uChiNearHole;' : ''}
uniform float uChiCutOn;
uniform sampler2D uChiCut;
uniform vec4 uChiCutBox;
uniform vec4 uChiPassCut[${PASS_CUT_MAX * 2}];
uniform float uChiPassCutN;
uniform vec4 uChiPassBox;
${zones.length ? shoreGlslHead(lakeShore) : ''}
${turf ? TURF_HEAD : ''}
${farSward ? FAR_SWARD_HEAD : ''}
` + shader.fragmentShader.replace('#include <clipping_planes_fragment>', `#include <clipping_planes_fragment>
${nearHole ? '  if (distance(vChiWorld, cameraPosition) < uChiNearHole) discard;' : ''}
${GROUND_CUT_FRAGMENT}
${PASS_CUT_FRAGMENT}`)
      .replace('#include <map_fragment>', /* glsl */`${PRAIRIE_FRAGMENT}
${zoneGlsl(zones, lakeShore)}
${farSward ? FAR_SWARD_FRAGMENT : ''}
${turf ? TURF_FRAGMENT : ''}
  diffuseColor.rgb = chiPrairie;
  diffuseColor.rgb = chiSeason(diffuseColor.rgb, vChiWorld.xz, 1.0, 1.0);
`)
      .replace('#include <normal_fragment_maps>', SWARD_NORMAL + (turf ? TURF_NORMAL : ''));
  };
  // Its own program: `customProgramCacheKey` defaults to the source text of
  // `onBeforeCompile`, which both ground materials share, so without this the
  // base could be drawn with the tiles' program (no hole) or the reverse.
  if (nearHole) mat.customProgramCacheKey = () => 'chicago4d-ground-base';
  mat.needsUpdate = true;
  return mat;
}

/** Set a ground material's T-2474 cut: `mask` over the world box, or off without one. */
function applyCut(m, { mask, x0, z0, width, depth } = {}) {
  const cut = m?.userData?.cut;
  if (!cut) return;
  cut.tex.value = mask ?? null;
  cut.box.value.set(x0 ?? 0, z0 ?? 0, width ? 1 / width : 0, depth ? 1 / depth : 0);
  cut.on.value = mask ? 1 : 0;
}

/** T-2474: drop the ground where the cut mask says a layer draws its own surface.
 *  The mask is 0..1 coverage over a world box (x0, z0, 1/width, 1/depth). */
const GROUND_CUT_FRAGMENT = /* glsl */`
  if (uChiCutOn > 0.5) {
    vec2 chiCutUv = (vChiWorld.xz - uChiCutBox.xy) * uChiCutBox.zw;
    if (chiCutUv.x > 0.0 && chiCutUv.y > 0.0 && chiCutUv.x < 1.0 && chiCutUv.y < 1.0
        && texture2D(uChiCut, chiCutUv).r > 0.5) discard;
  }
`;

/** T-2976: the most sunk-ground quads one scene may cut (Glessner's carriage way is four). */
export const PASS_CUT_MAX = 8;

/** T-2976: drop the ground inside any of the passage quads (world x, z; convex, either
 *  winding), behind one box test so the rest of the field pays a compare. */
const PASS_CUT_FRAGMENT = /* glsl */`
  if (uChiPassCutN > 0.5 && vChiWorld.x >= uChiPassBox.x && vChiWorld.x <= uChiPassBox.z
      && vChiWorld.z >= uChiPassBox.y && vChiWorld.z <= uChiPassBox.w) {
    vec2 chiP = vChiWorld.xz;
    for (int i = 0; i < ${PASS_CUT_MAX}; i++) {
      if (float(i) >= uChiPassCutN) break;
      vec4 chiAB = uChiPassCut[2 * i];
      vec4 chiCD = uChiPassCut[2 * i + 1];
      vec2 chiA = chiAB.xy; vec2 chiB = chiAB.zw; vec2 chiC = chiCD.xy; vec2 chiD = chiCD.zw;
      float c1 = (chiB.x - chiA.x) * (chiP.y - chiA.y) - (chiB.y - chiA.y) * (chiP.x - chiA.x);
      float c2 = (chiC.x - chiB.x) * (chiP.y - chiB.y) - (chiC.y - chiB.y) * (chiP.x - chiB.x);
      float c3 = (chiD.x - chiC.x) * (chiP.y - chiC.y) - (chiD.y - chiC.y) * (chiP.x - chiC.x);
      float c4 = (chiA.x - chiD.x) * (chiP.y - chiD.y) - (chiA.y - chiD.y) * (chiP.x - chiD.x);
      if ((c1 >= 0.0 && c2 >= 0.0 && c3 >= 0.0 && c4 >= 0.0)
          || (c1 <= 0.0 && c2 <= 0.0 && c3 <= 0.0 && c4 <= 0.0)) discard;
    }
  }
`;

/** T-2976: hand a ground material its passage quads — `pieces` as passageGroundFrom()
 *  returns them (`pts` four [e, n]) — or clear them with []. */
function applyPassCut(m, pieces = []) {
  const pass = m?.userData?.passCut;
  if (!pass) return;
  const use = pieces.slice(0, PASS_CUT_MAX);
  let x0 = Infinity; let z0 = Infinity; let x1 = -Infinity; let z1 = -Infinity;
  use.forEach((piece, i) => {
    const xz = piece.pts.map(([e, n]) => [e, -n]);
    pass.quads.value[2 * i].set(xz[0][0], xz[0][1], xz[1][0], xz[1][1]);
    pass.quads.value[2 * i + 1].set(xz[2][0], xz[2][1], xz[3][0], xz[3][1]);
    for (const [x, z] of xz) { x0 = Math.min(x0, x); z0 = Math.min(z0, z); x1 = Math.max(x1, x); z1 = Math.max(z1, z); }
  });
  if (use.length) pass.box.value.set(x0, z0, x1, z1); else pass.box.value.set(0, 0, -1, -1);
  pass.count.value = use.length;
}

/**
 * Water: a silty prairie river, not a swimming pool.
 *
 * There is no environment map in this scene on purpose (see world.js — a PMREM
 * of the analytic sky swamped every albedo), so the water cannot get its look
 * from a reflection probe. It gets it from three cheap things instead: a
 * drifting ripple normal map, a low roughness so the single directional light
 * leaves a real sun glint, and a Fresnel term that turns the surface toward the
 * sky colour at grazing angles — which is most of what makes a flat plane read
 * as water when you are standing on the bank looking across it.
 */
function waterMaterial() {
  const mat = new THREE.MeshStandardMaterial({
    color: 0x3e4a38,
    roughness: 0.17,
    metalness: 0.0,
    normalMap: rippleTexture(),
    normalScale: new THREE.Vector2(0.55, 0.55),
  });
  // 2400 m of plane / 700 tiles = a 3.4 m ripple cell, which is the scale you
  // actually read from a bank. Mipmaps + anisotropy fade it to flat by the far
  // shore instead of aliasing into noise.
  mat.normalMap.wrapS = mat.normalMap.wrapT = THREE.RepeatWrapping;
  mat.normalMap.repeat.set(700, 700);
  mat.normalMap.anisotropy = 8;

  const prior = mat.onBeforeCompile;
  mat.onBeforeCompile = (shader, renderer) => {
    if (typeof prior === 'function') prior(shader, renderer);
    // The same colour the far ground goes to (world.js HORIZON_HAZE), so the
    // river and the plain agree about what distance looks like — a hand-picked
    // grey-green here used to leave the water reading a season cooler than the
    // air above it.
    //
    // ONE conversion, not two. `new THREE.Color(hex)` already reads the hex as
    // sRGB and stores it in the renderer's linear working space
    // (ColorManagement.enabled is true by default since three r152), so the
    // `.convertSRGBToLinear()` that used to follow it applied the transfer
    // function a second time: the old 0x98a69d reached the shader as linear
    // (0.080,0.120,0.093) instead of (0.314,0.381,0.337) — 31 % of its intended
    // radiance. `outgoingLight` is linear at this point in the fragment, so what
    // the grazing angle mixed toward was not distance at all, it was a dark
    // olive: the far water read as a stain on the plain rather than as sky lying
    // on it, and the comment above it claimed the opposite in good faith.
    shader.uniforms.uSky = { value: new THREE.Color(HORIZON_HAZE) };
    // T-1631: the haze is no longer one colour — `world.js`'s `aim()` turns it
    // with the view — so the water's idea of distance has to be able to turn
    // with it. Published on the material rather than closed over, because the
    // material is what `setHaze` below is handed.
    mat.userData.chiSkyUniform = shader.uniforms.uSky;
    shader.vertexShader = 'varying vec3 vChiWorld;\n' + shader.vertexShader.replace(
      '#include <begin_vertex>', '#include <begin_vertex>' + WORLD_POS_VERT,
    );
    shader.fragmentShader = `
varying vec3 vChiWorld;
uniform vec3 uSky;
` + shader.fragmentShader.replace('#include <opaque_fragment>', /* glsl */`
  {
    // Fresnel toward the sky, capped well short of 1. A full Fresnel makes the
    // whole river read as one slab of sky-blue paint from bank level, which is
    // where a visitor actually stands; capping it keeps the silt colour of a
    // prairie river in the mix all the way to the far shore.
    vec3 chiV = normalize(cameraPosition - vChiWorld);
    float chiF = pow(1.0 - clamp(dot(chiV, vec3(0.0, 1.0, 0.0)), 0.0, 1.0), 4.0);
    float chiRip = sin(vChiWorld.x * 0.42 + vChiWorld.z * 0.31) * 0.5 + 0.5;
    vec3 chiSky = uSky * (0.90 + 0.14 * chiRip);
    outgoingLight = mix(outgoingLight, chiSky, clamp(chiF, 0.0, 0.70));
  }
#include <opaque_fragment>
`);
  };
  mat.needsUpdate = true;
  return mat;
}

/**
 * The July ground: one 256 px tile of procedural prairie, drawn once into a
 * canvas. It is the ALBEDO of what lies under the sward — visible as itself
 * between the clumps, and standing in for the sward wholesale past the range
 * where flora.js still plants instances.
 *
 * The colour is a measurement, not a taste. In the two verified July
 * photographs, Illinois tallgrass in the last week of July sits around sRGB
 * (122,139,74) in the middle distance and (109,128,78) at the far edge of the
 * field — a yellow-green whose green channel leads its red by about fifteen.
 * Working that target back through this scene's light (measured off the render
 * itself: the sky fill plus sun multiply albedo by ×1.42 red, ×1.42 green,
 * ×1.63 blue) and its ACES + sRGB output chain asks for a mean albedo near sRGB
 * (95,107,62), which is what this tile averages. It lands at (119,134,75) in the
 * middle distance of `prairie_west` — within three or four units of the
 * photograph on every channel.
 *
 * What it replaces averaged (139,139,91) — red and green level, a khaki closer
 * in hue to `bar/mesic_remnant_2016-10-27.jpg`, the OCTOBER negative control,
 * than to either July photograph. That is the failure this ramp exists to fix,
 * so the numbers are written down rather than left as three literals.
 *
 * Four octaves, not two, and all four baked into the same tile so the shader
 * still costs exactly one fetch: 0.7 m clumps, 0.35 m tussocks, 0.17 m leaf
 * mass and a per-texel grain that mipmaps away into tone by twenty metres out.
 * A minority of dry thatch is mixed in — last season's litter is present under a
 * July sward, and the palette record keeps it to a minority, which is where it
 * stays: it tints about a quarter of the tile and reaches half strength nowhere,
 * moving the mean by roughly two units.
 *
 * The tile stays 256 px, i.e. 4 cm per texel over its 11 m footprint. Doubling
 * it bought nothing the eye can find past the first few metres — the octave
 * sizes are fractions of the tile and so do not change with resolution — and
 * cost the software rasteriser measurably, this being the one texture that
 * covers the screen. Detail here is bought in octaves, not in pixels.
 */
export function prairieTexture() {
  const S = PRAIRIE_TILE_PX;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const ctx = c.getContext('2d');
  // The pixels are `prairie-tile.js`'s, so the tile a tool measures from Node is
  // the tile drawn here, texel for texel. The colour argument above is why they
  // are those pixels; that module only fills the buffer.
  const img = new ImageData(prairieTilePixels(), S, S);
  ctx.putImageData(img, 0, 0);

  const tex = new THREE.CanvasTexture(c);
  // The divisor that makes a substrate zone average exactly the triple its flora
  // record states — see zoneGlsl. Measured from the pixels, not a constant.
  tex.userData.meanLinearLuma = prairieTileMeanLuma(img.data);
  // And its mean linear COLOUR: what the tile fades toward with distance
  // (T-2552), so the fade moves contrast and never the July mean.
  const sum = [0, 0, 0];
  for (let i = 0; i < img.data.length; i += 4) {
    for (let ch = 0; ch < 3; ch++) sum[ch] += srgbToLinear(img.data[i + ch]);
  }
  tex.userData.meanLinear = sum.map((v) => v / (img.data.length / 4));
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  // Anisotropy stays at 4. Eight taps on a 512 px tile looked slightly cleaner
  // on the grazing mid-field and cost the software rasteriser half its frame
  // rate — the ground is most of the screen, so doubling its filter taps doubles
  // the most expensive fetch in the frame. Measured against this file's previous
  // revision on the `prairie_west` pose: 2.0 fps before, 1.0 with the eight taps,
  // 2.2 back at four on a 256 tile. One fps is enough to fail the smoke's "walk
  // intent moves the camera" check, which is wall-clock. Same lesson as the
  // one-fetch rule above; do not raise it without re-running that check.
  tex.anisotropy = 4;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * The grass grain as a texture (T-2089) — `grass-grain.js`'s pixels on a
 * runtime canvas, the way the grit is drawn for the road: no image fetch and no
 * wire bytes, 256 KiB of texture (a third more with its mips). Data, not colour
 * (`NoColorSpace`): R is a height and G/B a normal. Anisotropy 4, for the reason
 * the prairie tile gives above. `userData.mean` is the divisor the shader reads
 * the grain over, measured from the pixels.
 */
export function swardTexture() {
  const data = grassGrainPixels();
  const c = document.createElement('canvas');
  c.width = c.height = GRASS_GRAIN_PX;
  c.getContext('2d').putImageData(new ImageData(data, GRASS_GRAIN_PX, GRASS_GRAIN_PX), 0, 0);
  const tex = new THREE.CanvasTexture(c);
  tex.name = 'sward-grain';
  tex.colorSpace = THREE.NoColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 4;
  tex.userData.mean = grassGrainMean(data);
  return tex;
}

let macroTex = null;
/**
 * The variation map as a texture (T-2552) — `prairie-macro.js`'s pixels, one
 * DataTexture for the whole session: 1 MiB, a third more with its mips, shared
 * by every surface that paints the prairie so the strip and the bank cannot
 * drift from the terrain they feather into. Never disposed: a DataTexture keeps
 * its pixels, so even a caller that disposed it would only cost a re-upload.
 * Data, not colour. No anisotropy: at 6 m a texel it is magnified nearly
 * everywhere, so the extra taps would buy nothing.
 */
export function macroTexture() {
  if (macroTex) return macroTex;
  const data = macroPixels();
  const tex = new THREE.DataTexture(data, MACRO_PX, MACRO_PX, THREE.RGBAFormat);
  tex.name = 'prairie-variation';
  tex.colorSpace = THREE.NoColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.generateMipmaps = true;
  tex.userData.stats = macroStats(data);
  tex.needsUpdate = true;
  macroTex = tex;
  return tex;
}

/** The `uMacro*` and `uPrairieMean` uniforms `SWARD_HEAD` declares (T-2552). */
export function variationUniforms(prairieTex) {
  const tex = macroTexture();
  const { mean, gain } = tex.userData.stats;
  return {
    uMacro: { value: tex },
    uMacroM: { value: MACRO_M },
    uMacroMean: { value: new THREE.Vector4(...mean) },
    uMacroGain: { value: gain },
    uPrairieMean: { value: new THREE.Vector3(...prairieTex.userData.meanLinear) },
  };
}

/** The `uSward*` uniforms `SWARD_HEAD` declares, bound to one sward texture. */
export function swardUniforms(tex) {
  return {
    uSward: { value: tex },
    uSwardM: { value: GRASS_GRAIN_M },
    uSwardMean: { value: tex.userData.mean },
  };
}

/** A drifting ripple normal map, generated once. */
function rippleTexture() {
  const S = 128;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const ctx = c.getContext('2d');
  const img = ctx.createImageData(S, S);

  const h = new Float32Array(S * S);
  for (let y = 0; y < S; y++) {
    for (let x = 0; x < S; x++) {
      const u = (x / S) * Math.PI * 2;
      const v = (y / S) * Math.PI * 2;
      h[y * S + x] = Math.sin(u * 3 + Math.cos(v * 2) * 0.8) * 0.5
                   + Math.sin(v * 5 - u * 2) * 0.3
                   + Math.sin(u * 9 + v * 7) * 0.2;
    }
  }
  const at = (x, y) => h[((y + S) % S) * S + ((x + S) % S)];
  for (let y = 0; y < S; y++) {
    for (let x = 0; x < S; x++) {
      const dx = (at(x + 1, y) - at(x - 1, y)) * 0.5;
      const dy = (at(x, y + 1) - at(x, y - 1)) * 0.5;
      const len = Math.hypot(dx, dy, 1);
      const i = (y * S + x) * 4;
      img.data[i]     = Math.round((-dx / len * 0.5 + 0.5) * 255);
      img.data[i + 1] = Math.round((-dy / len * 0.5 + 0.5) * 255);
      img.data[i + 2] = Math.round((1 / len * 0.5 + 0.5) * 255);
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}
