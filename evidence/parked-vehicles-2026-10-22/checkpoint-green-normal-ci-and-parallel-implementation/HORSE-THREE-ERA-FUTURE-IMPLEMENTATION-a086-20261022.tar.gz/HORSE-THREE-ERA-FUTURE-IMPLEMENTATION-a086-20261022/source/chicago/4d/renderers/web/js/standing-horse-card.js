// SPDX-License-Identifier: GPL-3.0-or-later
// Modern asset credit is separate from historically graded animal claims.
import { horseSceneContext, isLegacyHorseRow } from './standing-horse-contract.js';
export function standingHorseCard(row, spec, context) {
  if (!context && row.surface_kind !== undefined) throw Error('New-era horse card requires explicit scene/date');
  const scene = context ? horseSceneContext(context.sceneId, context.targetDate) : horseSceneContext('1835');
  const legacy = isLegacyHorseRow(row, scene);
  const site = legacy ? 'the 1835 Western Hotel yard' : `${row.location} (${scene.targetDate})`;
  const year = scene.sceneId;
  return { id: row.id, sidecar: {
    name: row.name, phase: null,
    change_note: `A reconstructed, unidentified horse in ${site}. Modern model credit (published ${spec.source.publication_date.slice(0, 4)}): ${spec.source.credit} This modern asset credit is not evidence of a particular ${year} horse, breed or owner.`,
    placement: { symbolic_location: row.location, position_confidence: 'reconstructed',
      position_sources: row.source_ids, position_note: row.note },
    attributes: {
      animal: { value: 'Standing horse; individual unidentified', confidence: 'reconstructed',
        sources: row.source_ids, note: legacy ? 'Yard context supports horsekeeping; this individual is a reconstruction.'
          : 'The cited context supports horsekeeping in this era; this individual, exact stand and appearance are reconstructed. No ownership is assigned.' },
      breed_owner: { value: 'Unidentified', confidence: 'reconstructed', sources: [],
        note: 'No historical breed, owner, measured stature, coat or grooming is attested for this model.' },
      state: { value: 'Standing, unhitched, untied and unmounted', confidence: 'reconstructed', sources: [],
        note: row.animation?.enabled
          ? 'Gentle head/tail idle is reconstructed; no independent ear, body weight shift, walking, halter, tie rope, harness, rider, driver, boarding, route or physical coupling is enabled.'
          : 'Idle activation awaits qualification; no halter, tie rope, harness, rider, driver, boarding, route or physical coupling is enabled.' },
    },
    citations: [...row.source_ids, spec.source.id].map(source_id => ({ source_id })),
    research_note: `${row.note} Modern model credit (${spec.source.publication_date.slice(0, 4)}): ${spec.source.credit} Model adaptations: uniform reconstructed metre scale, source-origin wrapper,
      declared whole-root support rotation, ${legacy ? 'yard placement' : 'site-specific drawn-triangle support placement'} and source-derived reconstructed head/tail idle. Original six clips never autoplay. ${spec.material_variants[row.material_variant].change_notice}`,
  } };
}
