// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded copies of actual rendered surface triangles, BEFORE upload release.
import * as THREE from 'three';

const MAX_REGIONS = 1, MAX_AREA = 4, MAX_TRIANGLES = 32, MAX_BYTES = 4096;
const KINDS = new Set(['terrain_triangle', 'carriageway_triangle']);
const sha256 = async bytes => [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))]
  .map(x => x.toString(16).padStart(2, '0')).join('');

export function triangleHeight(values, e, n) {
  const z = -n; let highest = -Infinity;
  for (let i = 0; i < values.length; i += 9) {
    const x = values[i], zz = values[i + 2];
    const dx1 = values[i + 3] - x, dz1 = values[i + 5] - zz;
    const dx2 = values[i + 6] - x, dz2 = values[i + 8] - zz;
    const determinant = dx1 * dz2 - dx2 * dz1;
    if (Math.abs(determinant) < 1e-12) continue;
    const u = ((e - x) * dz2 - (z - zz) * dx2) / determinant;
    const v = (dx1 * (z - zz) - dz1 * (e - x)) / determinant;
    if (u < -1e-9 || v < -1e-9 || u + v > 1 + 1e-9) continue;
    highest = Math.max(highest, values[i + 1] + u * (values[i + 4] - values[i + 1])
      + v * (values[i + 7] - values[i + 1]));
  }
  return Number.isFinite(highest) ? highest : null;
}

/** sources(region) names only the constructor's exact drawn top surfaces.
 * A source is {mesh,ranges?}; ranges are triangle-ordinal [from,to) intervals.
 * Fresh BatchedMesh instances have contiguous, undeleted IDs. No source arrays
 * or whole-town geometry are retained. No analytic/bilinear fallback exists.
 */
export async function retainDrawnStaticSupport({ group, regions = [], sceneId,
  targetDate, surfaceKind, sources, problems = [] }) {
  const retained = new Map();
  const census = { regions: 0, triangles: 0, bytes: 0, disposed: false };
  const find = (recordId, regionId) => {
    const entry = retained.get(regionId);
    return !census.disposed && entry?.meta.record_id === recordId ? entry : null;
  };
  const out = { census,
    heightAt(e, n, recordId, regionId) {
      const entry = find(recordId, regionId);
      if (!entry || !Number.isFinite(e) || !Number.isFinite(n)) return null;
      const b = entry.meta.bounds_enu_m;
      if (e < b[0][0] || e > b[1][0] || n < b[0][1] || n > b[1][1]) return null;
      return triangleHeight(entry.triangles, e, n);
    },
    snapshot(recordId, regionId) {
      const entry = find(recordId, regionId);
      return entry ? structuredClone(entry.meta) : null;
    },
    // Explicit small copy for source-fit tools; never exposes mutable retained data.
    copyTriangles(recordId, regionId) { return find(recordId, regionId)?.triangles.slice() ?? null; },
    dispose() { retained.clear(); census.disposed = true;
      census.regions = census.triangles = census.bytes = 0; },
  };
  if (!regions.length) return out;
  if (regions.length > MAX_REGIONS || !KINDS.has(surfaceKind)) {
    problems.push('drawn support: region/provider budget refused'); return out;
  }
  const point = new THREE.Vector3(), matrix = new THREE.Matrix4();
  group.updateMatrixWorld(true);
  for (const region of regions) {
    try {
      const b = region.bounds_enu_m;
      if (!region.id || !region.record_id || region.scene_id !== String(sceneId)
        || region.target_date !== targetDate || region.surface_kind !== surfaceKind
        || !Array.isArray(b) || b.length !== 2 || b.some(p => !Array.isArray(p) || p.length !== 2)
        || !b.flat().every(Number.isFinite) || b[1][0] <= b[0][0] || b[1][1] <= b[0][1]
        || (b[1][0]-b[0][0])*(b[1][1]-b[0][1]) > MAX_AREA) throw Error('Invalid support region identity/bounds');
      const values = [];
      for (const source of sources(region)) {
        const mesh = source.mesh, geometry = mesh.geometry;
        if (!mesh.isMesh || !mesh.visible) continue;
        const position = geometry.getAttribute('position'), index = geometry.getIndex();
        if (!position?.array?.length || (index && !index.array?.length)) throw Error('Surface arrays released before snapshot');
        const instances = mesh.isBatchedMesh ? mesh.instanceCount : 1;
        for (let instance = 0; instance < instances; instance++) {
          if (mesh.isBatchedMesh && !mesh.getVisibleAt(instance)) continue;
          const range = mesh.isBatchedMesh
            ? mesh.getGeometryRangeAt(mesh.getGeometryIdAt(instance))
            : { start: geometry.drawRange.start, count: Math.min(geometry.drawRange.count,
              (index?.count ?? position.count) - geometry.drawRange.start) };
          if (!Number.isInteger(range.start) || range.start % 3 || !Number.isInteger(range.count) || range.count % 3)
            throw Error('Unsupported triangle draw range');
          if (mesh.isBatchedMesh) mesh.getMatrixAt(instance, matrix).premultiply(mesh.matrixWorld);
          else matrix.copy(mesh.matrixWorld);
          for (let i = range.start; i < range.start + range.count; i += 3) {
            if (source.ranges && !source.ranges.some(([from,to]) => i/3 >= from && i/3 < to)) continue;
            const triangle = [];
            for (let j = 0; j < 3; j++) {
              point.fromBufferAttribute(position, index ? index.getX(i+j) : i+j).applyMatrix4(matrix);
              if (![point.x,point.y,point.z].every(Number.isFinite)) throw Error('Nonfinite drawn triangle');
              triangle.push(point.x,point.y,point.z);
            }
            const es = [triangle[0],triangle[3],triangle[6]], ns = [-triangle[2],-triangle[5],-triangle[8]];
            if (Math.max(...es) < b[0][0] || Math.min(...es) > b[1][0]
              || Math.max(...ns) < b[0][1] || Math.min(...ns) > b[1][1]) continue;
            const upward = (triangle[5]-triangle[2])*(triangle[6]-triangle[0])
              - (triangle[3]-triangle[0])*(triangle[8]-triangle[2]);
            if (upward <= 1e-12) throw Error('Non-upward/degenerate support triangle');
            values.push(...triangle);
            if (values.length/9 > MAX_TRIANGLES || values.length*8 > MAX_BYTES)
              throw Error('Actual drawn support triangle/byte cap exceeded');
          }
        }
      }
      if (!values.length) throw Error('No matching drawn surface triangles');
      const triangles = new Float64Array(values);
      const canonical = new ArrayBuffer(triangles.byteLength), view = new DataView(canonical);
      values.forEach((value,i) => view.setFloat64(i*8,value,true));
      const meta = { sha256: await sha256(canonical), bounds_enu_m: structuredClone(b),
        record_id: region.record_id, region_id: region.id, surface_kind: surfaceKind,
        scene_id: String(sceneId), target_date: targetDate, triangles: values.length/9, bytes: triangles.byteLength };
      retained.set(region.id,{meta,triangles}); census.regions++; census.triangles += values.length/9;
      census.bytes += triangles.byteLength;
    } catch (error) { problems.push(`drawn support: ${error.message}`); }
  }
  return out;
}
