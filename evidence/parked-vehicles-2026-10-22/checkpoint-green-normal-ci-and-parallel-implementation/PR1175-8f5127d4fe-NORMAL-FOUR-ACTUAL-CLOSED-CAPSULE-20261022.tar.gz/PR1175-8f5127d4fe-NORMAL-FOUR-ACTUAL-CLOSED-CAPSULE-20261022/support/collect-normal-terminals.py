"""Root-released fixed normal run IDs; source/testmerge evidence only, never merge approval."""
import base64,datetime,hashlib,json,os,pathlib,re,subprocess,time
from normal_helpers import NORMAL,need,audit_job,audit_human_jobs,checkout_sha
HERE=pathlib.Path(__file__).resolve().parent
OUT=pathlib.Path('/workspace/shared/PR1175-8f5127d4fe-NORMAL-TERMINAL-GET-owner1')
HEAD='8f5127d4feebcaa63a0bc0c751dc4a1c1e7dd8d3'
BRANCH='steward/1835-workwear-repair-20261021'
RUNS={39866198822:('.github/workflows/chicago-4d-check.yml',365585053,'pull_request'),39866198809:('.github/workflows/chicago-4d-humans.yml',380427937,'pull_request'),39866198764:('.github/workflows/chicago-4d-moving-frames.yml',374947050,'pull_request'),39866189083:('.github/workflows/chicago-4d-pr-stuck.yml',365616743,'push')}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,r):p.write_text(json.dumps(r,indent=2)+'\n')
def main():
 OUT.mkdir(exist_ok=False);deadline=time.monotonic()+180*60;number=0;audited={};cached={}
 state={'status':'FIXED_NORMAL_RUNS_GET_COLLECTING','started':now(),'pid':os.getpid(),'source':HEAD,'source_branch':BRANCH,'run_ids':list(RUNS),'poll_seconds':60,'maximum_minutes':180,'POSTs':0,'automatic_retries':0,'qualification_pass':False,'current_final_head_qualified':False,'scope':'Actual four normal run/job/log/source/testmerge evidence only. Root separately reconciles latestDEV, mixed-source smoke coverage, local focused views and merge.'}
 save(OUT/'OWNER.json',state);print(json.dumps(state),flush=True)
 def api(label,route,plain=False):
  nonlocal number
  need(time.monotonic()<deadline,'Normal collection180min deadline');number+=1;p=OUT/('%04d-%s'%(number,label));r=subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/'+route],capture_output=True,timeout=45);p.with_suffix('.stdout').write_bytes(r.stdout);p.with_suffix('.stderr').write_bytes(r.stderr)
  with (OUT/'GET-ATTEMPTS.jsonl').open('a')as f:f.write(json.dumps({'at':now(),'route':route,'exit':r.returncode,'stdout_sha256':sha(r.stdout),'retry':False})+'\n')
  need(r.returncode==0,'GET failed; no retry: '+label+' '+r.stderr.decode(errors='replace')[-400:]);return r.stdout.decode()if plain else json.loads(r.stdout)
 pins={path:sha(subprocess.check_output(['git','-C','/workspace/chicago','show',HEAD+':'+path],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}))for path,_,_ in RUNS.values()};save(OUT/'SOURCE-WORKFLOW-BYTE-PINS.json',pins)
 try:
  while time.monotonic()<deadline:
   tick=time.monotonic()
   for ident,(path,wid,event)in RUNS.items():
    if ident in audited:continue
    run=api('run-'+str(ident),'actions/runs/'+str(ident));cached[ident]=run
    need(run['id']==ident and run['head_sha']==HEAD and run['head_branch']==BRANCH and run['event']==event and run['path']==path and run['workflow_id']==wid and run['run_attempt']==1 and run['repository']['full_name']=='kevinrhaas/chicago','Fixed normal run identity drift')
    if run['status']!='completed':continue
    save(OUT/('RUN-'+str(ident)+'.json'),run);jobs=api('jobs-'+str(ident),'actions/runs/'+str(ident)+'/attempts/1/jobs?per_page=100');save(OUT/('RUN-'+str(ident)+'-JOBS.json'),jobs);need(jobs['total_count']==len(jobs['jobs']),'Incomplete jobs')
    logs={}
    for job in jobs['jobs']:
     if job['conclusion']=='skipped':continue
     logs[job['id']]=api('job-'+str(job['id'])+'-log','actions/jobs/'+str(job['id'])+'/logs',True)
    proof={'run_id':ident,'source':HEAD,'workflow_path':path,'event':event,'run_conclusion':run['conclusion'],'PASS':False,'logs':[{'job':i,'sha256':sha(t.encode())}for i,t in logs.items()]}
    try:
     need(run['conclusion']=='success','Actual normal run failed: '+str(run['conclusion']))
     if path.endswith('chicago-4d-humans.yml'):job,detail=audit_human_jobs(jobs['jobs'],run,HEAD)
     else:
      need(len(jobs['jobs'])==1,'Unexpected normal job count');job=jobs['jobs'][0];name,steps=NORMAL[path];detail=audit_job(job,run,HEAD,name,steps)
     text=logs[job['id']];clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text);values=re.findall(r'(?m)^\S+Z\s*\[command\].*[/ ]git log -1 --format=%H\s*\n\S+Z\s*([a-f0-9]{40})\s*$',clean);need(len(values)==1,'Ambiguous actual checkout');checkout=checkout_sha(text,values[0]);proof['actual_checkout_sha']=checkout
     commit=api('checkout-'+str(ident),'git/commits/'+checkout);save(OUT/('RUN-'+str(ident)+'-ACTUAL-CHECKOUT-COMMIT.json'),commit);parents=[x['sha']for x in commit['parents']];proof.update(actual_checkout_tree=commit['tree']['sha'],actual_checkout_parents=parents)
     if event=='pull_request':
      need(checkout!=HEAD and len(parents)==2 and HEAD in parents,'PR checkout is not a testmerge containing exact source');proof['actual_checkout_base_sha']=next(x for x in parents if x!=HEAD)
     else:need(checkout==HEAD,'Push job did not checkout exactsource')
     wf=api('checkout-workflow-'+str(ident),'contents/'+path+'?ref='+checkout);need(wf['encoding']=='base64'and sha(base64.b64decode(wf['content']))==pins[path],'Actual checkout workflow bytes differ from source')
     proof.update(detail);proof.update(PASS=True,workflow_sha256=pins[path],actual_test_output_lines=[x for x in text.splitlines()if re.search(r'\bPASS\b|\bpassed\b|\bFAIL\b|failed|self-tests|self tests|1048|1047',x)][-40:])
    except Exception as error:proof.update(PASS=False,error=str(error),causal_lines=[x for t in logs.values()for x in t.splitlines()if re.search(r'\bFAIL\b|\bfail\b|Error:|exit code',x)][-50:])
    audited[ident]=proof;save(OUT/'AUDITED-JOBS.json',list(audited.values()));print(json.dumps({'at':now(),'new_terminal_run':ident,'proof':proof}),flush=True)
   state.update(at=now(),terminal_collected=len(audited),strict_success=sum(x['PASS']for x in audited.values()),runs=[{k:r.get(k)for k in ['id','status','conclusion']}for r in cached.values()]);save(OUT/'LATEST.json',state);print(json.dumps({k:state[k]for k in ['at','terminal_collected','strict_success','runs']}),flush=True)
   if len(audited)==4:state['status']='NORMAL_FOUR_TERMINAL_SOURCE_AND_CHECKOUT_EVIDENCE_ONLY';break
   remaining=min(60-(time.monotonic()-tick),deadline-time.monotonic())
   if remaining>0:time.sleep(remaining)
  else:state['status']='BOUNDED180MIN_PARTIAL_NO_RETRY'
 except Exception as error:state.update(status='STOPPED_GET_OR_BINDING_ERROR_NO_RETRY',error=str(error))
 finally:state['ended']=now();save(OUT/'TERMINAL.json',state);save(OUT/'LATEST.json',state);print(json.dumps(state),flush=True)
 return 0 if len(audited)==4 and all(x['PASS']for x in audited.values())else 1
if __name__=='__main__':raise SystemExit(main())
