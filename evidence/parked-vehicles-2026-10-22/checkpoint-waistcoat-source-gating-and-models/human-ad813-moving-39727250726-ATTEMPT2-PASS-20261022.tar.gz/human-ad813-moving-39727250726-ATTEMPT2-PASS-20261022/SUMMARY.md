# Exact ad813 moving workflow: qualified after one diagnostic rerun

Status: `qualified_after_one_diagnostic_rerun`; `first_pass:false`. Actual run39727250726 attempt2 and job/check119661122753 completed SUCCESS at exact headad813a6278b7d76961b78ef3483f1bbf3e106c02 on steward/1835-workwear-repair-20261021. Event remains workflow_dispatch. All mandatory steps succeeded, including moving-frame assertions and all32 phone/upload-release checks. This is qualification of this exact workflow attempt only.

Eight successful GET requests captured live run, exact attempt2 run/jobs, actual job/check metadata, raw full job log, attempt2 ZIP and exact-head workflow source. Checkout step log172–173 prints the executed git commitad813. Workflow SHA256a337a37dbeafb63654f5eb1f5f5357ed395f33d74405f980a6165edc35bec6c3 matches the retained original workflow. Raw job log is byte-exact ZIP0_moving-frames.txt; all actual step logs are retained with hashes. No remote POST, rerun, dispatch or cancel was made by this collector. Initial default-sandbox network refusal is preserved separately; the authorized GET collection then succeeded.

| Tier | Largest actual flora frame | Unchanged ceiling | Rounded margin | Highest flora p95 / ceiling |
|---|---:|---:|---:|---:|
| Full | turn24.2ms |60ms|35.8ms|6.9/15ms|
| Balanced | flight29.6ms|32ms|2.4ms|4.3/9ms|
| Light | travel6.9ms|21ms|14.1ms|4.0/7ms|

The original failed Light/travel reading was38.6ms>21ms; the diagnostic repeat reads6.9ms maximum and2.8ms p95 over674frames. Timing rows are rounded. Balanced flight is the closest current margin; retain these readings for comparison on the eventual wardrobe head. No threshold changed, no source fix was made for this replay, and no timing/GC/runner-noise cause is inferred from one success.

The original failure archive75e08066c250447e180725208be20b3d52d840038358dca03af3af34a6a9999e is included byte-exact. It retains actual attempt1 job119653898622 failure and skipped phone step. Root's exclusive-intent single diagnostic-repeat POST receipt and original-attempt run metadata are copied separately. Original failure is not reclassified as a pass.

Phone logs establish release, picking, detail-switch and no-page-error assertions; reported census byte fields count CPU arrays/source payload released, not measured GPU resident memory. Eighteen smokes remain undispatched under root's current scope; PR1175 is held for the wardrobe fix. This packet does not claim all checks green, a current future head qualified, photographic clothing complete or merge eligibility. A changed wardrobe source/model head needs its applicable actual qualification.
