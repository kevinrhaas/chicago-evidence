from pathlib import Path
import concurrent.futures,datetime,hashlib,json,subprocess,time,re
R=Path(__file__).parent;repo='repos/kevinrhaas/chicago/';head='ad813a6278b7d76961b78ef3483f1bbf3e106c02'
tasks=[('run-live.json','actions/runs/39727250726'),('run-attempt2.json','actions/runs/39727250726/attempts/2'),('jobs-attempt2.json','actions/runs/39727250726/attempts/2/jobs?per_page=100'),('job119661122753.json','actions/jobs/119661122753'),('job119661122753.log','actions/jobs/119661122753/logs'),('attempt2-logs.zip','actions/runs/39727250726/attempts/2/logs')]
def get(task):
 name,endpoint=task;attempts=[]
 for attempt in range(1,4):
  at=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(['gh','api','--method','GET',repo+endpoint],capture_output=True,timeout=60);(R/(name+'.stderr')).write_bytes(p.stderr);attempts.append({'at':at,'method':'GET','endpoint':repo+endpoint,'attempt':attempt,'returncode':p.returncode,'bytes':len(p.stdout),'sha256':hashlib.sha256(p.stdout).hexdigest()})
  if p.returncode==0:(R/name).write_bytes(p.stdout);return attempts
  err=p.stderr.decode(errors='replace');transient=not re.search(r'HTTP (401|403)',err) and re.search(r'HTTP (502|503|504)|unexpected EOF|connection reset',err,re.I)
  if not transient or attempt==3:raise RuntimeError(name+': '+err[-800:])
  time.sleep(2**attempt)
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:rows=list(pool.map(get,tasks))
(R/'GET-REQUESTS.json').write_text(json.dumps([x for rr in rows for x in rr],indent=2)+'\n')
for name in ['run-live.json','run-attempt2.json']:
 j=json.loads((R/name).read_text());assert j['id']==39727250726 and j['head_sha']==head and j['run_attempt']==2 and j['status']=='completed' and j['conclusion']=='success' and j['event']=='workflow_dispatch' and j['head_branch']=='steward/1835-workwear-repair-20261021'
j=json.loads((R/'jobs-attempt2.json').read_text());assert j['total_count']==len(j['jobs'])==1
job=json.loads((R/'job119661122753.json').read_text());assert job['id']==119661122753 and job['run_id']==39727250726 and job['run_attempt']==2 and job['head_sha']==head and job['name']=='moving-frames' and job['status']=='completed' and job['conclusion']=='success'
assert j['jobs'][0]['id']==job['id']
print(json.dumps({'GETs':sum(map(len,rows)),'run':39727250726,'attempt':2,'job':job['id'],'check_run_url':job['check_run_url'],'status':'metadata identity and terminal success verified','all_step_outcomes':[(s['name'],s['conclusion']) for s in job['steps']]},indent=2))
