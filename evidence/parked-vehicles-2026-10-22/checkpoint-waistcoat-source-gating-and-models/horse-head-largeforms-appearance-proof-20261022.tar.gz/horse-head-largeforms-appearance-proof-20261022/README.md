# T2800 head large-form actual outcome

One source-reviewed build, one unchanged independent actual proper-crossing/topology screen, one exact matched four-view capture. Build exit0/.365s; readback exit0/14.273s wall; capture exit0/6.370s. No automatic retry. No app installation, rig, old sockets or ticket closure.

Actual GLB d35679f9 is630584B/26144tri,13074vertices and6material batches. All200412AABB pairs screened: zero strict proper crossings. Two-owner edges/vertex links/Euler2, exact exported positions/indices, finite unit normals, one actual component and49Y0sole vertices per foot pass. Actual sole-vertex meanZ+.5903095mm remains separate from the authored contact-control mean0. Crossing screen does not certify coplanar contact/tangency/containment or concha tissue thickness.

The actual four images and parent772desktop comparisons were personally opened. Jaw/throat and near-quarter ear show partial improvement, but the result remains schematic and rejected as an anatomical/photographic master. Read APPEARANCE-REVIEW.json for concrete visual defects. Root must personally decide the next source scope. Hair/UV/PBR/rig/tack/LODs remain open.

The exact source/caller archives, model, actual terminal logs, camera/clip receipts, independent reader/adaptation and all images are included. Frozen previous packets and original installed89b048 remain untouched.
