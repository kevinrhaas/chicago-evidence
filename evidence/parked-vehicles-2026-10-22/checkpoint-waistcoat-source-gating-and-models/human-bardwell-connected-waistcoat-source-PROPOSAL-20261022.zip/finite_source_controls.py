#!/usr/bin/env python3
import sys;sys.dont_write_bytecode=True
import pathlib,json,importlib.util,hashlib,copy,collections,math,time,ast
D=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(D/'preimages/chicago/4d/tools'))
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
old=module('baseline_workwear',D/'preimages/chicago/4d/tools/human_workwear_fit.py');new=module('proposed_workwear',D/'proposed/chicago/4d/tools/human_workwear_fit.py')
body_path=R/'assets/authored/humans/makehuman_hm08/prepared_adult_25.json';body=json.loads(body_path.read_bytes());body_hash=hashlib.sha256(json.dumps(body,sort_keys=True).encode()).hexdigest();m=body['meshes'][0];bones={b['name']:b for b in body['skeleton']};recipe=json.loads((D/'preimages/chicago/4d/data/humans/recipes/worker_1835.json').read_text());proposed_recipe=json.loads((D/'proposed/chicago/4d/data/humans/recipes/worker_1835.json').read_text());pattern=proposed_recipe['proof_variants'][0]['waistcoat_shoulder_pattern'];configured={**recipe,'waistcoat_shoulder_pattern':pattern};started=time.monotonic();base=old.garment_shell(m,'waistcoat',recipe['waistcoat_offset_m'],recipe,bones,1.75);default=new.garment_shell(m,'waistcoat',recipe['waistcoat_offset_m'],recipe,bones,1.75);changed=new.garment_shell(m,'waistcoat',recipe['waistcoat_offset_m'],configured,bones,1.75)
checks=[]
def check(name,v):
 if not v:raise AssertionError(name)
 checks.append({'name':name,'PASS':True})
check('default geometry/UV/skin/sourcebasis/receipt exactly equals independent preimage helper',base==default)
removed=copy.deepcopy(proposed_recipe);del removed['proof_variants'][0]['waistcoat_shoulder_pattern'];check('recipe only Bardwell explicit opt-in',removed==recipe)
check('body/rig/weights/UV arrays remain unchanged',body_hash==hashlib.sha256(json.dumps(body,sort_keys=True).encode()).hexdigest())
check('nonempty original waistcoat mesh, no extra mesh/material inventory',len(changed['triangles'])>0 and set(changed)==set(base))
check('existing 2.5 percent discarded-mass guard stays satisfied',changed['receipt']['maximum_discarded_cut_weight']<=.025)
check('all new vertex weights normalized/top4',all(0<len(w)<=4 and abs(sum(w.values())-1)<1e-12 and min(w.values())>0 for w in changed['weights']))
check('per-corner source UV count preserved',len(changed['corner_uvs'])==len(changed['triangles']))
check('inherited complete fit remains unaccepted',not changed['receipt']['fit_accepted'] and not changed['receipt']['body_mutated'])
# Recover existing source coordinates solely from retained barycentrics, never
# compare proposed geometry against itself as an anatomical oracle.
src={sid:p for sid,p in zip(m['source_vertex_indices'],m['positions_m'])}
def raw_positions(g):return [[math.fsum(src[sid][a]*w for sid,w in basis.items()) for a in range(3)] for basis in g['source_basis']]
def bridges(g):
 raw=raw_positions(g);adj=collections.defaultdict(set)
 for face in g['triangles']:
  for a,b in zip(face,face[1:]+face[:1]):adj[a].add(b);adj[b].add(a)
 rows=[]
 for side in [-1,1]:
  allowed={i for i,p in enumerate(raw) if p[1]>=1.38 and .04<=side*p[0]<=.18}
  front={i for i in allowed if raw[i][2]>.005 and raw[i][1]>=1.41}
  back={i for i in allowed if raw[i][2]<-.015 and raw[i][1]>=1.41}
  visited=set(front);todo=collections.deque(front)
  while todo:
   i=todo.popleft()
   for j in adj[i]&allowed:
    if j not in visited:visited.add(j);todo.append(j)
  rows.append({'side':side,'front_upper_vertices':len(front),'back_upper_vertices':len(back),'path_above1_38m':bool(visited&back),'upper_allowed_vertices':len(allowed)})
 return rows
negative=bridges(base);positive=bridges(changed);check('original shoulder path negative control fails on both sides',all(not row['path_above1_38m'] for row in negative));check('actual proposed indexed shoulder paths connect upper front/back on both sides',all(row['path_above1_38m'] for row in positive))
# Structural seam/area controls are on actual emitted topology, not just receipts.
edges=collections.Counter();zero=[]
for k,(a,b,c) in enumerate(changed['triangles']):
 p,q,t=[changed['positions_m'][i] for i in (a,b,c)];u=[q[j]-p[j] for j in range(3)];v=[t[j]-p[j] for j in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
 if math.hypot(*cross)<=1e-18:zero.append(k)
 for x,y in ((a,b),(b,c),(c,a)):edges[tuple(sorted((x,y)))]+=1
check('no emitted degenerate triangles',not zero);check('no nonmanifold source-shell edges',max(edges.values())<=2)
raw=raw_positions(changed);max_head=max(sum(w.get(b,0) for b in ['head','jaw']) for w in changed['weights']);check('emitted head/jaw weight stays below existing 2.5 percent cap (not zero influence)',max_head<.025)
check('no authored garment vertex reaches above declared neckline plane',max(p[1] for p in changed['positions_m'])<=bones['neck_01']['head_m'][1]-.025+1e-12)
# Preserve arrays for the separate actual-rig/layer check; not canonical exports.
(D/'generated-source-waistcoat.json').write_text(json.dumps(changed,separators=(',',':'))+'\n')
(D/'baseline-source-waistcoat.json').write_text(json.dumps(base,separators=(',',':'))+'\n')
report={'status':'FINITE_SOURCE_CONTROLS_PASS_NOT_CANONICAL_OR_POSED_FIT_ACCEPTANCE','checks':checks,'body_input':{'path':str(body_path),'sha256':hashlib.sha256(body_path.read_bytes()).hexdigest()},'source_preimage_head':'ad813a6278b7d76961b78ef3483f1bbf3e106c02','baseline':{'vertices':len(base['positions_m']),'triangles':len(base['triangles']),'shoulder_path_negative':negative},'proposal':{'vertices':len(changed['positions_m']),'triangles':len(changed['triangles']),'shoulder_paths':positive,'maximum_head_jaw_weight':max_head,'maximum_discarded_skin_mass':changed['receipt']['maximum_discarded_cut_weight'],'top_Y_m':max(p[1] for p in changed['positions_m'])},'elapsed_seconds':time.monotonic()-started,'remaining':'Forty inherited idle negative projections not waived; actual posed fit/period drape/LOD/canonical/export/pixels/photo remain open. Finite source continuity is not complete fit.'};(D/'FINITE-SOURCE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks_PASS':len(checks),'elapsed_s':report['elapsed_seconds'],'baseline':report['baseline'],'proposal':report['proposal']}))
