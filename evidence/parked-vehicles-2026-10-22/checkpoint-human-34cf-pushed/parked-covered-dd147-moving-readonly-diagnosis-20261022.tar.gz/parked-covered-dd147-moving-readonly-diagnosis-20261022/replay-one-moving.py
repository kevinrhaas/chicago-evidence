#!/usr/bin/env python3
"""Root-only single POST caller, or separate GET-only attempt2 qualifier. No automatic replay."""
import argparse,base64,datetime,hashlib,importlib.util,json,pathlib,re,subprocess,time
P=pathlib.Path(__file__).resolve().parent
REPO='kevinrhaas/chicago'; RUN=39709833379; HEAD='dd147cae0e85f9e39855d0d130da19e782f7eecb'; TREE='5badfa088cfeb4ff9c86e31a1d2221a09c790db3'
BASE='fdb227dbf5ed952921ef652f5a02480fffdad462'; MERGE='74a5e7eec3cbe722a07e10cadff487cadbf343b4'; BRANCH='steward/parked-period-vehicles-20261021'
WF='.github/workflows/chicago-4d-moving-frames.yml'; WFSHA='a337a37dbeafb63654f5eb1f5f5357ed395f33d74405f980a6165edc35bec6c3'
OLDJOB=119598265851; OLDLOG='631e38d85b98a3b312affaeada44f592271468fc1d21bc99df6a4a6a583a2727'
HP=pathlib.Path('/workspace/shared/parked-covered-2981-NEXT-HEAD-CI-HELD/observe-GET-only.py')
spec=importlib.util.spec_from_file_location('helper',HP);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('mode',choices=['post-once','observe']);a=parser.parse_args()
O=P/('ROOT-POST-ONCE' if a.mode=='post-once' else 'ATTEMPT2-GET-ONLY');O.mkdir(exist_ok=False)
start=time.monotonic();deadline=start+(180 if a.mode=='post-once' else 45*60);seq=0
state={'mode':a.mode,'head':HEAD,'tree':TREE,'base':BASE,'merge_checkout':MERGE,'run_id':RUN,'workflow':WF,'started':h.now(),'caller_sha256':h.sha(pathlib.Path(__file__).read_bytes()),'attempt1_failure_log_sha256':OLDLOG,'attempt2_moving_qualification_pass':False,'normal_all_green':False,'POST_count':0}
def save():h.save(O/'state.json',state)
def get(label,endpoint,plain=False):
 global seq
 for attempt in range(1,4):
  h.need(time.monotonic()<deadline,'Finite deadline reached');seq+=1
  r=subprocess.run(['gh','api','--method','GET','repos/'+REPO+'/'+endpoint],capture_output=True,timeout=45)
  stem=O/(f'{seq:04d}-{label}-read{attempt}');stem.with_suffix('.stdout').write_bytes(r.stdout);stem.with_suffix('.stderr').write_bytes(r.stderr)
  err=r.stderr.decode();retry=r.returncode and attempt<3 and not re.search(r'HTTP (401|403)\b',err) and re.search(r'HTTP (502|503|504)\b|unexpected EOF|connection reset by peer|transport read',err,re.I)
  if retry:time.sleep(2**attempt);continue
  h.need(r.returncode==0,'GET failed: '+label+' '+err[-800:]);return r.stdout.decode() if plain else json.loads(r.stdout)
def identity(r,attempt):
 h.need(r['id']==RUN and r['run_attempt']==attempt and r['head_sha']==HEAD and r['head_branch']==BRANCH and r['event']=='pull_request' and r['path']==WF and r['workflow_id']==374947050,'Workflow/run/head/event/attempt identity drift')
 h.need(r['head_commit']['id']==HEAD,'Head commit drift')
def route():
 pr=get('pr','pulls/1174');h.need(pr['state']=='open' and pr['head']['sha']==HEAD and pr['head']['ref']==BRANCH and pr['head']['repo']['full_name']==REPO and pr['base']['ref']=='dev' and pr['base']['sha']==BASE,'PR source or base drift')
 h.need(get('branch','git/ref/heads/'+BRANCH)['object']['sha']==HEAD,'Branch head drift')
 h.need(get('head-commit','git/commits/'+HEAD)['tree']['sha']==TREE,'Source tree drift')
 wf=get('workflow-source','contents/'+WF+'?ref='+HEAD);h.need(h.sha(base64.b64decode(wf['content']))==WFSHA,'Source workflow pin drift')
try:
 h.need(h.sha((P/'dd147-original-failed-moving-log.stdout').read_bytes())==OLDLOG,'Original failure evidence differs')
 route()
 if a.mode=='post-once':
  # Exclusive intent precedes POST. This lock intentionally survives every failure.
  (P/'EXCLUSIVE-POST-INTENT.lock').mkdir(exist_ok=False)
  r=get('original-run','actions/runs/'+str(RUN));identity(r,1);h.need(r['status']=='completed' and r['conclusion']=='failure','Original attempt1 is not terminal failure')
  jobs=get('original-jobs',f'actions/runs/{RUN}/attempts/1/jobs?per_page=100');h.need(jobs['total_count']==len(jobs['jobs'])==1,'Unexpected original jobs')
  j=jobs['jobs'][0];h.need(j['id']==OLDJOB and j['head_sha']==HEAD and j['run_attempt']==1 and j['conclusion']=='failure','Original job differs')
  h.need(h.sha(get('original-log',f'actions/jobs/{OLDJOB}/logs',True).encode())==OLDLOG,'Original failed job log differs')
  state.update(post_intent={'method':'POST','endpoint':f'repos/{REPO}/actions/runs/{RUN}/rerun-failed-jobs','max_posts':1,'retry':False,'created':h.now()});save()
  # ONE POST only. No retry, even on transport ambiguity. Root reconciles any ambiguous result via GET.
  state['POST_count']=1;save()
  r=subprocess.run(['gh','api','--method','POST',state['post_intent']['endpoint']],capture_output=True,timeout=45)
  (O/'POST.stdout').write_bytes(r.stdout);(O/'POST.stderr').write_bytes(r.stderr)
  state.update(post_returncode=r.returncode,post_succeeded=r.returncode==0,post_result='accepted' if r.returncode==0 else 'failed-or-ambiguous; NEVER automatically retry');save();h.need(r.returncode==0,'Single POST failed or ambiguous; preserved, no retry')
 else:
  receipt=json.loads((P/'ROOT-POST-ONCE/state.json').read_text());h.need(receipt.get('post_succeeded') and receipt.get('POST_count')==1 and receipt.get('caller_sha256')==state['caller_sha256'],'Missing exact single-POST receipt')
  state['root_post_receipt_sha256']=h.sha((P/'ROOT-POST-ONCE/state.json').read_bytes());last=None
  while time.monotonic()<deadline:
   tick=time.monotonic();r=get('current-run','actions/runs/'+str(RUN));h.need(r['run_attempt'] in [1,2],'Only one replay allowed');identity(r,r['run_attempt'])
   status=(r['run_attempt'],r['status'],r['conclusion']);state.update(at=h.now(),actual_run_attempt=r['run_attempt'],status=r['status'],conclusion=r['conclusion']);save()
   if status!=last:print(json.dumps(state),flush=True);last=status
   if r['run_attempt']==2 and r['status']=='completed':
    # Attempt-specific route prevents accidentally qualifying the old job.
    ar=get('actual-attempt2',f'actions/runs/{RUN}/attempts/2');identity(ar,2)
    jobs=get('attempt2-jobs',f'actions/runs/{RUN}/attempts/2/jobs?per_page=100');h.need(jobs['total_count']==len(jobs['jobs'])==1,'Exactly one actual attempt2 job required')
    j=jobs['jobs'][0];h.need(j['id']!=OLDJOB and j['run_id']==RUN and j['run_attempt']==2 and j['head_sha']==HEAD and j['name']=='moving-frames','Actual attempt2 job identity differs')
    log=get('attempt2-job-log',f"actions/jobs/{j['id']}/logs",True);state.update(job_id=j['id'],steps=j['steps'],log_sha256=h.sha(log.encode()),log_bytes=len(log.encode()))
    h.need(r['conclusion']==ar['conclusion']==j['conclusion']=='success' and j['status']=='completed','Attempt2 failed; actual log preserved, STOP without another replay')
    for wanted in h.NORMAL[WF][2]:
     ss=[s for s in j['steps'] if s['name']==wanted];h.need(len(ss)==1 and ss[0]['status']=='completed' and ss[0]['conclusion']=='success','Mandatory actual step failed/skipped: '+wanted)
    h.need(all(s['conclusion']=='success' for s in j['steps']),'Unexpected non-success actual step')
    h.need(re.search(r'HEAD is now at 74a5e7ee Merge '+HEAD+' into '+BASE,log),'Actual PR merge checkout drift')
    h.need(re.search(r'Z '+MERGE+r'\s*$',log,re.M) and 'node tools/measure_walk_frames.mjs --only desktop --verify --gate' in log and 'node tools/check_upload_release.mjs' in log,'Actual checkout/commands absent')
    h.need(log.count('PASS — every moving frame inside the ceiling')==1 and 'FAIL —' not in log,'Actual moving result absent/failing')
    h.need('PASS phone: /1904/ still answers a tap on a building after the switch' in log and len(re.findall(r'PASS upload release: \d+ checks',log))==1 and 'FAIL ' not in log,'Actual GPU-release log is incomplete/failing')
    route();state.update(attempt2_moving_qualification_pass=True,scope='Only actual attempt2 moving workflow. Attempt1 failure retained. Gate/report/smoke/root merge eligibility separate.');break
   time.sleep(max(0,min(60-(time.monotonic()-tick),deadline-time.monotonic())))
  h.need(state['attempt2_moving_qualification_pass'],'45minute bound without qualified attempt2')
except Exception as e:state['error']=str(e)
finally:
 state.update(ended=h.now(),elapsed_seconds=time.monotonic()-start,GET_requests=seq);save();print(json.dumps(state),flush=True)
raise SystemExit(1 if state.get('error') else 0)
