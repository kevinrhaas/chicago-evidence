# Finite moving-frame diagnosis and HELD one-replay packet

No rerun has been submitted. Original dd147 attempt1 failure is preserved byte for byte. Root alone may execute the one POST caller after the separate gate continuation reaches its terminal result.

The exact original e694 moving workflow actually passed: run39705450622, attempt1, job119584298795. Its GET-fetched complete job log is here (SHA180aa97e4c1615a1e00ee637c7af69a821b8ec6551225f61557c6b731ef79203). All mandatory moving AND GPU-upload-release steps passed; the existing strict attempt1 auditor passed against the actual fetched job. This earlier result is diagnostic evidence only, not fresh dd147 qualification.

Light flora p95/max milliseconds:

|Move|e694|dd147 original|
|---|---:|---:|
|Walk|0.5/3.4|0.5/3.8|
|Turn,480frames|2.6/5.2|3.1/22.7 FAIL|
|Flight|0.6/4.1|0.8/3.4|
|Travel|1.0/6.0|1.9/4.4|

Light's unchanged limits are p957ms and maximum21ms. dd147 failed exactly one reading. Turn frame median/p95/max was0.4/3.4/23.4ms, one frame>16ms and none>33/50ms. Trees p95/max0.1/0.5; ground-reach max2.6. These separate maxima are not guaranteed to describe the same frame.

Both actual logs identify Node22.23.3/npm10.9.9, Playwright1.56.1, Chromium141.0.7390.37(build1194), ANGLE Vulkan1.3 SwiftShader, runner2.338.0, Ubuntu24.04.5 image20261018.339.1. Azure workers differ: e694 southcentralus, dd147 eastus. Both PR merges use base fdb227dbf5ed952921ef652f5a02480fffdad462. Exact independent source pins cover unchanged main.js/flora.js, measuring/release tools and workflow. Root's fuller projection proves unchanged renderer/scene/recipes/GLBs; only authoring/provenance and STATUS differ.

No causal attribution follows from this. The tool times wall elapsed around the whole flora.update, including GPU keep, carry-tail landing and far/near generators. Near landing max0.7ms is too small to identify the22.7ms sample. Aggregate far-pass42.6ms includes work across slices and held-loop frames: it is not a measured innercallee of the failing sample. Without --profile or --long-ms below23.4, the original job supplies no exact failing-frame innercallee trace. The page also keeps ticking between driven frames, and pass/worker scheduling differs: old/new Light turn spread13/21, held-loop170calls133ms/173calls170ms, far36/40passes. All Light-turn raw stat lines and all12 tier/move readings are saved, without hiding these differences. No flora/source/threshold change is justified by these logs alone.

A single same-run replay can test repeatability at unchanged source and context. The endpoint is POST actions/runs/39709833379/rerun-failed-jobs: the sole failed moving job runs again, including its previously skipped upload-release step; no other workflow/grid is rerun. GitHub increments run_attempt to2 and issues a new job ID, preserving event/head/workflow context. The original attempt1 failure remains evidence. A new workflow_dispatch has a different event/ref checkout context and is less suitable here.

Observed cost: e694 complete job12m08 (moving3m10, release6m48), dd147 failed job6m53 (moving4m12, release skipped). Workflow timeout30minutes; held reader bound45minutes with >=60sec polling. Root accepts one replay only, no optimization/replay loop.

HELD commands (root must read and execute explicitly; neither has been run):

    python /workspace/shared/parked-covered-dd147-moving-readonly-diagnosis-20261022/replay-one-moving.py post-once
    python /workspace/shared/parked-covered-dd147-moving-readonly-diagnosis-20261022/replay-one-moving.py observe

The caller verifies exact remote branch/tree/PR base/workflow, exact original failed run/job/log and creates a permanent exclusive intent lock BEFORE one POST. It never retries a POST, including transport ambiguity. Do not remove the lock to retry. The reader is GET-only, requires that exact accepted caller receipt, actual attempt2 run/job, all mandatory successful steps including release, full original merge checkout SHA, actual moving PASS and terminal upload-release PASS. It preserves actual logs on failure and stops; it cannot declare all normal workflows green. GET retries only502/503/504/EOF/reset with2/4sec delays; no401/403 retry. Python compile passed. No caller/reader execution, browser or CI mutation was performed in preparing this packet.
