# Actual bounded run — FAILED and CLOSED, no retry

Root released this one attempt after human fullgate1041/380PASS and commit34cf462ed/publisher/mirror completion. The actual owner ran2026-10-22 02:39:59–02:40:01UTC,2.385seconds,exit1. Both browser and localhost server closed; local lane is free. No app/index/Git/mirror/CI or geometry was changed.

Three normal desktop V9baseline screenshots were saved: quarter/front/profile. All have exact03c333af model bytes,30782source triangles,fullvehicle/pole framing,originalshadowsON/normalBias0,49renderer calls/61566render triangles,GL0 and no captured browser/page/console/request/HTTPerrors. These are partial before-only observations, not a preview pass. Image hashes match actual receipt.

The first arm's disposal guard then FAILED:25/25geometry and7/7material disposal events, idempotent=true,sceneChildren0,remainingGeometries0, but remainingTextures1 against required0. The thrown actual error retains those metrics in actual/receipt.json. This is observed residual texture accounting after the inherited fixture cleanup. Its exact resource/cause was not established; it cannot be asserted as a V10model leak, a photographic failure or an application regression. No guard was weakened, no fixture/source repaired, and no retry occurred.

V10 WAS NEVER LOADED OR RENDERED. Mobile was never reached. No A/B,roofimprovement,12frame/disposalPASS or photographic claim is possible. V10continues to have sourceproof only.

The quarter/profile V9PNGswere actually viewed after failure. They show the full central pole and coherent original cabin/wheel silhouette; the forward roof curl remains visible in profile. The simple smooth finish and unverified construction still fall below photographic quality. No V10appearance was inferred. Both are isolated original fixture lighting, not production app views, and fullvehicleframing differs from the catalog crop.

RELEASE/RUN-INTENT,actual/receipt,all3PNG/verifiedhashes,SERVER-CLOSED,stdout/stderr and frozeninputs remain intact. ACTUAL-FAILURE-SUMMARY.json supplies the compact exact result. Further activity requires a separately scoped root decision; this finite task stopped at its first failure as instructed.
