"""Read-only actual GLB readback; no producer, app edit or acceptance render."""
from pathlib import Path
import hashlib,importlib.util,io,json,struct
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('surface_readback_helpers',ROOT/'refine_timber_surface.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
source=(m.ROOT/'renderers/web/transport/parked-wagon/wagon-w01.glb').read_bytes();actual=(ROOT/'candidate-normalized/wagon-w01.glb').read_bytes();before,bb=m.unpack(source);after,ab=m.unpack(actual)
def geometry(g,b):
 records=[];triangles=0;uv_min=float('inf');normal_dot=0.;tangent_error=0.;cap_count=0
 for mesh in g['meshes']:
  for primitive in mesh['primitives']:
   p=m.array(g,b,primitive['attributes']['POSITION']);n=m.array(g,b,primitive['attributes']['NORMAL']);ids=m.array(g,b,primitive['indices']).reshape(-1)if'indices'in primitive else np.arange(len(p));assert len(ids)%3==0 and ids.min()>=0 and ids.max()<len(p);triangles+=len(ids)//3;faces=np.concatenate([p[ids].reshape(-1,9),n[ids].reshape(-1,9)],axis=1).astype('<f4');records.extend(row.tobytes()for row in faces)
   material=g['materials'][primitive['material']]
   if material['name']in ['timber','plank_a','plank_b','timber_cut_end','plank_a_cut_end','plank_b_cut_end']:
    uv=m.array(g,b,primitive['attributes']['TEXCOORD_0'])[ids].reshape(-1,3,2);cross=(uv[:,1,0]-uv[:,0,0])*(uv[:,2,1]-uv[:,0,1])-(uv[:,1,1]-uv[:,0,1])*(uv[:,2,0]-uv[:,0,0]);uv_min=min(uv_min,float(abs(cross).min()));t=m.array(g,b,primitive['attributes']['TANGENT']);normal_dot=max(normal_dot,float(abs(np.einsum('ij,ij->i',t[:,:3],n)).max()));tangent_error=max(tangent_error,float(abs(np.linalg.norm(t[:,:3],axis=1)-1).max()))
    if material['name'].endswith('_cut_end'):cap_count+=len(ids)//3
 return {'signature':hashlib.sha256(b''.join(sorted(records))).hexdigest(),'triangles':triangles,'minimum_wood_UV_double_area':uv_min,'max_tangent_normal_dot':normal_dot,'max_tangent_length_error':tangent_error,'cut_end_triangles':cap_count}
left=geometry(before,bb);right=geometry(after,ab);assert left['signature']==right['signature']and left['triangles']==right['triangles']==12104;assert right['minimum_wood_UV_double_area']>1e-14
protected={k:before.get(k)==after.get(k)for k in ['nodes','skins','animations','scenes','scene']};assert all(protected.values());assert ab[:len(bb)]==bb
def mapped_images(g,b):
 materials={p['material']for mesh in g['meshes']for p in mesh['primitives']};textures=set()
 for i in materials:
  mat=g['materials'][i];pbr=mat.get('pbrMetallicRoughness',{})
  for owner,key in [(pbr,'baseColorTexture'),(pbr,'metallicRoughnessTexture'),(mat,'normalTexture'),(mat,'occlusionTexture')]:
   if key in owner:textures.add(owner[key]['index'])
 images={g['textures'][i]['source']for i in textures};rows=[];total=0
 for i in sorted(images):
  payload=m.image_bytes(g,b,i);im=Image.open(io.BytesIO(payload));w,h=im.size;count=0
  while True:
   count+=w*h*4
   if w==h==1:break
   w=max(1,w//2);h=max(1,h//2)
  total+=count;rows.append({'image':i,'pixels':im.size,'sha256':hashlib.sha256(payload).hexdigest(),'RGBA8_all_mip_dimensions_bytes':count})
 return {'images':rows,'RGBA8_all_mip_dimensions_bytes':total,'scope':'Dimension-derived RGBA8 estimate only; actual GPU allocation/driver/format unmeasured'}
old_images=mapped_images(before,bb);new_images=mapped_images(after,ab)
for mi in [0,4]:
 assert before['materials'][mi]==after['materials'][mi]
 mat=before['materials'][mi]
 for owner,key in [(mat['pbrMetallicRoughness'],'baseColorTexture'),(mat['pbrMetallicRoughness'],'metallicRoughnessTexture'),(mat,'normalTexture')]:
  i=before['textures'][owner[key]['index']]['source'];assert m.image_bytes(before,bb,i)==m.image_bytes(after,ab,i)
# Deliberately corrupt actual POSITION bytes in memory: independent oriented-
# face signature must reject it. No file or accepted geometry is changed.
first=after['meshes'][0]['primitives'][0]['attributes']['POSITION'];accessor=after['accessors'][first];view=after['bufferViews'][accessor['bufferView']];offset=view.get('byteOffset',0)+accessor.get('byteOffset',0);bad=bytearray(ab);value=struct.unpack_from('<f',bad,offset)[0];struct.pack_into('<f',bad,offset,value+1);negative=geometry(after,bad)['signature']!=left['signature'];assert negative
variant_pins={str(p.relative_to(m.ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in (m.ROOT/'renderers/web/transport/covered-wagon').glob('**/*.glb')};variant_pins['data/transport/parked/covered-w01.json']=hashlib.sha256((m.ROOT/'data/transport/parked/covered-w01.json').read_bytes()).hexdigest()
result={'status':'ACTUAL_INDEPENDENT_STRUCTURE_PASS_UNRENDERED','geometry_before':left,'geometry_after':right,'protected_scene_nodes_and_articulation':protected,'old_binary_prefix_exact':True,'paint_and_iron_materials_and_images_exact':True,'all_original_color_factors_exact':all(before['materials'][i]['pbrMetallicRoughness']['baseColorFactor']==after['materials'][i]['pbrMetallicRoughness']['baseColorFactor']for i in range(len(before['materials']))),'corrupted_POSITION_negative_control_rejected':negative,'active_images_before':old_images,'active_images_after':new_images,'other_variant_file_pins_readonly':variant_pins,'other_variant_scope':'No variant file was written; current pins retained for next integrator, not a claim that this candidate already supports covered-variant ownership','candidate_sha256':hashlib.sha256(actual).hexdigest(),'Khronos_validation':'not run; local package unavailable, no install/network requested','visual_period_world_acceptance':False}
(ROOT/'ACTUAL-INDEPENDENT-READBACK.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['active_images_before','active_images_after','other_variant_file_pins_readonly']},indent=2));print(json.dumps({'RGBA8_mip_dimensions_before':old_images['RGBA8_all_mip_dimensions_bytes'],'RGBA8_mip_dimensions_after':new_images['RGBA8_all_mip_dimensions_bytes'],'untouched_other_variant_files_pinned':len(variant_pins)}))
