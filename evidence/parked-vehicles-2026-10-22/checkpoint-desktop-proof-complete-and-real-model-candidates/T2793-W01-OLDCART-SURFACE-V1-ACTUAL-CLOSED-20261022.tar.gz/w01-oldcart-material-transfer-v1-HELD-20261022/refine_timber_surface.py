"""GPL-3.0-or-later. Bounded W01 timber-surface derivative, no geometry edit.

CC BY4 Old Cart clean timber detail; original CC0 end-grain pixels. Not a
dated/identified wagon or photographic/period appearance qualification.
"""
import argparse,copy,hashlib,io,json,math,struct,time
from pathlib import Path
import numpy as np
from PIL import Image

SOURCE_SHA='13600b73c1777545e1454d452c58d141469f031b2c5e6c29b1c6fdefe9145046'
PARENT_SHA='274e737b51872983df792d0b24de8e75de8631890a8d586a32d9c6f0066484fb'
PARTS_SHA='2fb3709d233e896280c50342618c28f9e340029e52c67b328100e05a125e2c27'
CROP=(372,145,412,290) #128 exact UV witnesses + actually viewed clean timber.
SOURCE_DIRECTORY=Path('/workspace/shared/transport-two-public-GLBs-ACTUAL-AUDIT-20261022')
ROOT=Path('/tmp/chicago-covered-sag/chicago/4d')
ATTRIBUTION='Timber detail adapted from "Old Cart" by Lyskilde (longtail), https://sketchfab.com/3d-models/old-cart-f536745fd82144eeb5cc4900a48e816e , CC BY4.0 https://creativecommons.org/licenses/by/4.0/ . Changes: clean timber-only crop,90-degree rotation, reflected periodic extension, neutral linear-color normalization, roughness normalization and tangent-normal rotation. No donor geometry or portrait pixels used. Original W01 geometry retains GPL-3.0-or-later; newly authored end-grain pixels CC0-1.0. No period/maker/Dearborn/Chicago identification supplied by the donor.'
def need(value,message):
 if not value:raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
def unpack(raw):
 need(struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw)),'Valid GLB2 required');n=struct.unpack_from('<I',raw,12)[0];return json.loads(raw[20:20+n]),raw[28+n:]
def array(g,b,i):
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];dtype={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];dim={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];s=np.dtype(dtype).itemsize
 return np.ndarray((a['count'],dim),dtype=dtype,buffer=b,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',s*dim),s)).copy()
def image_bytes(g,b,i):
 v=g['bufferViews'][g['images'][i]['bufferView']];return b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
def to_srgb(a):return np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055)
def from_srgb(a):return np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
def png(a):
 f=io.BytesIO();Image.fromarray(np.asarray(a,dtype=np.uint8)).save(f,format='PNG',compress_level=6);return f.getvalue()
def resize(a):return np.asarray(Image.fromarray(np.asarray(a,dtype=np.uint8)).resize((512,128),Image.Resampling.LANCZOS)).copy()
def mirror(a,normal=False):
 b=a[:,::-1].copy()
 if normal:b[:,:,0]*=-1
 row=np.concatenate([a,b],axis=1);other=row[::-1].copy()
 if normal:other[:,:,1]*=-1
 return np.concatenate([row,other],axis=0)

def donor_tiles(source,metadata,annotation,out):
 need(sha(source)==SOURCE_SHA,'Exact OldCart input required');need(metadata['license']['slug']==annotation['license']=='by','Individual CC BY license required');need(metadata['user']['uid']==annotation['user']['uid']=='08f2163538df44258a5da0f0d95fd89b','Creator mismatch')
 g,b=unpack(source);m=g['materials'][0];need(m['name']=='CartBase'and m['pbrMetallicRoughness']['metallicFactor']==0,'Selected original timber material changed');tex=g['textures'];base_index=tex[m['pbrMetallicRoughness']['baseColorTexture']['index']]['source'];normal_index=tex[m['normalTexture']['index']]['source'];orm_index=tex[m['pbrMetallicRoughness']['metallicRoughnessTexture']['index']]['source'];images=[np.asarray(Image.open(io.BytesIO(image_bytes(g,b,i))).convert('RGB'))for i in [base_index,normal_index,orm_index]]
 need([base_index,normal_index,orm_index]==[0,2,1],'Actual image-channel assignment changed');x0,y0,x1,y1=CROP;crop=[a[y0:y1,x0:x1]for a in images];need(crop[0].shape==(145,40,3),'Crop dimensions changed')
 # UV grid must land in actual CartBase texture islands; no CartDetails fallback.
 uv_tri=[]
 for mesh in g['meshes']:
  for primitive in mesh['primitives']:
   if primitive.get('material')!=0:continue
   uv=array(g,b,primitive['attributes']['TEXCOORD_0']);ids=array(g,b,primitive['indices']).reshape(-1)if'indices'in primitive else np.arange(len(uv));uv_tri.extend(uv[ids].reshape(-1,3,2))
 uvt=np.array(uv_tri);a=uvt[:,0];e1=uvt[:,1]-a;e2=uvt[:,2]-a;det=e1[:,0]*e2[:,1]-e1[:,1]*e2[:,0];valid=np.abs(det)>1e-14;owned=[]
 for y in np.linspace(y0+.5,y1-.5,16):
  for x in np.linspace(x0+.5,x1-.5,8):
   q=np.array([x/1024,y/1024])-a;u=np.zeros(len(det));v=u.copy();u[valid]=(q[valid,0]*e2[valid,1]-q[valid,1]*e2[valid,0])/det[valid];v[valid]=(e1[valid,0]*q[valid,1]-e1[valid,1]*q[valid,0])/det[valid];hit=np.flatnonzero(valid&(u>=-1e-7)&(v>=-1e-7)&(u+v<=1+1e-7));need(len(hit)>0,'Selected crop leaves actual CartBase UV island');owned.extend(hit.tolist())
 # Rotate vertical grain to U.90CCW: tangent vector(nx,ny)->(ny,-nx).
 color=np.rot90(crop[0]);normal=np.rot90(crop[1]).astype(float)/127.5-1;normal=normal[:,:,[1,0,2]]*np.array([1,-1,1]);orm=np.rot90(crop[2]);linear=from_srgb(color/255);luma=linear@np.array([.2126,.7152,.0722]);centered=luma-float(luma.mean());normalized=.5+.25*centered/max(float(np.abs(centered).max()),1e-12);need(float(normalized.max())<1 and float(normalized.min())>0,'Linear normalization clips timber');neutral=np.repeat(normalized[:,:,None],3,axis=2);color_out=resize(np.round(to_srgb(mirror(neutral))*255));normal_out=resize(np.round((mirror(normal,True)*.5+.5)*255));nn=normal_out/127.5-1;nn/=np.linalg.norm(nn,axis=2,keepdims=True);normal_out=np.round((nn*.5+.5)*255).astype('uint8');rough=orm[:,:,1].astype(float)/255;rough=np.clip(rough-rough.mean()+.84,.60,.98);rough_out=resize(np.round(mirror(np.stack([np.ones_like(rough),rough,np.zeros_like(rough)],2))*255));maps={'color':color_out,'normal':normal_out,'orm':rough_out}
 report={'crop_pixels':list(CROP),'source_images':{'basecolor':base_index,'normal':normal_index,'orm':orm_index},'crop_cartbase_UV_grid_owned':128,'owner_material':'CartBase','owned_UV_triangles':sorted(set(owned)),'wood_dielectric_metallicFactor':0,'crop_basecolor_min_max':[int(crop[0].min()),int(crop[0].max())],'actual_color_source_native_pixels':[145,40],'output_pixels':[512,128],'tile_m':[2*.14*145/40,.28],'actual_periodic_extension':'Mirrored in U/V; tangent-normal corresponding component sign corrected','normal_rotation':'90CCW tangent(nx,ny)->(ny,-nx), then mirror component signs','linear_mean_before':float(luma.mean()),'normalized_linear_mean_before_quantization':float(neutral.mean()),'final_linear_mean':float(from_srgb(color_out/255).mean()),'normal_length_max_error':float(np.abs(np.linalg.norm(normal_out/127.5-1,axis=2)-1).max()),'normal_strength':.35,'roughness_normalization_target':.84,'occlusion_not_copied':True,'no_donor_geometry_or_paint_pixels':True,'period_attribution':'Unestablished'}
 for k,v in maps.items():(out/('oldcart_timber_'+k+'.png')).write_bytes(png(v))
 return maps,report

def end_tiles(out):
 # Original unmeasured cut-end appearance; no species/growth-age claim. Pith
 # offset outside the tile prevents every board showing a centered bullseye.
 n=128;y,x=np.mgrid[0:n,0:n]/n;xx=x+1.3;yy=y-.35;r=np.sqrt((xx+.018*np.sin(yy*13))**2+(yy*1.07)**2);phase=2*np.pi*(r*16+.10*np.sin(x*6+y*4));field=np.sin(phase)*.045+.014*np.sin(x*127+y*53);color=np.repeat(to_srgb(.5*(1+field))[:,:,None],3,axis=2);height=.000008*np.sin(phase);dy,dx=np.gradient(height,.14/n,.14/n);normal=np.stack([-dx,-dy,np.ones_like(dx)],2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);orm=np.stack([np.ones_like(x),.88+field*.2,np.zeros_like(x)],2)
 maps={'color':np.round(color*255).astype('uint8'),'normal':np.round((normal*.5+.5)*255).astype('uint8'),'orm':np.round(orm*255).astype('uint8')}
 for k,v in maps.items():(out/('original_cutend_'+k+'.png')).write_bytes(png(v))
 return maps

def refine(parent,parts,source,metadata,annotation,output):
 start=time.monotonic();need(not output.exists(),'Fresh output required');output.mkdir();(output/'textures').mkdir();need(sha(parent)==PARENT_SHA,'Exact parkedW01 parent only');need(sha(parts)==PARTS_SHA,'Exact authored ownership required');rows=json.loads(parts);g,oldbin=unpack(parent);before=copy.deepcopy(g);binary=bytearray(oldbin);wood,wood_report=donor_tiles(source,metadata,annotation,output/'textures');ends=end_tiles(output/'textures');need([m['name']for m in g['materials']]==['paint','timber','plank_a','plank_b','iron','end_grain'],'Source material identities changed')
 def view(data,target=None):
  binary.extend(b'\0'*((-len(binary))%4));i=len(g['bufferViews']);v={'buffer':0,'byteOffset':len(binary),'byteLength':len(data)}
  if target:v['target']=target
  g['bufferViews'].append(v);binary.extend(data);return i
 def attr(a,component=5126):
  dtype='<f4'if component==5126 else'<u4';a=np.asarray(a,dtype=dtype);vi=view(a.tobytes(),34962 if component==5126 else 34963);i=len(g['accessors']);entry={'bufferView':vi,'componentType':component,'count':len(a),'type':'SCALAR'if a.ndim==1 else'VEC'+str(a.shape[1])}
  if component==5126:entry.update(min=a.min(0).tolist(),max=a.max(0).tolist())
  g['accessors'].append(entry);return i
 def new_texture(data):
  vi=view(data);ii=len(g['images']);g['images'].append({'bufferView':vi,'mimeType':'image/png'});ti=len(g['textures']);g['textures'].append({'source':ii,'sampler':0});return ti
 # Replace exactly the shared wood images; paint/iron image objects and payloads
 # remain unchanged. Separate original cut-end images need no donor attribution.
 wood_refs={}
 for kind,field in [('color','baseColorTexture'),('normal','normalTexture'),('orm','metallicRoughnessTexture')]:
  mat=g['materials'][1];holder=mat if kind=='normal'else mat['pbrMetallicRoughness'];ti=holder[field]['index'];ii=g['textures'][ti]['source'];g['images'][ii]={'bufferView':view(png(wood[kind])),'mimeType':'image/png'};wood_refs[kind]=ti
 end_refs={k:new_texture(png(v))for k,v in ends.items()};cut_material={}
 for mi in [1,2,3]:
  g['materials'][mi]['normalTexture']['scale']=.35;clone=copy.deepcopy(g['materials'][mi]);clone['name']=g['materials'][mi]['name']+'_cut_end';clone['pbrMetallicRoughness']['baseColorTexture']={'index':end_refs['color']};clone['pbrMetallicRoughness']['metallicRoughnessTexture']={'index':end_refs['orm']};clone['normalTexture']={'index':end_refs['normal'],'scale':.35};clone['extras']={'license':'CC0-1.0 original cut-end pixels; original W01 geometry GPL-3.0-or-later','scope':'Original unmeasured cut-end reconstruction; no attested species/growth age/finish'};cut_material[mi]=len(g['materials']);g['materials'].append(clone)
 stats=[];tangent_errors=[];all_caps=0;uv_scale=np.array([2.24/wood_report['tile_m'][0],.14/wood_report['tile_m'][1]])
 for mesh in g['meshes']:
  need(len(mesh['primitives'])==1,'Single source primitive ownership');primitive=mesh['primitives'][0];mi=primitive['material']
  if mi not in [1,2,3]:continue
  matches=[r for r in rows if r['frame']+'_'+before['materials'][r['material']]['name']==mesh['name']];need(matches,'Missing authored part ownership');pos=array(before,oldbin,primitive['attributes']['POSITION']);normal=array(before,oldbin,primitive['attributes']['NORMAL']);need(np.array_equal(pos,np.asarray([p for r in matches for p in r['positions']],dtype='<f4')),'Authored part actual-position mismatch');uv_old=array(before,oldbin,primitive['attributes']['TEXCOORD_0']);uv=uv_old.astype(float)*uv_scale;tangent=array(before,oldbin,primitive['attributes']['TANGENT']);keep=[];caps=[];cursor=0
  for r in matches:
   lp=np.array(r['local_positions']);center=(lp.min(0)+lp.max(0))/2;values,axes=np.linalg.eigh(np.cov((lp-center).T));axes=axes[:,np.argsort(values)[::-1]]
   for k in range(3):
    if axes[np.argmax(np.abs(axes[:,k])),k]<0:axes[:,k]*=-1
   phase=int(hashlib.sha256(r['name'].encode()).hexdigest()[:8],16)/2**32;count=0
   for offset in range(0,len(lp),3):
    i=cursor+offset;q=uv_old[i:i+3];area=np.linalg.det(np.stack([q[1]-q[0],q[2]-q[0]]));selected=abs(area)<1e-14
    if selected:
     # Only previously constant unpainted caps receive end grain. Painted hubs
     # and all metal remain original, including original UV and images.
     new_uv=np.stack([lp[offset:offset+3]@axes[:,1]/.14+phase,lp[offset:offset+3]@axes[:,2]/.14+.37],axis=1);du=np.stack([new_uv[1]-new_uv[0],new_uv[2]-new_uv[0]]);need(abs(np.linalg.det(du))>1e-14,'Nondegenerate cut-end chart required');der=np.linalg.solve(du,np.stack([pos[i+1]-pos[i],pos[i+2]-pos[i]]));uv[i:i+3]=new_uv
     for j,n in enumerate(normal[i:i+3]):
      tt=der[0]-n*np.dot(n,der[0]);tt/=np.linalg.norm(tt);w=1 if np.dot(np.cross(n,tt),der[1])>0 else-1;tangent[i+j]=[*tt,w];tangent_errors.append(abs(float(np.dot(tt,n))))
     caps.extend(range(i,i+3));count+=1
    else:keep.extend(range(i,i+3))
   stats.append({'part':r['name'],'batch':mesh['name'],'triangles':len(lp)//3,'new_cut_end_triangles':count,'longitudinal_axes_original_chart_retained':True});cursor+=len(lp)
  need(cursor==len(pos),'Part stream ownership incomplete');primitive['attributes']['TEXCOORD_0']=attr(uv);primitive['attributes']['TANGENT']=attr(tangent);need('indices'not in primitive,'Expected original source triangle soup');primitive['indices']=attr(keep,5125)
  if caps:
   cap=copy.deepcopy(primitive);cap['indices']=attr(caps,5125);cap['material']=cut_material[mi];mesh['primitives'].append(cap)
  all_caps+=len(caps)//3
 # Strong actual readback of ordered oriented POSITION/NORMAL triangles per
 # original batch after splitting material primitives. Sorting changes no face.
 for mesh,original in zip(g['meshes'],before['meshes']):
  op=original['primitives'][0];need(all(p['attributes']['POSITION']==op['attributes']['POSITION']and p['attributes']['NORMAL']==op['attributes']['NORMAL']for p in mesh['primitives']),'Geometry accessor changed');indices=[]
  for primitive in mesh['primitives']:
   indices.extend(array(g,binary,primitive['indices']).reshape(-1).tolist()if'indices'in primitive else range(before['accessors'][op['attributes']['POSITION']]['count']))
  n=before['accessors'][op['attributes']['POSITION']]['count'];need(sorted(indices)==list(range(n)),'Face omitted/duplicated');need(all(indices[i+1]==indices[i]+1 and indices[i+2]==indices[i]+2 for i in range(0,len(indices),3)),'Oriented triangle changed')
 for key in ['nodes','skins','animations','scenes','scene']:need(g.get(key)==before.get(key),'Protected '+key+' changed')
 for mi in [0,4,5]:need(g['materials'][mi]==before['materials'][mi],'Paint/iron/unused-original material changed')
 need(binary[:len(oldbin)]==oldbin,'Old BIN not exact');g['asset']['copyright']=ATTRIBUTION;g['extras']['timber_surface_candidate']={'scope':'HELD source-only originalW01 surface derivative; photographic/period/world/variant gates OPEN','donor':'OldCart Lyskilde/longtail CC-BY-4.0','donor_model_sha256':SOURCE_SHA,'parent_sha256':PARENT_SHA,'geometry_articulation_color_factors_unchanged':True,'source_pixels_native_crop':list(CROP),'painted_hubs':'unchanged; not made into false unpainted cut ends'};binary.extend(b'\0'*((-len(binary))%4));g['buffers'][0]['byteLength']=len(binary);head=json.dumps(g,separators=(',',':')).encode();head+=b' '*((-len(head))%4);raw=struct.pack('<III',0x46546c67,2,28+len(head)+len(binary))+struct.pack('<II',len(head),0x4e4f534a)+head+struct.pack('<II',len(binary),0x004e4942)+binary;(output/'wagon-w01.glb').write_bytes(raw);(output/'ATTRIBUTION.txt').write_text(ATTRIBUTION+'\n');receipt={'status':'ACTUAL_SURFACE_STRUCTURE_PASS_UNRENDERED','parent_sha256':PARENT_SHA,'donor_sha256':SOURCE_SHA,'parts_sha256':PARTS_SHA,'candidate_sha256':sha(raw),'candidate_bytes':len(raw),'triangles':12104,'mesh_count':len(g['meshes']),'before_primitives':sum(len(m['primitives'])for m in before['meshes']),'candidate_primitives':sum(len(m['primitives'])for m in g['meshes']),'source_material_count':len(before['materials']),'candidate_material_count':len(g['materials']),'cut_end_triangles':all_caps,'oldBINprefix_exact':True,'positions_normals_oriented_faces_exact':True,'nodes_pivots_skins_animations_scenes_exact':True,'all_original_color_factors_unchanged':all(g['materials'][i]['pbrMetallicRoughness']['baseColorFactor']==before['materials'][i]['pbrMetallicRoughness']['baseColorFactor']for i in range(len(before['materials']))),'paint_iron_hubs_unchanged':True,'texel_source':wood_report,'endgrain_original_unmeasured':True,'tangent_normal_dot_max':max(tangent_errors,default=0),'part_metrics':stats,'decoded_active_RGBA8_mips_estimate':((512*128+128*128)*3+1024*64*3+256*256*3)*4*4//3,'all_other_variants_untouched':'No other asset read-write operations; this exact-parent study is parkedW01 only','elapsed_seconds':time.monotonic()-start};(output/'ACTUAL-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');return receipt

if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();receipt=refine((ROOT/'renderers/web/transport/parked-wagon/wagon-w01.glb').read_bytes(),Path('/workspace/shared/w01-combined-refinement-next/hardware-recapture/authored-parts.json').read_bytes(),(SOURCE_DIRECTORY/'f536745fd82144eeb5cc4900a48e816e.glb').read_bytes(),json.loads((SOURCE_DIRECTORY/'f536745fd82144eeb5cc4900a48e816e-model.json').read_text()),json.loads((SOURCE_DIRECTORY/'f536745fd82144eeb5cc4900a48e816e-objaverse-original-annotation.json').read_text()),args.output);print(json.dumps({k:v for k,v in receipt.items()if k not in ['part_metrics','texel_source']},indent=2))
