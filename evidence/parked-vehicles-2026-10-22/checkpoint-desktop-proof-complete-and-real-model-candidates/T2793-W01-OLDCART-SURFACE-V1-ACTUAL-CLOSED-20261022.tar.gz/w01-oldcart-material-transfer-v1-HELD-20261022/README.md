# W01 timber surface derivativeV1 — HELD, unrendered

Root-owned T2793 follow-up. Current people PR1175 and all app/Git/ticket files are untouched. One actual surface candidate was built outside the app; its native primitive cost is unsuitable to assume harmless. ArchiveV1 before any atlas follow-up.

## Actual source/licence

“Old Cart” by Lyskilde / longtail, https://sketchfab.com/3d-models/old-cart-f536745fd82144eeb5cc4900a48e816e , CC BY4.0 https://creativecommons.org/licenses/by/4.0/ . Both retained creator metadata and the individual Objaverse annotation say BY and identify author UID08f2163538df44258a5da0f0d95fd89b. The licence permits redistribution/adaptation including commercially, with attribution, licence link and changes identified. Source metadata/annotation and attribution are included. This does not make the model1835, a Dearborn, a Chicago specimen, a known maker or a historically dated cart. No donor geometry was used.

Donor GLB: `/workspace/shared/transport-two-public-GLBs-ACTUAL-AUDIT-20261022/f536745fd82144eeb5cc4900a48e816e.glb`, SHA25613600b73c1777545e1454d452c58d141469f031b2c5e6c29b1c6fdefe9145046. This9,809,548-byte source is already archived by root; this capsule does not duplicate it.

Only the CartBase timber atlas is used. CartDetails mixes hardware, wheel and timber islands and is excluded. Actual viewed clean crop is x372..411/y145..289:145×40 native pixels.128 exact UV point witnesses lie inside the real CartBase timber island (triangles535/536/541/542/557/558/567/568). No painted hardware, joint strip, dark AO band or texture padding is transferred. Material is dielectric; donor AO/metal channels are not copied. The wider first crop failed ownership before any pixels were transferred; an attempted narrowed crop still intersected a thin UV gap. Those refusals and exact point diagnosis are retained. A Python parse/schema error also preceded any candidate execution and is recorded rather than presented as a numerical failure.

Basecolor/detail changes: rotate vertical grain90CCW to W01U; rotate tangent normal components correctly; reflect tile in both axes with the matching normal sign changes; map luminance to zero-DC bounded contrast .5+.25*(L−mean)/maxabs. This preserves source relative linear variations and the old neutral mean without clipping. The naive .5/mean multiplication failed its gamut guard and is retained. Source hue does not override W01 palette. Native145×40 detail is expanded to512×128, not newly acquired photographic resolution. Physical tile1.015×.28m and normal strength.35 are reconstructed unmeasured optical choices.

Original project-authored128×128 cut-end maps supply708 previously constant unpainted end triangles. End grain is an original appearance reconstruction, not measured ring anatomy/species/growth age. These new pixels are CC0-1.0; donor-derived side maps remain CC-BY-4.0, never CC0. Every original colour factor is preserved. Painted hubs remain painted and exact; they are not given false exposed end grain. Paint and iron materials/images/geometry remain exact. Canvas and existing covered-wagon variants were not written.

## Actual outcome and cost

`candidate-normalized/wagon-w01.glb`: SHA256da5df4b37ce6830af04f055453f6cb11890be29b3b28e9f4bd31a26bd3ff86ec,2,478,856 bytes (parent1,926,852). Candidate generation0.509s at nice19/math threads1, exit0.23 meshes and12,104 triangles unchanged. Material splitting changes23→31 native primitives and6→9 material definitions;8 definitions are referenced. This extra draw risk is real, especially near the existing1835 confidence-view cap. No budget is raised or waived.

Producer actual receipt: `candidate-normalized/ACTUAL-RECEIPT.json`. Independent actual GLB readback: `ACTUAL-INDEPENDENT-READBACK.json`, exit0. Exact sorted oriented POSITION+NORMAL triangle signature ec856227f831309f05aac28163bb0f2e2a05f42d5cdd4ba661457e80e44e347f before/after. Original binary prefix, nodes/transforms/pivots, skins, animations and scenes are exact. Corrupting an actual POSITION float in memory is rejected by the independent signature. Minimum unpainted-wood UV double-area changes0→5.06656e−6; actual max tangent/normal dot8.94e−8; tangent-length error5.96e−8. No geometry face was omitted, duplicated or reversed.

Dimension-derived active RGBA8 texture+all-mip estimate6,291,684→3,408,000 bytes (simple4/3 estimate6,291,456→3,407,872). These are decoded-dimension estimates, not actual driver allocation. Original embedded bytes remain in the immutable prefix, so payload grew despite active texture memory falling. Encoded8-bit normal-vector length error up to.00523 is recorded; shader normalization and actual appearance remain subject to review.

No Blender/browser/Khronos/fullgate ran; the local Khronos package was unavailable and no install was attempted. No photographic, period, close-view, terrain, covered-variant integration, main-scene, confidence or world acceptance is claimed. Mirror/repeat visibility, actual roughness/grain scale and donor native resolution need actual review.

## Pins and recovery

Parent parkedW01 SHA256274e737b51872983df792d0b24de8e75de8631890a8d586a32d9c6f0066484fb at `/tmp/chicago-covered-sag/chicago/4d/renderers/web/transport/parked-wagon/wagon-w01.glb`.

Authored part ownership: `/workspace/shared/w01-combined-refinement-next/hardware-recapture/authored-parts.json`, SHA2562fb3709d233e896280c50342618c28f9e340029e52c67b328100e05a125e2c27. The original project chart source is unchanged. Existing covered GLBs and recipe are pinned read-only in the independent receipt; this is not a claim that the new helper supports their retired-part ownership.

`refine_timber_surface.py` is the complete reproducible, fresh-output-only producer; `check_actual.py` independently reads actual output. Default paths document this workspace; use the pure `refine(parentBytes,partBytes,donorBytes,creatorMetadata,annotation,output)` entry point on equivalent pinned bytes in another workspace. `UNAPPLIED-source.patch` adds the isolated helper and attribution only; it does not silently wire the derivative into any product or replace locked existing chart inputs. Future integration must reconcile paths/provenance/production metadata under actual current source rather than copying an old complete generator over new work.

Environment publication interrupted the session but did not interrupt a running candidate: the previous source-crop guard had already terminated. Source pins were checked again before continuing. No blind rerun or original failure replacement occurred. All candidate attempts use separate fresh output directories.
