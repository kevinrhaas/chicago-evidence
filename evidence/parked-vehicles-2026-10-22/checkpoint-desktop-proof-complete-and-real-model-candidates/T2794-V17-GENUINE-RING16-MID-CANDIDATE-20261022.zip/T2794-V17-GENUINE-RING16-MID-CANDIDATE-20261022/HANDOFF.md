# Genuine V17 Brougham mid candidate — saved, not installed

This packet contains a real generated and indexed 22,238-triangle candidate, down from the unchanged 33,502-triangle V17 near asset. It changes longitudinal subdivision on 16 rounded wheel rings to 16 segments. The original eight cross sections and every other producer parameter remain unchanged. No active app file, model selection, stand, camera, acceptance threshold or Git history was changed.

The historical model reference is the 1893 Studebaker Brougham catalogue plate. This remains a reconstructed, empty parked example for the 1904 scene; the individual carriage, owner and presence at this stop are not attested. The source and model license is GPL-3.0-or-later. The copied offline Khronos validator carries its own Apache-2.0 license and notices.

## What actually completed

Generation, lossless indexing, native geometry checks, current offline Khronos validation, the original near native check and the actual six legacy card regression all closed successfully before the environment publication interruption. Original receipts and logs are retained. Recovery packaging verifies their recorded hashes; it does not regenerate geometry.

- Raw candidate: `raw/brougham.glb`, 1,684,032 bytes, SHA-256 `7e70bf062196d87a38928a1ccc3e1afe39ae9a4b54a62f7f72bc6d5ddd7f78d7`.
- Indexed candidate: `delivery/brougham-mid.glb`, 1,047,068 bytes, SHA-256 `29a7feaa7aa660f31fbf53fecdc555526935a0d69fb59e39f6c427b644860282`.
- Native count: 22,238 triangles, saving 11,264. Exactly 452 other parts retain their complete Float32 position and normal bytes. Repeated hubcap batches are bound to their actual node paths and exhausted completely, rather than first-matched by duplicate name.
- All seven materials, 42 nodes, 13 anchors, full decoded bounds, wheel contacts, full fixed pole and shoe contacts remain exact. Neither asset has texture or UV streams; no UVs were invented.
- Both raw and indexed Khronos reports have zero errors, zero warnings and four empty-anchor information messages.
- Actual negative controls detect a mutation in the last repeated hubcap's protected button, an anchor translation change and an unchanged near asset passed as a claimed mid.
- Original near payloads and producer inputs remain exact. Four existing model definitions still serve the six existing placements/cards. The original harness's mistaken six-model assertion is retained as a refused preliminary check, followed by the corrected actual four-model/six-card proof.

## Restore and reproduce

`BINARY-TEXT-RESTORE-MANIFEST.json` identifies the two additive payloads and their exact expected-absent destination paths. `ADDITIVE-RECIPE-AND-MID-PAYLOAD.patch` is a real Git binary patch for those two new files only. A read-only apply check passed against app commit `3289b16cdc671a6ddf4c2e25587e8f0bd670fdb3`, tree `01d923aab229502a54e2804a4f816c17946018e3`. The patch was not applied there. It is not a complete runtime intake.

After extracting this packet, the bounded native proof can be repeated with `python3 verify_candidate.py`; the copied validator with `node validate_candidate.cjs`. These commands rewrite only their owned proof reports. To regenerate the candidate deliberately, use the exact command in `GENERATION-TERMINAL.json`, replacing its old absolute packet root with the extraction root. Pass `ring16-mid-recipe.json` explicitly. The copied `source/lods.json` is an older archived recipe, not the recipe used for this candidate.

`FILE-MANIFEST.json` covers every portable file except itself. The outer capsule receipt records ZIP hash, size and successful archive/member verification. Python bytecode caches are excluded.

## Remaining acceptance work

This candidate has not been rendered, visually compared, installed or selected at runtime. There is no accepted half-pixel policy, photographic-quality claim, current world or scene-budget acceptance. The preserved near asset remains the conversation-distance reference. A future owner must implement and test Brougham-only runtime selection, correct picking and disposal, honest sidecar/native contracts, actual fixed-view near-versus-mid appearance, and current desktop/mobile world budgets. Source triangle savings alone do not establish a render-frame saving. Preserve old C02, covered wagons, horses, people and all six legacy cards.

Current published source `3289b16` uses historical DEV base `824957fe`; it is not a qualification of latest DEV or combined incoming people. Existing mobile and desktop ordinary-world deadline failures remain failures in their separate saved packets. Do not replace them with this native candidate result.
