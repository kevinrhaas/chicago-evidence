const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=__dirname,pins=JSON.parse(fs.readFileSync(path.join(root,'VALIDATOR-PINS.json'))),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const[f,h]of Object.entries(pins.files))if(sha(fs.readFileSync(path.join(root,'validator',f)))!==h)throw Error('Existing validator pin drift');
const validator=require('./validator/index.js');if(validator.version()!==pins.version)throw Error('Validator version drift');
(async()=>{for(const [label,file]of [['raw','raw/brougham.glb'],['indexed','delivery/brougham-mid.glb']]){
 const bytes=fs.readFileSync(path.join(root,file)),report=await validator.validateBytes(new Uint8Array(bytes),{uri:path.basename(file),maxIssues:1000});
 fs.writeFileSync(path.join(root,'KHRONOS-'+label+'.json'),JSON.stringify(report,null,2)+'\n');
 const i=report.issues;if(i.numErrors||i.numWarnings||i.truncated||report.info.totalTriangleCount!==22238)throw Error('Actual candidate validator failed '+label);
 console.log(JSON.stringify({label,sha256:sha(bytes),version:report.validatorVersion,triangles:report.info.totalTriangleCount,errors:i.numErrors,warnings:i.numWarnings,infos:i.numInfos}));
}})().catch(e=>{console.error(e.stack);process.exitCode=1});
