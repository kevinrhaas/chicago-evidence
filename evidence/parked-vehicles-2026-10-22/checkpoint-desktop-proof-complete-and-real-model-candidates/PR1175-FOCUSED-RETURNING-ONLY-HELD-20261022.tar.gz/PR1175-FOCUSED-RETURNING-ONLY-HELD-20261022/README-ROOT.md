# Returning visitor only — prepared, not executed

This is one fresh ordinary Full desktop 1280×800 case on source 8f5127d4feebcaa63a0bc0c751dc4a1c1e7dd8d3 and its pinned published mirror. It preserves the original returning-visitor query and exact assertion literally: `ret.flagged.length === ret.total - 3 && ret.flagged.length > 0`. It retains the original normal navigation, bootstrap, 240-second boot bound, 90-second landing bound, hit-tested Home/Open controls, feed-import wait, page-error/vendor guards and cleanup. The seven imported helpers are unchanged. No drawing is held; no detail, opacity, camera, feed or clock is altered.

Only the completed first-visit checks and their second app boot are omitted. Instead BrowserContext.storageState initializes the one real same-origin localStorage entry `chicago4d.whatsnew.seen = '3'` before page creation and app navigation. This is the returning profile's authentic storage input, not an init script that resets state on every document or a rendered-feed injection. The actual browser context storage is asserted before navigation, then the production page's seen=3, default Full detail, Normal confidence, original grade settings and welcome phase are read and asserted before opening the feed. The original real Home click, actual What's-new navigation and literal query/assertion follow.

This is a valid projection of returning-profile behavior, not a re-execution of the original first-visit→reload sequence. It makes no additional persistence-across-reload or QA11 claim. Existing mobile full checks, desktop partial QA11/first-five observations and every timeout keep their original scopes. HISTORICAL-FAILURE-BINDING.json pins the six-check case's actual TIMEOUT124 and empty owned cleanup; it remains FAIL.

The held desktop configuration has release and browser-lane flags false. It binds the same exact 8f HEAD/tree, source smoke, source/published feed, production shim, published index, runtime/confidence sources and helper files as the prior six-case configuration. New caller/runner hashes and unique output directories distinguish this case. Review those pins before deliberately creating a separate root-released configuration. Do not overwrite the held template or prior evidence.

The existing ownership supervisor remains exact and unchanged. Its limits remain 360 seconds whole / 350 seconds execution, with no retry or extension. One explicitly released execution would be:

```
python3 /workspace/shared/PR1175-FOCUSED-RETURNING-ONLY-HELD-20261022/prepared/run_owned.py --released /absolute/path/to/ROOT-RETURNING-ONLY-RELEASED.json
```

The wrapper requires the unchanged original returning PASS label, both actual storage/default preconditions, zero process failures, unchanged input pins and the uniquely scoped terminal success marker. A timeout remains failure. Any success qualifies only this returning-profile behavior, not six assertions, QA11, whole part13, the full gate or a later head's publication.

Node syntax and Python AST parsing passed. The literal query/assertion, remaining helper/bootstrap code and unchanged post-part13 body were compared to source. No browser was launched, no app or Git state changed, and no old result was promoted.
