This is an ENVIRONMENT-INTERRUPTED canonical unit, not a canonical PASS and not a measured semantic producer failure. Do not relabel it from the zombie process's raw kernel field52=0.

Actual inspection:

- Old exec47577 is unknown to the execution manager. ResolverPID1964742 is zombieZ/PPID1; there are no live processes whose cwd is the horse app. The root's separate browser58134 was deliberately left alone.
- RESOLVE.log last prints step123 survey_stated_kin.py --write. The tool prints a step before executing it, so123 completion is unknown. Reaching123 means the synchronous loop returned from1–122; it does not prove the full sequence or second pass completed.
- No final resolver staging/terminal line, no queued PUBLISH.log and no MIRROR.log exists. The postresolve publication/mirror never ran. The resolver's earlier successful prepublish is a partial working-tree mirror, not qualified final combined publication; its tiny build stamp is preserved only as context.
- HEADa086 / MERGE_HEAD8fc remain unchanged. Exactly five generated index conflicts remain. Each working generated file is byte-identical to its original stage2(ours) blob, and there is no tracked unstaged drift outside those five. Frozen five authored resolutions and all protected horse source pins still pass. No rollback or new authored repair is indicated.

Preserved artifacts include the raw resolver log and full-decision reason, raw process stat, actual index snapshot and unmerged stage entries, all five current generated working files, current source/guard result, and partial mirror build stamp. They are evidence of this incomplete run, never a replacement for a terminal verdict.

Exact safe resume, only AFTER root's explicit quiet CPU release and browser58134 closure:

1. Recheck actualHEADa086cd7dab31935f52adcb1ca8494a12726f9f27 and MERGE_HEAD8fc3fd3f0db3088f61408e2fe4c0b993f623e1ee. Verify no old live owner; exact five authored file hashes, protected horse pins, incoming person bindings, the same five unmerged paths/stage2 working bytes, and the exact tracked7d9 Glessner package's three outputs. Do not fetch/update shared origin/dev or integrate new DEV73aef into this existing open merge. Both source snapshots remain durable.
2. Use a FRESH outside-app output directory, keeping every interrupted log unchanged. Record the new actual PID/session and each stage's start/terminal status. Run ONE supported resolver with the same sharedPython311PATH, nice19 and maththreads1:

       PATH=/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:$PATH OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 nice -n19 node tools/rederive.mjs --resolve

   The resolver will correctly choose FULL200 plus its supported second pass/settled tail because the first conflict is142 and second-pass seat_trade_roofs is145. This is the first explicitly root-released restart after a diagnosed environment interruption, not an automatic retry. Do not manually resume at123, skip completed-looking steps, switch to a short tail, edit the manifest or reinterpret raw kernel status as completion. The existing incomplete generated working values are safe inputs; canonical commands are idempotent and own this resolution.
3. Only on actual resolver exit0, run ordinary supported posttail publication and mirror with the same PATH/math1/nice19, each into its own fresh log:

       bash tools/publish.sh
       node tools/check_published.mjs

   Capture actual terminal exits. No blind repeat if a stage fails. Protect current model/source/pose/provenance; do not insert a source repair without diagnosing its real failure.
4. After actual normal terminal, verify and record zero unmerged paths, exact staged tree, any genuine unstaged derived outputs, authored/horse/person source guards, scene humans+standing_horses and exact support region, and current Glessner hashes. Stage only actual necessary generated outputs. Freeze a complete updated source/receipt checkpoint.
5. Return the local CPU lane for root's planned returning-only graphics check. FULL preflight, commit and push remain a separate root release; no gate/browser/commit/push was started during this interruption inspection. Keep1212DRAFT and the ownedlease, explicitly dependent on still-unmerged1175. Old a086/fde validation labels and the original desktop timing failures remain unchanged.
