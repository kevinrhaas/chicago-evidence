import builtins,sys,runpy
from pathlib import Path
def legacy_sum(items,start=0):
 total=start
 for value in items:total+=value
 return total
builtins.sum=legacy_sum
script=sys.argv[1];sys.path.insert(0,str(Path(script).parent));sys.argv=sys.argv[1:];runpy.run_path(script,run_name='__main__')
