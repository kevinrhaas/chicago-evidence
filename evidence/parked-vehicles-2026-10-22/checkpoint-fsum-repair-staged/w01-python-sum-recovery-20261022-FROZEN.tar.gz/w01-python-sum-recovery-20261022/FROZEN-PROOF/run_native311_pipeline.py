from pathlib import Path
import subprocess,sys,json,hashlib
p=Path(__file__).parent;rows=[]
commands=[('original-material-EXPECTED-REFUSAL',[p/'original/apply_materials.py','--vehicle',p/'native311-original/wagon-w01.glb','--parts',p/'native311-original/authored-parts.json','--parameters',p/'recipe.json','--output',p/'original-material-REFUSED'],False),('fixed-material',[p/'fsum/apply_materials.py','--vehicle',p/'native311-fsum/wagon-w01.glb','--parts',p/'native311-fsum/authored-parts.json','--parameters',p/'recipe.json','--output',p/'native311-material'],True),('fixed-finish',[p/'fsum/refine_materials.py','--parent',p/'native311-material/wagon-w01.glb','--parameters',p/'finish.json','--output',p/'native311-finish'],True),('unchanged-covered-core',[p/'covered-core.py','--parent',p/'native311-finish/wagon-w01.glb','--authored-parts',p/'native311-fsum/authored-parts.json','--parameters',p/'covered-parameters.json','--output',p/'native311-covered'],True)]
for label,command,expected in commands:
 r=subprocess.run([sys.executable,*map(str,command)],text=True,capture_output=True,timeout=100)
 (p/(label+'.stdout')).write_text(r.stdout);(p/(label+'.stderr')).write_text(r.stderr)
 rows.append({'label':label,'exit':r.returncode,'expected_success':expected});print(json.dumps(rows[-1]),flush=True)
 (p/'NATIVE311-PIPELINE-STEPS.json').write_text(json.dumps(rows,indent=2)+'\n')
 if expected and r.returncode:raise RuntimeError(r.stderr[-3000:])
 if not expected:assert r.returncode!=0 and 'Exact recaptured authored parts required' in r.stderr
expected=json.loads((p/'config.json').read_text())['expected_glb_sha256'];actual=hashlib.sha256((p/'native311-finish/wagon-w01.glb').read_bytes()).hexdigest();print('finalW01',actual,actual==expected,flush=True);assert actual==expected
source=json.loads((p/'covered-SOURCE.json').read_text());products=[]
for v in source['variants']:
 for name,k in [('covered-w01.glb','glb_sha256'),('covered-w01.json','sidecar_sha256')]:
  f=p/'native311-covered'/v['model']/name;actual=hashlib.sha256(f.read_bytes()).hexdigest();print(v['model'],name,actual,actual==v[k],flush=True);products.append({'model':v['model'],'file':name,'sha256':actual,'expected':v[k],'exact':actual==v[k]})
  assert actual==v[k]
(p/'NATIVE311-FINAL-PRODUCTS.json').write_text(json.dumps({'finalW01':expected,'covered_products':products,'all_original_guards_preserved':True},indent=2)+'\n')
