# Python3.11 wagon reproduction repaired without changing shipped models

Exact failing sourcee694849a2c516a9862a2564c5ff86d97406e09ab. All work outsideapp; no tracked source/index/mirror/Git/browser/CI mutation. NativeCPython3.11.17 officialuvmanagedLinuxx86_64 used, with pinned NumPy2.3.5/Pillow12.3.0/SciPy1.17.0 matchingrootdependencies. No system install, Blender, build or new test registration. CPUworksinglethread/nice10 and finite; runtime/dependency downloads were authorized free managed packages.

## Cause reproduced, then a second dependency uncovered

Exacthardwaregenerator under native3.12 writes original canonicalauthoredparts SHA2fb3709d233e896280c50342618c28f9e340029e52c67b328100e05a125e2c27 andGLB04820fc1… . Native3.11.17 writes rawparts9d143cd3a415abc4f7333bf351baa9ebfd10a58f397ef8d7e8e86b584f94ca26 whilethehardwareGLBremains04820exact. Narrowleft-to-rightsumemulationunder3.12 reproducesnative3.11'srawhash exactly.158records have606localnormal and606transformednormal scalardeltas,max2.220446049250313e-16; names/frames/materials/positions andotherfieldsunchanged. CI didnotprintorretain itsgeneratedrawhash, so9d143… isour sameversionnative reproduction, NOT aclaimedCIartifacthash.

Existingapply_materials rawparts2fb guard refuses nativeoldparts with the SAME exacterror asCI. Explicitmath.fsum at7float-sum sites across generate_wagon_hardware.py/hardware_shapes.py restores raw2fb ANDhardware04820 undernative3.11. Allrawguards, recipes, parents andfinalproductpinsremainunchanged. This avoids any semantic/hash guard relaxation. A preliminary isolatedpipeline first lackedSciPy; thatdependencywasinstalled atroot'sversion before the actualguardreproduction/pipeline. The exact refusal savedhere isafterdependencyreadiness, notthatsetupfailure.

The patchedhardware then passes unchanged apply_materials parent/materialguard and unchanged refine_materials parent0138ad…guard; finalW01 isEXACT274e737b51872983df792d0b24de8e75de8631890a8d586a32d9c6f0066484fb.

The FIRST unchangedcoveredcore run still failedproductidentity: Western4e398…/Oaka413… instead9b/c6. BOTHbinarychunks were alreadyEXACT2,918,192bytes; only11Western/10OakJSONscalars differed. Sixclothcolorfactors drifted from a393216termfloatmean; remainderwereunit/dotnormal-accessormin/max ulps. Thatactualfailedstep/log/deltasarepreserved, notcalledsuccess.

Explicitmath.fsum atONLY3floating-sum sites in covered/build.py(unit,dot,clothmean), retainingintegertriangle/primitive sums, repairs these remainingJSONdifferences. Finalnative3.11 Western9b6575d1702ca288b5a66487ef089cc51dd0b86d14a47574f94b6fe6eaf23d23 andOakc6f69830d4ad690125ed703353d429bb8f68d67d29d6f6161b383b8b2d78f191 arebyte-for-byte equaltooriginalcommittedGLBs. No textures/buffers/triangles/visuals/placementssilentlychange.

## Apply the complete3sourcepatch, preserve strictmetadata

`HELD-all-3-native311-math-fsum-against-e694849a.patch` is the finalproposal. Earlier2filepatch ishistoricalincomplete forcovered andmustnotbe mistaken forcompletefix. Newcodefilehashes:
- generate_wagon_hardware.py451b37c475dcce5bbb571e0cb392d5fa1ef7ec077668df38c088613a0b18f18f
- hardware_shapes.py2f69c0e8d04e8af1fd874f16c1a39c2b32fd2e0c5158484c63e668922d81cd12
- wagon_covered/build.py1a36e3506c9e515c5404d911f30f2c2093b325fe5a6184d931aefa6503d7555d

Root/coveredmetadataagent owntracked integration. W01derivedsidecar producer hashes and assets/authored/transport/wagon_parked/SOURCE source hashes need regeneration. CoveredSOURCE core_source_sha256 mustname1a36…; coveredJSONs ONLYsource_sha256fieldchanges. NewsidecarSHAWestern5261e1ea4c89312322f1589019c05e2bcb6402aea600848d3ee1fb6f30c6d5fc/Oak2873ec1ea489651dde522fbea3d8f078d8fe2d5661dea9c510b5775fba753891; actualnewJSONbytesareincluded. UpdatecoveredSOURCE sidecarhashes accordingly. KeepALL existingexpectedGLBpins/raw2fbownershippins/recipes/finishconfigbytesunchanged. finish.tilesmetadata ishashedintofinalW01,sochangingitwouldunnecessarilychangeprotectedGLB.

Existingrawparts guardsremain bothinapply_materials andcovered/build.py. refine_materials hasstrictparent0138GLBguard, notanotherrawpartsread; it passedunchanged. Coveredwrapperstrictcore-source guardmustbe updatedtoactualnewsourcehash, notremoved. ExistingfinalW01/coveredGLBchecks muststay.

Fullcheck.sh/preflight, exactcommitchecks andfreshactualCIqualification stillrequired beforemerging; thisfinite nativeproofisnotthe newCIresult. Realbrowser/photo/horse/humanacceptance isoutside thisrepair. OfficialCIstillfailedatoldhead; no rerun/POSTfromthisagent.

## Recovery and rerun notes

Fulloutsideworkingdirectory /workspace/shared/w01-python-sum-recovery-20261022 retainsmanagedruntime/venv, allgeneratedGLBs/rawJSONs/textures andcommands; compactarchiveexcludesruntime/venv/cache/duplicateGLBbytes alreadyavailable inGit. Exactoriginalandproposedcode, unchangedrecipes,old/newnativeauthoredJSONs,actualcorefailedJSONdeltas,newsidecars,nativeproof/logsandfinalproducthashcomparisons arearchived. Native3.11stdio logs showallrealexits; NATIVE311-FINAL-ALL-PRODUCTS.json is the terminalcorrectedproductproof, while earlierNATIVE311-PIPELINE.log endsat the genuineunchangedcorefailure.
