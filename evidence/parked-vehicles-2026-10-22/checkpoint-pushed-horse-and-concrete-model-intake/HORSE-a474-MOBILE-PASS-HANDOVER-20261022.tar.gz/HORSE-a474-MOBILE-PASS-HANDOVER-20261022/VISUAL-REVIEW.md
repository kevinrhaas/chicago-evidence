All four actual PNGs personally opened with view_image after terminal.

side.png: the complete textured horse stands beside the stable in its yard, within fixed framing. No visible source clipping or floating feet in this view. This remains a development model; stocky proportions, solid mane/tail, flat eyes and coat limits remain.

quarter.png and quarter-idle-active.png: same fixed quarter camera retains the real fence across the horse; head/shoulders and portions of legs visible, body partly occluded. No camera adaptation, fence removal or quality acceptance inferred. The numerical weighted-vertex movement proves actual idle; static PNGs alone do not show motion over time.

own-card.png: actual production popup names the yard horse, leads with reconstructed/unidentified status, explicitly credits modern2021sevketkabatas/CCBY4.0 and says this is not1835individual/breed/owner evidence. Attested0of4 visible. Shared popup still uses generic building nouns; known follow-up outside bounded own-card repair.

Actual whole run PASS160.54s, original timingPASS and all product checksPASS. Four annotated hoofpatch drifts exactly0; head3.183mm/tail.209mm movement, sourcebone0. Reducedmotion/hidden freeze, actualpick+popup, coarsearrayrelease/support and disposalPASS. This is software-rendered mobile viewport evidence, not phonehardware performance, photographic anatomy, exhaustive self-contact, gait, team, riding or fullticket completion.

Earlier desktop timingFAILs remainFAIL and no new desktop run occurred. PR1212 staysDRAFT and depends on unmerged1175 via8fc; sourcea474 excludeslatest73/subsequent3fperson. No source/threshold/deadline/camera change or retry.
