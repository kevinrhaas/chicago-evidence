"""One root-released unit only; unchanged source-pinned descendant supervisor."""
import argparse,json,pathlib,sys
HERE=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--lane-released',action='store_true',required=True);p.add_argument('--phase',choices=['1812-desktop','1812-mobile','1835-desktop','1835-mobile','1904-desktop','1904-mobile'],required=True);p.add_argument('--release-file',required=True);p.add_argument('--output-dir',required=True);a=p.parse_args()
cfg=json.loads(pathlib.Path(a.release_file).read_text())
if cfg.get('ROOT_RELEASE') is not True or cfg.get('released') is not True or cfg.get('browser_lane_free') is not True or cfg.get('phase')!=a.phase:raise SystemExit('HELD: no root release/final publication binding; no supervisor, server or browser started')
if cfg.get('unit')!=json.loads((HERE/'UNITS.json').read_text())[a.phase]:raise SystemExit('Unit/camera/deadline mismatch')
out=pathlib.Path(a.output_dir)
if out.exists() or out.with_name(out.name+'-terminal').exists():raise SystemExit('Refuse existing output or terminal; no retry')
sys.path.insert(0,str(HERE/'borrowed'))
from ownership_supervisor import run_owned
r=run_owned(['node',str(HERE/'capture_world_review.mjs'),'--lane-released',a.phase,str(pathlib.Path(a.release_file).resolve()),str(out)],out.with_name(out.name+'-terminal'),whole_timeout=360,execution_timeout=350)
print(json.dumps(r,indent=2));raise SystemExit(r['exit_code'])
