// Diagnostic only. Real live per-instance Box3 bounds, using Three's existing APIs.
// No geometry retained/restored, collision proxy generated, or acceptance margin invented.
export async function liveObstacles(page,horseWorldBounds){
 return page.evaluate(async horseWorldBounds=>{
  const a=window.__chicago4d,T=await import('three'),horse=new T.Box3(new T.Vector3().fromArray(horseWorldBounds[0]),new T.Vector3().fromArray(horseWorldBounds[1]));
  const all=[],missing=[];let inspected=0;
  const distance=b=>Math.hypot(Math.max(0,horse.min.x-b.max.x,b.min.x-horse.max.x),Math.max(0,horse.min.y-b.max.y,b.min.y-horse.max.y),Math.max(0,horse.min.z-b.max.z,b.min.z-horse.max.z));
  const add=(label,node,instance,box)=>{inspected++;all.push({category:label,node:node.name||node.type,instance,world_bounds:[box.min.toArray(),box.max.toArray()],box_separation_m:distance(box),box_overlap:horse.intersectsBox(box)});};
  const groups=[['buildings',a.buildings?.group],['trees',a.trees?.group],['street_trees',a.streetTrees?.group],['parked_transport',a.parkedTransport?.group],['enclosures',a.enclosures?.group]];
  for(const [label,group]of groups){if(!group)continue;group.updateMatrixWorld(true);group.traverse(m=>{
   if(!m.isMesh)return;for(let n=m;n;n=n.parent)if(!n.visible)return;
   const geom=m.geometry,box=new T.Box3(),mat=new T.Matrix4();
   if(m.isBatchedMesh){for(let j=0;j<m.instanceCount;j++){if(!m.getVisibleAt(j))continue;const id=m.getGeometryIdAt(j),cached=m._geometryInfo?.[id]?.boundingBox;
    if(!cached&&!geom.attributes.position?.array){missing.push({category:label,node:m.name||m.type,instance:j,reason:'released arrays and no existing per-geometry bound'});continue;}
    m.getBoundingBoxAt(id,box);m.getMatrixAt(j,mat).premultiply(m.matrixWorld);add(label,m,j,box.clone().applyMatrix4(mat));}return;}
   if(!geom.boundingBox){if(!geom.attributes.position?.array){missing.push({category:label,node:m.name||m.type,reason:'released arrays and no existing geometry bound'});return;}geom.computeBoundingBox();}
   if(m.isInstancedMesh){for(let j=0;j<m.count;j++){m.getMatrixAt(j,mat).premultiply(m.matrixWorld);add(label,m,j,geom.boundingBox.clone().applyMatrix4(mat));}}
   else add(label,m,null,geom.boundingBox.clone().applyMatrix4(m.matrixWorld));
  });}
  const nearest=all.sort((x,y)=>x.box_separation_m-y.box_separation_m),overlaps=nearest.filter(x=>x.box_overlap);
  const carriage=a.parkedTransport?.instances.find(x=>x.row.model==='carriage_c02');
  const c02=carriage?{id:carriage.row.id,model:carriage.row.model,world_root:carriage.group.position.toArray(),visible:carriage.group.visible,bounds:nearest.filter(x=>x.category==='parked_transport').slice(0,12)}:null;
  const trees=(a.streetTrees?.records??[]).map(t=>({id:t.id,e:t.e,n:t.n,root_plan_distance_m:Math.hypot(t.e-(horse.min.x+horse.max.x)/2,t.n+(horse.min.z+horse.max.z)/2)})).sort((x,y)=>x.root_plan_distance_m-y.root_plan_distance_m).slice(0,8);
  return{scope:'LIVE_RENDER_BOUNDS_DIAGNOSTIC_ONLY; per-instance existing geometry boxes, not triangle/self-contact/physics or shader-wind swept hull certification',world_qualified:false,inspected_bound_count:inspected,missing_bound_count:missing.length,missing:missing.slice(0,16),nearest:nearest.slice(0,16),box_overlap_count:overlaps.length,overlap_witnesses:overlaps.slice(0,16),c02,nearest_street_tree_records:trees,all_included_boxes_separated:missing.length===0&&overlaps.length===0,excluded:'ground/water, alpha-tested leaf pixel holes, wind shader displacement, continuous self-contact, unknown/uncached geometry and nonlisted clutter are not certified'};
 },horseWorldBounds);
}
