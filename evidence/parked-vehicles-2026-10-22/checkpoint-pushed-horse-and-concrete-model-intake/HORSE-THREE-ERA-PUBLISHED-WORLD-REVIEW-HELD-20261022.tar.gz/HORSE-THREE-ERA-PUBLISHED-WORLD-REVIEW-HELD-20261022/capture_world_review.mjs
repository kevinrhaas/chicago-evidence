// HELD: one finite phase; existing owned-process supervisor handles deadlines/cleanup.
import fs from 'node:fs/promises';import path from 'node:path';import crypto from 'node:crypto';
import {liveObstacles} from './live_obstacle_readback.mjs';
import {createServer} from 'node:http';import {execFileSync} from 'node:child_process';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),args=process.argv.slice(2);
if(args.length!==4||args[0]!=='--lane-released'||!['1812-desktop','1812-mobile','1835-desktop','1835-mobile','1904-desktop','1904-mobile'].includes(args[1]))throw Error('Require one explicit released phase');
const phase=args[1],year=phase.slice(0,4),cfg=JSON.parse(await fs.readFile(args[2],'utf8')),out=path.resolve(args[3]);
if(cfg.ROOT_RELEASE!==true||cfg.released!==true||cfg.browser_lane_free!==true||cfg.phase!==phase||!cfg.source_head||!cfg.app_root||!cfg.site_root||!cfg.publication_receipt?.file||!Object.keys(cfg.expected_files??{}).length)throw Error('HELD: root release and exact phase/input pins required');
const units=JSON.parse(await fs.readFile(path.join(here,'UNITS.json'),'utf8'));if(JSON.stringify(cfg.unit)!==JSON.stringify(units[phase]))throw Error('Predeclared unit/camera/deadline changed');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const [file,hash]of Object.entries(cfg.expected_files))if(sha(await fs.readFile(file))!==hash)throw Error('Input changed: '+file);
const git=(...args)=>execFileSync('git',args,{cwd:cfg.app_root,encoding:'utf8'}).trim();
const sourceBinding={head:git('rev-parse','HEAD'),tree:git('rev-parse','HEAD^{tree}'),published_build:JSON.parse(await fs.readFile(path.join(cfg.site_root,'build.json'),'utf8'))};
if(sourceBinding.head!==cfg.source_head||sourceBinding.tree!==cfg.source_staged_tree||git('status','--porcelain')||sourceBinding.published_build.version!==cfg.source_head.slice(0,9))throw Error('Current committed/published source binding differs from release');
if(!cfg.expected_files[cfg.publication_receipt.file]||cfg.expected_files[cfg.publication_receipt.file]!==cfg.publication_receipt.sha256)throw Error('HELD: root-reviewed final publication receipt is unbound');
const overlayRoutes=JSON.parse(await fs.readFile(path.join(here,'OVERLAY-ROUTES.json'),'utf8'));
for(const [url,entry]of Object.entries(overlayRoutes)){const published=path.join(cfg.site_root,url);const actual=path.join(cfg.app_root,entry.base_source_relative);if(entry.expected_base_sha256){if(sha(await fs.readFile(actual))!==entry.expected_base_sha256||sha(await fs.readFile(published))!==entry.expected_base_sha256)throw Error('HELD: final source/publication changed overlay preimage; rebase and re-pin, never shadow new work: '+url);}if(!entry.expected_base_sha256){try{await fs.access(actual);throw Error('New candidate source URL already exists; reconcile final source');}catch(error){if(error.code!=='ENOENT')throw error;}try{await fs.access(published);throw Error('New candidate published URL already exists; reconcile final source');}catch(error){if(error.code!=='ENOENT')throw error;}}if(!cfg.expected_files[path.join(here,entry.file)]||cfg.expected_files[path.join(here,entry.file)]!==entry.sha256)throw Error('Unpinned overlay route '+url);}
const model=await fs.readFile(cfg.source_model);if(model.length!==3377384||sha(model)!=='c2559073966cfb5b2c9d2c536ca03fbf03b71734f9a11ffcff48d4ec86e4d25c')throw Error('Normalized source-bound idle derivative pin mismatch');
await fs.mkdir(out,{recursive:false});
const report={phase,ROOT_RELEASE:true,review_only:true,world_qualified:false,normal_activation:false,served_fallback_files:{},served_overlay_files:{},predeclared_unit:cfg.unit,scope:'Development-base standing head/tail idle smoke only, no photographic/anatomical/continuous-contact/ride/hitch/phone-hardware acceptance',pass:false,errors:[],requests:[],captures:[],sourceBinding,inputPins:cfg.expected_files,started:new Date().toISOString(),product_checks:{}};
let server,browser,page,timingFailure=null,productFailure=false;
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.bin':'application/octet-stream','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.css':'text/css','.wasm':'application/wasm','.svg':'image/svg+xml','.md':'text/markdown'};
try{
 const app=cfg.app_root,vendor=path.join(app,'renderers/web/vendor');
 server=createServer(async(req,res)=>{try{
  const u=new URL(req.url,'http://localhost');if(u.pathname==='/favicon.ico'){res.writeHead(204);return res.end();}
  let file,bytes;
  const route=decodeURIComponent(u.pathname);
  if(overlayRoutes[route]){file=path.join(here,overlayRoutes[route].file);bytes=await fs.readFile(file);if(sha(bytes)!==overlayRoutes[route].sha256)throw Error('Changed overlay');report.served_overlay_files[route]={file,sha256:sha(bytes),bytes:bytes.length};}
  else{file=path.resolve(cfg.site_root,'.'+route);if(!file.startsWith(cfg.site_root+'/'))throw Error('Path');if((await fs.stat(file)).isDirectory())file=path.join(file,'index.html');bytes=await fs.readFile(file);const previous=report.served_fallback_files[file];if(previous&&previous.sha256!==sha(bytes))throw Error('Published fallback mutated');report.served_fallback_files[file]={sha256:sha(bytes),bytes:bytes.length};}
  bytes??=await fs.readFile(file);res.writeHead(200,{'Content-Type':mime[path.extname(file)]??'application/octet-stream','Cache-Control':'no-store'});res.end(bytes);
 }catch{res.writeHead(404);res.end('Unavailable');}});
 await new Promise((r,j)=>{server.once('error',j);server.listen(0,'127.0.0.1',r);});const origin='http://127.0.0.1:'+server.address().port;
 const {chromium}=await import('/workspace/shared/chicago-browser/node_modules/playwright/index.mjs');
 browser=await chromium.launchPersistentContext(path.join(out,'owned-browser-profile'),{viewport:cfg.unit.viewport,deviceScaleFactor:cfg.unit.dpr,hasTouch:cfg.unit.mobile,isMobile:cfg.unit.mobile,reducedMotion:'reduce',executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const mobile=phase.endsWith('mobile');page=browser.pages()[0]??await browser.newPage();
 if(browser.pages().length!==1)throw Error('One owned profile/viewport required');
 page.setDefaultTimeout(45000);page.on('console',m=>{if(m.type()==='error')report.errors.push('CONSOLE '+m.text());});page.on('requestfailed',r=>report.errors.push('REQUESTFAILED '+r.url()+' '+r.failure()?.errorText));page.on('pageerror',e=>report.errors.push(String(e)));page.on('response',r=>{if(r.status()>=400)report.errors.push(`HTTP${r.status()} ${r.url()}`);});page.on('request',r=>{if((/horse-sevket.*\.glb/.test(r.url())||r.url().includes('/standing-horse-idle/')))report.requests.push(r.url());});
 const shot=async(name,state)=>{const file=name+'.png',bytes=await page.screenshot({path:path.join(out,file)});report.captures.push({file,sha256:sha(bytes),state});await fs.writeFile(path.join(out,'progress.json'),JSON.stringify(report,null,2)+'\n');};
 // Same actual indexed-vertex readback for fixture and town; no fitting/reposing.
 const snapshot=async(kind)=>page.evaluate(async kind=>{
  const a=window.__chicago4d,f=window.fixture,layer=kind==='materials'?f.layer:a.standingHorses,camera=kind==='materials'?f.camera:a.camera;
  const i=layer.instances[0];if(!i)throw Error('Missing standing horse');const T=await import('three'),p=new T.Vector3(),b=new T.Box3();
  let count=0,clipped=0;const ndc={min:[Infinity,Infinity,Infinity],max:[-Infinity,-Infinity,-Infinity]},meshes=[];
  i.root.updateMatrixWorld(true);camera.updateMatrixWorld(true);
  i.root.traverse(m=>{if(!m.isMesh)return;if(!m.isSkinnedMesh||!m.visible||m.skeleton.bones.length!==15)throw Error('Lost actual source mesh/skin');m.skeleton.update();const ids=new Set(m.geometry.index.array);for(const id of ids){m.getVertexPosition(id,p).applyMatrix4(m.matrixWorld);b.expandByPoint(p);p.project(camera);count++;if(!p.toArray().every(Number.isFinite)||Math.abs(p.x)>.97||Math.abs(p.y)>.97||p.z< -1||p.z>1)clipped++;for(let k=0;k<3;k++){ndc.min[k]=Math.min(ndc.min[k],p.getComponent(k));ndc.max[k]=Math.max(ndc.max[k],p.getComponent(k));}}meshes.push({name:m.name,bones:m.skeleton.bones.length,vertices:m.geometry.attributes.position.count,metalness:m.material.metalness,confidence_values:Array.from(new Set(m.geometry.attributes._confidence.array)),scale:m.scale.toArray()});});
  if(meshes.length!==3||clipped)throw Error('Actual source groups missing/clipped in fixed view; no camera adaptation: '+JSON.stringify({clipped,ndc}));
  const renderer=kind==='materials'?f.renderer:a.renderer;if(renderer.getContext().getError()!==0)throw Error('WebGL error');
  if(kind==='yard'&&(i.asset.animations.length!==7||i.receipt.mixer_count!==1||!i.receipt.autoplay||i.receipt.original_six_autoplay!==false||i.idle?.status.clip!=='sevket_reconstructed_head_tail_idle_v1'))throw Error('Enabled source-bound idle identity mismatch');
  return{idle_status:i.idle?.status,indexed_vertices:count,projected_bounds:ndc,world_bounds:[b.min.toArray(),b.max.toArray()],meshes,clips:i.asset.animations.map(c=>c.name),receipt:i.receipt,camera:{position:camera.position.toArray(),quaternion:camera.quaternion.toArray(),fov:camera.fov},stats:kind==='materials'?{draws:renderer.info.render.calls,triangles:renderer.info.render.triangles}:a.stats()};
 },kind);
 {
  const initial=mobile?'balanced':'full';await page.addInitScript(detail=>localStorage.setItem('chicago4d.settings',JSON.stringify({detail})),initial);
  await page.goto(origin+'/walk/?year='+year,{waitUntil:'domcontentloaded',timeout:45000});await page.waitForFunction(()=>window.__chicago4d?.ready||window.__chicago4d?.error,null,{timeout:240000,polling:1000});
  await page.evaluate(()=>{const a=window.__chicago4d;if(!a.ready||a.error||!a.standingHorses)throw Error('Actual new layer not ready');if(a.welcome.state==='welcome')a.welcome.enter('spawn');});
  await page.waitForFunction(()=>{const w=window.__chicago4d?.welcome;if(w?.state==='welcome')w.enter('spawn');return w?.state==='world';},null,{timeout:30000,polling:100});
  await page.evaluate(async()=>{await window.__chicago4d.standingHorses.ready;});
  if(year==='1812'&&mobile&&report.requests.length)throw Error('1812 Balanced first spawn must stay cold outside40m reach');
  report.initial=await page.evaluate(()=>({detail:window.__chicago4d.detail,coarse:matchMedia('(pointer:coarse)').matches,instances:window.__chicago4d.standingHorses.instances.length}));
  report.first_spawn=await page.evaluate(()=>{const a=window.__chicago4d;return{camera:{position:a.camera.position.toArray(),quaternion:a.camera.quaternion.toArray()},stats:a.stats(),instances:a.standingHorses.instances.length,records:a.standingHorses.records,reviewBanner:document.getElementById('horse-support-review-only')?.textContent};});
  if(report.first_spawn.camera.position[0]!==cfg.unit.spawn.local_e||report.first_spawn.camera.position[2]!==-cfg.unit.spawn.local_n)throw Error('First spawn moved; no camera adaptation allowed');
  if(report.initial.detail!==cfg.unit.detail)throw Error('Ordinary required detail tier changed');
  if(!report.first_spawn.reviewBanner?.includes('WORLD / VISUAL QUALIFICATION OPEN'))throw Error('Diagnostic banner missing');
  if(!report.first_spawn.stats.withinBudget)throw Error('Original live budget exceeded at unmodified first spawn');
  await shot('first-spawn',report.first_spawn);
  if(year==='1812'&&mobile&&report.first_spawn.instances!==0)throw Error('1812 Balanced spawn unexpectedly loaded candidate');
  const views={near:cfg.unit.near_view};
  for(const [name,camera]of Object.entries(views)){
   await page.evaluate(async p=>{const a=window.__chicago4d;a.setFly(false);a.walker.teleport(p);a.step();await a.standingHorses.ready;},camera);
   await page.waitForFunction(()=>window.__chicago4d.standingHorses.instances.length===1,null,{timeout:45000});
   await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   const state=await snapshot('yard');if(!state.stats.withinBudget)throw Error('Existing public render budget exceeded');await shot(name,state);
  }
  report.ground=await page.evaluate(async()=>{
   const a=window.__chicago4d,T=await import('three'),i=a.standingHorses.instances[0],spec=await fetch(new URL('transport/parked/horse-sevket-sidecar.json',a.dataBase)).then(r=>r.json());
   const body=i.root.getObjectByName(spec.contact_mesh.renderer_name),p=new T.Vector3(),feet={};i.root.updateMatrixWorld(true);body.skeleton.update();
   for(const [name,patch]of Object.entries(spec.contacts)){const values=[];for(const fi of patch.source_triangle_ids){const v=[];for(let j=0;j<3;j++){body.getVertexPosition(body.geometry.index.getX(fi*3+j),p).applyMatrix4(body.matrixWorld);v.push(p.clone());}for(const q of [...v,v[0].clone().add(v[1]).multiplyScalar(.5),v[1].clone().add(v[2]).multiplyScalar(.5),v[2].clone().add(v[0]).multiplyScalar(.5),v[0].clone().add(v[1]).add(v[2]).multiplyScalar(1/3)]){const h=i.row.surface_kind==='terrain_triangle'?a.terrain.drawnStaticSupport.heightAt(q.x,-q.z,i.row.ground_record_id,i.row.ground_support_region_id):i.row.surface_kind==='carriageway_triangle'?a.streetGrid.drawnStaticSupport.heightAt(q.x,-q.z,i.row.ground_record_id,i.row.ground_support_region_id):a.yards.drawnBaseHeightAt(q.x,-q.z,i.row.ground_record_id,i.row.ground_support_region_id);if(!Number.isFinite(h))throw Error('Missing actual retained yard triangle');values.push(q.y-h);}}const min=Math.min(...values),max=Math.max(...values);if(min< -1e-5||min>.001)throw Error('Actual source surface contact fails accepted development bound');feet[name]={actual_triangle_vertex_edge_centroid_samples:values.length,minimum_gap_m:min,maximum_gap_m:max};}
   const legacy=!i.row.surface_kind,provider=legacy?null:i.row.surface_kind==='terrain_triangle'?a.terrain.drawnStaticSupport:a.streetGrid.drawnStaticSupport;const support={...(legacy?a.yards.staticSupport:provider.census)};let providerSnapshot=null,fit=null;
   if(!legacy){providerSnapshot=provider.snapshot(i.row.ground_record_id,i.row.ground_support_region_id);fit=await fetch(new URL(i.row.support_fit_file,a.dataBase)).then(r=>r.json());if(providerSnapshot?.sha256!==fit.provider_triangle_sha256||fit.world_qualified!==false||i.row.enabled!==false||i.receipt.world_qualified!==false)throw Error('Authentic source-fit/diagnostic flags changed');}
   if(support.regions!==1||support.triangles>32||support.bytes>4096)throw Error('Support retention cap failed');
   const surfaceGroup=legacy?a.yards.group:i.row.surface_kind==='terrain_triangle'?a.terrain.group:a.streetGrid.group;const released=[];surfaceGroup.traverse(m=>{if(m.isMesh&&m.geometry?.attributes.position)released.push({name:m.name,position_null:m.geometry.attributes.position.array===null,index_empty:!m.geometry.index||m.geometry.index.array.length===0});});
   return{feet,support,providerSnapshot,fit_world_qualified:fit?.world_qualified??null,legacy1835_control:legacy,normal_activation:false,surface_source_cpu_arrays:released,coarse:matchMedia('(pointer:coarse)').matches,query:location.search,receipt:i.receipt};
  });
  if(mobile&&(!report.ground.coarse||!report.ground.surface_source_cpu_arrays.length||!report.ground.surface_source_cpu_arrays.every(x=>x.position_null&&x.index_empty)))throw Error('Normal coarse upload-release path not exercised; no keep-geometry workaround');
  // Additive current-target observation. Existing cameras, graphics budgets and contact guards remain unchanged.
  report.idle_setup=await page.evaluate(async()=>{
   const a=window.__chicago4d,T=await import('three'),i=a.standingHorses.instances[0],spec=await fetch(new URL('transport/parked/horse-sevket-sidecar.json',a.dataBase)).then(r=>r.json());
   if(!i.idle||!i.row.animation.enabled||!spec.idle.enabled)throw Error('Qualified idle is not enabled');
   const body=i.root.getObjectByName(spec.contact_mesh.renderer_name),bones=body.skeleton.bones;
   const sourceBones=[];i.asset.scene.traverse(n=>{if(n.isBone)sourceBones.push(n);});
   if(bones.some(b=>sourceBones.includes(b)))throw Error('Clone shares source bones');
   const patches={};for(const [name,patch]of Object.entries(spec.contacts)){patches[name]=[...new Set(patch.source_triangle_ids.flatMap(fi=>[0,1,2].map(k=>body.geometry.index.getX(fi*3+k))))];}
   if(Object.keys(patches).length!==4||Object.values(patches).some(v=>!v.length))throw Error('Missing nonempty hoof patches');
   const roles={head:[],tail:[]},index=body.geometry.index,skin=body.geometry.getAttribute('skinIndex'),weight=body.geometry.getAttribute('skinWeight');
   for(const id of new Set(index.array))for(const [role,joint]of [['head',12],['tail',14]])if(['X','Y','Z','W'].some(k=>skin['get'+k](id)===joint&&weight['get'+k](id)>0))roles[role].push(id);
   if(!roles.head.length||!roles.tail.length)throw Error('No actual head/tail weighted surface');
   const sample=()=>{i.root.updateMatrixWorld(true);body.skeleton.update();const point=id=>body.getVertexPosition(id,new T.Vector3()).applyMatrix4(body.matrixWorld).toArray();return{elapsed:i.idle.status.elapsed_s,patches:Object.fromEntries(Object.entries(patches).map(([k,ids])=>[k,ids.map(point)])),roles:Object.fromEntries(Object.entries(roles).map(([k,ids])=>[k,ids.map(point)])),bones:bones.map(b=>b.quaternion.toArray()),source_bones:sourceBones.map(b=>b.quaternion.toArray())};};
   const compare=(before,after)=>{const distances=(aa,bb)=>Math.max(...aa.map((v,k)=>Math.hypot(...v.map((x,j)=>x-bb[k][j]))));return{hoof_maximum_drift_m:Object.fromEntries(Object.keys(patches).map(k=>[k,distances(before.patches[k],after.patches[k])])),head_maximum_displacement_m:distances(before.roles.head,after.roles.head),tail_maximum_displacement_m:distances(before.roles.tail,after.roles.tail),bone_component_maximum_delta:Math.max(...before.bones.flatMap((q,k)=>q.map((v,j)=>Math.abs(v-after.bones[k][j])))),source_bone_component_maximum_delta:Math.max(...before.source_bones.flatMap((q,k)=>q.map((v,j)=>Math.abs(v-after.source_bones[k][j]))))};};
   window.__horseIdleYardObservation={sample,compare,before:sample()};
   return{status:i.idle.status,hoof_unique_vertices:Object.fromEntries(Object.entries(patches).map(([k,v])=>[k,v.length])),weighted_role_vertices:Object.fromEntries(Object.entries(roles).map(([k,v])=>[k,v.length])),clone_bones_disjoint:true,original_six_autoplay_receipt:i.receipt.original_six_autoplay};
  });
  // DIAGNOSTIC ONLY: transparent forwarding of the existing production layer.update.
  // Never changes dt, options, return value, curves, camera, rendering or test thresholds.
  report.idle_diagnostic_before=await page.evaluate(()=>{
   const a=window.__chicago4d,layer=a.standingHorses,i=layer.instances[0],original=layer.update;
   const start=performance.now(),initial=i.idle.status,initialReduced=matchMedia('(prefers-reduced-motion: reduce)').matches,rows=[],counts={calls:0,positive_dt_calls:0,forwarded_dt_sum_s:0,maximum_forwarded_dt_s:0,eligible_dt_sum_s:0,paused_calls:0,reduced_calls:0,hidden_document_calls:0,invisible_calls:0};
   const ancestry=()=>{const nodes=[];for(let n=layer.group;n;n=n.parent)nodes.push({name:n.name||n.type,visible:n.visible});return nodes;};
   const state=()=>{const chain=ancestry(),media=matchMedia('(prefers-reduced-motion: reduce)').matches,distance=a.camera.getWorldPosition(a.camera.position.clone()).distanceTo(i.group.position),reach={full:70,balanced:40,light:0}[a.detail]??0;return{elapsed_s:i.idle.status.elapsed_s,idle:i.idle.status,document_hidden:document.hidden,visibility_state:document.visibilityState,document_has_focus:document.hasFocus(),media_reduce:media,instance_visible:i.group.visible,ancestor_visibility:chain,confidence_hidden_reconstructed:Boolean(a.confidence.hidden.reconstructed),distance_m:distance,reach_m:reach,within_reach:distance<reach,welcome_state:a.welcome.state,gate_dom_hidden:document.getElementById('gate')?.hidden??null,renderer_frame:a.renderer.info.render.frame??null,rounded_fps:a.stats().fps,governor:a.governor};};
   const observed=function(...args){const before=i.idle.status.elapsed_s,dt=Number(args[1]??0),opts=args[2]??{};const result=original.apply(this,args);const st=state(),visible=st.instance_visible&&!st.document_hidden&&st.ancestor_visibility.every(n=>n.visible),reduced=opts.reducedMotion===undefined?st.media_reduce:opts.reducedMotion,paused=opts.paused===undefined?false:opts.paused;
    counts.calls++;counts.positive_dt_calls+=Number(dt>0);counts.forwarded_dt_sum_s+=dt;counts.maximum_forwarded_dt_s=Math.max(counts.maximum_forwarded_dt_s,dt);counts.eligible_dt_sum_s+=!paused&&!reduced&&visible?dt:0;counts.paused_calls+=Number(paused);counts.reduced_calls+=Number(reduced);counts.hidden_document_calls+=Number(st.document_hidden);counts.invisible_calls+=Number(!visible);
    rows.push({phase:window.__horseIdleYardDiagnostic?.phase??'install',eligible:!paused&&!reduced&&visible,at_ms:performance.now()-start,forwarded_dt_s:dt,paused_argument:paused,reduced_motion_argument:opts.reducedMotion??null,effective_reduced_motion_from_public_media:reduced,visible,elapsed_before_s:before,elapsed_after_s:st.elapsed_s,renderer_frame:st.renderer_frame,document_hidden:st.document_hidden,media_reduce:st.media_reduce,distance_m:st.distance_m,reach_m:st.reach_m});return result;};
   layer.update=observed;
   const snapshot=()=>({wall_ms:performance.now()-start,initial_status:initial,initial_media_reduce:initialReduced,current:state(),counts:{...counts},all_forwarded_updates:rows.slice(),scope:'All actual forwarded layer dt, including unchanged explicit hidden/restoration probes labeled by phase; not raw private Clock delta. Original arguments/poses/source unchanged.'});
   window.__horseIdleYardDiagnostic={phase:'original_timing_observation',snapshot,restore(){if(layer.update===observed)layer.update=original;}};
   return snapshot();
  });
  // Observe the ordinary production host clock, not a synthetic mixer or direct pose assignment.
  await page.emulateMedia({reducedMotion:'no-preference'});
  await page.evaluate(()=>window.__chicago4d.setAnimationHold(false));
  try{
  await page.waitForFunction(()=>{const o=window.__horseIdleYardObservation,i=window.__chicago4d.standingHorses.instances[0];return i.idle.status.elapsed_s-o.before.elapsed>=1.5;},null,{timeout:15000,polling:100});
   report.original_timing_check={status:'PASS',owned_progress_target_s:1.5,wall_timeout_ms:15000};
  }catch(error){timingFailure=String(error.stack??error);report.original_timing_check={status:'FAIL',owned_progress_target_s:1.5,wall_timeout_ms:15000,error:timingFailure};report.idle_timeout_diagnostic=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());process.exitCode=1;}
  report.idle_diagnostic_after_wait=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());
  // Continue collecting independent product evidence; never erase the original timing FAIL.
  const productStep=async(name,run)=>{try{await page.evaluate(n=>{window.__horseIdleYardDiagnostic.phase=n;},name);const value=await run();report.product_checks[name]={status:'PASS',result:value};return value;}catch(error){productFailure=true;process.exitCode=1;report.product_checks[name]={status:'FAIL',error:String(error.stack??error)};return null;}finally{try{report.all_forwarded_clock_updates=await page.evaluate(()=>window.__horseIdleYardDiagnostic.snapshot());}catch(error){productFailure=true;process.exitCode=1;report.clock_trace_error=String(error);report.product_checks[name].trace_status='FAIL';}await fs.writeFile(path.join(out,'progress.json'),JSON.stringify(report,null,2)+'\n');}};
  const clockAccounting=()=>page.evaluate(()=>{const d=window.__horseIdleYardDiagnostic.snapshot(),initial=d.initial_status;
   if(initial.elapsed_s!==0||d.initial_media_reduce!==true)throw Error('Accounting requires fresh zero-age clone under original initial reduce preference');
   let age=0,elapsed=0,maximumError=0;for(const row of d.all_forwarded_updates){if(!Number.isFinite(row.forwarded_dt_s)||row.forwarded_dt_s<0)throw Error('Nonfinite/negative actual forwarded dt');if(row.elapsed_before_s!==elapsed)throw Error('Unexpected owned-clock advance outside observed updates');const before=age;if(row.eligible)age+=row.forwarded_dt_s;elapsed+=(Math.max(0,age-initial.initial_rest_delay_s)-Math.max(0,before-initial.initial_rest_delay_s))*initial.deterministic_playback_rate;maximumError=Math.max(maximumError,Math.abs(row.elapsed_after_s-elapsed));if(maximumError!==0)throw Error('Actual forwarded-dt accounting differs from source-owned elapsed');}
   if(d.current.elapsed_s!==elapsed)throw Error('Current elapsed differs from complete forwarded-dt accounting');
   return{status:'SOURCE_CLOCK_ACCOUNTING_PASS',fresh_zero_age_basis:'Original new clone loaded under initial reduced motion, no prior eligible phase',observed_updates:d.all_forwarded_updates.length,eligible_age_s:age,source_delay_s:initial.initial_rest_delay_s,source_rate:initial.deterministic_playback_rate,expected_elapsed_s:elapsed,actual_elapsed_s:d.current.elapsed_s,maximum_absolute_error_s:maximumError,arithmetic_tolerance_s:0,scope:'Owned host-delta accounting only; original wall-clock timing result remains independent'};});
  await productStep('source_clock_accounting_after_original_wait',clockAccounting);
  report.idle_motion=await productStep('idle_motion',()=>page.evaluate(()=>{const o=window.__horseIdleYardObservation,after=o.sample(),delta=o.compare(o.before,after);o.after=after;if(Math.max(...Object.values(delta.hoof_maximum_drift_m))>1e-5||delta.source_bone_component_maximum_delta!==0||delta.head_maximum_displacement_m<=1e-8||delta.tail_maximum_displacement_m<=1e-8)throw Error('Actual host idle motion/clone/planted-hoof observation failed: '+JSON.stringify(delta));return{...delta,elapsed_before_s:o.before.elapsed,elapsed_after_s:after.elapsed,host_clock_observed:true};}));
  await productStep('active_view_framing_budget_capture',async()=>{const activeState=await snapshot('yard');if(!activeState.stats.withinBudget)throw Error('Existing public render budget exceeded during idle');await shot('quarter-idle-active',activeState);return{captured:'quarter-idle-active.png'};});
  report.idle_reduced_motion=await productStep('idle_reduced_motion',async()=>{
  await page.emulateMedia({reducedMotion:'reduce'});
  // Capture only after the actual media preference has reached the production layer.
  await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  const reducedStart=await page.evaluate(()=>{const o=window.__horseIdleYardObservation;o.pauseBefore=o.sample();return o.pauseBefore.elapsed;});
  await page.evaluate(()=>new Promise(r=>{let n=0;const next=()=>++n>=8?r():requestAnimationFrame(next);requestAnimationFrame(next);}));
  const result=await page.evaluate(start=>{const o=window.__horseIdleYardObservation,after=o.sample(),d=o.compare(o.pauseBefore,after);if(!matchMedia('(prefers-reduced-motion: reduce)').matches||after.elapsed!==start||d.bone_component_maximum_delta!==0||Math.max(...Object.values(d.hoof_maximum_drift_m))>1e-5)throw Error('Actual reduced-motion host pause failed');return{elapsed_s:after.elapsed,bone_component_maximum_delta:d.bone_component_maximum_delta,hoof_maximum_drift_m:d.hoof_maximum_drift_m,media_preference_observed:true,render_frames_observed:8};},reducedStart);
  return result;
  });
  report.idle_hidden=await productStep('idle_hidden',()=>page.evaluate(()=>{const a=window.__chicago4d,o=window.__horseIdleYardObservation,prior=a.confidence.hidden.reconstructed;a.setAnimationHold(true);const before=o.sample();a.confidence.setHidden('reconstructed',true);a.standingHorses.update(a.camera,1,{reducedMotion:false});const after=o.sample(),d=o.compare(before,after),i=a.standingHorses.instances[0];if(i.group.visible||after.elapsed!==before.elapsed||d.bone_component_maximum_delta!==0)throw Error('Confidence-hidden owned idle did not pause');a.confidence.setHidden('reconstructed',prior);a.standingHorses.update(a.camera,0,{reducedMotion:true});return{hidden_scope:'existing reconstructed-confidence visibility; not OS document visibility',elapsed_s:after.elapsed,bone_component_maximum_delta:d.bone_component_maximum_delta,hoof_maximum_drift_m:d.hoof_maximum_drift_m,visible_after_restore:i.group.visible};}));
  report.live_obstacles=await productStep('live_obstacle_bounds',async()=>{const current=await snapshot('yard');const value=await liveObstacles(page,current.world_bounds);report.live_obstacle_readback=value;if(year==='1904'&&(!value.c02||!value.nearest_street_tree_records.length))throw Error('Actual C02/tree census absent');if(!value.all_included_boxes_separated)throw Error('Unresolved live bound overlap/missing geometry: diagnostic preserved, no collision approval');return value;});
  // Keep the original selection/card/confidence assertions and disposal after the observations.
  report.selection=await productStep('selection',()=>page.evaluate(async()=>{
   const a=window.__chicago4d,T=await import('three'),i=a.standingHorses.instances[0],p=new T.Vector3(i.group.position.x,i.group.position.y+.95,i.group.position.z).project(a.camera),hit=a.standingHorses.pickAt(new T.Vector2(p.x,p.y),a.camera);if(hit?.id!==i.row.id)throw Error('Horse layer pick failed');const worldHit=a.pick({x:p.x,y:p.y});if(worldHit?.id!==i.row.id)throw Error('Ordinary world NDC pick is occluded or differs from horse layer hit');const text=document.querySelector('#popup').innerText;if(!text.includes('sevketkabatas')||!text.includes('Unidentified'))throw Error('Actual selection card lacks source credit/identity limit');a.popup.close();const prior=a.confidence.hidden.reconstructed;a.confidence.setHidden('reconstructed',true);a.standingHorses.update(a.camera);if(i.group.visible||a.standingHorses.pickAt(new T.Vector2(p.x,p.y),a.camera))throw Error('Hidden reconstructed horse still draws/picks');a.confidence.setHidden('reconstructed',prior);a.standingHorses.update(a.camera);return{id:hit.id,text,confidence_hide_pick_pass:true};
  }));
  // Additive own-card qualification: real placed actor and production card, not a synthetic record.
  report.own_card=await productStep('own_card',async()=>{
   try{
    const result=await page.evaluate(async()=>{
     const a=window.__chicago4d,T=await import('three'),i=a.standingHorses.instances[0],spec=await fetch(new URL('transport/parked/horse-sevket-sidecar.json',a.dataBase)).then(r=>r.json());
     const expected=i.row.id,p=new T.Vector3(i.group.position.x,i.group.position.y+.95,i.group.position.z).project(a.camera),hit=a.standingHorses.pickAt(new T.Vector2(p.x,p.y),a.camera);
     if(hit?.id!==expected||hit.record!==i.card)throw Error('Own-card probe did not hit the actual placed actor/card');
     const worldHit=a.pick({x:p.x,y:p.y});if(worldHit?.id!==expected)throw Error('Ordinary world inspect did not select the same actual horse');const popup=document.querySelector('#popup'),lead=popup.querySelector('.pop-lead'),attrs=hit.record.sidecar.attributes,citationIds=hit.record.sidecar.citations.map(c=>c.source_id),normal=s=>String(s??'').replace(/\s+/g,' ').trim();
     const attested=popup.querySelector('.basis-row[data-level="attested"]'),attestedCount=normal(attested?.querySelector('.basis-count')?.textContent),leadText=normal(lead?.textContent),cites=popup.querySelectorAll('.cites li');
     const checks={actual_actor_placement:(!i.row.surface_kind||i.row.enabled===false)&&i.row.confidence==='reconstructed'&&i.row.id===expected&&i.group.name===expected&&Math.abs(i.group.position.x-i.row.at_local_enu_m[0])<1e-12&&Math.abs(i.group.position.z+i.row.at_local_enu_m[1])<1e-12&&Math.abs(i.group.rotation.y-(Math.PI-i.row.bearing_deg*Math.PI/180))<1e-12,
      actual_card_open:a.popup.openId===expected&&!popup.hasAttribute('hidden'),recorded_reconstruction_lead:!!lead&&!lead.hasAttribute('data-composed')&&leadText.includes('A reconstructed, unidentified horse')&&leadText.includes('not evidence of a particular '+new URL(location.href).searchParams.get('year')+' horse, breed or owner')&&(!i.row.surface_kind||leadText.includes('DIAGNOSTIC REVIEW ONLY')),
      exact_modern_credit_in_lead:leadText.includes('Modern model credit (published 2021):')&&leadText.includes(normal(spec.source.credit))&&spec.source.publication_date==='2021-03-29'&&spec.source.license==='CC-BY-4.0',
      modern_credit_not_historically_graded:!Object.hasOwn(attrs,'model_credit')&&Object.keys(attrs).sort().join(',')==='animal,breed_owner,state'&&Object.values(attrs).every(x=>x.confidence==='reconstructed')&&attestedCount==='0 of 4'&&!normal(attested?.textContent).includes('sevketkabatas'),
      historical_and_modern_citations_retained:[...i.row.source_ids,spec.source.id].every(id=>citationIds.includes(id))&&cites.length===citationIds.length,
      research_credit_retained:hit.record.sidecar.research_note.includes(spec.source.credit)&&hit.record.sidecar.research_note.includes('2021')};
     return{id:hit.id,open_id:a.popup.openId,placement:{local_enu_m:i.row.at_local_enu_m,world_root:i.group.position.toArray(),yaw_rad:i.group.rotation.y},checks,lead:leadText,attested_count:attestedCount,graded_attribute_names:Object.keys(attrs),citation_ids:citationIds,citation_DOM_count:cites.length,modern_source:{id:spec.source.id,author:spec.source.author,publication_date:spec.source.publication_date,license:spec.source.license,credit:spec.source.credit},card_text:popup.innerText,pick_scope:'actual layer ray hit plus ordinary main pick(NDC)/inspect ordering and production popup; not an OS pointer-event claim'};
    });
    await shot('own-card',result);if(Object.values(result.checks).some(value=>value!==true))throw Error('Own-card provenance/placement qualification failed: '+JSON.stringify(result.checks));return result;
   }finally{await page.evaluate(()=>window.__chicago4d.popup.close());}
  });
  await productStep('source_clock_accounting_after_pause_and_visibility',clockAccounting);
  await page.evaluate(()=>window.__horseIdleYardDiagnostic?.restore());
  report.teardown=await productStep('teardown',()=>page.evaluate(async()=>{const a=window.__chicago4d,i=a.standingHorses.instances[0],disposed={geometry:0,material:0};i.root.traverse(m=>{if(m.isMesh){m.geometry.addEventListener('dispose',()=>disposed.geometry++);m.material.addEventListener('dispose',()=>disposed.material++);}});await a.standingHorses.setTier('light');if(a.standingHorses.instances.length)throw Error('Light did not retire horse');a.standingHorses.dispose();if(!i.idle.status.disposed||i.idle.status.mixer_count!==0)throw Error('Owned idle not retired before clone disposal');return{disposed,idle_status:i.idle.status,instances:a.standingHorses.instances.length};}));
  await productStep('provider_owned_disposal',()=>page.evaluate(()=>{const a=window.__chicago4d,year=new URL(location.href).searchParams.get('year'),p=year==='1835'?null:year==='1812'?a.terrain.drawnStaticSupport:a.streetGrid.drawnStaticSupport,census=()=>p?p.census:a.yards.staticSupport;const before={...census()};if(p)p.dispose();else a.yards.dispose();if(census().regions!==0||census().triangles!==0||census().bytes!==0||!census().disposed)throw Error('Provider retained owned cache after dispose');return{before,after:{...census()},legacy_yard_layer_disposed:year==='1835'};}));
  await productStep('owned_clone_resource_disposal',async()=>{const d=report.teardown;if(!d||d.disposed.geometry!==3||d.disposed.material!==3||d.instances!==0||!d.idle_status.disposed||d.idle_status.mixer_count!==0)throw Error('Owned three-mesh clone/mixer disposal not observed');return{geometry:d.disposed.geometry,material:d.disposed.material,mixers:d.idle_status.mixer_count,instances:d.instances};});
 }
 if(report.errors.length)throw Error('Browser errors recorded');report.product_checks_status=productFailure?'FAIL':'PASS';report.pass=!timingFailure&&!productFailure;if(timingFailure){report.error=timingFailure;process.exitCode=1;}if(productFailure)process.exitCode=1;
}catch(error){report.error=String(error.stack??error);process.exitCode=1;}
finally{
 if(page&&!page.isClosed()){try{await page.evaluate(()=>window.__horseIdleYardDiagnostic?.restore());}catch{}}
 if(browser)await browser.close();if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}
 report.closed=true;report.ended=new Date().toISOString();report.inputs_unchanged=true;
 for(const [file,hash]of Object.entries(cfg.expected_files)){try{if(sha(await fs.readFile(file))!==hash)report.inputs_unchanged=false;}catch(error){report.inputs_unchanged=false;report.errors.push('POSTINPUT '+file+' '+error.message);}}
 for(const [file,entry]of Object.entries(report.served_fallback_files)){try{if(sha(await fs.readFile(file))!==entry.sha256)report.inputs_unchanged=false;}catch(error){report.inputs_unchanged=false;report.errors.push('POSTFALLBACK '+file+' '+error.message);}}
 if(git('rev-parse','HEAD')!==cfg.source_head||git('status','--porcelain'))report.inputs_unchanged=false;
 if(!report.inputs_unchanged){report.pass=false;process.exitCode=1;}
 await fs.writeFile(path.join(out,'receipt.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({phase,pass:report.pass,captures:report.captures.length,closed:report.closed,error:report.error}));
}
