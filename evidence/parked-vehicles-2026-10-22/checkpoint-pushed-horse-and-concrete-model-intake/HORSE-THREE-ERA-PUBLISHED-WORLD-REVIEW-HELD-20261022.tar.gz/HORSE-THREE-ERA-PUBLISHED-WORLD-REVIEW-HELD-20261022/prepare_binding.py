"""Read-only actual final committed/published intake; writes a HELD external receipt only.
No publication, generation, Git mutation, HTTP server or browser. Root release stays false.
"""
from pathlib import Path
import argparse,json,subprocess,hashlib,re
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--app-root',required=True);p.add_argument('--site-root',required=True);p.add_argument('--source-head',required=True);p.add_argument('--phase',choices=['1812-desktop','1812-mobile','1835-desktop','1835-mobile','1904-desktop','1904-mobile'],required=True);p.add_argument('--output',required=True);a=p.parse_args()
app=Path(a.app_root).resolve();site=Path(a.site_root).resolve();out=Path(a.output).resolve()
if out.exists():raise SystemExit('Refuse overwrite')
if not str(out).startswith('/workspace/shared/'):raise SystemExit('Binding output must be external /workspace/shared')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(app),*args],text=True).strip()
if not re.fullmatch('[a-f0-9]{40}',a.source_head) or git('rev-parse','HEAD')!=a.source_head or git('status','--porcelain'):raise SystemExit('Actual final committed clean source required; no staged-tree or build-stamp substitution')
build=json.loads((site/'build.json').read_text())
if build.get('version')!=a.source_head[:9]:raise SystemExit('Actual published build stamp does not match final HEAD')
cfg=json.loads((HERE/(a.phase+'-ROOT-RELEASE-HELD.json')).read_text());cfg.update(app_root=str(app),site_root=str(site),source_head=a.source_head,source_staged_tree=git('rev-parse','HEAD^{tree}'),source_model=str(app/'renderers/web/transport/standing-horse/horse-sevket-portable-filtered-idle-v1.glb'))
pins=cfg['expected_files']
for route,entry in json.loads((HERE/'OVERLAY-ROUTES.json').read_text()).items():
 src=app/entry['base_source_relative'];pub=site/route.lstrip('/')
 if entry['expected_base_sha256']:
  if sha(src.read_bytes())!=entry['expected_base_sha256'] or sha(pub.read_bytes())!=entry['expected_base_sha256']:raise SystemExit('FINAL SOURCE DRIFT: rebase/re-pin candidate module; do not shadow newer source: '+route)
  pins[str(src)]=sha(src.read_bytes());pins[str(pub)]=sha(pub.read_bytes())
 elif src.exists() or pub.exists():raise SystemExit('New candidate URL already exists in actual final source/publication; reconcile and re-pin: '+route)
for rel in ['build.json','walk/index.html','walk/vendor/three-0.185.1/three.module.js','walk/vendor/three-0.185.1/three.core.js','walk/js/standing-horse-idle.js','walk/js/popup.js','walk/transport/standing-horse/horse-sevket-portable-filtered-idle-v1.glb','data/transport/parked/horse-sevket-sidecar.json','data/transport/parked/standing-horse-idle/source.json','data/transport/parked/standing-horse-idle/append-receipt.json','data/prebuilt/index.json']:
 f=site/rel;pins[str(f)]=sha(f.read_bytes())
for f in [Path(cfg['source_model']),site/'walk/transport/standing-horse/horse-sevket-portable-filtered-idle-v1.glb']:
 if f.stat().st_size!=3377384 or sha(f.read_bytes())!='c2559073966cfb5b2c9d2c536ca03fbf03b71734f9a11ffcff48d4ec86e4d25c':raise SystemExit('Actual source/publication runtime GLB changed')
 pins[str(f)]=sha(f.read_bytes())
cfg['intake_note']='Actual clean final HEAD/tree, build stamp, overlay preimages and source/published runtime model verified. ROOT_RELEASE remains false. Root must bind an actual reviewed final publication receipt+SHA, then release exactly one unit if graphics lane is free. Metadata stamp alone is not publication/gate proof.'
out.write_text(json.dumps(cfg,indent=2)+'\n');print(json.dumps({'status':'HELD_FINAL_INPUTS_BOUND_NOT_RELEASED','file':str(out),'head':a.source_head,'ROOT_RELEASE':False}))
