from pathlib import Path
import json,hashlib,ast,subprocess,os,datetime,time
R=Path(__file__).resolve().parent;units=json.loads((R/'UNITS.json').read_text());routes=json.loads((R/'OVERLAY-ROUTES.json').read_text());records=[]
assert len(units)==6 and len(routes)==12
for phase,u in units.items():
 cfg=json.loads((R/(phase+'-ROOT-RELEASE-HELD.json')).read_text());assert cfg['ROOT_RELEASE'] is False and cfg['released'] is False and cfg['browser_lane_free'] is False
 assert all(cfg[k] is None for k in ['app_root','site_root','source_head','source_staged_tree','source_model']);assert cfg['publication_receipt']['file'] is None and cfg['unit']==u
 assert u['execution_seconds']==350 and u['whole_seconds']==360 and u['no_camera_adaptation'] is True
 assert u['detail']==('balanced' if u['mobile'] else 'full');assert u['dpr']==(2 if u['mobile'] else 1)
 for file,sha in cfg['expected_files'].items():assert hashlib.sha256(Path(file).read_bytes()).hexdigest()==sha
m=json.loads((R/'overlay/data/transport/parked/standing-horses.json').read_text())
for year in ['1812','1904']:
 row=m['scenes'][year][0];assert row['enabled'] is False and row['confidence']=='reconstructed';fit=json.loads((R/'overlay/data'/row['support_fit_file']).read_text());assert fit['world_qualified'] is False
 assert hashlib.sha256((R/'overlay/data'/row['support_fit_file']).read_bytes()).hexdigest()==row['support_fit_sha256']
assert m['scenes']['1904'][0]['belongs_to'] is None
for p in [R/'run_owned.py',R/'prepare_binding.py',R/'borrowed/ownership_supervisor.py']:ast.parse(p.read_text())
env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
for p in [R/'capture_world_review.mjs',R/'live_obstacle_readback.mjs']:
 t=time.monotonic();r=subprocess.run(['timeout','15s','nice','-n','19','node','--check',str(p)],capture_output=True,text=True,env=env);records.append({'kind':'syntax','file':str(p),'exit_code':r.returncode,'stderr':r.stderr,'elapsed_seconds':time.monotonic()-t});assert r.returncode==0
out=R/'GUARD-NO-OUTPUT-DO-NOT-CREATE';assert not out.exists() and not out.with_name(out.name+'-terminal').exists()
for cmd in [
 ['node',str(R/'capture_world_review.mjs'),'--lane-released','1812-mobile',str(R/'1812-mobile-ROOT-RELEASE-HELD.json'),str(out)],
 ['python',str(R/'run_owned.py'),'--lane-released','--phase','1904-mobile','--release-file',str(R/'1904-mobile-ROOT-RELEASE-HELD.json'),'--output-dir',str(out)]]:
 t=time.monotonic();r=subprocess.run(['timeout','15s','nice','-n','19']+cmd,capture_output=True,text=True,env=env);records.append({'kind':'expected_HELD_refusal','command':cmd,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'elapsed_seconds':time.monotonic()-t});assert r.returncode!=0 and 'HELD' in r.stderr+r.stdout;assert not out.exists() and not out.with_name(out.name+'-terminal').exists()
(R/'PREPARED-VALIDATION.json').write_text(json.dumps({'status':'PASS_PREPARED_HELD_ONLY','closed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'source/data/hash/syntax and explicit HELD refusal only; no HTTP server, profile, browser, producer or world capture launched','unit_count':6,'overlay_url_count':12,'records':records},indent=2)+'\n');print(json.dumps({'status':'PASS_PREPARED_HELD_ONLY','units':6,'overlay_routes':12,'server_browser_producer_launched':False}))
