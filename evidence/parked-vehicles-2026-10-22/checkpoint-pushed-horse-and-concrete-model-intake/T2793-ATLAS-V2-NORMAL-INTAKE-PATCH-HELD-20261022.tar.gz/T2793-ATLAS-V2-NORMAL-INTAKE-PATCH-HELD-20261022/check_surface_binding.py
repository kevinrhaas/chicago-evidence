from pathlib import Path
import hashlib,importlib.util,json,shutil,tempfile
HERE=Path(__file__).resolve().parent
ROOT=Path('/tmp/chicago-covered-sag/chicago/4d')
p=HERE/'overlay/tools/transport/generate_parked_wagon_atlas.py'
s=importlib.util.spec_from_file_location('atlas_binder',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
raw=(ROOT/'renderers/web/transport/parked-wagon/wagon-w01.glb').read_bytes();authored=HERE/'overlay/assets/authored/transport/wagon_parked_atlas_v2'
r={'status':'RUNNING','fresh_generator_chain_executed':False,'scope':'Pure binder on pinned checked-in baseline; authored arrays/pixels only. Fresh source pipeline remains a required subsequent check.'}
try:
 result=m.bind_surface(raw,authored)
 expected=(HERE/'overlay/renderers/web/transport/parked-wagon-atlas-v2/wagon-w01.glb').read_bytes()
 assert result==expected
 r.update(output_sha256=m.sha(result),output_bytes=len(result),exact_candidate_equality=True)
 negatives=[]
 for name in ('baseline-mutation','payload-mutation','binding-position-accessor'):
  with tempfile.TemporaryDirectory(prefix='w01-atlas-negative-')as d:
   target=Path(d);shutil.copytree(authored,target,dirs_exist_ok=True);source=raw
   if name=='baseline-mutation':source=raw[:-1]+bytes([raw[-1]^1])
   elif name=='payload-mutation':
    q=target/'atlas-surface.bin';b=q.read_bytes();q.write_bytes(bytes([b[0]^1])+b[1:])
   else:
    q=target/'atlas-surface.json';b=json.loads(q.read_text());b['append_accessors'][0]['type']='VEC3';q.write_text(json.dumps(b))
   try:m.bind_surface(source,target)
   except ValueError as e:negatives.append({'name':name,'rejected':True,'error':str(e)})
   else:raise AssertionError('Mutation escaped guard: '+name)
 r.update(status='ACTUAL_BINDER_EXACT_EQUALITY_PASS_FRESH_CHAIN_PENDING',negative_controls=negatives)
except Exception as e:r.update(status='ACTUAL_BINDER_FAIL',error=repr(e));raise
finally:(HERE/'ACTUAL-SURFACE-BINDING-TEST.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
