# T2793: unapplied W01 atlas V2 normal intake

HELD outside the app. This package does not activate a model or establish photographic/period/world acceptance. The previous frozen V1/V2 capsules are unchanged. This parcel prepares ordinary source integration of the exact V2, not a new material candidate.

The patch changes only W01's manifest asset/basis, passes the existing renderer's `capabilities.maxTextureSize`, and selects the original W01 before any candidate fetch if the cap is missing, nonfinite or below2576. There is no product control, query selector or hidden feature flag. The selected original basis is also used in its card. Other models, placements, contacts, colors, paint, canvas/covered variants, pivots and source IDs are retained. Source/asset licence entries distinguish donor material credit from historical evidence.

## Actual checks

`ACTUAL-CAP-FETCH-BATCH-TEST.json` records execution of the patched loader with actual GLB vertex arrays/hierarchy, real vendored Three batching and simulated fetch/device caps:

-4096 and2576 fetch only the atlas;2048, missing, null, NaN and infinite caps fetch only original W01. The original is selected before any candidate fetch.
- Two same-model rows share one asset fetch; each merges into five material batches, with nine unique referenced textures. Actual flat-ground wheel/tongue checks and unchanged declared placement pass.
- Light detail fetches no model. Removing the guard in memory is rejected by the low-cap test.
- This is source/CPU evidence: no browser image decode, actual GLTFLoader material import, GPU upload, shader, shadows, picking or rendered appearance is accepted by it.

`ACTUAL-SURFACE-BINDING-TEST.json` proves the surface-only binder reproduces exact candidate `d65a4c5c471c7d61ddac3cc1826fda6283018ba87adef80dd8ac46cda908373a` (2724384bytes) from pinned original274e plus792564bytes of authored PNG and UV/TANGENT arrays. Baseline mutation, payload mutation and inserting a position-shaped accessor are rejected. No position/normal/index/hierarchy data is supplied by the append. **The full fresh source-generation chain was not run in this restricted lane.** The production command first regenerates the original through its unchanged source chain; cached geometry is not a command input.

The first CPU harness incorrectly assumed indexed triangles. Its actual FAIL is preserved as `ACTUAL-CAP-FETCH-BATCH-TEST-fixture-v1-FAIL.json`; only the fixture optional-index reader was corrected because the actual W01 is non-indexed triangle soup. Production loader, candidate and test cases were unchanged. `PATCH-AUTHORING-CORRECTIONS.json` also records the newline diff packaging fix and correct inherited GPL licence for UV/tangent charts.

`ACTUAL-PATCH-CHECK.json` records `git apply --check` and source-pin equality. This is an applicability check, not an application. No active Git tree or asset was changed.

## Actual upload and cost implications

The site's import map uses Three0.185.1. Its renderer creates WebGL2 and rejects WebGL1. The vendored GLTFLoader keeps repeat wrapping and linear-mipmap-linear sampling and enables mip generation for these PNGs. The actual WebGL2 texture path applies those sampler settings directly; the2576×264NPOT dimensions are supported. No power-of-two padding, extra sampler workaround or transmission pass is needed.

The same renderer resizes an oversize ImageBitmap/HTML image before upload. On MAX_TEXTURE_SIZE2048 this would become2048×209, destroying the exact native UV/sample correspondence. The ordinary fallback therefore happens before fetch rather than accepting that silent resize. Passing the actual renderer cap avoids a second probe context or guess based on device name. MAX_TEXTURE_SIZE is only an image-dimension capability, not a GPU-memory or performance guarantee.

The source GLB keeps23meshes/23primitives/6material definitions. Five materials are actually referenced; the current rigid same-material merge yields five batches per W01 ordinary render pass, shared nine textures total (three unique map samplers per material; roughness/metalness share ORM). This matches original W01. Shadows/confidence passes can repeat those draws. No whole-scene refraction pass is introduced. Images/materials are cached per model, not duplicated per parked row.

`RUNTIME-COST-AUDIT.json` derives image sizes and all-mip RGBA8 dimension costs from the embedded PNGs: atlas12976992bytes versus baseline6291684bytes, +6685308bytes (about6.38MiB). These are dimension estimates, not measured driver allocations. The atlas adds797532downloadbytes over original. Current W01 loading is outside the building texture-residency pool; hiding it beyond100m/full or65m/balanced does not release its images. Light avoids initial loading; switching to light after a load does not evict it. No invented material-memory acceptance threshold is added.

The native donor timber information remains145×40pixels. Packing/repeating it in a2576×264atlas does not increase photographic source resolution. Four-pixel periodic gutters support the already tested near/base sampling but do not qualify coarse-mip separation. Anisotropic/coarse minification, actual texture upload/memory, close/far/shadow views and unchanged world budgets still need actual visual/GPU review. If those fail, retain original W01; this patch supplies no automatic quality claim or threshold relaxation.

## Rights and historical grade

Timber detail is adapted from [Old Cart](https://sketchfab.com/3d-models/old-cart-f536745fd82144eeb5cc4900a48e816e) by [Lyskilde / longtail](https://sketchfab.com/longtail), [CC BY4.0](https://creativecommons.org/licenses/by/4.0/). Original creator and matching Objaverse licence metadata are copied exactly under authored source-credits. Changes and links are retained in both runtime and authored attribution. Donor-derived timber pixels remain CC BY4.0; original cut-end pixels remain CC0-1.0; original geometry and authored UV/tangent derivative charts remain GPL-3.0-or-later. The donor's actual9,809,548byte GLB hash is13600b73c1777545e1454d452c58d141469f031b2c5e6c29b1c6fdefe9145046; it is not a runtime or geometry-generation input.

No maker, manufacture date, Dearborn type, Chicago specimen, historical paint, photograph/scan method or measured species is established. The dated W01 type/placement is the existing project reconstruction, not a donor identification. This does not relabel any covered wagon or establish an owner.

## Recovery and later integration

`overlay/` is a proposed normal app/source layout, not an active tree. `UNAPPLIED-normal-intake.patch` contains textual changes/new files. `OVERLAY-INVENTORY.json` identifies every proposed file and hash, including binary payload/runtime GLB and exact source-credit metadata not represented in the textual patch. Do not use the text patch alone as a complete installation. Compare `BASE-SOURCE-PINS.json` first; root must reconcile adjacent main/constructor option additions with the separately held Brougham-mid patch.

After the root authorizes actual visual comparison/integration and the exclusive browser lane closes, place the authored data and new producer in the reviewed app branch, then run the fresh producer:

```
python tools/transport/generate_parked_wagon_atlas.py \
  --parameters data/transport/parked/wagon-w01.json \
  --output-dir renderers/web/transport/parked-wagon-atlas-v2 --verify
```

It runs the unchanged original generator into a temporary directory, verifies baseline274e, binds only authored UV/tangent/pixels, and verifies exact d65a4c. A first fresh generation failure must be preserved and diagnosed, not bypassed with the packaged GLB. Existing parked-placement validators and required repository checks still apply after actual integration. No fullgate, fresh source chain or browser/world proof is claimed here. Actual ordinary1835 W01 close/medium/far views and native cuts/boards/hubs/shadows are the next appearance evidence; existing covered variants must remain visibly distinct and unchanged. Keep this entire parcel held until those reviews.
