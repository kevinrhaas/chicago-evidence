// Source-only execution. Real patched loader, actual GLB arrays, vendored Three
// batching; simulated network and device caps. No browser, image decode or GPU.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import crypto from 'node:crypto';
const HERE=path.dirname(new URL(import.meta.url).pathname);
const ROOT='/tmp/chicago-covered-sag/chicago/4d';
const OVER=path.join(HERE,'overlay');
const threeURL=pathToFileURL(`${ROOT}/renderers/web/vendor/three-0.185.1/three.module.js`).href;
const THREE=await import(threeURL);
const utility=fs.readFileSync(`${ROOT}/renderers/web/vendor/three-0.185.1/addons/utils/BufferGeometryUtils.js`,'utf8').replaceAll("from 'three'",`from '${threeURL}'`);
const utilityURL=`data:text/javascript;base64,${Buffer.from(utility).toString('base64')}`;
const actualSource=fs.readFileSync(`${OVER}/renderers/web/js/parked-transport.js`,'utf8');
function parse(file){
 const raw=fs.readFileSync(file),n=raw.readUInt32LE(12);return {g:JSON.parse(raw.subarray(20,20+n)),bin:raw.subarray(28+n)};
}
const baseline=parse(`${ROOT}/renderers/web/transport/parked-wagon/wagon-w01.glb`);
const atlas=parse(`${OVER}/renderers/web/transport/parked-wagon-atlas-v2/wagon-w01.glb`);
function fixture({g,bin}){
 const types={5126:Float32Array,5125:Uint32Array,5123:Uint16Array};
 const sizes={SCALAR:1,VEC2:2,VEC3:3,VEC4:4};
 function attr(ai){
  const a=g.accessors[ai],v=g.bufferViews[a.bufferView],C=types[a.componentType];
  assert(C&&!v.byteStride&&!a.sparse,'Fixture only handles actual packed source arrays');
  const start=(v.byteOffset??0)+(a.byteOffset??0),bytes=bin.subarray(start,start+a.count*sizes[a.type]*C.BYTES_PER_ELEMENT);
  const array=new C(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
  return new THREE.BufferAttribute(array,sizes[a.type],a.normalized??false);
 }
 const textures=g.images.map(()=>new THREE.Texture());
 const materials=g.materials.map(m=>{
  const p=m.pbrMetallicRoughness??{},out=new THREE.MeshStandardMaterial({name:m.name});
  if(p.baseColorTexture)out.map=textures[g.textures[p.baseColorTexture.index].source];
  if(p.metallicRoughnessTexture)out.roughnessMap=out.metalnessMap=textures[g.textures[p.metallicRoughnessTexture.index].source];
  if(m.normalTexture)out.normalMap=textures[g.textures[m.normalTexture.index].source];
  return out;
 });
 const meshes=g.meshes.map(m=>{
  assert.equal(m.primitives.length,1);const p=m.primitives[0],geometry=new THREE.BufferGeometry();
  for(const [glName,name]of [['POSITION','position'],['NORMAL','normal'],['TEXCOORD_0','uv'],['TANGENT','tangent']])if(p.attributes[glName]!=null)geometry.setAttribute(name,attr(p.attributes[glName]));
  if(p.indices!=null)geometry.setIndex(attr(p.indices));return new THREE.Mesh(geometry,materials[p.material]);
 });
 const nodes=g.nodes.map(n=>{
  const o=n.mesh==null?new THREE.Group():meshes[n.mesh].clone();o.name=n.name??'';
  if(n.matrix)o.applyMatrix4(new THREE.Matrix4().fromArray(n.matrix));
  else{if(n.translation)o.position.fromArray(n.translation);if(n.rotation)o.quaternion.fromArray(n.rotation);if(n.scale)o.scale.fromArray(n.scale);}
  return o;
 });
 g.nodes.forEach((n,i)=>(n.children??[]).forEach(c=>nodes[i].add(nodes[c])));
 const root=new THREE.Group();for(const i of g.scenes[g.scene??0].nodes)root.add(nodes[i]);return {scene:root};
}
let requests=[];
globalThis.__W01Loader=class{async loadAsync(url){requests.push(url);if(url.endsWith('/parked-wagon-atlas-v2/wagon-w01.glb'))return fixture(atlas);if(url.endsWith('/parked-wagon/wagon-w01.glb'))return fixture(baseline);throw Error(`Unexpected simulated asset ${url}`);}};
async function loadModule(source){
 source=source.replace("import * as THREE from 'three';",`import * as THREE from '${threeURL}';`)
 .replace("import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';",'const GLTFLoader = globalThis.__W01Loader;')
 .replace("import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';",`import { mergeGeometries } from '${utilityURL}';`)
 .replace("import { disposeLoadedAsset } from './scene-loader.js';",'const disposeLoadedAsset = () => {};')
 .replaceAll('import.meta.url',JSON.stringify(pathToFileURL(`${ROOT}/renderers/web/js/parked-transport.js`).href));
 return import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
}
const production=await loadModule(actualSource);
const record=JSON.parse(fs.readFileSync(`${OVER}/data/transport/parked/placements.json`,'utf8'));
const row=record.scenes['1835'].find(r=>r.model==='wagon_w01');assert(row);
const controlled={...record,scenes:{'1835':[row,{...row,id:row.id+'-cache-probe'}]}};
globalThis.fetch=async()=>({ok:true,json:async()=>structuredClone(controlled)});
const results=[];
async function run(module,label,cap,expected,detail='full'){
 requests=[];const problems=[];
 const opts={dataBase:'https://fixture.invalid/data/',sceneId:'1835',terrain:{surfaceHeight:()=>0},detail,problems};
 if(label!=='missing-cap')opts.maxTextureSize=cap;
 const out=await module.createParkedTransport(opts);
 if(detail==='light'){assert.deepEqual(requests,[]);assert.equal(out.instances.length,0);}
 else{
  assert.equal(requests.length,1,'Actual per-model promise cache must fetch only once');
  assert(requests[0].endsWith(`/transport/${expected}/wagon-w01.glb`),`${label}: selected ${requests[0]}`);
  assert(!requests.some(url=>url.includes(expected==='parked-wagon'?'parked-wagon-atlas-v2/':'/parked-wagon/')),'Forbidden candidate/fallback fetch occurred');
  assert.deepEqual(problems,[]);assert.equal(out.instances.length,2);
  assert(out.instances.every(i=>i.draw_batches===5),'Actual vendored merge must retain five batches');
  const mats=new Set(),textures=new Set();out.group.traverse(n=>{if(n.isMesh){mats.add(n.material);for(const v of Object.values(n.material))if(v?.isTexture)textures.add(v);}});
  assert.equal(mats.size,5);assert.equal(textures.size,9);
  const expectedBasis=expected==='parked-wagon'?record.models.wagon_w01.fallback_basis:record.models.wagon_w01.basis;
  assert(out.instances.every(i=>i.card.sidecar.attributes.vehicle_type.note===expectedBasis),'Card must describe actual selected material');
  assert(out.instances.every(i=>i.wheel_clearance_m===0 && i.parking.minimum_clearance_m>=0 && i.parking.minimum_clearance_m<1e-6));
  assert(out.instances.every(i=>i.group.position.x===i.row.at_local_enu_m[0]&&i.group.position.z===-i.row.at_local_enu_m[1]));
 }
 results.push({label,cap:Number.isFinite(cap)?cap:String(cap),detail,requests:[...requests],instances:out.instances.length,draw_batches_per_instance:out.instances.map(i=>i.draw_batches)});
 out.dispose();
}
const terminal={status:'RUNNING',scope:'Actual patched loader and vendored geometry batching, actual GLB arrays; simulated fetch/caps. No browser/image decode/GLTFLoader material import/GPU/render acceptance.'};
try{
 for(const [label,cap,expected]of [['high-cap',4096,'parked-wagon-atlas-v2'],['exact-cap',2576,'parked-wagon-atlas-v2'],['low-cap',2048,'parked-wagon'],['missing-cap',undefined,'parked-wagon'],['null-cap',null,'parked-wagon'],['nan-cap',NaN,'parked-wagon'],['infinite-cap',Infinity,'parked-wagon']])await run(production,label,cap,expected);
 await run(production,'light',4096,null,'light');
 const needle='const useFallback = declaredSpec.required_max_texture_size != null\n            && (!Number.isFinite(maxTextureSize) || maxTextureSize < declaredSpec.required_max_texture_size);';
 assert(actualSource.includes(needle));
 const mutated=await loadModule(actualSource.replace(needle,'const useFallback = false; // negative-control mutation'));
 let rejected=false;try{await run(mutated,'negative-control-disabled-guard',2048,'parked-wagon');}catch(e){rejected=true;terminal.negative_control_error=String(e);}
 assert(rejected,'Disabled guard mutation escaped low-cap fetch assertion');
 terminal.status='ACTUAL_SOURCE_CAP_SELECTION_BATCHING_PASS_UNRENDERED';terminal.disabled_guard_negative_control_rejected=true;terminal.results=results;
 terminal.patched_source_sha256=crypto.createHash('sha256').update(actualSource).digest('hex');
}catch(error){terminal.status='ACTUAL_SOURCE_CHECK_FAIL';terminal.error=String(error);process.exitCode=1;}
finally{fs.writeFileSync(path.join(HERE,'ACTUAL-CAP-FETCH-BATCH-TEST.json'),JSON.stringify(terminal,null,2)+'\n');console.log(JSON.stringify(terminal));}
