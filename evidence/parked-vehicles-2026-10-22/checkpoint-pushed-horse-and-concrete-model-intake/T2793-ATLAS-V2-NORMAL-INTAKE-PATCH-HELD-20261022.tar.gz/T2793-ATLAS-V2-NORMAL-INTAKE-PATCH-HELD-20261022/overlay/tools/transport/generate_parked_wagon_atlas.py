#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Generate W01 atlas V2 from the original source chain plus authored surface charts.

No cached GLB input: main first regenerates the unchanged baseline. Authored
binary data contains only PNG pixels and UV/tangent arrays, never geometry.
The candidate remains an unaccepted material reconstruction pending visual review.
"""
from pathlib import Path
import argparse,copy,hashlib,json,struct,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[2]
AUTHORED=ROOT/'assets/authored/transport/wagon_parked_atlas_v2'
PARENT='274e737b51872983df792d0b24de8e75de8631890a8d586a32d9c6f0066484fb'
EXPECTED='d65a4c5c471c7d61ddac3cc1826fda6283018ba87adef80dd8ac46cda908373a'
def need(ok,message):
    if not ok:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def unpack(raw):
    magic,version,total=struct.unpack_from('<III',raw);need((magic,version,total)==(0x46546c67,2,len(raw)),'Invalid GLB header')
    size,kind=struct.unpack_from('<II',raw,12);need(kind==0x4e4f534a,'Missing JSON')
    g=json.loads(raw[20:20+size]);size2,kind2=struct.unpack_from('<II',raw,20+size)
    need(kind2==0x004e4942 and 28+size+size2==len(raw),'Missing exact BIN')
    return g,raw[28+size:]
def bind_surface(raw,authored=AUTHORED):
    need(sha(raw)==PARENT,'Fresh baseline bytes differ from reviewed original')
    binding=json.loads((authored/'atlas-surface.json').read_text());extra=(authored/'atlas-surface.bin').read_bytes()
    need(binding['schema']=='w01_surface_append_v2' and binding['parent_sha256']==PARENT and binding['expected_glb_sha256']==EXPECTED,'Unexpected authored binding')
    need(sha(extra)==binding['payload_sha256'],'Authored surface payload changed')
    g,binary=unpack(raw);before=copy.deepcopy(g)
    need(len(binary)==binding['parent_binary_bytes'] and len(binary)+len(extra)==binding['output_binary_bytes'],'Unexpected surface append offset')
    views=binding['append_buffer_views'];accessors=binding['append_accessors'];attrs=binding['mesh_attribute_bindings']
    need(len(views)==19 and len(accessors)==16 and len(attrs)==8,'Unexpected surface array counts')
    original_views=len(g['bufferViews']);original_accessors=len(g['accessors'])
    image_views={v['bufferView'] for v in binding['image_replacements'].values()}
    attribute_views={v['bufferView'] for v in accessors}
    need(image_views.isdisjoint(attribute_views) and image_views|attribute_views==set(range(original_views,original_views+19)),'Append contains unowned data views')
    need(len(image_views)==3 and all(v['componentType']==5126 and v['type']in ('VEC2','VEC4') for v in accessors),'Only float UV/tangent arrays permitted')
    for view in views:
        need(view['buffer']==0 and view['byteOffset']>=len(binary) and view['byteOffset']+view['byteLength']<=len(binary)+len(extra),'Surface view escapes append')
    for vi in image_views:
        v=views[vi-original_views];p=v['byteOffset']-len(binary)
        need(extra[p:p+8]==b'\x89PNG\r\n\x1a\n','Image append is not PNG')
    g['bufferViews'].extend(views);g['accessors'].extend(accessors)
    for image,replacement in binding['image_replacements'].items():
        need(int(image)in (0,1,2) and replacement['mimeType']=='image/png','Only shared wood images may change')
        g['images'][int(image)]=replacement
    need(set(binding['image_replacements'])=={'0','1','2'},'Wood image mapping incomplete')
    for chart in attrs:
        mesh=g['meshes'][chart['mesh']];need(len(mesh['primitives'])==1 and mesh['primitives'][0]['material']in (1,2,3),'Surface chart targets nonwood')
        attributes=mesh['primitives'][0]['attributes'];count=g['accessors'][attributes['POSITION']]['count']
        for name,kind in [('TEXCOORD_0','VEC2'),('TANGENT','VEC4')]:
            ai=chart[name];need(original_accessors<=ai<len(g['accessors']),'Surface chart must use append')
            acc=g['accessors'][ai];need(acc['count']==count and acc['type']==kind,'Surface chart vertex ownership differs')
            attributes[name]=ai
    for mi,values in binding['wood_materials'].items():
        need(int(mi)in (1,2,3),'Paint/iron material mutation forbidden')
        need(values['normalTexture']=={**before['materials'][int(mi)]['normalTexture'],'scale':0.35},'Only reviewed wood normal scale may change')
        g['materials'][int(mi)].update(values)
    need(set(binding['wood_materials'])=={'1','2','3'},'Wood material mapping incomplete')
    g['asset']['copyright']=binding['asset_copyright']
    need(set(binding['extras_updates'])<= {'material_study','timber_surface_atlas_candidate'},'Unexpected geometry metadata mutation')
    g['extras'].update(binding['extras_updates']);g['buffers'][0]['byteLength']=len(binary)+len(extra)
    for key in ('nodes','skins','animations','scene','scenes','textures','samplers'):
        need(g.get(key)==before.get(key),'Protected hierarchy/texture binding changed: '+key)
    for a,z in zip(before['meshes'],g['meshes']):
        a=copy.deepcopy(a);z=copy.deepcopy(z)
        for p in [a,z]:
            for primitive in p['primitives']:
                for attr in ('TEXCOORD_0','TANGENT'):primitive['attributes'].pop(attr,None)
        need(a==z,'Position/normal/topology/material ownership changed')
    head=json.dumps(g,separators=(',',':')).encode();head+=b' '*((-len(head))%4);data=binary+extra
    result=struct.pack('<III',0x46546c67,2,28+len(head)+len(data))+struct.pack('<II',len(head),0x4e4f534a)+head+struct.pack('<II',len(data),0x004e4942)+data
    need(sha(result)==EXPECTED,'Bound surface differs from exact reviewed V2')
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parameters',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    parser.add_argument('--verify',action='store_true')
    args=parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='w01-atlas-source-')as temp:
        subprocess.run([sys.executable,str(ROOT/'tools/transport/generate_parked_wagon.py'),'--parameters',str(args.parameters),'--output-dir',temp],check=True)
        raw=bind_surface((Path(temp)/'wagon-w01.glb').read_bytes())
    target=args.output_dir/'wagon-w01.glb'
    if args.verify:need(target.is_file()and target.read_bytes()==raw,'Stale or missing atlas output')
    else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    print(json.dumps({'glb_sha256':sha(raw),'source_regenerated':True,'verified':args.verify,'visual_acceptance':False}))
if __name__=='__main__':main()
