"""Root-released reconnection recovery: only three original pending run IDs, no inventory."""
import datetime,hashlib,json,os,pathlib,re,subprocess,time
from strict_helpers import need,audit_job,checkout_sha,smoke_cell
HERE=pathlib.Path(__file__).resolve().parent
OUT=pathlib.Path('/workspace/shared/PR1175-RECONNECTED-REMAINING3-GET-owner1')
STEPS=['Set up job','Run actions/checkout@v4','Run actions/setup-node@v4','Install Playwright','Publish the mirror the smoke serves (site/4d/ is generated)','Run the smoke against the published mirror','Complete job']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def main():
 lanes=json.loads((HERE/'LANES.json').read_bytes());need(len(lanes)==3,'Exactly three remaining run IDs')
 for c in lanes:need(not pathlib.Path('/proc/'+str(c['prior_pid'])).exists(),'Prior owner still present')
 lock=pathlib.Path(str(OUT)+'.lock');lock.mkdir(exist_ok=False);OUT.mkdir(exist_ok=False)
 state={'status':'RECONNECTED_FIXED_THREE_GET_COLLECTING','started':now(),'pid':os.getpid(),'source_sha256':sha(pathlib.Path(__file__).read_bytes()),'strict_helper_sha256':sha((HERE/'strict_helpers.py').read_bytes()),'poll_seconds':60,'POSTs':0,'CI_reruns':0,'cancellations':0,'workflow_inventory_requests':0,'automatic_retries':0,'qualification_pass':False,'current_final_head_qualified':False,'original_absolute_allowances_retained':True,'lanes':lanes}
 save(OUT/'OWNER.json',state);save(lock/'OWNER.json',{'pid':os.getpid(),'started':state['started']});print(json.dumps({'pid':os.getpid(),'output':str(OUT),'status':state['status']}),flush=True)
 number=0;audited={};cache={};inherited={}
 for c in lanes:
  old=pathlib.Path(c['prior_owner']);need(sha((old/'AUDITED-JOBS.json').read_bytes())==c['prior_audited_sha256'],'Prior audit changed');inherited[c['label']]=json.loads((old/'AUDITED-JOBS.json').read_bytes());save(OUT/(c['label']+'-INHERITED-AUDIT.json'),inherited[c['label']]);cache[c['run_id']]=json.loads((HERE/(c['label']+'-RUN.json')).read_bytes())
 def api(label,route,plain=False):
  nonlocal number
  number+=1;p=OUT/('%04d-%s'%(number,label));r=subprocess.run(['gh','api','--method','GET','repos/kevinrhaas/chicago/'+route],capture_output=True,timeout=45);p.with_suffix('.stdout').write_bytes(r.stdout);p.with_suffix('.stderr').write_bytes(r.stderr)
  with (OUT/'GET-ATTEMPTS.jsonl').open('a')as f:f.write(json.dumps({'at':now(),'route':route,'exit':r.returncode,'stdout_sha256':sha(r.stdout),'retry':False})+'\n')
  need(r.returncode==0,'GET unavailable, preserve/no retry: '+label+' '+r.stderr.decode(errors='replace')[-300:]);return r.stdout.decode()if plain else json.loads(r.stdout)
 first=True
 try:
  while len(audited)<3:
   tick=time.monotonic()
   for c in lanes:
    rid=c['run_id']
    if rid in audited:continue
    if datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(c['original_absolute_deadline_utc']):audited[rid]={'run_id':rid,'PASS':False,'status':'ORIGINAL_ABSOLUTE_COLLECTION_DEADLINE_NO_RETRY'};continue
    r=cache[rid]if first else api('run-'+str(rid),'actions/runs/'+str(rid));cache[rid]=r
    need(r['head_sha']==c['head']and r['head_branch']==c['branch']and r['event']=='workflow_dispatch'and r['run_attempt']==1 and r['workflow_id']==365585058 and r['path']=='.github/workflows/chicago-4d-smoke.yml'and r['repository']['full_name']=='kevinrhaas/chicago','Actual fixed run identity drift')
    if r['status']!='completed':continue
    save(OUT/('RUN-'+str(rid)+'.json'),r);jobs=api('jobs-'+str(rid),'actions/runs/'+str(rid)+'/attempts/1/jobs?per_page=100');save(OUT/('RUN-'+str(rid)+'-JOBS.json'),jobs);need(jobs['total_count']==len(jobs['jobs'])==1,'Unexpected smoke job inventory');job=jobs['jobs'][0];log=api('job-'+str(job['id'])+'-log','actions/jobs/'+str(job['id'])+'/logs',True)
    p={'run_id':rid,'job_id':job['id'],'head':c['head'],'tree':c['tree'],'branch':c['branch'],'event':r['event'],'workflow_id':r['workflow_id'],'workflow_path':r['path'],'run_attempt':1,'job_log_sha256':sha(log.encode()),'PASS':False,'lane':c['label'],'original_absolute_deadline_utc':c['original_absolute_deadline_utc']}
    try:
     p['actual_checkout_sha']=checkout_sha(log,c['head']);need(r['conclusion']=='success','Actual run conclusion '+str(r['conclusion']));p.update(audit_job(job,r,c['head'],'smoke',STEPS));cell=smoke_cell(log);need(cell==('desktop',c['stage']),'Actual remaining cell differs');counts=re.findall(r'(?m)^\S+Z\s+(\d+) passed, 0 failed\s*$',log);need(len(counts)==1 and int(counts[0])>0,'Missing exact nonzero terminal0fail count');need(api('final-ref-'+str(rid),'git/ref/heads/'+c['branch'])['object']['sha']==c['head'],'Immutable verification ref moved');p.update(viewport=cell[0],stage=cell[1],passed_assertions=int(counts[0]),failed_assertions=0,actual_smoke_step_terminal_success_exit0=True,PASS=True)
    except Exception as error:p.update(PASS=False,error=str(error),causal_lines=[x for x in log.splitlines()if re.search(r'\bFAIL\b|\bfail\b|Error:|exit code',x)][-50:])
    audited[rid]=p;save(OUT/('RUN-'+str(rid)+'-STRICT-PROOF.json'),p);save(OUT/'AUDITED-REMAINING-JOBS.json',list(audited.values()));combined=inherited[c['label']]+[p];save(OUT/(c['label']+'-COMPLETE-AGGREGATE.json'),{'head':c['head'],'jobs':combined,'strict_success':sum(x['PASS']for x in combined),'actual_failures':sum(not x['PASS']for x in combined),'qualification_pass':False,'current_final_head_qualified':False});print(json.dumps({'at':now(),'new_terminal':p}),flush=True)
   first=False;state.update(at=now(),remaining_terminal_collected=len(audited),strict_remaining_success=sum(x.get('PASS',False)for x in audited.values()),runs=[{'id':c['run_id'],'lane':c['label'],'status':cache[c['run_id']]['status'],'conclusion':cache[c['run_id']]['conclusion']}for c in lanes],api_requests=number);save(OUT/'LATEST.json',state);print(json.dumps({'at':state['at'],'terminal':len(audited),'success':state['strict_remaining_success'],'runs':state['runs']}),flush=True)
   if len(audited)==3:state['status']='RECONNECTED_THREE_REMAINING_TERMINAL_SOURCE_EVIDENCE_ONLY';break
   remaining=60-(time.monotonic()-tick)
   if remaining>0:time.sleep(remaining)
 except Exception as error:state.update(status='STOPPED_GET_OR_BINDING_ERROR_NO_RETRY',error=str(error))
 finally:state['ended']=now();save(OUT/'TERMINAL.json',state);save(OUT/'LATEST.json',state);print(json.dumps(state),flush=True)
 return 0 if len(audited)==3 and all(x.get('PASS',False)for x in audited.values())else 1
if __name__=='__main__':raise SystemExit(main())
