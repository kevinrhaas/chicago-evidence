Current-source repin only. Original c92a caller and d706 wrapper are BYTE IDENTICAL; REPiN-ONLY.patch changes only configs/head/tree/publication bindings and packet-local ownership paths. Root has not released or run either phase. PR1175 remains an unmerged dependency via8fc; latest73/subsequent person source excluded.

Prepared only: NO BROWSER EXECUTION and NO ROOT LANE RELEASE.

Target is the clean pushed horse commit a47401a24950ec2d6cd652e4badad89533a1fc16, treec9e0b41b746de967d73765633702dac748178d63, and its actual published mirror. Selected model c2559073, original41acd9, idle56a236a9, modern-card758421ed and all source/published inputs are explicitly pinned. The caller verifies actual Git HEAD/tree/clean status and published build version before opening Chrome. It does not silently repin to a later combined world.

This is a copy of the frozen098 continuation, with only current source/publication binding and additive own-card/placement/resource-disposal assertions. CHANGES-FROM-098.patch makes the scope reviewable. The ownership wrapper is byte-identical d706e244: each yard phase has a360s whole-owner and350s execution cap, explicit Chrome /usr/bin/chromium and known Playwright dependency, fresh output only, owned browser/server cleanup, no automatic retry or next phase. All existing viewport/DPR/detail choices, fixed camera poses, .97 indexed-vertex framing, draw budgets, 1mm sampled per-foot minimum/-1e-5m penetration bounds, motion thresholds and wait deadlines remain unchanged.

Execute only after ROOT explicitly releases ONE named phase on a quiet browser lane. Create a separate ROOT-RELEASE JSON by copying that phase's HELD JSON and changing only released/browser_lane_free to true; retain every input pin. Then use the existing wrapper, for example:

    python3 /workspace/shared/HORSE-a474-PUBLISHED-CARD-IDLE-HELD-20261022/run_owned.py --lane-released --phase yard-desktop --release-file /workspace/shared/HORSE-a474-yard-desktop-ROOT-RELEASE.json --output-dir /workspace/shared/HORSE-a474-yard-desktop-ACTUAL

    python3 /workspace/shared/HORSE-a474-PUBLISHED-CARD-IDLE-HELD-20261022/run_owned.py --lane-released --phase yard-mobile --release-file /workspace/shared/HORSE-a474-yard-mobile-ROOT-RELEASE.json --output-dir /workspace/shared/HORSE-a474-yard-mobile-ACTUAL

Each command needs normal escalation for Chrome/loopback/Git readers. These are two separately released runs, never an automatic desktop→mobile chain.

What the product observations actually prove when they pass:

- Ordinary production host updates move actual weighted head/tail vertices, the clone skeleton is disjoint from the source skeleton, four annotated hoof patches stay within the unchanged1e-5m drift bound, and the original six clips are not autoplayed.
- Actual reduced-motion preference freezes bone/hoof state across eight rendered frames. Confidence-hidden actors neither advance nor pick. This hidden probe is reconstructed-confidence visibility, not an OS background/tab-visibility test; document.hidden is observed/logged but not forced.
- The actual placed WesternHotel actor is ray-picked through its real layer. Its production popup opens that hit.record, not a synthetic card. Exact ENU/yaw/location identity, modern2021author/CCBY credit in the recorded lead, absence of graded model_credit, attested0of4, retained citations and research credit are checked. own-card.png captures the real card. This is layer ray-pick + popup API coverage, not an OS pointer-event/end-to-end occlusion claim. Shared popup's generic building wording is outside this own-card repair.
- Light retires the instance/player; explicit event observations require three cloned geometries and three cloned materials disposed, zero owned mixers/instances. The normal coarse mobile path must release yard source arrays and use the bounded retained support cache.

Timing truth is deliberately separate:

The ORIGINAL15wall-second /1.5owned-second wait is unchanged. A failure stays in original_timing_check, sets process exit1 and forces final report.pass=false even if later product_checks all pass. This packet never lengthens the wait, feeds extra dt, accelerates the clip, changes the source or calls a failed yard run PASS. Each later product result is reported separately, including exact all-forwarded-host-dt accounting against the source's fresh zero-age/rest/rate contract.

For this seeded instance, delay.5750385086459663s and rate.9802204318391672 mean1.5ownedseconds require2.10530655eligiblehostseconds, at least nine updates under the production .25s frame cap. The old desktop had three eligible updates (.75s) in15.0117wallseconds and mathematically correct.17150082861027566ownedseconds; both original desktop timing FAIL receipts remain FAIL. The old original mobile PASS remains labeled fde6. A continuation can independently verify real motion/contact/pause/card/disposal on this source without pretending the timing test passed. If no actual head/tail movement occurred during the unchanged wait, its unchanged>1e-8m motion assertion also fails; no synthetic advance or extra wait conceals it.

The initial side/quarter/active screenshots retain the original fixed views, including the real fence occlusion. own-card.png adds provenance evidence. Neither the CPU proof nor these browser checks qualify photographic anatomy, continuous hoof collision, exhaustive neck/tail self-contact, phone hardware performance, walking/weight shift, fitted gear, hitching, riding or whole-ticket completion. No app source, Git index/ref, ticket, PR or gate is changed by preparation.
