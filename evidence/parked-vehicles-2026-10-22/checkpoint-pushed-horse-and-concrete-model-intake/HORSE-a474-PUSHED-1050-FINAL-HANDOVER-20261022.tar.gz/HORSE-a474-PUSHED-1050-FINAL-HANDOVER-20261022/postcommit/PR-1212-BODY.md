Adds one reconstructed horse in the 1835 Western Hotel wagon yard, using a licensed textured development model and a gentle source-derived head/tail idle. The individual, breed and owner remain unidentified. Full/Balanced load it lazily; Light keeps no horse model or idle player. A bounded retained yard-support cache permits grounding after coarse-device CPU geometry release. The original model and attribution are preserved.

The selection card identifies the horse as reconstructed and keeps the modern 2021 author/license credit outside historical confidence grades, retaining citations and research credit. No model, idle, placement, support or non-card consumer behavior changed during the card repair/integration.

Validation at pushed `a47401a24950ec2d6cd652e4badad89533a1fc16`, tree `c9e0b41b746de967d73765633702dac748178d63`:

- Canonical resolver passed all 200 producers, seven second-pass producers and the settled downstream tail. Normal publication/mirror and exact protected horse/runtime/person source checks passed. An earlier environment-interrupted resolver is preserved as interrupted, not successful.
- Full preflight passed **1,050 checks, including 381 self-tests**, with required readers and unchanged source. Global terminal logs were immediately preserved.
- Actual-commit changelog/ID/whitespace checks and postcommit publication/mirror passed. The branch is clean and the remote HEAD is verified.
- The focused own-card regression passes against the actual card helper/popup lead, with controls for the former false historical attestation and a missing modern citation.

**Dependency and tested base:** this normal merge includes still-unmerged person PR #1175 through its actual test-merge `8fc3fd3f0` (parents `8f5127d4` and DEV `7d9afc0e`). Both 1835 actor layers, their separate mixers/ground callbacks and the horse support region are preserved. The latest Wheeler DEV changes (`73aef…`) and subsequent person head are not included in this tested tree. Keep this PR draft and do not merge it before #1175 lands; current live-DEV integration/CI remains separate.

Earlier browser evidence remains labeled `fde6bc317`; protected model/idle/placement/support and non-card runtime bytes remain unchanged:

- The unchanged original mobile yard caller passed head/tail movement, zero drift of four annotated hoof patches, reduced-motion/confidence-hidden pause, coarse array release, selection and disposal. Three images were reviewed; the quarter view is partly occluded by the real fence. That run exposed the card defect repaired here.
- Desktop model/framing/budget/finite-contact checks passed. Both original desktop 15-wall-second/1.5-owned-second timing checks **failed** and remain failed. Exact source-clock accounting was confirmed under three slow software-rendered frames; independent review identifies the timing bound as a private caller heuristic. Later desktop product checks were not completed. No desktop performance qualification is claimed.

The repaired card and current integrated published world still need bounded browser verification. T-2800/T-2803 remain open: anatomy, eyes, solid mane/tail and the 1K coat remain development limits. No walking, four-leg weight shift, fitted gear, hitching, riding, photographic master, full-ticket completion or merge clearance is claimed.
