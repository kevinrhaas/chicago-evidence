from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/workspace/chicago-waistcoat')
HERE=Path(__file__).resolve().parent
HEAD='a086cd7dab31935f52adcb1ca8494a12726f9f27'
BASE='8fc3fd3f0db3088f61408e2fe4c0b993f623e1ee'
def git(*a): return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
state=json.loads((HERE/'STATE.json').read_text())
assert state['status']=='CANONICAL_POSTPUBLISH_MIRROR_PASS_AWAIT_POSTSOURCE_GUARDS',state
assert git('rev-parse','HEAD')==HEAD and git('rev-parse','MERGE_HEAD')==BASE
assert not git('diff','--name-only') and not git('ls-files','-u')
frozen=json.loads(Path('/workspace/shared/HORSE-POST1175-INTEGRATION-PREPARED-20261022/FROZEN-RESOLUTIONS.json').read_text())
checks={}
for path,info in frozen['files'].items():
    assert sha(ROOT/path)==info['resolved_sha256'],path
    checks[path]=info['resolved_sha256']
source=json.loads(Path('/workspace/shared/HORSE-8fc-PHASEA-SOURCE-CHECKPOINT-20261022/SOURCE-ASSERTIONS.json').read_text())
for path,expected in source['protected_sha256s'].items():
    assert sha(ROOT/path)==expected,path
    checks[path]=expected
for path,expected in frozen['required_incoming_person_blob_oids'].items():
    assert git('hash-object',path)==expected,path
    checks[path]=expected
# All licensed horse files remain the exact a086 source; no normalization/rebake here.
paths=git('ls-tree','-r','--name-only',HEAD,'chicago/4d/assets/authored/transport/horse_standing','chicago/4d/renderers/web/transport/standing-horse').splitlines()
assert paths
for path in paths:
    expected=git('rev-parse',HEAD+':'+path)
    assert git('hash-object',path)==expected,path
    checks[path]=expected
scene=json.loads((ROOT/'chicago/4d/data/scenes/1835.json').read_text())
# Exact authored scene hash above includes both independently owned actor layers/support.
manifest=json.loads((ROOT/'chicago/4d/docs/RESEARCH/glessner-v4-recovery/manifest.json').read_text())
for rel,info in manifest['files'].items():
    p=ROOT/'chicago/4d'/rel
    assert p.stat().st_size==info['bytes'] and sha(p)==info['sha256'],rel
out={'status':'PASS','head':HEAD,'merge_head':BASE,'canonical_resolve_publish_mirror':'PASS',
'authored_horse_person_guards':'PASS','staged_tree':git('write-tree'),'protected_checks':checks,
'latest_DEV73_Wheeler_included':False,'PR1175_dependency':'NOT_MERGED; keep PR1212 DRAFT',
'current_combined_browser':'NOT_RUN','earlier_interruption':'Preserved unchanged; not a successful run'}
(HERE/'POSTSOURCE-GUARD.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='protected_checks'},indent=2))
