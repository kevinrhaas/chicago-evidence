from pathlib import Path
import json,hashlib,re
D=Path(__file__).resolve().parent;P=D/'candidate/chicago/4d';C=Path('/workspace/shared/T2794-V17-GENUINE-RING16-MID-CANDIDATE-20261022');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();S=P/'tools/transport/brougham';A=P/'renderers/web/transport/parked-brougham'
p=S/'test_lod.mjs';s=p.read_text().replace('renderedTriangles','activeGeometryReadback');p.write_text(s)
p=S/'check_mid.py';s=p.read_text().replace("'source_or_app_edits':0", "'near_geometry_or_active_app_edits':0");p.write_text(s)
receipt={'scope':'Original actual closed external generation and lossless indexing, preserved as historical receipts. This proposed app intake does not regenerate geometry.','license':'GPL-3.0-or-later','source_recipe':'tools/transport/brougham/ring16-mid-lods.json','source_recipe_sha256':sha(S/'ring16-mid-lods.json'),'source_files':json.loads((C/'GENERATION-TERMINAL.json').read_bytes())['source_file_pins'],'actual_generation':json.loads((C/'GENERATION-TERMINAL.json').read_bytes()),'actual_lossless_indexing':json.loads((C/'INDEXING-RECEIPT.json').read_bytes()),'raw_delivery':'brougham-mid-source.glb','indexed_delivery':'brougham-mid.glb','near_source_unchanged':True,'runtime_world_visual_budget_accepted':False}
(A/'MID-BUILD-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
p=A/'brougham.json';s=json.loads(p.read_bytes());s['mid_provenance']['build_receipt']='MID-BUILD-RECEIPT.json';s['mid_provenance']['build_receipt_sha256']=sha(A/'MID-BUILD-RECEIPT.json');p.write_text(json.dumps(s,indent=2)+'\n')
p=S/'near-contract.json';c=json.loads(p.read_bytes());c['delivery_metadata_files']['brougham.json']=sha(A/'brougham.json');p.write_text(json.dumps(c,indent=2)+'\n')
p=S/'check_near.py';s=p.read_text();s=re.sub(r"EXPECTED_CONTRACT='[0-9a-f]+'", "EXPECTED_CONTRACT='"+sha(S/'near-contract.json')+"'",s,count=1);p.write_text(s)
p=S/'mid-contract.json';c=json.loads(p.read_bytes());c['build_receipt_sha256']=sha(A/'MID-BUILD-RECEIPT.json');p.write_text(json.dumps(c,indent=2)+'\n')
p=S/'check_mid.py';s=p.read_text();s=re.sub(r"mid_contract.read_bytes\(\)\)=='[0-9a-f]+'", "mid_contract.read_bytes())=='"+sha(S/'mid-contract.json')+"'",s,count=1);s=s.replace("    mc=json.loads(mid_contract.read_bytes())", "    mc=json.loads(mid_contract.read_bytes())\n    assert sha((ASSET/'MID-BUILD-RECEIPT.json').read_bytes())==mc['build_receipt_sha256']");p.write_text(s)
# Compact read-only pre/post protection review. The original card, static batcher,
# terrain/tongue solver and exact wheel/shoe base calculation remain verbatim.
O=D/'original/chicago/4d/renderers/web/js/parked-transport.js';N=P/'renderers/web/js/parked-transport.js';before=O.read_text();after=N.read_text();segments={}
for name,start,end in [('card','function card(', '/** Merge only static meshes'),('staticBatches','function staticBatches(', '/** Solve the lowest'),('parkTongue','function parkTongue(', 'export async function createParkedTransport'),('wheel_shoe_ground_solver','          const heights = spec.wheel_contacts_m.map', '          const parking = parkTongue(root, row, terrain, base);')]:
 a=before[before.index(start):before.index(end,before.index(start))];b=after[after.index(start):after.index(end,after.index(start))];assert a==b,name;segments[name]={'verbatim_equal':True,'sha256':hashlib.sha256(a.encode()).hexdigest()}
(D/'VERBATIM-PROTECTED-RUNTIME-SEGMENTS.json').write_text(json.dumps(segments,indent=2)+'\n')
print('Final proposed source frozen; original card/batching/terrain/tongue/support segments verbatim')
