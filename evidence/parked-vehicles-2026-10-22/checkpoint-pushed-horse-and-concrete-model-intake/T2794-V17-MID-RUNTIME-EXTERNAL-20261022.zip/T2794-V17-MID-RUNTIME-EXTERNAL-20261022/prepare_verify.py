from pathlib import Path
import shutil,json,hashlib
D=Path(__file__).resolve().parent;W=Path('/tmp/chicago-covered-sag/chicago/4d');V=D/'verification/chicago/4d';P=D/'candidate/chicago/4d'
# Exact read-only source dependencies. This partial fixture is not a Git worktree.
for rel in ['renderers/web/js','renderers/web/vendor/three-0.185.1','tools/transport/brougham','tools/transport/wagon_covered','data/transport/parked','renderers/web/transport','data/yard','data/sources']:
 src=W/rel;dst=V/rel
 if src.exists():shutil.copytree(src,dst,dirs_exist_ok=True)
for name in ['test_brougham_card.mjs','check_brougham_near.py']:
 target=V/'tools'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/'tools'/name,target)
for p in P.rglob('*'):
 if p.is_file():
  target=V/p.relative_to(P);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
print(V)
