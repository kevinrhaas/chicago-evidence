# Proposed Brougham near/mid runtime intake — external, not applied

This packet provides a normal binary/source patch against commit `3289b16cdc671a6ddf4c2e25587e8f0bd670fdb3`, tree `01d923aab229502a54e2804a4f816c17946018e3`. It installs the genuine 22,238-triangle wheel-ring mid beside the unchanged 33,502-triangle V17 near model, then selects between them for this Brougham alone. The app worktree remains clean at those exact pins. No browser, full gate, publication, commit, PR update or ticket mutation occurred.

## Proposed behavior

Both Full and Balanced use a standard `THREE.LOD`, with a minimum switch distance of 24 m and the class's existing 5% hysteresis. A larger actual drawing buffer or narrower field of view increases the near distance; camera zoom uses Three's normal LOD distance adjustment. Missing render-height information retains near. Conversation-distance geometry remains the original reviewed near asset. Full/Balanced/Light reach stays exactly 100 m/65 m/0; scene camera, stand, ground/contact solver, performance caps and legacy models/cards remain unchanged.

The candidate screen-size estimate uses the 0.65 m wheel radius's ring chord sagitta, `0.65 * (1 - cos(pi / 16))`, with a 2.5 m wheel-envelope reserve. It scales with actual drawing-buffer height, not CSS pixels. This is a proposed engineering selection policy, not an accepted half-pixel, material/shading or photographic guarantee. Fixed-view near/mid comparison is still required. At the historical source spawn distance of 25.227878 m and an 800-pixel buffer, the actual selector chooses mid; a 3200-pixel buffer or 2x zoom restores near there.

Both assets are cached once per transport instance using the existing asset map. Each is separately merged into seven material batches; only one level is displayed. Picking starts at the active level because Three's default recursive raycast also traverses invisible children. The unchanged card owner is on the shared LOD parent. The renderer cannot independently switch levels during shadow rendering. Mid load/batch failure keeps near with a reported problem. Disposal follows existing cached-source ownership and retires both sets of merged buffers.

## Actual focused results

The final three checks closed PASS on the external partial fixture:

- Exact near plus genuine mid native gate: 1.569 s. Original source, material, anchor, full bounds and rigid support guards remain. The independent mid check binds exact raw/indexed payloads, recipe, build receipt and original validator reports; it checks all 452 protected parts through actual node roles and retains the three mutation controls.
- Existing Brougham card entry plus its narrow runtime helper: 0.401 s. Actual popup/card equality holds for all six legacy placements. Real vendored Three and GLTF parsing read back near/mid counts and seven merged batches, then exercise hysteresis, resize/zoom, active-level picking, confidence hiding, original reach, Light boot, cache reuse, failure fallback and disposal. A negative control proves ordinary recursive LOD picking visits inactive geometry. Disposing a Light-to-Full load while its actual mid request is pending attaches no late model and disposes source resources once.
- Existing parked placement and covered identity gate: 0.049 s. All scene rows and all four legacy model specifications remain exact.

The runtime unit uses synthetic flat support ground and local file reads; it is not current world or GPU proof. For unchanged C02 image-bearing materials, Node supplies a minimal bitmap object at the image decode boundary; pixel appearance is not tested. Brougham has no image/UV streams. Initial Node test-harness and partial-fixture failures are retained, including the refused runner syntax check and missing dependencies. No existing world view or acceptance threshold was moved to make these unit checks pass.

## Apply and recovery

`BROUGHAM-MID-RUNTIME.patch` is the complete 19-file normal patch. `git apply --check` passed read-only against the exact app base. `SOURCE-PINS-AND-RESTORE-MANIFEST.json` lists every path, old hash or expected absence, new hash and payload size. `candidate/` holds exact replacement payloads; `original/` holds edited preimages. No patch was applied to the app. Do not copy the partial verification fixture into the repository.

The patch honestly adds the mid to sidecar/placement metadata and updates only the near contract's metadata hash and two-level statement. Every original near geometry and producer pin remains unchanged. The original near build receipt remains historical; the additive `MID-BUILD-RECEIPT.json` preserves the actual completed mid generation and lossless-indexing receipts. Existing registered Brougham check entries invoke the narrow added helpers, avoiding a new gate framework. After actual intake, use the supported derived/isolation workflow and normal full gate; no full-gate result is claimed for this unapplied patch.

Original source/license snapshots are in `provenance/`. Complete earlier generation proof is also sealed in `/workspace/shared/T2794-V17-GENUINE-RING16-MID-CANDIDATE-20261022.zip`, SHA-256 `2a0e2154aa3d11e03c38bb502ce1339dd8e112f63042a192943ee338a3c0288c`. Native metadata retains GPL-3.0-or-later attribution and the 1893 Studebaker catalogue design reference. This is a reconstructed individual, with no attested owner or presence at the 1904 stop. No occupied/animated/boarding capability is enabled.

Historical packet-construction scripts are retained for recovery; they are not an automatic replay or producer instruction. The changed product files and registered checks are under `candidate/`.

## Adjacent W01 integration

The independent W01 atlas proposal adds `maxTextureSize = null` to the same constructor options and `maxTextureSize: renderer.capabilities.maxTextureSize` beside the main call's `groundHeight` property. Combine these adjacent options manually with `getDrawingBufferHeight = () => null` and its actual buffer provider; preserve both. Its loader selection begins at `const spec = record.models[row.model]`, while this Brougham block begins after the existing parking solve. No W01 proposal has been applied or overwritten here.

The source base is historical DEV8249 plus Brougham, not current DEV. Current combined world obstacles, canopy, actual render-frame budgets and desktop/mobile fixed-view quality remain pending. The original ordinary-world deadline failures stay failures; this packet does not replace them.
