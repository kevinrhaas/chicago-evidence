from pathlib import Path
import json,subprocess,datetime,time,os
D=Path(__file__).resolve().parent;V=D/'verification/chicago/4d';results=[]
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
for name,cmd in [('native',['python3','tools/check_brougham_near.py']),('card-and-runtime',['node','tools/test_brougham_card.mjs']),('placements',['python3','tools/transport/check_parked_placements.py'])]:
 start=time.monotonic()
 try:
  p=subprocess.run(cmd,cwd=V,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=14)
  code=p.returncode;output=p.stdout
 except subprocess.TimeoutExpired as exc:code=124;output=exc.stdout or b''
 (D/('FOCUSED-'+name+'.log')).write_bytes(output)
 row={'name':name,'command':cmd,'cwd':str(V),'exit':code,'seconds':round(time.monotonic()-start,3),'bound_seconds':14,'log':'FOCUSED-'+name+'.log'};results.append(row);print(json.dumps(row),flush=True)
 if code:break
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'CLOSED_PASS'if len(results)==3 and all(r['exit']==0 for r in results)else'CLOSED_FAIL','results':results,'scope':'External exact-source partial fixture and real GLB/Three checks only; no WebGL, world-ground, visual, performance or photographic acceptance.'};(D/'FOCUSED-TERMINAL.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(0 if receipt['state']=='CLOSED_PASS' else 1)
