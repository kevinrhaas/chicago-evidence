from pathlib import Path
import json,hashlib,shutil
D=Path(__file__).resolve().parent; W=Path('/tmp/chicago-covered-sag'); C=Path('/workspace/shared/T2794-V17-GENUINE-RING16-MID-CANDIDATE-20261022'); O=D/'original'; P=D/'candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=['chicago/4d/renderers/web/js/parked-transport.js','chicago/4d/renderers/web/js/main.js','chicago/4d/data/transport/parked/placements.json','chicago/4d/renderers/web/transport/parked-brougham/brougham.json','chicago/4d/tools/transport/brougham/near-contract.json','chicago/4d/tools/transport/brougham/check_near.py','chicago/4d/tools/check_brougham_near.py','chicago/4d/tools/check.sh','chicago/4d/tools/transport/check_parked_placements.py']
for f in files:
 for target in [O/f,P/f]:target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/f,target)
path=P/files[0];s=path.read_text();anchor='const yawOf = (bearing) => Math.PI - bearing * Math.PI / 180;'
s=s.replace(anchor,anchor+'''

/** Candidate wheel-ring screen-size estimate, not visual/photographic acceptance.
 * Keep the reviewed near geometry within 24 m; increase that distance for a
 * larger actual drawing buffer or narrower field of view. THREE.LOD itself
 * accounts for camera zoom. The 2.5 m reserve covers the changed wheel envelope.
 */
function broughamMidDistance(camera, drawingBufferHeight) {
  if (!camera.isPerspectiveCamera || !Number.isFinite(camera.fov)
    || camera.fov <= 0 || camera.fov >= 180 || !Number.isFinite(drawingBufferHeight)
    || drawingBufferHeight <= 0) return Number.MAX_VALUE;
  const wheelChord = 0.65 * (1 - Math.cos(Math.PI / 16));
  const focalPixels = drawingBufferHeight / (2 * Math.tan(camera.fov * Math.PI / 360));
  return Math.max(24, 2.5 + focalPixels * wheelChord / 0.5);
}
''',1)
s=s.replace("detail = 'full', problems = [], hostMissing = () => false, groundHeight = null } = {})", "detail = 'full', problems = [], hostMissing = () => false, groundHeight = null,\n  getDrawingBufferHeight = () => null } = {})",1)
s=s.replace('instance.group.visible = visible;','''instance.group.visible = visible;
        if (instance.lod) {
          camera.updateWorldMatrix(true, false);
          instance.lod.updateWorldMatrix(true, false);
          instance.lod.levels[1].distance = broughamMidDistance(camera, getDrawingBufferHeight());
          instance.lod.update(camera);
          instance.active_lod = instance.lod.getCurrentLevel() === 0 ? 'near' : 'mid';
          instance.active_triangles = instance.active_lod === 'near' ? 33502 : 22238;
        }''',1)
s=s.replace('instances.filter(i => i.group.visible).map(i => i.group)', '''instances.filter(i => i.group.visible).map(i =>
        // Recursive raycasting visits invisible LOD children too. Start at ONLY
        // the committed active level, preserving the common parked card owner.
        i.lod ? i.lod.levels[i.lod.getCurrentLevel()].object : i.group)''',1)
needle='''          const model = staticBatches(root, confidence);
          model.name = row.id;'''
replacement='''          let midAsset = null;
          if (row.model === 'studebaker_brougham_1893'
            && spec.delivery_lods?.runtime_distance_selection_enabled) {
            try {
              const key = `${row.model}:mid`;
              let pendingMid = assets.get(key);
              if (!pendingMid) {
                pendingMid = new GLTFLoader().loadAsync(new URL(spec.delivery_lods.mid, new URL('../', import.meta.url)).href);
                assets.set(key, pendingMid);
              }
              midAsset = await pendingMid;
              if (disposed) break;
            } catch (error) { problems.push(`parked transport ${row.id} mid: ${error.message}; near retained`); }
          }
          const near = staticBatches(root, confidence);
          let model = near, lod = null;
          if (midAsset) {
            try {
              const mid = staticBatches(midAsset.scene.clone(true), confidence);
              lod = new THREE.LOD();
              // Selection happens with the same camera as reach/picking. Avoid
              // the renderer independently reselecting during shadow passes.
              lod.autoUpdate = false;
              lod.addLevel(near, 0);
              lod.addLevel(mid, 24, 0.05);
              near.visible = true; mid.visible = false;
              model = lod;
            } catch (error) { problems.push(`parked transport ${row.id} mid: ${error.message}; near retained`); }
          }
          model.name = row.id;'''
assert needle in s;s=s.replace(needle,replacement,1)
s=s.replace('wheel_clearance_m: wheelGap, static_support: staticSupport, draw_batches: model.children.length });','''wheel_clearance_m: wheelGap, static_support: staticSupport, draw_batches: near.children.length,
            ...(lod ? { lod, active_lod: 'near', active_triangles: 33502 } : {}) });''',1)
path.write_text(s)
path=P/files[1];s=path.read_text();needle='  const parkedTransport = await createParkedTransport({';assert needle in s;s=s.replace(needle,'  const parkedDrawingBuffer = new THREE.Vector2();\n'+needle,1);needle="    groundHeight: String(YEAR) === '1904' ? (e, n) => streetGrid.carriagewayHeight(e, n) : null,";assert needle in s;s=s.replace(needle,needle+'\n    getDrawingBufferHeight: () => renderer.getDrawingBufferSize(parkedDrawingBuffer).y,',1);path.write_text(s)
path=P/files[2];r=json.loads(path.read_bytes());r['models']['studebaker_brougham_1893']['delivery_lods']={'near':'transport/parked-brougham/brougham-near.glb','mid':'transport/parked-brougham/brougham-mid.glb','runtime_distance_selection_enabled':True};path.write_text(json.dumps(r,indent=2)+'\n')
base=P/'chicago/4d';a=base/'renderers/web/transport/parked-brougham';source=base/'tools/transport/brougham'
for origin,target in [(C/'raw/brougham.glb',a/'brougham-mid-source.glb'),(C/'delivery/brougham-mid.glb',a/'brougham-mid.glb'),(C/'ring16-mid-recipe.json',source/'ring16-mid-lods.json'),(C/'NATIVE-CANDIDATE-RESULT.json',source/'mid-native-original.json'),(C/'KHRONOS-raw.json',source/'archived-khronos/KHRONOS-MID-RAW.json'),(C/'KHRONOS-indexed.json',source/'archived-khronos/KHRONOS-MID.json')]:
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(origin,target)
path=P/files[3];s=json.loads(path.read_bytes());mid=dict(s['lods'][0]);mid.update(detail='mid',file='brougham-mid.glb',triangles=22238,source_bytes=1684032,indexed_bytes=1047068,source_sha256=sha(a/'brougham-mid-source.glb'),indexed_sha256=sha(a/'brougham-mid.glb'),expanded_triangle_PN_sha256='b22ebde8a8474409c66530c887217e33929353767d3b5c3537aee92fd9ff3eca');s['lods'].append(mid);s['lod_runtime_selection_enabled']=True;s['mid_provenance']={'recipe':'tools/transport/brougham/ring16-mid-lods.json','recipe_sha256':sha(source/'ring16-mid-lods.json'),'source_master_near_sha256':s['source_master_sha256'],'change':'Only 16 rounded wheel ring longitudinal segment counts reduced to 16; original 8 cross sections and 452 other source parts retained exactly.','license':'GPL-3.0-or-later','appearance_accepted':False,'world_budget_accepted':False};s['pending_deliverables']=[x for x in s['pending_deliverables']if x!='optional mid/far V17 delivery'];s['pending_deliverables'].insert(1,'mid fixed-view visual and normal runtime qualification');s['rendering']='Original PBR factors; no image textures. Native lossless indexing only. Both near and mid merge into seven active material batches. Brougham-only distance/screen-size selection remains subject to actual world and photographic review.';path.write_text(json.dumps(s,indent=2)+'\n')
# The near contract keeps every original geometric/source pin, while its metadata
# digest and honest two-level statement now reflect the proposed runtime intake.
path=P/files[4];c=json.loads(path.read_bytes());c['scope']='Exact V17 NEAR native source/delivery contract with additive independently checked ring16 mid; not terrain, world, photographic or occupied acceptance';c['delivery_metadata_files']['brougham.json']=sha(a/'brougham.json');path.write_text(json.dumps(c,indent=2)+'\n')
path=P/files[5];s=path.read_text();s=s.replace('V17 NEAR-ONLY original delivery gate.','V17 exact NEAR delivery gate with independent additive MID gate.');import re;s=re.sub(r"EXPECTED_CONTRACT='[0-9a-f]+'", "EXPECTED_CONTRACT='"+sha(P/files[4])+"'",s,count=1);s=s.replace("assert len(side['lods'])==1 and side['lods'][0]['detail']=='near' and side['lods'][0]['indexed_sha256']==c['near_sha256'] and side['lod_runtime_selection_enabled'] is False", "assert len(side['lods'])==2 and [r['detail'] for r in side['lods']]==['near','mid'] and side['lods'][0]['indexed_sha256']==c['near_sha256'] and side['lod_runtime_selection_enabled'] is True");path.write_text(s)
# Preserve the stronger genuine native proof as the new owned MID check; adapt
# paths only, keeping the actual decoded comparisons and all negative controls.
s=(C/'verify_candidate.py').read_text();s=s.replace("D=Path(__file__).parent;sys.path.insert(0,str(D/'source'))", "D=Path(__file__).resolve().parent; ROOT=D.parents[2]; ASSET=ROOT/'renderers/web/transport/parked-brougham';sys.path.insert(0,str(D))")
s=s.replace("D/'baseline/brougham-source.glb'","ASSET/'brougham-source.glb'").replace("D/'baseline/brougham-near.glb'","ASSET/'brougham-near.glb'").replace("D/'raw/brougham.glb'","ASSET/'brougham-mid-source.glb'").replace("D/'delivery/brougham-mid.glb'","ASSET/'brougham-mid.glb'").replace("D/'baseline/brougham.json'","ASSET/'brougham.json'").replace("D/'source/near-contract.json'","D/'near-contract.json'")
s=s.replace("    (D/'NATIVE-CANDIDATE-RESULT.json').write_text(json.dumps(result,indent=2)+'\\n');(D/'candidate-static-master.json').write_text(json.dumps(contract,indent=2)+'\\n');return result", "    return result")
assert 'write_text'not in s
# Bind actual metadata and archived current-validator reports without weakening
# either original NEAR guard or genuine native geometry proof.
needle="    assert sha((ASSET/'brougham-near.glb').read_bytes())==c['near_sha256']"
s=s.replace(needle,needle+'''
    midrow=side['lods'][1]; assert midrow['detail']=='mid' and midrow['triangles']==22238
    assert midrow['source_sha256']==sha((ASSET/'brougham-mid-source.glb').read_bytes())
    assert midrow['indexed_sha256']==sha((ASSET/'brougham-mid.glb').read_bytes())
    assert sha((D/'ring16-mid-lods.json').read_bytes())=='d7dd2cc647ad095c4fef148e5f8db88ddeb1b74fab7878dc547f8e4a30b5100d'
    for name in ['KHRONOS-MID-RAW.json','KHRONOS-MID.json']:
        report=json.loads((D/'archived-khronos'/name).read_bytes()); issues=report['issues']
        assert issues['numErrors']==issues['numWarnings']==0 and issues['numInfos']==4 and not issues['truncated']
        assert report['info']['totalTriangleCount']==22238
''',1)
(source/'check_mid.py').write_text(s)
path=P/files[6];s=path.read_text();s=s.replace('from transport.brougham.check_near import check_near','from transport.brougham.check_near import check_near\nfrom transport.brougham.check_mid import verify as check_mid');s=s.replace("    print(json.dumps(check_near(ROOT/'renderers/web/transport/parked-brougham', ROOT/'tools/transport/brougham')))","    print(json.dumps(check_near(ROOT/'renderers/web/transport/parked-brougham', ROOT/'tools/transport/brougham')))\n    print(json.dumps(check_mid()))");path.write_text(s)
path=P/files[8];s=path.read_text().replace("{'near':'transport/parked-brougham/brougham-near.glb','runtime_distance_selection_enabled':False}","{'near':'transport/parked-brougham/brougham-near.glb','mid':'transport/parked-brougham/brougham-mid.glb','runtime_distance_selection_enabled':True}");s=s.replace("        assert sum(r['model']", "        assert (ROOT/'renderers/web'/spec['delivery_lods']['mid']).is_file(), 'Missing genuine Brougham mid'\n        assert sum(r['model']",1);path.write_text(s)
print(json.dumps({'external_candidate':str(P),'source_preimages':{f:sha(O/f)for f in files}},indent=2))
