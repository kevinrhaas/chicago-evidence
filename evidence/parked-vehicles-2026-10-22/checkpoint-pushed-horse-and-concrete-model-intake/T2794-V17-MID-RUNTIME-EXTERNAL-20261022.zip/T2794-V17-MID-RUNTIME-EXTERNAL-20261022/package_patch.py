from pathlib import Path
import json,hashlib,subprocess,datetime,zipfile,shutil
D=Path(__file__).resolve().parent;W=Path('/tmp/chicago-covered-sag');O=D/'original';P=D/'candidate';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((D/'FOCUSED-TERMINAL.json').read_bytes());assert receipt['state']=='CLOSED_PASS'
git=lambda *args:subprocess.check_output(['git','-C',str(W),*args],text=True).strip()
assert git('rev-parse','HEAD')=='3289b16cdc671a6ddf4c2e25587e8f0bd670fdb3';assert git('rev-parse','HEAD^{tree}')=='01d923aab229502a54e2804a4f816c17946018e3';assert not git('status','--porcelain=v1')
proc=subprocess.run(['git','diff','--no-index','--binary','--no-renames','--','original','candidate'],cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert proc.returncode==1 and not proc.stderr
lines=[]
for line in proc.stdout.splitlines(keepends=True):
 if line.startswith((b'diff --git ',b'--- ',b'+++ ')):
  for prefix in [b'original/',b'candidate/']:
   line=line.replace(b'a/'+prefix,b'a/').replace(b'b/'+prefix,b'b/')
 lines.append(line)
patch=D/'BROUGHAM-MID-RUNTIME.patch';patch.write_bytes(b''.join(lines))
check=subprocess.run(['git','-C',str(W),'apply','--check',str(patch)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(D/'PATCH-READONLY-APPLY-CHECK.log').write_bytes(check.stdout);assert check.returncode==0
changed=[]
for p in sorted(P.rglob('*')):
 if not p.is_file()or'__pycache__'in p.parts:continue
 rel=p.relative_to(P);old=O/rel
 if old.exists()and old.read_bytes()==p.read_bytes():continue
 if old.exists():assert old.read_bytes()==(W/rel).read_bytes(),'App preimage changed '+str(rel)
 else:assert not(W/rel).exists(),'Expected absent destination '+str(rel)
 changed.append({'repository_path':str(rel),'source_payload':'candidate/'+str(rel),'preimage_sha256':sha(old)if old.exists()else'ABSENT','new_sha256':sha(p),'bytes':p.stat().st_size})
assert len(changed)==sum(1 for line in lines if line.startswith(b'diff --git '))
# All previous reconstructed scene/legacy model/card records remain exact.
b=json.loads((O/'chicago/4d/data/transport/parked/placements.json').read_bytes());a=json.loads((P/'chicago/4d/data/transport/parked/placements.json').read_bytes());assert b['scenes']==a['scenes'];assert {k:v for k,v in b['models'].items()if k!='studebaker_brougham_1893'}=={k:v for k,v in a['models'].items()if k!='studebaker_brougham_1893'}
oldspec=b['models']['studebaker_brougham_1893'];newspec=a['models']['studebaker_brougham_1893'];assert {k:v for k,v in oldspec.items()if k!='delivery_lods'}=={k:v for k,v in newspec.items()if k!='delivery_lods'}
original_near=W/'chicago/4d/renderers/web/transport/parked-brougham/brougham-near.glb';assert sha(original_near)=='ec2bfc0da49b570429dbcd8db39250aa6f1bbf55587570f0dafad9a42afc4ee5'
result={'state':'CLOSED_SOURCE_PATCH_AND_FOCUSED_PASS_NOT_INSTALLED','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'app_HEAD':git('rev-parse','HEAD'),'app_tree':git('rev-parse','HEAD^{tree}'),'app_worktree_clean':True,'patch':patch.name,'patch_sha256':sha(patch),'patch_bytes':patch.stat().st_size,'read_only_apply_check_exit':check.returncode,'patch_applied':False,'files':changed,'original_near_sha256':sha(original_near),'all_scene_rows_and_all_legacy_model_specs_exact':True,'protected_original_runtime_segments':'VERBATIM-PROTECTED-RUNTIME-SEGMENTS.json','fullgate_browser_publish_or_Git_mutations':0,'visual_acceptance':False,'current_scene_budget_acceptance':False,'photographic_completion':False}
(D/'SOURCE-PINS-AND-RESTORE-MANIFEST.json').write_text(json.dumps(result,indent=2)+'\n')
# Small actual before/after review without printing binary patch lines.
stat=subprocess.run(['git','diff','--no-index','--stat','--','original','candidate'],cwd=D,stdout=subprocess.PIPE);(D/'PATCH-STAT.txt').write_bytes(stat.stdout)
print(json.dumps({k:result[k]for k in ['state','patch','patch_sha256','patch_bytes','app_HEAD','app_tree','read_only_apply_check_exit']},indent=2));print('changed_files',len(changed))
