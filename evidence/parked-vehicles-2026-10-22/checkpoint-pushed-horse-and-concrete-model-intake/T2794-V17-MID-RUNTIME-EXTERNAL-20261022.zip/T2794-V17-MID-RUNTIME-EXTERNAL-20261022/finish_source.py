from pathlib import Path
import json,hashlib,shutil,re
D=Path(__file__).resolve().parent;P=D/'candidate/chicago/4d';O=D/'original/chicago/4d';W=Path('/tmp/chicago-covered-sag/chicago/4d');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
src=P/'tools/transport/brougham';asset=P/'renderers/web/transport/parked-brougham'
c={'scope':'Exact generated ring16 mid from unchanged V17 source. Native geometry/provenance only; not appearance, runtime world or photographic acceptance.','raw_file':'brougham-mid-source.glb','raw_sha256':sha(asset/'brougham-mid-source.glb'),'raw_bytes':(asset/'brougham-mid-source.glb').stat().st_size,'indexed_file':'brougham-mid.glb','indexed_sha256':sha(asset/'brougham-mid.glb'),'indexed_bytes':(asset/'brougham-mid.glb').stat().st_size,'triangles':22238,'expanded_triangle_PN_sha256':'b22ebde8a8474409c66530c887217e33929353767d3b5c3537aee92fd9ff3eca','recipe':'ring16-mid-lods.json','recipe_sha256':sha(src/'ring16-mid-lods.json'),'unchanged_near_sha256':'ec2bfc0da49b570429dbcd8db39250aa6f1bbf55587570f0dafad9a42afc4ee5','license':'GPL-3.0-or-later','changed_ring_parts':16,'protected_other_parts':452,'materials':7,'nodes':42,'anchors':13,'archived_current_validator_reports':{n:sha(src/'archived-khronos'/n)for n in ['KHRONOS-MID-RAW.json','KHRONOS-MID.json']}}
(src/'mid-contract.json').write_text(json.dumps(c,indent=2)+'\n')
p=src/'check_mid.py';s=p.read_text();needle="    start=time.monotonic();old,ob=";assert needle in s;s=s.replace(needle,"    mid_contract=D/'mid-contract.json';assert sha(mid_contract.read_bytes())=='"+sha(src/'mid-contract.json')+"'\n    mc=json.loads(mid_contract.read_bytes())\n    for filename,digest,size in [(mc['raw_file'],mc['raw_sha256'],mc['raw_bytes']),(mc['indexed_file'],mc['indexed_sha256'],mc['indexed_bytes'])]:\n        p=ASSET/filename;assert sha(p.read_bytes())==digest and p.stat().st_size==size\n    for name,digest in mc['archived_current_validator_reports'].items():assert sha((D/'archived-khronos'/name).read_bytes())==digest\n    start=time.monotonic();old,ob=",1);p.write_text(s)
# Keep meaningful actual runtime checks within the already registered Brougham
# card entry. The helper lives under transport/brougham, not a new flat check.
p=P/'tools/test_brougham_lod.mjs';s=p.read_text().replace("../renderers/","../../../renderers/").replace("../data/","../../../data/");(src/'test_lod.mjs').write_text(s);p.unlink()
p=W/'tools/test_brougham_card.mjs'
for root in [O,P]:
 target=root/'tools/test_brougham_card.mjs';target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
p=P/'tools/test_brougham_card.mjs';s=p.read_text();s+="\n// Same registered Brougham entry also exercises actual near/mid runtime ownership.\nawait import('./transport/brougham/test_lod.mjs');\n";p.write_text(s)
p=P/'tools/check.sh';s=p.read_text().replace('Catalogue Brougham preserves exact V17 near source, contacts and inert interfaces (T-2794)','Catalogue Brougham preserves exact V17 near and genuine ring16 mid, contacts and inert interfaces (T-2794)').replace('The Brougham card distinguishes its catalogue design from a reconstructed parked individual, preserving every prior parked card (T-2794)','Brougham card and actual near/mid selection preserve catalogue scope, all prior cards, active picking and disposal (T-2794)');p.write_text(s)
# More legible source metadata than the retained original candidate receipt.
p=src/'mid-native-original.json';p.unlink()
print('Finished narrow proposed source metadata, exact mid contract and existing registered check integration')
