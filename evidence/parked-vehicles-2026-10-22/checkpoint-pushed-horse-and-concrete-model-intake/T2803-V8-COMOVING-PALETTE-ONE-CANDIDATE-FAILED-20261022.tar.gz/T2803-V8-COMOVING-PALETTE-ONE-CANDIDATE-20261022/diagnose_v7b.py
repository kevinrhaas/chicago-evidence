"""One exact V7B field diagnostic; unpruned field is diagnostic, never a four-weight candidate."""
import sys,pathlib,json,hashlib,time
import numpy as np
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P/'exact-v7b-preimages'))
from actual_model import Model
from walk_source import pose,PARAMETERS,THRESHOLDS
from screened_harmonic_v7_HELD import build
start=time.monotonic();rig=pathlib.Path('/workspace/shared/T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb');m=Model(rig);assert hashlib.sha256(m.raw).hexdigest()=='03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36'
controls=json.loads((P/'exact-v7b-preimages/RERIG-CONTROLS-PROPOSAL-V2.json').read_text());side=json.loads(pathlib.Path('/workspace/shared/horse-standing-intake-proposal-V2-20261022/proposed/data/transport/parked/horse-sevket-sidecar.json').read_text());parts=[];rest=[]
for ni in [26,27,28]:
 pr=m.g['meshes'][m.g['nodes'][ni]['mesh']]['primitives'][0];a=pr['attributes'];parts.append((m.accessor(a['POSITION']).astype(float),m.accessor(a['NORMAL']).astype(float),m.accessor(a['JOINTS_0']).astype(int),m.accessor(a['WEIGHTS_0']).astype(float),m.accessor(pr['indices']).astype(int).reshape(-1,3)));rest.append(m.mesh(ni)[0])
patch={label:np.unique(parts[1][4][row['source_triangle_ids']].ravel())for label,row in side['contacts'].items()};captured={}
def profile(frame,event,arg):
 if event=='return'and frame.f_code is build.__code__:
  for name in ['dense','vc','unknown','fixed','genuine_ownership']:captured[name]=frame.f_locals[name].copy()if isinstance(frame.f_locals[name],np.ndarray)else[x.copy()for x in frame.f_locals[name]]
sys.setprofile(profile);arrays,receipt=build(rest,parts,controls,patch);sys.setprofile(None)
dense=[captured['dense'][ids]for ids in captured['vc']];ib=m.accessor(m.g['skins'][0]['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1);piv=np.array([m.world(i)for i in range(26)])[:,:3,3];hoof={k:float(rest[1][v,1].min())for k,v in patch.items()};old=json.loads(pathlib.Path('/workspace/shared/T2803-V7B-IDENTITY-CORRECTED-STUDY-20261022/ACTUAL-WALK-WEIGHT-V7B-CPU-READBACK.json').read_text());times=np.linspace(0,PARAMETERS['period_s'],65);results={};comotion=0.;root_difference=0.;witness_rows=[]
def skinned(transforms,mi,unpruned):
 pos=parts[mi][0]
 if unpruned:return np.einsum('nk,kij,nj->ni',dense[mi],transforms,np.c_[pos,np.ones(len(pos))],optimize=True)[:,:3]
 j,w=arrays[mi];blend=np.einsum('nw,nwij->nij',w,transforms[j]);return np.einsum('nij,nj->ni',blend,np.c_[pos,np.ones(len(pos))])[:,:3]
ix=parts[1][4];rt=rest[1][ix];re=np.linalg.norm(rt[:,[1,2,0]]-rt[:,[0,1,2]],axis=2);ra=np.linalg.norm(np.cross(rt[:,1]-rt[:,0],rt[:,2]-rt[:,0]),axis=1)
for name,unpruned in [('four_weight_V7B',False),('unpruned_diagnostic_ONLY',True)]:
 edge_min=area_min=1.;edge_max=area_max=1.;worst={}
 for t in times:
  matrices,_=pose(float(t),piv,controls['limbs'],hoof);trans=matrices@ib;comotion=max(comotion,float(np.abs(trans[2:6]-trans[1]).max()));root_difference=max(root_difference,float(np.abs(trans[0]-trans[1]).max()));points=skinned(trans,1,unpruned);tri=points[ix];er=np.linalg.norm(tri[:,[1,2,0]]-tri[:,[0,1,2]],axis=2)/re;ar=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)/ra
  edge_min=min(edge_min,float(er.min()));edge_max=max(edge_max,float(er.max()));area_min=min(area_min,float(ar.min()));area_max=max(area_max,float(ar.max()))
  for key,values,maximize in [('edge_max',er,True),('edge_min',er,False),('area_max',ar,True),('area_min',ar,False)]:
   f=int(np.argmax(values)if maximize else np.argmin(values));value=float(values.flat[f]);prior=worst.get(key)
   if prior is None or (value>prior['value']if maximize else value<prior['value']):worst[key]={'triangle':f//3 if values.ndim==2 else f,'time_s':float(t),'value':value}
  for key,w in old['witnesses'].items():
   if key=='normal_min'or abs(t-w['time_s'])>1e-9:continue
   ti=w['triangle'];witness_rows.append({'field':name,'old_witness':key,'triangle':ti,'time_s':float(t),'edge_ratios':er[ti].tolist(),'area_ratio':float(ar[ti])})
 results[name]={'edge_ratio_min':edge_min,'edge_ratio_max':edge_max,'area_ratio_min':area_min,'area_ratio_max':area_max,'witnesses':worst}
assert abs(results['four_weight_V7B']['edge_ratio_max']-old['surfaces'][1]['edge_ratio_max'])<1e-9
assert abs(results['four_weight_V7B']['area_ratio_min']-old['surfaces'][1]['area_ratio_min'])<1e-9
assert comotion<1e-7 and root_difference>.01
np.savez_compressed(P/'EXACT-V7B-FIELD-DIAGNOSTIC.npz',dense_class=captured['dense'],unknown=captured['unknown'],fixed=captured['fixed'],genuine_owner=captured['genuine_ownership'],**{'vertex_classes_'+str(i):v for i,v in enumerate(captured['vc'])})
report={'status':'V7B diagnostic only; no new candidate yet','source_rig_sha256':hashlib.sha256(m.raw).hexdigest(),'builder_sha256':hashlib.sha256((P/'exact-v7b-preimages/screened_harmonic_v7_HELD.py').read_bytes()).hexdigest(),'walk_sha256':hashlib.sha256((P/'exact-v7b-preimages/walk_source.py').read_bytes()).hexdigest(),'old_four_weight_reproduced':True,'body_surfaces':results,'old_witness_comparison':witness_rows,'maximum_body_vs_joints_2_to_5_affine_difference':comotion,'root0_vs_body_affine_difference':root_difference,'whole_field_length_scale_m':receipt['physical_screening_length_m'],'parameters':PARAMETERS,'thresholds':THRESHOLDS,'elapsed_seconds':time.monotonic()-start,'limits':'Unpruned field is not a candidate, valid four-weight skin, export or accepted gait; all source deformation caps unchanged.'};(P/'V7B-DIAGNOSIS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['old_four_weight_reproduced','body_surfaces','maximum_body_vs_joints_2_to_5_affine_difference','root0_vs_body_affine_difference','elapsed_seconds']},indent=2))
