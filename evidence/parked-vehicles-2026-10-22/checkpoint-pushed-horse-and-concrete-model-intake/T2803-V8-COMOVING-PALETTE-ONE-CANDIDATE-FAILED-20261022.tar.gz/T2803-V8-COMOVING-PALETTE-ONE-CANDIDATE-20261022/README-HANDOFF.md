# T2803: one co-moving palette candidate, closed deformation failure

The single V8 CPU candidate completed with exit 2 in 2.006 seconds. It improved the saved V7B stretch and area extrema, but it did not meet the existing limits. This packet is an experimental source checkpoint, not an accepted walking horse, exported animation, rendered result or live team.

| Body-mesh screen | Original V7B | Unpruned diagnostic only | One V8 candidate | Unchanged limits |
| --- | --- | --- | --- | --- |
| Edge ratio | 0.778392–1.348984 | 0.782896–1.272096 | 0.784081–1.298114 | 0.9–1.1 |
| Triangle area ratio | 0.520688–1.485031 | 0.523194–1.457415 | 0.550116–1.424873 | 0.8–1.2 |

The original failure is concentrated in the upper forelimb and chest, not the preserved tail. V7B's maximum stretched edge is triangle 5313 at 1.175 seconds: vertices 3240 and 3228 exchange neck versus hoof influence during four-weight pruning. The exact unpruned field still fails both area limits at the same original triangles 5378 and 5342. Thus pruning contributes to the failure, but does not explain all of it.

V8 folds joints 2–5 into body joint 1 only for the existing unknown classes before the unchanged four-weight pruning. This is justified only for this exact frozen walk: actual affine matrices co-move within 7.153e-8 over all 65 poses. Root joint 0 differs by 30 mm and is excluded. Hard/source-owned classes, hoof handles and all original isolated-tail joint slots and weights remain unchanged. The exact original mesh, neutral pose, inverse binds, joint hierarchy, source gait and numerical acceptance limits are unchanged. This reduction cannot be inherited by a future independently moving head or tail clip.

The new maximum stretch is triangle 6577 at 1.05 seconds, under the chest between left/right shoulder and elbow influences. The minimum edge is triangle 4725 at 1.075 seconds. The persistent maximum/minimum area failures remain the original right upper-forelimb/chest triangles 5378 at 0.25 seconds and 5342 at 0.275 seconds, blending body 1 with right shoulder 11, elbow 12 and hoof 15. Their exact rest edge lengths, areas and altitudes are recorded separately. Their remaining area distortion is measured; attributing a sufficient anatomical repair to a particular anchor or joint is not established by this one experiment.

All 65 poses were evaluated, with 11,556 vertices and 14,986 triangles per pose. Mechanics, annotated stance patches, loop closure, segment lengths, seams, finite coordinates, neutral parity and the existing negative controls pass. The deformation screen and walk acceptance remain false. The preserved tail is exact; no deformation, ground, hoof, seam or loop threshold was changed.

## Recoverable files

`CANDIDATE-ONLY.patch` is additive against the exact copied V7B producer. It was actually applied in the external `patch-application-proof` directory and its postimage matches the frozen candidate byte for byte. `candidate/` contains the exact producer, actual proof caller, controls, tail fixture, gait source, 65 authored pose matrices and complete actual numerical readbacks. `exact-v7b-preimages/`, `V7B-DIAGNOSIS.json` and `EXACT-V7B-FIELD-DIAGNOSTIC.npz` retain the old source and diagnostic evidence. The dense diagnostic field is not a valid four-influence skin and is never proposed for export.

The original immutable rig is `/workspace/shared/T2803-FOUR-LIMB-EXPORT-ACTUAL-20261022/horse-sevket-reconstructed-four-limb-bind-study-v1.glb`, SHA256 `03a1f747189ee2457f0fc3dc9720b1d3d288e36c32b7171b5a9976afb7e63c36`. The saved original V7B archive remains untouched. The candidate caller uses the existing Python 3.11 dependency environment and original absolute input locations; this is a reproducible workspace checkpoint, not a self-contained model distribution.

No second candidate was attempted. No app, ticket, Git reference, model, GLB, browser, Blender, publish or full gate was changed or executed. No photographic appearance, anatomical correctness, complete hoof contact, load transfer, self-intersection clearance, slope/turning, hitch, riding or team claim follows from these CPU measurements.
