"""Read-only contact annotation/support fit; no model or rig export/modification."""
import hashlib,json,math,sys
from collections import Counter
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
SOURCE=Path('/workspace/shared/horse-public-base-search-20261022')
APP=Path('/workspace/chicago/chicago/4d')
sys.path.insert(0,str(SOURCE));import read_native_pose as native
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
C=json.loads((HERE/'SOURCE-CONTACT-DERIVATION.json').read_text())
Y=json.loads((HERE/'YARD-STAND-DERIVATION.json').read_text())
body=next(v for m,v in native.points({})if m==1)
allv=np.concatenate([v for m,v in native.points({})])
tri=native.acc(7).reshape(-1,3).astype(int);vt=body[tri]
cr=np.cross(vt[:,1]-vt[:,0],vt[:,2]-vt[:,0]);a2=np.linalg.norm(cr,axis=1)
normal=cr/np.maximum(a2[:,None],1e-30);center=vt.mean(1)
origin=np.array(C['origin_native']);scale=C['uniform_metres_per_native_unit']
canonical=(allv-origin)*scale
meta_path=APP/'data/terrain/epochs/e1834_harbor_cut/heightfield.json'
meta=json.loads(meta_path.read_text());bin_path=meta_path.with_name(meta['bin'])
raw=np.memmap(bin_path,dtype='<i2',mode='r',shape=(meta['rows'],meta['cols']))
def ground(e,n):
 gx=(e-meta['origin_e'])/meta['cell_m'];gy=(n-meta['origin_n'])/meta['cell_m']
 assert 0<=gx<=meta['cols']-1 and 0<=gy<=meta['rows']-1
 x=min(math.floor(gx),meta['cols']-2);y=min(math.floor(gy),meta['rows']-2);fx=gx-x;fy=gy-y
 h=lambda yy,xx:float(np.float32(int(raw[yy,xx])*meta['scale']+meta.get('offset',0)))
 return(h(y,x)*(1-fx)+h(y,x+1)*fx)*(1-fy)+(h(y+1,x)*(1-fx)+h(y+1,x+1)*fx)*fy+.022
def components(faces):
 edges={};neigh={int(f):set()for f in faces}
 for fi in faces:
  for j in range(3):edges.setdefault(tuple(sorted((int(tri[fi,j]),int(tri[fi,(j+1)%3])))),[]).append(int(fi))
 for fs in edges.values():
  for f in fs:neigh[f].update(set(fs)-{f})
 remaining=set(neigh);sizes=[]
 while remaining:
  stack=[remaining.pop()];size=0
  while stack:
   f=stack.pop();size+=1
   for g in neigh[f]&remaining:remaining.remove(g);stack.append(g)
  sizes.append(size)
 return {'edge_connected_face_component_sizes':sorted(sizes,reverse=True),'boundary_edges':sum(len(v)==1 for v in edges.values()),'nonmanifold_patch_edges':sum(len(v)>2 for v in edges.values())}
anchors=[];audit={};slab_samples={}
for label,p in C['patches'].items():
 end,side=label.split('_');xs=1 if side=='l'else-1;zs=1 if end=='fore'else-1
 low=(body[:,1]<1.25)&(body[:,0]*xs>.1)&(body[:,2]*zs>0)
 ids=np.flatnonzero(low);vid=int(ids[np.argmin(body[ids,1])]);minimum=float(body[vid,1]);point=(body[vid]-origin)*scale
 anchors.append(point)
 faces=np.asarray(p['triangle_ids']);broad=np.flatnonzero((center[:,0]*xs>.1)&(center[:,2]*zs>0)&(vt[:,:,1].max(1)<minimum+.085)&(a2>1e-10))
 # Equal PHYSICAL10mm all-winding slab, without requiring whole coarse
 # triangles to fit inside it. Clip triangle polygons to its top plane for
 # annotation/sampling only; never emit changed geometry. Keep original IDs.
 top=minimum+.010/scale
 whole=np.flatnonzero((center[:,0]*xs>.1)&(center[:,2]*zs>0)&(vt[:,:,1].max(1)<=top)&(a2>1e-10))
 slab=np.flatnonzero((center[:,0]*xs>.1)&(center[:,2]*zs>0)&(vt[:,:,1].min(1)<=top)&(a2>1e-10))
 sv=np.unique(tri[slab]);clipped=[];clipped_area=0.
 for fi in slab:
  poly=[];verts=vt[fi]
  for a,b in zip(verts,np.roll(verts,-1,axis=0)):
   ia=a[1]<=top;ib=b[1]<=top
   if ia:poly.append(a)
   if ia!=ib:poly.append(a+(b-a)*((top-a[1])/(b[1]-a[1])))
  poly=np.asarray(poly)
  if len(poly)<3:continue
  area=sum(np.linalg.norm(np.cross(poly[j]-poly[0],poly[j+1]-poly[0]))*.5 for j in range(1,len(poly)-1))
  clipped_area+=area;clipped.extend(poly);clipped.extend((poly+np.roll(poly,-1,axis=0))/2);clipped.append(poly.mean(0))
 samples=np.unique(np.round(np.asarray(clipped),10),axis=0)
 slab_samples[label]=(samples-origin)*scale
 audit[label]={'actual_minimum_body_vertex_id':vid,'minimum_vertex_native':body[vid].tolist(),'minimum_vertex_m':point.tolist(),'selected_downward_patch':{'faces':len(faces),'vertices':len(p['vertex_ids']),'area_m2':float(a2[faces].sum()*.5*scale**2),'normalY_min_max':[float(normal[faces,1].min()),float(normal[faces,1].max())],**components(faces)},'all_winding_lower_30_975mm_band':{'faces':len(broad),'downward_faces':int(sum(normal[broad,1]<-.45)),'upward_faces':int(sum(normal[broad,1]>.45)),'side_faces':int(sum(abs(normal[broad,1])<=.45)),'area_m2':float(a2[broad].sum()*.5*scale**2),'downward_area_m2':float(a2[broad[normal[broad,1]<-.45]].sum()*.5*scale**2),'upward_area_m2':float(a2[broad[normal[broad,1]>.45]].sum()*.5*scale**2)},'equal_10mm_geometric_slab':{'triangle_ids':slab.tolist(),'source_triangle_vertices':len(sv),'intersecting_faces':len(slab),'whole_faces':len(whole),'clipped_sample_count':len(samples),'clipped_area_m2':float(clipped_area*scale**2),'normalY_min_max':[float(normal[slab,1].min()),float(normal[slab,1].max())],**components(slab)}}
e,n=Y['chosen']['at_local_enu_m'];bearing=Y['chosen']['bearing_deg'];yaw=math.pi-math.radians(bearing)
def en(v):return np.c_[e+math.cos(yaw)*v[:,0]+math.sin(yaw)*v[:,2],n+math.sin(yaw)*v[:,0]-math.cos(yaw)*v[:,2]]
def matrix(pitch,roll):
 cx,sx=math.cos(pitch),math.sin(pitch);cz,sz=math.cos(roll),math.sin(roll)
 return np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])@np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])
anchors=np.asarray(anchors);en0=en(anchors);g=np.array([ground(*v)for v in en0])
# Exactly ONE linear least-squares fit, followed by exact rigid transform and
# exact ground resampling. Not an iterative per-limb or mesh solve.
roll,pitch,base_fit=np.linalg.lstsq(np.c_[anchors[:,0],-anchors[:,2],np.ones(4)],g-anchors[:,1],rcond=None)[0]
R=matrix(pitch,roll);angle=math.acos(np.clip((np.trace(R)-1)/2,-1,1));assert angle<=math.radians(2),'Whole-root tilt exceeds declared bound; preserve failure'
samples={k:np.asarray(v['samples_m'])@R.T for k,v in C['patches'].items()}
grounded={k:np.array([ground(*v)for v in en(s)])for k,s in samples.items()}
base=max(float(np.max(grounded[k]-s[:,1]))for k,s in samples.items())
def metrics(points):
 out={}
 for k,v in points.items():
  world=en(v);gs=np.array([ground(*q)for q in world]);gaps=base+v[:,1]-gs
  out[k]={'sample_count':len(v),'minimum_gap_m':float(gaps.min()),'maximum_gap_m':float(gaps.max()),'sampled_penetrations_below_minus_1um':int(sum(gaps<-.000001)),'minimum_sample_index':int(np.argmin(gaps)),'all_sample_gaps_m':gaps.tolist(),'all_sample_ground_y_m':gs.tolist()}
 return out
actual_metrics=metrics(samples);slab_metrics=metrics({k:v@R.T for k,v in slab_samples.items()})
rotated_anchor=anchors@R.T;anchor_ground=np.array([ground(*v)for v in en(rotated_anchor)]);anchor_gaps=base+rotated_anchor[:,1]-anchor_ground
rotated_all=canonical@R.T;bounds=[en(rotated_all).min(0).tolist(),en(rotated_all).max(0).tolist()]
def distance(a,b):return math.hypot(max(a[0][0]-b[1][0],b[0][0]-a[1][0],0),max(a[0][1]-b[1][1],b[0][1]-a[1][1],0))
qx=math.cos(roll/2)*math.sin(pitch/2);qy=math.sin(roll/2)*math.sin(pitch/2);qz=math.sin(roll/2)*math.cos(pitch/2);qw=math.cos(roll/2)*math.cos(pitch/2)
proxy=(np.asarray(C['withers_proxy']['actual_native'])-origin)*scale;proxy_rot=R@proxy
result={'schema':'standing_horse_rigid_support_review_v1','status':'PROPOSED exact source unchanged; not installed, source contacts not certified sockets; root and independent review required','source_sha256':C['source_sha256'],'input_contact_json_sha256':sha(HERE/'SOURCE-CONTACT-DERIVATION.json'),'upright_receipt_json_sha256':sha(HERE/'YARD-STAND-DERIVATION.json'),'reader_sha256':sha(Path(__file__)),'upright':Y['chosen'],'method':'One linear least-squares fit from FOUR actual minimum hoof vertices to the SAME committed bilinear heightfield plus yard22mm base. Exact Rz(roll)*Rx(pitch) then all488 original patch samples resampled. Whole-root baseY chosen to avoid any sampled penetration. No iterative correction, per-limb change, rig change, source edit or per-part scaling. Equal10mm slab separately evaluated with same transform/baseY.','contact_topology_audit':audit,'fit':{'at_local_enu_m':[e,n],'bearing_deg':bearing,'root_y_m':base,'linear_fit_base_y_m':float(base_fit),'local_pitch_x_rad':float(pitch),'local_roll_z_rad':float(roll),'total_tilt_deg':math.degrees(angle),'maximum_allowed_tilt_deg':2,'local_support_quaternion_xyzw':[qx,qy,qz,qw],'local_up_after_support_rotation':R[:,1].tolist(),'matrix_rows':R.tolist(),'actual_minimum_anchor_labels':list(C['patches']),'actual_anchor_gaps_m':anchor_gaps.tolist(),'maximum_hoof_minimum_gap_m':max(v['minimum_gap_m']for v in actual_metrics.values()),'original_patch_samples':actual_metrics,'equal_10mm_slab_samples':slab_metrics,'rotated_withers_proxy_y_above_root_m':float(proxy_rot[1]),'all_source_bounds_relative_root_m':[rotated_all.min(0).tolist(),rotated_all.max(0).tolist()],'all_source_bounds_enu_m':bounds,'clearance_m':{'building_conservative_AABB':min(distance(bounds,x['bounds'])for x in Y['building_boxes']),'vehicle_conservative_AABB':min(distance(bounds,x['bounds'])for x in Y['vehicle_boxes']),'east_yard_fence':-124.5-bounds[1][0],'stable_front':bounds[0][1]+298,'reserved_3m_stable_door_approach':distance(bounds,[[-130.575,-298],[-129.225,-295]])}},'limits':['A single rigid source pose support adjustment is reconstructed and requires actual normalized desktop/mobile review. It is not an anatomical pose certification.','Ground is a sampled bilinear heightfield plus rendered yard base lift; continuous triangle collision and soft-hoof deformation are not certified.','Vertex and triangle IDs annotate the current exact body surface and source pose, not rig names or certified sockets.','Original downward patch selection and independent equal10mm all-winding slab deliberately use different fixed definitions, not a post-hoc acceptance threshold. Neither triangle count alone proves anatomical completeness.']}
(HERE/'CONTACT-ANNOTATION-CANDIDATE.json').write_text(json.dumps({k:{'minimum_vertex_id':audit[k]['actual_minimum_body_vertex_id'],'minimum_vertex_native':audit[k]['minimum_vertex_native'],'samples_m':v['samples_m'],'equal_10mm_slab_samples_m':slab_samples[k].tolist(),'source_triangle_ids':v['triangle_ids'],'status':'actual source-surface annotation; no certified bone/socket/anatomical compatibility'}for k,v in C['patches'].items()},indent=2)+'\n')
(HERE/'RIGID-SUPPORT-AND-TOPOLOGY-REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'fit':{k:v for k,v in result['fit'].items()if k not in ['original_patch_samples','equal_10mm_slab_samples']},'patch_summary':{k:{'selected':v['selected_downward_patch'],'band':v['all_winding_lower_30_975mm_band'],'slab':{a:b for a,b in v['equal_10mm_geometric_slab'].items()if a!='triangle_ids'}}for k,v in audit.items()},'original_samples':{k:{a:b for a,b in v.items()if not a.startswith('all_')}for k,v in actual_metrics.items()},'slab_samples':{k:{a:b for a,b in v.items()if not a.startswith('all_')}for k,v in slab_metrics.items()}},indent=2))
