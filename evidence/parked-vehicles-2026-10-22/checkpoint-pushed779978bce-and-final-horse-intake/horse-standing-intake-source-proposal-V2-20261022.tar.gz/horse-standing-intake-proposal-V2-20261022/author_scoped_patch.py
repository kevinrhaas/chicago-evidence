"""Prepare exact-preimage scoped diff outside app. Never apply to app."""
import difflib,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');patch=[];pre=[]
def update(rel,edits):
 path=A/rel;before=path.read_text();after=before
 for old,new,count in edits:
  assert after.count(old)==count,(rel,old,after.count(old),count)
  after=after.replace(old,new)
 patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel,n=4));pre.append({'path':rel,'preimage_sha256':hashlib.sha256(before.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(after.encode()).hexdigest()})
update('renderers/web/js/main.js',[
("import { createParkedTransport } from './parked-transport.js';","import { createParkedTransport } from './parked-transport.js';\nimport { createStandingHorses } from './standing-horses.js';",1),
('    prebuilt: yardsPrebuilt, recordHashes: enclosureHashes,', '    prebuilt: yardsPrebuilt, recordHashes: enclosureHashes,\n    supportRegions: draws(\"standing_horses\") ? (loaded.scene.static_support_regions ?? []) : [],',1),
('  api.parkedTransport = parkedTransport;','''  api.parkedTransport = parkedTransport;
  const standingHorses = await createStandingHorses({
    dataBase: layerBase('standing_horses'), sceneId: YEAR, confidence, detail: detailLevel,
    problems: layerProblems('standing_horses'), hostMissing,
    groundHeight: (e, n, recordId, regionId) => yards.drawnBaseHeightAt(e, n, recordId, regionId),
  });
  scene3d.add(standingHorses.group); settleOnGpu(standingHorses.group);
  api.standingHorses = standingHorses;
  standingHorses.update(camera);''',1),
('void parkedTransport.setTier(level);','void parkedTransport.setTier(level);\n      void standingHorses.setTier(level);',2),
('    if (vehicle?.record && (!hit || vehicle.distance < hit.distance)) hit = vehicle;','''    if (vehicle?.record && (!hit || vehicle.distance < hit.distance)) hit = vehicle;
    const horse = standingHorses.pickAt(ndc, camera);
    if (horse?.record && (!hit || horse.distance < hit.distance)) hit = horse;''',1),
('    parkedTransport.update(camera);','    parkedTransport.update(camera);\n    standingHorses.update(camera);',1)])
update('data/scenes/1835.json', [('    \"parked_transport\",','    \"parked_transport\",\n    \"standing_horses\",',1), ('  \"layers\": [', '  \"static_support_regions\": '+json.dumps([json.loads((P/'STATIC-SUPPORT-REGION-PROPOSAL.json').read_text())],indent=2).replace('\n','\n  ')+',\n  \"layers\": [',1)])
update('renderers/web/js/yards.js',[
("import * as THREE from 'three';","import * as THREE from 'three';\nimport { retainYardStaticSupport } from './yard-static-support.js';",1),
('  records = [], terrain, confidence = null, problems = [], prebuilt = null, recordHashes = null,','  records = [], terrain, confidence = null, problems = [], prebuilt = null, recordHashes = null, supportRegions = [],',1),
('    treatmentAt: () => null,','''    treatmentAt: () => null,
    drawnBaseHeightAt: () => null,
    staticSupport: { regions: 0, triangles: 0, bytes: 0, disposed: false },''',1),
('  out.dispose = () => { for (const d of disposables) d.dispose?.(); };','''  // Retain ONLY declared small support regions now, before main.js calls
  // settleOnGpu and normal coarse upload-release empties source CPU arrays.
  const support = retainYardStaticSupport(group, supportRegions, problems);
  out.staticSupport = support.census;
  out.drawnBaseHeightAt = (e, n, recordId, regionId) => {
    const interior = out.interiors.find(item => item.record === recordId
      && pointInPolygon(item.pts, e, n));
    if (!interior || interior.treatment !== 'worn_earth') return null;
    return support.heightAt(e, n, recordId, regionId);
  };
  out.dispose = () => { support.dispose(); for (const d of disposables) d.dispose?.(); };''',1)])
(P/'SCOPED-INTEGRATION.patch').write_text(''.join(patch));(P/'APP-PREIMAGES.json').write_text(json.dumps(pre,indent=2)+'\n')
print(json.dumps({'scoped_files':len(pre),'patch_bytes':(P/'SCOPED-INTEGRATION.patch').stat().st_size,'app_modified':False}))
