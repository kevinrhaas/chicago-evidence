"""Plane explanations only; never refit/repose model or change existing fit."""
import json,math,hashlib
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
r=json.loads((P/'RIGID-SUPPORT-AND-TOPOLOGY-REVIEW.json').read_text());f=r['fit'];labels=f['actual_minimum_anchor_labels']
a=np.array([r['contact_topology_audit'][k]['minimum_vertex_m']for k in labels]);coefs=np.linalg.lstsq(np.c_[a[:,0],a[:,2],np.ones(4)],a[:,1],rcond=None)[0];normal=np.array([-coefs[0],1,-coefs[1]]);normal/=np.linalg.norm(normal)
R=np.array(f['matrix_rows']);yaw=math.pi-math.radians(f['bearing_deg']);Y=np.array([[math.cos(yaw),0,math.sin(yaw)],[0,1,0],[-math.sin(yaw),0,math.cos(yaw)]])
out={'status':'Reconstructed support geometry explanation; not a certified anatomical support plane or original source bone/socket','labels':labels,'source_minimum_anchor_plane_y_equals_a_x_plus_b_z_plus_c':coefs.tolist(),'source_minimum_anchor_plane_normal_canonical_xyz':normal.tolist(),'source_anchor_plane_residuals_m':(a[:,1]-np.c_[a[:,0],a[:,2],np.ones(4)]@coefs).tolist(),'normal_after_proposed_support_rotation_canonical_xyz':(R@normal).tolist(),'normal_after_heading_world_xyz':(Y@R@normal).tolist(),'root_local_up_after_support_rotation_is_different_quantity':f['local_up_after_support_rotation'],'root_support_fit_is_not_recomputed':True,'rigid_support_receipt_sha256':hashlib.sha256((P/'RIGID-SUPPORT-AND-TOPOLOGY-REVIEW.json').read_bytes()).hexdigest()}
(P/'SUPPORT-PLANE-NORMAL-EXPLANATION.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
