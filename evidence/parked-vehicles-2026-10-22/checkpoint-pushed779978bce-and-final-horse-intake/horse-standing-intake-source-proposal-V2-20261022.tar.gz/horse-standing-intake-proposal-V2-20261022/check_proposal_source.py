"""Finite source-only checks, outside-app scratch copies. No imports/render/gate."""
import hashlib,json,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent;A=Path('/workspace/chicago/chicago/4d');T=P/'syntax-scratch';T.mkdir(exist_ok=True)
rows=json.loads((P/'APP-PREIMAGES.json').read_text())
for r in rows:
 f=A/r['path'];assert hashlib.sha256(f.read_bytes()).hexdigest()==r['preimage_sha256'];d=T/r['path'];d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(f.read_bytes())
commands=[]
with (P/'SCOPED-INTEGRATION.patch').open('rb')as f:
 r=subprocess.run(['patch','--batch','--fuzz=0','-p1','-d',str(T)],stdin=f,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=False)
 commands.append({'command':['patch','--batch','--fuzz=0','-p1','-d','outside-app syntax-scratch'],'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()});assert r.returncode==0
for r in rows:
 f=T/r['path'];assert hashlib.sha256(f.read_bytes()).hexdigest()==r['proposed_sha256']
for f in [P/'proposed/renderers/web/js/standing-horses.js',T/'renderers/web/js/main.js',T/'renderers/web/js/yards.js']:
 r=subprocess.run(['node','--check',str(f)],capture_output=True,text=True);commands.append({'command':['node','--check',str(f)],'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0
for f in (P/'proposed').rglob('*.json'):json.loads(f.read_text())
json.loads((T/'data/scenes/1835.json').read_text())
(P/'SOURCE-SYNTAX-CHECK.json').write_text(json.dumps({'scope':'Source parsing/diff exact-preimage checks ONLY, no JS module execution, no GLB export/browser/app write/gate','commands':commands,'all_pass':True},indent=2)+'\n');print(json.dumps({'all_pass':True,'app_modified':False,'browser_or_model_build':False,'checks':len(commands)}))
