"""Source-only correction of rejected late-raycast API; no app writes."""
from pathlib import Path
import json,numpy as np,hashlib
P=Path(__file__).resolve().parent
s=json.loads((P/'proposed/data/transport/parked/horse-sevket-sidecar.json').read_text());r=json.loads((P/'RIGID-SUPPORT-AND-TOPOLOGY-REVIEW.json').read_text());R=np.array(r['fit']['matrix_rows']);e,n=r['fit']['at_local_enu_m'];points=np.concatenate([np.array(v['samples_m'])for v in s['contacts'].values()]+[np.array(v['equal_10mm_slab_samples_m'])for v in s['contacts'].values()])@R.T;en=np.c_[e+points[:,2],n+points[:,0]];bounds=[(en.min(0)-.05).tolist(),(en.max(0)+.05).tolist()]
region={'id':'western_hotel_yard_horse_support_01','record_id':'western_hotel_wagon_yard','bounds_enu_m':bounds,'basis':'Actual current horse contact annotations after declared uniform scale/rigid support/heading, with50mm plan margin. Source/pose changes outside this region refuse support.','maximum_region_count':1,'maximum_region_area_m2':4,'maximum_retained_triangles':32,'maximum_retained_typed_array_bytes':4096,'lifetime':'Snapshot actual drawn yard triangles before upload release; own only narrow Float64 triangle copies until yards.dispose, normal original arrays still release.'}
(P/'STATIC-SUPPORT-REGION-PROPOSAL.json').write_text(json.dumps(region,indent=2)+'\n')
f=P/'proposed/data/transport/parked/standing-horses.json';j=json.loads(f.read_text());j['scenes']['1835'][0]['ground_support_region_id']=region['id'];f.write_text(json.dumps(j,indent=2)+'\n')
s['ground_support']={'region_id':region['id'],'snapshot':'Exact actual yard-worn_earth drawn triangle copies retained before normal coarse upload release, max32triangles/4096typed-array bytes for one ≤4m² rectangle. No whole-town array retention, no RELEASE_KEEP change, no ?keep-geometry.','status':'Source proposal, CPU retention regression and normal coarse browser check required; no continuous collision claim'}
f=P/'proposed/data/transport/parked/horse-sevket-sidecar.json';f.write_text(json.dumps(s,indent=2)+'\n')
f=P/'proposed/renderers/web/js/standing-horses.js';s=f.read_text().replace('groundHeight(e, n, row.ground_record_id)','groundHeight(e, n, row.ground_record_id, row.ground_support_region_id)');f.write_text(s)
f=P/'author_scoped_patch.py';s=f.read_text();s=s.replace("groundHeight: (e, n, recordId) => yards.drawnBaseHeightAt(e, n, recordId),", "groundHeight: (e, n, recordId, regionId) => yards.drawnBaseHeightAt(e, n, recordId, regionId),")
s=s.replace("update('data/scenes/1835.json', [('    \"parked_transport\",','    \"parked_transport\",\\n    \"standing_horses\",',1)])", "update('data/scenes/1835.json', [('    \\\"parked_transport\\\",','    \\\"parked_transport\\\",\\n    \\\"standing_horses\\\",',1), ('  \\\"layers\\\": [', '  \\\"static_support_regions\\\": '+json.dumps([json.loads((P/'STATIC-SUPPORT-REGION-PROPOSAL.json').read_text())],indent=2).replace('\\n','\\n  ')+',\\n  \\\"layers\\\": [',1)])")
# Replace yard-edit source block wholesale in this outside-app patch AUTHOR.
begin=s.index("update('renderers/web/js/yards.js',[");end=s.index("(P/'SCOPED-INTEGRATION.patch')",begin)
replacement="""update('renderers/web/js/yards.js',[
(\"import * as THREE from 'three';\",\"import * as THREE from 'three';\\nimport { retainYardStaticSupport } from './yard-static-support.js';\",1),
('  records = [], terrain, confidence = null, problems = [], prebuilt = null, recordHashes = null,','  records = [], terrain, confidence = null, problems = [], prebuilt = null, recordHashes = null, supportRegions = [],',1),
('    treatmentAt: () => null,','''    treatmentAt: () => null,
    drawnBaseHeightAt: () => null,
    staticSupport: { regions: 0, triangles: 0, bytes: 0, disposed: false },''',1),
('  out.dispose = () => { for (const d of disposables) d.dispose?.(); };','''  // Retain ONLY declared small support regions now, before main.js calls
  // settleOnGpu and normal coarse upload-release empties source CPU arrays.
  const support = retainYardStaticSupport(group, supportRegions, problems);
  out.staticSupport = support.census;
  out.drawnBaseHeightAt = (e, n, recordId, regionId) => {
    const interior = out.interiors.find(item => item.record === recordId
      && pointInPolygon(item.pts, e, n));
    if (!interior || interior.treatment !== 'worn_earth') return null;
    return support.heightAt(e, n, recordId, regionId);
  };
  out.dispose = () => { support.dispose(); for (const d of disposables) d.dispose?.(); };''',1)])
"""
s=s[:begin]+replacement+s[end:]
# Main yard constructor receives only this scene's explicit opt-in region data.
s=s.replace("('  api.parkedTransport = parkedTransport;'", "('    prebuilt: yardsPrebuilt, recordHashes: enclosureHashes,', '    prebuilt: yardsPrebuilt, recordHashes: enclosureHashes,\\n    supportRegions: draws(\\\"standing_horses\\\") ? (loaded.scene.static_support_regions ?? []) : [],',1),\n('  api.parkedTransport = parkedTransport;'")
f.write_text(s)
print(json.dumps({'support_bounds_enu_m':bounds,'area_m2':float(np.prod(en.max(0)-en.min(0)+.1)),'source_only':True}))
