# Standing horse intake independent consumer review

BLOCKED for integration of frozen source proposal120e565a24a0e49418d0d4c57e5520b0ffde049f325f0b2abf4caf86503116d1 by one concrete normal coarse-device path defect. All35 manifest entries match bytes/hashes; source/metadata review is limited to this frozen proposal. No browser/build/app/ticket/Git mutation or network operation ran.

## Blocking finding: actual-ground CPU raycast reads released arrays

The proposed yards.drawnBaseHeightAt uses Raycaster.intersectObjects on the published/built yard-worn_earth BatchedMesh. Main already calls settleOnGpu(yards.group) before standing-horse construction. For coarse devices, uploadLayerNow marks yard-ground with RELEASE_KEEP['yard-ground']=[], uploads it and drops position attributes; BatchedMesh indices become empty arrays. A later lazy horse load therefore cannot safely raycast those actual triangles. Normal balanced/full on a coarse device is affected even though light correctly avoids horse GLB fetch. A keep-geometry harness run can conceal this defect. Relevant source: main.js settleOnGpu/yard boot order, upload-release.js RELEASE_KEEP/markLayer/release and proposed yards API.

Retain a narrowly bounded exact support-triangle representation before upload release, with explicit owner/memory/disposal and record/footprint bounds, or provide another exact path that never reads released buffers. Do not exempt whole town geometry from release or silently raise caps. Actual support query cost also needs one bounded measurement: instantiation currently requests962 independent sample heights; current API raycasts whole worn-earth batches and traverses world matrices for each query. Source review does not claim measured timing.

## Other reviewed paths

Scene opt-in is1835-only and respects host existence. Model fetch is lazy and reach-gated; no source GLB starts at distant spawn or light. Full/balanced reaches70/40m and one actual LOD are explicit; no motion/tack capability is invented. Native SHA/bytes/skin/group/triangle/image/bounds/anchor checks bind the actual redistributed source. No animation mixer, pose reset, rebind or retarget occurs.

Source normalization wraps the entire skin/bone hierarchy using source-origin translation, uniform reconstructed metric scale, local support quaternion and outer heading. Per-foot minimum-gap1mm development placement bound is root-authorized per the current task; zero sampled penetration and actual triangle-ground readback remain mandatory. Original upright exploration is preserved and its no-pitch restriction explicitly superseded by final sidecar history. The independent earlier transform review remains applicable; no anatomical/continuous-contact/socket acceptance transfers.

Material adaptation is declared and reversible: only cloned runtime material metalness0, retaining source map bytes/UVs/roughness/alpha/double-sided settings. Source-native is a separate declared variant; no main-world photographic verdict exists yet. Source credit is contemporary attested artifact metadata, while every horse vertex carries reconstructed confidence1. Custom color/depth/distance materials are confidence-patched; hidden-grade render/pick guards and nearest-hit selection are present.

Revision/abort checks discard stale loads, parsed stale resources dispose, clone-owned geometry/material/shadow/skeleton resources retire before source textures close, and light/dispose invalidates in-flight work. Failed same-revision loads do not silently retry; switching tiers is an explicit new revision. Instances remain resident but invisible when walking out of reach, an explicit bounded single-instance policy rather than eviction. No additional lifecycle blocker found by source inspection.

Archive/provenance/license records and both proposed unchanged GLB copy paths are explicit. Individual CC BY4.0 source credit/change notice is separate from Objaverse database ODC-By; modern model metadata is not historical phenotype/ownership evidence. Root still owns canonical catalog/publisher cap/gate/source-index integration.

Once the released-array defect is fixed and refrozen, source clearance can be reconsidered narrowly. Actual normalized/yard desktop and mobile contact/appearance, source parity, ordinary confidence/ghost/shadow/pick, near/far/no-fetch and load→light/dispose→recovery checks remain necessary; source syntax alone cannot accept them.
