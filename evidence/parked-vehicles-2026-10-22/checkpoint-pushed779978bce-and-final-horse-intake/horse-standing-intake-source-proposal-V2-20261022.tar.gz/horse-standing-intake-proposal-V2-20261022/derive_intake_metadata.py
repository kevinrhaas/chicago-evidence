"""Metadata authoring only: read actual licensed vertices/terrain, never emit GLB."""
import hashlib,json,math,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
SOURCE=Path('/workspace/shared/horse-public-base-search-20261022')
APP=Path('/workspace/chicago/chicago/4d')
sys.path.insert(0,str(SOURCE));import read_native_pose as native
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
body=next(v for m,v in native.points({})if m==1);allv=np.concatenate([v for m,v in native.points({})]);tri=native.acc(7).reshape(-1,3).astype(int);vtri=body[tri]
cross=np.cross(vtri[:,1]-vtri[:,0],vtri[:,2]-vtri[:,0]);area2=np.linalg.norm(cross,axis=1);normals=cross/np.maximum(area2[:,None],1e-30);centers=vtri.mean(1)
patches={}
for end,zsign in [('fore',1),('hind',-1)]:
 for side,xsign in [('l',1),('r',-1)]:
  label=end+'_'+side;low=(body[:,1]<1.25)&(body[:,0]*xsign>.1)&(body[:,2]*zsign>0);minimum=float(body[low,1].min())
  faces=np.flatnonzero((centers[:,0]*xsign>.1)&(centers[:,2]*zsign>0)&(vtri[:,:,1].max(1)<minimum+.085)&(normals[:,1]<-.45)&(area2>1e-10));ids=np.unique(tri[faces]);assert len(faces)>0
  center=np.average(centers[faces],axis=0,weights=area2[faces]);assert abs(float(body[ids,1].min())-minimum)<1e-9
  samples=np.concatenate([body[ids],centers[faces],(vtri[faces,0]+vtri[faces,1])/2,(vtri[faces,1]+vtri[faces,2])/2,(vtri[faces,2]+vtri[faces,0])/2]);samples=np.unique(np.round(samples,10),axis=0)
  patches[label]={'source_node_index':22,'source_primitive':0,'source_material':1,'renderer_mesh_name':'BezierCurve005_Mesh005_1','triangle_ids':faces.tolist(),'vertex_ids':ids.tolist(),'vertices_native':body[ids].tolist(),'representative_native':center.tolist(),'minimum_y_native':minimum,'samples_native':samples.tolist(),'definition':'Actual downward-facing lower-hoof triangles: normalY<−.45, all vertices below local lowest hoofY+.085 native. Includes their vertices, edge midpoints and centroids; no invented geometry.'}
origin=np.array([np.mean([p['representative_native'][0]for p in patches.values()]),min(p['minimum_y_native']for p in patches.values()),np.mean([p['representative_native'][2]for p in patches.values()])])
proxy_id=3872;proxy=body[proxy_id];target=1.55;scale=target/(proxy[1]-origin[1]);canonical=(allv-origin)*scale
for p in patches.values():
 p['samples_m']=((np.asarray(p['samples_native'])-origin)*scale).tolist();p['representative_m']=((np.asarray(p['representative_native'])-origin)*scale).tolist();p['minimum_y_m']=(p['minimum_y_native']-origin[1])*scale
contact={'schema':'standing_horse_contacts_v1','status':'PROPOSED actual source surface annotation, independently review before integration','source_sha256':sha(SOURCE/'horse-53a6eb7ccf054aa2a378dd7ec08f88fe.glb'),'source_decoder_sha256':sha(SOURCE/'read_native_pose.py'),'source_pose':'native unanimated default, no clip applied','native_up':'+Y','native_forward':'+Z','native_anatomical_left':'+X','origin_native':origin.tolist(),'origin_definition':'Ground at lowest actual hoof patch vertexY, under equally weighted mean of four actual patch area-centroidXZ positions; mean soleY is not asserted zero','uniform_metres_per_native_unit':float(scale),'scale_grade':'reconstructed','target_withers_proxy_m':target,'withers_proxy':{'mesh_node':22,'vertex_id':proxy_id,'actual_native':proxy.tolist(),'anatomical_rationale':'Dorsal shoulder/neck transition immediately behind forefeet; an explicitly chosen geometric withers proxy, not a measured breed dimension','proxy_uncertainty_native_magnitude':.10,'target_choice_range_m':[1.50,1.60]},'bounds_m':[canonical.min(0).tolist(),canonical.max(0).tolist()],'patches':patches,'grounding_limits':{'maximum_per_hoof_minimum_gap_m':.010,'minimum_sample_clearance_m':-1e-5,'method':'Rigid placement only. BaseY=max(ground at every actual patch sample minus canonical sampleY); each hoof must retain a sampled minimum gap≤10mm. No individual foot offsets, pitch, deformation or root scale solve.'},'remaining':['root acceptance of chosen withers proxy and reconstructed1.55m size','actual normalized-source review on desktop/mobile','source cap/UV/material and contact geometry readback parity','terrain grounding is sampled support, not continuous collision/force certification']}
(HERE/'SOURCE-CONTACT-DERIVATION.json').write_text(json.dumps(contact,indent=2)+'\n')

# Exact committed Heightfield.sample bilinear behavior. Cast each int16 decoded
# sample through Float32, as Heightfield.adopt does, before interpolation.
meta_path=APP/'data/terrain/epochs/e1834_harbor_cut/heightfield.json';meta=json.loads(meta_path.read_text());bin_path=meta_path.with_name(meta['bin']);raw=np.memmap(bin_path,dtype='<i2',mode='r',shape=(meta['rows'],meta['cols']))
def ground(e,n):
 gx=(e-meta['origin_e'])/meta['cell_m'];gy=(n-meta['origin_n'])/meta['cell_m'];assert 0<=gx<=meta['cols']-1 and 0<=gy<=meta['rows']-1
 x=min(math.floor(gx),meta['cols']-2);y=min(math.floor(gy),meta['rows']-2);fx=gx-x;fy=gy-y
 h=lambda yy,xx:float(np.float32(int(raw[yy,xx])*meta['scale']+meta.get('offset',0)))
 return(h(y,x)*(1-fx)+h(y,x+1)*fx)*(1-fy)+(h(y+1,x)*(1-fx)+h(y+1,x+1)*fx)*fy+.022
def bbox_distance(a,b):return math.hypot(max(a[0][0]-b[1][0],b[0][0]-a[1][0],0),max(a[0][1]-b[1][1],b[0][1]-a[1][1],0))
def rigid_points(file):
 b=Path(file).read_bytes();n=int.from_bytes(b[12:16],'little');g=json.loads(b[20:20+n]);blob=b[n+28:];parents={k:i for i,x in enumerate(g['nodes'])for k in x.get('children',[])};world={}
 def w(i):
  if i not in world:world[i]=(w(parents[i])if i in parents else np.eye(4))@native.local(g['nodes'][i],{})
  return world[i]
 points=[]
 for ni,node in enumerate(g['nodes']):
  if 'mesh'not in node:continue
  for pr in g['meshes'][node['mesh']]['primitives']:
   a=g['accessors'][pr['attributes']['POSITION']];view=g['bufferViews'][a['bufferView']];assert a['componentType']==5126
   v=np.ndarray((a['count'],3),dtype='<f4',buffer=blob,offset=view.get('byteOffset',0)+a.get('byteOffset',0),strides=(view.get('byteStride',12),4));points.append((np.c_[v,np.ones(len(v))]@w(ni).T)[:,:3])
 return np.concatenate(points)
placements=json.loads((APP/'data/transport/parked/placements.json').read_text());vehicle_boxes=[]
for row in placements['scenes']['1835']:
 if 'western'not in row['id']:continue
 file=APP/'renderers/web'/placements['models'][row['model']]['file'];v=rigid_points(file);yaw=math.pi-math.radians(row['bearing_deg']);co,si=math.cos(yaw),math.sin(yaw);en=np.c_[row['at_local_enu_m'][0]+co*v[:,0]+si*v[:,2],row['at_local_enu_m'][1]+si*v[:,0]-co*v[:,2]];vehicle_boxes.append({'id':row['id'],'bounds':[en.min(0).tolist(),en.max(0).tolist()],'source_glb_sha256':sha(file),'method':'Conservative unpitched source all-mesh AABB, includes pole; parked positive tongue pitch shortens pole plan envelope. Not triangle collision certification.'})
building_boxes=[]
for file in sorted((APP/'data/sidecars/1835').glob('*.json')):
 if file.stat().st_size>100000:continue
 try:j=json.loads(file.read_text());p=j.get('placement',{});poly=j.get('footprint',{}).get('polygon',[])
 except Exception:continue
 if not poly or not isinstance(p,dict)or p.get('local_e')is None or abs(p['local_e']+127.5)>45 or abs(p['local_n']+295.5)>45:continue
 theta=math.radians(p.get('rotation_deg',0));co,si=math.cos(theta),math.sin(theta);v=np.asarray(poly);en=np.c_[p['local_e']+co*v[:,0]+si*v[:,1],p['local_n']-si*v[:,0]+co*v[:,1]];building_boxes.append({'id':j['id'],'bounds':[en.min(0).tolist(),en.max(0).tolist()],'source_json_sha256':sha(file)})
candidates=[]
for e in [-128.0,-127.5,-127.0]:
 for n in [-296.0,-295.5,-295.0]:
  # Heading90deg, so native+Z faces east; all source geometry remains unchanged.
  samples={k:np.asarray(v['samples_m'])for k,v in patches.items()};base=max(ground(e+p[2],n+p[0])-p[1]for v in samples.values()for p in v);gaps={k:float(min(base+p[1]-ground(e+p[2],n+p[0])for p in v))for k,v in samples.items()};en=np.c_[e+canonical[:,2],n+canonical[:,0]];box=[en.min(0).tolist(),en.max(0).tolist()]
  walls=min(bbox_distance(box,x['bounds'])for x in building_boxes);vehicles=min(bbox_distance(box,x['bounds'])for x in vehicle_boxes);east=-124.5-box[1][0];south=box[0][1]+298.0;door=bbox_distance(box,[[-130.575,-298],[-129.225,-295]])
  candidates.append({'at_local_enu_m':[e,n],'bearing_deg':90,'root_y_m':base,'minimum_gap_by_hoof_m':gaps,'maximum_hoof_gap_m':max(gaps.values()),'bounds_enu_m':box,'building_AABB_clearance_m':walls,'vehicle_AABB_clearance_m':vehicles,'east_fence_clearance_m':east,'stable_front_clearance_m':south,'stable_door_3m_approach_clearance_m':door,'eligible':max(gaps.values())<=.010 and min(walls,east,south)>=1.0 and vehicles>=.75 and door>=.50})
eligible=[c for c in candidates if c['eligible']];assert eligible,'No proposed stand satisfies bounds; do not silently move source feet'
chosen=min(eligible,key=lambda x:(x['maximum_hoof_gap_m'],abs(x['at_local_enu_m'][0]+127.5)+abs(x['at_local_enu_m'][1]+295.5)))
yard_path=APP/'data/enclosures/western_hotel_wagon_yard.json';receipt={'status':'PROPOSED stand from nine bounded candidates, all geometry/source/terrain read only','scene':'1835','source_ids':['chicagology_prefire278'],'yard':'western_hotel_wagon_yard','ground':'Exact committed heightfield bilinear samples plus authoritative yard-base lift. Runtime proposal reads the yard module API rather than duplicating its22mm lift.','terrain_meta_sha256':sha(meta_path),'terrain_bin_sha256':sha(bin_path),'yard_record_sha256':sha(yard_path),'yard_source_code_sha256':sha(APP/'renderers/web/js/yards.js'),'vehicle_placements_sha256':sha(APP/'data/transport/parked/placements.json'),'chosen':chosen,'candidates':candidates,'building_boxes':building_boxes,'vehicle_boxes':vehicle_boxes,'scope_limits':['Sidecar buildingAABBs use local footprint bounds; not per-triangle collision','Measured source pole/body conservative bounds only; no hitching or force physics','Door3m approach is an explicit clearance guard, not a historical surveyed route','First horse stand, phenotype and exact time are reconstructed; no owner or breed assigned']}
(HERE/'YARD-STAND-DERIVATION.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'uniform_metres_per_native_unit':scale,'withers_proxy':contact['withers_proxy'],'bounds_m':contact['bounds_m'],'contacts':{k:{'faces':len(v['triangle_ids']),'vertices':len(v['vertex_ids']),'samples':len(v['samples_m']),'minimum_y_m':v['minimum_y_m']}for k,v in patches.items()},'chosen_stand':chosen,'nearby_buildings':[x['id']for x in building_boxes]},indent=2))
