"""Read actual GLB bytes only; never import/render/execute model content."""
from pathlib import Path
import json,struct,hashlib,math,io
from PIL import Image
R=Path(__file__).parent

def matmul(a,b):return [[sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
def identity():return [[1. if i==j else 0. for j in range(4)] for i in range(4)]
def local(n):
 if 'matrix' in n:return [[n['matrix'][j*4+i] for j in range(4)] for i in range(4)]
 x,y,z,w=n.get('rotation',[0,0,0,1]);sx,sy,sz=n.get('scale',[1,1,1]);t=n.get('translation',[0,0,0]);rot=[[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w),t[0]],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w),t[1]],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y),t[2]],[0,0,0,1]]
 for i in range(3):
  for j,s in enumerate([sx,sy,sz]):rot[i][j]*=s
 return rot
reports=[]
for p in sorted(R.glob('*.glb')):
 raw=p.read_bytes();magic,version,length=struct.unpack_from('<III',raw);assert magic==0x46546c67 and version==2 and length==len(raw);at=12;chunks=[];document=None;binary=None
 while at<len(raw):
  size,kind=struct.unpack_from('<II',raw,at);chunk=raw[at+8:at+8+size];assert len(chunk)==size;chunks.append({'type':hex(kind),'bytes':size})
  if kind==0x4e4f534a:assert document is None;document=json.loads(chunk)
  elif kind==0x004e4942:assert binary is None;binary=chunk
  at+=8+size
 assert at==len(raw) and document is not None and binary is not None;g=document;(R/(p.stem+'-ACTUAL-GLB-JSON.json')).write_text(json.dumps(g,indent=2)+'\n')
 assert len(g.get('buffers',[]))==1 and 'uri' not in g['buffers'][0] and g['buffers'][0]['byteLength']<=len(binary)
 images=[]
 for i,im in enumerate(g.get('images',[])):
  if 'bufferView' in im:
   v=g['bufferViews'][im['bufferView']];data=binary[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
   with Image.open(io.BytesIO(data)) as image:fmt=image.format;dims=list(image.size);mode=image.mode
   images.append({'index':i,'name':im.get('name'),'mimeType':im.get('mimeType'),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'format':fmt,'dimensions':dims,'mode':mode})
  else:images.append({'index':i,'external_uri':im.get('uri')})
 prims=[];positions={}
 for mi,m in enumerate(g.get('meshes',[])):
  for pi,pr in enumerate(m['primitives']):
   attrs=pr['attributes'];acc=g['accessors'][attrs['POSITION']];mode=pr.get('mode',4);count=g['accessors'][pr['indices']]['count'] if 'indices' in pr else acc['count'];assert mode==4 and count%3==0
   prims.append({'mesh':mi,'mesh_name':m.get('name'),'primitive':pi,'position_accessor':attrs['POSITION'],'position_count':acc['count'],'triangles':count//3,'material':pr.get('material'),'attributes':attrs,'extensions':pr.get('extensions',{})})
   ai=attrs['POSITION']
   if ai not in positions:
    assert acc['componentType']==5126 and acc['type']=='VEC3' and not acc.get('sparse'),'inspect unsupported position encoding'
    v=g['bufferViews'][acc['bufferView']];start=v.get('byteOffset',0)+acc.get('byteOffset',0);stride=v.get('byteStride',12);positions[ai]=[struct.unpack_from('<fff',binary,start+k*stride) for k in range(acc['count'])]
    assert all(math.isfinite(c) for q in positions[ai] for c in q)
 worlds={};nodes=g.get('nodes',[])
 def walk(i,parent,seen):
  assert i not in seen,'node cycle';w=matmul(parent,local(nodes[i]));worlds[i]=w
  for c in nodes[i].get('children',[]):walk(c,w,seen|{i})
 scene=g.get('scene',0);roots=g.get('scenes',[{'nodes':[]}])[scene].get('nodes',[])
 for i in roots:walk(i,identity(),set())
 boundrows=[];mins=[float('inf')]*3;maxs=[-float('inf')]*3
 for ni,w in worlds.items():
  n=nodes[ni]
  if 'mesh' not in n:continue
  lo=[float('inf')]*3;hi=[-float('inf')]*3
  for prim in g['meshes'][n['mesh']]['primitives']:
   for pt in positions[prim['attributes']['POSITION']]:
    q=[sum(w[i][j]*pt[j] for j in range(3))+w[i][3] for i in range(3)]
    for k in range(3):lo[k]=min(lo[k],q[k]);hi[k]=max(hi[k],q[k]);mins[k]=min(mins[k],q[k]);maxs[k]=max(maxs[k],q[k])
  boundrows.append({'node':ni,'name':n.get('name'),'mesh':n['mesh'],'skin':n.get('skin'),'translation':n.get('translation'),'rotation':n.get('rotation'),'scale':n.get('scale'),'world_min':lo,'world_max':hi,'world_dimensions':[hi[k]-lo[k] for k in range(3)]})
 external=[]
 for kind in ['buffers','images']:
  external.extend({'kind':kind,'uri':x['uri']} for x in g.get(kind,[]) if 'uri' in x)
 attribution=[]
 def scan(x,path=''):
  if isinstance(x,dict):
   for k,v in x.items():
    q=path+'/'+k
    if k.lower() in ['copyright','author','license','licence','credits','attribution'] or (k.lower()=='source' and isinstance(v,str) and v.startswith('http')):attribution.append({'path':q,'value':v})
    scan(v,q)
  elif isinstance(x,list):
   for i,v in enumerate(x):scan(v,path+'/'+str(i))
 scan(g)
 report={'file':p.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'GLB_version':version,'chunks':chunks,'asset':g.get('asset'),'extensionsUsed':g.get('extensionsUsed',[]),'extensionsRequired':g.get('extensionsRequired',[]),'scenes':len(g.get('scenes',[])),'active_scene':scene,'nodes':len(nodes),'meshes':len(g.get('meshes',[])),'primitives':prims,'actual_unique_mesh_triangle_sum':sum(pr['triangles'] for pr in prims),'actual_unique_POSITION_vertex_count':sum(len(v) for v in positions.values()),'skins':len(g.get('skins',[])),'animations':len(g.get('animations',[])),'materials':g.get('materials',[]),'textures':g.get('textures',[]),'images':images,'external_dependencies':external,'world_bounds':{'min':mins,'max':maxs,'dimensions':[maxs[k]-mins[k] for k in range(3)],'units':'glTF conventionmetres; real-world metric scale/source calibration NOT verified','deformed_skin_animation_bounds':'NOT evaluated'},'per_mesh_node_bounds':boundrows,'embedded_attribution_license_fields':attribution,'limits':['actual file structure/binary positions/material/image headers read only','no mesh import, artifact code execution, geometry generation, browser or rendering','no historical date/maker/place or wheel/steering/rig/mesh quality acceptance','Objaverse originalcurrent creator provenance saved separately; no license inferred from missing embedded credits']}
 reports.append(report);(R/(p.stem+'-ACTUAL-STRUCTURE-AUDIT.json')).write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['file','bytes','sha256','asset','meshes','skins','animations','actual_unique_mesh_triangle_sum','actual_unique_POSITION_vertex_count','world_bounds','external_dependencies','embedded_attribution_license_fields']}));print('IMAGE_HEADERS',[(x.get('name'),x.get('dimensions'),x.get('format')) for x in images])
(R/'ALL-ACTUAL-GLB-AUDITS.json').write_text(json.dumps(reports,indent=2)+'\n')
