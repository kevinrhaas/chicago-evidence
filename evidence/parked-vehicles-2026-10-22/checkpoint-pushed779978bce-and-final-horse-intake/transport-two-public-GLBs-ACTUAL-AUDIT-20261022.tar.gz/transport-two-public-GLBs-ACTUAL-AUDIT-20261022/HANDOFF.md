# Actual public OldCart and RFD GLB audit — no installation

**Old Cart is a promising material/geometry development base after root personally reviewed its preview.** Its body, steering and four wheels are already separate source nodes. Existing historical vehicles, Brougham source and app assets remain untouched. RFD remains a future finish candidate:240pieces, a blended material, unknown prototype/maker/date and noPrairie1904placement evidence. The damaged PersScanscarriage is rejected as an app replacement and was not downloaded.

Exactly the two root-authorized ordinary public Objaverse GLBs were downloaded, original bytes retained:

|Asset|Actual bytes /SHA256|Actual GLB structure|
|---|---|---|
|Old Cart — Lyskilde/longtail|9,809,548B;13600b73c1777545e1454d452c58d141469f031b2c5e6c29b1c6fdefe9145046|17,506indexed triangles;8meshes/primitives;51,595POSITIONaccessor vertices across actual split meshes (originalSketchfabmetadata9,352vertices isnotthisderivedGLB count);2materials;6embedded1024²PNGimages;0skins/animations/externaldependencies/compressionextensions.|
|Rural Free Delivery wagon — Aldemona|9,173,856B;8308d8530715d58b6a93b226d237a37f9be9b1751bbd168dd5aaf8309f066d32|11,526indexed triangles;240meshes/primitives;13,040actualPOSITIONvertices;2materials;6embedded1024²PNGimages;0skins/animations/externaldependencies/compressionextensions.|

Full primitive/accessor/material/image/binary-position/node-transform bounds audit is in each ACTUAL-STRUCTURE-AUDIT.json. GLB2 headers, declared lengths and source HEAD byte lengths match. Full payload hashes above were computed locally; earlier publicHEAD ETags are object-version metadata and DO NOT equal these content hashes. No asset code or embedded scripts were executed.

## OldCart hierarchy and material cost

Exact complete hierarchy/transforms: f536745fd82144eeb5cc4900a48e816e-NODE-HIERARCHY.txt. Source organization:

- CartBody parent holds CartBody_CartBase_0 and CartBody_CartDetails_0 meshes.
- CartSteer parent holds CartSteer_CartBase_0 and CartSteer_CartDetails_0 meshes.
- Four separate wheel parents/meshes:wheel_fr_CartDetails_0,wheel_fl_CartDetails_0,wheel_rl_CartDetails_0,wheel_rr_CartDetails_0.

These are source grouping names, not tested kinematic pivots or complete wheel/steering animation acceptance. Exact node hierarchy preserves original rotations/scales; do not assume grouporigins are calibrated axes. No rescale/recenter/rotation/reparent/export performed.

OldCart materials CartBase/CartDetails are OPAQUE,doubleSided,PBR metallicFactor0, each binding basecolor+packedmetallicRoughness/occlusion+normal. Actual sixRGB1024²PNGs total7,110,986B. Estimated6RGBA8decoded textures24MiB atbaselevel/~32MiB fullmips, excludes CPUduplicates/staging/driverbuffers. ActualGPUusage not measured. Eight sourceprimitives are not a measuredrenderpass/driver count.

RFD materials UV_Sat_02/UV_Sat_01 use the same two3texture PBR sets;firstmaterialBLEND,doubleSided;secondOPAQUE,doubleSided. Six1024²PNGimages total8,084,182B, oneRGBA andfiveRGB. Same24MiBbase/~32MiBfullmip RGBA8estimate.240sourceprimitives likely require a later reviewed static-batching plan while preserving separate motion parts, UVs, opacity and original guards; actual driverdraws/performance are unmeasured and additional passes may increase calls.

## Units/origin truth

These are exact transformed static POSITION bounds in original file units, with original active scene/node transforms applied:

- OldCart:min(−249.251988,−0.646568,−71.886369),max(140.279817,119.472397,67.819371);dimensions(389.531805,120.118965,139.705741).
- RFD:min(3067.393158,−53.684452,−99.865828),max(3500.179413,176.021319,94.940657);dimensions(432.786255,229.705771,194.806485).

The glTF format convention alone does not validate these numeric lengths as real-world metres. RFD also carries a large sourceworldXoffset. No physical dimensions/source specimen calibration were supplied by the inspected creator pages. Root will choose any later independently justified normalization/calibration; no automatic centimetre assumption, centering, unit conversion or placement has been applied.

## Source, license and history

Both actual GLBs embed asset.extras with exact creator, originalSketchfabsource,title and CC-BY-4.0link. This agrees with each originalcreatorUID/currentCCBY4API and individualObjaverseannotation licenseby. ORIGINAL-SOURCE-CREDIT.json and copied originalmetadata/annotation/profile records retain the links and attribution. All textures are embedded, with no external fetching needed. No embedded metadata claims a maker/date or gives additional third-party texture credits. No broad photorealistic/historical/rig/budget acceptance transfers.

OldCart original:https://sketchfab.com/3d-models/old-cart-f536745fd82144eeb5cc4900a48e816e ;creator:https://sketchfab.com/longtail ;publicdownload:https://huggingface.co/datasets/allenai/objaverse/resolve/main/glbs/000-032/f536745fd82144eeb5cc4900a48e816e.glb . Credit:Lyskilde,OldCart,CCBY4,originalURL,andstateactualfuturechanges. Generic farm-style vehicle, no specimen/date/place/Chicago attestation.

RFD original:https://sketchfab.com/3d-models/rural-free-delivery-wagon-73c59f9eded94cdea8cc1237ecde53c8 ;creator:https://sketchfab.com/Aldemona ;publicdownload:https://huggingface.co/datasets/allenai/objaverse/resolve/main/glbs/000-036/73c59f9eded94cdea8cc1237ecde53c8.glb . Credit:Aldemona,RuralFreeDeliverywagon,CCBY4,originalURL,andstateactualfuturechanges. Creator description says only3dsMax/Marmoset/SubstancePainterworkflow. Publication2021-06-19 isnotmanufacture date. Embedded metadata supplies no museum accession/maker/date. VisibleUSMAIL/RouteNo8/RuralFreeDelivery/POSTMAN lettering isnotuniqueidentification. Boundedwebsearch returnedJSenable pages, so no actualmuseum match was obtained. Precise prototype/maker/date remainUNKNOWN; no inventedStudebakerorother attribution and noPrairie1904placement claim. See RFD-SPECIMEN-DATE-MAKER-FINDING.json.

License:https://creativecommons.org/licenses/by/4.0/ . Dataset ODC-BY isnotanindividualmeshlicense. Preserve both originalGLBs/attribution during futurederivation.

## Finite handoff

No app/worktree/tickets/Git edits, install, rescale, import, model export, Blender, browser orCI action. Any next OldCart normalization/parts/parked intake needs rootseparate review against existing type/date/scene/budget/source contracts, sourceunits calibration and actualfixed-view acceptance. RFD requires batching plusidentifiedhistoricalprototype/date/placement before application; useitsfinish as a reference only meanwhile. ExistingBrougham work remains active.
