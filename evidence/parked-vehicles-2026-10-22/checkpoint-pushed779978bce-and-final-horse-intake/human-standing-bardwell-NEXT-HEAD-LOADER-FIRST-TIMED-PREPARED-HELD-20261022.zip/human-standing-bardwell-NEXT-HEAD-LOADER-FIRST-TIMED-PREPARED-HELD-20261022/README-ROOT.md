# Fresh merged/card-fixed town review — HELD

This is one new execution copy, prepared from the actual143 TIMED caller. No browser is launched. Final HEAD/index and canonical-input hash are unassigned; all3 release templates remain false. The143 desktop visual PASS and genuine cold-far desktop functional FAIL are preserved as historical evidence only, together with their original source/pin metadata. They do not qualify the next head.

The source delta only reorders desktop_functional: required production loader checks0,1,2,3 run first, then the same existing ordinary AUTO far check at lake_at_canal. It is explicitly labelled warm process after required loader checks. Existing loaderOne releases every ordinary lease; this does not promise a GLB remains in the refcounted store. The receipt records actual store.loaded before the far check. There is no retained preload lease, forced actorLOD, replacement geometry, new route, changed camera, pose or clock. Browser helper a8cf3f35 is unchanged, including exact original90-second readiness deadline/timestamp semantics and all far/root/sole/fit/shoe/render/budget assertions. The global540-second cap remains.

Desktop_visual still captures profile/front/quarter/card plus original timing. Mobile_full still runs the original complete grid once:3views/card/timing, required loader checks and ordinary far. Their source blocks are unchanged. The v1 receipt protocol stays compatible; observerRevision explicitly records v4_timed_readiness_loader_first. Actual startup caller/helper SHA fields are retained.

Root sequence after merging currentDEV and the reviewed card repair:

1. Finish supported derivation and actual required full gate; commit the passed tree, publish from that commit and finish existing published checks. Keep the new source fixed. Incoming smoke changes must be reconciled and priced from the actual final diff; no assumption of unchanged143 smoke bytes is made here.
2. Use unchanged final_pins.py to bind the actual clean committed/published head/tree and exact same96c4 canonical import. It rejects dirty/staged changes, a tree unlike the passed tree, stale published/runtime/GLBs, altered authoring inputs, mismatched16registry or public canonical provenance. Full-gate and runtime checks retain their existing public budgets. No final pin command was run during preparation.

```sh
python3 -B /workspace/shared/human-standing-bardwell-NEXT-HEAD-LOADER-FIRST-TIMED-PREPARED-HELD-20261022/final_pins.py pin --expected-head ACTUAL_NEW_HEAD --passed-tree ACTUAL_GATE_PASSED_TREE --gate-closed-pass
```

3. On one actual free browser lane, root separately releases each actual phase with fresh release/output files. Use this SAME copy and canonical path for all3 phases. Functional release requires the new successful visual receipt path/hash. The helper prepares release JSON only; root separately launches capture_town.cjs once per released phase. No automatic retry or old-head transplant is authorized by this packet.

```sh
python3 -B <THIS_COPY>/final_pins.py release --phase desktop_visual --lane-closed --release <FRESH_VISUAL_RELEASE.json> --output <FRESH_VISUAL_OUTPUT>
PW_EXECUTABLE=/usr/bin/chromium node <THIS_COPY>/capture_town.cjs <FRESH_VISUAL_RELEASE.json>
python3 -B <THIS_COPY>/final_pins.py release --phase desktop_functional --lane-closed --visual-receipt <ACTUAL_NEW_VISUAL_OUTPUT/receipt.json> --release <FRESH_FUNCTIONAL_RELEASE.json> --output <FRESH_FUNCTIONAL_OUTPUT>
PW_EXECUTABLE=/usr/bin/chromium node <THIS_COPY>/capture_town.cjs <FRESH_FUNCTIONAL_RELEASE.json>
python3 -B <THIS_COPY>/final_pins.py release --phase mobile_full --lane-closed --release <FRESH_MOBILE_RELEASE.json> --output <FRESH_MOBILE_OUTPUT>
PW_EXECUTABLE=/usr/bin/chromium node <THIS_COPY>/capture_town.cjs <FRESH_MOBILE_RELEASE.json>
```

Actual new card PNG review must confirm the source-identity/firm-connection repair. Warm AUTO far success would not establish a cold-load performance claim. Town results remain separate from actual remote CI/new-head/incremental-coverage evidence. Photographic/full-fit/occupied acceptance stays open. No app/worktree/index/CI/network/browser action occurred in preparation.
