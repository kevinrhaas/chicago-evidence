"""Outside-app held execution copy; does not launch or touch app/index/source refs."""
import pathlib,shutil,json,hashlib,difflib,datetime
S=pathlib.Path('/workspace/shared/human-standing-bardwell-FINAL-HEAD-TIMED-EXECUTION-14323534-20261022')
D=pathlib.Path(__file__).parent
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert H(S/'browser_review.cjs')=='a8cf3f354f1a9f1caddced6808f4a2857c68b73158f2f02eaa80809a53b2d193'
assert H(S/'capture_town.cjs')=='87b464969c1d200c074651ba7b480f5f22b87205cd5e483b2988a9ee8142b129'
hist=D/'historical-143-only';hist.mkdir(exist_ok=False)
for p in S.iterdir():
 if p.name=='IMMUTABLE-CANONICAL-IMPORT-REFERENCE':shutil.copytree(p,D/p.name)
 elif p.is_file() and p.name not in ['CANONICAL-EXPECTED-INPUTS-HELD.json','RELEASE-desktop_visual-HELD.json','RELEASE-desktop_functional-HELD.json','RELEASE-mobile_full-HELD.json']:
  if p.name in ['browser_review.cjs','capture_town.cjs','final_pins.py']:shutil.copy2(p,D/p.name)
  else:shutil.copy2(p,hist/p.name)
for phase,folder in [('desktop_visual','bardwell-FINAL-town-desktop-visual-TIMED-20261022'),('desktop_functional','bardwell-FINAL-town-desktop-functional-TIMED-20261022')]:
 p=pathlib.Path('/workspace/shared')/folder/'receipt.json';r=json.loads(p.read_bytes());assert r['closed'] is True and r['head']=='14323534e9493a3630ac9dcbe1b8daa1db3ae454';assert r['pass'] is (phase=='desktop_visual');shutil.copy2(p,hist/f'ACTUAL-{phase}-receipt.json')
original=(S/'capture_town.cjs').read_text();updated=original
old=""" if(cfg.phase==='desktop_functional'){
  phase('far_started');receipt.far=await page.evaluate(()=>window.__bardwellTownReview.far());phase('far_completed');receipt.loader=[];
  for(let lod=0;lod<4;lod++){remaining();phase('loader_one_started',{lod});const row=await page.evaluate(lod=>window.__bardwellTownReview.loaderOne(lod),lod);receipt.loader.push(row);fs.writeFileSync(path.join(out,'loader-lod'+lod+'.json'),JSON.stringify(row,null,2)+'\\n');phase('loader_one_completed',{lod});}
 }else if(cfg.phase==='mobile_full')"""
new=""" if(cfg.phase==='desktop_functional'){
  receipt.functionalOrder=['required_loader0','required_loader1','required_loader2','required_loader3','ordinary_AUTO_far_after_loader_checks'];receipt.loader=[];
  for(let lod=0;lod<4;lod++){remaining();phase('loader_one_started',{lod});const row=await page.evaluate(lod=>window.__bardwellTownReview.loaderOne(lod),lod);receipt.loader.push(row);fs.writeFileSync(path.join(out,'loader-lod'+lod+'.json'),JSON.stringify(row,null,2)+'\\n');phase('loader_one_completed',{lod});}
  receipt.farWarmContext={classification:'warm_process_after_four_required_loader_checks',lease_policy:'Normal production loaderOne releases each lease; no retained preload or guaranteed resident GLB cache',assets_loaded_before_far:await page.evaluate(()=>window.__chicago4d.humans.assets.loaded)};
  phase('far_started',{cache_state:receipt.farWarmContext.classification});receipt.far=await page.evaluate(()=>window.__bardwellTownReview.far());receipt.far.warm_process_after_required_loader_checks=true;phase('far_completed');
 }else if(cfg.phase==='mobile_full')"""
assert updated.count(old)==1;updated=updated.replace(old,new)
assert updated.count("observerRevision:'v3_timed_readiness'")==1;updated=updated.replace("observerRevision:'v3_timed_readiness'","observerRevision:'v4_timed_readiness_loader_first'")
assert updated.count('desktop_functional=far-first/four loader rows')==1;updated=updated.replace('desktop_functional=far-first/four loader rows','desktop_functional=four loader rows then ordinary AUTO far (warm process)')
(D/'capture_town.cjs').write_text(updated)
(hist/'ORIGINAL-TIMED-capture_town.cjs').write_text(original)
(D/'LOADER-FIRST-ONLY.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),updated.splitlines(True),fromfile='timed143/capture_town.cjs',tofile='nexthead-loader-first/capture_town.cjs')))
canonical=json.loads((S/'CANONICAL-EXPECTED-INPUTS-HELD.json').read_bytes());canonical.update(state='PREPARED_HELD_NEW_HEAD_PENDING',final_head=None,final_index_digest=None,note='HELD for new merged/card-fixed committed/published source.96c4 canonical asset identity remains the immutable candidate, but actual future source/public bytes must pass unchanged final_pins.py; no old143town result qualifies this new head.')
(D/'CANONICAL-EXPECTED-INPUTS-HELD.json').write_text(json.dumps(canonical,indent=2)+'\n')
for phase in ['desktop_visual','desktop_functional','mobile_full']:
 cfg=json.loads((S/f'RELEASE-{phase}-HELD.json').read_bytes());cfg.update(released=False,rootLaneClosed=False,expectedHead=None,expectedIndexDigest=None,expectedCanonicalInputsSHA=None,output=None,note='HELD until exact new merged/card-fixed source gate, commit, postcommit publish and final pinning. No browser launched; original540s cap and all assertions retained.');
 if phase=='desktop_functional':cfg.update(baseVisualReceipt=None,baseVisualReceiptSHA=None)
 (D/f'RELEASE-{phase}-HELD.json').write_text(json.dumps(cfg,indent=2)+'\n')
receipt={'state':'PREPARED_HELD_NEXT_HEAD_UNKNOWN_NO_BROWSER','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_copy':str(S),'expected_head':None,'all_releases_false':True,'browser_helper_sha256':H(D/'browser_review.cjs'),'capture_caller_sha256':H(D/'capture_town.cjs'),'unchanged_final_pins_sha256':H(D/'final_pins.py'),'original_capture_sha256':H(S/'capture_town.cjs'),'patch_sha256':H(D/'LOADER-FIRST-ONLY.patch'),'scope':'Only desktop_functional order changes: existing4loader checks precede existingordinaryAUTO far. Warm process labelled; normal lease releases retained. Actual cache inventory recorded without changing it. Mobile_full grid and desktop_visual code unchanged. Timely readiness proof,90s waits,540s global cap,route/camera/fit/sole/shoe/budget/card/identity/source/closure assertions unchanged.','historical143_visual':'PASS preserved under historical-143-only; no future head qualification','historical143_functional':'COLD far readiness FAIL preserved under historical-143-only; never retrospectively accepted'}
(D/'PREPARED-HELD.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
