HELD: do not execute until root explicitly releases the full-gate lane after primary gate5211 closes and its global logs are copied.

Pinned app: /workspace/chicago-waistcoat/chicago/4d
HEAD: fde6bc317f6c82b57a1eaaf77a46d6d8274ecfd8
MERGE_HEAD / supported BASE: 824957fe47dd70fad729c3b117cb18b695d54b0b
Staged tree: 4eda1bf9303d1d968fffeb2f686396637a513b3c

Released command (normal escalation for network/Git/required readers):

    python3 /workspace/shared/HORSE-4eda-FINAL-PREFLIGHT-HELD-20261022/run_once.py --lane-released

The runner uses the existing preflight unchanged, CHECK_JOBS=4, required readers, shared Python311 PATH and single-thread math. BASE is the exact supported SHA override, so preflight's fetch will not advance shared origin/dev. There is no added outer timeout, assertion change, automatic retry or automatic commit/push. It refuses a changed source/base or reused output directory and verifies all three ignored Glessner outputs against the current tracked manifest. It copies /tmp/preflight-{check,cl,ids}.log immediately after normal termination and records actual exit/source stability in ACTUAL/RESULT.json.

After actual full PASS on the unchanged tree, root may release/confirm ordinary merge commit and push, actual-HEAD changelog/ID checks, postcommit normal publish and mirror. A commit must not borrow the old fde6 gate. The PR body checkpoint is local only and has not been submitted to GitHub. Old mobilePASS and desktop timingFAIL receipts remain labeled fde6, never relabeled current-source proof.
