#!/usr/bin/env python3
"""Held normal preflight, exact source/base pins, with immediate terminal log capture."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys, time

ROOT = Path('/workspace/chicago-waistcoat')
APP = ROOT / 'chicago/4d'
HERE = Path(__file__).resolve().parent
HEAD = 'fde6bc317f6c82b57a1eaaf77a46d6d8274ecfd8'
BASE = '824957fe47dd70fad729c3b117cb18b695d54b0b'
TREE = '4eda1bf9303d1d968fffeb2f686396637a513b3c'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lane-released', action='store_true', required=True)
    args = parser.parse_args()
    assert args.lane_released
    assert git('rev-parse', 'HEAD') == HEAD
    assert git('rev-parse', 'MERGE_HEAD') == BASE
    assert git('write-tree') == TREE
    assert not git('diff', '--name-only') and not git('ls-files', '-u')
    assert (APP / 'tickets').resolve() == APP / 'tickets'
    assert (APP / 'tickets/.git').is_dir() and not (APP / 'tickets/.git').is_symlink()
    manifest = json.loads((APP / 'docs/RESEARCH/glessner-v4-recovery/manifest.json').read_text())
    for relative, expected in manifest['files'].items():
        data = (APP / relative).read_bytes()
        assert len(data) == expected['bytes']
        assert hashlib.sha256(data).hexdigest() == expected['sha256']
    output = HERE / 'ACTUAL'
    output.mkdir(exist_ok=False)
    env = os.environ.copy()
    env.update(PATH='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:' + env['PATH'],
               BASE=BASE, C4D_GATE_REQUIRE_READERS='1', CHECK_JOBS='4',
               OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
    command = ['bash', 'tools/preflight.sh']
    start = time.monotonic()
    with (output / 'FULL-PREFLIGHT.log').open('w') as stream:
        result = subprocess.run(command, cwd=APP, env=env, stdout=stream, stderr=subprocess.STDOUT)
    # Copy globals immediately after this foreground gate has terminated.
    copied = []
    for name in ['preflight-check.log', 'preflight-cl.log', 'preflight-ids.log']:
        source = Path('/tmp') / name
        if source.is_file():
            shutil.copyfile(source, output / name)
            copied.append(name)
    after = {'head': git('rev-parse', 'HEAD'), 'merge_head': git('rev-parse', 'MERGE_HEAD'),
             'tree': git('write-tree'), 'unstaged': bool(git('diff', '--name-only')),
             'unmerged': bool(git('ls-files', '-u'))}
    unchanged = after == {'head': HEAD, 'merge_head': BASE, 'tree': TREE, 'unstaged': False, 'unmerged': False}
    receipt = {'command': command, 'base': BASE, 'head': HEAD, 'staged_tree': TREE,
               'check_jobs': 4, 'require_readers': True, 'elapsed_s': time.monotonic() - start,
               'preflight_exit': result.returncode, 'copied_globals': copied,
               'after': after, 'tracked_source_unchanged': unchanged,
               'status': 'PASS' if result.returncode == 0 and unchanged else 'FAIL',
               'postcommit_head_checks_publish_browser': 'NOT_RUN'}
    (output / 'RESULT.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))
    return 0 if receipt['status'] == 'PASS' else (result.returncode or 1)

if __name__ == '__main__':
    sys.exit(main())
