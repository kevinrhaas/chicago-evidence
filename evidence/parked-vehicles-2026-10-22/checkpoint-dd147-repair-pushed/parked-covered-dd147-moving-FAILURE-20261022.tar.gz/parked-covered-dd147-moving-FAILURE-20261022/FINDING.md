# Actual current-head moving-frame failure — preserved

Source dd147cae0e85f9e39855d0d130da19e782f7eecb, PR1174, branch steward/parked-period-vehicles-20261021. Three exact current-head normal source/workflow IDs/event routes independently pinned against remote committed workflow bytes and source pricing. GET-only, no workflow rerun/dispatch/cancel/ref/app mutation. No historical2a/0a/e694 green reused.

Actual moving-frames run39709833379, attempt1, job119598265851 TERMINALFAIL02:16:39UTC. Step6 'Walk, turn, fly and ride; hold the flora frame to its ceilings' failed after02:12:27start. Desktop1280x800,1835,LightTURN480frames: flora worst22.7ms > existing21ms. Flora p953.1ms; scriptedmax23.4ms/one>16frame. Full/Balanced and otherLightmovement rows report no additional failure. Exact terminal says1reading over ceiling. A phone keeps the town on the GPU, not twice wasSKIPPED, so it has no qualification at this head.

Actual checkout log74a5e7eec3cbe722a07e10cadff487cadbf343b4, merge dd147 into fdb227dbf5ed952921ef652f5a02480fffdad462; publicationbuild74a5e7ee. Full actual job logSHA631e38d85b98a3b312affaeada44f592271468fc1d21bc99df6a4a6a583a2727, retained under actual-terminal-observer/0017-job-119598265851-log-attempt1.stdout. No causalexception/pagerender error or proof that the timing spike is caused by wagon code is claimed. No threshold change proposed.

Report run39709828775, job119598251738 has actual strict job/mandatory-step/logPASS at dd147/attempt1. Gate39709833378 was stillinprogress when this initial observer stopped on movingFAIL. A distinct GET-only gate continuation is ACTIVE under PID744449/session77497, /workspace/shared/parked-covered-2981-dd147-GATE-CONTINUATION-GET-owner1/, under original02:58:22UTCdeadline. It permanently carries the known movingFAIL and cannot qualifyallnormalsgreen. This archive is a failure checkpoint, NOT its later gate result.

Root remains sole tracked writer/merger and owns any subsequent diagnosis/action. No retry, CI POST, ready, merge or allgreen claim from this agent.
