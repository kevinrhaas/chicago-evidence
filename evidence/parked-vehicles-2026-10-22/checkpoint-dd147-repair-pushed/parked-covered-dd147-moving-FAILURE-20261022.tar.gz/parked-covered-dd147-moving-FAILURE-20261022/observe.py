#!/usr/bin/env python3
"""Finite GET-only exact-head normal CI reader; reuses existing strict job auditor."""
import pathlib,importlib.util,json,subprocess,time,datetime,hashlib,base64,os,re
SHARED=pathlib.Path('/workspace/shared');HELPER=SHARED/'parked-covered-2981-NEXT-HEAD-CI-HELD/observe-GET-only.py'
spec=importlib.util.spec_from_file_location('existing_ci_auditor',HELPER);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
HEAD='dd147cae0e85f9e39855d0d130da19e782f7eecb';TREE='5badfa088cfeb4ff9c86e31a1d2221a09c790db3';PR=1174
BRANCH='steward/parked-period-vehicles-20261021';REPO='kevinrhaas/chicago'
OUT=SHARED/'parked-covered-2981-dd147-NORMAL-GET-owner1';OUT.mkdir(exist_ok=False)
(SHARED/'parked-covered-2981-dd147-NORMAL-GET.lock').mkdir(exist_ok=False)
start=time.monotonic();deadline=start+45*60;counter=0;audited={};last=None
state={'sha':HEAD,'tree':TREE,'repository':REPO,'branch':BRANCH,'pr':PR,'started':h.now(),'observer_pid':os.getpid(),'observer_source_sha256':h.sha(pathlib.Path(__file__).read_bytes()),'reused_auditor':str(HELPER),'reused_auditor_sha256':h.sha(HELPER.read_bytes()),'scope':'GET-only normal gate/moving-frames/report at current head; no smoke/canonical/dispatch/merge qualification','normal_qualification_pass':False,'POSTs':0,'interval_seconds':60,'max_minutes':45}
h.save(OUT/'owner.json',state)
def get(label,endpoint,plain=False):
 global counter
 for attempt in range(1,4):
  h.need(time.monotonic()<deadline,'45minute observer deadline');counter+=1
  stem=OUT/(f'{counter:04d}-{label}-attempt{attempt}')
  r=subprocess.run(['gh','api','--method','GET','repos/'+REPO+'/'+endpoint],text=True,capture_output=True,timeout=min(45,max(1,deadline-time.monotonic())))
  stem.with_suffix('.stdout').write_text(r.stdout);stem.with_suffix('.stderr').write_text(r.stderr)
  transient=not re.search(r'HTTP (?:401|403)\b',r.stderr) and bool(re.search(r'HTTP (?:502|503|504)\b|unexpected EOF|connection reset by peer|transport read',r.stderr,re.I))
  retry=bool(r.returncode and transient and attempt<3)
  with (OUT/'GET-ATTEMPTS.jsonl').open('a') as f:f.write(json.dumps({'at':h.now(),'endpoint':endpoint,'label':label,'attempt':attempt,'returncode':r.returncode,'retry':retry,'retry_seconds':2**attempt if retry else 0,'stdout_sha256':h.sha(r.stdout.encode()),'stderr_sha256':h.sha(r.stderr.encode())})+'\n')
  if retry:time.sleep(2**attempt);continue
  h.need(r.returncode==0,'Actual GET failed: '+label+' '+r.stderr[-1000:]);return r.stdout if plain else json.loads(r.stdout)
def route():
 p=get('pr','pulls/'+str(PR));h.need(p['state']=='open' and p['head']['sha']==HEAD and p['head']['ref']==BRANCH and p['head']['repo']['full_name']==REPO and p['base']['ref']=='dev','PR source/base/head route changed')
 h.need(get('branch','git/ref/heads/'+BRANCH)['object']['sha']==HEAD,'Remote branch changed')
 return {k:p.get(k) for k in ['number','state','draft','mergeable','mergeable_state','updated_at']}
try:
 pricing=json.loads((SHARED/'wagon-fsum-dd147-FINAL-DIFF-PRICING.json').read_text());h.need(pricing['sha']==HEAD and pricing['tree']==TREE and pricing['expected_three_normal'],'Wrong diff pricing')
 expected={(x['path'],x['event']) for x in pricing['predicted_normal_runs']};h.need(expected=={(p,v[0]) for p,v in h.NORMAL.items()},'Normal event/path expectation drift')
 pins={};ids={}
 for path in h.NORMAL:
  local=subprocess.check_output(['git','show',HEAD+':'+path],cwd='/workspace/chicago');pin=h.sha(local)
  prediction=next(x for x in pricing['workflow_trigger_pricing'] if x['workflow_path']==path and x['event']==h.NORMAL[path][0])
  h.need(prediction['workflow_sha256']==pin and prediction['predicted_trigger'] is True,'Pricing/source workflow pin differs')
  remote=get('source-'+pathlib.Path(path).stem,'contents/'+path+'?ref='+HEAD);raw=base64.b64decode(remote['content']);h.need(raw==local,'Remote exact-head workflow differs')
  wf=get('workflow-'+pathlib.Path(path).stem,'actions/workflows/'+pathlib.Path(path).name);h.need(wf['path']==path,'Workflow descriptor path differs');pins[path]=pin;ids[path]=wf['id']
 state['source_workflow_sha256']=pins;state['workflow_ids']=ids;state['pr_state']=route();h.save(OUT/'owner.json',state)
 while time.monotonic()<deadline:
  tick=time.monotonic();listing=get('normal-runs','actions/runs?head_sha='+HEAD+'&per_page=100');runs=listing['workflow_runs'];h.need(listing['total_count']==len(runs),'Incomplete current-head run list')
  h.need(all(r['path'] in h.NORMAL for r in runs),'Unexpected current-head workflow; inspect before qualifying')
  for path in h.NORMAL:h.need(sum(r['path']==path for r in runs)<=1,'Duplicate normal run')
  failures=[]
  for r in runs:
   event,name,steps=h.NORMAL[r['path']]
   h.need(r['head_sha']==HEAD and r['head_branch']==BRANCH and r['run_attempt']==1 and r['event']==event and r['workflow_id']==ids[r['path']],'Run source/event/ref/attempt/workflow identity drift')
   if r['status']!='completed' or str(r['id']) in audited:continue
   jobs=get('jobs-'+str(r['id']),'actions/runs/'+str(r['id'])+'/jobs?per_page=100');h.need(jobs['total_count']==len(jobs['jobs'])==1,'Exactly one actual job required')
   job=jobs['jobs'][0];log=get('job-'+str(job['id'])+'-log','actions/jobs/'+str(job['id'])+'/logs',True);h.need(bool(log.strip()),'Actual completed job log is empty')
   if r['conclusion']!='success':
    failures.append({'run_id':r['id'],'job_id':job['id'],'workflow':r['path'],'conclusion':r['conclusion'],'steps':job['steps'],'job_log_sha256':h.sha(log.encode())});continue
   proof=h.audit_job(job,r,HEAD,name,steps);proof.update(workflow=r['path'],event=event,head_sha=HEAD,head_branch=BRANCH,run_attempt=1,workflow_source_sha256=pins[r['path']],html_url=r['html_url'],job_log_sha256=h.sha(log.encode()),log_bytes=len(log.encode()))
   audited[str(r['id'])]=proof;h.save(OUT/'audited-jobs.json',list(audited.values()))
  state.update(at=h.now(),runs=[{k:r.get(k) for k in ['id','path','event','head_sha','head_branch','run_attempt','status','conclusion','html_url']} for r in runs],audited=list(audited.values()),normal_strict_success=len(audited),api_requests=counter,failures=failures)
  h.save(OUT/'latest.json',state)
  summary=tuple((r['id'],r['status'],r['conclusion']) for r in runs)
  if summary!=last:
   with (OUT/'transitions.jsonl').open('a') as f:f.write(json.dumps(state)+'\n')
   print(json.dumps({'at':state['at'],'normal_strict_success':len(audited),'runs':state['runs'],'failures':failures}),flush=True);last=summary
  h.need(not failures,'Actual current-head normal CI failure; logs and steps preserved')
  if len(runs)==3 and len(audited)==3:
   state['pr_state']=route();state['checks']=get('current-check-runs','commits/'+HEAD+'/check-runs?per_page=100');state['normal_qualification_pass']=True;break
  remaining=min(60-(time.monotonic()-tick),deadline-time.monotonic())
  if remaining>0:time.sleep(remaining)
 h.need(state['normal_qualification_pass'],'45minute deadline without all3 normal jobs qualified')
except Exception as error:state['error']=str(error)
finally:
 state.update(ended=h.now(),elapsed_seconds=time.monotonic()-start,api_requests=counter);h.save(OUT/'latest.json',state);h.save(OUT/'terminal.json',state)
 print(json.dumps({'normal_qualification_pass':state['normal_qualification_pass'],'normal_strict_success':len(audited),'error':state.get('error'),'output':str(OUT)}),flush=True)
raise SystemExit(0 if state['normal_qualification_pass'] else 1)
