from pathlib import Path
import subprocess,json,hashlib,os
P=Path(__file__).parent;R=Path('/tmp/wolf-credit-work-20261103');A=R/'chicago/4d';base='dc54f207878bec2726a56c7bd2297ffb038fb062'
def g(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def run(label,*args):subprocess.run(['python3',str(P/'run_command.py'),label,'90',*args],check=True,cwd=A)
gate=json.loads((P/'FINAL-AUTHORED-SOURCE-GATES.json').read_bytes());assert gate['status']=='ALL_FOUR_PARTS_PASS'
paths=['data/sidecars/1812/sources/uses.json','data/sidecars/1835/sources/index.json','data/sidecars/1835/wolf_point_tavern.json','data/sidecars/1904/sources/uses.json','data/sources/blanchard_shober_1867_wolf_point.json','data/structures/wolf_point_tavern.json','docs/RESEARCH/wolf_point_tavern.md','docs/ROADMAP.md','docs/STATUS.md','docs/measurements/source_use_coverage.md','tools/derived_manifest.json','changelog.d/T-2386.json','data/sidecars/1835/sources/blanchard_davis_c1893_wolfs_point_poster.json','data/sources/blanchard_davis_c1893_wolfs_point_poster.json'];paths=['chicago/4d/'+p for p in paths]
assert g('rev-parse','HEAD')==base and g('rev-parse','origin/dev')==base
assert not g('diff','--cached','--name-only')
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=R,text=True);assert {x[3:]for x in status.splitlines()}==set(paths),status
subprocess.run(['git','add','--',*paths],cwd=R,check=True)
assert set(g('diff','--cached','--name-only').splitlines())==set(paths)
tree=g('write-tree');candidate=subprocess.check_output(['git','commit-tree',tree,'-p',base,'-m','Preflight candidate: credit the Blanchard/Davis Wolf Point poster'],cwd=R,text=True).strip();assert len(candidate)==40
run('authored-preflight-changelog', 'node','tools/check-changelog-entry.mjs',base,candidate)
run('authored-preflight-ticket-ids','node','tools/resolve_id_collisions.mjs','--base','origin/dev','--check')
(P/'AUTHORED-THREE-QUESTIONS.json').write_text(json.dumps({'source_gate':gate,'candidate_tree':tree,'candidate_commit':candidate,'cached_authored_base':base,'latest_public_base_not_yet_available':'PUBLIC-DEV-PRE-AUTHORED-PREFLIGHT.json','fresh_base_integration_pending':True,'native_changelog_question':'authored-preflight-changelog-RESULT.json','native_ticket_ids_question':'authored-preflight-ticket-ids-RESULT.json','source_gate_first_then_candidate_questions_before_branch_commit':True},indent=2)+'\n')
subprocess.run(['git','commit','-m','Credit the Blanchard/Davis Wolf Point poster in Images'],cwd=R,check=True)
head=g('rev-parse','HEAD');assert g('rev-parse','HEAD^{tree}')==tree;assert not g('status','--porcelain','--untracked-files=normal')
run('actual-authored-commit-changelog-question','node','tools/check-changelog-entry.mjs',base,head)
(P/'AUTHORED-COMMIT.json').write_text(json.dumps({'head':head,'tree':tree,'parent':base,'source_gate':'FINAL-AUTHORED-SOURCE-GATES.json','native_preflight':'AUTHORED-THREE-QUESTIONS.json','paths':paths,'clean':True,'source_scope':'partial T2386 source credit, no GLB/renderer/camera changes'},indent=2)+'\n');print(json.dumps({'commit':head,'tree':tree,'paths':len(paths),'all4_source_parts_and_3_questions':'PASS','clean':True}),flush=True)
