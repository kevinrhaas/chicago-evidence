from pathlib import Path
import json,subprocess,hashlib,datetime
P=Path(__file__).parent;R=Path('/tmp/wolf-credit-work-20261103');A=R/'chicago/4d';incoming='ce91e60c6b283e318a4eaad0ce2c40769383ade0';authored='ea0aef7c2a5b3a3d6a17613be263bc52a4f1845e'
def g(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def run(label,*cmd):subprocess.run(['python3',str(P/'run_command.py'),label,'90',*cmd],cwd=A,check=True)
checks=[]
for n in ['liberties','sourceuse','scene','validate','house','count','trade','entrances','yard']:
 f=P/f'integrate-ce91-check-{n}-RESULT.json';r=json.loads(f.read_bytes());assert r['exit']==r['reaper_exit']==0 and r['all_children_reaped']and not r['cleanup'];checks.append({'name':n,'result':f.name,'seconds':r['seconds']})
proj=json.loads((P/'CE91-NATIVE-SOURCEUSE-PROJECTION.json').read_bytes());assert proj['status']=='NATIVE_REPORT_PROJECTION_ALL_NONREPORT_OUTPUTS_EXACT'and proj['owned_manifest_exact']and not proj['report_changed']
assert g('rev-parse','HEAD')==authored and g('rev-parse','MERGE_HEAD')==incoming
for row in json.loads((P/'authored-ready-checkpoint/payload/BASE-GUARDS.json').read_bytes())['rows']:assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['post_sha256'],row['path']
conflicts=json.loads((P/'MERGE-CE91-INITIAL.json').read_bytes())['unmerged'];assert set(g('diff','--name-only','--diff-filter=U').splitlines())==set(conflicts)
subprocess.run(['git','add','--',*conflicts],cwd=R,check=True);assert not g('diff','--name-only','--diff-filter=U');assert not g('diff','--name-only')
expected=set(json.loads((P/'AUTHORED-COMMIT.json').read_bytes())['paths']);changed=set(g('diff','--cached','--name-only',incoming).splitlines());assert changed==expected,(changed-expected,expected-changed)
protected=['chicago/4d/assets','chicago/4d/generators','chicago/4d/renderers','chicago/4d/data/reference_views','chicago/reference/images'];assert not g('diff','--cached','--name-only',incoming,'--',*protected)
tree=g('write-tree');candidate=g('commit-tree',tree,'-p',authored,'-p',incoming,'-m','Preflight candidate: integrate current dev into Wolf source-credit increment')
run('integrated-ce91-preflight-changelog','node','tools/check-changelog-entry.mjs',incoming,candidate)
run('integrated-ce91-preflight-ticketids','node','tools/resolve_id_collisions.mjs','--base','origin/dev','--check')
(P/'CE91-INTEGRATION-NATIVE-PREFLIGHT.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'incoming':incoming,'authored':authored,'tree':tree,'candidate':candidate,'native_sourceuse_projection':proj,'nine_fresh_native_checks':checks,'all_seven_authored_posts_exact_checkpoint':True,'all_incoming_assets_generators_renderers_cameras_photos_exact':True,'owned_difference_paths':sorted(changed),'source_gate_inherited':'FINAL-AUTHORED-SOURCE-GATES.json','stopped_narrow_tail_not_qualification':'integrate-ce91-native-resolve-RESULT.json','integration_only_no_new_authored_source_or_policy_change':True},indent=2)+'\n')
subprocess.run(['git','commit','-m','Merge dev into Wolf poster credit with native source metadata refresh'],cwd=R,check=True)
head=g('rev-parse','HEAD');assert g('rev-parse','HEAD^{tree}')==tree and g('show','-s','--format=%P','HEAD').split()==[authored,incoming];assert not g('status','--porcelain','--untracked-files=normal')
(P/'CE91-INTEGRATED-COMMIT.json').write_text(json.dumps({'head':head,'tree':tree,'parents':[authored,incoming],'clean':True,'native_integration':'CE91-INTEGRATION-NATIVE-PREFLIGHT.json','qualification':'source/authored4 + nativeintegration9/strictprojection; publishedUI/native3 pending GPUlease'},indent=2)+'\n');print(json.dumps({'integrated_head':head,'tree':tree,'all14_only_vs_incoming':True,'clean':True}),flush=True)
run('integrated-ce91-push','git','push','--porcelain','origin','HEAD:refs/heads/steward/wolf-poster-credit-20261103')
