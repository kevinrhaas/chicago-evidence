"""Native report projection, with exact guards on every non-report compiler output.
Prepared independently; do not run while canonical source readers are active.
"""
from pathlib import Path
import argparse,importlib.util,sys,json,hashlib,subprocess,os
sys.dont_write_bytecode=True
R=Path('/tmp/wolf-credit-work-20261103');A=R/'chicago/4d'
ap=argparse.ArgumentParser();ap.add_argument('--head',required=True);ap.add_argument('--proof',type=Path,required=True);ap.add_argument('--write',action='store_true');args=ap.parse_args()
assert not args.proof.exists()
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,env=E,text=True).strip();assert head==args.head
sys.path.insert(0,str(A/'tools'))
spec=importlib.util.spec_from_file_location('native_source_use',A/'tools/compile_source_use.py');native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
c=native.Compiler(A);c.collect();out=c.outputs();report=c.report(out)
dest=A/'data/sidecars/1835/sources';files={dest/name:body for name,body in out.items()}
files.update({A/f'data/sidecars/{scene}/sources/uses.json':body for scene,body in c.scene_outputs(out).items()})
leaf=A/'docs/measurements/source_use_coverage.md'
assert not (set(dest.glob('*.json'))-set(files)),'Extra source outputs require full native ownership resolution'
manifest=json.loads(native.MANIFEST.read_text());missing,extra=native.owned_resolves(manifest,{'chicago/4d/'+str(p.relative_to(A))for p in [*files,leaf]})
assert not missing and not extra,(missing,extra)
rows=[]
for path,body in files.items():
 assert path.read_text()==body,'Non-report output changed; use the native dependency tail: '+str(path)
 rows.append({'path':str(path.relative_to(A)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
before=leaf.read_bytes();after=report.encode();changed=before!=after
proof={'status':'NATIVE_REPORT_PROJECTION_ALL_NONREPORT_OUTPUTS_EXACT','head':head,'compiler_api':'Compiler.collect / outputs / scene_outputs / report','compiler_sha256':hashlib.sha256((A/'tools/compile_source_use.py').read_bytes()).hexdigest(),'leaf':str(leaf.relative_to(A)),'old_sha256':hashlib.sha256(before).hexdigest(),'native_report_sha256':hashlib.sha256(after).hexdigest(),'report_changed':changed,'report_written':bool(args.write and changed),'nonreport_count':len(rows),'nonreport_outputs':rows,'owned_manifest_exact':True,'scope':'Only the native-generated leaf report may change; all published source catalogue and use-map outputs are byte-identical to native compiler results. No runtime input is rewritten. Fresh full native --check is required afterward.'}
if args.write and changed:leaf.write_text(report)
args.proof.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items()if k!='nonreport_outputs'}))
