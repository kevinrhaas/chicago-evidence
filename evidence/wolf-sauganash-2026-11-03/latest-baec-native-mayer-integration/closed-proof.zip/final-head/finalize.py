from pathlib import Path
import os,json,hashlib,subprocess,time
P=Path(__file__).resolve().parent;OLDP=Path('/workspace/wolf-latest92bee-integration-20261103');W=Path('/tmp/wolf-poster-source-20261103');A=W/'chicago/4d';E=os.environ.copy()
for k in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','CHICAGO_TICKETS_DIR']:E.pop(k,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');OLD='cd66c7bf3fd6c7e28c6df6cc6933325f42406df9';TIP='92bee8bdb89a900a840bcd94e760bb8f21c757c2'
def git(*a):return subprocess.check_output(['git','-C',str(W),*a],env=E)
assert not (W/'.git/index.lock').exists();assert git('rev-parse','HEAD').decode().strip()==OLD;assert git('rev-parse','MERGE_HEAD').decode().strip()==TIP;assert not git('diff','--name-only').strip()
before=json.loads((OLDP/'OWNED17-BEFORE.json').read_text());assert all(hashlib.sha256((W/p).read_bytes()).hexdigest()==h for p,h in before.items())
checks=json.loads((OLDP/'OWNERS-CHECKS.json').read_text());assert len(checks)==9 and all(r['exit']==0 for r in checks)
with (P/'native-commit.log').open('wb') as f:r=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(P/'commit-REAPER.json'),'--','timeout','--signal=TERM','--kill-after=15s','600s','git','-C',str(W),'commit','-m','Merge current dev native K01 repair into Wolf picture comparison'],env=E,stdout=f,stderr=subprocess.STDOUT);assert r.returncode==0
head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip();parents=git('show','-s','--format=%P','HEAD').decode().strip().split();assert parents==[OLD,TIP]
receipt={'head':head,'tree':tree,'parents':parents,'all_owned17_postimages_unchanged':True,'actual_validate_all_pass':True,'currentMayerInput':'4554d48e59d1d54071cd4160313618a5d774dbf1ce6a3102718accf36433d997','genuine_upstream_native_reemission':'PR1672','no_manual_hash_or_output_edits':True,'scope':'Documented integration-only native checks; original source4 qualifies authored Wolf, e32 UI qualifies unchanged1835 targets, not newer1904 content.'}
(P/'INTEGRATED-COMMIT.json').write_text(json.dumps(receipt,indent=2)+'\n')
for n,args in [('PR-changelog',['node','tools/check-changelog-entry.mjs','e32abc49306697818ebdf22958ae80afaf5d44d2',head]),('PR-ids',['node','tools/resolve_id_collisions.mjs','--check','--base','e32abc49306697818ebdf22958ae80afaf5d44d2'])]:
 with (P/(n+'.log')).open('wb') as f:r=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(P/(n+'-REAPER.json')),'--','taskset','-c','2','nice','-n','19','timeout','--signal=TERM','--kill-after=15s','600s',*args],cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(n,r.returncode);d=json.loads((P/(n+'-REAPER.json')).read_text());assert d['all_children_reaped'] and not d['leftover_cleanup'];print(n,'PASS',flush=True)
assert not git('status','--porcelain','--untracked-files=no').strip();print('FINALIZED',head,tree,flush=True)
