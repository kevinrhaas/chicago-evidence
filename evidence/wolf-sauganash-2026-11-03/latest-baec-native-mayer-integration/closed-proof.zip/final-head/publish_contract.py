from pathlib import Path
import os,subprocess,json,time
P=Path(__file__).resolve().parent;W=Path('/tmp/wolf-poster-source-20261103');A=W/'chicago/4d';E=os.environ.copy()
for k in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','CHICAGO_TICKETS_DIR']:E.pop(k,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');H='baec9ffa57059a5fa3209cec8f5216731cb574b8';BASE='92bee8bdb89a900a840bcd94e760bb8f21c757c2';rows=[]
for n,args in [('actual-parent-PR-changelog',['node','tools/check-changelog-entry.mjs',BASE,H]),('actual-parent-PR-ids',['node','tools/resolve_id_collisions.mjs','--check','--base',BASE]),('actual-head-publication',['bash','tools/publish.sh']),('actual-head-published-contract',['python','tools/check_published.py'])]:
 t=time.monotonic()
 with (P/(n+'.log')).open('wb') as f:r=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(P/(n+'-REAPER.json')),'--','taskset','-c','2','nice','-n','19','timeout','--signal=TERM','--kill-after=15s','600s',*args],cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
 d=json.loads((P/(n+'-REAPER.json')).read_text());assert r.returncode==0,(n,r.returncode);assert d['all_children_reaped'] and not d['leftover_cleanup'];rows.append({'check':n,'seconds':time.monotonic()-t,'exit':0});print(n,'PASS',flush=True)
(P/'FINAL-PUBLICATION-CHECKS.json').write_text(json.dumps(rows,indent=2)+'\n')
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],env=E).decode().strip()==H;assert not subprocess.check_output(['git','-C',str(W),'status','--porcelain','--untracked-files=no'],env=E).strip()
b=json.loads((W/'site/4d/build.json').read_text());assert b['version'].startswith(H[:7]);print('FINALHEAD PUBLICATION CLOSED',H,b['version'],flush=True)
