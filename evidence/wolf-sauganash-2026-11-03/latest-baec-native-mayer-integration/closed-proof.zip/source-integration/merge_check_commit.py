from pathlib import Path
import subprocess,os,json,hashlib,time
P=Path(__file__).resolve().parent;W=Path('/tmp/wolf-poster-source-20261103');A=W/'chicago/4d';E=os.environ.copy()
for k in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','CHICAGO_TICKETS_DIR']:E.pop(k,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');OLD='cd66c7bf3fd6c7e28c6df6cc6933325f42406df9';TIP='92bee8bdb89a900a840bcd94e760bb8f21c757c2'
def git(*a):return subprocess.check_output(['git','-C',str(W),*a],env=E)
assert git('rev-parse','HEAD').decode().strip()==OLD and not git('status','--porcelain','--untracked-files=no').strip()
C=Path('/tmp/lake-latest92bee-prefetch-20261103');ready=json.loads((C/'READY.json').read_text());assert ready['tip']==TIP and ready['fresh_pack_only_every_raw_object_readback_exact']
obj=Path(git('rev-parse','--git-path','objects').decode().strip());obj=obj if obj.is_absolute() else W/obj
for n,row in ready['pack_files'].items():
 src=Path(row['path']);assert src.stat().st_size==row['bytes'] and hashlib.sha256(src.read_bytes()).hexdigest()==row['sha256']
 dst=obj/'pack'/n;assert not dst.exists();dst.symlink_to(src)
(obj/'pack'/('pack-'+ready['pack']+'.keep')).write_text('Shared immutable authenticated latest92bee cache; preserve backing files.\n')
assert git('rev-parse',TIP+'^{tree}').decode().strip()==ready['tip_tree']
owned=git('diff','--name-only','d9bbfca5aded1b976e33e4331391642f77a39441','355679d98029dd82d620ac7ca181577ee591282c').decode().splitlines()+['.github/workflows/chicago-4d-check.yml','.github/workflows/chicago-4d-bake.yml']
assert len(owned)==17
before={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in owned};(P/'OWNED17-BEFORE.json').write_text(json.dumps(before,indent=2)+'\n')
with (P/'normal-merge.log').open('wb') as f:subprocess.run(['git','-C',str(W),'merge','--no-ff','--no-commit',TIP],env=E,stdout=f,stderr=subprocess.STDOUT,check=True)
assert all(hashlib.sha256((W/p).read_bytes()).hexdigest()==h for p,h in before.items())
checks=[]
def checked(n,args,native_ticket=False):
 env=E.copy()
 if native_ticket:env['CHICAGO_TICKETS_DIR']=str(A/'tickets')
 t=time.monotonic()
 with (P/(n+'.log')).open('wb') as f:r=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(P/(n+'-REAPER.json')),'--','taskset','-c','2','nice','-n','19','timeout','--signal=TERM','--kill-after=15s','600s',*args],cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT)
 d=json.loads((P/(n+'-REAPER.json')).read_text());assert r.returncode==0,(n,r.returncode);assert d['all_children_reaped'] and not d['leftover_cleanup'];checks.append({'name':n,'seconds':time.monotonic()-t,'exit':0});(P/'OWNERS-CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');print(n,'PASS',flush=True)
for n,args in [('pictures',['python','tools/compile_pictures.py']),('scene1835',['python','tools/compile_scene.py','--scene','1835']),('source-use',['python','tools/compile_source_use.py']),('grade',['python','tools/grade_structures.py','--check']),('ACTUAL-VALIDATE-ALL',['python','tools/validate.py','--all']),('wolf-current-eight',['node','tools/image_gate.mjs','--structure','wolf_point_tavern']),('image-bindings-all',['node','tools/image_gate.mjs','--check'])]:checked(n,args)
checked('closing-liveness',['python','tools/ticket_liveness.py','--closing','T-2386'],True)
checked('entry-shape',['node','tools/changelog-entries.mjs','--check'])
assert all(hashlib.sha256((W/p).read_bytes()).hexdigest()==h for p,h in before.items()),'Owned authored/postimages changed unexpectedly'
manifest=json.loads((A/'assets/manifest.json').read_text())['assets'];row=manifest['mayer_house_2009_prairie__as_mapped_1904.glb'];assert row['inputs_sha256']=='4554d48e59d1d54071cd4160313618a5d774dbf1ce6a3102718accf36433d997'
for p,sha in [('assets/gltf/mayer_house_2009_prairie__as_mapped_1904.glb','757d32e65459d1b75821ee4651ed67e4a76b8188bfbd383dd89394e0a600d261'),('assets/web/mayer_house_2009_prairie__as_mapped_1904.glb','f69981e4918c79a66a2f50550f1559cf8d654e9c17620d7857b65de926e1c3cd')]:assert hashlib.sha256((A/p).read_bytes()).hexdigest()==sha
subprocess.run(['git','-C',str(W),'add','-A','--','chicago/4d'],env=E,check=True)
with (P/'integration-commit.log').open('wb') as f:subprocess.run(['git','-C',str(W),'commit','-m','Merge current dev native K01 repair into Wolf picture comparison'],env=E,stdout=f,stderr=subprocess.STDOUT,check=True)
head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip();parents=git('show','-s','--format=%P','HEAD').decode().strip().split();assert parents==[OLD,TIP]
(P/'INTEGRATED-COMMIT.json').write_text(json.dumps({'head':head,'tree':tree,'parents':parents,'all_owned17_postimages_unchanged':True,'actual_validate_all_pass':True,'currentMayerInput':row['inputs_sha256'],'genuine_upstream_native_reemission':'PR1672','no_manual_hash_or_output_edits':True,'scope':'Documented integration-only native checks; old source4 qualifies authored Wolf source, existing e32 UI qualifies unchanged1835 targets, not all newer1904 content.'},indent=2)+'\n')
checked('PR-changelog',['node','tools/check-changelog-entry.mjs','e32abc49306697818ebdf22958ae80afaf5d44d2',head])
checked('PR-ids',['node','tools/resolve_id_collisions.mjs','--check','--base','e32abc49306697818ebdf22958ae80afaf5d44d2'])
assert not git('status','--porcelain','--untracked-files=no').strip();print('INTEGRATION CLOSED',head,tree,flush=True)
