"""Publish the exact normal two-parent native commit to the existing PR feature ref."""
from pathlib import Path
import base64, datetime, hashlib, json, os, re, subprocess
P=Path(__file__).resolve().parent; W=Path('/tmp/wolf-poster-source-20261103')
OLD='baec9ffa57059a5fa3209cec8f5216731cb574b8'; TIP='dacc6364b6e6dce484d197627abbea5244218a0c'
BRANCH='steward/t2386-wolf-poster-current-20261103'
E=os.environ.copy()
for key in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']:E.pop(key,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*args):return subprocess.check_output(['git','-C',str(W),*args],env=E)
def api(path,body=None,method=None):
    command=['gh','api','repos/kevinrhaas/chicago/'+path]
    if body is not None:command+=['--method',method or 'POST','--input','-']
    result=subprocess.run(command,input=None if body is None else json.dumps(body).encode(),capture_output=True)
    if result.returncode:raise RuntimeError((path,result.stderr.decode()[:1500]))
    return json.loads(result.stdout)
receipt=json.loads((P/'INTEGRATED-COMMIT.json').read_bytes()); H=receipt['head']; TREE=receipt['tree']
assert receipt['parents']==[OLD,TIP] and receipt['actual_validate_all_pass']
for name in ['PR-changelog','PR-ids']:
    row=json.loads((P/(name+'-REAPER.json')).read_bytes()); assert row['command_exit']==0 and row['all_children_reaped'] and not row['leftover_cleanup']
assert git('rev-parse','HEAD').decode().strip()==H and not git('status','--porcelain','--untracked-files=normal').strip()
raw=git('cat-file','commit',H); assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==H
header,message=raw.split(b'\n\n',1); lines=header.decode().splitlines()
fields={};parents=[]
for line in lines:
    key,value=line.split(' ',1)
    if key=='parent':parents.append(value)
    else:assert key not in fields;fields[key]=value
assert parents==[OLD,TIP] and set(fields)=={'tree','author','committer'} and fields['tree']==TREE
def identity(text):
    m=re.fullmatch(r'(.*) <([^<>]+)> (\d+) ([+-])(\d{2})(\d{2})',text);assert m
    minutes=(int(m[5])*60+int(m[6]))*(1 if m[4]=='+' else -1)
    return {'name':m[1],'email':m[2],'date':datetime.datetime.fromtimestamp(int(m[3]),datetime.timezone(datetime.timedelta(minutes=minutes))).isoformat()}
assert api('git/ref/heads/'+BRANCH)['object']['sha']==OLD
packet=P/'packet'; packet.mkdir(); (packet/'blobs').mkdir();(packet/'commit.raw').write_bytes(raw)
entries=[];blobs=[]
names=git('diff','--name-only',TIP,H).decode().splitlines()
assert names and all(p.startswith('chicago/4d/')or p in ['.github/workflows/chicago-4d-check.yml','.github/workflows/chicago-4d-bake.yml'] for p in names)
for index,path in enumerate(names):
    data=git('show',H+':'+path);oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    row=git('ls-tree',H,'--',path).decode().split();assert row[:2]==['100644','blob'] and row[2]==oid
    back=api('git/blobs',{'encoding':'base64','content':base64.b64encode(data).decode()});assert back['sha']==oid
    assert base64.b64decode(api('git/blobs/'+oid)['content'])==data
    (packet/'blobs'/str(index)).write_bytes(data)
    entries.append({'path':path,'mode':'100644','type':'blob','sha':oid})
    blobs.append({'path':path,'mode':'100644','git_blob':oid,'body':'blobs/'+str(index),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    print('Exact server postimage',path,flush=True)
base_tree=git('rev-parse',TIP+'^{tree}').decode().strip()
tree=api('git/trees',{'base_tree':base_tree,'tree':entries});assert tree['sha']==TREE
commit=api('git/commits',{'tree':TREE,'parents':parents,'message':message.decode(),'author':identity(fields['author']),'committer':identity(fields['committer'])});assert commit['sha']==H
back=api('git/commits/'+H);assert back['tree']['sha']==TREE and [r['sha']for r in back['parents']]==parents
assert api('git/ref/heads/'+BRANCH)['object']['sha']==OLD
updated=api('git/refs/heads/'+BRANCH,{'sha':H,'force':False},'PATCH');assert updated['object']['sha']==H
assert api('git/ref/heads/'+BRANCH)['object']['sha']==H
proof={'head':H,'tree':TREE,'parents':parents,'branch':BRANCH,'expected_old':OLD,'base_tree':base_tree,'normal_force_false_fast_forward':True,'exact_native_commit_tree_and_all_blob_readbacks':True,'no_dev_main_write':True,'blobs':blobs}
(P/'PUBLIC-PUSH.json').write_text(json.dumps(proof,indent=2)+'\n');(packet/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n')
print('PUBLIC NORMAL FEATURE FF CLOSED',H,flush=True)
