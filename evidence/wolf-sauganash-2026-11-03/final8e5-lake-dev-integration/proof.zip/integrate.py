from pathlib import Path
import hashlib, json, os, subprocess, time

P=Path(__file__).resolve().parent
W=Path('/tmp/wolf-poster-source-20261103'); A=W/'chicago/4d'
OLD='baec9ffa57059a5fa3209cec8f5216731cb574b8'
BASE='92bee8bdb89a900a840bcd94e760bb8f21c757c2'
TIP='dacc6364b6e6dce484d197627abbea5244218a0c'
C=Path('/tmp/lake-merged-dacc-prefetch-20261103')
E=os.environ.copy()
for k in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','CHICAGO_TICKETS_DIR']:E.pop(k,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(W),*args],env=E)
def dump(name,d):(P/name).write_text(json.dumps(d,indent=2)+'\n')
assert git('rev-parse','HEAD').decode().strip()==OLD
assert not git('status','--porcelain','--untracked-files=normal').strip()
ready=json.loads((C/'READY.json').read_bytes())
assert ready['base']==BASE and ready['tip']==TIP and ready['fresh_pack_only_every_raw_object_readback_exact']
obj=W/Path(git('rev-parse','--git-path','objects').decode().strip())
for name,row in ready['pack_files'].items():
    source=Path(row['path']); assert source.stat().st_size==row['bytes'] and sha(source.read_bytes())==row['sha256']
    dest=obj/'pack'/name
    assert not dest.exists(); dest.symlink_to(source)
(obj/'pack'/('pack-'+ready['pack']+'.keep')).write_text('Immutable verified Lake merged dacc cache; preserve backing files.\n')
assert git('rev-parse',TIP+'^{tree}').decode().strip()==ready['tip_tree']
owned=json.loads(Path('/workspace/wolf-latest92bee-integration-20261103/OWNED17-BEFORE.json').read_bytes())
assert len(owned)==17 and all(sha((W/p).read_bytes())==h for p,h in owned.items())
dump('OWNED17-BEFORE.json',owned)
docs=['chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md']
resolved={}; proof={}
for path in docs:
    base=git('show',BASE+':'+path); ours=git('show',OLD+':'+path); theirs=git('show',TIP+':'+path)
    assert ours.startswith(base) and theirs.startswith(base),(path,'not independent byte append')
    assert ours[len(base):] and theirs[len(base):]
    combined=theirs+ours[len(base):]
    resolved[path]=combined
    proof[path]={'base_bytes':len(base),'base_sha256':sha(base),'ours_suffix_bytes':len(ours)-len(base),'ours_suffix_sha256':sha(ours[len(base):]),'theirs_whole_bytes':len(theirs),'theirs_whole_sha256':sha(theirs),'resolved_bytes':len(combined),'resolved_sha256':sha(combined),'theirs_whole_preserved_exact_prefix':True,'own_original_suffix_preserved_exact':True,'no_text_decoding_or_replacement':True}
dump('DOC-APPEND-RESOLUTION.json',proof)
with (P/'normal-merge.log').open('xb') as log:
    merge=subprocess.run(['git','-C',str(W),'merge','--no-ff','--no-commit',TIP],env=E,stdout=log,stderr=subprocess.STDOUT)
conflicts=git('diff','--name-only','--diff-filter=U').decode().splitlines()
assert merge.returncode in (0,1) and set(conflicts)<=set(docs),(merge.returncode,conflicts)
assert git('rev-parse','MERGE_HEAD').decode().strip()==TIP
for path,data in resolved.items():
    (W/path).write_bytes(data)
    oid=git('hash-object','--',path).decode().strip()
    exists=subprocess.run(['git','-C',str(W),'cat-file','-e',oid],env=E,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
    if not exists:assert git('hash-object','-w','--',path).decode().strip()==oid
    subprocess.run(['git','-C',str(W),'update-index','--add','--cacheinfo','100644,'+oid+','+path],env=E,check=True)
assert not git('diff','--name-only','--diff-filter=U').strip()
assert not git('diff','--name-only').strip()
assert all(sha((W/p).read_bytes())==h for p,h in owned.items() if p not in docs)
dump('NORMAL-MERGE-CLOSED.json',{'old':OLD,'incoming':TIP,'returncode':merge.returncode,'expected_doc_conflicts':conflicts,'resolved_byte_appends':proof,'own_other15_exact':True,'no_broad_git_add':True})
print('Normal dacc merge and byte-preserving append resolution CLOSED',flush=True)

checks=[]
def check(name,args,tickets=False):
    env=E.copy()
    if tickets:env['CHICAGO_TICKETS_DIR']=str(A/'tickets')
    t=time.monotonic()
    with (P/(name+'.log')).open('xb') as log:
        result=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(P/(name+'-REAPER.json')),'--','taskset','-c','2','nice','-n','19','timeout','--signal=TERM','--kill-after=15s','600s',*args],cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT)
    receipt=json.loads((P/(name+'-REAPER.json')).read_bytes())
    assert result.returncode==receipt['command_exit']==0 and receipt['all_children_reaped'] and not receipt['leftover_cleanup'] and receipt['interrupted_signal'] is None,(name,result.returncode,receipt)
    checks.append({'name':name,'seconds':time.monotonic()-t,'exit':0}); dump('OWNERS-CHECKS.json',checks)
    print(name,'PASS',flush=True)
for name,args in [('pictures',['python','tools/compile_pictures.py']),('scene1835',['python','tools/compile_scene.py','--scene','1835']),('source-use',['python','tools/compile_source_use.py']),('grade',['python','tools/grade_structures.py','--check']),('ACTUAL-VALIDATE-ALL',['python','tools/validate.py','--all']),('wolf-current-eight',['node','tools/image_gate.mjs','--structure','wolf_point_tavern']),('image-bindings-all',['node','tools/image_gate.mjs','--check'])]:check(name,args)
check('closing-liveness',['python','tools/ticket_liveness.py','--closing','T-2386'],True)
check('entry-shape',['node','tools/changelog-entries.mjs','--check'])
assert not git('diff','--name-only').strip(),'Owner changed a derived output: native resolution required before commit'
assert all(sha((W/p).read_bytes())==h for p,h in owned.items() if p not in docs)
assert all((W/path).read_bytes()==data for path,data in resolved.items())
assert git('rev-parse',OLD+':chicago/4d/assets/manifest.json')==git('rev-parse',':chicago/4d/assets/manifest.json')
assert git('rev-parse',OLD+':chicago/4d/assets/manifest.web.json')==git('rev-parse',':chicago/4d/assets/manifest.web.json')
dump('PRECOMMIT-CLOSED.json',{'old':OLD,'incoming':TIP,'own_other15_exact':True,'both_doc_appends_preserved_exact':True,'actual_validate_all_pass':True,'all_asset_registries_exact_old':True,'checks':checks,'qualification':'Integration-only owner checks over unchanged already-gated authored Wolf source and actual qualified e32 Wolf UI; no new whole-four or new browser claim. Final current-head hosted full gate required before dev merge.'})
check('native-commit',['git','-C',str(W),'commit','-m','Merge Lake House dev increment into Wolf picture signoff'])
head=git('rev-parse','HEAD').decode().strip(); tree=git('rev-parse','HEAD^{tree}').decode().strip()
parents=git('show','-s','--format=%P','HEAD').decode().strip().split(); assert parents==[OLD,TIP]
dump('INTEGRATED-COMMIT.json',{'head':head,'tree':tree,'parents':parents,'actual_validate_all_pass':True,'own_other15_exact':True,'both_doc_appends_preserved_exact':True,'checks':checks})
check('PR-changelog',['node','tools/check-changelog-entry.mjs',TIP,head])
check('PR-ids',['node','tools/resolve_id_collisions.mjs','--check','--base',TIP])
assert not git('status','--porcelain','--untracked-files=normal').strip()
print('NORMAL INTEGRATION FINALIZED',head,tree,flush=True)
