from pathlib import Path
import hashlib, json, os, subprocess, time
P=Path(__file__).resolve().parent; W=Path('/tmp/wolf-poster-source-20261103'); A=W/'chicago/4d'; S=W/'site/4d'
OLD='baec9ffa57059a5fa3209cec8f5216731cb574b8'
H=json.loads((P/'INTEGRATED-COMMIT.json').read_bytes())['head']
E=os.environ.copy()
for key in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','CHICAGO_TICKETS_DIR']:E.pop(key,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def git(*args):return subprocess.check_output(['git','-C',str(W),*args],env=E)
def reader():
    code="import fs from'node:fs';import{pathToFileURL}from'node:url';const r=process.argv[1];const{readerCopy}=await import(pathToFileURL(r+'/walk/js/reader-text.js'));console.log(JSON.stringify(readerCopy(JSON.parse(fs.readFileSync(r+'/data/sidecars/1835/wolf_point_tavern.json')),JSON.parse(fs.readFileSync(r+'/data/reader/structures_1835.json')))));"
    return json.loads(subprocess.check_output(['node','--input-type=module','-e',code,str(S)],env=E))
assert git('rev-parse','HEAD').decode().strip()==H and not git('status','--porcelain','--untracked-files=normal').strip()
assert json.loads((S/'build.json').read_bytes())['version'].startswith(OLD[:7])
before={'native_reader':reader(),'picture_rows':json.loads((S/'data/pictures/1835.json').read_bytes())['by_structure']['wolf_point_tavern'],'published_sidecar_sha256':hashlib.sha256((S/'data/sidecars/1835/wolf_point_tavern.json').read_bytes()).hexdigest()}
(P/'OLD-BAEC-PUBLISHED-WOLF-READER-CARD.json').write_text(json.dumps(before,indent=2)+'\n')
checks=[]
for name,args in [('actual-head-publication',['bash','tools/publish.sh']),('actual-head-published-contract',['node','tools/check_published.mjs'])]:
    t=time.monotonic()
    with (P/(name+'.log')).open('xb')as log:
        result=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(P/(name+'-REAPER.json')),'--','taskset','-c','2','nice','-n','19','timeout','--signal=TERM','--kill-after=15s','600s',*args],cwd=A,env=E,stdout=log,stderr=subprocess.STDOUT)
    row=json.loads((P/(name+'-REAPER.json')).read_bytes()); assert result.returncode==row['command_exit']==0 and row['all_children_reaped'] and not row['leftover_cleanup'] and row['interrupted_signal'] is None,(name,result.returncode,row)
    checks.append({'name':name,'seconds':time.monotonic()-t,'exit':0});(P/'PUBLICATION-CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');print(name,'PASS',flush=True)
assert json.loads((S/'build.json').read_bytes())['version'].startswith(H[:7])
after={'native_reader':reader(),'picture_rows':json.loads((S/'data/pictures/1835.json').read_bytes())['by_structure']['wolf_point_tavern'],'published_sidecar_sha256':hashlib.sha256((S/'data/sidecars/1835/wolf_point_tavern.json').read_bytes()).hexdigest()}
assert before==after,'Wolf current native reader/card/sidecar changed'
identical={}
for path in ['chicago/4d/data/reference_views/wolf_point_tavern','chicago/4d/data/sidecars/1835/wolf_point_tavern.json','chicago/4d/assets/gltf/wolf_point_tavern__log_frame_1828.glb','chicago/4d/assets/web/wolf_point_tavern__log_frame_1828.glb']:
    assert git('rev-parse',OLD+':'+path)==git('rev-parse',H+':'+path);identical[path]=True
runtime=git('diff','--name-only',OLD,H,'--','chicago/4d/renderers/web').decode().splitlines();assert not runtime,runtime
changes1835=git('diff','--name-only',OLD,H,'--','chicago/4d/data/sidecars/1835').decode().splitlines()
proof={'head':H,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'comparison_head':OLD,'wolf_model_reference_sidecar_identity':identical,'runtime_changed_paths':runtime,'native_published_Wolf_reader_card_sidecar_exact':True,'wolf_images_count':len(after['picture_rows']),'legitimate_other_1835_sidecar_changed_paths':changes1835,'checks':checks,'scope':'Existing exact-e32 actual Wolf desktop/phone and107native assertions each apply to unchanged Wolf model/reference/sidecar/runtime/card/native-reader. This is no new browser run and no unchanged-all1835-subtree claim; Lake House legitimately has its new credited later-state source and card.'}
(P/'FINAL-TARGET-QUALIFICATION.json').write_text(json.dumps(proof,indent=2)+'\n')
assert not git('status','--porcelain','--untracked-files=normal').strip()
print('Actual current-head publish/contract and Wolf target identity CLOSED',H,flush=True)
