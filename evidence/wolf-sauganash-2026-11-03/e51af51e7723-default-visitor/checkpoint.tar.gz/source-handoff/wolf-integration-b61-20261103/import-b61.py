from pathlib import Path,PurePosixPath
import os,json,hashlib,zlib,subprocess,base64,datetime,time,concurrent.futures
from urllib.request import Request,urlopen
R=Path('/workspace/chicago-bridge-increment-20261102');O=Path('/workspace/wolf-integration-b61-20261103');T=Path('/tmp/wolf-b61-safe-objects');T.mkdir(exist_ok=True);(T/'pack').mkdir(exist_ok=True);BASE='eaeff876666fa231e7a619f5c4939b10d754a58d';TIP='b61c3ffc783e46c3b2aae9944954344e6483fff6';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');API='https://api.github.com/repos/kevinrhaas/chicago/'
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def api(p):
 with urlopen(Request(API+p,headers={'User-Agent':'Chicago-native-integration-object-import','Accept':'application/vnd.github+json'}),timeout=60)as r:return json.load(r)
def git(*args,input=None,env=E):return subprocess.check_output(['git',*args],cwd=R,env=env,input=input)
def object_oid(kind,data):return hashlib.sha1(kind.encode()+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()
rows=[]
def store(oid,kind,data):
 assert object_oid(kind,data)==oid,(oid,kind)
 p=T/oid[:2]/oid[2:];p.parent.mkdir(exist_ok=True)
 if not p.exists():p.write_bytes(zlib.compress(kind.encode()+b' '+str(len(data)).encode()+b'\0'+data))
 rows.append({'sha':oid,'type':kind,'bytes':len(data)})
def commit_raw(c):
 v=c['verification'];candidates=[]
 if v.get('payload'):
  payload=v['payload'].encode();sig=v.get('signature')
  if sig:
   for s in [sig,sig.rstrip('\n')]:
    h,b=payload.split(b'\n\n',1);candidates.append(h+b'\ngpgsig '+s.encode().replace(b'\n',b'\n ')+b'\n\n'+b)
  else:candidates.append(payload)
 else:
  def person(p):
   dt=datetime.datetime.fromisoformat(p['date'].replace('Z','+00:00'));return f"{p['name']} <{p['email']}> {int(dt.timestamp())} +0000"
  h='tree '+c['tree']['sha']+'\n'+''.join('parent '+p['sha']+'\n'for p in c['parents'])+'author '+person(c['author'])+'\ncommitter '+person(c['committer'])+'\n\n'
  for msg in [c['message'],c['message']+'\n']:candidates.append((h+msg).encode())
 for b in candidates:
  if object_oid('commit',b)==c['sha']:return b
 raise AssertionError('Commit canonical bytes not reconstructible with verified public metadata: '+c['sha'])
start=time.monotonic();before_head=git('rev-parse','HEAD').decode().strip();before_index=hashlib.sha256((R/'.git/index').read_bytes()).hexdigest();compare=api('compare/'+BASE+'...'+TIP);save('INCOMING-COMPARE.json',compare);assert compare['ahead_by']==2
commits={c['sha']:api('git/commits/'+c['sha'])for c in compare['commits']}
for oid,c in commits.items():save(oid+'.commit.json',c);store(oid,'commit',commit_raw(c))
root=commits[TIP]['tree']['sha'];tree=api('git/trees/'+root+'?recursive=1');assert not tree.get('truncated');save('INCOMING-TREE.json',tree)
expected={'':root};children={}
for e in tree['tree']:
 p=PurePosixPath(e['path']);d=''if str(p.parent)=='.'else str(p.parent);children.setdefault(d,[]).append(e)
 if e['type']=='tree':expected[e['path']]=e['sha']
all_ids=list(expected.values())+[r['sha']for r in compare['files']if r['status']!='removed'];q=git('cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(all_ids)+'\n').encode()).decode();missing={line.split()[0]for line in q.splitlines()if line.endswith(' missing')}
for d,oid in expected.items():
 if oid not in missing:continue
 es=sorted(children.get(d,[]),key=lambda e:PurePosixPath(e['path']).name.encode()+(b'/'if e['type']=='tree'else b'\0'))
 b=b''.join(e['mode'].lstrip('0').encode()+b' '+PurePosixPath(e['path']).name.encode()+b'\0'+bytes.fromhex(e['sha'])for e in es);store(oid,'tree',b)
blobs=[r for r in compare['files']if r['status']!='removed'and r['sha']in missing]
def download(r):
 x=api('git/blobs/'+r['sha']);assert x['encoding']=='base64'and x['size']<=32*1024**2;b=base64.b64decode(x['content']);assert len(b)==x['size'];return r['sha'],b
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for oid,b in pool.map(download,blobs):store(oid,'blob',b)
assert sum(r['bytes']for r in rows)<=128*1024**2
ids=sorted({r['sha']for r in rows});env=dict(E,GIT_OBJECT_DIRECTORY=str(T),GIT_ALTERNATE_OBJECT_DIRECTORIES=str(R/'.git/objects'));pack=T/'pack/temp.pack'
with pack.open('xb')as f:subprocess.run(['git','pack-objects','--stdout','--compression=1','--no-reuse-delta','--no-reuse-object','--window=0','--depth=0'],cwd=R,env=env,input=('\n'.join(ids)+'\n').encode(),stdout=f,check=True)
ix=T/'pack/temp.idx';pid=git('index-pack','-o',str(ix),str(pack),env=env).decode().strip();dest=T/'pack'/('pack-'+pid+'.pack');ind=dest.with_suffix('.idx');pack.rename(dest);ix.rename(ind)
for p in [dest,ind]:(R/'.git/objects/pack'/p.name).symlink_to(p)
(R/'.git/objects/pack'/(dest.stem+'.keep')).write_text('Bounded verified b61 incoming objects, ordinary TMP backing.\n')
assert git('rev-parse',TIP+'^{tree}').decode().strip()==root
assert git('rev-parse','HEAD').decode().strip()==before_head and hashlib.sha256((R/'.git/index').read_bytes()).hexdigest()==before_index
remote=api('git/ref/heads/dev')['object']['sha'];cached=git('rev-parse','origin/dev').decode().strip();cas=remote==TIP and cached==BASE
if cas:subprocess.run(['git','update-ref','refs/remotes/origin/dev',TIP,BASE],cwd=R,env=E,check=True)
result={'status':'B61_INCOMING_OBJECTS_SHA_VERIFIED_TMP_CACHED','tip':TIP,'remote_tip_at_close':remote,'cached_origin_cas':cas,'objects':len(rows),'blobs':len(blobs),'canonical_bytes':sum(r['bytes']for r in rows),'safe_pack':str(dest),'safe_pack_bytes':dest.stat().st_size,'seconds':time.monotonic()-start,'head_and_index_unchanged':True};save('OBJECTS-SAFE-READY.json',result);print(json.dumps(result),flush=True)
