from pathlib import Path
import os, subprocess, json, time, sys

OUT = Path('/workspace/wolf-integration-eae-20261103')
assert len(sys.argv) > 4 and sys.argv[3] == '--'
label, cwd = sys.argv[1:3]
command = sys.argv[4:]
assert label.replace('-', '').replace('_', '').isalnum()
log = OUT / (label + '.log')
reaper = OUT / (label + '.REAPER.json')
assert not log.exists() and not reaper.exists()
env = dict(os.environ, TMPDIR='/tmp/bg1102', TMP='/tmp/bg1102', TEMP='/tmp/bg1102', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', GIT_NO_LAZY_FETCH='1', PYTHONDONTWRITEBYTECODE='1')
cmd = ['python3', '/workspace/shared/run-with-reaping.py', str(reaper), '--', 'timeout', '--signal=TERM', '--kill-after=15s', '600s', 'nice', '-n', '19', 'taskset', '-c', '0,1,3,4', *command]
t = time.monotonic()
with log.open('xb') as stream:
    ret = subprocess.run(cmd, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT)
receipt = json.loads(reaper.read_bytes())
row = {'label': label, 'command': command, 'exit': ret.returncode, 'seconds': time.monotonic() - t, 'log': str(log), 'reaper': receipt}
(OUT / (label + '.RESULT.json')).write_text(json.dumps(row, indent=2) + '\n')
print(json.dumps({k: row[k] for k in ['label', 'exit', 'seconds', 'log']}), flush=True)
assert ret.returncode == receipt['command_exit'] == 0 and receipt['all_children_reaped'] and not receipt['leftover_cleanup'] and receipt['interrupted_signal'] is None, row
