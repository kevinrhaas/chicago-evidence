from pathlib import Path
import os,sys,json,time,subprocess,hashlib,gzip,io,zipfile,xml.etree.ElementTree as ET,concurrent.futures
R=Path('/workspace/chicago-bridge-increment-20261102');A=R/'chicago/4d';O=Path('/workspace/wolf-integration-eae-20261103');BASE='eaeff876666fa231e7a619f5c4939b10d754a58d';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env=E)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
p=O/'native-source-tail-resolve.RESULT.json';deadline=time.monotonic()+180
while not p.exists():
 assert time.monotonic()<deadline,'Existing resolver controller has not closed';time.sleep(2)
x=json.loads(p.read_bytes());rr=x['reaper'];assert x['exit']==rr['command_exit']==0 and rr['all_children_reaped']and not rr['leftover_cleanup'],x
assert 'the last one moved nothing' in Path(x['log']).read_text(),x
assert git('rev-parse','MERGE_HEAD').decode().strip()==BASE
proof=[];keep=O/'native-format-products';keep.mkdir(exist_ok=True)
paths=['chicago/reference/resident-research/final/audit/resident_audit_master.xlsx','chicago/4d/data/research/research_spend_ledger.json.gz','chicago/4d/data/research/convergence_coverage.json.gz','chicago/4d/data/research/location_reconciliation.json.gz']
def xml(node):return (node.tag,tuple(sorted(node.attrib.items())),node.text,node.tail,tuple(xml(c)for c in node))
for rel in paths:
 q=R/rel;native=q.read_bytes();dev=git('show',BASE+':'+rel)
 if native==dev:proof.append({'path':rel,'already_exact_dev':True});continue
 equivalent=False;detail={}
 if rel.endswith('.xlsx'):
  with zipfile.ZipFile(io.BytesIO(native))as n,zipfile.ZipFile(io.BytesIO(dev))as d:
   assert set(n.namelist())==set(d.namelist());parts=[]
   for name in sorted(n.namelist()):
    l=n.read(name);r=d.read(name)
    try:equal=xml(ET.fromstring(l))==xml(ET.fromstring(r))
    except ET.ParseError:equal=l==r
    parts.append({'member':name,'exact_tree_or_raw':equal})
   equivalent=all(v['exact_tree_or_raw']for v in parts);detail['parts']=parts
 elif rel.endswith('.gz'):equivalent=gzip.decompress(native)==gzip.decompress(dev)
 if equivalent:
  dst=keep/q.name;dst.write_bytes(native);subprocess.run(['git','restore','--source',BASE,'--staged','--worktree','--',rel],cwd=R,env=E,check=True)
  assert q.read_bytes()==dev
  proof.append({'path':rel,'equivalent_format_only':True,'native_preserved':str(dst),'native_sha256':sha(native),'dev_sha256':sha(dev),**detail})
 else:proof.append({'path':rel,'native_semantic_change_retained':True,'native_sha256':sha(native),'dev_sha256':sha(dev),**detail})
save('FORMAT-ONLY-CLEANUP-PASS.json',proof)
assert not git('diff','--name-only','--diff-filter=U').strip()
commands=[('native-scene-check',['python3','tools/compile_scene.py','--all','--check']),('native-liberties-check',['python3','tools/compile_liberties.py','--check']),('native-source-use-check',['python3','tools/compile_source_use.py','--check']),('native-dataset-assets-check',['python3','tools/validate.py','--all']),('native-web-assets-check',['python3','tools/measure_web_derivatives.py','--gate','--quiet']),('native-modeltown-check',['python3','tools/model_town_1835.py','--check']),('native-image-bindings-check',['node','tools/image_gate.mjs','--structure','wolf_point_tavern','philo_carpenter_log_shop']),('format-cleanup-resident-check',['python3','tools/export_resident_audit.py','--check']),('format-cleanup-ledger-check',['python3','tools/measure_research_spend.py','--check'])]
def run(item):
 label,cmd=item;ret=subprocess.run(['python3',str(O/'run-command.py'),label,str(A),'--',*cmd],env=E,cwd=R);assert ret.returncode==0,label;return json.loads((O/(label+'.RESULT.json')).read_bytes())
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:rows=list(pool.map(run,commands))
save('TARGETED-NATIVE-ALL-PASS.json',{'status':'INTEGRATION_ONLY_NATIVE_OWNERS_ASSETS_IMAGES_AND_FORMAT_CHECKS_PASS','full_local_four_parts_rerun_on_lap':False,'fresh_both_viewport_UI_and_native_card_runs_required':True,'final_head_CI_required_before_merge':True,'rows':rows})
print('Existing owner closed; format proof and all nine focused checks PASS.',flush=True)
