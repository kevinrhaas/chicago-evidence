# Fresh actual runtime qualification after the transport/memory integration

Prepared, NOT RUN. No final plan exists. Wait for the exact final source/commit/publish writer freeze. Then run the official read-only defer_household_notes.mjs --check with a fresh reaper/log in this folder, prepare a new plan at /workspace/combined-wolf-saug-plan-eae-20261103.json, and let root release it after verifying the final head.

This reuses the previously passed combined Wolf/Sauganash actual driver and all of its unchanged assertions. The one intentional driver change removes keep-geometry=1 from the page URL, so the incoming memory-release lifecycle runs as it does for visitors. No renderer, shader, native assertion, application flag or source file is patched. Both desktop and phone actual views run before the separate unmodified native card stage3 regression.

Output: /workspace/combined-wolf-saug-both-actual-eae-20261103. Scratch: /tmp/combinedwseae1103. Source: /workspace/chicago-bridge-increment-20261102. Actual prior evidence remains under the immutable1855 prefix and must not be claimed for the changed core runtime.
