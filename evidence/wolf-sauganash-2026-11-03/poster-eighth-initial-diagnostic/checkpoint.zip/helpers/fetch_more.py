from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import quote
import json,base64,hashlib
Q=Path(__file__).parent;H='0e838b35b5ba32b61ccd01499310520e160ab4a2';manifest=json.loads((Q/'IMMUTABLE-INPUTS.json').read_text());rows=manifest['rows']
def get(rel):
 u='https://api.github.com/repos/kevinrhaas/chicago/contents/'+quote(rel,safe='/')+'?ref='+H
 with urlopen(Request(u,headers={'User-Agent':'Chicago-isolated-source-proposal','Accept':'application/vnd.github+json'}),timeout=20)as r:d=json.load(r)
 if isinstance(d,list):return d
 b=base64.b64decode(d['content']);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==d['sha'];p=Q/'immutable0e'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);rows.append({'path':rel,'git_blob':d['sha'],'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)});return b
paths=['chicago/reference/images/chicago','chicago/prairie_1904_v1/data/images.json','chicago/4d/docs/RESEARCH/wolf_point_tavern.md','chicago/4d/data/sources/blanchard_shober_1867_wolf_point.json','chicago/4d/data/reference_views/wolf_point_tavern/nypl-1867.json','chicago/4d/tools/photo_match.mjs','chicago/4d/tools/photo_match_group.mjs','chicago/4d/tools/photo_match_enclosures.mjs','chicago/4d/tools/photo_match_flora.mjs','chicago/4d/renderers/web/js/keith-stone.js','chicago/4d/assets/gltf/wolf_point_tavern__log_frame_1828.glb']
for rel in paths:
 try:
  d=get(rel)
  if isinstance(d,list):print(rel,[x['name']for x in d if any(t in x['name']for t in ['wolf','herriott'])]);(Q/'reference-image-listing.json').write_text(json.dumps(d,indent=2)+'\n')
  else:print(rel,len(d),flush=True)
 except Exception as e:print(rel,type(e).__name__,str(e)[:120],flush=True)
manifest['rows']=rows;(Q/'IMMUTABLE-INPUTS.json').write_text(json.dumps(manifest,indent=2)+'\n')
