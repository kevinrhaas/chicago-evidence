from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import quote
import json,base64,hashlib
Q=Path(__file__).parent;H='0e838b35b5ba32b61ccd01499310520e160ab4a2';m=json.loads((Q/'IMMUTABLE-INPUTS.json').read_text());rows=m['rows']
for rel in ['chicago/reference/images/chicago/chicago_wolf_tavern_miller_house_1832.jpg','chicago/reference/images/chicago/chicago_river_wolf_point_1833.jpg','chicago/reference/images/IMAGE_SOURCES.md','chicago/prairie_1904_v1/data/images.json']:
 try:
  u='https://api.github.com/repos/kevinrhaas/chicago/contents/'+quote(rel,safe='/')+'?ref='+H
  with urlopen(Request(u,headers={'User-Agent':'Chicago-isolated-source-proposal','Accept':'application/vnd.github+json'}),timeout=20)as r:d=json.load(r)
  if d.get('encoding')=='base64':b=base64.b64decode(d['content'])
  else:
   with urlopen(Request(d['download_url'],headers={'User-Agent':'Chicago-isolated-source-proposal'}),timeout=20)as r:b=r.read()
  assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==d['sha'];p=Q/'immutable0e'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);rows.append({'path':rel,'git_blob':d['sha'],'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)});print(rel,len(b),rows[-1]['sha256'],flush=True)
 except Exception as e:print(rel,type(e).__name__,str(e)[:120],flush=True)
m['rows']=rows;(Q/'IMMUTABLE-INPUTS.json').write_text(json.dumps(m,indent=2)+'\n')
