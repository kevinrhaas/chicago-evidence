from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import quote
import json,base64,hashlib
Q=Path(__file__).parent;H='0e838b35b5ba32b61ccd01499310520e160ab4a2';api='https://api.github.com/repos/kevinrhaas/chicago/contents/';rows=[]
def get(rel):
 req=Request(api+quote(rel,safe='/')+'?ref='+H,headers={'User-Agent':'Chicago-isolated-source-proposal','Accept':'application/vnd.github+json'})
 with urlopen(req,timeout=30)as r:d=json.load(r)
 if isinstance(d,list):return d
 b=base64.b64decode(d['content']);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==d['sha'];p=Q/'immutable0e'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);rows.append({'path':rel,'git_blob':d['sha'],'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)});return b
for rel in ['chicago/4d/data/structures/wolf_point_tavern.json','chicago/4d/data/reference_views/wolf_point_tavern','chicago/4d/data/sources','chicago/4d/tools/photo_match.py']:
 try:
  d=get(rel)
  if isinstance(d,list):
   names=[x['name']for x in d];print(rel,[n for n in names if any(x in n.lower()for x in ['wolf','1832','blanchard','poster','newberry'])]if'/sources' in rel else names,flush=True)
   (Q/(Path(rel).name+'-listing.json')).write_text(json.dumps(d,indent=2)+'\n')
  else:print(rel,len(d),flush=True)
 except Exception as e:print(rel,type(e).__name__,str(e)[:100],flush=True)
(Q/'IMMUTABLE-INPUTS.json').write_text(json.dumps({'commit':H,'rows':rows},indent=2)+'\n')
