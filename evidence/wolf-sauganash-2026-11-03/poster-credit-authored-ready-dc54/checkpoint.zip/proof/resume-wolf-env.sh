source /workspace/shared/resume-chicago-env.sh
unset GIT_CONFIG_COUNT GIT_CONFIG_KEY_0 GIT_CONFIG_VALUE_0 GIT_CONFIG_KEY_1 GIT_CONFIG_VALUE_1
export GIT_NO_LAZY_FETCH=1 GIT_OPTIONAL_LOCKS=0 CHECK_JOBS=4 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
unset CHICAGO_TICKETS_DIR
export TMPDIR=/tmp/wolf-credit-proof-20261103/scratch TMP=/tmp/wolf-credit-proof-20261103/scratch TEMP=/tmp/wolf-credit-proof-20261103/scratch NODE_COMPILE_CACHE=/tmp/wolf-credit-proof-20261103/node-cache
export PATH=/tmp/wolf-credit-proof-20261103/git-fixture-env-strict:$PATH
