from pathlib import Path
import hashlib,json,os,re,subprocess,time,shutil
D=Path(__file__).resolve().parent
Q=Path('/tmp/wolf-final-head-qa2-20261103')
code=(Q/'run.py').read_text();prefix=code.split('assert not O.exists()and not K.exists()')[0]
ns={'__file__':str(Q/'run.py')};exec(prefix,ns)
plan=json.loads((Q/'PLAN.json').read_bytes());before_pub=json.loads((Q/'BEFORE-PUBMAP.json').read_bytes());old_owner=json.loads(Path('/tmp/wolf-final-head-actual2-20261103/OWNER.json').read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();pf=lambda p:sha(Path(p).read_bytes());own_hash=pf(__file__)
def dump(n,d): (D/n).write_text(json.dumps(d,indent=2)+'\n')
def guard():
 assert ns['metadata']()==plan['metadata'],'Source Git metadata drifted'
 assert ns['bindings']()==plan['input_bindings'],'Selected714 inputs drifted'
 assert ns['pubmap']()==before_pub,'Full5848 pubmap drifted'
 assert pf(Q/'PLAN.json')==old_owner['plan_sha256']
 assert {n:pf(Q/n)for n in plan['helpers']}==plan['helpers']
 assert pf('/workspace/shared/run-with-reaping.py')==plan['reaper_sha256']
 assert pf(__file__)==own_hash
 return ns['floor']()
resources=guard();custom=json.loads(Path('/tmp/wolf-final-head-actual2-20261103/RESULT.json').read_bytes());prior=json.loads(Path('/tmp/wolf-final-head-native3b-20261103/PROGRESS.json').read_bytes());assert len(custom['steps'])==2 and all(x['reaper']['all_children_reaped']and not x['reaper']['leftover_cleanup']for x in custom['steps']);assert len(prior)==1 and prior[0]['viewport']=='mobile'and prior[0]['passed']==107 and prior[0]['failed']==0 and prior[0]['reaper']['all_children_reaped']and not prior[0]['reaper']['leftover_cleanup']
assert not (D/'RETRY-REAPER.json').exists()
scratch=Path('/tmp/wolf-final-desktop-recovery-scratch-20261103');scratch.mkdir(exist_ok=True)
env=dict(ns['E'],TMPDIR=str(scratch),TMP=str(scratch),TEMP=str(scratch),NODE_COMPILE_CACHE=str(scratch/'node-cache'),SMOKE_VIEWPORT='desktop',SMOKE_STAGE='3',SMOKE_ROOT=str(ns['S']),SMOKE_SHOTS=str(D/'desktop-shots'))
dump('START.json',{'status':'ALL_CURRENT_GUARDS_MATCH_ORIGINAL_QA2','head':plan['expected_head'],'tree':plan['expected_tree'],'selected_inputs':len(plan['input_bindings']),'full_published_members':len(before_pub),'full_pubmap_sha256':plan['full_published_map_sha256'],'resources':resources,'prior_custom_both':custom['steps'],'prior_official_mobile':prior,'old_desktop':'Raw107/0 SMOKE PASS survived but original controller/subreaper interrupted. Retained as interrupted; this fresh foreground leg earns its own full reaper/exit proof.'})
started=time.monotonic()
command=['python','/workspace/shared/run-with-reaping.py',str(D/'RETRY-REAPER.json'),'--','timeout','--signal=TERM','--kill-after=15s','600s','nice','-n','19','taskset','-c','0-4','node','tools/smoke_renderer.mjs','--published']
with (D/'native-desktop.log').open('xb')as f: result=subprocess.run(command,cwd=ns['A'],env=env,stdout=f,stderr=subprocess.STDOUT)
reaper=json.loads((D/'RETRY-REAPER.json').read_bytes());log=(D/'native-desktop.log').read_text(errors='replace');counts=re.findall(r'(\d+) passed, (\d+) failed',log);resources=guard();passed=result.returncode==0 and reaper['command_exit']==0 and reaper['all_children_reaped']and not reaper['leftover_cleanup']and reaper['interrupted_signal']is None and counts and counts[-1]==('107','0')and'SMOKE PASS'in log
receipt={'status':'FRESH_DESKTOP_OFFICIAL107_PASS_ALL_E32_ACCEPTANCE_COMPLETE'if passed else'NOT_QUALIFIED','head':plan['expected_head'],'tree':plan['expected_tree'],'seconds':time.monotonic()-started,'exit':result.returncode,'counts':counts[-1]if counts else None,'reaper':reaper,'all714_inputs_Git_full5848_publication_helpers_exact':True,'full_published_map_sha256':plan['full_published_map_sha256'],'prior_custom_both':custom['steps'],'prior_official_mobile':prior,'original_desktop_interruption_preserved':True,'resources':resources,'scope':'Final actual e32 authored/integrated head only. Custom default-world body/Images/Record both PASS; official published Stage3 mobile107/0 before interruption and desktop107/0 fresh retry. No all15 stages, FPS, geographic photo-camera, street-arrival or original-ticket completion claim before normal merge.'}
dump('FINAL-CLOSURE.json',receipt);print(json.dumps({'status':receipt['status'],'seconds':receipt['seconds'],'counts':receipt['counts']}),flush=True)
raise SystemExit(0 if passed else 1)
