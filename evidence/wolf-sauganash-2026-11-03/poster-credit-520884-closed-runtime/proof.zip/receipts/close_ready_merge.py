from pathlib import Path
import json,hashlib,subprocess,re,datetime
from urllib.request import Request,urlopen
P=Path(__file__).parent;R=Path('/tmp/wolf-credit-work-20261103');U=Path('/tmp/wolf-credit-runtime-actual-20261103');N=Path('/tmp/wolf-credit-native-card-smoke-v2-20261103');H=Path('/tmp/wolf-credit-runtime-helper-v2-20261103');PLAN=Path('/tmp/wolf-credit-runtime-plan-v2-20261103.json');HEAD='520884613539cec3ba6874a1c82cd5ee377665a9';sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
ui=json.loads((U/'RESULT.json').read_bytes());native=json.loads((N/'RESULT.json').read_bytes());plan=json.loads(PLAN.read_bytes());review=json.loads((U/'ROOT-DIRECT-REVIEW.json').read_bytes());assert ui['head']==native['head']==plan['expected_head']==review['head']==HEAD
assert ui['status']=='FOCUSED_PUBLISHED_WOLF_IMAGES_BOTH_PASS'and native['status']=='NATIVE_PUBLISHED_CARD_PART3_BOTH_PASS'and review['directly_viewed_all_four']and review['accepted_credit_increment'];assert all(ui['closure'][k]for k in ['metadata_unchanged','selected_source_and_published_inputs_unchanged','plan_unchanged','helpers_unchanged'])
counts=[]
for row in native['rows']:
 rr=row['reaper'];assert row['exit']==rr['command_exit']==0 and rr['all_children_reaped']and not rr['leftover_cleanup']and rr['interrupted_signal']is None
 log=re.sub(r'\x1b\[[0-9;]*m','',Path(row['log']).read_text(errors='replace'));passed=len(re.findall(r'^\s*pass\s+',log,re.M|re.I));failed=len(re.findall(r'^\s*fail\s+',log,re.M|re.I));assert passed==107 and failed==0 and'SMOKE PASS'in log;counts.append({'viewport':row['viewport'],'passed':passed,'failed':failed,'seconds':row['seconds']})
assert {x['viewport']for x in counts}=={'mobile','desktop'}
for x in review['images']:assert sha(Path(x['path']).read_bytes())==x['sha256']
post=P/'POST-NATIVE-W-PLAN.json'
if not post.exists():subprocess.run(['python3',str(H/'run.py'),'--prepare',str(post)],check=True,cwd=R/'chicago/4d')
after=json.loads(post.read_bytes())
for k in ['expected_picture_ids','expected_camera_source_ids','picture_id_by_camera_source','source_root','site_parent','expected_head','input_bindings','source_scope_sha256','metadata','helpers','reaper_sha256']:assert after[k]==plan[k],k
before=json.loads((P/'W-PUBLISHED-BEFORE-RUNTIME-FULLMAP.json').read_bytes());rows=[]
for f in sorted((R/'site/4d').rglob('*')):
 if not f.is_file():continue
 h=hashlib.sha256()
 with f.open('rb')as inp:
  for b in iter(lambda:inp.read(1048576),b''):h.update(b)
 rows.append({'path':f.relative_to(R/'site/4d').as_posix(),'bytes':f.stat().st_size,'sha256':h.hexdigest()})
assert rows==before['members'];assert sha((json.dumps(rows,sort_keys=True,separators=(',',':'))+'\n').encode())==before['map_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD and not subprocess.check_output(['git','status','--porcelain','--untracked-files=normal'],cwd=R)
closure={'status':'FINAL_WOLF_UI_NATIVE3_ALL_READERS_CLOSED_PASS','at':now(),'head':HEAD,'native_counts':counts,'selected_bindings':len(plan['input_bindings']),'all_source_published_selected_bindings_exact':True,'all_Git_metadata_exact':True,'helpers_and_plan_exact':True,'full_published_member_count':len(rows),'full_published_member_map_sha256':before['map_sha256'],'all_full_published_bytes_exact':True,'root_direct_review_accepted':True,'all_reapers_closed_no_leftovers':True,'scope':'Actual defaultvisitor7picture/1held/6linked/currentNewberry creditedcard bothviewports plus official nativeStage3; no originalticket/fullpicture/newcamera/bodyframing claim'};(N/'FINAL-CLOSURE.json').write_text(json.dumps(closure,indent=2)+'\n');(P/'W-RUNTIME-FINAL-CLOSURE.json').write_text(json.dumps(closure,indent=2)+'\n');print(json.dumps(closure),flush=True)
def api(path,data=None,method=None,graphql=False):
 base='https://api.github.com/'if graphql else'https://api.github.com/repos/kevinrhaas/chicago/'
 q=Request(base+path,data=None if data is None else json.dumps(data).encode(),headers={'User-Agent':'Chicago-source-credit-protected-merge','Content-Type':'application/json','Accept':'application/vnd.github+json'},method=method or('GET'if data is None else'POST'))
 with urlopen(q,timeout=60)as r:return json.load(r)
pr=api('pulls/1657');assert pr['head']['sha']==HEAD and pr['state']=='open'and pr['mergeable']is True,(pr['head']['sha'],pr['state'],pr['mergeable_state'])
checks=api('commits/'+HEAD+'/check-runs?per_page=100');assert any(c['name']=='gate'and c['conclusion']=='success'for c in checks['check_runs']);assert all(c['status']=='completed'and c['conclusion']in['success','skipped','neutral']for c in checks['check_runs']),[(c['name'],c['status'],c['conclusion'])for c in checks['check_runs']]
body=(P/'PR-BODY.md').read_text();body=body.replace('- Final published desktop/390×780 Images-card checks and native card regression are pending; required final-head CI must pass before normal protected merge.','- Actual published desktop1280×800 and phone390×780 Images cards pass:7pictures,1loadedheld image,6creditedlinks and the current Newberry poster link/credit fully visible. All4actual shots are directly reviewed. Default visitor geometry lifecycle, no page/console/network/server errors.\n- Official published native stage3 passes107checks/0failures at each viewport. All reapers close and all584selected inputs, Git metadata and5811published member bytes remain exact. Final-head required GitHub gate41608457934 passes.').replace('The actual browser/native stage3 proof remains pending.','Actual browser/native107×2 proof is closed and will be linked alongside the merged handoff.');(P/'PR-BODY.md').write_text(body);api('pulls/1657',{'body':body},'PATCH')
if pr['draft']:
 mutation='mutation Ready($id: ID!) { markPullRequestReadyForReview(input:{pullRequestId:$id}) { pullRequest { number isDraft headRefOid } } }';ready=api('graphql',{'query':mutation,'variables':{'id':pr['node_id']}},graphql=True);assert not ready.get('errors'),ready;(P/'PR1657-READY.json').write_text(json.dumps(ready,indent=2)+'\n')
pr=api('pulls/1657');assert not pr['draft']and pr['head']['sha']==HEAD and pr['mergeable']is True,(pr['draft'],pr['mergeable_state'])
result=api('pulls/1657/merge',{'sha':HEAD,'merge_method':'merge','commit_title':'Credit the Blanchard/Davis Wolf Point poster in Images (#1657)'},'PUT');(P/'PR1657-MERGE-ACTION.json').write_text(json.dumps({'at':now(),'exact_head_CAS':HEAD,'normal_protected_merge':True,'result':result,'checks_before_merge':checks},indent=2)+'\n');assert result['merged']is True,result
pr=api('pulls/1657');assert pr['merged']is True and pr['merge_commit_sha']==result['sha']and pr['head']['sha']==HEAD;(P/'PR1657-MERGED.json').write_text(json.dumps({'at':now(),'merged':True,'merge_sha':result['sha'],'head':HEAD,'merged_at':pr['merged_at'],'pr':pr,'native_closure':closure},indent=2)+'\n');print(json.dumps({'PR':1657,'MERGED':True,'merge_sha':result['sha'],'at':pr['merged_at'],'head':HEAD,'normal_protected_CAS':True}),flush=True)
