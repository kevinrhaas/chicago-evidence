/** Outside-only actual in-app Wolf framing; integrate into ONE existing world.
 * Caller owns exact-head source/publication guards, native600s reaper, both
 * viewports, page/network/console/server error capture and default lifecycle.
 * This function creates no browser, changes no application source or asset,
 * hides no building and never changes the camera frustum.
 */
export async function inspectWolfBody(page, reference) {
  const evidence=await page.evaluate(async reference=>{
    const a=window.__chicago4d,id='wolf_point_tavern';
    if(!a?.ready||a.welcome?.state!=='world')throw Error('Wolf framing requires ready real world');
    a.popup.close();a.navigator.dock();a.travel.stop('Curated Wolf Point body inspection');
    a.confidence.resetGrades();a.setConfidenceView(false);a.setFly(true);a.walker.setFlying(true);
    const wholeBox=a.buildings.instanceBounds()[id],matrix=a.buildings.matrixOf(id);
    const box=wholeBox?.body;
    if(!box?.valid||box.errors.length||box.samples<=0||box.wallSamples<=0)throw Error('Native Wolf mesh body bounds invalid');
    const missing=a.buildings.missing?.has?.(id);
    if(missing!==false||!box||!matrix)throw Error('Real Wolf Point geometry/transform missing');
    const transform=(p,m)=>{
      const w=m[3]*p[0]+m[7]*p[1]+m[11]*p[2]+m[15];
      return [(m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12])/w,(m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13])/w,(m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14])/w];
    };
    const m=[...matrix.elements],corners=[];
    for(const x of [box.min[0],box.max[0]])for(const y of [box.min[1],box.max[1]])for(const z of [box.min[2],box.max[2]])corners.push(transform([x,y,z],m));
    const center=transform(box.min.map((n,i)=>(n+box.max[i])/2),m);
    const referenceEye=transform([reference.eye[0],reference.eye[2],-reference.eye[1]],m);
    const delta=referenceEye.map((n,i)=>n-center[i]),length=Math.hypot(...delta);
    if(!Number.isFinite(length)||length<=0)throw Error('Invalid Wolf inspection direction');
    const horizontal=Math.hypot(delta[0],delta[2]),elevation=35*Math.PI/180;
    if(!(horizontal>0))throw Error('Invalid horizontal inspection direction');
    const direction=[delta[0]/horizontal*Math.cos(elevation),Math.sin(elevation),delta[2]/horizontal*Math.cos(elevation)];
    const miller=a.buildings.matrixOf('miller_house');
    if(miller&&Math.hypot(m[12]-miller.elements[12],m[14]-miller.elements[14])<0.01)throw Error('Wolf target transform must not be Miller House');
    const radius=Math.max(...corners.map(p=>Math.hypot(...p.map((n,i)=>n-center[i]))));
    const vfov=(a.camera.getEffectiveFOV?.()??a.camera.fov)*Math.PI/180,aspect=a.camera.aspect;
    if(!(radius>0&&vfov>0&&vfov<Math.PI&&aspect>0))throw Error('Invalid actual Wolf bounds/frustum');
    const half=Math.min(vfov/2,Math.atan(Math.tan(vfov/2)*aspect));
    let distance=radius/Math.sin(half)*1.15,placement,projected;
    for(let attempt=0;attempt<6;attempt++){
      const eye=center.map((n,i)=>n+direction[i]*distance),ground=a.walker.surfaceAt(eye[0],-eye[2]);
      eye[1]+=Math.max(0,ground+2-eye[1]);
      const de=center[0]-eye[0],dn=eye[2]-center[2],rise=center[1]-eye[1];
      placement={local_e:eye[0],local_n:-eye[2],yaw_deg:(Math.atan2(de,dn)*180/Math.PI+360)%360,pitch_deg:Math.atan2(rise,Math.hypot(de,dn))*180/Math.PI,altitude_m:eye[1]-ground};
      a.walker.teleport(placement);a.step();
      projected=corners.map(p=>({world:p,ndc:a.project(p[0],-p[2],p[1])}));
      if(projected.every(p=>Number.isFinite(p.ndc.x)&&Number.isFinite(p.ndc.y)&&p.ndc.z>=-1&&p.ndc.z<=1&&Math.abs(p.ndc.x)<=0.96&&Math.abs(p.ndc.y)<=0.96))break;
      distance*=1.2;
    }
    const before=a.renderer.info.render.frame,pending=a.capture(12);a.step();const signature=await pending;
    return {id,missing,box,whole_asset_box:wholeBox,body_bounds_native:true,curated_elevation_deg:35,matrix:m,center,corners,radius,direction,reference_eye_enu:reference.eye,reference_world_eye:referenceEye,reference_direction_only:true,distance,placement,projected,actual_walker:{...a.walker.state},camera_world:a.camera.position.toArray(),before,after:a.renderer.info.render.frame,signature,ready:a.ready,welcome:a.welcome.state,contextLost:a.renderer.getContext().isContextLost(),detail:a.detail,flying:a.walker.state.flying,scope:'Actual Wolf Point native mesh-body eight-corner elevated flying inspection; complete pole is not the framing target. No calibrated historical street pose, source-camera viewpoint, normal-arrival behavior, unobstructed-feature or original-ticket acceptance claim until direct screenshot review.'};
  },reference);
  if(evidence.id!=='wolf_point_tavern'||evidence.missing!==false||!evidence.flying||!evidence.ready||evidence.welcome!=='world'||evidence.contextLost||evidence.detail!=='full')throw Error('Actual full-detail Wolf world failed');
  if(evidence.projected.length!==8||!evidence.projected.every(p=>Number.isFinite(p.ndc.x)&&Number.isFinite(p.ndc.y)&&p.ndc.z>=-1&&p.ndc.z<=1&&Math.abs(p.ndc.x)<=0.96&&Math.abs(p.ndc.y)<=0.96))throw Error('Eight actual native Wolf body mesh corners must fit unchanged frustum');
  if(!(evidence.after>evidence.before&&evidence.signature.litFraction>0.05&&Number.isFinite(evidence.signature.mean)))throw Error('Actual Wolf native readback failed');
  await page.waitForFunction(frame=>{const a=window.__chicago4d;if(!a.ready||a.welcome.state!=='world'||document.visibilityState!=='visible'||a.renderer.getContext().isContextLost())throw Error('Wolf framing world readiness changed');return a.renderer.info.render.frame>=frame+3;},evidence.after,{timeout:180000,polling:500});
  evidence.settled_frame=await page.evaluate(()=>window.__chicago4d.renderer.info.render.frame);
  return evidence;
}
