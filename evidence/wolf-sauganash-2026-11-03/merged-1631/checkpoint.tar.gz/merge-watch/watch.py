"""Merge the one reviewed PR once its unchanged head has green required CI.
No source, Git refs, branch protection or other PR is changed by this watcher.
"""
from pathlib import Path
import subprocess,json,time,datetime,hashlib,sys
O=Path(__file__).resolve().parent;HEAD='0e838b35b5ba32b61ccd01499310520e160ab4a2';REPO='kevinrhaas/chicago';PR='1631'
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def gh(*a):return subprocess.check_output(['gh',*a],text=True,timeout=60)
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
release=json.loads((O/'ROOT-RELEASE.json').read_text());assert release['head']==HEAD and release['root_approved'] is True
for p,sha in release['proofs'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha,p
assert not (O/'MERGE-ACTION.json').exists(),'A merge action has already been attempted; inspect its receipt'
deadline=time.monotonic()+1200
while time.monotonic()<deadline:
 x=json.loads(gh('pr','view',PR,'--repo',REPO,'--json','state,headRefOid,mergeable,isDraft,labels,statusCheckRollup,reviewDecision,mergeCommit,mergedAt'))
 save('LATEST.json',dict(at=stamp(),pr=x))
 if x['state']=='MERGED':
  save('RESULT.json',dict(status='ALREADY_MERGED_OBSERVED',at=stamp(),pr=x));print('PR1631 already merged; no action.',flush=True);sys.exit(0)
 if x['state']!='OPEN' or x['headRefOid']!=HEAD or x['isDraft']or any(l['name']=='hold'for l in x['labels'])or x['reviewDecision']=='CHANGES_REQUESTED':
  save('RESULT.json',dict(status='STOP_CHANGED_OR_UNAPPROVED_PR',at=stamp(),pr=x));print('Stopped: PR changed or requires review.',flush=True);sys.exit(3)
 if x['mergeable']=='CONFLICTING':
  save('RESULT.json',dict(status='STOP_NEW_DEV_CONFLICT',at=stamp(),pr=x));print('Stopped: new dev conflict needs native integration.',flush=True);sys.exit(3)
 checks=x['statusCheckRollup'];gates=[c for c in checks if c.get('name')=='gate']
 failed=[c for c in checks if c.get('status')=='COMPLETED'and c.get('conclusion')not in ['SUCCESS','SKIPPED','NEUTRAL']or c.get('state')in ['FAILURE','ERROR']]
 if failed:
  save('RESULT.json',dict(status='STOP_CI_FAILED',at=stamp(),checks=failed));print('Stopped: CI did not pass.',flush=True);sys.exit(4)
 green=bool(gates)and all(c.get('status')=='COMPLETED'and c.get('conclusion')=='SUCCESS'for c in gates)and all(c.get('status')=='COMPLETED'and c.get('conclusion')in ['SUCCESS','SKIPPED','NEUTRAL']or c.get('state')=='SUCCESS'for c in checks)
 if green and x['mergeable']in ['MERGEABLE','UNKNOWN']and x['reviewDecision']!='REVIEW_REQUIRED':
  for p,sha in release['proofs'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha,p
  cmd=['gh','pr','merge',PR,'--repo',REPO,'--squash','--match-head-commit',HEAD]
  q=subprocess.run(cmd,text=True,capture_output=True,timeout=60)
  save('MERGE-ACTION.json',dict(at=stamp(),command=cmd,exit=q.returncode,stdout=q.stdout,stderr=q.stderr,validated_pr=x))
  if q.returncode:print('Protected normal merge refused; inspect MERGE-ACTION.json.',flush=True);sys.exit(5)
  final=json.loads(gh('pr','view',PR,'--repo',REPO,'--json','state,headRefOid,mergeCommit,mergedAt'));assert final['state']=='MERGED'and final['headRefOid']==HEAD
  save('RESULT.json',dict(status='MERGED_REVIEWED_INCREMENT_TO_DEV',at=stamp(),pr=final));print(json.dumps(final),flush=True);sys.exit(0)
 time.sleep(30)
save('RESULT.json',dict(status='WAITING_REQUIRED_CI_NO_MERGE_ATTEMPT',at=stamp(),head=HEAD));print('CI still pending; no merge attempted.',flush=True)
