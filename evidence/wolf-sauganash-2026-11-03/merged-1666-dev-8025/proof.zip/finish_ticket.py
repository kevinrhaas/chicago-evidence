from pathlib import Path
import base64, json, os, subprocess, time
P=Path(__file__).resolve().parent; W=Path('/tmp/wolf-poster-source-20261103'); A=W/'chicago/4d'; T=A/'tickets'
E=os.environ.copy()
for key in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']:E.pop(key,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',CHICAGO_TICKETS_DIR=str(T))
def api(repo,path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/'+repo+'/'+path]))
def native(name,argv):
    t=time.monotonic()
    with (P/(name+'.log')).open('xb')as log:
        r=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(P/(name+'-REAPER.json')),'--','taskset','-c','2','nice','-n','19','timeout','--signal=TERM','--kill-after=15s','600s',*argv],cwd=A,env=E,stdout=log,stderr=subprocess.STDOUT)
    d=json.loads((P/(name+'-REAPER.json')).read_bytes());assert r.returncode==d['command_exit']==0 and d['all_children_reaped']and not d['leftover_cleanup']and d['interrupted_signal']is None,(name,r.returncode,d)
    print(name,'CLOSED',round(time.monotonic()-t,3),flush=True)
assert api('chicago','pulls/1666')['merged']
f=next((T/'T-2250-2499').glob('T-2386-*.md'))
before=f.read_text();marker='## Final eight-comparison signoff merged';prior,tail=before.split(marker,1)
for old,new in [('at2026','at 2026'),('gate41717780685','gate 41717780685'),('all1137','all 1137'),('ca.1893','ca. 1893'),('Newberry1935','Newberry 1935'),('earlier1867','earlier 1867'),('T3153','T-3153'),('passes107/0','passes 107/0'),('PR1674','PR #1674'),('exactly0','exactly 0')]:tail=tail.replace(old,new)
after=prior+marker+tail
if after!=before:
    f.write_text(after);native('ticket-final-clarity-sync',['node','tools/ticket.mjs','sync','-m','Clarify final Wolf Point signoff notation'])
native('ticket-native-settle',['node','tools/ticket.mjs','settle'])
row=api('chicago-tickets','contents/T-2250-2499/'+f.name+'?ref=main');body=base64.b64decode(row['content']);fields=dict(line.split(': ',1)for line in body.decode().split('---',2)[1].strip().splitlines()if ': 'in line)
assert fields['state']=='done'and fields['pr']=='1666'and marker.encode()in body
(P/'T2386-PUBLIC-DONE.md').write_bytes(body)
proof={'main':api('chicago-tickets','git/ref/heads/main')['object']['sha'],'file':f.relative_to(T).as_posix(),'blob':row['sha'],'state':fields['state'],'pr':fields['pr'],'closed_at':fields.get('closed_at'),'final_merged_signoff_present':True,'native_settlement_not_manual_header_edit':True};(P/'T2386-NATIVE-DONE-READBACK.json').write_text(json.dumps(proof,indent=2)+'\n')
marker_result=subprocess.run(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/lap/pr-1666'],capture_output=True)
if marker_result.returncode==0:
    old=json.loads(marker_result.stdout)['object']['sha'];assert old=='f70c9c93639e42768a0e5dc080ff233d8bd42385',('A different marker holder must be reviewed',old)
    native('lap1666-release',['node','tools/ticket.mjs','lap','1666','--release'])
else:assert b'404'in marker_result.stderr
gone=subprocess.run(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/lap/pr-1666'],capture_output=True);assert gone.returncode!=0 and b'404'in gone.stderr
(P/'LAP1666-RELEASED-READBACK.json').write_text(json.dumps({'pr':1666,'native_release_complete':True,'public_marker_ref_404':True,'no_source_branch_or_dev_main_ref_deletion':True},indent=2)+'\n')
assert not subprocess.check_output(['git','-C',str(W),'status','--porcelain','--untracked-files=normal'],env=E).strip()
print('ORIGINAL T2386 NATIVE DONE AND LAP RELEASED',proof['main'],flush=True)
