"""Ordinary exact-head protected merge, only after the actual final hosted gate passes."""
from pathlib import Path
import datetime, json, os, subprocess

P=Path(__file__).resolve().parent; W=Path('/tmp/wolf-poster-source-20261103')
HEAD='8e5aedc13ec207020c1c08d1ea78ec0eab450654'; BASE='dacc6364b6e6dce484d197627abbea5244218a0c'; RUN=41717780685
def api(path,body=None,method=None):
    command=['gh','api','repos/kevinrhaas/chicago/'+path]
    if body is not None:command+=['--method',method or 'POST','--input','-']
    result=subprocess.run(command,input=None if body is None else json.dumps(body).encode(),capture_output=True)
    if result.returncode:raise RuntimeError((path,result.stderr.decode()[:2000]))
    return json.loads(result.stdout)
def dump(name,value):(P/name).write_text(json.dumps(value,indent=2)+'\n')
gate=api('actions/runs/'+str(RUN));assert gate['head_sha']==HEAD
if gate['status']!='completed':print('FINAL_GATE_PENDING',gate['status']);raise SystemExit(20)
dump('FINAL-HOSTED-GATE-CLOSED.json',gate)
assert gate['conclusion']=='success',('Final current-head source gate did not pass',gate['conclusion'])
jobs=api('actions/runs/'+str(RUN)+'/jobs');assert jobs['jobs'] and all(j['status']=='completed'and j['conclusion']=='success'for j in jobs['jobs']);dump('FINAL-HOSTED-GATE-JOBS.json',jobs)
for name in ['PRECOMMIT-CLOSED.json','FINAL-TARGET-QUALIFICATION.json','PUBLIC-PUSH.json']:assert (P/name).is_file()
source=json.loads((P/'PUBLIC-PUSH.json').read_bytes());assert source['head']==HEAD and source['exact_native_commit_tree_and_all_blob_readbacks']
qualification=json.loads((P/'FINAL-TARGET-QUALIFICATION.json').read_bytes());assert qualification['head']==HEAD and qualification['native_published_Wolf_reader_card_sidecar_exact'] and qualification['accepted_e32_plan']['exact_e32_native_reader_note_and_all_picture_rows']
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD']).decode().strip()==HEAD
assert not subprocess.check_output(['git','-C',str(W),'status','--porcelain','--untracked-files=normal']).strip()
pr=api('pulls/1666');assert pr['head']['sha']==HEAD and pr['base']['ref']=='dev';dump('PR1666-BEFORE-MERGE.json',pr)
if pr['merged']:
    dump('MERGED-READBACK.json',pr);print('ALREADY_MERGED',pr['merge_commit_sha']);raise SystemExit()
assert not pr['draft'] and pr['state']=='open' and pr['mergeable'] is True
assert not any(x['name']in ['hold','resume']for x in pr['labels']),pr['labels']
dev=api('git/ref/heads/dev')['object']['sha'];dump('DEV-BEFORE-MERGE.json',{'head':dev})
if dev!=BASE:
    comparison=api('compare/'+BASE+'...'+dev);dump('CURRENT-DEV-COMPARE-BEFORE-MERGE.json',comparison)
    assert comparison['status']in ['ahead','identical'] and not comparison['behind_by']
    allowed={'chicago/4d/changelog.d/T-2379.json','chicago/4d/renderers/web/js/changelog.js','chicago/4d/renderers/web/js/night-lights.js'}
    assert all(row['filename']in allowed for row in comparison['files']),('New non-fold dev changes need qualification',[r['filename']for r in comparison['files']])
    peer_commit='e5739ab8f62e6957eeff69a53f87fe9b01bccd5b'
    assert all(c['commit']['message'].startswith('changelog: fold entry files')or c['sha']==peer_commit for c in comparison['commits'])
    night=[row for row in comparison['files']if row['filename'].endswith('/night-lights.js')]
    if night:
        assert len(night)==1 and night[0]['sha']=='b94806505c5b73ac1e98427f7d3a7c0d63ea0013'
        peer=json.loads((P/'UPSTREAM-PR1674.json').read_bytes());assert peer['merged'] and peer['merge_commit_sha']==peer_commit and peer['head']['sha']=='b519b5dae4ec351b88248364ef1f0cbed45f5a6e'
        peer_checks=json.loads((P/'UPSTREAM-PR1674-CHECKS.json').read_bytes());assert any(c['name']=='gate'and c['status']=='completed'and c['conclusion']=='success'for c in peer_checks['check_runs'])
        dump('UPSTREAM-NIGHT-PATCH-QUALIFICATION.json',{'current_dev':dev,'peer_pr':1674,'peer_merge':peer_commit,'peer_head':peer['head']['sha'],'night_module_blob':night[0]['sha'],'peer_full_gate':'success','peer_reported_local_validation':'All4 source parts and actual1904 dusk near/far walk with no pixel dropouts or page errors. Optional moving-frames/warranted cancellations are not represented as runtime passes.','reviewed_delta':'Only v1-to-v2 shader cache key and batched vChiWinId choosing the stable instance translation instead of transient instance index; existing unbatched path already uses that translation.','day_equivalence':'Daylight glow uniform remains exactly0; fragment emission branch is guarded by uWinGlow>0. Positions, normals, card, reader, data, models and references are unchanged. Peer actual batched dusk runtime exercises the changed shader compile path.','root_independent_review':'Parent explicitly reviewed actual PR1674 body/files/patch and authorized this bounded current-day qualification at21:49UTC.','scope':'Accepted daytime Wolf body/card/native-reader and default-day Stage3 remain qualified. This is no claim the current merged renderer bundle is byte-identical or a newly executed browser/night review.'})
payload={'sha':HEAD,'merge_method':'squash','commit_title':pr['title']+' (#1666)','commit_message':'Complete the bounded Wolf Point picture inventory with eight native source/camera/model comparisons and an explicit contextual disposition for the unidentified Herriott view. Preserve source conflicts and existing geometry. Final hosted gate41717780685 passed; qualified actual desktop/phone and native107 checks each remain bound to unchanged Wolf targets.'}
dump('NORMAL-MERGE-REQUEST.json',payload)
try:
    response=api('pulls/1666/merge',payload,'PUT');dump('NORMAL-MERGE-RESPONSE.json',response);assert response.get('merged')is True,response
except RuntimeError as error:
    dump('NORMAL-MERGE-REQUEST-ERROR.json',{'error':str(error),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    raced=api('pulls/1666')
    if not raced['merged']:raise
pr=api('pulls/1666');assert pr['merged'] and pr['head']['sha']==HEAD and pr['merge_commit_sha'];dump('MERGED-READBACK.json',pr)
current=api('git/ref/heads/dev')['object']['sha'];comparison=api('compare/'+pr['merge_commit_sha']+'...'+current);assert comparison['status']in ['identical','ahead'] and not comparison['behind_by'];dump('MERGED-DEV-ANCESTRY.json',comparison)
dump('MERGE-CLOSED-SUMMARY.json',{'pr':1666,'reviewed_head':HEAD,'merge_commit':pr['merge_commit_sha'],'merged_at':pr['merged_at'],'current_dev':current,'final_hosted_gate':RUN,'final_hosted_gate_conclusion':'success','ordinary_exact_head_squash_merge':True,'no_admin_or_forced_ref_update':True,'public_delivery_verified':False})
print('ACTUAL_NORMAL_DEV_MERGE_CLOSED',pr['merge_commit_sha'],pr['merged_at'],flush=True)
