"""Private level-camera solve: actual MASTER roof vertices, six picked source points.

Model scale is reconstructed. Manual picks are approximate, and heldouts never
participate in the solve. This is not a historical camera or accepted match.
"""
from pathlib import Path
import hashlib
import json
import math
import struct
import numpy as np
from scipy.optimize import least_squares

O = Path(__file__).resolve().parent
glb = O / 'initial-proof/models/wolf_point_tavern__log_frame_1828.glb'
b = glb.read_bytes()
assert hashlib.sha256(b).hexdigest() == '225f3e1041d02cdaa627d3d73c5f6448aff9b12c66f4a545462db45bbf8e0d59'
n = struct.unpack_from('<I', b, 12)[0]
doc = json.loads(b[20:20+n])
binary = 20+n+8

def positions(ai):
    a = doc['accessors'][ai]
    v = doc['bufferViews'][a['bufferView']]
    return np.ndarray((a['count'], 3), '<f4', buffer=b, offset=binary+v.get('byteOffset', 0)+a.get('byteOffset', 0), strides=(v.get('byteStride', 12), 4)).astype(float)

roof = positions(6)
def actual_roof(ideal):
    vertex = roof[np.argmin(np.linalg.norm(roof-np.array(ideal), axis=1))]
    assert np.linalg.norm(vertex-np.array(ideal)) < 0.00002
    return [float(vertex[0]), float(-vertex[2]), float(vertex[1])]

# All source points are selected from the full unchanged 2947x2502 poster.
# Source caption identifies the left cabins as the tavern. The right large
# Miller House is excluded from this target-only camera.
definitions = [
    ('annex-east-eave-south', [7.32,2.49195,0.12], [106,1217], 6),
    ('annex-east-apex', [7.32,4.85101,-2.5], [211,1087], 5),
    ('annex-east-eave-north', [7.32,2.49195,-5.12], [310,1222], 6),
    ('main-north-eave-east', [5.12,2.49195,-10.22], [550,1227], 6),
    ('main-north-apex', [2.5,4.85101,-10.22], [652,1087], 5),
    ('main-north-eave-west', [-0.12,2.49195,-10.22], [765,1218], 6),
]
controls = [{'id': name, 'world_enu': actual_roof(p), 'source_pixel': pix, 'manual_uncertainty_px': sigma} for name,p,pix,sigma in definitions]
# Independent elements are paired by the actual material/accessor geometry.
# Pole end is deliberately not used: its fork endpoint identification is ambiguous.
holdouts = [
    {'id':'square-stack-top-centre','world_enu':[2.5,2.929,5.351009845733643],'source_pixel':[385,1059],'manual_uncertainty_px':6,'basis':'chimney material accessor31 top four vertices centre'},
    {'id':'thin-pipe-top-centre','world_enu':[2.5,7.474,5.401010036468506],'source_pixel':[542,1060],'manual_uncertainty_px':6,'basis':'dark material accessor16 octagonal pipe top vertices centre'},
    {'id':'main-north-window-centre','world_enu':[1.449999988079071,10.147000312805176,1.699999988079071],'source_pixel':[678,1249],'manual_uncertainty_px':8,'basis':'glass accessor41/11 front window centre; source opening partly textured'},
]
picked = {'source_sha256':'96fb4ee23dfff23097365987be08d0486f4c05e2a7f25c10330fc8dc919ab4f8','MASTER_sha256':hashlib.sha256(b).hexdigest(),'selection':'New manual selections in this recovery, not reconstruction of the lost pick file. Approximate roof paint edges, not subpixel measurements. Ground/pole positions are not controls.','controls':controls,'held_out':holdouts}
(O/'MANUAL-PICKS-EXACT-VERTICES-v3.json').write_text(json.dumps(picked,indent=2)+'\n')
points = np.array([x['world_enu'] for x in controls])
observed = np.array([x['source_pixel'] for x in controls])
weights = np.array([x['manual_uncertainty_px'] for x in controls])[:,None]
def project(p, xyz):
    u,v,h,yaw,f,cx,cy = p
    a = math.radians(yaw)
    forward = np.array([math.sin(a),math.cos(a),0.])
    right = np.array([math.cos(a),-math.sin(a),0.])
    vectors = np.asarray(xyz)-np.array([u,v,h])
    depth = vectors@forward
    return np.stack([cx+f*(vectors@right)/depth,cy-f*vectors[:,2]/depth],axis=1)
def residual(p):
    return ((project(p,points)-observed)/weights).ravel()

# A finite set of mathematically distinct level-camera starting distances.
# No source measurements or canonical files are changed to obtain a fit.
starts = [
    [131.1461,122.6598,2,227.78687,9000,501.02245,1249.94188],
    [45,43,1.5,228,3000,500,1270],
    [19,19,0.5,228,1200,500,1320],
]
solves = []
for start in starts:
    result = least_squares(residual,start,bounds=([8,11,0.1,180,300,0,0],[400,400,6,270,25000,2947,2502]),max_nfev=2500,xtol=1e-12,ftol=1e-12,gtol=1e-12)
    p = result.x
    r = project(p,points)-observed
    hs = np.array([x['world_enu'] for x in holdouts])
    hr = project(p,hs)-np.array([x['source_pixel'] for x in holdouts])
    solves.append({'parameters':p.tolist(),'success':bool(result.success),'evaluations':result.nfev,'control_coordinate_RMS_px':float(np.sqrt(np.mean(r*r))),'control_point_distances_px':np.linalg.norm(r,axis=1).tolist(),'heldout_coordinate_RMS_px':float(np.sqrt(np.mean(hr*hr))),'heldout_point_distances_px':np.linalg.norm(hr,axis=1).tolist(),'projected_controls':project(p,points).tolist(),'projected_heldouts':project(p,hs).tolist(),'active_bounds':result.active_mask.tolist()})
best = min(solves,key=lambda x:x['control_coordinate_RMS_px'])
(O/'OFFLINE-LEVEL-CAMERA-FITS-v3.json').write_text(json.dumps({'scope':'Offline numerical solve only; not native rendered or accepted. Heldouts excluded. Scale is model reconstruction; level-camera assumption may disagree with artist perspective.','solves':solves,'best_control_fit':best},indent=2)+'\n')
print(json.dumps(best))
