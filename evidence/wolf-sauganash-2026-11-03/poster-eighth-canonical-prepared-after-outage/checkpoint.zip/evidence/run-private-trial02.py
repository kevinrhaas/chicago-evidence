import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

O = Path(__file__).resolve().parent
A = O / 'native/chicago/4d'
out = O / 'trial02'
out.mkdir(exist_ok=False)
os_tmp = out / 'os-tmp'
os_tmp.mkdir()
camera = O / 'poster-private-control-02.json'
inputs = [p for p in A.rglob('*') if p.is_file() and 'node_modules' not in p.parts]
inputs += [camera, O / 'initial-proof/visual/canonical-original-poster.jpg', Path(__file__), Path('/workspace/shared/run-with-reaping.py')]
sha = lambda b: hashlib.sha256(b).hexdigest()
before = {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in inputs}
assert shutil.disk_usage('/workspace').free >= 536870912
assert shutil.disk_usage('/tmp').free >= 1800000000
assert before[str(A / 'assets/gltf/wolf_point_tavern__log_frame_1828.glb')]['sha256'] == '225f3e1041d02cdaa627d3d73c5f6448aff9b12c66f4a545462db45bbf8e0d59'
assert before[str(O / 'initial-proof/visual/canonical-original-poster.jpg')]['sha256'] == '96fb4ee23dfff23097365987be08d0486f4c05e2a7f25c10330fc8dc919ab4f8'
(out / 'BEFORE.json').write_text(json.dumps(before, indent=2) + '\n')
command = ['python', '/workspace/shared/run-with-reaping.py', str(out / 'REAPER.json'), '--', 'timeout', '--signal=TERM', '--kill-after=15s', '600s', 'nice', '-n', '19', 'taskset', '-c', '2', 'node', 'tools/photo_match.mjs', str(camera), '--glb', 'assets/gltf/wolf_point_tavern__log_frame_1828.glb', '--out', str(out)]
env = os.environ.copy()
env['TMPDIR'] = str(os_tmp)
start = time.monotonic()
with (out / 'native.log').open('w') as log:
    result = subprocess.run(command, cwd=A, env=env, stdout=log, stderr=subprocess.STDOUT)
after = {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in inputs}
reaper = json.loads((out / 'REAPER.json').read_bytes())
closed = before == after and reaper['all_children_reaped'] and not reaper['leftover_cleanup']
proof = {'status': 'NATIVE_PRIVATE_TRIAL_RENDERED_UNREVIEWED' if result.returncode == 0 and closed else 'PRIVATE_TRIAL_FAILED', 'native_tools_commit': '0e838b35b5ba32b61ccd01499310520e160ab4a2', 'exit_code': result.returncode, 'seconds': time.monotonic() - start, 'guarded_paths': len(inputs), 'all_inputs_exact': before == after, 'all_owned_children_reaped': reaper['all_children_reaped'], 'leftover_cleanup': reaper['leftover_cleanup'], 'R_or_canonical_reads_writes': False, 'command': command, 'scope': 'Private asset-only diagnostic on exact225Master/full96fbposter. No final-tool/current-head/whole-ticket or accepted-fit claim. Camera outsidecanonicalreference_views.'}
(out / 'RESULT.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof))
raise SystemExit(0 if result.returncode == 0 and closed else 1)
