# Final integration native stage 3

Prepared/syntax-checked only; not run. Pinned from the frozen final source-writer handoff to commit `0e838b35b5ba32b61ccd01499310520e160ab4a2`; execution remains unrun pending explicit root release after the final default-visitor UI BOTH_PASS. Require root release after `/workspace/combined-wolf-saug-both-actual-final-20261103/RESULT.json` records `FOCUSED_PUBLISHED_COMBINED_WOLF_SAUG_BOTH_PASS` at the identical final HEAD and source scope bound by `/workspace/combined-wolf-saug-plan-final-20261103.json`.

The unchanged native published SMOKE_STAGE=3 runs mobile then desktop with separate 600-second reapers, unchanged assertions and selected-source/publication/clean-HEAD guards before/between/after. This folder owns new logs/screens/results and separate final /tmp cache/scratch. Prior e51 probe evidence and unrun e51 native runner remain untouched.

Fresh default-visitor focused UI proof is a prerequisite; it must not be carried from e51 to changed Eae/Fort/Pullman code. This is focused native card/ground/confidence regression, not the whole 15-part smoke, historical camera calibration, door traversal or final ticket signoff. No canonical source or Git metadata writes are authorized.
