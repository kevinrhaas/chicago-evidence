from pathlib import Path
import json,os,subprocess,hashlib,importlib.util,sys,concurrent.futures
R=Path('/workspace/chicago-bridge-increment-20261102');A=R/'chicago/4d';O=Path('/workspace/wolf-integration-01a-20261103');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');BASE='b61c3ffc783e46c3b2aae9944954344e6483fff6';OURS='e51af51e7723b1f39586e204f29b64f15263b920';TIP='01a82b38666715230edf114b514f66c9ec05d2f9'
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env=E)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('native_registry_merge',A/'tools/merge_asset_registry.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);proof=[]
for rel in ['chicago/4d/assets/manifest.json','chicago/4d/assets/manifest.web.json']:
 reemit={};expected=m.merge_texts(rel,git('show',BASE+':'+rel).decode(),git('show',OURS+':'+rel).decode(),git('show',TIP+':'+rel).decode(),reemit);assert not reemit,reemit;assert (R/rel).read_text()==expected,rel;proof.append({'path':rel,'official_three_way_byte_exact':True,'reemit_required':False})
save('NATIVE-REGISTRY-MERGE-PASS.json',proof)
rel='chicago/4d/docs/LIBERTIES.md';old=git('show',BASE+':'+rel);ours=git('show',OURS+':'+rel);theirs=git('show',TIP+':'+rel)
prior_base=git('show','25cdb2f3f7cf6f5c4847b95dabb137c8391e530e:'+rel);prior_feature=git('show','258ae324686c7bd40159a2e3a04735f90b4e5262:'+rel);assert prior_feature.startswith(prior_base);appendix=prior_feature[len(prior_base):];current=(R/rel).read_bytes()
assert len(appendix)==1863 and ours.count(appendix)==current.count(appendix)==1 and theirs.count(appendix)==0
assert ours.replace(appendix,b'',1)==old and current.replace(appendix,b'',1)==theirs
save('SOURCE-NOTES-PRESERVATION-PASS.json',{'incoming_document_and_own_appendix_exact':True,'own_appendix_bytes':len(appendix),'current_sha256':hashlib.sha256(current).hexdigest(),'method':'Removing the one exact own appendix reconstitutes the entire incoming document byte for byte; union order need not put ours last.'})

rows=json.loads(Path('/workspace/wolf-integration-eae-20261103/TARGET-ASSETS-EXACT.json').read_text())
for row in rows:assert hashlib.sha256((A/row['path']).read_bytes()).hexdigest()==row['sha256'],row
save('TARGET-ASSETS-EXACT.json',rows)
commands=[('native-scene-check',['python3','tools/compile_scene.py','--all','--check']),('native-liberties-check',['python3','tools/compile_liberties.py','--check']),('native-source-use-check',['python3','tools/compile_source_use.py','--check']),('native-dataset-assets-check',['python3','tools/validate.py','--all']),('native-web-assets-check',['python3','tools/measure_web_derivatives.py','--gate','--quiet']),('native-modeltown-check',['python3','tools/model_town_1835.py','--check']),('native-image-bindings-check',['node','tools/image_gate.mjs','--structure','wolf_point_tavern','philo_carpenter_log_shop']),('native-square-tower-fixture',['python3','tools/test_k01_tower.py']),('native-fort-ground',['python3','tools/generate_fort_parade_ground.py','--check']),('native-fort-gates',['node','tools/test_fort_gates.mjs']),('native-fort-gates-measure',['python3','tools/measure_fort_gates.py','--gate','--quiet']),('native-pullman-architrave',['python3','tools/test_k01_architrave.py'])]
def run(item):
 label,cmd=item;p=subprocess.run(['python3',str(O/'run-command.py'),label,str(A),'--',*cmd],cwd=R,env=E);return json.loads((O/(label+'.RESULT.json')).read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:checks=list(pool.map(run,commands))
save('NATIVE-CHECK-RESULTS.json',checks);failed=[r['label']for r in checks if r['exit']!=0];print(json.dumps({'checks':[(r['label'],r['exit'],round(r['seconds'],2))for r in checks],'failed':failed}),flush=True)
if failed:sys.exit(1)
save('TARGETED-NATIVE-ALL-PASS.json',{'status':'LATEST_01A_NATIVE_OWNERS_ASSETS_IMAGES_AND_TOWER_FIXTURE_PASS','rows':checks,'fresh_actual_UI_and_native_card_both_required':True,'final_head_CI_required':True,'duplicated_full_local_four_not_run':True})
