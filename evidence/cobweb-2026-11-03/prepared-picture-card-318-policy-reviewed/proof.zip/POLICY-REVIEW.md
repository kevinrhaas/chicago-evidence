# Policy and unchanged grade wording

Exact AGENTS.md from publicdev318 is included, authenticated Gitblob below.

## Review scope

AGENTS lines152 and157–160 quote the owner’s16October2026 permission: “And I think ok to for native and Métis depictions based on your fair and reasonable judgement, you have been careful and I trust you to make informed and reasonable depictions.” They require evidence bounds, liberties for thin evidence and no invented dialogue or ceremony presented as attested. Lines161–166 retain `review_required`/`touches_removal` and their explanatory prose, but explicitly say “They do not block a scene from being marked released” and quote the owner “Yes lift that.” They name no external reviewer or new approval prerequisite.

The old Cobweb structure note and research dossier retain earlier interpretive-review/no-release wording. That historical prose is not silently deleted; the current AGENTS explicit supersession governs release. This prepared increment adds bibliographic picture context only. It creates no figures, cultural/ceremonial staging, dialogue or new removal narrative. The complete structure before/after comparison proves all review flags and reasons unchanged. This is a scope interpretation based on actual instructions, not a new owner approval or invented institutional permission.

## Linked context does not promote grade

AGENTS137–140: “A detail, an interior, a plan, or a street view the building stands in the corner of does not attest it. The grade is derived, never typed.” The native grader includes a linked illustration only after a solved camera or affirmative pictured ruling; a linked contextual panorama by itself does not do this. Explicit-input native calls produce one link and keep inferred with no depicting pictures. No grader or ruling is changed.

The existing generic inferred `why` remains “Known from maps or written records; no picture of it has been found.” This wording is potentially confusing beside a contextual picture link: under the current rule it means no reasonable building depiction has been established, rather than no contextual image exists. The prepared research-note introduction explicitly identifies the small panorama and its limits. This packet records the generic-wording limitation; it does not weaken the rule, promote grade, change shared grader text or claim a solved comparison. The actual final card must be inspected during native published desktop/mobile qualification.

## Documentation

AGENTS’s How-work-ships section expressly states: “docs/ROADMAP.md is the backlog and docs/STATUS.md is the honest state — update both in the same PR as the work.” The tiny separate append fragments honor that instruction while preserving all existing doc bytes. The authenticated inherited ROADMAP blob already includes non-UTF8 bytes; they are outside this patch’s scope.

## Required final native work

After applying to a separately claimed authored branch, use the current native derivation owners and freshness checks, all four independent foreground `./tools/check.sh --part 1/4` through `--part 4/4`, and the two PR-specific preflight questions. Then publish natively and inspect the actual Images tab in both viewports. Official focused published smoke commands use `SMOKE_VIEWPORT=mobile SMOKE_STAGE=3 node tools/smoke_renderer.mjs --published` and the corresponding desktop command, after checking smoke_budget for the actual diff. Browser GPU and source writer leases must be coordinated. No such final checks have run for this prepared patch.

Authenticated AGENTS Gitblob: `a91fd05f792d1efcff76e67aa9ce1b15ffd17f4e`.
