import json,hashlib,importlib.util,sys,copy
from pathlib import Path
D=Path(__file__).resolve().parent;P=D/'current/chicago/4d/generators/archetypes/log_dwelling_params.py';spec=importlib.util.spec_from_file_location('closed_cobweb_params',P);mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod);record=json.loads((D/'current/chicago/4d/data/structures/cobweb_castle.json').read_text());phase=record['phases'][0];params=mod.from_phase(phase,record);rects=mod.compound_front_rects(params);front=mod.core_front_rects(params);trials=[]
variants={
 'two_front_windows_per_side':lambda ph:ph['form'].update({'front_windows_per_side':{'value':2,'confidence':'reconstructed'}}),
 'attic_end_light':lambda ph:ph['form'].update({'end_openings':{'value':[{'end':'max','kind':'light','at':0.5,'z':3.3}],'confidence':'reconstructed'}}),
 'multiple_central_front_openings':lambda ph:ph['form']['compound_parts']['value'][0].update({'front_opening':['door','window']})}
for name,mutate in variants.items():
 trial=copy.deepcopy(phase);mutate(trial)
 try:mod.from_phase(trial,record);trials.append({'variant':name,'accepted':True})
 except Exception as e:trials.append({'variant':name,'accepted':False,'error_type':type(e).__name__,'error':str(e)})
assert all(not t['accepted'] for t in trials);assert len(front)==1 and front[0][0]=='door'
result={'native_unmodified_params_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'baseline_params_pass':True,'all_compound_front_rects':rects,'central_front_wall_rects':front,'central_front_count':len(front),'gable_light_control_for_this_compound':False,'actual_existing_control_trials':trials,'conclusion':'Source visually supports two lower dark rectangles plus one gable mark, but the current five-room compound only supports one centred door/window per room and no attic opening. Existing generic facade/loft/end controls are explicitly forbidden. No safe data-only opening-count patch is expressible.'};(D/'OPENING-CONTROL-PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
