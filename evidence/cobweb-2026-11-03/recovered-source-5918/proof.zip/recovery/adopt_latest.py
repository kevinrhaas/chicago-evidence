from pathlib import Path
import base64, datetime, hashlib, json, subprocess, zlib

P = Path(__file__).resolve().parent
R = Path('/workspace/chicago-bridge-increment-20261102')
BASE = 'e01634621cfaeee4ba12a5d6743a8367dc54c73c'
TIP = '5918d14dfb9884c41c57d74d24faeef6f583ed9c'
O = P / 'objects'

def api(path):
    return json.loads(subprocess.check_output(['gh', 'api', 'repos/kevinrhaas/chicago/' + path], text=True))

def oid(kind, raw):
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def put(kind, raw, expected):
    assert oid(kind, raw) == expected, ('hash', expected, oid(kind, raw))
    q = O / expected[:2] / expected[2:]
    if not q.exists():
        q.parent.mkdir(exist_ok=True)
        q.write_bytes(zlib.compress(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw))

def commit(sha):
    d = api('git/commits/' + sha)
    (P / ('commit-' + sha + '.json')).write_text(json.dumps(d))
    verification = d.get('verification') or {}
    if verification.get('payload') and verification.get('signature'):
        headers, body = verification['payload'].split('\n\n', 1)
        raw = (headers + '\ngpgsig ' + verification['signature'].replace('\n', '\n ') + '\n\n' + body).encode()
        put('commit', raw, sha)
        return d
    def identity(x, offset):
        t = datetime.datetime.fromisoformat(x['date'].replace('Z', '+00:00'))
        return f"{x['name']} <{x['email']}> {int(t.timestamp())} {offset}"
    offsets = ['+0000', '-0500', '-0600']
    offsets += [f"{'+' if n >= 0 else '-'}{abs(n)//60:02d}{abs(n)%60:02d}" for n in range(-720, 841, 15)]
    for author_offset in dict.fromkeys(offsets):
        for committer_offset in dict.fromkeys(offsets):
            for suffix in ['\n', '']:
                raw = ('tree ' + d['tree']['sha'] + '\n' + ''.join('parent ' + x['sha'] + '\n' for x in d['parents']) + 'author ' + identity(d['author'], author_offset) + '\ncommitter ' + identity(d['committer'], committer_offset) + '\n\n' + d['message'] + suffix).encode()
                if oid('commit', raw) == sha:
                    put('commit', raw, sha)
                    return d
    raise AssertionError(('could not authenticate commit bytes', sha))

comparison = api('compare/' + BASE + '...' + TIP)
assert comparison['behind_by'] == 0 and comparison['ahead_by'] == 4
assert len(comparison['commits']) == 4
for row in comparison['commits']:
    commit(row['sha'])
    print('commit authenticated', row['sha'], flush=True)
head = commit(TIP)
tree = api('git/trees/' + head['tree']['sha'] + '?recursive=1')
assert not tree['truncated']
(P / 'LATEST-tree-api.json').write_text(json.dumps(tree))
directories = {'': {}}
directory_ids = {'': head['tree']['sha']}
files = {}
for entry in tree['tree']:
    parent, _, name = entry['path'].rpartition('/')
    directories.setdefault(parent, {})[name] = entry
    if entry['type'] == 'tree':
        directories.setdefault(entry['path'], {})
        directory_ids[entry['path']] = entry['sha']
    else:
        files[entry['path']] = entry
for path, children in directories.items():
    raw = b''
    for name, entry in sorted(children.items(), key=lambda item: (item[0] + ('/' if item[1]['type'] == 'tree' else '')).encode()):
        raw += entry['mode'].lstrip('0').encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(entry['sha'])
    put('tree', raw, directory_ids[path])
(P / 'LATEST-files.json').write_text(json.dumps(files))
old = json.loads((P / 'HEAD-files.json').read_text())
changed = {path: row for path, row in files.items() if old.get(path, {}).get('sha') != row['sha']}
assert len(changed) < 100
assert sum(row.get('size', 0) for row in changed.values()) < 128 * 1024**2
total = 0
for path, row in changed.items():
    assert row['type'] == 'blob' and row.get('size', 0) < 32 * 1024**2
    data = api('git/blobs/' + row['sha'])
    raw = base64.b64decode(data['content'])
    assert len(raw) == row['size']
    total += len(raw)
    assert total < 128 * 1024**2
    put('blob', raw, row['sha'])
    print('blob authenticated', path, len(raw), flush=True)
(P / 'LATEST-READY.json').write_text(json.dumps({'base': BASE, 'tip': TIP, 'commits': 4, 'changed_blobs': len(changed), 'blob_bytes': total, 'all_hashes_authenticated': True}, indent=2) + '\n')
print('READY', total, flush=True)
