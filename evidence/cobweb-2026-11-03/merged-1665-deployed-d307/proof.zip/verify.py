"""Read-only public delivery verification; does not extend runtime proof scope."""
import argparse
import hashlib
import json
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
HEAD = "07b8ece7c807352ee56ba59d76f76fa54b3691c8"
BASE = "https://chicago.polecat.live/4d/dev/"
PICTURES = "data/pictures/1835.json"
SIDECAR = "data/sidecars/1835/cobweb_castle.json"
MODELS = {
    "data/gltf/green_tree_tavern__frame_1833.glb": "e9688ba27ce9d46a1baf0c00aee020e49c005a362b44c5349f197787824012cc",
    "data/gltf/wolf_point_tavern__log_frame_1828.glb": "fdc5ef22a440636e35e4cec15818661f4351f0f4d0c9e506ef36b00422a45210",
}


def api(path):
    return json.loads(subprocess.check_output(["gh", "api", "repos/kevinrhaas/chicago/" + path], text=True))


def get(path):
    with urlopen(Request(BASE + path + "?pr1665=" + str(time.time_ns()),
                         headers={"Cache-Control": "no-cache"}), timeout=45) as response:
        assert response.status == 200
        data = response.read(2_000_001)
    assert len(data) <= 2_000_000
    return data


def snapshot():
    stamp = get("build.json")
    paths = [PICTURES, SIDECAR, *MODELS]
    with ThreadPoolExecutor(max_workers=4) as pool:
        payloads = dict(zip(paths, pool.map(get, paths)))
    assert stamp == get("build.json"), "Public build changed during snapshot; repeat"
    return json.loads(stamp), {"build.json": stamp, **payloads}


parser = argparse.ArgumentParser()
parser.add_argument("--snapshot-before", action="store_true")
args = parser.parse_args()
if args.snapshot_before:
    build, payloads = snapshot()
    assert not json.loads(payloads[PICTURES])["by_structure"].get("cobweb_castle", [])
    output = ROOT / "before"
    output.mkdir(parents=True, exist_ok=True)
    for path, data in payloads.items():
        target = output / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    print(json.dumps({"status": "PREMERGE_PUBLIC_SNAPSHOT", "build": build["sha"], "cobweb_entries": 0}))
    raise SystemExit()

pr = api("pulls/1665")
assert pr["head"]["sha"] == HEAD, "Review scope changed"
if not pr["merged"]:
    print("NOT_MERGED_YET")
    raise SystemExit(20)
merge = pr["merge_commit_sha"]
build, payloads = snapshot()
assert build["tier"] == "dev" and build["ref"] == "refs/heads/dev"
comparison = api(f"compare/{merge}...{build['sha']}")
if comparison["behind_by"] or comparison["status"] not in ("ahead", "identical"):
    print("MERGED_NOT_DEPLOYED_YET", merge, build["sha"])
    raise SystemExit(21)
for path, expected in MODELS.items():
    assert hashlib.sha256(payloads[path]).hexdigest() == expected, path
pictures = json.loads(payloads[PICTURES])["by_structure"]
rows = pictures["cobweb_castle"]
assert len(rows) == 1
row = rows[0]
assert row["id"] == "kinzie_1857_chicago_1831_panorama"
assert row["rights"] == "public domain"
assert row["url"] == "https://commons.wikimedia.org/wiki/File:Fort_Dearborn_%26_Chicago_in_1831.jpg"
assert not row.get("held") and not row.get("spot")
sidecar = json.loads(payloads[SIDECAR])
assert sidecar["id"] == "cobweb_castle"
assert sidecar["grade"]["value"] == "inferred"
assert "kinzie_1857_chicago_1831_panorama" in sidecar["research_note"]
old = json.loads((ROOT / "before" / PICTURES).read_bytes())["by_structure"]
assert pictures["wolf_point_tavern"] == old["wolf_point_tavern"]
output = ROOT / ("after-" + build["sha"])
output.mkdir(exist_ok=True)
for path, data in payloads.items():
    target = output / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
result = {
    "status": "MERGED_AND_DEPLOYED_DEV_DELIVERY_VERIFIED",
    "at": datetime.now(timezone.utc).isoformat(),
    "pr": 1665, "reviewed_head": HEAD, "merge_commit": merge,
    "deployed_build": build, "deployed_descends_from_merge": True,
    "cobweb_entries": 1, "new_credited_source": row,
    "cobweb_grade": sidecar["grade"], "wolf_entries_exact_before_after": True,
    "files": {path: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
              for path, data in payloads.items()},
    "scope": "Public dev ancestry and static delivery only. Runtime proof remains scoped to reviewed07b8; originalT2374 is partial, with no full image-match claim.",
}
text = json.dumps(result, indent=2) + "\n"
(output / "RESULT.json").write_text(text)
(ROOT / "RESULT.json").write_text(text)
print(json.dumps({"status": result["status"], "merge": merge, "build": build["sha"]}))
