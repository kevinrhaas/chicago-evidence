

### T-2374 picture-card continuation — original ticket remains open

Expose the original keyed 1831 panorama as a credited Images-tab link on Cobweb
Castle’s card. Preserve the same-witness Wau-Bun/Wentworth distinction, the
unresolved compound appearance, partial siding and July 1835 survival. This
increment adds no camera or matched verdict and does not promote the structure’s
grade. Continue the original image gate; file no photo follow-up.
