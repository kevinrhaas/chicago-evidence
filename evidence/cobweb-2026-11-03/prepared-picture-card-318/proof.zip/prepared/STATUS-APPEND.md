

### T-2374 — Cobweb Castle’s original panorama on its card

Partial picture-card increment: the Indian Agency House’s Images tab links the
original ticket’s keyed 1831 panorama through the existing credited, public-domain
Wentworth 1881 source. The small “Agency-House” subject remains retrospective
context, not an accepted match or proof of July 1835 continuity. No geometry,
camera, position, dimensions, form values or grade ruling changes. T-2374 remains
open. Source-gate and actual published desktop/mobile validation must be recorded
on the final authored branch before committing or merging this prepared patch.
