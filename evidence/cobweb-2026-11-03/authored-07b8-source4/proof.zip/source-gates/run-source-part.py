from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, time

P = Path(__file__).resolve().parent
R = Path('/tmp/cobweb-active-20261103')
A = R / 'chicago/4d'
part = int(sys.argv[1])
assert part in (1, 2, 3, 4)
attempt = sys.argv[2] if len(sys.argv) > 2 else ''
assert not attempt or re.fullmatch(r'[a-z0-9_-]+', attempt)
out = P / (f'source-part{part}' + ('-' + attempt if attempt else ''))
assert not out.exists()
out.mkdir()
scratch = Path('/tmp/cobweb-source-checks-20261103')
scratch.mkdir(exist_ok=True)
shim = P / 'strict-fixture-env'
shim.mkdir(exist_ok=True)
target = shim / 'git'
if not target.exists():
    shutil.copyfile(P / 'fixture-git', target)
    target.chmod(0o755)
env = os.environ.copy()
env['PATH'] = str(shim) + os.pathsep + env['PATH']
env['GIT_NO_LAZY_FETCH'] = '1'
env['CHECK_JOBS'] = '4'
env['C4D_GATE_REQUIRE_READERS'] = '1'
env['TMPDIR'] = str(scratch)
env.pop('CHICAGO_TICKETS_DIR', None)
before = {'head': subprocess.check_output(['/usr/local/bin/git', '-C', str(R), 'rev-parse', 'HEAD'], text=True).strip(), 'fixture_shim_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'guard': 'NoLazy1 everywhere except exact native fresh local repo-file-*/leg fixture', 'cpu': [0, 1, 3, 4], 'CHECK_JOBS': 4, 'timeout_seconds': 600}
(out / 'START.json').write_text(json.dumps(before, indent=2) + '\n')
command = ['python', '/workspace/shared/run-with-reaping.py', str(out / 'REAPER.json'), '--', 'timeout', '--signal=TERM', '--kill-after=15s', '600s', 'nice', '-n', '19', 'taskset', '-c', '0,1,3,4', './tools/check.sh', '--part', f'{part}/4']
started = time.monotonic()
with (out / 'native.log').open('wb') as log:
    result = subprocess.run(command, cwd=A, env=env, stdout=log, stderr=subprocess.STDOUT)
reaper = json.loads((out / 'REAPER.json').read_text())
log = (out / 'native.log').read_text(errors='replace')
clean_log = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', log)
passed = result.returncode == 0 and f'CHECK PASS — part {part}/4' in clean_log and reaper['all_children_reaped'] and not reaper['leftover_cleanup']
receipt = {**before, 'status': 'PASS' if passed else 'FAIL', 'exit': result.returncode, 'seconds': time.monotonic() - started, 'reaper_closed': reaper['all_children_reaped'], 'leftovers': reaper['leftover_cleanup'], 'tail': log.splitlines()[-12:]}
(out / 'RESULT.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(0 if passed else result.returncode or 1)
