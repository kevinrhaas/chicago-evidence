# Prepared command — wait for explicit GPU release

No browser/GPU run has started. The only source root used will be read-only independentW at exact520; this does not touch canonicalR.

```bash
source /workspace/shared/resume-chicago-env.sh
python /tmp/next-picture-increment-20261103/private-camera/run-private-diagnostic.py --gpu-lease-released
```

The wrapper invokes the unchanged native CLI fromW/chicago/4d:

```bash
node tools/photo_match.mjs /tmp/next-picture-increment-20261103/private-camera/agency_1831_private.json --glb assets/gltf/cobweb_castle__log_1820.glb --out /tmp/next-picture-increment-20261103/private-camera/native-render
```

The native match record will be beside the privatecamera, **outsideW**. The side-by-side and log are in private native-render.600s parentprocessgroup/subreaper cleanup; exact wholeWtrackedsource/Gitmetadata +originalJPEG/camera/helper before/after guards. Diskfloors stay512MiB workspace/1.8GB TMP. If head/camera/model/photo moved, it refuses rather than changing baselines.

This is one asset-only diagnostic, not an in-app snapshot or an accepted match. Keep the actual20.75pxheldout residual and evaluate tentative rear-ridge correspondence after the real render. The numerical frontfit is not a rendered fit. All canonicalcameras and grade rulings remain untouched.
