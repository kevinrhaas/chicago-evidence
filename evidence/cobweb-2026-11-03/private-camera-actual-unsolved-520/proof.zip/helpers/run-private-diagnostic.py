from pathlib import Path
import argparse,ctypes,hashlib,json,os,signal,subprocess,time,shutil
ap=argparse.ArgumentParser();ap.add_argument('--gpu-lease-released',action='store_true');args=ap.parse_args()
if not args.gpu_lease_released:raise SystemExit('Prepared only. Parent must explicitly release GPU lease before this diagnostic runs.')
O=Path('/tmp/next-picture-increment-20261103');D=O/'private-camera';W=Path('/tmp/wolf-credit-work-20261103');A=W/'chicago/4d';C=D/'agency_1831_private.json';OUT=D/'native-render';OUT.mkdir(exist_ok=True)
assert not (OUT/'RESULT.json').exists(),'Closed diagnostic output already exists; do not overwrite.'
assert shutil.disk_usage('/tmp').free>=1800000000 and shutil.disk_usage('/workspace').free>=536870912,'Required disk floors unavailable'
assert json.loads(C.read_text())['diagnostic_only'] is True
assert hashlib.sha256(C.read_bytes()).hexdigest()=='07f94fa8654e1c0469ad4d3df2c0c01414e15ce5cfabcdadde9260a942ea4977'
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1')
head=subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],env=env,text=True).strip();assert head=='520884613539cec3ba6874a1c82cd5ee377665a9',head
assert hashlib.sha256((A/'assets/gltf/cobweb_castle__log_1820.glb').read_bytes()).hexdigest()=='af1f33c0f5d75fc8c40e6cbb589adfd7d29d551572c2775e236bb260f6ee561f'
assert hashlib.sha256((O/'chicago/chicago/reference/images/chicago/chicago_fort_dearborn_1831_1.jpg').read_bytes()).hexdigest()=='624d8f1f52a75bf30653e8cbf37a388478b0ddf5a02f1fadf727cf2144b84c3f'
# Strict tracked-source byte guards; no Git writes, no native owner invocation.
tracked=subprocess.check_output(['git','-C',str(W),'ls-files','-z'],env=env).split(b'\0');paths=[W/os.fsdecode(p) for p in tracked if p]
paths += [p for p in (W/'.git').rglob('*') if p.is_file() and '/objects/' not in p.as_posix() and '/logs/' not in p.as_posix()]
# Own camera/helper/original-source guard, excluding newly produced match/output files.
paths += [C,Path(__file__),D/'LANDMARK-CANDIDATE.json',O/'chicago/chicago/reference/images/chicago/chicago_fort_dearborn_1831_1.jpg']
paths=sorted(set(paths))
def snapshot():
 out={}
 for p in paths:
  if p.is_symlink():out[str(p)]={'symlink':os.readlink(p)};continue
  if not p.is_file():out[str(p)]={'missing':True};continue
  b=p.read_bytes();out[str(p)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':p.stat().st_mode&0o7777}
 return out
before=snapshot();(OUT/'BEFORE-GUARDS.json').write_text(json.dumps({'head':head,'paths':before},indent=2)+'\n')
# Become a subreaper for this child tree so timed-out browser descendants cannot be orphaned.
ctypes.CDLL(None).prctl(36,1,0,0,0)
cmd=['node','tools/photo_match.mjs',str(C),'--glb','assets/gltf/cobweb_castle__log_1820.glb','--out',str(OUT)]
start=time.monotonic();timed_out=False;cleanup=[]
with (OUT/'native.log').open('wb') as log:
 proc=subprocess.Popen(cmd,cwd=A,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:rc=proc.wait(timeout=600)
 except subprocess.TimeoutExpired:
  timed_out=True
  try:os.killpg(proc.pid,signal.SIGTERM);cleanup.append('SIGTERM_process_group')
  except ProcessLookupError:pass
  try:rc=proc.wait(timeout=5)
  except subprocess.TimeoutExpired:
   try:os.killpg(proc.pid,signal.SIGKILL);cleanup.append('SIGKILL_process_group')
   except ProcessLookupError:pass
   rc=proc.wait(timeout=5)
 # Reap this runner's own adopted descendants; do not touch other agents' processes.
 for attempt in range(20):
  live=[]
  for p in Path('/proc').iterdir():
   if not p.name.isdigit():continue
   try:
    fields=(p/'stat').read_text().rsplit(')',1)[1].split();ppid=int(fields[1]);pgid=int(fields[2]);state=fields[0]
    if ppid==os.getpid() or pgid==proc.pid:live.append((int(p.name),state))
   except (OSError,ValueError):pass
  for pid,state in live:
   if state!='Z':
    try:os.kill(pid,signal.SIGKILL);cleanup.append(f'SIGKILL_own_descendant:{pid}')
    except ProcessLookupError:pass
  while True:
   try:
    pid,_=os.waitpid(-1,os.WNOHANG)
    if pid==0:break
   except ChildProcessError:break
  if not live:break
  time.sleep(.1)
after=snapshot();assert after==before,'Tracked source, Git metadata, original image, camera or helper changed'
match=C.with_suffix('.match.json');side=OUT/(C.stem+'-side-by-side.jpg')
result={'status':'NATIVE_ASSET_ONLY_PRIVATE_DIAGNOSTIC_PASS_UNREVIEWED' if rc==0 and not timed_out else 'NATIVE_DIAGNOSTIC_FAILED_OR_TIMED_OUT','head':head,'command':cmd,'cwd':str(A),'exit_code':rc,'timeout_600s':timed_out,'seconds':round(time.monotonic()-start,3),'source_git_camera_original_guards_exact':True,'guarded_paths':len(before),'cleanup':cleanup,'all_owned_processes_reaped':not live,'match_file':str(match),'side_by_side':str(side),'scope':'One private asset-only diagnostic, no canonical camera, no grade promotion, no authored source gate or in-app UI claim. Numerical frontfit/heldout residual stays unchanged; actual comparison still needs direct review.'}
if match.exists():result['native_match']=json.loads(match.read_text())
(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if rc or timed_out or live:raise SystemExit(1)
