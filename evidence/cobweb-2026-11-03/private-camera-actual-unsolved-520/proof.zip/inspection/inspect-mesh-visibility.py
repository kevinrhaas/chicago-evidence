from pathlib import Path
import json,struct,numpy as np,hashlib
D=Path('/tmp/next-picture-increment-20261103/private-camera');p=Path('/tmp/wolf-credit-work-20261103/chicago/4d/assets/gltf/cobweb_castle__log_1820.glb');raw=p.read_bytes();jlen=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+jlen]);binstart=20+jlen+8
ct={5126:np.dtype('<f4'),5125:np.dtype('<u4'),5123:np.dtype('<u2'),5121:np.dtype('u1')};sz={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def acc(i):
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];dtype=ct[a['componentType']];w=sz[a['type']];offset=binstart+v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',w*dtype.itemsize);return np.ndarray((a['count'],w),dtype=dtype,buffer=raw,offset=offset,strides=(stride,dtype.itemsize)).copy()
tri=[];material=[]
for pp in g['meshes'][0]['primitives']:
 xyz=acc(pp['attributes']['POSITION']);idx=acc(pp['indices']).ravel();tt=xyz[idx].reshape((-1,3,3));tri.append(tt);material.extend([g['materials'][pp['material']]['name']]*len(tt))
T=np.concatenate(tri).astype(float);e1=T[:,1]-T[:,0];e2=T[:,2]-T[:,0];cam=json.loads((D/'agency_1831_private.json').read_text());u,v,y=cam['eye'];eye=np.array([u,y,-v]);rows=[]
points=[('centralfrontdoorcentre',[6.5,9.06,1.1]),('centralfrontwallcentre',[6.5,9.04,2.1]),('centralfrontgablecentre',[6.5,9.251,3.3]),('centralfrontgableapex',[6.5,9.25,4.525570869445801])]
for name,(u,v,h) in points:
 pt=np.array([u,h,-v]);delta=pt-eye;length=np.linalg.norm(delta);direction=delta/length;hv=np.cross(np.repeat(direction[None,:],len(T),axis=0),e2);det=np.einsum('ij,ij->i',e1,hv);ok=np.abs(det)>1e-9;inv=np.zeros(len(T));inv[ok]=1/det[ok];s=eye-T[:,0];a=inv*np.einsum('ij,ij->i',s,hv);q=np.cross(s,e1);b=inv*np.einsum('j,ij->i',direction,q);distance=inv*np.einsum('ij,ij->i',e2,q);ok &= (a>=-1e-6)&(b>=-1e-6)&(a+b<=1+1e-6)&(distance>0)&(distance<length-.005);hits=np.where(ok)[0];hits=hits[np.argsort(distance[hits])];rows.append({'point':name,'uvy':[u,v,h],'target_distance_m':length,'occluding_intersections':[{'material':material[i],'distance_before_target_m':float(length-distance[i]),'world_uvy':(eye+direction*distance[i])[[0,2,1]].tolist()}for i in hits[:5]],'unoccluded_to_5mm':len(hits)==0})
(D/'MESH-VISIBILITY-CHECK.json').write_text(json.dumps({'status':'OFFLINE_RAY_TRIANGLE_CHECK_NO_GPU','master_sha256':hashlib.sha256(raw).hexdigest(),'triangles':len(T),'rows':rows},indent=2)+'\n');print(json.dumps(rows))
