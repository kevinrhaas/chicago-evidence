# Asset licenses

Every file under `assets/` needs an entry here, matched by its path relative to
`assets/`. `tools/check.sh` fails if one is missing. CC0 and CC-BY only unless a
clearance is recorded below.

Generated output (`gltf/`, `web/`) is covered by the project's own license and by the
provenance of the data it was generated from — but any **texture, audio, or authored
asset** brought in from outside needs its own row, with a URL and the license name.

Two files here are build RECORDS rather than assets, carry no third-party content, and
are covered by the project's own license along with the output they describe:
`manifest.json`, written by the Blender build, records data → master; and
`manifest.web.json`, written by `tools/web_derivatives.sh`, records master →
derivative (ROADMAP K39). A third, `manifest.versions.json`, records both links for
the structure VERSIONS under `gltf/versions/` and `web/versions/` (T-1727) — generated
output of the same kind, from alternate records under `data/structures/versions/`.

## Rights gating

A source whose `rights_status` is `check_required` or `restricted` in `data/sources/`
may be cited in text but **must not have assets derived from it**. The validator
enforces this against the source's `asset_use` field. Currently gated:

| source | status | why |
|---|---|---|
| `conley_stelzer_1933` | `check_required` | 1933 US publication; BPL asserts no known restrictions but a dealer reports a 1933 copyright stamp. Public domain only if the 1961 renewal lapsed. Run a Stanford Copyright Renewal Database check and record the outcome in the source record before deriving any asset. |
| `chicagology_*` | `check_required` | The site carries no license statement. It is a transcription and finding aid; re-source every image from the holding institution before it enters the model. |
| `drloih_hotels` | `check_required` | Unfootnoted blog; leads only. |

## Recorded clearances — the CC0/CC-BY default, excepted

The default above is CC0 and CC-BY only. Each exception is a decision recorded here,
with what it permits and what it does not.

| item | licence | cleared for | NOT cleared for |
|---|---|---|---|
| `data/sources/assets/saari_2018_dupage_tallgrass/dupage_tallgrass_2018-07-24.jpg` — Cassi Saari, *Restored tallgrass prairie in DuPage County, Illinois*, 24 July 2018, [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Restored_tallgrass_prairie_in_DuPage_County,_Illinois.jpg) | **CC BY-SA 4.0**, attribution required | **Verbatim redistribution in this repository, and measurement.** Committed byte-for-byte unmodified (SHA-1 `0da00f1178e7790b04c05364d78f7cb6a43992ae`, identical to the Commons API's SHA-1 for the file page), so what is redistributed is the licensed work and not an adaptation — ShareAlike is not triggered. Source record `saari_2018_dupage_tallgrass`; attribution carried there, in the README beside the image, and here. | **Any derived asset.** A crop, a resample, a texture, a colour LUT or a tile built from it is an adaptation, and CC BY-SA 4.0 would require releasing that adaptation under CC BY-SA 4.0. This project derives nothing from it: it is read by `tools/measure_reference.py` and never enters a scene. `tools/publish.sh` does not copy `data/sources/`, so it is not on the published site. Anyone wanting to derive from it must take the ShareAlike obligation on deliberately, not by accident. |
| `data/sources/assets/samstone_2017_tallgrass_trail/tallgrass_prairie_trail_2017-09-08.jpg` — Samstone13, *Tallgrass Prairie Trail*, 8 September 2017, [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Tallgrass_Prairie_Trail.jpg) | **CC BY-SA 4.0**, attribution required | **Verbatim redistribution in this repository, and measurement.** Committed byte-for-byte unmodified (SHA-1 `c2da32962b8c4ddb73b8f2cd36f4a39abeff7628`), so what is redistributed is the licensed work and not an adaptation — ShareAlike is not triggered. Source record `samstone_2017_tallgrass_trail`; it is the road-contrast reference for R-M1b. | **Any derived asset.** A crop, a resample, a texture or a tile built from it is an adaptation and would have to be released under CC BY-SA 4.0. This project derives nothing from it: it is measured and never enters a scene. `tools/publish.sh` does not copy `data/sources/`, so it is not on the published site. |
| `data/sources/assets/haas_2021_sagebrush_two_track/sagebrush_two_track_2021-06-26.jpg` — Kevin Haas, *Earth two-track through sagebrush steppe*, 26 June 2021 | **All rights reserved.** The owner's own photograph, deliberately NOT under an open licence | **Reading it, to check the figures derived from it.** Committed verbatim (SHA-1 `9fdb465d952b98adb6ada9356f21df8c76897bd1`, 4032x3024) so a reader can verify a measurement against the pixels it came from — which is this project's standard and why it is committed rather than withheld. Source record `haas_2021_sagebrush_two_track`; it is the far-band road-contrast reference for R-M1b. | **Reuse of any kind.** No redistribution, no republication, no derived asset — not a crop, a resample, a texture or a tile. VISIBLE IS NOT REUSABLE: this is the one row in this table outside the CC0/CC-BY default, at the owner's direction of 2026-08-15. `tools/publish.sh` does not copy `data/sources/`, so it is not on the published site. |

| `gifford_tremont_house_no_1` — N. Roswell Gifford, first Tremont drawing, reproduced by [Chicagology](https://chicagology.com/prefire/prefire021/) | **Owner-approved attributed project use**, 2026-10-22; original publication/collection and copyright status unresolved | Reference, picture comparison/source display and this project’s explicitly reconstructed Tremont appearance. Credit and source link retained in the source record and research comparison. Generated model contains no external image texture. | Public-domain status, copyright-holder permission, an open redistribution licence or any geographic/metric survey claim. |

Held out of the published tree entirely, by the user's instruction:

| item | disposition |
|---|---|
| `chicago/reference/photos/old-chicago-complete-map.png` (Nelson & Winters, *Old Chicago*, © 1940) | **Reference and research only — never published**, per Kevin's instruction. Now formally citable as `nelson_winters_1940` in `data/sources/` (tier 6, `asset_use: orientation`): toponym and trail-network cross-checks only, no geometry, never sole evidence. Public domain only if the 1968 renewal lapsed — unchecked. |

## Third-party assets

### The 1835 PBR texture library — `textures/chicago_1835_pbr/`

The first texture arrival this file anticipated. Supplied by the owner 2026-09-19; 25
materials, procedurally synthesised by the generator that ships inside it
(`tools/generate_1835_pbr_library.py`, seeded per material, deterministic). Provenance and
the measurements that say which maps may be bound to a surface are in
`docs/RESEARCH/texture_library.md`; adoption is T-1450.

| item | licence | cleared for | NOT cleared for |
|---|---|---|---|
| `textures/chicago_1835_pbr/**` — *Chicago 1835 PBR Texture Library v1.0.0*, original procedural output generated for this project. Full text at `textures/chicago_1835_pbr/LICENSE.txt` | **Project-permissive, CC0-equivalent.** "The maps and generator may be used, modified, and redistributed with the project." No third-party photograph is embedded or sampled in the production maps | **Use, modification and redistribution with the project**, including derived and regenerated maps — the generator ships, so a map may be re-derived rather than re-authored. | **Stripping the confidence labels.** The licence carries one condition and it is this project's own standard: *"Historical confidence labels and provenance notes should remain attached so reconstructed surfaces are not silently represented as attested evidence."* Every `material.json` carries its `confidence` tier and its note, and they travel with the maps. |
| `textures/chicago_1835_pbr/tools/source_mud_ai.png` — the flat-lit mud study `muddy_rutted_street` is derived from | as above | **Reading, and deriving the mud maps from it**, which is what it is for | **Being described as a photograph.** It is an AI-generated study, not a camera image and not a period source. It is evidence of nothing about 1835 and is committed so the derivation can be checked. |

**Not published.** `tools/publish.sh` copies named files and `assets/web/*.glb`; it does not
walk `assets/`, so this directory stays in the repository and off the live site. It is carried
for the web renderer's relief maps and for the Unreal target's DirectX normals, packed ORM and
16-bit displacement. The `.webp` beside ten of the maps is a lossless derivative of
its PNG master, the same pixels in fewer bytes, written and held pixel-identical by
`tools/web_textures.py` (T-1973). Beside the two signboard-wood sheets the same tool writes
four DERIVED tiles instead (T-2590): `_grain.webp`, the basecolor's grain read down to 512²,
turned a quarter and normalised about mid-grey, and `_normal_turned.webp`, the normal read
down and turned with its vectors — what `renderers/web/js/signage.js` used to compute from
the maps at every boot, now computed once and held to that computation pixel for pixel.
Those fourteen are the one exception to "not published": `tools/publish.sh` copies them by
name to `data/textures/`, where the relief modules bind them. They carry the library's
licence and its one condition unchanged.

**The `.ktx2` beside six of them (T-2582, T-2590)** — the two roof coverings' `normal_gl`
and `orm` and the wet prairie muck's and the dune sand's basecolor — is the same map
GPU-compressed by
`tools/ktx2_sheets.py` with KTX-Software 4.3.2 (Basis Universal: ETC1S for the colour, UASTC
for the data maps), from the PNG master. It is lossy where the `.webp` is not, a derivative
for the GPU and not a new map, and `tools/publish.sh` copies it by name beside its `.webp`
or `.png`. It carries the library's licence and its one condition unchanged. The sand's
`_basecolor.luma.json` beside it is one number derived from its master by the same tool
— the mean linear luminance the ground strip once read from the image's pixels — and
carries no pixels at all.

**The wall relief's `.ktx2` and its statement (T-2588)** — `clapboard_board_face` and
`hewn_log_face` each carry a `_normal_gl.ktx2` (the normal, UASTC) and an `_orl.ktx2`, the
map `renderers/web/js/relief-pack.js` used to pack in the page from the `orm` and the
basecolor (R = AO, G = roughness, B = the basecolor's luminance over its mean; ETC1S), written
by `tools/ktx2_sheets.py` from the PNG masters, plus `_orl.json` stating the mean roughness
and the masters' hashes. Derivatives of the library's own maps, lossy, for the GPU; they
carry the library's licence and its one condition unchanged.

**The frontage timber's two (T-2589)** — the board face's `orm` and
`clapboard_board_face_grain.ktx2`, the albedo modulation `renderers/web/js/frontage.js` used to
derive from the basecolor at load — are written the same way by the same tool, from the PNG
masters (the grain from the basecolor master, by `packGrain`'s own arithmetic); the layer's
normal is the wall's `_normal_gl.ktx2` above. The grain is a derived map of the library's
basecolor, not a new image; both carry the library's licence and its one condition unchanged.

Every file, as the checker matches them one by one:

```
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_basecolor.webp
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_normal_gl.ktx2
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_normal_gl.webp
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_orl.json
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_orl.ktx2
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_orm.webp
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_basecolor.webp
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_normal_gl.ktx2
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_normal_gl.webp
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_orl.json
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_orl.ktx2
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_orm.webp
textures/chicago_1835_pbr/LICENSE.txt
textures/chicago_1835_pbr/README.md
textures/chicago_1835_pbr/RESEARCH_NOTES.md
textures/chicago_1835_pbr/contact_sheet.jpg
textures/chicago_1835_pbr/ground/lake_michigan_dune_sand/lake_michigan_dune_sand_ao.png
textures/chicago_1835_pbr/ground/lake_michigan_dune_sand/lake_michigan_dune_sand_basecolor.ktx2
textures/chicago_1835_pbr/ground/lake_michigan_dune_sand/lake_michigan_dune_sand_basecolor.luma.json
textures/chicago_1835_pbr/ground/lake_michigan_dune_sand/lake_michigan_dune_sand_basecolor.png
textures/chicago_1835_pbr/ground/lake_michigan_dune_sand/lake_michigan_dune_sand_height16.png
textures/chicago_1835_pbr/ground/lake_michigan_dune_sand/lake_michigan_dune_sand_metallic.png
textures/chicago_1835_pbr/ground/lake_michigan_dune_sand/lake_michigan_dune_sand_normal_dx.png
textures/chicago_1835_pbr/ground/lake_michigan_dune_sand/lake_michigan_dune_sand_normal_gl.png
textures/chicago_1835_pbr/ground/lake_michigan_dune_sand/lake_michigan_dune_sand_orm.png
textures/chicago_1835_pbr/ground/lake_michigan_dune_sand/lake_michigan_dune_sand_roughness.png
textures/chicago_1835_pbr/ground/lake_michigan_dune_sand/material.json
textures/chicago_1835_pbr/ground/muddy_rutted_street/material.json
textures/chicago_1835_pbr/ground/muddy_rutted_street/muddy_rutted_street_ao.png
textures/chicago_1835_pbr/ground/muddy_rutted_street/muddy_rutted_street_basecolor.png
textures/chicago_1835_pbr/ground/muddy_rutted_street/muddy_rutted_street_height16.png
textures/chicago_1835_pbr/ground/muddy_rutted_street/muddy_rutted_street_metallic.png
textures/chicago_1835_pbr/ground/muddy_rutted_street/muddy_rutted_street_normal_dx.png
textures/chicago_1835_pbr/ground/muddy_rutted_street/muddy_rutted_street_normal_gl.png
textures/chicago_1835_pbr/ground/muddy_rutted_street/muddy_rutted_street_orm.png
textures/chicago_1835_pbr/ground/muddy_rutted_street/muddy_rutted_street_roughness.png
textures/chicago_1835_pbr/ground/packed_black_loam/material.json
textures/chicago_1835_pbr/ground/packed_black_loam/packed_black_loam_ao.png
textures/chicago_1835_pbr/ground/packed_black_loam/packed_black_loam_basecolor.png
textures/chicago_1835_pbr/ground/packed_black_loam/packed_black_loam_height16.png
textures/chicago_1835_pbr/ground/packed_black_loam/packed_black_loam_metallic.png
textures/chicago_1835_pbr/ground/packed_black_loam/packed_black_loam_normal_dx.png
textures/chicago_1835_pbr/ground/packed_black_loam/packed_black_loam_normal_gl.png
textures/chicago_1835_pbr/ground/packed_black_loam/packed_black_loam_orm.png
textures/chicago_1835_pbr/ground/packed_black_loam/packed_black_loam_roughness.png
textures/chicago_1835_pbr/ground/river_stone_gravel_fill/material.json
textures/chicago_1835_pbr/ground/river_stone_gravel_fill/river_stone_gravel_fill_ao.png
textures/chicago_1835_pbr/ground/river_stone_gravel_fill/river_stone_gravel_fill_basecolor.png
textures/chicago_1835_pbr/ground/river_stone_gravel_fill/river_stone_gravel_fill_height16.png
textures/chicago_1835_pbr/ground/river_stone_gravel_fill/river_stone_gravel_fill_metallic.png
textures/chicago_1835_pbr/ground/river_stone_gravel_fill/river_stone_gravel_fill_normal_dx.png
textures/chicago_1835_pbr/ground/river_stone_gravel_fill/river_stone_gravel_fill_normal_gl.png
textures/chicago_1835_pbr/ground/river_stone_gravel_fill/river_stone_gravel_fill_orm.png
textures/chicago_1835_pbr/ground/river_stone_gravel_fill/river_stone_gravel_fill_roughness.png
textures/chicago_1835_pbr/ground/wet_prairie_muck/material.json
textures/chicago_1835_pbr/ground/wet_prairie_muck/wet_prairie_muck_ao.png
textures/chicago_1835_pbr/ground/wet_prairie_muck/wet_prairie_muck_basecolor.ktx2
textures/chicago_1835_pbr/ground/wet_prairie_muck/wet_prairie_muck_basecolor.png
textures/chicago_1835_pbr/ground/wet_prairie_muck/wet_prairie_muck_height16.png
textures/chicago_1835_pbr/ground/wet_prairie_muck/wet_prairie_muck_metallic.png
textures/chicago_1835_pbr/ground/wet_prairie_muck/wet_prairie_muck_normal_dx.png
textures/chicago_1835_pbr/ground/wet_prairie_muck/wet_prairie_muck_normal_gl.png
textures/chicago_1835_pbr/ground/wet_prairie_muck/wet_prairie_muck_orm.png
textures/chicago_1835_pbr/ground/wet_prairie_muck/wet_prairie_muck_roughness.png
textures/chicago_1835_pbr/manifest.json
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_ao.png
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_basecolor.png
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_height16.png
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_metallic.png
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_normal_dx.png
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_normal_gl.png
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_orm.png
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/cat_and_clay_chimney_roughness.png
textures/chicago_1835_pbr/masonry/cat_and_clay_chimney/material.json
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_ao.png
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_basecolor.png
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_height16.png
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_metallic.png
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_normal_dx.png
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_normal_gl.png
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_orm.png
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/chicago_clay_brick_lime_mortar_roughness.png
textures/chicago_1835_pbr/masonry/chicago_clay_brick_lime_mortar/material.json
textures/chicago_1835_pbr/masonry/limestone_rubble_lime_mortar/limestone_rubble_lime_mortar_ao.png
textures/chicago_1835_pbr/masonry/limestone_rubble_lime_mortar/limestone_rubble_lime_mortar_basecolor.png
textures/chicago_1835_pbr/masonry/limestone_rubble_lime_mortar/limestone_rubble_lime_mortar_height16.png
textures/chicago_1835_pbr/masonry/limestone_rubble_lime_mortar/limestone_rubble_lime_mortar_metallic.png
textures/chicago_1835_pbr/masonry/limestone_rubble_lime_mortar/limestone_rubble_lime_mortar_normal_dx.png
textures/chicago_1835_pbr/masonry/limestone_rubble_lime_mortar/limestone_rubble_lime_mortar_normal_gl.png
textures/chicago_1835_pbr/masonry/limestone_rubble_lime_mortar/limestone_rubble_lime_mortar_orm.png
textures/chicago_1835_pbr/masonry/limestone_rubble_lime_mortar/limestone_rubble_lime_mortar_roughness.png
textures/chicago_1835_pbr/masonry/limestone_rubble_lime_mortar/material.json
textures/chicago_1835_pbr/props/blue_painted_shutter/blue_painted_shutter_ao.png
textures/chicago_1835_pbr/props/blue_painted_shutter/blue_painted_shutter_basecolor.png
textures/chicago_1835_pbr/props/blue_painted_shutter/blue_painted_shutter_height16.png
textures/chicago_1835_pbr/props/blue_painted_shutter/blue_painted_shutter_metallic.png
textures/chicago_1835_pbr/props/blue_painted_shutter/blue_painted_shutter_normal_dx.png
textures/chicago_1835_pbr/props/blue_painted_shutter/blue_painted_shutter_normal_gl.png
textures/chicago_1835_pbr/props/blue_painted_shutter/blue_painted_shutter_orm.png
textures/chicago_1835_pbr/props/blue_painted_shutter/blue_painted_shutter_roughness.png
textures/chicago_1835_pbr/props/blue_painted_shutter/material.json
textures/chicago_1835_pbr/props/signboard_weathered/material.json
textures/chicago_1835_pbr/props/signboard_weathered/signboard_weathered_ao.png
textures/chicago_1835_pbr/props/signboard_weathered/signboard_weathered_basecolor.png
textures/chicago_1835_pbr/props/signboard_weathered/signboard_weathered_grain.webp
textures/chicago_1835_pbr/props/signboard_weathered/signboard_weathered_height16.png
textures/chicago_1835_pbr/props/signboard_weathered/signboard_weathered_metallic.png
textures/chicago_1835_pbr/props/signboard_weathered/signboard_weathered_normal_dx.png
textures/chicago_1835_pbr/props/signboard_weathered/signboard_weathered_normal_gl.png
textures/chicago_1835_pbr/props/signboard_weathered/signboard_weathered_normal_turned.webp
textures/chicago_1835_pbr/props/signboard_weathered/signboard_weathered_orm.png
textures/chicago_1835_pbr/props/signboard_weathered/signboard_weathered_roughness.png
textures/chicago_1835_pbr/props/wrought_iron_forged/material.json
textures/chicago_1835_pbr/props/wrought_iron_forged/wrought_iron_forged_ao.png
textures/chicago_1835_pbr/props/wrought_iron_forged/wrought_iron_forged_basecolor.png
textures/chicago_1835_pbr/props/wrought_iron_forged/wrought_iron_forged_height16.png
textures/chicago_1835_pbr/props/wrought_iron_forged/wrought_iron_forged_metallic.png
textures/chicago_1835_pbr/props/wrought_iron_forged/wrought_iron_forged_normal_dx.png
textures/chicago_1835_pbr/props/wrought_iron_forged/wrought_iron_forged_normal_gl.png
textures/chicago_1835_pbr/props/wrought_iron_forged/wrought_iron_forged_orm.png
textures/chicago_1835_pbr/props/wrought_iron_forged/wrought_iron_forged_roughness.png
textures/chicago_1835_pbr/roofs/roof_boards_weathered/material.json
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_ao.png
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_basecolor.png
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_height16.png
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_metallic.png
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_normal_dx.png
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_normal_gl.ktx2
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_normal_gl.png
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_normal_gl.webp
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_orm.ktx2
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_orm.png
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_orm.webp
textures/chicago_1835_pbr/roofs/roof_boards_weathered/roof_boards_weathered_roughness.png
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/material.json
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_ao.png
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_basecolor.png
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_basecolor.webp
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_height16.png
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_metallic.png
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_normal_dx.png
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_normal_gl.ktx2
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_normal_gl.png
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_normal_gl.webp
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_orl.json
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_orl.ktx2
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_orm.png
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_orm.webp
textures/chicago_1835_pbr/roofs/wood_shingles_weathered/wood_shingles_weathered_roughness.png
textures/chicago_1835_pbr/timber/fresh_sawn_framing/fresh_sawn_framing_ao.png
textures/chicago_1835_pbr/timber/fresh_sawn_framing/fresh_sawn_framing_basecolor.png
textures/chicago_1835_pbr/timber/fresh_sawn_framing/fresh_sawn_framing_height16.png
textures/chicago_1835_pbr/timber/fresh_sawn_framing/fresh_sawn_framing_metallic.png
textures/chicago_1835_pbr/timber/fresh_sawn_framing/fresh_sawn_framing_normal_dx.png
textures/chicago_1835_pbr/timber/fresh_sawn_framing/fresh_sawn_framing_normal_gl.png
textures/chicago_1835_pbr/timber/fresh_sawn_framing/fresh_sawn_framing_orm.png
textures/chicago_1835_pbr/timber/fresh_sawn_framing/fresh_sawn_framing_roughness.png
textures/chicago_1835_pbr/timber/fresh_sawn_framing/material.json
textures/chicago_1835_pbr/timber/heavy_timber_weathered/heavy_timber_weathered_ao.png
textures/chicago_1835_pbr/timber/heavy_timber_weathered/heavy_timber_weathered_basecolor.png
textures/chicago_1835_pbr/timber/heavy_timber_weathered/heavy_timber_weathered_grain.webp
textures/chicago_1835_pbr/timber/heavy_timber_weathered/heavy_timber_weathered_height16.png
textures/chicago_1835_pbr/timber/heavy_timber_weathered/heavy_timber_weathered_metallic.png
textures/chicago_1835_pbr/timber/heavy_timber_weathered/heavy_timber_weathered_normal_dx.png
textures/chicago_1835_pbr/timber/heavy_timber_weathered/heavy_timber_weathered_normal_gl.png
textures/chicago_1835_pbr/timber/heavy_timber_weathered/heavy_timber_weathered_normal_turned.webp
textures/chicago_1835_pbr/timber/heavy_timber_weathered/heavy_timber_weathered_orm.png
textures/chicago_1835_pbr/timber/heavy_timber_weathered/heavy_timber_weathered_roughness.png
textures/chicago_1835_pbr/timber/heavy_timber_weathered/material.json
textures/chicago_1835_pbr/timber/sawn_board_weathered/material.json
textures/chicago_1835_pbr/timber/sawn_board_weathered/sawn_board_weathered_ao.png
textures/chicago_1835_pbr/timber/sawn_board_weathered/sawn_board_weathered_basecolor.png
textures/chicago_1835_pbr/timber/sawn_board_weathered/sawn_board_weathered_height16.png
textures/chicago_1835_pbr/timber/sawn_board_weathered/sawn_board_weathered_metallic.png
textures/chicago_1835_pbr/timber/sawn_board_weathered/sawn_board_weathered_normal_dx.png
textures/chicago_1835_pbr/timber/sawn_board_weathered/sawn_board_weathered_normal_gl.png
textures/chicago_1835_pbr/timber/sawn_board_weathered/sawn_board_weathered_orm.png
textures/chicago_1835_pbr/timber/sawn_board_weathered/sawn_board_weathered_roughness.png
textures/chicago_1835_pbr/tools/generate_1835_pbr_library.py
textures/chicago_1835_pbr/tools/source_mud_ai.png
textures/chicago_1835_pbr/walls/board_and_batten_weathered/board_and_batten_weathered_ao.png
textures/chicago_1835_pbr/walls/board_and_batten_weathered/board_and_batten_weathered_basecolor.png
textures/chicago_1835_pbr/walls/board_and_batten_weathered/board_and_batten_weathered_height16.png
textures/chicago_1835_pbr/walls/board_and_batten_weathered/board_and_batten_weathered_metallic.png
textures/chicago_1835_pbr/walls/board_and_batten_weathered/board_and_batten_weathered_normal_dx.png
textures/chicago_1835_pbr/walls/board_and_batten_weathered/board_and_batten_weathered_normal_gl.png
textures/chicago_1835_pbr/walls/board_and_batten_weathered/board_and_batten_weathered_orm.png
textures/chicago_1835_pbr/walls/board_and_batten_weathered/board_and_batten_weathered_roughness.png
textures/chicago_1835_pbr/walls/board_and_batten_weathered/material.json
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_ao.png
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_basecolor.png
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_basecolor.webp
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_grain.ktx2
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_height16.png
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_metallic.png
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_normal_dx.png
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_normal_gl.ktx2
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_normal_gl.png
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_normal_gl.webp
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_orm.ktx2
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_orm.png
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_orm.webp
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_orl.json
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_orl.ktx2
textures/chicago_1835_pbr/walls/clapboard_board_face/clapboard_board_face_roughness.png
textures/chicago_1835_pbr/walls/clapboard_board_face/material.json
textures/chicago_1835_pbr/walls/clapboard_red_oxide/clapboard_red_oxide_ao.png
textures/chicago_1835_pbr/walls/clapboard_red_oxide/clapboard_red_oxide_basecolor.png
textures/chicago_1835_pbr/walls/clapboard_red_oxide/clapboard_red_oxide_height16.png
textures/chicago_1835_pbr/walls/clapboard_red_oxide/clapboard_red_oxide_metallic.png
textures/chicago_1835_pbr/walls/clapboard_red_oxide/clapboard_red_oxide_normal_dx.png
textures/chicago_1835_pbr/walls/clapboard_red_oxide/clapboard_red_oxide_normal_gl.png
textures/chicago_1835_pbr/walls/clapboard_red_oxide/clapboard_red_oxide_orm.png
textures/chicago_1835_pbr/walls/clapboard_red_oxide/clapboard_red_oxide_roughness.png
textures/chicago_1835_pbr/walls/clapboard_red_oxide/material.json
textures/chicago_1835_pbr/walls/clapboard_weathered_oak/clapboard_weathered_oak_ao.png
textures/chicago_1835_pbr/walls/clapboard_weathered_oak/clapboard_weathered_oak_basecolor.png
textures/chicago_1835_pbr/walls/clapboard_weathered_oak/clapboard_weathered_oak_height16.png
textures/chicago_1835_pbr/walls/clapboard_weathered_oak/clapboard_weathered_oak_metallic.png
textures/chicago_1835_pbr/walls/clapboard_weathered_oak/clapboard_weathered_oak_normal_dx.png
textures/chicago_1835_pbr/walls/clapboard_weathered_oak/clapboard_weathered_oak_normal_gl.png
textures/chicago_1835_pbr/walls/clapboard_weathered_oak/clapboard_weathered_oak_orm.png
textures/chicago_1835_pbr/walls/clapboard_weathered_oak/clapboard_weathered_oak_roughness.png
textures/chicago_1835_pbr/walls/clapboard_weathered_oak/material.json
textures/chicago_1835_pbr/walls/clapboard_white_lead_paint/clapboard_white_lead_paint_ao.png
textures/chicago_1835_pbr/walls/clapboard_white_lead_paint/clapboard_white_lead_paint_basecolor.png
textures/chicago_1835_pbr/walls/clapboard_white_lead_paint/clapboard_white_lead_paint_height16.png
textures/chicago_1835_pbr/walls/clapboard_white_lead_paint/clapboard_white_lead_paint_metallic.png
textures/chicago_1835_pbr/walls/clapboard_white_lead_paint/clapboard_white_lead_paint_normal_dx.png
textures/chicago_1835_pbr/walls/clapboard_white_lead_paint/clapboard_white_lead_paint_normal_gl.png
textures/chicago_1835_pbr/walls/clapboard_white_lead_paint/clapboard_white_lead_paint_orm.png
textures/chicago_1835_pbr/walls/clapboard_white_lead_paint/clapboard_white_lead_paint_roughness.png
textures/chicago_1835_pbr/walls/clapboard_white_lead_paint/material.json
textures/chicago_1835_pbr/walls/clapboard_whitewash/clapboard_whitewash_ao.png
textures/chicago_1835_pbr/walls/clapboard_whitewash/clapboard_whitewash_basecolor.png
textures/chicago_1835_pbr/walls/clapboard_whitewash/clapboard_whitewash_height16.png
textures/chicago_1835_pbr/walls/clapboard_whitewash/clapboard_whitewash_metallic.png
textures/chicago_1835_pbr/walls/clapboard_whitewash/clapboard_whitewash_normal_dx.png
textures/chicago_1835_pbr/walls/clapboard_whitewash/clapboard_whitewash_normal_gl.png
textures/chicago_1835_pbr/walls/clapboard_whitewash/clapboard_whitewash_orm.png
textures/chicago_1835_pbr/walls/clapboard_whitewash/clapboard_whitewash_roughness.png
textures/chicago_1835_pbr/walls/clapboard_whitewash/material.json
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_ao.png
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_basecolor.png
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_basecolor.webp
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_height16.png
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_metallic.png
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_normal_dx.png
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_normal_gl.png
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_normal_gl.ktx2
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_normal_gl.webp
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_orm.png
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_orm.webp
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_orl.json
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_orl.ktx2
textures/chicago_1835_pbr/walls/hewn_log_face/hewn_log_face_roughness.png
textures/chicago_1835_pbr/walls/hewn_log_face/material.json
textures/chicago_1835_pbr/walls/hewn_log_oak_chinked/hewn_log_oak_chinked_ao.png
textures/chicago_1835_pbr/walls/hewn_log_oak_chinked/hewn_log_oak_chinked_basecolor.png
textures/chicago_1835_pbr/walls/hewn_log_oak_chinked/hewn_log_oak_chinked_height16.png
textures/chicago_1835_pbr/walls/hewn_log_oak_chinked/hewn_log_oak_chinked_metallic.png
textures/chicago_1835_pbr/walls/hewn_log_oak_chinked/hewn_log_oak_chinked_normal_dx.png
textures/chicago_1835_pbr/walls/hewn_log_oak_chinked/hewn_log_oak_chinked_normal_gl.png
textures/chicago_1835_pbr/walls/hewn_log_oak_chinked/hewn_log_oak_chinked_orm.png
textures/chicago_1835_pbr/walls/hewn_log_oak_chinked/hewn_log_oak_chinked_roughness.png
textures/chicago_1835_pbr/walls/hewn_log_oak_chinked/material.json
textures/chicago_1835_pbr/walls/vertical_sawn_board/material.json
textures/chicago_1835_pbr/walls/vertical_sawn_board/vertical_sawn_board_ao.png
textures/chicago_1835_pbr/walls/vertical_sawn_board/vertical_sawn_board_basecolor.png
textures/chicago_1835_pbr/walls/vertical_sawn_board/vertical_sawn_board_height16.png
textures/chicago_1835_pbr/walls/vertical_sawn_board/vertical_sawn_board_metallic.png
textures/chicago_1835_pbr/walls/vertical_sawn_board/vertical_sawn_board_normal_dx.png
textures/chicago_1835_pbr/walls/vertical_sawn_board/vertical_sawn_board_normal_gl.png
textures/chicago_1835_pbr/walls/vertical_sawn_board/vertical_sawn_board_orm.png
textures/chicago_1835_pbr/walls/vertical_sawn_board/vertical_sawn_board_roughness.png
textures/chicago_1835_pbr/waterfront/dock_timber_tar_darkened/dock_timber_tar_darkened_ao.png
textures/chicago_1835_pbr/waterfront/dock_timber_tar_darkened/dock_timber_tar_darkened_basecolor.png
textures/chicago_1835_pbr/waterfront/dock_timber_tar_darkened/dock_timber_tar_darkened_height16.png
textures/chicago_1835_pbr/waterfront/dock_timber_tar_darkened/dock_timber_tar_darkened_metallic.png
textures/chicago_1835_pbr/waterfront/dock_timber_tar_darkened/dock_timber_tar_darkened_normal_dx.png
textures/chicago_1835_pbr/waterfront/dock_timber_tar_darkened/dock_timber_tar_darkened_normal_gl.png
textures/chicago_1835_pbr/waterfront/dock_timber_tar_darkened/dock_timber_tar_darkened_orm.png
textures/chicago_1835_pbr/waterfront/dock_timber_tar_darkened/dock_timber_tar_darkened_roughness.png
textures/chicago_1835_pbr/waterfront/dock_timber_tar_darkened/material.json
textures/chicago_1835_pbr/waterfront/plank_walk_weathered/material.json
textures/chicago_1835_pbr/waterfront/plank_walk_weathered/plank_walk_weathered_ao.png
textures/chicago_1835_pbr/waterfront/plank_walk_weathered/plank_walk_weathered_basecolor.png
textures/chicago_1835_pbr/waterfront/plank_walk_weathered/plank_walk_weathered_height16.png
textures/chicago_1835_pbr/waterfront/plank_walk_weathered/plank_walk_weathered_metallic.png
textures/chicago_1835_pbr/waterfront/plank_walk_weathered/plank_walk_weathered_normal_dx.png
textures/chicago_1835_pbr/waterfront/plank_walk_weathered/plank_walk_weathered_normal_gl.png
textures/chicago_1835_pbr/waterfront/plank_walk_weathered/plank_walk_weathered_orm.png
textures/chicago_1835_pbr/waterfront/plank_walk_weathered/plank_walk_weathered_roughness.png
```

### The Prairie Avenue 1904 street-surface library — `textures/prairie_1904_pbr/`

T-1728. Seven procedural materials for the 1904 scene's roadways, alleys, walks, curbs and
parkways, built by the generator that ships inside it (`tools/generate_prairie_1904_pbr.py`,
deterministic, seeded per material) in the 1835 library's map-for-map layout at 512 px. Which
surface wears which material, and on what evidence, is `data/street_surfaces/1904.json`'s to
say; the look of every map is reconstructed (`docs/LIBERTIES.md` L296).
T-3488 added a `yard/` group of five back- and side-yard grounds (`yard_brick_herringbone`,
`bluestone_flags`, `pea_gravel`, `beaten_earth`, `garden_loam`) from the same generator and on the
same terms; which yard surface wears which is the back-yard layout's to say, and their look is
reconstructed too.

| item | licence | cleared for | NOT cleared for |
|---|---|---|---|
| `textures/prairie_1904_pbr/**` — *Prairie Avenue 1904 street-surface PBR library v1.1.0*, original procedural output generated for this project. Full text at `textures/prairie_1904_pbr/LICENSE.txt` | **Project-permissive, CC0-equivalent**, the 1835 library's terms. No third-party photograph or image is embedded, sampled or traced | **Use, modification and redistribution with the project**, including regenerated maps | **Stripping the confidence labels.** Each `material.json` says its appearance is reconstructed and that the surfaces file, not the map, carries the evidence |

**Published in part.** `tools/publish.sh` ships each material's `material.json` and its three
`*_web.jpg` maps to `data/textures/prairie_1904_pbr/`; the PNG masters, the DirectX normal and the
16-bit height stay in the repository.
Beside each `*_web.jpg` it also ships a `.ktx2` of the same map (T-2582): the PNG master
GPU-compressed by `tools/ktx2_sheets.py` with KTX-Software 4.3.2 at the web map's size. A
derivative for the GPU, not a new map; it carries the library's licence unchanged.

Every file, as the checker matches them one by one:

```
textures/prairie_1904_pbr/LICENSE.txt
textures/prairie_1904_pbr/README.md
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_ao.png
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_basecolor.ktx2
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_basecolor.png
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_basecolor_web.jpg
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_height16.png
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_metallic.png
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_normal_dx.png
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_normal_gl.ktx2
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_normal_gl.png
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_normal_gl_web.jpg
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_orm.ktx2
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_orm.png
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_orm_web.jpg
textures/prairie_1904_pbr/alley/earth_and_cinders/earth_and_cinders_roughness.png
textures/prairie_1904_pbr/alley/earth_and_cinders/material.json
textures/prairie_1904_pbr/contact_sheet.jpg
textures/prairie_1904_pbr/curb/sandstone_curbstone/material.json
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_ao.png
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_basecolor.ktx2
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_basecolor.png
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_basecolor_web.jpg
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_height16.png
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_metallic.png
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_normal_dx.png
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_normal_gl.ktx2
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_normal_gl.png
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_normal_gl_web.jpg
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_orm.ktx2
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_orm.png
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_orm_web.jpg
textures/prairie_1904_pbr/curb/sandstone_curbstone/sandstone_curbstone_roughness.png
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_ao.png
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_basecolor.ktx2
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_basecolor.png
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_basecolor_web.jpg
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_height16.png
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_metallic.png
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_normal_dx.png
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_normal_gl.ktx2
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_normal_gl.png
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_normal_gl_web.jpg
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_orm.ktx2
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_orm.png
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_orm_web.jpg
textures/prairie_1904_pbr/parkway/grass_plat/grass_plat_roughness.png
textures/prairie_1904_pbr/parkway/grass_plat/material.json
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_ao.png
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_basecolor.ktx2
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_basecolor.png
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_basecolor_web.jpg
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_height16.png
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_metallic.png
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_normal_dx.png
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_normal_gl.ktx2
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_normal_gl.png
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_normal_gl_web.jpg
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_orm.ktx2
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_orm.png
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_orm_web.jpg
textures/prairie_1904_pbr/roadway/macadam_limestone/macadam_limestone_roughness.png
textures/prairie_1904_pbr/roadway/macadam_limestone/material.json
textures/prairie_1904_pbr/roadway/sheet_asphalt/material.json
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_ao.png
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_basecolor.ktx2
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_basecolor.png
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_basecolor_web.jpg
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_height16.png
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_metallic.png
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_normal_dx.png
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_normal_gl.ktx2
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_normal_gl.png
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_normal_gl_web.jpg
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_orm.ktx2
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_orm.png
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_orm_web.jpg
textures/prairie_1904_pbr/roadway/sheet_asphalt/sheet_asphalt_roughness.png
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/material.json
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_ao.png
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_basecolor.ktx2
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_basecolor.png
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_basecolor_web.jpg
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_height16.png
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_metallic.png
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_normal_dx.png
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_normal_gl.ktx2
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_normal_gl.png
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_normal_gl_web.jpg
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_orm.ktx2
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_orm.png
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_orm_web.jpg
textures/prairie_1904_pbr/roadway/vitrified_paving_brick/vitrified_paving_brick_roughness.png
textures/prairie_1904_pbr/tools/generate_prairie_1904_pbr.py
textures/prairie_1904_pbr/walk/portland_cement_walk/material.json
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_ao.png
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_basecolor.ktx2
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_basecolor.png
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_basecolor_web.jpg
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_height16.png
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_metallic.png
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_normal_dx.png
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_normal_gl.ktx2
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_normal_gl.png
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_normal_gl_web.jpg
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_orm.ktx2
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_orm.png
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_orm_web.jpg
textures/prairie_1904_pbr/walk/portland_cement_walk/portland_cement_walk_roughness.png
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_ao.png
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_basecolor.ktx2
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_basecolor.png
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_basecolor_web.jpg
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_height16.png
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_metallic.png
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_normal_dx.png
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_normal_gl.ktx2
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_normal_gl.png
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_normal_gl_web.jpg
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_orm.ktx2
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_orm.png
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_orm_web.jpg
textures/prairie_1904_pbr/yard/beaten_earth/beaten_earth_roughness.png
textures/prairie_1904_pbr/yard/beaten_earth/material.json
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_ao.png
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_basecolor.ktx2
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_basecolor.png
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_basecolor_web.jpg
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_height16.png
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_metallic.png
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_normal_dx.png
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_normal_gl.ktx2
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_normal_gl.png
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_normal_gl_web.jpg
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_orm.ktx2
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_orm.png
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_orm_web.jpg
textures/prairie_1904_pbr/yard/bluestone_flags/bluestone_flags_roughness.png
textures/prairie_1904_pbr/yard/bluestone_flags/material.json
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_ao.png
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_basecolor.ktx2
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_basecolor.png
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_basecolor_web.jpg
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_height16.png
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_metallic.png
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_normal_dx.png
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_normal_gl.ktx2
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_normal_gl.png
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_normal_gl_web.jpg
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_orm.ktx2
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_orm.png
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_orm_web.jpg
textures/prairie_1904_pbr/yard/garden_loam/garden_loam_roughness.png
textures/prairie_1904_pbr/yard/garden_loam/material.json
textures/prairie_1904_pbr/yard/pea_gravel/material.json
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_ao.png
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_basecolor.ktx2
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_basecolor.png
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_basecolor_web.jpg
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_height16.png
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_metallic.png
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_normal_dx.png
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_normal_gl.ktx2
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_normal_gl.png
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_normal_gl_web.jpg
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_orm.ktx2
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_orm.png
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_orm_web.jpg
textures/prairie_1904_pbr/yard/pea_gravel/pea_gravel_roughness.png
textures/prairie_1904_pbr/yard/yard_brick_herringbone/material.json
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_ao.png
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_basecolor.ktx2
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_basecolor.png
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_basecolor_web.jpg
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_height16.png
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_metallic.png
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_normal_dx.png
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_normal_gl.ktx2
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_normal_gl.png
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_normal_gl_web.jpg
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_orm.ktx2
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_orm.png
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_orm_web.jpg
textures/prairie_1904_pbr/yard/yard_brick_herringbone/yard_brick_herringbone_roughness.png
```

### The 1812 Potawatomi camp coverings library — `textures/camp_1812_pbr/`

T-3342. Three procedural materials for the coverings of the Potawatomi camp of August 1812 — the
cat-tail mat, the elm-bark sheet and the cut boughs of an arbor — built by the generator that ships
inside it (`tools/generate_camp_1812_pbr.py`, deterministic, seeded per material) in the 1835
library's map-for-map layout at 1024 px. Which lodge wears which, and on what evidence, is the camp
records' to say; the look of every map is reconstructed (`docs/LIBERTIES.md`
L-1812-potawatomi-camp-2515). T-3401 added three hay sheets (`hay_stack`, `hay_weathered`,
`hay_cut`) for the haystacks at Lee's Place, from the same generator and on the same terms
(L-1812-lees-place-haystacks-2510).

| item | licence | cleared for | NOT cleared for |
|---|---|---|---|
| `textures/camp_1812_pbr/**` — *1812 Potawatomi camp coverings PBR library v1.1.0*, original procedural output generated for this project. Full text at `textures/camp_1812_pbr/LICENSE.txt` | **Project-permissive, CC0-equivalent**, the 1835 library's terms. No third-party photograph or image is embedded, sampled or traced | **Use, modification and redistribution with the project**, including regenerated maps | **Stripping the confidence labels.** Each `material.json` says its appearance is reconstructed |

**Published in part.** `tools/publish.sh` ships each material's `material.json`, its three
`*_web.jpg` maps and their `.ktx2` derivatives (`tools/ktx2_sheets.py`, KTX-Software 4.3.2) to
`data/textures/camp_1812_pbr/`; the PNG masters and the 16-bit height stay in the repository.

Every file, as the checker matches them one by one:

```
textures/camp_1812_pbr/LICENSE.txt
textures/camp_1812_pbr/README.md
textures/camp_1812_pbr/bough_thatch/bough_thatch_basecolor.ktx2
textures/camp_1812_pbr/bough_thatch/bough_thatch_basecolor.png
textures/camp_1812_pbr/bough_thatch/bough_thatch_basecolor_web.jpg
textures/camp_1812_pbr/bough_thatch/bough_thatch_height16.png
textures/camp_1812_pbr/bough_thatch/bough_thatch_normal_gl.ktx2
textures/camp_1812_pbr/bough_thatch/bough_thatch_normal_gl.png
textures/camp_1812_pbr/bough_thatch/bough_thatch_normal_gl_web.jpg
textures/camp_1812_pbr/bough_thatch/bough_thatch_orm.ktx2
textures/camp_1812_pbr/bough_thatch/bough_thatch_orm.png
textures/camp_1812_pbr/bough_thatch/bough_thatch_orm_web.jpg
textures/camp_1812_pbr/bough_thatch/material.json
textures/camp_1812_pbr/cattail_mat/cattail_mat_basecolor.ktx2
textures/camp_1812_pbr/cattail_mat/cattail_mat_basecolor.png
textures/camp_1812_pbr/cattail_mat/cattail_mat_basecolor_web.jpg
textures/camp_1812_pbr/cattail_mat/cattail_mat_height16.png
textures/camp_1812_pbr/cattail_mat/cattail_mat_normal_gl.ktx2
textures/camp_1812_pbr/cattail_mat/cattail_mat_normal_gl.png
textures/camp_1812_pbr/cattail_mat/cattail_mat_normal_gl_web.jpg
textures/camp_1812_pbr/cattail_mat/cattail_mat_orm.ktx2
textures/camp_1812_pbr/cattail_mat/cattail_mat_orm.png
textures/camp_1812_pbr/cattail_mat/cattail_mat_orm_web.jpg
textures/camp_1812_pbr/cattail_mat/material.json
textures/camp_1812_pbr/elm_bark/elm_bark_basecolor.ktx2
textures/camp_1812_pbr/elm_bark/elm_bark_basecolor.png
textures/camp_1812_pbr/elm_bark/elm_bark_basecolor_web.jpg
textures/camp_1812_pbr/elm_bark/elm_bark_height16.png
textures/camp_1812_pbr/elm_bark/elm_bark_normal_gl.ktx2
textures/camp_1812_pbr/elm_bark/elm_bark_normal_gl.png
textures/camp_1812_pbr/elm_bark/elm_bark_normal_gl_web.jpg
textures/camp_1812_pbr/elm_bark/elm_bark_orm.ktx2
textures/camp_1812_pbr/elm_bark/elm_bark_orm.png
textures/camp_1812_pbr/elm_bark/elm_bark_orm_web.jpg
textures/camp_1812_pbr/elm_bark/material.json
textures/camp_1812_pbr/hay_cut/hay_cut_basecolor.ktx2
textures/camp_1812_pbr/hay_cut/hay_cut_basecolor.png
textures/camp_1812_pbr/hay_cut/hay_cut_basecolor_web.jpg
textures/camp_1812_pbr/hay_cut/hay_cut_height16.png
textures/camp_1812_pbr/hay_cut/hay_cut_normal_gl.ktx2
textures/camp_1812_pbr/hay_cut/hay_cut_normal_gl.png
textures/camp_1812_pbr/hay_cut/hay_cut_normal_gl_web.jpg
textures/camp_1812_pbr/hay_cut/hay_cut_orm.ktx2
textures/camp_1812_pbr/hay_cut/hay_cut_orm.png
textures/camp_1812_pbr/hay_cut/hay_cut_orm_web.jpg
textures/camp_1812_pbr/hay_cut/material.json
textures/camp_1812_pbr/hay_stack/hay_stack_basecolor.ktx2
textures/camp_1812_pbr/hay_stack/hay_stack_basecolor.png
textures/camp_1812_pbr/hay_stack/hay_stack_basecolor_web.jpg
textures/camp_1812_pbr/hay_stack/hay_stack_height16.png
textures/camp_1812_pbr/hay_stack/hay_stack_normal_gl.ktx2
textures/camp_1812_pbr/hay_stack/hay_stack_normal_gl.png
textures/camp_1812_pbr/hay_stack/hay_stack_normal_gl_web.jpg
textures/camp_1812_pbr/hay_stack/hay_stack_orm.ktx2
textures/camp_1812_pbr/hay_stack/hay_stack_orm.png
textures/camp_1812_pbr/hay_stack/hay_stack_orm_web.jpg
textures/camp_1812_pbr/hay_stack/material.json
textures/camp_1812_pbr/hay_weathered/hay_weathered_basecolor.ktx2
textures/camp_1812_pbr/hay_weathered/hay_weathered_basecolor.png
textures/camp_1812_pbr/hay_weathered/hay_weathered_basecolor_web.jpg
textures/camp_1812_pbr/hay_weathered/hay_weathered_height16.png
textures/camp_1812_pbr/hay_weathered/hay_weathered_normal_gl.ktx2
textures/camp_1812_pbr/hay_weathered/hay_weathered_normal_gl.png
textures/camp_1812_pbr/hay_weathered/hay_weathered_normal_gl_web.jpg
textures/camp_1812_pbr/hay_weathered/hay_weathered_orm.ktx2
textures/camp_1812_pbr/hay_weathered/hay_weathered_orm.png
textures/camp_1812_pbr/hay_weathered/hay_weathered_orm_web.jpg
textures/camp_1812_pbr/hay_weathered/material.json
textures/camp_1812_pbr/manifest.json
textures/camp_1812_pbr/tools/generate_camp_1812_pbr.py
```

### The yard woodpiles' wood library — `textures/yard_wood_pbr/`

T-3474. One procedural atlas of six wood cells — two rick faces of split billet ends, the sticks
along their length, a sawn round's end, oak/hickory log bark and a split face — built by the
generator that ships inside it (`tools/generate_yard_wood_pbr.py`, deterministic, seeded), drawn at
1024 px a cell and shipped at 512. `renderers/web/js/yard.js` binds it on the woodpile mesh. The
look of every map is reconstructed (`docs/LIBERTIES.md` L-t3474-yard-wood-surfaces).

| item | licence | cleared for | NOT cleared for |
|---|---|---|---|
| `textures/yard_wood_pbr/**` — *Yard woodpile wood PBR library v1.0.0*, original procedural output generated for this project. Full text at `textures/yard_wood_pbr/LICENSE.txt` | **Project-permissive, CC0-equivalent**, the 1835 library's terms. No third-party photograph or image is embedded, sampled or traced | **Use, modification and redistribution with the project**, including regenerated maps | **Stripping the confidence labels.** `material.json` says its appearance is reconstructed |

**Published in part.** `tools/publish.sh` ships the atlas's `material.json`, its three `*_web.jpg`
maps and their `.ktx2` derivatives to `data/textures/yard_wood_pbr/`; the PNG masters and the
16-bit height stay in the repository.

Every file, as the checker matches them one by one:

```
textures/yard_wood_pbr/LICENSE.txt
textures/yard_wood_pbr/README.md
textures/yard_wood_pbr/manifest.json
textures/yard_wood_pbr/tools/generate_yard_wood_pbr.py
textures/yard_wood_pbr/woodpile_atlas/material.json
textures/yard_wood_pbr/woodpile_atlas/woodpile_atlas_basecolor.ktx2
textures/yard_wood_pbr/woodpile_atlas/woodpile_atlas_basecolor.png
textures/yard_wood_pbr/woodpile_atlas/woodpile_atlas_basecolor_web.jpg
textures/yard_wood_pbr/woodpile_atlas/woodpile_atlas_height16.png
textures/yard_wood_pbr/woodpile_atlas/woodpile_atlas_normal_gl.ktx2
textures/yard_wood_pbr/woodpile_atlas/woodpile_atlas_normal_gl.png
textures/yard_wood_pbr/woodpile_atlas/woodpile_atlas_normal_gl_web.jpg
textures/yard_wood_pbr/woodpile_atlas/woodpile_atlas_orm.ktx2
textures/yard_wood_pbr/woodpile_atlas/woodpile_atlas_orm.png
textures/yard_wood_pbr/woodpile_atlas/woodpile_atlas_orm_web.jpg
```


### The Prairie Avenue 1904 lakefront railway library — `textures/prairie_1904_rail/`

T-2478. Four procedural materials for the 1904 scene's Illinois Central right-of-way (cinder
ballast, trodden cinders, a weedy verge, a crosstie's top) and one alpha card for the verges' grass
tufts, built by the generator that ships inside it (`tools/generate_prairie_1904_rail.py`,
deterministic, seeded per material, borrowing the street library's noise). Which ground wears which
material is `data/railway/1904_spec.json`'s to say; the look of every map is reconstructed
(`docs/LIBERTIES.md` L-ic-tracks-2478). T-2479 added four more under `edge/` for the railway's edge
against the lake (the riprap face, one limestone block's face, the cap timber, the made ground),
equally reconstructed (L-ic-lake-edge-2479).

| item | licence | cleared for | NOT cleared for |
|---|---|---|---|
| `textures/prairie_1904_rail/**` — *Prairie Avenue 1904 lakefront railway PBR library v1.1.0*, original procedural output generated for this project. Full text at `textures/prairie_1904_rail/LICENSE.txt` | **Project-permissive, CC0-equivalent**, the 1835 library's terms. No third-party photograph or image is embedded, sampled or traced | **Use, modification and redistribution with the project**, including regenerated maps | **Stripping the confidence labels.** Each `material.json` says its appearance is reconstructed and that the railway spec, not the map, carries the evidence |

**Published in part.** `tools/publish.sh` ships each material's `material.json` and its three
`*_web.jpg` maps (the tuft's one `grass_tuft_web.png`) to `data/textures/prairie_1904_rail/`; the PNG
masters and the 16-bit height stay in the repository.

Every file, as the checker matches them one by one:

```
textures/prairie_1904_rail/LICENSE.txt
textures/prairie_1904_rail/README.md
textures/prairie_1904_rail/ballast/cinder_ballast/cinder_ballast_basecolor.png
textures/prairie_1904_rail/ballast/cinder_ballast/cinder_ballast_basecolor_web.jpg
textures/prairie_1904_rail/ballast/cinder_ballast/cinder_ballast_height16.png
textures/prairie_1904_rail/ballast/cinder_ballast/cinder_ballast_normal_gl.png
textures/prairie_1904_rail/ballast/cinder_ballast/cinder_ballast_normal_gl_web.jpg
textures/prairie_1904_rail/ballast/cinder_ballast/cinder_ballast_orm.png
textures/prairie_1904_rail/ballast/cinder_ballast/cinder_ballast_orm_web.jpg
textures/prairie_1904_rail/ballast/cinder_ballast/material.json
textures/prairie_1904_rail/contact_sheet.jpg
textures/prairie_1904_rail/edge/cap_timber/cap_timber_basecolor.png
textures/prairie_1904_rail/edge/cap_timber/cap_timber_basecolor_web.jpg
textures/prairie_1904_rail/edge/cap_timber/cap_timber_height16.png
textures/prairie_1904_rail/edge/cap_timber/cap_timber_normal_gl.png
textures/prairie_1904_rail/edge/cap_timber/cap_timber_normal_gl_web.jpg
textures/prairie_1904_rail/edge/cap_timber/cap_timber_orm.png
textures/prairie_1904_rail/edge/cap_timber/cap_timber_orm_web.jpg
textures/prairie_1904_rail/edge/cap_timber/material.json
textures/prairie_1904_rail/edge/limestone_block/limestone_block_basecolor.png
textures/prairie_1904_rail/edge/limestone_block/limestone_block_basecolor_web.jpg
textures/prairie_1904_rail/edge/limestone_block/limestone_block_height16.png
textures/prairie_1904_rail/edge/limestone_block/limestone_block_normal_gl.png
textures/prairie_1904_rail/edge/limestone_block/limestone_block_normal_gl_web.jpg
textures/prairie_1904_rail/edge/limestone_block/limestone_block_orm.png
textures/prairie_1904_rail/edge/limestone_block/limestone_block_orm_web.jpg
textures/prairie_1904_rail/edge/limestone_block/material.json
textures/prairie_1904_rail/edge/made_ground/made_ground_basecolor.png
textures/prairie_1904_rail/edge/made_ground/made_ground_basecolor_web.jpg
textures/prairie_1904_rail/edge/made_ground/made_ground_height16.png
textures/prairie_1904_rail/edge/made_ground/made_ground_normal_gl.png
textures/prairie_1904_rail/edge/made_ground/made_ground_normal_gl_web.jpg
textures/prairie_1904_rail/edge/made_ground/made_ground_orm.png
textures/prairie_1904_rail/edge/made_ground/made_ground_orm_web.jpg
textures/prairie_1904_rail/edge/made_ground/material.json
textures/prairie_1904_rail/edge/riprap_limestone/material.json
textures/prairie_1904_rail/edge/riprap_limestone/riprap_limestone_basecolor.png
textures/prairie_1904_rail/edge/riprap_limestone/riprap_limestone_basecolor_web.jpg
textures/prairie_1904_rail/edge/riprap_limestone/riprap_limestone_height16.png
textures/prairie_1904_rail/edge/riprap_limestone/riprap_limestone_normal_gl.png
textures/prairie_1904_rail/edge/riprap_limestone/riprap_limestone_normal_gl_web.jpg
textures/prairie_1904_rail/edge/riprap_limestone/riprap_limestone_orm.png
textures/prairie_1904_rail/edge/riprap_limestone/riprap_limestone_orm_web.jpg
textures/prairie_1904_rail/foliage/grass_tuft/grass_tuft_web.png
textures/prairie_1904_rail/foliage/grass_tuft/material.json
textures/prairie_1904_rail/ground/trodden_cinders/material.json
textures/prairie_1904_rail/ground/trodden_cinders/trodden_cinders_basecolor.png
textures/prairie_1904_rail/ground/trodden_cinders/trodden_cinders_basecolor_web.jpg
textures/prairie_1904_rail/ground/trodden_cinders/trodden_cinders_height16.png
textures/prairie_1904_rail/ground/trodden_cinders/trodden_cinders_normal_gl.png
textures/prairie_1904_rail/ground/trodden_cinders/trodden_cinders_normal_gl_web.jpg
textures/prairie_1904_rail/ground/trodden_cinders/trodden_cinders_orm.png
textures/prairie_1904_rail/ground/trodden_cinders/trodden_cinders_orm_web.jpg
textures/prairie_1904_rail/manifest.json
textures/prairie_1904_rail/timber/tie_timber/material.json
textures/prairie_1904_rail/timber/tie_timber/tie_timber_basecolor.png
textures/prairie_1904_rail/timber/tie_timber/tie_timber_basecolor_web.jpg
textures/prairie_1904_rail/timber/tie_timber/tie_timber_height16.png
textures/prairie_1904_rail/timber/tie_timber/tie_timber_normal_gl.png
textures/prairie_1904_rail/timber/tie_timber/tie_timber_normal_gl_web.jpg
textures/prairie_1904_rail/timber/tie_timber/tie_timber_orm.png
textures/prairie_1904_rail/timber/tie_timber/tie_timber_orm_web.jpg
textures/prairie_1904_rail/tools/generate_prairie_1904_rail.py
textures/prairie_1904_rail/verge/weedy_verge/material.json
textures/prairie_1904_rail/verge/weedy_verge/weedy_verge_basecolor.png
textures/prairie_1904_rail/verge/weedy_verge/weedy_verge_basecolor_web.jpg
textures/prairie_1904_rail/verge/weedy_verge/weedy_verge_height16.png
textures/prairie_1904_rail/verge/weedy_verge/weedy_verge_normal_gl.png
textures/prairie_1904_rail/verge/weedy_verge/weedy_verge_normal_gl_web.jpg
textures/prairie_1904_rail/verge/weedy_verge/weedy_verge_orm.png
textures/prairie_1904_rail/verge/weedy_verge/weedy_verge_orm_web.jpg
```

### The Prairie Avenue 1904 K03 brick library — `textures/prairie_1904_brick/`

T-2290 (piece 1 of T-1845, package K03 of T-1837). Four joint-free brick fabrics (pressed red,
common buff, dark fired, rough red-brown), two mortars, `profiles.json` (joints, bonds, specials
and firing spread as data) and four bonded LOD panels rendered from it, built by the generator
that ships inside it (`tools/generate_prairie_1904_brick.py`, deterministic, seeded per fabric).
Which house is built of which brick is the T-1837 register's and each house's own evidence to say;
the look of every map is reconstructed (`docs/LIBERTIES.md` L-k03-brick-library-2290).

| item | licence | cleared for | NOT cleared for |
|---|---|---|---|
| `textures/prairie_1904_brick/**`: *Prairie Avenue 1904 K03 brick library v1.0.0*, original procedural output generated for this project. Full text at `textures/prairie_1904_brick/LICENSE.txt` | **Project-permissive, CC0-equivalent**, the street library's terms. No third-party photograph or image is embedded, sampled or traced | **Use, modification and redistribution with the project**, including regenerated maps | **Stripping the confidence labels.** Each `material.json` and `profiles.json` says its appearance is reconstructed and that the register, not the map, carries the evidence |

**Not published yet.** `tools/publish.sh` ships nothing from this library until a component binds it
(T-2291).

Every file, as the checker matches them one by one:

```
textures/prairie_1904_brick/LICENSE.txt
textures/prairie_1904_brick/README.md
textures/prairie_1904_brick/brick/common_buff/common_buff_basecolor.png
textures/prairie_1904_brick/brick/common_buff/common_buff_basecolor_web.jpg
textures/prairie_1904_brick/brick/common_buff/common_buff_height16.png
textures/prairie_1904_brick/brick/common_buff/common_buff_normal_gl.png
textures/prairie_1904_brick/brick/common_buff/common_buff_normal_gl_web.jpg
textures/prairie_1904_brick/brick/common_buff/common_buff_orm.png
textures/prairie_1904_brick/brick/common_buff/common_buff_orm_web.jpg
textures/prairie_1904_brick/brick/common_buff/common_buff_roughness.png
textures/prairie_1904_brick/brick/common_buff/material.json
textures/prairie_1904_brick/brick/dark_fired/dark_fired_basecolor.png
textures/prairie_1904_brick/brick/dark_fired/dark_fired_basecolor_web.jpg
textures/prairie_1904_brick/brick/dark_fired/dark_fired_height16.png
textures/prairie_1904_brick/brick/dark_fired/dark_fired_normal_gl.png
textures/prairie_1904_brick/brick/dark_fired/dark_fired_normal_gl_web.jpg
textures/prairie_1904_brick/brick/dark_fired/dark_fired_orm.png
textures/prairie_1904_brick/brick/dark_fired/dark_fired_orm_web.jpg
textures/prairie_1904_brick/brick/dark_fired/dark_fired_roughness.png
textures/prairie_1904_brick/brick/dark_fired/material.json
textures/prairie_1904_brick/brick/pressed_red/material.json
textures/prairie_1904_brick/brick/pressed_red/pressed_red_basecolor.png
textures/prairie_1904_brick/brick/pressed_red/pressed_red_basecolor_web.jpg
textures/prairie_1904_brick/brick/pressed_red/pressed_red_height16.png
textures/prairie_1904_brick/brick/pressed_red/pressed_red_normal_gl.png
textures/prairie_1904_brick/brick/pressed_red/pressed_red_normal_gl_web.jpg
textures/prairie_1904_brick/brick/pressed_red/pressed_red_orm.png
textures/prairie_1904_brick/brick/pressed_red/pressed_red_orm_web.jpg
textures/prairie_1904_brick/brick/pressed_red/pressed_red_roughness.png
textures/prairie_1904_brick/brick/rough_red_brown/material.json
textures/prairie_1904_brick/brick/rough_red_brown/rough_red_brown_basecolor.png
textures/prairie_1904_brick/brick/rough_red_brown/rough_red_brown_basecolor_web.jpg
textures/prairie_1904_brick/brick/rough_red_brown/rough_red_brown_height16.png
textures/prairie_1904_brick/brick/rough_red_brown/rough_red_brown_normal_gl.png
textures/prairie_1904_brick/brick/rough_red_brown/rough_red_brown_normal_gl_web.jpg
textures/prairie_1904_brick/brick/rough_red_brown/rough_red_brown_orm.png
textures/prairie_1904_brick/brick/rough_red_brown/rough_red_brown_orm_web.jpg
textures/prairie_1904_brick/brick/rough_red_brown/rough_red_brown_roughness.png
textures/prairie_1904_brick/brick/cream_rough/cream_rough_basecolor.png
textures/prairie_1904_brick/brick/cream_rough/cream_rough_basecolor_web.jpg
textures/prairie_1904_brick/brick/cream_rough/cream_rough_height16.png
textures/prairie_1904_brick/brick/cream_rough/cream_rough_normal_gl.png
textures/prairie_1904_brick/brick/cream_rough/cream_rough_normal_gl_web.jpg
textures/prairie_1904_brick/brick/cream_rough/cream_rough_orm.png
textures/prairie_1904_brick/brick/cream_rough/cream_rough_orm_web.jpg
textures/prairie_1904_brick/brick/cream_rough/cream_rough_roughness.png
textures/prairie_1904_brick/brick/cream_rough/material.json
textures/prairie_1904_brick/mortar/mortar_dark/material.json
textures/prairie_1904_brick/mortar/mortar_dark/mortar_dark_basecolor.png
textures/prairie_1904_brick/mortar/mortar_dark/mortar_dark_basecolor_web.jpg
textures/prairie_1904_brick/mortar/mortar_dark/mortar_dark_height16.png
textures/prairie_1904_brick/mortar/mortar_dark/mortar_dark_normal_gl.png
textures/prairie_1904_brick/mortar/mortar_dark/mortar_dark_normal_gl_web.jpg
textures/prairie_1904_brick/mortar/mortar_dark/mortar_dark_orm.png
textures/prairie_1904_brick/mortar/mortar_dark/mortar_dark_orm_web.jpg
textures/prairie_1904_brick/mortar/mortar_dark/mortar_dark_roughness.png
textures/prairie_1904_brick/mortar/mortar_lime/material.json
textures/prairie_1904_brick/mortar/mortar_lime/mortar_lime_basecolor.png
textures/prairie_1904_brick/mortar/mortar_lime/mortar_lime_basecolor_web.jpg
textures/prairie_1904_brick/mortar/mortar_lime/mortar_lime_height16.png
textures/prairie_1904_brick/mortar/mortar_lime/mortar_lime_normal_gl.png
textures/prairie_1904_brick/mortar/mortar_lime/mortar_lime_normal_gl_web.jpg
textures/prairie_1904_brick/mortar/mortar_lime/mortar_lime_orm.png
textures/prairie_1904_brick/mortar/mortar_lime/mortar_lime_orm_web.jpg
textures/prairie_1904_brick/mortar/mortar_lime/mortar_lime_roughness.png
textures/prairie_1904_brick/panel/common_buff_common_6/common_buff_common_6_basecolor.png
textures/prairie_1904_brick/panel/common_buff_common_6/common_buff_common_6_basecolor_web.jpg
textures/prairie_1904_brick/panel/common_buff_common_6/common_buff_common_6_height16.png
textures/prairie_1904_brick/panel/common_buff_common_6/common_buff_common_6_normal_gl.png
textures/prairie_1904_brick/panel/common_buff_common_6/common_buff_common_6_normal_gl_web.jpg
textures/prairie_1904_brick/panel/common_buff_common_6/common_buff_common_6_orm.png
textures/prairie_1904_brick/panel/common_buff_common_6/common_buff_common_6_orm_web.jpg
textures/prairie_1904_brick/panel/common_buff_common_6/common_buff_common_6_roughness.png
textures/prairie_1904_brick/panel/common_buff_common_6/material.json
textures/prairie_1904_brick/panel/pressed_red_flemish_dark_headers/material.json
textures/prairie_1904_brick/panel/pressed_red_flemish_dark_headers/pressed_red_flemish_dark_headers_basecolor.png
textures/prairie_1904_brick/panel/pressed_red_flemish_dark_headers/pressed_red_flemish_dark_headers_basecolor_web.jpg
textures/prairie_1904_brick/panel/pressed_red_flemish_dark_headers/pressed_red_flemish_dark_headers_height16.png
textures/prairie_1904_brick/panel/pressed_red_flemish_dark_headers/pressed_red_flemish_dark_headers_normal_gl.png
textures/prairie_1904_brick/panel/pressed_red_flemish_dark_headers/pressed_red_flemish_dark_headers_normal_gl_web.jpg
textures/prairie_1904_brick/panel/pressed_red_flemish_dark_headers/pressed_red_flemish_dark_headers_orm.png
textures/prairie_1904_brick/panel/pressed_red_flemish_dark_headers/pressed_red_flemish_dark_headers_orm_web.jpg
textures/prairie_1904_brick/panel/pressed_red_flemish_dark_headers/pressed_red_flemish_dark_headers_roughness.png
textures/prairie_1904_brick/panel/pressed_red_running/material.json
textures/prairie_1904_brick/panel/pressed_red_running/pressed_red_running_basecolor.png
textures/prairie_1904_brick/panel/pressed_red_running/pressed_red_running_basecolor_web.jpg
textures/prairie_1904_brick/panel/pressed_red_running/pressed_red_running_height16.png
textures/prairie_1904_brick/panel/pressed_red_running/pressed_red_running_normal_gl.png
textures/prairie_1904_brick/panel/pressed_red_running/pressed_red_running_normal_gl_web.jpg
textures/prairie_1904_brick/panel/pressed_red_running/pressed_red_running_orm.png
textures/prairie_1904_brick/panel/pressed_red_running/pressed_red_running_orm_web.jpg
textures/prairie_1904_brick/panel/pressed_red_running/pressed_red_running_roughness.png
textures/prairie_1904_brick/panel/rough_red_brown_running/material.json
textures/prairie_1904_brick/panel/rough_red_brown_running/rough_red_brown_running_basecolor.png
textures/prairie_1904_brick/panel/rough_red_brown_running/rough_red_brown_running_basecolor_web.jpg
textures/prairie_1904_brick/panel/rough_red_brown_running/rough_red_brown_running_height16.png
textures/prairie_1904_brick/panel/rough_red_brown_running/rough_red_brown_running_normal_gl.png
textures/prairie_1904_brick/panel/rough_red_brown_running/rough_red_brown_running_normal_gl_web.jpg
textures/prairie_1904_brick/panel/rough_red_brown_running/rough_red_brown_running_orm.png
textures/prairie_1904_brick/panel/rough_red_brown_running/rough_red_brown_running_orm_web.jpg
textures/prairie_1904_brick/panel/rough_red_brown_running/rough_red_brown_running_roughness.png
textures/prairie_1904_brick/panel/cream_rough_running/cream_rough_running_basecolor.png
textures/prairie_1904_brick/panel/cream_rough_running/cream_rough_running_basecolor_web.jpg
textures/prairie_1904_brick/panel/cream_rough_running/cream_rough_running_height16.png
textures/prairie_1904_brick/panel/cream_rough_running/cream_rough_running_normal_gl.png
textures/prairie_1904_brick/panel/cream_rough_running/cream_rough_running_normal_gl_web.jpg
textures/prairie_1904_brick/panel/cream_rough_running/cream_rough_running_orm.png
textures/prairie_1904_brick/panel/cream_rough_running/cream_rough_running_orm_web.jpg
textures/prairie_1904_brick/panel/cream_rough_running/cream_rough_running_roughness.png
textures/prairie_1904_brick/panel/cream_rough_running/material.json
textures/prairie_1904_brick/profiles.json
textures/prairie_1904_brick/tools/generate_prairie_1904_brick.py
```

### The Prairie Avenue 1904 stone library (K02) — `textures/prairie_1904_stone/`

T-2288, piece 1 of T-1844. Seven procedural stone fabrics for the 1904 programme's walls, trim and
foundations (rock-faced granite, brown sandstone, light fawn sandstone (T-1881), Lemont and Bedford
limestone, dressed trim, foundation rubble), built by the generator that ships inside it
(`tools/generate_prairie_1904_stone.py`, deterministic, seeded per fabric). Which building wears
which stone is its structure record's to say; the look of every map is reconstructed
(`docs/LIBERTIES.md` L-k02-stone-library-2288).

| item | licence | cleared for | NOT cleared for |
|---|---|---|---|
| `textures/prairie_1904_stone/**` — *Prairie Avenue 1904 stone library (K02) v1.0.0*, original procedural output generated for this project. Full text at `textures/prairie_1904_stone/LICENSE.txt` | **Project-permissive, CC0-equivalent**, the 1835 and 1904 street libraries' terms. No third-party photograph or image is embedded, sampled or traced | **Use, modification and redistribution with the project**, including regenerated maps | **Stripping the confidence labels.** Each `material.json` says its appearance is reconstructed and that a structure record, not the map, carries the evidence |

**Not published.** No scene binds these maps yet and `tools/publish.sh` ships none of them; T-2289
lays them on the 1808 Prairie exemplar.

Every file, as the checker matches them one by one:

```
textures/prairie_1904_stone/LICENSE.txt
textures/prairie_1904_stone/README.md
textures/prairie_1904_stone/contact_sheet.jpg
textures/prairie_1904_stone/dressed_trim/dressed_trim_basecolor.png
textures/prairie_1904_stone/dressed_trim/dressed_trim_basecolor_web.jpg
textures/prairie_1904_stone/dressed_trim/dressed_trim_height16.png
textures/prairie_1904_stone/dressed_trim/dressed_trim_normal_gl.png
textures/prairie_1904_stone/dressed_trim/dressed_trim_normal_gl_web.jpg
textures/prairie_1904_stone/dressed_trim/dressed_trim_orm.png
textures/prairie_1904_stone/dressed_trim/dressed_trim_orm_web.jpg
textures/prairie_1904_stone/dressed_trim/material.json
textures/prairie_1904_stone/foundation_rubble/foundation_rubble_basecolor.png
textures/prairie_1904_stone/foundation_rubble/foundation_rubble_basecolor_web.jpg
textures/prairie_1904_stone/foundation_rubble/foundation_rubble_height16.png
textures/prairie_1904_stone/foundation_rubble/foundation_rubble_normal_gl.png
textures/prairie_1904_stone/foundation_rubble/foundation_rubble_normal_gl_web.jpg
textures/prairie_1904_stone/foundation_rubble/foundation_rubble_orm.png
textures/prairie_1904_stone/foundation_rubble/foundation_rubble_orm_web.jpg
textures/prairie_1904_stone/foundation_rubble/material.json
textures/prairie_1904_stone/granite_rock_faced/granite_rock_faced_basecolor.png
textures/prairie_1904_stone/granite_rock_faced/granite_rock_faced_basecolor_web.jpg
textures/prairie_1904_stone/granite_rock_faced/granite_rock_faced_height16.png
textures/prairie_1904_stone/granite_rock_faced/granite_rock_faced_normal_gl.png
textures/prairie_1904_stone/granite_rock_faced/granite_rock_faced_normal_gl_web.jpg
textures/prairie_1904_stone/granite_rock_faced/granite_rock_faced_orm.png
textures/prairie_1904_stone/granite_rock_faced/granite_rock_faced_orm_web.jpg
textures/prairie_1904_stone/granite_rock_faced/material.json
textures/prairie_1904_stone/limestone_bedford/limestone_bedford_basecolor.png
textures/prairie_1904_stone/limestone_bedford/limestone_bedford_basecolor_web.jpg
textures/prairie_1904_stone/limestone_bedford/limestone_bedford_height16.png
textures/prairie_1904_stone/limestone_bedford/limestone_bedford_normal_gl.png
textures/prairie_1904_stone/limestone_bedford/limestone_bedford_normal_gl_web.jpg
textures/prairie_1904_stone/limestone_bedford/limestone_bedford_orm.png
textures/prairie_1904_stone/limestone_bedford/limestone_bedford_orm_web.jpg
textures/prairie_1904_stone/limestone_bedford/material.json
textures/prairie_1904_stone/limestone_lemont/limestone_lemont_basecolor.png
textures/prairie_1904_stone/limestone_lemont/limestone_lemont_basecolor_web.jpg
textures/prairie_1904_stone/limestone_lemont/limestone_lemont_height16.png
textures/prairie_1904_stone/limestone_lemont/limestone_lemont_normal_gl.png
textures/prairie_1904_stone/limestone_lemont/limestone_lemont_normal_gl_web.jpg
textures/prairie_1904_stone/limestone_lemont/limestone_lemont_orm.png
textures/prairie_1904_stone/limestone_lemont/limestone_lemont_orm_web.jpg
textures/prairie_1904_stone/limestone_lemont/material.json
textures/prairie_1904_stone/sandstone_brown/material.json
textures/prairie_1904_stone/sandstone_brown/sandstone_brown_basecolor.png
textures/prairie_1904_stone/sandstone_brown/sandstone_brown_basecolor_web.jpg
textures/prairie_1904_stone/sandstone_brown/sandstone_brown_height16.png
textures/prairie_1904_stone/sandstone_brown/sandstone_brown_normal_gl.png
textures/prairie_1904_stone/sandstone_brown/sandstone_brown_normal_gl_web.jpg
textures/prairie_1904_stone/sandstone_brown/sandstone_brown_orm.png
textures/prairie_1904_stone/sandstone_brown/sandstone_brown_orm_web.jpg
textures/prairie_1904_stone/sandstone_fawn/material.json
textures/prairie_1904_stone/sandstone_fawn/sandstone_fawn_basecolor.png
textures/prairie_1904_stone/sandstone_fawn/sandstone_fawn_basecolor_web.jpg
textures/prairie_1904_stone/sandstone_fawn/sandstone_fawn_height16.png
textures/prairie_1904_stone/sandstone_fawn/sandstone_fawn_normal_gl.png
textures/prairie_1904_stone/sandstone_fawn/sandstone_fawn_normal_gl_web.jpg
textures/prairie_1904_stone/sandstone_fawn/sandstone_fawn_orm.png
textures/prairie_1904_stone/sandstone_fawn/sandstone_fawn_orm_web.jpg
textures/prairie_1904_stone/tools/generate_prairie_1904_stone.py
```

| path | source | license | notes |
|---|---|---|---|

### The Prairie Avenue 1904 roof library (K04) — `textures/prairie_1904_roofs/`

T-2292. Eleven procedural fabrics for the 1904 programme's roof coverings, flashings and rainwater
goods, built by the generator that ships inside it (`tools/generate_prairie_1904_roofs.py`,
deterministic, seeded per fabric) from the modules in `data/components/prairie_1904/k04_roofs.json`,
with the study renderer beside it. The look of every map is reconstructed (`docs/LIBERTIES.md`
L-k04-roof-library-2292); the flat tile's module is HABS's for Glessner, and nothing else here is
measured.

| item | licence | cleared for | NOT cleared for |
|---|---|---|---|
| `textures/prairie_1904_roofs/**` — *Prairie Avenue 1904 roof-covering library (K04) v1.0.0*, original procedural output generated for this project. Full text at `textures/prairie_1904_roofs/LICENSE.txt` | **Project-permissive, CC0-equivalent**, the 1904 street-surface library's terms. No third-party photograph or image is embedded, sampled or traced | **Use, modification and redistribution with the project**, including regenerated maps | **Stripping the confidence labels.** Each `material.json` says its appearance is reconstructed and names the data file its module comes from |

The files:

```
textures/prairie_1904_roofs/LICENSE.txt
textures/prairie_1904_roofs/README.md
textures/prairie_1904_roofs/copper_sheet/copper_sheet_basecolor.png
textures/prairie_1904_roofs/copper_sheet/copper_sheet_basecolor_web.jpg
textures/prairie_1904_roofs/copper_sheet/copper_sheet_normal_gl.png
textures/prairie_1904_roofs/copper_sheet/copper_sheet_normal_gl_web.jpg
textures/prairie_1904_roofs/copper_sheet/copper_sheet_orm.png
textures/prairie_1904_roofs/copper_sheet/copper_sheet_orm_web.jpg
textures/prairie_1904_roofs/copper_sheet/copper_sheet_roughness.png
textures/prairie_1904_roofs/copper_sheet/material.json
textures/prairie_1904_roofs/copper_standing_seam/copper_standing_seam_basecolor.png
textures/prairie_1904_roofs/copper_standing_seam/copper_standing_seam_basecolor_web.jpg
textures/prairie_1904_roofs/copper_standing_seam/copper_standing_seam_normal_gl.png
textures/prairie_1904_roofs/copper_standing_seam/copper_standing_seam_normal_gl_web.jpg
textures/prairie_1904_roofs/copper_standing_seam/copper_standing_seam_orm.png
textures/prairie_1904_roofs/copper_standing_seam/copper_standing_seam_orm_web.jpg
textures/prairie_1904_roofs/copper_standing_seam/copper_standing_seam_roughness.png
textures/prairie_1904_roofs/copper_standing_seam/material.json
textures/prairie_1904_roofs/lead_sheet/lead_sheet_basecolor.png
textures/prairie_1904_roofs/lead_sheet/lead_sheet_basecolor_web.jpg
textures/prairie_1904_roofs/lead_sheet/lead_sheet_normal_gl.png
textures/prairie_1904_roofs/lead_sheet/lead_sheet_normal_gl_web.jpg
textures/prairie_1904_roofs/lead_sheet/lead_sheet_orm.png
textures/prairie_1904_roofs/lead_sheet/lead_sheet_orm_web.jpg
textures/prairie_1904_roofs/lead_sheet/lead_sheet_roughness.png
textures/prairie_1904_roofs/lead_sheet/material.json
textures/prairie_1904_roofs/manifest.json
textures/prairie_1904_roofs/painted_tin_sheet/material.json
textures/prairie_1904_roofs/painted_tin_sheet/painted_tin_sheet_basecolor.png
textures/prairie_1904_roofs/painted_tin_sheet/painted_tin_sheet_basecolor_web.jpg
textures/prairie_1904_roofs/painted_tin_sheet/painted_tin_sheet_normal_gl.png
textures/prairie_1904_roofs/painted_tin_sheet/painted_tin_sheet_normal_gl_web.jpg
textures/prairie_1904_roofs/painted_tin_sheet/painted_tin_sheet_orm.png
textures/prairie_1904_roofs/painted_tin_sheet/painted_tin_sheet_orm_web.jpg
textures/prairie_1904_roofs/painted_tin_sheet/painted_tin_sheet_roughness.png
textures/prairie_1904_roofs/slate_fishscale/material.json
textures/prairie_1904_roofs/slate_fishscale/slate_fishscale_basecolor.png
textures/prairie_1904_roofs/slate_fishscale/slate_fishscale_basecolor_web.jpg
textures/prairie_1904_roofs/slate_fishscale/slate_fishscale_normal_gl.png
textures/prairie_1904_roofs/slate_fishscale/slate_fishscale_normal_gl_web.jpg
textures/prairie_1904_roofs/slate_fishscale/slate_fishscale_orm.png
textures/prairie_1904_roofs/slate_fishscale/slate_fishscale_orm_web.jpg
textures/prairie_1904_roofs/slate_fishscale/slate_fishscale_roughness.png
textures/prairie_1904_roofs/slate_pennsylvania/material.json
textures/prairie_1904_roofs/slate_pennsylvania/slate_pennsylvania_basecolor.png
textures/prairie_1904_roofs/slate_pennsylvania/slate_pennsylvania_basecolor_web.jpg
textures/prairie_1904_roofs/slate_pennsylvania/slate_pennsylvania_normal_gl.png
textures/prairie_1904_roofs/slate_pennsylvania/slate_pennsylvania_normal_gl_web.jpg
textures/prairie_1904_roofs/slate_pennsylvania/slate_pennsylvania_orm.png
textures/prairie_1904_roofs/slate_pennsylvania/slate_pennsylvania_orm_web.jpg
textures/prairie_1904_roofs/slate_pennsylvania/slate_pennsylvania_roughness.png
textures/prairie_1904_roofs/slate_vermont/material.json
textures/prairie_1904_roofs/slate_vermont/slate_vermont_basecolor.png
textures/prairie_1904_roofs/slate_vermont/slate_vermont_basecolor_web.jpg
textures/prairie_1904_roofs/slate_vermont/slate_vermont_normal_gl.png
textures/prairie_1904_roofs/slate_vermont/slate_vermont_normal_gl_web.jpg
textures/prairie_1904_roofs/slate_vermont/slate_vermont_orm.png
textures/prairie_1904_roofs/slate_vermont/slate_vermont_orm_web.jpg
textures/prairie_1904_roofs/slate_vermont/slate_vermont_roughness.png
textures/prairie_1904_roofs/terracotta_flat_tile/material.json
textures/prairie_1904_roofs/terracotta_flat_tile/terracotta_flat_tile_basecolor.png
textures/prairie_1904_roofs/terracotta_flat_tile/terracotta_flat_tile_basecolor_web.jpg
textures/prairie_1904_roofs/terracotta_flat_tile/terracotta_flat_tile_normal_gl.png
textures/prairie_1904_roofs/terracotta_flat_tile/terracotta_flat_tile_normal_gl_web.jpg
textures/prairie_1904_roofs/terracotta_flat_tile/terracotta_flat_tile_orm.png
textures/prairie_1904_roofs/terracotta_flat_tile/terracotta_flat_tile_orm_web.jpg
textures/prairie_1904_roofs/terracotta_flat_tile/terracotta_flat_tile_roughness.png
textures/prairie_1904_roofs/tin_flat_seam_painted/material.json
textures/prairie_1904_roofs/tin_flat_seam_painted/tin_flat_seam_painted_basecolor.png
textures/prairie_1904_roofs/tin_flat_seam_painted/tin_flat_seam_painted_basecolor_web.jpg
textures/prairie_1904_roofs/tin_flat_seam_painted/tin_flat_seam_painted_normal_gl.png
textures/prairie_1904_roofs/tin_flat_seam_painted/tin_flat_seam_painted_normal_gl_web.jpg
textures/prairie_1904_roofs/tin_flat_seam_painted/tin_flat_seam_painted_orm.png
textures/prairie_1904_roofs/tin_flat_seam_painted/tin_flat_seam_painted_orm_web.jpg
textures/prairie_1904_roofs/tin_flat_seam_painted/tin_flat_seam_painted_roughness.png
textures/prairie_1904_roofs/tin_standing_seam_painted/material.json
textures/prairie_1904_roofs/tin_standing_seam_painted/tin_standing_seam_painted_basecolor.png
textures/prairie_1904_roofs/tin_standing_seam_painted/tin_standing_seam_painted_basecolor_web.jpg
textures/prairie_1904_roofs/tin_standing_seam_painted/tin_standing_seam_painted_normal_gl.png
textures/prairie_1904_roofs/tin_standing_seam_painted/tin_standing_seam_painted_normal_gl_web.jpg
textures/prairie_1904_roofs/tin_standing_seam_painted/tin_standing_seam_painted_orm.png
textures/prairie_1904_roofs/tin_standing_seam_painted/tin_standing_seam_painted_orm_web.jpg
textures/prairie_1904_roofs/tin_standing_seam_painted/tin_standing_seam_painted_roughness.png
textures/prairie_1904_roofs/tools/generate_prairie_1904_roofs.py
textures/prairie_1904_roofs/tools/study_prairie_1904_roofs.py
textures/prairie_1904_roofs/zinc_sheet/material.json
textures/prairie_1904_roofs/zinc_sheet/zinc_sheet_basecolor.png
textures/prairie_1904_roofs/zinc_sheet/zinc_sheet_basecolor_web.jpg
textures/prairie_1904_roofs/zinc_sheet/zinc_sheet_normal_gl.png
textures/prairie_1904_roofs/zinc_sheet/zinc_sheet_normal_gl_web.jpg
textures/prairie_1904_roofs/zinc_sheet/zinc_sheet_orm.png
textures/prairie_1904_roofs/zinc_sheet/zinc_sheet_orm_web.jpg
textures/prairie_1904_roofs/zinc_sheet/zinc_sheet_roughness.png
```

## Generated assets

`gltf/` and `web/` are build output. Canonical archetype assets are regenerated by
`tools/bake.sh` from `data/` and `generators/`, and tracked in `assets/manifest.json`
with the input hash and the Blender version that produced them. Explicitly flagged
review massings for the anonymous reconstruction programme are regenerated without
Blender by `generators/inferred_placeholder.py`; the glTF asset itself carries
`asset.extras.placeholder: true`, the viewer says so, and `tools/check.sh` compares
the bytes to the source record. Do not hand-edit either kind; stale output is a check
failure.

| path | origin | license | notes |
|---|---|---|---|
| `gltf/sauganash_hotel__frame_1831.glb` | `tools/bake.sh` (this repo, Blender 4.5.3) from `data/structures/sauganash_hotel.json` | project license | The Milestone 0 bake. Generated output; its provenance is the provenance of the record it was generated from, tracked in `assets/manifest.json`. |
| `gltf/keith_house_1808_prairie__as_built_1886.glb` | `python3 generators/k01_emit.py` (this repo, pure Python, no Blender) from `data/structures/keith_house_1808_prairie.json` | project license | The first K01 component assembly (T-2266). Generated output; its provenance is its record's, tracked in `assets/manifest.json`. Embeds two images verbatim from `textures/glessner-v4/` (`limestone_basecolor.jpg`, `brick_basecolor.jpg`), original procedural pixels under that library's project-permissive terms (`textures/glessner-v4/LICENSE.txt`). |
| `web/keith_house_1808_prairie__as_built_1886.glb` | `tools/web_derivatives.sh` from the master above | project license | The web derivative of the K01 assembly; same provenance and the same two library images. |
| `gltf/pullman_house_1729_prairie_conservatory__as_standing_1904.glb` | `python3 generators/k13_emit.py` (this repo, pure Python, no Blender) from `data/structures/pullman_house_1729_prairie_conservatory.json` and the K13 kit | project license | The first K13 conservatory in the scene (T-2306). Generated output; its provenance is its record's, tracked in `assets/manifest.json`. Flat colours only: no image is embedded. |
| `web/pullman_house_1729_prairie_conservatory__as_standing_1904.glb` | `tools/web_derivatives.sh` from the master above | project license | The web derivative of the K13 conservatory; same provenance. |
| `gltf/shortall_gregory_house_1638_prairie_front__as_standing_1904.glb` | `python3 generators/k16_emit.py` (this repo, pure Python, no Blender) from `data/structures/shortall_gregory_house_1638_prairie_front.json` and the K16 kit | project license | The first K16 timber front in the scene (T-2323). Generated output; its provenance is its record's, tracked in `assets/manifest.json`. Flat colours only: no image is embedded. |
| `web/shortall_gregory_house_1638_prairie_front__as_standing_1904.glb` | `tools/web_derivatives.sh` from the master above | project license | The web derivative of the K16 timber front; same provenance. |
| `gltf/wheeler_house_1812_prairie_coach_house__as_standing_1904.glb` | `python3 generators/k12_emit.py` (this repo, pure Python, no Blender) from `data/structures/wheeler_house_1812_prairie_coach_house.json` | project license | The first K12 coach house on a named lot (T-2321). Generated output; its provenance is its record's, tracked in `assets/manifest.json`. Flat colours only; embeds no image. |
| `web/wheeler_house_1812_prairie_coach_house__as_standing_1904.glb` | `tools/web_derivatives.sh` from the master above | project license | The web derivative of the 1812 coach house; same provenance, no image. |
| `gltf/*__draft_1904.glb` (the one hundred and thirty-nine `prairie_draft` records) | `python3 generators/draft_emit.py` (this repo, pure Python, no Blender) from the matching `data/structures/*.json` record, written by `tools/draft_prairie_1904.py` | project license | The Prairie Avenue district draft (T-2329, T-2330, T-2334, T-2335, T-2351) and its named context buildings off the avenue (T-2982). Generated output; its provenance is its record's, tracked in `assets/manifest.json`. Flat colours only: no image is embedded. |
| `web/*__draft_1904.glb` | `tools/web_derivatives.sh` from the masters above | project license | The web derivatives of the district draft; same provenance. |
| `gltf/recon_1835_*__inferred_1835.glb` and matching `web/` derivatives | `generators/inferred_placeholder.py` from the matching `data/structures/recon_1835_*.json` record | project license | Pure-Python review massing for the 108 anonymous inferred roofs. Every file self-identifies as a placeholder and is replaced, not silently promoted, when the canonical family bake lands. |
| `humans/c4d_fixture.lod0.glb` | `tools/human_export.sh` (this repo, Blender 4.5.3): `tools/human_fixture_blend.py` builds the master, `tools/human_export.py` exports it | project license | The portable-human pipeline's CI fixture (T-1787, liberty L417): a figure that is nobody, built from primitives. Its master is the script, so the `.blend` is rebuilt on every run and this file is never the only copy. Its one texture, a 64 px twill, is generated in the script; nothing third-party is sampled or embedded. |
| `humans/web/c4d_fixture.lod0.glb` | `tools/human_export.sh` from the master above (gltf-transform `meshopt`, the `tools/web_derivatives.sh` pin) | project license | The Meshopt derivative of the fixture's LOD0; same provenance. |
| `humans/c4d_fixture.lod1.glb` | `tools/human_export.sh` (this repo, Blender 4.5.3): `tools/human_fixture_blend.py` builds the master, `tools/human_export.py` exports it | project license | The portable-human pipeline's CI fixture (T-1787, liberty L417): a figure that is nobody, built from primitives. Its master is the script, so the `.blend` is rebuilt on every run and this file is never the only copy. Its one texture, a 64 px twill, is generated in the script; nothing third-party is sampled or embedded. |
| `humans/web/c4d_fixture.lod1.glb` | `tools/human_export.sh` from the master above (gltf-transform `meshopt`, the `tools/web_derivatives.sh` pin) | project license | The Meshopt derivative of the fixture's LOD1; same provenance. |
| `humans/c4d_fixture.lod2.glb` | `tools/human_export.sh` (this repo, Blender 4.5.3): `tools/human_fixture_blend.py` builds the master, `tools/human_export.py` exports it | project license | The portable-human pipeline's CI fixture (T-1787, liberty L417): a figure that is nobody, built from primitives. Its master is the script, so the `.blend` is rebuilt on every run and this file is never the only copy. Its one texture, a 64 px twill, is generated in the script; nothing third-party is sampled or embedded. |
| `humans/web/c4d_fixture.lod2.glb` | `tools/human_export.sh` from the master above (gltf-transform `meshopt`, the `tools/web_derivatives.sh` pin) | project license | The Meshopt derivative of the fixture's LOD2; same provenance. |
| `humans/c4d_fixture.lod3.glb` | `tools/human_export.sh` (this repo, Blender 4.5.3): `tools/human_fixture_blend.py` builds the master, `tools/human_export.py` exports it | project license | The portable-human pipeline's CI fixture (T-1787, liberty L417): a figure that is nobody, built from primitives. Its master is the script, so the `.blend` is rebuilt on every run and this file is never the only copy. Its one texture, a 64 px twill, is generated in the script; nothing third-party is sampled or embedded. |
| `humans/web/c4d_fixture.lod3.glb` | `tools/human_export.sh` from the master above (gltf-transform `meshopt`, the `tools/web_derivatives.sh` pin) | project license | The Meshopt derivative of the fixture's LOD3; same provenance. |

`authored/` holds hero assets that cannot come from a structure record (Fort Dearborn
detailing, signboards). They are exempt from regeneration but **not** from provenance:
each needs a row here and a source record explaining what the form is based on.
### Glessner House stone-occlusion atlases (T-2431)

T-2494 retains each atlas's generated UV coordinates in the same NPZ, with the exact
mesh/unwrap-recipe key and a coordinate checksum. These are coordinates generated
from this project's own mesh, under the same project license; no reference pixels
or third-party mesh data are incorporated.

Generated output of this repository's own Cycles bake (`generators/archetypes/masonry_house_v4_occlusion.py`, Blender 4.5.3) of the Glessner House's own geometry: the quantised ambient-occlusion atlas of its granite, kept so a bake on any CPU reproduces the committed models. Nothing third-party is sampled or embedded; project license. Provenance is the model's, tracked in `assets/manifest.json`.

- `bakes/stone-occlusion/README.md`
- `bakes/stone-occlusion/granite_stone_occlusion_1024.npz`
- `bakes/stone-occlusion/granite_stone_occlusion_2048.npz`

### Glessner House v4 original surface studies

The following 44 files are original project material assets: twelve deterministic numeric PBR fabrics, three unchanged original generated albedo studies, their executable recipe and provenance. No historical, owner, Google or other third-party image pixels are sampled or embedded. Numeric maps are reproduced by `generate.py`; generated image prompts, hashes, methods and reconstructed confidence are preserved in the three provenance JSON files. Exact appearance is reconstructed, not historical evidence. Use, modification and redistribution with this project are permitted under the accompanying `LICENSE.txt`; retain provenance and confidence.

- `textures/glessner-v4/LICENSE.txt`
- `textures/glessner-v4/README.md`
- `textures/glessner-v4/brick_basecolor.jpg`
- `textures/glessner-v4/brick_normal.png`
- `textures/glessner-v4/brick_roughness.png`
- `textures/glessner-v4/court_brick_basecolor.jpg`
- `textures/glessner-v4/common_brick_basecolor.jpg`
- `textures/glessner-v4/copper_basecolor.jpg`
- `textures/glessner-v4/copper_normal.png`
- `textures/glessner-v4/copper_roughness.png`
- `textures/glessner-v4/generate.py`
- `textures/glessner-v4/granite_basecolor.jpg`
- `textures/glessner-v4/granite_normal.png`
- `textures/glessner-v4/granite_occlusion.png`
- `textures/glessner-v4/granite_photographic_basecolor.png`
- `textures/glessner-v4/granite_photographic_provenance.json`
- `textures/glessner-v4/granite_roughness.png`
- `textures/glessner-v4/gravel_basecolor.jpg`
- `textures/glessner-v4/gravel_normal.png`
- `textures/glessner-v4/gravel_roughness.png`
- `textures/glessner-v4/limestone_basecolor.jpg`
- `textures/glessner-v4/limestone_normal.png`
- `textures/glessner-v4/limestone_roughness.png`
- `textures/glessner-v4/material-library.json`
- `textures/glessner-v4/mortar_basecolor.jpg`
- `textures/glessner-v4/mortar_normal.png`
- `textures/glessner-v4/mortar_roughness.png`
- `textures/glessner-v4/oak_basecolor.jpg`
- `textures/glessner-v4/oak_normal.png`
- `textures/glessner-v4/oak_roughness.png`
- `textures/glessner-v4/painted_wood_basecolor.jpg`
- `textures/glessner-v4/painted_wood_normal.png`
- `textures/glessner-v4/painted_wood_roughness.png`
- `textures/glessner-v4/terracotta_basecolor.jpg`
- `textures/glessner-v4/terracotta_normal.png`
- `textures/glessner-v4/terracotta_roughness.png`
- `textures/glessner-v4/roof_tiles_basecolor.jpg`
- `textures/glessner-v4/roof_tiles_normal.png`
- `textures/glessner-v4/roof_tiles_roughness.png`
- `textures/glessner-v4/turf_basecolor.jpg`
- `textures/glessner-v4/turf_normal.png`
- `textures/glessner-v4/turf_patch_photographic_basecolor.png`
- `textures/glessner-v4/turf_patch_provenance.json`
- `textures/glessner-v4/turf_photographic_basecolor.png`
- `textures/glessner-v4/turf_photographic_provenance.json`
- `textures/glessner-v4/turf_roughness.png`


T-2220 copper: `textures/glessner-v4/copper_basecolor.jpg` and
`copper_roughness.png` are original procedural pixels from `generate.py --only
copper`, under the existing material-library LICENSE.txt. Drainage streaks are
numeric fields, not sampled photographs. The low hood and seam geometry derive
from unrestricted HABS section controls and declared stock reconstructions
(L-glessner-copper-2220). The three `wlemay_glessner_courtyard_2024_*` source
records are CC BY-SA 2.0 reference comparisons; their credited library display
and thumbnail copies retain that license in the separate chicago-images store.
No photographic pixels or traced patterns are embedded in model assets.

### T-2495 outer lakefront terrain

`data/terrain/epochs/e1871_postfire/context_ground.glb` (stored beside its terrain
sidecars, outside assets/) is generated by `tools/extend_ic_lakefront_1904.py` from
project heightfield data and map-coordinate readings. Project license; no raster
texture is embedded. The underlying 1904 Talbot map is public domain, credited to
the University of Chicago Library, Map Collection; source record
`data/sources/talbot_1904_railroad_map.json` records the provenance.

### Glessner chimney refinement (T-2222)

The regenerated Glessner master and Full/Light derivatives retain their existing
asset license. New chimney placement/cap construction rests on unrestricted HABS
IL-1015 measured drawings and public-domain Taylor2135; service masonry is a
bounded reconstruction corroborated by w_lemay's CC BY-SA2.0 courtyard photographs
159537051 and159537085. Source records retain creator, license and catalog links.
These are credited reference copies, not projected texture pixels or traced stone
patterns. The existing metric granite/brick/limestone textures are unchanged.
The Inland1888 digital reproduction and copied HABS05 remain textual/qualitative
cross-checks only and supply no new derived geometry or texture. Full/Light
simplifications and invented flue dimensions are declared in L-glessner-stacks-2222.
The HABS drawing excerpts in the T-2222 research folder are annotated diagnostic
crops of unrestricted federal measured drawings, not newly surveyed dimensions.

### Glessner service-access refinement (T-2223)

Generated Glessner Full/web/Light geometry and recovery assets follow the
existing model license. Service-access layout uses cleared HABS IL-1015 drawing
sheets 2 and 4. The qualitative stair/rail/capital comparison uses w_lemay's
October 26, 2024 Commons photograph 159537058 and the previously credited
159537051; CC BY-SA 2.0, https://creativecommons.org/licenses/by-sa/2.0/.
The new Prairie library display and thumbnail retain w_lemay attribution and
that license. They derive from the recorded 1920×1440 display rendition,
not the unavailable native original. No photographic pixels become textures.
Gate finish and hidden joints are procedural bounded reconstructions; no
uncleared photograph is traced. Research browser screenshots are generated
from this project's scene and contain no imported reference photograph.

### Glessner courtyard ground (T-2224)

The regenerated Full/web/Light model and recovery assets retain the existing model
license. New functional circulation is independently reconstructed from the cleared
HABS IL-1015 sheet 2 opening/stair locations and public-domain written alteration
history. HABS05 is rights-uncleared and is not traced for this work. The plan does not
identify 1904 paths or paving materials; those choices are declared in
L-glessner-court-ground-2224. Existing original procedural gravel and turf textures
are unchanged. Browser screenshots and the schematic ground plot are generated
project diagnostics, not reproductions of a historical courtyard photograph.


### T-2225 — Original Glessner vine atlas and generated planting

`assets/textures/glessner-v4/vines_atlas.png` is original procedural artwork generated by `python3 tools/generate_glessner_vines.py` from `form.vines_details` and `generators/archetypes/masonry_house_v4_vines.py`. It contains no sampled photograph, external illustration or imported texture. The numeric profiles, vein/serration strokes and reconstructed summer colours are created for this project and covered by the repository license. The public-domain USDA NRCS Plant Guide by Kellie King and James Henson (edited2005/2006, source `usda_nrcs_virginia_creeper_2006`) bounds Virginia-creeper botanical facts only. HABS supplies the walls/openings; no source supplies the invented July1904 coverage. Boston ivy profiles are independent original botanical reconstructions. The Full and Light Glessner assets share this atlas and carry L-glessner-vines-2225; existing house/master/derivative provenance remains applicable.


### Glessner plain-brick surface study — T-2226

`textures/glessner-v4/flat_brick_basecolor.png`, `textures/glessner-v4/flat_brick_normal.png` and `textures/glessner-v4/flat_brick_roughness.png` are original procedural artwork generated by `python3 tools/generate_glessner_finish.py` from `form.surface_finish`, the existing original courtyard clay/mortar maps and `generators/archetypes/masonry_house_v4_finish.py`. They contain no photograph pixels, tracings or imported material and are covered by the repository license. Cleared HABS measured drawings, the licensed w_lemay courtyard reference and the owner brief bound the declared reconstruction; the family typescript remains a textual comparison with unresolved rights unchanged and supplies no asset pixels or traced pattern. Full and Light share these maps. See L-glessner-finish-2226; existing house/master/derivative provenance remains applicable.


### T-1883 — Keith house stone-front finish (2026-10-16)

`gltf/keith_house_1808_prairie__as_built_1886.glb` and its `web/` derivative are
procedurally generated from the structure record by `generators/k01_emit.py`.
The geometry is project-authored under the repository licence. Existing K02 granite
and dressed-stone textures retain their own entries above; no photograph is used
as a texture. The reconstruction uses the February 1888 Inland Architect plate,
credited to Inland Architect Press, scan via Internet Archive (Serials in Microfilm).
The project owner expressly approved this image for T-1883 on 2026-10-16; see
`data/sources/inland_architect_1888_02_keith_plate.json` for the scope and exact quote.
The reference scan is `data/sources/assets/inland_architect_1888_02_keith/plate.jpg`.
The September 1886 notice is public-domain textual evidence for granite; the
neutral light greige tint is reconstructed, not a colour sampled from the monochrome plate.

The additional comparison photographs retain the credits, source links and unresolved
rights recorded in [the reference credit ledger](../data/sources/assets/inland_architect_1888_02_keith/README.md).
They are research copies under the owner’s library instruction, not material textures or
a claim that the plate approval covers later photographs.


Glessner T-2228 entrance-section update (2026-10-16): generated geometry additionally cites public-domain Richardson office doorway23A, `artic_glessner_sheet_23a_entrance_detail`, corroborated by U.S. Government HABS IL-1015 sheet5. No photographic or drawing pixels are embedded in the asset; exact relief dimensions remain reconstructed.

## textures/trees/ — the grown trees' leaf and bark atlases (T-2743)

textures/trees/leaf_atlas.webp
textures/trees/bark_basecolor.webp
textures/trees/bark_normal.webp
textures/trees/leaf_atlas.ktx2
textures/trees/bark_basecolor.ktx2
textures/trees/bark_normal.ktx2

These are painted from code (the .ktx2 files are GPU-compressed copies of the same maps) by `tools/generate_tree_atlas.py` (seeded noise, cell patterns and drawn leaf
outlines), and the generator reproduces them. One photograph is sampled: since T-3247 the elm
tiles' blades take their surface (lightness only) from Steven J. Baskauf, *Ulmus americana
(Ulmaceae) - leaf - whole upper surface*, 2 June 2002, [Bioimages, Vanderbilt University
image 11688](https://bioimages.vanderbilt.edu/baskauf/11688.htm), **CC BY 4.0**
(https://creativecommons.org/licenses/by/4.0/); source record `bioimages_ulmus_americana_11688`,
the photograph at `data/sources/assets/bioimages_ulmus_americana_11688/`. The leaf atlas is an
adaptation of it and carries that attribution; everything else in these files is
project-authored under the repository licence. They show what a species' leaf and bark
generally look like; they are not evidence about any tree that stood (docs/LIBERTIES.md
L-tree-architecture-2743). Since T-1934 the leaf atlas has a sixth row: a bare elm's winter
twig (a branch end's, and a tuft of them), drawn by the same generator in code alone, no
photograph sampled.


### Anonymous adult source and preparation — `authored/humans/makehuman_hm08/`

The verbatim MakeHuman graphical assets are **CC0-1.0**,
pinned to [MakeHuman commit a8bc2d54ff0ac92e78ff71431b1023eda42bf482](https://github.com/makehumancommunity/makehuman/tree/a8bc2d54ff0ac92e78ff71431b1023eda42bf482).
The upstream license documents are preserved verbatim under their own distribution
terms; LICENSE.CODE.md is a license notice, not included program code.
`SOURCE.json` records per-file upstream URLs and SHA-256 hashes; the OBJ, skeleton,
weights and material retain their own CC0 notices. Upstream application code is AGPL
and is not included or copied into the preprocessing tool. `LICENSE.md.gz` losslessly preserves
the upstream explanation of this distinction. Original `prepared.json`,
`prepared.report.json`, `SOURCE.json` and README adaptations are CC0-1.0.
Height, pose, joint mapping and weight pruning are reconstructed (L418). This is a
cleared modeling input, not a finished photographic person. No external skin-image
pack has been imported.

Originally authored canonical workwear masters under `authored/humans/teamsters/`
and their `humans/*_1835.lod*.glb` / `humans/web/*_1835.lod*.glb`
exports are CC0-1.0 with the same base provenance and L418 reconstruction declaration.
These paths become deliverables only after the CI bake produces and validates them;
listing the license does not assert the files already exist or meet production quality.

Exact covered paths (future canonical/export paths retain the provisional status above):

```text
authored/humans/makehuman_hm08/LICENSE.ASSETS.md
authored/humans/makehuman_hm08/LICENSE.CODE.md
authored/humans/makehuman_hm08/LICENSE.md.gz
authored/humans/makehuman_hm08/README.md
authored/humans/makehuman_hm08/SOURCE.json
authored/humans/makehuman_hm08/adult_25.recipe.json
authored/humans/makehuman_hm08/adult_35.recipe.json
authored/humans/makehuman_hm08/makehuman/data/3dobjs/base.obj
authored/humans/makehuman_hm08/makehuman/data/rigs/default.mhskel
authored/humans/makehuman_hm08/makehuman/data/rigs/default_weights.mhw
authored/humans/makehuman_hm08/makehuman/data/skins/default.mhmat
authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/african-male-old.target
authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/african-male-young.target
authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/asian-male-old.target
authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/asian-male-young.target
authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/caucasian-male-old.target
authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/caucasian-male-young.target
authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/universal-male-young-averagemuscle-averageweight.target
authored/humans/makehuman_hm08/prepared.json
authored/humans/makehuman_hm08/prepared.report.json
authored/humans/makehuman_hm08/prepared_adult_25.json
authored/humans/makehuman_hm08/prepared_adult_25.report.json
authored/humans/makehuman_hm08/prepared_adult_35.json
authored/humans/makehuman_hm08/prepared_adult_35.report.json
authored/humans/teamsters/bardwell_otis_1835/canonical.blend
humans/bardwell_otis_1835.lod0.glb
humans/web/bardwell_otis_1835.lod0.glb
humans/bardwell_otis_1835.lod1.glb
humans/web/bardwell_otis_1835.lod1.glb
humans/bardwell_otis_1835.lod2.glb
humans/web/bardwell_otis_1835.lod2.glb
humans/bardwell_otis_1835.lod3.glb
humans/web/bardwell_otis_1835.lod3.glb
authored/humans/teamsters/dufresne_joseph_1835/canonical.blend
humans/dufresne_joseph_1835.lod0.glb
humans/web/dufresne_joseph_1835.lod0.glb
humans/dufresne_joseph_1835.lod1.glb
humans/web/dufresne_joseph_1835.lod1.glb
humans/dufresne_joseph_1835.lod2.glb
humans/web/dufresne_joseph_1835.lod2.glb
humans/dufresne_joseph_1835.lod3.glb
humans/web/dufresne_joseph_1835.lod3.glb
authored/humans/teamsters/flynn_martin_1835/canonical.blend
humans/flynn_martin_1835.lod0.glb
humans/web/flynn_martin_1835.lod0.glb
humans/flynn_martin_1835.lod1.glb
humans/web/flynn_martin_1835.lod1.glb
humans/flynn_martin_1835.lod2.glb
humans/web/flynn_martin_1835.lod2.glb
humans/flynn_martin_1835.lod3.glb
humans/web/flynn_martin_1835.lod3.glb
```


### Hair component — `authored/humans/hair_bun_brown/` (CC0-1.0)

RehmanPolanski, *hair bun brown* (2020; UUID `9bf96086-aaa0-4a13-9d83-71b6c4b4732a`),
adapted by its author from the MakeHuman system ponytail01. **CC0** in the official
MakeHuman pack: <https://files2.makehumancommunity.org/asset_packs/hair01/hair01_cc0.zip>
(ETag `"d93956d-6160e7894ff24"`), whose pack page and `packs/hair01.json` list it as CC0;
that record is retained as `hair01.original.json`. The OBJ and MHCLO headers keep the
MakeClothes default export stamp ("license AGPL3 (see also … external_tools_license)");
the author's CC0 listing in the official pack is the release relied on, and both are
recorded in SOURCE.json. The OBJ, MHCLO, MHMAT and PNG are unchanged archive entries,
each checked against the archive's CRC-32. `hair_bun_brown_dark_tie.png` is a project
CC0 derivative (the red velvet tie recoloured dark brown). No MakeHuman program or
shader code is included. This component conveys no historical likeness (T-3434).

| Path relative to assets/ | Kind | SHA-256 |
|---|---|---|
| authored/humans/hair_bun_brown/Hair_bun_brown.png | CC0 original graphical source | `ebcf2d58a5f8dfe11db376e559d0308e57da00170cde1c1304871bab10d251fa` |
| authored/humans/hair_bun_brown/README.md | CC0 original project documentary | `9e1dbb82b77985dc3da97a25aad5cc3456a58d317ea58bc4fb54f67e8d283b7e` |
| authored/humans/hair_bun_brown/SOURCE.json | CC0 original project documentary | `1c4e95ace2160f24f37837e4ae8dd592c85f9c3cf0afd53bcf0ed5789ca30903` |
| authored/humans/hair_bun_brown/hair01.original.json | CC0 pack metadata record | `34f0f557598a989cf94b00eef7cf7147c37b8b31007013fa08bbc2d22374085b` |
| authored/humans/hair_bun_brown/hair_bun_brown.mhmat | CC0 original graphical/source metadata | `4f5c86a531b73707505632b36507c30f8759cea2f001de06d794aa1c4e1be716` |
| authored/humans/hair_bun_brown/hair_bun_brown.obj | CC0 original graphical/source metadata | `87620ef37e13235c103415db778ae583b4f1abab21323ac1180bce57bef64856` |
| authored/humans/hair_bun_brown/hair_bun_brown_dark_tie.png | CC0 derived texture (tie recoloured) | `15339830ff1143c171ee83b807948d7a7989c108df3088fd03777b3c5adde340` |
| authored/humans/hair_bun_brown/rehmanpolanski_hair_bun_brown.mhclo | CC0 original graphical/source metadata | `54f136555d516f940268881e75453305789ff430be85032f25864d773ebe9676` |


### Skin material component — `authored/humans/skin_mh_old_lightskinned_male/`

MakeHuman's own system skin *old_caucasian_male* (`old_lightskinned_male_diffuse.png`),
**CC0-1.0** by the statement in its material file ("explicitly released as CC0 in
september 2020"; Data Collection AB, Joel Palmius, Jonas Hauquier), kept unchanged here;
source <https://files2.makehumancommunity.org/asset_packs/makehuman_system_assets/makehuman_system_assets_cc0.zip>.
The original 2048² atlas (SHA-256 `dfb2310ed3e0ad024ea7a3ad321215e2e9e2994cca64043d9f3d07c6543ec847`)
is pinned in SOURCE.json and not kept; `old_lightskinned_male_bald_crown.png` is its CC0
derivative with the scalp stubble blended to skin by `tools/human_skin_bald_scalp.py`
(SHA-256 `d97a3f236a1a4fd7cb846e5f8575a219c86e5947e1bbcf9c4d444ab293e344d8`). SOURCE/README
are project-authored CC0. This component conveys no historical likeness (T-3441).

Additional exact covered CC0 graphical/derived and documentary paths:

```text
authored/humans/skin_mh_old_lightskinned_male/README.md
authored/humans/skin_mh_old_lightskinned_male/SOURCE.json
authored/humans/skin_mh_old_lightskinned_male/old_caucasian_male.mhmat
authored/humans/skin_mh_old_lightskinned_male/old_lightskinned_male_bald_crown.png
```


### Face library — `authored/humans/face_library/` and `humans/web/faces/hm08_faces.jpg` (T-3553)

The face of each of 22 skin atlases MakeHuman and its community publish as **CC0-1.0**, for
the people who have no pictures of their own (owner, 2026-11-14: "MakeHuman skins only for
now"; liberty `L-face-library-3553`). Three packs, each fetched on 2026-11-14 from the
MakeHuman community's own server:
<https://files2.makehumancommunity.org/asset_packs/makehuman_system_assets/makehuman_system_assets_cc0.zip>
(MakeHuman's own system skins; CC0 by the statement in each skin's material file,
"explicitly released as CC0 in september 2020", Data Collection AB, Joel Palmius, Jonas
Hauquier; the files kept unchanged in `materials/`),
<https://files2.makehumancommunity.org/asset_packs/skins01/skins01_cc0.zip> and
<https://files2.makehumancommunity.org/asset_packs/skins02/skins02_cc0.zip> (community
skins; CC0 in each pack's own record of the asset, kept unchanged as
`skins01.original.json` and `skins02.original.json`; the community material files are not
kept and not used, but each is read once for a licence line of its own, and `SOURCE.json`
keeps its hash and any line found). The system pack's own record is kept unchanged too, as
`makehuman_system_assets.original.json`, so the three packs' 59 skins can be counted against
the 22 kept and the 37 left out. `SOURCE.json` pins all three records by SHA-256. Each `faces/<id>.png` is the unchanged 512 by 512 pixel box
`[1504, 800, 2016, 1312]` of its 2048 by 2048 atlas; the atlases are not kept, and
`SOURCE.json` pins each by size, CRC-32 and SHA-256. No photograph of any person is among
them. These components convey no historical likeness, and a pack's own name for a skin is
not a fact about anyone who wears its face.

| File | Creator and source | Rights |
|---|---|---|
| `authored/humans/face_library/faces/young_lightskinned_female.png` | MakeHuman system skin `young_caucasian_female` (Data Collection AB, Joel Palmius, Jonas Hauquier) | CC0-1.0 by its material file's header, kept in `materials/`; atlas SHA-256 `b2a6ac8cd4f9febdb447368e29c76cd68410bb66e46d9dcfa2d5f75126eea8fc` |
| `authored/humans/face_library/faces/young_lightskinned_female_2.png` | MakeHuman system skin `young_caucasian_female2` (Data Collection AB, Joel Palmius, Jonas Hauquier) | CC0-1.0 by its material file's header, kept in `materials/`; atlas SHA-256 `8d1fb3ceedf142fad32a3504eca1feb4539aecca6de66acde1514b9a61fc7ba0` |
| `authored/humans/face_library/faces/middleage_lightskinned_female.png` | MakeHuman system skin `middleage_caucasian_female` (Data Collection AB, Joel Palmius, Jonas Hauquier) | CC0-1.0 by its material file's header, kept in `materials/`; atlas SHA-256 `bcb9c2c8ace23880bc4407602a249abbcf4608b6ba0894e423b031913012a363` |
| `authored/humans/face_library/faces/middleage_lightskinned_female_2.png` | MakeHuman system skin `middleage_asian_female` (Data Collection AB, Joel Palmius, Jonas Hauquier) | CC0-1.0 by its material file's header, kept in `materials/`; atlas SHA-256 `39c505ca224387bef0b20cd2bf513c3997c27c7e7434447228c9991b87cb8d01` |
| `authored/humans/face_library/faces/old_lightskinned_female.png` | MakeHuman system skin `old_caucasian_female` (Data Collection AB, Joel Palmius, Jonas Hauquier) | CC0-1.0 by its material file's header, kept in `materials/`; atlas SHA-256 `00c45246c145562b917371e92de44a1fe394bc5f4bd91418addf24b6adff5e9d` |
| `authored/humans/face_library/faces/old_lightskinned_female_2.png` | MakeHuman system skin `old_asian_female` (Data Collection AB, Joel Palmius, Jonas Hauquier) | CC0-1.0 by its material file's header, kept in `materials/`; atlas SHA-256 `e0c6317c2354ee54c16ad5f871293121e4eee697d16423536bb1db3641d56bc9` |
| `authored/humans/face_library/faces/young_lightskinned_male.png` | MakeHuman system skin `young_caucasian_male` (Data Collection AB, Joel Palmius, Jonas Hauquier) | CC0-1.0 by its material file's header, kept in `materials/`; atlas SHA-256 `862a26e335e958b70534cb5f0d7c47ef30ab148a56c42b3e9da969cf76f12963` |
| `authored/humans/face_library/faces/young_lightskinned_male_2.png` | MakeHuman system skin `young_caucasian_male2` (Data Collection AB, Joel Palmius, Jonas Hauquier) | CC0-1.0 by its material file's header, kept in `materials/`; atlas SHA-256 `03efe1f6b0ae52429649dcefc9dcaef6058032f874a251169cc3e2ed473c3874` |
| `authored/humans/face_library/faces/middleage_lightskinned_male.png` | MakeHuman system skin `middleage_caucasian_male` (Data Collection AB, Joel Palmius, Jonas Hauquier) | CC0-1.0 by its material file's header, kept in `materials/`; atlas SHA-256 `3f94f3f6a5cab92dedf5cce392a87332312fc435f1cb44c6e7b897daef9a5fbb` |
| `authored/humans/face_library/faces/old_lightskinned_male.png` | MakeHuman system skin `old_caucasian_male` (Data Collection AB, Joel Palmius, Jonas Hauquier) | CC0-1.0 by its material file's header, kept in `materials/`; atlas SHA-256 `dfb2310ed3e0ad024ea7a3ad321215e2e9e2994cca64043d9f3d07c6543ec847` |
| `authored/humans/face_library/faces/old_lightskinned_male_2.png` | MakeHuman system skin `old_asian_male` (Data Collection AB, Joel Palmius, Jonas Hauquier) | CC0-1.0 by its material file's header, kept in `materials/`; atlas SHA-256 `8b3232676c5b271b4f44ead68845155d93f15de641b6819561781e16701a6c59` |
| `authored/humans/face_library/faces/callharvey3d_midtoned_female.png` | callharvey3d, `callharvey3d_midtoned_female` (skins01), http://www.makehumancommunity.org/node/802 | CC0-1.0 in the pack's own record, kept as `skins01.original.json`; atlas SHA-256 `dd0e953bb1ec3eee3d4956853599372c8faf5ba69982f0b4c3cc220b70cb0be0`. The pack's material file for this skin (not kept, not used) is MakeHuman's 2016 material for its `young_african_female` skin reused with its header ("This file is licensed AGPLv3"); the atlas is read as CC0 on the pack's record and on MakeHuman's September 2020 CC0 release of the skin it was made from (`licence_note` in `data/humans/variation/face_library.json`) |
| `authored/humans/face_library/faces/cutoff3d_female.png` | CutOff3D, `cutoff3d_indian_female_skin` (skins01), http://www.makehumancommunity.org/node/3013 | CC0-1.0 in the pack's own record, kept as `skins01.original.json`; atlas SHA-256 `09ec5071c5be9c3e1d36b52675eb053152796b3f75abc2e96853a277174856a8` |
| `authored/humans/face_library/faces/onlytheghosts_young_female.png` | OnlyTheGhosts, `onlytheghosts_young_eurasian_female` (skins01), http://www.makehumancommunity.org/node/1578 | CC0-1.0 in the pack's own record, kept as `skins01.original.json`; atlas SHA-256 `e4547a04bab2244d8ec6bcb1d239f4cddb83f145d4ce2a5c7734ec514c8bebcf` |
| `authored/humans/face_library/faces/onlytheghosts_middleage_female.png` | OnlyTheGhosts, `onlytheghosts_middle_aged_eurasian_female` (skins01), http://www.makehumancommunity.org/node/1579 | CC0-1.0 in the pack's own record, kept as `skins01.original.json`; atlas SHA-256 `621d572153231348c5ff1248a72721109f5b4855215c895cb15d2991a22fff84` |
| `authored/humans/face_library/faces/onlytheghosts_old_female.png` | OnlyTheGhosts, `onlytheghosts_old_eurasian_female` (skins01), http://www.makehumancommunity.org/node/1580 | CC0-1.0 in the pack's own record, kept as `skins01.original.json`; atlas SHA-256 `ff3e6ceba012b6be73f168b01145aeb4925f7db45b4790ab71b33a28e7ce644b` |
| `authored/humans/face_library/faces/toigo_freckles_female.png` | MargaretToigo, `toigo_light_skin_female_freckles` (skins01), http://www.makehumancommunity.org/node/1134 | CC0-1.0 in the pack's own record, kept as `skins01.original.json`; atlas SHA-256 `8d8b7dac34f97ebdd8605b51d527ac6863685054b33e1004b3e309599542beaf` |
| `authored/humans/face_library/faces/toigo_ginger_female.png` | MargaretToigo, `toigo_light_skin_female_ginger` (skins01), http://www.makehumancommunity.org/node/1130 | CC0-1.0 in the pack's own record, kept as `skins01.original.json`; atlas SHA-256 `8b547a325983272838738b58a5992f032f3cb065ce137699f94211e96ead13b1` |
| `authored/humans/face_library/faces/toigo_ginger_female_2.png` | MargaretToigo, `toigo_light_skin_female_ginger_2` (skins01), http://www.makehumancommunity.org/node/1132 | CC0-1.0 in the pack's own record, kept as `skins01.original.json`; atlas SHA-256 `6a644aa688dfe2451579533a578b63ee1d0785ab900b43d172d0f005f21d8a55` |
| `authored/humans/face_library/faces/onlytheghosts_old_male.png` | OnlyTheGhosts, `onlytheghosts_old_eurasian_male` (skins02), http://www.makehumancommunity.org/node/1581 | CC0-1.0 in the pack's own record, kept as `skins02.original.json`; atlas SHA-256 `923dee56ac9527886ab8b0498566bea15442a37ea4b4adaf88e40138ab38a0d4` |
| `authored/humans/face_library/faces/toigo_freckles_male.png` | MargaretToigo, `toigo_light_skin_male_freckles` (skins02), http://www.makehumancommunity.org/node/1137 | CC0-1.0 in the pack's own record, kept as `skins02.original.json`; atlas SHA-256 `32d33fab52bda1b6bc8cd134bb34f2980a77d2b51c9f048e8ea00c861b4da604` |
| `authored/humans/face_library/faces/toigo_ginger_male.png` | MargaretToigo, `toigo_light_skin_male_ginger` (skins02), http://www.makehumancommunity.org/node/1135 | CC0-1.0 in the pack's own record, kept as `skins02.original.json`; atlas SHA-256 `795eec22b27ba5a2527d99e60a31be61e06a45a39250c39b24b36438e963c4aa` |

`humans/web/faces/hm08_faces.jpg` is the sheet the app reads: those 22 cuts, each scaled to
256 pixels and multiplied to one tone where it meets the skin round it, laid side by side by
`tools/face_library.py` (a CC0-1.0 derivative of the CC0 cuts above; its SHA-256 is in
`data/humans/variation/face_library.json`). SOURCE and README are project-authored CC0.
`evidence/young_african_female.mhmat` is MakeHuman's own material file for a skin that is not
used here, kept unchanged (CC0 by its own header) because the licence note for
`callharvey3d_midtoned_female` cites it: that face's atlas was made from that skin.

Additional exact covered CC0 source-metadata and documentary paths:

```text
authored/humans/face_library/README.md
authored/humans/face_library/SOURCE.json
authored/humans/face_library/evidence/young_african_female.mhmat
authored/humans/face_library/makehuman_system_assets.original.json
authored/humans/face_library/materials/middleage_asian_female.mhmat
authored/humans/face_library/materials/middleage_caucasian_female.mhmat
authored/humans/face_library/materials/middleage_caucasian_male.mhmat
authored/humans/face_library/materials/old_asian_female.mhmat
authored/humans/face_library/materials/old_asian_male.mhmat
authored/humans/face_library/materials/old_caucasian_female.mhmat
authored/humans/face_library/materials/old_caucasian_male.mhmat
authored/humans/face_library/materials/young_caucasian_female.mhmat
authored/humans/face_library/materials/young_caucasian_female2.mhmat
authored/humans/face_library/materials/young_caucasian_male.mhmat
authored/humans/face_library/materials/young_caucasian_male2.mhmat
authored/humans/face_library/skins01.original.json
authored/humans/face_library/skins02.original.json
```


### Skin material component — `authored/humans/skin_toigo_bronze_female/`

MargaretToigo, *young light-skinned female, bronze variation* (2017, changed 2019),
**CC0-1.0** in the official MakeHuman pack metadata; source
<https://files2.makehumancommunity.org/asset_packs/skins01/skins01_cc0.zip>,
asset page <http://www.makehumancommunity.org/node/1133>. The unchanged 2048² PNG
is SHA-256 `535535f30bacd42111590df4b03cf3b6bcdb7db18f336ce670665ec332ab3e0b`.
The pack metadata, material and extraction checks are retained beside it; the
original SOURCE/README are project-authored CC0. This component conveys no
historical likeness (T-3434).

Additional exact covered CC0 graphical/derived and documentary paths:

```text
authored/humans/skin_toigo_bronze_female/README.md
authored/humans/skin_toigo_bronze_female/SOURCE.json
authored/humans/skin_toigo_bronze_female/skins01.original.json
authored/humans/skin_toigo_bronze_female/toigo_light_skin_female_bronze.mhmat
authored/humans/skin_toigo_bronze_female/young_lightskinned_female_diffuse_Bronze.png
```


### Skin material component — `authored/humans/skin_toigo_bronze/`

MargaretToigo, *young light-skinned male, bronze variation* (2017, changed 2019),
**CC0-1.0** in the actual official MakeHuman pack metadata; source
<https://files2.makehumancommunity.org/asset_packs/skins02/skins02_cc0.zip>,
asset page <http://www.makehumancommunity.org/node/1136>. The unchanged 2048² PNG
is SHA-256 `5a53213f061bfa97ee0afd6b40650ffbc089a479c144e63f3c39acceca5853c0`.
Exact metadata, material, official-page copies and extraction checks are retained
beside it; those documentary copies retain their source terms, while the original
SOURCE/README are project-authored CC0. This component conveys no historical likeness.

Additional exact covered CC0 graphical/derived and documentary paths:

```text
authored/humans/skin_toigo_bronze/README.md
authored/humans/skin_toigo_bronze/SOURCE.json
authored/humans/skin_toigo_bronze/skins02.official-page.md
authored/humans/skin_toigo_bronze/skins02.original.json
authored/humans/skin_toigo_bronze/toigo_light_skin_male_bronze.mhmat
authored/humans/skin_toigo_bronze/young_lightskinned_male_diffuse_Bronze.png
```

The upstream MakeHuman overview notice is retained verbatim as deterministic gzip:
its original seven-equals Markdown heading conflicts with the repository's literal
marker scan. SOURCE.json records both original and stored hashes and sizes, and the
preparation tool verifies the decompressed original too. No notice wording or
conflict-check assertion is changed.


### Hair component — `authored/humans/hair_short04/` (CC0-1.0)

MakeHuman system **short04**, UUID `e09bfd91-f83f-4f9a-ba8c-4635cd1ae0d8`, officially listed author `makehuman_system`. Actual original OBJ, mhclo and mhmat headers EACH state:

> This asset was explicitly released as CC0 in september 2020.
> Copyright (C) 2020 Data Collection AB, https://www.datacollection.se
> Copyright (C) 2020 Joel Palmius
> Copyright (C) 2020 Jonas Hauquier

Original archive: <https://files2.makehumancommunity.org/asset_packs/makehuman_system_assets/makehuman_system_assets_cc0.zip>, ETag `"10bbb7ea-6160e7c0d7996"`. The original material directly names `short04_diffuse.png`; that texture is part of the expressly CC0 asset. No separate PNG license exception found. The headers refer to the upstream CC0 legal text; this component does not falsely claim a separate legal-text file was extracted from the archive. Retain original notices verbatim. No MakeHuman AGPL program or shader code included in the asset.

The periodic padded PNG is an original CC0 source derivative, explicitly labeled draft. README.md and SOURCE.json are original project-authored CC0 documentary provenance; original `.mhmat`/`.mhclo`/`.obj` notices retain their exact upstream wording. All exact component paths and SHA-256 hashes:

| Path relative to assets/ | Kind | SHA-256 |
|---|---|---|
| authored/humans/hair_short04/README.md | CC0 original project documentary | `fb920ea8d0082d3080db8acf6ed0d98805335ee166e1e1957861a3c520ac7679` |
| authored/humans/hair_short04/SOURCE.json | CC0 original project documentary | `68a02130cd50dd0d727f31f8f53702fe91bd9ecb9aa98309a7814191abf89e99` |
| authored/humans/hair_short04/short04.mhclo | CC0 original graphical/source metadata | `d60640aa4c4ffce1aa269647ba436b6ee0bb21bb948f927b84e27a48d2107157` |
| authored/humans/hair_short04/short04.mhmat | CC0 original graphical/source metadata | `7a3ac74db8478aa0afdb8a596c6fe3997d1a8a09d12211d70e8f1e9f0b7e0e97` |
| authored/humans/hair_short04/short04.obj | CC0 original graphical/source metadata | `676964a133ee35ffcea1195382bf75542da7a298931e4001bc7b0d7b707225de` |
| authored/humans/hair_short04/short04_diffuse.png | CC0 original graphical/source metadata | `0bef7fc0e403db5a40fabb2111ebfa6f7e8158e204c6e56b8da98e9ef527846e` |
| authored/humans/hair_short04/short04_diffuse_periodic_pad_draft.png | CC0 derived periodic-padded texture | `194e53741c7c96e16d4aac8ba10a1bb87c9cb86e976bda82655ad10d38b58871` |

This is a component entry additive to existing canonical-master and human master/web export entries for `bardwell_otis_1835`, `dufresne_joseph_1835` and `flynn_martin_1835`; their rebuilt byte hashes do not exist yet and must be measured after CI, never fabricated. The source component conveys no period hairstyle, resident likeness, ancestry or historically observed action. Fitting tools remain project GPL-3.0-or-later code; those tools are not CC0 graphical assets.


## Original paired equine head/neck and headstrap refinement (T-2800/T-2801/T-2803)

CC0-1.0 original generated geometry and original generator source: `tools/transport/horse_geometry.py`, `tools/transport/generate_horse.py`, `tools/transport/generate_harness.py`; original parameter data `data/transport/studies/horse.json` (unchanged) and `data/transport/studies/harness.json`; derived `renderers/web/transport/horse/{equine_light_harness_skinned_prototype_01.glb,manifest.json}` and `renderers/web/transport/harness/{light_breastcollar_harness_reconstructed_01.glb,manifest.json,geometry-stats.json}`. Exact hashes are recorded in `docs/RESEARCH/period-transport-2026-10-18/head-neck-refinement/integration-inputs.json`. No external model, texture, source pixels or traced plate geometry. Research text informs provisional anatomy/construction but does not attest a horse, owner, breed, exact anatomy or strap dimensions. Original additions retain CC0-1.0 SPDX headers. Demo/integration and reused project fit methodology remain under the project's existing GPL license; CC0 geometry does not relicense those tools. Documentary screenshots/receipts are original diagnostic outputs, not source photographs.


## Grounded trot study (2026-10-19)

Original grounded-trot engineering addition (T-2803): tools/transport/horse_geometry.py, unchanged original tools/transport/generate_horse.py, data/transport/studies/horse.json, generated renderers/web/transport/horse/{equine_light_harness_skinned_prototype_01.glb,manifest.json} contain project-original CC0-1.0 procedural geometry/solver/animation/data; no externally copied program/model/texture or image tracing. Original3Dtwo-bone solver uses geometric sphere intersection and shortest-arc quaternions. renderers/web/transport/horse/{demo.js,index.html} and diagnostic test glue retain project's existing GPL license. No source-bounded measured biological gait or historic animal identity asserted. Concrete checkpoint hashes are in `docs/RESEARCH/period-transport-2026-10-18/head-neck-refinement/trot-inputs.json`.


## Original harness chest-clearance repair (T-2801, 2026-10-19)

The original CC0-1.0 harness generator, parameter data and generated web geometry retain the existing original reconstructed-asset license. Only breastcollar, two support straps and saddle-pad surfaces change; no external model, photograph, texture or traced source plate is copied. Current exact hashes appear in `docs/RESEARCH/period-transport-2026-10-18/harness-body-fit/INTEGRATION-MANIFEST.json`. Diagnostic screenshots are original project outputs, not historical source images.

`tools/transport/fixtures/harness-before-body-fit.json` is unchanged original CC0 parameter data (SHA-256 `7473be06e127388b07cd67af69db671bcc134999fa66849a5866f40c0794d85d`). `tools/transport/fixtures/harness-before-body-fit.glb.gz` is the original CC0 generated geometry, stored SHA-256 `cce8c06f3ff46346c133bdc4954546aa7533febd645bff61e6db5a2a11b5ebf9`, decompressed SHA-256 `b4a7318053e8508617a24fff64f02beb7eee77684db689dc04771d209a54fa8b`. Both are regression controls, not newly licensed third-party assets. The new standard-library diagnostic `tools/transport/test_harness_body_fit.py` remains project GPL-3.0-or-later code.

## C02 enclosed carriage reconstruction (T-2794,2026-10-19)

Original project-derived GPL-3.0-or-later source/geometry, based on the already licensed C01 procedural conventions; C02 is standalone source, not a runtime import or downloaded base. Exact source/input/output hashes are in docs/RESEARCH/period-transport-2026-10-18/c02-enclosed-door/INTEGRATION-MANIFEST.json. New files are tools/transport/generate_carriage_c02.py, tools/transport/test_carriage_c02_door.py, tools/transport/smoke_carriage_c02.cjs, data/transport/studies/carriage-c02.json, tools/transport/fixtures/carriage-c02-flag-off.json and renderers/web/transport/carriage-c02/{carriage-c02.glb,carriage-c02.json,parameters.json,index.html,demo.js}; gallery/orchestrator changes and original documentary receipts/screenshots retain projectGPL terms. No external model/texture/sourcepixels or proprietary program code is included. ExistingThree/vendor remains separately licensed and is not copied. No asset under assets/ is added; this entry records original generated-output provenance, not a CC0 external-asset exception.

All cabin/hardware/color dimensions are reconstructed. Reference catalog wording is 'No known restrictions on publication', not a new unconditional license. No rights-pending local photo or unseenWareplate derivation, attested ownership/subtype or historical paint is asserted. BaselineGLB SHA256 93d4020036e5c685ce95010fe64b26c55a1561db4517405f0590f7a398253331.


**Metadata and articulation qualification:** The pre-door project scope quotation is preserved separately with its original branch and explicit non-period origin; the enabled branch now describes reconstructed rigid door/hinge geometry and endpoint transforms. Current model metadata hash is 93d4020036e5c685ce95010fe64b26c55a1561db4517405f0590f7a398253331 (860956 bytes). Corrected checks bind all 424 actual moving triangles to the unique active exported door and compose actual hierarchy transforms at each angle; closed-world shape alone cannot qualify detached geometry. Old closed-mapping/source-posed receipts are retained only as limited historical checkpoints. No continuous/occupant/photographic acceptance or installed-head gate is implied.


### Supported W01 driver-bench study and named seated authoring (T-2804, 2026-10-19)

`renderers/web/transport/wagon-driver/wagon-w01.glb` and its JSON sidecar are original GPL-3.0-or-later procedural geometry produced by `tools/transport/generate_wagon.py` from `data/transport/studies/wagon-driver-bench.json`. The unoccupied variant is separate from the existing W01 and introduces no external image/model/texture derivation. Bench/hardware dimensions and construction are reconstructed engineering choices; license provenance does not establish period accuracy.

Optional seated resident pose data in `data/humans/poses/w01/` is original reconstructed CC0-1.0 numerical authoring based on the already-cleared CC0 human inputs. Helper, viewer and authoring code remains GPL-3.0-or-later. Existing MakeHuman graphical-base, skin, hair, canonical-master and human-export provenance continues unchanged. Existing L418 records these residents' reconstructed appearance and actions. New seated canonical export hashes and garment/contact/photographic acceptance must be measured after the actual CI export; no new master hash or likeness is invented here.


## Named era authoring studies (1812/1904), unaccepted prototypes

New files under assets/authored/humans/era_studies/{1812,1904} contain CC0-source prepared MakeHuman software bodies and original project-authored conjectural garment arrays/recipes. Body source metadata preserves the existing cleared source hashes and license; exact age target recipes accompany each immutable body. Original garment arrays, canonical composition adapters and engineering derivations are authored for this repository under its applicable original-work license. Garment_sources is empty: no photograph, museum garment, personal outfit, portrait or unknown-rights image was used to derive these garments.

The canonical caller reuses existing cleared skin_toigo_bronze and hair_short04 inputs under their existing unchanged SOURCE.json license evidence and exact file hashes. It does not relicense those assets. The source atlas is labeled young; using it on mature software bodies is an unaccepted engineering color-map choice, not an age-specific or personal complexion claim. Historical OCR citations remain identity/text evidence only and do not confer appearance rights or likeness provenance.

Exact body/garment hashes and derivations are in data/humans/recipes/era_studies/{1812,1904}.json and actual master metadata. No output is photographic, source-matched, period-wardrobe accepted, deformation accepted or scene eligible solely because this source is integrated.


Exact asset registrations for the named era studies (CC0-1.0 software graphical
inputs retain their existing source records; original numerical authoring below
is dedicated to CC0-1.0 alongside those inputs):

| path relative to assets/ | license | provenance |
| --- | --- | --- |
| `authored/humans/era_studies/1812/body-target.json` | CC0-1.0 | Original reconstructed age49/height parameters; existing cleared MakeHuman graphical targets, not application code. |
| `authored/humans/era_studies/1812/body.json` | CC0-1.0 | Prepared existing cleared hm08 graphical body; exact source and target hashes remain in this file. |
| `authored/humans/era_studies/1812/garments.json` | CC0-1.0 | Original project-authored conjectural garment arrays; no external garment or picture derived. |
| `authored/humans/era_studies/1904/body-target.json` | CC0-1.0 | Original reconstructed age61/height parameters; existing cleared MakeHuman graphical targets, not application code. |
| `authored/humans/era_studies/1904/glessner_john_j_1904.prepared.json` | CC0-1.0 | Prepared existing cleared hm08 graphical body; exact source and target hashes remain in this file. |
| `authored/humans/era_studies/1904/glessner_john_j_1904.garments.json` | CC0-1.0 | Original project-authored conjectural garment arrays; no external garment or picture derived. |


## Parked original transport variants (T-2979)

W01 geometry and source: GPL-3.0-or-later; nine original generated timber/paint/iron maps: CC0-1.0. See each SOURCE.json/ORIGINAL-MATERIAL-LICENSE.txt. No external photographic pixels or scans are incorporated.

| path relative to assets/ | license | provenance |
| --- | --- | --- |
| `authored/transport/wagon_parked/ORIGINAL-MATERIAL-LICENSE.txt` | CC0-1.0 | Original project-authored procedural graphical input; reproducible by tools/transport/generate_parked_wagon.py. |
| `authored/transport/wagon_parked/SOURCE.json` | CC0-1.0 | Original project-authored procedural graphical input; reproducible by tools/transport/generate_parked_wagon.py. |
| `authored/transport/wagon_parked/textures/iron_color.png` | CC0-1.0 | Original project-authored procedural graphical input; reproducible by tools/transport/generate_parked_wagon.py. |
| `authored/transport/wagon_parked/textures/iron_normal.png` | CC0-1.0 | Original project-authored procedural graphical input; reproducible by tools/transport/generate_parked_wagon.py. |
| `authored/transport/wagon_parked/textures/iron_orm.png` | CC0-1.0 | Original project-authored procedural graphical input; reproducible by tools/transport/generate_parked_wagon.py. |
| `authored/transport/wagon_parked/textures/paint_color.png` | CC0-1.0 | Original project-authored procedural graphical input; reproducible by tools/transport/generate_parked_wagon.py. |
| `authored/transport/wagon_parked/textures/paint_normal.png` | CC0-1.0 | Original project-authored procedural graphical input; reproducible by tools/transport/generate_parked_wagon.py. |
| `authored/transport/wagon_parked/textures/paint_orm.png` | CC0-1.0 | Original project-authored procedural graphical input; reproducible by tools/transport/generate_parked_wagon.py. |
| `authored/transport/wagon_parked/textures/wood_color.png` | CC0-1.0 | Original project-authored procedural graphical input; reproducible by tools/transport/generate_parked_wagon.py. |
| `authored/transport/wagon_parked/textures/wood_normal.png` | CC0-1.0 | Original project-authored procedural graphical input; reproducible by tools/transport/generate_parked_wagon.py. |
| `authored/transport/wagon_parked/textures/wood_orm.png` | CC0-1.0 | Original project-authored procedural graphical input; reproducible by tools/transport/generate_parked_wagon.py. |

## Original covered-wagon surfaces (T-2980)

| path relative to assets/ | license | provenance |
| --- | --- | --- |
| `authored/transport/wagon_covered/SOURCE.json` | CC0-1.0 original procedural pixels and descriptive data; geometry/source retain GPL-3.0-or-later | Original analytic reconstruction, no external pixels; reproducible by tools/transport/generate_covered_wagons.py; exact source and output hashes in SOURCE.json. |
| `authored/transport/wagon_covered/ORIGINAL-LICENSE.txt` | CC0-1.0 original procedural pixels and descriptive data; geometry/source retain GPL-3.0-or-later | Original analytic reconstruction, no external pixels; reproducible by tools/transport/generate_covered_wagons.py; exact source and output hashes in SOURCE.json. |
| `authored/transport/wagon_covered/textures/canvas_color.png` | CC0-1.0 original procedural pixels and descriptive data; geometry/source retain GPL-3.0-or-later | Original analytic reconstruction, no external pixels; reproducible by tools/transport/generate_covered_wagons.py; exact source and output hashes in SOURCE.json. |
| `authored/transport/wagon_covered/textures/canvas_normal.png` | CC0-1.0 original procedural pixels and descriptive data; geometry/source retain GPL-3.0-or-later | Original analytic reconstruction, no external pixels; reproducible by tools/transport/generate_covered_wagons.py; exact source and output hashes in SOURCE.json. |
| `authored/transport/wagon_covered/textures/canvas_orm.png` | CC0-1.0 original procedural pixels and descriptive data; geometry/source retain GPL-3.0-or-later | Original analytic reconstruction, no external pixels; reproducible by tools/transport/generate_covered_wagons.py; exact source and output hashes in SOURCE.json. |


## Original authored W01 material charts (T-2980)

The existing project-authored geometry supplies these original UV/tangent source inputs. Their GPL license is separate from the CC0 original procedural pixel maps. Exact hardware, ownership, recipe and original authoring hashes are recorded in SOURCE.json and the chart manifest. The ordinary producer validates these authored inputs; the original numerical authoring remains explicit opt-in. No outside geometry or photographic pixels are incorporated.

| path relative to assets/ | license | provenance |
| --- | --- | --- |
| `authored/transport/wagon_parked/charts/original-w01-charts.bin` | GPL-3.0-or-later | Original project-authored ordered UV/tangent data and author-time mapping from the reviewed W01 source; exact provenance in the manifest and SOURCE.json. |
| `authored/transport/wagon_parked/charts/original-w01-charts.json` | GPL-3.0-or-later | Original project-authored ordered UV/tangent data and author-time mapping from the reviewed W01 source; exact provenance in the manifest and SOURCE.json. |
| `authored/transport/wagon_parked/charts/original-w01-charts.mapping.json` | GPL-3.0-or-later | Original project-authored ordered UV/tangent data and author-time mapping from the reviewed W01 source; exact provenance in the manifest and SOURCE.json. |

### Actual Bardwell initial-standing canonical exports — 2026-10-22

Actual run39712579846, head34cf462ed343b8b2b70da70303344fff7e5e083f, artifact12398870779; exact existing CC0-1.0 graphical/component/master-export licenses and notices above continue. This receipt records actual bytes, not likeness, photographic or full-fit acceptance.

|Path under assets/|Bytes|SHA256|
|---|---:|---|
|humans/bardwell_otis_1835.lod0.glb|8633684|8b7d165bedfa5c8f12fd7e9aeb8d51e1cfc3cab816675a7817900f4bd9418198|
|humans/bardwell_otis_1835.lod1.glb|8004644|7935a45d0332020adae619b05fe84c5010a84a260ba04764bea6371ad953f318|
|humans/bardwell_otis_1835.lod2.glb|7459216|555432bfd5ca37c96755d33ed8ff24cc1ff7d77ad50896fa75ec0b61497c00c4|
|humans/bardwell_otis_1835.lod3.glb|7238540|4ec095034edbe19e91a53d34d82f5eb47ed99a0ec620ca2e487e328170872aa4|
|humans/web/bardwell_otis_1835.lod0.glb|4439324|47132fdfe27c1c144039e2db708bca6da6db63c201b37351a7632f1c0f45a953|
|humans/web/bardwell_otis_1835.lod1.glb|1564256|485856360666b48ea0534e645ebda0e678af63be9e66514be78df0621a262454|
|humans/web/bardwell_otis_1835.lod2.glb|617540|b9976874ae6a20a1e884bec62d97c4039312ae2e8ac4bd5cfbffd8148192485a|
|humans/web/bardwell_otis_1835.lod3.glb|308100|c86fff664ac893d0fb5d6877040a0d0a9d388dc9f25acfc208be0eeb13e12ad2|

### Actual Bardwell connected-waistcoat canonical replacement — 2026-10-22

Actual source96c4da4b1fe68e6dec3b18c15da2f14c596a60c5, successful canonical run39736567239 attempt1, artifact12408480668, ZIP SHA2569ca4e1e692da77d3cbb1e0089f2d53cc01cd360d8cafc2b0e97230434326d5f5. These eight exact same-run exports replace the earlier Bardwell initial-standing bytes only. Existing CC0-1.0 graphical/master/base/skin/hair provenance and notices above remain; project build-code licensing is unchanged. Source/web/sole/normal/rigid-frame/container/seated/W01 mechanical qualification is actual. Root reviewed actual publishedLOD0front/profile and accepted the repaired upper panels for the initial visible increment; broad photographic/full-fit/occupied acceptance remains open. Historical export receipts above remain historical.

|Path under assets/|Bytes|SHA256|
|---|---:|---|
|humans/bardwell_otis_1835.lod0.glb|8656876|84cdeb6d362aa1a85549b18daef41ae492f18595a19ff5b7e6eff539a3576d04|
|humans/bardwell_otis_1835.lod1.glb|8018176|e2ff6d6d4df02b3852248c4712b9472c86fe7ca14a60b3db02788deed8db73c3|
|humans/bardwell_otis_1835.lod2.glb|7465876|bc7ab6752b92f5451b285b070d2f76d896edddffa46d976c3569820745b8be7f|
|humans/bardwell_otis_1835.lod3.glb|7241808|8d36ceade3b2dce3b8d081dc484faa98bb57dd2c0d288c1043f0a6da9d3dc233|
|humans/web/bardwell_otis_1835.lod0.glb|4447008|3c75b33e5130fb8fe4813866d52d248bdab4207ab7a10c78b4074cc5fc30e999|
|humans/web/bardwell_otis_1835.lod1.glb|1568968|af2492264df071facce2c4ba128d851a5624f93bcf3f9e507eb406694e3124f1|
|humans/web/bardwell_otis_1835.lod2.glb|619964|ac21fdb00c402f76810a23467e299612042aa3ce21b017e7705ca675793df77a|
|humans/web/bardwell_otis_1835.lod3.glb|309428|b61d09e2efdb204a90d5d3c8fe49d1a6502108fd6ac62a592350129db48f8d40|

## V18 catalogue-guided Brougham lamps (T-2794)

Original project GPL-3.0-or-later source and generated geometry: `tools/transport/brougham/{generate.py,lamp_geometry.py,source_details.py,quarter_surface.py,index_streams.py,static_master.py,parameters.json,lods.json,rear-quarter.json,ring16-mid-lods.json,LICENSE}`. Current V18 near raw SHA256 `99f2ca33f0228d486db274f461c59eecdfa19dcb70d1eb2c080c30d4d5456b4a`, indexed SHA256 `bce1ecc757a7175cb193b1263fc8dbcdf1ce76a263916d3cff5e41dc4a835938` (33,374 triangles). Current mid raw SHA256 `f184d0fc96ecca92ae4ed51a57c468e9cf7e689264865ae45b23ccb007236f0d`, indexed SHA256 `65eec8b7e04e636c90e2d797f5e7e8c1d2695f0f45c6fb5c7f340f73e5616fa1` (11,706 triangles). The existing ring16 distance recipe uses 480 near and 314 mid subdivision records. Protected non-lamp positions/normals, seven materials, nodes, anchors, contacts and original conservative collision proxy remain exact; only the reconstructed lamp form changes. No external geometry or image textures are used.

The public-domain appearance reference is US1893 Studebaker catalogue leaf0095, source `studebaker_1893_illustrated_souvenir`, plate SHA256 `b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe`. No plate pixels are embedded. Maker/design availability is evidenced; this specimen, owner, stop, absolute dimensions, hidden construction and optical materials remain reconstructed. No Pullman/Glessner ownership is claimed. Rounder twin-faced lamp heads replace the earlier tall angular cages; a fixed-camera software projection comparison supports that limited form improvement, not Three PBR, browser, world, photographic or occupied acceptance. New native desktop/mobile image acceptance remains false after environment-limited launches. Eight earlier native views applied only to historical V17 distance appearance and are not transferred to V18. V17 source/contracts/metadata/receipts are retained explicitly as historical under `tools/transport/brougham/archive-v17/`, with its original GLBs in PR1175 Git history. The earlier22,238-triangle mid likewise remains historical. No Brougham file is added under assets/.

## W01 fine-grained timber material increment (T-2793)

`parked-wagon-fine-wood/` uses unchanged original project W01 geometry and project-authored UV/tangent/index charts (GPL-3.0-or-later). Side timber pixels derive from [Fine Grained Wood](https://polyhaven.com/a/fine_grained_wood), Rob Tuytel / Poly Haven, [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/); original paint, iron and cut-end pixels remain CC0. Native2K maps were rotated, cropped, reduced2x, narrow8pxperiodic edge blended, and albedo given bounded1.5linear exposure; GL normal vectors were correspondingly rotated and renormalized. This is a modern optical analogy and reconstructed brown finish, with no species/date/coating/maker/Chicago-specimen attestation. Photographic/world/budget acceptance remains open. Source map URLs, official hashes and derivation are in `assets/authored/transport/wagon_parked_fine_wood/SOURCE.json`.

The authored binding files `assets/authored/transport/wagon_parked_fine_wood/{surface.json,surface.bin}` combine original project GPL-3.0-or-later UV/tangent/index charts with the documented CC0 image derivatives; the geometry is freshly regenerated by `tools/transport/generate_parked_wagon_fine_wood.py` through the unchanged original W01 pipeline. `ATTRIBUTION.txt` and `SOURCE.json` preserve creator, URLs, source hashes and transformations. The installed `renderers/web/transport/parked-wagon-fine-wood/wagon-w01.glb` SHA256 is e1e5b4f1d7dfe6bf08cca21e8cfae2e88748a3f6e6c6959753334ae2b0c84dd8. The original parked-wagon asset remains unchanged. The two covered variants retain distinct finish families and take only the separately documented cloth-drape increment.

| Asset | License | Provenance |
| --- | --- | --- |
| `authored/transport/wagon_parked_fine_wood/ATTRIBUTION.txt` | GPL-3.0-or-later | Original project attribution text identifying the separately licensed CC0 texture maps and their transformations. |
| `authored/transport/wagon_parked_fine_wood/surface.json` | GPL-3.0-or-later (project binding and charts); CC0-1.0 (texture derivatives) | Original project UV/tangent/index binding; Fine Grained Wood maps by Rob Tuytel / Poly Haven and original CC0 paint, iron and cut-end pixels, as documented above and in SOURCE.json. |
| `authored/transport/wagon_parked_fine_wood/surface.bin` | GPL-3.0-or-later (project charts); CC0-1.0 (texture pixels) | Original project chart streams and documented CC0 texture derivatives; no third-party geometry. |

The covered-cloth refinement under T-2980 changes only the reconstructed inter-bow drape constants (8–10mm to20–28mm over750mm spans), retaining original GPL geometry/source lineage and CC0 analytic texture pixels. Current source/product hashes are in `assets/authored/transport/wagon_covered/SOURCE.json`: core679fc439, blue GLB aaffa339, oak GLB22072e6f. Variant identities, seeded finish colors/aging, yokes, pivots, stands and newer terrain qualification are preserved. This is not an attested historic textile form or physical cloth simulation.


## Canonical26 planted-standing horse development derivative (T-2800/T-2803)

“Horse” by sevketkabatas, [CC BY4.0](https://creativecommons.org/licenses/by/4.0/), original https://sketchfab.com/3d-models/horse-53a6eb7ccf054aa2a378dd7ec08f88fe, retrieved via Objaverse on2026-10-22. Exact original source SHA41acd9bee7bf05fbcdd813fad965027b01b8801d6a21ca1c22eb2178c8842988 is unchanged in preserved acquisition/recovery. Current derivative b479442cb03ac46eb13c19da15a79cdfaf28dbdf356b116f78de7ce7ecdc60be is3,783,600bytes. Source rest surface baked to canonical metres; reconstructed26controls/V16skin and12s planted body-shift clip are explicit project adaptations. UV/maps/index topology and source shape retain CC BY4.0; no source six-clip or earlier head/tail playback is composed.

Rigged Mid-Poly Horse by antemeossa, CC BY4.0, https://sketchfab.com/3d-models/rigged-mid-poly-horse-fea999c1d8d64eb4a9c2bb1fac1e7d83 supplied hierarchy analogy only, not copied mesh or animation keys. Objaverse database notice remains ODC-By1.0 (Deitke etal.,2022); individual object rights remain CC BY4.0. Modern source publication/rights do not attest a Chicago individual, breed, owner or period appearance.

|Path relative to assets/|License and provenance|
|---|---|
|`authored/transport/horse_standing/horse-sevket-v16-planted-standing-v1.glb`|CC-BY-4.0 derivative; exact source/field/export lineage in SOURCE.json and ADAPTATION.md.|
|`authored/transport/horse_standing/SOURCE.json`|Project-authored source/change/binary binding; original third-party rights preserved.|
|`authored/transport/horse_standing/ADAPTATION.md`|Project-authored exact reconstruction/normalization/motion scope notice.|
|`authored/transport/horse_standing/ATTRIBUTION.md`|Preserved author/listing/license/acquisition credit and dataset notice.|
|`authored/transport/horse_standing/CC-BY-4.0-legal-text.txt`|Creative Commons legal-text notice preserved verbatim.|
|`authored/transport/horse_standing/dataset-README.md`|Preserved Objaverse ODC-By1.0 database notice; individual CC object license remains separate.|
|`authored/transport/horse_standing/53a6eb7ccf054aa2a378dd7ec08f88fe-public-metadata.json`|Preserved modern author/source/CC-BY-4.0 metadata, not period evidence.|
|`authored/transport/horse_standing/selected-dataset-metadata.json`|Preserved individual object license/creator metadata, not a new license grant.|
|`authored/transport/horse_standing/selected-acquisition.json`|Preserved exact-source acquisition provenance.|
|`authored/transport/horse_standing/planted-standing-export-receipt.json`|Project-authored source-protection/export receipt; export-only scope.|

Byte-identical runtime copy: `renderers/web/transport/standing-horse/horse-sevket-v16-planted-standing-v1.glb`. The renderer's declared organic_dielectric_v1 variant changes only cloned material metalness0, with original PBR maps/roughness/UV policy unchanged. Loaded129 CPU/Mixer PASS is recorded separately; yard/mobile/GPU/photographic/gait/tack/riding acceptance is not implied.

## Verified 1902 jail reference pages — T-3056

| item | licence | cleared for | NOT established |
|---|---|---|---|
| `data/sources/assets/trowbridge_first_jail_gale_1902/` — three unmodified JPEG scans, exact URLs/hashes in its manifest; [Internet Archive](https://archive.org/details/reminiscencesofe00ingale/page/n79/mode/1up) | **Public domain by age: US publication 1902**, verified actual title and copyright pages | Faithful reference copies and model derivation from W. E. S. Trowbridge’s published illustration in Edwin O. Gale’s book; credit retained in the source record and companion README | Exact July 1835 condition, metric dimensions, rights in added 1947 newspaper layout, or an item-specific licence for the separate UCR copy |


## Verified1902 Green Tree and Sauganash reference pages — T-3055

| item | licence | provenance and limits |
|---|---|---|
| `data/sources/assets/trowbridge_green_tree_1902/gale-n55.jpg` and `data/sources/assets/trowbridge_sauganash_hotel/gale-n49.jpg` | Public domain by independently verified 1902 US publication | Unmodified InternetArchive page scans of W. E. S. Trowbridge illustrations in Edwin O. Gale, *Reminiscences of Early Chicago and Vicinity* (Fleming H. Revell Company,1902), facing printed pp. 35 and31. Exact URLs/hashes in adjacent manifests; actual title/copyright proof shared with `trowbridge_first_jail_gale_1902`. Retrospective 1835 caption does not establish July 1835 fitting dates, metrics, colours or modern stock reproduction licences. |


## T-3055 first Tremont reconstructed arch name

The optional baked TREMONT paint strokes are original project GPL-3.0-or-later procedural geometry, adapting six existing prairie_draft.GLYPHS capitals locally through MeshBuilder. No external font, photograph or source-image pixels are baked. The independently known house name bounds the explicit reconstructed word; Gifford/Chicagology remains owner-approved attributed reference use, with no claim of a legible original inscription or public-domain finding. Exact glyph/colour/placement choices and source limits are recorded in L-tremont-reconstructed-arch-name-2385.

## Eye-UV-v1 planted-standing derivative amendment (T-2800)

The historical b479 entry above describes the preserved previous stage. The current separately versioned selection is d4544c2845256858dfa614235bcb37cb964ab63095a53a2436225182cefbb914,3,784,176bytes, `horse-sevket-v16-planted-standing-eye-uv-v1.glb`. Its eye UV10/bounds and derivative notice change; source texture pixels, other UVs, material records, geometry, rig and planted animation are exact b479 data. Reconstructed gaze/pupil is an adaptation under the same sevketkabatas Horse CC BY4.0 source credit and Objaverse database notice, not attested Chicago anatomy or photographic completion. The preceding unchanged-UV statements apply to the historical b479 stage only. Fresh d454 loaded129 CPU qualification is distinct from historical b479 results; neither certifies native/mobile/GPU/world/photographic quality.

|Path relative to assets/|License and provenance|
|---|---|
|`authored/transport/horse_standing/horse-sevket-v16-planted-standing-eye-uv-v1.glb`|CC-BY-4.0 derivative of Horse by sevketkabatas; exact changes in ADAPTATION.md.|
|`authored/transport/horse_standing/generate_eye_uv_v1.py`|Project-authored UV recipe/source-aperture evidence/protection receipt; source mesh/image rights and author credit remain CC-BY-4.0.|
|`authored/transport/horse_standing/eye-uv-v1-source-aperture-rays.json`|Project-authored UV recipe/source-aperture evidence/protection receipt; source mesh/image rights and author credit remain CC-BY-4.0.|
|`authored/transport/horse_standing/eye-uv-v1-boundary-receipt.json`|Project-authored UV recipe/source-aperture evidence/protection receipt; source mesh/image rights and author credit remain CC-BY-4.0.|
|`authored/transport/horse_standing/eye-uv-v1-derivation-receipt.json`|Project-authored UV recipe/source-aperture evidence/protection receipt; source mesh/image rights and author credit remain CC-BY-4.0.|

Byte-identical current runtime copy: `renderers/web/transport/standing-horse/horse-sevket-v16-planted-standing-eye-uv-v1.glb`. Protected b479 authored/runtime files and original receipts remain unchanged.

## V19 catalogue-guided Brougham body and finish (T-3084)

Original GPL-3.0-or-later source and generated geometry: `tools/transport/brougham/{generate.py,body_finish.py,body_geometry.py,build_body.py,parameters.json,quarter_surface.py,source_details.py,index_streams.py,static_master.py,LICENSE}` and `renderers/web/transport/parked-brougham/`. Current near raw SHA256 `fbe0f9b3d60c69ff85678b877a7d5c5e86fea05262d5fe13cfe246687e6b2d45`, indexed SHA256 `80bdf8a64ff2205de6575675f81efce7de0a6d41f45f934e3730f454cc1ab87f` (45,338triangles); mid raw SHA256 `5fa3a2127a805c52d040e17c533105ce43c545bcb3903f1ea717afb52c429694`, indexed SHA256 `6b8134c697c5538a004ca34e0a5a5822377b3e16d856ee098e1422bdf290fb2f` (23,062triangles). Both are deterministic original source exports with lossless indexing, freshly validated by gltf-validator2.0.0-dev.3.10 with0errors/0warnings. No external geometry, source pixels or texture images are embedded.

Appearance reference remains the cleared public-domain1893 Studebaker catalogue Brougham leaf0095, source `studebaker_1893_illustrated_souvenir`, plate SHA256 `b458565ec06ba1e8e59d1455cc2d3f277c2371910b3085c2085749fc59a68abe`. Native model studies are original project renders. Dark green/black colour families and narrow bright lining are visible in the colour plate; metric dimensions, hidden/opposite construction, empty upholstery, wood species, lacquer pigments/optics and physical glass coefficients are reconstructed. Maker/type availability does not identify an actual1904 specimen or household. Original V18 lamp geometry/materials and physical interfaces are preserved. V18 source/contracts/metadata remain under `archive-v18/`; its original GLBs remain in accepted cb93 Git history. Final source-camera/published/phone/world budget and photographic acceptance remain pending; T-3085's later qualification is not claimed here.

### V19 C1 front-slope output amendment (T-3084,2026-10-26)

Current near raw SHA256 `50f56eed76942ed65b232dfa005912e2587184020aca5b058837a8b4d41c3635`, indexed `5bbdb1932074b0bddfa72afc99f34773a0fb337cb02480136deb8fe65ef0cec0`; mid raw `d2e2452b04f63c366a8debac88833d7ca21ef9f6a8031d57c240b600e3740b0a`, indexed `90e258c14ea9201b055e1862066c28077ea4ee48d699b9ca59928a371c13bcc3`. Same original GPL source and public-domain1893 plate, no embedded source pixels. Limited continuous front slopes replace the previous fbe0 candidate; source-bearing values, interval envelope, V18 lamps/physical interfaces remain protected. Fresh four raw/indexed validator reports retain0errors/0warnings. Earlier image evidence is explicitly PRE-C1; current native/photographic/published qualification remains pending.

### Analytical-front-normal-only current output (T-3084,2026-10-26)

Near raw `206cd7a9141896361abd312ce73cd4de0e0868eca532b097a995a0488fa3dfe4`, indexed `3d2f3a802f4b32dba6a3e61f2c188dddce4db05cecfcbba81e1e8d369d5dfe89`; mid raw `560373980cc70524c4f85071fb4e3df6bc29df8a884f3dc17960fabcaa625f9d`, indexed `d5cdd34e981d29db41634ac780c22526742f6a20527b5866d2349c727a67400d`. Original GPL geometry/source and the same cleared1893plate. All priorC1POSITION streams remain exact; only owned front NORMAL changes, with inverse-transpose body scaling and separate thin-rim normals. Current actual close-up is source-bound; older17-image proofs remain historical. No new geometry source, texture image, source pixel, pigment attestation or photographic/published acceptance is introduced.


### Optical-only V19 runtime delivery (T-3084, 2026-10-26)

`renderers/web/transport/parked-brougham/brougham-near-delivery-v1.glb` (SHA256 `b5b183b4f115c5c7779ba0cb4ccba83fbffb62349647a9a6487f50cde49aef77`) and `brougham-mid-delivery-v1.glb` (`16daaf1d5003aae3ea64de9d037962aaabf2a5c8638ac77a5a2e037564ef2d63`) are original GPL-3.0-or-later optical derivatives of the retained indexed V19 masters. Canonical source is `tools/transport/brougham/generate_optical_delivery.mjs`; `OPTICAL-DELIVERY-RECEIPT.json` records its exact producer/source bindings. Every BIN byte, geometry/layout/node/scene value and material0–6 remains exact; 45,338/23,062 triangles and eight batches are retained. Only cabin glass uses the declared reconstructed BLEND/0.14-opacity/zero-transmission/IOR1.5 delivery approximation. All four physical raw/indexed masters remain unchanged, including their separate0.98-transmission optics. No new geometry, pixels, textures or outside material rights are introduced; the same cleared1893 catalogue/source limits apply. Actual source-bound diagnostic images are project renders and retain their NONPASS whole-budget result; a source derivative or Full-only allowance is not photographic/Light/memory acceptance.

## T-3088 source-bounded horse anatomy authoring

The anatomy recipes derive from the preserved selected d454 standing horse above,
under the same sevketkabatas **CC-BY-4.0** credit, source URL and change-notice
requirements. Existing source images, repaired eye UVs, acquired original,
b479 and d454 parent files remain preserved. The project-authored recipe code
and bounds are **GPL-3.0-or-later**; no claim is made that a software licence
replaces the model's attribution licence.

|Path relative to assets/|Licence and provenance|
|---|---|
|`authored/transport/horse_standing/generate_anatomy_v1.py`|Project-authored GPL-3.0-or-later source-only smooth rest-surface recipe; parent mesh rights remain CC-BY-4.0.|
|`authored/transport/horse_standing/anatomy-v1-recipe.json`|Project-authored reconstructed source bounds and exact reference-image bindings; no reference pixels copied into the model.|
|`authored/transport/horse_standing/generate_anatomy_v2.py`|Project-authored GPL-3.0-or-later canonical authored-mesh derivation with immutable-parent and live-field lineage.|
|`authored/transport/horse_standing/anatomy_topology_v2.py`|Project-authored GPL-3.0-or-later adaptive hoof-wall/coronet/toe subdivision and bounded fairing; generated geometry remains an attributed CC-BY-4.0 model derivative.|
|`authored/transport/horse_standing/anatomy-v2-recipe.json`|Project-authored reconstructed anatomy/topology choices, per-feature source IDs, confidence and immutable reference hashes.|
|`authored/transport/horse_standing/ANATOMY.md`|Project-authored source, reconstruction, authoring and acceptance boundary notice; original model attribution remains separate.|
|`authored/transport/horse_standing/horse-sevket-anatomy-v2.glb`|CC-BY-4.0 derivative of sevketkabatas' Horse; reconstructed eyelid and hoof topology changes declared in ANATOMY.md and the versioned recipe. Repaired eye UVs and original six image payloads retain the source rights and credit.|

The anatomy runtime copy is byte-identical at
`renderers/web/transport/standing-horse/horse-sevket-anatomy-v2.glb`.
The original acquired model and b479/d454 authored parents and their old receipts
remain unchanged. Fresh selected-body Mixer129 physical proof is separate from
surface, LOD, world, device performance and photographic qualification.

The input plates by Ellenberger/Baum/Dittrich and Seton are recorded public-domain
anatomical works. The Vassil and Joselodos living-animal photographs are cleared
CC0 references. These supply anatomical relationships and visible continuity;
neither the modern animals' breeds/markings nor their dimensions become evidence
for an 1835 Chicago animal. Their pixels are not sampled into output textures.
The unchanged six model texture payloads retain the source model's CC-BY-4.0
provenance. Source recipes and uninstalled candidate generation do not constitute
native, physical, historical or photographic acceptance.


### T-1789 modular workwear source construction (canonical outputs pending)

`tools/human_period_wardrobe.py` is original project GPL-3.0-or-later code; the original graphical arrays generated by its garment returns, fitted buttons, short jacket/lapel and felt-hat constructors are dedicated CC0-1.0, as declared in `data/humans/recipes/worker_1835.json`. They use existing cleared CC0 MakeHuman body/hair components without copying upstream program logic. No new outside image/texture or rights-pending source is derived into an asset. Colors, materials and garment dimensions are original reconstructions. The currently committed human GLBs remain the prior outputs with their existing provenance; this source checkpoint does not relabel them as the new wardrobe. Canonical new masters/exports and their hashes/licenses must accompany their eventual integration.


### T-1789 original adult dress components and verified female source base

`assets/authored/humans/makehuman_hm08/prepared_adult_female_25.json`, its report and `adult_female_25.recipe.json` are original CC0-1.0 engineering derivatives of the same pinned MakeHuman graphical data. The three female-young category targets and header-only universal-female target preserve their upstream CC0 notices; exact upstream commit, source URLs, bytes and SHA256 are in `SOURCE-female.json`. The universal target has zero delta rows and is not claimed as a deformation. Upstream category labels are software provenance, not an inference of a resident ancestry. Existing MakeHuman graphical/license notices remain unchanged.

Generated bodice, skirt, apron and low-shoe arrays from `tools/human_dress_components.py` are original CC0-1.0 geometry. Generator/test code is GPL-3.0-or-later. Cuts, cloth dimensions, color and drape are reconstructed, not traced from a historical pattern or painting. The held credited public-domain Wild1835 Cincinnati image is a narrow cross-check via source wild_1835_third_vine; no image pixel enters any texture or asset. Generic cleared skin/hair components retain their existing source notices and remain unqualified for photographic female appearance.

| Path relative to assets/ | Licence and provenance |
|---|---|
| `authored/humans/makehuman_hm08/SOURCE-female.json` | Project-authored CC0-1.0 graphical-source provenance, exact official upstream hashes and notices. |
| `authored/humans/makehuman_hm08/adult_female_25.recipe.json` | Original CC0-1.0 graphical blend recipe; reconstructed engineering parameters, no resident ancestry or portrait. |
| `authored/humans/makehuman_hm08/prepared_adult_female_25.json` | CC0-1.0 engineering derivative of verified MakeHuman graphical data; complete anatomy/UV/rig retained. |
| `authored/humans/makehuman_hm08/prepared_adult_female_25.report.json` | Project-authored CC0-1.0 preparation measurements and explicit unqualified limitations. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/african-female-young.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-female.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/asian-female-young.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-female.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/caucasian-female-young.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-female.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/universal-female-young-averagemuscle-averageweight.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-female.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/african-female-old.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-variation.json (T-3423 female build axes). |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/asian-female-old.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-variation.json (T-3423 female build axes). |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/caucasian-female-old.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-variation.json (T-3423 female build axes). |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/universal-female-young-averagemuscle-maxweight.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-variation.json (T-3423 female build axes). |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/universal-female-young-averagemuscle-minweight.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-variation.json (T-3423 female build axes). |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/universal-female-young-maxmuscle-averageweight.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-variation.json (T-3423 female build axes). |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/universal-female-young-minmuscle-averageweight.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-variation.json (T-3423 female build axes). |
| `humans/flynn_mary_1835_dress_study.lod0.glb` | Original CC0-1.0 export of the canonical builder over the female base and the dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/flynn_mary_1835_dress_study.lod0.glb` | Original CC0-1.0 export of the canonical builder over the female base and the dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/flynn_mary_1835_dress_study.lod1.glb` | Original CC0-1.0 export of the canonical builder over the female base and the dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/flynn_mary_1835_dress_study.lod1.glb` | Original CC0-1.0 export of the canonical builder over the female base and the dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/flynn_mary_1835_dress_study.lod2.glb` | Original CC0-1.0 export of the canonical builder over the female base and the dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/flynn_mary_1835_dress_study.lod2.glb` | Original CC0-1.0 export of the canonical builder over the female base and the dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/flynn_mary_1835_dress_study.lod3.glb` | Original CC0-1.0 export of the canonical builder over the female base and the dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/flynn_mary_1835_dress_study.lod3.glb` | Original CC0-1.0 export of the canonical builder over the female base and the dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/williamson_mattie_1904_cook_study.lod0.glb` | Original CC0-1.0 export of the canonical builder over the female base and the 1904 dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/williamson_mattie_1904_cook_study.lod0.glb` | Original CC0-1.0 export of the canonical builder over the female base and the 1904 dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/williamson_mattie_1904_cook_study.lod1.glb` | Original CC0-1.0 export of the canonical builder over the female base and the 1904 dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/williamson_mattie_1904_cook_study.lod1.glb` | Original CC0-1.0 export of the canonical builder over the female base and the 1904 dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/williamson_mattie_1904_cook_study.lod2.glb` | Original CC0-1.0 export of the canonical builder over the female base and the 1904 dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/williamson_mattie_1904_cook_study.lod2.glb` | Original CC0-1.0 export of the canonical builder over the female base and the 1904 dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/williamson_mattie_1904_cook_study.lod3.glb` | Original CC0-1.0 export of the canonical builder over the female base and the 1904 dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/williamson_mattie_1904_cook_study.lod3.glb` | Original CC0-1.0 export of the canonical builder over the female base and the 1904 dress components above (T-3423); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/glessner_john_j_1904.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 gentleman's components (`tools/human_gentleman_1904.py`, T-3441); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/glessner_john_j_1904.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 gentleman's components (`tools/human_gentleman_1904.py`, T-3441); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/glessner_john_j_1904.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 gentleman's components (`tools/human_gentleman_1904.py`, T-3441); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/glessner_john_j_1904.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 gentleman's components (`tools/human_gentleman_1904.py`, T-3441); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/glessner_john_j_1904.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 gentleman's components (`tools/human_gentleman_1904.py`, T-3441); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/glessner_john_j_1904.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 gentleman's components (`tools/human_gentleman_1904.py`, T-3441); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/glessner_john_j_1904.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 gentleman's components (`tools/human_gentleman_1904.py`, T-3441); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/glessner_john_j_1904.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 gentleman's components (`tools/human_gentleman_1904.py`, T-3441); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/glessner_frances_m_1904.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 lady's components (`tools/human_lady_1904.py`, T-3447); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/glessner_frances_m_1904.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 lady's components (`tools/human_lady_1904.py`, T-3447); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/glessner_frances_m_1904.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 lady's components (`tools/human_lady_1904.py`, T-3447); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/glessner_frances_m_1904.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 lady's components (`tools/human_lady_1904.py`, T-3447); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/glessner_frances_m_1904.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 lady's components (`tools/human_lady_1904.py`, T-3447); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/glessner_frances_m_1904.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 lady's components (`tools/human_lady_1904.py`, T-3447); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/glessner_frances_m_1904.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 lady's components (`tools/human_lady_1904.py`, T-3447); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/glessner_frances_m_1904.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 lady's components (`tools/human_lady_1904.py`, T-3447); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/reynolds_mary_1904_maid.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 house maid's components (`tools/human_maid_1904.py`, T-3448); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/reynolds_mary_1904_maid.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 house maid's components (`tools/human_maid_1904.py`, T-3448); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/reynolds_mary_1904_maid.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 house maid's components (`tools/human_maid_1904.py`, T-3448); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/reynolds_mary_1904_maid.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 house maid's components (`tools/human_maid_1904.py`, T-3448); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/reynolds_mary_1904_maid.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 house maid's components (`tools/human_maid_1904.py`, T-3448); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/reynolds_mary_1904_maid.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 house maid's components (`tools/human_maid_1904.py`, T-3448); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/reynolds_mary_1904_maid.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 house maid's components (`tools/human_maid_1904.py`, T-3448); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/reynolds_mary_1904_maid.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 house maid's components (`tools/human_maid_1904.py`, T-3448); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/ryan_kate_1904_cook.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 cook's working dress (`tools/human_cook_1904.py`, T-3479); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/ryan_kate_1904_cook.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 cook's working dress (`tools/human_cook_1904.py`, T-3479); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/ryan_kate_1904_cook.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 cook's working dress (`tools/human_cook_1904.py`, T-3479); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/ryan_kate_1904_cook.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 cook's working dress (`tools/human_cook_1904.py`, T-3479); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/ryan_kate_1904_cook.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 cook's working dress (`tools/human_cook_1904.py`, T-3479); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/ryan_kate_1904_cook.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 cook's working dress (`tools/human_cook_1904.py`, T-3479); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/ryan_kate_1904_cook.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 cook's working dress (`tools/human_cook_1904.py`, T-3479); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/ryan_kate_1904_cook.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 cook's working dress (`tools/human_cook_1904.py`, T-3479); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/nelson_christine_1904_errand.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 parlor maid's street dress and market basket (`tools/human_errand_1904.py`, T-3481); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/nelson_christine_1904_errand.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 parlor maid's street dress and market basket (`tools/human_errand_1904.py`, T-3481); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/nelson_christine_1904_errand.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 parlor maid's street dress and market basket (`tools/human_errand_1904.py`, T-3481); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/nelson_christine_1904_errand.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 parlor maid's street dress and market basket (`tools/human_errand_1904.py`, T-3481); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/nelson_christine_1904_errand.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 parlor maid's street dress and market basket (`tools/human_errand_1904.py`, T-3481); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/nelson_christine_1904_errand.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 parlor maid's street dress and market basket (`tools/human_errand_1904.py`, T-3481); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/nelson_christine_1904_errand.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 parlor maid's street dress and market basket (`tools/human_errand_1904.py`, T-3481); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/nelson_christine_1904_errand.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1904 parlor maid's street dress and market basket (`tools/human_errand_1904.py`, T-3481); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/peck_philip_1835.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 merchant's components (`tools/human_merchant_1835.py`, T-3449); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/peck_philip_1835.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 merchant's components (`tools/human_merchant_1835.py`, T-3449); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/peck_philip_1835.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 merchant's components (`tools/human_merchant_1835.py`, T-3449); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/peck_philip_1835.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 merchant's components (`tools/human_merchant_1835.py`, T-3449); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/peck_philip_1835.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 merchant's components (`tools/human_merchant_1835.py`, T-3449); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/peck_philip_1835.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 merchant's components (`tools/human_merchant_1835.py`, T-3449); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/peck_philip_1835.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 merchant's components (`tools/human_merchant_1835.py`, T-3449); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/peck_philip_1835.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 merchant's components (`tools/human_merchant_1835.py`, T-3449); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/mahoney_patrick_1835.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 labourer's components (`tools/human_labourer_1835.py`, T-3450); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/mahoney_patrick_1835.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 labourer's components (`tools/human_labourer_1835.py`, T-3450); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/mahoney_patrick_1835.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 labourer's components (`tools/human_labourer_1835.py`, T-3450); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/mahoney_patrick_1835.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 labourer's components (`tools/human_labourer_1835.py`, T-3450); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/mahoney_patrick_1835.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 labourer's components (`tools/human_labourer_1835.py`, T-3450); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/mahoney_patrick_1835.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 labourer's components (`tools/human_labourer_1835.py`, T-3450); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/mahoney_patrick_1835.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 labourer's components (`tools/human_labourer_1835.py`, T-3450); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/mahoney_patrick_1835.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1835 labourer's components (`tools/human_labourer_1835.py`, T-3450); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/private_first_infantry_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 soldier's components (`tools/human_soldier_1812.py`, T-3451); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/private_first_infantry_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 soldier's components (`tools/human_soldier_1812.py`, T-3451); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/private_first_infantry_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 soldier's components (`tools/human_soldier_1812.py`, T-3451); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/private_first_infantry_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 soldier's components (`tools/human_soldier_1812.py`, T-3451); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/private_first_infantry_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 soldier's components (`tools/human_soldier_1812.py`, T-3451); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/private_first_infantry_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 soldier's components (`tools/human_soldier_1812.py`, T-3451); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/private_first_infantry_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 soldier's components (`tools/human_soldier_1812.py`, T-3451); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/private_first_infantry_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 soldier's components (`tools/human_soldier_1812.py`, T-3451); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/lady_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 lady's day dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/lady_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 lady's day dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/lady_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 lady's day dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/lady_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 lady's day dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/lady_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 lady's day dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/lady_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 lady's day dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/lady_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 lady's day dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/lady_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 lady's day dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/woman_working_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 working woman's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/woman_working_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 working woman's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/woman_working_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 working woman's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/woman_working_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 working woman's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/woman_working_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 working woman's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/woman_working_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 working woman's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/woman_working_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 working woman's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/woman_working_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 working woman's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/woman_country_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 woman of the country's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/woman_country_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 woman of the country's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/woman_country_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 woman of the country's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/woman_country_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 woman of the country's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/woman_country_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 woman of the country's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/woman_country_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 woman of the country's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/woman_country_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 woman of the country's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/woman_country_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the 1812 woman of the country's dress (`tools/human_women_1812.py`, T-3464); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/potawatomi_woman_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the everyday dress of a Potawatomi woman of the 1812 camp (`tools/human_women_1812.py`, T-3464; review required, touches removal); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/potawatomi_woman_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the everyday dress of a Potawatomi woman of the 1812 camp (`tools/human_women_1812.py`, T-3464; review required, touches removal); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/potawatomi_woman_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the everyday dress of a Potawatomi woman of the 1812 camp (`tools/human_women_1812.py`, T-3464; review required, touches removal); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/potawatomi_woman_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the everyday dress of a Potawatomi woman of the 1812 camp (`tools/human_women_1812.py`, T-3464; review required, touches removal); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/potawatomi_woman_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the everyday dress of a Potawatomi woman of the 1812 camp (`tools/human_women_1812.py`, T-3464; review required, touches removal); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/potawatomi_woman_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the everyday dress of a Potawatomi woman of the 1812 camp (`tools/human_women_1812.py`, T-3464; review required, touches removal); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/potawatomi_woman_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the everyday dress of a Potawatomi woman of the 1812 camp (`tools/human_women_1812.py`, T-3464; review required, touches removal); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/potawatomi_woman_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared female base and the everyday dress of a Potawatomi woman of the 1812 camp (`tools/human_women_1812.py`, T-3464; review required, touches removal); the shared cleared short04 hair cap and bronze female skin atlas; reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/engage_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 engagé's components (`tools/human_engage_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/engage_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 engagé's components (`tools/human_engage_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/potawatomi_man_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 Potawatomi man's components (`tools/human_potawatomi_man_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness of any person; held for review under the AGENTS.md standing constraint. |
| `humans/web/potawatomi_man_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 Potawatomi man's components (`tools/human_potawatomi_man_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness of any person; held for review under the AGENTS.md standing constraint. |
| `humans/engage_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 engagé's components (`tools/human_engage_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/engage_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 engagé's components (`tools/human_engage_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/engage_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 engagé's components (`tools/human_engage_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/engage_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 engagé's components (`tools/human_engage_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/engage_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 engagé's components (`tools/human_engage_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/engage_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 engagé's components (`tools/human_engage_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/potawatomi_man_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 Potawatomi man's components (`tools/human_potawatomi_man_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/potawatomi_man_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 Potawatomi man's components (`tools/human_potawatomi_man_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/potawatomi_man_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 Potawatomi man's components (`tools/human_potawatomi_man_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/potawatomi_man_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 Potawatomi man's components (`tools/human_potawatomi_man_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/potawatomi_man_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 Potawatomi man's components (`tools/human_potawatomi_man_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/potawatomi_man_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 Potawatomi man's components (`tools/human_potawatomi_man_1812.py`); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/officer_first_infantry_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a captain, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/officer_first_infantry_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a captain, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/officer_first_infantry_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a captain, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/officer_first_infantry_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a captain, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/officer_first_infantry_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a captain, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/officer_first_infantry_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a captain, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/officer_first_infantry_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a captain, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/officer_first_infantry_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a captain, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/officer_first_infantry_1812_lieutenant.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a lieutenant, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/officer_first_infantry_1812_lieutenant.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a lieutenant, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/officer_first_infantry_1812_lieutenant.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a lieutenant, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/officer_first_infantry_1812_lieutenant.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a lieutenant, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/officer_first_infantry_1812_lieutenant.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a lieutenant, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/officer_first_infantry_1812_lieutenant.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a lieutenant, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/officer_first_infantry_1812_lieutenant.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a lieutenant, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/officer_first_infantry_1812_lieutenant.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a lieutenant, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/surgeons_mate_first_infantry_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a surgeon's mate, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/surgeons_mate_first_infantry_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a surgeon's mate, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/surgeons_mate_first_infantry_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a surgeon's mate, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/surgeons_mate_first_infantry_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a surgeon's mate, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/surgeons_mate_first_infantry_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a surgeon's mate, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/surgeons_mate_first_infantry_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a surgeon's mate, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/surgeons_mate_first_infantry_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a surgeon's mate, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/surgeons_mate_first_infantry_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 First Infantry officer's components (`tools/human_officer_1812.py`, a surgeon's mate, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/trader_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 trader's components (`tools/human_trader_1812.py`, a trader, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/trader_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 trader's components (`tools/human_trader_1812.py`, a trader, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/trader_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 trader's components (`tools/human_trader_1812.py`, a trader, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/trader_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 trader's components (`tools/human_trader_1812.py`, a trader, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/trader_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 trader's components (`tools/human_trader_1812.py`, a trader, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/trader_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 trader's components (`tools/human_trader_1812.py`, a trader, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/trader_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 trader's components (`tools/human_trader_1812.py`, a trader, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/trader_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 trader's components (`tools/human_trader_1812.py`, a trader, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/settler_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 settler's components (`tools/human_settler_1812.py`, a settler, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/settler_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 settler's components (`tools/human_settler_1812.py`, a settler, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/settler_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 settler's components (`tools/human_settler_1812.py`, a settler, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/settler_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 settler's components (`tools/human_settler_1812.py`, a settler, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/settler_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 settler's components (`tools/human_settler_1812.py`, a settler, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/settler_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 settler's components (`tools/human_settler_1812.py`, a settler, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/settler_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 settler's components (`tools/human_settler_1812.py`, a settler, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/settler_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1812 settler's components (`tools/human_settler_1812.py`, a settler, 1812 dress build); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/nelson_charles_1904_coachman.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 coachman's standing livery (`tools/human_coachman_1904.py`, T-3483); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. Near coat material derivative: original CC0-1.0 periodic wool color/ORM/tangent-normal maps and exact Mikk corner splits from SHA-bound current GLB parents, generated by `tools/human_charles_coat.py`; all original expanded triangle attributes, rig, clips, noncoat data and far files protected. Reconstructed surface choice under L-charles-near-wool-1789; not a captured textile or photographic/fit acceptance. |
| `humans/web/nelson_charles_1904_coachman.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 coachman's standing livery (`tools/human_coachman_1904.py`, T-3483); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. Near coat material derivative: original CC0-1.0 periodic wool color/ORM/tangent-normal maps and exact Mikk corner splits from SHA-bound current GLB parents, generated by `tools/human_charles_coat.py`; all original expanded triangle attributes, rig, clips, noncoat data and far files protected. Reconstructed surface choice under L-charles-near-wool-1789; not a captured textile or photographic/fit acceptance. |
| `humans/nelson_charles_1904_coachman.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 coachman's standing livery (`tools/human_coachman_1904.py`, T-3483); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. Near coat material derivative: original CC0-1.0 periodic wool color/ORM/tangent-normal maps and exact Mikk corner splits from SHA-bound current GLB parents, generated by `tools/human_charles_coat.py`; all original expanded triangle attributes, rig, clips, noncoat data and far files protected. Reconstructed surface choice under L-charles-near-wool-1789; not a captured textile or photographic/fit acceptance. |
| `humans/web/nelson_charles_1904_coachman.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 coachman's standing livery (`tools/human_coachman_1904.py`, T-3483); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. Near coat material derivative: original CC0-1.0 periodic wool color/ORM/tangent-normal maps and exact Mikk corner splits from SHA-bound current GLB parents, generated by `tools/human_charles_coat.py`; all original expanded triangle attributes, rig, clips, noncoat data and far files protected. Reconstructed surface choice under L-charles-near-wool-1789; not a captured textile or photographic/fit acceptance. |
| `humans/nelson_charles_1904_coachman.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 coachman's standing livery (`tools/human_coachman_1904.py`, T-3483); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/nelson_charles_1904_coachman.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 coachman's standing livery (`tools/human_coachman_1904.py`, T-3483); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/nelson_charles_1904_coachman.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 coachman's standing livery (`tools/human_coachman_1904.py`, T-3483); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/nelson_charles_1904_coachman.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 coachman's standing livery (`tools/human_coachman_1904.py`, T-3483); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/billings_august_1904_stable_helper.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 stable helper's working dress (`tools/human_stable_helper_1904.py`, T-3484); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/billings_august_1904_stable_helper.lod0.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 stable helper's working dress (`tools/human_stable_helper_1904.py`, T-3484); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/billings_august_1904_stable_helper.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 stable helper's working dress (`tools/human_stable_helper_1904.py`, T-3484); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/billings_august_1904_stable_helper.lod1.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 stable helper's working dress (`tools/human_stable_helper_1904.py`, T-3484); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/billings_august_1904_stable_helper.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 stable helper's working dress (`tools/human_stable_helper_1904.py`, T-3484); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/billings_august_1904_stable_helper.lod2.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 stable helper's working dress (`tools/human_stable_helper_1904.py`, T-3484); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/billings_august_1904_stable_helper.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 stable helper's working dress (`tools/human_stable_helper_1904.py`, T-3484); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/billings_august_1904_stable_helper.lod3.glb` | Original CC0-1.0 export of the canonical builder over the shared male base and the 1904 stable helper's working dress (`tools/human_stable_helper_1904.py`, T-3484); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |


## Licensed Old Cart farm-box development master — T-2793

| Path | License and attribution | Scope |
|---|---|---|
| `authored/transport/farm_box_master_v1/old-cart-original.glb` | **CC BY4.0**, “Old Cart” by Lyskilde (longtail), https://sketchfab.com/longtail; https://sketchfab.com/3d-models/old-cart-f536745fd82144eeb5cc4900a48e816e; https://creativecommons.org/licenses/by/4.0/ | Exact unchanged9,809,548B original, SHA25613600b73c1777545e1454d452c58d141469f031b2c5e6c29b1c6fdefe9145046. Individual author/model/Objaverse credit retained in ORIGINAL-CREDIT.json. Modern artistic source; no maker, historical date, Chicago presence or original metric calibration. |
| `authored/transport/farm_box_master_v1/{ORIGINAL-CREDIT.json,ATTRIBUTION.md}` | Saved individual source rights metadata and project attribution/change notice | Credits accompany the artist-authored geometry, UVs and maps; producer-code SPDX does not replace these rights. |
| `renderers/web/transport/farm-box-master/` licensed wagon derivatives | **CC BY4.0** adaptation of Lyskilde/longtail's Old Cart, exact original author/source/license extras retained | Explicit Chicago changes: metre/axis calibration, independently circular front/rear wheels, neutralised source front-steer pose, reconstructed single pole and central bearing, articulated frames and proposed unloaded interfaces. No source texture pixels are repainted in the near master. Compression/LOD changes are disclosed in their actual export receipts. |

The Python/JS producer and preview code are original project GPL-3.0-or-later. The credited source geometry/maps and their derivatives retain CC BY4.0; neither a code header nor the project author's source changes erase the original credit. See L-farm-box-licensed-master-2793.

Exact authored paths for the same credited CC BY4.0 adaptation above:

| Path relative to assets/ | License and provenance |
|---|---|
| `authored/transport/farm_box_master_v1/ORIGINAL-CREDIT.json` | Unmodified individual source attribution/rights metadata; original Old Cart author and CC BY4.0 license retained. |
| `authored/transport/farm_box_master_v1/ATTRIBUTION.md` | Project adaptation notice retaining Old Cart by Lyskilde/longtail, CC BY4.0. |
| `authored/transport/farm_box_master_v1/SOURCE.json` | Project provenance/derivation inventory; licensed underlying geometry/maps remain CC BY4.0. |
| `authored/transport/farm_box_master_v1/derived/farm-box-source.glb` | CC BY4.0 derivative of Old Cart by Lyskilde/longtail. Original image bytes retained in this authored master; web derivatives use separately measured WebP representations. |
| `authored/transport/farm_box_master_v1/derived/farm-box-source.json` | Engine-neutral reconstruction/attribution/ownership sidecar accompanying that CC BY4.0 geometry. |

The optional muted warm finish multiplies existing source material colors; it
adds no texture maps and identifies no historic paint, timber species or finish.
It is an explicit reconstructed display alternative. The default weathered
finish retains source material factors. Source geometry/UVs/maps remain CC BY4.0;
producer/checker code is GPL-3.0-or-later project work. This amendment preserves
the earlier exact-pixel statements for the authored master: production WebP
images intentionally have bounded, recorded codec loss rather than byte identity.

Exact reconstructed-fit limitation: the retained artist kingbolt axis is 4.994mm eccentric from the tyre-centre yaw frame (XZ+1.925/+4.609mm), moving0.697mm over an8degree turn. No exact coaxial/strength claim. Original rims retain at most2.617mm radial ground irregularity; this is not a perfect-circle/suspension simulation.

The final farm-box master also includes an actual central90x55mm coupling reach, reconstructed from the same licensed shaft surface/UVs and separately owned in vehicle_reach. Its end connections are geometry-checked against the fixed front bolster and rear axle. The actual original28-triangle kingbolt is separately owned in vehicle_kingbolt; this is a component split, not an empty proxy or a hidden change to source surfaces. Both remain CC BY4.0 derivatives with the same author credit; fit/strength/historic-design limits remain reconstruction.



### T-3465 child bodies and the 1812 children's dress

`assets/authored/humans/makehuman_hm08/prepared_child_male_8.json`, `prepared_child_female_8.json`, `prepared_child_3.json`, their reports and the three `child_*.recipe.json` are original CC0-1.0 engineering derivatives of the same pinned MakeHuman graphical data (T-3465). The twelve child and baby macro targets preserve their upstream CC0 notices; exact upstream commit, source URLs, bytes and SHA256 are in `SOURCE-child.json`, which repeats every `SOURCE.json` row unchanged. Category names are software provenance, not ancestry.

| Path relative to assets/ | Licence and provenance |
|---|---|
| `authored/humans/makehuman_hm08/SOURCE-child.json` | Project-authored CC0-1.0 graphical-source provenance, exact official upstream hashes and notices (T-3465). |
| `authored/humans/makehuman_hm08/child_male_8.recipe.json` | Original CC0-1.0 graphical blend recipe; reconstructed engineering parameters, no resident ancestry or portrait. |
| `authored/humans/makehuman_hm08/child_female_8.recipe.json` | Original CC0-1.0 graphical blend recipe; reconstructed engineering parameters, no resident ancestry or portrait. |
| `authored/humans/makehuman_hm08/child_3.recipe.json` | Original CC0-1.0 graphical blend recipe; reconstructed engineering parameters, no resident ancestry or portrait. |
| `authored/humans/makehuman_hm08/prepared_child_male_8.json` | CC0-1.0 engineering derivative of verified MakeHuman graphical data; complete anatomy/UV/rig retained. |
| `authored/humans/makehuman_hm08/prepared_child_male_8.report.json` | Project-authored CC0-1.0 preparation measurements and explicit unqualified limitations. |
| `authored/humans/makehuman_hm08/prepared_child_female_8.json` | CC0-1.0 engineering derivative of verified MakeHuman graphical data; complete anatomy/UV/rig retained. |
| `authored/humans/makehuman_hm08/prepared_child_female_8.report.json` | Project-authored CC0-1.0 preparation measurements and explicit unqualified limitations. |
| `authored/humans/makehuman_hm08/prepared_child_3.json` | CC0-1.0 engineering derivative of verified MakeHuman graphical data; complete anatomy/UV/rig retained. |
| `authored/humans/makehuman_hm08/prepared_child_3.report.json` | Project-authored CC0-1.0 preparation measurements and explicit unqualified limitations. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/caucasian-male-child.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/caucasian-male-baby.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/caucasian-female-child.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/caucasian-female-baby.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/asian-male-child.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/asian-male-baby.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/asian-female-child.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/asian-female-baby.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/african-male-child.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/african-male-baby.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/african-female-child.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/african-female-baby.target` | Verbatim MakeHuman graphical asset, CC0-1.0 explicit upstream header; original credit retained, pinned commit/URL/hash in SOURCE-child.json. |
| `humans/child_boy_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_boy_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/child_boy_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_boy_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/child_boy_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_boy_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/child_boy_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_boy_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/child_girl_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_girl_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/child_girl_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_girl_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/child_girl_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_girl_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/child_girl_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_girl_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/child_toddler_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the 3-year child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_toddler_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the 3-year child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/child_toddler_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the 3-year child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_toddler_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the 3-year child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/child_toddler_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the 3-year child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_toddler_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the 3-year child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/child_toddler_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the 3-year child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/web/child_toddler_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the 3-year child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness. |
| `humans/potawatomi_boy_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/web/potawatomi_boy_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/potawatomi_boy_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/web/potawatomi_boy_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/potawatomi_boy_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/web/potawatomi_boy_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/potawatomi_boy_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/web/potawatomi_boy_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the 8-year male child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/potawatomi_girl_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/web/potawatomi_girl_1812.lod0.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/potawatomi_girl_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/web/potawatomi_girl_1812.lod1.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/potawatomi_girl_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/web/potawatomi_girl_1812.lod2.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/potawatomi_girl_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |
| `humans/web/potawatomi_girl_1812.lod3.glb` | Original CC0-1.0 export of the canonical builder over the 8-year female child base and the 1812 children's components (`tools/human_child_1812.py`, T-3465); reconstructed under L418 and L-human-modular-dress-1789, not a likeness; review required, touches removal (AGENTS.md standing constraint). |

### Log-jail keeper house generated pair — T-2380

| path | origin | license | notes |
|---|---|---|---|
| `gltf/log_jail_keeper_house__frame_1835.glb` | Native Blender4.5.3 generation from `data/structures/log_jail_keeper_house.json`, optional `frame_dwelling` keeper layout | project license | Source-informed form from W.E.S.Trowbridge's illustration in Edwin O.Gale, *Reminiscences of Early Chicago and Vicinity* (Fleming H.Revell,1902), plate facingp53, source `trowbridge_first_jail_gale_1902`; independently public domain by1902USpublication. Flat/procedural materials, no source-image texture. Metric dimensions, finish and July1835continuity remain reconstructed. Actual source/MASTER registration is required, not supplied by this prose. |
| `web/log_jail_keeper_house__frame_1835.glb` | Native pinned web derivative of the master above | project license | Same provenance. The retained pair is byte-exact actual native output; current family qualification and entrywise registry integration remain required before release. |

## T-3088 source-bounded horse anatomy authoring

The anatomy recipes derive from the preserved selected d454 standing horse above,
under the same sevketkabatas **CC-BY-4.0** credit, source URL and change-notice
requirements. Existing source images, repaired eye UVs, acquired original,
b479 and d454 parent files remain preserved. The project-authored recipe code
and bounds are **GPL-3.0-or-later**; no claim is made that a software licence
replaces the model's attribution licence.

|Path relative to assets/|Licence and provenance|
|---|---|
|`authored/transport/horse_standing/generate_anatomy_v1.py`|Project-authored GPL-3.0-or-later source-only smooth rest-surface recipe; parent mesh rights remain CC-BY-4.0.|
|`authored/transport/horse_standing/anatomy-v1-recipe.json`|Project-authored reconstructed source bounds and exact reference-image bindings; no reference pixels copied into the model.|
|`authored/transport/horse_standing/generate_anatomy_v2.py`|Project-authored GPL-3.0-or-later canonical authored-mesh derivation with immutable-parent and live-field lineage.|
|`authored/transport/horse_standing/anatomy_topology_v2.py`|Project-authored GPL-3.0-or-later adaptive hoof-wall/coronet/toe subdivision and bounded fairing; generated geometry remains an attributed CC-BY-4.0 model derivative.|
|`authored/transport/horse_standing/anatomy-v2-recipe.json`|Project-authored reconstructed anatomy/topology choices, per-feature source IDs, confidence and immutable reference hashes.|
|`authored/transport/horse_standing/ANATOMY.md`|Project-authored source, reconstruction, authoring and acceptance boundary notice; original model attribution remains separate.|
|`authored/transport/horse_standing/horse-sevket-anatomy-v2.glb`|CC-BY-4.0 derivative of sevketkabatas' Horse; reconstructed eyelid and hoof topology changes declared in ANATOMY.md and the versioned recipe. Repaired eye UVs and original six image payloads retain the source rights and credit.|

The anatomy runtime copy is byte-identical at
`renderers/web/transport/standing-horse/horse-sevket-anatomy-v2.glb`.
The original acquired model and b479/d454 authored parents and their old receipts
remain unchanged. Fresh selected-body Mixer129 physical proof is separate from
surface, LOD, world, device performance and photographic qualification.

The input plates by Ellenberger/Baum/Dittrich and Seton are recorded public-domain
anatomical works. The Vassil and Joselodos living-animal photographs are cleared
CC0 references. These supply anatomical relationships and visible continuity;
neither the modern animals' breeds/markings nor their dimensions become evidence
for an 1835 Chicago animal. Their pixels are not sampled into output textures.
The unchanged six model texture payloads retain the source model's CC-BY-4.0
provenance. Source recipes and uninstalled candidate generation do not constitute
native, physical, historical or photographic acceptance.


## T-3088 exact fixed-boundary upper-lid strip

The selected5a2b2e87 source is a **CC-BY-4.0 derivative of Horse by
sevketkabatas**, published29March2021, retrieved via Objaverse. The original
credit, licence/source URLs and ODC-By1.0 dataset notice remain in
`authored/transport/horse_standing/SOURCE.json`;925fac95, d454 and the acquired
original remain preserved. The changes replace142 upper-lid head face slots,
41 interior position/normal rows and two declared internal BODY UV rows. Every
EYE UV and all six original image payloads retain their exact bytes and source
rights. No reference-photo pixels are copied into model textures.

|Path relative to assets/|Licence and provenance|
|---|---|
|`authored/transport/horse_standing/horse-sevket-upper-lid-strip-v1.glb`|CC-BY-4.0 derivative of sevketkabatas' Horse via Objaverse, exact qualified5a source copied without re-export. Fixed-boundary upper-lid topology and two BODY UV repairs are declared in ANATOMY.md and the versioned recipe; source model/images keep their original attribution.|
|`authored/transport/horse_standing/upper-lid-strip-v1-recipe.json`|Project-authored GPL-3.0-or-later reconstructed bounds, explicit patch/UV ownership and cleared source/reference bindings. No source pixels or modern breed identity are transferred as historical evidence.|
|`authored/transport/horse_standing/generate_upper_lid_strip_v1.py`|Project-authored GPL-3.0-or-later deterministic NumPy source generator derived from the reviewed strip algorithm. It verifies immutable parents, source rights and fixed bounds; generation does not replace the model's CC-BY-4.0 attribution or assert qualification.|

The exact runtime copy is
`renderers/web/transport/standing-horse/horse-sevket-upper-lid-strip-v1.glb`.
The old925 authored/runtime files remain unchanged. Ellenberger/Baum/Dittrich
public-domain anatomy plates and the Joselodos CC0 living-animal reference guide
this bounded reconstruction; their rights, dates and limits remain in the source
register. Source qualification and visible anatomical improvement do not establish
full photographic, historical-individual, gait or occupied-use acceptance.


### Preserved5a child: upper-orbital BODY transition (T-3088)

| File | Credit and scope |
|---|---|
|`authored/transport/horse_standing/horse-sevket-upper-orbital-transition-v1.glb`|Exact e49b CC-BY-4.0 derivative of sevketkabatas's2021 Horse; original modern author, source URL and Objaverse/acquisition provenance remain in SOURCE.json. Project-authored reconstructed BODY ridge adjustment; no historical owner/breed or pixel-calibrated period measurement claimed.|
|`authored/transport/horse_standing/upper-orbital-transition-v1-recipe.json`|GPL-3.0-or-later project recipe, explicit10-position/38-normal region, same-side fixed anchors and unchanged limits. Original5a/f77 recipe and strict failure remain preserved.|
|`authored/transport/horse_standing/generate_upper_orbital_transition_v1.py`|GPL-3.0-or-later pure source-table generator and protected-source controls; it does not replace the asset's CC-BY-4.0 attribution or prove photographic likeness.|

The runtime file is `renderers/web/transport/standing-horse/horse-sevket-upper-orbital-transition-v1.glb`, byte-identical to the authored source. All5a/925/d454/raw/canonical26 sources and old modes remain. Cleared PD anatomy/CC0 living-animal references guide the bounded reconstruction with their existing date/identity limits. Exact-source fresh129 and matched source views support this increment; current app/yard/full gates and remaining anatomy/surface concerns are separate.


### Pending e49 child: eye smooth normals (T-3088, 29 October 2026)

|File|License and change notice|
|---|---|
|`authored/transport/horse_standing/horse-sevket-eye-smooth-normals-v1.glb`|CC-BY-4.0 derivative of “Horse” by sevketkabatas, published29March2021, via the preserved Objaverse/acquisition lineage and original source URL in SOURCE.json. Exact e49 parent; only3968 EYE NORMAL rows and their truthful accessor min/max change. Existing model, six images, UVs, rig, clip and material credit remain unchanged.|
|`authored/transport/horse_standing/eye-smooth-normals-v1-recipe.json`|GPL-3.0-or-later project recipe for deterministic source-derived sphere normals. Its historical unadopted creation-state notice is preserved; it does not grant asset qualification.|
|`authored/transport/horse_standing/generate_eye_smooth_normals_v1.py`|GPL-3.0-or-later project source-table derivation and protected-byte verifier; the emitted model remains credited to sevketkabatas under CC-BY-4.0.|

This is a separately declared pending source child, not the selected runtime horse.
SOURCE.json retains the original modern author, source URL, license URL and parent
lineage. No normal texture, new photograph, reference-image derivative or invented
historical individual is introduced. Exact-child physical/socket qualification,
canonical source gates and genuine native organic yard comparison remain pending.
The e49/5a/925/d454 assets and their exact-byte certificates remain preserved.


The separate eye-normal child above is now source-selected under explicit
`eye_smooth_normals_v1` after fresh29October2026 canonical static/native
physical129/posed socket129 qualification of exact bd443 bytes. Its runtime copy
is `renderers/web/transport/standing-horse/horse-sevket-eye-smooth-normals-v1.glb`.
The preserved e49 parent retains its old exact-byte proof. The new recipe's
creation notice remains historical; actual qualification is in the separate
source-bound summary. Native organic published-yard comparison and whole-photo
acceptance remain pending. Source credits and CC-BY-4.0 license do not change.


### Pending natural planted idle source (T-2803, 29 October 2026)

|File|License and change notice|
|---|---|
|`authored/transport/horse_standing/horse-sevket-natural-planted-idle-v1.glb`|Animation-only CC-BY-4.0 model derivative of sevketkabatas' Horse, via unchanged SOURCE.json/Objaverse acquisition lineage. All geometry, skin, six images, materials and existing clip retain original credit. Project-authored reconstructed neck/head look and tail flick are exported as one additional clip; no source-native donated animation, historical individual/breed or gait is claimed.|
|`authored/transport/horse_standing/natural-planted-idle-v1-recipe.json`|GPL-3.0-or-later project reconstructed motion parameters, explicit local axes and original standing protections. Historical creation flags remain preserved; qualification is separate.|
|`authored/transport/horse_standing/generate_natural_planted_idle_v1.py`|GPL-3.0-or-later deterministic portable animation-only source generator and strict parent-byte verifier. Emitted model credit and CC-BY-4.0 attribution remain intact.|
|`authored/transport/horse_standing/natural-planted-idle-v1-PROVENANCE.json`|GPL-3.0-or-later project change/provenance notice with original licensed asset credit, parent/candidate identities and pending qualification scope.|

Exact source candidate8ea7748f is PREPARED ONLY. Active runtime stays exact bd443
and its existing one-clip mode. Fresh selected17track native physical/socket129,
actual published desktop/phone visible motion and full application gates are
UNRUN. No old certificate transfers. No new photograph or invented archival action.


### Prepared anatomical binding repair v2 (T-2803, 29 October 2026)

|File|License and change notice|
|---|---|
|`authored/transport/horse_standing/horse-sevket-natural-planted-binding-v2.glb`|CC-BY-4.0 derivative of sevketkabatas' Horse through unchanged SOURCE.json credit/acquisition lineage. Project-authored reconstructed skull/neck and tail binding replaces only declared skin rows; original geometry, rig, images and animation are retained. Source preparation only, no native motion acceptance or historical individual likeness.|
|`authored/transport/horse_standing/horse-sevket-original925-paired-binding-v2.glb`|CC-BY-4.0 separately versioned original925-geometry reference with exactly the same reviewed new skin tuples, retaining original author/credits. Never represented as unchanged original925.|
|`authored/transport/horse_standing/natural-planted-binding-v2-recipe.json`|GPL-3.0-or-later project anatomical field recipe and explicit row domain; no copied image pixels.|
|`authored/transport/horse_standing/natural-planted-binding-v2-PROVENANCE.json`|GPL-3.0-or-later project change notice retaining original model credit and CC-BY-4.0 asset attribution.|

The earlier8ea new17-track trial failed physical limits; that verdict is preserved.
V2 source-byte controls pass, but old13/native17/socket129/world qualification and
application adoption remain UNRUN. Active runtime stays bd443.


### Prepared root-aware mane binding v3 (T-2803, 29 October 2026)

|File|License and change notice|
|---|---|
|`authored/transport/horse_standing/horse-sevket-natural-planted-root-binding-v3.glb`|CC-BY-4.0 derivative of sevketkabatas' Horse retaining SOURCE.json acquisition/author/source credit and all previous notices. Project-authored reconstructed mane-root binding changes1119declaredHAIR rows only; no donated/source-native motion or historic animal identity is asserted.|
|`authored/transport/horse_standing/horse-sevket-original925-root-binding-v3.glb`|CC-BY-4.0 separately versioned original925-geometry reference, with the same reviewed root-binding overlay; original model credit remains intact. Not unchanged925.|
|`authored/transport/horse_standing/root-binding-v3-recipe.json`|GPL-3.0-or-later project source-geometry crest guide, explicit domain and reconstructed attachment rule; no copied image pixels.|
|`authored/transport/horse_standing/root-binding-v3-PROVENANCE.json`|GPL-3.0-or-later project change/lineage notice retaining original model attribution and CC-BY-4.0 license.|

V2 actualretained13-track parity/physical passed, but new17HAIRarea failed. The V3
source-only export/11corruption controls pass; all fresh native/posed/world gates
and adoption remain UNRUN. Runtime remains bd443; no old qualification transfers.


### Quiet head/neck first motion V6 — reconstructed, unselected PhaseA

|File|Rights and scope|
|---|---|
|`authored/transport/horse_standing/horse-sevket-quiet-head-neck-idle-v6.glb`|CC-BY-4.0 derivative of Horse by sevketkabatas (29March2021), retaining SOURCE.json acquisition/source URL and original model/six-image credit. Project-authored exact V4HEAD skin field and separately named quiet head/neck clip; all original source13/failed17 history preserved. Reconstructed first motion, not a historical animal or gait. Unselected pending fresh canonical qualification.|
|`authored/transport/horse_standing/horse-sevket-original925-head-neck-binding-v6.glb`|Separately versioned CC-BY-4.0 original925-geometry reference with identical new HEAD binding. Same sevketkabatas attribution; never represented as unchanged925.|
|`authored/transport/horse_standing/quiet-head-neck-v6-PROVENANCE.json`|GPL-3.0-or-later project source/change/scope notice. Original model/images retain CC-BY-4.0 credit and acquired provenance; no qualification or historical likeness is transferred.|

Project-authored V6 code/recipe/HEAD-field fixture are under `tools/transport/horse_quiet_head_neck_idle_v6/`, GPL-3.0-or-later. The one-quiet-clip runtime derivative is `renderers/web/transport/standing-horse/horse-sevket-quiet-head-neck-idle-v6.glb`; its entire BIN/geometry/images/materials/rig and retained motion curves equal the authored master, with old13/failed17 omitted only from playable inventory. Source/projection preparation is not native/socket/world/photo acceptance.


### T-1790 original natural-standing animation derivative

The eight existing `bardwell_otis_1835` master/web LODs below append the project-authored `idle_natural_v1` standing look and breath. Original geometry, images, skinning, inverse binds, nodes, materials, arm/lower-body animation channels and all original clips remain preserved. Original MakeHuman/other graphical notices above continue to apply. New animation curve arrays are dedicated CC0-1.0; generator/probe code remains GPL-3.0-or-later. Timings and amplitudes are reconstructed ordinary standing, not a witnessed action, named gesture or documentary likeness (liberty L-natural-standing-1790). Original canonical metadata identifies the parents only; exact derivation and separate native qualification are filed under data/humans/animations/. Finite native CPU checks are not photographic or complete clothing/scene acceptance.

|Path relative to assets/|Licence|Bytes|SHA256|
|---|---|---:|---|
|`humans/bardwell_otis_1835.lod0.glb`|CC0-1.0 graphical assets and original notices retained|8673076|`821d771462b6ff583c27ccc00fbcde3604dc34d24b4512c5d5ba92dba331589f`|
|`humans/bardwell_otis_1835.lod1.glb`|CC0-1.0 graphical assets and original notices retained|8034376|`4752182f829f21e9e959c700d98e2aa4c75b97a7ea1b58814148bb3a7cded854`|
|`humans/bardwell_otis_1835.lod2.glb`|CC0-1.0 graphical assets and original notices retained|7482072|`c4a99b4ba9f1a375a4490383322506d772ee6b588959aa645d686f7dddd1a68f`|
|`humans/bardwell_otis_1835.lod3.glb`|CC0-1.0 graphical assets and original notices retained|7258004|`18e48c466ace5f47f799607128b52c1a9118627fec7afc323ad18cd63c4914d1`|
|`humans/web/bardwell_otis_1835.lod0.glb`|CC0-1.0 graphical assets and original notices retained|4463076|`d568cb8f7d17fb9f8ca7035049c6f1c3f02a30f3d153242d1ea67f876b454ddf`|
|`humans/web/bardwell_otis_1835.lod1.glb`|CC0-1.0 graphical assets and original notices retained|1585036|`aef139f58ee352ef7c8e73d945bc0af5d1bbf5d4f27e4f43fb5ed8b739b16bc3`|
|`humans/web/bardwell_otis_1835.lod2.glb`|CC0-1.0 graphical assets and original notices retained|636028|`dd12e07063c142628cfe3c0f2d7b42a38c018376722af669b27ee768fc8408ad`|
|`humans/web/bardwell_otis_1835.lod3.glb`|CC0-1.0 graphical assets and original notices retained|325492|`bb650009de2987b46e1c54fa64ca45f42c7e3d088f71de3451adb8d83c9de0d7`|

## Driven-team hitch (T-2804, bounded reconstructed increment)

`assets/authored/transport/driven_hitch_v2/`, `renderers/web/transport/driven-hitch/current26-collar-girth-v2.glb` and `connection-units-v1.glb`: original project-authored fitted strap/link geometry and producers, GPL-3.0-or-later. Surface fitting and skin-weight interpolation derive from **Horse by sevketkabatas**, CC BY4.0, https://sketchfab.com/3d-models/horse-53a6eb7ccf054aa2a378dd7ec08f88fe. Existing source-specific26-joint adaptation retains its separate **antemeossa** Rigged Mid-Poly Horse rig/motion reference credit, CC BY4.0, https://sketchfab.com/3d-models/rigged-mid-poly-horse-fea999c1d8d64eb4a9c2bb1fac1e7d83. Complete inherited source credit, exact input hashes and modification notice are in `assets/authored/transport/driven_hitch_v2/LICENSE-PROVENANCE.json`. No historical harness photograph or rights-pending image was traced. Colors, construction, dimensions and driving use are declared reconstructions.

## Driven current26 in-place horse (T-2803/T-2804)

`assets/authored/transport/driven_current26_v1/horse-current26-inplace-master.glb` and `renderers/web/transport/driven/horse-current26-inplace-full.glb`: **Horse by sevketkabatas**, CC BY4.0, https://sketchfab.com/3d-models/horse-53a6eb7ccf054aa2a378dd7ec08f88fe. Inherited **Rigged Mid-Poly Horse by antemeossa** rig/motion reference credit, CC BY4.0, https://sketchfab.com/3d-models/rigged-mid-poly-horse-fea999c1d8d64eb4a9c2bb1fac1e7d83. Original author/license/source links and the complete declared derivative history remain in the GLB. Reconstructed current26 skin/rig, quiet idle and in-place careful WALK are modifications; no historical breed, owner or individual is identified. The authored master publishes byte-identically with its included Python command; no Blender or source photograph tracing is required for that delivery.

`renderers/web/transport/driven/horse-walk-v2.json` and `data/transport/driven/current26-walk-v2-hoof-domain.json` (T-2803): an in-place walk clip and its hoof-support measurement, generated by `tools/horse_walk_v2.mjs` from the rest pose of the horse GLB above. They contain no mesh or texture data, only bone rotations and measurements, and carry the same inherited credits: **Horse by sevketkabatas**, CC BY4.0, and the **Rigged Mid-Poly Horse by antemeossa** rig reference, CC BY4.0. The gait is an original reconstruction; no historical horse is identified.

`renderers/web/transport/driven/driver-livery-1904.json` (T-3398, T-3409): a coachman's box coat with shoulder cape, brass buttons and silk top hat, and `renderers/web/transport/driven/wardrobe-bardwell-otis-1835.json` (T-3409): a round jacket with horn buttons and a broad-brimmed felt hat. Original geometry generated by `tools/human_wardrobe.py` and `tools/wardrobe_kit.py` from the recipes in `data/humans/wardrobes/` (garments offset from each driver's own shirt mesh, cloth draped by an original position-based simulation, hats fitted to the head) and skinned to each driver's skeleton, with original spring-tail bones. Original work, CC0-1.0. They carry no texture; their shapes follow the CC0 portable-human drivers above.

### T-2804 — reconstructed1904 working-driver depiction ingredient

The following graphical assets are CC0-1.0 derivatives of the cleared MakeHuman adult35, Toigo skin, short04 hair and original project workwear components. Complete original creator notices, exact immutable canonical artifact12398870779/source34cf462e ingredient hashes and transformations are retained in authored/humans/working_driver_1904/SOURCE.json. The display figure binds existing inferred coachman Hans Johnson; body, clothes, seated action and journey are reconstructed, not a portrait or household carriage ownership. Producer/test code is GPL-3.0-or-later. No new external image is used.

| File | License | Basis |
|---|---|---|
| `authored/humans/working_driver_1904/POSE-MASTER.json` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `authored/humans/working_driver_1904/SOURCE.json` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `authored/humans/working_driver_1904/ingredients/dufresne_joseph_1835.lod0.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `authored/humans/working_driver_1904/ingredients/dufresne_joseph_1835.lod1.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `authored/humans/working_driver_1904/ingredients/dufresne_joseph_1835.lod2.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `authored/humans/working_driver_1904/ingredients/dufresne_joseph_1835.lod3.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `authored/humans/working_driver_1904/ingredients/web/dufresne_joseph_1835.lod0.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `authored/humans/working_driver_1904/ingredients/web/dufresne_joseph_1835.lod1.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `authored/humans/working_driver_1904/ingredients/web/dufresne_joseph_1835.lod2.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `authored/humans/working_driver_1904/ingredients/web/dufresne_joseph_1835.lod3.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `humans/anonymous_working_driver_1904.lod0.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `humans/anonymous_working_driver_1904.lod1.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `humans/anonymous_working_driver_1904.lod2.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `humans/anonymous_working_driver_1904.lod3.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `humans/web/anonymous_working_driver_1904.lod0.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `humans/web/anonymous_working_driver_1904.lod1.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `humans/web/anonymous_working_driver_1904.lod2.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |
| `humans/web/anonymous_working_driver_1904.lod3.glb` | CC0-1.0 | Cleared graphical ingredient or original documented derivative; SOURCE.json retains exact source and credit. |


### T-3088 — explicit authored transport source-file registration

These are the source and numerical-provenance files accompanying the driven-team hitch and current26 horse entries above. This registration retains their existing source credits and licenses; it adds no external ingredient or historical attestation. Project-authored producers and parameter records are GPL-3.0-or-later. Referenced horse graphics retain CC BY4.0 credits, and referenced MakeHuman graphical ingredients retain their CC0 notices. No geometry, animation, material, source image or asset selection changes here.

| File | License | Basis |
|---|---|---|
| `authored/transport/driven_current26_v1/SOURCE.json` | CC-BY-4.0 | Attribution and derivative record for Horse by sevketkabatas; inherited antemeossa rig/motion-reference credit remains in the master and the preceding entry. |
| `authored/transport/driven_current26_v1/publish_master.py` | GPL-3.0-or-later | Original project-authored byte-preserving publisher; its SPDX notice is retained. |
| `authored/transport/driven_hitch_v2/ACTUAL-1835-OTIS-PALM-SURFACES.json` | GPL-3.0-or-later | Original numerical surface-measurement record; the named Bardwell MakeHuman graphical ingredients retain their CC0 notices. Not a photograph or a closed-finger-grasp claim. |
| `authored/transport/driven_hitch_v2/author_hitch.py` | GPL-3.0-or-later | Original project-authored producer covered by the driven-team hitch provenance entry and LICENSE-PROVENANCE.json above. |
| `authored/transport/driven_hitch_v2/build_connection_units.py` | GPL-3.0-or-later | Original project-authored producer; inherited ingredient credits remain as declared above. |
| `authored/transport/driven_hitch_v2/build_hitch_prototype.py` | GPL-3.0-or-later | Original project-authored producer; Horse by sevketkabatas and the inherited antemeossa reference retain CC BY4.0 attribution. |
| `authored/transport/driven_hitch_v2/build_live_bindings.py` | GPL-3.0-or-later | Original project-authored binding producer; referenced graphical assets retain their existing notices. |
| `authored/transport/driven_hitch_v2/connection-unit-parameters.json` | GPL-3.0-or-later | Original reconstructed connection-unit dimensions and construction parameters under the existing driven-team hitch declaration. |
| `authored/transport/driven_hitch_v2/team-hitch-parameters.json` | GPL-3.0-or-later | Original reconstructed fitted-hitch parameters; declared source horse and wagon hashes and inherited graphical attribution remain unchanged. |


### T-2804 — original seated driver looking animation derivative

The following active LOD0/LOD3 exports append an original reconstructed head/neck animation to the exact cleared Otis and Hans parents. All existing MakeHuman, Toigo, short04 hair and original workwear creator notices, identity/scene metadata, graphical geometry, materials, textures and source clips remain. The original animation data is released as CC0-1.0 with the graphical derivatives; `tools/human_seated_look.py` and its tests remain GPL-3.0-or-later. No external image, cultural evidence, historical likeness or witnessed action is introduced. The exact parent chain, generated children and finite native readback are in `data/humans/animations/seated-driver-look-v2.json`, `.derivation.json`, `.native.json` and `.binding-refresh.json`. Earlier table rows and receipts remain parent records.

| Active file under `assets/` | License | Bytes | SHA256 |
|---|---|---:|---|
| `humans/bardwell_otis_1835.lod0.glb` | CC0-1.0; original creator notices retained | 8688224 | `4816ec6176ef6037834c1e8a14c528a5b394173bfa2821372bd66ae1d802bd38` |
| `humans/bardwell_otis_1835.lod3.glb` | CC0-1.0; original creator notices retained | 7273156 | `2c57f30ca74d2390913167a63e2df6fe0b3b92d9296c6b078d237e6bda0a693e` |
| `humans/web/bardwell_otis_1835.lod0.glb` | CC0-1.0; original creator notices retained | 4478104 | `afc2fda09713911404b4b2c39ee08bf5d98e126f62ca16c55cf50de728586c6b` |
| `humans/web/bardwell_otis_1835.lod3.glb` | CC0-1.0; original creator notices retained | 340516 | `9423585a506b1ae317c08c7eae9fb936e6ceea5e46d00ae6b2673f8c5e268f81` |
| `humans/anonymous_working_driver_1904.lod0.glb` | CC0-1.0; original creator notices retained | 8650564 | `c3b285d0305559ee5fbe13695985df86cde4c38ca8d7efd8419fcdd2d97bc4b8` |
| `humans/anonymous_working_driver_1904.lod3.glb` | CC0-1.0; original creator notices retained | 7256444 | `3833f8fc26f722d17c62afa36ce1b511e38fd112142619db58fa1bf9f551ef75` |
| `humans/web/anonymous_working_driver_1904.lod0.glb` | CC0-1.0; original creator notices retained | 4458148 | `49a84c1d858f67359ff33e56762336ade56db1dcbbb1cbe923846d95825c9547` |
| `humans/web/anonymous_working_driver_1904.lod3.glb` | CC0-1.0; original creator notices retained | 326600 | `84e602cd49c6e355fb25bc6659a0f4a9e573e4bebe6ce8d2e30e14ed5250b60b` |


### T-2804 — explicit terminal LOD3 garment retention

Only the following four active LOD3 payloads replace the seated-looking parents listed above. The exact same-resident LOD0 shirt/trouser topology is retained on LOD3; WEB garment positions/normals are newly derived by deterministic single-skin rest-weighted rebinding. Existing cleared MakeHuman, Toigo, short04 hair and original workwear notices remain; no external image, likeness or new historical claim is introduced. Existing body, rig, original skin, images/materials and old clips remain. Graphical derivatives retain CC0-1.0 and creator notices; project-authored tools remain GPL-3.0-or-later. All LOD0/1/2 files and every other human payload are unchanged. Exact parents, donors, outputs and regeneration are in `data/humans/animations/driver-garment-retention-v2.json`, `.derivation.json` and `.native.json`; previous receipt/table hashes remain historical parent records.

| Active file under `assets/` | License | Bytes | SHA256 |
|---|---|---:|---|
| `humans/bardwell_otis_1835.lod3.glb` | CC0-1.0; original creator notices retained | 7573012 | `e89508276188b4ceabd612a79552fdab284dc45d832f26b6d2a09b42401a3016` |
| `humans/web/bardwell_otis_1835.lod3.glb` | CC0-1.0; original creator notices retained | 564628 | `c5b1e37cc39b44e5dfb74496df957de7d93e5e0341f58e6d608f6fb09857bd88` |
| `humans/anonymous_working_driver_1904.lod3.glb` | CC0-1.0; original creator notices retained | 7557312 | `0754da886b868ffe1f18d9d89a11174bbca6b9f330bf3a5ca45f7982dcb44a9a` |
| `humans/web/anonymous_working_driver_1904.lod3.glb` | CC0-1.0; original creator notices retained | 551488 | `6c5182d709ce9de5be003a650c4f7f69b90ae9591d0865174d4303103bd97de4` |

### Body and face variation kit — `humans/web/hm08_variation_kit.*` (T-3412)

The MakeHuman graphical targets below are **CC0-1.0**, each carrying its own CC0 header, copied verbatim
from the same pinned [MakeHuman commit a8bc2d54ff0ac92e78ff71431b1023eda42bf482](https://github.com/makehumancommunity/makehuman/tree/a8bc2d54ff0ac92e78ff71431b1023eda42bf482);
`SOURCE-variation.json` records each one's upstream URL, size and SHA-256 (the macro age targets it also
lists are the ones `SOURCE.json` already pins, unchanged). No MakeHuman program code is copied.
`hm08_variation_kit.bin`, `.json`, `hm08_variation_persons.json` and the 1835 and 1871 towns' own tables `hm08_variation_persons_1835.json` (T-3556) and `hm08_variation_persons_1871.json` (T-3690) are generated from them by `tools/human_variation_kit.py` (original,
GPL-3.0-or-later code) and are CC0-1.0, like `prepared.json` they are carried onto. Every value a person
draws from the kit is a reconstruction (L-human-variation-3412), not a likeness. The nine `expression/units/caucasian/mouth-*`
targets (T-3553) are not axes of the kit: `tools/bake_likeness_skin.py` reads them to fit a person's smile
to a picture (`data/humans/variation/smiles/`, L-grey-smile-3553, L-grey-sarah-smile-3553).

```text
authored/humans/makehuman_hm08/SOURCE-variation.json
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/l-cheek-bones-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/l-cheek-bones-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/l-cheek-inner-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/l-cheek-inner-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/l-cheek-volume-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/l-cheek-volume-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/r-cheek-bones-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/r-cheek-bones-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/r-cheek-inner-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/r-cheek-inner-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/r-cheek-volume-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/cheek/r-cheek-volume-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/chin/chin-bones-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/chin/chin-bones-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/chin/chin-height-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/chin/chin-height-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/chin/chin-prognathism-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/chin/chin-prognathism-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/chin/chin-prominent-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/chin/chin-prominent-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/chin/chin-width-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/chin/chin-width-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/l-ear-flap-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/l-ear-flap-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/l-ear-lobe-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/l-ear-lobe-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/l-ear-scale-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/l-ear-scale-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/r-ear-flap-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/r-ear-flap-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/r-ear-lobe-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/r-ear-lobe-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/r-ear-scale-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/ears/r-ear-scale-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/expression/units/caucasian/mouth-corner-puller.target
authored/humans/makehuman_hm08/makehuman/data/targets/expression/units/caucasian/mouth-depression-retraction.target
authored/humans/makehuman_hm08/makehuman/data/targets/expression/units/caucasian/mouth-depression.target
authored/humans/makehuman_hm08/makehuman/data/targets/expression/units/caucasian/mouth-elevation.target
authored/humans/makehuman_hm08/makehuman/data/targets/expression/units/caucasian/mouth-eversion.target
authored/humans/makehuman_hm08/makehuman/data/targets/expression/units/caucasian/mouth-parling.target
authored/humans/makehuman_hm08/makehuman/data/targets/expression/units/caucasian/mouth-part-later.target
authored/humans/makehuman_hm08/makehuman/data/targets/expression/units/caucasian/mouth-retraction.target
authored/humans/makehuman_hm08/makehuman/data/targets/expression/units/caucasian/mouth-upward-retraction.target
authored/humans/makehuman_hm08/makehuman/data/targets/eyebrows/eyebrows-angle-down.target
authored/humans/makehuman_hm08/makehuman/data/targets/eyebrows/eyebrows-angle-up.target
authored/humans/makehuman_hm08/makehuman/data/targets/eyebrows/eyebrows-trans-backward.target
authored/humans/makehuman_hm08/makehuman/data/targets/eyebrows/eyebrows-trans-down.target
authored/humans/makehuman_hm08/makehuman/data/targets/eyebrows/eyebrows-trans-forward.target
authored/humans/makehuman_hm08/makehuman/data/targets/eyebrows/eyebrows-trans-up.target
authored/humans/makehuman_hm08/makehuman/data/targets/eyes/l-eye-eyefold-down.target
authored/humans/makehuman_hm08/makehuman/data/targets/eyes/l-eye-eyefold-up.target
authored/humans/makehuman_hm08/makehuman/data/targets/eyes/r-eye-eyefold-down.target
authored/humans/makehuman_hm08/makehuman/data/targets/eyes/r-eye-eyefold-up.target
authored/humans/makehuman_hm08/makehuman/data/targets/forehead/forehead-nubian-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/forehead/forehead-nubian-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/forehead/forehead-scale-vert-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/forehead/forehead-scale-vert-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/forehead/forehead-temple-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/forehead/forehead-temple-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/head/head-age-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/head/head-age-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/head/head-diamond.target
authored/humans/makehuman_hm08/makehuman/data/targets/head/head-fat-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/head/head-fat-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/head/head-invertedtriangular.target
authored/humans/makehuman_hm08/makehuman/data/targets/head/head-oval.target
authored/humans/makehuman_hm08/makehuman/data/targets/head/head-rectangular.target
authored/humans/makehuman_hm08/makehuman/data/targets/head/head-round.target
authored/humans/makehuman_hm08/makehuman/data/targets/head/head-square.target
authored/humans/makehuman_hm08/makehuman/data/targets/head/head-triangular.target
authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/universal-male-young-averagemuscle-maxweight.target
authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/universal-male-young-averagemuscle-minweight.target
authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/universal-male-young-maxmuscle-averageweight.target
authored/humans/makehuman_hm08/makehuman/data/targets/macrodetails/universal-male-young-minmuscle-averageweight.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-angles-down.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-angles-up.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-lowerlip-height-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-lowerlip-height-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-lowerlip-volume-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-lowerlip-volume-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-scale-horiz-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-scale-horiz-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-trans-down.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-trans-up.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-upperlip-volume-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/mouth/mouth-upperlip-volume-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/neck/neck-double-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/neck/neck-scale-horiz-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/neck/neck-scale-horiz-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/neck/neck-trans-backward.target
authored/humans/makehuman_hm08/makehuman/data/targets/neck/neck-trans-forward.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-curve-concave.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-curve-convex.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-hump-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-hump-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-nostrils-angle-down.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-nostrils-angle-up.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-nostrils-width-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-nostrils-width-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-point-down.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-point-up.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-point-width-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-point-width-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-scale-depth-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-scale-depth-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-scale-horiz-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-scale-horiz-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-scale-vert-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-scale-vert-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-septumangle-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-septumangle-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-trans-down.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-trans-up.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-volume-decr.target
authored/humans/makehuman_hm08/makehuman/data/targets/nose/nose-volume-incr.target
authored/humans/makehuman_hm08/makehuman/data/targets/stomach/stomach-pregnant-incr.target
humans/web/hm08_variation_kit.bin
humans/web/hm08_variation_kit.json
humans/web/hm08_variation_persons.json
humans/web/hm08_variation_persons_1835.json
humans/web/hm08_variation_persons_1871.json
```

### A named resident's portrait and fitted face — `humans/web/portraits/` (T-3413)

`glessner_john_j_portrait.jpg` is cut and scaled from the Internet Archive's scan of the Library of
Congress copy of *The Commercial Club of Chicago* (1910), p. 81 (source record
`glessner_commercial_club_1910_presidents_plate`): a US book of 1910, **public domain**. The crop box
is recorded in `data/humans/variation/portraits/glessner_john_j.json`.
`glessner_john_j_model.jpg` (and its `.json` sidecar) is rendered by `tools/portrait_still.mjs` from
the CC0 MakeHuman-derived body and the fit in `data/humans/variation/fits/`, and is **CC0-1.0**.

```text
humans/web/portraits/glessner_john_j_model.jpg
humans/web/portraits/glessner_john_j_model.json
humans/web/portraits/glessner_john_j_portrait.jpg
```

`glessner_frances_m_portrait.jpg` (T-3473) is cut and scaled from the copy the owner supplied of the
Chicago History Museum's photograph ICHi-061818 of 4 March 1892 (source record
`chm_ichi_061818_frances_glessner_conservatory_1892`), which the museum marks "No Copyright - United
States": **public domain**; credit Chicago History Museum, ICHi-061818. The crop box is recorded in
`data/humans/variation/portraits/glessner_frances_m.json`. `glessner_frances_m_model.jpg` (and its
`.json` sidecar) is rendered by `tools/portrait_still.mjs` as above, and is **CC0-1.0**.

```text
humans/web/portraits/glessner_frances_m_model.jpg
humans/web/portraits/glessner_frances_m_model.json
humans/web/portraits/glessner_frances_m_portrait.jpg
```

`glessner_williamson_martha_l_portrait.jpg` (T-3486) is cut and scaled from the Glessner House Museum's blog copy of Mattie Williamson's 1890s portrait (source record `glessner_blog_mattie_williamson_portrait_1890s`), a photograph made before 1906: **public domain** in the United States; credit Glessner House Museum. The crop box is recorded in
`data/humans/variation/portraits/glessner_williamson_martha_l.json`. `glessner_williamson_martha_l_model.jpg` (and its `.json` sidecar) is
rendered by `tools/portrait_still.mjs` as above, and is **CC0-1.0**.

```text
humans/web/portraits/glessner_williamson_martha_l_model.jpg
humans/web/portraits/glessner_williamson_martha_l_model.json
humans/web/portraits/glessner_williamson_martha_l_portrait.jpg
```

`pa1904_glessner_john_j_c1900_mary_reynolds_portrait.jpg` (T-3486) is cut and scaled from the Library of Congress master of a 1908 General Electric photograph of a house maid (LC-USZ62-67635; source record `loc_cph_3b15107_ge_house_maid_ironing_1908`), a STAND-IN, not Mary Reynolds; the Library states no known restrictions on publication and a 1908 photograph is **public domain** in the United States. The stand-in label is burned on the picture. The crop box is recorded in
`data/humans/variation/portraits/pa1904_glessner_john_j_c1900_mary_reynolds.json`. `pa1904_glessner_john_j_c1900_mary_reynolds_model.jpg` (and its `.json` sidecar) is
rendered by `tools/portrait_still.mjs` as above, and is **CC0-1.0**.

```text
humans/web/portraits/pa1904_glessner_john_j_c1900_mary_reynolds_model.jpg
humans/web/portraits/pa1904_glessner_john_j_c1900_mary_reynolds_model.json
humans/web/portraits/pa1904_glessner_john_j_c1900_mary_reynolds_portrait.jpg
```

`pa1904_glessner_john_j_c1900_kate_ryan_portrait.jpg` (T-3479) is cut and scaled from the left frame of William H. Rau's 1903 Achill Island stereograph (LC-DIG-stereo-1s27248; source record `loc_stereo_1s27248_achill_spinning_wheel_1903`), a STAND-IN, not Kate Ryan; no known restrictions, **public domain** in the United States. The stand-in label is burned on the picture. The crop box is recorded in
`data/humans/variation/portraits/pa1904_glessner_john_j_c1900_kate_ryan.json`. `pa1904_glessner_john_j_c1900_kate_ryan_model.jpg` (and its `.json` sidecar) is
rendered by `tools/portrait_still.mjs` as above, and is **CC0-1.0**.

```text
humans/web/portraits/pa1904_glessner_john_j_c1900_kate_ryan_model.jpg
humans/web/portraits/pa1904_glessner_john_j_c1900_kate_ryan_model.json
humans/web/portraits/pa1904_glessner_john_j_c1900_kate_ryan_portrait.jpg
```

`pa1904_grey_w_l_portrait.jpg` and `pa1904_grey_mrs_w_l_portrait.jpg` (T-3553) are cut and scaled from two sepia portraits the project owner supplied on 2026-11-12 as the likenesses to use for William L. and Sarah Grey (source records `owner_grey_likeness_william_2026`, `owner_grey_likeness_sarah_2026`; the full pictures are kept in kevinrhaas/chicago-evidence, `evidence/grey-likenesses-2026-11-12/`). They are STAND-INS, not the Greys: who sat for them and who made them are not recorded. Cleared by the owner for this project's own use and derivation; **not openly licensed** (all rights as the owner holds them). The stand-in label is burned on each picture. The crop boxes are recorded in
`data/humans/variation/portraits/pa1904_grey_w_l.json` and `pa1904_grey_mrs_w_l.json`. The `_model.jpg` stills (and their `.json` sidecars) are
rendered by `tools/portrait_still.mjs` as above, and are **CC0-1.0**.

```text
humans/web/portraits/pa1904_grey_mrs_w_l_model.jpg
humans/web/portraits/pa1904_grey_mrs_w_l_model.json
humans/web/portraits/pa1904_grey_mrs_w_l_portrait.jpg
humans/web/portraits/pa1904_grey_w_l_model.jpg
humans/web/portraits/pa1904_grey_w_l_model.json
humans/web/portraits/pa1904_grey_w_l_portrait.jpg
```

`pa1904_grey_w_l_skin.jpg` and `pa1904_grey_mrs_w_l_skin.jpg` (T-3553) are baked by `tools/bake_likeness_skin.py` from the head turnaround sheets the project owner supplied on 2026-11-13 of the same two stand-ins (front, both sides and behind, in colour; source records `owner_grey_likeness_william_2026`, `owner_grey_likeness_sarah_2026`; the sheets are kept in kevinrhaas/chicago-evidence, `evidence/grey-likenesses-2026-11-12/`). Each is the four views of a stand-in's head laid onto the body's skin layout as the figure's skin, hair and eyes, with the tool's own small blocks beside them (where the sheet covers, how far the hair stands out and which way it faces, and each iris drawn from the front view). `pa1904_grey_w_l_front.jpg` and `pa1904_grey_mrs_w_l_front.jpg` are the same tool's cut of each sheet's front view alone (the head's square of it, its white ground and the clothing filled from the head beside them, and beside it a block saying where the renderer shows it), which the figure's skin shows to someone standing in front of it. `pa1904_grey_mrs_w_l_skin.jpg` also holds, in a patch of 64 by 160 pixels, the upper teeth of a photograph of the same stand-in smiling, which the owner supplied on 2026-11-14 (kept in the same evidence folder; the record's `smile_view`), brought to the sheet's light. They are pictures of STAND-INS, not of the Greys: who sat for them and who made them are not recorded. Cleared by the owner for this project's own use and derivation; **not openly licensed** (all rights as the owner holds them). No label can be burned on a skin: the stand-in label is on each person's card. The crops, cameras and what is left out are recorded in
`data/humans/variation/skins/pa1904_grey_w_l.json` and `pa1904_grey_mrs_w_l.json`.

```text
humans/web/likeness/pa1904_grey_mrs_w_l_front.jpg
humans/web/likeness/pa1904_grey_mrs_w_l_skin.jpg
humans/web/likeness/pa1904_grey_w_l_front.jpg
humans/web/likeness/pa1904_grey_w_l_skin.jpg
```

`pa1904_glessner_john_j_c1900_christine_nelson_portrait.jpg` (T-3481) is cut and scaled from Bohusläns museum's copy of Ossian Berggren's cabinet card of the housemaid Anna Åkerman, 1890-1895 (UMFA53226:1855; source record `bhm_umfa53226_1855_hembitrade_anna_akerman`), a STAND-IN, not Christine Nelson; the museum marks it Public Domain Mark 1.0: **public domain**. The stand-in label is burned on the picture. The crop box is recorded in
`data/humans/variation/portraits/pa1904_glessner_john_j_c1900_christine_nelson.json`. `pa1904_glessner_john_j_c1900_christine_nelson_model.jpg` (and its `.json` sidecar) is
rendered by `tools/portrait_still.mjs` as above, and is **CC0-1.0**.

```text
humans/web/portraits/pa1904_glessner_john_j_c1900_christine_nelson_model.jpg
humans/web/portraits/pa1904_glessner_john_j_c1900_christine_nelson_model.json
humans/web/portraits/pa1904_glessner_john_j_c1900_christine_nelson_portrait.jpg
```

`pa1904_glessner_john_j_c1900_charles_nelson_portrait.jpg` (T-3483) is cut and scaled from Västmanlands läns museum's copy of Ernst Blom's glass negative 'Kusken Kalén' (Vlm-Blom P 157; source record `vlm_blom_p157_kusken_kalen`), a STAND-IN, not Charles Nelson; the museum marks it Public Domain Mark 1.0: **public domain**. The stand-in label is burned on the picture. The crop box is recorded in
`data/humans/variation/portraits/pa1904_glessner_john_j_c1900_charles_nelson.json`. `pa1904_glessner_john_j_c1900_charles_nelson_model.jpg` (and its `.json` sidecar) is
rendered by `tools/portrait_still.mjs` as above, and is **CC0-1.0**.

```text
humans/web/portraits/pa1904_glessner_john_j_c1900_charles_nelson_model.jpg
humans/web/portraits/pa1904_glessner_john_j_c1900_charles_nelson_model.json
humans/web/portraits/pa1904_glessner_john_j_c1900_charles_nelson_portrait.jpg
```

`pa1904_glessner_john_j_c1900_august_billings_portrait.jpg` (T-3484) is cut and scaled from Vänersborgs museum's copy of K & A Vikner's 1903 glass negative 'Nordström, Kusk' (VMVP3391; source record `vbg_vmvp3391_nordstrom_kusk_1903`), a STAND-IN, not August Billings; K-samsök gives Public Domain Mark 1.0 (Europeana's older record says CC BY-SA 4.0; the conflict is recorded in the source record): **public domain**. The stand-in label is burned on the picture. The crop box is recorded in
`data/humans/variation/portraits/pa1904_glessner_john_j_c1900_august_billings.json`. `pa1904_glessner_john_j_c1900_august_billings_model.jpg` (and its `.json` sidecar) is
rendered by `tools/portrait_still.mjs` as above, and is **CC0-1.0**.

```text
humans/web/portraits/pa1904_glessner_john_j_c1900_august_billings_model.jpg
humans/web/portraits/pa1904_glessner_john_j_c1900_august_billings_model.json
humans/web/portraits/pa1904_glessner_john_j_c1900_august_billings_portrait.jpg
### Stand-in portraits for the 1812 garrison's looks — `humans/web/portraits/ref_1812_*.jpg` (T-3491)

Seven period portraits of American men of about 1810-1825 from The Metropolitan Museum of Art,
each marked "Public Domain" under the Met's Open Access policy (isPublicDomain true in the Met
Collection API): **public domain**. Each is scaled to 360x480 from the Met's image. They are shown
on a soldier's card as a stand-in for how a man of his sort looked, never as his likeness
(`data/humans/variation/looks/`, liberty L-1812-garrison-looks-3491).

- `ref_1812_97_39.jpg`: Gilbert Stuart, *Henry Rice*, ca. 1815, accession 97.39 (https://www.metmuseum.org/art/collection/search/12666).
- `ref_1812_81_16.jpg`: John Wesley Jarvis, *Alexander Anderson*, 1815, accession 81.16 (https://www.metmuseum.org/art/collection/search/11240).
- `ref_1812_1993_283.jpg`: Joseph Wood, *Self-portrait*, ca. 1810, accession 1993.283 (https://www.metmuseum.org/art/collection/search/15307).
- `ref_1812_33_73.jpg`: John Wesley Jarvis, *Mr. Cook*, 1810, accession 33.73 (https://www.metmuseum.org/art/collection/search/11244).
- `ref_1812_22_217_1.jpg`: Samuel Lovett Waldo, *Self-portrait*, ca. 1815, accession 22.217.1 (https://www.metmuseum.org/art/collection/search/13105).
- `ref_1812_94_23_3.jpg`: Thomas Sully, *Portrait of the Artist*, 1821, accession 94.23.3 (https://www.metmuseum.org/art/collection/search/12701).
- `ref_1812_36_114.jpg`: Samuel Lovett Waldo, *Henry La Tourette de Groot*, 1825-30, accession 36.114 (https://www.metmuseum.org/art/collection/search/13094).

```text
humans/web/portraits/ref_1812_1993_283.jpg
humans/web/portraits/ref_1812_22_217_1.jpg
humans/web/portraits/ref_1812_33_73.jpg
humans/web/portraits/ref_1812_36_114.jpg
humans/web/portraits/ref_1812_81_16.jpg
humans/web/portraits/ref_1812_94_23_3.jpg
humans/web/portraits/ref_1812_97_39.jpg
```

### Two named men's own portraits — `humans/web/portraits/*_kirkland_1893.jpg` (T-3508)

Two wood engravings from Joseph Kirkland, *The Chicago Massacre of 1812* (Chicago: Dibble, 1893),
as Project Gutenberg eBook #59624 reproduces them (`images/page139.png`, `images/page101.png`):
published 1893 in the United States, **public domain**. Each is set on white and scaled into
360x480; nothing else is changed. They are the men's own likenesses, late in life, and are shown
on their cards as such (`data/residents_1812/households/hh_shabbona_1812.json`,
`hh_robinson_alexander_1812.json`; liberty L-1812-native-cards-3507).

- `shabbona_kirkland_1893.jpg`: "Shaubena in old age. (About 1856.)", Kirkland p. 139.
- `robinson_kirkland_1893.jpg`: "Alexander Robinson (in old age). Chief of the Pottowatomies, Chippewas, and others.", Kirkland p. 101.

```text
humans/web/portraits/robinson_kirkland_1893.jpg
humans/web/portraits/shabbona_kirkland_1893.jpg
```

## Recorded audio and owner-supplied score — T-3532, 2026-11-10

`assets/audio/catalog.json` lists every original by path, creator/source, rights,
SHA-256 and every delivery derivative. `tools/prepare_audio.py` reproduces the web
files; originals are never copied to the published site. The app's Audio library
(`renderers/web/audio/credits.html`) presents the credits and liberties.

| Files | Rights and provenance |
|---|---|
| `audio/originals/1-Border-Ballad.m4a`, `audio/originals/2-Border-Ballad-2.m4a` | Owner-supplied Suno-generated score, assigned to 1835. Owner explicitly authorized use and app distribution in chat on 2026-11-10. No open asset license or archival performance is asserted. |
| `audio/originals/3-Salon-Waltz.m4a`, `audio/originals/5-Elegant-Waltz.m4a` | Same owner authorization; assigned to 1904, retired from playback 2026-11-12 (T-3569) and kept for provenance. |
| `audio/originals/1904-ragtime/Brass-Trolley.mp3`, `audio/originals/1904-ragtime/Main-Street-Trot.mp3`, `audio/originals/1904-ragtime/Nickel-Stroll.mp3`, `audio/originals/1904-ragtime/Patent-Leather.mp3`, `audio/originals/1904-ragtime/Pocket-Change.mp3`, `audio/originals/1904-ragtime/Ragtime-Avenue.mp3`, `audio/originals/1904-ragtime/Sidewalk-Ticker.mp3`, `audio/originals/1904-ragtime/Sunday-Best.mp3`, `audio/originals/1904-ragtime/Tin-Pan-Stroll.mp3`, `audio/originals/1904-ragtime/Trolley-Hop.mp3` | Owner-supplied ragtime (file tags: artist Kevin R Haas, album "Made with Mozart"), the 1904 playlist since 2026-11-12 (T-3569). Owner asked for them in the app in chat that day. No open asset license or archival performance is asserted. |
| `audio/originals/score-v1/23-theme-remembrance.mp3`, `audio/originals/score-v1/30-jaunt-opening-1812.mp3`, `audio/originals/score-v1/30-jaunt-opening-1904.mp3`, `audio/originals/score-v1/31-jaunt-closing-1812.mp3`, `audio/originals/score-v1/31-jaunt-closing-1904.mp3`, `audio/originals/score-v1/40-bed-1812-fort.mp3`, `audio/originals/score-v1/41-bed-1812-mystery.mp3`, `audio/originals/score-v1/42-battle-1-buildup.mp3`, `audio/originals/score-v1/43-battle-2-march.mp3`, `audio/originals/score-v1/44-battle-3-fight.mp3`, `audio/originals/score-v1/45-battle-4-aftermath.mp3`, `audio/originals/score-v1/46-bed-1904-places.mp3`, `audio/originals/score-v1/47-bed-1904-household.mp3`, `audio/originals/score-v1/48-bed-1904-people.mp3`, `audio/originals/score-v1/49-bed-1904-stories.mp3`, `audio/originals/score-v1/50-bed-1904-architecture.mp3`, `audio/originals/score-v1/51-bed-1904-ghosts.mp3`, `audio/originals/score-v1/52-bed-1904-bronze.mp3` | The jaunts' score, set v1 (T-3710): generated for the app on the owner's fal account (ElevenLabs Music; Stable Audio 2.5 inpainting for joins) from the cue plans in `data/music/score.json`, and selected by the owner on 2026-11-20, who asked for it in the jaunts that day. The main theme's phrases are cut from his fixed recording. Instrumental; a modern score in period colours, not an archival performance. No open asset license is asserted. |
| `audio/originals/4-Reel-of-the-Frontier.m4a`, `audio/originals/6-Reel-of-the-Frontier-2.m4a`, `audio/originals/7-Reel-of-the-Frontier-3.m4a` | Same owner authorization; assigned to 1812. Separate collection from 1835, per owner. |
| `audio/originals/475448_7009965-hq.mp3` | o_ciz, Wind(leaves).WAV, https://freesound.org/people/o_ciz/sounds/475448/ — CC0 1.0; HQ preview acquired 2026-11-10. |
| `audio/originals/577323_97550-hq.mp3` | TRP, Waves, gentle lapping, river, water, close, PEI, 2011.wav, https://freesound.org/people/TRP/sounds/577323/ — CC0 1.0; HQ preview acquired 2026-11-10. |
| `audio/originals/442543_5902878-hq.mp3` | BonnyOrbit, Waves on shore from pier of lake maggiore.wav, https://freesound.org/people/BonnyOrbit/sounds/442543/ — CC0 1.0; HQ preview acquired 2026-11-10. |
| `audio/catalog.json` | Project-authored metadata; the source-specific licenses above govern the audio, not the repository's code license. |

CC0 text: https://creativecommons.org/publicdomain/zero/1.0/ . The source pages
identify real-world field recordings. These are acoustic proxies, not Chicago
historical evidence. Environmental derivatives are trimmed, folded to mono,
crossfaded at the loop seam and MP3 encoded. Music Ogg deliveries preserve the
supplied Opus packets; AAC alternatives are transcoded. Owner authorization covers
app distribution; it is not a general permission to redistribute the score as a
standalone sample library. No paid account or purchase was made for this work.


## Audio library expansion — T-3532, 2026-11-10

These files are reviewable recordings, not automatically enabled scene cues.
Individual source descriptions and licence evidence are retained under
`assets/audio/evidence/`; `assets/audio/intake.json` carries placement limits.
Freesound sources are HQ MP3 previews; the SoundBible cricket is a WAV download.

| File | Creator and source | Rights |
|---|---|---|
| `audio/originals/intake/538795_11519060-hq.mp3` | bruno.auzet — https://freesound.org/people/bruno.auzet/sounds/538795/ | CC0-1.0 |
| `audio/originals/intake/53259_177850-hq.mp3` | stomachache — https://freesound.org/people/stomachache/sounds/53259/ | CC0-1.0 |
| `audio/originals/intake/637065_6922646-hq.mp3` | lukewarm_sound — https://freesound.org/people/lukewarm_sound/sounds/637065/ | CC0-1.0 |
| `audio/originals/intake/675230_2524442-hq.mp3` | craigsmith — https://freesound.org/people/craigsmith/sounds/675230/ | CC0-1.0 |
| `audio/originals/intake/272169_3186672-hq.mp3` | dethrok — https://freesound.org/people/dethrok/sounds/272169/ | CC0-1.0 |
| `audio/originals/intake/636070_3320549-hq.mp3` | coalcon — https://freesound.org/people/coalcon/sounds/636070/ | CC0-1.0 |
| `audio/originals/intake/509933_9142988-hq.mp3` | phylobates — https://freesound.org/people/phylobates/sounds/509933/ | CC0-1.0 |
| `audio/originals/intake/571206_97550-hq.mp3` | TRP — https://freesound.org/people/TRP/sounds/571206/ | CC0-1.0 |
| `audio/originals/intake/soundbible-2083.wav` | Lisa Redfern — https://soundbible.com/2083-Crickets-Chirping-At-Night.html | Public domain (source declaration) |
| `audio/originals/intake/640060_5487341-hq.mp3` | SamsterBirdies — https://freesound.org/people/SamsterBirdies/sounds/640060/ | CC0-1.0 |
| `audio/originals/intake/475483_7009965-hq.mp3` | o_ciz — https://freesound.org/people/o_ciz/sounds/475483/ | CC0-1.0 |
| `audio/originals/intake/347036_1708499-hq.mp3` | Kubuzz — https://freesound.org/people/Kubuzz/sounds/347036/ | CC0-1.0 |
| `audio/originals/intake/159498_1177772-hq.mp3` | davilca — https://freesound.org/people/davilca/sounds/159498/ | CC0-1.0 |
| `audio/originals/intake/383725_7146007-hq.mp3` | deleted_user_7146007 — https://freesound.org/people/deleted_user_7146007/sounds/383725/ | CC0-1.0 |
| `audio/originals/intake/118341_1535323-hq.mp3` | Julien_Matthey — https://freesound.org/people/Julien_Matthey/sounds/118341/ | CC0-1.0 |
| `audio/originals/intake/654043_14308672-hq.mp3` | RCSound99 — https://freesound.org/people/RCSound99/sounds/654043/ | CC0-1.0 |
| `audio/originals/intake/91912_1512131-hq.mp3` | Filipe Chagas — https://freesound.org/people/Filipe%20Chagas/sounds/91912/ | CC0-1.0 |

Metadata authored for the project:

```text
audio/intake.json
audio/evidence/musket-outdoors.json
audio/evidence/frog-call.json
audio/evidence/late-summer-katydid.json
audio/evidence/wood-wagon.json
audio/evidence/summer-cicada-proxy.json
audio/evidence/robin-calls.json
audio/evidence/redwing-call.json
audio/evidence/summer-crickets.json
audio/evidence/night-crickets.json
audio/evidence/coyote-distant.json
audio/evidence/horse-snort.json
audio/evidence/horse-whinny.json
audio/evidence/horse-walking.json
audio/evidence/hand-saw.json
audio/evidence/hammer-nail.json
audio/evidence/wood-fire.json
audio/evidence/wood-dock.json
```

Every derivative is covered by its source rights and recorded edit recipe in
`audio/catalog.json`. Public-domain status for Lisa Redfern’s cricket recording
is the source page’s declaration, not a claim that it uses the CC0 instrument.
The Italian cicada is an owner-authorized acoustic proxy; it is not represented
as a named Chicago species. No standalone redistribution right is added to the
owner-supplied music.

Additional recorded building and transport candidates:

| File | Creator and source | Rights |
|---|---|---|
| `audio/originals/intake/651364_4219647-hq.mp3` | dazzamoo — https://freesound.org/people/dazzamoo/sounds/651364/ | CC0-1.0 |
| `audio/originals/intake/125958_981397-hq.mp3` | Ryding — https://freesound.org/people/Ryding/sounds/125958/ | CC0-1.0 |
| `audio/originals/intake/407394_5385809-hq.mp3` | mike_stranks — https://freesound.org/people/mike_stranks/sounds/407394/ | CC0-1.0 |
| `audio/originals/intake/475481_7009965-hq.mp3` | o_ciz — https://freesound.org/people/o_ciz/sounds/475481/ | CC0-1.0 |
| `audio/originals/intake/223153_2792951-hq.mp3` | Yoyodaman234 — https://freesound.org/people/Yoyodaman234/sounds/223153/ | CC0-1.0 |
| `audio/originals/intake/426642_2061858-hq.mp3` | Garuda1982 — https://freesound.org/people/Garuda1982/sounds/426642/ | CC0-1.0 |

Project-authored evidence metadata:

```text
audio/evidence/tavern-walla.json
audio/evidence/wood-door.json
audio/evidence/steam-whistle-proxy.json
audio/evidence/horse-harness.json
audio/evidence/dirt-footstep.json
audio/evidence/church-bell-proxy.json
```


## Prairie Avenue portraits and child body sources (T-3546–T-3548)

Portrait crops retain the identified original image; no generated face is passed off as a photograph. Scan URLs, original SHA-256 and crop coordinates are in `docs/RESEARCH/prairie-portraits-3546/portraits.json`. Model JPEGs and their receipts are original project CC0-1.0 renders; these grant no historical attestation.

| Asset | Rights and source |
| --- | --- |
| `humans/web/portraits/pa1904_pike_eugene_s_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 58; original caption/signature checked. |
| `humans/web/portraits/pa1904_pike_eugene_s_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_pike_eugene_s_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_buckingham_e_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 103; original caption/signature checked. |
| `humans/web/portraits/pa1904_buckingham_e_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_buckingham_e_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_lowden_frank_orren_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 173; original caption/signature checked. |
| `humans/web/portraits/pa1904_lowden_frank_orren_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_lowden_frank_orren_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_shortall_john_g_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 191; original caption/signature checked. |
| `humans/web/portraits/pa1904_shortall_john_g_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_shortall_john_g_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_shipman_daniel_b_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 278; original caption/signature checked. |
| `humans/web/portraits/pa1904_shipman_daniel_b_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_shipman_daniel_b_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_mckinlock_george_a_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 283; original caption/signature checked. |
| `humans/web/portraits/pa1904_mckinlock_george_a_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_mckinlock_george_a_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_otis_f_r_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 464; original caption/signature checked. |
| `humans/web/portraits/pa1904_otis_f_r_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_otis_f_r_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_walker_henry_h_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 470; original caption/signature checked. |
| `humans/web/portraits/pa1904_walker_henry_h_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_walker_henry_h_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_gorton_frank_s_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 134; original caption/signature checked. |
| `humans/web/portraits/pa1904_gorton_frank_s_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_gorton_frank_s_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_young_lawrence_a_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 203; original caption/signature checked. |
| `humans/web/portraits/pa1904_young_lawrence_a_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_young_lawrence_a_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_field_marshall_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 353; original caption/signature checked. |
| `humans/web/portraits/pa1904_field_marshall_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_field_marshall_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_clark_john_m_portrait.jpg` | US public-domain printed portrait; `data/sources/witherspoon_men_of_illinois_1902.json`, 474; original caption/signature checked. |
| `humans/web/portraits/pa1904_clark_john_m_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_clark_john_m_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_kimball_william_w_portrait.jpg` | US public-domain printed portrait; `data/sources/hall_successful_men_1896.json`, plate facing p. 461; original caption/signature checked. |
| `humans/web/portraits/pa1904_kimball_william_w_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_kimball_william_w_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_keith_elbridge_g_portrait.jpg` | US public-domain printed portrait; `data/sources/glessner_commercial_club_1910_keith_plate.json`, p. 77, lower right; original caption/signature checked. |
| `humans/web/portraits/pa1904_keith_elbridge_g_model.jpg` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `humans/web/portraits/pa1904_keith_elbridge_g_model.json` | Original CC0-1.0 project render/receipt from the named portrait fit; colours and unseen form reconstructed. |
| `authored/humans/makehuman_hm08/SOURCE-prairie.json` | Original CC0-1.0 engineering derivative/recipe/provenance of existing pinned MakeHuman graphical targets. Equal software shape categories do not imply ancestry; no new upstream code or graphics copied. |
| `authored/humans/makehuman_hm08/teen_male_15.recipe.json` | Original CC0-1.0 engineering derivative/recipe/provenance of existing pinned MakeHuman graphical targets. Equal software shape categories do not imply ancestry; no new upstream code or graphics copied. |
| `authored/humans/makehuman_hm08/prepared_teen_male_15.json` | Original CC0-1.0 engineering derivative/recipe/provenance of existing pinned MakeHuman graphical targets. Equal software shape categories do not imply ancestry; no new upstream code or graphics copied. |
| `authored/humans/makehuman_hm08/prepared_teen_male_15.report.json` | Original CC0-1.0 engineering derivative/recipe/provenance of existing pinned MakeHuman graphical targets. Equal software shape categories do not imply ancestry; no new upstream code or graphics copied. |
| `authored/humans/makehuman_hm08/teen_female_15.recipe.json` | Original CC0-1.0 engineering derivative/recipe/provenance of existing pinned MakeHuman graphical targets. Equal software shape categories do not imply ancestry; no new upstream code or graphics copied. |
| `authored/humans/makehuman_hm08/prepared_teen_female_15.json` | Original CC0-1.0 engineering derivative/recipe/provenance of existing pinned MakeHuman graphical targets. Equal software shape categories do not imply ancestry; no new upstream code or graphics copied. |
| `authored/humans/makehuman_hm08/prepared_teen_female_15.report.json` | Original CC0-1.0 engineering derivative/recipe/provenance of existing pinned MakeHuman graphical targets. Equal software shape categories do not imply ancestry; no new upstream code or graphics copied. |

| `humans/web/portraits/pa1904_pullman_mrs_george_m_portrait.jpg` | Public domain: Harris & Ewing, 1908, US copyright registration H105262, LOC 90710921; term expired. Wikimedia Commons copy of LOC image cph.3c01380. | Face crop; later than the scene. |
| `humans/web/portraits/pa1904_pullman_mrs_george_m_model.jpg` and `humans/web/portraits/pa1904_pullman_mrs_george_m_model.json` | Original project CC0-1.0 rendering and receipt. | Reconstructed 1904 appearance fitted to the 1908 photograph. |

| `humans/web/portraits/pa1904_meeker_mrs_arthur_portrait.jpg` | Public domain: Chicago Sunday Tribune, 3 March 1907, Part 7, p. 4; MSU Libraries item 9696. Exact source crop in the portrait ledger; caption visually checked. |
| `humans/web/portraits/pa1904_meeker_mrs_arthur_model.jpg` | Original project CC0-1.0 render/receipt. Single-view face fit; colour, unseen form and exact grooming reconstructed. |
| `humans/web/portraits/pa1904_meeker_mrs_arthur_model.json` | Original project CC0-1.0 render/receipt. Single-view face fit; colour, unseen form and exact grooming reconstructed. |

| `humans/web/portraits/pa1904_field_mrs_marshall_jr_portrait.jpg` | Public domain: Chicago Sunday Tribune, 3 March 1907, Part 7, p. 4; MSU Libraries item 9696. Exact source crop in the portrait ledger; caption visually checked. |
| `humans/web/portraits/pa1904_field_mrs_marshall_jr_model.jpg` | Original project CC0-1.0 render/receipt. Single-view face fit; colour, unseen form and exact grooming reconstructed. |
| `humans/web/portraits/pa1904_field_mrs_marshall_jr_model.json` | Original project CC0-1.0 render/receipt. Single-view face fit; colour, unseen form and exact grooming reconstructed. |

## Prairie Avenue child and teen exports (T-3550)

| Asset | Provenance and license |
|---|---|
| `humans/child_boy_1904.lod0.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/child_boy_1904.lod1.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/child_boy_1904.lod2.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/child_boy_1904.lod3.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_boy_1904.lod0.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_boy_1904.lod1.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_boy_1904.lod2.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_boy_1904.lod3.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/child_girl_1904.lod0.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/child_girl_1904.lod1.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/child_girl_1904.lod2.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/child_girl_1904.lod3.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_girl_1904.lod0.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_girl_1904.lod1.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_girl_1904.lod2.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_girl_1904.lod3.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/child_toddler_1904.lod0.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/child_toddler_1904.lod1.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/child_toddler_1904.lod2.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/child_toddler_1904.lod3.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_toddler_1904.lod0.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_toddler_1904.lod1.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_toddler_1904.lod2.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/child_toddler_1904.lod3.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/teen_boy_1904.lod0.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/teen_boy_1904.lod1.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/teen_boy_1904.lod2.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/teen_boy_1904.lod3.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/teen_boy_1904.lod0.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/teen_boy_1904.lod1.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/teen_boy_1904.lod2.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/teen_boy_1904.lod3.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/teen_girl_1904.lod0.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/teen_girl_1904.lod1.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/teen_girl_1904.lod2.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/teen_girl_1904.lod3.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/teen_girl_1904.lod0.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/teen_girl_1904.lod1.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/teen_girl_1904.lod2.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |
| `humans/web/teen_girl_1904.lod3.glb` | CC0-1.0: original 1904 child/teen clothing generated by `tools/human_child_1904.py`, pinned MakeHuman body, Toigo skin and short04 hair under their existing cleared source notices; canonical run 42997832738. Reconstructed, not an archival likeness. First-role owner admission: `data/humans/role_reviews/prairie_children_1904.json`. |

Owner-selected calmer river recording (T-3544, 2026-11-11):

| File | Creator and source | Rights |
|---|---|---|
| `audio/originals/575244_97550-hq.mp3` | TRP — water on rocks, calm, manitoulin.mp3 — https://freesound.org/people/TRP/sounds/575244/ | CC0-1.0; HQ MP3 preview, not original download. |

`audio/evidence/calm-river-water.json` is project-authored acquisition/license and owner-selection metadata. Source SHA-256 `8ab476464f7d1280514f6a405988550f423b572e9fe3900b29b776cfba77ab48`; the accepted `renderers/web/audio/river.mp3` derivative is `6831b7ad102ec023194c4040776c5245b6cb47451d652a94a07dc742e28362af`. The exact 22-second mono loop was selected as “Light water on rocks”; its crop and seam recipe are in the generated catalogue. The modern rocky-lake recording is a reconstructed river proxy. The previous TRP577323 source and its CC0 derivative remain under `river-held.mp3`, disabled in scenes; no existing rights are withdrawn.


1812 seasonal audio and generated work kit (T-3551,2026-11-11):

| Asset | Rights and provenance |
|---|---|
| `props/work_1812.glb` | CC0-1.0 original project geometry generated from `data/humans/work_1812.json` by `tools/generate_work_1812.py`. A reconstructed wooden packing chest/support and hand hammer, not an archival artifact scan. No third-party textures. |

The six 1812 nature placements, two short dirt-hoof transients and hammer cue reuse the existing cleared recordings and immutable delivery bytes listed above. No newly downloaded audio or new audio license is asserted. Runtime crops/filtering retain the CC 0 source attribution; the snow treatment is a processed dirt-road recording. `data/sources/illinois_dnr_american_robin.json` is a textual ecological citation only; no Illinois DNR photograph or map is copied into an asset. Existing held recordings retain their licensing and review status.

## V20 plate-matched Brougham (T-3558)

`renderers/web/transport/parked-brougham/{brougham-v20-near.glb,brougham-v20-mid.glb,brougham-v20-far.glb,brougham-v20.json}`: original GPL-3.0-or-later project geometry derived by `tools/transport/brougham_v20/{produce.py,simplify_far.mjs,far-lods.json,discrepancies.json,check.py}` from the V19 masters above. Near SHA256 `34c14f142cadce1d89fc5ccb43a7d195ae287ab18258e9b1a8463e294e6ec2b7` (46,796 triangles), mid `69e3f8bfff45b03d5eb7e267de0d20dd6c8ea3ccadbc976c01e33d6dc5f4004d` (23,660), far `e0eda0a61eeb6e585282fcc913c04eb8a9b468bc847d513b79f6be3f37383748` (11,360). Every V19 part is carried over byte for byte except the four post/support beams and two rear mudguards it removes and the cab it lowers (below); it adds an original closed driving box, dash, iron rail and stays and swept box irons, drawn after the cleared public-domain 1893 Studebaker catalogue plate leaf 0095 (source `studebaker_1893_illustrated_souvenir`). Inside, the passengers' cushion, bench base and floor are lowered, the squab lengthened down to them, and the body's lower rear quarter brought down with them (T-3553), so a passenger sits upright under the roof. The far level's two body shells are simplified with meshoptimizer 1.2.0 (MIT, build tool only; no code shipped). No plate pixels, textures or outside geometry are embedded. Specimen, owner, dimensions and hidden construction remain reconstructed.


### The 1871 city context kit — data/context/1871/

The portable asset `data/context/1871/kit.glb` and its `kit.json` record are generated by `generators/city_context_emit.py` from `data/context/1871/kit-recipe.json`. Original procedural building geometry, three generic deciduous canopy forms and embedded base-colour, normal and ORM maps are covered by the project's license; no third-party image pixels are embedded or sampled. Ruger's 1868 public-domain panorama (`ruger_1868_chicago_panorama`) bounds generic form families only. The trees claim no identified species or observed leaf colour on that day. Every dimension, facade and colour is reconstructed and retains `_CONFIDENCE=1.0`. The recipe, generator-input SHA-256, GLB SHA-256, byte size, template node names and triangle inventories travel in `kit.json`. `python3 generators/city_context_emit.py --check` requires registered cleared sources, reconstructs both outputs and refuses any byte mismatch. These data-subtree assets are published with the context JSON and are not structure master/web derivatives.

The city field and infrastructure are generated by `generators/city_1871_emit.py` from the explicitly graded map interpretation in `data/context/1871/plan.json`. The geometry and procedural surface colours are original project work. The 1869 ward map and 1870 Mitchell map are public-domain geographic references; their raster pixels are not embedded in the generated meshes. Terrain masters live in `assets/gltf/`, their published derivatives in `assets/web/`; portable infrastructure is under `data/context/1871/`. `generated-assets.json` records each output's digest and size. `python3 generators/city_1871_emit.py --check` rebuilds and checks the bytes. See L-1871-city-baseline for reconstruction limits.

The research raster `../pre_fire_v1/maps/images/1869_usace_chicago_harbor.jpg` is the public-domain U.S. Army Engineers August 1869 harbor sheet, preserved from NARA NAID 86744439 via Wikimedia Commons. Its catalog title differs from the date printed on the sheet; the source record `usace_chicago_harbor_august_1869` retains that discrepancy. The original raster and manually read relative traces are research evidence, with absolute scene placement unresolved. Modern street-control primitives under `data/traces/gcp/mitchell_1870_*` credit OpenStreetMap contributors under ODbL 1.0; they establish control targets only, not historic street identity.


## Sixteen-face photographic pilot (T-3746)

`assets/authored/humans/photo_face_pilot/sources.png` is original project-generated imagery, created for the owner's explicit sixteen-face request on 25 November 2026. All subjects are fictional adults. The generated output is used under the image-generation service's output terms for this project; it is not a scraped face dataset and no archival likeness is asserted. Source `synthetic_photo_face_pilot_2026` records the generation, original SHA-256, rights basis and limits. The original output is preserved unchanged.

`assets/humans/web/photo_faces/pilot/` (all `pilot_*_source.jpg`, `faces_full.jpg`, `faces_light.jpg`, `hair_full.png`, `hair_light.png`, `hair_shell_full.glb`, `hair_shell_light.glb`, `review.json`, and `recipe.json`) is generated by `python3 tools/photo_face_library.py --batch data/humans/variation/photo_face_pilot.json --output assets/humans/web/photo_faces/pilot`. Its source previews are crops of that sheet. Face patches combine those pixels with the existing CC0 MakeHuman skin for unseen areas (the MakeHuman/Toigo skin entries above and the library's pinned SOURCE.json retain their attribution). Landmark-fitted proportions use the existing CC0 hm08 morph kit and its correspondence table. The two small unit scalp GLBs are original procedural project geometry from the same command, transformed by source-bounded JSON dimensions and bound to the existing head joint; they carry no new third-party mesh or rig. No archival or living person's photo is included. The review is graded reconstructed and assigns no resident.


`assets/humans/web/photo_faces/pilot/*`: photo-face pilot derivatives and original procedural scalp meshes (T-3746), generated by `tools/photo_face_library.py` from the preserved project-generated fictional source sheet and the existing CC0 MakeHuman/Toigo skin, with their source attribution retained in the section above. Project code/geometry uses the repository license; source pixels are authorized project-generated output. No archival likeness or historical identity is claimed.


Photo pilot file inventory (same project-generated/CC0 provenance and rights as above):

```text
humans/web/photo_faces/pilot/faces_full.jpg
humans/web/photo_faces/pilot/faces_light.jpg
humans/web/photo_faces/pilot/hair_full.png
humans/web/photo_faces/pilot/hair_light.png
humans/web/photo_faces/pilot/hair_shell_full.glb
humans/web/photo_faces/pilot/hair_shell_light.glb
humans/web/photo_faces/pilot/pilot_01_source.jpg
humans/web/photo_faces/pilot/pilot_02_source.jpg
humans/web/photo_faces/pilot/pilot_03_source.jpg
humans/web/photo_faces/pilot/pilot_04_source.jpg
humans/web/photo_faces/pilot/pilot_05_source.jpg
humans/web/photo_faces/pilot/pilot_06_source.jpg
humans/web/photo_faces/pilot/pilot_07_source.jpg
humans/web/photo_faces/pilot/pilot_08_source.jpg
humans/web/photo_faces/pilot/pilot_09_source.jpg
humans/web/photo_faces/pilot/pilot_10_source.jpg
humans/web/photo_faces/pilot/pilot_11_source.jpg
humans/web/photo_faces/pilot/pilot_12_source.jpg
humans/web/photo_faces/pilot/pilot_13_source.jpg
humans/web/photo_faces/pilot/pilot_14_source.jpg
humans/web/photo_faces/pilot/pilot_15_source.jpg
humans/web/photo_faces/pilot/pilot_16_source.jpg
humans/web/photo_faces/pilot/recipe.json
humans/web/photo_faces/pilot/review.json
```
