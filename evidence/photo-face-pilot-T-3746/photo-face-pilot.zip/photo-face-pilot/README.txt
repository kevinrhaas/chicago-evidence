PHOTO FACE PILOT — T-3746

These are sixteen fictional adults generated as photographic source images.
The heads shown in the review are the real portable meshes and renderer, not
retouched screenshots. No resident assignments are changed by this page.

OPEN THE REVIEW
1. Extract this ZIP.
2. In the photo-face-pilot folder run:
   python3 -m http.server 3000
3. Open http://localhost:3000/tools/photo_face_review.html in your browser.

Light is the default. Choose Full for close inspection. Select a source, use
Front / Three-quarter / Profile, or show All faces. On your own PC, click
Measure on this PC, then Save measurement. That downloaded JSON records your
renderer, viewport, frame intervals, submission time, draw calls and atlas bytes.
A browser with WebGL2 is required. Internet is not needed for the review assets.

BUDGET
The town opt-in uses one shared 512-square face atlas: 1.33 MiB with mipmaps.
This review also shows a prototype photographed-hair surface: Light adds two
shared 512-square atlases (2.67 MiB total), Full two 1024-square atlases
(10.67 MiB total). These bounds exclude existing bodies, textures, driver
overhead and page images. They are not a whole-scene memory measurement.

WHAT TO CHECK
The eye pilot retains iris detail, reduces corneal glare, measures sclera tone,
fits iris positions and sizes, and matches resting lid aperture to the source.
The review deliberately exposes the rendered result beside its source.
Profile depth and unseen hair are inferred from the existing head and hair
priors. The hair proposal still needs visual review. These are not historical
likenesses or an automatic approval for population-wide rollout.

The included software measurement used SwiftShader, not a hardware GPU.
Low-end-PC and complete-town hardware performance remain unverified.

ADDING A PERSON'S PHOTO
Use tools/photo_face_library.py in the source code branch below. Register the
original photograph's source and texture rights first. The single-photo
command fits the head, maps the face, and produces this same review format.
The repository documentation contains the command and dependency setup.
The importer is in the source repository; this ZIP is a portable viewer.

Code: https://github.com/kevinrhaas/chicago/tree/steward/t3746-photo-face-pilot-16/chicago/4d
Guide: docs/PHOTO-FACE-PILOT.md
Credits and inherited human/vendor licences: assets/LICENSES.md and vendor files.
