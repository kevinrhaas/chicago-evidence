/**
 * Confidence view (SCR 07): show, hide, colour and opacity per grade (§09).
 *
 * A Navigator app (T-2618): see js/nav-rail.js for the fields. Its lane owns this file.
 */
export default {
  id: 'confidence',
  label: 'Confidence view',
  railLabel: 'Confidence',
  code: 'SCR 07 · CONFIDENCE VIEW',
  order: 50,
  icon: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m12 3 9 4.5-9 4.5-9-4.5z"/><path d="m3 12 9 4.5 9-4.5"/><path d="m3 16.5 9 4.5 9-4.5"/></svg>',
  // The icon glows while the Confidence view is on.
  glow: (ctx) => !!ctx.confidenceOn,
  // The presets, the grade rows and the readout (T-2647), loaded on first open (§14).
  load: () => import('./confidence-view.js'),
};
