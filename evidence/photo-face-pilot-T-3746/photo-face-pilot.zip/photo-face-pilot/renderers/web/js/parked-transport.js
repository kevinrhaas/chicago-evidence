// SPDX-License-Identifier: GPL-3.0-or-later
/** Parked authored vehicles, with the old yard vehicle retained as a light/far fallback.
 * Models are type reconstructions; neither a manufacturer's replica nor an owner is implied.
 * The GLB remains authoritative. Only its parking articulation and world placement change.
 */
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { disposeLoadedAsset } from './scene-loader.js';

/** T-3542: every tier draws the parked teams and vehicles. Light (a phone's) draws them
 * nearer, never not at all: horses and carriages are the town's core (owner, 2026-11-10). */
const REACH = { full: 100, balanced: 65, light: 50 };
const draws = t => (REACH[t] ?? 0) > 0;

/** T-3300: with `loadWithin` set, a vehicle's GLB is fetched only once the camera
 * comes within its tier's REACH plus that many metres, not at boot. The 1835 boot
 * fetched all three wagon models (2.0 MB on the wire) for stands 204-307 m from
 * where a first visitor stands, every one beyond the 100 m it is drawn within. The
 * yard's own legacy vehicle keeps the stand until the parked model arrives — the
 * same fallback a failed load and the Light tier already use. Unset, every row
 * still loads at creation, as the Brougham LOD gate expects.
 */
const horizontalDistance = (camera, row) => Math.hypot(
  camera.position.x - row.at_local_enu_m[0], -camera.position.z - row.at_local_enu_m[1]);
const yawOf = (bearing) => Math.PI - bearing * Math.PI / 180;

/** Candidate wheel-ring screen-size estimate, not visual/photographic acceptance.
 * Keep the reviewed near geometry within 24 m; increase that distance for a
 * larger actual drawing buffer or narrower field of view. THREE.LOD itself
 * accounts for camera zoom. The 2.5 m reserve covers the changed wheel envelope.
 */
function broughamMidDistance(camera, drawingBufferHeight) {
  if (!camera.isPerspectiveCamera || !Number.isFinite(camera.fov)
    || camera.fov <= 0 || camera.fov >= 180 || !Number.isFinite(drawingBufferHeight)
    || drawingBufferHeight <= 0) return Number.MAX_VALUE;
  const wheelChord = 0.65 * (1 - Math.cos(Math.PI / 16));
  const focalPixels = drawingBufferHeight / (2 * Math.tan(camera.fov * Math.PI / 360));
  return Math.max(24, 2.5 + focalPixels * wheelChord / 0.5);
}


/** Own this Brougham's complete body read before parsing. The native plate
 * helper uses this same path; the observed mobile FileLoader request was
 * canceled before readiness despite a decoded model. Keep manager abort/error
 * accounting, and resolve embedded relative resources from the asset directory.
 */
async function loadBrougham(file, expectedHash = null) {
  const loader = new GLTFLoader(), manager = loader.manager;
  const assetUrl = new URL(file, new URL('../', import.meta.url));
  const requestUrl = manager.resolveURL(assetUrl.href);
  manager.itemStart(requestUrl);
  try {
    const response = await fetch(requestUrl, {
      headers: loader.requestHeader,
      credentials: loader.withCredentials ? 'include' : 'same-origin',
      signal: manager.abortController.signal,
    });
    if (!response.ok) throw Error(`Brougham HTTP ${response.status}`);
    const bytes = await response.arrayBuffer();
    let actualHash = null;
    if (expectedHash) {
      actualHash = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))]
        .map(n => n.toString(16).padStart(2, '0')).join('');
    }
    const asset = await loader.parseAsync(bytes, new URL('.', assetUrl).href);
    if (actualHash) asset.parkedDeliverySha256 = actualHash;
    return asset;
  } catch (error) {
    manager.itemError(requestUrl);
    throw error;
  } finally { manager.itemEnd(requestUrl); }
}

function card(row, manifest, team = null) {
  return { id: row.id, sidecar: {
    name: row.name, phase: null,
    ...(row.model === 'studebaker_brougham_1893' ? { change_note: 'This is a reconstructed, empty parked example based on the 1893 Studebaker Brougham catalogue design. This individual carriage, its ownership and its presence at this stop in 1904 are not attested.' } : {}),
    placement: { symbolic_location: row.location, position_confidence: 'reconstructed',
      position_sources: row.source_ids, position_note: row.note },
    attributes: {
      vehicle_type: { value: manifest.type, confidence: 'reconstructed', sources: [], note: manifest.basis },
      maker: { value: manifest.design_reference ? 'Reconstructed individual; no attested specimen' : 'Unidentified; type reconstruction', confidence: 'reconstructed', sources: [],
        note: manifest.design_reference ? 'The catalogue design is identified separately; this parked individual and its ownership are reconstructed.' : 'This model is not identified as a particular manufacturer or catalog model.' },
      ...(manifest.design_reference ? { design_reference: manifest.design_reference } : {}),
      parked: { value: team ? 'Unoccupied, with a pair of horses in harness' : 'Unoccupied and unhitched', confidence: 'reconstructed', sources: [],
        note: team ? 'A reconstructed stationary team. No seated coachman, passengers or boarding is enabled; no household ownership is attested.'
          : 'A parked example, without a driver, passengers or a claim of ownership.' },
    },
    citations: row.source_ids.map(source_id => ({ source_id })),
    research_note: `${manifest.basis} ${row.note} Liberties: ${row.liberty}${team ? `; ${row.stationary_team.liberty}` : ''}.`,
  } };
}

/** Merge only static meshes sharing the SAME material, after the parking pose.
 * This preserves their GLB vertex normals/UVs/maps while avoiding a draw per hardware part.
 */
function staticBatches(root, confidence, excluded = null) {
  root.updateMatrixWorld(true);
  const local = root.matrixWorld.clone().invert();
  const byMaterial = new Map();
  root.traverse(node => {
    if (!node.isMesh) return;
    for (let p = node; p; p = p.parent) if (p === excluded) return;
    if (node.isSkinnedMesh || Array.isArray(node.material)) throw Error('Expected rigid single-material primitives');
    const geometry = node.geometry.clone().applyMatrix4(local.clone().multiply(node.matrixWorld));
    const list = byMaterial.get(node.material) ?? [];
    list.push(geometry); byMaterial.set(node.material, list);
  });
  const group = new THREE.Group();
  try {
    for (const [material, pieces] of byMaterial) {
      const geometry = mergeGeometries(pieces, false);
      if (!geometry) throw Error('Incompatible authored mesh streams');
      geometry.setAttribute('_confidence', new THREE.Float32BufferAttribute(
        new Float32Array(geometry.getAttribute('position').count).fill(1), 1));
      confidence?.patch(material);
      const mesh = new THREE.Mesh(geometry, material);
      mesh.userData.parkedBatchGeometry = true;
      mesh.castShadow = true; mesh.receiveShadow = true;
      group.add(mesh);
    }
  } catch (error) {
    group.traverse(n => n.geometry?.dispose());
    throw error;
  } finally {
    for (const pieces of byMaterial.values()) for (const geometry of pieces) geometry.dispose();
  }
  return group;
}

/** T-3558: one model's seeded paint over a shared photographic master. The factors
 * multiply the master's own maps (grain, wear and ironwork read through), body meshes
 * by `paint.body`, every other mesh by `paint.gear`, per source material name. Painted
 * materials are cached per model so its batches still merge by material. */
function paintVehicle(root, model, paint, paintedMaterials) {
  const body = new Set(paint.body_meshes ?? []);
  root.traverse(node => {
    if (!node.isMesh || Array.isArray(node.material)) return;
    const part = body.has(node.name) ? 'body' : 'gear';
    const factor = paint[part]?.[node.material.name];
    if (!factor) return;
    const key = `${model}:${part}:${node.material.uuid}`;
    let material = paintedMaterials.get(key);
    if (!material) {
      material = node.material.clone();
      material.color.setRGB(factor[0], factor[1], factor[2]);
      material.userData = { ...material.userData, parkedPaint: part };
      paintedMaterials.set(key, material);
    }
    node.material = material;
  });
}

/** Solve the lowest actual tongue vertex against this stand's terrain, not its centerline.
 * A failed bracket keeps the legacy wagon; it never silently buries the pole.
 */
function parkTongue(root, row, terrain, base) {
  const tongue = root.getObjectByName('vehicle_tongue');
  if (!tongue) return null;
  const yaw = yawOf(row.bearing_deg), sin = Math.sin(yaw), cos = Math.cos(yaw);
  const p = new THREE.Vector3();
  const clearance = angle => {
    tongue.rotation.x = angle; root.updateMatrixWorld(true);
    let minimum = Infinity;
    tongue.traverse(node => {
      const pos = node.geometry?.getAttribute('position');
      if (!pos) return;
      for (let i = 0; i < pos.count; i++) {
        p.fromBufferAttribute(pos, i).applyMatrix4(node.matrixWorld);
        const e = row.at_local_enu_m[0] + cos * p.x + sin * p.z;
        const n = row.at_local_enu_m[1] - (-sin * p.x + cos * p.z);
        const ground = terrain.surfaceHeight(e, n);
        if (!Number.isFinite(ground)) throw Error('No terrain under parked tongue');
        minimum = Math.min(minimum, base + p.y - ground);
      }
    });
    return minimum;
  };
  let low = 0, high = Math.PI / 4;
  if (clearance(low) < 0 || clearance(high) > 0) throw Error('Parked tongue has no ground-contact bracket');
  for (let i = 0; i < 25; i++) {
    const middle = (low + high) / 2;
    if (clearance(middle) >= 0) low = middle; else high = middle;
  }
  const gap = clearance(low);
  return { angle_rad: low, minimum_clearance_m: gap };
}

export async function createParkedTransport({ dataBase, sceneId, terrain, confidence,
  detail = 'full', problems = [], hostMissing = () => false, groundHeight = null,
  getDrawingBufferHeight = () => null, loadWithin = null, stationaryTeams = false } = {}) {
  const group = new THREE.Group(); group.name = 'parked-transport';
  const instances = [], assets = new Map(), replacementIds = new Set(), paintedMaterials = new Map();
  // T-3558: yard vehicles no row replaces and the record retires (`retired_yard_wagons`).
  // The yard layer reads this set and never builds them (main.js passes it beside
  // `replacementIds`), so no tier, setting, reach or far merge can draw one.
  const retiredIds = new Set();
  let tier = detail, fallback = () => {}, lastCamera = null, disposed = false, loading = null;
  // T-3439: Settings › Show › Carriages and horses. Hidden, no vehicle (nor the yard's old
  // stand-in it replaces) is drawn, fetched or picked.
  let shown = true;
  // T-3557: parked vehicles another layer stands in for (the Glessner brougham while its driven
  // twin is out, town-transport-scene.js): not drawn, picked or animated until given back.
  const standIns = new Set();
  const ray = new THREE.Raycaster();
  const deferred = Number.isFinite(loadWithin) && loadWithin >= 0;
  const requested = new Set(), finished = new Set();
  const out = { group, instances, replacementIds, retiredIds, records: [], requested,
    // Vehicles asked for and not yet placed (or refused): a scripted view waits on 0.
    get pending() { return requested.size - finished.size + instances.filter(i => i.teamPending).length; },
    async ready() {
      // A hide/show revision can retire a pending team and schedule its
      // replacement in that promise's continuation. Drain until stable rather
      // than reporting ready after only the original snapshot settles.
      while (!disposed) {
        const currentLoading = loading;
        await Promise.all([currentLoading, ...instances.map(i => i.teamPending)]);
        if (disposed || (loading === currentLoading && !instances.some(i => i.teamPending))) return;
      }
    },
    setFallback(callback) { fallback = callback; },
    /** T-3557: hide (`shown` false) or give back one parked vehicle, its team and its pick. */
    setStandIn(id, shownAgain) {
      const had = standIns.has(id);
      if (shownAgain === false) standIns.add(id); else standIns.delete(id);
      const instance = instances.find(i => i.row.id === id);
      if (instance && shownAgain === false) instance.group.visible = false;
      if (had && shownAgain !== false && lastCamera) out.update(lastCamera);
      return !!instance;
    },
    isStoodIn: id => standIns.has(id),
    /** T-3557: a parked vehicle's stand: its root (ENU), bearing, rendered base and whether its team is up. */
    standOf(id) {
      const instance = instances.find(i => i.row.id === id);
      const row = instance?.row ?? rows.find(r => r.id === id);
      if (!row) return null;
      return { id, at_local_enu_m: [...row.at_local_enu_m], bearing_deg: row.bearing_deg,
        base_m: instance ? instance.group.position.y : null, team: !!instance?.team, loaded: !!instance };
    },
    get shown() { return shown; },
    setShown(on) {
      shown = on !== false;
      group.visible = shown;
      if (!shown) for (const instance of instances) {
        instance.teamRevision++; instance.team?.dispose(); instance.team = null;
        instance.static_support = instance.original_unhitched_static_support ?? instance.static_support;
        instance.card = card(instance.row, instance.spec);
      }
      // Shown again: every stand-in back, then each vehicle in reach takes its place again.
      for (const id of replacementIds) fallback(id, !shown);
      if (shown && lastCamera) out.update(lastCamera);
      return shown;
    },
    update(camera, dt = 0, { paused = false, reducedMotion = false } = {}) {
      if (disposed) return;
      lastCamera = camera;
      if (!shown) return;
      if (deferred && (REACH[tier] ?? REACH.full) > 0) {
        const within = (REACH[tier] ?? REACH.full) + loadWithin;
        void load(row => horizontalDistance(camera, row) < within);
      }
      for (const instance of instances) {
        const visible = (REACH[tier] ?? REACH.full) > 0 && !standIns.has(instance.row.id)
          && camera.position.distanceTo(instance.group.position) < REACH[tier];
        instance.group.visible = visible;
        if (instance.team && horizontalDistance(camera, instance.row) > (REACH[tier] ?? 0) + (loadWithin ?? 0)) {
          instance.teamRevision++; instance.team.dispose(); instance.team = null;
          instance.card = card(instance.row, instance.spec);
          instance.static_support = instance.original_unhitched_static_support ?? instance.static_support;
        }
        if (visible && !instance.team && !confidence?.hidden?.reconstructed) void ensureTeam(instance);
        if (instance.team) {
          try { instance.team.update(dt, { paused, reducedMotion,
            visible: visible && !confidence?.hidden?.reconstructed,
            shadows: tier === 'full' && camera.position.distanceTo(instance.group.position) < 30 }); }
          catch (error) {
            instance.team.dispose(); instance.team = null;
            instance.static_support = instance.original_unhitched_static_support ?? instance.static_support;
            instance.card = card(instance.row, instance.spec);
            problems.push(`parked transport ${instance.row.id} team: ${error.message}; unoccupied carriage retained`);
          }
        }
        if (instance.lod) {
          camera.updateWorldMatrix(true, false);
          instance.lod.updateWorldMatrix(true, false);
          instance.lod.levels[1].distance = broughamMidDistance(camera, getDrawingBufferHeight());
          instance.lod.update(camera);
          instance.active_lod = instance.lod.getCurrentLevel() === 0 ? 'near' : 'mid';
          instance.active_triangles = instance.active_lod === 'near' ? 45338 : 23062;
        }
        if (instance.row.replaces) fallback(instance.row.replaces, !visible);
      }
    },
    async setTier(next) {
      tier = next;
      if (!draws(next)) for (const instance of instances) {
        instance.teamRevision++; instance.team?.dispose(); instance.team = null;
        instance.static_support = instance.original_unhitched_static_support ?? instance.static_support;
        instance.card = card(instance.row, instance.spec);
      }
      if (draws(next) && !deferred) await load();
      if (draws(next)) await Promise.all(instances.map(ensureTeam));
      if (lastCamera) out.update(lastCamera);
    },
    pickAt(ndc, camera) {
      if (disposed || confidence?.hidden?.reconstructed) return null;
      for (let ancestor = group; ancestor; ancestor = ancestor.parent) if (!ancestor.visible) return null;
      ray.setFromCamera(ndc ?? new THREE.Vector2(), camera);
      const roots = instances.filter(i => i.group.visible).flatMap(i =>
        // Recursive raycasting visits invisible LOD children too. Start at ONLY
        // the committed active level, preserving the common parked card owner.
        i.lod ? [i.lod.levels[i.lod.getCurrentLevel()].object, ...(i.team?.pickRoots ?? [])] : [i.group]);
      const meshes = [];
      for (const root of roots) root.traverse(node => {
        if (!node.isMesh) return;
        for (let p = node; p; p = p.parent) if (!p.visible) return;
        meshes.push(node);
      });
      const hit = ray.intersectObjects(meshes, false)[0];
      if (!hit) return null;
      let owner = hit.object;
      while (owner && !owner.userData.parkedId) owner = owner.parent;
      const instance = instances.find(i => i.row.id === owner?.userData.parkedId);
      return instance ? { id: instance.row.id, record: instance.card, point: hit.point, distance: hit.distance } : null;
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      for (const instance of instances) { instance.teamRevision++; instance.team?.dispose(); }
      for (const instance of instances) if (instance.row.replaces) fallback(instance.row.replaces, true);
      const geometry = new Set();
      group.traverse(n => { if (n.userData.parkedBatchGeometry) geometry.add(n.geometry); });
      for (const value of geometry) value.dispose();
      for (const promise of assets.values()) void promise.then(disposeLoadedAsset, () => {});
      for (const material of paintedMaterials.values()) material.dispose();
      paintedMaterials.clear();
      group.clear();
      instances.length = 0; replacementIds.clear(); retiredIds.clear();
    },
  };
  // Declared before the early returns below (T-3311): a scene with no parked
  // vehicles (1812, 1880) or a failed placements fetch returns `out` here, and
  // its deferred update() still calls load(), which must find an empty list
  // rather than a binding still in its temporal dead zone.
  let record = null, rows = [];
  let teamTools = null;
  function ensureTeam(instance) {
    if (!stationaryTeams || !instance.row.stationary_team || !instance.retainedPole
      || !shown || confidence?.hidden?.reconstructed || !draws(tier) || disposed || !lastCamera
      || horizontalDistance(lastCamera, instance.row) >= (REACH[tier] ?? 0)
      || instance.team || instance.teamAttempted === instance.teamRevision) {
      return instance.teamPending ?? Promise.resolve(instance.team ?? null);
    }
    if (instance.teamPending) return instance.teamPending.then(() => ensureTeam(instance));
    const revision = instance.teamRevision;
    instance.teamAttempted = revision;
    instance.teamPending = (async () => {
      const spec = instance.row.stationary_team;
      if (instance.vehicleHashes.near !== spec.vehicles.near.sha256
        || (instance.midVehicle && instance.vehicleHashes.mid !== spec.vehicles.mid.sha256)) {
        throw Error('current delivery geometry is not the reviewed team binding');
      }
      teamTools ??= import('./parked-draft-team.js');
      const { createParkedDraftTeam } = await teamTools;
      const team = await createParkedDraftTeam({ row: instance.row, frame: instance.group,
        vehicle: instance.vehicle, midVehicle: instance.midVehicle, dataBase,
        heightAt, confidence });
      if (disposed || !shown || !draws(tier) || instance.teamRevision !== revision
        || !lastCamera || horizontalDistance(lastCamera, instance.row) >= (REACH[tier] ?? 0)) {
        team.dispose(); instance.teamAttempted = null; return null;
      }
      instance.team = team; instance.card = card(instance.row, instance.spec, team);
      instance.original_unhitched_static_support ??= instance.static_support;
      instance.static_support = null;
      return team;
    })().catch(error => {
      problems.push(`parked transport ${instance.row.id} team: ${error.message}; unoccupied carriage retained`);
      return null;
    }).finally(() => { instance.teamPending = null; });
    return instance.teamPending;
  }
  // T-3686: 1871 keeps the hack stand the Sherman House stereograph shows on Clark Street.
  if (!dataBase || !terrain || !['1835', '1871', '1904'].includes(String(sceneId))) return out;
  const heightAt = groundHeight ?? ((e, n) => terrain.surfaceHeight(e, n));
  try {
    const response = await fetch(new URL('transport/parked/placements.json', dataBase));
    if (!response.ok) throw Error(`Placements HTTP ${response.status}`);
    record = await response.json();
  } catch (error) { problems.push(`parked transport: ${error.message}`); return out; }
  rows = (record.scenes[String(sceneId)] ?? []).filter(row => !hostMissing(row.belongs_to));
  for (const row of rows) if (row.replaces) replacementIds.add(row.replaces);
  for (const id of record.retired_yard_wagons?.[String(sceneId)] ?? []) {
    if (typeof id === 'string' && !replacementIds.has(id)) retiredIds.add(id);
  }
  out.records = rows;
  // Each row is requested once; a later call loads only rows not yet asked for,
  // after whatever is already in flight, so the order and the caches are as before.
  function load(want = () => true) {
    if (disposed) return loading;
    const batch = rows.filter(row => !requested.has(row.id) && want(row));
    if (!batch.length) return loading;
    for (const row of batch) requested.add(row.id);
    loading = (loading ?? Promise.resolve()).then(() => loadRows(batch))
      .finally(() => { for (const row of batch) finished.add(row.id); });
    return loading;
  }
  async function loadRows(batch) {
    for (const row of batch) {
      if (disposed) break;
      const spec = record.models[row.model];
      let building = null;
      try {
        // T-3558: ordinary models are cached by FILE, so models that share one GLB
        // (the farm-box master under every covered wagon) decode and upload it once.
        // Light (phones) takes a model's own `file_light` when it names one: the farm-box
        // master's mid level carries a quarter of the near level's texture memory.
        const file = (tier === 'light' && spec.file_light) || spec.file;
        const assetKey = row.model === 'studebaker_brougham_1893' ? row.model : `file:${file}`;
        let pending = assets.get(assetKey);
        if (!pending) {
          pending = row.model === 'studebaker_brougham_1893' ? loadBrougham(spec.file,
            stationaryTeams ? row.stationary_team?.vehicles?.near?.sha256 : null)
            : new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).loadAsync(new URL(file, new URL('../', import.meta.url)).href);
          assets.set(assetKey, pending);
        }
        const asset = await pending;
        if (disposed) break;
        const root = asset.scene.clone(true);
        if (spec.paint) paintVehicle(root, row.model, spec.paint, paintedMaterials);
        if (spec.support_file) {
          const supportKey = `file:${spec.support_file}`;
          let support = assets.get(supportKey);
          if (!support) {
            support = new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).loadAsync(new URL(spec.support_file, new URL('../', import.meta.url)).href);
            assets.set(supportKey, support);
          }
          const supportAsset = await support;
          if (disposed) break;
          root.add(supportAsset.scene.clone(true));
        }
        root.updateMatrixWorld(true);
        const yaw = yawOf(row.bearing_deg), sin = Math.sin(yaw), cos = Math.cos(yaw);
        const heights = spec.wheel_contacts_m.map(([x, z]) => heightAt(
          row.at_local_enu_m[0] + cos * x + sin * z,
          row.at_local_enu_m[1] - (-sin * x + cos * z)));
        if (!heights.every(Number.isFinite)) throw Error('No ground under all four wheels');
        let base = Math.max(...heights);
        let wheelGap = base - Math.min(...heights);
        if (wheelGap > 0.03) throw Error(`Stand exceeds 30mm wheel-plane variation (${wheelGap})`);
        // A pre-authored static pole shoe is not a hinge. Qualify its actual support
        // points on the SAME rendered surface provider as the four wheel contacts.
        let staticSupport = null;
        if (spec.static_support_contacts_m) {
          const contacts = spec.static_support_contacts_m;
          if (!Array.isArray(contacts) || !contacts.length || contacts.some(p => !Array.isArray(p) || p.length !== 3 || !p.every(Number.isFinite))) throw Error('Invalid static support contacts');
          const supportGrounds = contacts.map(([x, y, z]) => heightAt(
            row.at_local_enu_m[0] + cos * x + sin * z,
            row.at_local_enu_m[1] - (-sin * x + cos * z)));
          // Missing carriageway is null; reject BEFORE subtraction can coerce it to zero.
          if (!supportGrounds.every(Number.isFinite)) throw Error('No rendered ground under all static support contacts');
          if (row.model === 'studebaker_brougham_1893') {
            // This rigid parked model also rests on its fixed pole shoe. Solve
            // the least vertical base clearing all four declared shoe corners
            // and wheels, then retain the SAME wheel and shoe gap limits.
            base = Math.max(base, ...contacts.map((point, index) => supportGrounds[index] - point[1]));
            wheelGap = base - Math.min(...heights);
            if (wheelGap > 0.03) throw Error(`Stand exceeds 30mm wheel-plane variation (${wheelGap})`);
          }
          const gaps = contacts.map((point, index) => base + point[1] - supportGrounds[index]);
          if (!gaps.every(Number.isFinite) || Math.min(...gaps) < -0.001 || Math.max(...gaps) > 0.03) throw Error('Static support exceeds 1mm penetration/30mm gap limits');
          staticSupport = { minimum_gap_m: Math.min(...gaps), maximum_gap_m: Math.max(...gaps) };
        }
        const parking = parkTongue(root, row, terrain, base);
        let midAsset = null;
        if (row.model === 'studebaker_brougham_1893'
          && spec.delivery_lods?.runtime_distance_selection_enabled) {
          try {
            const key = `${row.model}:mid`;
            let pendingMid = assets.get(key);
            if (!pendingMid) {
              pendingMid = loadBrougham(spec.delivery_lods.mid,
                stationaryTeams ? row.stationary_team?.vehicles?.mid?.sha256 : null);
              assets.set(key, pendingMid);
            }
            midAsset = await pendingMid;
            if (disposed) break;
          } catch (error) { problems.push(`parked transport ${row.id} mid: ${error.message}; near retained`); }
        }
        const placement = new THREE.Group();
        placement.name = row.id; placement.userData.parkedId = row.id;
        placement.position.set(row.at_local_enu_m[0], base, -row.at_local_enu_m[1]);
        placement.rotation.y = yaw; placement.visible = false;
        const midRoot = midAsset?.scene.clone(true) ?? null;
        placement.add(root); if (midRoot) placement.add(midRoot);
        placement.updateWorldMatrix(true, true);
        const poleName = stationaryTeams ? row.stationary_team?.pole_node : null;
        const nearPole = poleName ? root.getObjectByName(poleName) : null;
        const midPole = midRoot && poleName ? midRoot.getObjectByName(poleName) : null;
        const instance = { row, spec, group: placement, vehicle: root, midVehicle: midRoot,
          retainedPole: Boolean(nearPole && (!midRoot || midPole)), team: null,
          teamRevision: 0, teamAttempted: null, teamPending: null,
          vehicleHashes: { near: asset.parkedDeliverySha256, mid: midAsset?.parkedDeliverySha256 },
          card: card(row, spec), parking, wheel_clearance_m: wheelGap,
          static_support: staticSupport, ownedBatches: [] };
        building = instance;
        await ensureTeam(instance);
        if (disposed) { instance.team?.dispose(); break; }
        const retainPole = (source, pole, batches) => {
          source.traverse(n => {
            if (!n.isMesh) return;
            let keep = false; for (let p = n; p; p = p.parent) if (p === pole) keep = true;
            n.visible = keep;
          });
          batches.add(source);
        };
        const near = staticBatches(root, confidence, instance.retainedPole ? nearPole : null);
        instance.ownedBatches.push(near);
        if (instance.retainedPole) retainPole(root, nearPole, near); else placement.remove(root);
        let model = near, lod = null;
        if (midAsset) {
          try {
            const mid = staticBatches(midRoot, confidence, instance.retainedPole ? midPole : null);
            instance.ownedBatches.push(mid);
            if (instance.retainedPole) retainPole(midRoot, midPole, mid); else placement.remove(midRoot);
            lod = new THREE.LOD();
            // Selection happens with the same camera as reach/picking. Avoid
            // the renderer independently reselecting during shadow passes.
            lod.autoUpdate = false;
            lod.addLevel(near, 0);
            lod.addLevel(mid, 24, 0.05);
            near.visible = true; mid.visible = false;
            model = lod;
          } catch (error) {
            midRoot.removeFromParent();
            problems.push(`parked transport ${row.id} mid: ${error.message}; near retained`);
          }
        }
        if (instance.retainedPole) placement.add(model);
        else {
          // Keep the original public group for ordinary parked vehicles:
          // a merged mesh group, or the Brougham's controlled LOD itself.
          model.name = row.id; model.userData.parkedId = row.id;
          model.position.copy(placement.position);
          model.quaternion.copy(placement.quaternion);
          model.visible = false;
          instance.group = model;
        }
        group.add(instance.group);
        instance.draw_batches = near.children.filter(n => n.userData.parkedBatchGeometry).length
          + (instance.retainedPole ? 2 : 0);
        if (instance.team) {
          instance.original_unhitched_static_support = staticSupport;
          instance.static_support = null;
        }
        Object.assign(instance, lod ? { lod, active_lod: 'near', active_triangles: 45338 } : {});
        instances.push(instance);
        building = null;
      } catch (error) {
        building?.team?.dispose(); building?.group.removeFromParent();
        for (const batch of building?.ownedBatches ?? []) batch.traverse(n => {
          if (n.userData.parkedBatchGeometry) n.geometry.dispose();
        });
        problems.push(`parked transport ${row.id}: ${error.message}; ${row.replaces ? 'existing yard vehicle retained' : 'vehicle not shown'}`);
      }
    }
    if (lastCamera) out.update(lastCamera);
  }
  if (draws(tier) && !deferred) await load();
  return out;
}
