/**
 * world.js — sky, sun, light, environment, tone mapping.
 *
 * The sun is not art-directed. `data/scenes/1835.json` records a lighting
 * moment ("10:00", 1 July 1835) and `data/datum.json` records where that is
 * (41.8867 N, 87.6380 W); the azimuth and elevation are computed from those two
 * facts and drive both the sky and the single directional light. If the scene
 * date moves, the shadows move.
 *
 * On the clock: standard time zones did not exist in 1835 — they arrive with the
 * railroads in 1883. A time written against an 1835 scene can only mean LOCAL
 * MEAN time at that longitude, so that is how it is read here. It matters: the
 * datum longitude is 5h 50m west of Greenwich, nearly ten minutes off the
 * Central Standard meridian, and reading 10:00 as CST would put the sun in the
 * wrong place by about two and a half degrees.
 *
 * The sky's ABSOLUTE brightness, on the other hand, is not physics and has to be
 * calibrated — see SKY_EXPOSURE below.
 */

import * as THREE from 'three';
import { Sky } from 'three/addons/objects/Sky.js';
import {
  gradeAt, resolveTime, minutesOf, isHorizonReference, publishDaylight, NIGHT_KEY, NIGHT_KEY_COLOR,
  NIGHT_KEY_AZIMUTH, NIGHT_KEY_ELEVATION, LOW_SUN_COLOR, NIGHT_SKY_ZENITH,
  NIGHT_SKY_HORIZON, TWILIGHT_GLOW, DUSK_SKY_ZENITH, DUSK_SKY_HORIZON,
} from './time-of-day.js';

const DEG = Math.PI / 180;

/**
 * The one free constant in the sky, and why it has a number rather than a
 * default.
 *
 * Preetham's model — which `Sky.js` implements — produces radiance in arbitrary
 * units: its `EE = 1000.0` "sun intensity" is a convention, not a measurement,
 * so the model fixes the sky's COLOUR but says nothing about where that colour
 * should sit on the exposure scale. three's own example papers over this by
 * running the whole scene at `toneMappingExposure = 0.5`, which is not available
 * here: the same exposure lights the buildings, and their albedo is evidence.
 *
 * So the sky gets its own exposure, and the number is measured rather than
 * dialled by eye. Against `dupage_tallgrass_2018-07-24.jpg` — a verified 24 July
 * photograph of Illinois tallgrass at this latitude, framed the way the standard
 * `prairie_west` shot is framed — the sky reads sRGB (101,153,209) about 15°
 * above the horizon, (125,165,205) at 8°, (137,166,200) at 4°. Running this
 * shader through the same ACES + sRGB chain the renderer uses, 0.045 lands the
 * 1835 sky within a few units of all three at the shot's own view azimuth. The
 * scene default of 1.0 rendered (245,252,255) — a white wash at every elevation,
 * which is what the baseline showed.
 *
 * It is applied to the sky ALONE. It is deliberately NOT a change to
 * `toneMappingExposure`, which would move the ground, the water and every
 * documented wall colour with it.
 *
 * What it does NOT fix, because a single scalar cannot: the SHAPE of the sky
 * with elevation. Exposure moves all three channels at every elevation together;
 * the error against the photograph was concentrated in red and green, and only
 * near the horizon. That is HORIZON_RESTORE below.
 */
const SKY_EXPOSURE = 0.045;

/**
 * The calibrated exposure the whole scene is graded at, and the one number the
 * brightness aid is allowed to move.
 *
 * K24. `toneMappingExposure` lights the ground, the water and every documented
 * wall colour together — which is exactly why SKY_EXPOSURE above refuses to use
 * it, and exactly why a visitor-facing brightness control has to be built as an
 * accommodation rather than as a second grade. 0.95 is the calibrated position:
 * every gate in `tools/smoke_renderer.mjs`, every frame `tools/critic_shots.mjs`
 * takes and every reading `tools/light_probe.mjs` reports is taken here, and the
 * aid below is off at boot so they stay taken here.
 *
 * T-3428 (owner, 2026-11-06): the ceiling is TWO STOPS — 4x — and it is no longer
 * exposure alone. One stop of exposure was the old ceiling, and the owner found a
 * shaded front (the Glessner house under the parkway elms on a jaunt stop) still
 * too dark at it, because exposure lifts the sunlit roofs and the sky into the
 * ACES shoulder long before a wall in shade has moved. So the aid now splits its
 * stops three ways:
 *
 *   - EXPOSURE takes half of them (4x → 2x, the old ceiling), lifting everything.
 *   - The SKY FILL takes the other half (4x → 2x on `environmentIntensity`, the
 *     flora's published fill and the leaves' transmitted skylight). The fill is
 *     nearly all of the light on a surface in shade and a small part of it in
 *     sun, so a facade in shade gets the whole 4x and a sunlit roof about 2.3x.
 *   - The SKY ITSELF (the dome and the haze matched to it) is held back to a
 *     quarter of the stops, 4x → 1.41x, so it keeps its blue rather than washing
 *     to white at the top of the slider.
 *
 * Still an accommodation and not a second grade: no material or record changes,
 * nothing is baked from it, and 0 is the calibrated frame exactly (every factor
 * is 2^0). A visitor's stored stop from the old 0..1 slider means the same
 * exposure it did plus the fill, which is only ever brighter in shade.
 */
const BASE_EXPOSURE = 0.95;
const MAX_BRIGHTNESS_STOPS = 2;
/** T-3428: the share of the aid's stops each of the three takes. */
const BRIGHT_EXPOSURE_SHARE = 0.5;
const BRIGHT_FILL_SHARE = 0.5;
const BRIGHT_SKY_SHARE = 0.25;

/**
 * Putting the colour back into Preetham's horizon.
 *
 * THE DEFECT. Follow the model down to the horizon and watch the wavelength
 * dependence leave it. `Sky.js` builds in-scatter as
 *
 *     Lin = ( sunE * (betaR*rPhase + betaM*mPhase) / (betaR + betaM) * (1 - Fex) ) ^ 1.5
 *
 * and `Fex`, the extinction, is by far the strongest wavelength-dependent factor
 * in it. Along a horizon ray the model's own optical-length term runs to ~26×
 * the zenith path at 1° up and ~37× at the horizontal, so `Fex` has gone to
 * zero in all three channels and `1 - Fex` is 1, 1, 1. What is left is the
 * ratio of the two phase functions, and those are almost achromatic:
 * evaluated for this scene at 1° up, the red:green:blue in-scatter comes out
 * 0.816 : 0.919 : 1.000. The model therefore renders a WHITE horizon and hands
 * the whitening job to a neutral, so the band above the skyline arrived as
 * sRGB (181,191,195) at saturation 0.072.
 *
 * The photograph disagrees, and not by a little. `bar/dupage_tallgrass_
 * 2018-07-24.jpg` reads (136,163,192) at saturation 0.288 immediately above its
 * own sky/land step — B-R +55 against our +14. Note WHERE the error is: our
 * blue is essentially right (195 against 191). The whole of it is red +45 and
 * green +28. The horizon was not short of blue, it was carrying red and green
 * that a real horizon does not carry.
 *
 * THE CORRECTION. So this restores the channel dependence the saturated `1-Fex`
 * threw away, and does it the only way that leaves everything else alone: red
 * and green are attenuated toward the horizon, blue is not touched at all, and
 * the attenuation dies out with height fast enough that the upper sky renders as
 * the model built it — 0.3 % of the green at 30°, 0.03 % at 40°, nothing that
 * survives rounding to 8 bits anywhere above that.
 *
 *     scale(channel) = 1 - A * exp( -( sin(elevation) / E ) ^ P )
 *
 * A, E and P are FITTED — to the photograph, not by eye. The bar's sky was
 * sampled at ten elevations from 16° down to 0.5°, and A and E were solved by
 * running each candidate back through this scene's own shader, exposure, ACES
 * curve and sRGB encode and least-squaring against those samples
 * (`gaa_fit4.mjs` in the working directory). Residuals: 1.6 units RMS in red,
 * 1.0 in green, worst case 4, and the last degree — the elevation the
 * verification actually reads — lands within one unit on both.
 *
 * Red and green have to be solved TOGETHER, which is easy to get wrong: ACES is
 * not a per-channel curve. Its input matrix row for red is
 * (0.597, 0.355, 0.048), so taking green out takes red with it, and fitting the
 * two channels separately produced a pair that each looked right alone and
 * overshot red by 10 units together. The exponent is shared and lands at 1.6; a
 * plain exponential (P = 1) fits the middle of the band and then overshoots the
 * last degree, which is exactly where the check is.
 *
 * WHAT IT IS NOT. It is not exposure and it is not a tone curve: the patch
 * multiplies `texColor` inside the SKY shader. It is not "add blue": blue is
 * untouched, and every unit of the change is red and green coming off.
 *
 * WHAT IT NOW ALSO IS, since W1. This used to say the patch reached nothing but
 * the backdrop, because the PMREM built from this sky was disposed unused. It is
 * installed now, so the fit below no longer decides only what the horizon LOOKS
 * like — it decides what colour the light coming from that horizon IS, and it
 * reaches every wall in the town. The fit was made against a photograph and is
 * the better authority for both jobs, but a future change to it is a change to
 * the lighting and must be measured with `tools/light_probe.mjs`, not only with
 * a capture of the sky.
 *
 * ITS ONE HONEST COST, so nobody has to rediscover it. The fit is azimuth-blind,
 * because the model's horizon goes achromatic in every direction and the defect
 * is therefore the same in every direction — but the model's horizon BRIGHTNESS
 * is not the same in every direction. `prairie_west` looks south, within 19° of
 * the sun's azimuth and into the forward-scattering lobe, and the bar photograph
 * is framed the same way. The anti-sun views (`river_bank`, looking north) start
 * darker, so subtracting the same fraction of red and green leaves them bluer
 * and DARKER than the photograph: measured at 1° above the north horizon,
 * (104,132,166) — hue improved (B-R +62 against the bar's +55, where before it
 * was +17) but luminance down to 128 against the bar's 160, because red and
 * green are most of what luminance is. So the render brackets the photograph
 * rather than sitting on it, and it now brackets from the blue side instead of
 * the grey side.
 *
 * A floor keyed on the horizon's own chromaticity was tried and thrown away: it
 * scales with the blue channel, and the anti-sun blue is low too, so it moved
 * B-R by three units and earned nothing. Fixing this properly means an azimuth
 * term, and an azimuth term needs a second VERIFIED July photograph shot away
 * from the sun to fit against. `bar/REFERENCES.md` does not have one, and
 * guessing the anti-sun sky from the solar one is exactly the kind of invention
 * this project does not do.
 */
const HORIZON_RESTORE = {
  /** red: how much comes off at the horizon, and the scale in sin(elevation) */
  redAmount: 0.495, redScale: 0.130,
  /** green: two thirds as much to remove, and it reaches a little higher */
  greenAmount: 0.330, greenScale: 0.190,
  /** shared falloff exponent */
  power: 1.6,
};

/**
 * The colour the air itself is, and therefore the colour distance goes to.
 *
 * This is the MEASURED horizon sky of `bar/dupage_tallgrass_2018-07-24.jpg`:
 * sRGB (136,163,192), taken from the twelve pixels immediately above the
 * sky/land step, which is a reading that does not depend on knowing the
 * photograph's field of view.
 *
 * It replaces a hand-picked grey-green (0x98a69d), and the reason is worth
 * keeping. That value was reasoned from "a hazed plain keeps some of its own
 * green", and it does — but it was set so far toward the sward that a
 * fully-hazed surface rendered at sRGB (143,157,130): GREENER than the sky it
 * was supposed to converge on, and REDDER than it was blue (B-R -13). Real
 * aerial perspective pushes distance toward the sky, i.e. BLUE — the bar's own
 * most distant land reads (118,146,145), B-R +27. With a haze that goes the
 * other way, no amount of distance can make ground and air meet: the horizon
 * stayed a step rather than a convergence (63 luminance across four pixels,
 * where the note below this one had designed for 15).
 *
 * The green does not disappear, it just stops being IN the air: the ground
 * keeps its own colour and the haze mixes it toward the sky, which is the
 * order the physics happens in. A fully-hazed surface now renders sRGB
 * (152,175,195) — B-R +43, and 12 luminance off this scene's own horizon sky.
 *
 * Shared with the water's grazing-angle term in terrain.js, and with the
 * horizon-timber band in trees.js, so the river, the far ground and the far
 * timber all agree about what distance looks like. Changing it here without
 * changing it there splits the scene's idea of distance in three.
 */
export const HORIZON_HAZE = 0x88a3c0;

/**
 * THE GROUND'S HALF OF THE ENVIRONMENT — a reflectance, not a colour.
 *
 * An environment map of an analytic sky has a defect nothing in the sky model
 * can fix: the model is defined over the whole sphere, so it paints the ground
 * half too, and it paints it BLUE. Install that as `scene.environment` and every
 * downward-facing surface in the town — an eave's underside, the shaded side of
 * a log wall, the interior of a crown — is lit by sky from below as well as
 * above. That is not aerial physics, it is a hole in the model, and it is the
 * whole of why the last attempt "swamped albedo": the environment it installed
 * had no ground in it, so it replaced the warm bounce with more sky and every
 * surface converged on the sky's hue regardless of what it was made of.
 *
 * So the environment is built with a ground in it. Its radiance is DERIVED, and
 * from numbers already committed rather than picked:
 *
 *     L_ground = reflectance * E_horizontal / PI
 *
 * `reflectance` is the dun `0x7a6b4e` the hemisphere light already carried as
 * its ground colour. Read as a reflectance — which is what its numbers already
 * are, linear (0.195, 0.144, 0.074), a 15 % reflector — it is a plausible
 * prairie-and-mud albedo and needs no new constant. What was missing was the
 * other factor: the old rig applied that colour at a hand-picked intensity, so
 * the bounce bore no relation to how much light was actually falling on the
 * ground it was supposed to be bouncing off.
 *
 * `E_horizontal` is the light this scene actually delivers to a horizontal
 * surface: the sun's own term, computed here from its colour, intensity and
 * elevation, plus SKY_FILL_UP below.
 */
const GROUND_REFLECTANCE = 0x7a6b4e;

/**
 * The fill the environment actually delivers, MEASURED — and the discrepancy
 * that came out of measuring it, which is the finding of this phase.
 *
 * `SKY_FILL_UP` is the irradiance on an upward-facing white Lambertian card from
 * this environment at intensity 1, sun excluded, reported by a committed
 * instrument:
 *
 *     node tools/light_probe.mjs
 *
 * `CALIBRATED_FILL_UP` is the same reading taken from the rig this phase
 * replaces — a `HemisphereLight(0xa8c4e0, 0x7a6b4e, 2.4)` plus a second at 0.20.
 *
 *     measured 2026-08-14      R       G       B     luminance
 *     the old hemisphere    1.0440  1.4565  1.9535     1.4047
 *     this sky, at 1        0.3663  0.7916  1.5492     0.7558
 *
 * THE OLD FILL WAS NOT THE SKY. It delivered 1.86x the luminance of the sky it
 * stood for and nearly three times the red, at a scene exposure calibrated so
 * that same sky renders within a few units of a verified photograph. So the town
 * was lit by a fill that contradicted its own backdrop, and every later
 * calibration — the sward's density, the wall colours, the crown contrast — was
 * measured under it.
 *
 * WHICH LEAVES A CHOICE, and it was made by measuring both halves of it rather
 * than by argument. RENDERING §4 W1 says to rebalance "so total illuminance
 * stays calibrated rather than doubled", which here means scaling the sky back
 * UP by 1.858 to restore the luminance the old fill delivered. That was built
 * and measured, and it fails the acceptance it was built to satisfy:
 *
 *     log wall R/B retained, against a white card in the same light
 *       the old hemisphere fill                85 %
 *       this environment at its own magnitude  76 %
 *       this environment scaled to 1.858       62 %
 *
 * Scaling a sky that is genuinely blue — the calibrated zenith is B/R 4.2 —
 * until it carries a hand-picked fill's luminance puts nearly three times the
 * blue on every surface, and the browns converge toward it. That is the 2026-08
 * failure this file already records, arrived at from the other direction.
 *
 * So the environment is installed at ITS OWN MAGNITUDE — `environmentIntensity`
 * stays 1 and there is no invented scalar anywhere in the fill. The scene's
 * total illuminance falls 16 % as a result, which is the honest consequence of
 * lighting the town with the sky it is calibrated against, and every number it
 * moves is measured in `docs/STATUS.md` rather than left to be discovered.
 *
 * NEITHER FIGURE IS FREE TO DRIFT. `tools/smoke_renderer.mjs` re-measures the
 * fill through the same probe and fails if the rig has moved more than 5 % from
 * what is written here, because a stale figure would mis-derive both the ground
 * bounce and the intensity, and a bounce wrong in the direction of "too dark" is
 * exactly the failure this phase exists to retire.
 */
const SKY_FILL_UP = [0.3663, 0.7916, 1.5492];
const CALIBRATED_FILL_UP = [1.0440, 1.4565, 1.9535];
/** The environment is installed as measured. Named, rather than left implicit,
 *  because "1" here is a decision and not a default. */
const ENV_INTENSITY = 1.0;
const FILL_UP = SKY_FILL_UP.map((v) => v * ENV_INTENSITY);

/**
 * Exponential-squared haze, and since T-1635 the density is DERIVED rather than
 * tuned. `FogExp2` leaves a surface exp(-(d * density)^2) of its own colour at
 * distance d, so at 0.00089 the air takes 0.8 % at 100 m, 6.9 % at 300 m, 32 %
 * at 700 m, 68 % at 1,200 m, 83 % at 1,500 m, and the last representable 8-bit
 * step of it at 2,644.9 m.
 *
 * WHAT SETS IT, AND IT IS A MEASUREMENT OF COMMITTED GEOMETRY. The air here
 * exists to close the horizon over the apron. docs/LIBERTIES.md L17 carries each
 * boundary vertex of the modelled box outward past the box — geometry for the
 * horizon only, nothing modelled, sampled or claimed — and the fog has to be
 * total by the time the eye reaches that apron's OUTER EDGE, or the edge itself
 * reads as a landform. The apron's width is not a choice either:
 * `generators/terrain_gen.py` derives it from the box so the publish step's
 * quantiser lattice divides the terrain grid (T-0152) and publishes it as
 * `heightfield.json`'s `skirt.margin_m`, which for the committed field is
 * **2,659.84 m**. Solve `hazeReachM(density) <= 2659.84` and the thinnest air
 * this scene is allowed is 0.0008850. 0.00089 is that bound rounded up to two
 * figures; the haze goes total 14.9 m inside the apron's edge.
 *
 * THE NUMBER IT REPLACES WAS THE SAME ARGUMENT AGAINST A BOX THREE MOVES AGO.
 * 0.00125 is total at 1,883 m, and it was set against L17 as L17 was first
 * written: a heightfield covering "a 640 m square", "a radial skirt carried out
 * to 1400 m", and the standing condition that "the scene's fog is total by
 * 1500 m". All three of those figures have since been retired inside L17 itself
 * — the box was extended east, north and south, and the apron was re-derived
 * with it — so the distance the fog is actually asked to close over ran 776.7 m
 * past the air that was built for it, and nothing re-thinned the air to match.
 * What was left of it is what the owner reported from the air: past about 1.2 km
 * the plain was a featureless band with the far timber standing in it, because
 * one tenth of the prairie's own colour survived the trip. Just under a third of
 * it does now, and the same reading at 1,500 m goes 3.0 % to 16.8 %.
 *
 * SO THIS IS NOT A LOOK, AND IT IS NOT A CLAIM ABOUT JULY WEATHER EITHER. No
 * source reached describes visibility over the 1835 prairie, and none is cited
 * here: the air is as clear as the modelled world allows and no clearer, which
 * is a stated liberty and is recorded as one in L17. Read as meteorological
 * visibility (the 2 % contrast distance) it is still only 2.2 km, up from
 * 1.6 km — mist, not a clear summer day. That gap is a fact about how much
 * ground has been built, not about the weather, and it closes by building
 * ground.
 *
 * IT IS GATED, NOT PROMISED. `tools/check_haze_reach.mjs` reads this literal,
 * the copy in `trees.js` and every epoch's published `skirt.margin_m`, and
 * refuses a density whose total distance runs past the apron it has to close
 * over. L17's standing condition is therefore held by a check on every commit
 * instead of by a sentence in this block that the next box extension can quietly
 * make false — which is exactly what happened to the last one.
 *
 * WHAT IT COSTS, MEASURED. `terrain.js`'s `hazeReachM()` derives the ground cull
 * from this density, so thinning the air pushes the reach out 761.7 m (1,883.2
 * -> 2,644.9). Read on the published mirror at desktop 1280x800, at T-0135's
 * five stands and all three sealed tiers, this tree against dev's: the triangle
 * and draw-call counts are IDENTICAL at all fifteen readings, and identical
 * again at the owner's own pose (fly, e 120, n -420, 183 m, yaw 0, pitch -8 —
 * 1,072,186 triangles, 89 calls, 30 of 217 ground tiles drawn, at both
 * densities). The ground's culling grid is cut at 240 m and what lies between
 * the two reaches at these stands is apron, which T-1595's sliver merge already
 * submits as one always-drawn mesh of 2,489 triangles. The reach moved and the
 * frame did not.
 */
const HAZE_DENSITY = 0.00089;
// T-3654: the 1871 municipal field has a 20 km horizon apron.
// A visual reconstruction, not recorded weather; checked against that apron.
const CITY_HAZE_DENSITY = 0.00012;

/**
 * ROADMAP R-W3b(a) — HOW FAR FROM THE VISITOR THE SUN'S SHADOW REACHES, in
 * metres, as the half-width of the orthographic box that follows them.
 *
 * Exported because it is a claim a gate can read: `tools/smoke_renderer.mjs`
 * asserts that the shipped rig carries this reach at the texel size the block
 * beside `light.shadow` documents, and `tools/measure_shadow_reach.mjs` prints
 * what each candidate value would cost. The full reasoning, the measured
 * coverage it buys and the draw-call ceiling that decides the number are in that
 * block — read it before changing this.
 */
export const SHADOW_REACH_M = 240;

/**
 * THE SHADOW BIASES ARE FRACTIONS OF A TEXEL, NOT LENGTHS — T-3054.
 *
 * A shadow map is a raster, so a wall lit at a slant spans more depth inside
 * one of its texels than the wall is thick, and without an allowance it finds
 * itself behind its own stored depth and shadows itself in blocks. The two
 * allowances are `bias` (depth, toward the light) and `normalBias` (along the
 * receiver's own normal), and how much either must allow scales with the
 * TEXEL: the depth a face spans in one texel is the texel times the tangent of
 * the sun's angle off the face's normal. -0.0004 and 0.045 m were tuned on the
 * 11.7 cm texel `full` and `balanced` draw. The `light` tier draws 23.4 cm
 * (1024 over +/-120 m, `setShadowRig`) and kept both, which is half the
 * allowance its texel needs: at the scene's 12:30 sun a south wall is lit
 * about 70 degrees off its normal, and it shadowed itself.
 *
 * The owner saw it on his iPhone on 2026-10-23 as the 1835 freight shed by the
 * Dearborn draw going "very pixelated when I moved around it": blotches of the
 * wall's own shadow on a pale untextured board front. Measured at 375x636 on
 * the phone profile: with the sun's shadow off the blotches vanish; doubling
 * `normalBias` alone clears the shed's boards and not the D4 cottage's
 * clapboards; doubling both clears both, leaving only the eaves' real shadow.
 *
 * So both are stated per texel and `setShadowRig` re-derives them with the
 * map: exactly -0.0004 and 0.045 m on `full` and `balanced` (unchanged), and
 * twice that on `light`. `tools/check_shadow_bias.mjs` holds it.
 */
const FULL_TEXEL_M = (2 * SHADOW_REACH_M) / 4096;
export const SHADOW_BIAS_TEXELS = -0.0004 / FULL_TEXEL_M;
export const SHADOW_NORMAL_BIAS_TEXELS = 0.045 / FULL_TEXEL_M;

/** The depth and normal biases for a shadow texel of `texelM` metres. */
export function shadowBiasFor(texelM) {
  return { bias: SHADOW_BIAS_TEXELS * texelM, normalBias: SHADOW_NORMAL_BIAS_TEXELS * texelM };
}

/**
 * THE HAZE FOLLOWS THE SKY IT CONVERGES ON — T-1631.
 *
 * THE DEFECT, and it is one number. `HORIZON_HAZE` above is the horizon sky of
 * the BAR PHOTOGRAPH, sRGB (136,163,192), L 159.4. This scene's own horizon sky
 * is not that colour in any direction, and the two notes that knew it never met:
 * HORIZON_RESTORE's "one honest cost" records the render at 1° above the NORTH
 * horizon as (104,132,166), L 128, because the anti-sun sky starts darker and an
 * azimuth-blind fit takes the same red and green off it; and `trees.js` records
 * the fully-fogged pixel as "four levels BELOW the horizon sky, which is what
 * airlight is supposed to do" — true on the solar side, where that note was
 * measured, and false everywhere else.
 *
 * Sampled here rather than argued about: the scene's own sky at 1° elevation,
 * every 10° of bearing, reads L 122 due north rising to L 148 due south. The fog
 * is L 159. **The haze is brighter than the sky it is supposed to be converging
 * on at every azimuth on the compass** — by 11 luminance toward the sun and by
 * 37 away from it.
 *
 * WHAT THAT LOOKS LIKE, which is what the ticket was filed for. Distance cannot
 * then fade into the sky; it can only rise out of it. A visitor flying north at
 * 600 ft sees the ground past the drawn town converge on a flat sheet 31
 * luminance BRIGHTER than the sky above it, with a hard step where the two meet
 * — and a bright flat blue-grey sheet under a darker sky, with trees standing up
 * out of it, is what a lake looks like from the air. Measured at that pose
 * (e 120, n -420, 183 m, yaw 0, pitch -8°): the pixel below the step reads
 * (136,163,192) against (103,131,165) above it. Turn the fog off and the same
 * pixel reads (109,125,84) — GREEN. The ground was there the whole time and the
 * reach was never the fault: the haze was painting land the colour of water.
 *
 * THE FIX IS A SAMPLE, NOT A FIT. `HORIZON_RESTORE` refused an azimuth term
 * because fitting one honestly needs a second verified July photograph shot away
 * from the sun, and `bar/REFERENCES.md` has none. That refusal stands and this
 * does not touch it: the fog is not being fitted to anything. It is being told
 * to converge on the sky THIS SCENE ALREADY DRAWS, read off the shader at boot.
 * Nothing is invented, no photograph is guessed at, and the sky is unchanged —
 * what changes is that distance now goes toward the air that is actually there
 * instead of toward the air over a different photograph.
 *
 * WHAT IT COSTS. Thirty-six one-pixel renders of the sky box, once, at boot. Per
 * frame it is a bearing, a table index and a colour copy; no geometry is added,
 * no reach moves, and `hazeReachM()` is untouched because it reads the DENSITY,
 * which does not change. The consumers that copy the haze follow it live —
 * `terrain.js`'s water `uSky` and `trees.js`'s horizon band — and the release
 * smoke already asserts the band against `scene.fog.color` rather than against a
 * hex, so that coupling is gated rather than promised.
 */
const HORIZON_RING_STEPS = 36;
/** The elevation the ring is read at: the one the committed readings are at. */
const HORIZON_SAMPLE_DEG = 1.0;
/**
 * The anti-sun reading this sampler has to reproduce, from HORIZON_RESTORE's own
 * measurement at 1° above the north horizon. The guard is deliberately loose —
 * its job is to catch a sampler that has stopped reading the sky at all (a white
 * wash from a lost shader marker, a linear-space read at a third the radiance),
 * not to re-litigate a unit. A ring that misses it is reported and the fixed
 * constant is kept, because a haze read off nothing is worse than a stale one.
 */
const HORIZON_RING_NORTH = [104, 132, 166];
const HORIZON_RING_TOLERANCE = 14;

/**
 * Read this scene's own sky at the horizon, all the way round.
 *
 * The sky is lifted into a bare scene for the pass for the same reason the PMREM
 * build above lifts it: everything else in the world would be in the way. It is
 * put back before this returns.
 *
 * The render target carries `SRGBColorSpace`, so what comes back is the DISPLAY
 * colour — which is the space `FogExp2` lerps in (three r185 runs fog after the
 * tone curve and the colour-space encode, and uploads the fog uniform through
 * `getUnlitUniformColorSpace()`). Reading it in any other space would give a fog
 * that is arithmetically defensible and visibly wrong, which is the exact bug
 * `terrain.js`'s `uSky` note records having shipped once already.
 *
 * @returns {THREE.Color[] | null} one colour per 10° of bearing, or null
 */
function sampleHorizonRing(renderer, sky, problems = [], validate = true) {
  const parent = sky.parent;
  const stage = new THREE.Scene();
  // One pixel per bearing, side by side in one target, read back once: each step
  // renders the same 1 x 1 view into its own pixel (viewport and scissor), so the
  // colours are the ones a 1 x 1 target per step gave, for one GPU round trip
  // instead of 36 (T-3643).
  const rt = new THREE.WebGLRenderTarget(HORIZON_RING_STEPS, 1, { colorSpace: THREE.SRGBColorSpace });
  const cam = new THREE.PerspectiveCamera(1, 1, 0.1, 1e6);
  const prevTarget = renderer.getRenderTarget();
  const px = new Uint8Array(4 * HORIZON_RING_STEPS);
  const el = HORIZON_SAMPLE_DEG * Math.PI / 180;
  const ring = [];
  try {
    stage.add(sky);
    rt.scissorTest = true;
    for (let i = 0; i < HORIZON_RING_STEPS; i++) {
      const b = (i / HORIZON_RING_STEPS) * Math.PI * 2;
      // ENU bearing 0 is north and the renderer's north is -Z, so a bearing of
      // b looks along (sin b, ., -cos b) — the same mapping `enuToWorld` uses.
      cam.position.set(0, 0, 0);
      cam.up.set(0, 1, 0);
      cam.lookAt(Math.sin(b) * Math.cos(el), Math.sin(el), -Math.cos(b) * Math.cos(el));
      cam.updateMatrixWorld();
      rt.viewport.set(i, 0, 1, 1);
      rt.scissor.set(i, 0, 1, 1);
      renderer.setRenderTarget(rt);
      renderer.render(stage, cam);
    }
    renderer.readRenderTargetPixels(rt, 0, 0, HORIZON_RING_STEPS, 1, px);
    for (let i = 0; i < HORIZON_RING_STEPS; i++) {
      ring.push(new THREE.Color().setRGB(px[4 * i] / 255, px[4 * i + 1] / 255, px[4 * i + 2] / 255,
        THREE.SRGBColorSpace));
    }
  } catch (err) {
    problems.push(`world: the horizon ring could not be sampled (${err?.message || err}); `
      + 'the haze is the fixed constant');
    return null;
  } finally {
    renderer.setRenderTarget(prevTarget);
    rt.dispose();
    parent?.add(sky);
  }
  // The committed reading is of 1 July 1835 at 12:30 local mean solar time.
  // Other dates and hours are taken as rendered, not held to that July reading.
  if (!validate) return ring;
  const north = ring[0].getHex(THREE.SRGBColorSpace);
  const got = [(north >> 16) & 255, (north >> 8) & 255, north & 255];
  const off = Math.max(...got.map((v, i) => Math.abs(v - HORIZON_RING_NORTH[i])));
  if (off > HORIZON_RING_TOLERANCE) {
    const said = `world: the sampled horizon sky due north is (${got.join(',')}), `
      + `${off} off the measured (${HORIZON_RING_NORTH.join(',')}) — the haze is `
      + 'the fixed constant until someone says which of the two moved';
    problems.push(said);
    console.warn(`[4D Chicago] ${said}`);
    return null;
  }
  return ring;
}

/**
 * Solar azimuth and elevation, NOAA's algorithm.
 *
 * @param {object} o
 * @param {number} o.lat            degrees north
 * @param {number} o.lon            degrees east (negative west)
 * @param {string} o.date           'YYYY-MM-DD'
 * @param {string} o.localMeanTime  'HH:MM', local mean solar time at `lon`
 * @returns {{azimuthDeg:number, elevationDeg:number, declinationDeg:number,
 *            equationOfTimeMin:number, utcHours:number}}
 */
export function solarPosition({ lat, lon, date, localMeanTime = '12:00' }) {
  const [y, mo, d] = date.split('-').map(Number);
  const [hh, mm] = localMeanTime.split(':').map(Number);
  const localHours = hh + (mm || 0) / 60;

  // Local mean time -> UTC. Longitude west is negative, so this adds.
  const utcHours = localHours - lon / 15;

  // Julian day (Fliegel & Van Flandern), then centuries from J2000.0.
  const a = Math.floor((14 - mo) / 12);
  const yy = y + 4800 - a;
  const mm2 = mo + 12 * a - 3;
  const jdn = d + Math.floor((153 * mm2 + 2) / 5) + 365 * yy + Math.floor(yy / 4)
    - Math.floor(yy / 100) + Math.floor(yy / 400) - 32045;
  const jd = jdn - 0.5 + utcHours / 24;
  const T = (jd - 2451545.0) / 36525;

  const L0 = mod360(280.46646 + T * (36000.76983 + 0.0003032 * T));
  const M = 357.52911 + T * (35999.05029 - 0.0001537 * T);
  const e = 0.016708634 - T * (0.000042037 + 0.0000001267 * T);
  const C = Math.sin(M * DEG) * (1.914602 - T * (0.004817 + 0.000014 * T))
    + Math.sin(2 * M * DEG) * (0.019993 - 0.000101 * T)
    + Math.sin(3 * M * DEG) * 0.000289;
  const trueLong = L0 + C;
  const omega = 125.04 - 1934.136 * T;
  const lambda = trueLong - 0.00569 - 0.00478 * Math.sin(omega * DEG);
  const eps0 = 23 + (26 + (21.448 - T * (46.815 + T * (0.00059 - T * 0.001813))) / 60) / 60;
  const eps = eps0 + 0.00256 * Math.cos(omega * DEG);

  const decl = Math.asin(Math.sin(eps * DEG) * Math.sin(lambda * DEG)) / DEG;

  const varY = Math.tan(eps / 2 * DEG) ** 2;
  const eqTime = 4 / DEG * (
    varY * Math.sin(2 * L0 * DEG)
    - 2 * e * Math.sin(M * DEG)
    + 4 * e * varY * Math.sin(M * DEG) * Math.cos(2 * L0 * DEG)
    - 0.5 * varY * varY * Math.sin(4 * L0 * DEG)
    - 1.25 * e * e * Math.sin(2 * M * DEG)
  );

  const trueSolarMin = mod(utcHours * 60 + eqTime + 4 * lon, 1440);
  const hourAngle = trueSolarMin / 4 - 180;

  const latR = lat * DEG, declR = decl * DEG, haR = hourAngle * DEG;
  const cosZenith = Math.min(1, Math.max(-1,
    Math.sin(latR) * Math.sin(declR) + Math.cos(latR) * Math.cos(declR) * Math.cos(haR)));
  const zenith = Math.acos(cosZenith);
  const elevation = 90 - zenith / DEG;

  let azimuth;
  const denom = Math.cos(latR) * Math.sin(zenith);
  if (Math.abs(denom) < 1e-9) {
    azimuth = hourAngle > 0 ? 180 : 0;
  } else {
    const cosAz = Math.min(1, Math.max(-1,
      (Math.sin(latR) * cosZenith - Math.sin(declR)) / denom));
    const a = Math.acos(cosAz) / DEG;
    // NOAA's branch, and it is easy to get backwards: before local solar noon
    // the sun is EAST of south, after it is west. Getting this wrong put the
    // 10 a.m. July sun in the north-east and the shadows on the wrong side.
    azimuth = hourAngle > 0 ? mod360(a + 180) : mod360(540 - a);
  }

  return {
    azimuthDeg: mod360(azimuth),
    elevationDeg: elevation,
    declinationDeg: decl,
    equationOfTimeMin: eqTime,
    utcHours,
  };
}

/** Compass bearing + elevation -> a unit direction in three's world frame. */
export function sunDirection(azimuthDeg, elevationDeg, target = new THREE.Vector3()) {
  const az = azimuthDeg * DEG;
  const el = elevationDeg * DEG;
  const horiz = Math.cos(el);
  return target.set(
    Math.sin(az) * horiz,     // +x east
    Math.sin(el),             // +y up
    -Math.cos(az) * horiz,    // -z north
  ).normalize();
}

function mod(a, n) { return ((a % n) + n) % n; }
function mod360(a) { return mod(a, 360); }

/**
 * Build the sky, the sun and the environment for a scene.
 *
 * @param {object} o
 * @param {THREE.WebGLRenderer} o.renderer
 * @param {THREE.Scene} o.scene
 * @param {object} o.sceneJson   data/scenes/<year>.json
 * @param {object} o.datum       data/datum.json
 * @param {boolean} o.lowSpec    smaller shadow map, cheaper env
 * @param {string[]} [o.problems] collector, same list the scene loader writes to
 */
export function createWorld({
  renderer, scene, sceneJson, datum, lowSpec = false, problems = [],
}) {
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = BASE_EXPOSURE;
  renderer.shadowMap.enabled = true;
  // PCF on every device (T-3643). three r185 deprecates PCFSoftShadowMap: its
  // first shadow render swaps it for PCFShadowMap, which is what every frame has
  // drawn with since. Until that swap, a program compiles with BASIC shadows
  // under the old type's key, so the whole boot compile (main.js compileAsync)
  // was thrown away and each material compiled again, mid-walk, the first time
  // it came into view. Booting with the type three draws anyway keeps them.
  renderer.shadowMap.type = THREE.PCFShadowMap;

  // T-3654: an explicitly declared presentation calibration, independent of
  // the dated solar position. The 1871 afternoon uses 6x; omitted is exactly
  // the established 1812/1835/1904 exposure. Dome, PMREM and sampled haze share
  // this value, including after a time change or the visitor's brightness aid.
  const sceneSkyExposure = SKY_EXPOSURE * (sceneJson.lighting?.sky_exposure_multiplier ?? 1);
  let sunDate = sceneJson.target_date;
  // T-3331: the hour the sun is computed for. The scene's own unless the visitor's
  // Time of day (or a jaunt stop) moved it.
  const sceneTime = sceneJson.lighting?.local_time ?? '12:00';
  let sunTime = sceneTime;
  let sun = solarPosition({
    lat: datum.origin_lat,
    lon: datum.origin_lon,
    date: sceneJson.target_date,
    localMeanTime: sceneTime,
  });
  const dir = sunDirection(sun.azimuthDeg, sun.elevationDeg);

  // Prairie haze and woodsmoke, per the scene's own lighting note. Turbidity 6
  // is hazier than a clear modern day and cheaper than any volumetric. It is the
  // aerosol term: it whitens the horizon and leaves the zenith alone, which is
  // the right shape — at 24° up it moves the sky by three or four units out of
  // 255, and at 3° up by fourteen.
  const sky = new Sky();
  sky.name = 'sky';
  sky.scale.setScalar(45000);
  sky.material.uniforms.turbidity.value = 6.0;
  sky.material.uniforms.rayleigh.value = 2.2;
  sky.material.uniforms.mieCoefficient.value = 0.006;
  sky.material.uniforms.mieDirectionalG.value = 0.82;
  sky.material.uniforms.sunPosition.value.copy(dir).multiplyScalar(45000 * 0.9);

  // No clouds. The vendored Sky ships an fbm cloud layer on by default
  // (coverage 0.4) whose `time` uniform nothing in this renderer drives, so what
  // it actually produces is one frozen noise field — an invented cloudscape over
  // a specific hour of a specific day, held still. There is no weather record
  // for 1 July 1835; drawing no clouds claims less than drawing those, so the
  // layer is switched off rather than animated.
  sky.material.uniforms.cloudCoverage.value = 0.0;
  sky.material.uniforms.cloudDensity.value = 0.0;

  // The sky's own exposure (see SKY_EXPOSURE). Patched into the vendored shader
  // rather than forked: vendor/ is read-only and pinned by sha256 in
  // vendor/MANIFEST, so this marker cannot move underneath us without a
  // deliberate three bump — and if a bump ever does move it, say so out loud
  // instead of silently rendering the white sky again.
  sky.material.uniforms.skyExposure = { value: sceneSkyExposure };
  sky.material.uniforms.horizonAmount = {
    value: new THREE.Vector2(HORIZON_RESTORE.redAmount, HORIZON_RESTORE.greenAmount),
  };
  sky.material.uniforms.horizonScale = {
    value: new THREE.Vector2(HORIZON_RESTORE.redScale, HORIZON_RESTORE.greenScale),
  };
  sky.material.uniforms.horizonPower = { value: HORIZON_RESTORE.power };
  // T-3331 — twilight and night. The sky model goes black once the sun is 2.3°
  // under the horizon (the vendored shader's cutoffAngle), so below it the sky is
  // its own term: a night sky graded zenith to horizon, and the glow on the horizon
  // toward the sun through twilight. Both amounts are exactly 0 from 6° up, so a
  // daytime sky is the shipped sky to the bit (time-of-day.js gradeAt).
  sky.material.uniforms.nightAmount = { value: 0 };
  sky.material.uniforms.glowAmount = { value: 0 };
  sky.material.uniforms.nightZenith = { value: new THREE.Vector3(...NIGHT_SKY_ZENITH) };
  sky.material.uniforms.nightHorizon = { value: new THREE.Vector3(...NIGHT_SKY_HORIZON) };
  sky.material.uniforms.twilightGlow = { value: new THREE.Vector3(...TWILIGHT_GLOW) };

  const skyFrag = sky.material.fragmentShader;
  const declared = skyFrag.replace('uniform float time;', /* glsl */`uniform float time;
		uniform float skyExposure;
		uniform vec2 horizonAmount;
		uniform vec2 horizonScale;
		uniform float horizonPower;
		uniform float nightAmount;
		uniform float glowAmount;
		uniform vec3 nightZenith;
		uniform vec3 nightHorizon;
		uniform vec3 twilightGlow;`);
  // `direction` is the vendored shader's own view ray, already normalised, so
  // direction.y IS sin(elevation) and no trig is needed. Clamped at 0 because
  // the box is drawn below the horizon too and a negative elevation would run
  // the exponential the wrong way; the sliver of sky under the horizontal is
  // a tenth of a degree at eye height and the ground covers it.
  const patched = declared.replace('gl_FragColor = vec4( texColor, 1.0 );', /* glsl */`
			// Restore the wavelength dependence Preetham's saturated (1 - Fex)
			// term loses at the horizon. See HORIZON_RESTORE. Red and green only:
			// the blue channel already matches the reference photograph.
			vec2 chiFade = exp( -pow( max( direction.y, 0.0 ) / horizonScale, vec2( horizonPower ) ) );
			texColor.rg *= max( vec2( 0.0 ), vec2( 1.0 ) - horizonAmount * chiFade );

			vec3 chiOut = texColor * skyExposure;
			// T-3331 — the night sky and the twilight glow (see nightAmount above).
			float chiUp = max( direction.y, 0.0 );
			vec2 chiSunH = vSunDirection.xz;
			vec2 chiDirH = direction.xz;
			float chiToward = 0.5 + 0.5 * dot( chiDirH, chiSunH )
				/ max( length( chiDirH ) * length( chiSunH ), 1e-4 );
			chiOut += nightAmount * mix( nightHorizon, nightZenith, sqrt( chiUp ) );
			chiOut += glowAmount * twilightGlow * chiToward * chiToward * chiToward * exp( -chiUp * 6.0 );

			gl_FragColor = vec4( chiOut, 1.0 );`);
  if (!patched.includes('nightAmount * mix')) {
    problems.push('world: the night sky could not be patched into the sky shader; night will draw a black sky');
  }
  sky.material.fragmentShader = patched;
  // Both markers are load-bearing and they fail differently: without the first
  // the sky renders at the model's arbitrary scale (a white wash at every
  // elevation), without the second it renders Preetham's white horizon under a
  // correctly exposed zenith. Check them separately so the message names the
  // one that actually broke rather than guessing.
  const lost = [];
  if (declared === skyFrag) lost.push('the exposure uniform (the sky will read as a white wash)');
  if (patched === declared) lost.push('the horizon restore (the skyline will read grey, not blue)');
  if (lost.length) {
    const said = `world: the vendored Sky shader no longer carries ${lost.join(' or ')}`;
    problems.push(said);
    // Also to the console, because the caller is not obliged to pass a collector
    // and a silent fallback to the white sky is exactly the failure this guards.
    console.warn(`[4D Chicago] ${said}`);
  }
  sky.material.needsUpdate = true;
  scene.add(sky);

  // The sky IS the environment. One PMREM pass at boot; nothing animates it.
  //
  // The sun disc MUST be switched off for that pass. Its radiance runs to five
  // or six figures in linear space, which overflows the half-float cube target
  // PMREM blurs through; the overflow becomes Inf, the blur turns Inf into NaN,
  // and a NaN environment map makes every lit surface in the scene render pure
  // black while the sky itself — an unlit shader — keeps looking fine. That is
  // a genuinely baffling failure to debug from the symptom, so it is written
  // down here rather than rediscovered. The disc goes straight back on for the
  // real render, where tone mapping handles it.
  const light = new THREE.DirectionalLight(0xfff2dc, 3.0);
  light.name = 'sun';
  light.castShadow = true;
  light.position.copy(dir).multiplyScalar(320);
  light.target.position.set(0, 0, 0);
  scene.add(light);
  scene.add(light.target);

  // One shadow camera that follows the walker, and its reach is what decides how
  // much of the town can cast a shadow at all — ROADMAP R-W3b(a).
  //
  // IT USED TO BE +/-60 m, on the reasoning that this covers what you can resolve
  // on foot. Measured on the published mirror at eight anchors, that box holds
  // **5 to 8 of the town's 331 structures and 0 to 41 of its 730 stems**: from
  // South Water Street 8 buildings and 12 trees cast a shadow and the other 323
  // and 718 meet the ground with nothing under them. The mid-field town and the
  // whole river timber were floating, and no amount of light fixes that, because
  // the geometry was being clipped out of the depth map before it was drawn.
  //
  // 120 m doubled the reach and the map doubled with it, so THE TEXEL SIZE WAS
  // UNCHANGED — 11.7 cm on desktop, 23.4 cm on a phone, exactly what the old rig
  // resolved. Nothing a visitor stands next to got softer to buy it.
  //
  // R-W3b(a) STOPPED AT 120 m FOR ONE REASON, and it was not resolution: **the
  // reach is draw-call-bound, not fill-bound.** Every batch that enters the box
  // is another draw call in the shadow pass, and the budget is 80. Measured then
  // at the worst station (`green_tree`): 70 calls at 60 m, 74 at 120, 78 at 150
  // and **exactly 80 at 180** — the ceiling, with the town still two thirds
  // outside the box. It named the two routes past it: fewer batches (R-W5a2) or
  // true cascades (R-W3b(b)).
  //
  // **240 m, 2026-08-17 — R-W5a2 took the first route and the ceiling moved.**
  // Carrying roughness per vertex collapsed the town's 16 building batches to
  // ONE, which is one call saved in the colour pass and one saved in the shadow
  // pass for every batch that was entering the box. Re-measured on the published
  // mirror, same instrument, same anchors: `green_tree` reads **48 calls at
  // ±120 m and 50 at ±240**, `south_water` 40 and 41, `forks` 47 and 47 — against
  // the 74 the same station read before the merge. The reach doubled again and
  // the frame is 30 calls under budget instead of 6.
  //
  // WHY 240 AND NOT MORE, and it is a resolution answer this time rather than a
  // budget one. The map has to double with the box or the texel grows, and 4096²
  // is the largest map worth asking a browser for: 2·240/4096 is **11.7 cm**, the
  // same texel this rig has resolved since R-W3b(a), and 2·240/2048 is **23.4 cm**
  // on a phone, likewise unchanged. ±360 m would need 6144² to hold that, or it
  // buys its reach by blurring the eave shadow a visitor is standing under —
  // which is the trade R-W3b(a) refused and this parcel is not reopening. Past
  // here the honest route is still R-W3b(b), true cascades, which spends texels
  // where they are looked at instead of spreading them evenly over 480 m.
  const half = SHADOW_REACH_M;
  const cam = light.shadow.camera;
  cam.left = -half; cam.right = half; cam.top = half; cam.bottom = -half;
  cam.near = 1; cam.far = 900;
  cam.updateProjectionMatrix();
  // 4096 over a 480 m frustum is 11.7 cm per texel — the same figure the 2048
  // over 240 m carried, and the 1024 over 120 m before that. The phone's map
  // doubles too, for the same reason and the same result. `bias` and
  // `normalBias` below are in world units and are calibrated to the TEXEL, not
  // to the reach, which is why holding the texel size is what lets them stand.
  const baseMap = lowSpec ? 2048 : 4096;
  light.shadow.mapSize.setScalar(baseMap);
  // -0.0004 and 0.045 m at 4096 over ±240 m; a lowSpec device's 2048 gets twice
  // both, and `setShadowRig` re-derives them for each tier's map (T-3054).
  Object.assign(light.shadow, shadowBiasFor((2 * half) / baseMap));

  // THE FILL. One PMREM at boot, and it IS the fill — there is no hemisphere
  // light any more. See GROUND_REFLECTANCE for why the environment is built with
  // a ground in it, and why a sky-only environment is what swamped albedo the
  // last time this was tried.
  //
  // THE SUN DISC MUST BE SWITCHED OFF for the pass. Its radiance runs to five or
  // six figures in linear space, which overflows the half-float cube target
  // PMREM blurs through; the overflow becomes Inf, the blur turns Inf into NaN,
  // and a NaN environment map makes every lit surface in the scene render pure
  // black while the sky itself — an unlit shader — keeps looking fine. That is a
  // genuinely baffling failure to debug from the symptom, so it is written down
  // here rather than rediscovered. The disc goes straight back on for the real
  // render, where the direct sun is the directional light above and tone mapping
  // handles the disc.
  const reflectance = new THREE.Color(GROUND_REFLECTANCE);
  // L = reflectance * E_h / PI, with E_h the sun's horizontal term plus the
  // measured sky fill. Written straight into the working colour space: this is a
  // radiance, not a colour anyone authored, and pushing it through the sRGB
  // transfer would darken it by a factor of three for no reason.
  // T-3331: the key's own height (the sun's, or by night the night key's) and the
  // fill's share at this hour (1 by day, so the daytime dome is unchanged).
  const groundRadianceFor = (keyElevationDeg, fillK = 1) => {
    const sunHorizontal = new THREE.Color(light.color).multiplyScalar(
      light.intensity * Math.max(0, Math.sin(keyElevationDeg * DEG)));
    return new THREE.Color().setRGB(
      reflectance.r * (sunHorizontal.r + FILL_UP[0] * fillK) / Math.PI,
      reflectance.g * (sunHorizontal.g + FILL_UP[1] * fillK) / Math.PI,
      reflectance.b * (sunHorizontal.b + FILL_UP[2] * fillK) / Math.PI,
      THREE.LinearSRGBColorSpace,
    );
  };
  const groundRadiance = groundRadianceFor(sun.elevationDeg);

  // The lower hemisphere, seen from inside. `renderOrder` is load-bearing: the
  // Sky shader forces its own depth to the far plane and writes no depth, so the
  // dome has to be drawn FIRST for the depth test to keep the sky off the ground
  // half. Drawn second, it would be a sphere painted over a sky that had already
  // won every pixel.
  const groundGeo = new THREE.SphereGeometry(
    1, 24, 8, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2);
  const groundMat = new THREE.MeshBasicMaterial({
    color: groundRadiance, side: THREE.BackSide, fog: false, toneMapped: false,
  });
  const groundDome = new THREE.Mesh(groundGeo, groundMat);
  groundDome.renderOrder = -1;
  // T-2481: baked again whenever the Season setting moves the sun.
  // T-3728 (Bill's PC, 2026-11-23): ONE generator, kept. A new one each bake made its
  // blur and filtering shaders afresh and `dispose` let their programs go, so every Season
  // or hour change (a jaunt's own season, at its start) linked them again inside the frame:
  // about 1.3 s of the jaunt start on the UHD 630. Kept, the second bake is draws only.
  const pmrem = new THREE.PMREMGenerator(renderer);
  const bakeEnvironment = () => {
    const envScene = new THREE.Scene();
    const skyParent = sky.parent;
    sky.material.uniforms.showSunDisc.value = false;
    envScene.add(groundDome);
    envScene.add(sky);
    const rt = pmrem.fromScene(envScene);
    skyParent.add(sky);
    sky.material.uniforms.showSunDisc.value = true;
    return rt;
  };
  let envRT = bakeEnvironment();

  scene.environment = envRT.texture;
  scene.environmentIntensity = ENV_INTENSITY;

  /**
   * THE FILL, STATED — because one important surface cannot read it.
   *
   * `scene.environment` reaches `MeshStandardMaterial` and nothing else: three
   * applies a scene environment only to the physical materials, so the terrain,
   * the streets, the buildings and the near timber receive this fill and the
   * sward does not — `flora.js` draws with `MeshLambertMaterial` and its own
   * shader, and it used to find the hemisphere light by traversing the scene.
   *
   * Removing the hemisphere light would therefore have darkened the prairie by
   * the whole of its fill while every other surface was merely getting the same
   * light from a better-shaped source. So the fill is published here as a value
   * rather than left to be sniffed out of the light list, and flora.js reads it.
   * It is the fill as installed, so the sward and the town are lit by one sky.
   * It is the sky's own fill, so the sward moves with the town rather than
   * staying lit by a fill the town no longer has. That is a real change to the
   * prairie and a stated one, measured in docs/STATUS.md with this phase's
   * frames — not a silent re-tune of a layer calibrated by another phase.
   */
  scene.userData.chiSkyFill = FILL_UP.slice();

  // Aerial perspective. Exponential-squared rather than the linear ramp it
  // replaces, because linear fog starts at nothing and then turns on: with
  // near 340 / far 1500 the whole walkable town sat at exactly zero haze and the
  // ground at 400 m was the same colour as the ground at 3 m, which is what the
  // baseline showed. Exp2 has no near plane — it is small everywhere and never
  // zero, so distance reads continuously.
  //
  // The colour is HORIZON_HAZE — the photograph's own horizon sky. Distance
  // goes toward the AIR, and the air over a July plain is blue; the prairie's
  // green survives in the mix because the fog only reaches 95 % at the far edge
  // of what is drawn, not because the fog itself is green. See the constant for
  // what the green-tinted haze it replaces did to the horizon.
  scene.fog = new THREE.FogExp2(HORIZON_HAZE, sceneJson.id === '1871' ? CITY_HAZE_DENSITY : HAZE_DENSITY);

  // The haze COLOUR is not this constant for long: `aim()` below replaces it
  // every time the view turns far enough, with the colour this scene's own sky
  // is at the horizon the visitor is looking at. See HORIZON_RING. The constant
  // is what the fog is installed with, what it falls back to if the ring cannot
  // be sampled, and the solar-side reading the ring is checked against.
  let ring = sampleHorizonRing(renderer, sky, problems, isHorizonReference(sunDate, sunTime));

  const offset = new THREE.Vector3();
  const lastFollow = new THREE.Vector3();
  const shadowRig = {
    reachM: half,
    mapSize: light.shadow.mapSize.x,
    texelM: (2 * half) / light.shadow.mapSize.x,
    /** R-BUG6. Whether `follow` quantises the box onto its own texel grid. */
    snapped: true,
  };

  /**
   * R-BUG6 — THE SHADOW BOX MOVES IN WHOLE TEXELS, NOT WITH THE WALKER.
   *
   * The box follows the visitor, so before this it was re-centred on their exact
   * position every frame. A shadow map is a raster: its samples are a lattice
   * fixed to the box, so sliding the box by a fraction of a texel re-quantises
   * every shadow edge in the scene at once. Nothing in the world moved and every
   * boundary is redrawn slightly differently — which is what a visitor sees as
   * crawl along an eave line. Measured with the camera held perfectly still and
   * the box slid half a texel (`measure_river_edge.mjs --box-drift`): 2,023
   * changed pixels at `from_above` and 5,650 at `descend_main_stem`, both **0**
   * with the rounding below. The 2 mm nudge that opened R-BUG6 sees only 1.7 % of
   * this, because 2 mm is 1.7 % of a texel — see that parcel's finding 3 before
   * measuring a shadow box by moving a camera.
   *
   * The fix is the standard one and it is arithmetic rather than a tuning: round
   * the centre onto a world-anchored lattice of the box's OWN texel size, in the
   * light's own plane. Two consequences worth stating:
   *
   *   - the offset is at most half a texel — 5.9 cm on desktop, 11.7 cm on a
   *     phone — so no shadow moves anywhere a visitor could measure it, and
   *     nothing about the reach, the map size or the texel size changes;
   *   - the rounding is in LIGHT space, on the two axes of the map, so the box
   *     never moves along the sun's direction. Depth is untouched, which is what
   *     keeps `bias` and `normalBias` calibrated to the texel the way the block
   *     above says they are.
   *
   * The lattice has to be anchored to the world rather than to the walker, or
   * the rounding would simply follow them and quantise nothing.
   */
  const snapRight = new THREE.Vector3();
  const snapUp = new THREE.Vector3();
  const snapBasis = () => {
    // The basis three itself will use: the shadow camera is placed at the light
    // and aimed at the target, so its right and up axes are fixed as long as the
    // sun is (the sun here is one date and one time — see the module header).
    const basis = new THREE.Matrix4().lookAt(
      dir.clone().multiplyScalar(320), new THREE.Vector3(), cam.up,
    );
    snapRight.setFromMatrixColumn(basis, 0);
    snapUp.setFromMatrixColumn(basis, 1);
  };
  snapBasis();
  const snapCentre = new THREE.Vector3();
  function centreFor(position) {
    snapCentre.set(position.x, 0, position.z);
    if (!shadowRig.snapped) return snapCentre;
    const texel = shadowRig.texelM;
    const e = snapCentre.dot(snapRight);
    const u = snapCentre.dot(snapUp);
    return snapCentre
      .addScaledVector(snapRight, Math.round(e / texel) * texel - e)
      .addScaledVector(snapUp, Math.round(u / texel) * texel - u);
  }
  let brightness = 0;
  // The haze's own state: which of the ring's 36 bearings the fog is currently
  // set to, so `aim()` writes a uniform when the view has actually turned that
  // far and not once per frame.
  let hazeSlot = -1;

  // T-3331 — THE RELIGHT. One function takes the sun (date and hour) to every
  // number the frame is lit by: the sky's sun and its night and twilight terms, the
  // key light (the sun, or by night the night key), the fill's share, the ground
  // dome, the exposure the dark-adapted eye adds, and the grade the unlit layers
  // are told. time-of-day.js gradeAt holds the curves; from 14° up every factor is
  // its identity, so the scene's own hour draws the shipped frame.
  const SUN_COLOR = new THREE.Color(0xfff2dc);
  const SUN_INTENSITY = 3.0;
  const lowSun = new THREE.Color(LOW_SUN_COLOR);
  const nightColor = new THREE.Color(NIGHT_KEY_COLOR);
  const skySun = new THREE.Vector3();
  let grade = gradeAt(sun.elevationDeg);
  let keyElevation = sun.elevationDeg;
  const exposureNow = () => BASE_EXPOSURE * (2 ** (brightness * BRIGHT_EXPOSURE_SHARE)) * grade.adapt;
  // T-3428: the aid's fill lift, and what the sky and the haze are scaled by so they
  // rise by the sky's share only (the exposure would otherwise carry them its whole
  // share). All three are exactly 1 at 0.
  const fillLift = () => 2 ** (brightness * BRIGHT_FILL_SHARE);
  const skyHold = () => 2 ** (brightness * (BRIGHT_SKY_SHARE - BRIGHT_EXPOSURE_SHARE));
  // The environment bake and the horizon sample read the sky as calibrated, never
  // through the aid's hold, or the fill and haze baked from it would carry it twice.
  const atCalibratedSky = (fn) => {
    const u = sky.material.uniforms.skyExposure;
    const held = u.value;
    u.value = sceneSkyExposure;
    try { return fn(); } finally { u.value = held; }
  };
  function applyGrade() {
    grade = gradeAt(sun.elevationDeg);
    sunDirection(sun.azimuthDeg, sun.elevationDeg, skySun);
    sky.material.uniforms.sunPosition.value.copy(skySun).multiplyScalar(45000 * 0.9);
    sky.material.uniforms.nightAmount.value = grade.night;
    sky.material.uniforms.glowAmount.value = grade.glow;
    sky.material.uniforms.nightZenith.value.set(...NIGHT_SKY_ZENITH)
      .lerp(new THREE.Vector3(...DUSK_SKY_ZENITH), grade.dusk);
    sky.material.uniforms.nightHorizon.value.set(...NIGHT_SKY_HORIZON)
      .lerp(new THREE.Vector3(...DUSK_SKY_HORIZON), grade.dusk);
    scene.environmentIntensity = ENV_INTENSITY * grade.envBoost * fillLift();
    sky.material.uniforms.skyExposure.value = sceneSkyExposure * skyHold();
    if (grade.sunK > 0) {
      // A sun on the horizon is held a degree up for the shadow map: a light from
      // under the ground plane would cast every shadow through it.
      keyElevation = Math.max(sun.elevationDeg, 1.0);
      sunDirection(sun.azimuthDeg, keyElevation, dir);
      light.color.copy(SUN_COLOR).lerp(lowSun, grade.warm);
      light.intensity = SUN_INTENSITY * grade.sunK;
    } else {
      keyElevation = NIGHT_KEY_ELEVATION;
      sunDirection(NIGHT_KEY_AZIMUTH, NIGHT_KEY_ELEVATION, dir);
      light.color.copy(nightColor);
      light.intensity = NIGHT_KEY * grade.nightK;
    }
    scene.userData.chiSkyFill = FILL_UP.map((v) => v * grade.fillK * fillLift());
    groundMat.color.copy(groundRadianceFor(keyElevation, grade.fillK));
    renderer.toneMappingExposure = exposureNow();
    // What an unlit, display-space layer should be multiplied by: the light on a
    // level surface against a 30° sun, through the eye's adaptation, as a display
    // value. Exactly 1 whenever the sun is fully up and the fill whole.
    let display = 1;
    if (grade.sunK < 1 || grade.fillK < 1) {
      const flat = light.intensity * Math.max(0, Math.sin(keyElevation * DEG)) + 0.9 * grade.fillK;
      const ref = SUN_INTENSITY * 0.5 + 0.9;
      display = Math.min(1, Math.pow(Math.max(0, flat / ref) * grade.adapt, 1 / 2.2));
    }
    // A changed lift has to reach the haze too: forget the slot so the next aim() writes it.
    hazeSlot = -1;
    publishDaylight({
      display, grade, elevationDeg: sun.elevationDeg, sunTime, sunDate, lift: fillLift(),
    });
  }
  applyGrade();
  const aimForward = new THREE.Vector3();

  return {
    sky, light,
    get sun() { return sun; },
    get direction() { return dir.clone(); },
    /** The sampled horizon sky, or null where the sampler could not read it. */
    get horizonRing() { return ring; },
    /**
     * Point the haze at the sky the visitor is looking at — T-1631, and see
     * HORIZON_RING above for why the fog cannot be one colour.
     *
     * Called once a frame from the render loop, after the walker has moved the
     * camera and before anything is submitted. It is a bearing, a table index
     * and — only when the index moved — a colour copy, so standing still costs
     * nothing and a full turn costs 36 uniform writes.
     *
     * @param {THREE.Camera} camera the camera about to render
     * @returns {boolean} whether the haze colour changed this frame
     */
    aim(camera) {
      if (!ring || !camera || !scene.fog) return false;
      camera.getWorldDirection(aimForward);
      // Bearing from the renderer's north (-Z), the same mapping the sampler
      // used. atan2 of (east, north) rather than of the raw axes, so a camera
      // looking straight down still yields the bearing it is facing.
      const bearing = Math.atan2(aimForward.x, -aimForward.z);
      const turns = bearing / (Math.PI * 2);
      const slot = ((Math.round(turns * HORIZON_RING_STEPS) % HORIZON_RING_STEPS)
        + HORIZON_RING_STEPS) % HORIZON_RING_STEPS;
      if (slot === hazeSlot) return false;
      hazeSlot = slot;
      scene.fog.color.copy(ring[slot]).multiplyScalar(skyHold());
      return true;
    },
    /** The environment map this rig installed, and the fill it delivers. */
    get environment() { return envRT.texture; },
    skyFill: FILL_UP.slice(), envIntensity: ENV_INTENSITY,
    /**
     * R-W3b(a). The shadow rig as a claim rather than as three internals: how
     * far from the visitor a shadow can be cast, and how coarsely it is
     * resolved. A gate reading `light.shadow.camera.right` reads the same
     * number, but reading it here is reading what this module MEANT.
     */
    shadowRig,
    /**
     * Harness only — set the reach and report what took effect.
     *
     * It exists because of R-A1's finding: an assertion that the rig carries a
     * documented reach passes identically whether the reach reaches the screen
     * or reaches nothing. The gate winds the reach back to the pre-R-W3b(a)
     * ±60 m, photographs the same held frame and requires it to CHANGE — which
     * is a thing you cannot ask without being able to move the number.
     */
    setShadowReach(metres) {
      const r = Math.max(1, Number(metres) || 0);
      cam.left = -r; cam.right = r; cam.top = r; cam.bottom = -r;
      cam.updateProjectionMatrix();
      light.shadow.needsUpdate = true;
      shadowRig.reachM = r;
      shadowRig.texelM = (2 * r) / light.shadow.mapSize.x;
      return r;
    },
    /**
     * THE SCENE-DETAIL RIG — T-0115. The reach AND the map together, so the
     * TEXEL is what stays fixed.
     *
     * `setShadowReach` above moves the box and leaves the map alone, which is
     * exactly what the gate's liveness check wants: wind the reach back, watch
     * the frame change, wind it forward. It is the wrong instrument for a
     * detail level, because a level that halves the box and keeps a 4096² map
     * pays the same fill and the same memory for a smaller shadow — it buys
     * nothing except a shorter reach. Halving the map with the box is what
     * makes the step affordable, and it holds the one number the block by
     * `light.shadow` says must hold: 2·120/2048 is 11.7 cm on desktop and
     * 2·120/1024 is 23.4 cm on a phone, both the texel this rig has resolved
     * since R-W3b(a). Nothing a visitor stands next to gets softer; what the
     * step costs is reach, and it costs it where the visitor asked for a
     * cheaper frame.
     *
     * @param {number} metres half-width of the box, in metres
     * @returns {{reachM:number, mapSize:number, texelM:number}} what took effect
     */
    setShadowRig(metres) {
      const r = Math.max(1, Number(metres) || 0);
      const map = Math.max(512, Math.round(baseMap * (r / SHADOW_REACH_M)));
      cam.left = -r; cam.right = r; cam.top = r; cam.bottom = -r;
      cam.updateProjectionMatrix();
      if (map !== light.shadow.mapSize.x) {
        // A shadow map is sized at allocation, so the old render target has to
        // go before three will build one at the new size. Disposing without
        // clearing the handle leaves three re-using a destroyed texture.
        light.shadow.mapSize.setScalar(map);
        light.shadow.map?.dispose();
        light.shadow.map = null;
      }
      light.shadow.needsUpdate = true;
      shadowRig.reachM = r;
      shadowRig.mapSize = map;
      shadowRig.texelM = (2 * r) / map;
      // T-3054: the biases hold their fraction of the texel the map just took.
      Object.assign(light.shadow, shadowBiasFor(shadowRig.texelM));
      return { reachM: r, mapSize: map, texelM: shadowRig.texelM };
    },
    /**
     * K24. The visitor's brightness aid, in stops above the calibrated grade.
     *
     * T-3428: up to two stops (4x), split between the exposure, the sky fill and
     * a hold on the sky — see BASE_EXPOSURE. It moves no material and no record,
     * so it cannot become a second reconstruction, and dropping it back to 0
     * returns the calibrated frame exactly, which is the third assertion the
     * smoke takes of it.
     *
     * @param {number} stops 0 = calibrated, clamped to [0, MAX_BRIGHTNESS_STOPS]
     */
    setBrightness(stops) {
      const s = Math.min(MAX_BRIGHTNESS_STOPS, Math.max(0, Number(stops) || 0));
      if (s === brightness) return s;
      brightness = s;
      applyGrade();
      return s;
    },
    /** The aid's current position, so a gate can assert it rather than assume it. */
    get brightness() { return brightness; },
    /** The calibrated position, named so the HUD does not restate the number. */
    baseExposure: BASE_EXPOSURE,
    maxBrightnessStops: MAX_BRIGHTNESS_STOPS,
    /** Keep the shadow frustum on the walker, quantised onto its own texel grid
     *  (R-BUG6 — see `centreFor`). Cheap; call every frame. */
    follow(position) {
      lastFollow.copy(position);
      light.target.position.copy(centreFor(position));
      light.target.updateMatrixWorld();
      offset.copy(dir).multiplyScalar(320);
      light.position.copy(light.target.position).add(offset);
      light.updateMatrixWorld();
    },
    /**
     * Harness only — R-BUG6's own liveness handle, and it exists for the reason
     * R-A1 wrote down: "the box did not move" passes identically on a rig that
     * quantises and on a rig whose `follow` is never called, so the gate takes
     * the same millimetre with this off and requires the box to MOVE. It is also
     * how `--box-drift` photographs the before state on the shipped build.
     */
    setShadowSnap(on) {
      shadowRig.snapped = !!on;
      light.shadow.needsUpdate = true;
      return shadowRig.snapped;
    },
    describe() {
      return `sun ${sun.elevationDeg.toFixed(1)}° up, bearing ${sun.azimuthDeg.toFixed(1)}°`
        + ` (${sunTime} local mean time, ${sunDate})`;
    },
    /** The date the sun is computed for: the scene's own, unless the Season setting moved it. */
    get sunDate() { return sunDate; },
    /** T-3331: the hour the sun is computed for, 'HH:MM' local mean solar time. */
    get sunTime() { return sunTime; },
    /** The scene's own hour, which the Time of day's `daytime` names. */
    sceneTime,
    /** T-3331: the grade in force (time-of-day.js gradeAt) and the exposure the eye adds. */
    get grade() { return grade; },
    /**
     * T-3331 — a Time of day value ('HH:MM' or a name) as the clock time it stands
     * for on `date` (default the date in force): daybreak and sunset are solved
     * against that date's sun.
     */
    resolveTime(value, date = sunDate) {
      const elevationAt = (min) => solarPosition({
        lat: datum.origin_lat, lon: datum.origin_lon, date,
        localMeanTime: `${Math.floor(min / 60)}:${min % 60}`,
      }).elevationDeg;
      return resolveTime(value, { sceneTime, elevationAt });
    },
    /**
     * T-2481 + T-3331 — move the sun to a date and an hour: its bearing and height,
     * the sky, the key, the fill baked from them, the horizon haze sampled off that
     * sky and the shadow lattice. One PMREM bake and one horizon sample, on a
     * change only.
     * @param {object} o
     * @param {string} [o.date] 'YYYY-MM-DD'; empty is the scene's own date; undefined keeps it
     * @param {string} [o.time] 'HH:MM'; empty is the scene's own hour; undefined keeps it
     * @returns {boolean} whether anything moved
     */
    setSun({ date, time } = {}) {
      const wantDate = date === undefined ? sunDate : (date || sceneJson.target_date);
      const wantTime = time === undefined ? sunTime
        : (minutesOf(time) !== null ? time : sceneTime);
      if (wantDate === sunDate && wantTime === sunTime) return false;
      sunDate = wantDate;
      sunTime = wantTime;
      sun = solarPosition({
        lat: datum.origin_lat, lon: datum.origin_lon, date: sunDate, localMeanTime: sunTime,
      });
      applyGrade();
      const old = envRT;
      envRT = atCalibratedSky(bakeEnvironment);
      scene.environment = envRT.texture;
      old.dispose();
      // A scene's own hour is not necessarily the measured July 1835 timestamp.
      // Keep its guard exactly there; every other sky supplies its own haze.
      ring = atCalibratedSky(() => sampleHorizonRing(renderer, sky, [], isHorizonReference(sunDate, sunTime))) ?? ring;
      hazeSlot = -1;
      snapBasis();
      this.follow(lastFollow);
      light.shadow.needsUpdate = true;
      return true;
    },
    /** T-2481 — the Season's date, at the hour in force. */
    setSunDate(date) { return this.setSun({ date: date || '' }); },
    /** T-3331 — the Time of day's hour, on the date in force. */
    setSunTime(time) { return this.setSun({ time: time || '' }); },
    dispose() {
      envRT.dispose();
      pmrem.dispose();
      groundGeo.dispose();
      groundMat.dispose();
      sky.geometry.dispose();
      sky.material.dispose();
    },
  };
}
