/**
 * device-profile.js — read what the device offers, then choose per device.
 *
 * T-2559. The owner, 2026-10-16: *"if there is a way to tap into local
 * computing resources for rendering based on the browser and platform"*. Until
 * this the renderer knew one thing about the device — whether it has a touch
 * screen — so a 2026 iPad Pro and a five-year-old Android phone both booted
 * `light` at Sharpness Low, and a weak laptop booted `full`.
 *
 * Run once at boot, before the scene is fetched:
 *
 *  1. READ what the platform says: WebGPU (`navigator.gpu`, its adapter's info
 *     and limits), the WebGL2 renderer string, MAX_TEXTURE_SIZE, the
 *     compressed formats (ASTC / ETC2 / BC7 — T-2551 needs the same answer),
 *     `hardwareConcurrency`, `deviceMemory` (Chromium only, a hint), screen
 *     pixels and `devicePixelRatio`.
 *  2. MEASURE for at most a second: a fill and a vertex pass on an offscreen
 *     target, timed with EXT_disjoint_timer_query_webgl2 where the browser
 *     exposes it and by the wall clock across a pixel read otherwise.
 *  3. DECIDE a class — weak, standard or strong — and from the class and the
 *     platform the boot detail tier, Sharpness, texture tier (T-2551/T-2553),
 *     worker count (T-2556) and whether WebGPU is there for a later renderer
 *     (T-2558).
 *
 * The result is cached in localStorage keyed by the renderer string and the
 * build, so a repeat visit skips the benchmark. A forced profile is never
 * cached.
 *
 * THE VISITOR KEEPS THE LAST WORD. These are the defaults for a visitor who
 * never chose; a stored Scene detail or Image sharpness always wins (main.js
 * reads it first, as it did before), and Settings says what was chosen and why.
 *
 * DOCTRINE 5 HOLDS: a class moves flora, shadows, resolution and texture tier —
 * the existing detail ladder and the Sharpness stops — and never what is
 * reconstructed.
 *
 * WHAT IS NOT YET KNOWN, SAID PLAINLY. The benchmark's thresholds below are a
 * first setting, not a calibration: no reading from real phone or laptop
 * silicon was taken to set them, and they are to be moved when T-2546's meter
 * reports what the classes actually cost. The raw readings are kept on the
 * profile (`api.device.bench`) so that can be done from the field.
 *
 * A SOFTWARE RASTERISER IS NOT BENCHMARKED. SwiftShader and llvmpipe measure
 * the CPU, not a GPU, and they are the machine every one of this project's
 * frame and triangle ceilings is gated on: the platform default is, by that
 * gate, the one the budgets were set for there. So a software renderer keeps
 * the platform default as `standard`, with that reason written on the profile,
 * and pays no benchmark. `?device=weak` is the visitor's way down.
 */

/** The classes, weakest first. */
export const DEVICE_CLASSES = Object.freeze(['weak', 'standard', 'strong']);

/** localStorage key for the cached profile. */
export const PROFILE_KEY = 'chicago4d.device';

/** The benchmark's ceiling, and the measured passes' share of it. */
export const BENCH_BUDGET_MS = 1000;

/**
 * Thresholds on the measured rates. A FIRST SETTING (see the header): weak is
 * below the slower of the two floors, strong above both ceilings.
 *   fill: megapixels shaded per millisecond (1 Mpx/ms = 1 Gpx/s)
 *   verts: million vertices transformed per millisecond (Mvert/ms)
 */
export const THRESHOLDS = Object.freeze({
  fill: { weak: 0.6, strong: 4 },
  verts: { weak: 0.05, strong: 0.4 },
});

const SOFTWARE = /swiftshader|llvmpipe|softpipe|software|basic render|microsoft basic|mesa offscreen/i;

/** True when the renderer string names a software rasteriser. */
export function isSoftwareRenderer(renderer) {
  return SOFTWARE.test(String(renderer || ''));
}

/**
 * T-3537: AN INTEGRATED GPU HAS NO MEMORY OF ITS OWN. The owner's test PC (Dell
 * Inspiron 3880: i5-10400, Intel UHD Graphics 630, 12 GB) passed the benchmark as
 * `standard`, so the meter read it in the 70s and 1904 booted Full, and Chrome's tab
 * died ("Aw, Snap") on dev and prod. Its GPU is fast enough; what it lacks is memory:
 * the "128 MB" Windows reports is a carve-out, and every texture and vertex buffer
 * comes out of the same system RAM the tab's own arrays live in, so a desktop at Full
 * pays for each heavy layer twice from one pool (1904 Full read 1.17 GB here before
 * the driver's own copies). The benchmark cannot see that, and Chromium's
 * `deviceMemory` stops at 8, so the renderer string is the signal.
 *
 * Named here: Intel's UHD / HD / Iris graphics and the Arc graphics built into its
 * Core Ultra chips (a discrete Arc card names its model, A770 or B580, and is left
 * out); AMD's APUs ("Radeon(TM) Graphics", "Vega 8", "780M"); Qualcomm Adreno and
 * Arm Mali on Windows-on-Arm laptops and Chromebooks. Apple silicon is left out on
 * purpose: its memory is shared too, but a Mac is the machine the desktop budgets
 * were read on, and the owner's own Mac boots 1904 Full without a crash.
 */
const SHARED_GPU = [
  /\bintel\b[^,]*\b(?:u?hd|iris)\b/i,
  /\bintel\b[^,]*\barc(?:\(tm\))? graphics/i,
  /\bintel\b[^,]*\b(?:gma|graphics media accelerator)\b/i,
  /\bradeon(?:\(tm\))?(?: r[2-7])? graphics\b/i,
  /\bradeon(?:\(tm\))? vega \d+(?: mobile)? graphics\b/i,
  /\bradeon(?:\(tm\))? (?:\d{3}m|vega)\b/i,
  /\badreno\b/i,
  /\bmali\b/i,
  // T-3675: the PowerVR in MediaTek's older Chromebook chips (MT8173: "PowerVR Rogue GX6250").
  /\bpowervr\b/i,
];

/** True when the renderer string names an integrated GPU that shares the system's memory. */
export function sharesSystemMemory(renderer) {
  const r = String(renderer || '');
  if (!r || isSoftwareRenderer(r) || /\bapple\b/i.test(r)) return false;
  return SHARED_GPU.some((re) => re.test(r));
}

/**
 * T-3675: A CHROMEBOOK IS A COMPUTER. A classroom set is mostly low-end Chromebooks
 * (a Celeron with Intel UHD 600/605 or HD Graphics, or a MediaTek / Snapdragon chip
 * with Arm Mali, PowerVR or Adreno; 4 GB; 2-4 cores). Every Chromebook draws on
 * graphics that share its memory, and the only thing it shares with a phone is an
 * ARM GPU's name. So ChromeOS is read from the user agent ("CrOS") or Chrome's
 * userAgentData ("Chrome OS"), and a Chromebook is profiled as a computer even with a
 * touch screen or in tablet mode: `weak`, so Balanced at Sharpness Low, light
 * textures and the memory diet, people, horses, carriages and wagons all drawn (the
 * owner, 2026-11-10: Light is not a computer's floor). Its controls still follow its
 * pointer (touchDefault below), and a touch on the screen switches to touch controls.
 */
export function isChromeOS(ua, platform) {
  return /\bCrOS\b/.test(String(ua || '')) || /^chrome ?os$/i.test(String(platform || '').trim());
}

/**
 * Whether the touch controls are the default. Pure; controls/touch.js `prefersTouch`
 * reads the page into it. A coarse primary pointer, or a touch screen in a narrow window
 * (a phone that reports a fine pointer). On ChromeOS only the primary pointer counts: a
 * Chromebook with a touch screen in a half-screen window still has its keyboard and
 * trackpad, and in tablet mode its pointer is coarse.
 */
export function touchDefault({ coarse = false, maxTouchPoints = 0, width = 1024, chromeos = false } = {}) {
  if (chromeos) return !!coarse;
  return !!coarse || (maxTouchPoints > 0 && width < 900);
}

/** `?device=weak|standard|strong` — HARNESS ONLY: forces the class, never cached. */
export function forcedClass(search) {
  try {
    const v = new URLSearchParams(search || '').get('device');
    return DEVICE_CLASSES.includes(v) ? v : null;
  } catch { return null; }
}

/**
 * The class from what was read and measured. Pure, so it is tested in node.
 * Returns { cls, why }.
 */
export function classify(signals, bench, { forced = null, stepDown = 0, touch = false } = {}) {
  let cls;
  let why;
  if (forced) {
    cls = forced; why = `forced by ?device=${forced}`;
  } else if (!signals.webgl2) {
    cls = 'weak'; why = 'no WebGL2 context could be read';
  } else if (isSoftwareRenderer(signals.renderer) && signals.automated === false) {
    // T-3552: a real visitor drawing in software (Windows with no graphics driver in
    // use: "Microsoft Basic Render Driver"; graphics acceleration turned off) pays for
    // every texture in the tab's own memory and every pixel on the CPU, so it boots as
    // a modest computer: Balanced, its people and teams kept, on the memory diet. Only
    // a browser that says it is automated (the harness) keeps the platform default.
    cls = 'weak'; why = 'a software rasteriser: no graphics driver in use, not benchmarked';
  } else if (isSoftwareRenderer(signals.renderer)) {
    cls = 'standard'; why = 'a software rasteriser: the platform default, not benchmarked';
  } else if ((signals.cores && signals.cores <= 2) || (signals.memoryGB && signals.memoryGB <= 2)
    || (signals.maxTexture && signals.maxTexture < 4096)) {
    cls = 'weak';
    why = `few resources (${signals.cores ?? '?'} cores, ${signals.memoryGB ?? '?'} GB, `
      + `${signals.maxTexture ?? '?'} px textures)`;
  } else if (signals.chromeos) {
    // T-3675: whatever the benchmark reads, a Chromebook's graphics memory is its 4-8 GB of RAM.
    cls = 'weak';
    why = `a Chromebook: graphics sharing the system's memory (${shortGpu(signals.renderer)}`
      + `${signals.memoryGB ? `, ${signals.memoryGB} GB` : ''})`;
  } else if (!touch && sharesSystemMemory(signals.renderer)) {
    // T-3537: a phone keeps Light whatever its class, so only a computer is moved.
    cls = 'weak';
    why = `integrated graphics sharing the system's memory (${shortGpu(signals.renderer)})`;
  } else if (!bench || !Number.isFinite(bench.fill) || !Number.isFinite(bench.verts)) {
    cls = 'standard'; why = 'the benchmark gave no reading';
  } else if (bench.fill < THRESHOLDS.fill.weak || bench.verts < THRESHOLDS.verts.weak) {
    cls = 'weak'; why = `benchmark below the floor (${fmt(bench.fill)} Mpx/ms, ${fmt(bench.verts)} Mvert/ms)`;
  } else if (bench.fill >= THRESHOLDS.fill.strong && bench.verts >= THRESHOLDS.verts.strong
    && (signals.cores ?? 8) >= 6) {
    cls = 'strong'; why = `benchmark above the ceiling (${fmt(bench.fill)} Mpx/ms, ${fmt(bench.verts)} Mvert/ms)`;
  } else {
    cls = 'standard'; why = `benchmark between the bounds (${fmt(bench.fill)} Mpx/ms, ${fmt(bench.verts)} Mvert/ms)`;
  }
  // T-2547's crash marker: a device that ran out of memory last session steps down.
  const steps = Math.max(0, Math.floor(stepDown) || 0);
  if (steps) {
    const at = Math.max(0, DEVICE_CLASSES.indexOf(cls) - steps);
    if (DEVICE_CLASSES[at] !== cls) { cls = DEVICE_CLASSES[at]; why += `; stepped down ${steps} after a crash`; }
  }
  return { cls, why };
}

function fmt(n) { return Number.isFinite(n) ? n.toFixed(2) : '?'; }

/** "ANGLE (Intel, Intel(R) UHD Graphics 630 (0x00009BC8) Direct3D11 …)" → "Intel(R) UHD Graphics 630". */
export function shortGpu(renderer) {
  let s = String(renderer || '');
  const angle = s.match(/^ANGLE \((.*)\)$/);
  if (angle) { const parts = angle[1].split(', '); s = parts[1] || parts[0]; }
  s = s.replace(/^ANGLE Metal Renderer:\s*/, '').replace(/\s*\(0x[0-9a-f]+\)/gi, '')
    .replace(/\s+Direct3D.*$/i, '').replace(/\/PCIe\/SSE2/i, '')
    // T-3675: Mesa's prefix and chip codename on Linux and ChromeOS: "Mesa Intel(R) UHD Graphics 600 (GLK 2)".
    .replace(/^Mesa (?:DRI )?/i, '').replace(/\s*\([A-Z]{2,4}(?: GT)?\s?\d?\)$/, '').trim();
  return s || 'GPU not reported';
}

/**
 * What a class chooses, on a touch device or not. Pure.
 *
 * A phone or tablet starts at `light`, and since T-3542 a strong one at
 * `balanced` (measured: 1904 525 MB, 1835 677, 1812 470 on the phone meter,
 * against Light's 426 / 501 / 339), every phone still on the memory diet; a
 * phone that runs out of memory steps down (crash-guard.js). Light itself no
 * longer drops anything core: since the owner's ruling (2026-11-10) it draws
 * people to 140 m and keeps its horses, carriages and wagons, nearer. A weak desktop boots `balanced` at Low, and since T-3537 with the
 * phone's memory diet: `balanced` alone still held 1904's every page array beside
 * the GPU's copy (1,009 MB), and a weak computer is mostly one on integrated
 * graphics, whose GPU copy comes out of the same RAM. Not `light`: the owner,
 * 2026-11-10, "I didn't want to lose people at lower computer settings ... or
 * horses or carriages or wagons" — `light` then drew no horse or vehicle at all
 * (T-3542 since draws them nearer). Blurrier is the price instead: Sharpness Low and the
 * light texture tier. A strong desktop is drawn at High.
 */
export function decide(cls, { touch = false, cores = null, webgpu = false } = {}) {
  const c = DEVICE_CLASSES.includes(cls) ? cls : 'standard';
  const table = touch
    ? { weak: ['light', 1], standard: ['light', 1], strong: ['balanced', 1.5] }
    : { weak: ['balanced', 1], standard: ['full', 1.5], strong: ['full', 2] };
  const [detail, sharpness] = table[c];
  const textures = touch || c === 'weak' ? 'light' : 'full';
  const n = Number.isFinite(cores) && cores > 0 ? cores : 4;
  const workers = c === 'weak' ? 1 : Math.max(1, Math.min(c === 'strong' ? 6 : 4, n - 1));
  // T-3537: the phone's memory diet (main.js `lowMem`): release page arrays once the
  // GPU holds them, build layers lowSpec. Every phone, and a weak computer, which is
  // where integrated graphics land: their GPU memory is the tab's own system RAM.
  const lowMemory = touch || c === 'weak';
  return { detail, sharpness, textures, workers, webgpu: !!webgpu, lowMemory };
}

/** The words Settings shows. */
export const CLASS_LABEL = Object.freeze({ weak: 'modest', standard: 'standard', strong: 'strong' });
const DETAIL_LABEL = { full: 'Full', balanced: 'Balanced', light: 'Light' };
const SHARP_LABEL = { 1: 'Low', 1.5: 'Medium', 2: 'High' };

/** "Your device: strong desktop, chosen Full detail at High sharpness." */
export function describeProfile(profile) {
  if (!profile) return '';
  const kind = profile.headset ? 'VR headset' : profile.signals?.chromeos ? 'Chromebook'
    : profile.touch ? 'phone or tablet' : 'computer';
  const d = DETAIL_LABEL[profile.choice.detail] ?? profile.choice.detail;
  const s = SHARP_LABEL[profile.choice.sharpness] ?? String(profile.choice.sharpness);
  return `Your device: ${CLASS_LABEL[profile.cls] ?? profile.cls} ${kind}, chosen ${d} detail at ${s} sharpness.`;
}

/**
 * T-2901: the front door's device meter — one 0-100 number and five grades.
 *
 * Read from the SAME profile the town boots on, and clamped into the band of
 * the class that profile chose, so the meter never promises more than the
 * town will draw: weak 8-39 (Poor, Low), standard 40-79 (Fair, Good), strong
 * 76-99 (Good, Peak). Inside its band a device is placed by what was measured:
 * the benchmark's fill and vertex rates on a log scale (each class floor in
 * THRESHOLDS reads 40, each ceiling 80, so the two scales meet the bands), then
 * cores and memory. A software rasteriser, or a browser that gave no
 * benchmark, is placed on cores and memory alone.
 */
export const GRADES = Object.freeze([
  { id: 'poor', label: 'Poor', min: 0 },
  { id: 'low', label: 'Low', min: 20 },
  { id: 'fair', label: 'Fair', min: 40 },
  { id: 'good', label: 'Good', min: 60 },
  { id: 'peak', label: 'Peak', min: 80 },
]);
const CLASS_BAND = Object.freeze({ weak: [8, 39], standard: [40, 79], strong: [76, 99] });

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
function logScore(rate, floor, ceiling) {
  return Number.isFinite(rate) && rate > 0 ? 40 + 40 * Math.log(rate / floor) / Math.log(ceiling / floor) : null;
}

/** The grade a 0-100 score falls in. */
export function gradeOf(score) {
  let grade = GRADES[0];
  for (const g of GRADES) if (score >= g.min) grade = g;
  return grade;
}

/** { score, grade, basis: 'measured' | 'resources' } for a profile. Pure. */
export function scoreProfile(profile) {
  const cls = DEVICE_CLASSES.includes(profile?.cls) ? profile.cls : 'standard';
  const s = profile?.signals || {};
  const fill = logScore(profile?.bench?.fill, THRESHOLDS.fill.weak, THRESHOLDS.fill.strong);
  const verts = logScore(profile?.bench?.verts, THRESHOLDS.verts.weak, THRESHOLDS.verts.strong);
  // The slower of the two passes is the one a frame waits on, so it weighs more.
  const gpu = fill != null && verts != null
    ? clamp(0.6 * Math.min(fill, verts) + 0.4 * Math.max(fill, verts), 0, 100) : null;
  const cores = s.cores ? clamp(s.cores * 10, 10, 100) : null;
  // deviceMemory is Chromium's hint and stops at 8 GB, so 8 reads full.
  const memory = s.memoryGB ? clamp(s.memoryGB * 12.5, 10, 100) : null;
  const parts = [[gpu, 0.65], [cores, 0.2], [memory, 0.15]].filter(([v]) => v != null);
  const [lo, hi] = CLASS_BAND[cls];
  const weight = parts.reduce((a, [, w]) => a + w, 0);
  const raw = weight ? parts.reduce((a, [v, w]) => a + v * w, 0) / weight : (lo + hi) / 2;
  const score = Math.round(clamp(raw, lo, hi));
  return { score, grade: gradeOf(score), basis: gpu != null ? 'measured' : 'resources' };
}

/** The cache key: renderer string and build, so a new GPU or a new build re-measures. */
export function cacheKey(renderer, build) {
  return `${String(renderer || '?')}|${String(build || '?')}`;
}

/** The cached profile if it was measured on this renderer and build, else null. */
export function readCached(storage, key) {
  try {
    const raw = storage?.getItem(PROFILE_KEY);
    if (!raw) return null;
    const hit = JSON.parse(raw);
    return hit && (key == null || hit.key === key) && DEVICE_CLASSES.includes(hit.cls) ? hit : null;
  } catch { return null; }
}

// ---- reading the platform ---------------------------------------------------

function readGl(doc) {
  const out = { webgl2: false, renderer: '', vendor: '', maxTexture: null, formats: [], timer: false };
  let canvas;
  let gl;
  try {
    canvas = doc.createElement('canvas');
    canvas.width = 256; canvas.height = 256;
    gl = canvas.getContext('webgl2', { antialias: false, depth: false, stencil: false,
      preserveDrawingBuffer: false, powerPreference: 'high-performance' });
  } catch { gl = null; }
  if (!gl) return { signals: out, gl: null };
  out.webgl2 = true;
  const dbg = gl.getExtension('WEBGL_debug_renderer_info');
  out.renderer = String((dbg && gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) || gl.getParameter(gl.RENDERER) || '');
  out.vendor = String((dbg && gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL)) || gl.getParameter(gl.VENDOR) || '');
  out.maxTexture = Number(gl.getParameter(gl.MAX_TEXTURE_SIZE)) || null;
  const exts = gl.getSupportedExtensions() || [];
  const has = (re) => exts.some((e) => re.test(e));
  if (has(/compressed_texture_astc/)) out.formats.push('astc');
  if (has(/compressed_texture_etc$/) || has(/compressed_texture_etc\b/)) out.formats.push('etc2');
  if (has(/compressed_texture_bptc/)) out.formats.push('bc7');
  if (has(/compressed_texture_s3tc/)) out.formats.push('s3tc');
  out.timer = exts.includes('EXT_disjoint_timer_query_webgl2');
  return { signals: out, gl };
}

async function readWebGpu(nav, timeoutMs = 250) {
  if (!nav?.gpu?.requestAdapter) return { present: false };
  try {
    const adapter = await Promise.race([
      nav.gpu.requestAdapter(),
      new Promise((r) => setTimeout(() => r(undefined), timeoutMs)),
    ]);
    if (adapter === undefined) return { present: true, adapter: false, note: 'adapter request timed out' };
    if (!adapter) return { present: true, adapter: false };
    const info = adapter.info || {};
    return {
      present: true, adapter: true,
      vendor: info.vendor || '', architecture: info.architecture || '',
      maxTexture: adapter.limits?.maxTextureDimension2D ?? null,
      maxBufferMB: adapter.limits?.maxBufferSize ? Math.round(adapter.limits.maxBufferSize / 2 ** 20) : null,
    };
  } catch (err) {
    return { present: true, adapter: false, note: String(err?.message || err) };
  }
}

// ---- the benchmark ----------------------------------------------------------

const VS = `#version 300 es
in vec2 p; uniform float k;
void main(){ vec2 q = p; for (int i = 0; i < 4; i++) q = q * 0.999 + sin(q.yx * k + float(i)) * 1e-4;
  gl_Position = vec4(q, 0.0, 1.0); }`;
const FS = `#version 300 es
precision highp float; uniform float k; out vec4 o;
void main(){ vec2 u = gl_FragCoord.xy * 0.01; float a = 0.0;
  for (int i = 0; i < 8; i++) a += sin(u.x * k + float(i)) * cos(u.y * k - float(i));
  o = vec4(fract(a), 0.5, 0.5, 1.0); }`;

function program(gl) {
  const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; };
  const p = gl.createProgram();
  gl.attachShader(p, sh(gl.VERTEX_SHADER, VS));
  gl.attachShader(p, sh(gl.FRAGMENT_SHADER, FS));
  gl.linkProgram(p);
  return gl.getProgramParameter(p, gl.LINK_STATUS) ? p : null;
}

const frame = () => new Promise((r) => (typeof requestAnimationFrame === 'function'
  ? requestAnimationFrame(() => r()) : setTimeout(r, 16)));

/**
 * Time `draw` on the GPU: the timer query where there is one (polled over the
 * following frames), else the wall clock across a 1-pixel read, which waits for
 * the GPU. Null once `deadline` has passed: the budget is a ceiling, not a hope.
 */
async function timeDraw(gl, timerExt, draw, now, deadline) {
  if (now() >= deadline) return null;
  const px = new Uint8Array(4);
  if (timerExt) {
    const q = gl.createQuery();
    gl.beginQuery(timerExt.TIME_ELAPSED_EXT, q);
    draw();
    gl.endQuery(timerExt.TIME_ELAPSED_EXT);
    while (now() < deadline) {
      await frame();
      if (gl.getQueryParameter(q, gl.QUERY_RESULT_AVAILABLE)) {
        const disjoint = gl.getParameter(timerExt.GPU_DISJOINT_EXT);
        const ns = gl.getQueryParameter(q, gl.QUERY_RESULT);
        gl.deleteQuery(q);
        return !disjoint && ns > 0 ? { ms: ns / 1e6, method: 'timer-query' } : null;
      }
    }
    gl.deleteQuery(q);
    return null;
  }
  gl.readPixels(0, 0, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px);
  const t0 = now();
  draw();
  gl.readPixels(0, 0, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px);
  return { ms: now() - t0, method: 'wall-clock' };
}

/**
 * A fill pass (full-target quads, an 8-term shader) and a vertex pass (a list
 * of zero-area triangles, so vertices dominate), each grown fourfold from a
 * small first draw until one pass takes long enough to read (>= 8 ms), all
 * inside BENCH_BUDGET_MS — the fill pass may spend up to half of it.
 * Returns { fill: Mpx/ms, verts: Mvert/ms, ms, method }.
 */
export async function benchmark(gl, { now = () => performance.now(), budgetMs = BENCH_BUDGET_MS } = {}) {
  const start = now();
  const deadline = start + budgetMs * 0.9;
  const prog = program(gl);
  if (!prog) return { fill: NaN, verts: NaN, ms: now() - start, method: 'no-program' };
  const W = 512;
  const tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texStorage2D(gl.TEXTURE_2D, 1, gl.RGBA8, W, W);
  const fb = gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
  gl.viewport(0, 0, W, W);
  gl.useProgram(prog);
  gl.uniform1f(gl.getUniformLocation(prog, 'k'), 3.1);
  const loc = gl.getAttribLocation(prog, 'p');
  const quad = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quad);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW);
  gl.enableVertexAttribArray(loc);
  gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const timerExt = gl.getExtension('EXT_disjoint_timer_query_webgl2');
  let method = timerExt ? 'timer-query' : 'wall-clock';

  // Fill: n full-target quads, n x4 until a pass reads >= 8 ms.
  let fill = NaN;
  const fillDeadline = start + budgetMs * 0.5;
  for (let n = 1; n <= 1024; n *= 4) {
    const t = await timeDraw(gl, timerExt, () => { for (let i = 0; i < n; i++) gl.drawArrays(gl.TRIANGLES, 0, 6); },
      now, fillDeadline);
    if (!t) break;
    method = t.method;
    if (t.ms > 0) fill = (n * W * W / 1e6) / t.ms;
    if (t.ms >= 8) break;
  }

  // Vertices: zero-area triangles on one diagonal, so the fragment stage does no work.
  let verts = NaN;
  const count = 3 * 2 ** 15;
  const vb = new Float32Array(count * 2);
  for (let i = 0; i < count; i++) { vb[2 * i] = (i % 997) / 997 * 2 - 1; vb[2 * i + 1] = vb[2 * i]; }
  const vbuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vbuf);
  gl.bufferData(gl.ARRAY_BUFFER, vb, gl.STATIC_DRAW);
  gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  for (let n = 1; n <= 256; n *= 4) {
    const t = await timeDraw(gl, timerExt, () => { for (let i = 0; i < n; i++) gl.drawArrays(gl.TRIANGLES, 0, count); },
      now, deadline);
    if (!t) break;
    if (t.ms > 0) verts = (n * count / 1e6) / t.ms;
    if (t.ms >= 8) break;
  }
  gl.deleteBuffer(quad); gl.deleteBuffer(vbuf); gl.deleteFramebuffer(fb); gl.deleteTexture(tex); gl.deleteProgram(prog);
  return { fill, verts, ms: now() - start, method };
}

// ---- the profile -------------------------------------------------------------

/**
 * Profile this device once. Never throws: any failure reads as `standard` with
 * the reason, so a browser that refuses a probe boots exactly as it did before.
 *
 * Returns { cls, why, touch, choice: {detail, sharpness, textures, workers,
 * webgpu}, signals, bench, cached, forced, costMs, key }.
 */
export async function profileDevice({
  touch = false, build = '', storage = null, search = '', stepDown = 0,
  doc = globalThis.document, nav = globalThis.navigator, win = globalThis.window,
  now = () => performance.now(), forceBench = false,
} = {}) {
  const t0 = now();
  const forced = forcedClass(search);
  let gl = null;
  try {
    const read = readGl(doc);
    gl = read.gl;
    const signals = {
      ...read.signals,
      // T-3675: ChromeOS, so a touch-screen Chromebook is profiled as the computer it is.
      chromeos: isChromeOS(nav?.userAgent, nav?.userAgentData?.platform),
      cores: Number(nav?.hardwareConcurrency) || null,
      memoryGB: Number(nav?.deviceMemory) || null,
      // T-3552: an automated browser (Playwright, WebDriver) says so; a visitor's does not.
      automated: nav ? !!nav.webdriver : null,
      screen: win?.screen ? [win.screen.width, win.screen.height] : null,
      dpr: Number(win?.devicePixelRatio) || 1,
    };
    if (signals.chromeos) touch = false;
    const key = cacheKey(signals.renderer, build);
    const hit = !forced && !forceBench && !stepDown ? readCached(storage, key) : null;
    if (hit) {
      return { ...hit, touch, choice: decide(hit.cls, { touch, cores: signals.cores, webgpu: hit.choice?.webgpu }),
        cached: true, forced: null, costMs: now() - t0 };
    }
    const gpu = await readWebGpu(nav);
    signals.webgpu = gpu;
    const software = isSoftwareRenderer(signals.renderer);
    const bench = gl && !forced && (!software || forceBench) ? await benchmark(gl, { now }) : null;
    const { cls, why } = classify(signals, bench, { forced, stepDown, touch });
    const profile = {
      key, cls, why, touch,
      choice: decide(cls, { touch, cores: signals.cores, webgpu: !!gpu.adapter }),
      signals, bench, cached: false, forced, costMs: now() - t0,
    };
    // A forced or crash-stepped profile is a one-off; only a measured one is kept.
    if (!forced && !stepDown) {
      try { storage?.setItem(PROFILE_KEY, JSON.stringify({ key, cls, why, signals, bench, choice: profile.choice })); } catch { /* full or private */ }
    }
    return profile;
  } catch (err) {
    return { key: null, cls: forced || 'standard', why: `the profile failed: ${err?.message || err}`, touch,
      choice: decide(forced || 'standard', { touch }), signals: {}, bench: null, cached: false, forced,
      costMs: now() - t0 };
  } finally {
    try { gl?.getExtension('WEBGL_lose_context')?.loseContext(); } catch { /* best effort */ }
  }
}
