/**
 * The Navigator's Settings app (T-2656, NAV-903; DESIGN §07 "Settings", §13 type rules).
 *
 * The drawer's Settings section moved into the Settings app as it was (T-2620); this lays
 * it out the way the design asks and adds what it lacked:
 *
 *   Display      light or dark, text size (100-140 %), brightness, field of view, road
 *                visibility; then Show, the labels and the map
 *   Machine      the four skins as preview tiles (js/skin.js paints and applies them)
 *   Performance  detail, sharpness and frame pacing, with an Auto key that puts back what
 *                this device's profile recommends (js/device-profile.js)
 *   Sound        master, effects and ambience, which js/sound.js (T-2659) reads live; the
 *                note says what each covers, and that the ambience is mood, not a recording
 *   Units
 *   About        the build stamp (js/about.js, T-2629) and What's new. T-2657 adds
 *                Researcher mode here.
 *
 * T-3563 (the owner, 2026-11-12: "organize that settings card better with tabs and icons at the
 * top like ... the inspect card ... move whats new to one of those tabs maybe one of the last and
 * also the research mode should be at the end"): the groups are spread over one row of icon tabs
 * styled like Inspect's (T-3435): Display (with Machine and Units) · Show · Look (the new mouse
 * sensitivity, and Movement; not "Controls", which section 03 renamed Guide) · Graphics (Performance) · Sound · About · What's new ·
 * Research. What's new is still its own HUD section (its key, dot and every route to it stay);
 * its tab here selects that section, and the bar stays up over it.
 *
 * Every choice is a key of the HUD's one settings object, stored the way the others are
 * (hud.js `store`, which swallows a refused storage), so nothing here persists on its own.
 * Light or dark keeps its own key, `chicago4d.theme`, which js/skin.js reads before paint.
 */
import { readingChoice, LEVEL_IDS, levelLabel } from './reading-level.js';
import { t as str } from './strings/index.js';
import './strings/settings.js';
import { autoPacing, autoAntialias, autoGraphicsLine, storedPacing, storedAntialias } from './graphics-settings.js'; // T-3736
import { NARRATORS, normalNarrator } from './narrators.js'; // T-3627: not the player itself
import { MOTION_CHOICES, MOTION_LABELS, motionChoice, setMotionChoice, onMotionChange } from './motion.js'; // T-3671
import { LETTER_KEY_CHOICES, LETTER_KEY_LABELS, letterKeysChoice, setLetterKeys, onLetterKeysChange } from './letter-keys.js'; // T-3671, WCAG 2.1.4

/** Text size: 100 % to 140 % (QA-18), and on to 200 % (T-3671, WCAG 1.4.4) — the Navigator's apps,
 * its rail and head, the HUD, the cards, a Jaunt's panel, the tour, the hints and the name cards. */
export const TEXT_SCALES = Object.freeze([1, 1.1, 1.2, 1.3, 1.4, 1.6, 1.8, 2]);
export function normalTextScale(value) {
  const n = Number(value);
  return TEXT_SCALES.includes(n) ? n : 1;
}

/** The sound levels the HUD's settings carry (0..1). js/sound.js (T-2659) reads them on every
 * move. Sound is OFF by default (T-2941; the owner, 2026-10-20: "the sound is a bit much, can
 * you default that to off for now"), reversing the 2026-10-16 ruling: Master starts at 0, and
 * Effects and Ambience stay up, so moving Master alone turns every sound on. */
// T-3578: Narration (jaunt voices) joins them; at 1, like Effects and Ambience, it plays once Master is up.
export const SOUND_KEYS = Object.freeze(['soundMaster', 'soundEffects', 'soundAmbience', 'soundMusic', 'soundNarration']);
export const SOUND_DEFAULTS = Object.freeze({ soundMaster: 0, soundEffects: 1, soundAmbience: 1, soundMusic: 0.4, soundNarration: 1 });
/** The level every key had while sound was on by default (2026-10-16 to T-2941). */
const SOUND_WAS_DEFAULT = 1;

/**
 * The sound levels a stored settings object stands for (T-2941). The HUD stores its whole
 * settings object on any change, so a visitor who never touched Sound has the old all-on
 * defaults stored beside their real choices, and those 1s are not a choice to keep. A stored
 * level is the visitor's own when `soundChosen` is set (a slider was moved since T-2941), or
 * when any level differs from the old default (it can only have got there by a slider).
 * Otherwise every level is the default, which is silence. Returns the five levels and
 * `soundChosen`; never touches storage.
 */
export function soundLevelsFrom(saved) {
  const s = saved && typeof saved === 'object' ? saved : {};
  const moved = SOUND_KEYS.filter(k => k !== 'soundMusic' && k !== 'soundNarration').some((k) => s[k] != null && normalVolume(s[k], SOUND_WAS_DEFAULT) !== SOUND_WAS_DEFAULT);
  const chosen = s.soundChosen === true || moved;
  const out = { soundChosen: chosen };
  for (const k of SOUND_KEYS) out[k] = chosen ? normalVolume(s[k], SOUND_DEFAULTS[k]) : SOUND_DEFAULTS[k];
  return out;
}
export function normalVolume(value, fallback = 1) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : fallback;
}
export function volumeReadout(value) {
  const v = normalVolume(value, 0);
  return v <= 0 ? str('settings.sound.off') : `${Math.round(v * 100)} %`;
}

/**
 * Look sensitivity (T-3563; the owner, 2026-11-12: "could you add a setting to adjust the mouse
 * sensitivity for the app?"). A multiple of the turn the app has always made: the mouse's
 * PointerLockControls.pointerSpeed (js/controls/pointerlock.js) and, on a touch screen, the
 * drag-to-look rate (js/controls/touch.js). 1 is Standard, which leaves both as they were.
 */
export const LOOK_SPEED = Object.freeze({ min: 0.2, max: 3, step: 0.1, standard: 1 });
export function normalLookSpeed(value) {
  const n = Number(value);
  if (value == null || value === '' || !Number.isFinite(n)) return LOOK_SPEED.standard;
  return Math.round(Math.min(LOOK_SPEED.max, Math.max(LOOK_SPEED.min, n)) * 10) / 10;
}
export function lookSpeedReadout(value) {
  const v = normalLookSpeed(value);
  return v === LOOK_SPEED.standard ? str('settings.look.standard') : `${v.toFixed(1)}×`;
}

/**
 * The card's tabs, in order (T-3563). Each group in the Settings section names its tab with
 * `data-set-pane`; `whatsnew` is the HUD's own What's new section, and Research is last.
 */
export const SETTINGS_TABS = Object.freeze(['display', 'you', 'show', 'look', 'graphics', 'sound', 'about', 'whatsnew', 'research']);
/** The HUD sections the bar stands over. */
export const SETTINGS_SECTIONS = Object.freeze(['settings', 'whatsnew']);
/** Each tab's glyph: single-colour line icons in currentColor, 24-unit box (as Inspect's). */
const SET_TAB_ICON = Object.freeze({
  display: '<rect x="3" y="4.5" width="18" height="12" rx="1.5"/><path d="M8.5 20h7M12 16.5V20"/>',
  // T-3644: the visitor's own person: a head and shoulders.
  you: '<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20.5c.8-4 3.8-6.2 7.5-6.2s6.7 2.2 7.5 6.2"/>',
  show: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
  look: '<rect x="6.5" y="3" width="11" height="18" rx="5.5"/><path d="M12 3v6.5M6.5 9.5h11"/>',
  graphics: '<path d="M4.2 17.5a8.5 8.5 0 1 1 15.6 0"/><path d="m12 13.5 4-4.5"/><circle cx="12" cy="13.5" r="1.3"/>',
  sound: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
  about: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.6v.4"/>',
  whatsnew: '<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2H4.5z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  research: '<path d="M9 3h6M10 3v6l-5 9.5A1.7 1.7 0 0 0 6.5 21h11a1.7 1.7 0 0 0 1.5-2.5L14 9V3"/><path d="M7.5 15h9"/>',
});

/**
 * Draw and wire the tab bar (#settings-tabs). `selectSection(key)` is the HUD's selectTab and
 * `section()` reads which HUD section is showing. Returns `paint(section)` (the HUD calls it on
 * every section change), `select(tab)` and the tab in force, or null without the bar.
 */
export function wireSettingsTabs({ doc = globalThis.document, selectSection = () => {}, section = () => null } = {}) {
  const bar = doc?.getElementById?.('settings-tabs') ?? null;
  if (!bar) return null;
  const body = doc.querySelector?.('.panel-body[data-panel="settings"]') ?? null;
  let pane = SETTINGS_TABS[0];
  if (!bar.querySelector?.('[data-set-tab]')) {
    for (const key of SETTINGS_TABS) {
      const b = doc.createElement('button');
      b.type = 'button';
      b.className = 'set-tab';
      b.id = `set-tab-${key}`;
      b.dataset.setTab = key;
      b.setAttribute('role', 'tab');
      b.innerHTML = `<svg class="set-tab-icon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${SET_TAB_ICON[key]}</svg>`;
      const label = doc.createElement('span');
      label.className = 'set-tab-label';
      label.textContent = str(`settings.tab.${key}`);
      b.append(label);
      // What's new keeps its unread dot on its tab (hud.js paints it beside #whatsnew-dot).
      if (key === 'whatsnew') {
        const dot = doc.createElement('span');
        dot.className = 'set-tab-dot';
        dot.id = 'settings-whatsnew-dot';
        dot.hidden = true;
        dot.setAttribute('aria-hidden', 'true');
        b.append(dot);
      }
      bar.append(b);
    }
  }
  const buttons = () => [...bar.querySelectorAll('[data-set-tab]')];
  // T-3671 (WCAG 4.1.2): each tab names the section it shows, and that section is a tabpanel
  // named by the tab in force (the Settings section holds every tab's groups but What's new's).
  const news = doc.querySelector?.('.panel-body[data-panel="whatsnew"]') ?? null;
  for (const el of [body, news]) if (el && !el.id) el.id = `panel-body-${el.dataset?.panel}`;
  for (const b of buttons()) {
    const to = b.dataset.setTab === 'whatsnew' ? news : body;
    if (to?.id) b.setAttribute('aria-controls', to.id);
  }
  const paint = (now = section()) => {
    const shown = SETTINGS_SECTIONS.includes(now);
    bar.hidden = !shown;
    const sel = now === 'whatsnew' ? 'whatsnew' : pane;
    for (const b of buttons()) {
      const on = shown && b.dataset.setTab === sel;
      b.setAttribute('aria-selected', String(on));
      b.tabIndex = on ? 0 : -1;
    }
    body?.setAttribute?.('role', 'tabpanel');
    body?.setAttribute?.('aria-labelledby', `set-tab-${pane}`);
    news?.setAttribute?.('role', 'tabpanel');
    news?.setAttribute?.('aria-labelledby', 'set-tab-whatsnew');
    for (const g of body?.querySelectorAll?.('.settings-group[data-set-pane]') ?? []) g.hidden = g.dataset.setPane !== pane;
    return sel;
  };
  const select = (key) => {
    if (!SETTINGS_TABS.includes(key)) return false;
    if (key === 'whatsnew') {
      if (section() !== 'whatsnew') selectSection('whatsnew');
      paint('whatsnew');
      return true;
    }
    pane = key;
    if (section() !== 'settings') selectSection('settings');
    paint('settings');
    // A tab opens at its top, as Inspect's do.
    const scroll = doc.getElementById?.('panel-scroll');
    if (scroll) scroll.scrollTop = 0;
    return true;
  };
  bar.addEventListener('click', (e) => {
    const b = e.target?.closest?.('[data-set-tab]');
    if (b) select(b.dataset.setTab);
  });
  bar.addEventListener('keydown', (e) => {
    // T-3671: Home and End go to the row's ends, as in every tab row (WAI-ARIA tabs).
    const step = { ArrowRight: 1, ArrowLeft: -1, Home: 0, End: 0 }[e.key];
    if (step == null || e.altKey || e.ctrlKey || e.metaKey) return;
    const list = buttons().filter((b) => !b.hidden);
    const i = list.indexOf(doc.activeElement);
    if (i < 0) return;
    e.preventDefault();
    const next = e.key === 'Home' ? list[0] : e.key === 'End' ? list.at(-1) : list[(i + step + list.length) % list.length];
    select(next.dataset.setTab);
    next.focus?.();
  });
  paint();
  return { paint, select, get pane() { return pane; } };
}

const DETAIL_WORD = Object.freeze({ full: 'Full', balanced: 'Balanced', light: 'Light' });
const SHARP_WORD = Object.freeze({ 1: 'Low', 1.5: 'Medium', 2: 'High' });

/** What Auto chooses on this device: the profile's detail and sharpness, adaptive pacing.
 * null when there is no profile to read (the Auto row then stays out of sight). */
export function autoChoice(device) {
  const c = device?.choice;
  if (!c || !DETAIL_WORD[c.detail] || !SHARP_WORD[Number(c.sharpness)]) return null;
  // T-3736: and Fast pacing with antialiasing off on a weak computer (main.js sets weakDesktop).
  const weakDesktop = !!device?.weakDesktop;
  return { detail: c.detail, quality: Number(c.sharpness), pacing: autoPacing(weakDesktop),
    antialias: autoAntialias(weakDesktop), weakDesktop };
}

/** "Auto for this device: Full detail, Medium sharpness, adaptive pacing." */
export function autoLine(choice) {
  if (!choice) return '';
  return autoGraphicsLine(choice);
}

/** On Auto: the visitor has chosen none of detail, sharpness, pacing and antialiasing. */
export function onAuto(settings) {
  return !settings?.detail && !settings?.quality && !storedPacing(settings) && !storedAntialias(settings);
}

/** Put the settings back on Auto: no stored detail or sharpness, adaptive pacing. */
export function useAuto(settings) {
  settings.detail = '';
  settings.quality = '';
  settings.pacing = '';
  settings.antialias = '';
  delete settings.governor;
  return settings;
}

/** The interface's tone as the page has it now. */
export function themeOf(root) {
  return root?.getAttribute?.('data-theme') === 'light' ? 'light' : 'dark';
}

/** Set the text scale the whole interface reads (--text-scale: css/navigator.css for the
 * Navigator, css/walk.css § T-3671 for the rest), and mark the page while it is above 100 %
 * (html[data-text-scale]). */
export function applyTextScale(root, value) {
  const v = normalTextScale(value);
  root?.style?.setProperty?.('--text-scale', String(v));
  // The map's scope stays at its own size inside a zoomed screen (a picture, sized from its
  // box), so it is zoomed back by the inverse.
  root?.style?.setProperty?.('--text-unscale', String(Math.round(1e6 / v) / 1e6));
  if (root?.dataset) {
    if (v > 1) root.dataset.textScale = String(v);
    else delete root.dataset.textScale;
  }
  return v;
}

/**
 * Wire the Settings app's new rows. `settings` is the HUD's own object; `save()` stores it,
 * `saveTheme(tone)` stores light or dark, `onSetting(key, value)` is main.js's handler, and
 * `openWhatsNew()` shows the What's new section.
 */
/**
 * T-3645 (the owner, 2026-11-17: "a person can set a grade level age level in their
 * settings"): Settings › Display › Reading age, one key per age, as many pressed as the
 * reader likes. Each press is the shared choice (reading-level.js), so the Jaunts menu and
 * every card follow it, and a change made there (or by the account) shows here.
 */
/**
 * Settings › Display › Reading age (T-3645), drawn here rather than in index.html: the page is
 * published once for every year's door, and four copies of it sit at the published tree's
 * duplicate floor (validate.py SITE_DUPE_FLOOR), so the group costs the page no bytes. It goes
 * in above Appearance; the tab bar shows and hides it with the rest of Display.
 */
export function readingAgesGroup(doc = globalThis.document) {
  const have = doc?.getElementById?.('s-reading-ages');
  if (have) return have;
  const before = doc?.getElementById?.('s-machine');
  if (!before?.parentNode) return null;
  const group = doc.createElement('div');
  group.className = 'settings-group';
  group.id = 's-reading';
  group.dataset.setPane = 'display';
  group.hidden = !!before.hidden;
  const h = doc.createElement('h4');
  h.textContent = 'Reading age';
  const seg = doc.createElement('div');
  seg.className = 'seg reading-ages';
  seg.id = 's-reading-ages';
  seg.setAttribute('role', 'group');
  seg.setAttribute('aria-label', 'Reading age');
  for (const id of LEVEL_IDS) {
    const b = doc.createElement('button');
    b.type = 'button';
    b.className = 'seg-btn';
    b.dataset.readingAge = id;
    b.setAttribute('aria-pressed', 'false');
    b.setAttribute('aria-label', id === '18+' ? 'Ages 18 and over' : `Ages ${id.replace('-', ' to ')}`);
    b.textContent = levelLabel(id);
    seg.append(b);
  }
  const note = doc.createElement('p');
  note.className = 'legend-note';
  note.textContent = 'Pick one or more. Jaunts and cards are told for these ages.';
  group.append(h, seg, note);
  before.parentNode.insertBefore(group, before);
  return seg;
}

export function wireReadingAges(seg, choice = readingChoice()) {
  if (!seg) return false;
  const keys = [...seg.querySelectorAll('[data-reading-age]')];
  const paint = () => { for (const k of keys) k.setAttribute('aria-pressed', String(choice.has(k.dataset.readingAge))); };
  for (const k of keys) k.addEventListener('click', () => choice.toggle(k.dataset.readingAge));
  choice.subscribe(paint);
  paint();
  return true;
}

/**
 * T-3671 (WCAG 2.2.2, 2.3.3; the owner asked for "motion-comfort settings"): Settings › Look ›
 * Motion — System, Reduce or Full (js/motion.js). Drawn here, under the look speed, rather than
 * in index.html. Three radios in one group: Tab reaches the one chosen, the arrows move the
 * choice, Space or Enter takes the one focused.
 */
export function motionGroup(doc = globalThis.document) {
  const have = doc?.getElementById?.('s-motion');
  if (have) return have;
  const look = doc?.getElementById?.('s-look');
  if (!look) return null;
  const row = doc.createElement('div');
  row.className = 'field row theme-row motion-row'; // the theme row's segmented look
  row.id = 'row-motion';
  const label = doc.createElement('span');
  label.id = 's-motion-label';
  label.textContent = 'Motion';
  const seg = doc.createElement('div');
  seg.className = 'seg';
  seg.id = 's-motion';
  seg.setAttribute('role', 'radiogroup');
  seg.setAttribute('aria-labelledby', 's-motion-label');
  for (const id of MOTION_CHOICES) {
    const b = doc.createElement('button');
    b.type = 'button';
    b.className = 'seg-btn';
    b.dataset.motion = id;
    b.setAttribute('role', 'radio');
    b.setAttribute('aria-checked', 'false');
    b.textContent = MOTION_LABELS[id];
    seg.append(b);
  }
  const note = doc.createElement('p');
  note.className = 'legend-note';
  note.id = 's-motion-note';
  note.textContent = 'Reduce: no head bob, no fly-ins, no pulsing or ticking. System follows your device.';
  seg.setAttribute('aria-describedby', note.id);
  row.append(label, seg);
  look.append(row, note);
  return seg;
}

export function wireMotion(seg, { choose = setMotionChoice, current = motionChoice, subscribe = onMotionChange } = {}) {
  if (!seg) return false;
  const keys = [...seg.querySelectorAll('[data-motion]')];
  const paint = () => {
    const now = current();
    for (const k of keys) {
      const on = k.dataset.motion === now;
      k.setAttribute('aria-checked', String(on));
      k.classList.toggle('is-on', on);
      k.tabIndex = on ? 0 : -1;
    }
  };
  for (const k of keys) k.addEventListener('click', () => { choose(k.dataset.motion); paint(); });
  seg.addEventListener('keydown', (e) => {
    const step = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
    const at = keys.indexOf(e.target);
    if (!step || at < 0) return;
    e.preventDefault();
    e.stopPropagation();
    const next = keys[(at + step + keys.length) % keys.length];
    choose(next.dataset.motion);
    paint();
    next.focus();
  });
  subscribe(paint);
  paint();
  return true;
}

/**
 * T-3671 (WCAG 2.1.4): Settings › Look › Letter keys — On or Off (js/letter-keys.js). Off holds
 * back every bare letter and number shortcut; the arrows, Space and the controls still answer.
 * Two radios in one group, drawn under Motion, the same way.
 */
export function letterKeysGroup(doc = globalThis.document) {
  const have = doc?.getElementById?.('s-letter-keys');
  if (have) return have;
  const look = doc?.getElementById?.('s-look');
  if (!look) return null;
  const row = doc.createElement('div');
  row.className = 'field row theme-row letter-keys-row';
  row.id = 'row-letter-keys';
  const label = doc.createElement('span');
  label.id = 's-letter-keys-label';
  label.textContent = 'Letter keys';
  const seg = doc.createElement('div');
  seg.className = 'seg';
  seg.id = 's-letter-keys';
  seg.setAttribute('role', 'radiogroup');
  seg.setAttribute('aria-labelledby', 's-letter-keys-label');
  for (const id of LETTER_KEY_CHOICES) {
    const b = doc.createElement('button');
    b.type = 'button';
    b.className = 'seg-btn';
    b.dataset.letterKeys = id;
    b.setAttribute('role', 'radio');
    b.setAttribute('aria-checked', 'false');
    b.textContent = LETTER_KEY_LABELS[id];
    seg.append(b);
  }
  const note = doc.createElement('p');
  note.className = 'legend-note';
  note.id = 's-letter-keys-note';
  note.textContent = 'Off: single letter and number keys do nothing. Walk with the arrows; every key still works in a control.';
  seg.setAttribute('aria-describedby', note.id);
  row.append(label, seg);
  look.append(row, note);
  return seg;
}

export function wireLetterKeys(seg, { choose = setLetterKeys, current = letterKeysChoice, subscribe = onLetterKeysChange } = {}) {
  if (!seg) return false;
  const keys = [...seg.querySelectorAll('[data-letter-keys]')];
  const paint = () => {
    const now = current();
    for (const k of keys) {
      const on = k.dataset.letterKeys === now;
      k.setAttribute('aria-checked', String(on));
      k.classList.toggle('is-on', on);
      k.tabIndex = on ? 0 : -1;
    }
  };
  for (const k of keys) k.addEventListener('click', () => { choose(k.dataset.letterKeys); paint(); });
  seg.addEventListener('keydown', (e) => {
    const step = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
    const at = keys.indexOf(e.target);
    if (!step || at < 0) return;
    e.preventDefault();
    e.stopPropagation();
    const next = keys[(at + step + keys.length) % keys.length];
    choose(next.dataset.letterKeys);
    paint();
    next.focus();
  });
  subscribe(paint);
  paint();
  return true;
}

export function wireSettingsApp({
  doc = globalThis.document, settings, device = null, save = () => {}, saveTheme = () => {},
  onSetting = null, openWhatsNew = null, isTouch = false,
} = {}) {
  const $ = (id) => doc?.getElementById?.(id) ?? null;
  const root = doc?.documentElement;

  // ---- Display: light or dark (it left the HUD with T-2625; here it is a two-way choice).
  const themeSeg = $('s-theme');
  const paintTheme = () => {
    const now = themeOf(root);
    themeSeg?.querySelectorAll('.seg-btn').forEach((b) => {
      const on = b.dataset.themeChoice === now;
      b.classList.toggle('is-on', on);
      b.setAttribute('aria-checked', String(on));
    });
    return now;
  };
  const setTheme = (tone) => {
    const next = tone === 'light' ? 'light' : 'dark';
    root?.setAttribute('data-theme', next);
    saveTheme(next);
    paintTheme();
    return next;
  };
  themeSeg?.querySelectorAll('.seg-btn').forEach((b) => b.addEventListener('click', () => setTheme(b.dataset.themeChoice)));
  // A machine picked from its tile brings its own tone (js/skin.js): keep the choice true.
  if (root && typeof globalThis.MutationObserver === 'function') {
    new globalThis.MutationObserver(paintTheme).observe(root, { attributes: true, attributeFilter: ['data-theme'] });
  }
  paintTheme();

  // ---- Display: text size.
  settings.textScale = applyTextScale(root, settings.textScale);
  const textSize = $('s-text-size');
  if (textSize) {
    textSize.value = String(settings.textScale);
    textSize.addEventListener('change', () => {
      settings.textScale = applyTextScale(root, textSize.value);
      save();
      onSetting?.('textScale', settings.textScale);
    });
  }

  // ---- Display: reading age (T-3645). The Jaunts menu's age row is the same choice.
  wireReadingAges(readingAgesGroup(doc));

  // ---- Performance: Auto.
  const auto = autoChoice(device);
  const autoRow = $('s-perf-auto')?.closest?.('.field') ?? null;
  const autoKey = $('s-perf-auto');
  const autoText = $('s-perf-auto-line');
  const paintAuto = () => {
    if (autoRow) autoRow.hidden = !auto;
    if (!auto) return false;
    const on = onAuto(settings);
    if (autoText) autoText.textContent = autoLine(auto);
    if (autoKey) {
      autoKey.textContent = str(on ? 'settings.auto.on' : 'settings.auto.use');
      autoKey.disabled = on;
      autoKey.setAttribute('aria-pressed', String(on));
    }
    return on;
  };
  autoKey?.addEventListener('click', () => {
    if (!auto) return;
    useAuto(settings);
    save();
    const selects = { 's-detail': auto.detail, 's-quality': String(auto.quality), 's-governor': auto.pacing,
      's-antialias': auto.antialias };
    for (const [id, value] of Object.entries(selects)) { const el = $(id); if (el) el.value = value; }
    onSetting?.('detail', auto.detail);
    onSetting?.('quality', auto.quality);
    onSetting?.('pacing', '');
    onSetting?.('antialias', '');
    paintAuto();
  });
  // A choice made by hand leaves Auto; the HUD stores it first (its listener came first).
  for (const id of ['s-detail', 's-quality', 's-governor', 's-antialias']) $(id)?.addEventListener('change', () => paintAuto());
  paintAuto();

  // ---- Sound: five levels; main.js hands each move to js/sound.js (T-2659).
  for (const key of SOUND_KEYS) {
    settings[key] = normalVolume(settings[key], SOUND_DEFAULTS[key]);
    const slug = key.replace(/^sound/, '').toLowerCase();
    const el = $(`s-sound-${slug}`);
    const out = $(`v-sound-${slug}`);
    if (!el) continue;
    el.value = String(settings[key]);
    const paint = () => { if (out) out.textContent = volumeReadout(el.value); };
    paint();
    el.addEventListener('input', () => {
      settings[key] = normalVolume(el.value, SOUND_DEFAULTS[key]);
      // T-2941: a slider moved by the visitor is their choice, kept over the default from now on.
      settings.soundChosen = true;
      paint();
      save();
      onSetting?.(key, settings[key]);
    });
  }

  // ---- Sound: which narrator reads the jaunts (T-3578; the owner, 2026-11-13: "they can choose
  // which narrator in settings"). The essayist is the default; the people keep their own voices.
  const narrator = $('s-narrator');
  settings.narrator = normalNarrator(settings.narrator);
  if (narrator) {
    narrator.replaceChildren(...NARRATORS.map(n => { const o = doc.createElement('option'); o.value = n.id; o.textContent = n.label; return o; }));
    narrator.value = settings.narrator;
    narrator.addEventListener('change', () => {
      settings.narrator = normalNarrator(narrator.value); narrator.value = settings.narrator;
      save(); onSetting?.('narrator', settings.narrator);
    });
  }

  // ---- Look: mouse sensitivity (T-3563). A phone turns by a finger's drag, so it says Look.
  settings.lookSpeed = normalLookSpeed(settings.lookSpeed);
  const look = $('s-look-speed');
  const lookOut = $('v-look-speed');
  const lookLabel = $('s-look-speed-label');
  if (lookLabel) lookLabel.textContent = str(isTouch ? 'settings.look.touch' : 'settings.look.mouse');
  if (look) {
    look.value = String(settings.lookSpeed);
    const paintLook = () => { if (lookOut) lookOut.textContent = lookSpeedReadout(look.value); };
    paintLook();
    look.addEventListener('input', () => {
      settings.lookSpeed = normalLookSpeed(look.value);
      paintLook();
      save();
      onSetting?.('lookSpeed', settings.lookSpeed);
    });
  }

  // ---- Look: motion (T-3671). One choice, kept by js/motion.js, read by everything that moves.
  wireMotion(motionGroup(doc));
  wireLetterKeys(letterKeysGroup(doc));

  // ---- About & What's new.
  $('s-open-whatsnew')?.addEventListener('click', () => openWhatsNew?.());

  return { paintTheme, setTheme, paintAuto, auto };
}
