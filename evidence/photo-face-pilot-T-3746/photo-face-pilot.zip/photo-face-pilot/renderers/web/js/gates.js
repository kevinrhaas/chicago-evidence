/**
 * WHAT HANGS IN A GATEWAY (T-2112) — the leaves and slip bars a
 * fence record's `openings[].gate` states, as plain boxes the calling layer
 * pushes into its own buffer with its own `pushBox`.
 *
 * Two layers draw fences — `enclosures.js` (the yards, pens and lot lines) and
 * `frontage.js` (the street-lining board fences) — and both already leave the
 * gap. This module is only what stands IN the gap, so the two say the same
 * thing about a gate and neither has to know the other's buffer.
 *
 * The gate itself is `tools/gate_kinds.py`'s, and every number below is a
 * reconstruction like the record that asks for it: a 3 ft 6 in house gate on
 * one leaf, a pair of cart leaves, or slip bars let down out of a rail fence.
 * A boarded leaf is one panel, the way the fence's own butted boards read; a
 * paled leaf is two rails with the pales spaced across them. No brace is
 * drawn for those default leaves. The explicit braced_rail opt-in is an open
 * framed leaf read from a cited picture; only enclosures consumes its optional
 * tilted brace descriptor. No current frontage gate selects this stock.
 *
 * WHAT IT DOES NOT DRAW, and why (T-0672's ceilings): the gate posts. Both
 * fence layers already stand a post at either end of every stretch, so the
 * jambs a gate hangs on are there; a second post in each would be 448 boxes
 * of timber nobody sees twice. A boarded leaf is one box rather than a board
 * apiece for the same reason.
 *
 * Coordinates: the caller hands local ENU jambs with their ground heights; a
 * box comes back in the renderer's world frame (E, up, −N), with `u` its
 * horizontal along-direction and `part` the face set the caller should use.
 */

const POST_HALF_M = 0.07;          // the fence's own end post, which the leaf clears
const LEAF_RAIL_H_M = 0.09;
const LEAF_T_M = 0.025;
const BAR_H_M = 0.09;
const CLEAR_M = 0.03;              // hinge and latch play either side of a leaf
const PALE_PITCH_M = 0.17;
const PALE_W_M = 0.075;

function box(out, e, y, n, ue, un, halfLen, halfW, halfH, part) {
  out.push({ cx: e, cy: y, cz: -n, ux: ue, uz: -un, halfLen, halfW, halfH, part });
}

/**
 * One leaf, hinged at `h` (ENU + ground y) and closing along the unit `d`,
 * swung `deg` toward the unit `inward`.
 */
function leaf(out, h, d, inward, len, deg, height, stock) {
  const r = (deg * Math.PI) / 180;
  const ue = d[0] * Math.cos(r) + inward[0] * Math.sin(r);
  const un = d[1] * Math.cos(r) + inward[1] * Math.sin(r);
  const at = (t) => [h.e + ue * t, h.n + un * t];
  const top = height - 0.12;
  const low = 0.18;
  const mid = at(len / 2);
  if (stock === 'braced_rail') {
    // Explicit source-led open leaf only. Every unstated/board/picket leaf
    // continues through its original branch below with identical arithmetic.
    for (const y of [low, top]) box(out, mid[0], h.y + y, mid[1], ue, un,
      len / 2, LEAF_T_M, LEAF_RAIL_H_M / 2, 'rail');
    for (const t of [LEAF_RAIL_H_M / 2, len - LEAF_RAIL_H_M / 2]) {
      const p = at(t); box(out, p[0], h.y + (low + top) / 2, p[1], ue, un,
        LEAF_RAIL_H_M / 2, LEAF_T_M, (top - low) / 2, 'rail');
    }
    const rise = top - low, diag = Math.hypot(len, rise);
    box(out, mid[0], h.y + (low + top) / 2, mid[1], ue, un,
      diag / 2, LEAF_T_M / 2, LEAF_RAIL_H_M / 2, 'rail');
    out[out.length - 1].tilt_cos = len / diag;
    out[out.length - 1].tilt_sin = rise / diag;
    return;
  }
  if (stock !== 'picket') {
    // Boards butted edge to edge read as one face, so they are drawn as one.
    box(out, mid[0], h.y + (0.06 + top) / 2, mid[1], ue, un, len / 2, LEAF_T_M / 2,
      (top - 0.06) / 2, 'pale');
    return;
  }
  // The frame: a rail low and a rail high.
  box(out, mid[0], h.y + low, mid[1], ue, un, len / 2, LEAF_T_M, LEAF_RAIL_H_M / 2, 'rail');
  box(out, mid[0], h.y + top, mid[1], ue, un, len / 2, LEAF_T_M, LEAF_RAIL_H_M / 2, 'rail');
  // The pales across it, spaced and standing a hand above the top rail the
  // way the fence's do.
  const pitch = PALE_PITCH_M;
  const w = PALE_W_M;
  const count = Math.max(1, Math.floor(len / pitch));
  const first = (len - (count - 1) * pitch) / 2;
  const tall = top + 0.08;
  for (let k = 0; k < count; k++) {
    const p = at(first + k * pitch);
    box(out, p[0], h.y + (0.06 + tall) / 2, p[1], ue, un, w / 2, LEAF_T_M / 2,
      (tall - 0.06) / 2, 'pale');
  }
}

/**
 * The boxes for one opening. `a` and `b` are the gap's two jambs, `{ e, n, y }`
 * in local ENU with ground height; `height` is the fence's; `into` is the
 * record's `opens_into_local_enu_m`, the side a leaf swings to and slip bars
 * are laid on. Returns [] for a plain opening.
 */
export function gateBoxes(gate, a, b, height, into) {
  const out = [];
  if (!gate || gate.kind === 'opening') return out;
  const de = b.e - a.e;
  const dn = b.n - a.n;
  const width = Math.hypot(de, dn);
  if (width < 0.5) return out;
  const d = [de / width, dn / width];
  // Inward is whichever normal points at `into`; a record that names no side
  // swings to the left of a→b.
  let inward = [-d[1], d[0]];
  if (Array.isArray(into)) {
    const mx = (a.e + b.e) / 2;
    const my = (a.n + b.n) / 2;
    if ((into[0] - mx) * inward[0] + (into[1] - my) * inward[1] < 0) {
      inward = [-inward[0], -inward[1]];
    }
  }
  const span = width - 2 * POST_HALF_M - 2 * CLEAR_M;
  if (gate.kind === 'bars') {
    // Slip bars let down: the rails drawn out of the posts and laid along the
    // fence on the lot's side, one on another, and any left in place across
    // the top. A rail fence's way in, and no hinge anywhere on it.
    const down = Math.max(0, Math.min(3, gate.bars_down ?? 3));
    const lay = [a.e + de / 2 + inward[0] * 0.7, a.n + dn / 2 + inward[1] * 0.7];
    const y0 = Math.min(a.y, b.y);
    for (let k = 0; k < down; k++) {
      box(out, lay[0], y0 + BAR_H_M / 2 + k * BAR_H_M, lay[1], d[0], d[1],
        width / 2 + 0.25, 0.05, BAR_H_M / 2, 'rail');
    }
    for (let k = down; k < 3; k++) {
      const f = 1 - k / 3;
      box(out, a.e + de / 2, (a.y + b.y) / 2 + height * f - BAR_H_M / 2, a.n + dn / 2,
        d[0], d[1], width / 2 + 0.1, 0.05, BAR_H_M / 2, 'rail');
    }
    return out;
  }
  const stock = gate.leaf_stock ?? 'board';
  const leafH = Math.max(0.9, height - 0.05);
  const hingeA = { e: a.e + d[0] * (POST_HALF_M + CLEAR_M), n: a.n + d[1] * (POST_HALF_M + CLEAR_M), y: a.y };
  const hingeB = { e: b.e - d[0] * (POST_HALF_M + CLEAR_M), n: b.n - d[1] * (POST_HALF_M + CLEAR_M), y: b.y };
  if ((gate.leaves ?? 1) >= 2) {
    const sw = Array.isArray(gate.swing_deg) ? gate.swing_deg : [gate.swing_deg ?? 0, gate.swing_deg ?? 0];
    leaf(out, hingeA, d, inward, span / 2 - CLEAR_M, sw[0] ?? 0, leafH, stock);
    leaf(out, hingeB, [-d[0], -d[1]], inward, span / 2 - CLEAR_M, sw[1] ?? 0, leafH, stock);
  } else {
    const fromB = gate.hinge === 'b';
    leaf(out, fromB ? hingeB : hingeA, fromB ? [-d[0], -d[1]] : d, inward, span,
      Number(gate.swing_deg) || 0, leafH, stock);
  }
  return out;
}
