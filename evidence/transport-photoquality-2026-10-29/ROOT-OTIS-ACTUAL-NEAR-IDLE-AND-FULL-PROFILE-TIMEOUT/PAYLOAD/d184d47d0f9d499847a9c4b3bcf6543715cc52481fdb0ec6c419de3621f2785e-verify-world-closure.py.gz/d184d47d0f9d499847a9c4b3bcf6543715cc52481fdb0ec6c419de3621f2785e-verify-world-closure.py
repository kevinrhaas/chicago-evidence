"""Read actual closed P world receipts; never certifies personal visual review."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, subprocess, re, sys
sys.dont_write_bytecode = True

sha = lambda b: hashlib.sha256(b).hexdigest()

def load(p):
    assert p.is_file() and not p.is_symlink(), p
    return json.loads(p.read_bytes())

def jpeg_dimensions(b):
    assert b[:2] == b'\xff\xd8'
    i = 2
    while i < len(b):
        assert b[i] == 255
        while b[i] == 255:
            i += 1
        marker = b[i]
        i += 1
        n = int.from_bytes(b[i:i+2], 'big')
        assert n >= 2 and i+n <= len(b)
        if marker in (192,193,194):
            return dict(height=int.from_bytes(b[i+3:i+5], 'big'), width=int.from_bytes(b[i+5:i+7], 'big'))
        i += n
    raise AssertionError('No actual JPEG dimensions')

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--prefix', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--guard', required=True, type=Path)
    p.add_argument('--profile', required=True, choices=['desktop','mobile'])
    p.add_argument('--report', required=True, type=Path)
    a = p.parse_args()
    assert not a.report.exists()
    root = a.out.resolve()
    result = load(Path(str(a.prefix)+'.result.json'))
    cleanup = load(Path(str(a.prefix)+'.cleanup.json'))
    actual = load(root/'RESULT.json')
    closed = load(root.with_name(root.name+'-GUARD-CLOSED.json'))
    capture = load(root/'ACTUAL-NATIVE-VIDEO-CAPTURE.json')
    assert result['returncode'] == 0 and not result['timed_out']
    assert result['requested_timeout_seconds'] == result['effective_timeout_seconds'] == 600
    assert result['timeout_override_reason'] is None
    assert result['command'] == ['python', str(Path(__file__).parent/'run-guarded-human-world.py'), a.profile, str(root), str(a.guard.resolve())]
    assert result['cwd'] == '/tmp/chicago-transport-resume-20261029/chicago/4d'
    assert cleanup['cleanup_complete'] and cleanup['remaining_owned_children'] == []
    assert closed['returncode'] == 0 and closed['before'] == closed['after']
    assert closed['closure_errors'] == [] and closed['HTTP_server_closed']
    resource_module=Path('/workspace/.cloud-setup/logs/transport-recovery/WAGON-CURRENT-DEV-20261029/PINNED-EC16-INTAKE-PRESERVED/OWNED-WAGON-BOUND-REPAIR-20261029/resource_admission_v10.py');resource_pins=[{'path': '/workspace/.cloud-setup/logs/transport-recovery/WAGON-CURRENT-DEV-20261029/PINNED-EC16-INTAKE-PRESERVED/OWNED-WAGON-BOUND-REPAIR-20261029/resource_admission_v10.py', 'bytes': 5621, 'sha256': 'eebdd83e057f31bc44f76e0b85acf037f28e4d06807c1070346e4e2802b6d65d'}, {'path': '/workspace/.cloud-setup/logs/transport-recovery/ROOT-READONLY-MEMORY-EVENT-BASELINE-20261030-0235.json', 'bytes': 4799, 'sha256': 'fc9b837d38e9c235ae8c2fa88001a31ac05bdb858e051193df36dbdbd1be4205'}]
    for pin in resource_pins:
        f=Path(pin['path']);assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==pin['bytes'] and sha(b)==pin['sha256']
    spec=importlib.util.spec_from_file_location('p_closed_resource_admission_v10',resource_module);policy=importlib.util.module_from_spec(spec);spec.loader.exec_module(policy)
    pair=policy.check_pair(closed['resources_before'],closed['resources_after'])
    assert pair['accepted'] and pair==closed['resource_pair_admission_v10']
    assert closed['resource_policy_v10_pair_required_before_after'] and closed['max_counter_informational']
    for resources in [closed['resources_before'],closed['resources_after']]:
        assert resources['external_resource_policy']==resource_pins
        assert resources['active_browser_or_heavy_owners']==[]
    assert load(a.guard)['outside_resource_policy']==resource_pins
    assert closed['before']['source_files'] == 53 and closed['before']['asset_files'] == 16
    assert closed['before']['semantic_index_entries'] == 18052 and closed['before']['published_files'] == 5635
    assert closed['guard_manifest_sha256'] == sha(a.guard.read_bytes()) == actual['guard_manifest_sha256']
    assert actual['status'] == 'NATIVE_WORLD_UNHELD_MOTION_AND_REAL_SELECTION_PASS_REQUIRES_ROOT_VIDEO_REVIEW'
    assert actual['returncode'] == 0 and actual['profile'] == a.profile
    assert all(not rows for rows in actual['errors'].values())
    assert actual['nativeClockOrPoseWritten'] is False and actual['wholeTicketOrPhotographicAcceptance'] is False
    assert len(actual['rows']) == 2 and [r['label'] for r in actual['rows']] == ['near','mid']
    for row in actual['rows']:
        assert 8000 <= row['realElapsedMs'] <= 120000 and row['observedFrames'] >= 2
        assert row['mixerDelta'] >= 8 and row['animatedDelta'] > 0 and row['renderFrameDelta'] > 0
        assert row['full8nativeMixerSecondsObserved'] and row['maximumWallMs'] == 120000
        assert row['fullFootwearVertexMaximumDriftM'] <= 1e-5
        assert all(row['boneMaximumAngularChangeRadians'][n] > 1e-7 for n in ['head','neck_01','spine_02'])
        assert all(row['boneMaximumComponentDeltas'][n] > 1e-10 for n in ['head','neck_01','spine_02'])
        assert all(not row['unchangedActualNativeQuaternionNegativeControls'][n]['changed'] for n in ['head','neck_01','spine_02'])
    size = dict(width=1280,height=800) if a.profile == 'desktop' else dict(width=390,height=780)
    assert capture['frame_capture_started_after_native_actor_ready']
    assert capture['encoder_returncode'] == 0 and capture['encoder_exit_signal'] is None
    assert capture['encoder_process_exit_awaited_before_media_hash'] and capture['encoder_stdio_close_awaited_before_media_hash']
    assert capture['actor_pose_time_renderer_modified'] is False
    assert capture['raw_capture_byte_cap'] == 64*1024**2
    assert capture['original_final_PNG_video_cap_bytes'] == 32*1024**2
    assert capture['maximum_capture_frames_per_second'] == 6
    assert len(capture['frames']) >= 2
    raw_total = 0
    timestamps = []
    for i,row in enumerate(capture['frames']):
        assert row['index'] == i and row['path'] == f'raw-native-frames/{i:06d}.jpg'
        f = root/row['path']
        assert f.is_file() and not f.is_symlink()
        b = f.read_bytes()
        assert len(b) == row['bytes'] and sha(b) == row['sha256']
        assert row['dimensions'] == jpeg_dimensions(b) == size
        t = row['native_CDP_timestamp_s']
        if timestamps:
            assert t > timestamps[-1] and t-timestamps[-1] >= 1/6
        timestamps.append(t)
        raw_total += len(b)
    assert raw_total == capture['actual_raw_capture_bytes'] <= 64*1024**2
    assert capture['actual_native_recorded_duration_s'] >= 16
    assert abs(capture['actual_encoded_duration_error_s']) <= .1
    assert capture['maximum_encoding_duration_quantization_error_s'] == .1
    media = actual['media']
    assert len([r for r in media if r['file'].endswith('.png')]) == 5
    assert sum(r['bytes'] for r in media) <= 32*1024**2
    for row in media:
        rel = Path(row['file'])
        assert not rel.is_absolute() and '..' not in rel.parts
        f = root/rel
        assert f.is_file() and not f.is_symlink()
        b = f.read_bytes()
        assert len(b) == row['bytes'] and sha(b) == row['sha256']
    video = root/capture['actual_video']['path']
    b = video.read_bytes()
    assert len(b) == capture['actual_video']['bytes'] and sha(b) == capture['actual_video']['sha256']
    facts = json.loads(subprocess.check_output(['/usr/bin/ffprobe','-v','error','-show_entries','format=duration:stream=codec_name,width,height','-of','json',str(video)],timeout=10))
    assert any(r['codec_name']=='vp8' and r['width']==size['width'] and r['height']==size['height'] for r in facts['streams'])
    assert abs(float(facts['format']['duration'])-capture['actual_native_recorded_duration_s']) <= .1
    assert load(root/'REAL-POINTER-RESIDENT-CARD.json')['selects']
    report = dict(status='ACTUAL_CLOSED_P_WORLD_TECHNICAL_PASS_PERSONAL_REVIEW_PENDING', profile=a.profile,
                  source_index_fullmirror_exact=True, actual_full8native_seconds_both_views=True,
                  actual_media_bytes=sum(r['bytes'] for r in media), actual_raw_capture_bytes=raw_total,
                  final_video=capture['actual_video'], root_personal_video_and_image_review='PENDING',
                  photographic_gait_rider_driver_traffic_acceptance=False)
    a.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))

if __name__ == '__main__':
    main()
