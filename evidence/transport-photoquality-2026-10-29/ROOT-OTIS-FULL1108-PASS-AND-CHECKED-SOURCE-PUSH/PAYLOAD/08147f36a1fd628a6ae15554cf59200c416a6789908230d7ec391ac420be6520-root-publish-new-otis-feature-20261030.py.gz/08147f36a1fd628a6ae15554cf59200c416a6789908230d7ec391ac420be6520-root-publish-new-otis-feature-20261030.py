from pathlib import Path
import subprocess,json,hashlib,importlib.util,datetime,re,time
repo=Path('/tmp/chicago-transport-resume-20261029');app=repo/'chicago/4d';prep=Path('/tmp/OTIS-CHECKED-FEATURE-PUSH-AFTER-WRITER-INVENTORY-PREP-20261030');out=Path('/tmp/OTIS-ACTUAL-CHECKED-FIRST-FEATURE-PUSH-20261030-04');out.mkdir(exist_ok=False)
exe=prep/'run-checked-feature-commit-push.py';assert hashlib.sha256(exe.read_bytes()).hexdigest()=='58213cbc72c9f5141fc339bde166205aaec6f2137d64cf3a6ef7a86aa3793146'
spec=importlib.util.spec_from_file_location('checked_unchanged_p55',exe);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
state={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'VALIDATE_PASSED_P55_NEW_REMOTE_BRANCH','commands':[],'commit':'UNRUN','push':'UNRUN','DEV_merge':False}
def save():(out/'ACTUAL-CHECKED-FIRST-FEATURE-PUSH.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,argv,cwd=repo,allowed=(0,),timeout=60):
 t=time.monotonic();p=subprocess.run(argv,cwd=cwd,env=m.E,capture_output=True,timeout=timeout);log=out/(label+'.log');log.write_bytes(p.stdout+p.stderr);state['commands'].append({'label':label,'argv':argv,'cwd':str(cwd),'returncode':p.returncode,'seconds':time.monotonic()-t,'log':str(log)});save();assert p.returncode in allowed,(label,p.returncode);return p
save()
try:
 g=Path('/tmp/OTIS-ACTUAL-FULL-GATE-SHM-20261030-03');d=json.loads((g/'ACTUAL-WHOLE-GATE-CLOSED.json').read_text());r=json.loads((g/'native-check.result.json').read_text());c=json.loads((g/'native-check.cleanup.json').read_text())
 assert d['status']=='ACTUAL_FULL_NATIVE_CHECK_SH_PASS_SOURCE_AND_RESOURCE10_EXACT'and not d['errors']and d['source_index_unchanged']and d['native_result']==r and d['native_cleanup']==c
 assert (d['head'],d['tree'],d['app_tree'])==(m.OLD,m.TREE,m.APP)and r['returncode']==0 and not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==1200 and r['timeout_override_reason']is None and c['cleanup_complete']and not c['remaining_owned_children']
 assert d['native_environment_explicit']['C4D_GATE_REQUIRE_READERS']=='1'and d['native_environment_explicit']['C4D_GATE_REQUIRE_BASE']=='1'and d['native_environment_explicit']['CHECK_JOBS']=='4'
 text=re.sub(r'\x1b\[[0-9;]*m','',(g/'native-check.log').read_text(errors='replace'));summaries=re.findall(r'^CHECK (PASS|FAIL) — (.+)$',text,re.M);assert summaries[-1]==('PASS','1108 steps, none red.')and list(summaries[-1])==d['final_native_summary']
 before=json.loads((g/'SOURCE-BEFORE.json').read_text());after=json.loads((g/'SOURCE-AFTER.json').read_text());assert before==after and len(before['source_files'])==55
 idx=(g/'COMPLETE-INDEX-BEFORE.z').read_bytes();assert hashlib.sha256(idx).hexdigest()==m.INDEX_SHA==before['semantic_index_sha256']
 assert m.pin(m.POLICY)['sha256']==m.POLICY_SHA
 ps=importlib.util.spec_from_file_location('resource10_firstpush',m.POLICY);policy=importlib.util.module_from_spec(ps);ps.loader.exec_module(policy)
 rb=json.loads((g/'RESOURCES-BEFORE.json').read_text());ra=json.loads((g/'RESOURCES-AFTER.json').read_text());assert policy.check_pair(rb['snapshot'],ra['snapshot'])==d['shared_resource10_pair']and d['shared_resource10_pair']['accepted']
 state['source_before']=m.current_source(m.OLD,idx);mirror=json.loads((g/'MIRROR-AFTER.json').read_text());state['mirror_before']=m.current_mirror(mirror)
 assert m.git('remote','get-url','--push','origin')=='https://github.com/kevinrhaas/chicago.git'
 def absent(label):
  p=run(label,['git','ls-remote','--exit-code','origin',m.REF],allowed=(0,2));assert p.returncode==2 and not p.stdout,'Remote feature appeared; stop rather than take it'
 absent('REMOTE-NEW-FEATURE-ABSENT-BEFORE')
 run('REFRESH-DEV',['git','-c','gc.auto=0','-c','maintenance.auto=false','fetch','--filter=blob:none','origin','dev']);dev=m.git('rev-parse','origin/dev');assert run('REMOTE-DEV-BOUND',['git','ls-remote','--exit-code','origin','refs/heads/dev']).stdout.decode().split()[0]==dev
 base=m.git('merge-base',dev,'HEAD');assert re.fullmatch('[0-9a-f]{40}',base);state.update(current_DEV=dev,actual_merge_base=base,actual_full_gate_original=str(g),actual_full_gate_retargeted=False,old_remote_ref_absent=True);save()
 m.current_source(m.OLD,idx);run('STAGED-WHITESPACE',['git','diff','--cached','--check'])
 run('NORMAL-FEATURE-COMMIT',['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','--file',str(prep/'COMMIT-MESSAGE.txt')]);head=m.git('rev-parse','HEAD');state.update(commit='CREATED_HEAD_CHECKS_PENDING',HEAD=head);save();assert m.git('show','-s','--format=%P','HEAD')==m.OLD and m.git('merge-base',dev,'HEAD')==base;m.current_source(head,idx)
 commands=[('HEAD-changelog-entry',['node','tools/check-changelog-entry.mjs',base,head]),('HEAD-ID-collision',['node','tools/resolve_id_collisions.mjs','--base',dev,'--check']),('HEAD-changelog-contract',['node','tools/check-changelog.mjs']),('HEAD-pending-entries',['node','tools/changelog-entries.mjs','--check']),('HEAD-shipped-history',['node','tools/changelog-history.mjs','--base',dev])]
 for label,argv in commands:run(label,argv,cwd=app)
 run('COMMITTED-WHITESPACE',['git','diff','--check',m.OLD,head]);m.current_source(head,idx);m.current_mirror(mirror)
 absent('REMOTE-NEW-FEATURE-ABSENT-BEFORE-PUSH');assert run('REMOTE-DEV-BEFORE-PUSH',['git','ls-remote','--exit-code','origin','refs/heads/dev']).stdout.decode().split()[0]==dev,'DEV advanced; preserve commit and recheck new base'
 assert m.git('rev-parse','HEAD')==head and m.git('branch','--show-current')==m.BRANCH
 run('NORMAL-FIRST-FEATURE-PUSH',['git','-c','gc.auto=0','-c','maintenance.auto=false','push','--set-upstream','origin','HEAD:'+m.REF],timeout=120)
 state['push']='NORMAL_PUSH_RETURNED_ZERO';save();remote=run('REMOTE-FEATURE-EXACT',['git','ls-remote','--exit-code','origin',m.REF]).stdout.decode().split()[0];assert remote==head
 state['source_after']=m.current_source(head,idx);state['mirror_after']=m.current_mirror(mirror);assert not m.git('status','--porcelain')and m.git('config','--get','branch.'+m.BRANCH+'.remote')=='origin'
 state.update(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),state='PASS_ACTUAL_CHECKED_FIRST_FEATURE_COMMIT_AND_NORMAL_PUSH',commit='PASS_FIVE_ACTUAL_NEW_HEAD_CHECKS',push='PASS_REMOTE_EXACT',remote_HEAD=remote,clean=True,published_newHEAD=False,full_world_photo_gait_acceptance='OPEN',DEV_merge=False,ordinary_CI='NOT_QUERIED');save();print(json.dumps({k:v for k,v in state.items()if k!='commands'}))
except BaseException as error:
 state.update(state='STOPPED_PRESERVE_ALL_ACTUALS',error=repr(error));save();raise
