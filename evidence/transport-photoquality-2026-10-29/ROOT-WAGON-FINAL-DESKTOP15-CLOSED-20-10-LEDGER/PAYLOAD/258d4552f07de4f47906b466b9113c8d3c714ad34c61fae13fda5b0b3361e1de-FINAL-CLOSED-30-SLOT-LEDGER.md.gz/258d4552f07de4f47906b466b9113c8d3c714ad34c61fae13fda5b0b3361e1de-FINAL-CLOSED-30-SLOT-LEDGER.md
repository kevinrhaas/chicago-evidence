# Frozen W native coverage:20 accepted,10 unqualified

Source `78b11b7a8e49126a8a5724a4035ea961461a4f49`. No untouched runnable slots remain; the whole published gate remains PENDING.

| Part | Mobile | Desktop |
|---|---|---|
| 1 | ACCEPTED | ACCEPTED |
| 2 | ACCEPTED | UNQUALIFIED |
| 3 | ACCEPTED | ACCEPTED |
| 4 | ACCEPTED | UNQUALIFIED |
| 5 | ACCEPTED | ACCEPTED |
| 6 | ACCEPTED | ACCEPTED |
| 7 | ACCEPTED | UNQUALIFIED |
| 8 | ACCEPTED | UNQUALIFIED |
| 9 | ACCEPTED | ACCEPTED |
| 10 | ACCEPTED | ACCEPTED |
| 11 | ACCEPTED | ACCEPTED |
| 12 | ACCEPTED | UNQUALIFIED |
| 13 | UNQUALIFIED | UNQUALIFIED |
| 14 | UNQUALIFIED | UNQUALIFIED |
| 15 | ACCEPTED | UNQUALIFIED |

Unqualified actual original600 timeouts: mobile13/14; desktop2/4/7/8/12/15. Desktop13/14 remain deferred UNRUN.

Mobile2/3 share the existing explicit committed-source/publish coverage bridge; mobile10/11 share one complete native group. Desktop3 uses reviewed40ee reconciliation preserving original resourceFalse. Desktop10 uses fresh attempt02 PASS, preserving original attempt01 resourceFalse.

D15 has27 observed partial PASS lines and0 observed assertionFAIL lines, with NO native summary/fullPASS. Source/index/fullmirror/resources/ownedcleanup closed healthy. The launch-tool transport disconnect occurred despite actual process start and caused no second launch.

Ordinary CI/PR readiness/DEV merge remain unknown or unclaimed. Broad photoquality, motion, riding, driving, interactions and town traffic acceptance remain open.
