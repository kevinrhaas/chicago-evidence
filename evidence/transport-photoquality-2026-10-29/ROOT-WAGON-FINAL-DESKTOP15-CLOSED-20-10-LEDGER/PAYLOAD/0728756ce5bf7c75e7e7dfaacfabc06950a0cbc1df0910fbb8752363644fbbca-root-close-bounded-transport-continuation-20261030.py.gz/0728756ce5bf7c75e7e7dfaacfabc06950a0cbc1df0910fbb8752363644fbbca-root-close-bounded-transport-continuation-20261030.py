from pathlib import Path
import subprocess,os,json,datetime
r=Path('/tmp/chicago-transport-tickets-20261029')
cwd=Path('/workspace/chicago-smoke-infra-t3121/chicago/4d')
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],text=True).strip()
assert not git(r,'status','--porcelain')
subprocess.run(['git','-C',str(r),'fetch','origin','main'],check=True)
subprocess.run(['git','-C',str(r),'merge','--ff-only','--no-stat','origin/main'],check=True)
ids=['T-1789','T-1790','T-2793','T-2803','T-3088','T-3173']
before={}
for tid in ids:
 p=next(p for p in r.glob('T-*/*.md')if p.name.startswith(tid+'-'));front=p.read_text().split('---',2)[1]
 assert 'state: claimed' in front and 'claimed_by: Codex root' in front,(tid,front)
 before[tid]={'path':str(p),'frontmatter':front}
sources=[('/tmp/chicago-transport-resume-20261029','11140ef913ffb43e9f5c46a0d0f8a8166290dcb5'),('/tmp/chicago-horse-20261029','2177b51b1f6d0c4aedfbc5374f4f1e2ce1fa7d1b'),('/tmp/chicago-wagon-20261029','78b11b7a8e49126a8a5724a4035ea961461a4f49')]
source_readback=[]
for repo,head in sources:
 assert git(repo,'rev-parse','HEAD')==head and not git(repo,'status','--porcelain')
 branch=git(repo,'branch','--show-current');remote=git(repo,'ls-remote','--heads','origin','refs/heads/'+branch)
 assert remote.split()[0]==head
 source_readback.append({'repo':repo,'branch':branch,'HEAD':head,'clean':True,'remote_exact':True})
base=Path('/workspace/.cloud-setup/logs/transport-recovery/WAGON-CURRENT-DEV-20261029')
v=json.loads(Path('/tmp/WAGON-OWNBOUND-PUBLISHED-DESKTOP-STAGE15-01/ACTUAL-PARTIAL-VERDICT.json').read_text())
nr=json.loads((base/'rail-owned-wagon-bound-published-desktop-15-01.result.json').read_text())
cleanup=json.loads((base/'rail-owned-wagon-bound-published-desktop-15-01.cleanup.json').read_text())
assert v['timed_out']and not v['native_assertions_complete_PASS']and v['resource_complete_before_after_PASS']and v['source_index_fullmirror_unchanged']
assert nr['returncode']==124 and nr['requested_timeout_seconds']==nr['effective_timeout_seconds']==600 and nr['timeout_override_reason']is None
assert cleanup['cleanup_complete']and cleanup['remaining_owned_children']==[]
why=('Local continuation exhausted original-limit native runs: wagon20/30 accepted, tenUNQUALIFIED (phone13/14;desktop2/4/7/8/12/13/14/15). '
     'Do not count partial assertions or timeouts as PASS. Checked source remains normally pushed: Otis11140ef (full1108PASS/currentlocalpublish), '
     'horse2177b51 (full1109PASS/currentlocalpublish), wagon78b11b7 (full1105PASS/PR1340). '
     'Current GitHub API access is blocked by active policy; ordinary CI/required published checks and safe DEV merges remain pending. '
     'Branches, all primary source/results/captures and public evidence remain available; continue existing work after normal claim/readback, avoid duplicate PRs. '
     'Broader photographic/world/gait/riding/driving/people-interaction/town acceptance is unfinished; no broad ticket is marked done or review.')
env=dict(os.environ,CHICAGO_TICKETS_DIR=str(r))
subprocess.run(['node','tools/ticket.mjs','release',*ids,'--why',why],cwd=cwd,env=env,check=True)
assert not git(r,'status','--porcelain')
for tid in ids:
 p=Path(before[tid]['path']);front=p.read_text().split('---',2)[1];assert 'state: open' in front and 'claimed_by: null' in front
ticket_commit=git(r,'rev-parse','HEAD');assert git(r,'ls-remote','origin','refs/heads/main').split()[0]==ticket_commit
lapenv=dict(os.environ);lapenv.pop('CHICAGO_TICKETS_DIR',None)
status=subprocess.run(['node','tools/ticket.mjs','lap','1340','--status'],cwd=cwd,env=lapenv,text=True,capture_output=True)
print(status.stdout,status.stderr)
assert status.returncode==3 and status.stdout.startswith('held lap/pr-1340')and 'Codex root continuing same checked78b11 PR1340 final published groups and ordinary safe DEV delivery' in status.stdout,'Do not release an unrecognized lap owner'
subprocess.run(['node','tools/ticket.mjs','lap','1340','--release'],cwd=cwd,env=lapenv,check=True)
after=subprocess.run(['node','tools/ticket.mjs','lap','1340','--status'],cwd=cwd,env=lapenv,text=True,capture_output=True)
print(after.stdout,after.stderr);assert after.returncode==0 and after.stdout.startswith('free lap/pr-1340')
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':source_readback,'wagon_accepted_groups':20,'wagon_unqualified_groups':10,'unqualified':[{'viewport':'mobile','stage':x}for x in ['13','14']]+[{'viewport':'desktop','stage':x}for x in ['2','4','7','8','12','13','14','15']],'unqualified_timeouts_not_retried':True,'whole_gate_PASS':False,'current_GitHub_CI':'UNKNOWN_API_POLICY_BLOCKED','DEV_merge':False,'broad_tickets_done_or_review':False,'unfinished_own_claims_released':ids,'ticket_commit':ticket_commit,'ticket_remote_exact_clean':True,'own_PR1340_lap_released_after_exact_owner_check':True,'last_native_verdict':v,'last_native_result':nr,'last_native_cleanup':cleanup,'claim_before':before,'why':why}
p=Path('/tmp/ROOT-TRANSPORT-CLOSED-LOCAL-VALIDATION-AND-RESUME-20261030.json');p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'receipt':str(p),'ticket_commit':ticket_commit,'normal_own_releases':ids,'sources_remote_exact_clean':True,'accepted':20,'unqualified':10,'DEV_merge':False}))
