"""Build transparently NEW NORMAL-child producer from the archived5a source.

Only source admission is changed. The9176-byte original physical metric/limit
loop and actual Float64 socket capture implementation remain byte-exact.
"""
from pathlib import Path
import hashlib,json,difflib
ROOT=Path(__file__).resolve().parent
APP=Path('/tmp/chicago-horse-20261029/chicago/4d')
source=APP/'tools/transport/horse_socket_interface_v1/fixtures/NATIVE-PRODUCER-readback-socket129.mjs'
loop=APP/'tools/transport/horse_socket_interface_v1/fixtures/UNCHANGED-PHYSICAL-METRIC-LOOP.mjs.txt'
original=source.read_text();physical=loop.read_text()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(loop.read_bytes())==9176 and sha(loop.read_bytes())=='a8515b35e18a058673fe330a127eba129851f324915858971e3b683bc4d259a1'
assert original.count(physical)==1
text=original
old="config.inputs.candidate.sha256==='5a2b2e87c3931e3ab82be3ce3bc69724a0a088aac30920cea9ad348bbaf8fad5'"
assert text.count(old)==1
text=text.replace(old,"config.inputs.candidate.sha256==='bd443df87b92d19266284cb9b52d30e791215cddf099876c774e9cfb5f5a79b6'&&config.inputs.normal_parent.sha256==='e49b6f1c9f7b70f1fcdf19fa7f6dddf54048b32256b4d8030d6238d6dfe79d49'")
old="staticProof.status==='EXTERNAL_SOCKET_STATIC_ONLY_PASS'&&staticProof.mode==='canonical_socket_interface_v1'&&staticProof.parent_sha256===config.inputs.legacy_parent.sha256"
assert text.count(old)==1
text=text.replace(old,"staticProof.status==='NORMAL_CHILD_CURRENT_SOURCE_STATIC_ONLY_PASS'&&staticProof.source_admission==='eye_smooth_normals_v1'&&staticProof.collision_mode==='canonical_socket_interface_v1'&&staticProof.collision_reference925_sha256===config.inputs.legacy_parent.sha256&&staticProof.normal_parent_e49_sha256===config.inputs.normal_parent.sha256")
old="need(bytesEqual(parentRaw.bin,candidateRaw.bin.subarray(0,parentRaw.bin.length)),'Every parent BIN byte retained in this candidate');"
assert text.count(old)==1
new="""const normalParentRaw=glb(resources.normal_parent);
  need(bytesEqual(parentRaw.bin,normalParentRaw.bin.subarray(0,parentRaw.bin.length)),'Historical e49 preserves every original d454 BIN byte');
  normalChildSourceGuard(normalParentRaw,candidateRaw);
  need(JSON.stringify(parentRaw.doc.nodes)===JSON.stringify(normalParentRaw.doc.nodes),'Actual e49 rig remains unchanged');"""
text=text.replace(old,new)
marker='window.compare=async()=>{'
assert text.count(marker)==1
helper="""// Explicit new eye-NORMAL-only admission. No old master/policy constant is reassigned.
function normalChildSourceGuard(parent,child){
 need(parent.bin.length===child.bin.length,'New child BIN length fixed');
 const a=parent.doc.accessors[208],v=parent.doc.bufferViews[a.bufferView];
 need(a.componentType===5126&&a.type==='VEC3'&&a.count===3968&&!a.sparse&&!a.normalized,'Explicit dense3968eye NORMAL source');
 const start=(v.byteOffset??0)+(a.byteOffset??0),stride=v.byteStride??12;
 const allowed=new Set();for(let row=0;row<a.count;row++)for(let k=0;k<12;k++)allowed.add(start+row*stride+k);
 let changes=0;for(let i=0;i<parent.bin.length;i++)if(parent.bin[i]!==child.bin[i]){need(allowed.has(i),'Protected NORMAL-child BIN byte');changes++;}
 need(changes===37722,'Exact reviewed NORMAL-child byte difference');
 const clean=structuredClone(child.doc);for(const k of ['min','max'])clean.accessors[208][k]=parent.doc.accessors[208][k];
 need(JSON.stringify(clean)===JSON.stringify(parent.doc),'Only NORMAL208extrema may change in JSON');
 const p=rawValues(child,2,'POSITION').values,n=rawValues(child,2,'NORMAL').values;
 need(n.length===3968*3,'New child eye NORMAL count');
 for(let i=0;i<n.length;i+=3){
  const center=p[i]<0?[-.08190010690063015,1.5196372239921074,1.3421662949986715]:[.08116699382591966,1.5196359365078531,1.3421654682847983];
  const r=[p[i]-center[0],p[i+1]-center[1],p[i+2]-center[2]],length=Math.hypot(...r),unit=Math.hypot(n[i],n[i+1],n[i+2]);
  need(Math.abs(unit-1)<1e-7&&(r[0]*n[i]+r[1]*n[i+1]+r[2]*n[i+2])/length>.9999999,'Actual child radial outward unit eye normals');
 }
}
"""
text=text.replace(marker,helper+marker)
text='// NEW EXTERNAL bd443 eye-NORMAL child producer; no old certificate transfer.\n'+text
assert text.count(physical)==1,'Original physical metric/limit loop must be byte-exact'
original_capture=original[original.index('// Distinct external capture only.'):]
assert text.endswith(original_capture),'Original actual socket Float64 capture code unchanged'
output=ROOT/'native_normal_child129.mjs';assert not output.exists();output.write_text(text)
(ROOT/'NATIVE-PRODUCER-EXPLICIT-SOURCE-ADMISSION.diff').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True),text.splitlines(keepends=True),fromfile='archived-5a-producer-source',tofile='NEW-normal-child-producer')))
(ROOT/'NATIVE-PRODUCER-BUILD.json').write_text(json.dumps({'state':'NEW_SOURCE_PRODUCER_PREPARED_NOT_EXECUTED','archived_source_sha256':sha(source.read_bytes()),'new_producer_sha256':sha(output.read_bytes()),'physical_loop_sha256':sha(loop.read_bytes()),'physical_loop_bytes':9176,'original_physical_loop_exact':True,'original_native_socket_capture_suffix_exact':True,'candidate_sha256':'bd443df87b92d19266284cb9b52d30e791215cddf099876c774e9cfb5f5a79b6','parent_e49_sha256':'e49b6f1c9f7b70f1fcdf19fa7f6dddf54048b32256b4d8030d6238d6dfe79d49','old_certificate_transferred':False,'qualification':'UNRUN'},indent=2)+'\n')
print(output)
