"""Outside CPU mechanical helper integration; root-owned slot required. No renderer."""
from pathlib import Path
import hashlib,json,os,resource,subprocess,sys
P=Path(__file__).resolve().parent
A=Path('/tmp/chicago-horse-20261029/chicago/4d')
T=A/'tools/transport/horse_quiet_head_neck_idle_v6'
CERT=Path('/tmp/horse-quiet-head-neck-v6-finite-qualification-summary-20261030-01.json')
CERT_SHA='badca71fb2ab7596be9447adaf01b3d035d5a59c7b844bc27b500d0a004d78a6'
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
    assert len(sys.argv)==2,'Fresh outside output path required';out=Path(sys.argv[1]).resolve();assert not out.exists() and out.parent.is_dir() and not out.is_relative_to(A.parents[1])
    sys.path.insert(0,str(T));import canonical_guard as guard;import recorded_qualification as record
    before=guard.snapshot();assert before['TREE']=='bc697721852b6a3fb2e2dc5850dcebf693ad0089' and before['APP']=='4367c7e1d1a19226d28ea34e3da218e823336db5' and before['semantic_index_sha256']=='8544dc56091fecdf4dea2b3497f418f10c43a75fb5eb81d6e2e64f4617cfd747' and len(before['source_files'])==110,'Exact unchanged PhaseA source before mechanical helper test'
    record.read_certificate(CERT,CERT_SHA)
    files=[P/'standing-horse-quiet-head-neck-idle.js',P/'test-certified-native-helper.mjs',Path(__file__),A/'renderers/web/vendor/three-0.185.1/three.module.js',A/'renderers/web/vendor/three-0.185.1/three.core.js',A/'renderers/web/vendor/three-0.185.1/addons/loaders/GLTFLoader.js',A/'renderers/web/vendor/three-0.185.1/addons/utils/SkeletonUtils.js',A/'renderers/web/vendor/three-0.185.1/addons/utils/BufferGeometryUtils.js']
    def pins():
        result=[]
        for p in files:
            assert p.is_file() and not p.is_symlink();b=p.read_bytes();result.append(dict(path=str(p),bytes=len(b),sha256=sha(b)))
        return result
    code=pins();rc=1;after=None
    def cap():resource.setrlimit(resource.RLIMIT_CPU,(10,10))
    command=['node',str(P/'test-certified-native-helper.mjs'),str(A),str(CERT),str(out)]
    try:rc=subprocess.run(command,cwd=A,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'},preexec_fn=cap,timeout=25).returncode
    finally:
        after=guard.snapshot();assert before==after and code==pins(),'Exact source/index/mirror/certificate/helper/vendor bytes retained';assert sha(CERT.read_bytes())==CERT_SHA
        out.with_name(out.name+'-SOURCE-CLOSED.json').write_text(json.dumps(dict(returncode=rc,source_index_mirror_exact=before==after,phaseA_tree=before['TREE'],phaseA_app=before['APP'],source_files=len(before['source_files']),semantic_index_sha256=before['semantic_index_sha256'],code_pins=code,certificate_sha256=CERT_SHA,actual_command=command,cwd=str(A),child_CPU_limit_s=10,child_timeout_s=25,outer_supervisor_required_s=30,world='UNRUN',runtime_adoption=False),indent=2)+'\n')
    assert rc==0 and out.is_file();result=json.loads(out.read_bytes());assert result['status']=='ACTUAL_CERTIFIED_QUIET_HELPER_NATIVE_CPU_MECHANICAL_ONLY_PASS';return 0
if __name__=='__main__':raise SystemExit(main())
