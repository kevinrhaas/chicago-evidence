"""Install ONLY after explicit root GO. Exact reviewed source/index bridge, no tests."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys
P=Path(__file__).resolve().parent;A=Path('/tmp/chicago-horse-20261029/chicago/4d');R=A.parents[1];T=A/'tools/transport/horse_quiet_head_neck_idle_v6'
PLAN=P/'PHASEB-EXACT-ADOPTION-PLAN-01.json';PLAN_SHA='71394bc7b1e869577e69fab1b23e811faf62a1e1647ea46c3427c128826e2ffe';CERT=Path('/tmp/horse-quiet-head-neck-v6-finite-qualification-summary-20261030-01.json');CERT_SHA='badca71fb2ab7596be9447adaf01b3d035d5a59c7b844bc27b500d0a004d78a6'
sha=lambda b:hashlib.sha256(b).hexdigest();env={**os.environ,'GIT_NO_LAZY_FETCH':'1'}
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env=env)
def main():
    assert len(sys.argv)==2;output=Path(sys.argv[1]).resolve();assert not output.exists() and output.parent.is_dir() and not output.is_relative_to(R),'Fresh outside installation receipt'
    assert sha(PLAN.read_bytes())==PLAN_SHA and sha(CERT.read_bytes())==CERT_SHA;plan=json.loads(PLAN.read_bytes());cert=json.loads(CERT.read_bytes())
    sys.path.insert(0,str(T));import canonical_guard as guard
    before=guard.snapshot();assert before['TREE']==plan['phaseA_TREE'] and before['APP']==plan['phaseA_APP'] and len(before['source_files'])==110 and before['semantic_index_sha256']=='8544dc56091fecdf4dea2b3497f418f10c43a75fb5eb81d6e2e64f4617cfd747','Exact original110/index PhaseA before installation'
    index_before=git('ls-files','--stage','-z');paths=[r['path']for r in plan['changes']];assert len(paths)==19 and len(set(paths))==19
    for row in plan['changes']:
        raw=Path(row['proposal_source']).read_bytes();assert len(raw)==row['after']['bytes'] and sha(raw)==row['after']['sha256'];assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['after']['blob']
        target=R/row['path'];assert target.is_relative_to(A) and not target.is_symlink()
        if row['before'] is None:assert not target.exists(),'New path unexpectedly exists'
        else:assert target.is_file() and hashlib.sha1(b'blob '+str(target.stat().st_size).encode()+b'\0'+target.read_bytes()).hexdigest()==row['before']['blob']
    # All concrete before/after checks above finish before the first write.
    for row in plan['changes']:
        target=R/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(Path(row['proposal_source']).read_bytes());target.chmod(0o755 if row['after']['mode']=='100755' else 0o644)
    subprocess.check_call(['git','add','--',*paths],cwd=R,env=env)
    assert not git('diff','--name-only').strip(),'No unstaged source changes'
    tree=git('write-tree').decode().strip();app=git('rev-parse',tree+':chicago/4d').decode().strip()
    def entries(raw):return {x.split(b'\t',1)[1]:x.split(b'\t',1)[0]for x in raw.split(b'\0')if x}
    before_entries=entries(index_before);after_entries=entries(git('ls-files','--stage','-z'));allowed={p.encode()for p in paths};assert all(after_entries.get(p)==entry for p,entry in before_entries.items()if p not in allowed);assert set(after_entries)-set(before_entries)=={r['path'].encode()for r in plan['changes']if r['before']is None}
    spec=importlib.util.spec_from_file_location('quiet_phaseB_worldguard',P/'run-guarded-quiet-horse-world.py');world=importlib.util.module_from_spec(spec);spec.loader.exec_module(world);bridge=world.adoption_bridge(cert['phaseA_source_binding'],tree,PLAN,PLAN_SHA);assert guard.code_pins()==cert['actual_code_pins']
    source=[]
    for relative in sorted({r['path']for r in before['source_files']}|set(paths)):
        p=R/relative;b=p.read_bytes();source.append(dict(path=relative,bytes=len(b),sha256=sha(b)))
    result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='EXACT_REVIEWED_LOCAL_PHASEB_SOURCE_INSTALLED_STAGED_ONLY',HEAD=git('rev-parse','HEAD').decode().strip(),TREE=tree,APP=app,semantic_index_sha256=sha(git('ls-files','--stage','-z')),semantic_index_entries=len(after_entries),source_files=source,actual_exact_adoption_bridge=bridge,original63_qualifier_pins_exact=True,original_PhaseA_receipts_rewritten=False,certificate_sha256=CERT_SHA,source_controls='UNRUN',world='UNRUN',full_app_gate='UNRUN',feature_commit_push='UNRUN',DEV_merge='UNRUN')
    output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in {'source_files','actual_exact_adoption_bridge'}},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
