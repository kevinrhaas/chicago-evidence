import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

PREP=Path(__file__).resolve().parent
OLD=PREP.parent/'HORSE-NATURAL-IDLE-BINDING-V3-ROOTGUIDE-PREP-20261029'
REPO=Path('/tmp/chicago-horse-20261029');APP=REPO/'chicago/4d'
OUT=Path('/tmp/horse-attachment-v4-artifacts-20261029-01')
FREEZE=json.loads((OLD/'FROZEN-CANONICAL-ROOT-BINDING-V3-SOURCE-01.json').read_bytes())
E={**os.environ,'GIT_NO_LAZY_FETCH':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO,env=E)
def guard():
 assert git('rev-parse','HEAD').decode().strip()==FREEZE['base_HEAD']
 assert git('write-tree').decode().strip()==FREEZE['tree']
 assert sha(git('ls-files','--stage','-z'))==FREEZE['semantic_index_sha256']
 assert not git('diff','--name-only').strip()
 for row in FREEZE['source_files']:
  b=(REPO/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
 return dict(HEAD=FREEZE['base_HEAD'],TREE=FREEZE['tree'],APP=FREEZE['app_tree'],semantic_index_sha256=FREEZE['semantic_index_sha256'],source_files=FREEZE['source_files'])
assert not OUT.exists();OUT.mkdir()
before=guard();(PREP/'SOURCE-BEFORE-EXPORT01.json').write_text(json.dumps(before,indent=2)+'\n')
maximum=int(Path('/sys/fs/cgroup/memory.max').read_text());current=int(Path('/sys/fs/cgroup/memory.current').read_text())
assert maximum-current>2*1024**3,'2GiB RAM reserve'
assert shutil.disk_usage('/tmp').free>768*1024**2,'original output reserve retained'
browser_pids=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if Path(os.readlink(p/'exe')).name in {'chrome','chromium','headless_shell','chrome-headless-shell'}:browser_pids.append(int(p.name))
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not browser_pids,'one heavy/browser owner; root paused W for this bounded source export'
audit=json.loads((APP/'tools/transport/horse_natural_idle_root_binding_v3/INPUTS.json').read_bytes())
parent=APP/audit['inputs']['v2_candidate']['path'];reference=APP/audit['inputs']['v2_paired_reference']['path']
command=['python',str(PREP/'generate_attachment_v4.py'),'--parent',str(parent),'--reference',str(reference),'--recipe',str(PREP/'attachment-v4-recipe.json'),'--candidate-out',str(OUT/'horse-sevket-natural-planted-attachment-v4.glb'),'--paired-out',str(OUT/'horse-sevket-original925-attachment-v4.glb'),'--report-out',str(OUT/'SOURCE-EXPORT-AND-CONTROLS.json'),'--overlay-out',str(OUT/'ACTUAL-ATTACHMENT-OVERLAY.json')]
start=time.monotonic();rc=1
try:
 rc=subprocess.run(command,cwd=APP,env=E).returncode
finally:
 after=guard();assert after==before
 (PREP/'SOURCE-AFTER-EXPORT01.json').write_text(json.dumps(after,indent=2)+'\n')
 summary=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=rc,seconds=time.monotonic()-start,source_and_complete_index_unchanged=True,output_directory=str(OUT),CPU_limit_seconds=30,command=command,canonical_install=False,native_qualification='UNRUN',runtime_adoption=False)
 (PREP/'ACTUAL-SOURCE-EXPORT-CLOSED-01.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
assert rc==0,'Actual source-only export failed; no source adoption or unchanged rerun'
