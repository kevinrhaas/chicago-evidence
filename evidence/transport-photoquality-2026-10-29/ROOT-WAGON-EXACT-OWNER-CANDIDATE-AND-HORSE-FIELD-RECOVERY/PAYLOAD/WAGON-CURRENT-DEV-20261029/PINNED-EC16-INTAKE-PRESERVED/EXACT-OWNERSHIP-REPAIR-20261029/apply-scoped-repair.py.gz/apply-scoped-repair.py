from pathlib import Path
R=Path('/tmp/chicago-wagon-20261029/chicago/4d');p=R/'renderers/web/js/yard.js';s=p.read_text()
def sub(a,b):
 global s
 assert s.count(a)==1,(a[:100],s.count(a));s=s.replace(a,b)
sub('const emit = (chunk, id, draw) => {','const emit = (chunk, id, draw, objectId = null, objectKind = null) => {')
sub('    if (id) chunk.spans.push({ id, from, to: chunk.buf.pos.length / 9 });','''    if (id) {
      const span = { id, from, to: chunk.buf.pos.length / 9 };
      // Ownership of the existing pick range, not another geometry or pick target.
      // Nearby covered wagons must not absorb a bench or shed in measurements.
      if (objectId) Object.assign(span, { objectId, objectKind });
      chunk.spans.push(span);
    }''')
sub('''        (b) => build(b, wagon, form, terrain, LEVEL[wagon.confidence] ?? level,
          problems))) continue;''','''        (b) => build(b, wagon, form, terrain, LEVEL[wagon.confidence] ?? level,
          problems), wagon.under_shed ? wagon.id : null, 'wagon')) continue;''')
sub('''          problems, bench.belongs_to ?? bench.id))) continue;''','''          problems, bench.belongs_to ?? bench.id), bench.id, 'bench')) continue;''')
sub('''        (b) => buildShed(b, shed, form, terrain, LEVEL[shed.confidence] ?? level,
          problems))) continue;''','''        (b) => buildShed(b, shed, form, terrain, LEVEL[shed.confidence] ?? level,
          problems), shed.id, 'shed')) continue;''')
p.write_text(s)
p=R/'tools/smoke_renderer.mjs';s=p.read_text()
anchor='''      const unknownLotOwners = [...lotOwners.values()].flat().filter((s) => !s.pile).length;
'''
insert=r'''      // T-2376 moved the covered wagon beside the bench. A radius is not
      // ownership: read the exact existing emitted pick ranges instead.
      const expectedObjects = [
        ...benches.map((record) => ({ kind: 'bench', record })),
        ...sheds.map((record) => ({ kind: 'shed', record })),
        ...wagons.filter((record) => record.under_shed).map((record) => ({ kind: 'wagon', record })),
      ];
      const spanSets = meshes.map((m) => ({ geometry: m.geometry,
        triangles: m.geometry.getAttribute('position').count / 3,
        spans: m.userData.spans ?? [] }));
      function resolveExactOwners(sets) {
        const expected = new Map(expectedObjects.map((o) => [`${o.kind}:${o.record.id}`, o]));
        const counts = new Map();
        const owners = new Map();
        const errors = [];
        for (const set of sets) {
          const list = [];
          let previousEnd = 0;
          for (const span of [...set.spans].sort((a, b) => a.from - b.from)) {
            const validRange = Number.isInteger(span.from) && Number.isInteger(span.to)
              && span.from >= previousEnd && span.to > span.from && span.to <= set.triangles;
            if (!validRange) errors.push('invalid or overlapping emitted pick range');
            previousEnd = Math.max(previousEnd, span.to);
            if (!span.objectId && !span.objectKind) continue;
            const key = `${span.objectKind}:${span.objectId}`;
            const owner = expected.get(key);
            if (!owner || owner.record.belongs_to !== span.id) {
              errors.push(`unknown or misassigned object owner ${key}`);
              continue;
            }
            counts.set(key, (counts.get(key) ?? 0) + 1);
            if (validRange) list.push({ ...span, kind: owner.kind, record: owner.record });
          }
          owners.set(set.geometry, list);
        }
        for (const key of expected.keys()) if (counts.get(key) !== 1) errors.push(`missing or duplicate owner ${key}`);
        return { owners, errors, count: [...counts.values()].reduce((a, b) => a + b, 0) };
      }
      const exactOwnership = resolveExactOwners(spanSets);
      const exactOwners = exactOwnership.owners;
      const clonedSpans = () => spanSets.map((set) => ({ ...set, spans: set.spans.map((span) => ({ ...span })) }));
      const benchTag = (sets) => sets.flatMap((set) => set.spans).find((span) => span.objectKind === 'bench');
      const missing = clonedSpans();
      const missingBench = benchTag(missing);
      if (missingBench) { delete missingBench.objectId; delete missingBench.objectKind; }
      const unknown = clonedSpans();
      const unknownBench = benchTag(unknown);
      if (unknownBench) unknownBench.objectId = '__not_a_yard_record__';
      const misassigned = clonedSpans();
      const misassignedBench = benchTag(misassigned);
      if (misassignedBench && sheds[0]) Object.assign(misassignedBench,
        { objectKind: 'shed', objectId: sheds[0].id });
      const outside = clonedSpans();
      const outsideSet = outside.find((set) => set.spans.some((span) => span.objectKind === 'bench'));
      if (outsideSet) benchTag([outsideSet]).to = outsideSet.triangles + 1;
      const overlap = clonedSpans();
      const overlapSet = overlap.find((set) => set.spans.some((span) => span.objectKind === 'bench'));
      if (overlapSet) overlapSet.spans.push({ ...benchTag([overlapSet]) });
      const ownerControls = {
        missingRejected: !!missingBench && resolveExactOwners(missing).errors.length > 0,
        unknownRejected: !!unknownBench && resolveExactOwners(unknown).errors.length > 0,
        misassignmentRejected: !!misassignedBench && !!sheds[0] && resolveExactOwners(misassigned).errors.length > 0,
        outsideRejected: !!outsideSet && resolveExactOwners(outside).errors.length > 0,
        overlapRejected: !!overlapSet && resolveExactOwners(overlap).errors.length > 0,
      };
      // Controls copy only observed points into local arithmetic, never moving a
      // scene vertex or changing a renderer/material to make the check pass.
      const benchPoints = [];
      let shedOutsideBay = 0;
      const shedFrame = (sh, e, n) => {
        const b = ((sh.bearing_deg ?? 0) * Math.PI) / 180;
        const de = e - sh.at_local_enu_m[0], dn = n - sh.at_local_enu_m[1];
        return { along: de * Math.cos(b) - dn * Math.sin(b), out: de * Math.sin(b) + dn * Math.cos(b) };
      };
      const inShedBay = (sh, frame) => Math.abs(frame.along) <= sh.length_m / 2 + 0.4
        && Math.abs(frame.out) <= sh.depth_m / 2 + 0.5;
      const measureShedPoint = (sh, e, n, y) => {
        const frame = shedFrame(sh, e, n);
        shedVerts++;
        shedOut = Math.max(shedOut, frame.out); shedIn = Math.min(shedIn, frame.out);
        shedHigh = Math.max(shedHigh, y); shedLow = Math.min(shedLow, y);
      };
'''
sub(anchor,anchor+insert)
sub('''        let ownerIndex = 0;
        for (let i = 0; i < pos.count; i++) {''','''        let ownerIndex = 0;
        const objectOwners = exactOwners.get(geo) ?? [];
        let objectIndex = 0;
        for (let i = 0; i < pos.count; i++) {''')
anchor='''          highest = Math.max(highest, pos.getY(i));
'''
insert=r'''          while (objectIndex < objectOwners.length && i >= objectOwners[objectIndex].to * 3) objectIndex++;
          const object = objectOwners[objectIndex];
          const owned = object && i >= object.from * 3 && i < object.to * 3 ? object : null;
          if (owned?.kind === 'bench') {
            const bn = owned.record;
            benchVerts++;
            benchStray = Math.max(benchStray, Math.hypot(e - bn.at_local_enu_m[0], n - bn.at_local_enu_m[1]));
            const b = ((bn.bearing_deg ?? 0) * Math.PI) / 180;
            benchInside = Math.min(benchInside,
              (e - bn.at_local_enu_m[0]) * Math.sin(b) + (n - bn.at_local_enu_m[1]) * Math.cos(b));
            benchPoints.push({ e, n, y: pos.getY(i), record: bn });
            continue;
          }
          if (owned?.kind === 'shed') {
            const sh = owned.record;
            if (!inShedBay(sh, shedFrame(sh, e, n))) shedOutsideBay++;
            measureShedPoint(sh, e, n, pos.getY(i));
            continue;
          }
          if (owned?.kind === 'wagon') {
            const sh = sheds.find((s) => s.id === owned.record.under_shed);
            // Preserve the original tongue rule: owned wagon vertices beyond
            // its bay remain wagon geometry rather than inflating the roof.
            if (sh && inShedBay(sh, shedFrame(sh, e, n))) measureShedPoint(sh, e, n, pos.getY(i));
            else wagonVerts++;
            continue;
          }
'''
# This height accumulator occurs only in the goods measurement block.
sub(anchor,anchor+insert)
start=s.index('''          let inBay = false;
''');end=s.index('''          // A wagon is 3 m of body''',start);s=s[:start]+s[end:]
start=s.index("          // A bench's furthest corner is hypot(L/2, D/2)");end=s.index('''          let best = null;''',start);s=s[:start]+s[end:]
anchor='''      const verts = geos.reduce(
        (t, geo) => t + (geo.getAttribute('position')?.count ?? 0), 0);
'''
insert=r'''      const displacedBench = benchPoints.map((point) => ({ ...point }));
      if (displacedBench[0]) displacedBench[0].e = displacedBench[0].record.at_local_enu_m[0] + 2;
      ownerControls.displacementRejected = displacedBench.length > 0
        && displacedBench.some((point) => Math.hypot(point.e - point.record.at_local_enu_m[0],
          point.n - point.record.at_local_enu_m[1]) > 1.0);
'''
sub(anchor,insert+anchor)
sub('''        benchInside,
        benches,''','''        benchInside,
        exactOwnerErrors: exactOwnership.errors,
        exactOwnerCount: exactOwnership.count,
        expectedOwnerCount: expectedObjects.length,
        ownerControls,
        shedOutsideBay,
        benches,''')
anchor='''    check(`${label}: the bench stands against the Green Tree's front wall`,'''
insert=r'''    check(`${label}: bench, shed and covered-wagon geometry has exact recorded ownership`,
      goods.expectedOwnerCount > 0 && goods.exactOwnerCount === goods.expectedOwnerCount
        && goods.exactOwnerErrors.length === 0,
      `${goods.exactOwnerCount}/${goods.expectedOwnerCount} emitted owners; ${goods.exactOwnerErrors.join('; ')}`);
    check(`${label}: exact owners reject missing, unknown, misassigned, overlapping and out-of-buffer ranges and a displaced bench`,
      Object.values(goods.ownerControls).every(Boolean), JSON.stringify(goods.ownerControls));
'''
sub(anchor,insert+anchor)
sub('''      goods.shedVerts > 0
        && goods.shedIn''','''      goods.shedVerts > 0 && goods.shedOutsideBay === 0
        && goods.shedIn''')
sub('''          // T-2385 — the native Dearborn street-edge closure lengthens
          // blk_south_water_clark_east_walk_1 from 30.97058 to 36.13067 m:
          // 97 to 113 board tops (+32 triangles), 15 to 17 stringer bays
          // (+8 triangles). check_far_plank_tops independently reads 111510.
          && m.candidates === 111510''','''          // T-2385's accepted DEV merge d217fd8c restored this walk from
          // 36.13067 to 30.97058 m but retained the former smoke census.
          // Sixteen fewer board tops and two stringer bays remove40 triangles.
          // The actual emitted geometry independently reads111470; preserve it.
          && m.candidates === 111470''')
p.write_text(s)
