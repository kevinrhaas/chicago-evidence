import argparse,datetime,hashlib,json,os,shutil,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('phase',choices=['before','after']);p.add_argument('output');a=p.parse_args()
R=Path('/tmp/chicago-wagon-20261029');O=Path(__file__).resolve().parent;D=Path(a.output);D.mkdir(parents=True,exist_ok=True);G={**os.environ,'GIT_NO_LAZY_FETCH':'1'}
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env=G)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
b=json.loads((O/'SEALED-CANDIDATE.json').read_bytes());assert git('rev-parse','HEAD').decode().strip()==b['HEAD'];assert git('write-tree').decode().strip()==b['TREE'];assert not git('diff','--name-only').strip();index=git('ls-files','--stage','-z');assert index==(O/'SEALED-COMPLETE-INDEX.z').read_bytes();assert not git('ls-files','--others','--exclude-standard').strip()
rows={r['path']:r for r in json.loads((O.parent/'COMPLETE-NATIVE-PREFLIGHT-02/SOURCE-BINDING.json').read_bytes())['source_paths']};rows.update({r['path']:r for r in b['paths']})
for old in rows.values():
 q=R/old['path'];assert(not q.exists())if old.get('deleted')else(q.is_file()and sha(q)==old['sha256']),old['path']
mirror=R/'site/4d';assert mirror.is_dir();mir=[{'path':str(q.relative_to(mirror)),'bytes':q.stat().st_size,'sha256':sha(q)}for q in sorted(mirror.rglob('*'))if q.is_file()]
state=dict(HEAD=b['HEAD'],TREE=b['TREE'],APP=b['APP'],source_scope='Sealed staged candidate, not a new pushed HEAD. Original a829/profile receipts remain historical.',source_paths=sorted(rows.values(),key=lambda r:r['path']),index_sha256=hashlib.sha256(index).hexdigest(),mirror_paths=mir,mirror_files=len(mir),mirror_bytes=sum(x['bytes']for x in mir))
if a.phase=='after':assert state==json.loads((D/'SOURCE-AND-MIRROR-BEFORE.json').read_bytes()),'Candidate source/index or actual published mirror changed during gate'
(D/('SOURCE-AND-MIRROR-'+a.phase.upper()+'.json')).write_text(json.dumps(state,indent=2)+'\n')
if a.phase=='before':(D/'COMPLETE-INDEX.z').write_bytes(index)
resource=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=a.phase,workspace_free_bytes=shutil.disk_usage('/workspace').free,tmp_free_bytes=shutil.disk_usage('/tmp').free)
for k in ['memory.max','memory.current','memory.events']:
 q=Path('/sys/fs/cgroup')/k
 if q.exists():resource[k]=q.read_text().strip()
(D/('RESOURCES-'+a.phase.upper()+'.json')).write_text(json.dumps(resource,indent=2)+'\n');print(json.dumps(dict(phase=a.phase,HEAD=b['HEAD'],TREE=b['TREE'],APP=b['APP'],source_paths=len(rows),mirror_files=len(mir),mirror_bytes=state['mirror_bytes'],result='PASS exact sealed candidate source/index/full published mirror binding',resources=resource)),flush=True)
