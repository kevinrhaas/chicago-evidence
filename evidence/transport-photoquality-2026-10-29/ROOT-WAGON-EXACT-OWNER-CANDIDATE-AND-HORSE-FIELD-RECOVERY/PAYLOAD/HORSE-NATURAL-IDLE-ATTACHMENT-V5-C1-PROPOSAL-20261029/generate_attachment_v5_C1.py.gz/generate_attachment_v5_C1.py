#!/usr/bin/env python3
"""Source-only harmonic attachment authoring. No pose or acceptance inputs."""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import resource
import struct
import time
import numpy as np
import scipy
from scipy import sparse
from scipy.sparse.linalg import spsolve

PARENT = '0ced8a09e27da047ad404c902e9d032e43654393027199db8dfd9c315be17929'
PAIR = 'a3eca1a164e2adf13d7d5f6699ff43de66d48dde0e3220f4aae90591dcaf4cb3'
NOTICE = 'chicago4d_natural_planted_attachment_v5'
PALETTES = {'head': (2, 3), 'tail': (4, 5)}

def tail_c1(u):
    need(0 <= u <= 1, 'bounded latent anatomical coordinate, no clipping')
    return u*u*(3.0-2.0*u)

def inverse_tail_c1(value):
    need(0 <= value <= 1, 'bounded exported C1 mass fraction')
    if value == 0 or value == 1:
        return value
    # Analytic monotone inverse of 3u²-2u³; used only by independent admission.
    return .5-math.sin(math.asin(1-2*value)/3)

def need(ok, why):
    if not ok:
        raise ValueError(why)

def sha(raw): return hashlib.sha256(raw).hexdigest()

def read(raw):
    magic, version, size, length, tag = struct.unpack_from('<5I', raw)
    need((magic, version, size, tag) == (0x46546c67, 2, len(raw), 0x4e4f534a), 'complete GLB2')
    count, tag = struct.unpack_from('<2I', raw, 20+length)
    need(tag == 0x004e4942 and 28+length+count == len(raw), 'complete embedded BIN')
    return json.loads(raw[20:20+length]), raw[28+length:]

def write(doc, binary):
    text = json.dumps(doc, separators=(',', ':'), ensure_ascii=False).encode()
    text += b' '*(-len(text) % 4)
    return struct.pack('<5I', 0x46546c67, 2, 28+len(text)+len(binary), len(text), 0x4e4f534a)+text+struct.pack('<2I', len(binary), 0x004e4942)+binary

def view(doc, binary, mesh, name):
    p = doc['meshes'][mesh]['primitives'][0]
    a = doc['accessors'][p['indices'] if name == 'indices' else p['attributes'][name]]
    v = doc['bufferViews'][a['bufferView']]
    width = {'SCALAR':1, 'VEC2':2, 'VEC3':3, 'VEC4':4}[a['type']]
    dtype = np.dtype({5121:'u1', 5123:'<u2', 5125:'<u4', 5126:'<f4'}[a['componentType']])
    need(not a.get('normalized') and not a.get('sparse'), 'explicit dense source streams')
    offset = v.get('byteOffset', 0)+a.get('byteOffset', 0)
    stride = v.get('byteStride', dtype.itemsize*width)
    rows = np.ndarray((a['count'], width), dtype=dtype, buffer=binary, offset=offset, strides=(stride, dtype.itemsize))
    return rows, offset, stride, dtype.itemsize*width

def dense(joints, weights):
    result = np.zeros((len(joints),26))
    for k in range(4):
        for i in range(len(joints)):
            if weights[i,k]:
                need(0 <= joints[i,k] < 26, 'positive original influence inside palette')
                result[i,int(joints[i,k])] += float(weights[i,k])
    return result

def source(raw):
    doc, binary = read(raw)
    p = view(doc,binary,0,'POSITION')[0].astype(np.float64)
    j = view(doc,binary,0,'JOINTS_0')[0].copy()
    w = view(doc,binary,0,'WEIGHTS_0')[0].copy()
    tri = view(doc,binary,0,'indices')[0].reshape(-1,3).astype(np.int64)
    need(p.shape == (3275,3), 'original complete HAIR stream')
    sem = dense(j,w)
    classes = {}
    for i,point in enumerate(p): classes.setdefault(tuple(np.rint(point/1e-6).astype(np.int64)),[]).append(i)
    members = sorted(classes.values(),key=lambda r:r[0])
    mapping = np.empty(len(p),dtype=np.int64)
    for ci,rows in enumerate(members):
        mapping[rows]=ci
        need(all(np.array_equal(sem[rows[0]],sem[row]) for row in rows), 'original source canonical weld semantics')
    head=(p[:,1]>1.04)&(p[:,2]>.28)
    s=((p[:,1]-1.3)*.18+(p[:,2]-.55)*.48)/(.18**2+.48**2)
    t=((p[:,1]-1.28)*(-.68)+(p[:,2]+.85)*(-.25))/(.68**2+.25**2)
    masks={'head':head&(s>.48)&(s<.9),'tail':(~head)&(t>.18)&(t<1)}
    need(int(head.sum())==2306 and int((~head).sum())==969 and int((head&(s>=.9)).sum())==1184, 'original anatomical domains/core')
    need([int(masks[k].sum()) for k in ('head','tail')]==[417,653], 'reviewed minimal transition rows')
    for rows in members:
        for mask in masks.values(): need(all(mask[row]==mask[rows[0]] for row in rows), 'whole weld class within each authored domain')
    # Source-surface cotangent conductance; negative shared-edge sums are zero.
    # No sampled pose, motion amplitude, acceptance limit or witness is read.
    weights={}; zero_faces=0
    for ids in tri:
        xyz=p[ids]; area=float(np.linalg.norm(np.cross(xyz[1]-xyz[0],xyz[2]-xyz[0])))
        if area==0:
            zero_faces+=1
            continue
        for k in range(3):
            a,b=int(mapping[ids[(k+1)%3]]),int(mapping[ids[(k+2)%3]])
            if a==b: continue
            edge=tuple(sorted((a,b)))
            cot=float(np.dot(xyz[(k+1)%3]-xyz[k],xyz[(k+2)%3]-xyz[k])/area)/2
            weights[edge]=weights.get(edge,0.0)+cot
    neighbors=[{} for _ in members]; removed=0
    for (a,b),weight in sorted(weights.items()):
        if weight<=0:
            removed+=1
            continue
        need(np.isfinite(weight), 'finite source conductance')
        neighbors[a][b]=weight;neighbors[b][a]=weight
    return dict(doc=doc,binary=binary,p=p,j=j,w=w,tri=tri,semantic=sem,members=members,
                mapping=mapping,masks=masks,core=head&(s>=.9),neighbors=neighbors,
                graph=dict(weld_classes=len(members),positive_edges=sum(map(len,neighbors))//2,
                           nonpositive_shared_edges_removed=removed,zero_area_source_faces=zero_faces))

def field(base, name):
    low,high=PALETTES[name]; mask=base['masks'][name]
    free=[i for i,rows in enumerate(base['members']) if mask[rows[0]]]
    need(len(free)==(359 if name=='head' else 619),'reviewed free canonical class count')
    lookup={ci:i for i,ci in enumerate(free)}
    boundary=[]
    for rows in base['members']:
        row=rows[0]; mass=base['semantic'][row,low]+base['semantic'][row,high]
        boundary.append(float(base['semantic'][row,high]/mass) if mass else 0.0)
    # Each free component must touch a fixed Dirichlet boundary. This is the
    # uniqueness proof; never hide an unanchored island behind a regularizer.
    unseen=set(free); components=[];exact={}
    while unseen:
        seed=min(unseen);unseen.remove(seed);stack=[seed];component=[];fixed=set()
        while stack:
            ci=stack.pop();component.append(ci)
            for other in base['neighbors'][ci]:
                if other in lookup:
                    if other in unseen: unseen.remove(other);stack.append(other)
                else: fixed.add(other)
        need(fixed,'well-posed source Dirichlet component')
        lower=min(boundary[i] for i in fixed);upper=max(boundary[i] for i in fixed)
        # A connected Dirichlet component with one identical boundary value
        # has that constant as its unique harmonic solution. Compute it
        # analytically, never by clipping a numerically overshooting solve.
        if lower==upper:
            for ci in component:exact[ci]=lower
        components.append(dict(free_classes=len(component),boundary_classes=len(fixed),
                               boundary_min=lower,boundary_max=upper,
                               analytical_constant_solution=lower if lower==upper else None))
    rr=[];cc=[];vv=[];rhs=np.zeros(len(free));degrees=np.zeros(len(free))
    for ci,i in lookup.items():
        for other,weight in base['neighbors'][ci].items():
            degrees[i]+=weight
            if other in lookup: rr.append(i);cc.append(lookup[other]);vv.append(-weight)
            else: rhs[i]+=weight*boundary[other]
        need(degrees[i]>0,'positive free source degree')
        rr.append(i);cc.append(i);vv.append(degrees[i])
    matrix=sparse.csr_matrix((vv,(rr,cc)),shape=(len(free),len(free)))
    solution=np.empty(len(free));fixed_indices=[lookup[ci] for ci in exact]
    for ci,value in exact.items():solution[lookup[ci]]=value
    active=np.array([lookup[ci] for ci in free if ci not in exact],dtype=np.int64)
    if len(active):
        reduced=matrix[active,:][:,active]
        adjusted=rhs[active].copy()
        if fixed_indices:adjusted-=matrix[active,:][:,fixed_indices]@solution[fixed_indices]
        scale=1/np.sqrt(degrees[active])
        normal=sparse.diags(scale)@reduced@sparse.diags(scale)
        solution[active]=scale*spsolve(normal,adjusted*scale,permc_spec='NATURAL',use_umfpack=False)
    need(np.isfinite(solution).all() and (solution>=0).all() and (solution<=1).all(), 'bounded harmonic field, no clipping')
    residual=np.max(np.abs(matrix@solution-rhs)/degrees)
    need(residual<1e-10,'actual source Dirichlet solve residual')
    return {ci:float(solution[i]) for ci,i in lookup.items()},dict(name=name,rows=int(mask.sum()),
        free_weld_classes=len(free),components=components,minimum=float(solution.min()),maximum=float(solution.max()),
        normalized_residual=float(residual),analytically_constant_classes=len(exact),
        solver='Exact constant Dirichlet components; Float64 symmetric degree-equilibrated SuperLU NATURAL for nonconstant components, single numerical thread')

def tuples(base):
    overlay=[];reports=[]
    for name in ('head','tail'):
        values,report=field(base,name);reports.append(report);low,high=PALETTES[name]
        report['transfer'] = 'identity, exact unchanged V4 head field' if name=='head' else 'exact original V2 C1 polynomial u*u*(3-2*u)'
        for ci,q in values.items():
            if name=='tail': q=tail_c1(q)
            for row in base['members'][ci]:
                joints=base['j'][row].copy();weights=base['w'][row].copy()
                mass=float(base['semantic'][row,low]+base['semantic'][row,high])
                need(mass>0,'genuine adjacent-control source support')
                protected=[k for k in range(4) if weights[k]>0 and joints[k] not in (low,high)]
                slots=[k for k in range(4) if k not in protected]
                desired=[(low,np.float32(mass*(1-q))),(high,np.float32(mass*q))]
                desired=[pair for pair in desired if pair[1]>0]
                need(len(slots)>=len(desired),'all original residual influences retained, no pruning')
                for k in slots:joints[k]=0;weights[k]=0
                for k,(joint,weight) in zip(slots,desired):joints[k]=joint;weights[k]=weight
                need(abs(float(weights.astype(float).sum()-base['w'][row].astype(float).sum()))<2e-7,'unchanged Float32 source mass tolerance')
                if not np.array_equal(joints,base['j'][row]) or not np.array_equal(weights,base['w'][row]):
                    overlay.append(dict(row=row,joints=joints.tolist(),weights=weights.tolist(),region=name))
    overlay.sort(key=lambda r:r['row'])
    return overlay,reports

def notice(parent_sha,recipe_sha,role):
    return dict(source_parent_sha256=parent_sha,recipe_sha256=recipe_sha,binding_version=5,role=role,
                qualification='UNRUN',old_certificate_transferred=False)

def export(parent,overlay,recipe_sha,parent_sha,role):
    doc,binary=read(parent);out=bytearray(binary)
    for name,key in [('JOINTS_0','joints'),('WEIGHTS_0','weights')]:
        rows,offset,stride,width=view(doc,binary,0,name)
        for row in overlay:
            encoded=np.array(row[key],dtype=rows.dtype).tobytes()
            need(len(encoded)==width,'exact authored skin stream width')
            begin=offset+row['row']*stride;out[begin:begin+width]=encoded
    child=copy.deepcopy(doc);child.setdefault('asset',{}).setdefault('extras',{})[NOTICE]=notice(parent_sha,recipe_sha,role)
    raw=write(child,out);need(len(raw)<=4*1024**2,'unchanged four-MiB master cap')
    return raw

def audit_one(parent,child,base,recipe_sha,parent_sha,role):
    pd,pb=read(parent);cd,cb=read(child);clean=copy.deepcopy(cd)
    need(clean['asset']['extras'].pop(NOTICE,None)==notice(parent_sha,recipe_sha,role),'exact V5 parent/recipe/role notice')
    need(clean==pd and len(cb)==len(pb),'all original JSON/rig/clips/geometry declarations unchanged')
    free=base['masks']['head']|base['masks']['tail'];allowed=bytearray(len(pb))
    for name in ('JOINTS_0','WEIGHTS_0'):
        _,offset,stride,width=view(pd,pb,0,name)
        for row in np.flatnonzero(free):allowed[offset+int(row)*stride:offset+int(row)*stride+width]=b'\1'*width
    differing=np.flatnonzero(np.frombuffer(pb,dtype='u1')!=np.frombuffer(cb,dtype='u1'))
    need(all(allowed[int(i)] for i in differing),'BODY/EYE/unlisted HAIR/geometry/texture/clip and all outside BIN bytes unchanged')
    j=view(cd,cb,0,'JOINTS_0')[0];w=view(cd,cb,0,'WEIGHTS_0')[0];sem=dense(j,w)
    need(np.isfinite(w).all() and (w>=0).all(),'finite nonnegative source weights')
    mass_delta=float(np.max(np.abs(w.astype(float).sum(axis=1)-base['w'].astype(float).sum(axis=1))))
    need(mass_delta<2e-7,'source Float32 mass preserved')
    for ci,rows in enumerate(base['members']):
        need(all(np.array_equal(sem[rows[0]],sem[row]) for row in rows),'canonical weld class semantic equality')
    for name,(low,high) in PALETTES.items():
        for row in np.flatnonzero(base['masks'][name]):
            row=int(row)
            old_out=base['semantic'][row].copy();new_out=sem[row].copy();old_out[[low,high]]=0;new_out[[low,high]]=0
            need(np.array_equal(old_out,new_out),'original residual/body influences preserved, no new palette or pruning')
            for k in range(4):
                if base['w'][row,k]>0 and base['j'][row,k] not in (low,high):
                    need(j[row,k]==base['j'][row,k] and w[row,k].tobytes()==base['w'][row,k].tobytes(),'original off-palette positive slot bits unchanged')
    # Independent admission checks the exported field equation, not equality to
    # the producer's overlay. Its rounding bound is Float32 arithmetic only.
    field_residual={}
    for name,(low,high) in PALETTES.items():
        values=[]
        for rows in base['members']:
            row=rows[0];mass=sem[row,low]+sem[row,high]
            value=float(sem[row,high]/mass) if mass else 0.0
            values.append(inverse_tail_c1(value) if name=='tail' else value)
        worst=0.0
        for ci,rows in enumerate(base['members']):
            if not base['masks'][name][rows[0]]:continue
            degree=sum(base['neighbors'][ci].values())
            residual=sum(weight*(values[ci]-values[other]) for other,weight in base['neighbors'][ci].items())/degree
            worst=max(worst,abs(residual))
        need(worst<=8*np.finfo(np.float32).eps,'exported source harmonic equation within explicit Float32 rounding bound')
        field_residual[name]=worst
    need(np.array_equal(j[base['core']],base['j'][base['core']]) and np.array_equal(w[base['core']],base['w'][base['core']]),'all1184 skull core tuples exact')
    return dict(changed_BIN_bytes=len(differing),maximum_mass_delta=mass_delta,field_equation_residual=field_residual,
                all_BODY_EYE_geometry_UV_images_rig_IBMs_old13_new17_bytes_exact=True,all1184_skull_core_exact=True,
                all_unlisted_HAIR_rows_exact=True,weld_classes_checked=len(base['members']))

def pair_admission(parent,reference,candidate,paired,base,recipe_sha):
    reports=[audit_one(parent,candidate,base,recipe_sha,PARENT,'natural-idle-candidate'),
             audit_one(reference,paired,base,recipe_sha,PAIR,'paired-original925-geometry-reference')]
    cd,cb=read(candidate);rd,rb=read(paired)
    for mesh in range(3):
        for name in ('JOINTS_0','WEIGHTS_0'):
            need(np.array_equal(view(cd,cb,mesh,name)[0],view(rd,rb,mesh,name)[0]),'entire candidate/paired925 skin tuple equality')
    return reports

def controls(parent,reference,candidate,paired,base,recipe_sha):
    doc,binary=read(candidate);results=[]
    def mutate(mesh,name,row,component,value=None):
        out=bytearray(binary);a,offset,stride,_=view(doc,binary,mesh,name);begin=offset+row*stride+component*a.dtype.itemsize
        if value is None:out[begin]^=1
        else:out[begin:begin+a.dtype.itemsize]=np.array(value,dtype=a.dtype).tobytes()
        return write(doc,out)
    free=base['masks']['head']|base['masks']['tail'];core=int(np.flatnonzero(base['core'])[0]);fixed=int(np.flatnonzero(~free&~base['core'])[0])
    free_row=next(rows[0] for rows in base['members'] if len(rows)==1 and free[rows[0]])
    actual_weights=view(doc,binary,0,'WEIGHTS_0')[0]
    weld=next(rows for rows in base['members'] if len(rows)>1 and free[rows[0]] and min(actual_weights[rows[0],:2])>0)
    weld_binary=bytearray(binary);wa,wo,ws,_=view(doc,binary,0,'WEIGHTS_0')
    wrow=weld[0];amount=float(min(wa[wrow,:2]))*.25
    for component,change in [(0,amount),(1,-amount)]:
        begin=wo+wrow*ws+component*wa.dtype.itemsize
        weld_binary[begin:begin+wa.dtype.itemsize]=np.array(float(wa[wrow,component])+change,dtype=wa.dtype).tobytes()
    old_clip=doc['animations'][0]['samplers'][0]['output'];new_clip=doc['animations'][1]['samplers'][-1]['output']
    def change_accessor(index):
        out=bytearray(binary);a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];out[v.get('byteOffset',0)+a.get('byteOffset',0)]^=1
        return write(doc,out)
    image=doc['images'][0];iv=doc['bufferViews'][image['bufferView']];im=bytearray(binary);im[iv.get('byteOffset',0)]^=1
    testcases=[('BODY position',mutate(1,'POSITION',0,0),paired),('EYE position',mutate(2,'POSITION',0,0),paired),
        ('unlisted HAIR weight',mutate(0,'WEIGHTS_0',fixed,0),paired),('single weld member with mass preserved',write(doc,weld_binary),paired),
        ('rigid skull core',mutate(0,'WEIGHTS_0',core,0),paired),('forbidden positive joint',mutate(0,'JOINTS_0',free_row,0,6),paired),
        ('source weight mass',mutate(0,'WEIGHTS_0',free_row,0,float(view(doc,binary,0,'WEIGHTS_0')[0][free_row,0])+0.1),paired),
        ('old13 clip byte',change_accessor(old_clip),paired),('new17 clip byte',change_accessor(new_clip),paired),
        ('HAIR geometry byte',mutate(0,'POSITION',0,0),paired),('original texture byte',write(doc,im),paired),
        ('mismatched paired source',candidate,candidate)]
    # Remove only the C1 transfer on a whole canonical tail class. Palette,
    # total mass, weld consistency, geometry and all motion bytes stay intact.
    # Independent inverse-field admission must still refuse this corruption.
    latent,_=field(base,'tail')
    ci=next(ci for ci,u in latent.items() if 0<u<1 and u!=.5)
    bypass=bytearray(binary);wa,wo,ws,_=view(doc,binary,0,'WEIGHTS_0')
    for row in base['members'][ci]:
        mass=float(base['semantic'][row,4]+base['semantic'][row,5])
        for component,value in [(0,mass*(1-latent[ci])),(1,mass*latent[ci])]:
            begin=wo+row*ws+component*wa.dtype.itemsize
            bypass[begin:begin+wa.dtype.itemsize]=np.array(value,dtype=wa.dtype).tobytes()
    testcases.append(('original C1 tail transfer bypass',write(doc,bypass),paired))
    for label,bad,bad_pair in testcases:
        need(bad!=candidate or bad_pair!=paired,'meaningful actual mutation')
        try:pair_admission(parent,reference,bad,bad_pair,base,recipe_sha)
        except (ValueError,KeyError,IndexError) as error:results.append(dict(control=label,detected=True,reason=str(error),mutant_sha256=sha(bad),paired_sha256=sha(bad_pair)))
        else:raise ValueError('Independent mutation control escaped: '+label)
    return results

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(10,11))
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('parent','reference','recipe','candidate_out','paired_out','report_out','overlay_out'):
        parser.add_argument('--'+key.replace('_','-'),required=True,type=Path)
    args=parser.parse_args();outputs=[args.candidate_out,args.paired_out,args.report_out,args.overlay_out]
    need(all(not path.exists() for path in outputs),'fresh outside-app outputs required')
    start=time.process_time();parent=args.parent.read_bytes();reference=args.reference.read_bytes();recipe_raw=args.recipe.read_bytes();recipe=json.loads(recipe_raw)
    need(sha(parent)==PARENT and sha(reference)==PAIR,'immutable V2 candidate/paired925 source')
    need(recipe['schema']=='source_harmonic_attachment_v5_C1' and recipe['source_parent_sha256']==PARENT and recipe['paired_parent_sha256']==PAIR,'explicit new versioned source recipe')
    need(recipe['method']=='positive_shared_cotangent_Dirichlet_original_V2_boundaries_then_original_tail_C1' and recipe['head_transition_s']==[.48,.9] and recipe['tail_transition_t']==[.18,1.0],'fixed source-only anatomical method, no parameter search')
    need(recipe['numerical_versions']==dict(numpy=np.__version__,scipy=scipy.__version__),'declared deterministic numerical toolchain')
    base=source(parent);rd,rb=read(reference)
    for name in ('POSITION','JOINTS_0','WEIGHTS_0','indices'):
        need(np.array_equal(view(base['doc'],base['binary'],0,name)[0],view(rd,rb,0,name)[0]),'candidate/paired original HAIR source equality')
    overlay,fields=tuples(base);rsha=sha(recipe_raw)
    candidate=export(parent,overlay,rsha,PARENT,'natural-idle-candidate');paired=export(reference,overlay,rsha,PAIR,'paired-original925-geometry-reference')
    admission=pair_admission(parent,reference,candidate,paired,base,rsha);negative=controls(parent,reference,candidate,paired,base,rsha)
    report=dict(status='V5_C1_SOURCE_EXPORT_AND_MUTATION_CONTROLS_ONLY_PASS_NATIVE_UNRUN',
        source_parent_sha256=PARENT,paired_parent_sha256=PAIR,candidate_sha256=sha(candidate),paired925_sha256=sha(paired),
        candidate_bytes=len(candidate),paired925_bytes=len(paired),recipe_sha256=rsha,producer_sha256=sha(Path(__file__).read_bytes()),
        numerical_versions=dict(numpy=np.__version__,scipy=scipy.__version__),source_graph=base['graph'],fields=fields,
        changed_HAIR_rows=len(overlay),maximum_allowed_HAIR_rows=1070,admission=admission,negative_controls=negative,
        CPU_seconds=time.process_time()-start,canonical_install=False,old13_native129='UNRUN',new17_native129='UNRUN',
        paired925_raw129='UNRUN',posed925='UNRUN',native_world='UNRUN',runtime_adoption=False,old_certificate_transferred=False)
    args.candidate_out.write_bytes(candidate);args.paired_out.write_bytes(paired)
    args.overlay_out.write_text(json.dumps({'0':overlay},separators=(',',':'))+'\n')
    args.report_out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)

if __name__=='__main__':main()
