"""Diagnostic only: fixed V5 C1 export under already-recorded V3 bone matrices."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import resource
resource.setrlimit(resource.RLIMIT_CPU,(10,11))
import hashlib,json,struct,time
from pathlib import Path
import numpy as np

PREP=Path(__file__).resolve().parent
APP=Path('/tmp/chicago-horse-20261029/chicago/4d')
OUT=Path('/tmp/horse-attachment-v5-C1-artifacts-20261029-01')
poses_path=Path('/tmp/horse-root-v3-native129-20261029-01/ACTUAL-PHYSICAL129.json')
poses_raw=poses_path.read_bytes();actual=json.loads(poses_raw)
audit=json.loads((APP/'tools/transport/horse_natural_idle_root_binding_v3/INPUTS.json').read_bytes())
report=json.loads((OUT/'SOURCE-EXPORT-AND-CONTROLS.json').read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def evaluate(path,expected,control):
 raw=path.read_bytes();assert sha(raw)==expected
 n=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+n]);binary=raw[28+n:]
 def acc(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];width={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];dtype=np.dtype({5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']]);assert not a.get('sparse') and not a.get('normalized')
  return np.ndarray((a['count'],width),dtype=dtype,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',width*dtype.itemsize),dtype.itemsize)).copy()
 p=doc['meshes'][0]['primitives'][0];position=acc(p['attributes']['POSITION']).astype(float);j=acc(p['attributes']['JOINTS_0']).astype('i8');w=acc(p['attributes']['WEIGHTS_0']).astype(float);w=(w/np.abs(w).sum(axis=1,keepdims=True)).astype('f4').astype(float)
 tri=acc(p['indices']).reshape(-1,3).astype('i8');ibm=acc(doc['skins'][0]['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1).astype(float);rest=position[tri];restedges=np.stack([np.linalg.norm(rest[:,(k+1)%3]-rest[:,k],axis=1)for k in range(3)],axis=1);restnormal=np.cross(rest[:,1]-rest[:,0],rest[:,2]-rest[:,0]);restarea=np.linalg.norm(restnormal,axis=1)
 homogeneous=np.concatenate([position,np.ones((len(position),1))],axis=1);summary=[];maximum_edge=None;maximum_area=None;residual=0
 for pose in actual['poses']:
  world=np.array(pose['world_matrices']).reshape(-1,4,4).transpose(0,2,1);bones=(world@ibm).astype('f4').astype(float);moved=np.zeros_like(position)
  for k in range(4):moved+=w[:,k,None]*np.einsum('nij,nj->ni',bones[j[:,k],:3,:],homogeneous)
  xyz=moved[tri];edges=np.stack([np.linalg.norm(xyz[:,(k+1)%3]-xyz[:,k],axis=1)for k in range(3)],axis=1);ratios=np.divide(edges,restedges,out=np.ones_like(edges),where=restedges>1e-8);normal=np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]);areas=np.divide(np.linalg.norm(normal,axis=1),restarea,out=np.ones_like(restarea),where=restarea>1e-12)
  ti,k=np.unravel_index(int(np.argmax(ratios)),ratios.shape);ai=int(np.argmax(areas))
  if maximum_edge is None or ratios[ti,k]>maximum_edge['ratio']:maximum_edge=dict(time_s=pose['time'],triangle=int(ti),edge_slot=int(k),vertices=tri[ti].tolist(),ratio=float(ratios[ti,k]))
  if maximum_area is None or areas[ai]>maximum_area['ratio']:maximum_area=dict(time_s=pose['time'],triangle=ai,vertices=tri[ai].tolist(),ratio=float(areas[ai]))
  row=dict(time_s=pose['time'],edgeMin=float(min(1,ratios.min())),edgeMax=float(max(1,ratios.max())),areaMin=float(min(1,areas.min())),areaMax=float(max(1,areas.max())),negative=int(np.sum(np.sum(restnormal*normal,axis=1)<0)),minY=float(moved[:,1].min()),over_edge_faces=sorted(np.flatnonzero((ratios>1.1).any(axis=1)|(ratios<.9).any(axis=1)).tolist()),over_area_faces=sorted(np.flatnonzero((areas>1.2)|(areas<.8)).tolist()))
  if control:
   native=next(s for s in pose['surfaces'] if s['mesh']==0);residual=max(residual,*[abs(row[key]-native[key])for key in ('edgeMin','edgeMax','areaMin','areaMax')]);assert row['negative']==native['negative']
  summary.append(row)
 if control:assert residual<2e-5
 return dict(source_sha256=expected,maximum_edge=maximum_edge,maximum_area=maximum_area,native_calibration_residual=residual if control else None,poses=summary,
             diagnostic_failing_samples=sum(bool(x['over_edge_faces']or x['over_area_faces']or x['negative']or x['minY']<-.00001)for x in summary))
start=time.process_time();v3=evaluate(APP/audit['inputs']['candidate']['path'],audit['inputs']['candidate']['sha256'],True);v5=evaluate(OUT/'horse-sevket-natural-planted-attachment-v5-C1.glb',report['candidate_sha256'],False)
result=dict(status='OFFLINE_DIAGNOSTIC_ONLY_NOT_NATIVE_QUALIFICATION',actual_native_matrix_report_sha256=sha(poses_raw),v3_control=v3,v5_preview=v5,source_producer_uses_no_poses=True,source_changes=False,native_static='UNRUN',native_old13='UNRUN',native_new17='UNRUN',posed925='UNRUN',runtime_adoption=False,CPU_seconds=time.process_time()-start)
target=PREP/'STORED-MATRIX-V5-C1-DIAGNOSTIC-01.json';assert not target.exists();target.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:{k:value[k]for k in ('maximum_edge','maximum_area','native_calibration_residual','diagnostic_failing_samples')}for key,value in [('v3_control',v3),('v5_preview',v5)]},indent=2));print('CPU_seconds',result['CPU_seconds'])
