import datetime,json,os,re,shutil,subprocess,sys
from pathlib import Path
O=Path(__file__).resolve().parent; R=Path('/tmp/chicago-wagon-20261029'); A=R/'chicago/4d'; L=O.parent.parent
SUP='/workspace/.cloud-setup/transport-supervise.py'; BIND=O/'bind-checked-followup-published-source.py'
plan=json.loads((O/'ACTUAL-NEWHEAD-NATIVE-SMOKE-PLAN-SUMMARY.json').read_bytes());receipt=json.loads((O/'ACTUAL-NORMAL-CHECKED-FOLLOWUP-PUSH.json').read_bytes());assert(plan['HEAD'],plan['TREE'],plan['APP'])==(receipt['HEAD'],receipt['TREE'],receipt['APP'])
bridge=json.loads((O/'TARGETED-TO-COMMITTED-PUBLISH-COVERAGE-BRIDGE.json').read_bytes());assert bridge['result'].startswith('PASS')and bridge['committed_HEAD']==plan['HEAD']and(bridge['TREE'],bridge['APP'])==(plan['TREE'],plan['APP'])
# Both first-profile groups have actually closed and been rebound, before this
# controller is started. Never assume an existing unclosed transcript is a PASS.
for v in ['MOBILE','DESKTOP']:
 d=json.loads((Path('/tmp')/f'WAGON-OWNBOUND-PUBLISHED-{v}-STAGE1-01/ACTUAL-PARTIAL-VERDICT.json').read_bytes())
 assert d['result'].startswith('PASS') and d['cleanup_complete'] and d['remaining_owned_children']==0
 assert d['HEAD']==plan['HEAD']
rows=[r for r in plan['groups'] if r['stage']!='1'and not(r['viewport']=='mobile'and r['stage']=='2-3')];assert len(rows)==25;completed=[]
prior=json.loads((O/'REMAINING-NATIVE-PUBLISHED-GROUPS-STOPPED02-20261030T0041.json').read_bytes())
assert prior['status'].startswith('STOPPED') and prior['error']=="BrokenPipeError(32, 'Broken pipe')"
assert prior['HEAD']==plan['HEAD'] and [(x['viewport'],x['stage'])for x in prior['completed']]==[('mobile','4'),('mobile','5'),('mobile','6')]
admit=O/'RESUME03-ACTUAL-ADMISSION';admit.mkdir(exist_ok=False)
with(admit/'CURRENT-BINDING.log').open('wb')as f:subprocess.run([sys.executable,str(BIND),'before',str(admit)],cwd=A,stdout=f,stderr=subprocess.STDOUT,check=True)
current_binding=json.loads((admit/'SOURCE-AND-MIRROR-BEFORE.json').read_bytes())
completed=[]
for saved in prior['completed']:
 v=saved['viewport'];stage=saved['stage'];attempt='02'if stage=='4'else'01'
 out=Path('/tmp')/f'WAGON-OWNBOUND-PUBLISHED-{v.upper()}-STAGE{stage}-{attempt}';prefix=L/f'rail-owned-wagon-bound-published-{v}-{stage}-{attempt}'
 actual=json.loads((out/'ACTUAL-PARTIAL-VERDICT.json').read_bytes());result=json.loads(Path(str(prefix)+'.result.json').read_bytes());cleanup=json.loads(Path(str(prefix)+'.cleanup.json').read_bytes())
 assert actual==saved and actual['result'].startswith('PASS') and actual['failed_checks']==0
 assert (actual['HEAD'],actual['TREE'],actual['APP'])==(plan['HEAD'],plan['TREE'],plan['APP'])
 assert result['returncode']==0 and not result['timed_out'] and result['requested_timeout_seconds']==600 and result['effective_timeout_seconds']==600 and result['timeout_override_reason']is None
 assert result['command']==['node','tools/smoke_renderer.mjs','--published']and result['cwd']==str(A)
 assert cleanup['cleanup_complete'] and cleanup['remaining_owned_children']==[]
 assert json.loads((out/'SOURCE-AND-MIRROR-BEFORE.json').read_bytes())==json.loads((out/'SOURCE-AND-MIRROR-AFTER.json').read_bytes())==current_binding
 transcript=Path(str(prefix)+'.log').read_text(errors='replace');summary=re.search(r'(\d+) passed, (\d+) failed',transcript)
 assert 'SMOKE PASS'in transcript and summary and (int(summary[1]),int(summary[2]))==(actual['passed_checks'],0)
 completed.append(actual)
skipped={(x['viewport'],x['stage'])for x in completed};assert len(skipped)==3
(admit/'ACTUAL-VALIDATED-CLOSED-GROUPS.json').write_text(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),HEAD=plan['HEAD'],completed=completed,remaining_groups=22,source_index_fullmirror_exact=True),indent=2)+'\n')
(O/'EXTERNAL-CONTROLLER-03.pid').write_text(str(os.getpid())+'\n')

S=O/'REMAINING-NATIVE-PUBLISHED-GROUPS-ACTUAL-STATE.json'
def save(status,**kw):
 data=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),HEAD=plan['HEAD'],status=status,completed=completed,remaining_groups=len(rows)-len(completed),whole_gate='PENDING unless every required group actually passes and binds',**kw)
 S.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data),flush=True)
try:
 for row in rows:
  if(row['viewport'],row['stage'])in skipped:continue
  v=row['viewport'];stage=row['stage'];attempt='02'if v=='mobile'and stage=='4'else'01';out=Path('/tmp')/f'WAGON-OWNBOUND-PUBLISHED-{v.upper()}-STAGE{stage}-{attempt}';prefix=L/f'rail-owned-wagon-bound-published-{v}-{stage}-{attempt}'
  assert not out.exists() and not Path(str(prefix)+'.log').exists(),f'Existing actual group must be reviewed, never overwritten: {out}'
  save('PREPARING next native group',active=row,prefix=str(prefix),output=str(out))
  out.mkdir();(out/'PNGS').mkdir()
  with (out/'STANDING-RECORD.log').open('wb')as f:subprocess.run(['node','tools/dev-smoke-state.mjs','ask','--viewport',v,'--stage',stage],cwd=A,stdout=f,stderr=subprocess.STDOUT,check=True)
  with(out/'BINDING-BEFORE.log').open('wb')as f:subprocess.run([sys.executable,str(BIND),'before',str(out)],cwd=A,stdout=f,stderr=subprocess.STDOUT,check=True)
  cg=Path('/sys/fs/cgroup');maxmem=int((cg/'memory.max').read_text());mem=int((cg/'memory.current').read_text())
  stats={key:int(value)for key,value in(line.split()for line in(cg/'memory.stat').read_text().splitlines())}
  events={key:int(value)for key,value in(line.split()for line in(cg/'memory.events').read_text().splitlines())}
  raw=max(0,maxmem-mem);clean_inactive=max(0,stats['inactive_file']-stats['file_dirty']-stats['file_writeback'])
  resource=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),memory_max_bytes=maxmem,memory_current_bytes=mem,memory_free_bytes=maxmem-mem,raw_headroom_bytes=raw,clean_inactive_file_bytes=clean_inactive,memory_available_bytes=raw+clean_inactive,memory_stat=stats,memory_events=events,all_memory_events_zero=all(value==0 for value in events.values()),available_calculation='max(0,memory.max-memory.current)+max(0,inactive_file-file_dirty-file_writeback); cgroup v2 memory.stat; excludes shmem, active_file and slab',memory_floor_bytes=4*1024**3,workspace_free_bytes=shutil.disk_usage('/workspace').free,tmp_free_bytes=shutil.disk_usage('/tmp').free)
  (out/'ACTUAL-LAUNCH-RESOURCES.json').write_text(json.dumps(resource,indent=2)+'\n')
  assert resource['memory_available_bytes']>=4*1024**3 and resource['all_memory_events_zero'] and resource['workspace_free_bytes']>=512*1024**2 and resource['tmp_free_bytes']>=1024**3,'Conservative available-memory/events/disk reserve failed; no browser launched'
  assert not Path('/workspace/.cloud-setup/transport-browser-resource-pause.json').exists(),'Root browser pause active; no browser launched'
  tmp=Path('/tmp')/f'wg-bound-{v[0]}{stage.replace("-", "_")}-r{attempt}';tmp.mkdir(mode=0o700,exist_ok=False)
  env={**os.environ,'TMPDIR':str(tmp),'SMOKE_VIEWPORT':v,'SMOKE_STAGE':stage,'SMOKE_TIMING':'1','SMOKE_SHOTS':str(out/'PNGS')}
  save('RUNNING actual native group',active=row,prefix=str(prefix),output=str(out))
  rc=subprocess.run([sys.executable,SUP,'--prefix',str(prefix),'--cwd',str(A),'--timeout','600','--','node','tools/smoke_renderer.mjs','--published'],cwd=A,env=env).returncode
  result=json.loads(Path(str(prefix)+'.result.json').read_bytes());cleanup=json.loads(Path(str(prefix)+'.cleanup.json').read_bytes())
  with(out/'BINDING-AFTER.log').open('wb')as f:subprocess.run([sys.executable,str(BIND),'after',str(out)],cwd=A,stdout=f,stderr=subprocess.STDOUT,check=True)
  transcript=Path(str(prefix)+'.log').read_text(errors='replace');summary=re.search(r'(\d+) passed, (\d+) failed',transcript)
  passed=rc==0 and result['returncode']==0 and not result['timed_out'] and cleanup['cleanup_complete'] and not cleanup['remaining_owned_children']and 'SMOKE PASS'in transcript and summary is not None and int(summary[2])==0
  verdict=dict(HEAD=plan['HEAD'],TREE=plan['TREE'],APP=plan['APP'],passed_checks=int(summary[1])if summary else None,failed_checks=int(summary[2])if summary else None,result='PASS native partial group only'if passed else'NONPASS actual native partial group',viewport=v,stage=stage,seconds=result['seconds'],timed_out=result['timed_out'],cleanup_complete=cleanup['cleanup_complete'],remaining_owned_children=len(cleanup['remaining_owned_children']),source_index_fullmirror_unchanged=True,whole_published_gate='PENDING until all required groups pass')
  (out/'ACTUAL-PARTIAL-VERDICT.json').write_text(json.dumps(verdict,indent=2)+'\n');completed.append(verdict)
  if not passed:save('STOPPED at first actual NONPASS',active=row,prefix=str(prefix));raise SystemExit(1)
  save('CLOSED PASS partial group; preparing next',last=row)
 save('ALL planned native groups closed PASS; root review and fresh CI/merge still required',whole_gate_candidates='25remaining native groups plus freshly closed first mobile/desktop and exact209targeted phone2-3 bridged source/mirror; root must audit complete coverage, no CI/merge claim')
except BaseException as err:
 if not isinstance(err,SystemExit):save('STOPPED exception/resource/source issue; inspect actuals before resuming',error=repr(err))
 raise
