import hashlib, json, os, subprocess
from pathlib import Path
R=Path('/tmp/chicago-wagon-20261029');A=R/'chicago/4d';O=Path(__file__).resolve().parent
BASE='ec16b8dd726fa7852ede885ef2d754d55b9b4c59';OLD='9e14c138848ef854a535271fbd3feaae52dd4aa2'
PREFIX=O.parent/'rail-native-preflight-ec16-02';F=O/'COMPLETE-NATIVE-PREFLIGHT-02'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads(Path(str(PREFIX)+'.result.json').read_bytes());c=json.loads(Path(str(PREFIX)+'.cleanup.json').read_bytes())
assert r['returncode']==0 and not r['timed_out'] and c['cleanup_complete'] and not c['remaining_owned_children']
assert json.loads((F/'ACTUAL-CLOSURE.json').read_bytes())['result'].startswith('PASS')
b=json.loads((F/'SOURCE-BINDING.json').read_bytes())
assert git('rev-parse','HEAD').decode().strip()==OLD and git('rev-parse','MERGE_HEAD').decode().strip()==BASE
assert git('write-tree').decode().strip()==b['TREE']
assert git('ls-files','--stage','-z')==(F/'COMPLETE-INDEX.z').read_bytes()
assert not git('diff','--name-only').strip()
for row in b['source_paths']:
 p=R/row['path'];assert (not p.exists()) if row.get('deleted') else (p.is_file() and sha(p)==row['sha256']),row['path']
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
message=O/'EXACT-CHECKED-MERGE-MESSAGE.txt'
message.write_text('T-2793: integrate DEV ec16 and preserve rail context recovery\n\nRetain the checked wagon master, source credits and runtime LOD bytes.\nPreserve the rail render-loop recovery fix and canonical generated provenance\nwhile integrating the accepted current 1904 house geometry and metadata.\n\nRetain the accepted T-2376 Green Tree wagon-bay placement in the exact\nprotection baseline. Its one existing wagon moved with its bay upstream;\nall 80 other records, dimensions and eligibility remain unchanged, and all\noriginal checker assertions remain in force.\n\nThe exact staged tree passed the full native preflight. Native1904 memory\npassed the original 1125 MiB desktop/400 MiB phone comparisons on the same\nruntime closure before a documented guard-only accepted-DEV baseline update.\n')
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','--file',str(message)],cwd=R,check=True)
head=git('rev-parse','HEAD').decode().strip()
assert git('rev-parse','HEAD^{tree}').decode().strip()==b['TREE']
assert git('rev-parse','HEAD:chicago/4d').decode().strip()==b['APP']
assert git('rev-parse','HEAD^1').decode().strip()==OLD and git('rev-parse','HEAD^2').decode().strip()==BASE
assert git('merge-base',BASE,'HEAD').decode().strip()==BASE
assert not git('status','--porcelain').strip()
checks=[]
for label,cmd in [('real-newHEAD-changelog',['node','tools/check-changelog-entry.mjs',BASE,'HEAD']),('real-newHEAD-ID',['node','tools/resolve_id_collisions.mjs','--base',BASE,'--check'])]:
 p=subprocess.run(cmd,cwd=A,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(O/(label+'.log')).write_bytes(p.stdout);print(p.stdout.decode(errors='replace'),flush=True);checks.append(dict(label=label,command=cmd,returncode=p.returncode));assert p.returncode==0,label
assert not git('status','--porcelain').strip()
out=dict(result='CHECKED EXACT MERGE +REAL NEWHEAD CHANGELOG/ID/BASE/TREE/PARENTS/CLEAN PASS; normal push still pending',HEAD=head,TREE=b['TREE'],APP=b['APP'],parents=[OLD,BASE],BASE=BASE,checks=checks,full_preflight=str(F/'ACTUAL-CLOSURE.json'),strict_memory=str(O/'STRICT-NATIVE-1904-MEMORY-01/ORIGINAL-STRICT-COMPARISON.json'),push='UNRUN',DEV_merge='UNRUN; no GitHub API/green merge claim')
(O/'CHECKED-REAL-NEWHEAD.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
