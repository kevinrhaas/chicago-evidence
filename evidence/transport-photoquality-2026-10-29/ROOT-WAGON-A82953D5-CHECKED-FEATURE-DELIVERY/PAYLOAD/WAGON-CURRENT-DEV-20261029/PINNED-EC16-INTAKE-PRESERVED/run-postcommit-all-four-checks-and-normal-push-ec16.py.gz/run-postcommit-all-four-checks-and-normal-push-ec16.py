import datetime, hashlib, json, os, subprocess
from pathlib import Path
R=Path('/tmp/chicago-wagon-20261029'); A=R/'chicago/4d'; O=Path(__file__).resolve().parent
BASE='ec16b8dd726fa7852ede885ef2d754d55b9b4c59'; OLD='9e14c138848ef854a535271fbd3feaae52dd4aa2'; BRANCH='steward/t2793-wagon-photoquality-20261026'
E={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0','C4D_GATE_REQUIRE_READERS':'1','C4D_GATE_REQUIRE_BASE':'1'}
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=R,env=E).decode().strip()
b=json.loads((O/'CHECKED-REAL-NEWHEAD.json').read_bytes()); head=b['HEAD']
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==b['TREE']
assert git('rev-parse','HEAD^1')==OLD and git('rev-parse','HEAD^2')==BASE
assert git('branch','--show-current')==BRANCH and not git('status','--porcelain')
assert git('merge-base',BASE,'HEAD')==BASE
checks=[]
for label, cmd in [
 ('postcommit-changelog-entry',['node','tools/check-changelog-entry.mjs',BASE,'HEAD']),
 ('postcommit-ID-collision',['node','tools/resolve_id_collisions.mjs','--base',BASE,'--check']),
 ('postcommit-changelog-history-contract',['node','tools/check-changelog.mjs']),
 ('postcommit-changelog-pending-entries',['node','tools/changelog-entries.mjs','--check'])]:
 p=subprocess.run(cmd,cwd=A,env=E,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (O/(label+'.log')).write_bytes(p.stdout); print(p.stdout.decode(errors='replace'),flush=True)
 checks.append(dict(label=label,command=cmd,returncode=p.returncode,log_sha256=hashlib.sha256(p.stdout).hexdigest()))
 assert p.returncode==0,label
assert not git('status','--porcelain') and git('rev-parse','HEAD^{tree}')==b['TREE']
remote_before=git('ls-remote','--heads','origin','refs/heads/'+BRANCH).split()
assert len(remote_before)==2 and remote_before[0]==OLD, remote_before
out=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),HEAD=head,TREE=b['TREE'],APP=b['APP'],BASE=BASE,checks=checks,remote_before=remote_before[0],push='PENDING',DEV_merge='UNRUN; API/CI readiness unavailable')
(O/'ALL-FOUR-ACTUAL-NEWHEAD-CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','push','origin','HEAD:refs/heads/'+BRANCH],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(O/'NORMAL-CHECKED-BRANCH-PUSH.log').write_bytes(p.stdout);print(p.stdout.decode(errors='replace'),flush=True)
assert p.returncode==0,'normal branch push failed'
remote_after=git('ls-remote','--heads','origin','refs/heads/'+BRANCH).split()
assert len(remote_after)==2 and remote_after[0]==head, remote_after
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==b['TREE'] and not git('status','--porcelain')
out.update(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),push='PASS normal feature-branch update',remote_after=head,clean=True,PR=1340,DEV_merge='UNRUN; no API/CI/ready/merge claim')
(O/'ACTUAL-NORMAL-CHECKED-BRANCH-PUSH.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
