# Otis checked feature checkpoint proposal — unrun

Root must read an actual closed P full check PASS and explicitly authorize execution. H full gate currently owns the heavy slot. This proposal runs no tests, application/source/index writes, Git mutations, browser or encoder. The executor is a limited adaptation of reviewed H code97d34722dbc169dcfb55c8f79f30ca8d3344128f190e774b3b8f9efb81268370; H-TO-P-LIMITED-ADAPTATION.patch records every change. It preserves the same control flow, five existing native new-HEAD questions, current DEV/feature-ref guards and normal explicit feature push. No invented approval artifact is needed.

Fixed P inputs: repository /tmp/chicago-transport-resume-20261029; branch steward/t1790-natural-human-idle-20261029; existing public parent9400c662b24909598fa6afdea2df4d3b89e7f25d; staged wholeTREEeee92b422b653b68593fbfeab11c3c4b37122247 / APP44d9d0908178710474c4003e1631dcb8f01f8f84; source53 including16human GLBs; full semantic index18052 entries/SHA371981aa663e1a99dbeb4adc83a56992745af12f8680b8f4912a5de6f9887d34. Sourceguard0cacf9f7ebc8b650b139a6ef7c9e5148180b87ed0142dbbe5bd0812ef3ea4948 stores source paths relative to chicago/4d (the H guard used repository-relative paths), so the sole path-semantics adaptation is A/row.path.

## Actual full-gate dependency

The exact reviewed wrapper is /tmp/TRANSPORT-WHOLE-GATE-SHM-PREP-20261030/run-guarded-whole-gate.py, SHA48d63aea46fba701170523ea096f7d6dee9028101595ae9ee3675a31f2e24310. Its real P configuration uses that0cacf9 sourceguard, source53/index18052 and the expected eee/44d trees. The executor requires real /tmp/OTIS-ACTUAL-FULL-GATE-SHM-20261030-01 receipts: workerP closedPASS, bash tools/check.sh, original1200/no timeout/no override, raw final CHECK PASS, complete owned cleanup, before/after exact source and raw complete index, actual mandatory readers/base/CHECK_JOBS4, reviewed wrapper/module pins, independent resource10 before/after pair, no active owners. P full gate has not run yet. No manual PASS, isolated target result or old near8 proof substitutes for it.

After actual full gate PASS, the precommit checked source/index and actual after-publish mirror are re-read. The feature parent is checked by real ls-remote before commit; DEV is normally fetched and independently remote-bound, then the actual merge base is recorded. Commit consumes only the existing staged chicago/4d index, COMMIT-MESSAGE.txt and normal hooks. No git add, source rewrite, maintenance/pruning, rebase, force/lease-force or DEV push occurs. P.git remains an untouched object donor apart from the later expressly authorized normal commit/fetch/push. The new commit must have the exact old single parent and checked source tree.

## Five real committed-HEAD questions

With normally fetched and remote-verified DEV and actual MB=merge-base(DEV,HEAD), the existing native scripts run from chicago/4d with C4D_GATE_REQUIRE_BASE=1 and normal permitted promisor fetching:

1. node tools/check-changelog-entry.mjs MB NEW_HEAD
2. node tools/resolve_id_collisions.mjs --base DEV --check
3. node tools/check-changelog.mjs
4. node tools/changelog-entries.mjs --check
5. node tools/changelog-history.mjs --base DEV

Actual logs and return codes are required, with source/index/mirror guards before and after. This answers the real preflight questions using the actual source-identical full check plus real new-HEAD PR-event questions; it does not claim that preflight.sh itself was newly invoked. Git whitespace checks are also required. Source before/after remains exact; actual full-gate mirror retains old-HEAD metadata and is not claimed newly published for the new commit.

Both feature ref and DEV must remain unchanged immediately before the one normal explicit push to refs/heads/steward/t1790-natural-human-idle-20261029. Any race or failed check preserves the local commit and stops without force or automatic retry. Actual remote HEAD is independently verified afterward. The operation runs only after root GO under a fresh original300 supervisor prefix; EXPECTED-COMMAND.json contains the exact argv and required reviewed full-wrapper SHA. A new actual receipt honestly records all successes, timeouts or later failures.

## Acceptance and binding instructions

AGENTS.md:51 requires check.sh PASS before every app commit; :55 retains the documented600 cost ceiling, which a1200 execution allowance does not establish. :795-804 requires the full check plus merge-base changelog/ID preflight questions before PR. :805-812 separately requires published desktop1280x800 and phone390x780 smoke, zero page errors and unweakened assertions before merge. :825,874,880,885 require ticket changelog, same-PR STATUS/ROADMAP, append-only liberties and honest pending claims. Current staged STATUS:25334,25345,25347 leaves actual town motion/card/clothing, complete gates and actual PR checks separate. T1790:29-43/45-46 requires a much broader shared idle/walk/talk/gesture/carry/work/facial/transition/group-cost library; it stays open.

COMMIT-MESSAGE.txt is truthful about the finite-qualified eight derivatives and native near8 section PASS, while the original whole desktop profile remains TIMEOUT600.1310998959816. Mid motion/card/phone, accepted final video and complete world acceptance remain pending. Original failures/raw frames remain preserved. Photo quality, continuous garment acceptance, riding/driving, route population and town traffic are unfinished. No ticket closure, GitHub API/ordinary CI read, PR action, DEV merge, new-HEAD publication or preview verification is performed or claimed. This proposal prepares an incremental feature checkpoint after a real mandatory full pass; it supplies no blanket gate waiver.
