"""Execute the unchanged native V3 qualifier after root releases the heavy slot."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

REPO = Path('/tmp/chicago-horse-20261029')
APP = REPO/'chicago/4d'
PREP = Path(__file__).resolve().parent
RECORD = PREP/'CANONICAL-NATIVE-RESUME-01'
CAPTURE = Path('/tmp/horse-root-v3-native129-20261029-01')
STATIC = PREP/'ACTUAL-CANONICAL-STATIC-01.json'
ENV = {**os.environ, 'GIT_NO_LAZY_FETCH': '1'}
FREEZE = json.loads((PREP/'FROZEN-CANONICAL-ROOT-BINDING-V3-SOURCE-01.json').read_bytes())

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, env=ENV)

def save(name, value):
    (RECORD/name).write_text(json.dumps(value, indent=2)+'\n')

def binding():
    assert git('rev-parse', 'HEAD').decode().strip() == FREEZE['base_HEAD']
    assert git('write-tree').decode().strip() == FREEZE['tree']
    assert not git('diff', '--name-only').strip()
    index = git('ls-files', '--stage', '-z')
    assert digest(index) == FREEZE['semantic_index_sha256']
    rows = []
    for row in FREEZE['source_files']:
        data = (REPO/row['path']).read_bytes()
        assert len(data) == row['bytes'] and digest(data) == row['sha256'], row['path']
        rows.append(row)
    code_root = APP/'tools/transport/horse_natural_idle_root_binding_v3'
    declaration = json.loads((code_root/'CODE-PIN-PATHS.json').read_bytes())
    pins = {name: digest((APP/relative).read_bytes()) for name, relative in declaration['paths'].items()}
    assert pins == FREEZE['code_pins']
    for name, expected in declaration['preserved_old36_expected_sha256'].items():
        assert pins[name] == expected, name
    static_raw = STATIC.read_bytes()
    assert digest(static_raw) == '07aafc3ee4ec282a74c060a6de9362e16ed319bfad785bc0f84b2920fb501f48'
    static = json.loads(static_raw)
    assert static['status'] == 'ROOT_BINDING_V3_CURRENT_SOURCE_STATIC_ONLY_PASS'
    assert static['code_pins'] == pins
    assert not (REPO/'site/4d').exists(), 'Ignored old H mirror remains truthfully absent'
    return dict(HEAD=FREEZE['base_HEAD'], TREE=FREEZE['tree'], APP=FREEZE['app_tree'],
                source_files=rows, semantic_index_sha256=digest(index),
                code_pins=pins, static_proof_sha256=digest(static_raw),
                published_mirror=dict(exists=False))

assert not RECORD.exists() and not CAPTURE.exists(), 'Fresh output required'
RECORD.mkdir()
before = binding()
save('BEFORE-SOURCE-BINDING.json', before)
browser_pids = []
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        exe = Path(os.readlink(proc/'exe')).name
        if exe in {'chrome', 'chromium', 'headless_shell', 'chrome-headless-shell'}:
            browser_pids.append(int(proc.name))
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        pass
maximum = (Path('/sys/fs/cgroup')/'memory.max').read_text().strip()
current = int((Path('/sys/fs/cgroup')/'memory.current').read_text())
available = None if maximum == 'max' else int(maximum)-current
resources = dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 memory_max=maximum, memory_current=current, memory_available=available,
                 required_memory_reserve=2*1024**3, existing_browser_pids=browser_pids,
                 output_parent='/tmp', output_parent_free=shutil.disk_usage('/tmp').free,
                 required_output_free=768*1024**2, capture=str(CAPTURE),
                 reason='Native unchanged 768MiB output reserve is met on /tmp; workspace holds small supervisory receipts only')
save('ACTUAL-LAUNCH-RESOURCES.json', resources)
assert not browser_pids, 'Root must release the W browser/heavy slot before H native starts'
assert available is None or available > 2*1024**3, 'Original native RAM reserve'
assert resources['output_parent_free'] > 768*1024**2, 'Original native output reserve'
scratch = Path(tempfile.mkdtemp(prefix='hrv3-', dir='/tmp'))
assert len(str(scratch)) <= 35 and not any(scratch.iterdir())
command = ['node', 'tools/transport/horse_natural_idle_root_binding_v3/run_root_binding129.cjs', str(STATIC), str(CAPTURE)]
print(json.dumps(dict(stage='ACTUAL UNCHANGED V3 NATIVE129 START', command=command, capture=str(CAPTURE))), flush=True)
start = time.monotonic()
rc = 1
try:
    rc = subprocess.run(command, cwd=APP, env={**ENV, 'TMPDIR': str(scratch)}).returncode
finally:
    after = binding()
    assert after == before, 'Source/index/static proof/code pins changed during qualification'
    save('AFTER-SOURCE-BINDING.json', after)
    summary = dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   returncode=rc, seconds=time.monotonic()-start,
                   source_binding_unchanged=True, capture=str(CAPTURE),
                   TREE=before['TREE'], APP=before['APP'], runtime_adoption=False,
                   socket_posed_qualification='UNRUN; requires root review of this actual native result',
                   supervisor_cleanup='Read actual outer cleanup receipt after process closes')
    result_path = CAPTURE/'RESULT.json'
    if result_path.exists():
        result = json.loads(result_path.read_bytes())
        summary.update(native_status=result['status'], socket_frames=result['socket_frames'],
                       WebGL_contexts_created=result['WebGL_contexts_created'],
                       WebGL_context_requests=result['WebGL_context_requests'])
    if rc == 0:
        assert summary['native_status'] == 'NEW_ROOT_BINDING_V3_NATIVE129_CAPTURE_ONLY_COMPLETE'
        manifest = json.loads((CAPTURE/'POSE-MANIFEST.json').read_bytes())
        assert manifest['raw_Float64_bytes'] == 59214096 and len(manifest['frames']) == 129
        summary.update(result='PASS actual unchanged native old13 parity/physical, new17 physical and paired925 Float64 capture; posed proof remains UNRUN', raw_Float64_bytes=manifest['raw_Float64_bytes'])
    else:
        summary['result'] = 'NONPASS actual native qualifier; preserve result, no pose proof or adoption'
    save('ACTUAL-CLOSED-SUMMARY.json', summary)
    if scratch.exists() and not any(scratch.iterdir()):
        scratch.rmdir()
    print(json.dumps(summary), flush=True)
assert rc == 0, 'Actual native qualifier failed; no unchanged retry or runtime adoption'
